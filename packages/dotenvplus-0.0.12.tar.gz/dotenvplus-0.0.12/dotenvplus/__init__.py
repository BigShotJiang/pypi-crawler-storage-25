import os
import re

from collections.abc import MutableMapping
from typing import (
    Any, Iterator, Optional, Tuple, Dict,
    Generic, TypeVar, cast, TypedDict, List
)

__version__ = "0.0.12"

# RegEx patterns
re_keyvar = re.compile(r"^\s*(?:export\s+)?([a-zA-Z0-9_]+)\s*=\s*(.*)$")
re_isdigit = re.compile(r"^(?:-)?\d+$")
re_isfloat = re.compile(r"^(?:-)?\d+\.\d+$")
re_var_call = re.compile(r"\$\{([a-zA-Z0-9_]*)\}")

# Return types
DotT = TypeVar("DotT", bound=TypedDict)  # type: ignore


class ParsingError(Exception):
    pass


class DotEnv(MutableMapping, Generic[DotT]):
    """
    DotEnv is a dotenv parser for Python with additional type support.

    It supports parsing of string, integer, float, none, and boolean values.

    Arguments
    ---------
    path:
        The path to the .env file.
        If none are provided, it defaults to `./.env`
    update_system_env:
        If True, it will load the values to the instance's environment variables.
        Be warned that this will only support string values, so any other types will be converted to strings.
    handle_key_not_found:
        If True, it will make the object return `None` for any key that is not found.
        Essentially simulating `dict().get("Key", None)`

    Returns
    -------
        A DotEnv object that can be used to access the parsed values, just like dict.
        The object is a dictionary-like object, so you can do `DotEnv()["KEY"]` to access the value.

        It also supports type hints, so you can do `env: DotEnv[TypedDict] = DotEnv(".env")`
        and then `env.as_typed()` to get the parsed values as a typed dictionary.
        One-line version: `env: DotEnv[TypedDict] = DotEnv[TypedDict](".env").as_typed()`

    Raises
    ------
    FileNotFoundError
        If the file_path is not a valid path.
    ParsingError
        If one of the values cannot be parsed.
    """
    def __init__(
        self,
        path: Optional[str] = None,
        *,
        update_system_env: bool = False,
        handle_key_not_found: bool = False,
    ):
        # General values
        self.__env: Dict[str, Any] = {}

        # Defined values
        self.__quotes: Tuple[str, ...] = ('"', "'")
        self.__bools: Tuple[str, ...] = ("true", "false")
        self.__none: Tuple[str, ...] = ("null", "none", "nil", "undefined")

        # Config for the parser
        self.__path: str = path or ".env"
        self.__handle_key_not_found: bool = handle_key_not_found

        # Finally, the parser
        self.__parser()

        if update_system_env:
            os.environ.update({
                key: str(value)
                for key, value in self.__env.items()
            })

    def __repr__(self) -> str:
        return f"<DotEnv {self.__env}>"

    def __getitem__(self, key: str) -> Any:  # noqa: ANN401
        if self.__handle_key_not_found:
            return self.__env.get(key, None)
        return self.__env[key]

    def __setitem__(self, key: str, value: Any) -> None:  # noqa: ANN401
        if not isinstance(value, (str, int, float, bool, type(None))):
            raise TypeError(f"Value must be a string, int, float, bool, or None, got {type(value)}")
        self.__env[key] = value

    def __delitem__(self, key: str) -> None:
        del self.__env[key]

    def __str__(self) -> str:
        return str(self.__env)

    def __len__(self) -> int:
        return len(self.__env)

    def __iter__(self) -> Iterator[str]:
        return iter(self.__env)

    def copy(self) -> Dict[str, Any]:
        """ Returns a shallow copy of the parsed values. """
        return self.__env.copy()

    def to_dict(self) -> Dict[str, Any]:
        """ Returns a dictionary of the parsed values. """
        return self.__env

    def as_typed(self) -> DotT:
        """
        Returns the parsed values as a typed dictionary.

        Helpful if you want to have TypedDict support.
        Otherwise doing `DotEnv[...]` is fine, but you lose types.

        Example
        -------
        .. code-block:: python
            from dotenvplus import DotEnv
            from typing import TypedDict

            class MyTypes(TypedDict):
                STRING_VALUE: str

            env: DotEnv[MyTypes] = DotEnv(".env")
            env_types = env.as_typed()
            print(env_types["STRING_VALUE"])
        """
        return cast("DotT", self.__env)

    def __parser(self) -> None:
        """
        Parse the .env file and store the values in a dictionary.

        The keys are accessible later by using the square bracket notation
        directly on the DotEnv object.

        Raises
        ------
        FileNotFoundError
            If the file_path is not a valid path.
        ParsingError
            If one of the values cannot be parsed.
        """
        with open(self.__path, encoding="utf-8") as f:
            data: List[str] = f.readlines()

        for line_no, line in enumerate(data, start=1):
            line = line.strip()

            if line.startswith("#") or line == "":
                continue

            find_kv = re_keyvar.search(line)
            if not find_kv:
                raise ParsingError(
                    f"Error at line {line_no}: "
                    f"Expected key=value format, got '{line}'"
                )

            key, value = find_kv.groups()
            is_string_forced = False

            if (
                len(value) >= 2 and
                value[0] in self.__quotes and
                value[0] == value[-1]
            ):
                value = value[1:-1]
                is_string_forced = True
            else:
                value = value.split("#")[0].strip()

            value = re_var_call.sub(
                lambda m: str(self.__env.get(m.group(1), os.environ.get(m.group(1), ""))),
                str(value)
            )

            if not is_string_forced:
                if re_isdigit.search(value):
                    value = int(value)

                elif re_isfloat.search(value):
                    value = float(value)

                elif value.lower() in self.__bools:
                    value = value.lower() == "true"

                elif value.lower() in self.__none:
                    value = None

            self.__env[key] = value
