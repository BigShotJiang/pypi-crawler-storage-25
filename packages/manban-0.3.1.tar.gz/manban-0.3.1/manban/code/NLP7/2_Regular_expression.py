import re 

# Helper function for clean section display
def print_section(title):
    print("\n\n" + "="*50)
    print(f"{title}")
    print("="*50)

def print_list(data):
    print(", ".join(map(str, data)))

# Sample text 
text = "Hello, my name is John Doe! I am learning Python, and it's fun 2 much." 

# 1. Words
print_section("WORD EXTRACTION")
word_pattern = r'\b\w+\b' 
words = re.findall(word_pattern, text) 
print_list(words)

# 2. Words starting with P
print_section("WORDS STARTING WITH 'P'")
pattern_start_with_p = r'\bP\w*\b' 
p_words = re.findall(pattern_start_with_p, text) 
print_list(p_words)

# 3. Tokens
print_section("TOKENIZATION")
tokens = re.split(r'(\W+)', text) 
clean_tokens = [token.strip() for token in tokens if token.strip()]
print_list(clean_tokens)

# 4. Numbers
print_section("NUMBER EXTRACTION")
number_pattern = r'\b\d+\b' 
numbers = re.findall(number_pattern, text) 
print_list(numbers)

# Course text parsing 
print_section("COURSE DATA PARSING")
text = """101   COM   Computers 205   MAT   Mathematics 189   ENG    English""" 

print("Course Codes:", re.findall('[0-9]+', text)) 
print("Departments:", re.findall('[A-Z]{3}', text)) 
print("Course Names:", re.findall('[A-Za-z]{4,}', text)) 

course_pattern = r'([0-9]+)\s*([A-Z]{3})\s*([A-Za-z]{4,})' 
courses = re.findall(course_pattern, text)

print("\nStructured Courses:")
for code, dept, name in courses:
    print(f"→ Code: {code} | Dept: {dept} | Name: {name}")

# Cool example
print_section("PATTERN MATCHING (Co+l)")
cool_text = "Super Cool Coool cooool col"
print_list(re.findall(r'Co+l', cool_text))

# Word boundary
print_section("WORD BOUNDARY (toy)")
toys_text = "play toy broke toys"
print_list(re.findall(r'\btoy\b', toys_text))

# Email extraction
print_section("EMAIL EXTRACTION")
emails = """zuck26@facebook.com 
page33@google.com 
jeff42@amazon.com""" 

pattern = r'(\w+)@([A-Z0-9]+)\.([A-Z]{2,4})' 
email_matches = re.findall(pattern, emails, re.IGNORECASE)

for user, domain, ext in email_matches:
    print(f"→ Username: {user} | Domain: {domain} | Extension: {ext}")

# Cleaning tweet
print_section("TWEET CLEANING")

tweet = '''Good advice! RT @TheNextWeb:  
What I would do differently if I was learning to code today  
http://t.co/lbwej0pxOd cc: @garybernhardt #rstats''' 

def clean_tweet(tweet): 
    tweet = re.sub(r'http\S+\s*', '', tweet)      
    tweet = re.sub(r'RT|cc', '', tweet)           
    tweet = re.sub(r'#\S+', '', tweet)            
    tweet = re.sub(r'@\S+', '', tweet)            
    tweet = re.sub(r'[%s]' % re.escape(r"""!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"""), '', tweet)
    tweet = re.sub(r'\s+', ' ', tweet)            
    return tweet.strip()

print("Original Tweet:\n", tweet)
print("\nCleaned Tweet:\n", clean_tweet(tweet))
