sentence = input("Enter a sentence: ").split()

# Convert to lowercase to match emission dictionary
sentence = [w.lower() for w in sentence]

states = ["PRON", "VERB", "NOUN"]

transition = {
    "START": {"PRON": 2/3, "NOUN": 1/3},
    "PRON": {"VERB": 1},
    "VERB": {"NOUN": 2/3},
    "NOUN": {"VERB": 1}
}

emission = {
    "PRON": {"i": 1/2, "you": 1/2},
    "VERB": {"love": 2/3, "meow": 1/3},
    "NOUN": {"cats": 1/2, "dogs": 1/2}
}

V = [{}]
backpointer = [{}]

# Initialization
for state in states:
    V[0][state] = transition.get("START", {}).get(state, 0) * \
                  emission.get(state, {}).get(sentence[0], 0)
    backpointer[0][state] = None

# Recursion
for t in range(1, len(sentence)):
    V.append({})
    backpointer.append({})

    for curr_state in states:
        max_prob = 0
        best_prev_state = None

        for prev_state in states:
            prob = (
                V[t-1].get(prev_state, 0) *
                transition.get(prev_state, {}).get(curr_state, 0) *
                emission.get(curr_state, {}).get(sentence[t], 0)
            )

            if prob > max_prob:
                max_prob = prob
                best_prev_state = prev_state

        V[t][curr_state] = max_prob
        backpointer[t][curr_state] = best_prev_state

# Check if valid path exists
if all(prob == 0 for prob in V[-1].values()):
    print("\n No valid tagging found (unknown words).")
else:
    # Backtracking
    last_state = max(V[-1], key=V[-1].get)
    best_path = [last_state]

    for t in range(len(sentence) - 1, 0, -1):
        last_state = backpointer[t][last_state]
        best_path.insert(0, last_state)

    print("\n=== TAGGED SENTENCE ===")
    for word, tag in zip(sentence, best_path):
        print(f"{word:<10} → {tag}")
