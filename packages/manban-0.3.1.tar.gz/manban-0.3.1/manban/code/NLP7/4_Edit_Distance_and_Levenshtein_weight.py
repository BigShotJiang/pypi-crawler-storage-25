# Helper functions
def section(title):
    print("\n" + "="*60)
    print(title)
    print("="*60)

def print_matrix(dp, s1, s2):
    print("\nDP Matrix:\n")

    # Header row
    header = [" "] + ["∅"] + list(s2)
    print("     " + " ".join(f"{h:^5}" for h in header))

    print("     " + "-" * (6 * len(header)))

    # Rows
    for i, row in enumerate(dp):
        if i == 0:
            label = "∅"
        else:
            label = s1[i-1]

        row_str = ""
        for j, val in enumerate(row):
            row_str += f"{val:^5}"

        print(f"{label:^5}|{row_str}")


# 1. BASIC EDIT DISTANCE
def edit_distance(s1, s2): 
    n, m = len(s1), len(s2) 
    dp = [[0] * (m + 1) for _ in range(n + 1)] 

    for i in range(n + 1): 
        dp[i][0] = i 
    for j in range(m + 1): 
        dp[0][j] = j 

    for i in range(1, n + 1): 
        for j in range(1, m + 1): 
            cost = 0 if s1[i-1] == s2[j-1] else 1 
            dp[i][j] = min( 
                dp[i-1][j] + 1, 
                dp[i][j-1] + 1, 
                dp[i-1][j-1] + cost 
            ) 
    return dp


def print_edit_distance(s1, s2): 
    section("BASIC EDIT DISTANCE")

    dp = edit_distance(s1, s2)
    print(f"s1: {s1}")
    print(f"s2: {s2}")
    print(f"\nEdit Distance: {dp[len(s1)][len(s2)]}")

    print_matrix(dp, s1, s2)


print_edit_distance("CHARACTERIZATION", "NATIONALIZATION")


# 2. WEIGHTED EDIT DISTANCE
def weighted_edit_distance(s1, s2, w_ins=1, w_del=1, w_sub=lambda a, b: 0 if a == b else 1): 
    n, m = len(s1), len(s2) 
    dp = [[0] * (m + 1) for _ in range(n + 1)] 

    for i in range(n + 1): 
        dp[i][0] = i * w_del 
    for j in range(m + 1): 
        dp[0][j] = j * w_ins 

    for i in range(1, n + 1): 
        for j in range(1, m + 1): 
            dp[i][j] = min( 
                dp[i-1][j] + w_del, 
                dp[i][j-1] + w_ins, 
                dp[i-1][j-1] + w_sub(s1[i-1], s2[j-1]) 
            ) 
    return dp


def print_weighted_distance(s1, s2): 
    section("WEIGHTED EDIT DISTANCE")

    dp = weighted_edit_distance(s1, s2)

    print(f"s1: {s1}")
    print(f"s2: {s2}")
    print(f"\nWeighted Distance: {dp[len(s1)][len(s2)]}")

    print_matrix(dp, s1, s2)


print_weighted_distance("CHARACTERIZATION", "NATIONALIZATION")


# 3. WORD LEVEL EDIT DISTANCE
def edit_distance_words(s1, s2): 
    words1 = s1.split() 
    words2 = s2.split() 
    n, m = len(words1), len(words2) 

    dp = [[0] * (m + 1) for _ in range(n + 1)] 

    for i in range(n + 1): 
        dp[i][0] = i 
    for j in range(m + 1): 
        dp[0][j] = j 

    for i in range(1, n + 1): 
        for j in range(1, m + 1): 
            cost = 0 if words1[i-1] == words2[j-1] else 1 
            dp[i][j] = min( 
                dp[i-1][j] + 1, 
                dp[i][j-1] + 1, 
                dp[i-1][j-1] + cost 
            ) 
    return dp, words1, words2


def print_word_distance(s1, s2):
    section("WORD LEVEL EDIT DISTANCE")

    dp, w1, w2 = edit_distance_words(s1, s2)

    print(f"s1: {s1}")
    print(f"s2: {s2}")
    print(f"\nWord-level Distance: {dp[len(w1)][len(w2)]}")

    print_matrix(dp, ["_"] + w1, ["_"] + w2)


s1 = "I love natural language processing" 
s2 = "I enjoy learning language processing" 

print_word_distance(s1, s2)
