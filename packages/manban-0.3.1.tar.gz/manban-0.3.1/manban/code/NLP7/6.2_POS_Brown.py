#BROWN CORPUS
# pip install nltk

import nltk
from nltk.corpus import brown

# Downloads
nltk.download('brown', quiet=True)
nltk.download('universal_tagset', quiet=True)

print("\nBROWN CORPUS SAMPLE")
print("="*40)

# Get tagged sentences
sentences = brown.tagged_sents(tagset='universal')

# Show first sentence
for word, tag in sentences[0]:
    print(f"{word:<10} → {tag}")
