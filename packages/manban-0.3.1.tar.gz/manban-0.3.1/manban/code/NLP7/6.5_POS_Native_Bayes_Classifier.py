#Native Bayes Classifier
# pip install nltk

import nltk
import random
from nltk.classify import NaiveBayesClassifier
from nltk.corpus import names

# Downloads
nltk.download('names', quiet=True)

# Feature extractor
def gender_features(word):
    return {'last_letter': word[-1]}

# Prepare dataset
labeled_names = ([(n, 'male') for n in names.words('male.txt')] +
                 [(n, 'female') for n in names.words('female.txt')])

random.shuffle(labeled_names)

featuresets = [(gender_features(n), gender) for (n, gender) in labeled_names]

train_set = featuresets[500:]
test_set = featuresets[:500]

# Train classifier
classifier = NaiveBayesClassifier.train(train_set)

print("\nNAIVE BAYES CLASSIFIER")
print("="*40)

# Accuracy
accuracy = nltk.classify.accuracy(classifier, test_set)
print(f"Accuracy: {accuracy:.3f}")

# Most informative features
print("\nMost Informative Features:")
classifier.show_most_informative_features(5)

# Prediction
name = "John"
print(f"\nPrediction for '{name}': {classifier.classify(gender_features(name))}")
