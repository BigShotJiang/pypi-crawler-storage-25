import re
from nltk.util import ngrams
import textwrap

# ---------- Helper Functions ----------
def section(title):
    print("\n" + "="*60)
    print(title)
    print("="*60)

def print_inline(label, data):
    print(f"\n{label}:")
    formatted = [ " ".join(gram) for gram in data ]
    print(textwrap.fill(", ".join(formatted), width=80))

def print_tokens(label, tokens):
    print(f"\n{label}:")
    print(", ".join(tokens))


# ---------- Core Functions ----------
def preprocess(text):
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', '', text)
    return text.split()

def generate_ngrams(tokens, n):
    return list(ngrams(tokens, n))

def jaccard_coefficient(text1, text2, n):
    tokens1 = preprocess(text1)
    tokens2 = preprocess(text2)

    ngrams1 = set(generate_ngrams(tokens1, n))
    ngrams2 = set(generate_ngrams(tokens2, n))

    intersection = ngrams1.intersection(ngrams2)
    union = ngrams1.union(ngrams2)

    if len(union) == 0:
        return 0.0

    return len(intersection) / len(union)


# ---------- Input ----------
text1 = input("Enter first sentence: ")
text2 = input("Enter second sentence: ")

tokens1 = preprocess(text1)
tokens2 = preprocess(text2)

# ---------- Output ----------
section("PREPROCESSED TOKENS")
print_tokens("Sentence 1 Tokens", tokens1)
print_tokens("Sentence 2 Tokens", tokens2)

section("N-GRAMS FOR SENTENCE 1")
print_inline("Unigrams", generate_ngrams(tokens1, 1))
print_inline("Bigrams", generate_ngrams(tokens1, 2))
print_inline("Trigrams", generate_ngrams(tokens1, 3))

section("N-GRAMS FOR SENTENCE 2")
print_inline("Unigrams", generate_ngrams(tokens2, 1))
print_inline("Bigrams", generate_ngrams(tokens2, 2))
print_inline("Trigrams", generate_ngrams(tokens2, 3))

section("JACCARD SIMILARITY")
bigram_sim = jaccard_coefficient(text1, text2, 2)
trigram_sim = jaccard_coefficient(text1, text2, 3)

print(f"Bigram Similarity : {bigram_sim:.3f}")
print(f"Trigram Similarity: {trigram_sim:.3f}")
