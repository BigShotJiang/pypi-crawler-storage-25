#AVERAGED PERCEPTRON TAGGER
# pip install nltk

import nltk

# Downloads
nltk.download('punkt', quiet=True)
nltk.download('averaged_perceptron_tagger', quiet=True)

sentence = "The quick brown fox jumps over the lazy dog."
tokens = nltk.word_tokenize(sentence)

tagged = nltk.pos_tag(tokens)

print("\nAVERAGED PERCEPTRON TAGGER")
print("="*40)
for word, tag in tagged:
    print(f"{word:<10} → {tag}")
