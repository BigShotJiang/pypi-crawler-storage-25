# pip install nltk
# pip install spacy
# python -m spacy download en_core_web_sm

import nltk
import spacy
import random
from nltk.corpus import brown, names
from nltk.tokenize import word_tokenize
from nltk import pos_tag
from nltk.classify import NaiveBayesClassifier

# ---------- Helper Functions ----------
def section(title):
    print("\n" + "="*70)
    print(title)
    print("="*70)

def print_table(headers, rows):
    col_widths = [max(len(str(item)) for item in col) for col in zip(headers, *rows)]
    header_row = " | ".join(f"{h:<{col_widths[i]}}" for i, h in enumerate(headers))
    print(header_row)
    print("-" * len(header_row))
    for row in rows:
        print(" | ".join(f"{str(item):<{col_widths[i]}}" for i, item in enumerate(row)))

# ---------- NLTK Downloads (quiet) ----------
nltk.download('punkt', quiet=True)
nltk.download('averaged_perceptron_tagger', quiet=True)
nltk.download('brown', quiet=True)
nltk.download('universal_tagset', quiet=True)
nltk.download('names', quiet=True)


# 1. UNIVERSAL TAGSET
section("UNIVERSAL TAGSET (NLTK)")

sentence = "The quick brown fox jumps over the lazy dog."
tokens = word_tokenize(sentence)

tagged_universal = pos_tag(tokens, tagset='universal')
rows = [(w, t) for w, t in tagged_universal]

print_table(["Word", "Universal POS"], rows)


# 2. BROWN CORPUS
section("BROWN CORPUS (SAMPLE)")

brown_sent = brown.tagged_sents(tagset='universal')[0]
rows = [(w, t) for w, t in brown_sent]

print_table(["Word", "POS"], rows)


# 3. AVERAGED PERCEPTRON TAGGER
section("AVERAGED PERCEPTRON TAGGER")

tagged = pos_tag(tokens)
rows = [(w, t) for w, t in tagged]

print_table(["Word", "POS Tag"], rows)


# 4. SPACY POS + DEPENDENCY
section("SPACY (POS + DEPENDENCY)")

nlp = spacy.load("en_core_web_sm")
doc = nlp("Google Colab is a great platform for running Python code.")

rows = [(token.text, token.pos_, token.dep_) for token in doc]
print_table(["Word", "POS", "Dependency"], rows)


# 5. NAIVE BAYES CLASSIFIER
section("NAIVE BAYES CLASSIFIER (GENDER PREDICTION)")

def gender_features(word):
    return {'last_letter': word[-1]}

# Dataset
labeled_names = ([(n, 'male') for n in names.words('male.txt')] +
                 [(n, 'female') for n in names.words('female.txt')])

random.shuffle(labeled_names)

featuresets = [(gender_features(n), gender) for (n, gender) in labeled_names]
train_set = featuresets[500:]
test_set = featuresets[:500]

# Train model
classifier = NaiveBayesClassifier.train(train_set)

# Accuracy
accuracy = nltk.classify.accuracy(classifier, test_set)
print(f"\nAccuracy: {accuracy:.3f}")

# Informative features
print("\nMost Informative Features:")
classifier.show_most_informative_features(5)

# Prediction
name = "John"
prediction = classifier.classify(gender_features(name))
print(f"\nPrediction for '{name}': {prediction}")
