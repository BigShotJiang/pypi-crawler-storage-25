import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.probability import FreqDist
from nltk.corpus import stopwords
import matplotlib.pyplot as plt

nltk.download("punkt", quiet="True")
nltk.download("punkt_tab", quiet="True")
nltk.download("stopwords", quiet="True")

text = """On a windy Tuesday afternoon, a turquoise robot carrying three slightly 
bruised mangoes wandered past an old library. It hummed an off-key tune as if 
trying to remember the chorus of a forgotten song while tiny holographic notes 
flickered around its metal head."""

# Sentence Tokenization
tokenized_sent = sent_tokenize(text)
print("\n--- Sentences ---")
for i, sent in enumerate(tokenized_sent, 1):
    print(f"{i}. {sent}")

# Word Tokenization
tokenized_word = word_tokenize(text)
print("\n\n--- Tokenized Words ---")
print(tokenized_word)

# Frequency Distribution
freq_dist = FreqDist(tokenized_word)
print("\n\n--- Frequency Distribution (Top 10) ---")
for word, freq in freq_dist.most_common(10):
    print(f"{word}: {freq}")

# Improved Visualization
plt.figure(figsize=(12, 6))
freq_dist.plot(30, cumulative=False)

plt.title("Top 30 Word Frequency Distribution", fontsize=14)
plt.xlabel("Words", fontsize=12)
plt.ylabel("Frequency", fontsize=12)
plt.xticks(rotation=60)
plt.grid(axis='y', linestyle='--', alpha=0.7)

plt.tight_layout()
plt.show()

# Stopwords
stop_words = set(stopwords.words("english"))
print("\n\n--- Stopwords ---")
print(list(stop_words))

# Filtering
filtered_words = []
for word in tokenized_word:
    if word not in stop_words:
        filtered_words.append(word)

print("\n\n--- Filtered Words ---")
print(filtered_words)
