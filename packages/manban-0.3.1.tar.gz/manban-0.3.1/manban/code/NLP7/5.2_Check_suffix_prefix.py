import re
from nltk.util import ngrams
import textwrap

# ---------- Helper Functions ----------
def section(title):
    print("\n" + "="*60)
    print(title)
    print("="*60)

def print_inline(label, data):
    print(f"\n{label}:")
    formatted = [ " ".join(gram) for gram in data ]
    print(textwrap.fill(", ".join(formatted), width=80))

def print_tokens(label, tokens):
    print(f"\n{label}:")
    print(", ".join(tokens))

def print_pairs(label, words, values):
    print(f"\n{label}:")
    for w, v in zip(words, values):
        print(f"{w:<15} → {v}")


# ---------- Core Functions ----------
def preprocess(text):
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', '', text)
    return text.split()

def generate_ngrams(tokens, n):
    return list(ngrams(tokens, n))

def jaccard_coefficient(text1, text2, n):
    tokens1 = preprocess(text1)
    tokens2 = preprocess(text2)

    ngrams1 = set(generate_ngrams(tokens1, n))
    ngrams2 = set(generate_ngrams(tokens2, n))

    intersection = ngrams1.intersection(ngrams2)
    union = ngrams1.union(ngrams2)

    if len(union) == 0:
        return 0.0

    return len(intersection) / len(union)


# ---------- Prefix & Suffix Functions ----------
def extract_prefix(word):
    prefixes = ['un', 're', 'pre', 'dis', 'in', 'im']
    for p in prefixes:
        if word.startswith(p) and len(word) > len(p):
            return p
    return None

def extract_suffix(word):
    suffixes = ['ing', 'ed', 'ly', 's', 'es', 'ment']
    for s in suffixes:
        if word.endswith(s) and len(word) > len(s):
            return s
    return None


# ---------- Input ----------
text1 = input("Enter first sentence: ")
text2 = input("Enter second sentence: ")

tokens1 = preprocess(text1)
tokens2 = preprocess(text2)

# ---------- Output ----------
section("PREPROCESSED TOKENS")
print_tokens("Sentence 1 Tokens", tokens1)
print_tokens("Sentence 2 Tokens", tokens2)

# N-Grams
section("N-GRAMS FOR SENTENCE 1")
print_inline("Unigrams", generate_ngrams(tokens1, 1))
print_inline("Bigrams", generate_ngrams(tokens1, 2))
print_inline("Trigrams", generate_ngrams(tokens1, 3))

section("N-GRAMS FOR SENTENCE 2")
print_inline("Unigrams", generate_ngrams(tokens2, 1))
print_inline("Bigrams", generate_ngrams(tokens2, 2))
print_inline("Trigrams", generate_ngrams(tokens2, 3))

# Similarity
section("JACCARD SIMILARITY")
bigram_sim = jaccard_coefficient(text1, text2, 2)
trigram_sim = jaccard_coefficient(text1, text2, 3)

print(f"Bigram Similarity : {bigram_sim:.3f}")
print(f"Trigram Similarity: {trigram_sim:.3f}")

# Prefix & Suffix Analysis
section("PREFIX & SUFFIX ANALYSIS")

def print_filtered_pairs(label, words, values):
    print(f"\n{label}:")
    found = False
    for w, v in zip(words, values):
        if v is not None:
            print(f"{w:<15} → {v}")
            found = True
    if not found:
        print("No matches found.")


prefixes1 = [extract_prefix(w) for w in tokens1]
suffixes1 = [extract_suffix(w) for w in tokens1]

prefixes2 = [extract_prefix(w) for w in tokens2]
suffixes2 = [extract_suffix(w) for w in tokens2]

print("\nSentence 1:")
print_filtered_pairs("Prefix", tokens1, prefixes1)
print_filtered_pairs("Suffix", tokens1, suffixes1)

print("\nSentence 2:")
print_filtered_pairs("Prefix", tokens2, prefixes2)
print_filtered_pairs("Suffix", tokens2, suffixes2)

