#Universal Tagset
# pip install nltk

import nltk

# Downloads
nltk.download('punkt', quiet=True)
nltk.download('averaged_perceptron_tagger', quiet=True)
nltk.download('universal_tagset', quiet=True)

sentence = "The quick brown fox jumps over the lazy dog."
tokens = nltk.word_tokenize(sentence)

# Universal tagset
tagged = nltk.pos_tag(tokens, tagset='universal')

print("\nUNIVERSAL TAGSET POS TAGGING")
print("="*40)
for word, tag in tagged:
    print(f"{word:<10} → {tag}")
