import nltk 
from nltk.stem import PorterStemmer, WordNetLemmatizer 
from nltk.corpus import wordnet 
from nltk.tag import RegexpTagger 
from nltk.tokenize import word_tokenize 
import re 
import spacy 
import textwrap


def section(title):
    print("\n" + "="*60)
    print(title)
    print("="*60)

def inline_list(label, data):
    print(f"\n{label}:")
    print(textwrap.fill(", ".join(map(str, data)), width=80))

def paired_display(label, original, processed):
    print(f"\n{label}:")
    for o, p in zip(original, processed):
        print(f"{o:<15} → {p}")


# 1. STEMMING
section("STEMMING (PorterStemmer)")

stemmer = PorterStemmer() 
words = ["running", "runner", "runs", "easily", "happier", "better"] 
stemmed_words = [stemmer.stem(word) for word in words] 

paired_display("Word → Stem", words, stemmed_words)


# 2. LEMMATIZATION
section("LEMMATIZATION (WordNet)")

nltk.download('wordnet', quiet=True) 
nltk.download('omw-1.4', quiet=True) 

lemmatizer = WordNetLemmatizer() 
lemmatized_words = [lemmatizer.lemmatize(word, pos=wordnet.VERB) for word in words] 

paired_display("Word → Lemma", words, lemmatized_words)


# 3. REGEX TAGGING
section("REGEX TAGGING")

nltk.download('punkt', quiet=True) 
nltk.download('punkt_tab', quiet=True) 

sentence = "The cats were running quickly." 
tokens = word_tokenize(sentence) 

patterns = [
    (r'.*ing$', 'VB'), 
    (r'.*ly$', 'RB'), 
    (r'.*es$', 'NNS'), 
] 

tagger = RegexpTagger(patterns) 
tagged = tagger.tag(tokens) 

for word, tag in tagged:
    print(f"{word:<12} → {tag}")


# 4. WORDNET SYNSETS
section("WORDNET SYNSETS")

synsets = wordnet.synsets("running") 
if synsets:
    lemmas = [lemma.name() for lemma in synsets[0].lemmas()]
    inline_list("First Synset Lemmas", lemmas)
else:
    print("No synsets found.")


# 5. SUFFIX EXTRACTION
section("SUFFIX EXTRACTION")

def extract_suffixes(word): 
    suffixes = ['ing', 'ed', 'ly', 's'] 
    for suffix in suffixes: 
        if word.endswith(suffix): 
            return suffix 
    return None 

words_suffix = ["running", "played", "unhappy", "cats", "jump"] 
suffixes = [extract_suffixes(word) for word in words_suffix] 

paired_display("Word → Suffix", words_suffix, suffixes)


# 6. PREFIX EXTRACTION

section("PREFIX EXTRACTION")

def extract_prefixes(word): 
    prefixes = ['un', 're', 'pre', 'dis'] 
    for prefix in prefixes: 
        if word.startswith(prefix): 
            return prefix 
    return None 

words_prefix = ["running", "redo", "unhappy", "dislike", "prepaid", "happy"] 
prefixes = [extract_prefixes(word) for word in words_prefix] 

paired_display("Word → Prefix", words_prefix, prefixes)


# 7. COMPOUND WORD SPLITTING
section("COMPOUND WORD SPLITTING")

compound_words = ['sunflower', 'basketball', 'football', 'notebook', 'toothbrush'] 
common_words = ['sun', 'flower', 'basket', 'ball', 'foot', 'book', 'tooth', 'brush'] 

def split_compound_word(word, components): 
    for component in components: 
        if word.startswith(component): 
            remaining = word[len(component):] 
            if remaining in components: 
                return component, remaining 
    return (word,) 

for word in compound_words:
    print(f"{word:<15} → {split_compound_word(word, common_words)}")


# 8. SPACY COMPOUND DETECTION
section("SPACY COMPOUND DETECTION")

nlp = spacy.load("en_core_web_sm") 
text = "The football players were practicing on the basketball court." 
doc = nlp(text) 

for token in doc:
    if token.dep_ == "compound":
        print(f"{token.text:<12} → Head: {token.head.text}")


# 9. MORPHOLOGICAL ANALYSIS
section("SPACY MORPHOLOGICAL FEATURES")

words_morph = ["preprocessing", "processor", "invaluable", "thankful", "crossed"] 

for w in words_morph:
    token = nlp(w)[0]
    print(f"{w:<15} → {token.morph}")

# Rule-based splitting
print("\nRule-Based Morpheme Splitting:")
prefixes = ["pre", "un", "in", "re"] 
suffixes = ["ing", "ed", "ful", "less", "able"] 

def split_morphemes(word): 
    for p in prefixes: 
        if word.startswith(p): 
            return (p, word[len(p):]) 
    for s in suffixes: 
        if word.endswith(s): 
            return (word[:-len(s)], s) 
    return (word,) 

for w in words_morph:
    print(f"{w:<15} → {split_morphemes(w)}")


# 10. SPACY POS TAGGING
section("SPACY POS TAGGING")

sentence = "We will meet at eight o'clock on Thursday morning." 
doc = nlp(sentence) 

for token in doc:
    print(f"{token.text:<12} → {token.pos_:<8} ({token.tag_})")
