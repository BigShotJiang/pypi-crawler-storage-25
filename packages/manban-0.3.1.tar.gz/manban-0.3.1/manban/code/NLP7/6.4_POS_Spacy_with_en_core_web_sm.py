#Spacy with en_core_web_sm
# pip install spacy
# python -m spacy download en_core_web_sm

import spacy

nlp = spacy.load("en_core_web_sm")

text = "Google Colab is a great platform for running Python code."
doc = nlp(text)

print("\nSPACY POS + DEPENDENCY")
print("="*50)
for token in doc:
    print(f"{token.text:<12} → POS: {token.pos_:<10} DEP: {token.dep_}")
