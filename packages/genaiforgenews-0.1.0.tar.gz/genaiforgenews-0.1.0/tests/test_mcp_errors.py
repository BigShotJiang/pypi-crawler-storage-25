from src.mcp.errors import GenaiforgenewsMcpError


def test_genaiforgenews_mcp_error_string_representation() -> None:
    err = GenaiforgenewsMcpError(code="E_TEST", message="boom", details={"k": "v"})

    assert str(err) == "E_TEST: boom"
    assert err.details == {"k": "v"}
