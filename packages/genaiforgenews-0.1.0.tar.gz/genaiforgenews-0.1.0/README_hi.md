# genaiforgenews

**AI आपके लिए तकनीकी समाचार चुनता है — आप बस पढ़ें।**

[English README](README.md) · [लाइव डेमो](https://vikas972.github.io/genAINews/) · [कॉन्फ़िग गाइड](https://vikas972.github.io/genAINews/configuration)

## यह क्या करता है?

कई स्रोतों (Hacker News, RSS, Reddit, GitHub, …) से सामग्री लेता है, AI से 0–10 स्कोर देता है, फ़िल्टर करता है, वेब सर्च से संदर्भ जोड़ता है, और **अंग्रेज़ी और/या हिंदी** में दैनिक Markdown सार तैयार करता है।

## त्वरित शुरुआत

### PyPI से (pip)

```bash
pip install genaiforgenews
mkdir ~/mera-genaiforgenews && cd ~/mera-genaiforgenews
# इस फ़ोल्डर में .env बनाएँ (API कुंजियाँ)
genaiforgenews-wizard
genaiforgenews
```

विस्तृत अंग्रेज़ी दस्तावेज़: [`docs/PYPI.md`](docs/PYPI.md) (उपयोगकर्ता + PyPI पर अपलोड करने वालों के लिए)।

### रिपॉज़िटरी से (git + uv)

```bash
uv sync
cp .env.example .env
cp data/config.example.json data/config.json
# .env में API कुंजी भरें; config में "languages": ["en", "hi"] जोड़ें
uv run genaiforgenews-wizard   # वैकल्पिक
uv run genaiforgenews
```

सार फ़ाइलें: `data/summaries/genaiforgenews-तारीख-hi.md` और `-en.md`।

## हिंदी सार के लिए कॉन्फ़िग

`data/config.json` में:

```json
"ai": {
  ...
  "languages": ["en", "hi"]
}
```

संवर्धन (enrichment) चरण अंग्रेज़ी और देवनागरी हिंदी दोनों में फ़ील्ड बनाता है; सार उसी भाषा कोड के अनुसार रेंडर होता है।

## लाइसेंस

[MIT](LICENSE)
