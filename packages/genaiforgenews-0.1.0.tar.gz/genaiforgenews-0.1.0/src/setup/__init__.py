"""Setup wizard for genaiforgenews configuration."""
