"""genaiforgenews — AI-driven news aggregation and daily briefings."""

try:
    from importlib.metadata import PackageNotFoundError, version

    __version__ = version("genaiforgenews")
except (ImportError, PackageNotFoundError):
    __version__ = "0.0.0"
