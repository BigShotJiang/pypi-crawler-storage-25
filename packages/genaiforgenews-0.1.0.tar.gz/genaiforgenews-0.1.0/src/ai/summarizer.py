"""Daily summary generation — pure programmatic rendering."""

import re
from typing import List, Dict

from ..models import ContentItem


_DEVANAGARI = r"[\u0900-\u097f]"
_ASCII = r"[A-Za-z0-9]"


def _devanagari_latin_spacing(text: str) -> str:
    """Insert a space between Devanagari and Latin letters/digits for readability."""
    text = re.sub(rf"({_DEVANAGARI})({_ASCII})", r"\1 \2", text)
    text = re.sub(rf"({_ASCII})({_DEVANAGARI})", r"\1 \2", text)
    return text


LABELS = {
    "en": {
        "header": "genaiforgenews Daily",
        "intro_selected": "From {total} items, {kept} important content pieces were selected",
        "intro_empty": "Analyzed {total} items, but none met the importance threshold.",
        "source": "Source",
        "background": "Background",
        "discussion": "Discussion",
        "references": "References",
        "tags": "Tags",
        "empty_body": (
            "No significant developments today. This might indicate:\n"
            "- A quiet day in your tracked sources\n"
            "- The AI score threshold is too high\n"
            "- Your information sources need expansion\n\n"
            "Consider:\n"
            "1. Lowering the `ai_score_threshold` in config.json\n"
            "2. Adding more diverse information sources\n"
            "3. Checking if the AI model is working correctly\n"
        ),
    },
    "hi": {
        "header": "genaiforgenews दैनिक सारांश",
        "intro_selected": "{total} आइटम में से {kept} महत्वपूर्ण चुने गए",
        "intro_empty": "{total} आइटम विश्लेषित किए, लेकिन कोई भी थ्रेशोल्ड पर नहीं पहुँचा।",
        "source": "स्रोत",
        "background": "पृष्ठभूमि",
        "discussion": "चर्चा",
        "references": "संदर्भ लिंक",
        "tags": "टैग",
        "empty_body": (
            "आज कोई महत्वपूर्ण अपडेट नहीं मिला। संभावित कारण:\n"
            "- आपके स्रोतों में आज कम गतिविधि रही हो\n"
            "- `ai_score_threshold` बहुत ऊँचा सेट है\n"
            "- स्रोत विविधता कम हो\n\n"
            "सुझाव:\n"
            "1. config.json में `ai_score_threshold` कम करें\n"
            "2. अधिक विविध स्रोत जोड़ें\n"
            "3. जाँचें कि AI मॉडल सही काम कर रहा है\n"
        ),
    },
}


class DailySummarizer:
    """Generates daily Markdown summaries from pre-analyzed content items."""

    def __init__(self):
        pass

    async def generate_summary(
        self,
        items: List[ContentItem],
        date: str,
        total_fetched: int,
        language: str = "en",
    ) -> str:
        """Generate daily summary in Markdown format.

        Items are rendered in score-descending order (already sorted by orchestrator).

        Args:
            items: High-scoring content items (already enriched)
            date: Date string (YYYY-MM-DD)
            total_fetched: Total number of items fetched before filtering
            language: Output language, either "en" or "hi"

        Returns:
            str: Markdown formatted summary
        """
        labels = LABELS.get(language, LABELS["en"])

        if not items:
            return self._generate_empty_summary(date, total_fetched, labels)

        intro = labels.get("intro_selected", "From {total} items, {kept} important content pieces were selected").format(
            total=total_fetched, kept=len(items)
        )
        header = f"# {labels['header']} - {date}\n\n> {intro}\n\n---\n\n"

        # TOC
        toc_entries = []
        for i, item in enumerate(items):
            _t = item.metadata.get(f"title_{language}") or item.title
            t = str(_t).replace("[", "(").replace("]", ")")
            if language == "hi":
                t = _devanagari_latin_spacing(t)
            score = item.ai_score or "?"
            toc_entries.append(f"{i + 1}. [{t}](#item-{i + 1}) \u2b50\ufe0f {score}/10")
        toc = "\n".join(toc_entries) + "\n\n---\n\n"

        parts = [self._format_item(item, labels, language, i + 1) for i, item in enumerate(items)]

        return header + toc + "".join(parts)

    def _format_item(self, item: ContentItem, labels: dict, language: str, index: int) -> str:
        """Format a single ContentItem into Markdown."""
        _title = item.metadata.get(f"title_{language}") or item.title
        title = str(_title).replace("[", "(").replace("]", ")")
        url = str(item.url)
        score = item.ai_score or "?"
        meta = item.metadata

        summary = (
            meta.get(f"detailed_summary_{language}")
            or meta.get("detailed_summary")
            or item.ai_summary
            or ""
        )
        background = meta.get(f"background_{language}") or meta.get("background") or ""
        discussion = (
            meta.get(f"community_discussion_{language}")
            or meta.get("community_discussion")
            or ""
        )

        if language == "hi":
            title = _devanagari_latin_spacing(title)
            summary = _devanagari_latin_spacing(summary)
            background = _devanagari_latin_spacing(background)
            discussion = _devanagari_latin_spacing(discussion)

        # Source line with parts joined by " · ", link appended at end
        source_type = item.source_type.value
        source_parts = [source_type]
        if meta.get("subreddit"):
            source_parts.append(f"r/{meta['subreddit']}")
        if meta.get("feed_name"):
            source_parts.append(meta["feed_name"])
        else:
            source_parts.append(item.author or "unknown")
        if item.published_at:
            day = item.published_at.strftime("%d").lstrip("0")
            source_parts.append(item.published_at.strftime(f"%b {day}, %H:%M"))
        source_line = " \u00b7 ".join(source_parts)  # ·

        lines = [
            f'<a id="item-{index}"></a>',
            f"## [{title}]({url}) \u2b50\ufe0f {score}/10",  # ⭐️
            "",
            summary,
            "",
            source_line,
        ]

        if background:
            lines.append("")
            lines.append(f"**{labels['background']}**: {background}")

        sources = meta.get("sources") or []
        if sources:
            items_html = "".join(f'<li><a href="{s["url"]}">{s["title"]}</a></li>\n' for s in sources)
            lines += [
                "",
                f'<details><summary>{labels["references"]}</summary>\n<ul>\n{items_html}\n</ul>\n</details>',
            ]

        if discussion:
            lines.append("")
            lines.append(f"**{labels['discussion']}**: {discussion}")

        if item.ai_tags:
            tags_str = ", ".join([f"`#{t}`" for t in item.ai_tags])
            lines.append("")
            lines.append(f"**{labels['tags']}**: {tags_str}")

        lines.append("")
        lines.append("---")

        return "\n".join(lines) + "\n\n"

    def _generate_empty_summary(self, date: str, total_fetched: int, labels: dict) -> str:
        """Generate summary when no high-scoring items were found."""
        intro = labels.get("intro_empty", "Analyzed {total} items, but none met the importance threshold.").format(
            total=total_fetched
        )
        return f"# {labels['header']} - {date}\n\n> {intro}\n\n" + labels["empty_body"]
