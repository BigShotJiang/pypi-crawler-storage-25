"""Basic example: Create agent identity, sign actions, and audit them."""

import json

from plyra_id import AgentID, AuditLog, AuditLogEntry, ActionStatus, sign_action, verify_signature


def main():
    # Step 1: Create an agent identity with Ed25519 keypair
    print("📋 Creating agent identity...")
    agent = AgentID.create(
        owner="alice@company.com",
        name="Research Agent",
        policy_constraints=["no_file_write", "no_external_payments"],
        metadata={"environment": "production"},
    )
    print(f"✓ Agent created: {agent.id}")
    print(f"  Owner: {agent.owner}")
    print(f"  Name: {agent.name}\n")

    # Step 2: Sign some actions
    print("📝 Signing actions...")
    actions = [
        "Search for AI safety papers",
        "Summarize findings",
        "Generate report",
    ]

    audit_log = AuditLog()

    for action in actions:
        # Sign the action
        signature = sign_action(action, agent.private_key_pem)

        # Create audit entry
        entry = AuditLogEntry(
            agent_id=agent.id,
            action=action,
            input_hash=f"sha256:{hash(action) % (2**256):064x}",
            authorized_by=agent.owner,
            timestamp="2026-05-16T10:30:00Z",
            signature=signature,
            policy_constraints=agent.policy_constraints,
            status=ActionStatus.SUCCESS,
            metadata={"action_index": actions.index(action)},
        )

        # Verify the signature
        is_valid = verify_signature(action, signature, agent.public_key_pem)
        print(f"  • {action}")
        print(f"    Signature: {signature[:40]}...")
        print(f"    Valid: {is_valid}")

        audit_log.add_entry(entry)

    print()

    # Step 3: Export audit log
    print("📤 Exporting audit log...")
    json_output = audit_log.to_json(pretty=True)
    print(json_output)
    print()

    # Step 4: Export as CSV
    print("📊 CSV Export:")
    csv_output = audit_log.to_csv()
    print(csv_output)


if __name__ == "__main__":
    main()
