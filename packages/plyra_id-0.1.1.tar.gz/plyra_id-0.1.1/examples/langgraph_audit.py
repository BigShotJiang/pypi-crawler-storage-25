"""LangGraph integration example: Sign node executions and track audit trail."""

from plyra_id import AgentID
from plyra_id.frameworks.langgraph import PlyraCheckpointSaver, sign_node


def main():
    # Step 1: Create agent identity
    print("📋 Creating agent identity...")
    agent = AgentID.create(
        owner="researcher@company.com",
        name="LangGraph Research Agent",
    )
    print(f"✓ Agent: {agent.id}\n")

    # Step 2: Create checkpoint saver with signing
    print("📋 Setting up checkpoint saver...")
    checkpointer = PlyraCheckpointSaver(
        agent_id=agent.id,
        authorizer="researcher@company.com",
        storage_path="~/.plyra/langgraph_checkpoints.db",
        private_key_pem=agent.private_key_pem,
    )
    print("✓ Checkpoint saver initialized\n")

    # Step 3: Simulate node execution with signing
    print("🔄 Simulating node executions...")

    @sign_node(
        name="research",
        agent_id=agent.id,
        authorizer="researcher@company.com",
    )
    def research_node(query: str) -> dict:
        """Simulated research node."""
        return {"query": query, "results": ["Paper 1", "Paper 2", "Paper 3"]}

    # Execute signed node
    result = research_node("AI safety trends 2026")
    print(f"✓ Research node executed: {result}\n")

    # Step 4: Store checkpoint
    print("💾 Storing checkpoint...")
    checkpoint_id = checkpointer.put(
        values={"state": result, "query": "AI safety trends 2026"},
        metadata={
            "agent_id": agent.id,
            "node_name": "research",
            "thread_id": "thread_001",
        },
    )
    print(f"✓ Checkpoint stored: {checkpoint_id}\n")

    # Step 5: Retrieve checkpoint
    print("🔍 Retrieving checkpoint...")
    retrieved = checkpointer.get(checkpoint_id)
    if retrieved:
        print(f"✓ Retrieved checkpoint:")
        print(f"  State: {retrieved['values']}\n")

    # Step 6: Export audit trail
    print("📤 Exporting audit trail...")
    audit_trail = checkpointer.export_audit_trail(format="json")
    print(audit_trail)


if __name__ == "__main__":
    main()
