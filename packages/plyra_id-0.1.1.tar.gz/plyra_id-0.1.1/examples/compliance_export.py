"""Compliance example: Export audit trails for regulatory compliance."""

from pathlib import Path

from plyra_id import AgentID
from plyra_id.frameworks.python import PlyraAuditLog
from plyra_id.storage.sqlite import SQLiteStorage


def main():
    # Step 1: Create agent identity
    print("📋 Creating agent identity...")
    agent = AgentID.create(
        owner="compliance@company.com",
        name="Data Processing Agent",
        policy_constraints=["no_external_payments", "restricted_to:company_data_*"],
    )
    print(f"✓ Agent: {agent.id}\n")

    # Step 2: Use plain Python audit context to track actions
    print("📝 Tracking actions with audit log...")
    audit_log = PlyraAuditLog(
        agent_id=agent.id,
        authorizer="compliance@company.com",
        private_key_pem=agent.private_key_pem,
        policy_constraints=agent.policy_constraints,
    )

    # Track data processing actions
    with audit_log.track("load_data", input_data={"source": "db_prod"}) as ctx:
        data = {"records": 1000, "timestamp": "2026-05-16"}
        ctx.set_output(data)

    with audit_log.track("validate_data", input_data={"records": 1000}) as ctx:
        result = {"valid": 950, "invalid": 50}
        ctx.set_output(result)

    with audit_log.track("process_data", input_data={"valid": 950}) as ctx:
        result = {"processed": 950, "errors": 0}
        ctx.set_output(result)

    with audit_log.track("export_report", input_data={"processed": 950}) as ctx:
        result = {"report_id": "RPT_2026_05_001", "status": "success"}
        ctx.set_output(result)

    print("✓ Actions tracked with signatures\n")

    # Step 3: Export to SQLite for persistence
    print("💾 Storing audit log in database...")
    db_path = "~/.plyra/compliance_audit.db"
    with SQLiteStorage(db_path) as storage:
        for entry in audit_log.get_log().entries:
            storage.store(entry)
    print(f"✓ Stored in: {db_path}\n")

    # Step 4: Export as JSON (for compliance reporting)
    print("📋 JSON Export (for compliance reporting):")
    json_export = audit_log.export_json()
    print(json_export)
    print()

    # Step 5: Export as CSV (for spreadsheet review)
    print("📊 CSV Export (for review):")
    csv_export = audit_log.export_csv()
    print(csv_export)
    print()

    # Step 6: Query database for compliance verification
    print("🔍 Database Query for Compliance Verification:")
    with SQLiteStorage(db_path) as storage:
        print(f"Total audit entries: {storage.count()}")
        print(f"Entries for agent {agent.id[:20]}...: {storage.count(agent_id=agent.id)}")

        # Export compliance report
        compliance_data = storage.export_json(agent_id=agent.id)

        # Save to file
        report_path = "compliance_report.json"
        Path(report_path).write_text(compliance_data)
        print(f"✓ Compliance report saved: {report_path}\n")

    print("✅ Compliance audit complete!")


if __name__ == "__main__":
    main()
