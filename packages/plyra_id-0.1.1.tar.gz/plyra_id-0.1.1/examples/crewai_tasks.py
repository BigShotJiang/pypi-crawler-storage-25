"""CrewAI integration example: Wrap tasks with signing and audit trails."""

from plyra_id import AgentID
from plyra_id.frameworks.crewai import PlyraTaskWrapper


class MockCrewAITask:
    """Mock CrewAI task for demonstration."""

    def __init__(self, description: str):
        self.description = description

    def execute(self, context=None) -> str:
        """Simulate task execution."""
        return f"Task executed: {self.description}"


def main():
    # Step 1: Create agent identity
    print("📋 Creating agent identity...")
    agent = AgentID.create(
        owner="crew@company.com",
        name="CrewAI Manager",
        policy_constraints=["no_database_delete"],
    )
    print(f"✓ Agent: {agent.id}\n")

    # Step 2: Create mock tasks
    print("📝 Creating tasks...")
    research_task = MockCrewAITask("Research AI trends for 2026")
    analysis_task = MockCrewAITask("Analyze competitive landscape")
    report_task = MockCrewAITask("Generate executive summary")
    print("✓ Tasks created\n")

    # Step 3: Wrap with Plyra signing
    print("🔐 Wrapping tasks with Plyra audit...")
    wrapped_research = PlyraTaskWrapper(
        task=research_task,
        agent_id=agent.id,
        authorizer="crew@company.com",
        private_key_pem=agent.private_key_pem,
        policy_constraints=agent.policy_constraints,
    )
    print("✓ Task wrapped with Plyra audit\n")

    # Step 4: Execute wrapped task
    print("⚙️  Executing task...")
    result = wrapped_research.execute(context={"year": 2026})
    print(f"✓ Task executed")
    print(f"  Result: {result['result']}\n")

    # Step 5: Execute multiple tasks to build audit trail
    print("⚙️  Executing task workflow...")
    wrapped_analysis = PlyraTaskWrapper(
        task=analysis_task,
        agent_id=agent.id,
        authorizer="crew@company.com",
    )
    wrapped_report = PlyraTaskWrapper(
        task=report_task,
        agent_id=agent.id,
        authorizer="crew@company.com",
    )

    wrapped_analysis.execute()
    wrapped_report.execute()
    print("✓ All tasks executed\n")

    # Step 6: Export audit log
    print("📤 Exporting audit log...")
    audit_trail = wrapped_research.export_audit_trail(format="json")
    print(audit_trail)


if __name__ == "__main__":
    main()
