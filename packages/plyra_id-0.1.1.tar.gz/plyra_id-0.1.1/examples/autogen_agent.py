"""AutoGen integration example: Wrap agents with signing and audit trails."""

from plyra_id import AgentID
from plyra_id.frameworks.autogen import PlyraAgentWrapper


class MockAutoGenAgent:
    """Mock AutoGen agent for demonstration."""

    def __init__(self, name: str):
        self.name = name

    def generate_reply(self, messages: list, sender=None) -> str:
        """Simulate generating a reply."""
        return f"Response from {self.name} based on {len(messages)} messages"

    def initiate_chat(self, recipient, message: str, **kwargs):
        """Simulate initiating a chat."""
        print(f"Chat initiated with {recipient.name}: {message}")


def main():
    # Step 1: Create agent identity
    print("📋 Creating agent identity...")
    agent = AgentID.create(
        owner="team@company.com",
        name="AutoGen Coordinator",
    )
    print(f"✓ Agent: {agent.id}\n")

    # Step 2: Create mock AutoGen agents
    print("🤖 Creating AutoGen agents...")
    assistant = MockAutoGenAgent("AssistantAgent")
    user_proxy = MockAutoGenAgent("UserProxy")
    print(f"✓ Created: {assistant.name}, {user_proxy.name}\n")

    # Step 3: Wrap with Plyra signing
    print("🔐 Wrapping with Plyra audit...")
    wrapped_assistant = PlyraAgentWrapper(
        agent=assistant,
        agent_id=agent.id,
        authorizer="team@company.com",
        private_key_pem=agent.private_key_pem,
    )
    print("✓ Assistant wrapped with Plyra audit\n")

    # Step 4: Execute wrapped agent
    print("💬 Generating reply...")
    messages = [
        {"role": "user", "content": "What is AI safety?"},
        {"role": "assistant", "content": "AI safety is..."},
    ]
    result = wrapped_assistant.generate_reply(messages)
    print(f"✓ Reply generated")
    print(f"  Result: {result['reply']}\n")

    # Step 5: Initiate chat with audit
    print("🤝 Initiating chat with audit...")
    wrapped_assistant.initiate_chat(
        user_proxy,
        "Let's discuss AI safety best practices",
    )
    print()

    # Step 6: Export audit log
    print("📤 Exporting audit log...")
    audit_trail = wrapped_assistant.export_audit_trail(format="json")
    print(audit_trail)


if __name__ == "__main__":
    main()
