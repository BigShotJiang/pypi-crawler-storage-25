"""Tests for storage backends."""

import json
import tempfile
from pathlib import Path

import pytest

from plyra_id.core.audit_log import AuditLogEntry, ActionStatus
from plyra_id.storage.sqlite import SQLiteStorage


class TestSQLiteStorage:
    """Tests for SQLite storage."""

    @pytest.fixture
    def storage(self):
        """Create temporary storage for testing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = f"{tmpdir}/test.db"
            storage = SQLiteStorage(db_path)
            yield storage
            storage.close()

    def test_create_storage(self, storage):
        """Test creating storage."""
        assert storage is not None

    def test_store_entry(self, storage):
        """Test storing an entry."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )

        row_id = storage.store(entry)

        assert row_id is not None
        assert isinstance(row_id, int)

    def test_store_multiple_entries(self, storage):
        """Test storing multiple entries."""
        for i in range(5):
            entry = AuditLogEntry(
                agent_id=f"plyra://agt_test_{i}",
                action=f"action_{i}",
                input_hash=f"sha256:abc{i}",
                authorized_by="user@example.com",
                timestamp="2026-05-16T10:00:00Z",
                signature="ed25519:sig123",
                policy_constraints=[],
            )
            storage.store(entry)

        assert storage.count() == 5

    def test_query_all(self, storage):
        """Test querying all entries."""
        entries = []
        for i in range(3):
            entry = AuditLogEntry(
                agent_id="plyra://agt_test",
                action=f"action_{i}",
                input_hash=f"sha256:abc{i}",
                authorized_by="user@example.com",
                timestamp="2026-05-16T10:00:00Z",
                signature="ed25519:sig123",
                policy_constraints=[],
            )
            storage.store(entry)
            entries.append(entry)

        results = storage.query()

        assert len(results) == 3

    def test_query_by_agent_id(self, storage):
        """Test querying by agent ID."""
        entry1 = AuditLogEntry(
            agent_id="plyra://agt_agent1",
            action="search",
            input_hash="sha256:abc1",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )
        entry2 = AuditLogEntry(
            agent_id="plyra://agt_agent2",
            action="search",
            input_hash="sha256:abc2",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )

        storage.store(entry1)
        storage.store(entry2)

        results = storage.query(agent_id="plyra://agt_agent1")

        assert len(results) == 1
        assert results[0]["agent_id"] == "plyra://agt_agent1"

    def test_query_by_action(self, storage):
        """Test querying by action."""
        entry1 = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc1",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )
        entry2 = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="process",
            input_hash="sha256:abc2",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )

        storage.store(entry1)
        storage.store(entry2)

        results = storage.query(action="search")

        assert len(results) == 1
        assert results[0]["action"] == "search"

    def test_query_by_status(self, storage):
        """Test querying by status."""
        entry1 = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc1",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
            status=ActionStatus.SUCCESS,
        )
        entry2 = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="process",
            input_hash="sha256:abc2",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
            status=ActionStatus.FAILED,
        )

        storage.store(entry1)
        storage.store(entry2)

        results = storage.query(status="failed")

        assert len(results) == 1
        assert results[0]["status"] == "failed"

    def test_get_by_id(self, storage):
        """Test getting entry by ID."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )

        row_id = storage.store(entry)
        result = storage.get_by_id(row_id)

        assert result is not None
        assert result["agent_id"] == "plyra://agt_test"

    def test_get_nonexistent_id(self, storage):
        """Test getting non-existent entry."""
        result = storage.get_by_id(99999)

        assert result is None

    def test_count(self, storage):
        """Test counting entries."""
        for i in range(3):
            entry = AuditLogEntry(
                agent_id="plyra://agt_test",
                action="search",
                input_hash=f"sha256:abc{i}",
                authorized_by="user@example.com",
                timestamp="2026-05-16T10:00:00Z",
                signature="ed25519:sig123",
                policy_constraints=[],
            )
            storage.store(entry)

        assert storage.count() == 3

    def test_count_by_agent(self, storage):
        """Test counting entries by agent."""
        entry1 = AuditLogEntry(
            agent_id="plyra://agt_agent1",
            action="search",
            input_hash="sha256:abc1",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )
        entry2 = AuditLogEntry(
            agent_id="plyra://agt_agent2",
            action="search",
            input_hash="sha256:abc2",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )

        storage.store(entry1)
        storage.store(entry2)

        assert storage.count(agent_id="plyra://agt_agent1") == 1
        assert storage.count(agent_id="plyra://agt_agent2") == 1

    def test_export_json(self, storage):
        """Test JSON export."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )

        storage.store(entry)
        json_str = storage.export_json()

        data = json.loads(json_str)
        assert isinstance(data, list)
        assert len(data) > 0

    def test_export_csv(self, storage):
        """Test CSV export."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )

        storage.store(entry)
        csv_str = storage.export_csv()

        lines = csv_str.strip().split("\n")
        assert len(lines) >= 2  # Header + at least 1 entry

    def test_context_manager(self):
        """Test using storage as context manager."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = f"{tmpdir}/test.db"
            with SQLiteStorage(db_path) as storage:
                entry = AuditLogEntry(
                    agent_id="plyra://agt_test",
                    action="search",
                    input_hash="sha256:abc123",
                    authorized_by="user@example.com",
                    timestamp="2026-05-16T10:00:00Z",
                    signature="ed25519:sig123",
                    policy_constraints=[],
                )
                storage.store(entry)
                assert storage.count() == 1
