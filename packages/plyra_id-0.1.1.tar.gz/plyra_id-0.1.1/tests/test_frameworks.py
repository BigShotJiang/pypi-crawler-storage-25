"""Tests for framework integrations."""

import pytest
from plyra_id import AgentID
from plyra_id.frameworks.langgraph import PlyraCheckpointSaver, sign_node
from plyra_id.frameworks.autogen import PlyraAgentWrapper
from plyra_id.frameworks.crewai import PlyraTaskWrapper
from plyra_id.frameworks.python import PlyraAuditContext, PlyraAuditLog


class TestLangGraphIntegration:
    """Tests for LangGraph integration."""

    def test_checkpoint_saver_creation(self):
        """Test creating checkpoint saver."""
        saver = PlyraCheckpointSaver(
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        assert saver is not None
        assert saver.agent_id == "plyra://agt_test"

    def test_checkpoint_put_and_get(self):
        """Test storing and retrieving checkpoint."""
        saver = PlyraCheckpointSaver(
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        checkpoint_data = {"state": {"query": "test"}, "status": "done"}
        checkpoint_id = saver.put(
            values=checkpoint_data,
            metadata={"thread_id": "t1"},
        )

        retrieved = saver.get(checkpoint_id)

        assert retrieved is not None
        assert retrieved["values"]["state"]["query"] == "test"

    def test_checkpoint_list(self):
        """Test listing checkpoints."""
        saver = PlyraCheckpointSaver(
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        saver.put({"data": "1"}, {"thread_id": "t1"})
        saver.put({"data": "2"}, {"thread_id": "t1"})

        checkpoints = saver.list()

        assert len(checkpoints) >= 2

    def test_sign_node_decorator(self):
        """Test sign_node decorator."""
        @sign_node(
            name="test_node",
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )
        def node_func(value):
            return value * 2

        result = node_func(5)

        assert result == 10

    def test_checkpoint_export(self):
        """Test exporting audit trail from checkpointer."""
        saver = PlyraCheckpointSaver(
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        saver.put({"data": "test"}, {"thread_id": "t1"})

        json_export = saver.export_audit_trail(format="json")
        csv_export = saver.export_audit_trail(format="csv")

        assert len(json_export) > 0
        assert len(csv_export) >= 0  # CSV might be empty if no entries


class MockAutoGenAgent:
    """Mock AutoGen agent for testing."""

    def __init__(self, name):
        self.name = name

    def generate_reply(self, messages, sender=None):
        return f"Reply from {self.name}"

    def initiate_chat(self, recipient, message=None, **kwargs):
        pass


class TestAutoGenIntegration:
    """Tests for AutoGen integration."""

    def test_agent_wrapper_creation(self):
        """Test creating agent wrapper."""
        mock_agent = MockAutoGenAgent("TestAgent")
        wrapper = PlyraAgentWrapper(
            agent=mock_agent,
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        assert wrapper is not None
        assert wrapper.agent_id == "plyra://agt_test"

    def test_generate_reply_with_audit(self):
        """Test generating reply with audit trail."""
        mock_agent = MockAutoGenAgent("TestAgent")
        wrapper = PlyraAgentWrapper(
            agent=mock_agent,
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        messages = [{"role": "user", "content": "Hello"}]
        result = wrapper.generate_reply(messages)

        assert "reply" in result
        assert "audit_entry" in result

    def test_initiate_chat_with_audit(self):
        """Test initiating chat with audit."""
        mock_agent = MockAutoGenAgent("Agent1")
        mock_recipient = MockAutoGenAgent("Agent2")

        wrapper = PlyraAgentWrapper(
            agent=mock_agent,
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        result = wrapper.initiate_chat(mock_recipient, "Hello")

        assert "success" in result
        assert "audit_entry" in result

    def test_export_audit_trail(self):
        """Test exporting audit trail."""
        mock_agent = MockAutoGenAgent("TestAgent")
        wrapper = PlyraAgentWrapper(
            agent=mock_agent,
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        messages = [{"role": "user", "content": "Hello"}]
        wrapper.generate_reply(messages)

        json_export = wrapper.export_audit_trail(format="json")

        assert len(json_export) > 0


class MockCrewAITask:
    """Mock CrewAI task for testing."""

    def __init__(self, description):
        self.description = description

    def execute(self, context=None):
        return f"Executed: {self.description}"


class TestCrewAIIntegration:
    """Tests for CrewAI integration."""

    def test_task_wrapper_creation(self):
        """Test creating task wrapper."""
        mock_task = MockCrewAITask("Test Task")
        wrapper = PlyraTaskWrapper(
            task=mock_task,
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        assert wrapper is not None
        assert wrapper.agent_id == "plyra://agt_test"

    def test_task_execute_with_audit(self):
        """Test executing task with audit."""
        mock_task = MockCrewAITask("Test Task")
        wrapper = PlyraTaskWrapper(
            task=mock_task,
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        result = wrapper.execute()

        assert "result" in result
        assert "audit_entry" in result

    def test_export_audit_trail(self):
        """Test exporting audit trail."""
        mock_task = MockCrewAITask("Test Task")
        wrapper = PlyraTaskWrapper(
            task=mock_task,
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        wrapper.execute()

        json_export = wrapper.export_audit_trail(format="json")

        assert len(json_export) > 0


class TestPythonAuditContext:
    """Tests for plain Python audit context."""

    def test_context_basic(self):
        """Test basic context usage."""
        with PlyraAuditContext(
            agent_id="plyra://agt_test",
            action_name="search",
            authorizer="user@example.com",
        ) as ctx:
            result = 42
            ctx.set_output(result)

        assert ctx.entry is not None
        assert ctx.entry.action == "search"

    def test_context_with_error(self):
        """Test context with error."""
        try:
            with PlyraAuditContext(
                agent_id="plyra://agt_test",
                action_name="risky_action",
                authorizer="user@example.com",
            ) as ctx:
                raise ValueError("Test error")
        except ValueError:
            pass

        assert ctx.entry is not None

    def test_audit_log(self):
        """Test audit log tracking."""
        log = PlyraAuditLog(
            agent_id="plyra://agt_test",
            authorizer="user@example.com",
        )

        with log.track("action1", input_data={"data": "test"}) as ctx:
            ctx.set_output({"result": "success"})

        with log.track("action2") as ctx:
            ctx.set_output({"result": "success"})

        json_export = log.export_json()

        # Check that export was generated (entries may be async)
        assert json_export is not None
