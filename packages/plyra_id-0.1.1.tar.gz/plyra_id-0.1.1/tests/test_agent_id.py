"""Tests for agent identity module."""

import pytest
from plyra_id.core.agent_id import AgentID, generate_agent_id, validate_agent_id


class TestAgentIDCreation:
    """Tests for AgentID creation."""

    def test_create_basic(self):
        """Test creating basic agent ID."""
        agent = AgentID.create("user@example.com", "TestAgent")

        assert agent.id.startswith("plyra://agt_")
        assert agent.owner == "user@example.com"
        assert agent.name == "TestAgent"
        assert agent.public_key_pem.startswith("-----BEGIN PUBLIC KEY-----")
        assert agent.private_key_pem.startswith("-----BEGIN PRIVATE KEY-----")

    def test_create_with_constraints(self):
        """Test creating agent with policy constraints."""
        constraints = ["no_file_write", "no_external_payments"]
        agent = AgentID.create("user@example.com", "TestAgent", constraints)

        assert agent.policy_constraints == constraints

    def test_create_with_metadata(self):
        """Test creating agent with metadata."""
        metadata = {"environment": "prod", "version": "1.0"}
        agent = AgentID.create(
            "user@example.com",
            "TestAgent",
            metadata=metadata,
        )

        assert agent.metadata == metadata

    def test_create_unique_ids(self):
        """Test that each created agent has unique ID."""
        agent1 = AgentID.create("user@example.com", "Agent1")
        agent2 = AgentID.create("user@example.com", "Agent2")

        assert agent1.id != agent2.id

    def test_create_timestamp(self):
        """Test that created_at is set."""
        agent = AgentID.create("user@example.com", "TestAgent")

        assert agent.created_at is not None
        assert "T" in agent.created_at  # ISO format

    def test_create_different_owners(self):
        """Test agents with different owners are distinct."""
        agent1 = AgentID.create("user1@example.com", "TestAgent")
        agent2 = AgentID.create("user2@example.com", "TestAgent")

        assert agent1.owner != agent2.owner
        assert agent1.id != agent2.id


class TestAgentIDValidation:
    """Tests for agent ID validation."""

    def test_validate_agent_id_valid(self):
        """Test validating correct agent ID."""
        agent = AgentID.create("user@example.com", "TestAgent")

        assert validate_agent_id(agent.id)

    def test_validate_agent_id_invalid_prefix(self):
        """Test that invalid prefix fails validation."""
        assert not validate_agent_id("invalid://agt_12345678")

    def test_validate_agent_id_too_short(self):
        """Test that too-short ID fails validation."""
        assert not validate_agent_id("plyra://agt_")

    def test_validate_agent_id_empty(self):
        """Test that empty string fails validation."""
        assert not validate_agent_id("")

    def test_validate_agent_id_none(self):
        """Test that None fails gracefully."""
        try:
            validate_agent_id(None)
            assert False, "Should raise error"
        except (TypeError, AttributeError):
            pass


class TestAgentIDSerialization:
    """Tests for agent ID serialization."""

    def test_to_dict_without_private_key(self):
        """Test dict export without private key."""
        agent = AgentID.create("user@example.com", "TestAgent")
        data = agent.to_dict(include_private_key=False)

        assert "id" in data
        assert "owner" in data
        assert "name" in data
        assert "public_key_pem" in data
        assert "private_key_pem" not in data

    def test_to_dict_with_private_key(self):
        """Test dict export with private key."""
        agent = AgentID.create("user@example.com", "TestAgent")
        data = agent.to_dict(include_private_key=True)

        assert "private_key_pem" in data

    def test_from_dict(self):
        """Test reconstructing agent from dict."""
        agent1 = AgentID.create("user@example.com", "TestAgent")
        data = agent1.to_dict(include_private_key=True)
        agent2 = AgentID.from_dict(data)

        assert agent1.id == agent2.id
        assert agent1.owner == agent2.owner
        assert agent1.public_key_pem == agent2.public_key_pem

    def test_roundtrip(self):
        """Test dict roundtrip preserves data."""
        original = AgentID.create("user@example.com", "TestAgent", ["no_file_write"])
        data = original.to_dict(include_private_key=True)
        restored = AgentID.from_dict(data)

        assert original.id == restored.id
        assert original.name == restored.name
        assert original.policy_constraints == restored.policy_constraints


class TestGenerateAgentId:
    """Tests for generate_agent_id shorthand."""

    def test_generate_agent_id(self):
        """Test generate_agent_id function."""
        agent_id = generate_agent_id("user@example.com", "TestAgent")

        assert agent_id.startswith("plyra://agt_")
        assert len(agent_id) >= 20

    def test_generate_agent_id_unique(self):
        """Test that generated IDs are unique."""
        id1 = generate_agent_id("user@example.com", "Agent1")
        id2 = generate_agent_id("user@example.com", "Agent2")

        assert id1 != id2


class TestAgentIDEdgeCases:
    """Tests for edge cases."""

    def test_special_characters_in_owner(self):
        """Test owner with special characters."""
        agent = AgentID.create("user+test@example.co.uk", "TestAgent")

        assert agent.owner == "user+test@example.co.uk"

    def test_unicode_in_name(self):
        """Test agent name with unicode."""
        agent = AgentID.create("user@example.com", "研究エージェント")

        assert "研究エージェント" in agent.name

    def test_empty_constraints_list(self):
        """Test with empty constraints list."""
        agent = AgentID.create("user@example.com", "TestAgent", [])

        assert agent.policy_constraints == []

    def test_many_constraints(self):
        """Test with many constraints."""
        constraints = [f"constraint_{i}" for i in range(10)]
        agent = AgentID.create("user@example.com", "TestAgent", constraints)

        assert len(agent.policy_constraints) == 10

    def test_public_key_bytes(self):
        """Test public_key_bytes method."""
        agent = AgentID.create("user@example.com", "TestAgent")
        key_bytes = agent.public_key_bytes()

        assert isinstance(key_bytes, bytes)
        assert key_bytes.startswith(b"-----BEGIN PUBLIC KEY-----")
