"""Tests for policy enforcement module."""

import pytest
from plyra_id.core.policies import PolicyEngine, ConstraintType


class TestPolicyEngine:
    """Tests for PolicyEngine."""

    def test_create_engine(self):
        """Test creating policy engine."""
        engine = PolicyEngine()

        assert engine is not None
        assert len(engine.constraint_handlers) > 0

    def test_no_file_write_pass(self):
        """Test no_file_write constraint passes for non-file actions."""
        engine = PolicyEngine()
        context = {"action": "search"}

        assert engine.check_constraint("no_file_write", context)

    def test_no_file_write_fail(self):
        """Test no_file_write constraint fails for file write."""
        engine = PolicyEngine()
        context = {"action": "write_file"}

        assert not engine.check_constraint("no_file_write", context)

    def test_no_file_write_variations(self):
        """Test no_file_write catches various patterns."""
        engine = PolicyEngine()

        blocked_actions = ["write", "upload", "save", "create_file"]
        for action in blocked_actions:
            context = {"action": action}
            assert not engine.check_constraint("no_file_write", context), f"Failed for {action}"

    def test_no_external_payments_pass(self):
        """Test no_external_payments constraint passes."""
        engine = PolicyEngine()
        context = {"action": "search"}

        assert engine.check_constraint("no_external_payments", context)

    def test_no_external_payments_fail(self):
        """Test no_external_payments constraint fails."""
        engine = PolicyEngine()

        blocked_actions = ["payment", "transfer", "charge", "withdraw"]
        for action in blocked_actions:
            context = {"action": action}
            assert not engine.check_constraint("no_external_payments", context)

    def test_no_database_delete_pass(self):
        """Test no_database_delete constraint passes."""
        engine = PolicyEngine()
        context = {"action": "query"}

        assert engine.check_constraint("no_database_delete", context)

    def test_no_database_delete_fail(self):
        """Test no_database_delete constraint fails."""
        engine = PolicyEngine()

        blocked_actions = ["delete", "drop", "truncate", "remove"]
        for action in blocked_actions:
            context = {"action": action}
            assert not engine.check_constraint("no_database_delete", context)

    def test_max_token_usage_pass(self):
        """Test max_token_usage constraint passes."""
        engine = PolicyEngine()
        context = {"token_count": 100}

        assert engine.check_constraint("max_token_usage:1000", context)

    def test_max_token_usage_fail(self):
        """Test max_token_usage constraint fails."""
        engine = PolicyEngine()
        context = {"token_count": 2000}

        assert not engine.check_constraint("max_token_usage:1000", context)

    def test_max_token_usage_equal(self):
        """Test max_token_usage at boundary."""
        engine = PolicyEngine()
        context = {"token_count": 1000}

        assert engine.check_constraint("max_token_usage:1000", context)

    def test_restricted_to_pass(self):
        """Test restricted_to constraint passes."""
        engine = PolicyEngine()
        context = {"resource": "company_data_archive"}

        assert engine.check_constraint("restricted_to:company_data_*", context)

    def test_restricted_to_fail(self):
        """Test restricted_to constraint fails."""
        engine = PolicyEngine()
        context = {"resource": "external_data"}

        assert not engine.check_constraint("restricted_to:company_data_*", context)

    def test_unknown_constraint(self):
        """Test that unknown constraint passes."""
        engine = PolicyEngine()
        context = {"action": "anything"}

        assert engine.check_constraint("unknown_constraint", context)

    def test_evaluate_all_pass(self):
        """Test evaluate_all with all constraints passing."""
        engine = PolicyEngine()
        context = {"action": "search", "token_count": 100}
        constraints = ["no_file_write", "no_external_payments"]

        assert engine.evaluate_all(constraints, context)

    def test_evaluate_all_fail(self):
        """Test evaluate_all with one constraint failing."""
        engine = PolicyEngine()
        context = {"action": "write_file"}
        constraints = ["no_file_write", "no_external_payments"]

        assert not engine.evaluate_all(constraints, context)

    def test_evaluate_all_empty(self):
        """Test evaluate_all with empty constraints."""
        engine = PolicyEngine()
        context = {"action": "anything"}

        assert engine.evaluate_all([], context)


class TestConstraintType:
    """Tests for ConstraintType enum."""

    def test_constraint_type_values(self):
        """Test ConstraintType enum values."""
        assert ConstraintType.NO_FILE_WRITE.value == "no_file_write"
        assert ConstraintType.NO_EXTERNAL_PAYMENTS.value == "no_external_payments"
        assert ConstraintType.NO_DATABASE_DELETE.value == "no_database_delete"
        assert ConstraintType.MAX_TOKEN_USAGE.value == "max_token_usage"
        assert ConstraintType.RESTRICTED_TO.value == "restricted_to"


class TestPolicyEdgeCases:
    """Tests for edge cases."""

    def test_case_insensitive_actions(self):
        """Test that action matching is case insensitive."""
        engine = PolicyEngine()
        context = {"action": "WRITE"}

        assert not engine.check_constraint("no_file_write", context)

    def test_max_token_zero(self):
        """Test max_token_usage with zero limit."""
        engine = PolicyEngine()
        context = {"token_count": 1}

        assert not engine.check_constraint("max_token_usage:0", context)

    def test_max_token_missing_context(self):
        """Test max_token_usage with missing token_count."""
        engine = PolicyEngine()
        context = {}

        assert engine.check_constraint("max_token_usage:1000", context)

    def test_restricted_to_complex_pattern(self):
        """Test restricted_to with complex pattern."""
        engine = PolicyEngine()
        context = {"resource": "company_data_prod_users"}

        assert engine.check_constraint("restricted_to:company_data_*", context)

    def test_multiple_constraints_same_type(self):
        """Test evaluating same constraint multiple times."""
        engine = PolicyEngine()
        context = {"action": "search"}

        constraints = ["no_file_write", "no_file_write", "no_file_write"]
        assert engine.evaluate_all(constraints, context)
