"""Tests for audit log module."""

import json
import pytest
from plyra_id.core.audit_log import AuditLogEntry, AuditLog, ActionStatus


class TestAuditLogEntry:
    """Tests for AuditLogEntry."""

    def test_create_basic(self):
        """Test creating basic audit log entry."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=["no_file_write"],
        )

        assert entry.agent_id == "plyra://agt_test"
        assert entry.action == "search"
        assert entry.status == ActionStatus.SUCCESS

    def test_create_with_error(self):
        """Test creating entry with error."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
            status=ActionStatus.FAILED,
            error_message="Search timeout",
        )

        assert entry.status == ActionStatus.FAILED
        assert entry.error_message == "Search timeout"

    def test_to_dict(self):
        """Test converting entry to dict."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=["no_file_write"],
        )

        data = entry.to_dict()

        assert data["agent_id"] == "plyra://agt_test"
        assert data["action"] == "search"
        assert data["status"] == "success"

    def test_to_json(self):
        """Test converting entry to JSON."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )

        json_str = entry.to_json()

        data = json.loads(json_str)
        assert data["action"] == "search"

    def test_from_dict(self):
        """Test reconstructing entry from dict."""
        original = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=["no_file_write"],
        )

        data = original.to_dict()
        restored = AuditLogEntry.from_dict(data)

        assert original.agent_id == restored.agent_id
        assert original.action == restored.action
        assert original.status == restored.status

    def test_action_status_values(self):
        """Test ActionStatus enum values."""
        assert ActionStatus.SUCCESS.value == "success"
        assert ActionStatus.FAILED.value == "failed"
        assert ActionStatus.BLOCKED.value == "blocked"
        assert ActionStatus.ESCALATED.value == "escalated"

    def test_entry_with_metadata(self):
        """Test entry with metadata."""
        metadata = {"request_id": "12345", "version": "1.0"}
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
            metadata=metadata,
        )

        assert entry.metadata == metadata


class TestAuditLog:
    """Tests for AuditLog collection."""

    def test_create_empty(self):
        """Test creating empty audit log."""
        log = AuditLog()

        assert len(log.entries) == 0
        assert log.created_at is not None

    def test_add_entry(self):
        """Test adding entry to log."""
        log = AuditLog()
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )

        log.add_entry(entry)

        assert len(log.entries) == 1
        assert log.entries[0].action == "search"

    def test_add_multiple_entries(self):
        """Test adding multiple entries."""
        log = AuditLog()

        for i in range(5):
            entry = AuditLogEntry(
                agent_id="plyra://agt_test",
                action=f"action_{i}",
                input_hash=f"sha256:abc{i}",
                authorized_by="user@example.com",
                timestamp="2026-05-16T10:00:00Z",
                signature="ed25519:sig123",
                policy_constraints=[],
            )
            log.add_entry(entry)

        assert len(log.entries) == 5

    def test_log_to_dict(self):
        """Test converting log to dict."""
        log = AuditLog()
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )
        log.add_entry(entry)

        data = log.to_dict()

        assert data["entry_count"] == 1
        assert len(data["entries"]) == 1

    def test_log_to_json(self):
        """Test converting log to JSON."""
        log = AuditLog()
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
        )
        log.add_entry(entry)

        json_str = log.to_json(pretty=True)

        data = json.loads(json_str)
        assert data["entry_count"] == 1

    def test_log_to_csv(self):
        """Test converting log to CSV."""
        log = AuditLog()
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=["no_file_write"],
        )
        log.add_entry(entry)

        csv_str = log.to_csv()

        lines = csv_str.strip().split("\n")
        assert len(lines) >= 2  # Header + at least 1 entry

    def test_empty_log_csv(self):
        """Test CSV export of empty log."""
        log = AuditLog()

        csv_str = log.to_csv()

        assert csv_str == ""


class TestAuditLogEdgeCases:
    """Tests for edge cases."""

    def test_entry_without_output_hash(self):
        """Test entry without output hash."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=[],
            output_hash=None,
        )

        assert entry.output_hash is None

    def test_entry_blocked_status(self):
        """Test entry with BLOCKED status."""
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="payment",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=["no_external_payments"],
            status=ActionStatus.BLOCKED,
        )

        assert entry.status == ActionStatus.BLOCKED
        data = entry.to_dict()
        assert data["status"] == "blocked"

    def test_large_policy_constraints(self):
        """Test with many policy constraints."""
        constraints = [f"constraint_{i}" for i in range(20)]
        entry = AuditLogEntry(
            agent_id="plyra://agt_test",
            action="search",
            input_hash="sha256:abc123",
            authorized_by="user@example.com",
            timestamp="2026-05-16T10:00:00Z",
            signature="ed25519:sig123",
            policy_constraints=constraints,
        )

        assert len(entry.policy_constraints) == 20
