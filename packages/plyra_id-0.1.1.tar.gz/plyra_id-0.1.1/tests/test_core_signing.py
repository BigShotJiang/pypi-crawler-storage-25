"""Tests for signing and verification module."""

import pytest
from plyra_id.core.agent_id import AgentID
from plyra_id.core.signing import (
    sign_action,
    verify_signature,
    sign_dict,
    verify_dict,
)


class TestSignAction:
    """Tests for sign_action function."""

    def test_sign_action_basic(self):
        """Test basic action signing."""
        agent = AgentID.create("test@example.com", "test")
        message = "test message"
        signature = sign_action(message, agent.private_key_pem)

        assert signature.startswith("ed25519:")
        assert len(signature) > 20

    def test_sign_action_format(self):
        """Test signature format."""
        agent = AgentID.create("test@example.com", "test")
        signature = sign_action("message", agent.private_key_pem)

        assert signature.startswith("ed25519:")
        # Should be base64 encoded after prefix
        import base64
        sig_part = signature[8:]
        try:
            base64.b64decode(sig_part)
            valid = True
        except Exception:
            valid = False
        assert valid

    def test_sign_action_deterministic(self):
        """Test that signing same message produces different signatures."""
        agent = AgentID.create("test@example.com", "test")
        sig1 = sign_action("message", agent.private_key_pem)
        sig2 = sign_action("message", agent.private_key_pem)

        # Ed25519 is deterministic, so same message should produce same signature
        assert sig1 == sig2

    def test_sign_action_different_messages(self):
        """Test that different messages produce different signatures."""
        agent = AgentID.create("test@example.com", "test")
        sig1 = sign_action("message1", agent.private_key_pem)
        sig2 = sign_action("message2", agent.private_key_pem)

        assert sig1 != sig2


class TestVerifySignature:
    """Tests for verify_signature function."""

    def test_verify_valid_signature(self):
        """Test verification of valid signature."""
        agent = AgentID.create("test@example.com", "test")
        message = "test message"
        signature = sign_action(message, agent.private_key_pem)

        assert verify_signature(message, signature, agent.public_key_pem)

    def test_verify_invalid_signature(self):
        """Test that invalid signature fails verification."""
        agent = AgentID.create("test@example.com", "test")
        message = "test message"

        assert not verify_signature(message, "invalid_sig", agent.public_key_pem)

    def test_verify_wrong_message(self):
        """Test that signature for wrong message fails."""
        agent = AgentID.create("test@example.com", "test")
        signature = sign_action("message1", agent.private_key_pem)

        assert not verify_signature("message2", signature, agent.public_key_pem)

    def test_verify_no_prefix(self):
        """Test that signature without prefix fails."""
        agent = AgentID.create("test@example.com", "test")
        message = "test message"
        signature = sign_action(message, agent.private_key_pem)

        # Remove prefix
        sig_without_prefix = signature[8:]
        assert not verify_signature(message, sig_without_prefix, agent.public_key_pem)

    def test_verify_wrong_public_key(self):
        """Test that verification fails with wrong public key."""
        agent1 = AgentID.create("user1@example.com", "agent1")
        agent2 = AgentID.create("user2@example.com", "agent2")

        message = "test message"
        signature = sign_action(message, agent1.private_key_pem)

        assert not verify_signature(message, signature, agent2.public_key_pem)


class TestSignDict:
    """Tests for sign_dict function."""

    def test_sign_dict_basic(self):
        """Test signing dictionary."""
        agent = AgentID.create("test@example.com", "test")
        data = {"key": "value", "number": 42}
        signature = sign_dict(data, agent.private_key_pem)

        assert signature.startswith("ed25519:")

    def test_sign_dict_deterministic(self):
        """Test that dicts with same content produce same signature."""
        agent = AgentID.create("test@example.com", "test")
        data1 = {"z": 1, "a": 2}  # Different order
        data2 = {"a": 2, "z": 1}  # Different order

        sig1 = sign_dict(data1, agent.private_key_pem)
        sig2 = sign_dict(data2, agent.private_key_pem)

        # Should be same because JSON is sorted
        assert sig1 == sig2

    def test_sign_dict_empty(self):
        """Test signing empty dict."""
        agent = AgentID.create("test@example.com", "test")
        signature = sign_dict({}, agent.private_key_pem)

        assert signature.startswith("ed25519:")

    def test_sign_dict_nested(self):
        """Test signing nested dict."""
        agent = AgentID.create("test@example.com", "test")
        data = {"outer": {"inner": {"deep": "value"}}}
        signature = sign_dict(data, agent.private_key_pem)

        assert signature.startswith("ed25519:")


class TestVerifyDict:
    """Tests for verify_dict function."""

    def test_verify_dict_valid(self):
        """Test verification of valid dict signature."""
        agent = AgentID.create("test@example.com", "test")
        data = {"action": "search", "query": "AI"}
        signature = sign_dict(data, agent.private_key_pem)

        assert verify_dict(data, signature, agent.public_key_pem)

    def test_verify_dict_modified(self):
        """Test that verification fails if dict is modified."""
        agent = AgentID.create("test@example.com", "test")
        data = {"action": "search", "query": "AI"}
        signature = sign_dict(data, agent.private_key_pem)

        data["query"] = "ML"  # Modify
        assert not verify_dict(data, signature, agent.public_key_pem)

    def test_verify_dict_order_invariant(self):
        """Test that dict order doesn't matter for verification."""
        agent = AgentID.create("test@example.com", "test")
        data1 = {"z": 1, "a": 2}
        signature = sign_dict(data1, agent.private_key_pem)

        data2 = {"a": 2, "z": 1}
        assert verify_dict(data2, signature, agent.public_key_pem)

    def test_verify_dict_empty(self):
        """Test verification of empty dict."""
        agent = AgentID.create("test@example.com", "test")
        signature = sign_dict({}, agent.private_key_pem)

        assert verify_dict({}, signature, agent.public_key_pem)


class TestSigningEdgeCases:
    """Tests for edge cases."""

    def test_unicode_message(self):
        """Test signing unicode message."""
        agent = AgentID.create("test@example.com", "test")
        message = "Hello 世界 🌍"
        signature = sign_action(message, agent.private_key_pem)

        assert verify_signature(message, signature, agent.public_key_pem)

    def test_long_message(self):
        """Test signing very long message."""
        agent = AgentID.create("test@example.com", "test")
        message = "x" * 10000
        signature = sign_action(message, agent.private_key_pem)

        assert verify_signature(message, signature, agent.public_key_pem)

    def test_special_characters(self):
        """Test signing message with special characters."""
        agent = AgentID.create("test@example.com", "test")
        message = "!@#$%^&*(){}[]|\\:;\"'<>,.?/"
        signature = sign_action(message, agent.private_key_pem)

        assert verify_signature(message, signature, agent.public_key_pem)
