"""Tests for CLI tool."""

import json
import tempfile
from pathlib import Path

import pytest
from click.testing import CliRunner

from plyra_id.cli import cli
from plyra_id import AgentID
from plyra_id.core.audit_log import AuditLogEntry
from plyra_id.storage.sqlite import SQLiteStorage


class TestCLI:
    """Tests for CLI commands."""

    @pytest.fixture
    def runner(self):
        """Create CLI runner."""
        return CliRunner()

    @pytest.fixture
    def temp_db(self):
        """Create temporary database."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = f"{tmpdir}/test.db"
            # Create and populate database
            with SQLiteStorage(db_path) as storage:
                entry = AuditLogEntry(
                    agent_id="plyra://agt_test",
                    action="search",
                    input_hash="sha256:abc123",
                    authorized_by="user@example.com",
                    timestamp="2026-05-16T10:00:00Z",
                    signature="ed25519:sig123",
                    policy_constraints=[],
                )
                storage.store(entry)
            yield db_path

    def test_export_json(self, runner, temp_db):
        """Test export command with JSON format."""
        result = runner.invoke(cli, [
            "export",
            "--db", temp_db,
            "--format", "json",
        ])

        assert result.exit_code == 0
        # Should output JSON
        try:
            json.loads(result.output)
        except json.JSONDecodeError:
            # May contain other text, so just check it ran
            assert "entries" in result.output or len(result.output) > 0

    def test_export_csv(self, runner, temp_db):
        """Test export command with CSV format."""
        result = runner.invoke(cli, [
            "export",
            "--db", temp_db,
            "--format", "csv",
        ])

        assert result.exit_code == 0

    def test_export_to_file(self, runner, temp_db):
        """Test export to file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = f"{tmpdir}/export.json"
            result = runner.invoke(cli, [
                "export",
                "--db", temp_db,
                "--format", "json",
                "--output", output_file,
            ])

            assert result.exit_code == 0
            assert Path(output_file).exists()

    def test_export_filter_agent_id(self, runner, temp_db):
        """Test export with agent ID filter."""
        result = runner.invoke(cli, [
            "export",
            "--db", temp_db,
            "--agent-id", "plyra://agt_test",
            "--format", "json",
        ])

        assert result.exit_code == 0

    def test_stats_command(self, runner, temp_db):
        """Test stats command."""
        result = runner.invoke(cli, [
            "stats",
            "--db", temp_db,
        ])

        assert result.exit_code == 0
        assert "Total entries" in result.output or "entries" in result.output

    def test_create_agent(self, runner):
        """Test create-agent command."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = f"{tmpdir}/agent.json"
            result = runner.invoke(cli, [
                "create-agent",
                "--owner", "user@example.com",
                "--name", "TestAgent",
                "--output", output_file,
            ])

            assert result.exit_code == 0
            assert Path(output_file).exists()

            # Verify the created file
            data = json.loads(Path(output_file).read_text())
            assert data["owner"] == "user@example.com"
            assert data["name"] == "TestAgent"

    def test_verify_signature(self, runner):
        """Test verify command."""
        # Create an agent and sign a message
        agent = AgentID.create("user@example.com", "TestAgent")
        from plyra_id.core.signing import sign_action

        message = "test message"
        signature = sign_action(message, agent.private_key_pem)

        with tempfile.TemporaryDirectory() as tmpdir:
            key_file = f"{tmpdir}/pubkey.pem"
            Path(key_file).write_text(agent.public_key_pem)

            result = runner.invoke(cli, [
                "verify",
                "--signature", signature,
                "--public-key", key_file,
                "--message", message,
            ])

            assert result.exit_code == 0
            assert "valid" in result.output.lower()

    def test_serve_command(self, runner, temp_db):
        """Test serve command (dashboard info)."""
        result = runner.invoke(cli, [
            "serve",
            "--db", temp_db,
            "--port", "8765",
        ])

        assert result.exit_code == 0

    def test_cli_help(self, runner):
        """Test CLI help."""
        result = runner.invoke(cli, ["--help"])

        assert result.exit_code == 0
        assert "Plyra Audit CLI" in result.output

    def test_export_help(self, runner):
        """Test export command help."""
        result = runner.invoke(cli, ["export", "--help"])

        assert result.exit_code == 0
        assert "Export" in result.output or "export" in result.output
