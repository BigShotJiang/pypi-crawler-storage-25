# plyra-id

**Cryptographic identity and audit trails for autonomous AI agents.**

When your agents go into production, compliance teams ask: *"Who did this? Who authorized it? Can you prove it?"*

You have logs. You don't have proof.

`plyra-id` gives you cryptographically signed, tamper-evident receipts proving who did what and who authorized it.

---

## The Problem

Autonomous agents are moving into production across enterprises—in financial services, healthcare, insurance, and legal. But there's a compliance wall:

- **Who authorized this action?** Logs don't prove authorization.
- **Who is responsible if something goes wrong?** You can't trace accountability.
- **Can you prove this in an audit?** Logs can be tampered with. Receipts can't.

`plyra-id` solves this with one decorator.

---

## The Solution

```python
from plyra_id import AgentID, sign_action

# Create agent identity (once)
agent = AgentID.create(owner="compliance@company.com", name="document-analyzer")

# Sign every action (automatic with frameworks)
signature = sign_action("analyzed_document_123", agent.private_key_pem)

# Verify in audit (tamper-evident)
is_valid = verify_signature("analyzed_document_123", signature, agent.public_key_pem)
# True ✓ (can be proven in court)
```

One decorator. Framework-agnostic. Compliance-ready.

---

## Framework Support

`plyra-id` integrates seamlessly with the frameworks you're already using:

### LangGraph
```python
from langgraph.graph import StateGraph
from plyra_id.frameworks.langgraph import PlyraCheckpointSaver, sign_node

@sign_node(name="research", agent_id=agent.id, authorizer="human@company.com")
def research_node(state):
    return {"result": web_search(state.query)}

# Every checkpoint is now a signed receipt
checkpointer = PlyraCheckpointSaver()
compiled = graph.compile(checkpointer=checkpointer)

# Export compliance report
audit_trail = checkpointer.export_audit_trail(format="json")
```

### AutoGen
```python
from autogen import AssistantAgent
from plyra_id.frameworks.autogen import PlyraAgentWrapper

assistant = AssistantAgent(...)
wrapped = PlyraAgentWrapper(
    agent=assistant,
    agent_id=agent.id,
    authorizer="human@company.com"
)

reply = wrapped.generate_reply(messages)
# Returns both: {"reply": ..., "audit_entry": {...}}
```

### CrewAI
```python
from crewai import Task
from plyra_id.frameworks.crewai import PlyraTaskWrapper

task = Task(description="Analyze financial report")
wrapped = PlyraTaskWrapper(task, agent_id=agent.id, authorizer="human@company.com")

result = wrapped.execute()
# Returns both: {"result": ..., "audit_entry": {...}}
```

### Plain Python
```python
from plyra_id.frameworks.python import sign_action

with sign_action(agent_id, "fetch_data", authorizer) as log:
    data = fetch_from_api()
    # log now contains signed audit entry
```

---

## Export & Compliance

Export signed audit trails in any format:

```python
# JSON (for APIs, pipelines)
json_trail = audit_log.to_json(pretty=True)

# CSV (for Excel, compliance reports)
csv_trail = audit_log.to_csv()

# SIEM integration (Datadog, Splunk, Sumo Logic)
exporter = DatadogExporter(api_key="...")
for entry in audit_log.entries:
    exporter.export(entry)
```

Every entry includes:
- Agent ID
- Action taken
- Timestamp (ISO8601)
- Signature (Ed25519, tamper-proof)
- Authorization (who approved)
- Policy constraints (what was forbidden)
- Success/failure status

---

## Use Cases

### Financial Services
- **KYC/AML agents:** Prove who performed customer verification
- **Trade execution:** Audit trail for every agent-initiated trade
- **Compliance:** Meet GLBA, SOX, OCC requirements

### Healthcare
- **Prior authorization:** Signed receipts for agent approvals
- **Patient data access:** Who accessed what, when, why
- **HIPAA audits:** Tamper-evident proof of compliance

### Insurance
- **Claims processing:** Agent decisions with authorization proof
- **Underwriting:** Signed audit trail for every agent assessment
- **State compliance:** Meet state-by-state AI regulations

### Legal
- **Contract review:** Agent analysis with attorney sign-off
- **Due diligence:** Verified agent findings for M&A
- **Legal research:** Traceable agent citations

---

## Installation

```bash
# Core library only
pip install plyra-id

# With LangGraph support
pip install plyra-id[langgraph]

# With all frameworks
pip install plyra-id[langgraph,autogen,crewai]

# With SIEM exporters
pip install plyra-id[otel,datadog]

# With PostgreSQL backend
pip install plyra-id[postgres]
```

---

## Quick Start (5 minutes)

1. **Create an agent identity:**
```python
from plyra_id import AgentID

agent = AgentID.create(
    owner="compliance@company.com",
    name="document-analyzer"
)
print(f"Agent ID: {agent.id}")
```

2. **Sign an action:**
```python
from plyra_id import sign_action, verify_signature

action = "analyzed_report_2024_q1"
signature = sign_action(action, agent.private_key_pem)
print(f"Signature: {signature}")

# Verify
is_valid = verify_signature(action, signature, agent.public_key_pem)
print(f"Valid: {is_valid}")  # True ✓
```

3. **Create an audit log entry:**
```python
from plyra_id.core.audit_log import AuditLogEntry, ActionStatus
from datetime import datetime, timezone

entry = AuditLogEntry(
    agent_id=agent.id,
    action="analyzed_report_2024_q1",
    input_hash="sha256:abc123...",
    authorized_by="compliance@company.com",
    timestamp=datetime.now(timezone.utc).isoformat(),
    signature=signature,
    policy_constraints=["no_external_payments", "max_token_usage:10000"],
    status=ActionStatus.SUCCESS,
)

print(entry.to_json(pretty=True))
```

4. **Export for compliance:**
```python
from plyra_id.core.audit_log import AuditLog

audit_log = AuditLog()
audit_log.add_entry(entry)

# JSON for your API
json_output = audit_log.to_json(pretty=True)

# CSV for audit committee
csv_output = audit_log.to_csv()
```

---

## Command-Line Interface

```bash
# Export audit trail from a database
plyra-audit export --from langgraph --format json --output audit.json

# Verify a signature
plyra-audit verify \
  --signature "ed25519:abc123..." \
  --public-key pubkey.pem \
  --message "analyzed_report_2024_q1"

# Start audit dashboard
plyra-audit serve --port 8765 --db ~/.plyra/checkpoints.db
```

---

## Documentation

- **[Getting Started](https://plyraai.github.io/plyra-id/getting-started/)** — 10-minute tutorial
- **[API Reference](https://plyraai.github.io/plyra-id/api-reference/)** — Complete API docs
- **[Framework Guides](https://plyraai.github.io/plyra-id/frameworks/)** — LangGraph, AutoGen, CrewAI
- **[Examples](https://plyraai.github.io/plyra-id/examples/)** — Working code samples
- **[Exporters](https://plyraai.github.io/plyra-id/exporters/)** — Datadog, OpenTelemetry, etc.
- **[FAQ](https://plyraai.github.io/plyra-id/faq/)** — Common questions

---

## Architecture

`plyra-id` is built in layers:

1. **Core Identity** (`plyra_id.core`)
   - Ed25519 keypair generation
   - Cryptographic signing & verification
   - Audit log schema & serialization
   - Policy constraint enforcement

2. **Framework Integrations** (`plyra_id.frameworks`)
   - LangGraph checkpoint saver
   - AutoGen agent wrapper
   - CrewAI task wrapper
   - Plain Python context manager

3. **Exporters** (`plyra_id.exporters`)
   - StdoutExporter (logging)
   - OpenTelemetryExporter (OTel)
   - DatadogExporter (Datadog)
   - SidecarExporter (webhooks)

4. **Storage** (`plyra_id.storage`)
   - SQLiteStorage (local)
   - PostgresStorage (cloud)

5. **CLI** (`plyra_id.cli`)
   - `plyra-audit export`
   - `plyra-audit verify`
   - `plyra-audit serve`

---

## Security

`plyra-id` uses **Ed25519** (NIST-standard public-key cryptography) for all signatures.

- **Private keys** are never logged; export only with explicit flag
- **Signatures** are tamper-evident (any modification invalidates)
- **Audit trails** are immutable by design
- **Policy constraints** are enforced before action execution

For security issues, please email: security@plyra.dev

---

## Open Source

`plyra-id` is licensed under **Apache 2.0**. Build on it, extend it, integrate it. No proprietary lockdown.

- GitHub: https://github.com/plyraAI/plyra-id
- PyPI: https://pypi.org/project/plyra-id
- License: https://github.com/plyraAI/plyra-id/blob/main/LICENSE

---

## Contributing

We welcome contributions. See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## Support

- **Issues:** https://github.com/plyraAI/plyra-id/issues
- **Discussions:** https://github.com/plyraAI/plyra-id/discussions
- **Email:** team@plyra.dev

---

## Roadmap

**v0.1.0** (now)
- Core signing & verification
- Framework integrations (LangGraph, AutoGen, CrewAI)
- Exporters & storage backends
- CLI tool

**v0.2.0** (Month 2)
- Enterprise dashboard (SaaS)
- SIEM integration (Datadog, Splunk, Sumo Logic)
- Advanced policy engine
- Compliance report generation

**v0.3.0+** (Months 3+)
- Agent reputation scoring (plyra-cred)
- Payment integration (plyra-pay)
- Agent marketplace (plyra-marketplace)

---

## Citation

If you use `plyra-id` in your research or product, please cite:

```bibtex
@software{plyra_id,
  title={plyra-id: Cryptographic identity and audit trails for autonomous AI agents},
  author={Plyra AI},
  url={https://github.com/plyraAI/plyra-id},
  year={2026},
}
```

---

**Built with precision. Deployed with confidence. Scaled globally.**

*plyra-id: Identity infrastructure for the autonomous agent economy.*
