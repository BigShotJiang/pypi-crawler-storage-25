"""Base exporter and implementations for audit trail export."""

import json
from abc import ABC, abstractmethod
from typing import Optional

from plyra_id.core.audit_log import AuditLogEntry


class BaseExporter(ABC):
    """Abstract base class for audit exporters."""

    @abstractmethod
    def export(self, entry: AuditLogEntry) -> None:
        """Export an audit entry.

        Args:
            entry: AuditLogEntry to export
        """
        pass

    @abstractmethod
    def close(self) -> None:
        """Close exporter and cleanup resources."""
        pass


class StdoutExporter(BaseExporter):
    """Print audit entries to stdout (JSON format).

    Usage:
        exporter = StdoutExporter()
        exporter.export(audit_entry)
    """

    def export(self, entry: AuditLogEntry) -> None:
        """Print entry to stdout as JSON.

        Args:
            entry: AuditLogEntry to export
        """
        data = entry.to_dict()
        print(f"[PLYRA] {json.dumps(data)}")

    def close(self) -> None:
        """No cleanup needed for stdout."""
        pass


class OpenTelemetryExporter(BaseExporter):
    """Export audit entries to OpenTelemetry.

    Requires: pip install opentelemetry-api opentelemetry-exporter-jaeger

    Usage:
        exporter = OpenTelemetryExporter(service_name="my-agent")
        exporter.export(audit_entry)
    """

    def __init__(self, service_name: str = "plyra-agent"):
        """Initialize OpenTelemetry exporter.

        Args:
            service_name: Service name for OpenTelemetry spans
        """
        try:
            from opentelemetry import trace
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.trace.export import SimpleSpanProcessor
            from opentelemetry.exporter.jaeger.thrift import JaegerExporter

            jaeger_exporter = JaegerExporter(
                agent_host_name="localhost",
                agent_port=6831,
            )
            trace.set_tracer_provider(TracerProvider())
            trace.get_tracer_provider().add_span_processor(
                SimpleSpanProcessor(jaeger_exporter)
            )
            self.tracer = trace.get_tracer(__name__)
        except ImportError:
            raise ImportError(
                "OpenTelemetry not installed. "
                "Install with: pip install opentelemetry-api opentelemetry-exporter-jaeger"
            )

    def export(self, entry: AuditLogEntry) -> None:
        """Create an OpenTelemetry span for the audit entry.

        Args:
            entry: AuditLogEntry to export
        """
        with self.tracer.start_as_current_span("agent_action") as span:
            span.set_attribute("agent_id", entry.agent_id)
            span.set_attribute("action", entry.action)
            span.set_attribute("status", entry.status.value)
            span.set_attribute("authorized_by", entry.authorized_by)
            span.set_attribute("timestamp", entry.timestamp)
            if entry.error_message:
                span.set_attribute("error_message", entry.error_message)

    def close(self) -> None:
        """Close the tracer provider."""
        try:
            from opentelemetry import trace
            trace.get_tracer_provider().force_flush()
        except Exception:
            pass


class DatadogExporter(BaseExporter):
    """Export audit entries to Datadog.

    Requires: pip install datadog

    Usage:
        exporter = DatadogExporter(api_key="...")
        exporter.export(audit_entry)
    """

    def __init__(self, api_key: str, hostname: str = "localhost"):
        """Initialize Datadog exporter.

        Args:
            api_key: Datadog API key
            hostname: Datadog hostname (default: localhost for agent)
        """
        try:
            from datadog import initialize, api
            options = {
                "api_key": api_key,
                "app_key": "",
                "api_version": "v1",
            }
            initialize(**options)
            self.api = api
        except ImportError:
            raise ImportError(
                "Datadog not installed. Install with: pip install datadog"
            )

    def export(self, entry: AuditLogEntry) -> None:
        """Send audit entry to Datadog as an event.

        Args:
            entry: AuditLogEntry to export
        """
        try:
            event_data = {
                "title": f"Agent Action: {entry.action}",
                "text": f"Agent: {entry.agent_id}\nStatus: {entry.status.value}",
                "priority": "normal" if entry.status.value == "success" else "high",
                "tags": [
                    f"agent:{entry.agent_id}",
                    f"action:{entry.action}",
                    f"status:{entry.status.value}",
                ],
            }
            self.api.Event.create(**event_data)
        except Exception as e:
            print(f"Failed to export to Datadog: {e}")

    def close(self) -> None:
        """No cleanup needed for Datadog."""
        pass


class SidecarExporter(BaseExporter):
    """Export audit entries to a sidecar/webhook endpoint.

    Usage:
        exporter = SidecarExporter(webhook_url="http://localhost:8765/audit")
        exporter.export(audit_entry)
    """

    def __init__(self, webhook_url: str, timeout: int = 5):
        """Initialize sidecar exporter.

        Args:
            webhook_url: URL of the sidecar/webhook
            timeout: Request timeout in seconds
        """
        try:
            import requests
            self.requests = requests
        except ImportError:
            raise ImportError(
                "requests not installed. Install with: pip install requests"
            )
        self.webhook_url = webhook_url
        self.timeout = timeout

    def export(self, entry: AuditLogEntry) -> None:
        """POST audit entry to webhook.

        Args:
            entry: AuditLogEntry to export
        """
        try:
            data = entry.to_dict()
            response = self.requests.post(
                self.webhook_url,
                json=data,
                timeout=self.timeout,
            )
            response.raise_for_status()
        except Exception as e:
            print(f"Failed to export to sidecar: {e}")

    def close(self) -> None:
        """No cleanup needed for sidecar."""
        pass
