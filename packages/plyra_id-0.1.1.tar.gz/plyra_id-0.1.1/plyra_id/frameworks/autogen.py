"""AutoGen integration for plyra-id — agent wrapper with signing."""

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from plyra_id.core.audit_log import ActionStatus, AuditLog, AuditLogEntry
from plyra_id.core.signing import sign_dict


class PlyraAgentWrapper:
    """Wrapper for AutoGen agents with cryptographic signing.

    Usage:
        from autogen import AssistantAgent
        from plyra_id.frameworks.autogen import PlyraAgentWrapper

        assistant = AssistantAgent(name="Research", ...)
        wrapped = PlyraAgentWrapper(
            agent=assistant,
            agent_id="plyra://agt_...",
            authorizer="human@company.com",
            private_key_pem=agent.private_key_pem
        )
        result = wrapped.generate_reply(messages)
        # Returns: {"reply": ..., "audit_entry": ...}
    """

    def __init__(
        self,
        agent: Any,
        agent_id: str,
        authorizer: Optional[str] = None,
        private_key_pem: Optional[str] = None,
        policy_constraints: Optional[List[str]] = None,
    ):
        """Initialize agent wrapper.

        Args:
            agent: The AutoGen agent to wrap
            agent_id: Plyra agent identifier
            authorizer: Human authorizer/user
            private_key_pem: Private key for signing (optional)
            policy_constraints: List of policy constraints
        """
        self.agent = agent
        self.agent_id = agent_id
        self.authorizer = authorizer or "system"
        self.private_key_pem = private_key_pem
        self.policy_constraints = policy_constraints or []
        self.audit_log = AuditLog()

    def generate_reply(
        self,
        messages: List[Dict[str, Any]],
        sender: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """Generate reply with audit trail.

        Args:
            messages: Conversation history
            sender: Message sender (optional)

        Returns:
            Dictionary with "reply" and "audit_entry" keys
        """
        try:
            # Call original generate_reply
            reply = self.agent.generate_reply(messages, sender)
            status = ActionStatus.SUCCESS
            error_msg = None
        except Exception as e:
            reply = None
            status = ActionStatus.FAILED
            error_msg = str(e)

        # Create audit entry
        input_data = {
            "message_count": len(messages),
            "sender": str(sender) if sender else None,
        }
        input_hash = _hash_object(input_data)

        output_hash = _hash_object(reply) if reply else None

        entry = AuditLogEntry(
            agent_id=self.agent_id,
            action=f"generate_reply:{self.agent.name}",
            input_hash=input_hash,
            authorized_by=self.authorizer,
            timestamp=datetime.now(timezone.utc).isoformat(),
            signature="",
            policy_constraints=self.policy_constraints,
            status=status,
            output_hash=output_hash,
            error_message=error_msg,
            metadata={"agent_name": self.agent.name, "message_count": len(messages)},
        )

        # Sign if private key available
        if self.private_key_pem:
            entry_dict = entry.to_dict()
            entry.signature = sign_dict(entry_dict, self.private_key_pem)

        self.audit_log.add_entry(entry)

        return {
            "reply": reply,
            "audit_entry": entry.to_dict(),
        }

    def initiate_chat(
        self,
        recipient: Any,
        message: str,
        **kwargs,
    ) -> Dict[str, Any]:
        """Initiate chat with audit trail.

        Args:
            recipient: Recipient agent
            message: Initial message
            **kwargs: Additional arguments

        Returns:
            Dictionary with "success" and "audit_entry" keys
        """
        try:
            self.agent.initiate_chat(recipient, message=message, **kwargs)
            status = ActionStatus.SUCCESS
            error_msg = None
        except Exception as e:
            status = ActionStatus.FAILED
            error_msg = str(e)

        # Create audit entry
        entry = AuditLogEntry(
            agent_id=self.agent_id,
            action=f"initiate_chat:{recipient.name}",
            input_hash=_hash_object({"message": message, "kwargs": kwargs}),
            authorized_by=self.authorizer,
            timestamp=datetime.now(timezone.utc).isoformat(),
            signature="",
            policy_constraints=self.policy_constraints,
            status=status,
            error_message=error_msg,
            metadata={
                "agent_name": self.agent.name,
                "recipient_name": getattr(recipient, "name", "unknown"),
            },
        )

        # Sign if private key available
        if self.private_key_pem:
            entry_dict = entry.to_dict()
            entry.signature = sign_dict(entry_dict, self.private_key_pem)

        self.audit_log.add_entry(entry)

        return {
            "success": status == ActionStatus.SUCCESS,
            "audit_entry": entry.to_dict(),
        }

    def get_audit_log(self) -> AuditLog:
        """Get the underlying audit log."""
        return self.audit_log

    def export_audit_trail(self, format: str = "json") -> str:
        """Export audit trail.

        Args:
            format: Export format ("json" or "csv")

        Returns:
            Formatted audit trail
        """
        if format == "json":
            return self.audit_log.to_json(pretty=True)
        elif format == "csv":
            return self.audit_log.to_csv()
        else:
            raise ValueError(f"Unknown export format: {format}")


def _hash_object(obj: Any) -> str:
    """Hash any object to sha256:hex format.

    Args:
        obj: Object to hash

    Returns:
        Formatted hash string
    """
    try:
        json_str = json.dumps(obj, sort_keys=True, default=str)
    except (TypeError, ValueError):
        json_str = str(obj)
    hash_hex = hashlib.sha256(json_str.encode()).hexdigest()
    return f"sha256:{hash_hex}"
