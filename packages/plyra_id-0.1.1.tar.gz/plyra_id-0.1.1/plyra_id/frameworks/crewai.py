"""CrewAI integration for plyra-id — task wrapper with signing."""

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from plyra_id.core.audit_log import ActionStatus, AuditLog, AuditLogEntry
from plyra_id.core.signing import sign_dict


class PlyraTaskWrapper:
    """Wrapper for CrewAI tasks with cryptographic signing.

    Usage:
        from crewai import Task
        from plyra_id.frameworks.crewai import PlyraTaskWrapper

        task = Task(description="Research AI trends", ...)
        wrapped = PlyraTaskWrapper(
            task=task,
            agent_id="plyra://agt_...",
            authorizer="human@company.com",
            private_key_pem=agent.private_key_pem
        )
        result = wrapped.execute()
        # Returns: {"result": ..., "audit_entry": ...}
    """

    def __init__(
        self,
        task: Any,
        agent_id: str,
        authorizer: Optional[str] = None,
        private_key_pem: Optional[str] = None,
        policy_constraints: Optional[List[str]] = None,
    ):
        """Initialize task wrapper.

        Args:
            task: The CrewAI task to wrap
            agent_id: Plyra agent identifier
            authorizer: Human authorizer/user
            private_key_pem: Private key for signing (optional)
            policy_constraints: List of policy constraints
        """
        self.task = task
        self.agent_id = agent_id
        self.authorizer = authorizer or "system"
        self.private_key_pem = private_key_pem
        self.policy_constraints = policy_constraints or []
        self.audit_log = AuditLog()

    def execute(self, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute task with audit trail.

        Args:
            context: Execution context (optional)

        Returns:
            Dictionary with "result" and "audit_entry" keys
        """
        try:
            result = self.task.execute(context) if context else self.task.execute()
            status = ActionStatus.SUCCESS
            error_msg = None
        except Exception as e:
            result = None
            status = ActionStatus.FAILED
            error_msg = str(e)

        # Create audit entry
        task_description = getattr(self.task, "description", "task_execution")
        input_data = {
            "task_description": task_description,
            "context_keys": list(context.keys()) if context else [],
        }
        input_hash = _hash_object(input_data)
        output_hash = _hash_object(result) if result else None

        entry = AuditLogEntry(
            agent_id=self.agent_id,
            action=f"task:{task_description}",
            input_hash=input_hash,
            authorized_by=self.authorizer,
            timestamp=datetime.now(timezone.utc).isoformat(),
            signature="",
            policy_constraints=self.policy_constraints,
            status=status,
            output_hash=output_hash,
            error_message=error_msg,
            metadata={
                "task_description": task_description,
                "has_context": context is not None,
            },
        )

        # Sign if private key available
        if self.private_key_pem:
            entry_dict = entry.to_dict()
            entry.signature = sign_dict(entry_dict, self.private_key_pem)

        self.audit_log.add_entry(entry)

        return {
            "result": result,
            "audit_entry": entry.to_dict(),
        }

    def get_audit_log(self) -> AuditLog:
        """Get the underlying audit log."""
        return self.audit_log

    def export_audit_trail(self, format: str = "json") -> str:
        """Export audit trail.

        Args:
            format: Export format ("json" or "csv")

        Returns:
            Formatted audit trail
        """
        if format == "json":
            return self.audit_log.to_json(pretty=True)
        elif format == "csv":
            return self.audit_log.to_csv()
        else:
            raise ValueError(f"Unknown export format: {format}")


def _hash_object(obj: Any) -> str:
    """Hash any object to sha256:hex format.

    Args:
        obj: Object to hash

    Returns:
        Formatted hash string
    """
    try:
        json_str = json.dumps(obj, sort_keys=True, default=str)
    except (TypeError, ValueError):
        json_str = str(obj)
    hash_hex = hashlib.sha256(json_str.encode()).hexdigest()
    return f"sha256:{hash_hex}"
