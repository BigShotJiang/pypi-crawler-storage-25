"""Plain Python context manager for plyra-id — framework-agnostic signing."""

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from plyra_id.core.audit_log import ActionStatus, AuditLog, AuditLogEntry
from plyra_id.core.signing import sign_dict


class PlyraAuditContext:
    """Context manager for tracking and signing actions in plain Python code.

    Usage:
        from plyra_id.frameworks.python import PlyraAuditContext

        with PlyraAuditContext(
            agent_id="plyra://agt_...",
            action_name="web_search",
            authorizer="human@company.com",
            private_key_pem=agent.private_key_pem
        ) as ctx:
            result = perform_web_search(query)
            ctx.set_output(result)

        # Retrieve the signed audit entry
        entry = ctx.get_entry()
    """

    def __init__(
        self,
        agent_id: str,
        action_name: str,
        authorizer: Optional[str] = None,
        private_key_pem: Optional[str] = None,
        policy_constraints: Optional[List[str]] = None,
        input_data: Optional[Dict[str, Any]] = None,
    ):
        """Initialize audit context.

        Args:
            agent_id: Plyra agent identifier
            action_name: Name of the action being audited
            authorizer: Human authorizer/user
            private_key_pem: Private key for signing (optional)
            policy_constraints: List of policy constraints
            input_data: Input data for hashing (optional)
        """
        self.agent_id = agent_id
        self.action_name = action_name
        self.authorizer = authorizer or "system"
        self.private_key_pem = private_key_pem
        self.policy_constraints = policy_constraints or []
        self.input_hash = _hash_object(input_data) if input_data else "sha256:"
        self.output_hash: Optional[str] = None
        self.error_message: Optional[str] = None
        self.status = ActionStatus.SUCCESS
        self._start_time = datetime.now(timezone.utc)
        self.entry: Optional[AuditLogEntry] = None

    def __enter__(self) -> "PlyraAuditContext":
        """Enter context."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context and create audit entry."""
        if exc_type is not None:
            self.status = ActionStatus.FAILED
            self.error_message = str(exc_val)

        # Create audit entry
        self.entry = AuditLogEntry(
            agent_id=self.agent_id,
            action=self.action_name,
            input_hash=self.input_hash,
            authorized_by=self.authorizer,
            timestamp=self._start_time.isoformat(),
            signature="",
            policy_constraints=self.policy_constraints,
            status=self.status,
            output_hash=self.output_hash,
            error_message=self.error_message,
        )

        # Sign if private key available
        if self.private_key_pem:
            entry_dict = self.entry.to_dict()
            self.entry.signature = sign_dict(entry_dict, self.private_key_pem)

        # Don't suppress exceptions
        return False

    def set_output(self, output_data: Any) -> None:
        """Set the output data (for hashing).

        Args:
            output_data: Output to hash
        """
        self.output_hash = _hash_object(output_data)

    def set_error(self, error_msg: str) -> None:
        """Manually set an error message.

        Args:
            error_msg: Error message
        """
        self.status = ActionStatus.FAILED
        self.error_message = error_msg

    def set_status(self, status: ActionStatus) -> None:
        """Set the action status.

        Args:
            status: ActionStatus value
        """
        self.status = status

    def get_entry(self) -> Optional[AuditLogEntry]:
        """Get the audit entry (available after context exit).

        Returns:
            AuditLogEntry if context has been exited, None otherwise
        """
        return self.entry

    def to_dict(self) -> Dict[str, Any]:
        """Export entry to dictionary.

        Returns:
            Dictionary representation of audit entry
        """
        if not self.entry:
            raise RuntimeError("Context has not been exited yet")
        return self.entry.to_dict()


class PlyraAuditLog:
    """Simple audit log collector for plain Python code.

    Usage:
        log = PlyraAuditLog(
            agent_id="plyra://agt_...",
            private_key_pem=agent.private_key_pem
        )

        # Track multiple actions
        with log.track("search", input_data={"query": q}) as ctx:
            result = search_api(q)
            ctx.set_output(result)

        with log.track("process", input_data={"data": result}) as ctx:
            processed = process(result)
            ctx.set_output(processed)

        # Export all entries
        print(log.export_json())
    """

    def __init__(
        self,
        agent_id: str,
        authorizer: Optional[str] = None,
        private_key_pem: Optional[str] = None,
        policy_constraints: Optional[List[str]] = None,
    ):
        """Initialize audit log.

        Args:
            agent_id: Plyra agent identifier
            authorizer: Human authorizer/user
            private_key_pem: Private key for signing (optional)
            policy_constraints: List of policy constraints
        """
        self.agent_id = agent_id
        self.authorizer = authorizer or "system"
        self.private_key_pem = private_key_pem
        self.policy_constraints = policy_constraints or []
        self.audit_log = AuditLog()

    def track(
        self,
        action_name: str,
        input_data: Optional[Dict[str, Any]] = None,
    ) -> PlyraAuditContext:
        """Create a context manager to track an action.

        Args:
            action_name: Name of the action
            input_data: Input data to hash (optional)

        Returns:
            PlyraAuditContext instance
        """
        ctx = PlyraAuditContext(
            agent_id=self.agent_id,
            action_name=action_name,
            authorizer=self.authorizer,
            private_key_pem=self.private_key_pem,
            policy_constraints=self.policy_constraints,
            input_data=input_data,
        )
        # Wrap to auto-add to log
        original_exit = ctx.__exit__

        def exit_with_log(exc_type, exc_val, exc_tb):
            result = original_exit(exc_type, exc_val, exc_tb)
            if ctx.entry:
                self.audit_log.add_entry(ctx.entry)
            return result

        ctx.__exit__ = exit_with_log
        return ctx

    def add_entry(self, entry: AuditLogEntry) -> None:
        """Manually add an entry to the log.

        Args:
            entry: AuditLogEntry to add
        """
        self.audit_log.add_entry(entry)

    def export_json(self, pretty: bool = True) -> str:
        """Export log to JSON.

        Args:
            pretty: Pretty-print JSON

        Returns:
            JSON string
        """
        return self.audit_log.to_json(pretty=pretty)

    def export_csv(self) -> str:
        """Export log to CSV.

        Returns:
            CSV string
        """
        return self.audit_log.to_csv()

    def get_log(self) -> AuditLog:
        """Get the underlying AuditLog.

        Returns:
            AuditLog instance
        """
        return self.audit_log


def _hash_object(obj: Any) -> str:
    """Hash any object to sha256:hex format.

    Args:
        obj: Object to hash

    Returns:
        Formatted hash string
    """
    try:
        json_str = json.dumps(obj, sort_keys=True, default=str)
    except (TypeError, ValueError):
        json_str = str(obj)
    hash_hex = hashlib.sha256(json_str.encode()).hexdigest()
    return f"sha256:{hash_hex}"
