"""LangGraph integration for plyra-id — checkpoint signing and audit trails."""

import hashlib
import json
from datetime import datetime, timezone
from functools import wraps
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

from plyra_id.core.agent_id import AgentID
from plyra_id.core.audit_log import ActionStatus, AuditLog, AuditLogEntry
from plyra_id.core.signing import sign_dict


def sign_node(
    name: str,
    agent_id: str,
    authorizer: Optional[str] = None,
    policy_constraints: Optional[List[str]] = None,
):
    """Decorator to sign a LangGraph node execution.

    Usage:
        @sign_node(name="research", agent_id=agent.id, authorizer="user@company.com")
        def research_node(state):
            return {"result": web_search(state.query)}
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            # Execute the node
            try:
                result = func(*args, **kwargs)
                status = ActionStatus.SUCCESS
                error_msg = None
                output_data = result
            except Exception as e:
                result = None
                status = ActionStatus.FAILED
                error_msg = str(e)
                output_data = None

            # Create audit entry (signatures would be applied if private key is available)
            entry = AuditLogEntry(
                agent_id=agent_id,
                action=f"node:{name}",
                input_hash=_hash_object(args),
                authorized_by=authorizer or "system",
                timestamp=datetime.now(timezone.utc).isoformat(),
                signature="",
                policy_constraints=policy_constraints or [],
                status=status,
                output_hash=_hash_object(output_data) if output_data else None,
                error_message=error_msg,
            )

            # Store in thread-local context for retrieval by checkpointer
            _node_audit_context.entry = entry

            return result

        return wrapper

    return decorator


class _NodeAuditContext:
    """Thread-local storage for node audit entries."""

    def __init__(self):
        self.entry: Optional[AuditLogEntry] = None


_node_audit_context = _NodeAuditContext()


class PlyraCheckpointSaver:
    """Custom checkpoint saver that stores signed audit trails.

    Usage:
        from langgraph.graph import StateGraph
        from plyra_id.frameworks.langgraph import PlyraCheckpointSaver

        checkpointer = PlyraCheckpointSaver(
            agent_id="plyra://agt_...",
            storage_path="~/.plyra/checkpoints.db"
        )
        compiled = graph.compile(checkpointer=checkpointer)
    """

    def __init__(
        self,
        agent_id: str = "system",
        authorizer: Optional[str] = None,
        storage_path: str = "~/.plyra/checkpoints.db",
        private_key_pem: Optional[str] = None,
    ):
        """Initialize checkpoint saver.

        Args:
            agent_id: Agent identifier
            authorizer: Human authorizer/user
            storage_path: Path to checkpoint storage (not implemented in this version)
            private_key_pem: Private key for signing (optional)
        """
        self.agent_id = agent_id
        self.authorizer = authorizer or "system"
        self.storage_path = storage_path
        self.private_key_pem = private_key_pem
        self.audit_log = AuditLog()
        self._checkpoints: Dict[str, Any] = {}  # In-memory storage

    def put(self, values: Dict[str, Any], metadata: Dict[str, Any]) -> str:
        """Store checkpoint with signature.

        Args:
            values: Checkpoint state values
            metadata: Checkpoint metadata (thread_id, checkpoint_id, etc)

        Returns:
            Checkpoint ID
        """
        checkpoint_id = str(uuid4())

        # Hash the checkpoint
        checkpoint_json = json.dumps(values, sort_keys=True, default=str)
        checkpoint_hash = hashlib.sha256(checkpoint_json.encode()).hexdigest()

        # Get any pending node audit entry
        node_entry = _node_audit_context.entry
        _node_audit_context.entry = None

        # Create or update audit entry
        if node_entry:
            entry = node_entry
            entry.output_hash = f"sha256:{checkpoint_hash}"
        else:
            entry = AuditLogEntry(
                agent_id=self.agent_id,
                action="checkpoint",
                input_hash=f"sha256:{checkpoint_hash}",
                authorized_by=self.authorizer,
                timestamp=datetime.now(timezone.utc).isoformat(),
                signature="",
                policy_constraints=[],
                status=ActionStatus.SUCCESS,
                metadata={"checkpoint_id": checkpoint_id, **metadata},
            )

        # Sign the checkpoint if private key is available
        if self.private_key_pem:
            checkpoint_data = {
                "checkpoint_id": checkpoint_id,
                "values": values,
                "metadata": metadata,
            }
            entry.signature = sign_dict(checkpoint_data, self.private_key_pem)

        # Store in memory
        self._checkpoints[checkpoint_id] = {
            "values": values,
            "metadata": metadata,
            "audit_entry": entry,
        }

        self.audit_log.add_entry(entry)

        return checkpoint_id

    def get(self, checkpoint_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve checkpoint by ID.

        Args:
            checkpoint_id: Checkpoint identifier

        Returns:
            Checkpoint data or None if not found
        """
        checkpoint = self._checkpoints.get(checkpoint_id)
        if checkpoint:
            return {
                "values": checkpoint["values"],
                "metadata": checkpoint["metadata"],
            }
        return None

    def list(self, thread_id: Optional[str] = None, **filters) -> List[Dict[str, Any]]:
        """List checkpoints matching filters.

        Args:
            thread_id: Filter by thread ID
            **filters: Additional filters

        Returns:
            List of checkpoint metadata
        """
        results = []
        for checkpoint_id, checkpoint in self._checkpoints.items():
            metadata = checkpoint["metadata"]
            if thread_id and metadata.get("thread_id") != thread_id:
                continue
            results.append(
                {
                    "checkpoint_id": checkpoint_id,
                    "metadata": metadata,
                    "timestamp": checkpoint["audit_entry"].timestamp,
                }
            )
        return results

    def export_audit_trail(self, format: str = "json") -> str:
        """Export signed audit trail.

        Args:
            format: Export format ("json" or "csv")

        Returns:
            Formatted audit trail
        """
        if format == "json":
            return self.audit_log.to_json(pretty=True)
        elif format == "csv":
            return self.audit_log.to_csv()
        else:
            raise ValueError(f"Unknown export format: {format}")

    def get_audit_log(self) -> AuditLog:
        """Get the underlying audit log."""
        return self.audit_log


def _hash_object(obj: Any) -> str:
    """Hash any object to sha256:hex format.

    Args:
        obj: Object to hash

    Returns:
        Formatted hash string
    """
    try:
        json_str = json.dumps(obj, sort_keys=True, default=str)
    except (TypeError, ValueError):
        json_str = str(obj)
    hash_hex = hashlib.sha256(json_str.encode()).hexdigest()
    return f"sha256:{hash_hex}"
