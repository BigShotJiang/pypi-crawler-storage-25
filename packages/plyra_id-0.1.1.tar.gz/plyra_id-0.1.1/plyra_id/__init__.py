"""plyra-id: Cryptographic identity and audit trails for autonomous AI agents."""

__version__ = "0.1.0"

from plyra_id.core.agent_id import AgentID, generate_agent_id, validate_agent_id
from plyra_id.core.signing import (
    sign_action,
    verify_signature,
    sign_dict,
    verify_dict,
)
from plyra_id.core.audit_log import (
    AuditLog,
    AuditLogEntry,
    ActionStatus,
)
from plyra_id.core.policies import PolicyEngine, ConstraintType

__all__ = [
    "AgentID",
    "generate_agent_id",
    "validate_agent_id",
    "sign_action",
    "verify_signature",
    "sign_dict",
    "verify_dict",
    "AuditLog",
    "AuditLogEntry",
    "ActionStatus",
    "PolicyEngine",
    "ConstraintType",
]
