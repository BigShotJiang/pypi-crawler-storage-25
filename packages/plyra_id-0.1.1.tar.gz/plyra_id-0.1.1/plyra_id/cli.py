"""CLI tool for plyra-id — audit export and compliance reporting."""

import json
from pathlib import Path
from typing import Optional

import click

from plyra_id.core.agent_id import AgentID
from plyra_id.core.signing import verify_signature
from plyra_id.storage.sqlite import SQLiteStorage


@click.group()
def cli():
    """Plyra Audit CLI — Agent identity and compliance tooling."""
    pass


@cli.command()
@click.option(
    "--db",
    "db_path",
    default="~/.plyra/audits.db",
    type=click.Path(),
    help="Path to SQLite database",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["json", "csv"]),
    default="json",
    help="Output format",
)
@click.option(
    "--output",
    "output_file",
    type=click.Path(),
    help="Output file (default: stdout)",
)
@click.option(
    "--agent-id",
    "agent_id",
    help="Filter by agent ID",
)
@click.option(
    "--action",
    "action",
    help="Filter by action",
)
@click.option(
    "--status",
    "status",
    type=click.Choice(["success", "failed", "blocked", "escalated"]),
    help="Filter by status",
)
@click.option(
    "--limit",
    "limit",
    type=int,
    default=1000,
    help="Maximum number of entries",
)
def export(
    db_path: str,
    output_format: str,
    output_file: Optional[str],
    agent_id: Optional[str],
    action: Optional[str],
    status: Optional[str],
    limit: int,
):
    """Export audit logs from database.

    Examples:
        plyra-audit export --format json --output audit.json
        plyra-audit export --agent-id plyra://agt_abc123 --format csv
    """
    try:
        with SQLiteStorage(db_path) as storage:
            entries = storage.query(
                agent_id=agent_id,
                action=action,
                status=status,
                limit=limit,
            )

            if output_format == "json":
                output = json.dumps(entries, indent=2, default=str)
            else:  # csv
                import csv
                import io

                if not entries:
                    output = ""
                else:
                    string_io = io.StringIO()
                    writer = csv.DictWriter(string_io, fieldnames=entries[0].keys())
                    writer.writeheader()
                    writer.writerows(entries)
                    output = string_io.getvalue()

            if output_file:
                Path(output_file).parent.mkdir(parents=True, exist_ok=True)
                Path(output_file).write_text(output)
                click.echo(f"✓ Exported {len(entries)} entries to {output_file}")
            else:
                click.echo(output)

    except Exception as e:
        click.echo(f"✗ Export failed: {e}", err=True)
        raise click.Exit(1)


@cli.command()
@click.option(
    "--db",
    "db_path",
    default="~/.plyra/audits.db",
    type=click.Path(),
    help="Path to SQLite database",
)
@click.option(
    "--port",
    "port",
    type=int,
    default=8765,
    help="Port to listen on",
)
@click.option(
    "--host",
    "host",
    default="0.0.0.0",
    help="Host to bind to",
)
def serve(db_path: str, port: int, host: str):
    """Start Plyra audit dashboard (requires Flask/FastAPI).

    Note: Dashboard server requires Flask or FastAPI to be installed.
    This is a placeholder that shows the audit database path.

    Examples:
        plyra-audit serve --port 8765
    """
    click.echo(f"📊 Plyra Audit Dashboard")
    click.echo(f"🗄️  Database: {Path(db_path).expanduser()}")
    click.echo()

    try:
        with SQLiteStorage(db_path) as storage:
            total = storage.count()
            click.echo(f"📈 Total audit entries: {total}")
            click.echo()

            # Show summary
            entries = storage.query(limit=5)
            if entries:
                click.echo("📝 Recent entries:")
                for entry in entries:
                    click.echo(
                        f"  • {entry['timestamp']}: {entry['agent_id']} — {entry['action']}"
                    )
            else:
                click.echo("No entries found in database.")

        click.echo()
        click.echo(f"💡 To set up a full dashboard, install Flask/FastAPI:")
        click.echo(f"   pip install flask")
        click.echo(f"   Then implement: plyra_id.dashboard")

    except Exception as e:
        click.echo(f"✗ Failed to read database: {e}", err=True)
        raise click.Exit(1)


@cli.command()
@click.option(
    "--signature",
    "signature",
    required=True,
    help="Signature to verify (ed25519:...)",
)
@click.option(
    "--public-key",
    "public_key_file",
    type=click.File("r"),
    required=True,
    help="Public key file (PEM format)",
)
@click.option(
    "--message",
    "message",
    required=True,
    help="Message to verify",
)
def verify(signature: str, public_key_file, message: str):
    """Verify a signed message.

    Examples:
        plyra-audit verify --signature "ed25519:..." --public-key key.pem --message "test"
    """
    try:
        pk_content = public_key_file.read()
        is_valid = verify_signature(message, signature, pk_content)

        if is_valid:
            click.echo(click.style("✓ Signature is valid", fg="green"))
        else:
            click.echo(click.style("✗ Signature is invalid", fg="red"))
            raise click.Exit(1)

    except Exception as e:
        click.echo(f"✗ Verification failed: {e}", err=True)
        raise click.Exit(1)


@cli.command()
@click.option(
    "--owner",
    required=True,
    help="Agent owner (email or identifier)",
)
@click.option(
    "--name",
    required=True,
    help="Agent name",
)
@click.option(
    "--output",
    "output_file",
    type=click.Path(),
    required=True,
    help="Output file for agent JSON",
)
def create_agent(owner: str, name: str, output_file: str):
    """Create a new agent identity.

    Examples:
        plyra-audit create-agent --owner user@company.com --name "Research Agent" --output agent.json
    """
    try:
        agent = AgentID.create(owner, name)
        output_data = agent.to_dict(include_private_key=True)

        Path(output_file).parent.mkdir(parents=True, exist_ok=True)
        Path(output_file).write_text(json.dumps(output_data, indent=2))

        click.echo(click.style("✓ Agent created successfully", fg="green"))
        click.echo(f"  Agent ID: {agent.id}")
        click.echo(f"  Owner: {agent.owner}")
        click.echo(f"  Name: {agent.name}")
        click.echo(f"  Saved to: {output_file}")

    except Exception as e:
        click.echo(f"✗ Failed to create agent: {e}", err=True)
        raise click.Exit(1)


@cli.command()
@click.option(
    "--db",
    "db_path",
    default="~/.plyra/audits.db",
    type=click.Path(),
    help="Path to SQLite database",
)
def stats(db_path: str):
    """Show database statistics.

    Examples:
        plyra-audit stats
    """
    try:
        with SQLiteStorage(db_path) as storage:
            total = storage.count()
            click.echo(f"📊 Database: {Path(db_path).expanduser()}")
            click.echo(f"📈 Total entries: {total}")

            # Count by status
            for status_val in ["success", "failed", "blocked", "escalated"]:
                count = len(storage.query(status=status_val, limit=100000))
                click.echo(f"  • {status_val}: {count}")

    except Exception as e:
        click.echo(f"✗ Failed to read database: {e}", err=True)
        raise click.Exit(1)


def main():
    """Entry point for CLI."""
    cli()


if __name__ == "__main__":
    main()
