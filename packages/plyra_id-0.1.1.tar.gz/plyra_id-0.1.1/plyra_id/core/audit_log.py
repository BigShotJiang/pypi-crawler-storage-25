"""Audit log schema and serialization module.

This module defines the audit trail structure and provides methods to
serialize audit entries and logs to various formats (JSON, CSV).
"""

import csv
import io
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


class ActionStatus(str, Enum):
    """Status of an agent action."""

    SUCCESS = "success"
    BLOCKED = "blocked"
    ESCALATED = "escalated"
    FAILED = "failed"


@dataclass
class AuditLogEntry:
    """Single signed action entry in an audit log.

    Each entry represents one action taken by an agent, including who
    authorized it, what constraints were enforced, and a cryptographic
    signature proving the action occurred as recorded.
    """

    agent_id: str
    action: str
    input_hash: str
    authorized_by: str
    timestamp: str
    signature: str
    policy_constraints: List[str]
    status: ActionStatus = ActionStatus.SUCCESS
    output_hash: Optional[str] = None
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Export entry to dictionary.

        Returns:
            Dictionary representation of the audit entry
        """
        result = asdict(self)
        result["status"] = self.status.value
        return result

    def to_json(self, pretty: bool = False) -> str:
        """Export entry to JSON string.

        Args:
            pretty: If True, format with indentation (default False)

        Returns:
            JSON string representation
        """
        data = self.to_dict()
        if pretty:
            return json.dumps(data, indent=2)
        return json.dumps(data)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditLogEntry":
        """Reconstruct entry from dictionary.

        Args:
            data: Dictionary containing entry fields

        Returns:
            AuditLogEntry instance
        """
        data_copy = data.copy()
        # Convert status string to enum if needed
        if isinstance(data_copy.get("status"), str):
            data_copy["status"] = ActionStatus(data_copy["status"])
        return cls(**data_copy)


@dataclass
class AuditLog:
    """Collection of audit log entries.

    Provides methods to aggregate, serialize, and export audit trails
    for compliance reporting.
    """

    entries: List[AuditLogEntry] = field(default_factory=list)
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def add_entry(self, entry: AuditLogEntry) -> None:
        """Add an entry to the audit log.

        Args:
            entry: AuditLogEntry to add
        """
        self.entries.append(entry)

    def to_dict(self) -> Dict[str, Any]:
        """Export log to dictionary.

        Returns:
            Dictionary with metadata and all entries
        """
        return {
            "created_at": self.created_at,
            "entry_count": len(self.entries),
            "entries": [e.to_dict() for e in self.entries],
        }

    def to_json(self, pretty: bool = True) -> str:
        """Export log to JSON string.

        Args:
            pretty: If True, format with indentation (default True)

        Returns:
            JSON string representation
        """
        data = self.to_dict()
        if pretty:
            return json.dumps(data, indent=2)
        return json.dumps(data)

    def to_csv(self) -> str:
        """Export log to CSV format.

        Returns:
            CSV string with audit entries

        Example:
            >>> csv_output = audit_log.to_csv()
            >>> # Write to file
            >>> with open("audit.csv", "w") as f:
            ...     f.write(csv_output)
        """
        if not self.entries:
            return ""

        output = io.StringIO()
        fieldnames = [
            "timestamp",
            "agent_id",
            "action",
            "authorized_by",
            "status",
            "policy_constraints",
        ]
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()

        for entry in self.entries:
            writer.writerow(
                {
                    "timestamp": entry.timestamp,
                    "agent_id": entry.agent_id,
                    "action": entry.action,
                    "authorized_by": entry.authorized_by,
                    "status": entry.status.value,
                    "policy_constraints": ";".join(entry.policy_constraints),
                }
            )

        return output.getvalue()

    @classmethod
    def from_json(cls, json_str: str) -> "AuditLog":
        """Reconstruct log from JSON string.

        Args:
            json_str: JSON string containing log data

        Returns:
            AuditLog instance
        """
        data = json.loads(json_str)
        log = cls(created_at=data.get("created_at", datetime.now(timezone.utc).isoformat()))
        for entry_data in data.get("entries", []):
            log.add_entry(AuditLogEntry.from_dict(entry_data))
        return log
