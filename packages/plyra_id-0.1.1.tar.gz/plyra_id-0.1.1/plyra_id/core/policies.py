"""Policy constraint enforcement module.

This module provides a policy engine that evaluates constraints against
agent actions, ensuring agents operate within defined boundaries.
"""

import fnmatch
from enum import Enum
from typing import Any, Callable, Dict, List


class ConstraintType(str, Enum):
    """Standard constraint types for agent actions."""

    NO_FILE_WRITE = "no_file_write"
    NO_EXTERNAL_PAYMENTS = "no_external_payments"
    NO_DATABASE_DELETE = "no_database_delete"
    MAX_TOKEN_USAGE = "max_token_usage"
    RESTRICTED_TO = "restricted_to"


class PolicyEngine:
    """Evaluates agent policy constraints.

    Checks whether proposed actions violate defined constraints.
    """

    def __init__(self) -> None:
        """Initialize policy engine with constraint handlers."""
        self.constraint_handlers: Dict[str, Callable[[str, Dict[str, Any]], bool]] = {
            "no_file_write": self._check_no_file_write,
            "no_external_payments": self._check_no_external_payments,
            "no_database_delete": self._check_no_database_delete,
            "max_token_usage": self._check_max_token_usage,
            "restricted_to": self._check_restricted_to,
        }

    def check_constraint(
        self,
        constraint: str,
        context: Dict[str, Any],
    ) -> bool:
        """Check if action violates a single constraint.

        Args:
            constraint: Constraint string (e.g., "no_file_write" or "max_token_usage:10000")
            context: Action context dictionary with keys like "action", "resource", etc.

        Returns:
            True if constraint is satisfied, False if violated
        """
        constraint_type = constraint.split(":")[0]
        handler = self.constraint_handlers.get(constraint_type)

        if not handler:
            # Unknown constraint type = pass (don't block unknown constraints)
            return True

        return handler(constraint, context)

    def evaluate_all(
        self,
        constraints: List[str],
        context: Dict[str, Any],
    ) -> bool:
        """Evaluate all constraints. Return True if all are satisfied.

        Args:
            constraints: List of constraint strings
            context: Action context

        Returns:
            True if all constraints are satisfied, False if any violated
        """
        return all(self.check_constraint(c, context) for c in constraints)

    def _check_no_file_write(self, constraint: str, context: Dict[str, Any]) -> bool:
        """Check if action writes files."""
        action = context.get("action", "").lower()
        blocked_keywords = ["write", "upload", "save", "create_file"]
        return not any(keyword in action for keyword in blocked_keywords)

    def _check_no_external_payments(self, constraint: str, context: Dict[str, Any]) -> bool:
        """Check if action initiates payments."""
        action = context.get("action", "").lower()
        blocked_keywords = ["payment", "transfer", "charge", "withdraw"]
        return not any(keyword in action for keyword in blocked_keywords)

    def _check_no_database_delete(self, constraint: str, context: Dict[str, Any]) -> bool:
        """Check if action deletes from database."""
        action = context.get("action", "").lower()
        blocked_keywords = ["delete", "drop", "truncate", "remove"]
        return not any(keyword in action for keyword in blocked_keywords)

    def _check_max_token_usage(self, constraint: str, context: Dict[str, Any]) -> bool:
        """Check if token usage exceeds limit.

        Constraint format: "max_token_usage:10000"
        """
        parts = constraint.split(":")
        if len(parts) < 2:
            return True

        try:
            max_tokens = int(parts[1])
            current_tokens = context.get("token_count", 0)
            return current_tokens <= max_tokens
        except (ValueError, KeyError):
            return True

    def _check_restricted_to(self, constraint: str, context: Dict[str, Any]) -> bool:
        """Check if action is restricted to specific resources.

        Constraint format: "restricted_to:users/*" or "restricted_to:/data/public/*"
        Uses wildcard pattern matching.
        """
        parts = constraint.split(":")
        if len(parts) < 2:
            return True

        allowed_pattern = parts[1]
        resource = context.get("resource", "")

        # Simple wildcard matching (supports * and ?)
        return fnmatch.fnmatch(resource, allowed_pattern)
