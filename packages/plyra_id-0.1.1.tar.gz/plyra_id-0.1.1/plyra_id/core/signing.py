"""Cryptographic signing and verification module using Ed25519.

This module provides functions to sign and verify messages using Ed25519
cryptography, ensuring tamper-evident audit trails.
"""

import base64
import json
from typing import Any, Dict

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519


def sign_action(message: str, private_key_pem: str) -> str:
    """Sign an action message using Ed25519.

    Args:
        message: The message/action to sign
        private_key_pem: Private key in PEM format

    Returns:
        Signature in format "ed25519:<base64_encoded_signature>"

    Raises:
        ValueError: If private key is not valid Ed25519 key

    Example:
        >>> signature = sign_action("action_123", private_key_pem)
        >>> signature
        'ed25519:abc123...'
    """
    # Load private key from PEM
    private_key = serialization.load_pem_private_key(
        private_key_pem.encode(),
        password=None,
    )

    # Validate it's an Ed25519 key
    if not isinstance(private_key, ed25519.Ed25519PrivateKey):
        raise ValueError("Private key must be Ed25519")

    # Sign the message
    signature_bytes = private_key.sign(message.encode())

    # Encode as base64
    signature_b64 = base64.b64encode(signature_bytes).decode()

    return f"ed25519:{signature_b64}"


def verify_signature(message: str, signature: str, public_key_pem: str) -> bool:
    """Verify a signed message using Ed25519.

    Args:
        message: The original message/action that was signed
        signature: The signature in format "ed25519:<base64>"
        public_key_pem: Public key in PEM format

    Returns:
        True if signature is valid, False otherwise

    Example:
        >>> is_valid = verify_signature(message, signature, public_key_pem)
        >>> is_valid
        True
    """
    try:
        # Validate signature format
        if not signature.startswith("ed25519:"):
            return False

        # Extract base64 part
        signature_b64 = signature[8:]
        signature_bytes = base64.b64decode(signature_b64)

        # Load public key
        public_key = serialization.load_pem_public_key(public_key_pem.encode())

        # Validate it's an Ed25519 key
        if not isinstance(public_key, ed25519.Ed25519PublicKey):
            return False

        # Verify signature
        public_key.verify(signature_bytes, message.encode())
        return True

    except (InvalidSignature, ValueError, Exception):
        return False


def sign_dict(data: Dict[str, Any], private_key_pem: str) -> str:
    """Sign a dictionary by signing its JSON representation.

    Ensures deterministic JSON serialization (sorted keys) for consistent
    signatures across different systems.

    Args:
        data: Dictionary to sign
        private_key_pem: Private key in PEM format

    Returns:
        Signature in format "ed25519:<base64_encoded_signature>"

    Example:
        >>> action_dict = {"action": "read", "resource": "file.txt"}
        >>> signature = sign_dict(action_dict, private_key_pem)
    """
    # Serialize to deterministic JSON (sorted keys, minimal whitespace)
    json_str = json.dumps(data, sort_keys=True, separators=(",", ":"))
    return sign_action(json_str, private_key_pem)


def verify_dict(
    data: Dict[str, Any],
    signature: str,
    public_key_pem: str,
) -> bool:
    """Verify a signed dictionary.

    Args:
        data: The dictionary that was signed
        signature: The signature in format "ed25519:<base64>"
        public_key_pem: Public key in PEM format

    Returns:
        True if signature is valid, False otherwise

    Example:
        >>> is_valid = verify_dict(action_dict, signature, public_key_pem)
    """
    # Serialize to same deterministic JSON format
    json_str = json.dumps(data, sort_keys=True, separators=(",", ":"))
    return verify_signature(json_str, signature, public_key_pem)
