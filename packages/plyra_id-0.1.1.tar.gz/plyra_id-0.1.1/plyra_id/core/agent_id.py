"""Agent identity generation and management module.

This module provides cryptographic identity management for autonomous agents
using Ed25519 keypair generation.
"""

from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
import hashlib

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from pydantic import BaseModel, Field


class AgentID(BaseModel):
    """Cryptographic identity for an autonomous agent."""

    id: str = Field(..., description="Unique agent ID (plyra://agt_...)")
    owner: str = Field(..., description="Owner email or identifier")
    name: str = Field(..., description="Human-readable agent name")
    policy_constraints: List[str] = Field(
        default_factory=list,
        description="List of policy constraints (e.g., 'no_file_write')",
    )
    public_key_pem: str = Field(..., description="Ed25519 public key in PEM format")
    private_key_pem: Optional[str] = Field(
        default=None,
        description="Ed25519 private key in PEM format (export only)",
    )
    created_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
        description="ISO8601 timestamp",
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Custom metadata",
    )

    class Config:
        """Pydantic config."""

        frozen = False

    @classmethod
    def create(
        cls,
        owner: str,
        name: str,
        policy_constraints: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "AgentID":
        """Generate a new agent identity with Ed25519 keypair.

        Args:
            owner: Email or identifier of the agent owner
            name: Human-readable name for the agent
            policy_constraints: Optional list of policy constraint names
            metadata: Optional custom metadata dictionary

        Returns:
            AgentID instance with generated keypair

        Example:
            >>> agent = AgentID.create("compliance@company.com", "doc-analyzer")
            >>> print(agent.id)
            plyra://agt_abc123...
        """
        # Generate Ed25519 keypair
        private_key = ed25519.Ed25519PrivateKey.generate()
        public_key = private_key.public_key()

        # Serialize keys to PEM format
        pub_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode()

        priv_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode()

        # Generate agent ID from public key hash (first 8 chars of SHA256)
        pub_hash = hashlib.sha256(pub_pem.encode()).hexdigest()[:8]
        agent_id = f"plyra://agt_{pub_hash}"

        return cls(
            id=agent_id,
            owner=owner,
            name=name,
            policy_constraints=policy_constraints or [],
            public_key_pem=pub_pem,
            private_key_pem=priv_pem,
            metadata=metadata or {},
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentID":
        """Reconstruct AgentID from dictionary.

        Args:
            data: Dictionary containing AgentID fields

        Returns:
            AgentID instance

        Example:
            >>> agent_dict = {"id": "plyra://agt_abc123", "owner": "test@example.com", ...}
            >>> agent = AgentID.from_dict(agent_dict)
        """
        return cls(**data)

    def to_dict(self, include_private_key: bool = False) -> Dict[str, Any]:
        """Export to dictionary.

        Args:
            include_private_key: If True, include private key in export.
                                 Default False for security.

        Returns:
            Dictionary representation of the agent

        Example:
            >>> agent = AgentID.create("test@example.com", "agent-1")
            >>> data = agent.to_dict(include_private_key=False)
            >>> "private_key_pem" not in data  # True
        """
        data = {
            "id": self.id,
            "owner": self.owner,
            "name": self.name,
            "policy_constraints": self.policy_constraints,
            "public_key_pem": self.public_key_pem,
            "private_key_pem": self.private_key_pem,
            "created_at": self.created_at,
            "metadata": self.metadata,
        }
        if not include_private_key:
            data.pop("private_key_pem", None)
        return data

    def public_key_bytes(self) -> bytes:
        """Get public key as bytes.

        Returns:
            Public key in bytes form (PEM encoded as UTF-8)
        """
        return self.public_key_pem.encode()


def generate_agent_id(owner: str, name: str) -> str:
    """Shorthand to generate just the agent ID string.

    Args:
        owner: Email or identifier of the agent owner
        name: Human-readable name for the agent

    Returns:
        Agent ID string (format: plyra://agt_<hash>)

    Example:
        >>> agent_id = generate_agent_id("test@example.com", "analyzer")
        >>> agent_id
        'plyra://agt_abc123...'
    """
    agent = AgentID.create(owner, name)
    return agent.id


def validate_agent_id(agent_id: str) -> bool:
    """Validate agent ID format.

    Args:
        agent_id: Agent ID string to validate

    Returns:
        True if valid format, False otherwise

    Example:
        >>> validate_agent_id("plyra://agt_abc123def4")
        True
        >>> validate_agent_id("invalid_id")
        False
    """
    return agent_id.startswith("plyra://agt_") and len(agent_id) >= 20
