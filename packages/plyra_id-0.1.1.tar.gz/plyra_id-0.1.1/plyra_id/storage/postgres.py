"""PostgreSQL storage backend for plyra-id audit logs."""

import json
from typing import Any, Dict, List, Optional

from plyra_id.core.audit_log import AuditLogEntry


class PostgreSQLStorage:
    """PostgreSQL-based storage for audit log entries.

    Requires: pip install psycopg

    Usage:
        storage = PostgreSQLStorage(
            host="localhost",
            database="plyra",
            user="plyra",
            password="secret"
        )
        storage.store(audit_entry)
        entries = storage.query(agent_id="plyra://agt_...")
        storage.close()
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 5432,
        database: str = "plyra",
        user: str = "plyra",
        password: str = "",
    ):
        """Initialize PostgreSQL storage.

        Args:
            host: PostgreSQL host
            port: PostgreSQL port
            database: Database name
            user: Database user
            password: Database password
        """
        try:
            import psycopg
            self.psycopg = psycopg
        except ImportError:
            raise ImportError(
                "psycopg not installed. Install with: pip install psycopg"
            )

        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self.conn: Any = None
        self._init_db()

    def _init_db(self) -> None:
        """Initialize database schema."""
        self.conn = self.psycopg.connect(
            host=self.host,
            port=self.port,
            dbname=self.database,
            user=self.user,
            password=self.password,
        )

        with self.conn.cursor() as cursor:
            # Create audit log table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id SERIAL PRIMARY KEY,
                    agent_id TEXT NOT NULL,
                    action TEXT NOT NULL,
                    input_hash TEXT,
                    output_hash TEXT,
                    authorized_by TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    signature TEXT,
                    status TEXT DEFAULT 'success',
                    error_message TEXT,
                    policy_constraints JSONB,
                    metadata JSONB,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Create indexes
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_agent_id ON audit_logs(agent_id)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_timestamp ON audit_logs(timestamp)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_status ON audit_logs(status)
            """)

        self.conn.commit()

    def store(self, entry: AuditLogEntry) -> int:
        """Store an audit log entry.

        Args:
            entry: AuditLogEntry to store

        Returns:
            Row ID of stored entry
        """
        with self.conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO audit_logs (
                    agent_id, action, input_hash, output_hash,
                    authorized_by, timestamp, signature, status,
                    error_message, policy_constraints, metadata
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
            """, (
                entry.agent_id,
                entry.action,
                entry.input_hash,
                entry.output_hash,
                entry.authorized_by,
                entry.timestamp,
                entry.signature,
                entry.status.value,
                entry.error_message,
                json.dumps(entry.policy_constraints),
                json.dumps(entry.metadata),
            ))
            row_id = cursor.fetchone()[0]

        self.conn.commit()
        return row_id

    def query(
        self,
        agent_id: Optional[str] = None,
        action: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Query audit log entries.

        Args:
            agent_id: Filter by agent ID
            action: Filter by action
            status: Filter by status
            limit: Maximum number of results

        Returns:
            List of matching entries
        """
        where_clauses = []
        params = []

        if agent_id:
            where_clauses.append("agent_id = %s")
            params.append(agent_id)
        if action:
            where_clauses.append("action = %s")
            params.append(action)
        if status:
            where_clauses.append("status = %s")
            params.append(status)

        where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"
        query_sql = f"""
            SELECT * FROM audit_logs
            WHERE {where_sql}
            ORDER BY timestamp DESC
            LIMIT %s
        """
        params.append(limit)

        with self.conn.cursor() as cursor:
            cursor.execute(query_sql, params)
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]

    def get_by_id(self, row_id: int) -> Optional[Dict[str, Any]]:
        """Get a single entry by row ID.

        Args:
            row_id: Row ID

        Returns:
            Entry dictionary or None if not found
        """
        with self.conn.cursor() as cursor:
            cursor.execute("SELECT * FROM audit_logs WHERE id = %s", (row_id,))
            row = cursor.fetchone()
            if row:
                columns = [desc[0] for desc in cursor.description]
                return dict(zip(columns, row))
        return None

    def count(self, agent_id: Optional[str] = None) -> int:
        """Count entries.

        Args:
            agent_id: Filter by agent ID (optional)

        Returns:
            Number of entries
        """
        with self.conn.cursor() as cursor:
            if agent_id:
                cursor.execute(
                    "SELECT COUNT(*) FROM audit_logs WHERE agent_id = %s",
                    (agent_id,),
                )
            else:
                cursor.execute("SELECT COUNT(*) FROM audit_logs")
            return cursor.fetchone()[0]

    def delete_by_age(self, days: int) -> int:
        """Delete entries older than N days.

        Args:
            days: Age in days

        Returns:
            Number of deleted entries
        """
        with self.conn.cursor() as cursor:
            cursor.execute("""
                DELETE FROM audit_logs
                WHERE created_at < NOW() - INTERVAL '%s days'
            """, (days,))
            deleted = cursor.rowcount

        self.conn.commit()
        return deleted

    def export_json(self, agent_id: Optional[str] = None) -> str:
        """Export entries to JSON.

        Args:
            agent_id: Filter by agent ID (optional)

        Returns:
            JSON string
        """
        entries = self.query(agent_id=agent_id, limit=10000)
        return json.dumps(entries, indent=2, default=str)

    def export_csv(self, agent_id: Optional[str] = None) -> str:
        """Export entries to CSV.

        Args:
            agent_id: Filter by agent ID (optional)

        Returns:
            CSV string
        """
        import csv
        import io

        entries = self.query(agent_id=agent_id, limit=10000)
        if not entries:
            return ""

        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=entries[0].keys())
        writer.writeheader()
        writer.writerows(entries)

        return output.getvalue()

    def close(self) -> None:
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
