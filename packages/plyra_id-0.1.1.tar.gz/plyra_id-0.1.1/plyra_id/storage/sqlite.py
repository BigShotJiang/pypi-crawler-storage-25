"""SQLite storage backend for plyra-id audit logs."""

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from plyra_id.core.audit_log import ActionStatus, AuditLogEntry


class SQLiteStorage:
    """SQLite-based storage for audit log entries.

    Usage:
        storage = SQLiteStorage(db_path="~/.plyra/audits.db")
        storage.store(audit_entry)
        entries = storage.query(agent_id="plyra://agt_...")
        storage.close()
    """

    def __init__(self, db_path: str = "~/.plyra/audits.db"):
        """Initialize SQLite storage.

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = str(Path(db_path).expanduser())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn: Optional[sqlite3.Connection] = None
        self._init_db()

    def _init_db(self) -> None:
        """Initialize database schema."""
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        cursor = self.conn.cursor()

        # Create audit log table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                action TEXT NOT NULL,
                input_hash TEXT,
                output_hash TEXT,
                authorized_by TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                signature TEXT,
                status TEXT DEFAULT 'success',
                error_message TEXT,
                policy_constraints TEXT,
                metadata TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Create index for fast queries
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_agent_id ON audit_logs(agent_id)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_timestamp ON audit_logs(timestamp)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_status ON audit_logs(status)
        """)

        self.conn.commit()

    def store(self, entry: AuditLogEntry) -> int:
        """Store an audit log entry.

        Args:
            entry: AuditLogEntry to store

        Returns:
            Row ID of stored entry
        """
        cursor = self.conn.cursor()

        cursor.execute("""
            INSERT INTO audit_logs (
                agent_id, action, input_hash, output_hash,
                authorized_by, timestamp, signature, status,
                error_message, policy_constraints, metadata
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            entry.agent_id,
            entry.action,
            entry.input_hash,
            entry.output_hash,
            entry.authorized_by,
            entry.timestamp,
            entry.signature,
            entry.status.value,
            entry.error_message,
            json.dumps(entry.policy_constraints),
            json.dumps(entry.metadata),
        ))

        self.conn.commit()
        return cursor.lastrowid

    def query(
        self,
        agent_id: Optional[str] = None,
        action: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Query audit log entries.

        Args:
            agent_id: Filter by agent ID
            action: Filter by action
            status: Filter by status
            limit: Maximum number of results

        Returns:
            List of matching entries
        """
        cursor = self.conn.cursor()
        where_clauses = []
        params = []

        if agent_id:
            where_clauses.append("agent_id = ?")
            params.append(agent_id)
        if action:
            where_clauses.append("action = ?")
            params.append(action)
        if status:
            where_clauses.append("status = ?")
            params.append(status)

        where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"
        query_sql = f"""
            SELECT * FROM audit_logs
            WHERE {where_sql}
            ORDER BY timestamp DESC
            LIMIT ?
        """
        params.append(limit)

        cursor.execute(query_sql, params)
        columns = [desc[0] for desc in cursor.description]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]

    def get_by_id(self, row_id: int) -> Optional[Dict[str, Any]]:
        """Get a single entry by row ID.

        Args:
            row_id: Row ID

        Returns:
            Entry dictionary or None if not found
        """
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM audit_logs WHERE id = ?", (row_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            return dict(zip(columns, row))
        return None

    def count(self, agent_id: Optional[str] = None) -> int:
        """Count entries.

        Args:
            agent_id: Filter by agent ID (optional)

        Returns:
            Number of entries
        """
        cursor = self.conn.cursor()
        if agent_id:
            cursor.execute("SELECT COUNT(*) FROM audit_logs WHERE agent_id = ?", (agent_id,))
        else:
            cursor.execute("SELECT COUNT(*) FROM audit_logs")
        return cursor.fetchone()[0]

    def delete_by_age(self, days: int) -> int:
        """Delete entries older than N days.

        Args:
            days: Age in days

        Returns:
            Number of deleted entries
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            DELETE FROM audit_logs
            WHERE created_at < datetime('now', ? || ' days')
        """, (f"-{days}",))
        self.conn.commit()
        return cursor.rowcount

    def export_json(self, agent_id: Optional[str] = None) -> str:
        """Export entries to JSON.

        Args:
            agent_id: Filter by agent ID (optional)

        Returns:
            JSON string
        """
        entries = self.query(agent_id=agent_id, limit=10000)
        return json.dumps(entries, indent=2, default=str)

    def export_csv(self, agent_id: Optional[str] = None) -> str:
        """Export entries to CSV.

        Args:
            agent_id: Filter by agent ID (optional)

        Returns:
            CSV string
        """
        import csv
        import io

        entries = self.query(agent_id=agent_id, limit=10000)
        if not entries:
            return ""

        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=entries[0].keys())
        writer.writeheader()
        writer.writerows(entries)

        return output.getvalue()

    def close(self) -> None:
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
