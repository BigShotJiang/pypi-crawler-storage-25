from contextvars import ContextVar
from uuid import UUID

_user_id: ContextVar[UUID | None] = ContextVar("user_id", default=None)
_conversation_id: ContextVar[str | None] = ContextVar("conversation_id", default=None)


def get_user_id() -> UUID | None:
    """Return the current user ID from the request context."""
    return _user_id.get()


def set_user_id(value: UUID | None) -> None:
    """Set the current user ID in the request context."""
    _user_id.set(value)


def get_conversation_id() -> str | None:
    """Return the current conversation ID from the request context."""
    return _conversation_id.get()


def set_conversation_id(value: str | None) -> None:
    """Set the current conversation ID in the request context."""
    _conversation_id.set(value)

