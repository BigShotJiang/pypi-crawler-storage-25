"""CLI entry point for Percona server."""

import sys


def main() -> None:
    """Start the Percona API server."""
    import uvicorn

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8002
    uvicorn.run("percona.main:app", host="0.0.0.0", port=port, log_level="info")


if __name__ == "__main__":
    main()
