import json
import logging
import smtplib
import uuid
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import httpx

from percona.config import settings
from percona.models import NotificationChannelType, Severity

logger = logging.getLogger(__name__)

SEVERITY_COLORS = {
    Severity.CRITICAL: "#dc2626",
    Severity.HIGH: "#ea580c",
    Severity.MEDIUM: "#d97706",
    Severity.LOW: "#2563eb",
    Severity.INFO: "#6b7280",
}

SEVERITY_EMOJI = {
    Severity.CRITICAL: "🔴",
    Severity.HIGH: "🟠",
    Severity.MEDIUM: "🟡",
    Severity.LOW: "🔵",
    Severity.INFO: "⚪",
}


async def send_slack_notification(
    webhook_url: str,
    finding: dict,
    session_id: str,
    task_name: str,
    portal_base_url: str = "http://localhost:3000",
) -> bool:
    """Send a Slack Block Kit notification for a finding."""
    logger.debug("send_slack_notification_start session_id=%s task_name=%s", session_id, task_name)
    severity = finding["severity"]
    color = SEVERITY_COLORS.get(Severity(severity), "#6b7280")
    emoji = SEVERITY_EMOJI.get(Severity(severity), "⚪")

    blocks = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": f"{emoji} {finding['title']}", "emoji": True},
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Severity:* {severity.upper()}"},
                {"type": "mrkdwn", "text": f"*Type:* {finding['finding_type']}"},
                {"type": "mrkdwn", "text": f"*Task:* {task_name}"},
            ],
        },
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": finding["summary"][:3000]},
        },
    ]

    if finding.get("recommendation"):
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*Recommendation:*\n{finding['recommendation'][:1000]}"},
        })

    if finding.get("affected_components"):
        components = ", ".join(str(c) for c in finding["affected_components"][:10])
        blocks.append({
            "type": "context",
            "elements": [{"type": "mrkdwn", "text": f"*Affected:* {components}"}],
        })

    blocks.append({
        "type": "actions",
        "elements": [
            {
                "type": "button",
                "text": {"type": "plain_text", "text": "View Finding"},
                "url": f"{portal_base_url}/findings/{finding.get('id', '')}",
            },
            {
                "type": "button",
                "text": {"type": "plain_text", "text": "View Session"},
                "url": f"{portal_base_url}/sessions/{session_id}",
            },
        ],
    })

    payload = {"attachments": [{"color": color, "blocks": blocks}]}

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(webhook_url, json=payload, timeout=10)
            resp.raise_for_status()
            logger.info("send_slack_notification_success session_id=%s task_name=%s", session_id, task_name)
            return True
    except Exception as e:
        logger.error("send_slack_notification_failed session_id=%s task_name=%s error=%s", session_id, task_name, str(e))
        return False


async def send_pushover_notification(
    token: str,
    user: str,
    title: str,
    message: str,
) -> tuple[bool, str | None]:
    """Send a Pushover push notification."""
    logger.debug("send_pushover_notification_start title=%s", title)
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                "https://api.pushover.net/1/messages.json",
                json={"token": token, "user": user, "title": title[:250], "message": message[:1024]},
                timeout=10,
            )
            resp.raise_for_status()
        logger.info("send_pushover_notification_success title=%s", title)
        return True, None
    except Exception as e:
        error_msg = f"Pushover API request failed: {str(e)}"
        logger.error("send_pushover_notification_failed error=%s", str(e))
        return False, error_msg


async def send_telegram_notification(
    bot_token: str,
    chat_id: str,
    text: str,
    parse_mode: str = "HTML",
    reply_markup: dict | None = None,
) -> tuple[bool, str | None, int | None]:
    """Send a Telegram message. Returns (success, error_msg, message_id)."""
    logger.debug("send_telegram_notification_start chat_id=%s", chat_id)
    body: dict = {"chat_id": chat_id, "text": text, "parse_mode": parse_mode}
    if reply_markup:
        body["reply_markup"] = reply_markup
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"https://api.telegram.org/bot{bot_token}/sendMessage",
                json=body,
                timeout=10,
            )
            data = resp.json()
            if resp.status_code == 200 and data.get("ok"):
                msg_id = data["result"]["message_id"]
                logger.info("send_telegram_notification_success chat_id=%s message_id=%s", chat_id, msg_id)
                return True, None, msg_id
            error_msg = data.get("description", f"Telegram API error: HTTP {resp.status_code}")
            logger.error("send_telegram_notification_failed chat_id=%s error=%s", chat_id, error_msg)
            return False, error_msg, None
    except Exception as e:
        error_msg = f"Telegram API request failed: {str(e)}"
        logger.error("send_telegram_notification_failed chat_id=%s error=%s", chat_id, str(e))
        return False, error_msg, None


async def send_whatsapp_notification(
    jid: str,
    text: str,
) -> tuple[bool, str | None]:
    """Send a WhatsApp message to a JID via the active neonize client.

    Returns (success, error_msg).
    """
    from percona.services import whatsapp_service as _wa_svc
    adapter = _wa_svc.get_adapter()
    if adapter is None:
        return False, "WhatsApp adapter is not running"
    client = adapter.client
    if client is None:
        return False, "No active WhatsApp session — pair a device first"
    try:
        from neonize.utils.jid import build_jid
        user_part = jid.split("@")[0] if "@" in jid else jid
        server_part = jid.split("@")[1] if "@" in jid else "s.whatsapp.net"
        target = build_jid(user_part, server_part)
        await client.send_message(target, text)
        logger.info("send_whatsapp_notification_success jid=%s", jid)
        return True, None
    except Exception as e:
        error_msg = f"WhatsApp send failed: {str(e)}"
        logger.error("send_whatsapp_notification_failed jid=%s error=%s", jid, str(e))
        return False, error_msg


def send_email_notification(
    recipients: list[str],
    finding: dict,
    session_id: str,
    task_name: str,
    smtp_config: dict | None = None,
) -> tuple[bool, str | None]:
    """Send HTML email notification for a finding.

    smtp_config keys (optional, override env-var settings):
      smtp_host, smtp_port, smtp_username, smtp_password, smtp_from_email, smtp_use_tls
    """
    cfg = smtp_config or {}
    smtp_host = cfg.get("smtp_host") or settings.smtp_host
    smtp_port = int(cfg.get("smtp_port") or settings.smtp_port or 587)
    smtp_username = cfg.get("smtp_username") or settings.smtp_username
    smtp_password = cfg.get("smtp_password") or settings.smtp_password
    smtp_from_email = cfg.get("smtp_from_email") or settings.smtp_from_email
    smtp_use_tls_raw = cfg.get("smtp_use_tls")
    if smtp_use_tls_raw is None:
        smtp_use_tls = settings.smtp_use_tls
    elif isinstance(smtp_use_tls_raw, bool):
        smtp_use_tls = smtp_use_tls_raw
    else:
        smtp_use_tls = str(smtp_use_tls_raw).lower() == "true"

    logger.debug("send_email_notification_start session_id=%s recipients=%s host=%s port=%s tls=%s user=%s",
                 session_id, len(recipients), smtp_host, smtp_port, smtp_use_tls, smtp_username)
    if not smtp_host:
        error_msg = "SMTP not configured: smtp_host is required"
        logger.warning("SMTP not configured, skipping email notification")
        return False, error_msg

    severity = finding["severity"]
    color = SEVERITY_COLORS.get(Severity(severity), "#6b7280")

    html = f"""
    <html>
    <body style="font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: {color}; color: white; padding: 16px; border-radius: 8px 8px 0 0;">
            <h2 style="margin: 0;">{finding['title']}</h2>
            <p style="margin: 4px 0 0 0; opacity: 0.9;">Severity: {severity.upper()} | Type: {finding['finding_type']} | Task: {task_name}</p>
        </div>
        <div style="padding: 16px; border: 1px solid #e5e7eb; border-top: none;">
            <h3>Summary</h3>
            <p>{finding['summary']}</p>
            {"<h3>Recommendation</h3><p>" + finding['recommendation'] + "</p>" if finding.get('recommendation') else ""}
            {"<h3>Affected Components</h3><p>" + ", ".join(str(c) for c in finding.get('affected_components', [])) + "</p>" if finding.get('affected_components') else ""}
        </div>
        <div style="padding: 12px 16px; background: #f9fafb; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
            <small style="color: #6b7280;">Session: {session_id} | Percona</small>
        </div>
    </body>
    </html>
    """

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"[Percona {severity.upper()}] {finding['title']}"
        msg["From"] = smtp_from_email
        msg["To"] = ", ".join(recipients)
        msg.attach(MIMEText(html, "html"))

        with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
            server.ehlo()
            if smtp_use_tls:
                server.starttls()
                server.ehlo()
            if smtp_username:
                server.login(smtp_username, smtp_password)
            server.send_message(msg)
        logger.info("send_email_notification_success session_id=%s recipients=%s", session_id, len(recipients))
        return True, None
    except Exception as e:
        error_msg = f"SMTP send failed: {str(e)}"
        logger.error("send_email_notification_failed session_id=%s error=%s", session_id, str(e))
        return False, error_msg
