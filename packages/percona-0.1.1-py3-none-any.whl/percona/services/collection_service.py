import re
import uuid
import logging
from typing import Any

from sqlalchemy import cast, Float, func, or_, select, Text
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models.collections import Collection, CollectionField, CollectionItem
from percona.schemas.collections import (
    CollectionCreate,
    CollectionFieldCreate,
    CollectionFieldUpdate,
    CollectionItemCreate,
    CollectionItemUpdate,
    CollectionUpdate,
    VALID_FIELD_TYPES,
)
from percona.services.embeddings import delete_entity_embedding, schedule_indexing

logger = logging.getLogger(__name__)


# --- Helpers ---

def _generate_slug(name: str) -> str:
    slug = name.lower().strip().replace(" ", "-")
    slug = re.sub(r"[^a-z0-9-]", "", slug)
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug or "collection"


def _collection_index_text(c: Collection) -> str:
    parts = [c.name, c.description or ""]
    if c.tags:
        parts.extend(c.tags)
    return " ".join(p for p in parts if p).strip()


def _item_index_text(item: CollectionItem) -> str:
    parts = []
    if isinstance(item.data, dict):
        for v in item.data.values():
            if isinstance(v, str):
                parts.append(v)
            elif isinstance(v, list):
                parts.extend(str(x) for x in v)
            elif v is not None:
                parts.append(str(v))
    if item.notes:
        parts.append(item.notes)
    if item.tags:
        parts.extend(item.tags)
    return " ".join(p for p in parts if p).strip()


def _validate_item_data(data: dict[str, Any], fields: list[CollectionField]) -> list[str]:
    """Validate item data against collection field schema. Returns list of errors."""
    errors = []
    field_map = {f.name: f for f in fields}

    for f in fields:
        val = data.get(f.name)
        if f.required and (val is None or val == ""):
            errors.append(f"Field '{f.label}' is required")
            continue

        if val is None or val == "":
            continue

        if f.field_type == "number":
            if not isinstance(val, (int, float)):
                try:
                    float(val)
                except (ValueError, TypeError):
                    errors.append(f"Field '{f.label}' must be a number")

        elif f.field_type == "boolean":
            if not isinstance(val, bool):
                errors.append(f"Field '{f.label}' must be true or false")

        elif f.field_type == "select":
            options = f.options or []
            if val not in options:
                errors.append(f"Field '{f.label}' must be one of: {', '.join(options)}")

        elif f.field_type == "email":
            if isinstance(val, str) and "@" not in val:
                errors.append(f"Field '{f.label}' must be a valid email")

        elif f.field_type == "url":
            if isinstance(val, str) and not val.startswith(("http://", "https://")):
                errors.append(f"Field '{f.label}' must be a valid URL")

        elif f.field_type == "tags":
            if not isinstance(val, list):
                errors.append(f"Field '{f.label}' must be a list of strings")

        elif f.field_type == "reference":
            if not isinstance(val, str):
                errors.append(f"Field '{f.label}' must be a UUID string referencing another item")

    return errors


# --- Collection CRUD ---

async def get_collection(db: AsyncSession, user_id: uuid.UUID, collection_id: uuid.UUID) -> Collection | None:
    result = await db.execute(
        select(Collection)
        .where(Collection.id == collection_id)
        .where(Collection.user_id == user_id)
    )
    return result.scalar_one_or_none()


async def get_collection_by_slug(db: AsyncSession, user_id: uuid.UUID, slug: str) -> Collection | None:
    result = await db.execute(
        select(Collection)
        .where(Collection.slug == slug)
        .where(Collection.user_id == user_id)
    )
    return result.scalar_one_or_none()


async def list_collections(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    status: str | None = None,
    search: str | None = None,
    limit: int = 25,
    offset: int = 0,
) -> list[Collection]:
    filters = [Collection.user_id == user_id]
    if status:
        filters.append(Collection.status == status)
    if search:
        like = f"%{search}%"
        filters.append(
            or_(
                Collection.name.ilike(like),
                Collection.description.ilike(like),
            )
        )
    stmt = select(Collection).order_by(Collection.name.asc()).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_collections(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    status: str | None = None,
    search: str | None = None,
) -> int:
    filters = [Collection.user_id == user_id]
    if status:
        filters.append(Collection.status == status)
    if search:
        like = f"%{search}%"
        filters.append(
            or_(
                Collection.name.ilike(like),
                Collection.description.ilike(like),
            )
        )
    stmt = select(func.count()).select_from(Collection)
    for f in filters:
        stmt = stmt.where(f)
    return await db.scalar(stmt) or 0


async def create_collection(db: AsyncSession, user_id: uuid.UUID, data: CollectionCreate) -> Collection:
    slug = _generate_slug(data.name)

    # Ensure unique slug per user
    existing = await get_collection_by_slug(db, user_id, slug)
    suffix = 2
    base_slug = slug
    while existing:
        slug = f"{base_slug}-{suffix}"
        existing = await get_collection_by_slug(db, user_id, slug)
        suffix += 1

    collection = Collection(
        name=data.name.strip(),
        slug=slug,
        description=data.description,
        icon=data.icon,
        color=data.color,
        tags=data.tags or [],
        agent_instructions=data.agent_instructions,
        template_slug=data.template_slug,
        session_id=data.session_id,
        user_id=user_id,
    )
    db.add(collection)
    await db.flush()

    # Create inline fields
    for i, field_data in enumerate(data.fields):
        if field_data.field_type not in VALID_FIELD_TYPES:
            raise ValueError(f"Invalid field_type: {field_data.field_type!r}")
        field = CollectionField(
            collection_id=collection.id,
            user_id=user_id,
            name=field_data.name,
            label=field_data.label,
            field_type=field_data.field_type,
            required=field_data.required,
            default_value=field_data.default_value,
            options=field_data.options,
            placeholder=field_data.placeholder,
            sort_order=field_data.sort_order if field_data.sort_order is not None else i,
        )
        db.add(field)

    await db.flush()
    logger.info("collection_created id=%s name=%s slug=%s fields=%d", collection.id, collection.name, slug, len(data.fields))
    schedule_indexing("collection", collection.id, _collection_index_text(collection))
    return collection


async def update_collection(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    data: CollectionUpdate,
) -> Collection | None:
    collection = await get_collection(db, user_id, collection_id)
    if not collection:
        return None
    updated = data.model_dump(exclude_unset=True)

    # Update slug if name changes
    if "name" in updated:
        new_slug = _generate_slug(updated["name"])
        if new_slug != collection.slug:
            existing = await get_collection_by_slug(db, user_id, new_slug)
            if existing and existing.id != collection_id:
                suffix = 2
                base_slug = new_slug
                while existing and existing.id != collection_id:
                    new_slug = f"{base_slug}-{suffix}"
                    existing = await get_collection_by_slug(db, user_id, new_slug)
                    suffix += 1
            updated["slug"] = new_slug

    for field, value in updated.items():
        setattr(collection, field, value)
    logger.info("collection_updated id=%s fields=%s", collection_id, list(updated.keys()))
    schedule_indexing("collection", collection.id, _collection_index_text(collection))
    return collection


async def delete_collection(db: AsyncSession, user_id: uuid.UUID, collection_id: uuid.UUID) -> bool:
    collection = await get_collection(db, user_id, collection_id)
    if not collection:
        return False
    await delete_entity_embedding(db, "collection", collection.id)
    await db.delete(collection)
    logger.info("collection_deleted id=%s", collection_id)
    return True


# --- Field CRUD ---

async def list_fields(db: AsyncSession, user_id: uuid.UUID, collection_id: uuid.UUID) -> list[CollectionField]:
    result = await db.execute(
        select(CollectionField)
        .where(CollectionField.collection_id == collection_id)
        .where(CollectionField.user_id == user_id)
        .order_by(CollectionField.sort_order.asc())
    )
    return list(result.scalars().all())


async def add_field(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    data: CollectionFieldCreate,
) -> CollectionField:
    # Verify collection exists and belongs to user
    collection = await get_collection(db, user_id, collection_id)
    if not collection:
        raise ValueError("Collection not found")
    if data.field_type not in VALID_FIELD_TYPES:
        raise ValueError(f"Invalid field_type: {data.field_type!r}")

    field = CollectionField(
        collection_id=collection_id,
        user_id=user_id,
        name=data.name,
        label=data.label,
        field_type=data.field_type,
        required=data.required,
        default_value=data.default_value,
        options=data.options,
        placeholder=data.placeholder,
        sort_order=data.sort_order,
    )
    db.add(field)
    await db.flush()
    logger.info("collection_field_added collection=%s field=%s type=%s", collection_id, data.name, data.field_type)
    return field


async def update_field(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    field_id: uuid.UUID,
    data: CollectionFieldUpdate,
) -> CollectionField | None:
    result = await db.execute(
        select(CollectionField)
        .where(CollectionField.id == field_id)
        .where(CollectionField.collection_id == collection_id)
        .where(CollectionField.user_id == user_id)
    )
    field = result.scalar_one_or_none()
    if not field:
        return None
    updated = data.model_dump(exclude_unset=True)
    if "field_type" in updated and updated["field_type"] not in VALID_FIELD_TYPES:
        raise ValueError(f"Invalid field_type: {updated['field_type']!r}")
    for k, v in updated.items():
        setattr(field, k, v)
    logger.info("collection_field_updated collection=%s field=%s", collection_id, field_id)
    return field


async def delete_field(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    field_id: uuid.UUID,
) -> bool:
    result = await db.execute(
        select(CollectionField)
        .where(CollectionField.id == field_id)
        .where(CollectionField.collection_id == collection_id)
        .where(CollectionField.user_id == user_id)
    )
    field = result.scalar_one_or_none()
    if not field:
        return False
    await db.delete(field)
    logger.info("collection_field_deleted collection=%s field=%s", collection_id, field_id)
    return True


# --- Item CRUD ---

async def get_item(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    item_id: uuid.UUID,
) -> CollectionItem | None:
    result = await db.execute(
        select(CollectionItem)
        .where(CollectionItem.id == item_id)
        .where(CollectionItem.collection_id == collection_id)
        .where(CollectionItem.user_id == user_id)
    )
    return result.scalar_one_or_none()


def _parse_filters(filter_str: str, allowed_fields: set[str] | None = None) -> list:
    """Parse filter string like 'category:Work,rating:gte:4' into JSONB conditions.

    If allowed_fields is provided, only those field names are accepted.
    """
    conditions = []
    for part in filter_str.split(","):
        part = part.strip()
        if not part:
            continue
        tokens = part.split(":", 2)
        if len(tokens) == 2:
            field, value = tokens
            if allowed_fields and field not in allowed_fields:
                continue
            conditions.append(CollectionItem.data[field].astext == value)
        elif len(tokens) == 3:
            field, op, value = tokens
            if allowed_fields and field not in allowed_fields:
                continue
            json_val = CollectionItem.data[field].astext
            if op == "gte":
                conditions.append(cast(json_val, Float) >= float(value))
            elif op == "lte":
                conditions.append(cast(json_val, Float) <= float(value))
            elif op == "gt":
                conditions.append(cast(json_val, Float) > float(value))
            elif op == "lt":
                conditions.append(cast(json_val, Float) < float(value))
            elif op == "contains":
                conditions.append(json_val.ilike(f"%{value}%"))
    return conditions


async def list_items(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    *,
    search: str | None = None,
    filter_str: str | None = None,
    status: str | None = None,
    sort_by: str | None = None,
    sort_dir: str = "desc",
    limit: int = 25,
    offset: int = 0,
) -> list[CollectionItem]:
    filters = [
        CollectionItem.collection_id == collection_id,
        CollectionItem.user_id == user_id,
    ]
    if status:
        filters.append(CollectionItem.status == status)
    if search:
        filters.append(
            cast(CollectionItem.data, Text).ilike(f"%{search}%")
        )
    if filter_str:
        filters.extend(_parse_filters(filter_str))

    stmt = select(CollectionItem)
    for f in filters:
        stmt = stmt.where(f)

    if sort_by:
        order_expr = CollectionItem.data[sort_by].astext
        stmt = stmt.order_by(order_expr.desc() if sort_dir == "desc" else order_expr.asc())
    else:
        stmt = stmt.order_by(CollectionItem.created_at.desc())

    stmt = stmt.limit(limit).offset(offset)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_items(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    *,
    search: str | None = None,
    filter_str: str | None = None,
    status: str | None = None,
) -> int:
    filters = [
        CollectionItem.collection_id == collection_id,
        CollectionItem.user_id == user_id,
    ]
    if status:
        filters.append(CollectionItem.status == status)
    if search:
        filters.append(
            cast(CollectionItem.data, Text).ilike(f"%{search}%")
        )
    if filter_str:
        filters.extend(_parse_filters(filter_str))
    stmt = select(func.count()).select_from(CollectionItem)
    for f in filters:
        stmt = stmt.where(f)
    return await db.scalar(stmt) or 0


async def create_item(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    data: CollectionItemCreate,
) -> CollectionItem:
    collection = await get_collection(db, user_id, collection_id)
    if not collection:
        raise ValueError("Collection not found")

    # Validate data against schema
    fields = await list_fields(db, user_id, collection_id)
    errors = _validate_item_data(data.data, fields)
    if errors:
        raise ValueError("; ".join(errors))

    item = CollectionItem(
        collection_id=collection_id,
        user_id=user_id,
        data=data.data,
        status=data.status or "active",
        tags=data.tags or [],
        notes=data.notes,
        session_id=data.session_id,
    )
    db.add(item)

    # Increment item count
    collection.item_count = (collection.item_count or 0) + 1

    await db.flush()
    logger.info("collection_item_created collection=%s item=%s", collection_id, item.id)
    schedule_indexing("collection_item", item.id, _item_index_text(item))
    return item


async def update_item(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    item_id: uuid.UUID,
    data: CollectionItemUpdate,
) -> CollectionItem | None:
    item = await get_item(db, user_id, collection_id, item_id)
    if not item:
        return None

    updated = data.model_dump(exclude_unset=True)

    # Validate data if provided
    if "data" in updated and updated["data"] is not None:
        fields = await list_fields(db, user_id, collection_id)
        errors = _validate_item_data(updated["data"], fields)
        if errors:
            raise ValueError("; ".join(errors))

    for k, v in updated.items():
        setattr(item, k, v)
    logger.info("collection_item_updated collection=%s item=%s", collection_id, item_id)
    schedule_indexing("collection_item", item.id, _item_index_text(item))
    return item


async def delete_item(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
    item_id: uuid.UUID,
) -> bool:
    item = await get_item(db, user_id, collection_id, item_id)
    if not item:
        return False

    # Decrement item count
    collection = await get_collection(db, user_id, collection_id)
    if collection and collection.item_count > 0:
        collection.item_count -= 1

    await delete_entity_embedding(db, "collection_item", item.id)
    await db.delete(item)
    logger.info("collection_item_deleted collection=%s item=%s", collection_id, item_id)
    return True


async def get_collection_stats(
    db: AsyncSession,
    user_id: uuid.UUID,
    collection_id: uuid.UUID,
) -> dict:
    """Compute aggregation stats for a collection's items."""
    collection = await get_collection(db, user_id, collection_id)
    if not collection:
        raise KeyError("Collection not found")

    fields = await list_fields(db, user_id, collection_id)

    # Total items
    total = await count_items(db, user_id, collection_id)

    # Status breakdown
    status_result = await db.execute(
        select(CollectionItem.status, func.count())
        .where(CollectionItem.collection_id == collection_id, CollectionItem.user_id == user_id)
        .group_by(CollectionItem.status)
    )
    by_status = {row[0]: row[1] for row in status_result}

    # Per-field stats
    by_field: dict[str, Any] = {}
    for f in fields:
        if f.field_type == "select":
            result = await db.execute(
                select(CollectionItem.data[f.name].astext, func.count())
                .where(
                    CollectionItem.collection_id == collection_id,
                    CollectionItem.user_id == user_id,
                    CollectionItem.data[f.name].astext.isnot(None),
                    CollectionItem.data[f.name].astext != "",
                )
                .group_by(CollectionItem.data[f.name].astext)
            )
            by_field[f.name] = {row[0]: row[1] for row in result}
        elif f.field_type == "number":
            result = await db.execute(
                select(
                    func.min(cast(CollectionItem.data[f.name].astext, Float)),
                    func.max(cast(CollectionItem.data[f.name].astext, Float)),
                    func.avg(cast(CollectionItem.data[f.name].astext, Float)),
                )
                .where(
                    CollectionItem.collection_id == collection_id,
                    CollectionItem.user_id == user_id,
                    CollectionItem.data[f.name].astext.isnot(None),
                    CollectionItem.data[f.name].astext != "",
                )
            )
            row = result.one()
            if row[0] is not None:
                by_field[f.name] = {"min": row[0], "max": row[1], "avg": round(row[2], 2) if row[2] else None}
        elif f.field_type == "boolean":
            result = await db.execute(
                select(CollectionItem.data[f.name].astext, func.count())
                .where(
                    CollectionItem.collection_id == collection_id,
                    CollectionItem.user_id == user_id,
                )
                .group_by(CollectionItem.data[f.name].astext)
            )
            by_field[f.name] = {row[0]: row[1] for row in result}

    return {"total_items": total, "by_status": by_status, "by_field": by_field}
