"""Telegram integration service: validate bot token and create ConnectedAccount."""
import logging
import uuid

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models.integrations import ConnectedAccount
from percona.services.oauth_service import encrypt_token

logger = logging.getLogger(__name__)


async def validate_bot_token(bot_token: str) -> dict:
    """Call Telegram getMe API to validate the bot token. Returns bot info dict."""
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"https://api.telegram.org/bot{bot_token}/getMe")
        data = r.json()
    if not data.get("ok"):
        raise ValueError(f"Invalid bot token: {data.get('description', 'unknown error')}")
    return data["result"]


async def connect_telegram_bot(
    db: AsyncSession,
    user_id: uuid.UUID,
    bot_token: str,
    chat_id: int | None = None,
) -> ConnectedAccount:
    """Validate a Telegram bot token and create (or update) a ConnectedAccount."""
    bot_info = await validate_bot_token(bot_token)

    bot_username = f"@{bot_info.get('username', 'telegram_bot')}"
    bot_id = str(bot_info.get("id", ""))

    # If this bot is already connected for this user, update it
    existing = (await db.execute(
        select(ConnectedAccount).where(
            ConnectedAccount.user_id == user_id,
            ConnectedAccount.provider == "telegram",
            ConnectedAccount.provider_account_id == bot_id,
        )
    )).scalar_one_or_none()

    if existing:
        existing.access_token = encrypt_token(bot_token)
        if chat_id is not None:
            existing.provider_metadata = {**existing.provider_metadata, "chat_id": chat_id}
        existing.status = "active"
        existing.label = bot_info.get("first_name", "Telegram Bot")
        existing.provider_email = bot_username
        await db.flush()
        return existing

    account = ConnectedAccount(
        user_id=user_id,
        provider="telegram",
        label=bot_info.get("first_name", "Telegram Bot"),
        provider_email=bot_username,
        provider_account_id=bot_id,
        scopes=[],
        access_token=encrypt_token(bot_token),
        token_type="bot",
        status="active",
        provider_metadata={"chat_id": chat_id} if chat_id is not None else {},
    )
    db.add(account)
    await db.flush()
    return account
