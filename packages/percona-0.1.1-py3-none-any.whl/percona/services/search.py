import asyncio
import logging
import uuid
from dataclasses import dataclass

from sqlalchemy import text

from percona.database import async_session_factory

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _FTSConfig:
    table: str
    tsvector_expr: str  # SQL fragment — not user input, safe for text() format substitution


_ENTITY_FTS: dict[str, _FTSConfig] = {
    "incident":  _FTSConfig("incidents",  "to_tsvector('english', title || ' ' || COALESCE(summary, '') || ' ' || COALESCE(root_cause_html, ''))"),
    "finding":   _FTSConfig("findings",   "to_tsvector('english', title || ' ' || COALESCE(summary, '') || ' ' || COALESCE(recommendation, ''))"),
    "memory":    _FTSConfig("memories",   "to_tsvector('english', entity_type || ' ' || entity_key || ' ' || key || ' ' || COALESCE(value, ''))"),
}

# Text columns to fetch per entity type for reranking input
_RERANK_TEXT_SQL: dict[str, str] = {
    "incident":  "SELECT id, title || ' ' || COALESCE(summary, '') AS doc FROM incidents WHERE id = ANY(:ids)",
    "finding":   "SELECT id, title || ' ' || COALESCE(summary, '') AS doc FROM findings WHERE id = ANY(:ids)",
    "memory":    "SELECT id, entity_type || ' ' || entity_key || ' ' || key || ' ' || COALESCE(value, '') AS doc FROM memories WHERE id = ANY(:ids)",
}

_RRF_K = 60

_reranker = None
RERANK_MIN_CANDIDATES = 5
_RERANK_WORD_LIMIT = 400


async def semantic_search(entity_type: str, query: str, limit: int = 50) -> list[uuid.UUID]:
    """
    HNSW cosine search over entity_embeddings for a given entity_type.
    Chunk-aware: groups by entity_id, takes the best (min) distance per entity.
    Returns list[uuid.UUID] — caller applies .where(Model.id.in_(ids)).
    """
    try:
        from percona.services.embeddings import embed_query_async  # local import — avoids circular
        vec = await embed_query_async(query)
        vec_str = f"[{','.join(str(x) for x in vec)}]"
        async with async_session_factory() as db:
            result = await db.execute(
                text("""
                    SELECT entity_id, MIN(embedding <=> CAST(:query_vec AS vector)) AS min_dist
                    FROM entity_embeddings
                    WHERE entity_type = :entity_type
                    GROUP BY entity_id
                    ORDER BY min_dist ASC
                    LIMIT :limit
                """),
                {"entity_type": entity_type, "query_vec": vec_str, "limit": limit},
            )
            return [row[0] for row in result.fetchall()]
    except Exception:
        logger.exception("semantic_search_failed entity_type=%s", entity_type)
        return []


async def bm25_search(entity_type: str, keyword: str, limit: int = 50) -> list[uuid.UUID]:
    """Full-text BM25 search via PostgreSQL tsvector. Centralized for all entity types."""
    cfg = _ENTITY_FTS.get(entity_type)
    if not cfg:
        logger.warning("bm25_search_unknown_entity_type entity_type=%s", entity_type)
        return []
    try:
        # cfg.table and cfg.tsvector_expr are hardcoded constants — not user input (SQL injection safe)
        sql = text(f"""
            SELECT id FROM {cfg.table}
            WHERE {cfg.tsvector_expr} @@ websearch_to_tsquery('english', :kw)
            ORDER BY ts_rank_cd({cfg.tsvector_expr}, websearch_to_tsquery('english', :kw)) DESC
            LIMIT :limit
        """)
        async with async_session_factory() as db:
            result = await db.execute(sql, {"kw": keyword, "limit": limit})
            return [row[0] for row in result.fetchall()]
    except Exception:
        logger.exception("bm25_search_failed entity_type=%s", entity_type)
        return []


async def hybrid_search(entity_type: str, query: str, limit: int = 50) -> list[uuid.UUID]:
    """Reciprocal Rank Fusion of semantic + BM25 search results."""
    try:
        fetch = limit * 2
        semantic_ids, bm25_ids = await asyncio.gather(
            semantic_search(entity_type, query, limit=fetch),
            bm25_search(entity_type, query, limit=fetch),
        )
        scores: dict[uuid.UUID, float] = {}
        for rank, uid in enumerate(semantic_ids):
            scores[uid] = scores.get(uid, 0.0) + 1.0 / (_RRF_K + rank + 1)
        for rank, uid in enumerate(bm25_ids):
            scores[uid] = scores.get(uid, 0.0) + 1.0 / (_RRF_K + rank + 1)
        return sorted(scores, key=scores.__getitem__, reverse=True)[:limit]
    except Exception:
        logger.exception("hybrid_search_failed entity_type=%s", entity_type)
        return []


def _get_reranker():
    global _reranker
    if _reranker is None:
        from fastembed.rerank.cross_encoder import TextCrossEncoder
        logger.info("loading_reranker model=mixedbread-ai/mxbai-rerank-base-v1")
        _reranker = TextCrossEncoder("mixedbread-ai/mxbai-rerank-base-v1", cache_dir="/tmp/fastembed_cache")
    return _reranker


async def rerank(query: str, candidates: list[uuid.UUID], entity_type: str, limit: int | None = None) -> list[uuid.UUID]:
    """Cross-encoder reranking. Falls back to original order on any error."""
    if len(candidates) <= RERANK_MIN_CANDIDATES:
        return candidates[:limit] if limit else candidates
    try:
        sql = _RERANK_TEXT_SQL.get(entity_type)
        if not sql:
            return candidates[:limit] if limit else candidates
        async with async_session_factory() as db:
            result = await db.execute(text(sql), {"ids": [str(c) for c in candidates]})
            rows = {uuid.UUID(str(row[0])): row[1] for row in result.fetchall()}
        # Preserve candidate order for missing rows; truncate doc text
        docs = [" ".join((rows.get(c) or "").split()[:_RERANK_WORD_LIMIT]) for c in candidates]
        loop = asyncio.get_event_loop()
        scores = await loop.run_in_executor(None, lambda: list(_get_reranker().rerank(query, docs)))
        scored = sorted(zip(candidates, scores), key=lambda x: x[1], reverse=True)
        result_ids = [uid for uid, _ in scored]
        return result_ids[:limit] if limit else result_ids
    except Exception:
        logger.exception("rerank_failed entity_type=%s", entity_type)
        return candidates[:limit] if limit else candidates
