"""WhatsApp pairing service — Redis state machine for QR-based device linking.

Flow:
1. Frontend calls start_pairing() → generates pair_id, tells adapter to connect
2. Neonize fires QRCodeEv → adapter writes QR PNG to Redis
3. Frontend polls get_pair_status() → receives QR data to display
4. User scans QR → neonize fires ConnectedEv → adapter writes "connected" to Redis
5. Adapter creates ConnectedAccount via create_whatsapp_account()
"""
import base64
import io
import logging
import uuid
from uuid import UUID

import qrcode
import redis.asyncio as aioredis
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from percona.config import settings
from percona.models.integrations import ConnectedAccount
from percona.models.notifications import NotificationChannel, NotificationChannelType
from percona.services.oauth_service import encrypt_token

logger = logging.getLogger(__name__)

_PAIR_TTL = 120  # seconds — QR codes expire quickly anyway

# Lazy Redis pool
_redis_pool: aioredis.Redis | None = None

# Module-level adapter reference — set by WhatsAppAdapter.start()
_adapter_ref = None


def set_adapter(adapter) -> None:
    """Called by WhatsAppAdapter at startup so notification_service can send messages."""
    global _adapter_ref
    _adapter_ref = adapter


def get_adapter():
    """Return the active WhatsAppAdapter instance, or None if not started."""
    return _adapter_ref


def _get_redis() -> aioredis.Redis:
    global _redis_pool
    if _redis_pool is None:
        _redis_pool = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _redis_pool


def _key(pair_id: str, field: str) -> str:
    return f"whatsapp:pair:{pair_id}:{field}"


def qr_to_base64(data: str) -> str:
    """Render a QR code string as a base64-encoded PNG."""
    img = qrcode.make(data)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def start_pairing(user_id: UUID) -> str:
    """Begin a new WhatsApp pairing session. Returns pair_id."""
    pair_id = str(uuid.uuid4())
    r = _get_redis()
    pipe = r.pipeline()
    pipe.set(_key(pair_id, "status"), "waiting_qr", ex=_PAIR_TTL)
    pipe.set(_key(pair_id, "user_id"), str(user_id), ex=_PAIR_TTL)
    await pipe.execute()

    logger.info("whatsapp_pairing_started pair_id=%s user_id=%s", pair_id, user_id)
    return pair_id


async def set_qr(pair_id: str, qr_string: str) -> None:
    """Called by adapter when neonize fires QRCodeEv."""
    r = _get_redis()
    qr_b64 = qr_to_base64(qr_string)
    pipe = r.pipeline()
    pipe.set(_key(pair_id, "status"), "qr", ex=_PAIR_TTL)
    pipe.set(_key(pair_id, "qr"), qr_b64, ex=_PAIR_TTL)
    await pipe.execute()
    logger.debug("whatsapp_qr_set pair_id=%s qr_len=%s", pair_id, len(qr_b64))


async def set_connected(pair_id: str, jid: str) -> None:
    """Called by adapter when neonize fires ConnectedEv during pairing."""
    r = _get_redis()
    pipe = r.pipeline()
    pipe.set(_key(pair_id, "status"), "connected", ex=_PAIR_TTL)
    pipe.set(_key(pair_id, "jid"), jid, ex=_PAIR_TTL)
    await pipe.execute()
    logger.info("whatsapp_pairing_connected pair_id=%s jid=%s", pair_id, jid)


async def set_error(pair_id: str, error: str) -> None:
    """Called by adapter on pairing failure."""
    r = _get_redis()
    pipe = r.pipeline()
    pipe.set(_key(pair_id, "status"), "error", ex=_PAIR_TTL)
    pipe.set(_key(pair_id, "error"), error, ex=_PAIR_TTL)
    await pipe.execute()
    logger.warning("whatsapp_pairing_error pair_id=%s error=%s", pair_id, error)


async def get_pair_status(pair_id: str) -> dict:
    """Return current pairing state from Redis."""
    r = _get_redis()
    status = await r.get(_key(pair_id, "status"))
    if status is None:
        return {"status": "expired"}

    result: dict = {"status": status}
    if status == "qr":
        result["qr_data"] = await r.get(_key(pair_id, "qr"))
    elif status == "connected":
        result["jid"] = await r.get(_key(pair_id, "jid"))
    elif status == "error":
        result["error"] = await r.get(_key(pair_id, "error"))
    return result


async def get_pair_user_id(pair_id: str) -> UUID | None:
    """Return the user_id for a pairing session."""
    r = _get_redis()
    val = await r.get(_key(pair_id, "user_id"))
    return UUID(val) if val else None


async def cancel_pairing(pair_id: str) -> None:
    """Clean up Redis keys for a cancelled pairing."""
    r = _get_redis()
    keys = [_key(pair_id, f) for f in ("status", "qr", "jid", "user_id", "error")]
    await r.delete(*keys)
    logger.info("whatsapp_pairing_cancelled pair_id=%s", pair_id)


async def create_whatsapp_account(
    db: AsyncSession,
    user_id: UUID,
    jid: str,
) -> ConnectedAccount:
    """Create a ConnectedAccount for a paired WhatsApp device.

    Uses encrypt_token() for the placeholder access_token to satisfy NOT NULL.
    """
    # Check if account already exists for this JID
    existing = (await db.execute(
        select(ConnectedAccount).where(
            ConnectedAccount.provider == "whatsapp",
            ConnectedAccount.provider_account_id == jid,
        )
    )).scalar_one_or_none()

    if existing:
        existing.status = "active"
        existing.error_message = None
        existing.user_id = user_id
        await db.flush()
        logger.info("whatsapp_account_reactivated account_id=%s jid=%s", existing.id, jid)
        return existing

    account = ConnectedAccount(
        user_id=user_id,
        provider="whatsapp",
        provider_email=jid,
        provider_account_id=jid,
        access_token=encrypt_token("neonize-managed"),
        scopes=[],
        status="active",
        provider_metadata={
            "whatsapp_jid": jid,
            "allowed_jids": [],
            "default_agent_type": "claude-code",
            "default_system_prompt": "You are a helpful DevOps assistant.",
        },
    )
    db.add(account)
    await db.flush()
    logger.info("whatsapp_account_created account_id=%s jid=%s user_id=%s", account.id, jid, user_id)

    # Auto-create a default notification channel targeting the paired JID.
    # Strip device suffix (e.g. "123456:12@s.whatsapp.net" → "123456@s.whatsapp.net")
    user_part = jid.split("@")[0].split(":")[0]
    server_part = jid.split("@")[1] if "@" in jid else "s.whatsapp.net"
    clean_jid = f"{user_part}@{server_part}"
    await db.execute(
        pg_insert(NotificationChannel)
        .values(
            user_id=user_id,
            name=f"WhatsApp {user_part}",
            channel_type=NotificationChannelType.WHATSAPP,
            config={"jid": clean_jid},
            enabled=True,
        )
        .on_conflict_do_nothing()
    )
    logger.info("whatsapp_notification_channel_created jid=%s user_id=%s", jid, user_id)

    return account
