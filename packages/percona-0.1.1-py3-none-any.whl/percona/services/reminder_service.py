"""Reminder service — CRUD operations and delivery via configured channels."""
import uuid
import logging
import time
from datetime import date, datetime, timezone

import httpx
from sqlalchemy import cast, select, Date
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models import ProjectSettings, Reminder
from percona.services.notification import send_email_notification, send_pushover_notification

logger = logging.getLogger(__name__)


async def _deliver_slack(db: AsyncSession, reminder) -> str | None:
    """Send to Slack. Returns error string on failure, None on success."""
    logger.debug("reminder_slack_start id=%s name=%s", reminder.id, reminder.name)

    ps_result = await db.execute(
        select(ProjectSettings).where(ProjectSettings.user_id == reminder.user_id)
    )
    ps = ps_result.scalar_one_or_none()
    webhook_url = ps.slack_webhook_url if ps else None
    if not webhook_url:
        logger.warning("reminder_slack_skipped id=%s reason=no_webhook_configured", reminder.id)
        return None  # Not a failure — just unconfigured

    blocks = [
        {"type": "header", "text": {"type": "plain_text", "text": f"Reminder: {reminder.name}", "emoji": True}},
        {"type": "section", "text": {"type": "mrkdwn", "text": (reminder.description or "_No description_")[:3000]}},
    ]
    t0 = time.monotonic()
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(webhook_url, json={"blocks": blocks}, timeout=10)
            resp.raise_for_status()
        elapsed = int((time.monotonic() - t0) * 1000)
        logger.info(
            "reminder_slack_sent id=%s name=%s status_code=%s elapsed_ms=%d",
            reminder.id, reminder.name, resp.status_code, elapsed,
        )
        return None
    except httpx.HTTPStatusError as e:
        elapsed = int((time.monotonic() - t0) * 1000)
        logger.error(
            "reminder_slack_http_error id=%s name=%s status=%s body=%s elapsed_ms=%d",
            reminder.id, reminder.name, e.response.status_code,
            e.response.text[:500], elapsed,
        )
        return f"slack HTTP {e.response.status_code}"
    except httpx.TimeoutException:
        elapsed = int((time.monotonic() - t0) * 1000)
        logger.error("reminder_slack_timeout id=%s name=%s elapsed_ms=%d", reminder.id, reminder.name, elapsed)
        return "slack timeout"
    except Exception as e:
        elapsed = int((time.monotonic() - t0) * 1000)
        logger.exception("reminder_slack_failed id=%s name=%s error=%s elapsed_ms=%d", reminder.id, reminder.name, e, elapsed)
        return f"slack error: {type(e).__name__}"


async def _deliver_pushover(db: AsyncSession, reminder) -> str | None:
    """Send via Pushover. Returns error string on failure, None on success."""
    logger.debug("reminder_pushover_start id=%s name=%s", reminder.id, reminder.name)

    ps_result = await db.execute(
        select(ProjectSettings).where(ProjectSettings.user_id == reminder.user_id)
    )
    ps = ps_result.scalar_one_or_none()
    token = ps.pushover_token if ps else None
    user = ps.pushover_user if ps else None
    if not token or not user:
        missing = [k for k, v in [("pushover_token", token), ("pushover_user", user)] if not v]
        logger.warning(
            "reminder_pushover_skipped id=%s reason=missing_credentials missing=%s",
            reminder.id, missing,
        )
        return None  # Unconfigured — not a delivery failure

    title = reminder.name[:250]
    message = (reminder.description or "")[:1024]
    t0 = time.monotonic()
    try:
        ok, _err = await send_pushover_notification(token=token, user=user, title=title, message=message)
        elapsed = int((time.monotonic() - t0) * 1000)
        if ok:
            logger.info(
                "reminder_pushover_sent id=%s name=%s elapsed_ms=%d",
                reminder.id, reminder.name, elapsed,
            )
            return None
        else:
            logger.error(
                "reminder_pushover_api_rejected id=%s name=%s elapsed_ms=%d",
                reminder.id, reminder.name, elapsed,
            )
            return _err or "pushover API rejected"
    except Exception as e:
        elapsed = int((time.monotonic() - t0) * 1000)
        logger.exception(
            "reminder_pushover_failed id=%s name=%s error=%s elapsed_ms=%d",
            reminder.id, reminder.name, e, elapsed,
        )
        return f"pushover error: {type(e).__name__}"


async def _deliver_email(db: AsyncSession, reminder) -> str | None:
    """Send via email. Returns error string on failure, None on success."""
    logger.debug("reminder_email_start id=%s name=%s", reminder.id, reminder.name)

    ps_result = await db.execute(
        select(ProjectSettings).where(ProjectSettings.user_id == reminder.user_id)
    )
    ps = ps_result.scalar_one_or_none()
    recipients_str = ps.email_recipients if ps else None
    if not recipients_str:
        logger.warning("reminder_email_skipped id=%s reason=no_recipients_configured", reminder.id)
        return None  # Unconfigured — not a delivery failure

    recipients = [r.strip() for r in recipients_str.split(",") if r.strip()]
    if not recipients:
        logger.warning("reminder_email_skipped id=%s reason=empty_recipients_list", reminder.id)
        return None

    logger.debug("reminder_email_recipients id=%s count=%d", reminder.id, len(recipients))
    finding = {
        "title": reminder.name,
        "summary": reminder.description or "",
        "severity": "info",
        "finding_type": "recommendation",
    }
    t0 = time.monotonic()
    try:
        ok, _err = send_email_notification(
            recipients=recipients,
            finding=finding,
            session_id=None,
            task_name="Reminder",
        )
        elapsed = int((time.monotonic() - t0) * 1000)
        if ok:
            logger.info(
                "reminder_email_sent id=%s name=%s recipients=%d elapsed_ms=%d",
                reminder.id, reminder.name, len(recipients), elapsed,
            )
            return None
        else:
            logger.error(
                "reminder_email_smtp_failed id=%s name=%s recipients=%d elapsed_ms=%d",
                reminder.id, reminder.name, len(recipients), elapsed,
            )
            return _err or "email SMTP send failed"
    except Exception as e:
        elapsed = int((time.monotonic() - t0) * 1000)
        logger.exception(
            "reminder_email_failed id=%s name=%s error=%s elapsed_ms=%d",
            reminder.id, reminder.name, e, elapsed,
        )
        return f"email error: {type(e).__name__}"


async def deliver_reminder(db: AsyncSession, reminder) -> tuple[bool, str | None]:
    """Deliver a reminder via all configured channels.

    Each channel is attempted independently — a failure in one does not
    prevent delivery to others.

    Returns:
        (overall_success, error_message_or_None)
        overall_success is True only if every requested channel either
        succeeded or was simply unconfigured (not a delivery error).
    """
    t_total = time.monotonic()
    channels = reminder.channels or []
    logger.info(
        "deliver_reminder_start id=%s name=%s channels=%s",
        reminder.id, reminder.name, channels,
    )

    if not channels:
        logger.warning("deliver_reminder_no_channels id=%s name=%s", reminder.id, reminder.name)
        return True, None

    CHANNEL_HANDLERS = {
        "slack": _deliver_slack,
        "pushover": _deliver_pushover,
        "email": _deliver_email,
    }

    errors: list[str] = []
    for channel in channels:
        handler = CHANNEL_HANDLERS.get(channel)
        if handler is None:
            logger.warning("deliver_reminder_unknown_channel id=%s channel=%s", reminder.id, channel)
            continue
        error = await handler(db, reminder)
        if error:
            errors.append(error)

    elapsed = int((time.monotonic() - t_total) * 1000)
    success = len(errors) == 0

    if success:
        logger.info(
            "deliver_reminder_ok id=%s name=%s channels=%s elapsed_ms=%d",
            reminder.id, reminder.name, channels, elapsed,
        )
    else:
        logger.error(
            "deliver_reminder_partial_failure id=%s name=%s channels=%s errors=%s elapsed_ms=%d",
            reminder.id, reminder.name, channels, errors, elapsed,
        )

    error_msg = f"Failed: {'; '.join(errors)}" if errors else None
    return success, error_msg


# ---------------------------------------------------------------------------
# CRUD operations (used by MCP tool and API routes)
# ---------------------------------------------------------------------------

VALID_CHANNELS = {"email", "slack", "pushover"}


async def create_reminder(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    name: str,
    description: str | None = None,
    channels: list[str],
    scheduled_at: datetime | None = None,
    extra_schedules: list[str] | None = None,
    session_id: uuid.UUID | None = None,
) -> Reminder:
    """Create a new reminder.

    If scheduled_at is None or in the past, the caller should dispatch
    immediate delivery after committing.

    extra_schedules: list of ISO8601 strings for additional trigger times
    after the first. The worker will reschedule the reminder for each
    remaining time instead of marking it sent.
    """
    now = datetime.now(timezone.utc)
    send_now = scheduled_at is None or scheduled_at <= now

    r = Reminder(
        name=name,
        description=description,
        channels=channels,
        scheduled_at=None if send_now else scheduled_at,
        extra_schedules=extra_schedules or None,
        session_id=session_id,
        status="pending",
        user_id=user_id,
    )
    db.add(r)
    await db.flush()
    logger.info("reminder_created id=%s name=%s send_now=%s extra_schedules=%s", r.id, name, send_now, len(extra_schedules or []))
    return r


async def list_reminders(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    status: str | None = None,
    scheduled_date: date | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[Reminder]:
    stmt = (
        select(Reminder)
        .where(Reminder.user_id == user_id)
        .order_by(Reminder.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    if status:
        stmt = stmt.where(Reminder.status == status)
    if scheduled_date:
        stmt = stmt.where(cast(Reminder.scheduled_at, Date) == scheduled_date)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_reminder(
    db: AsyncSession,
    user_id: uuid.UUID,
    reminder_id: uuid.UUID,
) -> Reminder | None:
    result = await db.execute(
        select(Reminder)
        .where(Reminder.id == reminder_id)
        .where(Reminder.user_id == user_id)
    )
    return result.scalar_one_or_none()


async def update_reminder(
    db: AsyncSession,
    user_id: uuid.UUID,
    reminder_id: uuid.UUID,
    *,
    name: str | None = None,
    description: str | None = None,
    channels: list[str] | None = None,
    scheduled_at: datetime | None = ...,  # type: ignore[assignment]
) -> Reminder | None:
    """Update a pending reminder. Returns None if not found or not pending.

    Pass scheduled_at=None to clear the schedule.
    Sentinel default (Ellipsis) means 'do not change'.
    """
    r = await get_reminder(db, user_id, reminder_id)
    if not r:
        return None
    if r.status != "pending":
        return None
    if name:
        r.name = name
    if description is not None:
        r.description = description
    if channels:
        r.channels = channels
    if scheduled_at is not ...:
        r.scheduled_at = scheduled_at
    logger.info("reminder_updated id=%s", reminder_id)
    return r


async def cancel_reminder(
    db: AsyncSession,
    user_id: uuid.UUID,
    reminder_id: uuid.UUID,
) -> Reminder | None:
    """Cancel a pending reminder. Returns None if not found or not pending."""
    r = await get_reminder(db, user_id, reminder_id)
    if not r:
        return None
    if r.status != "pending":
        return None
    r.status = "cancelled"
    logger.info("reminder_cancelled id=%s", reminder_id)
    return r


async def count_reminders(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    status: str | None = None,
    scheduled_date: date | None = None,
) -> int:
    """Count reminders matching the given filters."""
    from sqlalchemy import func
    stmt = select(func.count()).select_from(Reminder).where(Reminder.user_id == user_id)
    if status:
        stmt = stmt.where(Reminder.status == status)
    if scheduled_date:
        stmt = stmt.where(cast(Reminder.scheduled_at, Date) == scheduled_date)
    result = await db.scalar(stmt)
    return result or 0


async def delete_reminder(
    db: AsyncSession,
    user_id: uuid.UUID,
    reminder_id: uuid.UUID,
) -> Reminder | None:
    """Delete or cancel a reminder.

    If pending, cancels it. Otherwise, deletes it.
    Returns the reminder if found, None otherwise.
    """
    r = await get_reminder(db, user_id, reminder_id)
    if not r:
        return None
    if r.status == "pending":
        r.status = "cancelled"
        logger.info("reminder_cancelled id=%s", reminder_id)
    else:
        await db.delete(r)
        logger.info("reminder_deleted id=%s", reminder_id)
    return r


async def send_reminder_now(
    db: AsyncSession,
    user_id: uuid.UUID,
    reminder_id: uuid.UUID,
) -> Reminder | None:
    """Mark a pending reminder for immediate sending.

    Returns the reminder if found and pending, None otherwise.
    The caller should commit and then dispatch the Celery task.
    """
    r = await get_reminder(db, user_id, reminder_id)
    if not r:
        return None
    if r.status != "pending":
        return None
    logger.info("reminder_force_sent id=%s", reminder_id)
    return r
