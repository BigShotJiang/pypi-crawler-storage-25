import json
import logging
from typing import Any, Optional, Tuple
import redis

logger = logging.getLogger(__name__)

class IdempotencyService:
    """Service to handle API-level idempotency using Redis caching."""

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.prefix = "idempotency:"

    async def get_cached_response(self, key: str) -> Tuple[bool, Optional[dict]]:
        """
        Check if a response is already cached for this key.
        Returns (is_duplicate, cached_data).
        """
        cache_key = f"{self.prefix}{key}"
        data = self.redis.get(cache_key)
        if data:
            logger.info("idempotency_cache_hit key=%s", key)
            return True, json.loads(data)
        return False, None

    async def cache_response(self, key: str, response_data: dict, ttl_seconds: int = 86400):
        """
        Store the response in Redis with a 24h default TTL.
        """
        cache_key = f"{self.prefix}{key}"
        self.redis.setex(cache_key, ttl_seconds, json.dumps(response_data))
        logger.debug("idempotency_cached key=%s", key)

    async def reserve_key(self, key: str, ttl_seconds: int = 60) -> bool:
        """
        Try to reserve a key to prevent concurrent requests with the same key.
        This acts as a short-term lock.
        """
        lock_key = f"{self.prefix}lock:{key}"
        return bool(self.redis.set(lock_key, "1", nx=True, ex=ttl_seconds))

    async def release_reservation(self, key: str):
        """Release the short-term lock."""
        lock_key = f"{self.prefix}lock:{key}"
        self.redis.delete(lock_key)
