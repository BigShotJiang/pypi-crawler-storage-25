import logging
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models.collections import Collection, CollectionField
from percona.services.collection_service import _generate_slug, get_collection_by_slug, list_fields

logger = logging.getLogger(__name__)

TEMPLATES: dict[str, dict] = {
    "contacts": {
        "name": "Contacts",
        "icon": "\U0001f464",
        "color": "#3b82f6",
        "description": "Personal and professional contacts",
        "agent_instructions": (
            "When adding a contact, always ask for full name and at least one of: phone, email. "
            "If user mentions a company, fill the company field. "
            "Deduplicate by email \u2014 check existing contacts before creating duplicates."
        ),
        "fields": [
            {"name": "full_name", "label": "Full Name", "field_type": "text", "required": True},
            {"name": "phone", "label": "Phone", "field_type": "text"},
            {"name": "email", "label": "Email", "field_type": "email"},
            {"name": "company", "label": "Company", "field_type": "text"},
            {"name": "category", "label": "Category", "field_type": "select", "options": ["Family", "Friend", "Work", "Other"]},
            {"name": "notes", "label": "Notes", "field_type": "textarea"},
        ],
    },
    "journal": {
        "name": "Journal",
        "icon": "\U0001f4d3",
        "color": "#8b5cf6",
        "description": "Daily journal entries and reflections",
        "agent_instructions": (
            "Each journal entry should have today's date, a title, and content. "
            "When user asks to journal, create an entry for today. "
            "If an entry for today already exists, update it instead of creating a duplicate. "
            "Use the mood field to capture emotional tone."
        ),
        "fields": [
            {"name": "date", "label": "Date", "field_type": "date", "required": True},
            {"name": "title", "label": "Title", "field_type": "text", "required": True},
            {"name": "content", "label": "Content", "field_type": "textarea", "required": True},
            {"name": "mood", "label": "Mood", "field_type": "select", "options": ["Great", "Good", "Okay", "Low", "Bad"]},
            {"name": "tags", "label": "Tags", "field_type": "tags"},
        ],
    },
    "habits": {
        "name": "Habits",
        "icon": "\U0001f3af",
        "color": "#10b981",
        "description": "Track daily habits and streaks",
        "agent_instructions": (
            "Each habit log records whether a habit was completed on a given date. "
            "When user says 'I worked out' or similar, log it as a habit completion for today. "
            "Track streaks by checking consecutive completed dates. Report stats when asked."
        ),
        "fields": [
            {"name": "habit_name", "label": "Habit", "field_type": "text", "required": True},
            {"name": "date", "label": "Date", "field_type": "date", "required": True},
            {"name": "completed", "label": "Completed", "field_type": "boolean", "required": True},
            {"name": "value", "label": "Value/Amount", "field_type": "number"},
            {"name": "notes", "label": "Notes", "field_type": "text"},
        ],
    },
    "expenses": {
        "name": "Expenses",
        "icon": "\U0001f4b0",
        "color": "#f59e0b",
        "description": "Track spending, expenses, and income",
        "agent_instructions": (
            "When user mentions spending money, create an expense entry with amount, category, and date (default today). "
            "Always ask for the amount if not mentioned. Default transaction_type to 'expense' unless user mentions income/salary/freelance. "
            "Default currency to EGP unless user specifies otherwise. "
            "Report totals by category when asked for spending summaries. "
            "For summaries, query items filtered by date range, group by category, and split by transaction_type."
        ),
        "fields": [
            {"name": "description", "label": "Description", "field_type": "text", "required": True},
            {"name": "amount", "label": "Amount", "field_type": "number", "required": True},
            {"name": "currency", "label": "Currency", "field_type": "select", "options": ["EGP", "USD", "EUR", "GBP", "SAR"]},
            {"name": "transaction_type", "label": "Type", "field_type": "select", "options": ["expense", "income"]},
            {"name": "category", "label": "Category", "field_type": "select", "options": ["Food", "Transport", "Shopping", "Bills", "Entertainment", "Health", "Education", "Salary", "Freelance", "Other"]},
            {"name": "date", "label": "Date", "field_type": "date", "required": True},
            {"name": "merchant", "label": "Merchant", "field_type": "text"},
            {"name": "location", "label": "Location", "field_type": "text"},
            {"name": "payment_method", "label": "Payment", "field_type": "select", "options": ["Cash", "Card", "Bank Transfer", "Mobile Wallet", "InstaPay", "Vodafone Cash"]},
            {"name": "receipt_url", "label": "Receipt URL", "field_type": "url"},
        ],
    },
}


def get_available_templates() -> list[dict]:
    """Return list of available templates for the API."""
    return [
        {
            "slug": slug,
            "name": tmpl["name"],
            "icon": tmpl["icon"],
            "color": tmpl["color"],
            "description": tmpl["description"],
            "field_count": len(tmpl["fields"]),
        }
        for slug, tmpl in TEMPLATES.items()
    ]


async def create_from_template(
    db: AsyncSession,
    user_id: uuid.UUID,
    template_slug: str,
) -> tuple[Collection | None, bool]:
    """Create a collection from a template. Returns (collection, created).
    Returns (None, False) if template not found.
    Returns (existing, False) if user already has this collection.
    """
    tmpl = TEMPLATES.get(template_slug)
    if not tmpl:
        return None, False

    # Check if user already has this template collection
    existing = await get_collection_by_slug(db, user_id, template_slug)
    if existing:
        return existing, False

    slug = _generate_slug(tmpl["name"])
    # Ensure slug matches template slug for discoverability
    if slug != template_slug:
        slug = template_slug

    collection = Collection(
        name=tmpl["name"],
        slug=slug,
        description=tmpl["description"],
        icon=tmpl["icon"],
        color=tmpl["color"],
        agent_instructions=tmpl["agent_instructions"],
        template_slug=template_slug,
        user_id=user_id,
    )
    db.add(collection)
    await db.flush()

    for i, field_def in enumerate(tmpl["fields"]):
        field = CollectionField(
            collection_id=collection.id,
            user_id=user_id,
            name=field_def["name"],
            label=field_def["label"],
            field_type=field_def["field_type"],
            required=field_def.get("required", False),
            options=field_def.get("options"),
            sort_order=i,
        )
        db.add(field)

    await db.flush()
    logger.info("collection_from_template user=%s template=%s collection=%s", user_id, template_slug, collection.id)
    return collection, True


async def seed_templates_for_user(db: AsyncSession, user_id: uuid.UUID) -> int:
    """Seed all template collections for a user. Returns count created."""
    created = 0
    for slug in TEMPLATES:
        existing = await get_collection_by_slug(db, user_id, slug)
        if not existing:
            _, was_created = await create_from_template(db, user_id, slug)
            if was_created:
                created += 1
    return created


async def upgrade_existing_collections(db: AsyncSession, user_id: uuid.UUID) -> int:
    """Find existing collections matching template slugs and upgrade them.
    Sets template_slug, adds missing fields, sets agent_instructions if empty.
    Returns count upgraded."""
    upgraded = 0
    for slug, tmpl in TEMPLATES.items():
        col = await get_collection_by_slug(db, user_id, slug)
        if not col:
            # Also try matching by name (case-insensitive)
            result = await db.execute(
                select(Collection)
                .where(Collection.user_id == user_id)
                .where(Collection.name.ilike(tmpl["name"]))
            )
            col = result.scalar_one_or_none()

        if not col:
            continue

        changed = False

        if not col.template_slug:
            col.template_slug = slug
            changed = True

        if not col.agent_instructions:
            col.agent_instructions = tmpl["agent_instructions"]
            changed = True

        # Add missing fields
        existing_fields = await list_fields(db, user_id, col.id)
        existing_names = {f.name for f in existing_fields}
        max_order = max((f.sort_order for f in existing_fields), default=-1)

        for field_def in tmpl["fields"]:
            if field_def["name"] not in existing_names:
                max_order += 1
                db.add(CollectionField(
                    collection_id=col.id,
                    user_id=user_id,
                    name=field_def["name"],
                    label=field_def["label"],
                    field_type=field_def["field_type"],
                    required=field_def.get("required", False),
                    options=field_def.get("options"),
                    sort_order=max_order,
                ))
                changed = True

        if changed:
            upgraded += 1
            logger.info("collection_upgraded user=%s collection=%s template=%s", user_id, col.id, slug)

    return upgraded
