"""Artifact service — creates, lists, and deletes workspace archives stored in S3."""
import asyncio
import logging
import shutil
import tempfile
import uuid
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.config import settings
from percona.models.artifacts import Artifact, ArtifactSourceType, ArtifactTrigger
from percona.services import storage

logger = logging.getLogger(__name__)


def _generate_artifact_s3_key() -> str:
    file_uuid = str(uuid.uuid4())
    prefix = settings.s3_key_prefix.rstrip("/")
    return f"{prefix}/artifacts/{file_uuid}.tar.gz"


def _compute_dir_stats(workspace_path: Path) -> tuple[int, int]:
    """Return (file_count, total_bytes) for all files under workspace_path."""
    files = [f for f in workspace_path.rglob("*") if f.is_file()]
    total_bytes = sum(f.stat().st_size for f in files)
    return len(files), total_bytes


def _make_archive(workspace_path: Path, output_path: str) -> str:
    """Create a tar.gz archive of workspace_path at output_path (without extension).
    Returns the actual archive file path created by shutil."""
    return shutil.make_archive(output_path, "gztar", root_dir=str(workspace_path.parent), base_dir=workspace_path.name)


async def create_artifact_from_workspace(
    db: AsyncSession,
    user_id: uuid.UUID,
    workspace_path: str,
    *,
    source_type: ArtifactSourceType,
    session_id: uuid.UUID | None = None,
    conversation_id: uuid.UUID | None = None,
    trigger: ArtifactTrigger = ArtifactTrigger.MANUAL,
) -> Artifact:
    """Compress workspace_path into a tar.gz, upload to S3, persist Artifact record.

    Raises ValueError if workspace does not exist or compressed size exceeds limit.
    """
    ws = Path(workspace_path)
    if not ws.exists() or not ws.is_dir():
        raise ValueError(f"Workspace directory not found: {workspace_path}")

    file_count, original_size_bytes = _compute_dir_stats(ws)
    max_bytes = settings.max_artifact_size_mb * 1024 * 1024

    # Build a short display name for the archive filename
    source_label = str(session_id or conversation_id or "workspace")
    short_id = str(source_label)[:8]
    archive_filename = f"workspace-{short_id}.tar.gz"
    s3_key = _generate_artifact_s3_key()

    with tempfile.TemporaryDirectory() as tmpdir:
        archive_base = str(Path(tmpdir) / "archive")
        archive_path = await asyncio.to_thread(_make_archive, ws, archive_base)
        archive_path = Path(archive_path)

        file_size_bytes = archive_path.stat().st_size
        if file_size_bytes > max_bytes:
            raise ValueError(
                f"Artifact size {file_size_bytes // (1024*1024)}MB exceeds "
                f"limit of {settings.max_artifact_size_mb}MB"
            )

        content = await asyncio.to_thread(archive_path.read_bytes)

    upload_result = await asyncio.to_thread(
        storage.upload_file,
        content,
        archive_filename,
        "application/gzip",
        False,
        s3_key=s3_key,
    )

    artifact = Artifact(
        user_id=user_id,
        source_type=source_type,
        session_id=session_id,
        conversation_id=conversation_id,
        trigger=trigger,
        filename=archive_filename,
        archive_format="tar.gz",
        file_size_bytes=upload_result["file_size_bytes"],
        original_size_bytes=original_size_bytes,
        s3_key=upload_result["s3_key"],
        s3_url=upload_result["s3_url"],
        file_count=file_count,
        workspace_path=workspace_path,
    )
    db.add(artifact)
    await db.flush()
    logger.info(
        "artifact_created artifact_id=%s source_type=%s trigger=%s size_bytes=%s",
        artifact.id, source_type.value, trigger.value, file_size_bytes,
    )
    return artifact


async def list_artifacts(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    session_id: uuid.UUID | None = None,
    conversation_id: uuid.UUID | None = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[Artifact], int]:
    filters = [Artifact.user_id == user_id]
    if session_id:
        filters.append(Artifact.session_id == session_id)
    if conversation_id:
        filters.append(Artifact.conversation_id == conversation_id)

    count_stmt = select(func.count()).select_from(Artifact)
    for f in filters:
        count_stmt = count_stmt.where(f)
    total = await db.scalar(count_stmt) or 0

    stmt = select(Artifact).order_by(Artifact.created_at.desc()).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all()), total


async def get_artifact(
    db: AsyncSession,
    user_id: uuid.UUID,
    artifact_id: uuid.UUID,
) -> Artifact | None:
    result = await db.execute(
        select(Artifact).where(Artifact.id == artifact_id, Artifact.user_id == user_id)
    )
    return result.scalar_one_or_none()


async def delete_artifact(
    db: AsyncSession,
    user_id: uuid.UUID,
    artifact_id: uuid.UUID,
) -> bool:
    artifact = await get_artifact(db, user_id, artifact_id)
    if not artifact:
        return False
    await asyncio.to_thread(storage.delete_file, artifact.s3_key)
    await db.delete(artifact)
    await db.flush()
    logger.info("artifact_deleted artifact_id=%s s3_key=%s", artifact_id, artifact.s3_key)
    return True
