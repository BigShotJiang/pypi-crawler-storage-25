"""MCP server service — encapsulates all MCP server business logic."""
import logging
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models import McpServer

logger = logging.getLogger(__name__)

CORE_MCP_SLUG = "percona"


async def get_default_mcp_ids(db: AsyncSession) -> list[uuid.UUID]:
    """Return the default MCP server IDs for new conversations and tasks.

    Enterprise requirement: do not auto-attach any MCP server; selection must be explicit.
    """
    logger.info("default_mcp_servers_empty selection must be explicit")
    return []
