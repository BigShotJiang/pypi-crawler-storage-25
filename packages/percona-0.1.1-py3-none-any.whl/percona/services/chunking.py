CHUNK_SIZE_WORDS = 512
OVERLAP_WORDS = 64
SHORT_DOC_THRESHOLD = 300  # ≤ this word count → single chunk, no split
_STRIDE = CHUNK_SIZE_WORDS - OVERLAP_WORDS  # = 448


def chunk_text(text: str) -> list[str]:
    """Split into overlapping word-based chunks. Returns [text] for short docs."""
    words = text.split()
    if len(words) <= SHORT_DOC_THRESHOLD:
        return [text]
    chunks, start = [], 0
    while start < len(words):
        end = min(start + CHUNK_SIZE_WORDS, len(words))
        chunks.append(" ".join(words[start:end]))
        if end == len(words):
            break
        start += _STRIDE
    return chunks


def count_words(text: str) -> int:
    return len(text.split())
