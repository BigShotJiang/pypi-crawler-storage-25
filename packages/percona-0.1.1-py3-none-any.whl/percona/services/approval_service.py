import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models.approvals import Approval, ApprovalComment, ApprovalStatus, ApprovalType

logger = logging.getLogger(__name__)

_VALID_TYPES = {t.value for t in ApprovalType}


def _validate_type(approval_type: str) -> str:
    if approval_type not in _VALID_TYPES:
        raise ValueError(f"Invalid approval_type: {approval_type!r}. Allowed: {sorted(_VALID_TYPES)}")
    return approval_type


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------


async def create_approval(
    db: AsyncSession,
    user_id: uuid.UUID,
    session_id: uuid.UUID,
    title: str,
    description: str,
    *,
    approval_type: str = "remediation",
    requested_by_agent_id: uuid.UUID | None = None,
    requested_by_user: str | None = None,
    entity_type: str | None = None,
    entity_id: uuid.UUID | None = None,
    payload: dict | None = None,
    expires_at: datetime | None = None,
) -> Approval:
    """Create a new approval request."""
    _validate_type(approval_type)
    approval = Approval(
        user_id=user_id,
        session_id=session_id,
        title=title,
        description=description,
        approval_type=approval_type,
        requested_by_agent_id=requested_by_agent_id,
        requested_by_user=requested_by_user,
        entity_type=entity_type,
        entity_id=entity_id,
        payload=payload,
        expires_at=expires_at,
    )
    db.add(approval)
    await db.flush()
    logger.info("approval_created id=%s type=%s title=%s session_id=%s", approval.id, approval_type, title, session_id)
    return approval


async def create_and_notify(
    db: AsyncSession,
    user_id: uuid.UUID,
    session_id: uuid.UUID,
    title: str,
    description: str,
    *,
    approval_type: str = "remediation",
    requested_by_agent_id: uuid.UUID | None = None,
    requested_by_user: str | None = None,
    entity_type: str | None = None,
    entity_id: uuid.UUID | None = None,
    payload: dict | None = None,
    expires_at: datetime | None = None,
    frontend_url: str = "",
) -> Approval:
    """Create approval and dispatch notifications to all channels.

    This is the high-level method MCP tools should call.
    Caller must commit after this returns.
    """
    from percona.services import notification_service

    approval = await create_approval(
        db, user_id, session_id, title, description,
        approval_type=approval_type,
        requested_by_agent_id=requested_by_agent_id,
        requested_by_user=requested_by_user,
        entity_type=entity_type,
        entity_id=entity_id,
        payload=payload,
        expires_at=expires_at,
    )

    approval_url = f"{frontend_url}/approvals/{approval.id}"
    notif_title = f"Approval Required: {title}"
    notif_body = f"[{approval_type}] {description[:500]}\n\nReview & approve: {approval_url}"

    for send_fn in [
        notification_service.send_slack,
        notification_service.send_email,
        notification_service.send_pushover,
        notification_service.send_whatsapp,
    ]:
        try:
            await send_fn(db, user_id, notif_title, notif_body, session_id=session_id)
        except Exception:
            logger.warning("approval_notification_failed channel=%s", send_fn.__name__, exc_info=True)

    try:
        reply_markup = {
            "inline_keyboard": [[
                {"text": "Review & Approve", "url": approval_url},
            ]]
        }
        await notification_service.send_telegram(
            db, user_id, notif_title, notif_body,
            session_id=session_id, reply_markup=reply_markup,
        )
    except Exception:
        logger.warning("approval_telegram_failed", exc_info=True)

    logger.info("approval_created_with_notifications id=%s type=%s", approval.id, approval_type)
    return approval


# ---------------------------------------------------------------------------
# Decide (approve / reject / request-revision) — single orchestration point
# ---------------------------------------------------------------------------


async def decide(
    db: AsyncSession,
    user_id: uuid.UUID,
    approval_id: uuid.UUID,
    action: str,
    decided_by: str,
    decision_note: str,
) -> Approval:
    """Approve, reject, or request revision on a pending approval.

    Handles status transition, conversation creation for agent resumption,
    and decision notification. Caller must commit.

    Args:
        action: One of "approve", "reject", "request_revision".
    """
    from percona.services.session_bridge import create_conversation_from_session
    from percona.services import notification_service

    approval = await get_approval(db, user_id, approval_id)
    if not approval:
        raise KeyError(f"Approval {approval_id} not found")
    if approval.status != ApprovalStatus.PENDING:
        raise ValueError(f"Approval is already {approval.status.value}")

    # 1. Status transition
    status_map = {
        "approve": ApprovalStatus.APPROVED,
        "reject": ApprovalStatus.REJECTED,
        "request_revision": ApprovalStatus.REVISION_REQUESTED,
    }
    if action not in status_map:
        raise ValueError(f"Invalid action: {action!r}. Allowed: {sorted(status_map)}")

    approval.status = status_map[action]
    approval.decided_by = decided_by
    approval.decided_at = datetime.now(timezone.utc)
    approval.decision_note = decision_note

    # 2. Record revision comment
    if action == "request_revision":
        comment = ApprovalComment(
            user_id=user_id,
            approval_id=approval_id,
            author_type="user",
            author_id=decided_by,
            body=f"Revision requested: {decision_note}",
        )
        db.add(comment)

    await db.flush()

    # 3. Create resumed conversation from original session
    title_prefix = {"approve": "Approved", "reject": "Rejected", "request_revision": "Revision requested"}
    try:
        conversation = await create_conversation_from_session(
            db, approval.user_id, approval.session_id,
            title=f"{title_prefix[action]}: {approval.title}",
        )
        approval.resumed_conversation_id = conversation.id
        await db.flush()
    except (KeyError, ValueError) as e:
        logger.error("approval_resume_failed id=%s action=%s error=%s", approval_id, action, e)
        raise ValueError(
            f"Cannot resume agent session: {e}. "
            f"The approval status has been set to {approval.status.value} "
            f"but the agent cannot be notified automatically."
        ) from e

    # 4. Notify channels about the decision
    action_labels = {"approve": "Approved", "reject": "Rejected", "request_revision": "Revision Requested"}
    notif_title = f"Approval {action_labels[action]}: {approval.title}"
    notif_body = f"Decision by {decided_by}: {decision_note or '(no note)'}"

    for send_fn in [notification_service.send_slack, notification_service.send_telegram]:
        try:
            await send_fn(db, user_id, notif_title, notif_body, session_id=approval.session_id)
        except Exception:
            logger.warning("approval_decision_notification_failed channel=%s", send_fn.__name__, exc_info=True)

    logger.info("approval_decided id=%s action=%s by=%s", approval_id, action, decided_by)
    return approval


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


async def list_approvals(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    status: ApprovalStatus | None = None,
    approval_type: str | None = None,
    limit: int = 25,
    offset: int = 0,
) -> list[Approval]:
    """List approvals for a user, optionally filtered by status and type."""
    filters = [Approval.user_id == user_id]
    if status:
        filters.append(Approval.status == status)
    if approval_type:
        filters.append(Approval.approval_type == approval_type)
    result = await db.execute(
        select(Approval)
        .where(*filters)
        .order_by(Approval.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    return list(result.scalars().all())


async def count_approvals(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    status: ApprovalStatus | None = None,
    approval_type: str | None = None,
) -> int:
    """Count approvals for a user."""
    filters = [Approval.user_id == user_id]
    if status:
        filters.append(Approval.status == status)
    if approval_type:
        filters.append(Approval.approval_type == approval_type)
    result = await db.execute(
        select(func.count()).select_from(Approval).where(*filters)
    )
    return result.scalar() or 0


async def get_approval(
    db: AsyncSession,
    user_id: uuid.UUID,
    approval_id: uuid.UUID,
) -> Approval | None:
    """Get a single approval by ID, scoped to user."""
    result = await db.execute(
        select(Approval).where(
            Approval.id == approval_id,
            Approval.user_id == user_id,
        )
    )
    return result.scalar_one_or_none()


async def get_approval_any_user(
    db: AsyncSession,
    approval_id: uuid.UUID,
) -> Approval | None:
    """Get a single approval by ID without user scoping (for approval links)."""
    result = await db.execute(
        select(Approval).where(Approval.id == approval_id)
    )
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


async def add_comment(
    db: AsyncSession,
    approval_id: uuid.UUID,
    author_type: str,
    author_id: str,
    body: str,
) -> ApprovalComment:
    """Add a comment to an approval (no user scoping — matches approve/reject)."""
    approval = await get_approval_any_user(db, approval_id)
    if not approval:
        raise KeyError(f"Approval {approval_id} not found")

    comment = ApprovalComment(
        user_id=approval.user_id,
        approval_id=approval_id,
        author_type=author_type,
        author_id=author_id,
        body=body,
    )
    db.add(comment)
    await db.flush()
    logger.info("approval_comment_added approval_id=%s author=%s/%s", approval_id, author_type, author_id)
    return comment


async def list_comments(
    db: AsyncSession,
    approval_id: uuid.UUID,
) -> list[ApprovalComment]:
    """List comments for an approval (no user scoping — matches approve/reject)."""
    result = await db.execute(
        select(ApprovalComment).where(
            ApprovalComment.approval_id == approval_id,
        ).order_by(ApprovalComment.created_at.asc())
    )
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Idempotency & expiry
# ---------------------------------------------------------------------------


async def find_pending_for_session(
    db: AsyncSession,
    user_id: uuid.UUID,
    session_id: uuid.UUID,
    title: str,
) -> Approval | None:
    """Find an existing PENDING approval for idempotency check."""
    result = await db.execute(
        select(Approval).where(
            Approval.user_id == user_id,
            Approval.session_id == session_id,
            Approval.title == title,
            Approval.status == ApprovalStatus.PENDING,
        ).limit(1)
    )
    return result.scalar_one_or_none()


async def expire_stale_approvals(db: AsyncSession) -> int:
    """Expire pending approvals past their expires_at. Cross-user.

    Sends notifications for each expired approval.
    """
    from percona.services import notification_service

    now = datetime.now(timezone.utc)
    result = await db.execute(
        select(Approval).where(
            and_(
                Approval.status == ApprovalStatus.PENDING,
                Approval.expires_at.isnot(None),
                Approval.expires_at <= now,
            )
        )
    )
    stale = result.scalars().all()
    for approval in stale:
        approval.status = ApprovalStatus.EXPIRED
        approval.decided_at = now
        approval.decided_by = "system"
        approval.decision_note = "Auto-expired"

        notif_title = f"Approval Expired: {approval.title}"
        notif_body = f"[{approval.approval_type}] This approval expired without a decision."
        for send_fn in [notification_service.send_slack, notification_service.send_telegram]:
            try:
                await send_fn(db, approval.user_id, notif_title, notif_body, session_id=approval.session_id)
            except Exception:
                logger.warning("approval_expiry_notification_failed id=%s", approval.id, exc_info=True)

    await db.flush()
    if stale:
        logger.info("approvals_expired count=%d", len(stale))
    return len(stale)
