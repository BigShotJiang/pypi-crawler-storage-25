import uuid
from datetime import datetime, timezone
import logging

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models.todos import TodoItem
from percona.schemas.todos import TodoCreate, TodoUpdate

logger = logging.getLogger(__name__)


def _todo_index_text(item: TodoItem) -> str:
    return f"{item.title}\n\n{item.description or ''}\n\n{item.notes or ''}".strip()


async def get_todo(db: AsyncSession, user_id: uuid.UUID, todo_id: uuid.UUID) -> TodoItem | None:
    result = await db.execute(
        select(TodoItem)
        .where(TodoItem.id == todo_id)
        .where(TodoItem.user_id == user_id)
    )
    return result.scalar_one_or_none()


async def create_todo(db: AsyncSession, user_id: uuid.UUID, data: TodoCreate) -> TodoItem:
    item = TodoItem(
        title=data.title.strip(),
        description=data.description,
        notes=data.notes,
        context=data.context,
        status=data.status or "todo",
        priority=data.priority or "medium",
        tags=data.tags or [],
        due_date=data.due_date,
        session_id=data.session_id,
        user_id=user_id,
    )
    db.add(item)
    await db.flush()
    logger.info("todo_created id=%s title=%r priority=%s status=%s", item.id, item.title, item.priority, item.status)
    return item


async def list_todos(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    status: str | None = None,
    priority: str | None = None,
    context: str | None = None,
    search: str | None = None,
    query: str | None = None,
    keyword: str | None = None,
    limit: int = 20,
    offset: int = 0,
    rerank: bool = False,
) -> list[TodoItem]:
    filters = [TodoItem.user_id == user_id]
    if status:
        filters.append(TodoItem.status == status)
    if priority:
        filters.append(TodoItem.priority == priority)
    if context:
        filters.append(TodoItem.context.ilike(context))
    if search:
        filters.append(
            or_(
                TodoItem.title.ilike(f"%{search}%"),
                TodoItem.description.ilike(f"%{search}%"),
            )
        )

    text_query = query or keyword
    if text_query:
        like = f"%{text_query}%"
        filters.append(
            or_(
                TodoItem.title.ilike(like),
                TodoItem.description.ilike(like),
                TodoItem.notes.ilike(like),
            )
        )

    stmt = select(TodoItem).order_by(TodoItem.created_at.desc()).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_todos(db: AsyncSession, user_id: uuid.UUID, *, status: str | None = None) -> int:
    stmt = select(func.count()).select_from(TodoItem)
    stmt = stmt.where(TodoItem.user_id == user_id)
    if status:
        stmt = stmt.where(TodoItem.status == status)
    return await db.scalar(stmt)


async def update_todo(db: AsyncSession, user_id: uuid.UUID, todo_id: uuid.UUID, data: TodoUpdate) -> TodoItem | None:
    item = await get_todo(db, user_id, todo_id)
    if not item:
        return None
    updated = data.model_dump(exclude_unset=True)
    old_status = item.status
    for field, value in updated.items():
        setattr(item, field, value)
    # Manage completed_at automatically on status transitions
    new_status = item.status
    now = datetime.now(timezone.utc)
    if new_status == "done" and old_status != "done":
        item.completed_at = now
    elif new_status != "done" and old_status == "done":
        item.completed_at = None
    logger.info("todo_updated id=%s fields=%s", todo_id, list(updated.keys()))
    return item


async def delete_todo(db: AsyncSession, user_id: uuid.UUID, todo_id: uuid.UUID) -> bool:
    item = await get_todo(db, user_id, todo_id)
    if not item:
        return False
    await db.delete(item)
    logger.info("todo_deleted id=%s", todo_id)
    return True


async def complete_todo(db: AsyncSession, user_id: uuid.UUID, todo_id: uuid.UUID) -> TodoItem | None:
    item = await get_todo(db, user_id, todo_id)
    if not item:
        return None
    if item.status == "done":
        return item  # already done — idempotent
    item.status = "done"
    item.completed_at = datetime.now(timezone.utc)
    logger.info("todo_completed id=%s", todo_id)
    return item
