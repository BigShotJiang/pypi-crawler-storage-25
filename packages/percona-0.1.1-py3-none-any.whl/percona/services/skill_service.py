import re
import uuid
import logging

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models.content import Skill, SkillEntryType

logger = logging.getLogger(__name__)


def slugify(name: str) -> str:
    """Convert name to a slug: lowercase, hyphens, no special chars."""
    slug = name.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug[:100]


async def get_skill_by_id(db: AsyncSession, user_id: uuid.UUID, skill_id: uuid.UUID) -> Skill | None:
    result = await db.execute(
        select(Skill)
        .where(Skill.id == skill_id)
        .where(Skill.user_id == user_id)
    )
    return result.scalar_one_or_none()


async def get_skill_by_slug(db: AsyncSession, user_id: uuid.UUID, slug: str) -> Skill | None:
    result = await db.execute(select(Skill).where(Skill.slug == slug).where(Skill.user_id == user_id))
    return result.scalar_one_or_none()


async def create_skill(db: AsyncSession, user_id: uuid.UUID, *, name: str, slug: str, description: str, domain: str, content: str, entry_type: str = "skill", session_id: uuid.UUID | None = None) -> Skill:
    """Create a skill with an explicit slug (used by the REST API)."""
    skill = Skill(name=name, slug=slug, description=description, domain=domain, content=content, entry_type=SkillEntryType(entry_type), session_id=session_id, user_id=user_id)
    db.add(skill)
    await db.flush()
    logger.info("skill_created id=%s slug=%s domain=%s", skill.id, slug, domain)
    return skill


async def create_or_update_skill(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    name: str,
    description: str,
    domain: str,
    content: str,
    entry_type: str = "skill",
    session_id: uuid.UUID | None = None,
) -> tuple[Skill, str]:
    """Upsert a skill by slug. Returns (skill, 'created' | 'updated')."""
    slug = slugify(name)
    existing = await get_skill_by_slug(db, user_id, slug)
    if existing:
        existing.name = name
        existing.description = description
        existing.domain = domain
        existing.content = content
        existing.entry_type = SkillEntryType(entry_type)
        logger.info("skill_updated slug=%s", slug)
        return existing, "updated"

    skill = Skill(
        name=name,
        slug=slug,
        description=description,
        domain=domain,
        content=content,
        entry_type=SkillEntryType(entry_type),
        session_id=session_id,
        user_id=user_id,
    )
    db.add(skill)
    await db.flush()
    logger.info("skill_created id=%s slug=%s domain=%s", skill.id, slug, domain)
    return skill, "created"


async def count_skills(db: AsyncSession, user_id: uuid.UUID, *, domain: str | None = None) -> int:
    stmt = select(func.count()).select_from(Skill)
    stmt = stmt.where(Skill.user_id == user_id)
    if domain:
        stmt = stmt.where(Skill.domain == domain)
    return (await db.scalar(stmt)) or 0


async def list_skills(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    domain: str | None = None,
    entry_type: str | None = None,
    query: str | None = None,
    keyword: str | None = None,
    limit: int = 50,
    offset: int = 0,
    rerank: bool = False,
) -> list[Skill]:
    filters = [Skill.user_id == user_id]
    if domain:
        filters.append(Skill.domain == domain)
    if entry_type:
        filters.append(Skill.entry_type == SkillEntryType(entry_type))

    text_query = query or keyword
    if text_query:
        like = f"%{text_query}%"
        filters.append(
            or_(
                Skill.name.ilike(like),
                Skill.description.ilike(like),
                Skill.content.ilike(like),
            )
        )

    stmt = select(Skill).order_by(Skill.domain, Skill.name).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def update_skill(
    db: AsyncSession,
    user_id: uuid.UUID,
    skill_id: uuid.UUID,
    *,
    name: str | None = None,
    description: str | None = None,
    domain: str | None = None,
    content: str | None = None,
    entry_type: str | None = None,
) -> Skill | None:
    skill = await get_skill_by_id(db, user_id, skill_id)
    if not skill:
        return None
    if name:
        skill.name = name
        skill.slug = slugify(name)
    if description:
        skill.description = description
    if domain:
        skill.domain = domain
    if content:
        skill.content = content
    if entry_type:
        skill.entry_type = SkillEntryType(entry_type)
    logger.info("skill_updated id=%s", skill_id)
    return skill


async def delete_skill(db: AsyncSession, user_id: uuid.UUID, skill_id: uuid.UUID) -> bool:
    skill = await get_skill_by_id(db, user_id, skill_id)
    if not skill:
        return False
    await db.delete(skill)
    logger.info("skill_deleted id=%s", skill_id)
    return True
