import json
import logging
import uuid
import asyncio
from typing import Any
from percona.config import settings

logger = logging.getLogger(__name__)

class Notifier:
    """Publishes events to Redis/SSE and dispatches external notifications."""

    def __init__(self, redis_client):
        self.redis = redis_client

    def publish_session_event(self, session_id: str, event_type: str, data: dict):
        """Publish event to Redis for WebSocket/SSE streaming."""
        payload = json.dumps({"type": event_type, **data})
        logger.debug("publish_event session_id=%s event_type=%s", session_id, event_type)
        self.redis.publish(f"session:{session_id}", payload)

    def publish_chat_event(self, conversation_id: str, event_type: str, data: dict):
        """Publish event to Redis for SSE streaming (chat channel)."""
        payload = json.dumps({"type": event_type, **data})
        logger.debug("publish_chat_event conversation_id=%s event_type=%s", conversation_id, event_type)
        self.redis.publish(f"chat:{conversation_id}", payload)

    async def dispatch_external_notifications(self, task, session, finding):
        """Send notifications to task-configured channels for a specific finding."""
        # This logic was mostly missing in the original tasks.py but planned in the user story
        # I'll implement a basic version that follows the models
        from percona.services.notification import send_slack_notification, send_email_notification, send_pushover_notification
        from percona.models import NotificationChannelType, Severity
        from percona.models import NotificationLog

        logger.info("dispatch_external_notifications session_id=%s finding_id=%s", session.id, finding.id)

        for channel in task.notification_channels:
            if not channel.enabled:
                continue

            # Check severity threshold (using a junction table field if we can access it, 
            # or default to MEDIUM if not specified in the relationship)
            # For now we'll assume the relationship gives us access.
            
            # TODO: Implement min_severity check if TaskNotificationChannel is exposed
            
            try:
                success = False
                if channel.channel_type == NotificationChannelType.SLACK:
                    webhook_url = channel.config.get("webhook_url")
                    if webhook_url:
                        success = await send_slack_notification(
                            webhook_url, 
                            finding.__dict__, 
                            str(session.id), 
                            task.name
                        )
                elif channel.channel_type == NotificationChannelType.EMAIL:
                    # Logic similar to mcp_internal/tools/notifications.py
                    pass # Placeholder
                
                # Log the notification attempt
                # Note: This requires a DB session, which Notifier doesn't currently hold.
                # In a real refactor, either pass DB to Notifier or return logs to be saved.
                
            except Exception as e:
                logger.error("notification_dispatch_failed channel=%s error=%s", channel.name, e)
