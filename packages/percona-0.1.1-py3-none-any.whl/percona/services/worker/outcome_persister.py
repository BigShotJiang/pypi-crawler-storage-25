import logging
import uuid
from datetime import datetime, timezone
from sqlalchemy import select, func as sa_func
from sqlalchemy.orm import selectinload
from percona.models import Session, Message, ToolCall, Task
from percona.models import SessionStatus, ToolCallStatus, MessageRole, TriggerSource

logger = logging.getLogger(__name__)

class OutcomePersister:
    """Handles persistence of all session artifacts and state transitions."""

    def __init__(self, db_session):
        self.db = db_session

    async def get_or_create_session(
        self,
        task: Task,
        session_id: str,
        trigger_source: str,
        idempotency_key: str | None = None,
    ) -> Session:
        """Create a new session or return existing if already exists (idempotency)."""
        # Try finding by ID first
        stmt = select(Session).where(Session.id == uuid.UUID(session_id))
        result = await self.db.execute(stmt)
        session = result.scalar_one_or_none()
        
        if session:
            logger.info("session_already_exists session_id=%s", session_id)
            return session

        # Try finding by idempotency key
        if idempotency_key:
            stmt = select(Session).where(Session.idempotency_key == idempotency_key)
            result = await self.db.execute(stmt)
            session = result.scalar_one_or_none()
            if session:
                logger.info("session_already_exists idempotency_key=%s session_id=%s", idempotency_key, session.id)
                return session

        logger.info("get_or_create_session_creating task_id=%s task.user_id=%s", task.id, task.user_id)
        session = Session(
            id=uuid.UUID(session_id),
            user_id=task.user_id,
            task_id=task.id,
            status=SessionStatus.PENDING,
            agent_type=task.agent_type,
            system_prompt_snapshot=None,
            prompt_snapshot=task.prompt,
            trigger_source=TriggerSource(trigger_source),
            idempotency_key=idempotency_key,
        )
        logger.info("get_or_create_session_created session_id=%s session.user_id=%s", session.id, session.user_id)
        self.db.add(session)
        
        await self.db.commit()
        return session

    async def save_message(self, session_id: uuid.UUID, role: str, content: str, sequence: int) -> Message:
        msg = Message(
            session_id=session_id,
            role=MessageRole(role),
            content=content,
            sequence=sequence,
        )
        self.db.add(msg)
        await self.db.flush()
        return msg

    async def save_tool_call_start(
        self, session_id: uuid.UUID, tool_name: str, tool_server: str | None, 
        input_params: dict | None, sequence: int
    ) -> ToolCall:
        tc = ToolCall(
            session_id=session_id,
            tool_name=tool_name,
            tool_server=tool_server,
            input_params=input_params,
            status=ToolCallStatus.RUNNING,
            sequence=sequence,
        )
        self.db.add(tc)
        await self.db.flush()
        return tc

    async def save_tool_call_end(
        self, tool_call: ToolCall, status: str, output: str, duration_ms: int | None
    ):
        tool_call.status = ToolCallStatus.SUCCESS if status == "success" else ToolCallStatus.ERROR
        tool_call.output_result = output
        tool_call.duration_ms = duration_ms
        await self.db.flush()

    async def update_session_status(self, session: Session, status: SessionStatus):
        if status == SessionStatus.RUNNING:
            session.start()
        elif status == SessionStatus.FAILED:
            session.fail(error_message="Failed before completion")
        elif status == SessionStatus.TIMEOUT:
            session.status = SessionStatus.TIMEOUT
            session.finished_at = datetime.now(timezone.utc)
        else:
            session.status = status
            if status == SessionStatus.COMPLETED:
                session.finished_at = datetime.now(timezone.utc)
        await self.db.flush()

    async def finalize_session(
        self, session: Session, agent_result, duration_ms: int, raw_output_path: str, workspace_path: str
    ):
        session.duration_ms = duration_ms
        session.raw_output_path = raw_output_path
        session.workspace_path = workspace_path
        session.agent_native_session_id = agent_result.agent_native_session_id

        if session.status != SessionStatus.TIMEOUT:
            if agent_result.success:
                session.complete(
                    summary=agent_result.summary,
                    input_tokens=agent_result.input_tokens,
                    output_tokens=agent_result.output_tokens,
                    cost_usd=agent_result.cost_usd
                )
            else:
                session.fail(
                    error_message=agent_result.error_message or "Unknown error",
                )
                session.input_tokens = agent_result.input_tokens
                session.output_tokens = agent_result.output_tokens
                session.total_tokens = agent_result.total_tokens
                session.cost_usd = agent_result.cost_usd
        
        await self.db.flush()
