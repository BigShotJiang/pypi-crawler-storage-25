import asyncio
import logging
import os
import time
from typing import AsyncIterator
from percona.agents.domain_events import DomainEvent, AgentCompleted, AgentError
from percona.services.workspace import WorkspaceService

logger = logging.getLogger(__name__)

class AgentExecutor:
    """Handles subprocess execution, output streaming, and lifecycle management."""

    async def run_agent(
        self,
        adapter,
        cmd: list[str],
        workspace_path: str,
        timeout_seconds: int,
        on_process_started=None,
    ) -> AsyncIterator[DomainEvent]:
        """Run agent subprocess and yield events."""
        # Whitelist-only env: never expose platform secrets to agent subprocesses.
        # Agents must not have access to DATABASE_URL, Redis, Telegram/Slack tokens,
        # OAuth secrets, or any PERCONA_* internal credentials.
        _ALLOWED_PREFIXES = ("OPENAI_", "ANTHROPIC_", "GOOGLE_", "GEMINI_", "CODEX_", "CLAUDE_", "UV_")
        _ALLOWED_KEYS = {
            "PATH", "HOME", "USER", "SHELL", "TMPDIR", "TEMP", "TMP",
            "LANG", "LC_ALL", "LC_CTYPE", "TERM", "COLORTERM",
            "NODE_ENV", "NODE_PATH",
            "GIT_AUTHOR_NAME", "GIT_AUTHOR_EMAIL",
            "GIT_COMMITTER_NAME", "GIT_COMMITTER_EMAIL",
        }
        agent_env = {
            k: v for k, v in os.environ.items()
            if k in _ALLOWED_KEYS or any(k.startswith(p) for p in _ALLOWED_PREFIXES)
        }
        # Remove nested Claude Code session markers
        for key in ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT"]:
            agent_env.pop(key, None)
        # Claude Code 2.1.69+ blocks --dangerously-skip-permissions when running as root
        # unless IS_SANDBOX=1 is set. Explicitly set it so the worker always works
        # regardless of whether the container env already has it.
        agent_env["IS_SANDBOX"] = "1"

        agent_env.update(adapter.get_extra_env(workspace_path))

        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=workspace_path,
            env=agent_env,
            limit=10 * 1024 * 1024,
        )
        
        logger.info("agent_process_started pid=%s", process.pid)

        if on_process_started:
            on_process_started(process)

        try:
            async for event in adapter.stream_output(process):
                yield event

            # Wait for completion and capture stderr
            try:
                return_code = await asyncio.wait_for(process.wait(), timeout=timeout_seconds)
                stderr_data = await process.stderr.read()
                stderr_text = stderr_data.decode("utf-8", errors="replace") if stderr_data else ""
                
                # Yield a virtual "process_finished" event for internal use
                yield AgentCompleted(
                    success=return_code == 0,
                    usage={"return_code": return_code, "stderr": stderr_text}
                )
            except asyncio.TimeoutError:
                process.kill()
                yield AgentCompleted(
                    success=False,
                    usage={"return_code": -1, "error": "timeout", "stderr": ""}
                )
                
        except Exception as e:
            logger.exception("agent_execution_crashed")
            if process.returncode is None:
                process.kill()
            yield AgentError(message=str(e), error_type="ExecutionError")
            raise
