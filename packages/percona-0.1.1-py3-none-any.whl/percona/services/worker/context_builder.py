import json
import logging
from sqlalchemy import select
from percona.defaults import GLOBAL_SYSTEM_PROMPT
from percona.models import Task
from percona.models.integrations import ProjectSettings
from percona.models.content import Memory
from percona.services import mcp_client

MEMORY_INJECTION_LIMIT = 20

logger = logging.getLogger(__name__)

class ContextBuilder:
    """Builds effective system prompts and pre-run context injections."""

    def __init__(self, db_session):
        self.db = db_session

    async def build_system_prompt(
        self,
        task: Task,
        session_id: str,
        workspace_path: str,
        webhook_payload: dict | None = None,
    ) -> str:
        """Assemble the full effective system prompt."""
        # 1. Global prefix
        global_prefix = await self._fetch_global_system_prompt(user_id=task.user_id)

        # 2. Session context
        session_context = (
            f"## Session Context\n"
            f"Your session_id is: {session_id}\n"
            f"Your task_id is: {task.id}\n"
            f"Your workspace path is: `{workspace_path}`\n"
            f"Use this session_id when calling Percona MCP tools that require it.\n\n"
        )

        # 3. Base system prompt
        system_prompt = global_prefix + session_context + (task.system_prompt or "")

        # 4. Webhook payload
        if webhook_payload is not None:
            webhook_block = (
                "\n\n## Webhook Trigger Context\n"
                "This session was triggered by an external webhook. "
                "Analyze the following payload as the primary input for your task:\n\n"
                f"```json\n{json.dumps(webhook_payload, indent=2)}\n```"
            )
            system_prompt += webhook_block

        # 5. Task memory from previous sessions
        if task.task_memory and task.task_memory.strip():
            system_prompt += (
                "\n\n## Task Memory\n"
                "The following is a persistent scratchpad written by previous runs of this task. "
                "Its purpose is to carry forward only what future sessions need to know — "
                "unresolved items, decisions already made, duplicates to avoid, and patterns spotted across runs. "
                "It is NOT a log or audit trail; keep it concise and actionable.\n\n"
                "**IMPORTANT — update_memory REPLACES the entire memory, it does NOT append.** "
                "At the end of your session you MUST call "
                f"`task(action=\"update_memory\", task_id=\"{task.id}\", memory=\"...\")`. "
                "Before saving, read the existing content below, merge it with what you learned this session, "
                "and drop anything that is no longer relevant or has been resolved. "
                "The result should be the single source of truth for the next agent run.\n\n"
                + task.task_memory.strip() + "\n"
            )

        # 5.5 Task attached files
        if hasattr(task, "files") and task.files:
            file_lines = ["\n\n## Attached Files", "The following files are attached to this task and available in your workspace under `files/`:\n"]
            for sf in task.files:
                file_lines.append(f"- `files/{sf.original_filename}` ({sf.content_type}, {sf.file_size_bytes} bytes)")
            system_prompt += "\n".join(file_lines) + "\n"

        # 6. Pre-run injections (skills + memories)
        prc = task.pre_run_context or {"inject_skills": True, "injections": []}
        mcp_servers = [
            {"slug": s.slug, "command": s.command, "args": s.args or [], "env": s.env or {}, "transport": s.transport, "url": s.url}
            for s in task.mcp_servers
            if s.enabled
        ]
        suffix = await self._build_pre_run_suffix(prc, mcp_servers, task=task)
        if suffix:
            system_prompt += suffix

        return system_prompt

    async def _fetch_global_system_prompt(self, user_id=None) -> str:
        if not user_id:
            return ""
        result = await self.db.execute(
            select(ProjectSettings).where(ProjectSettings.user_id == user_id)
        )
        row = result.scalar_one_or_none()
        if row and row.global_system_prompt and row.global_system_prompt.strip():
            return row.global_system_prompt.strip() + "\n\n"
        return GLOBAL_SYSTEM_PROMPT.strip() + "\n\n"

    async def _build_memory_block(self, task_prompt: str | None, limit: int, user_id=None) -> str:
        """Load relevant memories for the session.

        If task_prompt is provided, uses hybrid search to surface semantically
        relevant memories. Falls back to latest N by recency otherwise.
        """
        try:
            base_filter = [Memory.user_id == user_id] if user_id else []
            if task_prompt and task_prompt.strip():
                from percona.services.search import hybrid_search
                matching_ids = await hybrid_search("memory", task_prompt.strip(), limit=limit)
                if matching_ids:
                    result = await self.db.execute(
                        select(Memory).where(Memory.id.in_(matching_ids), *base_filter)
                    )
                    mem_map = {m.id: m for m in result.scalars().all()}
                    memories = [mem_map[mid] for mid in matching_ids if mid in mem_map]
                else:
                    memories = []
            else:
                result = await self.db.execute(
                    select(Memory).where(*base_filter).order_by(Memory.updated_at.desc()).limit(limit)
                )
                memories = list(result.scalars().all())

            if not memories:
                return ""

            lines = []
            for m in memories:
                label = f"{m.entity_type}/{m.entity_key}/{m.key}"
                text = m.value or (json.dumps(m.value_json) if m.value_json else "")
                meta_parts = []
                if m.confidence is not None:
                    meta_parts.append(f"confidence: {m.confidence:.2f}")
                if m.tags:
                    meta_parts.append(f"tags: {', '.join(m.tags)}")
                meta = f"  ({', '.join(meta_parts)})" if meta_parts else ""
                lines.append(f"- [{label}] {text}{meta}")
            return "\n\n## Agent Memories\n" + "\n".join(lines) + "\n"
        except Exception:
            logger.warning("memory_block_build_failed", exc_info=True)
            return ""

    async def _build_pre_run_suffix(self, prc: dict, mcp_servers: list[dict], *, task: Task | None = None, conversation=None) -> str:
        suffix = ""

        user_id = (task.user_id if task else conversation.user_id if conversation else None)

        # Memory injection
        if prc.get("inject_memories", True):
            mem_limit = int(prc.get("memory_injection_limit", MEMORY_INJECTION_LIMIT))
            search_query = (
                (task.prompt or task.name or "") if task
                else (conversation.title or "") if conversation
                else ""
            )
            memory_block = await self._build_memory_block(search_query or None, mem_limit, user_id=user_id)
            if memory_block:
                suffix += memory_block

        # Skill injection — pinned skills + auto-search
        if user_id:
            try:
                import uuid as uuid_lib
                from percona.services import skill_service

                skills_to_inject: list = []
                pinned_ids = prc.get("skill_ids", [])

                # 1. Fetch pinned skills by ID (always, regardless of inject_skills toggle)
                for sid in pinned_ids:
                    try:
                        s = await skill_service.get_skill_by_id(self.db, user_id, uuid_lib.UUID(sid))
                        if s:
                            skills_to_inject.append(s)
                    except (ValueError, Exception):
                        pass

                # 2. Auto-search if inject_skills=True
                if prc.get("inject_skills", True):
                    search_query = ((task.prompt or task.name or "") if task else (conversation.title or ""))[:500]
                    if search_query.strip():
                        pinned_set = {s.id for s in skills_to_inject}
                        auto_skills = await skill_service.list_skills(
                            self.db, user_id,
                            query=search_query,
                            entry_type="skill",
                            limit=5,
                        )
                        remaining = max(0, 5 - len(skills_to_inject))
                        for s in auto_skills:
                            if s.id not in pinned_set and remaining > 0:
                                skills_to_inject.append(s)
                                remaining -= 1

                if skills_to_inject:
                    suffix += "\n\n## Relevant Skills from Past Experience\n"
                    suffix += "These skills were matched from previous sessions. To use one, call the `skill` MCP tool with action `get` and the skill's `skill_id` to retrieve its full content.\n"
                    for s in skills_to_inject:
                        desc = f": {s.description}" if s.description else ""
                        suffix += f"\n- **{s.name}** (skill_id: `{s.id}`){desc}\n"
            except Exception:
                logger.warning("skill_injection_failed", exc_info=True)

        # Collection schema injection
        if user_id:
            try:
                from sqlalchemy import select
                from percona.models.collections import Collection, CollectionField

                # Batch-fetch all active collections and their fields in 2 queries (not N+1)
                col_result = await self.db.execute(
                    select(Collection)
                    .where(Collection.user_id == user_id, Collection.status == "active")
                    .order_by(Collection.name.asc())
                    .limit(20)
                )
                collections = list(col_result.scalars().all())

                if collections:
                    col_ids = [c.id for c in collections]
                    field_result = await self.db.execute(
                        select(CollectionField)
                        .where(CollectionField.collection_id.in_(col_ids), CollectionField.user_id == user_id)
                        .order_by(CollectionField.sort_order.asc())
                    )
                    all_fields = list(field_result.scalars().all())
                    fields_by_col: dict[str, list] = {}
                    for f in all_fields:
                        fields_by_col.setdefault(str(f.collection_id), []).append(f)

                    collection_block = "\n\n## User Collections\n"
                    collection_block += (
                        "The user has the following data collections. "
                        "Use the `collection_manage`, `collection_items`, and `collection_query` tools to manage them.\n\n"
                    )
                    for c in collections:
                        col_fields = fields_by_col.get(str(c.id), [])
                        field_desc = ", ".join(
                            f"{f.name} ({f.field_type}{'*' if f.required else ''})"
                            for f in col_fields
                        )
                        collection_block += f"- **{c.name}** (slug=`{c.slug}`, {c.item_count} items): {field_desc}\n"
                        if c.agent_instructions:
                            collection_block += f"  Instructions: {c.agent_instructions}\n"
                    suffix += collection_block
            except Exception:
                logger.warning("collection_injection_failed", exc_info=True)

        return suffix
