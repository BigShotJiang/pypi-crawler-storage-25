import logging
import uuid

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models.secrets import Secret
from percona.schemas.secrets import SecretCreate, SecretUpdate
from percona.services.oauth_service import decrypt_token, encrypt_token

logger = logging.getLogger(__name__)


def secret_to_out_dict(secret: Secret) -> dict:
    """Convert a Secret ORM object to a dict with decrypted value."""
    return {
        "id": secret.id,
        "name": secret.name,
        "value": decrypt_token(secret.encrypted_value),
        "description": secret.description,
        "provider": secret.provider,
        "environment": secret.environment,
        "created_at": secret.created_at,
        "updated_at": secret.updated_at,
    }


async def get_secret(db: AsyncSession, user_id: uuid.UUID, secret_id: uuid.UUID) -> Secret | None:
    result = await db.execute(
        select(Secret)
        .where(Secret.id == secret_id)
        .where(Secret.user_id == user_id)
    )
    return result.scalar_one_or_none()


async def get_secret_by_name(db: AsyncSession, user_id: uuid.UUID, name: str) -> Secret | None:
    result = await db.execute(
        select(Secret)
        .where(Secret.name == name)
        .where(Secret.user_id == user_id)
    )
    return result.scalar_one_or_none()


async def create_secret(db: AsyncSession, user_id: uuid.UUID, data: SecretCreate) -> Secret:
    secret = Secret(
        name=data.name,
        encrypted_value=encrypt_token(data.value),
        description=data.description,
        provider=data.provider,
        environment=data.environment,
        user_id=user_id,
    )
    db.add(secret)
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise ValueError(f"Secret with name '{data.name}' already exists in this project")
    await db.refresh(secret)
    logger.info("secret_created id=%s name=%s", secret.id, secret.name)
    return secret


async def list_secrets(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    provider: str | None = None,
    environment: str | None = None,
    name: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[Secret]:
    filters = [Secret.user_id == user_id]
    if provider:
        filters.append(Secret.provider == provider)
    if environment:
        filters.append(Secret.environment == environment)
    if name:
        filters.append(Secret.name.ilike(f"%{name}%"))

    stmt = select(Secret).order_by(Secret.created_at.desc()).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_secrets(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    provider: str | None = None,
    environment: str | None = None,
) -> int:
    stmt = select(func.count(Secret.id)).where(Secret.user_id == user_id)
    if provider:
        stmt = stmt.where(Secret.provider == provider)
    if environment:
        stmt = stmt.where(Secret.environment == environment)
    result = await db.execute(stmt)
    return result.scalar()


async def update_secret(db: AsyncSession, user_id: uuid.UUID, secret_id: uuid.UUID, data: SecretUpdate) -> Secret | None:
    secret = await get_secret(db, user_id, secret_id)
    if not secret:
        return None
    updates = data.model_dump(exclude_unset=True)
    if "value" in updates:
        value = updates.pop("value")
        if value is not None:
            secret.encrypted_value = encrypt_token(value)
    for field, value in updates.items():
        setattr(secret, field, value)
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise ValueError(f"Secret with name '{data.name}' already exists in this project")
    await db.refresh(secret)
    return secret


async def delete_secret(db: AsyncSession, user_id: uuid.UUID, secret_id: uuid.UUID) -> bool:
    secret = await get_secret(db, user_id, secret_id)
    if not secret:
        return False
    await db.delete(secret)
    return True
