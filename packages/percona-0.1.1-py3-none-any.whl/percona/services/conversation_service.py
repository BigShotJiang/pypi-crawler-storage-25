import uuid
import logging
from datetime import datetime

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.models import AgentType
from percona.models.conversations import (
    Conversation,
    ConversationMcpServer,
    ConversationMemoryFile,
    ConversationMessage,
    MessageRole,
)
from percona.models.integrations import ProjectSettings
from percona.schemas import ConversationCreate
from percona.services.mcp_service import get_default_mcp_ids

logger = logging.getLogger(__name__)


async def get_channel_agent_defaults(db: AsyncSession, user_id: uuid.UUID) -> dict:
    """Return channel_agent_defaults from ProjectSettings, or {} if not configured."""
    ps = (await db.execute(
        select(ProjectSettings).where(ProjectSettings.user_id == user_id)
    )).scalar_one_or_none()
    return (ps.channel_agent_defaults or {}) if ps else {}


async def list_conversations(
    db: AsyncSession,
    user_id: uuid.UUID,
    *,
    updated_after: datetime | None = None,
    limit: int = 20,
    offset: int = 0,
) -> list[Conversation]:
    stmt = (
        select(Conversation)
        .where(Conversation.user_id == user_id)
        .order_by(Conversation.updated_at.desc())
        .limit(limit)
        .offset(offset)
    )
    if updated_after:
        stmt = stmt.where(Conversation.updated_at > updated_after)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_conversation_with_messages(
    db: AsyncSession,
    user_id: uuid.UUID,
    conversation_id: uuid.UUID,
) -> dict | None:
    """Fetch a conversation with its user/assistant messages.

    Returns a dict with conversation metadata and messages list,
    or None if the conversation is not found.
    """
    result = await db.execute(
        select(Conversation)
        .where(Conversation.id == conversation_id)
        .where(Conversation.user_id == user_id)
    )
    c = result.scalar_one_or_none()
    if not c:
        return None

    msgs_stmt = (
        select(ConversationMessage)
        .where(ConversationMessage.conversation_id == c.id)
        .where(ConversationMessage.role.in_([MessageRole.USER, MessageRole.ASSISTANT]))
        .order_by(ConversationMessage.sequence)
    )
    msgs = (await db.execute(msgs_stmt)).scalars().all()

    return {
        "id": str(c.id),
        "title": c.title,
        "agent_type": c.agent_type.value if hasattr(c.agent_type, "value") else str(c.agent_type),
        "updated_at": c.updated_at.isoformat(),
        "created_at": c.created_at.isoformat(),
        "messages": [
            {
                "role": m.role.value,
                "content": m.content,
                "sequence": m.sequence,
                "turn": m.turn_sequence,
            }
            for m in msgs
        ],
    }


async def create_conversation(
    db: AsyncSession,
    user_id: uuid.UUID,
    data: ConversationCreate,
) -> Conversation:
    """Create a conversation with MCP server and memory file associations.

    Raises ValueError if agent_type is invalid.
    The caller should commit.
    """
    try:
        agent_type = AgentType(data.agent_type)
    except ValueError:
        raise ValueError(f"Invalid agent_type: {data.agent_type}")

    conversation = Conversation(
        title=data.title,
        agent_type=agent_type,
        system_prompt=data.system_prompt,
        agent_settings=data.agent_settings,
        pre_run_context=data.pre_run_context,
        user_id=user_id,
    )
    db.add(conversation)
    await db.flush()

    mcp_ids_to_add = data.mcp_server_ids if data.mcp_server_ids is not None else await get_default_mcp_ids(db)
    for mid in mcp_ids_to_add:
        db.add(ConversationMcpServer(conversation_id=conversation.id, mcp_server_id=mid))

    for mfid in data.memory_file_ids:
        db.add(ConversationMemoryFile(conversation_id=conversation.id, memory_file_id=mfid))

    logger.info(
        "conversation_created id=%s agent=%s mcp_servers=%s memory_files=%s",
        conversation.id, conversation.agent_type, len(mcp_ids_to_add), len(data.memory_file_ids),
    )
    return conversation


async def update_conversation(
    db: AsyncSession,
    user_id: uuid.UUID,
    conversation_id: uuid.UUID,
    *,
    title: str | None = None,
    system_prompt: str | None = None,
    agent_settings: dict | None = None,
    pre_run_context: dict | None = None,
    mcp_server_ids: list[uuid.UUID] | None = None,
) -> Conversation | None:
    """Update conversation fields and optionally sync MCP server associations.

    Returns None if the conversation is not found. Caller should commit.
    """
    from sqlalchemy.orm import selectinload

    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation_id)
        .where(Conversation.user_id == user_id)
        .options(selectinload(Conversation.mcp_servers))
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        return None

    if title is not None:
        conversation.title = title
    if system_prompt is not None:
        conversation.system_prompt = system_prompt
    if agent_settings is not None:
        current = dict(conversation.agent_settings or {})
        current.update(agent_settings)
        conversation.agent_settings = current
    if pre_run_context is not None:
        conversation.pre_run_context = pre_run_context

    if mcp_server_ids is not None:
        await db.execute(
            delete(ConversationMcpServer).where(
                ConversationMcpServer.conversation_id == conversation_id
            )
        )
        for sid in mcp_server_ids:
            db.add(ConversationMcpServer(conversation_id=conversation_id, mcp_server_id=sid))

    return conversation


async def delete_conversation(
    db: AsyncSession,
    user_id: uuid.UUID,
    conversation_id: uuid.UUID,
) -> bool:
    """Delete a conversation. Returns True if found and deleted. Caller should commit."""
    stmt = select(Conversation).where(Conversation.id == conversation_id).where(Conversation.user_id == user_id)
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        return False
    await db.delete(conversation)
    logger.info("conversation_deleted id=%s", conversation_id)
    return True
