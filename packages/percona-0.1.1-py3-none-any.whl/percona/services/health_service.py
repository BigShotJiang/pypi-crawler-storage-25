import asyncio
import time
from dataclasses import dataclass

import redis.asyncio as aioredis
from sqlalchemy import text

from percona.config import settings
from percona.database import engine

@dataclass
class DependencyStatus:
    name: str
    ok: bool
    latency_ms: float
    error: str | None = None

async def check_database() -> DependencyStatus:
    start = time.perf_counter()
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return DependencyStatus("database", ok=True, latency_ms=(time.perf_counter() - start) * 1000)
    except Exception as e:
        return DependencyStatus("database", ok=False, latency_ms=0, error=str(e))

async def check_redis(redis_url: str) -> DependencyStatus:
    start = time.perf_counter()
    try:
        r = aioredis.from_url(redis_url)
        await r.ping()
        await r.aclose()
        return DependencyStatus("redis", ok=True, latency_ms=(time.perf_counter() - start) * 1000)
    except Exception as e:
        return DependencyStatus("redis", ok=False, latency_ms=0, error=str(e))

async def readiness() -> tuple[bool, list[DependencyStatus]]:
    results = await asyncio.gather(
        check_database(),
        check_redis(settings.redis_url),
    )
    all_ok = all(r.ok for r in results)
    return all_ok, list(results)
