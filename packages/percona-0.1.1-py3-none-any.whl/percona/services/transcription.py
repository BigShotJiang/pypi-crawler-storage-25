"""Async HTTP client for the transcription microservice.

Sends audio bytes to the transcription service and returns the text.
Used by the voice API endpoint and the Telegram voice handler.
"""

import asyncio
import logging
import mimetypes
from dataclasses import dataclass

import httpx

from percona.config import settings

logger = logging.getLogger(__name__)

# Generous timeout — transcription of long voice notes can take time
_TIMEOUT = httpx.Timeout(90.0, connect=5.0)

# Map file extensions to MIME types for audio formats
_AUDIO_MIME_TYPES: dict[str, str] = {
    ".ogg": "audio/ogg",
    ".oga": "audio/ogg",
    ".opus": "audio/opus",
    ".webm": "audio/webm",
    ".mp3": "audio/mpeg",
    ".wav": "audio/wav",
    ".m4a": "audio/mp4",
    ".mp4": "audio/mp4",
    ".flac": "audio/flac",
}


def _detect_mime_type(filename: str) -> str:
    """Detect audio MIME type from filename extension."""
    ext = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return _AUDIO_MIME_TYPES.get(ext, mimetypes.guess_type(filename)[0] or "audio/ogg")


@dataclass
class TranscriptionResponse:
    text: str
    language: str
    duration_seconds: float
    provider: str
    processing_time_ms: int = 0


class TranscriptionClient:
    """Async client for the transcription microservice."""

    def __init__(self, base_url: str | None = None):
        self._base_url = base_url or settings.transcription_service_url

    async def transcribe(
        self,
        audio_bytes: bytes,
        language: str | None = None,
        filename: str = "audio.ogg",
        max_retries: int = 3,
    ) -> TranscriptionResponse:
        """Send audio to the transcription service and return the text.

        Args:
            audio_bytes: Raw audio data.
            language: Optional language hint (e.g., "en", "ar").
            filename: Filename for the multipart upload.
            max_retries: Number of retry attempts on transient errors.

        Returns:
            TranscriptionResponse with text and metadata.

        Raises:
            httpx.HTTPStatusError: If the service returns an error.
            httpx.ConnectError: If the service is unreachable after retries.
        """
        url = f"{self._base_url}/transcribe"
        content_type = _detect_mime_type(filename)
        files = {"audio": (filename, audio_bytes, content_type)}
        data = {}
        if language:
            data["language"] = language

        # Retry logic with exponential backoff
        for attempt in range(max_retries):
            try:
                async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
                    response = await client.post(url, files=files, data=data)
                    response.raise_for_status()

                result = response.json()
                return TranscriptionResponse(
                    text=result["text"],
                    language=result.get("language", ""),
                    duration_seconds=result.get("duration_seconds", 0.0),
                    provider=result.get("provider", "unknown"),
                    processing_time_ms=result.get("processing_time_ms", 0),
                )

            except httpx.HTTPStatusError as e:
                # 503 = service busy (GPU still processing) — retry with backoff
                if e.response.status_code == 503 and attempt < max_retries - 1:
                    delay = min(1.5 * (2 ** attempt), 10.0)
                    logger.warning(
                        f"Transcription service busy (503), attempt {attempt + 1}. "
                        f"Retrying in {delay}s..."
                    )
                    await asyncio.sleep(delay)
                    continue
                raise

            except (httpx.ConnectError, httpx.RemoteProtocolError) as e:
                # Network errors - retry
                if attempt == max_retries - 1:
                    logger.error(f"Transcription failed after {max_retries} attempts: {e}")
                    raise

                delay = min(1.0 * (2 ** attempt), 10.0)
                logger.warning(f"Transcription attempt {attempt + 1} failed: {e}. Retrying in {delay}s...")
                await asyncio.sleep(delay)

            except httpx.TimeoutException as e:
                # Timeout - don't retry (audio probably too long)
                logger.error(f"Transcription timeout: {e}")
                raise

    async def health_check(self) -> bool:
        """Check if the transcription service is healthy.

        Returns:
            True if the service is reachable and responsive.
        """
        try:
            url = f"{self._base_url}/health"
            async with httpx.AsyncClient(timeout=httpx.Timeout(5.0)) as client:
                response = await client.get(url)
                return response.status_code == 200
        except Exception:
            return False
