import json
import logging
import os
import shutil
import subprocess
from pathlib import Path

from percona.config import settings

logger = logging.getLogger(__name__)


class WorkspaceService:
    """Prepares isolated workspace directories for agent sessions."""

    def __init__(self, session_id: str):
        self.session_id = session_id
        self.workspace_path = Path(settings.workspace_base_path) / session_id

    def setup(self) -> Path:
        """Create workspace directory structure."""
        self.workspace_path.mkdir(parents=True, exist_ok=True)
        logger.debug("workspace_setup session_id=%s path=%s", self.session_id, self.workspace_path)
        return self.workspace_path

    def _to_internal_url(self, url: str) -> str:
        """Replace external API base URL with internal Docker service URL.

        Agent CLI subprocesses run inside containers and can't reach the external
        HTTPS URL. This replaces the external base URL with the internal service URL
        so all agent types (Claude Code, Gemini, Codex) can reach MCP servers.
        """
        external = settings.api_base_url.rstrip("/")
        internal = settings.internal_api_url.rstrip("/")
        if external and internal and external != internal and url and url.startswith(external + "/"):
            return internal + url[len(external):]
        return url

    def write_mcp_config(self, mcp_servers: list[dict]) -> Path:
        """Generate .mcp.json for the agent session."""
        mcp_config = {"mcpServers": {}}

        for server in mcp_servers:
            slug = server["slug"]
            if server.get("transport") in ("http", "streamable-http"):
                http_cfg = {
                    "type": "http",
                    "url": self._to_internal_url(server["url"]),
                }
                if server.get("user_id"):
                    http_cfg["headers"] = {"X-User-ID": str(server["user_id"])}
                mcp_config["mcpServers"][slug] = http_cfg
            else:
                server_config = {
                    "command": server["command"],
                    "args": server.get("args", []),
                }
                env = server.get("env", {})
                if env:
                    server_config["env"] = env
                mcp_config["mcpServers"][slug] = server_config

        config_path = self.workspace_path / ".mcp.json"
        config_path.write_text(json.dumps(mcp_config, indent=2))

        # Also write Gemini-compatible MCP config (.gemini/settings.json)
        gemini_mcp = {}
        for name, cfg in mcp_config["mcpServers"].items():
            if cfg.get("type") in ("http", "streamable-http"):
                gemini_mcp[name] = {"httpUrl": cfg["url"]}
                if cfg.get("headers"):
                    gemini_mcp[name]["headers"] = cfg["headers"]
            else:
                gemini_mcp[name] = {
                    "command": cfg.get("command", ""),
                    "args": cfg.get("args", []),
                    "env": cfg.get("env", {}),
                }
        gemini_dir = self.workspace_path / ".gemini"
        gemini_dir.mkdir(exist_ok=True)
        gemini_settings = {"mcpServers": gemini_mcp}
        (gemini_dir / "settings.json").write_text(json.dumps(gemini_settings, indent=2))

        # Also write Codex-compatible MCP config (.codex/config.toml)
        # Codex reads project-scoped config from .codex/config.toml in CWD.
        # This is the only source of MCP servers for Codex — no global definitions.
        codex_lines = []
        for name, cfg in mcp_config["mcpServers"].items():
            codex_lines.append(f"[mcp_servers.{name}]")
            if cfg.get("type") in ("http", "streamable-http", "sse"):
                url = cfg["url"]
                # Codex doesn't support custom HTTP headers — embed user_id as
                # a query param instead so the MCP middleware can read it.
                user_id = (cfg.get("headers") or {}).get("X-User-ID")
                if user_id:
                    url = f"{url}?user_id={user_id}"
                codex_lines.append(f'url = "{url}"')
            else:
                codex_lines.append(f'command = "{cfg["command"]}"')
                if cfg.get("args"):
                    args_toml = ", ".join(f'"{a}"' for a in cfg["args"])
                    codex_lines.append(f"args = [{args_toml}]")
                if cfg.get("env"):
                    env_pairs = ", ".join(f'{k} = "{v}"' for k, v in cfg["env"].items())
                    codex_lines.append(f"env = {{{env_pairs}}}")
            codex_lines.append("")
        codex_dir = self.workspace_path / ".codex"
        codex_dir.mkdir(exist_ok=True)
        (codex_dir / "config.toml").write_text("\n".join(codex_lines))

        logger.debug("mcp_config_written session_id=%s path=%s servers=%s", self.session_id, config_path, len(mcp_servers))
        return config_path

    def write_system_prompt_file(self, prompt: str) -> Path:
        """Write the effective system prompt to system_prompt.md in workspace.

        Used by Codex (experimental_instructions_file) and Gemini (GEMINI_SYSTEM_MD).
        Claude Code uses --append-system-prompt directly without a file.
        """
        path = self.workspace_path / "system_prompt.md"
        path.write_text(prompt)
        logger.debug("system_prompt_file_written session_id=%s path=%s", self.session_id, path)
        return path

    def cleanup(self):
        """Remove workspace directory."""
        if self.workspace_path.exists():
            shutil.rmtree(self.workspace_path, ignore_errors=True)
            logger.debug("workspace_cleaned session_id=%s path=%s", self.session_id, self.workspace_path)

    def get_raw_output_path(self) -> Path:
        """Path for raw agent output."""
        path = self.workspace_path / "raw_output.jsonl"
        return path
