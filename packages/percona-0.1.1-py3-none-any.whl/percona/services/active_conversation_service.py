"""Service for managing the single permanent conversation per user with agent session rotation."""

from __future__ import annotations

import logging
import uuid

from sqlalchemy import select, func as sa_func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from percona.config import AGENT_CONTEXT_WINDOWS, settings
from percona.models import AgentType
from percona.models.conversations import (
    Conversation,
    ConversationMcpServer,
    ConversationMessage,
    ConversationSummary,
)
from percona.services.conversation_service import get_channel_agent_defaults
from percona.services.mcp_service import get_default_mcp_ids

logger = logging.getLogger(__name__)


async def get_or_create_active_conversation(
    db: AsyncSession,
    user_id: uuid.UUID,
) -> Conversation:
    """Return the single permanent conversation for a user, creating one if none exists."""
    stmt = (
        select(Conversation)
        .where(Conversation.user_id == user_id, Conversation.is_active.is_(True))
        .options(
            selectinload(Conversation.mcp_servers),
            selectinload(Conversation.memory_files),
        )
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if conversation:
        return conversation

    # Create permanent conversation with defaults
    defaults = await get_channel_agent_defaults(db, user_id)
    agent_type_str = defaults.get("agent_type", settings.default_agent_type)
    system_prompt = defaults.get("system_prompt", "You are a helpful AI assistant.")

    conversation = Conversation(
        user_id=user_id,
        title="New Chat",
        agent_type=AgentType(agent_type_str),
        system_prompt=system_prompt,
        agent_settings=defaults.get("agent_settings", {}),
        pre_run_context={"inject_skills": True, "inject_memories": True},
        is_active=True,
    )
    db.add(conversation)
    await db.flush()

    for mid in await get_default_mcp_ids(db):
        db.add(ConversationMcpServer(conversation_id=conversation.id, mcp_server_id=mid))

    await db.flush()
    logger.info("active_conversation_created user_id=%s conversation_id=%s", user_id, conversation.id)
    return conversation


async def get_context_usage(conversation: Conversation, threshold_override: float | None = None) -> dict:
    """Calculate context usage from agent-reported tokens_remaining_pct.

    Args:
        conversation: The conversation to check.
        threshold_override: If provided, use this instead of looking up ProjectSettings.
            Falls back to config default (0.80) if not provided and no user setting exists.
    """
    agent_type_str = conversation.agent_type.value
    context_window = conversation.context_window or AGENT_CONTEXT_WINDOWS.get(agent_type_str, 200_000)

    remaining_pct = conversation.tokens_remaining_pct
    if remaining_pct is not None and remaining_pct < 100.0:
        usage_percent = (100.0 - remaining_pct) / 100.0
    else:
        total_tokens = conversation.total_input_tokens + conversation.total_output_tokens
        usage_percent = total_tokens / context_window if context_window > 0 else 0.0

    threshold = threshold_override if threshold_override is not None else settings.context_rotation_threshold
    should_rotate = usage_percent >= threshold

    return {
        "total_tokens": conversation.total_input_tokens + conversation.total_output_tokens,
        "context_window": context_window,
        "usage_percent": round(usage_percent, 4),
        "tokens_remaining_pct": round(remaining_pct, 2) if remaining_pct is not None else None,
        "should_rotate": should_rotate,
        "rotation_threshold": threshold,
        "agent_type": agent_type_str,
    }


async def should_rotate(conversation: Conversation, db: AsyncSession | None = None) -> bool:
    """Check if the conversation has exceeded the rotation threshold.

    If db is provided, reads the user's custom threshold from ProjectSettings.
    Otherwise falls back to the global config default.
    """
    threshold = None
    if db is not None:
        from percona.models.integrations import ProjectSettings
        result = await db.execute(
            select(ProjectSettings).where(ProjectSettings.user_id == conversation.user_id)
        )
        ps = result.scalar_one_or_none()
        if ps and ps.context_rotation_threshold is not None:
            threshold = ps.context_rotation_threshold
    usage = await get_context_usage(conversation, threshold_override=threshold)
    return usage["should_rotate"]


async def rotate_session(
    db: AsyncSession,
    conversation: Conversation,
    summary: str,
) -> None:
    """Rotate the agent session within the same conversation.

    This does NOT create a new conversation. It:
    1. Saves the summary to conversation_summaries
    2. Clears agent_native_session_id (next turn starts fresh agent session)
    3. Resets token counters and context usage
    4. Marks the compaction turn messages as internal (hidden from UI)

    The conversation ID never changes. The user sees one continuous chat.
    Caller should commit.
    """
    total_tokens = conversation.total_input_tokens + conversation.total_output_tokens

    # 1. Save summary (skip if compact_session MCP tool already saved one recently)
    existing = await db.execute(
        select(ConversationSummary)
        .where(
            ConversationSummary.conversation_id == conversation.id,
            ConversationSummary.token_count_at_compaction == total_tokens,
        )
        .limit(1)
    )
    if not existing.scalar_one_or_none():
        db.add(ConversationSummary(
            user_id=conversation.user_id,
            conversation_id=conversation.id,
            summary=summary,
            token_count_at_compaction=total_tokens,
        ))

    # 2. Mark the compaction turn messages as internal (hidden from UI).
    # The compaction turn is the last turn_sequence in the conversation.
    last_turn_result = await db.execute(
        select(sa_func.max(ConversationMessage.turn_sequence))
        .where(ConversationMessage.conversation_id == conversation.id)
    )
    last_turn = last_turn_result.scalar()
    if last_turn is not None:
        from sqlalchemy import update
        await db.execute(
            update(ConversationMessage)
            .where(
                ConversationMessage.conversation_id == conversation.id,
                ConversationMessage.turn_sequence == last_turn,
            )
            .values(status="internal")
        )

    # 3. Clear agent session — next turn starts a fresh agent session
    conversation.agent_native_session_id = None

    # 4. Reset token counters (fresh agent session = fresh context window)
    conversation.tokens_remaining_pct = 100.0
    conversation.context_window = AGENT_CONTEXT_WINDOWS.get(conversation.agent_type.value, 200_000)

    logger.info(
        "session_rotated conversation_id=%s tokens_at_rotation=%d summary_len=%d",
        conversation.id, total_tokens, len(summary),
    )


async def start_new_conversation(
    db: AsyncSession,
    user_id: uuid.UUID,
) -> Conversation:
    """Archive the current active conversation and create a fresh one.

    The old conversation is deactivated (is_active=False) but preserved
    with all its messages. A new empty conversation is created with
    the same settings (agent type, MCP servers, system prompt).
    Caller should commit.
    """
    # Find and deactivate current active conversation
    stmt = (
        select(Conversation)
        .where(Conversation.user_id == user_id, Conversation.is_active.is_(True))
        .options(
            selectinload(Conversation.mcp_servers),
            selectinload(Conversation.memory_files),
        )
    )
    result = await db.execute(stmt)
    old_conversation = result.scalar_one_or_none()

    # Capture MCP server IDs before any state changes
    old_mcp_ids: set[uuid.UUID] = set()
    if old_conversation:
        old_mcp_ids = {ms.id for ms in old_conversation.mcp_servers}
        old_conversation.is_active = False
        # Auto-title if still "New Chat"
        if old_conversation.title == "New Chat":
            old_conversation.title = "Chat (archived)"
        await db.flush()
        logger.info(
            "conversation_archived user_id=%s old_id=%s",
            user_id, old_conversation.id,
        )

    # Create fresh conversation with same defaults
    new_conversation = await get_or_create_active_conversation(db, user_id)

    # Copy MCP server associations from old conversation
    if old_mcp_ids:
        # Reload new conversation's MCP servers
        await db.refresh(new_conversation, ["mcp_servers"])
        new_mcp_ids = {ms.id for ms in new_conversation.mcp_servers}
        for mid in old_mcp_ids - new_mcp_ids:
            db.add(ConversationMcpServer(conversation_id=new_conversation.id, mcp_server_id=mid))
        await db.flush()

    logger.info(
        "new_conversation_created user_id=%s new_id=%s",
        user_id, new_conversation.id,
    )
    return new_conversation


async def get_latest_summary(
    db: AsyncSession,
    conversation: Conversation,
) -> str | None:
    """Get the most recent (and best) summary for this conversation."""
    stmt = (
        select(ConversationSummary.summary)
        .where(ConversationSummary.conversation_id == conversation.id)
        .order_by(
            sa_func.length(ConversationSummary.summary).desc(),
        )
        .limit(1)
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()
