from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "Percona"
    debug: bool = False
    log_level: str = "INFO"

    # Database
    database_url: str = "postgresql+asyncpg://percona:percona@percona-db:5432/percona"
    database_echo: bool = False

    # Redis
    redis_url: str = "redis://percona-redis:6379/0"

    # Celery
    celery_broker_url: str = "redis://percona-redis:6379/1"
    celery_result_backend: str = "redis://percona-redis:6379/2"

    # Agent defaults
    default_agent_type: str = "claude-code"
    agent_timeout_seconds: int = 600
    workspace_base_path: str = "/tmp/percona/workspaces"
    workspace_retention_hours: int = 24

    # Notifications
    slack_default_webhook_url: str = ""
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from_email: str = "percona@localhost"
    smtp_use_tls: bool = True

    # Public-facing API URL (used for OAuth callbacks, external links)
    api_base_url: str = "http://localhost:8001"

    # Internal API URL for agent subprocess MCP connections (within Docker network)
    # Agent CLIs run inside containers and can't reach the external HTTPS URL.
    # Defaults to the Docker service name — works from both percona-api and percona-worker.
    internal_api_url: str = "http://percona-api:8001"

    # OAuth — Google
    google_oauth_client_id: str = ""
    google_oauth_client_secret: str = ""

    # OAuth — Slack
    slack_client_id: str = ""
    slack_client_secret: str = ""
    slack_signing_secret: str = ""
    slack_app_token: str = ""   # xapp- token for Socket Mode (no public URL needed)
    slack_webhook_base_url: str = ""   # Override tunnel URL; auto-detected from /tunnel/url if empty
    slack_default_agent_type: str = "claude-code"
    slack_default_system_prompt: str = "You are a helpful personal AI assistant."
    # OAuth — Microsoft
    microsoft_oauth_client_id: str = ""
    microsoft_oauth_client_secret: str = ""
    microsoft_oauth_tenant_id: str = "common"  # Azure AD tenant ID, "common", or "consumers"

    oauth_encryption_key: str = ""   # Fernet key; generate with: python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
    oauth_callback_base_url: str = ""   # Public URL for OAuth callback (defaults to api_base_url if empty)
    frontend_url: str = "http://localhost:3000"   # Post-OAuth redirect target

    # Auth
    api_key: str = ""  # legacy — kept for backward compat
    jwt_secret_key: str = "change-me-in-production-use-a-long-random-secret"
    admin_email: str = "admin@percona.ai"
    admin_password: str = "admin123"
    google_signin_redirect_uri: str = ""  # defaults to {api_base_url}/api/auth/google/callback

    # CORS
    cors_origins: list[str] = ["http://localhost:3000"]

    # Frontend (static export dir; auto-detected if empty)
    frontend_dir: str = ""

    # S3 / Storage
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_region: str = "us-east-1"
    s3_bucket_name: str = "eduwise-storage-prod"
    s3_key_prefix: str = "percona"
    s3_endpoint_url: str | None = None
    s3_public_url_base: str = "https://eduwise.storage.msrashed.com"
    max_upload_size_mb: int = 50
    max_artifact_size_mb: int = 200

    # Transcription service
    transcription_service_url: str = "http://127.0.0.1:8090"

    # Telegram channel
    telegram_enabled: bool = False
    telegram_bot_token: str = ""
    telegram_chat_id: int | None = None
    telegram_default_agent_type: str = "claude-code"
    telegram_default_system_prompt: str = "You are a helpful personal AI assistant."
    telegram_webhook_secret: str = ""
    telegram_webhook_base_url: str = ""
    telegram_drain_timeout_seconds: float = 30.0
    telegram_queue_maxsize: int = 100
    telegram_edit_debounce_seconds: float = 0.5
    telegram_api_timeout_seconds: float = 10.0
    telegram_user_id: str = ""  # UUID string; empty = first project in DB

    # WhatsApp channel (via neonize / whatsmeow)
    # Per-user config (allowed_jids, default_agent_type, default_system_prompt)
    # is stored in ConnectedAccount.provider_metadata — configured from the integrations page.
    # Always enabled — adapter starts with active ConnectedAccounts from DB (no-op if none).
    whatsapp_session_db: str = "/data/whatsapp/session.db"
    whatsapp_queue_maxsize: int = 100
    whatsapp_drain_timeout_seconds: float = 30.0

    # Context rotation
    context_rotation_threshold: float = 0.80  # rotate at 80% context usage

    model_config = {"env_prefix": "PERCONA_", "env_file": ".env"}


settings = Settings()

# Context window sizes per agent type (in tokens)
AGENT_CONTEXT_WINDOWS: dict[str, int] = {
    "claude-code": 200_000,
    "gemini": 1_000_000,
    "codex": 200_000,
}
