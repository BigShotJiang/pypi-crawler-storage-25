"""Application service for task management.

Encapsulates task use-cases: create, update, list, get, delete, trigger.
Decouples the HTTP layer from SQLAlchemy and Celery so alternative runners
(e.g. NoOpTaskRunner) can be injected for tests without code changes.
"""
import logging
import uuid
from abc import ABC, abstractmethod

from percona.context import get_user_id
from percona.infrastructure.repos.task_repo import TaskRepository
from percona.models import Task
from percona.schemas import TaskCreate, TaskTriggerResponse, TaskUpdate

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Task runner port
# ---------------------------------------------------------------------------


class TaskRunnerPort(ABC):
    """Abstracts task execution so HTTP code never imports Celery directly."""

    @abstractmethod
    def trigger(
        self, 
        task_id: str, 
        session_id: str, 
        trigger_source: str = "manual",
        webhook_event_id: str | None = None,
        webhook_payload: dict | None = None,
        idempotency_key: str | None = None,
    ) -> None: ...


class CeleryTaskRunner(TaskRunnerPort):
    """Production runner — delegates to Celery worker via .delay()."""

    def trigger(
        self, 
        task_id: str, 
        session_id: str, 
        trigger_source: str = "manual",
        webhook_event_id: str | None = None,
        webhook_payload: dict | None = None,
        idempotency_key: str | None = None,
    ) -> None:
        from percona.worker.tasks import run_agent_session  # lazy import to avoid circular deps
        run_agent_session.delay(
            task_id,
            session_id,
            trigger_source=trigger_source,
            idempotency_key=idempotency_key
        )


class NoOpTaskRunner(TaskRunnerPort):
    """Test runner — records invocations without side effects.

    Swap in tests by overriding the `get_tasks_service` dependency:
        app.dependency_overrides[get_tasks_service] = lambda: TasksService(mock_repo, NoOpTaskRunner())
    """

    def __init__(self) -> None:
        self.calls: list[dict] = []

    def trigger(
        self, 
        task_id: str, 
        session_id: str, 
        trigger_source: str = "manual",
        webhook_event_id: str | None = None,
        webhook_payload: dict | None = None,
        idempotency_key: str | None = None,
    ) -> None:
        self.calls.append({
            "task_id": task_id, 
            "session_id": session_id, 
            "trigger_source": trigger_source,
            "webhook_event_id": webhook_event_id,
            "webhook_payload": webhook_payload,
            "idempotency_key": idempotency_key
        })


# ---------------------------------------------------------------------------
# Application service
# ---------------------------------------------------------------------------


class TasksService:
    """Orchestrates task use-cases using a repository and a runner port.

    Does NOT commit — the FastAPI `get_db()` context manager handles that.
    Services only flush when FK integrity requires it.
    """

    def __init__(self, repo: TaskRepository, runner: TaskRunnerPort) -> None:
        self._repo = repo
        self._runner = runner

    async def list_tasks(
        self,
        enabled: bool | None = None,
        agent_type: str | None = None,
        search: str | None = None,
        sort: str = "created_desc",
        created_after=None,
        created_before=None,
        limit: int = 25,
        offset: int = 0,
    ) -> tuple[list[Task], int]:
        tasks = await self._repo.list(
            enabled=enabled, agent_type=agent_type, search=search,
            sort=sort, created_after=created_after, created_before=created_before,
            limit=limit, offset=offset,
        )
        total = await self._repo.count(
            enabled=enabled, agent_type=agent_type, search=search,
            created_after=created_after, created_before=created_before,
        )
        return tasks, total

    async def get_stats(self) -> dict:
        return await self._repo.get_stats()

    async def get_task(self, task_id: uuid.UUID) -> Task:
        task = await self._repo.get_with_relations(task_id)
        if not task:
            raise KeyError(f"Task {task_id} not found")
        return task

    async def create_task(self, data: TaskCreate, user_id: uuid.UUID) -> Task:
        task = Task(
            id=uuid.uuid4(),
            name=data.name,
            description=data.description,
            template_id=data.template_id,
            cron_schedule=data.cron_schedule,
            agent_type=data.agent_type,
            system_prompt=data.system_prompt,
            prompt=data.prompt,
            timeout_seconds=data.timeout_seconds,
            max_retries=data.max_retries,
            enabled=data.enabled,
            auto_archive_artifact=data.auto_archive_artifact,
            user_id=user_id,
        )
        await self._repo.add(task)
        await self._repo.flush()  # satisfies FK constraint before junction inserts

        mcp_ids = data.mcp_server_ids if data.mcp_server_ids else await self._repo.get_default_mcp_ids()
        await self._repo.sync_relations(
            task.id, mcp_ids, None, data.notification_channel_ids, data.memory_file_ids
        )
        await self._repo.flush()

        logger.info("task_created task_id=%s name=%s", task.id, task.name)
        result = await self._repo.get_with_relations(task.id)
        assert result is not None  # just created, must exist within transaction
        return result

    async def update_task(self, task_id: uuid.UUID, data: TaskUpdate) -> Task:
        task = await self._repo.get_by_id(task_id)
        if not task:
            raise KeyError(f"Task {task_id} not found")

        update_data = data.model_dump(exclude_unset=True)

        # Separate relation fields from scalar fields
        relation_keys = ("mcp_server_ids", "notification_channel_ids", "memory_file_ids")
        relation_fields: dict = {}
        for key in relation_keys:
            if key in update_data:
                relation_fields[key] = update_data.pop(key)

        for key, value in update_data.items():
            setattr(task, key, value)

        if relation_fields:
            await self._repo.sync_relations(
                task_id,
                relation_fields.get("mcp_server_ids"),
                None,
                relation_fields.get("notification_channel_ids"),
                relation_fields.get("memory_file_ids"),
            )

        await self._repo.flush()
        logger.info("task_updated task_id=%s", task_id)
        result = await self._repo.get_with_relations(task_id)
        assert result is not None
        return result

    async def delete_task(self, task_id: uuid.UUID) -> None:
        task = await self._repo.get_by_id(task_id)
        if not task:
            raise KeyError(f"Task {task_id} not found")
        await self._repo.delete(task)
        logger.info("task_deleted task_id=%s", task_id)

    async def bulk_delete_tasks(self, task_ids: list[uuid.UUID]) -> tuple[int, list[str]]:
        deleted = 0
        failed: list[str] = []
        tasks = await self._repo.get_by_ids(task_ids)
        found_ids = {t.id for t in tasks}
        for task in tasks:
            try:
                await self._repo.delete(task)
                deleted += 1
            except Exception:
                failed.append(str(task.id))
        for tid in task_ids:
            if tid not in found_ids:
                failed.append(str(tid))
        logger.info("bulk_delete_tasks deleted=%s failed=%s", deleted, len(failed))
        return deleted, failed

    async def clone_task(self, task_id: uuid.UUID, user_id: uuid.UUID) -> Task:
        task = await self._repo.get_with_relations(task_id)
        if not task:
            raise KeyError(f"Task {task_id} not found")
        new_task = Task(
            id=uuid.uuid4(),
            name=f"Copy of {task.name}",
            description=task.description,
            template_id=task.template_id,
            cron_schedule=task.cron_schedule,
            agent_type=task.agent_type,
            system_prompt=task.system_prompt,
            prompt=task.prompt,
            timeout_seconds=task.timeout_seconds,
            max_retries=task.max_retries,
            enabled=False,
            agent_settings=task.agent_settings,
            pre_run_context=task.pre_run_context,
            user_id=user_id,
        )
        await self._repo.add(new_task)
        await self._repo.flush()
        mcp_ids = [s.id for s in task.mcp_servers]
        notif_ids = [n.id for n in task.notification_channels]
        mem_ids = [m.id for m in task.memory_files]
        await self._repo.sync_relations(new_task.id, mcp_ids, None, notif_ids, mem_ids)
        await self._repo.flush()
        logger.info("task_cloned original_id=%s new_id=%s", task_id, new_task.id)
        result = await self._repo.get_with_relations(new_task.id)
        assert result is not None
        return result

    async def trigger_task(
        self, 
        task_id: uuid.UUID, 
        trigger_source: str = "manual",
        webhook_event_id: str | None = None,
        webhook_payload: dict | None = None,
        idempotency_key: str | None = None,
    ) -> TaskTriggerResponse:
        task = await self._repo.get_by_id(task_id)
        if not task:
            raise KeyError(f"Task {task_id} not found")

        session_id = uuid.uuid4()

        # Create session record immediately so the frontend can poll for it
        # without getting 404 while the worker is busy with another task.
        await self._repo.create_pending_session(session_id, task, trigger_source, idempotency_key)
        await self._repo.flush()

        self._runner.trigger(
            str(task_id),
            str(session_id),
            trigger_source=trigger_source,
            webhook_event_id=webhook_event_id,
            webhook_payload=webhook_payload,
            idempotency_key=idempotency_key
        )
        logger.info("task_triggered task_id=%s session_id=%s idempotency_key=%s", task_id, session_id, idempotency_key)
        return TaskTriggerResponse(
            session_id=session_id,
            message=f"Session {session_id} queued for task '{task.name}'",
        )
