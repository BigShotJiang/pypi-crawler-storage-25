from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ReportCreate(BaseModel):
    title: str = Field(..., max_length=500)
    content_md: str | None = None
    content_html: str | None = None
    task_id: uuid.UUID | None = None
    session_id: uuid.UUID | None = None


class ReportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    user_id: uuid.UUID
    task_id: uuid.UUID | None
    session_id: uuid.UUID | None
    title: str
    s3_url: str | None
    created_at: datetime
    updated_at: datetime


class ReportListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str
    s3_url: str | None
    created_at: datetime
    task_id: uuid.UUID | None
    task_name: str | None = None  # Joined field
    session_id: uuid.UUID | None


class SkillCreate(BaseModel):
    name: str = Field(..., max_length=255)
    slug: str = Field(..., max_length=100)
    description: str
    domain: str = Field(..., max_length=100)
    content: str
    entry_type: str = "skill"
    session_id: uuid.UUID | None = None


class SkillUpdate(BaseModel):
    name: str | None = Field(None, max_length=255)
    description: str | None = None
    domain: str | None = Field(None, max_length=100)
    content: str | None = None
    entry_type: str | None = None


class SkillOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    user_id: uuid.UUID
    name: str
    slug: str
    description: str
    domain: str
    content: str
    entry_type: str
    session_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime


class SkillStats(BaseModel):
    total: int
    by_domain: dict[str, int]
