from __future__ import annotations
import uuid
from datetime import datetime
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict

from percona.schemas.conversations import ConversationStats, DailySessionStat, TopFailingTool
from percona.schemas.content import SkillStats
from percona.schemas.notifications import NotificationDeliveryStats


class ReminderStats(BaseModel):
    total: int
    by_status: dict[str, int]
    by_channel: dict[str, int]
    failure_rate: float



class TodoStats(BaseModel):
    total: int
    by_status: dict[str, int]
    by_priority: dict[str, int]
    overdue: int
    completion_rate: float



class StorageStats(BaseModel):
    total_files: int
    total_size_bytes: int
    by_folder: dict[str, int]



class DashboardStats(BaseModel):
    total_tasks: int
    enabled_tasks: int
    total_sessions_today: int
    sessions_by_status: dict[str, int]
    # reliability
    session_failures_today: int
    tool_call_total_today: int
    tool_call_failures_today: int
    # performance
    avg_session_duration_ms: float | None
    total_cost_today: float
    total_tokens_today: int
    # trends
    sessions_last_7_days: list[DailySessionStat]
    top_failing_tools: list[TopFailingTool]
    # breakdowns
    sessions_by_agent: dict[str, int]
    # entity stats
    reminders: ReminderStats
    todos: TodoStats
    conversations: ConversationStats
    notifications: NotificationDeliveryStats
    skills: SkillStats
    storage: StorageStats



class ReminderCreate(BaseModel):
    name: str
    description: str | None = None
    channels: list[str]
    scheduled_at: datetime | None = None
    extra_schedules: list[str] | None = None  # additional ISO8601 trigger times



class ReminderUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    channels: list[str] | None = None
    scheduled_at: datetime | None = None



class ReminderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    description: str | None
    channels: list[str]
    scheduled_at: datetime | None
    extra_schedules: list[str] | None
    sent_at: datetime | None
    status: str
    error_message: str | None
    session_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime


# --- Todo Items ---


VALID_TODO_STATUSES = {"todo", "in_progress", "done", "cancelled"}
VALID_TODO_PRIORITIES = {"low", "medium", "high", "urgent"}



class TodoCreate(BaseModel):
    title: str
    description: str | None = None
    notes: str | None = None
    context: str | None = None
    status: str = "todo"
    priority: str = "medium"
    tags: list[str] = []
    due_date: datetime | None = None
    session_id: uuid.UUID | None = None



class TodoUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    notes: str | None = None
    context: str | None = None
    status: str | None = None
    priority: str | None = None
    tags: list[str] | None = None
    due_date: datetime | None = None



class TodoOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str
    description: str | None
    notes: str | None
    context: str | None
    status: str
    priority: str
    tags: list[str]
    due_date: datetime | None
    completed_at: datetime | None
    session_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime


# --- Stored Files ---



class StoredFileOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    filename: str
    original_filename: str
    content_type: str
    file_size_bytes: int
    s3_url: str
    folder: str | None
    thumbnail_url: str | None
    is_optimized: bool
    session_id: uuid.UUID | None
    conversation_id: uuid.UUID | None
    expires_at: datetime | None
    uploaded_at: datetime



class PresignedUploadRequest(BaseModel):
    filename: str
    content_type: str | None = None
    folder: str | None = None



class PresignedUploadResponse(BaseModel):
    s3_key: str
    upload_url: str
    public_url: str
    expires_in: int
    content_type: str



class StorageQuotaResponse(BaseModel):
    used_bytes: int
    used_formatted: str
    file_count: int



class BulkDeleteRequest(BaseModel):
    file_ids: list[uuid.UUID]



class BulkDeleteResponse(BaseModel):
    deleted_count: int
    failed_ids: list[str]


# --- Conversations ---

VALID_REMINDER_CHANNELS = {"email", "slack", "pushover"}

DashboardStats.model_rebuild()
