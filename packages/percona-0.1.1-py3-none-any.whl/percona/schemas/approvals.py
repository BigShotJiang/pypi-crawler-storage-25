from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict

from percona.models.approvals import ApprovalStatus


class ApprovalOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    user_id: uuid.UUID
    session_id: uuid.UUID
    title: str
    description: str
    approval_type: str
    status: ApprovalStatus
    decided_by: str | None = None
    decided_at: datetime | None = None
    decision_note: str | None = None
    requested_by_agent_id: uuid.UUID | None = None
    requested_by_user: str | None = None
    entity_type: str | None = None
    entity_id: uuid.UUID | None = None
    payload: dict | None = None
    expires_at: datetime | None = None
    resumed_conversation_id: uuid.UUID | None = None
    created_at: datetime
    updated_at: datetime


class ApprovalDecision(BaseModel):
    decided_by: str = "operator"
    decision_note: str = ""


class ApprovalCommentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    approval_id: uuid.UUID
    author_type: str
    author_id: str
    body: str
    created_at: datetime


class ApprovalCommentCreate(BaseModel):
    author_type: str = "user"
    author_id: str = "operator"
    body: str
