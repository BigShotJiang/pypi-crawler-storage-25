from __future__ import annotations
import uuid
from datetime import datetime
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict

from percona.models import (
    AgentType,
    MessageRole,
    NotificationChannelType,
    SessionStatus,
    ToolCallStatus,
    TriggerSource,
)

if TYPE_CHECKING:
    pass

class SessionStatsOut(BaseModel):
    total: int
    by_status: dict[str, int]
    by_agent: dict[str, int]
    by_trigger: dict[str, int]


class SessionBulkDeleteRequest(BaseModel):
    file_ids: list[uuid.UUID]


class SessionBulkDeleteResponse(BaseModel):
    deleted_count: int
    failed_ids: list[str]


# --- Sessions ---



class SessionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    task_id: uuid.UUID | None
    task_name: str | None = None
    status: SessionStatus
    agent_type: AgentType
    trigger_source: TriggerSource = TriggerSource.MANUAL
    started_at: datetime | None
    finished_at: datetime | None
    duration_ms: int | None
    input_tokens: int
    output_tokens: int
    total_tokens: int
    cost_usd: float
    summary: str | None
    total_messages_count: int = 0
    total_tool_calls_count: int = 0
    success_tool_calls_count: int = 0
    failed_tool_calls_count: int = 0
    error_message: str | None
    error_details: str | None = None
    agent_native_session_id: str | None = None
    created_at: datetime



class SessionArtifactReport(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    title: str
    created_at: datetime



class SessionArtifactSkill(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    slug: str
    domain: str
    description: str
    created_at: datetime



class SessionArtifactNotification(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    channel_type: NotificationChannelType
    title: str
    recipient: str
    status: str
    sent_at: datetime



class SessionDetailOut(SessionOut):
    system_prompt_snapshot: str | None = None
    prompt_snapshot: str | None = None
    messages: list["MessageOut"] = []
    tool_calls: list["ToolCallOut"] = []
    reports: list["SessionArtifactReport"] = []
    skills: list["SessionArtifactSkill"] = []
    notification_logs: list["SessionArtifactNotification"] = []


# --- Messages ---



class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    role: MessageRole
    content: str
    sequence: int
    created_at: datetime


# --- Tool Calls ---



class ToolCallOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    tool_name: str
    tool_server: str | None
    input_params: dict | None
    output_result: str | None
    status: ToolCallStatus
    duration_ms: int | None
    sequence: int
    created_at: datetime


class DailySessionStat(BaseModel):
    date: str
    total: int
    failed: int



class TopFailingTool(BaseModel):
    tool_name: str
    failures: int
    total: int



class ConversationStats(BaseModel):
    total: int
    by_agent: dict[str, int]
    total_cost_usd: float
    total_tokens: int



class ConversationCreate(BaseModel):
    title: str = "New Chat"
    agent_type: str = "claude-code"
    system_prompt: str = "You are a helpful AI assistant."
    agent_settings: dict = {}
    pre_run_context: dict = {"inject_skills": True}
    mcp_server_ids: list[uuid.UUID] = []
    memory_file_ids: list[uuid.UUID] = []


class ConversationUpdate(BaseModel):
    title: str | None = None
    agent_type: str | None = None
    system_prompt: str | None = None
    agent_settings: dict | None = None
    pre_run_context: dict | None = None
    mcp_server_ids: list[uuid.UUID] | None = None



class ConversationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str
    agent_type: str
    system_prompt: str
    agent_settings: dict
    pre_run_context: dict
    total_input_tokens: int
    total_output_tokens: int
    total_cost_usd: float
    mcp_server_ids: list[uuid.UUID] = []
    memory_file_ids: list[uuid.UUID] = []
    created_at: datetime
    updated_at: datetime

    @classmethod
    def from_orm_with_relations(cls, obj) -> "ConversationResponse":
        """Build response from ORM object, extracting ids from relationships."""
        data = {c.key: getattr(obj, c.key) for c in obj.__table__.columns}
        data["mcp_server_ids"] = [s.id for s in obj.mcp_servers] if obj.mcp_servers else []
        data["memory_file_ids"] = [mf.id for mf in obj.memory_files] if obj.memory_files else []
        return cls.model_validate(data)

    @classmethod
    def from_orm_with_mcp(cls, obj) -> "ConversationResponse":
        """Alias kept for backwards compatibility."""
        return cls.from_orm_with_relations(obj)


# --- Webhooks ---


from percona.schemas.content import ReportOut, SkillOut
from percona.schemas.notifications import NotificationLogOut
SessionDetailOut.model_rebuild()
