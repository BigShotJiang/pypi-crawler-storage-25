from __future__ import annotations
import uuid
from datetime import datetime
from pydantic import BaseModel, ConfigDict, field_validator

from percona.models.users import AccountStatus, UserRole


class UserCreate(BaseModel):
    name: str
    slug: str
    email: str
    password: str
    full_name: str | None = None
    role: UserRole = UserRole.USER
    color: str | None = "#6366f1"
    description: str | None = None


class UserCreateAdmin(BaseModel):
    """Admin-initiated user creation with explicit role and password."""
    email: str
    password: str
    full_name: str | None = None
    role: UserRole = UserRole.USER

    @field_validator("role")
    @classmethod
    def validate_role(cls, v: UserRole) -> UserRole:
        if v not in UserRole:
            raise ValueError(f"Invalid role: {v}. Must be one of: {', '.join(UserRole)}")
        return v


class UserUpdate(BaseModel):
    name: str | None = None
    slug: str | None = None
    full_name: str | None = None
    color: str | None = None
    description: str | None = None
    role: UserRole | None = None
    is_active: bool | None = None
    account_status: AccountStatus | None = None
    password: str | None = None  # Admin can reset password


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    email: str
    full_name: str | None
    role: str
    is_active: bool
    account_status: str
    auth_provider: str
    avatar_url: str | None = None
    google_id: str | None = None
    color: str | None
    description: str | None
    last_login_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


# Backward compatibility aliases
ProjectCreate = UserCreate
ProjectUpdate = UserUpdate
ProjectOut = UserOut
