from __future__ import annotations
import uuid
from datetime import datetime
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict

from percona.models import (
    AgentType,
)

if TYPE_CHECKING:
    from percona.schemas.integrations import McpServerOut
    from percona.schemas.memory_files import MemoryFileOut
    from percona.schemas.notifications import NotificationChannelOut


class TaskTemplateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    description: str
    default_cron: str
    default_agent_type: AgentType
    system_prompt: str
    default_mcp_servers: list | None = None
    default_timeout_seconds: int
    icon: str
    color: str
    created_at: datetime


# --- MCP Servers ---



class TaskCreate(BaseModel):
    name: str
    description: str | None = None
    template_id: uuid.UUID | None = None
    cron_schedule: str | None = None
    agent_type: AgentType = AgentType.CLAUDE_CODE
    system_prompt: str | None = None
    prompt: str
    timeout_seconds: int = 600
    max_retries: int = 0
    enabled: bool = True
    auto_archive_artifact: bool = False
    agent_settings: dict = {}
    pre_run_context: dict = {"inject_skills": True}
    task_memory: str | None = None
    mcp_server_ids: list[uuid.UUID] = []
    notification_channel_ids: list[uuid.UUID] = []
    memory_file_ids: list[uuid.UUID] = []



class TaskUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    cron_schedule: str | None = None
    agent_type: AgentType | None = None
    system_prompt: str | None = None
    prompt: str | None = None
    timeout_seconds: int | None = None
    max_retries: int | None = None
    enabled: bool | None = None
    auto_archive_artifact: bool | None = None
    agent_settings: dict | None = None
    pre_run_context: dict | None = None
    task_memory: str | None = None
    mcp_server_ids: list[uuid.UUID] | None = None
    notification_channel_ids: list[uuid.UUID] | None = None
    memory_file_ids: list[uuid.UUID] | None = None



class TaskOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    description: str | None
    template_id: uuid.UUID | None
    cron_schedule: str | None
    agent_type: AgentType
    system_prompt: str | None
    prompt: str
    timeout_seconds: int
    max_retries: int
    enabled: bool
    auto_archive_artifact: bool
    agent_settings: dict = {}
    pre_run_context: dict = {"inject_skills": True}
    task_memory: str | None = None
    last_run_at: datetime | None
    next_run_at: datetime | None
    created_at: datetime
    updated_at: datetime
    mcp_servers: list[McpServerOut] = []
    notification_channels: list[NotificationChannelOut] = []
    memory_files: list[MemoryFileOut] = []



class TaskListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    description: str | None
    cron_schedule: str | None
    agent_type: AgentType
    enabled: bool
    auto_archive_artifact: bool
    agent_settings: dict = {}
    last_run_at: datetime | None
    next_run_at: datetime | None
    created_at: datetime
    session_count: int = 0



class TaskStatsOut(BaseModel):
    total: int
    enabled: int
    disabled: int
    scheduled: int
    by_agent: dict[str, int]



class TaskTriggerResponse(BaseModel):
    session_id: uuid.UUID
    message: str


class TaskBulkDeleteRequest(BaseModel):
    file_ids: list[uuid.UUID]


class TaskBulkDeleteResponse(BaseModel):
    deleted_count: int
    failed_ids: list[str]


# --- Reports ---


# --- Knowledge Base ---


from percona.schemas.integrations import McpServerOut
from percona.schemas.notifications import NotificationChannelOut
from percona.schemas.memory_files import MemoryFileOut
TaskOut.model_rebuild()
