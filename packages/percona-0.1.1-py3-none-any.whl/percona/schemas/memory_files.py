from __future__ import annotations
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class MemoryFileCreate(BaseModel):
    name: str
    description: str | None = None
    content: str = ""
    destination: str  # e.g. "CLAUDE.md", "AGENTS.md", "GEMINI.md"
    agent_type: str | None = None  # null = all agents; "claude-code" | "codex" | "gemini"



class MemoryFileUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    content: str | None = None
    destination: str | None = None
    agent_type: str | None = None



class MemoryFileOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    description: str | None
    content: str
    destination: str
    agent_type: str | None
    created_at: datetime
    updated_at: datetime
