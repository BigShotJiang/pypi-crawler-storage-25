from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class SecretCreate(BaseModel):
    name: str
    value: str
    description: str | None = None
    provider: str | None = None
    environment: str | None = None


class SecretUpdate(BaseModel):
    name: str | None = None
    value: str | None = None
    description: str | None = None
    provider: str | None = None
    environment: str | None = None


class SecretOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    value: str
    description: str | None
    provider: str | None
    environment: str | None
    created_at: datetime
    updated_at: datetime | None


class SecretListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    description: str | None
    provider: str | None
    environment: str | None
    created_at: datetime
    updated_at: datetime | None
