from __future__ import annotations
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict

from percona.models import (
    NotificationChannelType,
)


class NotificationChannelCreate(BaseModel):
    name: str
    channel_type: NotificationChannelType
    config: dict
    enabled: bool = True



class NotificationChannelUpdate(BaseModel):
    name: str | None = None
    config: dict | None = None
    enabled: bool | None = None



class NotificationChannelOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    channel_type: NotificationChannelType
    config: dict
    enabled: bool
    created_at: datetime
    updated_at: datetime


# --- Settings ---



class NotificationDeliveryStats(BaseModel):
    total: int
    sent: int
    failed: int
    failure_rate: float
    by_channel: dict[str, int]



class NotificationLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    session_id: uuid.UUID | None
    channel_type: NotificationChannelType
    title: str
    content: str
    recipient: str
    status: str
    error_message: str | None
    sent_at: datetime


# --- Connected Accounts (OAuth) ---

