from __future__ import annotations
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class McpServerCreate(BaseModel):
    name: str
    slug: str
    description: str | None = None
    command: str
    args: list | None = None
    env: dict | None = None
    enabled: bool = True



class McpServerUpdate(BaseModel):
    name: str | None = None
    slug: str | None = None
    description: str | None = None
    command: str | None = None
    url: str | None = None
    args: list | None = None
    env: dict | None = None
    enabled: bool | None = None



class McpServerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    description: str | None
    command: str
    args: list | None
    env: dict | None
    enabled: bool
    is_internal: bool = False
    transport: str = "stdio"
    url: str | None = None
    created_at: datetime
    updated_at: datetime


# --- Notification Channels ---



class SettingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    key: str
    value: str
    description: str | None
    updated_at: datetime



class SettingUpdate(BaseModel):
    value: str
    description: str | None = None



class SettingsBatchUpdate(BaseModel):
    settings: dict[str, str]


# --- Dashboard ---


class ConnectedAccountOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    provider: str
    label: str | None
    provider_email: str
    scopes: list[str]
    status: str
    error_message: str | None
    provider_metadata: dict = {}
    last_used_at: datetime | None
    created_at: datetime
    updated_at: datetime



class ConnectedAccountUpdate(BaseModel):
    label: str | None = None
    provider_metadata: dict | None = None



class OAuthInitiateRequest(BaseModel):
    provider: str
    redirect_to: str = "/integrations"



class OAuthInitiateResponse(BaseModel):
    authorization_url: str
    state: str


# --- User Settings ---


class ProjectSettingOut(BaseModel):
    """User-scoped settings for branding, theme, system prompt, and notifications."""
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    user_id: uuid.UUID
    # Branding
    brand_name: str | None = None
    brand_tagline: str | None = None
    brand_logo_url: str | None = None
    brand_favicon_url: str | None = None
    brand_background_url: str | None = None
    # Theme
    theme_preset: str | None = None
    theme_mode: str | None = None
    theme_primary: str | None = None
    theme_primary_foreground: str | None = None
    theme_background: str | None = None
    theme_foreground: str | None = None
    theme_card: str | None = None
    theme_card_foreground: str | None = None
    theme_secondary: str | None = None
    theme_secondary_foreground: str | None = None
    theme_accent: str | None = None
    theme_accent_foreground: str | None = None
    theme_muted: str | None = None
    theme_muted_foreground: str | None = None
    theme_border: str | None = None
    # Agent settings
    global_system_prompt: str | None = None
    compact_prompt: str | None = None
    context_rotation_threshold: float = 0.80
    session_handoff_message_count: int | None = None
    session_handoff_prompt: str | None = None
    channel_agent_defaults: dict | None = None
    # SMTP
    smtp_host: str | None = None
    smtp_port: int | None = None
    smtp_username: str | None = None
    smtp_password: str | None = None
    smtp_from_email: str | None = None
    smtp_use_tls: bool = True
    email_recipients: str | None = None
    # Pushover
    pushover_token: str | None = None
    pushover_user: str | None = None
    # Slack
    slack_webhook_url: str | None = None
    # Telegram
    telegram_bot_token: str | None = None
    # Timestamps
    created_at: datetime
    updated_at: datetime


class ProjectSettingUpdate(BaseModel):
    """Partial update for project settings - all fields optional."""
    # Branding
    brand_name: str | None = None
    brand_tagline: str | None = None
    brand_logo_url: str | None = None
    brand_favicon_url: str | None = None
    brand_background_url: str | None = None
    # Theme
    theme_preset: str | None = None
    theme_mode: str | None = None
    theme_primary: str | None = None
    theme_primary_foreground: str | None = None
    theme_background: str | None = None
    theme_foreground: str | None = None
    theme_card: str | None = None
    theme_card_foreground: str | None = None
    theme_secondary: str | None = None
    theme_secondary_foreground: str | None = None
    theme_accent: str | None = None
    theme_accent_foreground: str | None = None
    theme_muted: str | None = None
    theme_muted_foreground: str | None = None
    theme_border: str | None = None
    # Agent settings
    global_system_prompt: str | None = None
    compact_prompt: str | None = None
    context_rotation_threshold: float | None = None
    session_handoff_message_count: int | None = None
    session_handoff_prompt: str | None = None
    channel_agent_defaults: dict | None = None
    # SMTP
    smtp_host: str | None = None
    smtp_port: int | None = None
    smtp_username: str | None = None
    smtp_password: str | None = None
    smtp_from_email: str | None = None
    smtp_use_tls: bool | None = None
    email_recipients: str | None = None
    # Pushover
    pushover_token: str | None = None
    pushover_user: str | None = None
    # Slack
    slack_webhook_url: str | None = None
    # Telegram
    telegram_bot_token: str | None = None


# --- Reminders ---


VALID_REMINDER_CHANNELS = {"email", "slack", "pushover"}
