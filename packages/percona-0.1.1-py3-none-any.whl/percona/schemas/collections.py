import uuid
from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


VALID_FIELD_TYPES = {"text", "number", "date", "boolean", "select", "url", "email", "tags", "textarea", "reference"}
VALID_COLLECTION_STATUSES = {"active", "archived"}
VALID_ITEM_STATUSES = {"active", "archived", "completed"}


# --- Collection Field schemas ---

class CollectionFieldCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    label: str = Field(..., min_length=1, max_length=255)
    field_type: str = Field(..., min_length=1, max_length=20)
    required: bool = False
    default_value: Optional[str] = None
    options: Optional[list[str]] = None
    placeholder: Optional[str] = Field(None, max_length=255)
    sort_order: int = 0

    @field_validator("field_type")
    @classmethod
    def validate_field_type(cls, v: str) -> str:
        if v not in VALID_FIELD_TYPES:
            raise ValueError(f"Invalid field_type: {v!r}. Allowed: {sorted(VALID_FIELD_TYPES)}")
        return v


class CollectionFieldUpdate(BaseModel):
    label: Optional[str] = Field(None, min_length=1, max_length=255)
    field_type: Optional[str] = Field(None, min_length=1, max_length=20)
    required: Optional[bool] = None
    default_value: Optional[str] = None
    options: Optional[list[str]] = None
    placeholder: Optional[str] = Field(None, max_length=255)
    sort_order: Optional[int] = None

    @field_validator("field_type")
    @classmethod
    def validate_field_type(cls, v: str | None) -> str | None:
        if v is not None and v not in VALID_FIELD_TYPES:
            raise ValueError(f"Invalid field_type: {v!r}. Allowed: {sorted(VALID_FIELD_TYPES)}")
        return v


class CollectionFieldOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    label: str
    field_type: str
    required: bool
    default_value: Optional[str]
    options: Optional[list[str]]
    placeholder: Optional[str]
    sort_order: int
    created_at: datetime
    updated_at: datetime


# --- Collection schemas ---

class CollectionCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    icon: Optional[str] = Field(None, max_length=50)
    color: Optional[str] = Field(None, max_length=20)
    tags: list[str] = []
    fields: list[CollectionFieldCreate] = []
    agent_instructions: Optional[str] = None
    template_slug: Optional[str] = None
    session_id: Optional[uuid.UUID] = None


class CollectionUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    icon: Optional[str] = Field(None, max_length=50)
    color: Optional[str] = Field(None, max_length=20)
    status: Optional[str] = None
    tags: Optional[list[str]] = None
    agent_instructions: Optional[str] = None

    @field_validator("status")
    @classmethod
    def validate_status(cls, v: str | None) -> str | None:
        if v is not None and v not in VALID_COLLECTION_STATUSES:
            raise ValueError(f"Invalid status: {v!r}. Allowed: {sorted(VALID_COLLECTION_STATUSES)}")
        return v


class CollectionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    description: Optional[str]
    icon: Optional[str]
    color: Optional[str]
    status: str
    tags: list[str]
    item_count: int
    agent_instructions: Optional[str]
    template_slug: Optional[str]
    session_id: Optional[uuid.UUID]
    created_at: datetime
    updated_at: datetime
    fields: list[CollectionFieldOut] = []


# --- Collection Item schemas ---

class CollectionItemCreate(BaseModel):
    data: dict[str, Any]
    status: str = "active"
    tags: list[str] = []
    notes: Optional[str] = None
    session_id: Optional[uuid.UUID] = None

    @field_validator("status")
    @classmethod
    def validate_status(cls, v: str) -> str:
        if v not in VALID_ITEM_STATUSES:
            raise ValueError(f"Invalid status: {v!r}. Allowed: {sorted(VALID_ITEM_STATUSES)}")
        return v


class CollectionItemUpdate(BaseModel):
    data: Optional[dict[str, Any]] = None
    status: Optional[str] = None
    tags: Optional[list[str]] = None
    notes: Optional[str] = None

    @field_validator("status")
    @classmethod
    def validate_status(cls, v: str | None) -> str | None:
        if v is not None and v not in VALID_ITEM_STATUSES:
            raise ValueError(f"Invalid status: {v!r}. Allowed: {sorted(VALID_ITEM_STATUSES)}")
        return v


class CollectionItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    collection_id: uuid.UUID
    data: dict[str, Any]
    status: str
    tags: list[str]
    notes: Optional[str]
    session_id: Optional[uuid.UUID]
    created_at: datetime
    updated_at: datetime


class CollectionStatsOut(BaseModel):
    total_items: int
    by_status: dict[str, int] = {}
    by_field: dict[str, Any] = {}
