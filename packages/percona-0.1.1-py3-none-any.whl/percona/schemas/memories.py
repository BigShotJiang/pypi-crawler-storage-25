from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class MemoryCreate(BaseModel):
    entity_type: str = Field(..., max_length=100)
    entity_key: str = Field(..., max_length=255)
    key: str = Field(..., max_length=255)
    value: str | None = None
    value_json: dict | None = None
    tags: list[str] = Field(default=[])
    confidence: float | None = Field(None, ge=0.0, le=1.0)
    created_by: str | None = Field(None, max_length=255)
    source_session_id: uuid.UUID | None = None
    source_task_id: uuid.UUID | None = None


class MemoryUpdate(BaseModel):
    value: str | None = None
    value_json: dict | None = None
    tags: list[str] | None = None
    confidence: float | None = Field(None, ge=0.0, le=1.0)


class MemoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    entity_type: str
    entity_key: str
    key: str
    value: str | None
    value_json: dict | None
    tags: list[str] | None
    confidence: float | None
    created_by: str | None
    source_session_id: uuid.UUID | None
    source_task_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime
