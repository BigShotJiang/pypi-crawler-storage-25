from __future__ import annotations

import enum

_enum_values = lambda e: [m.value for m in e]  # noqa: E731


class AgentType(str, enum.Enum):
    CLAUDE_CODE = "claude-code"
    CODEX = "codex"
    GEMINI = "gemini"



class Severity(str, enum.Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"



class TriggerSource(str, enum.Enum):
    MANUAL = "manual"
    SCHEDULED = "scheduled"
    WEBHOOK = "webhook"


# --- Memory Files ---

