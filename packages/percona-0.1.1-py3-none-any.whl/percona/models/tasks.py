from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from percona.database import Base

_enum_values = lambda e: [m.value for m in e]  # noqa: E731

from typing import TYPE_CHECKING

from percona.models.common import AgentType, Severity

if TYPE_CHECKING:
    from percona.models.common import AgentType, Severity
    from percona.models.integrations import McpServer
    from percona.models.notifications import NotificationChannel
    from percona.models.sessions import Session
    from percona.models.memory_files import MemoryFile


class TaskMcpServer(Base):
    __tablename__ = "task_mcp_servers"

    task_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tasks.id", ondelete="CASCADE"), primary_key=True)
    mcp_server_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("mcp_servers.id", ondelete="CASCADE"), primary_key=True)



class TaskNotificationChannel(Base):
    __tablename__ = "task_notification_channels"

    task_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tasks.id", ondelete="CASCADE"), primary_key=True)
    notification_channel_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("notification_channels.id", ondelete="CASCADE"), primary_key=True)
    min_severity: Mapped[Severity] = mapped_column(Enum(Severity, values_callable=_enum_values), default=Severity.MEDIUM)



class TaskMemoryFile(Base):
    __tablename__ = "task_memory_files"

    task_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tasks.id", ondelete="CASCADE"), primary_key=True)
    memory_file_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("memory_files.id", ondelete="CASCADE"), primary_key=True)


class TaskFile(Base):
    __tablename__ = "task_files"

    task_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tasks.id", ondelete="CASCADE"), primary_key=True)
    stored_file_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("stored_files.id", ondelete="CASCADE"), primary_key=True)


# --- Core Models ---



class TaskTemplate(Base):
    __tablename__ = "task_templates"
    __table_args__ = (
        UniqueConstraint("user_id", "name", name="uq_task_templates_project_name"),
        UniqueConstraint("user_id", "slug", name="uq_task_templates_project_slug"),
    )

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    slug: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    default_cron: Mapped[str] = mapped_column(String(100), nullable=False)
    default_agent_type: Mapped[AgentType] = mapped_column(Enum(AgentType, values_callable=_enum_values), default=AgentType.CLAUDE_CODE)
    system_prompt: Mapped[str] = mapped_column(Text, nullable=False)
    default_mcp_servers: Mapped[list | None] = mapped_column(JSONB, default=list)
    default_timeout_seconds: Mapped[int] = mapped_column(Integer, default=600)
    icon: Mapped[str] = mapped_column(String(50), default="activity")
    color: Mapped[str] = mapped_column(String(20), default="blue")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())



class Task(Base):
    __tablename__ = "tasks"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    template_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("task_templates.id", ondelete="SET NULL"))
    cron_schedule: Mapped[str | None] = mapped_column(String(100), nullable=True)
    agent_type: Mapped[AgentType] = mapped_column(Enum(AgentType, values_callable=_enum_values), default=AgentType.CLAUDE_CODE)
    system_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
    prompt: Mapped[str] = mapped_column(Text, nullable=False)
    timeout_seconds: Mapped[int] = mapped_column(Integer, default=600)
    max_retries: Mapped[int] = mapped_column(Integer, default=0)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    agent_settings: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict, server_default="{}")
    pre_run_context: Mapped[dict] = mapped_column(JSONB, nullable=False, default=lambda: {"inject_skills": True}, server_default='{"inject_skills": true}')
    auto_archive_artifact: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    task_memory: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    next_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    template: Mapped[TaskTemplate | None] = relationship()
    mcp_servers: Mapped[list[McpServer]] = relationship(secondary="task_mcp_servers", back_populates="tasks")
    notification_channels: Mapped[list[NotificationChannel]] = relationship(secondary="task_notification_channels", back_populates="tasks")
    memory_files: Mapped[list["MemoryFile"]] = relationship(secondary="task_memory_files", back_populates="tasks")
    files: Mapped[list["StoredFile"]] = relationship(secondary="task_files")
    sessions: Mapped[list["Session"]] = relationship(back_populates="task", order_by="Session.created_at.desc()", passive_deletes=True)
