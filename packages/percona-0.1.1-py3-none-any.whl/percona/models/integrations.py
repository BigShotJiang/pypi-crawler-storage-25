from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    ARRAY,
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from percona.database import Base

_enum_values = lambda e: [m.value for m in e]  # noqa: E731

from typing import TYPE_CHECKING

from percona.models.common import AgentType

if TYPE_CHECKING:
    from percona.models.common import AgentType
    from percona.models.conversations import Conversation


class OAuthProvider(str, enum.Enum):
    GOOGLE = "google"



class ConnectedAccountStatus(str, enum.Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    REVOKED = "revoked"
    ERROR = "error"



class McpServer(Base):
    __tablename__ = "mcp_servers"
    __table_args__ = (
        UniqueConstraint("user_id", "name", name="uq_mcp_servers_project_name"),
        UniqueConstraint("user_id", "slug", name="uq_mcp_servers_project_slug"),
    )

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    slug: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    command: Mapped[str] = mapped_column(Text, nullable=False)
    args: Mapped[list | None] = mapped_column(JSONB, default=list)
    env: Mapped[dict | None] = mapped_column(JSONB, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    is_internal: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    transport: Mapped[str] = mapped_column(String(20), default="stdio", server_default="'stdio'")
    url: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    tasks: Mapped[list["Task"]] = relationship(secondary="task_mcp_servers", back_populates="mcp_servers")



class Setting(Base):
    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String(255), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


# --- Chat Models ---



class ConnectedAccount(Base):
    __tablename__ = "connected_accounts"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    provider: Mapped[str] = mapped_column(String(50), nullable=False)  # "google"
    label: Mapped[str | None] = mapped_column(String(255))
    provider_email: Mapped[str] = mapped_column(String(255), nullable=False)
    provider_account_id: Mapped[str | None] = mapped_column(String(255))
    scopes: Mapped[list] = mapped_column(ARRAY(Text), nullable=False, default=list, server_default="{}")
    access_token: Mapped[str] = mapped_column(Text, nullable=False)        # Fernet-encrypted (bot token)
    user_access_token: Mapped[str | None] = mapped_column(Text)           # Fernet-encrypted (user token, Slack xoxp-)
    refresh_token: Mapped[str | None] = mapped_column(Text)               # Fernet-encrypted
    token_type: Mapped[str] = mapped_column(String(50), nullable=False, default="Bearer")
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="active")
    error_message: Mapped[str | None] = mapped_column(Text)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    provider_metadata: Mapped[dict] = mapped_column("provider_metadata", JSONB, nullable=False, default=dict, server_default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())



class OAuthState(Base):
    __tablename__ = "oauth_states"

    state: Mapped[str] = mapped_column(String(255), primary_key=True)
    provider: Mapped[str] = mapped_column(String(50), nullable=False)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    code_verifier: Mapped[str] = mapped_column(String(255), nullable=False)
    redirect_to: Mapped[str] = mapped_column(String(500), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


# --- Reminders ---



class ChannelConfig(Base):
    __tablename__ = "channel_configs"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    channel_type: Mapped[str] = mapped_column(String(50), nullable=False)  # "telegram", "discord", "whatsapp"
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    token: Mapped[str] = mapped_column(Text, nullable=False)
    settings: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict, server_default="{}")
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())



class TelegramTopic(Base):
    __tablename__ = "telegram_topics"
    __table_args__ = (UniqueConstraint("chat_id", "topic_id", name="uq_telegram_topics_chat_topic"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    chat_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    topic_id: Mapped[int | None] = mapped_column(Integer, nullable=True)  # NULL for private chats
    conversation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    agent_type: Mapped[AgentType] = mapped_column(Enum(AgentType, values_callable=_enum_values), nullable=False, default=AgentType.CLAUDE_CODE)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    conversation: Mapped[Conversation] = relationship()


class SlackConversation(Base):
    __tablename__ = "slack_conversations"
    __table_args__ = (UniqueConstraint("team_id", "channel_id", "thread_ts", name="uq_slack_conversations_team_channel_thread"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    team_id: Mapped[str] = mapped_column(String(50), nullable=False)     # Slack workspace team ID
    channel_id: Mapped[str] = mapped_column(String(50), nullable=False)  # Slack channel or DM ID
    thread_ts: Mapped[str] = mapped_column(String(50), nullable=False)   # Thread timestamp (AI assistant threads)
    conversation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    conversation: Mapped["Conversation"] = relationship()


class WhatsAppConversation(Base):
    __tablename__ = "whatsapp_conversations"
    __table_args__ = (UniqueConstraint("jid", name="uq_whatsapp_conversations_jid"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    jid: Mapped[str] = mapped_column(String(100), nullable=False)  # e.g. "1234567890@s.whatsapp.net"
    push_name: Mapped[str | None] = mapped_column(String(200), nullable=True)  # WhatsApp display name
    conversation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    conversation: Mapped["Conversation"] = relationship()


# --- Project Settings ---


class ProjectSettings(Base):
    """Project-scoped settings for branding, theme, system prompt, and notifications.

    Consolidates:
    - Whitelabel (brand_*, theme_*)
    - Agent defaults (global_system_prompt)
    - SMTP configuration (smtp_*)
    - Pushover configuration (pushover_*)
    - Email recipients
    """
    __tablename__ = "project_settings"
    __table_args__ = (UniqueConstraint("user_id", name="uq_project_settings_user_id"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True)

    # Branding
    brand_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    brand_tagline: Mapped[str | None] = mapped_column(String(512), nullable=True)
    brand_logo_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    brand_favicon_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    brand_background_url: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Theme
    theme_preset: Mapped[str | None] = mapped_column(String(100), nullable=True)
    theme_mode: Mapped[str | None] = mapped_column(String(50), nullable=True)
    theme_primary: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_primary_foreground: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_background: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_foreground: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_card: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_card_foreground: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_secondary: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_secondary_foreground: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_accent: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_accent_foreground: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_muted: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_muted_foreground: Mapped[str | None] = mapped_column(String(7), nullable=True)
    theme_border: Mapped[str | None] = mapped_column(String(7), nullable=True)

    # Agent settings
    global_system_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
    channel_agent_defaults: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    compact_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
    context_rotation_threshold: Mapped[float] = mapped_column(Float, nullable=False, default=0.80, server_default="0.80")
    session_handoff_message_count: Mapped[int] = mapped_column(Integer, nullable=False, default=20, server_default="20")
    session_handoff_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)

    # SMTP configuration
    smtp_host: Mapped[str | None] = mapped_column(String(255), nullable=True)
    smtp_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    smtp_username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    smtp_password: Mapped[str | None] = mapped_column(String(255), nullable=True)
    smtp_from_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    smtp_use_tls: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    email_recipients: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Pushover configuration
    pushover_token: Mapped[str | None] = mapped_column(String(255), nullable=True)
    pushover_user: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Slack configuration
    slack_webhook_url: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Telegram configuration
    telegram_bot_token: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


# --- Webhook Models ---

