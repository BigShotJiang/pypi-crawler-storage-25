import asyncio
import logging
from abc import ABC, abstractmethod
from pathlib import Path

logger = logging.getLogger(__name__)

TUNNEL_URL_FILE = Path("/tunnel/url")
TUNNEL_WAIT_SECONDS = 45
TUNNEL_POLL_INTERVAL = 2


class IChannelAdapter(ABC):
    """Abstract base class for channel adapters (Telegram, Discord, WhatsApp, ...)."""

    channel_type: str

    @abstractmethod
    async def start(self) -> None:
        """Start the channel adapter (e.g., begin polling)."""
        ...

    @abstractmethod
    async def stop(self) -> None:
        """Stop the channel adapter gracefully."""
        ...

    @abstractmethod
    def is_enabled(self) -> bool:
        """Return True if this adapter is configured and should run."""
        ...

    async def _wait_for_tunnel_url(self) -> str | None:
        """Wait for the shared Cloudflare tunnel URL file (written by percona-tunnel sidecar)."""
        if not TUNNEL_URL_FILE.parent.exists():
            logger.debug("%s_tunnel_dir_not_mounted", self.channel_type)
            return None

        elapsed = 0
        while elapsed < TUNNEL_WAIT_SECONDS:
            if TUNNEL_URL_FILE.exists():
                url = TUNNEL_URL_FILE.read_text().strip()
                if url:
                    logger.info("%s_tunnel_url_found url=%s after=%ds", self.channel_type, url, elapsed)
                    return url
            await asyncio.sleep(TUNNEL_POLL_INTERVAL)
            elapsed += TUNNEL_POLL_INTERVAL

        logger.warning("%s_tunnel_url_timeout after=%ds", self.channel_type, TUNNEL_WAIT_SECONDS)
        return None
