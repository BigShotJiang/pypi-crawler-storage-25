"""SlackAdapter — Slack AI assistant via Events API (webhook mode).

Webhook mode: Slack POSTs events to /api/slack/events.
Requires a public HTTPS URL — use the shared Cloudflare tunnel (same as Telegram).

On startup the adapter reads the tunnel URL from /tunnel/url (or PERCONA_SLACK_WEBHOOK_BASE_URL)
and logs the webhook URL prominently so you can register it in Slack App Event Subscriptions.

Uses Slack's native AI Assistant API (2025):
- assistant_thread_started → show suggested prompts
- user_message → run agent, stream via chat.startStream/appendStream/stopStream
- Custom authorize() reads bot token from ConnectedAccount by team_id
"""

import asyncio
import logging

from fastapi import Request, Response
from slack_bolt.async_app import AsyncApp, AsyncAssistant
from slack_bolt.adapter.fastapi.async_handler import AsyncSlackRequestHandler
from slack_bolt.authorization import AuthorizeResult
from sqlalchemy import select

from percona.channels.base import IChannelAdapter
from percona.config import settings
from percona.database import async_session_factory
from percona.models.integrations import ConnectedAccount
from percona.services import oauth_service

logger = logging.getLogger(__name__)


async def _authorize(team_id: str | None, enterprise_id: str | None, **kwargs) -> AuthorizeResult:
    """Look up the bot token for a given Slack team_id from ConnectedAccount."""
    if not team_id:
        raise ValueError("No team_id in request")

    async with async_session_factory() as db:
        result = await db.execute(
            select(ConnectedAccount).where(
                ConnectedAccount.provider == "slack",
                ConnectedAccount.provider_account_id == team_id,
                ConnectedAccount.status == "active",
            )
        )
        account = result.scalar_one_or_none()

    if not account:
        logger.warning("slack_authorize_failed team_id=%s no_active_account", team_id)
        raise ValueError(f"No active Slack account for team_id={team_id}")

    async with async_session_factory() as db:
        token = await oauth_service.get_valid_access_token(db, account.id)

    if not token:
        logger.warning("slack_authorize_failed team_id=%s no_token", team_id)
        raise ValueError(f"No valid token for team_id={team_id}")

    logger.debug("slack_authorize_success team_id=%s account_id=%s", team_id, account.id)
    return AuthorizeResult(
        enterprise_id=enterprise_id,
        team_id=team_id,
        bot_token=token,
        bot_id=account.provider_email or "slack-bot",
    )


class SlackAdapter(IChannelAdapter):
    channel_type = "slack"

    def __init__(self):
        self._app: AsyncApp | None = None
        self._http_handler: AsyncSlackRequestHandler | None = None
        self._webhook_url: str | None = None

    def is_enabled(self) -> bool:
        return bool(settings.slack_signing_secret)

    async def start(self) -> None:
        from percona.channels.slack.handlers.message import register_handlers

        self._app = AsyncApp(
            signing_secret=settings.slack_signing_secret,
            authorize=_authorize,
        )

        assistant = AsyncAssistant()
        register_handlers(self._app, assistant)
        self._app.use(assistant)

        self._http_handler = AsyncSlackRequestHandler(self._app)
        logger.info("slack_adapter_started mode=webhook")

        # Fire-and-forget: resolve + log webhook URL (reads tunnel file when ready)
        asyncio.create_task(self._log_webhook_url(), name="slack-log-webhook-url")

    async def _log_webhook_url(self) -> None:
        """Resolve the public webhook URL and log it prominently for manual Slack App registration."""
        base_url = settings.slack_webhook_base_url

        if not base_url:
            base_url = await self._wait_for_tunnel_url()

        if not base_url:
            logger.warning("slack_webhook_url_unknown set PERCONA_SLACK_WEBHOOK_BASE_URL or mount /tunnel/url")
            return

        self._webhook_url = f"{base_url.rstrip('/')}/api/slack/events"
        logger.info(
            "slack_webhook_url_ready url=%s — register this as the Request URL in Slack App → Event Subscriptions",
            self._webhook_url,
        )

    def get_webhook_url(self) -> str | None:
        """Return the resolved public webhook URL (available after startup)."""
        return self._webhook_url

    async def stop(self) -> None:
        from percona.channels.slack.handlers.message import shutdown_all_workers
        await shutdown_all_workers()
        logger.info("slack_adapter_stopped")

    async def handle_request(self, request: Request) -> Response:
        """Handle incoming Slack webhook."""
        if not self._http_handler:
            return Response(content='{"ok":false}', status_code=503, media_type="application/json")
        return await self._http_handler.handle(request)
