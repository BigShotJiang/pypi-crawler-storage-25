"""Slack AI assistant message handlers with streaming via native Slack streaming APIs."""

import asyncio
import json
import logging
import re
import time
from uuid import UUID

import redis.asyncio as aioredis
from slack_bolt.async_app import AsyncAssistant, AsyncSetStatus, AsyncSetSuggestedPrompts, AsyncSay
from slack_sdk.web.async_client import AsyncWebClient
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from percona.channels.config import MODELS_BY_AGENT, SYSTEM_PROMPT_PRESETS
from percona.config import settings
from percona.context import set_user_id
from percona.database import async_session_factory
from percona.models import AgentType, Conversation, ConversationMcpServer, SlackConversation
from percona.models.integrations import ConnectedAccount, McpServer
from percona.services.conversation_service import get_channel_agent_defaults
from percona.services.mcp_service import get_default_mcp_ids
from percona.worker.tasks import _run_chat_turn_async

logger = logging.getLogger(__name__)

# Per-conversation queues and worker tasks keyed by str(conversation_id)
_queues: dict[str, asyncio.Queue] = {}
_workers: dict[str, asyncio.Task] = {}
_queue_lock = asyncio.Lock()


async def shutdown_all_workers() -> None:
    """Cancel all active queue workers — called by SlackAdapter.stop() on shutdown/reload."""
    global _redis_pool
    async with _queue_lock:
        tasks = list(_workers.values())
    for task in tasks:
        if not task.done():
            task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    _queues.clear()
    _workers.clear()
    if _redis_pool:
        await _redis_pool.aclose()
        _redis_pool = None

# Shared Redis connection pool
_redis_pool: aioredis.Redis | None = None

SUGGESTED_PROMPTS = [
    {"title": "Check cluster health", "message": "Check the health of all Kubernetes clusters and report any issues."},
    {"title": "Recent incidents", "message": "List recent incidents from the last 24 hours."},
    {"title": "Cost summary", "message": "Summarize GCP costs and identify any recent spikes."},
    {"title": "⚙️ Configure agent", "message": "configure"},
]

# Trigger word that shows the interactive config panel instead of going to AI
_CONFIGURE_TRIGGER = "configure"


def _get_redis() -> aioredis.Redis:
    global _redis_pool
    if _redis_pool is None:
        _redis_pool = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _redis_pool


def _strip_mention(text: str) -> str:
    """Remove Slack @mention from text (e.g. '<@U12345> do this' → 'do this')."""
    return re.sub(r"<@[A-Z0-9]+>\s*", "", text).strip()


async def _get_user_id_for_team(team_id: str) -> UUID | None:
    """Find the user_id by looking up ConnectedAccount with the given Slack team_id."""
    async with async_session_factory() as db:
        result = await db.execute(
            select(ConnectedAccount.user_id).where(
                ConnectedAccount.provider == "slack",
                ConnectedAccount.provider_account_id == team_id,
                ConnectedAccount.status == "active",
            )
        )
        return result.scalar_one_or_none()


async def get_or_create_slack_conversation(
    team_id: str,
    channel_id: str,
    thread_ts: str,
    user_id: UUID,
) -> SlackConversation:
    """Return SlackConversation for (team_id, channel_id, thread_ts), creating one if absent."""
    from percona.services import active_conversation_service

    async with async_session_factory() as db:
        stmt = select(SlackConversation).where(
            SlackConversation.team_id == team_id,
            SlackConversation.channel_id == channel_id,
            SlackConversation.thread_ts == thread_ts,
        )
        result = await db.execute(stmt)
        slack_conv = result.scalar_one_or_none()

        if slack_conv:
            return slack_conv

        # Use the single active conversation for this user
        conv = await active_conversation_service.get_or_create_active_conversation(db, user_id)

        await db.execute(
            pg_insert(SlackConversation)
            .values(
                user_id=user_id,
                team_id=team_id,
                channel_id=channel_id,
                thread_ts=thread_ts,
                conversation_id=conv.id,
            )
            .on_conflict_do_nothing(constraint="uq_slack_conversations_team_channel_thread")
        )
        await db.commit()

        # Re-fetch after potential concurrent insert
        result = await db.execute(stmt)
        slack_conv = result.scalar_one()
        logger.info(
            "slack_conversation_created team=%s channel=%s thread=%s conversation_id=%s",
            team_id, channel_id, thread_ts, conv.id,
        )
        return slack_conv


class _WorkerCleanup:
    def __init__(self, conversation_id: str) -> None:
        self._conversation_id = conversation_id

    def __call__(self, t: asyncio.Task) -> None:
        _queues.pop(self._conversation_id, None)
        _workers.pop(self._conversation_id, None)
        if not t.cancelled() and (exc := t.exception()):
            logger.exception(
                "slack_worker_died conversation_id=%s",
                self._conversation_id,
                exc_info=exc,
            )


async def _get_or_create_queue(
    conversation_id: str,
    client: AsyncWebClient,
    channel_id: str,
    thread_ts: str,
) -> asyncio.Queue:
    async with _queue_lock:
        existing_task = _workers.get(conversation_id)
        if existing_task is not None and existing_task.done():
            existing_q = _queues.get(conversation_id)
            if existing_q is None or existing_q.empty():
                _queues.pop(conversation_id, None)
                _workers.pop(conversation_id, None)

        if conversation_id not in _queues:
            q: asyncio.Queue = asyncio.Queue(maxsize=100)
            _queues[conversation_id] = q
            task = asyncio.create_task(
                _queue_worker(client, conversation_id, channel_id, thread_ts, q),
                name=f"slack-worker-{conversation_id[:8]}",
            )
            _workers[conversation_id] = task
            task.add_done_callback(_WorkerCleanup(conversation_id))
            logger.info(
                "slack_queue_worker_created conversation_id=%s channel=%s thread=%s",
                conversation_id, channel_id, thread_ts,
            )

    return _queues[conversation_id]


async def _queue_worker(
    client: AsyncWebClient,
    conversation_id: str,
    channel_id: str,
    thread_ts: str,
    queue: asyncio.Queue,
) -> None:
    """Serialize agent turns for one Slack AI assistant thread."""
    logger.debug("slack_worker_started conversation_id=%s", conversation_id)
    try:
        while True:
            item = await queue.get()
            if len(item) == 3:
                user_message, worker_client, attachments = item
            else:
                user_message, worker_client = item
                attachments = None
            try:
                await _process_turn(worker_client, conversation_id, channel_id, thread_ts, user_message, attachments)
            except Exception as exc:
                logger.exception(
                    "slack_turn_failed conversation_id=%s channel=%s error=%s",
                    conversation_id, channel_id, exc,
                )
                try:
                    await worker_client.chat_postMessage(
                        channel=channel_id,
                        thread_ts=thread_ts,
                        text=f"❌ Error processing your message: {exc}",
                    )
                except Exception:
                    pass
            finally:
                queue.task_done()
    except Exception as exc:
        logger.exception("slack_worker_crashed conversation_id=%s error=%s", conversation_id, exc)
        drained = 0
        while not queue.empty():
            try:
                queue.get_nowait()
                drained += 1
                queue.task_done()
            except asyncio.QueueEmpty:
                break
        if drained:
            logger.warning("slack_worker_drained conversation_id=%s count=%s", conversation_id, drained)


async def _process_turn(
    client: AsyncWebClient,
    conversation_id: str,
    channel_id: str,
    thread_ts: str,
    user_message: str,
    attachments: list[dict] | None = None,
) -> None:
    """Run one agent turn, streaming via Slack's native streaming APIs."""
    logger.info(
        "slack_turn_start conversation_id=%s channel=%s thread=%s user_len=%s",
        conversation_id, channel_id, thread_ts, len(user_message),
    )

    # Set project context for the agent
    async with async_session_factory() as db:
        _conv = (await db.execute(
            select(Conversation).where(Conversation.id == UUID(conversation_id))
        )).scalar_one_or_none()
        if _conv and _conv.user_id:
            set_user_id(_conv.user_id)

    # Start native Slack stream
    try:
        stream_resp = await client.chat_startStream(
            channel=channel_id,
            thread_ts=thread_ts,
        )
        stream_ts = stream_resp["ts"]
    except Exception as exc:
        logger.exception("slack_stream_start_failed conversation_id=%s error=%s", conversation_id, exc)
        await client.chat_postMessage(
            channel=channel_id,
            thread_ts=thread_ts,
            text="❌ Failed to start response stream.",
        )
        return

    # Subscribe to Redis pub/sub BEFORE starting the agent
    r = _get_redis()
    pubsub = r.pubsub()
    channel = f"chat:{conversation_id}"
    try:
        await pubsub.subscribe(channel)
    except Exception as exc:
        logger.exception("slack_pubsub_subscribe_failed conversation_id=%s error=%s", conversation_id, exc)
        await client.chat_stopStream(channel=channel_id, ts=stream_ts, status="error")
        return

    agent_task = asyncio.create_task(
        _run_chat_turn_async(conversation_id, user_message, attachments=attachments)
    )

    accumulated_text = ""
    last_append_time = 0.0
    pending_chunk = ""
    debounce_seconds = 0.5

    try:
        async for redis_msg in pubsub.listen():
            if redis_msg["type"] != "message":
                continue

            try:
                event = json.loads(redis_msg["data"])
            except (json.JSONDecodeError, KeyError):
                continue

            event_type = event.get("type", "")

            if event_type == "message":
                chunk = event.get("content", "")
                accumulated_text += chunk
                pending_chunk += chunk
                now = time.monotonic()
                if pending_chunk and (now - last_append_time) >= debounce_seconds:
                    try:
                        await client.chat_appendStream(
                            channel=channel_id,
                            ts=stream_ts,
                            markdown_text=pending_chunk,
                        )
                        pending_chunk = ""
                        last_append_time = now
                    except Exception as exc:
                        logger.warning("slack_stream_append_failed conversation_id=%s error=%s", conversation_id, exc)

            elif event_type in ("turn_end", "error"):
                logger.info(
                    "slack_turn_event_end conversation_id=%s type=%s success=%s",
                    conversation_id, event_type, event.get("success", True),
                )
                # Flush any buffered chunk before exiting loop
                if pending_chunk:
                    try:
                        await client.chat_appendStream(channel=channel_id, ts=stream_ts, markdown_text=pending_chunk)
                        pending_chunk = ""
                    except Exception as exc:
                        logger.warning("slack_stream_final_chunk_failed conversation_id=%s error=%s", conversation_id, exc)
                break

    except Exception as exc:
        logger.warning("slack_pubsub_error conversation_id=%s error=%s", conversation_id, exc)

    finally:
        async def _cleanup():
            await pubsub.unsubscribe(channel)
            await pubsub.aclose()

        try:
            await asyncio.wait_for(_cleanup(), timeout=2.0)
        except Exception as exc:
            logger.warning("slack_redis_cleanup_failed conversation_id=%s error=%s", conversation_id, exc)

    # Flush any remaining pending chunk
    if pending_chunk:
        try:
            await client.chat_appendStream(channel=channel_id, ts=stream_ts, markdown_text=pending_chunk)
        except Exception as exc:
            logger.warning("slack_stream_final_append_failed conversation_id=%s error=%s", conversation_id, exc)

    # Stop stream
    try:
        await client.chat_stopStream(channel=channel_id, ts=stream_ts)
    except Exception as exc:
        logger.warning("slack_stream_stop_failed conversation_id=%s error=%s", conversation_id, exc)

    # Wait for agent task
    try:
        await asyncio.wait_for(agent_task, timeout=30.0)
    except asyncio.TimeoutError:
        logger.warning("slack_agent_task_timeout conversation_id=%s", conversation_id)
        agent_task.cancel()
        try:
            await agent_task
        except asyncio.CancelledError:
            pass
    except asyncio.CancelledError:
        pass

    logger.info(
        "slack_turn_complete conversation_id=%s channel=%s accumulated_len=%s",
        conversation_id, channel_id, len(accumulated_text),
    )


_CONFIG_MODAL_CALLBACK_ID = "percona_config_modal"


async def _fetch_config_data(team_id: str, channel_id: str, thread_ts: str) -> dict:
    """Fetch conversation config and available resources for the config modal."""
    async with async_session_factory() as db:
        slack_conv = (await db.execute(
            select(SlackConversation).where(
                SlackConversation.team_id == team_id,
                SlackConversation.channel_id == channel_id,
                SlackConversation.thread_ts == thread_ts,
            )
        )).scalar_one_or_none()

        current_agent = settings.slack_default_agent_type or "claude-code"
        current_model = ""
        current_prompt = ""
        user_id = None
        conversation_id = None
        attached_mcp_ids: set = set()
        all_mcp_servers: list = []

        if slack_conv:
            conv = (await db.execute(
                select(Conversation).where(Conversation.id == slack_conv.conversation_id)
            )).scalar_one_or_none()
            if conv:
                current_agent = conv.agent_type.value
                current_model = (conv.agent_settings or {}).get("model", "")
                current_prompt = conv.system_prompt or ""
                user_id = conv.user_id
                conversation_id = conv.id

        if user_id:
            servers = (await db.execute(
                select(McpServer)
                .where(McpServer.user_id == user_id, McpServer.enabled == True)
                .order_by(McpServer.name)
            )).scalars().all()
            all_mcp_servers = list(servers)

        if conversation_id:
            rows = (await db.execute(
                select(ConversationMcpServer.mcp_server_id)
                .where(ConversationMcpServer.conversation_id == conversation_id)
            )).scalars().all()
            attached_mcp_ids = set(rows)

    return {
        "current_agent": current_agent,
        "current_model": current_model,
        "current_prompt": current_prompt,
        "all_mcp_servers": all_mcp_servers,
        "attached_mcp_ids": attached_mcp_ids,
    }


def _build_config_modal(thread_ts: str, channel_id: str, team_id: str, config: dict) -> dict:
    """Build the Slack modal view for Percona configuration."""
    current_agent = config["current_agent"]
    current_model = config["current_model"]
    current_prompt = config["current_prompt"]
    all_mcp_servers = config["all_mcp_servers"]
    attached_mcp_ids = config["attached_mcp_ids"]

    private_metadata = json.dumps({"thread_ts": thread_ts, "channel_id": channel_id, "team_id": team_id})

    # Agent dropdown
    agent_options = [{"text": {"type": "plain_text", "text": a.value}, "value": a.value} for a in AgentType]
    initial_agent = next((o for o in agent_options if o["value"] == current_agent), agent_options[0])

    # Model dropdown — filtered to selected agent
    models = MODELS_BY_AGENT.get(current_agent, [])
    model_options = [{"text": {"type": "plain_text", "text": label}, "value": mid} for mid, label in models]
    initial_model = next((o for o in model_options if o["value"] == current_model), model_options[0] if model_options else None)

    # MCP multi-select
    mcp_options = [{"text": {"type": "plain_text", "text": srv.name}, "value": str(srv.id)} for srv in all_mcp_servers]
    initial_mcp = [o for o in mcp_options if UUID(o["value"]) in attached_mcp_ids]

    # System prompt presets as a dropdown
    preset_options = [{"text": {"type": "plain_text", "text": label}, "value": key} for key, label, _ in SYSTEM_PROMPT_PRESETS]

    blocks: list[dict] = [
        # Agent — dispatch_action so changing it refreshes model options
        {
            "type": "input",
            "block_id": "agent_block",
            "dispatch_action": True,
            "label": {"type": "plain_text", "text": "Agent Backend"},
            "element": {
                "type": "static_select",
                "action_id": "cfg_modal_agent_select",
                "options": agent_options,
                "initial_option": initial_agent,
            },
        },
    ]

    # Model — only shown if models are defined for this agent
    if model_options:
        model_block: dict = {
            "type": "input",
            "block_id": "model_block",
            "label": {"type": "plain_text", "text": "Model"},
            "element": {
                "type": "static_select",
                "action_id": "cfg_modal_model_select",
                "options": model_options,
            },
        }
        if initial_model:
            model_block["element"]["initial_option"] = initial_model
        blocks.append(model_block)

    # MCP servers multi-select
    if mcp_options:
        mcp_block: dict = {
            "type": "input",
            "block_id": "mcp_block",
            "optional": True,
            "label": {"type": "plain_text", "text": "MCP Servers"},
            "element": {
                "type": "multi_static_select",
                "action_id": "cfg_modal_mcp_select",
                "placeholder": {"type": "plain_text", "text": "Select servers to enable"},
                "options": mcp_options,
            },
        }
        if initial_mcp:
            mcp_block["element"]["initial_options"] = initial_mcp
        blocks.append(mcp_block)

    # System prompt preset picker
    blocks.append({
        "type": "input",
        "block_id": "preset_block",
        "optional": True,
        "label": {"type": "plain_text", "text": "System Prompt Preset"},
        "hint": {"type": "plain_text", "text": "Overwrites the custom prompt below"},
        "element": {
            "type": "static_select",
            "action_id": "cfg_modal_preset_select",
            "placeholder": {"type": "plain_text", "text": "Choose a preset…"},
            "options": preset_options,
        },
    })

    # Custom system prompt textarea
    prompt_block: dict = {
        "type": "input",
        "block_id": "prompt_block",
        "optional": True,
        "label": {"type": "plain_text", "text": "Custom System Prompt"},
        "hint": {"type": "plain_text", "text": "Leave empty to use the default Percona prompt"},
        "element": {
            "type": "plain_text_input",
            "action_id": "cfg_modal_prompt_input",
            "multiline": True,
            "placeholder": {"type": "plain_text", "text": "Enter a custom system prompt…"},
        },
    }
    if current_prompt:
        prompt_block["element"]["initial_value"] = current_prompt
    blocks.append(prompt_block)

    # Options (reset conversation)
    blocks.append({"type": "divider"})
    blocks.append({
        "type": "input",
        "block_id": "options_block",
        "optional": True,
        "label": {"type": "plain_text", "text": "Options"},
        "element": {
            "type": "checkboxes",
            "action_id": "cfg_modal_options",
            "options": [{
                "text": {"type": "mrkdwn", "text": "*Reset conversation* — start a fresh session"},
                "value": "reset_conversation",
            }],
        },
    })

    return {
        "type": "modal",
        "callback_id": _CONFIG_MODAL_CALLBACK_ID,
        "private_metadata": private_metadata,
        "title": {"type": "plain_text", "text": "⚙️ Percona Config"},
        "submit": {"type": "plain_text", "text": "Apply"},
        "close": {"type": "plain_text", "text": "Cancel"},
        "blocks": blocks,
    }


async def _show_config_button(client: AsyncWebClient, channel_id: str, thread_ts: str) -> None:
    """Post a single button that opens the config modal."""
    await client.chat_postMessage(
        channel=channel_id,
        thread_ts=thread_ts,
        text="⚙️ Configure Percona",
        blocks=[{
            "type": "actions",
            "elements": [{
                "type": "button",
                "text": {"type": "plain_text", "text": "⚙️ Configure Percona"},
                "style": "primary",
                "action_id": "cfg_open_modal",
                "value": thread_ts,
            }],
        }],
    )


def register_handlers(app, assistant: AsyncAssistant) -> None:
    """Register AI assistant event handlers."""
    @app.event("message")
    async def handle_non_assistant_messages(body, logger):
        """Silently ack non-assistant message events (channel messages, bot echoes, etc.)."""
        pass

    @app.action("cfg_open_modal")
    async def handle_cfg_open_modal(ack, body, client):
        """Open the config modal when the Configure button is clicked."""
        await ack()
        trigger_id: str = body.get("trigger_id", "")
        team_raw = body.get("team", {})
        team_id: str = (team_raw.get("id", "") if isinstance(team_raw, dict) else team_raw) or body.get("team_id", "")
        channel_raw = body.get("channel", {})
        channel_id: str = (channel_raw.get("id", "") if isinstance(channel_raw, dict) else str(channel_raw))
        thread_ts: str = body["actions"][0].get("value", "")

        config = await _fetch_config_data(team_id, channel_id, thread_ts)
        modal = _build_config_modal(thread_ts, channel_id, team_id, config)
        try:
            await client.views_open(trigger_id=trigger_id, view=modal)
        except Exception as exc:
            logger.exception("slack_cfg_modal_open_failed team=%s error=%s", team_id, exc)

    @app.action("cfg_modal_agent_select")
    async def handle_cfg_modal_agent_select(ack, body, client):
        """Rebuild the modal with model options for the newly selected agent."""
        await ack()
        view = body["view"]
        view_id: str = view["id"]
        meta = json.loads(view.get("private_metadata", "{}"))
        thread_ts = meta.get("thread_ts", "")
        channel_id = meta.get("channel_id", "")
        team_id = meta.get("team_id", "")

        # Get the newly selected agent from action
        selected_agent: str = body["actions"][0]["selected_option"]["value"]

        # Build fresh config with overridden agent so model list updates
        config = await _fetch_config_data(team_id, channel_id, thread_ts)
        config["current_agent"] = selected_agent
        config["current_model"] = ""  # Reset model when agent changes
        modal = _build_config_modal(thread_ts, channel_id, team_id, config)
        try:
            await client.views_update(view_id=view_id, view=modal)
        except Exception as exc:
            logger.exception("slack_cfg_modal_agent_update_failed team=%s error=%s", team_id, exc)

    @app.view(_CONFIG_MODAL_CALLBACK_ID)
    async def handle_config_modal_submit(ack, body, client):
        """Apply all configuration changes from the modal submission."""
        await ack()
        view = body["view"]
        state = view["state"]["values"]
        meta = json.loads(view.get("private_metadata", "{}"))
        thread_ts = meta.get("thread_ts", "")
        channel_id = meta.get("channel_id", "")
        team_id = meta.get("team_id", "")

        # Extract submitted values
        selected_agent: str = (
            (state.get("agent_block", {}).get("cfg_modal_agent_select") or {})
            .get("selected_option", {})
            .get("value", "")
        )
        selected_model: str = (
            (state.get("model_block", {}).get("cfg_modal_model_select") or {})
            .get("selected_option", {})
            .get("value", "")
        )
        selected_mcp_options: list = (
            (state.get("mcp_block", {}).get("cfg_modal_mcp_select") or {})
            .get("selected_options", [])
        )
        selected_preset: str = (
            (state.get("preset_block", {}).get("cfg_modal_preset_select") or {})
            .get("selected_option", {})
            .get("value", "")
        )
        custom_prompt: str = (
            (state.get("prompt_block", {}).get("cfg_modal_prompt_input") or {})
            .get("value", "") or ""
        )
        selected_options: list = (
            (state.get("options_block", {}).get("cfg_modal_options") or {})
            .get("selected_options", [])
        )
        reset_conversation = any(o.get("value") == "reset_conversation" for o in selected_options)
        selected_mcp_ids = {UUID(o["value"]) for o in selected_mcp_options}

        # Apply changes
        async with async_session_factory() as db:
            slack_conv = (await db.execute(
                select(SlackConversation).where(
                    SlackConversation.team_id == team_id,
                    SlackConversation.channel_id == channel_id,
                    SlackConversation.thread_ts == thread_ts,
                )
            )).scalar_one_or_none()

            if not slack_conv:
                logger.warning("slack_cfg_modal_submit_no_conversation team=%s channel=%s", team_id, channel_id)
                return

            conv = (await db.execute(
                select(Conversation).where(Conversation.id == slack_conv.conversation_id)
            )).scalar_one_or_none()
            if not conv:
                return

            changes: list[str] = []

            # Agent backend
            if selected_agent and selected_agent != conv.agent_type.value:
                conv.agent_type = AgentType(selected_agent)
                conv.agent_native_session_id = None  # New agent = new session
                changes.append(f"Agent → `{selected_agent}`")

            # Model
            if selected_model:
                settings_dict = dict(conv.agent_settings or {})
                old_model = settings_dict.get("model", "")
                if selected_model != old_model:
                    settings_dict["model"] = selected_model
                    conv.agent_settings = settings_dict
                    # Codex locks model at session creation — must reset
                    if conv.agent_type.value == "codex":
                        conv.agent_native_session_id = None
                        changes.append(f"Model → `{selected_model}` _(Codex session reset)_")
                    else:
                        changes.append(f"Model → `{selected_model}`")

            # System prompt — preset takes priority over custom
            if selected_preset:
                preset_prompt = next(
                    (prompt for key, _label, prompt in SYSTEM_PROMPT_PRESETS if key == selected_preset), None
                )
                if preset_prompt and preset_prompt != conv.system_prompt:
                    conv.system_prompt = preset_prompt
                    changes.append(f"System prompt → preset `{selected_preset}`")
            elif custom_prompt and custom_prompt != conv.system_prompt:
                conv.system_prompt = custom_prompt
                changes.append("System prompt → custom")

            # MCP servers
            if selected_mcp_ids is not None:
                current_rows = (await db.execute(
                    select(ConversationMcpServer).where(
                        ConversationMcpServer.conversation_id == conv.id
                    )
                )).scalars().all()
                current_ids = {r.mcp_server_id for r in current_rows}

                to_add = selected_mcp_ids - current_ids
                to_remove = current_ids - selected_mcp_ids

                for row in current_rows:
                    if row.mcp_server_id in to_remove:
                        await db.delete(row)

                for mid in to_add:
                    await db.execute(
                        pg_insert(ConversationMcpServer)
                        .values(conversation_id=conv.id, mcp_server_id=mid)
                        .on_conflict_do_nothing()
                    )

                if to_add or to_remove:
                    changes.append(f"MCP servers updated (+{len(to_add)}/-{len(to_remove)})")

            # Reset conversation
            if reset_conversation:
                conv.agent_native_session_id = None
                changes.append("Conversation reset to new session")

            await db.commit()

        # Post summary message
        if changes:
            summary = "✅ *Percona configuration updated:*\n" + "\n".join(f"• {c}" for c in changes)
        else:
            summary = "ℹ️ No changes applied."
        try:
            await client.chat_postMessage(channel=channel_id, thread_ts=thread_ts, text=summary)
        except Exception as exc:
            logger.warning("slack_cfg_modal_summary_post_failed error=%s", exc)

    @assistant.thread_started
    async def handle_thread_started(
        say: AsyncSay,
        set_suggested_prompts: AsyncSetSuggestedPrompts,
        logger: logging.Logger,
    ) -> None:
        try:
            await set_suggested_prompts(prompts=SUGGESTED_PROMPTS)
            await say("👋 Hello! I'm your Percona AI assistant. Ask me anything about your infrastructure.")
        except Exception as exc:
            logger.exception("slack_thread_started_error: %s", exc)

    @assistant.user_message
    async def handle_user_message(
        payload: dict,
        context: dict,
        client: AsyncWebClient,
        set_status: AsyncSetStatus,
        logger: logging.Logger,
    ) -> None:
        try:
            # Skip bot's own messages
            if payload.get("bot_id") or payload.get("subtype") == "bot_message":
                return

            text = _strip_mention(payload.get("text", "")).strip()
            if not text:
                return

            channel_id = payload["channel"]
            thread_ts = payload.get("thread_ts") or payload["ts"]
            team_id = context.get("team_id") or payload.get("team")

            if not team_id:
                logger.warning("slack_handle_user_message_no_team_id payload=%s", str(payload)[:200])
                return

            # Intercept "configure" trigger — show config button that opens a modal
            if text.lower().strip() == _CONFIGURE_TRIGGER:
                await set_status("")
                await _show_config_button(client, channel_id, thread_ts)
                return

            # Show "thinking" status
            await set_status("is thinking...")

            user_id = await _get_user_id_for_team(team_id)
            if not user_id:
                await client.chat_postMessage(
                    channel=channel_id,
                    thread_ts=thread_ts,
                    text="❌ This Slack workspace is not connected to an Percona project. Visit the Integrations page to reconnect.",
                )
                return

            slack_conv = await get_or_create_slack_conversation(team_id, channel_id, thread_ts, user_id)
            conversation_id = str(slack_conv.conversation_id)

            queue = await _get_or_create_queue(conversation_id, client, channel_id, thread_ts)

            if queue.full():
                logger.warning("slack_queue_full conversation_id=%s", conversation_id)
                await client.chat_postMessage(
                    channel=channel_id,
                    thread_ts=thread_ts,
                    text="⚠️ I'm busy processing other messages. Please wait a moment.",
                )
                return

            queue.put_nowait((text, client))
            logger.info(
                "slack_message_enqueued team=%s channel=%s thread=%s conversation_id=%s",
                team_id, channel_id, thread_ts, conversation_id,
            )

        except Exception as exc:
            logger.exception("slack_handle_user_message_error: %s", exc)
            try:
                await set_status("")
            except Exception:
                pass
