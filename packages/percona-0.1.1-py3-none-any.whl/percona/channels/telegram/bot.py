"""Builds and configures the python-telegram-bot Application."""
import logging

from telegram.ext import Application, CallbackQueryHandler, CommandHandler, MessageHandler, filters

from percona.config import settings

from percona.channels.telegram.handlers.callbacks import callback_handler
from percona.channels.telegram.handlers.commands import (
    backend_handler,
    cancel_handler,
    configure_handler,
    help_handler,
    history_handler,
    mcp_handler,
    memory_handler,
    model_handler,
    new_handler,
    project_handler,
    prompt_handler,
    repos_handler,
    sessions_handler,
    start_handler,
    status_handler,
)
from percona.channels.telegram.handlers.message import text_handler, voice_handler, photo_handler, document_handler

logger = logging.getLogger(__name__)


def build_application(
    token: str,
    account_id: str,
    allowed_chat_id: int | None,
    user_id_str: str,
) -> Application:
    """Build and return a configured python-telegram-bot Application (webhook mode)."""
    timeout = settings.telegram_api_timeout_seconds
    app = (
        Application.builder()
        .token(token)
        .updater(None)
        .connect_timeout(timeout)
        .read_timeout(timeout)
        .write_timeout(timeout)
        .build()
    )

    # Store account context in bot_data so handlers can access it without DB lookups
    app.bot_data["account_id"] = account_id
    app.bot_data["allowed_chat_id"] = allowed_chat_id  # int or None
    app.bot_data["user_id"] = user_id_str  # UUID string

    # Slash commands
    app.add_handler(CommandHandler("start", start_handler))
    app.add_handler(CommandHandler("configure", configure_handler))
    app.add_handler(CommandHandler("project", project_handler))
    app.add_handler(CommandHandler("new", new_handler))
    app.add_handler(CommandHandler("cancel", cancel_handler))
    app.add_handler(CommandHandler("esc", cancel_handler))
    app.add_handler(CommandHandler("backend", backend_handler))
    app.add_handler(CommandHandler("model", model_handler))
    app.add_handler(CommandHandler("mcp", mcp_handler))
    app.add_handler(CommandHandler("memory", memory_handler))
    app.add_handler(CommandHandler("repos", repos_handler))
    app.add_handler(CommandHandler("prompt", prompt_handler))
    app.add_handler(CommandHandler("sessions", sessions_handler))
    app.add_handler(CommandHandler("history", history_handler))
    app.add_handler(CommandHandler("help", help_handler))
    app.add_handler(CommandHandler("status", status_handler))

    # Plain text messages (not commands)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))

    # Voice messages — transcribed then processed as text
    app.add_handler(MessageHandler(filters.VOICE, voice_handler))

    # Photo messages — processed as image attachments
    app.add_handler(MessageHandler(filters.PHOTO, photo_handler))

    # Document messages — processed as file attachments
    app.add_handler(MessageHandler(filters.Document.ALL, document_handler))

    # Inline keyboard callbacks (lowest priority — after command handlers)
    app.add_handler(CallbackQueryHandler(callback_handler))

    logger.debug("telegram_application_built account_id=%s handlers_registered=17", account_id)
    return app
