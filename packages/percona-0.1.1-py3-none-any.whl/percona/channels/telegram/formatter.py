"""Telegram message formatter.

Converts Markdown to MarkdownV2-safe text and handles message splitting.
Falls back gracefully when telegramify-markdown is not installed.
"""
import logging

logger = logging.getLogger(__name__)

MAX_MESSAGE_LENGTH = 4096


def _split_text(text: str, max_len: int = MAX_MESSAGE_LENGTH) -> list[str]:
    """Split text at paragraph boundaries to stay within Telegram's 4096-char limit."""
    if len(text) <= max_len:
        return [text]

    chunks: list[str] = []
    paragraphs = text.split("\n\n")
    current = ""
    for para in paragraphs:
        candidate = (current + "\n\n" + para).lstrip("\n") if current else para
        if len(candidate) <= max_len:
            current = candidate
        else:
            if current:
                chunks.append(current)
            # If single paragraph is too long, hard-split it
            while len(para) > max_len:
                chunks.append(para[:max_len])
                para = para[max_len:]
            current = para
    if current:
        chunks.append(current)
    return chunks or [text[:max_len]]


def to_markdown_v2(text: str) -> str:
    """Convert markdown text to Telegram MarkdownV2-safe format."""
    try:
        import telegramify_markdown  # type: ignore[import]
        return telegramify_markdown.markdownify(text)
    except ImportError:
        # Fall back to escaping special chars manually
        return _escape_markdownv2(text)


def _escape_markdownv2(text: str) -> str:
    """Escape special MarkdownV2 characters (used as fallback)."""
    special = r"\_*[]()~`>#+-=|{}.!"
    for ch in special:
        text = text.replace(ch, f"\\{ch}")
    return text


def format_tool_call(tool_name: str, status: str = "running") -> str:
    """Return a short tool-call status line."""
    icon = {"running": "🔧", "success": "✅", "error": "❌"}.get(status, "🔧")
    return f"{icon} `{tool_name}`"


def prepare_messages(text: str) -> list[tuple[str, str]]:
    """Return a list of (text_chunk, parse_mode) tuples ready to send.

    Tries MarkdownV2 first; falls back to HTML escaping, then plain text.
    """
    chunks = _split_text(text)
    result = []
    for chunk in chunks:
        try:
            converted = to_markdown_v2(chunk)
            result.append((converted, "MarkdownV2"))
        except Exception:
            # Last resort: strip all formatting
            result.append((chunk, ""))
    return result
