"""Shared utilities for Telegram handlers."""
import functools
import logging
import uuid

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

logger = logging.getLogger(__name__)


def ref_id() -> str:
    """Generate a short reference ID for correlating errors across logs and user replies."""
    return uuid.uuid4().hex[:12]


def format_error_reply(ref: str, exc: Exception) -> str:
    return f"❌ Error [ref:{ref}]\n{type(exc).__name__}: {str(exc)[:300]}\n\nSearch logs for: ref:{ref}"


def build_mcp_keyboard(all_servers, attached_ids: set) -> InlineKeyboardMarkup:
    """Build an inline keyboard for toggling MCP servers on/off."""
    keyboard = []
    for s in all_servers:
        check = "✓ " if s.id in attached_ids else "  "
        off_tag = " [off]" if not s.enabled else ""
        keyboard.append([InlineKeyboardButton(
            f"{check}{s.name}{off_tag}",
            callback_data=f"mcp_tog:{s.id}",
        )])
    return InlineKeyboardMarkup(keyboard)


def build_mcp_wizard_keyboard(all_servers, attached_ids: set) -> InlineKeyboardMarkup:
    """Build an inline keyboard for toggling MCP servers during setup wizard."""
    keyboard = []
    for s in all_servers:
        check = "✓ " if s.id in attached_ids else "  "
        off_tag = " [off]" if not s.enabled else ""
        keyboard.append([InlineKeyboardButton(
            f"{check}{s.name}{off_tag}",
            callback_data=f"wiz_mcp:{s.id}",
        )])
    keyboard.append([InlineKeyboardButton("Done →", callback_data="wiz_mcp_done")])
    return InlineKeyboardMarkup(keyboard)


def build_memory_wizard_keyboard(all_files, attached_ids: set) -> InlineKeyboardMarkup:
    """Build an inline keyboard for toggling memory files during setup wizard."""
    keyboard = []
    for mf in all_files:
        prefix = "✓ " if mf.id in attached_ids else "  "
        keyboard.append([InlineKeyboardButton(
            f"{prefix}{mf.name} [{mf.destination}]",
            callback_data=f"wiz_mem:{mf.id}",
        )])
    keyboard.append([InlineKeyboardButton("Done →", callback_data="wiz_mem_done")])
    return InlineKeyboardMarkup(keyboard)


def build_repo_wizard_keyboard(all_repos, attached_ids: set) -> InlineKeyboardMarkup:
    """Build an inline keyboard for toggling git repos during setup wizard."""
    keyboard = []
    for repo in all_repos:
        prefix = "✓ " if repo.id in attached_ids else "  "
        keyboard.append([InlineKeyboardButton(
            f"{prefix}{repo.name} [{repo.branch}]",
            callback_data=f"wiz_repo:{repo.id}",
        )])
    keyboard.append([InlineKeyboardButton("Done →", callback_data="wiz_repo_done")])
    return InlineKeyboardMarkup(keyboard)


def error_reply(handler):
    """Decorator: catch unhandled exceptions in a Telegram handler and reply with error + RefId."""
    @functools.wraps(handler)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        ref = ref_id()
        try:
            await handler(update, context)
        except Exception as exc:
            logger.exception(
                "telegram_handler_error ref=%s handler=%s chat_id=%s thread_id=%s error=%s",
                ref,
                handler.__name__,
                getattr(update.effective_chat, "id", None),
                getattr(getattr(update, "message", None), "message_thread_id", None),
                exc,
            )
            try:
                msg = update.message
                if msg:
                    await msg.reply_text(
                        format_error_reply(ref, exc),
                        message_thread_id=msg.message_thread_id,
                    )
            except Exception as fallback_exc:
                logger.warning(
                    "telegram_error_reply_failed ref=%s error=%s", ref, fallback_exc
                )
    return wrapper
