"""Inline keyboard callback handler for /model, /sessions, /mcp, /prompt, and /project pickers."""
import logging
import uuid
from uuid import UUID

from sqlalchemy import delete, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import selectinload
from telegram import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from percona.channels.config import MODELS_BY_AGENT, SYSTEM_PROMPT_PRESETS as SYSTEM_PROMPTS
from percona.channels.telegram.handlers.commands import (
    _AGENT_EMOJI,
    _build_configure_panel,
    _build_telegram_conversation,
    _show_agent_picker,
    _show_mcp_wizard,
    _show_memory_wizard_for_conv,
    _show_model_picker,
    _show_repo_wizard_for_conv,
    _show_wizard_complete,
)
from percona.channels.telegram.handlers.utils import build_mcp_keyboard, build_mcp_wizard_keyboard, build_memory_wizard_keyboard, build_repo_wizard_keyboard, format_error_reply, ref_id
from percona.database import async_session_factory
from percona.models import AgentType, Conversation, ConversationMemoryFile, ConversationMcpServer, McpServer, MemoryFile, User, TelegramTopic
from percona.services import session_bridge

logger = logging.getLogger(__name__)


async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Route inline keyboard callbacks by prefix."""
    query = update.callback_query
    if not query or not query.message:
        return

    ref = ref_id()
    data = query.data or ""
    chat_id = query.message.chat_id
    thread_id = query.message.message_thread_id

    # Validate chat against allowed_chat_id stored in bot_data
    allowed_chat_id = context.bot_data.get("allowed_chat_id")
    if allowed_chat_id is not None and chat_id != allowed_chat_id:
        logger.warning("telegram_callback_unauthorized_chat ref=%s chat_id=%s allowed=%s", ref, chat_id, allowed_chat_id)
        return

    logger.info(
        "telegram_callback_received ref=%s chat_id=%s thread_id=%s data_prefix=%s",
        ref, chat_id, thread_id, data[:24],
    )

    try:
        await query.answer()
    except Exception as exc:
        logger.warning("telegram_callback_answer_failed ref=%s error=%s", ref, exc)

    try:
        if data.startswith("model_sel:"):
            await _handle_model_sel(query, chat_id, thread_id, data[len("model_sel:"):])

        elif data.startswith("session_sel:"):
            await _handle_session_sel(query, chat_id, thread_id, data[len("session_sel:"):])

        elif data.startswith("mcp_tog:"):
            await _handle_mcp_tog(query, chat_id, thread_id, data[len("mcp_tog:"):])

        elif data.startswith("prompt_sel:"):
            await _handle_prompt_sel(query, chat_id, thread_id, data[len("prompt_sel:"):])

        elif data.startswith("memory_tog:"):
            await _handle_memory_tog(query, chat_id, thread_id, data[len("memory_tog:"):])

        elif data.startswith("setup_proj:"):
            await _handle_setup_proj(query, chat_id, thread_id, data[len("setup_proj:"):])

        elif data.startswith("setup_agent:"):
            await _handle_setup_agent(query, chat_id, thread_id, data[len("setup_agent:"):])

        elif data.startswith("setup_model:"):
            await _handle_setup_model(query, chat_id, thread_id, data[len("setup_model:"):])

        elif data.startswith("wiz_mcp:"):
            await _handle_wiz_mcp(query, chat_id, thread_id, data[len("wiz_mcp:"):])

        elif data == "wiz_mcp_done":
            await _handle_wiz_mcp_done(query, chat_id, thread_id)

        elif data.startswith("continue_session:"):
            await _handle_continue_session(query, chat_id, thread_id, data[len("continue_session:"):])

        elif data.startswith("wiz_mem:"):
            await _handle_wiz_mem(query, chat_id, thread_id, data[len("wiz_mem:"):])

        elif data == "wiz_mem_done":
            await _handle_wiz_mem_done(query, chat_id, thread_id)

        elif data == "cfg:agent":
            await _handle_cfg_agent(query, chat_id, thread_id)

        elif data.startswith("cfg:agent_sel:"):
            await _handle_cfg_agent_sel(query, chat_id, thread_id, data[len("cfg:agent_sel:"):])

        elif data == "cfg:model":
            await _handle_cfg_model(query, chat_id, thread_id)

        elif data.startswith("cfg:model_sel:"):
            await _handle_cfg_model_sel(query, chat_id, thread_id, data[len("cfg:model_sel:"):])

        elif data == "cfg:mcp":
            await _handle_cfg_mcp(query, chat_id, thread_id)

        elif data.startswith("cfg:mcp_tog:"):
            await _handle_cfg_mcp_tog(query, chat_id, thread_id, data[len("cfg:mcp_tog:"):])

        elif data == "cfg:memory":
            await _handle_cfg_memory(query, chat_id, thread_id)

        elif data.startswith("cfg:mem_tog:"):
            await _handle_cfg_mem_tog(query, chat_id, thread_id, data[len("cfg:mem_tog:"):])

        elif data == "cfg:prompt":
            await _handle_cfg_prompt(query, chat_id, thread_id)

        elif data.startswith("cfg:prompt_sel:"):
            await _handle_cfg_prompt_sel(query, chat_id, thread_id, data[len("cfg:prompt_sel:"):])

        elif data == "cfg:reset":
            await _handle_cfg_reset(query, chat_id, thread_id)

        elif data == "cfg:back":
            await _handle_cfg_back(query, chat_id, thread_id)

        elif data.startswith("repo_tog:"):
            await _handle_repo_tog(query, chat_id, thread_id, data[len("repo_tog:"):])

        elif data.startswith("wiz_repo:"):
            await _handle_wiz_repo(query, chat_id, thread_id, data[len("wiz_repo:"):])

        elif data == "wiz_repo_done":
            await _handle_wiz_repo_done(query, chat_id, thread_id)

    except Exception as exc:
        logger.exception("telegram_callback_error ref=%s data=%s error=%s", ref, data, exc)
        try:
            await query.edit_message_text(format_error_reply(ref, exc))
        except Exception:
            pass


async def _handle_model_sel(
    query: CallbackQuery, chat_id: int, thread_id: int | None, model: str
) -> None:
    """Set the model on the current conversation."""
    async with async_session_factory() as db:
        topic_stmt = select(TelegramTopic).where(
            TelegramTopic.chat_id == chat_id,
            TelegramTopic.topic_id == thread_id,
        )
        topic_result = await db.execute(topic_stmt)
        topic = topic_result.scalar_one_or_none()

        if not topic:
            await query.edit_message_text("❌ No active conversation found.")
            return

        conv_stmt = select(Conversation).where(Conversation.id == topic.conversation_id)
        conv_result = await db.execute(conv_stmt)
        conv = conv_result.scalar_one_or_none()

        if not conv:
            await query.edit_message_text("❌ Conversation not found.")
            return

        valid_ids = [m for m, _ in MODELS_BY_AGENT.get(conv.agent_type.value, [])]
        if model not in valid_ids:
            await query.edit_message_text(f"❌ Invalid model '{model}' for {conv.agent_type.value}.")
            return

        settings_dict = dict(conv.agent_settings or {})
        settings_dict["model"] = model
        conv.agent_settings = settings_dict
        await db.commit()

    logger.info(
        "telegram_model_set_callback chat_id=%s thread_id=%s model=%s", chat_id, thread_id, model
    )
    await query.edit_message_text(f"✅ Model set to {model}")


async def _handle_session_sel(
    query: CallbackQuery, chat_id: int, thread_id: int | None, conv_uuid: str
) -> None:
    """Switch the current topic to an existing conversation (resume native session)."""
    async with async_session_factory() as db:
        conv_stmt = select(Conversation).where(Conversation.id == conv_uuid)
        conv_result = await db.execute(conv_stmt)
        conv = conv_result.scalar_one_or_none()

        if not conv:
            await query.edit_message_text("❌ Session not found.")
            return

        topic_stmt = select(TelegramTopic).where(
            TelegramTopic.chat_id == chat_id,
            TelegramTopic.topic_id == thread_id,
        )
        topic_result = await db.execute(topic_stmt)
        topic = topic_result.scalar_one_or_none()

        if not topic:
            await query.edit_message_text("❌ No topic binding found. Send a message first.")
            return

        agent_mismatch = topic.agent_type != conv.agent_type
        old_agent = topic.agent_type.value

        topic.conversation_id = conv.id
        topic.agent_type = conv.agent_type
        await db.commit()

    emoji = _AGENT_EMOJI.get(conv.agent_type.value, "🔧")
    native_id = (conv.agent_native_session_id or "")[:8]
    title = (conv.title or "Untitled")[:32]
    warning_text = (
        f"\n⚠️ Agent type changed from {old_agent} to {conv.agent_type.value}."
        if agent_mismatch
        else ""
    )

    logger.info(
        "telegram_session_resumed chat_id=%s thread_id=%s conversation_id=%s agent=%s native_id=%s",
        chat_id, thread_id, conv.id, conv.agent_type.value, native_id,
    )
    await query.edit_message_text(
        f"✅ Resumed: {emoji} {title} ({conv.agent_type.value}) — {native_id}…{warning_text}"
    )


async def _handle_mcp_tog(
    query: CallbackQuery, chat_id: int, thread_id: int | None, server_id_str: str
) -> None:
    """Toggle an MCP server on/off for the current conversation and refresh the picker."""
    try:
        server_id = uuid.UUID(server_id_str)
    except ValueError:
        await query.edit_message_text("❌ Invalid server ID.")
        return

    new_keyboard = None
    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            await query.edit_message_text("❌ No active conversation found.")
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(selectinload(Conversation.mcp_servers))
        )).scalar_one_or_none()

        if not conv:
            await query.edit_message_text("❌ Conversation not found.")
            return

        all_servers = (await db.execute(
            select(McpServer).order_by(McpServer.name)
        )).scalars().all()

        attached_ids = {s.id for s in conv.mcp_servers}

        if server_id in attached_ids:
            await db.execute(
                delete(ConversationMcpServer).where(
                    ConversationMcpServer.conversation_id == conv.id,
                    ConversationMcpServer.mcp_server_id == server_id,
                )
            )
            attached_ids.discard(server_id)
        else:
            db.add(ConversationMcpServer(conversation_id=conv.id, mcp_server_id=server_id))
            attached_ids.add(server_id)

        await db.commit()

        # Build keyboard inside session while all_servers objects are still loaded
        new_keyboard = build_mcp_keyboard(all_servers, attached_ids)

    logger.info(
        "telegram_mcp_toggled chat_id=%s thread_id=%s conversation_id=%s server_id=%s",
        chat_id, thread_id, topic.conversation_id, server_id,
    )
    await query.edit_message_reply_markup(reply_markup=new_keyboard)


async def _handle_prompt_sel(
    query: CallbackQuery, chat_id: int, thread_id: int | None, key: str
) -> None:
    """Set a system prompt preset on the current conversation."""
    entry = next((p for p in SYSTEM_PROMPTS if p[0] == key), None)
    if not entry:
        await query.edit_message_text("❌ Unknown prompt preset.")
        return

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            await query.edit_message_text("❌ No active conversation found.")
            return

        conv = (await db.execute(
            select(Conversation).where(Conversation.id == topic.conversation_id)
        )).scalar_one_or_none()

        if not conv:
            await query.edit_message_text("❌ Conversation not found.")
            return

        conv.system_prompt = entry[2]
        await db.commit()

    logger.info(
        "telegram_prompt_set_callback chat_id=%s thread_id=%s key=%s", chat_id, thread_id, key
    )
    await query.edit_message_text(f"✅ System prompt set to: {entry[1]}")


async def _handle_memory_tog(
    query: CallbackQuery, chat_id: int, thread_id: int | None, file_id_str: str
) -> None:
    """Toggle a memory file on/off for the current conversation and refresh the picker."""
    try:
        file_id = uuid.UUID(file_id_str)
    except ValueError:
        await query.edit_message_text("❌ Invalid memory file ID.")
        return

    new_keyboard = None
    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            await query.edit_message_text("❌ No active conversation found.")
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(selectinload(Conversation.memory_files))
        )).scalar_one_or_none()

        if not conv:
            await query.edit_message_text("❌ Conversation not found.")
            return

        all_files = (await db.execute(
            select(MemoryFile).order_by(MemoryFile.name)
        )).scalars().all()

        attached_ids = {mf.id for mf in conv.memory_files}

        # Single-select: clear all then select the tapped one (deselect if already selected)
        await db.execute(
            delete(ConversationMemoryFile).where(
                ConversationMemoryFile.conversation_id == conv.id,
            )
        )
        if file_id in attached_ids:
            attached_ids = set()
        else:
            db.add(ConversationMemoryFile(conversation_id=conv.id, memory_file_id=file_id))
            attached_ids = {file_id}

        await db.commit()

        keyboard = []
        for mf in all_files:
            prefix = "✓ " if mf.id in attached_ids else "  "
            keyboard.append([
                InlineKeyboardButton(
                    f"{prefix}{mf.name} [{mf.destination}]",
                    callback_data=f"memory_tog:{mf.id}",
                )
            ])
        new_keyboard = InlineKeyboardMarkup(keyboard)

    logger.info(
        "telegram_memory_toggled chat_id=%s thread_id=%s conversation_id=%s file_id=%s",
        chat_id, thread_id, topic.conversation_id, file_id,
    )
    await query.edit_message_reply_markup(reply_markup=new_keyboard)


async def _handle_setup_proj(
    query: CallbackQuery, chat_id: int, thread_id: int | None, user_id_str: str
) -> None:
    """Step 1 → Step 2: user picked a project, show agent picker."""
    logger.info("telegram_setup_proj_received chat_id=%s thread_id=%s user_id=%s", chat_id, thread_id, user_id_str)
    try:
        user_id = UUID(user_id_str)
    except ValueError:
        await query.edit_message_text("❌ Invalid project ID.")
        return

    async with async_session_factory() as db:
        proj = (await db.execute(
            select(User).where(User.id == user_id)
        )).scalar_one_or_none()

        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()
        current_agent = topic.agent_type.value if topic else ""

    if not proj:
        await query.edit_message_text("❌ User not found.")
        return

    logger.info("telegram_setup_proj_showing_agents chat_id=%s project=%s current_agent=%s", chat_id, proj.name, current_agent)
    await _show_agent_picker(query, str(user_id), proj.name, current_agent)


async def _handle_setup_agent(
    query: CallbackQuery, chat_id: int, thread_id: int | None, payload: str
) -> None:
    """Step 2 → Step 3: user picked agent, show model picker."""
    logger.info("telegram_setup_agent_received chat_id=%s thread_id=%s payload=%s", chat_id, thread_id, payload)
    parts = payload.split(":", 1)
    if len(parts) != 2:
        await query.edit_message_text("❌ Malformed callback data.")
        return
    user_id_str, agent_type = parts

    try:
        user_id = UUID(user_id_str)
    except ValueError:
        await query.edit_message_text("❌ Invalid project ID.")
        return

    if agent_type not in {a.value for a in AgentType}:
        await query.edit_message_text("❌ Invalid agent type.")
        return

    async with async_session_factory() as db:
        proj = (await db.execute(
            select(User).where(User.id == user_id)
        )).scalar_one_or_none()

        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        current_model = ""
        if topic:
            conv = (await db.execute(
                select(Conversation).where(Conversation.id == topic.conversation_id)
            )).scalar_one_or_none()
            if conv:
                current_model = (conv.agent_settings or {}).get("model", "")

    if not proj:
        await query.edit_message_text("❌ User not found.")
        return

    logger.info("telegram_setup_agent_showing_models chat_id=%s project=%s agent=%s", chat_id, proj.name, agent_type)
    await _show_model_picker(query, user_id_str, proj.name, agent_type, current_model)


async def _handle_setup_model(
    query: CallbackQuery, chat_id: int, thread_id: int | None, payload: str
) -> None:
    """Step 3 → Apply: create new conversation with selected project/agent/model."""
    logger.info("telegram_setup_model_received chat_id=%s thread_id=%s payload=%s", chat_id, thread_id, payload)
    parts = payload.split(":", 2)
    if len(parts) != 3:
        await query.edit_message_text("❌ Malformed callback data.")
        return
    user_id_str, agent_type, model_spec = parts

    try:
        user_id = UUID(user_id_str)
        new_agent = AgentType(agent_type)
    except (ValueError, KeyError):
        await query.edit_message_text("❌ Invalid setup data.")
        return

    # Resolve model: "default" → empty string, else look up by index
    model_id = ""
    if model_spec != "default":
        models = MODELS_BY_AGENT.get(agent_type, [])
        try:
            idx = int(model_spec)
            model_id = models[idx][0]
        except (ValueError, IndexError):
            await query.edit_message_text("❌ Invalid model selection.")
            return

    async with async_session_factory() as db:
        proj = (await db.execute(
            select(User).where(User.id == user_id)
        )).scalar_one_or_none()
        if not proj:
            await query.edit_message_text("❌ User not found.")
            return

        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        new_conv = await _build_telegram_conversation(db, chat_id, thread_id, new_agent, user_id)
        if model_id:
            new_conv.agent_settings = dict(new_conv.agent_settings or {})
            new_conv.agent_settings["model"] = model_id

        if topic:
            topic.user_id = user_id
            topic.agent_type = new_agent
            topic.conversation_id = new_conv.id
        else:
            topic = TelegramTopic(
                user_id=user_id,
                chat_id=chat_id,
                topic_id=thread_id,
                conversation_id=new_conv.id,
                agent_type=new_agent,
            )
            db.add(topic)

        await db.commit()
        conv_id = str(new_conv.id)

    agent_label = {
        AgentType.CLAUDE_CODE.value: "Claude Code",
        AgentType.CODEX.value: "Codex",
        AgentType.GEMINI.value: "Gemini",
    }.get(agent_type, agent_type)
    logger.info(
        "telegram_setup_model_done chat_id=%s thread_id=%s user_id=%s agent=%s model=%s conv_id=%s",
        chat_id, thread_id, user_id, agent_type, model_id, conv_id,
    )

    # Step 4: show MCP server picker
    async with async_session_factory() as db:
        all_servers = (await db.execute(
            select(McpServer).order_by(McpServer.name)
        )).scalars().all()
        conv_reloaded = (await db.execute(
            select(Conversation)
            .where(Conversation.id == new_conv.id)
            .options(selectinload(Conversation.mcp_servers))
        )).scalar_one_or_none()
        attached_ids = {s.id for s in conv_reloaded.mcp_servers} if conv_reloaded else set()

    await _show_mcp_wizard(query, proj.name, agent_label, new_conv, all_servers, attached_ids)


async def _handle_wiz_mcp(
    query: CallbackQuery, chat_id: int, thread_id: int | None, server_id_str: str
) -> None:
    """Wizard Step 4: toggle an MCP server and refresh the wizard MCP picker."""
    try:
        server_id = uuid.UUID(server_id_str)
    except ValueError:
        await query.edit_message_text("❌ Invalid server ID.")
        return

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()
        if not topic:
            await query.edit_message_text("❌ No active conversation found.")
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(selectinload(Conversation.mcp_servers))
        )).scalar_one_or_none()
        if not conv:
            await query.edit_message_text("❌ Conversation not found.")
            return

        all_servers = (await db.execute(
            select(McpServer).order_by(McpServer.name)
        )).scalars().all()

        attached_ids = {s.id for s in conv.mcp_servers}

        if server_id in attached_ids:
            await db.execute(
                delete(ConversationMcpServer).where(
                    ConversationMcpServer.conversation_id == conv.id,
                    ConversationMcpServer.mcp_server_id == server_id,
                )
            )
            attached_ids.discard(server_id)
        else:
            db.add(ConversationMcpServer(conversation_id=conv.id, mcp_server_id=server_id))
            attached_ids.add(server_id)

        await db.commit()
        new_keyboard = build_mcp_wizard_keyboard(all_servers, attached_ids)

    logger.info(
        "telegram_wiz_mcp_toggled chat_id=%s thread_id=%s server_id=%s",
        chat_id, thread_id, server_id,
    )
    await query.edit_message_reply_markup(reply_markup=new_keyboard)


async def _handle_wiz_mcp_done(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Wizard Step 4 → Step 5: MCP done, show memory file picker."""
    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()
        if not topic:
            await query.edit_message_text("❌ No active conversation found.")
            return

        conv = (await db.execute(
            select(Conversation).where(Conversation.id == topic.conversation_id)
        )).scalar_one_or_none()
        if not conv:
            await query.edit_message_text("❌ Conversation not found.")
            return

        proj = (await db.execute(
            select(User).where(User.id == conv.user_id)
        )).scalar_one_or_none()

    agent_label = {
        AgentType.CLAUDE_CODE.value: "Claude Code",
        AgentType.CODEX.value: "Codex",
        AgentType.GEMINI.value: "Gemini",
    }.get(conv.agent_type.value, conv.agent_type.value)

    logger.info("telegram_wiz_mcp_done chat_id=%s thread_id=%s", chat_id, thread_id)
    await _show_memory_wizard_for_conv(query, proj.name if proj else "Unknown", agent_label, conv)


async def _handle_wiz_mem(
    query: CallbackQuery, chat_id: int, thread_id: int | None, file_id_str: str
) -> None:
    """Wizard Step 5: toggle a memory file (single-select) and refresh the picker."""
    try:
        file_id = uuid.UUID(file_id_str)
    except ValueError:
        await query.edit_message_text("❌ Invalid memory file ID.")
        return

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()
        if not topic:
            await query.edit_message_text("❌ No active conversation found.")
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(selectinload(Conversation.memory_files))
        )).scalar_one_or_none()
        if not conv:
            await query.edit_message_text("❌ Conversation not found.")
            return

        all_files = (await db.execute(
            select(MemoryFile).order_by(MemoryFile.name)
        )).scalars().all()

        attached_ids = {mf.id for mf in conv.memory_files}

        # Single-select: clear all then select the tapped one (deselect if already selected)
        await db.execute(
            delete(ConversationMemoryFile).where(
                ConversationMemoryFile.conversation_id == conv.id,
            )
        )
        if file_id in attached_ids:
            attached_ids = set()
        else:
            db.add(ConversationMemoryFile(conversation_id=conv.id, memory_file_id=file_id))
            attached_ids = {file_id}

        await db.commit()
        new_keyboard = build_memory_wizard_keyboard(all_files, attached_ids)

    logger.info(
        "telegram_wiz_mem_toggled chat_id=%s thread_id=%s file_id=%s",
        chat_id, thread_id, file_id,
    )
    await query.edit_message_reply_markup(reply_markup=new_keyboard)


async def _handle_wiz_mem_done(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Wizard Step 5 → Step 6: memory done, show git repo picker."""
    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()
        if not topic:
            await query.edit_message_text("❌ No active conversation found.")
            return

        conv = (await db.execute(
            select(Conversation).where(Conversation.id == topic.conversation_id)
        )).scalar_one_or_none()
        if not conv:
            await query.edit_message_text("❌ Conversation not found.")
            return

        proj = (await db.execute(
            select(User).where(User.id == conv.user_id)
        )).scalar_one_or_none()

    agent_label = {
        AgentType.CLAUDE_CODE.value: "Claude Code",
        AgentType.CODEX.value: "Codex",
        AgentType.GEMINI.value: "Gemini",
    }.get(conv.agent_type.value, conv.agent_type.value)

    logger.info("telegram_wiz_mem_done chat_id=%s thread_id=%s", chat_id, thread_id)
    await _show_repo_wizard_for_conv(query, proj.name if proj else "Unknown", agent_label, conv)


async def _handle_repo_tog(
    query: CallbackQuery, chat_id: int, thread_id: int | None, repo_id_str: str
) -> None:
    """Git repository integration is no longer available."""
    await query.edit_message_text("Git repository integration is not available.")


async def _handle_wiz_repo(
    query: CallbackQuery, chat_id: int, thread_id: int | None, repo_id_str: str
) -> None:
    """Git repository integration is no longer available."""
    await query.edit_message_text("Git repository integration is not available.")


async def _handle_wiz_repo_done(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Wizard Step 6 → Complete: show final summary."""
    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()
        if not topic:
            await query.edit_message_text("❌ No active conversation found.")
            return

        conv = (await db.execute(
            select(Conversation).where(Conversation.id == topic.conversation_id)
        )).scalar_one_or_none()
        if not conv:
            await query.edit_message_text("❌ Conversation not found.")
            return

    logger.info("telegram_wiz_repo_done chat_id=%s thread_id=%s", chat_id, thread_id)
    await _show_wizard_complete(query, conv)


async def _get_topic_conv(db, chat_id: int, thread_id: int | None):
    """Helper: load TelegramTopic and its Conversation."""
    topic = (await db.execute(
        select(TelegramTopic).where(
            TelegramTopic.chat_id == chat_id,
            TelegramTopic.topic_id == thread_id,
        )
    )).scalar_one_or_none()
    if not topic:
        return None, None
    conv = (await db.execute(
        select(Conversation).where(Conversation.id == topic.conversation_id)
    )).scalar_one_or_none()
    return topic, conv


async def _handle_cfg_back(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Return to the main configure panel."""
    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return
        text, keyboard = await _build_configure_panel(db, conv.id)
    await query.edit_message_text(text, reply_markup=keyboard)


async def _handle_cfg_agent(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Show agent picker with Back button."""
    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return

    agents = [
        (AgentType.CLAUDE_CODE.value, "Claude Code"),
        (AgentType.CODEX.value, "Codex"),
        (AgentType.GEMINI.value, "Gemini"),
    ]
    keyboard = []
    for agent_val, label in agents:
        prefix = "✓ " if agent_val == conv.agent_type.value else "  "
        keyboard.append([InlineKeyboardButton(
            f"{prefix}{label}",
            callback_data=f"cfg:agent_sel:{agent_val}",
        )])
    keyboard.append([InlineKeyboardButton("« Back", callback_data="cfg:back")])
    await query.edit_message_text(
        "Select agent backend:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def _handle_cfg_agent_sel(
    query: CallbackQuery, chat_id: int, thread_id: int | None, agent_type: str
) -> None:
    """Set agent type and return to config panel."""
    if agent_type not in {a.value for a in AgentType}:
        await query.edit_message_text("Invalid agent type.")
        return

    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return

        new_agent = AgentType(agent_type)
        conv.agent_type = new_agent
        topic.agent_type = new_agent
        # Clear native session when agent changes
        conv.agent_native_session_id = None
        await db.commit()

        text, keyboard = await _build_configure_panel(db, conv.id)

    logger.info("cfg_agent_set chat_id=%s agent=%s", chat_id, agent_type)
    await query.edit_message_text(text, reply_markup=keyboard)


async def _handle_cfg_model(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Show model picker with Back button."""
    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return

    agent_type = conv.agent_type.value
    models = MODELS_BY_AGENT.get(agent_type, [])
    current_model = (conv.agent_settings or {}).get("model", "")

    if not models:
        await query.edit_message_text(f"No model options for {agent_type}.")
        return

    keyboard = []
    for model_id, label in models:
        prefix = "✓ " if model_id == current_model else "  "
        keyboard.append([InlineKeyboardButton(
            f"{prefix}{model_id}",
            callback_data=f"cfg:model_sel:{model_id}",
        )])
    keyboard.append([InlineKeyboardButton("« Back", callback_data="cfg:back")])
    await query.edit_message_text(
        f"Select model for {agent_type}:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def _handle_cfg_model_sel(
    query: CallbackQuery, chat_id: int, thread_id: int | None, model: str
) -> None:
    """Set model and return to config panel."""
    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return

        valid_ids = [m for m, _ in MODELS_BY_AGENT.get(conv.agent_type.value, [])]
        if model not in valid_ids:
            await query.edit_message_text(f"Invalid model '{model}'.")
            return

        settings_dict = dict(conv.agent_settings or {})
        settings_dict["model"] = model
        conv.agent_settings = settings_dict
        # Clear native session when model changes
        conv.agent_native_session_id = None
        await db.commit()

        text, keyboard = await _build_configure_panel(db, conv.id)

    logger.info("cfg_model_set chat_id=%s model=%s", chat_id, model)
    await query.edit_message_text(text, reply_markup=keyboard)


async def _handle_cfg_mcp(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Show MCP server toggle with Back button."""
    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == conv.id)
            .options(selectinload(Conversation.mcp_servers))
        )).scalar_one_or_none()

        all_servers = (await db.execute(
            select(McpServer).order_by(McpServer.name)
        )).scalars().all()

        if not all_servers:
            await query.edit_message_text("No MCP servers configured.")
            return

        attached_ids = {s.id for s in conv.mcp_servers}
        keyboard = []
        for s in all_servers:
            check = "✓ " if s.id in attached_ids else "  "
            off_tag = " [off]" if not s.enabled else ""
            keyboard.append([InlineKeyboardButton(
                f"{check}{s.name}{off_tag}",
                callback_data=f"cfg:mcp_tog:{s.id}",
            )])
        keyboard.append([InlineKeyboardButton("« Back", callback_data="cfg:back")])

    await query.edit_message_text(
        "Toggle MCP servers:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def _handle_cfg_mcp_tog(
    query: CallbackQuery, chat_id: int, thread_id: int | None, server_id_str: str
) -> None:
    """Toggle MCP server and refresh the cfg MCP picker."""
    try:
        server_id = uuid.UUID(server_id_str)
    except ValueError:
        await query.edit_message_text("Invalid server ID.")
        return

    async with async_session_factory() as db:
        topic, _ = await _get_topic_conv(db, chat_id, thread_id)
        if not topic:
            await query.edit_message_text("No active conversation.")
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(selectinload(Conversation.mcp_servers))
        )).scalar_one_or_none()

        all_servers = (await db.execute(
            select(McpServer).order_by(McpServer.name)
        )).scalars().all()

        attached_ids = {s.id for s in conv.mcp_servers}
        if server_id in attached_ids:
            await db.execute(
                delete(ConversationMcpServer).where(
                    ConversationMcpServer.conversation_id == conv.id,
                    ConversationMcpServer.mcp_server_id == server_id,
                )
            )
            attached_ids.discard(server_id)
        else:
            db.add(ConversationMcpServer(conversation_id=conv.id, mcp_server_id=server_id))
            attached_ids.add(server_id)
        await db.commit()

        keyboard = []
        for s in all_servers:
            check = "✓ " if s.id in attached_ids else "  "
            off_tag = " [off]" if not s.enabled else ""
            keyboard.append([InlineKeyboardButton(
                f"{check}{s.name}{off_tag}",
                callback_data=f"cfg:mcp_tog:{s.id}",
            )])
        keyboard.append([InlineKeyboardButton("« Back", callback_data="cfg:back")])

    await query.edit_message_reply_markup(reply_markup=InlineKeyboardMarkup(keyboard))


async def _handle_cfg_memory(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Show memory file toggle with Back button."""
    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == conv.id)
            .options(selectinload(Conversation.memory_files))
        )).scalar_one_or_none()

        all_files = (await db.execute(
            select(MemoryFile).order_by(MemoryFile.name)
        )).scalars().all()

        if not all_files:
            await query.edit_message_text("No memory files defined.")
            return

        attached_ids = {mf.id for mf in conv.memory_files}
        keyboard = []
        for mf in all_files:
            prefix = "✓ " if mf.id in attached_ids else "  "
            keyboard.append([InlineKeyboardButton(
                f"{prefix}{mf.name} [{mf.destination}]",
                callback_data=f"cfg:mem_tog:{mf.id}",
            )])
        keyboard.append([InlineKeyboardButton("« Back", callback_data="cfg:back")])

    await query.edit_message_text(
        "Toggle memory files:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def _handle_cfg_mem_tog(
    query: CallbackQuery, chat_id: int, thread_id: int | None, file_id_str: str
) -> None:
    """Toggle memory file (single-select) and refresh the cfg memory picker."""
    try:
        file_id = uuid.UUID(file_id_str)
    except ValueError:
        await query.edit_message_text("Invalid memory file ID.")
        return

    async with async_session_factory() as db:
        topic, _ = await _get_topic_conv(db, chat_id, thread_id)
        if not topic:
            await query.edit_message_text("No active conversation.")
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(selectinload(Conversation.memory_files))
        )).scalar_one_or_none()

        all_files = (await db.execute(
            select(MemoryFile).order_by(MemoryFile.name)
        )).scalars().all()

        attached_ids = {mf.id for mf in conv.memory_files}

        # Single-select: clear all, then select tapped (deselect if already selected)
        await db.execute(
            delete(ConversationMemoryFile).where(
                ConversationMemoryFile.conversation_id == conv.id,
            )
        )
        if file_id in attached_ids:
            attached_ids = set()
        else:
            db.add(ConversationMemoryFile(conversation_id=conv.id, memory_file_id=file_id))
            attached_ids = {file_id}
        await db.commit()

        keyboard = []
        for mf in all_files:
            prefix = "✓ " if mf.id in attached_ids else "  "
            keyboard.append([InlineKeyboardButton(
                f"{prefix}{mf.name} [{mf.destination}]",
                callback_data=f"cfg:mem_tog:{mf.id}",
            )])
        keyboard.append([InlineKeyboardButton("« Back", callback_data="cfg:back")])

    await query.edit_message_reply_markup(reply_markup=InlineKeyboardMarkup(keyboard))


async def _handle_cfg_prompt(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Show prompt preset picker with Back button."""
    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return

    current_prompt = (conv.system_prompt or "").strip()
    keyboard = []
    for key, label, value in SYSTEM_PROMPTS:
        prefix = "✓ " if current_prompt == value.strip() else "  "
        keyboard.append([InlineKeyboardButton(
            f"{prefix}{label}",
            callback_data=f"cfg:prompt_sel:{key}",
        )])
    keyboard.append([InlineKeyboardButton("« Back", callback_data="cfg:back")])
    await query.edit_message_text(
        "Select system prompt:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def _handle_cfg_prompt_sel(
    query: CallbackQuery, chat_id: int, thread_id: int | None, key: str
) -> None:
    """Set prompt and return to config panel."""
    entry = next((p for p in SYSTEM_PROMPTS if p[0] == key), None)
    if not entry:
        await query.edit_message_text("Unknown prompt preset.")
        return

    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return

        conv.system_prompt = entry[2]
        await db.commit()

        text, keyboard = await _build_configure_panel(db, conv.id)

    logger.info("cfg_prompt_set chat_id=%s key=%s", chat_id, key)
    await query.edit_message_text(text, reply_markup=keyboard)


async def _handle_cfg_reset(
    query: CallbackQuery, chat_id: int, thread_id: int | None
) -> None:
    """Clear the agent native session and return to config panel."""
    async with async_session_factory() as db:
        topic, conv = await _get_topic_conv(db, chat_id, thread_id)
        if not topic or not conv:
            await query.edit_message_text("No active conversation.")
            return

        conv.agent_native_session_id = None
        await db.commit()

        text, keyboard = await _build_configure_panel(db, conv.id)

    logger.info("cfg_reset chat_id=%s conversation_id=%s", chat_id, conv.id)
    # Prepend reset confirmation
    text = "Session reset.\n\n" + text
    await query.edit_message_text(text, reply_markup=keyboard)


async def _handle_continue_session(
    query: CallbackQuery, chat_id: int, thread_id: int | None, session_id_str: str
) -> None:
    """Bridge a task Session into a Conversation and point the Telegram topic to it."""
    try:
        session_id = uuid.UUID(session_id_str)
    except ValueError:
        await query.edit_message_text("Invalid session ID.")
        return

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            user_id_str = context.bot_data.get("user_id")
            if not user_id_str:
                await query.edit_message_text("No project configured. Send /start first.")
                return
            try:
                user_id = UUID(user_id_str)
            except (ValueError, AttributeError):
                logger.error("telegram_continue_session_invalid_user_id user_id_str=%s", user_id_str)
                await query.edit_message_text("Invalid project context. Send /start to reset.")
                return
        else:
            user_id = topic.user_id

        try:
            new_conv = await session_bridge.create_conversation_from_session(
                db, user_id, session_id,
            )
        except (KeyError, ValueError) as e:
            await query.edit_message_text(f"Cannot continue session: {e}")
            return

        if topic:
            topic.conversation_id = new_conv.id
            topic.agent_type = new_conv.agent_type
        else:
            topic = TelegramTopic(
                user_id=user_id,
                chat_id=chat_id,
                topic_id=thread_id,
                conversation_id=new_conv.id,
                agent_type=new_conv.agent_type,
            )
            db.add(topic)

        await db.commit()

    logger.info(
        "telegram_continue_session chat_id=%s thread_id=%s session_id=%s conversation_id=%s",
        chat_id, thread_id, session_id, new_conv.id,
    )
    await query.edit_message_text(
        f"Session loaded. Send a message to continue."
    )
