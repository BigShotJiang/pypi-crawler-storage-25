"""TelegramAdapter — multi-account webhook mode, one PTB Application per connected bot."""
import asyncio
import logging
import secrets as secrets_lib
from uuid import UUID

import httpx
from sqlalchemy import select

from percona.channels.base import IChannelAdapter
from percona.config import settings
from percona.database import async_session_factory
from percona.models.integrations import ConnectedAccount

logger = logging.getLogger(__name__)


class TelegramAdapter(IChannelAdapter):
    channel_type = "telegram"

    def __init__(self):
        # Active PTB Applications keyed by str(account_id)
        self._apps: dict[str, object] = {}

    def is_enabled(self) -> bool:
        return True  # Always enabled — no-op if no accounts in DB

    async def start(self) -> None:
        async with async_session_factory() as db:
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.provider == "telegram",
                    ConnectedAccount.status == "active",
                )
            )
            accounts = result.scalars().all()
            account_data = []
            for a in accounts:
                from percona.services.oauth_service import decrypt_token
                try:
                    bot_token = decrypt_token(a.access_token)
                except Exception:
                    logger.warning("telegram_account_token_decrypt_failed account_id=%s", a.id)
                    continue
                account_data.append((str(a.id), bot_token, a.provider_metadata or {}, a.user_id))

        # Legacy env-var migration: if no DB accounts but env vars are set, auto-migrate
        if not account_data and settings.telegram_bot_token:
            logger.info("telegram_adapter_migrating_from_env_vars")
            account_data = await self._migrate_from_env_vars()

        if not account_data:
            logger.info("telegram_adapter_started no_active_accounts")
            return

        for account_id, bot_token, metadata, user_id in account_data:
            await self._start_app(account_id, bot_token, metadata, user_id)

        logger.info("telegram_adapter_started active_accounts=%s", len(account_data))

    async def _migrate_from_env_vars(self) -> list:
        """One-time migration: create ConnectedAccount from legacy env vars."""
        from percona.models.users import User
        from percona.services import telegram_service

        try:
            async with async_session_factory() as db:
                user_id: UUID | None = None
                if settings.telegram_user_id:
                    user_id = UUID(settings.telegram_user_id)
                else:
                    result = await db.execute(select(User.id).order_by(User.created_at).limit(1))
                    user_id = result.scalar_one_or_none()

                if not user_id:
                    logger.warning("telegram_migrate_no_user_found")
                    return []

                account = await telegram_service.connect_telegram_bot(
                    db,
                    user_id,
                    settings.telegram_bot_token,
                    settings.telegram_chat_id,
                )
                await db.commit()
                return [(str(account.id), settings.telegram_bot_token, account.provider_metadata or {}, user_id)]
        except Exception:
            logger.exception("telegram_migrate_from_env_vars_failed")
            return []

    async def _start_app(self, account_id: str, bot_token: str, metadata: dict, user_id: UUID) -> None:
        """Start a PTB Application for one connected Telegram bot."""
        from percona.channels.telegram.bot import build_application

        raw_chat_id = metadata.get("chat_id")
        try:
            allowed_chat_id: int | None = int(raw_chat_id) if raw_chat_id is not None else None
        except (ValueError, TypeError):
            logger.warning("telegram_invalid_chat_id_in_metadata account_id=%s value=%s", account_id, raw_chat_id)
            allowed_chat_id = None

        app = build_application(bot_token, account_id, allowed_chat_id, str(user_id))
        await app.initialize()
        await app.start()
        bot_id = getattr(getattr(app, "bot", None), "id", None)
        self._apps[account_id] = app
        logger.info("telegram_app_started account_id=%s bot_id=%s", account_id, bot_id)

        asyncio.create_task(self._register_webhook(account_id, bot_token))

    async def _register_webhook(self, account_id: str, bot_token: str) -> None:
        """Register this bot's webhook at /api/telegram/webhook/{account_id}."""
        base_url = settings.telegram_webhook_base_url
        if not base_url:
            base_url = await self._wait_for_tunnel_url()

        if not base_url:
            logger.warning("telegram_webhook_not_registered account_id=%s no_url_available", account_id)
            return

        webhook_url = f"{base_url.rstrip('/')}/api/telegram/webhook/{account_id}"

        secret = settings.telegram_webhook_secret
        if not secret:
            secret = secrets_lib.token_urlsafe(32)
            settings.telegram_webhook_secret = secret
            logger.info("telegram_webhook_secret_generated")

        max_retries = 15
        for attempt in range(1, max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=15) as client:
                    r = await client.post(
                        f"https://api.telegram.org/bot{bot_token}/setWebhook",
                        json={
                            "url": webhook_url,
                            "secret_token": secret,
                            "allowed_updates": ["message", "callback_query", "edited_message"],
                            "drop_pending_updates": True,
                        },
                    )
                    data = r.json()

                if data.get("ok"):
                    logger.info(
                        "telegram_webhook_registered account_id=%s url=%s attempt=%d",
                        account_id, webhook_url, attempt,
                    )
                    return

                desc = data.get("description", "")
                if "resolve" in desc.lower() and attempt < max_retries:
                    delay = min(attempt * 10, 30)
                    logger.warning(
                        "telegram_webhook_dns_not_ready account_id=%s attempt=%d/%d retrying_in=%ds",
                        account_id, attempt, max_retries, delay,
                    )
                    await asyncio.sleep(delay)
                    continue

                logger.error("telegram_webhook_registration_failed account_id=%s response=%s", account_id, data)
                return
            except Exception:
                if attempt < max_retries:
                    delay = min(attempt * 10, 30)
                    logger.warning(
                        "telegram_webhook_registration_error account_id=%s attempt=%d/%d",
                        account_id, attempt, max_retries,
                        exc_info=True,
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.exception("telegram_webhook_registration_error account_id=%s", account_id)

    async def stop_app(self, account_id: str) -> None:
        """Stop and remove the PTB Application for one account."""
        app = self._apps.pop(account_id, None)
        if app:
            try:
                await app.stop()
                await app.shutdown()
            except Exception:
                logger.debug("telegram_app_shutdown_error account_id=%s", account_id, exc_info=True)
        logger.info("telegram_app_stopped account_id=%s", account_id)

    async def stop(self) -> None:
        for account_id, app in list(self._apps.items()):
            try:
                await app.stop()
                await app.shutdown()
            except Exception:
                logger.debug("telegram_app_shutdown_error account_id=%s", account_id, exc_info=True)
        self._apps.clear()
        logger.info("telegram_adapter_stopped")

    async def process_update(self, account_id: str, data: dict) -> None:
        """Route a raw Telegram update to the correct PTB Application."""
        from telegram import Update

        app = self._apps.get(account_id)
        if not app:
            logger.warning("telegram_app_not_found account_id=%s", account_id)
            return

        try:
            update = Update.de_json(data, app.bot)
        except Exception as exc:
            logger.exception("telegram_update_deserialize_failed account_id=%s error=%s", account_id, exc)
            return

        try:
            await app.process_update(update)
        except Exception as exc:
            logger.exception(
                "telegram_update_process_failed account_id=%s update_id=%s error=%s",
                account_id, getattr(update, "update_id", None), exc,
            )
