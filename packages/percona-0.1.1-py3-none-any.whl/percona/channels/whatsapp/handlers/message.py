"""WhatsApp message handler and per-conversation queue workers.

Each active conversation gets its own asyncio.Queue + worker Task so that
concurrent messages in the same JID are serialized while multiple JIDs
can run in parallel.  Mirrors the Telegram/Slack handler pattern exactly.
"""
import asyncio
import json
import logging
import time
from uuid import UUID

import redis.asyncio as aioredis
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from percona.config import settings
from percona.context import set_user_id
from percona.database import async_session_factory
from percona.models import AgentType, Conversation, ConversationMcpServer, WhatsAppConversation
from percona.models.integrations import ProjectSettings
from percona.models.integrations import ConnectedAccount
from percona.models.users import User
from percona.services.mcp_service import get_default_mcp_ids
from percona.worker.tasks import _run_chat_turn_async

logger = logging.getLogger(__name__)

# Per-conversation queues and worker tasks keyed by str(conversation_id)
_queues: dict[str, asyncio.Queue] = {}
_workers: dict[str, asyncio.Task] = {}
_queue_lock = asyncio.Lock()

# Shared Redis connection pool — lazy init
_redis_pool: aioredis.Redis | None = None

# Configure trigger
_CONFIGURE_TRIGGER = "configure"

# Max WhatsApp message length for readability (WhatsApp allows ~65000)
_MAX_CHUNK_LEN = 4000


async def shutdown_all_workers() -> None:
    """Cancel all active queue workers — called by WhatsAppAdapter.stop()."""
    global _redis_pool
    async with _queue_lock:
        tasks = list(_workers.values())
    for task in tasks:
        if not task.done():
            task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    _queues.clear()
    _workers.clear()
    if _redis_pool:
        await _redis_pool.aclose()
        _redis_pool = None


def _get_redis() -> aioredis.Redis:
    global _redis_pool
    if _redis_pool is None:
        _redis_pool = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _redis_pool


# ---------------------------------------------------------------------------
# Send helper
# ---------------------------------------------------------------------------


async def _send_whatsapp(client, jid: str, text: str) -> None:
    """Send a text message to a WhatsApp JID via neonize."""
    from neonize.utils.jid import build_jid

    if not text.strip():
        return
    user_part = jid.split("@")[0] if "@" in jid else jid
    server_part = jid.split("@")[1] if "@" in jid else "s.whatsapp.net"
    target = build_jid(user_part, server_part)
    try:
        await client.send_message(target, text)
    except Exception:
        logger.exception("whatsapp_send_failed jid=%s text_len=%s", jid, len(text))


async def _send_chunked(client, jid: str, text: str) -> None:
    """Send a potentially long message, splitting into chunks."""
    if len(text) <= _MAX_CHUNK_LEN:
        await _send_whatsapp(client, jid, text)
        return

    chunks = []
    while text:
        chunks.append(text[:_MAX_CHUNK_LEN])
        text = text[_MAX_CHUNK_LEN:]

    total = len(chunks)
    for i, chunk in enumerate(chunks, 1):
        prefix = f"(Part {i}/{total})\n" if total > 1 else ""
        await _send_whatsapp(client, jid, prefix + chunk)


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------


async def _get_whatsapp_account(db) -> ConnectedAccount | None:
    """Return the first active WhatsApp ConnectedAccount."""
    result = await db.execute(
        select(ConnectedAccount).where(
            ConnectedAccount.provider == "whatsapp",
            ConnectedAccount.status == "active",
        ).limit(1)
    )
    return result.scalar_one_or_none()


async def _get_default_user_id(db) -> UUID:
    """Return user_id from the active WhatsApp ConnectedAccount, falling back to first project."""
    account = await _get_whatsapp_account(db)
    if account:
        return account.user_id

    # Fallback: first project in DB
    result = await db.execute(select(User.id).order_by(User.created_at).limit(1))
    user_id = result.scalar_one_or_none()
    if user_id is None:
        raise RuntimeError("No projects in database — cannot create WhatsApp conversation")
    return user_id


async def get_or_create_whatsapp_conversation(
    jid: str,
    push_name: str | None = None,
    user_id: UUID | None = None,
) -> WhatsAppConversation:
    """Return WhatsAppConversation for the given JID, creating one if absent."""
    from percona.services import active_conversation_service

    async with async_session_factory() as db:
        stmt = select(WhatsAppConversation).where(WhatsAppConversation.jid == jid)
        result = await db.execute(stmt)
        wa_conv = result.scalar_one_or_none()

        if wa_conv:
            # Update push_name if changed
            if push_name and wa_conv.push_name != push_name:
                wa_conv.push_name = push_name
                await db.commit()
            return wa_conv

        if user_id is None:
            user_id = await _get_default_user_id(db)

        # Use the single active conversation for this user
        conv = await active_conversation_service.get_or_create_active_conversation(db, user_id)

        # Upsert WhatsAppConversation — ON CONFLICT DO NOTHING handles concurrent creation
        await db.execute(
            pg_insert(WhatsAppConversation)
            .values(
                user_id=user_id,
                jid=jid,
                push_name=push_name,
                conversation_id=conv.id,
            )
            .on_conflict_do_nothing(constraint="uq_whatsapp_conversations_jid")
        )
        await db.commit()

        # Re-fetch (may have been inserted by a concurrent request)
        result = await db.execute(stmt)
        wa_conv = result.scalar_one()
        logger.info(
            "whatsapp_conversation_created jid=%s push_name=%s conversation_id=%s",
            jid, push_name, conv.id,
        )
        return wa_conv


# ---------------------------------------------------------------------------
# Queue / worker machinery
# ---------------------------------------------------------------------------


class _WorkerCleanup:
    def __init__(self, conversation_id: str) -> None:
        self._conversation_id = conversation_id

    def __call__(self, t: asyncio.Task) -> None:
        _queues.pop(self._conversation_id, None)
        _workers.pop(self._conversation_id, None)
        if not t.cancelled() and (exc := t.exception()):
            logger.exception(
                "whatsapp_worker_died conversation_id=%s",
                self._conversation_id,
                exc_info=exc,
            )


async def _get_or_create_queue(conversation_id: str, client, jid: str) -> asyncio.Queue:
    """Return the queue for this conversation, creating a worker task if needed."""
    async with _queue_lock:
        existing_task = _workers.get(conversation_id)
        if existing_task is not None and existing_task.done():
            existing_q = _queues.get(conversation_id)
            if existing_q is None or existing_q.empty():
                _queues.pop(conversation_id, None)
                _workers.pop(conversation_id, None)

        if conversation_id not in _queues:
            q: asyncio.Queue = asyncio.Queue(maxsize=settings.whatsapp_queue_maxsize)
            _queues[conversation_id] = q
            task = asyncio.create_task(
                _queue_worker(client, conversation_id, jid, q),
                name=f"wa-worker-{conversation_id[:8]}",
            )
            _workers[conversation_id] = task
            task.add_done_callback(_WorkerCleanup(conversation_id))
            logger.info(
                "whatsapp_queue_worker_created conversation_id=%s jid=%s",
                conversation_id, jid,
            )

    return _queues[conversation_id]


async def _queue_worker(
    client,
    conversation_id: str,
    jid: str,
    queue: asyncio.Queue,
) -> None:
    """Serialize agent turns for one conversation."""
    logger.debug("whatsapp_worker_started conversation_id=%s jid=%s", conversation_id, jid)
    try:
        while True:
            queue_item = await queue.get()
            if isinstance(queue_item, str):
                user_message = queue_item
                attachments = None
            else:
                user_message = queue_item["text"]
                attachments = queue_item.get("attachments")
            logger.info(
                "whatsapp_worker_turn_received conversation_id=%s jid=%s queued=%s msg_len=%s attachments=%s",
                conversation_id, jid, queue.qsize(), len(user_message), len(attachments) if attachments else 0,
            )
            try:
                await _process_turn(client, conversation_id, jid, user_message, attachments)
            except Exception as exc:
                logger.exception(
                    "whatsapp_turn_failed conversation_id=%s jid=%s error=%s",
                    conversation_id, jid, exc,
                )
                try:
                    await _send_whatsapp(client, jid, f"Error: {exc}")
                except Exception:
                    pass
            finally:
                queue.task_done()
    except Exception as exc:
        logger.exception("whatsapp_worker_crashed conversation_id=%s error=%s", conversation_id, exc)
        drained = 0
        while not queue.empty():
            try:
                queue.get_nowait()
                drained += 1
                queue.task_done()
            except asyncio.QueueEmpty:
                break
        if drained:
            logger.warning("whatsapp_worker_drained conversation_id=%s count=%s", conversation_id, drained)


async def _process_turn(
    client,
    conversation_id: str,
    jid: str,
    user_message: str,
    attachments: list[dict] | None = None,
) -> None:
    """Run one agent turn, sending the final response back to WhatsApp.

    WhatsApp doesn't support message editing, so we accumulate the full
    response and send it as one or more messages when complete.
    """
    logger.info(
        "whatsapp_turn_start conversation_id=%s jid=%s user_len=%s",
        conversation_id, jid, len(user_message),
    )

    # Send processing indicator
    await _send_whatsapp(client, jid, "Processing...")

    # Subscribe to Redis BEFORE starting the agent
    r = _get_redis()
    pubsub = r.pubsub()
    channel = f"chat:{conversation_id}"
    try:
        await pubsub.subscribe(channel)
    except Exception as exc:
        logger.exception("whatsapp_pubsub_subscribe_failed conversation_id=%s error=%s", conversation_id, exc)
        await _send_whatsapp(client, jid, "Internal error subscribing to updates.")
        return

    # Set project context
    async with async_session_factory() as db:
        _conv = (await db.execute(
            select(Conversation).where(Conversation.id == UUID(conversation_id))
        )).scalar_one_or_none()
        if _conv and _conv.user_id:
            set_user_id(_conv.user_id)

    # Kick off the agent turn
    agent_task = asyncio.create_task(
        _run_chat_turn_async(conversation_id, user_message, attachments=attachments)
    )

    accumulated_text = ""
    last_tool_time = 0.0

    try:
        async for redis_msg in pubsub.listen():
            if redis_msg["type"] != "message":
                continue

            try:
                event = json.loads(redis_msg["data"])
            except (json.JSONDecodeError, KeyError):
                continue

            event_type = event.get("type", "")

            if event_type == "message":
                accumulated_text += event.get("content", "")

            elif event_type == "tool_call_start":
                # Send tool status as a brief separate message (throttled to 2s)
                now = time.monotonic()
                if (now - last_tool_time) >= 2.0:
                    tool_name = event.get("tool_name", "unknown")
                    await _send_whatsapp(client, jid, f"Running {tool_name}...")
                    last_tool_time = now

            elif event_type == "turn_end":
                if not accumulated_text and not event.get("success", True):
                    err = event.get("error") or "Agent failed with no output."
                    accumulated_text = f"Error: {err}"
                break

            elif event_type == "error":
                if not accumulated_text:
                    accumulated_text = f"Error: {event.get('message', 'Unknown error')}"
                break

    except Exception as exc:
        logger.warning("whatsapp_pubsub_error conversation_id=%s error=%s", conversation_id, exc)

    finally:
        # Unsubscribe first (fast), then close — each step is independently guarded
        for _cleanup_step, _cleanup_coro in [
            ("unsubscribe", pubsub.unsubscribe(channel)),
            ("aclose", pubsub.aclose()),
        ]:
            try:
                await asyncio.wait_for(_cleanup_coro, timeout=2.0)
            except Exception as exc:
                logger.warning(
                    "whatsapp_redis_cleanup_%s_failed conversation_id=%s error=%s",
                    _cleanup_step, conversation_id, exc,
                )

    # Wait for agent task to finish
    try:
        await asyncio.wait_for(agent_task, timeout=settings.whatsapp_drain_timeout_seconds)
    except asyncio.TimeoutError:
        logger.warning("whatsapp_agent_task_timeout conversation_id=%s", conversation_id)
        agent_task.cancel()
        try:
            await agent_task
        except asyncio.CancelledError:
            pass
    except asyncio.CancelledError:
        pass

    # Send the accumulated response
    final_text = accumulated_text.strip() or "Done."
    await _send_chunked(client, jid, final_text)

    logger.info(
        "whatsapp_turn_complete conversation_id=%s jid=%s accumulated_len=%s",
        conversation_id, jid, len(accumulated_text),
    )


# ---------------------------------------------------------------------------
# Entry point — called from WhatsAppAdapter event handler
# ---------------------------------------------------------------------------


async def handle_incoming_event(client, event) -> None:
    """Process an incoming WhatsApp message event from neonize."""
    from neonize.utils.jid import Jid2String

    info = event.Info
    message = event.Message

    # Extract JID first — needed to check agent group before IsFromMe filter
    jid = Jid2String(info.MessageSource.Chat)

    # Skip messages we sent, UNLESS it's the configured agent group.
    # In that group the user is the only sender, so IsFromMe is always true.
    if info.MessageSource.IsFromMe:
        async with async_session_factory() as _db:
            _account = await _get_whatsapp_account(_db)
        agent_group_jid = (_account.provider_metadata or {}).get("agent_group_jid") if _account else None
        if jid != agent_group_jid:
            return

    push_name = info.Pushname or None

    # Extract text content from various message types
    text = ""
    if message.conversation:
        text = message.conversation
    elif message.extendedTextMessage and message.extendedTextMessage.text:
        text = message.extendedTextMessage.text

    text = text.strip()
    if not text:
        return

    # Check allowed JIDs from ConnectedAccount metadata
    async with async_session_factory() as db:
        account = await _get_whatsapp_account(db)

    if account:
        metadata = account.provider_metadata or {}
        allowed_jids = metadata.get("allowed_jids", [])
        agent_group_jid = metadata.get("agent_group_jid")
        if allowed_jids and jid not in allowed_jids and jid != agent_group_jid:
            logger.warning("whatsapp_unauthorized_jid jid=%s", jid)
            return

    logger.info(
        "whatsapp_message_received jid=%s push_name=%s text_len=%s",
        jid, push_name, len(text),
    )

    # Check for configure trigger
    if text.lower() == _CONFIGURE_TRIGGER:
        wa_conv = await get_or_create_whatsapp_conversation(jid, push_name)
        from percona.channels.whatsapp.handlers.commands import start_configure_session

        await start_configure_session(client, jid, str(wa_conv.conversation_id))
        return

    # Check if in active config session
    from percona.channels.whatsapp.handlers.commands import handle_config_input

    if await handle_config_input(client, jid, text):
        return

    # Normal message — get/create conversation and queue
    wa_conv = await get_or_create_whatsapp_conversation(jid, push_name)
    conversation_id = str(wa_conv.conversation_id)

    queue = await _get_or_create_queue(conversation_id, client, jid)

    try:
        queue.put_nowait(text)
    except asyncio.QueueFull:
        logger.warning("whatsapp_queue_full conversation_id=%s jid=%s", conversation_id, jid)
        await _send_whatsapp(client, jid, "I'm still processing your previous message. Please wait.")
        return

    logger.info(
        "whatsapp_message_queued jid=%s conversation_id=%s queue_size=%s",
        jid, conversation_id, queue.qsize(),
    )
