"""WhatsApp configure command — text-based menu state machine.

Since WhatsApp has no rich UI (modals, inline keyboards), configuration
is done via numbered text menus with state stored in Redis (TTL 300s).
"""
import json
import logging
from uuid import UUID

import redis.asyncio as aioredis
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from percona.channels.config import MODELS_BY_AGENT, SYSTEM_PROMPT_PRESETS
from percona.config import settings
from percona.database import async_session_factory
from percona.models import AgentType, Conversation, ConversationMcpServer
from percona.models.integrations import McpServer

logger = logging.getLogger(__name__)

_CONFIG_TTL = 300  # 5 minutes

# Shared Redis pool (lazy init)
_redis_pool: aioredis.Redis | None = None


def _get_redis() -> aioredis.Redis:
    global _redis_pool
    if _redis_pool is None:
        _redis_pool = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _redis_pool


def _config_key(jid: str) -> str:
    return f"whatsapp:config:{jid}"


async def _get_state(jid: str) -> dict | None:
    r = _get_redis()
    raw = await r.get(_config_key(jid))
    if raw:
        return json.loads(raw)
    return None


async def _set_state(jid: str, state: dict) -> None:
    r = _get_redis()
    await r.set(_config_key(jid), json.dumps(state), ex=_CONFIG_TTL)


async def _clear_state(jid: str) -> None:
    r = _get_redis()
    await r.delete(_config_key(jid))


async def _send(client, jid: str, text: str) -> None:
    from percona.channels.whatsapp.handlers.message import _send_whatsapp

    await _send_whatsapp(client, jid, text)


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------


async def _get_conversation(conversation_id: str) -> Conversation | None:
    async with async_session_factory() as db:
        result = await db.execute(
            select(Conversation).where(Conversation.id == UUID(conversation_id))
        )
        return result.scalar_one_or_none()


async def _get_active_mcp_ids(conversation_id: str) -> set[str]:
    async with async_session_factory() as db:
        result = await db.execute(
            select(ConversationMcpServer.mcp_server_id).where(
                ConversationMcpServer.conversation_id == UUID(conversation_id)
            )
        )
        return {str(row) for row in result.scalars().all()}


async def _get_project_mcps(user_id: UUID) -> list[McpServer]:
    async with async_session_factory() as db:
        result = await db.execute(
            select(McpServer).where(McpServer.user_id == user_id, McpServer.enabled.is_(True))
            .order_by(McpServer.name)
        )
        return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def handle_config_input(client, jid: str, text: str) -> bool:
    """Handle input during an active config session. Returns True if consumed."""
    state = await _get_state(jid)
    if state is None:
        return False

    step = state.get("step", "main")
    conv_id = state["conversation_id"]
    choice = text.strip()

    if step == "main":
        await _handle_main(client, jid, choice, conv_id, state)
    elif step == "agent":
        await _handle_agent(client, jid, choice, conv_id, state)
    elif step == "model":
        await _handle_model(client, jid, choice, conv_id, state)
    elif step == "mcp":
        await _handle_mcp(client, jid, choice, conv_id, state)
    elif step == "prompt":
        await _handle_prompt(client, jid, choice, conv_id, state)
    elif step == "reset":
        await _handle_reset(client, jid, choice, conv_id, state)
    else:
        await _clear_state(jid)
        return False

    return True


async def start_configure_session(client, jid: str, conversation_id: str) -> None:
    """Start a new configure session and show the main menu."""
    state = {"step": "main", "conversation_id": conversation_id}
    await _set_state(jid, state)
    await _show_main_menu(client, jid, conversation_id)


# ---------------------------------------------------------------------------
# Main menu
# ---------------------------------------------------------------------------


async def _show_main_menu(client, jid: str, conversation_id: str) -> None:
    conv = await _get_conversation(conversation_id)
    if not conv:
        await _send(client, jid, "Error: conversation not found.")
        await _clear_state(jid)
        return

    agent = conv.agent_type.value if conv.agent_type else "unknown"
    model = (conv.agent_settings or {}).get("model", "default")

    menu = (
        f"Configuration\n"
        f"Current: {agent} / {model}\n"
        f"\n"
        f"1. Change agent backend\n"
        f"2. Change model\n"
        f"3. Toggle MCP servers\n"
        f"4. Change system prompt\n"
        f"5. Reset conversation\n"
        f"0. Cancel\n"
        f"\n"
        f"Reply with a number:"
    )
    await _send(client, jid, menu)


async def _handle_main(client, jid: str, choice: str, conv_id: str, state: dict) -> None:
    if choice == "0":
        await _clear_state(jid)
        await _send(client, jid, "Configuration closed.")
        return

    if choice == "1":
        state["step"] = "agent"
        await _set_state(jid, state)
        await _show_agent_menu(client, jid, conv_id)
    elif choice == "2":
        state["step"] = "model"
        await _set_state(jid, state)
        await _show_model_menu(client, jid, conv_id)
    elif choice == "3":
        state["step"] = "mcp"
        await _set_state(jid, state)
        await _show_mcp_menu(client, jid, conv_id)
    elif choice == "4":
        state["step"] = "prompt"
        await _set_state(jid, state)
        await _show_prompt_menu(client, jid)
    elif choice == "5":
        state["step"] = "reset"
        await _set_state(jid, state)
        await _send(client, jid, "Reset conversation? This starts a fresh agent session.\n\n1. Yes, reset\n0. No, cancel")
    else:
        await _send(client, jid, "Invalid option. Reply with a number (0-5):")


# ---------------------------------------------------------------------------
# Agent selection
# ---------------------------------------------------------------------------


async def _show_agent_menu(client, jid: str, conv_id: str) -> None:
    conv = await _get_conversation(conv_id)
    current = conv.agent_type.value if conv else "unknown"

    agents = [at.value for at in AgentType]
    lines = ["Select agent backend:\n"]
    for i, agent in enumerate(agents, 1):
        marker = " (current)" if agent == current else ""
        lines.append(f"{i}. {agent}{marker}")
    lines.append("0. Back")
    await _send(client, jid, "\n".join(lines))


async def _handle_agent(client, jid: str, choice: str, conv_id: str, state: dict) -> None:
    if choice == "0":
        state["step"] = "main"
        await _set_state(jid, state)
        await _show_main_menu(client, jid, conv_id)
        return

    agents = [at.value for at in AgentType]
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(agents):
            new_agent = agents[idx]
            async with async_session_factory() as db:
                conv = (await db.execute(
                    select(Conversation).where(Conversation.id == UUID(conv_id))
                )).scalar_one_or_none()
                if conv:
                    conv.agent_type = AgentType(new_agent)
                    conv.agent_native_session_id = None  # Reset session for new agent
                    await db.commit()

            await _send(client, jid, f"Agent set to: {new_agent}")
            state["step"] = "main"
            await _set_state(jid, state)
            await _show_main_menu(client, jid, conv_id)
            return
    except (ValueError, IndexError):
        pass

    await _send(client, jid, "Invalid option. Try again:")


# ---------------------------------------------------------------------------
# Model selection
# ---------------------------------------------------------------------------


async def _show_model_menu(client, jid: str, conv_id: str) -> None:
    conv = await _get_conversation(conv_id)
    if not conv:
        await _send(client, jid, "Error: conversation not found.")
        return

    agent = conv.agent_type.value
    current_model = (conv.agent_settings or {}).get("model", "")
    models = MODELS_BY_AGENT.get(agent, [])

    if not models:
        await _send(client, jid, f"No models available for {agent}.")
        state = await _get_state(jid)
        if state:
            state["step"] = "main"
            await _set_state(jid, state)
        await _show_main_menu(client, jid, conv_id)
        return

    lines = [f"Select model for {agent}:\n"]
    for i, (model_id, label) in enumerate(models, 1):
        marker = " (current)" if model_id == current_model else ""
        lines.append(f"{i}. {label}{marker}")
    lines.append("0. Back")
    await _send(client, jid, "\n".join(lines))


async def _handle_model(client, jid: str, choice: str, conv_id: str, state: dict) -> None:
    if choice == "0":
        state["step"] = "main"
        await _set_state(jid, state)
        await _show_main_menu(client, jid, conv_id)
        return

    conv = await _get_conversation(conv_id)
    if not conv:
        return

    agent = conv.agent_type.value
    models = MODELS_BY_AGENT.get(agent, [])

    try:
        idx = int(choice) - 1
        if 0 <= idx < len(models):
            model_id, label = models[idx]
            async with async_session_factory() as db:
                conv = (await db.execute(
                    select(Conversation).where(Conversation.id == UUID(conv_id))
                )).scalar_one_or_none()
                if conv:
                    agent_settings = dict(conv.agent_settings or {})
                    agent_settings["model"] = model_id
                    conv.agent_settings = agent_settings
                    await db.commit()

            await _send(client, jid, f"Model set to: {label}")
            state["step"] = "main"
            await _set_state(jid, state)
            await _show_main_menu(client, jid, conv_id)
            return
    except (ValueError, IndexError):
        pass

    await _send(client, jid, "Invalid option. Try again:")


# ---------------------------------------------------------------------------
# MCP servers toggle
# ---------------------------------------------------------------------------


async def _show_mcp_menu(client, jid: str, conv_id: str) -> None:
    conv = await _get_conversation(conv_id)
    if not conv:
        return

    mcps = await _get_project_mcps(conv.user_id)
    active_ids = await _get_active_mcp_ids(conv_id)

    if not mcps:
        await _send(client, jid, "No MCP servers available.")
        state = await _get_state(jid)
        if state:
            state["step"] = "main"
            await _set_state(jid, state)
        await _show_main_menu(client, jid, conv_id)
        return

    lines = ["MCP Servers (reply number to toggle):\n"]
    for i, mcp in enumerate(mcps, 1):
        check = "[x]" if str(mcp.id) in active_ids else "[ ]"
        lines.append(f"{i}. {check} {mcp.name}")
    lines.append("\n0. Save & back")

    # Store MCP IDs in state for reference
    state = await _get_state(jid) or {}
    state["mcp_ids"] = [str(mcp.id) for mcp in mcps]
    await _set_state(jid, state)

    await _send(client, jid, "\n".join(lines))


async def _handle_mcp(client, jid: str, choice: str, conv_id: str, state: dict) -> None:
    if choice == "0":
        state["step"] = "main"
        state.pop("mcp_ids", None)
        await _set_state(jid, state)
        await _show_main_menu(client, jid, conv_id)
        return

    mcp_ids = state.get("mcp_ids", [])
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(mcp_ids):
            mcp_id = mcp_ids[idx]
            active_ids = await _get_active_mcp_ids(conv_id)

            async with async_session_factory() as db:
                if mcp_id in active_ids:
                    # Remove
                    from sqlalchemy import delete
                    await db.execute(
                        delete(ConversationMcpServer).where(
                            ConversationMcpServer.conversation_id == UUID(conv_id),
                            ConversationMcpServer.mcp_server_id == UUID(mcp_id),
                        )
                    )
                    await db.commit()
                else:
                    # Add
                    await db.execute(
                        pg_insert(ConversationMcpServer)
                        .values(conversation_id=UUID(conv_id), mcp_server_id=UUID(mcp_id))
                        .on_conflict_do_nothing()
                    )
                    await db.commit()

            # Re-show menu
            await _show_mcp_menu(client, jid, conv_id)
            return
    except (ValueError, IndexError):
        pass

    await _send(client, jid, "Invalid option. Try again:")


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------


async def _show_prompt_menu(client, jid: str) -> None:
    lines = ["Select system prompt preset:\n"]
    for i, (key, label, _) in enumerate(SYSTEM_PROMPT_PRESETS, 1):
        lines.append(f"{i}. {label}")
    lines.append(f"{len(SYSTEM_PROMPT_PRESETS) + 1}. Custom (type your own next)")
    lines.append("0. Back")
    await _send(client, jid, "\n".join(lines))


async def _handle_prompt(client, jid: str, choice: str, conv_id: str, state: dict) -> None:
    if choice == "0":
        state["step"] = "main"
        await _set_state(jid, state)
        await _show_main_menu(client, jid, conv_id)
        return

    # Check if we're in custom prompt mode
    if state.get("awaiting_custom_prompt"):
        # The entire message is the custom prompt
        async with async_session_factory() as db:
            conv = (await db.execute(
                select(Conversation).where(Conversation.id == UUID(conv_id))
            )).scalar_one_or_none()
            if conv:
                conv.system_prompt = choice  # choice is the full text
                await db.commit()

        await _send(client, jid, "Custom system prompt set.")
        state["step"] = "main"
        state.pop("awaiting_custom_prompt", None)
        await _set_state(jid, state)
        await _show_main_menu(client, jid, conv_id)
        return

    try:
        idx = int(choice) - 1
        if 0 <= idx < len(SYSTEM_PROMPT_PRESETS):
            _, label, prompt_text = SYSTEM_PROMPT_PRESETS[idx]
            async with async_session_factory() as db:
                conv = (await db.execute(
                    select(Conversation).where(Conversation.id == UUID(conv_id))
                )).scalar_one_or_none()
                if conv:
                    conv.system_prompt = prompt_text
                    await db.commit()

            await _send(client, jid, f"System prompt set to: {label}")
            state["step"] = "main"
            await _set_state(jid, state)
            await _show_main_menu(client, jid, conv_id)
            return

        if idx == len(SYSTEM_PROMPT_PRESETS):
            # Custom prompt mode
            state["awaiting_custom_prompt"] = True
            await _set_state(jid, state)
            await _send(client, jid, "Type your custom system prompt:")
            return
    except (ValueError, IndexError):
        pass

    await _send(client, jid, "Invalid option. Try again:")


# ---------------------------------------------------------------------------
# Reset conversation
# ---------------------------------------------------------------------------


async def _handle_reset(client, jid: str, choice: str, conv_id: str, state: dict) -> None:
    if choice == "1":
        async with async_session_factory() as db:
            conv = (await db.execute(
                select(Conversation).where(Conversation.id == UUID(conv_id))
            )).scalar_one_or_none()
            if conv:
                conv.agent_native_session_id = None
                await db.commit()

        await _send(client, jid, "Conversation reset. Next message starts a fresh session.")
    else:
        await _send(client, jid, "Reset cancelled.")

    state["step"] = "main"
    await _set_state(jid, state)
    await _show_main_menu(client, jid, conv_id)
