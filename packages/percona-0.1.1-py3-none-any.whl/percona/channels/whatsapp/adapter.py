"""WhatsAppAdapter — connects via neonize (whatsmeow) to WhatsApp Web.

Runs inside the FastAPI process, same pattern as TelegramAdapter with PTB.

Lifecycle:
- On startup: queries ConnectedAccount(provider="whatsapp", status="active") from DB
  and reconnects existing sessions.
- On pairing: creates a temp neonize client, captures QR events, and on success
  creates a ConnectedAccount and moves the client to the active pool.

Neonize API notes (v0.3.x):
- NewAClient(name) — `name` is both the client identifier AND the SQLite session DB
  path (Go binary opens it as a file path). Pass the full path (e.g. /data/whatsapp/id.db).
- QR callback: client.qr(async_fn) — receives (client, qr_bytes: bytes)
- Event registration: @client.event(EventType) — ConnectedEv, MessageEv, etc.
- After ConnectedEv fires, client.me.JID holds the device JID (set via Device event).
- Jid2String(jid) converts a JID proto to "user@server" string.
"""
import asyncio
import logging
from pathlib import Path
from uuid import UUID

from sqlalchemy import select

from percona.channels.base import IChannelAdapter
from percona.config import settings
from percona.database import async_session_factory
from percona.models.integrations import ConnectedAccount

logger = logging.getLogger(__name__)


class WhatsAppAdapter(IChannelAdapter):
    channel_type = "whatsapp"

    def __init__(self):
        # Active clients keyed by str(account_id)
        self._clients: dict[str, object] = {}
        self._connect_tasks: dict[str, asyncio.Task] = {}
        # Temp pairing clients keyed by pair_id
        self._pairing_clients: dict[str, object] = {}
        self._pairing_tasks: dict[str, asyncio.Task] = {}
        # Lock protecting pairing dicts from concurrent access
        self._pairing_lock = asyncio.Lock()

    def is_enabled(self) -> bool:
        return True  # Always enabled — starts with active accounts from DB, no-op if none

    def _session_db_path(self, account_id: str) -> str:
        """Return the session DB path for an account.

        The path is passed as the neonize client `name`, which the Go binary
        uses as the SQLite file path directly.
        """
        base = Path(settings.whatsapp_session_db).parent
        base.mkdir(parents=True, exist_ok=True)
        return str(base / f"{account_id}.db")

    def _pairing_db_path(self, pair_id: str) -> str:
        """Return a temp session DB path for a pairing session."""
        base = Path(settings.whatsapp_session_db).parent / "pairing"
        base.mkdir(parents=True, exist_ok=True)
        return str(base / f"{pair_id}.db")

    async def start(self) -> None:
        """Reconnect all active WhatsApp accounts from the DB."""
        # Register adapter reference for notification_service
        from percona.services import whatsapp_service as _wa_svc
        _wa_svc.set_adapter(self)

        async with async_session_factory() as db:
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.provider == "whatsapp",
                    ConnectedAccount.status == "active",
                )
            )
            accounts = result.scalars().all()
            # Extract IDs before closing the session to avoid detached instance errors
            account_ids = [(str(a.id), a.provider_account_id or "") for a in accounts]

        if not account_ids:
            logger.info("whatsapp_adapter_started no_active_accounts")
            return

        for account_id, jid in account_ids:
            logger.info("whatsapp_reconnecting account_id=%s jid=%s", account_id, jid)
            await self._start_client(account_id)

        logger.info("whatsapp_adapter_started active_accounts=%s", len(account_ids))

    async def _start_client(self, account_id: str) -> None:
        """Start a neonize client for an existing account."""
        from neonize.aioze.client import NewAClient
        from neonize.events import ConnectedEv, MessageEv

        # Pass the full DB path as the name — neonize uses it as the SQLite file path
        db_path = self._session_db_path(account_id)
        client = NewAClient(db_path)

        @client.event(ConnectedEv)
        async def on_connected(c, event):
            try:
                from neonize.utils.jid import Jid2String
                jid = Jid2String(c.me.JID) if c.me else "unknown"
                logger.info("whatsapp_reconnected account_id=%s jid=%s", account_id, jid)
            except Exception:
                logger.exception("whatsapp_reconnected_handler_error account_id=%s", account_id)

        @client.event(MessageEv)
        async def on_message(c, event):
            from percona.channels.whatsapp.handlers.message import handle_incoming_event
            try:
                await handle_incoming_event(c, event)
            except Exception:
                logger.exception("whatsapp_message_handler_error account_id=%s", account_id)

        self._clients[account_id] = client
        task = asyncio.create_task(self._connect(client, account_id), name=f"wa-connect-{account_id[:8]}")
        self._connect_tasks[account_id] = task

    async def _connect(self, client, identifier: str) -> None:
        try:
            await client.connect()
        except Exception:
            logger.exception("whatsapp_connect_failed id=%s", identifier)

    # -----------------------------------------------------------------------
    # QR Pairing
    # -----------------------------------------------------------------------

    async def start_pairing(self, user_id: UUID, pair_id: str) -> None:
        """Start a temporary neonize client for QR-based pairing."""
        from neonize.aioze.client import NewAClient
        from neonize.events import ConnectedEv
        from neonize.utils.jid import Jid2String

        from percona.services import whatsapp_service

        # Pass the full DB path as the name — neonize creates the SQLite file at this path
        db_path = self._pairing_db_path(pair_id)
        client = NewAClient(db_path)

        async def on_qr(c, qr_bytes: bytes) -> None:
            """Called by neonize when the QR code is ready to scan."""
            try:
                qr_string = qr_bytes.decode("utf-8", errors="replace")
                logger.info("whatsapp_qr_received pair_id=%s", pair_id)
                await whatsapp_service.set_qr(pair_id, qr_string)
            except Exception:
                logger.exception("whatsapp_qr_handler_error pair_id=%s", pair_id)
                await whatsapp_service.set_error(pair_id, "Failed to process QR code")

        # Register QR callback via the dedicated client.qr() API
        client.qr(on_qr)

        @client.event(ConnectedEv)
        async def on_connected(c, event) -> None:
            try:
                jid = Jid2String(c.me.JID) if c.me else "unknown"
                logger.info("whatsapp_pairing_success pair_id=%s jid=%s", pair_id, jid)

                # Create ConnectedAccount in DB
                async with async_session_factory() as db:
                    account = await whatsapp_service.create_whatsapp_account(db, user_id, jid)
                    await db.commit()
                    account_id = str(account.id)

                # Update Redis status
                await whatsapp_service.set_connected(pair_id, jid)

                # Move pairing DB to permanent location
                import shutil
                permanent_path = self._session_db_path(account_id)
                try:
                    shutil.move(db_path, permanent_path)
                except Exception:
                    logger.warning("whatsapp_session_move_failed pair_id=%s", pair_id)

                # Remove pairing entries under lock
                async with self._pairing_lock:
                    self._pairing_clients.pop(pair_id, None)
                    self._pairing_tasks.pop(pair_id, None)

                # Start a proper client for this account
                await self._start_client(account_id)

            except Exception:
                logger.exception("whatsapp_connected_handler_error pair_id=%s", pair_id)
                await whatsapp_service.set_error(pair_id, "Failed to complete pairing")

        async with self._pairing_lock:
            self._pairing_clients[pair_id] = client
            task = asyncio.create_task(self._connect(client, f"pair-{pair_id[:8]}"), name=f"wa-pair-{pair_id[:8]}")
            self._pairing_tasks[pair_id] = task

    async def stop_pairing(self, pair_id: str) -> None:
        """Cancel an in-progress pairing session."""
        async with self._pairing_lock:
            task = self._pairing_tasks.pop(pair_id, None)
            client = self._pairing_clients.pop(pair_id, None)

        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        if client is not None:
            try:
                await client.disconnect()
            except Exception:
                logger.debug("whatsapp_pairing_disconnect_error pair_id=%s", pair_id)

        logger.info("whatsapp_pairing_stopped pair_id=%s", pair_id)

    async def stop_client(self, account_id: str) -> None:
        """Stop and clean up the client for a disconnected account."""
        task = self._connect_tasks.pop(account_id, None)
        client = self._clients.pop(account_id, None)

        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        if client is not None:
            try:
                await client.disconnect()
            except Exception:
                logger.debug("whatsapp_client_disconnect_error account_id=%s", account_id)

        # Delete the session DB so a fresh pairing starts clean
        import os
        db_path = self._session_db_path(account_id)
        try:
            os.unlink(db_path)
            logger.info("whatsapp_session_db_deleted account_id=%s", account_id)
        except FileNotFoundError:
            pass
        except Exception:
            logger.warning("whatsapp_session_db_delete_failed account_id=%s", account_id)

        logger.info("whatsapp_client_stopped account_id=%s", account_id)

    # -----------------------------------------------------------------------
    # Shutdown
    # -----------------------------------------------------------------------

    async def stop(self) -> None:
        from percona.channels.whatsapp.handlers.message import shutdown_all_workers

        await shutdown_all_workers()

        # Disconnect all active clients gracefully
        for account_id, client in list(self._clients.items()):
            try:
                await client.disconnect()
            except Exception:
                logger.debug("whatsapp_client_disconnect_error account_id=%s", account_id)

        # Cancel all connect tasks
        all_tasks = list(self._connect_tasks.values()) + list(self._pairing_tasks.values())
        for task in all_tasks:
            if not task.done():
                task.cancel()
        if all_tasks:
            await asyncio.gather(*all_tasks, return_exceptions=True)

        self._clients.clear()
        self._connect_tasks.clear()
        self._pairing_clients.clear()
        self._pairing_tasks.clear()
        logger.info("whatsapp_adapter_stopped")

    @property
    def client(self):
        """Return the first active client (for backwards compat)."""
        if self._clients:
            return next(iter(self._clients.values()))
        return None
