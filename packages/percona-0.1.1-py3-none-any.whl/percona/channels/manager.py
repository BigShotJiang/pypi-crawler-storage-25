import logging

from percona.channels.base import IChannelAdapter
from percona.channels.telegram.adapter import TelegramAdapter
from percona.channels.slack.adapter import SlackAdapter
from percona.channels.whatsapp.adapter import WhatsAppAdapter

logger = logging.getLogger(__name__)


class ChannelManager:
    """Lifecycle manager for all channel adapters."""

    def __init__(self):
        self._adapters: list[IChannelAdapter] = [
            TelegramAdapter(),
            SlackAdapter(),
            WhatsAppAdapter(),
        ]

    async def start(self) -> None:
        for adapter in self._adapters:
            if adapter.is_enabled():
                logger.info("channel_adapter_starting type=%s", adapter.channel_type)
                try:
                    await adapter.start()
                    logger.info("channel_adapter_started type=%s", adapter.channel_type)
                except Exception:
                    logger.exception("channel_adapter_start_failed type=%s", adapter.channel_type)
            else:
                logger.debug("channel_adapter_disabled type=%s", adapter.channel_type)

    def get_adapter(self, channel_type: str) -> IChannelAdapter | None:
        return next((a for a in self._adapters if a.channel_type == channel_type), None)

    async def stop(self) -> None:
        for adapter in self._adapters:
            if adapter.is_enabled():
                logger.info("channel_adapter_stopping type=%s", adapter.channel_type)
                try:
                    await adapter.stop()
                    logger.info("channel_adapter_stopped type=%s", adapter.channel_type)
                except Exception:
                    logger.exception("channel_adapter_stop_failed type=%s", adapter.channel_type)
