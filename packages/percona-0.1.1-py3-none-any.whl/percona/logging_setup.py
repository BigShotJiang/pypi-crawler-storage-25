import contextvars
import logging

from percona.config import settings

_CONFIGURED = False

trace_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("trace_id", default="")

_old_factory = logging.getLogRecordFactory()

def _record_factory(*args, **kwargs):
    record = _old_factory(*args, **kwargs)
    trace_id = trace_id_var.get()
    record.trace_id = f" [trace={trace_id}]" if trace_id else ""
    return record


def configure_logging() -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return

    level_name = (settings.log_level or "INFO").upper()
    if settings.debug and level_name == "INFO":
        level_name = "DEBUG"
    level = getattr(logging, level_name, logging.INFO)

    logging.setLogRecordFactory(_record_factory)

    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s [%(name)s]%(trace_id)s %(message)s",
    )

    # Suppress chatty third-party loggers
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.INFO)
    logging.getLogger("sse_starlette").setLevel(logging.WARNING)
    # MCP library logs ClosedResourceError as ERROR when a client disconnects mid-stream — harmless
    logging.getLogger("mcp.server.streamable_http_manager").setLevel(logging.CRITICAL)
    logging.getLogger("mcp.server.streamable_http").setLevel(logging.CRITICAL)
    logging.getLogger("mcp.server.lowlevel.server").setLevel(logging.WARNING)

    _CONFIGURED = True
