import logging

import sqlalchemy as sa
from sqlalchemy import select

from percona.config import settings
from percona.database import async_session_factory
from percona.defaults import GLOBAL_SYSTEM_PROMPT
from percona.models import McpServer, TaskTemplate
from percona.models import AgentType, Setting
from percona.models.users import User
from percona.services.auth_service import hash_password

logger = logging.getLogger(__name__)

TEMPLATES = [
    {
        "name": "Memory Extractor",
        "slug": "memory-extractor",
        "description": "Scans recent conversations and sessions, extracts important facts, and saves them to your memory store.",
        "default_cron": "0 22 * * *",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "You are a memory assistant. Extract and save important facts from conversations.",
        "default_mcp_servers": ["percona"],
        "default_timeout_seconds": 300,
        "icon": "brain",
        "color": "purple",
    },
    {
        "name": "Daily Briefing",
        "slug": "daily-briefing",
        "description": "Generates a personalized daily briefing with your todos, reminders, and key priorities.",
        "default_cron": "0 8 * * *",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "You are a personal assistant generating a daily briefing.",
        "default_mcp_servers": ["percona", "percona-notify"],
        "default_timeout_seconds": 300,
        "icon": "sun",
        "color": "yellow",
    },
    {
        "name": "Weekly Review",
        "slug": "weekly-review",
        "description": "Reviews completed tasks, sessions, and memories from the past week and generates a summary report.",
        "default_cron": "0 9 * * 0",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "You are a personal productivity assistant doing a weekly review.",
        "default_mcp_servers": ["percona", "percona-notify"],
        "default_timeout_seconds": 600,
        "icon": "calendar",
        "color": "blue",
    },
    {
        "name": "Custom Task",
        "slug": "custom",
        "description": "A blank template for creating custom automation tasks.",
        "default_cron": "",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "You are a helpful personal AI assistant.",
        "default_mcp_servers": ["percona", "percona-notify", "percona-google"],
        "default_timeout_seconds": 600,
        "icon": "settings",
        "color": "gray",
    },
]


_TEMPLATE_SYNC_FIELDS = (
    "name", "description", "default_cron", "default_agent_type",
    "system_prompt", "default_mcp_servers", "default_timeout_seconds", "icon", "color",
)


async def seed_default_admin():
    async with async_session_factory() as session:
        result = await session.execute(
            select(sa.func.count()).select_from(User).where(User.hashed_password.isnot(None), User.hashed_password != "")
        )
        count = result.scalar()
        if count > 0:
            logger.debug("seed_default_admin_skipped auth_users_exist=%s", count)
            return

        email = settings.admin_email
        password = settings.admin_password
        username = email.split("@")[0]
        user = User(
            name="Admin",
            slug=username.lower().replace(" ", "-"),
            email=email,
            hashed_password=hash_password(password),
            full_name="Admin",
            role="admin",
            is_active=True,
            account_status="active",
        )
        session.add(user)
        await session.commit()
        logger.info("seed_default_admin_created email=%s", email)


async def seed_templates():
    """Seed task templates for all projects."""
    logger.debug("seed_templates_start")
    async with async_session_factory() as session:
        created_count = 0
        updated_count = 0

        # Get all projects
        result = await session.execute(select(sa.func.distinct(TaskTemplate.user_id)).select_from(TaskTemplate))
        all_user_ids = [row[0] for row in result if row[0]]

        for user_id in all_user_ids:
            for tmpl_data in TEMPLATES:
                stmt = select(TaskTemplate).where(
                    TaskTemplate.user_id == user_id,
                    TaskTemplate.slug == tmpl_data["slug"]
                )
                result = await session.execute(stmt)
                existing = result.scalar_one_or_none()
                if not existing:
                    session.add(TaskTemplate(**tmpl_data, user_id=user_id))
                    created_count += 1
                else:
                    for field in _TEMPLATE_SYNC_FIELDS:
                        if field in tmpl_data:
                            setattr(existing, field, tmpl_data[field])
                    updated_count += 1

        await session.commit()
        logger.info("seed_templates_completed created=%s updated=%s total=%s", created_count, updated_count, len(TEMPLATES))


DEFAULT_SETTINGS = [
    {"key": "brand_name",           "value": "Percona",                    "description": "Customer-facing brand name"},
    {"key": "brand_tagline",        "value": "Personal AI Assistant",        "description": "Short marketing tagline"},
    {"key": "brand_logo_url",       "value": "",                            "description": "Brand logo URL"},
    {"key": "brand_favicon_url",    "value": "",                            "description": "Favicon URL"},
    {"key": "brand_background_url", "value": "",                            "description": "Background watermark image URL"},
    {"key": "theme_preset",         "value": "darkGold",                    "description": "Selected theme preset"},
    {"key": "theme_mode",           "value": "dark",                        "description": "light or dark"},
    {"key": "theme_primary",        "value": "#d4af37",                     "description": "Primary color"},
    {"key": "theme_background",     "value": "#050505",                     "description": "Background color"},
    {"key": "theme_accent",         "value": "#0f0f17",                     "description": "Accent color"},
    {"key": "theme_border",         "value": "#1f1f28",                     "description": "Border color"},
    {"key": "theme_muted",          "value": "#11131a",                     "description": "Muted surface color"},
    # AI Agent
    {"key": "global_system_prompt", "value": GLOBAL_SYSTEM_PROMPT, "description": "Global system prompt prepended to every agent session — gives the agent identity, personality, and platform context"},
    # Notifications
    {"key": "slack_webhook_url",    "value": "",                            "description": "Slack incoming webhook URL for notifications"},
    {"key": "email_recipients",     "value": "",                            "description": "Comma-separated email addresses for notifications"},
    {"key": "pushover_user_key",    "value": "",                            "description": "Pushover user key for push notifications"},
    {"key": "pushover_api_token",   "value": "",                            "description": "Pushover application API token"},
]


async def seed_default_settings():
    """Legacy settings seeding - deprecated.

    Settings are now project-scoped via ProjectSettings table.
    The migration backfills from old settings table.
    ProjectSettings are auto-created with defaults on first access via get_or_create_default_settings.
    """
    logger.debug("seed_default_settings_skipped - settings are now project-scoped")


INTERNAL_MCP_SERVERS = [
    {
        "name": "Percona Core",
        "slug": "percona",
        "description": "Core ops tools: incidents, findings, reports, skills, todos, file storage",
        "transport": "http",
        "url_path": "/mcp/core/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "Percona Notify",
        "slug": "percona-notify",
        "description": "Notification tools: Slack, email, Pushover, and scheduled reminders",
        "transport": "http",
        "url_path": "/mcp/notify/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "Percona Google",
        "slug": "percona-google",
        "description": "Google Workspace tools: Gmail, Calendar, and Drive",
        "transport": "http",
        "url_path": "/mcp/google/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "Percona Slack",
        "slug": "percona-slack",
        "description": "Slack workspace tools: list channels, read messages, and threads",
        "transport": "http",
        "url_path": "/mcp/slack/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "Percona WhatsApp",
        "slug": "percona-whatsapp",
        "description": "WhatsApp tools: list groups, list contacts, and read message history",
        "transport": "http",
        "url_path": "/mcp/whatsapp/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "Percona Task Automation",
        "slug": "percona-tasks",
        "description": "Create, list, update, trigger, and delete automation tasks.",
        "transport": "http",
        "url_path": "/mcp/tasks/mcp",
        "is_internal": True,
        "enabled": False,
    },
    {
        "name": "Percona Microsoft",
        "slug": "percona-microsoft",
        "description": "Microsoft 365 tools: Outlook Mail, Calendar, OneDrive, To Do, OneNote, Planner, Teams, SharePoint, Contacts, Excel",
        "transport": "http",
        "url_path": "/mcp/microsoft/mcp",
        "is_internal": True,
        "enabled": True,
    },
]


async def seed_mcp_servers_for_project(db, user_id):
    """Seed internal MCP servers for a specific project."""
    for _srv in INTERNAL_MCP_SERVERS:
        srv_data = dict(_srv)
        url_path = srv_data.pop("url_path")
        full_url = f"{settings.api_base_url}{url_path}"
        stmt = select(McpServer).where(
            McpServer.user_id == user_id,
            McpServer.slug == srv_data["slug"]
        )
        existing = (await db.execute(stmt)).scalar_one_or_none()
        if not existing:
            db.add(McpServer(
                **srv_data,
                user_id=user_id,
                url=full_url,
                command="",
            ))
            logger.info("seed_mcp_server_for_project user_id=%s slug=%s", user_id, srv_data["slug"])


async def seed_task_templates_for_project(db, user_id):
    """Seed task templates for a specific project."""
    for tmpl in TEMPLATES:
        tmpl_data = dict(tmpl)
        stmt = select(TaskTemplate).where(
            TaskTemplate.user_id == user_id,
            TaskTemplate.slug == tmpl_data["slug"]
        )
        existing = (await db.execute(stmt)).scalar_one_or_none()
        if not existing:
            db.add(TaskTemplate(
                **tmpl_data,
                user_id=user_id,
            ))
            logger.info("seed_task_template_for_project user_id=%s slug=%s", user_id, tmpl_data["slug"])


async def seed_collection_templates_for_user(db, user_id):
    """Seed collection templates for a specific user."""
    from percona.services.collection_templates import seed_templates_for_user, upgrade_existing_collections
    await upgrade_existing_collections(db, user_id)
    await seed_templates_for_user(db, user_id)


async def seed_internal_mcp_servers():
    """Seed internal MCP servers for all users."""
    async with async_session_factory() as session:
        result = await session.execute(select(User.id).where(User.is_active == True))
        user_ids = [row[0] for row in result]

        for user_id in user_ids:
            await seed_mcp_servers_for_project(session, user_id)

        await session.commit()


async def seed_collection_templates():
    """Seed collection templates for all active users and upgrade existing collections."""
    from percona.services.collection_templates import seed_templates_for_user, upgrade_existing_collections

    async with async_session_factory() as session:
        result = await session.execute(select(User.id).where(User.is_active == True))
        user_ids = [row[0] for row in result]

        total_created = 0
        total_upgraded = 0
        for user_id in user_ids:
            total_upgraded += await upgrade_existing_collections(session, user_id)
            total_created += await seed_templates_for_user(session, user_id)

        await session.commit()
        logger.info(
            "seed_collection_templates_completed users=%s created=%s upgraded=%s",
            len(user_ids), total_created, total_upgraded,
        )
