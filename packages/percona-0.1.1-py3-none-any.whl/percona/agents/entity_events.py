"""Entity event extraction from MCP tool results.

Maps tool names + actions to entity types and extracts structured data
from tool results for UI entity cards.

Used by:
- Backend: chat.py (entity extraction + SSE emission + persistence)
- Frontend: entity-card.tsx (renders cards)
"""

import json
import logging
import re
from typing import Any

logger = logging.getLogger(__name__)


# Frontend routes for each entity type
ENTITY_URLS: dict[str, str] = {
    "todo": "/todos",
    "reminder": "/reminders",
    "report": "/reports",
    "skill": "/skills",
    "memory": "/memories",
    "collection": "/collections",
}

# Maps (tool_name, action) → entity_type
# The tool_name is the MCP tool function name as registered (e.g. "transaction", "todo")
# For tools registered as mcp__percona__<name>, we match on <name>
TOOL_ENTITY_MAP: dict[str, str] = {
    "todo": "todo",
    "reminder": "reminder",
    "create_report": "report",
    "skill": "skill",
    "memory": "memory",
    "collection": "collection",
}

# Actions that produce entity events
MUTATING_ACTIONS = {"create", "update", "delete", "complete", "cancel"}


def _extract_tool_short_name(tool_name: str) -> str:
    """Extract the short tool name from qualified MCP tool name.

    Examples:
        "mcp__percona__todo" → "todo"
        "mcp__percona__create_report" → "create_report"
        "todo" → "todo"
    """
    if tool_name.startswith("mcp__percona__"):
        return tool_name[len("mcp__percona__"):]
    if tool_name.startswith("mcp__"):
        # e.g. mcp__percona-notify__send_slack_notification
        parts = tool_name.split("__", 2)
        return parts[-1] if len(parts) >= 3 else tool_name
    return tool_name


def _parse_json_result(result: Any) -> dict | None:
    """Parse JSON from tool result string."""
    if isinstance(result, dict):
        return result
    if isinstance(result, str):
        try:
            parsed = json.loads(result)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
    return None


def _determine_action(tool_input: dict | None, tool_name_short: str) -> str | None:
    """Determine the CRUD action from tool input or tool name."""
    if tool_input and "action" in tool_input:
        return tool_input["action"]
    # Some tools encode action in name (e.g. "create_report")
    for action in MUTATING_ACTIONS:
        if tool_name_short.startswith(action):
            return action
    return None


def extract_entity_from_tool_result(
    tool_name: str,
    tool_input: dict | None,
    tool_result: Any,
) -> dict | None:
    """Extract entity information from a completed tool call.

    Returns a dict with keys: entity_type, event_type, entity_id, entity_title,
    entity_url, metadata. Returns None if the tool is not an entity-producing tool
    or the result can't be parsed.
    """
    short_name = _extract_tool_short_name(tool_name)
    entity_type = TOOL_ENTITY_MAP.get(short_name)
    if not entity_type:
        return None

    action = _determine_action(tool_input, short_name)
    if not action or action not in MUTATING_ACTIONS:
        return None

    data = _parse_json_result(tool_result)
    if not data:
        return None

    # Skip error responses
    if "error" in data and len(data) <= 2:
        return None

    # Map action to event_type
    event_type_map = {
        "create": "created",
        "update": "updated",
        "delete": "deleted",
        "complete": "updated",
        "cancel": "updated",
    }
    event_type = event_type_map.get(action, action)

    # Extract entity ID — use explicit None checks to handle falsy values like 0
    _id_candidates = [
        data.get("id"),
        data.get(f"{entity_type}_id"),
        data.get("todo_id"),
        data.get("reminder_id"),
        data.get("report_id"),
        data.get("skill_id"),
        data.get("memory_id"),
        data.get("collection_id"),
        data.get("deleted"),  # delete actions return {"deleted": "id"}
    ]
    entity_id = str(next((v for v in _id_candidates if v is not None), ""))

    entity_title = str(
        data.get("title")
        or data.get("name")
        or data.get("description")
        or data.get("message", "")
    )
    # Truncate long titles
    if len(entity_title) > 80:
        entity_title = entity_title[:77] + "..."

    entity_url = ENTITY_URLS.get(entity_type, "")

    # Build metadata (entity-type specific)
    metadata: dict[str, Any] = {}

    if entity_type == "todo":
        if data.get("priority"):
            metadata["priority"] = data["priority"]
        if data.get("status"):
            metadata["status"] = data["status"]
        if data.get("due_date"):
            metadata["due_date"] = data["due_date"]

    elif entity_type == "reminder":
        if data.get("channels"):
            metadata["channels"] = data["channels"]
        if data.get("scheduled_at"):
            metadata["scheduled_at"] = data["scheduled_at"]

    elif entity_type == "report":
        if data.get("s3_url"):
            metadata["s3_url"] = data["s3_url"]

    elif entity_type == "skill":
        if data.get("domain"):
            metadata["domain"] = data["domain"]

    elif entity_type == "collection":
        if data.get("slug"):
            metadata["slug"] = data["slug"]
        if data.get("item_count") is not None:
            metadata["item_count"] = data["item_count"]

    logger.info(
        "entity_event_extracted type=%s event=%s id=%s title=%s",
        entity_type, event_type, entity_id, entity_title[:50],
    )

    return {
        "entity_type": entity_type,
        "event_type": event_type,
        "entity_id": entity_id,
        "entity_title": entity_title,
        "entity_url": entity_url,
        "metadata": metadata,
    }
