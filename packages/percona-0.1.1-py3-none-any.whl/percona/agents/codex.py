import asyncio
import json
import logging
import time
from collections.abc import AsyncIterator
from pathlib import Path

from percona.agents.base import AgentAdapter, AgentResult
from percona.agents.tool_result_analyzer import analyze_tool_result
from .domain_events import (
    AgentCompleted,
    AgentError,
    AgentStarted,
    DomainEvent,
    TextDelta,
    ThinkingDelta,
    ToolInvocationCompleted,
    ToolInvocationStarted,
)

logger = logging.getLogger(__name__)


class CodexAdapter(AgentAdapter):
    agent_type = "codex"


    def build_command(
        self,
        workspace_path: str,
        system_prompt: str | None,
        prompt: str,
        mcp_config_path: str | None,
        timeout_seconds: int,
        resume_session_id: str | None = None,
        is_chat: bool = False,
        agent_settings: dict | None = None,
    ) -> list[str]:
        # Base flags that must come before any subcommand
        base_flags = [
            "codex", "exec",
            "--profile", "full_access",
            "--json",
            "--sandbox", "danger-full-access",
            "--dangerously-bypass-approvals-and-sandbox",
            "--skip-git-repo-check",
            "-c", 'approval_policy="never"',
        ]

        cfg = agent_settings or {}
        model = cfg.get("model")
        reasoning_effort = cfg.get("effort")

        if workspace_path:
            base_flags.extend(["--cd", workspace_path])

        if not resume_session_id:
            if model:
                base_flags.extend(["-c", f'model="{model}"'])
            if reasoning_effort:
                base_flags.extend(["-c", f'model_reasoning_effort="{reasoning_effort}"'])

        if resume_session_id:
            # Flags must come before the "resume" subcommand.
            cmd = base_flags + ["resume", resume_session_id]
        else:
            cmd = base_flags

        # Inject system prompt via experimental_instructions_file if file exists
        if workspace_path and system_prompt:
            instructions_path = Path(workspace_path) / "system_prompt.md"
            if instructions_path.exists():
                cmd.extend(["-c", f'experimental_instructions_file="{instructions_path}"'])

        # Inject per-session MCP configuration via -c flags
        if workspace_path:
            codex_config = Path(workspace_path) / ".codex" / "config.toml"
            if codex_config.exists():
                cmd.extend(self._mcp_flags_from_codex_config(codex_config))

        cmd.append(prompt)
        return cmd

    @staticmethod
    def _mcp_flags_from_codex_config(config_path: Path) -> list[str]:
        """Read workspace .codex/config.toml and return -c flags for Option 2 isolation:

        - Disable globally-defined servers (from ~/.codex/config.toml) that are NOT
          assigned to this session, so they don't start unnecessarily.
        - Inject per-session env vars for servers that ARE in this session.

        The workspace .codex/config.toml is written by WorkspaceService.write_mcp_config()
        and contains only the servers assigned to this session (with env vars).
        """
        try:
            import tomllib
        except ImportError:
            import tomli as tomllib  # type: ignore[no-redef]

        # Always disable global MCP servers unless explicitly included for this session.
        # If the per-session config file is empty/invalid (common when a task has
        # no MCP servers attached), we should still disable all globals to avoid
        # leaking default servers into the run.
        session_servers: dict = {}
        try:
            data = tomllib.loads(config_path.read_text())
            session_servers = data.get("mcp_servers", {}) or {}
        except Exception:
            # Leave session_servers empty; we'll still emit disable flags below.
            session_servers = {}

        flags: list[str] = []

        for name, cfg in session_servers.items():
            # Inject URL for HTTP MCP servers
            if url := cfg.get("url"):
                flags += ["-c", f'mcp_servers.{name}.url="{url}"']
            # Inject env vars
            for k, v in cfg.get("env", {}).items():
                flags += ["-c", f'mcp_servers.{name}.env.{k}="{v}"']

        return flags

    async def stream_output(self, process: asyncio.subprocess.Process) -> AsyncIterator[DomainEvent]:
        """Parse Codex CLI's exec --json output format (JSONL)."""
        seq = 0

        async for raw in process.stdout:
            line = raw.decode("utf-8", errors="replace").strip()
            if not line:
                continue

            logger.debug("codex_raw pid=%s line=%s", process.pid, line)

            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue

            event_type = event.get("type", "")
            item = event.get("item", {})
            item_type = item.get("type", "")
            item_id = item.get("id", "")
            seq += 1

            if event_type == "thread.started":
                yield AgentStarted(
                    sequence=seq,
                    agent_type=self.agent_type,
                    session_id=event.get("thread_id", ""),
                )

            elif event_type == "item.started":
                if item_type == "command_execution":
                    yield ToolInvocationStarted(
                        sequence=seq,
                        tool_name="shell",
                        tool_use_id=item_id,
                        input={"command": item.get("command", "")},
                    )
                elif item_type == "mcp_tool_call":
                    server = item.get("server", "")
                    tool = item.get("tool", "")
                    tool_name = f"mcp__{server}__{tool}" if server else tool
                    yield ToolInvocationStarted(
                        sequence=seq,
                        tool_name=tool_name,
                        tool_use_id=item_id,
                        tool_server=server or None,
                        input=item.get("arguments", {}),
                    )

            elif event_type == "item.completed":
                if item_type == "command_execution":
                    exit_code = item.get("exit_code")
                    output = item.get("aggregated_output", "")
                    yield ToolInvocationCompleted(
                        sequence=seq,
                        tool_name="shell",
                        tool_use_id=item_id,
                        result=output,
                        status="error" if exit_code and exit_code != 0 else "success",
                        is_error=bool(exit_code and exit_code != 0),
                    )

                elif item_type == "mcp_tool_call":
                    server = item.get("server", "")
                    tool = item.get("tool", "")
                    tool_name = f"mcp__{server}__{tool}" if server else tool
                    result = item.get("result") or {}
                    content_parts = result.get("content", [])
                    output = "\n".join(p.get("text", "") for p in content_parts if p.get("type") == "text")
                    item_status = item.get("status", "completed")
                    is_error = item_status == "failed"
                    if is_error and not output:
                        output = item.get("error") or result.get("error") or "Tool call failed with no error details"
                        if not isinstance(output, str):
                            output = str(output)

                    # Check if the tool result indicates a failure even if status is "completed"
                    result_indicates_failure, failure_reason = analyze_tool_result(output, tool_name)
                    if result_indicates_failure:
                        is_error = True
                        # Prepend error details to the result
                        if failure_reason:
                            output = f"[ERROR] {failure_reason}\n\nOriginal response:\n{output}"

                    yield ToolInvocationCompleted(
                        sequence=seq,
                        tool_name=tool_name,
                        tool_use_id=item_id,
                        result=output,
                        status="error" if is_error else "success",
                        is_error=is_error,
                    )

                elif item_type == "agent_message":
                    text = item.get("text", "")
                    if text:
                        yield TextDelta(sequence=seq, text=text)

                elif item_type == "reasoning":
                    text = item.get("text", "")
                    if text:
                        yield ThinkingDelta(sequence=seq, thinking=text)

            elif event_type == "turn.completed":
                usage = event.get("usage", {})
                cum_inp = usage.get("input_tokens", 0) or 0
                cum_out = usage.get("output_tokens", 0) or 0
                cache_read = usage.get("cached_input_tokens", 0) or 0
                context_window = 200_000  # Codex context window
                remaining_pct = round(
                    max(0.0, (context_window - cum_inp) / context_window * 100), 2
                ) if cum_inp and context_window > 0 else 100.0

                yield AgentCompleted(
                    sequence=seq,
                    usage={
                        "input_tokens": cum_inp,
                        "output_tokens": cum_out,
                        "cache_read_tokens": cache_read,
                        "context_window": context_window,
                        "tokens_remaining_pct": remaining_pct,
                    }
                )

    def extract_result(self, events: list[DomainEvent], return_code: int) -> AgentResult:
        success = return_code == 0
        summary = ""
        input_tokens = 0
        output_tokens = 0
        cache_read_tokens = 0
        agent_native_session_id = None
        error_message = ""

        for event in events:
            if isinstance(event, AgentStarted):
                agent_native_session_id = event.session_id
            elif isinstance(event, AgentCompleted):
                u = event.usage
                input_tokens += u.get("input_tokens", 0)
                output_tokens += u.get("output_tokens", 0)
                cache_read_tokens += u.get("cache_read_tokens", 0)
            elif isinstance(event, TextDelta):
                summary = event.text
            elif isinstance(event, AgentError):
                error_message = event.message

        total_input = input_tokens + cache_read_tokens
        return AgentResult(
            success=success,
            summary=summary[:2000],
            input_tokens=total_input,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read_tokens,
            total_tokens=total_input + output_tokens,
            cost_usd=0.0,  # Codex doesn't report cost
            error_message=error_message if not success else None,
            agent_native_session_id=agent_native_session_id,
        )
