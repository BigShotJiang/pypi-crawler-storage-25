from dataclasses import dataclass, field
from typing import Any, Optional

@dataclass
class DomainEvent:
    """Base class for all agent domain events."""
    sequence: int = 0

@dataclass
class AgentStarted(DomainEvent):
    agent_type: str = ""
    session_id: str = ""

@dataclass
class TextDelta(DomainEvent):
    text: str = ""

@dataclass
class ThinkingDelta(DomainEvent):
    thinking: str = ""

@dataclass
class ToolInvocationStarted(DomainEvent):
    tool_name: str = ""
    tool_use_id: str = ""
    tool_server: Optional[str] = None
    input: dict = field(default_factory=dict)

@dataclass
class ToolInvocationCompleted(DomainEvent):
    tool_name: str = ""
    tool_use_id: str = ""
    result: Any = None
    status: str = "success"
    is_error: bool = False
    duration_ms: Optional[int] = None

@dataclass
class AgentCompleted(DomainEvent):
    usage: dict = field(default_factory=dict)
    success: bool = True

@dataclass
class AgentError(DomainEvent):
    message: str = ""
    error_type: str = "GeneralError"


@dataclass
class EntityEvent(DomainEvent):
    """An entity was created/updated/deleted by a tool invocation."""
    entity_type: str = ""       # "todo", "report", "collection", etc.
    event_type: str = ""        # "created", "updated", "deleted"
    entity_id: str = ""
    entity_title: str = ""
    entity_url: str = ""        # frontend path, e.g. "/collections"
    metadata: dict = field(default_factory=dict)


@dataclass
class UserQuestionRequested(DomainEvent):
    """The agent is requesting interactive input from the user."""
    question_id: str = ""
    question: str = ""
    options: list = field(default_factory=list)
    header: str = "Quick Question"
    multi_select: bool = False
    allow_custom: bool = False
    conversation_id: str = ""


@dataclass
class AgentPaused(DomainEvent):
    """Agent execution is paused waiting for user input."""
    reason: str = ""
    question_id: str = ""
