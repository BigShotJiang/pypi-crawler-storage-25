import asyncio
import json
import logging
from collections.abc import AsyncIterator
from pathlib import Path

from percona.agents.base import AgentAdapter, AgentResult
from percona.agents.tool_result_analyzer import analyze_tool_result
from .domain_events import (
    AgentCompleted,
    AgentError,
    AgentStarted,
    DomainEvent,
    TextDelta,
    ThinkingDelta,
    ToolInvocationCompleted,
    ToolInvocationStarted,
)

logger = logging.getLogger(__name__)


class GeminiAdapter(AgentAdapter):
    agent_type = "gemini"

    def build_command(
        self,
        workspace_path: str,
        system_prompt: str | None,
        prompt: str,
        mcp_config_path: str | None,
        timeout_seconds: int,
        resume_session_id: str | None = None,
        is_chat: bool = False,
        agent_settings: dict | None = None,
    ) -> list[str]:
        cfg = agent_settings or {}
        model = cfg.get("model") or "gemini-2.5-flash-lite"

        cmd = [
            "gemini",
            "-p", prompt,
            "--model", model,
            "--output-format", "stream-json",
            "--yolo",
        ]

        if resume_session_id:
            cmd.extend(["--resume", resume_session_id])

        return cmd

    def get_extra_env(self, workspace_path: str) -> dict:
        """Set GEMINI_SYSTEM_MD to the system prompt file if it exists."""
        path = Path(workspace_path) / "system_prompt.md"
        if path.exists():
            return {"GEMINI_SYSTEM_MD": str(path)}
        return {}

    async def stream_output(self, process: asyncio.subprocess.Process) -> AsyncIterator[DomainEvent]:
        """Parse Gemini CLI's stream-json output format (JSONL)."""
        seq = 0

        while True:
            try:
                raw = await process.stdout.readline()
            except ValueError:
                # asyncio raises ValueError when a line exceeds the StreamReader
                # buffer limit (set to 10 MB in agent_executor). Skip the oversized
                # line and keep streaming rather than crashing the session.
                logger.warning("gemini_line_too_large pid=%s skipping", process.pid)
                continue
            if not raw:
                break
            line = raw.decode("utf-8", errors="replace").strip()
            if not line:
                continue

            logger.debug("gemini_raw pid=%s line=%s", process.pid, line)

            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue

            event_type = event.get("type", "")
            seq += 1

            if event_type == "init":
                yield AgentStarted(
                    sequence=seq,
                    agent_type=self.agent_type,
                    session_id=event.get("session_id", ""),
                )

            elif event_type == "message":
                role = event.get("role", "")
                content = event.get("content", "")
                is_delta = event.get("delta", False)

                if role == "assistant":
                    if is_delta:
                        yield TextDelta(sequence=seq, text=content)
                    else:
                        if content:
                            yield TextDelta(sequence=seq, text=content)

            elif event_type == "tool_use":
                tool_name = event.get("tool_name", "unknown")
                tool_server = None
                if "__" in tool_name:
                    parts = tool_name.split("__", 1)
                    if len(parts) == 2:
                        tool_server = parts[0]

                yield ToolInvocationStarted(
                    sequence=seq,
                    tool_name=tool_name,
                    tool_use_id=event.get("tool_id", ""),
                    tool_server=tool_server,
                    input=event.get("parameters", {}),
                )

            elif event_type == "tool_result":
                tool_name = event.get("tool_name", "unknown")
                tool_output = event.get("output", "")
                is_error = event.get("status") == "error"

                # Check if the tool result indicates a failure in the output JSON
                result_indicates_failure, failure_reason = analyze_tool_result(tool_output, tool_name)
                if result_indicates_failure:
                    is_error = True
                    # Prepend error details to the result
                    if failure_reason:
                        tool_output = f"[ERROR] {failure_reason}\n\nOriginal response:\n{tool_output}"

                yield ToolInvocationCompleted(
                    sequence=seq,
                    tool_name=tool_name,
                    tool_use_id=event.get("tool_id", ""),
                    result=tool_output,
                    status="error" if is_error else "success",
                    is_error=is_error,
                )

            elif event_type == "result":
                stats = event.get("stats", {})
                if event.get("status") == "error":
                    error_info = event.get("error", {})
                    yield AgentError(
                        sequence=seq,
                        message=error_info.get("message", "Unknown Gemini error"),
                        error_type=error_info.get("type", "GeminiError"),
                    )
                else:
                    inp = stats.get("input_tokens", 0)
                    out = stats.get("output_tokens", 0)
                    cached = stats.get("cached", 0)
                    context_window = 1_000_000  # Gemini context window
                    remaining_pct = round(
                        max(0.0, (context_window - inp) / context_window * 100), 2
                    ) if inp and context_window > 0 else 100.0

                    yield AgentCompleted(
                        sequence=seq,
                        success=True,
                        usage={
                            "input_tokens": inp,
                            "output_tokens": out,
                            "cached_tokens": cached,
                            "cost_usd": 0.0,
                            "context_window": context_window,
                            "tokens_remaining_pct": remaining_pct,
                        }
                    )

    def extract_result(self, events: list[DomainEvent], return_code: int) -> AgentResult:
        success = return_code == 0
        summary = ""
        input_tokens = 0
        output_tokens = 0
        agent_native_session_id = None

        for event in events:
            if isinstance(event, AgentStarted):
                agent_native_session_id = event.session_id
            elif isinstance(event, AgentCompleted):
                success = event.success
                input_tokens = event.usage.get("input_tokens", 0)
                output_tokens = event.usage.get("output_tokens", 0)
            elif isinstance(event, TextDelta):
                summary += event.text

        return AgentResult(
            success=success,
            summary=summary[:2000],
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
            cost_usd=0.0,
            agent_native_session_id=agent_native_session_id,
        )
