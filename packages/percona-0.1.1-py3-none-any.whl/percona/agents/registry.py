import logging

from percona.agents.base import AgentAdapter
from percona.agents.claude_code import ClaudeCodeAdapter
from percona.agents.codex import CodexAdapter
from percona.agents.gemini import GeminiAdapter

logger = logging.getLogger(__name__)

_ADAPTERS: dict[str, type[AgentAdapter]] = {
    "claude-code": ClaudeCodeAdapter,
    "codex": CodexAdapter,
    "gemini": GeminiAdapter,
}


def get_adapter(agent_type: str) -> AgentAdapter:
    logger.debug("get_adapter agent_type=%s", agent_type)
    adapter_cls = _ADAPTERS.get(agent_type)
    if not adapter_cls:
        logger.error("unknown_agent_type agent_type=%s available=%s", agent_type, list(_ADAPTERS.keys()))
        raise ValueError(f"Unknown agent type: {agent_type}. Available: {list(_ADAPTERS.keys())}")
    adapter = adapter_cls()
    logger.debug("get_adapter_selected adapter=%s", adapter.__class__.__name__)
    return adapter
