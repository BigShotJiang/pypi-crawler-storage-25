"""Analyze tool results to detect failures based on response structure."""

import json
import logging
from typing import Any, Optional, Tuple

logger = logging.getLogger(__name__)


def analyze_tool_result(
    result: Any,
    tool_name: str,
) -> Tuple[bool, Optional[str]]:
    """
    Analyze a tool result to detect if the operation actually failed.

    Checks for:
    1. JSON responses with a "status" field indicating failure
    2. Nested "error" or "error_message" fields in JSON
    3. Common failure patterns in tool responses

    Args:
        result: The tool result (usually a string, but can be any type)
        tool_name: The tool name (for context in logging)

    Returns:
        Tuple of (is_failed: bool, error_message: Optional[str])
        - is_failed: True if the tool operation failed
        - error_message: Human-readable error message, if any
    """

    if not result:
        # Empty result might indicate failure, but not necessarily
        return False, None

    result_str = str(result).strip() if not isinstance(result, str) else result.strip()

    # Check for <tool_use_error> markers (agent framework error)
    if "<tool_use_error>" in result_str:
        error_match = result_str.split("<tool_use_error>")[1].split("</tool_use_error>")[0]
        return True, f"Tool execution error: {error_match}"

    # Try to parse as JSON
    try:
        data = json.loads(result_str)

        # Check for explicit status field indicating failure
        if isinstance(data, dict):
            status = data.get("status")
            if status in ["failed", "error", "failure"]:
                error_msg = data.get("error") or data.get("error_message") or data.get("message")
                return True, f"Tool returned failure status: {error_msg or status}"

            # Check for nested error field (but not error_type which might be informational)
            if "error" in data and data.get("error"):
                error_info = data.get("error")
                # Skip if it's just error_type without actual error message
                if not (isinstance(error_info, str) and error_info.startswith("No such")):
                    return True, f"Tool error: {error_info}"

            # Check for "result" field with nested failure status
            if "result" in data and isinstance(data["result"], dict):
                nested_result = data["result"]
                if nested_result.get("status") in ["failed", "error", "failure"]:
                    error_msg = (nested_result.get("error") or
                               nested_result.get("error_message") or
                               nested_result.get("message"))
                    return True, f"Nested failure: {error_msg or nested_result.get('status')}"
    except (json.JSONDecodeError, ValueError, AttributeError):
        # Not JSON, skip JSON-based checks
        pass

    # Check for "No such tool available" pattern
    if "No such tool available" in result_str or "Tool not found" in result_str:
        return True, result_str

    return False, None


def extract_error_details(result: Any) -> Optional[str]:
    """Extract detailed error information from tool result."""
    result_str = str(result).strip() if not isinstance(result, str) else result.strip()

    try:
        data = json.loads(result_str)
        if isinstance(data, dict):
            # Try different error field names
            for field in ["error", "error_message", "message", "details", "reason"]:
                if field in data and data[field]:
                    return str(data[field])

            # Try nested result
            if "result" in data and isinstance(data["result"], dict):
                result_data = data["result"]
                for field in ["error", "error_message", "message"]:
                    if field in result_data and result_data[field]:
                        return str(result_data[field])
    except (json.JSONDecodeError, ValueError):
        pass

    return None
