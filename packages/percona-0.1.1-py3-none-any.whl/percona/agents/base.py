import asyncio
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from enum import Enum


from .domain_events import DomainEvent

@dataclass
class AgentResult:
    success: bool
    summary: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float = 0.0
    error_message: str | None = None
    raw_output_path: str | None = None
    agent_native_session_id: str | None = None  # for chat resume


class AgentAdapter(ABC):
    agent_type: str

    @abstractmethod
    def build_command(
        self,
        workspace_path: str,
        system_prompt: str | None,
        prompt: str,
        mcp_config_path: str | None,
        timeout_seconds: int,
        resume_session_id: str | None = None,
        is_chat: bool = False,
        agent_settings: dict | None = None,
    ) -> list[str]:
        """Build the CLI command to execute the agent."""

    def get_extra_env(self, workspace_path: str) -> dict:
        """Return extra environment variables to merge into the agent process env."""
        return {}

    @abstractmethod
    async def stream_output(self, process: asyncio.subprocess.Process) -> AsyncIterator[DomainEvent]:
        """Stream and parse output from the running process."""

    @abstractmethod
    def extract_result(self, events: list[DomainEvent], return_code: int) -> AgentResult:
        """Extract final result from collected events."""
