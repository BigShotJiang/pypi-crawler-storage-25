"""SQLAlchemy repository for Task aggregate.

Encapsulates all persistence operations for tasks and their junction-table
relations (MCP servers, git repos, notification channels, memory files).
"""
from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from datetime import datetime

from sqlalchemy import delete, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from percona.context import get_user_id
from percona.models import Task, TaskMemoryFile, TaskMcpServer, TaskNotificationChannel
from percona.services.mcp_service import get_default_mcp_ids


class TaskRepository(ABC):
    """Abstract interface for task persistence operations."""

    @abstractmethod
    async def get_by_id(self, task_id: uuid.UUID) -> Task | None: ...

    @abstractmethod
    async def get_with_relations(self, task_id: uuid.UUID) -> Task | None: ...

    @abstractmethod
    async def list(
        self,
        enabled: bool | None = None,
        agent_type: str | None = None,
        search: str | None = None,
        sort: str = "created_desc",
        created_after: datetime | None = None,
        created_before: datetime | None = None,
        limit: int = 25,
        offset: int = 0,
    ) -> list[Task]: ...

    @abstractmethod
    async def count(
        self,
        enabled: bool | None = None,
        agent_type: str | None = None,
        search: str | None = None,
        created_after: datetime | None = None,
        created_before: datetime | None = None,
    ) -> int: ...

    @abstractmethod
    async def get_stats(self) -> dict: ...

    @abstractmethod
    async def add(self, task: Task) -> None: ...

    @abstractmethod
    async def delete(self, task: Task) -> None: ...

    @abstractmethod
    async def flush(self) -> None: ...

    @abstractmethod
    async def sync_relations(
        self,
        task_id: uuid.UUID,
        mcp_ids: list[uuid.UUID] | None,
        git_ids: list[uuid.UUID] | None,
        notif_ids: list[uuid.UUID] | None,
        memory_file_ids: list[uuid.UUID] | None,
    ) -> None: ...

    @abstractmethod
    async def get_by_ids(self, task_ids: list[uuid.UUID]) -> list[Task]: ...

    @abstractmethod
    async def get_default_mcp_ids(self) -> list[uuid.UUID]: ...

    @abstractmethod
    async def create_pending_session(
        self,
        session_id: uuid.UUID,
        task: Task,
        trigger_source: str,
        idempotency_key: str | None,
    ) -> None: ...


class SqlaTaskRepository(TaskRepository):
    """Concrete SQLAlchemy implementation of TaskRepository."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def get_by_id(self, task_id: uuid.UUID) -> Task | None:
        user_id = get_user_id()
        stmt = select(Task).where(Task.id == task_id)
        if user_id is not None:
            stmt = stmt.where(Task.user_id == user_id)
        result = await self._db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_with_relations(self, task_id: uuid.UUID) -> Task | None:
        user_id = get_user_id()
        stmt = (
            select(Task)
            .where(Task.id == task_id)
            .options(
                selectinload(Task.mcp_servers),
                selectinload(Task.notification_channels),
                selectinload(Task.memory_files),
            )
        )
        if user_id is not None:
            stmt = stmt.where(Task.user_id == user_id)
        result = await self._db.execute(stmt)
        return result.scalar_one_or_none()

    async def list(
        self,
        enabled: bool | None = None,
        agent_type: str | None = None,
        search: str | None = None,
        sort: str = "created_desc",
        created_after: datetime | None = None,
        created_before: datetime | None = None,
        limit: int = 25,
        offset: int = 0,
    ) -> list[Task]:
        # Mandatory project context check - don't allow cross-project queries
        user_id = get_user_id()
        if not user_id:
            return []

        order = Task.created_at.asc() if sort == "created_asc" else Task.created_at.desc()
        stmt = select(Task).order_by(order).limit(limit).offset(offset)
        stmt = stmt.where(Task.user_id == user_id)
        if enabled is not None:
            stmt = stmt.where(Task.enabled == enabled)
        if agent_type:
            stmt = stmt.where(Task.agent_type == agent_type)
        if search:
            stmt = stmt.where(
                or_(Task.name.ilike(f"%{search}%"), Task.description.ilike(f"%{search}%"))
            )
        if created_after:
            stmt = stmt.where(Task.created_at >= created_after)
        if created_before:
            stmt = stmt.where(Task.created_at <= created_before)
        result = await self._db.execute(stmt)
        return list(result.scalars().all())

    async def count(
        self,
        enabled: bool | None = None,
        agent_type: str | None = None,
        search: str | None = None,
        created_after: datetime | None = None,
        created_before: datetime | None = None,
    ) -> int:
        # Mandatory project context check - don't allow cross-project queries
        user_id = get_user_id()
        if not user_id:
            return 0

        stmt = select(func.count()).select_from(Task)
        stmt = stmt.where(Task.user_id == user_id)
        if enabled is not None:
            stmt = stmt.where(Task.enabled == enabled)
        if agent_type:
            stmt = stmt.where(Task.agent_type == agent_type)
        if search:
            stmt = stmt.where(
                or_(Task.name.ilike(f"%{search}%"), Task.description.ilike(f"%{search}%"))
            )
        if created_after:
            stmt = stmt.where(Task.created_at >= created_after)
        if created_before:
            stmt = stmt.where(Task.created_at <= created_before)
        return await self._db.scalar(stmt) or 0

    async def get_stats(self) -> dict:
        user_id = get_user_id()
        stats_stmt = select(
            func.count().label("total"),
            func.count().filter(Task.enabled == True).label("enabled"),
            func.count().filter(Task.enabled == False).label("disabled"),
            func.count().filter(Task.cron_schedule.isnot(None)).label("scheduled"),
        )
        by_agent_stmt = select(Task.agent_type, func.count().label("cnt")).group_by(Task.agent_type)
        if user_id is not None:
            stats_stmt = stats_stmt.where(Task.user_id == user_id)
            by_agent_stmt = by_agent_stmt.where(Task.user_id == user_id)
        row = (await self._db.execute(stats_stmt)).one()
        by_agent_rows = (await self._db.execute(by_agent_stmt)).fetchall()
        return {
            "total": row.total,
            "enabled": row.enabled,
            "disabled": row.disabled,
            "scheduled": row.scheduled,
            "by_agent": {r.agent_type.value: r.cnt for r in by_agent_rows},
        }

    async def add(self, task: Task) -> None:
        self._db.add(task)

    async def delete(self, task: Task) -> None:
        await self._db.delete(task)

    async def flush(self) -> None:
        await self._db.flush()

    async def sync_relations(
        self,
        task_id: uuid.UUID,
        mcp_ids: list[uuid.UUID] | None,
        git_ids: list[uuid.UUID] | None,
        notif_ids: list[uuid.UUID] | None,
        memory_file_ids: list[uuid.UUID] | None,
    ) -> None:
        if mcp_ids is not None:
            await self._db.execute(delete(TaskMcpServer).where(TaskMcpServer.task_id == task_id))
            for mid in mcp_ids:
                self._db.add(TaskMcpServer(task_id=task_id, mcp_server_id=mid))

        if notif_ids is not None:
            await self._db.execute(
                delete(TaskNotificationChannel).where(TaskNotificationChannel.task_id == task_id)
            )
            for nid in notif_ids:
                self._db.add(TaskNotificationChannel(task_id=task_id, notification_channel_id=nid))

        if memory_file_ids is not None:
            await self._db.execute(delete(TaskMemoryFile).where(TaskMemoryFile.task_id == task_id))
            for mfid in memory_file_ids:
                self._db.add(TaskMemoryFile(task_id=task_id, memory_file_id=mfid))

    async def get_by_ids(self, task_ids: list[uuid.UUID]) -> list[Task]:
        result = await self._db.execute(select(Task).where(Task.id.in_(task_ids)))
        return list(result.scalars().all())

    async def get_default_mcp_ids(self) -> list[uuid.UUID]:
        return await get_default_mcp_ids(self._db)

    async def create_pending_session(
        self,
        session_id: uuid.UUID,
        task: Task,
        trigger_source: str,
        idempotency_key: str | None,
    ) -> None:
        from percona.models import Session, SessionStatus, TriggerSource
        session = Session(
            id=session_id,
            user_id=task.user_id,
            task_id=task.id,
            status=SessionStatus.PENDING,
            agent_type=task.agent_type,
            prompt_snapshot=task.prompt,
            trigger_source=TriggerSource(trigger_source),
            idempotency_key=idempotency_key,
        )
        self._db.add(session)
