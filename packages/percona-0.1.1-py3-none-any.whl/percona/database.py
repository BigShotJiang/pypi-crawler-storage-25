from collections.abc import AsyncGenerator
import logging
import os

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from percona.config import settings

logger = logging.getLogger(__name__)

# Celery workers run each task in a fresh asyncio event loop via asyncio.run().
# A pooled async engine holds asyncpg connections tied to the loop that created them,
# causing "Future attached to a different loop" errors across tasks. NullPool disables
# connection pooling so every DB operation opens and closes its own connection.
_engine_kwargs = {}
if os.environ.get("PERCONA_WORKER"):
    from sqlalchemy.pool import NullPool
    _engine_kwargs["poolclass"] = NullPool
    logger.debug("database_engine_nullpool enabled for worker process")

engine = create_async_engine(settings.database_url, echo=settings.database_echo, **_engine_kwargs)
async_session_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_factory() as session:
        try:
            logger.debug("db_session_opened")
            yield session
            await session.commit()
            logger.debug("db_session_committed")
        except Exception:
            logger.exception("db_session_failed_rolling_back")
            await session.rollback()
            raise
