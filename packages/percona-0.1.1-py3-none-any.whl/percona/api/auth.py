import json
import logging
import secrets
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode
from uuid import UUID

import httpx
import redis.asyncio as aioredis
from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import RedirectResponse
from fastapi.security import OAuth2PasswordRequestForm
from jose import JWTError, jwt
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_current_user
from percona.config import settings
from percona.database import get_db
from percona.models.users import AccountStatus, User
from percona.services.auth_service import (
    authenticate_user,
    create_access_token,
    create_refresh_token,
    create_user,
    decode_token,
    get_user_by_email,
    hash_password,
)
from percona.services.oauth_service import (
    GOOGLE_AUTH_URL,
    GOOGLE_TOKEN_URL,
    _decode_id_token_claims,
    generate_pkce,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["auth"])

# Redis pool for Google Sign-In state (ephemeral, no DB needed)
_redis_pool: aioredis.Redis | None = None
GOOGLE_SIGNIN_STATE_PREFIX = "google_signin_state:"
GOOGLE_SIGNIN_STATE_TTL = 600  # 10 minutes

# OpenID Connect scopes — sign-in only, no service access
GOOGLE_SIGNIN_SCOPES = [
    "openid",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
]


def _get_redis() -> aioredis.Redis:
    global _redis_pool
    if _redis_pool is None:
        _redis_pool = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _redis_pool


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: dict


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    full_name: str | None = None


class RefreshRequest(BaseModel):
    refresh_token: str


class GoogleAuthInitResponse(BaseModel):
    authorization_url: str
    state: str


def _user_dict(user: User) -> dict:
    return {
        "id": str(user.id),
        "email": user.email,
        "full_name": user.full_name,
        "role": user.role,
        "account_status": user.account_status,
        "auth_provider": user.auth_provider,
        "avatar_url": user.avatar_url,
    }


def _google_signin_redirect_uri() -> str:
    if settings.google_signin_redirect_uri:
        return settings.google_signin_redirect_uri
    base = settings.oauth_callback_base_url or settings.api_base_url
    return f"{base}/api/auth/google/callback"


# ─── Standard Auth ────────────────────────────────────────────────────────────


@router.post("/login", response_model=TokenResponse)
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: AsyncSession = Depends(get_db)):
    user = await authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    user.last_login_at = datetime.now(timezone.utc)
    await db.flush()

    token_data = {"sub": str(user.id), "email": user.email, "role": user.role, "account_status": user.account_status}
    logger.info("user_login email=%s", user.email)
    return TokenResponse(
        access_token=create_access_token(token_data, settings.jwt_secret_key),
        refresh_token=create_refresh_token(token_data, settings.jwt_secret_key),
        user=_user_dict(user),
    )


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, db: AsyncSession = Depends(get_db)):
    existing = await get_user_by_email(db, payload.email)
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email already registered")

    user = await create_user(db, payload.email, payload.password, payload.full_name)
    await db.flush()

    # Seed templates for new user
    from percona.seed import seed_mcp_servers_for_project, seed_task_templates_for_project, seed_collection_templates_for_user
    await seed_mcp_servers_for_project(db, user.id)
    await seed_task_templates_for_project(db, user.id)
    await seed_collection_templates_for_user(db, user.id)

    token_data = {"sub": str(user.id), "email": user.email, "role": user.role, "account_status": user.account_status}
    logger.info("user_registered email=%s", user.email)
    return TokenResponse(
        access_token=create_access_token(token_data, settings.jwt_secret_key),
        refresh_token=create_refresh_token(token_data, settings.jwt_secret_key),
        user=_user_dict(user),
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(payload: RefreshRequest, db: AsyncSession = Depends(get_db)):
    try:
        data = decode_token(payload.refresh_token, settings.jwt_secret_key)
        if data.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")
        user_id = data.get("sub")
        result = await db.execute(select(User).where(User.id == UUID(user_id), User.is_active == True))
        user = result.scalar_one_or_none()
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        token_data = {"sub": str(user.id), "email": user.email, "role": user.role, "account_status": user.account_status}
        return TokenResponse(
            access_token=create_access_token(token_data, settings.jwt_secret_key),
            refresh_token=create_refresh_token(token_data, settings.jwt_secret_key),
            user=_user_dict(user),
        )
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")


@router.get("/me")
async def get_me(current_user: User = Depends(get_current_user)):
    return {
        "id": str(current_user.id),
        "email": current_user.email,
        "full_name": current_user.full_name,
        "role": current_user.role,
        "account_status": current_user.account_status,
        "auth_provider": current_user.auth_provider,
        "avatar_url": current_user.avatar_url,
        "is_active": current_user.is_active,
        "last_login_at": current_user.last_login_at.isoformat() if current_user.last_login_at else None,
    }


@router.post("/logout")
async def logout(current_user: User = Depends(get_current_user)):
    return {"message": "Logged out successfully"}


# ─── Google Sign-In ───────────────────────────────────────────────────────────
# Reuses PKCE, token exchange, and ID token parsing from oauth_service.py
# (same Google client credentials as the integrations flow).
# State is stored in Redis (not OAuthState DB table) because sign-in has
# no user_id yet — it's pre-authentication.


@router.post("/google", response_model=GoogleAuthInitResponse)
async def initiate_google_signin():
    """Initiate Google Sign-In flow with PKCE. Returns authorization URL."""
    if not settings.google_oauth_client_id:
        raise HTTPException(status_code=503, detail="Google Sign-In is not configured")

    state = secrets.token_urlsafe(32)
    verifier, challenge = generate_pkce()
    redirect_uri = _google_signin_redirect_uri()

    params = {
        "client_id": settings.google_oauth_client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": " ".join(GOOGLE_SIGNIN_SCOPES),
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "access_type": "online",
        "prompt": "select_account",
    }
    authorization_url = f"{GOOGLE_AUTH_URL}?{urlencode(params)}"

    # Store state + code_verifier in Redis with TTL
    r = _get_redis()
    await r.setex(
        f"{GOOGLE_SIGNIN_STATE_PREFIX}{state}",
        GOOGLE_SIGNIN_STATE_TTL,
        json.dumps({"code_verifier": verifier}),
    )

    logger.info("google_signin_initiated")
    return GoogleAuthInitResponse(authorization_url=authorization_url, state=state)


@router.get("/google/callback")
async def google_signin_callback(
    code: str = Query(...),
    state: str = Query(...),
    db: AsyncSession = Depends(get_db),
):
    """Handle Google OAuth callback. Validates PKCE, creates/links user, redirects with tokens."""
    frontend_url = settings.frontend_url

    # Validate state from Redis
    r = _get_redis()
    state_json = await r.getdel(f"{GOOGLE_SIGNIN_STATE_PREFIX}{state}")
    if not state_json:
        logger.warning("google_signin_invalid_state state=%s", state[:8])
        return RedirectResponse(url=f"{frontend_url}/login?error=invalid_state", status_code=302)

    state_data = json.loads(state_json)
    code_verifier = state_data["code_verifier"]
    redirect_uri = _google_signin_redirect_uri()

    try:
        # Exchange code for tokens (reuses same Google client as integrations)
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                GOOGLE_TOKEN_URL,
                data={
                    "code": code,
                    "client_id": settings.google_oauth_client_id,
                    "client_secret": settings.google_oauth_client_secret,
                    "redirect_uri": redirect_uri,
                    "code_verifier": code_verifier,
                    "grant_type": "authorization_code",
                },
                timeout=15,
            )
            resp.raise_for_status()
            token_data = resp.json()

        # Extract user info from ID token (reuses oauth_service helper)
        claims = _decode_id_token_claims(token_data.get("id_token", ""))
        email = claims.get("email")
        if not email:
            raise ValueError("Could not extract email from Google ID token")

        google_id = claims.get("sub", "")
        name = claims.get("name", email.split("@")[0])
        picture = claims.get("picture")

        # Find or create user
        user, is_new = await _find_or_create_google_user(db, google_id, email, name, picture)

        user.last_login_at = datetime.now(timezone.utc)
        await db.commit()

        # Issue JWT tokens
        token_data = {"sub": str(user.id), "email": user.email, "role": user.role, "account_status": user.account_status}
        access_token = create_access_token(token_data, settings.jwt_secret_key)
        refresh_tok = create_refresh_token(token_data, settings.jwt_secret_key)

        logger.info("google_signin_success email=%s is_new=%s", user.email, is_new)

        # Redirect to frontend with tokens in URL fragment (not sent to server)
        return RedirectResponse(
            url=f"{frontend_url}/auth/callback#access_token={access_token}&refresh_token={refresh_tok}&is_new={str(is_new).lower()}",
            status_code=302,
        )

    except Exception as e:
        logger.error("google_signin_failed error=%s", str(e), exc_info=True)
        return RedirectResponse(
            url=f"{frontend_url}/login?error=auth_failed",
            status_code=302,
        )


async def _find_or_create_google_user(
    db: AsyncSession, google_id: str, email: str, name: str, picture: str | None,
) -> tuple[User, bool]:
    """Find existing user by google_id or email, or create a new pending user."""
    # 1. Find by google_id (already linked)
    result = await db.execute(select(User).where(User.google_id == google_id))
    user = result.scalar_one_or_none()
    if user:
        if picture and user.avatar_url != picture:
            user.avatar_url = picture
            await db.flush()
        logger.info("google_signin_existing google_id=%s user_id=%s", google_id, user.id)
        return user, False

    # 2. Find by email (auto-link)
    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()
    if user:
        user.google_id = google_id
        user.auth_provider = "google+local" if user.hashed_password else "google"
        if picture and not user.avatar_url:
            user.avatar_url = picture
        await db.flush()
        logger.info("google_signin_linked email=%s user_id=%s", email, user.id)
        return user, False

    # 3. Create new user (pending approval)
    username = email.split("@")[0]
    user = User(
        name=name or username,
        slug=username.lower().replace(" ", "-"),
        email=email,
        hashed_password="",
        full_name=name,
        role="user",
        is_active=True,
        account_status=AccountStatus.PENDING,
        auth_provider="google",
        google_id=google_id,
        avatar_url=picture,
    )
    db.add(user)
    await db.flush()
    await db.refresh(user)

    # Seed templates for new user
    from percona.seed import seed_mcp_servers_for_project, seed_task_templates_for_project, seed_collection_templates_for_user
    await seed_mcp_servers_for_project(db, user.id)
    await seed_task_templates_for_project(db, user.id)
    await seed_collection_templates_for_user(db, user.id)

    logger.info("google_signin_created email=%s user_id=%s", email, user.id)
    return user, True


# ─── Password Reset ──────────────────────────────────────────────────────────


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str


@router.post("/forgot-password")
async def forgot_password(payload: ForgotPasswordRequest, db: AsyncSession = Depends(get_db)):
    user = await get_user_by_email(db, payload.email)
    if not user:
        return {"message": "If the email exists, a reset link has been sent"}
    reset_data = {"sub": str(user.id), "email": user.email, "type": "reset"}
    reset_token = jwt.encode(
        {**reset_data, "exp": datetime.now(timezone.utc) + timedelta(hours=1)},
        settings.jwt_secret_key, algorithm="HS256",
    )
    reset_url = f"https://percona.msrashed.com/reset-password?token={reset_token}"
    logger.info("password_reset_requested email=%s reset_url=%s", user.email, reset_url)
    return {"message": "If the email exists, a reset link has been sent"}


@router.post("/reset-password")
async def reset_password(payload: ResetPasswordRequest, db: AsyncSession = Depends(get_db)):
    try:
        data = decode_token(payload.token, settings.jwt_secret_key)
        if data.get("type") != "reset":
            raise HTTPException(400, "Invalid reset token")
        user_id = data.get("sub")
        result = await db.execute(select(User).where(User.id == UUID(user_id)))
        user = result.scalar_one_or_none()
        if not user:
            raise HTTPException(400, "Invalid reset token")
        user.hashed_password = hash_password(payload.new_password)
        await db.flush()
        logger.info("password_reset_completed email=%s", user.email)
        return {"message": "Password reset successfully"}
    except JWTError:
        raise HTTPException(400, "Invalid or expired reset token")
