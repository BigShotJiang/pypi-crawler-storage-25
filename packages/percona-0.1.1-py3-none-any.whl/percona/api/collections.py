import logging
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_user_id_dep
from percona.database import get_db
from percona.schemas import PaginatedResponse
from percona.schemas.collections import (
    CollectionCreate,
    CollectionFieldCreate,
    CollectionFieldOut,
    CollectionFieldUpdate,
    CollectionItemCreate,
    CollectionItemOut,
    CollectionItemUpdate,
    CollectionOut,
    CollectionStatsOut,
    CollectionUpdate,
)
from percona.services import collection_service
from percona.services.collection_templates import get_available_templates, create_from_template

router = APIRouter(prefix="/collections", tags=["collections"])
logger = logging.getLogger(__name__)


# --- Templates ---

@router.get("/templates")
async def list_templates():
    return get_available_templates()


@router.post("/from-template/{template_slug}", response_model=CollectionOut)
async def create_from_template_endpoint(
    template_slug: str,
    response: Response,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    collection, created = await create_from_template(db, user_id, template_slug)
    if not collection:
        raise HTTPException(404, f"Template not found: {template_slug}")
    response.status_code = 201 if created else 200
    fields = await collection_service.list_fields(db, user_id, collection.id)
    out = CollectionOut.model_validate(collection)
    out.fields = [CollectionFieldOut.model_validate(f) for f in fields]
    return out


# --- Collection CRUD ---

@router.get("", response_model=PaginatedResponse[CollectionOut])
async def list_collections(
    status: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = Query(25, le=500),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    total = await collection_service.count_collections(db, user_id, status=status, search=search)
    items = await collection_service.list_collections(db, user_id, status=status, search=search, limit=limit, offset=offset)
    # Attach fields to each collection
    result = []
    for c in items:
        fields = await collection_service.list_fields(db, user_id, c.id)
        out = CollectionOut.model_validate(c)
        out.fields = [CollectionFieldOut.model_validate(f) for f in fields]
        result.append(out)
    return {"items": result, "total": total}


@router.get("/{collection_id}", response_model=CollectionOut)
async def get_collection(
    collection_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    collection = await collection_service.get_collection(db, user_id, collection_id)
    if not collection:
        raise HTTPException(404, "Collection not found")
    fields = await collection_service.list_fields(db, user_id, collection_id)
    out = CollectionOut.model_validate(collection)
    out.fields = [CollectionFieldOut.model_validate(f) for f in fields]
    return out


@router.post("", response_model=CollectionOut, status_code=201)
async def create_collection(
    data: CollectionCreate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    try:
        collection = await collection_service.create_collection(db, user_id, data)
        fields = await collection_service.list_fields(db, user_id, collection.id)
        out = CollectionOut.model_validate(collection)
        out.fields = [CollectionFieldOut.model_validate(f) for f in fields]
        return out
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.patch("/{collection_id}", response_model=CollectionOut)
async def update_collection(
    collection_id: uuid.UUID,
    data: CollectionUpdate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    collection = await collection_service.update_collection(db, user_id, collection_id, data)
    if not collection:
        raise HTTPException(404, "Collection not found")
    await db.flush()
    await db.refresh(collection)
    fields = await collection_service.list_fields(db, user_id, collection_id)
    out = CollectionOut.model_validate(collection)
    out.fields = [CollectionFieldOut.model_validate(f) for f in fields]
    return out


@router.delete("/{collection_id}", status_code=204)
async def delete_collection(
    collection_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    if not await collection_service.delete_collection(db, user_id, collection_id):
        raise HTTPException(404, "Collection not found")


# --- Stats ---

@router.get("/{collection_id}/stats", response_model=CollectionStatsOut)
async def get_collection_stats(
    collection_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    try:
        return await collection_service.get_collection_stats(db, user_id, collection_id)
    except KeyError:
        raise HTTPException(404, "Collection not found")


# --- Field CRUD ---

@router.get("/{collection_id}/fields", response_model=list[CollectionFieldOut])
async def list_fields(
    collection_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    return await collection_service.list_fields(db, user_id, collection_id)


@router.post("/{collection_id}/fields", response_model=CollectionFieldOut, status_code=201)
async def add_field(
    collection_id: uuid.UUID,
    data: CollectionFieldCreate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    try:
        return await collection_service.add_field(db, user_id, collection_id, data)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.patch("/{collection_id}/fields/{field_id}", response_model=CollectionFieldOut)
async def update_field(
    collection_id: uuid.UUID,
    field_id: uuid.UUID,
    data: CollectionFieldUpdate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    try:
        field = await collection_service.update_field(db, user_id, collection_id, field_id, data)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not field:
        raise HTTPException(404, "Field not found")
    await db.flush()
    await db.refresh(field)
    return field


@router.delete("/{collection_id}/fields/{field_id}", status_code=204)
async def delete_field(
    collection_id: uuid.UUID,
    field_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    if not await collection_service.delete_field(db, user_id, collection_id, field_id):
        raise HTTPException(404, "Field not found")


# --- Item CRUD ---

@router.get("/{collection_id}/items", response_model=PaginatedResponse[CollectionItemOut])
async def list_items(
    collection_id: uuid.UUID,
    search: Optional[str] = None,
    filter: Optional[str] = Query(None, alias="filter", description="Field filters, e.g. category:Work,rating:gte:4"),
    status: Optional[str] = None,
    sort_by: Optional[str] = None,
    sort_dir: str = Query("desc", pattern="^(asc|desc)$"),
    limit: int = Query(25, le=500),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    total = await collection_service.count_items(db, user_id, collection_id, search=search, filter_str=filter, status=status)
    items = await collection_service.list_items(
        db, user_id, collection_id,
        search=search, filter_str=filter, status=status,
        sort_by=sort_by, sort_dir=sort_dir,
        limit=limit, offset=offset,
    )
    return {"items": items, "total": total}


@router.get("/{collection_id}/items/{item_id}", response_model=CollectionItemOut)
async def get_item(
    collection_id: uuid.UUID,
    item_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    item = await collection_service.get_item(db, user_id, collection_id, item_id)
    if not item:
        raise HTTPException(404, "Item not found")
    return item


@router.post("/{collection_id}/items", response_model=CollectionItemOut, status_code=201)
async def create_item(
    collection_id: uuid.UUID,
    data: CollectionItemCreate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    try:
        return await collection_service.create_item(db, user_id, collection_id, data)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.patch("/{collection_id}/items/{item_id}", response_model=CollectionItemOut)
async def update_item(
    collection_id: uuid.UUID,
    item_id: uuid.UUID,
    data: CollectionItemUpdate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    try:
        item = await collection_service.update_item(db, user_id, collection_id, item_id, data)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not item:
        raise HTTPException(404, "Item not found")
    await db.flush()
    await db.refresh(item)
    return item


@router.delete("/{collection_id}/items/{item_id}", status_code=204)
async def delete_item(
    collection_id: uuid.UUID,
    item_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    if not await collection_service.delete_item(db, user_id, collection_id, item_id):
        raise HTTPException(404, "Item not found")
