"""Slack webhook endpoint — receives events from Slack Events API.

Delegates all request handling (signature verification, retry dedup, event routing)
to the Bolt AsyncSlackRequestHandler. Always returns 200 to Slack.
"""

import logging

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, Response

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/slack", tags=["slack"])


@router.get("/webhook-url")
async def slack_webhook_url(request: Request) -> JSONResponse:
    """Return the current public Slack webhook URL (for manual Event Subscriptions registration)."""
    channel_manager = getattr(request.app.state, "channel_manager", None)
    adapter = channel_manager.get_adapter("slack") if channel_manager else None
    url = adapter.get_webhook_url() if adapter else None
    return JSONResponse({"webhook_url": url, "ready": url is not None})


@router.post("/events")
async def slack_events(request: Request) -> Response:
    """Receive Slack event payloads and delegate to the SlackAdapter (Bolt handler)."""
    channel_manager = getattr(request.app.state, "channel_manager", None)
    if channel_manager is None:
        logger.warning("slack_events_channel_manager_not_ready")
        # Must return 200 or Slack will retry
        return Response(content='{"ok":true}', media_type="application/json")

    adapter = channel_manager.get_adapter("slack")
    if adapter is None:
        logger.warning("slack_adapter_not_found")
        return Response(content='{"ok":true}', media_type="application/json")

    try:
        return await adapter.handle_request(request)
    except Exception as exc:
        logger.exception("slack_events_handler_error: %s", exc)
        return Response(content='{"ok":true}', media_type="application/json")
