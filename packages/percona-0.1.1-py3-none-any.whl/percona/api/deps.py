"""Shared FastAPI dependencies — JWT-based authentication."""
from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.config import settings
from percona.context import set_user_id
from percona.database import get_db
from percona.models.users import AccountStatus, User, UserRole
from percona.services.auth_service import decode_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decode_token(token, settings.jwt_secret_key)
        if payload.get("type") != "access":
            raise exc
        user_id: str = payload.get("sub")
        if not user_id:
            raise exc
    except JWTError:
        raise exc

    result = await db.execute(select(User).where(User.id == UUID(user_id), User.is_active == True))
    user = result.scalar_one_or_none()
    if not user:
        raise exc
    # Set ContextVar so repo-layer filtering works without explicit user_id threading
    set_user_id(user.id)
    return user


async def get_user_id_dep(current_user: User = Depends(get_current_user)) -> UUID:
    """Returns the authenticated user's id."""
    return current_user.id


def require_role(*roles: str):
    """RBAC dependency factory."""
    async def _check(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in roles:
            raise HTTPException(status_code=403, detail=f"Requires role: {roles}")
        return current_user
    return _check


async def require_writable(current_user: User = Depends(get_current_user)) -> User:
    """Block viewer role from write operations."""
    if current_user.role == UserRole.VIEWER:
        raise HTTPException(status_code=403, detail="Viewer role has read-only access")
    return current_user


async def require_active_account(current_user: User = Depends(get_current_user)) -> User:
    """Block pending/suspended users from protected operations."""
    if current_user.account_status != AccountStatus.ACTIVE:
        raise HTTPException(status_code=403, detail="Account pending admin approval")
    return current_user


async def require_agent_access(current_user: User = Depends(require_active_account)) -> User:
    """Active account + non-viewer role. For chat/task trigger endpoints."""
    if current_user.role == UserRole.VIEWER:
        raise HTTPException(status_code=403, detail="Viewer role cannot execute agents")
    return current_user
