import uuid
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_current_user, get_user_id_dep, require_role
from percona.database import get_db
from percona.models import NotificationChannel
from percona.models.users import User
from percona.schemas import NotificationChannelCreate, NotificationChannelOut, NotificationChannelUpdate

router = APIRouter(prefix="/notification-channels", tags=["notification-channels"])
logger = logging.getLogger(__name__)


@router.get("", response_model=list[NotificationChannelOut])
async def list_channels(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    logger.debug("list_notification_channels")
    stmt = select(NotificationChannel).where(NotificationChannel.user_id == user_id).order_by(NotificationChannel.name)
    result = await db.execute(stmt)
    return result.scalars().all()


@router.get("/{channel_id}", response_model=NotificationChannelOut)
async def get_channel(
    channel_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    stmt = select(NotificationChannel).where(
        NotificationChannel.id == channel_id,
        NotificationChannel.user_id == current_user.id,
    )
    result = await db.execute(stmt)
    channel = result.scalar_one_or_none()
    if not channel:
        raise HTTPException(404, "Notification channel not found")
    return channel


@router.post("", response_model=NotificationChannelOut, status_code=201, dependencies=[Depends(require_role("admin"))])
async def create_channel(
    data: NotificationChannelCreate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    logger.info("create_notification_channel name=%s channel_type=%s", data.name, data.channel_type)
    channel = NotificationChannel(**data.model_dump(), user_id=user_id)
    db.add(channel)
    await db.flush()
    logger.info("notification_channel_created channel_id=%s", channel.id)
    return channel


@router.patch("/{channel_id}", response_model=NotificationChannelOut, dependencies=[Depends(require_role("admin"))])
async def update_channel(
    channel_id: uuid.UUID,
    data: NotificationChannelUpdate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    stmt = select(NotificationChannel).where(
        NotificationChannel.id == channel_id,
        NotificationChannel.user_id == user_id,
    )
    result = await db.execute(stmt)
    channel = result.scalar_one_or_none()
    if not channel:
        raise HTTPException(404, "Notification channel not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(channel, key, value)
    logger.debug("notification_channel_updated channel_id=%s", channel_id)
    return channel


@router.delete("/{channel_id}", status_code=204, dependencies=[Depends(require_role("admin"))])
async def delete_channel(
    channel_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    stmt = select(NotificationChannel).where(
        NotificationChannel.id == channel_id,
        NotificationChannel.user_id == user_id,
    )
    result = await db.execute(stmt)
    channel = result.scalar_one_or_none()
    if not channel:
        raise HTTPException(404, "Notification channel not found")
    await db.delete(channel)
    logger.info("notification_channel_deleted channel_id=%s", channel_id)
