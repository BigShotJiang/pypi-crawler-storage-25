import time
import uuid
import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_current_user, get_user_id_dep, require_role
from percona.database import get_db
from percona.models import McpServer
from percona.models.users import User
from percona.schemas import McpServerCreate, McpServerOut, McpServerUpdate
from percona.services import mcp_client
from percona.services.mcp_playground import list_tools, call_tool
from pydantic import BaseModel

router = APIRouter(prefix="/mcp-servers", tags=["mcp-servers"])
logger = logging.getLogger(__name__)


# ─── CRUD ─────────────────────────────────────────────────────────────────────

@router.get("", response_model=list[McpServerOut])
async def list_mcp_servers(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    logger.debug("list_mcp_servers")
    stmt = select(McpServer).where(McpServer.user_id == user_id).order_by(McpServer.name)
    result = await db.execute(stmt)
    return result.scalars().all()


@router.get("/{server_id}", response_model=McpServerOut)
async def get_mcp_server(
    server_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    stmt = select(McpServer).where(McpServer.id == server_id, McpServer.user_id == current_user.id)
    result = await db.execute(stmt)
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(404, "MCP server not found")
    return server


@router.post("", response_model=McpServerOut, status_code=201, dependencies=[Depends(require_role("admin"))])
async def create_mcp_server(
    data: McpServerCreate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    logger.info("create_mcp_server name=%s slug=%s", data.name, data.slug)
    server = McpServer(**data.model_dump(), user_id=user_id)
    db.add(server)
    await db.flush()
    logger.info("mcp_server_created server_id=%s slug=%s", server.id, server.slug)
    return server


@router.patch("/{server_id}", response_model=McpServerOut, dependencies=[Depends(require_role("admin"))])
async def update_mcp_server(
    server_id: uuid.UUID,
    data: McpServerUpdate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    logger.info("update_mcp_server server_id=%s", server_id)
    stmt = select(McpServer).where(McpServer.id == server_id, McpServer.user_id == user_id)
    result = await db.execute(stmt)
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(404, "MCP server not found")
    update_fields = data.model_dump(exclude_unset=True)
    if server.is_internal:
        non_enabled_fields = {k for k in update_fields if k != "enabled"}
        if non_enabled_fields:
            raise HTTPException(403, "Internal MCP servers can only have 'enabled' toggled")
    for key, value in update_fields.items():
        setattr(server, key, value)
    logger.debug("mcp_server_updated server_id=%s", server_id)
    return server


@router.delete("/{server_id}", status_code=204, dependencies=[Depends(require_role("admin"))])
async def delete_mcp_server(
    server_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    logger.info("delete_mcp_server server_id=%s", server_id)
    stmt = select(McpServer).where(McpServer.id == server_id, McpServer.user_id == user_id)
    result = await db.execute(stmt)
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(404, "MCP server not found")
    if server.is_internal:
        raise HTTPException(403, "Internal MCP servers cannot be deleted")
    await db.delete(server)
    logger.info("mcp_server_deleted server_id=%s", server_id)


# ─── Connectivity ─────────────────────────────────────────────────────────────

@router.post("/{server_id}/ping")
async def ping_mcp_server(
    server_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Test connectivity to an MCP server."""
    logger.info("ping_mcp_server server_id=%s", server_id)
    stmt = select(McpServer).where(McpServer.id == server_id, McpServer.user_id == current_user.id)
    result = await db.execute(stmt)
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(404, "MCP server not found")

    t0 = time.monotonic()
    if server.transport in ("http", "streamable-http") or server.is_internal:
        url = server.url
        if not url:
            return {"ok": False, "error": "No URL configured", "latency_ms": 0}
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(url)
            latency_ms = int((time.monotonic() - t0) * 1000)
            ok = resp.status_code < 500
            return {"ok": ok, "latency_ms": latency_ms, "status_code": resp.status_code}
        except Exception as exc:
            latency_ms = int((time.monotonic() - t0) * 1000)
            logger.warning("ping_http_failed server_id=%s error=%s", server_id, exc)
            return {"ok": False, "error": str(exc), "latency_ms": latency_ms}
    else:
        try:
            tools = await mcp_client.list_tools(server.command, server.args, server.env)
            latency_ms = int((time.monotonic() - t0) * 1000)
            logger.info("ping_stdio_ok server_id=%s tools=%s", server_id, len(tools))
            return {"ok": True, "tool_count": len(tools), "latency_ms": latency_ms}
        except Exception as exc:
            latency_ms = int((time.monotonic() - t0) * 1000)
            logger.warning("ping_stdio_failed server_id=%s error=%s", server_id, exc)
            return {"ok": False, "error": str(exc), "latency_ms": latency_ms}


# ─── Playground ───────────────────────────────────────────────────────────────

@router.get("/{server_id}/tools")
async def list_server_tools(
    server_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Discover tools exposed by any MCP server (internal, stdio, or HTTP)."""
    logger.info("list_server_tools server_id=%s", server_id)
    stmt = select(McpServer).where(McpServer.id == server_id, McpServer.user_id == current_user.id)
    result = await db.execute(stmt)
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(404, "MCP server not found")
    try:
        tools = await list_tools(server)
        logger.info("list_server_tools_ok server_id=%s count=%s", server_id, len(tools))
        return {"tools": tools, "error": None}
    except Exception as exc:
        logger.warning("list_server_tools_failed server_id=%s error=%s", server_id, exc)
        return {"tools": [], "error": str(exc)}


class ToolCallRequest(BaseModel):
    tool: str
    params: dict = {}


@router.post("/{server_id}/call")
async def call_server_tool(
    server_id: uuid.UUID,
    body: ToolCallRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Call a tool on any registered MCP server."""
    logger.info("call_server_tool server_id=%s tool=%s", server_id, body.tool)
    stmt = select(McpServer).where(McpServer.id == server_id, McpServer.user_id == current_user.id)
    result = await db.execute(stmt)
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(404, "MCP server not found")
    try:
        tool_result = await call_tool(server, body.tool, body.params)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        logger.warning("call_server_tool_failed server_id=%s tool=%s error=%s", server_id, body.tool, exc)
        raise HTTPException(502, str(exc))
    logger.info("call_server_tool_ok server_id=%s tool=%s", server_id, body.tool)
    return {"tool": body.tool, "result": tool_result}
