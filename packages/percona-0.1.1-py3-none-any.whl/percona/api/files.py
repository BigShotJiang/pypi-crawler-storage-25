import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_user_id_dep
from percona.database import get_db
from percona.schemas import (
    BulkDeleteRequest,
    BulkDeleteResponse,
    PaginatedResponse,
    PresignedUploadRequest,
    PresignedUploadResponse,
    StorageQuotaResponse,
    StoredFileOut,
)
from percona.services.storage import (
    delete_file,
    format_file_size,
    generate_presigned_upload_url,
    generate_thumbnail,
    is_image,
    optimize_image,
    read_file_with_limit,
    upload_file,
    validate_file_extension,
    validate_file_size,
)
from percona.services import storage_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/files", tags=["files"])


@router.post("/upload", response_model=StoredFileOut, status_code=201)
async def upload(
    file: UploadFile,
    folder: str | None = None,
    db=Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    content = read_file_with_limit(file.file)
    original_filename = file.filename or "upload"

    if not validate_file_extension(original_filename):
        raise HTTPException(status_code=400, detail=f"File type not allowed: {original_filename.rsplit('.',1)[-1]!r}")
    if not validate_file_size(len(content)):
        raise HTTPException(status_code=413, detail="File exceeds maximum allowed size")

    content_type = file.content_type or "application/octet-stream"

    is_optimized = False
    if is_image(content_type):
        content = optimize_image(content)
        is_optimized = True
        content_type = "image/jpeg"

    upload_result = upload_file(content, original_filename, content_type=content_type)

    thumbnail_s3_key = None
    thumbnail_url = None
    if is_image(content_type):
        thumb_bytes = generate_thumbnail(content)
        if thumb_bytes:
            thumb_result = upload_file(
                thumb_bytes,
                f"thumb_{original_filename}",
                content_type="image/jpeg",
                is_thumbnail=True,
            )
            thumbnail_s3_key = thumb_result["s3_key"]
            thumbnail_url = thumb_result["s3_url"]

    from percona.models import StoredFile
    item = StoredFile(
        user_id=user_id,
        filename=upload_result["s3_key"].rsplit("/", 1)[-1],
        original_filename=original_filename,
        content_type=upload_result["content_type"],
        file_size_bytes=upload_result["file_size_bytes"],
        s3_key=upload_result["s3_key"],
        s3_url=upload_result["s3_url"],
        folder=folder,
        thumbnail_s3_key=thumbnail_s3_key,
        thumbnail_url=thumbnail_url,
        is_optimized=is_optimized,
    )
    db.add(item)
    await db.flush()
    await db.commit()
    logger.info("storage_file_uploaded id=%s original=%r size=%d", item.id, original_filename, item.file_size_bytes)
    return item


@router.post("/presigned-url", response_model=PresignedUploadResponse)
async def get_presigned_url(body: PresignedUploadRequest):
    result = generate_presigned_upload_url(
        filename=body.filename,
        content_type=body.content_type,
    )
    return result


@router.get("", response_model=PaginatedResponse[StoredFileOut])
async def list_files(
    folder: str | None = None,
    search: str | None = None,
    content_type: str | None = None,
    sort_by: str = "uploaded_at",
    sort_order: str = "desc",
    limit: int = 25,
    offset: int = 0,
    db=Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    items, total = await storage_service.list_files(
        db, user_id,
        folder=folder, search=search, content_type=content_type,
        sort_by=sort_by, sort_order=sort_order, limit=limit, offset=offset,
    )
    return PaginatedResponse(items=items, total=total)


@router.get("/quota", response_model=StorageQuotaResponse)
async def get_quota(
    db=Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    quota = await storage_service.get_quota(db, user_id)
    return StorageQuotaResponse(
        used_bytes=quota["used_bytes"],
        used_formatted=format_file_size(quota["used_bytes"]),
        file_count=quota["file_count"],
    )


@router.get("/{file_id}", response_model=StoredFileOut)
async def get_file(
    file_id: uuid.UUID,
    db=Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    item = await storage_service.get_file(db, user_id, file_id)
    if not item:
        raise HTTPException(status_code=404, detail="File not found")
    return item


@router.delete("/{file_id}", status_code=204)
async def delete_stored_file(
    file_id: uuid.UUID,
    db=Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    deleted = await storage_service.delete_file(db, user_id, file_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="File not found")
    await db.commit()
    logger.info("storage_file_deleted id=%s", file_id)


@router.post("/bulk-delete", response_model=BulkDeleteResponse)
async def bulk_delete(
    body: BulkDeleteRequest,
    db=Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    deleted_count, failed_ids = await storage_service.bulk_delete_files(db, user_id, body.file_ids)
    await db.commit()
    return BulkDeleteResponse(deleted_count=deleted_count, failed_ids=failed_ids)
