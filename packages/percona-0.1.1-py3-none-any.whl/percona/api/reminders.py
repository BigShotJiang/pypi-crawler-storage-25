import logging
import uuid
from datetime import date, datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_user_id_dep
from percona.database import get_db
from percona.schemas import ReminderCreate, ReminderOut, ReminderUpdate, PaginatedResponse
from percona.schemas import VALID_REMINDER_CHANNELS
from percona.services import reminder_service

router = APIRouter(prefix="/reminders", tags=["reminders"])
logger = logging.getLogger(__name__)


@router.get("", response_model=PaginatedResponse[ReminderOut])
async def list_reminders(
    status: str | None = None,
    scheduled_date: date | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    items = await reminder_service.list_reminders(
        db, user_id, status=status, scheduled_date=scheduled_date, limit=limit, offset=offset,
    )
    total = await reminder_service.count_reminders(
        db, user_id, status=status, scheduled_date=scheduled_date,
    )
    return {"items": items, "total": total}


@router.get("/{reminder_id}", response_model=ReminderOut)
async def get_reminder(
    reminder_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    reminder = await reminder_service.get_reminder(db, user_id, reminder_id)
    if not reminder:
        raise HTTPException(404, "Reminder not found")
    return reminder


@router.post("", response_model=ReminderOut, status_code=201)
async def create_reminder(
    data: ReminderCreate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    # Validate channels
    invalid = set(data.channels) - VALID_REMINDER_CHANNELS
    if invalid:
        raise HTTPException(400, f"Invalid channels: {invalid}. Allowed: {VALID_REMINDER_CHANNELS}")
    if not data.channels:
        raise HTTPException(400, "At least one channel is required")

    now = datetime.now(timezone.utc)
    send_now = data.scheduled_at is None or data.scheduled_at <= now

    reminder = await reminder_service.create_reminder(
        db, user_id,
        name=data.name,
        description=data.description,
        channels=data.channels,
        scheduled_at=data.scheduled_at,
    )

    logger.info("reminder_created id=%s name=%s send_now=%s", reminder.id, reminder.name, send_now)

    if send_now:
        await db.commit()
        from percona.worker.tasks import send_reminder
        send_reminder.delay(str(reminder.id))
        await db.refresh(reminder)
    else:
        await db.flush()

    return reminder


@router.patch("/{reminder_id}", response_model=ReminderOut)
async def update_reminder(
    reminder_id: uuid.UUID,
    data: ReminderUpdate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    result = await reminder_service.get_reminder(db, user_id, reminder_id)
    if not result:
        raise HTTPException(404, "Reminder not found")
    if result.status != "pending":
        raise HTTPException(400, f"Cannot update reminder with status '{result.status}'")

    updates = data.model_dump(exclude_unset=True)
    if "channels" in updates:
        invalid = set(updates["channels"]) - VALID_REMINDER_CHANNELS
        if invalid:
            raise HTTPException(400, f"Invalid channels: {invalid}")
        if not updates["channels"]:
            raise HTTPException(400, "At least one channel is required")

    for field, value in updates.items():
        setattr(result, field, value)

    return result


@router.delete("/{reminder_id}", status_code=204)
async def delete_reminder(
    reminder_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    reminder = await reminder_service.delete_reminder(db, user_id, reminder_id)
    if not reminder:
        raise HTTPException(404, "Reminder not found")


@router.post("/{reminder_id}/send", response_model=ReminderOut)
async def send_reminder_now(
    reminder_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    reminder = await reminder_service.send_reminder_now(db, user_id, reminder_id)
    if not reminder:
        raise HTTPException(404, "Reminder not found")
    if reminder.status != "pending":
        raise HTTPException(400, f"Cannot send reminder with status '{reminder.status}'")

    await db.commit()
    from percona.worker.tasks import send_reminder
    send_reminder.delay(str(reminder.id))
    await db.refresh(reminder)
    logger.info("reminder_force_sent id=%s", reminder_id)
    return reminder
