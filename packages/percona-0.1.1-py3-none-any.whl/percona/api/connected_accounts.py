import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_user_id_dep
from percona.database import get_db
from percona.models import ConnectedAccount
from percona.schemas import ConnectedAccountOut, ConnectedAccountUpdate
from percona.services import oauth_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/connected-accounts", tags=["connected-accounts"])


class TelegramConnectRequest(BaseModel):
    bot_token: str
    chat_id: int | None = None


@router.get("", response_model=list[ConnectedAccountOut])
async def list_connected_accounts(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.user_id == user_id).order_by(ConnectedAccount.created_at.desc())
    )
    return result.scalars().all()


@router.get("/{account_id}", response_model=ConnectedAccountOut)
async def get_connected_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.id == account_id, ConnectedAccount.user_id == user_id)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Connected account not found")
    return account


@router.patch("/{account_id}", response_model=ConnectedAccountOut)
async def update_connected_account(
    account_id: uuid.UUID,
    body: ConnectedAccountUpdate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.id == account_id, ConnectedAccount.user_id == user_id)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Connected account not found")

    if body.label is not None:
        account.label = body.label or None
    if body.provider_metadata is not None:
        account.provider_metadata = {**account.provider_metadata, **body.provider_metadata}

    await db.commit()
    await db.refresh(account)
    return account


@router.delete("/{account_id}", status_code=204)
async def delete_connected_account(
    account_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.id == account_id, ConnectedAccount.user_id == user_id)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Connected account not found")

    provider = account.provider  # capture before delete
    await oauth_service.revoke_account(db, account_id)

    channel_manager = getattr(request.app.state, "channel_manager", None)
    if channel_manager:
        if provider == "whatsapp":
            adapter = channel_manager.get_adapter("whatsapp")
            if adapter:
                await adapter.stop_client(str(account_id))
        elif provider == "telegram":
            adapter = channel_manager.get_adapter("telegram")
            if adapter:
                await adapter.stop_app(str(account_id))


@router.post("/telegram/connect", response_model=ConnectedAccountOut)
async def connect_telegram_bot(
    body: TelegramConnectRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    from percona.services import telegram_service

    try:
        account = await telegram_service.connect_telegram_bot(db, user_id, body.bot_token, body.chat_id)
        await db.commit()
        await db.refresh(account)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    # Start the adapter for this newly connected bot
    channel_manager = getattr(request.app.state, "channel_manager", None)
    if channel_manager:
        adapter = channel_manager.get_adapter("telegram")
        if adapter:
            from percona.services.oauth_service import decrypt_token
            bot_token = decrypt_token(account.access_token)
            await adapter._start_app(str(account.id), bot_token, account.provider_metadata, account.user_id)

    return account


@router.post("/{account_id}/refresh", response_model=ConnectedAccountOut)
async def refresh_connected_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.id == account_id, ConnectedAccount.user_id == user_id)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Connected account not found")
    try:
        await oauth_service.get_valid_access_token(db, account_id)
        await db.refresh(account)
        return account
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
