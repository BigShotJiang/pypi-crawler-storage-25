import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_current_user, require_role
from percona.database import get_db
from percona.models.users import User
from percona.schemas.users import UserCreateAdmin, UserOut, UserUpdate
from percona.services.auth_service import create_user, get_user_by_email, hash_password

router = APIRouter(prefix="/users", tags=["users"])
logger = logging.getLogger(__name__)


@router.get("", response_model=list[UserOut], dependencies=[Depends(require_role("admin"))])
async def list_users(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).order_by(User.name))
    return result.scalars().all()


@router.post("", response_model=UserOut, status_code=201, dependencies=[Depends(require_role("admin"))])
async def create_user_admin(
    data: UserCreateAdmin,
    db: AsyncSession = Depends(get_db),
):
    """Admin-only: create a new user with specified role."""
    existing = await get_user_by_email(db, data.email)
    if existing:
        raise HTTPException(409, "A user with this email already exists")

    user = await create_user(
        db,
        email=data.email,
        password=data.password,
        full_name=data.full_name,
        role=data.role,
    )
    return user


@router.get("/{user_id}", response_model=UserOut, dependencies=[Depends(require_role("admin"))])
async def get_user(user_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "User not found")
    return user


@router.patch("/{user_id}", response_model=UserOut, dependencies=[Depends(require_role("admin"))])
async def update_user(
    user_id: uuid.UUID,
    data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "User not found")

    # Prevent self-demotion and self-deactivation
    if user_id == current_user.id:
        if data.role is not None and data.role != current_user.role:
            raise HTTPException(400, "Cannot change your own role")
        if data.is_active is not None and not data.is_active:
            raise HTTPException(400, "Cannot deactivate your own account")

    updates = data.model_dump(exclude_unset=True)

    # Handle password separately — hash it
    password = updates.pop("password", None)
    if password:
        user.hashed_password = hash_password(password)

    for field, value in updates.items():
        setattr(user, field, value)

    await db.flush()
    await db.refresh(user)
    return user


@router.delete("/{user_id}", status_code=204, dependencies=[Depends(require_role("admin"))])
async def delete_user(
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if user_id == current_user.id:
        raise HTTPException(400, "Cannot delete your own account")

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "User not found")
    await db.delete(user)
    logger.info("user_deleted id=%s by=%s", user_id, current_user.id)
