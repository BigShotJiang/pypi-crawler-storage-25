import io
import json
import logging
import uuid

import redis.asyncio as aioredis
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.requests import Request
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from sse_starlette.sse import EventSourceResponse

from percona.api.deps import get_user_id_dep, require_agent_access
from percona.config import AGENT_CONTEXT_WINDOWS, settings
from percona.context import set_conversation_id
from percona.database import get_db, async_session_factory
from percona.models import AgentType, Conversation, ConversationMessage, ConversationToolCall, MessageRole, ToolCallStatus
from percona.models.artifacts import ArtifactSourceType, ArtifactTrigger
from percona.schemas import BulkDeleteRequest, BulkDeleteResponse, ConversationCreate, ConversationUpdate
from percona.schemas.artifacts import ArtifactOut
from percona.services import active_conversation_service, artifact_service, conversation_service
from percona.services.worker.chat_orchestrator import ChatOrchestrator

from percona.agents.domain_events import (
    AgentCompleted,
    AgentError,
    AgentPaused,
    AgentStarted,
    DomainEvent,
    EntityEvent,
    TextDelta,
    ThinkingDelta,
    ToolInvocationCompleted,
    ToolInvocationStarted,
    UserQuestionRequested,
)
from percona.agents.entity_events import extract_entity_from_tool_result

router = APIRouter(prefix="/conversations", tags=["chat"])
logger = logging.getLogger(__name__)


def domain_event_to_sse(event: DomainEvent) -> dict:
    """Serialize DomainEvent to SSE payload."""
    if isinstance(event, AgentStarted):
        return {"event": "started", "data": json.dumps({"session_id": event.session_id, "agent_type": event.agent_type})}
    if isinstance(event, TextDelta):
        return {"event": "text_delta", "data": json.dumps({"text": event.text})}
    if isinstance(event, ThinkingDelta):
        return {"event": "thinking", "data": json.dumps({"thinking": event.thinking})}
    if isinstance(event, ToolInvocationStarted):
        return {"event": "tool_use_start", "data": json.dumps({"tool_name": event.tool_name, "tool_use_id": event.tool_use_id, "tool_server": event.tool_server, "input": event.input})}
    if isinstance(event, ToolInvocationCompleted):
        return {"event": "tool_result", "data": json.dumps({"tool_use_id": event.tool_use_id, "result": event.result, "is_error": event.is_error})}
    if isinstance(event, AgentCompleted):
        return {"event": "completed", "data": json.dumps({"usage": event.usage, "success": event.success})}
    if isinstance(event, AgentError):
        return {"event": "error", "data": json.dumps({"message": event.message, "error_type": event.error_type})}
    if isinstance(event, EntityEvent):
        return {"event": "entity_event", "data": json.dumps({
            "entity_type": event.entity_type,
            "event_type": event.event_type,
            "entity_id": event.entity_id,
            "entity_title": event.entity_title,
            "entity_url": event.entity_url,
            "metadata": event.metadata,
        })}
    if isinstance(event, UserQuestionRequested):
        return {"event": "user_question", "data": json.dumps({
            "question_id": event.question_id,
            "question": event.question,
            "options": event.options,
            "header": event.header,
            "multi_select": event.multi_select,
            "allow_custom": event.allow_custom,
            "conversation_id": event.conversation_id,
        })}
    if isinstance(event, AgentPaused):
        return {"event": "paused", "data": json.dumps({
            "reason": event.reason,
            "question_id": event.question_id,
        })}
    return {"event": "unknown", "data": json.dumps({})}


# --- Schemas ---


class MessageCreate(BaseModel):
    content: str
    attachment_ids: list[uuid.UUID] = []


# --- Endpoints ---


def _conv_dict(c, message_count: int = 0, tool_call_count: int = 0) -> dict:
    return {
        "id": str(c.id),
        "title": c.title,
        "agent_type": c.agent_type.value,
        "system_prompt": c.system_prompt,
        "agent_settings": c.agent_settings,
        "pre_run_context": c.pre_run_context,
        "is_active": c.is_active,
        "source_session_id": str(c.source_session_id) if c.source_session_id else None,
        "total_input_tokens": c.total_input_tokens,
        "total_output_tokens": c.total_output_tokens,
        "total_cost_usd": c.total_cost_usd,
        "mcp_server_ids": [str(s.id) for s in c.mcp_servers],
        "memory_file_ids": [str(mf.id) for mf in c.memory_files],
        "message_count": message_count,
        "tool_call_count": tool_call_count,
        "created_at": c.created_at.isoformat(),
        "updated_at": c.updated_at.isoformat(),
    }


def _conv_opts():
    return [
        selectinload(Conversation.mcp_servers),
        selectinload(Conversation.memory_files),
    ]


# --- Recent (non-active) conversations ---


@router.get("/recent")
async def list_recent_conversations(
    limit: int = Query(5, le=20),
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """List recent conversations continued from task sessions."""
    stmt = (
        select(Conversation)
        .where(
            Conversation.user_id == user_id,
            Conversation.is_active.is_(False),
            Conversation.archived_at.is_(None),
            Conversation.source_session_id.isnot(None),
        )
        .order_by(Conversation.updated_at.desc())
        .limit(limit)
        .options(*_conv_opts())
    )
    result = await db.execute(stmt)
    convs = result.scalars().all()
    return {"items": [_conv_dict(c) for c in convs]}


# --- Active Chat Endpoints (single endless conversation) ---


@router.get("/active")
async def get_active_conversation(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """Get or create the single active conversation for the current user."""
    conversation = await active_conversation_service.get_or_create_active_conversation(db, user_id)
    await db.commit()

    # Reload with associations
    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation.id)
        .options(
            selectinload(Conversation.messages),
            selectinload(Conversation.tool_calls),
            selectinload(Conversation.mcp_servers),
            selectinload(Conversation.memory_files),
        )
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one()

    return _active_conv_detail(conversation)


@router.post("/active/new")
async def start_new_conversation(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """Archive the current conversation and start a fresh one."""
    conversation = await active_conversation_service.start_new_conversation(db, user_id)
    await db.commit()

    # Reload with associations
    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation.id)
        .options(
            selectinload(Conversation.messages),
            selectinload(Conversation.tool_calls),
            selectinload(Conversation.mcp_servers),
            selectinload(Conversation.memory_files),
        )
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one()

    return _active_conv_detail(conversation)


@router.get("/active/context-usage")
async def get_active_context_usage(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """Get context usage metrics for the active conversation."""
    conversation = await active_conversation_service.get_or_create_active_conversation(db, user_id)
    await db.commit()
    return await active_conversation_service.get_context_usage(conversation)


@router.get("/active/messages")
async def get_active_messages(
    limit: int = Query(30, le=100),
    before: str | None = None,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """Get paginated messages across the full conversation chain.

    Walks the chain: active → parent → grandparent → ...
    Returns messages ordered by created_at desc, newest first.
    Use `before` cursor (ISO datetime) for pagination.
    """
    conversation = await active_conversation_service.get_or_create_active_conversation(db, user_id)
    await db.commit()

    # Collect conversation chain IDs
    chain_ids = []
    current = conversation
    max_depth = 50  # safety limit
    while current and len(chain_ids) < max_depth:
        chain_ids.append(current.id)
        if current.parent_conversation_id:
            result = await db.execute(
                select(Conversation).where(Conversation.id == current.parent_conversation_id)
            )
            current = result.scalar_one_or_none()
        else:
            break

    # Query messages across the chain
    stmt = (
        select(ConversationMessage)
        .where(ConversationMessage.conversation_id.in_(chain_ids))
        .order_by(ConversationMessage.created_at.desc())
        .limit(limit)
    )
    if before:
        from datetime import datetime as dt
        try:
            before_dt = dt.fromisoformat(before.replace("Z", "+00:00"))
            stmt = stmt.where(ConversationMessage.created_at < before_dt)
        except ValueError:
            raise HTTPException(400, "Invalid 'before' datetime format")

    result = await db.execute(stmt)
    messages_raw = list(result.scalars().all())

    # Filter out compaction turn messages — these are internal system messages
    # that should not be visible to the user. The compaction turn is the last
    # turn in any archived (non-active) conversation in the chain.
    archived_ids = set(chain_ids) - {conversation.id}
    compaction_turns: dict[uuid.UUID, int] = {}
    if archived_ids:
        for arc_id in archived_ids:
            max_turn_result = await db.execute(
                select(func.max(ConversationMessage.turn_sequence))
                .where(ConversationMessage.conversation_id == arc_id)
            )
            max_turn = max_turn_result.scalar()
            if max_turn is not None:
                compaction_turns[arc_id] = max_turn

    messages = [
        m for m in messages_raw
        if not (m.conversation_id in compaction_turns
                and m.turn_sequence == compaction_turns[m.conversation_id])
    ]

    # Also fetch tool calls for these conversations
    tc_stmt = (
        select(ConversationToolCall)
        .where(ConversationToolCall.conversation_id.in_(chain_ids))
        .order_by(ConversationToolCall.created_at.desc())
        .limit(limit * 3)  # tool calls can be more numerous
    )
    if before:
        tc_stmt = tc_stmt.where(ConversationToolCall.created_at < before_dt)
    tc_result = await db.execute(tc_stmt)
    tool_calls_raw = list(tc_result.scalars().all())

    # Filter out compaction turn tool calls too
    tool_calls = [
        tc for tc in tool_calls_raw
        if not (tc.conversation_id in compaction_turns
                and tc.turn_sequence == compaction_turns[tc.conversation_id])
    ]

    # Get the active conversation's agent type for assistant messages
    agent_type_val = conversation.agent_type.value

    return {
        "messages": [
            {
                "id": str(m.id),
                "conversation_id": str(m.conversation_id),
                "role": m.role.value,
                "content": m.content,
                "sequence": m.sequence,
                "turn_sequence": m.turn_sequence,
                "error_message": m.error_message,
                "error_type": m.error_type,
                "status": m.status,
                "message_type": m.message_type,
                "result_data": m.result_data,
                "agent_type": agent_type_val if m.role == MessageRole.ASSISTANT else None,
                "created_at": m.created_at.isoformat(),
            }
            for m in sorted(messages, key=lambda m: m.created_at)
        ],
        "tool_calls": [
            {
                "id": str(tc.id),
                "conversation_id": str(tc.conversation_id),
                "turn_sequence": tc.turn_sequence,
                "tool_name": tc.tool_name,
                "tool_server": tc.tool_server,
                "input_params": tc.input_params,
                "output_result": tc.output_result,
                "status": tc.status.value,
                "duration_ms": tc.duration_ms,
                "sequence": tc.sequence,
                "created_at": tc.created_at.isoformat(),
            }
            for tc in sorted(tool_calls, key=lambda tc: tc.created_at)
        ],
        "has_more": len(messages) == limit,
    }


def _active_conv_detail(conversation: Conversation) -> dict:
    """Serialize active conversation with messages and tool calls."""
    return {
        "id": str(conversation.id),
        "title": conversation.title,
        "agent_type": conversation.agent_type.value,
        "system_prompt": conversation.system_prompt,
        "agent_settings": conversation.agent_settings,
        "pre_run_context": conversation.pre_run_context,
        "is_active": conversation.is_active,
        "source_session_id": str(conversation.source_session_id) if conversation.source_session_id else None,
        "parent_conversation_id": str(conversation.parent_conversation_id) if conversation.parent_conversation_id else None,
        "total_input_tokens": conversation.total_input_tokens,
        "total_output_tokens": conversation.total_output_tokens,
        "total_cost_usd": conversation.total_cost_usd,
        "mcp_server_ids": [str(s.id) for s in conversation.mcp_servers],
        "memory_file_ids": [str(mf.id) for mf in conversation.memory_files],
        "created_at": conversation.created_at.isoformat(),
        "updated_at": conversation.updated_at.isoformat(),
        "messages": [
            {
                "id": str(m.id),
                "role": m.role.value,
                "content": m.content,
                "sequence": m.sequence,
                "turn_sequence": m.turn_sequence,
                "error_message": m.error_message,
                "error_type": m.error_type,
                "status": m.status,
                "message_type": m.message_type,
                "result_data": m.result_data,
                "agent_type": conversation.agent_type.value if m.role == MessageRole.ASSISTANT else None,
                "created_at": m.created_at.isoformat(),
            }
            for m in sorted(conversation.messages, key=lambda m: m.sequence)
        ],
        "tool_calls": [
            {
                "id": str(tc.id),
                "turn_sequence": tc.turn_sequence,
                "tool_name": tc.tool_name,
                "tool_server": tc.tool_server,
                "input_params": tc.input_params,
                "output_result": tc.output_result,
                "status": tc.status.value,
                "duration_ms": tc.duration_ms,
                "sequence": tc.sequence,
                "created_at": tc.created_at.isoformat(),
            }
            for tc in sorted(conversation.tool_calls, key=lambda tc: tc.sequence)
        ],
    }


# --- Legacy Multi-Chat Endpoints (kept for backwards compat) ---


@router.get("")
async def list_conversations(
    limit: int = Query(25, le=200),
    offset: int = 0,
    agent_type: str | None = None,
    q: str | None = None,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    base_stmt = select(Conversation).where(Conversation.user_id == user_id)
    if agent_type:
        try:
            at = AgentType(agent_type)
            base_stmt = base_stmt.where(Conversation.agent_type == at)
        except ValueError:
            pass
    if q:
        base_stmt = base_stmt.where(Conversation.title.ilike(f"%{q}%"))

    count_result = await db.execute(select(func.count()).select_from(base_stmt.subquery()))
    total = count_result.scalar_one()

    msg_count_sq = (
        select(func.count())
        .where(ConversationMessage.conversation_id == Conversation.id)
        .correlate(Conversation)
        .scalar_subquery()
    )
    tool_count_sq = (
        select(func.count())
        .where(ConversationToolCall.conversation_id == Conversation.id)
        .correlate(Conversation)
        .scalar_subquery()
    )

    stmt = (
        base_stmt
        .add_columns(msg_count_sq.label("message_count"), tool_count_sq.label("tool_call_count"))
        .order_by(Conversation.updated_at.desc())
        .limit(limit)
        .offset(offset)
        .options(*_conv_opts())
    )
    result = await db.execute(stmt)
    items = [_conv_dict(c, msg_count or 0, tool_count or 0) for c, msg_count, tool_count in result.all()]
    return {"items": items, "total": total}


@router.post("", status_code=201)
async def create_conversation(
    body: ConversationCreate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    try:
        conversation = await conversation_service.create_conversation(db, user_id, body)
    except ValueError as e:
        raise HTTPException(400, str(e))

    await db.commit()

    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation.id)
        .options(*_conv_opts())
    )
    result = await db.execute(stmt)
    return _conv_dict(result.scalar_one())


@router.get("/{conversation_id}")
async def get_conversation(
    conversation_id: uuid.UUID,
    message_limit: int = Query(30, le=200),
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation_id)
        .where(Conversation.user_id == user_id)
        .options(
            selectinload(Conversation.mcp_servers),
            selectinload(Conversation.memory_files),
        )
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    # Load last N visible messages (exclude internal/compaction messages)
    msg_stmt = (
        select(ConversationMessage)
        .where(
            ConversationMessage.conversation_id == conversation_id,
            ConversationMessage.status != "internal",
        )
        .order_by(ConversationMessage.created_at.desc())
        .limit(message_limit)
    )
    msg_result = await db.execute(msg_stmt)
    messages = list(reversed(msg_result.scalars().all()))

    # Load tool calls for the visible turns only
    visible_turns = {m.turn_sequence for m in messages}
    tc_stmt = (
        select(ConversationToolCall)
        .where(
            ConversationToolCall.conversation_id == conversation_id,
            ConversationToolCall.turn_sequence.in_(visible_turns),
        )
        .order_by(ConversationToolCall.sequence)
    )
    tc_result = await db.execute(tc_stmt)
    tool_calls = list(tc_result.scalars().all())

    return {
        "id": str(conversation.id),
        "title": conversation.title,
        "agent_type": conversation.agent_type.value,
        "system_prompt": conversation.system_prompt,
        "agent_settings": conversation.agent_settings,
        "pre_run_context": conversation.pre_run_context,
        "is_active": conversation.is_active,
        "source_session_id": str(conversation.source_session_id) if conversation.source_session_id else None,
        "parent_conversation_id": str(conversation.parent_conversation_id) if conversation.parent_conversation_id else None,
        "total_input_tokens": conversation.total_input_tokens,
        "total_output_tokens": conversation.total_output_tokens,
        "total_cost_usd": conversation.total_cost_usd,
        "mcp_server_ids": [str(s.id) for s in conversation.mcp_servers],
        "memory_file_ids": [str(mf.id) for mf in conversation.memory_files],
        "created_at": conversation.created_at.isoformat(),
        "updated_at": conversation.updated_at.isoformat(),
        "messages": [
            {
                "id": str(m.id),
                "role": m.role.value,
                "content": m.content,
                "sequence": m.sequence,
                "turn_sequence": m.turn_sequence,
                "error_message": m.error_message,
                "error_type": m.error_type,
                "status": m.status,
                "message_type": m.message_type,
                "result_data": m.result_data,
                "agent_type": conversation.agent_type.value if m.role == MessageRole.ASSISTANT else None,
                "created_at": m.created_at.isoformat(),
            }
            for m in messages
        ],
        "tool_calls": [
            {
                "id": str(tc.id),
                "turn_sequence": tc.turn_sequence,
                "tool_name": tc.tool_name,
                "tool_server": tc.tool_server,
                "input_params": tc.input_params,
                "output_result": tc.output_result,
                "status": tc.status.value,
                "duration_ms": tc.duration_ms,
                "sequence": tc.sequence,
                "created_at": tc.created_at.isoformat(),
            }
            for tc in tool_calls
        ],
    }


@router.get("/{conversation_id}/effective-system-prompt")
async def get_effective_system_prompt(
    conversation_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """Build and return the full effective system prompt for a conversation."""
    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation_id)
        .where(Conversation.user_id == user_id)
        .options(selectinload(Conversation.mcp_servers))
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    effective = await _build_effective_prompt(db, conversation)
    return {"effective_system_prompt": effective}


@router.patch("/{conversation_id}")
async def update_conversation(
    conversation_id: uuid.UUID,
    body: ConversationUpdate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    # Check if agent type is changing — requires session rotation
    if body.agent_type:
        conv_result = await db.execute(
            select(Conversation)
            .where(Conversation.id == conversation_id, Conversation.user_id == user_id)
        )
        existing = conv_result.scalar_one_or_none()
        if existing and existing.agent_type.value != body.agent_type:
            # Agent type is changing — rotate session so the new agent gets
            # a summary of the conversation context from the old agent
            try:
                new_agent = AgentType(body.agent_type)
            except ValueError:
                raise HTTPException(400, f"Invalid agent_type: {body.agent_type}")

            existing.agent_type = new_agent
            existing.agent_native_session_id = None
            existing.tokens_remaining_pct = 100.0
            existing.context_window = AGENT_CONTEXT_WINDOWS.get(body.agent_type, 200_000)
            if body.agent_settings:
                existing.agent_settings = body.agent_settings

    conversation = await conversation_service.update_conversation(
        db, user_id, conversation_id,
        title=body.title,
        system_prompt=body.system_prompt,
        agent_settings=body.agent_settings,
        pre_run_context=body.pre_run_context,
        mcp_server_ids=body.mcp_server_ids,
    )
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    await db.commit()
    # Refresh to get updated state
    stmt = select(Conversation).where(Conversation.id == conversation_id).options(*_conv_opts())
    res = await db.execute(stmt)
    conversation = res.scalar_one()

    return _conv_dict(conversation)


@router.delete("/{conversation_id}", status_code=204)
async def delete_conversation(
    conversation_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    deleted = await conversation_service.delete_conversation(db, user_id, conversation_id)
    if not deleted:
        raise HTTPException(404, "Conversation not found")
    await db.commit()


@router.post("/bulk-delete", response_model=BulkDeleteResponse)
async def bulk_delete_conversations(
    body: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    deleted_count = 0
    failed_ids = []
    for conv_id in body.file_ids:
        result = await db.execute(
            select(Conversation)
            .where(Conversation.id == conv_id)
            .where(Conversation.user_id == user_id)
        )
        item = result.scalar_one_or_none()
        if not item:
            failed_ids.append(str(conv_id))
            continue
        await db.delete(item)
        deleted_count += 1
    await db.commit()
    logger.info("conversations_bulk_deleted count=%d", deleted_count)
    return BulkDeleteResponse(deleted_count=deleted_count, failed_ids=failed_ids)


@router.post("/{conversation_id}/messages", dependencies=[Depends(require_agent_access)])
async def send_message(
    conversation_id: uuid.UUID,
    body: MessageCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """
    Send a message and receive streaming agent response.
    Following best practices from eduwise: direct streaming + atomic persistence.
    """
    if not body.content.strip():
        raise HTTPException(400, "Message content cannot be empty")
    stmt = select(Conversation).where(Conversation.id == conversation_id).where(Conversation.user_id == user_id)
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    async def event_generator():
        # Ordered list of events preserving arrival sequence.
        # Each item: {"kind": "text", "content": str}
        #          | {"kind": "tool", "tool_id": str, "tool_name": str, ...}
        events_ordered: list[dict] = []
        entity_events: list[dict] = []  # Entity card data to persist
        usage_data = {}
        agent_native_session_id = None
        error_message = None
        error_type = None
        turn_finalized = False

        async with async_session_factory() as gen_db:
            orchestrator = ChatOrchestrator(gen_db)
            set_conversation_id(str(conversation_id))

            try:
                # Resolve attachment_ids to attachment metadata
                attachments = None
                if body.attachment_ids:
                    from percona.models import StoredFile
                    att_result = await gen_db.execute(
                        select(StoredFile).where(
                            StoredFile.id.in_(body.attachment_ids),
                            StoredFile.user_id == user_id,
                        )
                    )
                    stored_files = att_result.scalars().all()
                    attachments = [
                        {
                            "id": str(sf.id),
                            "filename": sf.filename,
                            "original_filename": sf.original_filename,
                            "content_type": sf.content_type,
                            "size_bytes": sf.file_size_bytes,
                            "s3_key": sf.s3_key,
                            "s3_url": sf.s3_url,
                            "thumbnail_url": sf.thumbnail_url,
                            "extracted_text": None,
                            "source": "web",
                        }
                        for sf in stored_files
                    ]
                    # Extract text from documents
                    from percona.services.media_service import _extract_text
                    for att in attachments:
                        if att["content_type"] in ("application/pdf", "text/plain", "text/csv", "text/markdown",
                                                   "application/json", "text/html", "application/xml", "text/xml"):
                            from percona.services.storage import download_file_bytes
                            file_bytes = download_file_bytes(att["s3_key"])
                            if file_bytes:
                                att["extracted_text"] = _extract_text(file_bytes, att["content_type"], att["original_filename"])

                async for event in orchestrator.run_chat_turn(str(conversation_id), body.content.strip(), attachments=attachments):
                    if isinstance(event, AgentStarted):
                        # The adapter emits a second AgentStarted with the native session ID.
                        # Capture it but don't forward to the frontend — a duplicate "started"
                        # resets liveTurn on the client, wiping any accumulated tool calls.
                        if event.session_id and event.session_id != str(conversation_id):
                            agent_native_session_id = event.session_id
                            continue
                    elif isinstance(event, TextDelta):
                        # Extend the last text segment or start a new one
                        if events_ordered and events_ordered[-1]["kind"] == "text":
                            events_ordered[-1]["content"] += event.text
                        else:
                            events_ordered.append({"kind": "text", "content": event.text})
                    elif isinstance(event, ToolInvocationStarted):
                        events_ordered.append({
                            "kind": "tool",
                            "tool_id": event.tool_use_id,
                            "tool_name": event.tool_name,
                            "tool_server": event.tool_server,
                            "input_params": event.input,
                            "status": "running",
                        })
                    elif isinstance(event, ToolInvocationCompleted):
                        # Find the matching tool start event
                        tool_input = None
                        for ev in events_ordered:
                            if ev.get("kind") == "tool" and ev.get("tool_id") == event.tool_use_id:
                                ev["is_error"] = event.is_error
                                ev["status"] = event.status
                                ev["output_result"] = str(event.result)
                                ev["duration_ms"] = event.duration_ms
                                tool_input = ev.get("input_params")
                                break

                        # Check if this is a pending user input (ask_user tool)
                        if not event.is_error and isinstance(event.result, str):
                            try:
                                result_parsed = json.loads(event.result)
                                if isinstance(result_parsed, dict) and result_parsed.get("_pending_user_input"):
                                    q_data = result_parsed.get("_question_data", {})
                                    yield domain_event_to_sse(UserQuestionRequested(
                                        question_id=q_data.get("question_id", ""),
                                        question=q_data.get("question", ""),
                                        options=q_data.get("options", []),
                                        header=q_data.get("header", "Quick Question"),
                                        multi_select=q_data.get("multi_select", False),
                                        allow_custom=q_data.get("allow_custom", False),
                                        conversation_id=str(conversation_id),
                                    ))
                            except (json.JSONDecodeError, TypeError):
                                pass

                        # Check if this tool produced an entity event
                        if not event.is_error:
                            entity_data = extract_entity_from_tool_result(
                                event.tool_name, tool_input, event.result,
                            )
                            if entity_data:
                                entity_events.append(entity_data)
                                entity_evt = EntityEvent(
                                    entity_type=entity_data["entity_type"],
                                    event_type=entity_data["event_type"],
                                    entity_id=entity_data["entity_id"],
                                    entity_title=entity_data["entity_title"],
                                    entity_url=entity_data["entity_url"],
                                    metadata=entity_data["metadata"],
                                )
                                yield domain_event_to_sse(entity_evt)

                    elif isinstance(event, AgentError):
                        error_message = event.message
                        error_type = event.error_type
                    elif isinstance(event, AgentCompleted):
                        usage_data = event.usage
                        # If resume failed (0 tokens = stale session), clear the session ID
                        # so finalize_turn clears the dead reference from the DB
                        if not event.success and event.usage.get("input_tokens", 0) == 0:
                            agent_native_session_id = None
                            if not error_message:
                                error_message = "Session expired — please resend your message."
                                error_type = "SessionExpired"

                    yield domain_event_to_sse(event)

                # Finalize turn: handle both successful completion and error cases
                await orchestrator.finalize_turn(
                    conversation_id=str(conversation_id),
                    events_ordered=events_ordered,
                    agent_native_session_id=agent_native_session_id,
                    input_tokens=usage_data.get("input_tokens", 0),
                    output_tokens=usage_data.get("output_tokens", 0),
                    cost_usd=usage_data.get("cost_usd", 0.0),
                    error_message=error_message,
                    error_type=error_type,
                    context_window=usage_data.get("context_window"),
                    tokens_remaining_pct=usage_data.get("tokens_remaining_pct"),
                    entity_events=entity_events if entity_events else None,
                )
                turn_finalized = True

                # Check if context rotation is needed
                conv_result = await gen_db.execute(
                    select(Conversation).where(Conversation.id == conversation_id)
                )
                conv_fresh = conv_result.scalar_one_or_none()
                if conv_fresh and not error_message:
                    needs_rotation = await active_conversation_service.should_rotate(conv_fresh, db=gen_db)
                    if needs_rotation:
                        yield {"event": "rotation_starting", "data": json.dumps({})}

                        # Run compaction turn
                        compaction_events: list[dict] = []
                        compaction_usage = {}
                        compaction_session_id = None

                        compaction_prompt = await _get_compact_prompt(gen_db, conversation.user_id)

                        async for cevent in orchestrator.run_chat_turn(str(conversation_id), compaction_prompt):
                            if isinstance(cevent, AgentStarted):
                                if cevent.session_id and cevent.session_id != str(conversation_id):
                                    compaction_session_id = cevent.session_id
                                continue
                            elif isinstance(cevent, TextDelta):
                                if compaction_events and compaction_events[-1]["kind"] == "text":
                                    compaction_events[-1]["content"] += cevent.text
                                else:
                                    compaction_events.append({"kind": "text", "content": cevent.text})
                            elif isinstance(cevent, ToolInvocationStarted):
                                compaction_events.append({
                                    "kind": "tool", "tool_id": cevent.tool_use_id,
                                    "tool_name": cevent.tool_name, "tool_server": cevent.tool_server,
                                    "input_params": cevent.input, "status": "running",
                                })
                            elif isinstance(cevent, ToolInvocationCompleted):
                                for ev in compaction_events:
                                    if ev.get("kind") == "tool" and ev.get("tool_id") == cevent.tool_use_id:
                                        ev["is_error"] = cevent.is_error
                                        ev["status"] = cevent.status
                                        ev["output_result"] = str(cevent.result)
                                        ev["duration_ms"] = cevent.duration_ms
                                        break
                            elif isinstance(cevent, AgentCompleted):
                                compaction_usage = cevent.usage

                        # Finalize compaction turn
                        await orchestrator.finalize_turn(
                            conversation_id=str(conversation_id),
                            events_ordered=compaction_events,
                            agent_native_session_id=compaction_session_id,
                            input_tokens=compaction_usage.get("input_tokens", 0),
                            output_tokens=compaction_usage.get("output_tokens", 0),
                            cost_usd=compaction_usage.get("cost_usd", 0.0),
                        )

                        # Extract summary from compaction events (the text response)
                        summary_text = " ".join(
                            ev["content"] for ev in compaction_events if ev["kind"] == "text"
                        ).strip()
                        if not summary_text:
                            summary_text = "Session compacted due to context limit."

                        # Rotate the agent session (same conversation, fresh agent)
                        await active_conversation_service.rotate_session(
                            gen_db, conv_fresh, summary_text,
                        )
                        await gen_db.commit()

                        yield {
                            "event": "rotation_complete",
                            "data": json.dumps({"conversation_id": str(conversation_id)}),
                        }

            except Exception as e:
                logger.exception("chat_turn_generator_failed")
                # If turn not finalized yet (error occurred before AgentCompleted/AgentError), persist the error
                if not turn_finalized:
                    try:
                        await orchestrator.finalize_turn(
                            conversation_id=str(conversation_id),
                            events_ordered=events_ordered,
                            agent_native_session_id=agent_native_session_id,
                            input_tokens=0,
                            output_tokens=0,
                            cost_usd=0.0,
                            error_message=str(e),
                            error_type="SystemError",
                        )
                    except Exception:
                        logger.exception("failed_to_finalize_error_turn")
                yield {"event": "error", "data": json.dumps({"message": str(e)})}

    return EventSourceResponse(event_generator(), ping=15)


from percona.defaults import DEFAULT_COMPACT_PROMPT


async def _get_compact_prompt(db: AsyncSession, user_id: uuid.UUID) -> str:
    """Get the compact prompt from ProjectSettings, or use the default."""
    from percona.models.integrations import ProjectSettings
    result = await db.execute(
        select(ProjectSettings).where(ProjectSettings.user_id == user_id)
    )
    ps = result.scalar_one_or_none()
    return (ps.compact_prompt if ps and ps.compact_prompt else None) or DEFAULT_COMPACT_PROMPT


@router.post("/active/compact")
async def trigger_compact(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """Manually trigger a compact & rotate on the active conversation.

    Sends a compaction prompt to the agent, saves the summary, archives the
    current conversation, and creates a new one. Returns SSE stream.
    """
    conversation = await active_conversation_service.get_or_create_active_conversation(db, user_id)
    await db.commit()
    conversation_id = conversation.id

    async def event_generator():
        async with async_session_factory() as gen_db:
            orchestrator = ChatOrchestrator(gen_db)
            compaction_prompt = await _get_compact_prompt(gen_db, user_id)

            yield {"event": "rotation_starting", "data": json.dumps({})}

            compaction_events: list[dict] = []
            compaction_usage = {}
            compaction_session_id = None

            async for cevent in orchestrator.run_chat_turn(str(conversation_id), compaction_prompt):
                if isinstance(cevent, AgentStarted):
                    if cevent.session_id and cevent.session_id != str(conversation_id):
                        compaction_session_id = cevent.session_id
                    continue
                elif isinstance(cevent, TextDelta):
                    if compaction_events and compaction_events[-1]["kind"] == "text":
                        compaction_events[-1]["content"] += cevent.text
                    else:
                        compaction_events.append({"kind": "text", "content": cevent.text})
                elif isinstance(cevent, ToolInvocationStarted):
                    compaction_events.append({
                        "kind": "tool", "tool_id": cevent.tool_use_id,
                        "tool_name": cevent.tool_name, "tool_server": cevent.tool_server,
                        "input_params": cevent.input, "status": "running",
                    })
                elif isinstance(cevent, ToolInvocationCompleted):
                    for ev in compaction_events:
                        if ev.get("kind") == "tool" and ev.get("tool_id") == cevent.tool_use_id:
                            ev["is_error"] = cevent.is_error
                            ev["status"] = cevent.status
                            ev["output_result"] = str(cevent.result)
                            ev["duration_ms"] = cevent.duration_ms
                            break
                elif isinstance(cevent, AgentCompleted):
                    compaction_usage = cevent.usage

                yield domain_event_to_sse(cevent)

            await orchestrator.finalize_turn(
                conversation_id=str(conversation_id),
                events_ordered=compaction_events,
                agent_native_session_id=compaction_session_id,
                input_tokens=compaction_usage.get("input_tokens", 0),
                output_tokens=compaction_usage.get("output_tokens", 0),
                cost_usd=compaction_usage.get("cost_usd", 0.0),
                context_window=compaction_usage.get("context_window"),
                tokens_remaining_pct=compaction_usage.get("tokens_remaining_pct"),
            )

            summary_text = " ".join(
                ev["content"] for ev in compaction_events if ev["kind"] == "text"
            ).strip()
            if not summary_text:
                summary_text = "Session compacted manually."

            # Reload conversation for rotate_session
            conv_result = await gen_db.execute(
                select(Conversation).where(Conversation.id == conversation_id)
            )
            conv_fresh = conv_result.scalar_one()
            await active_conversation_service.rotate_session(
                gen_db, conv_fresh, summary_text,
            )
            await gen_db.commit()

            yield {
                "event": "rotation_complete",
                "data": json.dumps({"conversation_id": str(conversation_id)}),
            }

    return EventSourceResponse(event_generator(), ping=15)


@router.post("/{conversation_id}/cancel", status_code=204)
async def cancel_turn(
    conversation_id: uuid.UUID,
    user_id: uuid.UUID = Depends(get_user_id_dep),
    db: AsyncSession = Depends(get_db),
):
    """Kill the currently running agent subprocess for this conversation."""
    # Verify ownership
    stmt = select(Conversation.id).where(Conversation.id == conversation_id, Conversation.user_id == user_id)
    result = await db.execute(stmt)
    if not result.scalar_one_or_none():
        raise HTTPException(404, "Conversation not found")

    from percona.services.worker.chat_orchestrator import _active_processes
    process = _active_processes.get(str(conversation_id))
    if process and process.returncode is None:
        process.kill()
        logger.info("chat_turn_cancelled conversation_id=%s", conversation_id)


@router.post("/{conversation_id}/artifacts", response_model=ArtifactOut, status_code=201)
async def create_conversation_artifact(
    conversation_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """Export the conversation workspace directory as a downloadable tar.gz artifact."""
    result = await db.execute(
        select(Conversation).where(Conversation.id == conversation_id, Conversation.user_id == user_id)
    )
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    workspace_path = f"{settings.workspace_base_path}/chat-{conversation_id}"
    try:
        artifact = await artifact_service.create_artifact_from_workspace(
            db, user_id, workspace_path,
            source_type=ArtifactSourceType.CONVERSATION,
            conversation_id=conversation.id,
            trigger=ArtifactTrigger.MANUAL,
        )
        await db.commit()
        logger.info("conversation_artifact_created conversation_id=%s artifact_id=%s", conversation_id, artifact.id)
        return artifact
    except ValueError as e:
        raise HTTPException(409, str(e))


@router.get("/{conversation_id}/export")
async def export_conversation(
    conversation_id: uuid.UUID,
    format: str = Query("md", pattern="^(md|pdf)$"),
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    """Export conversation as Markdown or PDF."""
    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation_id)
        .where(Conversation.user_id == user_id)
        .options(
            selectinload(Conversation.messages),
            selectinload(Conversation.tool_calls),
            selectinload(Conversation.mcp_servers),
        )
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    # Build effective system prompt for export
    effective_prompt = await _build_effective_prompt(db, conversation)
    md = _render_conversation_md(conversation, effective_system_prompt=effective_prompt)

    if format == "pdf":
        from weasyprint import HTML
        from percona.services.report_service import markdown_to_styled_html
        html_doc = markdown_to_styled_html(md, title=conversation.title or "Conversation Export")
        pdf_bytes = HTML(string=html_doc, base_url="").write_pdf()
        filename = f"conversation-{conversation_id}.pdf"
        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    filename = f"conversation-{conversation_id}.md"
    return Response(
        content=md,
        media_type="text/markdown",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


async def _build_effective_prompt(db, conversation: Conversation) -> str:
    """Build the effective system prompt for export (same logic as chat_orchestrator)."""
    from percona.services.worker.context_builder import ContextBuilder

    ctx = ContextBuilder(db)
    global_prefix = await ctx._fetch_global_system_prompt(user_id=conversation.user_id)
    conversation_context = (
        f"## Session Context\n"
        f"You are running in a chat session. Your conversation_id is: {conversation.id}\n"
        f"There is no task session_id in chat mode — session_id is optional for all Percona MCP tools.\n\n"
    )
    mcp_servers = [
        {"slug": s.slug, "command": s.command, "args": s.args or [], "env": s.env or {},
         "transport": s.transport, "url": s.url,
         "user_id": str(s.user_id) if s.user_id else None}
        for s in conversation.mcp_servers if s.enabled
    ]
    prc = conversation.pre_run_context or {"inject_skills": True, "injections": []}
    suffix = await ctx._build_pre_run_suffix(prc, mcp_servers, conversation=conversation)

    return global_prefix + conversation_context + (conversation.system_prompt or "") + suffix


def _render_conversation_md(conversation: Conversation, *, effective_system_prompt: str = "") -> str:
    """Render a conversation to Markdown for export."""
    from datetime import datetime
    lines = [
        f"# {conversation.title}",
        f"",
        f"**Agent**: {conversation.agent_type.value}  ",
        f"**Date**: {conversation.created_at.strftime('%Y-%m-%d %H:%M UTC')}  ",
        f"**Tokens**: {conversation.total_input_tokens:,} in / {conversation.total_output_tokens:,} out",
        f"",
        "---",
        "",
    ]

    if effective_system_prompt:
        lines += [
            "## System Prompt",
            "",
            "```",
            effective_system_prompt.strip(),
            "```",
            "",
            "---",
            "",
        ]

    import json

    # Build interleaved timeline sorted by sequence (same approach as session export)
    timeline: list[tuple[int, str, object]] = []
    for m in conversation.messages:
        if m.role == MessageRole.SYSTEM:
            continue
        timeline.append((m.sequence, "message", m))
    for tc in conversation.tool_calls:
        timeline.append((tc.sequence, "tool_call", tc))
    timeline.sort(key=lambda x: x[0])

    for _seq, kind, item in timeline:
        if kind == "message":
            role_label = "User" if item.role == MessageRole.USER else "Assistant"
            lines += ["", f"**{role_label}**", "", item.content, ""]
        elif kind == "tool_call":
            status_icon = "\u2705" if item.status.value == "success" else "\u274c"
            server = f" ({item.tool_server})" if item.tool_server else ""
            duration = f" — {item.duration_ms}ms" if item.duration_ms else ""
            lines.append(f"#### {status_icon} `{item.tool_name}`{server}{duration}")
            lines.append("")
            if item.input_params:
                try:
                    input_str = json.dumps(item.input_params, indent=2, default=str)
                except (TypeError, ValueError):
                    input_str = str(item.input_params)
                lines += ["**Input:**", "", "```json", input_str, "```", ""]
            if item.output_result:
                lines += ["**Output:**", "", "```", item.output_result, "```", ""]

    return "\n".join(lines)


# --- Answer Submission Endpoint (for ask_user tool) ---

class AnswerSubmission(BaseModel):
    question_id: str
    answer: str


def _get_answer_redis() -> aioredis.Redis:
    """Reuse the same Redis pool as ask_user tool for answer coordination."""
    from percona.mcp_internal.tools.ask_user import _get_redis
    return _get_redis()


@router.post("/{conversation_id}/answer")
async def submit_answer(
    conversation_id: uuid.UUID,
    body: AnswerSubmission,
    user_id: uuid.UUID = Depends(get_user_id_dep),
    db: AsyncSession = Depends(get_db),
):
    """Submit the user's answer to a pending ask_user question.

    The ask_user MCP tool polls Redis for the answer. This endpoint
    stores the answer in Redis so the tool can pick it up and resume.
    """
    # Verify the conversation belongs to this user
    stmt = select(Conversation).where(
        Conversation.id == conversation_id,
        Conversation.user_id == user_id,
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    redis = _get_answer_redis()
    answer_key = f"ask_user:answer:{conversation_id}:{body.question_id}"
    question_key = f"ask_user:question:{conversation_id}:{body.question_id}"

    # Verify the question exists (hasn't timed out)
    question_data = await redis.get(question_key)
    if not question_data:
        raise HTTPException(400, "Question not found or has timed out")

    # Store the answer — the polling tool picks it up
    # Push answer to list — wait_for_answer uses BLPOP for efficient blocking wait
    await redis.lpush(answer_key, body.answer)
    await redis.expire(answer_key, 120)  # TTL cleanup in case tool already timed out

    logger.info(
        "answer_submitted conversation=%s question_id=%s answer=%s",
        conversation_id, body.question_id, body.answer[:100],
    )

    return {"status": "ok", "message": "Answer submitted"}
