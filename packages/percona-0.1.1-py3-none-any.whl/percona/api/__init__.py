from fastapi import APIRouter

from percona.api.chat import router as chat_router
from percona.api.files import router as files_router
from percona.api.memory_files import router as memory_files_router
from percona.api.connected_accounts import router as connected_accounts_router
from percona.api.reminders import router as reminders_router
from percona.api.todos import router as todos_router
from percona.api.dashboard import router as dashboard_router
from percona.api.mcp_servers import router as mcp_servers_router
from percona.api.notification_channels import router as notification_channels_router
from percona.api.notification_logs import router as notification_logs_router
from percona.api.oauth import router as oauth_router
from percona.api.reports import router as reports_router
from percona.api.sessions import router as sessions_router
from percona.api.settings import router as settings_router
from percona.api.skills import router as skills_router
from percona.api.task_templates import router as task_templates_router
from percona.api.tasks import router as tasks_router
from percona.api.memories import router as memories_router
from percona.api.telegram import router as telegram_router
from percona.api.slack import router as slack_router
from percona.api.voice import router as voice_router
from percona.api.auth import router as auth_router
from percona.api.users import router as users_router
from percona.api.projects import router as projects_router  # backward compat
from percona.api.artifacts import router as artifacts_router
from percona.api.secrets import router as secrets_router
from percona.api.collections import router as collections_router
from percona.api.approvals import router as approvals_router
from percona.api.whatsapp import router as whatsapp_router
from percona.api.ws import router as ws_router

api_router = APIRouter(prefix="/api")

api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(projects_router)  # backward compat: keeps /api/projects working
api_router.include_router(dashboard_router)
api_router.include_router(task_templates_router)
api_router.include_router(tasks_router)
api_router.include_router(sessions_router)
api_router.include_router(reports_router)
api_router.include_router(skills_router)
api_router.include_router(notification_logs_router)
api_router.include_router(mcp_servers_router)
api_router.include_router(notification_channels_router)
api_router.include_router(settings_router)
api_router.include_router(ws_router)
api_router.include_router(chat_router)
api_router.include_router(oauth_router)
api_router.include_router(connected_accounts_router)
api_router.include_router(reminders_router)
api_router.include_router(todos_router)
api_router.include_router(files_router)
api_router.include_router(memory_files_router)
api_router.include_router(memories_router)
api_router.include_router(voice_router)
api_router.include_router(telegram_router)
api_router.include_router(slack_router)
api_router.include_router(collections_router)
api_router.include_router(artifacts_router)
api_router.include_router(secrets_router)
api_router.include_router(approvals_router)
api_router.include_router(whatsapp_router)
