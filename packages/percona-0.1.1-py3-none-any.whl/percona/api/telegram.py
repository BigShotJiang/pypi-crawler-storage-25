"""Telegram webhook endpoint — receives updates from Telegram via Cloudflare tunnel.

Always returns HTTP 200 to prevent Telegram retry storms.
Validates X-Telegram-Bot-Api-Secret-Token on every request; rejects (logs + 200) if
no secret is configured at all. Deduplicates updates via Redis (TTL 600 s).
Processing is fire-and-forget: errors are logged, never surfaced to Telegram.
"""
import json
import logging
import secrets

import redis.asyncio as aioredis
from fastapi import APIRouter, Request

from percona.config import settings

router = APIRouter(prefix="/telegram", tags=["telegram"])
logger = logging.getLogger(__name__)


@router.post("/webhook/{account_id}")
async def telegram_webhook(account_id: str, request: Request) -> dict:
    """
    Receives Telegram Bot API updates pushed via webhook for a specific account.

    Security model:
    - Returns HTTP 200 unconditionally (prevents Telegram retry storms).
    - Rejects requests when no secret is configured (misconfiguration guard).
    - Validates X-Telegram-Bot-Api-Secret-Token with timing-safe comparison.
    - Deduplicates update_id via Redis to handle Telegram retries gracefully.
    """
    ref = secrets.token_hex(4)

    try:
        # Reject entirely if secret is not configured — misconfiguration guard
        if not settings.telegram_webhook_secret:
            logger.warning("telegram_webhook_no_secret_configured ref=%s account_id=%s", ref, account_id)
            return {"ok": True}

        # Validate secret token (timing-safe comparison)
        secret_header = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if not secrets.compare_digest(secret_header, settings.telegram_webhook_secret):
            logger.warning("telegram_webhook_invalid_secret ref=%s account_id=%s", ref, account_id)
            return {"ok": True}

        body = await request.body()
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            logger.warning("telegram_webhook_invalid_json ref=%s account_id=%s", ref, account_id)
            return {"ok": True}

        # Deduplicate by update_id to handle Telegram retries
        update_id = data.get("update_id")
        if update_id is not None:
            try:
                r = aioredis.from_url(settings.redis_url, decode_responses=True)
                async with r:
                    dedup_key = f"tg:seen:{update_id}"
                    was_set = await r.set(dedup_key, "1", nx=True, ex=600)
                if not was_set:
                    logger.debug("telegram_webhook_duplicate_update ref=%s update_id=%s", ref, update_id)
                    return {"ok": True}
            except Exception as redis_exc:
                logger.warning(
                    "telegram_webhook_dedup_failed ref=%s update_id=%s error=%s",
                    ref, update_id, redis_exc,
                )

        chat = (data.get("message") or data.get("callback_query", {}).get("message") or {}).get("chat", {})
        chat_id = chat.get("id")
        message_type = (
            "callback_query" if "callback_query" in data else
            "message" if "message" in data else
            "unknown"
        )
        msg_text = (data.get("message") or {}).get("text", "")
        cb_data = (data.get("callback_query") or {}).get("data", "")
        logger.info(
            "telegram_webhook_received ref=%s update_id=%s account_id=%s chat_id=%s type=%s text=%s cb_data=%s",
            ref, update_id, account_id, chat_id, message_type,
            msg_text[:80] if msg_text else "",
            cb_data[:60] if cb_data else "",
        )

        # Access adapter via app state (set in main.py lifespan after channel_manager.start())
        channel_manager = getattr(request.app.state, "channel_manager", None)
        if channel_manager is None:
            logger.warning("telegram_webhook_channel_manager_not_ready ref=%s account_id=%s", ref, account_id)
            return {"ok": True}

        adapter = channel_manager.get_adapter("telegram")
        if adapter:
            try:
                await adapter.process_update(account_id, data)
            except Exception as exc:
                logger.exception(
                    "telegram_webhook_process_update_failed ref=%s account_id=%s update_id=%s error=%s",
                    ref, account_id, update_id, exc,
                )
        else:
            logger.warning("telegram_adapter_not_found ref=%s account_id=%s", ref, account_id)

    except Exception:
        logger.exception("telegram_webhook_processing_error ref=%s account_id=%s", ref, account_id)

    return {"ok": True}
