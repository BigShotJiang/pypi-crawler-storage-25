import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import require_role
from percona.database import get_db
from percona.models.users import User
from percona.schemas.projects import ProjectCreate, ProjectOut, ProjectUpdate

router = APIRouter(prefix="/projects", tags=["projects"])
logger = logging.getLogger(__name__)


@router.get("", response_model=list[ProjectOut], dependencies=[Depends(require_role("admin"))])
async def list_projects(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).order_by(User.name))
    return result.scalars().all()


@router.post("", response_model=ProjectOut, status_code=201, dependencies=[Depends(require_role("admin"))])
async def create_project(data: ProjectCreate, db: AsyncSession = Depends(get_db)):
    project = User(
        name=data.name,
        slug=data.slug,
        color=data.color,
        description=data.description,
    )
    db.add(project)
    await db.flush()

    # Auto-create default ProjectSettings for the new project
    from percona.services.project_settings_service import get_or_create_default_settings
    await get_or_create_default_settings(db, project.id)

    # Seed MCP servers and task templates for the new project
    from percona.seed import seed_mcp_servers_for_project, seed_task_templates_for_project
    await seed_mcp_servers_for_project(db, project.id)
    await seed_task_templates_for_project(db, project.id)
    await db.commit()

    await db.refresh(project)
    logger.info("project_created id=%s name=%s with default settings, mcp_servers, and task_templates", project.id, project.name)
    return project


@router.get("/{user_id}", response_model=ProjectOut, dependencies=[Depends(require_role("admin"))])
async def get_project(user_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(404, "User not found")
    return project


@router.patch("/{user_id}", response_model=ProjectOut, dependencies=[Depends(require_role("admin"))])
async def update_project(user_id: uuid.UUID, data: ProjectUpdate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(404, "User not found")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(project, field, value)
    await db.flush()
    await db.refresh(project)
    return project


@router.delete("/{user_id}", status_code=204, dependencies=[Depends(require_role("admin"))])
async def delete_project(user_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(404, "User not found")
    await db.delete(project)
    logger.info("project_deleted id=%s", user_id)
