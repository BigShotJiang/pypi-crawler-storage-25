import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_user_id_dep
from percona.database import get_db
from percona.schemas.artifacts import ArtifactListResponse, ArtifactOut
from percona.services import artifact_service

router = APIRouter(prefix="/artifacts", tags=["artifacts"])


@router.get("", response_model=ArtifactListResponse)
async def list_artifacts(
    session_id: uuid.UUID | None = None,
    conversation_id: uuid.UUID | None = None,
    limit: int = Query(50, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    items, total = await artifact_service.list_artifacts(
        db, user_id, session_id=session_id, conversation_id=conversation_id, limit=limit, offset=offset
    )
    return {"items": items, "total": total}


@router.get("/{artifact_id}", response_model=ArtifactOut)
async def get_artifact(
    artifact_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    artifact = await artifact_service.get_artifact(db, user_id, artifact_id)
    if not artifact:
        raise HTTPException(404, "Artifact not found")
    return artifact


@router.delete("/{artifact_id}", status_code=204)
async def delete_artifact(
    artifact_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    deleted = await artifact_service.delete_artifact(db, user_id, artifact_id)
    if not deleted:
        raise HTTPException(404, "Artifact not found")
    await db.commit()
