import logging
import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_user_id_dep
from percona.database import get_db
from percona.schemas import DashboardStats
from percona.services import dashboard_service

router = APIRouter(prefix="/dashboard", tags=["dashboard"])
logger = logging.getLogger(__name__)


@router.get("/stats", response_model=DashboardStats)
async def get_dashboard_stats(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    logger.debug("get_dashboard_stats")
    return await dashboard_service.get_dashboard_stats(db, user_id)
