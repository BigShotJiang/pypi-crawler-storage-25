import logging
import uuid

from fastapi import APIRouter, Depends
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_user_id_dep
from percona.database import get_db
from percona.models import TaskTemplate
from percona.schemas import TaskTemplateOut

router = APIRouter(prefix="/task-templates", tags=["task-templates"])
logger = logging.getLogger(__name__)


@router.get("", response_model=list[TaskTemplateOut])
async def list_templates(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
):
    logger.debug("list_task_templates")
    stmt = (
        select(TaskTemplate)
        .where(or_(TaskTemplate.user_id == user_id, TaskTemplate.user_id.is_(None)))
        .order_by(TaskTemplate.name)
    )
    result = await db.execute(stmt)
    return result.scalars().all()
