"""User-scoped settings API routes for branding, theme, SMTP, and system prompt configuration.

All settings are scoped to the authenticated user via JWT.
"""

import logging
import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from percona.api.deps import get_user_id_dep
from percona.database import get_db
from percona.schemas.integrations import ProjectSettingOut, ProjectSettingUpdate
from percona.services.project_settings_service import (
    get_or_create_default_settings,
    update_project_settings,
)

router = APIRouter(prefix="/project-settings", tags=["project-settings"])
logger = logging.getLogger(__name__)


@router.get("", response_model=ProjectSettingOut)
async def get_project_settings(
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
) -> ProjectSettingOut:
    """Get project settings for the current project.

    Returns settings with all branding, theme, SMTP, and system prompt config.
    If settings don't exist, creates them with defaults.

    Requires: valid JWT (Authorization: Bearer <token>)
    """
    logger.debug("get_project_settings user_id=%s", user_id)

    settings = await get_or_create_default_settings(db, user_id)
    await db.commit()
    return settings


@router.put("", response_model=ProjectSettingOut)
async def update_project_settings_endpoint(
    data: ProjectSettingUpdate,
    db: AsyncSession = Depends(get_db),
    user_id: uuid.UUID = Depends(get_user_id_dep),
) -> ProjectSettingOut:
    """Update project settings (upsert operation).

    Accepts partial updates - only provided fields are changed.
    Automatically creates with defaults if settings don't exist.

    Requires: valid JWT (Authorization: Bearer <token>)
    """
    logger.info("update_project_settings user_id=%s", user_id)

    settings = await update_project_settings(db, user_id, data)
    await db.commit()
    return settings
