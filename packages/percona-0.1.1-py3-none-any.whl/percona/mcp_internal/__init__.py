import logging

from fastmcp import FastMCP

logger = logging.getLogger(__name__)

_CORE_INSTRUCTIONS = """Percona Core MCP Server — personal AI assistant tools.

## Productivity Tools

**Todos**
- **create_todo**: Create a new todo/task item
- **search_todos**: Search/list todos with filters (status, priority, context, semantic search)
- **get_todo**: Get full todo details
- **update_todo**: Update a todo
- **delete_todo**: Delete a todo
- **complete_todo**: Mark a todo as completed

**Collections** — Dynamic structured data (contacts, books, recipes, inventory, or ANY custom schema)
- **list_collections**: List all collections
- **get_collection**: Get a collection with its field schema (use slug for natural lookups)
- **create_collection**: Create a new collection with optional fields
- **update_collection**: Update collection metadata
- **delete_collection**: Delete a collection and all its items
- **add_collection_field**: Add a field to a collection schema
- **delete_collection_field**: Remove a field from a collection
- **add_collection_item**: Add a record to a collection
- **get_collection_item**: Get a single item by ID
- **list_collection_items**: List items in a collection
- **update_collection_item**: Update an item's data/status/tags
- **delete_collection_item**: Delete an item
- **search_collection_items**: Full-text search across item data
- **filter_collection_items**: Filter items by field values (e.g. category:Work,rating:gte:4)
- **collection_stats**: Get aggregation stats (counts, min/max/avg)

## Memory
- **create_memory**: Store a structured fact keyed to an entity (upserts)
- **search_memories**: Search agent memories (semantic + BM25)
- **get_memory**: Get memory details
- **update_memory**: Update a memory
- **delete_memory**: Delete a memory

## Interactive
- **ask_user**: Ask the user a question with clickable option buttons. ALWAYS prefer this over plain-text questions.
- **wait_for_answer**: Wait for user's response to a question asked via ask_user.

## Other Tools
- **create_report**: Generate a Markdown report summarizing your work for this session
- **create_secret** / **search_secrets** / **get_secret** / **get_secret_by_name** / **update_secret** / **delete_secret**: Encrypted secrets storage
- **create_skill** / **search_skills** / **get_skill** / **update_skill** / **delete_skill**: Reusable skills/runbooks
- **upload_file** / **delete_file**: Upload files to S3 and get public URLs
- **search_sessions** / **get_session**: Read past agent task sessions
- **search_conversations** / **get_conversation**: Read past chat conversations
- **compact_session**: Save a conversation summary for session rotation

Your session_id is embedded in the connection URL and used automatically.
"""

_NOTIFY_INSTRUCTIONS = """Percona Notify MCP Server.

Use these tools to send notifications and manage reminders during your session:

**Notifications**
- **send_slack_notification**: Send a Slack notification to the configured channel
- **send_email_notification**: Send an email notification to configured recipients
- **send_pushover_push**: Send a Pushover push notification
- **send_telegram_notification**: Send a Telegram notification to configured channels
- **send_whatsapp_notification**: Send a WhatsApp notification to configured numbers

**Reminders**
- **create_reminder**: Create a new reminder (immediate or scheduled, via email/slack/pushover)
- **search_reminders**: List reminders with status/date filters
- **get_reminder**: Get full reminder details
- **update_reminder**: Update a pending reminder
- **cancel_reminder**: Cancel a pending reminder
- **send_reminder_now**: Send a pending reminder immediately

Your session_id is embedded in the connection URL and used automatically.
"""

_TASKS_INSTRUCTIONS = """Percona Task Automation MCP Server.

Use these tools to manage automation tasks from a chat conversation or external channel:

- **create_task**: Create a new automation task (name + prompt required; optionally set agent_type, cron_schedule, system_prompt)
- **search_tasks**: List all tasks with their status and schedule
- **get_task**: Get full details of a specific task
- **update_task**: Update any field of an existing task
- **delete_task**: Delete a task permanently
- **trigger_task**: Manually run a task immediately (returns a session_id to track progress)
- **update_task_memory**: Replace the task's accumulated memory content
"""

_GOOGLE_INSTRUCTIONS = """Percona Google MCP Server.

Use these tools to interact with Google Workspace during your session:

- **gmail_list_accounts**: List all connected Gmail accounts (call this first to discover available accounts)
- **gmail_list_emails**: List emails from a connected Gmail account (supports Gmail search queries)
- **gmail_read_email**: Read the full content of a Gmail message by ID
- **gmail_get_thread**: Read all messages in a Gmail thread by thread ID
- **calendar_list_calendars**: List all calendars for connected Google account
- **calendar_list_events**: List events in a calendar with optional date filtering
- **calendar_create_event**: Create a new event in a calendar
- **calendar_update_event**: Update an existing event
- **calendar_delete_event**: Delete an event
- **calendar_get_event**: Get full details of a specific event
- **drive_list_files**: List files/folders in Google Drive
- **drive_get_file**: Get file metadata
- **drive_download_file**: Download/read file content
- **drive_create_file**: Create a new file in Google Drive from string content or a local file_path (use share_publicly=True to get a public URL)
- **drive_upload_file**: Update file content in Google Drive
- **drive_delete_file**: Delete a file from Google Drive
- **drive_share_file**: Make an existing file publicly accessible and get a shareable URL
Your session_id is embedded in the connection URL and used automatically.
"""


def create_core_server() -> FastMCP:
    mcp = FastMCP("percona", instructions=_CORE_INSTRUCTIONS)

    from percona.mcp_internal.tools import (
        approvals, ask_user, collections, conversations, files, memory, reports, secrets, sessions, skills, todos
    )

    reports.register(mcp)
    secrets.register(mcp)
    skills.register(mcp)
    todos.register(mcp)
    collections.register(mcp)
    files.register(mcp)
    memory.register(mcp)
    sessions.register(mcp)
    conversations.register(mcp)
    approvals.register(mcp)
    ask_user.register(mcp)

    logger.info("mcp_core_server_created")
    return mcp


def create_notify_server() -> FastMCP:
    mcp = FastMCP("percona-notify", instructions=_NOTIFY_INSTRUCTIONS)

    from percona.mcp_internal.tools import notifications, reminders

    notifications.register(mcp)
    reminders.register(mcp)

    logger.info("mcp_notify_server_created")
    return mcp


_SLACK_INSTRUCTIONS = """Percona Slack MCP Server.

Use these tools to interact with connected Slack workspaces during your session:

- **slack_list_workspaces**: List all connected Slack workspaces (call this first to discover available workspaces)
- **slack_list_channels**: List channels the bot can see in a workspace
- **slack_read_channel_history**: Read message history from a Slack channel
- **slack_read_thread**: Read all replies in a Slack thread
- **slack_get_user_info**: Get profile information for a Slack user by their ID
Your session_id is embedded in the connection URL and used automatically.
"""

_WHATSAPP_INSTRUCTIONS = """Percona WhatsApp MCP Server.

Use these tools to read from the connected WhatsApp account:

- **list_whatsapp_groups**: List all groups the paired device has joined (JID, name, participant count)
- **list_whatsapp_contacts**: List contacts/groups that have messaged the bot (from stored conversations)
- **read_whatsapp_messages**: Read stored message history for a contact or group by JID
Your session_id is embedded in the connection URL and used automatically.
"""


def create_slack_server() -> FastMCP:
    mcp = FastMCP("percona-slack", instructions=_SLACK_INSTRUCTIONS)

    from percona.mcp_internal.tools import slack

    slack.register(mcp)

    logger.info("mcp_slack_server_created")
    return mcp


def create_google_server() -> FastMCP:
    mcp = FastMCP("percona-google", instructions=_GOOGLE_INSTRUCTIONS)

    from percona.mcp_internal.tools import calendar, drive, gmail

    gmail.register(mcp)
    calendar.register(mcp)
    drive.register(mcp)

    logger.info("mcp_google_server_created")
    return mcp


def create_whatsapp_server() -> FastMCP:
    mcp = FastMCP("percona-whatsapp", instructions=_WHATSAPP_INSTRUCTIONS)

    from percona.mcp_internal.tools import whatsapp

    whatsapp.register(mcp)

    logger.info("mcp_whatsapp_server_created")
    return mcp


_MICROSOFT_INSTRUCTIONS = """Percona Microsoft MCP Server.

Use these tools to interact with Microsoft 365 during your session:

- **outlook_list_accounts**: List all connected Microsoft accounts (call this first to discover available accounts)
- **outlook_list_emails**: List emails from Outlook (supports Microsoft Search queries)
- **outlook_read_email**: Read the full content of an Outlook message by ID
- **outlook_get_thread**: Read all messages in an Outlook conversation thread
- **outlook_send_email**: Send an email via Outlook
- **outlook_list_calendars**: List all Outlook calendars
- **outlook_list_events**: List calendar events within a date range
- **outlook_create_event**: Create a new calendar event
- **outlook_update_event**: Update an existing event
- **outlook_delete_event**: Delete a calendar event
- **outlook_get_event**: Get full details of a specific event
- **onedrive_list_files**: List files/folders in OneDrive
- **onedrive_get_file**: Get file metadata
- **onedrive_download_file**: Download/read file content
- **onedrive_upload_file**: Upload a file to OneDrive
- **onedrive_create_folder**: Create a new folder
- **onedrive_share_file**: Create a sharing link for a file
- **onedrive_delete_file**: Delete a file or folder
- **todo_list_lists**: List all To Do task lists
- **todo_list_tasks**: List tasks in a To Do list
- **todo_create_task**: Create a new To Do task
- **todo_update_task**: Update a To Do task
- **todo_complete_task**: Mark a To Do task as completed
- **contacts_list**: List Outlook contacts
- **contacts_search**: Search contacts and people by name or email
- **contacts_get**: Get full details of a specific contact
- **onenote_list_notebooks**: List all OneNote notebooks
- **onenote_list_sections**: List sections within a notebook
- **onenote_list_pages**: List pages within a section
- **onenote_read_page**: Read the HTML content of a page
- **onenote_create_page**: Create a new page in a section
- **planner_list_plans**: List Planner plans
- **planner_list_tasks**: List tasks in a plan or assigned to the user
- **planner_create_task**: Create a new Planner task
- **planner_update_task**: Update a Planner task (title, progress, priority, due date)
- **teams_list_teams**: List Microsoft Teams the user is a member of
- **teams_list_channels**: List channels in a team
- **teams_read_messages**: Read recent messages from a channel
- **teams_send_message**: Send a message to a channel
- **teams_list_chats**: List recent 1:1 and group chats
- **sharepoint_list_sites**: List or search SharePoint sites
- **sharepoint_list_files**: List files in a SharePoint document library
- **sharepoint_download_file**: Download file content from SharePoint
- **sharepoint_upload_file**: Upload a file to SharePoint
- **excel_list_worksheets**: List worksheets in an Excel workbook
- **excel_read_range**: Read cell values from a worksheet
- **excel_write_range**: Write values to a cell range
- **excel_add_row**: Add a row to an Excel table
Your session_id is embedded in the connection URL and used automatically.
"""


def create_microsoft_server() -> FastMCP:
    mcp = FastMCP("percona-microsoft", instructions=_MICROSOFT_INSTRUCTIONS)

    from percona.mcp_internal.tools import (
        contacts, excel, microsoft_todo, onedrive, onenote, outlook_calendar, outlook_mail,
        planner, sharepoint, teams,
    )

    outlook_mail.register(mcp)
    outlook_calendar.register(mcp)
    onedrive.register(mcp)
    microsoft_todo.register(mcp)
    contacts.register(mcp)
    onenote.register(mcp)
    planner.register(mcp)
    teams.register(mcp)
    sharepoint.register(mcp)
    excel.register(mcp)

    logger.info("mcp_microsoft_server_created")
    return mcp


def create_tasks_server() -> FastMCP:
    mcp = FastMCP("percona-tasks", instructions=_TASKS_INSTRUCTIONS)

    from percona.mcp_internal.tools import task_automation

    task_automation.register(mcp)

    logger.info("mcp_tasks_server_created")
    return mcp


def create_mcp_server() -> FastMCP:
    mcp = create_core_server()

    from percona.mcp_internal.tools import calendar, drive, gmail, notifications, reminders

    notifications.register(mcp)
    reminders.register(mcp)
    gmail.register(mcp)
    calendar.register(mcp)
    drive.register(mcp)

    logger.info("mcp_internal_server_created tools=32")
    return mcp
