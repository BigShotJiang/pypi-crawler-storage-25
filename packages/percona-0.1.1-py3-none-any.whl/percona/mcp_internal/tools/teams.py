"""Microsoft Teams MCP tools — access teams, channels, chats, and messages via Microsoft Graph API."""

import json
import logging

from fastmcp import FastMCP

from percona.mcp_internal.tools._microsoft_graph import (
    graph_get,
    graph_post,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def teams_list_teams(
        account_id: str | None = None,
    ) -> str:
        """List Microsoft Teams the user is a member of.

        Args:
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            data = await graph_get(token, "/me/joinedTeams", {
                "$select": "id,displayName,description",
            })

            teams = [
                {
                    "id": t["id"],
                    "name": t.get("displayName"),
                    "description": t.get("description", ""),
                }
                for t in data.get("value", [])
            ]

            logger.info("teams_list_teams account=%s count=%d", email_addr, len(teams))
            return json.dumps({"account": email_addr, "teams": teams, "total": len(teams)})

        except Exception as e:
            logger.error("teams_list_teams_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def teams_list_channels(
        team_id: str,
        account_id: str | None = None,
    ) -> str:
        """List channels in a Microsoft Team.

        Args:
            team_id: Team ID from teams_list_teams.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            data = await graph_get(token, f"/teams/{team_id}/channels", {
                "$select": "id,displayName,description,membershipType",
            })

            channels = [
                {
                    "id": ch["id"],
                    "name": ch.get("displayName"),
                    "description": ch.get("description", ""),
                    "membership_type": ch.get("membershipType"),
                }
                for ch in data.get("value", [])
            ]

            logger.info("teams_list_channels account=%s team_id=%s count=%d", email_addr, team_id, len(channels))
            return json.dumps({"account": email_addr, "team_id": team_id, "channels": channels, "total": len(channels)})

        except Exception as e:
            logger.error("teams_list_channels_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def teams_read_messages(
        team_id: str,
        channel_id: str,
        max_results: int = 20,
        account_id: str | None = None,
    ) -> str:
        """Read recent messages from a Teams channel.

        Args:
            team_id: Team ID.
            channel_id: Channel ID from teams_list_channels.
            max_results: Max messages to return (1-50).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(50, max_results))
            data = await graph_get(token, f"/teams/{team_id}/channels/{channel_id}/messages", {
                "$top": str(max_results),
            })

            messages = []
            for msg in data.get("value", []):
                from_user = msg.get("from", {}).get("user", {})
                body = msg.get("body", {})
                messages.append({
                    "id": msg["id"],
                    "from": from_user.get("displayName", ""),
                    "from_email": from_user.get("email", ""),
                    "date": msg.get("createdDateTime"),
                    "content": body.get("content", "")[:8000],
                    "content_type": body.get("contentType", "text"),
                    "reply_count": len(msg.get("replies", [])),
                    "importance": msg.get("importance"),
                })

            logger.info("teams_read_messages account=%s channel=%s count=%d", email_addr, channel_id, len(messages))
            return json.dumps({
                "account": email_addr,
                "team_id": team_id,
                "channel_id": channel_id,
                "messages": messages,
                "total": len(messages),
            })

        except Exception as e:
            logger.error("teams_read_messages_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def teams_send_message(
        team_id: str,
        channel_id: str,
        content: str,
        account_id: str | None = None,
    ) -> str:
        """Send a message to a Teams channel.

        Args:
            team_id: Team ID.
            channel_id: Channel ID.
            content: Message content (plain text or HTML).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            result = await graph_post(token, f"/teams/{team_id}/channels/{channel_id}/messages", {
                "body": {
                    "content": content,
                },
            })

            logger.info("teams_send_message account=%s channel=%s", email_addr, channel_id)
            return json.dumps({
                "status": "sent",
                "id": result.get("id"),
                "channel_id": channel_id,
            })

        except Exception as e:
            logger.error("teams_send_message_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def teams_list_chats(
        max_results: int = 20,
        account_id: str | None = None,
    ) -> str:
        """List the user's recent 1:1 and group chats in Teams.

        Args:
            max_results: Max chats to return (1-50).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(50, max_results))
            data = await graph_get(token, "/me/chats", {
                "$top": str(max_results),
                "$select": "id,topic,chatType,createdDateTime,lastUpdatedDateTime",
                "$orderby": "lastUpdatedDateTime desc",
                "$expand": "members($select=displayName,email)",
            })

            chats = []
            for chat in data.get("value", []):
                members = [
                    {"name": m.get("displayName", ""), "email": m.get("email", "")}
                    for m in chat.get("members", [])
                ]
                chats.append({
                    "id": chat["id"],
                    "topic": chat.get("topic") or "(no topic)",
                    "chat_type": chat.get("chatType"),
                    "created": chat.get("createdDateTime"),
                    "last_updated": chat.get("lastUpdatedDateTime"),
                    "members": members,
                })

            logger.info("teams_list_chats account=%s count=%d", email_addr, len(chats))
            return json.dumps({"account": email_addr, "chats": chats, "total": len(chats)})

        except Exception as e:
            logger.error("teams_list_chats_error: %s", e)
            return json.dumps({"error": str(e)})
