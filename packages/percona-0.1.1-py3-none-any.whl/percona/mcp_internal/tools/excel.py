"""Excel MCP tools — read and write Excel workbooks via Microsoft Graph API.

Works with Excel files stored in OneDrive or SharePoint.
"""

import json
import logging

from fastmcp import FastMCP

from percona.mcp_internal.tools._microsoft_graph import (
    graph_get,
    graph_patch,
    graph_post,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def excel_list_worksheets(
        item_id: str,
        account_id: str | None = None,
    ) -> str:
        """List worksheets in an Excel workbook stored in OneDrive.

        Args:
            item_id: OneDrive item ID of the Excel file (from onedrive_list_files).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            data = await graph_get(token, f"/me/drive/items/{item_id}/workbook/worksheets", {
                "$select": "id,name,position,visibility",
            })

            sheets = [
                {
                    "id": ws["id"],
                    "name": ws.get("name"),
                    "position": ws.get("position"),
                    "visibility": ws.get("visibility"),
                }
                for ws in data.get("value", [])
            ]

            logger.info("excel_list_worksheets account=%s item_id=%s count=%d", email_addr, item_id, len(sheets))
            return json.dumps({"account": email_addr, "item_id": item_id, "worksheets": sheets, "total": len(sheets)})

        except Exception as e:
            logger.error("excel_list_worksheets_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def excel_read_range(
        item_id: str,
        sheet_name: str,
        range_address: str = "",
        account_id: str | None = None,
    ) -> str:
        """Read cell values from an Excel worksheet.

        Args:
            item_id: OneDrive item ID of the Excel file.
            sheet_name: Worksheet name (e.g. "Sheet1").
            range_address: Cell range in A1 notation (e.g. "A1:D10"). If empty, reads the used range.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            encoded_name = sheet_name.replace("'", "''")

            if range_address:
                path = f"/me/drive/items/{item_id}/workbook/worksheets('{encoded_name}')/range(address='{range_address}')"
            else:
                path = f"/me/drive/items/{item_id}/workbook/worksheets('{encoded_name}')/usedRange"

            data = await graph_get(token, path, {
                "$select": "address,values,numberFormat,rowCount,columnCount",
            })

            values = data.get("values", [])
            # Cap output to avoid huge responses
            max_rows = 500
            if len(values) > max_rows:
                values = values[:max_rows]
                truncated = True
            else:
                truncated = False

            result = {
                "account": email_addr,
                "item_id": item_id,
                "sheet": sheet_name,
                "address": data.get("address"),
                "rows": data.get("rowCount"),
                "columns": data.get("columnCount"),
                "values": values,
                "truncated": truncated,
            }

            logger.info("excel_read_range account=%s sheet=%s address=%s", email_addr, sheet_name, data.get("address"))
            return json.dumps(result)

        except Exception as e:
            logger.error("excel_read_range_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def excel_write_range(
        item_id: str,
        sheet_name: str,
        range_address: str,
        values: str,
        account_id: str | None = None,
    ) -> str:
        """Write values to a cell range in an Excel worksheet.

        Args:
            item_id: OneDrive item ID of the Excel file.
            sheet_name: Worksheet name (e.g. "Sheet1").
            range_address: Cell range in A1 notation (e.g. "A1:C3"). Must match the dimensions of values.
            values: JSON string of a 2D array — rows of columns. E.g. '[["Name","Age"],["Alice",30]]'.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            try:
                parsed_values = json.loads(values)
            except json.JSONDecodeError:
                return json.dumps({"error": "Invalid JSON for values. Must be a 2D array like [[\"a\",1],[\"b\",2]]"})

            if not isinstance(parsed_values, list) or not all(isinstance(row, list) for row in parsed_values):
                return json.dumps({"error": "values must be a 2D array (list of lists)"})

            encoded_name = sheet_name.replace("'", "''")
            path = f"/me/drive/items/{item_id}/workbook/worksheets('{encoded_name}')/range(address='{range_address}')"

            result = await graph_patch(token, path, {"values": parsed_values})

            logger.info("excel_write_range account=%s sheet=%s range=%s", email_addr, sheet_name, range_address)
            return json.dumps({
                "status": "written",
                "item_id": item_id,
                "sheet": sheet_name,
                "range": range_address,
                "rows_written": len(parsed_values),
            })

        except Exception as e:
            logger.error("excel_write_range_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def excel_add_row(
        item_id: str,
        sheet_name: str,
        table_name: str,
        values: str,
        account_id: str | None = None,
    ) -> str:
        """Add a row to an Excel table.

        Args:
            item_id: OneDrive item ID of the Excel file.
            sheet_name: Worksheet name containing the table.
            table_name: Table name or index (e.g. "Table1").
            values: JSON string of a 1D array — one value per column. E.g. '["Alice", 30, "Engineering"]'.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            try:
                parsed_values = json.loads(values)
            except json.JSONDecodeError:
                return json.dumps({"error": "Invalid JSON for values. Must be a 1D array like [\"a\", 1, \"b\"]"})

            if not isinstance(parsed_values, list):
                return json.dumps({"error": "values must be a 1D array"})

            encoded_name = sheet_name.replace("'", "''")
            path = f"/me/drive/items/{item_id}/workbook/worksheets('{encoded_name}')/tables('{table_name}')/rows/add"

            result = await graph_post(token, path, {
                "values": [parsed_values],
            })

            logger.info("excel_add_row account=%s table=%s", email_addr, table_name)
            return json.dumps({
                "status": "row_added",
                "item_id": item_id,
                "sheet": sheet_name,
                "table": table_name,
                "index": result.get("index"),
            })

        except Exception as e:
            logger.error("excel_add_row_error: %s", e)
            return json.dumps({"error": str(e)})
