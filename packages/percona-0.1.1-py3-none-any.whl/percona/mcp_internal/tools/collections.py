import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from percona.context import get_user_id
from percona.database import async_session_factory
from percona.schemas.collections import (
    CollectionCreate,
    CollectionFieldCreate,
    CollectionItemCreate,
    CollectionItemUpdate,
    CollectionUpdate,
    VALID_FIELD_TYPES,
)
from percona.services import collection_service

logger = logging.getLogger(__name__)


async def _resolve_collection(db, user_id, collection_id, slug):
    """Resolve collection by ID or slug. Returns Collection or JSON error string."""
    if collection_id:
        try:
            col = await collection_service.get_collection(db, user_id, uuid.UUID(collection_id))
        except ValueError:
            return json.dumps({"error": f"Invalid collection_id: {collection_id!r}"})
        if not col:
            return json.dumps({"error": f"Collection not found: {collection_id}"})
        return col
    elif slug:
        col = await collection_service.get_collection_by_slug(db, user_id, slug)
        if not col:
            return json.dumps({"error": f"Collection not found with slug: {slug}"})
        return col
    else:
        return json.dumps({"error": "Requires collection_id or slug"})


def register(mcp: FastMCP) -> None:

    # ── Collection Management ──────────────────────────────────────────

    @mcp.tool()
    async def list_collections(
        status: str | None = None,
        name: str | None = None,
    ) -> str:
        """List all collections (custom data types like Contacts, Books, etc.).

        Args:
            status: Filter by status — active | archived
            name: Search by collection name
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                items = await collection_service.list_collections(
                    db, user_id, status=status, search=name, limit=50, offset=0,
                )
                return json.dumps([{
                    "collection_id": str(c.id),
                    "name": c.name,
                    "slug": c.slug,
                    "description": c.description,
                    "icon": c.icon,
                    "status": c.status,
                    "item_count": c.item_count,
                    "agent_instructions": c.agent_instructions,
                    "template_slug": c.template_slug,
                } for c in items])

        except ToolError:
            raise
        except Exception as e:
            logger.error("list_collections_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_collection(
        collection_id: str | None = None,
        slug: str | None = None,
    ) -> str:
        """Get a single collection with its fields.

        Args:
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                col_fields = await collection_service.list_fields(db, user_id, col.id)
                return json.dumps({
                    "collection_id": str(col.id),
                    "name": col.name,
                    "slug": col.slug,
                    "description": col.description,
                    "icon": col.icon,
                    "status": col.status,
                    "item_count": col.item_count,
                    "agent_instructions": col.agent_instructions,
                    "fields": [{
                        "field_id": str(f.id),
                        "name": f.name,
                        "label": f.label,
                        "field_type": f.field_type,
                        "required": f.required,
                        "options": f.options,
                    } for f in col_fields],
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_collection_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def create_collection(
        name: str,
        description: str | None = None,
        icon: str | None = None,
        color: str | None = None,
        tags: list[str] | None = None,
        agent_instructions: str | None = None,
        fields: str | None = None,
        session_id: str | None = None,
    ) -> str:
        """Create a new collection (custom data type like Contacts, Books, etc.).

        Args:
            name: Collection name (required)
            description: Collection description
            icon: Emoji icon
            color: Theme color
            tags: Label list
            agent_instructions: Natural language rules for the agent when using this collection
            fields: JSON string of field definitions, e.g. '[{"name":"phone","label":"Phone","field_type":"text"}]'
            session_id: Current session ID
        """
        try:
            field_defs = []
            if fields:
                try:
                    raw = json.loads(fields)
                    field_defs = [CollectionFieldCreate(**f) for f in raw]
                except (json.JSONDecodeError, TypeError) as e:
                    return json.dumps({"error": f"Invalid fields JSON: {e}"})

            async with async_session_factory() as db:
                user_id = get_user_id()
                create_data = CollectionCreate(
                    name=name,
                    description=description,
                    icon=icon,
                    color=color,
                    tags=tags or [],
                    fields=field_defs,
                    agent_instructions=agent_instructions,
                    session_id=uuid.UUID(session_id) if session_id else None,
                )
                try:
                    col = await collection_service.create_collection(db, user_id, create_data)
                except ValueError as e:
                    return json.dumps({"error": str(e)})
                await db.commit()
                return json.dumps({
                    "collection_id": str(col.id),
                    "name": col.name,
                    "slug": col.slug,
                    "fields_count": len(field_defs),
                    "message": f"Collection '{col.name}' created with {len(field_defs)} field(s).",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_collection_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_collection(
        collection_id: str | None = None,
        slug: str | None = None,
        name: str | None = None,
        description: str | None = None,
        icon: str | None = None,
        color: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
        agent_instructions: str | None = None,
    ) -> str:
        """Update collection metadata.

        Args:
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
            name: New collection name
            description: New description
            icon: New emoji icon
            color: New theme color
            status: active | archived
            tags: New label list
            agent_instructions: New natural language rules for the agent
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                update_kwargs = {}
                if name is not None:
                    update_kwargs["name"] = name
                if description is not None:
                    update_kwargs["description"] = description
                if icon is not None:
                    update_kwargs["icon"] = icon
                if color is not None:
                    update_kwargs["color"] = color
                if status is not None:
                    update_kwargs["status"] = status
                if tags:
                    update_kwargs["tags"] = tags
                if agent_instructions is not None:
                    update_kwargs["agent_instructions"] = agent_instructions
                col = await collection_service.update_collection(
                    db, user_id, col.id, CollectionUpdate(**update_kwargs)
                )
                if not col:
                    return json.dumps({"error": "Collection not found"})
                await db.commit()
                return json.dumps({"collection_id": str(col.id), "name": col.name, "message": "Updated"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_collection_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_collection(
        collection_id: str | None = None,
        slug: str | None = None,
    ) -> str:
        """Delete a collection and all its items.

        Args:
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                await collection_service.delete_collection(db, user_id, col.id)
                await db.commit()
                return json.dumps({"deleted": str(col.id), "message": f"Collection '{col.name}' deleted"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_collection_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def add_collection_field(
        field_name: str,
        field_label: str,
        field_type: str,
        collection_id: str | None = None,
        slug: str | None = None,
        required: bool = False,
        options: str | None = None,
        sort_order: int = 0,
    ) -> str:
        """Add a field to a collection schema.

        Args:
            field_name: Field key name
            field_label: Field display label
            field_type: text | number | date | boolean | select | url | email | tags | textarea | reference
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
            required: Whether field is required
            options: JSON string of select options, e.g. '["A","B"]'
            sort_order: Field ordering
        """
        try:
            if field_type not in VALID_FIELD_TYPES:
                return json.dumps({"error": f"Invalid field_type: {field_type!r}. Allowed: {sorted(VALID_FIELD_TYPES)}"})

            parsed_options = None
            if options:
                try:
                    parsed_options = json.loads(options)
                except json.JSONDecodeError:
                    return json.dumps({"error": "Invalid options JSON"})

            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                try:
                    field = await collection_service.add_field(
                        db, user_id, col.id,
                        CollectionFieldCreate(
                            name=field_name, label=field_label, field_type=field_type,
                            required=required, options=parsed_options, sort_order=sort_order,
                        )
                    )
                except ValueError as e:
                    return json.dumps({"error": str(e)})
                await db.commit()
                return json.dumps({"field_id": str(field.id), "name": field.name, "message": f"Field '{field.label}' added"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("add_collection_field_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_collection_field(
        field_id: str,
        collection_id: str | None = None,
        slug: str | None = None,
    ) -> str:
        """Remove a field from a collection schema.

        Args:
            field_id: Field UUID (required)
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                try:
                    deleted = await collection_service.delete_field(db, user_id, col.id, uuid.UUID(field_id))
                except ValueError:
                    return json.dumps({"error": f"Invalid field_id: {field_id!r}"})
                if not deleted:
                    return json.dumps({"error": f"Field not found: {field_id}"})
                await db.commit()
                return json.dumps({"deleted": field_id, "message": "Field deleted"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_collection_field_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    # ── Collection Items ───────────────────────────────────────────────

    @mcp.tool()
    async def add_collection_item(
        data: str,
        collection_id: str | None = None,
        slug: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
        notes: str | None = None,
        session_id: str | None = None,
    ) -> str:
        """Add a new item to a collection.

        Args:
            data: JSON string of field values, e.g. '{"name":"John","phone":"01012345678"}' (required)
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
            status: Item status: active | archived | completed (default: active)
            tags: Labels list
            notes: Item notes
            session_id: Current session ID
        """
        try:
            try:
                parsed_data = json.loads(data)
            except json.JSONDecodeError as e:
                return json.dumps({"error": f"Invalid data JSON: {e}"})

            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                try:
                    item = await collection_service.create_item(
                        db, user_id, col.id,
                        CollectionItemCreate(
                            data=parsed_data,
                            status=status or "active",
                            tags=tags or [],
                            notes=notes,
                            session_id=uuid.UUID(session_id) if session_id else None,
                        )
                    )
                except ValueError as e:
                    return json.dumps({"error": str(e)})
                await db.commit()
                return json.dumps({
                    "item_id": str(item.id),
                    "collection": col.name,
                    "data": item.data,
                    "message": f"Item added to '{col.name}'",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("add_collection_item_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_collection_item(
        item_id: str,
        collection_id: str | None = None,
        slug: str | None = None,
    ) -> str:
        """Get a single item from a collection by ID.

        Args:
            item_id: Item UUID (required)
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                try:
                    item = await collection_service.get_item(db, user_id, col.id, uuid.UUID(item_id))
                except ValueError:
                    return json.dumps({"error": f"Invalid item_id: {item_id!r}"})
                if not item:
                    return json.dumps({"error": f"Item not found: {item_id}"})
                return json.dumps({
                    "item_id": str(item.id),
                    "collection": col.name,
                    "data": item.data,
                    "status": item.status,
                    "tags": item.tags,
                    "notes": item.notes,
                    "created_at": item.created_at.isoformat() if item.created_at else None,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_collection_item_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def list_collection_items(
        collection_id: str | None = None,
        slug: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> str:
        """List items in a collection.

        Args:
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
            status: Filter by item status: active | archived | completed
            limit: Max results (default 20)
            offset: Pagination offset
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                items = await collection_service.list_items(
                    db, user_id, col.id, status=status, limit=limit, offset=offset,
                )
                return json.dumps([{
                    "item_id": str(i.id),
                    "data": i.data,
                    "status": i.status,
                    "tags": i.tags,
                    "notes": i.notes,
                    "created_at": i.created_at.isoformat() if i.created_at else None,
                } for i in items])

        except ToolError:
            raise
        except Exception as e:
            logger.error("list_collection_items_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_collection_item(
        item_id: str,
        collection_id: str | None = None,
        slug: str | None = None,
        data: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
        notes: str | None = None,
    ) -> str:
        """Update an item's data, status, tags, or notes.

        Args:
            item_id: Item UUID (required)
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
            data: JSON string of field values, e.g. '{"name":"John","phone":"01012345678"}'
            status: Item status: active | archived | completed
            tags: Labels list
            notes: Item notes
        """
        try:
            update_kwargs = {}
            if data:
                try:
                    update_kwargs["data"] = json.loads(data)
                except json.JSONDecodeError as e:
                    return json.dumps({"error": f"Invalid data JSON: {e}"})
            if status is not None:
                update_kwargs["status"] = status
            if tags:
                update_kwargs["tags"] = tags
            if notes is not None:
                update_kwargs["notes"] = notes

            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                try:
                    item = await collection_service.update_item(
                        db, user_id, col.id, uuid.UUID(item_id),
                        CollectionItemUpdate(**update_kwargs)
                    )
                except ValueError as e:
                    return json.dumps({"error": str(e)})
                if not item:
                    return json.dumps({"error": f"Item not found: {item_id}"})
                await db.commit()
                return json.dumps({"item_id": item_id, "data": item.data, "status": item.status, "message": "Updated"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_collection_item_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_collection_item(
        item_id: str,
        collection_id: str | None = None,
        slug: str | None = None,
    ) -> str:
        """Delete an item from a collection.

        Args:
            item_id: Item UUID (required)
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                try:
                    deleted = await collection_service.delete_item(db, user_id, col.id, uuid.UUID(item_id))
                except ValueError:
                    return json.dumps({"error": f"Invalid item_id: {item_id!r}"})
                if not deleted:
                    return json.dumps({"error": f"Item not found: {item_id}"})
                await db.commit()
                return json.dumps({"deleted": item_id, "message": "Item deleted"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_collection_item_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    # ── Collection Query ───────────────────────────────────────────────

    @mcp.tool()
    async def search_collection_items(
        collection_id: str | None = None,
        slug: str | None = None,
        search: str | None = None,
        status: str | None = None,
        sort_by: str | None = None,
        sort_dir: str = "desc",
        limit: int = 20,
        offset: int = 0,
    ) -> str:
        """Full-text search across all item data fields in a collection.

        Args:
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
            search: Search term for full-text search across JSONB data
            status: Filter by item status: active | archived | completed
            sort_by: Field name to sort by
            sort_dir: asc | desc (default: desc)
            limit: Max results (default 20)
            offset: Pagination offset
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                items = await collection_service.list_items(
                    db, user_id, col.id,
                    search=search, status=status,
                    sort_by=sort_by, sort_dir=sort_dir,
                    limit=limit, offset=offset,
                )
                return json.dumps([{
                    "item_id": str(i.id),
                    "data": i.data,
                    "status": i.status,
                    "tags": i.tags,
                } for i in items])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_collection_items_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def filter_collection_items(
        collection_id: str | None = None,
        slug: str | None = None,
        filter: str | None = None,
        status: str | None = None,
        sort_by: str | None = None,
        sort_dir: str = "desc",
        limit: int = 20,
        offset: int = 0,
    ) -> str:
        """Filter items by specific field values in a collection.

        Filter syntax: field:value (exact), field:gte:N, field:lte:N, field:contains:text

        Args:
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
            filter: Filter expression, e.g. "category:Work,rating:gte:4"
            status: Filter by item status: active | archived | completed
            sort_by: Field name to sort by
            sort_dir: asc | desc (default: desc)
            limit: Max results (default 20)
            offset: Pagination offset
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                items = await collection_service.list_items(
                    db, user_id, col.id,
                    filter_str=filter, status=status,
                    sort_by=sort_by, sort_dir=sort_dir,
                    limit=limit, offset=offset,
                )
                total = await collection_service.count_items(
                    db, user_id, col.id, filter_str=filter, status=status,
                )
                return json.dumps({
                    "total": total,
                    "items": [{
                        "item_id": str(i.id),
                        "data": i.data,
                        "status": i.status,
                        "tags": i.tags,
                    } for i in items],
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("filter_collection_items_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def collection_stats(
        collection_id: str | None = None,
        slug: str | None = None,
    ) -> str:
        """Get aggregation stats for a collection (counts by select fields, min/max/avg for numbers).

        Args:
            collection_id: Collection UUID (or use slug)
            slug: Collection slug for natural lookups like "contacts"
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                col = await _resolve_collection(db, user_id, collection_id, slug)
                if isinstance(col, str):
                    return col
                stats = await collection_service.get_collection_stats(db, user_id, col.id)
                return json.dumps(stats)

        except ToolError:
            raise
        except Exception as e:
            logger.error("collection_stats_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
