import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from percona.context import get_user_id
from percona.database import async_session_factory
from percona.schemas.memories import MemoryCreate, MemoryUpdate
from percona.services import memory_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_memory(
        entity_type: str,
        entity_key: str,
        key: str,
        value: str | None = None,
        value_json: dict | None = None,
        tags: list[str] | None = None,
        confidence: float | None = None,
        created_by: str | None = None,
        session_id: str | None = None,
    ) -> str:
        """Store a structured fact keyed to an entity. Upserts on matching entity_type/entity_key/key.

        Args:
            entity_type: "service" | "cluster" | "repo" | "codebase" | "user" | "team" | "pattern" | "project"
            entity_key: Stable entity identifier (e.g. "payments-api", "prod-cluster")
            key: Snake_case fact name (e.g. "deployment_frequency", "owner")
            value: Plain text fact value
            value_json: Structured JSON payload (alternative to value)
            tags: Labels (e.g. ["type:semantic", "domain:ops"])
            confidence: Confidence score 0.0-1.0
            created_by: Creator identifier
            session_id: Current session UUID
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                data = MemoryCreate(
                    entity_type=entity_type,
                    entity_key=entity_key,
                    key=key,
                    value=value,
                    value_json=value_json,
                    tags=tags or [],
                    confidence=confidence,
                    created_by=created_by,
                    source_session_id=uuid.UUID(session_id) if session_id else None,
                )
                mem = await memory_service.create_memory(db, user_id, data)
                await db.commit()
                logger.info("memory_created id=%s key=%s/%s/%s", mem.id, entity_type, entity_key, key)
                return json.dumps({
                    "id": str(mem.id),
                    "entity_type": mem.entity_type,
                    "entity_key": mem.entity_key,
                    "key": mem.key,
                    "created_at": mem.created_at.isoformat(),
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_memory_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_memories(
        entity_type: str | None = None,
        entity_key: str | None = None,
        query: str | None = None,
        keyword: str | None = None,
        rerank: bool = False,
        limit: int = 20,
        offset: int = 0,
    ) -> str:
        """Search agent memories. Supports semantic search, keyword search, and entity filtering.

        Args:
            entity_type: Filter by entity type (e.g. "service", "cluster")
            entity_key: Filter by entity key (e.g. "payments-api")
            query: Semantic search query
            keyword: BM25 keyword search
            rerank: Cross-encoder reranking (default false)
            limit: Max results (default 20)
            offset: Pagination offset
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                if not user_id:
                    return json.dumps({"error": "No user context. Cannot search memories without user scope."})

                entries = await memory_service.list_memories(
                    db, user_id,
                    entity_type=entity_type,
                    entity_key=entity_key,
                    query=query,
                    keyword=keyword,
                    rerank=rerank,
                    limit=limit,
                    offset=offset,
                )
                return json.dumps([
                    {
                        "id": str(m.id),
                        "entity_type": m.entity_type,
                        "entity_key": m.entity_key,
                        "key": m.key,
                        "value": m.value,
                        "value_json": m.value_json,
                        "tags": list(m.tags or []),
                        "confidence": m.confidence,
                        "updated_at": m.updated_at.isoformat(),
                    }
                    for m in entries
                ])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_memories_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_memory(memory_id: str) -> str:
        """Get full details of an agent memory by ID.

        Args:
            memory_id: UUID of the memory entry
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                mem = await memory_service.get_memory(db, user_id, uuid.UUID(memory_id))
                if not mem:
                    return json.dumps({"error": f"Memory not found: {memory_id}"})
                return json.dumps({
                    "id": str(mem.id),
                    "entity_type": mem.entity_type,
                    "entity_key": mem.entity_key,
                    "key": mem.key,
                    "value": mem.value,
                    "value_json": mem.value_json,
                    "tags": list(mem.tags or []),
                    "confidence": mem.confidence,
                    "created_by": mem.created_by,
                    "source_session_id": str(mem.source_session_id) if mem.source_session_id else None,
                    "created_at": mem.created_at.isoformat(),
                    "updated_at": mem.updated_at.isoformat(),
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_memory_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_memory(
        memory_id: str,
        value: str | None = None,
        value_json: dict | None = None,
        tags: list[str] | None = None,
        confidence: float | None = None,
    ) -> str:
        """Update an existing agent memory.

        Args:
            memory_id: UUID of the memory entry to update
            value: New plain text value
            value_json: New structured JSON payload
            tags: New tags
            confidence: New confidence score 0.0-1.0
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                update_kwargs = {}
                if value is not None:
                    update_kwargs["value"] = value
                if value_json is not None:
                    update_kwargs["value_json"] = value_json
                if tags is not None:
                    update_kwargs["tags"] = tags
                if confidence is not None:
                    update_kwargs["confidence"] = confidence
                mem = await memory_service.update_memory(
                    db, user_id, uuid.UUID(memory_id), MemoryUpdate(**update_kwargs)
                )
                if not mem:
                    return json.dumps({"error": f"Memory not found: {memory_id}"})
                await db.commit()
                return json.dumps({"id": memory_id, "updated_at": mem.updated_at.isoformat()})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_memory_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_memory(memory_id: str) -> str:
        """Delete an agent memory.

        Args:
            memory_id: UUID of the memory entry to delete
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                deleted = await memory_service.delete_memory(db, user_id, uuid.UUID(memory_id))
                if not deleted:
                    return json.dumps({"error": f"Memory not found: {memory_id}"})
                await db.commit()
                return json.dumps({"deleted": memory_id})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_memory_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
