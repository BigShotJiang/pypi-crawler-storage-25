import json
import logging
import uuid
from datetime import datetime

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from percona.context import get_user_id
from percona.database import async_session_factory
from percona.models.conversations import SessionStatus
from percona.services import session_read_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def search_sessions(
        status: str | None = None,
        created_after: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> str:
        """Search agent task sessions. Filter by status or creation date.

        Args:
            status: Filter by status — pending/running/completed/failed/cancelled/timeout
            created_after: ISO8601 datetime — only sessions created after this time
            limit: Max results (default 20)
            offset: Pagination offset
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                if not user_id:
                    return json.dumps([])

                status_enum: SessionStatus | None = None
                if status:
                    try:
                        status_enum = SessionStatus(status)
                    except ValueError:
                        return json.dumps({"error": f"Invalid status: {status!r}"})

                dt: datetime | None = None
                if created_after:
                    try:
                        dt = datetime.fromisoformat(created_after.replace("Z", "+00:00"))
                    except ValueError:
                        return json.dumps({"error": f"Invalid created_after: {created_after!r} — use ISO8601"})

                rows = await session_read_service.list_sessions(
                    db, user_id,
                    status=status_enum,
                    created_after=dt,
                    limit=limit,
                    offset=offset,
                )
                return json.dumps([
                    {
                        "id": str(s.id),
                        "status": s.status.value if hasattr(s.status, "value") else str(s.status),
                        "trigger_source": str(s.trigger_source),
                        "task_id": str(s.task_id) if s.task_id else None,
                        "summary": s.summary,
                        "created_at": s.created_at.isoformat(),
                        "finished_at": s.finished_at.isoformat() if s.finished_at else None,
                    }
                    for s in rows
                ])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_sessions_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_session(session_id: str) -> str:
        """Get full details and message history for an agent session.

        Args:
            session_id: UUID of the session to retrieve
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                result = await session_read_service.get_session_with_messages(
                    db, user_id, uuid.UUID(session_id),
                )
                if not result:
                    return json.dumps({"error": f"Session not found: {session_id}"})
                return json.dumps(result)

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_session_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
