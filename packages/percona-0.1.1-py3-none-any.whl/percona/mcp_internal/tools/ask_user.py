import json
import logging
import uuid

import redis.asyncio as aioredis
from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from percona.config import settings
from percona.context import get_conversation_id

logger = logging.getLogger(__name__)

# Redis key patterns
_QUESTION_KEY = "ask_user:question:{conversation_id}:{question_id}"
_ANSWER_KEY = "ask_user:answer:{conversation_id}:{question_id}"

# Defaults
DEFAULT_TIMEOUT_SECONDS = 600  # 10 minutes

_redis_pool: aioredis.Redis | None = None


def _get_redis() -> aioredis.Redis:
    global _redis_pool
    if _redis_pool is None:
        _redis_pool = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _redis_pool


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def ask_user(
        question: str,
        options: list[str],
        header: str = "Quick Question",
        multi_select: bool = False,
        allow_custom: bool = False,
        timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
    ) -> str:
        """Ask the user an interactive question with clickable option buttons and wait for their answer.

        IMPORTANT: Use this tool whenever you need user input and can offer predefined options.
        Users interact via web or mobile — clicking a button is instant, typing a reply is slow.
        ALWAYS prefer this over asking questions as plain text in the chat.

        Examples:
        - "Which category?" with options ["Food", "Transport", "Entertainment"]
        - "Confirm deletion?" with options ["Yes, delete", "No, cancel"]
        - "What priority?" with options ["Low", "Medium", "High", "Urgent"]

        Set multi_select=true when the user can pick multiple answers.
        Set allow_custom=true when the user might want to type their own answer.

        Args:
            question: The question to ask (clear and concise)
            options: 2-6 clickable options for the user to choose from
            header: Short title shown above the question (max 30 chars, default: "Quick Question")
            multi_select: Allow selecting multiple options (default: false = single select)
            allow_custom: Show a free-text input field for custom answers (default: false)
            timeout_seconds: How long to wait for user response (default: 600 = 10 minutes)

        Returns:
            The user's answer as a string. If multi_select, answers are comma-separated.
        """
        # Validation
        if not question or not question.strip():
            raise ToolError("Question cannot be empty")

        if not options or len(options) < 2:
            raise ToolError("Must provide at least 2 options")

        if len(options) > 6:
            raise ToolError("Maximum 6 options allowed")

        if len(header) > 30:
            raise ToolError(f"Header too long ({len(header)} chars). Must be 30 characters or less")

        cleaned_options = [opt.strip() for opt in options if opt.strip()]
        if len(cleaned_options) < 2:
            raise ToolError("All options must be non-empty strings")

        conversation_id = get_conversation_id()
        if not conversation_id:
            raise ToolError("Cannot ask user: no active conversation context")

        question_id = str(uuid.uuid4())
        redis = _get_redis()

        # Store question data in Redis for the frontend to pick up
        question_data = {
            "question_id": question_id,
            "question": question.strip(),
            "options": cleaned_options,
            "header": header.strip(),
            "multi_select": multi_select,
            "allow_custom": allow_custom,
            "conversation_id": conversation_id,
        }

        question_key = _QUESTION_KEY.format(
            conversation_id=conversation_id, question_id=question_id
        )
        answer_key = _ANSWER_KEY.format(
            conversation_id=conversation_id, question_id=question_id
        )

        await redis.set(question_key, json.dumps(question_data), ex=timeout_seconds)

        logger.info(
            "ask_user_question_posted conversation=%s question_id=%s question=%s",
            conversation_id, question_id, question.strip()[:50],
        )

        # Return special marker that the ChatOrchestrator will detect
        # to emit the SSE event to the frontend
        return json.dumps({
            "_pending_user_input": True,
            "_question_data": question_data,
        })

    @mcp.tool()
    async def wait_for_answer(
        question_id: str,
        timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
    ) -> str:
        """Wait for the user's answer to a previously asked question.

        This is automatically called after ask_user. Do NOT call this directly.
        The system will handle the waiting automatically.

        Args:
            question_id: The question_id returned by ask_user
            timeout_seconds: Maximum time to wait (default: 600 seconds)

        Returns:
            The user's answer as a string.
        """
        conversation_id = get_conversation_id()
        if not conversation_id:
            raise ToolError("Cannot wait for answer: no active conversation context")

        redis = _get_redis()
        answer_key = _ANSWER_KEY.format(
            conversation_id=conversation_id, question_id=question_id
        )
        question_key = _QUESTION_KEY.format(
            conversation_id=conversation_id, question_id=question_id
        )

        # Use BLPOP for efficient blocking wait instead of polling.
        # The /answer endpoint pushes the answer to a Redis list.
        result = await redis.blpop(answer_key, timeout=timeout_seconds)

        # Clean up question key regardless of outcome
        await redis.delete(question_key)

        if result is None:
            # Timeout — BLPOP returns None when timeout expires
            logger.warning(
                "ask_user_timeout conversation=%s question_id=%s timeout=%d",
                conversation_id, question_id, timeout_seconds,
            )
            raise ToolError(
                f"User did not respond within {timeout_seconds} seconds. "
                "The question has timed out. You may proceed without user input or try asking again."
            )

        # BLPOP returns (key, value)
        answer = result[1]
        logger.info(
            "ask_user_answer_received conversation=%s question_id=%s answer=%s",
            conversation_id, question_id, str(answer)[:100],
        )
        return str(answer)
