import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from percona.context import get_user_id
from percona.database import async_session_factory
from percona.services import skill_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP):

    @mcp.tool()
    async def create_skill(
        name: str,
        content: str,
        description: str | None = None,
        domain: str | None = None,
        entry_type: str = "skill",
        session_id: str | None = None,
    ) -> str:
        """Create or update a reusable skill or runbook (upserts by name/slug).

        Args:
            name: Skill name (also used as slug)
            content: Markdown procedure content
            description: Brief description
            domain: monitoring | infrastructure | data | security | applications | cicd
            entry_type: "skill" (agent-executable, default) | "runbook" (human operational procedure)
            session_id: Current session ID
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                s, op_status = await skill_service.create_or_update_skill(
                    db, user_id,
                    name=name,
                    description=description,
                    domain=domain,
                    content=content,
                    entry_type=entry_type,
                    session_id=uuid.UUID(session_id) if session_id else None,
                )
                await db.commit()
                return json.dumps({"id": str(s.id), "name": s.name, "slug": s.slug, "entry_type": s.entry_type.value, "status": op_status})

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_skill_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_skills(
        domain: str | None = None,
        entry_type: str | None = None,
        query: str | None = None,
        keyword: str | None = None,
        limit: int = 50,
        offset: int = 0,
        rerank: bool = False,
    ) -> str:
        """Search reusable skills and runbooks. Supports semantic search, keyword search, and filtering.

        Args:
            domain: Filter by domain — monitoring/infrastructure/data/security/applications/cicd
            entry_type: Filter by type — "skill" | "runbook"
            query: Semantic search query
            keyword: BM25 keyword search
            limit: Max results (default 50)
            offset: Pagination offset
            rerank: Cross-encoder reranking (default false)
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                if not user_id:
                    return json.dumps({"error": "No user context. Cannot search skills without user scope."})

                skills = await skill_service.list_skills(
                    db, user_id, domain=domain, entry_type=entry_type, query=query, keyword=keyword,
                    limit=limit, offset=offset, rerank=rerank,
                )
                return json.dumps([{
                    "id": str(s.id), "name": s.name, "slug": s.slug,
                    "domain": s.domain, "description": s.description,
                    "entry_type": s.entry_type.value,
                } for s in skills])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_skills_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_skill(
        skill_id: str | None = None,
        name: str | None = None,
    ) -> str:
        """Get full details of a skill by ID or name/slug.

        Args:
            skill_id: UUID of the skill
            name: Skill name or slug (alternative to skill_id)
        """
        try:
            if not name and not skill_id:
                return json.dumps({"error": "get_skill requires: skill_id or name"})

            async with async_session_factory() as db:
                user_id = get_user_id()
                if name:
                    s = await skill_service.get_skill_by_slug(db, user_id, skill_service.slugify(name))
                else:
                    s = await skill_service.get_skill_by_id(db, user_id, uuid.UUID(skill_id))
                if not s:
                    return json.dumps({"error": f"Skill not found: {name or skill_id}"})
                return json.dumps({
                    "id": str(s.id), "name": s.name, "slug": s.slug,
                    "domain": s.domain, "description": s.description,
                    "entry_type": s.entry_type.value,
                    "content": s.content,
                    "created_at": s.created_at.isoformat() if s.created_at else None,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_skill_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_skill(
        skill_id: str,
        name: str | None = None,
        description: str | None = None,
        domain: str | None = None,
        content: str | None = None,
        entry_type: str | None = None,
    ) -> str:
        """Update an existing skill or runbook.

        Args:
            skill_id: UUID of the skill to update
            name: New name
            description: New description
            domain: New domain
            content: New markdown content
            entry_type: New entry type — "skill" | "runbook"
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                s = await skill_service.update_skill(
                    db, user_id, uuid.UUID(skill_id),
                    name=name, description=description, domain=domain, content=content, entry_type=entry_type,
                )
                if not s:
                    return json.dumps({"error": f"Skill {skill_id} not found"})
                await db.commit()
                logger.info("skill_updated id=%s", skill_id)
                return json.dumps({"id": str(s.id), "name": s.name, "slug": s.slug, "status": "updated"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_skill_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_skill(skill_id: str) -> str:
        """Delete a skill or runbook.

        Args:
            skill_id: UUID of the skill to delete
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                deleted = await skill_service.delete_skill(db, user_id, uuid.UUID(skill_id))
                if not deleted:
                    return json.dumps({"error": f"Skill {skill_id} not found"})
                await db.commit()
                logger.info("skill_deleted id=%s", skill_id)
                return json.dumps({"deleted": skill_id})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_skill_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
