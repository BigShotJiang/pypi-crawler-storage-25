"""OneNote MCP tools — access notebooks, sections, and pages via Microsoft Graph API."""

import json
import logging

from fastmcp import FastMCP

from percona.mcp_internal.tools._microsoft_graph import (
    graph_get,
    graph_get_raw,
    graph_post,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def onenote_list_notebooks(
        account_id: str | None = None,
    ) -> str:
        """List all OneNote notebooks.

        Args:
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            data = await graph_get(token, "/me/onenote/notebooks", {
                "$select": "id,displayName,createdDateTime,lastModifiedDateTime,isDefault,isShared",
                "$orderby": "lastModifiedDateTime desc",
            })

            notebooks = [
                {
                    "id": nb["id"],
                    "name": nb.get("displayName"),
                    "is_default": nb.get("isDefault", False),
                    "is_shared": nb.get("isShared", False),
                    "created": nb.get("createdDateTime"),
                    "last_modified": nb.get("lastModifiedDateTime"),
                }
                for nb in data.get("value", [])
            ]

            logger.info("onenote_list_notebooks account=%s count=%d", email_addr, len(notebooks))
            return json.dumps({"account": email_addr, "notebooks": notebooks, "total": len(notebooks)})

        except Exception as e:
            logger.error("onenote_list_notebooks_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onenote_list_sections(
        notebook_id: str,
        account_id: str | None = None,
    ) -> str:
        """List sections within a OneNote notebook.

        Args:
            notebook_id: Notebook ID from onenote_list_notebooks.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            data = await graph_get(token, f"/me/onenote/notebooks/{notebook_id}/sections", {
                "$select": "id,displayName,createdDateTime,lastModifiedDateTime,isDefault",
            })

            sections = [
                {
                    "id": s["id"],
                    "name": s.get("displayName"),
                    "is_default": s.get("isDefault", False),
                    "created": s.get("createdDateTime"),
                    "last_modified": s.get("lastModifiedDateTime"),
                }
                for s in data.get("value", [])
            ]

            logger.info("onenote_list_sections account=%s notebook_id=%s count=%d", email_addr, notebook_id, len(sections))
            return json.dumps({"account": email_addr, "notebook_id": notebook_id, "sections": sections, "total": len(sections)})

        except Exception as e:
            logger.error("onenote_list_sections_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onenote_list_pages(
        section_id: str,
        max_results: int = 25,
        account_id: str | None = None,
    ) -> str:
        """List pages within a OneNote section.

        Args:
            section_id: Section ID from onenote_list_sections.
            max_results: Max pages to return (1-100).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(100, max_results))
            data = await graph_get(token, f"/me/onenote/sections/{section_id}/pages", {
                "$top": str(max_results),
                "$select": "id,title,createdDateTime,lastModifiedDateTime,contentUrl,order",
                "$orderby": "order",
            })

            pages = [
                {
                    "id": p["id"],
                    "title": p.get("title"),
                    "created": p.get("createdDateTime"),
                    "last_modified": p.get("lastModifiedDateTime"),
                }
                for p in data.get("value", [])
            ]

            logger.info("onenote_list_pages account=%s section_id=%s count=%d", email_addr, section_id, len(pages))
            return json.dumps({"account": email_addr, "section_id": section_id, "pages": pages, "total": len(pages)})

        except Exception as e:
            logger.error("onenote_list_pages_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onenote_read_page(
        page_id: str,
        account_id: str | None = None,
    ) -> str:
        """Read the HTML content of a OneNote page.

        Args:
            page_id: Page ID from onenote_list_pages.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            # Get page metadata
            meta = await graph_get(token, f"/me/onenote/pages/{page_id}", {
                "$select": "id,title,createdDateTime,lastModifiedDateTime",
            })

            # Get page content (returned as HTML)
            content_bytes = await graph_get_raw(token, f"/me/onenote/pages/{page_id}/content")
            content = content_bytes.decode("utf-8", errors="replace")[:50000]

            result = {
                "id": meta["id"],
                "title": meta.get("title"),
                "created": meta.get("createdDateTime"),
                "last_modified": meta.get("lastModifiedDateTime"),
                "content_html": content,
            }

            logger.info("onenote_read_page account=%s page_id=%s", email_addr, page_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("onenote_read_page_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onenote_create_page(
        section_id: str,
        title: str,
        content: str,
        account_id: str | None = None,
    ) -> str:
        """Create a new page in a OneNote section.

        Args:
            section_id: Section ID from onenote_list_sections.
            title: Page title.
            content: Page content in HTML or plain text.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            # OneNote pages are created by POSTing HTML content
            html = f"""<!DOCTYPE html>
<html>
<head><title>{title}</title></head>
<body>
{content}
</body>
</html>"""

            import httpx
            from percona.mcp_internal.tools._microsoft_graph import GRAPH_BASE

            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    f"{GRAPH_BASE}/me/onenote/sections/{section_id}/pages",
                    headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/xhtml+xml",
                    },
                    content=html.encode("utf-8"),
                    timeout=15,
                )
                resp.raise_for_status()
                result = resp.json()

            logger.info("onenote_create_page account=%s title=%s", email_addr, title)
            return json.dumps({
                "status": "created",
                "id": result.get("id"),
                "title": result.get("title"),
            })

        except Exception as e:
            logger.error("onenote_create_page_error: %s", e)
            return json.dumps({"error": str(e)})
