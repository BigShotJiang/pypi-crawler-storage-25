"""Outlook Mail MCP tools — read, search, and send emails via Microsoft Graph API."""

import json
import logging

from fastmcp import FastMCP
from sqlalchemy import select

from percona.context import get_user_id
from percona.database import async_session_factory
from percona.models import ConnectedAccount
from percona.mcp_internal.tools._microsoft_graph import (
    graph_get,
    graph_post,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def outlook_list_accounts() -> str:
        """List connected Microsoft accounts. Call this first before using other Microsoft tools.

        Pass the returned account_id to target a specific account.
        """
        user_id = get_user_id()
        async with async_session_factory() as db:
            result = await db.execute(
                select(ConnectedAccount)
                .where(
                    ConnectedAccount.user_id == user_id,
                    ConnectedAccount.provider == "microsoft",
                )
                .order_by(ConnectedAccount.created_at)
            )
            accounts = result.scalars().all()

        if not accounts:
            return json.dumps({"accounts": [], "message": "No Microsoft accounts connected. Visit /integrations to connect one."})

        return json.dumps({
            "accounts": [
                {
                    "account_id": str(a.id),
                    "email": a.provider_email,
                    "label": a.label,
                    "status": a.status,
                    "default": i == 0,
                }
                for i, a in enumerate(accounts)
            ],
            "note": "Pass account_id to any Microsoft tool to target a specific account. The first account is used by default.",
        })

    @mcp.tool()
    async def outlook_list_emails(
        query: str = "",
        folder: str = "inbox",
        max_results: int = 10,
        account_id: str | None = None,
    ) -> str:
        """List emails from Outlook.

        Args:
            query: Search query (e.g. "from:boss@example.com", "subject:invoice"). Uses Microsoft Search syntax.
            folder: Mail folder to list from (inbox, sentitems, drafts, etc.). Default: inbox.
            max_results: Max emails to return (1-50).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(50, max_results))
            params = {
                "$top": str(max_results),
                "$select": "id,conversationId,subject,from,toRecipients,receivedDateTime,bodyPreview,isRead,hasAttachments",
                "$orderby": "receivedDateTime desc",
            }

            if query:
                params["$search"] = f'"{query}"'
                path = "/me/messages"
            else:
                path = f"/me/mailFolders/{folder}/messages"

            data = await graph_get(token, path, params)
            messages = data.get("value", [])

            emails = []
            for msg in messages:
                from_addr = msg.get("from", {}).get("emailAddress", {})
                to_list = [r.get("emailAddress", {}).get("address", "") for r in msg.get("toRecipients", [])]
                emails.append({
                    "id": msg["id"],
                    "conversation_id": msg.get("conversationId"),
                    "subject": msg.get("subject", "(no subject)"),
                    "from": from_addr.get("address", ""),
                    "from_name": from_addr.get("name", ""),
                    "to": to_list,
                    "date": msg.get("receivedDateTime"),
                    "preview": msg.get("bodyPreview", ""),
                    "is_read": msg.get("isRead", False),
                    "has_attachments": msg.get("hasAttachments", False),
                })

            logger.info("outlook_list_emails account=%s count=%d", email_addr, len(emails))
            return json.dumps({"account": email_addr, "emails": emails, "total": len(emails)})

        except Exception as e:
            logger.error("outlook_list_emails_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_read_email(
        message_id: str,
        account_id: str | None = None,
    ) -> str:
        """Read the full content of an Outlook email.

        Args:
            message_id: Message ID from outlook_list_emails.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            msg = await graph_get(token, f"/me/messages/{message_id}", {
                "$select": "id,conversationId,subject,from,toRecipients,ccRecipients,body,receivedDateTime,isRead,hasAttachments",
                "$expand": "attachments($select=id,name,contentType,size)",
            })

            from_addr = msg.get("from", {}).get("emailAddress", {})
            to_list = [r.get("emailAddress", {}).get("address", "") for r in msg.get("toRecipients", [])]
            cc_list = [r.get("emailAddress", {}).get("address", "") for r in msg.get("ccRecipients", [])]
            body = msg.get("body", {}).get("content", "")

            attachments = []
            for att in msg.get("attachments", []):
                attachments.append({
                    "id": att.get("id"),
                    "name": att.get("name"),
                    "content_type": att.get("contentType"),
                    "size": att.get("size"),
                })

            result = {
                "id": msg["id"],
                "conversation_id": msg.get("conversationId"),
                "subject": msg.get("subject", "(no subject)"),
                "from": from_addr.get("address", ""),
                "from_name": from_addr.get("name", ""),
                "to": to_list,
                "cc": cc_list,
                "date": msg.get("receivedDateTime"),
                "is_read": msg.get("isRead", False),
                "body": body[:32000],
                "attachments": attachments,
            }

            logger.info("outlook_read_email account=%s message_id=%s", email_addr, message_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("outlook_read_email_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_get_thread(
        conversation_id: str,
        max_results: int = 25,
        account_id: str | None = None,
    ) -> str:
        """Retrieve all messages in an Outlook email conversation/thread.

        Args:
            conversation_id: Conversation ID from outlook_list_emails or outlook_read_email.
            max_results: Max messages to return (1-50).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(50, max_results))
            data = await graph_get(token, "/me/messages", {
                "$filter": f"conversationId eq '{conversation_id}'",
                "$top": str(max_results),
                "$select": "id,subject,from,toRecipients,ccRecipients,body,receivedDateTime",
                "$orderby": "receivedDateTime asc",
            })

            messages = []
            for msg in data.get("value", []):
                from_addr = msg.get("from", {}).get("emailAddress", {})
                body = msg.get("body", {}).get("content", "")
                messages.append({
                    "id": msg["id"],
                    "subject": msg.get("subject", "(no subject)"),
                    "from": from_addr.get("address", ""),
                    "from_name": from_addr.get("name", ""),
                    "to": [r.get("emailAddress", {}).get("address", "") for r in msg.get("toRecipients", [])],
                    "cc": [r.get("emailAddress", {}).get("address", "") for r in msg.get("ccRecipients", [])],
                    "date": msg.get("receivedDateTime"),
                    "body": body[:32000],
                })

            result = {
                "conversation_id": conversation_id,
                "account": email_addr,
                "message_count": len(messages),
                "messages": messages,
            }
            logger.info("outlook_get_thread account=%s conversation_id=%s count=%d", email_addr, conversation_id, len(messages))
            return json.dumps(result)

        except Exception as e:
            logger.error("outlook_get_thread_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_send_email(
        to: str,
        subject: str,
        body: str,
        cc: str = "",
        account_id: str | None = None,
    ) -> str:
        """Send an email via Outlook.

        Args:
            to: Recipient email address (comma-separated for multiple).
            subject: Email subject line.
            body: Email body (plain text).
            cc: CC recipients (comma-separated). Optional.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            to_recipients = [
                {"emailAddress": {"address": addr.strip()}}
                for addr in to.split(",") if addr.strip()
            ]
            cc_recipients = [
                {"emailAddress": {"address": addr.strip()}}
                for addr in cc.split(",") if addr.strip()
            ] if cc else []

            payload = {
                "message": {
                    "subject": subject,
                    "body": {"contentType": "Text", "content": body},
                    "toRecipients": to_recipients,
                },
                "saveToSentItems": True,
            }
            if cc_recipients:
                payload["message"]["ccRecipients"] = cc_recipients

            await graph_post(token, "/me/sendMail", payload)
            logger.info("outlook_send_email from=%s to=%s subject=%s", email_addr, to, subject)
            return json.dumps({"status": "sent", "from": email_addr, "to": to, "subject": subject})

        except Exception as e:
            logger.error("outlook_send_email_error: %s", e)
            return json.dumps({"error": str(e)})
