"""OneDrive MCP tools — manage files and folders via Microsoft Graph API."""

import base64
import json
import logging

from fastmcp import FastMCP

from percona.mcp_internal.tools._microsoft_graph import (
    graph_delete,
    graph_get,
    graph_get_raw,
    graph_post,
    graph_put_content,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def onedrive_list_files(
        folder_id: str = "",
        path: str = "",
        max_results: int = 25,
        account_id: str | None = None,
    ) -> str:
        """List files and folders in OneDrive.

        Args:
            folder_id: Folder item ID to list contents of. Lists root if omitted.
            path: Folder path (e.g. "/Documents/Reports"). Alternative to folder_id.
            max_results: Max items to return (1-200).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(200, max_results))

            if folder_id:
                api_path = f"/me/drive/items/{folder_id}/children"
            elif path:
                clean_path = path.strip("/")
                api_path = f"/me/drive/root:/{clean_path}:/children"
            else:
                api_path = "/me/drive/root/children"

            data = await graph_get(token, api_path, {
                "$top": str(max_results),
                "$select": "id,name,size,lastModifiedDateTime,folder,file,webUrl,parentReference",
                "$orderby": "name",
            })

            items = []
            for item in data.get("value", []):
                is_folder = "folder" in item
                file_info = item.get("file", {})
                items.append({
                    "id": item["id"],
                    "name": item.get("name"),
                    "type": "folder" if is_folder else "file",
                    "size": item.get("size", 0),
                    "mime_type": file_info.get("mimeType", "") if not is_folder else "",
                    "last_modified": item.get("lastModifiedDateTime"),
                    "web_url": item.get("webUrl"),
                    "child_count": item.get("folder", {}).get("childCount") if is_folder else None,
                    "parent_path": item.get("parentReference", {}).get("path", ""),
                })

            logger.info("onedrive_list_files account=%s count=%d", email_addr, len(items))
            return json.dumps({"account": email_addr, "items": items, "total": len(items)})

        except Exception as e:
            logger.error("onedrive_list_files_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_get_file(
        item_id: str = "",
        path: str = "",
        account_id: str | None = None,
    ) -> str:
        """Get file or folder metadata from OneDrive.

        Args:
            item_id: Item ID.
            path: File path (e.g. "/Documents/report.pdf"). Alternative to item_id.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            if item_id:
                api_path = f"/me/drive/items/{item_id}"
            elif path:
                clean_path = path.strip("/")
                api_path = f"/me/drive/root:/{clean_path}"
            else:
                return json.dumps({"error": "Either item_id or path is required"})

            item = await graph_get(token, api_path, {
                "$select": "id,name,size,lastModifiedDateTime,createdDateTime,folder,file,webUrl,parentReference,description",
            })

            is_folder = "folder" in item
            file_info = item.get("file", {})

            result = {
                "id": item["id"],
                "name": item.get("name"),
                "type": "folder" if is_folder else "file",
                "size": item.get("size", 0),
                "mime_type": file_info.get("mimeType", "") if not is_folder else "",
                "created": item.get("createdDateTime"),
                "last_modified": item.get("lastModifiedDateTime"),
                "web_url": item.get("webUrl"),
                "description": item.get("description", ""),
                "parent_path": item.get("parentReference", {}).get("path", ""),
                "child_count": item.get("folder", {}).get("childCount") if is_folder else None,
            }

            logger.info("onedrive_get_file account=%s item_id=%s", email_addr, item.get("id"))
            return json.dumps(result)

        except Exception as e:
            logger.error("onedrive_get_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_download_file(
        item_id: str = "",
        path: str = "",
        account_id: str | None = None,
    ) -> str:
        """Download/read file content from OneDrive.

        Returns text content for text files, base64-encoded content for binary files.
        Maximum file size: 10 MB.

        Args:
            item_id: Item ID of the file.
            path: File path (e.g. "/Documents/notes.txt"). Alternative to item_id.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            # First get metadata to check size and type
            if item_id:
                meta_path = f"/me/drive/items/{item_id}"
                content_path = f"/me/drive/items/{item_id}/content"
            elif path:
                clean_path = path.strip("/")
                meta_path = f"/me/drive/root:/{clean_path}"
                content_path = f"/me/drive/root:/{clean_path}:/content"
            else:
                return json.dumps({"error": "Either item_id or path is required"})

            meta = await graph_get(token, meta_path, {"$select": "id,name,size,file"})
            size = meta.get("size", 0)
            if size > 10 * 1024 * 1024:
                return json.dumps({"error": f"File too large ({size} bytes). Max 10 MB."})

            mime_type = meta.get("file", {}).get("mimeType", "application/octet-stream")
            raw = await graph_get_raw(token, content_path)

            is_text = mime_type.startswith("text/") or mime_type in (
                "application/json", "application/xml", "application/javascript",
                "application/x-yaml", "application/yaml",
            )

            if is_text:
                content = raw.decode("utf-8", errors="replace")[:50000]
                encoding = "text"
            else:
                content = base64.b64encode(raw).decode()
                encoding = "base64"

            logger.info("onedrive_download_file account=%s name=%s size=%d", email_addr, meta.get("name"), size)
            return json.dumps({
                "id": meta["id"],
                "name": meta.get("name"),
                "mime_type": mime_type,
                "size": size,
                "encoding": encoding,
                "content": content,
            })

        except Exception as e:
            logger.error("onedrive_download_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_upload_file(
        path: str,
        content: str,
        content_type: str = "text/plain",
        account_id: str | None = None,
    ) -> str:
        """Upload or create a file in OneDrive.

        For files up to 4 MB. Creates or overwrites the file at the given path.

        Args:
            path: Destination path in OneDrive (e.g. "/Documents/notes.txt").
            content: File content as text.
            content_type: MIME type (e.g. "text/plain", "application/json").
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            clean_path = path.strip("/")
            api_path = f"/me/drive/root:/{clean_path}:/content"
            raw = content.encode("utf-8")

            if len(raw) > 4 * 1024 * 1024:
                return json.dumps({"error": "Content too large. Max 4 MB for simple upload."})

            result = await graph_put_content(token, api_path, raw, content_type)

            logger.info("onedrive_upload_file account=%s path=%s size=%d", email_addr, path, len(raw))
            return json.dumps({
                "status": "uploaded",
                "id": result.get("id"),
                "name": result.get("name"),
                "size": result.get("size"),
                "web_url": result.get("webUrl"),
            })

        except Exception as e:
            logger.error("onedrive_upload_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_create_folder(
        name: str,
        parent_folder_id: str = "",
        parent_path: str = "",
        account_id: str | None = None,
    ) -> str:
        """Create a new folder in OneDrive.

        Args:
            name: Folder name.
            parent_folder_id: Parent folder ID. Creates in root if omitted.
            parent_path: Parent folder path (e.g. "/Documents"). Alternative to parent_folder_id.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            if parent_folder_id:
                api_path = f"/me/drive/items/{parent_folder_id}/children"
            elif parent_path:
                clean_path = parent_path.strip("/")
                api_path = f"/me/drive/root:/{clean_path}:/children"
            else:
                api_path = "/me/drive/root/children"

            result = await graph_post(token, api_path, {
                "name": name,
                "folder": {},
                "@microsoft.graph.conflictBehavior": "rename",
            })

            logger.info("onedrive_create_folder account=%s name=%s", email_addr, name)
            return json.dumps({
                "status": "created",
                "id": result.get("id"),
                "name": result.get("name"),
                "web_url": result.get("webUrl"),
            })

        except Exception as e:
            logger.error("onedrive_create_folder_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_share_file(
        item_id: str,
        share_type: str = "view",
        account_id: str | None = None,
    ) -> str:
        """Create a sharing link for a OneDrive file.

        Args:
            item_id: Item ID of the file to share.
            share_type: Permission type — "view" (read-only) or "edit".
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            result = await graph_post(token, f"/me/drive/items/{item_id}/createLink", {
                "type": share_type,
                "scope": "anonymous",
            })

            link = result.get("link", {})
            logger.info("onedrive_share_file account=%s item_id=%s type=%s", email_addr, item_id, share_type)
            return json.dumps({
                "status": "shared",
                "item_id": item_id,
                "share_type": share_type,
                "link": link.get("webUrl"),
            })

        except Exception as e:
            logger.error("onedrive_share_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_delete_file(
        item_id: str,
        account_id: str | None = None,
    ) -> str:
        """Delete a file or folder from OneDrive.

        Args:
            item_id: Item ID of the file or folder to delete.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            await graph_delete(token, f"/me/drive/items/{item_id}")

            logger.info("onedrive_delete_file account=%s item_id=%s", email_addr, item_id)
            return json.dumps({"status": "deleted", "item_id": item_id})

        except Exception as e:
            logger.error("onedrive_delete_file_error: %s", e)
            return json.dumps({"error": str(e)})
