import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from percona.context import get_user_id
from percona.database import async_session_factory
from percona.services import storage_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def upload_file(
        file_path: str,
        folder: str | None = None,
        session_id: str | None = None,
    ) -> str:
        """Upload a local file to S3 and get its public URL.

        Args:
            file_path: Absolute local path to upload (e.g. /tmp/percona/workspaces/{session_id}/file.csv)
            folder: Virtual folder (e.g. "reports", "exports")
            session_id: Current session ID
        """
        try:
            async with async_session_factory() as db:
                user_id = get_user_id()
                try:
                    item = await storage_service.upload_file(
                        db, user_id, file_path,
                        folder=folder,
                        session_id=uuid.UUID(session_id) if session_id else None,
                    )
                except FileNotFoundError:
                    return json.dumps({"error": f"File not found: {file_path!r}"})
                except OSError as e:
                    return json.dumps({"error": f"Cannot read file: {e}"})
                except ValueError as e:
                    return json.dumps({"error": str(e)})

                file_id_str = str(item.id)
                await db.commit()

            logger.info("mcp_storage_uploaded file_id=%s original=%r url=%s", file_id_str, item.original_filename, item.s3_url)
            return json.dumps({
                "file_id": file_id_str,
                "original_filename": item.original_filename,
                "public_url": item.s3_url,
                "thumbnail_url": item.thumbnail_url,
                "file_size_bytes": item.file_size_bytes,
                "content_type": item.content_type,
                "message": f"File uploaded: {item.original_filename!r}",
            })

        except ToolError:
            raise
        except Exception as e:
            logger.error("upload_file_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_file(file_id: str) -> str:
        """Delete a stored file from S3 by its file ID.

        Args:
            file_id: UUID of the stored file to delete
        """
        try:
            try:
                fid = uuid.UUID(file_id)
            except ValueError:
                return json.dumps({"error": f"Invalid file_id: {file_id!r}"})

            async with async_session_factory() as db:
                user_id = get_user_id()
                deleted = await storage_service.delete_file(db, user_id, fid)
                if not deleted:
                    return json.dumps({"error": f"File not found: {file_id}"})
                await db.commit()

            logger.info("mcp_storage_deleted file_id=%s", file_id)
            return json.dumps({"file_id": file_id, "message": "File deleted"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_file_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
