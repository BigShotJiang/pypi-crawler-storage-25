"""Shared helpers for Microsoft Graph API MCP tools.

Centralises account resolution and HTTP calls so individual tool modules
(outlook_mail, outlook_calendar, onedrive, etc.) stay thin.
"""

import json
import logging
import uuid

import httpx
from sqlalchemy import select

from percona.context import get_user_id
from percona.database import async_session_factory
from percona.models import ConnectedAccount
from percona.services import oauth_service

logger = logging.getLogger(__name__)

GRAPH_BASE = "https://graph.microsoft.com/v1.0"


async def resolve_microsoft_account(account_id: str | None = None) -> tuple[str, str]:
    """Return (access_token, provider_email) for the given or first active Microsoft account.

    Enforces user isolation: only accounts belonging to the current user are accessible.
    """
    user_id = get_user_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", ""
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.user_id == user_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, aid)
            return token, account.provider_email
        else:
            account = await oauth_service.get_first_active_account(db, user_id, "microsoft")
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, account.id)
            return token, account.provider_email


def _auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


async def graph_get(token: str, path: str, params: dict | None = None) -> dict:
    """GET request to Microsoft Graph API."""
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{GRAPH_BASE}{path}",
            headers=_auth_headers(token),
            params=params,
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()


async def graph_get_raw(token: str, path: str) -> bytes:
    """GET request returning raw bytes (for file downloads)."""
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{GRAPH_BASE}{path}",
            headers=_auth_headers(token),
            timeout=30,
            follow_redirects=True,
        )
        resp.raise_for_status()
        return resp.content


async def graph_post(token: str, path: str, json_body: dict | None = None) -> dict:
    """POST request to Microsoft Graph API."""
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{GRAPH_BASE}{path}",
            headers={**_auth_headers(token), "Content-Type": "application/json"},
            json=json_body,
            timeout=15,
        )
        resp.raise_for_status()
        # Some POST endpoints return 202 with no body
        if resp.status_code == 202 or not resp.content:
            return {"status": "accepted"}
        return resp.json()


async def graph_patch(token: str, path: str, json_body: dict) -> dict:
    """PATCH request to Microsoft Graph API."""
    async with httpx.AsyncClient() as client:
        resp = await client.patch(
            f"{GRAPH_BASE}{path}",
            headers={**_auth_headers(token), "Content-Type": "application/json"},
            json=json_body,
            timeout=15,
        )
        resp.raise_for_status()
        if not resp.content:
            return {"status": "updated"}
        return resp.json()


async def graph_delete(token: str, path: str) -> None:
    """DELETE request to Microsoft Graph API."""
    async with httpx.AsyncClient() as client:
        resp = await client.delete(
            f"{GRAPH_BASE}{path}",
            headers=_auth_headers(token),
            timeout=15,
        )
        resp.raise_for_status()


async def graph_put_content(token: str, path: str, content: bytes, content_type: str = "application/octet-stream") -> dict:
    """PUT request with raw content (for file uploads)."""
    async with httpx.AsyncClient() as client:
        resp = await client.put(
            f"{GRAPH_BASE}{path}",
            headers={**_auth_headers(token), "Content-Type": content_type},
            content=content,
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json()


def no_account_error() -> str:
    return json.dumps({"error": "No active Microsoft account connected. Visit /integrations to connect one."})
