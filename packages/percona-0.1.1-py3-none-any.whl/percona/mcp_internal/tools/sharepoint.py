"""SharePoint MCP tools — access sites, document libraries, and files via Microsoft Graph API."""

import base64
import json
import logging

from fastmcp import FastMCP

from percona.mcp_internal.tools._microsoft_graph import (
    graph_get,
    graph_get_raw,
    graph_put_content,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def sharepoint_list_sites(
        query: str = "",
        max_results: int = 20,
        account_id: str | None = None,
    ) -> str:
        """List or search SharePoint sites the user has access to.

        Args:
            query: Search query to find sites by name. If empty, lists followed sites.
            max_results: Max sites to return (1-50).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(50, max_results))

            if query:
                data = await graph_get(token, "/sites", {
                    "$search": query,
                    "$top": str(max_results),
                    "$select": "id,displayName,webUrl,description",
                })
            else:
                data = await graph_get(token, "/me/followedSites", {
                    "$top": str(max_results),
                    "$select": "id,displayName,webUrl,description",
                })

            sites = [
                {
                    "id": s["id"],
                    "name": s.get("displayName"),
                    "url": s.get("webUrl"),
                    "description": s.get("description", ""),
                }
                for s in data.get("value", [])
            ]

            logger.info("sharepoint_list_sites account=%s count=%d", email_addr, len(sites))
            return json.dumps({"account": email_addr, "sites": sites, "total": len(sites)})

        except Exception as e:
            logger.error("sharepoint_list_sites_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def sharepoint_list_files(
        site_id: str,
        folder_id: str = "",
        path: str = "",
        max_results: int = 25,
        account_id: str | None = None,
    ) -> str:
        """List files and folders in a SharePoint site's default document library.

        Args:
            site_id: SharePoint site ID from sharepoint_list_sites.
            folder_id: Folder item ID to list contents of. Lists root if omitted.
            path: Folder path (e.g. "/General/Reports"). Alternative to folder_id.
            max_results: Max items to return (1-200).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(200, max_results))

            if folder_id:
                api_path = f"/sites/{site_id}/drive/items/{folder_id}/children"
            elif path:
                clean_path = path.strip("/")
                api_path = f"/sites/{site_id}/drive/root:/{clean_path}:/children"
            else:
                api_path = f"/sites/{site_id}/drive/root/children"

            data = await graph_get(token, api_path, {
                "$top": str(max_results),
                "$select": "id,name,size,lastModifiedDateTime,folder,file,webUrl",
                "$orderby": "name",
            })

            items = []
            for item in data.get("value", []):
                is_folder = "folder" in item
                items.append({
                    "id": item["id"],
                    "name": item.get("name"),
                    "type": "folder" if is_folder else "file",
                    "size": item.get("size", 0),
                    "mime_type": item.get("file", {}).get("mimeType", "") if not is_folder else "",
                    "last_modified": item.get("lastModifiedDateTime"),
                    "web_url": item.get("webUrl"),
                    "child_count": item.get("folder", {}).get("childCount") if is_folder else None,
                })

            logger.info("sharepoint_list_files account=%s site=%s count=%d", email_addr, site_id, len(items))
            return json.dumps({"account": email_addr, "site_id": site_id, "items": items, "total": len(items)})

        except Exception as e:
            logger.error("sharepoint_list_files_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def sharepoint_download_file(
        site_id: str,
        item_id: str,
        account_id: str | None = None,
    ) -> str:
        """Download/read file content from a SharePoint site.

        Returns text content for text files, base64-encoded content for binary files.
        Maximum file size: 10 MB.

        Args:
            site_id: SharePoint site ID.
            item_id: File item ID from sharepoint_list_files.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            meta = await graph_get(token, f"/sites/{site_id}/drive/items/{item_id}", {
                "$select": "id,name,size,file",
            })
            size = meta.get("size", 0)
            if size > 10 * 1024 * 1024:
                return json.dumps({"error": f"File too large ({size} bytes). Max 10 MB."})

            mime_type = meta.get("file", {}).get("mimeType", "application/octet-stream")
            raw = await graph_get_raw(token, f"/sites/{site_id}/drive/items/{item_id}/content")

            is_text = mime_type.startswith("text/") or mime_type in (
                "application/json", "application/xml", "application/javascript",
                "application/x-yaml", "application/yaml",
            )

            if is_text:
                content = raw.decode("utf-8", errors="replace")[:50000]
                encoding = "text"
            else:
                content = base64.b64encode(raw).decode()
                encoding = "base64"

            logger.info("sharepoint_download_file account=%s name=%s size=%d", email_addr, meta.get("name"), size)
            return json.dumps({
                "id": meta["id"],
                "name": meta.get("name"),
                "mime_type": mime_type,
                "size": size,
                "encoding": encoding,
                "content": content,
            })

        except Exception as e:
            logger.error("sharepoint_download_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def sharepoint_upload_file(
        site_id: str,
        path: str,
        content: str,
        content_type: str = "text/plain",
        account_id: str | None = None,
    ) -> str:
        """Upload or create a file in a SharePoint site's default document library.

        For files up to 4 MB. Creates or overwrites the file at the given path.

        Args:
            site_id: SharePoint site ID.
            path: Destination path (e.g. "/General/report.txt").
            content: File content as text.
            content_type: MIME type (e.g. "text/plain", "application/json").
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            clean_path = path.strip("/")
            api_path = f"/sites/{site_id}/drive/root:/{clean_path}:/content"
            raw = content.encode("utf-8")

            if len(raw) > 4 * 1024 * 1024:
                return json.dumps({"error": "Content too large. Max 4 MB for simple upload."})

            result = await graph_put_content(token, api_path, raw, content_type)

            logger.info("sharepoint_upload_file account=%s site=%s path=%s", email_addr, site_id, path)
            return json.dumps({
                "status": "uploaded",
                "id": result.get("id"),
                "name": result.get("name"),
                "size": result.get("size"),
                "web_url": result.get("webUrl"),
            })

        except Exception as e:
            logger.error("sharepoint_upload_file_error: %s", e)
            return json.dumps({"error": str(e)})
