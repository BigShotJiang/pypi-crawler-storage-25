import html
import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from sqlalchemy import select

from percona.context import get_user_id
from percona.database import async_session_factory
from percona.models import Report, Session
from percona.services.storage import upload_file

logger = logging.getLogger(__name__)

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  *, *::before, *::after {{ box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    max-width: 960px; margin: 48px auto; padding: 0 24px;
    color: #1a202c; background: #fff; line-height: 1.75; font-size: 16px;
  }}
  h1 {{ font-size: 2em; color: #1a202c; border-bottom: 3px solid #4299e1; padding-bottom: .4em; margin-bottom: .6em; }}
  h2 {{ font-size: 1.5em; color: #2d3748; border-bottom: 1px solid #e2e8f0; padding-bottom: .3em; margin-top: 2em; }}
  h3 {{ font-size: 1.2em; color: #4a5568; margin-top: 1.5em; }}
  h4, h5, h6 {{ color: #718096; margin-top: 1.2em; }}
  a {{ color: #4299e1; text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  code {{
    background: #edf2f7; color: #c53030; padding: 2px 6px;
    border-radius: 4px; font-size: .875em; font-family: "SFMono-Regular", Consolas, monospace;
  }}
  pre {{
    background: #1a202c; color: #e2e8f0; padding: 1.2em 1.4em;
    border-radius: 8px; overflow-x: auto; margin: 1.2em 0;
  }}
  pre code {{ background: transparent; color: inherit; padding: 0; font-size: .9em; }}
  table {{ border-collapse: collapse; width: 100%; margin: 1.2em 0; font-size: .95em; }}
  th {{
    background: #4299e1; color: #fff; padding: 10px 14px;
    text-align: left; font-weight: 600;
  }}
  td {{ border: 1px solid #e2e8f0; padding: 9px 14px; }}
  tr:nth-child(even) td {{ background: #f7fafc; }}
  blockquote {{
    border-left: 4px solid #4299e1; margin: 1em 0; padding: .8em 1.2em;
    background: #ebf8ff; color: #2c5282; border-radius: 0 6px 6px 0;
  }}
  blockquote p {{ margin: 0; }}
  ul, ol {{ padding-left: 1.6em; }}
  li {{ margin: .3em 0; }}
  hr {{ border: none; border-top: 2px solid #e2e8f0; margin: 2em 0; }}
  img {{ max-width: 100%; border-radius: 6px; }}
  .report-header {{
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff; padding: 32px 36px; border-radius: 12px; margin-bottom: 2em;
  }}
  .report-header h1 {{ color: #fff; border-bottom-color: rgba(255,255,255,.4); }}
  .report-header p {{ margin: 0; opacity: .85; font-size: .95em; }}
</style>
</head>
<body>
<div class="report-header">
  <h1>{title}</h1>
</div>
{body}
</body>
</html>"""


def _markdown_to_html_body(md: str) -> str:
    try:
        import markdown  # type: ignore
        return markdown.markdown(md, extensions=["extra", "tables", "fenced_code"])
    except Exception:
        return f"<pre>{html.escape(md)}</pre>"


def _build_report_html(title: str, content_md: str | None, content_html: str | None) -> bytes:
    if content_html and (
        content_html.lstrip().lower().startswith("<!doctype")
        or content_html.lstrip().lower().startswith("<html")
    ):
        return content_html.encode("utf-8")

    if content_html:
        body = content_html
    elif content_md:
        body = _markdown_to_html_body(content_md)
    else:
        body = "<p><em>No content provided.</em></p>"

    doc = _HTML_TEMPLATE.format(
        title=html.escape(title),
        body=body,
    )
    return doc.encode("utf-8")


def register(mcp: FastMCP):
    @mcp.tool()
    async def create_report(
        title: str,
        content_md: str | None = None,
        content_html: str | None = None,
        session_id: str | None = None,
    ) -> str:
        """Create a session report and upload to S3. One per session (upserts). Returns public_url.

        Prefer content_html for polished output; content_md is auto-converted to styled HTML.

        Args:
            title: Report title
            content_md: Markdown content
            content_html: HTML content (full document or body fragment)
            session_id: Current session ID
        """
        try:
            sid = uuid.UUID(session_id) if session_id else None
            async with async_session_factory() as db:
                task_id = None
                if sid:
                    result = await db.execute(select(Session.task_id).where(Session.id == sid))
                    row = result.one_or_none()
                    if row:
                        task_id = row[0]

                # Upsert: check if report exists for this session
                report = None
                if sid:
                    result = await db.execute(select(Report).where(Report.session_id == sid))
                    report = result.scalar_one_or_none()

                if report:
                    report.title = title
                    logger.info("report_updating session_id=%s report_id=%s", session_id, report.id)
                else:
                    report = Report(
                        user_id=get_user_id(),
                        task_id=task_id,
                        session_id=sid,
                        title=title,
                    )
                    db.add(report)
                    await db.flush()
                    logger.info("report_created session_id=%s report_id=%s", session_id or "none", report.id)

                # Build HTML and upload to S3
                html_bytes = _build_report_html(title, content_md, content_html)
                filename = f"report-{report.id}.html"
                upload_result = upload_file(html_bytes, filename, "text/html")
                report.s3_url = upload_result["s3_url"]

                await db.commit()
                logger.info("report_uploaded report_id=%s url=%s", report.id, report.s3_url)
                return json.dumps({
                    "id": str(report.id),
                    "title": report.title,
                    "public_url": report.s3_url,
                    "status": "created",
                })
        except Exception as e:
            logger.error("create_report_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
