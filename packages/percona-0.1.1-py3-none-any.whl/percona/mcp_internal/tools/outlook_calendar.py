"""Outlook Calendar MCP tools — manage events via Microsoft Graph API."""

import json
import logging
from datetime import datetime, timezone

from fastmcp import FastMCP

from percona.mcp_internal.tools._microsoft_graph import (
    graph_delete,
    graph_get,
    graph_patch,
    graph_post,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def outlook_list_calendars(
        account_id: str | None = None,
    ) -> str:
        """List all calendars in the connected Microsoft account.

        Args:
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            data = await graph_get(token, "/me/calendars", {
                "$select": "id,name,color,isDefaultCalendar,canEdit",
            })

            calendars = [
                {
                    "id": cal["id"],
                    "name": cal.get("name"),
                    "color": cal.get("color"),
                    "is_default": cal.get("isDefaultCalendar", False),
                    "can_edit": cal.get("canEdit", True),
                }
                for cal in data.get("value", [])
            ]

            logger.info("outlook_list_calendars account=%s count=%d", email_addr, len(calendars))
            return json.dumps({"account": email_addr, "calendars": calendars})

        except Exception as e:
            logger.error("outlook_list_calendars_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_list_events(
        start_date: str = "",
        end_date: str = "",
        calendar_id: str = "",
        max_results: int = 20,
        account_id: str | None = None,
    ) -> str:
        """List calendar events within a date range.

        Args:
            start_date: Start datetime in ISO 8601 format (e.g. "2025-01-01T00:00:00"). Defaults to now.
            end_date: End datetime in ISO 8601 format (e.g. "2025-01-31T23:59:59"). Defaults to 7 days from start.
            calendar_id: Calendar ID from outlook_list_calendars. Uses default calendar if omitted.
            max_results: Max events to return (1-100).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(100, max_results))

            if not start_date:
                start_date = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
            if not end_date:
                # Default to 7 days from start
                from datetime import timedelta
                try:
                    start_dt = datetime.fromisoformat(start_date.replace("Z", "+00:00"))
                except ValueError:
                    start_dt = datetime.now(timezone.utc)
                end_date = (start_dt + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%S")

            base = f"/me/calendars/{calendar_id}" if calendar_id else "/me"
            data = await graph_get(token, f"{base}/calendarView", {
                "startDateTime": start_date,
                "endDateTime": end_date,
                "$top": str(max_results),
                "$select": "id,subject,start,end,location,organizer,isAllDay,isCancelled,responseStatus",
                "$orderby": "start/dateTime",
            })

            events = []
            for evt in data.get("value", []):
                organizer = evt.get("organizer", {}).get("emailAddress", {})
                location = evt.get("location", {})
                events.append({
                    "id": evt["id"],
                    "subject": evt.get("subject", "(no title)"),
                    "start": evt.get("start", {}).get("dateTime"),
                    "start_timezone": evt.get("start", {}).get("timeZone"),
                    "end": evt.get("end", {}).get("dateTime"),
                    "end_timezone": evt.get("end", {}).get("timeZone"),
                    "is_all_day": evt.get("isAllDay", False),
                    "is_cancelled": evt.get("isCancelled", False),
                    "location": location.get("displayName", ""),
                    "organizer": organizer.get("address", ""),
                    "response_status": evt.get("responseStatus", {}).get("response"),
                })

            logger.info("outlook_list_events account=%s count=%d", email_addr, len(events))
            return json.dumps({"account": email_addr, "events": events, "total": len(events)})

        except Exception as e:
            logger.error("outlook_list_events_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_get_event(
        event_id: str,
        account_id: str | None = None,
    ) -> str:
        """Get full details of a specific calendar event.

        Args:
            event_id: Event ID from outlook_list_events.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            evt = await graph_get(token, f"/me/events/{event_id}", {
                "$select": "id,subject,body,start,end,location,organizer,attendees,isAllDay,isCancelled,recurrence,onlineMeeting,webLink",
            })

            organizer = evt.get("organizer", {}).get("emailAddress", {})
            attendees = [
                {
                    "email": a.get("emailAddress", {}).get("address", ""),
                    "name": a.get("emailAddress", {}).get("name", ""),
                    "status": a.get("status", {}).get("response"),
                }
                for a in evt.get("attendees", [])
            ]

            result = {
                "id": evt["id"],
                "subject": evt.get("subject", "(no title)"),
                "body": evt.get("body", {}).get("content", "")[:16000],
                "start": evt.get("start", {}).get("dateTime"),
                "start_timezone": evt.get("start", {}).get("timeZone"),
                "end": evt.get("end", {}).get("dateTime"),
                "end_timezone": evt.get("end", {}).get("timeZone"),
                "is_all_day": evt.get("isAllDay", False),
                "is_cancelled": evt.get("isCancelled", False),
                "location": evt.get("location", {}).get("displayName", ""),
                "organizer": organizer.get("address", ""),
                "attendees": attendees,
                "web_link": evt.get("webLink"),
                "online_meeting_url": (evt.get("onlineMeeting") or {}).get("joinUrl"),
                "recurrence": evt.get("recurrence"),
            }

            logger.info("outlook_get_event account=%s event_id=%s", email_addr, event_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("outlook_get_event_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_create_event(
        subject: str,
        start: str,
        end: str,
        timezone: str = "UTC",
        location: str = "",
        body: str = "",
        attendees: str = "",
        is_all_day: bool = False,
        calendar_id: str = "",
        account_id: str | None = None,
    ) -> str:
        """Create a new calendar event.

        Args:
            subject: Event title.
            start: Start datetime in ISO 8601 format (e.g. "2025-03-15T10:00:00").
            end: End datetime in ISO 8601 format (e.g. "2025-03-15T11:00:00").
            timezone: Timezone for start/end (e.g. "UTC", "America/New_York"). Default: UTC.
            location: Location display name. Optional.
            body: Event description (plain text). Optional.
            attendees: Comma-separated email addresses of attendees. Optional.
            is_all_day: Whether this is an all-day event.
            calendar_id: Calendar ID. Uses default calendar if omitted.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            event_body: dict = {
                "subject": subject,
                "start": {"dateTime": start, "timeZone": timezone},
                "end": {"dateTime": end, "timeZone": timezone},
                "isAllDay": is_all_day,
            }

            if location:
                event_body["location"] = {"displayName": location}
            if body:
                event_body["body"] = {"contentType": "Text", "content": body}
            if attendees:
                event_body["attendees"] = [
                    {"emailAddress": {"address": addr.strip()}, "type": "required"}
                    for addr in attendees.split(",") if addr.strip()
                ]

            path = f"/me/calendars/{calendar_id}/events" if calendar_id else "/me/events"
            result = await graph_post(token, path, event_body)

            logger.info("outlook_create_event account=%s subject=%s", email_addr, subject)
            return json.dumps({
                "status": "created",
                "id": result.get("id"),
                "subject": result.get("subject"),
                "start": result.get("start", {}).get("dateTime"),
                "end": result.get("end", {}).get("dateTime"),
                "web_link": result.get("webLink"),
            })

        except Exception as e:
            logger.error("outlook_create_event_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_update_event(
        event_id: str,
        subject: str = "",
        start: str = "",
        end: str = "",
        timezone: str = "",
        location: str | None = None,
        body: str | None = None,
        account_id: str | None = None,
    ) -> str:
        """Update an existing calendar event. Only provide fields you want to change.

        Args:
            event_id: Event ID to update.
            subject: New event title.
            start: New start datetime in ISO 8601 format.
            end: New end datetime in ISO 8601 format.
            timezone: Timezone for start/end.
            location: New location display name.
            body: New event description.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            patch_body: dict = {}
            tz = timezone or "UTC"
            if subject:
                patch_body["subject"] = subject
            if start:
                patch_body["start"] = {"dateTime": start, "timeZone": tz}
            if end:
                patch_body["end"] = {"dateTime": end, "timeZone": tz}
            if location is not None:
                patch_body["location"] = {"displayName": location}
            if body is not None:
                patch_body["body"] = {"contentType": "Text", "content": body}

            if not patch_body:
                return json.dumps({"error": "No fields to update"})

            result = await graph_patch(token, f"/me/events/{event_id}", patch_body)

            logger.info("outlook_update_event account=%s event_id=%s", email_addr, event_id)
            return json.dumps({
                "status": "updated",
                "id": result.get("id", event_id),
                "subject": result.get("subject"),
            })

        except Exception as e:
            logger.error("outlook_update_event_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_delete_event(
        event_id: str,
        account_id: str | None = None,
    ) -> str:
        """Delete a calendar event.

        Args:
            event_id: Event ID to delete.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            await graph_delete(token, f"/me/events/{event_id}")

            logger.info("outlook_delete_event account=%s event_id=%s", email_addr, event_id)
            return json.dumps({"status": "deleted", "event_id": event_id})

        except Exception as e:
            logger.error("outlook_delete_event_error: %s", e)
            return json.dumps({"error": str(e)})
