"""Microsoft Contacts MCP tools — access contacts and people via Microsoft Graph API."""

import json
import logging

from fastmcp import FastMCP

from percona.mcp_internal.tools._microsoft_graph import (
    graph_get,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def _format_contact(c: dict) -> dict:
    """Extract key fields from a Graph contact object."""
    emails = [e.get("address", "") for e in c.get("emailAddresses", []) if e.get("address")]
    phones = [p.get("number", "") for p in c.get("phones", []) if p.get("number")]
    return {
        "id": c.get("id"),
        "display_name": c.get("displayName"),
        "given_name": c.get("givenName"),
        "surname": c.get("surname"),
        "emails": emails,
        "phones": phones,
        "company": c.get("companyName"),
        "job_title": c.get("jobTitle"),
        "department": c.get("department"),
    }


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def contacts_list(
        max_results: int = 25,
        account_id: str | None = None,
    ) -> str:
        """List contacts from Outlook.

        Args:
            max_results: Max contacts to return (1-200).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(200, max_results))
            data = await graph_get(token, "/me/contacts", {
                "$top": str(max_results),
                "$select": "id,displayName,givenName,surname,emailAddresses,phones,companyName,jobTitle,department",
                "$orderby": "displayName",
            })

            contacts = [_format_contact(c) for c in data.get("value", [])]

            logger.info("contacts_list account=%s count=%d", email_addr, len(contacts))
            return json.dumps({"account": email_addr, "contacts": contacts, "total": len(contacts)})

        except Exception as e:
            logger.error("contacts_list_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def contacts_search(
        query: str,
        max_results: int = 10,
        account_id: str | None = None,
    ) -> str:
        """Search contacts and people by name or email.

        Uses the Microsoft People API which searches across contacts, directory, and recent communications.

        Args:
            query: Search query (name, email, etc.).
            max_results: Max results to return (1-50).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(50, max_results))
            data = await graph_get(token, "/me/people", {
                "$search": f'"{query}"',
                "$top": str(max_results),
                "$select": "id,displayName,givenName,surname,emailAddresses,phones,companyName,jobTitle,department",
            })

            people = []
            for p in data.get("value", []):
                emails = [e.get("address", "") for e in p.get("emailAddresses", []) if e.get("address")]
                phones = [ph.get("number", "") for ph in p.get("phones", []) if ph.get("number")]
                people.append({
                    "id": p.get("id"),
                    "display_name": p.get("displayName"),
                    "given_name": p.get("givenName"),
                    "surname": p.get("surname"),
                    "emails": emails,
                    "phones": phones,
                    "company": p.get("companyName"),
                    "job_title": p.get("jobTitle"),
                    "department": p.get("department"),
                })

            logger.info("contacts_search account=%s query=%s count=%d", email_addr, query, len(people))
            return json.dumps({"account": email_addr, "query": query, "people": people, "total": len(people)})

        except Exception as e:
            logger.error("contacts_search_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def contacts_get(
        contact_id: str,
        account_id: str | None = None,
    ) -> str:
        """Get full details of a specific contact.

        Args:
            contact_id: Contact ID from contacts_list.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            c = await graph_get(token, f"/me/contacts/{contact_id}", {
                "$select": "id,displayName,givenName,surname,emailAddresses,phones,companyName,jobTitle,department,businessAddress,homeAddress,birthday,personalNotes",
            })

            result = _format_contact(c)
            # Add extra detail fields
            result["birthday"] = c.get("birthday")
            result["notes"] = (c.get("personalNotes") or "")[:4000]
            for addr_type in ("businessAddress", "homeAddress"):
                addr = c.get(addr_type)
                if addr and any(addr.values()):
                    result[addr_type] = {
                        "street": addr.get("street", ""),
                        "city": addr.get("city", ""),
                        "state": addr.get("state", ""),
                        "postal_code": addr.get("postalCode", ""),
                        "country": addr.get("countryOrRegion", ""),
                    }

            logger.info("contacts_get account=%s contact_id=%s", email_addr, contact_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("contacts_get_error: %s", e)
            return json.dumps({"error": str(e)})
