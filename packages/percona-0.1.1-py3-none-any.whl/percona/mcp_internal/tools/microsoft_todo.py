"""Microsoft To Do MCP tools — manage task lists and tasks via Microsoft Graph API."""

import json
import logging

from fastmcp import FastMCP

from percona.mcp_internal.tools._microsoft_graph import (
    graph_delete,
    graph_get,
    graph_patch,
    graph_post,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def todo_list_lists(
        account_id: str | None = None,
    ) -> str:
        """List all To Do task lists.

        Args:
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            data = await graph_get(token, "/me/todo/lists", {
                "$select": "id,displayName,isOwner,wellknownListName",
            })

            lists = [
                {
                    "id": lst["id"],
                    "name": lst.get("displayName"),
                    "is_owner": lst.get("isOwner", True),
                    "wellknown_name": lst.get("wellknownListName"),
                }
                for lst in data.get("value", [])
            ]

            logger.info("todo_list_lists account=%s count=%d", email_addr, len(lists))
            return json.dumps({"account": email_addr, "lists": lists, "total": len(lists)})

        except Exception as e:
            logger.error("todo_list_lists_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def todo_list_tasks(
        list_id: str,
        status: str = "",
        max_results: int = 25,
        account_id: str | None = None,
    ) -> str:
        """List tasks in a To Do task list.

        Args:
            list_id: Task list ID from todo_list_lists.
            status: Filter by status — "notStarted", "inProgress", "completed", or "" for all.
            max_results: Max tasks to return (1-100).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(100, max_results))
            params: dict[str, str] = {
                "$top": str(max_results),
                "$select": "id,title,status,importance,createdDateTime,dueDateTime,completedDateTime,body",
                "$orderby": "createdDateTime desc",
            }
            if status:
                params["$filter"] = f"status eq '{status}'"

            data = await graph_get(token, f"/me/todo/lists/{list_id}/tasks", params)

            tasks = []
            for task in data.get("value", []):
                due = task.get("dueDateTime")
                completed = task.get("completedDateTime")
                tasks.append({
                    "id": task["id"],
                    "title": task.get("title"),
                    "status": task.get("status"),
                    "importance": task.get("importance"),
                    "created": task.get("createdDateTime"),
                    "due_date": due.get("dateTime") if due else None,
                    "due_timezone": due.get("timeZone") if due else None,
                    "completed_date": completed.get("dateTime") if completed else None,
                    "body": (task.get("body") or {}).get("content", "")[:4000],
                })

            logger.info("todo_list_tasks account=%s list_id=%s count=%d", email_addr, list_id, len(tasks))
            return json.dumps({"account": email_addr, "list_id": list_id, "tasks": tasks, "total": len(tasks)})

        except Exception as e:
            logger.error("todo_list_tasks_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def todo_create_task(
        list_id: str,
        title: str,
        body: str = "",
        due_date: str = "",
        importance: str = "normal",
        account_id: str | None = None,
    ) -> str:
        """Create a new task in a To Do list.

        Args:
            list_id: Task list ID from todo_list_lists.
            title: Task title.
            body: Task description (plain text). Optional.
            due_date: Due date in ISO 8601 format (e.g. "2025-03-20T00:00:00"). Optional.
            importance: Priority — "low", "normal", or "high". Default: normal.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            task_body: dict = {
                "title": title,
                "importance": importance,
            }
            if body:
                task_body["body"] = {"contentType": "text", "content": body}
            if due_date:
                task_body["dueDateTime"] = {"dateTime": due_date, "timeZone": "UTC"}

            result = await graph_post(token, f"/me/todo/lists/{list_id}/tasks", task_body)

            logger.info("todo_create_task account=%s title=%s", email_addr, title)
            return json.dumps({
                "status": "created",
                "id": result.get("id"),
                "title": result.get("title"),
                "importance": result.get("importance"),
            })

        except Exception as e:
            logger.error("todo_create_task_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def todo_update_task(
        list_id: str,
        task_id: str,
        title: str = "",
        body: str | None = None,
        due_date: str | None = None,
        importance: str = "",
        account_id: str | None = None,
    ) -> str:
        """Update an existing To Do task. Only provide fields you want to change.

        Args:
            list_id: Task list ID.
            task_id: Task ID to update.
            title: New task title.
            body: New task description.
            due_date: New due date in ISO 8601 format. Set to empty string to clear.
            importance: New priority — "low", "normal", or "high".
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            patch_body: dict = {}
            if title:
                patch_body["title"] = title
            if body is not None:
                patch_body["body"] = {"contentType": "text", "content": body}
            if due_date is not None:
                if due_date:
                    patch_body["dueDateTime"] = {"dateTime": due_date, "timeZone": "UTC"}
                else:
                    patch_body["dueDateTime"] = None
            if importance:
                patch_body["importance"] = importance

            if not patch_body:
                return json.dumps({"error": "No fields to update"})

            result = await graph_patch(token, f"/me/todo/lists/{list_id}/tasks/{task_id}", patch_body)

            logger.info("todo_update_task account=%s task_id=%s", email_addr, task_id)
            return json.dumps({
                "status": "updated",
                "id": result.get("id", task_id),
                "title": result.get("title"),
            })

        except Exception as e:
            logger.error("todo_update_task_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def todo_complete_task(
        list_id: str,
        task_id: str,
        account_id: str | None = None,
    ) -> str:
        """Mark a To Do task as completed.

        Args:
            list_id: Task list ID.
            task_id: Task ID to complete.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            result = await graph_patch(token, f"/me/todo/lists/{list_id}/tasks/{task_id}", {
                "status": "completed",
            })

            logger.info("todo_complete_task account=%s task_id=%s", email_addr, task_id)
            return json.dumps({
                "status": "completed",
                "id": result.get("id", task_id),
                "title": result.get("title"),
            })

        except Exception as e:
            logger.error("todo_complete_task_error: %s", e)
            return json.dumps({"error": str(e)})
