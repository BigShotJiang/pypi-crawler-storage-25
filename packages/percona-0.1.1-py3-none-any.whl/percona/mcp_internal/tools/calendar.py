import asyncio
import json
import logging
import uuid
from functools import partial
from datetime import datetime, timedelta

from fastmcp import FastMCP
from sqlalchemy import select

from percona.context import get_user_id
from percona.database import async_session_factory
from percona.models import ConnectedAccount
from percona.services import oauth_service

logger = logging.getLogger(__name__)


def _build_calendar_service(access_token: str):
    """Build a Google Calendar API service from a raw access token."""
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build

    creds = Credentials(token=access_token)
    return build("calendar", "v3", credentials=creds, cache_discovery=False)


async def _resolve_account(account_id: str | None) -> tuple[str, str]:
    """Return (access_token, provider_email) for the given account_id or first active account.

    Enforces project isolation: only accounts belonging to the current project are accessible.
    """
    user_id = get_user_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", ""
            # Verify account belongs to this project
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.user_id == user_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, aid)
            email_addr = account.provider_email
        else:
            account = await oauth_service.get_first_active_account(db, user_id, "google")
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, account.id)
            email_addr = account.provider_email
    return token, email_addr


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def calendar_list_calendars(account_id: str | None = None) -> str:
        """List all calendars for the user.

        Args:
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected. Connect one at /integrations."})

            loop = asyncio.get_event_loop()
            calendar = _build_calendar_service(access_token)

            list_fn = partial(calendar.calendarList().list(maxResults=250).execute)
            result = await loop.run_in_executor(None, list_fn)

            calendars = []
            for cal in result.get("items", []):
                calendars.append({
                    "id": cal.get("id"),
                    "summary": cal.get("summary"),
                    "description": cal.get("description", ""),
                    "timezone": cal.get("timeZone"),
                    "primary": cal.get("primary", False),
                })

            logger.info("calendar_list_calendars account=%s count=%d", email_addr, len(calendars))
            return json.dumps({"account": email_addr, "calendars": calendars, "total": len(calendars)})

        except Exception as e:
            logger.error("calendar_list_calendars_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def calendar_list_events(
        calendar_id: str,
        start_date: str | None = None,
        end_date: str | None = None,
        max_results: int = 10,
        account_id: str | None = None,
    ) -> str:
        """List events in a calendar. Dates must be YYYY-MM-DD format (not RFC3339).

        Args:
            calendar_id: Calendar ID (e.g. "primary")
            start_date: Start date YYYY-MM-DD (defaults to today)
            end_date: End date YYYY-MM-DD (defaults to 30 days from start)
            max_results: Max events (1-250)
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            max_results = max(1, min(250, max_results))

            # Parse dates
            if not start_date:
                start_date = datetime.now().date().isoformat()
            if not end_date:
                end_date = (datetime.now() + timedelta(days=30)).date().isoformat()

            loop = asyncio.get_event_loop()
            calendar = _build_calendar_service(access_token)

            list_fn = partial(
                calendar.events()
                .list(
                    calendarId=calendar_id,
                    timeMin=f"{start_date}T00:00:00Z",
                    timeMax=f"{end_date}T23:59:59Z",
                    maxResults=max_results,
                    orderBy="startTime",
                    singleEvents=True,
                )
                .execute
            )
            result = await loop.run_in_executor(None, list_fn)

            events = []
            for event in result.get("items", []):
                start = event.get("start", {})
                end = event.get("end", {})
                events.append({
                    "id": event.get("id"),
                    "summary": event.get("summary", "(no title)"),
                    "start": start.get("dateTime") or start.get("date"),
                    "end": end.get("dateTime") or end.get("date"),
                    "location": event.get("location", ""),
                    "attendees": [
                        {"email": att.get("email"), "status": att.get("responseStatus")}
                        for att in event.get("attendees", [])
                    ],
                    "description": event.get("description", ""),
                })

            logger.info("calendar_list_events account=%s calendar=%s count=%d", email_addr, calendar_id, len(events))
            return json.dumps({"account": email_addr, "calendar_id": calendar_id, "events": events, "total": len(events)})

        except Exception as e:
            logger.error("calendar_list_events_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def calendar_create_event(
        calendar_id: str,
        summary: str,
        start_time: str,
        end_time: str,
        description: str = "",
        location: str = "",
        attendees: list[str] | None = None,
        account_id: str | None = None,
    ) -> str:
        """Create a new event in a calendar.

        Args:
            calendar_id: Calendar ID (e.g. "primary")
            summary: Event title
            start_time: Start time in RFC3339 (e.g. "2026-03-01T10:00:00Z")
            end_time: End time in RFC3339
            description: Event description
            location: Event location
            attendees: Attendee email addresses
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            event = {
                "summary": summary,
                "start": {"dateTime": start_time},
                "end": {"dateTime": end_time},
            }
            if description:
                event["description"] = description
            if location:
                event["location"] = location
            if attendees:
                event["attendees"] = [{"email": email} for email in attendees]

            loop = asyncio.get_event_loop()
            calendar = _build_calendar_service(access_token)

            create_fn = partial(calendar.events().insert(calendarId=calendar_id, body=event).execute)
            result = await loop.run_in_executor(None, create_fn)

            logger.info("calendar_create_event account=%s calendar=%s event=%s", email_addr, calendar_id, result.get("id"))
            return json.dumps({
                "account": email_addr,
                "event_id": result.get("id"),
                "summary": result.get("summary"),
                "start": result.get("start", {}).get("dateTime") or result.get("start", {}).get("date"),
                "end": result.get("end", {}).get("dateTime") or result.get("end", {}).get("date"),
                "status": "created",
            })

        except Exception as e:
            logger.error("calendar_create_event_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def calendar_update_event(
        calendar_id: str,
        event_id: str,
        summary: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        description: str | None = None,
        location: str | None = None,
        account_id: str | None = None,
    ) -> str:
        """Update an existing calendar event.

        Args:
            calendar_id: Calendar ID
            event_id: Event ID to update
            summary: New title
            start_time: New start time in RFC3339
            end_time: New end time in RFC3339
            description: New description
            location: New location
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            loop = asyncio.get_event_loop()
            calendar = _build_calendar_service(access_token)

            # Fetch existing event
            get_fn = partial(calendar.events().get(calendarId=calendar_id, eventId=event_id).execute)
            event = await loop.run_in_executor(None, get_fn)

            # Update fields
            if summary is not None:
                event["summary"] = summary
            if start_time is not None:
                event["start"] = {"dateTime": start_time}
            if end_time is not None:
                event["end"] = {"dateTime": end_time}
            if description is not None:
                event["description"] = description
            if location is not None:
                event["location"] = location

            # Save updated event
            update_fn = partial(calendar.events().update(calendarId=calendar_id, eventId=event_id, body=event).execute)
            result = await loop.run_in_executor(None, update_fn)

            logger.info("calendar_update_event account=%s calendar=%s event=%s", email_addr, calendar_id, event_id)
            return json.dumps({
                "account": email_addr,
                "event_id": result.get("id"),
                "summary": result.get("summary"),
                "status": "updated",
            })

        except Exception as e:
            logger.error("calendar_update_event_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def calendar_delete_event(
        calendar_id: str,
        event_id: str,
        account_id: str | None = None,
    ) -> str:
        """Delete a calendar event.

        Args:
            calendar_id: Calendar ID
            event_id: Event ID to delete
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            loop = asyncio.get_event_loop()
            calendar = _build_calendar_service(access_token)

            delete_fn = partial(calendar.events().delete(calendarId=calendar_id, eventId=event_id).execute)
            await loop.run_in_executor(None, delete_fn)

            logger.info("calendar_delete_event account=%s calendar=%s event=%s", email_addr, calendar_id, event_id)
            return json.dumps({
                "account": email_addr,
                "event_id": event_id,
                "status": "deleted",
            })

        except Exception as e:
            logger.error("calendar_delete_event_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def calendar_get_event(
        calendar_id: str,
        event_id: str,
        account_id: str | None = None,
    ) -> str:
        """Get full details of a calendar event.

        Args:
            calendar_id: Calendar ID
            event_id: Event ID
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            loop = asyncio.get_event_loop()
            calendar = _build_calendar_service(access_token)

            get_fn = partial(calendar.events().get(calendarId=calendar_id, eventId=event_id).execute)
            event = await loop.run_in_executor(None, get_fn)

            start = event.get("start", {})
            end = event.get("end", {})
            result = {
                "account": email_addr,
                "event_id": event.get("id"),
                "summary": event.get("summary", "(no title)"),
                "description": event.get("description", ""),
                "start": start.get("dateTime") or start.get("date"),
                "end": end.get("dateTime") or end.get("date"),
                "location": event.get("location", ""),
                "attendees": [
                    {"email": att.get("email"), "status": att.get("responseStatus")}
                    for att in event.get("attendees", [])
                ],
                "status": event.get("status"),
                "created": event.get("created"),
                "updated": event.get("updated"),
            }

            logger.info("calendar_get_event account=%s calendar=%s event=%s", email_addr, calendar_id, event_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("calendar_get_event_error: %s", e)
            return json.dumps({"error": str(e)})
