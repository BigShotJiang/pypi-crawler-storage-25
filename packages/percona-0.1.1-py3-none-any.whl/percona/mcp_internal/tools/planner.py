"""Microsoft Planner MCP tools — manage plans and tasks via Microsoft Graph API."""

import json
import logging

from fastmcp import FastMCP

from percona.mcp_internal.tools._microsoft_graph import (
    graph_get,
    graph_patch,
    graph_post,
    no_account_error,
    resolve_microsoft_account,
)

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def planner_list_plans(
        account_id: str | None = None,
    ) -> str:
        """List Planner plans the user has access to.

        Args:
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            # Get plans assigned to the user
            data = await graph_get(token, "/me/planner/plans", {
                "$select": "id,title,createdDateTime,owner",
            })

            plans = [
                {
                    "id": p["id"],
                    "title": p.get("title"),
                    "created": p.get("createdDateTime"),
                    "owner_group_id": p.get("owner"),
                }
                for p in data.get("value", [])
            ]

            logger.info("planner_list_plans account=%s count=%d", email_addr, len(plans))
            return json.dumps({"account": email_addr, "plans": plans, "total": len(plans)})

        except Exception as e:
            logger.error("planner_list_plans_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def planner_list_tasks(
        plan_id: str = "",
        max_results: int = 50,
        account_id: str | None = None,
    ) -> str:
        """List Planner tasks. If plan_id is provided, lists tasks in that plan. Otherwise lists tasks assigned to the user.

        Args:
            plan_id: Plan ID from planner_list_plans. If omitted, lists all tasks assigned to the user.
            max_results: Max tasks to return (1-100).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            max_results = max(1, min(100, max_results))

            if plan_id:
                path = f"/planner/plans/{plan_id}/tasks"
            else:
                path = "/me/planner/tasks"

            data = await graph_get(token, path, {
                "$top": str(max_results),
                "$select": "id,title,percentComplete,priority,startDateTime,dueDateTime,createdDateTime,bucketId,assigneePriority,orderHint",
            })

            tasks = []
            for t in data.get("value", []):
                tasks.append({
                    "id": t["id"],
                    "title": t.get("title"),
                    "percent_complete": t.get("percentComplete", 0),
                    "priority": t.get("priority"),
                    "start_date": t.get("startDateTime"),
                    "due_date": t.get("dueDateTime"),
                    "created": t.get("createdDateTime"),
                    "bucket_id": t.get("bucketId"),
                })

            logger.info("planner_list_tasks account=%s plan_id=%s count=%d", email_addr, plan_id or "all", len(tasks))
            return json.dumps({"account": email_addr, "plan_id": plan_id or "all", "tasks": tasks, "total": len(tasks)})

        except Exception as e:
            logger.error("planner_list_tasks_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def planner_create_task(
        plan_id: str,
        title: str,
        bucket_id: str = "",
        due_date: str = "",
        priority: int = 5,
        account_id: str | None = None,
    ) -> str:
        """Create a new Planner task.

        Args:
            plan_id: Plan ID to create the task in.
            title: Task title.
            bucket_id: Bucket ID to place the task in. Optional.
            due_date: Due date in ISO 8601 format (e.g. "2025-03-20T00:00:00Z"). Optional.
            priority: Priority (1=urgent, 3=important, 5=medium, 9=low). Default: 5.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            task_body: dict = {
                "planId": plan_id,
                "title": title,
                "priority": priority,
            }
            if bucket_id:
                task_body["bucketId"] = bucket_id
            if due_date:
                task_body["dueDateTime"] = due_date

            result = await graph_post(token, "/planner/tasks", task_body)

            logger.info("planner_create_task account=%s title=%s", email_addr, title)
            return json.dumps({
                "status": "created",
                "id": result.get("id"),
                "title": result.get("title"),
                "plan_id": plan_id,
            })

        except Exception as e:
            logger.error("planner_create_task_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def planner_update_task(
        task_id: str,
        title: str = "",
        percent_complete: int | None = None,
        priority: int | None = None,
        due_date: str | None = None,
        account_id: str | None = None,
    ) -> str:
        """Update a Planner task. Only provide fields you want to change.

        Note: Planner PATCH requires an If-Match header with the task's etag.
        This tool fetches the current etag automatically.

        Args:
            task_id: Task ID to update.
            title: New task title.
            percent_complete: Completion percentage (0-100). Set to 100 to mark complete.
            priority: Priority (1=urgent, 3=important, 5=medium, 9=low).
            due_date: New due date in ISO 8601 format. Set to empty string to clear.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            token, email_addr = await resolve_microsoft_account(account_id)
            if not token:
                return no_account_error()

            # Planner requires If-Match with current etag
            import httpx
            from percona.mcp_internal.tools._microsoft_graph import GRAPH_BASE

            async with httpx.AsyncClient() as client:
                # Get current etag
                get_resp = await client.get(
                    f"{GRAPH_BASE}/planner/tasks/{task_id}",
                    headers={"Authorization": f"Bearer {token}"},
                    timeout=15,
                )
                get_resp.raise_for_status()
                etag = get_resp.headers.get("ETag", "")

                patch_body: dict = {}
                if title:
                    patch_body["title"] = title
                if percent_complete is not None:
                    patch_body["percentComplete"] = max(0, min(100, percent_complete))
                if priority is not None:
                    patch_body["priority"] = priority
                if due_date is not None:
                    patch_body["dueDateTime"] = due_date if due_date else None

                if not patch_body:
                    return json.dumps({"error": "No fields to update"})

                resp = await client.patch(
                    f"{GRAPH_BASE}/planner/tasks/{task_id}",
                    headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json",
                        "If-Match": etag,
                    },
                    json=patch_body,
                    timeout=15,
                )
                resp.raise_for_status()
                result = resp.json() if resp.content else {}

            logger.info("planner_update_task account=%s task_id=%s", email_addr, task_id)
            return json.dumps({
                "status": "updated",
                "id": result.get("id", task_id),
                "title": result.get("title"),
                "percent_complete": result.get("percentComplete"),
            })

        except Exception as e:
            logger.error("planner_update_task_error: %s", e)
            return json.dumps({"error": str(e)})
