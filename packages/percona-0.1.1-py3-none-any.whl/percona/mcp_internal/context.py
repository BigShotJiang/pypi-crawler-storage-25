import logging
import uuid

from sqlalchemy import select

from percona.database import async_session_factory
from percona.models import Session

logger = logging.getLogger(__name__)


async def get_session_and_task_id(session_id_str: str) -> tuple[uuid.UUID, uuid.UUID | None]:
    """Look up session and return (session_id, task_id)."""
    session_id = uuid.UUID(session_id_str)
    async with async_session_factory() as db:
        result = await db.execute(select(Session.task_id).where(Session.id == session_id))
        row = result.one_or_none()
        task_id = row[0] if row else None
    return session_id, task_id
