"""Supabase Realtime listener for the MeshCode MCP server.

Connects to Supabase Realtime via WebSocket (no supabase-py dep — uses
the `websockets` package directly to keep the install light).

When a new mc_message INSERT arrives for the current agent, it:
  1. Pushes the message into an in-memory deque (consumed by meshcode_check tool)
  2. Calls the registered notify_callback (FastMCP session.send_resource_updated)
"""
import asyncio
import json
import logging
import ssl
from collections import deque
from typing import Any, Awaitable, Callable, Deque, Dict, Optional
from urllib.parse import quote as url_quote

try:
    import certifi
    _SSL_CTX = ssl.create_default_context(cafile=certifi.where())
except Exception:
    # Fallback to system trust store if certifi isn't available.
    try:
        _SSL_CTX = ssl.create_default_context()
    except Exception:
        _SSL_CTX = None

try:
    import websockets
    WEBSOCKETS_AVAILABLE = True
except ImportError:
    WEBSOCKETS_AVAILABLE = False

log = logging.getLogger("meshcode-mcp.realtime")


class RealtimeListener:
    """Connects to Supabase Realtime and forwards mc_messages INSERTs to a callback."""

    def __init__(
        self,
        supabase_url: str,
        supabase_key: str,
        project_id: str,
        agent_name: str,
        notify_callback: Optional[Callable[[Dict], Awaitable[None]]] = None,
        service_role_key: Optional[str] = None,
    ):
        self.supabase_url = supabase_url
        self.supabase_key = supabase_key
        self.project_id = project_id
        self.agent_name = agent_name
        self.notify_callback = notify_callback
        self.service_role_key = service_role_key

        # Last 100 unread messages — drained by meshcode_check tool
        self.queue: Deque[Dict] = deque(maxlen=100)
        self._task: Optional[asyncio.Task] = None
        # asyncio.Event() in Py3.10+ no longer requires a running loop, but
        # on older Python or certain Windows event-loop policies it can
        # raise. Defer creation to start() which is always called from
        # inside the running event loop.
        self._stop: Optional[asyncio.Event] = None
        self._connected = False
        # Event fired whenever a new message is appended to the queue.
        # meshcode_wait awaits this instead of polling -> zero-cost idle.
        self.message_event: Optional[asyncio.Event] = None

    @property
    def ws_url(self) -> str:
        host = self.supabase_url.replace("https://", "").replace("http://", "").rstrip("/")
        # Use service_role_key for WebSocket auth if available — bypasses RLS
        # so Realtime can deliver INSERT events without needing auth.uid().
        # Falls back to publishable key (requires anon RLS policy).
        key = self.service_role_key or self.supabase_key
        return f"wss://{host}/realtime/v1/websocket?apikey={key}&vsn=1.0.0"

    async def start(self) -> None:
        if not WEBSOCKETS_AVAILABLE:
            log.warning("websockets package not installed — Realtime disabled")
            return
        if self._stop is None:
            self._stop = asyncio.Event()
        if self.message_event is None:
            self.message_event = asyncio.Event()
        if self._task and not self._task.done():
            return
        self._stop.clear()
        self._task = asyncio.create_task(self._run(), name="meshcode-realtime")

    async def stop(self) -> None:
        if self._stop is not None:
            self._stop.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _run(self) -> None:
        """Outer loop: reconnect with exponential backoff on disconnect."""
        backoff = 1
        while not self._stop.is_set():
            try:
                await self._connect_and_listen()
                backoff = 1  # reset on clean disconnect
            except asyncio.CancelledError:
                return
            except Exception as e:
                log.warning(f"Realtime connection error: {e}; reconnecting in {backoff}s")
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=backoff)
                    return  # stop signaled
                except asyncio.TimeoutError:
                    pass
                backoff = min(backoff * 2, 30)

    async def _connect_and_listen(self) -> None:
        """Single connection lifecycle: connect, subscribe, listen."""
        # Cap the initial TLS handshake at 10s. Without this, websockets.connect
        # can hang indefinitely behind a corporate firewall / DNS stall, which
        # blocks the MCP lifespan startup -> Claude Code times out the spawn
        # -> "Failed to reconnect".
        connect_kwargs = {"ping_interval": 20, "ping_timeout": 10}
        if _SSL_CTX is not None and self.ws_url.startswith("wss://"):
            connect_kwargs["ssl"] = _SSL_CTX
        ws = await asyncio.wait_for(
            websockets.connect(self.ws_url, **connect_kwargs),
            timeout=10.0,
        )
        try:
            self._connected = True
            log.info(f"Realtime connected for agent={self.agent_name}")

            # Phoenix channel join: phoenix realtime topic
            topic = f"realtime:{self.project_id}-{self.agent_name}"
            join_msg = {
                "topic": topic,
                "event": "phx_join",
                "payload": {
                    "config": {
                        "postgres_changes": [
                            {
                                "event": "INSERT",
                                "schema": "meshcode",
                                "table": "mc_messages",
                                "filter": f"to_agent=eq.{url_quote(self.agent_name, safe='')}",
                            }
                        ]
                    }
                },
                "ref": "1",
            }
            await ws.send(json.dumps(join_msg))

            # Wait for phx_reply to confirm subscription was accepted.
            self._subscription_ok = False
            try:
                reply_raw = await asyncio.wait_for(ws.recv(), timeout=10.0)
                reply = json.loads(reply_raw)
                reply_status = (reply.get("payload") or {}).get("status")
                if reply_status == "ok":
                    self._subscription_ok = True
                    log.info(f"Realtime subscription OK for {self.agent_name} on {topic}")
                else:
                    log.error(
                        f"Realtime subscription FAILED for {self.agent_name}: "
                        f"status={reply_status} payload={reply.get('payload')}"
                    )
            except asyncio.TimeoutError:
                log.error(f"Realtime subscription TIMEOUT — no phx_reply in 10s for {self.agent_name}")
            except Exception as e:
                log.error(f"Realtime subscription error reading phx_reply: {e}")

            # Heartbeat task to keep the connection alive
            heartbeat_task = asyncio.create_task(self._heartbeat(ws))
            try:
                async for raw in ws:
                    if self._stop.is_set():
                        break
                    try:
                        msg = json.loads(raw)
                    except Exception:
                        continue
                    await self._handle_message(msg)
            finally:
                heartbeat_task.cancel()
                self._connected = False
        finally:
            try:
                await ws.close()
            except Exception:
                pass

    async def _heartbeat(self, ws) -> None:
        """Send phoenix heartbeats every 25s to keep the channel alive."""
        ref = 0
        while not self._stop.is_set():
            await asyncio.sleep(25)
            ref += 1
            try:
                await ws.send(json.dumps({
                    "topic": "phoenix",
                    "event": "heartbeat",
                    "payload": {},
                    "ref": str(ref),
                }))
            except Exception:
                return

    async def _handle_message(self, msg: Dict[str, Any]) -> None:
        event = msg.get("event")
        payload = msg.get("payload") or {}

        # postgres_changes payload structure:
        # {"event": "postgres_changes", "payload": {"data": {"record": {...}, "type": "INSERT", ...}}}
        if event == "postgres_changes":
            data = payload.get("data") or {}
            if data.get("type") == "INSERT":
                record = data.get("record") or {}
                if record.get("to_agent") == self.agent_name and record.get("project_id") == self.project_id:
                    enriched = {
                        "from": record.get("from_agent"),
                        "type": record.get("type", "msg"),
                        "ts": record.get("created_at"),
                        "payload": record.get("payload", {}),
                        "id": record.get("id"),
                        "parent_id": record.get("parent_msg_id"),
                    }
                    self.queue.append(enriched)
                    # Wake any meshcode_wait blocked on this event.
                    try:
                        self.message_event.set()
                    except Exception:
                        pass
                    log.info(f"new message from {enriched['from']}")
                    if self.notify_callback:
                        try:
                            await self.notify_callback(enriched)
                        except Exception as e:
                            log.warning(f"notify_callback failed: {e}")

    def peek(self) -> list:
        """Return queued messages without removing them."""
        return list(self.queue)

    def drain(self) -> list:
        """Pop and return all queued messages."""
        out = list(self.queue)
        self.queue.clear()
        # Queue is empty → reset the wake event so the next wait blocks again.
        try:
            self.message_event.clear()
        except Exception:
            pass
        return out

    async def wait_for_message(self, timeout: Optional[float] = None) -> bool:
        """Block until a new message lands in the queue (or timeout).

        Returns True if woken by a message, False on timeout. This is the
        core of the zero-cost idle loop: while awaiting, the event loop
        does ZERO work — no polling, no Supabase calls, no token cost.
        """
        try:
            await asyncio.wait_for(self.message_event.wait(), timeout=timeout)
            return True
        except asyncio.TimeoutError:
            return False

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def is_subscribed(self) -> bool:
        return self._connected and getattr(self, "_subscription_ok", False)
