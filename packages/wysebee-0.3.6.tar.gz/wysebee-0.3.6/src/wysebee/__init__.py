def __getattr__(name):
    _desktop_exports = {
        "Wysebee": ".desktop.wysebee",
        "WysebeeWebView": ".desktop.wysebee_webview",
        "WysebeeWebEnginePage": ".desktop.wysebee_webengine_page",
        "WysebeeBackend": ".desktop.wysebee_backend",
        "singleton": ".desktop.singleton",
        "TempFileHelper": ".desktop.temp_helper",
        "WysebeeWebPopup": ".desktop.wysebee_webpopup",
        "WysebeeAppMenu": ".desktop.wysebee_app_menu",
    }
    if name in _desktop_exports:
        import importlib
        module = importlib.import_module(_desktop_exports[name], __package__)
        attr = getattr(module, name)
        globals()[name] = attr
        return attr
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


from .desktop.filesystem import (
    get_file_size,
    same_file_extension,
    is_file,
    is_directory,
    in_directory,
    resolve_relative_path,
    copy_file,
    move_file,
    remove_file,
    create_directory,
    list_directory,
    remove_directory,
)