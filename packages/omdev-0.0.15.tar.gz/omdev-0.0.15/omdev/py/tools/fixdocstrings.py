"""
Fix docstring formatting in Python source code.

Reads Python source from stdin and outputs to stdout with docstrings reformatted according to:
1. If docstring fits on a single 120-char line (including triple-quotes and indentation), make it single-line
2. Otherwise, put each triple-quote on its own line with no content sharing the line
3. Always ensure a blank line follows class/function docstrings (but NOT module docstrings)
"""
import ast
import os.path
import re
import sys
import typing as ta

from omlish import check
from omlish.logs import all as logs
from omlish.re import regex_to_string

from ..tokens import all as tks


log = logs.get_module_logger(globals())


##


class DocstringFixer:
    """Fixes docstring formatting while preserving all other whitespace and comments."""

    def __init__(self, src: str) -> None:
        super().__init__()

        self._src = src

        self._tree: ast.Module | None

        # Try to tokenize and parse - if either fails, we can't fix anything
        try:
            self._tokens = list(tks.src_to_tokens(src))
        except Exception:  # noqa
            # If tokenization fails, we can't do anything
            self._tokens = []
            self._tree = None
            self._docstring_positions: set[tuple[int, int]] = set()
            self._module_docstring_positions: set[tuple[int, int]] = set()
            return

        # Parse AST to identify docstring positions
        try:
            self._tree = ast.parse(src)
        except SyntaxError:
            # If we can't parse, don't try to fix anything
            self._tree = None
            self._docstring_positions = set()
            self._module_docstring_positions = set()
        else:
            self._docstring_positions = self._find_docstring_positions()

    def _find_docstring_positions(self) -> set[tuple[int, int]]:
        """Find all docstring positions (line, col_offset) in the AST."""

        if self._tree is None:
            return set()

        positions = set()
        module_positions = set()

        for node in ast.walk(self._tree):
            # Only these node types can have docstrings
            if not isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                continue

            docstring = ast.get_docstring(node, clean=False)
            if docstring is None:
                continue

            # Get the first statement which should be the Expr node containing the docstring
            if node.body and isinstance(node.body[0], ast.Expr):
                expr_node = node.body[0]
                if isinstance(expr_node.value, ast.Constant) and isinstance(expr_node.value.value, str):
                    # Record position (line, col_offset)
                    pos = (expr_node.lineno, expr_node.col_offset)
                    positions.add(pos)
                    # Track module-level docstrings separately
                    if isinstance(node, ast.Module):
                        module_positions.add(pos)

        self._module_docstring_positions = module_positions
        return positions

    def _is_docstring(self, token: tks.Token) -> bool:
        """Check if a token is a docstring based on AST positions."""

        if token.name != 'STRING':
            return False

        # Check if this token's position matches a docstring position
        return (token.line, token.utf8_byte_offset) in self._docstring_positions

    def _is_module_docstring(self, token: tks.Token) -> bool:
        """Check if a token is a module-level docstring."""

        return (token.line, token.utf8_byte_offset) in self._module_docstring_positions

    def _get_string_content(self, token_src: str) -> tuple[str, str, str]:
        """
        Parse a string token into (prefix, quotes, content).

        Returns:
            (prefix, quotes, content) where:
            - prefix is the string prefix (r, u, f, b, etc., possibly empty)
            - quotes is the quote style (', ", ''', \"\"\")
            - content is the actual string content
        """

        src = token_src

        # Extract prefix
        prefix_chars = []
        i = 0
        while i < len(src) and src[i] in 'rRuUfFbB':
            prefix_chars.append(src[i])
            i += 1
        prefix = ''.join(prefix_chars)

        # Extract quotes
        remainder = src[i:]
        if remainder.startswith(('"""', "'''")):
            quotes = remainder[:3]
            content = remainder[3:-3]
        elif remainder.startswith(('"', "'")):
            quotes = remainder[0]
            content = remainder[1:-1]
        else:
            raise ValueError(f'Invalid string token: {token_src}')

        return prefix, quotes, content

    def _calculate_display_width(self, s: str) -> int:
        """Calculate the display width of a string (treating tabs as single characters for simplicity)."""

        # For docstring width calculation, we need to account for indentation. Tabs are typically 8 spaces, but in code
        # they align to tab stops. For simplicity, we'll count each tab as 4 spaces.
        return len(s.replace('\t', '    '))

    def _fix_docstring(self, token: tks.Token, indent: str) -> list[tks.Token]:
        """
        Fix a docstring token's formatting.

        Returns a list of tokens to replace the original docstring token.
        """

        prefix, quotes, content = self._get_string_content(token.src)

        # Only handle triple-quoted strings as docstrings
        if len(quotes) != 3:
            return [token]

        # Check if the docstring is already in "proper" multiline format (starts with newline after opening quotes)
        already_multiline_format = content.startswith('\n')

        # Strip leading/trailing newlines (and any surrounding whitespace on those lines) from content that come from
        # multi-line format - these are formatting artifacts
        lines = content.split('\n')

        # Remove empty leading lines
        while lines and not lines[0].strip():
            lines.pop(0)

        # Remove empty trailing lines
        while lines and not lines[-1].strip():
            lines.pop()

        # Check if the content has explicit newlines (i.e., it's meant to be multi-line)
        has_explicit_newlines = len(lines) > 1

        # Prepare the content based on whether it's single or multi-line
        if not has_explicit_newlines:
            # Single line content - but we need to handle two cases:
            # 1. If already in multiline format, preserve the line as-is for potential multiline output
            # 2. For single-line output, we'll strip it
            if already_multiline_format:
                # Keep the content for multiline format (preserve indentation)
                stripped_content_multiline = '\n'.join(lines)
                # But also prepare a stripped version for single-line format
                stripped_content_single = lines[0].strip() if lines else ''
            else:
                # Not in multiline format, just strip it
                stripped_content_single = lines[0].strip() if lines else ''
                stripped_content_multiline = stripped_content_single
        else:
            # Multi-line - only dedent if we're reformatting from "content on same line as quotes" format.
            # If it's already in proper multiline format, preserve the content structure exactly.
            if already_multiline_format:
                # Already properly formatted - just preserve the content
                stripped_content_multiline = '\n'.join(lines)
                stripped_content_single = '\n'.join(lines)  # Won't be used but set it anyway
            else:
                # Needs reformatting - dedent the content. Python's textwrap.dedent doesn't work well when the first
                # line has no indent, so we do it manually: find the minimum indent of non-empty lines (excluding the
                # first), then strip that from all lines.
                dedented_lines = []

                # Find the minimum indentation of non-empty, non-first lines
                min_indent = None
                for _i, line in enumerate(lines[1:], start=1):  # Skip first line
                    if line.strip():  # Only consider non-empty lines
                        # Count leading whitespace
                        stripped = line.lstrip()
                        indent_len = len(line) - len(stripped)
                        if min_indent is None or indent_len < min_indent:
                            min_indent = indent_len

                # If we found no indented lines, just use the lines as-is
                if min_indent is None:
                    min_indent = 0

                # Now strip that minimum indent from all lines
                for i, line in enumerate(lines):
                    if i == 0:
                        # First line - just strip any leading/trailing whitespace
                        dedented_lines.append(line.strip())
                    elif not line.strip():
                        # Empty line - keep it empty
                        dedented_lines.append('')
                    else:
                        # Other lines - remove the minimum indent
                        dedented_lines.append(line[min_indent:] if len(line) >= min_indent else line.lstrip())

                stripped_content_multiline = '\n'.join(dedented_lines)
                stripped_content_single = '\n'.join(dedented_lines)

        # Calculate if single-line format fits in 120 chars
        single_line = f'{prefix}{quotes}{stripped_content_single}{quotes}'
        single_line_with_indent = f'{indent}{single_line}'

        if not has_explicit_newlines and self._calculate_display_width(single_line_with_indent) <= 120:
            # Use single-line format
            new_src = single_line
        else:
            # Use multi-line format with triple-quotes on separate lines.
            if already_multiline_format:
                # Already in multiline format - content already has the correct indentation, don't add more
                new_src = f'{prefix}{quotes}\n{stripped_content_multiline}\n{indent}{quotes}'
            else:
                # Reformatting from single-line-ish format - need to indent each line
                indented_lines = [
                    indent + line if line.strip() else ''
                    for line in stripped_content_multiline.split('\n')
                ]
                indented_content = '\n'.join(indented_lines)
                new_src = f'{prefix}{quotes}\n{indented_content}\n{indent}{quotes}'

        return [tks.Token(name='STRING', src=new_src, line=token.line, utf8_byte_offset=token.utf8_byte_offset)]

    def _ensure_blank_line_after_docstring(
            self,
            tokens: list[tks.Token],
            docstring_idx: int,
    ) -> list[tks.Token]:
        """
        Ensure there's a blank line after a docstring.

        Returns modified token list.
        """

        # Find the next NEWLINE token after the docstring
        idx = docstring_idx + 1
        while idx < len(tokens) and tokens[idx].name == 'UNIMPORTANT_WS':
            idx += 1

        if idx >= len(tokens) or tokens[idx].name != 'NEWLINE':
            # Something's wrong, don't modify
            return tokens

        # Check what comes after the NEWLINE
        idx += 1

        # Count consecutive NL/NEWLINE tokens (blank lines)
        newline_count = 0
        first_newline_idx = idx

        while idx < len(tokens):
            if tokens[idx].name in ('NL', 'NEWLINE'):
                newline_count += 1
                idx += 1
            elif tokens[idx].name == 'UNIMPORTANT_WS':
                # Skip whitespace between newlines
                idx += 1
            else:
                break

        # Check if we're at EOF (only ENDMARKER or nothing left, possibly with DEDENT/INDENT tokens). If so, don't add a
        # blank line as it would create an extra newline at EOF.
        temp_idx = idx
        while temp_idx < len(tokens) and tokens[temp_idx].name in ('DEDENT', 'INDENT'):
            temp_idx += 1

        if temp_idx >= len(tokens) or tokens[temp_idx].name == 'ENDMARKER':
            return tokens

        # If we don't have at least one blank line (2 newlines total including the one right after docstring), we need
        # to add a NL token
        if newline_count == 0:
            # Insert a NL token to create a blank line. We need to insert it right after the first NEWLINE following the
            # docstring.
            new_tokens = [*tokens[:first_newline_idx], tks.Token('NL', '\n'), *tokens[first_newline_idx:]]
            return new_tokens

        return tokens

    def fix(self) -> str:
        """Fix all docstrings in the source and return the modified source."""

        if self._tree is None:
            # Can't parse, return original
            return self._src

        tokens = self._tokens[:]

        # Identify and fix docstrings
        i = 0
        while i < len(tokens):
            token = tokens[i]

            if self._is_docstring(token):
                # Get the indentation before this token. The indentation could be an INDENT token or UNIMPORTANT_WS
                # before the docstring on the same line.
                indent = ''
                j = i - 1

                # Look backwards for INDENT or UNIMPORTANT_WS
                while j >= 0:
                    if tokens[j].name == 'INDENT':
                        indent = tokens[j].src
                        break
                    elif tokens[j].name == 'UNIMPORTANT_WS' and '\n' not in tokens[j].src:
                        indent = tokens[j].src
                        break
                    elif tokens[j].name in ('NEWLINE', 'NL'):
                        # Reached the previous line without finding indent
                        break
                    j -= 1

                # Fix the docstring
                fixed_tokens = self._fix_docstring(token, indent)
                tokens = tokens[:i] + fixed_tokens + tokens[i + 1:]

                # Ensure blank line after docstring (but not for module docstrings)
                if not self._is_module_docstring(token):
                    tokens = self._ensure_blank_line_after_docstring(tokens, i)

            i += 1

        return tks.tokens_to_src(tokens)


##


class _Runner:
    def __init__(
            self,
            *,
            print_diff: bool = False,
            overwrite: bool = False,
            dry_run: bool = False,

            num_workers: int | None = None,

            exclude_file_pats: ta.Sequence[re.Pattern] | None = None,
            exclude_src_pats: ta.Sequence[re.Pattern] | None = None,
    ) -> None:
        super().__init__()

        self._print_diff = print_diff
        self._overwrite = overwrite
        self._dry_run = dry_run

        self._num_workers = num_workers

        self._exclude_file_pats = exclude_file_pats
        self._exclude_src_pats = exclude_src_pats

        self._exclude_src_pats_srcs = [
            check.isinstance(regex_to_string(xp), str)
            for xp in exclude_src_pats
        ] if exclude_src_pats else None

    #

    def _should_exclude_file(self, file_path: str) -> bool:
        if (xps := self._exclude_file_pats):
            for xp in xps:
                if xp.match(file_path):
                    return True

        return False

    def _find_file_paths(self, roots: ta.Iterable[str]) -> set[str]:
        roots = sorted({check.non_empty_str(s) for s in check.not_isinstance(roots, str)})

        file_paths: set[str] = set()

        for root in roots:
            if os.path.isfile(root):
                if not self._should_exclude_file(root):
                    file_paths.add(root)

            elif os.path.isdir(root):
                for dp, _dns, fns in os.walk(root):
                    for fn in fns:
                        if not fn.endswith('.py'):
                            continue

                        fp = os.path.join(dp, fn)

                        if not self._should_exclude_file(fp):
                            file_paths.add(fp)

            else:
                raise FileNotFoundError(root)

        return file_paths

    #

    @classmethod
    def _run_one(
            cls,
            file_path: str,
            *,
            exclude_src_pats_srcs: ta.Sequence[str] | None = None,
    ) -> tuple[str, str] | None:
        with open(file_path) as f:
            src = f.read()

        if exclude_src_pats_srcs is not None:
            for xp in exclude_src_pats_srcs:
                if re.search(xp, src):
                    return None

        fixed_src = DocstringFixer(src).fix()

        if fixed_src == src:
            return None

        return (file_path, fixed_src)

    def run(
            self,
            roots: ta.Iterable[str],
    ) -> None:
        file_paths = self._find_file_paths(roots)

        #

        import concurrent.futures as cf

        from omlish.concurrent.executors import new_executor

        with new_executor(
            self._num_workers if self._num_workers is not None else 0,
            cf.ProcessPoolExecutor,
        ) as exe:
            futs: list[cf.Future] = [
                exe.submit(
                    self._run_one,
                    fp,
                    exclude_src_pats_srcs=self._exclude_src_pats_srcs,
                )
                for fp in sorted(file_paths)
            ]

            for fut in futs:
                if (res := fut.result()) is not None:
                    fp, fixed_src = res

                    if not self._overwrite:
                        if self._print_diff:
                            with open(fp) as f:
                                src = f.read()

                            import difflib

                            out = ''.join(difflib.unified_diff(
                                src.splitlines(keepends=True),
                                fixed_src.splitlines(keepends=True),
                            ))

                        else:
                            out = fixed_src

                        sys.stdout.write('\n'.join([
                            '====',
                            fp,
                            '====',
                            out,
                            '',
                        ]))

                    elif self._dry_run:
                        log.info(lambda: f'Would fix {fp}')

                    else:
                        log.info(lambda: f'Fixing {fp}')
                        with open(fp, 'w') as f:
                            f.write(fixed_src)


##


def _main() -> None:
    import argparse

    parser = argparse.ArgumentParser()

    parser.add_argument('src', nargs='+')

    parser.add_argument('-D', '--diff', action='store_true')
    parser.add_argument('-W', '--overwrite', action='store_true')
    parser.add_argument('--dry-run', action='store_true')

    parser.add_argument('-j', '--workers')

    parser.add_argument('-x', '--exclude-file', action='append')
    parser.add_argument('-X', '--exclude-src', action='append')

    args = parser.parse_args()

    if not args.src:
        raise Exception('src must be specified')

    logs.configure_standard_logging()

    if '-' in args.src:
        if list(args.src) != ['-']:
            raise Exception('if - in src it must be only src')

        src = sys.stdin.read()
        fixed_src = DocstringFixer(src).fix()
        sys.stdout.write(fixed_src)

        return

    if (nw := args.workers) is not None:
        if nw == '-':
            nw = os.process_cpu_count()
        else:
            nw = int(nw)

    _Runner(
        print_diff=bool(args.diff),
        overwrite=bool(args.overwrite),
        dry_run=bool(args.dry_run),

        num_workers=nw,

        exclude_file_pats=[re.compile(xp) for xp in args.exclude_file] if args.exclude_file else None,
        exclude_src_pats=[re.compile(xp) for xp in args.exclude_src] if args.exclude_src else None,
    ).run(args.src)


if __name__ == '__main__':
    _main()
