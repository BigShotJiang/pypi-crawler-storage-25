yes | sudo unminimize ;
