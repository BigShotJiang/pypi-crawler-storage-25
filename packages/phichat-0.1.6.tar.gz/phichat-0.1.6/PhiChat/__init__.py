"""
PhiChat
-------
Wrapper LangChain para Phi-4-mini via Ollama con soporte robusto de tool calling.
"""

from PhiChat.model import ChatPhi
from PhiChat.tools import create_tool, run_tool_loop
from PhiChat.parsers import parse_phi4_tool_calls, inject_tool_system_message
from PhiChat.constants import _PHI4_TOOL_SYSTEM_SUFFIX, _TOOL_CALL_PATTERNS

__all__ = [
    "ChatPhi",
    "create_tool",
    "run_tool_loop",
    "parse_phi4_tool_calls",
    "inject_tool_system_message",
    "_PHI4_TOOL_SYSTEM_SUFFIX",
    "_TOOL_CALL_PATTERNS",
]
