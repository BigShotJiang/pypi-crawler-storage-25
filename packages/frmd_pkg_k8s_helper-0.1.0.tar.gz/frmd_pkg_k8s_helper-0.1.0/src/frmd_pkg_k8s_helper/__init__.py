def hello() -> str:
    return "Hello from frmd-pkg-k8s-helper!"
