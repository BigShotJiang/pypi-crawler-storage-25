"""LocalData MCP - Database connection and query management."""

import argparse
import atexit
import configparser
import hashlib
import importlib.metadata
import json
import logging
import os
import psutil
import sys
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional

if TYPE_CHECKING:
    from .graph_manager import GraphStorageManager
    from .rdf_storage import RDFStorageManager

import pandas as pd
import yaml
from fastmcp import FastMCP
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.sql import quoted_name

# Import SQL query parser for security validation
from .query_parser import parse_and_validate_sql, SQLSecurityError

# Import query analyzer for pre-execution analysis
from .query_analyzer import analyze_query, QueryAnalysis

# Import streaming executor for memory-bounded processing
from .streaming_executor import StreamingQueryExecutor, create_streaming_source

# Import timeout manager for query timeout handling
from .timeout_manager import QueryTimeoutError, get_timeout_manager

# Import streaming file processors for memory-efficient file loading
from .file_processor import create_streaming_file_engine, FileProcessorFactory

# Import enhanced response metadata system
from .response_metadata import (
    get_metadata_generator,
    EnhancedResponseMetadata,
    LLMCommunicationProtocol,
    ResponseMetadataGenerator,
)

# Import structured logging system
from .logging_manager import get_logging_manager, get_logger
from .config_manager import get_config_manager, initialize_config

# Import backward compatibility management
from .compatibility_manager import get_compatibility_manager

# Import staging manager singleton
from .staging_manager import get_staging_manager

# Import structured error classification
from .error_classification import classify_error

# Import tree storage for structured data (TOML, JSON, YAML)
from .tree_storage import TreeStorageManager, create_tree_schema
from .tree_parsers import parse_toml_to_tree, parse_json_to_tree, parse_yaml_to_tree
from .tree_tools import (
    tool_get_node,
    tool_get_children,
    tool_set_node,
    tool_move_node,
    tool_delete_node,
    tool_list_keys,
    tool_get_value,
    tool_set_value,
    tool_delete_key,
)
from .tree_export import tool_export_structured

# Import graph tool functions
from .graph_tools import (
    tool_get_node_graph,
    tool_get_neighbors,
    tool_get_edges,
    tool_set_node_graph,
    tool_delete_node_graph,
    tool_add_edge,
    tool_remove_edge,
    tool_find_path,
    tool_get_graph_stats,
    tool_get_value_graph,
    tool_set_value_graph,
    tool_delete_key_graph,
    tool_list_keys_graph,
    tool_export_graph,
)

# TOML support
try:
    import toml

    TOML_AVAILABLE = True
except ImportError:
    TOML_AVAILABLE = False

# Excel support libraries with graceful error handling
try:
    import openpyxl

    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False

try:
    import xlrd

    XLRD_AVAILABLE = True
except ImportError:
    XLRD_AVAILABLE = False

try:
    import defusedxml

    DEFUSEDXML_AVAILABLE = True
except ImportError:
    DEFUSEDXML_AVAILABLE = False

# ODS (LibreOffice Calc) support libraries with graceful error handling
try:
    from odf import opendocument, table

    ODFPY_AVAILABLE = True
except ImportError:
    ODFPY_AVAILABLE = False

# XML parsing support
try:
    import lxml

    LXML_AVAILABLE = True
except ImportError:
    LXML_AVAILABLE = False

# Analytical format support (Parquet, Arrow, Feather)
try:
    import pyarrow

    PYARROW_AVAILABLE = True
except ImportError:
    PYARROW_AVAILABLE = False

# Apple Numbers support
try:
    from numbers_parser import Document

    NUMBERS_PARSER_AVAILABLE = True
except ImportError:
    NUMBERS_PARSER_AVAILABLE = False

# DuckDB support
try:
    import duckdb

    DUCKDB_AVAILABLE = True
except ImportError:
    DUCKDB_AVAILABLE = False

# HDF5 support for scientific data
try:
    import h5py

    H5PY_AVAILABLE = True
except ImportError:
    H5PY_AVAILABLE = False

# Modern database support - Redis
try:
    import redis

    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

# Modern database support - Elasticsearch
try:
    from elasticsearch import Elasticsearch

    ELASTICSEARCH_AVAILABLE = True
except ImportError:
    ELASTICSEARCH_AVAILABLE = False

# Modern database support - MongoDB
try:
    import pymongo

    PYMONGO_AVAILABLE = True
except ImportError:
    PYMONGO_AVAILABLE = False

# Modern database support - InfluxDB
try:
    from influxdb_client import InfluxDBClient

    INFLUXDB_AVAILABLE = True
except ImportError:
    INFLUXDB_AVAILABLE = False

# Modern database support - Neo4j
try:
    from neo4j import GraphDatabase

    NEO4J_AVAILABLE = True
except ImportError:
    NEO4J_AVAILABLE = False

# Modern database support - CouchDB
try:
    import couchdb

    COUCHDB_AVAILABLE = True
except ImportError:
    COUCHDB_AVAILABLE = False

# SPARQL endpoint support
try:
    from SPARQLWrapper import SPARQLWrapper as _SPARQLWrapper

    SPARQLWRAPPER_AVAILABLE = True
except ImportError:
    SPARQLWRAPPER_AVAILABLE = False

# Oracle support (optional enterprise dependency)
try:
    from .oracle_support import ORACLEDB_AVAILABLE
except ImportError:
    ORACLEDB_AVAILABLE = False

# MS SQL Server support (optional enterprise dependency)
try:
    from .mssql_support import PYMSSQL_AVAILABLE, PYODBC_AVAILABLE

    MSSQL_AVAILABLE = PYMSSQL_AVAILABLE or PYODBC_AVAILABLE
except ImportError:
    PYMSSQL_AVAILABLE = False
    PYODBC_AVAILABLE = False
    MSSQL_AVAILABLE = False

# Set up logging
# Initialize structured logging before other components
config_manager = get_config_manager()
logging_config = config_manager.get_logging_config()
logging_manager = get_logging_manager(logging_config)

# Get structured logger (logging configuration handled by LoggingManager)
logger = get_logger(__name__)

# Create the MCP server instance
mcp = FastMCP("localdata-mcp")

# Add metrics endpoint if enabled
if logging_config.enable_metrics:
    from prometheus_client import CONTENT_TYPE_LATEST

    @mcp.tool()
    def get_metrics() -> str:
        """Get Prometheus metrics for monitoring dashboards.

        Returns:
            Prometheus-formatted metrics string
        """
        try:
            with logging_manager.context(
                operation="metrics_export", component="localdata_mcp"
            ):
                logger.debug("Exporting Prometheus metrics")

            metrics_data = logging_manager.get_metrics()
            return metrics_data

        except Exception as e:
            logging_manager.log_error(e, "localdata_mcp", operation="metrics_export")
            return f"Error exporting metrics: {e}"


@dataclass
class QueryBuffer:
    query_id: str
    db_name: str
    query: str
    results: pd.DataFrame
    timestamp: float
    source_file_path: Optional[str] = None
    source_file_mtime: Optional[float] = None

    # Enhanced metadata integration
    response_metadata: Optional["EnhancedResponseMetadata"] = None
    llm_protocol: Optional["LLMCommunicationProtocol"] = None


class DatabaseManager:
    def __init__(self):
        self.connections: Dict[str, Any] = {}
        self.db_types: Dict[str, str] = {}  # Track database type for each connection
        self.query_history: Dict[str, List[str]] = {}

        # Security and connection management
        self.connection_semaphore = threading.Semaphore(
            10
        )  # Max 10 concurrent connections
        self.connection_lock = threading.Lock()
        self.connection_count = 0

        # Query buffering system
        self.query_buffers: Dict[str, QueryBuffer] = {}
        self.query_buffer_lock = threading.Lock()

        # Temporary file management
        self.temp_files: List[str] = []
        self.temp_file_lock = threading.Lock()

        # Auto-cleanup for buffers (10 minute expiry)
        self.buffer_cleanup_interval = 600  # 10 minutes
        self.last_cleanup = time.time()

        # Streaming executor for memory-bounded processing
        self.streaming_executor = StreamingQueryExecutor()

        # Tree storage managers for structured data (TOML, JSON, YAML)
        self._tree_managers: Dict[str, Any] = {}  # name → TreeStorageManager

        # Graph storage managers for graph files (DOT, GML, GraphML)
        self._graph_managers: Dict[str, Any] = {}  # name → GraphStorageManager

        # RDF storage managers for RDF files (Turtle, N-Triples)
        self._rdf_managers: Dict[str, Any] = {}  # name → RDFStorageManager

        # SPARQL endpoint connections for remote triple stores
        self._sparql_connections: Dict[str, Any] = {}  # name → SPARQLEndpointConnection

        # Initialize backward compatibility manager
        self.compatibility_manager = get_compatibility_manager()

        # Check for legacy configuration and show warnings
        self._check_legacy_configuration()

        # Register cleanup on exit
        atexit.register(self._cleanup_all)

        # Register tools with MCP server (fastmcp v3 requires bound method registration)
        self._register_tools(mcp)

    def _check_legacy_configuration(self):
        """Check for legacy configuration patterns and show warnings."""
        try:
            legacy_config = self.compatibility_manager.detect_legacy_configuration()

            if legacy_config["detected"]:
                logger.info("Legacy configuration patterns detected")

                for pattern in legacy_config["detected"]:
                    if pattern["pattern"] == "Legacy Environment Variables":
                        self.compatibility_manager.warn_deprecated(
                            "single_database_env_vars"
                        )

                if legacy_config["migration_required"]:
                    self.compatibility_manager.warn_deprecated("env_only_config")
                    logger.info(
                        "Consider running compatibility check for migration assistance"
                    )

        except Exception as e:
            logger.warning(f"Error checking legacy configuration: {e}")

    def _register_tools(self, mcp_server):
        """Register all public tool methods with the MCP server.

        FastMCP v3 requires bound methods to be registered via add_tool()
        rather than using @mcp.tool on class methods with self.
        """
        mcp_server.add_tool(self.connect_database)
        mcp_server.add_tool(self.disconnect_database)
        mcp_server.add_tool(self.execute_query)
        mcp_server.add_tool(self.analyze_query_preview)
        mcp_server.add_tool(self.next_chunk)
        mcp_server.add_tool(self.list_databases)
        mcp_server.add_tool(self.describe_database)
        mcp_server.add_tool(self.find_table)
        mcp_server.add_tool(self.describe_table)
        mcp_server.add_tool(self.manage_memory_bounds)
        mcp_server.add_tool(self.get_streaming_status)
        mcp_server.add_tool(self.clear_streaming_buffer)
        mcp_server.add_tool(self.get_query_metadata)
        mcp_server.add_tool(self.request_data_chunk)
        mcp_server.add_tool(self.request_multiple_chunks)
        mcp_server.add_tool(self.cancel_query_operation)
        mcp_server.add_tool(self.get_data_quality_report)
        mcp_server.add_tool(self.check_compatibility)
        # Tree tools for structured data (TOML, JSON, YAML)
        mcp_server.add_tool(self.get_node)
        mcp_server.add_tool(self.get_children)
        mcp_server.add_tool(self.set_node)
        mcp_server.add_tool(self.move_node)
        mcp_server.add_tool(self.delete_node)
        mcp_server.add_tool(self.list_keys)
        mcp_server.add_tool(self.get_value)
        mcp_server.add_tool(self.set_value)
        mcp_server.add_tool(self.delete_key)
        mcp_server.add_tool(self.export_structured)
        # Graph-only tools (new MCP endpoints)
        mcp_server.add_tool(self.get_neighbors)
        mcp_server.add_tool(self.get_edges)
        mcp_server.add_tool(self.add_edge)
        mcp_server.add_tool(self.remove_edge)
        mcp_server.add_tool(self.find_path)
        mcp_server.add_tool(self.get_graph_stats)
        mcp_server.add_tool(self.export_graph)
        # Regex tools
        mcp_server.add_tool(self.search_data)
        mcp_server.add_tool(self.transform_data)
        # Schema export tool
        mcp_server.add_tool(self.export_schema)
        # Query audit tools
        mcp_server.add_tool(self.get_query_log)
        mcp_server.add_tool(self.get_error_log)

    def _get_connection(self, name: str):
        if name not in self.connections:
            raise ValueError(
                f"Database '{name}' is not connected. Use 'connect_database' first."
            )
        return self.connections[name]

    def _record_audit(
        self,
        database: str,
        query: str,
        status: str,
        start_time: float,
        rows_returned: Optional[int] = None,
        error_type: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> None:
        """Record a query execution in the audit buffer."""
        try:
            from .query_audit import get_query_audit_buffer

            duration_ms = (time.time() - start_time) * 1000
            buf = get_query_audit_buffer()
            buf.record_query(
                database=database,
                query=query,
                status=status,
                duration_ms=duration_ms,
                rows_returned=rows_returned,
                error_type=error_type,
                error_message=error_message,
            )
        except Exception:
            logger.debug("Failed to record audit entry", exc_info=True)

    def _sanitize_path(self, file_path: str):
        """Enhanced path security - restrict to current working directory and subdirectories only."""
        base_dir = Path(os.getcwd()).resolve()
        try:
            # Resolve the path to handle symlinks and relative paths
            abs_file_path = Path(file_path).resolve()
        except (OSError, ValueError) as e:
            raise ValueError(f"Invalid path '{file_path}': {e}")

        # Security check: ensure path is within base directory
        try:
            abs_file_path.relative_to(base_dir)
        except ValueError:
            raise ValueError(
                f"Path '{file_path}' is outside the allowed directory. Only current directory and subdirectories are allowed."
            )

        # Check if file exists
        if not abs_file_path.is_file():
            raise ValueError(f"File not found at path '{file_path}'.")

        return str(abs_file_path)

    def _serialize_complex_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Serialize complex nested objects (dict, list) in DataFrame columns to JSON strings.

        This prevents SQLite insertion errors when DataFrame contains nested structures
        that can't be directly serialized to database columns.

        Args:
            df: DataFrame that may contain columns with complex nested objects

        Returns:
            DataFrame with complex objects serialized as JSON strings
        """
        if df.empty:
            return df

        # Create a copy to avoid modifying the original DataFrame
        df_copy = df.copy()

        for col in df_copy.columns:
            if df_copy[col].dtype == "object":
                # Check if this column contains complex objects (dict/list)
                non_null_values = df_copy[col].dropna()
                if not non_null_values.empty:
                    # Check first few non-null values to determine if serialization is needed
                    sample_values = non_null_values.head(3)
                    needs_serialization = any(
                        isinstance(val, (dict, list)) for val in sample_values.values
                    )

                    if needs_serialization:
                        logger.info(
                            f"Serializing column '{col}' containing complex nested objects"
                        )

                        def serialize_value(x):
                            # Handle null values safely - avoid pd.notna() with arrays
                            if x is None:
                                return x
                            # Check if it's a complex object that needs serialization
                            if isinstance(x, (dict, list)):
                                return json.dumps(x)
                            return x

                        df_copy[col] = df_copy[col].apply(serialize_value)

        return df_copy

    @staticmethod
    def _collect_leaf_rows(
        data: Any, path: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """Recursively walk a nested dict tree and collect leaf-node rows.

        A "leaf" is a dict whose values are all scalars or lists of scalars
        (no further nested dicts).  Each leaf produces one row that includes
        the path keys that led to it plus all its own key/value pairs.

        Returns an empty list if the structure has no recognisable leaf pattern
        (caller should fall back to pd.json_normalize).
        """
        if path is None:
            path = []
        rows: List[Dict[str, Any]] = []

        if not isinstance(data, dict):
            return rows

        # Check if this dict is a leaf (all values are scalars or lists of scalars)
        is_leaf = all(not isinstance(v, dict) for v in data.values())

        if is_leaf and data:
            row: Dict[str, Any] = {}
            # Add path levels
            for i, key in enumerate(path):
                row[f"level_{i}"] = key
            # Add leaf values, converting lists to comma-separated strings
            for k, v in data.items():
                if isinstance(v, list):
                    row[k] = ", ".join(str(item) for item in v) if v else ""
                else:
                    row[k] = v
            rows.append(row)
        else:
            # Recurse into nested dicts
            for key, value in data.items():
                if isinstance(value, dict):
                    rows.extend(DatabaseManager._collect_leaf_rows(value, path + [key]))

        return rows

    def _normalize_nested_data(self, data: Any) -> pd.DataFrame:
        """Normalize nested dict structures into a DataFrame.

        For shallow structures (few resulting columns) uses the standard
        pd.json_normalize.  For deeply nested hierarchical data (like
        taxonomies) collects leaf nodes as rows instead, producing a tall
        DataFrame rather than an ultra-wide single-row one.
        """
        if not isinstance(data, (dict, list)):
            return pd.DataFrame(data)

        # Try standard flattening first
        flat = pd.json_normalize(data)

        # Heuristic: if the result is very wide relative to rows, the data is
        # deeply nested and should be row-normalised instead.
        if len(flat.columns) > 200 and len(flat) <= 5:
            leaf_rows = self._collect_leaf_rows(data)
            if leaf_rows:
                logger.info(
                    f"Deeply nested structure detected ({len(flat.columns)} cols). "
                    f"Row-normalising into {len(leaf_rows)} leaf rows instead."
                )
                return pd.DataFrame(leaf_rows)

        return flat

    def _get_file_size(self, file_path: str) -> int:
        """Get file size in bytes."""
        try:
            return os.path.getsize(file_path)
        except OSError as e:
            raise ValueError(f"Cannot get size of file '{file_path}': {e}")

    def _is_large_file(self, file_path: str, threshold_mb: int = 100) -> bool:
        """Check if file exceeds the size threshold (default 100MB)."""
        threshold_bytes = threshold_mb * 1024 * 1024
        return self._get_file_size(file_path) > threshold_bytes

    def _sanitize_sheet_name(self, sheet_name: str, used_names: set = None) -> str:
        """Sanitize sheet name for use as SQL table name."""
        import re

        if used_names is None:
            used_names = set()

        # Convert to string and strip whitespace
        name = str(sheet_name).strip()

        # Replace spaces and hyphens with underscores
        name = re.sub(r"[\s\-]+", "_", name)

        # Remove or replace problematic characters, keep only alphanumeric and underscore
        name = re.sub(r"[^\w]", "_", name)

        # Remove consecutive underscores
        name = re.sub(r"_+", "_", name)

        # Ensure it starts with letter or underscore
        if name and not re.match(r"^[a-zA-Z_]", name):
            name = "sheet_" + name

        # Handle empty names
        if not name:
            name = "sheet_unnamed"

        # Ensure uniqueness
        original_name = name
        counter = 1
        while name.lower() in {n.lower() for n in used_names}:
            name = f"{original_name}_{counter}"
            counter += 1

        # Add to used names
        used_names.add(name)

        return name

    def _generate_query_id(self, db_name: str, query: str) -> str:
        """Generate a unique query ID in format: {db}_{timestamp}_{4char_hash}."""
        timestamp = int(time.time())
        query_hash = hashlib.md5(query.encode(), usedforsecurity=False).hexdigest()[:4]  # nosec B324
        return f"{db_name}_{timestamp}_{query_hash}"

    def _cleanup_expired_buffers(self):
        """Remove expired query buffers (older than 10 minutes)."""
        current_time = time.time()
        if current_time - self.last_cleanup < self.buffer_cleanup_interval:
            return  # Skip if not time for cleanup yet

        with self.query_buffer_lock:
            expired_ids = [
                query_id
                for query_id, buffer in self.query_buffers.items()
                if current_time - buffer.timestamp > self.buffer_cleanup_interval
            ]
            for query_id in expired_ids:
                del self.query_buffers[query_id]

        self.last_cleanup = current_time

    def _cleanup_all(self):
        """Clean up all resources on exit."""
        # Clean up streaming executor buffers
        if hasattr(self, "streaming_executor"):
            try:
                self.streaming_executor.cleanup_expired_buffers(
                    max_age_seconds=0
                )  # Clean all
            except Exception:
                pass  # Ignore errors during cleanup

        # Clean up temporary files
        with self.temp_file_lock:
            for temp_file in self.temp_files:
                try:
                    if os.path.exists(temp_file):
                        os.unlink(temp_file)
                except OSError:
                    pass  # Ignore errors during cleanup
            self.temp_files.clear()

        # Close all database connections
        with self.connection_lock:
            for name, engine in self.connections.items():
                try:
                    engine.dispose()
                except Exception:
                    pass  # Ignore errors during cleanup
            self.connections.clear()
            self.db_types.clear()
            self._tree_managers.clear()
            self._graph_managers.clear()
            for mgr in self._rdf_managers.values():
                try:
                    mgr.graph.close()
                except Exception:
                    pass
            self._rdf_managers.clear()
            self._sparql_connections.clear()

    def _get_engine(
        self,
        db_type: str,
        conn_string: str,
        sheet_name: Optional[str] = None,
        auth: Optional[Dict[str, Any]] = None,
    ):
        if db_type == "sqlite":
            return create_engine(f"sqlite:///{conn_string}")
        elif db_type == "postgresql":
            return create_engine(conn_string)
        elif db_type == "mysql":
            return create_engine(conn_string)
        elif db_type == "duckdb":
            if not DUCKDB_AVAILABLE:
                raise ValueError(
                    "duckdb library is required for DuckDB connections. Install with: pip install duckdb"
                )
            return create_engine(f"duckdb:///{conn_string}")
        elif db_type == "redis":
            if not REDIS_AVAILABLE:
                raise ValueError(
                    "redis library is required for Redis connections. Install with: pip install redis"
                )
            return self._create_redis_connection(conn_string)
        elif db_type == "elasticsearch":
            if not ELASTICSEARCH_AVAILABLE:
                raise ValueError(
                    "elasticsearch library is required for Elasticsearch connections. Install with: pip install elasticsearch"
                )
            return self._create_elasticsearch_connection(conn_string)
        elif db_type == "mongodb":
            if not PYMONGO_AVAILABLE:
                raise ValueError(
                    "pymongo library is required for MongoDB connections. Install with: pip install pymongo"
                )
            return self._create_mongodb_connection(conn_string)
        elif db_type == "influxdb":
            if not INFLUXDB_AVAILABLE:
                raise ValueError(
                    "influxdb-client library is required for InfluxDB connections. Install with: pip install influxdb-client"
                )
            return self._create_influxdb_connection(conn_string)
        elif db_type == "neo4j":
            if not NEO4J_AVAILABLE:
                raise ValueError(
                    "neo4j library is required for Neo4j connections. Install with: pip install neo4j"
                )
            return self._create_neo4j_connection(conn_string)
        elif db_type == "couchdb":
            if not COUCHDB_AVAILABLE:
                raise ValueError(
                    "couchdb library is required for CouchDB connections. Install with: pip install couchdb"
                )
            return self._create_couchdb_connection(conn_string)
        elif db_type in ["dot", "gml", "graphml", "mermaid"]:
            sanitized_path = self._sanitize_path(conn_string)
            return self._create_graph_engine(sanitized_path, db_type)
        elif db_type in ["turtle", "ntriples"]:
            sanitized_path = self._sanitize_path(conn_string)
            return self._create_rdf_engine(sanitized_path, db_type)
        elif db_type in ["json", "yaml", "toml"]:
            sanitized_path = self._sanitize_path(conn_string)
            return self._create_tree_engine(sanitized_path, db_type)
        elif db_type in [
            "csv",
            "excel",
            "ods",
            "numbers",
            "xml",
            "ini",
            "tsv",
            "parquet",
            "feather",
            "arrow",
            "hdf5",
        ]:
            sanitized_path = self._sanitize_path(conn_string)
            return self._create_engine_from_file(sanitized_path, db_type, sheet_name)
        elif db_type == "oracle":
            if not ORACLEDB_AVAILABLE:
                raise ValueError(
                    "Oracle requires 'oracledb'. "
                    "Install with: pip install localdata-mcp[enterprise]"
                )
            from .oracle_support import create_oracle_engine

            # Use auth param; fall back to legacy sheet_name JSON for compat
            oracle_auth = auth
            if oracle_auth is None and sheet_name:
                import json as _json

                try:
                    oracle_auth = _json.loads(sheet_name)
                except (_json.JSONDecodeError, TypeError):
                    pass
            return create_oracle_engine(conn_string, auth=oracle_auth)
        elif db_type == "mssql":
            if not MSSQL_AVAILABLE:
                raise ValueError(
                    "MS SQL requires 'pymssql' or 'pyodbc'. "
                    "Install with: pip install localdata-mcp[enterprise]"
                )
            from .mssql_support import create_mssql_engine

            # Use auth param; fall back to legacy sheet_name JSON for compat
            mssql_auth = auth
            if mssql_auth is None and sheet_name:
                import json as _json

                try:
                    mssql_auth = _json.loads(sheet_name)
                except (_json.JSONDecodeError, TypeError):
                    pass
            return create_mssql_engine(conn_string, auth=mssql_auth)
        elif db_type == "sparql":
            if not SPARQLWRAPPER_AVAILABLE:
                raise ValueError(
                    "SPARQLWrapper library is required for SPARQL endpoint connections. "
                    "Install with: pip install SPARQLWrapper"
                )
            return self._create_sparql_connection(conn_string)
        else:
            raise ValueError(f"Unsupported db_type: {db_type}")

    # Sentinel returned by _create_tree_engine so connect_database knows
    # to produce a tree summary instead of a flat-table summary.
    _TREE_ENGINE_MARKER = "__tree__"

    def _create_tree_engine(self, file_path: str, file_type: str):
        """Parse a structured file into tree storage and return the SQLite engine."""
        from sqlalchemy.pool import StaticPool

        # StaticPool + check_same_thread=False ensures all threads share
        # the same in-memory SQLite connection (the default SingletonThreadPool
        # gives each thread its own empty database).
        engine = create_engine(
            "sqlite:///:memory:",
            poolclass=StaticPool,
            connect_args={"check_same_thread": False},
        )
        mgr = TreeStorageManager(engine)

        parsers = {
            "toml": parse_toml_to_tree,
            "json": parse_json_to_tree,
            "yaml": parse_yaml_to_tree,
        }
        parser = parsers.get(file_type)
        if parser is None:
            raise ValueError(f"No tree parser for file type: {file_type}")
        parser(file_path, mgr)

        return (engine, mgr)

    def _create_graph_engine(self, file_path: str, file_type: str):
        """Parse a graph file into a GraphStorageManager backed by SQLite."""
        from sqlalchemy.pool import StaticPool
        from .graph_manager import GraphStorageManager
        from .graph_parsers import (
            parse_dot_to_graph,
            parse_gml_to_graph,
            parse_graphml_to_graph,
            parse_mermaid_to_graph,
        )

        engine = create_engine(
            "sqlite:///:memory:",
            poolclass=StaticPool,
            connect_args={"check_same_thread": False},
        )
        manager = GraphStorageManager(engine)
        parsers = {
            "dot": parse_dot_to_graph,
            "gml": parse_gml_to_graph,
            "graphml": parse_graphml_to_graph,
            "mermaid": parse_mermaid_to_graph,
        }
        parser = parsers.get(file_type)
        if parser is None:
            raise ValueError(f"No graph parser for file type: {file_type}")
        parser(file_path, manager)

        return (engine, manager)

    def _create_rdf_engine(self, file_path: str, file_type: str):
        """Parse an RDF file into an RDFStorageManager (no SQL engine needed)."""
        from sqlalchemy.pool import StaticPool
        from .rdf_storage import RDFStorageManager
        from .rdf_parsers import parse_turtle_to_rdf, parse_ntriples_to_rdf

        # Create a dummy SQLite engine so connect_database has something to store.
        engine = create_engine(
            "sqlite:///:memory:",
            poolclass=StaticPool,
            connect_args={"check_same_thread": False},
        )
        manager = RDFStorageManager()
        parsers = {"turtle": parse_turtle_to_rdf, "ntriples": parse_ntriples_to_rdf}
        parser = parsers.get(file_type)
        if parser is None:
            raise ValueError(f"No RDF parser for file type: {file_type}")
        parser(file_path, manager)

        return (engine, manager)

    def _create_sparql_connection(self, endpoint_url: str):
        """Connect to a remote SPARQL endpoint."""
        from sqlalchemy.pool import StaticPool

        from .sparql_endpoint import SPARQLEndpointConnection

        # Create a dummy SQLite engine so connect_database has something to store.
        engine = create_engine(
            "sqlite:///:memory:",
            poolclass=StaticPool,
            connect_args={"check_same_thread": False},
        )
        conn = SPARQLEndpointConnection(endpoint_url)
        return (engine, conn)

    def _create_engine_from_file(
        self, file_path: str, file_type: str, sheet_name: Optional[str] = None
    ):
        """Create SQLite engine from file, using streaming processing for supported formats.

        Args:
            file_path: Path to the file
            file_type: Type of file (excel, ods, numbers, csv, json, etc.)
            sheet_name: For Excel/ODS/Numbers files, specific sheet to load. If None, load all sheets/datasets.
        """
        try:
            # Check if file type is supported by streaming processors
            if FileProcessorFactory.is_supported(file_type):
                logger.info(
                    f"Using streaming processor for {file_type} file: {file_path}"
                )

                # Use streaming file processing
                engine, processing_metadata = create_streaming_file_engine(
                    file_path=file_path,
                    file_type=file_type,
                    sheet_name=sheet_name,
                    temp_files_registry=self.temp_files,
                )

                logger.info(f"Streaming processing completed: {processing_metadata}")
                return engine

            # Fallback to batch processing for unsupported formats
            logger.info(f"Using batch processing for {file_type} file: {file_path}")

            # Check if file is large
            is_large = self._is_large_file(file_path)

            # Load data based on file type (keeping existing logic for unsupported formats)
            if file_type == "yaml":
                with open(file_path, "r") as f:
                    yaml_data = yaml.safe_load(f)
                data = self._normalize_nested_data(yaml_data)
            elif file_type == "toml":
                if not TOML_AVAILABLE:
                    raise ValueError(
                        "toml library is required for TOML files. "
                        "Install with: pip install toml"
                    )
                with open(file_path, "r") as f:
                    toml_data = toml.load(f)
                data = self._normalize_nested_data(toml_data)
            elif file_type == "xml":
                data = self._load_xml_file(file_path)
            elif file_type == "ini":
                data = self._load_ini_file(file_path)
            elif file_type == "parquet":
                if not PYARROW_AVAILABLE:
                    raise ValueError(
                        "pyarrow library is required for Parquet files. "
                        "Install with: pip install pyarrow"
                    )
                data = pd.read_parquet(file_path, engine="pyarrow")
            elif file_type == "feather":
                if not PYARROW_AVAILABLE:
                    raise ValueError(
                        "pyarrow library is required for Feather files. "
                        "Install with: pip install pyarrow"
                    )
                data = pd.read_feather(file_path)
            elif file_type == "arrow":
                if not PYARROW_AVAILABLE:
                    raise ValueError(
                        "pyarrow library is required for Arrow files. "
                        "Install with: pip install pyarrow"
                    )
                data = pd.read_feather(file_path)  # Arrow IPC format uses same reader
            elif file_type == "hdf5":
                data = self._load_hdf5_file(file_path, sheet_name)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")

            # Create engine - use temporary file for large files, memory for small ones
            if is_large:
                # Create temporary SQLite file
                temp_fd, temp_path = tempfile.mkstemp(
                    suffix=".sqlite", prefix="db_client_"
                )
                os.close(
                    temp_fd
                )  # Close the file descriptor, SQLAlchemy will handle the file

                with self.temp_file_lock:
                    self.temp_files.append(temp_path)

                engine = create_engine(f"sqlite:///{temp_path}")
            else:
                engine = create_engine("sqlite:///:memory:")

            # Load data into SQLite
            # Handle multi-sheet files (Excel/ODS) vs single DataFrame files
            if isinstance(data, dict):
                # Multi-sheet file: create separate table for each sheet
                for table_name, df in data.items():
                    # Serialize complex nested objects before SQLite insertion
                    df_serialized = self._serialize_complex_columns(df)
                    df_serialized.to_sql(
                        table_name, engine, index=False, if_exists="replace"
                    )
                    logger.info(
                        f"Created table '{table_name}' with {len(df_serialized)} rows"
                    )
            else:
                # Single DataFrame: create single table called 'data_table'
                # Serialize complex nested objects before SQLite insertion
                data_serialized = self._serialize_complex_columns(data)
                data_serialized.to_sql(
                    "data_table", engine, index=False, if_exists="replace"
                )
                logger.info(
                    f"Created table 'data_table' with {len(data_serialized)} rows"
                )

            return engine

        except Exception as e:
            raise ValueError(
                f"Failed to create engine from {file_type} file '{file_path}': {e}"
            )

    def _load_excel_file(
        self, file_path: str, sheet_name: Optional[str] = None
    ) -> Dict[str, pd.DataFrame]:
        """Load Excel file (.xlsx or .xls) into dict of pandas DataFrames (one per sheet).

        Args:
            file_path: Path to the Excel file
            sheet_name: Specific sheet to load. If None, load all sheets.
        """
        # Check for security library
        if not DEFUSEDXML_AVAILABLE:
            logger.warning(
                "defusedxml not available - Excel files may be vulnerable to XML attacks"
            )

        # Detect file format based on extension
        file_ext = Path(file_path).suffix.lower()

        try:
            # Determine engine based on file extension
            if file_ext in [".xlsx", ".xlsm"]:
                # Modern Excel format
                if not OPENPYXL_AVAILABLE:
                    raise ValueError(
                        "openpyxl library is required for .xlsx files. "
                        "Install with: pip install openpyxl"
                    )
                engine = "openpyxl"

            elif file_ext == ".xls":
                # Legacy Excel format
                if not XLRD_AVAILABLE:
                    raise ValueError(
                        "xlrd library is required for .xls files. "
                        "Install with: pip install xlrd"
                    )
                engine = "xlrd"

            else:
                # Try pandas auto-detection as fallback
                logger.info(
                    f"Unknown Excel extension '{file_ext}', trying pandas auto-detection"
                )
                engine = None

            # Read all sheets or specific sheet
            with pd.ExcelFile(file_path, engine=engine) as excel_file:
                available_sheet_names = excel_file.sheet_names
                logger.info(
                    f"Found {len(available_sheet_names)} sheets in Excel file: {available_sheet_names}"
                )

                # Determine which sheets to load
                if sheet_name is not None:
                    if sheet_name not in available_sheet_names:
                        raise ValueError(
                            f"Sheet '{sheet_name}' not found in Excel file. Available sheets: {available_sheet_names}"
                        )
                    sheets_to_load = [sheet_name]
                    logger.info(f"Loading specific sheet: {sheet_name}")
                else:
                    sheets_to_load = available_sheet_names
                    logger.info(f"Loading all sheets")

                # Track used table names for uniqueness
                used_names = set()
                sheets_data = {}

                for current_sheet_name in sheets_to_load:
                    try:
                        # Load sheet data
                        df = pd.read_excel(excel_file, sheet_name=current_sheet_name)

                        # Skip empty sheets
                        if df.empty:
                            logger.warning(
                                f"Sheet '{current_sheet_name}' is empty, skipping"
                            )
                            continue

                        # Clean up column names (remove extra whitespace, replace problematic characters)
                        df.columns = [
                            str(col).strip().replace(" ", "_").replace("-", "_")
                            for col in df.columns
                        ]

                        # Handle Excel-specific data types
                        # Convert any datetime-like columns properly
                        for col in df.columns:
                            if df[col].dtype == "object":
                                # Try to convert to datetime if it looks like dates
                                try:
                                    pd.to_datetime(df[col], errors="raise")
                                    df[col] = pd.to_datetime(df[col], errors="coerce")
                                except:
                                    pass  # Keep as object type

                        # Sanitize sheet name for SQL table name
                        table_name = self._sanitize_sheet_name(
                            current_sheet_name, used_names
                        )
                        sheets_data[table_name] = df

                        logger.info(
                            f"Successfully loaded sheet '{current_sheet_name}' as table '{table_name}' with {len(df)} rows and {len(df.columns)} columns"
                        )

                    except Exception as e:
                        logger.warning(
                            f"Failed to load sheet '{current_sheet_name}': {e}"
                        )
                        continue

                if not sheets_data:
                    raise ValueError(
                        f"Excel file '{file_path}' contains no readable data in any sheets"
                    )

                logger.info(
                    f"Successfully loaded Excel file '{file_path}' with {len(sheets_data)} sheets"
                )
                return sheets_data

        except Exception as e:
            raise ValueError(f"Failed to load Excel file '{file_path}': {e}")

    def _load_ods_file(
        self, file_path: str, sheet_name: Optional[str] = None
    ) -> Dict[str, pd.DataFrame]:
        """Load LibreOffice Calc ODS file into dict of pandas DataFrames (one per sheet).

        Args:
            file_path: Path to the ODS file
            sheet_name: Specific sheet to load. If None, load all sheets.
        """
        # Check for ODS support
        if not ODFPY_AVAILABLE:
            logger.warning("odfpy not available - ODS files cannot be loaded")
            raise ValueError(
                "odfpy library is required for .ods files. "
                "Install with: pip install odfpy"
            )

        try:
            # Use pandas native ODS support with odfpy engine
            with pd.ExcelFile(file_path, engine="odf") as excel_file:
                available_sheet_names = excel_file.sheet_names
                logger.info(
                    f"Found {len(available_sheet_names)} sheets in ODS file: {available_sheet_names}"
                )

                # Determine which sheets to load
                if sheet_name is not None:
                    if sheet_name not in available_sheet_names:
                        raise ValueError(
                            f"Sheet '{sheet_name}' not found in ODS file. Available sheets: {available_sheet_names}"
                        )
                    sheets_to_load = [sheet_name]
                    logger.info(f"Loading specific sheet: {sheet_name}")
                else:
                    sheets_to_load = available_sheet_names
                    logger.info(f"Loading all sheets")

                # Track used table names for uniqueness
                used_names = set()
                sheets_data = {}

                for current_sheet_name in sheets_to_load:
                    try:
                        # Load sheet data
                        df = pd.read_excel(
                            excel_file, sheet_name=current_sheet_name, engine="odf"
                        )

                        # Skip empty sheets
                        if df.empty:
                            logger.warning(
                                f"Sheet '{current_sheet_name}' is empty, skipping"
                            )
                            continue

                        # Clean up column names (remove extra whitespace, replace problematic characters)
                        df.columns = [
                            str(col).strip().replace(" ", "_").replace("-", "_")
                            for col in df.columns
                        ]

                        # Handle ODS-specific data types
                        # Convert any datetime-like columns properly
                        for col in df.columns:
                            if df[col].dtype == "object":
                                # Try to convert to datetime if it looks like dates
                                try:
                                    pd.to_datetime(df[col], errors="raise")
                                    df[col] = pd.to_datetime(df[col], errors="coerce")
                                except:
                                    pass  # Keep as object type

                        # Sanitize sheet name for SQL table name
                        table_name = self._sanitize_sheet_name(
                            current_sheet_name, used_names
                        )
                        sheets_data[table_name] = df

                        logger.info(
                            f"Successfully loaded sheet '{current_sheet_name}' as table '{table_name}' with {len(df)} rows and {len(df.columns)} columns"
                        )

                    except Exception as e:
                        logger.warning(
                            f"Failed to load sheet '{current_sheet_name}': {e}"
                        )
                        continue

                if not sheets_data:
                    raise ValueError(
                        f"ODS file '{file_path}' contains no readable data in any sheets"
                    )

                logger.info(
                    f"Successfully loaded ODS file '{file_path}' with {len(sheets_data)} sheets"
                )
                return sheets_data

        except Exception as e:
            raise ValueError(f"Failed to load ODS file '{file_path}': {e}")

    def _load_numbers_file(
        self, file_path: str, sheet_name: Optional[str] = None
    ) -> Dict[str, pd.DataFrame]:
        """Load Apple Numbers file into dict of pandas DataFrames (one per sheet/table).

        Args:
            file_path: Path to the Numbers file
            sheet_name: Specific sheet to load. If None, load all sheets.
        """
        # Check for Numbers support
        if not NUMBERS_PARSER_AVAILABLE:
            logger.warning(
                "numbers-parser not available - Numbers files cannot be loaded"
            )
            raise ValueError(
                "numbers-parser library is required for .numbers files. "
                "Install with: pip install numbers-parser"
            )

        try:
            # Open Numbers document
            doc = Document(file_path)
            logger.info(f"Opened Numbers document with {len(doc.sheets)} sheets")

            # Determine which sheets to load
            if sheet_name is not None:
                available_sheet_names = [sheet.name for sheet in doc.sheets]
                if sheet_name not in available_sheet_names:
                    raise ValueError(
                        f"Sheet '{sheet_name}' not found in Numbers file. Available sheets: {available_sheet_names}"
                    )
                sheets_to_load = [
                    sheet for sheet in doc.sheets if sheet.name == sheet_name
                ]
                logger.info(f"Loading specific sheet: {sheet_name}")
            else:
                sheets_to_load = doc.sheets
                sheet_names = [sheet.name for sheet in sheets_to_load]
                logger.info(f"Loading all sheets: {sheet_names}")

            # Track used table names for uniqueness
            used_names = set()
            sheets_data = {}

            for sheet in sheets_to_load:
                logger.info(
                    f"Processing sheet '{sheet.name}' with {len(sheet.tables)} tables"
                )

                # Numbers files can have multiple tables per sheet
                for table_idx, table in enumerate(sheet.tables):
                    try:
                        # Get table data as list of lists (includes headers)
                        table_data = table.rows(values_only=True)

                        if not table_data:
                            logger.warning(
                                f"Table {table_idx} in sheet '{sheet.name}' is empty, skipping"
                            )
                            continue

                        # First row is typically headers
                        if len(table_data) < 2:
                            logger.warning(
                                f"Table {table_idx} in sheet '{sheet.name}' has no data rows, skipping"
                            )
                            continue

                        # Create DataFrame from table data
                        headers = table_data[0]
                        data_rows = table_data[1:]

                        # Handle case where headers might be None or empty
                        if not headers or all(h is None or h == "" for h in headers):
                            # Generate column names
                            headers = [
                                f"Column_{i + 1}"
                                for i in range(len(data_rows[0]) if data_rows else 0)
                            ]
                        else:
                            # Clean up headers
                            headers = [
                                str(h) if h is not None else f"Column_{i + 1}"
                                for i, h in enumerate(headers)
                            ]

                        df = pd.DataFrame(data_rows, columns=headers)

                        # Skip empty DataFrames
                        if df.empty:
                            logger.warning(
                                f"Table {table_idx} in sheet '{sheet.name}' resulted in empty DataFrame, skipping"
                            )
                            continue

                        # Clean up column names (remove extra whitespace, replace problematic characters)
                        df.columns = [
                            str(col)
                            .strip()
                            .replace(" ", "_")
                            .replace("-", "_")
                            .replace(".", "_")
                            for col in df.columns
                        ]

                        # Handle Numbers-specific data types and formatting
                        for col in df.columns:
                            if df[col].dtype == "object":
                                # Try to convert numeric strings to numbers
                                try:
                                    # Check if this looks like a numeric column
                                    numeric_df = pd.to_numeric(df[col], errors="coerce")
                                    non_null_count = numeric_df.notna().sum()
                                    if (
                                        non_null_count > len(df) * 0.5
                                    ):  # If >50% can be converted to numbers
                                        df[col] = numeric_df
                                        continue
                                except:
                                    pass

                                # Try to convert to datetime if it looks like dates
                                try:
                                    pd.to_datetime(df[col], errors="raise")
                                    df[col] = pd.to_datetime(df[col], errors="coerce")
                                except:
                                    pass  # Keep as object type

                        # Create unique table name
                        if len(sheet.tables) == 1:
                            # Single table per sheet - use sheet name
                            base_table_name = (
                                sheet.name or f"Sheet_{len(sheets_data) + 1}"
                            )
                        else:
                            # Multiple tables per sheet - include table index
                            base_table_name = (
                                f"{sheet.name}_Table_{table_idx + 1}"
                                if sheet.name
                                else f"Sheet_{len(sheets_data) + 1}_Table_{table_idx + 1}"
                            )

                        # Sanitize table name for SQL table name
                        table_name = self._sanitize_sheet_name(
                            base_table_name, used_names
                        )
                        sheets_data[table_name] = df

                        logger.info(
                            f"Successfully loaded table {table_idx} from sheet '{sheet.name}' as table '{table_name}' with {len(df)} rows and {len(df.columns)} columns"
                        )

                    except Exception as e:
                        logger.warning(
                            f"Failed to load table {table_idx} from sheet '{sheet.name}': {e}"
                        )
                        continue

            if not sheets_data:
                raise ValueError(
                    f"Numbers file '{file_path}' contains no readable data in any sheets/tables"
                )

            logger.info(
                f"Successfully loaded Numbers file '{file_path}' with {len(sheets_data)} tables"
            )
            return sheets_data

        except Exception as e:
            # Handle specific Numbers parser limitations
            error_msg = str(e).lower()
            if "password" in error_msg or "encrypted" in error_msg:
                raise ValueError(
                    f"Numbers file '{file_path}' is password-protected. Please remove the password and try again."
                )
            elif "unsupported" in error_msg:
                raise ValueError(
                    f"Numbers file '{file_path}' uses unsupported features. Try re-saving the file in Numbers and try again."
                )
            else:
                raise ValueError(f"Failed to load Numbers file '{file_path}': {e}")

    def _load_hdf5_file(
        self, file_path: str, dataset_name: Optional[str] = None
    ) -> Dict[str, pd.DataFrame]:
        """Load HDF5 file into dict of pandas DataFrames (one per dataset).

        Args:
            file_path: Path to the HDF5 file
            dataset_name: Specific dataset to load. If None, load all compatible datasets.
        """
        # Check for HDF5 support
        if not H5PY_AVAILABLE:
            logger.warning("h5py not available - HDF5 files cannot be loaded")
            raise ValueError(
                "h5py library is required for .hdf5 files. "
                "Install with: pip install h5py"
            )

        try:
            import h5py

            datasets_data = {}
            used_names = set()

            with h5py.File(file_path, "r") as hdf_file:
                logger.info(
                    f"Opened HDF5 file with {len(hdf_file.keys())} top-level items"
                )

                # Recursive function to explore HDF5 structure
                def explore_hdf5_group(group, path=""):
                    """Recursively explore HDF5 groups and datasets."""
                    datasets_found = {}

                    for key in group.keys():
                        item = group[key]
                        current_path = f"{path}/{key}" if path else key

                        if isinstance(item, h5py.Dataset):
                            # This is a dataset - try to convert to DataFrame
                            try:
                                # Get dataset info
                                shape = item.shape
                                dtype = item.dtype
                                logger.info(
                                    f"Found dataset '{current_path}': shape={shape}, dtype={dtype}"
                                )

                                # Skip if dataset_name is specified and doesn't match
                                if (
                                    dataset_name is not None
                                    and key != dataset_name
                                    and current_path != dataset_name
                                ):
                                    continue

                                # Read dataset
                                data = item[...]

                                # Convert to DataFrame based on shape
                                if len(shape) == 1:
                                    # 1D array - create single column DataFrame
                                    df = pd.DataFrame({key: data})
                                elif len(shape) == 2:
                                    # 2D array - assume rows x columns
                                    if shape[1] == 1:
                                        # Single column
                                        df = pd.DataFrame({key: data.flatten()})
                                    else:
                                        # Multiple columns - generate column names
                                        columns = [
                                            f"{key}_col_{i + 1}"
                                            for i in range(shape[1])
                                        ]
                                        df = pd.DataFrame(data, columns=columns)
                                else:
                                    # Higher dimensional - flatten to 2D
                                    data_2d = data.reshape(shape[0], -1)
                                    columns = [
                                        f"{key}_dim_{i + 1}"
                                        for i in range(data_2d.shape[1])
                                    ]
                                    df = pd.DataFrame(data_2d, columns=columns)
                                    logger.info(
                                        f"Flattened {len(shape)}D dataset to 2D: {data_2d.shape}"
                                    )

                                # Handle data types
                                for col in df.columns:
                                    # Try to convert bytes to strings
                                    if df[col].dtype.kind == "S":  # String/bytes type
                                        try:
                                            df[col] = (
                                                df[col]
                                                .astype(str)
                                                .str.decode("utf-8", errors="ignore")
                                            )
                                        except:
                                            df[col] = df[col].astype(str)

                                # Create sanitized table name
                                table_name = self._sanitize_sheet_name(
                                    current_path.replace("/", "_"), used_names
                                )
                                datasets_found[table_name] = df

                                logger.info(
                                    f"Successfully loaded dataset '{current_path}' as table '{table_name}' with {len(df)} rows and {len(df.columns)} columns"
                                )

                            except Exception as e:
                                logger.warning(
                                    f"Failed to load dataset '{current_path}': {e}"
                                )
                                continue

                        elif isinstance(item, h5py.Group):
                            # This is a group - recurse into it
                            logger.info(
                                f"Exploring group '{current_path}' with {len(item.keys())} items"
                            )
                            sub_datasets = explore_hdf5_group(item, current_path)
                            datasets_found.update(sub_datasets)

                    return datasets_found

                # Start exploration from root
                if dataset_name is not None:
                    # Look for specific dataset
                    available_datasets = []

                    def collect_dataset_names(group, path=""):
                        for key in group.keys():
                            item = group[key]
                            current_path = f"{path}/{key}" if path else key
                            if isinstance(item, h5py.Dataset):
                                available_datasets.append(current_path)
                            elif isinstance(item, h5py.Group):
                                collect_dataset_names(item, current_path)

                    collect_dataset_names(hdf_file)

                    # Check if requested dataset exists
                    if dataset_name not in available_datasets and dataset_name not in [
                        d.split("/")[-1] for d in available_datasets
                    ]:
                        raise ValueError(
                            f"Dataset '{dataset_name}' not found in HDF5 file. Available datasets: {available_datasets}"
                        )

                datasets_data = explore_hdf5_group(hdf_file)

                if not datasets_data:
                    raise ValueError(
                        f"HDF5 file '{file_path}' contains no readable datasets"
                    )

                logger.info(
                    f"Successfully loaded HDF5 file '{file_path}' with {len(datasets_data)} datasets"
                )
                return datasets_data

        except Exception as e:
            # Handle specific HDF5 errors
            error_msg = str(e).lower()
            if "permission" in error_msg or "access" in error_msg:
                raise ValueError(
                    f"Cannot access HDF5 file '{file_path}': Permission denied or file in use"
                )
            elif "not an hdf5 file" in error_msg:
                raise ValueError(f"File '{file_path}' is not a valid HDF5 file")
            else:
                raise ValueError(f"Failed to load HDF5 file '{file_path}': {e}")

    def _load_xml_file(self, file_path: str) -> pd.DataFrame:
        """Load XML file into pandas DataFrame."""
        try:
            # Use pandas native XML support (available since pandas 1.3.0)
            df = pd.read_xml(file_path)

            # Validate that we have data
            if df.empty:
                raise ValueError(f"XML file '{file_path}' contains no data")

            # Clean up column names
            df.columns = [
                str(col).strip().replace(" ", "_").replace("-", "_")
                for col in df.columns
            ]

            logger.info(
                f"Successfully loaded XML file '{file_path}' with {len(df)} rows and {len(df.columns)} columns"
            )
            return df

        except Exception as e:
            # If pandas XML reading fails, provide helpful error message
            if "lxml" in str(e).lower():
                if not LXML_AVAILABLE:
                    raise ValueError(
                        f"Failed to load XML file '{file_path}': lxml library is required. "
                        "Install with: pip install lxml"
                    )
            raise ValueError(f"Failed to load XML file '{file_path}': {e}")

    def _load_ini_file(self, file_path: str) -> pd.DataFrame:
        """Load INI configuration file into pandas DataFrame."""
        try:
            config = configparser.ConfigParser()
            config.read(file_path)

            # Convert INI structure to flat DataFrame format
            rows = []
            for section_name in config.sections():
                section = config[section_name]
                for key, value in section.items():
                    rows.append({"section": section_name, "key": key, "value": value})

            # Handle case where no sections exist (only DEFAULT section)
            if not rows and config.defaults():
                for key, value in config.defaults().items():
                    rows.append({"section": "DEFAULT", "key": key, "value": value})

            if not rows:
                raise ValueError(
                    f"INI file '{file_path}' contains no configuration data"
                )

            df = pd.DataFrame(rows)
            logger.info(
                f"Successfully loaded INI file '{file_path}' with {len(df)} configuration entries"
            )
            return df

        except Exception as e:
            raise ValueError(f"Failed to load INI file '{file_path}': {e}")

    def _get_table_metadata(self, inspector, table_name):
        columns = inspector.get_columns(table_name)
        foreign_keys = inspector.get_foreign_keys(table_name)
        primary_keys = inspector.get_pk_constraint(table_name)["constrained_columns"]
        indexes = inspector.get_indexes(table_name)
        try:
            table_options = inspector.get_table_options(table_name)
        except NotImplementedError:
            # SQLite and some other dialects don't support table options
            table_options = {}

        col_list = []
        for col in columns:
            col_info = {"name": col["name"], "type": str(col["type"])}
            if col["nullable"] is False:
                col_info["not_null"] = True
            if col.get("autoincrement", False) is True:
                col_info["autoincrement"] = True
            if col.get("default"):
                col_info["default"] = str(col["default"])

            if col["name"] in primary_keys:
                col_info["primary_key"] = True

            for fk in foreign_keys:
                if col["name"] in fk["constrained_columns"]:
                    col_info["foreign_key"] = {
                        "referred_table": fk["referred_table"],
                        "referred_column": fk["referred_columns"][0],
                    }
            col_list.append(col_info)

        index_list = []
        for idx in indexes:
            index_list.append(
                {
                    "name": idx["name"],
                    "columns": idx["column_names"],
                    "unique": idx.get("unique", False),
                }
            )

        return {
            "name": table_name,
            "columns": col_list,
            "foreign_keys": [f["name"] for f in foreign_keys],
            "primary_keys": primary_keys,
            "indexes": index_list,
            "options": table_options,
        }

    def _build_connection_summary(
        self, engine, name: str, db_type: str, sql_flavor: str
    ) -> dict:
        """Build a data summary returned on connect so the LLM knows what's
        available without issuing a broad SELECT *.

        Returns table names, column schemas, row counts, and a few sample
        values per column so the LLM can craft targeted queries.
        """
        summary: Dict[str, Any] = {
            "success": True,
            "message": f"Successfully connected to database '{name}'",
            "connection_info": {
                "name": name,
                "db_type": db_type,
                "sql_flavor": sql_flavor,
                "total_connections": self.connection_count,
            },
            "tables": [],
        }

        try:
            insp = inspect(engine)
            table_names = insp.get_table_names()

            for tbl in table_names:
                table_meta = self._get_table_metadata(insp, tbl)

                # Row count
                safe_tbl = self._safe_table_identifier(tbl)
                with engine.connect() as conn:
                    row_count = conn.execute(
                        text(f"SELECT COUNT(*) FROM {safe_tbl}")  # nosec B608
                    ).scalar()

                # Sample values: first 3 rows, truncate long strings
                sample_rows: List[Dict[str, Any]] = []
                try:
                    with engine.connect() as conn:
                        result = conn.execute(
                            text(f"SELECT * FROM {safe_tbl} LIMIT 3")  # nosec B608
                        )
                        cols = list(result.keys())
                        for row in result:
                            sample = {}
                            for col_name, val in zip(cols, row):
                                if isinstance(val, str) and len(val) > 120:
                                    val = val[:120] + "..."
                                sample[col_name] = val
                            sample_rows.append(sample)
                except Exception:
                    pass  # sample is best-effort

                col_summary = []
                for col in table_meta["columns"]:
                    entry = {"name": col["name"], "type": col["type"]}
                    if col.get("primary_key"):
                        entry["primary_key"] = True
                    if col.get("not_null"):
                        entry["not_null"] = True
                    col_summary.append(entry)

                summary["tables"].append(
                    {
                        "name": tbl,
                        "row_count": row_count,
                        "columns": col_summary,
                        "sample_rows": sample_rows,
                    }
                )

        except Exception as e:
            logger.warning(f"Could not build connection summary for '{name}': {e}")
            summary["summary_error"] = str(e)

        return summary

    def _build_tree_connection_summary(self, name: str, db_type: str) -> dict:
        """Build a tree-structure summary for structured data connections."""
        mgr = self._tree_managers[name]
        stats = mgr.get_tree_stats()

        # Sample structure: first few root nodes with property count and children
        sample: Dict[str, Any] = {}
        for root_name in stats["root_nodes"][:10]:
            children = mgr.get_children(root_name, limit=5)
            sample[root_name] = {
                "properties": mgr.get_property_count(root_name),
                "children": [c.path for c in children],
            }

        return {
            "success": True,
            "message": f"Successfully connected to database '{name}'",
            "connection_info": {
                "name": name,
                "db_type": db_type,
                "storage": "tree",
                "total_connections": self.connection_count,
            },
            "tree_summary": {
                "root_nodes": stats["root_nodes"],
                "total_nodes": stats["total_nodes"],
                "total_properties": stats["total_properties"],
                "max_depth": stats["max_depth"],
                "sample_structure": sample,
            },
            "available_tools": [
                "get_node",
                "get_children",
                "set_node",
                "delete_node",
                "list_keys",
                "get_value",
                "set_value",
                "delete_key",
                "export_structured",
            ],
        }

    def _get_tree_manager(self, name: str) -> "TreeStorageManager":
        """Get the TreeStorageManager for a connection, or raise ValueError."""
        if name not in self._tree_managers:
            raise ValueError(
                f"'{name}' is not a tree-structured connection. "
                "Tree tools only work with TOML, JSON, or YAML connections."
            )
        return self._tree_managers[name]

    def _build_graph_connection_summary(self, name: str, db_type: str) -> dict:
        """Build a graph-structure summary for graph data connections."""
        mgr = self._graph_managers[name]
        stats = mgr.get_graph_stats()
        return {
            "success": True,
            "message": f"Successfully connected to database '{name}'",
            "connection_info": {
                "name": name,
                "db_type": db_type,
                "storage": "graph",
                "total_connections": self.connection_count,
            },
            "graph_summary": {
                "node_count": stats["node_count"],
                "edge_count": stats["edge_count"],
                "property_count": stats["property_count"],
                "is_directed": stats["is_directed"],
                "density": stats["density"],
            },
        }

    def _build_rdf_connection_summary(self, name: str, db_type: str) -> dict:
        """Build an RDF summary for RDF data connections."""
        mgr = self._rdf_managers[name]
        stats = mgr.get_stats()
        return {
            "success": True,
            "message": f"Successfully connected to database '{name}'",
            "connection_info": {
                "name": name,
                "db_type": db_type,
                "storage": "rdf",
                "total_connections": self.connection_count,
            },
            "rdf_summary": {
                "triple_count": stats["triple_count"],
                "namespaces": stats["namespaces"],
                "subject_count": stats["subject_count"],
                "predicate_count": stats["predicate_count"],
                "object_count": stats["object_count"],
            },
        }

    def _get_graph_manager(self, name: str) -> "GraphStorageManager":  # noqa: F821
        """Get the GraphStorageManager for a connection, or raise ValueError."""
        if name not in self._graph_managers:
            raise ValueError(
                f"'{name}' is not a graph-structured connection. "
                "Graph tools only work with DOT, GML, or GraphML connections."
            )
        return self._graph_managers[name]

    def _get_rdf_manager(self, name: str) -> "RDFStorageManager":  # noqa: F821
        """Get the RDFStorageManager for a connection, or raise ValueError."""
        if name not in self._rdf_managers:
            raise ValueError(
                f"'{name}' is not an RDF connection. "
                "RDF tools only work with Turtle or N-Triples connections."
            )
        return self._rdf_managers[name]

    def _execute_sparql(self, name: str, query: str) -> str:
        """Execute a SPARQL query against an RDF connection."""
        mgr = self._get_rdf_manager(name)
        try:
            results = mgr.execute_sparql(query)
            return json.dumps({"success": True, "results": results}, indent=2)
        except ValueError as exc:
            return json.dumps({"success": False, "error": str(exc)})

    def _build_sparql_connection_summary(self, name: str, db_type: str) -> dict:
        """Build a connection summary for a SPARQL endpoint."""
        conn = self._sparql_connections[name]
        stats = conn.get_stats()
        return {
            "success": True,
            "message": f"Successfully connected to SPARQL endpoint '{name}'",
            "connection_info": {
                "name": name,
                "db_type": db_type,
                "storage": "sparql_endpoint",
                "endpoint_url": conn.endpoint_url,
                "total_connections": self.connection_count,
            },
            "sparql_summary": stats,
        }

    def _execute_sparql_remote(self, name: str, query: str) -> str:
        """Execute a SPARQL query against a remote endpoint."""
        conn = self._sparql_connections[name]
        try:
            results = conn.execute_query(query)
            return json.dumps(
                {
                    "query_type": "SPARQL",
                    "endpoint": conn.endpoint_url,
                    "results": results,
                    "count": len(results),
                }
            )
        except Exception as e:
            logger.error("SPARQL query failed on '%s': %s", name, e)
            return json.dumps({"error": str(e), "query_type": "SPARQL"})

    # -- Tree/Graph tool wrappers (dispatch to tree or graph variant) ------

    def get_node(self, name: str, path: Optional[str] = None) -> Dict[str, Any]:
        """Get node details or summary for a tree, graph, or RDF connection.

        For graph connections, *path* is used as node_id.
        For RDF connections, *path* is used as subject URI.
        """
        if name in self._graph_managers:
            return tool_get_node_graph(
                self._get_graph_manager(name), name, node_id=path
            )
        if name in self._rdf_managers:
            mgr = self._get_rdf_manager(name)
            if path is None:
                return mgr.get_stats()
            predicates = mgr.get_predicates_for_subject(path)
            result: Dict[str, Any] = {"subject": path, "predicates": {}}
            for pred in predicates:
                result["predicates"][pred] = mgr.get_objects(path, pred)
            return result
        return tool_get_node(self._get_tree_manager(name), name, path)

    def get_children(
        self, name: str, path: Optional[str] = None, offset: int = 0, limit: int = 50
    ) -> Dict[str, Any]:
        """Get children of a node (or root nodes) with pagination."""
        return tool_get_children(
            self._get_tree_manager(name), name, path, offset, limit
        )

    def set_node(
        self, name: str, path: str, label: Optional[str] = None
    ) -> Dict[str, Any]:
        """Create a node in a tree or graph connection.

        For graph connections, *path* is used as node_id.
        """
        if name in self._graph_managers:
            return tool_set_node_graph(
                self._get_graph_manager(name), name, node_id=path, label=label
            )
        return tool_set_node(self._get_tree_manager(name), name, path)

    def move_node(
        self, name: str, path: str, new_parent: Optional[str] = None
    ) -> Dict[str, Any]:
        """Move a node and its subtree under a new parent (or to root level)."""
        return tool_move_node(self._get_tree_manager(name), name, path, new_parent)

    def delete_node(self, name: str, path: str) -> Dict[str, Any]:
        """Delete a node and all its descendants (or cascade for graphs)."""
        if name in self._graph_managers:
            return tool_delete_node_graph(
                self._get_graph_manager(name), name, node_id=path
            )
        return tool_delete_node(self._get_tree_manager(name), name, path)

    def list_keys(
        self, name: str, path: str, offset: int = 0, limit: int = 50
    ) -> Dict[str, Any]:
        """List key-value pairs at a node.

        For graph connections, *path* is used as node_id.
        """
        if name in self._graph_managers:
            return tool_list_keys_graph(
                self._get_graph_manager(name),
                name,
                node_id=path,
                offset=offset,
                limit=limit,
            )
        return tool_list_keys(self._get_tree_manager(name), name, path, offset, limit)

    def get_value(self, name: str, path: str, key: str) -> Dict[str, Any]:
        """Get a specific property value from a node.

        For graph connections, *path* is used as node_id.
        """
        if name in self._graph_managers:
            return tool_get_value_graph(
                self._get_graph_manager(name), name, node_id=path, key=key
            )
        return tool_get_value(self._get_tree_manager(name), name, path, key)

    def set_value(
        self,
        name: str,
        path: str,
        key: str,
        value: str,
        value_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Set a property on a node (auto-creates node if needed).

        For graph connections, *path* is used as node_id.
        """
        if name in self._graph_managers:
            return tool_set_value_graph(
                self._get_graph_manager(name),
                name,
                node_id=path,
                key=key,
                value=value,
                value_type=value_type,
            )
        return tool_set_value(
            self._get_tree_manager(name), name, path, key, value, value_type
        )

    def delete_key(self, name: str, path: str, key: str) -> Dict[str, Any]:
        """Delete a property from a node.

        For graph connections, *path* is used as node_id.
        """
        if name in self._graph_managers:
            return tool_delete_key_graph(
                self._get_graph_manager(name), name, node_id=path, key=key
            )
        return tool_delete_key(self._get_tree_manager(name), name, path, key)

    def export_structured(
        self, name: str, format: str, path: Optional[str] = None
    ) -> Dict[str, Any]:
        """Export tree data as TOML/JSON/YAML, or RDF data as Turtle/N-Triples."""
        if name in self._rdf_managers:
            return self._export_rdf(name, format)
        return tool_export_structured(self._get_tree_manager(name), name, format, path)

    def _export_rdf(self, name: str, format: str) -> Dict[str, Any]:
        """Export RDF graph in Turtle or N-Triples format with size limit."""
        from .graph_algorithms import MAX_EXPORT_BYTES

        fmt_map = {"turtle": "turtle", "ttl": "turtle", "ntriples": "nt", "nt": "nt"}
        fmt = fmt_map.get(format.lower())
        if fmt is None:
            return {
                "error": (
                    f"Unsupported RDF format '{format}'. "
                    "Use turtle, ttl, ntriples, or nt."
                )
            }

        mgr = self._get_rdf_manager(name)
        output = mgr.serialize(format=fmt)

        if len(output.encode("utf-8")) > MAX_EXPORT_BYTES:
            truncated = output[: MAX_EXPORT_BYTES // 2]
            return {
                "format": fmt,
                "truncated": True,
                "content": truncated,
                "notice": (
                    f"Output exceeded {MAX_EXPORT_BYTES // 1024}KB limit. "
                    "Use SPARQL CONSTRUCT to export a smaller subset."
                ),
            }

        return {"format": fmt, "content": output}

    # -- Graph-only tool wrappers -------------------------------------------

    def get_neighbors(
        self,
        name: str,
        node_id: str,
        direction: str = "both",
        offset: int = 0,
        limit: int = 50,
    ) -> Dict[str, Any]:
        """Get neighbors of a graph node with edge info."""
        return tool_get_neighbors(
            self._get_graph_manager(name), name, node_id, direction, offset, limit
        )

    def get_edges(
        self,
        name: str,
        node_id: Optional[str] = None,
        offset: int = 0,
        limit: int = 50,
    ) -> Dict[str, Any]:
        """List edges in a graph, optionally filtered by node."""
        return tool_get_edges(
            self._get_graph_manager(name), name, node_id, offset, limit
        )

    def add_edge(
        self,
        name: str,
        source: str,
        target: str,
        label: Optional[str] = None,
        weight: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Add an edge to a graph (auto-creates nodes)."""
        return tool_add_edge(
            self._get_graph_manager(name), name, source, target, label, weight
        )

    def remove_edge(
        self,
        name: str,
        source: str,
        target: str,
        label: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Remove an edge from a graph."""
        return tool_remove_edge(
            self._get_graph_manager(name), name, source, target, label
        )

    def find_path(
        self,
        name: str,
        source: str,
        target: str,
        algorithm: str = "shortest",
    ) -> Dict[str, Any]:
        """Find path(s) between two graph nodes."""
        return tool_find_path(
            self._get_graph_manager(name), name, source, target, algorithm
        )

    def get_graph_stats(self, name: str) -> Dict[str, Any]:
        """Get advanced graph statistics."""
        return tool_get_graph_stats(self._get_graph_manager(name), name)

    def export_graph(
        self,
        name: str,
        format: str,
        node_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Export graph as DOT, GML, or GraphML."""
        return tool_export_graph(self._get_graph_manager(name), name, format, node_id)

    # =========================================================
    # Regex Tools
    # =========================================================

    def search_data(
        self,
        name: str,
        query: str,
        pattern: str,
        columns: Optional[str] = None,
        case_sensitive: bool = True,
        max_matches: int = 100,
    ) -> str:
        """Search query results for regex pattern matches.

        Args:
            name: Database connection name.
            query: SQL query to execute and search within.
            pattern: Regex pattern to search for.
            columns: Comma-separated column names to search (empty = all).
            case_sensitive: Whether search is case-sensitive.
            max_matches: Maximum matches to return.
        """
        from .regex_tools import search_data as _search

        engine = self._get_connection(name)
        with engine.connect() as conn:
            df = pd.read_sql(text(query), conn)
        data = json.loads(df.to_json(orient="records"))
        col_list = [c.strip() for c in columns.split(",")] if columns else None
        result = _search(data, pattern, col_list, case_sensitive, max_matches)
        return json.dumps(result)

    def transform_data(
        self,
        name: str,
        query: str,
        column: str,
        find: str,
        replace: str,
        max_rows: int = 1000,
    ) -> str:
        """Apply regex find/replace to a column in query results.

        Args:
            name: Database connection name.
            query: SQL query to execute.
            column: Column name to apply transformation on.
            find: Regex pattern to find.
            replace: Replacement string.
            max_rows: Maximum rows to process.
        """
        from .regex_tools import transform_data as _transform

        engine = self._get_connection(name)
        with engine.connect() as conn:
            df = pd.read_sql(text(query), conn)
        data = json.loads(df.to_json(orient="records"))
        result = _transform(data, column, find, replace, max_rows)
        return json.dumps(result)

    # =========================================================
    # Schema Export Tools
    # =========================================================

    def export_schema(
        self,
        name: str,
        tables: Optional[str] = None,
        format: str = "json_schema",
    ) -> str:
        """Export database schema in various formats.

        Args:
            name: Database connection name.
            tables: Comma-separated table names (empty = all).
            format: Export format: json_schema, python, typescript, sql_ddl.
        """
        from .schema_export import (
            SchemaIntrospector,
            export_json_schema,
            export_python_dataclass,
            export_sql_ddl,
            export_typescript,
        )

        engine = self._get_connection(name)
        introspector = SchemaIntrospector(engine)
        table_list = [t.strip() for t in tables.split(",")] if tables else None
        exporters = {
            "json_schema": lambda: json.dumps(
                export_json_schema(introspector, table_list)
            ),
            "python": lambda: export_python_dataclass(introspector, table_list),
            "typescript": lambda: export_typescript(introspector, table_list),
            "sql_ddl": lambda: export_sql_ddl(introspector, table_list),
        }
        exporter = exporters.get(format)
        if exporter is None:
            return json.dumps(
                {"error": f"Unknown format '{format}'. Use: {', '.join(exporters)}"}
            )
        return exporter()

    # =========================================================
    # Query Audit Tools
    # =========================================================

    def get_query_log(
        self,
        database: Optional[str] = None,
        limit: int = 50,
        status: Optional[str] = None,
        since_minutes: int = 60,
    ) -> str:
        """Get recent query execution history.

        Args:
            database: Filter by database name (empty = all).
            limit: Maximum entries to return.
            status: Filter by status: success, error, timeout (empty = all).
            since_minutes: Look back this many minutes.
        """
        from .query_audit import get_query_audit_buffer

        buffer = get_query_audit_buffer()
        entries = buffer.get_entries(
            database=database,
            status=status,
            since_minutes=since_minutes,
            limit=limit,
        )
        return json.dumps(
            {"entries": [e.to_dict() for e in entries], "total_entries": len(entries)}
        )

    def get_error_log(
        self,
        database: Optional[str] = None,
        limit: int = 50,
        since_minutes: int = 60,
    ) -> str:
        """Get recent error and timeout history.

        Args:
            database: Filter by database name (empty = all).
            limit: Maximum entries to return.
            since_minutes: Look back this many minutes.
        """
        from .query_audit import get_query_audit_buffer

        buffer = get_query_audit_buffer()
        errors = buffer.get_entries(
            database=database,
            status="error",
            since_minutes=since_minutes,
            limit=limit,
        )
        timeouts = buffer.get_entries(
            database=database,
            status="timeout",
            since_minutes=since_minutes,
            limit=limit,
        )
        combined = sorted(errors + timeouts, key=lambda e: e.timestamp, reverse=True)[
            :limit
        ]
        return json.dumps(
            {"entries": [e.to_dict() for e in combined], "total_entries": len(combined)}
        )

    # =========================================================
    # Requested Tools
    # =========================================================

    def connect_database(
        self,
        name: str,
        db_type: str,
        conn_string: str,
        sheet_name: Optional[str] = None,
        auth: Optional[str] = None,
    ):
        """
        Open a connection to a database.

        Args:
            name: A unique name to identify the connection (e.g., "analytics_db", "user_data").
            db_type: The type of the database ("sqlite", "postgresql", "mysql", "duckdb", "csv", "json", "yaml", "toml", "excel", "ods", "numbers", "xml", "ini", "tsv", "parquet", "feather", "arrow", "hdf5", "dot", "gml", "graphml", "mermaid", "turtle", "ntriples", "sparql").
            conn_string: The connection string or file path for the database.
            sheet_name: Optional sheet name to load from Excel/ODS/Numbers files, or dataset name for HDF5 files. If not specified, all sheets/datasets are loaded.
            auth: Optional JSON string with authentication config. Example: '{"method": "wallet", "wallet_path": "/opt/oracle/wallet"}' or '{"method": "kerberos"}'.
        """
        logger.info(f"Attempting to connect to database '{name}' of type '{db_type}'")

        if name in self.connections:
            logger.warning(f"Database '{name}' is already connected")
            return f"Error: A database with the name '{name}' is already connected."

        # Check connection limit
        if not self.connection_semaphore.acquire(blocking=False):
            logger.warning(f"Connection limit reached for database '{name}'")
            return f"Error: Maximum number of concurrent connections (10) reached. Please disconnect a database first."

        try:
            # Validate auth configuration if provided
            auth_dict = None
            if auth:
                import json as json_mod

                auth_dict = json_mod.loads(auth) if isinstance(auth, str) else auth
                from .auth_manager import AuthSecurityValidator, log_auth_attempt

                validator = AuthSecurityValidator()
                try:
                    auth_config = validator.validate(auth_dict, db_type)
                    log_auth_attempt(db_type, auth_config.method.value, True, name)
                except (ValueError, Exception) as e:
                    log_auth_attempt(
                        db_type, auth_dict.get("method", "unknown"), False, name
                    )
                    self.connection_semaphore.release()
                    return json.dumps({"error": str(e)})

            engine = self._get_engine(db_type, conn_string, sheet_name, auth_dict)

            # Unpack manager from creation helpers that return (engine, manager) tuples
            graph_manager = None
            rdf_manager = None
            sparql_conn = None
            tree_manager = None

            if isinstance(engine, tuple):
                engine, extra = engine
                if db_type in ("dot", "gml", "graphml", "mermaid"):
                    graph_manager = extra
                elif db_type in ("turtle", "ntriples"):
                    rdf_manager = extra
                elif db_type == "sparql":
                    sparql_conn = extra
                elif db_type in ("json", "yaml", "toml"):
                    tree_manager = extra

            sql_flavor = self._get_sql_flavor(db_type, engine)

            with self.connection_lock:
                self.connections[name] = engine
                self.db_types[name] = db_type
                self.query_history[name] = []
                self.connection_count += 1
                if graph_manager is not None:
                    self._graph_managers[name] = graph_manager
                if rdf_manager is not None:
                    self._rdf_managers[name] = rdf_manager
                if sparql_conn is not None:
                    self._sparql_connections[name] = sparql_conn
                if tree_manager is not None:
                    self._tree_managers[name] = tree_manager

            logger.info(
                f"Successfully connected to database '{name}' ({sql_flavor}). Total connections: {self.connection_count}"
            )

            # Return appropriate summary based on connection type
            if name in self._tree_managers:
                summary = self._build_tree_connection_summary(name, db_type)
            elif name in self._graph_managers:
                summary = self._build_graph_connection_summary(name, db_type)
            elif name in self._rdf_managers:
                summary = self._build_rdf_connection_summary(name, db_type)
            elif name in self._sparql_connections:
                summary = self._build_sparql_connection_summary(name, db_type)
            else:
                summary = self._build_connection_summary(
                    engine, name, db_type, sql_flavor
                )

            return json.dumps(summary, indent=2)

        except Exception as e:
            # Release semaphore on failure
            self.connection_semaphore.release()
            logger.error(f"Failed to connect to database '{name}': {e}")
            structured = classify_error(e, db_type)
            structured.database = name
            return json.dumps(structured.to_dict())

    def disconnect_database(self, name: str):
        """
        Close a connection to a database. All open connections are closed when the script terminates.

        Args:
            name: The name of the database connection to close.
        """
        logger.info(f"Attempting to disconnect from database '{name}'")
        try:
            conn = self._get_connection(name)
            conn.dispose()

            # Cascade-clean staging databases for this connection
            staging_cleaned = get_staging_manager().cleanup_by_parent(name)

            with self.connection_lock:
                del self.connections[name]
                del self.db_types[name]
                del self.query_history[name]
                self.connection_count -= 1
                # Clean up tree manager if present
                self._tree_managers.pop(name, None)
                self._graph_managers.pop(name, None)
                rdf_mgr = self._rdf_managers.pop(name, None)
                if rdf_mgr is not None:
                    try:
                        rdf_mgr.graph.close()
                    except Exception:
                        pass  # rdflib graph close is best-effort
                self._sparql_connections.pop(name, None)

            # Release semaphore slot
            self.connection_semaphore.release()

            logger.info(
                f"Successfully disconnected from database '{name}'. Total connections: {self.connection_count}"
            )
            msg = f"Successfully disconnected from database '{name}'."
            if staging_cleaned:
                msg += f" Cleaned {staging_cleaned} staging database(s)."
            return json.dumps(
                {
                    "message": msg,
                    "staging_cleaned": staging_cleaned,
                }
            )
        except ValueError as e:
            logger.error(f"Database '{name}' not found for disconnection: {e}")
            return str(e)
        except Exception as e:
            logger.error(f"Error disconnecting from database '{name}': {e}")
            return f"An error occurred while disconnecting: {e}"

    def execute_query(
        self,
        name: str,
        query: str,
        chunk_size: Optional[int] = None,
        enable_analysis: bool = True,
        include_blobs: bool = False,
        preflight: bool = False,
    ) -> str:
        """
        Execute a SQL query and return results as JSON.

        For large result sets (>100 rows), automatically creates chunked response with pagination.
        Includes pre-query analysis to estimate resource usage and prevent crashes.
        Auto-clears buffers from the same database when memory is high.

        Args:
            name: The name of the database connection.
            query: The SQL query to execute.
            chunk_size: Optional chunk size for pagination. If not specified, uses analysis recommendations.
            enable_analysis: Whether to perform pre-query analysis (default: True).
            include_blobs: When True, base64-encode small BLOBs in results. When False (default), replace BLOBs with informative placeholders.
            preflight: When True, run EXPLAIN without executing and return size/row estimates.
        """
        # Dispatch SPARQL queries for remote SPARQL endpoints
        if name in self._sparql_connections:
            return self._execute_sparql_remote(name, query)

        # Dispatch SPARQL queries for RDF connections
        if name in self._rdf_managers:
            return self._execute_sparql(name, query)

        # Pre-flight estimation mode: EXPLAIN only, no execution
        if preflight:
            return self._execute_preflight(name, query)

        try:
            # Backward compatibility check
            import inspect

            frame = inspect.currentframe()
            args, _, _, values = inspect.getargvalues(frame)
            compatibility_info = self.compatibility_manager.check_api_compatibility(
                "execute_query",
                (name, query),
                {"chunk_size": chunk_size, "enable_analysis": enable_analysis},
            )

            # Log compatibility warnings if any
            for warning in compatibility_info["warnings"]:
                logger.info(f"COMPATIBILITY: {warning}")
            for suggestion in compatibility_info["suggestions"]:
                logger.info(f"SUGGESTION: {suggestion}")

        except Exception as e:
            # Don't fail on compatibility check errors
            logger.warning(f"Compatibility check error: {e}")

        try:
            # Security validation: Only allow SELECT queries
            try:
                validated_query = parse_and_validate_sql(query)
                logger.info(f"SQL query validation passed for database '{name}'")
            except SQLSecurityError as e:
                logger.warning(f"SQL query blocked for database '{name}': {e}")
                return f"Security Error: {e}"
            except Exception as e:
                logger.error(f"Query validation error for database '{name}': {e}")
                return f"Query validation failed: {e}"

            engine = self._get_connection(name)

            # Pre-query analysis (optional but recommended)
            query_analysis = None
            if enable_analysis:
                try:
                    logger.info(f"Performing pre-query analysis for database '{name}'")
                    query_analysis = analyze_query(validated_query, engine, name)

                    # Log analysis results
                    logger.info(
                        f"Query analysis complete: {query_analysis.estimated_rows} rows, "
                        f"{query_analysis.estimated_total_memory_mb:.1f}MB, "
                        f"{query_analysis.estimated_total_tokens} tokens, "
                        f"risks: {query_analysis.memory_risk_level}/{query_analysis.token_risk_level}/{query_analysis.timeout_risk_level}"
                    )

                    # Check for critical risks and warn user
                    if query_analysis.memory_risk_level == "critical":
                        logger.warning(
                            f"CRITICAL memory risk detected: {query_analysis.estimated_total_memory_mb:.1f}MB estimated"
                        )

                    if query_analysis.timeout_risk_level == "critical":
                        logger.warning(
                            f"CRITICAL timeout risk detected: {query_analysis.estimated_execution_time_seconds:.1f}s estimated"
                        )

                except Exception as e:
                    logger.warning(
                        f"Pre-query analysis failed for database '{name}': {e}"
                    )
                    # Continue with execution even if analysis fails
                    query_analysis = None

            # Check memory usage before query execution
            memory_info = self._check_memory_usage()
            if memory_info.get("low_memory", False):
                logger.warning(
                    f"High memory usage detected ({memory_info.get('used_percent', 0)}%) before query execution"
                )
                # Auto-clear buffers from same database to free memory
                self._auto_clear_buffers_if_needed(name)

            # Clean up expired buffers
            self._cleanup_expired_buffers()

            # Use streaming execution for memory-bounded processing
            _query_start_time = time.time()
            query_id = self._generate_query_id(name, query)

            # Create streaming source
            streaming_source = create_streaming_source(
                engine=engine, query=validated_query, query_analysis=query_analysis
            )

            # Determine initial chunk size
            initial_chunk_size = chunk_size
            if initial_chunk_size is None:
                if query_analysis and query_analysis.should_chunk:
                    initial_chunk_size = query_analysis.recommended_chunk_size or 100
                else:
                    initial_chunk_size = 100  # Default

            # Execute streaming query with timeout management
            try:
                first_chunk, streaming_metadata = (
                    self.streaming_executor.execute_streaming(
                        streaming_source,
                        query_id,
                        initial_chunk_size,
                        database_name=name,  # Pass database name for timeout configuration
                    )
                )
                self.query_history[name].append(query)

                # Handle empty results
                if first_chunk.empty:
                    empty_response = {"data": []}
                    if query_analysis:
                        empty_response["analysis"] = {
                            "estimated_rows": query_analysis.estimated_rows,
                            "actual_rows": 0,
                            "analysis_accuracy": "N/A (empty result)",
                            "analysis_time": f"{query_analysis.analysis_time_seconds:.3f}s",
                        }
                    return json.dumps(empty_response)

                # Detect BLOB columns from query result dtypes
                blob_columns = []
                blob_warnings = []
                try:
                    engine_obj = self._get_connection(name)
                    insp = inspect(engine_obj)
                    from .blob_handler import is_blob_type, process_blob_columns

                    # Extract table names from query for column type lookup
                    for tbl in insp.get_table_names():
                        for col_info in insp.get_columns(tbl):
                            if col_info["name"] in first_chunk.columns and is_blob_type(
                                col_info["type"]
                            ):
                                blob_columns.append(col_info["name"])
                except Exception:
                    pass  # BLOB detection is best-effort

                # Generate enhanced response metadata
                metadata_generator = get_metadata_generator()
                enhanced_metadata = metadata_generator.generate_metadata(
                    query_id=query_id,
                    df=first_chunk,
                    query=validated_query,
                    query_analysis=query_analysis,
                    db_name=name,
                )

                # Check if we should use streaming approach based on data size
                total_rows_processed = streaming_metadata.get(
                    "total_rows_processed", len(first_chunk)
                )
                threshold = initial_chunk_size

                if total_rows_processed > threshold or streaming_metadata.get(
                    "streaming", False
                ):
                    # Large result set - use streaming approach with buffering
                    chunk_limit = len(first_chunk)
                    estimated_total = (
                        streaming_metadata.get("estimated_total_rows")
                        or total_rows_processed
                    )

                    # Create LLM communication protocol
                    llm_protocol = LLMCommunicationProtocol(enhanced_metadata)

                    # Store enhanced QueryBuffer with metadata
                    enhanced_query_buffer = QueryBuffer(
                        query_id=query_id,
                        db_name=name,
                        query=validated_query,
                        results=first_chunk,
                        timestamp=time.time(),
                        response_metadata=enhanced_metadata,
                        llm_protocol=llm_protocol,
                    )

                    with self.query_buffer_lock:
                        self.query_buffers[query_id] = enhanced_query_buffer

                    response = {
                        "metadata": {
                            "total_rows": estimated_total,
                            "showing_rows": f"1-{chunk_limit}",
                            "query_id": query_id,
                            "memory_info": memory_info,
                            "chunked": True,
                            "chunk_size": chunk_limit,
                            "streaming": True,
                            "buffer_complete": streaming_metadata.get(
                                "buffer_complete", False
                            ),
                        },
                        "data": self._process_blob_data(
                            json.loads(first_chunk.to_json(orient="records")),
                            blob_columns,
                            include_blobs,
                            blob_warnings,
                        ),
                        "pagination": {
                            "use_next_chunk": f"next_chunk(query_id='{query_id}', start_row={chunk_limit + 1}, chunk_size=100)",
                            "get_all_remaining": f"next_chunk(query_id='{query_id}', start_row={chunk_limit + 1}, chunk_size='all')",
                        },
                        "streaming_metadata": streaming_metadata,
                        "enhanced_metadata": {
                            "llm_summary": llm_protocol.get_summary(),
                            "complexity": {
                                "level": enhanced_metadata.query_complexity_level.value,
                                "score": enhanced_metadata.query_complexity_score,
                                "processing_time_estimate": enhanced_metadata.estimated_processing_time,
                            },
                            "data_quality": {
                                "overall": enhanced_metadata.data_quality_metrics.overall_quality.value,
                                "score": enhanced_metadata.data_quality_metrics.quality_score,
                                "completeness": enhanced_metadata.data_quality_metrics.completeness,
                            },
                            "recommended_action": enhanced_metadata.recommended_action,
                            "action_rationale": enhanced_metadata.action_rationale,
                        },
                    }

                    # Add analysis results to metadata
                    if query_analysis:
                        actual_rows = streaming_metadata.get(
                            "total_rows_processed", len(first_chunk)
                        )
                        response["analysis"] = {
                            "estimated_rows": query_analysis.estimated_rows,
                            "actual_rows": actual_rows,
                            "row_estimate_accuracy": f"{(1 - abs(query_analysis.estimated_rows - actual_rows) / max(actual_rows, 1)) * 100:.1f}%",
                            "estimated_memory_mb": query_analysis.estimated_total_memory_mb,
                            "estimated_tokens": query_analysis.estimated_total_tokens,
                            "complexity_score": query_analysis.complexity_score,
                            "risk_levels": {
                                "memory": query_analysis.memory_risk_level,
                                "tokens": query_analysis.token_risk_level,
                                "timeout": query_analysis.timeout_risk_level,
                            },
                            "recommendations": query_analysis.recommendations,
                            "analysis_time": f"{query_analysis.analysis_time_seconds:.3f}s",
                        }

                    if blob_warnings:
                        response["blob_warnings"] = blob_warnings

                    self._record_audit(
                        name,
                        query,
                        "success",
                        _query_start_time,
                        rows_returned=estimated_total,
                    )
                    return json.dumps(response, indent=2)
                else:
                    # Small result set - return all results
                    # Create LLM communication protocol for small results too
                    llm_protocol = LLMCommunicationProtocol(enhanced_metadata)

                    # Store enhanced QueryBuffer with metadata
                    enhanced_query_buffer = QueryBuffer(
                        query_id=query_id,
                        db_name=name,
                        query=validated_query,
                        results=first_chunk,
                        timestamp=time.time(),
                        response_metadata=enhanced_metadata,
                        llm_protocol=llm_protocol,
                    )

                    with self.query_buffer_lock:
                        self.query_buffers[query_id] = enhanced_query_buffer

                    response = {
                        "metadata": {
                            "total_rows": len(first_chunk),
                            "showing_rows": f"1-{len(first_chunk)}",
                            "memory_info": memory_info,
                            "chunked": False,
                            "streaming": True,
                        },
                        "data": self._process_blob_data(
                            json.loads(first_chunk.to_json(orient="records")),
                            blob_columns,
                            include_blobs,
                            blob_warnings,
                        ),
                        "streaming_metadata": streaming_metadata,
                        "enhanced_metadata": {
                            "llm_summary": llm_protocol.get_summary(),
                            "complexity": {
                                "level": enhanced_metadata.query_complexity_level.value,
                                "score": enhanced_metadata.query_complexity_score,
                                "processing_time_estimate": enhanced_metadata.estimated_processing_time,
                            },
                            "data_quality": {
                                "overall": enhanced_metadata.data_quality_metrics.overall_quality.value,
                                "score": enhanced_metadata.data_quality_metrics.quality_score,
                                "completeness": enhanced_metadata.data_quality_metrics.completeness,
                            },
                            "recommended_action": enhanced_metadata.recommended_action,
                            "action_rationale": enhanced_metadata.action_rationale,
                        },
                    }

                    # Add analysis results to metadata for small results too
                    if query_analysis:
                        response["analysis"] = {
                            "estimated_rows": query_analysis.estimated_rows,
                            "actual_rows": len(first_chunk),
                            "row_estimate_accuracy": f"{(1 - abs(query_analysis.estimated_rows - len(first_chunk)) / max(len(first_chunk), 1)) * 100:.1f}%",
                            "estimated_memory_mb": query_analysis.estimated_total_memory_mb,
                            "estimated_tokens": query_analysis.estimated_total_tokens,
                            "complexity_score": query_analysis.complexity_score,
                            "risk_levels": {
                                "memory": query_analysis.memory_risk_level,
                                "tokens": query_analysis.token_risk_level,
                                "timeout": query_analysis.timeout_risk_level,
                            },
                            "recommendations": query_analysis.recommendations,
                            "analysis_time": f"{query_analysis.analysis_time_seconds:.3f}s",
                        }

                    if blob_warnings:
                        response["blob_warnings"] = blob_warnings

                    self._record_audit(
                        name,
                        query,
                        "success",
                        _query_start_time,
                        rows_returned=len(first_chunk),
                    )
                    return json.dumps(response, indent=2)

            except QueryTimeoutError as timeout_error:
                logger.error(f"Query timed out for database '{name}': {timeout_error}")
                self._record_audit(
                    name,
                    query,
                    "timeout",
                    _query_start_time,
                    error_type="QueryTimeoutError",
                    error_message=str(timeout_error),
                )
                return f"Query Timeout Error: {timeout_error.message} (execution time: {timeout_error.execution_time:.1f}s, reason: {timeout_error.timeout_reason.value})"
            except Exception as streaming_error:
                logger.error(
                    f"Streaming execution failed for database '{name}': {streaming_error}"
                )
                self._record_audit(
                    name,
                    query,
                    "error",
                    _query_start_time,
                    error_type=type(streaming_error).__name__,
                    error_message=str(streaming_error),
                )
                db_type = self.db_types.get(name, "generic")
                structured = classify_error(streaming_error, db_type)
                return json.dumps(structured.to_dict())

        except Exception as e:
            db_type = self.db_types.get(name, "generic")
            structured = classify_error(e, db_type)
            return json.dumps(structured.to_dict())

    def _execute_preflight(self, name: str, query: str) -> str:
        """Run EXPLAIN without executing, return estimates."""
        from .explain_parser import PreflightResult, generate_suggestion, run_explain
        from .size_estimator import get_size_estimator

        engine = self._get_connection(name)

        try:
            explain = run_explain(engine, query)
            estimator = get_size_estimator(engine)

            estimated_rows = explain.estimated_rows if explain else None
            size_est = estimator.estimate_result_size(
                query, estimated_rows=estimated_rows
            )

            size_mb = round(size_est.estimated_total_bytes / (1024 * 1024), 2)
            suggestion = generate_suggestion(estimated_rows, size_mb)

            result = PreflightResult(
                estimated_rows=estimated_rows,
                estimated_size_bytes=size_est.estimated_total_bytes,
                estimated_size_mb=size_mb,
                scan_type=explain.scan_type if explain else None,
                confidence=explain.confidence if explain else 0.0,
                suggestion=suggestion,
            )
            return json.dumps(result.to_dict(), indent=2)
        except Exception as e:
            result = PreflightResult(error=str(e))
            return json.dumps(result.to_dict(), indent=2)

    def analyze_query_preview(self, name: str, query: str) -> str:
        """
        Analyze a SQL query without executing it to preview resource requirements.

        This tool performs the same pre-query analysis as execute_query but without
        actually running the main query. Useful for understanding query complexity,
        estimated resource usage, and getting recommendations before execution.

        Args:
            name: The name of the database connection.
            query: The SQL query to analyze.
        """
        try:
            # Security validation: Only allow SELECT queries
            try:
                validated_query = parse_and_validate_sql(query)
                logger.info(
                    f"SQL query validation passed for preview analysis on database '{name}'"
                )
            except SQLSecurityError as e:
                logger.warning(
                    f"SQL query blocked for preview analysis on database '{name}': {e}"
                )
                return f"Security Error: {e}"
            except Exception as e:
                logger.error(
                    f"Query validation error for preview analysis on database '{name}': {e}"
                )
                return f"Query validation failed: {e}"

            engine = self._get_connection(name)

            # Perform query analysis
            try:
                logger.info(f"Performing query preview analysis for database '{name}'")
                query_analysis = analyze_query(validated_query, engine, name)

                # Build comprehensive analysis response
                response = {
                    "query_info": {
                        "query_hash": query_analysis.query_hash,
                        "complexity_score": query_analysis.complexity_score,
                        "analysis_time": f"{query_analysis.analysis_time_seconds:.3f}s",
                    },
                    "estimates": {
                        "rows": query_analysis.estimated_rows,
                        "memory_mb": query_analysis.estimated_total_memory_mb,
                        "tokens": query_analysis.estimated_total_tokens,
                        "execution_time_seconds": query_analysis.estimated_execution_time_seconds,
                        "row_size_bytes": query_analysis.estimated_row_size_bytes,
                    },
                    "query_features": {
                        "has_joins": query_analysis.has_joins,
                        "has_aggregations": query_analysis.has_aggregations,
                        "has_subqueries": query_analysis.has_subqueries,
                        "has_window_functions": query_analysis.has_window_functions,
                        "column_count": query_analysis.column_count,
                        "column_types": query_analysis.column_types,
                    },
                    "risk_assessment": {
                        "memory": query_analysis.memory_risk_level,
                        "tokens": query_analysis.token_risk_level,
                        "timeout": query_analysis.timeout_risk_level,
                        "overall_risk": max(
                            [
                                ["low", "medium", "high", "critical"].index(
                                    query_analysis.memory_risk_level
                                ),
                                ["low", "medium", "high", "critical"].index(
                                    query_analysis.token_risk_level
                                ),
                                ["low", "medium", "high", "critical"].index(
                                    query_analysis.timeout_risk_level
                                ),
                            ]
                        ),
                    },
                    "recommendations": {
                        "messages": query_analysis.recommendations,
                        "should_chunk": query_analysis.should_chunk,
                        "recommended_chunk_size": query_analysis.recommended_chunk_size,
                    },
                    "sampling_info": {
                        "count_query_time": f"{query_analysis.count_query_time:.3f}s",
                        "sample_query_time": f"{query_analysis.sample_query_time:.3f}s",
                        "has_sample_data": query_analysis.sample_row is not None,
                    },
                }

                # Convert overall risk index back to string
                risk_levels = ["low", "medium", "high", "critical"]
                response["risk_assessment"]["overall_risk"] = risk_levels[
                    response["risk_assessment"]["overall_risk"]
                ]

                logger.info(
                    f"Query preview analysis completed for database '{name}': "
                    f"{query_analysis.estimated_rows} rows, {query_analysis.estimated_total_memory_mb:.1f}MB, "
                    f"overall risk: {response['risk_assessment']['overall_risk']}"
                )

                return json.dumps(response, indent=2)

            except Exception as e:
                logger.error(
                    f"Query preview analysis failed for database '{name}': {e}"
                )
                return f"Analysis failed: {e}"

        except ValueError as e:
            logger.error(f"Database '{name}' not found for preview analysis: {e}")
            return str(e)
        except Exception as e:
            logger.error(f"Unexpected error during query preview analysis: {e}")
            return f"An unexpected error occurred: {e}"

    def next_chunk(self, query_id: str, start_row: int, chunk_size: str) -> str:
        """
        Retrieve the next chunk of rows from a buffered query result.

        Args:
            query_id: The ID of the buffered query result.
            start_row: The starting row number (1-based indexing).
            chunk_size: Number of rows to retrieve, or 'all' for all remaining rows.
        """
        try:
            # Clean up expired buffers in streaming executor
            self.streaming_executor.cleanup_expired_buffers()

            # Get buffer info from streaming executor
            buffer_info = self.streaming_executor.get_buffer_info(query_id)
            if buffer_info is None:
                return f"Error: Query buffer '{query_id}' not found. It may have expired or been cleared."

            # Handle chunk_size parameter
            if chunk_size == "all":
                requested_chunk_size = None  # Get all remaining
            else:
                try:
                    requested_chunk_size = int(chunk_size)
                    if requested_chunk_size <= 0:
                        return "Error: chunk_size must be a positive integer or 'all'."
                except ValueError:
                    return "Error: chunk_size must be a positive integer or 'all'."

            # Convert to 0-based indexing for streaming executor
            start_idx = start_row - 1

            # Get chunk using streaming executor's chunk iterator
            chunk_iterator = self.streaming_executor.get_chunk_iterator(
                query_id,
                start_idx,
                requested_chunk_size or 1000,  # Default large chunk if 'all'
            )

            try:
                chunk_df = next(chunk_iterator)
                if chunk_df.empty:
                    return json.dumps(
                        {"metadata": {"message": "No more rows available"}, "data": []}
                    )
            except StopIteration:
                return json.dumps(
                    {"metadata": {"message": "No more rows available"}, "data": []}
                )

            if chunk_df.empty:
                return json.dumps(
                    {"metadata": {"message": "No more rows available"}, "data": []}
                )

            # Build response
            showing_end = start_row + len(chunk_df) - 1  # Adjust for 1-based indexing
            total_rows = buffer_info.get("total_rows", "unknown")

            response = {
                "metadata": {
                    "query_id": query_id,
                    "total_rows": total_rows,
                    "showing_rows": f"{start_row}-{showing_end}",
                    "chunk_size": len(chunk_df),
                    "buffer_timestamp": buffer_info.get("timestamp"),
                    "buffer_memory_usage_mb": buffer_info.get("memory_usage_mb"),
                    "buffer_complete": buffer_info.get("is_complete", False),
                    "streaming": True,
                },
                "data": json.loads(chunk_df.to_json(orient="records")),
            }

            # Add next pagination options if more rows might be available
            # For streaming, we don't always know the total, so we provide next options
            if len(chunk_df) > 0:  # If we got data, there might be more
                next_start = showing_end + 1
                response["pagination"] = {
                    "next_100": f"next_chunk(query_id='{query_id}', start_row={next_start}, chunk_size=100)",
                    "get_all_remaining": f"next_chunk(query_id='{query_id}', start_row={next_start}, chunk_size='all')",
                }

            return json.dumps(response, indent=2)

        except Exception as e:
            return f"An error occurred while retrieving query chunk: {e}"

    def list_databases(self, include_staging: bool = False) -> str:
        """
        List all available database connections with their SQL flavor information.

        Args:
            include_staging: When True, append active staging databases to the list.
        """
        if not self.connections and not include_staging:
            return json.dumps(
                {"message": "No databases are currently connected.", "databases": []}
            )

        databases = []
        for name in self.connections.keys():
            db_type = self.db_types.get(name, "unknown")
            sql_flavor = self._get_sql_flavor(db_type, self.connections[name])
            entry = {"name": name, "db_type": db_type, "sql_flavor": sql_flavor}
            if name in self._tree_managers:
                entry["storage"] = "tree"
            elif name in self._graph_managers:
                entry["storage"] = "graph"
            elif name in self._rdf_managers:
                entry["storage"] = "rdf"
            elif name in self._sparql_connections:
                entry["storage"] = "sparql_endpoint"
            databases.append(entry)

        response = {"total_connections": len(databases), "databases": databases}

        if include_staging:
            staging_entries = get_staging_manager().list_staging()
            response["staging_databases"] = staging_entries

        return json.dumps(response, indent=2)

    def describe_database(self, name: str) -> str:
        """
        Get detailed information about a database, including its schema in JSON format.

        Args:
            name: The name of the database connection.
        """
        # Graph connections
        if name in self._graph_managers:
            mgr = self._graph_managers[name]
            stats = mgr.get_graph_stats()
            first_nodes = mgr.list_nodes(offset=0, limit=20)
            info = {
                "name": name,
                "storage": "graph",
                "node_count": stats["node_count"],
                "edge_count": stats["edge_count"],
                "density": stats["density"],
                "is_directed": stats["is_directed"],
                "first_node_ids": [n.node_id for n in first_nodes],
            }
            return json.dumps(info, indent=2)

        # RDF connections
        if name in self._rdf_managers:
            mgr = self._rdf_managers[name]
            stats = mgr.get_stats()
            info = {
                "name": name,
                "storage": "rdf",
                "triple_count": stats["triple_count"],
                "namespaces": stats["namespaces"],
                "subject_count": stats["subject_count"],
                "predicate_count": stats["predicate_count"],
                "object_count": stats["object_count"],
            }
            return json.dumps(info, indent=2)

        # SPARQL endpoint connections
        if name in self._sparql_connections:
            conn = self._sparql_connections[name]
            info = {
                "name": name,
                "storage": "sparql_endpoint",
                "endpoint_url": conn.endpoint_url,
            }
            return json.dumps(info, indent=2)

        try:
            engine = self._get_connection(name)
            inspector = inspect(engine)

            db_info = {
                "name": name,
                "dialect": engine.dialect.name,
                "version": inspector.get_server_version_info(),
                "default_schema_name": inspector.default_schema_name,
                "schemas": inspector.get_schema_names(),
                "tables": [],
            }

            for table_name in inspector.get_table_names():
                table_info = self._get_table_metadata(inspector, table_name)
                with engine.connect() as conn:
                    safe_table_name = self._safe_table_identifier(table_name)
                    result = conn.execute(
                        text(f"SELECT COUNT(*) FROM {safe_table_name}")  # nosec B608
                    )
                    row_count = result.scalar()
                table_info["size"] = row_count
                db_info["tables"].append(table_info)

            return json.dumps(db_info, indent=2)
        except Exception as e:
            return f"An error occurred: {e}"

    def find_table(self, table_name: str) -> str:
        """
        Find which database contains a specific table.

        Args:
            table_name: The name of the table to find.
        """
        found_dbs = []
        for name, engine in self.connections.items():
            inspector = inspect(engine)
            if table_name in inspector.get_table_names():
                found_dbs.append(name)

        if not found_dbs:
            return f"Table '{table_name}' was not found in any connected databases."
        return json.dumps(found_dbs)

    def describe_table(self, name: str, table_name: str) -> str:
        """
        Get a detailed description of a table including its schema in JSON.

        Args:
            name: The name of the database connection.
            table_name: The name of the table.
        """
        try:
            engine = self._get_connection(name)
            inspector = inspect(engine)
            if table_name not in inspector.get_table_names():
                return (
                    f"Error: Table '{table_name}' does not exist in database '{name}'."
                )

            table_info = self._get_table_metadata(inspector, table_name)
            with engine.connect() as conn:
                safe_table_name = self._safe_table_identifier(table_name)
                result = conn.execute(
                    text(f"SELECT COUNT(*) FROM {safe_table_name}")  # nosec B608
                )
                row_count = result.scalar()
            table_info["size"] = row_count

            return json.dumps(table_info, indent=2)
        except Exception as e:
            return f"An error occurred: {e}"

    def _check_file_modified(self, buffer: QueryBuffer) -> bool:
        """Check if the source file has been modified since buffer creation."""
        if not buffer.source_file_path or not buffer.source_file_mtime:
            return False

        try:
            current_mtime = os.path.getmtime(buffer.source_file_path)
            return current_mtime > buffer.source_file_mtime
        except OSError:
            # File might not exist anymore
            return True

    def _process_blob_data(
        self,
        data: List[Dict[str, Any]],
        blob_columns: List[str],
        include_blobs: bool,
        blob_warnings: List[str],
    ) -> List[Dict[str, Any]]:
        """Process BLOB columns in result data, returning modified rows."""
        if not blob_columns or not data:
            return data
        from .blob_handler import process_blob_columns

        processed, warnings = process_blob_columns(data, blob_columns, include_blobs)
        blob_warnings.extend(warnings)
        return processed

    def _check_memory_usage(self) -> Dict[str, Any]:
        """Check current memory usage and available memory."""
        try:
            memory = psutil.virtual_memory()
            return {
                "total_gb": round(memory.total / (1024**3), 2),
                "available_gb": round(memory.available / (1024**3), 2),
                "used_percent": memory.percent,
                "low_memory": memory.percent
                > 85,  # Consider 85% as low memory threshold
            }
        except Exception as e:
            logger.warning(f"Could not check memory usage: {e}")
            return {"error": str(e), "low_memory": False}

    def _auto_clear_buffers_if_needed(self, db_name: str) -> bool:
        """Auto-clear buffers from the same database if memory is high."""
        memory_info = self._check_memory_usage()

        if memory_info.get("low_memory", False):
            with self.query_buffer_lock:
                # Clear buffers from the same database
                buffers_to_clear = [
                    query_id
                    for query_id, buffer in self.query_buffers.items()
                    if buffer.db_name == db_name
                ]
                for query_id in buffers_to_clear:
                    del self.query_buffers[query_id]

                if buffers_to_clear:
                    logger.info(
                        f"Auto-cleared {len(buffers_to_clear)} buffers from '{db_name}' due to low memory"
                    )
                    return True

        return False

    def _get_sql_flavor(self, db_type: str, engine=None) -> str:
        """Determine the SQL flavor/dialect for the database type."""
        if db_type == "sqlite":
            return "SQLite"
        elif db_type == "postgresql":
            return "PostgreSQL"
        elif db_type == "mysql":
            return "MySQL"
        elif db_type == "duckdb":
            return "Duckdb"
        elif db_type == "redis":
            return "Redis"
        elif db_type == "elasticsearch":
            return "Elasticsearch"
        elif db_type == "mongodb":
            return "MongoDB"
        elif db_type == "influxdb":
            return "InfluxDB"
        elif db_type == "neo4j":
            return "Neo4j"
        elif db_type == "couchdb":
            return "CouchDB"
        elif db_type in ["dot", "gml", "graphml", "mermaid"]:
            return "Graph (SQLite)"
        elif db_type in ["turtle", "ntriples"]:
            return "RDF (SPARQL)"
        elif db_type == "sparql":
            return "SPARQL Endpoint"
        elif db_type in [
            "csv",
            "json",
            "yaml",
            "toml",
            "excel",
            "ods",
            "xml",
            "ini",
            "tsv",
            "parquet",
            "feather",
            "arrow",
            "hdf5",
        ]:
            # File formats use SQLite dialect internally
            return "SQLite"
        else:
            # Try to get from engine if available
            if engine and hasattr(engine, "dialect"):
                return engine.dialect.name.title()
            return "Unknown"

    def _safe_table_identifier(self, table_name: str) -> str:
        """Create a safe SQL identifier for table names to prevent injection."""
        # Validate table name contains only safe characters
        import re

        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", table_name):
            raise ValueError(
                f"Invalid table name '{table_name}'. Table names must start with a letter or underscore and contain only alphanumeric characters and underscores."
            )

        # Use SQLAlchemy's quoted_name for safe identifier quoting
        return str(quoted_name(table_name, quote=True))

    # Modern Database Connection Methods

    def _create_redis_connection(self, conn_string: str):
        """Create Redis connection from connection string."""
        import redis

        # Parse connection string (redis://localhost:6379/0)
        if conn_string.startswith("redis://"):
            # Parse URL format
            parts = conn_string.replace("redis://", "").split("/")
            host_port = parts[0].split(":")
            host = host_port[0] or "localhost"
            port = int(host_port[1]) if len(host_port) > 1 else 6379
            db = int(parts[1]) if len(parts) > 1 else 0
        else:
            # Default localhost
            host, port, db = "localhost", 6379, 0

        return redis.Redis(host=host, port=port, db=db, decode_responses=True)

    def _create_elasticsearch_connection(self, conn_string: str):
        """Create Elasticsearch connection from connection string."""
        from elasticsearch import Elasticsearch

        # Parse connection string (http://localhost:9200)
        if not conn_string.startswith("http"):
            conn_string = f"http://{conn_string}"

        return Elasticsearch([conn_string])

    def _create_mongodb_connection(self, conn_string: str):
        """Create MongoDB connection from connection string."""
        import pymongo

        # Parse connection string (mongodb://localhost:27017/database)
        if not conn_string.startswith("mongodb://"):
            conn_string = f"mongodb://{conn_string}"

        return pymongo.MongoClient(conn_string)

    def _create_influxdb_connection(self, conn_string: str):
        """Create InfluxDB connection from connection string."""
        from influxdb_client import InfluxDBClient

        # Parse connection string (http://localhost:8086)
        if not conn_string.startswith("http"):
            conn_string = f"http://{conn_string}"

        # InfluxDB requires token and org - use defaults for local testing
        return InfluxDBClient(url=conn_string, token="", org="")

    def _create_neo4j_connection(self, conn_string: str):
        """Create Neo4j connection from connection string."""
        from neo4j import GraphDatabase

        # Parse connection string (bolt://localhost:7687)
        if not conn_string.startswith("bolt://"):
            conn_string = f"bolt://{conn_string}"

        # Neo4j requires auth - use defaults for local testing
        return GraphDatabase.driver(conn_string, auth=("neo4j", "password"))

    def _create_couchdb_connection(self, conn_string: str):
        """Create CouchDB connection from connection string."""
        import couchdb

        # Parse connection string (http://admin:testpassword@localhost:5984/)
        if not conn_string.startswith("http"):
            conn_string = f"http://admin:testpassword@{conn_string}/"

        return couchdb.Server(conn_string)

    def manage_memory_bounds(self) -> str:
        """
        Monitor and manage memory usage across all streaming operations.

        This tool provides comprehensive memory management including:
        - Current memory status and usage statistics
        - Automatic cleanup of expired buffers
        - Memory optimization recommendations
        - Active buffer information

        Returns JSON with memory management actions taken and current status.
        """
        try:
            # Execute memory management
            management_result = self.streaming_executor.manage_memory_bounds()

            # Add database manager specific memory info
            additional_info = {
                "legacy_query_buffers": len(self.query_buffers),
                "active_connections": len(self.connections),
                "temp_files_count": len(self.temp_files),
            }

            # Estimate memory for graph connections
            graph_memory: Dict[str, Any] = {}
            for gname, gmgr in self._graph_managers.items():
                stats = gmgr.get_graph_stats()
                est_bytes = stats["node_count"] * 200 + stats["edge_count"] * 150
                graph_memory[gname] = {
                    "node_count": stats["node_count"],
                    "edge_count": stats["edge_count"],
                    "estimated_bytes": est_bytes,
                }
            if graph_memory:
                additional_info["graph_connections"] = graph_memory

            # Estimate memory for RDF connections
            rdf_memory: Dict[str, Any] = {}
            for rname, rmgr in self._rdf_managers.items():
                stats = rmgr.get_stats()
                est_bytes = stats["triple_count"] * 300
                rdf_memory[rname] = {
                    "triple_count": stats["triple_count"],
                    "estimated_bytes": est_bytes,
                }
            if rdf_memory:
                additional_info["rdf_connections"] = rdf_memory

            # Clean up legacy query buffers if memory is high
            memory_status = management_result.get("memory_status", {})
            if memory_status.get("is_low_memory", False):
                with self.query_buffer_lock:
                    legacy_buffers_cleared = len(self.query_buffers)
                    self.query_buffers.clear()
                    if legacy_buffers_cleared > 0:
                        management_result["actions_taken"].append(
                            f"Cleared {legacy_buffers_cleared} legacy query buffers"
                        )

            management_result["database_manager_info"] = additional_info

            return json.dumps(management_result, indent=2)

        except Exception as e:
            logger.error(f"Error in memory management: {e}")
            return f"Memory management error: {e}"

    def get_streaming_status(self) -> str:
        """
        Get detailed status of all streaming operations and memory usage.

        Returns comprehensive information about:
        - Active streaming buffers and their memory usage
        - Memory status and recommendations
        - Performance metrics from recent streaming operations
        - Configuration settings for streaming

        Useful for monitoring and debugging streaming performance.
        """
        try:
            # Get memory status
            memory_info = self._check_memory_usage()

            # Get streaming executor status
            streaming_status = {
                "memory_status": memory_info,
                "streaming_buffers": {},
                "performance_config": {
                    "memory_limit_mb": self.streaming_executor.config.memory_limit_mb,
                    "default_chunk_size": self.streaming_executor.config.chunk_size,
                    "memory_warning_threshold": self.streaming_executor.config.memory_warning_threshold,
                    "enable_query_analysis": self.streaming_executor.config.enable_query_analysis,
                    "auto_cleanup_buffers": self.streaming_executor.config.auto_cleanup_buffers,
                },
                "recent_chunk_metrics": self.streaming_executor._chunk_metrics[-10:]
                if hasattr(self.streaming_executor, "_chunk_metrics")
                else [],
            }

            # Get info for each active buffer
            for query_id in self.streaming_executor._result_buffers:
                buffer_info = self.streaming_executor.get_buffer_info(query_id)
                if buffer_info:
                    streaming_status["streaming_buffers"][query_id] = buffer_info

            # Add database manager specific info
            streaming_status["database_manager"] = {
                "total_connections": len(self.connections),
                "connection_types": {
                    name: db_type for name, db_type in self.db_types.items()
                },
                "legacy_buffers": len(self.query_buffers),
                "temp_files": len(self.temp_files),
            }

            return json.dumps(streaming_status, indent=2, default=str)

        except Exception as e:
            logger.error(f"Error getting streaming status: {e}")
            return f"Streaming status error: {e}"

    def clear_streaming_buffer(self, query_id: str) -> str:
        """
        Clear a specific streaming result buffer to free memory.

        Args:
            query_id: The ID of the streaming buffer to clear.

        This is useful when you're done with a large result set and want to
        free up memory immediately instead of waiting for automatic cleanup.
        """
        try:
            success = self.streaming_executor.clear_buffer(query_id)
            if success:
                return f"Successfully cleared streaming buffer: {query_id}"
            else:
                return f"Streaming buffer '{query_id}' not found or already cleared."

        except Exception as e:
            logger.error(f"Error clearing streaming buffer {query_id}: {e}")
            return f"Error clearing buffer: {e}"

    def get_query_metadata(self, query_id: str) -> str:
        """
        Get comprehensive metadata for a query result including LLM-friendly summary,
        data quality metrics, complexity analysis, and processing recommendations.

        Args:
            query_id: The ID of the query to get metadata for.

        Returns:
            Comprehensive metadata in JSON format for LLM decision-making.
        """
        try:
            with self.query_buffer_lock:
                if query_id not in self.query_buffers:
                    return f"Query ID '{query_id}' not found in buffers."

                query_buffer = self.query_buffers[query_id]

                if not query_buffer.llm_protocol:
                    return f"Query ID '{query_id}' does not have enhanced metadata available."

                # Get comprehensive summary
                summary = query_buffer.llm_protocol.get_summary()

                # Add additional metadata
                metadata_response = {
                    "query_info": {
                        "query_id": query_id,
                        "database": query_buffer.db_name,
                        "timestamp": query_buffer.timestamp,
                        "query": query_buffer.query,
                    },
                    "llm_summary": summary,
                    "schema_details": query_buffer.llm_protocol.get_schema_details(),
                    "data_quality_report": query_buffer.llm_protocol.get_data_quality_report(),
                    "enhanced_metadata": {
                        "complexity_score": query_buffer.response_metadata.query_complexity_score,
                        "processing_time_estimate": query_buffer.response_metadata.estimated_processing_time,
                        "memory_footprint_mb": query_buffer.response_metadata.memory_footprint,
                        "token_estimation": {
                            "total_tokens": query_buffer.response_metadata.token_estimation.total_tokens,
                            "tokens_per_row": query_buffer.response_metadata.token_estimation.tokens_per_row,
                            "confidence": query_buffer.response_metadata.token_estimation.confidence,
                        },
                        "llm_friendly_summary": query_buffer.response_metadata.llm_friendly_summary,
                    },
                }

                return json.dumps(metadata_response, indent=2)

        except Exception as e:
            logger.error(f"Error getting query metadata for {query_id}: {e}")
            return f"Error getting metadata: {e}"

    def request_data_chunk(self, query_id: str, chunk_id: int) -> str:
        """
        Request a specific chunk of data using the LLM communication protocol.
        This enables progressive loading of large datasets.

        Args:
            query_id: The ID of the query to get chunk from.
            chunk_id: The ID of the chunk to retrieve (starting from 0).

        Returns:
            Chunk data with metadata in JSON format.
        """
        try:
            with self.query_buffer_lock:
                if query_id not in self.query_buffers:
                    return f"Query ID '{query_id}' not found in buffers."

                query_buffer = self.query_buffers[query_id]

                if not query_buffer.llm_protocol:
                    return f"Query ID '{query_id}' does not support chunk requests."

                # Request the chunk
                chunk_data = query_buffer.llm_protocol.request_chunk(chunk_id)

                if chunk_data is None:
                    return f"Chunk {chunk_id} not available for query {query_id}."

                return json.dumps(chunk_data, indent=2)

        except Exception as e:
            logger.error(f"Error requesting chunk {chunk_id} for query {query_id}: {e}")
            return f"Error requesting chunk: {e}"

    def request_multiple_chunks(self, query_id: str, chunk_ids: str) -> str:
        """
        Request multiple chunks of data efficiently.

        Args:
            query_id: The ID of the query to get chunks from.
            chunk_ids: Comma-separated list of chunk IDs (e.g., "0,1,2").

        Returns:
            Multiple chunks data with metadata in JSON format.
        """
        try:
            # Parse chunk IDs
            try:
                chunk_id_list = [int(cid.strip()) for cid in chunk_ids.split(",")]
            except ValueError:
                return f"Invalid chunk_ids format. Use comma-separated integers like '0,1,2'."

            with self.query_buffer_lock:
                if query_id not in self.query_buffers:
                    return f"Query ID '{query_id}' not found in buffers."

                query_buffer = self.query_buffers[query_id]

                if not query_buffer.llm_protocol:
                    return f"Query ID '{query_id}' does not support chunk requests."

                # Request multiple chunks
                chunks_data = query_buffer.llm_protocol.request_multiple_chunks(
                    chunk_id_list
                )

                return json.dumps(chunks_data, indent=2)

        except Exception as e:
            logger.error(
                f"Error requesting chunks {chunk_ids} for query {query_id}: {e}"
            )
            return f"Error requesting chunks: {e}"

    def cancel_query_operation(
        self, query_id: str, reason: str = "User requested"
    ) -> str:
        """
        Cancel an ongoing query operation and free resources.

        Args:
            query_id: The ID of the query operation to cancel.
            reason: Reason for cancellation (optional).

        Returns:
            Cancellation status message.
        """
        try:
            with self.query_buffer_lock:
                if query_id not in self.query_buffers:
                    return f"Query ID '{query_id}' not found in buffers."

                query_buffer = self.query_buffers[query_id]

                if not query_buffer.llm_protocol:
                    return f"Query ID '{query_id}' does not support cancellation."

                # Cancel the operation
                success = query_buffer.llm_protocol.cancel_operation(reason)

                if success:
                    # Also clear from our buffers
                    del self.query_buffers[query_id]
                    return f"Successfully cancelled operation for query {query_id}. Reason: {reason}"
                else:
                    return f"Failed to cancel operation for query {query_id}. Operation may not support cancellation."

        except Exception as e:
            logger.error(f"Error cancelling operation for query {query_id}: {e}")
            return f"Error cancelling operation: {e}"

    def get_data_quality_report(self, query_id: str) -> str:
        """
        Get a comprehensive data quality assessment for a query result.

        Args:
            query_id: The ID of the query to assess data quality for.

        Returns:
            Detailed data quality report in JSON format.
        """
        try:
            with self.query_buffer_lock:
                if query_id not in self.query_buffers:
                    return f"Query ID '{query_id}' not found in buffers."

                query_buffer = self.query_buffers[query_id]

                if not query_buffer.llm_protocol:
                    return f"Query ID '{query_id}' does not have data quality information available."

                # Get data quality report
                quality_report = query_buffer.llm_protocol.get_data_quality_report()

                return json.dumps(quality_report, indent=2)

        except Exception as e:
            logger.error(f"Error getting data quality report for {query_id}: {e}")
            return f"Error getting quality report: {e}"

    def check_compatibility(self, generate_migration_script: bool = False) -> str:
        """
        Check backward compatibility status and get migration recommendations.

        Args:
            generate_migration_script: Whether to generate a migration script for legacy configuration

        Returns:
            Comprehensive compatibility report and migration guidance
        """
        try:
            # Get compatibility status
            status = self.compatibility_manager.get_compatibility_status()

            # Check optional library availability
            library_checks = {}
            for lib_name in ("networkx", "pydot", "rdflib", "SPARQLWrapper"):
                try:
                    mod = __import__(lib_name)
                    library_checks[lib_name] = {
                        "available": True,
                        "version": getattr(mod, "__version__", "unknown"),
                    }
                except ImportError:
                    library_checks[lib_name] = {"available": False}

            # Built-in parsers (no external dependency)
            library_checks["mermaid"] = {
                "available": True,
                "version": "built-in",
                "note": "Pure Python parser, no external dependency",
            }

            # Create report
            report = {
                "compatibility_status": "OK"
                if not status["legacy_config_detected"]
                else "LEGACY_DETECTED",
                "version": status["version"],
                "compatibility_mode": status["compatibility_mode"],
                "legacy_configuration": status["legacy_config_detected"],
                "recommendations": status["recommendations"],
                "deprecation_warnings": status["deprecation_warnings_shown"],
                "details": status["legacy_patterns"],
                "libraries": library_checks,
            }

            # Generate migration script if requested
            if generate_migration_script and status["legacy_config_detected"]:
                try:
                    migration_script = (
                        self.compatibility_manager.create_migration_script()
                    )
                    report["migration_script"] = migration_script
                    report["migration_script_note"] = (
                        "Save this script and run it to migrate your configuration"
                    )
                except Exception as e:
                    report["migration_script_error"] = (
                        f"Failed to generate migration script: {e}"
                    )

            # Add helpful information
            if status["legacy_config_detected"]:
                report["migration_guidance"] = {
                    "current_status": "Using deprecated configuration patterns",
                    "action_required": "Migration recommended but not required immediately",
                    "timeline": "Legacy patterns will be removed in v1.4.0",
                    "next_steps": [
                        "Review recommendations above",
                        "Create YAML configuration file (localdata.yaml)",
                        "Test new configuration alongside existing setup",
                        "Gradually migrate environment variables to YAML",
                    ],
                }
            else:
                report["migration_guidance"] = {
                    "current_status": "Using modern configuration patterns",
                    "action_required": "None - configuration is up to date",
                    "next_steps": ["Continue using current configuration"],
                }

            return json.dumps(report, indent=2)

        except Exception as e:
            logger.error(f"Error checking compatibility: {e}")
            return f"Error checking compatibility: {e}"


def _get_version() -> str:
    """Return package version from metadata, with fallback."""
    try:
        return importlib.metadata.version("localdata-mcp")
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def _parse_cli_args() -> argparse.Namespace:
    """Parse CLI arguments without consuming stdin (needed for MCP stdio transport)."""
    parser = argparse.ArgumentParser(
        description="LocalData MCP server",
        prog="localdata-mcp",
    )
    parser.add_argument(
        "--config",
        "-c",
        type=str,
        default=None,
        help="Path to YAML configuration file (highest precedence)",
    )
    parser.add_argument(
        "--version",
        "-V",
        action="version",
        version=f"localdata-mcp {_get_version()}",
    )
    parser.add_argument(
        "--migrate-config",
        action="store_true",
        default=False,
        help="Migrate legacy configuration to YAML format",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="Force overwrite during migration",
    )
    parser.add_argument(
        "--validate-config",
        action="store_true",
        default=False,
        help="Validate configuration and exit",
    )
    parser.add_argument(
        "--show-config",
        action="store_true",
        default=False,
        help="Show resolved configuration and exit",
    )
    parser.add_argument(
        "--init-config",
        action="store_true",
        default=False,
        help="Create default config file and exit",
    )
    args, _ = parser.parse_known_args(sys.argv[1:])
    return args


def main():
    """Main entry point with structured logging initialization."""
    args = _parse_cli_args()

    if args.migrate_config:
        from .config_paths import get_recommended_path, migrate_config

        try:
            source = Path("~/.localdata.yaml").expanduser()
            dest = get_recommended_path()
            if args.force and dest.exists():
                dest.unlink()
            print(f"Migrating config from {source} to {dest}...")
            migrate_config(source=source, dest=dest)
            print(f"Config migrated successfully to {dest}")
        except FileNotFoundError:
            print("No legacy config found at ~/.localdata.yaml")
            sys.exit(1)
        except FileExistsError:
            print(f"Config already exists at {dest}. Use --force to overwrite.")
            sys.exit(1)
        except Exception as e:
            print(f"Migration failed: {e}")
            sys.exit(1)
        sys.exit(0)

    if args.init_config:
        from .config_paths import create_default_config

        try:
            path = create_default_config()
            print(f"Default config created at {path}")
        except FileExistsError:
            print(
                f"Config file already exists. Remove it first or use a different path."
            )
            sys.exit(1)
        except Exception as e:
            print(f"Failed to create config: {e}")
            sys.exit(1)
        sys.exit(0)

    if args.validate_config:
        try:
            mgr = get_config_manager()
            mgr._validate_config()
            print("Configuration is valid.")
        except Exception as e:
            print(f"Configuration validation failed: {e}")
            sys.exit(1)
        sys.exit(0)

    if args.show_config:
        import copy
        import re as _re

        mgr = get_config_manager()
        data = copy.deepcopy(mgr._config_data)

        def _redact(obj):
            """Recursively redact sensitive values."""
            if isinstance(obj, dict):
                for key in obj:
                    if any(
                        s in key.lower()
                        for s in (
                            "password",
                            "secret",
                            "token",
                            "connection_string",
                            "key_path",
                            "cert_path",
                            "wallet_path",
                        )
                    ):
                        obj[key] = "***REDACTED***"
                    else:
                        _redact(obj[key])
            elif isinstance(obj, list):
                for item in obj:
                    _redact(item)

        _redact(data)
        print(yaml.dump(data, default_flow_style=False, sort_keys=True))
        sys.exit(0)

    if args.config:
        initialize_config(config_file=args.config)

    try:
        version = _get_version()
        with logging_manager.context(
            operation="system_startup", component="localdata_mcp"
        ):
            logger.info(
                "LocalData MCP starting up",
                version=version,
                structured_logging_enabled=True,
                metrics_enabled=logging_config.enable_metrics,
                security_logging_enabled=logging_config.enable_security_logging,
            )

        manager = DatabaseManager()

        with logging_manager.context(
            operation="system_ready", component="localdata_mcp"
        ):
            logger.info(
                "LocalData MCP ready to accept connections",
                transport="stdio",
                logging_level=logging_config.level.value,
                metrics_endpoint=f"http://localhost:{logging_config.metrics_port}{logging_config.metrics_endpoint}"
                if logging_config.enable_metrics
                else None,
            )

        mcp.run(transport="stdio")

    except Exception as e:
        logging_manager.log_error(e, "localdata_mcp", operation="system_startup")
        raise


if __name__ == "__main__":
    main()
