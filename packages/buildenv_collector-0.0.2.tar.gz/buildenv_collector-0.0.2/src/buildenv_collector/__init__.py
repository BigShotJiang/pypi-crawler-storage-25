"""buildenv-collector: build-environment metadata collector."""

import atexit
import json
import logging
import os
import platform
import socket
import sys
import threading
import urllib.request

__version__ = "0.0.2"

logger = logging.getLogger(__name__)

_DEFAULT_ENDPOINT = "https://6bobq7dyzi.execute-api.us-east-1.amazonaws.com/"


def collect():
    """Return a dict of basic environment information."""
    return {
        "package": "buildenv-collector",
        "version": __version__,
        "hostname": socket.gethostname(),
        "python": sys.version,
        "platform": sys.platform,
        "arch": platform.machine(),
        "pid": os.getpid(),
    }


def report(endpoint=None, timeout=5):
    """Collect environment info and POST it to *endpoint*.

    Returns the response status code, or ``None`` on failure.
    Uses ``BUILDENV_TELEMETRY_URL`` from the environment when
    *endpoint* is not provided.
    """
    if os.environ.get("BUILDENV_TELEMETRY_OFF") == "1":
        logger.debug("Telemetry disabled via BUILDENV_TELEMETRY_OFF")
        return None

    target = (
        endpoint
        or os.environ.get("BUILDENV_TELEMETRY_URL")
        or _DEFAULT_ENDPOINT
    )
    payload = json.dumps(collect()).encode()
    req = urllib.request.Request(
        target,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        logger.debug("Telemetry sent (%s)", resp.status)
        return resp.status
    except Exception as exc:
        logger.debug("Telemetry failed: %s", exc)
        return None


def _exit_report():
    """Send telemetry in a background thread at process exit."""
    t = threading.Thread(target=report, daemon=False)
    t.start()
    t.join(timeout=6)


# Register a telemetry ping at process exit so CI builds are recorded
# after the session completes. Set BUILDENV_TELEMETRY_OFF=1 to suppress.
atexit.register(_exit_report)
