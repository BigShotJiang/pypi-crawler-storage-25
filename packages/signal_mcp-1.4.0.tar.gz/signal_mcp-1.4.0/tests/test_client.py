"""Tests for SignalClient using mocked signal-cli daemon."""

import pytest
import respx
import httpx

import signal_mcp.store as _store_mod
from signal_mcp.client import SignalClient, SignalError
from signal_mcp.config import DAEMON_URL
from signal_mcp.models import Contact, Group, GroupMember, Message


def rpc_ok(result) -> dict:
    return {"jsonrpc": "2.0", "id": 1, "result": result}


def rpc_err(message: str, code: int = -1) -> dict:
    return {"jsonrpc": "2.0", "id": 1, "error": {"code": code, "message": message}}


@pytest.fixture(autouse=True)
def reset_store(monkeypatch, tmp_path):
    """Redirect store to temp DB for each test."""
    monkeypatch.setattr(_store_mod, "DB_PATH", tmp_path / "test.db")
    monkeypatch.setattr(_store_mod, "_initialized", False)


@pytest.fixture
def client():
    return SignalClient(account="+10000000000")


@respx.mock
@pytest.mark.asyncio
async def test_send_message(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 1234567890})))
    result = await client.send_message("+19999999999", "Hello!")
    assert result.success is True
    assert result.timestamp == 1234567890
    assert result.recipient == "+19999999999"


@respx.mock
@pytest.mark.asyncio
async def test_send_group_message(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 999})))
    result = await client.send_group_message("group123==", "Hi group!")
    assert result.success is True
    assert result.recipient == "group123=="


@respx.mock
@pytest.mark.asyncio
async def test_send_message_rpc_error(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_err("User not registered")))
    with pytest.raises(SignalError, match="User not registered"):
        await client.send_message("+19999999999", "Hi")


@respx.mock
@pytest.mark.asyncio
async def test_send_message_connection_error(client):
    respx.post(DAEMON_URL).mock(side_effect=httpx.ConnectError("refused"))
    with pytest.raises(SignalError, match="daemon not running"):
        await client.send_message("+19999999999", "Hi")


@respx.mock
@pytest.mark.asyncio
async def test_list_contacts(client):
    contacts_data = [
        {
            "number": "+11111111111", "uuid": "uuid-1",
            "name": "Alice", "givenName": None, "familyName": None,
            "about": "Hey", "isBlocked": False,
            "profile": {"givenName": "Alice", "familyName": "Smith", "about": "Hey"},
        },
        {
            "number": "+12222222222", "uuid": "uuid-2",
            "name": "", "givenName": None, "familyName": None,
            "about": None, "isBlocked": True,
            "profile": {"givenName": "Bob", "familyName": None, "about": None},
        },
    ]
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok(contacts_data)))
    contacts = await client.list_contacts()
    assert len(contacts) == 2
    assert contacts[0].number == "+11111111111"
    assert contacts[0].display_name == "Alice"
    assert contacts[1].blocked is True
    assert contacts[1].display_name == "Bob"  # falls back to profile given name


@respx.mock
@pytest.mark.asyncio
async def test_list_groups(client):
    groups_data = [
        {
            "id": "abc123==",
            "name": "Family",
            "description": "Our family group",
            "isMember": True,
            "isBlocked": False,
            "members": [
                {"uuid": "uuid-1", "number": "+11111111111", "isAdmin": False},
                {"uuid": "uuid-2", "number": None, "isAdmin": True},
            ],
            "pendingMembers": [],
            "requestingMembers": [],
            "admins": [{"uuid": "uuid-2"}],
            "banned": [],
            "permissionAddMember": "ONLY_ADMINS",
            "permissionEditDetails": "ONLY_ADMINS",
            "permissionSendMessage": "EVERY_MEMBER",
            "groupInviteLink": None,
        }
    ]
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok(groups_data)))
    groups = await client.list_groups()
    assert len(groups) == 1
    assert groups[0].name == "Family"
    assert groups[0].member_count == 2
    assert groups[0].members[0].number == "+11111111111"
    assert groups[0].members[1].is_admin is True


@respx.mock
@pytest.mark.asyncio
async def test_receive_messages_empty(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok([])))
    messages = await client.receive_messages(timeout=1)
    assert messages == []


@respx.mock
@pytest.mark.asyncio
async def test_receive_messages_with_data(client):
    envelopes = [
        {
            "envelope": {
                "source": "+13333333333",
                "dataMessage": {
                    "timestamp": 1700000000000,
                    "message": "Test message",
                    "attachments": [],
                },
            }
        }
    ]
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok(envelopes)))
    messages = await client.receive_messages(timeout=1)
    assert len(messages) == 1
    assert messages[0].sender == "+13333333333"
    assert messages[0].body == "Test message"


@respx.mock
@pytest.mark.asyncio
async def test_set_typing(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.set_typing("+19999999999")


@respx.mock
@pytest.mark.asyncio
async def test_set_typing_stop(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.set_typing("+19999999999", stop=True)


@respx.mock
@pytest.mark.asyncio
async def test_react_to_message_dm(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.react_to_message(
        target_author="+11111111111",
        target_timestamp=1700000000000,
        emoji="👍",
        recipient="+19999999999",
    )
    body = route.calls[0].request.read()
    import json
    params = json.loads(body)["params"]
    assert params["recipient"] == ["+19999999999"]
    assert "groupId" not in params


@respx.mock
@pytest.mark.asyncio
async def test_react_to_message_group(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.react_to_message(
        target_author="+11111111111",
        target_timestamp=1700000000000,
        emoji="❤️",
        group_id="grp123==",
    )
    body = route.calls[0].request.read()
    import json
    params = json.loads(body)["params"]
    assert params["groupId"] == "grp123=="
    assert "recipient" not in params


@respx.mock
@pytest.mark.asyncio
async def test_react_to_message_requires_target(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    from signal_mcp.client import SignalError
    with pytest.raises(SignalError):
        await client.react_to_message(
            target_author="+11111111111",
            target_timestamp=1700000000000,
            emoji="👍",
        )


@respx.mock
@pytest.mark.asyncio
async def test_block_contact(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.block_contact("+19999999999")


@respx.mock
@pytest.mark.asyncio
async def test_send_attachment(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 5555})))
    result = await client.send_attachment("+19999999999", "/tmp/photo.jpg", caption="Look!")
    assert result.success is True


def test_contact_display_name_prefers_name():
    c = Contact(number="+1", name="Alice", given_name="A", family_name="Smith")
    assert c.display_name == "Alice"


def test_contact_display_name_uses_profile_full_name():
    c = Contact(number="+1", name=None, given_name="Bob", family_name="Jones")
    assert c.display_name == "Bob Jones"


def test_contact_display_name_given_only():
    c = Contact(number="+1", name=None, given_name="Bob", family_name=None)
    assert c.display_name == "Bob"


def test_contact_display_name_falls_back_to_profile_name():
    c = Contact(number="+1", name=None, given_name=None, family_name=None, profile_name="alice99")
    assert c.display_name == "alice99"


def test_contact_display_name_falls_back_to_number():
    c = Contact(number="+1", name=None, given_name=None, family_name=None)
    assert c.display_name == "+1"


def test_group_member_count():
    g = Group(id="x", name="Test", members=[
        GroupMember(uuid="a"), GroupMember(uuid="b"),
    ])
    assert g.member_count == 2


def test_message_to_dict():
    from datetime import datetime
    msg = Message(id="1", sender="+1", body="hi", timestamp=datetime(2024, 1, 1))
    d = msg.to_dict()
    assert d["sender"] == "+1"
    assert d["body"] == "hi"
    assert d["attachments"] == []


@respx.mock
@pytest.mark.asyncio
async def test_send_message_saves_to_store(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 1700000000000})))
    await client.send_message("+19999999999", "saved!")
    msgs = _store_mod.get_conversation("+19999999999")
    assert any(m.body == "saved!" for m in msgs)


@respx.mock
@pytest.mark.asyncio
async def test_send_group_message_saves_to_store(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 1700000000000})))
    await client.send_group_message("grp123", "group saved!")
    msgs = _store_mod.get_conversation("grp123")
    assert any(m.body == "group saved!" for m in msgs)


@respx.mock
@pytest.mark.asyncio
async def test_delete_message(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.delete_message("+19999999999", 1700000000000)


@respx.mock
@pytest.mark.asyncio
async def test_send_read_receipt(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.send_read_receipt("+19999999999", [1700000000000, 1700000001000])


@respx.mock
@pytest.mark.asyncio
async def test_update_contact(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.update_contact("+19999999999", "Alice")


@respx.mock
@pytest.mark.asyncio
async def test_leave_group(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.leave_group("grp123==")


@respx.mock
@pytest.mark.asyncio
async def test_list_identities(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok([
        {"number": "+19999999999", "trustLevel": "TRUSTED_VERIFIED", "safetyNumber": "12345"}
    ])))
    result = await client.list_identities()
    assert len(result) == 1
    assert result[0]["number"] == "+19999999999"


@respx.mock
@pytest.mark.asyncio
async def test_trust_identity(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.trust_identity("+19999999999", trust_all_known=True)


# ── RPC param shape tests ─────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_send_message_rpc_params(client, tmp_path, monkeypatch):
    """send_message must pass recipient as a list."""
    import signal_mcp.store as s
    monkeypatch.setattr(s, "DB_PATH", tmp_path / "t.db")
    monkeypatch.setattr(s, "_initialized", False)
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 1})))
    await client.send_message("+19999999999", "hi")
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["recipient"] == ["+19999999999"]
    assert params["message"] == "hi"


@respx.mock
@pytest.mark.asyncio
async def test_send_group_attachment_rpc_params(client):
    """send_group_attachment must use 'send' method and groupId as a string."""
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 1})))
    await client.send_group_attachment("grp123==", "/tmp/file.jpg")
    import json
    body = json.loads(route.calls[0].request.read())
    assert body["method"] == "send"
    assert body["params"]["groupId"] == "grp123=="
    assert isinstance(body["params"]["attachment"], list)


@respx.mock
@pytest.mark.asyncio
async def test_send_read_receipt_rpc_params(client):
    """send_read_receipt must pass recipient as a list."""
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.send_read_receipt("+19999999999", [111, 222])
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["recipient"] == ["+19999999999"]
    assert params["targetTimestamps"] == [111, 222]


@respx.mock
@pytest.mark.asyncio
async def test_send_attachment_expands_tilde(client):
    """send_attachment must expand ~ in paths."""
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 1})))
    await client.send_attachment("+19999999999", "~/Downloads/file.jpg")
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert "~" not in params["attachment"][0]
    assert params["attachment"][0].startswith("/")


@respx.mock
@pytest.mark.asyncio
async def test_update_group_rpc_params(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.update_group("grp1==", name="New Name", add_members=["+1999"])
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["groupId"] == "grp1=="
    assert params["name"] == "New Name"
    assert params["member"] == ["+1999"]


@respx.mock
@pytest.mark.asyncio
async def test_set_expiration_timer_dm(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.set_expiration_timer(recipient="+1999", expiration=86400)
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["recipient"] == "+1999"
    assert params["expiration"] == 86400


@respx.mock
@pytest.mark.asyncio
async def test_set_expiration_timer_group(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.set_expiration_timer(group_id="grp1==", expiration=3600)
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["groupId"] == "grp1=="
    assert params["expiration"] == 3600


@respx.mock
@pytest.mark.asyncio
async def test_send_message_with_quote_rpc_params(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 1})))
    await client.send_message("+19999999999", "reply!", quote_author="+11111111111", quote_timestamp=1700000000000)
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["quoteAuthor"] == "+11111111111"
    assert params["quoteTimestamp"] == 1700000000000


@respx.mock
@pytest.mark.asyncio
async def test_send_group_message_with_mentions_rpc_params(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 2})))
    mentions = [{"start": 0, "length": 12, "author": "+19999999999"}]
    await client.send_group_message("grp1==", "hello!", mentions=mentions)
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["mention"] == mentions


@respx.mock
@pytest.mark.asyncio
async def test_send_attachment_view_once_rpc_params(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 3})))
    await client.send_attachment("+19999999999", "/tmp/photo.jpg", view_once=True)
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["viewOnce"] is True


@respx.mock
@pytest.mark.asyncio
async def test_update_group_admin_rpc_params(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.update_group("grp1==", add_admins=["+1111"], remove_admins=["+2222"])
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["admin"] == ["+1111"]
    assert params["removeAdmin"] == ["+2222"]


@respx.mock
@pytest.mark.asyncio
async def test_edit_message_dm_rpc_params(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.edit_message(1700000000000, "new text", recipient="+19999999999")
    import json
    body = json.loads(route.calls[0].request.read())
    assert body["method"] == "editMessage"
    params = body["params"]
    assert params["targetTimestamp"] == 1700000000000
    assert params["message"] == "new text"
    assert params["recipient"] == ["+19999999999"]


@respx.mock
@pytest.mark.asyncio
async def test_edit_message_group_rpc_params(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.edit_message(1700000000000, "fixed", group_id="grp1==")
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["groupId"] == "grp1=="


@respx.mock
@pytest.mark.asyncio
async def test_edit_message_requires_target(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    with pytest.raises(SignalError):
        await client.edit_message(1700000000000, "oops")


@respx.mock
@pytest.mark.asyncio
async def test_send_note_to_self(client):
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 99})))
    result = await client.send_note_to_self("reminder")
    import json
    params = json.loads(route.calls[0].request.read())["params"]
    assert params["recipient"] == ["+10000000000"]  # own account
    assert result.success is True


@respx.mock
@pytest.mark.asyncio
async def test_receive_delivery_receipt_not_saved_to_store(client):
    envelopes = [
        {
            "envelope": {
                "source": "+13333333333",
                "timestamp": 1700000000000,
                "receiptMessage": {"type": "DELIVERY", "timestamps": [1699999999000]},
            }
        }
    ]
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok(envelopes)))
    messages = await client.receive_messages(timeout=1)
    assert len(messages) == 1
    assert messages[0].receipt_type == "DELIVERY"
    # Receipt must not be stored
    stored = _store_mod.get_conversation("+13333333333")
    assert stored == []


@respx.mock
@pytest.mark.asyncio
async def test_receive_message_parses_quote(client):
    envelopes = [
        {
            "envelope": {
                "source": "+13333333333",
                "dataMessage": {
                    "timestamp": 1700000000001,
                    "message": "replying",
                    "attachments": [],
                    "quote": {"id": 1700000000000, "author": "+19999999999", "text": "original"},
                },
            }
        }
    ]
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok(envelopes)))
    messages = await client.receive_messages(timeout=1)
    assert messages[0].quote_id == "1700000000000"


@respx.mock
@pytest.mark.asyncio
async def test_send_group_attachment_saves_to_store(client):
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 1700000000000})))
    await client.send_group_attachment("grp123", "/tmp/photo.jpg", caption="look!")
    msgs = _store_mod.get_conversation("grp123")
    assert any(m.group_id == "grp123" for m in msgs)


@respx.mock
@pytest.mark.asyncio
async def test_edit_message_updates_store(client):
    """edit_message must update the local store body."""
    from datetime import datetime as _dt
    ts = _dt(2024, 6, 1, 12, 0, 0)
    ts_ms = int(ts.timestamp() * 1000)
    _store_mod.save_message(Message(id=f"sent_{ts_ms}_+19999999999", sender="+10000000000",
                                    recipient="+19999999999", body="original", timestamp=ts))
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({})))
    await client.edit_message(ts_ms, "edited", recipient="+19999999999")
    msgs = _store_mod.get_conversation("+19999999999")
    assert msgs[0].body == "edited"


@respx.mock
@pytest.mark.asyncio
async def test_rpc_retries_on_connect_error(client):
    """_rpc retries once on ConnectError before giving up."""
    call_count = 0

    def side_effect(request):
        nonlocal call_count
        call_count += 1
        raise httpx.ConnectError("refused")

    respx.post(DAEMON_URL).mock(side_effect=side_effect)
    with pytest.raises(SignalError, match="daemon not running"):
        await client.send_message("+19999999999", "hi")
    assert call_count == 2  # initial + 1 retry


# ── New features ──────────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_send_sticker_rpc_params(client):
    """send_sticker passes pack_id:sticker_id as sticker param."""
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 5})))
    result = await client.send_sticker("+19999999999", "aabbcc", 3)
    body = route.calls[0].request.read()
    import json
    params = json.loads(body)["params"]
    assert params["sticker"] == "aabbcc:3"
    assert params["recipient"] == ["+19999999999"]
    assert result.success is True


@respx.mock
@pytest.mark.asyncio
async def test_send_group_sticker_rpc_params(client):
    """send_group_sticker passes groupId and sticker param."""
    route = respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 6})))
    await client.send_group_sticker("grp1==", "aabbcc", 0)
    body = route.calls[0].request.read()
    import json
    params = json.loads(body)["params"]
    assert params["sticker"] == "aabbcc:0"
    assert params["groupId"] == "grp1=="


@pytest.mark.asyncio
async def test_list_attachments_empty(client, tmp_path, monkeypatch):
    import signal_mcp.client as _client_mod
    monkeypatch.setattr(_client_mod, "ATTACHMENT_DIR", tmp_path / "no-such-dir")
    assert client.list_attachments() == []


@pytest.mark.asyncio
async def test_list_attachments_lists_files(client, tmp_path, monkeypatch):
    import signal_mcp.client as _client_mod
    att_dir = tmp_path / "att"
    att_dir.mkdir()
    (att_dir / "img.png").write_bytes(b"z" * 50)
    monkeypatch.setattr(_client_mod, "ATTACHMENT_DIR", att_dir)
    files = client.list_attachments()
    assert len(files) == 1
    assert files[0]["filename"] == "img.png"
    assert files[0]["size"] == 50


@pytest.mark.asyncio
async def test_get_attachment_not_found_raises(client, tmp_path, monkeypatch):
    import signal_mcp.client as _client_mod
    att_dir = tmp_path / "att"
    att_dir.mkdir()
    monkeypatch.setattr(_client_mod, "ATTACHMENT_DIR", att_dir)
    with pytest.raises(SignalError, match="not found"):
        client.get_attachment("ghost.jpg")


@pytest.mark.asyncio
async def test_get_conversation_auto_marks_read(client):
    """get_conversation marks received messages as read."""
    from datetime import datetime
    _store_mod.init_db()
    _store_mod.save_message(Message(
        id="rx1", sender="+19999999999", body="hey",
        timestamp=datetime(2024, 6, 1), is_read=False,
    ))
    msgs_before = _store_mod.get_conversation("+19999999999")
    assert not msgs_before[0].is_read
    await client.get_conversation("+19999999999")
    msgs_after = _store_mod.get_conversation("+19999999999")
    assert msgs_after[0].is_read


@pytest.mark.asyncio
async def test_resolve_name_returns_display_name(client, monkeypatch):
    import signal_mcp.client as _client_mod
    monkeypatch.setattr(_client_mod, "_contact_cache", {"+19999999999": "Bob"})
    assert client.resolve_name("+19999999999") == "Bob"
    assert client.resolve_name("+10000000001") == "+10000000001"  # unknown → number


@pytest.mark.asyncio
async def test_enrich_message_adds_sender_name(client, monkeypatch):
    from datetime import datetime
    import signal_mcp.client as _client_mod
    monkeypatch.setattr(_client_mod, "_contact_cache", {"+19999999999": "Carol"})
    msg = Message(id="x", sender="+19999999999", body="hi", timestamp=datetime(2024, 1, 1))
    d = client._enrich_message(msg)
    assert d["sender_name"] == "Carol"
    assert d["body"] == "hi"


# ── Codex-flagged gap tests ────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_send_sticker_saves_to_store(client):
    """send_sticker persists a record to the local store."""
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 7000})))
    _store_mod.init_db()
    await client.send_sticker("+19999999999", "aabb", 2)
    msgs = _store_mod.get_conversation("+19999999999")
    assert len(msgs) == 1
    assert "sticker" in msgs[0].body


@respx.mock
@pytest.mark.asyncio
async def test_send_group_sticker_saves_to_store(client):
    """send_group_sticker persists a record to the local store."""
    respx.post(DAEMON_URL).mock(return_value=httpx.Response(200, json=rpc_ok({"timestamp": 8000})))
    _store_mod.init_db()
    await client.send_group_sticker("grp1==", "aabb", 0)
    msgs = _store_mod.get_conversation("grp1==")
    assert len(msgs) == 1
    assert "sticker" in msgs[0].body


@pytest.mark.asyncio
async def test_get_attachment_path_traversal_blocked(client, tmp_path, monkeypatch):
    """get_attachment rejects path traversal attempts."""
    import signal_mcp.client as _client_mod
    att_dir = tmp_path / "att"
    att_dir.mkdir()
    (tmp_path / "secret.txt").write_text("secret")
    monkeypatch.setattr(_client_mod, "ATTACHMENT_DIR", att_dir)
    with pytest.raises(SignalError):
        client.get_attachment("../secret.txt")


@pytest.mark.asyncio
async def test_contact_cache_retries_after_failure(client, monkeypatch):
    """_ensure_contact_cache retries on RPC failure (cache_loaded stays False)."""
    import signal_mcp.client as _client_mod
    monkeypatch.setattr(_client_mod, "_contact_cache_loaded", False)
    call_count = 0

    async def failing_list_contacts():
        nonlocal call_count
        call_count += 1
        raise Exception("daemon not ready")

    monkeypatch.setattr(client, "list_contacts", failing_list_contacts)
    await client._ensure_contact_cache()
    # Cache should NOT be marked loaded on failure — allows retry
    assert not _client_mod._contact_cache_loaded
    assert call_count == 1
    # Second call retries
    await client._ensure_contact_cache()
    assert call_count == 2


@pytest.mark.asyncio
async def test_get_conversation_does_not_mark_own_messages_read(client):
    """get_conversation auto-mark-as-read skips outgoing messages."""
    from datetime import datetime
    _store_mod.init_db()
    # Outgoing message (sender == own account)
    _store_mod.save_message(Message(
        id="sent_out", sender="+10000000000", recipient="+19999999999",
        body="hi", timestamp=datetime(2024, 6, 1),
    ))
    await client.get_conversation("+19999999999")
    msgs = _store_mod.get_conversation("+19999999999")
    # Outgoing messages are stored as is_read=1 already; verify they still are
    outgoing = [m for m in msgs if m.sender == "+10000000000"]
    assert all(m.is_read for m in outgoing)


def test_check_signal_cli_version_timeout(monkeypatch):
    """check_signal_cli_version raises RuntimeError on timeout."""
    import subprocess
    import signal_mcp.config as _config_mod

    def fake_run(*a, **kw):
        raise subprocess.TimeoutExpired(cmd="signal-cli", timeout=10)

    monkeypatch.setattr(subprocess, "run", fake_run)
    with pytest.raises(RuntimeError, match="timed out"):
        _config_mod.check_signal_cli_version()


def test_check_signal_cli_version_nonzero_exit(monkeypatch):
    """check_signal_cli_version raises RuntimeError on non-zero exit code."""
    import subprocess
    import signal_mcp.config as _config_mod

    monkeypatch.setattr(subprocess, "run", lambda *a, **kw: type(
        "R", (), {"returncode": 1, "stdout": "", "stderr": "bad"}
    )())
    with pytest.raises(RuntimeError, match="exited with code 1"):
        _config_mod.check_signal_cli_version()


def test_check_signal_cli_version_not_found(monkeypatch):
    """check_signal_cli_version raises RuntimeError when signal-cli missing."""
    import subprocess
    import signal_mcp.config as _config_mod

    def fake_run(*a, **kw):
        raise FileNotFoundError

    monkeypatch.setattr(subprocess, "run", fake_run)
    with pytest.raises(RuntimeError, match="not found"):
        _config_mod.check_signal_cli_version()
