# Flexoki for Zensical

[![Support](https://img.shields.io/pypi/status/flexoki-zensical?label=support&color=f3c539)](https://pypi.org/project/flexoki-zensical/)
[![PyPI](https://img.shields.io/pypi/v/flexoki-zensical?label=pypi&color=107cb8)](https://pypi.org/project/flexoki-zensical/)

Flexoki for Zensical (`flexoki-zensical`) is a packaged
[Flexoki](https://stephango.com/flexoki) theme for use with
[Zensical](https://zensical.org/).

[Read the docs](https://leightonpayne.github.io/flexoki-zensical) for more
information.

## Quick start

Install the package and point your theme config at `flexoki`:

```bash
uv add flexoki-zensical
```

```toml
[project.theme]
name = "flexoki"

[[project.theme.palette]]
media = "(prefers-color-scheme: light)"
scheme = "default"
toggle.icon = "lucide/moon"
toggle.name = "Switch to dark mode"

[[project.theme.palette]]
media = "(prefers-color-scheme: dark)"
scheme = "slate"
toggle.icon = "lucide/sun"
toggle.name = "Switch to light mode"
```

## Attribution

Flexoki was created by [Steph Ango](https://stephango.com/) and is available at
https://stephango.com/flexoki and https://github.com/kepano/flexoki

## License

Flexoki is
[MIT licensed](https://raw.githubusercontent.com/kepano/flexoki/refs/heads/main/LICENSE).
Flexoki for Zensical is
[MIT licensed](https://raw.githubusercontent.com/leightonpayne/flexoki-zensical/refs/heads/main/LICENSE).
