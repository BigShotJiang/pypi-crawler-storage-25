"""Flexoki theme extension for Zensical."""
