"""Core model architecture."""

import torch
import torch.nn as nn
import pytorch_lightning as pl
from conformer import Conformer
from sklearn.preprocessing import StandardScaler
import snntorch as snn
from snntorch import surrogate

from .utils.set_seed import SetSeed


class SA_NET(pl.LightningModule):
    def __init__(
        self,
        input_channels=21,
        output_channels=1,
        middle_channels=11,
        seed=42,
        spike_slope=25,
        lif1_beta=0.9956,
        lif2_beta=0.9821,
        lif3_beta=0.930,
        conformer_dim=512,
        conformer_depth=2,
        conformer_dim_head=64,
        conformer_heads=8,
        conformer_ff_mult=4,
        conformer_conv_expansion_factor=2,
        conformer_conv_kernel_size=24,
        conformer_attn_dropout=0.1,
        conformer_ff_dropout=0.1,
        conformer_conv_dropout=0.1,
        dropout_p1=0.0,
        dropout_p2=0.1,
        dropout_p3=0.1,
        dropout_p4=0.1,
    ):
        super().__init__()
        self.set_seed = SetSeed(seed=seed)
        self.set_seed.set_seed()
        self.input_channels = input_channels
        self.output_channels = output_channels
        self.middle_channels = middle_channels
        self.conformer_dim = conformer_dim
        self.conformer_depth = conformer_depth
        self.conformer_dim_head = conformer_dim_head
        self.conformer_heads = conformer_heads
        self.conformer_ff_mult = conformer_ff_mult
        self.conformer_conv_expansion_factor = conformer_conv_expansion_factor
        self.conformer_conv_kernel_size = conformer_conv_kernel_size
        self.conformer_attn_dropout = conformer_attn_dropout
        self.conformer_ff_dropout = conformer_ff_dropout
        self.conformer_conv_dropout = conformer_conv_dropout

        self.ch_rescaling_1 = nn.Sequential(
            nn.Conv1d(
                self.input_channels,
                64,
                kernel_size=7,
                stride=1,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm1d(64),
        )
        self.resnet1 = ResBlock1D(self.input_channels, 64, self.ch_rescaling_1, 7)

        self.ch_rescaling_2 = nn.Sequential(
            nn.Conv1d(64, 128, kernel_size=5, stride=1, padding=1, bias=False),
            nn.BatchNorm1d(128),
        )
        self.resnet2 = ResBlock1D(64, 128, self.ch_rescaling_2, 5)

        self.ch_rescaling_3 = nn.Sequential(
            nn.Conv1d(128, 256, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm1d(256),
        )
        self.resnet3 = ResBlock1D(128, 256, self.ch_rescaling_3, 3)

        self.ch_rescaling_4 = nn.Sequential(
            nn.Conv1d(256, 512, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm1d(512),
        )
        self.resnet4 = ResBlock1D(256, 512, self.ch_rescaling_4, 3)

        self.max_pooling1 = nn.MaxPool1d(4)
        self.max_pooling2 = nn.MaxPool1d(4)
        self.max_pooling3 = nn.MaxPool1d(4)
        self.max_pooling4 = nn.MaxPool1d(2)

        self.dropout1 = nn.Dropout1d(p=dropout_p1)
        self.dropouts = [
            nn.Dropout1d(p=dropout_p2),
            nn.Dropout1d(p=dropout_p3),
            nn.Dropout1d(p=dropout_p4),
        ]

        self.conformer1 = Conformer(
            dim=self.conformer_dim,
            depth=self.conformer_depth,
            dim_head=self.conformer_dim_head,
            heads=self.conformer_heads,
            ff_mult=self.conformer_ff_mult,
            conv_expansion_factor=self.conformer_conv_expansion_factor,
            conv_kernel_size=self.conformer_conv_kernel_size,
            attn_dropout=self.conformer_attn_dropout,
            ff_dropout=self.conformer_ff_dropout,
            conv_dropout=self.conformer_conv_dropout,
        )

        self.relu = nn.ReLU()
        self.fc_reduced = nn.Linear(512, 1)
        self.fc_singleton = nn.Linear(self.middle_channels, self.output_channels)
        self.spike_grad = surrogate.fast_sigmoid(slope=spike_slope)
        self.lif1 = snn.Leaky(beta=lif1_beta, spike_grad=self.spike_grad)
        self.lif2 = snn.Leaky(beta=lif2_beta, spike_grad=self.spike_grad)
        self.lif3 = snn.Leaky(beta=lif3_beta, spike_grad=self.spike_grad)

    def forward(self, x):
        x_cpu = x.cpu().numpy()
        for ch in range(x_cpu.shape[2]):
            scaler = StandardScaler()
            scaled_x = scaler.fit_transform(x_cpu[:, :, ch].T)
            x_cpu[:, :, ch] = scaled_x.T

        norm_x = torch.tensor(x_cpu, dtype=x.dtype).to(x.device)

        x = norm_x.to(x.device).transpose(1, 2).contiguous()
        mem1 = self.lif1.init_leaky()
        spk_rec = []

        x = self.resnet1(x)
        x = self.max_pooling1(x)
        x = self.dropout1(x)
        x = x.permute(2, 0, 1)
        num_steps = x.size(0)
        for t in range(num_steps):
            spk1, mem1 = self.lif1(x[t], mem1)
            spk_rec.append(spk1)

        x = torch.stack(spk_rec, dim=0)
        x = x.permute(1, 2, 0)
        for i in range(3):
            sed_resnet = getattr(self, f"resnet{i + 2}")
            x = sed_resnet(x)
            max_pooling_method = getattr(self, f"max_pooling{i + 2}")
            x = max_pooling_method(x)
            x = self.dropouts[i](x)

            if i < 2:
                spk_rec_ls = []
                lif = getattr(self, f"lif{i + 2}")
                mem = lif.init_leaky()

                x_t = x.permute(2, 0, 1)
                actual_steps = min(num_steps, x_t.size(0))

                for t in range(actual_steps):
                    spk, mem = lif(x_t[t], mem)
                    spk_rec_ls.append(spk)

                x = torch.stack(spk_rec_ls, dim=0)
                x = x.permute(1, 2, 0)

        x = x.transpose(1, 2).contiguous()
        x = self.conformer1(x)
        x = self.fc_reduced(x)
        x = x.view(x.size(0), -1)
        x = self.fc_singleton(x)
        x = self.relu(x)

        return x


class ResBlock1D(nn.Module):
    def __init__(self, in_channels, out_channels, rescaling=None, kernel_size=3):
        super().__init__()

        self.conv1 = nn.Conv1d(
            in_channels, out_channels, kernel_size=kernel_size, stride=1, padding=1
        )
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.relu = nn.ReLU(inplace=True)

        self.conv2 = nn.Conv1d(
            out_channels,
            out_channels,
            kernel_size=3,
            stride=1,
            padding=1,
        )
        self.bn2 = nn.BatchNorm1d(out_channels)

        self.ch_rescaling = rescaling

    def forward(self, x):
        identity = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.ch_rescaling is not None:
            identity = self.ch_rescaling(identity)

        out += identity
        out = self.relu(out)

        return out
