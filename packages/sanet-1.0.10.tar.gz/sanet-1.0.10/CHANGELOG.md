# CHANGELOG

<!-- version list -->

## v1.0.10 (2026-05-16)

### Bug Fixes

- Rename package
  ([`3d75724`](https://github.com/qtvo93/sanet-pypi-publish/commit/3d75724cc1124417a8371509aafdebb96f0412c0))

### Chores

- Rename package directory to sanet
  ([`e096aa6`](https://github.com/qtvo93/sanet-pypi-publish/commit/e096aa6eb13fe82598007b46023fb3ecc1408895))


## v1.0.9 (2026-05-16)

### Bug Fixes

- Add auto bump to init and pypi publish
  ([`b1fb143`](https://github.com/qtvo93/sanet-pypi-publish/commit/b1fb14313116b49f337cbc31575817a3d6a8c372))


## v1.0.8 (2026-05-16)

### Bug Fixes

- Add lock file
  ([`41d9ec0`](https://github.com/qtvo93/sanet-pypi-publish/commit/41d9ec095ea78d01646d323ead1cc5c3439ab105))


## v1.0.7 (2026-05-16)

### Bug Fixes

- Add default values
  ([`688435f`](https://github.com/qtvo93/sanet-pypi-publish/commit/688435f3f9581d2ed523983682da60bcd301e9bc))


## v1.0.6 (2026-05-16)

### Bug Fixes

- Add multi-line diagram and relax params
  ([`e816df3`](https://github.com/qtvo93/sanet-pypi-publish/commit/e816df338c57d50b5885168e2bcc42024fad0e55))


## v1.0.5 (2026-05-16)

### Bug Fixes

- Add multi-line diagram
  ([`5d212d9`](https://github.com/qtvo93/sanet-pypi-publish/commit/5d212d992fe06e1553373991ba6046037c893fa0))


## v1.0.4 (2026-05-16)

### Bug Fixes

- Add params to docs
  ([`c823673`](https://github.com/qtvo93/sanet-pypi-publish/commit/c8236733123db71e37dc699a34b442cd77670f10))


## v1.0.3 (2026-05-16)

### Bug Fixes

- Add params and bump patch
  ([`2918704`](https://github.com/qtvo93/sanet-pypi-publish/commit/29187045377b8b2ddd850ed9acfcf98d91bbf11b))

- Add params and bump patch
  ([`8a58273`](https://github.com/qtvo93/sanet-pypi-publish/commit/8a58273359d5133c09d82787bd4553dcec57899e))


## v1.0.2 (2026-05-15)

### Bug Fixes

- Add auto bump to release from tag
  ([`05d8da4`](https://github.com/qtvo93/sanet-pypi-publish/commit/05d8da4d71f4a952aab67ca75ab0f8f81577e70c))


## v1.0.1 (2026-05-15)

### Bug Fixes

- Add lint and version bump and release
  ([`f6a0910`](https://github.com/qtvo93/sanet-pypi-publish/commit/f6a0910d29a2c62397a4f8265fa9cbb534fb8802))


## v1.0.0 (2026-05-15)

- Initial Release
