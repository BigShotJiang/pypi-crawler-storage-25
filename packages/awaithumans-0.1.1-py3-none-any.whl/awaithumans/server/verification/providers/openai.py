"""OpenAI verifier.

Uses OpenAI's structured-output (JSON schema response_format) to force
the model to fill VERIFIER_OUTPUT_SCHEMA. Same shape as the Claude
verifier so the runner can swap providers without touching state."""

from __future__ import annotations

import json

from awaithumans.server.core.config import settings
from awaithumans.server.services.exceptions import (
    VerifierAPIKeyMissingError,
    VerifierProviderError,
    VerifierProviderUnavailableError,
)
from awaithumans.server.verification.prompt import (
    VERIFIER_OUTPUT_SCHEMA,
    build_system_prompt,
    build_user_prompt,
    to_openai_strict_schema,
)
from awaithumans.server.verification.providers import sanitize_provider_error_detail
from awaithumans.types import VerificationContext, VerifierConfig, VerifierResult
from awaithumans.utils.constants import (
    VERIFIER_MAX_OUTPUT_TOKENS,
    VERIFIER_OPENAI_DEFAULT_API_KEY_ENV,
    VERIFIER_OPENAI_DEFAULT_MODEL,
    VERIFIER_OUTPUT_SCHEMA_NAME,
)


async def verify(config: VerifierConfig, ctx: VerificationContext) -> VerifierResult:
    try:
        from openai import AsyncOpenAI
    except ImportError as exc:
        raise VerifierProviderUnavailableError("openai", "verifier-openai") from exc

    api_key_env = config.api_key_env or VERIFIER_OPENAI_DEFAULT_API_KEY_ENV
    api_key = settings.get_secret(api_key_env)
    if not api_key:
        raise VerifierAPIKeyMissingError(api_key_env)

    client = AsyncOpenAI(api_key=api_key)
    model = config.model or VERIFIER_OPENAI_DEFAULT_MODEL

    # OpenAI's JSON-schema response_format requires `additionalProperties:
    # false` and every property listed in `required`. The shared
    # VERIFIER_OUTPUT_SCHEMA leaves parsed_response optional (not all
    # tasks need NL parsing); `to_openai_strict_schema()` adapts it.
    strict_schema = to_openai_strict_schema(VERIFIER_OUTPUT_SCHEMA)

    try:
        response = await client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": build_system_prompt(config.instructions)},
                {"role": "user", "content": build_user_prompt(ctx)},
            ],
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": VERIFIER_OUTPUT_SCHEMA_NAME,
                    "schema": strict_schema,
                    "strict": True,
                },
            },
            max_tokens=VERIFIER_MAX_OUTPUT_TOKENS,
        )
    except Exception as exc:  # noqa: BLE001
        raise VerifierProviderError("openai", sanitize_provider_error_detail(str(exc))) from exc

    content = response.choices[0].message.content
    if not content:
        raise VerifierProviderError("openai", "Empty response content.")

    try:
        payload = json.loads(content)
    except json.JSONDecodeError as exc:
        raise VerifierProviderError("openai", f"Response was not valid JSON: {exc.msg}") from exc

    return VerifierResult(
        passed=bool(payload.get("passed", False)),
        reason=str(payload.get("reason", "")),
        parsed_response=payload.get("parsed_response"),
    )
