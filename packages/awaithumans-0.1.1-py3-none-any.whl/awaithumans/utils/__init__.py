"""Shared utilities — constants, helpers."""
