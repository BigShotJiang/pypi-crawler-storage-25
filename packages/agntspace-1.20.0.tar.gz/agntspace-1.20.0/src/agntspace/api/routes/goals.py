"""Goals and coaching API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/goals", tags=["goals"])


class GoalCreateRequest(BaseModel):
    title: str
    description: str
    goal_type: str = "goal"
    target_date: str = ""
    success_metric: str = ""
    budget: float = 0.0
    max_attempts: int = 20


class GoalStatusRequest(BaseModel):
    status: str


class GoalUpdateRequest(BaseModel):
    description: str | None = None
    target_date: str | None = None


class GoalRenameRequest(BaseModel):
    title: str


class GoalPursuitUpdateRequest(BaseModel):
    success_metric: str | None = None
    budget: float | None = None
    max_attempts: int | None = None


@router.get("")
async def list_goals(request: Request, status: str | None = None) -> list[dict]:
    """List all goals."""
    coach = request.app.state.coach
    return coach.list_goals(status_filter=status)


@router.post("")
async def create_goal(request: Request, body: GoalCreateRequest) -> dict:
    """Create a new goal."""
    coach = request.app.state.coach
    path = coach.create_goal(
        title=body.title,
        description=body.description,
        goal_type=body.goal_type,
        target_date=body.target_date,
        success_metric=body.success_metric,
        budget=body.budget,
        max_attempts=body.max_attempts,
    )
    return {"path": path, "status": "active"}


@router.get("/nudges")
async def get_nudges(request: Request) -> list[str]:
    """Get coaching nudges for stalled goals and deadlines."""
    coach = request.app.state.coach
    return coach.generate_nudges()


@router.get("/stalls")
async def get_stalls(request: Request) -> list[dict]:
    """Detect stalled goals."""
    coach = request.app.state.coach
    return coach.detect_stalls()


@router.get("/{slug}")
async def get_goal(request: Request, slug: str) -> dict:
    """Get a single goal."""
    coach = request.app.state.coach
    goal = coach.get_goal(slug)
    if not goal:
        raise HTTPException(status_code=404, detail=f"Goal not found: {slug}")
    return goal


@router.put("/{slug}")
async def update_goal(request: Request, slug: str, body: GoalUpdateRequest) -> dict:
    """Update a goal's description and/or target date."""
    coach = request.app.state.coach
    try:
        coach.update_goal(
            slug=slug,
            description=body.description,
            target_date=body.target_date,
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"slug": slug, "status": "updated"}


@router.post("/{slug}/rename")
async def rename_goal(request: Request, slug: str, body: GoalRenameRequest) -> dict:
    """Rename a goal: rewrite title, move file, update project references."""
    coach = request.app.state.coach
    try:
        result = coach.rename_goal(slug, body.title)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    activity = getattr(request.app.state, "activity_logger", None)
    if activity and result["slug"] != slug:
        activity.log(
            category="user_override",
            action="goal_renamed",
            summary=f"User renamed goal '{slug}' → '{result['slug']}' ('{body.title}')",
            details={"old_slug": slug, "new_slug": result["slug"], "projects_updated": result.get("projects_updated", 0)},
            importance="medium",
        )
    return {"slug": result["slug"], "projects_updated": result.get("projects_updated", 0)}


@router.patch("/{slug}/status")
async def update_goal_status(
    request: Request, slug: str, body: GoalStatusRequest
) -> dict:
    """Update a goal's status."""
    coach = request.app.state.coach
    try:
        coach.update_goal_status(slug, body.status)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"slug": slug, "status": body.status}


@router.get("/{slug}/projects")
async def list_goal_projects(request: Request, slug: str) -> list[dict]:
    """Reverse lookup: list projects whose related_goals contains this goal."""
    project_svc = request.app.state.project_service
    projects = project_svc.list_projects()
    return [p for p in projects if slug in (p.get("related_goals") or [])]


@router.post("/{slug}/projects/{project_slug}")
async def attach_goal_to_project(
    request: Request, slug: str, project_slug: str
) -> dict:
    """Attach this goal to a project (adds to project.related_goals)."""
    coach = request.app.state.coach
    if not coach.get_goal(slug):
        raise HTTPException(status_code=404, detail=f"Goal not found: {slug}")
    project_svc = request.app.state.project_service
    detail = project_svc.get_project_detail(project_slug)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_slug}")

    goals = list(detail.get("related_goals") or [])
    if slug in goals:
        return {"slug": slug, "project": project_slug, "status": "already_linked"}
    goals.append(slug)
    project_svc.update_project(slug=project_slug, related_goals=goals)

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user_override",
            action="goal_attached_to_project",
            summary=f"User linked goal '{slug}' to project '{project_slug}'",
            details={"goal": slug, "project": project_slug},
            importance="medium",
        )
    return {"slug": slug, "project": project_slug, "status": "attached"}


@router.delete("/{slug}/projects/{project_slug}")
async def detach_goal_from_project(
    request: Request, slug: str, project_slug: str
) -> dict:
    """Detach this goal from a project (removes from project.related_goals)."""
    project_svc = request.app.state.project_service
    detail = project_svc.get_project_detail(project_slug)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_slug}")

    goals = list(detail.get("related_goals") or [])
    if slug not in goals:
        return {"slug": slug, "project": project_slug, "status": "not_linked"}
    goals.remove(slug)
    project_svc.update_project(slug=project_slug, related_goals=goals)

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user_override",
            action="goal_detached_from_project",
            summary=f"User unlinked goal '{slug}' from project '{project_slug}'",
            details={"goal": slug, "project": project_slug},
            importance="medium",
        )
    return {"slug": slug, "project": project_slug, "status": "detached"}


@router.get("/{slug}/pursuit")
async def get_pursuit_status(request: Request, slug: str) -> dict:
    """Get pursuit tracking status for a goal."""
    coach = request.app.state.coach
    try:
        return coach.get_pursuit_status(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/{slug}/pursuit/start")
async def start_pursuit(request: Request, slug: str) -> dict:
    """Start autonomous pursuit of a goal."""
    coach = request.app.state.coach
    try:
        coach.set_pursuit_status(slug, "pursuing")
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"slug": slug, "pursuit_status": "pursuing"}


@router.post("/{slug}/pursuit/pause")
async def pause_pursuit(request: Request, slug: str) -> dict:
    """Pause autonomous pursuit of a goal."""
    coach = request.app.state.coach
    try:
        coach.set_pursuit_status(slug, "paused", reason="User paused")
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"slug": slug, "pursuit_status": "paused"}


@router.patch("/{slug}/pursuit")
async def update_pursuit_config(request: Request, slug: str, body: GoalPursuitUpdateRequest) -> dict:
    """Update pursuit configuration (metric, budget, max_attempts)."""
    import re as _re

    coach = request.app.state.coach
    path = f"goals/{slug}.md"
    reader = request.app.state.vault
    if not reader.exists(path):
        raise HTTPException(status_code=404, detail=f"Goal not found: {slug}")

    doc = reader.read(path)
    content = doc.raw
    writer = request.app.state.writer

    if body.success_metric is not None:
        content = _re.sub(
            r'^success_metric:\s*".*"', f'success_metric: "{body.success_metric}"',
            content, count=1, flags=_re.MULTILINE,
        )
    if body.budget is not None:
        content = _re.sub(
            r"^budget:\s*[\d.]+", f"budget: {body.budget}",
            content, count=1, flags=_re.MULTILINE,
        )
    if body.max_attempts is not None:
        content = _re.sub(
            r"^max_attempts:\s*\d+", f"max_attempts: {body.max_attempts}",
            content, count=1, flags=_re.MULTILINE,
        )

    writer.write(path, content, contract_action="create_task")
    return {"slug": slug, "status": "updated"}


@router.delete("/{slug}")
async def delete_goal(request: Request, slug: str) -> dict:
    """Delete a goal and clean up project references."""
    coach = request.app.state.coach
    try:
        result = coach.delete_goal(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user",
            action="goal_deleted",
            summary=f"User deleted goal '{slug}' (cleaned {result['projects_cleaned']} project refs)",
            details=result,
            importance="medium",
        )
    return result
