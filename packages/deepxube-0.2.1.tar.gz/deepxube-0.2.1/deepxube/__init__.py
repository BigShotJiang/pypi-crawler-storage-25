__version__ = "0.2.1"
__author__ = 'Forest Agostinelli'

# run registers
from . import domains  # noqa: F401
from . import heuristics  # noqa: F401
from . import pathfinding  # noqa: F401
from . import updaters  # noqa: F401

from deepxube.factories.nnet_input_factory import register_nnet_input_dynamic
from deepxube.factories.utils.import_modules import import_local_modules
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
import_local_modules("domains/")
import_local_modules("heuristics/")
import_local_modules("pathfinding/")
register_nnet_input_dynamic()
