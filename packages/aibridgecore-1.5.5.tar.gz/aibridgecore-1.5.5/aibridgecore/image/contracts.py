from dataclasses import dataclass, field
from typing import List, Optional, Dict
from enum import Enum
import time
from .artifacts import ImageArtifact


class ImageMode(str, Enum):
    """The type of image generation operation requested."""

    TEXT_TO_IMAGE = "text2img"
    EDIT = "edit"
    IMG_TO_IMG = "img2img"


@dataclass
class ImageGenerationRequest:
    prompts: List[str]
    model: str

    n: int = 1
    size: str = "1024x1024"

    mode: ImageMode = ImageMode.TEXT_TO_IMAGE

    # Optional fields for providers that support aspect ratios instead of pixel sizes
    aspect_ratio: Optional[str] = None
    quality: Optional[str] = None
    style: Optional[str] = None

    # Reference images for edit / img2img modes
    images: Optional[List[str]] = None
    masks: Optional[List[str]] = None

    # Provider-specific config (thoughtSignature, seed, cfg_scale, etc.)
    config: Dict[str, object] = field(default_factory=dict)

    def validate(self):
        if not self.prompts:
            raise ValueError("At least one prompt is required")

        if self.n < 1:
            raise ValueError("n must be >= 1")

        if self.mode in (ImageMode.EDIT, ImageMode.IMG_TO_IMG):
            if not self.images:
                raise ValueError(
                    f"Mode '{self.mode.value}' requires at least one reference image"
                )

        if self.masks and not self.images:
            raise ValueError("Masks require base images")

        if self.images and len(self.images) != len(self.prompts):
            raise ValueError("image count must match prompts count")

        if self.masks and len(self.masks) != len(self.images):
            raise ValueError("masks count must match images count")


@dataclass
class PromptImageResult:
    prompt_index: int
    prompt: str
    images: List[ImageArtifact]


@dataclass
class ImageGenerationResponse:
    provider: str
    model: str
    created_at: int
    results: List[PromptImageResult]

    # Populated when the orchestrator used a fallback provider
    fallback_notice: Optional[str] = None
    context: Optional[Dict] = field(default_factory=dict)  

    @classmethod
    def now(
        cls,
        provider: str,
        model: str,
        results: List[PromptImageResult],
        fallback_notice: Optional[str] = None,
        context: Optional[dict] = None, 
    ):
        return cls(
            provider=provider,
            model=model,
            created_at=int(time.time()),
            results=results,
            fallback_notice=fallback_notice,
            context=context or {},
        )
