from abc import ABC, abstractmethod


class ImageStorage(ABC):
    @abstractmethod
    def save(self, *, content: bytes, content_type: str, metadata: dict) -> str:

        raise NotImplementedError
