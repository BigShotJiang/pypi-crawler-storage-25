from dataclasses import dataclass, field
from typing import Dict


@dataclass
class ImageArtifact:

    content: bytes
    content_type: str

    provider: str
    model: str
    size: str

    metadata: Dict[str, object] = field(default_factory=dict)
