import logging
import requests
from typing import List

from aibridgecore.image.base import BaseImageProvider
from aibridgecore.image.contracts import (
    ImageGenerationRequest,
    ImageGenerationResponse,
    ImageMode,
    PromptImageResult,
)
from aibridgecore.image.artifacts import ImageArtifact
from aibridgecore.image.exceptions import ImageProviderError
from aibridgecore.constant.common import parse_api_key

logger = logging.getLogger(__name__)

STABILITY_ENDPOINT_MAP = {
    "sd3": "/generate/sd3",
    "sd3-turbo": "/generate/sd3",
    "sd3-large": "/generate/sd3",
    "sd3-large-turbo": "/generate/sd3",
    "sd3-medium": "/generate/sd3",
    "stable-image-ultra": "/generate/ultra",
    "stable-image-core": "/generate/core",
}


class StabilityImageProvider(BaseImageProvider):
    provider_name = "stability"
    BASE_URL = "https://api.stability.ai/v2beta/stable-image"

    def generate(
        self,
        request: ImageGenerationRequest,
        storage=None,
    ) -> ImageGenerationResponse:
        request.validate()

        api_key = self.api_key or parse_api_key("stable_diffusion")
        if not api_key:
            raise ValueError("Stable Diffusion API Key not found. Please configure it.")

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Accept": "image/*",
        }

        results: List[PromptImageResult] = []

        for idx, prompt in enumerate(request.prompts):
            has_image = request.images is not None and len(request.images) > idx
            has_mask = request.masks is not None and len(request.masks) > idx

            endpoint = self._resolve_endpoint(
                request.model, request.mode, has_image, has_mask
            )

            images = []
            for _ in range(request.n):
                files = {"none": (None, "")}

                data = {
                    "prompt": prompt,
                    "output_format": request.config.get("output_format", "png"),
                    "model": request.model,
                }

                if negative_prompt := request.config.get("negative_prompt"):
                    data["negative_prompt"] = negative_prompt

                if seed := request.config.get("seed"):
                    data["seed"] = seed

                if cfg_scale := request.config.get("cfg_scale"):
                    data["cfg_scale"] = cfg_scale

                VALID_STYLES = {
                    "3d-model",
                    "analog-film",
                    "anime",
                    "cinematic",
                    "comic-book",
                    "digital-art",
                    "enhance",
                    "fantasy-art",
                    "isometric",
                    "line-art",
                    "low-poly",
                    "modeling-compound",
                    "neon-punk",
                    "origami",
                    "photographic",
                    "pixel-art",
                    "tile-texture",
                }

                style_preset = request.style or request.config.get("style_preset")
                if style_preset and style_preset.lower() in VALID_STYLES:
                    data["style_preset"] = style_preset.lower()

                if has_image:
                    image_bytes = self._load_binary(request.images[idx])
                    files["image"] = ("image.png", image_bytes, "image/png")
                    if "/generate/" in endpoint:
                        data["mode"] = "image-to-image"
                        data["strength"] = request.config.get("strength", 0.5)
                if has_mask:
                    mask_bytes = self._load_binary(request.masks[idx])
                    files["mask"] = ("mask.png", mask_bytes, "image/png")

                try:
                    resp = requests.post(
                        endpoint,
                        headers=headers,
                        files=files,
                        data=data,
                        timeout=120,
                    )
                except requests.RequestException as e:
                    raise ImageProviderError(f"Stability API request failed: {str(e)}")

                if resp.status_code != 200:
                    raise ImageProviderError(
                        f"Stability API error {resp.status_code}: {resp.text[:200]}"
                    )

                images.append(
                    ImageArtifact(
                        content=resp.content,
                        content_type=resp.headers.get("content-type", "image/png"),
                        provider=self.provider_name,
                        model=request.model,
                        size=request.size,
                    )
                )

            results.append(
                PromptImageResult(prompt_index=idx, prompt=prompt, images=images)
            )

        return ImageGenerationResponse.now(
            provider=self.provider_name,
            model=request.model,
            results=results,
        )

    def _resolve_endpoint(
        self, model: str, mode: ImageMode, has_image: bool, has_mask: bool
    ) -> str:
        """Route to the correct Stability endpoint based on model and mode."""
        model_lower = (model or "").lower()

        if has_mask and mode in (ImageMode.EDIT, ImageMode.IMG_TO_IMG):
            return f"{self.BASE_URL}/edit/inpaint"

        if has_image and mode == ImageMode.EDIT:
            return f"{self.BASE_URL}/edit/inpaint"

        for key, path in STABILITY_ENDPOINT_MAP.items():
            if key in model_lower:
                return f"{self.BASE_URL}{path}"
        return f"{self.BASE_URL}/generate/sd3"
