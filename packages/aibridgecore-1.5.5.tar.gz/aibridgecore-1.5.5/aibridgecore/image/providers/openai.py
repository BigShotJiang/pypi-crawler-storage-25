import base64
import logging
import time
import httpx
from typing import List, Optional

from aibridgecore.image.base import BaseImageProvider
from aibridgecore.image.contracts import (
    ImageGenerationRequest,
    ImageGenerationResponse,
    ImageMode,
    PromptImageResult,
)
from aibridgecore.image.artifacts import ImageArtifact
from aibridgecore.image.exceptions import ImageProviderError
from aibridgecore.constant.common import parse_api_key

logger = logging.getLogger(__name__)


class OpenAIImageProvider(BaseImageProvider):
    provider_name = "openai"
    BASE_URL = "https://api.openai.com/v1"

    MAX_RETRIES = 3
    BACKOFF_FACTOR = 1.5

    def generate(
        self, request: ImageGenerationRequest, storage=None
    ) -> ImageGenerationResponse:
        request.validate()

        api_key = self.api_key or parse_api_key("open_ai")
        if not api_key:
            raise ImageProviderError("OpenAI API key required.")

        headers = {"Authorization": f"Bearer {api_key}"}
        results: List[PromptImageResult] = []
        usage_data = {"input_tokens": 0, "output_tokens": 0}

        with httpx.Client(headers=headers, timeout=120.0) as client:
            for idx, prompt in enumerate(request.prompts):
                image_bytes = None
                mask_bytes = None

                if (
                    request.mode in (ImageMode.EDIT, ImageMode.IMG_TO_IMG)
                    and request.images
                ):
                    image_bytes = self._load_binary(
                        request.images[min(idx, len(request.images) - 1)]
                    )
                    if request.masks and len(request.masks) > idx:
                        mask_bytes = self._load_binary(request.masks[idx])

                response_json = self._dispatch(
                    client, request, prompt, image_bytes, mask_bytes
                )
                usage = response_json.get("usage") or response_json.get(
                    "usage_metadata"
                )

                if usage:
                    print("aib=== USAGE FOUND ===")
                    print("aib input_tokens:", usage.get("input_tokens"))
                    print("aib output_tokens:", usage.get("output_tokens"))
                    input_tokens = usage.get("input_tokens")
                    output_tokens = usage.get("output_tokens")
                    usage_data["input_tokens"] += input_tokens
                    usage_data["output_tokens"] += output_tokens
                else:
                    print("=== NO USAGE IN RESPONSE  AIBRDGECORE===")

                artifacts = self._parse_response(response_json, request)
                results.append(
                    PromptImageResult(prompt_index=idx, prompt=prompt, images=artifacts)
                )

        return ImageGenerationResponse.now(
            provider=self.provider_name,
            model=request.model,
            results=results,
            context={"usage": usage_data},
        )

    def _dispatch(
        self,
        client: httpx.Client,
        request: ImageGenerationRequest,
        prompt: str,
        image_bytes: Optional[bytes],
        mask_bytes: Optional[bytes],
    ) -> dict:

        if image_bytes is None:
            return self._text_to_image(client, request, prompt)

        return self._image_edit(client, request, prompt, image_bytes, mask_bytes)

    def _text_to_image(
        self, client: httpx.Client, request: ImageGenerationRequest, prompt: str
    ) -> dict:
        url = f"{self.BASE_URL}/images/generations"
        payload = {
            "model": request.model,
            "prompt": prompt,
            "n": request.n,
            "size": request.size,
        }
        return self._post_with_retry(client, url, json=payload)

    def _image_edit(
        self,
        client: httpx.Client,
        request: ImageGenerationRequest,
        prompt: str,
        image_bytes: bytes,
        mask_bytes: Optional[bytes],
    ) -> dict:
        """
        For edits (including GPT Image models), use the official '/images/edits' REST endpoint.
        This must be multipart/form-data with actual file uploads.
        """
        url = f"{self.BASE_URL}/images/edits"
        data = {
            "model": request.model,
            "prompt": prompt,
            "n": str(request.n),
            "size": request.size,
        }

        files = {"image": ("image.png", image_bytes, "image/png")}
        if mask_bytes:
            files["mask"] = ("mask.png", mask_bytes, "image/png")

        return self._post_with_retry(client, url, data=data, files=files)

    def _post_with_retry(self, client: httpx.Client, url: str, **kwargs) -> dict:
        delay = 1.0
        for attempt in range(self.MAX_RETRIES):
            try:
                response = client.post(url, **kwargs)

                if response.status_code in (429,) or response.status_code >= 500:
                    raise httpx.HTTPStatusError(
                        "Retryable", request=response.request, response=response
                    )

                response.raise_for_status()
                return response.json()

            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                if status < 500 and status != 429:
                    msg = self._extract_error(e.response)
                    raise ImageProviderError(f"OpenAI API Error {status}: {msg}") from e

                if attempt == self.MAX_RETRIES - 1:
                    msg = self._extract_error(e.response)
                    raise ImageProviderError(f"OpenAI API Error {status}: {msg}") from e

                logger.warning(
                    "Retryable status %s, retrying in %.1fs...", status, delay
                )
                time.sleep(delay)
                delay *= self.BACKOFF_FACTOR

            except Exception as ex:
                if attempt == self.MAX_RETRIES - 1:
                    raise ImageProviderError(
                        f"OpenAI request failed: {str(ex)}"
                    ) from ex
                time.sleep(delay)
                delay *= self.BACKOFF_FACTOR

        raise ImageProviderError("OpenAI request failed after retries.")

    def _parse_response(
        self, data: dict, request: ImageGenerationRequest
    ) -> List[ImageArtifact]:
        artifacts: List[ImageArtifact] = []
        for item in data.get("data", []):
            b64 = item.get("b64_json")
            if not b64:
                continue

            raw = base64.b64decode(b64)
            artifacts.append(
                ImageArtifact(
                    content=raw,
                    content_type="image/png",
                    provider=self.provider_name,
                    model=request.model,
                    size=request.size,
                )
            )
        return artifacts

    def _extract_error(self, response: httpx.Response) -> str:
        try:
            err = response.json()
            if "error" in err and isinstance(err["error"], dict):
                return err["error"].get("message", response.text)
        except Exception:
            pass
        return response.text
