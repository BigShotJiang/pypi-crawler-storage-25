import requests
import time
import base64
from typing import List, Optional

from aibridgecore.image.base import BaseImageProvider
from aibridgecore.image.contracts import (
    ImageGenerationRequest,
    ImageGenerationResponse,
    PromptImageResult,
)
from aibridgecore.image.artifacts import ImageArtifact
from aibridgecore.constant.common import parse_api_key


class AlibabaWanImageProvider(BaseImageProvider):
    provider_name = "alibaba"
    API_URL = "https://dashscope-us.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis"

    def generate(
        self,
        request: ImageGenerationRequest,
        storage=None,
    ) -> ImageGenerationResponse:
        request.validate()

        api_key = self.api_key

        if not api_key:
            try:
                api_key = parse_api_key("alibaba")
            except ImportError:
                pass

        if not api_key:
            raise ValueError("API Key is required for Alibaba Wan Image")

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-DashScope-WorkSpace": "default",
        }

        model_name = request.model if request.model else "wanx-v1"

        results: List[PromptImageResult] = []

        for idx, prompt in enumerate(request.prompts):
            try:
                payload = {
                    "model": model_name,
                    "input": {"prompt": prompt},
                    "parameters": {"style": "<auto>", "n": request.n},
                }

                if request.size == "16:9":
                    payload["parameters"]["size"] = "1280*720"
                elif request.size == "9:16":
                    payload["parameters"]["size"] = "720*1280"
                elif request.size == "1:1" or not request.size:
                    payload["parameters"]["size"] = "1024*1024"
                else:
                    payload["parameters"]["size"] = "1024*1024"

                response = requests.post(
                    self.API_URL, headers=headers, json=payload, timeout=30
                )

                if response.status_code != 200:
                    try:
                        err_msg = response.json().get("message", response.text)
                    except:
                        err_msg = response.text
                    raise RuntimeError(f"Alibaba Submit Failed: {err_msg}")

                data = response.json()
                if "code" in data and data["code"]:
                    raise RuntimeError(f"Alibaba API Error: {data.get('message')}")

                task_id = data.get("output", {}).get("task_id")
                if not task_id:
                    raise RuntimeError(f"No Task ID returned: {data}")

                wait_time = 2
                max_retries = 45
                artifacts = []

                task_status = "PENDING"
                for _ in range(max_retries):
                    time.sleep(wait_time)

                    poll_url = (
                        f"https://dashscope-us.aliyuncs.com/api/v1/tasks/{task_id}"
                    )
                    poll_resp = requests.get(poll_url, headers=headers, timeout=30)
                    poll_data = poll_resp.json()

                    task_status = poll_data.get("output", {}).get("task_status")

                    if task_status == "SUCCEEDED":
                        img_results = poll_data.get("output", {}).get("results", [])

                        for item in img_results:
                            url = item.get("url")
                            if url:
                                try:
                                    img_resp = requests.get(url, timeout=60)
                                    img_resp.raise_for_status()
                                    img_bytes = img_resp.content

                                    artifacts.append(
                                        ImageArtifact(
                                            content=img_bytes,
                                            content_type="image/png",
                                            size=request.size,
                                            provider=self.provider_name,
                                            model=model_name,
                                        )
                                    )
                                except Exception as dl_err:
                                    print(f"Failed to download Alibaba image: {dl_err}")
                        break
                    elif task_status in ["FAILED", "UNKNOWN"]:
                        err_msg = poll_data.get("output", {}).get(
                            "message", "Unknown Error"
                        )
                        raise RuntimeError(f"Alibaba Task Failed: {err_msg}")

                if not artifacts and task_status != "SUCCEEDED":
                    raise RuntimeError("Alibaba Image Generation Timed Out")

                results.append(
                    PromptImageResult(
                        prompt_index=idx,
                        prompt=prompt,
                        images=artifacts,
                    )
                )

            except Exception as e:
                print(f"Alibaba Image Gen Failed for prompt '{prompt}': {e}")
                raise RuntimeError(f"Alibaba Gen Failed: {str(e)}")

        return ImageGenerationResponse.now(
            provider=self.provider_name,
            model=model_name,
            results=results,
        )
