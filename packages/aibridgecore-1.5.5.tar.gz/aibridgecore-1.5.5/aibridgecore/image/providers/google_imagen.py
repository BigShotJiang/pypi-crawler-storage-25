import base64
import logging
import requests
from typing import List

from aibridgecore.image.base import BaseImageProvider
from aibridgecore.image.contracts import (
    ImageGenerationRequest,
    ImageGenerationResponse,
    ImageMode,
    PromptImageResult,
)
from aibridgecore.image.artifacts import ImageArtifact
from aibridgecore.image.exceptions import ImageProviderError

logger = logging.getLogger(__name__)


def _detect_mime(data: bytes) -> str:
    """Detect image MIME type from magic bytes (replaces deprecated imghdr)."""
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:2] == b"\xff\xd8":
        return "image/jpeg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if data[:4] == b"GIF8":
        return "image/gif"
    return "image/jpeg"  # safe default


class GoogleImagenProvider(BaseImageProvider):
    provider_name = "google"
    BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

    def generate(
        self, request: ImageGenerationRequest, storage=None
    ) -> ImageGenerationResponse:
        request.validate()

        api_key = self.api_key
        if not api_key:
            try:
                from aibridgecore.constant.common import parse_api_key

                api_key = parse_api_key("gemini_ai")
            except ImportError:
                pass

        if not api_key:
            raise ValueError("API Key is required for Google Imagen")

        model_name = (
            request.model if request.model else "models/imagen-3.0-generate-001"
        )
        if not model_name.startswith("models/"):
            model_name = f"models/{model_name}"

        if "gemini" in model_name.lower():
            return self._generate_via_gemini_endpoint(request, model_name, api_key)
        else:
            if request.images and request.mode in (
                ImageMode.EDIT,
                ImageMode.IMG_TO_IMG,
            ):
                return self._generate_via_imagen_edit_endpoint(
                    request, model_name, api_key
                )
            return self._generate_via_predict_endpoint(request, model_name, api_key)

    def _generate_via_predict_endpoint(
        self, request: ImageGenerationRequest, model_name: str, api_key: str
    ) -> ImageGenerationResponse:
        results: List[PromptImageResult] = []
        url = f"{self.BASE_URL}/{model_name}:predict?key={api_key}"
        headers = {"Content-Type": "application/json"}

        for idx, prompt in enumerate(request.prompts):
            aspect = (
                request.aspect_ratio
                if request.aspect_ratio in ["16:9", "9:16", "3:4", "4:3"]
                else "1:1"
            )

            payload = {
                "instances": [{"prompt": prompt}],
                "parameters": {
                    "sampleCount": request.n,
                    "aspectRatio": aspect,
                },
            }

            try:
                response = requests.post(url, headers=headers, json=payload, timeout=60)
            except requests.RequestException as e:
                raise ImageProviderError(f"Google API request failed: {str(e)}")

            if response.status_code != 200:
                err_msg = self._extract_error(response)
                raise ImageProviderError(
                    f"Google API Error {response.status_code}: {err_msg}"
                )

            data = response.json()
            predictions = data.get("predictions", [])
            if not predictions:
                raise ImageProviderError("No image predictions returned from API.")

            artifacts = self._parse_predict_predictions(
                predictions, request, model_name
            )
            results.append(
                PromptImageResult(prompt_index=idx, prompt=prompt, images=artifacts)
            )

        return ImageGenerationResponse.now(
            provider=self.provider_name, model=model_name, results=results
        )

    def _generate_via_imagen_edit_endpoint(
        self, request: ImageGenerationRequest, model_name: str, api_key: str
    ) -> ImageGenerationResponse:
        results: List[PromptImageResult] = []
        url = f"{self.BASE_URL}/{model_name}:predict?key={api_key}"
        headers = {"Content-Type": "application/json"}

        for idx, prompt in enumerate(request.prompts):
            image_idx = min(idx, len(request.images) - 1)
            image_bytes = self._load_binary(request.images[image_idx])
            b64_image = base64.b64encode(image_bytes).decode("utf-8")

            instance = {
                "prompt": prompt,
                "image": {"bytesBase64Encoded": b64_image},
            }

            if request.masks and len(request.masks) > image_idx:
                mask_bytes = self._load_binary(request.masks[image_idx])
                b64_mask = base64.b64encode(mask_bytes).decode("utf-8")
                instance["mask"] = {"image": {"bytesBase64Encoded": b64_mask}}

            payload = {
                "instances": [instance],
                "parameters": {"sampleCount": request.n},
            }

            try:
                response = requests.post(url, headers=headers, json=payload, timeout=60)
            except requests.RequestException as e:
                raise ImageProviderError(f"Imagen Edit API request failed: {str(e)}")

            if response.status_code != 200:
                raise ImageProviderError(
                    f"Imagen Edit API Error: {response.text[:200]}"
                )

            data = response.json()
            predictions = data.get("predictions", [])
            artifacts = self._parse_predict_predictions(
                predictions, request, model_name
            )

            results.append(
                PromptImageResult(prompt_index=idx, prompt=prompt, images=artifacts)
            )

        return ImageGenerationResponse.now(
            provider=self.provider_name, model=model_name, results=results
        )

    def _generate_via_gemini_endpoint(
        self, request: ImageGenerationRequest, model_name: str, api_key: str
    ) -> ImageGenerationResponse:
        results: List[PromptImageResult] = []
        usage_data = {
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0,
        }
        url = f"{self.BASE_URL}/{model_name}:generateContent?key={api_key}"
        headers = {"Content-Type": "application/json"}

        thought_sig = request.config.get("thoughtSignature") or request.config.get(
            "thought_signature"
        )

        for idx, prompt in enumerate(request.prompts):
            parts = [{"text": prompt}]

            if request.images and len(request.images) > idx:
                image_bytes = self._load_binary(request.images[idx])
                mime_type = _detect_mime(image_bytes)
                b64_image = base64.b64encode(image_bytes).decode("utf-8")
                parts.append({"inlineData": {"mimeType": mime_type, "data": b64_image}})

            contents = []
            if thought_sig:
                contents.append(
                    {
                        "role": "model",
                        "parts": [
                            {
                                "text": "Previous image generated successfully.",
                                "thoughtSignature": thought_sig,
                            }
                        ],
                    }
                )

            contents.append({"role": "user", "parts": parts})
            payload = {"contents": contents}

            try:
                response = requests.post(url, headers=headers, json=payload, timeout=90)
            except requests.RequestException as e:
                raise ImageProviderError(f"Google Gemini API request failed: {str(e)}")

            if response.status_code != 200:
                err_msg = self._extract_error(response)
                raise ImageProviderError(
                    f"Google Gemini API error {response.status_code}: {err_msg}"
                )

            data = response.json()
            usage = data.get("usageMetadata")
            print("aib=== Gemini USAGE METADATA ===", usage)
            if usage:
                usage_data["input_tokens"] += usage.get("promptTokenCount", 0)
                usage_data["output_tokens"] += usage.get("candidatesTokenCount", 0)
                usage_data["total_tokens"] += usage.get("totalTokenCount", 0)
            candidates = data.get("candidates", [])
            if not candidates:
                raise ImageProviderError(
                    "No candidates returned from Gemini Image API."
                )

            parts_list = candidates[0].get("content", {}).get("parts", [])

            new_thought_sig = None
            for part in parts_list:
                if "thoughtSignature" in part:
                    new_thought_sig = part["thoughtSignature"]
                elif "thought_signature" in part:
                    new_thought_sig = part["thought_signature"]

            logger.debug("Extracted thoughtSignature: %s", bool(new_thought_sig))

            artifacts = []
            for part in parts_list:
                if "inlineData" in part:
                    b64_data = part["inlineData"]["data"]
                    mime_type = part["inlineData"].get("mimeType", "image/png")

                    artifacts.append(
                        ImageArtifact(
                            content=base64.b64decode(b64_data),
                            content_type=mime_type,
                            size=request.size,
                            provider=self.provider_name,
                            model=model_name,
                            metadata=(
                                {"thoughtSignature": new_thought_sig}
                                if new_thought_sig
                                else {}
                            ),
                        )
                    )

            results.append(
                PromptImageResult(prompt_index=idx, prompt=prompt, images=artifacts)
            )

        return ImageGenerationResponse.now(
            provider=self.provider_name, model=model_name, results=results, context={"usage": usage_data},
        )

    def _parse_predict_predictions(
        self, predictions: list, request: ImageGenerationRequest, model_name: str
    ) -> List[ImageArtifact]:
        """Parse predictions from Imagen predict endpoint into ImageArtifacts."""
        artifacts = []
        for pred in predictions:
            b64_data = None
            if isinstance(pred, dict):
                b64_data = pred.get("bytesBase64Encoded") or pred.get("image", {}).get(
                    "bytesBase64Encoded"
                )
            elif isinstance(pred, str):
                b64_data = pred

            if not b64_data:
                logger.warning("Could not extract image data from prediction")
                continue

            raw_bytes = base64.b64decode(b64_data)
            artifacts.append(
                ImageArtifact(
                    content=raw_bytes,
                    content_type="image/png",
                    size=request.size,
                    provider=self.provider_name,
                    model=model_name,
                )
            )
        return artifacts

    @staticmethod
    def _extract_error(response) -> str:
        """Extract error message from a failed API response."""
        try:
            return response.json().get("error", {}).get("message", response.text)
        except Exception:
            return response.text
