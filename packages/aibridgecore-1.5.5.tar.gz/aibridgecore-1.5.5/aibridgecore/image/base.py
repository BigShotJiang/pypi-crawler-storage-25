import logging
import time
import requests
from abc import ABC, abstractmethod
from typing import Optional

from .contracts import ImageGenerationRequest, ImageGenerationResponse
from .storage import ImageStorage
from .exceptions import ImageProviderError

logger = logging.getLogger(__name__)


class BaseImageProvider(ABC):
    provider_name: str

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key

    @abstractmethod
    def generate(
        self, request: ImageGenerationRequest, storage: ImageStorage = None
    ) -> ImageGenerationResponse:
        pass

    def _load_binary(self, source: str, retries: int = 2) -> bytes:
        """Load binary data from a URL or local file path.

        Includes retry logic for URL downloads to handle transient failures.
        Shared helper — providers should use this instead of implementing their own.
        """
        if source.startswith("http"):
            last_error = None
            for attempt in range(retries + 1):
                try:
                    logger.debug("Downloading binary from URL: %s (attempt %d)", source[:80], attempt + 1)
                    resp = requests.get(source, timeout=30)
                    resp.raise_for_status()
                    return resp.content
                except requests.RequestException as e:
                    last_error = e
                    if attempt < retries:
                        wait = 1 * (attempt + 1)  # 1s, 2s
                        logger.warning(
                            "Download failed (attempt %d/%d), retrying in %ds: %s",
                            attempt + 1, retries + 1, wait, str(e)
                        )
                        time.sleep(wait)
            raise ImageProviderError(
                f"Failed to download image after {retries + 1} attempts: {last_error}"
            )

        try:
            with open(source, "rb") as f:
                return f.read()
        except (FileNotFoundError, IOError) as e:
            raise ImageProviderError(f"Failed to read local image file: {e}")
