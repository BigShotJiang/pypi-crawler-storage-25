class ImageGenerationError(Exception):
    """
    Base exception for all image generation errors."""

    pass


class ImageValidationError(ImageGenerationError):
    """Raise when request validation fails."""

    pass


class ImageProviderError(ImageGenerationError):
    """Raised when the external AI provider fails (API error, timeout)."""

    pass


class ImageStorageError(ImageGenerationError):

    pass
