from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from enum import Enum


class VideoMode(str, Enum):
    TEXT_TO_VIDEO = "text2video"
    IMG_TO_VIDEO = "img2video"
    VIDEO_TO_VIDEO = "video2video"


@dataclass
class VideoGenerationRequest:

    model: str
    prompt: str
    duration_seconds: int = 5
    aspect_ratio: str = "16:9"
    mode: str = VideoMode.TEXT_TO_VIDEO.value
    images: List[str] = field(default_factory=list)
    videos: List[str] = field(default_factory=list)
    negative_prompt: Optional[str] = None
    seed: Optional[str] = None
    config: Dict[str, Any] = field(default_factory=dict)

    def validate(self):
        if not self.prompt:
            raise ValueError("Prompt cannot be empty")

        if self.mode not in {
            VideoMode.TEXT_TO_VIDEO.value,
            VideoMode.IMG_TO_VIDEO.value,
            VideoMode.VIDEO_TO_VIDEO.value,
        }:
            raise ValueError(f"Unsupported video mode '{self.mode}'")

        if self.mode == VideoMode.IMG_TO_VIDEO.value and not self.images:
            raise ValueError("img2video mode required at least one image reference")

        if self.mode == VideoMode.VIDEO_TO_VIDEO.value:
            raise NotImplementedError("video2video is planned but not enabled yet")


@dataclass
class VideoGenerationResponse:

    provider_job_id: str
    status: str
    provider: str
    model: str

    @staticmethod
    def now(provider: str, model: str, job_id: str, status: str):
        return VideoGenerationResponse(
            provider=provider, model=model, provider_job_id=job_id, status=status
        )
