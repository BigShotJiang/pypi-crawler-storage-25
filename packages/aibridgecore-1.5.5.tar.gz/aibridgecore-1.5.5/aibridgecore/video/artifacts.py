from dataclasses import dataclass
from typing import Optional


@dataclass
class VideoStatusArtifact:

    provider_job_id: str
    status: str
    result_url: Optional[str] = None
    error: Optional[str] = None
    progress: int = 0
