class VideoProviderError(Exception):
    pass
