from abc import ABC, abstractmethod
import requests
from typing import Optional
from ..contracts import VideoGenerationRequest, VideoGenerationResponse
from ..artifacts import VideoStatusArtifact


class BaseVideoProvider(ABC):
    provider_name: str = "unknown"

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key

    @abstractmethod
    def start_generation(
        self, request: VideoGenerationRequest
    ) -> VideoGenerationResponse:

        pass

    @abstractmethod
    def check_status(self, job_id: str) -> VideoStatusArtifact:

        pass

    def download_video(self, url: str) -> bytes:
        response = requests.get(url, timeout=60)
        response.raise_for_status()
        return response.content
