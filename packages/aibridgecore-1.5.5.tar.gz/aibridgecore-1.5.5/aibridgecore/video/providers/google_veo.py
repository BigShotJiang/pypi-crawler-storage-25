import requests

# import generativeai as genai
from .base import BaseVideoProvider
from ..contracts import VideoGenerationRequest, VideoGenerationResponse, VideoMode
from ..artifacts import VideoStatusArtifact


class GoogleVeoProvider(BaseVideoProvider):
    provider_name = "google"
    BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

    def check_status(self, job_id: str) -> VideoStatusArtifact:
        if not self.api_key:
            raise ValueError("API Key is required for Google Veo")

        separator = "&" if "?" in job_id else "?"
        url = f"{self.BASE_URL}/{job_id}{separator}key={self.api_key}"

        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            data = response.json()
            is_done = data.get("done", False)

            if not is_done:
                return VideoStatusArtifact(provider_job_id=job_id, status="processing")

            if "error" in data:
                return VideoStatusArtifact(
                    provider_job_id=job_id,
                    status="failed",
                    error=data["error"].get("message"),
                )

            video_url = None
            resp_body = data.get("response", {})
            gen_resp = resp_body.get("generateVideoResponse", {})
            samples = gen_resp.get("generatedSamples", [])

            if samples:
                video_url = samples[0].get("video", {}).get("uri")

            if not video_url:
                candidates = resp_body.get("candidates", [])
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    for part in parts:
                        if "fileData" in part:
                            video_url = part["fileData"].get("fileUri")
                            break

            if not video_url:
                return VideoStatusArtifact(
                    provider_job_id=job_id,
                    status="failed",
                    error="No video URL found in response",
                )

            if "generativelanguage.googleapis.com" in video_url:
                sep = "&" if "?" in video_url else "?"
                video_url = f"{video_url}{sep}key={self.api_key}"

            return VideoStatusArtifact(
                provider_job_id=job_id, status="completed", result_url=video_url
            )

        except requests.exceptions.HTTPError as e:
            error_detail = e.response.json() if e.response else str(e)
            return VideoStatusArtifact(
                provider_job_id=job_id,
                status="processing",
                error=f"HTTP Error: {str(error_detail)}",
            )
        except Exception as e:
            return VideoStatusArtifact(
                provider_job_id=job_id, status="processing", error=str(e)
            )

    def start_generation(
        self, request: VideoGenerationRequest
    ) -> VideoGenerationResponse:

        if not self.api_key:
            raise ValueError("API Key is required for Google Veo")

        request.validate()

        mode = (getattr(request, "mode", VideoMode.TEXT_TO_VIDEO.value) or "").lower()
        if mode == VideoMode.VIDEO_TO_VIDEO.value:
            raise NotImplementedError("video2video is planned but not enabled yet")

        model_name = request.model
        if not model_name.startswith("models/"):
            model_name = f"models/{model_name}"

        url = f"{self.BASE_URL}/{model_name}:predictLongRunning"

        instance = {"prompt": request.prompt}
        if mode == VideoMode.IMG_TO_VIDEO.value:
            if not request.images:
                raise ValueError("img2video mode requires image reference")
            instance["image"] = {"uri": request.images[0]}

        payload = {
            "instances": [instance],
            "parameters": {
                "aspectRatio": request.aspect_ratio,
                "sampleCount": 1,
            },
        }

        if request.duration_seconds:
            duration = int(request.duration_seconds)
            is_veo3 = "veo-3" in request.model.lower()
            
            if is_veo3:
                # Veo 3 only supports 4, 6, 8
                if duration <= 4:
                    duration = 4
                elif duration <= 6:
                    duration = 6
                else:
                    duration = 8
            else:
                # Veo 2 supports 5-8
                if duration < 5:
                    duration = 5
                elif duration > 8:
                    duration = 8

            payload["parameters"]["durationSeconds"] = duration

        if request.negative_prompt:
            payload["instances"][0]["negativePrompt"] = request.negative_prompt

        if request.config:
            if "seed" in request.config:
                payload["parameters"]["seed"] = int(request.config["seed"])
            if "resolution" in request.config:
                payload["parameters"]["resolution"] = request.config["resolution"]
            if "person_generation" in request.config:
                payload["parameters"]["personGeneration"] = request.config[
                    "person_generation"
                ]

        headers = {"Content-Type": "application/json"}

        try:
            response = requests.post(
                f"{url}?key={self.api_key}", json=payload, headers=headers, timeout=30
            )
            response.raise_for_status()

            data = response.json()
            operation_name = data.get("name")

            if not operation_name:
                raise RuntimeError(f"No operation ID returned. Response: {data}")

            return VideoGenerationResponse.now(
                provider=self.provider_name,
                model=model_name,
                job_id=operation_name,
                status="queued",
            )

        except requests.exceptions.HTTPError as e:
            try:
                error_detail = e.response.json()
            except:
                error_detail = e.response.text if e.response else str(e)
            raise RuntimeError(f"Google Veo Start Failed: {error_detail}")

        except Exception as e:
            raise RuntimeError(f"Google Veo Start Failed: {str(e)}")
