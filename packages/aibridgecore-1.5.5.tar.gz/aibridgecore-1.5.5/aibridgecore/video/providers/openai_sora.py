import requests
import logging
from .base import BaseVideoProvider
from ..contracts import VideoGenerationRequest, VideoGenerationResponse, VideoMode
from ..artifacts import VideoStatusArtifact

logger = logging.getLogger(__name__)

ASPECT_RATIO_MAP = {
    "16:9": "1280x720",
    "9:16": "720x1280",
    "1:1": "720x720",
}


class OpenAISoraProvider(BaseVideoProvider):
    provider_name = "openai"
    BASE_URL = "https://api.openai.com/v1/videos"

    def _get_headers(self):
        if not self.api_key:
            raise ValueError("API Key is required for OpenAI Sora")

        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def start_generation(
        self, request: VideoGenerationRequest
    ) -> VideoGenerationResponse:
        request.validate()

        mode = (getattr(request, "mode", VideoMode.TEXT_TO_VIDEO.value) or "").lower()
        if mode == VideoMode.VIDEO_TO_VIDEO.value:
            raise NotImplementedError("video2video is planned but not enabled yet")

        # size = ASPECT_RATIO_MAP.get(request.aspect_ratio, "1280x720")

        is_1080p = request.config and request.config.get("resolution") == "1080p"
        if request.aspect_ratio == "16:9":
            size = "1920x1080" if is_1080p else "1280x720"
        elif request.aspect_ratio == "9:16":
            size = "1080x1920" if is_1080p else "720x1280"
        else:
            size = "1280x720"

        payload = {
            "model": request.model,
            "prompt": request.prompt,
            "size": size,
        }

        if request.config and "duration" in request.config:
            payload["seconds"] = str(request.config["duration"])
        elif request.duration_seconds:
            payload["seconds"] = str(request.duration_seconds)

        if mode == VideoMode.IMG_TO_VIDEO.value:
            if not request.images:
                raise ValueError("img2video mode requires image reference")
            payload["image"] = request.images[0]

        if request.config:
            if "quality" in request.config:
                payload["quality"] = request.config["quality"]
            if "n" in request.config:
                payload["n"] = request.config["n"]

        try:
            response = requests.post(
                self.BASE_URL,
                headers=self._get_headers(),
                json=payload,
                timeout=30,
            )

            response.raise_for_status()
            data = response.json()

            job_id = data.get("id")
            if not job_id:
                raise RuntimeError(f"No job ID returned. Response: {data}")

            return VideoGenerationResponse.now(
                provider=self.provider_name,
                model=request.model,
                job_id=job_id,
                status="queued",
            )

        except requests.exceptions.HTTPError as e:
            try:
                error_detail = e.response.json()

            except Exception:
                error_detail = e.response.text if e.response else str(e)
            raise RuntimeError(f"OpenAI Sora start failed: {error_detail}")
        except Exception as e:
            raise RuntimeError(f"OpenAI Sora Start Failed: {str(e)}")

    def check_status(self, job_id: str) -> VideoStatusArtifact:

        url = f"{self.BASE_URL}/{job_id}"
        try:
            response = requests.get(url, headers=self._get_headers(), timeout=30)

            response.raise_for_status()
            data = response.json()

            status_map = {
                "queued": "pending",
                "in_progress": "processing",
                "processing": "processing",
                "completed": "completed",
                "failed": "failed",
                "expired": "expired",
            }

            standard_status = status_map.get(data.get("status"), "processing")

            result_url = None
            if standard_status == "completed":
                result_url = f"{self.BASE_URL}/{job_id}/content"

            error_msg = None
            if standard_status == "failed":
                error_obj = data.get("error", {})
                if isinstance(error_obj, dict):
                    error_msg = error_obj.get("message", "Unknown failure")
                else:
                    error_msg = str(error_obj)

            return VideoStatusArtifact(
                provider_job_id=job_id,
                status=standard_status,
                result_url=result_url,
                error=error_msg,
            )

        except Exception as e:
            return VideoStatusArtifact(
                provider_job_id=job_id, status="processing", error=str(e)
            )

    def download_video(self, url: str) -> bytes:
        response = requests.get(url, headers=self._get_headers(), timeout=60)
        response.raise_for_status()
        return response.content
