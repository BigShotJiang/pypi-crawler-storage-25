import requests
from .base import BaseVideoProvider
from ..contracts import VideoGenerationRequest, VideoGenerationResponse
from ..artifacts import VideoStatusArtifact
from aibridgecore.constant.common import parse_api_key


class LumaVideoProvider(BaseVideoProvider):
    provider_name = "luma"
    API_URL = "https://api.lumalabs.ai/dream-machine/v1/generations"

    def _get_headers(self):
        # api_key = ""
        # api_key = parse_api_key()
        if not self.api_key:
            raise ValueError("API Key is required for Luma Provider")

        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "accept": "application/json",
        }

    def start_generation(
        self, request, VideoGenerationRequest
    ) -> VideoGenerationResponse:
        request.validate()

        payload = {
            "prompt": request.prompt,
            "aspect_ratio": request.aspect_ratio,
            "loop": False,
        }

        payload.update(request.config)

        try:
            response = requests.post(
                self.API_URL, json=payload, headers=self._get_headers(), timeout=30
            )

            response.raise_for_status()
            data = response.json()

            return VideoGenerationResponse.now(
                provider=self.provider_name,
                model=request.model,
                job_id=data["id"],
                status="queued",
            )

        except Exception as e:
            raise RuntimeError(f"Luma Start Failed : {str(e)}")

    def check_status(self, job_id: str) -> VideoStatusArtifact:
        url = f"{self.API_URL}/{job_id}"

        try:
            response = requests.get(url, headers=self._get_headers(), timeout=30)
            response.raise_for_status()
            data = response.json()

            state = data.get("state")

            status_map = {
                "queued": "pending",
                "dreaming": "processing",
                "completed": "completed",
                "failed": "failed",
            }

            standard_status = status_map.get(state, "processing")

            result_url = None
            if standard_status == "completed":
                result_url = data.get("assets", {}).get("video")

            error_msg = (
                data.get("failure_reason") if standard_status == "failed" else None
            )

            return VideoStatusArtifact(
                provider_job_id=job_id,
                status=standard_status,
                result_url=result_url,
                error=error_msg,
            )
        except Exception as e:
            return VideoStatusArtifact(
                provider_job_id=job_id, status="processing", error=str(e)
            )
