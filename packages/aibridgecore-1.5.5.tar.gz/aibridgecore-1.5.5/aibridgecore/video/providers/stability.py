import requests
from .base import BaseVideoProvider
from ..contracts import VideoGenerationRequest, VideoGenerationResponse
from ..artifacts import VideoStatusArtifact
from aibridgecore.constant.common import parse_api_key


class StabilityVideoProvider(BaseVideoProvider):
    provider_name = "stability"
    API_HOST = "https://api.stability.ai"

    def _get_headers(self):
        if not self.api_key:
            raise ValueError("API Key is required for Stability Provider")

        # api_key = parse_api_key("stability_ai")
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def start_generation(
        self, request: VideoGenerationRequest
    ) -> VideoGenerationResponse:
        request.validate()

        url = f"{self.API_HOST}/v2beta/image-to-video"

        payload = {
            "text_prompts": [{"text": request.prompt}],
            "cfg_scale": 1.8,
            "motion_bucket_id": 127,
        }

        if request.aspect_ratio == "16:9":
            payload["width"] = 1024
            payload["height"] = 576

        elif request.aspect_ratio == "1:1":
            payload["width"] = 768
            payload["height"] = 768

        try:
            response = requests.post(
                url, headers=self._get_headers(), json=payload, timeout=30
            )

            response.raise_for_status()
            data = response.json()

            job_id = data["id"]

            return VideoGenerationResponse.now(
                provider=self.provider_name,
                model=request.model,
                job_id=job_id,
                status="queued",
            )

        except Exception as e:
            raise RuntimeError(f"Stability Start Failed: {str(e)}")

    def check_status(self, job_id: str) -> VideoStatusArtifact:
        url = f"{self.API_HOST}/v2beta/image-to-video/result/{job_id}"

        try:
            response = requests.get(url, headers=self._get_headers(), timeout=30)

            if response.status_code == 202:
                return VideoStatusArtifact(provider_job_id=job_id, status="processing")

            response.raise_for_status()
            data = response.json()

            if data.get("finish_reason") == "SUCCESS":

                video_url = data.get("video", {}).get("url")

                return VideoStatusArtifact(
                    provider_job_id=job_id, status="completed", result_url=video_url
                )

            if data.get("status") == "error":
                return VideoStatusArtifact(
                    provider_job_id=job_id, status="failed", error=data.get("message")
                )

            return VideoStatusArtifact(provider_job_id=job_id, status="processing")

        except Exception as e:
            return VideoStatusArtifact(
                provider_job_id=job_id, status="processing", error=str(e)
            )
