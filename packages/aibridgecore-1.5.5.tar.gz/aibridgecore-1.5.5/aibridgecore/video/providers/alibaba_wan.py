import requests
import json
from .base import BaseVideoProvider
from ..contracts import VideoGenerationRequest, VideoGenerationResponse, VideoMode
from ..artifacts import VideoStatusArtifact


class AlibabaWanProvider(BaseVideoProvider):
    provider_name = "alibaba"
    API_URL = "https://dashscope-us.aliyuncs.com/api/v1/services/aigc/video-generation/video-synthesis"

    def _get_headers(self):
        if not self.api_key:
            raise ValueError("API Key is required for Alibaba Wan")
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "X-DashScope-Async": "enable",
        }

    def start_generation(
        self, request: VideoGenerationRequest
    ) -> VideoGenerationResponse:
        request.validate()

        mode = (getattr(request, "mode", VideoMode.TEXT_TO_VIDEO.value) or "").lower()
        if mode == VideoMode.VIDEO_TO_VIDEO.value:
            raise NotImplementedError("video2video is planned but not enabled yet")

        model_name = request.model if "wan" in request.model else "wanx-v1"

        input_payload = {"prompt": request.prompt}
        if mode == VideoMode.IMG_TO_VIDEO.value:
            if not request.images:
                raise ValueError("img2video mode requires image reference")
            input_payload["img_url"] = request.images[0]

        payload = {
            "model": model_name,
            "input": input_payload,
            "parameters": {},
        }

        size = "1280*720"
        if request.aspect_ratio == "16:9":
            size = "1280*720"
        elif request.aspect_ratio == "9:16":
            size = "720*1280"
        elif request.aspect_ratio == "1:1":
            size = "1024*1024"

        if request.config and "resolution" in request.config:
            if request.config["resolution"] == "1080p":
                if request.aspect_ratio == "16:9":
                    size = "1920*1080"
                elif request.aspect_ratio == "9:16":
                    size = "1080*1920"

        payload["parameters"]["size"] = size

        if request.negative_prompt:
            payload["parameters"]["negative_prompt"] = request.negative_prompt

        if request.config:
            if "duration" in request.config:
                payload["parameters"]["duration"] = request.config["duration"]
            if "camera_motion" in request.config:
                payload["parameters"]["camera_motion"] = request.config["camera_motion"]
            if "seed" in request.config:
                payload["parameters"]["seed"] = request.config["seed"]
            if "use_prompt_extend" in request.config:
                payload["parameters"]["use_prompt_extend"] = (
                    request.config["use_prompt_extend"].lower() == "true"
                )

        try:
            response = requests.post(
                self.API_URL, headers=self._get_headers(), json=payload, timeout=30
            )

            if response.status_code != 200:
                try:
                    print(response.json())
                    err_msg = response.json().get("message", response.text)
                except:
                    print(response.json())
                    err_msg = str(response.status_code)
                raise RuntimeError(f"Alibaba HTTP Error : {err_msg}")

            data = response.json()

            if "code" in data and data["code"]:
                raise RuntimeError(
                    f"Alibaba API Error: {data.get('message')} (Code: {data.get('code')})"
                )

            task_id = data.get("output", {}).get("task_id")
            if not task_id:
                raise RuntimeError("No task_id returned from Alibaba API")

            return VideoGenerationResponse.now(
                provider=self.provider_name,
                model=model_name,
                job_id=task_id,
                status="queued",
            )
        except Exception as e:
            raise RuntimeError(f"Alibaba Wan Start Failed: {str(e)}")

    def check_status(self, job_id: str) -> VideoStatusArtifact:
        url = f"https://dashscope-us.aliyuncs.com/api/v1/tasks/{job_id}"
        try:
            response = requests.get(url, headers=self._get_headers(), timeout=30)

            if response.status_code != 200:
                return VideoStatusArtifact(
                    provider_job_id=job_id,
                    status="processing",
                    error=f"HTTP {response.status_code}",
                )
            data = response.json()
            task_status = data.get("output", {}).get("task_status")
            status_map = {
                "PENDING": "pending",
                "RUNNING": "processing",
                "SUCCEEDED": "completed",
                "FAILED": "failed",
                "UNKNOWN": "failed",
            }

            standard_status = status_map.get(task_status, "processing")

            result_url = None
            error_msg = None

            if standard_status == "completed":
                result_url = data.get("output", {}).get("video_url")

                if not result_url and "results" in data.get("output", {}):
                    results = data.get("output", {}).get("results")
                    if results and isinstance(results, list):
                        if len(results) > 0:
                            result_url = results[0].get("url")

            elif standard_status == "failed":
                error_msg = data.get("output", {}).get("message", "Task Failed")
                if not error_msg and "message" in data:
                    error_msg = data.get("message")

            return VideoStatusArtifact(
                provider_job_id=job_id,
                status=standard_status,
                result_url=result_url,
                error=error_msg,
            )

        except Exception as e:
            return VideoStatusArtifact(
                provider_job_id=job_id, status="processing", error=str(e)
            )
