# pycan_ultra

**pycan_ultra** is a deep, modular, and agentic Python platform for end-to-end cancer research,
translational analytics, and precision oncology decision support.

Built as a full-stack research engine, it unifies autonomous multi-agent reasoning, multi-omics
integration, survival modeling, drug prioritization, evidence retrieval, and publication-grade
visualization in one package.

## Why pycan_ultra

Most oncology stacks require stitching many isolated tools. **pycan_ultra** provides a coherent,
typed, and reproducible architecture that supports both exploratory science and production
pipelines.

### Key strengths

- **Agentic intelligence layer**: orchestrates genomics, transcriptomics, survival, pathology,
  drug-discovery, reporting, and memory agents from a single objective.
- **Multi-omics depth**: supports TCGA/GEO/cBioPortal ingestion patterns and harmonized modality
  processing for genomics, transcriptomics, spatial, methylation, proteomics, and metabolomics.
- **Precision oncology engine**: biomarker ranking, mutation signatures, neoantigen ranking,
  immunotherapy scoring, resistance forecasting, and patient-ready summary generation.
- **Modeling stack**: survival, multimodal fusion, graph ranking, anomaly detection, ctDNA risk,
  explainability, and model registry primitives.
- **Knowledge and evidence system**: OncoKB/CIViC-style abstractions, variant annotation, evidence
  ranking, and literature-aware answer generation.
- **Pipeline-first design**: discovery, patient, cohort, longitudinal, NGS, spatial, IO, and
  benchmark pipelines with scheduler-ready interfaces.
- **Clinical-grade foundations**: structured schemas, explicit exceptions, caching, logging,
  deterministic utilities, and test scaffolding.
- **Offline-capable operation**: rule-based fallback paths for environments without LLM/API access.

## Feature map

| Layer | What it provides |
|---|---|
| Agents | Autonomous planning, tool-call envelopes, reflection loops, state persistence |
| Omics | Typed loaders, harmonization helpers, integration and validation contracts |
| Precision | Clinical scoring modules and recommendation-ready outputs |
| Models | Research model primitives and deploy/export-oriented interfaces |
| Pipelines | One-function workflows for discovery, patient, and cohort operations |
| Knowledge | Evidence retrieval, annotation, and ranking for grounded decisions |
| Viz | OncoPrint, KM points, landscape, pathway, spatial, and reporting visuals |
| Core/Utils | Config, logging, cache, schemas, auth/rate-limits, async/parallel helpers |

## Installation

```bash
pip install pycan-ultra
```

Enable optional stacks:

```bash
pip install "pycan-ultra[omics,dl,agents,viz,dev,docs]"
```

## Quick start

```python
from pycan_ultra import __version__
from pycan_ultra.pipelines.discovery_pipeline import run_discovery

print("pycan_ultra", __version__)
result = run_discovery("BRCA", 1200)
print(result["targets"]) 
```

## CLI

```bash
pycan --help
pycan discover --cancer BRCA --omics tcga
```

## Packaging and distribution

This project uses **Hatchling** via [`pyproject.toml`](pyproject.toml).

Build artifacts:

```bash
python -m build
```

Upload (when token is configured):

```bash
python -m twine upload dist/*
```

## License

Apache-2.0

