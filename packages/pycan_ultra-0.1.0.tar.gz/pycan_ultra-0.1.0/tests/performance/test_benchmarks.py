"""Performance smoke benchmark tests."""

from pycan_ultra.pipelines.benchmark_pipeline import run_benchmark


def test_benchmark_payload_shape() -> None:
    """Benchmark payload should contain c_index field."""
    payload = run_benchmark("survival_transformer")
    assert "c_index" in payload

