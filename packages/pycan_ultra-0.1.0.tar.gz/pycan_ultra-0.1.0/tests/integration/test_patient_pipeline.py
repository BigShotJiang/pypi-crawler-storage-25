"""Integration test for patient pipeline."""

from pycan_ultra.pipelines.patient_pipeline import run_patient


def test_patient_pipeline_integration() -> None:
    """Patient pipeline should complete."""
    result = run_patient("P001")
    assert result["status"] == "completed"

