"""Integration test for discovery pipeline."""

from pycan_ultra.pipelines.discovery_pipeline import run_discovery


def test_discovery_pipeline_integration() -> None:
    """Discovery pipeline should return candidates."""
    result = run_discovery("LUAD", 200)
    assert len(result["drug_candidates"]) > 0

