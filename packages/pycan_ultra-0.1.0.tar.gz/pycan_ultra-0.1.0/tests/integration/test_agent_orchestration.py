"""Integration test for multi-agent orchestration."""

import pytest

from pycan_ultra.agents.orchestrator_agent import OrchestratorAgent


@pytest.mark.asyncio
async def test_agent_orchestration_integration() -> None:
    """Orchestrator integration smoke test."""
    out = await OrchestratorAgent().run_with_reflection("Rank EGFR targets")
    assert out.status in {"success", "fallback"}

