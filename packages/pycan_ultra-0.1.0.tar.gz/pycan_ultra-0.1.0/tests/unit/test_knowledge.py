"""Unit tests for knowledge modules."""

from pycan_ultra.knowledge.evidence_ranker import rank_evidence


def test_rank_evidence() -> None:
    """Evidence should sort by tier."""
    ranked = rank_evidence([("x", "PRECLINICAL"), ("y", "FDA")])
    assert ranked[0][1] == "FDA"

