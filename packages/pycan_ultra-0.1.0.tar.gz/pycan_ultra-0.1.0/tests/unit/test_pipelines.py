"""Unit tests for pipelines."""

from pycan_ultra.pipelines.discovery_pipeline import run_discovery


def test_run_discovery() -> None:
    """Discovery should produce targets."""
    payload = run_discovery("BRCA", 100)
    assert "targets" in payload

