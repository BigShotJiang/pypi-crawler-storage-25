"""Unit tests for utility modules."""

from pycan_ultra.utils.bioinformatics import gc_content
from pycan_ultra.utils.stats import benjamini_hochberg


def test_gc_content() -> None:
    """GC content should be computed correctly."""
    assert gc_content("GGCCAA") == 4 / 6


def test_bh_empty() -> None:
    """BH should handle empty list."""
    assert benjamini_hochberg([]) == []

