"""Unit tests for agents."""

import pytest

from pycan_ultra.agents.orchestrator_agent import OrchestratorAgent


@pytest.mark.asyncio
async def test_orchestrator_runs() -> None:
    """Orchestrator should return structured output."""
    agent = OrchestratorAgent()
    out = await agent.run_with_reflection("Find targets in BRCA")
    assert out.agent == "orchestrator"

