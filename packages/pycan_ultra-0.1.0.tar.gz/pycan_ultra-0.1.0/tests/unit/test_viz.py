"""Unit tests for visualization helpers."""

from pycan_ultra.viz.survival_plot import km_points


def test_km_points_nonempty() -> None:
    """KM points should include all times."""
    points = km_points([3.0, 1.0, 2.0])
    assert len(points) == 3

