"""Unit tests for precision modules."""

from pycan_ultra.precision.biomarker_discovery import rank_biomarkers


def test_rank_biomarkers() -> None:
    """Biomarker ranking should be descending."""
    ranked = rank_biomarkers({"A": 0.1, "B": 0.9, "C": 0.2}, top_k=2)
    assert ranked[0][0] == "B"

