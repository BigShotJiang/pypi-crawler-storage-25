"""Unit tests for model helpers."""

from pycan_ultra.models.multimodal_fusion import fuse_scores


def test_fuse_scores() -> None:
    """Fusion score should be mean of inputs."""
    assert fuse_scores(0.3, 0.6, 0.9) == 0.6

