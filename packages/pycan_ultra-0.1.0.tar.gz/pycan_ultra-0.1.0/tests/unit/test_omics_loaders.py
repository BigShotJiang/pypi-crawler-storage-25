"""Unit tests for omics loaders."""

from pathlib import Path

from pycan_ultra.omics.tcga_loader import load_tcga


def test_load_tcga(tmp_path: Path) -> None:
    """TCGA loader returns typed dataset."""
    ds = load_tcga("BRCA", tmp_path)
    assert ds.cancer_type == "BRCA"

