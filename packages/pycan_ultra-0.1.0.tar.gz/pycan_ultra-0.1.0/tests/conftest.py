"""Shared pytest fixtures for pycan_ultra."""

from pathlib import Path

import pytest


@pytest.fixture
def temp_output_dir(tmp_path: Path) -> Path:
    """Provide temporary output directory.

    Args:
        tmp_path: Built-in tmp fixture.

    Returns:
        Path to output dir.
    """
    output = tmp_path / "out"
    output.mkdir(parents=True, exist_ok=True)
    return output

