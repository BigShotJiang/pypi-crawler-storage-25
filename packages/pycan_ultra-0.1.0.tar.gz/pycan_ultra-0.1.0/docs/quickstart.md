# Quickstart

Install package:

```bash
pip install pycan-ultra
```

Run CLI:

```bash
pycan --help
```

