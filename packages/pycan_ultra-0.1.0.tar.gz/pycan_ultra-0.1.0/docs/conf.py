"""Sphinx configuration for pycan_ultra docs."""

project = "pycan_ultra"
author = "balagaraghuram1"
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "myst_parser",
    "nbsphinx",
]
html_theme = "furo"

