# Architecture

`pycan_ultra` uses clean architecture layers:

- domain schemas and contracts
- application services and pipelines
- infrastructure adapters for APIs, models, and I/O

