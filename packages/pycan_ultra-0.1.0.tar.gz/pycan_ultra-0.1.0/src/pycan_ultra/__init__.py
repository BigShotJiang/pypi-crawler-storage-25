"""Top-level package for pycan_ultra."""

from importlib.metadata import PackageNotFoundError, version


def _resolve_version() -> str:
    """Resolve installed package version safely.

    Returns:
        The installed package version or a local fallback.
    """
    try:
        return version("pycan-ultra")
    except PackageNotFoundError:
        return "0.1.0"


__version__ = _resolve_version()

