"""Figure export starter utilities."""

from pathlib import Path


def export_placeholder(path: Path, title: str) -> Path:
    """Export a placeholder text artifact.

    Args:
        path: Output path.
        title: Figure title.

    Returns:
        Path written.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"Figure: {title}\n", encoding="utf-8")
    return path

