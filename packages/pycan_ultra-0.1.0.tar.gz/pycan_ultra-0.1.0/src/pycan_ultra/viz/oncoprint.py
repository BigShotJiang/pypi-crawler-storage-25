"""OncoPrint utilities starter."""


def oncoprint_matrix(samples: int, genes: int) -> list[list[int]]:
    """Build an empty oncoprint matrix.

    Args:
        samples: Sample count.
        genes: Gene count.

    Returns:
        Binary matrix.
    """
    return [[0 for _ in range(genes)] for _ in range(samples)]

