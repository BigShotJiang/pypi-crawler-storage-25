"""Tumor evolution visualization starter."""


def fishplot_series(clonal_fraction: list[float]) -> list[float]:
    """Normalize clonal fractions for fishplot rendering.

    Args:
        clonal_fraction: Raw fractions.

    Returns:
        Normalized fractions.
    """
    total = sum(clonal_fraction)
    if total <= 0:
        return [0.0 for _ in clonal_fraction]
    return [x / total for x in clonal_fraction]

