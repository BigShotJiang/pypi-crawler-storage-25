"""Network visualization starter."""


def to_edges(pairs: list[tuple[str, str]]) -> list[dict[str, str]]:
    """Convert edge pairs to dict records.

    Args:
        pairs: Source-target pairs.

    Returns:
        Edge dictionaries.
    """
    return [{"source": s, "target": t} for s, t in pairs]

