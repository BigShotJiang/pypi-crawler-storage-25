"""Mutation landscape starter."""


def tmb_bar(values: list[float]) -> list[float]:
    """Return sorted TMB values for plotting.

    Args:
        values: TMB values.

    Returns:
        Sorted values.
    """
    return sorted(values, reverse=True)

