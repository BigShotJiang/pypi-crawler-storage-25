"""Spatial visualization starter."""


def spot_colors(values: list[float]) -> list[str]:
    """Map values to two-color palette.

    Args:
        values: Numeric values.

    Returns:
        Color labels.
    """
    return ["red" if v > 0.5 else "blue" for v in values]

