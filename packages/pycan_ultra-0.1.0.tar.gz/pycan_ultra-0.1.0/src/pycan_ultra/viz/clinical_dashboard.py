"""Clinical dashboard starter data model."""


def dashboard_payload(patient_id: str) -> dict[str, str]:
    """Build basic dashboard payload.

    Args:
        patient_id: Patient identifier.

    Returns:
        Dashboard payload.
    """
    return {"patient_id": patient_id, "view": "overview"}

