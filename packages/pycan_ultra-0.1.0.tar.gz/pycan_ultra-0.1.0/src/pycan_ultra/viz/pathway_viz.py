"""Pathway visualization starter."""


def bubble_sizes(enrichment_scores: list[float]) -> list[float]:
    """Convert enrichment scores to bubble sizes.

    Args:
        enrichment_scores: Scores.

    Returns:
        Positive sizes.
    """
    return [abs(s) * 10 for s in enrichment_scores]

