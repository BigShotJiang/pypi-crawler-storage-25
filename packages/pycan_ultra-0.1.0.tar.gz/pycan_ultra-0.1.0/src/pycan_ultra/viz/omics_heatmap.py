"""Omics heatmap starter."""


def zscore_row(row: list[float]) -> list[float]:
    """Z-score one row.

    Args:
        row: Numeric row.

    Returns:
        Standardized row.
    """
    if not row:
        return []
    mean = sum(row) / len(row)
    var = sum((x - mean) ** 2 for x in row) / len(row)
    std = var ** 0.5
    if std == 0:
        return [0.0 for _ in row]
    return [(x - mean) / std for x in row]

