"""Survival visualization starter."""


def km_points(times: list[float]) -> list[tuple[float, float]]:
    """Create simple KM-like staircase points.

    Args:
        times: Event times.

    Returns:
        Time-survival coordinate pairs.
    """
    if not times:
        return [(0.0, 1.0)]
    ordered = sorted(times)
    n = len(ordered)
    return [(t, max(0.0, 1.0 - (i + 1) / n)) for i, t in enumerate(ordered)]

