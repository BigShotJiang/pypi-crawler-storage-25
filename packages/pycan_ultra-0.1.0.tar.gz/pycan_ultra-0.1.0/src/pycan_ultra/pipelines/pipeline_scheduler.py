"""Pipeline scheduling helpers."""

import asyncio
from collections.abc import Awaitable, Callable


async def schedule(job: Callable[[], Awaitable[object]]) -> object:
    """Schedule one async job and return result.

    Args:
        job: Async job callable.

    Returns:
        Job result.
    """
    return await asyncio.create_task(job())

