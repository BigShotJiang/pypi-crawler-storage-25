"""Drug repurposing pipeline."""


def run_repurposing(signature: list[str]) -> list[str]:
    """Return ranked repurposing candidates.

    Args:
        signature: Gene signature.

    Returns:
        Candidate drugs.
    """
    if not signature:
        return []
    return ["Metformin", "Sirolimus", "Aspirin"]

