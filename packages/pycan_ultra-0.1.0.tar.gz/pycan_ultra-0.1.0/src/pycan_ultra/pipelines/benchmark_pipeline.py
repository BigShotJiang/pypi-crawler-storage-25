"""Benchmark automation pipeline."""


def run_benchmark(model_name: str) -> dict[str, object]:
    """Benchmark one model against baseline.

    Args:
        model_name: Model identifier.

    Returns:
        Benchmark payload.
    """
    return {"model": model_name, "c_index": 0.61, "baseline_c_index": 0.58}

