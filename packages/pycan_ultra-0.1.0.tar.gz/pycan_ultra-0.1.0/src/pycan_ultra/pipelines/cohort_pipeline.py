"""Cohort-level analysis pipeline."""


def run_cohort(cohort_name: str, n_samples: int) -> dict[str, object]:
    """Run cohort analysis.

    Args:
        cohort_name: Cohort label.
        n_samples: Number of samples.

    Returns:
        Analysis summary.
    """
    return {"cohort": cohort_name, "samples": n_samples, "subtypes": max(2, n_samples // 50)}

