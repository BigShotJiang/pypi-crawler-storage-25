"""Longitudinal omics pipeline."""


def run_longitudinal(timepoints: int) -> dict[str, float]:
    """Run simple resistance forecast.

    Args:
        timepoints: Number of serial measurements.

    Returns:
        Forecast summary.
    """
    return {"timepoints": float(timepoints), "resistance_risk": min(1.0, timepoints / 10)}

