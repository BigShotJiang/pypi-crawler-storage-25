"""Clinical NGS interpretation pipeline."""


def run_clinical_ngs(sample_id: str) -> dict[str, object]:
    """Run clinical NGS processing summary.

    Args:
        sample_id: Sample identifier.

    Returns:
        Result payload.
    """
    return {"sample_id": sample_id, "variants_detected": 0, "report_ready": True}

