"""Spatial transcriptomics pipeline."""


def run_spatial(spots: int) -> dict[str, int]:
    """Run spatial pipeline.

    Args:
        spots: Number of spots.

    Returns:
        Atlas summary.
    """
    return {"spots": spots, "neighborhoods": max(1, spots // 50)}

