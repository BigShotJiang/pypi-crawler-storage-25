"""Pipeline subsystem exports."""

from pycan_ultra.pipelines.discovery_pipeline import run_discovery

__all__ = ["run_discovery"]

