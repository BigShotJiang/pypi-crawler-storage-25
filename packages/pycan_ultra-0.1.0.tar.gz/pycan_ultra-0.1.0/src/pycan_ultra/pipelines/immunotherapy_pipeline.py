"""Immunotherapy biomarker pipeline."""


def run_immunotherapy(tmb: float, msi: float, til: float, hla: float) -> str:
    """Classify IO response with a simple score.

    Args:
        tmb: TMB score.
        msi: MSI score.
        til: TIL score.
        hla: HLA integrity score.

    Returns:
        Response class.
    """
    score = 0.25 * (tmb + msi + til + hla)
    return "responder" if score >= 0.5 else "non_responder"

