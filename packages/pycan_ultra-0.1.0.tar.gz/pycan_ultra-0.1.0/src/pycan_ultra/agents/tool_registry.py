"""Tool registration for agent tool-call interoperability."""

from dataclasses import dataclass
from typing import Any, Callable


@dataclass(slots=True)
class ToolSpec:
    """Registered callable tool specification."""

    name: str
    handler: Callable[..., Any]
    description: str


class ToolRegistry:
    """In-memory registry of callable tools."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}

    def register(self, spec: ToolSpec) -> None:
        """Register a new tool specification.

        Args:
            spec: Tool definition.
        """
        self._tools[spec.name] = spec

    def call(self, name: str, **kwargs: Any) -> Any:
        """Invoke a registered tool.

        Args:
            name: Tool name.
            **kwargs: Tool arguments.

        Returns:
            Tool return value.
        """
        return self._tools[name].handler(**kwargs)

