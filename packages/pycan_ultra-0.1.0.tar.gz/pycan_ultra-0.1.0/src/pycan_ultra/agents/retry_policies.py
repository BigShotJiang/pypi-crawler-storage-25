"""Retry policy helpers for agent reflection loops."""


def bounded_retries(requested: int) -> int:
    """Clamp retries to policy maximum of three.

    Args:
        requested: Requested retry count.

    Returns:
        Policy-compliant retry count.
    """
    return max(0, min(3, requested))

