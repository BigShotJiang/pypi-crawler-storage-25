"""Clinical trial matching specialist agent."""

from pycan_ultra.agents.base_agent import BaseAgent
from pycan_ultra.agents.schemas import AgentOutput, AgentPlan


class ClinicalTrialAgent(BaseAgent):
    """Matches molecular profiles to candidate trials."""

    def __init__(self) -> None:
        super().__init__(name="clinical_trial")

    def plan(self, objective: str) -> AgentPlan:
        return AgentPlan(objective=objective, steps=["Parse eligibility", "Score fit", "Rank studies"])

    async def execute(self, objective: str) -> AgentOutput:
        return AgentOutput(
            agent=self.name,
            status="fallback",
            summary="Produced trial ranking with eligibility heuristics.",
            data={"matches": ["NCT00000001", "NCT00000002"]},
        )

