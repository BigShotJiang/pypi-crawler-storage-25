"""Transcriptomics specialist agent."""

from pycan_ultra.agents.base_agent import BaseAgent
from pycan_ultra.agents.schemas import AgentOutput, AgentPlan


class TranscriptomicsAgent(BaseAgent):
    """Performs RNA-level differential and pathway analysis orchestration."""

    def __init__(self) -> None:
        super().__init__(name="transcriptomics")

    def plan(self, objective: str) -> AgentPlan:
        return AgentPlan(
            objective=objective,
            steps=["Normalize counts", "Compute differential signals", "Run pathway scoring"],
        )

    async def execute(self, objective: str) -> AgentOutput:
        return AgentOutput(
            agent=self.name,
            status="fallback",
            summary="Offline RNA workflow prepared for execution.",
            data={"objective": objective},
        )

