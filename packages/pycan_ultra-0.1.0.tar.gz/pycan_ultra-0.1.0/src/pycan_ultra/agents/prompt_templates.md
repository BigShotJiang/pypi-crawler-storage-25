# Prompt Templates

- Objective summary template for compressed context.
- Tool-call template for structured function invocation.
- Reflection critique template with retry budget awareness.

