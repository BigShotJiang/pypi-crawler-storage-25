"""Master orchestrator agent for multi-agent workflow planning."""

from pycan_ultra.agents.base_agent import BaseAgent
from pycan_ultra.agents.schemas import AgentOutput, AgentPlan


class OrchestratorAgent(BaseAgent):
    """Coordinates specialist agents from one objective."""

    def __init__(self) -> None:
        super().__init__(name="orchestrator")

    def plan(self, objective: str) -> AgentPlan:
        """Create a deterministic workflow plan.

        Args:
            objective: User research objective.

        Returns:
            Structured plan for specialist routing.
        """
        steps = [
            "Parse objective and infer modalities",
            "Dispatch tasks to genomics/transcriptomics/survival agents",
            "Aggregate evidence and rank findings",
            "Generate final summary report payload",
        ]
        return AgentPlan(objective=objective, steps=steps)

    async def execute(self, objective: str) -> AgentOutput:
        """Execute orchestration using rule-based offline fallback.

        Args:
            objective: User request.

        Returns:
            Agent output.
        """
        plan = self.plan(objective)
        self.stream_thoughts(f"Plan created with {len(plan.steps)} steps")
        return AgentOutput(
            agent=self.name,
            status="fallback",
            summary="Offline orchestrator produced deterministic execution plan.",
            data={"steps": plan.steps, "objective": objective},
        )

