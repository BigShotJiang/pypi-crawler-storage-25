"""Survival modelling specialist agent."""

from pycan_ultra.agents.base_agent import BaseAgent
from pycan_ultra.agents.schemas import AgentOutput, AgentPlan


class SurvivalAgent(BaseAgent):
    """Selects survival modelling strategy and summaries."""

    def __init__(self) -> None:
        super().__init__(name="survival")

    def plan(self, objective: str) -> AgentPlan:
        return AgentPlan(objective=objective, steps=["Check censoring", "Fit baseline", "Compare models"])

    async def execute(self, objective: str) -> AgentOutput:
        return AgentOutput(
            agent=self.name,
            status="fallback",
            summary="Built offline survival analysis recommendation.",
            data={"suggested_model": "cox_ph"},
        )

