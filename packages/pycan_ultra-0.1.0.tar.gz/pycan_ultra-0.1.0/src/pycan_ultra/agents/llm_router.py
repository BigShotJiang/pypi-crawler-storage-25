"""Provider routing with offline fallback policy."""

from pycan_ultra.core.config import get_settings


def choose_provider() -> str:
    """Choose configured provider with offline-safe fallback.

    Returns:
        Provider identifier.
    """
    provider = get_settings().llm_provider.lower().strip()
    return provider if provider else "offline"

