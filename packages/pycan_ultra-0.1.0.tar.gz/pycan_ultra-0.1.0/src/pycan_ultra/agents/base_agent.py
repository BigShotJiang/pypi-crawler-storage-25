"""Abstract base implementation for all pycan_ultra agents."""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from pycan_ultra.agents.schemas import AgentCritique, AgentOutput, AgentPlan
from pycan_ultra.core.logger import get_logger
from pycan_ultra.utils.text_utils import compress_text


@dataclass(slots=True)
class AgentState:
    """In-memory agent state container."""

    thought_stream: list[str] = field(default_factory=list)
    updated_at: datetime = field(default_factory=datetime.utcnow)


class BaseAgent(ABC):
    """Base class defining the common agent protocol."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.state = AgentState()
        self.logger = get_logger(agent=name)

    @abstractmethod
    def plan(self, objective: str) -> AgentPlan:
        """Build a structured plan for execution.

        Args:
            objective: Natural language objective.

        Returns:
            Structured plan.
        """

    @abstractmethod
    async def execute(self, objective: str) -> AgentOutput:
        """Execute agent logic asynchronously.

        Args:
            objective: Natural language objective.

        Returns:
            Structured output payload.
        """

    def reflect(self, output: AgentOutput) -> AgentCritique:
        """Critique output quality for retry decisions.

        Args:
            output: Agent output to review.

        Returns:
            Critique object.
        """
        approved = output.status in {"success", "fallback"} and len(output.summary) > 10
        reason = "Output accepted" if approved else "Insufficient output quality"
        return AgentCritique(approved=approved, reason=reason)

    async def run_with_reflection(self, objective: str, retries: int = 3) -> AgentOutput:
        """Execute with reflection-based retry loop.

        Args:
            objective: Objective text.
            retries: Maximum retries.

        Returns:
            Final agent output.
        """
        last: AgentOutput | None = None
        for attempt in range(1, retries + 1):
            result = await self.execute(objective)
            critique = self.reflect(result)
            self.stream_thoughts(f"Attempt {attempt}: {critique.reason}")
            last = result
            if critique.approved:
                return result
            await asyncio.sleep(0.1)
        assert last is not None
        return last

    def stream_thoughts(self, thought: str) -> None:
        """Append compressed reasoning trace for observability.

        Args:
            thought: Agent thought text.
        """
        compressed = compress_text(thought, max_chars=220)
        self.state.thought_stream.append(compressed)
        self.state.updated_at = datetime.utcnow()
        self.logger.info("agent_thought", thought=compressed)

    def tool_call(self, tool_name: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Tool-call interface compatible with function-style invocation.

        Args:
            tool_name: Logical tool identifier.
            payload: Serialized arguments.

        Returns:
            Standardized invocation envelope.
        """
        self.logger.info("tool_call", tool=tool_name)
        return {"tool": tool_name, "arguments": payload, "agent": self.name}

    def save_state(self) -> dict[str, Any]:
        """Serialize current runtime state.

        Returns:
            JSON-serializable state dictionary.
        """
        return {
            "name": self.name,
            "thought_stream": list(self.state.thought_stream),
            "updated_at": self.state.updated_at.isoformat(),
        }

