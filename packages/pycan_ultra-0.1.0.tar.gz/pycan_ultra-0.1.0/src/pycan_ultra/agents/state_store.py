"""Simple JSON state persistence for agents."""

import json
from pathlib import Path
from typing import Any


def save_agent_state(path: Path, payload: dict[str, Any]) -> None:
    """Persist agent state to disk.

    Args:
        path: File destination.
        payload: State dictionary.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def load_agent_state(path: Path) -> dict[str, Any]:
    """Load previously persisted agent state.

    Args:
        path: State file path.

    Returns:
        Parsed state dictionary.
    """
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))

