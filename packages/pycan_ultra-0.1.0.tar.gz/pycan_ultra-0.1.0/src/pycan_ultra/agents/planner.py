"""Planning utilities for orchestrating multi-agent workflows."""

from pycan_ultra.agents.schemas import AgentPlan


def build_plan(objective: str) -> AgentPlan:
    """Build a generic execution plan from objective text.

    Args:
        objective: Workflow objective.

    Returns:
        Structured plan.
    """
    steps = ["Understand objective", "Route specialists", "Aggregate and report"]
    return AgentPlan(objective=objective, steps=steps)

