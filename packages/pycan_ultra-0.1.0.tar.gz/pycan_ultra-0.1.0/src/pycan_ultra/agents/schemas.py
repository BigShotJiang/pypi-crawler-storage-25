"""Pydantic schemas for agent inputs and outputs."""

from pydantic import BaseModel, Field


class AgentPlan(BaseModel):
    """Execution plan structure."""

    objective: str = Field(min_length=3)
    steps: list[str] = Field(default_factory=list)


class AgentCritique(BaseModel):
    """Reflection critique payload."""

    approved: bool
    reason: str


class AgentOutput(BaseModel):
    """Structured output from agents."""

    agent: str
    status: str
    summary: str
    data: dict[str, str | int | float | bool | list[str]] = Field(default_factory=dict)

