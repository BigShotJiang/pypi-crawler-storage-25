"""CLI package for pycan_ultra."""

