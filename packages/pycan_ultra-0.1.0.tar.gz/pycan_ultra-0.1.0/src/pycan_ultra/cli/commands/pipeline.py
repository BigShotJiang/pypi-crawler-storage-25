"""Pipeline command implementation."""

import typer


def pipeline_command(run: str, config: str = "pipeline.yaml") -> None:
    """Run a named pipeline with a configuration file.

    Args:
        run: Pipeline name.
        config: Pipeline config path.
    """
    typer.echo(f"Running pipeline={run} with config={config}")

