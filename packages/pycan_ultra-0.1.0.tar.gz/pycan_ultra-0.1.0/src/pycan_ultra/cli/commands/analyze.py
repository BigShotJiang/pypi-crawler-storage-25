"""Analyze command implementation."""

from pathlib import Path

import typer


def analyze_command(patient: Path, rna: Path) -> None:
    """Run patient analysis workflow from input files.

    Args:
        patient: Path to patient VCF file.
        rna: Path to RNA count matrix file.
    """
    typer.echo(f"Analyzing patient data: vcf={patient} rna={rna}")

