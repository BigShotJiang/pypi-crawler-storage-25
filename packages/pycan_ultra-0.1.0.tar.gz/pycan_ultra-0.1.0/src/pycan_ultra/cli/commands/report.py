"""Report command implementation."""

import typer


def report_command(patient_id: str) -> None:
    """Generate a report for one patient identifier.

    Args:
        patient_id: Internal patient ID.
    """
    typer.echo(f"Generating report for patient={patient_id}")

