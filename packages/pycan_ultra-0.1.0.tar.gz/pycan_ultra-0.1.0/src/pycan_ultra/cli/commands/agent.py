"""Agent command implementation."""

import typer


def agent_command(query: str) -> None:
    """Run a natural-language request through the orchestrator.

    Args:
        query: User objective for autonomous analysis.
    """
    typer.echo(f"Executing agent query: {query}")

