"""Discover command implementation."""

import typer


def discover_command(cancer: str, omics: str = "tcga") -> None:
    """Run autonomous discovery workflow.

    Args:
        cancer: Cancer type identifier.
        omics: Omics source identifier.
    """
    typer.echo(f"Running discovery: cancer={cancer} omics={omics}")

