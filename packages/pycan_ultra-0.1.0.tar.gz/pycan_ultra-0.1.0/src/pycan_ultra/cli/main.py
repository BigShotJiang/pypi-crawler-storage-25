"""Typer CLI entrypoint for pycan_ultra."""

import typer

from pycan_ultra.cli.commands.agent import agent_command
from pycan_ultra.cli.commands.analyze import analyze_command
from pycan_ultra.cli.commands.discover import discover_command
from pycan_ultra.cli.commands.pipeline import pipeline_command
from pycan_ultra.cli.commands.report import report_command

app = typer.Typer(help="pycan_ultra CLI")
app.command("analyze")(analyze_command)
app.command("discover")(discover_command)
app.command("report")(report_command)
app.command("agent")(agent_command)
app.command("pipeline")(pipeline_command)


if __name__ == "__main__":
    app()

