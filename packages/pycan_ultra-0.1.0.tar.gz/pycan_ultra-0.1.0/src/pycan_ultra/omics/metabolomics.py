"""Metabolomics pathway mapping starter utilities."""


def metabolic_signature_score(features: list[float]) -> float:
    """Compute a simple metabolic signature score.

    Args:
        features: Metabolite feature vector.

    Returns:
        Mean feature intensity.
    """
    if not features:
        return 0.0
    return sum(features) / len(features)

