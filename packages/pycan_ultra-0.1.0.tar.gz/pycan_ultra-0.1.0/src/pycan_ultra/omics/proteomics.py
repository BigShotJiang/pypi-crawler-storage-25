"""Proteomics normalization starter utilities."""


def normalize_abundance(values: list[float]) -> list[float]:
    """Min-max normalize abundance values.

    Args:
        values: Raw abundances.

    Returns:
        Normalized values in [0, 1].
    """
    if not values:
        return []
    low, high = min(values), max(values)
    if high == low:
        return [0.0 for _ in values]
    return [(v - low) / (high - low) for v in values]

