"""GEO/SRA loader with assay auto-detection."""

from dataclasses import dataclass


@dataclass(slots=True)
class GEODataset:
    """Container for GEO study info."""

    accession: str
    assay: str


def detect_assay(accession: str) -> GEODataset:
    """Detect assay type from accession prefix heuristics.

    Args:
        accession: GEO accession.

    Returns:
        Typed GEO dataset descriptor.
    """
    assay = "rna_seq" if accession.upper().startswith("GSE") else "unknown"
    return GEODataset(accession=accession, assay=assay)

