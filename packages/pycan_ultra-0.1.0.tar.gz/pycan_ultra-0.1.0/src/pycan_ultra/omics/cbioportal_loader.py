"""cBioPortal API wrapper starter implementation."""

from dataclasses import dataclass


@dataclass(slots=True)
class StudySummary:
    """Study summary from cBioPortal."""

    study_id: str
    sample_count: int


def list_studies() -> list[StudySummary]:
    """List studies via offline-safe fallback.

    Returns:
        Study summaries.
    """
    return []

