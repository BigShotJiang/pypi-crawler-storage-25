"""TCGA data loader with resumable local caching."""

from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class TCGADataset:
    """Container for TCGA cohort metadata."""

    cancer_type: str
    samples: int
    cache_path: Path


def load_tcga(cancer_type: str, cache_dir: Path) -> TCGADataset:
    """Load TCGA metadata for one cancer type.

    Args:
        cancer_type: TCGA disease code.
        cache_dir: Cache directory path.

    Returns:
        Typed dataset metadata.
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    return TCGADataset(cancer_type=cancer_type, samples=0, cache_path=cache_dir)

