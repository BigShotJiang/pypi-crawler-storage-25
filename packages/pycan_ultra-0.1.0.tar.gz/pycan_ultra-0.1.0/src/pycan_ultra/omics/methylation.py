"""Methylation processing and DMR scoring starter."""


def dmr_score(beta_case: float, beta_ctrl: float) -> float:
    """Compute a simple delta-beta DMR score.

    Args:
        beta_case: Case beta value.
        beta_ctrl: Control beta value.

    Returns:
        Absolute difference score.
    """
    return abs(beta_case - beta_ctrl)

