"""Custom single-cell analysis engine starter."""

from dataclasses import dataclass


@dataclass(slots=True)
class SingleCellResult:
    """Single-cell pipeline result summary."""

    n_cells: int
    n_clusters: int


def run_single_cell_pipeline(n_cells: int) -> SingleCellResult:
    """Run a simplified single-cell workflow.

    Args:
        n_cells: Number of cells.

    Returns:
        Pipeline summary.
    """
    clusters = max(1, n_cells // 1000)
    return SingleCellResult(n_cells=n_cells, n_clusters=clusters)

