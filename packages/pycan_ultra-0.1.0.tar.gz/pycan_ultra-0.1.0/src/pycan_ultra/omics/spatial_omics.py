"""Spatial omics parsing and neighborhood scoring starter."""

from dataclasses import dataclass


@dataclass(slots=True)
class SpatialSummary:
    """Spatial dataset summary."""

    spots: int
    neighborhoods: int


def summarize_spatial(spots: int) -> SpatialSummary:
    """Summarize spatial transcriptomics scale.

    Args:
        spots: Number of spatial spots.

    Returns:
        Spatial summary.
    """
    return SpatialSummary(spots=spots, neighborhoods=max(1, spots // 50))

