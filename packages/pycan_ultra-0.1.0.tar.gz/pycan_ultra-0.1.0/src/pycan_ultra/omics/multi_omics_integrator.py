"""Multi-omics integration starter."""


def integrate_modalities(modalities: dict[str, int]) -> dict[str, float]:
    """Integrate modality counts into normalized weights.

    Args:
        modalities: Modality-to-feature count mapping.

    Returns:
        Normalized modality weights.
    """
    total = sum(modalities.values())
    if total <= 0:
        return {k: 0.0 for k in modalities}
    return {k: v / total for k, v in modalities.items()}

