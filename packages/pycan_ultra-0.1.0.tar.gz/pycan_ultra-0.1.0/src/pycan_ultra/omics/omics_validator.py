"""Data quality validator for multi-omics inputs."""


def validate_modalities(modalities: dict[str, int]) -> list[str]:
    """Validate modality availability and non-empty payloads.

    Args:
        modalities: Modality counts.

    Returns:
        Validation issues list.
    """
    issues: list[str] = []
    if not modalities:
        issues.append("No modalities provided")
    for name, count in modalities.items():
        if count <= 0:
            issues.append(f"{name} has no features")
    return issues

