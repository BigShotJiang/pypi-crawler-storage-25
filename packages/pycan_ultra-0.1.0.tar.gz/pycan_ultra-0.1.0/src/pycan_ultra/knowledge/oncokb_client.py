"""OncoKB client starter."""


def actionability_level(variant: str) -> str:
    """Return heuristic OncoKB-like actionability level.

    Args:
        variant: Variant identifier.

    Returns:
        Level label.
    """
    return "LEVEL_1" if "EGFR" in variant.upper() else "LEVEL_4"

