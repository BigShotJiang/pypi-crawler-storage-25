"""Unified drug database starter."""


def drugs_for_target(target: str) -> list[str]:
    """Return simple target-to-drug mapping.

    Args:
        target: Gene target.

    Returns:
        Drug names.
    """
    mapping = {"EGFR": ["Erlotinib", "Gefitinib"], "BRAF": ["Vemurafenib"]}
    return mapping.get(target.upper(), [])

