"""Pathway database starter."""


def pathways_for_gene(gene: str) -> list[str]:
    """Return compact gene-pathway mapping.

    Args:
        gene: Gene symbol.

    Returns:
        Pathway labels.
    """
    return [f"{gene.upper()}_PATHWAY"]

