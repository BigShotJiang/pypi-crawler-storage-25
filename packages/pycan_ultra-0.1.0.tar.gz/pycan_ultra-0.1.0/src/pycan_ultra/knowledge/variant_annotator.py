"""Variant annotator starter."""


def annotate_variant(hgvs: str) -> dict[str, str]:
    """Annotate variant with minimal fields.

    Args:
        hgvs: HGVS string.

    Returns:
        Annotation payload.
    """
    return {"hgvs": hgvs, "impact": "moderate", "hotspot": "no"}

