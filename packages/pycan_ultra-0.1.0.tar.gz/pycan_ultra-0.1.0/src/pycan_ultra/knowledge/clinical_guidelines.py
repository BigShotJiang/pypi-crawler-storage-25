"""Clinical guideline engine starter."""


def recommend(cancer_type: str, stage: str, biomarker: str) -> str:
    """Return compact treatment guidance.

    Args:
        cancer_type: Cancer type.
        stage: Stage label.
        biomarker: Biomarker symbol.

    Returns:
        Guidance summary.
    """
    return f"Guideline suggestion for {cancer_type} {stage} with {biomarker}"

