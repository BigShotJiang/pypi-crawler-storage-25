"""PubMed RAG starter."""


def answer_with_citations(query: str) -> dict[str, object]:
    """Produce compact answer and citations.

    Args:
        query: User query.

    Returns:
        RAG response.
    """
    return {"answer": f"Summary for: {query}", "citations": ["PMID:000000"]}

