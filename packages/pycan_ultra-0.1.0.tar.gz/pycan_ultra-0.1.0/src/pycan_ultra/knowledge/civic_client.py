"""CIViC client starter."""


def civic_evidence(variant: str) -> list[str]:
    """Return mock evidence statements.

    Args:
        variant: Variant identifier.

    Returns:
        Evidence list.
    """
    return [f"Evidence for {variant}"]

