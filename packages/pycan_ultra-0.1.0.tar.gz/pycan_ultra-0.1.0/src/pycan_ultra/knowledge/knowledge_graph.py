"""Knowledge graph starter utilities."""


def edge(gene: str, drug: str) -> tuple[str, str, str]:
    """Create a typed edge tuple.

    Args:
        gene: Gene node.
        drug: Drug node.

    Returns:
        Edge tuple.
    """
    return gene, "targets", drug

