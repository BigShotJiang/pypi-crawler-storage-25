"""Evidence ranking starter."""


def rank_evidence(items: list[tuple[str, str]]) -> list[tuple[str, str]]:
    """Rank evidence by tier priority.

    Args:
        items: List of (evidence, tier).

    Returns:
        Sorted evidence.
    """
    priority = {"FDA": 0, "PHASE3": 1, "PHASE2": 2, "PRECLINICAL": 3}
    return sorted(items, key=lambda x: priority.get(x[1].upper(), 99))

