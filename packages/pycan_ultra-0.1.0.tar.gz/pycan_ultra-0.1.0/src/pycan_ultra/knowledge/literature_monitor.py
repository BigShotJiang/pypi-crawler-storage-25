"""Literature monitoring starter."""


def summarize_new_papers(topic: str) -> str:
    """Return compact daily literature digest.

    Args:
        topic: Topic of interest.

    Returns:
        Digest text.
    """
    return f"No critical new findings today for topic: {topic}."

