"""Precision report assembly starter module."""


def build_precision_summary(patient_id: str, findings: list[str]) -> str:
    """Build a compact patient precision summary.

    Args:
        patient_id: Patient identifier.
        findings: Key findings.

    Returns:
        Markdown summary.
    """
    bullet = "\n".join(f"- {item}" for item in findings)
    return f"# Precision Summary: {patient_id}\n{bullet}"

