"""Pathway rewiring starter analytics."""


def pathway_activity(delta_expr: dict[str, float]) -> float:
    """Aggregate pathway activity from gene deltas.

    Args:
        delta_expr: Gene expression deltas.

    Returns:
        Mean absolute activity.
    """
    if not delta_expr:
        return 0.0
    vals = [abs(v) for v in delta_expr.values()]
    return sum(vals) / len(vals)

