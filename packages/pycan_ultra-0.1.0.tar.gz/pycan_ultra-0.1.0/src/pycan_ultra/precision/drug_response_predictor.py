"""Drug response prediction starter module."""


def rank_drugs(ic50: dict[str, float]) -> list[tuple[str, float]]:
    """Rank drugs by ascending predicted IC50.

    Args:
        ic50: Drug-to-IC50 map.

    Returns:
        Sorted candidate list.
    """
    return sorted(ic50.items(), key=lambda x: x[1])

