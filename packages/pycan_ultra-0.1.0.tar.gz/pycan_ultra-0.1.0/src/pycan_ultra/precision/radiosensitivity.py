"""Radiosensitivity index starter utilities."""


def radiosensitivity_index(genes: list[float]) -> float:
    """Compute basic radiosensitivity index.

    Args:
        genes: Gene feature values.

    Returns:
        Mean value as baseline index.
    """
    if not genes:
        return 0.0
    return sum(genes) / len(genes)

