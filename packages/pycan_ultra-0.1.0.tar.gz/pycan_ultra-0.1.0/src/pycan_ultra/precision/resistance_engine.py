"""Resistance mechanism starter module."""


def infer_resistance(drivers: list[str]) -> list[str]:
    """Infer candidate resistance pathways from drivers.

    Args:
        drivers: Driver genes.

    Returns:
        Candidate mechanism labels.
    """
    return [f"{gene}_bypass_pathway" for gene in drivers]

