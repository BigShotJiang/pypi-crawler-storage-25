"""Immunotherapy response scoring starter."""


def io_composite_score(tmb_value: float, msi: float, til: float, pdl1: float) -> float:
    """Compute composite immunotherapy response score.

    Args:
        tmb_value: Tumor mutational burden.
        msi: MSI score.
        til: TIL score.
        pdl1: PD-L1 score.

    Returns:
        Composite score in [0, 1] range approximation.
    """
    raw = 0.25 * tmb_value + 0.25 * msi + 0.25 * til + 0.25 * pdl1
    return max(0.0, min(1.0, raw))

