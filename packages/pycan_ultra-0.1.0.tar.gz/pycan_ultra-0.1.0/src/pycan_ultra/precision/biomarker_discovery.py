"""Biomarker discovery starter module."""


def rank_biomarkers(scores: dict[str, float], top_k: int = 10) -> list[tuple[str, float]]:
    """Rank biomarkers by descending score.

    Args:
        scores: Gene-to-score mapping.
        top_k: Number of top biomarkers.

    Returns:
        Sorted biomarker ranking.
    """
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]

