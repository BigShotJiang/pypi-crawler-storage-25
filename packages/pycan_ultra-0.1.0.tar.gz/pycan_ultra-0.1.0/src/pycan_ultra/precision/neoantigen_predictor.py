"""Neoantigen ranking starter logic."""


def rank_peptides(peptides: dict[str, float]) -> list[str]:
    """Rank peptides by binding affinity proxy score.

    Args:
        peptides: Peptide-to-score mapping.

    Returns:
        Ranked peptide IDs.
    """
    return [p for p, _ in sorted(peptides.items(), key=lambda x: x[1], reverse=True)]

