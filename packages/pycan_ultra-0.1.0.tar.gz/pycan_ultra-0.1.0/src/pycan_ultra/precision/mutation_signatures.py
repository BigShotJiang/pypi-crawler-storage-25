"""Mutation signature utilities starter."""


def tmb(mutations: int, covered_mb: float) -> float:
    """Compute tumor mutational burden.

    Args:
        mutations: Total mutations.
        covered_mb: Covered megabases.

    Returns:
        Mutations per megabase.
    """
    if covered_mb <= 0:
        return 0.0
    return mutations / covered_mb

