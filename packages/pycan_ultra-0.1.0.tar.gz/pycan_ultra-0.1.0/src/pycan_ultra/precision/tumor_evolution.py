"""Tumor evolution starter metrics."""


def ith_score(clones: list[float]) -> float:
    """Compute simple intra-tumor heterogeneity score.

    Args:
        clones: Clone prevalence fractions.

    Returns:
        Heterogeneity score.
    """
    return 1.0 - max(clones) if clones else 0.0

