"""Explainability starter interfaces."""


def explanation_card(model_name: str, top_features: list[str]) -> str:
    """Build compact explanation card text.

    Args:
        model_name: Name of model.
        top_features: Most influential features.

    Returns:
        Markdown explanation card.
    """
    feats = ", ".join(top_features)
    return f"Model: {model_name}\nTop features: {feats}"

