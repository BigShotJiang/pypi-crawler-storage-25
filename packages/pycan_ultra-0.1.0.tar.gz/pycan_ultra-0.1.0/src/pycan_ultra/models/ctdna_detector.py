"""ctDNA early detection starter scoring."""


def ctdna_risk(fragment_signal: list[float]) -> float:
    """Compute baseline ctDNA risk score.

    Args:
        fragment_signal: Fragment profile values.

    Returns:
        Risk score.
    """
    if not fragment_signal:
        return 0.0
    return max(fragment_signal)

