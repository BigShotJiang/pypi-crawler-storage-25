"""Graph neural network starter ranking helpers."""


def rank_nodes(node_scores: dict[str, float]) -> list[str]:
    """Rank graph nodes by descending score.

    Args:
        node_scores: Node score mapping.

    Returns:
        Sorted node identifiers.
    """
    return [n for n, _ in sorted(node_scores.items(), key=lambda x: x[1], reverse=True)]

