"""Survival transformer starter utilities."""


def survival_risk(features: list[float]) -> float:
    """Compute baseline survival risk score.

    Args:
        features: Feature vector.

    Returns:
        Risk score.
    """
    if not features:
        return 0.0
    return sum(features) / len(features)

