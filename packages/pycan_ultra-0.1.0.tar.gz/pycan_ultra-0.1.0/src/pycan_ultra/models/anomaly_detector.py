"""Anomaly detector starter module."""


def reconstruction_error(x: list[float], x_hat: list[float]) -> float:
    """Compute mean squared reconstruction error.

    Args:
        x: Original vector.
        x_hat: Reconstructed vector.

    Returns:
        Mean squared error.
    """
    if not x or len(x) != len(x_hat):
        return 0.0
    return sum((a - b) ** 2 for a, b in zip(x, x_hat, strict=True)) / len(x)

