"""Pathology CNN starter interfaces."""


def classify_tile(probabilities: list[float]) -> int:
    """Return argmax class index for one tile.

    Args:
        probabilities: Class probabilities.

    Returns:
        Predicted class index.
    """
    return int(max(range(len(probabilities)), key=lambda i: probabilities[i])) if probabilities else 0

