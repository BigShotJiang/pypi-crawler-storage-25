"""Foundation model adapter starter interfaces."""


def lora_budget_ok(vram_gb: float, target_hours: float = 1.0) -> bool:
    """Check if fine-tuning budget target is plausible.

    Args:
        vram_gb: Available VRAM.
        target_hours: Target wall time.

    Returns:
        Feasibility boolean.
    """
    return vram_gb >= 8.0 and target_hours <= 1.5

