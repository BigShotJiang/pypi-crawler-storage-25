"""Model registry starter abstraction."""

from dataclasses import dataclass


@dataclass(slots=True)
class ModelRecord:
    """Registered model metadata."""

    name: str
    version: str
    stage: str


def register_model(name: str, version: str, stage: str = "staging") -> ModelRecord:
    """Create model registry record.

    Args:
        name: Model name.
        version: Model version.
        stage: Deployment stage.

    Returns:
        Model record.
    """
    return ModelRecord(name=name, version=version, stage=stage)

