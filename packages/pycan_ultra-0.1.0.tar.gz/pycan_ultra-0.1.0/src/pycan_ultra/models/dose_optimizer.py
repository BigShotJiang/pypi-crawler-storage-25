"""Dose optimization starter utilities."""


def reward(pfs_gain: float, toxicity: float) -> float:
    """Compute treatment reward objective.

    Args:
        pfs_gain: Progression-free survival gain.
        toxicity: Toxicity penalty.

    Returns:
        Reward value.
    """
    return pfs_gain - toxicity

