"""Multimodal fusion starter scoring."""


def fuse_scores(genomics: float, pathology: float, clinical: float) -> float:
    """Fuse modality scores into one risk estimate.

    Args:
        genomics: Genomic score.
        pathology: Pathology score.
        clinical: Clinical score.

    Returns:
        Fused score.
    """
    return (genomics + pathology + clinical) / 3.0

