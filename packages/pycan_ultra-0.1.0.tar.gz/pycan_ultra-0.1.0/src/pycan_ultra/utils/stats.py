"""Statistical helper functions used across modules."""

import math


def benjamini_hochberg(p_values: list[float]) -> list[float]:
    """Adjust p-values using Benjamini-Hochberg FDR control.

    Args:
        p_values: Raw p-values.

    Returns:
        FDR-adjusted q-values.
    """
    n = len(p_values)
    if n == 0:
        return []
    indexed = sorted(enumerate(p_values), key=lambda x: x[1])
    adjusted = [1.0] * n
    prev = 1.0
    for rank, (idx, p_val) in enumerate(reversed(indexed), start=1):
        k = n - rank + 1
        q = min(prev, p_val * n / k)
        adjusted[idx] = min(1.0, max(0.0, q))
        prev = q
    return adjusted


def mean(values: list[float]) -> float:
    """Compute arithmetic mean.

    Args:
        values: Numeric values.

    Returns:
        Mean value.
    """
    if not values:
        return math.nan
    return sum(values) / len(values)

