"""Stable hashing utilities for content-addressed artifacts."""

import hashlib


def sha256_text(text: str) -> str:
    """Compute SHA-256 digest for text.

    Args:
        text: Input text to hash.

    Returns:
        Hex digest string.
    """
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

