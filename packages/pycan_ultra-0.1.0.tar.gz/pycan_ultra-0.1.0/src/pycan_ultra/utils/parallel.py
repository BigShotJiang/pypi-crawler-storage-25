"""Parallel execution helpers."""

from concurrent.futures import ThreadPoolExecutor
from typing import Callable, Iterable, TypeVar

T = TypeVar("T")
R = TypeVar("R")


def thread_map(func: Callable[[T], R], items: Iterable[T], max_workers: int = 4) -> list[R]:
    """Map function over items in a thread pool.

    Args:
        func: Callable to apply.
        items: Items to process.
        max_workers: Thread pool size.

    Returns:
        Ordered list of results.
    """
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        return list(executor.map(func, items))

