"""Asynchronous utility functions and decorators."""

import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar

T = TypeVar("T")


async def async_retry(
    func: Callable[[], Awaitable[T]],
    retries: int = 3,
    delay_seconds: float = 0.3,
) -> T:
    """Run async callable with retry policy.

    Args:
        func: Zero-argument async callable.
        retries: Maximum retry attempts.
        delay_seconds: Delay between attempts.

    Returns:
        Callable result.

    Raises:
        Exception: Re-raises last exception when retries exhausted.
    """
    last_exc: Exception | None = None
    for attempt in range(retries + 1):
        try:
            return await func()
        except Exception as exc:  # noqa: BLE001
            last_exc = exc
            if attempt == retries:
                break
            await asyncio.sleep(delay_seconds)
    assert last_exc is not None
    raise last_exc

