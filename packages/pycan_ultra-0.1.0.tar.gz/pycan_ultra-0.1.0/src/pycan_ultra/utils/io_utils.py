"""Safe file I/O utilities."""

from pathlib import Path


def write_text_atomic(path: Path, data: str) -> None:
    """Write text atomically via temporary file replacement.

    Args:
        path: Destination path.
        data: Text payload.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(data, encoding="utf-8")
    tmp.replace(path)

