"""Core bioinformatics utility functions."""


def gc_content(sequence: str) -> float:
    """Compute GC fraction of a nucleotide sequence.

    Args:
        sequence: DNA sequence.

    Returns:
        GC fraction between 0 and 1.
    """
    seq = sequence.upper().replace("\n", "")
    if not seq:
        return 0.0
    gc = sum(1 for base in seq if base in {"G", "C"})
    return gc / len(seq)

