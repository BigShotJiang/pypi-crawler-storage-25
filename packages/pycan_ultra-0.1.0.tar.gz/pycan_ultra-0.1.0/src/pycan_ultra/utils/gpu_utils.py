"""GPU discovery helpers with safe fallback behavior."""

from dataclasses import dataclass


@dataclass(slots=True)
class GPUInfo:
    """GPU capability snapshot."""

    available: bool
    device_name: str


def detect_gpu() -> GPUInfo:
    """Detect GPU availability using optional torch import.

    Returns:
        Detected GPU information.
    """
    try:
        import torch

        if torch.cuda.is_available():
            name = torch.cuda.get_device_name(0)
            return GPUInfo(available=True, device_name=name)
    except Exception:
        return GPUInfo(available=False, device_name="cpu")
    return GPUInfo(available=False, device_name="cpu")

