"""Validation helpers for repeated checks."""


def require_non_empty(value: str, name: str) -> str:
    """Ensure a string value is non-empty after trimming.

    Args:
        value: Candidate string.
        name: Field name for error messages.

    Returns:
        Stripped string value.

    Raises:
        ValueError: If value is empty.
    """
    stripped = value.strip()
    if not stripped:
        raise ValueError(f"{name} must not be empty")
    return stripped

