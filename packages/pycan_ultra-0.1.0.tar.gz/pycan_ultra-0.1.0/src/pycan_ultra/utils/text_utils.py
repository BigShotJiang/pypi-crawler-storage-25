"""Text utilities for prompt and report processing."""


def compress_text(text: str, max_chars: int = 2000) -> str:
    """Compress text by truncating while preserving head and tail.

    Args:
        text: Input text.
        max_chars: Maximum output characters.

    Returns:
        Compressed text string.
    """
    if len(text) <= max_chars:
        return text
    head = max_chars // 2
    tail = max_chars - head - 5
    return f"{text[:head]} ... {text[-tail:]}"

