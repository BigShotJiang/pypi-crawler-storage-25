"""Build metadata for pycan_ultra."""

__all__ = ["__version__", "__title__", "__description__"]

__title__ = "pycan-ultra"
__version__ = "0.1.0"
__description__ = "World's most advanced agentic AI framework for cancer research"

