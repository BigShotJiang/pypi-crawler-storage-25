"""Application settings and configuration loader."""

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from pycan_ultra.core.paths import get_default_cache_dir


class Settings(BaseSettings):
    """Typed runtime settings.

    Attributes:
        app_env: Runtime environment label.
        cache_dir: Directory for local cache artifacts.
        llm_provider: Active LLM provider name.
        max_retries: Retry count for recoverable operations.
    """

    model_config = SettingsConfigDict(env_prefix="PYCAN_", env_file=".env", extra="ignore")

    app_env: str = Field(default="dev")
    cache_dir: Path = Field(default_factory=get_default_cache_dir)
    llm_provider: str = Field(default="offline")
    max_retries: int = Field(default=3, ge=0, le=10)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Load and cache settings object.

    Returns:
        Cached settings instance.
    """
    settings = Settings()
    settings.cache_dir.mkdir(parents=True, exist_ok=True)
    return settings

