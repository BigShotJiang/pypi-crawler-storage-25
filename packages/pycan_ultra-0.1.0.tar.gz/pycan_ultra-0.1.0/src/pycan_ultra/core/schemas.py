"""Shared Pydantic schemas for cross-module contracts."""

from datetime import date
from typing import Literal

from pydantic import BaseModel, Field


class Variant(BaseModel):
    """Genomic variant schema."""

    gene: str = Field(min_length=1)
    hgvs: str = Field(min_length=1)
    consequence: str = Field(min_length=1)


class Drug(BaseModel):
    """Drug entity schema."""

    name: str = Field(min_length=1)
    mechanism: str = Field(default="unknown")
    approval_status: Literal["approved", "investigational", "preclinical"] = "investigational"


class Trial(BaseModel):
    """Clinical trial schema."""

    nct_id: str = Field(min_length=3)
    title: str
    phase: str
    score: float = Field(ge=0.0, le=1.0)


class Patient(BaseModel):
    """Patient profile schema."""

    patient_id: str
    diagnosis: str
    diagnosis_date: date | None = None
    stage: str | None = None
    variants: list[Variant] = Field(default_factory=list)


class AgentResult(BaseModel):
    """Structured agent execution result."""

    agent_name: str
    status: Literal["success", "fallback", "failed"]
    summary: str
    evidence: list[str] = Field(default_factory=list)

