"""Typed exception hierarchy for pycan_ultra."""


class PyCanError(Exception):
    """Base exception for package-specific errors."""


class DataError(PyCanError):
    """Raised when data ingestion or validation fails."""


class AgentError(PyCanError):
    """Raised when an agent cannot complete an assigned task."""


class ModelError(PyCanError):
    """Raised when model training, inference, or export fails."""


class APIError(PyCanError):
    """Raised when third-party API interaction fails."""


class ValidationError(PyCanError):
    """Raised when schema validation fails."""

