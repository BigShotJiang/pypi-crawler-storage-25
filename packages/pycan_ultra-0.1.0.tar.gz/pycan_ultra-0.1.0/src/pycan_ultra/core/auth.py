"""Authentication and API key helpers."""

import threading
import time
from dataclasses import dataclass


@dataclass(slots=True)
class RateLimiter:
    """Token-bucket-like fixed interval limiter.

    Attributes:
        max_calls: Maximum calls in the period.
        period_seconds: Time window for max_calls.
    """

    max_calls: int
    period_seconds: float

    def __post_init__(self) -> None:
        self._calls: list[float] = []
        self._lock = threading.Lock()

    def allow(self) -> bool:
        """Check and consume one request slot if available.

        Returns:
            True when request is allowed.
        """
        now = time.monotonic()
        with self._lock:
            self._calls = [t for t in self._calls if now - t < self.period_seconds]
            if len(self._calls) >= self.max_calls:
                return False
            self._calls.append(now)
            return True

