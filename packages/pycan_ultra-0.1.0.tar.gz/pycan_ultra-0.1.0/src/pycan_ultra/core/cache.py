"""Disk cache helpers and decorators."""

import hashlib
import json
from functools import wraps
from pathlib import Path
from typing import Any, Callable, TypeVar

from pycan_ultra.core.config import get_settings

F = TypeVar("F", bound=Callable[..., Any])


def _key_for_call(name: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> str:
    payload = json.dumps({"name": name, "args": args, "kwargs": kwargs}, default=str, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def disk_cache(namespace: str) -> Callable[[F], F]:
    """Cache function result to disk using call signature hash.

    Args:
        namespace: Subfolder name to isolate cache entries.

    Returns:
        Decorator caching JSON-serializable outputs.
    """

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            settings = get_settings()
            cache_dir = settings.cache_dir / namespace
            cache_dir.mkdir(parents=True, exist_ok=True)
            key = _key_for_call(func.__name__, args, kwargs)
            target = Path(cache_dir / f"{key}.json")
            if target.exists():
                return json.loads(target.read_text(encoding="utf-8"))
            value = func(*args, **kwargs)
            target.write_text(json.dumps(value, default=str), encoding="utf-8")
            return value

        return wrapper  # type: ignore[return-value]

    return decorator

