"""Global constants used throughout pycan_ultra."""

DEFAULT_CACHE_DIRNAME = "pycan_ultra_cache"
DEFAULT_MAX_RETRIES = 3
DEFAULT_TIMEOUT_SECONDS = 30.0

CANCER_TYPES = (
    "BRCA",
    "LUAD",
    "LUSC",
    "COAD",
    "READ",
    "GBM",
    "OV",
    "SKCM",
    "HNSC",
    "KIRC",
    "LIHC",
    "PAAD",
    "PRAD",
    "STAD",
)

