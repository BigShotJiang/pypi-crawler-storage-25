"""Path resolution helpers for pycan_ultra runtime data."""

from pathlib import Path

from pycan_ultra.core.constants import DEFAULT_CACHE_DIRNAME


def get_project_root() -> Path:
    """Resolve project root from current module location.

    Returns:
        Project root path.
    """
    return Path(__file__).resolve().parents[3]


def get_default_cache_dir() -> Path:
    """Compute default cache directory.

    Returns:
        Cache directory path.
    """
    return get_project_root() / ".cache" / DEFAULT_CACHE_DIRNAME

