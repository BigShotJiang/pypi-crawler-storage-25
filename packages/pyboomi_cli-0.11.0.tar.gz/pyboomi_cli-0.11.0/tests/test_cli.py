from pyboomi_cli.cli import main


def test_cli_registers_expected_commands():
    commands = set(main.commands.keys())
    assert {
        "folder",
        "folders",
        "component",
        "package",
        "branch",
        "process",
        "processes",
        "runtime",
        "runtime-mgmt",
    } <= commands
