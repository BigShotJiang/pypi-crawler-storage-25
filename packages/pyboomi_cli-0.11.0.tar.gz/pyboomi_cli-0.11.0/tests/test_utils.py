import types
from unittest.mock import patch

import click
import pytest

from pyboomi_cli import utils


def test_format_output_xml_bytes_and_text():
    xml_bytes = b"<root><a>1</a></root>"
    assert "<root>" in utils.format_output(xml_bytes, "xml")
    assert "fallback" not in utils.format_output({"a": 1}, "json")


def test_accept_header_for_output_format():
    assert utils.accept_header_for_output_format("xml") == "application/xml"
    assert utils.accept_header_for_output_format("json") is None
    assert utils.accept_header_for_output_format("yaml") is None
    assert utils.accept_header_for_output_format("text") is None


def test_apply_accept_header_variants():
    client = types.SimpleNamespace()
    client.session = types.SimpleNamespace(headers={})
    client.default_headers = {}

    utils._apply_accept_header(client, "application/xml")
    assert client.session.headers["Accept"] == "application/xml"
    assert client.default_headers["Accept"] == "application/xml"

    # Fallback attribute path should not raise
    client_no_headers = types.SimpleNamespace()
    utils._apply_accept_header(client_no_headers, "application/json")


def test_apply_accept_header_exception_handling():
    """Test _apply_accept_header handles exceptions gracefully."""

    # Client with session that raises exception
    class FailingSession:
        @property
        def headers(self):
            raise AttributeError("No headers")

    client1 = types.SimpleNamespace()
    client1.session = FailingSession()
    client1.default_headers = {}
    utils._apply_accept_header(client1, "application/xml")  # Should not raise

    # Client with default_headers that raises exception
    class FailingHeaders:
        def __setitem__(self, key, value):
            raise TypeError("Cannot set")

    client2 = types.SimpleNamespace()
    client2.session = None
    client2.default_headers = FailingHeaders()
    utils._apply_accept_header(client2, "application/xml")  # Should not raise

    # Client with no attributes that can be set
    client3 = types.SimpleNamespace()

    # Make setattr fail
    class ReadOnly:
        def __setattr__(self, name, value):
            raise AttributeError("Read only")

    client3 = ReadOnly()
    utils._apply_accept_header(client3, "application/xml")  # Should not raise


def test_get_client_requires_account(monkeypatch):
    monkeypatch.delenv("BOOMI_ACCT", raising=False)
    monkeypatch.delenv("BOOMI_AUTH", raising=False)
    with pytest.raises(Exception):
        utils.get_client(account_id=None, username="u", api_token="t")


def test_get_client_uses_boomi_auth(monkeypatch):
    monkeypatch.setenv("BOOMI_ACCT", "acct")
    # token.email:uuid
    import base64

    token = base64.b64encode(b"user@example.com:apitoken").decode("utf-8")
    monkeypatch.setenv("BOOMI_AUTH", token)

    class DummyClient:
        def __init__(self, account_id, username, api_token, base_url=None):
            self.account_id = account_id
            self.username = username
            self.api_token = api_token
            self.auth = None

    monkeypatch.setattr(utils, "BoomiPlatformClient", DummyClient)
    client = utils.get_client()
    assert client.account_id == "acct"
    # username derived from BOOMI_AUTH payload
    assert client.username == "user@example.com"


def test_get_client_boomi_auth_no_colon(monkeypatch):
    """Test get_client with BOOMI_AUTH that has no colon."""
    monkeypatch.setenv("BOOMI_ACCT", "acct")
    import base64

    token = base64.b64encode(b"justusername").decode("utf-8")
    monkeypatch.setenv("BOOMI_AUTH", token)

    class DummyClient:
        def __init__(self, account_id, username, api_token, base_url=None):
            self.account_id = account_id
            self.username = username
            self.api_token = api_token
            self.auth = None

    monkeypatch.setattr(utils, "BoomiPlatformClient", DummyClient)
    client = utils.get_client()
    assert client.account_id == "acct"
    assert client.username == "justusername"


def test_get_client_boomi_auth_decode_error(monkeypatch):
    """Test get_client handles BOOMI_AUTH decode errors."""
    monkeypatch.setenv("BOOMI_ACCT", "acct")
    monkeypatch.setenv("BOOMI_AUTH", "invalid-base64!!!")

    class DummyClient:
        def __init__(self, account_id, username, api_token, base_url=None):
            self.account_id = account_id
            self.username = username
            self.api_token = api_token
            self.auth = None

    monkeypatch.setattr(utils, "BoomiPlatformClient", DummyClient)
    client = utils.get_client()
    assert client.account_id == "acct"
    # Should use fallback values
    assert client.username == "user"


def test_get_client_missing_credentials(monkeypatch):
    """Test get_client raises error when credentials are missing."""
    monkeypatch.setenv("BOOMI_ACCT", "acct")
    monkeypatch.delenv("BOOMI_AUTH", raising=False)
    monkeypatch.delenv("BOOMI_USER", raising=False)
    monkeypatch.delenv("BOOMI_TOKEN", raising=False)

    with pytest.raises(Exception):  # click.UsageError
        utils.get_client(account_id="acct", username=None, api_token=None)


# Template function tests


def test_scan_template_parameters():
    """Test scanning template content for parameters."""
    # Simple case - no defaults
    content = "Hello {{name}}, your ID is {{userId}}"
    params = utils.scan_template_parameters(content)
    assert params == {"name": None, "userId": None}

    # Multiple occurrences of same parameter
    content = "{{name}} and {{name}} again"
    params = utils.scan_template_parameters(content)
    assert params == {"name": None}

    # No parameters
    content = "No parameters here"
    params = utils.scan_template_parameters(content)
    assert params == {}

    # Complex case with various parameter names
    content = "{{componentName}} in {{folderId}} with {{branchName}}"
    params = utils.scan_template_parameters(content)
    assert params == {"componentName": None, "folderId": None, "branchName": None}

    # Parameters with underscores
    content = "{{user_name}} and {{api_key}}"
    params = utils.scan_template_parameters(content)
    assert params == {"user_name": None, "api_key": None}

    # Parameters with default values
    content = "Hello {{name:World}}, your ID is {{userId}}"
    params = utils.scan_template_parameters(content)
    assert params == {"name": "World", "userId": None}

    # Parameters with defaults containing spaces
    content = "{{description:This is the default value}} and {{name:Test}}"
    params = utils.scan_template_parameters(content)
    assert params == {"description": "This is the default value", "name": "Test"}

    # Mix of parameters with and without defaults
    content = "{{name:Default Name}} in {{folderId}} with {{branchName:main}}"
    params = utils.scan_template_parameters(content)
    assert params == {"name": "Default Name", "folderId": None, "branchName": "main"}

    # Parameter with default that appears both with and without default (default takes precedence)
    content = "{{name:Default}} and {{name}}"
    params = utils.scan_template_parameters(content)
    assert params == {"name": "Default"}  # Default value should be used

    # Multi-line default value
    content = """{{description:Line 1
Line 2
Line 3}}"""
    params = utils.scan_template_parameters(content)
    assert params == {"description": "Line 1\nLine 2\nLine 3"}

    # Multi-line default with complex content (like the user's example)
    content = """{{description:Template UT-Act component used to execute the System Under Test (SUT). This component connects a unit test to the target process or logic being validated and routes prepared test data to the SUT. It contains no scenario-specific behavior and must be paired with Arrange, UTExec-Act, and Assert components to complete a unit test.

When implementing for a specific test, configure the Process Route to direct input from the appropriate test data source. To maintain proper unit test isolation, mock all external dependencies—including subprocesses and connector calls—so the UT-Act executes only the functionality under test. A single UT-Act component should be used for all unit tests targeting a given SUT.}}"""
    params = utils.scan_template_parameters(content)
    assert "description" in params
    assert "Template UT-Act component" in params["description"]
    assert "System Under Test" in params["description"]
    assert "\n" in params["description"]  # Should contain newlines


def test_replace_template_parameters():
    """Test replacing template parameters with values."""
    content = "Hello {{name}}, your ID is {{userId}}"
    values = {"name": "Alice", "userId": "12345"}
    result = utils.replace_template_parameters(content, values)
    assert result == "Hello Alice, your ID is 12345"

    # Multiple occurrences
    content = "{{name}} and {{name}} again"
    values = {"name": "Bob"}
    result = utils.replace_template_parameters(content, values)
    assert result == "Bob and Bob again"

    # No parameters
    content = "No parameters here"
    result = utils.replace_template_parameters(content, {})
    assert result == "No parameters here"

    # Complex XML-like content
    content = "<Process><Name>{{componentName}}</Name><FolderId>{{folderId}}</FolderId></Process>"
    values = {"componentName": "MyProcess", "folderId": "folder-123"}
    result = utils.replace_template_parameters(content, values)
    assert "MyProcess" in result
    assert "folder-123" in result
    assert "{{componentName}}" not in result
    assert "{{folderId}}" not in result

    # Parameters with default values (should replace both formats)
    content = "{{name:Default Name}} and {{name}}"
    values = {"name": "Custom Name"}
    result = utils.replace_template_parameters(content, values)
    assert result == "Custom Name and Custom Name"
    assert "{{name" not in result

    # Parameter with default value format
    content = "{{description:This is the default value}}"
    values = {"description": "Custom description"}
    result = utils.replace_template_parameters(content, values)
    assert result == "Custom description"
    assert "{{description" not in result

    # Multi-line default value replacement
    content = """{{description:Line 1
Line 2
Line 3}}"""
    values = {"description": "Replaced\nMulti-line\nValue"}
    result = utils.replace_template_parameters(content, values)
    assert "Replaced" in result
    assert "Multi-line" in result
    assert "{{description" not in result

    # Complex multi-line default replacement
    content = """<Process>
<Description>{{description:Default line 1
Default line 2
Default line 3}}</Description>
</Process>"""
    values = {"description": "Custom\nMulti-line\nDescription"}
    result = utils.replace_template_parameters(content, values)
    assert "Custom\nMulti-line\nDescription" in result
    assert "Default line" not in result
    assert "{{description" not in result


def test_get_templates_directory_env_var(monkeypatch, tmp_path):
    """Test get_templates_directory with environment variable."""
    custom_path = tmp_path / "custom_templates"
    custom_path.mkdir()
    monkeypatch.setenv("PYBOOMI_TEMPLATES_DIR", str(custom_path))
    result = utils.get_templates_directory()
    assert result == custom_path


def test_get_templates_directory_cwd_exists(monkeypatch, tmp_path):
    """Test get_templates_directory when templates exists in CWD."""
    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    monkeypatch.chdir(tmp_path)
    result = utils.get_templates_directory()
    assert result == templates_dir


def test_get_templates_directory_default(monkeypatch, tmp_path):
    """Test get_templates_directory default behavior."""
    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)
    result = utils.get_templates_directory()
    assert result == tmp_path / "templates"


def test_find_template_file_absolute_path(tmp_path):
    """Test find_template_file with absolute path."""
    template_file = tmp_path / "template.xml"
    template_file.write_text("test content")
    result = utils.find_template_file(str(template_file))
    assert result == template_file


def test_find_template_file_relative_path(tmp_path, monkeypatch):
    """Test find_template_file with relative path."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "processes" / "basic.xml"
    template_file.parent.mkdir()
    template_file.write_text("test content")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    result = utils.find_template_file("processes/basic.xml")
    assert result == template_file


def test_find_template_file_component_type(tmp_path, monkeypatch):
    """Test find_template_file with component_type."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    processes_dir = templates_dir / "processes"
    processes_dir.mkdir()
    template_file = processes_dir / "basic.xml"
    template_file.write_text("test content")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    result = utils.find_template_file("basic.xml", component_type="processes")
    assert result == template_file


def test_find_template_file_not_found(tmp_path, monkeypatch):
    """Test find_template_file raises error when file not found."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    with pytest.raises(Exception):  # click.UsageError
        utils.find_template_file("nonexistent.xml")


def test_prompt_for_template_parameters_all_provided():
    """Test prompt_for_template_parameters when all values are provided."""
    parameters = {"name": None, "userId": None}
    existing_values = {"name": "Alice", "userId": "123"}

    with patch("click.echo") as mock_echo:
        result = utils.prompt_for_template_parameters(parameters, existing_values)

    assert result == {"name": "Alice", "userId": "123"}
    # Should echo the provided values
    assert mock_echo.call_count == 2


def test_prompt_for_template_parameters_none_provided(monkeypatch):
    """Test prompt_for_template_parameters when existing_values is None."""
    parameters = {"name": None}

    with patch("click.prompt", return_value="Alice") as mock_prompt, patch("click.echo"):
        result = utils.prompt_for_template_parameters(parameters, None)

    assert result == {"name": "Alice"}
    assert mock_prompt.call_count == 1


def test_prompt_for_template_parameters_with_defaults(monkeypatch):
    """Test prompt_for_template_parameters with default values."""
    parameters = {"name": "Default Name", "userId": None}

    with patch("click.prompt", side_effect=["Custom Name", "123"]) as mock_prompt, patch("click.echo"):
        result = utils.prompt_for_template_parameters(parameters, {})

    # Should prompt for both, but name should have default shown
    assert result["name"] == "Custom Name"
    assert result["userId"] == "123"
    assert mock_prompt.call_count == 2
    # Check that default was passed to prompt for name
    assert mock_prompt.call_args_list[0][1].get("default") == "Default Name"


def test_prompt_for_template_parameters_accept_default(monkeypatch):
    """Test prompt_for_template_parameters when user accepts default value."""
    parameters = {"name": "Default Name"}

    # When default is provided and user just presses enter, prompt returns the default
    with patch("click.prompt", return_value="Default Name") as mock_prompt, patch("click.echo"):
        result = utils.prompt_for_template_parameters(parameters, {})

    assert result == {"name": "Default Name"}
    assert mock_prompt.call_count == 1
    # Verify default was passed
    assert mock_prompt.call_args_list[0][1].get("default") == "Default Name"


def test_prompt_for_template_parameters_prompting(monkeypatch):
    """Test prompt_for_template_parameters with interactive prompting."""
    parameters = {"name": None, "userId": None}

    with patch("click.prompt", side_effect=["Alice", "123"]) as mock_prompt, patch("click.echo"):
        result = utils.prompt_for_template_parameters(parameters, {})

    assert result == {"name": "Alice", "userId": "123"}
    assert mock_prompt.call_count == 2


def test_prompt_for_template_parameters_partial(monkeypatch):
    """Test prompt_for_template_parameters with some values provided."""
    parameters = {"name": None, "userId": None, "description": "Default desc"}
    existing_values = {"name": "Alice"}

    with patch("click.prompt", side_effect=["123", "Custom desc"]) as mock_prompt, patch("click.echo"):
        result = utils.prompt_for_template_parameters(parameters, existing_values)

    assert result["name"] == "Alice"
    # Parameters are sorted, so order may vary - check that both missing params got values
    assert "123" in result.values()
    assert "Custom desc" in result.values()
    assert result["userId"] in ["123", "Custom desc"]
    assert result["description"] in ["123", "Custom desc"]
    assert mock_prompt.call_count == 2  # Only for missing params


def test_load_and_process_template_no_parameters(tmp_path, monkeypatch):
    """Test load_and_process_template with template that has no parameters."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "simple.xml"
    template_file.write_text("<Process><Name>Test</Name></Process>")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    result = utils.load_and_process_template("simple.xml")
    assert result == "<Process><Name>Test</Name></Process>"


def test_load_and_process_template_with_parameters(tmp_path, monkeypatch):
    """Test load_and_process_template with parameters."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    template_file.write_text("<Process><Name>{{name}}</Name><Id>{{id}}</Id></Process>")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    parameter_values = {"name": "MyProcess", "id": "123"}

    result = utils.load_and_process_template("template.xml", parameter_values=parameter_values, prompt_missing=False)
    assert "MyProcess" in result
    assert "123" in result
    assert "{{name}}" not in result
    assert "{{id}}" not in result


def test_load_and_process_template_with_defaults_no_prompt(tmp_path, monkeypatch):
    """Test load_and_process_template uses defaults when prompt_missing=False."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    template_file.write_text("<Process><Name>{{name:Default Name}}</Name><Id>{{id}}</Id></Process>")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    # Only provide id, name should use default
    parameter_values = {"id": "123"}

    result = utils.load_and_process_template("template.xml", parameter_values=parameter_values, prompt_missing=False)
    assert "Default Name" in result
    assert "123" in result
    assert "{{name" not in result
    assert "{{id}}" not in result


def test_load_and_process_template_with_defaults_prompt(tmp_path, monkeypatch):
    """Test load_and_process_template prompts with defaults when prompt_missing=True."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    template_file.write_text("<Process><Name>{{name:Default Name}}</Name></Process>")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    with (
        patch("click.prompt", return_value="Custom Name") as mock_prompt,
        patch("click.confirm", return_value=True),
        patch("click.echo"),
    ):
        result = utils.load_and_process_template("template.xml", parameter_values={}, prompt_missing=True)

    assert "Custom Name" in result
    assert "{{name" not in result
    assert mock_prompt.called
    # Verify default was passed to prompt
    assert mock_prompt.call_args_list[0][1].get("default") == "Default Name"


def test_load_and_process_template_multiline_default(tmp_path, monkeypatch):
    """Test load_and_process_template with multi-line default value."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    multiline_default = """Template UT-Act component used to execute the System Under Test (SUT). This component connects a unit test to the target process or logic being validated and routes prepared test data to the SUT. It contains no scenario-specific behavior and must be paired with Arrange, UTExec-Act, and Assert components to complete a unit test.

When implementing for a specific test, configure the Process Route to direct input from the appropriate test data source. To maintain proper unit test isolation, mock all external dependencies—including subprocesses and connector calls—so the UT-Act executes only the functionality under test. A single UT-Act component should be used for all unit tests targeting a given SUT."""
    # Use double braces in f-string to get literal {{ in output
    template_content = f"<Process><Description>{{{{description:{multiline_default}}}}}</Description></Process>"
    template_file.write_text(template_content)

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    # Test with no-prompt (should use default automatically)
    result = utils.load_and_process_template("template.xml", parameter_values={}, prompt_missing=False)
    assert "Template UT-Act component" in result
    assert "System Under Test" in result
    assert "\n" in result  # Should contain newlines
    assert "{{description" not in result

    # Test with prompting (should show default in prompt)
    with (
        patch("pyboomi_cli.utils.click.prompt", return_value=multiline_default) as mock_prompt,
        patch("pyboomi_cli.utils.click.confirm", return_value=True),
        patch("pyboomi_cli.utils.click.echo"),
    ):
        result = utils.load_and_process_template("template.xml", parameter_values={}, prompt_missing=True)

    assert "Template UT-Act component" in result
    assert "{{description" not in result
    # Should have prompted (since we didn't provide the value)
    assert mock_prompt.called
    # Verify multi-line default was passed to prompt
    call_kwargs = mock_prompt.call_args_list[0][1]
    assert call_kwargs.get("default") == multiline_default


def test_load_and_process_template_prompt_missing(tmp_path, monkeypatch):
    """Test load_and_process_template with prompting for missing parameters."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    template_file.write_text("<Process><Name>{{name}}</Name></Process>")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    with (
        patch("click.prompt", return_value="MyProcess") as mock_prompt,
        patch("click.echo"),
        patch("click.confirm", return_value=True),
    ):  # User confirms to continue
        result = utils.load_and_process_template("template.xml", parameter_values={}, prompt_missing=True)

    assert "MyProcess" in result
    assert "{{name}}" not in result
    assert mock_prompt.called


def test_display_template_parameter_summary(capsys):
    """Test display_template_parameter_summary function."""
    parameters = {
        "name": None,  # No default
        "description": "Default description",  # With default
        "folderId": None,  # No default
        "branchName": "main",  # With default
    }
    provided_values = {"name": "MyComponent"}

    utils.display_template_parameter_summary(parameters, provided_values)
    output = capsys.readouterr().out

    # Check that summary is displayed
    assert "Template Parameter Summary" in output
    assert "Already Provided" in output
    assert "MyComponent" in output
    assert "Parameters with Default Values" in output
    assert "Default description" in output
    assert "main" in output
    assert "Parameters Requiring Values" in output
    assert "folderId" in output


def test_display_template_parameter_summary_empty():
    """Test display_template_parameter_summary with empty parameters."""
    # Should not raise an error
    utils.display_template_parameter_summary({}, {})
    utils.display_template_parameter_summary({})


def test_load_and_process_template_shows_summary_and_abort(tmp_path, monkeypatch):
    """Test that summary is shown and user can abort."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    template_file.write_text("<Process><Name>{{name}}</Name><Folder>{{folderId}}</Folder></Process>")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    with patch("click.echo") as mock_echo, patch("click.confirm", return_value=False):  # User chooses to abort
        try:
            utils.load_and_process_template("template.xml", parameter_values={}, prompt_missing=True)
            assert False, "Should have raised click.Abort"
        except click.Abort:
            pass  # Expected

    # Verify summary was displayed
    echo_calls = [str(call) for call in mock_echo.call_args_list]
    summary_shown = any("Template Parameter Summary" in str(call) for call in echo_calls)
    assert summary_shown, "Summary should have been displayed"


def test_load_and_process_template_shows_summary_and_continues(tmp_path, monkeypatch):
    """Test that summary is shown and user can continue."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    template_file.write_text("<Process><Name>{{name}}</Name><Folder>{{folderId}}</Folder></Process>")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    with (
        patch("click.prompt", side_effect=["MyProcess", "folder123"]) as mock_prompt,
        patch("click.echo") as mock_echo,
        patch("click.confirm", return_value=True),
    ):  # User chooses to continue
        result = utils.load_and_process_template("template.xml", parameter_values={}, prompt_missing=True)

    # Verify summary was displayed
    echo_calls = [str(call) for call in mock_echo.call_args_list]
    summary_shown = any("Template Parameter Summary" in str(call) for call in echo_calls)
    assert summary_shown, "Summary should have been displayed"

    # Verify parameters were replaced
    assert "MyProcess" in result
    assert "folder123" in result
    assert "{{name}}" not in result
    assert "{{folderId}}" not in result
    assert mock_prompt.call_count == 2  # Should have prompted for both missing params


def test_load_and_process_template_missing_values_error(tmp_path, monkeypatch):
    """Test load_and_process_template raises error when parameters are missing."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    template_file.write_text("<Process><Name>{{name}}</Name><Id>{{id}}</Id></Process>")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    with pytest.raises(Exception):  # click.UsageError
        utils.load_and_process_template("template.xml", parameter_values={"name": "Test"}, prompt_missing=False)


def test_load_and_process_template_file_not_found(tmp_path, monkeypatch):
    """Test load_and_process_template when template file doesn't exist."""
    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    with pytest.raises(Exception):  # click.UsageError
        utils.load_and_process_template("nonexistent.xml")


def test_load_and_process_template_read_error(tmp_path, monkeypatch):
    """Test load_and_process_template handles file read errors."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    template_file.write_text("test")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    # Make file unreadable
    template_file.chmod(0o000)

    try:
        with pytest.raises(Exception):  # click.UsageError
            utils.load_and_process_template("template.xml")
    finally:
        # Restore permissions for cleanup
        template_file.chmod(0o644)


def test_load_and_process_template_parameter_values_none(tmp_path, monkeypatch):
    """Test load_and_process_template with parameter_values=None."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    template_file = templates_dir / "template.xml"
    template_file.write_text("<Process><Name>{{name}}</Name></Process>")

    monkeypatch.delenv("PYBOOMI_TEMPLATES_DIR", raising=False)
    monkeypatch.chdir(tmp_path)

    with (
        patch("click.prompt", return_value="MyProcess") as mock_prompt,
        patch("click.confirm", return_value=True),
        patch("click.echo"),
    ):
        result = utils.load_and_process_template("template.xml", parameter_values=None, prompt_missing=True)

    assert "MyProcess" in result
    assert mock_prompt.called
