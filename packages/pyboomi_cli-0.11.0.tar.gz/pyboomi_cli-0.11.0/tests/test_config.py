"""Tests for config module."""

import json
from pathlib import Path


from pyboomi_cli.config import get_config, get_config_file_path


def test_config_file_path_local_priority(tmp_path, monkeypatch):
    """Test that local config file takes priority over home config."""
    # Change to temp directory
    monkeypatch.chdir(tmp_path)

    # Create local config file
    local_config = tmp_path / ".pyboomi.json"
    local_config.write_text('{"cache_dir": "local"}')

    # Mock home directory with config
    home_dir = tmp_path / "home"
    home_dir.mkdir()
    home_config = home_dir / ".pyboomi.json"
    home_config.write_text('{"cache_dir": "home"}')

    monkeypatch.setattr(Path, "home", lambda: home_dir)

    # Local config should take priority
    config_path = get_config_file_path()
    assert config_path.resolve() == local_config.resolve()


def test_config_file_path_home_fallback(tmp_path, monkeypatch):
    """Test that home config is used when no local config exists."""
    # Change to temp directory with no local config
    monkeypatch.chdir(tmp_path)

    # Mock home directory
    home_dir = tmp_path / "home"
    home_dir.mkdir()
    monkeypatch.setattr(Path, "home", lambda: home_dir)

    config_path = get_config_file_path()
    assert config_path == home_dir / ".pyboomi.json"


def test_get_config_success(tmp_path, monkeypatch):
    """Test successful config loading."""
    config_file = tmp_path / ".pyboomi.json"
    config_data = {"cache_dir": "/custom/cache", "other_setting": "value"}

    with open(config_file, "w") as f:
        json.dump(config_data, f)

    # Mock get_config_file_path to return our test file
    import pyboomi_cli.config as config_module

    monkeypatch.setattr(config_module, "get_config_file_path", lambda: config_file)

    config = get_config()
    assert config == config_data


def test_get_config_no_file(tmp_path, monkeypatch):
    """Test config loading when file doesn't exist."""
    non_existent = tmp_path / "nonexistent.json"

    import pyboomi_cli.config as config_module

    monkeypatch.setattr(config_module, "get_config_file_path", lambda: non_existent)

    config = get_config()
    assert config is None


def test_get_config_invalid_json(tmp_path, monkeypatch):
    """Test config loading with invalid JSON."""
    config_file = tmp_path / ".pyboomi.json"
    config_file.write_text("invalid json content")

    import pyboomi_cli.config as config_module

    monkeypatch.setattr(config_module, "get_config_file_path", lambda: config_file)

    config = get_config()
    assert config is None
