"""Tests for cache module."""

from pathlib import Path


from pyboomi_cli.cache import (cache_component, get_cache_key,
                               get_cached_component)


def test_cache_key_generation():
    """Test cache key generation for different component combinations."""
    key1 = get_cache_key("comp-123", "branch-456", "v1.0")
    key2 = get_cache_key("comp-123", "branch-789", "v1.0")
    key3 = get_cache_key("comp-123", "branch-456", "v2.0")

    # All keys should be different
    assert len({key1, key2, key3}) == 3

    # Keys should be consistent
    assert get_cache_key("comp-123", "branch-456", "v1.0") == key1


def test_cache_operations(monkeypatch, tmp_path):
    """Test basic cache store and retrieve operations."""
    # Mock cache directory
    cache_dir = tmp_path / ".boomicache"

    import pyboomi_cli.cache as cache_module

    monkeypatch.setattr(cache_module, "get_cache_dir", lambda: cache_dir)

    # Test cache miss without version
    cached = get_cached_component("comp-123")
    assert cached is None

    # Test cache miss with incomplete info
    cached = get_cached_component("comp-123", "branch-456")
    assert cached is None

    # Test cache store with complete info
    test_data = "<Component branchId='branch-456' version='v1.0'><Name>Test</Name></Component>"
    cache_component(test_data, "comp-123", "branch-456", "v1.0")

    # Test cache hit with complete info
    cached = get_cached_component("comp-123", "branch-456", "v1.0")
    assert cached == test_data

    # Verify cache directory was created
    assert cache_dir.exists()


def test_cache_with_branch_and_version(monkeypatch, tmp_path):
    """Test caching with branch and version parameters."""
    cache_dir = tmp_path / ".boomicache"

    import pyboomi_cli.cache as cache_module

    monkeypatch.setattr(cache_module, "get_cache_dir", lambda: cache_dir)

    # Cache different versions
    data1 = "<Component branchId='branch-456' version='v1.0'><Name>Test v1</Name></Component>"
    data2 = "<Component branchId='branch-456' version='v2.0'><Name>Test v2</Name></Component>"

    cache_component(data1, "comp-123", "branch-456", "v1.0")
    cache_component(data2, "comp-123", "branch-456", "v2.0")

    # Retrieve specific versions
    cached1 = get_cached_component("comp-123", "branch-456", "v1.0")
    cached2 = get_cached_component("comp-123", "branch-456", "v2.0")

    assert cached1 == data1
    assert cached2 == data2

    # Different branch should be cache miss
    cached3 = get_cached_component("comp-123", "branch-789", "v1.0")
    assert cached3 is None


def test_extract_component_info():
    """Test extraction of branch and version from component XML."""
    from pyboomi_cli.cache import extract_component_info

    # Test with branchId and version attributes
    xml1 = "<Component branchId='branch-123' version='v1.0'><Name>Test</Name></Component>"
    branch, version = extract_component_info(xml1)
    assert branch == "branch-123"
    assert version == "v1.0"

    # Test with alternative attribute names
    xml2 = "<Component branch-id='branch-456' revision='v2.0'><Name>Test</Name></Component>"
    branch, version = extract_component_info(xml2)
    assert branch == "branch-456"
    assert version == "v2.0"

    # Test with missing attributes
    xml3 = "<Component><Name>Test</Name></Component>"
    branch, version = extract_component_info(xml3)
    assert branch is None
    assert version is None

    # Test with invalid XML
    branch, version = extract_component_info("invalid xml")
    assert branch is None
    assert version is None


def test_cache_component_with_xml_extraction(monkeypatch, tmp_path):
    """Test caching component with automatic XML extraction."""
    cache_dir = tmp_path / ".boomicache"

    import pyboomi_cli.cache as cache_module

    monkeypatch.setattr(cache_module, "get_cache_dir", lambda: cache_dir)

    # Cache component without providing branch/version - should extract from XML
    test_data = "<Component branchId='branch-789' version='v3.0'><Name>Auto Extract</Name></Component>"
    cache_component(test_data, "comp-456")

    # Should be retrievable with extracted values
    cached = get_cached_component("comp-456", "branch-789", "v3.0")
    assert cached == test_data

    # Should not be retrievable without complete info
    cached_incomplete = get_cached_component("comp-456")
    assert cached_incomplete is None


def test_cache_error_handling(monkeypatch, tmp_path):
    """Test cache handles errors gracefully."""
    # Mock cache directory to non-writable location
    import pyboomi_cli.cache as cache_module

    # Mock get_cache_dir to return a path that will cause permission error
    def mock_get_cache_dir():
        bad_path = Path("/root/no-permission")
        return bad_path

    monkeypatch.setattr(cache_module, "get_cache_dir", mock_get_cache_dir)

    # Cache operations should not raise exceptions
    cache_component("test", "comp-123", "branch-456", "v1.0")  # Should not raise
    cached = get_cached_component("comp-123", "branch-456", "v1.0")  # Should return None
    assert cached is None
