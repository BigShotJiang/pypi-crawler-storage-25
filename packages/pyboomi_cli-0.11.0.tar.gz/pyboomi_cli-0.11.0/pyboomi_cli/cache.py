# PyBoomi CLI - Cache Management
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Cache management for PyBoomi CLI components."""

import hashlib
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional, Tuple


def get_cache_dir() -> Path:
    """Get the cache directory path, cross-platform compatible."""
    from pyboomi_cli.config import get_config

    config = get_config()

    if config and "cache_dir" in config:
        return Path(config["cache_dir"]).expanduser()

    # Default to .boomicache in user home directory
    home = Path.home()
    return home / ".boomicache"


def get_cache_key(component_id: str, branch_id: str, version: str) -> str:
    """Generate a cache key for a component. Requires both branch_id and version."""
    key_string = f"{component_id}|branch:{branch_id}|version:{version}"
    return hashlib.sha256(key_string.encode()).hexdigest()


def extract_component_info(component_xml: str) -> Tuple[Optional[str], Optional[str]]:
    """Extract branch ID and version from component XML."""
    try:
        root = ET.fromstring(component_xml)
        # Look for common attributes that contain branch and version info
        branch_id = root.get("branchId") or root.get("branch-id")
        version = root.get("version") or root.get("revision")
        return branch_id, version
    except Exception:
        return None, None


def get_cached_component(
    component_id: str, branch_id: Optional[str] = None, version: Optional[str] = None
) -> Optional[str]:
    """
    Retrieve a component from cache if it exists.

    Only works with specific branch_id and version.
    """
    if not branch_id or not version:
        return None  # Don't cache without specific branch and version

    try:
        cache_dir = get_cache_dir()
        if not cache_dir.exists():
            return None

        cache_key = get_cache_key(component_id, branch_id, version)
        cache_file = cache_dir / f"{cache_key}.xml"

        if cache_file.exists():
            return cache_file.read_text(encoding="utf-8")
    except Exception:
        pass

    return None


def cache_component(
    component_data: str,
    component_id: str,
    branch_id: Optional[str] = None,
    version: Optional[str] = None,
) -> None:
    """Store a component in the cache. Only caches with specific branch_id and version."""
    # If branch_id or version not provided, try to extract from component XML
    if not branch_id or not version:
        extracted_branch, extracted_version = extract_component_info(component_data)
        branch_id = branch_id or extracted_branch
        version = version or extracted_version

    # Only cache if we have both branch and version
    if not branch_id or not version:
        return

    try:
        cache_dir = get_cache_dir()
        cache_dir.mkdir(parents=True, exist_ok=True)

        cache_key = get_cache_key(component_id, branch_id, version)
        cache_file = cache_dir / f"{cache_key}.xml"

        cache_file.write_text(component_data, encoding="utf-8")
    except Exception:
        pass  # Silently fail if caching doesn't work
