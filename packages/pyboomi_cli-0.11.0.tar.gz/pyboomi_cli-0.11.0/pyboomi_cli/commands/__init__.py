# PyBoomi CLI - Commands Package
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-07-27

"""
PyBoomi CLI Commands Package.

This package contains all CLI command implementations for the PyBoomi CLI tool.
"""

"""
PyBoomi CLI Commands Package

This package contains all CLI command implementations for the PyBoomi CLI tool.
Each command is implemented as a separate module with a Click command function
that can be registered with the main CLI group.

Available Commands:
- folders (alias: folder): Query and list Boomi folders with filtering options
- processes (alias: process): List and manage Boomi processes (placeholder implementation)
- component: Retrieve component information by component ID; includes references (get/bulk/query/query-more) for ComponentReference API
- package: Create, get, and query Boomi packaged components
- branch: Manage Boomi branches (query, create, update, delete)

Command Structure:
Each command module should export a 'command' function decorated with @click.command()
that implements the specific functionality for that command.

Authentication:
All commands support multiple authentication methods:
1. BOOMI_AUTH environment variable (base64 encoded Basic Auth)
2. CLI arguments (--username, --api-token)
3. Environment variables (BOOMI_USER, BOOMI_TOKEN)

Account ID can be provided via --account-id argument or BOOMI_ACCT environment variable.
"""

# Commands are imported lazily to avoid circular imports
# This allows imports like "from pyboomi_cli.commands import branch" to work
# without causing circular import issues

__all__ = [
    "folders",
    "processes",
    "component",
    "package",
    "branch",
    "environment",
    "deployed",
]


# Lazy import implementation to avoid circular imports
def __getattr__(name):
    """Lazily import command modules when accessed."""
    if name == "branch":
        from . import branch

        return branch
    elif name == "component":
        from . import component

        return component
    elif name == "deployed":
        from . import deployed

        return deployed
    elif name == "environment":
        from . import environment

        return environment
    elif name == "folders":
        from . import folders

        return folders
    elif name == "package":
        from . import package

        return package
    elif name == "processes":
        from . import processes

        return processes
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
