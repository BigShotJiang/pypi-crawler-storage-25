# PyBoomi CLI - Deployed Package Command
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Implements DeployedPackage API: create, get, delete, bulk, query, query-more.
#     Uses pyboomi_platform DeploymentClient (client.deployment).
#
# Author: Robert Little
# Created: 2025-02-11

"""Deployed package management commands for PyBoomi CLI."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import sys
import uuid
from typing import Optional

import click
from pyboomi_platform.utils import build_query_filter

from pyboomi_cli.utils import format_output, get_client

try:
    from pyboomi_platform.exceptions import BoomiAPIError
except (ImportError, AttributeError):
    try:
        from pyboomi_platform import BoomiAPIError  # type: ignore[attr-defined]
    except (ImportError, AttributeError):

        class BoomiAPIError(Exception):  # type: ignore[no-redef]
            """Fallback exception for Boomi API errors."""

            pass


@click.group("deployed")
@click.pass_context
@click.option("--account-id", help="Boomi account ID (or use BOOMI_ACCT)")
@click.option("--username", help="Boomi user email (or use BOOMI_USER)")
@click.option("--api-token", help="Boomi Platform API token (or use BOOMI_TOKEN)")
def command(ctx, account_id, username, api_token):
    """
    Manage Boomi deployed packages (DeployedPackage).

    Deploy packaged components to environments, and list or remove deployments.

    Priority for credentials:
    - BOOMI_AUTH (base64 encoded Basic Auth string)
    - --username / --api-token CLI args
    - BOOMI_USER / BOOMI_TOKEN env vars

    Account ID can come from --account-id or BOOMI_ACCT env var.

    Note: Options like --account-id must be specified BEFORE the subcommand.
    Example: pyboomi deployed --account-id ACCT123 get <deployment-id>
    """
    ctx.ensure_object(dict)
    ctx.obj["account_id"] = account_id
    ctx.obj["username"] = username
    ctx.obj["api_token"] = api_token


@command.command("create")
@click.pass_context
@click.option(
    "--environment-id",
    required=True,
    help="Environment ID to deploy to",
)
@click.option("--package-id", help="Packaged component ID to deploy (use this OR --component-id)")
@click.option(
    "--component-id",
    help="Component ID to package and deploy in one step (use this OR --package-id)",
)
@click.option(
    "--listener-status",
    type=click.Choice(["RUNNING", "PAUSED"]),
    help="For listener processes: RUNNING or PAUSED",
)
@click.option("--notes", help="Notes describing the deployment")
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: deployed_create.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def create(
    ctx, environment_id, package_id, component_id, listener_status, notes, output_format, save, save_filename, quiet
):
    """Create a deployed package (deploy to an environment)."""
    if (package_id and component_id) or (not package_id and not component_id):
        click.echo(
            "Error: Exactly one of --package-id or --component-id must be provided.",
            err=True,
        )
        sys.exit(1)
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml" if output_format == "xml" else None,
        )
        result = client.deployment.create_deployed_package(
            environment_id=environment_id,
            package_id=package_id or None,
            component_id=component_id or None,
            listener_status=listener_status,
            notes=notes,
        )
        formatted = format_output(result, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "deployed_create.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("get")
@click.pass_context
@click.argument("deployment_id")
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: deployed_get_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def get(ctx, deployment_id, output_format, save, save_filename, quiet):
    """Get a deployed package by deployment ID."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml" if output_format == "xml" else None,
        )
        result = client.deployment.get_deployed_package(deployment_id)
        formatted = format_output(result, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"deployed_get_{deployment_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("delete")
@click.pass_context
@click.argument("deployment_id")
@click.option(
    "--auto-approve",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt",
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Show deployment details before delete",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: deployed_delete_<id>.txt).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def delete(ctx, deployment_id, auto_approve, verbose, save, save_filename, quiet):
    """Delete a deployed package by deployment ID."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )
        if verbose:
            try:
                info = client.deployment.get_deployed_package(deployment_id)
                click.echo(f"Deployment: {info.get('deploymentId', deployment_id)}")
                click.echo(f"  environmentId: {info.get('environmentId', '')}")
                click.echo(f"  packageId: {info.get('packageId', '')}")
                click.echo(f"  componentType: {info.get('componentType', '')}")
            except Exception:
                click.echo(f"Deployment ID: {deployment_id}")
        if not auto_approve:
            if not click.confirm("Are you sure you want to delete this deployment?"):
                click.echo("Deletion cancelled.")
                return
        client.deployment.delete_deployed_package(deployment_id)
        success_msg = "Deployment deleted successfully."
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"deployed_delete_{deployment_id}.txt"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(success_msg + "\n")
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(success_msg)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("bulk")
@click.pass_context
@click.argument("deployment_ids", nargs=-1, required=True)
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: deployed_bulk.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def bulk(ctx, deployment_ids, output_format, save, save_filename, quiet):
    """Get multiple deployed packages by ID (max 100)."""
    ids = list(deployment_ids)
    if len(ids) > 100:
        click.echo("Error: Maximum 100 deployment IDs allowed.", err=True)
        sys.exit(1)
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml" if output_format == "xml" else None,
        )
        result = client.deployment.get_deployed_package_bulk(ids)
        formatted = format_output(result, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "deployed_bulk.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


def _normalize_deployed_date(value: str, end_of_day: bool = False) -> str:
    """Normalize a date string to Boomi ISO 8601 format (UTC)."""
    value = value.strip()
    if "T" in value:
        return value if value.endswith("Z") or value[-3] in "+-" else value + "Z"
    if end_of_day:
        return value + "T23:59:59Z"
    return value + "T00:00:00Z"


def _is_environment_uuid(value: str) -> bool:
    """Return True if value looks like a UUID (can be used as environment ID)."""
    if not value or not isinstance(value, str):
        return False
    try:
        uuid.UUID(value.strip())
        return True
    except (ValueError, AttributeError, TypeError):
        return False


def _resolve_environment_id(client, environment: str) -> str:
    """
    Resolve environment name or ID to an environment UUID.
    If environment is already a UUID, return it; otherwise query by name and return the single match's id.
    """
    env = environment.strip()
    if _is_environment_uuid(env):
        return env
    filters = build_query_filter({"name": env})
    environments = client.query_environments(filters)
    if not environments.get("result"):
        raise click.UsageError(f"Environment '{env}' not found.")
    if len(environments["result"]) > 1:
        raise click.UsageError(
            f"Multiple environments found with name '{env}'. Use --environment-id to specify the environment."
        )
    resolved_id = environments["result"][0].get("id")
    if not resolved_id:
        raise click.UsageError(f"Environment '{env}' returned no id.")
    return resolved_id


def _build_deployed_query_filter(
    raw_filters: dict, deployed_after: Optional[str], deployed_before: Optional[str]
) -> dict:
    """Build QueryFilter for deployed package query, with optional date range."""
    expressions = []
    if deployed_after:
        expressions.append(
            {
                "property": "deployedDate",
                "operator": "GREATER_THAN_OR_EQUAL",
                "argument": [_normalize_deployed_date(deployed_after, end_of_day=False)],
            }
        )
    if deployed_before:
        expressions.append(
            {
                "property": "deployedDate",
                "operator": "LESS_THAN_OR_EQUAL",
                "argument": [_normalize_deployed_date(deployed_before, end_of_day=True)],
            }
        )
    for prop, val in raw_filters.items():
        expressions.append(
            {
                "property": prop,
                "operator": "EQUALS",
                "argument": [val] if not isinstance(val, list) else val,
            }
        )
    if not expressions:
        return {}
    if len(expressions) == 1:
        return {"QueryFilter": {"expression": expressions[0]}}
    return {"QueryFilter": {"expression": {"operator": "and", "nestedExpression": expressions}}}


@command.command("query")
@click.pass_context
@click.option("--environment-id", help="Filter by environment ID (UUID)")
@click.option(
    "--environment",
    help="Filter by environment name or ID (UUID). If name, resolved to ID before query. Ignored if --environment-id is set.",
)
@click.option("--package-id", help="Filter by package ID")
@click.option("--component-id", help="Filter by component ID")
@click.option(
    "--component-type",
    help="Filter by component type (e.g. process, webservice)",
)
@click.option(
    "--active",
    is_flag=True,
    default=None,
    help="Filter by active deployments only",
)
@click.option("--deployment-id", help="Filter by deployment ID")
@click.option("--deployed-by", help="Filter by deployer user ID")
@click.option(
    "--deployed-after",
    help="Filter deployments on or after this date (YYYY-MM-DD or ISO 8601).",
)
@click.option(
    "--deployed-before",
    help="Filter deployments on or before this date (YYYY-MM-DD or ISO 8601).",
)
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: deployed_query.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def query(
    ctx,
    environment_id,
    environment,
    package_id,
    component_id,
    component_type,
    active,
    deployment_id,
    deployed_by,
    deployed_after,
    deployed_before,
    output_format,
    save,
    save_filename,
    quiet,
):
    """Query deployed packages using filter criteria."""
    try:
        accept = "application/xml" if output_format == "xml" else None
        base_kw = {
            "account_id": ctx.obj.get("account_id"),
            "username": ctx.obj.get("username"),
            "api_token": ctx.obj.get("api_token"),
        }
        raw_filters = {}
        effective_environment_id = None
        if environment_id:
            effective_environment_id = environment_id
            client = get_client(**base_kw, accept=accept)
        elif environment:
            if accept:
                effective_environment_id = _resolve_environment_id(
                    get_client(**base_kw, accept=None), environment
                )
                client = get_client(**base_kw, accept=accept)
            else:
                client = get_client(**base_kw, accept=None)
                effective_environment_id = _resolve_environment_id(client, environment)
        else:
            client = get_client(**base_kw, accept=accept)
        if effective_environment_id:
            raw_filters["environmentId"] = effective_environment_id
        if package_id:
            raw_filters["packageId"] = package_id
        if component_id:
            raw_filters["componentId"] = component_id
        if component_type:
            raw_filters["componentType"] = component_type
        if active is not None:
            raw_filters["active"] = active
        if deployment_id:
            raw_filters["deploymentId"] = deployment_id
        if deployed_by:
            raw_filters["deployedBy"] = deployed_by

        if deployed_after or deployed_before:
            filters = _build_deployed_query_filter(raw_filters, deployed_after, deployed_before)
            results = (
                client.deployment.query_deployed_packages(filters)
                if filters
                else client.deployment.query_deployed_packages()
            )
        elif raw_filters:
            filters = build_query_filter(raw_filters)
            results = client.deployment.query_deployed_packages(filters)
        else:
            results = client.deployment.query_deployed_packages()

        formatted = format_output(results, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "deployed_query.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except click.UsageError:
        raise
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("query-more")
@click.pass_context
@click.option("--query-token", required=True, help="Pagination token from a previous query")
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: deployed_query_more.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def query_more(ctx, query_token, output_format, save, save_filename, quiet):
    """Retrieve the next page of deployed package query results."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml" if output_format == "xml" else None,
        )
        results = client.deployment.query_more_deployed_packages(query_token)
        formatted = format_output(results, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "deployed_query_more.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
