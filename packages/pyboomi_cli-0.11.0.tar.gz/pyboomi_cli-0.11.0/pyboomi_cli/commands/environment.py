# PyBoomi CLI - Environment Commands
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Author: Robert Little
# Created: 2026-01-26

"""Environment management commands for PyBoomi CLI."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import json
import sys
from typing import Optional

import click

from pyboomi_cli.commands.deployed import _resolve_environment_id
from pyboomi_cli.utils import (
    PLATFORM_OUTPUT_FORMATS,
    accept_header_for_output_format,
    format_output,
    get_client,
)

try:
    from pyboomi_platform.exceptions import BoomiAPIError
except (ImportError, AttributeError):
    try:
        from pyboomi_platform import BoomiAPIError  # type: ignore[attr-defined]
    except (ImportError, AttributeError):

        class BoomiAPIError(Exception):  # type: ignore[no-redef]
            """Fallback exception for Boomi API errors."""

            pass


try:
    from pyboomi_platform.utils import build_query_filter
except (ImportError, AttributeError):

    def build_query_filter(filters):
        """Fallback query filter builder."""
        return filters


def _extensions_auth_kw(ctx: click.Context) -> dict:
    """Credential kwargs for get_client from the environment extensions command context."""
    return {
        "account_id": ctx.parent.obj.get("account_id"),
        "username": ctx.parent.obj.get("username"),
        "api_token": ctx.parent.obj.get("api_token"),
    }


@click.group("environment")
@click.pass_context
@click.option("--account-id", envvar="BOOMI_ACCT", help="Boomi account ID")
@click.option("--username", envvar="BOOMI_USER", help="Boomi user email")
@click.option("--api-token", envvar="BOOMI_TOKEN", help="Boomi Platform API token")
def command(ctx, account_id, username, api_token):
    """
    Manage Boomi environments.

    Priority for credentials:
    - BOOMI_AUTH (base64 encoded Basic Auth string)
    - --username / --api-token CLI args
    - BOOMI_USER / BOOMI_TOKEN env vars

    Account ID can come from --account-id or BOOMI_ACCT env var.

    Note: Options like --account-id must be specified BEFORE the subcommand.
    Example: pyboomi environment --account-id ACCT123 get <env-id>
    """
    ctx.ensure_object(dict)
    ctx.obj["account_id"] = account_id
    ctx.obj["username"] = username
    ctx.obj["api_token"] = api_token


@command.command("get")
@click.pass_context
@click.argument("environment_id", required=False)
@click.option("--name", help="Environment name (alternative to environment ID)")
@click.option(
    "--output-format",
    type=click.Choice(PLATFORM_OUTPUT_FORMATS),
    default="json",
    help="Output format (default: json)",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: environment_get_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def get(ctx, environment_id, name, output_format, save, save_filename, quiet):
    """Get environment by ID or name."""
    if not environment_id and not name:
        raise click.UsageError("Either ENVIRONMENT_ID or --name must be provided.")
    if environment_id and name:
        raise click.UsageError("Provide either ENVIRONMENT_ID or --name, not both.")

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept=accept_header_for_output_format(output_format),
        )

        if environment_id:
            environment = client.get_environment(environment_id)
        else:
            filters = build_query_filter({"name": name})
            environments = client.query_environments(filters)
            if not environments.get("result"):
                raise click.UsageError(f"Environment '{name}' not found.")
            if len(environments["result"]) > 1:
                raise click.UsageError(f"Multiple environments found with name '{name}'. Use environment ID instead.")
            environment = environments["result"][0]

        formatted = format_output(environment, output_format)
        effective_id = environment.get("id") or environment_id or name or "unknown"
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"environment_get_{effective_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("query")
@click.pass_context
@click.option("--name", help="Filter by environment name")
@click.option("--classification", help="Filter by classification (e.g., PRODUCTION, TEST)")
@click.option("--id", "environment_id", help="Filter by environment ID")
@click.option(
    "--output-format",
    type=click.Choice(PLATFORM_OUTPUT_FORMATS),
    default="json",
    help="Output format (default: json)",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: environment_query.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def query(ctx, name, classification, environment_id, output_format, save, save_filename, quiet):
    """Query environments with optional filters."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept=accept_header_for_output_format(output_format),
        )

        raw_filters = {}
        if name:
            raw_filters["name"] = name
        if classification:
            raw_filters["classification"] = classification
        if environment_id:
            raw_filters["id"] = environment_id

        if raw_filters:
            filters = build_query_filter(raw_filters)
            environments = client.query_environments(filters)
        else:
            environments = client.query_environments()

        formatted = format_output(environments, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "environment_query.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# Add alias for query command
command.add_command(query, name="q")


def _extensions_save_and_print(
    formatted: str,
    effective_id: str,
    save: bool,
    save_filename: Optional[str],
    quiet: bool,
    default_filename: str,
) -> None:
    """Write extensions output to file if requested, then print unless quiet."""
    # Pass save_filename as Click provides it (None when omitted). Do not coerce to "" —
    # empty string is not None and would incorrectly enable should_save.
    should_save = save or (save_filename is not None)
    if should_save:
        filename = (
            save_filename.strip()
            if save_filename and save_filename.strip()
            else default_filename.format(id=effective_id)
        )
        with open(filename, "w", encoding="utf-8") as f:
            f.write(formatted)
        click.echo(f"Saved to {filename}", err=True)
    if not quiet:
        click.echo(formatted)


@command.group("extensions")
@click.pass_context
def extensions(ctx):
    """
    Environment extensions (process/runtime overrides: connections, properties, etc.).

    Uses the Boomi EnvironmentExtensions API via client.environment on BoomiPlatformClient.
    For multi-install integration packs, prefer query with --extension-group-id.

    Global options (--account-id, credentials) go before 'extensions', e.g.:
    pyboomi environment --account-id ACCT extensions get <environment-uuid>
    """
    # Forward parent dict so subcommands can use ctx.parent.obj like top-level commands.
    if ctx.parent is not None:
        ctx.obj = ctx.parent.obj


@extensions.command("get")
@click.pass_context
@click.argument("extensions_id", required=False)
@click.option(
    "--name",
    help="Environment name; resolved to environment ID used as EnvironmentExtensions GET id (typical case).",
)
@click.option(
    "--output-format",
    type=click.Choice(PLATFORM_OUTPUT_FORMATS),
    default="json",
    help="Output format (default: json)",
)
@click.option(
    "--save",
    is_flag=True,
    default=False,
    help="Save output to file (default: environment_extensions_get_<id>.json).",
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def extensions_get(
    ctx, extensions_id, name, output_format, save, save_filename, quiet
):
    """Get EnvironmentExtensions by id (usually the environment UUID) or by environment name."""
    if not extensions_id and not name:
        raise click.UsageError("Either EXTENSIONS_ID or --name must be provided.")
    if extensions_id and name:
        raise click.UsageError("Provide either EXTENSIONS_ID or --name, not both.")

    try:
        accept = accept_header_for_output_format(output_format)
        base_kw = _extensions_auth_kw(ctx)

        # Name resolution uses query_environments and requires JSON; do not reuse a client
        # whose session requests application/xml for the final extensions GET.
        if name:
            if accept:
                ext_id = _resolve_environment_id(get_client(**base_kw, accept=None), name)
                client = get_client(**base_kw, accept=accept)
            else:
                client = get_client(**base_kw, accept=None)
                ext_id = _resolve_environment_id(client, name)
        else:
            ext_id = extensions_id.strip()
            client = get_client(**base_kw, accept=accept)

        data = client.environment.get_environment_extensions(ext_id)
        formatted = format_output(data, output_format)
        if isinstance(data, dict):
            effective_id = data.get("id") or data.get("environmentId") or ext_id or "unknown"
        else:
            effective_id = ext_id or "unknown"
        _extensions_save_and_print(
            formatted,
            str(effective_id),
            save,
            save_filename,
            quiet,
            "environment_extensions_get_{id}.json",
        )
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except click.UsageError:
        raise
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@extensions.command("query")
@click.pass_context
@click.option("--environment-id", help="Filter by environment ID (UUID)")
@click.option(
    "--name",
    help="Environment name; resolved to environmentId in the query filter.",
)
@click.option(
    "--extension-group-id",
    help="Optional filter for multi-install integration pack instances (use with environment).",
)
@click.option(
    "--output-format",
    type=click.Choice(PLATFORM_OUTPUT_FORMATS),
    default="json",
    help="Output format (default: json)",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file.")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def extensions_query(
    ctx,
    environment_id,
    name,
    extension_group_id,
    output_format,
    save,
    save_filename,
    quiet,
):
    """Query EnvironmentExtensions (e.g. by environmentId and optional extensionGroupId)."""
    if not environment_id and not name:
        raise click.UsageError("Provide --environment-id or --name.")
    if environment_id and name:
        raise click.UsageError("Provide either --environment-id or --name, not both.")

    try:
        accept = accept_header_for_output_format(output_format)
        base_kw = _extensions_auth_kw(ctx)

        if environment_id:
            env_id = environment_id.strip()
            client = get_client(**base_kw, accept=accept)
        else:
            if accept:
                env_id = _resolve_environment_id(get_client(**base_kw, accept=None), name)
                client = get_client(**base_kw, accept=accept)
            else:
                client = get_client(**base_kw, accept=None)
                env_id = _resolve_environment_id(client, name)

        raw_filters = {"environmentId": env_id}
        if extension_group_id:
            raw_filters["extensionGroupId"] = extension_group_id.strip()
        filters = build_query_filter(raw_filters)
        data = client.environment.query_environment_extensions(filters)
        formatted = format_output(data, output_format)
        effective_id = env_id
        _extensions_save_and_print(
            formatted,
            effective_id,
            save,
            save_filename,
            quiet,
            "environment_extensions_query_{id}.json",
        )
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except click.UsageError:
        raise
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@extensions.command("query-more")
@click.pass_context
@click.argument("query_token")
@click.option(
    "--output-format",
    type=click.Choice(PLATFORM_OUTPUT_FORMATS),
    default="json",
    help="Output format (default: json)",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file.")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def extensions_query_more(ctx, query_token, output_format, save, save_filename, quiet):
    """Fetch next page of an EnvironmentExtensions query using queryToken from a prior query."""
    try:
        client = get_client(
            account_id=ctx.parent.obj.get("account_id"),
            username=ctx.parent.obj.get("username"),
            api_token=ctx.parent.obj.get("api_token"),
            accept=accept_header_for_output_format(output_format),
        )
        data = client.environment.query_more_environment_extensions(query_token)
        formatted = format_output(data, output_format)
        _extensions_save_and_print(
            formatted,
            "more",
            save,
            save_filename,
            quiet,
            "environment_extensions_query_more.json",
        )
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@extensions.command("bulk")
@click.pass_context
@click.argument("ids", nargs=-1, required=True)
@click.option(
    "--output-format",
    type=click.Choice(PLATFORM_OUTPUT_FORMATS),
    default="json",
    help="Output format (default: json)",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file.")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def extensions_bulk(ctx, ids, output_format, save, save_filename, quiet):
    """Bulk GET EnvironmentExtensions by one or more ids."""
    id_list = [i.strip() for i in ids if i and str(i).strip()]
    if not id_list:
        raise click.UsageError("Provide at least one EXTENSIONS_ID.")

    try:
        client = get_client(
            account_id=ctx.parent.obj.get("account_id"),
            username=ctx.parent.obj.get("username"),
            api_token=ctx.parent.obj.get("api_token"),
            accept=accept_header_for_output_format(output_format),
        )
        data = client.environment.get_environment_extensions_bulk(id_list)
        formatted = format_output(data, output_format)
        _extensions_save_and_print(
            formatted,
            "bulk",
            save,
            save_filename,
            quiet,
            "environment_extensions_bulk.json",
        )
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except click.UsageError:
        raise
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@extensions.command("update")
@click.pass_context
@click.argument("extensions_id")
@click.option(
    "--json-file",
    "json_path",
    required=True,
    type=click.Path(exists=True, dir_okay=False, readable=True),
    help="JSON file whose top-level keys are merged into the update request body.",
)
@click.option(
    "--output-format",
    type=click.Choice(PLATFORM_OUTPUT_FORMATS),
    default="json",
    help="Output format (default: json)",
)
@click.option("--save", is_flag=True, default=False, help="Save response to file.")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save response path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress response to stdout.")
def extensions_update(
    ctx, extensions_id, json_path, output_format, save, save_filename, quiet
):
    """Update EnvironmentExtensions (POST). Use Boomi docs for partial vs full update and payload shape."""
    try:
        with open(json_path, encoding="utf-8") as f:
            body = json.load(f)
        if not isinstance(body, dict):
            raise click.UsageError("JSON root must be an object.")

        client = get_client(
            account_id=ctx.parent.obj.get("account_id"),
            username=ctx.parent.obj.get("username"),
            api_token=ctx.parent.obj.get("api_token"),
            accept=accept_header_for_output_format(output_format),
        )
        data = client.environment.update_environment_extensions(
            extensions_id.strip(), **body
        )
        formatted = format_output(data, output_format)
        effective_id = extensions_id.strip() or "unknown"
        _extensions_save_and_print(
            formatted,
            effective_id,
            save,
            save_filename,
            quiet,
            "environment_extensions_update_{id}.json",
        )
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except click.UsageError:
        raise
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


command.add_command(extensions)
