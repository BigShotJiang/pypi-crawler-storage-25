# PyBoomi CLI - Process Command
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-12-12

"""Process management commands for PyBoomi CLI."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import click


@click.command()
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: processes.txt).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def command(save, save_filename, quiet):
    """List or manage processes from the Boomi Platform API."""
    output_msg = "Processes command executed."
    should_save = save or (save_filename is not None)
    if should_save:
        filename = save_filename.strip() if save_filename and save_filename.strip() else "processes.txt"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(output_msg + "\n")
        click.echo(f"Saved to {filename}", err=True)
    if not quiet:
        click.echo(output_msg)
