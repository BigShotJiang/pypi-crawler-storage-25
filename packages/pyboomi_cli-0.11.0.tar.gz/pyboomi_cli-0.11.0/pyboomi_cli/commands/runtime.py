# PyBoomi CLI - Runtime Management Commands
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Boomi Runtime Management API commands (via pyboomi_platform RuntimeManagementClient)."""

from __future__ import annotations

import json
import sys
from typing import Any, Dict, List, Optional

import click

from pyboomi_cli.utils import (
    PLATFORM_OUTPUT_FORMATS,
    accept_header_for_output_format,
    format_output,
    get_client,
)

try:
    from pyboomi_platform.exceptions import BoomiAPIError
except (ImportError, AttributeError):
    try:
        from pyboomi_platform import BoomiAPIError  # type: ignore[attr-defined]
    except (ImportError, AttributeError):

        class BoomiAPIError(Exception):  # type: ignore[no-redef]
            """Fallback exception for Boomi API errors."""

            pass


try:
    from pyboomi_platform.utils import build_query_filter
except (ImportError, AttributeError):

    def build_query_filter(filters):  # type: ignore[no-untyped-def]
        return filters


def _read_json_value(value: Optional[str], default: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Parse JSON from inline string or @path (UTF-8 file)."""
    if value is None or not str(value).strip():
        return dict(default or {})
    s = str(value).strip()
    if s.startswith("@"):
        path = s[1:].strip()
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return json.loads(s)


def _flatten_id_args(ids: tuple) -> List[str]:
    out: List[str] = []
    for part in ids:
        if "," in part:
            out.extend(p.strip() for p in part.split(",") if p.strip())
        elif part.strip():
            out.append(part.strip())
    return out


def _first_download_url(obj: Any) -> Optional[str]:
    """Best-effort find an HTTP(S) URL in a Boomi JSON response for log downloads."""
    if isinstance(obj, dict):
        for key, val in obj.items():
            lk = key.lower().replace("_", "")
            if lk in ("url", "downloadurl", "link", "href") and isinstance(val, str) and val.startswith("http"):
                return val
            nested = _first_download_url(val)
            if nested:
                return nested
    elif isinstance(obj, list):
        for item in obj:
            nested = _first_download_url(item)
            if nested:
                return nested
    return None


def _emit(
    data: Any,
    output_format: str,
    save: bool,
    save_filename: Optional[str],
    quiet: bool,
    default_filename: str,
) -> None:
    formatted = format_output(data, output_format)
    should_save = save or (save_filename is not None)
    if should_save:
        filename = (
            save_filename.strip()
            if save_filename and save_filename.strip()
            else default_filename
        )
        with open(filename, "w", encoding="utf-8") as f:
            f.write(formatted)
        click.echo(f"Saved to {filename}", err=True)
    if not quiet:
        click.echo(formatted)


def _resolve_cli_obj(ctx: click.Context) -> dict:
    """Find ctx.obj from this context or an ancestor (nested groups)."""
    c: Optional[click.Context] = ctx
    while c is not None:
        obj = getattr(c, "obj", None)
        if obj:
            return obj
        c = c.parent
    return {}


def _handle_cli_error(exc: BaseException) -> None:
    if isinstance(exc, BoomiAPIError):
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)
    click.echo(f"Error: {exc}", err=True)
    sys.exit(1)


@click.group("runtime")
@click.pass_context
@click.option("--account-id", envvar="BOOMI_ACCT", help="Boomi account ID")
@click.option("--username", envvar="BOOMI_USER", help="Boomi user email")
@click.option("--api-token", envvar="BOOMI_TOKEN", help="Boomi Platform API token")
def command(ctx, account_id, username, api_token):
    """
    Boomi Runtime Management (atoms, clouds, restarts, queues, etc.).

    Uses pyboomi_platform RuntimeManagementClient (client.runtime_management).

    Credentials: BOOMI_AUTH, or --username/--api-token, or BOOMI_USER/BOOMI_TOKEN.
    Account: --account-id or BOOMI_ACCT.

    Put global options before the subcommand, e.g. pyboomi runtime --account-id X atom get <id>
    """
    ctx.ensure_object(dict)
    ctx.obj["account_id"] = account_id
    ctx.obj["username"] = username
    ctx.obj["api_token"] = api_token


def _rm_client(ctx: click.Context, output_format: str = "json"):
    obj = _resolve_cli_obj(ctx)
    return get_client(
        account_id=obj.get("account_id"),
        username=obj.get("username"),
        api_token=obj.get("api_token"),
        accept=accept_header_for_output_format(output_format),
    )


# --- Atom -----------------------------------------------------------------

atom = click.Group("atom", help="Atom (runtime) operations.")


@atom.command("create")
@click.pass_context
@click.option("--cloud-id", required=True, help="Cloud ID to create the atom under")
@click.option("--name", required=True, help="Atom name")
@click.option(
    "--output-format",
    type=click.Choice(PLATFORM_OUTPUT_FORMATS),
    default="json",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file")
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_create(ctx, cloud_id, name, output_format, save, save_filename, quiet):
    """Create an atom."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.create_atom(cloud_id, name)
        _emit(data, output_format, save, save_filename, quiet, "runtime_atom_create.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("get")
@click.pass_context
@click.argument("atom_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_get(ctx, atom_id, output_format, save, save_filename, quiet):
    """Get an atom by ID."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_atom(atom_id)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_atom_get_{atom_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("update")
@click.pass_context
@click.argument("atom_id")
@click.option("--name", default=None, help="New atom name")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_update(ctx, atom_id, name, output_format, save, save_filename, quiet):
    """Update an atom."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.update_atom(atom_id, name=name)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_atom_update_{atom_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("delete")
@click.pass_context
@click.argument("atom_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_delete(ctx, atom_id, output_format, save, save_filename, quiet):
    """Delete an atom."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.delete_atom(atom_id)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_atom_delete_{atom_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("bulk")
@click.pass_context
@click.argument("atom_ids", nargs=-1, required=True)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_bulk(ctx, atom_ids, output_format, save, save_filename, quiet):
    """Get multiple atoms by ID (space- or comma-separated, max 100)."""
    ids = _flatten_id_args(atom_ids)
    if len(ids) > 100:
        click.echo("Error: Maximum 100 atom IDs allowed.", err=True)
        sys.exit(1)
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_atom_bulk(ids)
        _emit(data, output_format, save, save_filename, quiet, "runtime_atom_bulk.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("query")
@click.pass_context
@click.option("--name", default=None, help="Filter by name (simple query)")
@click.option("--id", "object_id", default=None, help="Filter by id")
@click.option(
    "--filters",
    "filter_json",
    default=None,
    help="Raw QueryFilter JSON, or @path.json",
)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_query(ctx, name, object_id, filter_json, output_format, save, save_filename, quiet):
    """Query atoms."""
    try:
        c = _rm_client(ctx, output_format)
        if filter_json:
            filters = _read_json_value(filter_json)
        elif name or object_id:
            raw: Dict[str, Any] = {}
            if name:
                raw["name"] = name
            if object_id:
                raw["id"] = object_id
            filters = build_query_filter(raw)
        else:
            filters = {}
        data = c.runtime_management.query_atom(filters)
        _emit(data, output_format, save, save_filename, quiet, "runtime_atom_query.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("query-more")
@click.pass_context
@click.argument("query_token")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_query_more(ctx, query_token, output_format, save, save_filename, quiet):
    """Next page of atom query (continuation token from prior query)."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.query_more_atom(query_token)
        _emit(data, output_format, save, save_filename, quiet, "runtime_atom_query_more.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("update-counters")
@click.pass_context
@click.argument("counter_id")
@click.option(
    "--body",
    required=True,
    help="JSON object of counter fields, or @file.json",
)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_update_counters(ctx, counter_id, body, output_format, save, save_filename, quiet):
    """Update atom counters (per SDK; counter_id is the resource id)."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.update_atom_counters(counter_id, payload)
        _emit(data, output_format, save, save_filename, quiet, "runtime_atom_counters.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("connector-versions")
@click.pass_context
@click.argument("atom_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_connector_versions(ctx, atom_id, output_format, save, save_filename, quiet):
    """Get connector versions for an atom."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_atom_connector_versions(atom_id)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_atom_connector_versions_{atom_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("connector-versions-bulk")
@click.pass_context
@click.argument("atom_ids", nargs=-1, required=True)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_connector_versions_bulk(ctx, atom_ids, output_format, save, save_filename, quiet):
    """Bulk connector versions for atoms."""
    ids = _flatten_id_args(atom_ids)
    if len(ids) > 100:
        click.echo("Error: Maximum 100 atom IDs allowed.", err=True)
        sys.exit(1)
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_atom_connector_versions_bulk(ids)
        _emit(data, output_format, save, save_filename, quiet, "runtime_atom_connector_versions_bulk.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("log-request")
@click.pass_context
@click.argument("atom_id")
@click.option(
    "--body",
    default=None,
    help="Optional extra JSON fields merged into request, or @file.json",
)
@click.option(
    "--download",
    "download_path",
    default=None,
    type=str,
    help="If response contains a URL, download to this path",
)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_log_request(ctx, atom_id, body, download_path, output_format, save, save_filename, quiet):
    """Request an atom log (optional file download if URL returned)."""
    try:
        c = _rm_client(ctx, output_format)
        extra = _read_json_value(body) if body else {}
        data = c.runtime_management.create_atom_log(atom_id, **extra)
        if download_path:
            url = _first_download_url(data)
            if url:
                c.download_to_path(url, download_path)
                click.echo(f"Downloaded log to {download_path}", err=True)
            else:
                click.echo("Warning: No download URL found in response; skipping --download.", err=True)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_atom_log_{atom_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("worker-log-request")
@click.pass_context
@click.argument("atom_id")
@click.option("--body", default=None, help="Optional extra JSON, or @file.json")
@click.option("--download", "download_path", default=None, type=str)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_worker_log_request(ctx, atom_id, body, download_path, output_format, save, save_filename, quiet):
    """Request an atom worker log."""
    try:
        c = _rm_client(ctx, output_format)
        extra = _read_json_value(body) if body else {}
        data = c.runtime_management.create_atom_worker_log(atom_id, **extra)
        if download_path:
            url = _first_download_url(data)
            if url:
                c.download_to_path(url, download_path)
                click.echo(f"Downloaded worker log to {download_path}", err=True)
            else:
                click.echo("Warning: No download URL found in response; skipping --download.", err=True)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_atom_worker_log_{atom_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("purge-update")
@click.pass_context
@click.argument("atom_id")
@click.option("--body", required=True, help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_purge_update(ctx, atom_id, body, output_format, save, save_filename, quiet):
    """Update atom purge settings."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.update_atom_purge(atom_id, **payload)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_atom_purge_{atom_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("security-policies-update")
@click.pass_context
@click.argument("atom_id")
@click.option("--body", required=True, help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_security_policies_update(ctx, atom_id, body, output_format, save, save_filename, quiet):
    """Update atom security policies."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.update_atom_security_policies(atom_id, **payload)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_atom_security_{atom_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("startup-properties")
@click.pass_context
@click.argument("atom_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_startup_properties(ctx, atom_id, output_format, save, save_filename, quiet):
    """Get atom startup properties."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_atom_startup_properties(atom_id)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_atom_startup_{atom_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@atom.command("startup-properties-bulk")
@click.pass_context
@click.argument("atom_ids", nargs=-1, required=True)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def atom_startup_properties_bulk(ctx, atom_ids, output_format, save, save_filename, quiet):
    """Bulk get atom startup properties."""
    ids = _flatten_id_args(atom_ids)
    if len(ids) > 100:
        click.echo("Error: Maximum 100 atom IDs allowed.", err=True)
        sys.exit(1)
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_atom_startup_properties_bulk(ids)
        _emit(data, output_format, save, save_filename, quiet, "runtime_atom_startup_bulk.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(atom, name="atom")


# --- Cloud ----------------------------------------------------------------

cloud = click.Group("cloud", help="Cloud operations.")


@cloud.command("get")
@click.pass_context
@click.argument("cloud_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def cloud_get(ctx, cloud_id, output_format, save, save_filename, quiet):
    """Get a cloud by ID."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_cloud(cloud_id)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_cloud_get_{cloud_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@cloud.command("bulk")
@click.pass_context
@click.argument("cloud_ids", nargs=-1, required=True)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def cloud_bulk(ctx, cloud_ids, output_format, save, save_filename, quiet):
    """Bulk get clouds by ID."""
    ids = _flatten_id_args(cloud_ids)
    if len(ids) > 100:
        click.echo("Error: Maximum 100 cloud IDs allowed.", err=True)
        sys.exit(1)
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_cloud_bulk(ids)
        _emit(data, output_format, save, save_filename, quiet, "runtime_cloud_bulk.json")
    except Exception as e:
        _handle_cli_error(e)


@cloud.command("query")
@click.pass_context
@click.option("--name", default=None)
@click.option("--id", "object_id", default=None)
@click.option("--filters", "filter_json", default=None, help="Raw QueryFilter JSON or @path")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def cloud_query(ctx, name, object_id, filter_json, output_format, save, save_filename, quiet):
    """Query clouds."""
    try:
        c = _rm_client(ctx, output_format)
        if filter_json:
            filters = _read_json_value(filter_json)
        elif name or object_id:
            raw = {}
            if name:
                raw["name"] = name
            if object_id:
                raw["id"] = object_id
            filters = build_query_filter(raw)
        else:
            filters = {}
        data = c.runtime_management.query_cloud(filters)
        _emit(data, output_format, save, save_filename, quiet, "runtime_cloud_query.json")
    except Exception as e:
        _handle_cli_error(e)


@cloud.command("query-more")
@click.pass_context
@click.argument("query_token")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def cloud_query_more(ctx, query_token, output_format, save, save_filename, quiet):
    """Next page of cloud query."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.query_more_cloud(query_token)
        _emit(data, output_format, save, save_filename, quiet, "runtime_cloud_query_more.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(cloud, name="cloud")


# --- Shared web server / shared server information ------------------------

shared_web_server = click.Group("shared-web-server", help="SharedWebServer operations.")


@shared_web_server.command("get")
@click.pass_context
@click.argument("resource_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def sws_get(ctx, resource_id, output_format, save, save_filename, quiet):
    """Get SharedWebServer by ID."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_shared_web_server(resource_id)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_sws_get_{resource_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@shared_web_server.command("bulk")
@click.pass_context
@click.argument("resource_ids", nargs=-1, required=True)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def sws_bulk(ctx, resource_ids, output_format, save, save_filename, quiet):
    """Bulk get SharedWebServer."""
    ids = _flatten_id_args(resource_ids)
    if len(ids) > 100:
        click.echo("Error: Maximum 100 IDs allowed.", err=True)
        sys.exit(1)
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_shared_web_server_bulk(ids)
        _emit(data, output_format, save, save_filename, quiet, "runtime_sws_bulk.json")
    except Exception as e:
        _handle_cli_error(e)


@shared_web_server.command("update")
@click.pass_context
@click.argument("resource_id")
@click.option("--body", required=True, help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def sws_update(ctx, resource_id, body, output_format, save, save_filename, quiet):
    """Update SharedWebServer."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.update_shared_web_server(resource_id, **payload)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_sws_update_{resource_id}.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(shared_web_server, name="shared-web-server")


shared_server_information = click.Group(
    "shared-server-information",
    help="SharedServerInformation operations.",
)


@shared_server_information.command("get")
@click.pass_context
@click.argument("resource_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def ssi_get(ctx, resource_id, output_format, save, save_filename, quiet):
    """Get SharedServerInformation by ID."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_shared_server_information(resource_id)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_ssi_get_{resource_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@shared_server_information.command("bulk")
@click.pass_context
@click.argument("resource_ids", nargs=-1, required=True)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def ssi_bulk(ctx, resource_ids, output_format, save, save_filename, quiet):
    """Bulk get SharedServerInformation."""
    ids = _flatten_id_args(resource_ids)
    if len(ids) > 100:
        click.echo("Error: Maximum 100 IDs allowed.", err=True)
        sys.exit(1)
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_shared_server_information_bulk(ids)
        _emit(data, output_format, save, save_filename, quiet, "runtime_ssi_bulk.json")
    except Exception as e:
        _handle_cli_error(e)


@shared_server_information.command("update")
@click.pass_context
@click.argument("resource_id")
@click.option("--body", required=True, help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def ssi_update(ctx, resource_id, body, output_format, save, save_filename, quiet):
    """Update SharedServerInformation."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.update_shared_server_information(resource_id, **payload)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_ssi_update_{resource_id}.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(shared_server_information, name="shared-server-information")


# --- Runtime restart / release schedule / properties ----------------------

restart_request = click.Group("restart-request", help="RuntimeRestartRequest operations.")


@restart_request.command("create")
@click.pass_context
@click.option("--body", default="{}", help="JSON body, or @file.json (default: {})")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def restart_create(ctx, body, output_format, save, save_filename, quiet):
    """Create a runtime restart request."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.create_runtime_restart_request(**payload)
        _emit(data, output_format, save, save_filename, quiet, "runtime_restart_create.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(restart_request, name="restart-request")


release_schedule = click.Group("release-schedule", help="RuntimeReleaseSchedule operations.")


@release_schedule.command("get")
@click.pass_context
@click.argument("schedule_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def rs_get(ctx, schedule_id, output_format, save, save_filename, quiet):
    """Get RuntimeReleaseSchedule by ID."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_runtime_release_schedule(schedule_id)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_rs_get_{schedule_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@release_schedule.command("create")
@click.pass_context
@click.option("--body", default="{}", help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def rs_create(ctx, body, output_format, save, save_filename, quiet):
    """Create RuntimeReleaseSchedule."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.create_runtime_release_schedule(**payload)
        _emit(data, output_format, save, save_filename, quiet, "runtime_rs_create.json")
    except Exception as e:
        _handle_cli_error(e)


@release_schedule.command("update")
@click.pass_context
@click.argument("schedule_id")
@click.option("--body", required=True, help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def rs_update(ctx, schedule_id, body, output_format, save, save_filename, quiet):
    """Update RuntimeReleaseSchedule."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.update_runtime_release_schedule(schedule_id, **payload)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_rs_update_{schedule_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@release_schedule.command("delete")
@click.pass_context
@click.argument("schedule_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def rs_delete(ctx, schedule_id, output_format, save, save_filename, quiet):
    """Delete RuntimeReleaseSchedule."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.delete_runtime_release_schedule(schedule_id)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_rs_delete_{schedule_id}.json")
    except Exception as e:
        _handle_cli_error(e)


@release_schedule.command("bulk")
@click.pass_context
@click.argument("schedule_ids", nargs=-1, required=True)
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def rs_bulk(ctx, schedule_ids, output_format, save, save_filename, quiet):
    """Bulk get RuntimeReleaseSchedule."""
    ids = _flatten_id_args(schedule_ids)
    if len(ids) > 100:
        click.echo("Error: Maximum 100 IDs allowed.", err=True)
        sys.exit(1)
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_runtime_release_schedule_bulk(ids)
        _emit(data, output_format, save, save_filename, quiet, "runtime_rs_bulk.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(release_schedule, name="release-schedule")


runtime_properties = click.Group("runtime-properties", help="RuntimeProperties operations.")


@runtime_properties.command("update")
@click.pass_context
@click.argument("resource_id")
@click.option("--body", required=True, help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def rp_update(ctx, resource_id, body, output_format, save, save_filename, quiet):
    """Update RuntimeProperties."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.update_runtime_properties(resource_id, **payload)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_props_update_{resource_id}.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(runtime_properties, name="runtime-properties")


observability = click.Group("observability-settings", help="RuntimeObservabilitySettings operations.")


@observability.command("update")
@click.pass_context
@click.argument("resource_id")
@click.option("--body", required=True, help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def obs_update(ctx, resource_id, body, output_format, save, save_filename, quiet):
    """Update RuntimeObservabilitySettings."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.update_runtime_observability_settings(resource_id, **payload)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_obs_update_{resource_id}.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(observability, name="observability-settings")


# --- Node offboard, move queue, Java, installer, certificates, clear queue

node_offboard = click.Group("node-offboard", help="NodeOffboard operations.")


@node_offboard.command("create")
@click.pass_context
@click.option("--body", default="{}", help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def no_create(ctx, body, output_format, save, save_filename, quiet):
    """Create a node offboard request."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.create_node_offboard(**payload)
        _emit(data, output_format, save, save_filename, quiet, "runtime_node_offboard.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(node_offboard, name="node-offboard")


move_queue = click.Group("move-queue-request", help="MoveQueueRequest operations.")


@move_queue.command("create")
@click.pass_context
@click.option("--body", default="{}", help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def mq_create(ctx, body, output_format, save, save_filename, quiet):
    """Create a move-queue request."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.create_move_queue_request(**payload)
        _emit(data, output_format, save, save_filename, quiet, "runtime_move_queue.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(move_queue, name="move-queue-request")


list_queues = click.Group("list-queues", help="Async ListQueues status.")


@list_queues.command("by-token")
@click.pass_context
@click.argument("token")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def lq_by_token(ctx, token, output_format, save, save_filename, quiet):
    """Get ListQueues async result by token."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_list_queues_async_by_token(token)
        _emit(data, output_format, save, save_filename, quiet, "runtime_list_queues_token.json")
    except Exception as e:
        _handle_cli_error(e)


@list_queues.command("by-id")
@click.pass_context
@click.argument("resource_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def lq_by_id(ctx, resource_id, output_format, save, save_filename, quiet):
    """Get ListQueues async result by ID."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_list_queues_async_by_id(resource_id)
        _emit(data, output_format, save, save_filename, quiet, "runtime_list_queues_id.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(list_queues, name="list-queues")


java_upgrade = click.Group("java-upgrade", help="JavaUpgrade operations.")


@java_upgrade.command("create")
@click.pass_context
@click.option("--body", default="{}", help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def ju_create(ctx, body, output_format, save, save_filename, quiet):
    """Create a Java upgrade request."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.create_java_upgrade(**payload)
        _emit(data, output_format, save, save_filename, quiet, "runtime_java_upgrade.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(java_upgrade, name="java-upgrade")


java_rollback = click.Group("java-rollback", help="JavaRollback operations.")


@java_rollback.command("execute")
@click.pass_context
@click.argument("rollback_id")
@click.option("--body", default="{}", help="Optional JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def jr_execute(ctx, rollback_id, body, output_format, save, save_filename, quiet):
    """Execute Java rollback."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.execute_java_rollback(rollback_id, **payload)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_java_rollback_{rollback_id}.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(java_rollback, name="java-rollback")


installer_token = click.Group("installer-token", help="InstallerToken operations.")


@installer_token.command("create")
@click.pass_context
@click.option("--body", default="{}", help="JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def it_create(ctx, body, output_format, save, save_filename, quiet):
    """Create an installer token."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.create_installer_token(**payload)
        _emit(data, output_format, save, save_filename, quiet, "runtime_installer_token.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(installer_token, name="installer-token")


deployed_expired_cert = click.Group(
    "deployed-expired-certificate",
    help="DeployedExpiredCertificate query operations.",
)


@deployed_expired_cert.command("query")
@click.pass_context
@click.option("--name", default=None)
@click.option("--id", "object_id", default=None)
@click.option("--filters", "filter_json", default=None, help="Raw QueryFilter JSON or @path")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def dec_query(ctx, name, object_id, filter_json, output_format, save, save_filename, quiet):
    """Query deployed expired certificates."""
    try:
        c = _rm_client(ctx, output_format)
        if filter_json:
            filters = _read_json_value(filter_json)
        elif name or object_id:
            raw = {}
            if name:
                raw["name"] = name
            if object_id:
                raw["id"] = object_id
            filters = build_query_filter(raw)
        else:
            filters = {}
        data = c.runtime_management.query_deployed_expired_certificate(filters)
        _emit(data, output_format, save, save_filename, quiet, "runtime_deployed_expired_cert.json")
    except Exception as e:
        _handle_cli_error(e)


@deployed_expired_cert.command("query-more")
@click.pass_context
@click.argument("query_token")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def dec_query_more(ctx, query_token, output_format, save, save_filename, quiet):
    """Next page of deployed expired certificate query."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.query_more_deployed_expired_certificate(query_token)
        _emit(data, output_format, save, save_filename, quiet, "runtime_deployed_expired_cert_more.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(deployed_expired_cert, name="deployed-expired-certificate")


clear_queue = click.Group("clear-queue", help="ClearQueue execute.")


@clear_queue.command("execute")
@click.pass_context
@click.argument("resource_id")
@click.option("--body", default="{}", help="Optional JSON body, or @file.json")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def cq_execute(ctx, resource_id, body, output_format, save, save_filename, quiet):
    """Execute clear queue for the given ID."""
    try:
        c = _rm_client(ctx, output_format)
        payload = _read_json_value(body)
        data = c.runtime_management.execute_clear_queue(resource_id, **payload)
        _emit(data, output_format, save, save_filename, quiet, f"runtime_clear_queue_{resource_id}.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(clear_queue, name="clear-queue")


atom_disk_space = click.Group("atom-disk-space", help="Async AtomDiskSpace status.")


@atom_disk_space.command("by-token")
@click.pass_context
@click.argument("token")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def ads_by_token(ctx, token, output_format, save, save_filename, quiet):
    """Get AtomDiskSpace async result by token."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_atom_disk_space_async_by_token(token)
        _emit(data, output_format, save, save_filename, quiet, "runtime_atom_disk_space_token.json")
    except Exception as e:
        _handle_cli_error(e)


@atom_disk_space.command("by-id")
@click.pass_context
@click.argument("resource_id")
@click.option("--output-format", type=click.Choice(PLATFORM_OUTPUT_FORMATS), default="json")
@click.option("--save", is_flag=True, default=False)
@click.option("--save-file", "save_filename", default=None, type=str)
@click.option("--quiet", is_flag=True)
def ads_by_id(ctx, resource_id, output_format, save, save_filename, quiet):
    """Get AtomDiskSpace async result by ID."""
    try:
        c = _rm_client(ctx, output_format)
        data = c.runtime_management.get_atom_disk_space_async_by_id(resource_id)
        _emit(data, output_format, save, save_filename, quiet, "runtime_atom_disk_space_id.json")
    except Exception as e:
        _handle_cli_error(e)


command.add_command(atom_disk_space, name="atom-disk-space")
