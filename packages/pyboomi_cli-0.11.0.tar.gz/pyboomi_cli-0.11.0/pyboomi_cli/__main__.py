"""Allow execution as python -m pyboomi_cli."""

from pyboomi_cli.cli import main

if __name__ == "__main__":
    main()
