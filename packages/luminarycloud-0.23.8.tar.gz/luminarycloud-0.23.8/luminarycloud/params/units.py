# Copyright 2026 Luminary Cloud, Inc. All Rights Reserved.

from dataclasses import dataclass

from luminarycloud._helpers import CodeRepr
from luminarycloud._proto.client import simulation_pb2 as clientpb
import luminarycloud.params.enum._enum_wrappers as enum

from luminarycloud.params._lib import ParamGroupWrapper


@dataclass(kw_only=True)
class Units(CodeRepr, ParamGroupWrapper[clientpb.Units]):
    """Unit settings for a project.

    For SI and US unit systems, individual unit fields are automatically
    overridden by the backend preset. Individual fields only take effect
    for a custom unit system (``UnitSystem.UNIT_SYSTEM_CUSTOM``).
    The defaults for individual fields are consistent with the SI preset.
    """

    unit_system: enum.UnitSystem = enum.UnitSystem.UNIT_SYSTEM_SI
    "Collection of units used for all quantities."
    temperature: enum.TemperatureUnit = enum.TemperatureUnit.UNIT_KELVIN
    "Unit used for temperature."
    mass: enum.MassUnit = enum.MassUnit.UNIT_KILOGRAM
    "Unit used for mass."
    length: enum.LengthUnit = enum.LengthUnit.UNIT_METER
    "Unit used for length."
    angle: enum.AngleUnit = enum.AngleUnit.UNIT_DEGREE
    "Unit used for angles."
    time: enum.TimeUnit = enum.TimeUnit.UNIT_SECOND
    "Unit used for time."
    velocity: enum.VelocityUnit = enum.VelocityUnit.UNIT_METER_PER_SECOND
    "Unit used for velocity."
    angular_velocity: enum.AngularVelocityUnit = enum.AngularVelocityUnit.UNIT_RADIAN_PER_SECOND
    "Unit used for angular velocity."
    force: enum.ForceUnit = enum.ForceUnit.UNIT_NEWTON
    "Unit used for force."
    moment: enum.MomentUnit = enum.MomentUnit.UNIT_NEWTON_METER
    "Unit used for moment."
    pressure: enum.PressureUnit = enum.PressureUnit.UNIT_PASCAL
    "Unit used for pressure."
    energy: enum.EnergyUnit = enum.EnergyUnit.UNIT_JOULE
    "Unit used for energy."
    power: enum.PowerUnit = enum.PowerUnit.UNIT_WATT
    "Unit used for power."
    volume: enum.VolumeUnit = enum.VolumeUnit.UNIT_CUBIC_METER
    "Unit used for volume."
    volumetric_flow: enum.VolumetricFlowUnit = enum.VolumetricFlowUnit.UNIT_CUBIC_METER_PER_SECOND
    "Unit used for volumetric flow."
    viscosity: enum.ViscosityUnit = enum.ViscosityUnit.UNIT_PASCAL_SECOND
    "Unit used for dynamic viscosity."
    conductivity: enum.ConductivityUnit = enum.ConductivityUnit.UNIT_WATT_PER_METER_KELVIN
    "Unit used for thermal conductivity."
    molecular_weight: enum.MolecularWeightUnit = enum.MolecularWeightUnit.UNIT_GRAM_PER_MOLE
    "Unit used for molecular weight."

    def _to_proto(self) -> clientpb.Units:
        _proto = clientpb.Units()
        _proto.unit_system = self.unit_system.value
        _proto.temperature_unit = self.temperature.value
        _proto.mass_unit = self.mass.value
        _proto.length_unit = self.length.value
        _proto.angle_unit = self.angle.value
        _proto.time_unit = self.time.value
        _proto.velocity_unit = self.velocity.value
        _proto.angular_velocity_unit = self.angular_velocity.value
        _proto.force_unit = self.force.value
        _proto.moment_unit = self.moment.value
        _proto.pressure_unit = self.pressure.value
        _proto.energy_unit = self.energy.value
        _proto.power_unit = self.power.value
        _proto.volume_unit = self.volume.value
        _proto.volumetric_flow_unit = self.volumetric_flow.value
        _proto.viscosity_unit = self.viscosity.value
        _proto.conductivity_unit = self.conductivity.value
        _proto.molecular_weight_unit = self.molecular_weight.value
        _proto.heat_flux_convention = enum.HeatFluxConvention.CONVENTION_HEAT_FLUX_OUT.value
        return _proto

    def _from_proto(self, proto: clientpb.Units) -> None:
        if proto.unit_system:
            self.unit_system = enum.UnitSystem(proto.unit_system)
        if proto.temperature_unit:
            self.temperature = enum.TemperatureUnit(proto.temperature_unit)
        if proto.mass_unit:
            self.mass = enum.MassUnit(proto.mass_unit)
        if proto.length_unit:
            self.length = enum.LengthUnit(proto.length_unit)
        if proto.angle_unit:
            self.angle = enum.AngleUnit(proto.angle_unit)
        if proto.time_unit:
            self.time = enum.TimeUnit(proto.time_unit)
        if proto.velocity_unit:
            self.velocity = enum.VelocityUnit(proto.velocity_unit)
        if proto.angular_velocity_unit:
            self.angular_velocity = enum.AngularVelocityUnit(proto.angular_velocity_unit)
        if proto.force_unit:
            self.force = enum.ForceUnit(proto.force_unit)
        if proto.moment_unit:
            self.moment = enum.MomentUnit(proto.moment_unit)
        if proto.pressure_unit:
            self.pressure = enum.PressureUnit(proto.pressure_unit)
        if proto.energy_unit:
            self.energy = enum.EnergyUnit(proto.energy_unit)
        if proto.power_unit:
            self.power = enum.PowerUnit(proto.power_unit)
        if proto.volume_unit:
            self.volume = enum.VolumeUnit(proto.volume_unit)
        if proto.volumetric_flow_unit:
            self.volumetric_flow = enum.VolumetricFlowUnit(proto.volumetric_flow_unit)
        if proto.viscosity_unit:
            self.viscosity = enum.ViscosityUnit(proto.viscosity_unit)
        if proto.conductivity_unit:
            self.conductivity = enum.ConductivityUnit(proto.conductivity_unit)
        if proto.molecular_weight_unit:
            self.molecular_weight = enum.MolecularWeightUnit(proto.molecular_weight_unit)
