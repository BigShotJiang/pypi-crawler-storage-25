# Copyright 2026 Luminary Cloud, Inc. All Rights Reserved.
from dataclasses import dataclass
from typing import Optional
from ...enum import GeometryExportType

from ..._proto.api.v0.luminarycloud.geometry import geometry_pb2 as geometrypb


@dataclass(kw_only=True)
class TessellationParams:
    """
    Tessellation parameters for mesh generation during STL export.
    """

    max_aspect_ratio: Optional[float] = None
    target_triangle_count: Optional[int] = None
    triangle_count_tolerance: Optional[float] = None
    non_conforming: bool = False

    def _to_proto(self) -> geometrypb.TessellationParameters:
        return geometrypb.TessellationParameters(
            non_conforming=self.non_conforming,
            **(
                {"max_aspect_ratio": self.max_aspect_ratio}
                if self.max_aspect_ratio is not None
                else {}
            ),
            **(
                {"target_triangle_count": self.target_triangle_count}
                if self.target_triangle_count is not None
                else {}
            ),
            **(
                {"triangle_count_tolerance": self.triangle_count_tolerance}
                if self.triangle_count_tolerance is not None
                else {}
            ),
        )


@dataclass(kw_only=True)
class StlExportOptions:
    """
    Options for exporting geometry as STL.
    """

    ascii: bool = False
    tessellation: Optional[TessellationParams] = None

    def _to_proto(self) -> geometrypb.StlExportOptions:
        tessellation_proto = (
            self.tessellation._to_proto()
            if self.tessellation is not None
            else geometrypb.TessellationParameters()
        )
        return geometrypb.StlExportOptions(
            ascii=self.ascii,
            tessellation=tessellation_proto,
        )


@dataclass(kw_only=True)
class GeometryExportParams:
    """
    Parameters defining the geometry export format and options.
    Only STL supported for now.
    """

    stl: Optional[StlExportOptions] = None
    tags: Optional[list[str]] = None

    def _to_proto(self, export_type: GeometryExportType) -> geometrypb.GeometryExportParams:
        if self.stl is None:
            raise ValueError(
                "Only STL export is supported for now, so stl format options must be set for STL export (e.g. GeometryExportParams(stl=StlExportOptions(...)))."
            )
        return geometrypb.GeometryExportParams(
            stl=self.stl._to_proto(),
            **({"tags": self.tags} if self.tags else {}),
        )
