# Copyright 2026 Luminary Cloud, Inc. All Rights Reserved.
from enum import Enum


class GeometryExportType(str, Enum):
    """
    Format to use when exporting geometry.

    Attributes
    ----------
    STL
        Export as STL mesh. Supports ASCII or binary and tessellation options.
    """

    STL = "stl"
