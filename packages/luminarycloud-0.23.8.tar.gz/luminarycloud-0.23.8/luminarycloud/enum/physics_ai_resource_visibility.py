from enum import IntEnum
from .._proto.api.v0.luminarycloud.physics_ai.physics_ai_pb2 import (
    PhysicsAiResourceVisibility as PhysicsAiResourceVisibilityPb,
)


class PhysicsAiResourceVisibility(IntEnum):
    """
    Represents the visibility of a Physics AI resource.

    Attributes
    ----------
    UNSPECIFIED
        Default value, should not be used in practice.
    INTERNAL
        Only visible to internal users.
    PRIVATE
        Only visible to the owner.
    ACCOUNT_WIDE
        Visible to all users within the same account.
    PUBLIC
        Visible to all users.
    """

    UNSPECIFIED = PhysicsAiResourceVisibilityPb.RESOURCE_VISIBILITY_UNSPECIFIED
    INTERNAL = PhysicsAiResourceVisibilityPb.RESOURCE_VISIBILITY_INTERNAL
    PRIVATE = PhysicsAiResourceVisibilityPb.RESOURCE_VISIBILITY_PRIVATE
    ACCOUNT_WIDE = PhysicsAiResourceVisibilityPb.RESOURCE_VISIBILITY_ACCOUNT_WIDE
    PUBLIC = PhysicsAiResourceVisibilityPb.RESOURCE_VISIBILITY_PUBLIC
