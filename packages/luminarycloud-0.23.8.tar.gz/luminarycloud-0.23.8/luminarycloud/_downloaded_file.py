# Copyright 2023-2024 Luminary Cloud, Inc. All Rights Reserved.
import io

from ._proto.api.v0.luminarycloud.common import common_pb2 as commonpb


class _DownloadedTextFile(io.StringIO):
    filename: str

    def __init__(self, file_proto: commonpb.File):
        super().__init__(file_proto.full_contents.decode())
        metadata = file_proto.metadata
        self.filename = metadata.name
        if metadata.ext:
            self.filename += "." + metadata.ext
