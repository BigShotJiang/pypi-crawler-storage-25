# Copyright 2025 Luminary Cloud, Inc. All Rights Reserved.

"""Priority job usage history functionality."""

from datetime import datetime, timedelta, timezone
from typing import Optional

from google.protobuf.timestamp_pb2 import Timestamp

from ._helpers.pagination import PaginationIterator
from ._proto.api.v0.luminarycloud.billing import billing_pb2 as billingpb
from .types import ProjectID


class PriorityJobUsageRecord:
    """A single resource usage record for a priority (non-batch) job.

    Attributes
    ----------
    project_id : str
        The project ID associated with this usage record.
    project_name : str
        The project name associated with this usage record.
    simulation_name : str
        The name of the simulation that produced this usage, if applicable.
    job_id : str
        The job ID associated with this usage record.
    email : str
        The email of the user who initiated the job.
    time : datetime
        The time of the usage record.
    gpu_type : str
        The GPU type used for this job (e.g. "H100", "A100").
    gpu_minutes : float
        Total GPU-minutes consumed by this job.
    amount : float
        Amount charged for this job, in the currency specified by ``currency``.
    currency : str
        ISO 4217 currency code (e.g. ``"USD"``).
    """

    def __init__(self, proto: billingpb.PriorityJobUsageRecord):
        self._proto = proto

    @property
    def project_id(self) -> str:
        return self._proto.project_id

    @property
    def project_name(self) -> str:
        return self._proto.project_name

    @property
    def simulation_name(self) -> str:
        return self._proto.simulation_name

    @property
    def job_id(self) -> str:
        return self._proto.job_id

    @property
    def email(self) -> str:
        return self._proto.email

    @property
    def time(self) -> datetime:
        return datetime.fromtimestamp(self._proto.time, tz=timezone.utc)

    @property
    def gpu_type(self) -> str:
        return self._proto.gpu_type

    @property
    def gpu_minutes(self) -> float:
        return self._proto.gpu_minutes

    @property
    def amount(self) -> float:
        return self._proto.amount

    @property
    def currency(self) -> str:
        return self._proto.currency

    def to_dict(self) -> dict:
        """Return the record as a dictionary."""
        return {
            "project_id": self.project_id,
            "project_name": self.project_name,
            "simulation_name": self.simulation_name,
            "job_id": self.job_id,
            "email": self.email,
            "time": self.time.isoformat(),
            "gpu_type": self.gpu_type,
            "gpu_minutes": self.gpu_minutes,
            "amount": self.amount,
            "currency": self.currency,
        }

    def __repr__(self) -> str:
        return (
            f"PriorityJobUsageRecord(project_id={self.project_id!r}, "
            f"project_name={self.project_name!r}, "
            f"simulation_name={self.simulation_name!r}, "
            f"job_id={self.job_id!r}, email={self.email!r}, "
            f"time={self.time.isoformat()!r}, "
            f"gpu_type={self.gpu_type!r}, gpu_minutes={self.gpu_minutes}, "
            f"amount={self.amount}, currency={self.currency!r})"
        )


def _datetime_to_timestamp(dt: datetime) -> Timestamp:
    ts = Timestamp()
    ts.FromDatetime(dt)
    return ts


class PriorityJobUsageIterator(PaginationIterator[PriorityJobUsageRecord]):
    """Iterator for priority job usage records with lazy pagination."""

    def __init__(
        self,
        start_time: Optional[datetime],
        end_time: Optional[datetime],
        project_id: Optional[str],
        page_size: int,
    ):
        self._start_time = start_time
        self._end_time = end_time
        self._project_id = project_id
        super().__init__(page_size)

    def _fetch_page(
        self, page_size: int, page_token: str
    ) -> tuple[list[PriorityJobUsageRecord], str, int]:
        kwargs: dict = {
            "page_size": page_size,
            "page_token": page_token,
        }
        if self._project_id is not None:
            kwargs["project_id"] = self._project_id
        if self._start_time is not None:
            kwargs["start_time"] = _datetime_to_timestamp(self._start_time)
        if self._end_time is not None:
            kwargs["end_time"] = _datetime_to_timestamp(self._end_time)

        req = billingpb.PriorityJobUsageRequest(**kwargs)
        res = self._client.ListPriorityJobUsage(req)

        records = [PriorityJobUsageRecord(r) for r in res.usage]
        return records, res.next_page_token, res.total_count


def iterate_priority_job_usage(
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    *,
    project_id: Optional[ProjectID] = None,
    page_size: int = 100,
) -> PriorityJobUsageIterator:
    """
    Iterate over priority job usage records for the current account.

    Parameters
    ----------
    start_time : datetime, optional
        The start of the time period to query. Defaults to 30 days ago.
    end_time : datetime, optional
        The end of the time period to query. Defaults to now.
    project_id : str, optional
        If set, only return usage records for this project.
        If omitted, returns usage records across the entire account.
    page_size : int, optional
        Number of records to fetch per page. Defaults to 100.

    Returns
    -------
    PriorityJobUsageIterator
        An iterator that yields PriorityJobUsageRecord objects one at a time.

    Raises
    ------
    luminarycloud.exceptions.InvalidRequestError
        If the date range exceeds 90 days.

    Examples
    --------
    Fetch all priority job usage for a project:

    >>> usage = list(lc.iterate_priority_job_usage(project_id="my-project-id"))

    Lazily iterate over all priority job usage records for the last 30 days:

    >>> for record in lc.iterate_priority_job_usage():
    ...     print(record.simulation_name, record.gpu_minutes, record.amount, record.currency)
    """
    now = datetime.now(tz=timezone.utc)
    if start_time is None:
        start_time = now - timedelta(days=30)
    if end_time is None:
        end_time = now
    return PriorityJobUsageIterator(
        start_time=start_time,
        end_time=end_time,
        project_id=project_id,
        page_size=page_size,
    )
