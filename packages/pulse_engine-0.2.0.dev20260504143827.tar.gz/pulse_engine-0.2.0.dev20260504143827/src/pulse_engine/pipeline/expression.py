"""Pure expression parser and resolver for v2 pipeline for_each expressions.

No Prefect, no AWS. All functions are synchronous and unit-testable in isolation.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any


@dataclass
class ParsedExpression:
    source: str  # "args", "steps", or "collect"
    step: str | None  # for source="steps": the referenced step name
    # for "args": arg key; for "steps"/"collect": optional output field
    field: str | None


def parse_expression(expr: str) -> ParsedExpression:
    """Parse a for_each expression string.

    Valid forms:
      $args.FIELD
      $steps.STEP_NAME.output
      $steps.STEP_NAME.output.FIELD
      $collect.FIELD

    Step names may contain hyphens (e.g. $steps.batch-yt.output.batches).
    """
    m = re.match(r"^\$args\.(\w+)$", expr)
    if m:
        return ParsedExpression(source="args", step=None, field=m.group(1))

    m = re.match(r"^\$steps\.([\w-]+)\.output(?:\.(\w+))?$", expr)
    if m:
        return ParsedExpression(source="steps", step=m.group(1), field=m.group(2))

    m = re.match(r"^\$collect\.(\w+)$", expr)
    if m:
        return ParsedExpression(source="collect", step=None, field=m.group(1))

    raise ValueError(f"Invalid for_each expression: {expr!r}")


def _singular(key: str) -> str:
    """Strip trailing 's' to derive singular form.

    channels → channel, accounts → account, sources → source, videos → video

    Note: only handles simple -s plurals. Words ending in -es (e.g. "batches",
    "speeches") will produce incorrect keys ("batche", "speeche"). Use arg
    names that pluralise with a plain -s suffix.
    """
    return key.rstrip("s")


def resolve_for_each_items(
    expr: ParsedExpression,
    module_args: dict[str, Any],
    step_results: dict[str, Any],
    collect_from: list[str] | None,
) -> list[Any]:
    """Return the list of items to fan out over for the given expression.

    Raises ValueError if an $args source is not a list.
    Returns [] for missing/empty sources rather than raising.
    """
    if expr.source == "args":
        assert expr.field is not None  # guaranteed by parse_expression for "args"
        items = module_args.get(expr.field, [])
        if not isinstance(items, list):
            raise ValueError(
                f"module.args['{expr.field}'] must be a list for fan-out, "
                f"got {type(items).__name__}"
            )
        return items

    if expr.source == "steps":
        assert expr.step is not None  # guaranteed by parse_expression for "steps"
        output = step_results.get(expr.step)
        if output is None:
            return []
        if expr.field:
            return list(output.get(expr.field, [])) if isinstance(output, dict) else []
        return output if isinstance(output, list) else [output]

    if expr.source == "collect":
        field = expr.field
        assert field is not None  # guaranteed by parse_expression for "collect"
        sources = collect_from or []
        collected: list[Any] = []
        for step_name in sources:
            result = step_results.get(step_name)
            if result is None:
                continue
            if isinstance(result, list):
                for r in result:
                    if isinstance(r, dict):
                        collected.extend(r.get(field, []))
            elif isinstance(result, dict):
                collected.extend(result.get(field, []))
        return collected

    return []


def build_task_args(
    expr: ParsedExpression,
    module_args: dict[str, Any],
    item: Any,
) -> tuple[dict[str, Any], Any]:
    """Build (task_args, input_ref) for a single fan-out task.

    $args source:
      Item is injected under the singular form of the field key into ARGS.
      INPUT_REF is also set to item so data-driven modules can read it directly.

    $steps / $collect source:
      ARGS = module_args unchanged.
      INPUT_REF = item (the individual fanned-out item).
    """
    if expr.source == "args":
        assert expr.field is not None  # guaranteed by parse_expression for "args"
        singular = _singular(expr.field)
        return {**module_args, singular: item}, item

    return dict(module_args), item


def _unwrap_item(item: Any) -> list[Any]:
    """Unwrap a step output item into a flat list of data items.

    If item is a dict with exactly ONE key and that value is a list, return
    that list — this handles the common pattern where a module returns
    {"videos": [...]} or {"speeches": [...]} and the caller wants the inner list.

    Dicts with multiple keys are never unwrapped to avoid accidentally extracting
    a list field (e.g. "segments") from a rich data object like a video item.
    """
    if isinstance(item, dict) and len(item) == 1:
        (val,) = item.values()
        if isinstance(val, list):
            return val
    return [item]


def collect_inputs(
    collect_from: list[str],
    step_results: dict[str, Any],
) -> list[Any]:
    """Flatten outputs from multiple steps into a single list for INPUT_REF.

    Each collected item is unwrapped via _unwrap_item so that modules returning
    {"videos": [...]} or {"speeches": [...]} contribute their inner list items
    rather than the wrapper dict.
    """
    result: list[Any] = []
    for step_name in collect_from:
        val = step_results.get(step_name)
        if val is None:
            continue
        items = val if isinstance(val, list) else [val]
        for item in items:
            result.extend(_unwrap_item(item))
    return result
