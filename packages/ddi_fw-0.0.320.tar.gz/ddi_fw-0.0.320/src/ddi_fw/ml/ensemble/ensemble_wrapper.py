
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from ddi_fw import utils
from ddi_fw.ml.ensemble.ensemble_strategy import AveragingStrategy, EnsembleStrategy, StackingStrategy, VotingStrategy
from ddi_fw.ml.evaluation_helper import Metrics, evaluate
from ddi_fw.ml.result import Result
from ddi_fw.ml.wrappers.model_wrapper import ModelWrapper


class GenericEnsembleWrapper(ModelWrapper):
    """Generic ensemble wrapper supporting multiple strategies"""

    STRATEGY_MAP = {
        "voting": VotingStrategy,
        "averaging": AveragingStrategy,
        "stacking": StackingStrategy
    }

    def __init__(
        self,
        base_wrappers: List[ModelWrapper],
        meta_learners: List[ModelWrapper],
        meta_learner_processors: Dict[str, Any],
        ensemble_strategies: str,          # now comma separated input
        name: str = "ensemble",
        tracking_service: Optional[Any] = None,
        date: Optional[str] = None
    ):
        self.base_wrappers = base_wrappers
        self.name = name
        self.tracking_service = tracking_service
        self.date = date or utils.utc_time_as_string_simple_format()
        self.ensemble_strategies = ensemble_strategies
        self.meta_learners = meta_learners
        self.meta_learner_processors = meta_learner_processors
        

        # prediction cache so we don't recompute
        self.wrapper_predictions: Dict[str, np.ndarray] = {}
        self._cached_scenario: Optional[str] = None

        self.individual_metrics = {}
        self.ensemble_metrics: Dict[str, Metrics] = {}
        self.result = Result()

    # ---------------------------------------------------------
    # FIT
    # ---------------------------------------------------------
    def fit(self):
        train_label, test_label = None, None

        # if any(getattr(wrapper, 'best_model', None) is not None for wrapper in self.base_wrappers):
        #     # At least one wrapper has best_model set
        #     pass

        train_label, test_label = None, None
        train_idx_arr, val_idx_arr = None, None
        val_labels = []
        inputs = []

        def _ordered_val_preds(val_preds_dict: Dict[str, np.ndarray], descriptor: str, num_folds: int) -> List[np.ndarray]:
            if not val_preds_dict:
                return []
            ordered = []
            for i in range(num_folds):
                key = f"{descriptor}_validation_{i}"
                if key in val_preds_dict:
                    ordered.append(val_preds_dict[key])
            if ordered:
                return ordered
            if len(val_preds_dict) == num_folds:
                for k in sorted(val_preds_dict.keys()):
                    ordered.append(val_preds_dict[k])
            return ordered

        for wrapper in self.base_wrappers:
            train_label = wrapper.train_label
            test_label = wrapper.test_label

            train_idx_arr = wrapper.train_idx_arr
            val_idx_arr = wrapper.val_idx_arr

            if train_label is None or train_idx_arr is None or val_idx_arr is None:
                raise ValueError(
                    f"Missing training labels or fold indices for {wrapper.descriptor}. "
                    "Ensure base models run with CV folds to produce OOF predictions."
                )

            if not val_labels:
                for i, (train_idx, val_idx) in enumerate(zip(train_idx_arr, val_idx_arr)):
                    fold_val_labels = train_label[val_idx]
                    val_labels.append(fold_val_labels)
            # Convert the list of arrays to a single numpy array
            all_fold_val_labels = np.concatenate(val_labels)

            print(f"Training base model: {wrapper.descriptor}")
            best_model, _, val_preds_dict = wrapper.fit()
            num_classes = getattr(wrapper, "num_classes", None)
            wrapper.best_model = best_model
            # pred_train = wrapper.predict()
            # if val_preds_dict is not None:
            # Validation predictions logged at debug level
            if val_preds_dict:
                for key, value in val_preds_dict.items():
                    pass  # Debug info available if needed

            preds_list = _ordered_val_preds(val_preds_dict, wrapper.descriptor, len(val_idx_arr))
            if not preds_list:
                raise ValueError(
                    f"No validation predictions found for {wrapper.descriptor}. "
                    "Ensure base models run with CV folds to produce OOF predictions."
                )

            stacked_values = np.concatenate(preds_list, axis=0)
            if num_classes is None:
                num_classes = stacked_values.shape[1] if stacked_values.ndim > 1 else 1
            
            # Apply processor to base model predictions if configured
            # This reduces embedding dimensions before concatenation
            for meta_learner in self.meta_learners:
                processor_dict = self.meta_learner_processors.get(meta_learner.descriptor)
                if processor_dict:
                    processor = processor_dict.get("processor")
                    processor_config = processor_dict.get("processor_config")
                    if processor and processor_config and processor_config.get("reduce_dimensions"):
                        stacked_values = processor().process2(stacked_values, processor_config)
                        break  # Apply processor only once per base model batch
            
            inputs.append(stacked_values)
            # inputs.append(list(val_preds_dict.values()))
      
        # inputs = np.concatenate(inputs, axis=1)
        if not inputs:
            raise ValueError("No base model predictions collected for stacking.")
        X_meta_train = np.concatenate(inputs, axis=1)
        self.num_classes = num_classes
        self.test_label = test_label
        y_meta_train = all_fold_val_labels

        # Step 3: set the meta-learner's training data
        for meta_learner in self.meta_learners:
            
            meta_learner.train_data = X_meta_train
            meta_learner.train_label = y_meta_train
            meta_learner.train_idx_arr = train_idx_arr
            meta_learner.val_idx_arr = val_idx_arr
            meta_learner.test_label = test_label
            setattr(meta_learner, "num_classes", num_classes)

        # Parse comma-separated strategies
        self.selected_strategies: List[EnsembleStrategy] = []
        for s in self.ensemble_strategies.split(","):
            s = s.strip().lower()
            if s not in self.STRATEGY_MAP:
                raise ValueError(f"Unknown strategy '{s}'")
            if s == "stacking":
                if not self.meta_learners:
                    raise ValueError(
                        "Meta-learner must be provided for stacking strategy")
                for meta_learner in self.meta_learners:
                    processor_dict = self.meta_learner_processors.get(meta_learner.descriptor)
                    processor = processor_dict.get("processor") if processor_dict else None
                    processor_config = processor_dict.get("processor_config") if processor_dict else None
                    if processor is None:
                        raise ValueError(
                            f"Processor must be provided for meta-learner '{meta_learner.descriptor}' in stacking strategy")
                    
                    if processor_config is None:
                        raise ValueError(
                            f"Processor config must be provided for meta-learner '{meta_learner.descriptor}' in stacking strategy")
                    
                    self.selected_strategies.append(StackingStrategy(descriptor=meta_learner.descriptor,
                                                                     meta_learner=meta_learner, 
                                                                     base_wrappers=self.base_wrappers,
                                                                     processor=processor,
                                                                     processor_config=processor_config))
            else:
                self.selected_strategies.append(self.STRATEGY_MAP[s]())

    # ---------------------------------------------------------
    # PREDICT — with prediction caching
    # ---------------------------------------------------------

    def _compute_and_cache_predictions(self, scenario: Optional[str] = None, force_recompute: bool = False):
        """Compute wrapper predictions once per scenario."""
        if force_recompute or self._cached_scenario != scenario:
            self.wrapper_predictions = {}
            self._cached_scenario = scenario

        if self.wrapper_predictions:
            return

        for wrapper in self.base_wrappers:
            descriptor = wrapper.descriptor

            y_pred = wrapper.predict(scenario=scenario)
            self.wrapper_predictions[descriptor] = y_pred

            # scenario-aware ground truth
            _, y_true = wrapper._resolve_test_payload(scenario)
            y_pred_cat = utils.convert_to_categorical(y_pred, self.num_classes)
            y_true_cat = utils.convert_to_categorical(y_true, self.num_classes)

            _, wrapper_metrics = evaluate(y_true_cat, y_pred_cat)
            wrapper_metrics.set_time(wrapper.elapsed_time)
            wrapper_metrics.format_float()

            self.result.add_metric(descriptor, wrapper_metrics)
            self.individual_metrics[descriptor] = wrapper_metrics

    def predict(self, scenario: Optional[str] = None):
        self._compute_and_cache_predictions(scenario=scenario)

        pred_list = list(self.wrapper_predictions.values())
        ensemble_outputs = {}

        # scenario-aware true labels (use first base wrapper)
        _, y_true = self.base_wrappers[0]._resolve_test_payload(scenario)
        y_true_cat = utils.convert_to_categorical(y_true, self.num_classes)

        for strategy in self.selected_strategies:
            strategy_name = strategy.get_strategy_name()

            ensemble_pred = strategy.combine_predictions(pred_list, scenario=scenario)
            ensemble_pred_cat = utils.convert_to_categorical(ensemble_pred, self.num_classes)

            _, metrics = evaluate(y_true_cat, ensemble_pred_cat)
            if type(strategy) is StackingStrategy:
                metrics.set_time(strategy.meta_learner.elapsed_time)
            metrics.format_float()

            token = strategy_name
            self.ensemble_metrics[token] = metrics
            self.result.add_metric(token, metrics)
            ensemble_outputs[token] = ensemble_pred_cat

        return ensemble_outputs

    def fit_and_evaluate_scenarios(self, scenarios: List[str], print_detail: bool = False) -> Dict[str, Tuple[dict[str, Any], Any, Any]]:
        if not scenarios:
            raise ValueError("scenarios cannot be empty")

        results: Dict[str, Tuple[dict[str, Any], Metrics, Any]] = {}
        self.fit()

        for scenario in scenarios:
            # force new predictions per scenario
            self.wrapper_predictions = {}
            self._cached_scenario = None

            ensemble_preds = self.predict(scenario=scenario)
            # return all strategy metrics for this scenario
            logs = {k: v.__dict__ for k, v in self.ensemble_metrics.items()}
            results[scenario] = (logs, self.result, ensemble_preds)

        return results
    # ---------------------------------------------------------
    # FIT AND EVALUATE
    # ---------------------------------------------------------
    def fit_and_evaluate(self):
        self.fit()
        ensemble_preds = self.predict()
        return None, self.result, ensemble_preds

    
    def _set_wrappers_scenario(self, scenario: str) -> None:
        """
        Route base/meta wrappers to scenario-specific test payloads.
        """
        for w in self.base_wrappers:
            X_s, y_s = w._resolve_test_payload(scenario)
            w.test_data = X_s
            w.test_label = y_s

        for w in self.meta_learners or []:
            # meta learner may not have scenario payload; ignore if missing
            try:
                X_s, y_s = w._resolve_test_payload(scenario)
                w.test_data = X_s
                w.test_label = y_s
            except Exception:
                pass