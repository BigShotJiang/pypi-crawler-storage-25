# ctfy

Open-source CTF platform — run challenges, score submissions, and let human
players hand out their own API tokens so agents can compete alongside them.
Ships with a REST API and MCP server for AI-agent evaluation harnesses.

![ctfy dashboard](docs/screenshots/dashboard.png)

## Quick start

The platform authenticates humans via **email+password** (on by default,
no external services required) or **OAuth** (GitHub and/or Google).
Worker nodes register with one-time invite tokens minted by an admin user.
Bring-up is two-stage: first the platform goes up so an admin can sign in
and mint a node invite, then the worker joins the cluster.

### 0. Quickstart without OAuth (easiest)

Password auth is enabled out of the box — no OAuth apps, no SMTP, no email
verification. Start the platform, open `/register`, and the very first
account becomes super-admin. Subsequent users register normally as members
and can be promoted to admin from the admin UI.

```bash
docker compose up -d
# open http://localhost:8100/register → create your super-admin account
```

Notes:

- The first user to register is auto-granted `super_admin` to bootstrap
  the deployment. After that, super-admin is only granted via
  `CTFY_SUPER_ADMIN_EMAILS` *and only for OAuth-verified emails* —
  password-registered emails are unverified and never match the allowlist,
  to prevent anyone from claiming `admin@your-domain.com` via registration.
- Regular admins are no longer set via env. A super-admin promotes
  regular users from **Admin → Users → Promote to admin**; the change
  takes effect immediately and is recorded in the activity log
  (`promoted_by` / `promoted_at`). Demote the same way.
- Users and teams are separate (post user/team-split): each
  registration mints a personal team and joins you to it. Captains
  mint short codes from **Team → Join code** to invite others;
  redeemers leave their old team automatically. Solves stay credited
  to whichever team you were on when you captured the flag.
- Per-competition teams: on each competition's detail page you can
  register **Solo** (one-person team), **Create team** (named
  multi-user team, you become captain), or **Join via code** (an
  existing team's invite code). Each user can be on a different
  team for each competition simultaneously. Browse all your
  per-comp memberships under **Sidebar → My Competitions**.
  Global player rankings live at **Scoreboard → Players** (sums
  solves across every team you've been on); the team-ranked board
  is the secondary tab.
- To disable password auth entirely on a production deployment, set
  `CTFY_PASSWORD_AUTH_ENABLED=false`.
- Password rotation: Settings → Password. Forgot-password is intentionally
  not implemented (no SMTP dependency); recovery is either "link OAuth
  with the same email" or ask the operator to wipe the
  `password_identities` row.

### 1. Configure OAuth

Register an OAuth App (at least one provider) and copy its credentials:

- GitHub: <https://github.com/settings/developers>, callback
  `http://localhost:8100/api/v1/auth/callback/github`
- Google: <https://console.cloud.google.com/apis/credentials>, redirect URI
  `http://localhost:8100/api/v1/auth/callback/google`

Copy the template env and fill in the provider credentials + the email
you want to anchor as the super-admin (the only env-driven privilege
tier; regular admin is granted from the admin UI by a super-admin):

```bash
cp .env.example .env
# edit: CTFY_GITHUB_CLIENT_ID / _SECRET (or the Google pair)
#       CTFY_SUPER_ADMIN_EMAILS=your@verified-primary-email
```

### 2. Start the platform

```bash
docker compose up -d
```

This brings up `traefik` + `platform` (the `node` service belongs to the
`node` profile and is skipped here). Open <http://localhost:8100/login>,
sign in with your provider, and you land on the admin console because your
email matches `CTFY_SUPER_ADMIN_EMAILS`. From there, promote other users
to regular admin via **Admin → Users**.

### 3. Mint a node invite and start the worker

In the admin console, open **Nodes → Mint invite**, copy the plaintext
token, drop it into `.env`:

```
CTFY_NODE_TOKEN=pt_...
```

Then start the node:

```bash
docker compose --profile node up -d
```

The node persists the per-node bearer it receives on first registration
under `./data/node`, so `docker compose restart node` (or the
container being recreated) does **not** need a fresh admin-minted invite.
If an admin deletes the node, the heartbeat is rejected and the node
clears its persisted identity — mint a new invite and update
`CTFY_NODE_TOKEN` to recover.

> Configuring just one provider is fine — the login page only renders
> buttons for providers with both `CLIENT_ID` and `CLIENT_SECRET` set.

## Sending an agent

Once signed in, visit **Settings → API tokens** and create an agent token
(`pa_...`). Export it as `CTFY_TOKEN` and the MCP / CLI / SDK all pick it up:

```bash
export CTFY_TOKEN=pa_...
uv run ctfy mcp           # or: uv run ctfy instance start WEB-001
```

Agent tokens can submit flags and run instances on your team's behalf but
cannot mint more tokens, re-link providers, or modify your team / team
membership — that's reserved for the user-kind session, so a leaked agent
token can be revoked without losing access to the account.

## Upgrading from a pre-OAuth build

Early-development builds stored per-team bearer tokens and an admin token in
the database. The OAuth rewrite drops those columns entirely. To upgrade a
local checkout (also wipes any prior node identity so the node re-registers
via a fresh admin-minted invite):

```bash
docker compose --profile node down
rm -rf ./data/platform ./data/node
docker compose up -d
```

## Screens

### Challenges

![](docs/screenshots/challenges.png) 

### Scoreboard

![](docs/screenshots/scoreboard.png)

### Activity

![](docs/screenshots/activity.png)

### Achievements

![](docs/screenshots/achievements.png)
