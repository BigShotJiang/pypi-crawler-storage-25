"""Framework configuration as a plain pydantic model.

Every knob is declared with a default + description so the CLI can mirror the
schema (``ctfy server start --help``) and operators see the full surface in
one place. Validation runs at instantiation; filesystem existence is *not*
enforced so tests can build a config inside a tmpdir without scaffolding.

The class also exposes :meth:`CtfyConfig.from_env`, the single source of truth
for translating ``CTFY_*`` environment variables into a config — used by the
CLI (``ctfy server start`` / ``ctfy node join``) and by ``ctfy config show``.

Authentication model: the platform authenticates humans via OAuth
(GitHub + Google) or local email+password. There is no static admin
token; super-admin privileges are granted by listing an email in
``CTFY_SUPER_ADMIN_EMAILS`` and having that user sign in with a verified
OAuth identity. Regular admin is then granted by a super-admin from the
admin UI — there is no env-driven path for the regular admin tier.
Agents call the API using ``pa_*`` bearer tokens that a logged-in user
mints from the Settings UI.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, SecretStr, field_validator, model_validator

from ctfy.core.constants import (
    SCOREBOARD_RATE_LIMIT,
    SUBMISSION_RATE_LIMIT,
    SUBMISSION_RATE_WINDOW,
)
from ctfy.core.exceptions import ConfigError

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

_PORT_MAX = 65535


class CtfyConfig(BaseModel):
    """Single source of truth for runtime configuration.

    Constructed explicitly with keyword arguments — the CLI reads values from
    env / ``.env`` via typer's ``envvar=`` and hands them to this constructor.
    Field defaults double as the typer ``--xxx`` defaults, so changing a
    default here propagates to ``ctfy server start --help`` automatically.
    """

    # --- Paths ---
    project_root: Path = Field(
        default=_PROJECT_ROOT,
        description="Repository root. Derived from the package location; rarely overridden.",
    )
    challenges_dir: Path = Field(
        default=_PROJECT_ROOT / "challenges",
        description=(
            "Directory containing challenge metadata.yaml files. Default is "
            "``./challenges`` in the repo root, populated as a git submodule "
            "(``git submodule update --init --recursive``). ``ctfy challenge "
            "sync`` still works for operators who prefer that workflow — point "
            "``CTFY_CHALLENGES_DIR`` at the synced location."
        ),
    )
    challenges_repo: str = Field(
        default="https://github.com/CTF-Arena/challenges.git",
        description=(
            "Git repository cloned into ``challenges_dir`` by ``ctfy challenge "
            "sync``. Empty string disables sync."
        ),
    )
    instances_dir: Path = Field(
        default=_PROJECT_ROOT / "data" / "instances",
        description="Working directory for per-instance artefacts (flags, proxy output).",
    )
    instance_archive_dir: Path = Field(
        default=_PROJECT_ROOT / "data" / "archive",
        description=(
            "Platform-side permanent archive for per-instance artifacts (manifest, "
            "event stream, flag-attempt log, container logs). One directory per "
            "instance_id; never auto-purged so the full benchmark history stays "
            "available for offline analysis."
        ),
    )

    # --- Host path translation (set when platform runs inside Docker) ---
    host_project_root: str = Field(
        default="",
        description=(
            "Host path that maps to the container's project root. Used to rewrite "
            "bind-mount sources when the node runs inside Docker. Leave empty on "
            "bare-metal deployments."
        ),
    )
    proxy_output_host_root: Path | None = Field(
        default=None,
        description=(
            "Fixed-convention root for mitmproxy + tcpdump sidecar output. When set, "
            "each instance's sidecar output goes to "
            "``<proxy_output_host_root>/<instance_id>`` as a literal absolute path "
            "and ``host_project_root``-style translation is skipped entirely. "
            "Requires the node container to bind-mount this same host directory at "
            "the same path internally (e.g. ``${PWD}/data/proxy:${PWD}/data/proxy``) "
            "so the path is valid on both sides of ``docker.sock``. Use this when "
            "the node's data dir is otherwise unreachable from the host (e.g. a "
            "Docker named volume the daemon cannot see)."
        ),
    )

    # --- Traefik (unified HTTP entrypoint for challenge instances) ---
    traefik_domain: str = Field(
        default="localtest.me",
        description=(
            "Wildcard domain Traefik routes under. Default ``localtest.me`` is "
            "public DNS that resolves ``*.localtest.me`` to 127.0.0.1, so "
            "instance URLs work from any browser on the host without extra "
            "DNS setup. Override to a deployment-specific wildcard for remote "
            "operators."
        ),
    )
    traefik_public_url: str = Field(
        default="",
        description=(
            "Base URL users see in instance attack surfaces (e.g. "
            "``http://localtest.me`` or ``http://ctf.example.com:8080``). "
            "The subdomain is prepended per instance. Leave empty to default "
            "to ``http://{traefik_domain}``."
        ),
    )
    traefik_network: str = Field(
        default="traefik_proxy",
        description=(
            "Name of the external Docker network shared between Traefik and "
            "challenge containers. Must be a pinned name — the top-level "
            "docker-compose declares it with ``name:`` so per-instance compose "
            "files can reference it as ``external: true``."
        ),
    )

    # --- Docker images ---
    image_mitmproxy: str = Field(
        default="ctfy-mitmproxy",
        description="Image tag used for the per-instance mitmproxy sidecar.",
    )
    node_image: str = Field(
        default="ghcr.io/wangyihang/ctfy:latest",
        description=(
            "Docker image advertised by ``ctfy server invite``. The same image "
            "powers platform + node — the ``command`` after the image name "
            "selects the role. Forks should override via ``--node-image`` / "
            "``CTFY_NODE_IMAGE`` to point at their own GHCR."
        ),
    )

    # --- Platform server ---
    platform_url: str = Field(
        default="",
        description=(
            "Platform base URL (e.g. http://server:8100) used by SDK/CLI/MCP "
            "clients and by nodes finding the platform."
        ),
    )
    server_host: str = Field(
        default="0.0.0.0",
        description="Bind address for ``ctfy server start``.",
    )
    server_port: int = Field(
        default=8100,
        ge=1,
        le=_PORT_MAX,
        description="Bind port for ``ctfy server start``.",
    )
    # --- OAuth (GitHub + Google) ---
    # Configure both providers if you want the login page to show both buttons;
    # a provider is only registered when both its client_id and client_secret
    # are non-empty. See docs/ for how to register the OAuth apps.
    github_client_id: str = Field(
        default="",
        description="GitHub OAuth App client id (from https://github.com/settings/developers).",
    )
    github_client_secret: SecretStr = Field(
        default=SecretStr(""),
        description="GitHub OAuth App client secret.",
    )
    google_client_id: str = Field(
        default="",
        description="Google OAuth 2.0 client id (from https://console.cloud.google.com/).",
    )
    google_client_secret: SecretStr = Field(
        default=SecretStr(""),
        description="Google OAuth 2.0 client secret.",
    )
    github_api_token: SecretStr = Field(
        default=SecretStr(""),
        description=(
            "Optional GitHub Personal Access Token (no scopes required, a "
            "fine-grained read-only token works) used by the Star Gazer "
            "achievement to query ``/users/{login}/starred`` server-side. "
            "Without it the platform falls back to anonymous calls (60 "
            "requests/hour shared); with it the ceiling rises to 5000/hour. "
            "Set via ``CTFY_GITHUB_API_TOKEN``."
        ),
    )
    oauth_redirect_base: str = Field(
        default="",
        description=(
            "Public URL base used to build OAuth redirect URIs (e.g. "
            "``https://ctf.example.com``). Must exactly match what you register "
            "with each provider. Required whenever any OAuth provider is "
            "configured — config validation rejects an empty value in that case."
        ),
    )
    super_admin_emails: list[str] = Field(
        default_factory=list,
        description=(
            "Email allowlist for super-admin privileges. Comma-separated "
            "via ``CTFY_SUPER_ADMIN_EMAILS``; case-insensitive match "
            "against the OAuth provider's verified primary email. Checked "
            "on every login — entries going in/out take effect on next "
            "sign-in. Only OAuth sign-ins grant super-admin through this "
            "allowlist: password-registered emails are unverified and "
            "never match, to prevent email spoofing. Super-admins are the "
            "only role allowed to grant or revoke regular admin via the "
            "admin UI. The very first user to register via password "
            "always becomes super-admin (bootstrap)."
        ),
    )
    password_auth_enabled: bool = Field(
        default=True,
        description=(
            "Enable email+password sign-in + registration endpoints. On by "
            "default so self-hosters can start without registering OAuth "
            "apps. Set ``CTFY_PASSWORD_AUTH_ENABLED=false`` to disable."
        ),
    )
    secret_key: SecretStr = Field(
        default=SecretStr(""),
        description=(
            "HMAC key for signing OAuth state (and any future signed tokens). "
            "Auto-generated and persisted on first boot if empty, so the "
            "``docker compose up -d`` quickstart works without extra setup."
        ),
    )

    # --- State backend ---
    db_path: str = Field(
        default="",
        description="SQLite file path (default: ``{project_root}/data/platform.sqlite3``).",
    )

    # --- Build / source provenance ---
    git_commit: str = Field(
        default="",
        description=(
            "Git commit sha of the running build, surfaced on /meta and the "
            "status bar so operators can correlate UI behaviour with a "
            "specific revision. Set via ``CTFY_GIT_COMMIT`` (Docker build arg "
            "/ env var); the platform falls back to ``git rev-parse HEAD`` in "
            "the project directory in dev so local runs still get a value."
        ),
    )
    repo_url: str = Field(
        default="https://github.com/wangyihang/ctfy",
        description=(
            "Public source repository URL. Used to build the commit-hash "
            "link in the status bar. Override via ``CTFY_REPO_URL`` for "
            "forks so the link goes to your fork's commits."
        ),
    )

    # --- Bootstrap ---
    auto_bootstrap_practice: bool = Field(
        default=True,
        description=(
            "When True (the default), the platform mints a permanent "
            "'practice' competition containing every known challenge "
            "on first launch against an empty competitions table. "
            "Set CTFY_AUTO_BOOTSTRAP_PRACTICE=false to suppress — useful "
            "for tests and for deployments that want a clean slate."
        ),
    )

    # --- Rate limiting (slowapi) ---
    rate_limiting_enabled: bool = Field(
        default=True,
        description=(
            "Master switch for slowapi rate limiting. Defaults to True so production "
            "deployments are protected out of the box (flag brute-force via "
            "/verify-flag, credential stuffing, sign-up abuse). Set "
            "CTFY_RATE_LIMITING_ENABLED=false in dev/CI when running large bulk "
            "operations against a TestClient."
        ),
    )
    rate_limit_default: str = Field(
        default="600/minute",
        description=(
            "Global ceiling applied per (token, IP) pair in addition to any "
            "per-endpoint cap. slowapi rate string (e.g. '600/minute'). "
            "Ignored when rate_limiting_enabled=False."
        ),
    )
    rate_limit_submission: str = Field(
        default=f"{SUBMISSION_RATE_LIMIT}/{int(SUBMISSION_RATE_WINDOW)} seconds",
        description="Per-(token, IP) cap on POST /submissions.",
    )
    rate_limit_verify_flag: str = Field(
        default=f"{SUBMISSION_RATE_LIMIT}/{int(SUBMISSION_RATE_WINDOW)} seconds",
        description=(
            "Per-(token, IP) cap on POST /instances/{id}/verify-flag. Same default "
            "as /submissions because /verify-flag is functionally an oracle on "
            "the same flag store; without a cap a leaked agent token can brute "
            "force candidates without leaving submission records. Tradeoff: the "
            "key is composite (token, IP), so a single token spread across N "
            "attacker IPs effectively gets N × this limit. A pure per-token cap "
            "would close that, at the cost of breaking legitimate single-team "
            "multi-IP setups (e.g. a team behind a load-balanced egress)."
        ),
    )
    rate_limit_scoreboard: str = Field(
        default=SCOREBOARD_RATE_LIMIT,
        description="Per-(token, IP) cap on /scoreboard and /scoreboard/challenges.",
    )
    rate_limit_instance_start: str = Field(
        default="10/minute",
        description=(
            "Per-(token, IP) cap on POST /instances. Container provisioning is "
            "expensive (image pull / network setup / volume mount); this cap "
            "is the primary defence against a stolen token saturating a node. "
            "Per-node capacity is a backstop, not the front line."
        ),
    )
    rate_limit_login: str = Field(
        default="10/minute",
        description=(
            "Per-IP cap on POST /auth/login (unauthenticated → falls back to peer "
            "IP). Note: argon2id offline cost is the primary defence against "
            "credential stuffing; this cap only constrains a single IP. A botnet "
            "spread across many IPs is bounded by argon2 hashing cost, not by "
            "this limit. The composite (token, IP) key takes effect once a "
            "successful sign-in returns a bearer."
        ),
    )
    rate_limit_register: str = Field(
        default="20/hour",
        description=(
            "Per-IP cap on POST /auth/register. Default raised from a stricter "
            "value because a classroom or office behind one NAT egress IP would "
            "otherwise share a single bucket. Operators expecting larger groups "
            "should raise it further; rely on audit logs (not this cap alone) "
            "to spot mass sign-up abuse."
        ),
    )
    rate_limit_token_create: str = Field(
        default="20/hour",
        description="Per-(token, IP) cap on POST /auth/tokens (agent token mint).",
    )
    rate_limit_password_change: str = Field(
        default="5/minute",
        description=(
            "Per-(token, IP) cap on POST /auth/password (set / change password). "
            "The route verifies ``current_password`` with argon2id, so an attacker "
            "with a stolen user-kind token can otherwise brute-force the existing "
            "password to change it and lock out the legitimate owner. Mirrors "
            "/auth/login's role for online password attacks."
        ),
    )
    rate_limit_auth_mutation: str = Field(
        default="20/hour",
        description=(
            "Per-(token, IP) cap on auth-state DELETEs that don't have a more "
            "specific limit: DELETE /auth/identities/{id}, DELETE /auth/password, "
            "DELETE /auth/tokens/{id}, DELETE /auth/tokens/others. These all "
            "require user-kind auth, so the cap is defence-in-depth — it bounds "
            "the blast radius of a stolen token before the global default kicks in."
        ),
    )

    @field_validator("super_admin_emails", mode="before")
    @classmethod
    def _parse_super_admin_emails(cls, value: Any) -> Any:
        """Accept a comma-separated string (from env) or a list."""
        if value is None or value == "":
            return []
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        return value

    @model_validator(mode="after")
    def _check_invariants(self) -> "CtfyConfig":
        if self.platform_url and not self.platform_url.startswith(("http://", "https://")):
            raise ConfigError(
                f"platform_url must start with http:// or https:// (got: {self.platform_url!r})"
            )
        if self.oauth_redirect_base and not self.oauth_redirect_base.startswith(
            ("http://", "https://")
        ):
            raise ConfigError(
                f"oauth_redirect_base must start with http:// or https:// "
                f"(got: {self.oauth_redirect_base!r})"
            )
        if self.github_client_id and not self.github_client_secret.get_secret_value():
            raise ConfigError("github_client_id set but github_client_secret is empty")
        if self.google_client_id and not self.google_client_secret.get_secret_value():
            raise ConfigError("google_client_id set but google_client_secret is empty")
        if (self.github_client_id or self.google_client_id) and not self.oauth_redirect_base:
            raise ConfigError(
                "oauth_redirect_base is required when any OAuth provider is "
                "configured (set CTFY_OAUTH_REDIRECT_BASE to the public URL "
                "registered with the provider, e.g. https://ctf.example.com)"
            )
        return self

    @classmethod
    def from_env(
        cls,
        overrides: dict[str, Any] | None = None,
        *,
        env: dict[str, str] | None = None,
    ) -> "CtfyConfig":
        """Build a config from ``CTFY_*`` env vars + optional explicit overrides.

        ``overrides`` always wins over the environment so CLI flags can stay
        authoritative.
        """
        env = env if env is not None else os.environ
        raw: dict[str, Any] = {}
        for name in cls.model_fields:
            value = env.get(f"CTFY_{name.upper()}")
            if value is None or value == "":
                continue
            raw[name] = value
        if overrides:
            for k, v in overrides.items():
                if v in (None, ""):
                    continue
                raw[k] = v
        return cls(**raw)
