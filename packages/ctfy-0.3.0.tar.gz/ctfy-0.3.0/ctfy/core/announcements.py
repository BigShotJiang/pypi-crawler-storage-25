"""Announcement helpers — pure functions over :class:`AnnouncementState`.

The activity window check lives here (not on the model) so both the
state backends and the route layer can evaluate it against the same
notion of "now" — sqlite filters in SQL using the same string
comparison the in-memory backend uses in Python.
"""

from __future__ import annotations

from ctfy.core.state.models import AnnouncementState


def is_active(ann: AnnouncementState, now_iso: str) -> bool:
    """True when ``now_iso`` falls inside the announcement's window.

    ``starts_at`` empty means "live immediately"; ``ends_at`` empty
    means "no expiry". ISO 8601 strings sort lexicographically, so a
    plain string comparison is correct as long as every timestamp uses
    the same offset (we always emit UTC ``Z``).
    """
    if ann.starts_at and ann.starts_at > now_iso:
        return False
    if ann.ends_at and ann.ends_at <= now_iso:
        return False
    return True
