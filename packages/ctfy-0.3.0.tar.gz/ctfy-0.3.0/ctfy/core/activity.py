"""Typed payload for ``Activity.detail`` — the per-event extra fields.

Historically ``ActivityState.detail`` / ``Activity.detail`` were free-form
``dict[str, Any]``. That let ``emit_event(...)`` forward arbitrary kwargs
but left every consumer (Python routes, TypeScript dashboard, external
dashboards via MCP) guessing at the shape.

``ActivityDetail`` captures the union of every field any emitter has ever
set, all as ``Optional``. Consumers read ``detail.instance_id`` with
proper typing (``str | None``); the OpenAPI schema exports a concrete
type that ``openapi-typescript`` turns into a TypeScript interface.

Per-event exact shapes (INSTANCE_READY needs ``node_id`` but TEAM_REGISTERED
does not) are intentionally *not* modelled as a discriminated union —
doing so would force a schema migration of already-stored activities in
Redis/SQLite. This single-class approach stays backward-compatible while
still giving callers and consumers a real type.
"""

from __future__ import annotations

from ctfy.core.models import CtfyModel

__all__ = ["ActivityDetail"]


class ActivityDetail(CtfyModel):
    """Event-specific extra fields attached to an ``Activity``.

    Each field is populated by at least one ``PlatformEvent`` — see
    ``ctfy.server.events.emit_event`` for the mapping.
    """

    # Instance-scoped events (INSTANCE_STARTED / _READY / _ERROR / _STOPPED
    # / _RENEWED, FLAG_CORRECT / _WRONG)
    instance_id: str | None = None

    # INSTANCE_READY, NODE_REGISTERED, NODE_UNHEALTHY, NODE_REMOVED
    node_id: str | None = None

    # NODE_REGISTERED, NODE_UNHEALTHY
    url: str | None = None

    # INSTANCE_ERROR
    error: str | None = None

    # INSTANCE_RENEWED
    ttl: int | None = None

    # INSTANCE_STOPPED (e.g. ``"auto_stop_after_solve"`` when a correct flag
    # submission triggers the auto-destroy path).
    reason: str | None = None

    # FLAG_CORRECT (seconds from instance start to correct submission) /
    # FLAG_WRONG (always 0).
    solve_time_s: float | None = None

    # Populated on events triggered by an authenticated HTTP request:
    # TEAM_REGISTERED, INSTANCE_STARTED, INSTANCE_STOPPED (user-initiated),
    # FLAG_CORRECT, FLAG_WRONG. Recorded verbatim from ``request.client.host``
    # — X-Forwarded-For is intentionally ignored so the field reflects the
    # platform's direct peer, not a header an attacker can forge.
    ip: str | None = None

    # NODE_UPDATED
    display_name: str | None = None
    labels_changed: list[str] | None = None

    # NODE_UNHEALTHY — free-form description of the failure, e.g.
    # "No heartbeat for 132.4s (timeout 120s)". Surfaces in the admin
    # downtime history card.
    error_message: str | None = None

    # NODE_RECOVERED — wall-clock gap between the last successful
    # heartbeat and the recovery beat. Pairs with the preceding
    # NODE_UNHEALTHY so the UI can render closed downtime windows
    # with a duration.
    downtime_seconds: float | None = None

    # ACHIEVEMENT_UNLOCKED
    achievement_id: str | None = None
    achievement_name: str | None = None
    tier: str | None = None
    secret: bool | None = None

    # TEAM_ROLE_CHANGED — old/new role names for audit display.
    previous_role: str | None = None
    new_role: str | None = None

    # COMPETITION_REGISTERED / COMPETITION_UNREGISTERED — denormalized title
    # so the activity feed can display "joined Spring CTF" without
    # joining back on the competitions table (which may have since been
    # deleted).
    competition_id: str | None = None
    competition_title: str | None = None

    # TEAM_MEMBER_JOINED — invite that was redeemed (helps correlate
    # captain mints to redeemers).
    invite_id: str | None = None

    # TEAM_MEMBER_KICKED — denormalized so the audit row can render
    # "Cap kicked Mem from Squad" without re-resolving a maybe-deleted
    # user row.
    target_user_id: str | None = None
    target_user_name: str | None = None
