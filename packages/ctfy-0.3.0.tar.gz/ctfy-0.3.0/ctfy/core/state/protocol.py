"""StateBackend Protocol — contract for instance / node / placement state storage."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from typing import Literal

from ctfy.core.state.models import (
    AchievementRecord,
    ActivityState,
    AnnouncementReadState,
    AnnouncementState,
    CompetitionState,
    InstanceRecord,
    InstanceState,
    NodeHealthSample,
    NodeInviteState,
    NodeState,
    OAuthIdentity,
    PasswordIdentity,
    ScoreboardSnapshotState,
    SolveState,
    SubmissionState,
    TeamInviteState,
    TeamMembershipState,
    TeamState,
    TeamToken,
    UserState,
)


@runtime_checkable
class StateBackend(Protocol):
    """Contract for instance / node / placement state storage."""

    # -- instance state -----------------------------------------------------

    def put_instance(self, instance_id: str, data: InstanceState, ttl: int = 0) -> None: ...
    def get_instance(self, instance_id: str) -> InstanceState | None: ...
    def remove_instance(self, instance_id: str) -> InstanceState | None: ...
    def list_instances(self) -> list[InstanceState]: ...
    def count_instances(self) -> int: ...
    def renew_instance(self, instance_id: str, ttl: int) -> float: ...
    def get_instance_by_team_challenge(
        self, team_id: str, challenge_id: str
    ) -> InstanceState | None: ...

    # -- expired instance iteration (for reaper) ---------------------------

    def pop_expired_instances(self) -> list[InstanceState]: ...

    # -- archived instance records (permanent history) ----------------------

    def archive_instance(self, record: InstanceRecord) -> None: ...
    def get_instance_record(self, instance_id: str) -> InstanceRecord | None: ...
    def list_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
        offset: int = 0,
        limit: int = 100,
    ) -> list[InstanceRecord]: ...
    def count_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
    ) -> int: ...

    # -- config (key-value) --------------------------------------------------

    def get_config(self, key: str) -> str | None: ...
    def set_config(self, key: str, value: str) -> None: ...
    def delete_config(self, key: str) -> None: ...

    # -- nodes (worker registration + heartbeat) -----------------------------

    def put_node(self, node_id: str, data: NodeState) -> None: ...
    def get_node(self, node_id: str) -> NodeState | None: ...
    def get_node_by_token(self, token: str) -> NodeState | None: ...
    def list_nodes(self) -> list[NodeState]: ...
    def remove_node(self, node_id: str) -> None: ...

    # -- node health history (bounded ring per node) ------------------------

    def append_health_sample(self, sample: NodeHealthSample) -> None: ...
    def list_health_samples(self, node_id: str, limit: int = 200) -> list[NodeHealthSample]: ...

    # -- node invites (one-time registration credentials) --------------------

    def put_invite(self, invite: NodeInviteState) -> None: ...
    def get_invite(self, invite_id: str) -> NodeInviteState | None: ...
    def get_invite_by_hash(self, token_hash: str) -> NodeInviteState | None: ...
    def list_invites(self) -> list[NodeInviteState]: ...
    def consume_invite(self, token_hash: str, node_id: str) -> NodeInviteState | None: ...
    def remove_invite(self, invite_id: str) -> None: ...

    # -- teams ---------------------------------------------------------------

    def put_team(self, team_id: str, data: TeamState) -> None: ...
    def get_team(self, team_id: str) -> TeamState | None: ...
    # Hard cascading delete: removes the team row plus every per-team
    # row across identities, tokens, submissions, solves, activities,
    # snapshots, achievements, and counters. Implementations must wrap
    # the work in their backend's transactional unit so a partial
    # failure leaves no orphans. Returns True when a row was deleted,
    # False when ``team_id`` didn't exist (idempotent on re-call).
    def delete_team(self, team_id: str) -> bool: ...
    # Resolve a hashed bearer token to its owning team. Internally walks
    # ``team_tokens`` to find an active (non-revoked) row, then returns the
    # team; revoked tokens are reported as "no match".
    def get_team_by_token(self, token_hash: str) -> TeamState | None: ...
    def list_teams(self) -> list[TeamState]: ...
    def count_teams(self) -> int: ...

    # -- OAuth identities ----------------------------------------------------
    #
    # A team can bind multiple OAuth identities (one per provider, with
    # (provider, provider_user_id) globally unique). Auth routes add/remove
    # rows here; login lookups use ``get_identity_by_provider_uid`` first and
    # only fall back to email-based auto-merge when no row matches.

    def put_identity(self, identity: OAuthIdentity) -> None: ...
    def get_identity(self, identity_id: str) -> OAuthIdentity | None: ...
    def get_identity_by_provider_uid(
        self, provider: str, provider_user_id: str
    ) -> OAuthIdentity | None: ...
    def list_identities_for_user(self, user_id: str) -> list[OAuthIdentity]: ...
    def remove_identity(self, identity_id: str) -> bool: ...

    # -- password identities (local email+password auth) --------------------
    #
    # Parallel to OAuth identities but keyed by email rather than
    # (provider, provider_user_id). At most one row per team; email is
    # globally unique (case-insensitive). Registration does not verify
    # email ownership, so these never match ``CTFY_SUPER_ADMIN_EMAILS`` —
    # see ``_apply_super_admin_status`` in the auth routes.

    def put_password_identity(self, identity: PasswordIdentity) -> None: ...
    def get_password_identity(self, identity_id: str) -> PasswordIdentity | None: ...
    def get_password_identity_by_email(self, email: str) -> PasswordIdentity | None: ...
    def list_password_identities_for_user(
        self, user_id: str
    ) -> list[PasswordIdentity]: ...
    def remove_password_identity(self, identity_id: str) -> bool: ...

    # -- team tokens (user + agent) -----------------------------------------
    #
    # Replaces the old single ``teams.token`` column. Each team owns many
    # tokens across two kinds (``user`` / ``agent``); both are hashed with
    # SHA-256 before storage. Revoked tokens are retained (not deleted) so
    # audit logs can still resolve their origin.

    def put_token(self, token: TeamToken) -> None: ...
    def get_token_by_hash(self, token_hash: str) -> TeamToken | None: ...
    def get_token(self, token_id: str) -> TeamToken | None: ...
    def list_tokens_for_user(
        self,
        user_id: str,
        *,
        kind: str = "",
        include_revoked: bool = False,
    ) -> list[TeamToken]: ...
    def revoke_token(self, token_id: str, ts: str) -> bool: ...
    def touch_token(self, token_id: str, ts: str) -> None: ...

    # -- submissions ---------------------------------------------------------

    def add_submission(self, data: SubmissionState) -> None: ...
    def list_submissions(
        self,
        team_id: str = "",
        challenge_id: str = "",
        *,
        user_id: str = "",
    ) -> list[SubmissionState]: ...

    # -- solves --------------------------------------------------------------
    #
    # Solves are tracked per (team, challenge, flag_id). Single-flag
    # challenges use flag_id="main". ``count_solves_for_challenge`` returns
    # the number of *teams* that have fully solved the challenge (captured
    # every declared flag); ``count_solves_for_flag`` returns teams who
    # captured a specific flag. For a single-flag challenge both functions
    # return the same value.

    def add_solve(
        self, team_id: str, challenge_id: str, flag_id: str, data: SolveState
    ) -> None: ...
    def get_solve(
        self, team_id: str, challenge_id: str, flag_id: str
    ) -> SolveState | None: ...
    def list_solves(
        self, team_id: str = "", *, user_id: str = ""
    ) -> list[SolveState]: ...
    def count_solves_for_flag(self, challenge_id: str, flag_id: str) -> int: ...
    def get_flag_solve_rank(
        self, team_id: str, challenge_id: str, flag_id: str
    ) -> int:
        """Return the team's 1-indexed rank in the flag's solve order.

        ``0`` means the team hasn't captured the flag. Rank is computed
        by ``solved_at`` ascending, mirroring how ``count_solves_for_flag``
        would tally at the moment of solve.
        """
        ...
    def count_solves_for_challenge(
        self, challenge_id: str, flag_ids: tuple[str, ...] = ()
    ) -> int: ...

    # -- activity log --------------------------------------------------------

    def add_activity(self, data: ActivityState) -> None: ...
    def list_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        since: str = "",
        until: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[ActivityState]: ...
    def count_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        since: str = "",
        until: str = "",
    ) -> int: ...

    # -- scoreboard snapshots ------------------------------------------------
    #
    # Snapshots are append-only and kept permanently so post-competition
    # reviews always have the full rank-over-time curve. No prune.

    def append_snapshot_batch(self, snapshots: list[ScoreboardSnapshotState]) -> None: ...
    def list_snapshots(
        self,
        *,
        team_id: str = "",
        since_ts: float = 0.0,
        limit: int = 0,
    ) -> list[ScoreboardSnapshotState]: ...

    # -- achievements --------------------------------------------------------
    #
    # Grant is idempotent on (team_id, achievement_id); a second call returns
    # None so evaluators can use the return value to tell "true unlock" from
    # "already had it" and only emit the ACHIEVEMENT_UNLOCKED event once.
    # Counters are a cheap aggregate store for predicates that don't want to
    # replay the submissions table (e.g. Sisyphus: wrong-attempts-on-same-
    # challenge-before-solve).

    # -- announcements -------------------------------------------------------
    #
    # Site-wide notices posted by admins. ``list_announcements`` with
    # ``active_only=True`` filters by the supplied ``now_iso`` against the
    # announcement's start/end window, so the public banner endpoint can
    # punt the date arithmetic to the backend (sqlite does it in SQL).

    def put_announcement(self, ann: AnnouncementState) -> None: ...
    def get_announcement(self, announcement_id: str) -> AnnouncementState | None: ...
    def list_announcements(
        self,
        *,
        active_only: bool = False,
        now_iso: str = "",
        limit: int = 100,
    ) -> list[AnnouncementState]: ...
    def delete_announcement(self, announcement_id: str) -> bool: ...

    # -- announcement read receipts -----------------------------------------
    #
    # Per-user read state for announcements. The Inbox renders an
    # "unread" badge by checking which currently-active announcements
    # the user has not yet acknowledged. ``mark_announcement_read`` is
    # idempotent — a re-mark keeps the original ``read_at`` so the
    # audit trail isn't trampled.

    def mark_announcement_read(
        self, user_id: str, announcement_id: str, now_iso: str
    ) -> bool: ...
    """Returns True iff a new row was inserted (False on no-op repeats)."""

    def mark_announcements_read_bulk(
        self, user_id: str, announcement_ids: list[str], now_iso: str
    ) -> int: ...
    """Returns the number of newly-read rows (excludes idempotent hits)."""

    def list_read_announcement_ids(self, user_id: str) -> set[str]: ...

    # -- users (post user/team split) ---------------------------------------
    #
    # ``UserState`` carries auth + profile + role. A user is always
    # associated with exactly one ``TeamState`` via ``TeamMembershipState``;
    # on first registration we mint a personal team and join the user
    # to it so the legacy "register and you're a team" UX keeps working.

    def put_user(self, user_id: str, data: UserState) -> None: ...
    def get_user(self, user_id: str) -> UserState | None: ...
    def get_user_by_email(self, email: str) -> UserState | None: ...
    def list_users(self) -> list[UserState]: ...
    def count_users(self) -> int: ...
    # ``delete_user`` cascades the user's identities, tokens, and team
    # membership. Solves and activity rows are left intact (history
    # is preserved against the user_id even after deletion).
    def delete_user(self, user_id: str) -> bool: ...
    # First-user-becomes-super-admin atomic upsert. Mirrors
    # ``put_team_first_user_aware`` so a fresh deployment can come up
    # without OAuth + env. Concurrent registrations cannot both win.
    def put_user_first_user_aware(
        self, user_id: str, user: UserState
    ) -> UserState: ...

    # -- team membership ----------------------------------------------------
    #
    # One team per user. ``put_membership`` is upsert-by-user_id —
    # writing again replaces the user's current team in one critical
    # section. ``delete_team`` cascades memberships + invites; the
    # ex-members are left without a team and the route layer is
    # responsible for spinning them a fresh personal team.

    def put_membership(self, m: TeamMembershipState) -> None: ...
    # Convenience: any membership row for the given user, or None.
    # Per-comp routes use ``get_membership_for_competition`` directly;
    # this helper is for tests and legacy "any team" idioms.
    def get_membership(self, user_id: str) -> TeamMembershipState | None: ...
    def get_membership_for_competition(
        self, user_id: str, competition_id: str
    ) -> TeamMembershipState | None: ...
    def list_memberships(
        self,
        *,
        team_id: str = "",
        user_id: str = "",
        competition_id: str = "",
    ) -> list[TeamMembershipState]: ...
    def count_memberships(self, team_id: str) -> int: ...
    def delete_membership(self, user_id: str) -> bool: ...

    # -- team invites -------------------------------------------------------
    #
    # ``code`` is the short opaque string the captain hands out;
    # lookups are by-code. ``consume_invite_atomic`` validates window /
    # max-uses / revoked status and increments use_count in one shot —
    # the per-team join flow uses this to avoid a check-then-act race.

    def put_team_invite(self, inv: TeamInviteState) -> None: ...
    def get_team_invite(self, invite_id: str) -> TeamInviteState | None: ...
    def get_team_invite_by_code(self, code: str) -> TeamInviteState | None: ...
    def list_team_invites(
        self, *, team_id: str = ""
    ) -> list[TeamInviteState]: ...
    def revoke_team_invite(self, invite_id: str, ts: str) -> bool: ...
    def consume_team_invite_atomic(
        self, code: str, now_iso: str
    ) -> TeamInviteState | None: ...

    # -- competitions --------------------------------------------------------
    #
    # Admin-curated time-windowed CTF events. The competition row carries
    # the curated ``challenge_ids`` subset; per-team registrations live in
    # their own table. ``list_competitions`` filters by phase against
    # ``now_iso`` so the public banner endpoint can punt the date
    # arithmetic to the backend (sqlite does it in SQL). The leaderboard
    # is computed at read time by ``compute_scoreboard_filtered`` over
    # (registered teams) × (curated challenges) × time window — no
    # competition fields are stamped on submissions/solves.

    def put_competition(self, comp: CompetitionState) -> None: ...
    def get_competition(self, competition_id: str) -> CompetitionState | None: ...
    def list_competitions(
        self,
        *,
        phase: Literal["", "upcoming", "running", "past"] = "",
        now_iso: str = "",
        limit: int = 100,
    ) -> list[CompetitionState]: ...
    # Removes the competition row only; per-comp teams are dropped
    # via ``remove_from_competition_team`` / ``delete_team``.
    def delete_competition(self, competition_id: str) -> bool: ...

    def list_achievements(self, team_id: str) -> list[AchievementRecord]: ...
    def has_achievement(self, team_id: str, achievement_id: str) -> bool: ...
    def grant_achievement(
        self,
        team_id: str,
        achievement_id: str,
        context: dict | None = None,
    ) -> AchievementRecord | None: ...
    def revoke_achievement(self, team_id: str, achievement_id: str) -> bool: ...
    # Aggregate "how many distinct teams hold each badge" — used by the
    # public catalog endpoint to render rarity / earned-by counts. Returns
    # a dense dict keyed by ``achievement_id``; achievements with zero
    # unlocks may be omitted (callers default to 0).
    def count_unlocks_by_achievement(self) -> dict[str, int]: ...
    # Newest-first global feed of recent unlocks — powers the platform-wide
    # "recent activity" surface on the achievements page. Caller is
    # responsible for filtering secrets / orphaned teams.
    def list_recent_achievement_unlocks(self, limit: int = 20) -> list[AchievementRecord]: ...
    def bump_counter(self, team_id: str, key: str, delta: int = 1) -> int: ...
    def get_counter(self, team_id: str, key: str) -> int: ...
    def reset_counter(self, team_id: str, key: str) -> None: ...
