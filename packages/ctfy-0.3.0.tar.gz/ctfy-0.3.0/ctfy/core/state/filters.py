"""Pure predicates used by the in-memory state backend.

The memory backend fetches records into Python lists and filters them
client-side. SQLite expresses the same filters as ``WHERE`` clauses and
does not import this module.
"""

from __future__ import annotations

from ctfy.core.state.models import ActivityState, SubmissionState


def match_activity(
    a: ActivityState,
    *,
    team_id: str = "",
    challenge_id: str = "",
    event: str = "",
    events: tuple[str, ...] = (),
    actor_id: str = "",
    since: str = "",
    until: str = "",
) -> bool:
    """True if *a* satisfies every non-empty filter.

    ``since`` / ``until`` bound the row's ``timestamp`` (an ISO-8601
    string written by ``now_iso()``). Lexicographic comparison works
    here because every row uses the same canonical UTC format with
    millisecond precision and a trailing ``Z`` — so ordering by string
    matches ordering by absolute time.
    """
    if team_id and a.team_id != team_id:
        return False
    if challenge_id and a.challenge_id != challenge_id:
        return False
    if event and a.event != event:
        return False
    if events and a.event not in events:
        return False
    if actor_id and a.actor_id != actor_id:
        return False
    if since and a.timestamp < since:
        return False
    if until and a.timestamp > until:
        return False
    return True


def match_submission(s: SubmissionState, *, team_id: str = "", challenge_id: str = "") -> bool:
    """True if *s* satisfies every non-empty filter."""
    if team_id and s.team_id != team_id:
        return False
    if challenge_id and s.challenge_id != challenge_id:
        return False
    return True
