"""SQLiteBackend — SQLite-backed state backend."""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timezone

from typing import Literal

from ctfy.core.state.models import (
    AchievementRecord,
    ActivityState,
    AnnouncementReadState,
    AnnouncementState,
    CompetitionState,
    InstanceRecord,
    InstanceState,
    NodeHealthSample,
    NodeInviteState,
    NodeState,
    OAuthIdentity,
    PasswordIdentity,
    ScoreboardSnapshotState,
    SolveState,
    SubmissionState,
    TeamInviteState,
    TeamMembershipState,
    TeamState,
    TeamToken,
    UserState,
)

# Upper bound on health samples kept per node. Shared with the in-memory
# backend via ``HEALTH_SAMPLE_RING_SIZE`` in memory.py — bump both.
HEALTH_SAMPLE_RING_SIZE = 200


class SQLiteBackend:
    """SQLite-backed state. Persistent across restarts.

    Instances (ephemeral) are kept in memory. Everything else
    (teams, submissions, solves, activities) is stored in SQLite.
    """

    def __init__(self, db_path: str) -> None:
        self._db_path = db_path
        # sqlite3.Connection is not thread-safe for concurrent cursor use.
        # Give each thread its own connection (WAL lets readers run in
        # parallel; the SQLite file itself serializes writers).
        self._local = threading.local()
        self._instance_lock = threading.Lock()
        self._instances: dict[str, InstanceState] = {}
        self._init_tables()
        self._migrate()
        # Indexes whose column might have been renamed by ``_migrate``
        # (oauth_identities / password_identities / team_tokens —
        # ``team_id`` → ``user_id`` in v1). Created after migrate so
        # both fresh and post-migration DBs land them on the new
        # column name.
        with self._conn:
            self._conn.executescript(
                """
                CREATE INDEX IF NOT EXISTS idx_identity_user
                    ON oauth_identities(user_id);
                CREATE INDEX IF NOT EXISTS idx_pwd_identity_user
                    ON password_identities(user_id);
                CREATE INDEX IF NOT EXISTS idx_token_user
                    ON team_tokens(user_id);
                """
            )

    @property
    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self._db_path)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA busy_timeout=5000")
            self._local.conn = conn
        return conn

    def _init_tables(self) -> None:
        with self._conn:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS config (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS nodes (
                    node_id TEXT PRIMARY KEY,
                    data TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS node_invites (
                    invite_id TEXT PRIMARY KEY,
                    token_hash TEXT NOT NULL,
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_invite_hash
                    ON node_invites(token_hash);
                CREATE TABLE IF NOT EXISTS node_health_samples (
                    node_id TEXT NOT NULL,
                    ts REAL NOT NULL,
                    data TEXT NOT NULL,
                    PRIMARY KEY (node_id, ts)
                );
                CREATE INDEX IF NOT EXISTS idx_health_node_ts
                    ON node_health_samples(node_id, ts DESC);
                CREATE TABLE IF NOT EXISTS teams (
                    team_id TEXT PRIMARY KEY,
                    data TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS oauth_identities (
                    identity_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    provider_user_id TEXT NOT NULL,
                    data TEXT NOT NULL,
                    UNIQUE(provider, provider_user_id)
                );
                CREATE TABLE IF NOT EXISTS password_identities (
                    identity_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    data TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS team_tokens (
                    token_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    token_hash TEXT NOT NULL UNIQUE,
                    kind TEXT NOT NULL,
                    data TEXT NOT NULL
                );
                -- Indexes for the three tables above are created in
                -- ``__init__`` after ``_migrate`` runs (the legacy
                -- column was named ``team_id``; the v1 cleanup
                -- migration renames it to ``user_id``).
                CREATE TABLE IF NOT EXISTS submissions (
                    submission_id TEXT PRIMARY KEY,
                    team_id TEXT NOT NULL,
                    challenge_id TEXT NOT NULL,
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_sub_team
                    ON submissions(team_id);
                CREATE INDEX IF NOT EXISTS idx_sub_challenge
                    ON submissions(challenge_id);
                CREATE TABLE IF NOT EXISTS solves (
                    team_id TEXT NOT NULL,
                    challenge_id TEXT NOT NULL,
                    flag_id TEXT NOT NULL DEFAULT 'main',
                    data TEXT NOT NULL,
                    PRIMARY KEY (team_id, challenge_id, flag_id)
                );
                CREATE INDEX IF NOT EXISTS idx_solves_challenge_flag
                    ON solves(challenge_id, flag_id);
                CREATE TABLE IF NOT EXISTS activities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event TEXT NOT NULL,
                    team_id TEXT NOT NULL DEFAULT '',
                    challenge_id TEXT NOT NULL DEFAULT '',
                    actor_id TEXT NOT NULL DEFAULT '',
                    actor_name TEXT NOT NULL DEFAULT '',
                    actor_type TEXT NOT NULL DEFAULT '',
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_act_team
                    ON activities(team_id);
                CREATE INDEX IF NOT EXISTS idx_act_event
                    ON activities(event);
                CREATE INDEX IF NOT EXISTS idx_act_actor
                    ON activities(actor_id);
                CREATE TABLE IF NOT EXISTS instance_records (
                    instance_id TEXT PRIMARY KEY,
                    team_id TEXT NOT NULL DEFAULT '',
                    challenge_id TEXT NOT NULL DEFAULT '',
                    node_id TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT '',
                    started_at REAL NOT NULL DEFAULT 0,
                    stopped_at REAL NOT NULL DEFAULT 0,
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_ir_team
                    ON instance_records(team_id);
                CREATE INDEX IF NOT EXISTS idx_ir_challenge
                    ON instance_records(challenge_id);
                CREATE INDEX IF NOT EXISTS idx_ir_node
                    ON instance_records(node_id);
                CREATE INDEX IF NOT EXISTS idx_ir_started
                    ON instance_records(started_at DESC);
                CREATE TABLE IF NOT EXISTS scoreboard_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    snapshot_at TEXT NOT NULL,
                    snapshot_at_ts REAL NOT NULL,
                    team_id TEXT NOT NULL,
                    team_name TEXT NOT NULL,
                    rank INTEGER NOT NULL,
                    solved INTEGER NOT NULL,
                    attempts INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_snap_team_ts
                    ON scoreboard_snapshots(team_id, snapshot_at_ts DESC);
                CREATE INDEX IF NOT EXISTS idx_snap_ts
                    ON scoreboard_snapshots(snapshot_at_ts DESC);
                CREATE TABLE IF NOT EXISTS team_achievements (
                    team_id TEXT NOT NULL,
                    achievement_id TEXT NOT NULL,
                    unlocked_at TEXT NOT NULL,
                    context_json TEXT NOT NULL DEFAULT '{}',
                    PRIMARY KEY (team_id, achievement_id)
                );
                CREATE INDEX IF NOT EXISTS idx_ach_team
                    ON team_achievements(team_id);
                CREATE INDEX IF NOT EXISTS idx_ach_id
                    ON team_achievements(achievement_id);
                CREATE TABLE IF NOT EXISTS achievement_counters (
                    team_id TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (team_id, key)
                );
                CREATE TABLE IF NOT EXISTS announcements (
                    announcement_id TEXT PRIMARY KEY,
                    starts_at TEXT NOT NULL DEFAULT '',
                    ends_at TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT '',
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_ann_created_at
                    ON announcements(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_ann_window
                    ON announcements(starts_at, ends_at);
                CREATE TABLE IF NOT EXISTS announcement_reads (
                    user_id          TEXT NOT NULL,
                    announcement_id  TEXT NOT NULL,
                    read_at          TEXT NOT NULL,
                    PRIMARY KEY (user_id, announcement_id)
                );
                CREATE INDEX IF NOT EXISTS idx_ann_reads_user
                    ON announcement_reads(user_id);
                CREATE TABLE IF NOT EXISTS competitions (
                    competition_id TEXT PRIMARY KEY,
                    starts_at TEXT NOT NULL DEFAULT '',
                    ends_at TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT '',
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_comp_window
                    ON competitions(starts_at, ends_at);
                CREATE INDEX IF NOT EXISTS idx_comp_created_at
                    ON competitions(created_at DESC);
                -- Post user/team-split. ``users`` is the auth principal;
                -- ``team_memberships`` maps user → current team (one team
                -- per user); ``team_invites`` carry captain-issued join
                -- codes consumed atomically by the invite redeem flow.
                CREATE TABLE IF NOT EXISTS users (
                    user_id TEXT PRIMARY KEY,
                    email TEXT NOT NULL DEFAULT '',
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_user_email ON users(email);
                CREATE TABLE IF NOT EXISTS team_memberships (
                    user_id TEXT NOT NULL,
                    team_id TEXT NOT NULL,
                    joined_at TEXT NOT NULL DEFAULT '',
                    joined_via TEXT NOT NULL DEFAULT '',
                    invited_by_user_id TEXT NOT NULL DEFAULT '',
                    competition_id TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (user_id, competition_id)
                );
                CREATE INDEX IF NOT EXISTS idx_membership_user
                    ON team_memberships(user_id);
                CREATE INDEX IF NOT EXISTS idx_membership_team
                    ON team_memberships(team_id);
                CREATE TABLE IF NOT EXISTS team_invites (
                    invite_id TEXT PRIMARY KEY,
                    team_id TEXT NOT NULL,
                    code TEXT NOT NULL UNIQUE,
                    created_by_user_id TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT '',
                    expires_at TEXT NOT NULL DEFAULT '',
                    max_uses INTEGER NOT NULL DEFAULT 1,
                    use_count INTEGER NOT NULL DEFAULT 0,
                    revoked_at TEXT NOT NULL DEFAULT '',
                    competition_id TEXT NOT NULL DEFAULT '',
                    kind TEXT NOT NULL DEFAULT 'code',
                    target_user_id TEXT NOT NULL DEFAULT ''
                );
                CREATE INDEX IF NOT EXISTS idx_invite_team
                    ON team_invites(team_id);
            """)

    def _migrate(self) -> None:
        """Apply in-place schema migrations for older DB files.

        The project dropped per-team bearer tokens stored on ``teams.token``
        when the OAuth model was introduced; fresh DBs get the new schema
        directly from ``_init_tables``. Dev DBs predating the cutover must
        be deleted (``rm ctfy.db``) — see README for details.
        """
        # Activity schema — actor_* columns were added with the audit-
        # tracking work. Old rows carry no actor context and would fail
        # pydantic validation (actor_* are required on ActivityState),
        # so drop + recreate rather than ALTER + backfill. The activity
        # log is strictly a display/audit surface; losing history on
        # upgrade is an acceptable tradeoff for a strict schema.
        act_cols = {r[1] for r in self._conn.execute("PRAGMA table_info(activities)")}
        if act_cols and "actor_id" not in act_cols:
            with self._conn:
                self._conn.execute("DROP TABLE activities")
                self._conn.execute(
                    """
                    CREATE TABLE activities (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT NOT NULL,
                        event TEXT NOT NULL,
                        team_id TEXT NOT NULL DEFAULT '',
                        challenge_id TEXT NOT NULL DEFAULT '',
                        actor_id TEXT NOT NULL DEFAULT '',
                        actor_name TEXT NOT NULL DEFAULT '',
                        actor_type TEXT NOT NULL DEFAULT '',
                        data TEXT NOT NULL
                    )
                    """
                )
                self._conn.execute("CREATE INDEX idx_act_team ON activities(team_id)")
                self._conn.execute("CREATE INDEX idx_act_event ON activities(event)")
                self._conn.execute("CREATE INDEX idx_act_actor ON activities(actor_id)")

        # NodeState grew a display_name field. Old node JSON blobs don't
        # carry it; reserialize them with display_name seeded to node_id
        # so subsequent reads validate cleanly without any fallback in
        # the request path.
        with self._conn:
            for row in self._conn.execute("SELECT node_id, data FROM nodes"):
                if not row[1]:
                    continue
                try:
                    blob = json.loads(row[1])
                except Exception:
                    continue
                if blob.get("display_name"):
                    continue
                blob["display_name"] = blob.get("node_id") or row[0]
                self._conn.execute(
                    "UPDATE nodes SET data = ? WHERE node_id = ?",
                    (json.dumps(blob), row[0]),
                )

        # Solves grew a flag_id column for multi-flag support. Old DBs have
        # only (team_id, challenge_id) PK; add flag_id with default "main",
        # rewrite the JSON blob to include flag_id="main", then rebuild the
        # composite PK + index. Single-flag challenges keep the same solve
        # behavior after migration.
        solve_cols = {r[1] for r in self._conn.execute("PRAGMA table_info(solves)")}
        if solve_cols and "flag_id" not in solve_cols:
            with self._conn:
                self._conn.execute(
                    "ALTER TABLE solves ADD COLUMN flag_id TEXT NOT NULL DEFAULT 'main'"
                )
                for row in self._conn.execute(
                    "SELECT team_id, challenge_id, data FROM solves"
                ):
                    if not row[2]:
                        continue
                    try:
                        blob = json.loads(row[2])
                    except Exception:
                        continue
                    if not blob.get("flag_id"):
                        blob["flag_id"] = "main"
                        self._conn.execute(
                            "UPDATE solves SET data = ? "
                            "WHERE team_id = ? AND challenge_id = ?",
                            (json.dumps(blob), row[0], row[1]),
                        )
                # Rebuild with composite PK on (team, chal, flag_id).
                self._conn.execute("ALTER TABLE solves RENAME TO solves_old")
                self._conn.execute(
                    """
                    CREATE TABLE solves (
                        team_id TEXT NOT NULL,
                        challenge_id TEXT NOT NULL,
                        flag_id TEXT NOT NULL DEFAULT 'main',
                        data TEXT NOT NULL,
                        PRIMARY KEY (team_id, challenge_id, flag_id)
                    )
                    """
                )
                self._conn.execute(
                    "INSERT INTO solves (team_id, challenge_id, flag_id, data) "
                    "SELECT team_id, challenge_id, flag_id, data FROM solves_old"
                )
                self._conn.execute("DROP TABLE solves_old")
                self._conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_solves_challenge_flag "
                    "ON solves(challenge_id, flag_id)"
                )

        # The ``console_cowboy`` easter egg was retired in favour of the
        # multi-step ``base64_cowboy`` puzzle. Existing unlocks are
        # orphaned (no catalog entry → never rendered), but they still
        # turn up in admin queries. Drop them once on startup. Safe to
        # run on fresh DBs — the DELETE simply matches zero rows.
        with self._conn:
            self._conn.execute(
                "DELETE FROM team_achievements WHERE achievement_id = 'console_cowboy'"
            )

        # TeamState's ``is_admin: bool`` was replaced by
        # ``role: "user"|"admin"|"super_admin"`` plus audit columns. Old
        # blobs carry ``is_admin`` (and no ``role``) — promote them now
        # so the model_validator never has to fall back. ``is_admin=True``
        # → ``role="admin"``; ``is_admin=False`` → ``role="user"``.
        # Super-admin promotion is intentionally not synthesized here —
        # the next OAuth callback re-applies CTFY_SUPER_ADMIN_EMAILS and
        # will upgrade matching emails on first sign-in. Idempotent on
        # already-migrated DBs (skips rows that already have ``role``).
        with self._conn:
            for row in self._conn.execute("SELECT team_id, data FROM teams"):
                if not row[1]:
                    continue
                try:
                    blob = json.loads(row[1])
                except Exception:
                    continue
                touched = False
                if "is_admin" in blob:
                    legacy = bool(blob.pop("is_admin"))
                    blob.setdefault("role", "admin" if legacy else "user")
                    touched = True
                # Belt-and-braces: ensure the role key exists even if a
                # blob predates both fields (theoretical, but cheap).
                if "role" not in blob:
                    blob["role"] = "user"
                    touched = True
                if touched:
                    self._conn.execute(
                        "UPDATE teams SET data = ? WHERE team_id = ?",
                        (json.dumps(blob), row[0]),
                    )

        # User/team split (one-shot per DB).
        #
        # Pre-split shape: each row in ``teams`` was the human — its
        # JSON blob carried email / display_name / avatar_url / role /
        # bio / country / website_url / timezone / social_links /
        # profile_visibility / promoted_by / promoted_at. The
        # ``oauth_identities``, ``password_identities``, and
        # ``team_tokens`` rows pointed at it via ``team_id``.
        #
        # Post-split: those auth + profile fields live on ``users``;
        # ``team_memberships`` links user → team; the ``teams`` JSON
        # blob is slimmed to {team_id, name, description,
        # captain_user_id, created_at}. Identities + tokens still
        # store ``team_id`` in their SQL column (renaming would be
        # destructive) — values are now interpreted as user_ids by
        # the storage layer, which works because user_id == old
        # team_id under this migration.
        #
        # Trigger condition: at least one ``teams`` row exists AND
        # ``users`` is empty. That makes the migration idempotent —
        # subsequent boots see ``users`` populated and skip.
        users_count = self._conn.execute(
            "SELECT COUNT(*) FROM users"
        ).fetchone()[0]
        teams_count = self._conn.execute(
            "SELECT COUNT(*) FROM teams"
        ).fetchone()[0]
        if users_count == 0 and teams_count > 0:
            with self._conn:
                for row in self._conn.execute("SELECT team_id, data FROM teams"):
                    team_id = row[0]
                    if not row[1]:
                        continue
                    try:
                        blob = json.loads(row[1])
                    except Exception:
                        continue
                    # Split the legacy blob: peel off auth + profile
                    # fields into a fresh ``users`` row, leave the
                    # team-scoped fields on ``teams`` (re-serialised
                    # in the slim post-split shape).
                    user_payload = {
                        "user_id": team_id,
                        "email": blob.get("email", ""),
                        "display_name": blob.get("display_name", "")
                        or blob.get("name", ""),
                        "avatar_url": blob.get("avatar_url", ""),
                        "created_at": blob.get("created_at", ""),
                        "role": blob.get("role", "user"),
                        "promoted_by": blob.get("promoted_by"),
                        "promoted_at": blob.get("promoted_at"),
                        "bio": blob.get("bio"),
                        "country": blob.get("country"),
                        "website_url": blob.get("website_url"),
                        "timezone": blob.get("timezone"),
                        "social_links": blob.get("social_links", {}),
                        "profile_visibility": blob.get(
                            "profile_visibility", {}
                        ),
                    }
                    self._conn.execute(
                        "INSERT OR REPLACE INTO users "
                        "(user_id, email, data) VALUES (?, ?, ?)",
                        (
                            team_id,
                            (user_payload["email"] or "").lower(),
                            json.dumps(user_payload),
                        ),
                    )
                    # Slim the team blob: keep team-scoped fields,
                    # set captain_user_id = team_id (= user_id).
                    slim_team = {
                        "team_id": team_id,
                        "name": blob.get("name", "")
                        or blob.get("display_name", ""),
                        "description": blob.get("description", ""),
                        "captain_user_id": team_id,
                        "created_at": blob.get("created_at", ""),
                    }
                    # ``teams.email`` column is dropped by v1 schema
                    # cleanup further down; until then the cell stays
                    # whatever the legacy row carried — harmless.
                    self._conn.execute(
                        "UPDATE teams SET data = ? WHERE team_id = ?",
                        (json.dumps(slim_team), team_id),
                    )
                    # Membership: legacy team had exactly one human in
                    # it (themselves). Joined at team.created_at.
                    self._conn.execute(
                        "INSERT OR REPLACE INTO team_memberships "
                        "(user_id, team_id, joined_at) VALUES (?, ?, ?)",
                        (team_id, team_id, blob.get("created_at", "")),
                    )

        # ---- v1 schema cleanup -------------------------------------
        # After the user/team-split landed in #396, the auth-attached
        # tables (``oauth_identities`` / ``password_identities`` /
        # ``team_tokens``) kept their legacy ``team_id`` column name
        # storing user_id values, and ``teams.email`` was left as a
        # write-empty deadweight column. Both are real footguns for
        # anyone reading raw SQL — clean them up under a versioned
        # one-shot migration so this runs at most once per DB. Skips
        # cleanly on already-migrated DBs (PRAGMA user_version >= 1).
        current_version = self._conn.execute(
            "PRAGMA user_version"
        ).fetchone()[0]
        if current_version < 1:
            with self._conn:
                # Each ALTER is idempotent — wrap in try / except so
                # an in-flight test DB that already has the new shape
                # (e.g. from a partial v1 run aborted mid-way) doesn't
                # crash the boot. ``IF NOT EXISTS`` isn't supported on
                # ALTER COLUMN; sqlite_master probe instead.
                def _has_column(table: str, column: str) -> bool:
                    rows = self._conn.execute(
                        f"PRAGMA table_info({table})"
                    ).fetchall()
                    return any(r[1] == column for r in rows)

                renames = [
                    ("oauth_identities", "team_id", "user_id"),
                    ("password_identities", "team_id", "user_id"),
                    ("team_tokens", "team_id", "user_id"),
                ]
                for table, old, new in renames:
                    if _has_column(table, old) and not _has_column(table, new):
                        self._conn.execute(
                            f"ALTER TABLE {table} RENAME COLUMN {old} TO {new}"
                        )
                # Indexes — drop the old name, add the new one. The
                # CREATE INDEX in ``_init_tables`` handles fresh DBs;
                # this branch is only for legacy.
                for old_idx, new_idx, table, col in [
                    (
                        "idx_identity_team",
                        "idx_identity_user",
                        "oauth_identities",
                        "user_id",
                    ),
                    (
                        "idx_pwd_identity_team",
                        "idx_pwd_identity_user",
                        "password_identities",
                        "user_id",
                    ),
                    (
                        "idx_token_team",
                        "idx_token_user",
                        "team_tokens",
                        "user_id",
                    ),
                ]:
                    self._conn.execute(f"DROP INDEX IF EXISTS {old_idx}")
                    self._conn.execute(
                        f"CREATE INDEX IF NOT EXISTS {new_idx} ON {table}({col})"
                    )
                # Drop ``teams.email`` (write-empty deadweight).
                if _has_column("teams", "email"):
                    self._conn.execute("DROP INDEX IF EXISTS idx_team_email")
                    self._conn.execute(
                        "ALTER TABLE teams DROP COLUMN email"
                    )
                self._conn.execute("PRAGMA user_version = 1")

        # ── v2 cleanup: membership audit columns ──────────────────────────
        # Add ``joined_via`` + ``invited_by_user_id`` to existing
        # ``team_memberships`` tables so post-split deployments capture
        # *why* a user joined a team (register / create / leave / redeem).
        if current_version < 2:
            with self._conn:
                def _has_column_v2(table: str, column: str) -> bool:
                    rows = self._conn.execute(
                        f"PRAGMA table_info({table})"
                    ).fetchall()
                    return any(r[1] == column for r in rows)

                for col in ("joined_via", "invited_by_user_id"):
                    if not _has_column_v2("team_memberships", col):
                        self._conn.execute(
                            f"ALTER TABLE team_memberships ADD COLUMN {col} "
                            "TEXT NOT NULL DEFAULT ''"
                        )
                self._conn.execute("PRAGMA user_version = 2")

        # ── v3: per-competition team scoping (Phase 1, additive) ───────────
        # Add ``competition_id`` to every team-stamped table so subsequent
        # phases can populate the per-competition shape without a second
        # schema migration. Empty default is the legacy / un-scoped value.
        # Phase 2+ will tighten validation, change membership PK to
        # ``(user_id, competition_id)``, and require non-empty in routes.
        if current_version < 3:
            with self._conn:
                def _has_column_v3(table: str, column: str) -> bool:
                    rows = self._conn.execute(
                        f"PRAGMA table_info({table})"
                    ).fetchall()
                    return any(r[1] == column for r in rows)

                for table in (
                    "team_memberships",
                    "team_invites",
                ):
                    if not _has_column_v3(table, "competition_id"):
                        self._conn.execute(
                            f"ALTER TABLE {table} ADD COLUMN competition_id "
                            "TEXT NOT NULL DEFAULT ''"
                        )
                # Indices for the cheap per-comp lookups Phase 3 will
                # need (filter memberships / invites by competition).
                self._conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_membership_competition "
                    "ON team_memberships(competition_id)"
                )
                self._conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_invite_competition "
                    "ON team_invites(competition_id)"
                )
                self._conn.execute("PRAGMA user_version = 3")

        # ── v4: team_memberships composite PK (user_id, competition_id) ────
        # Phase 2a: a user can now hold N memberships, one per
        # competition. SQLite cannot ALTER PRIMARY KEY in place, so we
        # recreate the table and copy rows over (legacy rows have
        # ``competition_id == ""`` — they remain the user's "default"
        # membership and continue to satisfy ``get_membership(user_id)``).
        if current_version < 4:
            with self._conn:
                self._conn.executescript(
                    """
                    CREATE TABLE team_memberships_new (
                        user_id TEXT NOT NULL,
                        team_id TEXT NOT NULL,
                        joined_at TEXT NOT NULL DEFAULT '',
                        joined_via TEXT NOT NULL DEFAULT '',
                        invited_by_user_id TEXT NOT NULL DEFAULT '',
                        competition_id TEXT NOT NULL DEFAULT '',
                        PRIMARY KEY (user_id, competition_id)
                    );
                    INSERT INTO team_memberships_new
                        (user_id, team_id, joined_at, joined_via,
                         invited_by_user_id, competition_id)
                    SELECT user_id, team_id, joined_at, joined_via,
                           invited_by_user_id, competition_id
                    FROM team_memberships;
                    DROP TABLE team_memberships;
                    ALTER TABLE team_memberships_new RENAME TO
                        team_memberships;
                    CREATE INDEX IF NOT EXISTS idx_membership_team
                        ON team_memberships(team_id);
                    CREATE INDEX IF NOT EXISTS idx_membership_competition
                        ON team_memberships(competition_id);
                    CREATE INDEX IF NOT EXISTS idx_membership_user
                        ON team_memberships(user_id);
                    """
                )
                self._conn.execute("PRAGMA user_version = 4")

        # ── v5: drop the now-vestigial competition_registrations table ────
        # Phase 5e-3: ``CompetitionRegistrationState`` is gone — a team
        # existing with ``competition_id == X`` *is* the registration.
        # Drop the legacy table so legacy DBs don't carry orphan rows
        # forever. Idempotent.
        if current_version < 5:
            with self._conn:
                self._conn.execute(
                    "DROP TABLE IF EXISTS competition_registrations"
                )
                self._conn.execute("PRAGMA user_version = 5")

        # ── v6: invite ``kind`` and ``target_user_id`` columns ────────────
        # Foundation for the direct-invite (captain → user) and
        # join-request (member → captain) mechanisms layered on top of
        # the existing code-redeem flow. Pre-v6 rows become
        # ``kind='code'``, ``target_user_id=''`` (the SQLite defaults
        # match the model defaults), so existing call sites keep
        # working unchanged.
        if current_version < 6:
            with self._conn:
                def _has_column_v6(table: str, column: str) -> bool:
                    rows = self._conn.execute(
                        f"PRAGMA table_info({table})"
                    ).fetchall()
                    return any(r[1] == column for r in rows)

                if not _has_column_v6("team_invites", "kind"):
                    self._conn.execute(
                        "ALTER TABLE team_invites ADD COLUMN kind "
                        "TEXT NOT NULL DEFAULT 'code'"
                    )
                if not _has_column_v6("team_invites", "target_user_id"):
                    self._conn.execute(
                        "ALTER TABLE team_invites ADD COLUMN target_user_id "
                        "TEXT NOT NULL DEFAULT ''"
                    )
                self._conn.execute("PRAGMA user_version = 6")

        # ── v7: rewrite legacy ``team_id`` JSON keys to ``user_id`` ───────
        # The user/team-split rename (v1) renamed the SQL columns but left
        # the in-blob field name alone — old rows in oauth_identities /
        # password_identities / team_tokens still carry
        # ``"team_id": "<user_id>"`` inside their ``data`` JSON. Three
        # ``_alias_legacy_team_id`` validators in models.py papered over
        # this on every read. Walk the three tables once and rewrite the
        # blobs so the models can drop the validators.
        if current_version < 7:
            with self._conn:
                for table in (
                    "oauth_identities",
                    "password_identities",
                    "team_tokens",
                ):
                    for row in self._conn.execute(
                        f"SELECT rowid, data FROM {table}"
                    ).fetchall():
                        rowid, raw = row[0], row[1]
                        if not raw:
                            continue
                        try:
                            blob = json.loads(raw)
                        except Exception:
                            continue
                        if not isinstance(blob, dict) or "team_id" not in blob:
                            continue
                        legacy = blob.pop("team_id")
                        # If both keys were somehow present (defensive),
                        # the explicit ``user_id`` wins; the legacy value
                        # is dropped.
                        blob.setdefault("user_id", legacy)
                        self._conn.execute(
                            f"UPDATE {table} SET data = ? WHERE rowid = ?",
                            (json.dumps(blob), rowid),
                        )
                self._conn.execute("PRAGMA user_version = 7")

    # -- instance (in-memory, ephemeral) ------------------------------------

    def put_instance(self, instance_id: str, data: InstanceState, ttl: int = 0) -> None:
        now = time.time()
        data = data.model_copy(
            update={
                "started_at": data.started_at or now,
                "ttl": ttl,
                "expires_at": (now + ttl) if ttl > 0 else 0.0,
            }
        )
        with self._instance_lock:
            self._instances[instance_id] = data

    def get_instance(self, instance_id: str) -> InstanceState | None:
        with self._instance_lock:
            return self._instances.get(instance_id)

    def remove_instance(self, instance_id: str) -> InstanceState | None:
        with self._instance_lock:
            return self._instances.pop(instance_id, None)

    def list_instances(self) -> list[InstanceState]:
        with self._instance_lock:
            return [v.model_copy(update={"instance_id": k}) for k, v in self._instances.items()]

    def count_instances(self) -> int:
        with self._instance_lock:
            return len(self._instances)

    def renew_instance(self, instance_id: str, ttl: int) -> float:
        now = time.time()
        expires_at = (now + ttl) if ttl > 0 else 0.0
        with self._instance_lock:
            inst = self._instances.get(instance_id)
            if inst is None:
                raise KeyError(instance_id)
            self._instances[instance_id] = inst.model_copy(
                update={"ttl": ttl, "expires_at": expires_at}
            )
        return expires_at

    def pop_expired_instances(self) -> list[InstanceState]:
        now = time.time()
        expired = []
        with self._instance_lock:
            for sid in list(self._instances):
                inst = self._instances[sid]
                if inst.expires_at and now >= inst.expires_at:
                    expired.append(self._instances.pop(sid).model_copy(update={"instance_id": sid}))
        return expired

    def get_instance_by_team_challenge(
        self, team_id: str, challenge_id: str
    ) -> InstanceState | None:
        with self._instance_lock:
            for instance_id, inst in self._instances.items():
                if inst.team_id == team_id and inst.challenge_id == challenge_id:
                    return inst.model_copy(update={"instance_id": instance_id})
        return None

    # -- archived instance records (permanent, survives TTL / restart) ------

    def archive_instance(self, record: InstanceRecord) -> None:
        """Persist a completed instance record.

        ``INSERT OR REPLACE`` — terminal hooks can fire more than once for
        the same instance (e.g. reconcile_error racing a user DELETE); the
        latest write wins, which is the right outcome because the later
        call has the freshest stop_reason / error context.
        """
        with self._conn:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO instance_records
                    (instance_id, team_id, challenge_id, node_id, status,
                     started_at, stopped_at, data)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record.instance_id,
                    record.team_id,
                    record.challenge_id,
                    record.node_id,
                    record.status,
                    record.started_at,
                    record.stopped_at,
                    record.model_dump_json(),
                ),
            )

    def get_instance_record(self, instance_id: str) -> InstanceRecord | None:
        row = self._conn.execute(
            "SELECT data FROM instance_records WHERE instance_id = ?",
            (instance_id,),
        ).fetchone()
        return InstanceRecord.model_validate_json(row[0]) if row else None

    @staticmethod
    def _instance_record_where(
        *,
        team_id: str,
        challenge_id: str,
        node_id: str,
        status: str,
        since_ts: float,
    ) -> tuple[str, list]:
        clauses: list[str] = []
        params: list = []
        if team_id:
            clauses.append("team_id = ?")
            params.append(team_id)
        if challenge_id:
            clauses.append("challenge_id = ?")
            params.append(challenge_id)
        if node_id:
            clauses.append("node_id = ?")
            params.append(node_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        if since_ts > 0:
            clauses.append("started_at >= ?")
            params.append(since_ts)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        return where, params

    def list_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
        offset: int = 0,
        limit: int = 100,
    ) -> list[InstanceRecord]:
        where, params = self._instance_record_where(
            team_id=team_id,
            challenge_id=challenge_id,
            node_id=node_id,
            status=status,
            since_ts=since_ts,
        )
        sql = (
            "SELECT data FROM instance_records"
            + where
            + " ORDER BY started_at DESC LIMIT ? OFFSET ?"
        )
        rows = self._conn.execute(sql, (*params, limit, offset)).fetchall()
        return [InstanceRecord.model_validate_json(r[0]) for r in rows]

    def count_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
    ) -> int:
        where, params = self._instance_record_where(
            team_id=team_id,
            challenge_id=challenge_id,
            node_id=node_id,
            status=status,
            since_ts=since_ts,
        )
        row = self._conn.execute(
            "SELECT COUNT(*) FROM instance_records" + where,
            params,
        ).fetchone()
        return int(row[0] or 0)

    # -- config (SQLite) ----------------------------------------------------

    def get_config(self, key: str) -> str | None:
        row = self._conn.execute("SELECT value FROM config WHERE key = ?", (key,)).fetchone()
        return row[0] if row else None

    def set_config(self, key: str, value: str) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)", (key, value)
            )

    def delete_config(self, key: str) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM config WHERE key = ?", (key,))

    # -- nodes (SQLite) -----------------------------------------------------

    def put_node(self, node_id: str, data: NodeState) -> None:
        data = data.model_copy(update={"node_id": node_id})
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO nodes (node_id, data) VALUES (?, ?)",
                (node_id, data.model_dump_json()),
            )

    def get_node(self, node_id: str) -> NodeState | None:
        row = self._conn.execute("SELECT data FROM nodes WHERE node_id = ?", (node_id,)).fetchone()
        return NodeState.model_validate_json(row[0]) if row else None

    def get_node_by_token(self, token: str) -> NodeState | None:
        if not token:
            return None
        # Node counts are small (tens, not millions); a scan is fine and
        # avoids a second index we'd have to maintain for token rotation.
        import hmac as _hmac

        for row in self._conn.execute("SELECT data FROM nodes"):
            node = NodeState.model_validate_json(row[0])
            if node.token and _hmac.compare_digest(token, node.token):
                return node
        return None

    def list_nodes(self) -> list[NodeState]:
        return [
            NodeState.model_validate_json(row[0])
            for row in self._conn.execute("SELECT data FROM nodes")
        ]

    def remove_node(self, node_id: str) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM nodes WHERE node_id = ?", (node_id,))
            self._conn.execute("DELETE FROM node_health_samples WHERE node_id = ?", (node_id,))

    # -- node health history (SQLite) --------------------------------------

    def append_health_sample(self, sample: NodeHealthSample) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO node_health_samples (node_id, ts, data) VALUES (?, ?, ?)",
                (sample.node_id, sample.ts, sample.model_dump_json()),
            )
            # Bound the ring: delete rows older than the N most-recent per
            # node. Same transaction so readers never see the untrimmed state.
            self._conn.execute(
                "DELETE FROM node_health_samples "
                "WHERE node_id = ? AND ts NOT IN ("
                "  SELECT ts FROM node_health_samples "
                "  WHERE node_id = ? ORDER BY ts DESC LIMIT ?"
                ")",
                (sample.node_id, sample.node_id, HEALTH_SAMPLE_RING_SIZE),
            )

    def list_health_samples(
        self, node_id: str, limit: int = HEALTH_SAMPLE_RING_SIZE
    ) -> list[NodeHealthSample]:
        # Oldest-first so the frontend can render left-to-right.
        rows = self._conn.execute(
            "SELECT data FROM ("
            "  SELECT ts, data FROM node_health_samples "
            "  WHERE node_id = ? ORDER BY ts DESC LIMIT ?"
            ") ORDER BY ts ASC",
            (node_id, limit),
        )
        return [NodeHealthSample.model_validate_json(row[0]) for row in rows]

    # -- node invites (SQLite) ---------------------------------------------

    def put_invite(self, invite: NodeInviteState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO node_invites "
                "(invite_id, token_hash, data) VALUES (?, ?, ?)",
                (invite.invite_id, invite.token_hash, invite.model_dump_json()),
            )

    def get_invite(self, invite_id: str) -> NodeInviteState | None:
        row = self._conn.execute(
            "SELECT data FROM node_invites WHERE invite_id = ?", (invite_id,)
        ).fetchone()
        return NodeInviteState.model_validate_json(row[0]) if row else None

    def get_invite_by_hash(self, token_hash: str) -> NodeInviteState | None:
        if not token_hash:
            return None
        row = self._conn.execute(
            "SELECT data FROM node_invites WHERE token_hash = ?", (token_hash,)
        ).fetchone()
        return NodeInviteState.model_validate_json(row[0]) if row else None

    def list_invites(self) -> list[NodeInviteState]:
        return [
            NodeInviteState.model_validate_json(row[0])
            for row in self._conn.execute("SELECT data FROM node_invites")
        ]

    def consume_invite(self, token_hash: str, node_id: str) -> NodeInviteState | None:
        if not token_hash:
            return None
        # CAS: single-row UPDATE that only takes effect if the invite is
        # still active, avoiding a read-then-write race under concurrent
        # registrations.
        with self._conn:
            cur = self._conn.execute(
                "UPDATE node_invites "
                "SET data = json_set(data, '$.consumed_at_ts', ?, "
                "                    '$.consumed_by_node_id', ?) "
                "WHERE token_hash = ? "
                "  AND json_extract(data, '$.consumed_at_ts') = 0",
                (time.time(), node_id, token_hash),
            )
            if cur.rowcount == 0:
                return None
        row = self._conn.execute(
            "SELECT data FROM node_invites WHERE token_hash = ?", (token_hash,)
        ).fetchone()
        return NodeInviteState.model_validate_json(row[0]) if row else None

    def remove_invite(self, invite_id: str) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM node_invites WHERE invite_id = ?", (invite_id,))

    # -- teams (SQLite) -----------------------------------------------------

    def put_team(self, team_id: str, data: TeamState) -> None:
        # Post user/team-split: ``teams`` is a slim container row.
        # The legacy ``email`` column was dropped in migration v1.
        data = data.model_copy(update={"team_id": team_id})
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO teams (team_id, data) VALUES (?, ?)",
                (team_id, data.model_dump_json()),
            )

    def delete_team(self, team_id: str) -> bool:
        # Single transaction so the cascade is atomic. Post-split, auth
        # rows (identities, tokens) belong to USERS not teams, so this
        # only sweeps team-scoped rows. Memberships are removed (the
        # ex-members are left without a team; the route layer is
        # responsible for spinning fresh personal teams for them).
        with self._conn:
            row = self._conn.execute(
                "SELECT 1 FROM teams WHERE team_id = ?", (team_id,)
            ).fetchone()
            if row is None:
                return False
            for table in (
                "submissions",
                "solves",
                "activities",
                "scoreboard_snapshots",
                "team_achievements",
                "achievement_counters",
                "team_memberships",
                "team_invites",
            ):
                self._conn.execute(f"DELETE FROM {table} WHERE team_id = ?", (team_id,))
            self._conn.execute("DELETE FROM teams WHERE team_id = ?", (team_id,))
            return True

    def get_team(self, team_id: str) -> TeamState | None:
        row = self._conn.execute("SELECT data FROM teams WHERE team_id = ?", (team_id,)).fetchone()
        return TeamState.model_validate_json(row[0]) if row else None

    def get_team_by_token(self, token_hash: str) -> TeamState | None:
        # Post-split: token → user → first per-comp membership → team.
        # Convenience for the legacy "give me a team for this token"
        # idiom; routes that need a specific team should look up the
        # user and pick the membership themselves (per-comp routes
        # use ``get_membership_for_competition``).
        tok = self.get_token_by_hash(token_hash)
        if not tok or tok.revoked_at:
            return None
        memberships = self.list_memberships(user_id=tok.user_id)
        if not memberships:
            return None
        return self.get_team(memberships[0].team_id)

    def list_teams(self, *, competition_id: str = "") -> list[TeamState]:
        rows = [
            TeamState.model_validate_json(row[0])
            for row in self._conn.execute("SELECT data FROM teams")
        ]
        if competition_id:
            rows = [t for t in rows if t.competition_id == competition_id]
        return rows

    def count_teams(self) -> int:
        row = self._conn.execute("SELECT COUNT(*) FROM teams").fetchone()
        return int(row[0] or 0)

    # -- OAuth identities (SQLite) ------------------------------------------

    def put_identity(self, identity: OAuthIdentity) -> None:
        # SQL column was renamed ``team_id`` → ``user_id`` in
        # migration v1; pre-v1 dbs are auto-converted by ``_migrate``.
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO oauth_identities "
                "(identity_id, user_id, provider, provider_user_id, data) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    identity.identity_id,
                    identity.user_id,
                    identity.provider,
                    identity.provider_user_id,
                    identity.model_dump_json(),
                ),
            )

    def get_identity(self, identity_id: str) -> OAuthIdentity | None:
        row = self._conn.execute(
            "SELECT data FROM oauth_identities WHERE identity_id = ?",
            (identity_id,),
        ).fetchone()
        return OAuthIdentity.model_validate_json(row[0]) if row else None

    def get_identity_by_provider_uid(
        self, provider: str, provider_user_id: str
    ) -> OAuthIdentity | None:
        row = self._conn.execute(
            "SELECT data FROM oauth_identities WHERE provider = ? AND provider_user_id = ?",
            (provider, provider_user_id),
        ).fetchone()
        return OAuthIdentity.model_validate_json(row[0]) if row else None

    def list_identities_for_user(self, user_id: str) -> list[OAuthIdentity]:
        return [
            OAuthIdentity.model_validate_json(row[0])
            for row in self._conn.execute(
                "SELECT data FROM oauth_identities WHERE user_id = ? ORDER BY provider",
                (user_id,),
            )
        ]


    def remove_identity(self, identity_id: str) -> bool:
        with self._conn:
            cur = self._conn.execute(
                "DELETE FROM oauth_identities WHERE identity_id = ?",
                (identity_id,),
            )
        return cur.rowcount > 0

    # -- password identities (SQLite) --------------------------------------

    def put_password_identity(self, identity: PasswordIdentity) -> None:
        normalised = identity.model_copy(update={"email": identity.email.lower()})
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO password_identities "
                "(identity_id, user_id, email, data) VALUES (?, ?, ?, ?)",
                (
                    normalised.identity_id,
                    normalised.user_id,
                    normalised.email,
                    normalised.model_dump_json(),
                ),
            )

    def get_password_identity(self, identity_id: str) -> PasswordIdentity | None:
        row = self._conn.execute(
            "SELECT data FROM password_identities WHERE identity_id = ?",
            (identity_id,),
        ).fetchone()
        return PasswordIdentity.model_validate_json(row[0]) if row else None

    def get_password_identity_by_email(self, email: str) -> PasswordIdentity | None:
        if not email:
            return None
        row = self._conn.execute(
            "SELECT data FROM password_identities WHERE email = ? LIMIT 1",
            (email.lower(),),
        ).fetchone()
        return PasswordIdentity.model_validate_json(row[0]) if row else None

    def list_password_identities_for_user(
        self, user_id: str
    ) -> list[PasswordIdentity]:
        return [
            PasswordIdentity.model_validate_json(row[0])
            for row in self._conn.execute(
                "SELECT data FROM password_identities WHERE user_id = ?",
                (user_id,),
            )
        ]


    def remove_password_identity(self, identity_id: str) -> bool:
        with self._conn:
            cur = self._conn.execute(
                "DELETE FROM password_identities WHERE identity_id = ?",
                (identity_id,),
            )
        return cur.rowcount > 0

    # -- team tokens (SQLite) ----------------------------------------------

    def put_token(self, token: TeamToken) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO team_tokens "
                "(token_id, user_id, token_hash, kind, data) VALUES (?, ?, ?, ?, ?)",
                (
                    token.token_id,
                    token.user_id,
                    token.token_hash,
                    token.kind,
                    token.model_dump_json(),
                ),
            )

    def get_token_by_hash(self, token_hash: str) -> TeamToken | None:
        row = self._conn.execute(
            "SELECT data FROM team_tokens WHERE token_hash = ?",
            (token_hash,),
        ).fetchone()
        return TeamToken.model_validate_json(row[0]) if row else None

    def get_token(self, token_id: str) -> TeamToken | None:
        row = self._conn.execute(
            "SELECT data FROM team_tokens WHERE token_id = ?",
            (token_id,),
        ).fetchone()
        return TeamToken.model_validate_json(row[0]) if row else None

    def list_tokens_for_user(
        self,
        user_id: str,
        *,
        kind: str = "",
        include_revoked: bool = False,
    ) -> list[TeamToken]:
        sql = "SELECT data FROM team_tokens WHERE user_id = ?"
        params: list = [user_id]
        if kind:
            sql += " AND kind = ?"
            params.append(kind)
        tokens = [TeamToken.model_validate_json(row[0]) for row in self._conn.execute(sql, params)]
        if not include_revoked:
            tokens = [t for t in tokens if not t.revoked_at]
        return tokens


    def revoke_token(self, token_id: str, ts: str) -> bool:
        tok = self.get_token(token_id)
        if not tok or tok.revoked_at:
            return False
        updated = tok.model_copy(update={"revoked_at": ts})
        self.put_token(updated)
        return True

    def touch_token(self, token_id: str, ts: str) -> None:
        tok = self.get_token(token_id)
        if not tok:
            return
        updated = tok.model_copy(update={"last_used_at": ts})
        self.put_token(updated)

    # -- submissions (SQLite) -----------------------------------------------

    def add_submission(self, data: SubmissionState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT INTO submissions (submission_id, team_id, challenge_id, data) "
                "VALUES (?, ?, ?, ?)",
                (data.submission_id, data.team_id, data.challenge_id, data.model_dump_json()),
            )

    def list_submissions(
        self,
        team_id: str = "",
        challenge_id: str = "",
        *,
        user_id: str = "",
    ) -> list[SubmissionState]:
        sql = "SELECT data FROM submissions WHERE 1=1"
        params: list = []
        if team_id:
            sql += " AND team_id = ?"
            params.append(team_id)
        if challenge_id:
            sql += " AND challenge_id = ?"
            params.append(challenge_id)
        # user_id lives inside the JSON blob (no dedicated column),
        # so we filter via json_extract. Acceptable for a "my
        # submissions" listing — typical user has <100 rows.
        if user_id:
            sql += " AND json_extract(data, '$.user_id') = ?"
            params.append(user_id)
        return [
            SubmissionState.model_validate_json(row[0]) for row in self._conn.execute(sql, params)
        ]

    # -- solves (SQLite) ----------------------------------------------------

    def add_solve(
        self, team_id: str, challenge_id: str, flag_id: str, data: SolveState
    ) -> None:
        data = data.model_copy(
            update={
                "team_id": team_id,
                "challenge_id": challenge_id,
                "flag_id": flag_id,
            }
        )
        with self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO solves "
                "(team_id, challenge_id, flag_id, data) VALUES (?, ?, ?, ?)",
                (team_id, challenge_id, flag_id, data.model_dump_json()),
            )

    def get_solve(
        self, team_id: str, challenge_id: str, flag_id: str
    ) -> SolveState | None:
        row = self._conn.execute(
            "SELECT data FROM solves "
            "WHERE team_id = ? AND challenge_id = ? AND flag_id = ?",
            (team_id, challenge_id, flag_id),
        ).fetchone()
        return SolveState.model_validate_json(row[0]) if row else None

    def list_solves(
        self, team_id: str = "", *, user_id: str = ""
    ) -> list[SolveState]:
        sql = "SELECT data FROM solves WHERE 1=1"
        params: list = []
        if team_id:
            sql += " AND team_id = ?"
            params.append(team_id)
        # user_id lives inside the JSON blob (no dedicated column).
        # Filter via json_extract — same approach as list_submissions.
        if user_id:
            sql += " AND json_extract(data, '$.user_id') = ?"
            params.append(user_id)
        return [
            SolveState.model_validate_json(row[0])
            for row in self._conn.execute(sql, params)
        ]

    def count_solves_for_flag(self, challenge_id: str, flag_id: str) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM solves WHERE challenge_id = ? AND flag_id = ?",
            (challenge_id, flag_id),
        ).fetchone()
        return row[0] if row else 0

    def get_flag_solve_rank(
        self, team_id: str, challenge_id: str, flag_id: str
    ) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) + 1 FROM solves "
            "WHERE challenge_id = ? AND flag_id = ? "
            "AND json_extract(data, '$.solved_at') < ("
            "  SELECT json_extract(data, '$.solved_at') FROM solves "
            "  WHERE team_id = ? AND challenge_id = ? AND flag_id = ?"
            ")",
            (challenge_id, flag_id, team_id, challenge_id, flag_id),
        ).fetchone()
        # Subquery returns NULL if the team has no solve, making the outer
        # filter false for every row — count is 0, +1 gives 1, which would
        # be wrong. Guard with an explicit existence check.
        own = self._conn.execute(
            "SELECT 1 FROM solves WHERE team_id = ? AND challenge_id = ? AND flag_id = ?",
            (team_id, challenge_id, flag_id),
        ).fetchone()
        if own is None:
            return 0
        return row[0] if row else 0

    def count_solves_for_challenge(
        self, challenge_id: str, flag_ids: tuple[str, ...] = ()
    ) -> int:
        """Teams who have captured every declared flag on the challenge."""
        if not flag_ids:
            return 0
        placeholders = ",".join("?" * len(flag_ids))
        row = self._conn.execute(
            f"SELECT COUNT(*) FROM ("
            f"  SELECT team_id FROM solves"
            f"  WHERE challenge_id = ? AND flag_id IN ({placeholders})"
            f"  GROUP BY team_id"
            f"  HAVING COUNT(DISTINCT flag_id) = ?"
            f")",
            (challenge_id, *flag_ids, len(set(flag_ids))),
        ).fetchone()
        return row[0] if row else 0

    # -- activity log (SQLite) ----------------------------------------------

    def add_activity(self, data: ActivityState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT INTO activities "
                "(timestamp, event, team_id, challenge_id, actor_id, actor_name, actor_type, data) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    data.timestamp,
                    data.event,
                    data.team_id,
                    data.challenge_id,
                    data.actor_id,
                    data.actor_name,
                    data.actor_type,
                    data.model_dump_json(),
                ),
            )

    def _activity_where(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        since: str = "",
        until: str = "",
    ) -> tuple[str, list]:
        clauses = "WHERE 1=1"
        params: list = []
        if team_id:
            clauses += " AND team_id = ?"
            params.append(team_id)
        if challenge_id:
            clauses += " AND challenge_id = ?"
            params.append(challenge_id)
        if event:
            clauses += " AND event = ?"
            params.append(event)
        if events:
            placeholders = ",".join("?" * len(events))
            clauses += f" AND event IN ({placeholders})"
            params.extend(events)
        if actor_id:
            clauses += " AND actor_id = ?"
            params.append(actor_id)
        # Lexicographic comparison on the canonical ISO-8601 timestamp
        # column matches absolute-time ordering (every row uses the
        # same UTC-with-Z format from ``now_iso()``), so we can index
        # on the existing TEXT column without parsing.
        if since:
            clauses += " AND timestamp >= ?"
            params.append(since)
        if until:
            clauses += " AND timestamp <= ?"
            params.append(until)
        return clauses, params

    def list_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        since: str = "",
        until: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[ActivityState]:
        where, params = self._activity_where(
            team_id=team_id,
            challenge_id=challenge_id,
            event=event,
            events=events,
            actor_id=actor_id,
            since=since,
            until=until,
        )
        sql = f"SELECT data FROM activities {where} ORDER BY id DESC LIMIT ? OFFSET ?"
        params += [limit, offset]
        return [
            ActivityState.model_validate_json(row[0]) for row in self._conn.execute(sql, params)
        ]

    def count_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        since: str = "",
        until: str = "",
    ) -> int:
        where, params = self._activity_where(
            team_id=team_id,
            challenge_id=challenge_id,
            event=event,
            events=events,
            actor_id=actor_id,
            since=since,
            until=until,
        )
        sql = f"SELECT COUNT(*) FROM activities {where}"
        return self._conn.execute(sql, params).fetchone()[0]

    # -- scoreboard snapshots -----------------------------------------------

    def append_snapshot_batch(self, snapshots: list[ScoreboardSnapshotState]) -> None:
        if not snapshots:
            return
        rows = [
            (
                s.snapshot_at,
                s.snapshot_at_ts,
                s.team_id,
                s.team_name,
                s.rank,
                s.solved,
                s.attempts,
            )
            for s in snapshots
        ]
        with self._conn:
            self._conn.executemany(
                "INSERT INTO scoreboard_snapshots "
                "(snapshot_at, snapshot_at_ts, team_id, team_name, rank, solved, attempts) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                rows,
            )

    def list_snapshots(
        self,
        *,
        team_id: str = "",
        since_ts: float = 0.0,
        limit: int = 0,
    ) -> list[ScoreboardSnapshotState]:
        clauses = "WHERE snapshot_at_ts >= ?"
        params: list = [since_ts]
        if team_id:
            clauses += " AND team_id = ?"
            params.append(team_id)
        sql = (
            "SELECT snapshot_at, snapshot_at_ts, team_id, team_name, rank, solved, attempts "
            f"FROM scoreboard_snapshots {clauses} ORDER BY snapshot_at_ts ASC"
        )
        if limit > 0:
            # Fetch newest *limit* by ts-desc then flip so callers still
            # get ascending output — saves a second pass in Python.
            sql = (
                "SELECT snapshot_at, snapshot_at_ts, team_id, team_name, rank, solved, attempts "
                f"FROM scoreboard_snapshots {clauses} ORDER BY snapshot_at_ts DESC LIMIT ?"
            )
            params.append(limit)
            rows = list(self._conn.execute(sql, params))
            rows.reverse()
        else:
            rows = list(self._conn.execute(sql, params))
        return [
            ScoreboardSnapshotState(
                snapshot_at=r[0],
                snapshot_at_ts=r[1],
                team_id=r[2],
                team_name=r[3],
                rank=r[4],
                solved=r[5],
                attempts=r[6],
            )
            for r in rows
        ]

    # -- achievements --------------------------------------------------------

    def list_achievements(self, team_id: str) -> list[AchievementRecord]:
        rows = self._conn.execute(
            "SELECT team_id, achievement_id, unlocked_at, context_json "
            "FROM team_achievements WHERE team_id = ? ORDER BY unlocked_at ASC",
            (team_id,),
        ).fetchall()
        return [
            AchievementRecord(
                team_id=r[0],
                achievement_id=r[1],
                unlocked_at=r[2],
                context=json.loads(r[3] or "{}"),
            )
            for r in rows
        ]

    def has_achievement(self, team_id: str, achievement_id: str) -> bool:
        row = self._conn.execute(
            "SELECT 1 FROM team_achievements WHERE team_id = ? AND achievement_id = ?",
            (team_id, achievement_id),
        ).fetchone()
        return row is not None

    def grant_achievement(
        self,
        team_id: str,
        achievement_id: str,
        context: dict | None = None,
    ) -> AchievementRecord | None:
        # INSERT OR IGNORE gives us an atomic "grant iff absent" — rowcount
        # distinguishes a true unlock (1) from a no-op (0), so the evaluator
        # can gate event emission off a single round-trip.
        unlocked_at = datetime.now(timezone.utc).isoformat()
        ctx_json = json.dumps(context or {})
        with self._conn:
            cur = self._conn.execute(
                "INSERT OR IGNORE INTO team_achievements "
                "(team_id, achievement_id, unlocked_at, context_json) "
                "VALUES (?, ?, ?, ?)",
                (team_id, achievement_id, unlocked_at, ctx_json),
            )
            if cur.rowcount == 0:
                return None
        return AchievementRecord(
            team_id=team_id,
            achievement_id=achievement_id,
            unlocked_at=unlocked_at,
            context=context or {},
        )

    def revoke_achievement(self, team_id: str, achievement_id: str) -> bool:
        with self._conn:
            cur = self._conn.execute(
                "DELETE FROM team_achievements WHERE team_id = ? AND achievement_id = ?",
                (team_id, achievement_id),
            )
            return cur.rowcount > 0

    def count_unlocks_by_achievement(self) -> dict[str, int]:
        rows = self._conn.execute(
            "SELECT achievement_id, COUNT(*) FROM team_achievements GROUP BY achievement_id"
        ).fetchall()
        return {r[0]: int(r[1]) for r in rows}

    def list_recent_achievement_unlocks(self, limit: int = 20) -> list[AchievementRecord]:
        rows = self._conn.execute(
            "SELECT team_id, achievement_id, unlocked_at, context_json "
            "FROM team_achievements ORDER BY unlocked_at DESC LIMIT ?",
            (max(0, int(limit)),),
        ).fetchall()
        return [
            AchievementRecord(
                team_id=r[0],
                achievement_id=r[1],
                unlocked_at=r[2],
                context=json.loads(r[3] or "{}"),
            )
            for r in rows
        ]

    def bump_counter(self, team_id: str, key: str, delta: int = 1) -> int:
        updated_at = datetime.now(timezone.utc).isoformat()
        with self._conn:
            self._conn.execute(
                "INSERT INTO achievement_counters (team_id, key, value, updated_at) "
                "VALUES (?, ?, ?, ?) "
                "ON CONFLICT(team_id, key) DO UPDATE SET "
                "  value = value + excluded.value, updated_at = excluded.updated_at",
                (team_id, key, delta, updated_at),
            )
        row = self._conn.execute(
            "SELECT value FROM achievement_counters WHERE team_id = ? AND key = ?",
            (team_id, key),
        ).fetchone()
        return int(row[0]) if row else 0

    def get_counter(self, team_id: str, key: str) -> int:
        row = self._conn.execute(
            "SELECT value FROM achievement_counters WHERE team_id = ? AND key = ?",
            (team_id, key),
        ).fetchone()
        return int(row[0]) if row else 0

    def reset_counter(self, team_id: str, key: str) -> None:
        with self._conn:
            self._conn.execute(
                "DELETE FROM achievement_counters WHERE team_id = ? AND key = ?",
                (team_id, key),
            )

    # -- announcements ------------------------------------------------------

    def put_announcement(self, ann: AnnouncementState) -> None:
        with self._conn:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO announcements
                    (announcement_id, starts_at, ends_at, created_at, data)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    ann.announcement_id,
                    ann.starts_at,
                    ann.ends_at,
                    ann.created_at,
                    ann.model_dump_json(),
                ),
            )

    def get_announcement(self, announcement_id: str) -> AnnouncementState | None:
        row = self._conn.execute(
            "SELECT data FROM announcements WHERE announcement_id = ?",
            (announcement_id,),
        ).fetchone()
        return AnnouncementState.model_validate_json(row[0]) if row else None

    def list_announcements(
        self,
        *,
        active_only: bool = False,
        now_iso: str = "",
        limit: int = 100,
    ) -> list[AnnouncementState]:
        sql = "SELECT data FROM announcements"
        params: list[str] = []
        if active_only:
            # Empty starts_at / ends_at are sentinels for "no bound"; the
            # ISO 8601 string ordering matches chronological order as
            # long as everything is normalised to UTC ``Z``.
            sql += (
                " WHERE (starts_at = '' OR starts_at <= ?)"
                "   AND (ends_at = '' OR ends_at > ?)"
            )
            params.extend([now_iso, now_iso])
        sql += " ORDER BY created_at DESC"
        if limit > 0:
            sql += " LIMIT ?"
            params.append(str(limit))
        rows = self._conn.execute(sql, params).fetchall()
        return [AnnouncementState.model_validate_json(r[0]) for r in rows]

    def delete_announcement(self, announcement_id: str) -> bool:
        with self._conn:
            cur = self._conn.execute(
                "DELETE FROM announcements WHERE announcement_id = ?",
                (announcement_id,),
            )
            existed = cur.rowcount > 0
            if existed:
                # Cascade read receipts so we don't leak orphan rows.
                self._conn.execute(
                    "DELETE FROM announcement_reads WHERE announcement_id = ?",
                    (announcement_id,),
                )
            return existed

    # -- announcement read receipts -----------------------------------------

    def mark_announcement_read(
        self, user_id: str, announcement_id: str, now_iso: str
    ) -> bool:
        with self._conn:
            cur = self._conn.execute(
                """
                INSERT OR IGNORE INTO announcement_reads
                    (user_id, announcement_id, read_at)
                VALUES (?, ?, ?)
                """,
                (user_id, announcement_id, now_iso),
            )
            return cur.rowcount > 0

    def mark_announcements_read_bulk(
        self, user_id: str, announcement_ids: list[str], now_iso: str
    ) -> int:
        if not announcement_ids:
            return 0
        with self._conn:
            new_count = 0
            for ann_id in announcement_ids:
                cur = self._conn.execute(
                    """
                    INSERT OR IGNORE INTO announcement_reads
                        (user_id, announcement_id, read_at)
                    VALUES (?, ?, ?)
                    """,
                    (user_id, ann_id, now_iso),
                )
                if cur.rowcount > 0:
                    new_count += 1
            return new_count

    def list_read_announcement_ids(self, user_id: str) -> set[str]:
        rows = self._conn.execute(
            "SELECT announcement_id FROM announcement_reads WHERE user_id = ?",
            (user_id,),
        ).fetchall()
        return {r[0] for r in rows}

    # -- competitions ------------------------------------------------------

    def put_competition(self, comp: CompetitionState) -> None:
        with self._conn:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO competitions
                    (competition_id, starts_at, ends_at, created_at, data)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    comp.competition_id,
                    comp.starts_at,
                    comp.ends_at,
                    comp.created_at,
                    comp.model_dump_json(),
                ),
            )

    def get_competition(self, competition_id: str) -> CompetitionState | None:
        row = self._conn.execute(
            "SELECT data FROM competitions WHERE competition_id = ?",
            (competition_id,),
        ).fetchone()
        return CompetitionState.model_validate_json(row[0]) if row else None

    def list_competitions(
        self,
        *,
        phase: Literal["", "upcoming", "running", "past"] = "",
        now_iso: str = "",
        limit: int = 100,
    ) -> list[CompetitionState]:
        sql = "SELECT data FROM competitions"
        params: list[str] = []
        # ISO 8601 strings sort lexicographically; empty = "no bound".
        if phase == "upcoming":
            sql += " WHERE starts_at != '' AND starts_at > ?"
            params.append(now_iso)
        elif phase == "running":
            sql += (
                " WHERE (starts_at = '' OR starts_at <= ?)"
                "   AND (ends_at = '' OR ends_at > ?)"
            )
            params.extend([now_iso, now_iso])
        elif phase == "past":
            sql += " WHERE ends_at != '' AND ends_at <= ?"
            params.append(now_iso)
        sql += " ORDER BY starts_at DESC, created_at DESC"
        if limit > 0:
            sql += " LIMIT ?"
            params.append(str(limit))
        rows = self._conn.execute(sql, params).fetchall()
        return [CompetitionState.model_validate_json(r[0]) for r in rows]

    def delete_competition(self, competition_id: str) -> bool:
        # Removing the competition row only; per-comp teams are
        # cascade-deleted via the foreign relationship through
        # delete_team / leaving the team. No registrations table
        # to clean up since the per-comp refactor.
        with self._conn:
            cur = self._conn.execute(
                "DELETE FROM competitions WHERE competition_id = ?",
                (competition_id,),
            )
            return cur.rowcount > 0

    # -- users (post user/team split) ---------------------------------------

    def put_user(self, user_id: str, data: UserState) -> None:
        data = data.model_copy(update={"user_id": user_id})
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO users (user_id, email, data) VALUES (?, ?, ?)",
                (user_id, data.email.lower(), data.model_dump_json()),
            )

    def get_user(self, user_id: str) -> UserState | None:
        row = self._conn.execute(
            "SELECT data FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()
        return UserState.model_validate_json(row[0]) if row else None

    def get_user_by_email(self, email: str) -> UserState | None:
        if not email:
            return None
        row = self._conn.execute(
            "SELECT data FROM users WHERE email = ? LIMIT 1", (email.lower(),)
        ).fetchone()
        return UserState.model_validate_json(row[0]) if row else None

    def list_users(self) -> list[UserState]:
        return [
            UserState.model_validate_json(row[0])
            for row in self._conn.execute("SELECT data FROM users")
        ]

    def count_users(self) -> int:
        row = self._conn.execute("SELECT COUNT(*) FROM users").fetchone()
        return int(row[0] or 0)

    def delete_user(self, user_id: str) -> bool:
        with self._conn:
            row = self._conn.execute(
                "SELECT 1 FROM users WHERE user_id = ?", (user_id,)
            ).fetchone()
            if row is None:
                return False
            # Auth-attached rows: identities, password identities, tokens.
            # Their SQL columns are still named team_id (legacy) but
            for table in ("oauth_identities", "password_identities", "team_tokens"):
                self._conn.execute(
                    f"DELETE FROM {table} WHERE user_id = ?", (user_id,)
                )
            self._conn.execute(
                "DELETE FROM team_memberships WHERE user_id = ?", (user_id,)
            )
            self._conn.execute(
                "DELETE FROM announcement_reads WHERE user_id = ?", (user_id,)
            )
            self._conn.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
            return True

    def put_user_first_user_aware(
        self, user_id: str, user: UserState
    ) -> UserState:
        # Atomic insert: first registered user becomes super_admin.
        # ``BEGIN IMMEDIATE`` upgrades the implicit deferred transaction
        # to a write lock *before* the SELECT so a concurrent writer
        # blocks here instead of also seeing zero rows.
        user = user.model_copy(update={"user_id": user_id})
        self._conn.execute("BEGIN IMMEDIATE")
        try:
            row = self._conn.execute("SELECT 1 FROM users LIMIT 1").fetchone()
            if row is None:
                user = user.model_copy(update={"role": "super_admin"})
            self._conn.execute(
                "INSERT OR REPLACE INTO users (user_id, email, data) VALUES (?, ?, ?)",
                (user_id, user.email.lower(), user.model_dump_json()),
            )
            self._conn.commit()
        except BaseException:
            self._conn.rollback()
            raise
        return user

    # -- team membership ----------------------------------------------------

    def put_membership(self, m: TeamMembershipState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO team_memberships "
                "(user_id, team_id, joined_at, joined_via, invited_by_user_id, "
                "competition_id) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    m.user_id,
                    m.team_id,
                    m.joined_at,
                    m.joined_via,
                    m.invited_by_user_id,
                    m.competition_id,
                ),
            )

    _MEMBERSHIP_COLS = (
        "user_id, team_id, joined_at, joined_via, invited_by_user_id, "
        "competition_id"
    )

    def _row_to_membership(self, row) -> TeamMembershipState:
        return TeamMembershipState(
            user_id=row[0],
            team_id=row[1],
            joined_at=row[2],
            joined_via=row[3] or "",
            invited_by_user_id=row[4] or "",
            competition_id=row[5] or "",
        )

    def get_membership(self, user_id: str) -> TeamMembershipState | None:
        """Convenience helper used by tests and a couple of legacy
        call sites that just want "any membership for this user". Per-
        comp routes use ``get_membership_for_competition`` directly.
        Returns ``None`` when the user isn't on any team.
        """
        rows = self.list_memberships(user_id=user_id)
        return rows[0] if rows else None

    def get_membership_for_competition(
        self, user_id: str, competition_id: str
    ) -> TeamMembershipState | None:
        row = self._conn.execute(
            f"SELECT {self._MEMBERSHIP_COLS} "
            "FROM team_memberships "
            "WHERE user_id = ? AND competition_id = ?",
            (user_id, competition_id),
        ).fetchone()
        return self._row_to_membership(row) if row else None

    def list_memberships(
        self,
        *,
        team_id: str = "",
        user_id: str = "",
        competition_id: str = "",
    ) -> list[TeamMembershipState]:
        sql = f"SELECT {self._MEMBERSHIP_COLS} FROM team_memberships"
        clauses: list[str] = []
        params: list = []
        if team_id:
            clauses.append("team_id = ?")
            params.append(team_id)
        if user_id:
            clauses.append("user_id = ?")
            params.append(user_id)
        if competition_id:
            clauses.append("competition_id = ?")
            params.append(competition_id)
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY joined_at"
        return [self._row_to_membership(r) for r in self._conn.execute(sql, params)]

    def count_memberships(self, team_id: str) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM team_memberships WHERE team_id = ?", (team_id,)
        ).fetchone()
        return int(row[0]) if row else 0

    def delete_membership(self, user_id: str) -> bool:
        with self._conn:
            cur = self._conn.execute(
                "DELETE FROM team_memberships WHERE user_id = ?", (user_id,)
            )
            return cur.rowcount > 0

    def remove_from_competition_team(
        self, user_id: str, competition_id: str
    ) -> str:
        """Atomic per-comp leave/kick — see ``InMemoryBackend`` for
        the full contract. Wrapped in ``BEGIN IMMEDIATE`` so the
        membership lookup → team cleanup sequence is serialized."""
        with self._conn:
            self._conn.execute("BEGIN IMMEDIATE")
            row = self._conn.execute(
                "SELECT team_id FROM team_memberships "
                "WHERE user_id = ? AND competition_id = ?",
                (user_id, competition_id),
            ).fetchone()
            if row is None:
                return "not_member"
            team_id = row[0]
            others = self._conn.execute(
                "SELECT user_id, joined_at FROM team_memberships "
                "WHERE team_id = ? AND user_id != ? "
                "ORDER BY joined_at",
                (team_id, user_id),
            ).fetchall()
            # Drop the user's membership.
            self._conn.execute(
                "DELETE FROM team_memberships "
                "WHERE user_id = ? AND competition_id = ?",
                (user_id, competition_id),
            )
            if not others:
                # Lone member — cascade delete the team's rows.
                for table in (
                    "team_memberships",
                    "team_invites",
                ):
                    self._conn.execute(
                        f"DELETE FROM {table} WHERE team_id = ?", (team_id,)
                    )
                self._conn.execute(
                    "DELETE FROM teams WHERE team_id = ?", (team_id,)
                )
                return "ok"
            # Multi-member team: if the leaving user was captain,
            # transfer captaincy to the longest-tenured other.
            team_row = self._conn.execute(
                "SELECT data FROM teams WHERE team_id = ?", (team_id,)
            ).fetchone()
            if team_row is None:
                return "ok"
            team_state = TeamState.model_validate_json(team_row[0])
            if team_state.captain_user_id == user_id:
                new_captain_id = others[0][0]
                updated = team_state.model_copy(
                    update={"captain_user_id": new_captain_id}
                )
                self._conn.execute(
                    "INSERT OR REPLACE INTO teams (team_id, data) "
                    "VALUES (?, ?)",
                    (team_id, updated.model_dump_json()),
                )
            return "ok"

    def create_team_for_competition(
        self,
        user_id: str,
        competition_id: str,
        *,
        team_name: str,
        description: str = "",
        now_iso: str,
        joined_via: str = "solo",
    ) -> TeamState:
        """Atomic: insert a fresh team scoped to ``competition_id`` and
        join ``user_id`` to it as captain. Idempotent on
        ``(user_id, competition_id)`` — if the user already has a
        membership for this competition, returns the existing team
        without modifying state. See :class:`InMemoryBackend` for the
        full contract.
        """
        # Wrap in BEGIN IMMEDIATE so the read-then-write check is
        # serialized — without it two concurrent callers can both pass
        # the membership-lookup, and both INSERT teams.
        with self._conn:
            self._conn.execute("BEGIN IMMEDIATE")
            existing_row = self._conn.execute(
                f"SELECT {self._MEMBERSHIP_COLS} "
                "FROM team_memberships "
                "WHERE user_id = ? AND competition_id = ?",
                (user_id, competition_id),
            ).fetchone()
            if existing_row is not None:
                existing_team_id = existing_row[1]
                team_row = self._conn.execute(
                    "SELECT data FROM teams WHERE team_id = ?",
                    (existing_team_id,),
                ).fetchone()
                if team_row is not None:
                    return TeamState.model_validate_json(team_row[0])
            team_id = str(uuid.uuid4())
            team = TeamState(
                team_id=team_id,
                name=team_name,
                description=description,
                captain_user_id=user_id,
                created_at=now_iso,
                competition_id=competition_id,
            )
            self._conn.execute(
                "INSERT INTO teams (team_id, data) VALUES (?, ?)",
                (team_id, team.model_dump_json()),
            )
            self._conn.execute(
                "INSERT INTO team_memberships "
                "(user_id, team_id, joined_at, joined_via, "
                " invited_by_user_id, competition_id) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    user_id,
                    team_id,
                    now_iso,
                    joined_via,
                    "",
                    competition_id,
                ),
            )
            return team

    def move_user_to_team(
        self,
        user_id: str,
        new_membership: TeamMembershipState,
        *,
        new_team: TeamState | None = None,
        old_team_id: str = "",
        delete_old_team: bool = False,
        transfer_old_captain_to: str = "",
    ) -> None:
        """Atomic membership move — see ``InMemoryBackend`` for the
        full contract. SQLite implementation runs the entire sequence
        (optional put new team → INSERT OR REPLACE membership →
        cleanup old team) in a single transaction so concurrent
        readers never observe the user in a no-team state.
        """
        with self._conn:
            # 1. Land the new team (only if caller is creating one).
            if new_team is not None:
                self._conn.execute(
                    "INSERT OR REPLACE INTO teams (team_id, data) VALUES (?, ?)",
                    (new_team.team_id, new_team.model_dump_json()),
                )
            # 2. Atomic membership swap. ``user_id`` is PK, so
            #    INSERT OR REPLACE rewrites the row in-place — no
            #    intermediate state where the row is missing.
            self._conn.execute(
                "INSERT OR REPLACE INTO team_memberships "
                "(user_id, team_id, joined_at, joined_via, invited_by_user_id, "
                "competition_id) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    new_membership.user_id,
                    new_membership.team_id,
                    new_membership.joined_at,
                    new_membership.joined_via,
                    new_membership.invited_by_user_id,
                    new_membership.competition_id,
                ),
            )
            # 3. Old-team cleanup (same transaction).
            if delete_old_team and old_team_id:
                # Mirror the cascade ``delete_team`` does for the
                # team-scoped tables.
                for table in (
                    "submissions",
                    "solves",
                    "activities",
                    "scoreboard_snapshots",
                    "team_achievements",
                    "achievement_counters",
                    "team_memberships",
                    "team_invites",
                ):
                    self._conn.execute(
                        f"DELETE FROM {table} WHERE team_id = ?", (old_team_id,)
                    )
                self._conn.execute(
                    "DELETE FROM teams WHERE team_id = ?", (old_team_id,)
                )
            elif transfer_old_captain_to and old_team_id:
                row = self._conn.execute(
                    "SELECT data FROM teams WHERE team_id = ?", (old_team_id,)
                ).fetchone()
                if row is not None:
                    old_state = TeamState.model_validate_json(row[0])
                    updated = old_state.model_copy(
                        update={"captain_user_id": transfer_old_captain_to}
                    )
                    self._conn.execute(
                        "INSERT OR REPLACE INTO teams (team_id, data) "
                        "VALUES (?, ?)",
                        (old_team_id, updated.model_dump_json()),
                    )

    # -- team invites -------------------------------------------------------

    def put_team_invite(self, inv: TeamInviteState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO team_invites "
                "(invite_id, team_id, code, created_by_user_id, created_at, "
                " expires_at, max_uses, use_count, revoked_at, competition_id, "
                " kind, target_user_id) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    inv.invite_id,
                    inv.team_id,
                    inv.code,
                    inv.created_by_user_id,
                    inv.created_at,
                    inv.expires_at,
                    inv.max_uses,
                    inv.use_count,
                    inv.revoked_at,
                    inv.competition_id,
                    inv.kind,
                    inv.target_user_id,
                ),
            )

    _INVITE_COLS = (
        "invite_id, team_id, code, created_by_user_id, created_at, "
        "expires_at, max_uses, use_count, revoked_at, competition_id, "
        "kind, target_user_id"
    )

    def _row_to_invite(self, row) -> TeamInviteState:
        return TeamInviteState(
            invite_id=row[0],
            team_id=row[1],
            code=row[2],
            created_by_user_id=row[3],
            created_at=row[4],
            expires_at=row[5],
            max_uses=int(row[6]),
            use_count=int(row[7]),
            revoked_at=row[8],
            competition_id=row[9] or "",
            kind=row[10] or "code",
            target_user_id=row[11] or "",
        )

    def get_team_invite(self, invite_id: str) -> TeamInviteState | None:
        row = self._conn.execute(
            f"SELECT {self._INVITE_COLS} "
            "FROM team_invites WHERE invite_id = ?",
            (invite_id,),
        ).fetchone()
        return self._row_to_invite(row) if row else None

    def get_team_invite_by_code(self, code: str) -> TeamInviteState | None:
        row = self._conn.execute(
            f"SELECT {self._INVITE_COLS} "
            "FROM team_invites WHERE code = ?",
            (code,),
        ).fetchone()
        return self._row_to_invite(row) if row else None

    def list_team_invites(
        self, *, team_id: str = ""
    ) -> list[TeamInviteState]:
        sql = f"SELECT {self._INVITE_COLS} FROM team_invites"
        params: list = []
        if team_id:
            sql += " WHERE team_id = ?"
            params.append(team_id)
        sql += " ORDER BY created_at DESC"
        return [self._row_to_invite(r) for r in self._conn.execute(sql, params)]

    def revoke_team_invite(self, invite_id: str, ts: str) -> bool:
        with self._conn:
            cur = self._conn.execute(
                "UPDATE team_invites SET revoked_at = ? "
                "WHERE invite_id = ? AND revoked_at = ''",
                (ts, invite_id),
            )
            return cur.rowcount > 0

    def consume_team_invite_atomic(
        self, code: str, now_iso: str
    ) -> TeamInviteState | None:
        # Single-statement update keyed on the code + window/use guards
        # makes the consume race-free under concurrent redeem attempts.
        # Empty ``expires_at`` and ``max_uses == 0`` are passed through
        # the WHERE so the predicate stays a single roundtrip.
        with self._conn:
            cur = self._conn.execute(
                "UPDATE team_invites SET use_count = use_count + 1 "
                "WHERE code = ? "
                "  AND revoked_at = '' "
                "  AND (expires_at = '' OR expires_at > ?) "
                "  AND (max_uses = 0 OR use_count < max_uses)",
                (code, now_iso),
            )
            if cur.rowcount == 0:
                return None
        return self.get_team_invite_by_code(code)

    def redeem_team_invite_for_competition(
        self,
        code: str,
        user_id: str,
        competition_id: str,
        now_iso: str,
        *,
        joined_via: str = "redeem",
        invited_by_user_id: str = "",
    ) -> tuple[TeamState | None, str]:
        """Atomic per-comp invite redemption — see ``InMemoryBackend``
        for the contract. Wrapped in ``BEGIN IMMEDIATE`` so concurrent
        redeemers see a serialized "is the code still consumable +
        is this user still un-joined" check.
        """
        with self._conn:
            self._conn.execute("BEGIN IMMEDIATE")
            inv_row = self._conn.execute(
                f"SELECT {self._INVITE_COLS} "
                "FROM team_invites WHERE code = ?",
                (code,),
            ).fetchone()
            if inv_row is None:
                return (None, "unknown_code")
            inv = self._row_to_invite(inv_row)
            if inv.competition_id != competition_id:
                return (None, "wrong_competition")
            existing = self._conn.execute(
                "SELECT 1 FROM team_memberships "
                "WHERE user_id = ? AND competition_id = ?",
                (user_id, competition_id),
            ).fetchone()
            if existing is not None:
                return (None, "already_member")
            if inv.revoked_at:
                return (None, "expired_or_revoked")
            if inv.expires_at and inv.expires_at <= now_iso:
                return (None, "expired_or_revoked")
            if inv.max_uses and inv.use_count >= inv.max_uses:
                return (None, "expired_or_revoked")
            team_row = self._conn.execute(
                "SELECT data FROM teams WHERE team_id = ?", (inv.team_id,)
            ).fetchone()
            if team_row is None:
                return (None, "team_deleted")
            target_team = TeamState.model_validate_json(team_row[0])
            # Commit: increment use_count + write membership.
            self._conn.execute(
                "UPDATE team_invites SET use_count = use_count + 1 "
                "WHERE invite_id = ?",
                (inv.invite_id,),
            )
            self._conn.execute(
                "INSERT INTO team_memberships "
                "(user_id, team_id, joined_at, joined_via, "
                " invited_by_user_id, competition_id) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    user_id,
                    target_team.team_id,
                    now_iso,
                    joined_via,
                    invited_by_user_id or inv.created_by_user_id,
                    competition_id,
                ),
            )
            return (target_team, "ok")
