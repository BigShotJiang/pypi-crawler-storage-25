"""InMemoryBackend — thread-safe in-memory state backend."""

from __future__ import annotations

import threading
import time
import uuid
from datetime import datetime, timezone

from typing import Literal

from ctfy.core.announcements import is_active as _ann_is_active
from ctfy.core.competitions import matches_phase as _comp_matches_phase
from ctfy.core.enums import InstanceStatus
from ctfy.core.state.filters import match_activity, match_submission
from ctfy.core.state.models import (
    AchievementRecord,
    ActivityState,
    AnnouncementReadState,
    AnnouncementState,
    CompetitionState,
    InstanceRecord,
    InstanceState,
    NodeHealthSample,
    NodeInviteState,
    NodeState,
    OAuthIdentity,
    PasswordIdentity,
    ScoreboardSnapshotState,
    SolveState,
    SubmissionState,
    TeamInviteState,
    TeamMembershipState,
    TeamState,
    TeamToken,
    UserState,
)

# Upper bound on samples kept per node. Matches the SQLite backend so
# both implementations behave identically and the frontend's strip
# length is stable. Bumping → widen both.
HEALTH_SAMPLE_RING_SIZE = 200


class InMemoryBackend:
    """Thread-safe in-memory backend. Suitable for single-process use."""

    def __init__(self) -> None:
        self._instances: dict[str, InstanceState] = {}
        self._nodes: dict[str, NodeState] = {}
        self._invites: dict[str, NodeInviteState] = {}
        # Bounded deque per node — O(1) append + head-trim.
        self._health_samples: dict[str, list[NodeHealthSample]] = {}
        self._teams: dict[str, TeamState] = {}
        self._identities: dict[str, OAuthIdentity] = {}
        self._password_identities: dict[str, PasswordIdentity] = {}
        self._tokens: dict[str, TeamToken] = {}
        self._submissions: list[SubmissionState] = []
        self._solves: dict[tuple[str, str, str], SolveState] = {}
        self._activities: list[ActivityState] = []
        self._instance_records: dict[str, InstanceRecord] = {}
        self._snapshots: list[ScoreboardSnapshotState] = []
        self._config: dict[str, str] = {}
        # Achievements: (team_id, achievement_id) -> record.
        self._achievements: dict[tuple[str, str], AchievementRecord] = {}
        # Cheap running counters for rule predicates (e.g. wrong-streaks).
        self._counters: dict[tuple[str, str], int] = {}
        self._announcements: dict[str, AnnouncementState] = {}
        # (user_id, announcement_id) -> read receipt
        self._announcement_reads: dict[tuple[str, str], AnnouncementReadState] = {}
        # Competitions and per-team registrations. Registrations are keyed
        # by (competition_id, team_id) for O(1) idempotent insert + lookup.
        self._competitions: dict[str, CompetitionState] = {}
        # Post user/team-split: users are the auth principal, teams are
        # containers. ``_memberships`` maps (user_id, competition_id) →
        # membership row. Phase 2a switched the key to a tuple so a user
        # can hold N memberships, one per competition. Legacy
        # ``competition_id == ""`` slot is the user's "default"
        # membership for backward compat with ``get_membership(user_id)``.
        self._users: dict[str, UserState] = {}
        self._memberships: dict[tuple[str, str], TeamMembershipState] = {}
        # ``_team_invites`` to disambiguate from the older
        # ``_invites`` dict for node-registration invites above.
        self._team_invites: dict[str, TeamInviteState] = {}
        self._lock = threading.Lock()

    # -- instance -----------------------------------------------------------

    def put_instance(self, instance_id: str, data: InstanceState, ttl: int = 0) -> None:
        now = time.time()
        status = data.status
        if status == InstanceStatus.READY:
            started_at = now
            expires_at = (now + ttl) if ttl > 0 else 0.0
        elif status == InstanceStatus.STARTING:
            started_at = 0.0
            expires_at = 0.0
        else:
            started_at = data.started_at
            expires_at = data.expires_at
        data = data.model_copy(
            update={"started_at": started_at, "ttl": ttl, "expires_at": expires_at}
        )
        with self._lock:
            self._instances[instance_id] = data

    def get_instance(self, instance_id: str) -> InstanceState | None:
        with self._lock:
            inst = self._instances.get(instance_id)
            return inst.model_copy() if inst is not None else None

    def remove_instance(self, instance_id: str) -> InstanceState | None:
        with self._lock:
            return self._instances.pop(instance_id, None)

    def list_instances(self) -> list[InstanceState]:
        with self._lock:
            return [v.model_copy(update={"instance_id": k}) for k, v in self._instances.items()]

    def count_instances(self) -> int:
        with self._lock:
            return len(self._instances)

    def renew_instance(self, instance_id: str, ttl: int) -> float:
        now = time.time()
        expires_at = (now + ttl) if ttl > 0 else 0.0
        with self._lock:
            inst = self._instances.get(instance_id)
            if inst is None:
                raise KeyError(instance_id)
            self._instances[instance_id] = inst.model_copy(
                update={"ttl": ttl, "expires_at": expires_at}
            )
        return expires_at

    def pop_expired_instances(self) -> list[InstanceState]:
        now = time.time()
        expired = []
        with self._lock:
            for sid in list(self._instances):
                inst = self._instances[sid]
                if inst.expires_at and now >= inst.expires_at:
                    expired.append(self._instances.pop(sid).model_copy(update={"instance_id": sid}))
        return expired

    def get_instance_by_team_challenge(
        self, team_id: str, challenge_id: str
    ) -> InstanceState | None:
        with self._lock:
            for instance_id, inst in self._instances.items():
                if inst.team_id == team_id and inst.challenge_id == challenge_id:
                    return inst.model_copy(update={"instance_id": instance_id})
        return None

    # -- archived instance records ------------------------------------------

    def archive_instance(self, record: InstanceRecord) -> None:
        with self._lock:
            # INSERT OR REPLACE semantics — mirror the SQLite backend.
            self._instance_records[record.instance_id] = record.model_copy()

    def get_instance_record(self, instance_id: str) -> InstanceRecord | None:
        with self._lock:
            rec = self._instance_records.get(instance_id)
            return rec.model_copy() if rec is not None else None

    def _filter_records(
        self,
        *,
        team_id: str,
        challenge_id: str,
        node_id: str,
        status: str,
        since_ts: float,
    ) -> list[InstanceRecord]:
        rows = sorted(
            self._instance_records.values(),
            key=lambda r: r.started_at,
            reverse=True,
        )
        return [
            r
            for r in rows
            if (not team_id or r.team_id == team_id)
            and (not challenge_id or r.challenge_id == challenge_id)
            and (not node_id or r.node_id == node_id)
            and (not status or r.status == status)
            and (since_ts <= 0 or r.started_at >= since_ts)
        ]

    def list_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
        offset: int = 0,
        limit: int = 100,
    ) -> list[InstanceRecord]:
        with self._lock:
            filtered = self._filter_records(
                team_id=team_id,
                challenge_id=challenge_id,
                node_id=node_id,
                status=status,
                since_ts=since_ts,
            )
            return [r.model_copy() for r in filtered[offset : offset + limit]]

    def count_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
    ) -> int:
        with self._lock:
            return len(
                self._filter_records(
                    team_id=team_id,
                    challenge_id=challenge_id,
                    node_id=node_id,
                    status=status,
                    since_ts=since_ts,
                )
            )

    # -- config --------------------------------------------------------------

    def get_config(self, key: str) -> str | None:
        with self._lock:
            return self._config.get(key)

    def set_config(self, key: str, value: str) -> None:
        with self._lock:
            self._config[key] = value

    def delete_config(self, key: str) -> None:
        with self._lock:
            self._config.pop(key, None)

    # -- nodes ---------------------------------------------------------------

    def put_node(self, node_id: str, data: NodeState) -> None:
        with self._lock:
            self._nodes[node_id] = data.model_copy(update={"node_id": node_id})

    def get_node(self, node_id: str) -> NodeState | None:
        with self._lock:
            node = self._nodes.get(node_id)
            return node.model_copy() if node is not None else None

    def get_node_by_token(self, token: str) -> NodeState | None:
        if not token:
            return None
        import hmac as _hmac

        with self._lock:
            for node in self._nodes.values():
                if node.token and _hmac.compare_digest(token, node.token):
                    return node.model_copy()
            return None

    def list_nodes(self) -> list[NodeState]:
        with self._lock:
            return [v.model_copy() for v in self._nodes.values()]

    def remove_node(self, node_id: str) -> None:
        with self._lock:
            self._nodes.pop(node_id, None)
            self._health_samples.pop(node_id, None)

    # -- node health history ------------------------------------------------

    def append_health_sample(self, sample: NodeHealthSample) -> None:
        with self._lock:
            ring = self._health_samples.setdefault(sample.node_id, [])
            ring.append(sample.model_copy())
            if len(ring) > HEALTH_SAMPLE_RING_SIZE:
                # Drop the oldest entries in bulk so we don't repeatedly
                # slice on every append in steady state.
                del ring[: len(ring) - HEALTH_SAMPLE_RING_SIZE]

    def list_health_samples(
        self, node_id: str, limit: int = HEALTH_SAMPLE_RING_SIZE
    ) -> list[NodeHealthSample]:
        with self._lock:
            ring = self._health_samples.get(node_id, [])
            # Return a copy so callers can't mutate our ring.
            return [s.model_copy() for s in ring[-limit:]]

    # -- node invites --------------------------------------------------------

    def put_invite(self, invite: NodeInviteState) -> None:
        with self._lock:
            self._invites[invite.invite_id] = invite.model_copy()

    def get_invite(self, invite_id: str) -> NodeInviteState | None:
        with self._lock:
            inv = self._invites.get(invite_id)
            return inv.model_copy() if inv is not None else None

    def get_invite_by_hash(self, token_hash: str) -> NodeInviteState | None:
        if not token_hash:
            return None
        with self._lock:
            for inv in self._invites.values():
                if inv.token_hash == token_hash:
                    return inv.model_copy()
            return None

    def list_invites(self) -> list[NodeInviteState]:
        with self._lock:
            return [inv.model_copy() for inv in self._invites.values()]

    def consume_invite(self, token_hash: str, node_id: str) -> NodeInviteState | None:
        if not token_hash:
            return None
        with self._lock:
            for invite_id, inv in self._invites.items():
                if inv.token_hash != token_hash:
                    continue
                if inv.consumed_at_ts > 0:
                    return None
                updated = inv.model_copy(
                    update={
                        "consumed_at_ts": time.time(),
                        "consumed_by_node_id": node_id,
                    }
                )
                self._invites[invite_id] = updated
                return updated.model_copy()
            return None

    def remove_invite(self, invite_id: str) -> None:
        with self._lock:
            self._invites.pop(invite_id, None)

    # -- teams ---------------------------------------------------------------

    def put_team(self, team_id: str, data: TeamState) -> None:
        with self._lock:
            data = data.model_copy(update={"team_id": team_id})
            self._teams[team_id] = data

    def delete_team(self, team_id: str) -> bool:
        # Single critical section so the cascade is atomic w.r.t. any
        # concurrent reader — they either see the full team or nothing
        # at all, never a half-deleted state. Post user/team-split,
        # auth-attached rows (identities, tokens) belong to USERS, not
        # teams; deleting a team only sweeps team-scoped rows.
        with self._lock:
            if team_id not in self._teams:
                return False
            del self._teams[team_id]
            self._submissions = [s for s in self._submissions if s.team_id != team_id]
            self._solves = {k: v for k, v in self._solves.items() if k[0] != team_id}
            self._activities = [a for a in self._activities if a.team_id != team_id]
            self._snapshots = [s for s in self._snapshots if s.team_id != team_id]
            self._achievements = {
                k: v for k, v in self._achievements.items() if k[0] != team_id
            }
            self._counters = {k: v for k, v in self._counters.items() if k[0] != team_id}
            self._memberships = {
                k: v for k, v in self._memberships.items() if v.team_id != team_id
            }
            self._team_invites = {
                k: v for k, v in self._team_invites.items() if v.team_id != team_id
            }
            return True

    def get_team(self, team_id: str) -> TeamState | None:
        with self._lock:
            team = self._teams.get(team_id)
            return team.model_copy() if team is not None else None

    def get_team_by_token(self, token_hash: str) -> TeamState | None:
        # Convenience: token → user → first per-comp membership → team.
        # Routes that need a specific team look up the user and pick
        # the right membership themselves (per-comp routes use
        # ``get_membership_for_competition``); this helper is for tests
        # and a couple of legacy call sites that just want "any team
        # the calling token belongs to".
        with self._lock:
            tok = self._tokens.get(self._token_id_for_hash_locked(token_hash) or "")
            if not tok or tok.revoked_at:
                return None
            for (user_id, _comp_id), membership in self._memberships.items():
                if user_id != tok.user_id:
                    continue
                team = self._teams.get(membership.team_id)
                if team is not None:
                    return team.model_copy()
            return None

    def list_teams(self, *, competition_id: str = "") -> list[TeamState]:
        with self._lock:
            rows = list(self._teams.values())
        if competition_id:
            rows = [t for t in rows if t.competition_id == competition_id]
        return [r.model_copy() for r in rows]

    def count_teams(self) -> int:
        with self._lock:
            return len(self._teams)

    # -- users (post user/team split) ---------------------------------------

    def put_user(self, user_id: str, data: UserState) -> None:
        with self._lock:
            data = data.model_copy(update={"user_id": user_id})
            self._users[user_id] = data

    def get_user(self, user_id: str) -> UserState | None:
        with self._lock:
            u = self._users.get(user_id)
            return u.model_copy() if u is not None else None

    def get_user_by_email(self, email: str) -> UserState | None:
        if not email:
            return None
        target = email.lower()
        with self._lock:
            for u in self._users.values():
                if u.email.lower() == target:
                    return u.model_copy()
        return None

    def list_users(self) -> list[UserState]:
        with self._lock:
            return [v.model_copy() for v in self._users.values()]

    def count_users(self) -> int:
        with self._lock:
            return len(self._users)

    def delete_user(self, user_id: str) -> bool:
        with self._lock:
            if user_id not in self._users:
                return False
            del self._users[user_id]
            self._identities = {
                k: v for k, v in self._identities.items() if v.user_id != user_id
            }
            self._password_identities = {
                k: v
                for k, v in self._password_identities.items()
                if v.user_id != user_id
            }
            self._tokens = {
                k: v for k, v in self._tokens.items() if v.user_id != user_id
            }
            # Drop every membership the user holds across all comps.
            self._memberships = {
                k: v for k, v in self._memberships.items()
                if v.user_id != user_id
            }
            # Drop the user's announcement read receipts — the rows no
            # longer correspond to a real principal.
            self._announcement_reads = {
                k: v
                for k, v in self._announcement_reads.items()
                if v.user_id != user_id
            }
            return True

    def put_user_first_user_aware(
        self, user_id: str, user: UserState
    ) -> UserState:
        user = user.model_copy(update={"user_id": user_id})
        with self._lock:
            if not self._users:
                user = user.model_copy(update={"role": "super_admin"})
            self._users[user_id] = user
            return user.model_copy()

    # -- team membership ----------------------------------------------------

    def put_membership(self, m: TeamMembershipState) -> None:
        with self._lock:
            self._memberships[(m.user_id, m.competition_id)] = m.model_copy()

    def get_membership(self, user_id: str) -> TeamMembershipState | None:
        """Convenience helper used by tests and a couple of legacy
        call sites that just want "any membership for this user". Per-
        comp routes use ``get_membership_for_competition`` directly.
        Returns ``None`` when the user isn't on any team.
        """
        rows = self.list_memberships(user_id=user_id)
        return rows[0] if rows else None

    def get_membership_for_competition(
        self, user_id: str, competition_id: str
    ) -> TeamMembershipState | None:
        with self._lock:
            row = self._memberships.get((user_id, competition_id))
            return row.model_copy() if row is not None else None

    def list_memberships(
        self,
        *,
        team_id: str = "",
        user_id: str = "",
        competition_id: str = "",
    ) -> list[TeamMembershipState]:
        with self._lock:
            rows = list(self._memberships.values())
        if team_id:
            rows = [r for r in rows if r.team_id == team_id]
        if user_id:
            rows = [r for r in rows if r.user_id == user_id]
        if competition_id:
            rows = [r for r in rows if r.competition_id == competition_id]
        rows.sort(key=lambda r: r.joined_at)
        return [r.model_copy() for r in rows]

    def count_memberships(self, team_id: str) -> int:
        with self._lock:
            return sum(1 for m in self._memberships.values() if m.team_id == team_id)

    def delete_membership(self, user_id: str) -> bool:
        """Drop every membership held by ``user_id`` across all
        competitions. Phase 3 will add a per-comp granular variant.
        """
        with self._lock:
            keys = [k for k in self._memberships if k[0] == user_id]
            for k in keys:
                self._memberships.pop(k, None)
            return bool(keys)

    def remove_from_competition_team(
        self, user_id: str, competition_id: str
    ) -> str:
        """Atomically drop ``user_id``'s membership for this comp +
        clean up the old team:

        * lone member → team is deleted (and its invites cascade out).
        * captain leaving with others remaining → captaincy transfers
          to the longest-tenured remaining member; team stays.
        * non-captain member → just remove the membership row.

        Returns ``"ok"`` on success or ``"not_member"`` if the user
        had no team for this comp.
        """
        with self._lock:
            m = self._memberships.get((user_id, competition_id))
            if m is None:
                return "not_member"
            team = self._teams.get(m.team_id)
            others = [
                row
                for row in self._memberships.values()
                if row.team_id == m.team_id and row.user_id != user_id
            ]
            self._memberships.pop((user_id, competition_id), None)
            if not others:
                # Lone member — drop the team + its invites.
                self._teams.pop(m.team_id, None)
                self._team_invites = {
                    k: v for k, v in self._team_invites.items()
                    if v.team_id != m.team_id
                }
            elif team is not None and team.captain_user_id == user_id:
                others.sort(key=lambda r: r.joined_at)
                self._teams[m.team_id] = team.model_copy(
                    update={"captain_user_id": others[0].user_id}
                )
            return "ok"

    def create_team_for_competition(
        self,
        user_id: str,
        competition_id: str,
        *,
        team_name: str,
        description: str = "",
        now_iso: str,
        joined_via: str = "solo",
    ) -> TeamState:
        """Atomic: insert a fresh team scoped to ``competition_id`` and
        join ``user_id`` to it as captain. Idempotent on
        ``(user_id, competition_id)`` — if the user already has a
        membership for this competition, returns the existing team
        without modifying state.

        ``joined_via`` audits *how* the user landed on this team
        (``"solo"`` for one-click registration, ``"create"`` for the
        named multi-user flow). The team_id is server-minted.
        """
        with self._lock:
            existing = self._memberships.get((user_id, competition_id))
            if existing is not None:
                team = self._teams.get(existing.team_id)
                if team is not None:
                    return team.model_copy()
            team_id = str(uuid.uuid4())
            team = TeamState(
                team_id=team_id,
                name=team_name,
                description=description,
                captain_user_id=user_id,
                created_at=now_iso,
                competition_id=competition_id,
            )
            self._teams[team_id] = team.model_copy()
            self._memberships[(user_id, competition_id)] = TeamMembershipState(
                user_id=user_id,
                team_id=team_id,
                joined_at=now_iso,
                joined_via=joined_via,
                competition_id=competition_id,
            )
            return team.model_copy()

    def move_user_to_team(
        self,
        user_id: str,
        new_membership: TeamMembershipState,
        *,
        new_team: TeamState | None = None,
        old_team_id: str = "",
        delete_old_team: bool = False,
        transfer_old_captain_to: str = "",
    ) -> None:
        """Atomically move ``user_id`` onto the team identified by
        ``new_membership.team_id``.

        Outside observers never see the user without a membership row
        and never see the old team in an inconsistent state — the
        whole sequence (optional put new team → INSERT OR REPLACE
        membership → cleanup old team) runs under a single lock.

        ``new_team`` is the destination team's full state. Pass it when
        the destination is brand-new (leave / create-team / kick — the
        caller mints a fresh personal team); leave it ``None`` when
        the destination already exists (invite redeem).

        Old-team disposition (caller picks one off pre-swap state):

        * ``delete_old_team=True`` — user was the lone member; drop
          the old team row + cascade its invites + activities (same
          tables ``delete_team`` would).
        * ``transfer_old_captain_to=<user_id>`` — user was captain
          and others remain; rewrite the old team's
          ``captain_user_id`` field.
        * neither — user was a non-captain member; old team
          unchanged.
        """
        with self._lock:
            # 1. Land the new team (only if caller is creating one).
            if new_team is not None:
                self._teams[new_team.team_id] = new_team.model_copy()
            # 2. Atomic membership swap — dict assignment is the GIL-
            #    atomic step that closes the no-team window.
            self._memberships[(user_id, new_membership.competition_id)] = (
                new_membership.model_copy()
            )
            # 3. Old-team cleanup.
            if delete_old_team and old_team_id:
                self._teams.pop(old_team_id, None)
                self._team_invites = {
                    k: v for k, v in self._team_invites.items()
                    if v.team_id != old_team_id
                }
            elif transfer_old_captain_to and old_team_id:
                old = self._teams.get(old_team_id)
                if old is not None:
                    self._teams[old_team_id] = old.model_copy(
                        update={"captain_user_id": transfer_old_captain_to}
                    )

    # -- team invites -------------------------------------------------------

    def put_team_invite(self, inv: TeamInviteState) -> None:
        with self._lock:
            self._team_invites[inv.invite_id] = inv.model_copy()

    def get_team_invite(self, invite_id: str) -> TeamInviteState | None:
        with self._lock:
            inv = self._team_invites.get(invite_id)
            return inv.model_copy() if inv is not None else None

    def get_team_invite_by_code(self, code: str) -> TeamInviteState | None:
        with self._lock:
            for inv in self._team_invites.values():
                if inv.code == code:
                    return inv.model_copy()
        return None

    def list_team_invites(
        self, *, team_id: str = ""
    ) -> list[TeamInviteState]:
        with self._lock:
            rows = list(self._team_invites.values())
        if team_id:
            rows = [r for r in rows if r.team_id == team_id]
        rows.sort(key=lambda r: r.created_at, reverse=True)
        return [r.model_copy() for r in rows]

    def revoke_team_invite(self, invite_id: str, ts: str) -> bool:
        with self._lock:
            inv = self._team_invites.get(invite_id)
            if inv is None or inv.revoked_at:
                return False
            self._team_invites[invite_id] = inv.model_copy(update={"revoked_at": ts})
            return True

    def consume_team_invite_atomic(
        self, code: str, now_iso: str
    ) -> TeamInviteState | None:
        with self._lock:
            target_id: str | None = None
            for inv in self._team_invites.values():
                if inv.code == code:
                    target_id = inv.invite_id
                    break
            if target_id is None:
                return None
            inv = self._team_invites[target_id]
            if inv.revoked_at:
                return None
            if inv.expires_at and inv.expires_at <= now_iso:
                return None
            if inv.max_uses and inv.use_count >= inv.max_uses:
                return None
            updated = inv.model_copy(update={"use_count": inv.use_count + 1})
            self._team_invites[target_id] = updated
            return updated.model_copy()

    def redeem_team_invite_for_competition(
        self,
        code: str,
        user_id: str,
        competition_id: str,
        now_iso: str,
        *,
        joined_via: str = "redeem",
        invited_by_user_id: str = "",
    ) -> tuple[TeamState | None, str]:
        """Atomically redeem an invite + join its team for the given
        competition. The whole sequence (invite lookup → comp check →
        already-member check → use_count increment → membership
        write) runs under one lock so concurrent redeemers see a
        consistent view of "is this code still consumable" and
        "is this user already on a team for this comp".

        Returns a ``(team, status)`` tuple. ``status`` is one of:

        * ``"ok"`` — joined; team is the captain's target team.
        * ``"unknown_code"`` — no invite with this code.
        * ``"wrong_competition"`` — code is for a different comp;
          use_count is NOT incremented (the invite stays valid).
        * ``"already_member"`` — user already has a team for this
          comp; use_count NOT incremented.
        * ``"expired_or_revoked"`` — code is past its window /
          revoked / exhausted (max_uses reached).
        * ``"team_deleted"`` — the invite's target team is gone.

        ``joined_via`` is stamped on the new membership row for audit.
        ``invited_by_user_id`` overrides the default of
        ``inv.created_by_user_id`` — needed for ``join_request``
        invites where the invite's creator is the requester
        themselves and the actual *inviter* (the captain who
        approved) is a separate user.
        """
        with self._lock:
            target_invite_id: str | None = None
            for inv in self._team_invites.values():
                if inv.code == code:
                    target_invite_id = inv.invite_id
                    break
            if target_invite_id is None:
                return (None, "unknown_code")
            inv = self._team_invites[target_invite_id]
            if inv.competition_id != competition_id:
                return (None, "wrong_competition")
            # Already-member check before consuming so a wrong attempt
            # doesn't burn a use.
            if (user_id, competition_id) in self._memberships:
                return (None, "already_member")
            if inv.revoked_at:
                return (None, "expired_or_revoked")
            if inv.expires_at and inv.expires_at <= now_iso:
                return (None, "expired_or_revoked")
            if inv.max_uses and inv.use_count >= inv.max_uses:
                return (None, "expired_or_revoked")
            target_team = self._teams.get(inv.team_id)
            if target_team is None:
                return (None, "team_deleted")
            # Commit: increment use_count + write membership.
            consumed = inv.model_copy(
                update={"use_count": inv.use_count + 1}
            )
            self._team_invites[target_invite_id] = consumed
            self._memberships[(user_id, competition_id)] = TeamMembershipState(
                user_id=user_id,
                team_id=target_team.team_id,
                joined_at=now_iso,
                joined_via=joined_via,
                invited_by_user_id=(
                    invited_by_user_id or consumed.created_by_user_id
                ),
                competition_id=competition_id,
            )
            return (target_team.model_copy(), "ok")

    # -- OAuth identities ---------------------------------------------------

    def put_identity(self, identity: OAuthIdentity) -> None:
        with self._lock:
            self._identities[identity.identity_id] = identity.model_copy()

    def get_identity(self, identity_id: str) -> OAuthIdentity | None:
        with self._lock:
            ident = self._identities.get(identity_id)
            return ident.model_copy() if ident is not None else None

    def get_identity_by_provider_uid(
        self, provider: str, provider_user_id: str
    ) -> OAuthIdentity | None:
        with self._lock:
            for ident in self._identities.values():
                if ident.provider == provider and ident.provider_user_id == provider_user_id:
                    return ident.model_copy()
        return None

    def list_identities_for_user(self, user_id: str) -> list[OAuthIdentity]:
        with self._lock:
            return [
                ident.model_copy()
                for ident in self._identities.values()
                if ident.user_id == user_id
            ]

    # Backward-compat alias used by older callers; identical semantics
    # since user_id equals the legacy team_id post-split migration.

    def remove_identity(self, identity_id: str) -> bool:
        with self._lock:
            return self._identities.pop(identity_id, None) is not None

    # -- password identities ------------------------------------------------

    def put_password_identity(self, identity: PasswordIdentity) -> None:
        with self._lock:
            # Normalise email on write so the sqlite ``COLLATE NOCASE``
            # semantics are mirrored here without per-read lowercasing.
            normalised = identity.model_copy(update={"email": identity.email.lower()})
            self._password_identities[identity.identity_id] = normalised

    def get_password_identity(self, identity_id: str) -> PasswordIdentity | None:
        with self._lock:
            ident = self._password_identities.get(identity_id)
            return ident.model_copy() if ident is not None else None

    def get_password_identity_by_email(self, email: str) -> PasswordIdentity | None:
        if not email:
            return None
        target = email.lower()
        with self._lock:
            for ident in self._password_identities.values():
                if ident.email == target:
                    return ident.model_copy()
        return None

    def list_password_identities_for_user(
        self, user_id: str
    ) -> list[PasswordIdentity]:
        with self._lock:
            return [
                ident.model_copy()
                for ident in self._password_identities.values()
                if ident.user_id == user_id
            ]


    def remove_password_identity(self, identity_id: str) -> bool:
        with self._lock:
            return self._password_identities.pop(identity_id, None) is not None

    # -- team tokens --------------------------------------------------------

    def _token_id_for_hash_locked(self, token_hash: str) -> str | None:
        for tok in self._tokens.values():
            if tok.token_hash == token_hash:
                return tok.token_id
        return None

    def put_token(self, token: TeamToken) -> None:
        with self._lock:
            self._tokens[token.token_id] = token.model_copy()

    def get_token_by_hash(self, token_hash: str) -> TeamToken | None:
        with self._lock:
            tid = self._token_id_for_hash_locked(token_hash)
            if not tid:
                return None
            return self._tokens[tid].model_copy()

    def get_token(self, token_id: str) -> TeamToken | None:
        with self._lock:
            tok = self._tokens.get(token_id)
            return tok.model_copy() if tok is not None else None

    def list_tokens_for_user(
        self,
        user_id: str,
        *,
        kind: str = "",
        include_revoked: bool = False,
    ) -> list[TeamToken]:
        with self._lock:
            result = []
            for tok in self._tokens.values():
                if tok.user_id != user_id:
                    continue
                if kind and tok.kind != kind:
                    continue
                if not include_revoked and tok.revoked_at:
                    continue
                result.append(tok.model_copy())
            return result


    def revoke_token(self, token_id: str, ts: str) -> bool:
        with self._lock:
            tok = self._tokens.get(token_id)
            if not tok or tok.revoked_at:
                return False
            self._tokens[token_id] = tok.model_copy(update={"revoked_at": ts})
            return True

    def touch_token(self, token_id: str, ts: str) -> None:
        with self._lock:
            tok = self._tokens.get(token_id)
            if not tok:
                return
            self._tokens[token_id] = tok.model_copy(update={"last_used_at": ts})

    # -- submissions ---------------------------------------------------------

    def add_submission(self, data: SubmissionState) -> None:
        with self._lock:
            self._submissions.append(data)

    def list_submissions(
        self,
        team_id: str = "",
        challenge_id: str = "",
        *,
        user_id: str = "",
    ) -> list[SubmissionState]:
        with self._lock:
            rows = list(self._submissions)
        out: list[SubmissionState] = []
        for s in rows:
            if not match_submission(s, team_id=team_id, challenge_id=challenge_id):
                continue
            if user_id and s.user_id != user_id:
                continue
            out.append(s.model_copy())
        return out

    # -- solves --------------------------------------------------------------

    def add_solve(
        self, team_id: str, challenge_id: str, flag_id: str, data: SolveState
    ) -> None:
        key = (team_id, challenge_id, flag_id)
        with self._lock:
            if key not in self._solves:
                self._solves[key] = data.model_copy(
                    update={
                        "team_id": team_id,
                        "challenge_id": challenge_id,
                        "flag_id": flag_id,
                    }
                )

    def get_solve(
        self, team_id: str, challenge_id: str, flag_id: str
    ) -> SolveState | None:
        with self._lock:
            solve = self._solves.get((team_id, challenge_id, flag_id))
            return solve.model_copy() if solve is not None else None

    def list_solves(
        self, team_id: str = "", *, user_id: str = ""
    ) -> list[SolveState]:
        with self._lock:
            rows = list(self._solves.items())
        out: list[SolveState] = []
        for k, v in rows:
            if team_id and k[0] != team_id:
                continue
            if user_id and v.user_id != user_id:
                continue
            out.append(v.model_copy())
        return out

    def count_solves_for_flag(self, challenge_id: str, flag_id: str) -> int:
        with self._lock:
            return sum(
                1 for k in self._solves if k[1] == challenge_id and k[2] == flag_id
            )

    def get_flag_solve_rank(
        self, team_id: str, challenge_id: str, flag_id: str
    ) -> int:
        with self._lock:
            mine = self._solves.get((team_id, challenge_id, flag_id))
            if mine is None:
                return 0
            earlier = sum(
                1
                for (tid, cid, fid), s in self._solves.items()
                if cid == challenge_id and fid == flag_id and s.solved_at < mine.solved_at
            )
            return earlier + 1

    def count_solves_for_challenge(
        self, challenge_id: str, flag_ids: tuple[str, ...] = ()
    ) -> int:
        """Teams who have captured *every* declared flag on the challenge.

        ``flag_ids`` is the challenge's full flag id set. If empty the count
        is zero (caller didn't pass the challenge spec, so "fully solved"
        is undefined). Single-flag challenges pass ``("main",)`` and this
        matches the old single-flag semantics.
        """
        if not flag_ids:
            return 0
        required = set(flag_ids)
        with self._lock:
            by_team: dict[str, set[str]] = {}
            for (team_id, cid, fid) in self._solves:
                if cid != challenge_id:
                    continue
                by_team.setdefault(team_id, set()).add(fid)
        return sum(1 for solved in by_team.values() if required <= solved)

    # -- activity log -------------------------------------------------------

    def add_activity(self, data: ActivityState) -> None:
        with self._lock:
            self._activities.append(data)

    def _filter_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        since: str = "",
        until: str = "",
    ) -> list[ActivityState]:
        return [
            a
            for a in reversed(self._activities)
            if match_activity(
                a,
                team_id=team_id,
                challenge_id=challenge_id,
                event=event,
                events=events,
                actor_id=actor_id,
                since=since,
                until=until,
            )
        ]

    def list_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        since: str = "",
        until: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[ActivityState]:
        with self._lock:
            filtered = self._filter_activities(
                team_id=team_id,
                challenge_id=challenge_id,
                event=event,
                events=events,
                actor_id=actor_id,
                since=since,
                until=until,
            )
            return filtered[offset : offset + limit]

    def count_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        since: str = "",
        until: str = "",
    ) -> int:
        with self._lock:
            return len(
                self._filter_activities(
                    team_id=team_id,
                    challenge_id=challenge_id,
                    event=event,
                    events=events,
                    actor_id=actor_id,
                    since=since,
                    until=until,
                )
            )

    # -- scoreboard snapshots -----------------------------------------------

    def append_snapshot_batch(self, snapshots: list[ScoreboardSnapshotState]) -> None:
        if not snapshots:
            return
        with self._lock:
            self._snapshots.extend(snapshots)

    def list_snapshots(
        self,
        *,
        team_id: str = "",
        since_ts: float = 0.0,
        limit: int = 0,
    ) -> list[ScoreboardSnapshotState]:
        with self._lock:
            # Ascending by timestamp so charts can render left-to-right.
            rows = sorted(self._snapshots, key=lambda s: s.snapshot_at_ts)
        filtered = [
            s
            for s in rows
            if (not team_id or s.team_id == team_id) and s.snapshot_at_ts >= since_ts
        ]
        if limit > 0:
            return filtered[-limit:]
        return filtered

    # -- achievements --------------------------------------------------------

    def list_achievements(self, team_id: str) -> list[AchievementRecord]:
        with self._lock:
            return [r.model_copy() for (tid, _), r in self._achievements.items() if tid == team_id]

    def has_achievement(self, team_id: str, achievement_id: str) -> bool:
        with self._lock:
            return (team_id, achievement_id) in self._achievements

    def grant_achievement(
        self,
        team_id: str,
        achievement_id: str,
        context: dict | None = None,
    ) -> AchievementRecord | None:
        key = (team_id, achievement_id)
        with self._lock:
            if key in self._achievements:
                return None
            record = AchievementRecord(
                team_id=team_id,
                achievement_id=achievement_id,
                unlocked_at=datetime.now(timezone.utc).isoformat(),
                context=dict(context or {}),
            )
            self._achievements[key] = record
            return record.model_copy()

    def revoke_achievement(self, team_id: str, achievement_id: str) -> bool:
        with self._lock:
            return self._achievements.pop((team_id, achievement_id), None) is not None

    def count_unlocks_by_achievement(self) -> dict[str, int]:
        out: dict[str, int] = {}
        with self._lock:
            for (_team_id, ach_id) in self._achievements.keys():
                out[ach_id] = out.get(ach_id, 0) + 1
        return out

    def list_recent_achievement_unlocks(self, limit: int = 20) -> list[AchievementRecord]:
        with self._lock:
            rows = sorted(
                self._achievements.values(),
                key=lambda r: r.unlocked_at,
                reverse=True,
            )[: max(0, limit)]
            return [r.model_copy() for r in rows]

    def bump_counter(self, team_id: str, key: str, delta: int = 1) -> int:
        with self._lock:
            new_value = self._counters.get((team_id, key), 0) + delta
            self._counters[(team_id, key)] = new_value
            return new_value

    def get_counter(self, team_id: str, key: str) -> int:
        with self._lock:
            return self._counters.get((team_id, key), 0)

    def reset_counter(self, team_id: str, key: str) -> None:
        with self._lock:
            self._counters.pop((team_id, key), None)

    # -- announcements ------------------------------------------------------

    def put_announcement(self, ann: AnnouncementState) -> None:
        with self._lock:
            self._announcements[ann.announcement_id] = ann.model_copy()

    def get_announcement(self, announcement_id: str) -> AnnouncementState | None:
        with self._lock:
            row = self._announcements.get(announcement_id)
            return row.model_copy() if row is not None else None

    def list_announcements(
        self,
        *,
        active_only: bool = False,
        now_iso: str = "",
        limit: int = 100,
    ) -> list[AnnouncementState]:
        with self._lock:
            rows = [v.model_copy() for v in self._announcements.values()]
        if active_only:
            rows = [r for r in rows if _ann_is_active(r, now_iso)]
        rows.sort(key=lambda r: r.created_at, reverse=True)
        return rows[: max(0, limit)] if limit > 0 else rows

    def delete_announcement(self, announcement_id: str) -> bool:
        with self._lock:
            existed = self._announcements.pop(announcement_id, None) is not None
            if existed:
                # Cascade read receipts so we don't leak orphan rows.
                self._announcement_reads = {
                    k: v
                    for k, v in self._announcement_reads.items()
                    if v.announcement_id != announcement_id
                }
            return existed

    # -- announcement read receipts -----------------------------------------

    def mark_announcement_read(
        self, user_id: str, announcement_id: str, now_iso: str
    ) -> bool:
        key = (user_id, announcement_id)
        with self._lock:
            if key in self._announcement_reads:
                return False
            self._announcement_reads[key] = AnnouncementReadState(
                user_id=user_id,
                announcement_id=announcement_id,
                read_at=now_iso,
            )
            return True

    def mark_announcements_read_bulk(
        self, user_id: str, announcement_ids: list[str], now_iso: str
    ) -> int:
        new_count = 0
        with self._lock:
            for ann_id in announcement_ids:
                key = (user_id, ann_id)
                if key in self._announcement_reads:
                    continue
                self._announcement_reads[key] = AnnouncementReadState(
                    user_id=user_id,
                    announcement_id=ann_id,
                    read_at=now_iso,
                )
                new_count += 1
        return new_count

    def list_read_announcement_ids(self, user_id: str) -> set[str]:
        with self._lock:
            return {
                k[1] for k in self._announcement_reads.keys() if k[0] == user_id
            }

    # -- competitions ------------------------------------------------------

    def put_competition(self, comp: CompetitionState) -> None:
        with self._lock:
            self._competitions[comp.competition_id] = comp.model_copy()

    def get_competition(self, competition_id: str) -> CompetitionState | None:
        with self._lock:
            row = self._competitions.get(competition_id)
            return row.model_copy() if row is not None else None

    def list_competitions(
        self,
        *,
        phase: Literal["", "upcoming", "running", "past"] = "",
        now_iso: str = "",
        limit: int = 100,
    ) -> list[CompetitionState]:
        with self._lock:
            rows = [v.model_copy() for v in self._competitions.values()]
        if phase:
            rows = [r for r in rows if _comp_matches_phase(r, phase, now_iso)]
        # Newest first by start time so the list view shows just-launched
        # competitions at the top; ties (or rows with empty starts_at)
        # fall back to ``created_at``.
        rows.sort(key=lambda r: (r.starts_at, r.created_at), reverse=True)
        return rows[: max(0, limit)] if limit > 0 else rows

    def delete_competition(self, competition_id: str) -> bool:
        with self._lock:
            if competition_id not in self._competitions:
                return False
            del self._competitions[competition_id]
            return True
