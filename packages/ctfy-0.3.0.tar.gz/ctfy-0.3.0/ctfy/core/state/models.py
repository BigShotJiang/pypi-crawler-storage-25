"""Typed state models — replace raw dicts in state backends."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field, computed_field, field_validator

from ctfy.core.activity import ActivityDetail
from ctfy.core.enums import InstanceStatus
from ctfy.core.models import CtfyModel
from ctfy.core.target import AttackSurface

# Who triggered an activity event. "team" / "node" cover authenticated
# caller identities; "admin" covers admin-privileged user writes;
# "system" covers background loops (reaper / reconciler / health check).
ActorType = Literal["team", "node", "admin", "system"]

# Bearer token flavours issued to a team:
#   - "user":  minted on OAuth login. Allowed to manage identities and
#     tokens (linking/unlinking providers, minting/revoking agent tokens).
#   - "agent": minted by a logged-in user for their own agents / CI. Can
#     participate (submit flags, run instances) but cannot edit auth state.
TokenKind = Literal["user", "agent"]

# OAuth providers wired into the platform.
OAuthProviderName = Literal["github", "google"]

# Team privilege role. ``super_admin`` is the env-anchored top tier (set
# from ``CTFY_SUPER_ADMIN_EMAILS`` on OAuth callback) and is the only
# role allowed to grant/revoke ``admin``. ``admin`` is the regular
# admin tier — same privileges as before, but now grantable through the
# UI by a super-admin. Defaults to ``user`` for everyone else.
TeamRole = Literal["user", "admin", "super_admin"]


class UserState(CtfyModel):
    """A registered human (or AI) on the platform.

    The auth + profile + role layer that used to live on ``TeamState``.
    Identity bindings (OAuth, password) and bearer tokens point here.
    A user is always a member of exactly one ``TeamState`` at a time —
    on first registration we mint a personal team and join them to it,
    so the "register and you're a team" UX of the old single-user model
    keeps working.
    """

    user_id: str
    email: str = ""
    display_name: str = ""
    avatar_url: str = ""
    created_at: str = ""

    # Privilege tier. ``super_admin`` is recomputed from
    # ``CTFY_SUPER_ADMIN_EMAILS`` on every OAuth callback (only when the
    # user has at least one OAuth identity — password rows don't count
    # as verified email). ``admin`` is granted by a super-admin via the
    # admin UI on a per-user basis.
    role: TeamRole = "user"
    promoted_by: str | None = None
    promoted_at: str | None = None

    # Profile fields — user-editable via PATCH /me/profile.
    bio: str | None = Field(default=None, max_length=280)
    country: str | None = None
    website_url: str | None = Field(default=None, max_length=200)
    timezone: str | None = Field(default=None, max_length=80)
    social_links: dict[str, str] = Field(default_factory=dict)
    profile_visibility: dict[str, bool] = Field(default_factory=dict)

    @field_validator("country")
    @classmethod
    def _validate_country(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if len(v) != 2 or not v.isascii() or not v.isalpha() or not v.isupper():
            raise ValueError("country must be a two-letter uppercase ISO code")
        return v

    @field_validator("social_links")
    @classmethod
    def _validate_social_links(cls, v: dict[str, str]) -> dict[str, str]:
        if len(v) > 8:
            raise ValueError("social_links may contain at most 8 entries")
        for value in v.values():
            if len(value) > 200:
                raise ValueError("each social_links value must be at most 200 characters")
        return v

    @computed_field  # type: ignore[prop-decorator]
    @property
    def is_admin(self) -> bool:
        return self.role in ("admin", "super_admin")

    @computed_field  # type: ignore[prop-decorator]
    @property
    def is_super_admin(self) -> bool:
        return self.role == "super_admin"


class TeamState(CtfyModel):
    """A team — a container that one or more users belong to.

    Post user/team-split this is no longer an identity row. It carries
    only team-scoped fields. Auth, profile, and role live on
    :class:`UserState`; the user → team mapping lives on
    :class:`TeamMembershipState`. The captain is the only member who
    can mint invites, kick others, rename the team, or delete it.

    ``competition_id`` scopes the team to one competition. Empty in
    Phase 1 (legacy / pre-per-comp shape); subsequent phases require
    non-empty so every team belongs to exactly one competition.
    """

    team_id: str
    name: str = ""
    description: str = ""
    created_at: str = ""
    captain_user_id: str = ""
    competition_id: str = ""


class TeamMembershipState(CtfyModel):
    """``user_id → team_id`` mapping.

    Phase 1 of the per-competition refactor: ``competition_id`` is an
    optional column. In Phase 1 the storage layer still treats
    ``user_id`` as the primary key (one team at a time). Subsequent
    phases promote the PK to ``(user_id, competition_id)`` so a user
    can be on team A in comp1 and team B in comp2 simultaneously.
    """

    user_id: str = ""
    team_id: str = ""
    joined_at: str = ""
    competition_id: str = ""
    # How the user landed on this team. Audit trail for "did they
    # self-join, redeem an invite, or get placed by an admin".
    # ``""`` means legacy / migrated row (no provenance recorded).
    # ``"register"``: minted with the user's personal team on signup.
    # ``"redeem"``: redeemed an invite code.
    # ``"create"``: created this team themselves (POST /me/team).
    # ``"leave"``: dropped into a fresh personal team after leaving.
    # ``"kick"``: placed into a fresh personal team after a captain
    # removed them from the previous one.
    joined_via: Literal[
        "",
        "register",
        "redeem",
        "create",
        "leave",
        "kick",
        "solo",
        "direct_invite_accepted",
        "join_request_approved",
    ] = ""
    # Captain who placed the user when ``joined_via == "kick"``;
    # otherwise empty. Surfaces in the activity log for audit.
    invited_by_user_id: str = ""


class TeamInviteState(CtfyModel):
    """A captain-issued join code or directed invite/request.

    ``code`` is the short opaque string handed to humans (typically 8
    base32 chars) for ``kind="code"`` invites. Lookups are by-code;
    the invite_id is just an internal handle for revocation.
    ``max_uses == 0`` means unlimited; ``expires_at == ""`` means
    never expires; ``revoked_at != ""`` rejects all subsequent consume
    attempts.

    ``kind`` discriminates three flavours over the same row shape:

    * ``"code"`` (default, legacy) — captain mints a short code,
      anyone with it can redeem.
    * ``"direct"`` — captain invites a specific user (looked up by
      exact email); only ``target_user_id`` can accept.
    * ``"join_request"`` — a non-captain asks to join a specific
      team; only that team's captain can approve.
    """

    invite_id: str = ""
    team_id: str = ""
    code: str = ""
    created_by_user_id: str = ""
    created_at: str = ""
    expires_at: str = ""
    max_uses: int = 1
    use_count: int = 0
    revoked_at: str = ""
    competition_id: str = ""
    kind: Literal["code", "direct", "join_request"] = "code"
    # Recipient for ``kind="direct"`` (the user being invited) and
    # implicitly for ``kind="join_request"`` once approved (the
    # requester is in ``created_by_user_id``). Empty for code-style
    # invites — those have no fixed recipient until redemption.
    target_user_id: str = ""


class OAuthIdentity(CtfyModel):
    """One bound (provider, provider_user_id) → user link.

    A user can have multiple identities (a human can sign in through
    GitHub and Google interchangeably). ``(provider, provider_user_id)``
    is globally unique — the same GitHub account cannot belong to two
    users. Email-based auto-merge happens at login time only for verified
    emails; see :mod:`ctfy.server.routes.auth`.
    """

    identity_id: str = ""
    user_id: str = ""
    provider: OAuthProviderName = "github"
    provider_user_id: str = ""
    provider_email: str = ""
    provider_display_name: str = ""
    # Provider-side login handle — the GitHub username, for instance.
    # Only GitHub populates it; Google has no equivalent. We need it
    # for the public-API star-verification flow because GitHub's
    # ``/users/{username}/starred`` endpoint takes the login, not the
    # numeric id stored in ``provider_user_id``. Old rows carry ``""``
    # and are backfilled lazily on next sign-in or via a one-shot
    # ``GET /user/{id}`` lookup at verification time.
    provider_login: str = ""
    avatar_url: str = ""
    created_at: str = ""
    last_used_at: str = ""


class PasswordIdentity(CtfyModel):
    """Email+password credential bound to a team.

    Sibling to :class:`OAuthIdentity` — one team has at most one row here.
    ``email`` is the external handle (unique across the table, case-
    insensitive). ``password_hash`` is an Argon2id PHC string; see
    :mod:`ctfy.server.password`. Registration does not verify the email,
    so password-only identities never match ``CTFY_SUPER_ADMIN_EMAILS``
    (see ``_apply_super_admin_status`` in :mod:`ctfy.server.routes.auth`).
    """

    identity_id: str = ""
    user_id: str = ""
    email: str = ""  # canonical lower-cased
    password_hash: str = ""
    display_name: str = ""
    created_at: str = ""
    last_used_at: str = ""


AnnouncementSeverity = Literal["info", "warning", "critical"]


class AnnouncementState(CtfyModel):
    """Site-wide announcement, visible to all visitors.

    Time-windowed: empty ``starts_at`` means "live immediately", empty
    ``ends_at`` means "no expiry". The ``active_only`` filter on
    :meth:`StateBackend.list_announcements` evaluates the window against
    a caller-supplied ``now`` so the comparison stays in the SQL layer.

    ``created_by_name`` is denormalized at write time so the public list
    view doesn't need to join on the team that posted it (and survives
    the team being later renamed or deleted).
    """

    announcement_id: str = ""
    title: str = ""
    body: str = ""  # Markdown
    severity: AnnouncementSeverity = "info"
    # ISO 8601. Empty = live immediately / never expires.
    starts_at: str = ""
    ends_at: str = ""
    created_at: str = ""
    updated_at: str = ""
    # team_id of the admin who created the announcement.
    created_by: str = ""
    created_by_name: str = ""


class AnnouncementReadState(CtfyModel):
    """Per-user read receipt for a single announcement.

    Tracks which users have acknowledged which announcements so the
    Inbox can render an "unread" badge. Idempotent on
    ``(user_id, announcement_id)`` — re-marking a row keeps the
    earliest ``read_at`` to preserve the audit trail.
    """

    user_id: str = ""
    announcement_id: str = ""
    read_at: str = ""  # ISO 8601


class CompetitionState(CtfyModel):
    """An admin-curated CTF competition with a fixed challenge subset
    and a time window.

    Read-only filtering layer on top of the global submissions/solves
    pipeline: registering doesn't reroute writes, it just opts the team
    into a separate leaderboard that re-aggregates over (registered
    teams) × (curated challenges) × (post-registration time window).

    Time fields use the same convention as :class:`AnnouncementState` —
    empty ``starts_at`` means "live immediately", empty ``ends_at``
    means "never ends" (used for permanent practice-style competitions
    if anyone ever wants one). ``challenge_ids`` is validated against
    the spec registry at write time on the admin route.
    """

    competition_id: str = ""
    title: str = ""
    description: str = ""  # Markdown
    starts_at: str = ""
    ends_at: str = ""
    challenge_ids: list[str] = Field(default_factory=list, max_length=200)
    created_at: str = ""
    updated_at: str = ""
    # team_id of the admin who created the competition.
    created_by: str = ""
    created_by_name: str = ""


class TeamToken(CtfyModel):
    """One bearer token issued to a user.

    Tokens are stored as SHA-256 hashes. The plaintext is only returned
    to the caller once — at creation time — and never persisted. Multiple
    tokens per user are supported so a single user can mint separate
    tokens per agent / CI pipeline and revoke them independently.

    The class name is preserved for backward compatibility with SDK
    consumers; conceptually post user/team-split this is a "user token".
    """

    token_id: str = ""
    user_id: str = ""
    token_hash: str = ""
    kind: TokenKind = "user"
    label: str = ""
    created_at: str = ""
    last_used_at: str = ""
    # ISO timestamp of revocation. Empty while the token is active;
    # revoked tokens are never purged so audit logs can resolve them.
    revoked_at: str = ""
    # ISO timestamp at which the token stops authenticating. Empty means
    # the token never expires. Agent tokens default to 30 days; user
    # (browser-session) tokens default to 90 days.
    expires_at: str = ""
    # Client metadata captured at mint time — used by the "Active sessions"
    # UI so a user can recognise their own devices and revoke anything
    # unfamiliar. Populated for user-kind tokens; agent tokens are minted
    # from an already-authenticated session so these stay empty.
    ip_address: str = ""
    user_agent: str = ""


class SolveState(CtfyModel):
    team_id: str = ""
    # Post user/team-split: the human who actually submitted the flag.
    # Stamped at solve time; survives the user later moving teams. Empty
    # for legacy rows pre-split — backfilled to ``team_id`` by the
    # SQLiteBackend migration since at that point team_id was the user.
    user_id: str = ""
    challenge_id: str = ""
    # Which flag on the challenge was solved. For challenges with a single
    # flag this is ``"main"``. Composite uniqueness on
    # (team_id, challenge_id, flag_id).
    flag_id: str = ""
    solved_at: str = ""
    solve_time_s: float = 0.0
    attempts: int = 0


class ActivityState(CtfyModel):
    id: str = ""
    timestamp: str = ""
    event: str = ""
    team_id: str = ""
    team_name: str = ""
    challenge_id: str = ""
    # Post user/team-split: the human who triggered the event. May be
    # empty for system-actor events (reaper, reconciler).
    user_id: str = ""
    # Who triggered this event — non-optional since every emit site has to
    # supply actor context. Auditors + admin filter on actor_id.
    actor_id: str
    actor_name: str
    actor_type: ActorType
    detail: ActivityDetail = Field(default_factory=ActivityDetail)


class NodeState(CtfyModel):
    node_id: str = ""
    url: str = ""
    # Human-readable label used in admin UI. Operators set it on register
    # or via PATCH — existing nodes get a one-time backfill to node_id in
    # the sqlite migration path.
    display_name: str = ""
    capacity: int = 0
    running: int = 0
    healthy: bool = True
    last_heartbeat: str = ""
    last_heartbeat_ts: float = 0.0
    # ISO-8601 UTC timestamp of the first successful POST /nodes that
    # created this row. Distinct from ``last_heartbeat`` (which advances
    # every beat). Empty for rows persisted before the field was
    # introduced; read paths fall back to ``last_heartbeat`` for those.
    registered_at: str = ""
    labels: dict[str, str] = Field(default_factory=dict)
    # Resource utilisation, 0–100. Updated on every heartbeat; the node
    # samples via psutil before posting. "Disk" is the filesystem that
    # holds the node's data dir.
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_percent: float = 0.0
    # Per-node bearer token, plaintext. Used both ways:
    #  * node→platform (heartbeat, deregister) — node sets it as Bearer,
    #    platform looks the row up by comparing plaintexts.
    #  * platform→node (start/stop/status) — platform presents this plaintext
    #    on every outbound call, node verifies against its in-memory copy.
    # Minted fresh on every register; rotation = re-register. The column
    # is never returned by ``GET /nodes`` or any other read path.
    #
    # Security note (audit #5): unlike user/agent tokens (which are SHA-256
    # hashed at rest), node tokens MUST be retrievable in plaintext for the
    # platform→node outbound path. A pure-hash store would force a redesign
    # in which the platform holds a separate cluster-level credential per
    # node (or signs each outbound RPC). This is tracked but out of scope
    # for the audit fix; the mitigation is to restrict file-system access
    # to the state backend (sqlite db file mode 0600, chown to the service
    # user) and to delete (revoke) the row promptly via DELETE /nodes/{id}.
    token: str = ""


class NodeHealthSample(CtfyModel):
    """One heartbeat-tick worth of node health + utilisation.

    The state backend keeps a bounded ring of the most recent samples per
    node so the admin UI can render uptime-kuma-style strips without
    storing unbounded time series. Appended on every heartbeat and
    whenever the health-check loop marks a node unhealthy; no separate
    reaper needed.
    """

    node_id: str = ""
    ts: float = 0.0  # Unix seconds, platform's wall clock when the sample landed
    healthy: bool = True
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_percent: float = 0.0
    # Server-measured one-way latency from when the node sampled metrics
    # to when the heartbeat landed. 0 means "no measurement" (reconciler-
    # synthesised samples, or pre-upgrade nodes that don't ship sampled_at).
    latency_ms: float = 0.0


class ScoreboardSnapshotState(CtfyModel):
    """One row of a periodic scoreboard snapshot.

    Taken every few minutes by a background loop so the scoreboard
    history chart can render "rank over time" without replaying the
    full activity log. Stored in a dedicated table (sqlite) or list
    (in-memory); pruned on a rolling window to keep the set bounded.
    """

    snapshot_at: str = ""  # ISO timestamp for display
    snapshot_at_ts: float = 0.0  # Unix seconds, used for filters + indexing
    team_id: str = ""
    team_name: str = ""
    rank: int = 0
    solved: int = 0
    attempts: int = 0


class NodeInviteState(CtfyModel):
    """One-time registration credential issued by an admin.

    Mirrors the GitHub Actions runner / Cloudflare Tunnel model: admin
    creates an invite → gets a plaintext token once → node presents it
    to ``POST /nodes/register`` → platform consumes it atomically and
    mints long-lived per-node credentials.
    """

    invite_id: str = ""  # short random id; used in GET/DELETE paths
    token_hash: str = ""  # SHA-256 of the plaintext; plaintext is never stored
    created_at: str = ""
    created_at_ts: float = 0.0
    expires_at_ts: float = 0.0
    # 0.0 while active; set to the consume wall clock once spent.
    consumed_at_ts: float = 0.0
    # Set alongside consumed_at_ts for audit: which node_id spent this invite.
    consumed_by_node_id: str = ""


class SubmissionState(CtfyModel):
    submission_id: str = ""
    team_id: str = ""
    # Post user/team-split: the human who submitted. Stamped at submit
    # time; survives the user later moving teams. Empty for legacy rows
    # pre-split (the SQLiteBackend migration backfills user_id = team_id
    # since at that point team_id was the user).
    user_id: str = ""
    challenge_id: str = ""
    claimed_flag: str = ""
    correct: bool = False
    # Which flag_id the submission matched, if any. Empty string on wrong
    # submissions. On multi-flag challenges this disambiguates which flag
    # was hit.
    flag_id: str = ""
    submitted_at: str = ""
    solve_time_s: float = 0.0


class AchievementRecord(CtfyModel):
    """One unlocked achievement for a team.

    Rows are idempotent on ``(team_id, achievement_id)`` — calling
    ``grant_achievement`` twice is a no-op. The ``context`` blob captures
    whatever the rule thought worth remembering (challenge_id that
    triggered it, solve_time_s, etc.) — it's free-form because rule
    authors know best.
    """

    team_id: str = ""
    achievement_id: str = ""
    unlocked_at: str = ""
    context: dict[str, Any] = Field(default_factory=dict)


class InstanceState(CtfyModel):
    instance_id: str = ""
    spec: dict[str, Any] = Field(default_factory=dict)
    challenge_id: str = ""
    status: str = InstanceStatus.STARTING
    team_id: str = ""
    # Competition the instance belongs to. Stamped at start time from
    # the resolved per-comp team's ``competition_id``. A user on
    # different teams across multiple comps can run the same challenge
    # in each — each instance row is pinned to one comp so the
    # listing endpoint can scope ``GET /instances?competition_id=X``
    # without leaking cross-comp rows. Empty for legacy rows minted
    # before this field existed; treat as "unscoped" / global.
    competition_id: str = ""
    node_id: str = ""
    surface: AttackSurface | None = None
    # Flags are generated by the platform on POST /instances and injected
    # into the node's container as $FLAG_<UPPER_ID> env vars (one per
    # declared flag_id; single-flag challenges get ``$FLAG_MAIN``). The
    # node does not persist them; the platform keeps the canonical copies
    # here for constant-time verification on /submissions (step 18).
    flags: dict[str, str] = Field(default_factory=dict)
    # Per-instance random tokens (path slugs / parameter names / column
    # names / etc.) that the platform mints alongside flags and injects
    # as ``$VAR_<UPPER_ID>`` env vars. Carries every id from both
    # ``spec.vars`` (private — never exposed to the agent) and
    # ``spec.public_vars`` (substituted into the per-instance description
    # via ``${VAR_X}`` placeholders). Public/private split is decided at
    # the API surface by consulting the spec, not by separate fields here.
    vars: dict[str, str] = Field(default_factory=dict)
    error: str = ""
    name: str = ""
    category: str = ""
    difficulty: str = ""
    started_at: float = 0.0
    # Wall-clock moment the platform accepted ``POST /instances`` for this row.
    # ``ready_at - requested_at`` is the launch latency surfaced on the admin
    # per-challenge dashboard. 0.0 on legacy rows / out-of-band writes.
    requested_at: float = 0.0
    # Wall-clock moment the node reported READY. Distinct from
    # ``started_at`` (which the in-memory backend overloads to "started
    # running" for solve-time bookkeeping) so launch-latency queries don't
    # depend on that overload.
    ready_at: float = 0.0
    ttl: int = 0
    expires_at: float = 0.0


class InstanceRecord(CtfyModel):
    """Archival row for a completed or failed instance.

    Written at every terminal path (user-initiated DELETE, TTL reaper,
    admin stop-all, health-check failure, reconcile error, auto-stop after
    a successful solve) so the benchmark retains a permanent, queryable
    record of every instance that has ever run — even after the live
    ``InstanceState`` is evicted from the in-memory dict.
    """

    instance_id: str = ""
    challenge_id: str = ""
    team_id: str = ""
    node_id: str = ""
    name: str = ""
    category: str = ""
    difficulty: str = ""
    # Final status (e.g. STOPPED / ERROR) — the value the instance held when
    # it left the live path. Not a time series; event history lives in the
    # per-instance ``events.jsonl`` file.
    status: str = ""
    # Why the instance ended: "user", "auto_stop_after_solve",
    # "admin_stop_all", "ttl_expired", "node_unhealthy", "error".
    stop_reason: str = ""
    surface: AttackSurface | None = None
    spec: dict[str, Any] = Field(default_factory=dict)
    error: str = ""
    started_at: float = 0.0
    stopped_at: float = 0.0
    # See InstanceState — these mirror the live row's launch timestamps so
    # the admin per-challenge panel can compute p50/p95 launch latency
    # straight off the archive without joining live state.
    requested_at: float = 0.0
    ready_at: float = 0.0
    duration_s: float = 0.0
    ttl: int = 0
    # Denormalized solve outcome for fast filtering — avoids a join to the
    # solves table. Populated when the archive hook runs; best-effort.
    # ``solved`` here means "every flag on the challenge was captured" so
    # archival "fully solved" queries remain a simple boolean filter.
    solved: bool = False
    # Per-flag solve record — which flag ids this team had captured at
    # archive time. Empty for unsolved instances. Preserved so historical
    # instance records show partial progress even after the live
    # InstanceState is evicted.
    solved_flags: list[str] = Field(default_factory=list)
    attempts: int = 0
    # Absolute path to the per-instance artifact directory. Empty when the
    # archive sink was disabled (e.g. tests).
    artifact_dir: str = ""
    # Total HTTP requests captured by the mitmproxy sidecar across the
    # instance's lifetime. Populated at archive time from the persisted
    # ``traffic.jsonl`` so the per-team admin analytics view can sum it
    # without cracking open every flow file. 0 when the archive was not
    # available (e.g. tests) or the sidecar captured nothing.
    request_count: int = 0
