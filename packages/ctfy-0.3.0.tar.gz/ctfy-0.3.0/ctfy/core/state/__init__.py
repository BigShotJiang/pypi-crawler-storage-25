"""Pluggable state backend — shared state for server, pool, and dashboard.

Implementations:
- ``InMemoryBackend``: zero-dependency, single-process (tests, dev)
- ``SQLiteBackend``:   persistent single-process state (prod default)

Factory::

    from ctfy.core.state import create_backend
    backend = create_backend(db_path="/tmp/platform.sqlite3")
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from ctfy.core.state.memory import InMemoryBackend
from ctfy.core.state.models import (
    ActivityState,
    InstanceState,
    NodeState,
    OAuthIdentity,
    ScoreboardSnapshotState,
    SolveState,
    SubmissionState,
    TeamState,
    TeamToken,
)
from ctfy.core.state.protocol import StateBackend
from ctfy.core.state.sqlite import SQLiteBackend


def create_backend(db_path: str = "", *, project_root: Path | None = None) -> StateBackend:
    """Create a state backend.

    Default when ``db_path`` is empty: SQLite at
    ``{project_root}/data/platform.sqlite3`` if ``project_root`` is given,
    otherwise in-memory.

    When SQLite is misconfigured or unreachable we log the reason and fall
    through to ``InMemoryBackend`` so a dev machine still boots — prod
    deployments should catch this via the warning log rather than relying
    on the in-memory fallback surviving a restart.
    """
    from ctfy.core.log import log

    if not db_path:
        if project_root is None:
            log.info("No db_path configured and no project_root given; using in-memory")
            return InMemoryBackend()
        db_dir = project_root / "data"
        db_dir.mkdir(parents=True, exist_ok=True)
        db_path = str(db_dir / "platform.sqlite3")

    try:
        be = SQLiteBackend(db_path)
        log.info("Using SQLite state backend", path=db_path)
        return be
    except (sqlite3.Error, OSError) as e:
        log.warning("SQLite unavailable, falling back to in-memory", error=str(e))
        return InMemoryBackend()


__all__ = [
    "StateBackend",
    "InMemoryBackend",
    "SQLiteBackend",
    "create_backend",
    "ActivityState",
    "InstanceState",
    "NodeState",
    "OAuthIdentity",
    "ScoreboardSnapshotState",
    "SolveState",
    "SubmissionState",
    "TeamState",
    "TeamToken",
]
