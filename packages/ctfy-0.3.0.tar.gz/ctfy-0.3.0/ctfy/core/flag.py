"""Flag generation and verification — single source of truth.

The platform is the canonical holder of every instance's flags (step 18 of
the architecture). Generation and constant-time comparison both live here
so routes that touch flags import from one place and the node never sees
the plaintext flag values.

A challenge can declare multiple named flags (e.g. ``foothold`` / ``root``);
the platform mints one independent random value per declared id.

The same module also mints *vars* — per-instance random tokens used to
randomise paths / parameter names / column names so each team's instance
has a different attack surface, defeating answer memorisation. Vars are
plain identifier-safe strings (no ``FLAG{}`` wrapper) and are never
verified — they are injected into challenge containers as
``$VAR_<UPPER_ID>`` and consumed by the challenge source code.
"""

from __future__ import annotations

import hmac
import re
import secrets
from collections.abc import Iterable

from ctfy.core.exceptions import FlagNotFoundError, InstanceNotFoundError
from ctfy.core.state import StateBackend

__all__ = ["generate_flag", "generate_flags", "generate_var", "generate_vars", "verify_flag"]

_FLAG_WRAPPER_RE = re.compile(r"FLAG\{(.+)\}")

# Var values must work as URL path segments AND programming-language
# identifiers, so we use ``[a-z][a-z0-9]{7}`` — 8 lowercase chars, the
# first one a letter. ~36 bits of entropy is plenty: vars are not
# secrets, just per-instance disambiguators.
_VAR_FIRST_ALPHABET = "abcdefghijklmnopqrstuvwxyz"
_VAR_ALPHABET = _VAR_FIRST_ALPHABET + "0123456789"
_VAR_LENGTH = 8


def generate_flag() -> str:
    """Generate a random platform flag in the canonical ``FLAG{...}`` format."""
    return f"FLAG{{{secrets.token_hex(32)}}}"


def generate_flags(flag_ids: Iterable[str]) -> dict[str, str]:
    """Mint one independent random flag per declared id.

    Each value is a fresh ``FLAG{...}`` token — values are never reused
    across ids so leaking one flag does not expose the others.
    """
    return {fid: generate_flag() for fid in flag_ids}


def generate_var() -> str:
    """Generate one random var value: 8 chars, ``[a-z][a-z0-9]{7}``.

    Identifier-safe and URL-path-safe — works as a route segment, query
    parameter name, DB column name, or cookie name without escaping.
    """
    first = secrets.choice(_VAR_FIRST_ALPHABET)
    rest = "".join(secrets.choice(_VAR_ALPHABET) for _ in range(_VAR_LENGTH - 1))
    return first + rest


def generate_vars(var_ids: Iterable[str]) -> dict[str, str]:
    """Mint one independent random var per declared id."""
    return {vid: generate_var() for vid in var_ids}


def verify_flag(
    state_backend: StateBackend,
    instance_id: str,
    claimed_flag: str,
) -> str | None:
    """Return the flag_id whose stored value matches *claimed_flag*, else None.

    Uses :func:`hmac.compare_digest` for timing safety. Tolerates an
    ``FLAG{...}`` wrapper on the claimed side so a user pasting the full
    token still matches. Compares against every stored flag so any flag id
    can be submitted in any order.
    """
    inst = state_backend.get_instance(instance_id)
    if not inst:
        raise InstanceNotFoundError(instance_id)
    if not inst.flags:
        raise FlagNotFoundError(instance_id)
    m = _FLAG_WRAPPER_RE.fullmatch(claimed_flag)
    unwrapped = m.group(1) if m else None
    for fid, actual in inst.flags.items():
        if hmac.compare_digest(actual, claimed_flag):
            return fid
        if unwrapped is not None and hmac.compare_digest(actual, unwrapped):
            return fid
    return None
