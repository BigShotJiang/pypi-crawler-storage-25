"""Challenge manager — spec registry and provider dispatch.

ChallengeSpec is the in-memory form of an upstream ``metadata.yaml``.
The core schema is the slim v3 spec defined in
https://github.com/CTF-Arena/challenges/blob/main/CLAUDE.md — four
upstream fields (``name``, ``description``, ``difficulty``, ``tags``) with
``id`` injected from the directory name at parse time.

ctfy adds three optional extensions:

* ``flags: list[str]`` — platform-minted flag ids for multi-flag challenges
  (e.g. foothold / root). Defaults to ``["main"]``; their values flow to
  the runtime as ``$FLAG`` (single) or ``$FLAG_<UPPER_ID>`` (multi).
* ``vars: list[str]`` — *private* random tokens minted per instance and
  injected as ``$VAR_<UPPER_ID>`` env vars. Used to randomise paths /
  parameter names / column names so each team's instance has a different
  surface, defeating answer memorisation. Hidden from the agent — the
  challenge must expose them through HTTP behaviour for the agent to
  discover.
* ``public_vars: list[str]`` — same mint mechanism as ``vars`` but the
  values are exposed via ``GET /instances/{id}`` and may be substituted
  into ``description`` via ``${VAR_<UPPER_ID>}`` placeholders.

Every other concept (category, provider, service topology, flag values)
remains platform-fixed and never appears in metadata.
"""

from __future__ import annotations

import atexit
import re
from pathlib import Path
from string import Template
from typing import ClassVar, Iterator

import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator

from ctfy.core.config import CtfyConfig
from ctfy.core.enums import Difficulty
from ctfy.core.provider import ChallengeProvider, StartResult

_TOKEN_ID_RE = re.compile(r"^[a-z][a-z0-9_]*$")
# Backwards-compatible alias — the flag-id regex was the only token-id
# regex before vars existed. Kept exported so external tooling that
# imported it stays valid.
_FLAG_ID_RE = _TOKEN_ID_RE
DEFAULT_FLAG_ID = "main"

# Match only ``VAR_*``-namespaced placeholders so a stray ``$5`` or
# ``$FLAG`` in description prose doesn't trip the validator. Both
# ``$VAR_X`` and ``${VAR_X}`` forms are recognised; ``string.Template``
# substitutes both during ``render_description``.
_DESCRIPTION_VAR_RE = re.compile(r"\$(?:\{(VAR_[A-Z][A-Z0-9_]*)\}|(VAR_[A-Z][A-Z0-9_]*))")


def _description_placeholders(description: str) -> set[str]:
    """Return the set of ``VAR_*`` placeholder names in *description*.

    Captures both ``$VAR_X`` and ``${VAR_X}`` forms. Names outside the
    ``VAR_*`` namespace are ignored on purpose — descriptions routinely
    include ``$``-prefixed text (prices, shell examples, the literal
    ``$FLAG``) that has nothing to do with our placeholder mechanism.
    The validator only enforces that names that *look* like ours
    resolve to a declared ``public_vars`` id.
    """
    out: set[str] = set()
    for braced, plain in _DESCRIPTION_VAR_RE.findall(description):
        out.add(braced or plain)
    return out


class ChallengeSpec(BaseModel):
    """Parsed challenge metadata — slim v3 upstream schema + ctfy extensions.

    Unknown keys raise ``ValidationError`` at parse time (enforces upstream
    rule META005, "no unknown top-level fields"). ``tags`` is required to be
    non-empty (META004). ``flags`` / ``vars`` / ``public_vars`` are
    platform-level optional lists; see module docstring for the contract.
    """

    model_config = ConfigDict(extra="forbid")

    # Upstream-sourced (metadata.yaml)
    name: str
    description: str
    difficulty: Difficulty
    tags: list[str] = Field(min_length=1)

    # ctfy extensions — optional lists of token ids. Snake-case identifiers
    # only, unique within the challenge, and pairwise-disjoint across the
    # three lists. ``flags`` defaults to a single flag named ``main``; the
    # two ``vars`` lists default empty (challenges opt in to randomisation).
    flags: list[str] = Field(default_factory=lambda: [DEFAULT_FLAG_ID], min_length=1)
    vars: list[str] = Field(default_factory=list)
    public_vars: list[str] = Field(default_factory=list)

    # Platform-injected
    id: str
    instance_id: str = ""

    # Platform-fixed defaults (the only category/provider supported today)
    CATEGORY: ClassVar[str] = "web"
    PROVIDER: ClassVar[str] = "docker"

    @model_validator(mode="after")
    def _validate_token_ids(self) -> ChallengeSpec:
        # Per-list shape + uniqueness.
        for label, ids in (
            ("flag", self.flags),
            ("var", self.vars),
            ("public_var", self.public_vars),
        ):
            if len(set(ids)) != len(ids):
                raise ValueError(f"{label} ids must be unique")
            for tid in ids:
                if not isinstance(tid, str) or not _TOKEN_ID_RE.fullmatch(tid):
                    raise ValueError(
                        f"{label} id {tid!r} must match ^[a-z][a-z0-9_]*$ (snake_case)"
                    )
        # Pairwise-disjoint: the same id cannot live in two lists, since
        # they collide on the env-var namespace (FLAG_X vs VAR_X are
        # different but the human-friendly id is the same and that's
        # confusing for authors and audit alike).
        all_ids = self.flags + self.vars + self.public_vars
        if len(set(all_ids)) != len(all_ids):
            raise ValueError(
                "flags, vars, and public_vars must be pairwise disjoint"
            )
        # Description may only reference public_vars. Substitute against
        # the public-var id set with a sentinel value to detect unknown /
        # private references; ``Template.substitute`` raises ``KeyError``
        # for any placeholder we did not provide.
        placeholders = _description_placeholders(self.description)
        if placeholders:
            allowed = {f"VAR_{vid.upper()}" for vid in self.public_vars}
            unknown = placeholders - allowed
            if unknown:
                raise ValueError(
                    "description references unknown or private vars: "
                    + ", ".join(sorted(unknown))
                    + " (only ${VAR_<UPPER_ID>} for declared public_vars is allowed)"
                )
        return self

    def render_description(self, public_var_values: dict[str, str]) -> str:
        """Substitute ``${VAR_X}`` placeholders with per-instance values.

        ``public_var_values`` is keyed by the lowercase id (matching
        ``self.public_vars``); the substitution map exposes them as
        ``VAR_<UPPER_ID>``. Private vars are intentionally not provided —
        the spec validator already rejected any description that referenced
        them. Returns the description unchanged when no placeholders /
        public_vars are involved.
        """
        if not self.public_vars:
            return self.description
        mapping = {f"VAR_{vid.upper()}": public_var_values.get(vid, "") for vid in self.public_vars}
        return Template(self.description).safe_substitute(mapping)

    @property
    def effective_id(self) -> str:
        """ID used for container/network naming (unique per team+challenge)."""
        return self.instance_id or self.id

    @classmethod
    def from_yaml(cls, path: Path) -> ChallengeSpec:
        """Parse ``metadata.yaml``; ``id`` comes from the parent directory name."""
        data = yaml.safe_load(path.read_text()) or {}
        if not isinstance(data, dict):
            raise ValueError(f"metadata.yaml must be a mapping at {path}")
        data["id"] = path.parent.name
        return cls(**data)


class ChallengeManager:
    """Scans metadata.yaml specs and dispatches lifecycle to the Docker provider.

    Historically this class ran a provider registry so multiple backends
    (``docker``, ``offline``, test shims) could coexist. The upstream SSOT
    now pins everything to ``docker compose``, so the registry was removed
    and a single :class:`DockerProvider` is instantiated lazily.
    """

    def __init__(self, config: CtfyConfig):
        self.config = config
        self.challenges_dir = config.challenges_dir
        self._provider: ChallengeProvider | None = None
        atexit.register(self.stop_all)

    @property
    def provider(self) -> ChallengeProvider:
        if self._provider is None:
            from ctfy.providers.docker_provider.provider import DockerProvider

            self._provider = DockerProvider(self.config)
        return self._provider

    # -- enumeration --------------------------------------------------------

    def iter_specs(
        self,
        *,
        challenge_id: str | None = None,
        difficulty: str | None = None,
        tag: str | None = None,
    ) -> Iterator[ChallengeSpec]:
        """Walk ``challenges_dir`` and yield parsed specs.

        Invalid metadata (parse / schema errors) is skipped with a warning —
        one malformed challenge doesn't block listing the rest. The CLI's
        ``ctfy challenge validate`` path surfaces those errors explicitly.
        """
        from pydantic import ValidationError

        from ctfy.core.log import log

        if not self.challenges_dir.exists():
            return
        for d in sorted(self.challenges_dir.iterdir()):
            yml = d / "metadata.yaml"
            if not d.is_dir() or not yml.exists():
                continue
            try:
                spec = ChallengeSpec.from_yaml(yml)
            except (ValidationError, yaml.YAMLError, OSError) as exc:
                log.warning("Skipping invalid challenge", challenge=d.name, error=str(exc))
                continue
            if challenge_id:
                patterns = [e.strip() for e in challenge_id.split(",")]
                if not any(spec.id == p or spec.id.startswith(p + "-") for p in patterns):
                    continue
            if difficulty is not None and spec.difficulty.value != difficulty:
                continue
            if tag and tag not in spec.tags:
                continue
            yield spec

    # -- lifecycle ----------------------------------------------------------

    def start(
        self,
        spec: ChallengeSpec,
        *,
        flags: dict[str, str],
        vars: dict[str, str] | None = None,
        proxy_output_dir: Path | None = None,
    ) -> StartResult:
        """Start an instance. ``flags`` and ``vars`` are minted on the platform.

        ``flags`` maps flag_id (declared in ``spec.flags``) to the raw flag
        value. Must be non-empty and cover every id in ``spec.flags`` with a
        non-empty value.

        ``vars`` (optional) maps every id declared in ``spec.vars`` and
        ``spec.public_vars`` to its per-instance random token. Visibility
        (private vs public) is decided at the API surface, not here — the
        provider injects every var as ``$VAR_<UPPER_ID>`` regardless of
        public/private classification.
        """
        if not flags:
            raise ValueError("flags must be non-empty; generate them on the platform")
        expected = set(spec.flags)
        missing = expected - set(flags)
        if missing:
            raise ValueError(f"flags dict missing ids: {sorted(missing)}")
        extra = set(flags) - expected
        if extra:
            raise ValueError(f"flags dict has unknown ids: {sorted(extra)}")
        for fid, val in flags.items():
            if not val:
                raise ValueError(f"flag {fid!r} is empty; every flag value must be non-empty")

        vars = vars or {}
        expected_vars = set(spec.vars) | set(spec.public_vars)
        missing_vars = expected_vars - set(vars)
        if missing_vars:
            raise ValueError(f"vars dict missing ids: {sorted(missing_vars)}")
        extra_vars = set(vars) - expected_vars
        if extra_vars:
            raise ValueError(f"vars dict has unknown ids: {sorted(extra_vars)}")
        for vid, val in vars.items():
            if not val:
                raise ValueError(f"var {vid!r} is empty; every var value must be non-empty")
        return self.provider.start(
            spec, proxy_output_dir=proxy_output_dir, flags=flags, vars=vars
        )

    def verify_flag(self, spec: ChallengeSpec, claimed_flag: str) -> str | None:
        """Return the flag_id that matches *claimed_flag*, or None if no match."""
        return self.provider.verify_flag(spec.effective_id, claimed_flag)

    def stop(self, spec: ChallengeSpec) -> None:
        self.provider.stop(spec)

    def check_health(self, instance_id: str) -> bool:
        """Check if an instance's containers are all running."""
        return self.provider.check_health(instance_id)

    def get_cert_volume(self, instance_id: str) -> str:
        """Return the Docker volume name containing mitmproxy CA certs."""
        return self.provider.get_cert_volume(instance_id)

    def get_proxy_output(self, instance_id: str) -> Path | None:
        """Return path to mitmproxy traffic output directory, if available."""
        return self.provider.get_proxy_output(instance_id)

    def get_container_logs(self, instance_id: str) -> str:
        """Return combined stdout+stderr for the instance's containers."""
        return self.provider.get_container_logs(instance_id)

    def stop_all(self) -> None:
        if self._provider is not None:
            self._provider.stop_all()
