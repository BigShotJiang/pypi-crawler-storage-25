"""Shared enums — single source of truth for status values, event types, and constants."""

from __future__ import annotations

from enum import Enum


class InstanceStatus(str, Enum):
    """Lifecycle status of a challenge instance."""

    STARTING = "starting"
    READY = "ready"
    ERROR = "error"
    STOPPED = "stopped"


class PlatformEvent(str, Enum):
    """Events emitted by the platform (SSE broadcast + activity log)."""

    INSTANCE_STARTED = "instance_started"
    INSTANCE_READY = "instance_ready"
    INSTANCE_ERROR = "instance_error"
    INSTANCE_STOPPED = "instance_stopped"
    FLAG_CORRECT = "flag_correct"
    FLAG_PART_CORRECT = "flag_part_correct"
    FLAG_WRONG = "flag_wrong"
    TEAM_REGISTERED = "team_registered"
    INSTANCE_RENEWED = "instance_renewed"
    NODE_REGISTERED = "node_registered"
    NODE_UNHEALTHY = "node_unhealthy"
    NODE_RECOVERED = "node_recovered"
    NODE_REMOVED = "node_removed"
    NODE_UPDATED = "node_updated"
    ACHIEVEMENT_UNLOCKED = "achievement_unlocked"
    # Synthetic UI signal — derived after any write that changes a /meta
    # counter (teams_total, nodes_*, running_instances, solves_total) so
    # the admin status bar can drop its 60s/30s polls. Never recorded on
    # the activity log; broadcast admin_only=True since the carried
    # numbers are admin-only on /meta.
    META_STATS = "meta_stats"
    # Per-node uptime + load update — pushed admin_only=True on every
    # heartbeat (and on heartbeat-timeout transitions detected by the
    # reconciler). Lets the admin NodeStatusStrip / overview drop their
    # 30s poll without losing strip-level granularity. Never recorded
    # on the activity log; carries one ``NodeHealthSample`` per frame.
    NODE_STATUS = "node_status"
    # Public scoreboard-changed signal — pushed after every write that
    # changes the visible ranking (today: full FLAG_CORRECT; tomorrow:
    # admin grants/revokes, retroactive marks). Subscribers refetch
    # ``/scoreboard`` so the consumer doesn't need to know which fields
    # moved. Not admin_only — every visitor sees the scoreboard.
    SCOREBOARD_UPDATED = "scoreboard_updated"
    # Team self-deleted via DELETE /me. Broadcast admin_only=True so
    # admin Overview can drop the row from its team list without
    # refetching. The accompanying meta_stats frame keeps teams_total
    # in lockstep.
    TEAM_DELETED = "team_deleted"
    # Team's own profile / visibility map changed via PATCH /me/profile
    # or /me/profile/visibility. Broadcast globally so anyone watching
    # /teams/{id} (or the team's own Settings) refetches in real time
    # without polling.
    TEAM_PROFILE_UPDATED = "team_profile_updated"
    # Team's privilege role was changed by a super-admin via
    # PATCH /admin/teams/{id}/role. Recorded on the activity log so the
    # audit surface answers "who promoted whom and when". Broadcast
    # admin_only=True so AdminTeams can refresh without polling and
    # without leaking role changes to the public.
    TEAM_ROLE_CHANGED = "team_role_changed"
    # Announcement lifecycle — every viewer subscribes (the announcement
    # banner + /announcements list) so admin edits land without a
    # manual reload. Broadcast globally; the carried payload is the
    # announcement_id, so subscribers refetch the list rather than
    # trusting per-frame fields.
    ANNOUNCEMENT_CREATED = "announcement_created"
    ANNOUNCEMENT_UPDATED = "announcement_updated"
    ANNOUNCEMENT_DELETED = "announcement_deleted"
    # Competition lifecycle — an admin created/edited/deleted a curated
    # competition. Broadcast globally so any open Competitions /
    # CompetitionDetail page refetches without polling. Carried payload
    # is just ``competition_id``; subscribers refetch the row.
    COMPETITION_CREATED = "competition_created"
    COMPETITION_UPDATED = "competition_updated"
    COMPETITION_DELETED = "competition_deleted"
    # Per-team competition signup. Recorded on the team's activity log so
    # the timeline shows "joined Spring CTF" alongside solves; broadcast
    # globally so the registered_count badge on /competitions updates
    # live for any viewer.
    COMPETITION_REGISTERED = "competition_registered"
    COMPETITION_UNREGISTERED = "competition_unregistered"
    # User changed teams: register / create / leave / redeem-invite / kick.
    # Broadcast globally so any open /team page (the captain's, the
    # member's, or a curious bystander on /teams/{id}) refetches the
    # member list without polling. Carried payload is just the user_id +
    # team_ids on either side of the move; subscribers refetch.
    TEAM_MEMBERSHIP_CHANGED = "team_membership_changed"
    # Per-team audit rows (durable activity log entries, not cache
    # invalidation). The membership_changed signal handles realtime UI;
    # these write to the activity log so "who joined / left / kicked
    # whom and when" is permanently traceable.
    TEAM_MEMBER_JOINED = "team_member_joined"
    TEAM_MEMBER_LEFT = "team_member_left"
    TEAM_MEMBER_KICKED = "team_member_kicked"


class Difficulty(str, Enum):
    """Upstream challenges slim v3 schema — difficulty is a 3-valued enum."""

    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


# Sort rank: easy < medium < hard. Used for stable ordering in listings.
DIFFICULTY_RANK: dict[str, int] = {
    Difficulty.EASY: 1,
    Difficulty.MEDIUM: 2,
    Difficulty.HARD: 3,
}
