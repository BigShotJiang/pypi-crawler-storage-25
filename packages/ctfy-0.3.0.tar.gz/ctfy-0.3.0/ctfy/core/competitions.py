"""Competition helpers — pure functions over :class:`CompetitionState`.

The phase classifier lives here so both backends evaluate it against
the same notion of "now": sqlite filters in SQL using the same string
comparison the in-memory backend uses in Python.
"""

from __future__ import annotations

from typing import Literal

from ctfy.core.state.models import CompetitionState

CompetitionPhase = Literal["upcoming", "running", "past"]


def phase(comp: CompetitionState, now_iso: str) -> CompetitionPhase:
    """Classify ``comp`` against ``now_iso``.

    Uses the same convention as :class:`AnnouncementState`: empty
    ``starts_at`` means "live immediately", empty ``ends_at`` means
    "never ends". A competition with both fields empty is always
    ``"running"``.
    """
    if comp.ends_at and comp.ends_at <= now_iso:
        return "past"
    if comp.starts_at and comp.starts_at > now_iso:
        return "upcoming"
    return "running"


def matches_phase(comp: CompetitionState, target: str, now_iso: str) -> bool:
    """True iff ``comp``'s phase matches ``target`` at ``now_iso``."""
    if not target:
        return True
    return phase(comp, now_iso) == target
