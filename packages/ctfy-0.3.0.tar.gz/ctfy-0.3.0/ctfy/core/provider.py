"""Challenge provider interface — the shared contract for all challenge backends.

Providers are ONLY used inside the server. CLI/agents never instantiate
providers directly; they always go through the server HTTP API.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar

from ctfy.core.target import AttackSurface


@dataclass
class StartResult:
    """Result of starting an instance. Flags are kept server-side."""

    surface: AttackSurface
    flags: dict[str, str]


class ChallengeProvider(ABC):
    """Lifecycle manager for challenge instances.

    Used exclusively inside the server. External clients use the HTTP API.
    """

    name: ClassVar[str]

    def __enter__(self):
        return self

    def __exit__(self, *exc_info):
        self.stop_all()

    @abstractmethod
    def start(
        self,
        spec,
        *,
        flags: dict[str, str],
        vars: dict[str, str] | None = None,
        proxy_output_dir: Path | None = None,
    ) -> StartResult:
        """Start the instance. Returns surface + flags (kept server-side).

        *flags* is the platform-generated flag_id→value mapping the provider
        must inject (one ``$FLAG_<UPPER_ID>`` env var per entry). Flag
        ownership is a platform-only concern (step 18) — providers never
        fabricate their own, and callers must never pass an empty dict or
        an empty value.

        *vars* is the platform-generated var_id→value mapping for
        per-instance random tokens (paths / parameter names / column
        names). Injected as ``$VAR_<UPPER_ID>`` env vars; defaults to an
        empty dict for challenges that do not declare any.
        """
        ...

    @abstractmethod
    def verify_flag(self, instance_id: str, claimed_flag: str) -> str | None:
        """Constant-time flag verification.

        Returns the flag_id whose stored value matches *claimed_flag*, or
        ``None`` if nothing matches.
        """
        ...

    @abstractmethod
    def stop(self, spec) -> None: ...

    @abstractmethod
    def stop_all(self) -> None: ...

    def check_health(self, instance_id: str) -> bool:
        """Return True if the instance's containers are all healthy/running."""
        return True

    def get_cert_volume(self, instance_id: str) -> str:
        return ""

    def get_proxy_output(self, instance_id: str) -> Path | None:
        return None

    def get_container_logs(self, instance_id: str) -> str:
        """Combined stdout+stderr for the instance's containers.

        Default: no logs. Providers that can capture container output
        (e.g. Docker) override this so the platform can archive the log
        at stop time for post-hoc analysis.
        """
        return ""
