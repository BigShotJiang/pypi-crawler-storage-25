"""Named constants — replaces magic numbers scattered across the codebase."""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Timeouts (seconds)
# ---------------------------------------------------------------------------

DEFAULT_INSTANCE_TTL: int = 3600
"""Default time-to-live for a running instance."""

DEFAULT_RUN_TIMEOUT: int = 300
"""Default wall-clock timeout for a single agent run."""

DEFAULT_POLL_TIMEOUT: int = 300
"""Default timeout when polling for instance readiness."""

DEFAULT_CLIENT_TIMEOUT: int = 600
"""Default HTTP client timeout for SDK requests."""

STARTUP_TIMEOUT: int = 120
"""Max seconds to wait for Docker services to become healthy."""

HEALTH_CHECK_INTERVAL: int = 30
"""Seconds between periodic health checks and reaper sweeps."""

HEARTBEAT_TIMEOUT: int = 90
"""Seconds before a worker node is considered unhealthy."""

REMOTE_INSTANCE_POLL_MAX: int = 300
"""Max iterations when polling a remote node for instance readiness."""

SSE_KEEPALIVE_INTERVAL: int = 30
"""Seconds between SSE keepalive pings."""

# ---------------------------------------------------------------------------
# Capacity & rate limits
# ---------------------------------------------------------------------------

MAX_INSTANCES_PER_TEAM: int = 5
"""Maximum concurrent instances per team."""

DEFAULT_NODE_CAPACITY: int = 50
"""Default max concurrent instances per worker node.

Used as a static fallback when a node cannot read its own resources
(e.g. ``psutil`` import failed). Operator-supplied ``--capacity`` and the
auto-derived value (see ``ctfy.server.node_app.auto_capacity``) take
precedence — this constant is only the last-resort default."""

NODE_CPU_PER_INSTANCE: int = 2
"""Auto-capacity heuristic: instances per CPU core.

Each CTF instance is a small container (web/pwn/crypto challenges); two
per core leaves headroom for the node process and Docker daemon. Combined
with ``NODE_MEMORY_GB_PER_INSTANCE`` to derive a node's default capacity
when the operator doesn't pass ``--capacity``."""

NODE_MEMORY_GB_PER_INSTANCE: float = 1.0
"""Auto-capacity heuristic: GB of RAM budgeted per instance.

A 4-core / 8 GB node lands at min(8, 8) = 8 instances; a 16-core / 32 GB
node lands at 32. Conservative on purpose — under-provisioning is
recoverable (operator passes ``--capacity``), OOM-kills aren't."""

NODE_SCHEDULING_CPU_THRESHOLD: float = 85.0
"""Skip a node during placement if its last-reported ``cpu_percent``
exceeds this value (0–100). Slot count remains the primary throttle;
this is a secondary safety so a thundering-herd of small challenges
doesn't pile onto a node that's already saturated."""

NODE_SCHEDULING_MEMORY_THRESHOLD: float = 85.0
"""Skip a node during placement if its last-reported ``memory_percent``
exceeds this value (0–100). Memory pressure is more dangerous than CPU
(OOM-kills the whole instance), but the threshold is symmetric for now —
operators tune via constants if needed."""

DEFAULT_MAX_INSTANCES: int = 50
"""Default max concurrent instances on the platform."""

SUBMISSION_RATE_LIMIT: int = 10
"""Max flag submissions per team per challenge within the rate window."""

SUBMISSION_RATE_WINDOW: float = 60.0
"""Rate window in seconds for submission rate limiting."""

SCOREBOARD_RATE_LIMIT: str = "30/minute"
"""slowapi rate string for scoreboard reads. Both ``/scoreboard`` and
``/scoreboard/challenges`` recompute aggregates on every hit and scan
the full state backend; a sensible per-IP cap keeps a noisy client
from turning them into a DoS vector."""

# ---------------------------------------------------------------------------
# Network
# ---------------------------------------------------------------------------

PROXY_PORT: int = 8080
"""Default mitmproxy listening port inside the sandbox network."""

# ---------------------------------------------------------------------------
# Agent defaults
# ---------------------------------------------------------------------------

DEFAULT_MAX_STEPS: int = 20
"""Default maximum agent steps per task."""

DEFAULT_MAX_BUDGET: float = 1.0
"""Default maximum USD budget per experiment."""

STEP_TIMEOUT_MULTIPLIER: int = 60
"""Seconds per step for computing agent timeout (base agents)."""

HPTSA_STEP_TIMEOUT_MULTIPLIER: int = 120
"""Seconds per step for computing HPTSA agent timeout."""

AGENT_WORKDIR: str = "/home/agent"
"""Unified working directory inside all agent containers."""
