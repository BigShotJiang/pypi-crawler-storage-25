"""Unit tests for Provider interfaces and flag verification."""

from __future__ import annotations

import hmac
from unittest.mock import MagicMock

import pytest
import yaml

from ctfy.core.challenge import ChallengeManager
from ctfy.core.config import CtfyConfig
from ctfy.core.provider import StartResult
from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType
from ctfy.providers.docker_provider.provider import (
    _build_endpoints,
    _build_flag_env,
    _build_var_env,
    _collect_ports,
    _dns_safe,
    _ServicePort,
    _strip_host_port_bindings,
    _traefik_public_host_port,
    _write_override,
)
from ctfy.tests.conftest import build_spec


class TestStartResult:
    def test_creation(self):
        surface = AttackSurface(
            services=[
                ServiceEndpoint(service_type=ServiceType.HTTP, host="target", port=80),
            ]
        )
        result = StartResult(surface=surface, flags={"main": "FLAG{abc123}"})
        assert result.flags == {"main": "FLAG{abc123}"}
        assert len(result.surface.services) == 1

    def test_flags_not_in_surface(self):
        """Flag values should be separate from AttackSurface."""
        surface = AttackSurface()
        result = StartResult(surface=surface, flags={"main": "FLAG{secret}"})
        dumped = result.surface.model_dump()
        assert "FLAG" not in str(dumped)

    def test_multi_flag(self):
        surface = AttackSurface()
        result = StartResult(
            surface=surface,
            flags={"foothold": "FLAG{a}", "root": "FLAG{b}"},
        )
        assert set(result.flags) == {"foothold", "root"}


class TestDockerProviderVerifyFlag:
    """Test flag verification without actually starting Docker containers."""

    def test_hmac_compare(self):
        """Verify that flag comparison is constant-time."""
        flag = "FLAG{deadbeef0123456789abcdef01234567}"
        assert hmac.compare_digest(flag, flag) is True
        assert hmac.compare_digest(flag, "FLAG{wrong}") is False

    def test_compare_empty(self):
        assert hmac.compare_digest("", "") is True
        assert hmac.compare_digest("FLAG{x}", "") is False


class TestChallengeManagerFlagContract:
    """Flags are platform-generated only; nodes must never fabricate any."""

    def _manager_with_mock_provider(self) -> tuple[ChallengeManager, MagicMock]:
        mock_provider = MagicMock()
        mock_provider.start.return_value = StartResult(
            surface=AttackSurface(), flags={"main": "FLAG{ignored}"}
        )
        cm = ChallengeManager(CtfyConfig())
        cm._provider = mock_provider  # bypass lazy Docker init
        return cm, mock_provider

    def test_flags_reach_provider(self):
        cm, provider = self._manager_with_mock_provider()
        spec = build_spec("REC-001")
        cm.start(spec, flags={"main": "FLAG{routed}"})
        provider.start.assert_called_once_with(
            spec, proxy_output_dir=None, flags={"main": "FLAG{routed}"}, vars={}
        )

    def test_empty_flags_rejected(self):
        cm, _ = self._manager_with_mock_provider()
        spec = build_spec("REC-002")
        with pytest.raises(ValueError, match="flags must be non-empty"):
            cm.start(spec, flags={})

    def test_missing_flag_id_rejected(self):
        cm, _ = self._manager_with_mock_provider()
        spec = build_spec("REC-003", flags=["foothold", "root"])
        with pytest.raises(ValueError, match="missing ids"):
            cm.start(spec, flags={"foothold": "FLAG{x}"})

    def test_empty_flag_value_rejected(self):
        cm, _ = self._manager_with_mock_provider()
        spec = build_spec("REC-004")
        with pytest.raises(ValueError, match="is empty"):
            cm.start(spec, flags={"main": ""})


class TestBuildFlagEnv:
    def test_single_flag_uses_bare_flag(self):
        # Single-flag challenges follow the upstream slim-v3 convention:
        # the container sees ``$FLAG``. The flag id (``main`` by default)
        # is platform-side bookkeeping only.
        env = _build_flag_env({"main": "FLAG{abc}"})
        assert env == {"FLAG": "FLAG{abc}"}

    def test_single_flag_with_custom_id_still_uses_bare_flag(self):
        # Even if the author named their single flag something other than
        # ``main``, the container contract is still ``$FLAG`` — the id
        # only affects scoreboard labels.
        env = _build_flag_env({"trophy": "FLAG{x}"})
        assert env == {"FLAG": "FLAG{x}"}

    def test_multi_flag_uses_id_prefix(self):
        # 2+ flags switch to ``$FLAG_<UPPER_ID>`` per id; bare ``$FLAG``
        # is intentionally absent so authors can detect multi-flag mode.
        env = _build_flag_env({"foothold": "FLAG{a}", "root": "FLAG{b}"})
        assert env == {"FLAG_FOOTHOLD": "FLAG{a}", "FLAG_ROOT": "FLAG{b}"}
        assert "FLAG" not in env

    def test_multi_flag_uppercases_id(self):
        env = _build_flag_env({"my_flag": "FLAG{x}", "other": "FLAG{y}"})
        assert "FLAG_MY_FLAG" in env
        assert "FLAG_OTHER" in env


class TestBuildVarEnv:
    def test_empty_vars_yields_empty_env(self):
        # Challenges that don't declare any vars should produce no
        # ``$VAR_*`` env vars — the convention is opt-in.
        assert _build_var_env({}) == {}

    def test_single_var_uses_id_prefix(self):
        # Unlike flags, vars never get a bare ``$VAR`` alias; even one
        # var gets the namespaced ``$VAR_<UPPER_ID>`` form so authors
        # can add more later without rewriting compose env references.
        env = _build_var_env({"admin_path": "x7q3p2k4"})
        assert env == {"VAR_ADMIN_PATH": "x7q3p2k4"}

    def test_multi_var_uppercases_each_id(self):
        env = _build_var_env({"admin_path": "abc12345", "api_param": "def67890"})
        assert env == {"VAR_ADMIN_PATH": "abc12345", "VAR_API_PARAM": "def67890"}


class TestVarsFlowToProvider:
    def _manager_with_mock_provider(self):
        from ctfy.core.challenge import ChallengeManager
        from ctfy.core.config import CtfyConfig
        from ctfy.core.provider import StartResult
        from ctfy.core.target import AttackSurface

        mock_provider = MagicMock()
        mock_provider.start.return_value = StartResult(
            surface=AttackSurface(), flags={"main": "FLAG{ignored}"}
        )
        cm = ChallengeManager(CtfyConfig())
        cm._provider = mock_provider
        return cm, mock_provider

    def test_vars_passed_through_to_provider(self):
        cm, provider = self._manager_with_mock_provider()
        spec = build_spec("VAR-001", vars=["admin_path"], public_vars=["banner"])
        cm.start(
            spec,
            flags={"main": "FLAG{x}"},
            vars={"admin_path": "abc12345", "banner": "def67890"},
        )
        provider.start.assert_called_once_with(
            spec,
            proxy_output_dir=None,
            flags={"main": "FLAG{x}"},
            vars={"admin_path": "abc12345", "banner": "def67890"},
        )

    def test_missing_var_id_rejected(self):
        cm, _ = self._manager_with_mock_provider()
        spec = build_spec("VAR-002", vars=["admin_path", "api_param"])
        with pytest.raises(ValueError, match="vars dict missing ids"):
            cm.start(
                spec, flags={"main": "FLAG{x}"}, vars={"admin_path": "abc12345"}
            )

    def test_unknown_var_id_rejected(self):
        cm, _ = self._manager_with_mock_provider()
        spec = build_spec("VAR-003", vars=["admin_path"])
        with pytest.raises(ValueError, match="unknown ids"):
            cm.start(
                spec,
                flags={"main": "FLAG{x}"},
                vars={"admin_path": "abc12345", "stale": "deadbeef"},
            )

    def test_empty_var_value_rejected(self):
        cm, _ = self._manager_with_mock_provider()
        spec = build_spec("VAR-004", vars=["admin_path"])
        with pytest.raises(ValueError, match="is empty"):
            cm.start(
                spec, flags={"main": "FLAG{x}"}, vars={"admin_path": ""}
            )


class TestDnsSafe:
    def test_underscores_become_hyphens(self):
        assert _dns_safe("pentest_abc_def") == "pentest-abc-def"

    def test_uppercase_lowercased(self):
        assert _dns_safe("PENTEST_WEB") == "pentest-web"

    def test_leading_trailing_dashes_stripped(self):
        assert _dns_safe("__foo__") == "foo"

    def test_empty_falls_back(self):
        assert _dns_safe("") == "x"
        assert _dns_safe("___") == "x"


class TestTraefikPublicHostPort:
    def test_empty_url_uses_domain_port_80(self):
        assert _traefik_public_host_port("", "localtest.me") == ("localtest.me", 80)

    def test_url_without_port_http(self):
        assert _traefik_public_host_port("http://ctf.example.com", "ignored") == (
            "ctf.example.com",
            80,
        )

    def test_url_without_port_https(self):
        assert _traefik_public_host_port("https://ctf.example.com", "ignored") == (
            "ctf.example.com",
            443,
        )

    def test_url_with_explicit_port(self):
        assert _traefik_public_host_port("http://ctf.example.com:8080", "ignored") == (
            "ctf.example.com",
            8080,
        )


class TestCollectPorts:
    def test_collects_container_ports(self):
        compose_data = {
            "services": {
                "web": {"ports": ["80:3000"]},
                "api": {"ports": [{"target": 8080, "published": 9000}]},
                "nope": {"image": "no-ports"},
            }
        }
        ports = _collect_ports(compose_data)
        by_service = {p.service: p for p in ports}
        assert by_service["web"].container_port == 3000
        assert by_service["api"].container_port == 8080
        assert "nope" not in by_service


class TestStripHostPortBindings:
    def test_removes_ports_field(self):
        compose_data = {
            "services": {
                "web": {"ports": ["80:3000"], "image": "x"},
                "sidecar": {"image": "y"},  # no ports — untouched
            }
        }
        _strip_host_port_bindings(compose_data)
        assert "ports" not in compose_data["services"]["web"]
        assert compose_data["services"]["web"]["image"] == "x"
        assert compose_data["services"]["sidecar"] == {"image": "y"}


class TestWriteOverrideTraefik:
    def test_single_service_uses_instance_subdomain(self, tmp_path):
        allocated = [_ServicePort(service="web", container_port=80)]
        out = tmp_path / "compose.override.yml"
        _write_override(
            out,
            allocated,
            instance_safe_id="abc-123",
            traefik_domain="localtest.me",
            traefik_network="traefik_proxy",
        )
        doc = yaml.safe_load(out.read_text())
        svc = doc["services"]["web"]
        assert svc["networks"] == ["default", "traefik_proxy"]
        labels = svc["labels"]
        assert "traefik.enable=true" in labels
        assert "traefik.docker.network=traefik_proxy" in labels
        # Single service → bare instance subdomain (no service prefix).
        assert "traefik.http.routers.abc-123-web-80.rule=Host(`abc-123.localtest.me`)" in labels
        assert "traefik.http.routers.abc-123-web-80.entrypoints=web" in labels
        assert "traefik.http.services.abc-123-web-80.loadbalancer.server.port=80" in labels
        assert "ports" not in svc  # no host port ever bound
        assert doc["networks"] == {"traefik_proxy": {"external": True, "name": "traefik_proxy"}}

    def test_multiple_services_get_service_subdomain(self, tmp_path):
        allocated = [
            _ServicePort(service="web", container_port=80),
            _ServicePort(service="api", container_port=8080),
        ]
        out = tmp_path / "compose.override.yml"
        _write_override(
            out,
            allocated,
            instance_safe_id="abc-123",
            traefik_domain="localtest.me",
            traefik_network="traefik_proxy",
        )
        doc = yaml.safe_load(out.read_text())
        web_labels = doc["services"]["web"]["labels"]
        api_labels = doc["services"]["api"]["labels"]
        # Multi-service → each gets a service sub-label so hosts don't collide.
        assert any("Host(`web.abc-123.localtest.me`)" in lbl for lbl in web_labels)
        assert any("Host(`api.abc-123.localtest.me`)" in lbl for lbl in api_labels)

    def test_no_ports_no_override(self, tmp_path):
        out = tmp_path / "compose.override.yml"
        _write_override(
            out,
            [],
            instance_safe_id="abc-123",
            traefik_domain="localtest.me",
            traefik_network="traefik_proxy",
        )
        doc = yaml.safe_load(out.read_text())
        assert doc == {"services": {}}


class TestBuildEndpointsTraefik:
    def test_single_service_uses_instance_subdomain(self):
        allocated = [_ServicePort(service="web", container_port=80)]
        host_eps, sandbox_eps = _build_endpoints(
            allocated,
            instance_safe_id="abc-123",
            traefik_domain="localtest.me",
            traefik_public_url="http://localtest.me",
        )
        assert len(host_eps) == 1
        assert host_eps[0].host == "abc-123.localtest.me"
        assert host_eps[0].port == 80
        assert host_eps[0].service_type == ServiceType.HTTP
        # sandbox view is always the compose DNS name
        assert sandbox_eps[0].host == "web"
        assert sandbox_eps[0].port == 80

    def test_multiple_services_get_service_subdomain(self):
        allocated = [
            _ServicePort(service="web", container_port=80),
            _ServicePort(service="api", container_port=8080),
        ]
        host_eps, _ = _build_endpoints(
            allocated,
            instance_safe_id="abc-123",
            traefik_domain="localtest.me",
            traefik_public_url="http://localtest.me",
        )
        hosts = sorted(ep.host for ep in host_eps)
        assert hosts == ["api.abc-123.localtest.me", "web.abc-123.localtest.me"]

    def test_traefik_public_url_with_port(self):
        allocated = [_ServicePort(service="web", container_port=80)]
        host_eps, _ = _build_endpoints(
            allocated,
            instance_safe_id="abc-123",
            traefik_domain="localtest.me",
            traefik_public_url="http://ctf.example.com:8080",
        )
        assert host_eps[0].port == 8080
