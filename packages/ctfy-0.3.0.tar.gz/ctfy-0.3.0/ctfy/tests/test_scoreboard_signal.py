"""Pin the contract that ``scoreboard_updated`` fires after every
write that should re-rank the public board, reaches every connected
client (not admin-only), and is filed against the right trigger set.
"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

from ctfy.core.enums import PlatformEvent
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import TeamState
from ctfy.server.app_state import AppState
from ctfy.server.event_payloads import (
    AchievementUnlockedPayload,
    FlagCorrectPayload,
    FlagWrongPayload,
)
from ctfy.server.events import emit_event
from ctfy.server.scoreboard_signal import (
    SCOREBOARD_AFFECTING_EVENTS,
    emit_scoreboard_updated,
)
from ctfy.server.sse import SSEHub


def _make_app() -> AppState:
    backend = InMemoryBackend()
    spec_reader = MagicMock()
    spec_reader.iter_specs.return_value = iter([])
    return AppState(
        config=MagicMock(),
        state_backend=backend,
        spec_reader=spec_reader,
        sse_hub=SSEHub(),
        host="x",
        max_instances=10,
    )


def _scoreboard_calls(spy):
    return [
        c
        for c in spy.call_args_list
        if c.args[0] == PlatformEvent.SCOREBOARD_UPDATED.value
    ]


def test_emit_scoreboard_updated_is_public_broadcast():
    """The frame goes to every connected client (no admin gate, no
    team filter) — the scoreboard is public."""
    app = _make_app()
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_scoreboard_updated(app)
    spy.assert_called_once()
    args, kwargs = spy.call_args
    assert args[0] == PlatformEvent.SCOREBOARD_UPDATED.value
    # Default admin_only is False; explicit team_id=""
    assert kwargs.get("admin_only", False) is False
    assert kwargs.get("team_id") == ""


def test_flag_correct_triggers_scoreboard_updated():
    app = _make_app()
    app.state_backend.put_team(
        "t1", TeamState(team_id="t1", name="T", created_at="2025-01-01T00:00:00Z")
    )
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_event(
        app,
        FlagCorrectPayload(
            team_id="t1",
            team_name="T",
            challenge_id="C",
            instance_id="i1",
            solve_time_s=12.5,
            flag_id="main",
            challenge_fully_solved=True,
        ),
        actor_id="t1",
        actor_name="T",
        actor_type="team",
    )
    assert len(_scoreboard_calls(spy)) == 1


def test_flag_wrong_does_not_trigger_scoreboard_updated():
    app = _make_app()
    app.state_backend.put_team(
        "t1", TeamState(team_id="t1", name="T", created_at="2025-01-01T00:00:00Z")
    )
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_event(
        app,
        FlagWrongPayload(
            team_id="t1",
            team_name="T",
            challenge_id="C",
            instance_id="i1",
            solve_time_s=4.2,
        ),
        actor_id="t1",
        actor_name="T",
        actor_type="team",
    )
    assert _scoreboard_calls(spy) == []


def test_achievement_unlocked_does_not_trigger_scoreboard_updated():
    """Achievement unlocks don't change the public ranking — only
    full FLAG_CORRECT does. Including unlocks here would
    double-refresh after every solve."""
    app = _make_app()
    app.state_backend.put_team(
        "t1", TeamState(team_id="t1", name="T", created_at="2025-01-01T00:00:00Z")
    )
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_event(
        app,
        AchievementUnlockedPayload(
            team_id="t1",
            team_name="T",
            challenge_id="",
            achievement_id="decathlete",
        ),
        actor_id="t1",
        actor_name="T",
        actor_type="team",
    )
    assert _scoreboard_calls(spy) == []


def test_scoreboard_updated_event_not_in_affecting_set():
    """Sanity: SCOREBOARD_UPDATED itself must not be in the trigger
    set — otherwise emit_event would recurse forever."""
    assert (
        PlatformEvent.SCOREBOARD_UPDATED.value not in SCOREBOARD_AFFECTING_EVENTS
    )


def test_member_and_admin_both_receive_scoreboard_updated():
    """End-to-end through the real hub: the frame is public so both
    member and admin queues see it."""

    async def go():
        app = _make_app()
        app.sse_hub.set_loop(asyncio.get_running_loop())
        _, member_q = app.sse_hub.connect(team_ids=frozenset({"t1"}), is_admin=False)
        _, admin_q = app.sse_hub.connect(team_ids=frozenset({"t1"}), is_admin=True)

        emit_scoreboard_updated(app)

        m_frame = await asyncio.wait_for(member_q.get(), timeout=1)
        a_frame = await asyncio.wait_for(admin_q.get(), timeout=1)
        assert "event: scoreboard_updated" in m_frame
        assert "event: scoreboard_updated" in a_frame

    asyncio.run(go())
