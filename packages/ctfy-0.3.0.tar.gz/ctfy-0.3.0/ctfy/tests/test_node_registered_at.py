"""Node ``registered_at`` field — set on first register, surfaced via
``GET /nodes`` and ``GET /admin/nodes/{id}``.

Closes the UI-tables audit gap that the admin /admin/nodes card had no
"join time" column. The new field is persisted on ``NodeState`` and
exposed on every ``NodeInfo`` read path; existing rows that pre-date
this change deserialize with an empty string and the read endpoints
fall back to ``last_heartbeat`` so the column never shows ``"—"`` for
running nodes that registered before the upgrade.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import NodeState
from ctfy.tests.conftest import build_spec, make_mock_challenge_manager, mint_team


@pytest.fixture
def mock_env_manager():
    return make_mock_challenge_manager(
        challenge_specs=[build_spec("MN-001", name="MN")],
    )


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def admin(backend):
    return mint_team(backend, name="admin", email="admin@example.test", is_admin=True)


@pytest.fixture
def client(mock_env_manager, backend, admin):
    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    return TestClient(app)


def test_register_sets_registered_at(client, admin):
    """A fresh node register persists ``registered_at`` in ISO format."""
    r = client.post(
        "/api/v1/nodes/register",
        json={"url": "http://node-a:8100", "display_name": "A", "capacity": 10},
        headers=admin.headers,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body.get("registered_at"), "registered_at should be set on register"
    # Looks like ISO 8601 with the canonical 'T' separator and 'Z' suffix
    # produced by ``now_iso()``.
    assert "T" in body["registered_at"]


def test_get_admin_node_surfaces_registered_at(client, admin):
    """``GET /admin/nodes/{id}`` returns the same registered_at."""
    r = client.post(
        "/api/v1/nodes/register",
        json={"url": "http://node-b:8100", "display_name": "B", "capacity": 10},
        headers=admin.headers,
    )
    assert r.status_code == 200
    node_id = r.json()["node_id"]
    registered_at = r.json()["registered_at"]

    r2 = client.get(f"/api/v1/admin/nodes/{node_id}", headers=admin.headers)
    assert r2.status_code == 200
    assert r2.json()["registered_at"] == registered_at


def test_list_nodes_surfaces_registered_at(client, admin):
    """``GET /nodes`` carries registered_at on every row."""
    client.post(
        "/api/v1/nodes/register",
        json={"url": "http://node-c:8100", "display_name": "C", "capacity": 10},
        headers=admin.headers,
    )
    r = client.get("/api/v1/nodes", headers=admin.headers)
    assert r.status_code == 200
    body = r.json()
    items = body["items"] if isinstance(body, dict) and "items" in body else body
    assert len(items) >= 1
    for item in items:
        assert "registered_at" in item


def test_legacy_node_falls_back_to_last_heartbeat(client, admin, backend):
    """A node persisted before this PR has registered_at=='', and the
    read endpoint returns ``last_heartbeat`` so the UI never shows '—'
    for an established node."""
    legacy = NodeState(
        node_id="legacy",
        url="http://legacy:8100",
        display_name="legacy",
        capacity=10,
        last_heartbeat="2026-04-01T00:00:00.000Z",
        registered_at="",
        token="t",
    )
    backend.put_node("legacy", legacy)
    r = client.get("/api/v1/admin/nodes/legacy", headers=admin.headers)
    assert r.status_code == 200, r.text
    body = r.json()
    # The fallback chooses last_heartbeat over an empty string.
    assert body["registered_at"] == legacy.last_heartbeat


def test_heartbeat_does_not_overwrite_registered_at(client, admin, backend):
    """Subsequent heartbeats must not move registered_at — the field is
    "join time", not "most recent contact"."""
    register = client.post(
        "/api/v1/nodes/register",
        json={"url": "http://node-d:8100", "display_name": "D", "capacity": 10},
        headers=admin.headers,
    )
    assert register.status_code == 200
    node_id = register.json()["node_id"]
    original = register.json()["registered_at"]
    node_token = register.json()["node_token"]

    hb = client.post(
        "/api/v1/nodes/heartbeat",
        json={"node_id": node_id, "running": 1, "capacity": 10},
        headers={"Authorization": f"Bearer {node_token}"},
    )
    assert hb.status_code == 200, hb.text
    after = backend.get_node(node_id)
    assert after is not None
    assert after.registered_at == original
