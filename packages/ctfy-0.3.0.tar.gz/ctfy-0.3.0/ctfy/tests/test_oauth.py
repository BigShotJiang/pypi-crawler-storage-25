"""End-to-end tests for the OAuth login + identity/token management flow.

Uses :class:`FakeOAuthProvider` (see ``conftest.py``) so the tests never
touch GitHub/Google; each test stages a profile keyed by ``code``, walks
``GET /auth/login/{provider}``, and follows the 302 chain through
``/auth/callback``.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from datetime import datetime, timedelta, timezone
from unittest.mock import patch
from urllib.parse import parse_qs, urlparse

import pytest
from fastapi.testclient import TestClient

from ctfy.server.app import create_app
from ctfy.server.auth import is_token_expired
from ctfy.server.oauth.providers import OAuthProfile
from ctfy.server.oauth.state import sign_state, verify_state
from ctfy.tests.conftest import (
    FakeOAuthProvider,
    install_fake_oauth,
    mint_team,
    oauth_login,
)


@pytest.fixture
def client(backend, mock_env_manager):
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="127.0.0.1", backend=backend)
    cli = TestClient(app)
    # Install fake providers for both github and google so every test can
    # drive either flow without touching the network.
    install_fake_oauth(cli)
    yield cli


@pytest.fixture
def admin_emails(client):
    """Mutator: register email(s) as super-admin for this client.

    Naming kept for historical continuity with the old
    ``CTFY_ADMIN_EMAILS`` allowlist; underneath, the only env-anchored
    privilege tier is now super-admin (regular admin is granted via the
    UI by a super-admin), so the mutator writes
    ``super_admin_emails_lower``.
    """

    def _set(*emails: str) -> None:
        client.app.state.ctfy.super_admin_emails_lower = {
            e.lower() for e in emails
        }

    return _set


# ---------------------------------------------------------------------------
# Provider listing
# ---------------------------------------------------------------------------


class TestProviders:
    def test_listing_reflects_configured_providers(self, client):
        # Both fake providers are installed by the fixture.
        r = client.get("/api/v1/auth/providers")
        assert r.status_code == 200
        providers = {p["name"]: p for p in r.json()["providers"]}
        assert providers["github"]["enabled"] is True
        assert providers["google"]["enabled"] is True
        assert providers["github"]["authorize_path"] == "/api/v1/auth/login/github"

    def test_unconfigured_providers_listed_disabled(self, client):
        # Strip out google; github only.
        client.app.state.ctfy.oauth_providers = {
            "github": client.app.state.ctfy.oauth_providers["github"]
        }
        r = client.get("/api/v1/auth/providers")
        providers = {p["name"]: p for p in r.json()["providers"]}
        assert providers["github"]["enabled"] is True
        assert providers["google"]["enabled"] is False


# ---------------------------------------------------------------------------
# Login flow — new user, returning user
# ---------------------------------------------------------------------------


class TestLoginFlow:
    def test_first_login_creates_user_and_identity(self, client, backend):
        """OAuth login mints a fresh user but no team — teams are
        per-competition now, so the user joins one (Solo / Create /
        Join) when they register for a comp.
        """
        tok = oauth_login(client, "github", email="alice@example.com")
        me = client.get(
            "/api/v1/me", headers={"Authorization": f"Bearer {tok}"}
        ).json()
        assert me["email"] == "alice@example.com"
        assert me["providers"] == ["github"]
        assert me["token_kind"] == "user"
        assert me["is_admin"] is False
        # No auto-team — competition_teams stays empty until the user
        # explicitly registers for a competition.
        assert me["competition_teams"] == []
        assert backend.list_teams() == []

    def test_returning_user_reuses_user_record(self, client, backend):
        tok1 = oauth_login(client, "github", email="alice@example.com")
        tok2 = oauth_login(client, "github", email="alice@example.com")
        # Two distinct tokens minted but one user record.
        assert tok1 != tok2
        assert backend.count_users() == 1
        # Both tokens continue to work (multi-device sign-in).
        for t in (tok1, tok2):
            r = client.get("/api/v1/me", headers={"Authorization": f"Bearer {t}"})
            assert r.status_code == 200

    def test_unverified_email_rejected(self, client):
        fake: FakeOAuthProvider = client.app.state.ctfy.oauth_providers["github"]

        code = secrets.token_urlsafe(12)
        fake.profiles[code] = OAuthProfile(
            provider="github",
            provider_user_id="u1",
            email="alice@example.com",
            email_verified=False,
            display_name="Alice",
        )
        r = client.get("/api/v1/auth/login/github", follow_redirects=False)
        state = parse_qs(urlparse(r.headers["location"]).query)["state"][0]
        r = client.get(
            f"/api/v1/auth/callback/github?code={code}&state={state}",
            follow_redirects=False,
        )
        assert r.status_code == 400
        assert "verify" in r.json()["detail"].lower()


# ---------------------------------------------------------------------------
# Email-based auto-merge
# ---------------------------------------------------------------------------


class TestEmailMerge:
    def test_verified_email_auto_merges_across_providers(self, client, backend):
        # Alice signs in via GitHub first.
        gh_tok = oauth_login(
            client, "github", email="alice@example.com", provider_user_id="gh-1"
        )
        user_id = client.get(
            "/api/v1/me", headers={"Authorization": f"Bearer {gh_tok}"}
        ).json()["user_id"]
        # Then the same (verified) email appears via Google.
        g_tok = oauth_login(
            client, "google", email="alice@example.com", provider_user_id="g-1"
        )
        merged = client.get(
            "/api/v1/me", headers={"Authorization": f"Bearer {g_tok}"}
        ).json()
        assert merged["user_id"] == user_id
        assert sorted(merged["providers"]) == ["github", "google"]
        # Still only one user (and one personal team).
        assert backend.count_users() == 1
        assert backend.list_teams() == []

    def test_unverified_email_does_not_merge(self, client, backend):
        oauth_login(
            client, "github", email="alice@example.com", provider_user_id="gh-1"
        )
        # Fake a second sign-in with email_verified=False directly.
        fake: FakeOAuthProvider = client.app.state.ctfy.oauth_providers["google"]

        code = secrets.token_urlsafe(12)
        fake.profiles[code] = OAuthProfile(
            provider="google",
            provider_user_id="g-1",
            email="alice@example.com",
            email_verified=False,
            display_name="Alice",
        )
        r = client.get("/api/v1/auth/login/google", follow_redirects=False)
        state = parse_qs(urlparse(r.headers["location"]).query)["state"][0]
        r = client.get(
            f"/api/v1/auth/callback/google?code={code}&state={state}",
            follow_redirects=False,
        )
        assert r.status_code == 400  # rejected for unverified email
        # No team was created for the rejected attempt.
        assert backend.list_teams() == []


# ---------------------------------------------------------------------------
# Link flow
# ---------------------------------------------------------------------------


class TestLinkFlow:
    def test_link_second_provider_via_xhr(self, client, backend):
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        # Step 1: authenticated POST returns an authorize_url containing a
        # link-bound state.
        r = client.post("/api/v1/auth/identities/link/google", headers=headers)
        assert r.status_code == 200
        authorize_url = r.json()["authorize_url"]
        state = parse_qs(urlparse(authorize_url).query)["state"][0]
        # Step 2: stage a Google profile and walk the callback with the
        # link state.
        fake: FakeOAuthProvider = client.app.state.ctfy.oauth_providers["google"]

        code = secrets.token_urlsafe(12)
        fake.profiles[code] = OAuthProfile(
            provider="google",
            provider_user_id="g-alice",
            email="alice-google@example.com",
            email_verified=True,
            display_name="Alice G",
        )
        r = client.get(
            f"/api/v1/auth/callback/google?code={code}&state={state}",
            follow_redirects=False,
        )
        assert r.status_code == 302
        # Identity landed on the same team.
        idents = client.get("/api/v1/auth/identities", headers=headers).json()["items"]
        assert sorted(i["provider"] for i in idents) == ["github", "google"]
        assert backend.list_teams() == []

    def test_expired_link_state_rejected(self, client):
        tok = oauth_login(client, "github", email="alice@example.com")
        # Forge an already-expired state.
        # We can do this by constructing one manually.

        secret = client.app.state.ctfy.oauth_secret
        payload = {
            "provider": "google",
            "flow": "link",
            "redirect_to": "/settings",
            "link_token_hash": "bogus",  # irrelevant — exp check fires first
            "nonce": "x" * 16,
            "exp": int(time.time()) - 10,
        }
        body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        sig = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        b64 = base64.urlsafe_b64encode(body).rstrip(b"=").decode()
        state = f"{b64}.{sig}"

        fake: FakeOAuthProvider = client.app.state.ctfy.oauth_providers["google"]
        fake.profiles["whatever"] = OAuthProfile(
            provider="google",
            provider_user_id="g-x",
            email="x@example.com",
            email_verified=True,
            display_name="X",
        )
        r = client.get(
            f"/api/v1/auth/callback/google?code=whatever&state={state}",
            follow_redirects=False,
        )
        assert r.status_code == 400
        assert "expired" in r.json()["detail"].lower()
        _ = tok  # keep tok alive for symmetry with other tests


# ---------------------------------------------------------------------------
# Identity management
# ---------------------------------------------------------------------------


class TestIdentities:
    def test_list_identities_requires_user_kind(self, client, backend):
        # Agent tokens must be rejected.
        m = mint_team(backend, name="Alice", email="alice@example.com")
        r = client.get("/api/v1/auth/identities", headers=m.headers)
        assert r.status_code == 200  # user-kind OK

        # Mint an agent token and try again.
        user_headers = m.headers
        r = client.post(
            "/api/v1/auth/tokens", headers=user_headers, json={"label": "agent"}
        )
        agent = r.json()
        agent_headers = {"Authorization": f"Bearer {agent['token']}"}
        r = client.get("/api/v1/auth/identities", headers=agent_headers)
        assert r.status_code == 403

    def test_cannot_unlink_last_identity(self, client):
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        idents = client.get("/api/v1/auth/identities", headers=headers).json()["items"]
        assert len(idents) == 1
        r = client.delete(
            f"/api/v1/auth/identities/{idents[0]['identity_id']}", headers=headers
        )
        assert r.status_code == 409

    def test_unlink_one_of_two_identities(self, client):
        tok = oauth_login(
            client, "github", email="alice@example.com", provider_user_id="gh-1"
        )
        headers = {"Authorization": f"Bearer {tok}"}
        client.post("/api/v1/auth/identities/link/google", headers=headers)
        # Pretend the user completed the provider flow by calling oauth_login
        # directly with the same email — auto-merge will attach the identity.
        oauth_login(
            client, "google", email="alice@example.com", provider_user_id="g-1"
        )
        idents = client.get("/api/v1/auth/identities", headers=headers).json()["items"]
        assert len(idents) == 2
        # Unlink one — should succeed.
        target = idents[0]["identity_id"]
        r = client.delete(f"/api/v1/auth/identities/{target}", headers=headers)
        assert r.status_code == 200
        remaining = client.get("/api/v1/auth/identities", headers=headers).json()["items"]
        assert len(remaining) == 1


# ---------------------------------------------------------------------------
# Token minting
# ---------------------------------------------------------------------------


class TestTokens:
    def test_agent_token_roundtrip(self, client):
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}

        r = client.post("/api/v1/auth/tokens", headers=headers, json={"label": "cli"})
        assert r.status_code == 200
        agent = r.json()
        assert agent["kind"] == "agent"
        assert agent["token"].startswith("pa_")

        # Listing omits plaintext.
        r = client.get("/api/v1/auth/tokens", headers=headers)
        items = r.json()["items"]
        agent_rows = [t for t in items if t["kind"] == "agent"]
        assert len(agent_rows) == 1
        assert "token" not in agent_rows[0]

        # The agent token can hit a participation endpoint.
        agent_headers = {"Authorization": f"Bearer {agent['token']}"}
        r = client.get("/api/v1/me", headers=agent_headers)
        assert r.status_code == 200
        assert r.json()["token_kind"] == "agent"

        # But cannot mint another token.
        r = client.post(
            "/api/v1/auth/tokens", headers=agent_headers, json={"label": "x"}
        )
        assert r.status_code == 403

        # Revoke it.
        r = client.delete(
            f"/api/v1/auth/tokens/{agent['token_id']}", headers=headers
        )
        assert r.status_code == 200
        # After revoke, the token no longer authenticates.
        r = client.get("/api/v1/me", headers=agent_headers)
        assert r.status_code == 403

    def test_cannot_revoke_current_session(self, client):
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        tokens = client.get("/api/v1/auth/tokens", headers=headers).json()["items"]
        user_tok = next(t for t in tokens if t["kind"] == "user")
        r = client.delete(
            f"/api/v1/auth/tokens/{user_tok['token_id']}", headers=headers
        )
        assert r.status_code == 409

    def test_agent_token_default_expiration(self, client):
        """Agent tokens minted with no ``expires_in_days`` default to 30 days."""
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        r = client.post("/api/v1/auth/tokens", headers=headers, json={"label": "cli"})
        assert r.status_code == 200
        body = r.json()
        assert body["expires_at"]
        expires = datetime.fromisoformat(body["expires_at"])
        delta = expires - datetime.now(timezone.utc)
        # Allow a generous window for slow CI — should be ~30 days.
        assert timedelta(days=29, hours=23) < delta <= timedelta(days=30, minutes=1)

    def test_agent_token_custom_expiration(self, client):
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        r = client.post(
            "/api/v1/auth/tokens",
            headers=headers,
            json={"label": "ci", "expires_in_days": 7},
        )
        assert r.status_code == 200
        expires = datetime.fromisoformat(r.json()["expires_at"])
        delta = expires - datetime.now(timezone.utc)
        assert timedelta(days=6, hours=23) < delta <= timedelta(days=7, minutes=1)

    def test_agent_token_never_expires(self, client):
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        r = client.post(
            "/api/v1/auth/tokens",
            headers=headers,
            json={"label": "forever", "expires_in_days": 0},
        )
        assert r.status_code == 200
        assert r.json()["expires_at"] == ""

    def test_agent_token_expiration_too_large(self, client):
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        r = client.post(
            "/api/v1/auth/tokens",
            headers=headers,
            json={"label": "x", "expires_in_days": 365 * 10},
        )
        # Caught by pydantic's ``le`` constraint.
        assert r.status_code == 422

    def test_expired_agent_token_rejected(self, client, backend):
        """A token whose ``expires_at`` is in the past must not authenticate."""
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        r = client.post("/api/v1/auth/tokens", headers=headers, json={"label": "cli"})
        agent = r.json()
        agent_headers = {"Authorization": f"Bearer {agent['token']}"}

        # Works while fresh.
        assert client.get("/api/v1/me", headers=agent_headers).status_code == 200

        # Force-expire it in the backend (bypasses the API, which caps min TTL).
        stored = backend.get_token(agent["token_id"])
        backend.put_token(
            stored.model_copy(
                update={
                    "expires_at": (
                        datetime.now(timezone.utc) - timedelta(seconds=1)
                    ).isoformat()
                }
            )
        )
        r = client.get("/api/v1/me", headers=agent_headers)
        assert r.status_code == 403
        assert "expired" in r.json()["detail"].lower()

    def test_user_token_has_90_day_expiration(self, client):
        """OAuth login mints a user token with a 90-day TTL."""
        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        tokens = client.get("/api/v1/auth/tokens", headers=headers).json()["items"]
        user_tok = next(t for t in tokens if t["kind"] == "user")
        assert user_tok["expires_at"]
        delta = datetime.fromisoformat(user_tok["expires_at"]) - datetime.now(timezone.utc)
        assert timedelta(days=89, hours=23) < delta <= timedelta(days=90, minutes=1)


class TestSessions:
    """Active-session UI: IP / UA capture, is_current flag, bulk sign-out."""

    def test_session_records_ip_and_user_agent(self, client):
        """User tokens capture client IP and UA at login time."""
        tok = oauth_login(
            client,
            "github",
            email="alice@example.com",
            headers={
                "User-Agent": "Mozilla/5.0 (Macintosh) Chrome/131.0",
                "X-Forwarded-For": "203.0.113.42",
            },
        )
        headers = {"Authorization": f"Bearer {tok}"}
        tokens = client.get("/api/v1/auth/tokens", headers=headers).json()["items"]
        user_tok = next(t for t in tokens if t["kind"] == "user")
        assert user_tok["ip_address"] == "203.0.113.42"
        assert user_tok["user_agent"].startswith("Mozilla/5.0")

    def test_is_current_flag_marks_calling_token(self, client, backend):
        """The token making the /auth/tokens call is flagged is_current=True."""
        first = oauth_login(client, "github", email="alice@example.com")
        # Simulate a second device by logging in again (same email auto-merges
        # onto the same team, giving us two user tokens on one team).
        client.post(
            "/api/v1/auth/identities/link/google",
            headers={"Authorization": f"Bearer {first}"},
        )
        oauth_login(
            client, "google", email="alice@example.com", provider_user_id="g-1"
        )
        headers = {"Authorization": f"Bearer {first}"}
        tokens = client.get("/api/v1/auth/tokens", headers=headers).json()["items"]
        user_rows = [t for t in tokens if t["kind"] == "user"]
        assert len(user_rows) == 2
        current = [t for t in user_rows if t["is_current"]]
        assert len(current) == 1
        # The current one should resolve to the first token by hash.
        from ctfy.server.auth import hash_token

        stored = backend.get_token_by_hash(hash_token(first))
        assert current[0]["token_id"] == stored.token_id

    def test_revoke_other_sessions_kills_only_others(self, client):
        first = oauth_login(client, "github", email="alice@example.com")
        client.post(
            "/api/v1/auth/identities/link/google",
            headers={"Authorization": f"Bearer {first}"},
        )
        second = oauth_login(
            client, "google", email="alice@example.com", provider_user_id="g-1"
        )
        headers = {"Authorization": f"Bearer {first}"}
        # Before: both sessions authenticate.
        assert client.get(
            "/api/v1/me", headers={"Authorization": f"Bearer {second}"}
        ).status_code == 200
        # Call the bulk-revoke endpoint from the first session.
        r = client.delete("/api/v1/auth/tokens/others", headers=headers)
        assert r.status_code == 200
        assert r.json()["revoked"] >= 1
        # First session still works…
        assert client.get("/api/v1/me", headers=headers).status_code == 200
        # …but the second session has been signed out.
        assert client.get(
            "/api/v1/me", headers={"Authorization": f"Bearer {second}"}
        ).status_code == 403

    def test_touch_token_throttled(self, client, backend):
        """Back-to-back requests should not each bump ``last_used_at``."""
        from ctfy.server.auth import hash_token

        tok = oauth_login(client, "github", email="alice@example.com")
        headers = {"Authorization": f"Bearer {tok}"}
        # First request — populates ``last_used_at``.
        client.get("/api/v1/me", headers=headers)
        first_seen = backend.get_token_by_hash(hash_token(tok)).last_used_at
        assert first_seen  # confirm the touch happened
        # Second request within the throttle window — timestamp stays the same.
        client.get("/api/v1/me", headers=headers)
        assert backend.get_token_by_hash(hash_token(tok)).last_used_at == first_seen


class TestTokenExpiryHelper:
    def test_empty_string_never_expires(self):
        assert is_token_expired("") is False

    def test_future_timestamp(self):
        future = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        assert is_token_expired(future) is False

    def test_past_timestamp(self):
        past = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
        assert is_token_expired(past) is True

    def test_unparseable_treated_as_expired(self):
        # Malformed value -> fail closed (403) rather than trusting it.
        assert is_token_expired("not a date") is True

    def test_naive_timestamp_treated_as_utc(self):
        # Defensive: a pre-migration row without a timezone suffix should
        # still compare sanely.
        past = (datetime.now(timezone.utc) - timedelta(days=1)).replace(tzinfo=None)
        assert is_token_expired(past.isoformat()) is True


# ---------------------------------------------------------------------------
# Admin email allowlist
# ---------------------------------------------------------------------------


class TestAdminAllowlist:
    def test_admin_email_grants_is_admin(self, client, admin_emails):
        admin_emails("admin@example.com")
        tok = oauth_login(client, "github", email="admin@example.com")
        me = client.get(
            "/api/v1/me", headers={"Authorization": f"Bearer {tok}"}
        ).json()
        assert me["is_admin"] is True

    def test_removing_from_allowlist_revokes_on_next_login(self, client, admin_emails):
        admin_emails("admin@example.com")
        tok1 = oauth_login(client, "github", email="admin@example.com")
        assert (
            client.get("/api/v1/me", headers={"Authorization": f"Bearer {tok1}"})
            .json()["is_admin"]
            is True
        )
        # Drop from allowlist and re-auth.
        admin_emails()  # empty set
        tok2 = oauth_login(client, "github", email="admin@example.com")
        assert (
            client.get("/api/v1/me", headers={"Authorization": f"Bearer {tok2}"})
            .json()["is_admin"]
            is False
        )


# ---------------------------------------------------------------------------
# State signing
# ---------------------------------------------------------------------------


class TestStateSigning:
    def test_tampered_state_rejected(self, client):
        fake: FakeOAuthProvider = client.app.state.ctfy.oauth_providers["github"]

        code = secrets.token_urlsafe(12)
        fake.profiles[code] = OAuthProfile(
            provider="github",
            provider_user_id="gh-1",
            email="alice@example.com",
            email_verified=True,
            display_name="Alice",
        )
        r = client.get("/api/v1/auth/login/github", follow_redirects=False)
        state = parse_qs(urlparse(r.headers["location"]).query)["state"][0]
        tampered = state[:-1] + ("0" if state[-1] != "0" else "1")
        r = client.get(
            f"/api/v1/auth/callback/github?code={code}&state={tampered}",
            follow_redirects=False,
        )
        assert r.status_code == 400

    def test_sign_verify_roundtrip(self):
        secret = "test-secret-abc"
        raw = sign_state(secret, {"provider": "github", "foo": "bar"}, ttl_s=60)

        payload = verify_state(secret, raw)
        assert payload["provider"] == "github"
        assert payload["foo"] == "bar"
