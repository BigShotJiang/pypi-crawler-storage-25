"""Shared fixtures for tests."""

from __future__ import annotations

import os
import secrets
import time
import uuid
from contextlib import ExitStack, contextmanager
from dataclasses import dataclass
from unittest.mock import MagicMock, patch
from urllib.parse import parse_qs, urlparse

import pytest
from fastapi.testclient import TestClient


# Production default for ``rate_limiting_enabled`` is True so live deployments
# are protected out of the box. The test suite hammers TestClient with bulk
# loops that would trip per-endpoint caps; flip the env switch off so every
# CtfyConfig() instantiated downstream sees the disabled default. Tests that
# specifically exercise rate limiting (e.g. test_platform.py::TestScoreboardEdgeCases)
# pass ``CtfyConfig(rate_limiting_enabled=True)`` explicitly, which overrides this.
os.environ.setdefault("CTFY_RATE_LIMITING_ENABLED", "false")
# The platform now auto-bootstraps a "Practice" competition on first
# launch against an empty competitions table. Tests that care about
# this surface (test_practice_bootstrap.py) call the helper directly;
# every other fixture should see the legacy "no comps" baseline so
# assertions like "list returns [] / two specific titles" stay
# meaningful.
os.environ.setdefault("CTFY_AUTO_BOOTSTRAP_PRACTICE", "false")

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.enums import Difficulty, InstanceStatus
from ctfy.core.provider import StartResult
from ctfy.core.state import InMemoryBackend, StateBackend
from ctfy.core.state.models import (
    NodeState,
    OAuthIdentity,
    TeamMembershipState,
    TeamState,
    TeamToken,
    UserState,
)
from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType
from ctfy.server.auth import hash_token
from ctfy.server.oauth.providers import OAuthProfile


def build_spec(
    id: str,
    *,
    name: str | None = None,
    description: str = "Test challenge.",
    difficulty: Difficulty | str = Difficulty.EASY,
    tags: list[str] | None = None,
    flags: list[str] | None = None,
    vars: list[str] | None = None,
    public_vars: list[str] | None = None,
) -> ChallengeSpec:
    """Construct a ChallengeSpec with sensible defaults for tests.

    The upstream slim v3 schema requires name/description/difficulty/tags;
    callers usually only care about ``id`` and occasionally ``difficulty``,
    so this wraps the pydantic ceremony. ``flags`` defaults to a single
    flag id ``main`` (matches the platform's implicit default). ``vars``
    and ``public_vars`` default to empty lists (no per-instance
    randomisation).
    """
    return ChallengeSpec(
        id=id,
        name=name or id,
        description=description,
        difficulty=Difficulty(difficulty) if isinstance(difficulty, str) else difficulty,
        tags=tags or ["test"],
        flags=flags or ["main"],
        vars=vars or [],
        public_vars=public_vars or [],
    )


#: Default competition id every ``mint_team``-created user is registered
#: for. Tests that don't care about per-comp scoping can ignore it; the
#: helper is built so all the workflow shortcuts (start/submit/...)
#: default to it. Tests that exercise multi-comp behaviour pass a
#: different ``competition_id`` explicitly.
TEST_COMPETITION_ID = "test-comp"


def start_instance_and_wait(
    client,
    challenge_id,
    *,
    max_wait=5,
    headers=None,
    ttl=300,
    competition_id: str = TEST_COMPETITION_ID,
):
    """POST /api/v1/instances then poll status until READY.

    Returns the instance_id. With multi-instance support (0.2+) the
    server always mints a fresh instance — no 409 absorption needed.
    Works with any TestClient-shaped client.
    """
    hdrs = headers or {}
    resp = client.post(
        "/api/v1/instances",
        json={
            "challenge_id": challenge_id,
            "ttl": ttl,
            "competition_id": competition_id,
        },
        headers=hdrs,
    )
    resp.raise_for_status()
    instance_id = resp.json()["instance_id"]

    deadline = time.monotonic() + max_wait
    while time.monotonic() < deadline:
        s = client.get(f"/api/v1/instances/{instance_id}/status", headers=hdrs)
        if s.status_code == 200:
            status = s.json().get("status")
            if status == "ready":
                return instance_id
            if status == "error":
                raise RuntimeError(s.json().get("error") or "instance error")
        time.sleep(0.1)
    raise TimeoutError(f"{challenge_id} not ready after {max_wait}s")


def make_mock_challenge_manager(
    *,
    challenge_specs: list[ChallengeSpec] | None = None,
    flag: str = "FLAG{testflag_0123456789abcdef01234567}",
    host: str = "127.0.0.1",
    port: int = 8080,
    service_type: ServiceType = ServiceType.HTTP,
    auto_generate_specs: bool = True,
) -> MagicMock:
    """Create a mock ChallengeManager with consistent behavior.

    - ``start()`` returns a StartResult with the given flag and service
    - ``iter_specs()`` returns the given specs, filtered by challenge_id if provided.
      If ``auto_generate_specs=True`` (default), unknown challenge_ids get a
      dynamic spec so ``POST /instances`` works with arbitrary test IDs.
    - ``stop()``, ``stop_all()``, ``check_health()`` are no-ops
    """
    mgr = MagicMock()

    mgr.start.return_value = StartResult(
        surface=AttackSurface(
            services=[
                ServiceEndpoint(
                    service_type=service_type,
                    host=host,
                    port=port,
                    label="target",
                ),
            ],
            flag_path="/flag.txt",
        ),
        flags={"main": flag},
    )
    mgr.stop.return_value = None
    mgr.stop_all.return_value = None
    mgr.check_health.return_value = True
    mgr.get_cert_volume.return_value = ""

    specs = challenge_specs or []

    def _iter_specs(
        challenge_id: str | None = None,
        difficulty: str | None = None,
        tag: str | None = None,
        **_kw,
    ):
        if challenge_id:
            patterns = [p.strip() for p in challenge_id.split(",")]
            found = False
            for s in specs:
                if any(s.id == p or s.id.startswith(p + "-") for p in patterns):
                    yield s
                    found = True
            if not found and auto_generate_specs:
                for p in patterns:
                    yield build_spec(p)
        else:
            for s in specs:
                if difficulty is not None and s.difficulty.value != difficulty:
                    continue
                if tag and tag not in s.tags:
                    continue
                yield s

    mgr.iter_specs = _iter_specs
    return mgr


# ---------------------------------------------------------------------------
# Fake node fixture — platform-side testing through the NodeClient seam.
# ---------------------------------------------------------------------------

FAKE_NODE_ID = "node-fake"
FAKE_NODE_URL = "http://fake-node:8101"
FAKE_CLUSTER_TOKEN = "test-cluster"


def make_fake_node_client(
    *,
    flag: str = "FLAG{testflag_0123456789abcdef01234567}",
    host: str = "127.0.0.1",
    port: int = 8080,
    service_type: ServiceType = ServiceType.HTTP,
    healthy: bool = True,
) -> MagicMock:
    """Build a MagicMock shaped like ``sdk.NodeClient``.

    Response payloads match the real node endpoints so platform code
    treats it as a live worker.
    """
    surface = AttackSurface(
        services=[
            ServiceEndpoint(
                service_type=service_type,
                host=host,
                port=port,
                label="target",
            ),
        ],
        flag_path="/flag.txt",
    )

    nc = MagicMock()
    nc.__enter__ = lambda self=None: nc
    nc.__exit__ = lambda *args, **kw: None

    nc.start_instance.return_value = {
        "instance_id": "placeholder",  # platform passes its own id in the request
        "status": InstanceStatus.READY,
    }
    nc.get_status.return_value = {
        "instance_id": "placeholder",
        "status": InstanceStatus.READY,
        "attack_surface": surface.model_dump(mode="json"),
        "error": None,
    }

    # verify_flag lives entirely on the platform post-step-18 — the node
    # never sees a submission. The mock keeps a no-op stub so legacy
    # callers don't AttributeError.
    nc.verify_flag.return_value = False
    nc.stop_instance.return_value = None
    nc.stop_all.return_value = None
    nc.check_health.return_value = healthy
    nc.get_agent_runtime.return_value = {
        "kind": "docker",
        "ca_volume": "",
        "proxy_url": "",
        "ca_cert_pem": "",
        "target_hosts": [host],
    }
    nc.get_traffic.return_value = []
    nc.get_pcap.return_value = b""
    nc.get_container_logs.return_value = ""
    nc.node_health.return_value = {"status": "ok", "running": 0, "capacity": 10}
    return nc


@contextmanager
def fake_node_context(
    backend: StateBackend,
    *,
    flag: str = "FLAG{testflag_0123456789abcdef01234567}",
    host: str = "127.0.0.1",
    port: int = 8080,
    service_type: ServiceType = ServiceType.HTTP,
    healthy: bool = True,
):
    """Register a fake node in ``backend`` and patch the NodeClient seam.

    Use in place of the legacy ``patch("...app.ChallengeManager", ...)``
    block to exercise platform routes through the remote (node) path.
    The caller still provides a mocked ``ChallengeManager`` for
    ``iter_specs`` spec lookup; this helper only covers the provider
    lifecycle calls that now travel over the NodeClient.
    """
    backend.put_node(
        FAKE_NODE_ID,
        NodeState(
            node_id=FAKE_NODE_ID,
            url=FAKE_NODE_URL,
            capacity=100,
            running=0,
            healthy=healthy,
            last_heartbeat=str(time.time()),
            last_heartbeat_ts=time.time(),
        ),
    )
    backend.set_config("cluster_key", FAKE_CLUSTER_TOKEN)

    fake_nc = make_fake_node_client(
        flag=flag,
        host=host,
        port=port,
        service_type=service_type,
        healthy=healthy,
    )

    # ``get_node_client`` lives in node_ops.py and imports NodeClient
    # there; patching at that module level covers every call site.
    with ExitStack() as stack:
        stack.enter_context(
            patch(
                "ctfy.server.node_ops.NodeClient",
                return_value=fake_nc,
            )
        )
        # Platform now generates flags locally (step 18). Pin them to a
        # deterministic mapping so submission assertions line up. All
        # declared flag ids get the same test value — tests that need
        # distinct per-flag values should override this patch.
        stack.enter_context(
            patch(
                "ctfy.server.routes.instances.generate_flags",
                side_effect=lambda flag_ids: {fid: flag for fid in flag_ids},
            )
        )
        yield fake_nc


# ---------------------------------------------------------------------------
# Shared TestClient fixtures — used by test_platform.py and test_team_isolation.py.
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_env_manager():
    return make_mock_challenge_manager(
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        auto_generate_specs=False,
        challenge_specs=[
            build_spec("WEB-001", name="SSTI Challenge", description="Flask SSTI"),
            build_spec(
                "WEB-002",
                name="SQLi Challenge",
                difficulty=Difficulty.MEDIUM,
                description="SQL injection",
            ),
            # Test IDs used by capacity/auth/lifecycle tests
            build_spec("E1"),
            build_spec("E2"),
            build_spec("RATE-001", name="Rate Test"),
            build_spec("AS-001", name="Auto-stop Test"),
        ],
    )


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def client(mock_env_manager, backend):
    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        yield TestClient(app)


# ---------------------------------------------------------------------------
# Auth helpers — bypass OAuth by directly inserting a team + user token into
# the backend. Tests that want to exercise the full OAuth callback path
# should use ``FakeOAuthProvider`` + ``oauth_login`` instead.
# ---------------------------------------------------------------------------


@dataclass
class _MintedTeam:
    """A test fixture's freshly-minted user + personal team + token.

    ``team_id`` is the personal team's id (most existing tests refer
    to this — the conceptual "actor" of the test, equivalent to the
    pre-split TeamState). ``user_id`` is the human's id, distinct now
    that User and Team are separate. Both are equal to ``user_id`` and
    ``team_id`` respectively in the storage layer; tests that need the
    user (e.g. role changes, profile updates) use ``user_id``.
    """

    team_id: str
    user_id: str
    token: str  # plaintext bearer
    headers: dict[str, str]


def mint_user(
    backend: StateBackend,
    *,
    name: str = "Test User",
    email: str = "",
    is_admin: bool = False,
    role: str | None = None,
    token_kind: str = "user",
    display_name: str = "",
) -> _MintedTeam:
    """Mint a user + token but NO team / membership / competition.

    For tests that exercise the new "OAuth login first, register for a
    comp later" flow. Returns a ``_MintedTeam`` for shape compatibility
    with ``mint_team``; the ``team_id`` field is empty.
    """
    if role is None:
        role = "admin" if is_admin else "user"
    user_id = str(uuid.uuid4())
    created_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    user = UserState(
        user_id=user_id,
        email=email,
        display_name=display_name or name,
        role=role,
        created_at=created_at,
    )
    backend.put_user(user_id, user)
    plaintext = f"{'pt_' if token_kind == 'user' else 'pa_'}{secrets.token_urlsafe(32)}"
    backend.put_token(
        TeamToken(
            token_id=secrets.token_urlsafe(12),
            user_id=user_id,
            token_hash=hash_token(plaintext),
            kind=token_kind,
            label="test",
            created_at=created_at,
        )
    )
    return _MintedTeam(
        team_id="",
        user_id=user_id,
        token=plaintext,
        headers={"Authorization": f"Bearer {plaintext}"},
    )


def mint_team(
    backend: StateBackend,
    *,
    name: str = "Test Team",
    email: str = "",
    is_admin: bool = False,
    role: str | None = None,
    token_kind: str = "user",
    display_name: str = "",
    competition_id: str = TEST_COMPETITION_ID,
    seed_competition: bool = True,
) -> _MintedTeam:
    """Insert a user + per-comp team + membership + matching token.

    Short-circuits the OAuth + register flow for tests that only need
    an authenticated identity registered for a competition. Each call
    creates a fresh team scoped to ``competition_id`` (default
    :data:`TEST_COMPETITION_ID`) so legacy "team is the user" tests
    keep working and per-comp tests can pin their own comp id.

    Privilege: pass ``role="user"|"admin"|"super_admin"`` to set the
    privilege tier on the user directly. The legacy ``is_admin=True``
    keyword maps to ``role="admin"``.
    """
    if role is None:
        role = "admin" if is_admin else "user"
    user_id = str(uuid.uuid4())
    team_id = str(uuid.uuid4())
    created_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    user = UserState(
        user_id=user_id,
        email=email,
        display_name=display_name or name,
        role=role,
        created_at=created_at,
    )
    backend.put_user(user_id, user)
    team = TeamState(
        team_id=team_id,
        name=name,
        description="",
        captain_user_id=user_id,
        created_at=created_at,
        competition_id=competition_id,
    )
    backend.put_team(team_id, team)
    backend.put_membership(
        TeamMembershipState(
            user_id=user_id,
            team_id=team_id,
            joined_at=created_at,
            competition_id=competition_id,
        )
    )
    # Make sure the competition row exists so ``/me``'s
    # competition_teams projection (which filters orphan rows pointing
    # at deleted competitions) actually surfaces this membership.
    # Tests that count competitions can pass ``seed_competition=False``
    # to keep their backend's competitions table empty.
    if (
        seed_competition
        and competition_id
        and backend.get_competition(competition_id) is None
    ):
        from ctfy.core.state.models import CompetitionState

        backend.put_competition(
            CompetitionState(
                competition_id=competition_id,
                title=competition_id,
                created_at=created_at,
            )
        )
    plaintext = f"{'pt_' if token_kind == 'user' else 'pa_'}{secrets.token_urlsafe(32)}"
    backend.put_token(
        TeamToken(
            token_id=secrets.token_urlsafe(12),
            user_id=user_id,
            token_hash=hash_token(plaintext),
            kind=token_kind,
            label="test",
            created_at=created_at,
        )
    )
    return _MintedTeam(
        team_id=team_id,
        user_id=user_id,
        token=plaintext,
        headers={"Authorization": f"Bearer {plaintext}"},
    )


@pytest.fixture
def mint_team_fixture(backend):
    def _mint(**kw):
        return mint_team(backend, **kw)

    return _mint


@pytest.fixture
def admin_team(backend):
    """A team with ``role="admin"`` — replacement for the old CTFY_ADMIN_TOKEN."""
    return mint_team(backend, name="Admin", email="admin@example.com", role="admin")


@pytest.fixture
def super_admin_team(backend):
    """A team with ``role="super_admin"`` — used to exercise admin-management routes."""
    return mint_team(
        backend,
        name="SuperAdmin",
        email="super@example.com",
        role="super_admin",
    )


# ---------------------------------------------------------------------------
# Fake OAuth provider — plugged into ``app.oauth_providers`` so tests that
# exercise the full login flow can do so without talking to GitHub/Google.
# ---------------------------------------------------------------------------


class FakeOAuthProvider:
    """Drop-in for :class:`ctfy.server.oauth.providers.OAuthProvider`.

    Tests register profiles keyed by ``code`` before calling
    ``/auth/callback`` — the fake's ``exchange_code`` returns the code
    as the access token and ``fetch_profile`` looks up the stored
    profile. ``authorize_url`` echoes the state back so the helper can
    extract it.
    """

    def __init__(self, name: str = "github") -> None:
        self.name = name
        self.profiles: dict[str, OAuthProfile] = {}

    def authorize_url(self, state: str, redirect_uri: str) -> str:
        return f"https://example.test/authorize?state={state}&redirect_uri={redirect_uri}"

    async def exchange_code(self, code: str, redirect_uri: str) -> str:
        if code not in self.profiles:
            raise RuntimeError(f"no profile staged for code={code!r}")
        return f"access_{code}"

    async def fetch_profile(self, access_token: str) -> OAuthProfile:
        code = access_token.removeprefix("access_")
        return self.profiles[code]


def install_fake_oauth(client: TestClient, providers: tuple[str, ...] = ("github", "google")):
    """Swap the live OAuth providers on the app for fakes. Returns the dict."""
    app_state = _app_state_from_client(client)
    fakes = {name: FakeOAuthProvider(name=name) for name in providers}
    app_state.oauth_providers = fakes
    return fakes


def _app_state_from_client(client: TestClient):
    """Fish AppState out of the TestClient — it's captured via closure by
    the routes; the easiest retrievable handle is ``.app.state`` plus the
    fact that our create_platform_app attaches auth deps as module globals
    inside the router. We rely on the same ``AppState`` object that routes
    reference by pulling it from a known dep attribute."""
    # The Limiter is attached at app.state.limiter; AppState.limiter points
    # at the same object, so we can reverse-lookup by scanning
    # `client.app.router.dependency_overrides_provider` — but FastAPI's
    # dependency wiring doesn't expose AppState directly. Simpler: every
    # route module's ``create_router`` closes over AppState; we instead
    # attach AppState to app.state explicitly at construction time.
    return client.app.state.ctfy


def register_team(
    client: TestClient,
    *,
    email: str,
    password: str = "pw-correct-horse-2",
    display_name: str = "",
) -> str:
    """POST /auth/register and return the plaintext user token.

    Parallels :func:`oauth_login` but for the local email+password flow.
    Fails fast on non-200 so tests get a useful assertion message.
    """
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "display_name": display_name},
    )
    assert resp.status_code == 200, resp.text
    return resp.json()["token"]


def password_login(
    client: TestClient,
    *,
    email: str,
    password: str,
) -> str:
    """POST /auth/login and return the plaintext user token."""
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": email, "password": password},
    )
    assert resp.status_code == 200, resp.text
    return resp.json()["token"]


def oauth_login(
    client: TestClient,
    provider: str,
    *,
    email: str = "alice@example.com",
    email_verified: bool = True,
    provider_user_id: str | None = None,
    provider_login: str = "",
    display_name: str = "Alice",
    avatar_url: str = "https://example.test/alice.png",
    headers: dict[str, str] | None = None,
) -> str:
    """Walk the full OAuth callback flow against a fake provider. Returns plaintext token.

    ``headers`` are forwarded to the callback request — useful for tests
    that exercise IP / User-Agent capture on ``_mint_user_token``.
    """
    fakes = getattr(client.app.state.ctfy, "oauth_providers", {})
    fake = fakes.get(provider)
    if not isinstance(fake, FakeOAuthProvider):
        fake = FakeOAuthProvider(name=provider)
        client.app.state.ctfy.oauth_providers[provider] = fake
    code = secrets.token_urlsafe(12)
    fake.profiles[code] = OAuthProfile(
        provider=provider,
        provider_user_id=provider_user_id or f"uid-{email}",
        provider_login=provider_login,
        email=email,
        email_verified=email_verified,
        display_name=display_name,
        avatar_url=avatar_url,
    )
    r = client.get(
        f"/api/v1/auth/login/{provider}?redirect_to=/",
        follow_redirects=False,
    )
    assert r.status_code == 302, r.text
    state = parse_qs(urlparse(r.headers["location"]).query)["state"][0]
    r = client.get(
        f"/api/v1/auth/callback/{provider}?code={code}&state={state}",
        follow_redirects=False,
        headers=headers,
    )
    assert r.status_code == 302, r.text
    frag = urlparse(r.headers["location"]).fragment
    return parse_qs(frag)["token"][0]


__all__ = [
    "FakeOAuthProvider",
    "install_fake_oauth",
    "mint_team",
    "oauth_login",
    "password_login",
    "register_team",
    "OAuthIdentity",
    "TeamState",
    "TeamToken",
]
