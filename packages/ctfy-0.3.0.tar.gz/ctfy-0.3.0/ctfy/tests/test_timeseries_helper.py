"""Unit tests for the shared timeseries helpers.

These functions back ``/admin/timeseries``,
``/admin/challenges/{id}/timeseries`` and ``/activities/timeseries``.
They're pure (no I/O, no clock reads), so the contract stays small and
fully testable without booting a FastAPI app.
"""

from __future__ import annotations

import pytest

from ctfy.server.timeseries import bucket_edges, bucketize


class TestBucketEdges:
    def test_rightmost_edge_equals_now_exactly(self):
        """The right edge is ``now`` — no snap-up to bucket boundaries.

        This is the core property: a chart titled "Last N seconds" must
        actually end at the moment of the request, not at the next
        clock-aligned boundary that may sit minutes in the future.
        """
        edges = bucket_edges(now=1700001800.0, window=3600, bucket=3600)
        assert edges[-1] == 1700001800.0

    def test_works_off_clock_alignment(self):
        """``now`` mid-bucket should still place the right edge at exactly
        ``now`` — the historical snap was the source of the timing-flaky
        admin tests."""
        edges = bucket_edges(now=1700001937.5, window=3600, bucket=3600)
        assert edges[-1] == 1700001937.5

    def test_window_3600_bucket_3600_yields_one_edge(self):
        edges = bucket_edges(now=1000.0, window=3600, bucket=3600)
        assert edges == [1000.0]

    def test_oldest_first_order_with_uniform_spacing(self):
        edges = bucket_edges(now=10000.0, window=14400, bucket=3600)
        # 4 buckets, each 3600s wide, oldest first.
        assert edges == [
            10000.0 - 3 * 3600,
            10000.0 - 2 * 3600,
            10000.0 - 3600,
            10000.0,
        ]

    def test_window_smaller_than_bucket_yields_at_least_one_edge(self):
        # Window=60, bucket=3600 → 60//3600 == 0 buckets, but a 0-bucket
        # response is useless to the frontend. Clamp to 1.
        edges = bucket_edges(now=5000.0, window=60, bucket=3600)
        assert edges == [5000.0]

    def test_zero_or_negative_bucket_rejected(self):
        with pytest.raises(ValueError):
            bucket_edges(now=1000.0, window=3600, bucket=0)
        with pytest.raises(ValueError):
            bucket_edges(now=1000.0, window=3600, bucket=-3600)


class TestBucketize:
    def test_timestamp_at_right_edge_lands_in_that_bucket(self):
        edges = [3600.0, 7200.0, 10800.0]
        # 7200 is the right edge of bucket 1 → lands there (inclusive on the right).
        counts = bucketize([7200.0], edges, bucket=3600)
        assert counts == [0, 1, 0]

    def test_timestamp_just_past_left_window_falls_into_first_bucket(self):
        edges = [3600.0, 7200.0]
        # Left edge of the window is 3600 - 3600 = 0; (0, 3600] = bucket 0.
        counts = bucketize([1.0, 3600.0], edges, bucket=3600)
        assert counts == [2, 0]

    def test_timestamp_at_or_before_left_edge_dropped(self):
        edges = [3600.0, 7200.0]
        # ``ts == start`` is the half-open exclusion: bucket window is
        # ``(start, edges[-1]]``, so a stamp on the boundary is excluded.
        counts = bucketize([0.0, -100.0], edges, bucket=3600)
        assert counts == [0, 0]

    def test_timestamp_after_rightmost_dropped(self):
        edges = [3600.0, 7200.0]
        counts = bucketize([7201.0, 99999.0], edges, bucket=3600)
        assert counts == [0, 0]

    def test_empty_inputs(self):
        assert bucketize([], [3600.0], bucket=3600) == [0]
        assert bucketize([100.0], [], bucket=3600) == []
