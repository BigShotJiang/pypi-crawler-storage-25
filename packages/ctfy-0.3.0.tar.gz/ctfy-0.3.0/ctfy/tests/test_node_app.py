"""Tests for ``ctfy.server.node_app`` module-level helpers.

Focus: the ``_resolve_public_host`` guardrail that replaces the old
``_default_public_host`` best-effort. On a single-NIC host we still
auto-resolve; anything ambiguous (zero or multiple non-loopback IPs)
must raise so the operator is forced to set ``CTFY_NODE_PUBLIC_URL``
instead of silently registering an unreachable address.
"""

from __future__ import annotations

import pytest

from ctfy.core.exceptions import ConfigError
from ctfy.server import node_app


class TestResolvePublicHost:
    def test_single_non_loopback_interface_succeeds(self, monkeypatch):
        monkeypatch.setattr(node_app, "_non_loopback_ipv4_addresses", lambda: ["10.0.0.5"])
        assert node_app._resolve_public_host() == "10.0.0.5"

    def test_multiple_interfaces_raise_configerror(self, monkeypatch):
        monkeypatch.setattr(
            node_app,
            "_non_loopback_ipv4_addresses",
            lambda: ["10.0.0.5", "192.168.1.12"],
        )
        with pytest.raises(ConfigError, match="CTFY_NODE_PUBLIC_URL"):
            node_app._resolve_public_host()

    def test_no_interfaces_raise_configerror(self, monkeypatch):
        """Containers where `gethostname()` only resolves to 127.0.0.1 would
        previously have silently registered 127.0.0.1 as the public URL. Now
        they must fail loud."""
        monkeypatch.setattr(node_app, "_non_loopback_ipv4_addresses", lambda: [])
        with pytest.raises(ConfigError, match="CTFY_NODE_PUBLIC_URL"):
            node_app._resolve_public_host()

    def test_error_message_lists_detected_addresses(self, monkeypatch):
        """So the operator knows which interface they probably want."""
        monkeypatch.setattr(
            node_app,
            "_non_loopback_ipv4_addresses",
            lambda: ["10.0.0.5", "192.168.1.12"],
        )
        with pytest.raises(ConfigError) as exc:
            node_app._resolve_public_host()
        assert "10.0.0.5" in str(exc.value)
        assert "192.168.1.12" in str(exc.value)


class TestNonLoopbackIpv4Addresses:
    def test_loopback_excluded(self, monkeypatch):
        """127.0.0.0/8 entries returned by the resolver must be stripped so a
        hostname that only resolves to loopback (common inside containers)
        yields an empty list, triggering the guardrail above."""
        fake_infos = [
            (None, None, None, None, ("127.0.0.1", 0)),
            (None, None, None, None, ("10.0.0.5", 0)),
            (None, None, None, None, ("127.1.2.3", 0)),
        ]
        import socket as _socket

        monkeypatch.setattr(node_app.socket, "getaddrinfo", lambda *a, **kw: fake_infos)
        monkeypatch.setattr(node_app.socket, "gethostname", lambda: "host")
        # Keep AF_INET reference reachable through the module under test.
        assert node_app.socket.AF_INET == _socket.AF_INET
        assert node_app._non_loopback_ipv4_addresses() == ["10.0.0.5"]

    def test_duplicates_collapsed(self, monkeypatch):
        fake_infos = [
            (None, None, None, None, ("10.0.0.5", 0)),
            (None, None, None, None, ("10.0.0.5", 80)),
        ]
        monkeypatch.setattr(node_app.socket, "getaddrinfo", lambda *a, **kw: fake_infos)
        monkeypatch.setattr(node_app.socket, "gethostname", lambda: "host")
        assert node_app._non_loopback_ipv4_addresses() == ["10.0.0.5"]

    def test_resolver_failure_returns_empty(self, monkeypatch):
        def _boom(*a, **kw):
            raise OSError("resolver offline")

        monkeypatch.setattr(node_app.socket, "getaddrinfo", _boom)
        assert node_app._non_loopback_ipv4_addresses() == []


class TestAutoCapacity:
    """``auto_capacity`` derives a per-node default from CPU + RAM.

    These tests stub psutil so the result is deterministic across CI
    machines (a 4-core / 8 GB CI runner would land on the same number
    every time, but a developer's 16-core box would see different
    output, which is the whole point of the helper).
    """

    def _fake_psutil(self, *, cpu_count: int, mem_bytes: int):
        class _VM:
            total = mem_bytes

        class _Fake:
            @staticmethod
            def cpu_count(logical=True):
                return cpu_count

            @staticmethod
            def virtual_memory():
                return _VM()

        return _Fake

    def test_cpu_bound_when_memory_is_plentiful(self, monkeypatch):
        """4 cores * 2 + 64 GB RAM → CPU is the binding constraint."""
        fake = self._fake_psutil(cpu_count=4, mem_bytes=64 * 1024**3)
        monkeypatch.setitem(__import__("sys").modules, "psutil", fake)
        # 4 * NODE_CPU_PER_INSTANCE(=2) = 8 ; mem_gb / 1.0 = 64 → min = 8
        assert node_app.auto_capacity() == 8

    def test_memory_bound_when_cpu_is_plentiful(self, monkeypatch):
        """64 cores + 4 GB RAM → memory is the binding constraint."""
        fake = self._fake_psutil(cpu_count=64, mem_bytes=4 * 1024**3)
        monkeypatch.setitem(__import__("sys").modules, "psutil", fake)
        # 64 * 2 = 128 ; 4 / 1 = 4 → min = 4
        assert node_app.auto_capacity() == 4

    def test_floor_at_one(self, monkeypatch):
        """A tiny VM (1 core, 256 MB) still gets at least 1 slot — 0 would be
        indistinguishable from 'unconfigured', and a tiny node serving one
        instance is more useful than a node serving none."""
        fake = self._fake_psutil(cpu_count=1, mem_bytes=256 * 1024**2)
        monkeypatch.setitem(__import__("sys").modules, "psutil", fake)
        assert node_app.auto_capacity() == 1

    def test_psutil_failure_falls_back_to_default(self, monkeypatch):
        """If psutil isn't available or its probes raise, we don't want to
        prevent the node from starting — fall back to the static
        platform-wide default."""
        from ctfy.core.constants import DEFAULT_NODE_CAPACITY

        class _Boom:
            @staticmethod
            def cpu_count(logical=True):
                raise RuntimeError("/proc unreadable")

            @staticmethod
            def virtual_memory():
                raise RuntimeError("/proc unreadable")

        monkeypatch.setitem(__import__("sys").modules, "psutil", _Boom)
        assert node_app.auto_capacity() == DEFAULT_NODE_CAPACITY
