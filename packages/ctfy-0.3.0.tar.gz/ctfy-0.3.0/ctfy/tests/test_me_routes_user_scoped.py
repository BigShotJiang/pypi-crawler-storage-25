"""Phase 1.C.2: ``/me/solves``, ``/submissions``, and ``/activities``
are user-scoped, not team-scoped.

Pre-refactor every "my X" endpoint depended on the legacy default-slot
"current team" lookup via ``get_current_team``. After the user-team
split a single user can be on different per-comp teams across
multiple competitions, so "my solves" / "my submissions" / "my
activity" mean "every row attributed to me as a user", aggregated
across every team I've ever been on.

Concretely: the endpoints filter by the SolveState / SubmissionState
/ ActivityState ``user_id`` (or ``actor_id``) field, not by
``team_id``.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import (
    ActivityState,
    SolveState,
    SubmissionState,
)
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team


@pytest.fixture
def world():
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    yield TestClient(app), backend


class TestMeSolvesUserScoped:
    """``GET /me/solves`` returns rows where ``solve.user_id == me``,
    not rows where ``solve.team_id == my_current_team``. Catches the
    case where a user moves teams between competitions: their solves
    on the old team must still show up in their personal /me/solves.
    """

    def test_includes_solves_made_on_a_team_the_user_left(self, world):
        client, backend = world
        alice = mint_team(backend, name="AliceTeam")
        old_team_id = "team-from-spring-ctf"
        # Solve stamped against a team the user no longer belongs to —
        # but ``solve.user_id`` is alice's, so it counts as her solve.
        backend.add_solve(
            old_team_id,
            "WEB-001",
            "main",
            SolveState(
                team_id=old_team_id,
                user_id=alice.user_id,
                challenge_id="WEB-001",
                flag_id="main",
                solved_at="2026-04-01T10:00:00Z",
            ),
        )
        # And another solve attributed to a *different* user on alice's
        # current team — this one must NOT show in alice's /me/solves
        # despite being on her current team.
        backend.add_solve(
            alice.team_id,
            "WEB-002",
            "main",
            SolveState(
                team_id=alice.team_id,
                user_id="different-user",
                challenge_id="WEB-002",
                flag_id="main",
                solved_at="2026-04-02T10:00:00Z",
            ),
        )
        rows = client.get("/api/v1/me/solves", headers=alice.headers).json()
        challenge_ids = {r["challenge_id"] for r in rows}
        assert "WEB-001" in challenge_ids, rows
        assert "WEB-002" not in challenge_ids, rows


class TestSubmissionsListingUserScoped:
    """``GET /submissions`` returns rows where ``submission.user_id == me``.
    Same rationale as /me/solves — survives team moves and excludes
    other users' submissions on a shared team.
    """

    def test_returns_my_submissions_across_all_teams(self, world):
        client, backend = world
        alice = mint_team(backend, name="AliceTeam")
        backend.add_submission(
            SubmissionState(
                submission_id="sub-1",
                team_id="some-old-team",
                user_id=alice.user_id,
                challenge_id="WEB-001",
                claimed_flag="x",
                correct=False,
                submitted_at="2026-04-01T10:00:00Z",
            )
        )
        backend.add_submission(
            SubmissionState(
                submission_id="sub-2",
                team_id=alice.team_id,
                user_id="different-user",
                challenge_id="WEB-002",
                claimed_flag="y",
                correct=False,
                submitted_at="2026-04-02T10:00:00Z",
            )
        )
        body = client.get("/api/v1/submissions", headers=alice.headers).json()
        ids = {r["submission_id"] for r in body["items"]}
        assert "sub-1" in ids, body
        assert "sub-2" not in ids, body


class TestActivitiesListingUserScoped:
    """``GET /activities`` returns rows where ``activity.actor_id == me``.
    The activity log already had an ``actor_id`` filter; we just stop
    forcing the team_id filter to be the caller's current team.
    """

    def test_returns_activities_actored_by_me_regardless_of_team(self, world):
        client, backend = world
        alice = mint_team(backend, name="AliceTeam")
        # Activity by alice on an old team — should be in her feed.
        backend.add_activity(
            ActivityState(
                timestamp="2026-04-01T10:00:00Z",
                event="flag_correct",
                team_id="some-old-team",
                team_name="Old",
                challenge_id="WEB-001",
                user_id=alice.user_id,
                actor_id=alice.user_id,
                actor_name="Alice",
                actor_type="team",
            )
        )
        # Activity by another user on alice's current team — must NOT
        # appear in her personal feed.
        backend.add_activity(
            ActivityState(
                timestamp="2026-04-02T10:00:00Z",
                event="flag_correct",
                team_id=alice.team_id,
                team_name="AliceTeam",
                challenge_id="WEB-002",
                user_id="different-user",
                actor_id="different-user",
                actor_name="Bob",
                actor_type="team",
            )
        )
        body = client.get("/api/v1/activities", headers=alice.headers).json()
        challenge_ids = {a["challenge_id"] for a in body["items"]}
        assert "WEB-001" in challenge_ids, body
        assert "WEB-002" not in challenge_ids, body
