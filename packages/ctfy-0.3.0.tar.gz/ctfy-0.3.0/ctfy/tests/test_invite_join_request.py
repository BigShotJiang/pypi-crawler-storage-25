"""TDD: member → captain join request flow.

Members who don't have a code can discover existing teams and ask
to join. The captain sees the request in their inbox (Branch #6)
and approves or rejects. Pins four endpoints:

* ``GET  /competitions/{id}/teams/search?q=<name|id>``
* ``POST /competitions/{id}/teams/{team_id}/join-request``
* ``POST /competitions/{id}/invites/{invite_id}/approve``
* ``POST /competitions/{id}/invites/{invite_id}/reject``
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import CompetitionState
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team


@pytest.fixture
def world():
    """Captain ``cap`` of team ``Pwners`` in comp ``spring``;
    aspirant ``alice`` (no team for this comp); bystander ``bob``.
    """
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    backend.put_competition(
        CompetitionState(
            competition_id="spring",
            title="Spring CTF 2026",
            starts_at="",
            ends_at="2099-01-01T00:00:00Z",
            challenge_ids=[],
            created_at="2026-01-01T00:00:00Z",
        )
    )
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)

    cap = mint_team(backend, name="Cap", email="cap@x", display_name="Cap")
    pwners = backend.create_team_for_competition(
        user_id=cap.user_id,
        competition_id="spring",
        team_name="Pwners",
        description="elite squad",
        now_iso="2026-01-01T00:00:00Z",
        joined_via="create",
    )
    # A second team so the search has more than one row to filter.
    other_cap = mint_team(
        backend, name="OtherCap", email="oc@x", display_name="OC"
    )
    backend.create_team_for_competition(
        user_id=other_cap.user_id,
        competition_id="spring",
        team_name="Goonies",
        description="",
        now_iso="2026-01-01T00:00:00Z",
        joined_via="create",
    )
    alice = mint_team(
        backend, name="Alice", email="alice@x", display_name="Alice"
    )
    bob = mint_team(backend, name="Bob", email="bob@x", display_name="Bob")
    return {
        "client": TestClient(app),
        "backend": backend,
        "cap": cap,
        "alice": alice,
        "bob": bob,
        "team_id": pwners.team_id,
    }


# ---- search ---------------------------------------------------------------


class TestSearchTeams:
    def test_substring_match_on_name_case_insensitive(self, world):
        r = world["client"].get(
            "/api/v1/competitions/spring/teams/search?q=pwn",
            headers=world["alice"].headers,
        )
        assert r.status_code == 200, r.text
        body = r.json()
        names = {row["name"] for row in body["items"]}
        assert "Pwners" in names
        assert "Goonies" not in names

    def test_exact_team_id_match(self, world):
        r = world["client"].get(
            f"/api/v1/competitions/spring/teams/search?q={world['team_id']}",
            headers=world["alice"].headers,
        )
        assert r.status_code == 200
        items = r.json()["items"]
        assert len(items) == 1
        assert items[0]["team_id"] == world["team_id"]

    def test_blank_query_returns_no_results(self, world):
        # Surface-area control — a blank ``q`` must NOT enumerate
        # every team in the comp; force the user to type something.
        r = world["client"].get(
            "/api/v1/competitions/spring/teams/search?q=",
            headers=world["alice"].headers,
        )
        assert r.status_code == 200
        assert r.json()["items"] == []

    def test_unauth_rejected(self, world):
        r = world["client"].get(
            "/api/v1/competitions/spring/teams/search?q=pwn"
        )
        assert r.status_code in (401, 403)


# ---- open join request ----------------------------------------------------


class TestOpenJoinRequest:
    def test_member_can_request_to_join(self, world):
        r = world["client"].post(
            f"/api/v1/competitions/spring/teams/{world['team_id']}/join-request",
            headers=world["alice"].headers,
        )
        assert r.status_code == 201, r.text
        body = r.json()
        assert body["kind"] == "join_request"
        assert body["created_by_user_id"] == world["alice"].user_id
        assert body["team_id"] == world["team_id"]

    def test_unknown_team_returns_404(self, world):
        r = world["client"].post(
            "/api/v1/competitions/spring/teams/no-such-team/join-request",
            headers=world["alice"].headers,
        )
        assert r.status_code == 404

    def test_already_on_team_for_comp_returns_409(self, world):
        # Alice solo-registers first, then tries to request another
        # team's join — should be rejected (one team per comp).
        world["backend"].create_team_for_competition(
            user_id=world["alice"].user_id,
            competition_id="spring",
            team_name="Alice's solo",
            description="",
            now_iso="2026-01-01T00:00:00Z",
            joined_via="solo",
        )
        r = world["client"].post(
            f"/api/v1/competitions/spring/teams/{world['team_id']}/join-request",
            headers=world["alice"].headers,
        )
        assert r.status_code == 409
        assert r.json()["detail"]["error"] == "already_on_team"

    def test_duplicate_pending_request_returns_409(self, world):
        first = world["client"].post(
            f"/api/v1/competitions/spring/teams/{world['team_id']}/join-request",
            headers=world["alice"].headers,
        )
        assert first.status_code == 201
        second = world["client"].post(
            f"/api/v1/competitions/spring/teams/{world['team_id']}/join-request",
            headers=world["alice"].headers,
        )
        assert second.status_code == 409
        assert second.json()["detail"]["error"] == "request_already_pending"


# ---- approve --------------------------------------------------------------


class TestApproveJoinRequest:
    def _open(self, world) -> str:
        r = world["client"].post(
            f"/api/v1/competitions/spring/teams/{world['team_id']}/join-request",
            headers=world["alice"].headers,
        )
        assert r.status_code == 201, r.text
        return r.json()["invite_id"]

    def test_captain_approves_requester_joins(self, world):
        invite_id = self._open(world)
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/approve",
            headers=world["cap"].headers,
        )
        assert r.status_code == 200, r.text
        m = world["backend"].get_membership_for_competition(
            world["alice"].user_id, "spring"
        )
        assert m is not None
        assert m.team_id == world["team_id"]
        assert m.joined_via == "join_request_approved"
        assert m.invited_by_user_id == world["cap"].user_id

    def test_non_captain_cannot_approve(self, world):
        invite_id = self._open(world)
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/approve",
            headers=world["bob"].headers,
        )
        assert r.status_code == 403

    def test_approving_a_code_invite_via_request_path_is_409(self, world):
        # Mint a regular code-style invite; trying to approve it via
        # the join_request approve route must reject it.
        mint = world["client"].post(
            "/api/v1/competitions/spring/invites",
            json={"max_uses": 1, "ttl_seconds": 3600},
            headers=world["cap"].headers,
        )
        invite_id = mint.json()["invite_id"]
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/approve",
            headers=world["cap"].headers,
        )
        assert r.status_code == 409
        assert r.json()["detail"]["error"] == "wrong_invite_kind"

    def test_approve_after_requester_joined_elsewhere_409(self, world):
        invite_id = self._open(world)
        # Alice solo-registers between request and approve.
        world["backend"].create_team_for_competition(
            user_id=world["alice"].user_id,
            competition_id="spring",
            team_name="Other",
            description="",
            now_iso="2026-01-01T00:00:00Z",
            joined_via="solo",
        )
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/approve",
            headers=world["cap"].headers,
        )
        assert r.status_code == 409
        assert r.json()["detail"]["error"] == "already_member"


# ---- reject ---------------------------------------------------------------


class TestRejectJoinRequest:
    def _open(self, world) -> str:
        r = world["client"].post(
            f"/api/v1/competitions/spring/teams/{world['team_id']}/join-request",
            headers=world["alice"].headers,
        )
        return r.json()["invite_id"]

    def test_captain_rejects_marks_revoked(self, world):
        invite_id = self._open(world)
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/reject",
            headers=world["cap"].headers,
        )
        assert r.status_code == 200
        inv = world["backend"].get_team_invite(invite_id)
        assert inv is not None and inv.revoked_at

    def test_non_captain_cannot_reject(self, world):
        invite_id = self._open(world)
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/reject",
            headers=world["bob"].headers,
        )
        assert r.status_code == 403
