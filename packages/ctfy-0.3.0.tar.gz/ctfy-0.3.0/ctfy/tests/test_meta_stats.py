"""Verify the synthetic ``meta_stats`` SSE frame is derived after every
write that mutates a /meta counter, and that the frame is admin-only
on the wire.

The point of this signal is to let the admin StatusBar drop its 60s
``/meta`` poll and 30s ``/admin/overview`` poll — the SSE frame
carries the same numbers directly. Tests pin two contracts:

1. ``emit_meta_stats`` snapshots the cluster counters and broadcasts
   the frame ``admin_only=True`` (members never receive it).
2. The selected ``META_AFFECTING_EVENTS`` are the only events that
   trigger a derived frame from inside :func:`emit_event`. Renews,
   ready transitions, wrong flags, and achievement unlocks must not
   produce spurious frames.
"""

from __future__ import annotations

import time
from unittest.mock import MagicMock

from ctfy.core.enums import PlatformEvent
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import NodeState, TeamState
from ctfy.server.app_state import AppState
from ctfy.server.event_payloads import (
    AchievementUnlockedPayload,
    FlagCorrectPayload,
    FlagWrongPayload,
    InstanceReadyPayload,
    InstanceRenewedPayload,
    InstanceStartedPayload,
    InstanceStoppedPayload,
    NodeRegisteredPayload,
    NodeRemovedPayload,
    NodeUnhealthyPayload,
    NodeUpdatedPayload,
    TeamRegisteredPayload,
)
from ctfy.server.events import emit_event
from ctfy.server.meta_stats import META_AFFECTING_EVENTS, emit_meta_stats
from ctfy.server.sse import SSEHub


def _make_app() -> AppState:
    """Minimal AppState with a real in-memory backend + real SSE hub.

    Routes / lifecycle are out of scope here — we drive ``emit_event``
    directly so the test stays focused on the broadcast contract.
    """
    backend = InMemoryBackend()
    spec_reader = MagicMock()
    spec_reader.iter_specs.return_value = iter([])
    return AppState(
        config=MagicMock(),
        state_backend=backend,
        spec_reader=spec_reader,
        sse_hub=SSEHub(),
        host="x",
        max_instances=10,
    )


def _meta_calls(spy):
    return [c for c in spy.call_args_list if c.args[0] == PlatformEvent.META_STATS.value]


# ---------------------------------------------------------------------------
# emit_meta_stats: shape + admin_only contract
# ---------------------------------------------------------------------------


def test_emit_meta_stats_broadcasts_admin_only():
    app = _make_app()
    app.sse_hub.broadcast = MagicMock()
    emit_meta_stats(app)
    app.sse_hub.broadcast.assert_called_once()
    args, kwargs = app.sse_hub.broadcast.call_args
    assert args[0] == "meta_stats"
    assert kwargs["admin_only"] is True
    # Cluster numbers go to every admin team (no per-team gate).
    assert kwargs["team_id"] == ""


def test_emit_meta_stats_payload_carries_all_counters():
    app = _make_app()
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_meta_stats(app)
    data = spy.call_args.kwargs["data"]
    for k in (
        "teams_total",
        "nodes_total",
        "nodes_healthy",
        "running_instances",
        "solves_total",
        "challenges_total",
    ):
        assert isinstance(data[k], int), f"expected int for {k}, got {data[k]!r}"


def test_emit_meta_stats_counts_only_healthy_nodes():
    """``nodes_healthy`` should match the rule used by /meta — heartbeat
    fresher than HEARTBEAT_TIMEOUT. A stale or zero-heartbeat node
    counts toward ``nodes_total`` but not ``nodes_healthy``."""
    app = _make_app()
    now = time.time()
    app.state_backend.put_node(
        "fresh", NodeState(node_id="fresh", url="x", capacity=1, last_heartbeat_ts=now)
    )
    app.state_backend.put_node(
        "stale", NodeState(node_id="stale", url="y", capacity=1, last_heartbeat_ts=now - 1000)
    )
    app.state_backend.put_node(
        "never", NodeState(node_id="never", url="z", capacity=1, last_heartbeat_ts=0.0)
    )
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_meta_stats(app)
    data = spy.call_args.kwargs["data"]
    assert data["nodes_total"] == 3
    assert data["nodes_healthy"] == 1


# ---------------------------------------------------------------------------
# emit_event hook: which events trigger meta_stats?
# ---------------------------------------------------------------------------


def _emit_with_spy(payload, *, app=None):
    app = app or _make_app()
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_event(
        app,
        payload,
        actor_id=payload.team_id or "system",
        actor_name=payload.team_name or "system",
        actor_type="team" if payload.team_id else "system",
    )
    return spy


def test_instance_started_triggers_meta_stats():
    spy = _emit_with_spy(
        InstanceStartedPayload(
            team_id="t1",
            team_name="T",
            challenge_id="C",
            instance_id="i1",
            node_id="n1",
        )
    )
    assert len(_meta_calls(spy)) == 1
    assert _meta_calls(spy)[0].kwargs["admin_only"] is True


def test_instance_stopped_triggers_meta_stats():
    spy = _emit_with_spy(
        InstanceStoppedPayload(
            team_id="t1",
            team_name="T",
            challenge_id="C",
            instance_id="i1",
            node_id="n1",
        )
    )
    assert len(_meta_calls(spy)) == 1


def test_team_registered_triggers_meta_stats():
    spy = _emit_with_spy(
        TeamRegisteredPayload(team_id="t1", team_name="T", challenge_id="")
    )
    assert len(_meta_calls(spy)) == 1


def test_node_lifecycle_triggers_meta_stats():
    """Each of register / unhealthy / remove changes nodes_total or
    nodes_healthy, so each should produce one frame."""
    for payload in (
        NodeRegisteredPayload(node_id="n1", url="http://x"),
        NodeUnhealthyPayload(node_id="n1"),
        NodeRemovedPayload(node_id="n1"),
    ):
        spy = _emit_with_spy(payload)
        assert len(_meta_calls(spy)) == 1, f"missing meta_stats for {payload!r}"


def test_flag_correct_triggers_meta_stats():
    spy = _emit_with_spy(
        FlagCorrectPayload(
            team_id="t1",
            team_name="T",
            challenge_id="C",
            instance_id="i1",
            solve_time_s=12.5,
            flag_id="main",
            challenge_fully_solved=True,
        )
    )
    assert len(_meta_calls(spy)) == 1


def test_renew_does_not_trigger_meta_stats():
    """Renew doesn't change running_instances (the row exists from
    STARTED through STOPPED) so emitting meta_stats here would just
    waste an admin frame."""
    spy = _emit_with_spy(
        InstanceRenewedPayload(
            team_id="t1",
            team_name="T",
            challenge_id="C",
            instance_id="i1",
            ttl=300,
        )
    )
    assert _meta_calls(spy) == []


def test_ready_does_not_trigger_meta_stats():
    spy = _emit_with_spy(
        InstanceReadyPayload(
            team_id="t1",
            team_name="T",
            challenge_id="C",
            instance_id="i1",
            node_id="n1",
        )
    )
    assert _meta_calls(spy) == []


def test_flag_wrong_does_not_trigger_meta_stats():
    spy = _emit_with_spy(
        FlagWrongPayload(
            team_id="t1",
            team_name="T",
            challenge_id="C",
            instance_id="i1",
            solve_time_s=4.2,
        )
    )
    assert _meta_calls(spy) == []


def test_achievement_unlocked_does_not_trigger_meta_stats():
    """Achievement unlocks aren't surfaced on /meta. Including this in
    the affecting set would also recurse through emit_event's own
    achievement evaluator."""
    spy = _emit_with_spy(
        AchievementUnlockedPayload(
            team_id="t1",
            team_name="T",
            challenge_id="",
            achievement_id="decathlete",
        )
    )
    assert _meta_calls(spy) == []


def test_node_updated_does_not_trigger_meta_stats():
    """Renaming / re-labeling a node changes neither nodes_total nor
    nodes_healthy."""
    spy = _emit_with_spy(NodeUpdatedPayload(node_id="n1", display_name="renamed"))
    assert _meta_calls(spy) == []


def test_meta_stats_event_not_in_affecting_set():
    """Sanity: META_STATS itself must not be in the trigger set —
    otherwise emit_event would recurse forever the moment something
    upstream broadcasts it directly."""
    assert PlatformEvent.META_STATS.value not in META_AFFECTING_EVENTS


# ---------------------------------------------------------------------------
# Integration: an admin SSE client receives the frame, a member doesn't.
# ---------------------------------------------------------------------------


def test_admin_client_receives_meta_stats_member_does_not():
    """End-to-end through the real hub: a write that triggers a
    meta_stats emit reaches admin queues and skips member queues."""
    import asyncio

    async def go():
        app = _make_app()
        # Pre-seed a team so emit_event's add_activity has something
        # to bind to (envelope columns aren't FK-checked here, this is
        # just defence against backend invariants drifting later).
        app.state_backend.put_team(
            "t1",
            TeamState(team_id="t1", name="T", created_at="2025-01-01T00:00:00Z"),
        )
        app.sse_hub.set_loop(asyncio.get_running_loop())
        # Connect both clients with the same team_id as the triggering
        # event so the team-filter doesn't mask the admin_only check
        # we actually care about.
        _, member_q = app.sse_hub.connect(team_ids=frozenset({"t1"}), is_admin=False)
        _, admin_q = app.sse_hub.connect(team_ids=frozenset({"t1"}), is_admin=True)

        emit_event(
            app,
            InstanceStartedPayload(
                team_id="t1",
                team_name="T",
                challenge_id="C",
                instance_id="i1",
                node_id="n1",
            ),
            actor_id="t1",
            actor_name="T",
            actor_type="team",
        )

        # Drain the admin queue until we see a meta_stats frame.
        # instance_started arrives first; meta_stats follows.
        seen_meta = False
        for _ in range(5):
            frame = await asyncio.wait_for(admin_q.get(), timeout=1)
            if "event: meta_stats" in frame:
                seen_meta = True
                break
        assert seen_meta, "admin queue never received meta_stats"

        # Member sees instance_started (not admin_only) but not the
        # derivative meta_stats frame.
        member_events: list[str] = []
        try:
            while True:
                frame = await asyncio.wait_for(member_q.get(), timeout=0.2)
                member_events.append(frame)
        except asyncio.TimeoutError:
            pass
        assert any("event: instance_started" in f for f in member_events)
        assert not any("event: meta_stats" in f for f in member_events), (
            "member must not receive admin_only meta_stats"
        )

    asyncio.run(go())
