"""Tests for ``GET /admin/challenges/stats`` — per-challenge launch /
solve / error aggregates that drive the admin Challenges dashboard.

The endpoint must return one row per defined spec so admins can spot
challenges with no data at all (potential metadata bugs) right beside
problem rows with high error rates.
"""

from __future__ import annotations

import time
from unittest.mock import patch

from fastapi.testclient import TestClient

from ctfy.core.enums import InstanceStatus
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import InstanceRecord, InstanceState, SolveState
from ctfy.tests.conftest import mint_team


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _bootstrap(env_manager):
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)
    return app, backend, admin


def _archive_record(
    backend,
    *,
    instance_id: str,
    challenge_id: str = "E1",
    team_id: str = "t1",
    stop_reason: str = "user",
    status: str = InstanceStatus.STOPPED,
    requested_at: float = 0.0,
    ready_at: float = 0.0,
    error: str = "",
    stopped_at: float | None = None,
):
    rec = InstanceRecord(
        instance_id=instance_id,
        challenge_id=challenge_id,
        team_id=team_id,
        node_id="n1",
        status=status,
        stop_reason=stop_reason,
        requested_at=requested_at,
        ready_at=ready_at,
        started_at=ready_at or requested_at,
        stopped_at=stopped_at if stopped_at is not None else (ready_at + 1.0 if ready_at else requested_at + 1.0),
        error=error,
    )
    backend.archive_instance(rec)


def _put_solve(backend, *, team_id: str, challenge_id: str, flag_id: str = "main"):
    backend.add_solve(
        team_id,
        challenge_id,
        flag_id,
        SolveState(
            team_id=team_id,
            challenge_id=challenge_id,
            flag_id=flag_id,
            solved_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            solve_time_s=1.0,
            attempts=1,
        ),
    )


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


def test_challenges_stats_requires_admin(mock_env_manager):
    app, _, _ = _bootstrap(mock_env_manager)
    c = TestClient(app)
    assert c.get("/api/v1/admin/challenges/stats").status_code in (401, 403)


def test_challenges_stats_403_for_non_admin_user(mock_env_manager):
    app, backend, _ = _bootstrap(mock_env_manager)
    c = TestClient(app)
    user = mint_team(backend, name="u", email="u@example.test", is_admin=False)
    r = c.get("/api/v1/admin/challenges/stats", headers=user.headers)
    assert r.status_code == 403


# ---------------------------------------------------------------------------
# Empty state — every spec returned with zero metrics
# ---------------------------------------------------------------------------


def test_empty_state_returns_one_row_per_spec(mock_env_manager):
    app, _, admin = _bootstrap(mock_env_manager)
    c = TestClient(app)
    r = c.get("/api/v1/admin/challenges/stats", headers=admin.headers)
    assert r.status_code == 200, r.text
    body = r.json()
    assert isinstance(body, dict)
    items = body["items"]
    challenge_ids = {row["challenge_id"] for row in items}
    # mock_env_manager exposes WEB-001/WEB-002/E1/E2/RATE-001/AS-001
    assert {"WEB-001", "WEB-002", "E1", "E2"} <= challenge_ids
    sample = next(row for row in items if row["challenge_id"] == "E1")
    assert sample["launches"] == 0
    assert sample["errors"] == 0
    assert sample["error_rate"] == 0.0
    assert sample["p50_launch_s"] == 0.0
    assert sample["p95_launch_s"] == 0.0
    assert sample["solve_rate"] == 0.0
    assert sample["running_count"] == 0
    assert sample["last_error"] is None
    assert sample["recent_launch_durations"] == []


# ---------------------------------------------------------------------------
# Aggregation math
# ---------------------------------------------------------------------------


def test_error_rate_and_last_error(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager)
    # 1 success + 3 errors = error_rate 0.75
    _archive_record(backend, instance_id="ok", challenge_id="E1",
                    requested_at=1000.0, ready_at=1002.0)
    _archive_record(backend, instance_id="err1", challenge_id="E1",
                    stop_reason="error", error="boom1",
                    requested_at=1100.0, stopped_at=1105.0)
    _archive_record(backend, instance_id="err2", challenge_id="E1",
                    stop_reason="error", error="boom2",
                    requested_at=1200.0, stopped_at=1205.0)
    _archive_record(backend, instance_id="err3", challenge_id="E1",
                    stop_reason="error", error="latest_boom",
                    requested_at=1300.0, stopped_at=1310.0)

    c = TestClient(app)
    r = c.get("/api/v1/admin/challenges/stats", headers=admin.headers)
    row = next(x for x in r.json()["items"] if x["challenge_id"] == "E1")
    assert row["launches"] == 4
    assert row["errors"] == 3
    assert abs(row["error_rate"] - 0.75) < 1e-6
    # Most-recent error wins (highest stopped_at).
    assert row["last_error"] is not None
    assert row["last_error"]["message"] == "latest_boom"
    assert row["last_error"]["instance_id"] == "err3"


def test_p50_and_p95_over_successful_launches_only(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager)
    # Successful durations: 1, 2, 3, 4, 5, 6, 7, 8, 9, 100 seconds.
    # p50 = 5.5 (between index 4 and 5 → linear interp would be 5.5; we
    # accept either nearest-rank 5/6 or linear 5.5). p95 over 10 items
    # nearest-rank = 100 (or close to it).
    durations = [1, 2, 3, 4, 5, 6, 7, 8, 9, 100]
    for i, d in enumerate(durations):
        _archive_record(
            backend, instance_id=f"s{i}", challenge_id="E2",
            requested_at=1000.0 + i, ready_at=1000.0 + i + d,
        )
    # An error row that should NOT contribute to launch-duration math.
    _archive_record(
        backend, instance_id="e0", challenge_id="E2",
        stop_reason="error", error="x",
        requested_at=999.0,
    )
    c = TestClient(app)
    r = c.get("/api/v1/admin/challenges/stats", headers=admin.headers)
    row = next(x for x in r.json()["items"] if x["challenge_id"] == "E2")
    assert row["launches"] == 11
    assert row["errors"] == 1
    # Median between 5 and 6.
    assert 5.0 <= row["p50_launch_s"] <= 6.0
    # The 100-second outlier dominates the high quantile.
    assert row["p95_launch_s"] >= 9.0
    # avg = (1+...+9+100)/10 = 145/10 = 14.5
    assert abs(row["avg_launch_s"] - 14.5) < 1e-6


def test_solve_rate_counts_unique_teams(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager)
    # 4 unique teams launch WEB-001; 1 fully solves.
    for tid in ("ta", "tb", "tc", "td"):
        _archive_record(
            backend, instance_id=f"i-{tid}", challenge_id="WEB-001",
            team_id=tid, requested_at=1000.0, ready_at=1001.0,
        )
    # Only ta solves the single declared flag.
    _put_solve(backend, team_id="ta", challenge_id="WEB-001", flag_id="main")
    c = TestClient(app)
    r = c.get("/api/v1/admin/challenges/stats", headers=admin.headers)
    row = next(x for x in r.json()["items"] if x["challenge_id"] == "WEB-001")
    assert row["launches"] == 4
    # 1 solving team / 4 launching teams = 0.25
    assert abs(row["solve_rate"] - 0.25) < 1e-6


def test_running_count_reflects_live_state(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager)
    # Two live STARTING/READY rows for E1, none for E2.
    backend.put_instance(
        "live-1",
        InstanceState(
            instance_id="live-1",
            challenge_id="E1",
            team_id="t1",
            node_id="n1",
            status=InstanceStatus.READY,
        ),
    )
    backend.put_instance(
        "live-2",
        InstanceState(
            instance_id="live-2",
            challenge_id="E1",
            team_id="t2",
            node_id="n1",
            status=InstanceStatus.STARTING,
        ),
    )
    c = TestClient(app)
    rows = c.get("/api/v1/admin/challenges/stats", headers=admin.headers).json()["items"]
    e1 = next(x for x in rows if x["challenge_id"] == "E1")
    e2 = next(x for x in rows if x["challenge_id"] == "E2")
    assert e1["running_count"] == 2
    assert e2["running_count"] == 0


def test_recent_launch_durations_only_uses_successful_launches(mock_env_manager):
    """Errors that never reached READY should not appear in the sparkline,
    even when they are among the most recent records by ``requested_at``.
    Otherwise the sparkline would silently include 0-duration noise."""
    app, backend, admin = _bootstrap(mock_env_manager)
    # 3 successful launches.
    for i in range(3):
        _archive_record(
            backend,
            instance_id=f"ok{i}",
            challenge_id="AS-001",
            requested_at=1000.0 + i,
            ready_at=1000.0 + i + 0.5,
        )
    # 2 errors AFTER the successes — must not appear in the sparkline.
    for i in range(2):
        _archive_record(
            backend,
            instance_id=f"err{i}",
            challenge_id="AS-001",
            stop_reason="error",
            requested_at=2000.0 + i,
        )
    c = TestClient(app)
    rows = c.get("/api/v1/admin/challenges/stats", headers=admin.headers).json()["items"]
    row = next(x for x in rows if x["challenge_id"] == "AS-001")
    assert row["launches"] == 5
    assert row["errors"] == 2
    assert len(row["recent_launch_durations"]) == 3


def test_recent_launch_durations_capped_and_recent_first(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager)
    # 25 successful records, monotonically increasing requested_at —
    # latest 20 expected, ordered newest first.
    for i in range(25):
        _archive_record(
            backend, instance_id=f"r{i}", challenge_id="RATE-001",
            requested_at=1000.0 + i, ready_at=1000.0 + i + (i + 1),
            # duration = i+1
        )
    c = TestClient(app)
    rows = c.get("/api/v1/admin/challenges/stats", headers=admin.headers).json()["items"]
    row = next(x for x in rows if x["challenge_id"] == "RATE-001")
    durs = row["recent_launch_durations"]
    assert len(durs) == 20
    # Newest (i=24) duration = 25.0; oldest in window (i=5) = 6.0
    assert durs[0] == 25.0
    assert durs[-1] == 6.0
