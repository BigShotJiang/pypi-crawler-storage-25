"""End-to-end tests for ``GET /api/v1/teams/{id}/profile-stats``.

The endpoint pre-aggregates four sections (calendar, by_tag,
by_difficulty, solve_trend) for the public profile page and applies
the team's per-section visibility map for non-owner non-admin viewers.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from ctfy.core.enums import Difficulty
from ctfy.core.state.models import SolveState
from ctfy.server.routes.team_profile_stats import _utc_day
from ctfy.tests.conftest import build_spec, mint_team


def _seed_solve(backend, *, team_id, challenge_id, flag_id="main", solved_at=""):
    backend.add_solve(
        team_id,
        challenge_id,
        flag_id,
        SolveState(
            team_id=team_id,
            challenge_id=challenge_id,
            flag_id=flag_id,
            solved_at=solved_at or "2026-04-25T10:00:00Z",
            solve_time_s=10.0,
            attempts=1,
        ),
    )


# ---- Pure helpers -------------------------------------------------------


def test_utc_day_normalizes_iso_and_z_suffix():
    assert _utc_day("2026-04-25T10:00:00Z") == "2026-04-25"
    assert _utc_day("2026-04-25T10:00:00+00:00") == "2026-04-25"
    assert _utc_day("2026-04-25T23:30:00-08:00") == "2026-04-26"  # crosses UTC midnight
    assert _utc_day("") is None
    assert _utc_day("not-a-time") is None


# ---- Endpoint integration ----------------------------------------------


def test_profile_stats_zero_state_returns_dense_calendar(client, backend):
    team = mint_team(backend, name="Solo")
    resp = client.get(f"/api/v1/teams/{team.team_id}/profile-stats?days=30")
    assert resp.status_code == 200
    body = resp.json()
    # Calendar is dense — one bucket per requested day.
    assert len(body["calendar"]) == 30
    assert all(b["count"] == 0 for b in body["calendar"])
    # Trend window is fixed at 30 days regardless of ?days=.
    assert len(body["solve_trend"]) == 30
    # Tags / difficulty pull from spec_reader; conftest seeds 6 specs
    # all with tag "test" and a mix of difficulties, so non-empty even
    # when this team has zero solves.
    assert any(t["tag"] == "test" for t in body["by_tag"])
    assert all(t["solved"] == 0 for t in body["by_tag"])


def test_profile_stats_counts_solves_per_day_and_per_tag(client, backend, mock_env_manager):
    team = mint_team(backend, name="Solver")
    today = datetime.now(timezone.utc).date()
    _seed_solve(
        backend,
        team_id=team.team_id,
        challenge_id="WEB-001",
        solved_at=f"{today.isoformat()}T08:00:00Z",
    )
    _seed_solve(
        backend,
        team_id=team.team_id,
        challenge_id="WEB-002",
        solved_at=f"{today.isoformat()}T09:00:00Z",
    )
    yesterday = today - timedelta(days=1)
    _seed_solve(
        backend,
        team_id=team.team_id,
        challenge_id="E1",
        solved_at=f"{yesterday.isoformat()}T22:00:00Z",
    )

    resp = client.get(f"/api/v1/teams/{team.team_id}/profile-stats?days=7")
    body = resp.json()

    by_date = {b["date"]: b["count"] for b in body["calendar"]}
    assert by_date[today.isoformat()] == 2
    assert by_date[yesterday.isoformat()] == 1

    # All conftest specs share the tag "test"; team solved 3 unique
    # challenges, so by_tag for "test" should report 3 solved.
    test_tag = next(t for t in body["by_tag"] if t["tag"] == "test")
    assert test_tag["solved"] == 3
    assert test_tag["total"] >= 3  # the conftest seeds 6 specs

    # by_difficulty pulls difficulty.value from each spec; conftest WEB-002
    # is medium and WEB-001/E1 are easy, so the counts split.
    diffs = {d["difficulty"]: d["solved"] for d in body["by_difficulty"]}
    assert diffs.get("easy", 0) == 2
    assert diffs.get("medium", 0) == 1


def test_profile_stats_solve_trend_window_is_30_days(client, backend):
    team = mint_team(backend, name="Trend")
    # A solve far outside the 30-day trend window must not appear in
    # the trend, but it can show up on the calendar (which honors the
    # ?days= param).
    long_ago = (datetime.now(timezone.utc).date() - timedelta(days=200)).isoformat()
    _seed_solve(
        backend,
        team_id=team.team_id,
        challenge_id="E1",
        solved_at=f"{long_ago}T08:00:00Z",
    )
    body = client.get(
        f"/api/v1/teams/{team.team_id}/profile-stats?days=365"
    ).json()
    assert all(p["solves"] == 0 for p in body["solve_trend"])
    # The single old solve still lands on the year-window calendar.
    assert sum(b["count"] for b in body["calendar"]) == 1


def test_profile_stats_visibility_masks_for_anonymous(client, backend):
    team = mint_team(backend, name="Private")
    today = datetime.now(timezone.utc).date()
    _seed_solve(
        backend,
        team_id=team.team_id,
        challenge_id="WEB-001",
        solved_at=f"{today.isoformat()}T10:00:00Z",
    )
    # Mark the calendar private for non-owner viewers.
    client.patch(
        "/api/v1/me/profile/visibility",
        headers=team.headers,
        json={"activity_calendar": False, "tag_stats": False},
    )
    body = client.get(f"/api/v1/teams/{team.team_id}/profile-stats").json()
    # Anonymous viewer: masked sections are emptied.
    assert body["calendar"] == []
    assert body["by_tag"] == []
    # Other sections still flow through — the toggle is per-section.
    assert any(d["solved"] == 1 for d in body["by_difficulty"])


def test_profile_stats_owner_bypass(client, backend):
    team = mint_team(backend, name="Owner")
    today = datetime.now(timezone.utc).date()
    _seed_solve(
        backend,
        team_id=team.team_id,
        challenge_id="WEB-001",
        solved_at=f"{today.isoformat()}T10:00:00Z",
    )
    client.patch(
        "/api/v1/me/profile/visibility",
        headers=team.headers,
        json={"activity_calendar": False, "tag_stats": False},
    )
    # Owner sees their own data unmasked even when the toggles are off.
    body = client.get(
        f"/api/v1/teams/{team.team_id}/profile-stats",
        headers=team.headers,
    ).json()
    assert sum(b["count"] for b in body["calendar"]) == 1
    assert any(t["solved"] == 1 for t in body["by_tag"])


def test_profile_stats_admin_bypass(client, backend, admin_team):
    team = mint_team(backend, name="Watched")
    today = datetime.now(timezone.utc).date()
    _seed_solve(
        backend,
        team_id=team.team_id,
        challenge_id="WEB-001",
        solved_at=f"{today.isoformat()}T10:00:00Z",
    )
    client.patch(
        "/api/v1/me/profile/visibility",
        headers=team.headers,
        json={"activity_calendar": False},
    )
    body = client.get(
        f"/api/v1/teams/{team.team_id}/profile-stats",
        headers=admin_team.headers,
    ).json()
    assert sum(b["count"] for b in body["calendar"]) == 1


def test_profile_stats_unknown_team_404(client):
    resp = client.get("/api/v1/teams/does-not-exist/profile-stats")
    assert resp.status_code == 404


def test_profile_stats_owner_bypass_via_per_comp_membership(client, backend):
    """Owner bypass must work when the viewer is on the team via a
    per-competition membership (``competition_id != ""``), not just via
    the legacy default slot. Otherwise users who joined the team in a
    real competition would see their own profile through the privacy
    scrub instead of unmasked.
    """
    from ctfy.core.state.models import TeamMembershipState

    team = mint_team(backend, name="OwnerInComp")
    # Drop the legacy default-slot row mint_team created and re-attach
    # the same user to the same team via a per-comp membership only.
    # This is the post-Phase-1.D world: every membership has a
    # non-empty competition_id.
    backend.delete_membership(team.user_id)
    backend.put_membership(
        TeamMembershipState(
            user_id=team.user_id,
            team_id=team.team_id,
            joined_at="2026-01-01T00:00:00Z",
            competition_id="spring-ctf",
        )
    )

    today = datetime.now(timezone.utc).date()
    _seed_solve(
        backend,
        team_id=team.team_id,
        challenge_id="WEB-001",
        solved_at=f"{today.isoformat()}T10:00:00Z",
    )
    client.patch(
        "/api/v1/me/profile/visibility",
        headers=team.headers,
        json={"activity_calendar": False, "tag_stats": False},
    )
    body = client.get(
        f"/api/v1/teams/{team.team_id}/profile-stats",
        headers=team.headers,
    ).json()
    # Owner — even via per-comp membership — sees unmasked data.
    assert sum(b["count"] for b in body["calendar"]) == 1
    assert any(t["solved"] == 1 for t in body["by_tag"])


def test_visibility_endpoint_accepts_new_keys(client, backend):
    """The PATCH /me/profile/visibility validator must learn the four
    new keys so the editor can drive them — otherwise toggling does
    nothing and the user can't actually hide a section."""
    team = mint_team(backend, name="V")
    client.patch(
        "/api/v1/me/profile/visibility",
        headers=team.headers,
        json={
            "activity_calendar": False,
            "tag_stats": False,
            "difficulty_stats": False,
            "solve_trend": False,
        },
    )
    after = backend.get_user(team.user_id).profile_visibility
    assert after == {
        "activity_calendar": False,
        "tag_stats": False,
        "difficulty_stats": False,
        "solve_trend": False,
    }


@pytest.mark.parametrize("days,expected_len", [(7, 7), (30, 30), (365, 365)])
def test_profile_stats_calendar_window_param(client, backend, days, expected_len):
    team = mint_team(backend, name="Win")
    body = client.get(
        f"/api/v1/teams/{team.team_id}/profile-stats?days={days}"
    ).json()
    assert len(body["calendar"]) == expected_len


def test_profile_stats_calendar_window_clamped(client, backend):
    """``days`` is clamped to 7..365 by the route. Out-of-range values
    return 422 rather than silently rendering a 0-day or 10000-day
    calendar."""
    team = mint_team(backend, name="W")
    assert client.get(
        f"/api/v1/teams/{team.team_id}/profile-stats?days=0"
    ).status_code == 422
    assert client.get(
        f"/api/v1/teams/{team.team_id}/profile-stats?days=99999"
    ).status_code == 422


def test_profile_stats_tag_axes_are_capped(client, backend, mock_env_manager):
    """The radar caps at 8 axes; deployments with many tags must not
    explode the polygon."""
    # Inject 12 distinct-tag specs by replacing iter_specs.
    many_tag_specs = [
        build_spec(f"X-{i:02d}", tags=[f"tag-{i}"], difficulty=Difficulty.EASY)
        for i in range(12)
    ]
    mock_env_manager.iter_specs = lambda **_kw: iter(many_tag_specs)
    team = mint_team(backend, name="Many")
    body = client.get(
        f"/api/v1/teams/{team.team_id}/profile-stats?days=7"
    ).json()
    assert len(body["by_tag"]) == 8
