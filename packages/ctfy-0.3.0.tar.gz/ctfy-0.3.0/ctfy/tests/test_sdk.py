"""End-to-end tests for the Python SDK (PlatformClient).

Live-network coverage — this file boots a real uvicorn server on a
background thread so the SDK exercises its real HTTP path rather than
a TestClient shim. Skipped in the default CI invocation (``--ignore``);
we keep the ``mint_team`` shortcut so local runs still work against the
post-OAuth platform.
"""

import socket
import threading
import time
from unittest.mock import MagicMock, patch

import pytest
import uvicorn
from starlette.testclient import TestClient as StarletteClient

from ctfy.core.provider import StartResult
from ctfy.core.state import InMemoryBackend
from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType
from ctfy.sdk import PlatformClient
from ctfy.server.models import (
    ChallengeInfo,
    ChallengeStats,
    HealthResponse,
    InstanceInfo,
    InstanceStatusResponse,
    RenewResponse,
    ScoreboardEntry,
    SubmissionResponse,
    TeamInfo,
    VerifyFlagResponse,
)
from ctfy.tests.conftest import build_spec, mint_team, start_instance_and_wait

SDK_FLAG = "FLAG{sdk_test_flag_0123456789abcdef}"


def _make_app(backend):
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import make_mock_challenge_manager

    mock_mgr = make_mock_challenge_manager(
        flag=SDK_FLAG,
        port=9090,
        challenge_specs=[
            build_spec("SDK-001", name="SDK Test"),
        ],
    )

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_mgr):
        return create_app(external_host="10.0.1.5", backend=backend)


@pytest.fixture
def platform():
    """Returns (authenticated TestClient, team_data, raw TestClient)."""
    from ctfy.tests.conftest import fake_node_context

    backend = InMemoryBackend()
    app = _make_app(backend)

    with fake_node_context(backend, flag=SDK_FLAG, port=9090):
        raw = StarletteClient(app)

        # Mint a team directly; OAuth is covered by test_oauth.py.
        minted = mint_team(backend, name="SDK Team", email="sdk@example.test")
        team = {"team_id": minted.team_id, "name": "SDK Team", "token": minted.token}

        auth = StarletteClient(app, headers={"Authorization": f"Bearer {team['token']}"})

        yield auth, team, raw


class TestSDKTeams:
    def test_public_registration_endpoint_removed(self, platform):
        """Self-signup via POST /teams is gone — teams come from OAuth."""
        _, _, raw = platform
        r = raw.post("/api/v1/teams", json={"name": "New"})
        assert r.status_code in (404, 405)

    def test_list(self, platform):
        auth, _, _ = platform
        assert len(auth.get("/api/v1/teams").json()["items"]) >= 1


class TestSDKChallenges:
    def test_list(self, platform):
        auth, _, _ = platform
        chals = auth.get("/api/v1/challenges").json()["items"]
        assert len(chals) == 1
        assert chals[0]["id"] == "SDK-001"


class TestSDKSubmissions:
    def test_correct(self, platform):
        auth, _, _ = platform
        instance_id = start_instance_and_wait(auth, "SDK-001")
        r = auth.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{sdk_test_flag_0123456789abcdef}",
            },
        )
        assert r.json()["correct"] is True
        assert r.json()["solve_time_s"] >= 0

    def test_wrong(self, platform):
        auth, _, _ = platform
        instance_id = start_instance_and_wait(auth, "SDK-001")
        r = auth.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{nope}",
            },
        )
        assert r.json()["correct"] is False


class TestSDKScoreboard:
    def test_ranking(self, platform):
        auth, _, _ = platform
        instance_id = start_instance_and_wait(auth, "SDK-001")
        auth.post(
            "/api/v1/submissions",
            json={"instance_id": instance_id, "flag": "FLAG{sdk_test_flag_0123456789abcdef}"},
        )
        board = auth.get("/api/v1/scoreboard").json()["items"]
        assert board[0]["solved"] == 1


class TestSDKClientWrapper:
    """Test the actual PlatformClient class methods (unit test)."""

    def test_submit_result_dataclass(self):
        r = SubmissionResponse(submission_id="abc", correct=True, solve_time_s=12.5)
        assert r.correct is True
        assert r.solve_time_s == 12.5

    def test_scoreboard_row_dataclass(self):
        r = ScoreboardEntry(
            rank=1,
            team_id="t1",
            team_name="A",
            solved=5,
            attempts=10,
            last_solve_at="2026-01-01",
        )
        assert r.solved == 5
        assert r.attempts == 10


class TestSDKFullLifecycle:
    def test_e2e(self, platform):
        """Register → challenges → start → submit → scoreboard → team stats."""
        auth, team, _ = platform

        chals = auth.get("/api/v1/challenges").json()["items"]
        assert len(chals) >= 1

        instance_id = start_instance_and_wait(auth, chals[0]["id"])

        r = auth.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{sdk_test_flag_0123456789abcdef}",
            },
        )
        assert r.json()["correct"] is True

        board = auth.get("/api/v1/scoreboard").json()["items"]
        me = [r for r in board if r["team_id"] == team["team_id"]]
        assert me[0]["solved"] == 1

        info = auth.get(f"/api/v1/teams/{team['team_id']}").json()
        assert info["solves"] == 1


# ============================================================================
# True E2E: a real uvicorn server in a background thread + real PlatformClient
# round trips. Verifies SDK methods (return types, parameter handling) against
# live HTTP, not just TestClient.
# ============================================================================

E2E_FLAG = "FLAG{sdk_e2e_test_flag_abcdef0123456789}"


def _make_e2e_app():
    mock_mgr = MagicMock()
    mock_mgr.start.return_value = StartResult(
        surface=AttackSurface(
            services=[
                ServiceEndpoint(
                    service_type=ServiceType.HTTP,
                    host="127.0.0.1",
                    port=9090,
                ),
            ],
        ),
        flags={"main": E2E_FLAG},
    )
    mock_mgr.stop.return_value = None
    mock_mgr.stop_all.return_value = None
    mock_mgr.get_cert_volume.return_value = ""
    specs = [
        build_spec("E2E-001", name="E2E Test Challenge", description="Test challenge for SDK e2e"),
        build_spec(
            "E2E-002",
            name="E2E Second",
            description="Another test",
            difficulty="medium",
        ),
    ]

    def _iter_specs(**kw):
        result = specs
        if kw.get("difficulty") is not None:
            result = [s for s in result if s.difficulty.value == kw["difficulty"]]
        if kw.get("tag"):
            result = [s for s in result if kw["tag"] in s.tags]
        return iter(result)

    mock_mgr.iter_specs.side_effect = _iter_specs

    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    return app, backend


def _find_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def server_url_and_backend():
    """Start a real HTTP server in a background thread. Returns (url, backend).

    Tests that need to mint a team call ``mint_team(backend, ...)``
    directly — the post-OAuth platform no longer supports the old
    public self-signup path.
    """
    from ctfy.tests.conftest import fake_node_context

    app, backend = _make_e2e_app()
    port = _find_free_port()
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    url = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            import httpx

            httpx.get(f"{url}/api/v1/health", timeout=1)
            break
        except Exception:
            time.sleep(0.1)
    else:
        raise RuntimeError("Test server did not start")

    with fake_node_context(backend, flag=E2E_FLAG):
        yield url, backend
    server.should_exit = True


@pytest.fixture(scope="module")
def server_url(server_url_and_backend):
    url, _ = server_url_and_backend
    return url


@pytest.fixture(scope="module")
def anon_client(server_url):
    with PlatformClient(server_url) as c:
        yield c


@pytest.fixture(scope="module")
def team_and_client(server_url_and_backend):
    url, backend = server_url_and_backend
    minted = mint_team(backend, name="SDK-E2E-Team", email="sdk-e2e@example.test")

    class _Team:
        team_id = minted.team_id
        user_id = minted.user_id
        token = minted.token
        name = "SDK-E2E-Team"

    team = _Team()
    with PlatformClient(url, token=team.token) as c:
        yield c, team


def _e2e_start_and_wait(client, challenge_id="E2E-001", *, max_wait=10):
    client._request("POST", "/instances", json={"challenge_id": challenge_id, "ttl": 300})
    deadline = time.monotonic() + max_wait
    while time.monotonic() < deadline:
        for inst in client.list_instances():
            if inst.challenge_id == challenge_id and inst.status == "ready":
                return inst.instance_id
        time.sleep(0.2)
    raise TimeoutError(f"{challenge_id} not ready")


class TestE2EHealth:
    def test_health(self, anon_client):
        h = anon_client.health()
        assert isinstance(h, HealthResponse)
        assert h.status == "ok"
        assert h.hostname != ""


class TestE2ETeams:
    def test_public_registration_is_closed(self, server_url):
        """The legacy ``POST /teams`` self-signup is gone.

        SDK has no ``register_team`` anymore; teams are minted via the
        OAuth callback. Tests that want a live token call ``mint_team``
        against the backend directly — see ``team_and_client``.
        """
        import httpx

        r = httpx.post(
            f"{server_url}/api/v1/teams",
            json={"name": "NewTeam"},
            timeout=5,
        )
        assert r.status_code in (404, 405)

    def test_list_teams(self, anon_client, team_and_client):
        # ``team_and_client`` seeds at least one team so the list is non-empty
        # regardless of test execution order.
        del team_and_client
        teams = anon_client.list_teams()
        assert isinstance(teams, list)
        assert len(teams) >= 1
        assert all(isinstance(t, TeamInfo) for t in teams)

    def test_get_team(self, team_and_client):
        client, team = team_and_client
        t = client.get_team(team.team_id)
        assert isinstance(t, TeamInfo)
        assert t.team_id == team.team_id
        assert t.name == "SDK-E2E-Team"

    def test_get_me(self, team_and_client):
        client, team = team_and_client
        me = client.get_me()
        # Post user/team-split /me is user-shaped.
        assert me.user_id == team.user_id
        # The minted team appears in the per-comp memberships list.
        assert any(
            ct.team_id == team.team_id for ct in me.competition_teams
        )


class TestE2ETeamUp:
    """End-to-end captain mints invite → other user redeems →
    both see the multi-member team via SDK."""

    def test_create_mint_redeem_leave(self, server_url_and_backend):
        """Per-comp captain CRUD via SDK: create team for a comp, mint
        invite, joiner redeems, joiner leaves, captain revokes invite."""
        from ctfy.core.state.models import CompetitionState
        from ctfy.tests.conftest import mint_team

        url, backend = server_url_and_backend
        backend.put_competition(
            CompetitionState(
                competition_id="sdk-comp",
                title="SDK Comp",
                challenge_ids=[],
                created_at="2026-01-01T00:00:00Z",
            )
        )
        captain = mint_team(backend, name="captain", email="cap@e2e.test")
        joiner = mint_team(backend, name="joiner", email="join@e2e.test")

        with PlatformClient(url, token=captain.token) as cap_cli:
            new_team = cap_cli.create_competition_team(
                "sdk-comp", name="SDK-Captains", description="formed via SDK"
            )
            assert new_team.captain_user_id == captain.user_id
            assert new_team.competition_id == "sdk-comp"
            assert new_team.member_count == 1

            inv = cap_cli.mint_competition_invite(
                "sdk-comp", max_uses=2, ttl_seconds=3600
            )
            assert inv.code
            assert inv.use_count == 0

            invites = cap_cli.list_competition_invites("sdk-comp")
            assert any(i.invite_id == inv.invite_id for i in invites)

        with PlatformClient(url, token=joiner.token) as join_cli:
            joined = join_cli.redeem_competition_invite("sdk-comp", inv.code)
            assert joined.team_id == new_team.team_id
            assert joined.member_count == 2

        # Joiner leaves → no longer registered for this comp.
        with PlatformClient(url, token=joiner.token) as join_cli:
            join_cli.leave_competition_team("sdk-comp")
        assert (
            backend.get_membership_for_competition(joiner.user_id, "sdk-comp")
            is None
        )

        # Captain revokes the invite.
        with PlatformClient(url, token=captain.token) as cap_cli:
            cap_cli.revoke_competition_invite("sdk-comp", inv.invite_id)
            invites_after = cap_cli.list_competition_invites("sdk-comp")
            revoked = next(
                i for i in invites_after if i.invite_id == inv.invite_id
            )
            assert revoked.revoked_at != ""
            assert revoked.active is False

    def test_kick_member_via_sdk(self, server_url_and_backend):
        """Captain kicks a member through
        ``PlatformClient.kick_competition_member``; kicked user is no
        longer registered for the comp."""
        from ctfy.core.state.models import CompetitionState
        from ctfy.tests.conftest import mint_team

        url, backend = server_url_and_backend
        backend.put_competition(
            CompetitionState(
                competition_id="sdk-kick",
                title="SDK Kick",
                challenge_ids=[],
                created_at="2026-01-01T00:00:00Z",
            )
        )
        captain = mint_team(backend, name="kickcap", email="kc@e2e.test")
        member = mint_team(backend, name="kickmem", email="km@e2e.test")
        with PlatformClient(url, token=captain.token) as cap_cli:
            cap_cli.create_competition_team("sdk-kick", name="KickSquad")
            inv = cap_cli.mint_competition_invite("sdk-kick")
        with PlatformClient(url, token=member.token) as mem_cli:
            mem_cli.redeem_competition_invite("sdk-kick", inv.code)
        # Captain kicks the member.
        with PlatformClient(url, token=captain.token) as cap_cli:
            cap_cli.kick_competition_member("sdk-kick", member.user_id)
        # Kicked user is no longer registered for this comp.
        assert (
            backend.get_membership_for_competition(member.user_id, "sdk-kick")
            is None
        )


class TestE2EAdminUsers:
    """Admin-scoped SDK helpers."""

    def test_get_admin_user(self, server_url_and_backend):
        """Admin can resolve a single user's audit shape via
        ``PlatformClient.get_admin_user(user_id)``."""
        from ctfy.tests.conftest import mint_team

        url, backend = server_url_and_backend
        admin = mint_team(backend, name="adm", email="adm@e2e.test", role="admin")
        target = mint_team(backend, name="tgt", email="tgt@e2e.test")
        with PlatformClient(url, token=admin.token) as cli:
            info = cli.get_admin_user(target.user_id)
            assert info.user_id == target.user_id
            assert info.email == "tgt@e2e.test"
            assert info.role == "user"


class TestE2EChallenges:
    def test_list_challenges(self, anon_client):
        chals = anon_client.list_challenges()
        assert len(chals) == 2
        assert all(isinstance(c, ChallengeInfo) for c in chals)
        ids = {c.id for c in chals}
        assert "E2E-001" in ids
        assert "E2E-002" in ids

    def test_category_is_platform_constant(self, anon_client):
        chals = anon_client.list_challenges()
        assert all(c.category == "web" for c in chals)

    def test_list_challenges_with_difficulty(self, anon_client):
        chals = anon_client.list_challenges(difficulty="medium")
        assert len(chals) == 1
        assert chals[0].id == "E2E-002"

    def test_list_challenges_with_q(self, anon_client):
        chals = anon_client.list_challenges(q="Second")
        assert len(chals) == 1
        assert chals[0].id == "E2E-002"

    def test_list_challenges_q_matches_id(self, anon_client):
        chals = anon_client.list_challenges(q="001")
        assert len(chals) == 1
        assert chals[0].id == "E2E-001"

    def test_list_challenges_q_no_match(self, anon_client):
        chals = anon_client.list_challenges(q="nonexistent")
        assert len(chals) == 0

    def test_get_challenge(self, anon_client):
        c = anon_client.get_challenge("E2E-001")
        assert isinstance(c, ChallengeInfo)
        assert c.id == "E2E-001"
        assert c.name == "E2E Test Challenge"


class TestE2EInstances:
    def test_start_and_stop_instance(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client, "E2E-001")
        assert instance_id

        instances = client.list_instances()
        assert isinstance(instances, list)
        assert len(instances) >= 1
        assert all(isinstance(e, InstanceInfo) for e in instances)

        client.stop_instance(instance_id)

    def test_list_instances_filter_challenge_id(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client, "E2E-001")
        try:
            instances = client.list_instances(challenge_id="E2E-001")
            assert len(instances) == 1
            assert instances[0].challenge_id == "E2E-001"

            instances_none = client.list_instances(challenge_id="NONEXISTENT")
            assert len(instances_none) == 0
        finally:
            client.stop_instance(instance_id)

    def test_list_instances_filter_status(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client, "E2E-001")
        try:
            instances = client.list_instances(status="ready")
            assert len(instances) >= 1
            assert all(e.status == "ready" for e in instances)

            instances_err = client.list_instances(status="error")
            assert len(instances_err) == 0
        finally:
            client.stop_instance(instance_id)

    def test_list_instances_filter_q(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client, "E2E-001")
        try:
            instances = client.list_instances(q="E2E")
            assert len(instances) >= 1

            instances_none = client.list_instances(q="zzzzz")
            assert len(instances_none) == 0
        finally:
            client.stop_instance(instance_id)

    def test_get_instance_status(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client, "E2E-001")
        try:
            status = client.get_instance_status(instance_id)
            assert isinstance(status, InstanceStatusResponse)
            assert status.status == "ready"
        finally:
            client.stop_instance(instance_id)

    def test_renew_instance(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client, "E2E-001")
        try:
            result = client.renew_instance(instance_id, ttl=7200)
            assert isinstance(result, RenewResponse)
            assert result.status == "renewed"
            assert result.expires_at > 0
        finally:
            client.stop_instance(instance_id)


class TestE2EFlags:
    def test_verify_flag_correct(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client)
        try:
            result = client.verify_flag(instance_id, E2E_FLAG)
            assert isinstance(result, VerifyFlagResponse)
            assert result.correct is True
        finally:
            client.stop_instance(instance_id)

    def test_verify_flag_wrong(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client)
        try:
            result = client.verify_flag(instance_id, "FLAG{wrong}")
            assert isinstance(result, VerifyFlagResponse)
            assert result.correct is False
        finally:
            client.stop_instance(instance_id)

    def test_submit_flag_correct(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client)
        try:
            r = client.submit_flag(instance_id, E2E_FLAG)
            assert isinstance(r, SubmissionResponse)
            assert r.correct is True
            assert r.solve_time_s >= 0
        finally:
            client.stop_instance(instance_id)

    def test_submit_flag_wrong(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client)
        try:
            r = client.submit_flag(instance_id, "FLAG{nope}")
            assert isinstance(r, SubmissionResponse)
            assert r.correct is False
        finally:
            client.stop_instance(instance_id)


class TestE2ESubmissions:
    def test_list_submissions(self, team_and_client):
        client, _ = team_and_client
        subs = client.list_submissions()
        assert isinstance(subs, list)
        assert len(subs) >= 1


class TestE2EScoreboard:
    def test_scoreboard(self, anon_client):
        board = anon_client.scoreboard()
        assert isinstance(board, list)
        assert all(isinstance(e, ScoreboardEntry) for e in board)

    def test_get_scoreboard_alias(self, anon_client):
        board = anon_client.get_scoreboard()
        assert isinstance(board, list)

    def test_scoreboard_has_attempts(self, anon_client):
        board = anon_client.scoreboard()
        for entry in board:
            assert isinstance(entry.attempts, int)

    def test_challenge_stats(self, anon_client):
        stats = anon_client.challenge_stats()
        assert isinstance(stats, list)
        assert all(isinstance(s, ChallengeStats) for s in stats)

    def test_get_challenge_stats_alias(self, anon_client):
        stats = anon_client.get_challenge_stats()
        assert isinstance(stats, list)


class TestE2EActivities:
    def test_get_activities(self, team_and_client):
        client, _ = team_and_client
        acts = client.get_activities()
        assert isinstance(acts, list)
        assert len(acts) >= 1

    def test_get_activities_filtered(self, team_and_client):
        client, _ = team_and_client
        acts = client.get_activities(event="team_registered")
        assert all(a.event == "team_registered" for a in acts)


class TestE2ENodes:
    def test_node_lifecycle(self, server_url):
        with PlatformClient(server_url) as c:
            try:
                c.register_node("http://node1:8100", capacity=20, labels={"gpu": "true"})
                nodes = c.list_nodes()
                assert isinstance(nodes, list)
            except Exception:
                pass

    def test_register_node_labels_type(self):
        import inspect

        sig = inspect.signature(PlatformClient.register_node)
        labels_param = sig.parameters["labels"]
        assert labels_param.default is None


class TestE2EFullLifecycle:
    def test_register_start_submit_scoreboard(self, server_url_and_backend):
        url, backend = server_url_and_backend
        minted = mint_team(backend, name="Lifecycle-Team", email="lifecycle@example.test")

        class _Team:
            team_id = minted.team_id
            token = minted.token

        team = _Team()
        with PlatformClient(url, token=team.token) as c:
            chals = c.list_challenges()
            assert len(chals) >= 1
            cid = chals[0].id

            start_resp = c._request(
                "POST", "/instances", json={"challenge_id": cid, "ttl": 300}
            )
            instance_id = start_resp.json()["instance_id"]
            deadline = time.monotonic() + 10
            ready = False
            while time.monotonic() < deadline:
                for inst in c.list_instances():
                    if inst.instance_id == instance_id and inst.status == "ready":
                        ready = True
                        break
                if ready:
                    break
                time.sleep(0.2)
            assert ready, f"{cid} not ready"

            r = c.submit_flag(instance_id, E2E_FLAG)
            assert r.correct is True

            board = c.scoreboard()
            my_entry = [e for e in board if e.team_id == team.team_id]
            assert len(my_entry) == 1
            assert my_entry[0].solved == 1
            assert my_entry[0].attempts >= 1

            me = c.get_me()
            assert me.solves == 1

            c.stop_instance(instance_id)
