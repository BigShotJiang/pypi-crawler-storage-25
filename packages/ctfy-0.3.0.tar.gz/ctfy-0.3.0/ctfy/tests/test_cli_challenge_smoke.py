"""`ctfy challenge smoke` walks challenges_dir and shells to the upstream
``scripts/smoke_test.py`` for each matching benchmark. We stub subprocess so
the test never actually runs docker / exploit.py, and exercise the typer
command via CliRunner to cover the wiring (filtering, summary, --jobs,
exit codes, smoke_test arg passthrough)."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from ctfy.cli.challenge import challenge_app


def _make_challenge(
    root: Path, cid: str, *, difficulty: str = "easy", tags: list[str] | None = None
) -> None:
    cdir = root / cid
    cdir.mkdir(parents=True)
    tags_yaml = "\n".join(f"  - {t}" for t in (tags or ["web"]))
    (cdir / "metadata.yaml").write_text(
        f"name: {cid}\n"
        f"description: test challenge {cid}\n"
        f"difficulty: {difficulty}\n"
        f"tags:\n{tags_yaml}\n"
    )
    (cdir / "docker-compose.yml").write_text("services:\n  app:\n    image: alpine:3\n")


def _make_smoke_script(root: Path) -> Path:
    """Materialise a stub `scripts/smoke_test.py` so the existence check
    passes. The subprocess is mocked; the file content is never executed."""
    scripts = root / "scripts"
    scripts.mkdir(exist_ok=True)
    smoke = scripts / "smoke_test.py"
    smoke.write_text("# stub for tests; subprocess.run is patched\n")
    return smoke


def _ok_result() -> MagicMock:
    r = MagicMock(spec=subprocess.CompletedProcess)
    r.returncode = 0
    r.stdout = ""
    r.stderr = ""
    return r


def _fail_result(rc: int = 1, stderr: str = "[smoke] FAIL: exploit rc=1") -> MagicMock:
    r = MagicMock(spec=subprocess.CompletedProcess)
    r.returncode = rc
    r.stdout = ""
    r.stderr = stderr
    return r


class TestChallengeSmoke:
    @patch("ctfy.cli.challenge.subprocess.run")
    def test_runs_smoke_per_challenge(self, run_stub, tmp_path: Path):
        _make_challenge(tmp_path, "alpha")
        _make_challenge(tmp_path, "beta")
        _make_smoke_script(tmp_path)
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(challenge_app, ["smoke", "--challenges-dir", str(tmp_path)])
        assert result.exit_code == 0, result.output

        # One smoke_test invocation per challenge.
        assert run_stub.call_count == 2
        invoked_ids = sorted(call.args[0][6] for call in run_stub.call_args_list)
        assert invoked_ids == ["alpha", "beta"]

        # Each invocation is `uv run --project <dir> python smoke_test.py <id> …`.
        for call in run_stub.call_args_list:
            argv = call.args[0]
            assert argv[:3] == ["uv", "run", "--project"]
            assert argv[3] == str(tmp_path)
            assert argv[4] == "python"
            assert argv[5].endswith("smoke_test.py")
            # --root is pinned to challenges_dir so smoke_test resolves the
            # benchmark path consistently no matter the cwd.
            assert "--root" in argv
            assert argv[argv.index("--root") + 1] == str(tmp_path)

        assert "2 ok, 0 failed" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_passes_host_port_timeout_keep(self, run_stub, tmp_path: Path):
        _make_challenge(tmp_path, "alpha")
        _make_smoke_script(tmp_path)
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(
            challenge_app,
            [
                "smoke",
                "--challenges-dir",
                str(tmp_path),
                "--host",
                "10.0.0.1",
                "--port",
                "8080",
                "--timeout",
                "120",
                "--keep",
            ],
        )
        assert result.exit_code == 0, result.output
        assert run_stub.call_count == 1
        argv = run_stub.call_args_list[0].args[0]
        assert "--host" in argv and argv[argv.index("--host") + 1] == "10.0.0.1"
        assert "--port" in argv and argv[argv.index("--port") + 1] == "8080"
        assert "--timeout" in argv and argv[argv.index("--timeout") + 1] == "120"
        assert "--keep" in argv

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_filter_by_challenge_id(self, run_stub, tmp_path: Path):
        _make_challenge(tmp_path, "alpha")
        _make_challenge(tmp_path, "beta")
        _make_smoke_script(tmp_path)
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(
            challenge_app,
            ["smoke", "--challenges-dir", str(tmp_path), "--challenge", "alpha"],
        )
        assert result.exit_code == 0, result.output
        assert run_stub.call_count == 1
        assert run_stub.call_args_list[0].args[0][6] == "alpha"

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_continues_after_failure_and_exits_nonzero(self, run_stub, tmp_path: Path):
        _make_challenge(tmp_path, "alpha")
        _make_challenge(tmp_path, "beta")
        _make_smoke_script(tmp_path)
        # alpha fails (exploit rc=1), beta succeeds. Sequential mode streams,
        # so the failure detail just carries the exit code.
        results = iter([_fail_result(rc=1), _ok_result()])
        run_stub.side_effect = lambda *a, **kw: next(results)

        result = CliRunner().invoke(challenge_app, ["smoke", "--challenges-dir", str(tmp_path)])
        assert result.exit_code == 1, result.output
        assert run_stub.call_count == 2
        assert "1 ok, 1 failed" in result.output
        assert "alpha" in result.output
        assert "see output above" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_sequential_streams_output_no_capture(self, run_stub, tmp_path: Path):
        _make_challenge(tmp_path, "alpha")
        _make_smoke_script(tmp_path)
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(challenge_app, ["smoke", "--challenges-dir", str(tmp_path)])
        assert result.exit_code == 0, result.output
        for call in run_stub.call_args_list:
            assert "capture_output" not in call.kwargs
            assert "text" not in call.kwargs

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_parallel_captures_output_and_surfaces_tail(self, run_stub, tmp_path: Path):
        _make_challenge(tmp_path, "alpha")
        _make_challenge(tmp_path, "beta")
        _make_smoke_script(tmp_path)
        results = iter(
            [
                _fail_result(rc=2, stderr="[smoke] compose up failed (rc=1)"),
                _ok_result(),
            ]
        )
        run_stub.side_effect = lambda *a, **kw: next(results)

        result = CliRunner().invoke(
            challenge_app,
            ["smoke", "--challenges-dir", str(tmp_path), "--jobs", "2"],
        )
        assert result.exit_code == 1, result.output
        for call in run_stub.call_args_list:
            assert call.kwargs.get("capture_output") is True
            assert call.kwargs.get("text") is True
        assert "compose up failed" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_jobs_parallel_runs_every_challenge(self, run_stub, tmp_path: Path):
        for cid in ("a", "b", "c", "d"):
            _make_challenge(tmp_path, cid)
        _make_smoke_script(tmp_path)
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(
            challenge_app,
            ["smoke", "--challenges-dir", str(tmp_path), "--jobs", "4"],
        )
        assert result.exit_code == 0, result.output
        assert run_stub.call_count == 4
        assert "4 ok, 0 failed" in result.output

    def test_no_match_exits_nonzero(self, tmp_path: Path):
        # challenges_dir exists but is empty.
        result = CliRunner().invoke(challenge_app, ["smoke", "--challenges-dir", str(tmp_path)])
        assert result.exit_code == 2, result.output
        assert "No challenges matched" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_missing_smoke_script_reports_failure(self, run_stub, tmp_path: Path):
        # challenge present but scripts/smoke_test.py absent (e.g. challenges
        # repo not yet sync'd or upstream lacking the helper).
        _make_challenge(tmp_path, "alpha")

        result = CliRunner().invoke(challenge_app, ["smoke", "--challenges-dir", str(tmp_path)])
        assert result.exit_code == 1, result.output
        run_stub.assert_not_called()
        assert "smoke_test.py not found" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_missing_compose_file_reports_failure(self, run_stub, tmp_path: Path):
        cdir = tmp_path / "broken"
        cdir.mkdir()
        (cdir / "metadata.yaml").write_text(
            "name: broken\ndescription: missing compose\ndifficulty: easy\ntags:\n  - web\n"
        )
        _make_smoke_script(tmp_path)

        result = CliRunner().invoke(challenge_app, ["smoke", "--challenges-dir", str(tmp_path)])
        assert result.exit_code == 1, result.output
        run_stub.assert_not_called()
        assert "docker-compose.yml not found" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_uv_binary_missing_reports_failure(self, run_stub, tmp_path: Path):
        _make_challenge(tmp_path, "alpha")
        _make_smoke_script(tmp_path)
        run_stub.side_effect = FileNotFoundError("uv")

        result = CliRunner().invoke(challenge_app, ["smoke", "--challenges-dir", str(tmp_path)])
        assert result.exit_code == 1, result.output
        assert "uv" in result.output.lower()

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_outer_timeout_includes_buffer(self, run_stub, tmp_path: Path):
        # The user-facing --timeout caps `compose up --wait` inside
        # smoke_test. The outer subprocess.run call gets a buffer on top so
        # the exploit + `compose down -v` phase isn't truncated.
        _make_challenge(tmp_path, "alpha")
        _make_smoke_script(tmp_path)
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(
            challenge_app,
            ["smoke", "--challenges-dir", str(tmp_path), "--timeout", "60"],
        )
        assert result.exit_code == 0, result.output
        outer_timeout = run_stub.call_args_list[0].kwargs.get("timeout")
        assert outer_timeout is not None
        assert outer_timeout > 60
