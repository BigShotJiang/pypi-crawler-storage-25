"""Regression tests for the first-user super-admin TOCTOU race.

Pre-fix, ``POST /auth/register`` did:

    first_user = backend.count_users() == 0
    user = create_user(role="super_admin" if first_user else "user")

Two concurrent registrations both saw ``count_users() == 0`` and both
landed with ``role="super_admin"``. The fix routes both backends
through ``put_user_first_user_aware``, which serialises the
empty-check + insert under the backend's own lock (in-memory) or
``BEGIN IMMEDIATE`` (sqlite), upgrading exactly one user to
``role="super_admin"``.
"""

from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import UserState
from ctfy.core.state.sqlite import SQLiteBackend


def _user(user_id: str, email: str) -> UserState:
    return UserState(
        user_id=user_id,
        email=email,
        display_name=email,
        created_at="2026-01-01T00:00:00Z",
        role="user",
    )


def test_inmemory_only_one_user_wins_first_admin_under_concurrency():
    backend = InMemoryBackend()
    barrier = threading.Barrier(20)

    def _register(i: int) -> bool:
        barrier.wait()
        u = backend.put_user_first_user_aware(
            f"user-{i}", _user(f"user-{i}", f"u{i}@example.com")
        )
        return u.is_super_admin

    with ThreadPoolExecutor(max_workers=20) as ex:
        results = list(ex.map(_register, range(20)))

    admins = sum(results)
    assert admins == 1, (
        f"exactly one user must win the first-admin race; got {admins} super-admins "
        f"out of 20 concurrent registrations"
    )
    persisted = [u.is_super_admin for u in backend.list_users()]
    assert sum(persisted) == 1, "DB must reflect exactly one super-admin row"


def test_sqlite_only_one_user_wins_first_admin_under_concurrency(tmp_path):
    db_path = str(tmp_path / "race.sqlite3")
    backend = SQLiteBackend(db_path)
    barrier = threading.Barrier(20)

    def _register(i: int) -> bool:
        barrier.wait()
        u = backend.put_user_first_user_aware(
            f"user-{i}", _user(f"user-{i}", f"u{i}@example.com")
        )
        return u.is_super_admin

    with ThreadPoolExecutor(max_workers=20) as ex:
        results = list(ex.map(_register, range(20)))

    admins = sum(results)
    assert admins == 1, (
        f"sqlite: exactly one user must win the race; got {admins} super-admins"
    )
    fresh = SQLiteBackend(db_path)
    assert sum(u.is_super_admin for u in fresh.list_users()) == 1


def test_register_endpoint_first_user_only_admin(backend, mock_env_manager):
    """End-to-end through /auth/register — the SECOND register call must NOT
    grant super-admin even though it's a separate password registration."""
    from unittest.mock import patch

    from fastapi.testclient import TestClient

    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(backend):
        client = TestClient(app)
        r1 = client.post(
            "/api/v1/auth/register",
            json={"email": "first@example.com", "password": "correct-horse-2"},
        )
        assert r1.status_code == 200, r1.text
        r2 = client.post(
            "/api/v1/auth/register",
            json={"email": "second@example.com", "password": "correct-horse-2"},
        )
        assert r2.status_code == 200, r2.text

    users = sorted(backend.list_users(), key=lambda u: u.email)
    assert len(users) == 2
    assert users[0].email == "first@example.com"
    assert users[0].is_super_admin is True
    assert users[1].email == "second@example.com"
    assert users[1].is_super_admin is False
