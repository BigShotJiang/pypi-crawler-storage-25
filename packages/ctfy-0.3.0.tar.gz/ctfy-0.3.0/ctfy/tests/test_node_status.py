"""Pin the contract that ``emit_node_status`` pushes one heartbeat
sample per write, ``admin_only=True``, and reaches admin SSE clients
without leaking to members.

The signal lets the admin ``NodeStatusStrip`` drop its 30s
``/admin/nodes/{id}/health-history`` poll: every heartbeat (and every
reconciler-detected timeout) emits the freshest sample directly to
admin sessions, so the strip can append a slot in real time.
"""

from __future__ import annotations

import asyncio
import time
from unittest.mock import MagicMock

from ctfy.core.enums import PlatformEvent
from ctfy.core.state.models import NodeHealthSample, NodeState
from ctfy.server.app_state import AppState
from ctfy.server.node_status import emit_node_status
from ctfy.server.sse import SSEHub


def _sample(**overrides) -> NodeHealthSample:
    base = dict(
        node_id="n1",
        ts=time.time(),
        healthy=True,
        cpu_percent=12.0,
        memory_percent=34.0,
        disk_percent=56.0,
    )
    base.update(overrides)
    return NodeHealthSample(**base)


def _make_app() -> AppState:
    return AppState(
        config=MagicMock(),
        state_backend=MagicMock(),
        spec_reader=MagicMock(),
        sse_hub=SSEHub(),
        host="x",
        max_instances=10,
    )


def test_emit_node_status_broadcasts_admin_only():
    app = _make_app()
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_node_status(app, _sample())
    spy.assert_called_once()
    args, kwargs = spy.call_args
    assert args[0] == PlatformEvent.NODE_STATUS.value
    assert kwargs["admin_only"] is True
    assert kwargs["team_id"] == ""


def test_emit_node_status_payload_matches_sample():
    """Wire shape mirrors NodeHealthSample so the frontend can reuse
    its existing type without a parallel SSE-only schema."""
    app = _make_app()
    sample = _sample(node_id="abc", healthy=False, cpu_percent=99.5)
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_node_status(app, sample)
    data = spy.call_args.kwargs["data"]
    assert data["node_id"] == "abc"
    assert data["healthy"] is False
    assert data["cpu_percent"] == 99.5
    # Sample carries timing + load triplet.
    for k in ("ts", "memory_percent", "disk_percent"):
        assert k in data, f"missing {k} on node_status frame"


def test_admin_client_receives_node_status_member_does_not():
    """Routing contract end-to-end through the real hub: only admin
    clients pull the frame off their queue."""

    async def go():
        app = _make_app()
        app.sse_hub.set_loop(asyncio.get_running_loop())
        # Same team_id so the team-filter doesn't mask the admin_only
        # check we actually want to assert.
        _, member_q = app.sse_hub.connect(team_ids=frozenset({"t1"}), is_admin=False)
        _, admin_q = app.sse_hub.connect(team_ids=frozenset({"t1"}), is_admin=True)

        emit_node_status(app, _sample())

        admin_frame = await asyncio.wait_for(admin_q.get(), timeout=1)
        assert "event: node_status" in admin_frame
        try:
            await asyncio.wait_for(member_q.get(), timeout=0.2)
            raise AssertionError(
                "member queue received node_status — admin_only filter broken"
            )
        except asyncio.TimeoutError:
            pass

    asyncio.run(go())


def test_heartbeat_route_emits_node_status(client, admin_team):
    """Wiring at the heartbeat endpoint: every heartbeat adds a sample
    AND fires a node_status frame so the admin strip stays live."""
    app_state = client.app.state.ctfy
    spy = MagicMock(wraps=app_state.sse_hub.broadcast)
    app_state.sse_hub.broadcast = spy
    # Pre-register a node so the heartbeat handler can find it. The
    # heartbeat endpoint expects a registered node + matching token,
    # but the only thing we care about here is the SSE side-effect, so
    # we go through admin auth to bypass the per-node check.
    app_state.state_backend.put_node(
        "node-h",
        NodeState(
            node_id="node-h",
            url="http://node-h",
            display_name="Node H",
            capacity=4,
            healthy=True,
            last_heartbeat_ts=time.time(),
        ),
    )
    resp = client.post(
        "/api/v1/nodes/heartbeat",
        json={
            "node_id": "node-h",
            "running": 0,
            "capacity": 4,
            "cpu_percent": 12.0,
            "memory_percent": 34.0,
            "disk_percent": 56.0,
        },
        headers=admin_team.headers,
    )
    assert resp.status_code == 200, resp.text
    events = [c.args[0] for c in spy.call_args_list]
    assert PlatformEvent.NODE_STATUS.value in events, events
    node_call = next(
        c for c in spy.call_args_list if c.args[0] == PlatformEvent.NODE_STATUS.value
    )
    assert node_call.kwargs["admin_only"] is True
    assert node_call.kwargs["data"]["node_id"] == "node-h"
    assert node_call.kwargs["data"]["healthy"] is True
