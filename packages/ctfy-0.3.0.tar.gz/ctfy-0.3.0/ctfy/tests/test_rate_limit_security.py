"""Rate-limit regression tests for security-sensitive endpoints.

These cover #1 + #2 from the security audit:

* ``POST /verify-flag`` had no limiter at all, letting any agent token brute
  force candidate flags as a silent oracle (no submission record created).
* The shared limiter key was peer IP only, so a single token could
  round-robin across IPs to bypass per-IP caps.
"""

from __future__ import annotations

from unittest.mock import patch

from fastapi.testclient import TestClient

from ctfy.core.config import CtfyConfig
from ctfy.tests.conftest import (
    fake_node_context,
    make_mock_challenge_manager,
    mint_team,
    register_team,
    start_instance_and_wait,
)


def _build_app(backend, mock_mgr):
    from ctfy.server.app import create_app

    config = CtfyConfig(rate_limiting_enabled=True)
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_mgr):
        return create_app(config=config, external_host="10.0.1.5", backend=backend)


def test_verify_flag_endpoint_is_rate_limited(backend):
    """Eleventh /verify-flag in 60 s should 429 — without the fix the loop
    runs to completion and a leaked token can brute force candidates."""
    mock_mgr = make_mock_challenge_manager(
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        auto_generate_specs=True,
    )
    app = _build_app(backend, mock_mgr)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        client = TestClient(app)
        team = mint_team(backend, name="Brute", email="b@example.test")
        instance_id = start_instance_and_wait(
            client, "BRUTE-001", headers=team.headers
        )

        statuses = []
        for i in range(15):
            r = client.post(
                f"/api/v1/instances/{instance_id}/verify-flag",
                json={"claimed_flag": f"FLAG{{wrong-{i}}}"},
                headers=team.headers,
            )
            statuses.append(r.status_code)

    assert 200 in statuses, "expected at least one verify before the cap"
    assert 429 in statuses, "verify-flag must be rate-limited (audit #1)"


def test_login_endpoint_is_rate_limited(backend):
    """Eleventh /auth/login attempt in 60 s should 429 — defends against
    online password brute-force on top of argon2id offline cost."""
    mock_mgr = make_mock_challenge_manager()
    app = _build_app(backend, mock_mgr)
    with fake_node_context(backend):
        client = TestClient(app)

        statuses = [
            client.post(
                "/api/v1/auth/login",
                json={"email": "victim@example.com", "password": "wrong"},
            ).status_code
            for _ in range(15)
        ]

    assert 401 in statuses
    assert 429 in statuses, "login must be rate-limited (audit #2)"


def test_composite_key_isolates_distinct_tokens(backend):
    """One token's verify-flag bucket must NOT consume another token's quota.

    With the old IP-only key two teams behind the same TestClient peer
    would share one bucket. The composite (token, IP) key gives each
    token its own quota.
    """
    mock_mgr = make_mock_challenge_manager(
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        auto_generate_specs=True,
    )
    app = _build_app(backend, mock_mgr)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        client = TestClient(app)
        a = mint_team(backend, name="A", email="a@example.test")
        b = mint_team(backend, name="B", email="b@example.test")
        a_inst = start_instance_and_wait(client, "ISO-A", headers=a.headers)
        b_inst = start_instance_and_wait(client, "ISO-B", headers=b.headers)

        # Drain team A's quota.
        for i in range(15):
            client.post(
                f"/api/v1/instances/{a_inst}/verify-flag",
                json={"claimed_flag": f"FLAG{{wrong-{i}}}"},
                headers=a.headers,
            )
        # Team B should still be able to verify at least once.
        r = client.post(
            f"/api/v1/instances/{b_inst}/verify-flag",
            json={"claimed_flag": "FLAG{wrong}"},
            headers=b.headers,
        )

    assert r.status_code == 200, (
        "Team B's bucket must be independent of Team A's; got "
        f"{r.status_code} — composite key is not isolating tokens"
    )


def test_password_change_endpoint_is_rate_limited(backend):
    """A stolen user-kind token must not be able to brute-force ``current_password``
    on POST /auth/password. The endpoint verifies the existing password with
    argon2id (offline-cost defence) but absent a per-token cap an attacker
    could still enumerate at network speed."""
    mock_mgr = make_mock_challenge_manager()
    app = _build_app(backend, mock_mgr)
    with fake_node_context(backend):
        client = TestClient(app)
        token = register_team(
            client, email="victim@example.com", password="pw-correct-horse-2"
        )
        headers = {"Authorization": f"Bearer {token}"}

        statuses = [
            client.post(
                "/api/v1/auth/password",
                headers=headers,
                json={
                    "current_password": f"wrong-guess-{i}",
                    "new_password": "pw-new-horse-22",
                },
            ).status_code
            for i in range(10)
        ]

    assert 401 in statuses, "expected at least one 401 from a wrong current_password"
    assert 429 in statuses, "POST /auth/password must be rate-limited"
