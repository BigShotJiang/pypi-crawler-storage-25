"""Latency capture + downtime event lifecycle on node heartbeat.

Covers the new fields/events that power the admin Downtime history card:

* heartbeat handler stamps ``latency_ms`` from the node's ``sampled_at``
* heartbeat handler emits ``node_recovered`` when a previously unhealthy
  node beats again
* reconciler-detected timeout fills ``NodeUnhealthyPayload.error_message``
* ``GET /admin/nodes/{node_id}/events`` filters node-scoped activity
  rows by payload node_id and returns newest-first
"""

from __future__ import annotations

import time
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.enums import PlatformEvent
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import NodeState
from ctfy.tests.conftest import build_spec, make_mock_challenge_manager, mint_team


@pytest.fixture
def mock_env_manager():
    return make_mock_challenge_manager(
        challenge_specs=[build_spec("MN-001", name="MN")],
    )


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def admin(backend):
    return mint_team(backend, name="admin", email="admin@example.test", is_admin=True)


@pytest.fixture
def client(mock_env_manager, backend, admin):
    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    return TestClient(app)


def _register(client, admin):
    r = client.post(
        "/api/v1/nodes/register",
        json={"url": "http://n1:8100", "display_name": "n1"},
        headers=admin.headers,
    )
    assert r.status_code == 200, r.text
    return r.json()["node_id"]


def _heartbeat(client, admin, node_id, *, sampled_at=None, **metrics):
    body = {
        "node_id": node_id,
        "running": 0,
        "capacity": 5,
        "cpu_percent": 0.0,
        "memory_percent": 0.0,
        "disk_percent": 0.0,
        **metrics,
    }
    if sampled_at is not None:
        body["sampled_at"] = sampled_at
    return client.post("/api/v1/nodes/heartbeat", json=body, headers=admin.headers)


class TestLatency:
    def test_sampled_at_stored_as_latency_ms(self, client, backend, admin):
        node_id = _register(client, admin)
        # sampled_at is 200ms in the past — should land as roughly that
        # latency on the new sample (loose bound to absorb test runtime).
        assert _heartbeat(client, admin, node_id, sampled_at=time.time() - 0.2).status_code == 200
        samples = backend.list_health_samples(node_id)
        assert samples, "heartbeat must record a sample"
        assert 100.0 <= samples[-1].latency_ms <= 5000.0

    def test_missing_sampled_at_records_zero(self, client, backend, admin):
        node_id = _register(client, admin)
        # Old node body without sampled_at — server must default to 0.0.
        assert _heartbeat(client, admin, node_id).status_code == 200
        samples = backend.list_health_samples(node_id)
        assert samples[-1].latency_ms == 0.0


class TestRecoveryEvent:
    def test_recovery_event_emitted_after_unhealthy(self, client, backend, admin):
        node_id = _register(client, admin)
        # Force the node into an unhealthy state with a stale heartbeat
        # so the next beat triggers the recovery branch.
        node = backend.get_node(node_id)
        backend.put_node(
            node_id,
            node.model_copy(
                update={"healthy": False, "last_heartbeat_ts": time.time() - 600}
            ),
        )
        assert _heartbeat(client, admin, node_id).status_code == 200

        rows = backend.list_activities(
            events=(PlatformEvent.NODE_RECOVERED.value,),
            limit=10,
        )
        assert len(rows) == 1
        assert rows[0].detail.node_id == node_id
        # downtime_seconds is the gap between the stale last_heartbeat
        # and the recovery beat (~600s); allow generous slack.
        assert (rows[0].detail.downtime_seconds or 0) >= 500.0

    def test_no_recovery_event_when_already_healthy(self, client, backend, admin):
        node_id = _register(client, admin)
        # Node is healthy at registration; subsequent heartbeats must
        # not emit NODE_RECOVERED.
        assert _heartbeat(client, admin, node_id).status_code == 200
        rows = backend.list_activities(
            events=(PlatformEvent.NODE_RECOVERED.value,), limit=10
        )
        assert rows == []


class TestReconcilerErrorMessage:
    def test_unhealthy_event_carries_error_message(self, backend):
        from ctfy.core.challenge import ChallengeManager
        from ctfy.core.config import CtfyConfig
        from ctfy.core.constants import HEARTBEAT_TIMEOUT
        from ctfy.server.app_state import AppState
        from ctfy.server.events import emit_event
        from ctfy.server.event_payloads import NodeUnhealthyPayload
        from ctfy.server.sse import SSEHub

        cfg = CtfyConfig()
        backend.put_node(
            "n1",
            NodeState(
                node_id="n1",
                url="http://n1",
                last_heartbeat_ts=time.time() - 600,
                healthy=True,
            ),
        )
        app_state = AppState(
            config=cfg,
            state_backend=backend,
            spec_reader=ChallengeManager(cfg),
            sse_hub=SSEHub(),
            host="127.0.0.1",
            max_instances=10,
        )

        # Mirror the reconciler's emit path with a non-empty error_message
        # so the downtime card has something to render.
        emit_event(
            app_state,
            NodeUnhealthyPayload(
                node_id="n1",
                url="http://n1",
                error_message=f"No heartbeat for 600.0s (timeout {HEARTBEAT_TIMEOUT}s)",
            ),
            actor_id="system",
            actor_name="reconciler",
            actor_type="system",
        )

        rows = backend.list_activities(
            events=(PlatformEvent.NODE_UNHEALTHY.value,), limit=5
        )
        assert len(rows) == 1
        assert "No heartbeat" in (rows[0].detail.error_message or "")


class TestNodeEventsEndpoint:
    def test_filters_to_node_id_and_orders_newest_first(self, client, backend, admin):
        # Register two nodes so we can prove the endpoint filters out the
        # other node's activity rows. Each registration emits one
        # NODE_REGISTERED row.
        node_a = _register(client, admin)
        r = client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n2:8100", "display_name": "n2"},
            headers=admin.headers,
        )
        node_b = r.json()["node_id"]

        # Drive node_a unhealthy then healthy → produces UNHEALTHY +
        # RECOVERED rows, both keyed to node_a.
        node = backend.get_node(node_a)
        backend.put_node(
            node_a,
            node.model_copy(
                update={"healthy": False, "last_heartbeat_ts": time.time() - 600}
            ),
        )
        # Manually emit unhealthy by writing the activity row directly —
        # the reconciler isn't running in tests and the FastAPI test
        # client doesn't expose AppState publicly.
        from ctfy.core.activity import ActivityDetail
        from ctfy.core.state.models import ActivityState

        backend.add_activity(
            ActivityState(
                event=PlatformEvent.NODE_UNHEALTHY.value,
                actor_id="system",
                actor_name="reconciler",
                actor_type="system",
                detail=ActivityDetail(
                    node_id=node_a,
                    url="http://n1",
                    error_message="boom",
                ),
            )
        )
        assert _heartbeat(client, admin, node_a).status_code == 200

        r = client.get(f"/api/v1/admin/nodes/{node_a}/events", headers=admin.headers)
        assert r.status_code == 200
        rows = r.json()
        events = [row["event"] for row in rows]
        # Newest-first: most recent activity is the recovery beat.
        assert events[0] == PlatformEvent.NODE_RECOVERED.value
        # All rows belong to node_a.
        assert all(row["detail"]["node_id"] == node_a for row in rows)
        # node_b's rows are absent.
        assert all(row["detail"]["node_id"] != node_b for row in rows)
        # We expect at least registered + unhealthy + recovered for node_a.
        assert {
            PlatformEvent.NODE_REGISTERED.value,
            PlatformEvent.NODE_UNHEALTHY.value,
            PlatformEvent.NODE_RECOVERED.value,
        }.issubset(set(events))

    def test_requires_admin(self, client):
        r = client.get("/api/v1/admin/nodes/foo/events")
        assert r.status_code in (401, 403)
