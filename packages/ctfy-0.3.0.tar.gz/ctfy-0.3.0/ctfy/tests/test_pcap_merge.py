"""Tests for ``ctfy.server.pcap_merge``."""

from __future__ import annotations

import struct

import pytest

from ctfy.server.pcap_merge import merge_pcaps


# Standard libpcap header: little-endian, microsecond resolution,
# snaplen=65535, linktype=LINKTYPE_LINUX_SLL2 (276) — what tcpdump
# writes for ``-i any`` on Linux. Tests construct fake records on top
# of this so we don't need real packet captures on disk.
_LE_USEC_MAGIC = b"\xd4\xc3\xb2\xa1"
_LE_USEC_HDR_LINKTYPE_276 = (
    _LE_USEC_MAGIC
    + struct.pack("<HHIIII", 2, 4, 0, 0, 65535, 276)
)
_LE_USEC_HDR_LINKTYPE_1 = (
    _LE_USEC_MAGIC
    + struct.pack("<HHIIII", 2, 4, 0, 0, 65535, 1)
)


def _record(payload: bytes, ts_sec: int = 0, ts_usec: int = 0) -> bytes:
    """Synthesize a single libpcap record (16-byte header + payload)."""
    return (
        struct.pack("<IIII", ts_sec, ts_usec, len(payload), len(payload))
        + payload
    )


def _write_pcap(path, header: bytes, records: list[bytes]) -> None:
    path.write_bytes(header + b"".join(records))


def test_merge_two_homogeneous_pcaps_concatenates_records(tmp_path):
    a = tmp_path / "a.pcap"
    b = tmp_path / "b.pcap"
    _write_pcap(a, _LE_USEC_HDR_LINKTYPE_276, [_record(b"hello", 1, 0)])
    _write_pcap(b, _LE_USEC_HDR_LINKTYPE_276, [_record(b"world", 2, 0)])

    merged = merge_pcaps([a, b])
    # Same single header, then both record bodies in order.
    assert merged.startswith(_LE_USEC_HDR_LINKTYPE_276)
    body = merged[len(_LE_USEC_HDR_LINKTYPE_276):]
    assert body == _record(b"hello", 1, 0) + _record(b"world", 2, 0)


def test_merge_drops_files_with_mismatched_linktype(tmp_path):
    """Different linktypes can't be merged under one header — Wireshark
    would render the alien records as garbage. The merger keeps the
    files matching the first file's linktype and silently drops the
    rest."""
    a = tmp_path / "a.pcap"
    b = tmp_path / "b.pcap"
    _write_pcap(a, _LE_USEC_HDR_LINKTYPE_276, [_record(b"AAAA")])
    _write_pcap(b, _LE_USEC_HDR_LINKTYPE_1, [_record(b"BBBB")])

    merged = merge_pcaps([a, b])
    assert merged.startswith(_LE_USEC_HDR_LINKTYPE_276)
    assert _record(b"AAAA") in merged
    assert _record(b"BBBB") not in merged


def test_merge_skips_empty_and_missing(tmp_path):
    real = tmp_path / "real.pcap"
    empty = tmp_path / "empty.pcap"
    missing = tmp_path / "missing.pcap"
    _write_pcap(real, _LE_USEC_HDR_LINKTYPE_276, [_record(b"x")])
    empty.write_bytes(b"")  # zero-byte file, not a pcap
    # ``missing`` is not created at all.

    merged = merge_pcaps([empty, missing, real])
    assert merged.startswith(_LE_USEC_HDR_LINKTYPE_276)
    assert _record(b"x") in merged


def test_merge_empty_input_returns_empty(tmp_path):
    assert merge_pcaps([]) == b""
    assert merge_pcaps([tmp_path / "nope.pcap"]) == b""


def test_merge_falls_back_to_largest_when_first_lacks_magic(tmp_path):
    """If the first usable file isn't a real pcap (corruption /
    overwritten), we hand back the largest candidate as-is rather than
    emitting something Wireshark would refuse."""
    bad = tmp_path / "bad.pcap"
    good = tmp_path / "good.pcap"
    bad.write_bytes(b"\x00" * 100)  # not a pcap, but big enough to pass the size gate
    _write_pcap(good, _LE_USEC_HDR_LINKTYPE_276, [_record(b"yo")])

    merged = merge_pcaps([bad, good])
    # The bad file is bigger (100 bytes vs ~46 for good) so the fallback
    # picks it. We don't assert the bytes here — just that the function
    # doesn't raise and returns something non-empty.
    assert len(merged) > 0


def test_merge_preserves_record_order_within_files(tmp_path):
    a = tmp_path / "a.pcap"
    _write_pcap(
        a,
        _LE_USEC_HDR_LINKTYPE_276,
        [_record(b"first", 1, 0), _record(b"second", 2, 0)],
    )
    merged = merge_pcaps([a])
    assert merged == a.read_bytes()


def test_merge_handles_big_endian_magic(tmp_path):
    """tcpdump writes whatever endianness the host CPU uses. The merger
    has to read the magic to decide how to read the linktype field — a
    big-endian capture should round-trip just like a little-endian one."""
    be_magic = b"\xa1\xb2\xc3\xd4"
    be_header = be_magic + struct.pack(">HHIIII", 2, 4, 0, 0, 65535, 276)
    a = tmp_path / "a.pcap"
    a.write_bytes(be_header + struct.pack(">IIII", 1, 0, 1, 1) + b"X")
    merged = merge_pcaps([a])
    assert merged == a.read_bytes()
