"""Competitions: backend + public + admin routes + leaderboard scoping.

Covers:
    * Backend ``list_competitions(phase=...)``, registration CRUD, and
      delete-cascade across InMemoryBackend + SQLiteBackend.
    * Admin CRUD: auth gating, challenge-id validation, window validation.
    * Public register / unregister: idempotency + after-window rejection.
    * Competition scoreboard scoping: only registered teams, only
      curated challenges, only post-registration solves.
    * Global ``/scoreboard`` unchanged by competition activity.
"""

from __future__ import annotations

import os
import tempfile
import time
from datetime import datetime, timedelta, timezone
from unittest.mock import patch
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

from ctfy.core.enums import Difficulty
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import (
    CompetitionState,
    SolveState,
    SubmissionState,
)
from ctfy.core.state.sqlite import SQLiteBackend
from ctfy.tests.conftest import (
    build_spec,
    make_mock_challenge_manager,
    mint_team,
)


def _iso(offset_seconds: int = 0) -> str:
    """ISO 8601 string ``offset_seconds`` from now (UTC, +00:00)."""
    return (datetime.now(timezone.utc) + timedelta(seconds=offset_seconds)).isoformat()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def world():
    """TestClient + backend + admin team. Two challenges in the spec
    registry: ``c1`` (curated into competitions) and ``c2`` (used to
    verify the curated subset really filters)."""
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    mgr = make_mock_challenge_manager(
        challenge_specs=[
            build_spec("c1", name="Chall One"),
            build_spec("c2", name="Chall Two"),
            build_spec("c3", name="Chall Three"),
        ],
        auto_generate_specs=False,
    )
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    admin = mint_team(
        backend,
        name="admin",
        email="admin@example.test",
        is_admin=True,
        seed_competition=False,
    )
    yield TestClient(app), backend, admin


def _player(client: TestClient, name: str = "Player"):
    backend = client.app.state.ctfy.state_backend
    return mint_team(
        backend,
        name=name,
        email=f"{name.lower()}@example.test",
        seed_competition=False,
    )


def _register_solo(backend, *, user_id: str, competition_id: str) -> str:
    """Create a Solo per-comp team for ``user_id`` in ``competition_id``
    via the atomic backend op + return the resulting team_id. Mirrors
    what ``POST /api/v1/competitions/{id}/teams {mode: "solo"}`` does
    server-side; tests that just need a registered team can skip the
    HTTP round-trip."""
    team = backend.create_team_for_competition(
        user_id=user_id,
        competition_id=competition_id,
        team_name="Solo",
        now_iso=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )
    return team.team_id


def _create_comp(
    client: TestClient,
    admin,
    *,
    title: str = "Test CTF",
    starts_at: str = "",
    ends_at: str = "",
    challenge_ids: list[str] | None = None,
) -> str:
    payload = {
        "title": title,
        "description": "x",
        "starts_at": starts_at,
        "ends_at": ends_at,
        "challenge_ids": challenge_ids if challenge_ids is not None else ["c1"],
    }
    r = client.post(
        "/api/v1/admin/competitions", json=payload, headers=admin.headers
    )
    assert r.status_code == 201, r.text
    return r.json()["competition_id"]


# ---------------------------------------------------------------------------
# Public list / detail
# ---------------------------------------------------------------------------


class TestPublicEndpoints:
    def test_list_endpoint_is_public(self, world):
        client, _, _ = world
        r = client.get("/api/v1/competitions")
        assert r.status_code == 200
        assert r.json()["items"] == []

    def test_phase_filter(self, world):
        """``phase`` evaluates server-side against now."""
        client, _, admin = world
        _create_comp(
            client, admin, title="upcoming",
            starts_at=_iso(3600), ends_at=_iso(7200),
        )
        running_id = _create_comp(
            client, admin, title="running",
            starts_at=_iso(-3600), ends_at=_iso(3600),
        )
        _create_comp(
            client, admin, title="past",
            starts_at=_iso(-7200), ends_at=_iso(-3600),
        )

        upcoming = client.get("/api/v1/competitions?phase=upcoming").json()["items"]
        running = client.get("/api/v1/competitions?phase=running").json()["items"]
        past = client.get("/api/v1/competitions?phase=past").json()["items"]

        assert {c["title"] for c in upcoming} == {"upcoming"}
        assert {c["title"] for c in running} == {"running"}
        assert [c["competition_id"] for c in running] == [running_id]
        assert {c["title"] for c in past} == {"past"}
        # phase echoed back on the row
        assert running[0]["phase"] == "running"

    def test_detail_resolves_challenges_in_curated_order(self, world):
        client, _, admin = world
        cid = _create_comp(client, admin, challenge_ids=["c2", "c1"])
        body = client.get(f"/api/v1/competitions/{cid}").json()
        ids = [c["id"] for c in body["challenges"]]
        # Preserves admin's curated order.
        assert ids == ["c2", "c1"]
        assert body["registered_count"] == 0
        assert body["is_registered"] is False

    def test_detail_404_when_unknown(self, world):
        client, _, _ = world
        r = client.get("/api/v1/competitions/does-not-exist")
        assert r.status_code == 404

    def test_detail_drops_unknown_challenge_ids(self, world):
        """Spec ids that vanish between create and detail just disappear."""
        client, backend, admin = world
        cid = _create_comp(client, admin, challenge_ids=["c1"])
        # Inject a stale id directly on the row (skip admin write
        # validation to simulate a spec rev that removed ``c-gone``).
        comp = backend.get_competition(cid)
        backend.put_competition(
            comp.model_copy(update={"challenge_ids": ["c1", "c-gone"]})
        )
        body = client.get(f"/api/v1/competitions/{cid}").json()
        ids = [c["id"] for c in body["challenges"]]
        assert ids == ["c1"]


# ---------------------------------------------------------------------------
# Admin CRUD
# ---------------------------------------------------------------------------


class TestAdminCrud:
    def test_create_requires_admin(self, world):
        client, _, _ = world
        r = client.post(
            "/api/v1/admin/competitions",
            json={"title": "x", "description": "", "challenge_ids": []},
        )
        assert r.status_code in (401, 403)
        team = _player(client)
        r = client.post(
            "/api/v1/admin/competitions",
            json={"title": "x", "description": "", "challenge_ids": []},
            headers=team.headers,
        )
        assert r.status_code in (401, 403)

    def test_create_validates_challenge_ids(self, world):
        client, _, admin = world
        r = client.post(
            "/api/v1/admin/competitions",
            json={
                "title": "bad",
                "description": "",
                "challenge_ids": ["c1", "no-such-challenge"],
            },
            headers=admin.headers,
        )
        assert r.status_code == 422
        assert "no-such-challenge" in r.text

    def test_create_rejects_duplicate_challenge_ids(self, world):
        client, _, admin = world
        r = client.post(
            "/api/v1/admin/competitions",
            json={
                "title": "dup",
                "description": "",
                "challenge_ids": ["c1", "c1"],
            },
            headers=admin.headers,
        )
        assert r.status_code == 422

    def test_create_rejects_inverted_window(self, world):
        client, _, admin = world
        r = client.post(
            "/api/v1/admin/competitions",
            json={
                "title": "broken",
                "description": "",
                "starts_at": _iso(3600),
                "ends_at": _iso(60),
                "challenge_ids": [],
            },
            headers=admin.headers,
        )
        assert r.status_code == 422

    def test_create_round_trips(self, world):
        client, backend, admin = world
        r = client.post(
            "/api/v1/admin/competitions",
            json={
                "title": "Spring CTF",
                "description": "# Welcome",
                "starts_at": _iso(-60),
                "ends_at": _iso(3600),
                "challenge_ids": ["c1", "c2"],
            },
            headers=admin.headers,
        )
        assert r.status_code == 201, r.text
        body = r.json()
        assert body["title"] == "Spring CTF"
        assert body["challenge_ids"] == ["c1", "c2"]
        assert body["created_by"] == admin.user_id
        cid = body["competition_id"]
        stored = backend.get_competition(cid)
        assert stored is not None
        assert stored.challenge_ids == ["c1", "c2"]

    def test_update_partial_preserves_other_fields(self, world):
        client, _, admin = world
        cid = _create_comp(client, admin, title="v1", challenge_ids=["c1"])
        r = client.patch(
            f"/api/v1/admin/competitions/{cid}",
            json={"title": "v2"},
            headers=admin.headers,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["title"] == "v2"
        assert body["challenge_ids"] == ["c1"]

    def test_update_rejects_inverted_post_merge_window(self, world):
        client, _, admin = world
        cid = _create_comp(
            client, admin,
            starts_at=_iso(60), ends_at=_iso(3600),
        )
        # Push starts_at past the existing ends_at.
        r = client.patch(
            f"/api/v1/admin/competitions/{cid}",
            json={"starts_at": _iso(7200)},
            headers=admin.headers,
        )
        assert r.status_code == 422

    def test_update_unknown_returns_404(self, world):
        client, _, admin = world
        r = client.patch(
            "/api/v1/admin/competitions/ghost",
            json={"title": "x"},
            headers=admin.headers,
        )
        assert r.status_code == 404

    def test_delete_round_trip(self, world):
        client, backend, admin = world
        cid = _create_comp(client, admin)
        r = client.delete(
            f"/api/v1/admin/competitions/{cid}", headers=admin.headers
        )
        assert r.status_code == 200
        assert backend.get_competition(cid) is None
        # Idempotent on repeat: 404.
        r2 = client.delete(
            f"/api/v1/admin/competitions/{cid}", headers=admin.headers
        )
        assert r2.status_code == 404

    def test_admin_list_includes_past_and_future(self, world):
        client, _, admin = world
        _create_comp(client, admin, title="past",
                     starts_at=_iso(-7200), ends_at=_iso(-3600))
        _create_comp(client, admin, title="upcoming",
                     starts_at=_iso(3600), ends_at=_iso(7200))
        r = client.get(
            "/api/v1/admin/competitions", headers=admin.headers
        )
        assert r.status_code == 200
        titles = {c["title"] for c in r.json()["items"]}
        assert titles == {"past", "upcoming"}

# ---------------------------------------------------------------------------
# Scoreboard scoping — the heart of the feature
# ---------------------------------------------------------------------------


def _add_solve(backend, team_id: str, challenge_id: str, *, when: str, flag_id: str = "main"):
    backend.add_solve(
        team_id, challenge_id, flag_id,
        SolveState(
            team_id=team_id,
            challenge_id=challenge_id,
            flag_id=flag_id,
            solved_at=when,
            solve_time_s=1.0,
            attempts=1,
        ),
    )
    backend.add_submission(
        SubmissionState(
            submission_id=uuid4().hex,
            team_id=team_id,
            challenge_id=challenge_id,
            claimed_flag="x",
            correct=True,
            flag_id=flag_id,
            submitted_at=when,
        )
    )


class TestCompetitionScoreboard:
    def test_unregistered_team_invisible_on_competition_scoreboard(self, world):
        client, backend, admin = world
        cid = _create_comp(
            client, admin, challenge_ids=["c1"],
            starts_at=_iso(-3600), ends_at=_iso(3600),
        )
        registered = _player(client, "Alice")
        unregistered = _player(client, "Bob")
        # Per the per-comp team refactor: "registered" = has a comp
        # team. ``_register_solo`` mints one for ``registered`` only.
        registered_team_id = _register_solo(
            backend, user_id=registered.user_id, competition_id=cid
        )
        # Both solve c1 inside the window. Solves for the registered
        # user are stamped to the per-comp team_id; the unregistered
        # user's solves are stamped to their (legacy / un-comp) team
        # — invisible on the per-comp board.
        _add_solve(backend, registered_team_id, "c1", when=_iso(0))
        _add_solve(backend, unregistered.team_id, "c1", when=_iso(0))

        comp_sb = client.get(
            f"/api/v1/competitions/{cid}/scoreboard"
        ).json()["items"]
        ids = {r["team_id"] for r in comp_sb}
        assert ids == {registered_team_id}

        # Global scoreboard sees both teams.
        global_sb = client.get("/api/v1/scoreboard").json()["items"]
        ids_g = {r["team_id"] for r in global_sb}
        assert {registered_team_id, unregistered.team_id} <= ids_g

    def test_pre_registration_solve_excluded(self, world):
        """Solves stamped before the per-comp team existed must not
        boost the comp board (the team's created_at floors the
        per-team solve window)."""
        client, backend, admin = world
        cid = _create_comp(
            client, admin, challenge_ids=["c1"],
            starts_at=_iso(-7200), ends_at=_iso(7200),
        )
        team = _player(client)
        # Register first so the per-comp team exists.
        per_comp_team_id = _register_solo(
            backend, user_id=team.user_id, competition_id=cid
        )
        # Stamp a solve dated before the per-comp team was created.
        _add_solve(backend, per_comp_team_id, "c1", when=_iso(-3600))
        # Bump the per-comp team's created_at forward (mid-event-join
        # case).
        comp_team = backend.get_team(per_comp_team_id)
        backend.put_team(
            per_comp_team_id,
            comp_team.model_copy(update={"created_at": _iso(0)}),
        )
        comp_sb = client.get(
            f"/api/v1/competitions/{cid}/scoreboard"
        ).json()["items"]
        row = next((r for r in comp_sb if r["team_id"] == per_comp_team_id), None)
        assert row is not None
        assert row["flags_solved"] == 0

    def test_post_registration_solve_counted(self, world):
        client, backend, admin = world
        cid = _create_comp(
            client, admin, challenge_ids=["c1"],
            starts_at=_iso(-7200), ends_at=_iso(7200),
        )
        team = _player(client)
        per_comp_team_id = _register_solo(
            backend, user_id=team.user_id, competition_id=cid
        )
        # Solve after registration.
        _add_solve(backend, per_comp_team_id, "c1", when=_iso(60))
        comp_sb = client.get(
            f"/api/v1/competitions/{cid}/scoreboard"
        ).json()["items"]
        row = next(r for r in comp_sb if r["team_id"] == per_comp_team_id)
        assert row["flags_solved"] == 1
        assert row["solved"] == 1

    def test_user_moving_teams_mid_competition(self, world):
        """Solves stay credited to whichever per-comp team_id was
        stamped on the SolveState at write time. A user moving from
        team A to team B mid-event leaves the c1 solve on A and
        their c2 solve on B."""
        client, backend, admin = world
        cid = _create_comp(
            client, admin, challenge_ids=["c1", "c2"],
            starts_at=_iso(-7200), ends_at=_iso(7200),
        )
        cap_a = _player(client, "CapA")
        cap_b = _player(client, "CapB")
        team_a_id = _register_solo(
            backend, user_id=cap_a.user_id, competition_id=cid
        )
        team_b_id = _register_solo(
            backend, user_id=cap_b.user_id, competition_id=cid
        )
        # Solve c1 while team A's roster (just A's captain).
        _add_solve(backend, team_a_id, "c1", when=_iso(60))
        # Solve c2 stamped against team B.
        _add_solve(backend, team_b_id, "c2", when=_iso(120))

        sb = client.get(
            f"/api/v1/competitions/{cid}/scoreboard"
        ).json()["items"]
        rows_by_team = {r["team_id"]: r for r in sb}
        assert rows_by_team[team_a_id]["flags_solved"] == 1
        assert rows_by_team[team_b_id]["flags_solved"] == 1

    def test_solve_outside_window_excluded(self, world):
        client, backend, admin = world
        cid = _create_comp(
            client, admin, challenge_ids=["c1"],
            starts_at=_iso(-60), ends_at=_iso(3600),
        )
        team = _player(client)
        per_comp_team_id = _register_solo(
            backend, user_id=team.user_id, competition_id=cid
        )
        # Solve four hours after the window closes.
        _add_solve(backend, per_comp_team_id, "c1", when=_iso(4 * 3600))
        comp_sb = client.get(
            f"/api/v1/competitions/{cid}/scoreboard"
        ).json()["items"]
        row = next(r for r in comp_sb if r["team_id"] == per_comp_team_id)
        assert row["flags_solved"] == 0

    def test_challenge_not_in_subset_excluded(self, world):
        client, backend, admin = world
        cid = _create_comp(
            client, admin, challenge_ids=["c1"],
            starts_at=_iso(-3600), ends_at=_iso(3600),
        )
        team = _player(client)
        per_comp_team_id = _register_solo(
            backend, user_id=team.user_id, competition_id=cid
        )
        # Solve a non-curated challenge.
        _add_solve(backend, per_comp_team_id, "c2", when=_iso(0))
        comp_sb = client.get(
            f"/api/v1/competitions/{cid}/scoreboard"
        ).json()["items"]
        row = next(r for r in comp_sb if r["team_id"] == per_comp_team_id)
        assert row["flags_solved"] == 0

    def test_global_scoreboard_unchanged_by_competition_filters(self, world):
        """Refactor regression: filter parametrisation must leave the
        global, no-filter path identical to the old behaviour."""
        client, backend, admin = world
        team = _player(client)
        _add_solve(backend, team.team_id, "c1", when=_iso(0))
        body = client.get("/api/v1/scoreboard").json()["items"]
        row = next(r for r in body if r["team_id"] == team.team_id)
        assert row["flags_solved"] == 1
        assert row["solved"] == 1


# ---------------------------------------------------------------------------
# SSE broadcast — admin CRUD pings every connected client.
# ---------------------------------------------------------------------------


class TestSSEBroadcast:
    def _spy(self, client: TestClient):
        from unittest.mock import MagicMock

        hub = client.app.state.ctfy.sse_hub
        spy = MagicMock(wraps=hub.broadcast)
        hub.broadcast = spy
        return spy

    def test_create_broadcasts(self, world):
        client, _, admin = world
        spy = self._spy(client)
        _create_comp(client, admin)
        events = [c.args[0] for c in spy.call_args_list]
        assert "competition_created" in events

    def test_update_broadcasts(self, world):
        client, _, admin = world
        cid = _create_comp(client, admin)
        spy = self._spy(client)
        client.patch(
            f"/api/v1/admin/competitions/{cid}",
            json={"title": "v2"},
            headers=admin.headers,
        )
        assert "competition_updated" in [c.args[0] for c in spy.call_args_list]

    def test_delete_broadcasts(self, world):
        client, _, admin = world
        cid = _create_comp(client, admin)
        spy = self._spy(client)
        client.delete(
            f"/api/v1/admin/competitions/{cid}", headers=admin.headers
        )
        assert "competition_deleted" in [c.args[0] for c in spy.call_args_list]

    def test_404_delete_does_not_broadcast(self, world):
        client, _, admin = world
        spy = self._spy(client)
        client.delete(
            "/api/v1/admin/competitions/ghost", headers=admin.headers
        )
        assert "competition_deleted" not in [c.args[0] for c in spy.call_args_list]


# ---------------------------------------------------------------------------
# Backend filter logic — guard against InMemory / SQLite drift.
# ---------------------------------------------------------------------------


@pytest.fixture(params=["memory", "sqlite"])
def comp_backend(request):
    if request.param == "memory":
        yield InMemoryBackend()
        return
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        yield SQLiteBackend(path)
    finally:
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass


class TestBackendBehaviour:
    def test_phase_filter_matches(self, comp_backend):
        backend = comp_backend
        now = _iso(0)
        live = CompetitionState(
            competition_id="live", title="live",
            starts_at=_iso(-60), ends_at=_iso(60),
            created_at=now, updated_at=now,
        )
        upcoming = CompetitionState(
            competition_id="up", title="upcoming",
            starts_at=_iso(3600), ends_at=_iso(7200),
            created_at=now, updated_at=now,
        )
        past = CompetitionState(
            competition_id="past", title="past",
            starts_at=_iso(-7200), ends_at=_iso(-3600),
            created_at=now, updated_at=now,
        )
        for c in (live, upcoming, past):
            backend.put_competition(c)

        assert {c.competition_id for c in backend.list_competitions(
            phase="running", now_iso=now,
        )} == {"live"}
        assert {c.competition_id for c in backend.list_competitions(
            phase="upcoming", now_iso=now,
        )} == {"up"}
        assert {c.competition_id for c in backend.list_competitions(
            phase="past", now_iso=now,
        )} == {"past"}
        assert {c.competition_id for c in backend.list_competitions()} == {
            "live", "up", "past",
        }

    def test_unbounded_competition_is_running(self, comp_backend):
        """A competition with empty starts_at AND empty ends_at is the
        permanent practice mode shape — should classify as running."""
        backend = comp_backend
        now = _iso(0)
        backend.put_competition(CompetitionState(
            competition_id="forever", title="forever",
            starts_at="", ends_at="",
            created_at=now, updated_at=now,
        ))
        running = {c.competition_id for c in backend.list_competitions(
            phase="running", now_iso=now,
        )}
        assert running == {"forever"}

    def test_delete_competition_idempotent(self, comp_backend):
        """Per the per-comp team refactor, delete_competition removes
        only the competition row. Per-comp teams (which carry the
        registration semantics now) are cleaned up via the team
        lifecycle ops."""
        backend = comp_backend
        now = _iso(0)
        backend.put_competition(CompetitionState(
            competition_id="c", title="t", created_at=now, updated_at=now,
        ))
        assert backend.delete_competition("c") is True
        assert backend.delete_competition("c") is False
