"""``GET /activities?since=&until=`` time-range filter.

Closes the audit gap that the activity feed exposed event/team/actor
filters but no time-range filter — surveys after a competition need
"events between 14:00 and 15:00 on day 2", not just "everything for
this team newest first".
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import ActivityState
from ctfy.tests.conftest import build_spec, make_mock_challenge_manager, mint_team


@pytest.fixture
def mock_env_manager():
    return make_mock_challenge_manager(
        challenge_specs=[build_spec("ACT-001", name="ACT")],
    )


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def caller(backend):
    return mint_team(backend, name="caller", email="c@example.test")


@pytest.fixture
def client(mock_env_manager, backend, caller):
    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    return TestClient(app)


def _seed(backend, *, user_id: str, team_id: str) -> None:
    """Seed a known list of activities at distinct ISO timestamps,
    actored by ``user_id`` so /activities (user-scoped) picks them up.
    """
    timestamps = [
        "2026-04-25T08:00:00.000Z",  # before any window
        "2026-04-25T10:00:00.000Z",  # window left edge
        "2026-04-25T11:30:00.000Z",  # interior
        "2026-04-25T13:00:00.000Z",  # window right edge
        "2026-04-25T15:00:00.000Z",  # after any window
    ]
    for i, ts in enumerate(timestamps):
        backend.add_activity(
            ActivityState(
                id=f"a{i}",
                timestamp=ts,
                event="flag_correct",
                team_id=team_id,
                team_name="caller",
                user_id=user_id,
                actor_id=user_id,
                actor_name="caller",
                actor_type="team",
                challenge_id="ACT-001",
                detail={},
            )
        )


def test_since_only_returns_rows_at_or_after_bound(client, caller, backend):
    _seed(backend, user_id=caller.user_id, team_id=caller.team_id)
    r = client.get(
        "/api/v1/activities",
        params={"since": "2026-04-25T11:00:00.000Z"},
        headers=caller.headers,
    )
    assert r.status_code == 200
    items = r.json()["items"]
    timestamps = sorted(a["timestamp"] for a in items)
    # 11:30, 13:00, 15:00 — three rows.
    assert timestamps == [
        "2026-04-25T11:30:00.000Z",
        "2026-04-25T13:00:00.000Z",
        "2026-04-25T15:00:00.000Z",
    ]
    assert r.json()["total"] == 3


def test_until_only_returns_rows_at_or_before_bound(client, caller, backend):
    _seed(backend, user_id=caller.user_id, team_id=caller.team_id)
    r = client.get(
        "/api/v1/activities",
        params={"until": "2026-04-25T11:00:00.000Z"},
        headers=caller.headers,
    )
    assert r.status_code == 200
    timestamps = sorted(a["timestamp"] for a in r.json()["items"])
    assert timestamps == [
        "2026-04-25T08:00:00.000Z",
        "2026-04-25T10:00:00.000Z",
    ]
    assert r.json()["total"] == 2


def test_since_and_until_return_inclusive_window(client, caller, backend):
    _seed(backend, user_id=caller.user_id, team_id=caller.team_id)
    r = client.get(
        "/api/v1/activities",
        params={
            "since": "2026-04-25T10:00:00.000Z",
            "until": "2026-04-25T13:00:00.000Z",
        },
        headers=caller.headers,
    )
    assert r.status_code == 200
    timestamps = sorted(a["timestamp"] for a in r.json()["items"])
    # Both endpoints inclusive: 10:00 + 11:30 + 13:00.
    assert timestamps == [
        "2026-04-25T10:00:00.000Z",
        "2026-04-25T11:30:00.000Z",
        "2026-04-25T13:00:00.000Z",
    ]
    assert r.json()["total"] == 3


def test_filter_combines_with_event_param(client, caller, backend):
    _seed(backend, user_id=caller.user_id, team_id=caller.team_id)
    # Add a non-matching event in the same window so we can prove the
    # event filter still applies on top of the time range.
    backend.add_activity(
        ActivityState(
            id="other",
            timestamp="2026-04-25T11:00:00.000Z",
            event="instance_started",
            team_id=caller.team_id,
            team_name="caller",
            actor_id=caller.team_id,
            actor_name="caller",
            actor_type="team",
            challenge_id="ACT-001",
            detail={},
        )
    )
    r = client.get(
        "/api/v1/activities",
        params={
            "event": "flag_correct",
            "since": "2026-04-25T10:00:00.000Z",
            "until": "2026-04-25T13:00:00.000Z",
        },
        headers=caller.headers,
    )
    assert r.status_code == 200
    events = {a["event"] for a in r.json()["items"]}
    assert events == {"flag_correct"}
    assert r.json()["total"] == 3
