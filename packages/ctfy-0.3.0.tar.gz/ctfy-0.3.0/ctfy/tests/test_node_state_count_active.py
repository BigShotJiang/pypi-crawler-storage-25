"""``NodeInstanceStore.count_active`` excludes terminal-status rows.

Regression: the node was reporting stale ERROR / STOPPED records as part of
its ``running`` heartbeat counter, so the admin Nodes page showed a node at
``10 / 10`` (100% utilisation) even when no containers were actually running.
``count_active`` is what the heartbeat reports — it must only count rows that
correspond to a live container (STARTING or READY).
"""

from __future__ import annotations

from ctfy.core.enums import InstanceStatus
from ctfy.server.node_state import NodeInstanceRecord, NodeInstanceStore


def _put(store: NodeInstanceStore, instance_id: str, status: InstanceStatus) -> None:
    store.put(
        NodeInstanceRecord(
            instance_id=instance_id,
            challenge_id="WEB-001",
            status=status.value,
            started_at=0.0,
            ttl=0,
        )
    )


class TestCountActive:
    def test_counts_only_starting_and_ready(self, tmp_path):
        store = NodeInstanceStore(tmp_path / "node.db")
        _put(store, "a", InstanceStatus.STARTING)
        _put(store, "b", InstanceStatus.READY)
        _put(store, "c", InstanceStatus.ERROR)
        _put(store, "d", InstanceStatus.STOPPED)

        # Total rows still includes the terminal ones — the store keeps them
        # around so /status can return a useful status instead of 404.
        assert store.count() == 4
        # But utilisation only reflects rows that own a real container.
        assert store.count_active() == 2

    def test_empty_store(self, tmp_path):
        store = NodeInstanceStore(tmp_path / "node.db")
        assert store.count_active() == 0

    def test_all_terminal_reports_zero(self, tmp_path):
        """The bug: 10 ERROR rows should not look like 10 running containers."""
        store = NodeInstanceStore(tmp_path / "node.db")
        for i in range(10):
            _put(store, f"i-{i}", InstanceStatus.ERROR)
        assert store.count() == 10
        assert store.count_active() == 0
