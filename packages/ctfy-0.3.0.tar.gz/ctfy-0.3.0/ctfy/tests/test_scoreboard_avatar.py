"""Scoreboard ``avatar_url`` enrichment.

Closes the audit gap that the scoreboard table couldn't render team
avatars because ``ScoreboardEntry`` didn't carry one. The route now
joins each team against its OAuth identities and picks the earliest
binding's ``avatar_url``:

* GitHub-only team → GitHub avatar
* Google-only team → Google avatar
* Both providers bound → whichever was bound first (by ``created_at``)
* Password-only / no identities → empty string (frontend renders a
  generated initials chip)
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import OAuthIdentity
from ctfy.tests.conftest import build_spec, make_mock_challenge_manager, mint_team


@pytest.fixture
def mock_env_manager():
    return make_mock_challenge_manager(
        challenge_specs=[build_spec("AVA-001", name="AVA")],
    )


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def client(mock_env_manager, backend):
    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    return TestClient(app)


def _bind(backend, user_id: str, provider: str, avatar: str, created_at: str) -> None:
    backend.put_identity(
        OAuthIdentity(
            identity_id=f"{user_id}-{provider}",
            user_id=user_id,
            provider=provider,  # type: ignore[arg-type]
            provider_user_id=f"{provider}-uid-{user_id}",
            provider_email=f"{provider}@example.test",
            avatar_url=avatar,
            created_at=created_at,
        )
    )


def _entry_for(items: list[dict], team_id: str) -> dict:
    matches = [i for i in items if i["team_id"] == team_id]
    assert matches, f"team {team_id} not in scoreboard"
    return matches[0]


def test_password_only_team_has_empty_avatar(client, backend):
    """No OAuth identities → empty avatar_url; the frontend will draw
    initials."""
    mint_team(backend, name="passwd-team", email="p@example.test")
    r = client.get("/api/v1/scoreboard")
    assert r.status_code == 200
    items = r.json()["items"]
    assert items
    assert all(it["avatar_url"] == "" for it in items)


def test_github_only_team_uses_github_avatar(client, backend):
    team = mint_team(backend, name="gh-only", email="gh@example.test")
    _bind(backend, team.user_id, "github", "https://gh.example/avatar.png", "2026-04-01T00:00:00.000Z")
    r = client.get("/api/v1/scoreboard")
    entry = _entry_for(r.json()["items"], team.team_id)
    assert entry["avatar_url"] == "https://gh.example/avatar.png"


def test_google_only_team_uses_google_avatar(client, backend):
    team = mint_team(backend, name="g-only", email="g@example.test")
    _bind(backend, team.user_id, "google", "https://g.example/avatar.png", "2026-04-01T00:00:00.000Z")
    r = client.get("/api/v1/scoreboard")
    entry = _entry_for(r.json()["items"], team.team_id)
    assert entry["avatar_url"] == "https://g.example/avatar.png"


def test_both_providers_bound_returns_earliest_binding(client, backend):
    """A team with both GitHub and Google bound shows the avatar of the
    one that was bound first."""
    team = mint_team(backend, name="dual", email="d@example.test")
    _bind(backend, team.user_id, "github", "https://gh.example/late.png", "2026-04-15T00:00:00.000Z")
    _bind(backend, team.user_id, "google", "https://g.example/early.png", "2026-04-01T00:00:00.000Z")
    r = client.get("/api/v1/scoreboard")
    entry = _entry_for(r.json()["items"], team.team_id)
    assert entry["avatar_url"] == "https://g.example/early.png"


def test_legacy_identity_with_empty_created_at_does_not_win(client, backend):
    """Rows pre-dating ``created_at`` (empty string) sort *last* so
    they don't accidentally win the "earliest binding" tiebreak."""
    team = mint_team(backend, name="legacy-mix", email="lm@example.test")
    # Legacy GitHub row with no created_at — should NOT be picked.
    _bind(backend, team.user_id, "github", "https://gh.example/legacy.png", "")
    # Properly stamped Google row.
    _bind(backend, team.user_id, "google", "https://g.example/proper.png", "2026-04-10T00:00:00.000Z")
    r = client.get("/api/v1/scoreboard")
    entry = _entry_for(r.json()["items"], team.team_id)
    assert entry["avatar_url"] == "https://g.example/proper.png"


def test_first_binding_without_avatar_falls_through(client, backend):
    """If the earliest binding has no avatar (provider hadn't returned
    one), the picker walks to the next-oldest binding that does."""
    team = mint_team(backend, name="no-pic-first", email="np@example.test")
    _bind(backend, team.user_id, "google", "", "2026-04-01T00:00:00.000Z")
    _bind(backend, team.user_id, "github", "https://gh.example/has.png", "2026-04-15T00:00:00.000Z")
    r = client.get("/api/v1/scoreboard")
    entry = _entry_for(r.json()["items"], team.team_id)
    assert entry["avatar_url"] == "https://gh.example/has.png"
