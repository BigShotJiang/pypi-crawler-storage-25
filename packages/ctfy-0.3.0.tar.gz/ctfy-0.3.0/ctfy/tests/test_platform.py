"""Tests for the CTF platform.

Covers teams, submissions, scoreboard, instance lifecycle, flag verification,
TTL renew, auth, and the async start+poll path. Uses FastAPI TestClient with
a mocked ChallengeManager and a fake worker node.
"""

import time
import uuid
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.config import CtfyConfig
from ctfy.core.state import InMemoryBackend
from ctfy.tests.conftest import (
    fake_node_context,
    make_mock_challenge_manager,
    mint_team,
    start_instance_and_wait,
)


def _mint(client, name="Team", *, is_admin=False, email=""):
    """Convenience wrapper — short-circuits OAuth by inserting directly.

    Mirrors the old ``POST /teams`` response shape (``token`` +
    ``team_id``) so existing test bodies don't need to change.
    """
    backend = client.app.state.ctfy.state_backend
    minted = mint_team(
        backend,
        name=name,
        email=email or f"{name.lower().replace(' ', '-')}@example.test",
        is_admin=is_admin,
    )
    return {"team_id": minted.team_id, "name": name, "token": minted.token}


# -- Team registration ------------------------------------------------------


class TestTeams:
    def test_public_registration_endpoint_removed(self, client):
        """``POST /api/v1/teams`` no longer exists — teams are provisioned via OAuth."""
        resp = client.post(
            "/api/v1/teams",
            json={"name": "Team Alpha"},
        )
        assert resp.status_code in (404, 405)

    def test_list_teams(self, client):
        _mint(client, "A")
        _mint(client, "B")
        resp = client.get("/api/v1/teams")
        assert resp.status_code == 200
        assert len(resp.json()["items"]) == 2

    def test_get_team(self, client):
        t = _mint(client, "Solo")
        resp = client.get(f"/api/v1/teams/{t['team_id']}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "Solo"

    def test_get_team_404(self, client):
        assert client.get("/api/v1/teams/nonexistent").status_code == 404


# -- Challenges --------------------------------------------------------------


class TestChallenges:
    def test_list_challenges(self, client):
        resp = client.get("/api/v1/challenges")
        assert resp.status_code == 200
        challenges = resp.json()["items"]
        assert len(challenges) == 6
        assert challenges[0]["id"] == "WEB-001"


# -- Submissions & flag verification ----------------------------------------


class TestSubmissions:
    def _setup(self, client):
        """Register team and start instance with auth."""
        team = _mint(client, "Hackers")
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "WEB-001", headers=auth)
        return team, instance_id

    def test_correct_flag(self, client):
        team, instance_id = self._setup(client)
        resp = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team['token']}"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["correct"] is True
        assert data["solve_time_s"] >= 0

    def test_wrong_flag(self, client):
        team, instance_id = self._setup(client)
        resp = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{wrong}",
            },
            headers={"Authorization": f"Bearer {team['token']}"},
        )
        assert resp.json()["correct"] is False

    def test_no_auth_401(self, client):
        resp = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": "00000000-0000-0000-0000-000000000000",
                "flag": "x",
            },
        )
        assert resp.status_code == 401

    def test_bad_key_403(self, client):
        resp = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": "00000000-0000-0000-0000-000000000000",
                "flag": "x",
            },
            headers={"Authorization": "Bearer invalid_key"},
        )
        assert resp.status_code == 403

    def test_second_team_solve(self, client):
        team1, instance1 = self._setup(client)
        team2 = _mint(client, "Team2")
        auth2 = {"Authorization": f"Bearer {team2['token']}"}
        instance2 = start_instance_and_wait(client, "WEB-001", headers=auth2)

        # Team 1 solves first
        r = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance1,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team1['token']}"},
        )
        assert r.json()["correct"] is True

        # Team 2 solves second
        r = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance2,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth2,
        )
        assert r.json()["correct"] is True
        assert r.json()["solve_time_s"] >= 0


# -- Scoreboard -------------------------------------------------------------


class TestScoreboard:
    def _setup_two_teams(self, client):
        team1 = _mint(client, "Alpha")
        team2 = _mint(client, "Beta")

        auth1 = {"Authorization": f"Bearer {team1['token']}"}
        auth2 = {"Authorization": f"Bearer {team2['token']}"}
        instance1 = start_instance_and_wait(client, "WEB-001", headers=auth1)
        instance2 = start_instance_and_wait(client, "WEB-001", headers=auth2)
        return (team1, instance1), (team2, instance2)

    def test_scoreboard_ranking(self, client):
        (team1, instance1), (team2, instance2) = self._setup_two_teams(client)

        # Team1 solves WEB-001
        client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance1,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team1['token']}"},
        )

        # Team2 fails
        client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance2,
                "flag": "FLAG{wrong}",
            },
            headers={"Authorization": f"Bearer {team2['token']}"},
        )

        resp = client.get("/api/v1/scoreboard")
        assert resp.status_code == 200
        board = resp.json()["items"]
        assert board[0]["team_name"] == "Alpha"
        assert board[0]["solved"] == 1
        assert board[0]["rank"] == 1


# -- Full lifecycle E2E ------------------------------------------------------


class TestFullLifecycle:
    def test_register_start_solve_scoreboard(self, client):
        """Complete flow: register → start instance → submit flag → check scoreboard."""
        # 1. Register (via the test-time backend shortcut; OAuth is exercised elsewhere)
        team = _mint(client, "Champion")
        auth = {"Authorization": f"Bearer {team['token']}"}

        # 2. Start instance (async) with auth + wait until ready
        instance_id = start_instance_and_wait(client, "WEB-001", headers=auth)

        # 3. Submit flag
        r = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        assert r.json()["correct"] is True

        # 4. Scoreboard
        r = client.get("/api/v1/scoreboard")
        board = r.json()["items"]
        assert board[0]["team_name"] == "Champion"
        assert board[0]["solved"] == 1

        # 5. Team stats
        r = client.get(f"/api/v1/teams/{team['team_id']}")
        assert r.json()["solves"] == 1


# -- Challenge stats (GET /scoreboard/challenges) ----------------------------


class TestChallengeStats:
    def _setup(self, client):
        team = _mint(client, "Stats")
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "WEB-001", headers=auth)
        return team, instance_id

    def test_challenge_stats_endpoint(self, client):
        """GET /scoreboard/challenges returns per-challenge data."""
        team, instance_id = self._setup(client)
        # Submit a correct + a wrong flag
        auth = {"Authorization": f"Bearer {team['token']}"}
        client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{wrong}",
            },
            headers=auth,
        )
        client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )

        r = client.get("/api/v1/scoreboard/challenges")
        assert r.status_code == 200
        stats = r.json()["items"]
        assert len(stats) == 6
        web001 = next(s for s in stats if s["challenge_id"] == "WEB-001")
        assert web001["solves_count"] == 1
        assert web001["total_attempts"] == 2

    def test_challenge_stats_no_submissions(self, client):
        r = client.get("/api/v1/scoreboard/challenges")
        assert r.status_code == 200
        for s in r.json()["items"]:
            assert s["solves_count"] == 0


# -- Scoreboard edge cases ---------------------------------------------------


class TestScoreboardEdgeCases:
    def test_empty_scoreboard(self, client):
        r = client.get("/api/v1/scoreboard")
        assert r.status_code == 200
        assert r.json()["items"] == []

    def test_rate_limit_returns_429(self, mock_env_manager, backend):
        """Scoreboard is expensive to compute; hammering it should 429 eventually.

        Rate limiting is off by default — this test explicitly opts in via
        ``CtfyConfig(rate_limiting_enabled=True)`` so the global switch stays
        disabled for every other test.
        """
        from ctfy.server.app import create_app

        config = CtfyConfig(rate_limiting_enabled=True)
        with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
            app = create_app(config=config, external_host="10.0.1.5", backend=backend)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            rl_client = TestClient(app)
            # 30/minute is the per-endpoint cap; request #31 must be rejected.
            statuses = [rl_client.get("/api/v1/scoreboard").status_code for _ in range(31)]
        assert 200 in statuses
        assert 429 in statuses

    def test_team_with_zero_solves(self, client):
        _mint(client, "Noob")
        r = client.get("/api/v1/scoreboard")
        board = r.json()["items"]
        assert len(board) == 1
        assert board[0]["solved"] == 0

    def test_tiebreak_by_last_solve(self, client):
        """Same solve count → earlier last_solve wins."""
        team1 = _mint(client, "Fast")
        team2 = _mint(client, "Slow")
        auth1 = {"Authorization": f"Bearer {team1['token']}"}
        auth2 = {"Authorization": f"Bearer {team2['token']}"}
        instance1 = start_instance_and_wait(client, "WEB-001", headers=auth1)
        instance2 = start_instance_and_wait(client, "WEB-001", headers=auth2)

        # Both solve WEB-001, team1 first
        client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance1,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team1['token']}"},
        )

        client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance2,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team2['token']}"},
        )

        r = client.get("/api/v1/scoreboard")
        board = r.json()["items"]
        # Both have 1 solve; first solver should rank higher (earlier last_solve_at)
        assert board[0]["team_name"] == "Fast"
        assert board[1]["team_name"] == "Slow"


# -- Submission edge cases ---------------------------------------------------


class TestSubmissionEdgeCases:
    def _setup(self, client):
        team = _mint(client, "Hacker")
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "WEB-001", headers=auth)
        return team, instance_id

    def test_duplicate_solve_no_double_count(self, client):
        """Solving same challenge twice should only count as 1 solve.
        After first correct submission, instance is auto-destroyed, so the
        second submission returns 404."""
        team, instance_id = self._setup(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        flag = "FLAG{deadbeef0123456789abcdef01234567}"

        r1 = client.post(
            "/api/v1/submissions",
            json={"instance_id": instance_id, "flag": flag},
            headers=auth,
        )
        assert r1.json()["correct"] is True

        # Instance is auto-destroyed after first solve; allow
        # the background auto-stop thread to complete.

        time.sleep(0.1)

        r2 = client.post(
            "/api/v1/submissions",
            json={"instance_id": instance_id, "flag": flag},
            headers=auth,
        )
        # Instance was auto-destroyed, so second submission gets 404
        assert r2.status_code == 404

        # Should still be 1 solve
        info = client.get(f"/api/v1/teams/{team['team_id']}").json()
        assert info["solves"] == 1

    def test_submit_no_instance_404(self, client):
        """Submitting flag against an unknown instance_id should 404."""
        team = _mint(client, "NoEnv")
        r = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": "00000000-0000-0000-0000-000000000000",
                "flag": "FLAG{x}",
            },
            headers={"Authorization": f"Bearer {team['token']}"},
        )
        assert r.status_code == 404

    def test_solve_time_positive(self, client):
        """Solve time should be > 0 for correct submissions."""
        team, instance_id = self._setup(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        r = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        assert r.json()["correct"] is True
        assert r.json()["solve_time_s"] >= 0

    def test_restart_after_solve_allowed(self, client):
        """Starting a new instance for an already-solved challenge should succeed."""
        team, instance_id = self._setup(client)
        auth = {"Authorization": f"Bearer {team['token']}"}

        # Solve the challenge
        r = client.post(
            "/api/v1/submissions",
            json={"instance_id": instance_id, "flag": "FLAG{deadbeef0123456789abcdef01234567}"},
            headers=auth,
        )
        assert r.json()["correct"] is True

        time.sleep(0.1)  # allow auto-stop thread to finish

        # Restart after solve — should be allowed for re-evaluation
        r2 = client.post(
            "/api/v1/instances",
            json={"challenge_id": "WEB-001"},
            headers=auth,
        )
        assert r2.status_code in (200, 201, 202)

    def test_relaunch_after_solve_autostops_on_resubmit(self, client):
        """Re-launching a solved challenge and re-submitting the correct flag
        must auto-stop the new instance, just like the first solve did.

        Regression: previously the auto-stop guard required the submission to
        record a *new* SolveState row, so a re-submit on the second instance
        (where the team's solve already exists from instance #1) was skipped
        and the new instance kept running indefinitely.
        """
        team, first_instance = self._setup(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        flag = "FLAG{deadbeef0123456789abcdef01234567}"

        # First solve — instance is auto-destroyed.
        r1 = client.post(
            "/api/v1/submissions",
            json={"instance_id": first_instance, "flag": flag},
            headers=auth,
        )
        assert r1.json()["correct"] is True
        for _ in range(30):
            if client.get(
                f"/api/v1/instances/{first_instance}/status",
                headers=auth,
            ).status_code == 404:
                break
            time.sleep(0.1)
        else:
            pytest.fail("first instance should have been auto-stopped")

        # Re-launch + resubmit the same correct flag.
        second_instance = start_instance_and_wait(client, "WEB-001", headers=auth)
        r2 = client.post(
            "/api/v1/submissions",
            json={"instance_id": second_instance, "flag": flag},
            headers=auth,
        )
        assert r2.json()["correct"] is True
        # On a re-submit, no fresh Solve row is recorded.
        assert r2.json()["solve_rank"] == 0
        # ...but the instance should still auto-stop because the challenge is
        # fully solved.
        for _ in range(30):
            if client.get(
                f"/api/v1/instances/{second_instance}/status",
                headers=auth,
            ).status_code == 404:
                break
            time.sleep(0.1)
        else:
            pytest.fail("relaunched instance should have been auto-stopped")


# -- Capacity limit -----------------------------------------------------------


class TestCapacityLimit:
    def test_503_when_full(self, mock_env_manager, backend):
        """Server should return 503 when at capacity."""
        from ctfy.server.app import create_app

        with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend, max_instances=1)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            team = _mint(c, "cap")
            auth = {"Authorization": f"Bearer {team['token']}"}

            # Start first instance (succeeds)
            r = c.post(
                "/api/v1/instances",
                json={
                    "challenge_id": "E1",
                    "ttl": 300,
                },
                headers=auth,
            )
            assert r.status_code == 202

            # Wait for it to be recorded
            import time

            time.sleep(0.5)

            # Start second instance (should fail with 503)
            r = c.post(
                "/api/v1/instances",
                json={
                    "challenge_id": "E2",
                    "ttl": 300,
                },
                headers=auth,
            )
            assert r.status_code == 503


# -- Challenge filtering -----------------------------------------------------


class TestChallengeFiltering:
    def test_filter_by_category(self, client):
        r = client.get("/api/v1/challenges?category=web")
        assert r.status_code == 200
        for c in r.json()["items"]:
            assert c["category"] == "web"

    def test_get_challenge_404(self, client):
        r = client.get("/api/v1/challenges/NONEXISTENT")
        assert r.status_code == 404


# -- Activity log ------------------------------------------------------------


class TestActivityLog:
    def test_activities_recorded_on_team_register(self, client):
        """OAuth login path records a team_registered activity.

        We drive the full OAuth flow via the fake provider, then
        Solo-register for the test competition — the team_registered
        event fires on per-comp registration now (the act of forming
        a team), not on the OAuth callback itself.
        """
        from ctfy.core.state.models import CompetitionState
        from ctfy.tests.conftest import TEST_COMPETITION_ID, oauth_login

        token = oauth_login(client, "github", email="logger@example.test")
        auth = {"Authorization": f"Bearer {token}"}
        backend = client.app.state.ctfy.state_backend
        if backend.get_competition(TEST_COMPETITION_ID) is None:
            backend.put_competition(
                CompetitionState(
                    competition_id=TEST_COMPETITION_ID,
                    title="Test",
                    created_at="2026-01-01T00:00:00Z",
                )
            )
        client.post(
            f"/api/v1/competitions/{TEST_COMPETITION_ID}/teams",
            json={"mode": "solo"},
            headers=auth,
        )
        r = client.get("/api/v1/activities?event=team_registered", headers=auth)
        assert r.status_code == 200
        acts = r.json()["items"]
        assert len(acts) >= 1
        assert acts[0]["event"] == "team_registered"
        assert isinstance(acts[0]["detail"], dict)

    def test_activities_recorded_on_flag_submit(self, client):
        team = _mint(client, "A")
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "WEB-001", headers=auth)
        client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        r = client.get("/api/v1/activities?event=flag_correct", headers=auth)
        assert len(r.json()["items"]) >= 1

    def test_activities_filter(self, client):
        """Activity log supports filtering by event type."""
        team = _mint(client, "X")
        auth = {"Authorization": f"Bearer {team['token']}"}
        all_acts = client.get("/api/v1/activities", headers=auth).json()["items"]
        team_acts = client.get(
            "/api/v1/activities?event=team_registered", headers=auth
        ).json()["items"]
        assert len(team_acts) <= len(all_acts)

    def test_instance_lifecycle_events(self, client):
        team = _mint(client, "evt")
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "WEB-001", headers=auth)
        client.delete(f"/api/v1/instances/{instance_id}", headers=auth)
        acts = client.get("/api/v1/activities", headers=auth).json()["items"]
        events = [a["event"] for a in acts]
        assert "instance_started" in events
        assert "instance_stopped" in events


# ============================================================================
# HTTP API surface — health, instance lifecycle, verify-flag, renew, auth.
# Uses an auto-spec-generating mock so tests can pick arbitrary challenge IDs.
# ============================================================================


@pytest.fixture
def auto_mock_env_manager():
    return make_mock_challenge_manager(
        flag="FLAG{deadbeef0123456789abcdef01234567}",
    )


@pytest.fixture
def auto_client(auto_mock_env_manager):
    """Authenticated TestClient: auto-registers a default team and pins its
    bearer token as a session-wide header so POST /instances (now
    auth-only) works without every test re-registering."""
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        c = TestClient(app)
        team = _mint(c, "auto")
        c.headers["Authorization"] = f"Bearer {team['token']}"
        yield c


@pytest.fixture
def auto_client_anon(auto_mock_env_manager):
    """Unauthenticated TestClient for tests that need to exercise the
    anonymous rejection path."""
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        yield TestClient(app)


def _start_and_wait(c, challenge_id="TEST-001", *, max_wait=5, headers=None):
    """POST /instances + poll /status until ready. Returns (status_resp, id)."""
    resp = c.post(
        "/api/v1/instances",
        json={"challenge_id": challenge_id, "ttl": 300},
        headers=headers or {},
    )
    if resp.status_code == 409:
        return resp, None
    assert resp.status_code == 202
    instance_id = resp.json()["instance_id"]
    deadline = time.monotonic() + max_wait
    while time.monotonic() < deadline:
        s = c.get(f"/api/v1/instances/{instance_id}/status", headers=headers or {})
        if s.json().get("status") == "ready":
            return s, instance_id
        if s.json().get("status") == "error":
            raise RuntimeError(s.json().get("error"))
        time.sleep(0.1)
    raise TimeoutError(f"{instance_id} not ready after {max_wait}s")


class TestHealth:
    def test_health(self, auto_client):
        resp = auto_client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["running_instances"] == 0
        assert data["capacity"] > 0


class TestMeta:
    def test_meta_public(self, client, admin_team):
        # No auth header — ``/meta`` feeds the status bar for guests too.
        resp = client.get("/api/v1/meta")
        assert resp.status_code == 200
        data = resp.json()
        expected_keys = {
            "version",
            "platform",
            "challenges",
            "started_at_ts",
            "server_time_ts",
            "teams_total",
            "nodes_total",
            "nodes_healthy",
            "running_instances",
            "solves_total",
        }
        assert expected_keys <= set(data)
        assert isinstance(data["version"], str) and data["version"]
        assert data["server_time_ts"] >= data["started_at_ts"] > 0
        # Nested groups carry the per-repo identity + (for challenges) the
        # public count. ``commit_sha`` may be None in hermetic envs but
        # the keys themselves must always be present.
        assert {"commit_sha", "commit_url", "repo_url"} <= set(data["platform"])
        assert {"commit_sha", "commit_url", "repo_url", "total"} <= set(data["challenges"])
        assert data["challenges"]["total"] >= 1  # TEST-001 fixture
        # nodes_healthy / nodes_total are admin-only — verify the
        # invariant under an admin token instead of the anonymous one.
        admin_data = client.get("/api/v1/meta", headers=admin_team.headers).json()
        assert admin_data["nodes_healthy"] <= admin_data["nodes_total"]

    def test_meta_repo_url_default(self, client):
        # Default points at the upstream repo so the status-bar's
        # "Source" link always works even on fresh deploys.
        data = client.get("/api/v1/meta").json()
        assert data["platform"]["repo_url"] == "https://github.com/wangyihang/ctfy"

    def test_meta_commit_absent_when_not_configured(self, client, monkeypatch):
        # Without ``CTFY_GIT_COMMIT`` and without a usable git binary
        # the meta endpoint should advertise ``commit_sha = None`` and
        # ``commit_url = None`` instead of inventing a value.
        # Force the subprocess fallback to fail so the test is hermetic
        # — the dev tree obviously has git available, but production
        # containers don't, and that's the codepath we're pinning.
        import ctfy.server.routes.meta as meta_module

        def _no_git(*_a, **_k):
            raise FileNotFoundError("git not installed")

        monkeypatch.setattr(meta_module.subprocess, "run", _no_git)
        data = client.get("/api/v1/meta").json()
        assert data["platform"]["commit_sha"] is None
        assert data["platform"]["commit_url"] is None

    def test_meta_emits_commit_url_when_configured(self, client):
        app_state = client.app.state.ctfy
        sha = "abc1234567890abcdef1234567890abcdef123456"
        app_state.config.git_commit = sha
        data = client.get("/api/v1/meta").json()
        assert data["platform"]["commit_sha"] == sha
        assert data["platform"]["commit_url"] == (
            f"https://github.com/wangyihang/ctfy/commit/{sha}"
        )

    def test_meta_uses_custom_repo_url(self, client):
        app_state = client.app.state.ctfy
        app_state.config.repo_url = "https://github.com/example/fork"
        app_state.config.git_commit = "deadbeefdeadbeefdeadbeefdeadbeefdeadbeef"
        data = client.get("/api/v1/meta").json()
        assert data["platform"]["repo_url"] == "https://github.com/example/fork"
        assert data["platform"]["commit_url"] == (
            "https://github.com/example/fork/commit/"
            "deadbeefdeadbeefdeadbeefdeadbeefdeadbeef"
        )

    def test_meta_challenges_commit_when_dir_is_git(self, client, tmp_path):
        # Operators want a one-glance answer to "which version of the
        # challenges set is loaded?". When the challenges dir is a real
        # git working tree, /meta surfaces its HEAD sha and the GitHub
        # link computed from challenges_repo.
        import subprocess as sp

        repo = tmp_path / "challenges"
        repo.mkdir()
        # Disable any environment-level commit signing so the test is
        # hermetic and doesn't depend on the developer's gpg setup.
        env = {**__import__("os").environ, "GIT_CONFIG_GLOBAL": "/dev/null"}
        sp.run(["git", "init", "-q"], cwd=repo, check=True, env=env)
        sp.run(["git", "config", "user.email", "t@t"], cwd=repo, check=True, env=env)
        sp.run(["git", "config", "user.name", "t"], cwd=repo, check=True, env=env)
        sp.run(["git", "config", "commit.gpgsign", "false"], cwd=repo, check=True, env=env)
        sp.run(
            ["git", "commit", "--allow-empty", "-q", "-m", "init"],
            cwd=repo, check=True, env=env,
        )
        head = sp.run(
            ["git", "rev-parse", "HEAD"], cwd=repo, capture_output=True, text=True, check=True, env=env,
        ).stdout.strip()

        app_state = client.app.state.ctfy
        app_state.config.challenges_dir = repo
        app_state.config.challenges_repo = "https://github.com/CTF-Arena/challenges.git"

        data = client.get("/api/v1/meta").json()
        assert data["challenges"]["commit_sha"] == head
        # ``.git`` suffix is stripped so the link points at the GitHub
        # web view, not at the clone URL.
        assert data["challenges"]["commit_url"] == (
            f"https://github.com/CTF-Arena/challenges/commit/{head}"
        )
        assert data["challenges"]["repo_url"] == (
            "https://github.com/CTF-Arena/challenges.git"
        )

    def test_meta_challenges_commit_absent_when_not_a_repo(self, client, tmp_path):
        # If the challenges dir doesn't exist or isn't a git working
        # tree, /meta advertises null rather than inventing a value.
        app_state = client.app.state.ctfy
        app_state.config.challenges_dir = tmp_path / "missing"
        data = client.get("/api/v1/meta").json()
        assert data["challenges"]["commit_sha"] is None
        assert data["challenges"]["commit_url"] is None

    def test_meta_anonymous_omits_admin_only_counters(self, client):
        # Guests / non-admin members must not learn cluster-wide
        # capacity from /meta. The fields are returned as null so the
        # frontend can distinguish "not authorised" from "empty".
        data = client.get("/api/v1/meta").json()
        for k in (
            "teams_total",
            "nodes_total",
            "nodes_healthy",
            "running_instances",
            "solves_total",
        ):
            assert data[k] is None, f"{k} should be hidden from anonymous callers"

    def test_meta_member_omits_admin_only_counters(self, client, backend):
        team = mint_team(backend, name="Member", email="member@example.com")
        data = client.get("/api/v1/meta", headers=team.headers).json()
        assert data["teams_total"] is None
        assert data["nodes_total"] is None
        assert data["nodes_healthy"] is None
        assert data["running_instances"] is None
        assert data["solves_total"] is None

    def test_meta_admin_sees_admin_only_counters(self, client, admin_team):
        data = client.get("/api/v1/meta", headers=admin_team.headers).json()
        # Even when zero, admins get the integer (0), not None — the
        # presence of the number itself is what tells the frontend it's
        # authorised to render the segment.
        for k in (
            "teams_total",
            "nodes_total",
            "nodes_healthy",
            "running_instances",
            "solves_total",
        ):
            assert isinstance(data[k], int), f"admin must see {k} as an int, got {data[k]!r}"

    def test_meta_public_fields_unchanged_by_role(self, client, admin_team, backend):
        member = mint_team(backend, name="Member", email="member2@example.com")
        anon = client.get("/api/v1/meta").json()
        member_view = client.get("/api/v1/meta", headers=member.headers).json()
        admin_view = client.get("/api/v1/meta", headers=admin_team.headers).json()
        # Public block (version, platform identity, challenges identity +
        # total) should look identical regardless of who's asking.
        for k in ("version", "platform", "challenges"):
            assert anon[k] == member_view[k] == admin_view[k]

    def test_meta_strips_trailing_slash_in_repo_url(self, client):
        # Operators sometimes paste a URL with a trailing slash; the
        # resulting commit URL shouldn't have a doubled slash.
        app_state = client.app.state.ctfy
        app_state.config.repo_url = "https://github.com/example/fork/"
        app_state.config.git_commit = "deadbeefdeadbeefdeadbeefdeadbeefdeadbeef"
        data = client.get("/api/v1/meta").json()
        assert data["platform"]["commit_url"] == (
            "https://github.com/example/fork/commit/"
            "deadbeefdeadbeefdeadbeefdeadbeefdeadbeef"
        )


class TestLifecycle:
    def test_start_returns_202(self, auto_client):
        resp = auto_client.post(
            "/api/v1/instances",
            json={"challenge_id": "TEST-001", "ttl": 300},
        )
        assert resp.status_code == 202
        data = resp.json()
        uuid.UUID(data["instance_id"])
        assert data["status"] == "starting"

    def test_status_becomes_ready(self, auto_client):
        s, _ = _start_and_wait(auto_client)
        data = s.json()
        assert data["status"] == "ready"
        assert data["attack_surface"] is not None
        assert data["attack_surface"]["services"][0]["host"] == "10.0.1.5"

    def test_flag_not_in_response(self, auto_client):
        resp = auto_client.post(
            "/api/v1/instances",
            json={"challenge_id": "TEST-002", "ttl": 300},
        )
        assert "flag" not in resp.json()

    def test_start_duplicate_creates_separate_instance(self, auto_client):
        """0.2 lifts the (team, challenge) uniqueness rule: two
        concurrent starts of the same challenge by the same team mint
        two distinct instances. Replaces the old 409-on-duplicate
        behaviour."""
        first = _start_and_wait(auto_client, "DUP-001")
        resp = auto_client.post(
            "/api/v1/instances",
            json={"challenge_id": "DUP-001", "ttl": 300},
        )
        assert resp.status_code == 202
        second = resp.json()["instance_id"]
        assert second != first

    def test_start_anonymous_forbidden(self, auto_client_anon):
        resp = auto_client_anon.post(
            "/api/v1/instances",
            json={"challenge_id": "TEST-001", "ttl": 300},
        )
        # HTTPBearer(auto_error=True) returns 403 via HTTPException, but
        # FastAPI's default maps no-credential Bearer to 401.
        assert resp.status_code in (401, 403)

    def test_concurrent_same_challenge_different_teams(self, auto_mock_env_manager):
        """Two authenticated teams may launch the same challenge concurrently."""
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            t1 = _mint(c, "A")
            t2 = _mint(c, "B")
            h1 = {"Authorization": f"Bearer {t1['token']}"}
            h2 = {"Authorization": f"Bearer {t2['token']}"}

            r1 = c.post(
                "/api/v1/instances",
                json={"challenge_id": "CONC-001", "ttl": 300},
                headers=h1,
            )
            r2 = c.post(
                "/api/v1/instances",
                json={"challenge_id": "CONC-001", "ttl": 300},
                headers=h2,
            )
            assert r1.status_code == 202
            assert r2.status_code == 202
            assert r1.json()["instance_id"] != r2.json()["instance_id"]

    def test_same_team_can_run_n_instances_of_one_challenge(self, auto_mock_env_manager):
        """Regression for the 0.2 multi-instance lift: a single team
        starting the same challenge twice in a row gets two distinct
        instance_ids (the legacy 409-on-(team, challenge) collision is
        gone), and submissions against each instance are scored
        independently."""
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            team = _mint(c, "fan-out")
            auth = {"Authorization": f"Bearer {team['token']}"}

            # Two starts of the same challenge by the same team — both succeed.
            r1 = c.post(
                "/api/v1/instances",
                json={"challenge_id": "FAN-001", "ttl": 300},
                headers=auth,
            )
            r2 = c.post(
                "/api/v1/instances",
                json={"challenge_id": "FAN-001", "ttl": 300},
                headers=auth,
            )
            assert r1.status_code == 202
            assert r2.status_code == 202
            inst1 = r1.json()["instance_id"]
            inst2 = r2.json()["instance_id"]
            assert inst1 != inst2

            # Both reach READY independently.
            for inst_id in (inst1, inst2):
                deadline = time.monotonic() + 5
                while time.monotonic() < deadline:
                    s = c.get(f"/api/v1/instances/{inst_id}/status", headers=auth)
                    if s.json().get("status") == "ready":
                        break
                    time.sleep(0.05)
                else:
                    pytest.fail(f"{inst_id} not ready")

            # Submitting a wrong flag to inst1 doesn't 'use up' inst2:
            # both submissions succeed against their own instance.
            wrong = c.post(
                "/api/v1/submissions",
                json={"instance_id": inst1, "flag": "FLAG{bad}"},
                headers=auth,
            )
            assert wrong.json()["correct"] is False
            right = c.post(
                "/api/v1/submissions",
                json={
                    "instance_id": inst2,
                    "flag": "FLAG{deadbeef0123456789abcdef01234567}",
                },
                headers=auth,
            )
            assert right.json()["correct"] is True

    def test_list_instances(self, auto_client):
        _start_and_wait(auto_client)
        resp = auto_client.get("/api/v1/instances")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["items"]) >= 1
        assert data["total"] >= 1

    def test_list_instances_filter_challenge_id(self, auto_client):
        _start_and_wait(auto_client, "FILTER-001")
        resp = auto_client.get("/api/v1/instances?challenge_id=FILTER-001")
        assert resp.status_code == 200
        items = resp.json()["items"]
        assert len(items) == 1
        assert items[0]["challenge_id"] == "FILTER-001"

    def test_list_instances_filter_status(self, auto_client):
        _start_and_wait(auto_client, "STATUS-001")
        resp = auto_client.get("/api/v1/instances?status=ready")
        assert len(resp.json()["items"]) >= 1
        resp = auto_client.get("/api/v1/instances?status=error")
        assert all(e["status"] == "error" for e in resp.json()["items"])

    def test_list_instances_filter_q(self, auto_client):
        _start_and_wait(auto_client, "SEARCH-001")
        resp = auto_client.get("/api/v1/instances?q=SEARCH")
        assert len(resp.json()["items"]) >= 1
        resp = auto_client.get("/api/v1/instances?q=zzzzz")
        assert len(resp.json()["items"]) == 0

    def test_stop(self, auto_client):
        _, instance_id = _start_and_wait(auto_client)
        resp = auto_client.delete(f"/api/v1/instances/{instance_id}")
        assert resp.status_code == 200
        assert resp.json()["instance_id"] == instance_id
        assert auto_client.get("/api/v1/instances").json()["items"] == []

    def test_stop_missing_404(self, auto_client):
        resp = auto_client.delete("/api/v1/instances/NONEXISTENT")
        assert resp.status_code == 404

    def test_bulk_stop(self, auto_client):
        _start_and_wait(auto_client)
        resp = auto_client.delete("/api/v1/instances")
        assert resp.status_code == 403

    def test_bulk_stop_with_admin(self, auto_mock_env_manager):
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            # Admin identity is now a flag on the team, not a separate secret.
            admin = mint_team(backend, name="admin", email="admin@example.test", is_admin=True)
            # Start an instance as a regular team (starts require team auth now).
            team = _mint(c, "bulk")
            team_headers = {"Authorization": f"Bearer {team['token']}"}
            _start_and_wait(c, headers=team_headers)
            # Bulk stop still requires admin.
            resp = c.delete("/api/v1/instances", headers=admin.headers)
            assert resp.status_code == 200
            assert len(resp.json()) >= 1


class TestAdminListInstances:
    """``GET /admin/instances`` returns cross-team instances for the admin
    dashboard — filterable by node_id so the nodes table can expand into
    "which instances run here"."""

    def _bootstrap(self, auto_mock_env_manager):
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        admin = mint_team(backend, name="admin", email="admin@example.test", is_admin=True)
        return app, backend, admin

    def test_requires_admin(self, auto_mock_env_manager):
        app, _, _ = self._bootstrap(auto_mock_env_manager)
        c = TestClient(app)
        r = c.get("/api/v1/admin/instances")
        assert r.status_code in (401, 403)

    def test_returns_all_instances_and_exposes_node_id(self, auto_mock_env_manager):
        app, backend, admin = self._bootstrap(auto_mock_env_manager)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            team = _mint(c, "adm-list")
            _start_and_wait(c, headers={"Authorization": f"Bearer {team['token']}"})

            r = c.get("/api/v1/admin/instances", headers=admin.headers)
            assert r.status_code == 200
            items = r.json()["items"]
            assert len(items) >= 1
            # The fake node backend registers under this id; the payload
            # surfaces it so the dashboard can render / filter.
            assert items[0]["node_id"]

    def test_filters_by_node_id(self, auto_mock_env_manager):
        app, backend, admin = self._bootstrap(auto_mock_env_manager)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            team = _mint(c, "adm-fltr")
            _start_and_wait(c, headers={"Authorization": f"Bearer {team['token']}"})

            all_items = c.get("/api/v1/admin/instances", headers=admin.headers).json()["items"]
            real_node = all_items[0]["node_id"]

            matched = c.get(
                f"/api/v1/admin/instances?node_id={real_node}", headers=admin.headers
            ).json()["items"]
            assert len(matched) == len(all_items)

            empty = c.get(
                "/api/v1/admin/instances?node_id=does-not-exist", headers=admin.headers
            ).json()["items"]
            assert empty == []


class TestAdminStats:
    """/admin/overview + /admin/solve-matrix feed the admin dashboard's
    single-request landing page + the team × challenge grid."""

    def _bootstrap(self, auto_mock_env_manager):
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        admin = mint_team(backend, name="admin", email="admin@example.test", is_admin=True)
        return app, backend, admin

    def test_overview_requires_admin(self, auto_mock_env_manager):
        app, _, _ = self._bootstrap(auto_mock_env_manager)
        c = TestClient(app)
        assert c.get("/api/v1/admin/overview").status_code in (401, 403)

    def test_overview_counts(self, auto_mock_env_manager):
        app, backend, admin = self._bootstrap(auto_mock_env_manager)
        with fake_node_context(backend, flag="FLAG{deadbeef0123456789abcdef01234567}"):
            c = TestClient(app)
            team = _mint(c, "ov-t")
            _start_and_wait(c, headers={"Authorization": f"Bearer {team['token']}"})

            r = c.get("/api/v1/admin/overview", headers=admin.headers)
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["nodes"]["total"] == 1
            assert body["nodes"]["healthy"] == 1
            # One admin team (seeded) + the solver created above.
            assert body["teams_total"] == 2
            # running_instances is driven by node heartbeats; the fake node
            # doesn't heartbeat, so just sanity-check the key shape.
            assert "running_instances" in body
            assert isinstance(body["solves_today"], int)

    def test_solve_matrix_requires_admin(self, auto_mock_env_manager):
        app, _, _ = self._bootstrap(auto_mock_env_manager)
        c = TestClient(app)
        assert c.get("/api/v1/admin/solve-matrix").status_code in (401, 403)

    def test_solve_matrix_records_first_blood(self, mock_env_manager):
        # Use the fixture that pre-defines WEB-001 as a spec so the matrix
        # column appears. auto_mock_env_manager auto-generates specs only
        # during iter_specs(challenge_id=...) lookups, not bulk iter_specs().
        app, backend, admin = self._bootstrap(mock_env_manager)
        with fake_node_context(backend, flag="FLAG{deadbeef0123456789abcdef01234567}"):
            c = TestClient(app)
            team = _mint(c, "fb")
            auth = {"Authorization": f"Bearer {team['token']}"}
            _, instance_id = _start_and_wait(c, challenge_id="WEB-001", headers=auth)
            c.post(
                "/api/v1/submissions",
                json={
                    "instance_id": instance_id,
                    "flag": "FLAG{deadbeef0123456789abcdef01234567}",
                },
                headers=auth,
            )

            r = c.get("/api/v1/admin/solve-matrix", headers=admin.headers)
            assert r.status_code == 200, r.text
            body = r.json()
            teams = body["teams"]
            cells = body["cells"]
            assert any(t["name"] == "fb" and t["solved"] == 1 for t in teams)
            solved = [cell for cell in cells if cell["solved"]]
            assert solved
            assert any(cell["first_blood"] for cell in solved)
            # Columns include the challenge we solved.
            assert any(col["challenge_id"] == "WEB-001" for col in body["challenges"])


class TestVerifyFlag:
    def test_correct_flag(self, auto_client):
        _, instance_id = _start_and_wait(auto_client, "FLAG-TEST")
        resp = auto_client.post(
            f"/api/v1/instances/{instance_id}/verify-flag",
            json={"claimed_flag": "FLAG{deadbeef0123456789abcdef01234567}"},
        )
        assert resp.status_code == 200
        assert resp.json()["correct"] is True

    def test_wrong_flag(self, auto_client):
        _, instance_id = _start_and_wait(auto_client, "FLAG-TEST2")
        resp = auto_client.post(
            f"/api/v1/instances/{instance_id}/verify-flag",
            json={"claimed_flag": "FLAG{wrong}"},
        )
        assert resp.status_code == 200
        assert resp.json()["correct"] is False

    def test_verify_missing_instance_404(self, auto_client):
        resp = auto_client.post(
            "/api/v1/instances/NONEXISTENT/verify-flag",
            json={"claimed_flag": "FLAG{x}"},
        )
        assert resp.status_code == 404


class TestRenew:
    def test_renew(self, auto_client):
        _, instance_id = _start_and_wait(auto_client, "TTL-TEST")
        resp = auto_client.post(f"/api/v1/instances/{instance_id}/renew?ttl=3600")
        assert resp.status_code == 200
        assert resp.json()["instance_id"] == instance_id

    def test_renew_missing_404(self, auto_client):
        resp = auto_client.post("/api/v1/instances/NONEXISTENT/renew?ttl=60")
        assert resp.status_code == 404


class TestAuth:
    def test_no_auth_required_by_default(self, auto_client):
        resp = auto_client.get("/api/v1/health")
        assert resp.status_code == 200

    def test_public_routes_accessible_without_admin(self, auto_mock_env_manager):
        from ctfy.server.app import create_app

        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="127.0.0.1", backend=InMemoryBackend())
        c = TestClient(app)
        assert c.get("/api/v1/health").status_code == 200

    def test_admin_only_routes_require_admin_team(self, auto_mock_env_manager):
        """Admin endpoints gate on ``TeamState.role`` (admin or super_admin
        — super_admin set from the ``CTFY_SUPER_ADMIN_EMAILS`` allowlist;
        admin granted by a super-admin via the admin UI). A regular team's
        token gets 403; a team with admin role passes."""
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="127.0.0.1", backend=backend)
        c = TestClient(app)
        # No Authorization header → HTTPBearer rejects at 401.
        assert c.get("/api/v1/cluster-info").status_code == 401
        # Bogus bearer → 403.
        assert (
            c.get(
                "/api/v1/cluster-info", headers={"Authorization": "Bearer wrong"}
            ).status_code
            == 403
        )
        # Regular (non-admin) team → 403 (is_admin=False).
        regular = mint_team(backend, name="plain", email="plain@example.test")
        assert c.get("/api/v1/cluster-info", headers=regular.headers).status_code == 403
        # Admin team → 200.
        admin = mint_team(backend, name="admin", email="admin@example.test", is_admin=True)
        assert c.get("/api/v1/cluster-info", headers=admin.headers).status_code == 200


# ============================================================================
# Async startup happy-path — exercises the post → poll → verify-flag → stop
# loop with a separate port (verifies port plumbing).
# ============================================================================


@pytest.fixture
def async_client():
    from ctfy.server.app import create_app

    mock_mgr = make_mock_challenge_manager(
        flag="FLAG{testflag123456789abcdef01234567}",
        port=9090,
    )
    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_mgr):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{testflag123456789abcdef01234567}",
        host="10.0.1.5",
        port=9090,
    ):
        with TestClient(app) as c:
            team = _mint(c, "async")
            c.headers["Authorization"] = f"Bearer {team['token']}"
            yield c


def _async_start(c, challenge_id="E2E-001"):
    resp = c.post(
        "/api/v1/instances",
        json={"challenge_id": challenge_id, "ttl": 300},
    )
    instance_id = resp.json()["instance_id"]
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        s = c.get(f"/api/v1/instances/{instance_id}/status")
        if s.json().get("status") == "ready":
            return instance_id
        time.sleep(0.1)
    raise TimeoutError(f"{instance_id} not ready")


class TestAsyncStartup:
    def test_post_returns_202(self, async_client):
        resp = async_client.post(
            "/api/v1/instances",
            json={"challenge_id": "T1", "ttl": 300},
        )
        assert resp.status_code == 202
        assert resp.json()["status"] == "starting"

    def test_status_becomes_ready(self, async_client):
        instance_id = _async_start(async_client, "T2")
        s = async_client.get(f"/api/v1/instances/{instance_id}/status")
        assert s.json()["status"] == "ready"
        assert s.json()["attack_surface"]["services"][0]["host"] == "10.0.1.5"

    def test_verify_flag_after_ready(self, async_client):
        instance_id = _async_start(async_client, "T3")
        r = async_client.post(
            f"/api/v1/instances/{instance_id}/verify-flag",
            json={"claimed_flag": "FLAG{testflag123456789abcdef01234567}"},
        )
        assert r.json()["correct"] is True

    def test_full_lifecycle(self, async_client):
        instance_id = _async_start(async_client, "T4")
        r = async_client.post(
            f"/api/v1/instances/{instance_id}/verify-flag",
            json={"claimed_flag": "FLAG{wrong}"},
        )
        assert r.json()["correct"] is False
        async_client.delete(f"/api/v1/instances/{instance_id}")
        assert async_client.get(f"/api/v1/instances/{instance_id}/status").status_code == 404
