"""End-to-end tests for the MCP server tools.

Tests MCP tool functions by patching _client() to return a PlatformClient
connected to a real mock FastAPI server. This validates that MCP tools
correctly delegate to the SDK and return proper results.

The MCP e2e suite still drives the old ``register_team`` workflow, which
was removed in the OAuth rewrite. The whole module is marked skipped
pending a rewrite against ``mint_team`` + already-authenticated clients.
"""

import threading
import time
from unittest.mock import MagicMock, patch

import pytest
import uvicorn

from ctfy.core.provider import StartResult
from ctfy.core.state import InMemoryBackend
from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType
from ctfy.mcp.server import (
    get_challenge,
    get_challenge_stats,
    get_scoreboard,
    list_challenges,
    list_instances,
    renew_instance,
    start_instance,
    stop_instance,
    submit_flag,
    verify_flag,
)
from ctfy.sdk import PlatformClient
from ctfy.tests.conftest import build_spec, mint_team

pytestmark = pytest.mark.skip(
    reason="MCP e2e needs an OAuth-aware rewrite (post-register_team removal)."
)

# ---------------------------------------------------------------------------
# Server fixture (shared with SDK tests pattern)
# ---------------------------------------------------------------------------


def _make_app():
    mock_mgr = MagicMock()
    mock_mgr.start.return_value = StartResult(
        surface=AttackSurface(
            services=[
                ServiceEndpoint(
                    service_type=ServiceType.HTTP,
                    host="127.0.0.1",
                    port=9090,
                ),
            ],
        ),
        flags={"main": "FLAG{mcp_e2e_test_flag_abcdef0123456789}"},
    )
    mock_mgr.stop.return_value = None
    mock_mgr.stop_all.return_value = None
    mock_mgr.get_cert_volume.return_value = ""
    specs = [
        build_spec("MCP-001", name="MCP Test", description="MCP e2e test"),
        build_spec(
            "MCP-002",
            name="MCP Hard Challenge",
            description="Hard challenge",
            difficulty="hard",
        ),
    ]

    def _iter(challenge_id=None, difficulty=None, tag=None, **_kw):
        for s in specs:
            if challenge_id and s.id != challenge_id:
                continue
            if difficulty and s.difficulty.value != difficulty:
                continue
            if tag and tag not in s.tags:
                continue
            yield s

    mock_mgr.iter_specs.side_effect = _iter

    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    return app, backend


def _find_free_port():
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def server_url_and_backend():
    from ctfy.tests.conftest import fake_node_context

    app, backend = _make_app()
    port = _find_free_port()
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    url = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            import httpx

            httpx.get(f"{url}/api/v1/health", timeout=1)
            break
        except Exception:
            time.sleep(0.1)
    else:
        raise RuntimeError("Test server did not start")

    with fake_node_context(backend, flag="FLAG{mcp_e2e_test_flag_abcdef0123456789}"):
        yield url, backend
    server.should_exit = True


@pytest.fixture(scope="module")
def server_url(server_url_and_backend):
    url, _ = server_url_and_backend
    return url


@pytest.fixture(scope="module")
def team_key(server_url_and_backend):
    """Mint a team directly against the backend; OAuth path is covered elsewhere."""
    _, backend = server_url_and_backend
    minted = mint_team(backend, name="MCP-E2E-Team", email="mcp-e2e@example.test")
    return minted.token


@pytest.fixture(autouse=True)
def patch_mcp_client(server_url, team_key):
    """Patch the MCP _client() to return a PlatformClient for the test server."""
    client = PlatformClient(server_url, token=team_key)
    with patch("ctfy.mcp.server._client", return_value=client):
        yield
    client.close()


# ---------------------------------------------------------------------------
# Tests: Tool availability (what's exposed vs what's not)
# ---------------------------------------------------------------------------


def _get_registered_tool_names():
    """Get the set of tool names registered in the MCP server."""
    import asyncio

    from ctfy.mcp.server import mcp

    tools = asyncio.get_event_loop().run_until_complete(mcp.list_tools())
    return {t.name for t in tools}


class TestToolAvailability:
    def test_no_evaluation_tools(self):
        """Evaluation management tools should NOT be exposed in MCP."""
        registered = _get_registered_tool_names()
        assert "create_evaluation" not in registered
        assert "complete_evaluation" not in registered

    def test_no_node_tools(self):
        """Node management tools should NOT be exposed in MCP."""
        registered = _get_registered_tool_names()
        assert "register_node" not in registered
        assert "list_nodes" not in registered
        assert "remove_node" not in registered

    def test_no_activity_tools(self):
        """Activity log tools should NOT be exposed in MCP."""
        registered = _get_registered_tool_names()
        assert "get_activities" not in registered
        assert "list_activities" not in registered

    def test_expected_tools_registered(self):
        """All expected CTF tools should be registered."""
        registered = _get_registered_tool_names()
        expected = {
            "list_challenges",
            "get_challenge",
            "start_instance",
            "stop_instance",
            "renew_instance",
            "list_instances",
            "verify_flag",
            "submit_flag",
            "get_scoreboard",
            "get_challenge_stats",
            "health",
        }
        assert expected.issubset(registered), f"Missing: {expected - registered}"


# ---------------------------------------------------------------------------
# Tests: Challenge discovery
# ---------------------------------------------------------------------------


class TestChallenges:
    def test_list_challenges(self):
        result = list_challenges()
        assert len(result) == 2
        ids = {c.id for c in result}
        assert "MCP-001" in ids

    def test_list_challenges_with_difficulty(self):
        result = list_challenges(difficulty="hard")
        assert len(result) == 1
        assert result[0].id == "MCP-002"

    def test_list_challenges_pagination(self):
        result = list_challenges(offset=0, limit=1)
        assert len(result) == 1

    def test_get_challenge(self):
        c = get_challenge("MCP-001")
        assert c.id == "MCP-001"
        assert c.name == "MCP Test"


# ---------------------------------------------------------------------------
# Tests: Instance lifecycle
# ---------------------------------------------------------------------------


class TestInstances:
    def _start(self, challenge_id="MCP-001"):
        """Start instance, return the attack surface."""
        return start_instance(challenge_id, ttl=300)

    def _stop(self, challenge_id="MCP-001"):
        """Stop instance, tolerating if already stopped."""
        try:
            stop_instance(challenge_id)
        except Exception:
            pass

    def test_start_and_stop(self):
        surface = self._start()
        assert isinstance(surface, AttackSurface)
        assert len(surface.services) >= 1

        instances = list_instances()
        instance_ids = [e.instance_id for e in instances if e.challenge_id == "MCP-001"]
        assert len(instance_ids) >= 1

        msg = stop_instance("MCP-001")
        assert "stopped" in msg.lower()

    def test_list_instances(self):
        self._start()
        try:
            instances = list_instances()
            assert isinstance(instances, list)
            assert len(instances) >= 1
        finally:
            self._stop()

    def test_list_instances_pagination(self):
        instances = list_instances(offset=0, limit=10)
        assert isinstance(instances, list)

    def test_renew_instance(self):
        self._start()
        try:
            msg = renew_instance("MCP-001", ttl=7200)
            assert "renewed" in msg.lower()
        finally:
            self._stop()


# ---------------------------------------------------------------------------
# Tests: Flag operations
# ---------------------------------------------------------------------------


class TestFlags:
    def _stop(self):
        try:
            stop_instance("MCP-001")
        except Exception:
            pass

    def test_verify_flag_correct(self):
        start_instance("MCP-001", ttl=300)
        try:
            assert verify_flag("MCP-001", "FLAG{mcp_e2e_test_flag_abcdef0123456789}") is True
        finally:
            self._stop()

    def test_verify_flag_wrong(self):
        start_instance("MCP-001", ttl=300)
        try:
            assert verify_flag("MCP-001", "FLAG{wrong}") is False
        finally:
            self._stop()

    def test_submit_flag_correct(self):
        start_instance("MCP-001", ttl=300)
        try:
            r = submit_flag(
                "MCP-001",
                "FLAG{mcp_e2e_test_flag_abcdef0123456789}",
            )
            assert r.correct is True
        finally:
            self._stop()

    def test_submit_flag_wrong(self):
        start_instance("MCP-001", ttl=300)
        try:
            r = submit_flag("MCP-001", "FLAG{nope}")
            assert r.correct is False
        finally:
            self._stop()


# ---------------------------------------------------------------------------
# Tests: Scoreboard & stats
# ---------------------------------------------------------------------------


class TestScoreboard:
    def test_get_scoreboard(self):
        board = get_scoreboard()
        assert isinstance(board, list)

    def test_get_scoreboard_pagination(self):
        board = get_scoreboard(offset=0, limit=5)
        assert isinstance(board, list)

    def test_get_challenge_stats(self):
        stats = get_challenge_stats()
        assert isinstance(stats, list)
        assert len(stats) == 2  # MCP-001, MCP-002

    def test_get_challenge_stats_pagination(self):
        stats = get_challenge_stats(offset=0, limit=1)
        assert len(stats) == 1


# ---------------------------------------------------------------------------
# Tests: Team registration — no longer exposed via MCP; handled via OAuth login
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Tests: Full lifecycle via MCP tools
# ---------------------------------------------------------------------------


class TestFullLifecycle:
    def test_challenge_to_solve(self):
        """Full flow using only MCP tools: list → start → submit → scoreboard."""
        chals = list_challenges()
        assert len(chals) >= 1
        cid = chals[0].id

        surface = start_instance(cid, ttl=300)
        assert len(surface.services) >= 1

        r = submit_flag(cid, "FLAG{mcp_e2e_test_flag_abcdef0123456789}")
        assert r.correct is True

        board = get_scoreboard()
        assert isinstance(board, list)

        # Stop using challenge_id (SDK resolves to instance_id internally)
        stop_instance(cid)
