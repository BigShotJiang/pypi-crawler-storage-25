"""Tests for ``GET /challenges/{id}/solve-attempts``."""

from __future__ import annotations

import time

from ctfy.core.enums import InstanceStatus
from ctfy.core.state.models import InstanceRecord
from ctfy.tests.conftest import mint_team


def _archive(
    backend,
    *,
    instance_id: str,
    team_id: str,
    challenge_id: str = "WEB-001",
    started_at: float | None = None,
    duration_s: float = 60.0,
    solved: bool = True,
    solved_flags: list[str] | None = None,
    attempts: int = 1,
    stop_reason: str = "auto_stop_after_solve",
    status: str = InstanceStatus.STOPPED,
) -> InstanceRecord:
    """Insert an ``InstanceRecord`` directly into the backend archive."""
    started = started_at if started_at is not None else time.time() - duration_s
    rec = InstanceRecord(
        instance_id=instance_id,
        challenge_id=challenge_id,
        team_id=team_id,
        node_id="node-1",
        status=status,
        stop_reason=stop_reason,
        started_at=started,
        stopped_at=started + duration_s,
        duration_s=duration_s,
        solved=solved,
        solved_flags=solved_flags or (["main"] if solved else []),
        attempts=attempts,
    )
    backend.archive_instance(rec)
    return rec


def test_solve_attempts_requires_login(client):
    r = client.get("/api/v1/challenges/WEB-001/solve-attempts")
    assert r.status_code in (401, 403)


def test_solve_attempts_unknown_challenge_returns_404(client, backend):
    team = mint_team(backend, name="alpha")
    r = client.get(
        "/api/v1/challenges/NOPE/solve-attempts", headers=team.headers
    )
    assert r.status_code == 404


def test_solve_attempts_default_filters_solved_only(client, backend):
    team = mint_team(backend, name="alpha", display_name="Alpha")
    base = time.time() - 1000
    _archive(
        backend,
        instance_id="i-1",
        team_id=team.team_id,
        started_at=base,
        duration_s=120.0,
        solved=True,
    )
    _archive(
        backend,
        instance_id="i-2",
        team_id=team.team_id,
        started_at=base + 200,
        duration_s=30.0,
        solved=False,
        solved_flags=[],
        attempts=3,
        stop_reason="ttl_expired",
    )

    r = client.get(
        "/api/v1/challenges/WEB-001/solve-attempts", headers=team.headers
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["challenge_id"] == "WEB-001"
    assert len(body["attempts"]) == 1
    assert body["attempts"][0]["instance_id"] == "i-1"
    assert body["attempts"][0]["solved"] is True
    assert body["total_attempts"] == 2  # all archived, regardless of solved

    assert len(body["per_team"]) == 1
    summary = body["per_team"][0]
    assert summary["team_id"] == team.team_id
    assert summary["solve_count"] == 1
    assert summary["attempt_count"] == 1  # only solved rows counted in per_team
    assert summary["best_duration_s"] == 120.0
    assert summary["display_name"] == "Alpha"


def test_solve_attempts_include_unsolved(client, backend):
    team = mint_team(backend, name="alpha")
    base = time.time() - 1000
    _archive(
        backend,
        instance_id="i-1",
        team_id=team.team_id,
        started_at=base,
        solved=True,
    )
    _archive(
        backend,
        instance_id="i-2",
        team_id=team.team_id,
        started_at=base + 100,
        solved=False,
        solved_flags=[],
        stop_reason="ttl_expired",
    )

    r = client.get(
        "/api/v1/challenges/WEB-001/solve-attempts?include_unsolved=true",
        headers=team.headers,
    )
    assert r.status_code == 200
    body = r.json()
    assert {a["instance_id"] for a in body["attempts"]} == {"i-1", "i-2"}
    summary = body["per_team"][0]
    # solve_count counts only solved=True; attempt_count includes the failed run.
    assert summary["solve_count"] == 1
    assert summary["attempt_count"] == 2


def test_solve_attempts_groups_per_team_with_aggregates(client, backend):
    me = mint_team(backend, name="alpha", display_name="Alpha")
    other = mint_team(backend, name="bravo")
    base = time.time() - 1000
    # Alpha: 3 solves of WEB-001 — fastest 30s, slowest 180s
    _archive(
        backend, instance_id="a1", team_id=me.team_id,
        started_at=base + 0,   duration_s=180.0,
    )
    _archive(
        backend, instance_id="a2", team_id=me.team_id,
        started_at=base + 300, duration_s=90.0,
    )
    _archive(
        backend, instance_id="a3", team_id=me.team_id,
        started_at=base + 600, duration_s=30.0,
    )
    # Bravo: 1 solve, slower than Alpha's best
    _archive(
        backend, instance_id="b1", team_id=other.team_id,
        started_at=base + 100, duration_s=240.0,
    )
    # Different challenge — must be excluded
    _archive(
        backend, instance_id="x1", team_id=me.team_id,
        challenge_id="WEB-002", started_at=base + 50, duration_s=10.0,
    )

    r = client.get(
        "/api/v1/challenges/WEB-001/solve-attempts", headers=me.headers
    )
    assert r.status_code == 200
    body = r.json()
    assert len(body["attempts"]) == 4
    # Attempts global-sorted by started_at ascending so the frontend can
    # slice per-team bars without re-sorting.
    starts = [a["started_at"] for a in body["attempts"]]
    assert starts == sorted(starts)

    # per_team ordered by (-solve_count, best_duration_s)
    assert [s["team_id"] for s in body["per_team"]] == [me.team_id, other.team_id]
    alpha = body["per_team"][0]
    assert alpha["solve_count"] == 3
    assert alpha["attempt_count"] == 3
    assert alpha["best_duration_s"] == 30.0
    assert alpha["total_duration_s"] == 300.0
    assert alpha["first_solved_at"] == base + 0
    assert alpha["last_solved_at"] == base + 600


def test_solve_attempts_team_name_fallback_when_team_deleted(client, backend):
    me = mint_team(backend, name="alpha")
    ghost_team_id = "deleted-team-id"
    _archive(backend, instance_id="g1", team_id=ghost_team_id)

    r = client.get(
        "/api/v1/challenges/WEB-001/solve-attempts", headers=me.headers
    )
    assert r.status_code == 200
    body = r.json()
    ghost = next(a for a in body["attempts"] if a["team_id"] == ghost_team_id)
    # Falls back to the team_id when the team row no longer exists.
    assert ghost["team_name"] == ghost_team_id
    assert ghost["display_name"] == ""


def test_solve_attempts_empty_when_no_archive(client, backend):
    team = mint_team(backend, name="alpha")
    r = client.get(
        "/api/v1/challenges/WEB-001/solve-attempts", headers=team.headers
    )
    assert r.status_code == 200
    body = r.json()
    assert body["attempts"] == []
    assert body["per_team"] == []
    assert body["total_attempts"] == 0
