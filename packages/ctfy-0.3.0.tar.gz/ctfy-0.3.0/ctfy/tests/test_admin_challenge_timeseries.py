"""Tests for ``GET /admin/challenges/{id}/timeseries`` — per-challenge
launches / errors / launch-duration percentiles bucketed for the admin
drilldown drawer."""

from __future__ import annotations

import time
from unittest.mock import patch

from fastapi.testclient import TestClient

from ctfy.core.enums import InstanceStatus
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import InstanceRecord
from ctfy.tests.conftest import mint_team


def _bootstrap(env_manager, *, clock=None):
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    if clock is not None:
        app.state.ctfy.clock = clock
    admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)
    return app, backend, admin


# Fixed clock instant — same as test_admin_timeseries — so the per-challenge
# and global tests share a vocabulary.
_FIXED_NOW = 1777681800.0


def _archive(
    backend: InMemoryBackend,
    *,
    iid: str,
    challenge_id: str = "E1",
    requested_offset_min: float,
    duration_s: float = 1.0,
    stop_reason: str = "",
    now: float | None = None,
) -> None:
    """Archive one record at ``requested_offset_min`` minutes before ``now``.

    Defaults to wall clock; pass ``now=_FIXED_NOW`` whenever the route under
    test pins its clock.
    """
    if now is None:
        now = time.time()
    requested = now - requested_offset_min * 60
    backend.archive_instance(
        InstanceRecord(
            instance_id=iid,
            challenge_id=challenge_id,
            team_id="t1",
            node_id="n1",
            status=InstanceStatus.STOPPED,
            requested_at=requested,
            ready_at=requested + duration_s,
            started_at=requested + duration_s,
            stopped_at=requested + 60,
            stop_reason=stop_reason,
        )
    )


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


def test_per_challenge_timeseries_requires_admin(mock_env_manager):
    app, _, _ = _bootstrap(mock_env_manager)
    c = TestClient(app)
    r = c.get("/api/v1/admin/challenges/E1/timeseries")
    assert r.status_code in (401, 403)


def test_per_challenge_timeseries_403_for_non_admin(mock_env_manager):
    app, backend, _ = _bootstrap(mock_env_manager)
    user = mint_team(backend, name="u", email="u@example.test", is_admin=False)
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/challenges/E1/timeseries",
        headers=user.headers,
    )
    assert r.status_code == 403


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def test_per_challenge_timeseries_404_for_unknown_challenge(mock_env_manager):
    app, _, admin = _bootstrap(mock_env_manager)
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/challenges/DOES_NOT_EXIST/timeseries",
        headers=admin.headers,
    )
    assert r.status_code == 404


def test_per_challenge_timeseries_default_window_24h_bucket_1h(mock_env_manager):
    app, _, admin = _bootstrap(mock_env_manager)
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/challenges/E1/timeseries",
        headers=admin.headers,
    )
    assert r.status_code == 200
    body = r.json()
    assert body["challenge_id"] == "E1"
    # 24 hourly buckets covering the past 24h.
    assert len(body["buckets"]) == 24
    # No data → every bucket reads zero across the board.
    for b in body["buckets"]:
        assert b["launches"] == 0
        assert b["errors"] == 0
        assert b["error_rate"] == 0.0
        assert b["p50_launch_s"] == 0.0
        assert b["p95_launch_s"] == 0.0


# ---------------------------------------------------------------------------
# Counts + error_rate + percentiles
# ---------------------------------------------------------------------------


def test_per_challenge_timeseries_buckets_count_launches_and_errors(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)

    # All in the most recent bucket (≤ 30 min ago, well under 1h window).
    _archive(backend, iid="ok1", requested_offset_min=10, duration_s=1.0, now=_FIXED_NOW)
    _archive(backend, iid="ok2", requested_offset_min=20, duration_s=2.0, now=_FIXED_NOW)
    _archive(
        backend,
        iid="err1",
        requested_offset_min=15,
        duration_s=0.5,
        stop_reason="error",
        now=_FIXED_NOW,
    )

    # An older record outside the 1h window — must NOT contribute.
    _archive(backend, iid="old", requested_offset_min=120, duration_s=1.0, now=_FIXED_NOW)

    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/challenges/E1/timeseries",
        params={"window": 3600, "bucket": 3600},
        headers=admin.headers,
    )
    assert r.status_code == 200
    body = r.json()
    assert len(body["buckets"]) == 1
    bucket = body["buckets"][0]
    assert bucket["launches"] == 3
    assert bucket["errors"] == 1
    assert bucket["error_rate"] == round(1 / 3, 4)
    # p50 of [0.5, 1.0, 2.0] (sorted) at nearest-rank q=50 → 1.0; p95 → 2.0.
    assert bucket["p50_launch_s"] == 1.0
    assert bucket["p95_launch_s"] == 2.0


def test_per_challenge_timeseries_filters_by_challenge_id(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)

    _archive(backend, iid="a", challenge_id="E1", requested_offset_min=10, now=_FIXED_NOW)
    _archive(backend, iid="b", challenge_id="E2", requested_offset_min=10, now=_FIXED_NOW)

    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/challenges/E1/timeseries",
        params={"window": 3600, "bucket": 3600},
        headers=admin.headers,
    )
    body = r.json()
    # E1 has 1 launch in the last hour; the E2 record must not leak in.
    assert sum(b["launches"] for b in body["buckets"]) == 1
