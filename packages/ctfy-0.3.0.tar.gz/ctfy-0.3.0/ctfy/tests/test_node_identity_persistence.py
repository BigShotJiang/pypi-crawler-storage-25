"""Tests for the node-side identity persistence added alongside the OAuth
rewrite.

The node now persists ``(node_id, node_token)`` to its local sqlite so
``docker compose restart node`` doesn't need a fresh admin-minted invite
every time. Coverage:

* :class:`NodeInstanceStore` identity CRUD (get/put/clear, partial rows).
* :func:`_register_with_platform` reuses the persisted identity when
  present, falls back to the invite-backed registration flow when not.
* Heartbeat rejection (401 / 403 / 404) clears the persisted identity
  so the next restart re-registers rather than looping on a stale token.
"""

from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from ctfy.server.node_app import (
    NodeAppState,
    _heartbeat_once,
    _register_with_platform,
)
from ctfy.server.node_state import NodeInstanceStore


@pytest.fixture
def store(tmp_path: Path) -> NodeInstanceStore:
    return NodeInstanceStore(tmp_path / "node.sqlite3")


# ---------------------------------------------------------------------------
# NodeInstanceStore — identity CRUD
# ---------------------------------------------------------------------------


class TestIdentityStore:
    def test_empty_store_returns_none(self, store: NodeInstanceStore):
        assert store.get_identity() is None

    def test_put_then_get_roundtrip(self, store: NodeInstanceStore):
        store.put_identity("node-abc", "tok-secret")
        assert store.get_identity() == ("node-abc", "tok-secret")

    def test_overwrite(self, store: NodeInstanceStore):
        store.put_identity("node-1", "tok-1")
        store.put_identity("node-2", "tok-2")
        assert store.get_identity() == ("node-2", "tok-2")

    def test_clear(self, store: NodeInstanceStore):
        store.put_identity("node-abc", "tok-secret")
        store.clear_identity()
        assert store.get_identity() is None

    def test_partial_row_treated_as_absent(self, tmp_path: Path):
        """A half-written identity (id only or token only) is invalid; the
        node must re-register rather than present a broken pair."""
        store = NodeInstanceStore(tmp_path / "node.sqlite3")
        # Write only node_id, no node_token.
        conn = sqlite3.connect(tmp_path / "node.sqlite3")
        with conn:
            conn.execute(
                "INSERT INTO node_identity (key, value) VALUES (?, ?)",
                ("node_id", "node-abc"),
            )
        conn.close()
        assert store.get_identity() is None


# ---------------------------------------------------------------------------
# _register_with_platform — identity reuse + first-time registration
# ---------------------------------------------------------------------------


def _make_state(store: NodeInstanceStore, *, registration_token: str = "") -> NodeAppState:
    return NodeAppState(
        registration_token=registration_token,
        public_url="http://node:8101",
        display_name="test-node",
        capacity=10,
        platform_url="http://platform:8100",
        store=store,
    )


class TestRegisterWithPlatform:
    def test_reuses_persisted_identity(self, store: NodeInstanceStore):
        store.put_identity("node-xyz", "tok-persisted")
        state = _make_state(store, registration_token="unused-invite")

        # If the code tries to actually hit the network, the test fails
        # — we want the persisted-identity branch to short-circuit before
        # any httpx call.
        with patch("ctfy.server.node_app.httpx.AsyncClient") as mock_client:
            ok = asyncio.run(_register_with_platform(state))

        assert ok is True
        assert state.node_id == "node-xyz"
        assert state.node_token == "tok-persisted"
        # Invite token cleared to prevent accidental replay.
        assert state.registration_token == ""
        assert mock_client.call_count == 0

    def test_first_time_registers_and_persists(self, store: NodeInstanceStore):
        state = _make_state(store, registration_token="seed-invite")

        async def fake_post(self, url: str, json: dict, headers: dict) -> httpx.Response:
            # Sanity: the platform only sees the invite token once.
            assert headers["Authorization"] == "Bearer seed-invite"
            return httpx.Response(
                200,
                json={
                    "node_id": "node-new",
                    "node_token": "tok-fresh",
                },
            )

        with patch.object(httpx.AsyncClient, "post", new=fake_post):
            ok = asyncio.run(_register_with_platform(state))

        assert ok is True
        assert state.node_id == "node-new"
        assert state.node_token == "tok-fresh"
        # Persisted so the next boot skips registration.
        assert store.get_identity() == ("node-new", "tok-fresh")

    def test_missing_invite_without_identity_aborts(self, store: NodeInstanceStore):
        state = _make_state(store, registration_token="")
        ok = asyncio.run(_register_with_platform(state))
        assert ok is False
        assert state.node_id == ""
        assert state.node_token == ""
        assert store.get_identity() is None

    def test_403_from_platform_does_not_persist_identity(
        self, store: NodeInstanceStore
    ):
        state = _make_state(store, registration_token="stale-invite")

        async def fake_post(self, url: str, json: dict, headers: dict) -> httpx.Response:
            return httpx.Response(403, text="Invite consumed")

        with patch.object(httpx.AsyncClient, "post", new=fake_post):
            ok = asyncio.run(_register_with_platform(state))

        assert ok is False
        assert store.get_identity() is None


# ---------------------------------------------------------------------------
# Heartbeat stale-identity recovery
# ---------------------------------------------------------------------------


class TestHeartbeatStaleIdentity:
    @pytest.mark.parametrize("status", [401, 403, 404])
    def test_rejected_heartbeat_clears_persisted_identity(
        self, store: NodeInstanceStore, status: int
    ):
        store.put_identity("node-stale", "tok-stale")
        state = _make_state(store)
        state.node_id = "node-stale"
        state.node_token = "tok-stale"

        async def fake_post(self, url: str, json: dict, headers: dict) -> httpx.Response:
            return httpx.Response(status, text=f"rejected {status}")

        with patch.object(httpx.AsyncClient, "post", new=fake_post):
            asyncio.run(_heartbeat_once(state))

        assert store.get_identity() is None, (
            f"status={status} should have cleared persisted identity "
            "so next restart re-registers"
        )

    def test_transient_network_error_keeps_identity(self, store: NodeInstanceStore):
        store.put_identity("node-ok", "tok-ok")
        state = _make_state(store)
        state.node_id = "node-ok"
        state.node_token = "tok-ok"

        async_mock = AsyncMock(side_effect=httpx.ConnectError("platform unreachable"))
        with patch.object(httpx.AsyncClient, "post", async_mock):
            asyncio.run(_heartbeat_once(state))

        assert store.get_identity() == ("node-ok", "tok-ok")

    def test_200_heartbeat_keeps_identity(self, store: NodeInstanceStore):
        store.put_identity("node-ok", "tok-ok")
        state = _make_state(store)
        state.node_id = "node-ok"
        state.node_token = "tok-ok"

        async def fake_post(self, url: str, json: dict, headers: dict) -> httpx.Response:
            return httpx.Response(200, text="")

        with patch.object(httpx.AsyncClient, "post", new=fake_post):
            asyncio.run(_heartbeat_once(state))

        assert store.get_identity() == ("node-ok", "tok-ok")
