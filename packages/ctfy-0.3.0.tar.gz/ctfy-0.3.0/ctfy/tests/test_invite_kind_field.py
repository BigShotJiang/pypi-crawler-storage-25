"""TDD: TeamInviteState gains ``kind`` and ``target_user_id`` fields.

These fields are the schema foundation for two upcoming invite
mechanisms layered on top of the existing code-based redeem flow:

* ``kind="direct"`` — captain hands a specific user (looked up by
  exact email) a one-shot invite. ``target_user_id`` is the recipient.
* ``kind="join_request"`` — a member asks to join a specific team.
  ``created_by_user_id`` is the requester; the captain accepts/rejects.

Existing code-based invites become ``kind="code"`` (the default) with
``target_user_id == ""`` — old rows must continue to round-trip
without changes.

This module pins:

* model defaults (kind="code", target_user_id="")
* model accepts the three documented kinds and rejects unknown ones
* SQLite round-trip preserves both new fields
* InMemoryBackend round-trip preserves both new fields
* legacy SQLite DBs (pre-v6 schema) migrate forward — columns added
  with sane defaults; old rows readable as ``kind="code"``,
  ``target_user_id=""``
"""

from __future__ import annotations

import sqlite3

import pytest
from pydantic import ValidationError

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import TeamInviteState
from ctfy.core.state.sqlite import SQLiteBackend


# -- model ------------------------------------------------------------------


def test_invite_defaults_to_code_kind_and_empty_target():
    """A vanilla TeamInviteState() must default to the legacy
    code-redeem semantics: kind="code", target_user_id="". This
    keeps every existing call site (which doesn't pass either
    field yet) producing rows that look exactly like pre-refactor
    invites.
    """
    inv = TeamInviteState()
    assert inv.kind == "code"
    assert inv.target_user_id == ""


def test_invite_accepts_direct_and_join_request_kinds():
    direct = TeamInviteState(kind="direct", target_user_id="u-target")
    assert direct.kind == "direct"
    assert direct.target_user_id == "u-target"

    request = TeamInviteState(kind="join_request", created_by_user_id="u-req")
    assert request.kind == "join_request"


def test_invite_rejects_unknown_kind():
    with pytest.raises(ValidationError):
        TeamInviteState(kind="totally-bogus")  # type: ignore[arg-type]


# -- in-memory round-trip ---------------------------------------------------


def test_memory_backend_preserves_kind_and_target_user_id():
    be = InMemoryBackend()
    be.put_team_invite(
        TeamInviteState(
            invite_id="inv-direct",
            team_id="t1",
            code="DIRECT01",
            kind="direct",
            target_user_id="u-target",
        )
    )
    fetched = be.get_team_invite("inv-direct")
    assert fetched is not None
    assert fetched.kind == "direct"
    assert fetched.target_user_id == "u-target"


# -- sqlite round-trip ------------------------------------------------------


def test_sqlite_backend_preserves_kind_and_target_user_id(tmp_path):
    db_path = str(tmp_path / "kind.sqlite3")
    backend = SQLiteBackend(db_path)
    backend.put_team_invite(
        TeamInviteState(
            invite_id="inv-req",
            team_id="t1",
            code="REQ12345",
            kind="join_request",
            target_user_id="",
            created_by_user_id="u-requester",
        )
    )
    fetched = backend.get_team_invite("inv-req")
    assert fetched is not None
    assert fetched.kind == "join_request"
    assert fetched.target_user_id == ""
    assert fetched.created_by_user_id == "u-requester"


def test_sqlite_legacy_invites_default_to_code_kind(tmp_path):
    """Persist a code-style invite, simulate it being read by code
    that's aware of the new fields. The fetched row must surface
    kind="code" and target_user_id="" — never None — so every
    consumer can safely branch on ``inv.kind``.
    """
    db_path = str(tmp_path / "legacy.sqlite3")
    backend = SQLiteBackend(db_path)
    backend.put_team_invite(
        TeamInviteState(
            invite_id="legacy", team_id="t1", code="LEGACY12"
        )
    )
    fetched = backend.get_team_invite("legacy")
    assert fetched is not None
    assert fetched.kind == "code"
    assert fetched.target_user_id == ""


# -- migration --------------------------------------------------------------


def _seed_pre_v6_db(db_path: str) -> None:
    """Build a SQLite file that's already through migrations v1–v5
    but predates the kind/target_user_id columns.

    Mirrors the layout produced by the v5 schema: every table the
    runtime expects exists, ``team_invites`` has the v3 columns
    (incl. competition_id) but NOT the v6 ones, and user_version=5
    so the boot path runs only the v6 step.
    """
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(
            """
            CREATE TABLE users (
                user_id TEXT PRIMARY KEY,
                email TEXT NOT NULL DEFAULT '',
                data TEXT NOT NULL
            );
            CREATE TABLE teams (
                team_id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE team_memberships (
                user_id TEXT NOT NULL,
                competition_id TEXT NOT NULL DEFAULT '',
                team_id TEXT NOT NULL,
                joined_at TEXT NOT NULL DEFAULT '',
                joined_via TEXT NOT NULL DEFAULT '',
                invited_by_user_id TEXT NOT NULL DEFAULT '',
                PRIMARY KEY (user_id, competition_id)
            );
            CREATE TABLE team_invites (
                invite_id TEXT PRIMARY KEY,
                team_id TEXT NOT NULL,
                code TEXT NOT NULL UNIQUE,
                created_by_user_id TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                expires_at TEXT NOT NULL DEFAULT '',
                max_uses INTEGER NOT NULL DEFAULT 1,
                use_count INTEGER NOT NULL DEFAULT 0,
                revoked_at TEXT NOT NULL DEFAULT '',
                competition_id TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE oauth_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                provider TEXT NOT NULL, provider_user_id TEXT NOT NULL,
                data TEXT NOT NULL, UNIQUE(provider, provider_user_id)
            );
            CREATE TABLE password_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE, data TEXT NOT NULL
            );
            CREATE TABLE team_tokens (
                token_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL, data TEXT NOT NULL
            );
            INSERT INTO team_invites
                (invite_id, team_id, code, competition_id)
            VALUES
                ('legacy-1', 't1', 'OLDCODE1', 'spring-ctf');
            PRAGMA user_version = 5;
            """
        )
        conn.commit()
    finally:
        conn.close()


def test_v6_invite_kind_columns_added_to_legacy_db(tmp_path):
    """A pre-v6 SQLite DB must boot cleanly — the v6 migration adds
    ``kind`` and ``target_user_id`` to ``team_invites`` with sane
    defaults, leaves existing rows readable as ``kind="code"``, and
    bumps user_version to 6.
    """
    db_path = str(tmp_path / "pre_v6.sqlite3")
    _seed_pre_v6_db(db_path)

    backend = SQLiteBackend(db_path)
    legacy = backend.get_team_invite("legacy-1")
    assert legacy is not None, "legacy invite must survive the migration"
    assert legacy.kind == "code"
    assert legacy.target_user_id == ""
    assert legacy.competition_id == "spring-ctf"

    conn = sqlite3.connect(db_path)
    try:
        cols = {row[1] for row in conn.execute("PRAGMA table_info(team_invites)")}
        assert "kind" in cols
        assert "target_user_id" in cols
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        assert version >= 6
    finally:
        conn.close()

    # Re-opening must be a no-op (idempotent migration).
    backend2 = SQLiteBackend(db_path)
    assert backend2.get_team_invite("legacy-1") is not None
