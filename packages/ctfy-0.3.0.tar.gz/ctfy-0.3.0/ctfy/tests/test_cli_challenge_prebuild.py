"""`ctfy challenge prebuild` walks challenges_dir and runs `docker compose
pull|build` for each match. We stub subprocess so the test never shells
out to a real docker daemon, and exercise the typer command via CliRunner
to cover the wiring (filtering, summary, --jobs, exit codes)."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from ctfy.cli.challenge import challenge_app


def _make_challenge(root: Path, cid: str, *, difficulty: str = "easy", tags: list[str] | None = None) -> None:
    cdir = root / cid
    cdir.mkdir(parents=True)
    tags_yaml = "\n".join(f"  - {t}" for t in (tags or ["web"]))
    (cdir / "metadata.yaml").write_text(
        f"name: {cid}\n"
        f"description: test challenge {cid}\n"
        f"difficulty: {difficulty}\n"
        f"tags:\n{tags_yaml}\n"
    )
    (cdir / "docker-compose.yml").write_text(
        "services:\n  app:\n    image: alpine:3\n"
    )


def _ok_result() -> MagicMock:
    r = MagicMock(spec=subprocess.CompletedProcess)
    r.returncode = 0
    r.stdout = ""
    r.stderr = ""
    return r


def _fail_result(stderr: str = "build error: missing FROM") -> MagicMock:
    r = MagicMock(spec=subprocess.CompletedProcess)
    r.returncode = 1
    r.stdout = ""
    r.stderr = stderr
    return r


class TestChallengePrebuild:
    @patch("ctfy.cli.challenge.subprocess.run")
    def test_runs_pull_then_build_per_challenge(self, run_stub, tmp_path: Path):
        _make_challenge(tmp_path, "alpha")
        _make_challenge(tmp_path, "beta")
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(
            challenge_app, ["prebuild", "--challenges-dir", str(tmp_path)]
        )
        assert result.exit_code == 0, result.output

        # Two challenges × (pull + build) = 4 invocations.
        assert run_stub.call_count == 4
        steps = [call.args[0][-1] for call in run_stub.call_args_list]
        # Sequential mode preserves submission order: pull,build,pull,build.
        assert steps == ["pull", "build", "pull", "build"]

        # Project name namespacing keeps prebuild artifacts off live instances.
        for call in run_stub.call_args_list:
            argv = call.args[0]
            assert argv[:4] == ["docker", "compose", "-p", argv[3]]
            assert argv[3].startswith("ctfy-prebuild-")

        assert "2 ok, 0 failed" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_filter_by_challenge_id(self, run_stub, tmp_path: Path):
        _make_challenge(tmp_path, "alpha")
        _make_challenge(tmp_path, "beta")
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(
            challenge_app,
            ["prebuild", "--challenges-dir", str(tmp_path), "--challenge", "alpha"],
        )
        assert result.exit_code == 0, result.output
        # Only alpha → 2 calls (pull + build).
        assert run_stub.call_count == 2
        for call in run_stub.call_args_list:
            assert call.args[0][3] == "ctfy-prebuild-alpha"

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_continues_after_failure_and_exits_nonzero(
        self, run_stub, tmp_path: Path
    ):
        _make_challenge(tmp_path, "alpha")
        _make_challenge(tmp_path, "beta")
        # alpha: pull fails. beta: both succeed.
        # Our impl skips build when pull fails, so we expect 3 calls total.
        # Sequential mode (default) streams output, so the failure summary
        # only carries the exit code, not the captured stderr — see the
        # parallel test below for the captured-tail variant.
        results = iter(
            [
                _fail_result("ECONNREFUSED registry"),  # alpha pull
                _ok_result(),  # beta pull
                _ok_result(),  # beta build
            ]
        )
        run_stub.side_effect = lambda *a, **kw: next(results)

        result = CliRunner().invoke(
            challenge_app, ["prebuild", "--challenges-dir", str(tmp_path)]
        )
        assert result.exit_code == 1, result.output
        assert run_stub.call_count == 3
        assert "1 ok, 1 failed" in result.output
        assert "alpha" in result.output
        assert "pull" in result.output
        assert "see output above" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_sequential_streams_output_no_capture(
        self, run_stub, tmp_path: Path
    ):
        # Default --jobs 1: subprocess.run must NOT capture, so compose's
        # `[+] Building n/m` lines reach the user's terminal in real time.
        _make_challenge(tmp_path, "alpha")
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(
            challenge_app, ["prebuild", "--challenges-dir", str(tmp_path)]
        )
        assert result.exit_code == 0, result.output
        for call in run_stub.call_args_list:
            assert "capture_output" not in call.kwargs
            assert "text" not in call.kwargs

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_parallel_captures_output_and_surfaces_tail(
        self, run_stub, tmp_path: Path
    ):
        # --jobs > 1: must capture (otherwise concurrent compose processes
        # interleave on the terminal) and the failure tail goes into the
        # summary table since the user never saw it stream by.
        _make_challenge(tmp_path, "alpha")
        _make_challenge(tmp_path, "beta")
        results = iter(
            [
                _fail_result("ECONNREFUSED registry"),  # one challenge fails on pull
                _ok_result(),
                _ok_result(),
            ]
        )
        run_stub.side_effect = lambda *a, **kw: next(results)

        result = CliRunner().invoke(
            challenge_app,
            ["prebuild", "--challenges-dir", str(tmp_path), "--jobs", "2"],
        )
        assert result.exit_code == 1, result.output
        for call in run_stub.call_args_list:
            assert call.kwargs.get("capture_output") is True
            assert call.kwargs.get("text") is True
        assert "ECONNREFUSED" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_jobs_parallel_runs_every_challenge(self, run_stub, tmp_path: Path):
        for cid in ("a", "b", "c", "d"):
            _make_challenge(tmp_path, cid)
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(
            challenge_app,
            ["prebuild", "--challenges-dir", str(tmp_path), "--jobs", "4"],
        )
        assert result.exit_code == 0, result.output
        # 4 challenges × 2 steps.
        assert run_stub.call_count == 8
        assert "4 ok, 0 failed" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_uppercase_challenge_id_lowercased_for_project_name(
        self, run_stub, tmp_path: Path
    ):
        # Upstream challenge IDs like ``CTFARENA-00`` are uppercase; compose
        # rejects uppercase project names, so prebuild must lowercase the id.
        _make_challenge(tmp_path, "CTFARENA-00")
        run_stub.return_value = _ok_result()

        result = CliRunner().invoke(
            challenge_app, ["prebuild", "--challenges-dir", str(tmp_path)]
        )
        assert result.exit_code == 0, result.output
        for call in run_stub.call_args_list:
            project = call.args[0][3]
            assert project == "ctfy-prebuild-ctfarena-00"

    def test_no_match_exits_nonzero(self, tmp_path: Path):
        # challenges_dir exists but is empty.
        result = CliRunner().invoke(
            challenge_app, ["prebuild", "--challenges-dir", str(tmp_path)]
        )
        assert result.exit_code == 2, result.output
        assert "No challenges matched" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_missing_compose_file_reports_failure(
        self, run_stub, tmp_path: Path
    ):
        # metadata.yaml without docker-compose.yml.
        cdir = tmp_path / "broken"
        cdir.mkdir()
        (cdir / "metadata.yaml").write_text(
            "name: broken\n"
            "description: missing compose\n"
            "difficulty: easy\n"
            "tags:\n  - web\n"
        )

        result = CliRunner().invoke(
            challenge_app, ["prebuild", "--challenges-dir", str(tmp_path)]
        )
        assert result.exit_code == 1, result.output
        # Never shelled out — failure detected before subprocess.
        run_stub.assert_not_called()
        assert "docker-compose.yml not found" in result.output

    @patch("ctfy.cli.challenge.subprocess.run")
    def test_docker_binary_missing_reports_failure(
        self, run_stub, tmp_path: Path
    ):
        _make_challenge(tmp_path, "alpha")
        run_stub.side_effect = FileNotFoundError("docker")

        result = CliRunner().invoke(
            challenge_app, ["prebuild", "--challenges-dir", str(tmp_path)]
        )
        assert result.exit_code == 1, result.output
        assert "docker" in result.output.lower()
