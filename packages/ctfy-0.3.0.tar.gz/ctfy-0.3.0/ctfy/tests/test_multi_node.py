"""Tests for multi-node support: registration, heartbeat, reconciler, scheduling."""

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import NodeState
from ctfy.tests.conftest import build_spec, make_mock_challenge_manager, mint_team


@pytest.fixture
def mock_env_manager():
    return make_mock_challenge_manager(
        flag="FLAG{multinode_test_flag_0123456789ab}",
        challenge_specs=[
            build_spec("MN-001", name="MultiNode Test"),
        ],
    )


class AuthTestClient(TestClient):
    """TestClient that automatically adds admin auth headers."""

    def __init__(self, app, *, admin_token: str) -> None:
        super().__init__(app)
        self._admin_token = admin_token

    def request(self, *args, **kwargs):
        headers = kwargs.pop("headers", None) or {}
        headers.setdefault("Authorization", f"Bearer {self._admin_token}")
        kwargs["headers"] = headers
        return super().request(*args, **kwargs)


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def client(mock_env_manager, backend):
    from ctfy.server.app import create_app

    # Provision an admin team up-front so every auth'd call rides on
    # is_admin=True credentials — same surface as CTFY_ADMIN_TOKEN used to.
    admin = mint_team(backend, name="admin", email="admin@example.com", is_admin=True)
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    return AuthTestClient(app, admin_token=admin.token)


class TestNodeRegistration:
    def test_register_node(self, client):
        r = client.post(
            "/api/v1/nodes/register",
            json={
                "url": "http://node1:8100",
                "display_name": "node1",
                "capacity": 20,
            },
        )
        assert r.status_code == 200
        data = r.json()
        assert data["url"] == "http://node1:8100"
        assert data["capacity"] == 20
        assert data["healthy"] is True

    def test_list_nodes(self, client):
        client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n1:8100", "display_name": "n1", "capacity": 10},
        )
        client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n2:8100", "display_name": "n2", "capacity": 20},
        )
        r = client.get("/api/v1/nodes")
        assert len(r.json()["items"]) == 2

    def test_remove_node(self, client):
        r = client.post(
            "/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"}
        )
        node_id = r.json()["node_id"]
        client.delete(f"/api/v1/nodes/{node_id}")
        assert len(client.get("/api/v1/nodes").json()["items"]) == 0


class TestHeartbeat:
    def test_heartbeat_updates_status(self, client):
        r = client.post(
            "/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"}
        )
        node_id = r.json()["node_id"]

        r = client.post(
            "/api/v1/nodes/heartbeat",
            json={
                "node_id": node_id,
                "running": 3,
                "capacity": 10,
                "cpu_percent": 12.5,
                "memory_percent": 34.0,
                "disk_percent": 56.7,
            },
        )
        assert r.json()["status"] == "ok"

        nodes = client.get("/api/v1/nodes").json()["items"]
        n = next(n for n in nodes if n["node_id"] == node_id)
        assert n["running"] == 3
        assert n["healthy"] is True
        # Metric sample round-trips into NodeInfo.
        assert n["cpu_percent"] == 12.5
        assert n["memory_percent"] == 34.0
        assert n["disk_percent"] == 56.7

    def test_heartbeat_unknown_node_404(self, client):
        r = client.post("/api/v1/nodes/heartbeat", json={"node_id": "unknown"})
        assert r.status_code == 404


class TestNodeScheduling:
    def test_no_nodes_rejects_start(self, mock_env_manager):
        """Without a healthy registered node, POST /instances returns 503."""
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        c = TestClient(app)
        team = mint_team(backend, name="mn", email="mn@example.test")
        auth = team.headers

        r = c.post(
            "/api/v1/instances",
            json={
                "challenge_id": "LOCAL-001",
                "ttl": 300,
            },
            headers=auth,
        )
        # CapacityExceededError is mapped to 503.
        assert r.status_code == 503, r.text
        assert "no healthy node" in r.text.lower()

    def test_activity_logged_on_register(self, client, backend):
        client.post("/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"})
        # Node events are operational (empty team_id) and not exposed over
        # the team-scoped /activities endpoint — assert via the backend.
        acts = backend.list_activities(event="node_registered")
        assert len(acts) >= 1


class TestStateBackendNodes:
    def test_put_get_list(self):
        be = InMemoryBackend()
        be.put_node("n1", NodeState(node_id="n1", url="http://n1:8100", capacity=10))
        n = be.get_node("n1")
        assert n.url == "http://n1:8100"
        assert len(be.list_nodes()) == 1

    def test_remove(self):
        be = InMemoryBackend()
        be.put_node("n1", NodeState(node_id="n1", url="http://n1:8100"))
        be.remove_node("n1")
        assert be.get_node("n1") is None

    def test_get_missing(self):
        be = InMemoryBackend()
        assert be.get_node("nope") is None

    def test_get_node_by_token(self):
        be = InMemoryBackend()
        be.put_node("n1", NodeState(node_id="n1", url="http://n1", token="abc"))
        be.put_node("n2", NodeState(node_id="n2", url="http://n2", token="def"))
        assert be.get_node_by_token("abc").node_id == "n1"
        assert be.get_node_by_token("def").node_id == "n2"
        assert be.get_node_by_token("nope") is None
        assert be.get_node_by_token("") is None


class TestPerNodeToken:
    """Nodes get an individual token at registration; they cannot act as
    another node, and re-registration rotates the token."""

    def test_register_returns_node_token(self, client):
        r = client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n1:8100", "display_name": "n1", "capacity": 10},
        )
        assert r.status_code == 200
        body = r.json()
        # NodeInfo fields still present (back-compat for older clients)
        assert body["url"] == "http://n1:8100"
        assert body["capacity"] == 10
        # New field: per-node bearer token, returned once, plaintext
        assert body["node_token"]
        assert len(body["node_token"]) >= 32

    def test_heartbeat_with_per_node_token(self, client):
        r = client.post(
            "/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"}
        )
        tok = r.json()["node_token"]
        node_id = r.json()["node_id"]
        hb = client.post(
            "/api/v1/nodes/heartbeat",
            json={"node_id": node_id, "running": 2, "capacity": 10},
            headers={"Authorization": f"Bearer {tok}"},
        )
        assert hb.status_code == 200
        assert hb.json()["status"] == "ok"

    def test_heartbeat_cross_node_rejected(self, client):
        r1 = client.post(
            "/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"}
        )
        r2 = client.post(
            "/api/v1/nodes/register", json={"url": "http://n2:8100", "display_name": "n2"}
        )
        tok1 = r1.json()["node_token"]
        node2 = r2.json()["node_id"]
        hb = client.post(
            "/api/v1/nodes/heartbeat",
            json={"node_id": node2},
            headers={"Authorization": f"Bearer {tok1}"},
        )
        assert hb.status_code == 403

    def test_delete_cross_node_rejected(self, client):
        r1 = client.post(
            "/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"}
        )
        r2 = client.post(
            "/api/v1/nodes/register", json={"url": "http://n2:8100", "display_name": "n2"}
        )
        tok1 = r1.json()["node_token"]
        node2 = r2.json()["node_id"]
        d = client.delete(f"/api/v1/nodes/{node2}", headers={"Authorization": f"Bearer {tok1}"})
        assert d.status_code == 403
        items = client.get("/api/v1/nodes").json()["items"]
        assert any(n["node_id"] == node2 for n in items)

    def test_reregistration_invalidates_old_token(self, client):
        r1 = client.post(
            "/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"}
        )
        old_tok = r1.json()["node_token"]
        node_id = r1.json()["node_id"]
        r2 = client.post(
            "/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"}
        )
        new_tok = r2.json()["node_token"]
        assert old_tok != new_tok

        # Old token no longer authenticates.
        hb_old = client.post(
            "/api/v1/nodes/heartbeat",
            json={"node_id": node_id},
            headers={"Authorization": f"Bearer {old_tok}"},
        )
        assert hb_old.status_code == 403

        # New token does.
        hb_new = client.post(
            "/api/v1/nodes/heartbeat",
            json={"node_id": node_id},
            headers={"Authorization": f"Bearer {new_tok}"},
        )
        assert hb_new.status_code == 200

    def test_token_not_exposed_in_list(self, client):
        client.post("/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"})
        items = client.get("/api/v1/nodes").json()["items"]
        assert items
        # Plaintext token must never leak via public /nodes.
        assert "token" not in items[0]
        assert "node_token" not in items[0]

    def test_admin_token_works_on_heartbeat(self, client):
        """Admin is the emergency auth path for node→platform calls after
        the cluster token was removed. Per-node tokens are still preferred."""
        r = client.post(
            "/api/v1/nodes/register", json={"url": "http://n1:8100", "display_name": "n1"}
        )
        node_id = r.json()["node_id"]

        hb = client.post(
            "/api/v1/nodes/heartbeat",
            json={"node_id": node_id, "running": 1},
            # client fixture auto-injects admin bearer; be explicit so the
            # test reads as "admin identity".
            headers={"Authorization": f"Bearer {client._admin_token}"},
        )
        assert hb.status_code == 200
