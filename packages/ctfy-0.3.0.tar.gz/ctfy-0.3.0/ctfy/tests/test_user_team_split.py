"""TDD: backend storage for the user/team split.

Today ``TeamState`` is the human — it carries email, OAuth identities,
tokens, role, etc. After the split:

  * ``UserState`` is the human (auth, profile, role).
  * ``TeamState`` is a pure container (name, captain, members).
  * ``TeamMembershipState`` maps user → team; one team at a time.
  * ``TeamInviteState`` is the captain-issued join code.

These tests exercise the new contracts on **both** the InMemoryBackend
and SQLiteBackend so the two impls cannot drift. Each fixture yields
a freshly-instantiated backend so cross-test state cannot leak.
"""

from __future__ import annotations

import os
import tempfile
from datetime import datetime, timedelta, timezone

import pytest

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import (
    TeamInviteState,
    TeamMembershipState,
    TeamState,
    UserState,
)
from ctfy.core.state.sqlite import SQLiteBackend


def _iso(offset_seconds: int = 0) -> str:
    return (datetime.now(timezone.utc) + timedelta(seconds=offset_seconds)).isoformat()


@pytest.fixture(params=["memory", "sqlite"])
def backend(request):
    if request.param == "memory":
        yield InMemoryBackend()
        return
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        yield SQLiteBackend(path)
    finally:
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass


# ---------------------------------------------------------------------------
# UserState — basic CRUD + email lookup + role gating
# ---------------------------------------------------------------------------


class TestUserCrud:
    def test_put_get_round_trips(self, backend):
        u = UserState(
            user_id="u1",
            email="alice@example.test",
            display_name="Alice",
            role="user",
            created_at=_iso(0),
        )
        backend.put_user("u1", u)
        got = backend.get_user("u1")
        assert got is not None
        assert got.user_id == "u1"
        assert got.email == "alice@example.test"
        assert got.display_name == "Alice"
        assert got.role == "user"

    def test_get_user_by_email_case_insensitive(self, backend):
        u = UserState(
            user_id="u1",
            email="Alice@Example.Test",
            display_name="Alice",
            created_at=_iso(0),
        )
        backend.put_user("u1", u)
        assert backend.get_user_by_email("alice@example.test").user_id == "u1"
        assert backend.get_user_by_email("ALICE@EXAMPLE.TEST").user_id == "u1"
        assert backend.get_user_by_email("missing@example.test") is None

    def test_get_missing_returns_none(self, backend):
        assert backend.get_user("ghost") is None

    def test_list_users(self, backend):
        backend.put_user(
            "u1", UserState(user_id="u1", email="a@x", display_name="A", created_at=_iso(0))
        )
        backend.put_user(
            "u2", UserState(user_id="u2", email="b@x", display_name="B", created_at=_iso(0))
        )
        ids = {u.user_id for u in backend.list_users()}
        assert ids == {"u1", "u2"}

    def test_count_users(self, backend):
        assert backend.count_users() == 0
        backend.put_user(
            "u1", UserState(user_id="u1", email="a@x", display_name="A", created_at=_iso(0))
        )
        assert backend.count_users() == 1

    def test_first_user_aware_makes_first_super_admin(self, backend):
        """First registered user becomes super_admin atomically.

        Mirrors the existing ``put_team_first_user_aware`` behaviour so
        a fresh password-only deployment can come up without OAuth +
        env. Concurrent registrations cannot both win the race.
        """
        u1 = UserState(
            user_id="u1", email="first@x", display_name="First", created_at=_iso(0)
        )
        stored = backend.put_user_first_user_aware("u1", u1)
        assert stored.role == "super_admin"

        # Second registration is a regular user.
        u2 = UserState(
            user_id="u2", email="second@x", display_name="Second", created_at=_iso(0)
        )
        stored2 = backend.put_user_first_user_aware("u2", u2)
        assert stored2.role == "user"


# ---------------------------------------------------------------------------
# Team / membership invariants
# ---------------------------------------------------------------------------


class TestTeamMembership:
    def _make_user(self, backend, user_id: str = "u1", email: str = "u@x") -> UserState:
        u = UserState(
            user_id=user_id,
            email=email,
            display_name=user_id,
            created_at=_iso(0),
        )
        backend.put_user(user_id, u)
        return u

    def _make_team(
        self, backend, team_id: str = "t1", captain: str = "u1", name: str = "Team"
    ) -> TeamState:
        t = TeamState(
            team_id=team_id,
            name=name,
            captain_user_id=captain,
            created_at=_iso(0),
        )
        backend.put_team(team_id, t)
        return t

    def test_membership_round_trip(self, backend):
        self._make_user(backend, "u1")
        self._make_team(backend, "t1", captain="u1")
        m = TeamMembershipState(user_id="u1", team_id="t1", joined_at=_iso(0))
        backend.put_membership(m)
        got = backend.get_membership("u1")
        assert got is not None
        assert got.user_id == "u1"
        assert got.team_id == "t1"

    def test_one_team_at_a_time_invariant(self, backend):
        """``put_membership`` is upsert-by-user_id — the second write
        replaces the first so a user is always on exactly one team."""
        self._make_user(backend, "u1")
        self._make_team(backend, "t1", captain="u1")
        self._make_team(backend, "t2", captain="u1")
        backend.put_membership(
            TeamMembershipState(user_id="u1", team_id="t1", joined_at=_iso(0))
        )
        backend.put_membership(
            TeamMembershipState(user_id="u1", team_id="t2", joined_at=_iso(60))
        )
        got = backend.get_membership("u1")
        assert got.team_id == "t2"
        # And t1 no longer lists u1 as a member.
        assert {m.user_id for m in backend.list_memberships(team_id="t1")} == set()
        assert {m.user_id for m in backend.list_memberships(team_id="t2")} == {"u1"}

    def test_list_memberships_by_team(self, backend):
        self._make_user(backend, "u1")
        self._make_user(backend, "u2", email="b@x")
        self._make_user(backend, "u3", email="c@x")
        self._make_team(backend, "t1", captain="u1")
        self._make_team(backend, "t2", captain="u3")
        for uid in ("u1", "u2"):
            backend.put_membership(
                TeamMembershipState(user_id=uid, team_id="t1", joined_at=_iso(0))
            )
        backend.put_membership(
            TeamMembershipState(user_id="u3", team_id="t2", joined_at=_iso(0))
        )
        assert {m.user_id for m in backend.list_memberships(team_id="t1")} == {"u1", "u2"}
        assert {m.user_id for m in backend.list_memberships(team_id="t2")} == {"u3"}

    def test_count_memberships(self, backend):
        self._make_user(backend, "u1")
        self._make_user(backend, "u2", email="b@x")
        self._make_team(backend, "t1", captain="u1")
        for uid in ("u1", "u2"):
            backend.put_membership(
                TeamMembershipState(user_id=uid, team_id="t1", joined_at=_iso(0))
            )
        assert backend.count_memberships("t1") == 2
        assert backend.count_memberships("nonexistent") == 0

    def test_delete_membership(self, backend):
        self._make_user(backend, "u1")
        self._make_team(backend, "t1", captain="u1")
        backend.put_membership(
            TeamMembershipState(user_id="u1", team_id="t1", joined_at=_iso(0))
        )
        assert backend.delete_membership("u1") is True
        assert backend.get_membership("u1") is None
        # Idempotent on missing.
        assert backend.delete_membership("u1") is False

    def test_delete_team_cascades_memberships_and_invites(self, backend):
        self._make_user(backend, "u1")
        self._make_user(backend, "u2", email="b@x")
        self._make_team(backend, "t1", captain="u1")
        backend.put_membership(
            TeamMembershipState(user_id="u1", team_id="t1", joined_at=_iso(0))
        )
        backend.put_membership(
            TeamMembershipState(user_id="u2", team_id="t1", joined_at=_iso(0))
        )
        backend.put_team_invite(
            TeamInviteState(
                invite_id="i1",
                team_id="t1",
                code="abc12345",
                created_by_user_id="u1",
                created_at=_iso(0),
            )
        )
        assert backend.delete_team("t1") is True
        assert backend.get_membership("u1") is None
        assert backend.get_membership("u2") is None
        assert backend.list_team_invites(team_id="t1") == []

    def test_delete_user_cascades_membership(self, backend):
        self._make_user(backend, "u1")
        self._make_team(backend, "t1", captain="u1")
        backend.put_membership(
            TeamMembershipState(user_id="u1", team_id="t1", joined_at=_iso(0))
        )
        assert backend.delete_user("u1") is True
        assert backend.get_user("u1") is None
        assert backend.get_membership("u1") is None

    def test_team_carries_competition_id(self, backend):
        """``TeamState.competition_id`` round-trips through storage so
        Phase 2+ can populate it on per-competition team writes."""
        self._make_user(backend, "u1")
        team = TeamState(
            team_id="t1",
            name="Spring",
            captain_user_id="u1",
            created_at=_iso(0),
            competition_id="spring-ctf-2026",
        )
        backend.put_team("t1", team)
        got = backend.get_team("t1")
        assert got is not None
        assert got.competition_id == "spring-ctf-2026"

    def test_membership_carries_competition_id(self, backend):
        """``TeamMembershipState.competition_id`` round-trips through
        ``get_membership_for_competition`` — the new explicit lookup
        introduced alongside the composite PK."""
        self._make_user(backend, "u1")
        self._make_team(backend, "t1", captain="u1")
        backend.put_membership(
            TeamMembershipState(
                user_id="u1",
                team_id="t1",
                joined_at=_iso(0),
                competition_id="spring-ctf-2026",
            )
        )
        got = backend.get_membership_for_competition("u1", "spring-ctf-2026")
        assert got is not None
        assert got.competition_id == "spring-ctf-2026"
        # Convenience ``get_membership(user_id)`` returns the per-comp
        # row — there's no separate "default slot" any more.
        any_membership = backend.get_membership("u1")
        assert any_membership is not None
        assert any_membership.competition_id == "spring-ctf-2026"

    def test_user_can_have_multiple_memberships_one_per_competition(self, backend):
        """Phase 2a: PK on team_memberships is now (user_id,
        competition_id), so a user can be on team A in comp1 and
        team B in comp2 simultaneously."""
        self._make_user(backend, "u1")
        self._make_team(backend, "t1", captain="u1", name="Spring")
        self._make_team(backend, "t2", captain="u1", name="Summer")
        backend.put_membership(
            TeamMembershipState(
                user_id="u1",
                team_id="t1",
                joined_at=_iso(0),
                competition_id="spring-ctf-2026",
            )
        )
        backend.put_membership(
            TeamMembershipState(
                user_id="u1",
                team_id="t2",
                joined_at=_iso(60),
                competition_id="summer-ctf-2026",
            )
        )
        # Both memberships coexist — this is the new invariant.
        spring = backend.get_membership_for_competition("u1", "spring-ctf-2026")
        summer = backend.get_membership_for_competition("u1", "summer-ctf-2026")
        assert spring is not None and spring.team_id == "t1"
        assert summer is not None and summer.team_id == "t2"
        # ``list_memberships(user_id=)`` returns both rows.
        all_for_u1 = backend.list_memberships(user_id="u1")
        assert {m.team_id for m in all_for_u1} == {"t1", "t2"}

    def test_get_membership_for_competition_returns_none_for_unknown(self, backend):
        self._make_user(backend, "u1")
        assert backend.get_membership_for_competition("u1", "nope") is None
        assert backend.get_membership_for_competition("ghost", "spring") is None

    def test_create_team_for_competition_atomic(self, backend):
        """Phase 2b: ``create_team_for_competition`` writes the team
        row + the membership row in one atomic step. The user is the
        captain; the new team is scoped to the given competition."""
        self._make_user(backend, "u1")
        team = backend.create_team_for_competition(
            user_id="u1",
            competition_id="spring-ctf",
            team_name="Pwners",
            description="go brrr",
            now_iso=_iso(0),
            joined_via="create",
        )
        assert team.team_id  # server-minted
        assert team.competition_id == "spring-ctf"
        assert team.captain_user_id == "u1"
        assert team.name == "Pwners"
        assert team.description == "go brrr"

        # Membership exists pointing at the new team.
        m = backend.get_membership_for_competition("u1", "spring-ctf")
        assert m is not None
        assert m.team_id == team.team_id
        assert m.competition_id == "spring-ctf"
        assert m.joined_via == "create"

    def test_create_team_for_competition_idempotent(self, backend):
        """Calling twice for the same (user, comp) returns the
        already-existing team — no second team minted, no membership
        churn. This is what the in-page Solo button relies on
        (double-click safe)."""
        self._make_user(backend, "u1")
        first = backend.create_team_for_competition(
            user_id="u1",
            competition_id="spring-ctf",
            team_name="Pwners",
            now_iso=_iso(0),
        )
        second = backend.create_team_for_competition(
            user_id="u1",
            competition_id="spring-ctf",
            team_name="Different Name",  # ignored — team already exists
            now_iso=_iso(60),
        )
        assert first.team_id == second.team_id
        assert second.name == "Pwners"  # original name kept
        # Only one team exists for (u1, spring-ctf).
        teams_in_comp = [
            t for t in backend.list_teams() if t.competition_id == "spring-ctf"
        ]
        assert len(teams_in_comp) == 1

    def test_create_team_for_competition_concurrent_safe(self, backend):
        """50 concurrent calls for the same (user, comp) → exactly
        one team minted. Every caller gets the same team_id back.
        This is the atomicity contract that closes the in-page Solo
        race window (user double-clicks faster than the round-trip)."""
        from concurrent.futures import ThreadPoolExecutor

        self._make_user(backend, "u1")

        def _attempt():
            return backend.create_team_for_competition(
                user_id="u1",
                competition_id="spring-ctf",
                team_name="Pwners",
                now_iso=_iso(0),
            )

        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: _attempt(), range(50)))

        team_ids = {t.team_id for t in results}
        assert len(team_ids) == 1, (
            f"Concurrent calls minted {len(team_ids)} distinct teams; "
            "the atomic op is not idempotent."
        )

    def test_redeem_invite_for_competition_happy_path(self, backend):
        """Captain mints comp-scoped invite; another user redeems it
        atomically — joins the captain's team for that comp + invite
        use_count increments by one. Returns (team, "ok")."""
        self._make_user(backend, "captain")
        self._make_user(backend, "joiner", email="j@x")
        # Captain has a team for spring-ctf.
        team = backend.create_team_for_competition(
            user_id="captain",
            competition_id="spring-ctf",
            team_name="Pwners",
            now_iso=_iso(0),
        )
        # Captain mints an invite for that team in that comp.
        backend.put_team_invite(
            TeamInviteState(
                invite_id="inv1",
                team_id=team.team_id,
                code="JOIN1234",
                created_by_user_id="captain",
                created_at=_iso(0),
                max_uses=2,
                competition_id="spring-ctf",
            )
        )
        joined, status = backend.redeem_team_invite_for_competition(
            code="JOIN1234",
            user_id="joiner",
            competition_id="spring-ctf",
            now_iso=_iso(60),
        )
        assert status == "ok"
        assert joined is not None
        assert joined.team_id == team.team_id
        # Membership written.
        m = backend.get_membership_for_competition("joiner", "spring-ctf")
        assert m is not None
        assert m.team_id == team.team_id
        assert m.joined_via == "redeem"
        assert m.invited_by_user_id == "captain"
        # use_count incremented.
        inv_after = backend.get_team_invite_by_code("JOIN1234")
        assert inv_after is not None
        assert inv_after.use_count == 1

    def test_redeem_invite_unknown_code(self, backend):
        self._make_user(backend, "u1")
        joined, status = backend.redeem_team_invite_for_competition(
            code="NO-SUCH",
            user_id="u1",
            competition_id="spring-ctf",
            now_iso=_iso(0),
        )
        assert joined is None
        assert status == "unknown_code"

    def test_redeem_invite_wrong_competition(self, backend):
        """Invite was minted for spring-ctf; user tries to redeem
        against summer-ctf. Defensive — invites are looked up by code
        globally, so an attacker who finds a code can't use it for a
        comp it wasn't intended for."""
        self._make_user(backend, "captain")
        self._make_user(backend, "joiner", email="j@x")
        team = backend.create_team_for_competition(
            user_id="captain",
            competition_id="spring-ctf",
            team_name="Pwners",
            now_iso=_iso(0),
        )
        backend.put_team_invite(
            TeamInviteState(
                invite_id="inv1",
                team_id=team.team_id,
                code="JOIN1234",
                created_by_user_id="captain",
                created_at=_iso(0),
                max_uses=2,
                competition_id="spring-ctf",
            )
        )
        joined, status = backend.redeem_team_invite_for_competition(
            code="JOIN1234",
            user_id="joiner",
            competition_id="summer-ctf",
            now_iso=_iso(60),
        )
        assert joined is None
        assert status == "wrong_competition"
        # use_count NOT incremented — the invite is still consumable.
        assert backend.get_team_invite_by_code("JOIN1234").use_count == 0

    def test_redeem_invite_already_member(self, backend):
        """User is already on a team for this comp — redeem rejected.
        Otherwise they'd be silently moved between teams without going
        through ``leave`` first."""
        self._make_user(backend, "captain")
        self._make_user(backend, "joiner", email="j@x")
        team_a = backend.create_team_for_competition(
            user_id="captain",
            competition_id="spring-ctf",
            team_name="Alpha",
            now_iso=_iso(0),
        )
        # Joiner already has their own solo team for spring-ctf.
        backend.create_team_for_competition(
            user_id="joiner",
            competition_id="spring-ctf",
            team_name="Joiner Solo",
            now_iso=_iso(0),
        )
        backend.put_team_invite(
            TeamInviteState(
                invite_id="inv1",
                team_id=team_a.team_id,
                code="JOIN1234",
                created_by_user_id="captain",
                created_at=_iso(0),
                max_uses=2,
                competition_id="spring-ctf",
            )
        )
        joined, status = backend.redeem_team_invite_for_competition(
            code="JOIN1234",
            user_id="joiner",
            competition_id="spring-ctf",
            now_iso=_iso(60),
        )
        assert joined is None
        assert status == "already_member"
        # use_count NOT incremented — the invite is still consumable.
        assert backend.get_team_invite_by_code("JOIN1234").use_count == 0

    def test_redeem_invite_concurrent_max_uses_one(self, backend):
        """5 users race to redeem a max_uses=1 invite. Exactly one
        gets "ok"; the other four get "expired_or_revoked". The
        invite row settles at use_count=1."""
        from concurrent.futures import ThreadPoolExecutor

        self._make_user(backend, "captain")
        team = backend.create_team_for_competition(
            user_id="captain",
            competition_id="spring-ctf",
            team_name="Alpha",
            now_iso=_iso(0),
        )
        backend.put_team_invite(
            TeamInviteState(
                invite_id="inv1",
                team_id=team.team_id,
                code="JOIN1234",
                created_by_user_id="captain",
                created_at=_iso(0),
                max_uses=1,
                competition_id="spring-ctf",
            )
        )
        for i in range(5):
            self._make_user(backend, f"j{i}", email=f"j{i}@x")

        def _attempt(idx: int):
            return backend.redeem_team_invite_for_competition(
                code="JOIN1234",
                user_id=f"j{idx}",
                competition_id="spring-ctf",
                now_iso=_iso(60),
            )

        with ThreadPoolExecutor(max_workers=5) as pool:
            results = list(pool.map(_attempt, range(5)))

        statuses = [s for _, s in results]
        assert statuses.count("ok") == 1
        assert statuses.count("expired_or_revoked") == 4
        assert backend.get_team_invite_by_code("JOIN1234").use_count == 1

    def test_legacy_get_membership_returns_default_competition_row(self, backend):
        """Backward compat: ``get_membership(user_id)`` still works,
        returning the row where ``competition_id == ""`` (the legacy
        default). Phase 3 will remove this method entirely once all
        call sites pass an explicit competition_id."""
        self._make_user(backend, "u1")
        self._make_team(backend, "t-default", captain="u1", name="Default")
        self._make_team(backend, "t-spring", captain="u1", name="Spring")
        backend.put_membership(
            TeamMembershipState(
                user_id="u1", team_id="t-default", joined_at=_iso(0)
            )
        )
        backend.put_membership(
            TeamMembershipState(
                user_id="u1",
                team_id="t-spring",
                joined_at=_iso(60),
                competition_id="spring-ctf-2026",
            )
        )
        legacy = backend.get_membership("u1")
        assert legacy is not None
        assert legacy.team_id == "t-default"
        assert legacy.competition_id == ""

    def test_membership_audit_fields_round_trip(self, backend):
        """``joined_via`` + ``invited_by_user_id`` survive the storage
        layer so post-mortem queries can answer "how did Bob end up on
        Alice's team?"."""
        self._make_user(backend, "u1")
        self._make_user(backend, "u2", email="b@x")
        self._make_team(backend, "t1", captain="u1")
        backend.put_membership(
            TeamMembershipState(
                user_id="u2",
                team_id="t1",
                joined_at=_iso(0),
                joined_via="redeem",
                invited_by_user_id="u1",
            )
        )
        m = backend.get_membership("u2")
        assert m is not None
        assert m.joined_via == "redeem"
        assert m.invited_by_user_id == "u1"
        # And ``list_memberships`` carries the same shape.
        rows = backend.list_memberships(team_id="t1")
        assert len(rows) == 1
        assert rows[0].joined_via == "redeem"
        assert rows[0].invited_by_user_id == "u1"


# ---------------------------------------------------------------------------
# TeamInvite — mint / list / revoke / atomic consume
# ---------------------------------------------------------------------------


class TestTeamInvite:
    def _make_user_and_team(self, backend):
        u = UserState(
            user_id="u1", email="u@x", display_name="U", created_at=_iso(0)
        )
        t = TeamState(team_id="t1", name="T", captain_user_id="u1", created_at=_iso(0))
        backend.put_user("u1", u)
        backend.put_team("t1", t)

    def test_mint_and_lookup_by_code(self, backend):
        self._make_user_and_team(backend)
        inv = TeamInviteState(
            invite_id="i1",
            team_id="t1",
            code="abc12345",
            created_by_user_id="u1",
            created_at=_iso(0),
            max_uses=1,
        )
        backend.put_team_invite(inv)
        got = backend.get_team_invite_by_code("abc12345")
        assert got is not None
        assert got.invite_id == "i1"
        assert got.team_id == "t1"

    def test_get_invite_by_unknown_code_returns_none(self, backend):
        assert backend.get_team_invite_by_code("nope") is None

    def test_list_invites_by_team(self, backend):
        self._make_user_and_team(backend)
        for i in range(3):
            backend.put_team_invite(
                TeamInviteState(
                    invite_id=f"i{i}",
                    team_id="t1",
                    code=f"code{i:04d}",
                    created_by_user_id="u1",
                    created_at=_iso(i),
                )
            )
        rows = backend.list_team_invites(team_id="t1")
        assert len(rows) == 3

    def test_revoke_invite_marks_revoked_at(self, backend):
        self._make_user_and_team(backend)
        backend.put_team_invite(
            TeamInviteState(
                invite_id="i1",
                team_id="t1",
                code="abc12345",
                created_by_user_id="u1",
                created_at=_iso(0),
            )
        )
        ts = _iso(60)
        assert backend.revoke_team_invite("i1", ts) is True
        got = backend.get_team_invite_by_code("abc12345")
        assert got is not None
        assert got.revoked_at == ts
        # Idempotent on already-revoked: returns False (no row updated).
        assert backend.revoke_team_invite("i1", _iso(120)) is False

    def test_consume_invite_atomic_increments_use_count(self, backend):
        """Atomically consume an invite — single-shot by default.

        Returns the row on success (use_count incremented), None when
        the invite is unknown, expired, revoked, or exhausted.
        """
        self._make_user_and_team(backend)
        backend.put_team_invite(
            TeamInviteState(
                invite_id="i1",
                team_id="t1",
                code="abc12345",
                created_by_user_id="u1",
                created_at=_iso(0),
                max_uses=1,
            )
        )
        first = backend.consume_team_invite_atomic("abc12345", _iso(60))
        assert first is not None
        assert first.team_id == "t1"
        assert first.use_count == 1
        # Second consume hits max_uses.
        second = backend.consume_team_invite_atomic("abc12345", _iso(120))
        assert second is None

    def test_consume_invite_atomic_unlimited_max_uses(self, backend):
        """``max_uses == 0`` means unlimited."""
        self._make_user_and_team(backend)
        backend.put_team_invite(
            TeamInviteState(
                invite_id="i1",
                team_id="t1",
                code="abc12345",
                created_by_user_id="u1",
                created_at=_iso(0),
                max_uses=0,
            )
        )
        for _ in range(5):
            assert backend.consume_team_invite_atomic("abc12345", _iso(0)) is not None

    def test_consume_invite_atomic_rejects_revoked(self, backend):
        self._make_user_and_team(backend)
        backend.put_team_invite(
            TeamInviteState(
                invite_id="i1",
                team_id="t1",
                code="abc12345",
                created_by_user_id="u1",
                created_at=_iso(0),
                revoked_at=_iso(0),
            )
        )
        assert backend.consume_team_invite_atomic("abc12345", _iso(60)) is None

    def test_consume_invite_atomic_rejects_expired(self, backend):
        self._make_user_and_team(backend)
        backend.put_team_invite(
            TeamInviteState(
                invite_id="i1",
                team_id="t1",
                code="abc12345",
                created_by_user_id="u1",
                created_at=_iso(-3600),
                expires_at=_iso(-60),
            )
        )
        assert backend.consume_team_invite_atomic("abc12345", _iso(0)) is None

    def test_consume_invite_atomic_rejects_unknown(self, backend):
        assert backend.consume_team_invite_atomic("missing", _iso(0)) is None
