"""TDD: captain → user direct invitation by exact email.

The captain can target a specific user by their exact email; the
target sees the pending invite in their inbox (Branch #6) and
accepts or declines. This pins the three new endpoints:

* ``POST /competitions/{id}/invites/direct`` body ``{email}``
* ``POST /competitions/{id}/invites/{invite_id}/accept``
* ``POST /competitions/{id}/invites/{invite_id}/decline``
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import CompetitionState
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team


@pytest.fixture
def world():
    """Captain ``cap`` (member of team ``Pwners`` in comp ``spring``),
    invitable user ``alice``, bystander ``bob``.
    """
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    backend.put_competition(
        CompetitionState(
            competition_id="spring",
            title="Spring CTF 2026",
            starts_at="",
            ends_at="2099-01-01T00:00:00Z",
            challenge_ids=[],
            created_at="2026-01-01T00:00:00Z",
        )
    )
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)

    cap = mint_team(backend, name="Cap", email="cap@x", display_name="Cap")
    backend.create_team_for_competition(
        user_id=cap.user_id,
        competition_id="spring",
        team_name="Pwners",
        description="",
        now_iso="2026-01-01T00:00:00Z",
        joined_via="create",
    )
    alice = mint_team(
        backend, name="Alice", email="alice@x", display_name="Alice"
    )
    bob = mint_team(backend, name="Bob", email="bob@x", display_name="Bob")
    return {
        "client": TestClient(app),
        "backend": backend,
        "cap": cap,
        "alice": alice,
        "bob": bob,
    }


# ---- mint direct invite ---------------------------------------------------


class TestMintDirectInvite:
    def test_captain_can_mint_invite_for_known_email(self, world):
        r = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": "alice@x"},
            headers=world["cap"].headers,
        )
        assert r.status_code == 201, r.text
        body = r.json()
        assert body["kind"] == "direct"
        assert body["target_user_id"] == world["alice"].user_id
        # The captain UI reuses the same row shape as code-style
        # invites, so a code is still generated server-side.
        assert body["code"]
        inv = world["backend"].get_team_invite(body["invite_id"])
        assert inv is not None
        assert inv.kind == "direct"
        assert inv.target_user_id == world["alice"].user_id

    def test_unknown_email_returns_404_with_typed_error(self, world):
        r = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": "ghost@nowhere"},
            headers=world["cap"].headers,
        )
        assert r.status_code == 404
        assert r.json()["detail"]["error"] == "user_not_found"

    def test_email_lookup_is_case_insensitive(self, world):
        r = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": "ALICE@X"},
            headers=world["cap"].headers,
        )
        assert r.status_code == 201, r.text
        assert r.json()["target_user_id"] == world["alice"].user_id

    def test_inviting_self_returns_400(self, world):
        r = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": "cap@x"},
            headers=world["cap"].headers,
        )
        assert r.status_code == 400
        assert r.json()["detail"]["error"] == "cannot_invite_self"

    def test_inviting_existing_member_returns_409(self, world):
        # Put alice on a competing team for the same comp.
        world["backend"].create_team_for_competition(
            user_id=world["alice"].user_id,
            competition_id="spring",
            team_name="Solo",
            description="",
            now_iso="2026-01-01T00:00:00Z",
            joined_via="solo",
        )
        r = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": "alice@x"},
            headers=world["cap"].headers,
        )
        assert r.status_code == 409
        assert r.json()["detail"]["error"] == "already_on_team"

    def test_duplicate_pending_invite_returns_409(self, world):
        first = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": "alice@x"},
            headers=world["cap"].headers,
        )
        assert first.status_code == 201
        second = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": "alice@x"},
            headers=world["cap"].headers,
        )
        assert second.status_code == 409
        assert second.json()["detail"]["error"] == "invite_already_pending"

    def test_non_captain_cannot_mint(self, world):
        # Bob is on no team for this comp at all → 403 from the
        # team-resolver dep before we even reach the captain check.
        r = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": "alice@x"},
            headers=world["bob"].headers,
        )
        assert r.status_code == 403


# ---- accept ---------------------------------------------------------------


class TestAcceptDirectInvite:
    def _mint(self, world, *, email: str = "alice@x") -> str:
        r = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": email},
            headers=world["cap"].headers,
        )
        assert r.status_code == 201, r.text
        return r.json()["invite_id"]

    def test_target_user_accepts_and_joins_team(self, world):
        invite_id = self._mint(world)
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/accept",
            headers=world["alice"].headers,
        )
        assert r.status_code == 200, r.text
        # Membership now exists, joined_via="direct_invite_accepted".
        m = world["backend"].get_membership_for_competition(
            world["alice"].user_id, "spring"
        )
        assert m is not None
        assert m.team_id == r.json()["team_id"]
        assert m.joined_via == "direct_invite_accepted"
        # Invited_by stamped to the captain (audit).
        assert m.invited_by_user_id == world["cap"].user_id

    def test_wrong_user_cannot_accept(self, world):
        invite_id = self._mint(world)
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/accept",
            headers=world["bob"].headers,
        )
        assert r.status_code == 403
        assert r.json()["detail"]["error"] == "not_invited"

    def test_unknown_invite_returns_404(self, world):
        r = world["client"].post(
            "/api/v1/competitions/spring/invites/never-existed/accept",
            headers=world["alice"].headers,
        )
        assert r.status_code == 404

    def test_accepting_revoked_invite_returns_409(self, world):
        invite_id = self._mint(world)
        # Captain revokes before alice can accept.
        world["client"].delete(
            f"/api/v1/competitions/spring/invites/{invite_id}",
            headers=world["cap"].headers,
        )
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/accept",
            headers=world["alice"].headers,
        )
        assert r.status_code == 409
        assert r.json()["detail"]["error"] == "expired_or_revoked"

    def test_accept_when_already_on_other_team_returns_409(self, world):
        invite_id = self._mint(world)
        world["backend"].create_team_for_competition(
            user_id=world["alice"].user_id,
            competition_id="spring",
            team_name="Other",
            description="",
            now_iso="2026-01-01T00:00:00Z",
            joined_via="solo",
        )
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/accept",
            headers=world["alice"].headers,
        )
        assert r.status_code == 409
        assert r.json()["detail"]["error"] == "already_member"

    def test_code_invite_cannot_be_accepted_via_direct_path(self, world):
        # Mint a code-style invite; the direct accept route must
        # reject it (kind mismatch) so a code can't be used to
        # bypass the per-recipient guard.
        mint = world["client"].post(
            "/api/v1/competitions/spring/invites",
            json={"max_uses": 1, "ttl_seconds": 3600},
            headers=world["cap"].headers,
        )
        assert mint.status_code == 201
        invite_id = mint.json()["invite_id"]
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/accept",
            headers=world["alice"].headers,
        )
        assert r.status_code == 409
        assert r.json()["detail"]["error"] == "wrong_invite_kind"


# ---- decline --------------------------------------------------------------


class TestDeclineDirectInvite:
    def _mint(self, world) -> str:
        r = world["client"].post(
            "/api/v1/competitions/spring/invites/direct",
            json={"email": "alice@x"},
            headers=world["cap"].headers,
        )
        return r.json()["invite_id"]

    def test_target_user_declines_marks_revoked(self, world):
        invite_id = self._mint(world)
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/decline",
            headers=world["alice"].headers,
        )
        assert r.status_code == 200
        inv = world["backend"].get_team_invite(invite_id)
        assert inv is not None
        assert inv.revoked_at, "decline must mark the invite revoked"

    def test_wrong_user_cannot_decline(self, world):
        invite_id = self._mint(world)
        r = world["client"].post(
            f"/api/v1/competitions/spring/invites/{invite_id}/decline",
            headers=world["bob"].headers,
        )
        assert r.status_code == 403
