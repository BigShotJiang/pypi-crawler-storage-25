"""`ctfy instance show / ls / start` rendering of per-instance public_vars.

The vars mechanism mints random tokens per instance and exposes the
public subset on ``InstanceInfo.public_vars``. The CLI is the agent's
primary surface; these tests pin that the public vars actually reach
the operator's terminal (and that private vars are never displayed,
since the platform never returns them on this field in the first
place).
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from ctfy.cli.instance import instance_app
from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType
from ctfy.server.models import InstanceInfo


def _info(
    *,
    instance_id: str = "i1",
    challenge_id: str = "WEB-001",
    description: str = "",
    public_vars: dict[str, str] | None = None,
) -> InstanceInfo:
    return InstanceInfo(
        instance_id=instance_id,
        challenge_id=challenge_id,
        team_id="t1",
        node_id="n1",
        name=challenge_id,
        category="web",
        difficulty="easy",
        status="ready",
        started_at=0.0,
        ttl=0,
        expires_at=0.0,
        services=[
            ServiceEndpoint(service_type=ServiceType.HTTP, host="127.0.0.1", port=8080),
        ],
        description=description,
        public_vars=public_vars or {},
    )


def _patch_client(client: MagicMock):
    """Patch ``get_client`` so the CLI uses our stub. Returns the patcher."""
    return patch("ctfy.cli.instance.get_client", return_value=client)


def test_instance_show_renders_public_vars():
    client = MagicMock()
    client.list_instances.return_value = [
        _info(
            description="Login as alice123 on the dashboard.",
            public_vars={"admin_user": "alice123", "api_path": "k7q3p2n4"},
        )
    ]
    with _patch_client(client):
        runner = CliRunner()
        result = runner.invoke(instance_app, ["show", "WEB-001"])

    assert result.exit_code == 0, result.output
    assert "Login as alice123" in result.output
    # Both var keys + values are rendered, in the order they appear in
    # the dict (Python preserves insertion order).
    assert "admin_user" in result.output
    assert "alice123" in result.output
    assert "api_path" in result.output
    assert "k7q3p2n4" in result.output


def test_instance_show_no_public_vars_skips_section():
    client = MagicMock()
    client.list_instances.return_value = [_info(description="", public_vars={})]
    with _patch_client(client):
        result = CliRunner().invoke(instance_app, ["show", "WEB-001"])

    assert result.exit_code == 0, result.output
    assert "public vars" not in result.output
    assert "description" not in result.output


def test_instance_ls_shows_var_count_column():
    client = MagicMock()
    client.list_instances.return_value = [
        _info(
            instance_id="i_with",
            challenge_id="WEB-001",
            public_vars={"admin_user": "x", "api_path": "y"},
        ),
        _info(
            instance_id="i_without",
            challenge_id="WEB-002",
            public_vars={},
        ),
    ]
    with _patch_client(client):
        result = CliRunner().invoke(instance_app, ["ls"])

    assert result.exit_code == 0, result.output
    # Var-count column reflects len(public_vars) — 2 for the first row,
    # blank for the second.
    assert "i_with" in result.output
    assert "i_without" in result.output
    assert " 2 " in result.output  # count column for i_with


def test_instance_show_resolves_by_instance_id_too():
    """Either challenge_id or instance_id resolves the same row —
    the CLI's previous habit for ``instance stop``."""
    client = MagicMock()
    client.list_instances.return_value = [
        _info(instance_id="abc-123", public_vars={"k": "v"}),
    ]
    with _patch_client(client):
        result = CliRunner().invoke(instance_app, ["show", "abc-123"])

    assert result.exit_code == 0, result.output
    assert "abc-123" in result.output
    assert "v" in result.output


def test_instance_start_appends_public_vars_after_ready():
    """After a successful start, the CLI should round-trip via
    list_instances and render description + public_vars under the
    service list — so an operator running ``ctfy instance start <id>``
    sees their dynamic tokens immediately, not after a separate
    ``instance show``."""
    client = MagicMock()
    client.start_instance.return_value = MagicMock(
        surface=AttackSurface(
            services=[ServiceEndpoint(service_type=ServiceType.HTTP, host="h", port=80)],
        ),
        cert_volume="",
    )
    client.list_instances.return_value = [
        _info(
            description="Hi alice123",
            public_vars={"admin_user": "alice123"},
        )
    ]
    with _patch_client(client):
        result = CliRunner().invoke(instance_app, ["start", "WEB-001"])

    assert result.exit_code == 0, result.output
    assert "Ready!" in result.output
    assert "Hi alice123" in result.output
    assert "admin_user" in result.output
