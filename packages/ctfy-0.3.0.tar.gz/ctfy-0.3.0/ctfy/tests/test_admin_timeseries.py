"""Tests for ``GET /admin/timeseries`` — bucketed counts that drive the
admin Overview's 24h pulse charts (launches/hr, submissions/hr,
solves/hr, concurrent running instances)."""

from __future__ import annotations

import time
from datetime import datetime, timezone
from unittest.mock import patch

from fastapi.testclient import TestClient

from ctfy.core.enums import InstanceStatus
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import (
    InstanceRecord,
    InstanceState,
    SolveState,
    SubmissionState,
    TeamState,
)
from ctfy.tests.conftest import mint_team


def _bootstrap(env_manager, *, clock=None):
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    if clock is not None:
        # AppState is exposed on ``app.state.ctfy`` (see create_platform_app).
        # Pin the clock so bucket placement is deterministic regardless of
        # when CI happens to run.
        app.state.ctfy.clock = clock
    admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)
    return app, backend, admin


# A clock instant fixed mid-hour so any sub-bucket arithmetic is unambiguous.
# 2026-04-27 12:30:00 UTC.
_FIXED_NOW = 1777681800.0


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


def test_timeseries_requires_admin(mock_env_manager):
    app, _, _ = _bootstrap(mock_env_manager)
    c = TestClient(app)
    r = c.get("/api/v1/admin/timeseries", params={"metric": "launches"})
    assert r.status_code in (401, 403)


def test_timeseries_403_for_non_admin(mock_env_manager):
    app, backend, _ = _bootstrap(mock_env_manager)
    user = mint_team(backend, name="u", email="u@example.test", is_admin=False)
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "launches"},
        headers=user.headers,
    )
    assert r.status_code == 403


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def test_timeseries_rejects_unknown_metric(mock_env_manager):
    app, _, admin = _bootstrap(mock_env_manager)
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "nope"},
        headers=admin.headers,
    )
    # FastAPI's Literal validation surfaces as 422.
    assert r.status_code == 422


def test_timeseries_default_window_24h_bucket_1h(mock_env_manager):
    app, _, admin = _bootstrap(mock_env_manager)
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "launches"},
        headers=admin.headers,
    )
    assert r.status_code == 200
    body = r.json()
    assert "buckets" in body
    # 24 hourly buckets covering the past 24h.
    assert len(body["buckets"]) == 24


# ---------------------------------------------------------------------------
# launches metric — counts InstanceRecord by requested_at
# ---------------------------------------------------------------------------


def test_launches_buckets_count_by_requested_at(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)

    now = _FIXED_NOW
    # Three records: 30 min ago (current bucket), 90 min ago, 150 min ago.
    for offset_min, iid in [(30, "i30"), (90, "i90"), (150, "i150")]:
        backend.archive_instance(
            InstanceRecord(
                instance_id=iid,
                challenge_id="E1",
                team_id="t1",
                node_id="n1",
                status=InstanceStatus.STOPPED,
                requested_at=now - offset_min * 60,
                ready_at=now - offset_min * 60 + 1.0,
                stopped_at=now - offset_min * 60 + 60,
                started_at=now - offset_min * 60 + 1.0,
            )
        )

    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "launches", "window": 14400, "bucket": 3600},
        headers=admin.headers,
    )
    body = r.json()
    # 4 hourly buckets covering 4h. All three records fall within.
    assert len(body["buckets"]) == 4
    total = sum(b["value"] for b in body["buckets"])
    assert total == 3
    # The most recent bucket (right-edge) holds the 30-min-ago record.
    assert body["buckets"][-1]["value"] >= 1


# ---------------------------------------------------------------------------
# submissions / solves — counts SubmissionState / SolveState by ISO ts
# ---------------------------------------------------------------------------


def test_submissions_metric_counts_submitted_at(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)

    now = _FIXED_NOW
    # Two submissions inside window, one outside (3h ago for a 1h window).
    backend.add_submission(
        SubmissionState(
            submission_id="s1",
            team_id="t1",
            challenge_id="E1",
            claimed_flag="x",
            submitted_at=_iso(now - 600),  # 10 min ago — inside
        )
    )
    backend.add_submission(
        SubmissionState(
            submission_id="s2",
            team_id="t1",
            challenge_id="E1",
            claimed_flag="y",
            submitted_at=_iso(now - 30),  # 30s ago — inside
        )
    )
    backend.add_submission(
        SubmissionState(
            submission_id="s3",
            team_id="t1",
            challenge_id="E1",
            claimed_flag="z",
            submitted_at=_iso(now - 3 * 3600),  # 3h ago — outside
        )
    )
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "submissions", "window": 3600, "bucket": 3600},
        headers=admin.headers,
    )
    body = r.json()
    assert len(body["buckets"]) == 1
    assert body["buckets"][0]["value"] == 2


def test_solves_metric_counts_solved_at(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)
    now = _FIXED_NOW
    backend.add_solve(
        "t1",
        "E1",
        "main",
        SolveState(
            team_id="t1",
            challenge_id="E1",
            flag_id="main",
            solved_at=_iso(now - 60),
        ),
    )
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "solves", "window": 3600, "bucket": 3600},
        headers=admin.headers,
    )
    assert sum(b["value"] for b in r.json()["buckets"]) == 1


# ---------------------------------------------------------------------------
# running_instances — concurrent count at each bucket boundary
# ---------------------------------------------------------------------------


def test_running_instances_counts_records_spanning_bucket_end(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)
    now = _FIXED_NOW
    # Record A: ran from 3h ago to 1h ago — covers buckets at -2h.
    backend.archive_instance(
        InstanceRecord(
            instance_id="A",
            challenge_id="E1",
            team_id="t1",
            node_id="n1",
            status=InstanceStatus.STOPPED,
            requested_at=now - 3 * 3600,
            ready_at=now - 3 * 3600 + 1.0,
            stopped_at=now - 1 * 3600,
            started_at=now - 3 * 3600 + 1.0,
        )
    )
    # Record B: ran from 30 min ago and is still going (live).
    backend.put_instance(
        "B",
        InstanceState(
            instance_id="B",
            challenge_id="E1",
            team_id="t2",
            node_id="n1",
            status=InstanceStatus.READY,
            requested_at=now - 30 * 60,
            ready_at=now - 30 * 60 + 1.0,
        ),
    )

    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "running_instances", "window": 4 * 3600, "bucket": 3600},
        headers=admin.headers,
    )
    buckets = r.json()["buckets"]
    assert len(buckets) == 4
    # Buckets oldest-first. Right edge timestamps:
    # bucket 0 → now - 3h, bucket 1 → now - 2h, bucket 2 → now - 1h,
    # bucket 3 → now (current). Record A spans -3h to -1h; record B
    # exists from -30min onward.
    # bucket 0 right-edge = -3h: A just started (requested_at = -3h),
    # so A is "active" exactly at that boundary; expect ≥ 1.
    # bucket 1 right-edge = -2h: A still running.
    # bucket 2 right-edge = -1h: A stopping at this exact boundary.
    # bucket 3 right-edge = now: B active, A stopped → 1.
    assert buckets[1]["value"] >= 1
    assert buckets[3]["value"] >= 1


# ---------------------------------------------------------------------------
# Bucket-edge semantics — these are the regressions that were timing-flaky
# under the old "snap to next bucket boundary" implementation. With a
# pinned clock the placement is deterministic on every CI run.
# ---------------------------------------------------------------------------


def test_right_edge_equals_now_no_snap(mock_env_manager):
    """The rightmost bucket's ``ts`` is exactly the wall-clock instant of
    the request, not a future-aligned boundary."""
    app, _, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "launches", "window": 14400, "bucket": 3600},
        headers=admin.headers,
    )
    body = r.json()
    assert body["buckets"][-1]["ts"] == _FIXED_NOW


def test_rightmost_bucket_marked_partial(mock_env_manager):
    """The rightmost bucket is "in progress" — only it carries
    ``partial=True``; older buckets are sealed."""
    app, _, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "launches", "window": 14400, "bucket": 3600},
        headers=admin.headers,
    )
    buckets = r.json()["buckets"]
    assert buckets[-1]["partial"] is True
    for b in buckets[:-1]:
        assert b["partial"] is False


# ---------------------------------------------------------------------------
# teams metric — cumulative count by created_at
# ---------------------------------------------------------------------------


def test_teams_metric_is_cumulative(mock_env_manager):
    """Teams metric is a stock — each bucket reports total registered
    up to its right edge, so the line never decreases."""
    app, backend, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)
    now = _FIXED_NOW

    # Three teams registered at increasingly recent timestamps. The
    # admin minted by `_bootstrap` itself contributes to the count.
    for offset_min, tid in [(180, "old"), (120, "mid"), (30, "new")]:
        backend.put_team(
            tid,
            TeamState(team_id=tid, name=tid, created_at=_iso(now - offset_min * 60)),
        )

    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "teams", "window": 4 * 3600, "bucket": 3600},
        headers=admin.headers,
    )
    assert r.status_code == 200
    buckets = r.json()["buckets"]
    assert len(buckets) == 4
    values = [b["value"] for b in buckets]
    # Monotonically non-decreasing.
    assert values == sorted(values)
    # By the rightmost bucket every test team is in.
    assert values[-1] >= 3


def test_teams_metric_legacy_rows_count_throughout(mock_env_manager):
    """Teams without a parseable ``created_at`` still appear in the
    cluster total, so they contribute to every bucket — otherwise the
    sparkline would start lower than the live count and visually imply
    that legacy teams "appeared" mid-window."""
    app, backend, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)
    backend.put_team("legacy", TeamState(team_id="legacy", name="legacy"))
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "teams", "window": 7200, "bucket": 3600},
        headers=admin.headers,
    )
    buckets = r.json()["buckets"]
    # Legacy team plus the bootstrap admin both lack created_at, so the
    # leftmost bucket already includes them.
    assert buckets[0]["value"] >= 1


def test_record_at_30_min_ago_lands_in_rightmost_bucket(mock_env_manager):
    """With ``right_edge == now`` the most recent bucket spans
    ``(now - bucket, now]``. A record from 30 min ago must always land in
    it — regardless of where ``now`` falls relative to the clock hour."""
    app, backend, admin = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)
    backend.archive_instance(
        InstanceRecord(
            instance_id="i30",
            challenge_id="E1",
            team_id="t1",
            node_id="n1",
            status=InstanceStatus.STOPPED,
            requested_at=_FIXED_NOW - 30 * 60,
            ready_at=_FIXED_NOW - 30 * 60 + 1.0,
            stopped_at=_FIXED_NOW - 30 * 60 + 60,
            started_at=_FIXED_NOW - 30 * 60 + 1.0,
        )
    )
    c = TestClient(app)
    r = c.get(
        "/api/v1/admin/timeseries",
        params={"metric": "launches", "window": 14400, "bucket": 3600},
        headers=admin.headers,
    )
    body = r.json()
    assert body["buckets"][-1]["value"] == 1
