"""Regression tests for ``SSEHub`` isolation between clients.

The original implementation queued the same mutable dict reference to
every subscriber and relied on the route handler to ``pop()`` the event
name off before serialising. The first consumer stole the ``event``
key; everyone else received an unnamed SSE frame, so
``addEventListener("instance_ready", …)`` never fired in the browser.

These tests pin the contract: the hub produces fully-formatted wire
frames so the payload is immutable from the producer side, and every
connected client gets exactly the same bytes regardless of read order.
"""

from __future__ import annotations

import asyncio
import json

import pytest

from ctfy.server.sse import SSEHub


def _run(coro):
    """Pytest-asyncio isn't wired up in this project's test deps, so
    drive async tests through a one-shot asyncio.run."""
    return asyncio.run(coro)


def test_two_clients_both_receive_named_event():
    async def go():
        hub = SSEHub()
        hub.set_loop(asyncio.get_running_loop())

        _c1, q1 = hub.connect()
        _c2, q2 = hub.connect()

        hub.broadcast(
            "instance_ready",
            team_id="",
            data={"challenge_id": "WEB-001", "instance_id": "abc"},
        )

        f1 = await asyncio.wait_for(q1.get(), timeout=1)
        f2 = await asyncio.wait_for(q2.get(), timeout=1)

        # Both clients see an identical, fully-formed SSE frame.
        assert f1 == f2
        assert f1.startswith("event: instance_ready\n")
        assert "data:" in f1
        assert f1.endswith("\n\n")

        # The data line parses back to the original payload.
        data_line = [ln for ln in f1.splitlines() if ln.startswith("data:")][0]
        payload = json.loads(data_line[len("data: ") :])
        assert payload == {"challenge_id": "WEB-001", "instance_id": "abc"}

    _run(go())


def test_team_filter_skips_mismatched_clients():
    async def go():
        hub = SSEHub()
        hub.set_loop(asyncio.get_running_loop())

        _, team_a_q = hub.connect(team_ids=frozenset({"team-a"}))
        _, team_b_q = hub.connect(team_ids=frozenset({"team-b"}))

        hub.broadcast("instance_ready", team_id="team-a", data={"x": 1})

        a_frame = await asyncio.wait_for(team_a_q.get(), timeout=1)
        assert "instance_ready" in a_frame

        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(team_b_q.get(), timeout=0.2)

    _run(go())


def test_global_event_reaches_every_client():
    async def go():
        hub = SSEHub()
        hub.set_loop(asyncio.get_running_loop())

        _, anon_q = hub.connect()
        _, team_q = hub.connect(team_ids=frozenset({"team-a"}))

        hub.broadcast("node_registered", team_id="", data={"node_id": "n1"})

        anon_frame = await asyncio.wait_for(anon_q.get(), timeout=1)
        team_frame = await asyncio.wait_for(team_q.get(), timeout=1)
        assert anon_frame == team_frame
        assert "event: node_registered" in anon_frame

    _run(go())


def test_admin_only_event_skips_non_admin_clients():
    """``admin_only=True`` is the gate for cluster-wide signals (node
    health, platform-wide running-instance counts) that members aren't
    allowed to see. Non-admin clients should be filtered out even if
    they would otherwise pass the team filter."""

    async def go():
        hub = SSEHub()
        hub.set_loop(asyncio.get_running_loop())

        _, member_q = hub.connect(team_ids=frozenset({"team-a"}), is_admin=False)
        _, admin_q = hub.connect(team_ids=frozenset({"team-b"}), is_admin=True)

        hub.broadcast(
            "node_status",
            team_id="",
            data={"node_id": "n1", "healthy": False},
            admin_only=True,
        )

        admin_frame = await asyncio.wait_for(admin_q.get(), timeout=1)
        assert "event: node_status" in admin_frame

        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(member_q.get(), timeout=0.2)

    _run(go())


def test_admin_only_default_false_preserves_existing_behavior():
    """``admin_only`` defaults to False so every existing emit
    (instance_ready, scoreboard updates, etc.) keeps reaching members
    without each call site having to opt in."""

    async def go():
        hub = SSEHub()
        hub.set_loop(asyncio.get_running_loop())

        _, member_q = hub.connect(team_ids=frozenset({"team-a"}), is_admin=False)
        _, admin_q = hub.connect(team_ids=frozenset({"team-a"}), is_admin=True)

        hub.broadcast("instance_ready", team_id="team-a", data={"x": 1})

        member_frame = await asyncio.wait_for(member_q.get(), timeout=1)
        admin_frame = await asyncio.wait_for(admin_q.get(), timeout=1)
        assert member_frame == admin_frame

    _run(go())


def test_admin_only_still_respects_team_filter():
    """Combining ``admin_only=True`` with a team filter is an AND, not
    an OR — a team-scoped admin event shouldn't bleed into a different
    team's admin (e.g. per-team admin notifications, if we ever add
    them). Today's emits are global, but the contract should still
    hold so future team-scoped admin events don't leak."""

    async def go():
        hub = SSEHub()
        hub.set_loop(asyncio.get_running_loop())

        _, admin_a_q = hub.connect(team_ids=frozenset({"team-a"}), is_admin=True)
        _, admin_b_q = hub.connect(team_ids=frozenset({"team-b"}), is_admin=True)

        hub.broadcast("private_admin_signal", team_id="team-a", data={}, admin_only=True)

        a_frame = await asyncio.wait_for(admin_a_q.get(), timeout=1)
        assert "event: private_admin_signal" in a_frame
        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(admin_b_q.get(), timeout=0.2)

    _run(go())


def test_connect_default_is_member():
    """Backwards-compat: existing callers that don't pass ``is_admin``
    should be treated as non-admin so admin_only events naturally
    stop reaching them."""

    async def go():
        hub = SSEHub()
        hub.set_loop(asyncio.get_running_loop())

        _, q = hub.connect(team_ids=frozenset({"team-a"}))  # no is_admin kwarg

        hub.broadcast("node_status", team_id="", data={}, admin_only=True)

        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(q.get(), timeout=0.2)

    _run(go())


def test_consumer_cannot_corrupt_other_consumers():
    """Mutation at the consumer site can't leak. Strings are immutable
    so the guarantee is baked into the type — the test defends the
    architectural choice against a future regression that might
    reintroduce a mutable container on the queue."""

    async def go():
        hub = SSEHub()
        hub.set_loop(asyncio.get_running_loop())

        _, q1 = hub.connect()
        _, q2 = hub.connect()

        hub.broadcast("instance_ready", team_id="", data={"foo": "bar"})

        f1 = await asyncio.wait_for(q1.get(), timeout=1)
        # Even if a handler tries to "mutate" the frame it's a no-op
        # on a string; the second consumer still gets the original.
        _tampered = f1.replace("instance_ready", "GARBAGE")
        f2 = await asyncio.wait_for(q2.get(), timeout=1)
        assert "event: instance_ready\n" in f2
        assert "GARBAGE" not in f2

    _run(go())
