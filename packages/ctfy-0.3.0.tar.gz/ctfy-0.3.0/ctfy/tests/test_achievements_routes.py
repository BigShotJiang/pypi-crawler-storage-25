"""HTTP-level tests for the achievement routes.

End-to-end tests that exercise the full dispatch path: a real flag
submission triggers the event, the event runs through emit_event, the
engine unlocks the badge, and the GET routes return it.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.tests.conftest import (
    fake_node_context,
    make_mock_challenge_manager,
    mint_team,
    start_instance_and_wait,
)

# -- End-to-end fixtures -----------------------------------------------------


@pytest.fixture
def app_client():
    """Build an app + admin team for the grant tests.

    Returns ``(TestClient, backend, admin_headers)`` — admin privileges
    are carried by a team whose ``is_admin`` flag is set at mint time,
    replacing the old ``CTFY_ADMIN_TOKEN``.
    """
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    mgr = make_mock_challenge_manager(
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        auto_generate_specs=True,
    )
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="10.0.0.1", backend=backend)
    admin = mint_team(backend, name="admin", email="admin@example.test", is_admin=True)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.0.1",
    ):
        yield TestClient(app), backend, admin.headers


def _make_team(client, *, name="T") -> tuple[str, dict]:
    """Sign in via OAuth, then register a Solo team for the test
    competition so the user has a per-comp team to earn achievements
    against. Achievements are still per-team rows; this mirrors the
    real-world "sign in, hit /c/:id/teams (Solo)" flow.
    """
    from ctfy.tests.conftest import TEST_COMPETITION_ID, oauth_login

    email = f"{name.lower()}@example.test"
    token = oauth_login(client, "github", email=email, display_name=name)
    auth = {"Authorization": f"Bearer {token}"}
    backend = client.app.state.ctfy.state_backend
    # Ensure the test competition row exists so the registration route
    # finds something to bind the membership to.
    if backend.get_competition(TEST_COMPETITION_ID) is None:
        from ctfy.core.state.models import CompetitionState

        backend.put_competition(
            CompetitionState(
                competition_id=TEST_COMPETITION_ID,
                title="Test Competition",
                created_at="2026-01-01T00:00:00Z",
            )
        )
    r = client.post(
        f"/api/v1/competitions/{TEST_COMPETITION_ID}/teams",
        json={"mode": "solo"},
        headers=auth,
    )
    assert r.status_code in (200, 201), r.text
    team_id = r.json()["team_id"]
    return team_id, auth


# -- Catalog -----------------------------------------------------------------


class TestCatalog:
    def test_catalog_hides_secrets_for_anonymous(self, app_client):
        client, _, admin_hdr = app_client
        r = client.get("/api/v1/achievements/catalog")
        assert r.status_code == 200
        ids = {a["id"] for a in r.json()["items"]}
        assert "welcome_aboard" in ids
        assert "secret_handshake" not in ids  # hidden until earned

    def test_catalog_hides_secrets_for_team_without_unlock(self, app_client):
        client, _, admin_hdr = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/achievements/catalog", headers=auth)
        ids = {a["id"] for a in r.json()["items"]}
        assert "secret_handshake" not in ids

    def test_catalog_reveals_earned_secret(self, app_client):
        client, backend, admin_hdr = app_client
        tid, auth = _make_team(client)
        backend.grant_achievement(tid, "secret_handshake", {})
        r = client.get("/api/v1/achievements/catalog", headers=auth)
        ids = {a["id"] for a in r.json()["items"]}
        assert "secret_handshake" in ids


# -- Self view: /me/achievements --------------------------------------------


class TestMyAchievements:
    def test_welcome_aboard_after_registration(self, app_client):
        client, _, admin_hdr = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/me/achievements", headers=auth)
        assert r.status_code == 200
        unlocked = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "welcome_aboard" in unlocked

    def test_requires_auth(self, app_client):
        client, _, admin_hdr = app_client
        r = client.get("/api/v1/me/achievements")
        assert r.status_code in (401, 403)

    def test_locked_list_excludes_secret(self, app_client):
        client, _, admin_hdr = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/me/achievements", headers=auth)
        locked_ids = {a["id"] for a in r.json()["locked"]}
        assert "secret_handshake" not in locked_ids
        assert "night_owl" in locked_ids  # regular locked badges still show

    def test_locked_entries_carry_progress_when_quantifiable(self, app_client):
        """Decathlete is the canonical "X / 10" badge — locked entry
        should carry a (current, target) progress object so the UI can
        render a bar instead of just a greyed-out icon."""
        from ctfy.core.state.models import SolveState

        client, backend, _ = app_client
        team_id, auth = _make_team(client)
        # Seed 3 solves directly into the backend — no need to drive the
        # full submission flow for a route assertion.
        for i in range(3):
            backend.add_solve(
                team_id,
                f"CHAL-{i:03d}",
                "main",
                SolveState(solved_at="2026-04-25T12:00:00Z"),
            )
        r = client.get("/api/v1/me/achievements", headers=auth)
        locked = {a["id"]: a for a in r.json()["locked"]}
        assert "decathlete" in locked
        assert locked["decathlete"]["progress"] == {"current": 3, "target": 10}

    def test_locked_entries_omit_progress_when_provider_returns_none(self, app_client):
        """Time-of-day badges (night_owl etc.) intentionally have no
        progress provider — the locked entry must serialise progress
        as null (not absent) so the frontend can branch cleanly."""
        client, _, _ = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/me/achievements", headers=auth)
        locked = {a["id"]: a for a in r.json()["locked"]}
        assert locked["night_owl"]["progress"] is None

    def test_unlocked_entries_do_not_advertise_progress(self, app_client):
        """Once the badge is earned the bar would be 100% redundant; the
        unlocked block stays a clean list of TeamAchievement rows."""
        client, _, _ = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/me/achievements", headers=auth)
        # welcome_aboard unlocks via TEAM_REGISTERED — every test team
        # gets it.
        for entry in r.json()["unlocked"]:
            assert "progress" not in entry


# -- Public team view --------------------------------------------------------


class TestTeamAchievements:
    def test_shows_other_teams_public_badges(self, app_client):
        client, _, admin_hdr = app_client
        tid, _ = _make_team(client, name="Target")
        r = client.get(f"/api/v1/teams/{tid}/achievements")
        assert r.status_code == 200
        ids = {a["achievement_id"] for a in r.json()["items"]}
        assert "welcome_aboard" in ids

    def test_hides_secret_badges_from_other_viewers(self, app_client):
        client, backend, admin_hdr = app_client
        tid, _ = _make_team(client)
        backend.grant_achievement(tid, "secret_handshake", {})
        r = client.get(f"/api/v1/teams/{tid}/achievements")
        ids = {a["achievement_id"] for a in r.json()["items"]}
        assert "secret_handshake" not in ids

    def test_unknown_team_returns_404(self, app_client):
        client, _, admin_hdr = app_client
        r = client.get("/api/v1/teams/does-not-exist/achievements")
        assert r.status_code == 404


# -- Admin grant + revoke ----------------------------------------------------


class TestAdminGrantRevoke:
    def test_grant_and_revoke(self, app_client):
        client, _, admin_hdr = app_client
        tid, auth = _make_team(client)
        admin = admin_hdr

        r = client.post(f"/api/v1/admin/teams/{tid}/achievements/bug_hunter", headers=admin)
        assert r.status_code == 200
        data = r.json()
        assert data["achievement_id"] == "bug_hunter"

        r = client.get("/api/v1/me/achievements", headers=auth)
        ids = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "bug_hunter" in ids

        r = client.delete(f"/api/v1/admin/teams/{tid}/achievements/bug_hunter", headers=admin)
        assert r.status_code == 204

        r = client.get("/api/v1/me/achievements", headers=auth)
        ids = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "bug_hunter" not in ids

    def test_grant_is_idempotent(self, app_client):
        client, _, admin_hdr = app_client
        tid, _ = _make_team(client)
        admin = admin_hdr
        for _ in range(3):
            r = client.post(f"/api/v1/admin/teams/{tid}/achievements/bug_hunter", headers=admin)
            assert r.status_code == 200

        r = client.get(f"/api/v1/teams/{tid}/achievements")
        bug_hunts = [a for a in r.json()["items"] if a["achievement_id"] == "bug_hunter"]
        assert len(bug_hunts) == 1

    def test_grant_requires_admin(self, app_client):
        client, _, admin_hdr = app_client
        tid, auth = _make_team(client)
        r = client.post(f"/api/v1/admin/teams/{tid}/achievements/bug_hunter", headers=auth)
        assert r.status_code in (401, 403)

    def test_unknown_achievement_404(self, app_client):
        client, _, admin_hdr = app_client
        tid, _ = _make_team(client)
        admin = admin_hdr
        r = client.post(f"/api/v1/admin/teams/{tid}/achievements/no_such_id", headers=admin)
        assert r.status_code == 404


# -- End-to-end: solve triggers achievement -----------------------------------


class TestEndToEndSolve:
    def test_solve_unlocks_first_blood_and_fastest_man(self, app_client):
        client, _, admin_hdr = app_client
        tid, auth = _make_team(client)
        instance_id = start_instance_and_wait(client, "E1", headers=auth)
        r = client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        assert r.status_code == 200
        assert r.json()["correct"] is True

        r = client.get("/api/v1/me/achievements", headers=auth)
        unlocked = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "first_blood_team" in unlocked
        assert "fastest_man" in unlocked

    def test_secret_handshake_flag_unlocks_it(self, app_client):
        client, _, admin_hdr = app_client
        tid, auth = _make_team(client)
        instance_id = start_instance_and_wait(client, "E1", headers=auth)
        r = client.post(
            "/api/v1/submissions",
            json={"instance_id": instance_id, "flag": "flag{hello_world}"},
            headers=auth,
        )
        assert r.status_code == 200
        assert r.json()["correct"] is False

        r = client.get("/api/v1/me/achievements", headers=auth)
        unlocked = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "secret_handshake" in unlocked

    def test_achievement_event_lands_in_activity_log(self, app_client):
        """Unlocks create ACHIEVEMENT_UNLOCKED activity rows (visible to the team)."""
        client, _, admin_hdr = app_client
        tid, auth = _make_team(client)
        instance_id = start_instance_and_wait(client, "E1", headers=auth)
        client.post(
            "/api/v1/submissions",
            json={
                "instance_id": instance_id,
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        r = client.get("/api/v1/activities?event=achievement_unlocked", headers=auth)
        assert r.status_code == 200
        items = r.json()["items"]
        assert items, "expected at least one achievement_unlocked event"
        # The payload carries the badge id in detail.
        badges = {item["detail"].get("achievement_id") for item in items}
        assert "first_blood_team" in badges


# -- earned_by_count + rarity + points ---------------------------------------


class TestCountsRarityPoints:
    def test_catalog_carries_points_count_and_rarity(self, app_client):
        client, _, _ = app_client
        r = client.get("/api/v1/achievements/catalog")
        assert r.status_code == 200
        entries = {e["id"]: e for e in r.json()["items"]}
        wa = entries["welcome_aboard"]
        # Bronze => 10 pts, no team has unlocked yet => unearned.
        assert wa["points"] == 10
        assert wa["earned_by_count"] == 0
        assert wa["rarity"] == "unearned"
        # Gold tier sanity check.
        assert entries["fastest_man"]["points"] == 50

    def test_unearned_until_a_team_grabs_it(self, app_client):
        client, _, _ = app_client
        # Register a single team — welcome_aboard auto-unlocks for them.
        _make_team(client)
        r = client.get("/api/v1/achievements/catalog")
        entries = {e["id"]: e for e in r.json()["items"]}
        # 1 team total, 1 unlock => 100% => "common".
        assert entries["welcome_aboard"]["earned_by_count"] == 1
        assert entries["welcome_aboard"]["rarity"] == "common"
        # Untouched badge stays "unearned" (separate bucket from "common").
        assert entries["night_owl"]["earned_by_count"] == 0
        assert entries["night_owl"]["rarity"] == "unearned"

    def test_rarity_buckets_by_percentage(self, app_client):
        """3% epic / 10% rare / 25% uncommon / 50% common — sanity check."""
        client, backend, _ = app_client
        # Register 19 teams (20 total counting the admin team the fixture
        # mints) so percentages divide cleanly.
        team_ids = []
        for i in range(19):
            tid, _ = _make_team(client, name=f"U{i}")
            team_ids.append(tid)
        assert backend.count_users() == 20
        # Grant night_owl to 1/20 (5%) => epic.
        backend.grant_achievement(team_ids[0], "night_owl")
        # Grant early_bird to 3/20 (15%) => rare.
        for tid in team_ids[:3]:
            backend.grant_achievement(tid, "early_bird")
        # Grant decathlete to 6/20 (30%) => uncommon.
        for tid in team_ids[:6]:
            backend.grant_achievement(tid, "decathlete")
        # Grant centurion to 11/20 (55%) => common.
        for tid in team_ids[:11]:
            backend.grant_achievement(tid, "centurion")
        r = client.get("/api/v1/achievements/catalog")
        entries = {e["id"]: e for e in r.json()["items"]}
        assert entries["night_owl"]["rarity"] == "epic"
        assert entries["early_bird"]["rarity"] == "rare"
        assert entries["decathlete"]["rarity"] == "uncommon"
        assert entries["centurion"]["rarity"] == "common"


# -- /me/achievements summary -------------------------------------------------


class TestMyAchievementsSummary:
    def test_summary_present_with_score_totals(self, app_client):
        client, _, _ = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/me/achievements", headers=auth)
        body = r.json()
        assert "summary" in body
        s = body["summary"]
        # welcome_aboard auto-unlocks => 1 unlocked, 10 pts.
        assert s["unlocked_count"] >= 1
        assert s["score"] >= 10
        # total_score is the sum of all non-secret tier weights — must be
        # a positive int and at least as large as the current score.
        assert s["total_score"] >= s["score"]


# -- recent-unlocks feed ------------------------------------------------------


class TestRecentUnlocks:
    def test_returns_newest_first(self, app_client):
        client, backend, _ = app_client
        # Two registered teams => two welcome_aboard unlocks.
        # OAuth alone no longer auto-creates a team — drive Solo
        # registration so each user has a per-comp team to credit.
        _make_team(client, name="A")
        _make_team(client, name="B")
        r = client.get("/api/v1/achievements/recent-unlocks?limit=20")
        assert r.status_code == 200
        body = r.json()
        items = body["items"]
        assert body["total"] >= 2
        assert len(items) >= 2
        # Newest first — unlocked_at sorts descending.
        ts = [it["unlocked_at"] for it in items]
        assert ts == sorted(ts, reverse=True)
        # Each row carries the public surface needed to render a feed.
        first = items[0]
        for key in ("team_id", "team_name", "achievement_id", "name", "icon", "tier"):
            assert key in first

    def test_filters_secret_badges(self, app_client):
        client, backend, _ = app_client
        tid, _ = _make_team(client)
        backend.grant_achievement(tid, "secret_handshake")
        r = client.get("/api/v1/achievements/recent-unlocks")
        ids = {it["achievement_id"] for it in r.json()["items"]}
        assert "secret_handshake" not in ids

    def test_skips_orphan_team_rows(self, app_client):
        client, backend, _ = app_client
        # Insert a row for a team that was deleted — recent-unlocks must
        # skip it instead of returning ``team_name=""`` or 500-ing.
        backend.grant_achievement("ghost-team", "welcome_aboard")
        r = client.get("/api/v1/achievements/recent-unlocks")
        team_ids = {it["team_id"] for it in r.json()["items"]}
        assert "ghost-team" not in team_ids

    def test_limit_clamped_to_page_max(self, app_client):
        client, _, _ = app_client
        # ``BigLimitOffsetPage`` caps limit at 10000; over-the-cap → 422.
        r = client.get("/api/v1/achievements/recent-unlocks?limit=99999")
        assert r.status_code == 422

    def test_pagination_offset_advances(self, app_client):
        client, backend, _ = app_client
        # Five teams + welcome_aboard => five rows in the feed.
        for i in range(5):
            _make_team(client, name=f"P{i}")
        first = client.get(
            "/api/v1/achievements/recent-unlocks?limit=2&offset=0"
        ).json()
        second = client.get(
            "/api/v1/achievements/recent-unlocks?limit=2&offset=2"
        ).json()
        assert first["total"] == second["total"] >= 5
        assert {it["team_id"] for it in first["items"]} & {
            it["team_id"] for it in second["items"]
        } == set()

    def test_anonymous_can_read(self, app_client):
        client, backend, _ = app_client
        _make_team(client)
        r = client.get("/api/v1/achievements/recent-unlocks")
        assert r.status_code == 200


# -- easter-egg claim ---------------------------------------------------------


class TestEasterEggClaim:
    def test_claim_grants_achievement_first_time(self, app_client):
        client, _, _ = app_client
        _, auth = _make_team(client)
        r = client.post("/api/v1/easter-eggs/base64-cowboy/claim", headers=auth)
        assert r.status_code == 200
        body = r.json()
        assert body["egg_id"] == "base64-cowboy"
        assert body["already_unlocked"] is False
        assert body["achievement"]["achievement_id"] == "base64_cowboy"
        assert body["achievement"]["tier"] == "secret"
        # Now visible in the team's unlocks.
        r = client.get("/api/v1/me/achievements", headers=auth)
        ids = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "base64_cowboy" in ids

    def test_claim_is_idempotent(self, app_client):
        client, _, _ = app_client
        _, auth = _make_team(client)
        first = client.post("/api/v1/easter-eggs/base64-cowboy/claim", headers=auth).json()
        second = client.post("/api/v1/easter-eggs/base64-cowboy/claim", headers=auth).json()
        assert first["already_unlocked"] is False
        assert second["already_unlocked"] is True
        # Same unlocked_at — second call did not overwrite.
        assert first["achievement"]["unlocked_at"] == second["achievement"]["unlocked_at"]

    def test_unknown_egg_returns_404(self, app_client):
        client, _, _ = app_client
        _, auth = _make_team(client)
        r = client.post("/api/v1/easter-eggs/nope/claim", headers=auth)
        assert r.status_code == 404

    def test_requires_auth(self, app_client):
        client, _, _ = app_client
        r = client.post("/api/v1/easter-eggs/base64-cowboy/claim")
        assert r.status_code in (401, 403)

    def test_emits_activity_log_event(self, app_client):
        client, _, _ = app_client
        _, auth = _make_team(client)
        client.post("/api/v1/easter-eggs/base64-cowboy/claim", headers=auth)
        r = client.get("/api/v1/activities?event=achievement_unlocked", headers=auth)
        badges = {item["detail"].get("achievement_id") for item in r.json()["items"]}
        assert "base64_cowboy" in badges

    def test_retired_console_cowboy_slug_404s(self, app_client):
        # The console-cowboy slug was retired in favour of base64-cowboy;
        # the route should reject the old slug rather than silently
        # 200ing into a different badge.
        client, _, _ = app_client
        _, auth = _make_team(client)
        r = client.post("/api/v1/easter-eggs/console-cowboy/claim", headers=auth)
        assert r.status_code == 404


# -- linked_<provider> auto-grant on OAuth callback ---------------------------


class TestLinkedProviderGrants:
    def test_github_signin_unlocks_linked_github(self, app_client):
        client, _, _ = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/me/achievements", headers=auth)
        ids = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "linked_github" in ids
        assert "linked_google" not in ids

    def test_google_signin_unlocks_linked_google(self, app_client):
        client, _, _ = app_client
        from ctfy.core.state.models import CompetitionState
        from ctfy.tests.conftest import TEST_COMPETITION_ID, oauth_login

        token = oauth_login(client, "google", email="g@example.test")
        auth = {"Authorization": f"Bearer {token}"}
        backend = client.app.state.ctfy.state_backend
        if backend.get_competition(TEST_COMPETITION_ID) is None:
            backend.put_competition(
                CompetitionState(
                    competition_id=TEST_COMPETITION_ID,
                    title="Test",
                    created_at="2026-01-01T00:00:00Z",
                )
            )
        client.post(
            f"/api/v1/competitions/{TEST_COMPETITION_ID}/teams",
            json={"mode": "solo"},
            headers=auth,
        )
        r = client.get("/api/v1/me/achievements", headers=auth)
        ids = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "linked_google" in ids
        assert "linked_github" not in ids


# -- POST /me/star-gazer/verify -----------------------------------------------


class TestStarGazerVerify:
    """End-to-end tests for the GitHub-API-backed Star Gazer flow.

    The verifier hits ``api.github.com``; we monkeypatch
    ``verify_star`` (and ``resolve_login``) so tests stay hermetic.
    The route's other branches — no GitHub identity, missing repo
    URL, rate limit cool-down — are covered without touching the
    network at all.
    """

    def _signin_github(
        self, client, *, email="player@example.test", login="player1"
    ) -> dict:
        from ctfy.tests.conftest import TEST_COMPETITION_ID, oauth_login

        token = oauth_login(
            client,
            "github",
            email=email,
            display_name="Player",
            provider_login=login,
        )
        auth = {"Authorization": f"Bearer {token}"}
        # Solo-register so the caller has a team to credit the badge to.
        backend = client.app.state.ctfy.state_backend
        if backend.get_competition(TEST_COMPETITION_ID) is None:
            from ctfy.core.state.models import CompetitionState

            backend.put_competition(
                CompetitionState(
                    competition_id=TEST_COMPETITION_ID,
                    title="Test",
                    created_at="2026-01-01T00:00:00Z",
                )
            )
        client.post(
            f"/api/v1/competitions/{TEST_COMPETITION_ID}/teams",
            json={"mode": "solo"},
            headers=auth,
        )
        return auth

    def test_no_github_identity_returns_friendly_reason(self, app_client):
        client, _, _ = app_client
        from ctfy.tests.conftest import TEST_COMPETITION_ID, oauth_login

        token = oauth_login(
            client, "google", email="googly@example.test", display_name="G"
        )
        auth = {"Authorization": f"Bearer {token}"}
        backend = client.app.state.ctfy.state_backend
        if backend.get_competition(TEST_COMPETITION_ID) is None:
            from ctfy.core.state.models import CompetitionState

            backend.put_competition(
                CompetitionState(
                    competition_id=TEST_COMPETITION_ID,
                    title="Test",
                    created_at="2026-01-01T00:00:00Z",
                )
            )
        client.post(
            f"/api/v1/competitions/{TEST_COMPETITION_ID}/teams",
            json={"mode": "solo"},
            headers=auth,
        )
        r = client.post("/api/v1/me/star-gazer/verify", headers=auth)
        assert r.status_code == 200
        body = r.json()
        assert body["verified"] is False
        assert body["reason"] == "no_github_identity"

    def test_repo_not_configured(self, app_client, monkeypatch):
        client, _, _ = app_client
        client.app.state.ctfy.config.repo_url = ""
        auth = self._signin_github(client)
        r = client.post("/api/v1/me/star-gazer/verify", headers=auth)
        assert r.status_code == 200
        assert r.json()["reason"] == "repo_not_configured"

    def test_starred_grants_badge_and_ambassador(self, app_client, monkeypatch):
        client, _, _ = app_client
        # Make sure the cooldown bucket is empty across tests.
        from ctfy.server.routes import achievements as ach_routes
        ach_routes._star_verify_last_attempt.clear()
        client.app.state.ctfy.config.repo_url = "https://github.com/wangyihang/ctfy"

        async def fake_verify_star(login, owner, repo, *, github_pat=""):
            from ctfy.server.achievements.github_star import StarVerifyResult

            assert login == "player1"
            assert (owner, repo) == ("wangyihang", "ctfy")
            return StarVerifyResult.STARRED

        monkeypatch.setattr(
            "ctfy.server.routes.achievements.verify_star", fake_verify_star
        )

        auth = self._signin_github(client, login="player1")
        r = client.post("/api/v1/me/star-gazer/verify", headers=auth)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["verified"] is True
        assert body["reason"] == "starred"
        assert body["already_unlocked"] is False
        assert body["achievement"]["achievement_id"] == "star_gazer"

        # Idempotent — calling again short-circuits without burning a
        # GitHub call (the cooldown also blocks it, but the early-out
        # for already-earned should win regardless).
        ach_routes._star_verify_last_attempt.clear()
        r2 = client.post("/api/v1/me/star-gazer/verify", headers=auth)
        assert r2.status_code == 200
        body2 = r2.json()
        assert body2["verified"] is True
        assert body2["already_unlocked"] is True

        # Ambassador combo fired because linked_github was already
        # granted at sign-in and now star_gazer is in place.
        r3 = client.get("/api/v1/me/achievements", headers=auth)
        ids = {a["achievement_id"] for a in r3.json()["unlocked"]}
        assert "ambassador" in ids

    def test_not_starred_returns_reason(self, app_client, monkeypatch):
        client, _, _ = app_client
        from ctfy.server.routes import achievements as ach_routes
        ach_routes._star_verify_last_attempt.clear()
        client.app.state.ctfy.config.repo_url = "https://github.com/wangyihang/ctfy"

        async def fake_verify_star(*args, **kwargs):
            from ctfy.server.achievements.github_star import StarVerifyResult

            return StarVerifyResult.NOT_STARRED

        monkeypatch.setattr(
            "ctfy.server.routes.achievements.verify_star", fake_verify_star
        )

        auth = self._signin_github(client, login="ghost")
        r = client.post("/api/v1/me/star-gazer/verify", headers=auth)
        assert r.status_code == 200
        body = r.json()
        assert body["verified"] is False
        assert body["reason"] == "not_starred"
        # And the badge stays locked.
        r2 = client.get("/api/v1/me/achievements", headers=auth)
        ids = {a["achievement_id"] for a in r2.json()["unlocked"]}
        assert "star_gazer" not in ids

    def test_backfills_login_for_old_identities(self, app_client, monkeypatch):
        client, backend, _ = app_client
        from ctfy.server.routes import achievements as ach_routes
        ach_routes._star_verify_last_attempt.clear()
        client.app.state.ctfy.config.repo_url = "https://github.com/wangyihang/ctfy"

        # Sign in with an empty provider_login, simulating an OAuth
        # identity created before the field was added.
        from ctfy.core.state.models import CompetitionState
        from ctfy.tests.conftest import TEST_COMPETITION_ID, oauth_login

        token = oauth_login(
            client,
            "github",
            email="oldtimer@example.test",
            display_name="Old Timer",
            provider_login="",
        )
        auth = {"Authorization": f"Bearer {token}"}
        if backend.get_competition(TEST_COMPETITION_ID) is None:
            backend.put_competition(
                CompetitionState(
                    competition_id=TEST_COMPETITION_ID,
                    title="Test",
                    created_at="2026-01-01T00:00:00Z",
                )
            )
        client.post(
            f"/api/v1/competitions/{TEST_COMPETITION_ID}/teams",
            json={"mode": "solo"},
            headers=auth,
        )

        async def fake_resolve_login(provider_user_id, *, github_pat=""):
            return "resolved-login"

        async def fake_verify_star(login, owner, repo, *, github_pat=""):
            from ctfy.server.achievements.github_star import StarVerifyResult

            assert login == "resolved-login"
            return StarVerifyResult.STARRED

        monkeypatch.setattr(
            "ctfy.server.routes.achievements.resolve_login", fake_resolve_login
        )
        monkeypatch.setattr(
            "ctfy.server.routes.achievements.verify_star", fake_verify_star
        )

        r = client.post("/api/v1/me/star-gazer/verify", headers=auth)
        assert r.status_code == 200, r.text
        assert r.json()["verified"] is True

        # The persisted identity now carries the resolved login so
        # subsequent verifications skip the lookup call.
        user = backend.get_user_by_email("oldtimer@example.test")
        idents = backend.list_identities_for_user(user.user_id)
        gh = next(i for i in idents if i.provider == "github")
        assert gh.provider_login == "resolved-login"

    def test_rate_limit_cooldown(self, app_client, monkeypatch):
        client, _, _ = app_client
        from ctfy.server.routes import achievements as ach_routes
        ach_routes._star_verify_last_attempt.clear()
        client.app.state.ctfy.config.repo_url = "https://github.com/wangyihang/ctfy"

        calls = {"n": 0}

        async def fake_verify_star(*args, **kwargs):
            from ctfy.server.achievements.github_star import StarVerifyResult

            calls["n"] += 1
            return StarVerifyResult.NOT_STARRED

        monkeypatch.setattr(
            "ctfy.server.routes.achievements.verify_star", fake_verify_star
        )

        auth = self._signin_github(client, email="rate@example.test", login="rate")
        r1 = client.post("/api/v1/me/star-gazer/verify", headers=auth)
        assert r1.json()["reason"] == "not_starred"
        # Immediate retry hits the per-team cooldown — no GitHub call.
        r2 = client.post("/api/v1/me/star-gazer/verify", headers=auth)
        assert r2.json()["reason"] == "rate_limited"
        assert calls["n"] == 1


class TestGitHubStarHelpers:
    """Pure-Python helpers in :mod:`ctfy.server.achievements.github_star`."""

    def test_parse_owner_repo_handles_common_shapes(self):
        from ctfy.server.achievements.github_star import parse_owner_repo

        assert parse_owner_repo("https://github.com/foo/bar") == ("foo", "bar")
        assert parse_owner_repo("https://github.com/foo/bar/") == ("foo", "bar")
        assert parse_owner_repo("https://github.com/foo/bar.git") == ("foo", "bar")
        assert parse_owner_repo("https://www.github.com/foo/bar") == ("foo", "bar")

    def test_parse_owner_repo_rejects_non_github(self):
        from ctfy.server.achievements.github_star import parse_owner_repo

        assert parse_owner_repo("") is None
        assert parse_owner_repo("https://gitlab.com/foo/bar") is None
        assert parse_owner_repo("https://github.com/foo") is None
        assert parse_owner_repo("not a url") is None
