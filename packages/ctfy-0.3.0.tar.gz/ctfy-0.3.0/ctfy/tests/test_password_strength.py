"""Audit #6 — password strength enforcement on register / set-password."""

from __future__ import annotations

import pytest

from ctfy.server.password import MIN_PASSWORD_LENGTH, validate_password_strength
from ctfy.tests.conftest import register_team


class TestStrengthValidator:
    def test_short_password_rejected(self):
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as ei:
            validate_password_strength("a" * (MIN_PASSWORD_LENGTH - 1))
        assert ei.value.status_code == 422
        assert "at least" in ei.value.detail

    def test_common_password_rejected(self):
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as ei:
            validate_password_strength("password1234")
        assert ei.value.status_code == 422
        assert "common" in ei.value.detail.lower()

    def test_strong_password_accepted(self):
        # No exception means accepted.
        validate_password_strength("correct-horse-battery-staple")


class TestRegisterEnforcesStrength:
    def test_pydantic_rejects_below_minimum(self, client):
        r = client.post(
            "/api/v1/auth/register",
            json={"email": "x@example.com", "password": "short"},
        )
        assert r.status_code == 422

    def test_validator_rejects_common_password_at_minimum_length(self, client):
        # 12-char password that's in the common-password list. Pydantic's
        # min_length passes (12 chars meets the floor); the route handler
        # then runs validate_password_strength and catches the dictionary hit.
        r = client.post(
            "/api/v1/auth/register",
            json={"email": "x@example.com", "password": "password1234"},
        )
        assert r.status_code == 422
        assert "common" in r.json()["detail"].lower()

    def test_strong_password_creates_team(self, client):
        token = register_team(
            client, email="ok@example.com", password="correct-horse-battery"
        )
        assert token.startswith("pt_")


class TestSetPasswordEnforcesStrength:
    def test_change_to_weak_rejected(self, client):
        token = register_team(
            client, email="alice@example.com", password="correct-horse-battery"
        )
        r = client.post(
            "/api/v1/auth/password",
            json={
                "current_password": "correct-horse-battery",
                "new_password": "abc",
            },
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status_code == 422
