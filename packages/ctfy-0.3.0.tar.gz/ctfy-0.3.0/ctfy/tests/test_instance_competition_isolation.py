"""Per-competition instance isolation.

A user can be on different per-comp teams across multiple competitions
(team A in comp1, team B in comp2). Instances belong to *one* team in
*one* competition — listing under comp2 must not surface comp1's
instances, even if the same challenge_id appears in both comps'
curated sets.

Pre-fix bug: ``GET /instances`` collected every team_id the user is on
across all comps, then listed every instance owned by any of those
teams. The frontend tried to band-aid the leak by filtering to
``competition.challenge_ids`` client-side, but a challenge that lived
in both comps still showed up in the wrong tab.

Fix shape:
- ``InstanceState`` carries ``competition_id``.
- ``POST /instances`` stamps it from the resolved per-comp team.
- ``GET /instances?competition_id=X`` filters server-side.
"""

from __future__ import annotations

from ctfy.core.state.models import (
    TeamMembershipState,
    TeamState,
    CompetitionState,
)
from ctfy.tests.conftest import (
    TEST_COMPETITION_ID,
    mint_team,
    start_instance_and_wait,
)


def _seed_second_competition(backend, user_id: str, comp_id: str = "comp-2") -> str:
    """Add a second competition + matching per-comp team for ``user_id``.

    Returns the team_id of the newly minted team scoped to ``comp_id``.
    The user is left on both comps simultaneously.
    """
    if backend.get_competition(comp_id) is None:
        backend.put_competition(
            CompetitionState(
                competition_id=comp_id,
                title=comp_id,
                created_at="2026-01-01T00:00:00Z",
            )
        )
    team = backend.create_team_for_competition(
        user_id=user_id,
        competition_id=comp_id,
        team_name=f"team-for-{comp_id}",
        now_iso="2026-01-01T00:00:00Z",
        joined_via="solo",
    )
    return team.team_id


class TestListInstancesScopedToCompetition:
    def test_instance_started_in_comp1_not_visible_under_comp2(self, client):
        """The reproducer for the user-reported bug.

        A user is registered for two comps. They start an instance for
        WEB-001 under comp1. Listing under comp2 must NOT return that
        instance — even though the user *can* reach instances on team A
        through their account, those rows are scoped to comp1.
        """
        backend = client.app.state.ctfy.state_backend
        # Default mint_team registers the user for TEST_COMPETITION_ID.
        minted = mint_team(backend, name="A", email="a@x")
        comp2 = "comp-2"
        _seed_second_competition(backend, minted.user_id, comp2)

        # Start an instance under comp1 — default in start_instance_and_wait.
        a_id = start_instance_and_wait(
            client,
            "WEB-001",
            headers=minted.headers,
            competition_id=TEST_COMPETITION_ID,
        )

        # Listing under comp2 must not surface it.
        r = client.get(
            f"/api/v1/instances?competition_id={comp2}",
            headers=minted.headers,
        )
        assert r.status_code == 200
        ids = {it["instance_id"] for it in r.json()["items"]}
        assert a_id not in ids

        # Sanity: listing under comp1 still returns it.
        r = client.get(
            f"/api/v1/instances?competition_id={TEST_COMPETITION_ID}",
            headers=minted.headers,
        )
        ids = {it["instance_id"] for it in r.json()["items"]}
        assert a_id in ids

    def test_instances_carry_competition_id(self, client):
        """``InstanceInfo.competition_id`` is the field the frontend
        will read to scope its rendering. Asserting it on the listing
        ensures the projection is wired end-to-end."""
        backend = client.app.state.ctfy.state_backend
        minted = mint_team(backend, name="A", email="a@x")
        a_id = start_instance_and_wait(
            client,
            "WEB-001",
            headers=minted.headers,
            competition_id=TEST_COMPETITION_ID,
        )
        items = client.get(
            f"/api/v1/instances?competition_id={TEST_COMPETITION_ID}",
            headers=minted.headers,
        ).json()["items"]
        match = [it for it in items if it["instance_id"] == a_id]
        assert match, "started instance must appear in its own comp listing"
        assert match[0]["competition_id"] == TEST_COMPETITION_ID

    def test_listing_without_filter_still_returns_all_user_instances(self, client):
        """The unfiltered listing keeps its old contract for clients
        that haven't migrated to the per-comp scope (CLI/SDK callers,
        the global Dashboard panel). It must still be user-scoped — i.e.
        only return instances owned by teams the user is currently on —
        but it must not start dropping per-comp rows."""
        backend = client.app.state.ctfy.state_backend
        minted = mint_team(backend, name="A", email="a@x")
        comp2 = "comp-2"
        _seed_second_competition(backend, minted.user_id, comp2)

        a_id = start_instance_and_wait(
            client, "WEB-001", headers=minted.headers, competition_id=TEST_COMPETITION_ID
        )
        b_id = start_instance_and_wait(
            client, "WEB-002", headers=minted.headers, competition_id=comp2
        )
        items = client.get("/api/v1/instances", headers=minted.headers).json()["items"]
        ids = {it["instance_id"] for it in items}
        assert a_id in ids
        assert b_id in ids


class TestStartInstanceStampsCompetitionId:
    def test_start_instance_records_competition_id_on_state(self, client):
        backend = client.app.state.ctfy.state_backend
        minted = mint_team(backend, name="A", email="a@x")
        instance_id = start_instance_and_wait(
            client,
            "WEB-001",
            headers=minted.headers,
            competition_id=TEST_COMPETITION_ID,
        )
        inst = backend.get_instance(instance_id)
        assert inst is not None
        assert inst.competition_id == TEST_COMPETITION_ID
