"""Schema tests for :class:`ctfy.core.challenge.ChallengeSpec`.

The upstream challenges repo enforces a slim v3 metadata contract — four
required fields, no unknown keys, difficulty restricted to {easy, medium,
hard}, tags non-empty. These tests pin the pydantic model to that contract
so we can't silently accept drift.
"""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.enums import Difficulty


def _write_metadata(tmp_path, challenge_id: str, body: dict) -> Path:
    d = tmp_path / challenge_id
    d.mkdir()
    yml = d / "metadata.yaml"
    yml.write_text(yaml.safe_dump(body, sort_keys=False))
    return yml


def test_from_yaml_injects_id_from_dirname(tmp_path):
    yml = _write_metadata(
        tmp_path,
        "CTFARENA-XX",
        {
            "name": "SampleCTF",
            "description": "desc",
            "difficulty": "easy",
            "tags": ["idor"],
        },
    )
    spec = ChallengeSpec.from_yaml(yml)
    assert spec.id == "CTFARENA-XX"
    assert spec.difficulty is Difficulty.EASY
    assert spec.tags == ["idor"]


def test_rejects_unknown_fields(tmp_path):
    """META005: any key beyond the four allowed ones must fail."""
    yml = _write_metadata(
        tmp_path,
        "CTFARENA-01",
        {
            "name": "X",
            "description": "x",
            "difficulty": "easy",
            "tags": ["t"],
            "origin": "legacy",  # forbidden
        },
    )
    with pytest.raises(ValidationError):
        ChallengeSpec.from_yaml(yml)


def test_rejects_empty_tags(tmp_path):
    """META004: tags must be a non-empty list."""
    yml = _write_metadata(
        tmp_path,
        "CTFARENA-02",
        {
            "name": "X",
            "description": "x",
            "difficulty": "easy",
            "tags": [],
        },
    )
    with pytest.raises(ValidationError):
        ChallengeSpec.from_yaml(yml)


def test_rejects_bad_difficulty(tmp_path):
    """META003: difficulty must be easy|medium|hard."""
    yml = _write_metadata(
        tmp_path,
        "CTFARENA-03",
        {
            "name": "X",
            "description": "x",
            "difficulty": "expert",  # bad
            "tags": ["t"],
        },
    )
    with pytest.raises(ValidationError):
        ChallengeSpec.from_yaml(yml)


def test_category_and_provider_are_platform_constants():
    assert ChallengeSpec.CATEGORY == "web"
    assert ChallengeSpec.PROVIDER == "docker"


def test_effective_id_falls_back_to_id():
    spec = ChallengeSpec(
        id="X",
        name="X",
        description="x",
        difficulty=Difficulty.EASY,
        tags=["t"],
    )
    assert spec.effective_id == "X"
    forked = spec.model_copy(update={"instance_id": "inst-42"})
    assert forked.effective_id == "inst-42"


class TestFlagsField:
    """Multi-flag extension: optional ``flags: list[str]`` in metadata.yaml."""

    def test_omitted_defaults_to_main(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F1",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
            },
        )
        spec = ChallengeSpec.from_yaml(yml)
        assert spec.flags == ["main"]

    def test_multi_flag_ids(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F2",
            {
                "name": "X",
                "description": "x",
                "difficulty": "medium",
                "tags": ["t"],
                "flags": ["foothold", "root"],
            },
        )
        spec = ChallengeSpec.from_yaml(yml)
        assert spec.flags == ["foothold", "root"]

    def test_rejects_non_snake_case_id(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F3",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "flags": ["Foot-hold"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_rejects_duplicate_ids(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F4",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "flags": ["foothold", "foothold"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_rejects_empty_list(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F5",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "flags": [],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_rejects_id_starting_with_digit(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F6",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "flags": ["1st"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)


class TestVarsAndPublicVars:
    """Per-instance random tokens — ``vars`` (private) + ``public_vars``.

    Both lists default empty, follow the same id rules as ``flags``, and
    must not collide with each other or with flag ids. The ``description``
    field may reference public_vars via ``${VAR_<UPPER_ID>}`` placeholders;
    referencing a private or undeclared id is a metadata error.
    """

    def test_default_vars_and_public_vars_are_empty(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-V1",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
            },
        )
        spec = ChallengeSpec.from_yaml(yml)
        assert spec.vars == []
        assert spec.public_vars == []

    def test_accepts_declared_vars(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-V2",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "vars": ["admin_path", "api_param"],
                "public_vars": ["banner"],
            },
        )
        spec = ChallengeSpec.from_yaml(yml)
        assert spec.vars == ["admin_path", "api_param"]
        assert spec.public_vars == ["banner"]

    def test_rejects_collision_between_flags_and_vars(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-V3",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "flags": ["foothold"],
                "vars": ["foothold"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_rejects_collision_between_vars_and_public_vars(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-V4",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "vars": ["banner"],
                "public_vars": ["banner"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_rejects_bad_var_id(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-V5",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "vars": ["AdminPath"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_description_can_reference_public_var(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-V6",
            {
                "name": "X",
                "description": "Find the admin at ${VAR_ADMIN_PATH}",
                "difficulty": "easy",
                "tags": ["t"],
                "public_vars": ["admin_path"],
            },
        )
        spec = ChallengeSpec.from_yaml(yml)
        rendered = spec.render_description({"admin_path": "abcd1234"})
        assert "abcd1234" in rendered

    def test_description_referencing_private_var_is_rejected(self, tmp_path):
        # Private vars must remain hidden; substitution would leak them
        # through the public InstanceInfo description payload.
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-V7",
            {
                "name": "X",
                "description": "Secret at ${VAR_SECRET}",
                "difficulty": "easy",
                "tags": ["t"],
                "vars": ["secret"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_description_referencing_unknown_var_is_rejected(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-V8",
            {
                "name": "X",
                "description": "Missing $VAR_NOPE",
                "difficulty": "easy",
                "tags": ["t"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_render_description_noop_when_no_public_vars(self):
        spec = ChallengeSpec(
            id="X",
            name="X",
            description="static text $FLAG",
            difficulty=Difficulty.EASY,
            tags=["t"],
        )
        # No public_vars means no substitution at all — even ``$FLAG``-like
        # tokens pass through unchanged. (The flag itself is a runtime
        # contract, not a description placeholder.)
        assert spec.render_description({}) == "static text $FLAG"
