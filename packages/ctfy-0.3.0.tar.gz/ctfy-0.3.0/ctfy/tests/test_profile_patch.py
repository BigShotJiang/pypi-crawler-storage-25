"""End-to-end tests for ``PATCH /api/v1/me/profile`` and
``PATCH /api/v1/me/profile/visibility``.

The TeamState fields themselves are covered in
``test_team_state_profile_fields.py``; these tests pin the route
contract: which fields can be set, which trigger validation
errors, and which auth surface gates the writes.
"""

from __future__ import annotations

from ctfy.tests.conftest import mint_team


def test_patch_profile_updates_fields(client, backend):
    team = mint_team(backend, name="P", email="p@example.test")
    resp = client.patch(
        "/api/v1/me/profile",
        headers=team.headers,
        json={
            "bio": "hello world",
            "country": "JP",
            "website_url": "https://example.com",
            "timezone": "Asia/Tokyo",
            "social_links": {"github": "octocat"},
        },
    )
    assert resp.status_code == 200
    after = backend.get_user(team.user_id)
    assert after.bio == "hello world"
    assert after.country == "JP"
    assert after.website_url == "https://example.com"
    assert after.timezone == "Asia/Tokyo"
    assert after.social_links == {"github": "octocat"}


def test_patch_profile_partial_only_overwrites_supplied_fields(client, backend):
    team = mint_team(backend, name="P", email="p@example.test")
    # First write — set bio + country.
    client.patch(
        "/api/v1/me/profile",
        headers=team.headers,
        json={"bio": "first", "country": "US"},
    )
    # Second write — only overwrite bio. country should survive.
    client.patch(
        "/api/v1/me/profile",
        headers=team.headers,
        json={"bio": "second"},
    )
    after = backend.get_user(team.user_id)
    assert after.bio == "second"
    assert after.country == "US"


def test_patch_profile_clears_a_field_with_explicit_null(client, backend):
    """Setting a field to null is distinct from omitting it — null
    means "I want the field cleared", omission means "leave it alone"."""
    team = mint_team(backend, name="P", email="p@example.test")
    client.patch(
        "/api/v1/me/profile",
        headers=team.headers,
        json={"bio": "to clear"},
    )
    assert backend.get_user(team.user_id).bio == "to clear"
    client.patch(
        "/api/v1/me/profile",
        headers=team.headers,
        json={"bio": None},
    )
    assert backend.get_user(team.user_id).bio is None


def test_patch_profile_rejects_invalid_country(client, backend):
    team = mint_team(backend, name="P", email="p@example.test")
    resp = client.patch(
        "/api/v1/me/profile",
        headers=team.headers,
        json={"country": "usa"},
    )
    assert resp.status_code in (400, 422)
    # Field unchanged.
    assert backend.get_user(team.user_id).country is None


def test_patch_profile_requires_authentication(client):
    resp = client.patch("/api/v1/me/profile", json={"bio": "x"})
    assert resp.status_code in (401, 403)


def test_patch_visibility_overlays_supplied_keys(client, backend):
    team = mint_team(backend, name="P", email="p@example.test")
    # Initial visibility map empty.
    assert backend.get_user(team.user_id).profile_visibility == {}
    client.patch(
        "/api/v1/me/profile/visibility",
        headers=team.headers,
        json={"email": False, "country": True},
    )
    assert backend.get_user(team.user_id).profile_visibility == {
        "email": False,
        "country": True,
    }
    # Second call only overlays the new key — existing entries survive.
    client.patch(
        "/api/v1/me/profile/visibility",
        headers=team.headers,
        json={"social_links": False},
    )
    assert backend.get_user(team.user_id).profile_visibility == {
        "email": False,
        "country": True,
        "social_links": False,
    }


def test_patch_visibility_only_accepts_known_keys(client, backend):
    """Unknown keys silently ignored or 422 — anything is fine as long
    as we don't write garbage into the row."""
    team = mint_team(backend, name="P", email="p@example.test")
    resp = client.patch(
        "/api/v1/me/profile/visibility",
        headers=team.headers,
        json={"definitely_not_a_field": True},
    )
    # Whichever the route picks, the row must not gain that key.
    assert resp.status_code in (200, 400, 422)
    assert "definitely_not_a_field" not in backend.get_user(team.user_id).profile_visibility


def test_patch_visibility_requires_authentication(client):
    resp = client.patch("/api/v1/me/profile/visibility", json={"email": False})
    assert resp.status_code in (401, 403)


# -- TeamInfo + MeResponse surface the new profile fields ----------------


def test_get_me_surfaces_profile_fields(client, backend):
    team = mint_team(backend, name="P", email="p@example.test")
    client.patch(
        "/api/v1/me/profile",
        headers=team.headers,
        json={
            "bio": "hello",
            "country": "JP",
            "website_url": "https://example.com",
            "timezone": "Asia/Tokyo",
            "social_links": {"github": "octocat"},
        },
    )
    resp = client.get("/api/v1/me", headers=team.headers)
    me = resp.json()
    assert me["bio"] == "hello"
    assert me["country"] == "JP"
    assert me["website_url"] == "https://example.com"
    assert me["timezone"] == "Asia/Tokyo"
    assert me["social_links"] == {"github": "octocat"}


def test_get_me_includes_profile_visibility(client, backend):
    """The editor needs the current visibility map to render its
    eye-icon toggles. /me is the only place that exposes it — the
    public /teams/{id} view hides it (the caller has no business
    seeing other teams' visibility config)."""
    team = mint_team(backend, name="P", email="p@example.test")
    client.patch(
        "/api/v1/me/profile/visibility",
        headers=team.headers,
        json={"email": False, "country": True},
    )
    me = client.get("/api/v1/me", headers=team.headers).json()
    assert me["profile_visibility"] == {"email": False, "country": True}


def test_me_endpoint_surfaces_profile_fields(client, backend):
    """Post user/team-split, profile fields live on the user — readable
    via ``/me``. Public team profiles (``/teams/{id}``) no longer
    carry per-human bio fields; team has its own description instead.
    """
    team = mint_team(backend, name="Display", email="d@example.test")
    client.patch(
        "/api/v1/me/profile",
        headers=team.headers,
        json={"bio": "hi"},
    )
    me = client.get("/api/v1/me", headers=team.headers).json()
    assert me["bio"] == "hi"
    # Public team endpoint exposes team-scoped fields, not user bio.
    public = client.get(f"/api/v1/teams/{team.team_id}").json()
    assert "bio" not in public
    assert "profile_visibility" not in public
