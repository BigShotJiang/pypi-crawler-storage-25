"""Site-wide announcements: backend + admin + Inbox surface.

Covers:
    * POST/PATCH/DELETE /admin/announcements — admin-gated, persistence,
      severity / window validation.
    * Backend ``list_announcements(active_only=...)`` time-window logic
      across both InMemoryBackend and SQLiteBackend.
    * GET /me/inbox — surfaces active + recently-expired announcements
      with per-user read state. (The legacy public ``/announcements``
      and ``/announcements/active`` endpoints have been removed.)
"""

from __future__ import annotations

import os
import tempfile
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import AnnouncementState
from ctfy.core.state.sqlite import SQLiteBackend
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team


# ---------------------------------------------------------------------------
# Time helpers — keep windows comfortably outside any test-runtime jitter.
# ---------------------------------------------------------------------------


def _iso(offset_seconds: int = 0) -> str:
    """ISO 8601 string ``offset_seconds`` away from now (UTC, with ``+00:00``).

    Matches what ``ctfy.server.app_state.now_iso`` emits so string
    comparison sorts chronologically.
    """
    return (datetime.now(timezone.utc) + timedelta(seconds=offset_seconds)).isoformat()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def world():
    """TestClient + backend + admin team — minimal harness, no challenge env."""
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    admin = mint_team(backend, name="admin", email="admin@example.test", is_admin=True)
    yield TestClient(app), backend, admin


def _player(client: TestClient, name: str = "Player"):
    backend = client.app.state.ctfy.state_backend
    return mint_team(backend, name=name, email=f"{name.lower()}@example.test")


# ---------------------------------------------------------------------------
# Public read surface — has been removed. The legacy /announcements and
# /announcements/active routes are gone; user-facing surfacing flows
# through /me/inbox now (see TestInboxSurface below).
# ---------------------------------------------------------------------------


class TestPublicEndpointsRemoved:
    """The user-facing public read endpoints have been removed; the
    SPA's catch-all static handler now serves the React index.html for
    any unmatched path under /api/v1, so we can't assert a clean 404.
    What we *can* assert is that the response is no longer the legacy
    JSON payload — the routes are gone in spirit."""

    def test_legacy_active_endpoint_no_longer_returns_json(self, world):
        client, _, _ = world
        r = client.get("/api/v1/announcements/active")
        # Whatever the response is, it must not be the old paginated
        # ``{items, total, ...}`` payload — the route is gone.
        if r.headers.get("content-type", "").startswith("application/json"):
            body = r.json()
            assert "items" not in body, (
                "Public /announcements/active endpoint should be removed"
            )

    def test_legacy_history_endpoint_no_longer_returns_json(self, world):
        client, _, _ = world
        r = client.get("/api/v1/announcements")
        if r.headers.get("content-type", "").startswith("application/json"):
            body = r.json()
            assert "items" not in body, (
                "Public /announcements endpoint should be removed"
            )


# ---------------------------------------------------------------------------
# Admin gating + CRUD
# ---------------------------------------------------------------------------


class TestAdminCrud:
    def test_create_requires_admin(self, world):
        client, _, _ = world
        # Anonymous
        r1 = client.post(
            "/api/v1/admin/announcements",
            json={"title": "x", "body": "x"},
        )
        assert r1.status_code in (401, 403)
        # Non-admin
        team = _player(client)
        r2 = client.post(
            "/api/v1/admin/announcements",
            json={"title": "x", "body": "x"},
            headers=team.headers,
        )
        assert r2.status_code in (401, 403)

    def test_admin_list_requires_admin(self, world):
        client, _, _ = world
        r = client.get("/api/v1/admin/announcements")
        assert r.status_code in (401, 403)

    def test_create_round_trips(self, world):
        client, backend, admin = world
        r = client.post(
            "/api/v1/admin/announcements",
            json={
                "title": "Maintenance tonight",
                "body": "**Heads up** — DB migration at 22:00 UTC.",
                "severity": "warning",
                "ends_at": _iso(7200),
            },
            headers=admin.headers,
        )
        assert r.status_code == 201
        body = r.json()
        assert body["title"] == "Maintenance tonight"
        assert body["severity"] == "warning"
        assert body["created_by"] == admin.user_id
        assert body["created_by_name"]
        ann_id = body["announcement_id"]
        assert ann_id

        # Backend has it.
        stored = backend.get_announcement(ann_id)
        assert stored is not None
        assert stored.title == "Maintenance tonight"

        # Inbox surfaces it for an authenticated user.
        team = _player(client)
        inbox = client.get("/api/v1/me/inbox", headers=team.headers).json()
        assert any(
            a["announcement_id"] == ann_id for a in inbox["announcements"]
        )

    def test_create_rejects_bad_severity(self, world):
        client, _, admin = world
        r = client.post(
            "/api/v1/admin/announcements",
            json={"title": "bad", "body": "", "severity": "shouting"},
            headers=admin.headers,
        )
        assert r.status_code == 422

    def test_create_rejects_inverted_window(self, world):
        client, _, admin = world
        r = client.post(
            "/api/v1/admin/announcements",
            json={
                "title": "broken",
                "body": "",
                "severity": "info",
                "starts_at": _iso(3600),
                "ends_at": _iso(60),  # before starts_at
            },
            headers=admin.headers,
        )
        assert r.status_code == 422

    def test_create_rejects_empty_title(self, world):
        client, _, admin = world
        r = client.post(
            "/api/v1/admin/announcements",
            json={"title": "", "body": "x"},
            headers=admin.headers,
        )
        assert r.status_code == 422

    def test_update_partial(self, world):
        client, _, admin = world
        ann_id = client.post(
            "/api/v1/admin/announcements",
            json={"title": "v1", "body": "old", "severity": "info"},
            headers=admin.headers,
        ).json()["announcement_id"]

        r = client.patch(
            f"/api/v1/admin/announcements/{ann_id}",
            json={"title": "v2"},
            headers=admin.headers,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["title"] == "v2"
        assert body["body"] == "old"  # untouched
        assert body["severity"] == "info"
        # updated_at advanced (or at least re-stamped)
        assert body["updated_at"]

    def test_update_unknown_returns_404(self, world):
        client, _, admin = world
        r = client.patch(
            "/api/v1/admin/announcements/does-not-exist",
            json={"title": "x"},
            headers=admin.headers,
        )
        assert r.status_code == 404

    def test_update_rejects_inverted_window(self, world):
        """PATCH must validate the post-merge window, not just the body."""
        client, _, admin = world
        ann_id = client.post(
            "/api/v1/admin/announcements",
            json={
                "title": "win",
                "body": "",
                "severity": "info",
                "starts_at": _iso(60),
                "ends_at": _iso(3600),
            },
            headers=admin.headers,
        ).json()["announcement_id"]
        # Push starts_at past the existing ends_at.
        r = client.patch(
            f"/api/v1/admin/announcements/{ann_id}",
            json={"starts_at": _iso(7200)},
            headers=admin.headers,
        )
        assert r.status_code == 422

    def test_delete_requires_admin(self, world):
        client, _, admin = world
        ann_id = client.post(
            "/api/v1/admin/announcements",
            json={"title": "doomed", "body": "", "severity": "info"},
            headers=admin.headers,
        ).json()["announcement_id"]

        team = _player(client)
        r = client.delete(
            f"/api/v1/admin/announcements/{ann_id}", headers=team.headers
        )
        assert r.status_code in (401, 403)

    def test_delete_round_trip(self, world):
        client, backend, admin = world
        ann_id = client.post(
            "/api/v1/admin/announcements",
            json={"title": "doomed", "body": "", "severity": "info"},
            headers=admin.headers,
        ).json()["announcement_id"]

        r = client.delete(
            f"/api/v1/admin/announcements/{ann_id}", headers=admin.headers
        )
        assert r.status_code == 200
        assert backend.get_announcement(ann_id) is None
        # Idempotent on repeat delete: returns 404.
        r2 = client.delete(
            f"/api/v1/admin/announcements/{ann_id}", headers=admin.headers
        )
        assert r2.status_code == 404


class TestSSEBroadcast:
    """Each admin write fires an SSE frame so listeners refresh in real
    time. The activity log is intentionally bypassed (announcement CRUD
    isn't a team activity) — same shape as ``meta_stats``.
    """

    def _spy(self, client: TestClient):
        from unittest.mock import MagicMock

        hub = client.app.state.ctfy.sse_hub
        spy = MagicMock(wraps=hub.broadcast)
        hub.broadcast = spy
        return spy

    def test_create_broadcasts_announcement_created(self, world):
        client, _, admin = world
        spy = self._spy(client)
        r = client.post(
            "/api/v1/admin/announcements",
            json={"title": "hello", "body": "", "severity": "info"},
            headers=admin.headers,
        )
        assert r.status_code == 201
        ann_id = r.json()["announcement_id"]
        events = [c.args[0] for c in spy.call_args_list]
        assert "announcement_created" in events
        # Carries just the announcement_id; subscribers refetch the list
        # rather than trusting per-frame fields.
        for c in spy.call_args_list:
            if c.args[0] == "announcement_created":
                assert c.kwargs.get("data") == {"announcement_id": ann_id}
                assert c.kwargs.get("team_id", "") == ""
                break
        else:  # pragma: no cover
            raise AssertionError("announcement_created frame not seen")

    def test_update_broadcasts_announcement_updated(self, world):
        client, _, admin = world
        ann_id = client.post(
            "/api/v1/admin/announcements",
            json={"title": "x", "body": "", "severity": "info"},
            headers=admin.headers,
        ).json()["announcement_id"]
        spy = self._spy(client)
        r = client.patch(
            f"/api/v1/admin/announcements/{ann_id}",
            json={"title": "y"},
            headers=admin.headers,
        )
        assert r.status_code == 200
        assert "announcement_updated" in [c.args[0] for c in spy.call_args_list]

    def test_delete_broadcasts_announcement_deleted(self, world):
        client, _, admin = world
        ann_id = client.post(
            "/api/v1/admin/announcements",
            json={"title": "x", "body": "", "severity": "info"},
            headers=admin.headers,
        ).json()["announcement_id"]
        spy = self._spy(client)
        r = client.delete(
            f"/api/v1/admin/announcements/{ann_id}", headers=admin.headers
        )
        assert r.status_code == 200
        assert "announcement_deleted" in [c.args[0] for c in spy.call_args_list]

    def test_404_delete_does_not_broadcast(self, world):
        """A failed mutation must not push a frame — clients would
        otherwise refetch on phantom changes."""
        client, _, admin = world
        spy = self._spy(client)
        r = client.delete(
            "/api/v1/admin/announcements/does-not-exist", headers=admin.headers
        )
        assert r.status_code == 404
        events = [c.args[0] for c in spy.call_args_list]
        assert "announcement_deleted" not in events


# ---------------------------------------------------------------------------
# Backend filter logic — guard against InMemory / SQLite drifting apart.
# ---------------------------------------------------------------------------


@pytest.fixture(params=["memory", "sqlite"])
def announcement_backend(request):
    if request.param == "memory":
        yield InMemoryBackend()
        return
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        yield SQLiteBackend(path)
    finally:
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass


class TestBackendWindow:
    def test_active_filter_matches_window(self, announcement_backend):
        backend = announcement_backend
        now = _iso(0)

        live = AnnouncementState(
            announcement_id="a",
            title="live",
            severity="info",
            starts_at="",
            ends_at="",
            created_at=now,
            updated_at=now,
        )
        scheduled = AnnouncementState(
            announcement_id="b",
            title="scheduled",
            severity="info",
            starts_at=_iso(3600),
            ends_at="",
            created_at=now,
            updated_at=now,
        )
        expired = AnnouncementState(
            announcement_id="c",
            title="expired",
            severity="info",
            starts_at=_iso(-7200),
            ends_at=_iso(-3600),
            created_at=now,
            updated_at=now,
        )
        for ann in (live, scheduled, expired):
            backend.put_announcement(ann)

        ids_active = {a.announcement_id for a in backend.list_announcements(
            active_only=True, now_iso=now
        )}
        assert ids_active == {"a"}

        ids_all = {a.announcement_id for a in backend.list_announcements(active_only=False)}
        assert ids_all == {"a", "b", "c"}

    def test_delete_returns_false_when_missing(self, announcement_backend):
        assert announcement_backend.delete_announcement("ghost") is False

    def test_mark_read_is_idempotent(self, announcement_backend):
        backend = announcement_backend
        backend.put_announcement(
            AnnouncementState(
                announcement_id="x", title="t", severity="info",
                starts_at="", ends_at="", created_at=_iso(0), updated_at=_iso(0),
            )
        )
        first = backend.mark_announcement_read("user-1", "x", _iso(0))
        second = backend.mark_announcement_read("user-1", "x", _iso(60))
        assert first is True
        assert second is False
        assert backend.list_read_announcement_ids("user-1") == {"x"}

    def test_mark_bulk_returns_new_count(self, announcement_backend):
        backend = announcement_backend
        for aid in ("a", "b", "c"):
            backend.put_announcement(
                AnnouncementState(
                    announcement_id=aid, title=aid, severity="info",
                    starts_at="", ends_at="", created_at=_iso(0), updated_at=_iso(0),
                )
            )
        # First call inserts all three.
        new1 = backend.mark_announcements_read_bulk(
            "user-1", ["a", "b", "c"], _iso(0)
        )
        assert new1 == 3
        # Second call sees them all already-read; only the brand new "d"
        # row would count, so 0 here.
        new2 = backend.mark_announcements_read_bulk(
            "user-1", ["a", "b", "c"], _iso(60)
        )
        assert new2 == 0

    def test_delete_announcement_cascades_reads(self, announcement_backend):
        backend = announcement_backend
        backend.put_announcement(
            AnnouncementState(
                announcement_id="x", title="t", severity="info",
                starts_at="", ends_at="", created_at=_iso(0), updated_at=_iso(0),
            )
        )
        backend.mark_announcement_read("user-1", "x", _iso(0))
        backend.delete_announcement("x")
        # Read receipt should be gone — no orphan rows.
        assert backend.list_read_announcement_ids("user-1") == set()


# ---------------------------------------------------------------------------
# Inbox surface — announcements + read state ride on /me/inbox.
# ---------------------------------------------------------------------------


class TestInboxSurface:
    def test_inbox_includes_active_announcements(self, world):
        client, _, admin = world
        ann_id = client.post(
            "/api/v1/admin/announcements",
            json={"title": "Live", "body": "x", "severity": "info"},
            headers=admin.headers,
        ).json()["announcement_id"]
        team = _player(client)
        body = client.get("/api/v1/me/inbox", headers=team.headers).json()
        ids = [a["announcement_id"] for a in body["announcements"]]
        assert ann_id in ids
        # Initially unread.
        assert body["unread_announcement_count"] >= 1
        for a in body["announcements"]:
            if a["announcement_id"] == ann_id:
                assert a["is_read"] is False

    def test_mark_read_flips_is_read_and_decrements_count(self, world):
        client, _, admin = world
        ann_id = client.post(
            "/api/v1/admin/announcements",
            json={"title": "Live", "body": "x", "severity": "info"},
            headers=admin.headers,
        ).json()["announcement_id"]
        team = _player(client)
        before = client.get("/api/v1/me/inbox", headers=team.headers).json()
        unread_before = before["unread_announcement_count"]

        r = client.post(
            f"/api/v1/me/announcements/{ann_id}/read", headers=team.headers
        )
        assert r.status_code == 200
        assert r.json() == {"ok": True, "new": True}

        after = client.get("/api/v1/me/inbox", headers=team.headers).json()
        assert after["unread_announcement_count"] == unread_before - 1
        for a in after["announcements"]:
            if a["announcement_id"] == ann_id:
                assert a["is_read"] is True

    def test_mark_read_is_idempotent_on_route(self, world):
        client, _, admin = world
        ann_id = client.post(
            "/api/v1/admin/announcements",
            json={"title": "Live", "body": "x", "severity": "info"},
            headers=admin.headers,
        ).json()["announcement_id"]
        team = _player(client)
        client.post(
            f"/api/v1/me/announcements/{ann_id}/read", headers=team.headers
        )
        r2 = client.post(
            f"/api/v1/me/announcements/{ann_id}/read", headers=team.headers
        )
        assert r2.status_code == 200
        assert r2.json() == {"ok": True, "new": False}

    def test_mark_read_unknown_announcement_404s(self, world):
        client, _, _ = world
        team = _player(client)
        r = client.post(
            "/api/v1/me/announcements/not-a-real-id/read", headers=team.headers
        )
        assert r.status_code == 404

    def test_read_all_marks_all_visible(self, world):
        client, _, admin = world
        for t in ("A", "B", "C"):
            client.post(
                "/api/v1/admin/announcements",
                json={"title": t, "body": "", "severity": "info"},
                headers=admin.headers,
            )
        team = _player(client)
        # First call: all three are unread → at least 3 newly-read.
        r1 = client.post(
            "/api/v1/me/announcements/read-all", headers=team.headers
        )
        assert r1.status_code == 200
        assert r1.json()["ok"] is True
        assert r1.json()["read_count"] >= 3
        # Inbox now reports zero unread.
        body = client.get("/api/v1/me/inbox", headers=team.headers).json()
        assert body["unread_announcement_count"] == 0

    def test_inbox_surfaces_recently_expired(self, world):
        """Expired-within-7d notices still appear so users who login
        shortly after expiry can still read what was posted."""
        client, _, admin = world
        # Window: started 2h ago, ended 1h ago — well inside the 7d
        # window for "recently expired".
        client.post(
            "/api/v1/admin/announcements",
            json={
                "title": "JustExpired",
                "body": "",
                "severity": "info",
                "starts_at": _iso(-7200),
                "ends_at": _iso(-3600),
            },
            headers=admin.headers,
        )
        team = _player(client)
        body = client.get("/api/v1/me/inbox", headers=team.headers).json()
        titles = [a["title"] for a in body["announcements"]]
        assert "JustExpired" in titles

    def test_inbox_requires_auth(self, world):
        client, _, _ = world
        r = client.get("/api/v1/me/inbox")
        assert r.status_code in (401, 403)
