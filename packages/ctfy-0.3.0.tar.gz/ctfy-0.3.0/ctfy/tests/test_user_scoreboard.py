"""TDD: user-ranked global scoreboard (Phase 3b).

Per the per-comp team refactor, the global ``/scoreboard`` no
longer makes sense team-ranked (a user's solves are scattered
across N comp teams). The new ``GET /scoreboard/users`` aggregates
solves at the user level — sums every solve a user made across
every team they were on, sorts users by total flag count.

The team-ranked ``/scoreboard`` route stays (admin overview, per-
comp variant) but is no longer the default front-page surface.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import CompetitionState, SolveState
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team


@pytest.fixture
def world():
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    backend.put_competition(
        CompetitionState(
            competition_id="spring",
            title="Spring CTF",
            challenge_ids=["c1", "c2", "c3"],
            created_at="2026-01-01T00:00:00Z",
        )
    )
    backend.put_competition(
        CompetitionState(
            competition_id="summer",
            title="Summer CTF",
            challenge_ids=["c4"],
            created_at="2026-06-01T00:00:00Z",
        )
    )
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    yield TestClient(app), backend


def _solve(backend, *, team_id: str, user_id: str, challenge_id: str, when: str):
    backend.add_solve(
        team_id,
        challenge_id,
        "main",
        SolveState(
            team_id=team_id,
            user_id=user_id,
            challenge_id=challenge_id,
            flag_id="main",
            solved_at=when,
        ),
    )


def test_user_scoreboard_aggregates_across_teams(world):
    """Alice plays solo in spring (1 solve) and joins a multi-user
    team in summer (2 more solves). Her global rank counts all 3."""
    client, backend = world
    alice = mint_team(backend, name="Alice", email="a@x")
    spring_team = backend.create_team_for_competition(
        user_id=alice.user_id,
        competition_id="spring",
        team_name="Alice solo",
        now_iso="2026-01-01T00:00:00Z",
    )
    summer_team = backend.create_team_for_competition(
        user_id=alice.user_id,
        competition_id="summer",
        team_name="Alice summer",
        now_iso="2026-06-01T00:00:00Z",
    )
    _solve(
        backend,
        team_id=spring_team.team_id,
        user_id=alice.user_id,
        challenge_id="c1",
        when="2026-01-02T00:00:00Z",
    )
    _solve(
        backend,
        team_id=summer_team.team_id,
        user_id=alice.user_id,
        challenge_id="c4",
        when="2026-06-02T00:00:00Z",
    )
    _solve(
        backend,
        team_id=summer_team.team_id,
        user_id=alice.user_id,
        challenge_id="c2",
        when="2026-06-03T00:00:00Z",
    )

    r = client.get("/api/v1/scoreboard/users")
    assert r.status_code == 200, r.text
    items = r.json()["items"]
    alice_row = next(i for i in items if i["user_id"] == alice.user_id)
    assert alice_row["flags_solved"] == 3
    assert alice_row["display_name"] == "Alice"


def test_user_scoreboard_ranks_by_flag_count(world):
    """Two players, different solve counts → ranks reflect that."""
    client, backend = world
    alice = mint_team(backend, name="Alice", email="a@x")
    bob = mint_team(backend, name="Bob", email="b@x")
    a_team = backend.create_team_for_competition(
        user_id=alice.user_id,
        competition_id="spring",
        team_name="A",
        now_iso="2026-01-01T00:00:00Z",
    )
    b_team = backend.create_team_for_competition(
        user_id=bob.user_id,
        competition_id="spring",
        team_name="B",
        now_iso="2026-01-01T00:00:00Z",
    )
    # Alice: 2 solves; Bob: 1.
    _solve(
        backend, team_id=a_team.team_id, user_id=alice.user_id,
        challenge_id="c1", when="2026-01-02T00:00:00Z",
    )
    _solve(
        backend, team_id=a_team.team_id, user_id=alice.user_id,
        challenge_id="c2", when="2026-01-03T00:00:00Z",
    )
    _solve(
        backend, team_id=b_team.team_id, user_id=bob.user_id,
        challenge_id="c3", when="2026-01-02T00:00:00Z",
    )

    items = client.get("/api/v1/scoreboard/users").json()["items"]
    # Alice is rank 1, Bob is rank 2.
    by_user = {i["user_id"]: i for i in items}
    assert by_user[alice.user_id]["rank"] == 1
    assert by_user[alice.user_id]["flags_solved"] == 2
    assert by_user[bob.user_id]["rank"] == 2
    assert by_user[bob.user_id]["flags_solved"] == 1


def test_user_scoreboard_excludes_users_with_zero_solves(world):
    """Users registered but with 0 solves don't pollute the
    leaderboard (otherwise the public /scoreboard/users page is
    mostly empty rows)."""
    client, backend = world
    alice = mint_team(backend, name="Alice", email="a@x")
    mint_team(backend, name="Lurker", email="l@x")  # no solves
    a_team = backend.create_team_for_competition(
        user_id=alice.user_id,
        competition_id="spring",
        team_name="A",
        now_iso="2026-01-01T00:00:00Z",
    )
    _solve(
        backend, team_id=a_team.team_id, user_id=alice.user_id,
        challenge_id="c1", when="2026-01-02T00:00:00Z",
    )

    items = client.get("/api/v1/scoreboard/users").json()["items"]
    user_ids = {i["user_id"] for i in items}
    assert alice.user_id in user_ids
    # No row for the lurker.
    assert all(i["flags_solved"] > 0 for i in items)


def test_user_scoreboard_avatar_and_country(world):
    """Display fields project from UserState — avatar_url + country
    so the leaderboard UI can show a flag emoji + thumbnail."""
    client, backend = world
    alice = mint_team(backend, name="Alice", email="a@x")
    user = backend.get_user(alice.user_id)
    backend.put_user(
        alice.user_id,
        user.model_copy(update={"avatar_url": "https://x/a.png", "country": "JP"}),
    )
    a_team = backend.create_team_for_competition(
        user_id=alice.user_id,
        competition_id="spring",
        team_name="A",
        now_iso="2026-01-01T00:00:00Z",
    )
    _solve(
        backend, team_id=a_team.team_id, user_id=alice.user_id,
        challenge_id="c1", when="2026-01-02T00:00:00Z",
    )

    items = client.get("/api/v1/scoreboard/users").json()["items"]
    row = next(i for i in items if i["user_id"] == alice.user_id)
    assert row["avatar_url"] == "https://x/a.png"
    assert row["country"] == "JP"


def test_team_scoreboard_unaffected(world):
    """Adding /scoreboard/users does not change /scoreboard."""
    client, backend = world
    alice = mint_team(backend, name="Alice", email="a@x")
    a_team = backend.create_team_for_competition(
        user_id=alice.user_id,
        competition_id="spring",
        team_name="Alice solo",
        now_iso="2026-01-01T00:00:00Z",
    )
    _solve(
        backend, team_id=a_team.team_id, user_id=alice.user_id,
        challenge_id="c1", when="2026-01-02T00:00:00Z",
    )
    items = client.get("/api/v1/scoreboard").json()["items"]
    row = next(i for i in items if i["team_id"] == a_team.team_id)
    assert row["flags_solved"] == 1
