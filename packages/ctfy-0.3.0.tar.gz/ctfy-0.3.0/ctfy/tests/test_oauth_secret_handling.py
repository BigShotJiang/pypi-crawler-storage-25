"""Audit #4 — OAuth signing key (CTFY_SECRET_KEY) handling.

Pre-fix, an unset env var caused ``create_app`` to generate a fresh key
**and persist it to the state backend** (config table). A leaked sqlite
file therefore leaked the HMAC secret used to sign OAuth ``state``
parameters, enabling forged callbacks against a phishing relay.

Post-fix:
* Env-var-supplied keys never touch the backend.
* A pre-existing persisted row is honoured (back-compat) but logs a
  warning.
* The ephemeral fallback no longer writes to the backend; it warns
  loudly that restarts will invalidate in-flight OAuth flows.
"""

from __future__ import annotations

from unittest.mock import patch

from pydantic import SecretStr

from ctfy.core.config import CtfyConfig
from ctfy.core.state import InMemoryBackend


def _build(config: CtfyConfig, backend: InMemoryBackend):
    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager"):
        return create_app(config=config, external_host="10.0.1.5", backend=backend)


def test_env_supplied_secret_is_not_persisted():
    backend = InMemoryBackend()
    cfg = CtfyConfig(secret_key=SecretStr("env-supplied-secret"))
    app = _build(cfg, backend)
    assert app.state.ctfy.oauth_secret == "env-supplied-secret"
    assert app.state.ctfy.oauth_secret_source == "env"
    assert backend.get_config("oauth_secret_key") in (None, ""), (
        "env-supplied secrets must NEVER be written to the state backend (audit #4)"
    )


def test_legacy_persisted_secret_is_loaded_with_warning(caplog):
    """Existing deployments with an auto-persisted secret keep working."""
    backend = InMemoryBackend()
    backend.set_config("oauth_secret_key", "legacy-persisted-secret")
    cfg = CtfyConfig()  # no env var
    with caplog.at_level("WARNING"):
        app = _build(cfg, backend)
    assert app.state.ctfy.oauth_secret == "legacy-persisted-secret"
    assert app.state.ctfy.oauth_secret_source == "state_backend"
    assert any("loaded from state backend" in str(r.msg) for r in caplog.records)


def test_ephemeral_fallback_does_not_persist(caplog):
    """No env var, no existing row -> ephemeral key, no DB write."""
    backend = InMemoryBackend()
    cfg = CtfyConfig()  # no env var, fresh backend
    with caplog.at_level("WARNING"):
        app = _build(cfg, backend)
    assert app.state.ctfy.oauth_secret  # non-empty
    assert app.state.ctfy.oauth_secret_source == "ephemeral"
    assert backend.get_config("oauth_secret_key") in (None, ""), (
        "ephemeral secrets must NOT be persisted (audit #4)"
    )
    assert any("EPHEMERAL OAuth signing key" in str(r.msg) for r in caplog.records)
