"""Pin the ``team_deleted`` SSE contract: admin sessions get a frame
carrying the deleted team's id + name AND a fresh ``meta_stats``
snapshot so ``teams_total`` rolls in lockstep, while members don't
receive either.

The frame is fired from inside ``DELETE /me`` after the cascading
``StateBackend.delete_team`` returns truthy. A duplicate-delete race
(``deleted == False``) deliberately doesn't broadcast — the row is
already gone and another caller already published the signal.
"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

from fastapi.testclient import TestClient

from ctfy.core.enums import PlatformEvent
from ctfy.core.state import InMemoryBackend
from ctfy.server.app_state import AppState
from ctfy.server.sse import SSEHub
from ctfy.server.team_signal import emit_team_deleted, emit_team_profile_updated


def _make_app() -> AppState:
    backend = InMemoryBackend()
    spec_reader = MagicMock()
    spec_reader.iter_specs.return_value = iter([])
    return AppState(
        config=MagicMock(),
        state_backend=backend,
        spec_reader=spec_reader,
        sse_hub=SSEHub(),
        host="x",
        max_instances=10,
    )


def _calls_for(spy, event_name: str):
    return [c for c in spy.call_args_list if c.args[0] == event_name]


def test_emit_team_deleted_broadcasts_admin_only():
    app = _make_app()
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_team_deleted(app, team_id="t-x", team_name="Gone")
    deleted = _calls_for(spy, PlatformEvent.TEAM_DELETED.value)
    assert len(deleted) == 1
    assert deleted[0].kwargs["admin_only"] is True
    assert deleted[0].kwargs["team_id"] == ""
    data = deleted[0].kwargs["data"]
    assert data["team_id"] == "t-x"
    assert data["team_name"] == "Gone"


def test_emit_team_deleted_also_pushes_meta_stats():
    """``teams_total`` is admin-visible on /meta — the deletion has
    to push a fresh meta_stats frame too, otherwise the cluster
    counter goes stale until the next unrelated write."""
    app = _make_app()
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_team_deleted(app, team_id="t", team_name="N")
    meta = _calls_for(spy, PlatformEvent.META_STATS.value)
    assert len(meta) == 1
    assert meta[0].kwargs["admin_only"] is True


def test_admin_receives_team_deleted_member_does_not():
    async def go():
        app = _make_app()
        app.sse_hub.set_loop(asyncio.get_running_loop())
        _, member_q = app.sse_hub.connect(team_ids=frozenset({"t-keep"}), is_admin=False)
        _, admin_q = app.sse_hub.connect(team_ids=frozenset({"t-keep"}), is_admin=True)

        emit_team_deleted(app, team_id="t-x", team_name="Gone")

        # Admin: team_deleted lands first, then meta_stats.
        seen_deleted = False
        seen_meta = False
        for _ in range(4):
            frame = await asyncio.wait_for(admin_q.get(), timeout=1)
            if "event: team_deleted" in frame:
                seen_deleted = True
            if "event: meta_stats" in frame:
                seen_meta = True
            if seen_deleted and seen_meta:
                break
        assert seen_deleted
        assert seen_meta

        # Member queue: silent.
        try:
            frame = await asyncio.wait_for(member_q.get(), timeout=0.2)
            raise AssertionError(
                f"member queue received an admin_only frame: {frame!r}"
            )
        except asyncio.TimeoutError:
            pass

    asyncio.run(go())


def test_delete_me_route_emits_team_deleted(client, mint_team_fixture):
    """End-to-end: a self-service DELETE /me fires team_deleted +
    meta_stats. Pre-existing tests cover the cascade itself; this
    pins the SSE side-effect."""
    team = mint_team_fixture(name="Doomed", email="bye@example.com")
    app_state = client.app.state.ctfy
    spy = MagicMock(wraps=app_state.sse_hub.broadcast)
    app_state.sse_hub.broadcast = spy

    resp = client.request(
        "DELETE",
        "/api/v1/me",
        json={"confirm_display_name": "Doomed"},
        headers=team.headers,
    )
    assert resp.status_code == 204

    deleted = _calls_for(spy, PlatformEvent.TEAM_DELETED.value)
    assert len(deleted) == 1
    assert deleted[0].kwargs["admin_only"] is True
    assert deleted[0].kwargs["data"]["team_id"] == team.team_id
    assert deleted[0].kwargs["data"]["team_name"] == "Doomed"
    # And teams_total snapshot follows.
    assert _calls_for(spy, PlatformEvent.META_STATS.value)


def test_delete_me_idempotent_does_not_double_emit(client, mint_team_fixture):
    """If the cascade returns False (race / already deleted), the
    route returns 204 but does NOT re-broadcast — otherwise
    concurrent deletes would spam admin sessions with one frame per
    racing caller. A direct second DELETE with the same token would
    401, so we approximate the race by deleting the row first."""
    team = mint_team_fixture(name="Doomed2", email="bye2@example.com")
    app_state = client.app.state.ctfy
    # Pull the team out from under the route — the auth dep already
    # resolved by the time we get here would still hold a TeamState
    # in-memory, but the cascade returns False because there's
    # nothing left to delete. Easiest setup: delete first, then
    # call from a parallel client share the token.
    app_state.state_backend.delete_team(team.team_id)

    spy = MagicMock(wraps=app_state.sse_hub.broadcast)
    app_state.sse_hub.broadcast = spy
    resp = client.request(
        "DELETE",
        "/api/v1/me",
        json={"confirm_display_name": "Doomed2"},
        headers=team.headers,
    )
    # Post user/team-split DELETE /me deletes the USER (the team was
    # the user's pre-existing team and is already gone). The deletion
    # path skips ``delete_team`` for an already-missing team — so no
    # TEAM_DELETED broadcast fires twice.
    assert resp.status_code == 204
    assert _calls_for(spy, PlatformEvent.TEAM_DELETED.value) == []


# ---------------------------------------------------------------------------
# team_profile_updated: PATCH /me/profile + visibility — public broadcast
# ---------------------------------------------------------------------------


def test_emit_team_profile_updated_is_public_broadcast():
    """Profile changes are public-facing — anyone viewing /teams/{id}
    needs to refetch, so no admin gate."""
    app = _make_app()
    spy = MagicMock()
    app.sse_hub.broadcast = spy
    emit_team_profile_updated(app, team_id="t-x", team_name="Visible")
    spy.assert_called_once()
    args, kwargs = spy.call_args
    assert args[0] == PlatformEvent.TEAM_PROFILE_UPDATED.value
    assert kwargs.get("admin_only", False) is False
    assert kwargs["team_id"] == ""
    assert kwargs["data"] == {"team_id": "t-x", "team_name": "Visible"}


def test_patch_profile_route_emits_team_profile_updated(
    client, mint_team_fixture
):
    team = mint_team_fixture(name="Editor", email="ed@example.com")
    app_state = client.app.state.ctfy
    spy = MagicMock(wraps=app_state.sse_hub.broadcast)
    app_state.sse_hub.broadcast = spy

    resp = client.patch(
        "/api/v1/me/profile",
        json={"bio": "hello world", "country": "JP"},
        headers=team.headers,
    )
    assert resp.status_code == 200, resp.text
    updates = _calls_for(spy, PlatformEvent.TEAM_PROFILE_UPDATED.value)
    assert len(updates) == 1
    assert updates[0].kwargs["data"]["team_id"] == team.team_id


def test_patch_visibility_route_emits_team_profile_updated(
    client, mint_team_fixture
):
    """Flipping a visibility bit reshapes the public profile too —
    same signal so existing viewers refetch with the new mask."""
    team = mint_team_fixture(name="Privacy", email="p@example.com")
    app_state = client.app.state.ctfy
    spy = MagicMock(wraps=app_state.sse_hub.broadcast)
    app_state.sse_hub.broadcast = spy

    resp = client.patch(
        "/api/v1/me/profile/visibility",
        json={"bio": False},
        headers=team.headers,
    )
    assert resp.status_code == 200, resp.text
    updates = _calls_for(spy, PlatformEvent.TEAM_PROFILE_UPDATED.value)
    assert len(updates) == 1
    assert updates[0].kwargs["data"]["team_id"] == team.team_id


def test_admin_and_member_both_receive_team_profile_updated():
    """Public broadcast — every connected client sees the frame
    regardless of their team or admin status. The frontend filters
    by team_id in the payload."""

    async def go():
        app = _make_app()
        app.sse_hub.set_loop(asyncio.get_running_loop())
        _, member_q = app.sse_hub.connect(team_ids=frozenset({"t-a"}), is_admin=False)
        _, admin_q = app.sse_hub.connect(team_ids=frozenset({"t-b"}), is_admin=True)

        emit_team_profile_updated(app, team_id="t-x", team_name="X")

        m_frame = await asyncio.wait_for(member_q.get(), timeout=1)
        a_frame = await asyncio.wait_for(admin_q.get(), timeout=1)
        assert "event: team_profile_updated" in m_frame
        assert "event: team_profile_updated" in a_frame

    asyncio.run(go())
