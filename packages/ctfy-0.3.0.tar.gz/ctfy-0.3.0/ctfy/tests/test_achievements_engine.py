"""Unit tests for the achievement engine + individual rule predicates.

Each test drives the engine directly (bypassing the HTTP layer) so the
assertions focus on rule logic — the routes get their own coverage in
``test_achievements_routes.py``.
"""

from __future__ import annotations

import importlib
import time
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from ctfy.core.enums import InstanceStatus, PlatformEvent
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import InstanceState, SolveState, SubmissionState, TeamState
from ctfy.server.achievements.engine import evaluate
from ctfy.server.event_payloads import (
    FlagCorrectPayload,
    FlagWrongPayload,
    TeamRegisteredPayload,
)

# Force the rule modules to import so their @register decorators fire —
# the engine dispatches by event name so the rules must be registered
# before any test triggers evaluation.
importlib.import_module("ctfy.server.achievements.rules")


class TestProgressProviders:
    """Per-achievement (current, target) coverage. The provider hook
    itself is exercised by ``TestProgressHook`` below; here we pin
    each individual progress reading against a seeded backend."""

    def _seed_solves(self, app, team_id: str, n: int) -> None:
        for i in range(n):
            app.state_backend.add_solve(
                team_id,
                f"CHAL-{i:03d}",
                "main",
                SolveState(solved_at="2026-04-25T12:00:00Z"),
            )

    def _seed_submissions(self, app, team_id: str, n: int) -> None:
        for i in range(n):
            app.state_backend.add_submission(
                SubmissionState(
                    submission_id=f"sub-{team_id}-{i}",
                    team_id=team_id,
                    challenge_id="CHAL-001",
                    flag="x",
                    correct=False,
                    submitted_at="2026-04-25T12:00:00Z",
                )
            )

    def test_decathlete_progress_grows_with_solves(self, app):
        from ctfy.server.achievements.engine import compute_progress

        team = _register_team(app)
        assert compute_progress(app, team, "decathlete") == (0, 10)
        self._seed_solves(app, team.team_id, 3)
        assert compute_progress(app, team, "decathlete") == (3, 10)
        self._seed_solves(app, team.team_id, 12)  # +12 → total 15, but capped at 10
        cur, tgt = compute_progress(app, team, "decathlete")
        assert tgt == 10
        assert cur >= 10

    def test_centurion_progress_counts_submissions(self, app):
        from ctfy.server.achievements.engine import compute_progress

        team = _register_team(app)
        assert compute_progress(app, team, "centurion") == (0, 100)
        self._seed_submissions(app, team.team_id, 7)
        assert compute_progress(app, team, "centurion") == (7, 100)

    def test_completionist_progress_uses_live_catalog(self, app):
        from ctfy.core.challenge import ChallengeSpec
        from ctfy.server.achievements.engine import compute_progress

        team = _register_team(app)
        # Empty catalog → no progress (denominator would be 0).
        assert compute_progress(app, team, "completionist") is None
        # Seed two challenges into the spec reader.
        specs = [
            ChallengeSpec(
                id="A",
                name="A",
                description="x",
                difficulty="easy",
                tags=("misc",),
                flags=("main",),
            ),
            ChallengeSpec(
                id="B",
                name="B",
                description="x",
                difficulty="easy",
                tags=("misc",),
                flags=("main",),
            ),
        ]
        app.spec_reader.iter_specs = lambda **_kw: iter(specs)
        assert compute_progress(app, team, "completionist") == (0, 2)
        app.state_backend.add_solve(
            team.team_id, "A", "main", SolveState(solved_at="2026-04-25T12:00:00Z")
        )
        assert compute_progress(app, team, "completionist") == (1, 2)

    def test_sisyphus_progress_is_max_wrongs_on_a_single_challenge(self, app):
        """Progress reflects how close the team is on the single
        challenge they've fought hardest. 50 wrongs on the same
        challenge before the eventual solve unlocks the badge."""
        from ctfy.server.achievements.engine import compute_progress

        team = _register_team(app)
        # 3 wrongs on CHAL-A, 1 wrong on CHAL-B → max=3
        for cid, n in (("CHAL-A", 3), ("CHAL-B", 1)):
            for i in range(n):
                app.state_backend.add_submission(
                    SubmissionState(
                        submission_id=f"sub-{cid}-{i}",
                        team_id=team.team_id,
                        challenge_id=cid,
                        flag="x",
                        correct=False,
                        submitted_at="2026-04-25T12:00:00Z",
                    )
                )
        assert compute_progress(app, team, "sisyphus") == (3, 50)

    def test_unicorn_progress_counts_first_blood_solves(self, app):
        from ctfy.server.achievements.engine import compute_progress

        team = _register_team(app)
        # No solves → 0 first-bloods.
        assert compute_progress(app, team, "unicorn") == (0, 3)
        # First solve on CHAL-A → first-blood.
        app.state_backend.add_solve(
            team.team_id, "CHAL-A", "main", SolveState(solved_at="2026-04-25T12:00:00Z")
        )
        assert compute_progress(app, team, "unicorn") == (1, 3)


class TestProgressHook:
    """The progress hook lives next to the rule registry and lets each
    achievement opt in to publishing a (current, target) tuple so the
    UI can render a progress bar instead of just locked / unlocked.

    These tests pin the contract — the per-achievement implementations
    are covered separately."""

    def setup_method(self):
        # Snapshot the registry rather than clearing it — the production
        # rule modules register their own providers at import time, and
        # other test files (e.g. test_achievements_routes) rely on those
        # being intact. We restore on teardown so this class's stubs
        # don't leak past the test.
        from ctfy.server.achievements import engine

        self._saved_progress = dict(engine._PROGRESS)
        engine._PROGRESS.clear()

    def teardown_method(self):
        from ctfy.server.achievements import engine

        engine._PROGRESS.clear()
        engine._PROGRESS.update(self._saved_progress)

    def test_compute_progress_returns_none_when_no_provider(self, app):
        from ctfy.server.achievements.engine import compute_progress

        team = _register_team(app)
        assert compute_progress(app, team, "decathlete") is None

    def test_register_progress_exposes_provider_via_compute(self, app):
        from ctfy.server.achievements.engine import compute_progress, register_progress

        @register_progress("decathlete")
        def _fake(_app, _team):
            return (3, 10)

        team = _register_team(app)
        assert compute_progress(app, team, "decathlete") == (3, 10)

    def test_compute_progress_swallows_provider_exceptions(self, app):
        """A buggy provider must not break the route that calls it.
        The catalog page would otherwise 500 every render."""
        from ctfy.server.achievements.engine import compute_progress, register_progress

        @register_progress("decathlete")
        def _broken(_app, _team):
            raise RuntimeError("boom")

        team = _register_team(app)
        assert compute_progress(app, team, "decathlete") is None

    def test_register_progress_replaces_existing_provider(self, app):
        """Re-decorating wins — useful in tests + when a rule module is
        reloaded during dev."""
        from ctfy.server.achievements.engine import compute_progress, register_progress

        @register_progress("decathlete")
        def _v1(_app, _team):
            return (1, 10)

        @register_progress("decathlete")
        def _v2(_app, _team):
            return (2, 10)

        team = _register_team(app)
        assert compute_progress(app, team, "decathlete") == (2, 10)




@pytest.fixture
def app():
    """Lightweight app-like mock good enough for the engine.

    The engine only touches ``state_backend`` and (for completionist)
    ``spec_reader.iter_specs``; every other attribute stays a Mock so
    the emit_event recursion path works without a real FastAPI app.
    """
    app = MagicMock()
    app.state_backend = InMemoryBackend()
    app.spec_reader.iter_specs = lambda **_kw: iter(())  # empty catalog by default
    app.instance_archive = None
    return app


def _register_team(app, *, team_id="t1", name="Team 1") -> TeamState:
    team = TeamState(team_id=team_id, name=name, created_at="2025-01-01T00:00:00+00:00")
    app.state_backend.put_team(team_id, team)
    return team


class TestTeamRegistered:
    def test_welcome_aboard_unlocks(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.TEAM_REGISTERED,
            TeamRegisteredPayload(team_id=team.team_id, team_name=team.name),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        unlocked = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "welcome_aboard" in unlocked


class TestFirstBlood:
    def _solve(self, app, team_id, challenge_id, **overrides):
        data = {
            "team_id": team_id,
            "challenge_id": challenge_id,
            "solved_at": datetime.now(timezone.utc).isoformat(),
            "solve_time_s": 120.0,
            "attempts": 2,
        }
        data.update(overrides)
        app.state_backend.add_solve(team_id, challenge_id, data.get("flag_id", "main"), SolveState(**data))

    def test_first_solve_unlocks(self, app):
        team = _register_team(app)
        self._solve(app, team.team_id, "CHAL-A")
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "first_blood_team" in ids

    def test_second_solve_does_not_unlock(self, app):
        team = _register_team(app)
        self._solve(app, team.team_id, "CHAL-A")
        # First solve would have unlocked it; simulate by pre-granting.
        app.state_backend.grant_achievement(team.team_id, "first_blood_team", {})
        self._solve(app, team.team_id, "CHAL-B")
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-B"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        records = app.state_backend.list_achievements(team.team_id)
        # Exactly one first_blood_team record.
        assert sum(1 for r in records if r.achievement_id == "first_blood_team") == 1


class TestFastestMan:
    def test_first_global_solver_gets_it(self, app):
        team = _register_team(app)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(
                team_id=team.team_id,
                challenge_id="CHAL-A",
                solved_at=datetime.now(timezone.utc).isoformat(),
            ),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "fastest_man" in ids

    def test_second_solver_does_not(self, app):
        # Team A solved first.
        team_a = _register_team(app, team_id="ta", name="A")
        app.state_backend.add_solve(
            team_a.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team_a.team_id, challenge_id="CHAL-A"),
        )
        team_b = _register_team(app, team_id="tb", name="B")
        app.state_backend.add_solve(
            team_b.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team_b.team_id, challenge_id="CHAL-A"),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team_b.team_id, team_name="B", challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team_b.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team_b.team_id)}
        assert "fastest_man" not in ids


class TestTimeOfDay:
    def test_night_owl_in_hours(self, app):
        team = _register_team(app)
        # Force "now" to 3 AM UTC.
        fake_now = datetime(2025, 3, 1, 3, 0, tzinfo=timezone.utc)
        with patch("ctfy.server.achievements.rules.flag_correct_rules.datetime") as mock_dt:
            mock_dt.now.return_value = fake_now
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
            evaluate(
                app,
                PlatformEvent.FLAG_CORRECT,
                FlagCorrectPayload(
                    team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"
                ),
                actor_type="team",
                actor_team_id=team.team_id,
            )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "night_owl" in ids

    def test_night_owl_out_of_hours(self, app):
        team = _register_team(app)
        fake_now = datetime(2025, 3, 1, 15, 0, tzinfo=timezone.utc)  # 3 PM
        with patch("ctfy.server.achievements.rules.flag_correct_rules.datetime") as mock_dt:
            mock_dt.now.return_value = fake_now
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
            evaluate(
                app,
                PlatformEvent.FLAG_CORRECT,
                FlagCorrectPayload(
                    team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"
                ),
                actor_type="team",
                actor_team_id=team.team_id,
            )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "night_owl" not in ids


class TestSpeed:
    def test_flash_solver_under_60s(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(
                team_id=team.team_id,
                team_name=team.name,
                challenge_id="CHAL-A",
                solve_time_s=42.0,
            ),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "flash_solver" in ids

    def test_flash_solver_not_granted_slow(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(
                team_id=team.team_id,
                team_name=team.name,
                challenge_id="CHAL-A",
                solve_time_s=120.0,
            ),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "flash_solver" not in ids

    def test_kamikaze_on_correct(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(
                team_id=team.team_id,
                team_name=team.name,
                challenge_id="CHAL-A",
                solve_time_s=3.0,
            ),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "kamikaze" in ids


class TestLuckyGuesser:
    def test_first_attempt_solve(self, app):
        team = _register_team(app)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(
                team_id=team.team_id,
                challenge_id="CHAL-A",
                attempts=1,
            ),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "lucky_guesser" in ids

    def test_multiple_attempts_no_unlock(self, app):
        team = _register_team(app)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team.team_id, challenge_id="CHAL-A", attempts=5),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "lucky_guesser" not in ids


class TestSisyphus:
    def test_fifty_wrongs_then_solve_unlocks(self, app):
        team = _register_team(app)
        # Pretend they already wrong-flagged 50 times — the wrong-rule
        # would have bumped this counter in production.
        app.state_backend.bump_counter(team.team_id, "wrong_on:CHAL-A", 50)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team.team_id, challenge_id="CHAL-A", attempts=51),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "sisyphus" in ids

    def test_fewer_wrongs_no_unlock(self, app):
        team = _register_team(app)
        app.state_backend.bump_counter(team.team_id, "wrong_on:CHAL-A", 10)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team.team_id, challenge_id="CHAL-A", attempts=11),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "sisyphus" not in ids


class TestWrongFlagRules:
    def test_wrong_counter_bumps(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.FLAG_WRONG,
            FlagWrongPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        assert app.state_backend.get_counter(team.team_id, "wrong_on:CHAL-A") == 1

    def test_secret_handshake_flag(self, app):
        team = _register_team(app)
        app.state_backend.add_submission(
            SubmissionState(
                submission_id="s1",
                team_id=team.team_id,
                challenge_id="CHAL-A",
                claimed_flag="flag{hello_world}",
                correct=False,
            )
        )
        evaluate(
            app,
            PlatformEvent.FLAG_WRONG,
            FlagWrongPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "secret_handshake" in ids

    def test_kamikaze_wrong_within_window(self, app):
        team = _register_team(app)
        app.state_backend.put_instance(
            "inst-1",
            InstanceState(
                instance_id="inst-1",
                team_id=team.team_id,
                challenge_id="CHAL-A",
                status=InstanceStatus.READY,
                started_at=time.time() - 2.0,  # 2 seconds ago → inside 5s window
            ),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_WRONG,
            FlagWrongPayload(
                team_id=team.team_id,
                team_name=team.name,
                challenge_id="CHAL-A",
                instance_id="inst-1",
            ),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "kamikaze" in ids


class TestGlobalBehavior:
    def test_non_team_actor_skipped(self, app):
        _register_team(app)
        evaluate(
            app,
            PlatformEvent.TEAM_REGISTERED,
            TeamRegisteredPayload(team_id="t1", team_name="T"),
            actor_type="system",
            actor_team_id="t1",
        )
        assert app.state_backend.list_achievements("t1") == []

    def test_rule_crash_does_not_break_others(self, app):
        """A rule that raises must not stop subsequent rules from running."""
        from ctfy.server.achievements import engine as _engine

        team = _register_team(app)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team.team_id, challenge_id="CHAL-A"),
        )

        def _boom(*_args, **_kw):
            raise RuntimeError("boom")

        existing = list(_engine._RULES.get(PlatformEvent.FLAG_CORRECT, []))
        # Prepend the crasher so it's evaluated before the real rules —
        # exercises the "skip to next rule on exception" path.
        _engine._RULES[PlatformEvent.FLAG_CORRECT] = [_boom, *existing]
        try:
            evaluate(
                app,
                PlatformEvent.FLAG_CORRECT,
                FlagCorrectPayload(
                    team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"
                ),
                actor_type="team",
                actor_team_id=team.team_id,
            )
        finally:
            _engine._RULES[PlatformEvent.FLAG_CORRECT] = existing
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "first_blood_team" in ids

    def test_grant_is_idempotent(self, app):
        team = _register_team(app)
        for _ in range(3):
            evaluate(
                app,
                PlatformEvent.TEAM_REGISTERED,
                TeamRegisteredPayload(team_id=team.team_id, team_name=team.name),
                actor_type="team",
                actor_team_id=team.team_id,
            )
        records = [
            r
            for r in app.state_backend.list_achievements(team.team_id)
            if r.achievement_id == "welcome_aboard"
        ]
        assert len(records) == 1


class TestRapidFire:
    def _solved_state(self, tid, cid, *, solved_at: str = ""):
        return SolveState(
            team_id=tid,
            challenge_id=cid,
            solved_at=solved_at or datetime.now(timezone.utc).isoformat(),
        )

    def test_rapid_fire_three_solves_in_window(self, app):
        team = _register_team(app)
        # Three solves spaced 2 minutes apart → well inside 10-minute window.
        base = datetime(2025, 5, 1, 12, 0, tzinfo=timezone.utc)
        for i in range(3):
            ts = base.replace(minute=i * 2).isoformat()
            app.state_backend.add_solve(
                team.team_id, f"C{i}", "main", self._solved_state(team.team_id, f"C{i}", solved_at=ts),
                )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="C2"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "rapid_fire" in ids

    def test_rapid_fire_skipped_when_spread_out(self, app):
        team = _register_team(app)
        base = datetime(2025, 5, 1, 12, 0, tzinfo=timezone.utc)
        # 20 minutes between solves — outside the window.
        for i in range(3):
            ts = base.replace(hour=12 + i).isoformat()
            app.state_backend.add_solve(
                team.team_id, f"C{i}", "main", self._solved_state(team.team_id, f"C{i}", solved_at=ts),
                )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="C2"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "rapid_fire" not in ids
