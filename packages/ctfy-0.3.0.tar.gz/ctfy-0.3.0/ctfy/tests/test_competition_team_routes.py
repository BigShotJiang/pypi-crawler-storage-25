"""TDD: per-competition team registration routes.

Phase 3a-1 of the per-comp team refactor — the in-page registration
flow on ``/competitions/{id}``. Three modes a user can land on a
competition team:

* ``POST /competitions/{id}/teams`` body ``{"mode": "solo"}`` —
  mints a 1-person team named after the user.
* ``POST /competitions/{id}/teams`` body
  ``{"mode": "create", "name": "...", "description": "..."}`` —
  mints a multi-user team, caller becomes captain.
* ``POST /competitions/{id}/teams/redeem`` body ``{"code": "..."}``
  — joins an existing team for this comp via an invite the captain
  minted.

All three are idempotent / race-safe at the backend layer (Phase 2b
+ 2c). The routes are thin — they translate body shape + error
codes from the backend's typed status strings.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import CompetitionState, TeamInviteState
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team, mint_user


@pytest.fixture
def world():
    """Throwaway server + a single registered competition the tests
    can register against."""
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    backend.put_competition(
        CompetitionState(
            competition_id="spring-ctf",
            title="Spring CTF 2026",
            starts_at="",
            ends_at="",
            challenge_ids=[],
            created_at="2026-01-01T00:00:00Z",
        )
    )
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    yield TestClient(app), backend


# ---------------------------------------------------------------------------
# Solo registration
# ---------------------------------------------------------------------------


class TestSoloRegistration:
    def test_solo_mode_mints_one_person_team(self, world):
        client, backend = world
        u = mint_team(backend, name="Alice", email="a@x")
        r = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "solo"},
            headers=u.headers,
        )
        assert r.status_code == 201, r.text
        body = r.json()
        assert body["captain_user_id"] == u.user_id
        assert body["competition_id"] == "spring-ctf"
        assert body["member_count"] == 1
        # Membership written.
        m = backend.get_membership_for_competition(u.user_id, "spring-ctf")
        assert m is not None
        assert m.team_id == body["team_id"]
        assert m.joined_via == "solo"

    def test_solo_mode_idempotent_returns_existing_team(self, world):
        """Double-clicking the Solo button must not mint two teams."""
        client, backend = world
        u = mint_team(backend, name="Alice", email="a@x")
        first = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "solo"},
            headers=u.headers,
        ).json()
        second = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "solo"},
            headers=u.headers,
        ).json()
        assert first["team_id"] == second["team_id"]

    def test_unknown_competition_404(self, world):
        client, backend = world
        u = mint_team(backend, name="Alice", email="a@x")
        r = client.post(
            "/api/v1/competitions/no-such-comp/teams",
            json={"mode": "solo"},
            headers=u.headers,
        )
        assert r.status_code == 404

    def test_unauth_rejected(self, world):
        client, _ = world
        r = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "solo"},
        )
        assert r.status_code in (401, 403)


# ---------------------------------------------------------------------------
# Create (named multi-user) registration
# ---------------------------------------------------------------------------


class TestCreateRegistration:
    def test_create_mode_mints_named_team_with_description(self, world):
        client, backend = world
        u = mint_team(backend, name="Captain", email="c@x")
        r = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={
                "mode": "create",
                "name": "Pwners",
                "description": "go brrr",
            },
            headers=u.headers,
        )
        assert r.status_code == 201, r.text
        body = r.json()
        assert body["name"] == "Pwners"
        assert body["description"] == "go brrr"
        assert body["captain_user_id"] == u.user_id
        m = backend.get_membership_for_competition(u.user_id, "spring-ctf")
        assert m.joined_via == "create"

    def test_create_mode_requires_name(self, world):
        client, backend = world
        u = mint_team(backend, name="Captain", email="c@x")
        r = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create"},  # missing name
            headers=u.headers,
        )
        assert r.status_code == 422

    def test_already_registered_409(self, world):
        """User already on a team for this comp can't double-register
        via the create path (would silently mint a second team)."""
        client, backend = world
        u = mint_team(backend, name="Captain", email="c@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "solo"},
            headers=u.headers,
        )
        r = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create", "name": "Pwners"},
            headers=u.headers,
        )
        assert r.status_code == 409


# ---------------------------------------------------------------------------
# Redeem invite
# ---------------------------------------------------------------------------


class TestRedeemRegistration:
    def _seed_team_with_invite(self, backend, *, code: str = "JOIN1234"):
        captain = mint_user(backend, name="Cap", email="cap@x")
        team = backend.create_team_for_competition(
            user_id=captain.user_id,
            competition_id="spring-ctf",
            team_name="Pwners",
            now_iso="2026-01-01T00:00:00Z",
        )
        backend.put_team_invite(
            TeamInviteState(
                invite_id="inv1",
                team_id=team.team_id,
                code=code,
                created_by_user_id=captain.user_id,
                created_at="2026-01-01T00:00:00Z",
                max_uses=2,
                competition_id="spring-ctf",
            )
        )
        return captain, team

    def test_redeem_joins_target_team(self, world):
        client, backend = world
        _, team = self._seed_team_with_invite(backend)
        joiner = mint_team(backend, name="Joiner", email="j@x")
        r = client.post(
            "/api/v1/competitions/spring-ctf/teams/redeem",
            json={"code": "JOIN1234"},
            headers=joiner.headers,
        )
        assert r.status_code == 200, r.text
        assert r.json()["team_id"] == team.team_id
        m = backend.get_membership_for_competition(joiner.user_id, "spring-ctf")
        assert m is not None and m.team_id == team.team_id

    def test_unknown_code_404(self, world):
        client, backend = world
        u = mint_user(backend, name="u", email="u@x")
        r = client.post(
            "/api/v1/competitions/spring-ctf/teams/redeem",
            json={"code": "NOPE"},
            headers=u.headers,
        )
        assert r.status_code == 404

    def test_wrong_competition_409(self, world):
        """Code minted for spring-ctf cannot be redeemed against
        another comp."""
        client, backend = world
        backend.put_competition(
            CompetitionState(
                competition_id="summer-ctf",
                title="Summer CTF",
                starts_at="",
                ends_at="",
                challenge_ids=[],
                created_at="",
            )
        )
        self._seed_team_with_invite(backend)
        u = mint_user(backend, name="u", email="u@x")
        r = client.post(
            "/api/v1/competitions/summer-ctf/teams/redeem",
            json={"code": "JOIN1234"},
            headers=u.headers,
        )
        assert r.status_code == 409
        body = r.json()
        # Typed body so the UI can show "this code is for a
        # different competition" instead of a generic error.
        assert body["detail"]["error"] == "wrong_competition"

    def test_already_member_409(self, world):
        """User already on a team for this comp gets 409, not a
        silent move — they need to leave first."""
        client, backend = world
        self._seed_team_with_invite(backend)
        u = mint_user(backend, name="u", email="u@x")
        # Solo first.
        client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "solo"},
            headers=u.headers,
        )
        # Then try to redeem — rejected.
        r = client.post(
            "/api/v1/competitions/spring-ctf/teams/redeem",
            json={"code": "JOIN1234"},
            headers=u.headers,
        )
        assert r.status_code == 409
        assert r.json()["detail"]["error"] == "already_member"


# ---------------------------------------------------------------------------
# Captain invite CRUD (per-comp)
# ---------------------------------------------------------------------------


class TestInviteCRUD:
    """Captain mints / lists / revokes invites for their team in a
    given competition. URL is ``/competitions/{id}/invites`` — no
    explicit team_id (the team is implicit from the caller's
    membership in that comp)."""

    def _captain_with_team(self, client, backend):
        captain = mint_user(backend, name="Cap", email="cap@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create", "name": "Pwners"},
            headers=captain.headers,
        )
        return captain

    def test_captain_mints_invite(self, world):
        client, backend = world
        captain = self._captain_with_team(client, backend)
        r = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={"max_uses": 3, "ttl_seconds": 3600},
            headers=captain.headers,
        )
        assert r.status_code == 201, r.text
        body = r.json()
        assert body["code"]
        assert body["max_uses"] == 3
        assert body["use_count"] == 0
        assert body["active"] is True
        assert body["competition_id"] == "spring-ctf"
        # Persisted with the right competition scope.
        inv = backend.get_team_invite_by_code(body["code"])
        assert inv is not None
        assert inv.competition_id == "spring-ctf"

    def test_non_captain_cannot_mint(self, world):
        """Member of the team but not captain → 403."""
        client, backend = world
        captain = self._captain_with_team(client, backend)
        # Captain mints invite; second user redeems → joins the team.
        inv = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={},
            headers=captain.headers,
        ).json()
        member = mint_user(backend, name="Mem", email="m@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams/redeem",
            json={"code": inv["code"]},
            headers=member.headers,
        )
        r = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={},
            headers=member.headers,
        )
        assert r.status_code == 403

    def test_not_registered_403(self, world):
        """User not on any team for this comp → 403 (the typed body
        from ``get_current_team_for_competition``)."""
        client, backend = world
        u = mint_user(backend, name="u", email="u@x")
        r = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={},
            headers=u.headers,
        )
        assert r.status_code == 403
        assert r.json()["detail"]["error"] == "not_registered"

    def test_captain_lists_invites(self, world):
        client, backend = world
        captain = self._captain_with_team(client, backend)
        for _ in range(3):
            client.post(
                "/api/v1/competitions/spring-ctf/invites",
                json={},
                headers=captain.headers,
            )
        r = client.get(
            "/api/v1/competitions/spring-ctf/invites",
            headers=captain.headers,
        )
        assert r.status_code == 200
        items = r.json()["items"]
        assert len(items) == 3
        assert all(i["competition_id"] == "spring-ctf" for i in items)

    def test_captain_revokes_invite(self, world):
        client, backend = world
        captain = self._captain_with_team(client, backend)
        inv = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={},
            headers=captain.headers,
        ).json()
        r = client.delete(
            f"/api/v1/competitions/spring-ctf/invites/{inv['invite_id']}",
            headers=captain.headers,
        )
        assert r.status_code == 200
        assert r.json()["status"] == "revoked"
        # Subsequent redeem fails.
        joiner = mint_team(backend, name="Joiner", email="j@x")
        r2 = client.post(
            "/api/v1/competitions/spring-ctf/teams/redeem",
            json={"code": inv["code"]},
            headers=joiner.headers,
        )
        assert r2.status_code in (404, 409)

    def test_revoke_other_teams_invite_404(self, world):
        """Captain B in spring-ctf can't revoke captain A's invite —
        the invite_id belongs to A's team, B's auth dep resolves to
        B's team, and the cross-team invite-id lookup must 404."""
        client, backend = world
        cap_a = self._captain_with_team(client, backend)
        # Different team in same comp, different captain.
        cap_b = mint_team(backend, name="CapB", email="b@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create", "name": "Bee"},
            headers=cap_b.headers,
        )
        a_invite = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={},
            headers=cap_a.headers,
        ).json()
        r = client.delete(
            f"/api/v1/competitions/spring-ctf/invites/{a_invite['invite_id']}",
            headers=cap_b.headers,
        )
        assert r.status_code == 404


# ---------------------------------------------------------------------------
# Captain CRUD: leave / kick / rename
# ---------------------------------------------------------------------------


class TestLeaveTeam:
    def _setup_team_with_member(self, client, backend):
        captain = mint_user(backend, name="Cap", email="cap@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create", "name": "Pwners"},
            headers=captain.headers,
        )
        inv = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={},
            headers=captain.headers,
        ).json()
        member = mint_user(backend, name="Mem", email="m@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams/redeem",
            json={"code": inv["code"]},
            headers=member.headers,
        )
        return captain, member

    def test_lone_member_leaving_deletes_team(self, world):
        client, backend = world
        u = mint_team(backend, name="Solo", email="s@x")
        team = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "solo"},
            headers=u.headers,
        ).json()
        r = client.post(
            "/api/v1/competitions/spring-ctf/team/leave",
            headers=u.headers,
        )
        assert r.status_code == 204
        # User no longer registered.
        assert backend.get_membership_for_competition(u.user_id, "spring-ctf") is None
        # Team gone too.
        assert backend.get_team(team["team_id"]) is None

    def test_member_leaving_keeps_team(self, world):
        client, backend = world
        captain, member = self._setup_team_with_member(client, backend)
        team_id = backend.get_membership_for_competition(
            captain.user_id, "spring-ctf"
        ).team_id
        r = client.post(
            "/api/v1/competitions/spring-ctf/team/leave",
            headers=member.headers,
        )
        assert r.status_code == 204
        # Member's membership gone.
        assert backend.get_membership_for_competition(member.user_id, "spring-ctf") is None
        # Captain still on the team.
        assert backend.get_team(team_id) is not None
        cap_m = backend.get_membership_for_competition(captain.user_id, "spring-ctf")
        assert cap_m is not None and cap_m.team_id == team_id

    def test_captain_leaving_with_others_transfers_captaincy(self, world):
        client, backend = world
        captain, member = self._setup_team_with_member(client, backend)
        team_id = backend.get_membership_for_competition(
            captain.user_id, "spring-ctf"
        ).team_id
        r = client.post(
            "/api/v1/competitions/spring-ctf/team/leave",
            headers=captain.headers,
        )
        assert r.status_code == 204
        # Team still exists; captaincy moved to the (now lone) member.
        team = backend.get_team(team_id)
        assert team is not None
        assert team.captain_user_id == member.user_id

    def test_not_registered_403(self, world):
        client, backend = world
        u = mint_team(backend, name="Solo", email="s@x")
        r = client.post(
            "/api/v1/competitions/spring-ctf/team/leave",
            headers=u.headers,
        )
        assert r.status_code == 403


class TestKickMember:
    def _setup_team_with_member(self, client, backend):
        captain = mint_user(backend, name="Cap", email="cap@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create", "name": "Pwners"},
            headers=captain.headers,
        )
        inv = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={},
            headers=captain.headers,
        ).json()
        member = mint_user(backend, name="Mem", email="m@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams/redeem",
            json={"code": inv["code"]},
            headers=member.headers,
        )
        return captain, member

    def test_captain_kicks_member(self, world):
        client, backend = world
        captain, member = self._setup_team_with_member(client, backend)
        r = client.delete(
            f"/api/v1/competitions/spring-ctf/team/members/{member.user_id}",
            headers=captain.headers,
        )
        assert r.status_code == 204
        # Kicked user is no longer registered for this comp.
        assert backend.get_membership_for_competition(member.user_id, "spring-ctf") is None

    def test_non_captain_cannot_kick(self, world):
        client, backend = world
        captain, member = self._setup_team_with_member(client, backend)
        r = client.delete(
            f"/api/v1/competitions/spring-ctf/team/members/{captain.user_id}",
            headers=member.headers,
        )
        assert r.status_code == 403

    def test_captain_cannot_kick_self(self, world):
        """Captain self-kick is a 400 — they leave via the dedicated
        leave route which has the captaincy-transfer path."""
        client, backend = world
        captain, _ = self._setup_team_with_member(client, backend)
        r = client.delete(
            f"/api/v1/competitions/spring-ctf/team/members/{captain.user_id}",
            headers=captain.headers,
        )
        assert r.status_code == 400

    def test_kick_unknown_user_404(self, world):
        client, backend = world
        captain, _ = self._setup_team_with_member(client, backend)
        r = client.delete(
            "/api/v1/competitions/spring-ctf/team/members/no-such-user",
            headers=captain.headers,
        )
        assert r.status_code == 404

    def test_kick_non_member_404(self, world):
        """Target user exists but isn't on the captain's team."""
        client, backend = world
        captain, _ = self._setup_team_with_member(client, backend)
        outsider = mint_team(backend, name="Outsider", email="o@x")
        r = client.delete(
            f"/api/v1/competitions/spring-ctf/team/members/{outsider.user_id}",
            headers=captain.headers,
        )
        assert r.status_code == 404


class TestRenameTeam:
    def test_captain_can_rename(self, world):
        client, backend = world
        captain = mint_user(backend, name="Cap", email="cap@x")
        team = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create", "name": "Old Name"},
            headers=captain.headers,
        ).json()
        r = client.patch(
            "/api/v1/competitions/spring-ctf/team",
            json={"name": "New Name", "description": "fresh desc"},
            headers=captain.headers,
        )
        assert r.status_code == 200, r.text
        assert r.json()["name"] == "New Name"
        assert r.json()["description"] == "fresh desc"
        # Persisted.
        team_after = backend.get_team(team["team_id"])
        assert team_after.name == "New Name"
        assert team_after.description == "fresh desc"

    def test_non_captain_cannot_rename(self, world):
        client, backend = world
        captain = mint_user(backend, name="Cap", email="cap@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create", "name": "Old"},
            headers=captain.headers,
        )
        inv = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={},
            headers=captain.headers,
        ).json()
        member = mint_user(backend, name="Mem", email="m@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams/redeem",
            json={"code": inv["code"]},
            headers=member.headers,
        )
        r = client.patch(
            "/api/v1/competitions/spring-ctf/team",
            json={"name": "Hijack"},
            headers=member.headers,
        )
        assert r.status_code == 403

    def test_partial_update_keeps_other_fields(self, world):
        client, backend = world
        captain = mint_user(backend, name="Cap", email="cap@x")
        team = client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create", "name": "Old", "description": "keep"},
            headers=captain.headers,
        ).json()
        r = client.patch(
            "/api/v1/competitions/spring-ctf/team",
            json={"name": "New"},
            headers=captain.headers,
        )
        assert r.status_code == 200
        assert r.json()["name"] == "New"
        assert r.json()["description"] == "keep"


# ---------------------------------------------------------------------------
# /me carries the per-comp memberships
# ---------------------------------------------------------------------------


class TestMeCompetitionTeams:
    """Frontend hydrates ``AuthContext.competitionTeams`` from
    ``/me``'s new ``competition_teams`` field — no N+1 fetches."""

    def test_no_competition_teams_when_unregistered(self, world):
        client, backend = world
        u = mint_user(backend, name="u", email="u@x")
        r = client.get("/api/v1/me", headers=u.headers)
        assert r.status_code == 200
        assert r.json()["competition_teams"] == []

    def test_competition_teams_listed_with_role(self, world):
        client, backend = world
        # Captain registers for spring as captain of a multi-user team.
        captain = mint_user(backend, name="Cap", email="cap@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "create", "name": "Pwners"},
            headers=captain.headers,
        )
        # Member joins via invite (now they have a per-comp membership
        # as a non-captain).
        inv = client.post(
            "/api/v1/competitions/spring-ctf/invites",
            json={},
            headers=captain.headers,
        ).json()
        member = mint_user(backend, name="Mem", email="m@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams/redeem",
            json={"code": inv["code"]},
            headers=member.headers,
        )
        # Captain's /me row.
        cap_me = client.get("/api/v1/me", headers=captain.headers).json()
        assert len(cap_me["competition_teams"]) == 1
        cap_row = cap_me["competition_teams"][0]
        assert cap_row["competition_id"] == "spring-ctf"
        assert cap_row["team_name"] == "Pwners"
        assert cap_row["role"] == "captain"
        # Member's /me row.
        mem_me = client.get("/api/v1/me", headers=member.headers).json()
        assert len(mem_me["competition_teams"]) == 1
        assert mem_me["competition_teams"][0]["role"] == "member"

    def test_user_on_multiple_competitions_lists_all(self, world):
        client, backend = world
        # Add a second comp so the user can register for both.
        backend.put_competition(
            CompetitionState(
                competition_id="summer-ctf",
                title="Summer CTF",
                challenge_ids=[],
                created_at="",
            )
        )
        u = mint_user(backend, name="Multi", email="m@x")
        client.post(
            "/api/v1/competitions/spring-ctf/teams",
            json={"mode": "solo"},
            headers=u.headers,
        )
        client.post(
            "/api/v1/competitions/summer-ctf/teams",
            json={"mode": "solo"},
            headers=u.headers,
        )
        me = client.get("/api/v1/me", headers=u.headers).json()
        comps = {row["competition_id"] for row in me["competition_teams"]}
        assert comps == {"spring-ctf", "summer-ctf"}
