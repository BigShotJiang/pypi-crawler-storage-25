"""Unit tests for ``InstanceInfo`` projection — vars filtering + description.

These pin the public/private boundary: the agent-facing ``InstanceInfo``
exposes only ``public_vars`` (a strict subset of the canonical
``InstanceState.vars`` keyed by ids declared in ``spec.public_vars``) and
renders ``description`` with per-instance ``${VAR_X}`` substitution.
Private vars (declared in ``spec.vars``) are intentionally not part of
the contract — they exist on disk and inside containers, but the
agent must discover them from HTTP behaviour.
"""

from __future__ import annotations

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.enums import Difficulty, InstanceStatus
from ctfy.core.state.models import InstanceState
from ctfy.server.routes.instances import _to_info


def _spec_dict(**overrides) -> dict:
    base = {
        "id": "CTFARENA-T1",
        "name": "Test",
        "description": "static",
        "difficulty": Difficulty.EASY,
        "tags": ["t"],
        "flags": ["main"],
        "vars": [],
        "public_vars": [],
    }
    base.update(overrides)
    return ChallengeSpec(**base).model_dump()


def test_public_vars_exposed_and_private_vars_hidden():
    spec = _spec_dict(
        vars=["secret_param"],
        public_vars=["admin_user"],
    )
    inst = InstanceState(
        instance_id="i1",
        challenge_id="CTFARENA-T1",
        spec=spec,
        status=InstanceStatus.READY,
        flags={"main": "FLAG{x}"},
        vars={"secret_param": "hidden01", "admin_user": "alice123"},
    )
    info = _to_info(inst)
    assert info.public_vars == {"admin_user": "alice123"}
    # Private var must not leak via the dict.
    assert "secret_param" not in info.public_vars


def test_description_substitutes_public_var():
    spec = _spec_dict(
        description="Login as ${VAR_ADMIN_USER}.",
        public_vars=["admin_user"],
    )
    inst = InstanceState(
        instance_id="i2",
        challenge_id="CTFARENA-T2",
        spec=spec,
        status=InstanceStatus.READY,
        flags={"main": "FLAG{x}"},
        vars={"admin_user": "alice123"},
    )
    info = _to_info(inst)
    assert info.description == "Login as alice123."


def test_description_passthrough_when_no_public_vars():
    spec = _spec_dict(description="A static prompt.")
    inst = InstanceState(
        instance_id="i3",
        challenge_id="CTFARENA-T3",
        spec=spec,
        status=InstanceStatus.READY,
        flags={"main": "FLAG{x}"},
    )
    info = _to_info(inst)
    assert info.description == "A static prompt."
    assert info.public_vars == {}


def test_legacy_state_without_spec_is_tolerated():
    # Pre-vars rows have an empty spec dict / empty vars dict. The
    # projection should not blow up — it returns an empty mapping +
    # empty description rather than raising.
    inst = InstanceState(
        instance_id="legacy",
        challenge_id="OLD-001",
        status=InstanceStatus.READY,
        flags={"main": "FLAG{x}"},
    )
    info = _to_info(inst)
    assert info.public_vars == {}
    assert info.description == ""
