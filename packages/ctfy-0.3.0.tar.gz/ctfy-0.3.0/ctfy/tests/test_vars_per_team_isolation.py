"""Per-team var isolation — end-to-end through the FastAPI route layer.

The vars mechanism's load-bearing property is that two teams launching
the same challenge get *different* random tokens, so an agent that
memorised team A's path can't replay it against team B. This test
exercises the whole pipeline: ``POST /instances`` mints fresh values,
the platform persists them on ``InstanceState``, and ``GET /instances``
projects them onto ``InstanceInfo`` — public_vars only, never private.
"""

from __future__ import annotations

from contextlib import contextmanager
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.enums import Difficulty
from ctfy.core.state import InMemoryBackend
from ctfy.tests.conftest import (
    build_spec,
    fake_node_context,
    make_mock_challenge_manager,
    mint_team,
    start_instance_and_wait,
)


CHALLENGE_ID = "VAR-001"


@pytest.fixture
def vars_client():
    """A TestClient wired with a single challenge declaring both vars
    and public_vars. Exercises the full mint / inject / project loop."""
    spec = build_spec(
        CHALLENGE_ID,
        name="Vars Demo",
        description="Sign in as ${VAR_ADMIN_USER} to begin.",
        difficulty=Difficulty.EASY,
        tags=["test"],
        vars=["admin_path"],
        public_vars=["admin_user"],
    )
    mgr = make_mock_challenge_manager(
        challenge_specs=[spec],
        auto_generate_specs=False,
    )
    backend = InMemoryBackend()

    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        yield TestClient(app), backend


@contextmanager
def _two_teams(client):
    backend = client.app.state.ctfy.state_backend
    a = mint_team(backend, name="Alpha", email="alpha@example.test")
    b = mint_team(backend, name="Bravo", email="bravo@example.test")
    yield a, b


def _instance_state(backend, instance_id):
    inst = backend.get_instance(instance_id)
    assert inst is not None, f"missing InstanceState for {instance_id}"
    return inst


def test_two_teams_get_different_var_values(vars_client):
    """Each team's instance has its own freshly minted vars dict."""
    client, backend = vars_client
    with _two_teams(client) as (a, b):
        a_id = start_instance_and_wait(client, CHALLENGE_ID, headers=a.headers)
        b_id = start_instance_and_wait(client, CHALLENGE_ID, headers=b.headers)

        a_state = _instance_state(backend, a_id)
        b_state = _instance_state(backend, b_id)

        # Both instances carry the declared var ids…
        for state in (a_state, b_state):
            assert set(state.vars.keys()) == {"admin_path", "admin_user"}
            for value in state.vars.values():
                assert len(value) == 8 and value.isalnum()

        # …with values that diverge per instance. Birthday-paradox
        # collision is theoretically possible at 36 bits but here we
        # mint fresh values per call, so equality would indicate the
        # mint pipeline is broken (e.g. caching, fixed seed).
        assert a_state.vars["admin_path"] != b_state.vars["admin_path"]
        assert a_state.vars["admin_user"] != b_state.vars["admin_user"]


def test_get_instances_returns_only_public_vars(vars_client):
    """``InstanceInfo.public_vars`` carries the public subset; the
    private ``admin_path`` is never exposed even though it lives on the
    same ``InstanceState.vars`` dict."""
    client, backend = vars_client
    with _two_teams(client) as (a, _):
        a_id = start_instance_and_wait(client, CHALLENGE_ID, headers=a.headers)
        items = client.get("/api/v1/instances", headers=a.headers).json()["items"]
        rows = [i for i in items if i["instance_id"] == a_id]
        assert len(rows) == 1
        row = rows[0]

        # Public_vars carries admin_user only.
        assert set(row["public_vars"].keys()) == {"admin_user"}
        a_state = _instance_state(backend, a_id)
        assert row["public_vars"]["admin_user"] == a_state.vars["admin_user"]
        # Private var must never appear in the public surface.
        assert "admin_path" not in row["public_vars"]
        # And not as a sneaky raw 'vars' field either.
        assert "vars" not in row


def test_description_is_rendered_per_instance(vars_client):
    """``${VAR_ADMIN_USER}`` resolves to this team's minted value, not a
    static placeholder. Two teams see two different rendered strings."""
    client, backend = vars_client
    with _two_teams(client) as (a, b):
        a_id = start_instance_and_wait(client, CHALLENGE_ID, headers=a.headers)
        b_id = start_instance_and_wait(client, CHALLENGE_ID, headers=b.headers)

        def _desc(headers, instance_id):
            items = client.get("/api/v1/instances", headers=headers).json()["items"]
            for item in items:
                if item["instance_id"] == instance_id:
                    return item["description"]
            raise AssertionError("instance not in listing")

        a_desc = _desc(a.headers, a_id)
        b_desc = _desc(b.headers, b_id)

        a_user = backend.get_instance(a_id).vars["admin_user"]
        b_user = backend.get_instance(b_id).vars["admin_user"]

        assert a_desc == f"Sign in as {a_user} to begin."
        assert b_desc == f"Sign in as {b_user} to begin."
        assert a_desc != b_desc
        # The raw template is no longer visible to either agent.
        assert "${VAR_ADMIN_USER}" not in a_desc
        assert "${VAR_ADMIN_USER}" not in b_desc


def test_global_challenge_listing_returns_raw_template(vars_client):
    """``GET /challenges`` is global and not team-scoped, so it must
    not substitute per-instance values into the description (whose
    instance would it pick?). The agent learns its specific values
    only after launching."""
    client, _ = vars_client
    with _two_teams(client) as (a, _):
        rows = client.get("/api/v1/challenges").json()["items"]
        match = [r for r in rows if r["id"] == CHALLENGE_ID]
        assert len(match) == 1
        assert match[0]["description"] == "Sign in as ${VAR_ADMIN_USER} to begin."
