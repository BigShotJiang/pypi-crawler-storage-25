"""Tests for instance archival (SQLite + InMemory + filesystem + hooks)."""

from __future__ import annotations

import time
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.enums import InstanceStatus
from ctfy.core.state import InMemoryBackend, SQLiteBackend
from ctfy.core.state.models import InstanceRecord
from ctfy.server.instance_archive import InstanceArchive

# ---------------------------------------------------------------------------
# DB archive — parity between in-memory + sqlite backends
# ---------------------------------------------------------------------------


def _seed(backend, instance_id: str, **overrides) -> InstanceRecord:
    rec = InstanceRecord(
        instance_id=instance_id,
        challenge_id=overrides.pop("challenge_id", "ch1"),
        team_id=overrides.pop("team_id", "team-a"),
        node_id=overrides.pop("node_id", "node-1"),
        status=overrides.pop("status", InstanceStatus.STOPPED),
        stop_reason=overrides.pop("stop_reason", "user"),
        started_at=overrides.pop("started_at", time.time() - 60),
        stopped_at=overrides.pop("stopped_at", time.time()),
        duration_s=overrides.pop("duration_s", 60.0),
        **overrides,
    )
    backend.archive_instance(rec)
    return rec


@pytest.mark.parametrize(
    "make_backend",
    [
        lambda tmp: InMemoryBackend(),
        lambda tmp: SQLiteBackend(str(tmp / "state.sqlite3")),
    ],
    ids=["memory", "sqlite"],
)
def test_archive_roundtrip(tmp_path, make_backend):
    be = make_backend(tmp_path)
    _seed(be, "inst-1", team_id="t1", challenge_id="c1")
    got = be.get_instance_record("inst-1")
    assert got is not None and got.instance_id == "inst-1"
    assert got.team_id == "t1"
    assert got.duration_s == 60.0


@pytest.mark.parametrize(
    "make_backend",
    [
        lambda tmp: InMemoryBackend(),
        lambda tmp: SQLiteBackend(str(tmp / "state.sqlite3")),
    ],
    ids=["memory", "sqlite"],
)
def test_archive_filters(tmp_path, make_backend):
    be = make_backend(tmp_path)
    _seed(be, "i1", team_id="t1", challenge_id="c1", node_id="n1")
    _seed(be, "i2", team_id="t2", challenge_id="c1", node_id="n2")
    _seed(be, "i3", team_id="t1", challenge_id="c2", node_id="n1")

    assert be.count_instance_records() == 3
    assert be.count_instance_records(team_id="t1") == 2
    assert be.count_instance_records(challenge_id="c1") == 2
    assert be.count_instance_records(node_id="n2") == 1
    assert be.count_instance_records(team_id="t1", challenge_id="c2") == 1
    assert be.count_instance_records(team_id="nope") == 0

    page1 = be.list_instance_records(team_id="t1", offset=0, limit=1)
    assert len(page1) == 1
    page2 = be.list_instance_records(team_id="t1", offset=1, limit=1)
    assert len(page2) == 1
    assert page1[0].instance_id != page2[0].instance_id


@pytest.mark.parametrize(
    "make_backend",
    [
        lambda tmp: InMemoryBackend(),
        lambda tmp: SQLiteBackend(str(tmp / "state.sqlite3")),
    ],
    ids=["memory", "sqlite"],
)
def test_archive_replace_is_idempotent(tmp_path, make_backend):
    be = make_backend(tmp_path)
    _seed(be, "inst-1", stop_reason="user")
    _seed(be, "inst-1", stop_reason="ttl_expired")  # second archive wins
    assert be.count_instance_records() == 1
    assert be.get_instance_record("inst-1").stop_reason == "ttl_expired"


def test_sqlite_archive_survives_restart(tmp_path):
    db = str(tmp_path / "state.sqlite3")
    be = SQLiteBackend(db)
    _seed(be, "inst-r", team_id="t1")
    # Simulate a process restart.
    be2 = SQLiteBackend(db)
    got = be2.get_instance_record("inst-r")
    assert got is not None
    assert got.instance_id == "inst-r"
    assert got.team_id == "t1"


# ---------------------------------------------------------------------------
# requested_at / ready_at — used by the admin per-challenge launch-duration
# panel. Captures the time the platform accepted POST /instances and the
# moment the node reported READY; launch_duration = ready_at - requested_at.
# ---------------------------------------------------------------------------


def test_instance_record_has_requested_and_ready_timestamps_with_default_zero():
    """Both fields default to 0.0 so legacy archive paths that don't set
    them still validate (preserves backward compat with old rows)."""
    rec = InstanceRecord(instance_id="i", status="STOPPED")
    assert rec.requested_at == 0.0
    assert rec.ready_at == 0.0


def test_instance_state_has_requested_and_ready_timestamps_with_default_zero():
    from ctfy.core.state.models import InstanceState

    inst = InstanceState(instance_id="i", challenge_id="c1", team_id="t1")
    assert inst.requested_at == 0.0
    assert inst.ready_at == 0.0


@pytest.mark.parametrize(
    "make_backend",
    [
        lambda tmp: InMemoryBackend(),
        lambda tmp: SQLiteBackend(str(tmp / "state.sqlite3")),
    ],
    ids=["memory", "sqlite"],
)
def test_archive_roundtrips_requested_and_ready_at(tmp_path, make_backend):
    be = make_backend(tmp_path)
    _seed(
        be,
        "inst-rd",
        requested_at=1700000000.5,
        ready_at=1700000003.5,
    )
    got = be.get_instance_record("inst-rd")
    assert got is not None
    assert got.requested_at == pytest.approx(1700000000.5)
    assert got.ready_at == pytest.approx(1700000003.5)


def test_sqlite_archive_old_row_without_requested_at_loads_with_default(tmp_path):
    """Old DB rows whose JSON blob predates these fields must still load —
    pydantic should fill them with the default 0.0 rather than failing
    validation."""
    import json

    db = str(tmp_path / "state.sqlite3")
    be = SQLiteBackend(db)
    # Hand-craft a legacy row: JSON missing requested_at / ready_at entirely.
    legacy_data = {
        "instance_id": "legacy-1",
        "team_id": "t1",
        "challenge_id": "c1",
        "node_id": "n1",
        "status": "STOPPED",
        "stop_reason": "user",
        "started_at": 1700000000.0,
        "stopped_at": 1700000060.0,
        "duration_s": 60.0,
    }
    be._conn.execute(
        """
        INSERT INTO instance_records
            (instance_id, team_id, challenge_id, node_id, status,
             started_at, stopped_at, data)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "legacy-1", "t1", "c1", "n1", "STOPPED",
            1700000000.0, 1700000060.0, json.dumps(legacy_data),
        ),
    )
    be._conn.commit()

    got = be.get_instance_record("legacy-1")
    assert got is not None
    assert got.requested_at == 0.0
    assert got.ready_at == 0.0


# ---------------------------------------------------------------------------
# InstanceArchive filesystem sink
# ---------------------------------------------------------------------------


def test_filesystem_archive_roundtrip(tmp_path):
    arch = InstanceArchive(tmp_path / "archive")
    rec = InstanceRecord(instance_id="inst-1", status="STOPPED", stop_reason="user")
    arch.write_manifest(rec, {"id": "c1", "name": "C1"})
    arch.append_event("inst-1", {"event": "INSTANCE_STARTED", "ts": 1})
    arch.append_event("inst-1", {"event": "INSTANCE_READY", "ts": 2})
    arch.append_submission("inst-1", {"correct": False})
    arch.append_submission("inst-1", {"correct": True})
    arch.write_container_logs("inst-1", "stdout line\nstderr line\n")

    root = tmp_path / "archive" / "inst-1"
    assert (root / "instance.json").is_file()
    assert (root / "events.jsonl").is_file()
    assert (root / "submissions.jsonl").is_file()
    assert (root / "container.log").is_file()

    events = arch.read_events("inst-1")
    assert [e["event"] for e in events] == ["INSTANCE_STARTED", "INSTANCE_READY"]
    subs = arch.read_submissions("inst-1")
    assert [s["correct"] for s in subs] == [False, True]
    assert "stdout line" in arch.read_container_log("inst-1")


def test_filesystem_archive_missing_instance_reads_return_empty(tmp_path):
    arch = InstanceArchive(tmp_path / "archive")
    assert arch.read_events("nonexistent") == []
    assert arch.read_submissions("nonexistent") == []
    assert arch.read_container_log("nonexistent") == ""
    assert not arch.has_artifact("nonexistent", "anything")


def test_filesystem_archive_corrupt_jsonl_line_is_skipped(tmp_path):
    arch = InstanceArchive(tmp_path / "archive")
    arch.append_event("inst-1", {"event": "ok"})
    (tmp_path / "archive" / "inst-1" / "events.jsonl").open("a").write(
        'not-json\n{"event": "also-ok"}\n'
    )
    events = arch.read_events("inst-1")
    assert [e["event"] for e in events] == ["ok", "also-ok"]


# ---------------------------------------------------------------------------
# End-to-end: lifecycle hooks produce DB row + filesystem artifacts
# ---------------------------------------------------------------------------


def test_stop_instance_archives_record_and_events(tmp_path, mock_env_manager, backend, monkeypatch):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    archive_dir = tmp_path / "archive"
    cfg = CtfyConfig(instance_archive_dir=archive_dir)

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        client = TestClient(app)
        # Create a team so POST /instances has an authenticated caller.
        team = mint_team(backend, name="tester", email="tester@example.test")
        hdr = team.headers

        iid = start_instance_and_wait(client, "E1", headers=hdr)
        # DELETE the instance — this should archive it.
        del_resp = client.delete(f"/api/v1/instances/{iid}", headers=hdr)
        assert del_resp.status_code == 200

    # DB row exists
    rec = backend.get_instance_record(iid)
    assert rec is not None
    assert rec.stop_reason == "user"
    assert rec.status == "stopped"
    # Filesystem artifacts
    assert (archive_dir / iid / "instance.json").is_file()
    events = (archive_dir / iid / "events.jsonl").read_text().strip().splitlines()
    # Expect at least STARTED + READY + STOPPED events mirrored into the stream
    assert any("instance_started" in ln or "INSTANCE_STARTED" in ln for ln in events)
    assert any("instance_stopped" in ln or "INSTANCE_STOPPED" in ln for ln in events)


def test_admin_list_and_detail_endpoints(tmp_path, mock_env_manager, backend, monkeypatch):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    archive_dir = tmp_path / "archive"
    cfg = CtfyConfig(instance_archive_dir=archive_dir)

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")
        hdr = team.headers
        admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)
        admin_hdr = admin.headers
        iid = start_instance_and_wait(client, "E1", headers=hdr)
        client.delete(f"/api/v1/instances/{iid}", headers=hdr)

        # List
        r = client.get("/api/v1/admin/instance-records", headers=admin_hdr)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["total"] >= 1
        assert any(item["instance_id"] == iid for item in body["items"])

        # Filtered list
        r2 = client.get(
            "/api/v1/admin/instance-records",
            headers=admin_hdr,
            params={"team_id": "nonexistent"},
        )
        assert r2.json()["total"] == 0

        # Detail
        r3 = client.get(f"/api/v1/admin/instance-records/{iid}", headers=admin_hdr)
        assert r3.status_code == 200, r3.text
        detail = r3.json()
        assert detail["record"]["instance_id"] == iid
        assert detail["artifacts"]["has_manifest"] is True

        # Events + submissions — both paginated via BigLimitOffsetPage.
        evs = client.get(f"/api/v1/admin/instance-records/{iid}/events", headers=admin_hdr).json()
        assert isinstance(evs["items"], list) and len(evs["items"]) >= 1
        assert evs["total"] >= 1

        subs = client.get(
            f"/api/v1/admin/instance-records/{iid}/submissions", headers=admin_hdr
        ).json()
        assert isinstance(subs["items"], list)
        assert "total" in subs


def test_admin_detail_endpoint_resolves_live_instance(
    tmp_path, mock_env_manager, backend
):
    """Admins navigating to /admin/instances/{id} for a *running* (not yet
    archived) instance must get a 200 with a synthesized record, not a 404.

    Regression test for the bug where ``GET /admin/instance-records/{id}``
    returned ``InstanceNotFoundError`` for any instance that was still in
    the live ``InstanceState`` map but had not yet been archived. The
    admin instances list links straight to that detail page, so the bug
    made every running instance unclickable for admins.
    """
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ):
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")
        admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)

        iid = start_instance_and_wait(client, "E1", headers=team.headers)
        # NOTE: we deliberately do NOT delete the instance — it stays
        # live, so the archive table has no row for it yet.
        assert backend.get_instance(iid) is not None
        assert backend.get_instance_record(iid) is None

        r = client.get(
            f"/api/v1/admin/instance-records/{iid}", headers=admin.headers
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["record"]["instance_id"] == iid
        # Live row is "ready", not a terminal status — no stop_reason yet.
        assert body["record"]["status"] == InstanceStatus.READY
        assert body["record"]["stop_reason"] == ""
        assert body["record"]["stopped_at"] == 0.0
        # No artifacts yet — instance hasn't been archived.
        assert body["artifacts"]["has_manifest"] is False


def test_lifecycle_populates_requested_and_ready_timestamps(
    tmp_path, mock_env_manager, backend
):
    """End-to-end: POST /instances must stamp ``requested_at`` immediately,
    the READY transition must stamp ``ready_at``, and both must propagate
    to the archived ``InstanceRecord`` so the admin per-challenge panel
    can compute launch latency without joining live state."""
    import time as _time

    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ):
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")

        before = _time.time()
        iid = start_instance_and_wait(client, "E1", headers=team.headers)
        after = _time.time()

        # Live row: both timestamps populated and ordered.
        live = backend.get_instance(iid)
        assert live is not None
        assert before <= live.requested_at <= after, (before, live.requested_at, after)
        assert before <= live.ready_at <= after, (before, live.ready_at, after)
        assert live.ready_at >= live.requested_at

        # Archive: timestamps propagated through ``archive_instance_record``.
        client.delete(f"/api/v1/instances/{iid}", headers=team.headers)
        rec = backend.get_instance_record(iid)
        assert rec is not None
        assert rec.requested_at == pytest.approx(live.requested_at)
        assert rec.ready_at == pytest.approx(live.ready_at)


def test_lifecycle_error_path_leaves_ready_at_zero(
    tmp_path, mock_env_manager, backend
):
    """When dispatch fails before READY, ``ready_at`` must stay 0.0 so
    the admin dashboard's launch-duration aggregation excludes the row
    from p50/p95 (success-only) while still counting it toward
    error_rate (errors / launches)."""
    import time as _time

    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ) as fake_nc:
        # Simulate the node never reaching READY: get_status keeps returning
        # STARTING until poll exhaustion (TimeoutError → ERROR).
        fake_nc.start_instance.return_value = {
            "instance_id": "x",
            "status": "starting",
        }
        fake_nc.get_status.return_value = {
            "instance_id": "x",
            "status": "starting",
            "attack_surface": None,
            "error": None,
        }
        # Speed up the poll loop so the test doesn't hang.
        with patch("ctfy.server.instance_lifecycle.REMOTE_INSTANCE_POLL_MAX", 1):
            with patch("ctfy.server.instance_lifecycle.time.sleep"):
                client = TestClient(app)
                team = mint_team(backend, name="tester", email="t@example.test")
                before = _time.time()
                resp = client.post(
                    "/api/v1/instances",
                    json={"challenge_id": "E1", "ttl": 300},
                    headers=team.headers,
                )
                assert resp.status_code < 400, resp.text
                iid = resp.json()["instance_id"]
                # Wait for the bg executor to record the error.
                deadline = _time.monotonic() + 3.0
                while _time.monotonic() < deadline:
                    rec = backend.get_instance_record(iid)
                    if rec is not None:
                        break
                    _time.sleep(0.05)
                rec = backend.get_instance_record(iid)
                assert rec is not None, "error path should have archived a record"
                assert rec.stop_reason == "error"
                assert rec.requested_at >= before
                assert rec.ready_at == 0.0


def test_non_admin_cannot_list_instance_records(tmp_path, mock_env_manager, backend):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    client = TestClient(app)
    r = client.get("/api/v1/admin/instance-records")
    assert r.status_code in (401, 403)


# ---------------------------------------------------------------------------
# Mitmproxy traffic — capture + archive + admin browsing + analytics
# ---------------------------------------------------------------------------


def _fake_flow(method: str = "GET", path: str = "/", status: int = 200) -> dict:
    """A minimal HTTPRecord-shaped dict matching ``mitmproxy/logger.py``."""
    return {
        "client": {"ip": "172.30.0.10", "port": 51234},
        "server": {"ip": "172.30.0.20", "port": 80},
        "request": {
            "method": method,
            "url": f"http://target{path}",
            "host": "target",
            "path": path,
            "version": "HTTP/1.1",
            "headers": {},
            "query": {},
            "body": "",
        },
        "response": {
            "status_code": status,
            "headers": {},
            "body": "",
            "content_type": None,
            "content_length": 0,
        },
        "metadata": {"timestamp": "2024-01-01T00:00:00+00:00", "duration": 1.0},
    }


def test_filesystem_archive_traffic_roundtrip(tmp_path):
    arch = InstanceArchive(tmp_path / "archive")
    flows = [_fake_flow(path="/a"), _fake_flow(path="/b", status=404)]
    arch.write_traffic("inst-1", flows)

    assert (tmp_path / "archive" / "inst-1" / "traffic.jsonl").is_file()
    assert arch.count_traffic("inst-1") == 2

    read = arch.read_traffic("inst-1")
    assert [f["request"]["path"] for f in read] == ["/a", "/b"]
    # Empty / unknown instance returns 0 / [].
    assert arch.count_traffic("nonexistent") == 0
    assert arch.read_traffic("nonexistent") == []


def test_filesystem_archive_traffic_overwrites(tmp_path):
    """A second ``write_traffic`` (e.g. archive retry) must replace, not append."""
    arch = InstanceArchive(tmp_path / "archive")
    arch.write_traffic("inst-1", [_fake_flow(path="/old")])
    arch.write_traffic("inst-1", [_fake_flow(path="/new1"), _fake_flow(path="/new2")])
    read = arch.read_traffic("inst-1")
    assert [f["request"]["path"] for f in read] == ["/new1", "/new2"]


def test_stop_instance_archives_traffic_and_request_count(
    tmp_path, mock_env_manager, backend
):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    archive_dir = tmp_path / "archive"
    cfg = CtfyConfig(instance_archive_dir=archive_dir)
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ) as fake_nc:
        # Pretend mitmproxy captured three flows during the instance run.
        fake_nc.get_traffic.return_value = [
            _fake_flow(path="/login"),
            _fake_flow(path="/admin", status=403),
            _fake_flow(method="POST", path="/api/submit"),
        ]
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")
        iid = start_instance_and_wait(client, "E1", headers=team.headers)
        del_resp = client.delete(f"/api/v1/instances/{iid}", headers=team.headers)
        assert del_resp.status_code == 200

    rec = backend.get_instance_record(iid)
    assert rec is not None
    assert rec.request_count == 3
    assert (archive_dir / iid / "traffic.jsonl").is_file()
    lines = (archive_dir / iid / "traffic.jsonl").read_text().strip().splitlines()
    assert len(lines) == 3


def test_admin_can_browse_archived_traffic_and_other_team_live_traffic(
    tmp_path, mock_env_manager, backend
):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ) as fake_nc:
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")
        admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)
        # Two live flows for the live admin endpoint.
        fake_nc.get_traffic.return_value = [
            _fake_flow(path="/x"),
            _fake_flow(path="/y", status=500),
        ]
        iid = start_instance_and_wait(client, "E1", headers=team.headers)

        # Admin can read another team's *live* traffic without owning it.
        live = client.get(
            f"/api/v1/admin/instances/{iid}/traffic", headers=admin.headers
        )
        assert live.status_code == 200, live.text
        assert len(live.json()) == 2

        # Stop → archive → admin reads the archived traffic + count.
        client.delete(f"/api/v1/instances/{iid}", headers=team.headers)

    archived = client.get(
        f"/api/v1/admin/instance-records/{iid}/traffic", headers=admin.headers
    )
    assert archived.status_code == 200, archived.text
    body = archived.json()
    assert body["total"] == 2
    assert len(body["items"]) == 2

    # Detail endpoint surfaces traffic_count alongside the other artifact counts.
    detail = client.get(
        f"/api/v1/admin/instance-records/{iid}", headers=admin.headers
    ).json()
    assert detail["artifacts"]["traffic_count"] == 2
    assert detail["record"]["request_count"] == 2


def test_non_admin_cannot_read_admin_traffic_endpoints(
    tmp_path, mock_env_manager, backend
):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ) as fake_nc:
        fake_nc.get_traffic.return_value = [_fake_flow()]
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")
        other = mint_team(backend, name="other", email="other@example.test")
        iid = start_instance_and_wait(client, "E1", headers=team.headers)

        # Non-admin (other team) hits admin endpoint → denied.
        r = client.get(
            f"/api/v1/admin/instances/{iid}/traffic", headers=other.headers
        )
        assert r.status_code in (401, 403)
        # Unauthenticated → also denied.
        r2 = client.get(f"/api/v1/admin/instances/{iid}/traffic")
        assert r2.status_code in (401, 403)
        # Other team also can't read the team-scoped endpoint for an instance
        # they don't own — already covered by test_team_isolation but assert
        # parity here for clarity.
        r3 = client.get(f"/api/v1/instances/{iid}/traffic", headers=other.headers)
        assert r3.status_code in (403, 404)


def test_admin_traffic_summary_aggregates_per_team(
    tmp_path, mock_env_manager, backend
):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ) as fake_nc:
        client = TestClient(app)
        team_a = mint_team(backend, name="alpha", email="alpha@example.test")
        team_b = mint_team(backend, name="bravo", email="bravo@example.test")
        admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)

        # team_a launches and stops two instances with 2 + 4 captured flows.
        fake_nc.get_traffic.return_value = [_fake_flow(), _fake_flow()]
        iid_a1 = start_instance_and_wait(client, "E1", headers=team_a.headers)
        client.delete(f"/api/v1/instances/{iid_a1}", headers=team_a.headers)

        fake_nc.get_traffic.return_value = [_fake_flow()] * 4
        iid_a2 = start_instance_and_wait(client, "E1", headers=team_a.headers)
        client.delete(f"/api/v1/instances/{iid_a2}", headers=team_a.headers)

        # team_b launches one instance with 1 captured flow.
        fake_nc.get_traffic.return_value = [_fake_flow()]
        iid_b1 = start_instance_and_wait(client, "E1", headers=team_b.headers)
        client.delete(f"/api/v1/instances/{iid_b1}", headers=team_b.headers)

        r = client.get("/api/v1/admin/traffic/summary", headers=admin.headers)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["total_requests"] == 7
        per_team = {row["team_id"]: row for row in body["teams"]}
        assert per_team[team_a.team_id]["request_count"] == 6
        assert per_team[team_a.team_id]["instance_count"] == 2
        assert per_team[team_b.team_id]["request_count"] == 1
        assert per_team[team_b.team_id]["instance_count"] == 1
        # Per-instance breakdown: 3 archived rows.
        archived_rows = [r for r in body["instances"] if not r["live"]]
        assert len(archived_rows) == 3
        per_inst = {r["instance_id"]: r for r in archived_rows}
        assert per_inst[iid_a1]["request_count"] == 2
        assert per_inst[iid_a2]["request_count"] == 4
        assert per_inst[iid_b1]["request_count"] == 1


# ---------------------------------------------------------------------------
# Pcap — capture archive + admin download + path-traversal safety
# ---------------------------------------------------------------------------


_FAKE_PCAP = (
    # 24-byte libpcap global header (magic + version + linktype) followed by
    # one tiny packet record. Not a *real* capture but enough to round-trip
    # through write/read and prove FileResponse streamed bytes verbatim.
    b"\xd4\xc3\xb2\xa1\x02\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    b"\xff\xff\x00\x00\x01\x00\x00\x00"
    b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b"
    b"\x04\x00\x00\x00\x04\x00\x00\x00"
    b"\xde\xad\xbe\xef"
)


def test_filesystem_archive_pcap_roundtrip(tmp_path):
    arch = InstanceArchive(tmp_path / "archive")
    arch.write_pcap("inst-1", _FAKE_PCAP)

    p = tmp_path / "archive" / "inst-1" / "traffic.pcap"
    assert p.is_file()
    assert p.read_bytes() == _FAKE_PCAP
    assert arch.pcap_size("inst-1") == len(_FAKE_PCAP)
    assert arch.pcap_path("inst-1") == p.resolve()
    # Missing instance reads gracefully.
    assert arch.pcap_size("nonexistent") == 0
    assert arch.pcap_path("nonexistent") is None


def test_filesystem_archive_pcap_overwrites(tmp_path):
    """Archive retries must replace, not append."""
    arch = InstanceArchive(tmp_path / "archive")
    arch.write_pcap("inst-1", b"first")
    arch.write_pcap("inst-1", _FAKE_PCAP)
    assert arch.pcap_size("inst-1") == len(_FAKE_PCAP)


def test_archive_rejects_path_traversal_instance_ids(tmp_path):
    """The archive must refuse to follow ``..`` or absolute paths.

    This is the root of the defence against the path-traversal class of
    bug — every read/write helper goes through ``is_safe_instance_id``
    or ``_safe_artifact_path`` so a malicious id becomes a no-op rather
    than an arbitrary-file read.
    """
    arch = InstanceArchive(tmp_path / "archive")
    # Plant a "secret" the attacker would target.
    secret = tmp_path / "secret.txt"
    secret.write_text("S3CR3T")

    bad_ids = [
        "../secret",
        "../../etc/passwd",
        "..",
        "/etc/passwd",
        "foo/bar",
        "foo\x00bar",
        " ",
        "",
    ]
    for bad in bad_ids:
        # Read paths return empty / None — never raise, never read foreign files.
        assert arch.read_traffic(bad) == [], f"unsafe id leaked: {bad!r}"
        assert arch.read_events(bad) == [], f"unsafe id leaked: {bad!r}"
        assert arch.read_submissions(bad) == [], f"unsafe id leaked: {bad!r}"
        assert arch.read_container_log(bad) == "", f"unsafe id leaked: {bad!r}"
        assert arch.pcap_path(bad) is None, f"unsafe id leaked: {bad!r}"
        assert arch.pcap_size(bad) == 0, f"unsafe id leaked: {bad!r}"
        assert arch.has_artifact(bad, "instance.json") is False
        # write_pcap is a no-op for unsafe ids — must not create files outside root.
        arch.write_pcap(bad, _FAKE_PCAP)

    # No artefacts written outside the archive root.
    assert secret.read_text() == "S3CR3T"
    archive_root = tmp_path / "archive"
    for p in archive_root.rglob("*"):
        # Anything under the root is fine; the test is the absence of escapes.
        assert archive_root in p.resolve().parents or p.resolve() == archive_root.resolve()


def test_stop_instance_archives_pcap(tmp_path, mock_env_manager, backend):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    archive_dir = tmp_path / "archive"
    cfg = CtfyConfig(instance_archive_dir=archive_dir)
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ) as fake_nc:
        fake_nc.get_pcap.return_value = _FAKE_PCAP
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")
        iid = start_instance_and_wait(client, "E1", headers=team.headers)
        client.delete(f"/api/v1/instances/{iid}", headers=team.headers)

    persisted = archive_dir / iid / "traffic.pcap"
    assert persisted.is_file()
    assert persisted.read_bytes() == _FAKE_PCAP


def test_admin_can_download_archived_pcap(tmp_path, mock_env_manager, backend):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ) as fake_nc:
        fake_nc.get_pcap.return_value = _FAKE_PCAP
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")
        admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)
        iid = start_instance_and_wait(client, "E1", headers=team.headers)
        client.delete(f"/api/v1/instances/{iid}", headers=team.headers)

    # Detail surfaces the artifact size so the UI can show the button.
    detail = client.get(
        f"/api/v1/admin/instance-records/{iid}", headers=admin.headers
    ).json()
    assert detail["artifacts"]["pcap_bytes"] == len(_FAKE_PCAP)

    # Streaming the file: bytes verbatim, correct media type + filename.
    r = client.get(
        f"/api/v1/admin/instance-records/{iid}/pcap", headers=admin.headers
    )
    assert r.status_code == 200, r.text
    assert r.content == _FAKE_PCAP
    assert r.headers["content-type"] == "application/vnd.tcpdump.pcap"
    assert f'filename="{iid}.pcap"' in r.headers.get("content-disposition", "")


def test_admin_pcap_endpoints_reject_path_traversal(tmp_path, mock_env_manager, backend):
    """Path-traversal payloads must be rejected at the route, not pass through.

    This is the primary defence the user asked for: a malicious admin
    (or compromised admin token) trying ``../../../etc/passwd`` in the
    URL must get a clean 400, never a file outside the archive root.
    """
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import mint_team

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    client = TestClient(app)
    admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)

    # Plant a target outside the archive root.
    secret = tmp_path / "secret.txt"
    secret.write_text("S3CR3T")

    # Two layers prevent traversal:
    #   1. URL-level: the HTTP client normalises ``..`` segments away,
    #      so requests like ``/.../../secret/pcap`` never reach the
    #      route at all (catch-all returns the SPA index, not pcap).
    #   2. Route-level: anything that *does* survive to the handler is
    #      validated by ``is_safe_instance_id`` and 400'd.
    # The assertion below covers both — no response ever returns the
    # secret bytes nor a successful pcap content-type.
    # httpx itself refuses null bytes / control chars in URLs, so those
    # never even reach the test server. The list below is the set the
    # test runner can actually issue; null bytes are covered by the
    # archive-level test above.
    for bad in [
        "..",
        "../secret",
        "..%2f..%2fetc%2fpasswd",
        "foo/bar",
        "%2e%2e%2fsecret",
        "foo;rm",
        "foo bar",
    ]:
        for url in (
            f"/api/v1/admin/instances/{bad}/pcap",
            f"/api/v1/admin/instance-records/{bad}/pcap",
        ):
            r = client.get(url, headers=admin.headers)
            ct = r.headers.get("content-type", "")
            assert "vnd.tcpdump.pcap" not in ct, (bad, url, ct)
            assert b"S3CR3T" not in r.content, (bad, url)


def test_non_admin_cannot_download_pcap(tmp_path, mock_env_manager, backend):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ) as fake_nc:
        fake_nc.get_pcap.return_value = _FAKE_PCAP
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")
        iid = start_instance_and_wait(client, "E1", headers=team.headers)
        client.delete(f"/api/v1/instances/{iid}", headers=team.headers)

    # Non-admin (team member) can never download.
    r = client.get(
        f"/api/v1/admin/instance-records/{iid}/pcap", headers=team.headers
    )
    assert r.status_code in (401, 403)
    # Unauthenticated.
    r2 = client.get(f"/api/v1/admin/instance-records/{iid}/pcap")
    assert r2.status_code in (401, 403)


def test_admin_get_instance_returns_info(tmp_path, mock_env_manager, backend):
    """``GET /admin/instances/{id}`` resolves a live instance for any team.

    The new endpoint backs the live-traffic page header so it can show
    team_id / challenge_id / status next to the bare UUID.
    """
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, mint_team, start_instance_and_wait

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend, flag="FLAG{deadbeef0123456789abcdef01234567}", host="10.0.1.5"
    ):
        client = TestClient(app)
        team = mint_team(backend, name="tester", email="tester@example.test")
        admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)
        iid = start_instance_and_wait(client, "E1", headers=team.headers)

        # Admin can resolve any instance, even ones they don't own.
        r = client.get(f"/api/v1/admin/instances/{iid}", headers=admin.headers)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["instance_id"] == iid
        assert body["team_id"] == team.team_id
        assert body["challenge_id"] == "E1"

        # Unknown id → 404 (not 500).
        r404 = client.get(
            "/api/v1/admin/instances/00000000-0000-0000-0000-000000000000",
            headers=admin.headers,
        )
        assert r404.status_code == 404

        # Non-admin denied.
        r403 = client.get(f"/api/v1/admin/instances/{iid}", headers=team.headers)
        assert r403.status_code in (401, 403)


def test_admin_get_instance_rejects_unsafe_id(tmp_path, mock_env_manager, backend):
    """Path-traversal payloads in the URL must be 400'd, mirroring pcap."""
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import mint_team

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    client = TestClient(app)
    admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)
    for bad in ["foo bar", "foo;rm", "foo$bar"]:
        r = client.get(
            f"/api/v1/admin/instances/{bad}", headers=admin.headers
        )
        assert r.status_code in (400, 404), (bad, r.status_code, r.text)


def test_admin_traffic_summary_requires_admin(tmp_path, mock_env_manager, backend):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import mint_team

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    client = TestClient(app)
    team = mint_team(backend, name="tester", email="tester@example.test")
    r = client.get("/api/v1/admin/traffic/summary", headers=team.headers)
    assert r.status_code in (401, 403)
    r2 = client.get("/api/v1/admin/traffic/summary")
    assert r2.status_code in (401, 403)
