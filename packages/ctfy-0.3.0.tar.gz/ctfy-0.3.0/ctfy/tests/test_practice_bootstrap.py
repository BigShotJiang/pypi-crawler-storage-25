"""Practice-competition bootstrap.

A fresh deployment ships with a challenge directory but no
competitions. Without one, players have no comp to register for and
the per-comp routes 404 across the board. The bootstrap helper
mints a single permanent "practice" competition containing every
known challenge so the platform is usable out of the box.

Idempotent: re-running on a populated database is a no-op (so a
restart of an already-bootstrapped server doesn't duplicate the
comp). Operators who want to *replace* the practice comp delete the
existing row first.
"""

from __future__ import annotations

from unittest.mock import MagicMock

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import CompetitionState
from ctfy.server.bootstrap import (
    PRACTICE_COMPETITION_ID,
    bootstrap_practice_competition,
)
from ctfy.tests.conftest import build_spec, make_mock_challenge_manager


def _spec_reader(*ids: str):
    return make_mock_challenge_manager(
        challenge_specs=[build_spec(i) for i in ids],
        auto_generate_specs=False,
    )


class TestBootstrapPracticeCompetition:
    def test_creates_practice_comp_with_every_known_challenge(self):
        backend = InMemoryBackend()
        reader = _spec_reader("c1", "c2", "c3")

        result = bootstrap_practice_competition(backend, reader)

        assert result is not None
        comp = backend.get_competition(PRACTICE_COMPETITION_ID)
        assert comp is not None
        assert sorted(comp.challenge_ids) == ["c1", "c2", "c3"]

    def test_practice_comp_runs_indefinitely(self):
        """Empty ``starts_at`` + ``ends_at`` are the platform sentinels
        for "live now / never expires" — the practice comp is meant to
        be permanently available."""
        backend = InMemoryBackend()
        reader = _spec_reader("c1")
        bootstrap_practice_competition(backend, reader)
        comp = backend.get_competition(PRACTICE_COMPETITION_ID)
        assert comp.starts_at == ""
        assert comp.ends_at == ""

    def test_idempotent_when_practice_comp_already_exists(self):
        """Calling again must not duplicate the row or churn its
        ``challenge_ids`` — operators expect bootstrap to be safe to
        re-run on every restart."""
        backend = InMemoryBackend()
        reader = _spec_reader("c1", "c2")
        bootstrap_practice_competition(backend, reader)
        # Tweak the comp out-of-band to simulate operator changes;
        # second bootstrap must NOT clobber them.
        backend.put_competition(
            backend.get_competition(PRACTICE_COMPETITION_ID).model_copy(
                update={"title": "Operator-renamed", "challenge_ids": ["c1"]}
            )
        )

        result = bootstrap_practice_competition(backend, reader)
        assert result is None  # signals "already bootstrapped"

        comp = backend.get_competition(PRACTICE_COMPETITION_ID)
        assert comp.title == "Operator-renamed"
        assert comp.challenge_ids == ["c1"]

    def test_skips_when_any_competition_already_exists(self):
        """If the operator has already curated their own comps, do
        not silently auto-mint a practice one — the existence of any
        comp is a signal that the platform is no longer "fresh"."""
        backend = InMemoryBackend()
        backend.put_competition(
            CompetitionState(
                competition_id="custom-1",
                title="Custom",
                created_at="2026-01-01T00:00:00Z",
            )
        )
        reader = _spec_reader("c1")
        result = bootstrap_practice_competition(backend, reader)
        assert result is None
        assert backend.get_competition(PRACTICE_COMPETITION_ID) is None

    def test_no_op_on_empty_challenge_directory(self):
        """An empty challenges_dir produces no practice comp — there's
        nothing to play. Logs a hint elsewhere (out of scope for the
        unit test); the contract is just "don't crash, don't insert
        an empty placeholder"."""
        backend = InMemoryBackend()
        reader = make_mock_challenge_manager(
            challenge_specs=[], auto_generate_specs=False
        )
        result = bootstrap_practice_competition(backend, reader)
        assert result is None
        assert backend.get_competition(PRACTICE_COMPETITION_ID) is None
