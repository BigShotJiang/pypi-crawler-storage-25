"""End-to-end coverage for multi-flag challenges.

Covers a 2-flag challenge (foothold / root) driven through the real
FastAPI stack: ``start_instance`` → submit first flag → instance is
still running → submit second flag → auto-stop fires + archive row
gets ``solved=True`` with both flag ids recorded.
"""

from __future__ import annotations

import time
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.tests.conftest import (
    build_spec,
    fake_node_context,
    make_mock_challenge_manager,
    mint_team,
    start_instance_and_wait,
)

FLAGS = {
    "foothold": "FLAG{foothold_0123456789abcdef0123456789abcdef0123}",
    "root":     "FLAG{root_0123456789abcdef0123456789abcdef01234567}",
}


@pytest.fixture
def multi_flag_client():
    """TestClient wired up with a single 2-flag challenge ``KIOSK-01``."""
    backend = InMemoryBackend()
    spec = build_spec(
        "KIOSK-01",
        name="Intranet Kiosk",
        description="Two-stage challenge",
        flags=["foothold", "root"],
    )
    mgr = make_mock_challenge_manager(
        challenge_specs=[spec],
        auto_generate_specs=False,
    )

    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="10.0.1.5", backend=backend)

    # Pin the flag dict the platform hands to the fake node so tests can
    # submit deterministic values.
    with fake_node_context(backend, flag="__unused__") as _:
        # Override the generate_flags patch so it yields per-flag values.
        with patch(
            "ctfy.server.routes.instances.generate_flags",
            side_effect=lambda ids: {fid: FLAGS[fid] for fid in ids},
        ):
            yield TestClient(app), backend


def _register_team(client: TestClient, name: str = "RedTeam") -> dict:
    """Mint a team + token directly via the backend (OAuth is covered elsewhere)."""
    backend = client.app.state.ctfy.state_backend
    minted = mint_team(
        backend,
        name=name,
        email=f"{name.lower()}@example.test",
    )
    return {"team_id": minted.team_id, "name": name, "token": minted.token}


def _submit(client: TestClient, token: str, instance_id: str, flag: str) -> dict:
    r = client.post(
        "/api/v1/submissions",
        json={"instance_id": instance_id, "flag": flag},
        headers={"Authorization": f"Bearer {token}"},
    )
    return r.json()


class TestMultiFlagSubmission:
    def test_partial_solve_keeps_instance_running(self, multi_flag_client):
        client, backend = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "KIOSK-01", headers=auth)

        data = _submit(client, team["token"], instance_id, FLAGS["foothold"])
        assert data["correct"] is True
        assert data["flag_id"] == "foothold"
        assert data["challenge_fully_solved"] is False
        # Still running — auto-stop only fires after the final flag.
        status = client.get(f"/api/v1/instances/{instance_id}/status", headers=auth)
        assert status.status_code == 200

    def test_second_flag_triggers_full_solve_and_autostop(self, multi_flag_client):
        client, backend = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "KIOSK-01", headers=auth)

        first = _submit(client, team["token"], instance_id, FLAGS["foothold"])
        assert first["challenge_fully_solved"] is False

        second = _submit(client, team["token"], instance_id, FLAGS["root"])
        assert second["correct"] is True
        assert second["flag_id"] == "root"
        assert second["challenge_fully_solved"] is True

        # Instance is auto-stopped asynchronously; poll briefly.
        for _ in range(30):
            status = client.get(f"/api/v1/instances/{instance_id}/status", headers=auth)
            if status.status_code == 404:
                break
            time.sleep(0.1)
        else:
            pytest.fail("instance should have been auto-stopped")

    def test_wrong_flag_returns_null_flag_id(self, multi_flag_client):
        client, _ = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "KIOSK-01", headers=auth)

        data = _submit(client, team["token"], instance_id, "FLAG{nope}")
        assert data["correct"] is False
        assert data["flag_id"] is None
        assert data["challenge_fully_solved"] is False

    def test_reverse_order_still_fully_solves(self, multi_flag_client):
        """Flags are independent; order doesn't matter."""
        client, _ = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "KIOSK-01", headers=auth)

        a = _submit(client, team["token"], instance_id, FLAGS["root"])
        assert a["flag_id"] == "root"
        assert a["challenge_fully_solved"] is False

        b = _submit(client, team["token"], instance_id, FLAGS["foothold"])
        assert b["flag_id"] == "foothold"
        assert b["challenge_fully_solved"] is True

    def test_duplicate_correct_flag_does_not_double_solve(self, multi_flag_client):
        client, backend = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "KIOSK-01", headers=auth)

        a = _submit(client, team["token"], instance_id, FLAGS["foothold"])
        assert a["solve_rank"] == 1

        b = _submit(client, team["token"], instance_id, FLAGS["foothold"])
        assert b["correct"] is True
        assert b["flag_id"] == "foothold"
        # Second hit does NOT register a new Solve → solve_rank stays 0.
        assert b["solve_rank"] == 0

    def test_scoreboard_counts_flags_solved(self, multi_flag_client):
        client, _ = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "KIOSK-01", headers=auth)

        _submit(client, team["token"], instance_id, FLAGS["foothold"])
        # Partial solve: 1 flag, 0 fully-solved challenges.
        sb = client.get("/api/v1/scoreboard").json()["items"]
        row = next(r for r in sb if r["team_id"] == team["team_id"])
        assert row["flags_solved"] == 1
        assert row["solved"] == 0

        _submit(client, team["token"], instance_id, FLAGS["root"])
        sb = client.get("/api/v1/scoreboard").json()["items"]
        row = next(r for r in sb if r["team_id"] == team["team_id"])
        assert row["flags_solved"] == 2
        assert row["solved"] == 1

    def test_challenge_info_exposes_flag_ids(self, multi_flag_client):
        client, _ = multi_flag_client
        _register_team(client)  # needs auth? challenges endpoint is public
        info = client.get("/api/v1/challenges/KIOSK-01").json()
        assert info["flag_ids"] == ["foothold", "root"]
        assert info["flag_solves"] == {"foothold": 0, "root": 0}


class TestMySolvesEndpoint:
    """``GET /me/solves`` powers the 1血/2血/3血 badge on challenge cards.

    Three teams race to solve the foothold flag in order; rank 1 / 2 / 3
    must surface in each team's summary. A non-solving team gets an
    empty list. For multi-flag challenges, ``best_rank`` is the smallest
    rank across captured flags so a team that nailed first blood on
    even one flag keeps its 1血 badge.
    """

    def test_per_team_blood_rank_orders_by_solved_at(self, multi_flag_client):
        client, _ = multi_flag_client

        teams = []
        for name in ("Alpha", "Bravo", "Charlie"):
            t = _register_team(client, name=name)
            auth = {"Authorization": f"Bearer {t['token']}"}
            instance_id = start_instance_and_wait(client, "KIOSK-01", headers=auth)
            _submit(client, t["token"], instance_id, FLAGS["foothold"])
            teams.append(t)
            # Force distinct solved_at timestamps even if the suite runs
            # fast enough to land submissions inside the same ISO second.
            time.sleep(0.01)

        for expected_rank, t in enumerate(teams, start=1):
            r = client.get(
                "/api/v1/me/solves",
                headers={"Authorization": f"Bearer {t['token']}"},
            )
            assert r.status_code == 200
            rows = r.json()
            assert len(rows) == 1
            assert rows[0]["challenge_id"] == "KIOSK-01"
            assert rows[0]["best_rank"] == expected_rank

    def test_non_solving_team_sees_empty_list(self, multi_flag_client):
        client, _ = multi_flag_client
        t = _register_team(client, name="Spectator")
        r = client.get(
            "/api/v1/me/solves",
            headers={"Authorization": f"Bearer {t['token']}"},
        )
        assert r.status_code == 200
        assert r.json() == []

    def test_best_rank_is_min_across_flags(self, multi_flag_client):
        """Multi-flag challenge: a team can be 1st on one flag, later on
        another. ``best_rank`` should report the team's strongest finish.
        """
        client, _ = multi_flag_client

        # Alpha goes first on ``foothold`` (rank 1 on that flag).
        alpha = _register_team(client, name="Alpha")
        alpha_inst = start_instance_and_wait(
            client, "KIOSK-01", headers={"Authorization": f"Bearer {alpha['token']}"}
        )
        _submit(client, alpha["token"], alpha_inst, FLAGS["foothold"])
        time.sleep(0.01)

        # Bravo races ahead on ``root`` while Alpha is still working.
        bravo = _register_team(client, name="Bravo")
        bravo_inst = start_instance_and_wait(
            client, "KIOSK-01", headers={"Authorization": f"Bearer {bravo['token']}"}
        )
        _submit(client, bravo["token"], bravo_inst, FLAGS["root"])
        time.sleep(0.01)

        # Alpha later picks up ``root`` (rank 2 on that flag) — but its
        # best rank stays 1 because of the foothold first blood.
        _submit(client, alpha["token"], alpha_inst, FLAGS["root"])

        rows_alpha = client.get(
            "/api/v1/me/solves",
            headers={"Authorization": f"Bearer {alpha['token']}"},
        ).json()
        assert rows_alpha[0]["best_rank"] == 1

        rows_bravo = client.get(
            "/api/v1/me/solves",
            headers={"Authorization": f"Bearer {bravo['token']}"},
        ).json()
        assert rows_bravo[0]["best_rank"] == 1
