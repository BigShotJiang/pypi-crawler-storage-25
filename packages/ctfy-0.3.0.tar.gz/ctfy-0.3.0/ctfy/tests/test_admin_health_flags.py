"""Tests for ``GET /admin/health-flags`` — the four-pane "needs attention"
panel on the admin Overview. Each pane surfaces a class of failure the
admin should investigate."""

from __future__ import annotations

import time
from datetime import datetime, timezone
from unittest.mock import patch

from fastapi.testclient import TestClient

from ctfy.core.enums import InstanceStatus
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import (
    InstanceRecord,
    InstanceState,
    NodeState,
    SolveState,
    SubmissionState,
)
from ctfy.tests.conftest import mint_team


def _bootstrap(env_manager):
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    admin = mint_team(backend, name="adm", email="adm@example.test", is_admin=True)
    return app, backend, admin


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


def test_health_flags_requires_admin(mock_env_manager):
    app, _, _ = _bootstrap(mock_env_manager)
    c = TestClient(app)
    assert c.get("/api/v1/admin/health-flags").status_code in (401, 403)


def test_health_flags_403_for_non_admin(mock_env_manager):
    app, backend, _ = _bootstrap(mock_env_manager)
    user = mint_team(backend, name="u", email="u@example.test", is_admin=False)
    c = TestClient(app)
    r = c.get("/api/v1/admin/health-flags", headers=user.headers)
    assert r.status_code == 403


# ---------------------------------------------------------------------------
# Empty system — all four lists empty
# ---------------------------------------------------------------------------


def test_empty_system_returns_empty_lists(mock_env_manager):
    app, _, admin = _bootstrap(mock_env_manager)
    c = TestClient(app)
    body = c.get("/api/v1/admin/health-flags", headers=admin.headers).json()
    assert body["stuck_starting"] == []
    assert body["recent_errors"] == []
    assert body["unhealthy_nodes"] == []
    assert body["silent_challenges"] == []


# ---------------------------------------------------------------------------
# stuck_starting — STARTING for > 60 seconds
# ---------------------------------------------------------------------------


def test_stuck_starting_only_lists_old_starting_rows(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager)
    now = time.time()
    # Recent STARTING — should NOT appear.
    backend.put_instance(
        "fresh",
        InstanceState(
            instance_id="fresh",
            challenge_id="E1",
            team_id="t1",
            node_id="n1",
            status=InstanceStatus.STARTING,
            requested_at=now - 5,
        ),
    )
    # Old STARTING — should appear.
    backend.put_instance(
        "stale",
        InstanceState(
            instance_id="stale",
            challenge_id="E1",
            team_id="t2",
            node_id="n1",
            status=InstanceStatus.STARTING,
            requested_at=now - 120,
        ),
    )
    # READY row — should NOT appear.
    backend.put_instance(
        "ready",
        InstanceState(
            instance_id="ready",
            challenge_id="E1",
            team_id="t3",
            node_id="n1",
            status=InstanceStatus.READY,
            requested_at=now - 600,
            ready_at=now - 590,
        ),
    )
    c = TestClient(app)
    body = c.get("/api/v1/admin/health-flags", headers=admin.headers).json()
    ids = {row["instance_id"] for row in body["stuck_starting"]}
    assert ids == {"stale"}


# ---------------------------------------------------------------------------
# recent_errors — capped at 50, newest-first
# ---------------------------------------------------------------------------


def test_recent_errors_capped_and_newest_first(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager)
    # Insert 60 error records with ascending stopped_at — only the newest
    # 50 should come back, in newest-first order.
    for i in range(60):
        backend.archive_instance(
            InstanceRecord(
                instance_id=f"err{i:02d}",
                challenge_id="E1",
                team_id="t1",
                node_id="n1",
                status=InstanceStatus.ERROR,
                stop_reason="error",
                error=f"e{i}",
                requested_at=1000.0 + i,
                stopped_at=2000.0 + i,
            )
        )
    # A non-error record must be ignored.
    backend.archive_instance(
        InstanceRecord(
            instance_id="ok",
            challenge_id="E1",
            team_id="t1",
            node_id="n1",
            status=InstanceStatus.STOPPED,
            stop_reason="user",
            requested_at=1000.0,
            stopped_at=2000.0,
        )
    )
    c = TestClient(app)
    body = c.get("/api/v1/admin/health-flags", headers=admin.headers).json()
    errs = body["recent_errors"]
    assert len(errs) == 50
    # Newest first: err59 → err10
    assert errs[0]["instance_id"] == "err59"
    assert errs[-1]["instance_id"] == "err10"
    # The non-error record didn't sneak in.
    assert all(e["instance_id"] != "ok" for e in errs)


# ---------------------------------------------------------------------------
# unhealthy_nodes — currently flagged unhealthy with downtime context
# ---------------------------------------------------------------------------


def test_unhealthy_nodes_include_downtime(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager)
    now = time.time()
    backend.put_node(
        "n-bad",
        NodeState(
            node_id="n-bad",
            url="http://n-bad:8101",
            display_name="badnode",
            capacity=10,
            running=0,
            healthy=False,
            last_heartbeat=_iso(now - 300),
            last_heartbeat_ts=now - 300,
        ),
    )
    backend.put_node(
        "n-good",
        NodeState(
            node_id="n-good",
            url="http://n-good:8101",
            display_name="goodnode",
            capacity=10,
            running=0,
            healthy=True,
            last_heartbeat=_iso(now - 5),
            last_heartbeat_ts=now - 5,
        ),
    )
    c = TestClient(app)
    body = c.get("/api/v1/admin/health-flags", headers=admin.headers).json()
    nodes = body["unhealthy_nodes"]
    assert len(nodes) == 1
    assert nodes[0]["node_id"] == "n-bad"
    # downtime_s is reasonably close to 300 seconds.
    assert nodes[0]["downtime_s"] >= 250


# ---------------------------------------------------------------------------
# silent_challenges — launched + submitted but never solved
# ---------------------------------------------------------------------------


def test_silent_challenges_flags_unsolved_with_attempts(mock_env_manager):
    app, backend, admin = _bootstrap(mock_env_manager)

    # Challenge SILENT-1: 5 successful launches across 3 teams + many wrong
    # submissions, ZERO solves → flagged.
    for i, tid in enumerate(["t1", "t2", "t3", "t1", "t2"]):
        backend.archive_instance(
            InstanceRecord(
                instance_id=f"s{i}",
                challenge_id="WEB-001",
                team_id=tid,
                node_id="n1",
                status=InstanceStatus.STOPPED,
                requested_at=1000.0 + i,
                ready_at=1001.0 + i,
                stopped_at=1500.0 + i,
            )
        )
    for i, tid in enumerate(["t1", "t2", "t3", "t1", "t2"]):
        backend.add_submission(
            SubmissionState(
                submission_id=f"sub{i}",
                team_id=tid,
                challenge_id="WEB-001",
                claimed_flag="wrong",
                submitted_at=_iso(1500.0 + i),
            )
        )

    # Challenge LIVE-1: same shape but solved by t1.
    backend.archive_instance(
        InstanceRecord(
            instance_id="L1",
            challenge_id="WEB-002",
            team_id="t1",
            node_id="n1",
            status=InstanceStatus.STOPPED,
            requested_at=1000.0,
            ready_at=1001.0,
            stopped_at=1500.0,
        )
    )
    backend.add_submission(
        SubmissionState(
            submission_id="sub-l",
            team_id="t1",
            challenge_id="WEB-002",
            claimed_flag="ok",
            correct=True,
            flag_id="main",
            submitted_at=_iso(1500.0),
        )
    )
    backend.add_solve(
        "t1",
        "WEB-002",
        "main",
        SolveState(
            team_id="t1",
            challenge_id="WEB-002",
            flag_id="main",
            solved_at=_iso(1500.0),
        ),
    )

    c = TestClient(app)
    body = c.get("/api/v1/admin/health-flags", headers=admin.headers).json()
    flagged_ids = {x["challenge_id"] for x in body["silent_challenges"]}
    assert "WEB-001" in flagged_ids
    assert "WEB-002" not in flagged_ids
