"""Node-side ``GET /instances/{id}/traffic`` walks the JSONL subtree.

The mitmproxy ``JsonlLogger`` addon writes flows nested per target host
and port: ``<proxy_out>/traffic/<host>/<port>/traffic.jsonl``. The
node route used to ``iterdir()`` the top-level proxy_out and filter for
``.json`` files, so it never found anything and the admin "Traffic"
dashboard always reported zero flows. These tests pin the new walker
in place.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

from fastapi import FastAPI
from fastapi.testclient import TestClient

from ctfy.server.node_app import NodeAppState, make_require_node_token
from ctfy.server.node_state import NodeInstanceRecord, NodeInstanceStore
from ctfy.server.routes.node_instances import create_router

NODE_TOKEN = "test-node-token"
AUTH = {"Authorization": f"Bearer {NODE_TOKEN}"}


def _build_client(tmp_path: Path, proxy_out: Path | None):
    store = NodeInstanceStore(tmp_path / "node.db")
    store.put(
        NodeInstanceRecord(
            instance_id="inst-1",
            challenge_id="WEB-001",
            proxy_output=str(proxy_out) if proxy_out else "",
            status="running",
        )
    )
    mgr = MagicMock()
    mgr.get_proxy_output.return_value = proxy_out
    state = NodeAppState(
        registration_token="",
        public_url="http://node:8101",
        capacity=10,
        store=store,
        challenge_manager=mgr,
        node_token=NODE_TOKEN,
    )
    state.require_node_token = make_require_node_token(state)
    app = FastAPI()
    app.include_router(create_router(state), prefix="/api/v1")
    return TestClient(app)


def _flow(host: str, path: str, ts: str) -> dict:
    """Minimal HTTPRecord-shaped dict — only the fields tests assert on."""
    return {
        "request": {"host": host, "path": path, "method": "GET"},
        "response": {"status_code": 200},
        "metadata": {"timestamp": ts, "duration": 1.0},
    }


def _write_jsonl(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


class TestNodeTrafficRoute:
    def test_walks_nested_host_port_dirs_and_returns_chronological(self, tmp_path):
        proxy_out = tmp_path / "proxy"
        traffic = proxy_out / "traffic"
        _write_jsonl(
            traffic / "api.example.com" / "443" / "traffic.jsonl",
            [
                json.dumps(_flow("api.example.com", "/a", "2026-04-27T10:00:02Z")),
                json.dumps(_flow("api.example.com", "/b", "2026-04-27T10:00:04Z")),
            ],
        )
        _write_jsonl(
            traffic / "api.example.com" / "80" / "traffic.jsonl",
            [json.dumps(_flow("api.example.com", "/c", "2026-04-27T10:00:01Z"))],
        )

        client = _build_client(tmp_path, proxy_out)
        r = client.get("/api/v1/instances/inst-1/traffic", headers=AUTH)
        assert r.status_code == 200, r.text

        flows = r.json()
        assert [f["request"]["path"] for f in flows] == ["/c", "/a", "/b"]

    def test_blank_and_malformed_lines_are_skipped(self, tmp_path):
        proxy_out = tmp_path / "proxy"
        traffic = proxy_out / "traffic"
        _write_jsonl(
            traffic / "h" / "443" / "traffic.jsonl",
            [
                "",
                json.dumps(_flow("h", "/ok1", "2026-04-27T10:00:01Z")),
                "{not valid json",
                "   ",
                json.dumps(_flow("h", "/ok2", "2026-04-27T10:00:02Z")),
            ],
        )

        client = _build_client(tmp_path, proxy_out)
        r = client.get("/api/v1/instances/inst-1/traffic", headers=AUTH)
        assert r.status_code == 200, r.text
        flows = r.json()
        assert [f["request"]["path"] for f in flows] == ["/ok1", "/ok2"]

    def test_missing_traffic_subdir_returns_empty(self, tmp_path):
        # proxy_out exists (sidecar started) but no flows were captured yet.
        proxy_out = tmp_path / "proxy"
        proxy_out.mkdir()

        client = _build_client(tmp_path, proxy_out)
        r = client.get("/api/v1/instances/inst-1/traffic", headers=AUTH)
        assert r.status_code == 200, r.text
        assert r.json() == []

    def test_no_proxy_output_returns_empty(self, tmp_path):
        client = _build_client(tmp_path, proxy_out=None)
        r = client.get("/api/v1/instances/inst-1/traffic", headers=AUTH)
        assert r.status_code == 200, r.text
        assert r.json() == []

    def test_unknown_instance_returns_404(self, tmp_path):
        proxy_out = tmp_path / "proxy"
        proxy_out.mkdir()
        client = _build_client(tmp_path, proxy_out)
        r = client.get("/api/v1/instances/does-not-exist/traffic", headers=AUTH)
        assert r.status_code == 404
