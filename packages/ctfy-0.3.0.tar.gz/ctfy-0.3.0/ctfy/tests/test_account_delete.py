"""End-to-end tests for ``DELETE /api/v1/me`` (self-service account deletion).

The cascade primitive itself is covered by ``test_state.py``; these
tests focus on the route's contract: confirmation gate, auth gate,
status code, and post-delete reachability.
"""

from __future__ import annotations

from ctfy.tests.conftest import mint_team


def test_delete_me_rejects_wrong_display_name_confirmation(client, backend):
    """Wrong ``confirm_display_name`` is a 400 and leaves the team
    intact — the typo gate is the user's primary safety net before
    the row goes."""
    team = mint_team(backend, name="Doomed", email="doomed@example.test")
    resp = client.request(
        "DELETE",
        "/api/v1/me",
        headers=team.headers,
        json={"confirm_display_name": "Definitely Not The Right Name"},
    )
    assert resp.status_code == 400
    # Team row still resolvable.
    assert backend.get_team(team.team_id) is not None
    # Token still works.
    me = client.get("/api/v1/me", headers=team.headers)
    assert me.status_code == 200


def test_delete_me_with_matching_name_returns_204_and_voids_the_token(client, backend):
    team = mint_team(backend, name="Doomed", email="doomed@example.test")
    resp = client.request(
        "DELETE",
        "/api/v1/me",
        headers=team.headers,
        json={"confirm_display_name": "Doomed"},
    )
    assert resp.status_code == 204
    # Team row gone.
    assert backend.get_team(team.team_id) is None
    # Token can no longer authenticate /me — bearer resolves to nothing.
    me = client.get("/api/v1/me", headers=team.headers)
    assert me.status_code in (401, 403)


def test_delete_me_requires_authentication(client):
    resp = client.request(
        "DELETE",
        "/api/v1/me",
        json={"confirm_display_name": "anything"},
    )
    assert resp.status_code in (401, 403)


def test_delete_me_rejects_agent_token(client, backend):
    """Account deletion is sensitive auth-state mutation: only a user-kind
    bearer (logged-in browser session) can call it. An agent token —
    even on the team's own account — gets a 403 so a leaked agent
    credential can't be used to wipe the team."""
    team = mint_team(
        backend,
        name="AgentOnly",
        email="agent@example.test",
        token_kind="agent",
    )
    resp = client.request(
        "DELETE",
        "/api/v1/me",
        headers=team.headers,
        json={"confirm_display_name": "AgentOnly"},
    )
    assert resp.status_code == 403


def test_delete_me_does_not_touch_other_teams(client, backend):
    doomed = mint_team(backend, name="Doomed", email="d@example.test")
    bystander = mint_team(backend, name="Bystander", email="b@example.test")
    resp = client.request(
        "DELETE",
        "/api/v1/me",
        headers=doomed.headers,
        json={"confirm_display_name": "Doomed"},
    )
    assert resp.status_code == 204
    # Bystander's row + token still work.
    assert backend.get_team(bystander.team_id) is not None
    me = client.get("/api/v1/me", headers=bystander.headers)
    assert me.status_code == 200
    assert me.json()["user_id"] == bystander.user_id
    # Per-comp memberships still resolve the bystander's team.
    assert any(
        ct["team_id"] == bystander.team_id
        for ct in me.json()["competition_teams"]
    )
