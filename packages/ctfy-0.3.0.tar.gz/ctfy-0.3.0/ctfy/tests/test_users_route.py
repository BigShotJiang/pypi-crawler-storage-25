"""TDD: public ``GET /users/{user_id}`` profile endpoint.

The team profile page (``/teams/{id}``) needs a way to fetch the
captain user's bio / country / social so the About card can render
the team's "face" again. Pre-split that data lived on the team row;
post-split it lives on the user. This route is the missing piece.

Visibility rules mirror the old ``/teams/{id}`` contract:

* Owner (the user themselves) and admins always see the full profile.
* Anonymous viewers and other authenticated users get the visibility-
  scrubbed view: keys whose ``profile_visibility`` entry is False
  are blanked out.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import UserState
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team


@pytest.fixture
def world():
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    yield TestClient(app), backend


def _seed_user_with_profile(backend, *, name: str = "Alice", email: str = "a@x"):
    """Mint a team via the conftest helper, then update the user with
    profile fields so we can assert visibility behaviour."""
    minted = mint_team(backend, name=name, email=email)
    user = backend.get_user(minted.user_id)
    backend.put_user(
        minted.user_id,
        user.model_copy(
            update={
                "bio": "I love CTFs",
                "country": "JP",
                "website_url": "https://example.com",
                "timezone": "Asia/Tokyo",
                "social_links": {"github": "octocat"},
            }
        ),
    )
    return minted


class TestPublicUserRoute:
    def test_anonymous_can_read(self, world):
        client, backend = world
        u = _seed_user_with_profile(backend)
        r = client.get(f"/api/v1/users/{u.user_id}")
        assert r.status_code == 200
        body = r.json()
        assert body["user_id"] == u.user_id
        assert body["display_name"] == "Alice"
        assert body["bio"] == "I love CTFs"
        assert body["country"] == "JP"
        assert body["social_links"] == {"github": "octocat"}

    def test_unknown_user_404(self, world):
        client, _ = world
        assert client.get("/api/v1/users/no-such-user").status_code == 404

    def test_visibility_hides_fields_for_other_viewers(self, world):
        client, backend = world
        target = _seed_user_with_profile(backend)
        # Mark bio + country as private.
        target_user = backend.get_user(target.user_id)
        backend.put_user(
            target.user_id,
            target_user.model_copy(
                update={
                    "profile_visibility": {
                        "bio": False,
                        "country": False,
                    }
                }
            ),
        )
        viewer = mint_team(backend, name="Viewer", email="v@x")
        r = client.get(
            f"/api/v1/users/{target.user_id}",
            headers=viewer.headers,
        )
        body = r.json()
        # Private fields scrubbed.
        assert body["bio"] is None
        assert body["country"] is None
        # Public fields still present.
        assert body["website_url"] == "https://example.com"
        assert body["social_links"] == {"github": "octocat"}

    def test_visibility_hides_solves_and_last_active_from_others(self, world):
        """``solves_count`` / ``attempts_count`` / ``last_active_at`` are
        also scrubbed — otherwise a user can mark their bio private but
        leak activity timing through the lifetime aggregates."""
        client, backend = world
        target = _seed_user_with_profile(backend)
        target_user = backend.get_user(target.user_id)
        # Pretend the user has some activity so the unfiltered shape
        # would non-trivially leak through.
        from ctfy.core.state.models import SolveState

        backend.add_solve(
            target.team_id,
            "c1",
            "main",
            SolveState(
                team_id=target.team_id,
                user_id=target.user_id,
                challenge_id="c1",
                flag_id="main",
                solved_at="2026-04-01T00:00:00Z",
            ),
        )
        backend.put_user(
            target.user_id,
            target_user.model_copy(
                update={
                    "profile_visibility": {
                        "solves_count": False,
                        "attempts_count": False,
                        "last_active_at": False,
                    }
                }
            ),
        )
        viewer = mint_team(backend, name="Viewer2", email="v2@x")
        r = client.get(
            f"/api/v1/users/{target.user_id}",
            headers=viewer.headers,
        )
        body = r.json()
        # All three lifetime counters scrubbed for the non-owner viewer.
        assert body["solves"] == 0
        assert body["attempts"] == 0
        assert body["last_active_at"] == ""
        # Owner still sees the truthful aggregates.
        own = client.get(
            f"/api/v1/users/{target.user_id}", headers=target.headers
        ).json()
        assert own["solves"] == 1

    def test_owner_sees_their_own_full_profile(self, world):
        client, backend = world
        target = _seed_user_with_profile(backend)
        target_user = backend.get_user(target.user_id)
        backend.put_user(
            target.user_id,
            target_user.model_copy(
                update={"profile_visibility": {"bio": False}}
            ),
        )
        r = client.get(
            f"/api/v1/users/{target.user_id}",
            headers=target.headers,
        )
        body = r.json()
        # Owner gets the unscrubbed view.
        assert body["bio"] == "I love CTFs"

    def test_admin_sees_full_profile(self, world):
        client, backend = world
        target = _seed_user_with_profile(backend)
        target_user = backend.get_user(target.user_id)
        backend.put_user(
            target.user_id,
            target_user.model_copy(
                update={"profile_visibility": {"bio": False}}
            ),
        )
        admin = mint_team(backend, name="Admin", email="admin@x", role="admin")
        r = client.get(
            f"/api/v1/users/{target.user_id}",
            headers=admin.headers,
        )
        assert r.json()["bio"] == "I love CTFs"


class TestUserSolveTrendRoute:
    """``GET /users/{user_id}/solve-trend`` — user-scoped daily solve count.

    Replaces the Dashboard's old `getTeamProfileStats(current_team_id)`
    call. Trend aggregates by ``solve.user_id`` so the "personal trend"
    survives the user moving teams between competitions.
    """

    def _seed_solves(self, backend, target, dates: list[str]):
        from ctfy.core.state.models import SolveState

        for i, d in enumerate(dates):
            backend.add_solve(
                target.team_id,
                f"c{i}",
                "main",
                SolveState(
                    team_id=target.team_id,
                    user_id=target.user_id,
                    challenge_id=f"c{i}",
                    flag_id="main",
                    solved_at=f"{d}T12:00:00Z",
                ),
            )

    def test_unknown_user_404(self, world):
        client, _ = world
        r = client.get("/api/v1/users/nope/solve-trend")
        assert r.status_code == 404

    def test_returns_zero_filled_window_with_no_solves(self, world):
        client, backend = world
        target = mint_team(backend, name="A", email="a@x")
        r = client.get(
            f"/api/v1/users/{target.user_id}/solve-trend?days=7",
            headers=target.headers,
        )
        assert r.status_code == 200
        body = r.json()
        assert len(body["solve_trend"]) == 7
        assert all(p["solves"] == 0 for p in body["solve_trend"])

    def test_aggregates_only_solves_owned_by_the_user(self, world):
        """A solve attributed to a different ``user_id`` (e.g. an old
        teammate's row that's still in the team's solve history) must
        NOT count toward the target user's trend."""
        client, backend = world
        target = mint_team(backend, name="A", email="a@x")
        other = mint_team(backend, name="B", email="b@x")
        # One solve by target, one by another user on the same team_id.
        from ctfy.core.state.models import SolveState

        from datetime import datetime, timezone

        today = datetime.now(timezone.utc).date().isoformat()
        backend.add_solve(
            target.team_id,
            "c1",
            "main",
            SolveState(
                team_id=target.team_id,
                user_id=target.user_id,
                challenge_id="c1",
                flag_id="main",
                solved_at=f"{today}T12:00:00Z",
            ),
        )
        backend.add_solve(
            target.team_id,
            "c2",
            "main",
            SolveState(
                team_id=target.team_id,
                user_id=other.user_id,
                challenge_id="c2",
                flag_id="main",
                solved_at=f"{today}T12:00:00Z",
            ),
        )
        r = client.get(
            f"/api/v1/users/{target.user_id}/solve-trend?days=7",
            headers=target.headers,
        )
        body = r.json()
        total = sum(p["solves"] for p in body["solve_trend"])
        assert total == 1, body

    def test_visibility_hides_trend_from_non_owner_when_off(self, world):
        client, backend = world
        target = mint_team(backend, name="A", email="a@x")
        target_user = backend.get_user(target.user_id)
        backend.put_user(
            target.user_id,
            target_user.model_copy(
                update={"profile_visibility": {"solve_trend": False}}
            ),
        )
        from datetime import datetime, timezone

        today = datetime.now(timezone.utc).date().isoformat()
        self._seed_solves(backend, target, [today])
        # Owner sees the real trend.
        own = client.get(
            f"/api/v1/users/{target.user_id}/solve-trend?days=7",
            headers=target.headers,
        ).json()
        assert sum(p["solves"] for p in own["solve_trend"]) == 1
        # A different viewer gets the empty list.
        viewer = mint_team(backend, name="V", email="v@x")
        r = client.get(
            f"/api/v1/users/{target.user_id}/solve-trend?days=7",
            headers=viewer.headers,
        )
        assert r.json()["solve_trend"] == []

    def test_admin_sees_trend_even_when_private(self, world):
        client, backend = world
        target = mint_team(backend, name="A", email="a@x")
        target_user = backend.get_user(target.user_id)
        backend.put_user(
            target.user_id,
            target_user.model_copy(
                update={"profile_visibility": {"solve_trend": False}}
            ),
        )
        from datetime import datetime, timezone

        today = datetime.now(timezone.utc).date().isoformat()
        self._seed_solves(backend, target, [today])
        admin = mint_team(backend, name="Adm", email="adm@x", role="admin")
        r = client.get(
            f"/api/v1/users/{target.user_id}/solve-trend?days=7",
            headers=admin.headers,
        ).json()
        assert sum(p["solves"] for p in r["solve_trend"]) == 1
