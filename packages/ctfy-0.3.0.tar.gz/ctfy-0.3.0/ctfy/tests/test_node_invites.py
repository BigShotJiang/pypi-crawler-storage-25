"""Node-invite endpoints + invite-driven registration.

Backend-only coverage for PR 1 of the invite-token rollout. CLI and web
UI wire-up land in subsequent PRs.
"""

from __future__ import annotations

import time
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import NodeInviteState
from ctfy.server.auth import hash_token
from ctfy.tests.conftest import build_spec, make_mock_challenge_manager, mint_team


@pytest.fixture
def mock_env_manager():
    return make_mock_challenge_manager(
        challenge_specs=[build_spec("MN-001", name="MN")],
    )


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def admin(backend):
    """A team flagged is_admin=True — the new replacement for CTFY_ADMIN_TOKEN."""
    return mint_team(backend, name="admin", email="admin@example.test", is_admin=True)


@pytest.fixture
def client(mock_env_manager, backend, admin):
    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    return TestClient(app)


class TestCreateInvite:
    def test_mint_returns_plaintext_once(self, client, admin):
        r = client.post(
            "/api/v1/nodes/invites",
            json={"ttl_seconds": 120},
            headers=admin.headers,
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["registration_token"].startswith("reg_")
        assert len(body["registration_token"]) >= 36  # "reg_" + 32 urlsafe bytes
        assert body["invite_id"]
        assert body["expires_at"]

    def test_requires_admin(self, client):
        r = client.post("/api/v1/nodes/invites", json={})
        assert r.status_code in (401, 403)

    def test_ttl_bounds(self, client, admin):
        # Below min (60s)
        r = client.post("/api/v1/nodes/invites", json={"ttl_seconds": 10}, headers=admin.headers)
        assert r.status_code == 422
        # Above max (7 days)
        r = client.post(
            "/api/v1/nodes/invites",
            json={"ttl_seconds": 10 * 24 * 3600},
            headers=admin.headers,
        )
        assert r.status_code == 422


class TestListAndRevokeInvite:
    def test_list_shows_active(self, client, admin):
        r = client.post("/api/v1/nodes/invites", json={"ttl_seconds": 3600}, headers=admin.headers)
        invite_id = r.json()["invite_id"]

        items = client.get("/api/v1/nodes/invites", headers=admin.headers).json()["items"]
        assert len(items) == 1
        assert items[0]["invite_id"] == invite_id
        assert items[0]["status"] == "active"
        # Plaintext / hash never leak through the list endpoint
        assert "registration_token" not in items[0]
        assert "token_hash" not in items[0]

    def test_list_requires_admin(self, client):
        assert client.get("/api/v1/nodes/invites").status_code in (401, 403)

    def test_revoke_removes(self, client, admin):
        r = client.post("/api/v1/nodes/invites", json={"ttl_seconds": 3600}, headers=admin.headers)
        invite_id = r.json()["invite_id"]
        assert (
            client.delete(f"/api/v1/nodes/invites/{invite_id}", headers=admin.headers).status_code
            == 200
        )
        assert client.get("/api/v1/nodes/invites", headers=admin.headers).json()["items"] == []

    def test_revoke_unknown_404(self, client, admin):
        assert (
            client.delete("/api/v1/nodes/invites/nope", headers=admin.headers).status_code == 404
        )


class TestRegisterViaInvite:
    def _mint(self, client, admin, ttl=3600):
        r = client.post(
            "/api/v1/nodes/invites",
            json={"ttl_seconds": ttl},
            headers=admin.headers,
        )
        return r.json()

    def test_register_succeeds_and_consumes(self, client, admin):
        inv = self._mint(client, admin)
        r = client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n1:8100", "display_name": "n1", "capacity": 10},
            headers={"Authorization": f"Bearer {inv['registration_token']}"},
        )
        assert r.status_code == 200, r.text
        assert r.json()["node_token"]  # per-node outbound still returned

        items = client.get("/api/v1/nodes/invites", headers=admin.headers).json()["items"]
        assert items[0]["status"] == "consumed"
        assert items[0]["consumed_by_node_id"] == r.json()["node_id"]

    def test_second_use_rejected(self, client, admin):
        inv = self._mint(client, admin)
        hdr = {"Authorization": f"Bearer {inv['registration_token']}"}
        ok = client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n1:8100", "display_name": "n1"},
            headers=hdr,
        )
        assert ok.status_code == 200
        again = client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n2:8100", "display_name": "n2"},
            headers=hdr,
        )
        assert again.status_code == 403
        assert "used" in again.text.lower()

    def test_expired_invite_rejected(self, client, backend):
        # Go around the HTTP layer to force an already-expired invite; the
        # public API rejects ttl < 60 so this is the cheapest path.
        plaintext = "reg_expired_fixture_token_xxxxxxxxxxxxxxxxxxx"
        backend.put_invite(
            NodeInviteState(
                invite_id="expired1",
                token_hash=hash_token(plaintext),
                created_at="2000-01-01T00:00:00Z",
                created_at_ts=time.time() - 7200,
                expires_at_ts=time.time() - 60,
            )
        )
        r = client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n1:8100"},
            headers={"Authorization": f"Bearer {plaintext}"},
        )
        assert r.status_code == 403
        assert "expired" in r.text.lower()

    def test_revoked_invite_rejected(self, client, admin):
        inv = self._mint(client, admin)
        client.delete(f"/api/v1/nodes/invites/{inv['invite_id']}", headers=admin.headers)
        r = client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n1:8100"},
            headers={"Authorization": f"Bearer {inv['registration_token']}"},
        )
        # Revoked = deleted; the invite lookup returns None so the dep
        # falls through to admin and ultimately 403.
        assert r.status_code == 403

    def test_admin_token_still_registers(self, client, admin):
        """Admin is the operator escape hatch — no invite needed."""
        r = client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n1:8100", "display_name": "n1"},
            headers=admin.headers,
        )
        assert r.status_code == 200

    def test_unauthenticated_register_rejected(self, client):
        r = client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n1:8100"},
        )
        assert r.status_code in (401, 403)


class TestStateBackendInvites:
    def test_consume_is_idempotent_per_hash(self):
        be = InMemoryBackend()
        inv = NodeInviteState(
            invite_id="a",
            token_hash="abc",
            created_at_ts=time.time(),
            expires_at_ts=time.time() + 600,
        )
        be.put_invite(inv)
        first = be.consume_invite("abc", "node-1")
        second = be.consume_invite("abc", "node-2")
        assert first is not None
        assert first.consumed_by_node_id == "node-1"
        assert second is None  # already consumed

    def test_get_by_hash_roundtrip(self):
        be = InMemoryBackend()
        inv = NodeInviteState(invite_id="a", token_hash="xyz")
        be.put_invite(inv)
        assert be.get_invite_by_hash("xyz").invite_id == "a"
        assert be.get_invite_by_hash("missing") is None
        assert be.get_invite_by_hash("") is None
