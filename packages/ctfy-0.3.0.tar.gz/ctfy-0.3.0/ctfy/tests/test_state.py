"""Unit tests for StateBackend (InMemoryBackend)."""

import threading
import time

import pytest

from ctfy.core.state import (
    ActivityState,
    InMemoryBackend,
    InstanceState,
    OAuthIdentity,
    ScoreboardSnapshotState,
    SolveState,
    SubmissionState,
    TeamState,
    TeamToken,
    create_backend,
)


@pytest.fixture
def be():
    return InMemoryBackend()


# -- instance CRUD ----------------------------------------------------------


class TestInstanceCRUD:
    def test_put_get(self, be):
        be.put_instance(
            "env-1",
            InstanceState(flags={"main": "FLAG{abc}"}, status="ready"),
            ttl=60,
        )
        inst = be.get_instance("env-1")
        assert inst is not None
        assert inst.flags == {"main": "FLAG{abc}"}
        assert inst.ttl == 60
        assert inst.expires_at > 0
        assert inst.started_at > 0

    def test_get_missing(self, be):
        assert be.get_instance("nonexistent") is None

    def test_remove(self, be):
        be.put_instance("env-1", InstanceState(flags={"main": "x"}))
        removed = be.remove_instance("env-1")
        assert removed is not None
        assert removed.flags == {"main": "x"}
        assert be.get_instance("env-1") is None

    def test_remove_missing(self, be):
        assert be.remove_instance("nonexistent") is None

    def test_list_instances(self, be):
        be.put_instance("a", InstanceState(flags={"main": "1"}))
        be.put_instance("b", InstanceState(flags={"main": "2"}))
        instances = be.list_instances()
        ids = {e.instance_id for e in instances}
        assert ids == {"a", "b"}

    def test_count(self, be):
        assert be.count_instances() == 0
        be.put_instance("a", InstanceState())
        assert be.count_instances() == 1

    def test_no_ttl(self, be):
        be.put_instance("env-1", InstanceState(flags={"main": "x"}), ttl=0)
        inst = be.get_instance("env-1")
        assert inst.expires_at == 0.0


# -- TTL & renew -------------------------------------------------------------


class TestTTL:
    def test_renew(self, be):
        be.put_instance("env-1", InstanceState(), ttl=10)
        new_exp = be.renew_instance("env-1", ttl=3600)
        assert new_exp > time.time() + 3500

    def test_renew_missing(self, be):
        with pytest.raises(KeyError):
            be.renew_instance("nonexistent", 60)

    def test_pop_expired(self, be):
        be.put_instance("old", InstanceState(), ttl=1)
        be.put_instance("new", InstanceState(), ttl=9999)
        # Force expiry
        be._instances["old"] = be._instances["old"].model_copy(
            update={"expires_at": time.time() - 1}
        )
        expired = be.pop_expired_instances()
        assert len(expired) == 1
        assert expired[0].instance_id == "old"
        assert be.get_instance("old") is None
        assert be.get_instance("new") is not None

    def test_pop_no_expired(self, be):
        be.put_instance("fresh", InstanceState(), ttl=9999)
        assert be.pop_expired_instances() == []


# -- teams -------------------------------------------------------------------


class TestTeams:
    def test_put_get(self, be):
        be.put_team("t1", TeamState(team_id="t1", name="Alpha"))
        t = be.get_team("t1")
        assert t.name == "Alpha"

    def test_get_missing(self, be):
        assert be.get_team("nope") is None

    def _bind_user_team(self, be, *, user_id: str, team_id: str, email: str = "") -> None:
        """Wire a User → Membership → Team trio so token lookups resolve."""
        from ctfy.core.state.models import TeamMembershipState, UserState

        be.put_user(user_id, UserState(user_id=user_id, email=email, display_name=user_id))
        be.put_team(team_id, TeamState(team_id=team_id, name="A", captain_user_id=user_id))
        be.put_membership(
            TeamMembershipState(user_id=user_id, team_id=team_id, joined_at="")
        )

    def test_get_by_token(self, be):
        self._bind_user_team(be, user_id="u1", team_id="t1")
        be.put_token(
            TeamToken(
                token_id="tok1",
                user_id="u1",
                token_hash="secret",
                kind="user",
                label="login",
            )
        )
        t = be.get_team_by_token("secret")
        assert t.team_id == "t1"

    def test_get_by_invalid_key(self, be):
        assert be.get_team_by_token("invalid") is None

    def test_revoked_token_no_longer_resolves(self, be):
        self._bind_user_team(be, user_id="u1", team_id="t1")
        be.put_token(
            TeamToken(
                token_id="tok1",
                user_id="u1",
                token_hash="secret",
                kind="user",
                label="login",
            )
        )
        assert be.get_team_by_token("secret") is not None
        assert be.revoke_token("tok1", "2026-04-24T00:00:00Z") is True
        assert be.get_team_by_token("secret") is None

    def test_list(self, be):
        be.put_team("t1", TeamState(team_id="t1", name="A"))
        be.put_team("t2", TeamState(team_id="t2", name="B"))
        assert len(be.list_teams()) == 2

    def test_get_user_by_email(self, be):
        from ctfy.core.state.models import UserState

        be.put_user(
            "u1", UserState(user_id="u1", email="alice@Example.com", display_name="A")
        )
        assert be.get_user_by_email("alice@example.com").user_id == "u1"
        assert be.get_user_by_email("ALICE@EXAMPLE.COM").user_id == "u1"
        assert be.get_user_by_email("") is None
        assert be.get_user_by_email("bob@example.com") is None


# -- OAuth identities --------------------------------------------------------


class TestOAuthIdentities:
    def test_put_and_lookup(self, be):
        ident = OAuthIdentity(
            identity_id="i1",
            user_id="t1",
            provider="github",
            provider_user_id="12345",
            provider_email="alice@example.com",
        )
        be.put_identity(ident)
        assert be.get_identity("i1").provider_user_id == "12345"
        assert be.get_identity_by_provider_uid("github", "12345").identity_id == "i1"
        assert be.get_identity_by_provider_uid("github", "missing") is None

    def test_list_for_team(self, be):
        be.put_identity(
            OAuthIdentity(
                identity_id="i1", user_id="t1", provider="github", provider_user_id="1"
            )
        )
        be.put_identity(
            OAuthIdentity(
                identity_id="i2", user_id="t1", provider="google", provider_user_id="2"
            )
        )
        be.put_identity(
            OAuthIdentity(
                identity_id="i3", user_id="t2", provider="github", provider_user_id="3"
            )
        )
        out = be.list_identities_for_user("t1")
        assert {i.identity_id for i in out} == {"i1", "i2"}

    def test_remove(self, be):
        be.put_identity(
            OAuthIdentity(
                identity_id="i1", user_id="t1", provider="github", provider_user_id="1"
            )
        )
        assert be.remove_identity("i1") is True
        assert be.remove_identity("i1") is False


# -- Team tokens -------------------------------------------------------------


class TestTeamTokens:
    def test_put_list_revoke(self, be):
        be.put_token(
            TeamToken(
                token_id="t1", user_id="team", token_hash="h1", kind="user", label="login"
            )
        )
        be.put_token(
            TeamToken(
                token_id="t2", user_id="team", token_hash="h2", kind="agent", label="cli"
            )
        )
        all_active = be.list_tokens_for_user("team")
        assert {t.token_id for t in all_active} == {"t1", "t2"}
        agent_only = be.list_tokens_for_user("team", kind="agent")
        assert {t.token_id for t in agent_only} == {"t2"}
        assert be.revoke_token("t1", "2026-04-24T00:00:00Z") is True
        # Second revoke is a no-op.
        assert be.revoke_token("t1", "2026-04-24T00:00:01Z") is False
        active_after = be.list_tokens_for_user("team")
        assert {t.token_id for t in active_after} == {"t2"}
        with_revoked = be.list_tokens_for_user("team", include_revoked=True)
        assert {t.token_id for t in with_revoked} == {"t1", "t2"}

    def test_touch(self, be):
        be.put_token(
            TeamToken(
                token_id="t1", user_id="team", token_hash="h1", kind="user", label="login"
            )
        )
        be.touch_token("t1", "2026-04-24T01:00:00Z")
        assert be.get_token("t1").last_used_at == "2026-04-24T01:00:00Z"


# -- submissions -------------------------------------------------------------


class TestSubmissions:
    def test_add_and_list(self, be):
        be.add_submission(
            SubmissionState(submission_id="s1", team_id="t1", challenge_id="c1", correct=True)
        )
        be.add_submission(
            SubmissionState(submission_id="s2", team_id="t1", challenge_id="c2", correct=False)
        )
        assert len(be.list_submissions()) == 2

    def test_filter_by_team(self, be):
        be.add_submission(
            SubmissionState(submission_id="s1", team_id="t1", challenge_id="c1", correct=True)
        )
        be.add_submission(
            SubmissionState(submission_id="s2", team_id="t2", challenge_id="c1", correct=False)
        )
        assert len(be.list_submissions(team_id="t1")) == 1

    def test_filter_by_challenge(self, be):
        be.add_submission(
            SubmissionState(submission_id="s1", team_id="t1", challenge_id="c1", correct=True)
        )
        be.add_submission(
            SubmissionState(submission_id="s2", team_id="t1", challenge_id="c2", correct=False)
        )
        assert len(be.list_submissions(challenge_id="c1")) == 1


# -- solves ------------------------------------------------------------------


class TestSolves:
    def test_add_and_get(self, be):
        be.add_solve("t1", "c1", "main", SolveState(solved_at="2026-01-01"))
        s = be.get_solve("t1", "c1", "main")
        assert s.solved_at == "2026-01-01"
        assert s.flag_id == "main"

    def test_get_missing(self, be):
        assert be.get_solve("t1", "c99", "main") is None

    def test_dedup(self, be):
        be.add_solve("t1", "c1", "main", SolveState(solved_at="first"))
        be.add_solve("t1", "c1", "main", SolveState(solved_at="second"))  # ignored
        assert be.get_solve("t1", "c1", "main").solved_at == "first"

    def test_list_by_team(self, be):
        be.add_solve("t1", "c1", "main", SolveState())
        be.add_solve("t1", "c2", "main", SolveState())
        be.add_solve("t2", "c1", "main", SolveState())
        assert len(be.list_solves("t1")) == 2
        assert len(be.list_solves("t2")) == 1

    def test_multi_flag_per_challenge(self, be):
        """Same challenge, different flag ids — two distinct SolveStates."""
        be.add_solve("t1", "c1", "foothold", SolveState(solved_at="a"))
        be.add_solve("t1", "c1", "root", SolveState(solved_at="b"))
        assert be.get_solve("t1", "c1", "foothold").solved_at == "a"
        assert be.get_solve("t1", "c1", "root").solved_at == "b"
        assert len(be.list_solves("t1")) == 2

    def test_count_for_flag(self, be):
        be.add_solve("t1", "c1", "foothold", SolveState())
        be.add_solve("t2", "c1", "foothold", SolveState())
        be.add_solve("t1", "c1", "root", SolveState())
        assert be.count_solves_for_flag("c1", "foothold") == 2
        assert be.count_solves_for_flag("c1", "root") == 1
        assert be.count_solves_for_flag("c1", "missing") == 0

    def test_count_for_challenge_requires_all_flags(self, be):
        # t1 captures both flags → fully solved.
        be.add_solve("t1", "c1", "foothold", SolveState())
        be.add_solve("t1", "c1", "root", SolveState())
        # t2 only captures one → not fully solved.
        be.add_solve("t2", "c1", "foothold", SolveState())
        assert be.count_solves_for_challenge("c1", ("foothold", "root")) == 1
        # Single-flag flavor.
        be.add_solve("t1", "c2", "main", SolveState())
        be.add_solve("t2", "c2", "main", SolveState())
        assert be.count_solves_for_challenge("c2", ("main",)) == 2
        assert be.count_solves_for_challenge("c99", ("main",)) == 0
        # Empty flag tuple → undefined, returns 0 (caller forgot to pass the spec).
        assert be.count_solves_for_challenge("c1", ()) == 0


# -- activity log ------------------------------------------------------------


def _act(**kw) -> ActivityState:
    """Build an ActivityState for tests with sensible actor defaults.

    The schema now requires actor_id/actor_name/actor_type; spelling the
    defaults out in every test would be noise, so centralise here.
    """
    defaults = {"actor_id": kw.get("team_id", ""), "actor_name": "", "actor_type": "team"}
    defaults.update(kw)
    return ActivityState(**defaults)


class TestActivityLog:
    def test_add_and_list(self, be):
        be.add_activity(
            _act(timestamp="t1", event="instance_started", team_id="t1", challenge_id="c1")
        )
        be.add_activity(_act(timestamp="t2", event="flag_correct", team_id="t1", challenge_id="c1"))
        acts = be.list_activities()
        assert len(acts) == 2
        # Most recent first
        assert acts[0].event == "flag_correct"

    def test_filter_by_event(self, be):
        be.add_activity(_act(timestamp="t1", event="instance_started"))
        be.add_activity(_act(timestamp="t2", event="flag_correct"))
        acts = be.list_activities(event="flag_correct")
        assert len(acts) == 1

    def test_filter_by_team(self, be):
        be.add_activity(_act(timestamp="t1", event="x", team_id="t1"))
        be.add_activity(_act(timestamp="t2", event="x", team_id="t2"))
        assert len(be.list_activities(team_id="t1")) == 1

    def test_filter_by_actor(self, be):
        be.add_activity(_act(timestamp="t1", event="x", actor_id="admin", actor_type="admin"))
        be.add_activity(_act(timestamp="t2", event="x", actor_id="system", actor_type="system"))
        be.add_activity(_act(timestamp="t3", event="x", actor_id="admin", actor_type="admin"))
        assert len(be.list_activities(actor_id="admin")) == 2
        assert len(be.list_activities(actor_id="system")) == 1

    def test_limit(self, be):
        for i in range(10):
            be.add_activity(_act(timestamp=f"t{i}", event="x"))
        assert len(be.list_activities(limit=3)) == 3

    def test_offset(self, be):
        for i in range(10):
            be.add_activity(_act(timestamp=f"t{i}", event="x"))
        page1 = be.list_activities(offset=0, limit=3)
        page2 = be.list_activities(offset=3, limit=3)
        assert len(page1) == 3
        assert len(page2) == 3
        assert page1 != page2  # different items

    def test_count_activities(self, be):
        be.add_activity(
            _act(timestamp="t1", event="instance_started", team_id="t1", challenge_id="c1")
        )
        be.add_activity(_act(timestamp="t2", event="flag_correct", team_id="t1", challenge_id="c1"))
        be.add_activity(
            _act(timestamp="t3", event="instance_started", team_id="t2", challenge_id="c2")
        )
        assert be.count_activities() == 3
        assert be.count_activities(team_id="t1") == 2
        assert be.count_activities(event="flag_correct") == 1


def _snap(**kw) -> ScoreboardSnapshotState:
    defaults = {
        "snapshot_at": "t",
        "snapshot_at_ts": 0.0,
        "team_id": "t1",
        "team_name": "t1",
        "rank": 1,
        "solved": 0,
        "attempts": 0,
    }
    defaults.update(kw)
    return ScoreboardSnapshotState(**defaults)


class TestScoreboardSnapshots:
    def test_append_and_list_ascending(self, be):
        be.append_snapshot_batch(
            [
                _snap(team_id="t1", snapshot_at_ts=100.0, rank=2),
                _snap(team_id="t2", snapshot_at_ts=100.0, rank=1),
                _snap(team_id="t1", snapshot_at_ts=200.0, rank=1),
            ]
        )
        rows = be.list_snapshots()
        assert [r.snapshot_at_ts for r in rows] == [100.0, 100.0, 200.0]

    def test_filter_by_team(self, be):
        be.append_snapshot_batch(
            [
                _snap(team_id="t1", snapshot_at_ts=100.0),
                _snap(team_id="t2", snapshot_at_ts=100.0),
                _snap(team_id="t1", snapshot_at_ts=200.0),
            ]
        )
        t1 = be.list_snapshots(team_id="t1")
        assert len(t1) == 2
        assert all(r.team_id == "t1" for r in t1)

    def test_filter_by_since(self, be):
        be.append_snapshot_batch(
            [
                _snap(snapshot_at_ts=100.0),
                _snap(snapshot_at_ts=200.0),
                _snap(snapshot_at_ts=300.0),
            ]
        )
        rows = be.list_snapshots(since_ts=200.0)
        assert [r.snapshot_at_ts for r in rows] == [200.0, 300.0]

    def test_limit_keeps_newest(self, be):
        be.append_snapshot_batch([_snap(snapshot_at_ts=float(i)) for i in range(10)])
        rows = be.list_snapshots(limit=3)
        # Ascending output, last 3 by timestamp
        assert [r.snapshot_at_ts for r in rows] == [7.0, 8.0, 9.0]

    def test_empty_batch_no_op(self, be):
        be.append_snapshot_batch([])
        assert be.list_snapshots() == []


# -- thread safety -----------------------------------------------------------


class TestThreadSafety:
    def test_concurrent_put_get(self, be):
        errors = []

        def worker(instance_id):
            try:
                for _ in range(100):
                    be.put_instance(
                        instance_id,
                        InstanceState(flags={"main": instance_id}),
                        ttl=60,
                    )
                    inst = be.get_instance(instance_id)
                    assert inst is not None
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker, args=(f"env-{i}",)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert not errors


# -- delete_team --------------------------------------------------------------


@pytest.fixture(params=["memory", "sqlite"])
def both(request, tmp_path):
    """Run a test against both backend implementations.

    delete_team is a single-call cascade contract — running the same
    asserts against memory + sqlite catches drift between the two
    implementations early.
    """
    if request.param == "memory":
        return InMemoryBackend()
    from ctfy.core.state import SQLiteBackend

    return SQLiteBackend(str(tmp_path / "delete_team.db"))


def _seed_team(be, team_id: str, *, with_data: bool = True) -> None:
    """Populate every per-team table so the cascade test can verify
    each one gets cleared. Called for both the doomed team and the
    bystander team to prove cross-team isolation."""
    from ctfy.core.state.models import (
        AchievementRecord,
        PasswordIdentity,
    )

    be.put_team(team_id, TeamState(team_id=team_id, name=f"Team-{team_id}"))
    if not with_data:
        return
    be.put_identity(
        OAuthIdentity(
            identity_id=f"id-{team_id}",
            user_id=team_id,
            provider="github",
            provider_user_id=f"gh-{team_id}",
            provider_email=f"{team_id}@example.test",
            created_at="2026-04-25T12:00:00Z",
        )
    )
    be.put_password_identity(
        PasswordIdentity(
            identity_id=f"pid-{team_id}",
            user_id=team_id,
            email=f"{team_id}@example.test",
            password_hash="$argon2id$dummy",
            created_at="2026-04-25T12:00:00Z",
        )
    )
    be.put_token(
        TeamToken(
            token_id=f"tok-{team_id}",
            user_id=team_id,
            kind="user",
            token_hash=f"hash-{team_id}",
            created_at="2026-04-25T12:00:00Z",
        )
    )
    be.add_submission(
        SubmissionState(
            submission_id=f"sub-{team_id}",
            team_id=team_id,
            challenge_id="WEB-001",
            flag="x",
            correct=False,
            submitted_at="2026-04-25T12:01:00Z",
        )
    )
    be.add_solve(
        team_id,
        "WEB-001",
        "main",
        SolveState(solved_at="2026-04-25T12:02:00Z"),
    )
    be.add_activity(
        ActivityState(
            timestamp="2026-04-25T12:03:00Z",
            event="flag_correct",
            team_id=team_id,
            team_name=f"Team-{team_id}",
            actor_id=team_id,
            actor_name=f"Team-{team_id}",
            actor_type="team",
        )
    )
    be.append_snapshot_batch(
        [
            ScoreboardSnapshotState(
                team_id=team_id,
                team_name=f"Team-{team_id}",
                snapshot_at_ts=time.time(),
                rank=1,
                score=10,
                solves=1,
                attempts=1,
            )
        ]
    )
    be.grant_achievement(team_id, "decathlete", context={"solves": 1})
    be.bump_counter(team_id, "wrong_attempts:WEB-001", 5)
    # Achievement model needed for assertions later
    _ = AchievementRecord


class TestDeleteTeam:
    def test_cascade_clears_every_per_team_table(self, both):
        _seed_team(both, "doomed")
        _seed_team(both, "bystander")

        deleted = both.delete_team("doomed")
        assert deleted is True

        # Team row gone.
        assert both.get_team("doomed") is None
        # Submissions / solves gone (team-scoped).
        assert both.list_submissions(team_id="doomed") == []
        assert both.list_solves(team_id="doomed") == []
        # Activities gone.
        assert both.count_activities(team_id="doomed") == 0
        # Snapshots gone.
        assert both.list_snapshots(team_id="doomed") == []
        # Achievements + counters gone.
        assert both.list_achievements("doomed") == []
        assert both.get_counter("doomed", "wrong_attempts:WEB-001") == 0
        # Identities + tokens are USER-attached post user/team-split —
        # delete_team does NOT cascade them. delete_user does. The
        # _seed_team helper writes them with id=team_id which doubles
        # as the user_id under the test's seed pattern, so they
        # survive intact here.
        assert len(both.list_identities_for_user("doomed")) == 1
        assert len(both.list_password_identities_for_user("doomed")) == 1

    def test_bystander_team_data_untouched(self, both):
        _seed_team(both, "doomed")
        _seed_team(both, "bystander")

        both.delete_team("doomed")

        # Bystander's full data set survives.
        assert both.get_team("bystander") is not None
        assert len(both.list_identities_for_user("bystander")) == 1
        assert len(both.list_password_identities_for_user("bystander")) == 1
        assert len(both.list_tokens_for_user("bystander", include_revoked=True)) == 1
        assert len(both.list_submissions(team_id="bystander")) == 1
        assert len(both.list_solves(team_id="bystander")) == 1
        assert both.count_activities(team_id="bystander") == 1
        assert len(both.list_snapshots(team_id="bystander")) == 1
        assert len(both.list_achievements("bystander")) == 1
        assert both.get_counter("bystander", "wrong_attempts:WEB-001") == 5

    def test_returns_false_when_team_does_not_exist(self, both):
        assert both.delete_team("ghost") is False

    def test_idempotent_after_first_call(self, both):
        _seed_team(both, "doomed", with_data=False)
        assert both.delete_team("doomed") is True
        # Second call is a no-op (returns False) instead of raising.
        assert both.delete_team("doomed") is False


# -- factory ------------------------------------------------------------------


class TestFactory:
    def test_default_sqlite(self, tmp_path):
        be = create_backend(project_root=tmp_path)
        from ctfy.core.state import SQLiteBackend

        assert isinstance(be, SQLiteBackend)

    def test_in_memory_when_no_inputs(self):
        """No db_path, no project_root → InMemoryBackend."""
        from ctfy.core.state import InMemoryBackend

        assert isinstance(create_backend(), InMemoryBackend)

    def test_sqlite_persistence(self):
        """Data survives backend reopen (simulates server restart)."""
        import os
        import tempfile

        from ctfy.core.state import SQLiteBackend

        db = tempfile.mktemp(suffix=".db")
        try:
            be1 = SQLiteBackend(db)
            be1.put_team("t1", TeamState(team_id="t1", name="Persistent"))
            be1.add_solve("t1", "c1", "main", SolveState(solved_at="now"))
            del be1

            be2 = SQLiteBackend(db)
            assert be2.get_team("t1").name == "Persistent"
            assert be2.count_solves_for_challenge("c1", ("main",)) == 1
            # Instances are ephemeral — lost after restart
            assert be2.get_instance("any") is None
        finally:
            os.unlink(db)
