"""Tests for ``GET /activities/timeseries`` — per-team event histogram
backing the chart strip on the activity page."""

from __future__ import annotations

import time
from datetime import datetime, timezone
from unittest.mock import patch

from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import ActivityState
from ctfy.tests.conftest import mint_team


def _bootstrap(env_manager, *, clock=None):
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    if clock is not None:
        app.state.ctfy.clock = clock
    return app, backend


_FIXED_NOW = 1777681800.0  # 2026-04-27 12:30:00 UTC


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _add_activity(
    backend: InMemoryBackend,
    *,
    team_id: str,
    event: str,
    ts: float,
    aid: str | None = None,
    user_id: str | None = None,
) -> None:
    """Seed an activity row. ``user_id`` defaults to ``team_id`` for
    legacy callers; new tests should pass it explicitly so the
    actor_id matches the authenticated viewer's user_id.
    """
    actor_id = user_id if user_id is not None else team_id
    backend.add_activity(
        ActivityState(
            id=aid or f"{event}-{ts}",
            timestamp=_iso(ts),
            event=event,
            team_id=team_id,
            team_name=team_id,
            user_id=actor_id,
            actor_id=actor_id,
            actor_name=team_id,
            actor_type="team",
        )
    )


def test_activity_timeseries_requires_auth(mock_env_manager):
    app, _ = _bootstrap(mock_env_manager)
    c = TestClient(app)
    r = c.get("/api/v1/activities/timeseries")
    assert r.status_code in (401, 403)


def test_activity_timeseries_default_window_24h_bucket_1h(mock_env_manager):
    app, backend = _bootstrap(mock_env_manager)
    user = mint_team(backend, name="t1", email="t1@example.test")
    c = TestClient(app)
    r = c.get("/api/v1/activities/timeseries", headers=user.headers)
    assert r.status_code == 200
    body = r.json()
    assert len(body["buckets"]) == 24
    assert body["events"] == []
    assert all(b["counts"] == {} for b in body["buckets"])


def test_activity_timeseries_buckets_count_per_event_type(mock_env_manager):
    app, backend = _bootstrap(mock_env_manager, clock=lambda: _FIXED_NOW)
    user = mint_team(backend, name="t1", email="t1@example.test")

    now = _FIXED_NOW
    _add_activity(backend, team_id=user.team_id, user_id=user.user_id, event="flag_correct", ts=now - 600)
    _add_activity(backend, team_id=user.team_id, user_id=user.user_id, event="flag_correct", ts=now - 300)
    _add_activity(backend, team_id=user.team_id, user_id=user.user_id, event="flag_wrong", ts=now - 120)
    # An event 3h ago — outside a 1h window.
    _add_activity(backend, team_id=user.team_id, user_id=user.user_id, event="flag_wrong", ts=now - 3 * 3600)

    c = TestClient(app)
    r = c.get(
        "/api/v1/activities/timeseries",
        params={"window": 3600, "bucket": 3600},
        headers=user.headers,
    )
    body = r.json()
    assert len(body["buckets"]) == 1
    bucket = body["buckets"][0]
    assert bucket["counts"]["flag_correct"] == 2
    assert bucket["counts"]["flag_wrong"] == 1
    # ``events`` is the sorted union of types that landed.
    assert body["events"] == ["flag_correct", "flag_wrong"]


def test_activity_timeseries_isolates_teams(mock_env_manager):
    """A team's histogram must not include another team's events."""
    app, backend = _bootstrap(mock_env_manager)
    a = mint_team(backend, name="ta", email="a@example.test")
    b = mint_team(backend, name="tb", email="b@example.test")

    now = time.time()
    _add_activity(backend, team_id=a.team_id, user_id=a.user_id, event="flag_correct", ts=now - 60)
    _add_activity(backend, team_id=b.team_id, user_id=b.user_id, event="flag_correct", ts=now - 60)

    c = TestClient(app)
    r = c.get(
        "/api/v1/activities/timeseries",
        params={"window": 3600, "bucket": 3600},
        headers=a.headers,
    )
    body = r.json()
    # Only team a's event is counted.
    assert sum(sum(b["counts"].values()) for b in body["buckets"]) == 1
