"""TDD: GET /me/inbox — unified pending invites/requests view.

Surfaces three collections relevant to the calling user:

* ``incoming_invites`` — pending direct invites where the calling
  user is the named target. Their accept/decline lives at
  ``/competitions/{id}/invites/{invite_id}/accept|decline``.
* ``outgoing_requests`` — pending join_request invites the calling
  user opened. Useful for "did the captain see this yet?" plus
  cancellation in a future pass.
* ``captain_requests`` — pending join_request invites against any
  team the calling user captains. Approve/reject lives at
  ``/competitions/{id}/invites/{invite_id}/approve|reject``.

Revoked / expired / used-up rows never appear; only ``active``
invites land in the inbox.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import CompetitionState
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team


@pytest.fixture
def world():
    """Captain ``cap`` of team ``Pwners``; aspirant ``alice``;
    bystander ``bob``. All three start with no pending invites/
    requests; tests opt in by hitting the relevant routes.
    """
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    backend.put_competition(
        CompetitionState(
            competition_id="spring",
            title="Spring CTF 2026",
            starts_at="",
            ends_at="2099-01-01T00:00:00Z",
            challenge_ids=[],
            created_at="2026-01-01T00:00:00Z",
        )
    )
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)

    cap = mint_team(backend, name="Cap", email="cap@x", display_name="Cap")
    pwners = backend.create_team_for_competition(
        user_id=cap.user_id,
        competition_id="spring",
        team_name="Pwners",
        description="",
        now_iso="2026-01-01T00:00:00Z",
        joined_via="create",
    )
    alice = mint_team(
        backend, name="Alice", email="alice@x", display_name="Alice"
    )
    bob = mint_team(backend, name="Bob", email="bob@x", display_name="Bob")
    return {
        "client": TestClient(app),
        "backend": backend,
        "cap": cap,
        "alice": alice,
        "bob": bob,
        "team_id": pwners.team_id,
    }


def test_empty_inbox_returns_three_empty_collections(world):
    r = world["client"].get(
        "/api/v1/me/inbox", headers=world["alice"].headers
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["incoming_invites"] == []
    assert body["outgoing_requests"] == []
    assert body["captain_requests"] == []


def test_incoming_direct_invite_surfaces_for_target(world):
    # Captain invites Alice → Alice's inbox shows it (Bob's doesn't).
    world["client"].post(
        "/api/v1/competitions/spring/invites/direct",
        json={"email": "alice@x"},
        headers=world["cap"].headers,
    )

    alice_inbox = world["client"].get(
        "/api/v1/me/inbox", headers=world["alice"].headers
    ).json()
    assert len(alice_inbox["incoming_invites"]) == 1
    row = alice_inbox["incoming_invites"][0]
    assert row["competition_id"] == "spring"
    assert row["competition_title"] == "Spring CTF 2026"
    assert row["team_id"] == world["team_id"]
    assert row["team_name"] == "Pwners"
    assert row["captain_display_name"] == "Cap"
    assert row["invite_id"]

    bob_inbox = world["client"].get(
        "/api/v1/me/inbox", headers=world["bob"].headers
    ).json()
    assert bob_inbox["incoming_invites"] == []


def test_outgoing_join_request_surfaces_for_requester(world):
    world["client"].post(
        f"/api/v1/competitions/spring/teams/{world['team_id']}/join-request",
        headers=world["alice"].headers,
    )

    alice_inbox = world["client"].get(
        "/api/v1/me/inbox", headers=world["alice"].headers
    ).json()
    assert len(alice_inbox["outgoing_requests"]) == 1
    row = alice_inbox["outgoing_requests"][0]
    assert row["team_id"] == world["team_id"]
    assert row["team_name"] == "Pwners"
    assert row["competition_title"] == "Spring CTF 2026"


def test_join_request_surfaces_in_captains_inbox(world):
    world["client"].post(
        f"/api/v1/competitions/spring/teams/{world['team_id']}/join-request",
        headers=world["alice"].headers,
    )

    cap_inbox = world["client"].get(
        "/api/v1/me/inbox", headers=world["cap"].headers
    ).json()
    assert len(cap_inbox["captain_requests"]) == 1
    row = cap_inbox["captain_requests"][0]
    assert row["requester_user_id"] == world["alice"].user_id
    assert row["requester_display_name"] == "Alice"
    assert row["competition_title"] == "Spring CTF 2026"
    assert row["team_id"] == world["team_id"]

    # Bystander Bob doesn't see it.
    bob_inbox = world["client"].get(
        "/api/v1/me/inbox", headers=world["bob"].headers
    ).json()
    assert bob_inbox["captain_requests"] == []


def test_revoked_direct_invite_disappears_from_inbox(world):
    mint = world["client"].post(
        "/api/v1/competitions/spring/invites/direct",
        json={"email": "alice@x"},
        headers=world["cap"].headers,
    )
    invite_id = mint.json()["invite_id"]
    world["client"].delete(
        f"/api/v1/competitions/spring/invites/{invite_id}",
        headers=world["cap"].headers,
    )
    inbox = world["client"].get(
        "/api/v1/me/inbox", headers=world["alice"].headers
    ).json()
    assert inbox["incoming_invites"] == []


def test_used_invite_does_not_appear(world):
    # Mint + accept → invite's use_count hits max → drops out of inbox.
    mint = world["client"].post(
        "/api/v1/competitions/spring/invites/direct",
        json={"email": "alice@x"},
        headers=world["cap"].headers,
    )
    invite_id = mint.json()["invite_id"]
    accept = world["client"].post(
        f"/api/v1/competitions/spring/invites/{invite_id}/accept",
        headers=world["alice"].headers,
    )
    assert accept.status_code == 200
    inbox = world["client"].get(
        "/api/v1/me/inbox", headers=world["alice"].headers
    ).json()
    assert inbox["incoming_invites"] == []


def test_inbox_rejects_unauth(world):
    r = world["client"].get("/api/v1/me/inbox")
    assert r.status_code in (401, 403)
