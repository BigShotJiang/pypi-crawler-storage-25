"""End-to-end tests for local email+password authentication.

Parallels :mod:`test_oauth` — exercises the HTTP layer (not backend
internals) against an :class:`InMemoryBackend`. Uses the
:func:`register_team` / :func:`password_login` helpers from conftest.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.server.app import create_app
from ctfy.tests.conftest import (
    oauth_login,
    password_login,
    register_team,
)


@pytest.fixture
def client(backend, mock_env_manager):
    """Fresh client with password auth enabled (default). No OAuth providers."""
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="127.0.0.1", backend=backend)
    return TestClient(app)


@pytest.fixture
def admin_emails(client):
    def _set(*emails: str) -> None:
        client.app.state.ctfy.super_admin_emails_lower = {
            e.lower() for e in emails
        }

    return _set


# ---------------------------------------------------------------------------
# Provider listing — the extra password_auth flag
# ---------------------------------------------------------------------------


class TestProvidersResponse:
    def test_response_includes_password_auth_flag(self, client):
        r = client.get("/api/v1/auth/providers")
        assert r.status_code == 200
        body = r.json()
        assert "password_auth" in body
        assert body["password_auth"]["enabled"] is True

    def test_disabled_flag_propagates(self, client):
        client.app.state.ctfy.config = client.app.state.ctfy.config.model_copy(
            update={"password_auth_enabled": False}
        )
        r = client.get("/api/v1/auth/providers")
        assert r.json()["password_auth"]["enabled"] is False


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


class TestRegister:
    def test_register_creates_user_and_token(self, client, backend):
        tok = register_team(client, email="alice@example.com", display_name="Alice")
        assert tok.startswith("pt_")
        me = client.get("/api/v1/me", headers={"Authorization": f"Bearer {tok}"}).json()
        assert me["email"] == "alice@example.com"
        assert "password" in me["providers"]
        assert me["token_kind"] == "user"
        # No auto-team — registration mints the user only. Teams are
        # per-comp now and the user joins one when registering for a
        # competition.
        assert backend.list_teams() == []
        assert me["competition_teams"] == []

    def test_duplicate_email_returns_409(self, client):
        register_team(client, email="alice@example.com")
        r = client.post(
            "/api/v1/auth/register",
            json={"email": "alice@example.com", "password": "another-strong-pw"},
        )
        assert r.status_code == 409

    def test_case_insensitive_duplicate(self, client):
        register_team(client, email="alice@example.com")
        r = client.post(
            "/api/v1/auth/register",
            json={"email": "ALICE@example.com", "password": "another-strong-pw"},
        )
        assert r.status_code == 409

    def test_oauth_email_collision_returns_409(self, client):
        # Install fake OAuth, register via OAuth with an email, then
        # attempt to register the same email via password — must fail
        # (force user to add password through Settings instead).
        from ctfy.tests.conftest import install_fake_oauth

        install_fake_oauth(client)
        oauth_login(client, "github", email="alice@example.com")
        r = client.post(
            "/api/v1/auth/register",
            json={"email": "alice@example.com", "password": "strong-password-1"},
        )
        assert r.status_code == 409

    def test_short_password_rejected(self, client):
        r = client.post(
            "/api/v1/auth/register",
            json={"email": "alice@example.com", "password": "abc"},
        )
        assert r.status_code == 422

    def test_disabled_flag_returns_404(self, client):
        client.app.state.ctfy.config = client.app.state.ctfy.config.model_copy(
            update={"password_auth_enabled": False}
        )
        r = client.post(
            "/api/v1/auth/register",
            json={"email": "alice@example.com", "password": "strong-password-1"},
        )
        assert r.status_code == 404


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------


class TestLogin:
    def test_login_round_trip(self, client):
        register_team(client, email="alice@example.com", password="pw-horse-battery-1")
        tok = password_login(client, email="alice@example.com", password="pw-horse-battery-1")
        r = client.get("/api/v1/me", headers={"Authorization": f"Bearer {tok}"})
        assert r.status_code == 200
        assert r.json()["email"] == "alice@example.com"

    def test_login_is_case_insensitive_on_email(self, client):
        register_team(client, email="alice@example.com", password="pw-horse-battery-1")
        tok = password_login(client, email="ALICE@Example.COM", password="pw-horse-battery-1")
        assert tok.startswith("pt_")

    def test_wrong_password_401(self, client):
        register_team(client, email="alice@example.com", password="pw-horse-battery-1")
        r = client.post(
            "/api/v1/auth/login",
            json={"email": "alice@example.com", "password": "WRONG"},
        )
        assert r.status_code == 401

    def test_unknown_email_401(self, client):
        r = client.post(
            "/api/v1/auth/login",
            json={"email": "ghost@example.com", "password": "whatever-long"},
        )
        assert r.status_code == 401


# ---------------------------------------------------------------------------
# Change / set password
# ---------------------------------------------------------------------------


class TestChangePassword:
    def test_change_requires_current(self, client):
        tok = register_team(client, email="alice@example.com", password="old-password-1")
        r = client.post(
            "/api/v1/auth/password",
            json={"new_password": "new-password-2"},
            headers={"Authorization": f"Bearer {tok}"},
        )
        assert r.status_code == 401

    def test_change_rotates_hash(self, client):
        tok = register_team(client, email="alice@example.com", password="old-password-1")
        r = client.post(
            "/api/v1/auth/password",
            json={"current_password": "old-password-1", "new_password": "new-password-2"},
            headers={"Authorization": f"Bearer {tok}"},
        )
        assert r.status_code == 200
        # Old password no longer works…
        r = client.post(
            "/api/v1/auth/login",
            json={"email": "alice@example.com", "password": "old-password-1"},
        )
        assert r.status_code == 401
        # …new one does.
        r = client.post(
            "/api/v1/auth/login",
            json={"email": "alice@example.com", "password": "new-password-2"},
        )
        assert r.status_code == 200

    def test_oauth_user_can_attach_password(self, client):
        from ctfy.tests.conftest import install_fake_oauth

        install_fake_oauth(client)
        tok = oauth_login(client, "github", email="alice@example.com")
        r = client.post(
            "/api/v1/auth/password",
            json={"new_password": "freshly-minted-pw"},
            headers={"Authorization": f"Bearer {tok}"},
        )
        assert r.status_code == 200
        # Password login now works with the OAuth email.
        r = client.post(
            "/api/v1/auth/login",
            json={"email": "alice@example.com", "password": "freshly-minted-pw"},
        )
        assert r.status_code == 200
        # /me shows both providers.
        me = client.get("/api/v1/me", headers={"Authorization": f"Bearer {tok}"}).json()
        assert "password" in me["providers"]
        assert "github" in me["providers"]


# ---------------------------------------------------------------------------
# Remove password
# ---------------------------------------------------------------------------


class TestRemovePassword:
    def test_blocked_when_only_identity(self, client):
        tok = register_team(client, email="alice@example.com")
        r = client.delete("/api/v1/auth/password", headers={"Authorization": f"Bearer {tok}"})
        assert r.status_code == 409

    def test_ok_with_oauth_linked(self, client):
        from ctfy.tests.conftest import install_fake_oauth

        install_fake_oauth(client)
        # Register with OAuth first, then attach password, then remove.
        tok = oauth_login(client, "github", email="alice@example.com")
        client.post(
            "/api/v1/auth/password",
            json={"new_password": "removable-pw"},
            headers={"Authorization": f"Bearer {tok}"},
        )
        r = client.delete("/api/v1/auth/password", headers={"Authorization": f"Bearer {tok}"})
        assert r.status_code == 200
        # Password login no longer works.
        r = client.post(
            "/api/v1/auth/login",
            json={"email": "alice@example.com", "password": "removable-pw"},
        )
        assert r.status_code == 401


# ---------------------------------------------------------------------------
# First-user bootstrap + anti-spoofing
# ---------------------------------------------------------------------------


class TestFirstUserAdmin:
    def test_first_registration_becomes_admin(self, client):
        tok = register_team(client, email="boss@example.com")
        me = client.get("/api/v1/me", headers={"Authorization": f"Bearer {tok}"}).json()
        assert me["is_admin"] is True

    def test_second_registration_is_not_admin(self, client, admin_emails):
        admin_emails("bob@example.com")  # allowlist set up early
        register_team(client, email="alice@example.com")  # first user → admin
        tok = register_team(client, email="bob@example.com")  # second user
        me = client.get("/api/v1/me", headers={"Authorization": f"Bearer {tok}"}).json()
        # Even though bob is in CTFY_SUPER_ADMIN_EMAILS, password
        # registration does not verify email ownership, so no admin grant.
        assert me["is_admin"] is False


class TestAntiSpoofing:
    def test_password_user_with_admin_email_is_not_admin(self, client, admin_emails):
        admin_emails("admin@corp.com")
        # Seed an unrelated first user so admin@corp.com is not first.
        register_team(client, email="alice@example.com")
        tok = register_team(client, email="admin@corp.com")
        me = client.get("/api/v1/me", headers={"Authorization": f"Bearer {tok}"}).json()
        assert me["is_admin"] is False

    def test_oauth_link_after_password_grants_admin(self, client, admin_emails):
        from ctfy.tests.conftest import install_fake_oauth

        install_fake_oauth(client)
        admin_emails("admin@corp.com")
        register_team(client, email="alice@example.com")  # first, absorbs bootstrap
        # Second user registers with admin email via password — not admin.
        pwd_tok = register_team(client, email="admin@corp.com")
        me = client.get("/api/v1/me", headers={"Authorization": f"Bearer {pwd_tok}"}).json()
        assert me["is_admin"] is False

        # Link a GitHub identity with the same verified email. The OAuth
        # callback's email-auto-merge grafts the identity onto the
        # existing password team, and the admin re-apply flips is_admin.
        oauth_login(client, "github", email="admin@corp.com")
        # Re-check via the original password token — same team, now admin.
        me = client.get("/api/v1/me", headers={"Authorization": f"Bearer {pwd_tok}"}).json()
        assert me["is_admin"] is True


# ---------------------------------------------------------------------------
# Identities listing includes password identity
# ---------------------------------------------------------------------------


class TestIdentitiesListing:
    def test_password_identity_appears_in_list(self, client):
        tok = register_team(client, email="alice@example.com", display_name="Alice")
        r = client.get("/api/v1/auth/identities", headers={"Authorization": f"Bearer {tok}"})
        assert r.status_code == 200
        rows = r.json()["items"]
        assert len(rows) == 1
        row = rows[0]
        assert row["provider"] == "password"
        assert row["provider_email"] == "alice@example.com"
