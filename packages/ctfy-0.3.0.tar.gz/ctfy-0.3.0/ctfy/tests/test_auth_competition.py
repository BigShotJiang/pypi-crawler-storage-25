"""TDD: ``make_get_current_team_for_competition`` auth dependency.

Phase 2d of the per-competition team refactor. This dependency
factory backs every comp-scoped write route (Phase 3): hitting
``POST /competitions/{id}/teams/{tid}/invites`` resolves
``competition_id`` from the path, walks token → user →
``get_membership_for_competition(user_id, competition_id)`` → team,
and returns 403 with a typed body when the user has no team for
that competition (the frontend renders the in-page Solo / Create /
Join card off this signal).
"""

from __future__ import annotations

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import TeamState
from ctfy.server.auth import make_get_current_team_for_competition
from ctfy.tests.conftest import mint_team


@pytest.fixture
def world():
    """A throwaway FastAPI app whose only route exercises the
    dependency. Lets us assert HTTP shape (status + body) without
    pulling in the full ``create_app`` machinery."""
    backend = InMemoryBackend()
    dep = make_get_current_team_for_competition(backend)
    app = FastAPI()

    @app.get("/competitions/{competition_id}/_probe")
    def probe(team: TeamState = Depends(dep)):
        return {
            "team_id": team.team_id,
            "competition_id": team.competition_id,
            "name": team.name,
        }

    return TestClient(app), backend


def test_returns_403_with_typed_body_when_user_has_no_team_for_comp(world):
    client, backend = world
    user = mint_team(backend, name="solo", email="s@x")
    r = client.get(
        "/competitions/spring-ctf/_probe",
        headers=user.headers,
    )
    assert r.status_code == 403
    body = r.json()
    assert body["detail"]["error"] == "not_registered"
    assert body["detail"]["competition_id"] == "spring-ctf"


def test_returns_team_when_user_is_registered(world):
    client, backend = world
    user = mint_team(backend, name="member", email="m@x")
    backend.create_team_for_competition(
        user_id=user.user_id,
        competition_id="spring-ctf",
        team_name="Pwners",
        now_iso="2026-01-01T00:00:00Z",
    )
    r = client.get(
        "/competitions/spring-ctf/_probe",
        headers=user.headers,
    )
    assert r.status_code == 200
    body = r.json()
    assert body["competition_id"] == "spring-ctf"
    assert body["name"] == "Pwners"


def test_user_can_be_on_different_teams_in_different_competitions(world):
    client, backend = world
    user = mint_team(backend, name="multi", email="multi@x")
    backend.create_team_for_competition(
        user_id=user.user_id,
        competition_id="spring",
        team_name="Spring Team",
        now_iso="2026-01-01T00:00:00Z",
    )
    backend.create_team_for_competition(
        user_id=user.user_id,
        competition_id="summer",
        team_name="Summer Team",
        now_iso="2026-06-01T00:00:00Z",
    )
    spring = client.get(
        "/competitions/spring/_probe", headers=user.headers
    ).json()
    summer = client.get(
        "/competitions/summer/_probe", headers=user.headers
    ).json()
    assert spring["name"] == "Spring Team"
    assert summer["name"] == "Summer Team"
    assert spring["team_id"] != summer["team_id"]


def test_returns_403_when_no_bearer_token(world):
    client, _ = world
    r = client.get("/competitions/spring-ctf/_probe")
    assert r.status_code in (401, 403)


def test_returns_403_when_bearer_invalid(world):
    client, _ = world
    r = client.get(
        "/competitions/spring-ctf/_probe",
        headers={"Authorization": "Bearer pt_not_a_real_token"},
    )
    assert r.status_code == 403
