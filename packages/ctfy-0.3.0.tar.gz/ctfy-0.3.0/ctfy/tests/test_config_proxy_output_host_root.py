"""Tests for the per-instance transparent sidecar fleet.

Covers:

* ``CTFY_PROXY_OUTPUT_HOST_ROOT`` config field — when set, sidecar
  output goes to a literal absolute path that the node container and
  the docker daemon both see at the same location (1:1 bind mount).
  ``to_host_path`` translation is skipped entirely. Without it, the
  walker fix from PR #384 reads from a path the daemon-spawned sidecar
  never wrote to (cf. named-volume invisibility).

* ``start_proxy_sidecars`` — one transparent mitmproxy sidecar per
  challenge container, joined to its netns via ``--network container:``,
  with the right caps + ``CTFY_INTERCEPT_PORTS`` env so iptables rules
  install correctly inside the entrypoint.

* ``start_pcap_sidecars`` — runs alongside, captures the same netns
  with plain tcpdump (entrypoint override + ``NET_RAW``/``NET_ADMIN``).
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import docker.errors

from ctfy.core.config import CtfyConfig
from ctfy.providers.docker_provider import utils as utils_mod
from ctfy.providers.docker_provider.utils import (
    start_pcap_sidecars,
    start_proxy_sidecars,
)


class TestConfigField:
    def test_default_is_none(self):
        c = CtfyConfig()
        assert c.proxy_output_host_root is None

    def test_set_via_constructor_resolves_to_path(self):
        c = CtfyConfig(proxy_output_host_root="/var/lib/ctfy/proxy")
        assert c.proxy_output_host_root == Path("/var/lib/ctfy/proxy")

    def test_set_via_from_env(self):
        c = CtfyConfig.from_env(env={"CTFY_PROXY_OUTPUT_HOST_ROOT": "/srv/ctfy/proxy"})
        assert c.proxy_output_host_root == Path("/srv/ctfy/proxy")

    def test_empty_env_value_keeps_default_none(self):
        # ``from_env`` skips empty strings — the field stays at its default.
        c = CtfyConfig.from_env(env={"CTFY_PROXY_OUTPUT_HOST_ROOT": ""})
        assert c.proxy_output_host_root is None


def _build_docker_client(*, exposed_ports: list[str]) -> MagicMock:
    """Mock docker client that:

    * pretends every container the function tries to remove is
      already gone (NotFound),
    * returns a target container with the requested
      ``Config.ExposedPorts`` shape when ``containers.get`` is asked
      about the *target* (not a sidecar name we attempted to remove),
    * returns a fresh MagicMock for every ``containers.run`` so we can
      inspect kwargs per-call.
    """
    client = MagicMock()
    target = MagicMock()
    target.attrs = {"Config": {"ExposedPorts": {p: {} for p in exposed_ports}}}

    def _containers_get(name: str):
        if name.startswith("target-"):
            return target
        # Anything else is one of our own sidecar names being removed
        # before reuse — pretend nothing was there.
        raise docker.errors.NotFound("absent")

    client.containers.get.side_effect = _containers_get

    spawned = MagicMock()
    spawned.exec_run.return_value = (0, b"")
    client.containers.run.return_value = spawned
    return client


def _stub_sleep(monkeypatch):
    """Cert-warmup waits up to 30s; test must not actually sleep."""
    monkeypatch.setattr(utils_mod.time, "sleep", lambda *_a, **_kw: None)


class TestProxySidecarsBindSource:
    def test_uses_literal_path_when_host_root_configured(self, tmp_path, monkeypatch):
        """``proxy_output_host_root`` set → bind source is the literal
        absolute output path, no ``to_host_path`` rewrite."""
        _stub_sleep(monkeypatch)
        # ``host_project_root`` would corrupt the path if to_host_path
        # were accidentally invoked — sentinel.
        config = CtfyConfig(
            project_root=tmp_path,
            host_project_root="/wrong/host/root",
            proxy_output_host_root=tmp_path / "proxy_root",
        )
        output_path = tmp_path / "proxy_root" / "inst-A"
        client = _build_docker_client(exposed_ports=["80/tcp"])

        state = start_proxy_sidecars(
            client,
            "inst-A",
            ["target-app"],
            config=config,
            proxy_output_dir=output_path,
        )

        assert state.proxy_container_names == ["pentest_inst-A_proxy_target-app"]

        # Two ``containers.run`` calls happen: the cert warmer (in
        # regular mode) + the actual transparent sidecar. We care
        # about the latter — find it by ``network_mode``.
        proxy_call = next(
            c
            for c in client.containers.run.call_args_list
            if c.kwargs.get("network_mode") == "container:target-app"
        )
        bind_sources = {
            src for src, spec in proxy_call.kwargs["volumes"].items() if spec["bind"] == "/output"
        }
        assert bind_sources == {str(output_path)}

    def test_falls_back_to_to_host_path_when_host_root_unset(self, tmp_path, monkeypatch):
        """Bare-metal: ``to_host_path`` keeps doing its
        ``host_project_root`` rewrite."""
        _stub_sleep(monkeypatch)
        config = CtfyConfig(
            project_root=tmp_path,
            host_project_root="/host/root",
        )
        output_path = tmp_path / "data" / "instances" / "inst-B" / "proxy"
        client = _build_docker_client(exposed_ports=["80/tcp"])

        start_proxy_sidecars(
            client,
            "inst-B",
            ["target-app"],
            config=config,
            proxy_output_dir=output_path,
        )

        proxy_call = next(
            c
            for c in client.containers.run.call_args_list
            if c.kwargs.get("network_mode") == "container:target-app"
        )
        bind_sources = {
            src for src, spec in proxy_call.kwargs["volumes"].items() if spec["bind"] == "/output"
        }
        assert bind_sources == {"/host/root/data/instances/inst-B/proxy"}


class TestProxySidecarsBehavior:
    def test_one_sidecar_per_target_with_intercept_ports(self, tmp_path, monkeypatch):
        """Two challenge containers → two sidecars; each gets the netns
        of its target and the right ports passed via env."""
        _stub_sleep(monkeypatch)
        config = CtfyConfig(
            project_root=tmp_path,
            proxy_output_host_root=tmp_path / "proxy_root",
        )
        client = MagicMock()
        target_a = MagicMock()
        target_a.attrs = {"Config": {"ExposedPorts": {"80/tcp": {}, "443/tcp": {}}}}
        target_b = MagicMock()
        target_b.attrs = {"Config": {"ExposedPorts": {"5432/tcp": {}, "9999/udp": {}}}}

        def _containers_get(name: str):
            if name == "target-app":
                return target_a
            if name == "target-db":
                return target_b
            raise docker.errors.NotFound("absent")

        client.containers.get.side_effect = _containers_get

        spawned = MagicMock()
        spawned.exec_run.return_value = (0, b"")
        client.containers.run.return_value = spawned

        state = start_proxy_sidecars(
            client,
            "inst-multi",
            ["target-app", "target-db"],
            config=config,
            proxy_output_dir=tmp_path / "proxy_root" / "inst-multi",
        )

        # One sidecar per target, plus the cert warmer.
        sidecar_calls = [
            c
            for c in client.containers.run.call_args_list
            if str(c.kwargs.get("network_mode", "")).startswith("container:")
        ]
        assert len(sidecar_calls) == 2
        assert state.proxy_container_names == [
            "pentest_inst-multi_proxy_target-app",
            "pentest_inst-multi_proxy_target-db",
        ]

        # Per-target invariants
        per_target = {c.kwargs["network_mode"]: c.kwargs for c in sidecar_calls}
        # Caps required for iptables + AF_PACKET inside the shared netns.
        for kw in per_target.values():
            assert set(kw["cap_add"]) == {"NET_ADMIN", "NET_RAW"}
            # No entrypoint override — image's transparent entrypoint runs.
            assert "entrypoint" not in kw or kw["entrypoint"] is None
        # Port lists come from each target's ``ExposedPorts``, TCP only.
        assert per_target["container:target-app"]["environment"][
            "CTFY_INTERCEPT_PORTS"
        ] == "80,443"
        assert per_target["container:target-db"]["environment"][
            "CTFY_INTERCEPT_PORTS"
        ] == "5432"

    def test_target_with_no_tcp_ports_is_skipped(self, tmp_path, monkeypatch):
        """A worker container with no TCP listener gets no proxy
        sidecar — there's nothing to intercept."""
        _stub_sleep(monkeypatch)
        config = CtfyConfig(
            project_root=tmp_path,
            proxy_output_host_root=tmp_path / "proxy_root",
        )
        client = _build_docker_client(exposed_ports=[])  # no exposed ports

        state = start_proxy_sidecars(
            client,
            "inst-quiet",
            ["target-worker"],
            config=config,
            proxy_output_dir=tmp_path / "proxy_root" / "inst-quiet",
        )
        assert state.proxy_container_names == []

    def test_empty_target_list_returns_empty_state(self, tmp_path):
        """No targets → no work, no exception, empty state."""
        config = CtfyConfig(
            project_root=tmp_path,
            proxy_output_host_root=tmp_path / "proxy_root",
        )
        client = MagicMock()
        state = start_proxy_sidecars(
            client,
            "inst-none",
            [],
            config=config,
            proxy_output_dir=tmp_path / "proxy_root" / "inst-none",
        )
        assert state.proxy_container_names == []
        assert state.cert_volume == ""
        # No docker calls at all
        client.containers.run.assert_not_called()


class TestPcapSidecarBindSource:
    def test_uses_literal_path_when_host_root_configured(self, tmp_path):
        config = CtfyConfig(
            project_root=tmp_path,
            host_project_root="/wrong/host/root",
            proxy_output_host_root=tmp_path / "proxy_root",
        )
        output_path = tmp_path / "proxy_root" / "inst-P"
        output_path.mkdir(parents=True)

        client = MagicMock()
        client.containers.get.side_effect = docker.errors.NotFound("absent")
        client.containers.run.return_value = MagicMock()

        names = start_pcap_sidecars(
            client,
            "inst-P",
            ["target-svc"],
            image="ctfy-mitmproxy:test",
            output_path=output_path,
            config=config,
        )
        assert len(names) == 1

        call = client.containers.run.call_args
        # The image's mitmproxy entrypoint must be overridden to plain
        # tcpdump (otherwise it would exec mitmdump and ignore command).
        assert call.kwargs["entrypoint"] == ["tcpdump"]
        # tcpdump needs CAP_NET_RAW for the capture socket and
        # CAP_NET_ADMIN for ``-i any`` on the shared netns.
        assert set(call.kwargs["cap_add"]) == {"NET_RAW", "NET_ADMIN"}
        bind_sources = {
            src
            for src, spec in (call.kwargs["volumes"] or {}).items()
            if spec["bind"].startswith("/pcap") or spec["bind"] == "/pcap"
        }
        # pcap_root is ``output_path / "pcap"`` and the bind source should be
        # exactly that absolute path, not a ``to_host_path`` rewrite of it.
        assert bind_sources == {str(output_path / "pcap")}

    def test_falls_back_to_to_host_path_when_host_root_unset(self, tmp_path):
        config = CtfyConfig(
            project_root=tmp_path,
            host_project_root="/host/root",
        )
        output_path = tmp_path / "data" / "instances" / "inst-Q" / "proxy"
        output_path.mkdir(parents=True)

        client = MagicMock()
        client.containers.get.side_effect = docker.errors.NotFound("absent")
        client.containers.run.return_value = MagicMock()

        start_pcap_sidecars(
            client,
            "inst-Q",
            ["target-svc"],
            image="ctfy-mitmproxy:test",
            output_path=output_path,
            config=config,
        )

        call = client.containers.run.call_args
        bind_sources = {
            src
            for src, spec in (call.kwargs["volumes"] or {}).items()
            if spec["bind"] == "/pcap"
        }
        expected = "/host/root/data/instances/inst-Q/proxy/pcap"
        assert bind_sources == {expected}
