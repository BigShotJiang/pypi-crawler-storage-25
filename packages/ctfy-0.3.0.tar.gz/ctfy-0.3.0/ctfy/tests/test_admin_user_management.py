"""Tests for the super-admin user management surface.

Two endpoints:

* ``GET /api/v1/admin/users`` — admin-or-better can read; carries
  ``role`` + ``promoted_by`` / ``promoted_at`` audit fields.
* ``PATCH /api/v1/admin/users/{user_id}/role`` — super-admin only.
  Promotes / demotes between ``user`` and ``admin``; the
  ``super_admin`` tier is intentionally not settable via the API
  (env-anchored).

Auth gates are the security-critical surface — anonymous / member /
agent / regular admin must all bounce on the PATCH route.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from ctfy.tests.conftest import mint_team


def _get_user_role(client: TestClient, user_id: str, super_admin_headers: dict) -> str:
    rows = client.get(
        "/api/v1/admin/users", headers=super_admin_headers
    ).json()["items"]
    by_id = {r["user_id"]: r for r in rows}
    return by_id[user_id]["role"]


# ---------------------------------------------------------------------------
# GET /admin/users — admin-or-better list with audit fields
# ---------------------------------------------------------------------------


class TestListAdminUsers:
    def test_anonymous_rejected(self, client):
        assert client.get("/api/v1/admin/users").status_code in (401, 403)

    def test_member_rejected(self, client, backend):
        member = mint_team(backend, name="m", email="m@example.test")
        r = client.get("/api/v1/admin/users", headers=member.headers)
        assert r.status_code in (401, 403)

    def test_admin_can_list(self, client, admin_team):
        r = client.get("/api/v1/admin/users", headers=admin_team.headers)
        assert r.status_code == 200
        items = r.json()["items"]
        me = next(i for i in items if i["user_id"] == admin_team.user_id)
        assert me["role"] == "admin"
        assert "email" in me
        assert "promoted_by" in me
        assert "promoted_at" in me

    def test_super_admin_can_list(self, client, super_admin_team):
        r = client.get(
            "/api/v1/admin/users", headers=super_admin_team.headers
        )
        assert r.status_code == 200
        me = next(
            i
            for i in r.json()["items"]
            if i["user_id"] == super_admin_team.user_id
        )
        assert me["role"] == "super_admin"


# ---------------------------------------------------------------------------
# GET /admin/users/{user_id} — single-user lookup (skip the list scan)
# ---------------------------------------------------------------------------


class TestGetAdminUser:
    def test_admin_can_get_single_user(self, client, admin_team, backend):
        target = mint_team(backend, name="target", email="t@example.test")
        r = client.get(
            f"/api/v1/admin/users/{target.user_id}",
            headers=admin_team.headers,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["user_id"] == target.user_id
        assert body["display_name"] == "target"
        assert body["email"] == "t@example.test"
        assert body["role"] == "user"

    def test_member_rejected(self, client, backend):
        member = mint_team(backend, name="m", email="m@example.test")
        r = client.get(
            f"/api/v1/admin/users/{member.user_id}", headers=member.headers
        )
        assert r.status_code in (401, 403)

    def test_anonymous_rejected(self, client, backend):
        target = mint_team(backend, name="t", email="t@example.test")
        r = client.get(f"/api/v1/admin/users/{target.user_id}")
        assert r.status_code in (401, 403)

    def test_unknown_user_404(self, client, admin_team):
        r = client.get(
            "/api/v1/admin/users/no-such-user", headers=admin_team.headers
        )
        assert r.status_code == 404


# ---------------------------------------------------------------------------
# PATCH /admin/users/{user_id}/role — super-admin only mutation
# ---------------------------------------------------------------------------


class TestSetUserRoleAuth:
    @pytest.fixture
    def victim(self, backend):
        return mint_team(backend, name="victim", email="v@example.test")

    def test_anonymous_rejected(self, client, victim):
        r = client.patch(
            f"/api/v1/admin/users/{victim.user_id}/role",
            json={"role": "admin"},
        )
        assert r.status_code in (401, 403)

    def test_member_rejected(self, client, backend, victim):
        member = mint_team(backend, name="m", email="m@example.test")
        r = client.patch(
            f"/api/v1/admin/users/{victim.user_id}/role",
            json={"role": "admin"},
            headers=member.headers,
        )
        assert r.status_code in (401, 403)

    def test_admin_rejected(self, client, admin_team, victim):
        r = client.patch(
            f"/api/v1/admin/users/{victim.user_id}/role",
            json={"role": "admin"},
            headers=admin_team.headers,
        )
        assert r.status_code == 403


class TestSetUserRoleHappyPath:
    def test_promote_user_to_admin_writes_audit_fields(
        self, client, super_admin_team, backend
    ):
        target = mint_team(backend, name="target", email="t@example.test")
        r = client.patch(
            f"/api/v1/admin/users/{target.user_id}/role",
            json={"role": "admin"},
            headers=super_admin_team.headers,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["role"] == "admin"
        assert body["promoted_by"] == super_admin_team.user_id
        assert body["promoted_at"]

        stored = backend.get_user(target.user_id)
        assert stored.role == "admin"
        assert stored.promoted_by == super_admin_team.user_id
        assert stored.promoted_at

    def test_demote_admin_to_user(self, client, super_admin_team, backend):
        target = mint_team(
            backend, name="target", email="t@example.test", role="admin"
        )
        r = client.patch(
            f"/api/v1/admin/users/{target.user_id}/role",
            json={"role": "user"},
            headers=super_admin_team.headers,
        )
        assert r.status_code == 200
        assert r.json()["role"] == "user"
        assert backend.get_user(target.user_id).role == "user"

    def test_idempotent_when_already_at_target_role(
        self, client, super_admin_team, backend
    ):
        target = mint_team(
            backend, name="target", email="t@example.test", role="admin"
        )
        r = client.patch(
            f"/api/v1/admin/users/{target.user_id}/role",
            json={"role": "admin"},
            headers=super_admin_team.headers,
        )
        assert r.status_code == 200
        stored = backend.get_user(target.user_id)
        assert stored.role == "admin"
        assert stored.promoted_at is None


class TestSetUserRoleSafetyRails:
    def test_cannot_change_own_role(self, client, super_admin_team):
        r = client.patch(
            f"/api/v1/admin/users/{super_admin_team.user_id}/role",
            json={"role": "user"},
            headers=super_admin_team.headers,
        )
        assert r.status_code == 400

    def test_cannot_modify_super_admin(self, client, super_admin_team, backend):
        other_super = mint_team(
            backend,
            name="other",
            email="other@example.test",
            role="super_admin",
        )
        r = client.patch(
            f"/api/v1/admin/users/{other_super.user_id}/role",
            json={"role": "admin"},
            headers=super_admin_team.headers,
        )
        assert r.status_code == 403
        assert backend.get_user(other_super.user_id).role == "super_admin"

    def test_cannot_set_role_to_super_admin(
        self, client, super_admin_team, backend
    ):
        target = mint_team(backend, name="target", email="t@example.test")
        r = client.patch(
            f"/api/v1/admin/users/{target.user_id}/role",
            json={"role": "super_admin"},
            headers=super_admin_team.headers,
        )
        assert r.status_code == 422

    def test_unknown_user_404(self, client, super_admin_team):
        r = client.patch(
            "/api/v1/admin/users/does-not-exist/role",
            json={"role": "admin"},
            headers=super_admin_team.headers,
        )
        assert r.status_code == 404


class TestPromotedAdminGetsAdminPrivileges:
    def test_promoted_admin_can_list_users(
        self, client, super_admin_team, backend
    ):
        target = mint_team(backend, name="target", email="t@example.test")
        r0 = client.get("/api/v1/admin/users", headers=target.headers)
        assert r0.status_code == 403

        client.patch(
            f"/api/v1/admin/users/{target.user_id}/role",
            json={"role": "admin"},
            headers=super_admin_team.headers,
        )

        r1 = client.get("/api/v1/admin/users", headers=target.headers)
        assert r1.status_code == 200

    def test_promoted_admin_still_cannot_change_roles(
        self, client, super_admin_team, backend
    ):
        target = mint_team(backend, name="target", email="t@example.test")
        client.patch(
            f"/api/v1/admin/users/{target.user_id}/role",
            json={"role": "admin"},
            headers=super_admin_team.headers,
        )
        bystander = mint_team(backend, name="b", email="b@example.test")
        r = client.patch(
            f"/api/v1/admin/users/{bystander.user_id}/role",
            json={"role": "admin"},
            headers=target.headers,
        )
        assert r.status_code == 403
