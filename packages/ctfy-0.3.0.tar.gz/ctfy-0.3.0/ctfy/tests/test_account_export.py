"""End-to-end tests for ``GET /api/v1/me/export`` (self-service data export).

Verifies the zip's structure + that sensitive secrets (token hashes,
password hashes) are scrubbed before they leave the server.
"""

from __future__ import annotations

import io
import json
import zipfile

from ctfy.core.state.models import (
    ActivityState,
    OAuthIdentity,
    PasswordIdentity,
    SolveState,
    SubmissionState,
)
from ctfy.tests.conftest import mint_team


def _open_zip(resp_bytes: bytes) -> zipfile.ZipFile:
    return zipfile.ZipFile(io.BytesIO(resp_bytes), mode="r")


def test_export_returns_zip_with_attachment_filename(client, backend):
    team = mint_team(backend, name="Exporter", email="ex@example.test")
    resp = client.get("/api/v1/me/export", headers=team.headers)
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("application/zip")
    cd = resp.headers.get("content-disposition", "")
    assert "attachment" in cd
    assert ".zip" in cd
    # Filename is keyed on the user_id post user/team-split.
    assert team.user_id in cd

    z = _open_zip(resp.content)
    names = set(z.namelist())
    # Required top-level files.
    assert "README.txt" in names
    assert "user.json" in names
    # Per-comp teams replace the legacy single-team file.
    assert "teams.json" in names
    assert "identities.json" in names
    assert "tokens.json" in names
    assert "submissions.json" in names
    assert "solves.json" in names
    assert "activity.jsonl" in names


def test_export_user_includes_user_state(client, backend):
    team = mint_team(backend, name="Exporter", email="ex@example.test")
    resp = client.get("/api/v1/me/export", headers=team.headers)
    z = _open_zip(resp.content)
    user = json.loads(z.read("user.json"))
    assert user["user_id"] == team.user_id
    assert user["display_name"] == "Exporter"
    assert user["email"] == "ex@example.test"
    teams = json.loads(z.read("teams.json"))
    assert any(row["team"]["team_id"] == team.team_id for row in teams)


def test_export_scrubs_password_and_token_hashes(client, backend):
    """Hashes (argon2 / sha256) are server-side secrets — they must not
    leave through the export. The export is the user's own data, not
    a credential dump."""
    team = mint_team(backend, name="Sec", email="sec@example.test")
    backend.put_password_identity(
        PasswordIdentity(
            identity_id="pid-1",
            team_id=team.team_id,
            email="sec@example.test",
            password_hash="$argon2id$VERY_SECRET_HASH_DO_NOT_LEAK",
            created_at="2026-04-25T12:00:00Z",
        )
    )
    resp = client.get("/api/v1/me/export", headers=team.headers)
    z = _open_zip(resp.content)
    identities = json.loads(z.read("identities.json"))
    tokens = json.loads(z.read("tokens.json"))
    blob = json.dumps(identities) + json.dumps(tokens)
    assert "VERY_SECRET_HASH_DO_NOT_LEAK" not in blob
    assert "password_hash" not in blob
    assert "token_hash" not in blob


def test_export_includes_submissions_solves_and_activity(client, backend):
    team = mint_team(backend, name="Active", email="a@example.test")
    # Stamp user_id on each row — the export filters by user_id post
    # user/team-split (so a user's lifetime history follows them across
    # team moves).
    backend.add_submission(
        SubmissionState(
            submission_id="sub-1",
            team_id=team.team_id,
            user_id=team.user_id,
            challenge_id="WEB-001",
            flag="x",
            correct=True,
            submitted_at="2026-04-25T12:01:00Z",
        )
    )
    backend.add_solve(
        team.team_id,
        "WEB-001",
        "main",
        SolveState(user_id=team.user_id, solved_at="2026-04-25T12:02:00Z"),
    )
    backend.add_activity(
        ActivityState(
            timestamp="2026-04-25T12:03:00Z",
            event="flag_correct",
            team_id=team.team_id,
            team_name="Active",
            user_id=team.user_id,
            actor_id=team.user_id,
            actor_name="Active",
            actor_type="team",
        )
    )
    resp = client.get("/api/v1/me/export", headers=team.headers)
    z = _open_zip(resp.content)
    subs = json.loads(z.read("submissions.json"))
    solves = json.loads(z.read("solves.json"))
    activity = z.read("activity.jsonl").decode().splitlines()
    assert any(s["challenge_id"] == "WEB-001" for s in subs)
    assert any(s["flag_id"] == "main" for s in solves)
    assert any(json.loads(line)["event"] == "flag_correct" for line in activity)


def test_export_scopes_to_caller_team_only(client, backend):
    """Bystander team's data must NOT appear in the caller's export."""
    caller = mint_team(backend, name="Caller", email="c@example.test")
    bystander = mint_team(backend, name="Bystander", email="b@example.test")
    backend.put_identity(
        OAuthIdentity(
            identity_id="bystander-id",
            team_id=bystander.team_id,
            provider="github",
            provider_user_id="gh-bystander",
            provider_email="b@example.test",
            created_at="2026-04-25T12:00:00Z",
        )
    )
    backend.add_submission(
        SubmissionState(
            submission_id="sub-bystander",
            team_id=bystander.team_id,
            challenge_id="WEB-001",
            flag="x",
            correct=False,
            submitted_at="2026-04-25T12:00:00Z",
        )
    )
    resp = client.get("/api/v1/me/export", headers=caller.headers)
    z = _open_zip(resp.content)
    blob = b"".join(z.read(name) for name in z.namelist())
    assert b"bystander-id" not in blob
    assert b"sub-bystander" not in blob


def test_export_requires_authentication(client):
    resp = client.get("/api/v1/me/export")
    assert resp.status_code in (401, 403)
