"""TDD: ``/me``'s ``competition_teams`` collection must filter out
memberships whose ``competition_id`` no longer points at an existing
competition.

Repro of the bug: an admin deletes a competition (or the user's
membership outlives a comp that was wiped), but the membership
row survives in storage. The frontend's competition rail tiles
that orphaned row, the user clicks it, and the
``/c/<dead-comp-id>/...`` route lands on the
``CompetitionLayout`` 404 panel — looking like a broken app.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import CompetitionState
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team


@pytest.fixture
def world():
    """A captain on a team for a comp that's *been deleted* —
    the membership row survives but the competition is gone.
    Hitting /me should silently drop the orphaned row.
    """
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    backend.put_competition(
        CompetitionState(
            competition_id="alive",
            title="Alive CTF",
            starts_at="",
            ends_at="2099-01-01T00:00:00Z",
            challenge_ids=[],
            created_at="2026-01-01T00:00:00Z",
        )
    )
    # The "ghost" comp is created so the team_for_competition op
    # accepts the join, then deleted before /me is called.
    backend.put_competition(
        CompetitionState(
            competition_id="ghost",
            title="Ghost CTF",
            starts_at="",
            ends_at="2099-01-01T00:00:00Z",
            challenge_ids=[],
            created_at="2026-01-01T00:00:00Z",
        )
    )
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)

    user = mint_team(
        backend,
        name="U",
        email="u@x",
        display_name="U",
        seed_competition=False,
    )
    # Drop the mint_team-seeded membership so the test starts from a
    # clean slate where every membership comes from the explicit
    # create_team_for_competition calls below.
    backend.delete_membership(user.user_id)
    backend.create_team_for_competition(
        user_id=user.user_id,
        competition_id="alive",
        team_name="LiveTeam",
        description="",
        now_iso="2026-01-01T00:00:00Z",
        joined_via="solo",
    )
    backend.create_team_for_competition(
        user_id=user.user_id,
        competition_id="ghost",
        team_name="GhostTeam",
        description="",
        now_iso="2026-01-01T00:00:00Z",
        joined_via="solo",
    )
    # Now delete the ghost comp — its membership row stays
    # behind in the backend (no cascade today), so the bug repro
    # is genuine.
    backend.delete_competition("ghost")
    return {
        "client": TestClient(app),
        "backend": backend,
        "user": user,
    }


def test_me_filters_memberships_pointing_at_deleted_comps(world):
    r = world["client"].get(
        "/api/v1/me", headers=world["user"].headers
    )
    assert r.status_code == 200, r.text
    body = r.json()
    comp_ids = {row["competition_id"] for row in body["competition_teams"]}
    assert comp_ids == {"alive"}, (
        "Orphaned membership for a deleted competition must be "
        f"filtered out of /me; got {comp_ids}"
    )
