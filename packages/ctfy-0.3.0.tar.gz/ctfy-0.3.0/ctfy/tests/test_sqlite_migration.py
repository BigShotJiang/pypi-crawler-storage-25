"""TDD: SQLite migration for the user/team-split.

A pre-split SQLite database has rows in ``teams`` whose JSON ``data``
blob carries ``email`` / ``role`` / ``bio`` / ``display_name`` and
friends — back when ``TeamState`` was the human. Post-split the
``users`` table owns those fields, ``team_memberships`` maps
user → team, and ``TeamState`` is slimmed.

Without a migration: a freshly-pulled deploy on top of an existing
DB would render every existing user un-signable-in (their token
resolves to a user_id, but no row exists in ``users``; the membership
walk fails).

This test seeds the legacy shape with raw SQL, instantiates a fresh
``SQLiteBackend`` (which runs ``_migrate``) and asserts the new
shape is materialised correctly.
"""

from __future__ import annotations

import json
import sqlite3

from ctfy.core.state.sqlite import SQLiteBackend


def _seed_legacy_team(
    db_path: str,
    *,
    team_id: str,
    email: str,
    display_name: str = "Legacy User",
    role: str = "user",
    bio: str | None = "I love CTFs",
    country: str | None = "JP",
    created_at: str = "2024-01-01T00:00:00+00:00",
) -> None:
    """Insert a pre-split ``teams`` row + matching token / identity in the
    same shape the old code would have written."""
    conn = sqlite3.connect(db_path)
    try:
        # Match the schema that ``_init_tables`` lays down — the column
        # names didn't change at the table level (only the JSON blob
        # contents did).
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS teams (
                team_id TEXT PRIMARY KEY,
                email TEXT NOT NULL DEFAULT '',
                data TEXT NOT NULL
            )
            """
        )
        legacy_blob = {
            "team_id": team_id,
            "name": display_name,
            "description": "",
            "created_at": created_at,
            "email": email,
            "display_name": display_name,
            "avatar_url": "",
            "role": role,
            "promoted_by": None,
            "promoted_at": None,
            "bio": bio,
            "country": country,
            "website_url": None,
            "timezone": None,
            "social_links": {},
            "profile_visibility": {},
        }
        conn.execute(
            "INSERT INTO teams (team_id, email, data) VALUES (?, ?, ?)",
            (team_id, email.lower(), json.dumps(legacy_blob)),
        )
        conn.commit()
    finally:
        conn.close()


def test_legacy_team_split_into_user_membership_and_team(tmp_path):
    db_path = str(tmp_path / "legacy.sqlite3")
    # Seed the legacy shape *before* the backend is constructed —
    # constructing the backend runs ``_init_tables`` then ``_migrate``.
    _seed_legacy_team(
        db_path,
        team_id="legacy-1",
        email="alice@example.com",
        display_name="Alice",
        role="admin",
        bio="hi I'm alice",
        country="JP",
    )

    backend = SQLiteBackend(db_path)

    # Migration must mint a UserState carrying the old auth + profile.
    user = backend.get_user("legacy-1")
    assert user is not None
    assert user.email == "alice@example.com"
    assert user.display_name == "Alice"
    assert user.role == "admin"
    assert user.bio == "hi I'm alice"
    assert user.country == "JP"

    # Email lookup goes through the new users table.
    by_email = backend.get_user_by_email("alice@example.com")
    assert by_email is not None and by_email.user_id == "legacy-1"

    # Membership row joins the user to a team with the same id (the
    # solo-team-of-one shape).
    m = backend.get_membership("legacy-1")
    assert m is not None
    assert m.team_id == "legacy-1"

    # TeamState is slimmed down — captain points at the user.
    team = backend.get_team("legacy-1")
    assert team is not None
    assert team.captain_user_id == "legacy-1"
    assert team.name == "Alice"


def test_migration_is_idempotent(tmp_path):
    """Running the migration twice on the same DB must not duplicate
    rows or change captain assignments."""
    db_path = str(tmp_path / "idempotent.sqlite3")
    _seed_legacy_team(
        db_path,
        team_id="legacy-2",
        email="bob@example.com",
        display_name="Bob",
    )
    backend1 = SQLiteBackend(db_path)
    user_count_1 = backend1.count_users()
    team_count_1 = backend1.count_teams()
    membership_count_1 = len(backend1.list_memberships())

    # Re-open — _migrate runs again.
    backend2 = SQLiteBackend(db_path)
    assert backend2.count_users() == user_count_1
    assert backend2.count_teams() == team_count_1
    assert len(backend2.list_memberships()) == membership_count_1


def test_migration_skips_when_users_already_present(tmp_path):
    """A modern DB (with users + memberships already populated) must
    not trigger the legacy-split pass."""
    db_path = str(tmp_path / "modern.sqlite3")
    backend = SQLiteBackend(db_path)
    # Insert via the backend's own API (post-split shape).
    from ctfy.core.state.models import (
        TeamMembershipState,
        TeamState,
        UserState,
    )

    backend.put_user(
        "u1",
        UserState(
            user_id="u1",
            email="modern@x",
            display_name="Modern",
            created_at="2026-01-01T00:00:00Z",
        ),
    )
    backend.put_team(
        "t1",
        TeamState(
            team_id="t1",
            name="Modern Team",
            captain_user_id="u1",
            created_at="2026-01-01T00:00:00Z",
        ),
    )
    backend.put_membership(
        TeamMembershipState(user_id="u1", team_id="t1", joined_at="")
    )

    # Re-open: migration sees users non-empty → no-op.
    backend2 = SQLiteBackend(db_path)
    assert backend2.count_users() == 1
    assert backend2.count_teams() == 1
    # Captain unchanged.
    assert backend2.get_team("t1").captain_user_id == "u1"


def test_v1_schema_cleanup_renames_columns_and_drops_email(tmp_path):
    """The user/team-split landed with auth tables still using a
    ``team_id`` column (storing user_id values) and a write-empty
    ``teams.email`` column. The v1 cleanup migration renames + drops
    them so anyone reading raw SQL gets the post-split semantics.
    """
    db_path = str(tmp_path / "v1cleanup.sqlite3")
    # Hand-build the pre-v1 schema with the legacy column names.
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(
            """
            CREATE TABLE teams (
                team_id TEXT PRIMARY KEY,
                email TEXT NOT NULL DEFAULT '',
                data TEXT NOT NULL
            );
            CREATE INDEX idx_team_email ON teams(email);
            CREATE TABLE oauth_identities (
                identity_id TEXT PRIMARY KEY,
                team_id TEXT NOT NULL,
                provider TEXT NOT NULL,
                provider_user_id TEXT NOT NULL,
                data TEXT NOT NULL,
                UNIQUE(provider, provider_user_id)
            );
            CREATE INDEX idx_identity_team ON oauth_identities(team_id);
            CREATE TABLE password_identities (
                identity_id TEXT PRIMARY KEY,
                team_id TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                data TEXT NOT NULL
            );
            CREATE INDEX idx_pwd_identity_team ON password_identities(team_id);
            CREATE TABLE team_tokens (
                token_id TEXT PRIMARY KEY,
                team_id TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL,
                data TEXT NOT NULL
            );
            CREATE INDEX idx_token_team ON team_tokens(team_id);
            """
        )
        conn.commit()
    finally:
        conn.close()

    # Boot the backend — runs ``_init_tables`` (no-ops here, tables
    # exist) then ``_migrate`` (legacy split + v1 cleanup).
    SQLiteBackend(db_path)

    # Assert the new column names are in place.
    conn = sqlite3.connect(db_path)
    try:
        for table in ("oauth_identities", "password_identities", "team_tokens"):
            cols = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
            assert "user_id" in cols, f"{table}.user_id missing"
            assert "team_id" not in cols, f"{table}.team_id should be gone"
        # ``teams.email`` is gone.
        teams_cols = {row[1] for row in conn.execute("PRAGMA table_info(teams)")}
        assert "email" not in teams_cols, "teams.email should be dropped"
        # PRAGMA user_version bumped so re-runs are no-ops.
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        assert version >= 1
    finally:
        conn.close()

    # Re-open: idempotent.
    SQLiteBackend(db_path)
    conn = sqlite3.connect(db_path)
    try:
        cols = {row[1] for row in conn.execute("PRAGMA table_info(oauth_identities)")}
        assert "user_id" in cols
        assert "team_id" not in cols
    finally:
        conn.close()


def test_v2_membership_audit_columns_added_to_existing_db(tmp_path):
    """A pre-v2 deployment with an existing ``team_memberships`` table
    (no audit columns) must upgrade cleanly: the v2 migration adds
    ``joined_via`` + ``invited_by_user_id`` with empty defaults so
    existing rows read back as ``TeamMembershipState`` without a
    Pydantic explosion.
    """
    db_path = str(tmp_path / "v2cleanup.sqlite3")
    # Hand-build a v1-shaped schema (post-rename, pre-audit-columns).
    # PRAGMA user_version=1 marks it as already through v1 cleanup.
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(
            """
            CREATE TABLE users (
                user_id TEXT PRIMARY KEY,
                email TEXT NOT NULL DEFAULT '',
                data TEXT NOT NULL
            );
            CREATE TABLE teams (
                team_id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE team_memberships (
                user_id TEXT PRIMARY KEY,
                team_id TEXT NOT NULL,
                joined_at TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE team_invites (
                invite_id TEXT PRIMARY KEY,
                team_id TEXT NOT NULL,
                code TEXT NOT NULL UNIQUE,
                created_by_user_id TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                expires_at TEXT NOT NULL DEFAULT '',
                max_uses INTEGER NOT NULL DEFAULT 1,
                use_count INTEGER NOT NULL DEFAULT 0,
                revoked_at TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE oauth_identities (
                identity_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                provider TEXT NOT NULL,
                provider_user_id TEXT NOT NULL,
                data TEXT NOT NULL,
                UNIQUE(provider, provider_user_id)
            );
            CREATE TABLE password_identities (
                identity_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                data TEXT NOT NULL
            );
            CREATE TABLE team_tokens (
                token_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL,
                data TEXT NOT NULL
            );
            INSERT INTO users (user_id, email, data) VALUES
                ('u1', 'a@x', '{"user_id":"u1","email":"a@x"}');
            INSERT INTO teams (team_id, data) VALUES
                ('t1', '{"team_id":"t1","name":"T","captain_user_id":"u1","created_at":""}');
            INSERT INTO team_memberships (user_id, team_id, joined_at) VALUES
                ('u1', 't1', '2026-01-01T00:00:00Z');
            PRAGMA user_version = 1;
            """
        )
        conn.commit()
    finally:
        conn.close()

    # Boot — runs ``_migrate``, which sees user_version=1 and runs the
    # v2 cleanup block (skipping v1).
    backend = SQLiteBackend(db_path)

    # The pre-existing membership reads back without crashing, with
    # the new audit fields defaulting to empty.
    m = backend.get_membership("u1")
    assert m is not None
    assert m.team_id == "t1"
    assert m.joined_via == ""
    assert m.invited_by_user_id == ""

    # Schema check: the new columns are physically present.
    conn = sqlite3.connect(db_path)
    try:
        cols = {row[1] for row in conn.execute("PRAGMA table_info(team_memberships)")}
        assert "joined_via" in cols
        assert "invited_by_user_id" in cols
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        assert version >= 2
    finally:
        conn.close()

    # Re-open: v2 is idempotent.
    SQLiteBackend(db_path)
    conn = sqlite3.connect(db_path)
    try:
        cols = {row[1] for row in conn.execute("PRAGMA table_info(team_memberships)")}
        # Still exactly one ``joined_via`` column (no double-add).
        assert sum(1 for c in cols if c == "joined_via") == 1
    finally:
        conn.close()


def test_v3_per_competition_columns_added_to_legacy_db(tmp_path):
    """A pre-v3 DB (already through v2 — has audit columns but no
    ``competition_id``) must upgrade cleanly: the v3 migration adds
    ``competition_id`` to ``team_memberships`` + ``team_invites``,
    creates the per-comp lookup indices, and bumps user_version=3.
    Existing rows read back with empty ``competition_id``.
    """
    db_path = str(tmp_path / "v3cleanup.sqlite3")
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(
            """
            CREATE TABLE users (
                user_id TEXT PRIMARY KEY,
                email TEXT NOT NULL DEFAULT '',
                data TEXT NOT NULL
            );
            CREATE TABLE teams (
                team_id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE team_memberships (
                user_id TEXT PRIMARY KEY,
                team_id TEXT NOT NULL,
                joined_at TEXT NOT NULL DEFAULT '',
                joined_via TEXT NOT NULL DEFAULT '',
                invited_by_user_id TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE team_invites (
                invite_id TEXT PRIMARY KEY,
                team_id TEXT NOT NULL,
                code TEXT NOT NULL UNIQUE,
                created_by_user_id TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                expires_at TEXT NOT NULL DEFAULT '',
                max_uses INTEGER NOT NULL DEFAULT 1,
                use_count INTEGER NOT NULL DEFAULT 0,
                revoked_at TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE oauth_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                provider TEXT NOT NULL, provider_user_id TEXT NOT NULL,
                data TEXT NOT NULL, UNIQUE(provider, provider_user_id)
            );
            CREATE TABLE password_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE, data TEXT NOT NULL
            );
            CREATE TABLE team_tokens (
                token_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL, data TEXT NOT NULL
            );
            INSERT INTO users (user_id, email, data) VALUES
                ('u1', 'a@x', '{"user_id":"u1","email":"a@x"}');
            INSERT INTO teams (team_id, data) VALUES
                ('t1', '{"team_id":"t1","name":"T","captain_user_id":"u1","created_at":""}');
            INSERT INTO team_memberships (user_id, team_id, joined_at) VALUES
                ('u1', 't1', '2026-01-01T00:00:00Z');
            PRAGMA user_version = 2;
            """
        )
        conn.commit()
    finally:
        conn.close()

    # Boot — runs ``_migrate``, which sees user_version=2 and runs only v3.
    backend = SQLiteBackend(db_path)
    m = backend.get_membership("u1")
    assert m is not None
    assert m.competition_id == ""

    conn = sqlite3.connect(db_path)
    try:
        cols = {row[1] for row in conn.execute("PRAGMA table_info(team_memberships)")}
        assert "competition_id" in cols
        cols2 = {row[1] for row in conn.execute("PRAGMA table_info(team_invites)")}
        assert "competition_id" in cols2
        idx = {row[1] for row in conn.execute("PRAGMA index_list(team_memberships)")}
        assert "idx_membership_competition" in idx
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        assert version >= 3
    finally:
        conn.close()


def test_v4_team_memberships_composite_pk(tmp_path):
    """Phase 2a: ``team_memberships`` PK becomes
    ``(user_id, competition_id)`` so a user can hold N memberships,
    one per competition. SQLite can't ALTER PRIMARY KEY in place;
    the v4 migration recreates the table and copies rows over.
    Existing legacy rows keep ``competition_id == ""`` and stay
    addressable via the legacy ``get_membership(user_id)`` lookup.
    """
    db_path = str(tmp_path / "v4cleanup.sqlite3")
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(
            """
            CREATE TABLE users (
                user_id TEXT PRIMARY KEY,
                email TEXT NOT NULL DEFAULT '',
                data TEXT NOT NULL
            );
            CREATE TABLE teams (
                team_id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE team_memberships (
                user_id TEXT PRIMARY KEY,
                team_id TEXT NOT NULL,
                joined_at TEXT NOT NULL DEFAULT '',
                joined_via TEXT NOT NULL DEFAULT '',
                invited_by_user_id TEXT NOT NULL DEFAULT '',
                competition_id TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE team_invites (
                invite_id TEXT PRIMARY KEY, team_id TEXT NOT NULL,
                code TEXT NOT NULL UNIQUE,
                created_by_user_id TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                expires_at TEXT NOT NULL DEFAULT '',
                max_uses INTEGER NOT NULL DEFAULT 1,
                use_count INTEGER NOT NULL DEFAULT 0,
                revoked_at TEXT NOT NULL DEFAULT '',
                competition_id TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE oauth_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                provider TEXT NOT NULL, provider_user_id TEXT NOT NULL,
                data TEXT NOT NULL, UNIQUE(provider, provider_user_id)
            );
            CREATE TABLE password_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE, data TEXT NOT NULL
            );
            CREATE TABLE team_tokens (
                token_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL, data TEXT NOT NULL
            );
            INSERT INTO users (user_id, email, data) VALUES
                ('u1', 'a@x', '{"user_id":"u1","email":"a@x"}');
            INSERT INTO teams (team_id, data) VALUES
                ('t1', '{"team_id":"t1","name":"T","captain_user_id":"u1","created_at":""}');
            INSERT INTO team_memberships (user_id, team_id, joined_at) VALUES
                ('u1', 't1', '2026-01-01T00:00:00Z');
            PRAGMA user_version = 3;
            """
        )
        conn.commit()
    finally:
        conn.close()

    # Boot — runs ``_migrate``, sees user_version=3, runs only v4.
    backend = SQLiteBackend(db_path)

    # Legacy row preserved + addressable via legacy lookup (it had
    # competition_id="", so it's the user's "default" membership).
    legacy = backend.get_membership("u1")
    assert legacy is not None
    assert legacy.team_id == "t1"
    assert legacy.competition_id == ""

    # New per-comp lookup also works against the same row.
    via_explicit = backend.get_membership_for_competition("u1", "")
    assert via_explicit is not None
    assert via_explicit.team_id == "t1"

    # Schema check: composite PK is in place.
    conn = sqlite3.connect(db_path)
    try:
        pk_cols = [
            row[1]
            for row in conn.execute("PRAGMA table_info(team_memberships)")
            if row[5] > 0  # pk column index, non-zero = part of PK
        ]
        assert set(pk_cols) == {"user_id", "competition_id"}
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        assert version >= 4
    finally:
        conn.close()

    # Re-open: v4 is idempotent (composite PK already in place).
    SQLiteBackend(db_path)
    legacy2 = backend.get_membership("u1")
    assert legacy2 is not None and legacy2.team_id == "t1"


def test_v5_drops_competition_registrations_table(tmp_path):
    """Phase 5e-3: ``CompetitionRegistrationState`` is gone — a team
    existing with ``competition_id == X`` *is* the registration. The
    v5 migration drops the legacy table on existing DBs. Idempotent.
    """
    db_path = str(tmp_path / "v5cleanup.sqlite3")
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(
            """
            CREATE TABLE users (
                user_id TEXT PRIMARY KEY,
                email TEXT NOT NULL DEFAULT '',
                data TEXT NOT NULL
            );
            CREATE TABLE teams (
                team_id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE team_memberships (
                user_id TEXT NOT NULL,
                team_id TEXT NOT NULL,
                joined_at TEXT NOT NULL DEFAULT '',
                joined_via TEXT NOT NULL DEFAULT '',
                invited_by_user_id TEXT NOT NULL DEFAULT '',
                competition_id TEXT NOT NULL DEFAULT '',
                PRIMARY KEY (user_id, competition_id)
            );
            CREATE TABLE team_invites (
                invite_id TEXT PRIMARY KEY, team_id TEXT NOT NULL,
                code TEXT NOT NULL UNIQUE,
                created_by_user_id TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                expires_at TEXT NOT NULL DEFAULT '',
                max_uses INTEGER NOT NULL DEFAULT 1,
                use_count INTEGER NOT NULL DEFAULT 0,
                revoked_at TEXT NOT NULL DEFAULT '',
                competition_id TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE oauth_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                provider TEXT NOT NULL, provider_user_id TEXT NOT NULL,
                data TEXT NOT NULL, UNIQUE(provider, provider_user_id)
            );
            CREATE TABLE password_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE, data TEXT NOT NULL
            );
            CREATE TABLE team_tokens (
                token_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL, data TEXT NOT NULL
            );
            CREATE TABLE competition_registrations (
                competition_id TEXT NOT NULL,
                team_id TEXT NOT NULL,
                registered_at TEXT NOT NULL DEFAULT '',
                PRIMARY KEY (competition_id, team_id)
            );
            INSERT INTO competition_registrations
                (competition_id, team_id, registered_at)
            VALUES ('legacy-comp', 'legacy-team', '2026-01-01T00:00:00Z');
            PRAGMA user_version = 4;
            """
        )
        conn.commit()
    finally:
        conn.close()

    SQLiteBackend(db_path)
    conn = sqlite3.connect(db_path)
    try:
        # Table is gone.
        tables = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        assert "competition_registrations" not in tables
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        assert version >= 5
    finally:
        conn.close()
    # Idempotent: re-open doesn't blow up trying to drop a missing
    # table (DROP TABLE IF EXISTS handles that).
    SQLiteBackend(db_path)


def test_v7_rewrites_legacy_team_id_in_blob_to_user_id(tmp_path):
    """v7: oauth_identities / password_identities / team_tokens stored
    their pydantic blob with the old ``team_id`` field name from
    pre-split deployments. v1 already renamed the SQL column to
    ``user_id`` but left the in-blob key alone — three model_validators
    aliased the legacy field on every read. v7 walks all three tables
    once and rewrites the JSON so the validators can be deleted; the
    models then reject blobs that still carry ``team_id`` (which is
    what we want — there shouldn't be any after this migration).
    """
    db_path = str(tmp_path / "v7cleanup.sqlite3")
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(
            """
            CREATE TABLE users (
                user_id TEXT PRIMARY KEY,
                email TEXT NOT NULL DEFAULT '',
                data TEXT NOT NULL
            );
            CREATE TABLE teams (
                team_id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE team_memberships (
                user_id TEXT NOT NULL,
                team_id TEXT NOT NULL,
                joined_at TEXT NOT NULL DEFAULT '',
                joined_via TEXT NOT NULL DEFAULT '',
                invited_by_user_id TEXT NOT NULL DEFAULT '',
                competition_id TEXT NOT NULL DEFAULT '',
                PRIMARY KEY (user_id, competition_id)
            );
            CREATE TABLE team_invites (
                invite_id TEXT PRIMARY KEY, team_id TEXT NOT NULL,
                code TEXT NOT NULL UNIQUE,
                created_by_user_id TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                expires_at TEXT NOT NULL DEFAULT '',
                max_uses INTEGER NOT NULL DEFAULT 1,
                use_count INTEGER NOT NULL DEFAULT 0,
                revoked_at TEXT NOT NULL DEFAULT '',
                competition_id TEXT NOT NULL DEFAULT '',
                kind TEXT NOT NULL DEFAULT 'code',
                target_user_id TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE oauth_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                provider TEXT NOT NULL, provider_user_id TEXT NOT NULL,
                data TEXT NOT NULL, UNIQUE(provider, provider_user_id)
            );
            CREATE TABLE password_identities (
                identity_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE, data TEXT NOT NULL
            );
            CREATE TABLE team_tokens (
                token_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL, data TEXT NOT NULL
            );
            INSERT INTO oauth_identities
                (identity_id, user_id, provider, provider_user_id, data)
            VALUES (
                'i1', 'u1', 'github', 'gh-1',
                '{"identity_id":"i1","team_id":"u1","provider":"github"}'
            );
            INSERT INTO password_identities
                (identity_id, user_id, email, data)
            VALUES (
                'p1', 'u1', 'a@x',
                '{"identity_id":"p1","team_id":"u1","email":"a@x"}'
            );
            INSERT INTO team_tokens
                (token_id, user_id, token_hash, kind, data)
            VALUES (
                'tok1', 'u1', 'h1', 'user',
                '{"token_id":"tok1","team_id":"u1","kind":"user"}'
            );
            PRAGMA user_version = 6;
            """
        )
        conn.commit()
    finally:
        conn.close()

    # Boot the backend — runs ``_migrate``, which sees user_version=6
    # and runs only v7. The validators are gone, so the round-trip
    # below would raise on a blob that still carried ``team_id``.
    backend = SQLiteBackend(db_path)
    assert backend.get_identity("i1").user_id == "u1"
    assert backend.get_password_identity("p1").user_id == "u1"
    assert backend.get_token("tok1").user_id == "u1"

    conn = sqlite3.connect(db_path)
    try:
        # Blobs no longer carry the legacy key.
        for table in ("oauth_identities", "password_identities", "team_tokens"):
            for row in conn.execute(f"SELECT data FROM {table}"):
                blob = json.loads(row[0])
                assert "team_id" not in blob
                assert blob["user_id"] == "u1"
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        assert version >= 7
    finally:
        conn.close()

    # Idempotent: re-open is a no-op (no rows to rewrite).
    SQLiteBackend(db_path)
