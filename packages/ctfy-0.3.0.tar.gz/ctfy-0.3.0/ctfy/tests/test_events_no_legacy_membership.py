"""Phase 1.C.1: ``emit_event`` and team-profile-stats stop calling
``state_backend.get_membership`` (which only returns the legacy default
slot ``competition_id == ""``).

After Phase 1.D every membership row carries a non-empty
``competition_id``, so ``get_membership(user_id)`` always returns
``None``. The two consumers must derive the team from data they
already have:

* ``emit_event`` — credit achievements against ``payload.team_id``
  (the payload was already constructed with the right team in scope).
* ``team_profile_stats._user_solve_trend`` (and ``is_owner`` check) —
  use ``list_memberships(user_id=...)`` to find any membership for
  the team being viewed.

This file pins down the behavior so the get_membership removal can't
silently re-introduce broken paths.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.enums import PlatformEvent
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import (
    SolveState,
    TeamMembershipState,
    TeamState,
    UserState,
)
from ctfy.server.event_payloads import FlagCorrectPayload
from ctfy.server.events import emit_event
from ctfy.tests.conftest import make_mock_challenge_manager, mint_team


@pytest.fixture
def world():
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    mgr = make_mock_challenge_manager()
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    yield TestClient(app), backend, app.state.ctfy


class TestAchievementCreditedToPayloadTeam:
    """``emit_event`` must credit achievements to ``payload.team_id``,
    not to ``get_membership(actor_id).team_id``. Otherwise a user
    registered for a competition (per-comp membership only, no
    legacy default slot) submits a flag, and the achievement is
    credited to "user-x" as a team_id — silently corrupting state.
    """

    def test_uses_payload_team_id_when_actor_has_no_default_slot(self, world):
        _client, backend, app_state = world

        # Seed a user with a per-comp membership only (no legacy
        # default-slot row). This is the post-Phase-1.D shape.
        user = UserState(user_id="u-alice", display_name="Alice", role="user")
        backend.put_user("u-alice", user)
        team = TeamState(team_id="t-team-A", name="Team A", captain_user_id="u-alice")
        backend.put_team("t-team-A", team)
        backend.put_membership(
            TeamMembershipState(
                user_id="u-alice",
                team_id="t-team-A",
                joined_at="2026-01-01T00:00:00Z",
                competition_id="spring-ctf",
            )
        )

        # Sanity: the only membership is the per-comp one we just put.
        assert backend.get_membership("u-alice").competition_id == "spring-ctf"

        captured: dict[str, str] = {}

        def fake_evaluate(app, event, payload, **kwargs):
            captured["actor_team_id"] = kwargs.get("actor_team_id", "")
            captured["payload_team_id"] = payload.team_id

        with patch(
            "ctfy.server.achievements.engine.evaluate",
            side_effect=fake_evaluate,
        ):
            emit_event(
                app_state,
                FlagCorrectPayload(
                    team_id="t-team-A",
                    team_name="Team A",
                    challenge_id="WEB-001",
                    instance_id="inst-1",
                    solve_time_s=10.0,
                    ip="1.2.3.4",
                    flag_id="main",
                    challenge_fully_solved=False,
                ),
                actor_id="u-alice",
                actor_name="Alice",
                actor_type="team",
            )

        # Achievement evaluator must receive the payload's team_id, not
        # the user_id (which is what the legacy ``actor_id`` fallback
        # would have produced).
        assert captured["actor_team_id"] == "t-team-A"
        assert captured["payload_team_id"] == "t-team-A"

    def test_does_not_consult_get_membership_at_all(self, world):
        """Stronger guarantee — ``get_membership`` must not even be
        called by emit_event. Otherwise a future caller could
        re-introduce the legacy lookup by accident.
        """
        _client, backend, app_state = world

        team = mint_team(backend, name="Solo")
        with patch.object(
            backend, "get_membership", side_effect=AssertionError("must not be called")
        ) as get_membership_spy:
            emit_event(
                app_state,
                FlagCorrectPayload(
                    team_id=team.team_id,
                    team_name="Solo",
                    challenge_id="WEB-001",
                    instance_id="inst-1",
                    solve_time_s=1.0,
                    ip="1.1.1.1",
                    flag_id="main",
                    challenge_fully_solved=False,
                ),
                actor_id=team.user_id,
                actor_name="Solo",
                actor_type="team",
            )
            assert get_membership_spy.call_count == 0
