"""HTTP client for platform → node machine calls.

Every call is authenticated with the target node's bearer token —
minted per node at registration and used in both directions. End users
never touch this client; they talk to the platform, which proxies to
the node. Node endpoints are defined in
``server/routes/node_instances.py``.
"""

from __future__ import annotations

from typing import Any

from ctfy.core.constants import DEFAULT_CLIENT_TIMEOUT
from ctfy.sdk.base import BaseHttpClient


class NodeClient(BaseHttpClient):
    """Thin sync HTTP client; one instance per node URL."""

    def __init__(
        self,
        node_url: str,
        token: str,
        *,
        timeout: int = DEFAULT_CLIENT_TIMEOUT,
    ) -> None:
        super().__init__(f"{node_url.rstrip('/')}/api/v1", token, timeout=timeout)

    # -- lifecycle ----------------------------------------------------------

    def start_instance(
        self,
        *,
        challenge_id: str,
        instance_id: str,
        ttl: int,
        flags: dict[str, str],
        vars: dict[str, str] | None = None,
        proxy_output_dir: str | None = None,
    ) -> dict[str, Any]:
        resp = self._request(
            "POST",
            "/instances",
            json={
                "challenge_id": challenge_id,
                "instance_id": instance_id,
                "ttl": ttl,
                "flags": flags,
                "vars": vars or {},
                "proxy_output_dir": proxy_output_dir,
            },
        )
        resp.raise_for_status()
        return resp.json()

    def stop_instance(self, instance_id: str) -> None:
        resp = self._request("DELETE", f"/instances/{instance_id}")
        resp.raise_for_status()

    def stop_all(self) -> None:
        resp = self._request("POST", "/admin/stop-all")
        resp.raise_for_status()

    # -- status / health ----------------------------------------------------

    def get_status(self, instance_id: str) -> dict[str, Any]:
        resp = self._request("GET", f"/instances/{instance_id}/status")
        resp.raise_for_status()
        return resp.json()

    def check_health(self, instance_id: str) -> bool:
        resp = self._request("GET", f"/instances/{instance_id}/health")
        resp.raise_for_status()
        return bool(resp.json().get("healthy"))

    def node_health(self) -> dict[str, Any]:
        """Liveness + ``{running, capacity}`` for heartbeat."""
        resp = self._request("GET", "/health")
        resp.raise_for_status()
        return resp.json()

    # -- traffic / runtime --------------------------------------------------

    def get_traffic(self, instance_id: str) -> dict[str, Any]:
        """Fetch mitmproxy flow data; file lives on the node's FS."""
        resp = self._request("GET", f"/instances/{instance_id}/traffic")
        resp.raise_for_status()
        return resp.json()

    def get_container_logs(self, instance_id: str) -> str:
        """Fetch combined container stdout/stderr for archival."""
        resp = self._request("GET", f"/instances/{instance_id}/container-logs")
        resp.raise_for_status()
        return str(resp.json().get("logs") or "")

    def get_pcap(self, instance_id: str) -> bytes:
        """Fetch the raw tcpdump capture for *instance_id*.

        Returns an empty ``bytes`` when no capture exists (sidecar
        disabled, instance never reached the running state, etc.) so
        callers can persist conditionally without try/except.
        """
        resp = self._request("GET", f"/instances/{instance_id}/pcap")
        if resp.status_code == 404:
            return b""
        resp.raise_for_status()
        return resp.content

    def get_agent_runtime(self, instance_id: str) -> dict[str, Any]:
        """Provider-agnostic runtime hints for attaching an agent (proxy URL,
        CA PEM, optional Docker-specific names). Replaces the old
        sandbox-network shape."""
        resp = self._request("GET", f"/instances/{instance_id}/agent-runtime")
        resp.raise_for_status()
        return resp.json()
