"""Platform HTTP client — single client for the ctfy platform.

This is the only HTTP client needed. Used by CLI, MCP server, and external users.

Usage::

    from ctfy.sdk import PlatformClient

    client = PlatformClient("http://localhost:8100", token="pt_xxx")
    challenges = client.list_challenges(category="web")
    ready = client.start_instance("WEB-001")
    result = client.submit_flag(ready.instance_id, "FLAG{...}")
    board = client.scoreboard()
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Generic, TypeVar

import httpx
from pydantic import BaseModel

from ctfy.core.constants import (
    DEFAULT_CLIENT_TIMEOUT,
    DEFAULT_INSTANCE_TTL,
    DEFAULT_POLL_TIMEOUT,
)
from ctfy.core.enums import InstanceStatus
from ctfy.core.state.models import SubmissionState
from ctfy.core.target import AttackSurface
from ctfy.sdk.base import BaseHttpClient
from ctfy.server.models import (
    Activity,
    AdminUserInfo,
    ChallengeInfo,
    ChallengeStats,
    HealthResponse,
    InstanceInfo,
    InstanceStatusResponse,
    MeResponse,
    NodeInfo,
    RenewResponse,
    ScoreboardEntry,
    StartResponse,
    SubmissionResponse,
    TeamDetail,
    TeamInfo,
    VerifyFlagResponse,
)

# ``TeamInviteInfo`` lives on the per-comp team route module — only
# that route owns it as a response model. SDK imports it directly so
# we don't bloat ``server/models.py`` with one-off invite shapes.
from ctfy.server.routes.competition_teams import TeamInviteInfo

T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    """Lightweight paginated response model for parsing server responses."""

    items: list[T]
    total: int
    offset: int = 0
    limit: int = 50


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


@dataclass
class InstanceReadyResult:
    """Result of polling an instance until ready."""

    surface: AttackSurface
    cert_volume: str = ""


def _poll_instance_ready(
    client: httpx.Client,
    instance_id: str,
    *,
    timeout: int = DEFAULT_POLL_TIMEOUT,
    poll_interval: float = 2.0,
) -> InstanceReadyResult:
    """Poll GET /instances/{id}/status until ready. Raises on error/timeout."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        resp = client.get(f"/instances/{instance_id}/status")
        if resp.status_code == 404:
            # Instance may not be registered yet (async start); keep polling
            time.sleep(poll_interval)
            continue
        resp.raise_for_status()
        status_resp = InstanceStatusResponse.model_validate(resp.json())

        if status_resp.status == InstanceStatus.READY and status_resp.attack_surface:
            return InstanceReadyResult(
                surface=status_resp.attack_surface,
                cert_volume=status_resp.cert_volume,
            )
        if status_resp.status == InstanceStatus.ERROR:
            raise RuntimeError(f"Instance {instance_id} failed: {status_resp.error}")
        time.sleep(poll_interval)

    raise TimeoutError(f"Instance {instance_id} not ready after {timeout}s")


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class PlatformClient(BaseHttpClient):
    """HTTP client for the ctfy platform.

    Handles: teams, challenges, instances, flag submission/verification,
    scoreboard. Used by CLI, SDK, and MCP.
    """

    def __init__(
        self,
        server_url: str,
        token: str = "",
        max_retries: int = 3,
        timeout: int = DEFAULT_CLIENT_TIMEOUT,
    ):
        self._url = server_url.rstrip("/")
        super().__init__(f"{self._url}/api/v1", token, timeout=timeout, max_retries=max_retries)

    # -- teams --------------------------------------------------------------

    def list_teams(self, offset: int = 0, limit: int = 50) -> list[TeamInfo]:
        resp = self._request("GET", "/teams", params={"offset": offset, "limit": limit})
        resp.raise_for_status()
        page = PaginatedResponse[TeamInfo].model_validate(resp.json())
        return page.items

    def get_team(self, team_id: str) -> TeamDetail:
        resp = self._request("GET", f"/teams/{team_id}")
        resp.raise_for_status()
        return TeamDetail.model_validate(resp.json())

    def get_me(self) -> MeResponse:
        """Get the calling user's profile + auth context.

        Per-competition team memberships ride along on
        ``competition_teams``; there is no global "current team" any
        more — pick the row whose ``competition_id`` matches the
        scope you care about.
        """
        resp = self._request("GET", "/me")
        resp.raise_for_status()
        return MeResponse.model_validate(resp.json())

    # -- per-competition teams: register / captain CRUD / invite redeem -----

    def register_solo(self, competition_id: str) -> TeamDetail:
        """Register Solo for ``competition_id`` (1-person team, you're
        captain, name auto-derived from your display_name).
        Idempotent on (you, competition_id)."""
        resp = self._request(
            "POST",
            f"/competitions/{competition_id}/teams",
            json={"mode": "solo"},
        )
        resp.raise_for_status()
        return TeamDetail.model_validate(resp.json())

    def create_competition_team(
        self,
        competition_id: str,
        *,
        name: str,
        description: str = "",
    ) -> TeamDetail:
        """Create a multi-user team for ``competition_id``; you become
        the captain. Returns 409 if you already have a team for this
        comp (use leave + create, or pass through redeem)."""
        resp = self._request(
            "POST",
            f"/competitions/{competition_id}/teams",
            json={
                "mode": "create",
                "name": name,
                "description": description,
            },
        )
        resp.raise_for_status()
        return TeamDetail.model_validate(resp.json())

    def redeem_competition_invite(
        self, competition_id: str, code: str
    ) -> TeamDetail:
        """Join the captain's team for ``competition_id`` via an
        invite code. 409 if the code was minted for a different comp
        or you already have a team for this comp."""
        resp = self._request(
            "POST",
            f"/competitions/{competition_id}/teams/redeem",
            json={"code": code},
        )
        resp.raise_for_status()
        return TeamDetail.model_validate(resp.json())

    def rename_competition_team(
        self,
        competition_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
    ) -> TeamDetail:
        """Captain-only: rename / re-describe the comp team."""
        body: dict[str, str] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        resp = self._request(
            "PATCH", f"/competitions/{competition_id}/team", json=body
        )
        resp.raise_for_status()
        return TeamDetail.model_validate(resp.json())

    def leave_competition_team(self, competition_id: str) -> None:
        """Drop your membership for ``competition_id``. If captain
        and others remain, captaincy transfers to longest-tenured
        member; if you were the lone member the team is deleted."""
        resp = self._request(
            "POST", f"/competitions/{competition_id}/team/leave"
        )
        resp.raise_for_status()

    def kick_competition_member(
        self, competition_id: str, user_id: str
    ) -> None:
        """Captain-only: remove ``user_id`` from the comp team.
        Self-kick rejected (use ``leave_competition_team`` instead)."""
        resp = self._request(
            "DELETE",
            f"/competitions/{competition_id}/team/members/{user_id}",
        )
        resp.raise_for_status()

    def mint_competition_invite(
        self,
        competition_id: str,
        *,
        max_uses: int = 1,
        ttl_seconds: int = 24 * 3600,
    ) -> TeamInviteInfo:
        """Captain-only: mint an invite code scoped to this comp.
        ``max_uses=0`` is unlimited; ``ttl_seconds=0`` never expires."""
        resp = self._request(
            "POST",
            f"/competitions/{competition_id}/invites",
            json={"max_uses": max_uses, "ttl_seconds": ttl_seconds},
        )
        resp.raise_for_status()
        return TeamInviteInfo.model_validate(resp.json())

    def list_competition_invites(
        self, competition_id: str
    ) -> list[TeamInviteInfo]:
        """Captain-only: list all invites for the caller's team in
        this comp."""
        resp = self._request(
            "GET", f"/competitions/{competition_id}/invites"
        )
        resp.raise_for_status()
        page = PaginatedResponse[TeamInviteInfo].model_validate(resp.json())
        return page.items

    def revoke_competition_invite(
        self, competition_id: str, invite_id: str
    ) -> None:
        """Captain-only: invalidate a previously-minted invite."""
        resp = self._request(
            "DELETE", f"/competitions/{competition_id}/invites/{invite_id}"
        )
        resp.raise_for_status()

    # -- admin --------------------------------------------------------------

    def get_admin_user(self, user_id: str) -> AdminUserInfo:
        """Admin-or-better: single-user lookup with the audit fields
        (role, promoted_by, promoted_at, current team summary). Skips
        the list scan ``GET /admin/users`` would otherwise force."""
        resp = self._request("GET", f"/admin/users/{user_id}")
        resp.raise_for_status()
        return AdminUserInfo.model_validate(resp.json())

    # -- challenges ---------------------------------------------------------

    def list_challenges(
        self,
        difficulty: str | None = None,
        tag: str = "",
        q: str = "",
        offset: int = 0,
        limit: int = 50,
    ) -> list[ChallengeInfo]:
        params: dict = {"offset": offset, "limit": limit}
        if difficulty:
            params["difficulty"] = difficulty
        if tag:
            params["tag"] = tag
        if q:
            params["q"] = q
        resp = self._request("GET", "/challenges", params=params)
        resp.raise_for_status()
        page = PaginatedResponse[ChallengeInfo].model_validate(resp.json())
        return page.items

    def get_challenge(self, challenge_id: str) -> ChallengeInfo:
        resp = self._request("GET", f"/challenges/{challenge_id}")
        resp.raise_for_status()
        return ChallengeInfo.model_validate(resp.json())

    # -- instances ----------------------------------------------------------

    def start_instance(
        self,
        challenge_id: str,
        ttl: int = DEFAULT_INSTANCE_TTL,
        *,
        competition_id: str = "",
        timeout: int = 300,
        poll_interval: float = 2.0,
        proxy_output_dir: str | None = None,
    ) -> InstanceReadyResult:
        """Start instance and wait until ready.

        Returns InstanceReadyResult with attack surface + sandbox network info.
        The .surface attribute provides backward compatibility.

        Args:
            challenge_id: Challenge ID (e.g., "XBOW-047").
            ttl: Time-to-live in seconds.
            competition_id: Which competition to spin the instance up
                under. Required when the calling user is on more than
                one team — agents tied to a single comp can leave it
                empty and the server picks the unambiguous team.
            timeout: Max seconds to wait for ready.
            poll_interval: Seconds between status polls.
            proxy_output_dir: Host path to store proxy traffic captures.
        """
        body: dict = {
            "challenge_id": challenge_id,
            "ttl": ttl,
            "competition_id": competition_id,
        }
        if proxy_output_dir:
            body["proxy_output_dir"] = proxy_output_dir
        resp = self._request("POST", "/instances", json=body)
        resp.raise_for_status()
        start = StartResponse.model_validate(resp.json())

        return _poll_instance_ready(
            self._client, start.instance_id, timeout=timeout, poll_interval=poll_interval
        )

    def get_instance_status(self, instance_id: str) -> InstanceStatusResponse:
        """Get instance status and attack surface."""
        resp = self._request("GET", f"/instances/{instance_id}/status")
        resp.raise_for_status()
        return InstanceStatusResponse.model_validate(resp.json())

    def stop_instance(self, instance_id: str) -> None:
        """Tear down ``instance_id``. Idempotent: a 404 from the server
        means the instance is already gone (auto-stopped after solve,
        TTL expiry, admin teardown) and is treated as success."""
        resp = self._request("DELETE", f"/instances/{instance_id}")
        if resp.status_code != 404:
            resp.raise_for_status()

    def renew_instance(self, instance_id: str, ttl: int = DEFAULT_INSTANCE_TTL) -> RenewResponse:
        """Extend the TTL of a running instance."""
        resp = self._request("POST", f"/instances/{instance_id}/renew", params={"ttl": ttl})
        resp.raise_for_status()
        return RenewResponse.model_validate(resp.json())

    # -- flag verification (low-level, used by CLI in local mode) -----------

    def verify_flag(self, instance_id: str, claimed_flag: str) -> VerifyFlagResponse:
        """Server-side flag verification (without recording as submission).

        Returns VerifyFlagResponse with ``.correct`` and ``.flag_id``.
        On multi-flag challenges ``.flag_id`` identifies which declared
        flag the claim matched (``None`` on wrong claims).
        """
        resp = self._request(
            "POST",
            f"/instances/{instance_id}/verify-flag",
            json={"claimed_flag": claimed_flag},
        )
        if resp.status_code == 404:
            return VerifyFlagResponse(correct=False)
        resp.raise_for_status()
        return VerifyFlagResponse.model_validate(resp.json())

    # -- submissions (platform mode, records score) -------------------------

    def submit_flag(self, instance_id: str, flag: str) -> SubmissionResponse:
        """Submit ``flag`` against ``instance_id``.

        The server reads challenge_id, team_id and competition_id off
        the instance row; the calling user must be on the same team
        that started this instance (in the same competition).
        """
        resp = self._request(
            "POST",
            "/submissions",
            json={"instance_id": instance_id, "flag": flag},
        )
        resp.raise_for_status()
        return SubmissionResponse.model_validate(resp.json())

    def list_submissions(
        self, challenge_id: str = "", offset: int = 0, limit: int = 50
    ) -> list[SubmissionState]:
        """List current team's submissions."""
        params: dict = {"offset": offset, "limit": limit}
        if challenge_id:
            params["challenge_id"] = challenge_id
        resp = self._request("GET", "/submissions", params=params)
        resp.raise_for_status()
        page = PaginatedResponse[SubmissionState].model_validate(resp.json())
        return page.items

    # -- scoreboard ---------------------------------------------------------

    def scoreboard(
        self, category: str = "", offset: int = 0, limit: int = 50
    ) -> list[ScoreboardEntry]:
        params: dict = {"offset": offset, "limit": limit}
        if category:
            params["category"] = category
        resp = self._request("GET", "/scoreboard", params=params)
        resp.raise_for_status()
        page = PaginatedResponse[ScoreboardEntry].model_validate(resp.json())
        return page.items

    def challenge_stats(self, offset: int = 0, limit: int = 50) -> list[ChallengeStats]:
        resp = self._request(
            "GET", "/scoreboard/challenges", params={"offset": offset, "limit": limit}
        )
        resp.raise_for_status()
        page = PaginatedResponse[ChallengeStats].model_validate(resp.json())
        return page.items

    # Aliases for naming consistency with MCP tools
    get_scoreboard = scoreboard
    get_challenge_stats = challenge_stats

    # -- health & status -----------------------------------------------------

    def health(self) -> HealthResponse:
        resp = self._request("GET", "/health")
        resp.raise_for_status()
        return HealthResponse.model_validate(resp.json())

    def list_instances(
        self,
        challenge_id: str = "",
        status: str = "",
        q: str = "",
        offset: int = 0,
        limit: int = 50,
    ) -> list[InstanceInfo]:
        """List all running instances."""
        params: dict = {"offset": offset, "limit": limit}
        if challenge_id:
            params["challenge_id"] = challenge_id
        if status:
            params["status"] = status
        if q:
            params["q"] = q
        resp = self._request("GET", "/instances", params=params)
        resp.raise_for_status()
        page = PaginatedResponse[InstanceInfo].model_validate(resp.json())
        return page.items

    # -- activities ---------------------------------------------------------

    def get_activities(
        self,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[Activity]:
        """Get platform activity log."""
        params: dict = {"offset": offset, "limit": limit}
        if team_id:
            params["team_id"] = team_id
        if challenge_id:
            params["challenge_id"] = challenge_id
        if event:
            params["event"] = event
        resp = self._request("GET", "/activities", params=params)
        resp.raise_for_status()
        return [Activity.model_validate(a) for a in resp.json()["items"]]

    # -- nodes --------------------------------------------------------------

    def list_nodes(self, offset: int = 0, limit: int = 50) -> list[NodeInfo]:
        resp = self._request("GET", "/nodes", params={"offset": offset, "limit": limit})
        resp.raise_for_status()
        page = PaginatedResponse[NodeInfo].model_validate(resp.json())
        return page.items

    def register_node(self, url: str, capacity: int = 10, labels: dict | None = None) -> NodeInfo:
        resp = self._request(
            "POST",
            "/nodes/register",
            json={
                "url": url,
                "capacity": capacity,
                "labels": labels or {},
            },
        )
        resp.raise_for_status()
        return NodeInfo.model_validate(resp.json())

    def remove_node(self, node_id: str) -> None:
        resp = self._request("DELETE", f"/nodes/{node_id}")
        resp.raise_for_status()
