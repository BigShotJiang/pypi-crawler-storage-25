"""Shared Docker utilities for instance providers."""

from __future__ import annotations

import re
import shutil
import tempfile
import time
from pathlib import Path

import docker
import docker.errors
from pydantic import BaseModel

from ctfy.core.config import CtfyConfig
from ctfy.core.log import log
from ctfy.providers.docker_provider.paths import to_host_path

# ---------------------------------------------------------------------------
# Prefix used for all pentest Docker resources
# ---------------------------------------------------------------------------
PREFIX: str = "pentest"


# ---------------------------------------------------------------------------
# ProxySidecar — encapsulates the per-instance mitmproxy + tcpdump fleet
# ---------------------------------------------------------------------------


class ProxySidecarState(BaseModel):
    """Tracks proxy + pcap sidecar resources for cleanup.

    One instance produces *N* of each kind, one per challenge container,
    sharing a single output directory and CA-cert volume. Both flavours
    join their target's network namespace so they observe browser →
    Traefik → container traffic transparently — no client-side proxy
    config required, no separate "attacker network".
    """

    # Mitmproxy transparent sidecars — one per challenge container.
    # Each joins the target's netns via ``--network container:<id>`` and
    # installs iptables PREROUTING redirects so inbound TCP on the
    # challenge's listening ports is intercepted on its way in.
    proxy_container_names: list[str] = []
    # tcpdump sidecars — one per challenge container, parallel layout
    # to ``proxy_container_names``. Capture every packet (including
    # mitmproxy's own forward leg) at the netns level for ground-truth
    # inspection.
    pcap_container_names: list[str] = []
    cert_volume: str = ""
    proxy_output: str = ""
    proxy_output_external: bool = False


def _resolve_bind_source(path: Path, *, config: CtfyConfig) -> str:
    """Pick the bind-mount source the docker daemon will resolve.

    With ``proxy_output_host_root`` set, ``path`` is already a literal
    host-resolvable absolute path (the node container 1:1-binds the
    same root internally). Otherwise translate via ``to_host_path``
    using ``host_project_root``.
    """
    if config.proxy_output_host_root:
        return str(path)
    return to_host_path(
        path,
        host_project_root=config.host_project_root,
        project_root=config.project_root,
    )


def _resolve_target_ports(
    docker_client: docker.DockerClient, container_name: str
) -> list[int]:
    """Return the TCP ports the target container is listening on.

    Read from ``Config.ExposedPorts`` (populated by Dockerfile ``EXPOSE``
    + compose ``expose`` / ``ports``). Empty list when the container is
    purely a worker / db without an exposed listener — caller can skip
    the proxy in that case.
    """
    try:
        attrs = docker_client.containers.get(container_name).attrs
    except docker.errors.NotFound:
        return []
    exposed = (attrs.get("Config") or {}).get("ExposedPorts") or {}
    ports: list[int] = []
    for spec in exposed.keys():
        # spec format: "80/tcp" or "5432/tcp" or "53/udp"
        port_str, _, proto = spec.partition("/")
        if proto and proto.lower() != "tcp":
            continue
        try:
            ports.append(int(port_str))
        except ValueError:
            continue
    return sorted(set(ports))


def start_proxy_sidecars(
    docker_client: docker.DockerClient,
    instance_id: str,
    target_container_names: list[str],
    *,
    config: CtfyConfig,
    proxy_output_dir: Path | None = None,
) -> ProxySidecarState:
    """Start one transparent mitmproxy sidecar per challenge container.

    Each sidecar joins its target's network namespace
    (``--network container:<id>``), installs iptables ``PREROUTING``
    REDIRECT rules for every TCP port the target is listening on, then
    runs mitmproxy in ``transparent`` mode. Inbound traffic — browser
    or agent, doesn't matter — is intercepted on the way in and logged
    as JSONL.

    Returns a single ``ProxySidecarState`` enumerating every spawned
    proxy + pcap container name plus the shared output / cert volume
    so ``stop_by_id`` can tear the whole fleet down idempotently.
    """
    if not target_container_names:
        # Nothing to attach to — caller guarantees this list comes from
        # ``_compose_target_containers`` so it skips the platform's own
        # sidecars; an empty list means the challenge has no targetable
        # listening container, which is unusual but not fatal.
        return ProxySidecarState()

    # Per-instance shared output dir
    if proxy_output_dir:
        output_path = proxy_output_dir
        output_path.mkdir(parents=True, exist_ok=True)
        external = True
    else:
        output_path = Path(tempfile.mkdtemp(prefix="pentest_proxy_"))
        external = False
    output_path.chmod(0o777)

    cert_vol = f"{PREFIX}_{instance_id}_certs"
    # Ensure CA exists before any sidecar starts so HTTPS clients that
    # download ``mitmproxy-ca-cert.pem`` don't race against startup.
    _warm_ca_cert(docker_client, cert_vol, image=config.image_mitmproxy)

    proxy_bind_source = _resolve_bind_source(output_path, config=config)

    proxy_names: list[str] = []
    for target in target_container_names:
        ports = _resolve_target_ports(docker_client, target)
        if not ports:
            log.info(
                "Skipping mitmproxy sidecar for target with no exposed TCP ports",
                target=target,
            )
            continue

        safe = re.sub(r"[^A-Za-z0-9_.-]", "_", target)
        sidecar_cname = f"{PREFIX}_{instance_id}_proxy_{safe}"

        try:
            docker_client.containers.get(sidecar_cname).remove(force=True)
        except docker.errors.NotFound:
            pass
        except Exception as exc:
            log.warning(
                "Failed to remove stale proxy sidecar",
                container=sidecar_cname,
                error=str(exc),
            )

        try:
            docker_client.containers.run(
                config.image_mitmproxy,
                name=sidecar_cname,
                detach=True,
                # Share the target's netns: all of its interfaces (and
                # only those) are visible. iptables rules in this netns
                # — installed by the entrypoint — REDIRECT inbound TCP
                # on the listening ports to mitmproxy:8080 here.
                network_mode=f"container:{target}",
                # Required for ``iptables -t nat`` and for setting
                # ``net.ipv4.ip_forward``.
                cap_add=["NET_ADMIN", "NET_RAW"],
                volumes={
                    cert_vol: {"bind": "/home/mitmproxy/.mitmproxy", "mode": "rw"},
                    proxy_bind_source: {"bind": "/output", "mode": "rw"},
                },
                environment={
                    "CTFY_INTERCEPT_PORTS": ",".join(str(p) for p in ports),
                },
            )
        except Exception as exc:
            log.warning(
                "Failed to start proxy sidecar",
                target=target,
                container=sidecar_cname,
                error=str(exc),
            )
            continue
        proxy_names.append(sidecar_cname)

    return ProxySidecarState(
        proxy_container_names=proxy_names,
        cert_volume=cert_vol,
        proxy_output=str(output_path),
        proxy_output_external=external,
    )


def _warm_ca_cert(
    docker_client: docker.DockerClient, cert_vol: str, *, image: str
) -> None:
    """Run a one-shot mitmdump just long enough to materialise the CA.

    The CA is shared by every transparent sidecar in this instance via
    ``cert_vol``. Doing it here means the cert is ready before any
    sidecar starts; no race when an operator wants to ``docker cp`` it
    out for browser trust setup.
    """
    warmer_name = f"{cert_vol}_warm"
    try:
        docker_client.containers.get(warmer_name).remove(force=True)
    except docker.errors.NotFound:
        pass

    try:
        warmer = docker_client.containers.run(
            image,
            name=warmer_name,
            detach=True,
            volumes={cert_vol: {"bind": "/home/mitmproxy/.mitmproxy", "mode": "rw"}},
            # Bypass the transparent entrypoint (it expects iptables
            # caps + a target netns we don't have here).
            entrypoint=["mitmdump"],
            command=["--mode", "regular@8080"],
        )
    except Exception as exc:
        log.warning("CA warmup failed to start", error=str(exc))
        return
    for _ in range(30):
        time.sleep(1)
        try:
            code, _ = warmer.exec_run(
                "test -f /home/mitmproxy/.mitmproxy/mitmproxy-ca-cert.pem"
            )
            if code == 0:
                break
        except Exception:
            pass
    try:
        warmer.remove(force=True)
    except Exception:
        pass


def start_pcap_sidecars(
    docker_client: docker.DockerClient,
    instance_id: str,
    target_container_names: list[str],
    *,
    image: str,
    output_path: Path,
    config: CtfyConfig,
) -> list[str]:
    """Spawn one tcpdump sidecar per challenge container.

    Each sidecar joins the target container's network namespace via
    ``--network container:<id>`` so it sees every interface the target
    has — capturing the raw packet stream alongside whatever mitmproxy
    parsed in the same netns (ground truth + parsed view stay in sync).

    Output is written to ``<output_path>/pcap/<container_name>.pcap``.
    The same bind-mount as the mitmproxy sidecar is reused so the
    ``InstanceArchive`` can pick everything up at stop time.

    *image* is reused from the mitmproxy build because it already has
    ``tcpdump`` installed and we ship it anyway — saves pulling a
    second image.

    Returns the list of sidecar container names so the caller can tear
    them down before compose-down (otherwise the netns disappears and
    tcpdump's pcap may be left without a final flush).
    """
    pcap_root = output_path / "pcap"
    pcap_root.mkdir(parents=True, exist_ok=True)
    pcap_root.chmod(0o777)

    if config.proxy_output_host_root:
        # Same fixed-convention assumption as the proxy sidecar — the
        # caller's ``output_path`` is already host-resolvable.
        host_pcap_root = str(pcap_root)
    else:
        host_pcap_root = to_host_path(
            pcap_root,
            host_project_root=config.host_project_root,
            project_root=config.project_root,
        )

    container_names: list[str] = []
    for target in target_container_names:
        # Sanitize the target name into a valid container name suffix.
        # Compose container names are already safe but we strip anything
        # that could trip docker's name regex just in case.
        safe = re.sub(r"[^A-Za-z0-9_.-]", "_", target)
        sidecar_cname = f"{PREFIX}_{instance_id}_pcap_{safe}"

        # Remove any stale sidecar from a prior run with the same id
        # (ourselves-after-restart, mostly). NotFound is the common
        # path; everything else gets logged but not raised because a
        # missing pcap is recoverable while a failed instance start is
        # not.
        try:
            docker_client.containers.get(sidecar_cname).remove(force=True)
        except docker.errors.NotFound:
            pass
        except Exception as exc:
            log.warning(
                "Failed to remove stale pcap sidecar",
                container=sidecar_cname,
                error=str(exc),
            )

        try:
            docker_client.containers.run(
                image,
                name=sidecar_cname,
                detach=True,
                # Share the *target's* network namespace. The sidecar
                # has no IP / network of its own — every interface
                # visible to the challenge container is visible to
                # tcpdump. This is what catches Traefik traffic.
                network_mode=f"container:{target}",
                volumes={
                    host_pcap_root: {"bind": "/pcap", "mode": "rw"},
                },
                # The image's default entrypoint (mitmproxy/entrypoint.sh)
                # tries ``sysctl net.ipv4.ip_forward=1`` then ``exec
                # mitmdump`` — the sysctl needs ``CAP_NET_ADMIN`` and
                # the exec discards our ``command`` entirely. Skip the
                # entrypoint so we run plain tcpdump, and grant only
                # the caps tcpdump itself needs (``CAP_NET_RAW`` to open
                # the capture socket; ``CAP_NET_ADMIN`` for ``-i any``
                # on the shared netns).
                entrypoint=["tcpdump"],
                cap_add=["NET_RAW", "NET_ADMIN"],
                # ``-U`` (packet-buffered) so each packet flushes to
                # disk immediately. ``-i any`` listens on every iface
                # the target container has. We write to a per-target
                # file so multi-service challenges don't clobber each
                # other.
                command=[
                    "-i", "any",
                    "-U",
                    "-w", f"/pcap/{safe}.pcap",
                ],
            )
        except Exception as exc:
            log.warning(
                "Failed to start pcap sidecar",
                target=target,
                container=sidecar_cname,
                error=str(exc),
            )
            continue
        container_names.append(sidecar_cname)
    return container_names


def stop_pcap_sidecars(
    docker_client: docker.DockerClient, container_names: list[str]
) -> None:
    """Gracefully stop pcap sidecars so tcpdump flushes its file.

    ``docker stop`` sends SIGTERM (then SIGKILL after a grace period);
    tcpdump catches the signal and writes any buffered records before
    exiting. Without this graceful path the trailing pcap records are
    sometimes lost when docker tears the netns down underneath
    tcpdump.
    """
    for name in container_names:
        try:
            c = docker_client.containers.get(name)
        except docker.errors.NotFound:
            continue
        try:
            c.stop(timeout=2)
        except Exception as exc:
            log.warning(
                "pcap sidecar stop failed",
                container=name,
                error=str(exc),
            )
        try:
            c.remove(force=True)
        except docker.errors.NotFound:
            pass
        except Exception as exc:
            log.warning(
                "pcap sidecar remove failed",
                container=name,
                error=str(exc),
            )


_BUSYBOX_IMAGE = "busybox:latest"


def _force_rmtree(path: Path, client) -> bool:
    """Remove *path* recursively, escalating to a root-in-container ``rm -rf``
    when the host uid can't delete files left by a previous (possibly
    container-root) controller run. Returns True on success.

    The escalation path is what makes docker-run → uv-run transitions
    survivable: otherwise `data/instances/<id>/flag` files written by a
    prior root process pile up forever and every startup logs a
    ``Permission denied`` warning.
    """
    try:
        shutil.rmtree(path)
        return True
    except PermissionError:
        pass
    except FileNotFoundError:
        return True
    try:
        client.images.get(_BUSYBOX_IMAGE)
    except docker.errors.ImageNotFound:
        try:
            client.images.pull(_BUSYBOX_IMAGE)
        except Exception as exc:
            log.warning("force rmtree: busybox pull failed", path=str(path), error=str(exc))
            return False
    try:
        client.containers.run(
            _BUSYBOX_IMAGE,
            command=["rm", "-rf", f"/parent/{path.name}"],
            volumes={str(path.parent): {"bind": "/parent", "mode": "rw"}},
            remove=True,
        )
    except Exception as exc:
        log.warning("force rmtree: busybox escalation failed", path=str(path), error=str(exc))
        return False
    return not path.exists()


def cleanup_orphans(*, instances_dir: Path, client=None) -> int:
    """Remove all pentest_* containers, networks, and instance dirs from a previous run.

    Called on server startup to clean up instances that outlived the process.
    Returns the number of resources cleaned up.
    """
    if client is None:
        try:
            client = docker.from_env()
        except Exception:
            return 0

    cleaned = 0
    # Containers
    for c in client.containers.list(all=True, filters={"name": f"{PREFIX}_"}):
        try:
            log.info("Cleaning orphan container", name=c.name)
            c.remove(force=True)
            cleaned += 1
        except Exception as e:
            log.warning("Failed to remove orphan", name=c.name, error=str(e))

    # Networks
    for n in client.networks.list(names=[f"{PREFIX}_"]):
        if n.name in ("bridge", "host", "none"):
            continue
        try:
            log.info("Cleaning orphan network", name=n.name)
            for cid in list(n.attrs.get("Containers", {}).keys()):
                try:
                    n.disconnect(cid, force=True)
                except Exception:
                    pass
            n.remove()
            cleaned += 1
        except Exception as e:
            log.warning("Failed to remove orphan network", name=n.name, error=str(e))

    # Volumes
    for v in client.volumes.list(filters={"name": f"{PREFIX}_"}):
        try:
            log.info("Cleaning orphan volume", name=v.name)
            v.remove(force=True)
            cleaned += 1
        except Exception as e:
            log.warning("Failed to remove orphan volume", name=v.name, error=str(e))

    # Instance workdirs
    if instances_dir.is_dir():
        for d in instances_dir.iterdir():
            if d.is_dir():
                log.info("Cleaning orphan instance dir", path=str(d))
                if _force_rmtree(d, client):
                    cleaned += 1
                else:
                    log.warning("Failed to remove instance dir", path=str(d))

    if cleaned:
        log.info("Orphan cleanup complete", cleaned=cleaned)
    return cleaned


def cleanup_containers(client, container_names: list[str]) -> None:
    """Force-remove containers, ignoring NotFound."""
    for name in container_names:
        try:
            client.containers.get(name).remove(force=True)
        except docker.errors.NotFound:
            pass
        except Exception as e:
            log.warning("Failed to remove container", container=name, error=str(e))


def cleanup_networks(client, network_names: list[str]) -> None:
    """Disconnect all endpoints and remove networks, ignoring NotFound."""
    for net_name in network_names:
        if not net_name:
            continue
        try:
            net = client.networks.get(net_name)
            net.reload()
            for cid in list(net.attrs.get("Containers", {}).keys()):
                try:
                    net.disconnect(cid, force=True)
                except Exception as e:
                    log.warning(
                        "Failed to disconnect container from network",
                        container=cid,
                        network=net_name,
                        error=str(e),
                    )
            net.remove()
        except docker.errors.NotFound:
            pass
        except Exception as e:
            log.warning("Failed to remove network", network=net_name, error=str(e))


def cleanup_volumes(client, volume_names: list[str]) -> None:
    """Remove volumes, ignoring NotFound."""
    for name in volume_names:
        if not name:
            continue
        try:
            client.volumes.get(name).remove()
        except docker.errors.NotFound:
            pass
        except Exception as e:
            log.warning("Failed to remove volume", volume=name, error=str(e))
