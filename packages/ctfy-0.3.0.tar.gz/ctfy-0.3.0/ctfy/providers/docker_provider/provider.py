"""Docker-based challenge provider — delegates container orchestration to
``docker compose``.

The upstream challenges repo (CTF-Arena/challenges) pins every challenge to
a standard ``docker-compose.yml`` shipping a ``flag-rotator`` sidecar that
injects the flag via a shared volume. Per the upstream CLAUDE.md, "the
platform runs a benchmark by ``docker compose up``-ing it", so we shell out
to the compose CLI rather than re-implementing the orchestration in Python.

Per-instance isolation is achieved via:

1. A unique compose project name (``pentest_<instance_id>``) so networks
   and containers don't collide across concurrent teams.
2. The base compose file is stripped of every service's ``ports:`` field
   so no challenge container binds a host port. Traefik discovers the
   containers via docker labels written to a ``compose.override.yml`` and
   routes ``<instance>.<traefik_domain>`` to them over the shared
   ``traefik_proxy`` docker network.
3. A per-instance workdir under ``instances_dir`` containing a duplicate
   of the challenge source tree, used as the compose build context.

Per-target transparent sidecars (mitmproxy + tcpdump) are then layered
on top — ``start_proxy_sidecars`` joins each challenge container's
network namespace and installs iptables PREROUTING redirects so all
inbound HTTP — browser or agent — is intercepted on the way in.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Any, ClassVar
from urllib.parse import urlparse

import docker
import docker.errors
import yaml
from pydantic import BaseModel, Field

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.config import CtfyConfig
from ctfy.core.exceptions import HealthCheckError, ProviderError
from ctfy.core.log import log
from ctfy.core.provider import ChallengeProvider, StartResult
from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType
from ctfy.providers.docker_provider.start_helpers import copy_challenge_dir
from ctfy.providers.docker_provider.utils import (
    PREFIX,
    ProxySidecarState,
    cleanup_volumes,
    start_pcap_sidecars,
    start_proxy_sidecars,
    stop_pcap_sidecars,
)

# How long to wait for `docker compose up --wait` before declaring failure.
_COMPOSE_UP_TIMEOUT = 180
# `docker compose up` retries on healthcheck failure; each retry tears down
# then re-runs up.
_STARTUP_RETRIES = 2


class _ServicePort(BaseModel):
    """One exposed port on a compose service.

    Every port is routed via Traefik: the service joins the shared Traefik
    network and gets docker labels so Traefik routes
    ``<subdomain>.<traefik_domain>`` to ``<container>:<container_port>``.
    No host port is ever bound.
    """

    service: str
    container_port: int
    protocol: str = "tcp"


class _RunningInstance(BaseModel):
    """Per-instance state we need to stop/verify later."""

    project: str
    workdir: Path
    compose_files: list[Path] = Field(default_factory=list)
    ports: list[_ServicePort] = Field(default_factory=list)
    flags: dict[str, str] = Field(default_factory=dict)
    vars: dict[str, str] = Field(default_factory=dict)
    proxy_state: ProxySidecarState | None = None


def _project_name(instance_id: str) -> str:
    """Sanitize an instance id into a valid docker compose project name.

    Compose allows lowercase, digits, hyphen, underscore only; must start
    with a letter or digit. We prefix ``pentest_`` so all our projects are
    greppable and the orphan cleaner can wipe them as one class.
    """
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in instance_id.lower())
    return f"{PREFIX}_{safe}"


_DNS_LABEL_RE = re.compile(r"[^a-z0-9-]+")


def _dns_safe(s: str) -> str:
    """Coerce *s* into a single DNS label: ``[a-z0-9-]+``, no leading/trailing dash.

    Used for building Traefik router names and instance subdomains. Compose
    project ids contain underscores (valid in compose, invalid in DNS) so we
    substitute them with hyphens.
    """
    collapsed = _DNS_LABEL_RE.sub("-", s.lower()).strip("-")
    # Guarantee non-empty so we never produce an empty label.
    return collapsed or "x"


def _parse_ports_entry(raw: Any) -> tuple[int, str] | None:
    """Extract (container_port, protocol) from one compose ``ports`` entry.

    Compose accepts several shapes:

    * ``"80"`` — container-only, protocol ``tcp``
    * ``"8080:80"`` — published:container
    * ``"8080:80/udp"`` — with protocol
    * ``{"target": 80, "published": 8080, "protocol": "udp"}`` — long form

    Host side is ignored: Traefik routes to the container by docker DNS,
    so only the container port + protocol matter.
    """
    if isinstance(raw, int):
        return raw, "tcp"
    if isinstance(raw, str):
        spec, _, proto = raw.partition("/")
        proto = proto or "tcp"
        parts = spec.split(":")
        container = parts[-1]  # last element is always container-side
        try:
            return int(container), proto
        except ValueError:
            return None
    if isinstance(raw, dict):
        target = raw.get("target")
        if target is None:
            return None
        try:
            return int(target), str(raw.get("protocol") or "tcp")
        except (TypeError, ValueError):
            return None
    return None


def _infer_service_type(container_port: int, protocol: str) -> ServiceType:
    """Tag a port's service type for the AttackSurface shown to agents.

    Every port is routed via Traefik (HTTP), but the surface metadata still
    distinguishes HTTPS (443) so agents pick the right scheme.
    """
    if protocol != "tcp":
        return ServiceType.TCP
    if container_port == 443:
        return ServiceType.HTTPS
    return ServiceType.HTTP


class DockerProvider(ChallengeProvider):
    """Runs challenges via ``docker compose``."""

    name: ClassVar[str] = "docker"

    def __init__(self, config: CtfyConfig):
        self.config = config
        self.challenges_dir = config.challenges_dir
        self._docker = docker.from_env()
        self._running: dict[str, _RunningInstance] = {}
        # Serialize per-challenge first-build so two concurrent starts of
        # the same challenge don't double-build the same image.
        self._build_locks: dict[str, threading.Lock] = {}
        self._build_locks_guard = threading.Lock()

    # -- public lifecycle ---------------------------------------------------

    def start(
        self,
        spec: ChallengeSpec,
        *,
        flags: dict[str, str],
        vars: dict[str, str] | None = None,
        proxy_output_dir: Path | None = None,
    ) -> StartResult:
        eid = spec.effective_id
        last_err: HealthCheckError | None = None
        for attempt in range(1, _STARTUP_RETRIES + 2):
            try:
                return self._do_start(
                    spec,
                    flags=flags,
                    vars=vars or {},
                    proxy_output_dir=proxy_output_dir,
                )
            except HealthCheckError as e:
                last_err = e
                log.warning(
                    "Startup health check failed",
                    challenge=eid,
                    attempt=attempt,
                    error=str(e),
                )
                self.stop(spec)
                if attempt <= _STARTUP_RETRIES:
                    log.info("Retrying instance start", challenge=eid, attempt=attempt + 1)
        # The loop runs at least once, so ``last_err`` is guaranteed to be
        # set by the time we fall out. The explicit check is for the type
        # checker, not runtime correctness.
        if last_err is None:
            raise RuntimeError("start loop exited without any attempt")
        raise last_err

    def _do_start(
        self,
        spec: ChallengeSpec,
        *,
        flags: dict[str, str],
        vars: dict[str, str] | None = None,
        proxy_output_dir: Path | None = None,
    ) -> StartResult:
        eid = spec.effective_id
        project = _project_name(eid)
        workdir = self.config.instances_dir / eid
        challenge_src = self.challenges_dir / spec.id
        challenge_dst = workdir / "challenge"
        compose_base = challenge_dst / "docker-compose.yml"
        compose_override = challenge_dst / "compose.override.yml"

        workdir.mkdir(parents=True, exist_ok=True)
        copy_challenge_dir(challenge_src, challenge_dst)

        if not compose_base.exists():
            raise ProviderError(f"docker-compose.yml not found in {challenge_src}")

        compose_data = _load_compose(compose_base)
        allocated = _collect_ports(compose_data)
        # Upstream challenges hardcode ``ports: - 80:<container>`` (or similar)
        # to publish on the host. That conflicts with Traefik's host:80 and is
        # unnecessary once Traefik routes by label. Compose's override-merge
        # for ``ports:`` is additive by {target, published, protocol} key, so
        # we can't erase the base entries from an override — we strip them
        # from the workdir copy of the base file before ``compose up``.
        _strip_host_port_bindings(compose_data)
        _dump_compose(compose_base, compose_data)
        # Subdomain uses the raw instance id (not the compose project name),
        # so users see ``<instance-id>.<domain>`` instead of the internal
        # ``pentest-`` namespace prefix.
        instance_safe_id = _dns_safe(eid)
        _write_override(
            compose_override,
            allocated,
            instance_safe_id=instance_safe_id,
            traefik_domain=self.config.traefik_domain,
            traefik_network=self.config.traefik_network,
        )

        self._running[eid] = _RunningInstance(
            project=project,
            workdir=workdir,
            compose_files=[compose_base, compose_override],
            ports=allocated,
        )

        compose_env = {**_build_flag_env(flags), **_build_var_env(vars or {})}
        with self._build_lock(spec.id):
            _compose_up(
                project=project,
                files=[compose_base, compose_override],
                env=compose_env,
                timeout=_COMPOSE_UP_TIMEOUT,
            )

        # Pick the per-instance proxy/pcap output root. Compose
        # deployments set ``proxy_output_host_root`` so the node and
        # the daemon-spawned sidecars agree on a host-resolvable
        # absolute path; bare-metal falls back to the workdir.
        if proxy_output_dir is not None:
            output_dir = proxy_output_dir
        elif self.config.proxy_output_host_root is not None:
            output_dir = self.config.proxy_output_host_root / eid
        else:
            output_dir = workdir / "proxy"

        # Identify the challenge's runtime containers up front: both
        # mitmproxy and tcpdump need them to attach to a netns.
        target_containers = self._compose_target_containers(project)

        # Transparent mitmproxy sidecars — one per target container.
        # They join the target's netns and install iptables PREROUTING
        # rules so inbound TCP on the challenge's listening ports is
        # captured regardless of whether the client used a proxy. There
        # is no separate "attacker network" — agents and browsers are
        # treated identically.
        try:
            proxy = start_proxy_sidecars(
                self._docker,
                eid,
                target_containers,
                config=self.config,
                proxy_output_dir=output_dir,
            )
        except Exception:
            # stop will clean up what compose brought up; re-raise after that.
            self.stop(spec)
            raise

        # tcpdump sidecars: also one per target, capturing the raw
        # packet stream as ground truth alongside mitmproxy's parsed
        # JSONL flows.
        if target_containers:
            try:
                proxy.pcap_container_names = start_pcap_sidecars(
                    self._docker,
                    eid,
                    target_containers,
                    image=self.config.image_mitmproxy,
                    output_path=Path(proxy.proxy_output),
                    config=self.config,
                )
            except Exception as exc:
                # Best-effort: a missing pcap is recoverable, so log
                # and continue rather than tearing the whole instance
                # down.
                log.warning(
                    "pcap sidecar setup failed",
                    instance=eid,
                    error=str(exc),
                )

        running = self._running[eid]
        running.flags = dict(flags)
        running.vars = dict(vars or {})
        running.proxy_state = proxy

        host_eps, sandbox_eps = _build_endpoints(
            allocated,
            instance_safe_id=instance_safe_id,
            traefik_domain=self.config.traefik_domain,
            traefik_public_url=self.config.traefik_public_url,
        )
        return StartResult(
            surface=AttackSurface(services=host_eps or sandbox_eps),
            flags=dict(flags),
        )

    def verify_flag(self, instance_id: str, claimed_flag: str) -> str | None:
        import hmac

        running = self._running.get(instance_id)
        if not running or not running.flags:
            return None
        for fid, actual in running.flags.items():
            if hmac.compare_digest(actual, claimed_flag):
                return fid
        return None

    def stop(self, spec: ChallengeSpec) -> None:
        self.stop_by_id(spec.effective_id)

    def stop_by_id(self, instance_id: str) -> None:
        running = self._running.pop(instance_id, None)
        if not running:
            return

        # Both kinds of sidecar share the target containers' netns. Stop
        # them *before* compose-down so tcpdump and mitmproxy receive
        # SIGTERM with their netns still alive — tcpdump flushes its
        # buffer, mitmproxy closes JSONL handles cleanly. Compose-down
        # afterwards tears the netns down, taking the now-empty
        # sidecars with it.
        if running.proxy_state:
            if running.proxy_state.pcap_container_names:
                stop_pcap_sidecars(self._docker, running.proxy_state.pcap_container_names)
            if running.proxy_state.proxy_container_names:
                stop_pcap_sidecars(self._docker, running.proxy_state.proxy_container_names)

        _compose_down(project=running.project, files=running.compose_files)

        # The shared CA volume + (when not externally managed) the
        # output directory are the only platform-side resources left.
        vol_names: list[str] = []
        if running.proxy_state:
            if running.proxy_state.cert_volume:
                vol_names.append(running.proxy_state.cert_volume)
            if running.proxy_state.proxy_output and not running.proxy_state.proxy_output_external:
                try:
                    shutil.rmtree(running.proxy_state.proxy_output)
                except Exception as e:
                    log.warning(
                        "Failed to remove proxy output",
                        path=running.proxy_state.proxy_output,
                        error=str(e),
                    )

        cleanup_volumes(self._docker, vol_names)

        if running.workdir.exists():
            try:
                shutil.rmtree(running.workdir)
            except Exception as e:
                log.warning("Failed to remove workdir", path=str(running.workdir), error=str(e))

    def stop_all(self) -> None:
        for instance_id in list(self._running):
            self.stop_by_id(instance_id)

    # -- health + sandbox accessors -----------------------------------------

    def check_health(self, instance_id: str) -> bool:
        running = self._running.get(instance_id)
        if not running:
            return False
        try:
            result = subprocess.run(
                ["docker", "compose", "-p", running.project, "ps", "--format", "json"],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            return False
        if result.returncode != 0:
            return False
        for line in result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if rec.get("State") not in ("running", "exited"):
                # exited is OK for the flag-rotator sidecar (it runs once).
                return False
        return True

    def _compose_target_containers(self, project: str) -> list[str]:
        """Return the names of the challenge's runtime containers.

        Filters out the platform-injected sidecars (mitmproxy proxy and
        upstream challenges' flag-rotator) so the pcap sidecar doesn't
        try to attach to itself or to the rotator that exits early.
        Falls back to an empty list on any docker error — the caller
        treats pcap as best-effort.
        """
        try:
            containers = self._docker.containers.list(
                filters={"label": f"com.docker.compose.project={project}"},
            )
        except Exception:
            return []
        names: list[str] = []
        for c in containers:
            name = c.name
            # Strip the leading slash docker.containers sometimes returns.
            if name.startswith("/"):
                name = name[1:]
            # Skip our own proxy + upstream's flag-rotator. The latter
            # is a one-shot sidecar that writes the flag file and
            # exits; tcpdump on its netns would die immediately.
            if name.endswith("_proxy") or "flag-rotator" in name or "flag_rotator" in name:
                continue
            names.append(name)
        return names

    def get_cert_volume(self, instance_id: str) -> str:
        running = self._running.get(instance_id)
        if running and running.proxy_state and running.proxy_state.cert_volume:
            return running.proxy_state.cert_volume
        return ""

    def get_proxy_output(self, instance_id: str) -> Path | None:
        running = self._running.get(instance_id)
        if running and running.proxy_state and running.proxy_state.proxy_output:
            return Path(running.proxy_state.proxy_output)
        return None

    def get_container_logs(self, instance_id: str) -> str:
        """Combined stdout+stderr for every service in the compose project.

        Captured synchronously via ``docker compose logs`` while the
        containers still exist. Returns an empty string if the project
        has already been torn down (compose returns non-zero) — callers
        accept that and skip writing the log file.
        """
        running = self._running.get(instance_id)
        if not running:
            return ""
        try:
            result = subprocess.run(
                [
                    "docker",
                    "compose",
                    "-p",
                    running.project,
                    "logs",
                    "--no-color",
                    "--timestamps",
                    "--tail",
                    "all",
                ],
                capture_output=True,
                text=True,
                check=False,
                timeout=30,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return ""
        if result.returncode != 0:
            return result.stdout or ""
        return result.stdout

    # -- internal helpers ---------------------------------------------------

    def _build_lock(self, challenge_id: str) -> threading.Lock:
        with self._build_locks_guard:
            return self._build_locks.setdefault(challenge_id, threading.Lock())


# ---------------------------------------------------------------------------
# Module-level compose helpers (pure functions, easy to patch in tests)
# ---------------------------------------------------------------------------


def _load_compose(path: Path) -> dict:
    try:
        data = yaml.safe_load(path.read_text()) or {}
    except yaml.YAMLError as e:
        raise ProviderError(f"docker-compose.yml parse error in {path}: {e}") from e
    if not isinstance(data, dict):
        raise ProviderError(f"docker-compose.yml must be a mapping: {path}")
    return data


def _dump_compose(path: Path, data: dict) -> None:
    path.write_text(yaml.safe_dump(data, sort_keys=False))


def _collect_ports(compose_data: dict) -> list[_ServicePort]:
    """Collect every exposed (service, container_port, protocol) for Traefik."""
    collected: list[_ServicePort] = []
    for sname, svc in (compose_data.get("services") or {}).items():
        if not isinstance(svc, dict):
            continue
        for entry in svc.get("ports") or []:
            parsed = _parse_ports_entry(entry)
            if parsed is None:
                log.warning(
                    "Skipping unparseable ports entry",
                    service=sname,
                    entry=entry,
                )
                continue
            container_port, protocol = parsed
            collected.append(
                _ServicePort(
                    service=sname,
                    container_port=container_port,
                    protocol=protocol,
                )
            )
    return collected


def _build_flag_env(flags: dict[str, str]) -> dict[str, str]:
    """Compose the env vars that carry flag values into challenge containers.

    Two mutually exclusive conventions, picked by flag count:

    * **Single-flag challenge** (1 flag) — exposed as ``$FLAG``. The flag id
      is irrelevant to the container; it only matters for platform-side
      bookkeeping (scoreboard, solves). This matches the upstream
      ``CTF-Arena/challenges`` slim-v3 contract where every challenge's
      compose / Dockerfile / entrypoint references ``${FLAG}``.
    * **Multi-flag challenge** (2+ flags) — each flag exposed as
      ``$FLAG_<UPPER_ID>`` (e.g. ``$FLAG_FOOTHOLD``, ``$FLAG_ROOT``).
      ``$FLAG`` is *not* set, so authors can rely on its absence to detect
      multi-flag mode at runtime if needed.

    Authors writing a multi-flag challenge therefore opt into the
    ``$FLAG_<ID>`` namespace explicitly via ``flags: [foothold, root, ...]``
    in metadata.yaml; everything else stays on the simpler ``$FLAG``.
    """
    if len(flags) == 1:
        return {"FLAG": next(iter(flags.values()))}
    return {f"FLAG_{fid.upper()}": value for fid, value in flags.items()}


def _build_var_env(vars: dict[str, str]) -> dict[str, str]:
    """Compose the env vars that carry per-instance random tokens.

    Every var (private or public) is exposed as ``$VAR_<UPPER_ID>``.
    No alias, no single-var shortcut — vars are always namespaced so an
    author can declare a single ``vars: [admin_path]`` today and
    additional ones tomorrow without rewriting compose env references.
    """
    return {f"VAR_{vid.upper()}": value for vid, value in vars.items()}


def _strip_host_port_bindings(compose_data: dict) -> None:
    """Remove every service's ``ports:`` field so no host port is published.

    Mutates *compose_data* in place. Traefik discovers containers by label
    and talks to them over the shared docker network, so host publishing is
    unnecessary (and fights Traefik's own host:80 binding).
    """
    for svc in (compose_data.get("services") or {}).values():
        if isinstance(svc, dict):
            svc.pop("ports", None)


def _write_override(
    path: Path,
    allocated: list[_ServicePort],
    *,
    instance_safe_id: str,
    traefik_domain: str,
    traefik_network: str,
) -> None:
    """Generate ``compose.override.yml`` with Traefik labels + network attachment."""
    routes_by_service: dict[str, list[_ServicePort]] = {}
    for p in allocated:
        routes_by_service.setdefault(p.service, []).append(p)

    services: dict[str, dict] = {}
    # Single HTTP service → ``<instance>.<domain>``; multiple HTTP services
    # within the same instance → ``<svc>.<instance>.<domain>`` so each has a
    # unique Host rule.
    multi_service = len(routes_by_service) > 1
    for sname, routes in routes_by_service.items():
        svc_block = services.setdefault(sname, {})
        svc_block["networks"] = ["default", traefik_network]
        svc_safe = _dns_safe(sname)
        host = (
            f"{svc_safe}.{instance_safe_id}.{traefik_domain}"
            if multi_service
            else f"{instance_safe_id}.{traefik_domain}"
        )
        labels: list[str] = ["traefik.enable=true", f"traefik.docker.network={traefik_network}"]
        for route in routes:
            # Router/service names must be unique per Traefik process. Instance
            # id is globally unique; adding service+port disambiguates within
            # a multi-port / multi-HTTP instance.
            tk = f"{instance_safe_id}-{svc_safe}-{route.container_port}"
            labels.extend(
                [
                    f"traefik.http.routers.{tk}.rule=Host(`{host}`)",
                    f"traefik.http.routers.{tk}.entrypoints=web",
                    f"traefik.http.routers.{tk}.service={tk}",
                    f"traefik.http.services.{tk}.loadbalancer.server.port={route.container_port}",
                ]
            )
        svc_block["labels"] = labels

    doc: dict[str, Any] = {"services": services}
    if routes_by_service:
        doc["networks"] = {traefik_network: {"external": True, "name": traefik_network}}
    path.write_text(yaml.safe_dump(doc, sort_keys=False))


def _compose_up(
    *,
    project: str,
    files: list[Path],
    env: dict[str, str],
    timeout: int,
) -> None:
    cmd = ["docker", "compose", "-p", project]
    for f in files:
        cmd.extend(["-f", str(f)])
    cmd.extend(["up", "-d", "--wait", "--build"])
    import os

    proc_env = {**os.environ, **env}
    log.info("docker compose up", project=project, files=[str(f) for f in files])
    result = subprocess.run(
        cmd,
        env=proc_env,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    if result.returncode != 0:
        raise HealthCheckError(
            project,
            f"`docker compose up` failed (exit {result.returncode}): "
            f"{result.stderr.strip()[-1500:]}",
        )


def _compose_down(*, project: str, files: list[Path]) -> None:
    cmd = ["docker", "compose", "-p", project]
    for f in files:
        if f.exists():
            cmd.extend(["-f", str(f)])
    cmd.extend(["down", "-v", "--remove-orphans"])
    try:
        subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=60)
    except subprocess.TimeoutExpired:
        log.warning("docker compose down timed out", project=project)


def _build_endpoints(
    allocated: list[_ServicePort],
    *,
    instance_safe_id: str,
    traefik_domain: str,
    traefik_public_url: str,
) -> tuple[list[ServiceEndpoint], list[ServiceEndpoint]]:
    """Turn allocated ports into (host_endpoints, sandbox_endpoints).

    Host endpoints: ``<instance>.<domain>:<traefik_port>`` (single HTTP
    service) or ``<svc>.<instance>.<domain>:<traefik_port>`` (multi-HTTP).
    Sandbox endpoints: the compose service name + container port —
    agents resolve services by docker DNS on the compose default
    network. Both flow paths are intercepted transparently by the
    in-netns mitmproxy sidecars.
    """
    _, traefik_port = _traefik_public_host_port(traefik_public_url, traefik_domain)
    # Must agree with _write_override: subdomain disambiguates only when an
    # instance has more than one exposed service.
    services = {p.service for p in allocated}
    multi_service = len(services) > 1
    host_eps: list[ServiceEndpoint] = []
    sandbox_eps: list[ServiceEndpoint] = []
    for p in allocated:
        stype = _infer_service_type(p.container_port, p.protocol)
        svc_safe = _dns_safe(p.service)
        subdomain_host = (
            f"{svc_safe}.{instance_safe_id}.{traefik_domain}"
            if multi_service
            else f"{instance_safe_id}.{traefik_domain}"
        )
        host_eps.append(
            ServiceEndpoint(
                service_type=stype,
                host=subdomain_host,
                port=traefik_port,
                label=p.service,
            )
        )
        sandbox_eps.append(
            ServiceEndpoint(
                service_type=stype,
                host=p.service,
                port=p.container_port,
                label=p.service,
            )
        )
    return host_eps, sandbox_eps


def _traefik_public_host_port(public_url: str, domain: str) -> tuple[str, int]:
    """Resolve the public-facing host + port for Traefik URLs.

    Falls back to ``http://{domain}:80`` when ``public_url`` is empty. When
    the URL omits an explicit port we default to 80 for http, 443 for https.
    """
    url = public_url.strip() or f"http://{domain}"
    parsed = urlparse(url)
    host = parsed.hostname or domain
    if parsed.port:
        return host, parsed.port
    return host, 443 if parsed.scheme == "https" else 80
