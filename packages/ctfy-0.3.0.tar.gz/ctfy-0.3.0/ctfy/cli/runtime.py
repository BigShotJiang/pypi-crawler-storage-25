"""Shared CLI runtime helpers: client settings pulled from ``ctx.obj``, Rich
consoles, and the fail-fast ``PlatformClient`` factory used by every
subcommand. All values originate in the top-level typer callback; this
module never reads the environment or the filesystem directly."""

from __future__ import annotations

import httpx
import typer
from rich.console import Console

from ctfy.sdk import PlatformClient

__all__ = [
    "console",
    "err_console",
    "platform_url",
    "token",
    "get_client",
    "auth_headers",
]

console = Console()
err_console = Console(stderr=True)


def platform_url(ctx: typer.Context) -> str:
    """Return the platform URL chosen at the top-level callback."""
    return ctx.obj["platform_url"]


def token(ctx: typer.Context) -> str:
    """Return the bearer token passed via ``--token`` / ``CTFY_TOKEN``."""
    return ctx.obj.get("token", "")


def get_client(ctx: typer.Context, *, require_auth: bool = True) -> PlatformClient:
    """Return a PlatformClient cached on ``ctx.obj``.

    Fails fast with an actionable error when the platform is unreachable;
    never auto-starts anything. ``require_auth`` controls whether a bearer
    token is required (a few read-only commands may run anon).
    """
    if ctx.obj is None:
        ctx.obj = {}
    if "client" in ctx.obj:
        return ctx.obj["client"]

    url = platform_url(ctx)
    tok = token(ctx)
    if require_auth and not tok:
        err_console.print(
            "[red]No bearer token configured.[/red]\n"
            "  Sign in at the web UI with GitHub/Google, then create an\n"
            "  agent token in Settings → API Tokens and export it as\n"
            "  CTFY_TOKEN (or pass --token)."
        )
        raise typer.Exit(2)

    client = PlatformClient(url, token=tok)
    # Probe so we fail fast instead of at the first API call.
    try:
        client.health()
    except (httpx.ConnectError, httpx.TimeoutException) as e:
        err_console.print(
            f"[red]No platform at {url}.[/red]\n"
            "  Start one in another terminal with [bold]ctfy server start[/bold],\n"
            "  or pass --platform-url / CTFY_PLATFORM_URL pointing at a running platform.\n"
            f"  ({e.__class__.__name__}: {e})"
        )
        raise typer.Exit(2)
    ctx.obj["client"] = client
    return client


def auth_headers(ctx: typer.Context) -> dict[str, str]:
    """Build an ``Authorization`` header dict for API calls."""
    tok = token(ctx)
    return {"Authorization": f"Bearer {tok}"} if tok else {}
