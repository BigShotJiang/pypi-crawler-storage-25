"""`ctfy node …` — worker-node lifecycle + cluster membership."""

from __future__ import annotations

import typer
import uvicorn
from rich.table import Table

from ctfy.cli.runtime import console, err_console, get_client
from ctfy.core.config import CtfyConfig
from ctfy.core.log import setup_logging

node_app = typer.Typer(help="Worker-node cluster membership", no_args_is_help=True)


@node_app.command("join")
def node_join(
    ctx: typer.Context,
    host: str = typer.Option("0.0.0.0", "--host", help="Bind address"),
    port: int = typer.Option(8101, "--port", help="Bind port"),
    public_url: str = typer.Option(
        "",
        "--public-url",
        envvar="CTFY_NODE_PUBLIC_URL",
        help="URL the platform/agents use to reach this node",
    ),
    capacity: int = typer.Option(
        0,
        "--capacity",
        envvar="CTFY_NODE_CAPACITY",
        help=(
            "Max concurrent instances. 0 (default) auto-derives from CPU + RAM "
            "(min(cores * 2, mem_gb)); pass an explicit number to override."
        ),
    ),
    display_name: str = typer.Option(
        "",
        "--display-name",
        envvar="CTFY_NODE_DISPLAY_NAME",
        help="Human-readable label shown in the admin UI (defaults to public URL).",
    ),
    label: list[str] = typer.Option([], "--label", help="Node label (k=v), repeatable"),
    labels_csv: str = typer.Option(
        "",
        "--labels",
        envvar="CTFY_NODE_LABELS",
        help="Labels as `k1=v1,k2=v2` CSV (merged with --label).",
    ),
    no_register: bool = typer.Option(
        False, "--no-register", help="Skip platform self-registration (debug)"
    ),
    node_token: str = typer.Option(
        "",
        "--node-token",
        envvar="CTFY_NODE_TOKEN",
        help=(
            "One-time registration token from `ctfy server invite`. Consumed "
            "on the first successful register; the platform mints long-lived "
            "per-node credentials in exchange."
        ),
    ),
):
    """Start this worker and join the platform cluster.

    Lower-level knobs (paths, ports, image tags) are read from ``CTFY_*``
    env vars — see ``ctfy config show`` for the full surface.
    """
    setup_logging()

    labels: dict[str, str] = {}
    items = list(label) + [x for x in labels_csv.split(",") if x.strip()]
    for item in items:
        if "=" in item:
            k, v = item.split("=", 1)
            labels[k.strip()] = v.strip()
        else:
            labels[item.strip()] = "true"

    config = CtfyConfig.from_env(
        overrides={
            "platform_url": ctx.obj["platform_url"],
            "server_port": port,
        }
    )

    if not any(config.challenges_dir.glob("*/metadata.yaml")):
        console.print(
            f"[yellow]No challenges found at {config.challenges_dir}. "
            f"Run [bold]ctfy challenge sync[/bold] to clone "
            f"{config.challenges_repo}.[/yellow]"
        )

    from ctfy.server.node_app import create_node_app

    app_ = create_node_app(
        config,
        registration_token=node_token,
        public_url=public_url,
        display_name=display_name,
        capacity=capacity,
        labels=labels or None,
        platform_url=ctx.obj["platform_url"],
        auto_register=not no_register,
    )
    console.print(f"Starting node on [bold]{host}:{port}[/bold]")
    uvicorn.run(app_, host=host, port=port)


@node_app.command("leave")
def node_leave():
    """Deregister this node from the platform and stop it."""
    err_console.print(
        "[yellow]`ctfy node join` runs in the foreground and deregisters on Ctrl-C. "
        "Stop it there, or use `ctfy node rm <node_id>` from the platform host to "
        "force a removal.[/yellow]"
    )
    raise typer.Exit(2)


@node_app.command("ls")
def node_ls(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """List nodes registered with the platform."""
    setup_logging()
    client = get_client(ctx, require_auth=False)
    nodes = client.list_nodes()

    if json_output:
        console.print_json(data=nodes)
        return

    table = Table(title="Compute Nodes")
    table.add_column("ID", style="cyan")
    table.add_column("URL")
    table.add_column("Capacity", justify="right")
    table.add_column("Running", justify="right")
    table.add_column("Health")
    table.add_column("Labels", style="dim")

    for n in nodes:
        healthy = n.get("healthy") if isinstance(n, dict) else getattr(n, "healthy", False)
        health = "[green]healthy[/]" if healthy else "[red]unhealthy[/]"
        node_id = n.get("node_id", "") if isinstance(n, dict) else getattr(n, "node_id", "")
        url = n.get("url", "") if isinstance(n, dict) else getattr(n, "url", "")
        capacity = n.get("capacity", "") if isinstance(n, dict) else getattr(n, "capacity", "")
        running = n.get("running", "") if isinstance(n, dict) else getattr(n, "running", "")
        labels = n.get("labels", {}) if isinstance(n, dict) else getattr(n, "labels", {})
        labels_csv = ", ".join(f"{k}={v}" for k, v in labels.items()) if labels else ""
        table.add_row(node_id, url, str(capacity), str(running), health, labels_csv)
    console.print(table)
    console.print(f"\n[bold]{len(nodes)}[/bold] node(s)")


@node_app.command("rm")
def node_rm(
    ctx: typer.Context,
    node_id: str = typer.Argument(help="Node ID to deregister"),
):
    """Force-remove a node from the platform (admin)."""
    setup_logging()
    client = get_client(ctx, require_auth=False)
    try:
        client.remove_node(node_id)
    except Exception as e:
        err_console.print(f"[red]Failed: {e}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Node removed: {node_id}[/green]")
