"""`ctfy challenge …` — static challenge assets in challenges_dir."""

from __future__ import annotations

import subprocess
from collections.abc import Iterable
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path

import typer
import yaml
from pydantic import ValidationError
from rich.table import Table

from ctfy.cli.runtime import console, err_console
from ctfy.core.challenge import ChallengeSpec
from ctfy.core.challenge_validate import validate_dir
from ctfy.core.config import CtfyConfig
from ctfy.core.enums import Difficulty
from ctfy.core.log import log, setup_logging

challenge_app = typer.Typer(help="Static challenge assets in challenges_dir", no_args_is_help=True)

# How long to wait for one `docker compose pull|build` step. Pulling a large
# base image or building from scratch can be slow on a cold node; an hour
# matches what a reasonable single-image build/pull should never exceed.
_PREBUILD_STEP_TIMEOUT = 3600


def _default_challenges_dir() -> Path:
    return CtfyConfig.model_fields["challenges_dir"].default


CHALLENGES_DIR_OPTION = typer.Option(
    _default_challenges_dir(),
    "--challenges-dir",
    envvar="CTFY_CHALLENGES_DIR",
    help="Directory containing challenge metadata.yaml files.",
)


def iter_challenge_specs(
    challenges_dir: Path,
    *,
    challenge_id: str | None = None,
    difficulty: Difficulty | None = None,
    tag: str | None = None,
) -> Iterable[ChallengeSpec]:
    if not challenges_dir.exists():
        return
    for d in sorted(challenges_dir.iterdir()):
        yml = d / "metadata.yaml"
        if not d.is_dir() or not yml.exists():
            continue
        try:
            spec = ChallengeSpec.from_yaml(yml)
        except (ValidationError, yaml.YAMLError) as e:
            log.warning("Skipping invalid challenge spec", path=str(yml), error=str(e))
            continue
        if challenge_id:
            patterns = [p.strip() for p in challenge_id.split(",")]
            if not any(spec.id == p or spec.id.startswith(p + "-") for p in patterns):
                continue
        if difficulty is not None and spec.difficulty != difficulty:
            continue
        if tag and tag not in spec.tags:
            continue
        yield spec


@challenge_app.command("sync")
def challenge_sync(
    repo: str = typer.Option(
        "",
        "--repo",
        envvar="CTFY_CHALLENGES_REPO",
        help="Git repo URL (default: from config).",
    ),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """Clone or fast-forward-pull the challenges repo locally.

    Run once after install, then whenever you want to pick up upstream
    changes. Server / node startup no longer pulls automatically.
    """
    setup_logging()
    config = CtfyConfig.from_env(
        overrides={
            "challenges_repo": repo,
            "challenges_dir": challenges_dir,
        }
    )
    from ctfy.core.challenges_sync import ensure_challenges

    ensure_challenges(config.challenges_dir, config.challenges_repo)
    console.print(f"[green]✓ Synced {config.challenges_repo} → {config.challenges_dir}[/green]")


@challenge_app.command("ls")
def challenge_ls(
    challenge: str | None = typer.Option(
        None, "--challenge", help="Filter by challenge ID (comma-separated, prefix-match)"
    ),
    difficulty: Difficulty | None = typer.Option(
        None, "--difficulty", help="Filter by difficulty (easy | medium | hard)"
    ),
    tag: str | None = typer.Option(None, "--tag", help="Filter by a single tag"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """List challenge definitions in challenges_dir."""
    setup_logging()
    specs = list(
        iter_challenge_specs(challenges_dir, challenge_id=challenge, difficulty=difficulty, tag=tag)
    )

    if json_output:
        console.print_json(data=[s.model_dump(mode="json") for s in specs])
        return

    table = Table(title="Challenge Definitions")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Difficulty", style="magenta")
    table.add_column("Tags", style="dim")
    for spec in specs:
        table.add_row(spec.id, spec.name, spec.difficulty.value, ", ".join(spec.tags))
    console.print(table)
    console.print(f"\n[bold]{len(specs)}[/bold] challenge(s)")


@challenge_app.command("show")
def challenge_show(
    challenge_id: str = typer.Argument(help="Challenge ID"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a summary"),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """Show full metadata for a single challenge."""
    setup_logging()
    for spec in iter_challenge_specs(challenges_dir, challenge_id=challenge_id):
        if spec.id == challenge_id:
            if json_output:
                console.print_json(data=spec.model_dump(mode="json"))
            else:
                console.print(spec.model_dump(mode="json"))
            return
    err_console.print(f"[red]Challenge not found: {challenge_id}[/red]")
    raise typer.Exit(1)


@challenge_app.command("validate")
def challenge_validate(
    challenge_id: str | None = typer.Argument(
        None, help="Challenge ID to validate (omit with --all to scan every challenge)"
    ),
    all_: bool = typer.Option(
        False, "--all", help="Validate every metadata.yaml in challenges_dir"
    ),
    strict: bool = typer.Option(
        False, "--strict", help="Passed through to the upstream audit (warnings become errors)."
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit one JSON object per finding"),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """Validate metadata + compose + source-code hygiene via the upstream audit."""
    setup_logging()
    if not all_ and not challenge_id:
        err_console.print("[red]Pass a challenge ID or --all.[/red]")
        raise typer.Exit(2)

    findings = validate_dir(
        challenges_dir,
        challenge_id=None if all_ else challenge_id,
        strict=strict,
    )

    if not findings:
        err_console.print("[red]No challenges matched.[/red]")
        raise typer.Exit(2)

    failed = [f for f in findings if not f.ok]

    if json_output:
        import json

        for f in findings:
            console.print(
                json.dumps(
                    {"challenge": f.challenge, "status": f.status, "reason": f.reason},
                    ensure_ascii=False,
                )
            )
    else:
        for f in findings:
            if f.ok:
                console.print(f"[green]OK[/green]    {f.challenge}")
            else:
                console.print(f"[red]FAIL[/red]  {f.challenge}: {f.reason}")
        console.print(
            f"\n[bold]{len(findings) - len(failed)}[/bold] ok, [bold]{len(failed)}[/bold] failed"
        )

    if failed:
        raise typer.Exit(1)


@dataclass
class _PrebuildFailure:
    challenge_id: str
    step: str  # "pull" or "build"
    detail: str


def _prebuild_project_name(challenge_id: str) -> str:
    """Compose project name for a prebuild run.

    Compose requires lowercase alphanumeric + ``-_`` only, starting with a
    letter or digit. Some upstream challenge IDs are uppercase (e.g.
    ``CTFARENA-00``), which compose rejects. Mirror the sanitizer in
    :func:`ctfy.providers.docker_provider.provider._project_name` —
    lowercase, replace anything outside ``[a-z0-9-_]`` with underscore —
    so prebuild never trips compose's name validation.
    """
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in challenge_id.lower())
    return f"ctfy-prebuild-{safe}"


def _prebuild_compose_cmd(*, project: str, compose_file: Path, step: str) -> list[str]:
    """Build the ``docker compose … pull|build`` argv for one challenge."""
    return [
        "docker",
        "compose",
        "-p",
        project,
        "-f",
        str(compose_file),
        step,
    ]


def _prebuild_one(
    spec: ChallengeSpec, challenges_dir: Path, *, stream: bool
) -> _PrebuildFailure | None:
    """Pull base + pre-built images and build local Dockerfiles for one challenge.

    Runs ``docker compose pull`` then ``docker compose build`` directly
    against the canonical ``challenges_dir/<id>/docker-compose.yml`` —
    no per-instance workdir copy. Build cache populated here is keyed by
    Dockerfile + context content, so the lazy ``_compose_up()`` path on
    first instance start reuses it under whatever project name it picks.
    Returns a :class:`_PrebuildFailure` for the first failing step (we
    skip ``build`` if ``pull`` failed, since the image set is already in
    a bad state), or None on success.

    When *stream* is True, compose's stdout/stderr is forwarded to the
    user's terminal so build progress is visible in real time. On failure
    the summary just reports the exit code — the actual error already
    scrolled by above. When *stream* is False (parallel mode), output is
    captured so concurrent builds don't interleave on the terminal, and
    the tail surfaces in the failure summary.
    """
    compose_file = challenges_dir / spec.id / "docker-compose.yml"
    if not compose_file.exists():
        return _PrebuildFailure(spec.id, "pull", f"docker-compose.yml not found: {compose_file}")

    project = _prebuild_project_name(spec.id)
    for step in ("pull", "build"):
        cmd = _prebuild_compose_cmd(project=project, compose_file=compose_file, step=step)
        log.info("docker compose " + step, challenge=spec.id, project=project)
        run_kwargs: dict[str, object] = {
            "timeout": _PREBUILD_STEP_TIMEOUT,
            "check": False,
        }
        if not stream:
            run_kwargs["capture_output"] = True
            run_kwargs["text"] = True
        try:
            result = subprocess.run(cmd, **run_kwargs)
        except FileNotFoundError:
            return _PrebuildFailure(spec.id, step, "`docker` binary not found on PATH")
        except subprocess.TimeoutExpired:
            return _PrebuildFailure(spec.id, step, f"timed out after {_PREBUILD_STEP_TIMEOUT}s")
        if result.returncode != 0:
            if stream:
                # Output already scrolled by; pointing the user up is more
                # useful than a synthesized one-liner.
                detail = f"exit {result.returncode} (see output above)"
            else:
                tail = (result.stderr or result.stdout or "").strip()[-1500:]
                detail = tail or f"exit {result.returncode}"
            return _PrebuildFailure(spec.id, step, detail)
    return None


@challenge_app.command("prebuild")
def challenge_prebuild(
    challenge: str | None = typer.Option(
        None,
        "--challenge",
        help="Filter by challenge ID (comma-separated, prefix-match).",
    ),
    difficulty: Difficulty | None = typer.Option(
        None, "--difficulty", help="Filter by difficulty (easy | medium | hard)."
    ),
    tag: str | None = typer.Option(None, "--tag", help="Filter by a single tag."),
    jobs: int = typer.Option(
        1,
        "--jobs",
        "-j",
        min=1,
        help=(
            "Prebuild N challenges in parallel. With the default of 1, "
            "compose's build/pull progress streams live to the terminal; "
            "with N>1, output is captured per challenge and only the tail "
            "of any failure is printed (otherwise concurrent builds would "
            "interleave on the terminal)."
        ),
    ),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """Pre-pull base images + pre-build challenge Dockerfiles.

    The first user to start any challenge would otherwise pay the cost of
    `docker compose up --build` populating the layer cache from cold. Run
    this on every worker node after `ctfy challenge sync` to make first-
    instance starts hit a warm cache.

    Failures on individual challenges are logged and the run continues;
    the command exits non-zero if any challenge failed.
    """
    setup_logging()

    specs = list(
        iter_challenge_specs(challenges_dir, challenge_id=challenge, difficulty=difficulty, tag=tag)
    )
    if not specs:
        err_console.print(f"[yellow]No challenges matched in {challenges_dir}.[/yellow]")
        raise typer.Exit(2)

    console.print(
        f"Prebuilding [bold]{len(specs)}[/bold] challenge(s) with [bold]{jobs}[/bold] worker(s)…"
    )

    failures: list[_PrebuildFailure] = []
    succeeded = 0

    # Stream compose output directly to the terminal in sequential mode so
    # users see `[+] Building n/m` in real time. Parallel mode captures —
    # otherwise N concurrent compose processes interleave into a mess.
    stream = jobs == 1

    def _run(spec: ChallengeSpec) -> tuple[ChallengeSpec, _PrebuildFailure | None]:
        return spec, _prebuild_one(spec, challenges_dir, stream=stream)

    if jobs == 1:
        for spec in specs:
            console.print(f"  [cyan]→[/cyan] {spec.id}")
            _, failure = _run(spec)
            if failure is None:
                console.print(f"  [green]✓[/green] {spec.id}")
                succeeded += 1
            else:
                console.print(f"  [red]✗[/red] {spec.id} ({failure.step})")
                failures.append(failure)
    else:
        with ThreadPoolExecutor(max_workers=jobs) as pool:
            futures = [pool.submit(_run, spec) for spec in specs]
            for fut in as_completed(futures):
                spec, failure = fut.result()
                if failure is None:
                    console.print(f"  [green]✓[/green] {spec.id}")
                    succeeded += 1
                else:
                    console.print(f"  [red]✗[/red] {spec.id} ({failure.step})")
                    failures.append(failure)

    console.print(f"\n[bold]{succeeded}[/bold] ok, [bold]{len(failures)}[/bold] failed")

    if failures:
        table = Table(title="Prebuild failures")
        table.add_column("Challenge", style="cyan")
        table.add_column("Step", style="magenta")
        table.add_column("Detail", style="red", overflow="fold")
        for f in sorted(failures, key=lambda x: x.challenge_id):
            table.add_row(f.challenge_id, f.step, f.detail)
        err_console.print(table)
        raise typer.Exit(1)


# Outer wall-clock buffer added on top of the user's --timeout when
# shelling to smoke_test.py. The inner timeout caps `compose up`; the
# outer process still has to run the exploit and `compose down -v`
# afterwards, which on a cold node can easily eat another minute or two.
_SMOKE_OUTER_TIMEOUT_BUFFER = 180


@dataclass
class _SmokeFailure:
    challenge_id: str
    rc: int
    detail: str


def _smoke_cmd(
    *,
    challenges_dir: Path,
    smoke_script: Path,
    spec_id: str,
    host: str,
    port: int,
    timeout: int,
    keep: bool,
) -> list[str]:
    """Build the ``uv run … smoke_test.py`` argv for one challenge.

    Routed through ``uv run --project <challenges_dir>`` so smoke_test
    picks up the challenges repo's deps (it imports ``yaml``) without
    requiring the caller to pre-activate a venv.
    """
    cmd = [
        "uv",
        "run",
        "--project",
        str(challenges_dir),
        "python",
        str(smoke_script),
        spec_id,
        "--host",
        host,
        "--port",
        str(port),
        "--timeout",
        str(timeout),
        "--root",
        str(challenges_dir),
    ]
    if keep:
        cmd.append("--keep")
    return cmd


def _smoke_one(
    spec: ChallengeSpec,
    challenges_dir: Path,
    *,
    stream: bool,
    host: str,
    port: int,
    timeout: int,
    keep: bool,
) -> _SmokeFailure | None:
    """Run smoke_test.py end-to-end for one challenge.

    Returns a :class:`_SmokeFailure` carrying smoke_test's exit code on
    failure (0=ok, 1=exploit failed, 2=compose up failed, 3=missing
    files) or None on success. When *stream* is True, smoke_test's
    output is forwarded to the terminal so compose progress + exploit
    stdout appear in real time; in parallel mode (*stream* False) we
    capture and surface only the tail in the failure table to keep
    concurrent runs from interleaving.
    """
    smoke_script = challenges_dir / "scripts" / "smoke_test.py"
    if not smoke_script.is_file():
        return _SmokeFailure(spec.id, -1, f"smoke_test.py not found: {smoke_script}")
    compose_file = challenges_dir / spec.id / "docker-compose.yml"
    if not compose_file.exists():
        return _SmokeFailure(spec.id, -1, f"docker-compose.yml not found: {compose_file}")

    cmd = _smoke_cmd(
        challenges_dir=challenges_dir,
        smoke_script=smoke_script,
        spec_id=spec.id,
        host=host,
        port=port,
        timeout=timeout,
        keep=keep,
    )
    log.info("smoke_test.py", challenge=spec.id)
    run_kwargs: dict[str, object] = {
        "timeout": timeout + _SMOKE_OUTER_TIMEOUT_BUFFER,
        "check": False,
    }
    if not stream:
        run_kwargs["capture_output"] = True
        run_kwargs["text"] = True
    try:
        result = subprocess.run(cmd, **run_kwargs)
    except FileNotFoundError:
        return _SmokeFailure(spec.id, -1, "`uv` binary not found on PATH")
    except subprocess.TimeoutExpired:
        return _SmokeFailure(
            spec.id,
            -1,
            f"timed out after {timeout + _SMOKE_OUTER_TIMEOUT_BUFFER}s",
        )
    if result.returncode != 0:
        if stream:
            detail = f"exit {result.returncode} (see output above)"
        else:
            tail = (result.stderr or result.stdout or "").strip()[-1500:]
            detail = tail or f"exit {result.returncode}"
        return _SmokeFailure(spec.id, result.returncode, detail)
    return None


@challenge_app.command("smoke")
def challenge_smoke(
    challenge: str | None = typer.Option(
        None,
        "--challenge",
        help="Filter by challenge ID (comma-separated, prefix-match).",
    ),
    difficulty: Difficulty | None = typer.Option(
        None, "--difficulty", help="Filter by difficulty (easy | medium | hard)."
    ),
    tag: str | None = typer.Option(None, "--tag", help="Filter by a single tag."),
    jobs: int = typer.Option(
        1,
        "--jobs",
        "-j",
        min=1,
        help=(
            "Smoke-test N challenges in parallel. With the default of 1, "
            "compose + exploit output streams live to the terminal; with "
            "N>1, output is captured per challenge and only the tail of "
            "any failure is printed (otherwise concurrent runs would "
            "interleave on the terminal)."
        ),
    ),
    timeout: int = typer.Option(
        300,
        "--timeout",
        help=(
            "Per-challenge `compose up --wait` timeout (s) — passed "
            "through to smoke_test.py. The outer subprocess gets an "
            "additional buffer for the exploit run + `compose down -v`."
        ),
    ),
    host: str = typer.Option("127.0.0.1", "--host", help="Host passed to exploit.py."),
    port: int = typer.Option(80, "--port", help="Port passed to exploit.py."),
    keep: bool = typer.Option(
        False,
        "--keep",
        help="Pass --keep to smoke_test (skip `docker compose down -v` on success).",
    ),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """End-to-end validate challenges: compose up → exploit.py → flag check.

    Loops over every matching challenge and shells to the upstream
    ``challenges_dir/scripts/smoke_test.py`` — which runs
    ``docker compose up -d --wait --build``, executes
    ``solution/exploit.py``, validates the captured flag against
    ``FLAG_RE``, then tears down with ``docker compose down -v``.

    Use this to sanity-check a fresh batch of challenges (e.g. AI-
    generated ones) before exposing them to players. Failures on
    individual challenges are logged and the run continues; the
    command exits non-zero if any challenge failed.
    """
    setup_logging()

    specs = list(
        iter_challenge_specs(challenges_dir, challenge_id=challenge, difficulty=difficulty, tag=tag)
    )
    if not specs:
        err_console.print(f"[yellow]No challenges matched in {challenges_dir}.[/yellow]")
        raise typer.Exit(2)

    console.print(
        f"Smoke-testing [bold]{len(specs)}[/bold] challenge(s) with [bold]{jobs}[/bold] worker(s)…"
    )

    failures: list[_SmokeFailure] = []
    succeeded = 0

    # Stream smoke_test output directly in sequential mode so users see
    # compose + exploit progress in real time. Parallel mode captures —
    # otherwise N concurrent runs interleave into a mess.
    stream = jobs == 1

    def _run(spec: ChallengeSpec) -> tuple[ChallengeSpec, _SmokeFailure | None]:
        return spec, _smoke_one(
            spec,
            challenges_dir,
            stream=stream,
            host=host,
            port=port,
            timeout=timeout,
            keep=keep,
        )

    if jobs == 1:
        for spec in specs:
            console.print(f"  [cyan]→[/cyan] {spec.id}")
            _, failure = _run(spec)
            if failure is None:
                console.print(f"  [green]✓[/green] {spec.id}")
                succeeded += 1
            else:
                console.print(f"  [red]✗[/red] {spec.id} (rc={failure.rc})")
                failures.append(failure)
    else:
        with ThreadPoolExecutor(max_workers=jobs) as pool:
            futures = [pool.submit(_run, spec) for spec in specs]
            for fut in as_completed(futures):
                spec, failure = fut.result()
                if failure is None:
                    console.print(f"  [green]✓[/green] {spec.id}")
                    succeeded += 1
                else:
                    console.print(f"  [red]✗[/red] {spec.id} (rc={failure.rc})")
                    failures.append(failure)

    console.print(f"\n[bold]{succeeded}[/bold] ok, [bold]{len(failures)}[/bold] failed")

    if failures:
        table = Table(title="Smoke failures")
        table.add_column("Challenge", style="cyan")
        table.add_column("RC", style="magenta")
        table.add_column("Detail", style="red", overflow="fold")
        for f in sorted(failures, key=lambda x: x.challenge_id):
            table.add_row(f.challenge_id, str(f.rc), f.detail)
        err_console.print(table)
        raise typer.Exit(1)
