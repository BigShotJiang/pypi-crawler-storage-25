"""`ctfy instance …` — running challenge instances."""

from __future__ import annotations

import typer
from rich.table import Table

from ctfy.cli.runtime import console, err_console, get_client
from ctfy.core.enums import InstanceStatus
from ctfy.core.log import setup_logging
from ctfy.server.models import InstanceInfo

instance_app = typer.Typer(help="Running challenge instances", no_args_is_help=True)


def _print_instance_extras(inst: InstanceInfo) -> None:
    """Render per-instance description + public_vars under an instance row.

    Both fields come from the platform's per-instance projection of
    ``InstanceInfo`` — the description has ``${VAR_X}`` placeholders
    already substituted server-side; ``public_vars`` is the (possibly
    empty) dict of values the challenge author opted to surface to the
    agent. Private vars are intentionally never shown — agents must
    discover those from HTTP behaviour.
    """
    if inst.description:
        console.print(f"  [dim]description:[/dim] {inst.description}")
    if inst.public_vars:
        console.print("  [dim]public vars:[/dim]")
        for vid, value in inst.public_vars.items():
            console.print(f"    [cyan]{vid}[/cyan] = [magenta]{value}[/magenta]")


def _resolve_instance(client, identifier: str) -> InstanceInfo:
    """Return the InstanceInfo for *identifier*.

    Accepts either an instance_id (UUID) or a challenge_id and resolves
    via ``list_instances`` so callers don't have to remember which
    they're dealing with — matches the ergonomics of ``instance stop``.
    """
    instances = client.list_instances()
    for inst in instances:
        if inst.instance_id == identifier or inst.challenge_id == identifier:
            return inst
    raise typer.Exit(code=1)


@instance_app.command("ls")
def instance_ls(
    ctx: typer.Context,
    challenge: str | None = typer.Option(None, "--challenge", help="Filter by challenge ID"),
    status: str | None = typer.Option(None, "--status", help="Filter by status"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """List instances currently running on the platform."""
    setup_logging()
    client = get_client(ctx)
    instances = client.list_instances(challenge_id=challenge or "", status=status or "")

    if json_output:
        console.print_json(data=[i.model_dump() for i in instances])
        return

    table = Table(title="Running Instances")
    table.add_column("Instance ID", style="cyan")
    table.add_column("Challenge")
    table.add_column("Status")
    table.add_column("Vars", style="magenta")
    table.add_column("Started", style="dim")
    table.add_column("TTL", justify="right")

    for inst in instances:
        status_style = "green" if inst.status == InstanceStatus.READY else "yellow"
        # Compact column: show the count of public_vars so the operator
        # spots at a glance which instances were minted with dynamic
        # tokens. Detail goes on `instance show`.
        var_count = len(inst.public_vars or {})
        table.add_row(
            inst.instance_id,
            inst.challenge_id or inst.name,
            f"[{status_style}]{inst.status}[/]",
            str(var_count) if var_count else "",
            str(int(inst.started_at)) if inst.started_at else "",
            str(inst.ttl) if inst.ttl else "",
        )
    console.print(table)
    console.print(f"\n[bold]{len(instances)}[/bold] running")


@instance_app.command("show")
def instance_show(
    ctx: typer.Context,
    identifier: str = typer.Argument(help="Instance ID (or challenge ID) to inspect"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON"),
):
    """Show full per-instance details: description + public_vars + services."""
    setup_logging()
    client = get_client(ctx)
    inst = _resolve_instance(client, identifier)

    if json_output:
        console.print_json(data=inst.model_dump())
        return

    console.print(f"[bold cyan]{inst.instance_id}[/bold cyan]")
    console.print(f"  challenge: [bold]{inst.challenge_id}[/bold] — {inst.name}")
    status_style = "green" if inst.status == InstanceStatus.READY else "yellow"
    console.print(f"  status: [{status_style}]{inst.status}[/]")
    if inst.services:
        console.print("  services:")
        for svc in inst.services:
            suffix = f"  ({svc.label})" if svc.label else ""
            console.print(f"    {svc.service_type.value}://{svc.host}:{svc.port}{suffix}")
    _print_instance_extras(inst)


@instance_app.command("start")
def instance_start(
    ctx: typer.Context,
    challenge_id: str = typer.Argument(help="Challenge ID to start"),
    ttl: int = typer.Option(3600, "--ttl", help="Time-to-live in seconds"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """Start an instance of a challenge and wait until it is ready."""
    setup_logging()
    client = get_client(ctx)
    console.print(f"Starting [bold]{challenge_id}[/bold]...")
    try:
        ready = client.start_instance(challenge_id, ttl=ttl)
    except Exception as e:
        err_console.print(f"[red]Failed: {e}[/red]")
        raise typer.Exit(1)

    if json_output:
        console.print_json(data=ready.surface.model_dump())
        return

    console.print("[green]Ready![/green]")
    for svc in ready.surface.services:
        suffix = f"  ({svc.label})" if svc.label else ""
        console.print(f"  {svc.service_type.value}://{svc.host}:{svc.port}{suffix}")
    # Round-trip via list_instances so the per-instance description
    # (with ${VAR_X} placeholders substituted) and public_vars dict
    # land in the launch output. Best-effort — a network glitch or
    # 404 mustn't fail the start.
    try:
        inst = _resolve_instance(client, challenge_id)
    except Exception:
        return
    _print_instance_extras(inst)


@instance_app.command("stop")
def instance_stop(
    ctx: typer.Context,
    instance_id: str = typer.Argument(help="Instance ID (UUID returned by start_instance) to stop"),
):
    """Stop a running instance."""
    setup_logging()
    client = get_client(ctx)
    try:
        client.stop_instance(instance_id)
    except Exception as e:
        err_console.print(f"[red]Failed: {e}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Stopped {instance_id}[/green]")
