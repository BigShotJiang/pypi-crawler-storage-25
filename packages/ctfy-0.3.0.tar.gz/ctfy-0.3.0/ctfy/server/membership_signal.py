"""Push a ``team_membership_changed`` SSE frame so any open team page
can refetch its member list in lockstep with membership writes.

Used by the team-up routes (register / create / leave / kick / redeem)
to invalidate the ``GET /teams/{id}`` cache without each page having
to subscribe to every individual route's event.

Not an :class:`~ctfy.server.event_payloads.EventPayload`: this is a
pure cache-invalidation signal — no activity-log row (the actual
user-facing actions emit their own activity events when warranted),
no team / actor envelope. The frame goes straight through
:meth:`SSEHub.broadcast` like :mod:`ctfy.server.meta_stats` and
:mod:`ctfy.server.scoreboard_signal`.
"""

from __future__ import annotations

from ctfy.core.enums import PlatformEvent
from ctfy.server.app_state import AppState

__all__ = ["emit_membership_changed"]


def emit_membership_changed(
    app: AppState,
    *,
    user_id: str,
    previous_team_id: str,
    current_team_id: str,
    joined_via: str,
) -> None:
    """Broadcast a membership-changed signal to all listeners.

    The frame carries both team_ids so a subscriber watching
    ``/teams/{id}`` can refetch only when ``id`` matches one of them.
    Broadcast globally (not admin-only) — every viewer of either
    team's profile wants to see the join/leave land in real time.
    """
    app.sse_hub.broadcast(
        PlatformEvent.TEAM_MEMBERSHIP_CHANGED.value,
        team_id="",
        data={
            "user_id": user_id,
            "previous_team_id": previous_team_id,
            "current_team_id": current_team_id,
            "joined_via": joined_via,
        },
    )
