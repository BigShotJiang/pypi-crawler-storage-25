"""Instance server — FastAPI application factory.

All state is stored in a ``StateBackend`` (Redis or in-memory). The flag
is **never** returned to clients; use ``POST /instances/{id}/verify-flag``
to check a candidate flag.
"""

from __future__ import annotations

import asyncio
import hashlib
import importlib
import socket
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi_pagination import add_pagination
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from ctfy.core.challenge import ChallengeManager
from ctfy.core.config import CtfyConfig
from ctfy.core.constants import DEFAULT_MAX_INSTANCES
from ctfy.core.exceptions import (
    CapacityExceededError,
    ChallengeNotFoundError,
    FlagNotFoundError,
    ForbiddenError,
    InstanceAlreadyRunningError,
    InstanceNotFoundError,
    RateLimitError,
    TeamNotFoundError,
)
from ctfy.core.log import log, setup_logging
from ctfy.core.state import StateBackend, create_backend
from ctfy.core.state.models import InstanceState, UserState
from ctfy.server.app_state import AppState
from ctfy.server.auth import (
    check_ownership,
    make_get_current_team_for_competition,
    make_get_current_user,
    make_get_current_user_or_none,
    make_get_current_user_with_token,
    make_require_admin,
    make_require_invite_or_admin,
    make_require_node_or_admin,
    make_require_super_admin,
    make_require_team_captain,
    make_require_user_kind,
    user_team_ids,
)
from ctfy.server.bootstrap import bootstrap_practice_competition
from ctfy.server.background import (
    make_health_check_loop,
    make_reaper_loop,
    make_reconciler_loop,
    make_scoreboard_snapshot_loop,
)
from ctfy.server.error_handlers import register_http_exception_handler, register_platform_error_handlers
from ctfy.server.instance_archive import InstanceArchive
from ctfy.server.oauth.providers import build_oauth_providers
from ctfy.server.routes import (
    achievements,
    activities,
    admin_announcements,
    admin_competitions,
    admin_stats,
    admin_traffic,
    admin_users,
    auth,
    challenges,
    cluster_info,
    competition_teams,
    competitions,
    events,
    health,
    instances,
    invites,
    me,
    meta,
    nodes,
    scoreboard,
    submissions,
    team_profile_stats,
    teams,
    users,
)
from ctfy.server.sse import SSEHub

# Importing the rules package is what wires every @register(...) predicate
# into the achievement engine's dispatch table. Do this at module import
# (not inside create_app) so tests that exercise rules directly — without
# instantiating the full app — still see the registered rules.
importlib.import_module("ctfy.server.achievements.rules")

_ROUTE_MODULES = (
    health,
    meta,
    events,
    instances,
    teams,
    users,
    me,
    admin_users,
    team_profile_stats,
    auth,
    challenges,
    submissions,
    scoreboard,
    nodes,
    invites,
    cluster_info,
    activities,
    admin_stats,
    admin_traffic,
    achievements,
    admin_announcements,
    competitions,
    competition_teams,
    admin_competitions,
)


def _get_external_host() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return socket.gethostname()


def create_platform_app(
    config: CtfyConfig | None = None,
    *,
    external_host: str | None = None,
    max_instances: int = DEFAULT_MAX_INSTANCES,
    backend: StateBackend | None = None,
) -> FastAPI:
    """Build the platform FastAPI app (orchestration + API + web UI).

    The platform delegates container lifecycle to one or more worker
    nodes via ``NodeClient``. A ``ChallengeManager`` is still attached so
    the platform can read ``challenges_dir`` metadata (``iter_specs``); its
    provider methods are only used as a fallback for single-process
    setups that do not register a node.

    *config* defaults to :class:`CtfyConfig` with library defaults — handy
    for tests and uvicorn factory-string use.
    """
    setup_logging()
    if config is None:
        config = CtfyConfig()
    host = external_host or _get_external_host()
    state_backend = backend or create_backend(config.db_path, project_root=config.project_root)
    # Sweep dead runtime-config keys from previous releases.
    state_backend.delete_config("allow_relaunch_solved")
    # Metadata-only reader: ChallengeManager is reused for iter_specs only.
    # The platform never orchestrates containers — that's the node's job.
    spec_reader = ChallengeManager(config)
    sse_hub = SSEHub()
    archive = InstanceArchive(Path(config.instance_archive_dir))
    app_state = AppState(
        config=config,
        state_backend=state_backend,
        spec_reader=spec_reader,
        sse_hub=sse_hub,
        host=host,
        max_instances=max_instances,
        instance_archive=archive,
    )

    # --- Auth dependencies (created once, shared by all route modules) ------
    app_state.get_current_user = make_get_current_user(state_backend)
    app_state.get_current_user_or_none = make_get_current_user_or_none(state_backend)
    app_state.get_current_user_with_token = make_get_current_user_with_token(state_backend)
    app_state.get_current_team_for_competition = (
        make_get_current_team_for_competition(state_backend)
    )
    app_state.require_team_captain = make_require_team_captain(state_backend)
    app_state.require_admin = make_require_admin(state_backend)
    app_state.require_super_admin = make_require_super_admin(state_backend)
    app_state.require_user_kind = make_require_user_kind(state_backend)
    app_state.require_node_or_admin = make_require_node_or_admin(state_backend)
    app_state.require_invite_or_admin = make_require_invite_or_admin(state_backend)

    # --- Resource+ownership dependency: lookup instance by id + guard
    # against the calling user touching another team's instance. The
    # check spans every team the user is currently on (across all
    # competitions), since instances aren't comp-scoped on the wire —
    # one user can have multiple instances on multiple teams.
    async def _require_instance(
        instance_id: str,
        user: UserState | None = Depends(app_state.get_current_user_or_none),
    ) -> InstanceState:
        inst = state_backend.get_instance(instance_id)
        if not inst:
            raise InstanceNotFoundError(instance_id)
        # Owned instances require an authenticated owner. Unowned
        # (anonymous) instances stay reachable without a token —
        # that's the legacy "no-auth" mode for challenges.
        if inst.team_id and user is None:
            from ctfy.core.exceptions import ForbiddenError

            raise ForbiddenError("Not your instance")
        check_ownership(inst, user_team_ids(state_backend, user), "instance")
        if inst.instance_id != instance_id:
            inst = inst.model_copy(update={"instance_id": instance_id})
        return inst

    app_state.require_instance = _require_instance

    # --- Practice-competition bootstrap --------------------------------------
    # Fresh deployment seed: when no competitions exist yet, mint a
    # single permanent "practice" comp containing every known
    # challenge so players can register and run instances out of the
    # box. Idempotent — re-runs on every restart but only writes the
    # row on the first one against an empty competitions table.
    # ``config.auto_bootstrap_practice`` is the structured switch;
    # the env-var fallback covers tests that build ``CtfyConfig()``
    # directly (without ``from_env``) — conftest sets the env var so
    # the legacy "platform comes up with no comps" fixture baseline
    # keeps holding.
    import os as _os  # local import — only needed at bootstrap

    _bootstrap_env = _os.environ.get("CTFY_AUTO_BOOTSTRAP_PRACTICE", "")
    _bootstrap_enabled = config.auto_bootstrap_practice and (
        _bootstrap_env == ""
        or _bootstrap_env.lower() in ("1", "true", "yes", "on")
    )
    if _bootstrap_enabled:
        bootstrap_practice_competition(state_backend, spec_reader)

    # --- OAuth configuration -------------------------------------------------
    # The HMAC secret signs OAuth ``state`` parameters (and any future signed
    # artefacts). Resolution order:
    #
    #   1. ``CTFY_SECRET_KEY`` env var — preferred for production; never
    #      written to the state backend.
    #   2. Existing ``oauth_secret_key`` row in the state backend — kept for
    #      backward compatibility with deployments that started before this
    #      hardening landed (audit #4). Logs a warning recommending the env
    #      var so operators can migrate.
    #   3. Ephemeral fallback — a fresh key is generated **without
    #      persistence**. In-flight OAuth flows are invalidated on restart
    #      (callers just retry login), and a DB leak no longer reveals the
    #      HMAC key. Logs a loud warning so operators don't run this in prod.
    import secrets as _secrets  # local import — only needed at bootstrap

    secret = config.secret_key.get_secret_value()
    secret_source = "env"
    if not secret:
        persisted = state_backend.get_config("oauth_secret_key") or ""
        if persisted:
            secret = persisted
            secret_source = "state_backend"
            log.warning(
                "OAuth signing key loaded from state backend. This row was "
                "auto-persisted by older builds. Set CTFY_SECRET_KEY in your "
                "environment and remove the 'oauth_secret_key' row from the "
                "config table to remove the on-disk copy.",
            )
        else:
            secret = _secrets.token_urlsafe(32)
            secret_source = "ephemeral"
            log.warning(
                "CTFY_SECRET_KEY is not set; generated an EPHEMERAL OAuth "
                "signing key. In-flight OAuth flows will be invalidated on "
                "every restart. Set CTFY_SECRET_KEY for production. "
                "Generate one with: "
                "python -c 'import secrets; print(secrets.token_urlsafe(32))'",
            )
    app_state.oauth_secret = secret
    app_state.oauth_secret_source = secret_source
    app_state.super_admin_emails_lower = {
        e.strip().lower() for e in config.super_admin_emails if e.strip()
    }
    app_state.oauth_providers = build_oauth_providers(config)
    if not app_state.oauth_providers:
        log.warning("No OAuth providers configured; no one can sign in")
    if not app_state.super_admin_emails_lower:
        log.warning(
            "CTFY_SUPER_ADMIN_EMAILS is empty; no super-admin can be "
            "bootstrapped via OAuth. Set it to the verified primary "
            "email(s) of your super-admin account(s)."
        )

    # --- Rate limiter (slowapi, per-app to avoid shared state across tests) --
    # Composite (token, peer-IP) key bounds both axes: a single token cannot
    # round-robin across many IPs to bypass the cap, and a single IP cannot
    # collapse every team behind a CDN/NAT into one bucket. Unauthenticated
    # callers fall back to peer-IP only.
    def _composite_rate_key(request: Request) -> str:
        auth = request.headers.get("authorization", "")
        if auth.lower().startswith("bearer "):
            token = auth.split(" ", 1)[1].strip()
            digest = hashlib.sha256(token.encode("utf-8", "ignore")).hexdigest()[:16]
            return f"tok:{digest}:{get_remote_address(request)}"
        return get_remote_address(request)

    limiter = Limiter(
        key_func=_composite_rate_key,
        enabled=config.rate_limiting_enabled,
        default_limits=([config.rate_limit_default] if config.rate_limiting_enabled else []),
    )
    if not config.rate_limiting_enabled:
        log.warning(
            "Rate limiting is DISABLED (CTFY_RATE_LIMITING_ENABLED=false). "
            "Production deployments should enable it to mitigate flag brute-force, "
            "credential stuffing, and abuse of /verify-flag and /auth endpoints."
        )
    app_state.limiter = limiter

    # Background task factories
    _reaper = make_reaper_loop(app_state)
    _health_chk = make_health_check_loop(app_state)
    _reconciler = make_reconciler_loop(app_state)
    _snapshot = make_scoreboard_snapshot_loop(app_state)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        sse_hub.set_loop(asyncio.get_running_loop())
        reaper = asyncio.create_task(_reaper())
        reconciler = asyncio.create_task(_reconciler())
        health_checker = asyncio.create_task(_health_chk())
        snapshotter = asyncio.create_task(_snapshot())
        yield
        for task in (snapshotter, health_checker, reconciler, reaper):
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        app_state.bg_executor.shutdown(wait=True, cancel_futures=False)

    app = FastAPI(
        title="ctfy",
        description="CTF evaluation platform for AI agents and humans.",
        version="1.0.0",
        lifespan=lifespan,
    )

    # Attach limiter to app.state for slowapi
    app.state.limiter = limiter
    # Expose AppState on app.state so tests (and debug code) can poke at
    # runtime internals — in particular swap in a ``FakeOAuthProvider``
    # without rebuilding the whole app.
    app.state.ctfy = app_state

    # CORS — allow_credentials=False when allow_origins=["*"] (per CORS spec)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Domain exception -> HTTP status mapping — emits ErrorResponse envelopes
    # (``{code, detail, timestamp}``). Pre-refactor responses were bare
    # ``{"detail": ...}``; callers reading that field keep working.
    register_platform_error_handlers(
        app,
        {
            InstanceNotFoundError: 404,
            FlagNotFoundError: 404,
            ChallengeNotFoundError: 404,
            TeamNotFoundError: 404,
            CapacityExceededError: 503,
            RateLimitError: 429,
            ForbiddenError: 403,
            InstanceAlreadyRunningError: 409,
        },
    )
    # Wrap any HTTPException raised by routes into the same envelope so
    # 4xx responses carry ``code`` + ``timestamp`` whether the route used
    # ``raise_error()``, raised a ``PlatformError``, or a plain
    # ``HTTPException``.
    register_http_exception_handler(app)

    # slowapi rate-limit exceeded handler
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

    # Include route modules
    for mod in _ROUTE_MODULES:
        app.include_router(mod.create_router(app_state), prefix="/api/v1")

    # Enable fastapi-pagination
    add_pagination(app)

    # Static files & SPA fallback
    _static = Path(__file__).resolve().parent / "static"
    if _static.exists() and (_static / "index.html").exists():
        _assets = _static / "assets"
        if _assets.exists():
            app.mount("/assets", StaticFiles(directory=str(_assets)), name="assets")

        @app.get("/{path:path}")
        def spa_fallback(path: str):
            f = _static / path
            return FileResponse(f if f.exists() and f.is_file() else _static / "index.html")
    else:
        log.warning(
            "Frontend static files not found. Web UI will not be available. "
            "To build: cd frontend && pnpm install && pnpm run build",
            path=str(_static),
        )

    return app


# Back-compat alias: legacy callers + uvicorn factory strings import
# ``create_app``. Tests, docs, and the docker-compose CMD use this name.
create_app = create_platform_app
