"""Derive a cluster-wide counter snapshot and push it to admin SSE clients.

The admin StatusBar used to poll ``/meta`` (60s) and ``/admin/overview``
(30s) to keep its cluster numbers fresh. Both polls are wasteful: the
write paths that mutate those counters (instance start/stop, team
register, node register/unhealthy/remove, flag correct) already emit
typed SSE events through :func:`ctfy.server.events.emit_event`. This
module piggybacks on those calls — when one of those events fires,
:func:`emit_meta_stats` snapshots the same numbers ``MetaResponse``
exposes and broadcasts them as a ``meta_stats`` SSE frame.

The frame is broadcast ``admin_only=True`` because the carried fields
are admin-only on ``/meta`` (members already get their own running
count via :class:`InstanceCountContext` driven by INSTANCE_EVENTS).

Not an :class:`~ctfy.server.event_payloads.EventPayload`: this is a
pure UI cache invalidator with no team/actor concept and no activity
log row — it bypasses :func:`emit_event` and goes straight to
:meth:`SSEHub.broadcast`.
"""

from __future__ import annotations

import time

from ctfy.core.constants import HEARTBEAT_TIMEOUT
from ctfy.core.enums import PlatformEvent
from ctfy.server.app_state import AppState
from ctfy.server.event_payloads import MetaStatsPayload

__all__ = ["emit_meta_stats", "META_AFFECTING_EVENTS"]


#: Events whose write paths change one or more cluster counters mirrored
#: in ``MetaStatsPayload``. Used by :mod:`ctfy.server.events` to decide
#: when to derive a meta_stats frame after the original broadcast.
#:
#: Excluded on purpose:
#:   - ``INSTANCE_READY`` / ``INSTANCE_RENEWED`` — neither changes the
#:     running-count (the row exists from STARTED through STOPPED).
#:   - ``FLAG_PART_CORRECT`` / ``FLAG_WRONG`` — only full ``FLAG_CORRECT``
#:     produces a Solve row counted by ``solves_total``.
#:   - ``ACHIEVEMENT_UNLOCKED`` — not surfaced on /meta.
#:   - ``NODE_UPDATED`` — display_name / labels only, no health change.
#:   - ``META_STATS`` itself — would recurse otherwise.
META_AFFECTING_EVENTS: frozenset[str] = frozenset({
    PlatformEvent.INSTANCE_STARTED.value,
    PlatformEvent.INSTANCE_STOPPED.value,
    PlatformEvent.INSTANCE_ERROR.value,
    PlatformEvent.TEAM_REGISTERED.value,
    PlatformEvent.NODE_REGISTERED.value,
    PlatformEvent.NODE_UNHEALTHY.value,
    PlatformEvent.NODE_REMOVED.value,
    PlatformEvent.FLAG_CORRECT.value,
})


def emit_meta_stats(app: AppState) -> None:
    """Snapshot the admin counters and broadcast a ``meta_stats`` frame.

    Reads exactly what ``/meta`` would return for an admin caller so
    the StatusBar can apply the payload without re-fetching. The
    snapshot is a single point-in-time read — concurrent writes during
    the snapshot are reconciled by the next emit (this is fine: the
    bar is a soft signal, not a transactional view).
    """
    now = time.time()
    nodes = app.state_backend.list_nodes()
    healthy = sum(
        1
        for n in nodes
        if n.last_heartbeat_ts and (now - n.last_heartbeat_ts) < HEARTBEAT_TIMEOUT
    )
    payload = MetaStatsPayload(
        teams_total=len(app.state_backend.list_teams()),
        nodes_total=len(nodes),
        nodes_healthy=healthy,
        running_instances=app.state_backend.count_instances(),
        solves_total=len(app.state_backend.list_solves()),
        challenges_total=sum(1 for _ in app.spec_reader.iter_specs()),
    )
    app.sse_hub.broadcast(
        PlatformEvent.META_STATS.value,
        team_id="",
        data=payload.model_dump(),
        admin_only=True,
    )
