"""Data models for the CTF platform API surface."""

from __future__ import annotations

from typing import Literal

from fastapi import Query
from fastapi_pagination import LimitOffsetPage
from fastapi_pagination.customization import CustomizedPage, UseParamsFields
from fastapi_pagination.utils import disable_installed_extensions_check
from pydantic import EmailStr, Field

from ctfy.core.activity import ActivityDetail
from ctfy.core.constants import DEFAULT_INSTANCE_TTL, DEFAULT_NODE_CAPACITY
from ctfy.core.enums import InstanceStatus
from ctfy.core.models import CtfyModel
from ctfy.core.target import AttackSurface, ServiceEndpoint

# fastapi-pagination logs a warning when SQLAlchemy etc. aren't installed;
# we don't use those integrations, so silence the notice.
disable_installed_extensions_check()

# Custom pagination page with a higher max limit (default 50, up to 10000).
# Used by endpoints that may legitimately page through large result sets
# (scoreboard, submissions, challenges).
BigLimitOffsetPage = CustomizedPage[
    LimitOffsetPage,
    UseParamsFields(limit=Query(50, ge=1, le=10000)),
]

# ---------------------------------------------------------------------------
# Team
# ---------------------------------------------------------------------------


class TeamInfo(CtfyModel):
    """A team's public-facing summary.

    Post user/team-split a team is a pure container — no email, no
    role, no human profile fields. ``solves`` and ``attempts`` aggregate
    across every member's contribution while they were on this team.
    """

    team_id: str
    name: str
    description: str = ""
    captain_user_id: str = ""
    captain_display_name: str = ""
    captain_avatar_url: str = ""
    member_count: int = 0
    created_at: str
    solves: int = 0
    attempts: int = 0
    last_active_at: str = ""
    # Per-competition scoping (Phase 1+). Empty for legacy teams
    # minted before the per-comp refactor.
    competition_id: str = ""


class TeamMemberInfo(CtfyModel):
    """One member row on the team-detail page."""

    user_id: str
    display_name: str = ""
    avatar_url: str = ""
    is_captain: bool = False
    joined_at: str = ""


class TeamDetail(TeamInfo):
    """``GET /teams/{id}`` payload — adds the resolved members list."""

    members: list[TeamMemberInfo] = Field(default_factory=list)


class UserInfo(CtfyModel):
    """A user's public-facing profile."""

    user_id: str
    display_name: str = ""
    avatar_url: str = ""
    created_at: str = ""
    bio: str | None = None
    country: str | None = None
    website_url: str | None = None
    timezone: str | None = None
    social_links: dict[str, str] = Field(default_factory=dict)
    # Lifetime totals across every team the user has ever been on.
    solves: int = 0
    attempts: int = 0
    last_active_at: str = ""


class CompetitionMembershipInfo(CtfyModel):
    """One row on ``MeResponse.competition_teams``.

    Lets the frontend hydrate a per-comp team picker / "My
    competitions" hub from a single ``/me`` call without N+1
    fetches. Captain status surfaces in the UI for buttons gated
    on ``role == "captain"`` (mint invite / kick / rename).
    """

    competition_id: str
    team_id: str
    team_name: str
    role: Literal["captain", "member"]


class InboxIncomingInvite(CtfyModel):
    """Pending direct invite where the calling user is the named target.

    The frontend renders an Accept / Decline pair pointing at
    ``/competitions/{competition_id}/invites/{invite_id}/accept|decline``.
    """

    invite_id: str
    competition_id: str
    competition_title: str
    team_id: str
    team_name: str
    captain_user_id: str
    captain_display_name: str
    created_at: str


class InboxOutgoingRequest(CtfyModel):
    """Pending join request the calling user opened — surfaces so the
    requester can see "did the captain see this yet?" without
    refreshing the team page.
    """

    invite_id: str
    competition_id: str
    competition_title: str
    team_id: str
    team_name: str
    captain_user_id: str
    captain_display_name: str
    created_at: str


class InboxCaptainRequest(CtfyModel):
    """Pending join request against any team the calling user
    captains. Frontend renders an Approve / Reject pair pointing at
    ``/competitions/{competition_id}/invites/{invite_id}/approve|reject``.
    """

    invite_id: str
    competition_id: str
    competition_title: str
    team_id: str
    team_name: str
    requester_user_id: str
    requester_display_name: str
    created_at: str


class InboxAnnouncement(CtfyModel):
    """Announcement projected onto the Inbox surface.

    Carries the same fields as :class:`AnnouncementInfo` plus a
    per-user ``is_read`` flag derived from the
    ``announcement_reads`` table. The frontend renders unread rows
    prominently and lets the user mark them read via
    ``POST /me/announcements/{id}/read``.
    """

    announcement_id: str
    title: str
    body: str
    severity: Literal["info", "warning", "critical"]
    starts_at: str
    ends_at: str
    created_at: str
    updated_at: str
    created_by: str
    created_by_name: str
    is_read: bool = False


class InboxResponse(CtfyModel):
    """``GET /me/inbox`` payload — pending invites/requests +
    actionable announcements grouped by the action the calling
    user can take.
    """

    incoming_invites: list[InboxIncomingInvite] = Field(default_factory=list)
    outgoing_requests: list[InboxOutgoingRequest] = Field(default_factory=list)
    captain_requests: list[InboxCaptainRequest] = Field(default_factory=list)
    # Site-wide announcements relevant right now (currently live + a
    # short tail of recently-expired) with the user's read state.
    announcements: list[InboxAnnouncement] = Field(default_factory=list)
    # Convenience count so the sidebar can render an unread badge
    # without re-iterating ``announcements``.
    unread_announcement_count: int = 0


class MeResponse(UserInfo):
    """``GET /me`` payload — the logged-in user's full profile.

    Extends :class:`UserInfo` with auth-state context so the frontend
    can render Settings (linked providers, admin badge) with a single
    request. ``providers`` lists provider names currently bound
    (e.g. ``["github", "google"]``); ``token_kind`` distinguishes
    ``"user"`` (browser session) from ``"agent"`` (CLI / agent token).

    ``is_admin`` is the OR of admin + super_admin so existing clients
    keep working without inspecting ``role`` directly.

    ``competition_teams`` carries every per-comp team the user is
    currently on. The legacy ``current_team_id`` /
    ``current_team_name`` fields were dropped — there is no global
    "current team" any more.
    """

    email: str = ""
    is_admin: bool = False
    role: Literal["user", "admin", "super_admin"] = "user"
    providers: list[str] = Field(default_factory=list)
    token_kind: str = "user"
    profile_visibility: dict[str, bool] = Field(default_factory=dict)
    competition_teams: list[CompetitionMembershipInfo] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Admin user management — replaces the old ``/admin/teams`` role-change
# surface. Privilege now lives on the user, so promote/demote operates
# on a user_id.
# ---------------------------------------------------------------------------


class AdminUserInfo(UserInfo):
    """Admin-only view of a user. Carries the privilege tier and the
    most recent role-change audit fields."""

    email: str = ""
    role: Literal["user", "admin", "super_admin"] = "user"
    promoted_by: str | None = None
    promoted_at: str | None = None


class UpdateUserRoleRequest(CtfyModel):
    """Body for ``PATCH /admin/users/{user_id}/role``.

    Only ``"admin"`` and ``"user"`` are accepted — granting
    ``"super_admin"`` is reserved for the env allowlist
    (``CTFY_SUPER_ADMIN_EMAILS``) so the trust anchor stays out-of-band.
    """

    role: Literal["admin", "user"]


# ---------------------------------------------------------------------------
# OAuth endpoints
# ---------------------------------------------------------------------------


class OAuthProviderInfo(CtfyModel):
    name: str  # "github" | "google"
    enabled: bool
    authorize_path: str  # relative, e.g. "/api/v1/auth/login/github"


class PasswordAuthInfo(CtfyModel):
    """Gating flag for the email+password sign-in form on the login page."""

    enabled: bool = False


class ProvidersResponse(CtfyModel):
    providers: list[OAuthProviderInfo] = Field(default_factory=list)
    password_auth: PasswordAuthInfo = Field(default_factory=PasswordAuthInfo)


class LinkedIdentity(CtfyModel):
    identity_id: str
    # "github" | "google" (OAuth) or "password" for a local credential.
    provider: str
    provider_email: str = ""
    provider_display_name: str = ""
    avatar_url: str = ""
    created_at: str = ""


# ---------------------------------------------------------------------------
# Password auth
# ---------------------------------------------------------------------------


class RegisterRequest(CtfyModel):
    email: EmailStr
    # Length minimum mirrors ``MIN_PASSWORD_LENGTH`` in
    # ``ctfy.server.password``. ``validate_password_strength`` runs the
    # full check (length + common-password reject) inside the route
    # handler so the rule lives in one place; this floor is a cheap
    # client-side hint that catches obviously short input before it
    # reaches argon2.
    password: str = Field(min_length=12, max_length=256)
    display_name: str = Field(default="", max_length=120)


class LoginRequest(CtfyModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=256)


class AuthTokenResponse(CtfyModel):
    """Returned by ``POST /auth/register`` and ``POST /auth/login``.

    The plaintext user token is returned directly (not via fragment) since
    these endpoints are called by first-party XHR, not redirects.
    """

    token: str
    redirect_to: str = "/"


class DeleteMeRequest(CtfyModel):
    """Body for ``DELETE /me``. ``confirm_display_name`` must match the
    caller's user display name exactly (case-sensitive) — the typo
    gate that stops a fat-fingered click from cascading the account's
    data away. (Falls back to email when display_name is empty.)
    """

    confirm_display_name: str = Field(min_length=1, max_length=120)


# Sentinel for "field omitted from the PATCH body". Distinct from None,
# which means "explicitly clear this field". Pydantic deserialises a
# missing key as the default, so we use a non-None sentinel to tell
# the two cases apart inside the route.
_UNSET: object = object()


class ProfilePatchRequest(CtfyModel):
    """Body for ``PATCH /me/profile``. Every field is optional so the
    UI can send only the diff; the route only writes the fields that
    were present in the JSON. ``None`` means "clear this field"."""

    # ``Field(default=...)`` with a non-None sentinel is awkward in
    # pydantic; we instead declare each field as Optional + default-None
    # and rely on the request's raw dict (via ``model_fields_set``) to
    # know which keys were actually present.
    bio: str | None = Field(default=None, max_length=280)
    country: str | None = None
    website_url: str | None = Field(default=None, max_length=200)
    timezone: str | None = Field(default=None, max_length=80)
    social_links: dict[str, str] | None = None


# Keys the visibility map is allowed to carry. Anything else is
# silently ignored — see PATCH /me/profile/visibility.
PROFILE_VISIBILITY_KEYS = frozenset(
    {
        "email",
        "country",
        "website_url",
        "social_links",
        "timezone",
        "bio",
        "last_active_at",
        "solves_count",
        "attempts_count",
        "achievements",
        "rank_history",
        # Profile-stats sections (GET /teams/{id}/profile-stats). Each
        # masks an independent visualization: the GitHub-style activity
        # heatmap, the per-tag radar, the difficulty bar chart, and the
        # 30-day solve trend line. False ⇒ section returns [] for non-
        # owner non-admin viewers.
        "activity_calendar",
        "tag_stats",
        "difficulty_stats",
        "solve_trend",
    }
)


class CalendarBucket(CtfyModel):
    """One UTC-day cell on the contribution calendar.

    ``count`` aggregates correct submissions + first-time solves on that
    day; effectively "did anything productive happen". The series is
    dense — every day in the requested window is present, zero-filled."""

    date: str = ""  # YYYY-MM-DD, UTC
    count: int = 0


class TagStat(CtfyModel):
    """One axis on the per-tag strength radar.

    ``solved`` is the team's solve count for challenges carrying this
    tag; ``total`` is the platform-wide challenge count for the tag,
    so the frontend can render "team / total" or normalize to a 0–1
    ratio for the radar polygon."""

    tag: str = ""
    solved: int = 0
    total: int = 0


class DifficultyStat(CtfyModel):
    difficulty: str = ""  # easy | medium | hard | ...
    solved: int = 0
    total: int = 0


class TrendPoint(CtfyModel):
    """One UTC-day bucket on the solve-trend line."""

    date: str = ""  # YYYY-MM-DD, UTC
    solves: int = 0


class ProfileStats(CtfyModel):
    """Aggregate per-team analytics surfaced on the public profile.

    Every section is independently visibility-gated; non-owner viewers
    see ``[]`` for a section the team has marked private. Owner and
    admin always see the full payload."""

    calendar: list[CalendarBucket] = Field(default_factory=list)
    by_tag: list[TagStat] = Field(default_factory=list)
    by_difficulty: list[DifficultyStat] = Field(default_factory=list)
    solve_trend: list[TrendPoint] = Field(default_factory=list)


class UserSolveTrend(CtfyModel):
    """The calling user's daily solve count for the last ``days`` UTC days,
    aggregated across every team they have ever been on (matched by
    ``user_id`` on each :class:`SolveState`).

    Powers the Dashboard's "personal solve trend" chart, which is
    user-scoped — independent of which competition the user is currently
    registered for. Multi-flag challenges count once per flag day, the
    same way :class:`ProfileStats.solve_trend` does it.
    """

    solve_trend: list[TrendPoint] = Field(default_factory=list)




class SetPasswordRequest(CtfyModel):
    # Required iff the caller already has a password identity — absent on
    # the first-time "attach password to an OAuth account" flow.
    current_password: str = Field(default="", max_length=256)
    # See RegisterRequest.password for the length-minimum rationale.
    new_password: str = Field(min_length=12, max_length=256)


class TokenInfo(CtfyModel):
    token_id: str
    kind: str  # "user" | "agent"
    label: str = ""
    created_at: str = ""
    last_used_at: str = ""
    # ISO-8601 UTC timestamp; empty means the token never expires.
    expires_at: str = ""
    # Client metadata captured when the session was minted. Only populated
    # for user-kind tokens (browser sessions).
    ip_address: str = ""
    user_agent: str = ""
    # True for the session that made this request — lets the UI show "this
    # session" and disable the Revoke button so a user can't accidentally
    # log themselves out.
    is_current: bool = False


class CreateAgentTokenRequest(CtfyModel):
    label: str = Field(default="", max_length=64)
    # Lifetime in days. ``None`` uses the server default (30); ``0`` means
    # "never expires". The server caps this at ~5 years to reject absurd
    # values.
    expires_in_days: int | None = Field(default=None, ge=0, le=365 * 5)


class CreateAgentTokenResponse(TokenInfo):
    """Includes the plaintext ``token`` — returned once, never persisted."""

    token: str


class LinkStartResponse(CtfyModel):
    """Returned by ``POST /auth/identities/link/{provider}``.

    The caller is already authenticated via XHR, so we don't 302 them;
    instead we hand back the authorize URL for the frontend to navigate
    the browser to.
    """

    authorize_url: str


# ---------------------------------------------------------------------------
# Challenge
# ---------------------------------------------------------------------------


class ChallengeInfo(CtfyModel):
    id: str
    name: str
    category: str = "web"
    difficulty: str = ""
    description: str = ""
    # Full-challenge solves: teams that captured every declared flag.
    solves_count: int = 0
    tags: list[str] = Field(default_factory=list)
    # Declared flag ids. Single-flag challenges expose ``["main"]``;
    # multi-flag challenges list each id in declaration order.
    flag_ids: list[str] = Field(default_factory=lambda: ["main"])
    # Per-flag solve counts (how many teams captured each flag). Keyed by
    # flag id. Useful for the challenge detail page's progress breakdown.
    flag_solves: dict[str, int] = Field(default_factory=dict)
    # Declared dynamic-token ids (not values). Empty for the typical
    # case; non-empty when the challenge author opted into the
    # per-instance random-token mechanism. Mirrors how ``flag_ids``
    # exposes labels without exposing the minted values — agents
    # learning that a challenge declares ``var_ids: [admin_path]``
    # know there is a dynamic path they must discover, but the actual
    # path value still requires HTTP-behaviour reconnaissance.
    var_ids: list[str] = Field(default_factory=list)
    public_var_ids: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Submission
# ---------------------------------------------------------------------------


class SubmissionCreate(CtfyModel):
    # ``instance_id`` is the canonical handle since 0.2: the server
    # reads challenge_id and competition_id off the instance row, so
    # callers don't need to repeat them and N instances per
    # (team, challenge) are unambiguous on submit.
    instance_id: str
    flag: str


class SubmissionResponse(CtfyModel):
    submission_id: str
    correct: bool
    solve_time_s: float = 0  # seconds from instance start to correct submission
    # 1 = first blood, 2 = second, 3 = third, 4+ = regular solve.
    # 0 when incorrect or when the team already had a prior correct solve.
    # On multi-flag challenges this ranks solves of the specific flag that
    # was just captured (not the full-challenge rank).
    solve_rank: int = 0
    # Which flag id this submission matched, if any. ``None`` on a wrong
    # claim. On single-flag challenges this is ``"main"`` on success.
    flag_id: str | None = None
    # True iff this team has now captured every flag declared on the
    # challenge. Single-flag challenges: always equals ``correct``.
    challenge_fully_solved: bool = False


class MySolveSummary(CtfyModel):
    """Per-challenge solve summary for the calling team.

    Returned by ``GET /me/solves``. One row per challenge with at least
    one captured flag. ``best_rank`` is the team's best (smallest) rank
    across the flags they captured for the challenge — drives the
    1血/2血/3血 badge on the challenge cards. Multi-flag challenges may
    have different ranks per flag; reporting the best one gives players
    credit for whichever piece they nailed first.
    """

    challenge_id: str
    best_rank: int
    solved_at: str


# ---------------------------------------------------------------------------
# Scoreboard
# ---------------------------------------------------------------------------


class ScoreboardEntry(CtfyModel):
    rank: int = 0
    team_id: str
    team_name: str
    # Challenges where the team captured every declared flag. Preserved
    # for parity with the legacy single-flag scoreboard.
    solved: int = 0
    # Total individual flags captured across all challenges. Primary
    # scoreboard metric now that multi-flag challenges exist — rewards
    # partial progress (e.g. foothold without root).
    flags_solved: int = 0
    attempts: int = 0
    last_solve_at: str = ""
    # Most recent activity of any kind. Distinct from ``last_solve_at`` —
    # a team may be actively attempting without a solve, and the UI
    # wants to show that they're not idle.
    last_active_at: str = ""
    # OAuth provider avatar URL for the team's earliest identity that
    # supplies one. Empty for password-only teams; the frontend falls
    # back to a generated initials avatar in that case.
    avatar_url: str = ""


class UserScoreboardEntry(CtfyModel):
    """One row on the user-ranked global scoreboard.

    Aggregates a single user's solves across every team they've
    ever been on (each ``SolveState`` carries both ``user_id`` and
    ``team_id``, so per-user totals are a straight filter over the
    global solve table). Excludes users with zero solves to keep
    the public list compact.
    """

    rank: int = 0
    user_id: str
    display_name: str
    avatar_url: str = ""
    country: str = ""
    # Total flags solved across all teams the user has ever been on.
    flags_solved: int = 0
    # Challenges fully solved (every declared flag captured).
    solved: int = 0
    last_solve_at: str = ""


class ChallengeFlagStats(CtfyModel):
    """Per-flag aggregate for one challenge (for the detail page)."""

    flag_id: str
    solves_count: int = 0


class ChallengeStats(CtfyModel):
    challenge_id: str
    name: str = ""
    category: str = ""
    difficulty: str = ""
    # Teams that captured every declared flag on this challenge.
    solves_count: int = 0
    total_attempts: int = 0
    success_rate: float = 0.0
    # Per-flag breakdown. Single-flag challenges have a single entry with
    # ``flag_id == "main"`` and ``solves_count == solves_count`` above.
    flag_stats: list[ChallengeFlagStats] = Field(default_factory=list)


class ChallengeSolveAttempt(CtfyModel):
    """One archived instance for a challenge — used to visualise per-team
    multi-solve attempts on the challenge detail page."""

    instance_id: str
    team_id: str = ""
    team_name: str = ""
    display_name: str = ""
    challenge_id: str = ""
    started_at: float = 0.0
    stopped_at: float = 0.0
    duration_s: float = 0.0
    attempts: int = 0
    solved: bool = False
    solved_flags: list[str] = Field(default_factory=list)
    stop_reason: str = ""


class ChallengeTeamSolveSummary(CtfyModel):
    """Per-team aggregate for the challenge detail solve-attempts panel."""

    team_id: str
    team_name: str = ""
    display_name: str = ""
    solve_count: int = 0
    attempt_count: int = 0
    best_duration_s: float = 0.0
    total_duration_s: float = 0.0
    first_solved_at: float = 0.0
    last_solved_at: float = 0.0


class ChallengeSolveAttemptsResponse(CtfyModel):
    challenge_id: str
    attempts: list[ChallengeSolveAttempt] = Field(default_factory=list)
    per_team: list[ChallengeTeamSolveSummary] = Field(default_factory=list)
    # Total archived instances (incl. unsolved) — lets the UI show
    # "showing N solved of M total" when the response is filtered.
    total_attempts: int = 0


# ---------------------------------------------------------------------------
# Admin dashboard aggregates
# ---------------------------------------------------------------------------


class AdminSolveCell(CtfyModel):
    """One cell in the team × challenge solve matrix.

    Unsolved cells are emitted when the team has at least one submission
    against the challenge (``attempts > 0``) so the UI can distinguish
    "tried and failed" from "never attempted".
    """

    team_id: str
    challenge_id: str
    solved: bool = False
    solved_at: str = ""
    solve_time_s: float = 0.0
    attempts: int = 0
    # True when this team is the first (fastest) solver of the challenge.
    first_blood: bool = False


class AdminSolveMatrixTeam(CtfyModel):
    team_id: str
    name: str = ""
    solved: int = 0


class AdminSolveMatrixChallenge(CtfyModel):
    challenge_id: str
    name: str = ""
    category: str = ""
    difficulty: str = ""
    solves_count: int = 0


class AdminSolveMatrix(CtfyModel):
    """Team × challenge solve matrix for the admin dashboard.

    Rows (teams) and columns (challenges) pre-sorted — teams by solve count
    desc, challenges by category → difficulty — so the frontend can render
    the grid verbatim without re-sorting. Cells are sparse: only teams that
    have at least attempted a challenge contribute a row there.
    """

    teams: list[AdminSolveMatrixTeam] = Field(default_factory=list)
    challenges: list[AdminSolveMatrixChallenge] = Field(default_factory=list)
    cells: list[AdminSolveCell] = Field(default_factory=list)


class AdminOverviewCounts(CtfyModel):
    total: int = 0
    healthy: int = 0


class AdminChallengeLastError(CtfyModel):
    """Most-recent error against a challenge, surfaced on the per-challenge
    admin row so an admin can spot a broken challenge without opening
    instance history."""

    ts: float = 0.0  # stopped_at of the failing instance
    message: str = ""
    instance_id: str = ""


class AdminChallengeStatsRow(CtfyModel):
    """One row of the per-challenge admin dashboard.

    Aggregates over ``InstanceRecord`` (lifetime) plus live ``InstanceState``
    (running). Launch-duration percentiles are computed only over rows with
    both ``requested_at`` and ``ready_at`` populated — error rows that never
    reached READY contribute to ``errors`` / ``error_rate`` but not to p50/p95.
    """

    challenge_id: str
    name: str = ""
    difficulty: str = ""
    launches: int = 0
    errors: int = 0
    error_rate: float = 0.0
    avg_launch_s: float = 0.0
    p50_launch_s: float = 0.0
    p95_launch_s: float = 0.0
    solve_rate: float = 0.0
    running_count: int = 0
    last_error: AdminChallengeLastError | None = None
    # Newest-first launch durations, capped at 20, used for the inline
    # sparkline. Recorded only for successful launches.
    recent_launch_durations: list[float] = Field(default_factory=list)


class AdminStuckInstance(CtfyModel):
    """A live instance stuck in STARTING for too long — likely a node-side
    failure that didn't reconcile to ERROR cleanly."""

    instance_id: str
    challenge_id: str = ""
    team_id: str = ""
    node_id: str = ""
    requested_at: float = 0.0
    stuck_for_s: float = 0.0


class AdminRecentError(CtfyModel):
    """An archived instance that ended in ``stop_reason="error"``."""

    instance_id: str
    challenge_id: str = ""
    team_id: str = ""
    node_id: str = ""
    error: str = ""
    stopped_at: float = 0.0


class AdminUnhealthyNode(CtfyModel):
    node_id: str
    display_name: str = ""
    url: str = ""
    last_heartbeat_ts: float = 0.0
    downtime_s: float = 0.0


class AdminSilentChallenge(CtfyModel):
    """A challenge that has launches and submissions but no full solves —
    a strong signal that the challenge or its flag is broken."""

    challenge_id: str
    name: str = ""
    launches: int = 0
    submissions: int = 0


class AdminHealthFlags(CtfyModel):
    """Aggregated red-flag panels for the admin Overview "needs attention"
    section. All four lists are independently populated and may be empty."""

    stuck_starting: list[AdminStuckInstance] = Field(default_factory=list)
    recent_errors: list[AdminRecentError] = Field(default_factory=list)
    unhealthy_nodes: list[AdminUnhealthyNode] = Field(default_factory=list)
    silent_challenges: list[AdminSilentChallenge] = Field(default_factory=list)


class AdminTimeseriesBucket(CtfyModel):
    """One bucket of an admin time-series chart.

    ``ts`` is the right edge of the bucket in Unix seconds — the natural
    point to evaluate "active right now" metrics like running_instances —
    and the natural label to render at the right of the bucket on the
    frontend.

    ``partial=True`` marks the rightmost bucket whose right edge is
    ``now``; it represents an in-progress window that hasn't finished
    accumulating yet. The frontend renders these with a "live" indicator
    (semi-transparent fill, pulsing label) to signal the value will
    grow until the bucket's right edge passes.
    """

    ts: float = 0.0
    value: int = 0
    partial: bool = False


class AdminTimeseries(CtfyModel):
    """24h-by-default bucketed counts driving the admin Overview pulse charts."""

    metric: str = ""
    window_s: int = 0
    bucket_s: int = 0
    buckets: list[AdminTimeseriesBucket] = Field(default_factory=list)


class AdminChallengeTimeseriesBucket(CtfyModel):
    """One bucket of the per-challenge health time-series.

    Carries enough fields for the admin UI to render error-rate **and**
    launch-duration trends from a single response — no need for the
    frontend to issue three calls or do its own bucketing.

    See :class:`AdminTimeseriesBucket` for the ``partial`` semantics.
    """

    ts: float = 0.0  # right edge, Unix seconds
    launches: int = 0
    errors: int = 0
    error_rate: float = 0.0  # errors / launches; 0 when no launches
    p50_launch_s: float = 0.0
    p95_launch_s: float = 0.0
    partial: bool = False


class AdminChallengeTimeseries(CtfyModel):
    """Per-challenge bucketed health metrics for the admin drilldown.

    Backs the row-level drawer on /admin/challenges that surfaces "did
    this challenge's error rate spike at some specific time" without
    forcing the operator to scrub through raw activity.
    """

    challenge_id: str = ""
    window_s: int = 0
    bucket_s: int = 0
    buckets: list[AdminChallengeTimeseriesBucket] = Field(default_factory=list)


class ActivityTimeseriesBucket(CtfyModel):
    """One bucket of the team's activity histogram.

    ``counts`` is keyed by event type (``flag_correct``, ``instance_started``,
    …) so the frontend can stack each event as its own bar segment without
    a follow-up shape-change to add new event types.

    See :class:`AdminTimeseriesBucket` for the ``partial`` semantics.
    """

    ts: float = 0.0  # right edge, Unix seconds
    counts: dict[str, int] = Field(default_factory=dict)
    partial: bool = False


class ActivityTimeseries(CtfyModel):
    """Bucketed activity counts for the per-team activity histogram.

    Same ``ts`` semantics as ``AdminTimeseries`` — oldest-first, right
    edge anchored to "now". ``events`` is the sorted union of event
    types that appear in any bucket, so the frontend has a stable list
    of stack segments to render even when individual buckets are empty.
    """

    window_s: int = 0
    bucket_s: int = 0
    events: list[str] = Field(default_factory=list)
    buckets: list[ActivityTimeseriesBucket] = Field(default_factory=list)


class AdminOverview(CtfyModel):
    """Single aggregate payload for the admin landing page."""

    nodes: AdminOverviewCounts = Field(default_factory=AdminOverviewCounts)
    capacity: int = 0
    running_instances: int = 0
    teams_total: int = 0
    solves_total: int = 0
    solves_today: int = 0


# ---------------------------------------------------------------------------
# Activity Log
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Nodes (multi-node cluster)
# ---------------------------------------------------------------------------


class NodeRegister(CtfyModel):
    url: str  # e.g. "http://node1:8100"
    display_name: str  # required; operators pick a human-readable label
    capacity: int = DEFAULT_NODE_CAPACITY
    labels: dict[str, str] = Field(default_factory=dict)  # optional metadata


class NodeInfo(CtfyModel):
    node_id: str
    url: str
    display_name: str = ""
    capacity: int = 0
    running: int = 0
    healthy: bool = True
    last_heartbeat: str = ""
    # ISO-8601 UTC timestamp of the first successful registration.
    # Empty only for rows that pre-date the field; read-path code in
    # ``ctfy/server/routes/nodes.py`` falls back to ``last_heartbeat``
    # so the admin UI never shows "—" for established nodes.
    registered_at: str = ""
    labels: dict[str, str] = Field(default_factory=dict)
    # Latest resource sample reported on heartbeat (0–100).
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_percent: float = 0.0


class NodePatch(CtfyModel):
    """Body for ``PATCH /admin/nodes/{node_id}``.

    Fields are optional — absent fields keep their current value.
    display_name is the common case; labels allow adding/replacing the
    full dict (partial label edits need a second round-trip).
    """

    display_name: str | None = None
    labels: dict[str, str] | None = None


class NodeHeartbeat(CtfyModel):
    """Body for ``POST /nodes/heartbeat``.

    Node reports its live counts + resource utilisation on every beat.
    All metrics are 0–100; 0 is a safe default for the first beat where
    psutil hasn't had a prior sample to diff against.
    """

    node_id: str
    running: int = 0
    capacity: int = 50
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_percent: float = 0.0
    # Unix seconds when the node sampled the metrics. The server stores
    # ``received_at - sampled_at`` as one-way latency on the resulting
    # health sample. Default 0 means "not measured" — older node builds
    # that haven't been upgraded keep working.
    sampled_at: float = 0.0


class NodeRegisterResponse(NodeInfo):
    """Registration response carries the node's bearer token (plaintext).

    Returned exactly once, at registration. The same token is used in
    both directions:

    * **node→platform** (heartbeat, deregister) — node presents it as
      the Bearer; platform looks the row up by comparing plaintexts.
    * **platform→node** (start/stop/status) — platform presents the
      same plaintext on every call; node verifies against its in-memory
      copy.

    Re-registration rotates the token. The node never persists it on
    disk; "restart = re-register = fresh credential".
    """

    node_token: str = ""


class CreateInviteRequest(CtfyModel):
    """Body for ``POST /api/v1/nodes/invites``.

    ``ttl_seconds`` controls how long the minted registration token stays
    valid — it cannot be renewed, only re-created.
    """

    ttl_seconds: int = Field(default=3600, ge=60, le=7 * 24 * 3600)


class CreateInviteResponse(CtfyModel):
    """Plaintext registration token is returned **exactly once** here.

    Subsequent ``GET /nodes/invites`` lookups only expose metadata; the
    plaintext is never persisted — only ``token_hash`` is stored.
    """

    invite_id: str
    registration_token: str
    expires_at: str


class NodeInviteInfo(CtfyModel):
    """Admin-facing summary (``GET /nodes/invites``). No token fields."""

    invite_id: str
    created_at: str
    expires_at: str
    status: str  # "active" | "consumed" | "expired"
    consumed_by_node_id: str = ""


class ClusterInfo(CtfyModel):
    """Returned by ``GET /cluster-info``.

    Provides the bits the ``ctfy server invite`` CLI and admin UI wizard
    need to build a runnable join command. The *registration token* is
    minted separately via ``POST /nodes/invites`` — it isn't on this
    payload because cluster info is queried speculatively by the UI on
    every admin dashboard load, and we never want to hand an invite
    token to a page that didn't explicitly ask for one.
    """

    platform_url: str
    node_image: str


# ---------------------------------------------------------------------------
# Activity Log
# ---------------------------------------------------------------------------


class Activity(CtfyModel):
    """A single activity event in the platform log."""

    id: str = ""
    timestamp: str = ""
    event: str  # See PlatformEvent enum for valid values
    team_id: str = ""
    team_name: str = ""
    challenge_id: str = ""
    # Who triggered this event — surfaced on the public feed so admins
    # can filter by actor and auditors can trace back. Values mirror
    # the ActivityState fields in core.state.models.
    actor_id: str = ""
    actor_name: str = ""
    actor_type: str = ""
    detail: ActivityDetail = Field(default_factory=ActivityDetail)


# ---------------------------------------------------------------------------
# Instance
# ---------------------------------------------------------------------------


class InstanceInfo(CtfyModel):
    instance_id: str
    challenge_id: str = ""
    team_id: str = ""
    # Competition the instance is scoped to. Stamped from the resolved
    # per-comp team at start time; empty for legacy rows or unscoped
    # admin instances. Frontend keys per-comp instance pages off this
    # field so a user registered for two comps doesn't see comp A's
    # instances in comp B's tab.
    competition_id: str = ""
    # Worker node currently hosting this instance. Empty only for
    # records created before nodes were tracked (legacy).
    node_id: str = ""
    name: str = ""
    category: str = ""
    difficulty: str = ""
    status: str = InstanceStatus.STARTING
    started_at: float = 0.0
    ttl: int = 0
    expires_at: float = 0.0
    services: list[ServiceEndpoint] = Field(default_factory=list)
    # Per-instance description with ${VAR_X} placeholders substituted
    # against the public_vars for this instance. Empty when the source
    # spec is no longer resolvable (e.g. challenges_dir lookup fails on
    # a stale instance row); callers should fall back to the static
    # description from /challenges in that case.
    description: str = ""
    # Public per-instance random tokens (subset of ``InstanceState.vars``
    # restricted to ids declared in ``spec.public_vars``). Private
    # ``vars`` are NEVER exposed here — the agent must discover them
    # from HTTP behaviour. Keyed by lowercase var id.
    public_vars: dict[str, str] = Field(default_factory=dict)


class InstanceRecordInfo(CtfyModel):
    """Archived-instance summary for the admin history list.

    Mirrors :class:`ctfy.core.state.models.InstanceRecord` minus the heavy
    fields (``spec``, ``surface``). Used by ``GET /admin/instance-records``.
    """

    instance_id: str
    team_id: str = ""
    challenge_id: str = ""
    node_id: str = ""
    name: str = ""
    category: str = ""
    difficulty: str = ""
    status: str = ""
    stop_reason: str = ""
    error: str = ""
    started_at: float = 0.0
    stopped_at: float = 0.0
    duration_s: float = 0.0
    ttl: int = 0
    solved: bool = False
    attempts: int = 0
    # Total HTTP requests captured by the mitmproxy sidecar during the
    # instance's lifetime. 0 when the archive sink was disabled or no
    # traffic was captured.
    request_count: int = 0


class InstanceRecordInfoDetail(InstanceRecordInfo):
    """Full record — includes spec + surface, returned by detail endpoint."""

    spec: dict = Field(default_factory=dict)
    surface: AttackSurface | None = None
    artifact_dir: str = ""


class InstanceRecordArtifacts(CtfyModel):
    """Per-artifact presence flags + counts for an archived instance.

    Returned alongside the full :class:`InstanceRecord` from
    ``GET /admin/instance-records/{id}`` so the admin UI can show
    ``Manifest / Events / Submissions / Container log`` tabs at a glance
    without a round-trip per tab.
    """

    has_manifest: bool = False
    has_container_log: bool = False
    events_count: int = 0
    submissions_count: int = 0
    traffic_count: int = 0
    # Bytes on disk for the archived ``traffic.pcap``. 0 when no capture
    # was persisted (sidecar disabled, archive disabled, or fetch
    # failed). The admin UI uses this both to gate the download button
    # and to render an "X MB" hint next to it.
    pcap_bytes: int = 0


class InstanceRecordDetail(CtfyModel):
    record: InstanceRecordInfoDetail
    artifacts: InstanceRecordArtifacts = Field(default_factory=InstanceRecordArtifacts)


class AdminTrafficTeamRow(CtfyModel):
    """Per-team aggregate row for the admin traffic dashboard.

    Sums HTTP request counts across every archived instance the team has
    ever launched, plus the live count for any instances the team is
    still running.
    """

    team_id: str
    team_name: str = ""
    instance_count: int = 0
    request_count: int = 0
    last_activity_at: float = 0.0


class AdminTrafficInstanceRow(CtfyModel):
    """One instance × team × challenge row for the admin traffic dashboard."""

    instance_id: str
    team_id: str
    team_name: str = ""
    challenge_id: str = ""
    name: str = ""
    status: str = ""
    request_count: int = 0
    started_at: float = 0.0
    stopped_at: float = 0.0
    # ``True`` if the instance is still running (request_count is approximate
    # — refreshed only when the dashboard re-fetches).
    live: bool = False


class AdminTrafficSummary(CtfyModel):
    """Top-level response for ``GET /admin/traffic/summary``."""

    teams: list[AdminTrafficTeamRow] = Field(default_factory=list)
    instances: list[AdminTrafficInstanceRow] = Field(default_factory=list)
    total_requests: int = 0


class InstanceStatusResponse(CtfyModel):
    instance_id: str
    status: str = InstanceStatus.STARTING
    attack_surface: AttackSurface | None = None
    error: str | None = None
    # CA volume for the per-instance mitmproxy. Operators trust this CA
    # if they want to MITM HTTPS; HTTP traffic is captured transparently
    # without it.
    cert_volume: str = ""


class StartResponse(CtfyModel):
    instance_id: str
    status: str = InstanceStatus.STARTING


class StopResponse(CtfyModel):
    status: str = InstanceStatus.STOPPED
    instance_id: str


class RenewResponse(CtfyModel):
    status: str = "renewed"
    instance_id: str
    expires_at: float


class VerifyFlagRequest(CtfyModel):
    claimed_flag: str


class VerifyFlagResponse(CtfyModel):
    correct: bool
    # Which flag on the challenge the claim matched. ``None`` on a wrong
    # claim or legacy single-flag deployments where the client doesn't
    # care which id hit. Populated only on correct claims.
    flag_id: str | None = None


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


class HealthResponse(CtfyModel):
    status: str = "ok"
    hostname: str = ""
    running_instances: int = 0
    capacity: int = 0


# ---------------------------------------------------------------------------
# Meta — server-wide snapshot consumed by the bottom status bar. Public,
# so the numbers must stay within what the individual public endpoints
# (``/challenges``, ``/teams``, ``/nodes``, ``/scoreboard``) already expose.
# ---------------------------------------------------------------------------


class MetaPlatform(CtfyModel):
    """Source-control identity of the running ctfy build.

    ``commit_sha`` is None when the build couldn't determine its own
    revision (no ``CTFY_GIT_COMMIT``, no usable git binary).
    ``commit_url`` is built from ``repo_url`` + sha so the frontend
    doesn't have to know the URL convention.
    """

    commit_sha: str | None = None
    commit_url: str | None = None
    repo_url: str = ""


class MetaChallenges(CtfyModel):
    """Source-control identity of the challenges repository, plus the
    public count of available challenges.

    ``commit_sha`` is None when the challenges directory isn't a git
    working tree (e.g. ``CTFY_CHALLENGES_REPO=""`` or a bare checkout).
    ``total`` is visible to everyone — the list itself is browsable.
    """

    commit_sha: str | None = None
    commit_url: str | None = None
    repo_url: str = ""
    total: int = 0


class MetaResponse(CtfyModel):
    version: str = ""
    platform: MetaPlatform = Field(default_factory=MetaPlatform)
    challenges: MetaChallenges = Field(default_factory=MetaChallenges)
    started_at_ts: float = 0.0
    server_time_ts: float = 0.0
    # Cluster-wide counters — admin-only. ``None`` for non-admin
    # callers so the frontend can distinguish "not authorised" from
    # "happens to be zero" and hide the segment entirely instead of
    # rendering a misleading "0 nodes".
    teams_total: int | None = None
    nodes_total: int | None = None
    nodes_healthy: int | None = None
    running_instances: int | None = None
    solves_total: int | None = None


# ---------------------------------------------------------------------------
# Error envelope
# ---------------------------------------------------------------------------


class ErrorResponse(CtfyModel):
    """Unified shape for every HTTP 4xx/5xx body produced by platform routes.

    ``detail`` mirrors the pre-existing field (so SDK / CLI / frontend code
    that reads ``data.detail`` keeps working); ``code`` adds a stable
    machine-readable identifier derived from the raising exception class,
    and ``timestamp`` is server-side UTC in ISO 8601 — useful when
    correlating client-side and server-side logs.
    """

    code: str
    detail: str
    timestamp: str


# ---------------------------------------------------------------------------
# Start Request
# ---------------------------------------------------------------------------


class StartRequest(CtfyModel):
    challenge_id: str
    proxy_output_dir: str | None = None
    ttl: int = DEFAULT_INSTANCE_TTL
    # Which competition this instance is for. The platform looks up
    # the caller's per-comp team via ``(user_id, competition_id)`` and
    # stamps the instance with that team. Optional only when the
    # caller is on exactly one team — multi-comp users always pass
    # it explicitly.
    competition_id: str = ""


# ---------------------------------------------------------------------------
# Announcements
# ---------------------------------------------------------------------------


class AnnouncementCreate(CtfyModel):
    """Request body for ``POST /admin/announcements``.

    Time fields accept ISO 8601 strings; empty means "no bound" (live
    immediately / never expires). Severity defaults to ``info`` so a
    minimal "title + body" payload still validates.
    """

    title: str = Field(min_length=1, max_length=200)
    body: str = Field(default="", max_length=20000)
    severity: str = "info"
    starts_at: str = ""
    ends_at: str = ""


class AnnouncementUpdate(CtfyModel):
    """PATCH body — every field optional, ``None`` means "leave alone"."""

    title: str | None = Field(default=None, min_length=1, max_length=200)
    body: str | None = Field(default=None, max_length=20000)
    severity: str | None = None
    starts_at: str | None = None
    ends_at: str | None = None


class AnnouncementInfo(CtfyModel):
    """Response shape — mirrors ``AnnouncementState`` field-for-field."""

    announcement_id: str
    title: str
    body: str
    severity: str
    starts_at: str
    ends_at: str
    created_at: str
    updated_at: str
    created_by: str
    created_by_name: str


# ---------------------------------------------------------------------------
# Competitions
# ---------------------------------------------------------------------------


class CompetitionCreate(CtfyModel):
    """Request body for ``POST /admin/competitions``.

    Time fields accept ISO 8601 strings; empty means "no bound" (live
    immediately / never expires). ``challenge_ids`` is validated against
    the spec registry inside the route handler — unknown ids return 422.
    """

    title: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=20000)
    starts_at: str = ""
    ends_at: str = ""
    challenge_ids: list[str] = Field(default_factory=list, max_length=200)


class CompetitionUpdate(CtfyModel):
    """PATCH body — every field optional, ``None`` means "leave alone"."""

    title: str | None = Field(default=None, min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=20000)
    starts_at: str | None = None
    ends_at: str | None = None
    challenge_ids: list[str] | None = Field(default=None, max_length=200)


class CompetitionInfo(CtfyModel):
    """Summary row used in the list view.

    Per-viewer fields (``is_registered`` / ``my_*``) are populated only
    when the request carries an authenticated user; for anonymous
    requests they fall back to sentinels (empty strings, ``-1``) so
    the response shape stays stable. Front-end treats ``my_rank < 0``
    as "no value" rather than "rank zero".
    """

    competition_id: str
    title: str
    description: str
    starts_at: str
    ends_at: str
    created_at: str
    updated_at: str
    created_by: str
    created_by_name: str
    challenge_ids: list[str] = Field(default_factory=list)
    # Server-derived projection. ``"upcoming"`` / ``"running"`` / ``"past"``
    # — saves the frontend from re-implementing the same string-compare
    # the backend already does.
    phase: Literal["upcoming", "running", "past"] = "running"
    # Total registered teams. Surfaced on cards so users can gauge
    # popularity at a glance.
    registered_count: int = 0
    # Viewer-scoped fields — see class docstring.
    is_registered: bool = False
    my_team_id: str = ""
    my_team_name: str = ""
    my_role: Literal["captain", "member", ""] = ""
    my_rank: int = -1
    my_score: int = -1
    my_solves: int = -1


class CompetitionDetail(CompetitionInfo):
    """Full detail payload — includes resolved challenge summaries and
    the caller's registration state when authenticated.
    """

    challenges: list[ChallengeInfo] = Field(default_factory=list)
    registered_at: str = ""


class CompetitionRegistrationInfo(CtfyModel):
    """One row in the admin "who's registered" table."""

    team_id: str
    team_name: str = ""
    registered_at: str


