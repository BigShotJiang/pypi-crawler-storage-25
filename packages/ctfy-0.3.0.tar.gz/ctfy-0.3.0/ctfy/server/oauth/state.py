"""HMAC-signed OAuth ``state`` parameters.

Rather than run server-side sessions just to round-trip a nonce through
the provider's authorize page, the platform encodes the interesting bits
(nonce, expiry, provider, optional redirect target, optional
link-token-hash) into a base64url payload and appends an HMAC-SHA256
signature. The key is :attr:`AppState.oauth_secret`, seeded from
``CTFY_SECRET_KEY`` or auto-generated on first boot.

Token format::

    <urlsafe_b64(canonical_json)>.<hex_sha256_hmac>

Canonicalisation uses ``json.dumps(..., sort_keys=True, separators=(",", ":"))``
so two equivalent dicts produce the same signature; callers never need
to match whitespace.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from typing import Any

from fastapi import HTTPException

_MAX_TTL_S = 15 * 60


def _canonical(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64_decode(data: str) -> bytes:
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def sign_state(
    secret: str,
    payload: dict[str, Any],
    *,
    ttl_s: int = 600,
) -> str:
    """Return a signed token encoding ``payload``.

    Always stamps a fresh nonce and an ``exp`` (Unix seconds) into the
    payload before signing, so callers don't need to worry about either.
    """
    if not secret:
        raise HTTPException(500, "OAuth signing secret is not configured")
    ttl_s = min(ttl_s, _MAX_TTL_S)
    stamped = dict(payload)
    stamped.setdefault("nonce", secrets.token_urlsafe(16))
    stamped["exp"] = int(time.time()) + ttl_s
    body = _canonical(stamped)
    sig = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return f"{_b64(body)}.{sig}"


def verify_state(secret: str, raw: str) -> dict[str, Any]:
    """Parse + verify a signed state string. Raises ``HTTPException(400)``
    on any failure (bad format, bad signature, expired).
    """
    if not secret:
        raise HTTPException(500, "OAuth signing secret is not configured")
    if not raw or raw.count(".") != 1:
        raise HTTPException(400, "Malformed state parameter")
    body_b64, sig = raw.split(".", 1)
    try:
        body = _b64_decode(body_b64)
    except Exception as exc:  # pragma: no cover — defensive
        raise HTTPException(400, "Malformed state parameter") from exc
    expected = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, expected):
        raise HTTPException(400, "Invalid state signature")
    try:
        payload: dict[str, Any] = json.loads(body)
    except Exception as exc:  # pragma: no cover — defensive
        raise HTTPException(400, "Malformed state payload") from exc
    if not isinstance(payload, dict):
        raise HTTPException(400, "Malformed state payload")
    exp = payload.get("exp")
    if not isinstance(exp, int) or exp < int(time.time()):
        raise HTTPException(400, "State parameter expired; start the login flow again")
    return payload
