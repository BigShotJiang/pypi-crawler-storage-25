"""OAuth2 client helpers for the platform login flow.

The platform supports GitHub and Google as identity providers. Both use
the standard Authorization Code flow; the implementation is intentionally
hand-rolled on top of ``httpx`` to avoid pulling in a heavier OAuth
library. A signed ``state`` parameter (``oauth.state``) defends against
CSRF and binds link-flow callbacks to a live user session.
"""

from ctfy.server.oauth.providers import (
    GitHubProvider,
    GoogleProvider,
    OAuthProfile,
    OAuthProvider,
    build_oauth_providers,
)
from ctfy.server.oauth.state import sign_state, verify_state

__all__ = [
    "GitHubProvider",
    "GoogleProvider",
    "OAuthProfile",
    "OAuthProvider",
    "build_oauth_providers",
    "sign_state",
    "verify_state",
]
