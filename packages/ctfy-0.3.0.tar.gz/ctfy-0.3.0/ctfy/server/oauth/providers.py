"""OAuth provider adapters (GitHub, Google).

Each provider implementation exposes three methods:

    ``authorize_url(state, redirect_uri)`` → URL the browser navigates to
    ``exchange_code(code, redirect_uri)``  → provider access token
    ``fetch_profile(access_token)``        → :class:`OAuthProfile`

Both providers are Authorization Code + user info endpoint; there is no
refresh token handling because the platform only uses the access token
once (to fetch the user's profile at login) and then discards it. A
future rewrite could store long-lived tokens for repo introspection —
that's explicitly out of scope for the login flow.
"""

from __future__ import annotations

from typing import Literal, Protocol, runtime_checkable

import httpx
from fastapi import HTTPException
from pydantic import BaseModel

from ctfy.core.config import CtfyConfig

# Timeout for outbound calls to providers. Short enough to fail fast if
# GitHub/Google are slow, long enough for real network round-trips.
_HTTP_TIMEOUT = httpx.Timeout(10.0, connect=5.0)


class OAuthProfile(BaseModel):
    """Normalised subset of provider user info."""

    provider: Literal["github", "google"]
    provider_user_id: str
    # Provider-side login handle (GitHub username). Only GitHub fills
    # it in; Google has no analogous concept. Used by the Star Gazer
    # verification flow because GitHub's public starred-listing
    # endpoint is keyed by login, not numeric id.
    provider_login: str = ""
    email: str = ""
    email_verified: bool = False
    display_name: str = ""
    avatar_url: str = ""


@runtime_checkable
class OAuthProvider(Protocol):
    # ``name`` is one of the values in :data:`OAUTH_PROVIDER_NAMES` but we
    # type it as ``str`` so test fakes can be instantiated without the
    # Protocol complaining about a narrower literal.
    name: str

    def authorize_url(self, state: str, redirect_uri: str) -> str: ...
    async def exchange_code(self, code: str, redirect_uri: str) -> str: ...
    async def fetch_profile(self, access_token: str) -> OAuthProfile: ...


OAUTH_PROVIDER_NAMES: tuple[str, ...] = ("github", "google")


class GitHubProvider:
    """GitHub OAuth App adapter.

    Requires ``user:email`` scope so we can pick the primary verified
    email — GitHub lets users hide their primary, and the bare
    ``/user`` endpoint can return ``email=null`` or an unverified
    secondary. Never trust the email until we've confirmed
    ``primary=true`` and ``verified=true``.
    """

    name: str = "github"

    def __init__(self, client_id: str, client_secret: str) -> None:
        self._client_id = client_id
        self._client_secret = client_secret

    def authorize_url(self, state: str, redirect_uri: str) -> str:
        params = httpx.QueryParams(
            {
                "client_id": self._client_id,
                "redirect_uri": redirect_uri,
                "scope": "read:user user:email",
                "state": state,
                "allow_signup": "true",
            }
        )
        return f"https://github.com/login/oauth/authorize?{params}"

    async def exchange_code(self, code: str, redirect_uri: str) -> str:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            resp = await client.post(
                "https://github.com/login/oauth/access_token",
                data={
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                    "code": code,
                    "redirect_uri": redirect_uri,
                },
                headers={"Accept": "application/json"},
            )
        _raise_for_status(resp, "GitHub token exchange failed")
        body = resp.json()
        token = body.get("access_token")
        if not token:
            raise HTTPException(400, f"GitHub declined the code: {body.get('error_description', '')}")
        return token

    async def fetch_profile(self, access_token: str) -> OAuthProfile:
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/vnd.github+json",
        }
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            user_resp = await client.get("https://api.github.com/user", headers=headers)
            _raise_for_status(user_resp, "GitHub /user failed")
            user = user_resp.json()
            emails_resp = await client.get(
                "https://api.github.com/user/emails", headers=headers
            )
            _raise_for_status(emails_resp, "GitHub /user/emails failed")
            emails = emails_resp.json()
        email = ""
        email_verified = False
        for row in emails if isinstance(emails, list) else []:
            if row.get("primary") and row.get("verified"):
                email = row.get("email") or ""
                email_verified = True
                break
        login = user.get("login") or ""
        display_name = user.get("name") or login
        return OAuthProfile(
            provider="github",
            provider_user_id=str(user.get("id", "")),
            provider_login=login,
            email=email,
            email_verified=email_verified,
            display_name=display_name,
            avatar_url=user.get("avatar_url") or "",
        )


class GoogleProvider:
    """Google OAuth 2.0 (OpenID Connect) adapter.

    The OpenID Connect userinfo endpoint returns the user's verified
    primary email in one call, so we skip ID-token parsing for the
    login flow. Scopes requested: ``openid email profile``.
    """

    name: str = "google"

    def __init__(self, client_id: str, client_secret: str) -> None:
        self._client_id = client_id
        self._client_secret = client_secret

    def authorize_url(self, state: str, redirect_uri: str) -> str:
        params = httpx.QueryParams(
            {
                "client_id": self._client_id,
                "redirect_uri": redirect_uri,
                "response_type": "code",
                "scope": "openid email profile",
                "state": state,
                "access_type": "online",
                "prompt": "select_account",
            }
        )
        return f"https://accounts.google.com/o/oauth2/v2/auth?{params}"

    async def exchange_code(self, code: str, redirect_uri: str) -> str:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            resp = await client.post(
                "https://oauth2.googleapis.com/token",
                data={
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                    "code": code,
                    "redirect_uri": redirect_uri,
                    "grant_type": "authorization_code",
                },
                headers={"Accept": "application/json"},
            )
        _raise_for_status(resp, "Google token exchange failed")
        body = resp.json()
        token = body.get("access_token")
        if not token:
            raise HTTPException(400, f"Google declined the code: {body.get('error_description', '')}")
        return token

    async def fetch_profile(self, access_token: str) -> OAuthProfile:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            resp = await client.get(
                "https://openidconnect.googleapis.com/v1/userinfo",
                headers={"Authorization": f"Bearer {access_token}"},
            )
        _raise_for_status(resp, "Google userinfo failed")
        info = resp.json()
        return OAuthProfile(
            provider="google",
            provider_user_id=str(info.get("sub", "")),
            email=info.get("email") or "",
            email_verified=bool(info.get("email_verified", False)),
            display_name=info.get("name") or info.get("email") or "",
            avatar_url=info.get("picture") or "",
        )


def _raise_for_status(resp: httpx.Response, message: str) -> None:
    if resp.status_code >= 400:
        snippet = resp.text[:200]
        raise HTTPException(400, f"{message}: HTTP {resp.status_code} {snippet}")


def build_oauth_providers(config: CtfyConfig) -> dict[str, OAuthProvider]:
    """Instantiate providers for any fully-configured credentials.

    A provider entry only appears in the returned dict when both its
    ``client_id`` and ``client_secret`` are non-empty. The login UI uses
    this set to decide which buttons to render.
    """
    providers: dict[str, OAuthProvider] = {}
    gh_id = config.github_client_id
    gh_secret = config.github_client_secret.get_secret_value()
    if gh_id and gh_secret:
        providers["github"] = GitHubProvider(gh_id, gh_secret)
    g_id = config.google_client_id
    g_secret = config.google_client_secret.get_secret_value()
    if g_id and g_secret:
        providers["google"] = GoogleProvider(g_id, g_secret)
    return providers
