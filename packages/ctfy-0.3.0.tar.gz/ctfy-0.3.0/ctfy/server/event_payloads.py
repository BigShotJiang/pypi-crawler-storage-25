"""Typed payloads for every :class:`PlatformEvent`.

Replaces the old ``emit_event(..., **detail_kwargs)`` signature. Each
event has its own pydantic model declaring exactly the fields it
carries — a typo at a call site (``ips`` instead of ``ip``) is now a
static error, a wrong payload class for a given event is caught by
mypy, and new event types can't ship without someone writing a model.

The model classes also advertise their :class:`PlatformEvent` via the
``EVENT`` class attribute so :func:`ctfy.server.events.emit_event` can
derive the broadcast name from the payload itself — callers only pass
the payload, never a separate ``event=`` arg.

Storage: these payloads are serialized into the existing
:class:`ctfy.core.activity.ActivityDetail` shape for the activity log
and straight to JSON for the SSE frame. ActivityDetail's free-form
``Optional[...]`` fields remain the on-disk schema so already-recorded
activities stay readable.
"""

from __future__ import annotations

from typing import ClassVar

from pydantic import ConfigDict

from ctfy.core.enums import PlatformEvent
from ctfy.core.models import CtfyModel

__all__ = [
    "EventPayload",
    "TeamRegisteredPayload",
    "TeamRoleChangedPayload",
    "TeamMembershipChangedPayload",
    "TeamMemberJoinedPayload",
    "TeamMemberLeftPayload",
    "TeamMemberKickedPayload",
    "InstanceStartedPayload",
    "InstanceReadyPayload",
    "InstanceErrorPayload",
    "InstanceStoppedPayload",
    "InstanceRenewedPayload",
    "FlagCorrectPayload",
    "FlagWrongPayload",
    "NodeRegisteredPayload",
    "NodeUnhealthyPayload",
    "NodeRecoveredPayload",
    "NodeRemovedPayload",
    "NodeUpdatedPayload",
    "AchievementUnlockedPayload",
    "MetaStatsPayload",
    "CompetitionRegisteredPayload",
    "CompetitionUnregisteredPayload",
]


class EventPayload(CtfyModel):
    """Envelope common to every event.

    ``team_id`` / ``team_name`` / ``challenge_id`` form the top-level
    columns on :class:`ActivityState`; per-event detail fields live on
    the concrete subclasses and are serialized into
    :class:`ActivityDetail`.

    ``extra="forbid"`` is the whole point — a typo at a call site
    (``ips`` instead of ``ip``, ``solve_time`` instead of
    ``solve_time_s``) raises :class:`pydantic.ValidationError` instead
    of being silently dropped on the floor.
    """

    model_config = ConfigDict(extra="forbid")

    #: Concrete subclass overrides with its own PlatformEvent member.
    EVENT: ClassVar[PlatformEvent]

    team_id: str = ""
    team_name: str = ""
    challenge_id: str = ""


# ---------------------------------------------------------------------------
# Team events
# ---------------------------------------------------------------------------


class TeamRegisteredPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.TEAM_REGISTERED

    ip: str = ""


class TeamRoleChangedPayload(EventPayload):
    """Audit payload for super-admin-driven role changes.

    ``previous_role`` / ``new_role`` capture the transition; the actor
    (the calling super-admin) is recorded by ``emit_event`` via its
    ``actor_id`` / ``actor_name`` kwargs and ends up on
    :class:`ActivityState` directly.
    """

    EVENT: ClassVar[PlatformEvent] = PlatformEvent.TEAM_ROLE_CHANGED

    previous_role: str = ""
    new_role: str = ""


class TeamMemberJoinedPayload(EventPayload):
    """Audit row: ``actor_id`` (the joining user) joined ``team_id``
    via an invite redeem. ``invite_id`` lets the activity surface
    correlate with the captain's mint."""

    EVENT: ClassVar[PlatformEvent] = PlatformEvent.TEAM_MEMBER_JOINED

    invite_id: str = ""


class TeamMemberLeftPayload(EventPayload):
    """Audit row: ``actor_id`` voluntarily left ``team_id`` (via
    ``POST /me/team/leave``). ``reason="leave"`` distinguishes from
    the kick path which writes a separate event type."""

    EVENT: ClassVar[PlatformEvent] = PlatformEvent.TEAM_MEMBER_LEFT


class TeamMemberKickedPayload(EventPayload):
    """Audit row: ``actor_id`` (the captain) removed
    ``target_user_id`` from ``team_id``. The kicked user's display
    name is denormalized so the audit page can render
    "Cap kicked Mem from Squad" without re-resolving the user.
    """

    EVENT: ClassVar[PlatformEvent] = PlatformEvent.TEAM_MEMBER_KICKED

    target_user_id: str = ""
    target_user_name: str = ""


class TeamMembershipChangedPayload(EventPayload):
    """A user moved teams (register / create / leave / redeem / kick).

    ``team_id`` (inherited from :class:`EventPayload`) is the team the
    user **landed on**. ``previous_team_id`` is the team they came from
    (empty on first registration). Subscribers refetch
    ``GET /teams/{id}`` for both sides — the SSE frame carries no member
    list, so the consumer always reads from authoritative state.

    Not admin_only: every viewer of a team page wants to see joins /
    leaves in real time. Not on the activity log either — the
    individual route (register / redeem / kick / leave) emits its own
    activity event when one is warranted; this is purely a
    "scoreboard-style" cache-invalidation signal.
    """

    EVENT: ClassVar[PlatformEvent] = PlatformEvent.TEAM_MEMBERSHIP_CHANGED

    user_id: str = ""
    previous_team_id: str = ""
    joined_via: str = ""


# ---------------------------------------------------------------------------
# Instance events
# ---------------------------------------------------------------------------


class InstanceStartedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_STARTED

    instance_id: str
    node_id: str
    ip: str = ""


class InstanceReadyPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_READY

    instance_id: str
    node_id: str


class InstanceErrorPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_ERROR

    instance_id: str
    node_id: str = ""
    error: str = ""


class InstanceStoppedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_STOPPED

    instance_id: str
    node_id: str = ""
    reason: str = ""
    ip: str = ""


class InstanceRenewedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_RENEWED

    instance_id: str
    ttl: int


# ---------------------------------------------------------------------------
# Flag submission events
# ---------------------------------------------------------------------------


class FlagCorrectPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.FLAG_CORRECT

    instance_id: str = ""
    solve_time_s: float = 0.0
    ip: str = ""
    # Which flag on the challenge was captured. On single-flag challenges
    # this is ``"main"``; on multi-flag challenges it identifies the hit
    # (e.g. ``"foothold"`` / ``"root"``). Achievement rules can key off
    # this to tell per-flag vs per-challenge events apart.
    flag_id: str = ""
    # True when this correct claim also made the team fully solve the
    # challenge (every declared flag captured). Equivalent to ``correct``
    # on single-flag challenges; distinguishes partial vs full solves on
    # multi-flag ones.
    challenge_fully_solved: bool = False


class FlagWrongPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.FLAG_WRONG

    instance_id: str = ""
    solve_time_s: float = 0.0
    ip: str = ""


# ---------------------------------------------------------------------------
# Node events — global scope, no team_id / challenge_id
# ---------------------------------------------------------------------------


class NodeRegisteredPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.NODE_REGISTERED

    node_id: str
    url: str


class NodeUnhealthyPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.NODE_UNHEALTHY

    node_id: str
    url: str = ""
    # Free-form description of why the node was marked unhealthy. The
    # reconciler fills in the heartbeat-timeout reason; future code
    # paths (e.g. registration retry exhaustion) can populate other
    # strings. Empty for older rows from before the field existed.
    error_message: str = ""


class NodeRecoveredPayload(EventPayload):
    """Emitted when a previously-unhealthy node sends a fresh heartbeat.

    Pairs with the most recent ``NodeUnhealthyPayload`` so the admin UI
    can show closed downtime windows with a duration. ``downtime_seconds``
    is the wall-clock gap between the last successful heartbeat and the
    recovery beat — it ignores reconciler-detection latency.
    """

    EVENT: ClassVar[PlatformEvent] = PlatformEvent.NODE_RECOVERED

    node_id: str
    url: str = ""
    downtime_seconds: float = 0.0


class NodeRemovedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.NODE_REMOVED

    node_id: str


class NodeUpdatedPayload(EventPayload):
    """Admin edited a node's display_name and/or labels.

    ``labels_changed`` is the list of label keys that differ from the
    previous state (added / removed / re-valued). Keeps the event
    compact while still being searchable — the new values live on the
    node row itself, fetched separately if needed.
    """

    EVENT: ClassVar[PlatformEvent] = PlatformEvent.NODE_UPDATED

    node_id: str
    display_name: str = ""
    labels_changed: list[str] = []


# ---------------------------------------------------------------------------
# Achievement events
# ---------------------------------------------------------------------------


class AchievementUnlockedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.ACHIEVEMENT_UNLOCKED

    achievement_id: str
    achievement_name: str = ""
    tier: str = "bronze"
    secret: bool = False


# ---------------------------------------------------------------------------
# Competition events — per-team signup recorded on the activity log so the
# timeline shows "joined Spring CTF". Lifecycle CRUD events
# (created/updated/deleted) bypass emit_event and broadcast straight
# through SSEHub like announcements; only the per-team registration ones
# need typed payloads here.
# ---------------------------------------------------------------------------


class CompetitionRegisteredPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.COMPETITION_REGISTERED

    competition_id: str
    competition_title: str = ""


class CompetitionUnregisteredPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.COMPETITION_UNREGISTERED

    competition_id: str
    competition_title: str = ""


# ---------------------------------------------------------------------------
# Synthetic UI signal — not an EventPayload because it has no team/actor
# envelope, no activity-log row, and is never recorded by emit_event. The
# StatusBar subscribes to its SSE topic to drop the 60s/30s polls it used
# to make against /meta and /admin/overview.
# ---------------------------------------------------------------------------


class MetaStatsPayload(CtfyModel):
    """Cluster-wide counters mirrored from ``MetaResponse`` admin fields.

    Broadcast ``admin_only=True`` since the numbers themselves are
    admin-only on /meta — members never see this frame. Carries the
    full snapshot (not a delta) so the StatusBar can apply the payload
    without holding any prior state and so a late-joining admin's
    initial /meta fetch and the first SSE frame agree.
    """

    model_config = ConfigDict(extra="forbid")

    teams_total: int = 0
    nodes_total: int = 0
    nodes_healthy: int = 0
    running_instances: int = 0
    solves_total: int = 0
    challenges_total: int = 0
