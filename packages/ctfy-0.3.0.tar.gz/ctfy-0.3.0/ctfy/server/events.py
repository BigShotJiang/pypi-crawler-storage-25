"""Typed platform event emission.

``emit_event(app, payload, *, actor_id, actor_name, actor_type)`` is
the single entry point. The payload class (see
:mod:`ctfy.server.event_payloads`) declares which :class:`PlatformEvent`
it represents and which fields it carries, so we never ship a typo'd
event name or a typo'd detail field again.

The function does two things:

1. Persists an :class:`ActivityState` row so the activity log stays
   authoritative.
2. Broadcasts the event (name + JSON payload) through :class:`SSEHub`
   to every connected client that matches the event's team filter.

Every call site must pass actor context — the three ``actor_*`` kwargs
are required so the activity log reliably answers 'who did this?'.
"""

from __future__ import annotations

from ctfy.core.activity import ActivityDetail
from ctfy.core.enums import PlatformEvent
from ctfy.core.log import log
from ctfy.core.state.models import ActivityState, ActorType
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.event_payloads import EventPayload

__all__ = ["emit_event"]

#: Envelope fields live on ``ActivityState`` top-level columns, everything
#: else goes into ``ActivityDetail``. Keep in sync with ``EventPayload``
#: envelope fields.
_ENVELOPE_FIELDS = frozenset({"team_id", "team_name", "challenge_id"})


def emit_event(
    app: AppState,
    payload: EventPayload,
    *,
    actor_id: str,
    actor_name: str,
    actor_type: ActorType,
    admin_only: bool = False,
) -> None:
    """Record and broadcast a typed platform event.

    The payload's class advertises its :class:`PlatformEvent` via the
    ``EVENT`` class attribute; callers never pass a separate event
    argument. Any missing or mistyped field surfaces at construction
    time, before the emit even runs.

    ``actor_id`` / ``actor_name`` / ``actor_type`` identify who caused
    the event (a team, a node, an admin, or a system loop). Required
    so the activity log always supports 'filter by actor'.

    ``admin_only=True`` restricts the SSE broadcast to admin sessions.
    The activity log row is always written regardless — the flag only
    gates real-time delivery. Use for events whose payload carries
    audit info that members shouldn't see (e.g. role changes).
    """
    event = payload.EVENT.value

    dumped = payload.model_dump()
    detail_fields = {k: v for k, v in dumped.items() if k not in _ENVELOPE_FIELDS}

    # ActivityDetail is the long-lived storage schema — tolerant of
    # missing fields per event. Validating here means an emitter that
    # grows a new field without updating ActivityDetail gets a loud
    # error rather than silently dropping the field.
    detail = ActivityDetail.model_validate(detail_fields)

    timestamp = now_iso()
    app.state_backend.add_activity(
        ActivityState(
            timestamp=timestamp,
            event=event,
            team_id=payload.team_id,
            team_name=payload.team_name,
            challenge_id=payload.challenge_id,
            actor_id=actor_id,
            actor_name=actor_name,
            actor_type=actor_type,
            detail=detail,
        )
    )
    app.sse_hub.broadcast(
        event,
        team_id=payload.team_id,
        data={
            "challenge_id": payload.challenge_id,
            "actor_id": actor_id,
            "actor_name": actor_name,
            "actor_type": actor_type,
            **detail.model_dump(exclude_none=True),
        },
        admin_only=admin_only,
    )

    # Derive the cluster-counter snapshot whenever the just-broadcast
    # event's write path changed a number that ``MetaResponse`` exposes
    # to admins. This is what lets the admin StatusBar drop the 60s
    # /meta and 30s /admin/overview polls — the SSE frame carries the
    # same numbers directly. Local import keeps the events module free
    # of the state snapshot dependencies that ``meta_stats`` pulls in.
    from ctfy.server.meta_stats import META_AFFECTING_EVENTS, emit_meta_stats

    if event in META_AFFECTING_EVENTS:
        try:
            emit_meta_stats(app)
        except Exception:
            log.exception("meta_stats emit failed", trigger_event=event)

    # Public scoreboard-changed signal — fired alongside the original
    # event so the Scoreboard page can refetch without subscribing to
    # every individual rank-affecting event type. See
    # ``scoreboard_signal.SCOREBOARD_AFFECTING_EVENTS``.
    from ctfy.server.scoreboard_signal import (
        SCOREBOARD_AFFECTING_EVENTS,
        emit_scoreboard_updated,
    )

    if event in SCOREBOARD_AFFECTING_EVENTS:
        try:
            emit_scoreboard_updated(app)
        except Exception:
            log.exception("scoreboard_updated emit failed", trigger_event=event)

    # Per-instance event stream. Any payload that carries an instance_id
    # gets mirrored into ``{archive}/{id}/events.jsonl`` so offline
    # analysis can reconstruct a single instance's lifecycle without
    # filtering the global activity table.
    archive = app.instance_archive
    if archive is not None:
        instance_id = getattr(payload, "instance_id", "") or dumped.get("instance_id") or ""
        if instance_id:
            archive.append_event(
                instance_id,
                {
                    "timestamp": timestamp,
                    "event": event,
                    "actor_id": actor_id,
                    "actor_name": actor_name,
                    "actor_type": actor_type,
                    "team_id": payload.team_id,
                    "team_name": payload.team_name,
                    "challenge_id": payload.challenge_id,
                    **detail.model_dump(exclude_none=True),
                },
            )

    # Achievement evaluation — run after the event is fully recorded so
    # rule predicates observing counts / solves see post-event state
    # (e.g. first_blood_team wants the Solve row to already be there).
    # Inline rather than dispatched to a thread: each rule is a handful
    # of cheap SQLite reads, the in-memory backend is sub-microsecond,
    # and keeping it synchronous means tests (and live clients) see the
    # unlocked state by the time the triggering request returns. Skip
    # ACHIEVEMENT_UNLOCKED itself so an unlock can't recursively trigger
    # another unlock.
    if event != PlatformEvent.ACHIEVEMENT_UNLOCKED.value and actor_type == "team":
        # Achievements credit the team in scope for this event. The
        # payload was already constructed with the right team_id in
        # scope (the call site knew which competition / per-comp team
        # the action belonged to), so we trust ``payload.team_id``
        # directly instead of round-tripping through
        # ``get_membership(actor_id)``. The latter only ever returned
        # the legacy default-slot membership, which doesn't exist
        # post user/team-split.
        from ctfy.server.achievements.engine import evaluate as _evaluate

        target_team_id = payload.team_id
        try:
            _evaluate(
                app,
                PlatformEvent(event),
                payload,
                actor_type="team",
                actor_team_id=target_team_id,
                actor_user_id=actor_id,
                actor_user_name=actor_name,
            )
        except Exception:
            log.exception(
                "Achievement evaluator crashed",
                trigger_event=event,
                team_id=target_team_id,
            )
