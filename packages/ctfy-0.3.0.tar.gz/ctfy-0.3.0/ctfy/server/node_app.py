"""Node-side FastAPI application factory.

Stands up a worker process that exposes the node HTTP contract (see
``server/routes/node_instances.py``), registers itself with the platform,
and runs a heartbeat loop so the platform can mark it unhealthy on loss.
"""

from __future__ import annotations

import asyncio
import hmac
import socket
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any

import httpx
from fastapi import Depends, FastAPI, HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from ctfy.core.challenge import ChallengeManager
from ctfy.core.config import CtfyConfig
from ctfy.core.constants import (
    DEFAULT_NODE_CAPACITY,
    NODE_CPU_PER_INSTANCE,
    NODE_MEMORY_GB_PER_INSTANCE,
)
from ctfy.core.enums import InstanceStatus
from ctfy.core.exceptions import ConfigError
from ctfy.core.log import log, setup_logging
from ctfy.server.auth import bearer_optional
from ctfy.server.node_state import NodeInstanceStore

DEFAULT_HEARTBEAT_INTERVAL = 30  # seconds
DEFAULT_REGISTER_RETRIES = 6
DEFAULT_REGISTER_BACKOFF = 2.0  # seconds (doubled each retry)


def _non_loopback_ipv4_addresses() -> list[str]:
    """Enumerate the host's non-loopback IPv4 addresses.

    Uses ``getaddrinfo(hostname)`` rather than parsing platform-specific
    interface tables so the implementation stays portable across Linux/mac.
    The order returned by the resolver is preserved so a single-interface
    host picks the same address every time.
    """
    try:
        infos = socket.getaddrinfo(socket.gethostname(), None, family=socket.AF_INET)
    except OSError:
        return []
    seen: list[str] = []
    for info in infos:
        addr = info[4][0]
        if addr.startswith("127.") or addr in seen:
            continue
        seen.append(addr)
    return seen


def auto_capacity(
    *,
    cpu_per_instance: int = NODE_CPU_PER_INSTANCE,
    memory_gb_per_instance: float = NODE_MEMORY_GB_PER_INSTANCE,
) -> int:
    """Derive a per-node instance capacity from the host's CPU + RAM.

    Replaces the historical ``--capacity 10`` static default: a 2-core
    laptop and a 32-core server should not advertise the same number of
    slots. Returns ``min(cpu_count * NODE_CPU_PER_INSTANCE, mem_gb /
    NODE_MEMORY_GB_PER_INSTANCE)``, floored at 1.

    Falls back to ``DEFAULT_NODE_CAPACITY`` if ``psutil`` is unavailable
    or the system probes fail — auto-capacity is best-effort, never a
    hard requirement to start the node.
    """
    try:
        import psutil

        cpu_count = psutil.cpu_count(logical=True) or 1
        mem_gb = psutil.virtual_memory().total / (1024**3)
    except Exception as exc:
        log.warning(
            "auto_capacity: psutil probe failed; using DEFAULT_NODE_CAPACITY",
            error=str(exc),
            fallback=DEFAULT_NODE_CAPACITY,
        )
        return DEFAULT_NODE_CAPACITY

    by_cpu = cpu_count * max(1, cpu_per_instance)
    by_mem = int(mem_gb / max(0.1, memory_gb_per_instance))
    return max(1, min(by_cpu, by_mem))


def _resolve_public_host(platform_url: str = "") -> str:
    """Pick the node's public-facing IPv4 when the operator didn't set one.

    * Exactly one non-loopback address → use it (single-NIC happy path).
    * ``platform_url`` points at localhost/127.0.0.1 → use ``127.0.0.1``
      (single-machine dev: server and node on the same box).
    * Zero / multiple addresses on a remote-platform setup → refuse to
      guess; registering the wrong interface fails silently later.
    """
    candidates = _non_loopback_ipv4_addresses()
    if len(candidates) == 1:
        return candidates[0]
    if platform_url and any(h in platform_url for h in ("127.0.0.1", "localhost")):
        return "127.0.0.1"
    raise ConfigError(
        "Cannot infer node public host automatically; set "
        "CTFY_NODE_PUBLIC_URL (or --public-url) explicitly. "
        f"Detected non-loopback IPv4 addresses: {candidates or '[]'}"
    )


@dataclass
class NodeAppState:
    """Shared state for the node process. Kept deliberately small."""

    # One-time registration token — invite minted by ``POST /nodes/invites``
    # or the admin token. Used exactly once, on the initial ``POST
    # /nodes/register`` call. Empty means "skip auto-register"; routes
    # that need real auth look at :attr:`node_token` instead.
    registration_token: str
    public_url: str
    capacity: int
    labels: dict[str, str] = field(default_factory=dict)
    # Human-readable label the node asks to be registered as. Defaults to
    # public_url so every node always has *something* — operators can
    # rename via PATCH /admin/nodes/{id} later.
    display_name: str = ""
    node_id: str = ""
    platform_url: str = ""
    store: NodeInstanceStore | None = None
    challenge_manager: Any = field(default=None, repr=False)
    # Filesystem root sampled for disk-utilisation metric at heartbeat.
    # Defaults to ``/`` — when the operator cares about the data volume
    # specifically, override with ``create_node_app(..., data_dir=...)``.
    data_dir: str = "/"
    # FastAPI auth dep for the node's own HTTP API. Injected into routes
    # by :func:`create_node_app`; rejects every request until registration
    # populates :attr:`node_token`.
    require_node_token: Any = field(default=None, repr=False)
    # Per-node bearer token. Same value is used both for node→platform
    # calls (as the outbound Bearer) and for verifying platform→node
    # calls (compare incoming Bearer against this). Empty until
    # registration succeeds, at which point the platform holds the same
    # plaintext on ``NodeState.token``.
    node_token: str = ""


def make_require_node_token(state: NodeAppState):
    """Bearer auth for the node's HTTP API.

    Compares the incoming Bearer against the per-node token the
    platform handed us at registration (stored in memory as
    ``state.node_token``). Before registration completes the token is
    empty, so every request 403s — that's deliberate, the platform has
    no reason to call us until it knows our node_id and holds our
    token plaintext.
    """

    async def _dep(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ):
        if not state.node_token:
            raise HTTPException(403, "Node has not yet registered; token unavailable")
        if not credentials:
            raise HTTPException(401, "Missing bearer token")
        if not hmac.compare_digest(credentials.credentials, state.node_token):
            raise HTTPException(403, "Invalid node token")

    return _dep


# ---------------------------------------------------------------------------
# Self-registration + heartbeat
# ---------------------------------------------------------------------------


def _parse_labels(raw: str) -> dict[str, str]:
    """Parse ``k=v,k=v`` form."""
    out: dict[str, str] = {}
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "=" in chunk:
            k, v = chunk.split("=", 1)
            out[k.strip()] = v.strip()
        else:
            out[chunk] = "true"
    return out


async def _register_with_platform(state: NodeAppState) -> bool:
    """Establish node identity against the platform. Returns True when the
    node has a usable ``(node_id, node_token)`` pair, False otherwise.

    Startup flow:

    1. If the local store has a persisted identity from a previous
       registration, reuse it — the platform retains the same row across
       its own restarts so the per-node bearer is still valid.
    2. Otherwise fall back to the one-time ``registration_token`` (an
       admin-minted invite) to call ``POST /nodes/register``.

    Persisting the returned ``node_token`` means subsequent container
    restarts do not need a fresh invite — critical for
    ``docker compose restart node``, which would otherwise burn a new
    admin-minted token every time.
    """
    if not state.platform_url:
        log.warning("CTFY_PLATFORM_URL not set; skipping node registration")
        return False

    if state.store is not None:
        identity = state.store.get_identity()
        if identity is not None:
            state.node_id, state.node_token = identity
            # Registration token (if any) is now redundant — keep it out of
            # memory so no code path accidentally replays a consumed invite.
            state.registration_token = ""
            log.info(
                "Loaded persisted node identity, skipping registration",
                node_id=state.node_id,
            )
            return True

    if not state.registration_token:
        log.error(
            "CTFY_NODE_TOKEN is empty and no persisted identity found; "
            "cannot register. Sign in to the platform as admin and mint "
            "a node invite (admin UI → Nodes → Mint invite, or "
            "`ctfy server invite`), then set CTFY_NODE_TOKEN."
        )
        return False

    url = f"{state.platform_url.rstrip('/')}/api/v1/nodes/register"
    # Registration uses the one-time invite (or admin) token — platform
    # burns it on success and hands back fresh per-node credentials.
    headers = {"Authorization": f"Bearer {state.registration_token}"}
    body = {
        "url": state.public_url,
        "display_name": state.display_name or state.public_url,
        "capacity": state.capacity,
        "labels": state.labels,
    }
    delay = DEFAULT_REGISTER_BACKOFF
    for attempt in range(DEFAULT_REGISTER_RETRIES):
        try:
            async with httpx.AsyncClient(timeout=10) as c:
                resp = await c.post(url, json=body, headers=headers)
            if resp.status_code == 200:
                node = resp.json()
                state.node_id = node.get("node_id", "")
                state.node_token = node.get("node_token", "")
                # Registration token is one-time; drop it from memory now
                # that we have the long-lived per-node token.
                state.registration_token = ""
                # Persist so later restarts can reuse the long-lived bearer.
                if state.store is not None and state.node_id and state.node_token:
                    state.store.put_identity(state.node_id, state.node_token)
                log.info(
                    "Node registered with platform",
                    node_id=state.node_id,
                    public_url=state.public_url,
                )
                return True
            # 403 on a replay means the invite was already consumed — no
            # amount of retrying will help.
            if resp.status_code == 403:
                log.error(
                    "Node registration rejected (token invalid / already used); aborting",
                    body=resp.text[:200],
                )
                return False
            log.warning(
                "Node registration rejected; retrying",
                status=resp.status_code,
                body=resp.text[:200],
            )
        except Exception as exc:
            log.warning("Node registration failed; retrying", error=str(exc))
        await asyncio.sleep(delay)
        delay *= 2
    log.error("Node registration exhausted retries")
    return False


def _sample_metrics(data_dir: str) -> dict[str, float]:
    """Sample CPU / memory / disk utilisation as percentages (0–100).

    ``cpu_percent(interval=None)`` diffs against the previous call, so
    the first beat after startup reports 0 — acceptable noise given the
    30s beat interval. Failures are swallowed (metrics aren't
    load-bearing) and default to 0.
    """
    try:
        import psutil

        return {
            "cpu_percent": float(psutil.cpu_percent(interval=None)),
            "memory_percent": float(psutil.virtual_memory().percent),
            "disk_percent": float(psutil.disk_usage(data_dir).percent),
        }
    except Exception as exc:
        log.debug("Metric sample failed", error=str(exc))
        return {"cpu_percent": 0.0, "memory_percent": 0.0, "disk_percent": 0.0}


async def _heartbeat_once(state: NodeAppState) -> None:
    if not state.platform_url or not state.node_id or not state.node_token:
        return
    url = f"{state.platform_url.rstrip('/')}/api/v1/nodes/heartbeat"
    headers = {"Authorization": f"Bearer {state.node_token}"}
    # Stamp ``sampled_at`` right before the request so the platform can
    # measure node→server one-way latency as ``received_at - sampled_at``.
    # This requires platform / node clock skew to be small (NTP); skew
    # makes the latency reading wrong but doesn't break heartbeats.
    body = {
        "node_id": state.node_id,
        "running": state.store.count_active() if state.store else 0,
        "capacity": state.capacity,
        **_sample_metrics(state.data_dir),
        "sampled_at": time.time(),
    }
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            resp = await c.post(url, json=body, headers=headers)
    except Exception as exc:
        log.debug("Heartbeat failed", error=str(exc))
        return
    # Stale identity (admin-deleted the node, platform DB reset, etc.) — drop
    # our persisted copy so the next container restart re-registers from the
    # invite token instead of looping on a token the platform no longer knows.
    if resp.status_code in (401, 403, 404) and state.store is not None:
        log.warning(
            "Heartbeat rejected; clearing persisted identity so next restart re-registers",
            status=resp.status_code,
            node_id=state.node_id,
        )
        state.store.clear_identity()


async def _heartbeat_loop(state: NodeAppState, interval: int) -> None:
    while True:
        await asyncio.sleep(interval)
        await _heartbeat_once(state)


async def _deregister(state: NodeAppState) -> None:
    if not state.platform_url or not state.node_id or not state.node_token:
        return
    url = f"{state.platform_url.rstrip('/')}/api/v1/nodes/{state.node_id}"
    headers = {"Authorization": f"Bearer {state.node_token}"}
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            await c.delete(url, headers=headers)
    except Exception as exc:
        log.debug("Node deregister failed (platform will time out heartbeat)", error=str(exc))


def _reconcile_store_on_start(state: NodeAppState) -> None:
    """Mark pre-existing records ERROR: their containers were killed by the
    orphan-cleanup sweep, so the instance can no longer serve traffic even
    though we still know its flag."""
    if not state.store:
        return
    for rec in state.store.list_all():
        if rec.status not in (InstanceStatus.ERROR, InstanceStatus.STOPPED):
            state.store.set_status(
                rec.instance_id,
                InstanceStatus.ERROR,
                error="Node restarted; container no longer running",
            )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_node_app(
    config: CtfyConfig | None = None,
    *,
    registration_token: str = "",
    public_url: str = "",
    display_name: str = "",
    capacity: int = 0,
    labels: dict[str, str] | None = None,
    platform_url: str = "",
    store: NodeInstanceStore | None = None,
    db_path: str = "",
    heartbeat_interval: int = DEFAULT_HEARTBEAT_INTERVAL,
    auto_register: bool = True,
) -> FastAPI:
    setup_logging()
    if config is None:
        config = CtfyConfig()

    platform_url = platform_url or config.platform_url
    public_url = public_url or f"http://{_resolve_public_host(platform_url)}:{config.server_port}"
    labels = labels if labels is not None else {}

    # capacity <= 0 means "decide for me" — sized from host CPU + RAM
    # rather than a one-size-fits-all default.
    if capacity <= 0:
        capacity = auto_capacity()
        log.info("Auto-derived node capacity from host resources", capacity=capacity)

    resolved_db = db_path or str(config.project_root / "data" / "node.sqlite3")
    if store is None:
        store = NodeInstanceStore(resolved_db)

    challenge_manager = ChallengeManager(config)

    # Sample disk usage against the partition that holds the node's
    # persistent data (SQLite + per-instance state), so alerts are
    # meaningful instead of reflecting whatever `/` has free.
    from pathlib import Path as _Path

    data_dir = str(_Path(resolved_db).resolve().parent)

    state = NodeAppState(
        registration_token=registration_token,
        public_url=public_url,
        display_name=display_name,
        platform_url=platform_url,
        capacity=capacity,
        labels=labels,
        store=store,
        challenge_manager=challenge_manager,
        data_dir=data_dir,
    )
    state.require_node_token = make_require_node_token(state)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        # Clean up any stale Docker containers from before this process started.
        try:
            from ctfy.providers.docker_provider.utils import cleanup_orphans

            await asyncio.get_running_loop().run_in_executor(
                None, lambda: cleanup_orphans(instances_dir=config.instances_dir)
            )
        except Exception as exc:
            log.warning("Orphan cleanup skipped", error=str(exc))

        # Mark surviving records as ERROR (container is gone after cleanup).
        _reconcile_store_on_start(state)

        tasks: list[asyncio.Task] = []
        if auto_register and platform_url:
            registered = await _register_with_platform(state)
            if registered:
                tasks.append(asyncio.create_task(_heartbeat_loop(state, heartbeat_interval)))

        try:
            yield
        finally:
            for t in tasks:
                t.cancel()
                try:
                    await t
                except (asyncio.CancelledError, Exception):
                    pass
            await _deregister(state)

    app = FastAPI(
        title="ctfy — Node",
        description="Worker node HTTP API. Authenticates with cluster token.",
        lifespan=lifespan,
    )

    # Routes are mounted under /api/v1 — matches the platform SDK's base path.
    from ctfy.server.routes import node_instances

    app.include_router(node_instances.create_router(state), prefix="/api/v1")

    @app.get("/api/v1/health")
    def health():
        return {
            "status": "ok",
            "public_url": state.public_url,
            "capacity": state.capacity,
            "running": state.store.count_active() if state.store else 0,
            "labels": state.labels,
        }

    # Expose state for tests / debugging.
    app.state.node = state
    return app
