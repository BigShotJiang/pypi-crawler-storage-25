"""Per-instance artifact directory on disk.

Owns the ``{root}/{instance_id}/`` layout and exposes small, focused helpers
for writing each artifact type. The route layer and background loops call
into this module; no one else touches the filesystem layout.

Contents of each instance directory:

* ``instance.json``  — :class:`InstanceRecord` snapshot plus the raw spec.
  Written atomically (temp file + rename) so a partial write never leaves a
  corrupt manifest visible.
* ``events.jsonl``   — newline-delimited lifecycle events as they occur
  (STARTED, READY, ERROR, RENEWED, STOPPED, FLAG_CORRECT, FLAG_WRONG).
* ``submissions.jsonl`` — one JSON object per flag attempt (redundant with
  ``events.jsonl`` but easier to batch-analyze on its own).
* ``container.log`` — combined stdout/stderr from the challenge container,
  captured from the node at stop time.
* ``traffic.jsonl`` — newline-delimited mitmproxy flows captured by the
  proxy sidecar (one JSON object per request/response pair). Pulled from
  the node at stop time.
* ``traffic.pcap`` — raw packet capture written by ``tcpdump -i any`` in
  the proxy sidecar. Pulled from the node at stop time. Useful for
  challenges that exercise non-HTTP protocols where the JSONL is silent.

Append helpers swallow OSError into a warning log: the archive is a
best-effort sidecar, not a correctness-critical path — a disk full or a
read-only mount should not crash the health-check loop.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
import threading
from pathlib import Path
from typing import Any

from ctfy.core.log import log
from ctfy.core.state.models import InstanceRecord

__all__ = ["InstanceArchive", "is_safe_instance_id"]


# Strict allowlist for instance ids used as path components. Real ids are
# UUIDv4 (``[a-f0-9-]{36}``); this superset accommodates legacy / future id
# schemes while still rejecting any character that could escape a path.
# Critical: ``..`` and ``/`` are excluded by construction.
_INSTANCE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def is_safe_instance_id(instance_id: str) -> bool:
    """True iff *instance_id* is safe to use as a single path component.

    Used by every code path that turns a user-supplied id into a
    filesystem path. The admin pcap download endpoint relies on this as
    the first line of defence against path-traversal attacks; the
    in-archive resolved-path check is a second layer.
    """
    return bool(instance_id) and _INSTANCE_ID_RE.fullmatch(instance_id) is not None


class InstanceArchive:
    """Thread-safe filesystem sink for per-instance artifacts."""

    def __init__(self, root: Path) -> None:
        self._root = Path(root)
        # One lock per instance would be ideal, but the write volume is
        # low (a few JSON lines per instance lifecycle) so a single lock
        # keeps the implementation simple without becoming a hotspot.
        self._lock = threading.Lock()

    @property
    def root(self) -> Path:
        return self._root

    def dir_for(self, instance_id: str) -> Path:
        """Return the per-instance directory, creating it on first access.

        Validates *instance_id* against a strict allowlist before joining
        it onto the archive root so a malicious value can't escape the
        directory. Internal callers always pass platform-generated UUIDs
        so this is belt-and-suspenders, but the same helper is reachable
        from the admin pcap download endpoint where the value is taken
        from a URL path parameter.
        """
        if not is_safe_instance_id(instance_id):
            raise ValueError(f"unsafe instance_id: {instance_id!r}")
        path = self._root / instance_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _safe_artifact_path(self, instance_id: str, filename: str) -> Path | None:
        """Resolve ``{root}/{instance_id}/{filename}`` and verify containment.

        Returns ``None`` if *instance_id* fails validation, the resolved
        path escapes the archive root, or the file does not exist. Used
        as the read-side of the same defence-in-depth pattern as
        :meth:`dir_for`.
        """
        if not is_safe_instance_id(instance_id) or "/" in filename or filename in (".", ".."):
            return None
        candidate = (self._root / instance_id / filename).resolve()
        try:
            root = self._root.resolve()
        except OSError:
            return None
        if not candidate.is_relative_to(root):
            return None
        return candidate if candidate.is_file() else None

    # -- manifest ------------------------------------------------------------

    def write_manifest(self, record: InstanceRecord, spec: dict[str, Any] | None = None) -> None:
        """Atomically (re)write ``instance.json`` for *record*."""
        try:
            target = self.dir_for(record.instance_id) / "instance.json"
            payload: dict[str, Any] = json.loads(record.model_dump_json())
            if spec:
                payload["spec"] = spec
            with self._lock:
                # tempfile + os.replace → either the old file stays or the
                # new one appears; no partial write is ever visible. The
                # temp lives in the same directory so rename is atomic.
                fd, tmp_path = tempfile.mkstemp(
                    prefix=".instance-", suffix=".json", dir=str(target.parent)
                )
                try:
                    with os.fdopen(fd, "w", encoding="utf-8") as fh:
                        json.dump(payload, fh, ensure_ascii=False, indent=2)
                    os.replace(tmp_path, target)
                except Exception:
                    with _suppress():
                        os.unlink(tmp_path)
                    raise
        except OSError as exc:
            log.warning(
                "Failed to write instance manifest",
                instance=record.instance_id,
                error=str(exc),
            )

    # -- append helpers ------------------------------------------------------

    def append_event(self, instance_id: str, event: dict[str, Any]) -> None:
        self._append_jsonl(instance_id, "events.jsonl", event)

    def append_submission(self, instance_id: str, submission: dict[str, Any]) -> None:
        self._append_jsonl(instance_id, "submissions.jsonl", submission)

    def _append_jsonl(self, instance_id: str, filename: str, payload: dict[str, Any]) -> None:
        if not instance_id:
            return
        try:
            target = self.dir_for(instance_id) / filename
            line = json.dumps(payload, ensure_ascii=False) + "\n"
            with self._lock, target.open("a", encoding="utf-8") as fh:
                fh.write(line)
        except OSError as exc:
            log.warning(
                "Failed to append to instance artifact",
                instance=instance_id,
                file=filename,
                error=str(exc),
            )

    # -- container log -------------------------------------------------------

    def write_container_logs(self, instance_id: str, logs: str) -> None:
        if not instance_id or logs is None:
            return
        try:
            target = self.dir_for(instance_id) / "container.log"
            with self._lock, target.open("w", encoding="utf-8", errors="replace") as fh:
                fh.write(logs)
        except OSError as exc:
            log.warning(
                "Failed to write container log",
                instance=instance_id,
                error=str(exc),
            )

    # -- traffic --------------------------------------------------------------

    def write_traffic(self, instance_id: str, flows: list[dict[str, Any]]) -> None:
        """Persist mitmproxy flows for *instance_id* as ``traffic.jsonl``.

        Called once at archive time with the full list of flows fetched
        from the node. Overwrites any prior file so retries are
        idempotent.
        """
        if not instance_id or flows is None:
            return
        try:
            target = self.dir_for(instance_id) / "traffic.jsonl"
            with self._lock, target.open("w", encoding="utf-8") as fh:
                for flow in flows:
                    fh.write(json.dumps(flow, ensure_ascii=False) + "\n")
        except OSError as exc:
            log.warning(
                "Failed to write instance traffic",
                instance=instance_id,
                error=str(exc),
            )

    # -- read helpers (admin API) -------------------------------------------

    def read_events(self, instance_id: str, *, limit: int = 0) -> list[dict[str, Any]]:
        return self._read_jsonl(instance_id, "events.jsonl", limit=limit)

    def read_submissions(self, instance_id: str, *, limit: int = 0) -> list[dict[str, Any]]:
        return self._read_jsonl(instance_id, "submissions.jsonl", limit=limit)

    def read_traffic(self, instance_id: str, *, limit: int = 0) -> list[dict[str, Any]]:
        return self._read_jsonl(instance_id, "traffic.jsonl", limit=limit)

    def count_traffic(self, instance_id: str) -> int:
        """Return the number of flows persisted for *instance_id* (0 if none)."""
        path = self._safe_artifact_path(instance_id, "traffic.jsonl")
        if path is None:
            return 0
        try:
            with path.open("r", encoding="utf-8") as fh:
                return sum(1 for line in fh if line.strip())
        except OSError as exc:
            log.warning(
                "Failed to count instance traffic",
                instance=instance_id,
                error=str(exc),
            )
            return 0

    # -- pcap -----------------------------------------------------------------

    def write_pcap(self, instance_id: str, data: bytes) -> None:
        """Persist a tcpdump capture as ``traffic.pcap``.

        Called once at archive time with the raw bytes pulled from the
        node. Overwrites any prior file so retries are idempotent.
        """
        if not data:
            return
        try:
            target = self.dir_for(instance_id) / "traffic.pcap"
            with self._lock, target.open("wb") as fh:
                fh.write(data)
        except (OSError, ValueError) as exc:
            log.warning(
                "Failed to write instance pcap",
                instance=instance_id,
                error=str(exc),
            )

    def pcap_path(self, instance_id: str) -> Path | None:
        """Path-traversal-safe lookup of the persisted pcap for *instance_id*.

        Returns ``None`` if the id is unsafe, the file is missing, or
        the resolved path escapes the archive root. The admin download
        route relies on this returning ``None`` rather than raising so a
        404 (not 500) surfaces for a missing capture.
        """
        return self._safe_artifact_path(instance_id, "traffic.pcap")

    def pcap_size(self, instance_id: str) -> int:
        """Bytes on disk for the persisted pcap (0 if absent)."""
        path = self.pcap_path(instance_id)
        if path is None:
            return 0
        try:
            return path.stat().st_size
        except OSError:
            return 0

    def read_container_log(self, instance_id: str) -> str:
        path = self._safe_artifact_path(instance_id, "container.log")
        if path is None:
            return ""
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            log.warning(
                "Failed to read container log",
                instance=instance_id,
                error=str(exc),
            )
            return ""

    def has_artifact(self, instance_id: str, filename: str) -> bool:
        return self._safe_artifact_path(instance_id, filename) is not None

    def _read_jsonl(self, instance_id: str, filename: str, *, limit: int) -> list[dict[str, Any]]:
        path = self._safe_artifact_path(instance_id, filename)
        if path is None:
            return []
        out: list[dict[str, Any]] = []
        try:
            with path.open("r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        out.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
                    if limit > 0 and len(out) >= limit:
                        break
        except OSError as exc:
            log.warning(
                "Failed to read instance artifact",
                instance=instance_id,
                file=filename,
                error=str(exc),
            )
        return out


class _suppress:
    """Tiny contextlib.suppress stand-in to avoid an import for one use."""

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return True
