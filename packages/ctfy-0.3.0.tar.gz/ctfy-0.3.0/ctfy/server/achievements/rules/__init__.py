"""Rule modules — importing this package registers every predicate.

Add a new rule by creating a module here and using the
``@register(PlatformEvent.X)`` decorator from
:mod:`ctfy.server.achievements.engine`. Then import the module in the
list below so it runs at app startup.
"""

from __future__ import annotations

# Import each rule module so their @register(...) decorators fire.
# Re-exporting via ``as`` + ``__all__`` keeps the names as genuine
# public API of the package, so linters treat them as used.
from ctfy.server.achievements.rules import (
    flag_correct_rules as flag_correct_rules,
)
from ctfy.server.achievements.rules import (
    flag_wrong_rules as flag_wrong_rules,
)
from ctfy.server.achievements.rules import (
    team_registered_rules as team_registered_rules,
)

__all__ = [
    "flag_correct_rules",
    "flag_wrong_rules",
    "team_registered_rules",
]
