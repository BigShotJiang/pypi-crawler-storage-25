"""GitHub-side verification for the Star Gazer achievement.

Server-side check that a user actually starred the project's GitHub
repo before we grant the badge. The whole reason this exists is that
honor-system "I starred it" buttons get cheated immediately on a CTF
platform.

We rely entirely on **public** GitHub API endpoints, so no OAuth scope
expansion or access-token persistence is required:

* :func:`verify_star` lists a user's stars via
  ``GET /users/{login}/starred`` and looks for the project repo.
  GitHub's default ordering is "most recently starred first", so a
  player who just clicked the star on github.com finds their star at
  the top of page 1. We page only twice (≤200 stars) before declaring
  ``NotStarred`` — anyone with that many *recent* stars can re-star
  and retry.
* :func:`resolve_login` is the fallback for old ``OAuthIdentity`` rows
  that predate the ``provider_login`` column. One unauthenticated call
  to ``GET /user/{id}`` returns the login so the verification can
  proceed; the caller persists the value back to the row.

A small in-memory LRU TTL cache absorbs duplicate clicks (or the
inevitable flurry of player presses) so we don't burn the GitHub rate
limit on a single team. Anonymous calls are limited to 60/hour by IP;
setting ``CTFY_GITHUB_API_TOKEN`` raises that to 5000/hour with a
read-only PAT.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from enum import Enum
from threading import Lock
from typing import Any

import httpx

from ctfy.core.log import log

# How long to remember a verification result. Long enough to soak up
# rapid re-clicks; short enough that someone who actually stars after
# a NotStarred gets a quick retry path.
_CACHE_TTL_SECONDS = 600.0

# Max entries in the verification cache. Bound the memory footprint so
# that an attacker can't bloat the process by burning random logins.
_CACHE_MAX_ENTRIES = 1024

# Max pages to walk on /users/{login}/starred. GitHub returns the
# newest stars first, so a freshly-added star is on page 1 in any
# realistic scenario; page 2 is a defensive cushion for users who
# rapid-fire stars after ours.
_MAX_PAGES = 2

# Per-page limit GitHub allows. Using the maximum minimises the number
# of round-trips we make.
_PER_PAGE = 100

_GITHUB_API = "https://api.github.com"
_GITHUB_ACCEPT = "application/vnd.github+json"
_HTTP_TIMEOUT = httpx.Timeout(10.0, connect=5.0)


class StarVerifyResult(str, Enum):
    """Outcome of :func:`verify_star`.

    Stringly-typed so the route handler can return the value as
    ``reason`` to the client without an extra mapping table.
    """

    STARRED = "starred"
    NOT_STARRED = "not_starred"
    # We hit our own page cap — the user has many stars but we
    # didn't find ours in the first ``_MAX_PAGES`` pages. The UI tells
    # them to re-star to bump it back to the top.
    LIMIT_EXCEEDED = "limit_exceeded"
    # GitHub returned 403 with rate-limit headers, or our pre-flight
    # check saw zero remaining requests.
    RATE_LIMITED = "rate_limited"
    # 404 on the login lookup (user renamed/deleted) or any other
    # unexpected non-2xx from GitHub. The badge stays unawarded.
    LOOKUP_FAILED = "lookup_failed"


@dataclass(frozen=True)
class _CacheEntry:
    result: StarVerifyResult
    expires_at: float


class _TtlCache:
    """Tiny thread-safe TTL cache. Avoids pulling in cachetools just for this."""

    def __init__(self, *, max_entries: int, ttl_seconds: float) -> None:
        self._max = max_entries
        self._ttl = ttl_seconds
        self._lock = Lock()
        self._store: dict[tuple[str, str, str], _CacheEntry] = {}

    def get(self, key: tuple[str, str, str]) -> StarVerifyResult | None:
        now = time.monotonic()
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            if entry.expires_at <= now:
                self._store.pop(key, None)
                return None
            return entry.result

    def put(self, key: tuple[str, str, str], result: StarVerifyResult) -> None:
        with self._lock:
            if len(self._store) >= self._max:
                # Drop the oldest entry — dicts preserve insertion
                # order, so popping the first item is FIFO eviction.
                # Good enough for a cap that exists only as a
                # memory-bound, not for a hit-rate optimisation.
                oldest = next(iter(self._store))
                self._store.pop(oldest, None)
            self._store[key] = _CacheEntry(
                result=result,
                expires_at=time.monotonic() + self._ttl,
            )

    def invalidate(self, key: tuple[str, str, str]) -> None:
        with self._lock:
            self._store.pop(key, None)


_verify_cache = _TtlCache(
    max_entries=_CACHE_MAX_ENTRIES, ttl_seconds=_CACHE_TTL_SECONDS
)


def _auth_headers(github_pat: str) -> dict[str, str]:
    headers = {"Accept": _GITHUB_ACCEPT, "User-Agent": "ctfy-platform"}
    if github_pat:
        headers["Authorization"] = f"Bearer {github_pat}"
    return headers


def _matches(repo_payload: dict[str, Any], owner: str, repo: str) -> bool:
    """Match a /starred row against ``owner/repo``, case-insensitively.

    GitHub's ``full_name`` is the most reliable field — it's always
    ``owner/name`` and is preserved through repo renames as the new
    canonical pair (the stars endpoint always reflects the current
    name). Fall back to ``owner.login`` + ``name`` if ``full_name`` is
    missing in some envelope variant we haven't seen.
    """
    full = (repo_payload.get("full_name") or "").lower()
    target = f"{owner.lower()}/{repo.lower()}"
    if full == target:
        return True
    fallback_owner = (
        (repo_payload.get("owner") or {}).get("login")
        if isinstance(repo_payload.get("owner"), dict)
        else None
    )
    fallback_name = repo_payload.get("name")
    if fallback_owner and fallback_name:
        return f"{fallback_owner.lower()}/{fallback_name.lower()}" == target
    return False


async def verify_star(
    login: str, owner: str, repo: str, *, github_pat: str = ""
) -> StarVerifyResult:
    """Return whether GitHub user ``login`` has starred ``owner/repo``.

    Uses :func:`httpx.AsyncClient`. The result is cached per
    ``(login, owner, repo)`` for ``_CACHE_TTL_SECONDS`` so duplicate
    clicks don't burn rate-limit budget. ``github_pat`` is optional —
    when provided it raises the rate-limit ceiling to 5000/hour.
    """
    if not login or not owner or not repo:
        return StarVerifyResult.LOOKUP_FAILED

    key = (login.lower(), owner.lower(), repo.lower())
    cached = _verify_cache.get(key)
    if cached is not None:
        return cached

    headers = _auth_headers(github_pat)
    try:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            for page in range(1, _MAX_PAGES + 1):
                resp = await client.get(
                    f"{_GITHUB_API}/users/{login}/starred",
                    params={
                        "per_page": _PER_PAGE,
                        "page": page,
                        "sort": "created",
                        "direction": "desc",
                    },
                    headers=headers,
                )
                if resp.status_code == 404:
                    result = StarVerifyResult.LOOKUP_FAILED
                    _verify_cache.put(key, result)
                    return result
                if resp.status_code == 403 and resp.headers.get(
                    "X-RateLimit-Remaining"
                ) == "0":
                    # Don't cache rate-limit results — the next call
                    # after the window resets should retry, not refuse.
                    return StarVerifyResult.RATE_LIMITED
                if resp.status_code >= 400:
                    log.warning(
                        "GitHub starred lookup failed",
                        login=login,
                        page=page,
                        status=resp.status_code,
                        body=resp.text[:200],
                    )
                    return StarVerifyResult.LOOKUP_FAILED
                rows = resp.json()
                if not isinstance(rows, list):
                    return StarVerifyResult.LOOKUP_FAILED
                for row in rows:
                    if isinstance(row, dict) and _matches(row, owner, repo):
                        _verify_cache.put(key, StarVerifyResult.STARRED)
                        return StarVerifyResult.STARRED
                if len(rows) < _PER_PAGE:
                    # Last page — the user simply hasn't starred us.
                    _verify_cache.put(key, StarVerifyResult.NOT_STARRED)
                    return StarVerifyResult.NOT_STARRED
    except httpx.HTTPError:
        log.exception("GitHub starred lookup raised", login=login)
        return StarVerifyResult.LOOKUP_FAILED

    # Walked _MAX_PAGES without finding our repo and without GitHub
    # signalling end-of-list — the user has many stars further back.
    # Cache as NotStarred-equivalent so a second click within the TTL
    # doesn't redo the same fruitless pagination.
    _verify_cache.put(key, StarVerifyResult.LIMIT_EXCEEDED)
    return StarVerifyResult.LIMIT_EXCEEDED


async def resolve_login(provider_user_id: str, *, github_pat: str = "") -> str | None:
    """Look up a GitHub login by numeric id.

    Used for backfill: identities created before ``provider_login`` was
    added carry only the numeric id. We hit ``GET /user/{id}`` once per
    such identity. Returns ``None`` on any failure so the caller can
    surface ``lookup_failed`` to the user.
    """
    if not provider_user_id:
        return None
    headers = _auth_headers(github_pat)
    try:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            resp = await client.get(
                f"{_GITHUB_API}/user/{provider_user_id}", headers=headers
            )
        if resp.status_code != 200:
            log.warning(
                "GitHub login resolve failed",
                provider_user_id=provider_user_id,
                status=resp.status_code,
                body=resp.text[:200],
            )
            return None
        body = resp.json()
        login = body.get("login") if isinstance(body, dict) else None
        return login or None
    except httpx.HTTPError:
        log.exception("GitHub login resolve raised", provider_user_id=provider_user_id)
        return None


def parse_owner_repo(repo_url: str) -> tuple[str, str] | None:
    """Extract ``(owner, repo)`` from a GitHub repository URL.

    Tolerates the common shapes — ``https://github.com/foo/bar``,
    ``https://github.com/foo/bar/``, ``https://github.com/foo/bar.git``
    — and returns ``None`` for anything that isn't a github.com repo
    URL with two non-empty path segments.
    """
    if not repo_url:
        return None
    try:
        from urllib.parse import urlparse

        parsed = urlparse(repo_url)
    except Exception:
        return None
    host = (parsed.hostname or "").lower()
    if host not in ("github.com", "www.github.com"):
        return None
    parts = [p for p in parsed.path.split("/") if p]
    if len(parts) < 2:
        return None
    owner = parts[0]
    repo = parts[1]
    if repo.endswith(".git"):
        repo = repo[: -len(".git")]
    if not owner or not repo:
        return None
    return owner, repo


def _clear_cache_for_tests() -> None:
    """Test hook — wipes the in-memory cache between unit tests."""
    with _verify_cache._lock:  # noqa: SLF001 — test-only access
        _verify_cache._store.clear()  # noqa: SLF001
