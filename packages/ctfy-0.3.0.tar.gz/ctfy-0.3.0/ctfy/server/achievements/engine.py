"""Evaluator registry + dispatcher.

Flow:

1. Rules self-register via :func:`register(event)` at import time.
2. :func:`evaluate` is called from inside :func:`ctfy.server.events.emit_event`
   (on the background thread pool so SQLite I/O here can't slow a
   submission response).
3. Each registered predicate inspects the payload + team state and
   returns either ``None`` (not qualifying) or a
   ``RuleResult(achievement_id, context)``.
4. :func:`grant_achievement` is idempotent — a second identical event
   is a no-op — so the downstream SSE + activity emit only fires on
   true unlocks.

Rule errors are logged and swallowed. An individual predicate must
never be able to break flag submission.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ctfy.core.enums import PlatformEvent
from ctfy.core.log import log
from ctfy.core.state.models import TeamState

if TYPE_CHECKING:
    from ctfy.server.app_state import AppState
    from ctfy.server.event_payloads import EventPayload


@dataclass(frozen=True)
class RuleResult:
    """Returned by a rule predicate when a team qualifies for a badge."""

    achievement_id: str
    context: dict[str, Any] | None = None


# A rule takes (app, payload, team) and returns either a RuleResult or None.
Rule = Callable[["AppState", "EventPayload", TeamState], "RuleResult | None"]

# A progress provider takes (app, team) and returns ``(current, target)``
# for a single achievement, or ``None`` if progress isn't meaningful
# (time-of-day badges, first-blood, etc.). Decoupled from ``Rule`` so
# the readout doesn't have to wait for an event to fire.
ProgressFn = Callable[["AppState", TeamState], "tuple[int, int] | None"]


_RULES: dict[PlatformEvent, list[Rule]] = {}
_PROGRESS: dict[str, ProgressFn] = {}


def register(event: PlatformEvent) -> Callable[[Rule], Rule]:
    """Register a predicate against one ``PlatformEvent``.

    Multiple rules may listen to the same event. A rule may also be
    registered on several events by stacking decorators.
    """

    def decorator(fn: Rule) -> Rule:
        _RULES.setdefault(event, []).append(fn)
        return fn

    return decorator


def _emit_unlocked(
    app: "AppState",
    team: TeamState,
    achievement_id: str,
    *,
    actor_user_id: str = "",
    actor_user_name: str = "",
) -> None:
    """Broadcast the ACHIEVEMENT_UNLOCKED event through the normal pipeline.

    ``actor_user_id`` / ``actor_user_name`` identify the human whose
    action triggered the unlock (or ran the admin route that granted
    it). The fields are threaded through so the achievement event
    surfaces in the user's user-scoped ``/activities`` feed via the
    standard ``actor_id`` filter — without them the row would be
    stamped with team_id and miss the user's history.
    """
    # Local import — events.py imports from this module's sibling (rules),
    # so keep this import inside the function to break the cycle.
    from ctfy.server.achievements.catalog import get as get_achievement
    from ctfy.server.event_payloads import AchievementUnlockedPayload
    from ctfy.server.events import emit_event

    ach = get_achievement(achievement_id)
    if ach is None:
        log.warning(
            "Unknown achievement id granted; not broadcasting",
            achievement_id=achievement_id,
            team_id=team.team_id,
        )
        return

    actor_id = actor_user_id or team.team_id
    actor_name = actor_user_name or team.name or team.team_id
    emit_event(
        app,
        AchievementUnlockedPayload(
            team_id=team.team_id,
            team_name=team.name,
            achievement_id=ach.id,
            achievement_name=ach.name,
            tier=ach.tier,
            secret=ach.secret,
        ),
        actor_id=actor_id,
        actor_name=actor_name,
        actor_type="team",
    )


def evaluate(
    app: "AppState",
    event: PlatformEvent,
    payload: "EventPayload",
    *,
    actor_type: str,
    actor_team_id: str,
    actor_user_id: str = "",
    actor_user_name: str = "",
) -> None:
    """Run every rule registered for ``event``; grant + broadcast unlocks.

    Only team-driven events are evaluated — system / admin / node events
    don't have a team to credit. Admin-granted badges go through the
    dedicated admin route, not this dispatcher.

    ``actor_user_id`` / ``actor_user_name`` are threaded through to the
    ACHIEVEMENT_UNLOCKED emit so the row lands in the user's
    user-scoped ``/activities`` feed.
    """
    if actor_type != "team" or not actor_team_id:
        return
    team = app.state_backend.get_team(actor_team_id)
    if not team:
        return

    for rule in _RULES.get(event, ()):
        try:
            result = rule(app, payload, team)
        except Exception:
            log.exception(
                "Achievement rule raised",
                trigger_event=event.value,
                rule=getattr(rule, "__qualname__", repr(rule)),
                team_id=team.team_id,
            )
            continue
        if result is None:
            continue
        record = app.state_backend.grant_achievement(
            team.team_id, result.achievement_id, result.context
        )
        if record is None:
            # Already unlocked — silently skip to stay idempotent.
            continue
        _emit_unlocked(
            app,
            team,
            result.achievement_id,
            actor_user_id=actor_user_id,
            actor_user_name=actor_user_name,
        )


def evaluator_count(event: PlatformEvent) -> int:
    """Test helper — how many predicates are listening to ``event``."""
    return len(_RULES.get(event, ()))


def maybe_grant_combo(
    app: "AppState",
    team: TeamState,
    *,
    required: tuple[str, ...],
    grant_id: str,
    actor_user_id: str = "",
    actor_user_name: str = "",
) -> bool:
    """Grant ``grant_id`` if the team already holds every id in ``required``.

    Used for combo / cumulative achievements that depend on more than
    one event (e.g. ``ambassador`` = ``star_gazer`` + ``linked_github``).
    Returns ``True`` only on the call that actually unlocked the combo
    so the caller can chain a follow-up emit if needed. Idempotent —
    repeat calls after the unlock are no-ops.

    ``actor_user_id`` / ``actor_user_name`` identify the human whose
    action triggered the combo so the activity row surfaces in their
    feed.
    """
    earned = {
        row.achievement_id
        for row in app.state_backend.list_achievements(team.team_id)
    }
    if not set(required).issubset(earned):
        return False
    if grant_id in earned:
        return False
    record = app.state_backend.grant_achievement(
        team.team_id,
        grant_id,
        context={"source": "combo", "required": list(required)},
    )
    if record is None:
        return False
    _emit_unlocked(
        app,
        team,
        grant_id,
        actor_user_id=actor_user_id,
        actor_user_name=actor_user_name,
    )
    return True


def register_progress(achievement_id: str) -> Callable[[ProgressFn], ProgressFn]:
    """Register a (current, target) provider for one achievement.

    Re-registering the same id replaces the existing provider, which
    keeps dev reloads + tests honest. Multiple decorators on the same
    function for different ids is fine — each call is independent.
    """

    def decorator(fn: ProgressFn) -> ProgressFn:
        _PROGRESS[achievement_id] = fn
        return fn

    return decorator


def compute_progress(
    app: "AppState",
    team: TeamState,
    achievement_id: str,
) -> "tuple[int, int] | None":
    """Look up + invoke the progress provider for one achievement.

    Returns ``None`` when no provider is registered (typical for
    time-of-day / first-blood / easter-egg badges where a fractional
    progress value doesn't make sense) and also when the provider
    raises — buggy progress code must not break the route that calls
    it, the catalog page would otherwise 500 every render.
    """
    fn = _PROGRESS.get(achievement_id)
    if fn is None:
        return None
    try:
        return fn(app, team)
    except Exception:
        log.exception(
            "Achievement progress provider raised",
            achievement_id=achievement_id,
            team_id=team.team_id,
        )
        return None
