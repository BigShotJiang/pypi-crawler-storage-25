"""Pcap file merging.

The proxy-sidecar architecture writes one pcap per challenge container
(``<output>/pcap/<container>.pcap``) plus mitmproxy's own
``<output>/traffic/raw.pcap``. To hand admins one Wireshark-readable
file we concatenate them in capture-order (file-by-file) by reusing
the first file's 24-byte global header and stripping the same header
off each subsequent file's body.

This is correct as long as every file has identical link-type and
snaplen, which they do when produced by ``tcpdump -i any`` on the
same kernel — Linux cooked v2 (LINKTYPE_LINUX_SLL2) for the netns
sidecars, and whichever interface the mitmproxy container's
``tcpdump`` was bound to. We sanity-check the global header so a
mismatch falls back to "return the largest file as-is" rather than
emitting a corrupt pcap that Wireshark refuses to open.
"""

from __future__ import annotations

import struct
from pathlib import Path

# pcap (libpcap) global header is 24 bytes. The first 4 are a magic
# number that doubles as a byte-order indicator; we only check that the
# first 16 bytes (magic+version+thiszone+sigfigs) match across files,
# because snaplen and linktype can legitimately differ between files
# captured from different interfaces.
_PCAP_HEADER_LEN = 24
_PCAP_MAGICS = (
    b"\xd4\xc3\xb2\xa1",  # microsecond, little-endian
    b"\xa1\xb2\xc3\xd4",  # microsecond, big-endian
    b"\x4d\x3c\xb2\xa1",  # nanosecond, little-endian
    b"\xa1\xb2\x3c\x4d",  # nanosecond, big-endian
)


def _has_pcap_magic(data: bytes) -> bool:
    return len(data) >= 4 and data[:4] in _PCAP_MAGICS


def merge_pcaps(paths: list[Path]) -> bytes:
    """Concatenate *paths* into a single pcap byte string.

    Empty / missing / header-only files are skipped silently. When
    files differ in link-type, the merger preserves only those that
    match the first file's link-type to keep Wireshark happy; the rest
    are dropped (logged by the caller, not here, to keep the helper
    pure).
    """
    files = [p for p in paths if p.is_file() and p.stat().st_size >= _PCAP_HEADER_LEN]
    if not files:
        return b""

    # Read the first usable header to anchor the output.
    first = files[0].read_bytes()
    if not _has_pcap_magic(first):
        # Nothing we can merge against — return the largest file
        # untouched and let the caller decide what to do.
        biggest = max(files, key=lambda p: p.stat().st_size)
        return biggest.read_bytes()

    header = first[:_PCAP_HEADER_LEN]
    # The linktype lives at offset 20..24. Endian matches the magic at
    # offset 0..4 so we read it accordingly.
    endian = "<" if header[0] == 0xD4 or header[0] == 0x4D else ">"
    linktype_first = struct.unpack(f"{endian}I", header[20:24])[0]

    out = bytearray(header)
    out.extend(first[_PCAP_HEADER_LEN:])
    for p in files[1:]:
        data = p.read_bytes()
        if not _has_pcap_magic(data):
            continue
        # Linktype must match for the records to be parseable under
        # the chosen header. Different interfaces (e.g. eth0 raw vs
        # ``any`` cooked) yield different linktypes; merging across
        # that line produces a file Wireshark renders as gibberish.
        endian_this = "<" if data[0] == 0xD4 or data[0] == 0x4D else ">"
        linktype_this = struct.unpack(f"{endian_this}I", data[20:24])[0]
        if linktype_this != linktype_first:
            continue
        out.extend(data[_PCAP_HEADER_LEN:])
    return bytes(out)
