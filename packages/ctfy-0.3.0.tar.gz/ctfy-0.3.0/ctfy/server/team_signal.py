"""Push admin-targeted SSE frames covering team-state changes that
admin pages need to react to in real time.

Today this is just ``team_deleted`` — emitted after the cascading
``DELETE /me`` finishes so the admin Overview / AdminTeams pages can
drop the team's row from the rendered list without a refetch.
:func:`ctfy.server.meta_stats.emit_meta_stats` is invoked alongside
to keep the cluster ``teams_total`` chip in sync (the StatusBar
listens for the same frame).

Like the other ``*_signal.py`` modules, this is a synthetic UI
signal: not an :class:`~ctfy.server.event_payloads.EventPayload`, no
activity log row, no team / actor envelope. Goes straight through
:meth:`SSEHub.broadcast` admin-only.
"""

from __future__ import annotations

from ctfy.core.enums import PlatformEvent
from ctfy.server.app_state import AppState

__all__ = ["emit_team_deleted", "emit_team_profile_updated"]


def emit_team_profile_updated(
    app: AppState, *, team_id: str, team_name: str
) -> None:
    """Broadcast ``team_profile_updated`` globally (no admin gate).

    Anyone watching /teams/{team_id} — owner's own Settings tab,
    other teams browsing the public profile, admin AdminTeams — can
    refetch on receipt. Carries ``team_id`` so consumers filter
    client-side instead of fanning out one SSE topic per team.
    """
    app.sse_hub.broadcast(
        PlatformEvent.TEAM_PROFILE_UPDATED.value,
        team_id="",
        data={"team_id": team_id, "team_name": team_name},
    )


def emit_team_deleted(app: AppState, *, team_id: str, team_name: str) -> None:
    """Broadcast ``team_deleted`` admin_only=True with the deleted
    team's id + name. Refresh the admin counters too so a stale
    ``teams_total`` chip can't outlive the row that disappeared.
    """
    app.sse_hub.broadcast(
        PlatformEvent.TEAM_DELETED.value,
        team_id="",
        data={"team_id": team_id, "team_name": team_name},
        admin_only=True,
    )
    # Local import: meta_stats imports from app_state which we already
    # depend on, but keeping it lazy keeps the module import graph
    # slim for callers who only want the team_deleted frame.
    from ctfy.server.meta_stats import emit_meta_stats

    emit_meta_stats(app)
