"""Bucket math shared by the three timeseries routes.

Three routes (``/admin/timeseries``, ``/admin/challenges/{id}/timeseries``,
``/activities/timeseries``) all do the same thing: take a window length, a
bucket size, and a list of timestamps, and return per-bucket counts oldest-
first. The bucketing logic lives here so all three agree on the same edge
semantics.

Right-edge anchored at ``now``, never snapped to clock-aligned boundaries.
The "Last N seconds" charts now actually end at the moment of the request,
which is what users expect when they read the title — and what tests need
when they want deterministic placement of timestamped fixtures.

A timestamp ``ts`` lands in the bucket with right edge ``e`` iff
``e - bucket < ts <= e`` — half-open on the left so a timestamp exactly
on a bucket boundary belongs to the older bucket, not both.
"""

from __future__ import annotations

__all__ = ["bucket_edges", "bucketize"]


def bucket_edges(*, now: float, window: int, bucket: int) -> list[float]:
    """Return the right edges of N evenly-sized buckets ending at ``now``.

    Oldest-first. The rightmost edge equals ``now`` exactly — no snap-up
    to clock-aligned boundaries (we found the "snap" pattern caused the
    rightmost bucket to extend into the future and dropped recent data
    on the floor whenever ``now mod bucket`` was small).

    ``window // bucket`` is clamped to at least 1 so a misconfigured
    request (e.g. ``window=60, bucket=3600``) still returns something
    renderable instead of an empty array.
    """
    if bucket <= 0:
        raise ValueError("bucket must be positive")
    n = max(1, window // bucket)
    return [float(now) - (n - 1 - i) * bucket for i in range(n)]


def bucketize(
    timestamps: list[float], right_edges: list[float], *, bucket: int
) -> list[int]:
    """Count how many ``timestamps`` fall into each bucket.

    Returns a counts list aligned with ``right_edges`` (oldest-first).
    Stamps outside the window — i.e. ``ts <= right_edges[0] - bucket``
    or ``ts > right_edges[-1]`` — are silently dropped.
    """
    counts = [0] * len(right_edges)
    if not right_edges:
        return counts
    start = right_edges[0] - bucket
    last = right_edges[-1]
    for ts in timestamps:
        if ts <= start or ts > last:
            continue
        idx = int((ts - start - 1) // bucket)
        if 0 <= idx < len(counts):
            counts[idx] += 1
    return counts
