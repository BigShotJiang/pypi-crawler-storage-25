"""Password hashing helpers (Argon2id via argon2-cffi).

Thin wrapper over :class:`argon2.PasswordHasher` so the rest of the code
base never touches the library directly. Uses the library's default
parameters (Argon2id, OWASP-recommended m/t/p); the hash encodes the
parameters in-band, so we can bump them later and
:func:`needs_rehash` will ask the verify path to transparently
re-hash on next successful login.

Reference: https://argon2-cffi.readthedocs.io/
"""

from __future__ import annotations

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerifyMismatchError
from fastapi import HTTPException

_HASHER = PasswordHasher()

# Pre-computed hash over a throwaway password. Used by login-miss paths
# so attackers can't time-distinguish "unknown email" from "wrong
# password" via whether the verify step ran.
_DUMMY_HASH = _HASHER.hash("ctfy-login-miss-dummy-never-valid")

# Minimum password length, in characters. argon2id makes offline brute force
# expensive but the in-line login limiter (audit #2) still permits a
# user-targeted dictionary attack at ~10/min, so reject obvious choices
# outright. 12 is the OWASP / NIST 800-63B recommendation.
MIN_PASSWORD_LENGTH = 12

# Top-N most common passwords (sourced from public breach corpora). Anything
# in this list is rejected even if it satisfies the length minimum, because
# it will be the first thing an attacker tries. List kept short on purpose;
# a heavier check (zxcvbn) would pull a third-party dep we don't otherwise
# need. Lower-cased for case-insensitive matching.
_COMMON_PASSWORDS = frozenset({
    "123456789012",
    "password1234",
    "qwerty123456",
    "111111111111",
    "passwordpassword",
    "letmeinletmein",
    "admin1234admin",
    "welcome12345",
    "iloveyou1234",
    "monkey123456",
    "dragon123456",
    "sunshine1234",
    "princess1234",
    "football1234",
    "baseball1234",
    "abc123abc123",
    "trustno1trust",
    "p@ssw0rdp@ss",
    "p@ssword1234",
    "ctfyctfyctfy",
})


def validate_password_strength(plaintext: str) -> None:
    """Reject passwords below our minimum bar.

    Raises ``HTTPException(422)`` with a human-readable message; FastAPI
    surfaces that as the response body to the registration / change-password
    handler. Length is checked before the dictionary lookup so attackers
    cannot probe the dictionary contents via a 422 oracle.
    """
    if len(plaintext) < MIN_PASSWORD_LENGTH:
        raise HTTPException(
            422,
            f"Password must be at least {MIN_PASSWORD_LENGTH} characters.",
        )
    if plaintext.lower() in _COMMON_PASSWORDS:
        raise HTTPException(
            422,
            "Password appears in a common-password list. Pick something less guessable.",
        )


def hash_password(plaintext: str) -> str:
    """Return an Argon2id PHC-format hash of ``plaintext``."""
    return _HASHER.hash(plaintext)


def verify_password(hashed: str, plaintext: str) -> bool:
    """True iff ``plaintext`` matches ``hashed``. Never raises on mismatch."""
    try:
        return _HASHER.verify(hashed, plaintext)
    except (VerifyMismatchError, InvalidHashError):
        return False


def needs_rehash(hashed: str) -> bool:
    """True when ``hashed`` was produced with older (weaker) parameters.

    Callers should re-hash on next successful login to migrate rows
    in-place without forcing a password reset.
    """
    try:
        return _HASHER.check_needs_rehash(hashed)
    except InvalidHashError:
        return False


def run_dummy_verify(plaintext: str) -> None:
    """Run verify against a throwaway hash to equalise login-miss timing."""
    try:
        _HASHER.verify(_DUMMY_HASH, plaintext)
    except (VerifyMismatchError, InvalidHashError):
        pass
