"""Push per-node heartbeat samples to admin SSE clients.

The admin ``NodeStatusStrip`` used to poll
``/admin/nodes/{id}/health-history`` every 30 s to keep its uptime-kuma
strip fresh. The poll is wasteful: every node already calls the
``/heartbeat`` endpoint on a tighter cadence than 30 s, and the
reconciler synthesises an unhealthy sample the moment a heartbeat
ages past :data:`HEARTBEAT_TIMEOUT`. Both write paths now broadcast a
``node_status`` SSE frame carrying the new
:class:`~ctfy.core.state.models.NodeHealthSample` so the strip can
append directly without a refetch.

Like :mod:`ctfy.server.meta_stats` this is a synthetic UI signal:
broadcast ``admin_only=True`` because cluster-load telemetry is not a
member-visible signal, no activity-log row, no team / actor envelope.
"""

from __future__ import annotations

from ctfy.core.enums import PlatformEvent
from ctfy.core.state.models import NodeHealthSample
from ctfy.server.app_state import AppState

__all__ = ["emit_node_status"]


def emit_node_status(app: AppState, sample: NodeHealthSample) -> None:
    """Broadcast a single heartbeat sample to admin SSE subscribers.

    The frame's wire shape matches ``NodeHealthSample.model_dump()`` —
    same keys the admin REST endpoint already returns — so the
    frontend can reuse its existing ``NodeHealthSample`` type without
    a parallel SSE-only schema.
    """
    app.sse_hub.broadcast(
        PlatformEvent.NODE_STATUS.value,
        team_id="",
        data=sample.model_dump(),
        admin_only=True,
    )
