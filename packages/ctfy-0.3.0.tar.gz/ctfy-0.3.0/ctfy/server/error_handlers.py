"""Unified exception-to-response mapping for platform errors.

Every 4xx / 5xx body the API emits is shaped as
:class:`ctfy.server.models.ErrorResponse` — ``{code, detail, timestamp}``.
Three sources feed the envelope:

* :class:`PlatformError` subclasses, mapped to a status code in
  :func:`register_platform_error_handlers` (called once at app build).
  ``code`` is derived from the class name
  (``InstanceNotFoundError`` → ``"instance_not_found"``).
* :func:`raise_error` for ad-hoc 4xx in routes that need a richer code
  than ``"http_400"`` without inventing a whole exception class.
* Plain :class:`HTTPException` from routes that pre-date this module —
  the global handler in :func:`register_http_exception_handler` wraps
  the detail into an envelope with code ``"http_<status>"``. A ``dict``
  detail (e.g. ``{"error": "not_registered", "competition_id": ...}``)
  passes through verbatim under ``detail`` so the existing structured
  payloads keep their shape.
"""

from __future__ import annotations

import re
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

from ctfy.core.exceptions import PlatformError
from ctfy.server.app_state import now_iso

__all__ = [
    "APIError",
    "exception_code",
    "raise_error",
    "register_http_exception_handler",
    "register_platform_error_handlers",
]

# CamelCase → snake_case: insert "_" before each uppercase letter that
# follows a lowercase letter or digit. Strips a trailing ``_error`` so
# ``InstanceNotFoundError`` becomes ``instance_not_found`` (shorter and
# matches how client code tends to write these codes).
_CAMEL_BOUNDARY = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")


def exception_code(exc: BaseException) -> str:
    """Derive the ``ErrorResponse.code`` for *exc*.

    Example: ``InstanceNotFoundError`` → ``"instance_not_found"``.
    """
    name = exc.__class__.__name__
    snake = _CAMEL_BOUNDARY.sub("_", name).lower()
    return snake.removesuffix("_error")


class APIError(HTTPException):
    """``HTTPException`` carrying a stable ``code`` for the envelope.

    Use :func:`raise_error` instead of constructing one directly — the
    helper keeps call sites short and the kwargs disciplined.
    """

    def __init__(self, status_code: int, code: str, detail: Any = "") -> None:
        super().__init__(status_code=status_code, detail=detail)
        self.code = code


def raise_error(status: int, code: str, detail: Any = "") -> None:
    """Raise an :class:`APIError` — the preferred shape for new code.

    ``code`` should be a stable snake-case identifier the frontend
    branches on (``"not_registered"``, ``"wrong_invite_kind"``, …).
    ``detail`` is the human message; pass a dict only when the route
    needs to attach structured context (kept for back-compat; new code
    should prefer a flat string).
    """
    raise APIError(status_code=status, code=code, detail=detail)


def _envelope(status: int, code: str, detail: Any) -> JSONResponse:
    """Pack ``(status, code, detail)`` into the unified response shape.

    ``detail`` keeps whatever form the route raised — string or dict —
    so structured payloads like ``{"error": "not_registered", ...}``
    survive verbatim. The envelope's job is only to *add* the
    machine-readable ``code`` and a UTC timestamp.
    """
    payload: dict[str, Any] = {
        "code": code,
        "detail": detail if isinstance(detail, dict) else str(detail),
        "timestamp": now_iso(),
    }
    return JSONResponse(status_code=status, content=payload)


def _handler_for(status: int):
    async def _handle(_request, exc):
        return _envelope(status, exception_code(exc), str(exc))

    return _handle


def register_platform_error_handlers(app: FastAPI, mapping: dict[type[PlatformError], int]) -> None:
    """Register an ``ErrorResponse``-emitting handler for each ``PlatformError``
    subclass in *mapping*.
    """
    for exc_cls, status in mapping.items():
        app.add_exception_handler(exc_cls, _handler_for(status))


async def _handle_http_exception(_request, exc: HTTPException) -> JSONResponse:
    code = getattr(exc, "code", None) or f"http_{exc.status_code}"
    return _envelope(exc.status_code, code, exc.detail)


def register_http_exception_handler(app: FastAPI) -> None:
    """Wrap ``HTTPException`` (and :class:`APIError`) into ``ErrorResponse``.

    Routes that still raise ``HTTPException(status, detail=...)`` get a
    unified envelope without per-route changes. New code should prefer
    :func:`raise_error` so the ``code`` field is meaningful instead of
    a fallback ``"http_400"``.
    """
    app.add_exception_handler(HTTPException, _handle_http_exception)
