"""Push a ``scoreboard_updated`` SSE frame so the public Scoreboard
page can refetch in lockstep with rank-affecting writes.

The Scoreboard used to subscribe directly to ``flag_correct`` and
refetch on every flag claim. That's tightly coupled — adding
admin-grants, retroactive marks, or any other write that should
update the ranking would require touching the page. This module
publishes a higher-level signal: the consumer just watches
``scoreboard_updated``, and any new write path opts in by emitting
the same frame.

Not :class:`~ctfy.server.event_payloads.EventPayload`: there's no
team / actor envelope and no activity-log row. The frame goes
straight through :meth:`SSEHub.broadcast` like
:mod:`ctfy.server.meta_stats` and :mod:`ctfy.server.node_status`.
"""

from __future__ import annotations

from ctfy.core.enums import PlatformEvent
from ctfy.server.app_state import AppState

__all__ = ["emit_scoreboard_updated", "SCOREBOARD_AFFECTING_EVENTS"]


#: Events whose write paths change a team's visible scoreboard rank.
#:
#: Today this is just full FLAG_CORRECT — the SDK records a Solve row
#: in :func:`ctfy.server.routes.submissions.submit_flag` immediately
#: before emitting the event, so by the time we broadcast a derivative
#: ``scoreboard_updated`` frame the next ``compute_scoreboard`` call
#: will already see the new solve. Partial flags don't change the
#: ranking until the challenge is fully solved (the Solve row only
#: lands then), so emitting on every flag_correct is a tiny over-emit
#: with the same eventual consistency.
#:
#: ``FLAG_PART_CORRECT`` / ``FLAG_WRONG`` are deliberately out — the
#: ranking doesn't move on those.
SCOREBOARD_AFFECTING_EVENTS: frozenset[str] = frozenset({
    PlatformEvent.FLAG_CORRECT.value,
})


def emit_scoreboard_updated(app: AppState) -> None:
    """Broadcast the public ``scoreboard_updated`` SSE frame.

    No payload — the consumer always refetches ``/scoreboard`` so an
    idempotent "something changed" hint is the cheapest contract.
    Sent ``team_id=""`` (no team filter) and the default
    ``admin_only=False`` so every connected client refreshes.
    """
    app.sse_hub.broadcast(
        PlatformEvent.SCOREBOARD_UPDATED.value,
        team_id="",
        data={},
    )
