"""Out-of-the-box bootstrap helpers.

Right now: the practice-competition seed. A fresh deployment ships
with a challenge directory but no competitions. Without one, players
register-for-nothing and the per-comp routes 404 across the board.
:func:`bootstrap_practice_competition` mints a single permanent
competition containing every known challenge so the platform is
playable straight after install.
"""

from __future__ import annotations

import time
from typing import Protocol

from ctfy.core.log import log
from ctfy.core.state import StateBackend
from ctfy.core.state.models import CompetitionState

#: Stable id for the auto-bootstrapped practice competition. Stable
#: so a frontend deep-link / docs reference doesn't break across
#: re-installs.
PRACTICE_COMPETITION_ID = "practice"


class _SpecReader(Protocol):
    def iter_specs(self, *args, **kwargs): ...  # pragma: no cover


def bootstrap_practice_competition(
    state_backend: StateBackend,
    spec_reader: _SpecReader,
) -> CompetitionState | None:
    """Mint a single permanent "practice" competition containing every
    known challenge. Idempotent — returns ``None`` when nothing was
    written (already bootstrapped, operator already curated their own
    comps, or the challenge directory is empty).

    The practice comp uses empty ``starts_at`` / ``ends_at`` so it's
    live immediately and never expires — operators who want a
    time-windowed event create their own via
    ``POST /admin/competitions``.
    """
    # Skip when *any* competition already exists. The bootstrap is for
    # fresh deployments; once an operator has curated their own list
    # we don't second-guess them.
    if state_backend.list_competitions(limit=1):
        log.debug("practice bootstrap: skipped — competitions already present")
        return None

    challenge_ids = sorted({spec.id for spec in spec_reader.iter_specs()})
    if not challenge_ids:
        log.debug("practice bootstrap: skipped — no challenges loaded")
        return None

    now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    comp = CompetitionState(
        competition_id=PRACTICE_COMPETITION_ID,
        title="Practice",
        description=(
            "All challenges, no time limit. Created automatically on "
            "first launch — admins can edit or delete from the admin "
            "console once a real event is configured."
        ),
        starts_at="",
        ends_at="",
        challenge_ids=challenge_ids,
        created_at=now_iso,
        updated_at=now_iso,
        created_by="",
        created_by_name="bootstrap",
    )
    state_backend.put_competition(comp)
    log.info(
        "Bootstrapped practice competition",
        competition_id=PRACTICE_COMPETITION_ID,
        challenge_count=len(challenge_ids),
    )
    return comp


__all__ = ["PRACTICE_COMPETITION_ID", "bootstrap_practice_competition"]
