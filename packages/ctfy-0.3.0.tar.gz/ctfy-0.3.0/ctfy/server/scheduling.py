"""Node placement scheduling: pick a healthy worker node for a new instance.

Extracted from ``routes/instances.py`` so the algorithm can be tested
independently from the HTTP layer (see TODO in the main plan about unit
tests for capacity/heartbeat edge cases).
"""

from __future__ import annotations

import time

from ctfy.core.constants import (
    HEARTBEAT_TIMEOUT,
    NODE_SCHEDULING_CPU_THRESHOLD,
    NODE_SCHEDULING_MEMORY_THRESHOLD,
)
from ctfy.core.state.models import NodeState
from ctfy.server.app_state import AppState

__all__ = ["pick_node"]


def pick_node(app: AppState) -> NodeState | None:
    """Select the healthiest node with the most available capacity (least-loaded).

    Returns ``None`` when no node passes the health + heartbeat + capacity
    + resource gates.

    Resource gates: nodes whose last-reported ``cpu_percent`` /
    ``memory_percent`` exceed the thresholds in
    ``ctfy.core.constants`` are skipped even if they still have free
    slots — slot count is fast but coarse, and a node sitting at 95% RAM
    will OOM-kill the instance we'd schedule onto it. Heartbeats arrive
    every 30s so this isn't perfect (a burst of placements can outpace
    metric updates), but the slot count remains the primary throttle —
    the resource check only kicks in when the host is *already*
    saturated according to its most recent sample.
    """
    now = time.time()
    best: NodeState | None = None
    for n in app.state_backend.list_nodes():
        if not n.healthy:
            continue
        lb = n.last_heartbeat_ts
        if lb and (now - lb) > HEARTBEAT_TIMEOUT:
            continue  # stale heartbeat
        avail = n.capacity - n.running
        if avail <= 0:
            continue
        if n.cpu_percent > NODE_SCHEDULING_CPU_THRESHOLD:
            continue
        if n.memory_percent > NODE_SCHEDULING_MEMORY_THRESHOLD:
            continue
        if best is None or avail > (best.capacity - best.running):
            best = n
    return best
