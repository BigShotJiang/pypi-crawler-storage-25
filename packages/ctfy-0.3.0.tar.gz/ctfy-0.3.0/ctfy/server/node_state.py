"""Per-node persistent instance store.

A node owns (a) the generated flag for every instance it hosts and (b) all
Docker-specific metadata. The flag cannot live on the platform — losing it
on node restart would silently break submissions — so we persist it here
in a small SQLite file beside the node process.

Pydantic provider handles (``StartResult`` etc.) are *not* persisted: they
live in an in-memory hot cache keyed by ``instance_id`` and are rebuilt or
cleaned up by the node's orphan-cleanup pass on startup.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from ctfy.core.enums import InstanceStatus
from ctfy.core.target import AttackSurface


class NodeInstanceRecord(BaseModel):
    """Persisted view of an instance on this node.

    Post-step-18 the flag lives on the platform; the node only keeps
    operational metadata so it can keep serving /status and /health
    across a restart.
    """

    instance_id: str
    challenge_id: str
    proxy_output: str = ""
    status: str = ""
    error: str = ""
    surface: AttackSurface | None = None
    started_at: float = 0.0
    ttl: int = 0

    @property
    def expires_at(self) -> float:
        return self.started_at + self.ttl if self.ttl > 0 else 0.0

    def is_expired(self, now: float | None = None) -> bool:
        if self.ttl <= 0:
            return False
        return (now or time.time()) >= self.expires_at


class NodeInstanceStore:
    """SQLite-backed store; one file per node process.

    Safe for concurrent use from multiple threads via a single shared
    connection with check_same_thread=False + an internal lock.
    """

    def __init__(self, db_path: str | Path) -> None:
        path = Path(db_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._lock = threading.Lock()
        self._init_tables()

    def _init_tables(self) -> None:
        with self._conn:
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS instances (
                    instance_id TEXT PRIMARY KEY,
                    data TEXT NOT NULL
                )
                """
            )
            # Single-row KV table: persists the node's own identity
            # (``node_id`` + per-node bearer minted by the platform on
            # first registration). Keeping it here means one less file
            # beside the node process and lets ``docker compose restart
            # node`` reuse an existing registration instead of burning a
            # fresh admin-minted invite every time.
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS node_identity (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                """
            )

    # -- CRUD ---------------------------------------------------------------

    def put(self, rec: NodeInstanceRecord) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO instances (instance_id, data) VALUES (?, ?)",
                (rec.instance_id, rec.model_dump_json()),
            )

    def get(self, instance_id: str) -> NodeInstanceRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT data FROM instances WHERE instance_id = ?", (instance_id,)
            ).fetchone()
        return NodeInstanceRecord.model_validate_json(row[0]) if row else None

    def delete(self, instance_id: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM instances WHERE instance_id = ?", (instance_id,))

    def list_all(self) -> list[NodeInstanceRecord]:
        with self._lock:
            rows = self._conn.execute("SELECT data FROM instances").fetchall()
        return [NodeInstanceRecord.model_validate_json(r[0]) for r in rows]

    def count(self) -> int:
        with self._lock:
            row = self._conn.execute("SELECT COUNT(*) FROM instances").fetchone()
        return int(row[0]) if row else 0

    def count_active(self) -> int:
        """Records still consuming a capacity slot (status STARTING or READY).

        ERROR / STOPPED rows are kept around so ``GET /instances/{id}/status``
        can return a useful status instead of 404, but their containers no
        longer exist — counting them as "running" inflates utilisation and
        falsely reports the node as full. Status lives inside the JSON blob
        so the filter happens in Python; capacity is small (~tens) so the
        full table scan is cheap.
        """
        active = {InstanceStatus.STARTING.value, InstanceStatus.READY.value}
        return sum(1 for r in self.list_all() if r.status in active)

    # -- convenience updates ------------------------------------------------

    def set_status(
        self,
        instance_id: str,
        status: str,
        *,
        error: str = "",
        surface: AttackSurface | None = None,
    ) -> NodeInstanceRecord | None:
        rec = self.get(instance_id)
        if not rec:
            return None
        updated = rec.model_copy(
            update={
                "status": status,
                "error": error or rec.error,
                "surface": surface if surface is not None else rec.surface,
            }
        )
        self.put(updated)
        return updated

    def pop_expired(self, now: float | None = None) -> list[NodeInstanceRecord]:
        """Remove and return any records past their TTL."""
        t = now or time.time()
        expired = [r for r in self.list_all() if r.is_expired(t)]
        for r in expired:
            self.delete(r.instance_id)
        return expired

    # -- node identity (persisted across restarts) -------------------------

    def get_identity(self) -> tuple[str, str] | None:
        """Return ``(node_id, node_token)`` if previously saved, else ``None``.

        Partial rows (only one of the two keys present) are treated as
        invalid — the caller should fall back to re-registration so a
        broken half-write can't leave the node stuck.
        """
        with self._lock:
            rows = self._conn.execute(
                "SELECT key, value FROM node_identity WHERE key IN ('node_id', 'node_token')"
            ).fetchall()
        kv = {r[0]: r[1] for r in rows}
        node_id = kv.get("node_id", "")
        node_token = kv.get("node_token", "")
        if node_id and node_token:
            return node_id, node_token
        return None

    def put_identity(self, node_id: str, node_token: str) -> None:
        """Overwrite the persisted identity atomically."""
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO node_identity (key, value) VALUES (?, ?)",
                ("node_id", node_id),
            )
            self._conn.execute(
                "INSERT OR REPLACE INTO node_identity (key, value) VALUES (?, ?)",
                ("node_token", node_token),
            )

    def clear_identity(self) -> None:
        """Drop the persisted identity (e.g. after platform rejects it)."""
        with self._lock, self._conn:
            self._conn.execute(
                "DELETE FROM node_identity WHERE key IN ('node_id', 'node_token')"
            )

    # -- raw escape hatch (useful for tests) --------------------------------

    def _raw(self, instance_id: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT data FROM instances WHERE instance_id = ?", (instance_id,)
            ).fetchone()
        return json.loads(row[0]) if row else None

    def close(self) -> None:
        self._conn.close()
