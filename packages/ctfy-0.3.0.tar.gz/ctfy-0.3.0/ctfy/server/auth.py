"""Authentication and ownership dependencies for the platform server.

Token identities recognized by the platform:

- **user token** (``team_tokens.kind == "user"``): minted on OAuth or
  password login. Carries the "logged-in human" privilege — allowed to
  manage linked providers, mint/revoke agent tokens, and (when the
  caller's :class:`UserState` ``role`` is ``admin`` or ``super_admin``)
  call admin endpoints.
- **agent token** (``team_tokens.kind == "agent"``): minted by a
  logged-in user from the Settings UI for their own agents / CI / CLI.
  Can submit flags and operate instances on the user's current team's
  behalf but cannot edit auth state (linking providers, minting tokens).
- **invite token** (``NodeInviteState``, minted by admin at
  ``POST /nodes/invites``): one-time registration credential consumed by
  ``POST /nodes/register``.
- **per-node token** (``NodeState.token``, minted on register): the node's
  identity. Used in both directions — node→platform (heartbeat,
  deregister) and platform→node (start/stop/status).

Post user/team-split: tokens identify a :class:`UserState`; routes that
need a team look up the user's current membership via
``backend.get_membership(user.user_id) → team_id`` and then
``backend.get_team(team_id)``. Admin gating reads ``user.role``;
super-admin is recomputed from ``CTFY_SUPER_ADMIN_EMAILS`` on every
OAuth callback. Regular admin is granted by a super-admin via
``PATCH /admin/users/{user_id}/role``.

Ownership helpers (:func:`check_ownership`, :func:`check_node_identity`)
live here because "who is this caller and what may they touch" is one
concern.
"""

from __future__ import annotations

import hashlib
import time
from datetime import datetime, timezone

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from ctfy.core.exceptions import ForbiddenError
from ctfy.core.state import StateBackend
from ctfy.core.state.models import (
    InstanceState,
    NodeInviteState,
    NodeState,
    TeamState,
    TeamToken,
    UserState,
)

# Shared security schemes — HTTPBearer handles "Bearer " parsing automatically
bearer_required = HTTPBearer()  # no token → 403
bearer_optional = HTTPBearer(auto_error=False)  # no token → None


def hash_token(token: str) -> str:
    """SHA-256 hash of a plaintext bearer token. Used for storage and lookup."""
    return hashlib.sha256(token.encode()).hexdigest()


def is_token_expired(expires_at: str, *, now: datetime | None = None) -> bool:
    """Return True if ``expires_at`` (ISO 8601, UTC) is in the past.

    Empty string means the token never expires. Unparseable strings are
    treated as "expired" so a malformed row never authenticates — we'd
    rather 403 than trust unknown data.
    """
    if not expires_at:
        return False
    try:
        ts = datetime.fromisoformat(expires_at)
    except ValueError:
        return True
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    current = now or datetime.now(timezone.utc)
    return current >= ts


# Minimum interval between ``last_used_at`` writes for the same token. Every
# authenticated request would otherwise issue a DB write purely to bump an
# audit timestamp — throttling keeps the hot path read-only for minute-scale
# bursts while the Settings "Active sessions" view stays accurate enough.
_TOUCH_THROTTLE_SECONDS = 60


def _maybe_touch_token(state_backend: StateBackend, tok: TeamToken) -> None:
    """Update ``tok.last_used_at`` to now, but skip if we touched recently."""
    current = datetime.now(timezone.utc)
    prev = tok.last_used_at
    if prev:
        try:
            ts = datetime.fromisoformat(prev)
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            if (current - ts).total_seconds() < _TOUCH_THROTTLE_SECONDS:
                return
        except ValueError:
            pass
    state_backend.touch_token(tok.token_id, current.isoformat())


def _resolve_user_token(
    state_backend: StateBackend, credentials: HTTPAuthorizationCredentials
) -> tuple[UserState, TeamToken]:
    """Resolve credentials to (user, token), or raise 403."""
    tok = state_backend.get_token_by_hash(hash_token(credentials.credentials))
    if not tok or tok.revoked_at:
        raise HTTPException(403, "Invalid or revoked token")
    if is_token_expired(tok.expires_at):
        raise HTTPException(403, "Token has expired")
    user = state_backend.get_user(tok.user_id)
    if not user:
        raise HTTPException(403, "User missing")
    _maybe_touch_token(state_backend, tok)
    return user, tok


def make_require_invite_or_admin(state_backend: StateBackend):
    """Node-registration auth: accept a one-time invite token or an admin user token."""

    async def dep(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ) -> NodeInviteState | None:
        if not credentials:
            raise HTTPException(401, "Missing bearer token")
        token = credentials.credentials
        invite = state_backend.get_invite_by_hash(hash_token(token))
        if invite:
            if invite.consumed_at_ts > 0:
                raise HTTPException(403, "Invite has already been used")
            if invite.expires_at_ts and time.time() >= invite.expires_at_ts:
                raise HTTPException(403, "Invite has expired")
            return invite
        tok = state_backend.get_token_by_hash(hash_token(token))
        if tok and not tok.revoked_at and not is_token_expired(tok.expires_at):
            user = state_backend.get_user(tok.user_id)
            if user and user.is_admin:
                return None
        raise HTTPException(403, "Invalid invite or admin credentials")

    return dep


def make_require_node_or_admin(state_backend: StateBackend):
    """Accept a per-node outbound token (preferred) or an admin user token."""

    async def dep(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ) -> NodeState | None:
        if not credentials:
            raise HTTPException(401, "Missing bearer token")
        token = credentials.credentials
        node = state_backend.get_node_by_token(token)
        if node:
            return node
        tok = state_backend.get_token_by_hash(hash_token(token))
        if tok and not tok.revoked_at and not is_token_expired(tok.expires_at):
            user = state_backend.get_user(tok.user_id)
            if user and user.is_admin:
                return None
        raise HTTPException(403, "Invalid node or admin credentials")

    return dep


def check_node_identity(authenticated: NodeState | None, node_id: str) -> None:
    """Guard per-node routes: reject if a node-token caller targets another node."""
    if authenticated is None:
        return
    if authenticated.node_id != node_id:
        raise HTTPException(403, "Node token does not match target node")


# ---------------------------------------------------------------------------
# Auth dependency factories
# ---------------------------------------------------------------------------


def make_get_current_user(state_backend: StateBackend):
    """Strict user auth: bearer token → :class:`UserState`. 403 if missing."""

    async def get_current_user(
        credentials: HTTPAuthorizationCredentials = Depends(bearer_required),
    ) -> UserState:
        return _resolve_user_token(state_backend, credentials)[0]

    return get_current_user


def make_get_current_user_or_none(state_backend: StateBackend):
    """Optional user auth: returns the user when token is valid, else None."""

    async def get_current_user_or_none(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ) -> UserState | None:
        if not credentials:
            return None
        tok = state_backend.get_token_by_hash(hash_token(credentials.credentials))
        if not tok or tok.revoked_at or is_token_expired(tok.expires_at):
            return None
        return state_backend.get_user(tok.user_id)

    return get_current_user_or_none


def make_get_current_team_for_competition(state_backend: StateBackend):
    """Per-competition team auth: bearer → user →
    ``get_membership_for_competition(user_id, competition_id)`` → team.

    Sub-dependency that takes ``competition_id`` from the route's
    path (FastAPI resolves it automatically). Returns 403 with body
    ``{"error": "not_registered", "competition_id": ...}`` when the
    user has no membership for that competition — the frontend reads
    this to render the in-page Solo / Create / Join registration card
    instead of an opaque error message.
    """

    async def get_current_team_for_competition(
        competition_id: str,
        credentials: HTTPAuthorizationCredentials = Depends(bearer_required),
    ) -> TeamState:
        user, _ = _resolve_user_token(state_backend, credentials)
        m = state_backend.get_membership_for_competition(
            user.user_id, competition_id
        )
        if m is None:
            raise HTTPException(
                403,
                detail={
                    "error": "not_registered",
                    "competition_id": competition_id,
                },
            )
        team = state_backend.get_team(m.team_id)
        if team is None:
            raise HTTPException(
                403,
                detail={
                    "error": "team_missing",
                    "competition_id": competition_id,
                },
            )
        return team

    return get_current_team_for_competition


def make_require_team_captain(state_backend: StateBackend):
    """Resolve the per-comp team for the calling user *and* assert
    they captain it. Returns ``(team, user)`` so the route doesn't
    have to redundantly resolve either.

    Routes that mutate team state (rename, mint invite, kick, approve
    join request) take this dependency instead of pairing
    :func:`make_get_current_team_for_competition` with an inline
    captain check — the precondition lives in the route signature and
    the body shrinks by a line.
    """

    get_team = make_get_current_team_for_competition(state_backend)
    get_user = make_get_current_user(state_backend)

    async def require_team_captain(
        team: TeamState = Depends(get_team),
        user: UserState = Depends(get_user),
    ) -> tuple[TeamState, UserState]:
        if team.captain_user_id != user.user_id:
            raise HTTPException(
                403, "Only the team captain can perform this action"
            )
        return team, user

    return require_team_captain


def make_get_current_user_with_token(state_backend: StateBackend):
    """Resolve Bearer → ``(user, token)`` regardless of token kind.

    Used by ``/me`` so the response can report the caller's token kind
    (user vs agent) without a second lookup.
    """

    async def dep(
        credentials: HTTPAuthorizationCredentials = Depends(bearer_required),
    ) -> tuple[UserState, TeamToken]:
        return _resolve_user_token(state_backend, credentials)

    return dep


def make_require_user_kind(state_backend: StateBackend):
    """Require a ``kind="user"`` bearer token.

    Used to gate sensitive auth-state mutations (linking/unlinking OAuth
    providers, minting/revoking agent tokens, joining / leaving teams).
    An agent-kind token — even from an admin user — cannot pass this
    dependency, which prevents lateral token escalation if an agent
    token leaks.

    Returns ``(user, token)`` so routes can inspect both without
    re-resolving.
    """

    async def dep(
        credentials: HTTPAuthorizationCredentials = Depends(bearer_required),
    ) -> tuple[UserState, TeamToken]:
        user, tok = _resolve_user_token(state_backend, credentials)
        if tok.kind != "user":
            raise HTTPException(
                403, "This operation requires a user session (logged-in OAuth token)"
            )
        return user, tok

    return dep


def make_require_admin(state_backend: StateBackend):
    """Require an authenticated user whose ``role`` grants admin."""

    async def dep(
        credentials: HTTPAuthorizationCredentials = Depends(bearer_required),
    ) -> UserState:
        user, _ = _resolve_user_token(state_backend, credentials)
        if not user.is_admin:
            raise HTTPException(403, "Admin privileges required")
        return user

    return dep


def make_require_super_admin(state_backend: StateBackend):
    """Require an authenticated user with ``role == "super_admin"``."""

    async def dep(
        credentials: HTTPAuthorizationCredentials = Depends(bearer_required),
    ) -> UserState:
        user, _ = _resolve_user_token(state_backend, credentials)
        if not user.is_super_admin:
            raise HTTPException(403, "Super-admin privileges required")
        return user

    return dep


# ---------------------------------------------------------------------------
# Ownership helpers
# ---------------------------------------------------------------------------


def resolve_team_for_competition(
    state_backend: StateBackend,
    user: UserState,
    competition_id: str,
) -> TeamState:
    """Look up the team the calling user is on for ``competition_id``.

    When ``competition_id`` is empty and the user is on exactly one
    team across all competitions, that team is returned (the
    unambiguous case). Otherwise the caller has to disambiguate.
    Raises 403 with a typed body the frontend uses to render the
    in-page Solo / Create / Join card.
    """
    if competition_id:
        m = state_backend.get_membership_for_competition(
            user.user_id, competition_id
        )
    else:
        rows = state_backend.list_memberships(user_id=user.user_id)
        if len(rows) != 1:
            raise HTTPException(
                403,
                detail={
                    "error": "competition_required"
                    if rows
                    else "not_registered",
                    "competition_id": competition_id,
                },
            )
        m = rows[0]
    if m is None:
        raise HTTPException(
            403,
            detail={
                "error": "not_registered",
                "competition_id": competition_id,
            },
        )
    team = state_backend.get_team(m.team_id)
    if team is None:
        raise HTTPException(
            403,
            detail={
                "error": "team_missing",
                "competition_id": competition_id,
            },
        )
    return team


def user_team_ids(state_backend: StateBackend, user: UserState | None) -> set[str]:
    """Set of team_ids the user is on right now via *any* per-comp
    membership. Empty set for anonymous callers.

    Drives ownership checks on shared user resources (instances,
    submissions). After the user/team-split a user can be on
    different teams in different competitions; this helper enumerates
    all of them in one place.
    """
    if user is None:
        return set()
    return {
        m.team_id
        for m in state_backend.list_memberships(user_id=user.user_id)
    }


def check_ownership(
    resource: TeamState | InstanceState,
    user_team_ids_set: set[str],
    resource_name: str = "resource",
) -> None:
    """Raise :class:`ForbiddenError` when the calling user is not on
    the resource's team.

    Used by per-team-resource routes (instance lifecycle, archived
    instance reads). The check compares the resource's stamped
    ``team_id`` against the set of teams the calling user is currently
    on (across every competition). A user who left the team after
    spinning up an instance no longer passes the guard — the team
    they're no longer on isn't theirs to operate.

    Unowned resources (``resource.team_id == ""``) are reachable by
    everyone — they pre-date team scoping and are not security-
    sensitive.
    """
    if not resource.team_id:
        return
    if resource.team_id not in user_team_ids_set:
        raise ForbiddenError(f"Not your {resource_name}")
