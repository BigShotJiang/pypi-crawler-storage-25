"""Shared application state container for the platform server.

``AppState`` bundles long-lived server dependencies (state backend, SSE hub,
challenge metadata reader, pre-built FastAPI auth dependencies, etc.) so
route modules can accept a single argument rather than wiring each
dependency individually.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Awaitable, Callable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from ctfy.core.challenge import ChallengeManager
from ctfy.core.config import CtfyConfig
from ctfy.core.state import StateBackend
from ctfy.core.state.models import (
    InstanceState,
    NodeInviteState,
    NodeState,
    TeamState,
    TeamToken,
    UserState,
)
from ctfy.server.instance_archive import InstanceArchive
from ctfy.server.sse import SSEHub

if TYPE_CHECKING:  # avoid import cycles at runtime for dataclass annotations
    from slowapi import Limiter

    from ctfy.server.oauth.providers import OAuthProvider

__all__ = [
    "AppState",
    "AdminAuthDep",
    "CaptainAuthDep",
    "InstanceDep",
    "OptionalUserAuthDep",
    "TeamAuthDep",
    "UserAuthDep",
    "UserKindAuthDep",
    "now_iso",
]

# Type aliases for FastAPI dependency callables attached to AppState.
# Post user/team-split: ``UserAuthDep`` is the primary identity dep;
# ``TeamAuthDep`` is the per-competition team-resolution dep used for
# any write that mutates per-comp state.
UserAuthDep = Callable[..., Awaitable[UserState]]
OptionalUserAuthDep = Callable[..., Awaitable[UserState | None]]
TeamAuthDep = Callable[..., Awaitable[TeamState]]
# Captain-of-current-team dep: returns ``(team, user)`` after asserting
# the calling user captains the per-comp team. Lets routes that mutate
# team state declare the precondition in their signature instead of
# inline-checking ``team.captain_user_id == user.user_id``.
CaptainAuthDep = Callable[..., Awaitable[tuple[TeamState, UserState]]]
# Admin auth returns the calling :class:`UserState` (admin/super_admin).
# Routes that don't need the object use it as a gate-only dependency via
# ``dependencies=[Depends(app.require_admin)]``.
AdminAuthDep = Callable[..., Awaitable[UserState]]
UserKindAuthDep = Callable[..., Awaitable[tuple[UserState, TeamToken]]]
UserWithTokenDep = Callable[..., Awaitable[tuple[UserState, TeamToken]]]
InstanceDep = Callable[..., Awaitable[InstanceState]]
NodeAuthDep = Callable[..., Awaitable[NodeState | None]]
InviteAuthDep = Callable[..., Awaitable[NodeInviteState | None]]


@dataclass
class AppState:
    """Immutable container for shared application dependencies."""

    config: CtfyConfig
    state_backend: StateBackend
    # ``spec_reader`` on the platform side is just a metadata reader — it
    # exposes ``iter_specs`` over ``challenges_dir``. The full ChallengeManager
    # class is reused for convenience, but its provider registry is never
    # triggered on the platform (no Docker, no ports). Container lifecycle
    # goes to worker nodes via NodeClient.
    spec_reader: ChallengeManager
    sse_hub: SSEHub
    host: str
    max_instances: int
    # Filesystem sink for per-instance artifacts. Routes / lifecycle hooks
    # write events, submissions, manifest, and container logs through this
    # handle; the archive directory is created on first write.
    instance_archive: InstanceArchive | None = None
    # Wall-clock source for any route that needs "now" — pulled out of
    # the global namespace so tests can pin a deterministic instant.
    # Production stays on ``time.time``; the timeseries routes used to
    # call it directly and inherited the resulting timing flakiness.
    clock: Callable[[], float] = field(default=time.time)
    # Process start time — surfaced by /api/v1/meta so the status bar can
    # render "up 2d 3h". Captured at app construction; a fresh process
    # means a fresh value.
    started_at_ts: float = field(default_factory=time.time)
    instance_start_lock: threading.Lock = field(default_factory=threading.Lock)
    bg_executor: ThreadPoolExecutor = field(
        default_factory=lambda: ThreadPoolExecutor(max_workers=8, thread_name_prefix="ctfy-bg")
    )

    # Pre-built auth dependencies (created once in app.py, reused by all route modules)
    get_current_user: UserAuthDep | None = field(default=None, repr=False)
    get_current_user_or_none: OptionalUserAuthDep | None = field(default=None, repr=False)
    # Per-competition team auth — sub-dependency that takes
    # ``competition_id`` from the route's path or body. Routes use
    # this for any write that mutates per-comp state (start instance,
    # submit flag, mint invite, etc.). 403s with a typed body when the
    # caller is not registered for the targeted competition so the
    # frontend can render the in-page Solo / Create / Join card.
    get_current_team_for_competition: TeamAuthDep | None = field(default=None, repr=False)
    # Captain gate built on top of ``get_current_team_for_competition``
    # — used by every route that mutates per-comp team state (rename,
    # mint invite, kick, approve join request). Routes declare it
    # directly instead of pairing the team dep with an inline
    # ``_require_captain`` call.
    require_team_captain: CaptainAuthDep | None = field(default=None, repr=False)
    # Resolves Bearer → ``(user, token)`` — used by ``/me`` so the response
    # can include the caller's token kind.
    get_current_user_with_token: UserWithTokenDep | None = field(default=None, repr=False)
    require_admin: AdminAuthDep | None = field(default=None, repr=False)
    # Stricter than ``require_admin``: only ``role=="super_admin"`` passes.
    # Used to gate admin-management routes (promote/demote regular admins).
    require_super_admin: AdminAuthDep | None = field(default=None, repr=False)
    # Sensitive auth-state mutations (OAuth link/unlink, token mint/revoke)
    # require a user-kind token; agent-kind tokens are rejected.
    require_user_kind: UserKindAuthDep | None = field(default=None, repr=False)
    # Node→platform calls (heartbeat, self-deregister): per-node outbound
    # token OR admin. Returns the authenticated NodeState so routes can
    # bind the caller's identity to a node_id.
    require_node_or_admin: NodeAuthDep | None = field(default=None, repr=False)
    # POST /nodes/register auth: invite token (preferred) or admin token.
    # Returns the NodeInviteState when an invite is used so the register
    # handler can atomically consume it.
    require_invite_or_admin: InviteAuthDep | None = field(default=None, repr=False)

    # --- OAuth wiring ------------------------------------------------------
    # HMAC key for signing OAuth state. Read from CTFY_SECRET_KEY (preferred),
    # legacy persisted row in the state backend, or an ephemeral fallback
    # (in that order — see create_platform_app for the resolution).
    oauth_secret: str = ""
    # Where ``oauth_secret`` came from this boot — surfaced to ops endpoints
    # / startup logs so operators can see whether the key is durable.
    # Values: ``"env"``, ``"state_backend"``, ``"ephemeral"``.
    oauth_secret_source: str = ""
    # Lowercased super-admin email allowlist (looked up on every OAuth
    # callback). Regular admin role is granted via the admin UI by a
    # super-admin and is not derived from this set.
    super_admin_emails_lower: set[str] = field(default_factory=set)
    # Provider implementations keyed by provider name. Entries only appear
    # when the corresponding client_id and client_secret are both set.
    oauth_providers: dict[str, "OAuthProvider"] = field(default_factory=dict)

    # Pre-built resource+ownership dependencies
    require_instance: InstanceDep | None = field(default=None, repr=False)

    # Rate limiter (created per-app to avoid shared state across tests)
    limiter: "Limiter | None" = field(default=None, repr=False)

    # Discarded on purpose: ``Any`` for fields above would have hidden
    # signature drift between routes and the dependency factories that
    # build these callables. With concrete aliases, IDEs flag mismatches
    # (e.g. passing ``get_current_team`` where ``require_admin`` is
    # expected).


def now_iso() -> str:
    """Return current UTC time as ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat()
