"""Aggregate server snapshot for the UI status bar.

A single public endpoint so the bar fires one request instead of four
against ``/challenges``, ``/teams``, ``/nodes``, and ``/scoreboard``.
Only exposes numbers those endpoints already disclose to anonymous
callers; admin-only details (capacity, solves-today) stay on
``/admin/overview``.
"""

from __future__ import annotations

import subprocess
import time
from importlib import metadata
from pathlib import Path

from fastapi import APIRouter, Depends

from ctfy.core.config import CtfyConfig
from ctfy.core.constants import HEARTBEAT_TIMEOUT
from ctfy.core.state.models import UserState
from ctfy.server.app_state import AppState
from ctfy.server.auth import make_get_current_user_or_none
from ctfy.server.models import MetaChallenges, MetaPlatform, MetaResponse


def _package_version() -> str:
    try:
        return metadata.version("ctfy")
    except metadata.PackageNotFoundError:
        return "0.0.0+unknown"


def _git_commit(config: CtfyConfig) -> str | None:
    """Return the running build's git sha, or None when unavailable.

    Configured value (``CTFY_GIT_COMMIT``) wins so production deploys
    are deterministic. The subprocess fallback only fires in dev where
    the source tree is checked out — production containers don't ship
    git so ``rev-parse`` will fail and we return None rather than
    pretending.
    """
    if config.git_commit:
        return config.git_commit
    try:
        out = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(Path(config.project_root)),
            capture_output=True,
            check=True,
            text=True,
            timeout=2,
        )
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None
    sha = out.stdout.strip()
    return sha or None


def _challenges_commit(config: CtfyConfig) -> str | None:
    """Return the challenges-repo HEAD sha, or None when unavailable.

    Unlike ``_git_commit`` there is no env-var override: the challenges
    directory is the source of truth (``ensure_challenges`` syncs it).
    Returns None when the dir doesn't exist, isn't a git working tree,
    or the git binary is missing.
    """
    try:
        out = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(config.challenges_dir),
            capture_output=True,
            check=True,
            text=True,
            timeout=2,
        )
    except (FileNotFoundError, NotADirectoryError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None
    sha = out.stdout.strip()
    return sha or None


def _commit_url(repo_url: str, sha: str | None) -> str | None:
    if not sha or not repo_url:
        return None
    # Strip the conventional ``.git`` suffix so the resulting URL is the
    # GitHub web view, not the clone URL.
    base = repo_url.rstrip("/")
    if base.endswith(".git"):
        base = base[: -len(".git")]
    return f"{base}/commit/{sha}"


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    get_user_or_none = make_get_current_user_or_none(app.state_backend)

    @router.get("/meta", response_model=MetaResponse)
    def meta(
        user: UserState | None = Depends(get_user_or_none),
    ) -> MetaResponse:
        now = time.time()
        platform_sha = _git_commit(app.config)
        challenges_sha = _challenges_commit(app.config)
        is_admin = bool(user and user.is_admin)
        # Public payload — every caller (guests included) can see the
        # build identity, server clock, and the count of *available*
        # challenges (the list is browsable anyway).
        response = MetaResponse(
            version=_package_version(),
            platform=MetaPlatform(
                commit_sha=platform_sha,
                commit_url=_commit_url(app.config.repo_url, platform_sha),
                repo_url=app.config.repo_url,
            ),
            challenges=MetaChallenges(
                commit_sha=challenges_sha,
                commit_url=_commit_url(app.config.challenges_repo, challenges_sha),
                repo_url=app.config.challenges_repo,
                total=sum(1 for _ in app.spec_reader.iter_specs()),
            ),
            started_at_ts=app.started_at_ts,
            server_time_ts=now,
        )
        # Admin-only counters: cluster capacity (nodes), competition
        # health (teams/solves), and platform-wide running instances.
        # Non-admins should not be able to compose a competitive
        # signal from /meta alone.
        if is_admin:
            nodes = app.state_backend.list_nodes()
            healthy = sum(
                1
                for n in nodes
                if n.last_heartbeat_ts and (now - n.last_heartbeat_ts) < HEARTBEAT_TIMEOUT
            )
            response.teams_total = len(app.state_backend.list_teams())
            response.nodes_total = len(nodes)
            response.nodes_healthy = healthy
            response.running_instances = app.state_backend.count_instances()
            response.solves_total = len(app.state_backend.list_solves())
        return response

    return router
