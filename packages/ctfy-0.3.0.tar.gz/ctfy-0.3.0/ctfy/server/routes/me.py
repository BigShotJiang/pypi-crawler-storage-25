"""Routes that operate on the authenticated user (``/me/...``).

Post user/team-split, ``/me`` is user-shaped: it returns the calling
user's profile, role, providers, token kind, plus a pointer to their
current team. Team-scoped operations (rename, delete, invite) live on
:mod:`ctfy.server.routes.team_invites`.

The data export (``GET /me/export``) bundles up everything the
platform stores about the calling user — identities, tokens, solves,
submissions, activities, achievements, snapshots — including data
attributed to teams the user used to be on. Useful for audit and
GDPR-style "give me a copy" requests.
"""

from __future__ import annotations

import io
import json
import time
import zipfile

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Body, Depends, HTTPException, Response

from ctfy.core.announcements import is_active as _ann_is_active
from ctfy.core.log import log
from ctfy.core.state.models import TeamToken, UserState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.models import (
    PROFILE_VISIBILITY_KEYS,
    CompetitionMembershipInfo,
    DeleteMeRequest,
    InboxAnnouncement,
    InboxCaptainRequest,
    InboxIncomingInvite,
    InboxOutgoingRequest,
    InboxResponse,
    MeResponse,
    ProfilePatchRequest,
)

# Announcements that ended within this window are still surfaced in the
# Inbox so a user who logs in shortly after a notice expires can still
# see what was posted. Older expired rows are dropped (admin can fetch
# the full history from /admin/announcements).
_RECENTLY_EXPIRED_DAYS = 7
from ctfy.server.routes.teams import team_info as _team_info_for_team_id


def _user_aggregates(app: AppState, user_id: str) -> tuple[int, int, str]:
    """Lifetime (solves, attempts, last_active_at) for ``user_id``.

    Sums across every team the user has ever been on by filtering on
    ``user_id`` rather than ``team_id``.
    """
    solves = sum(
        1 for s in app.state_backend.list_solves() if s.user_id == user_id
    )
    attempts = sum(
        1 for s in app.state_backend.list_submissions() if s.user_id == user_id
    )
    last_active = ""
    for a in app.state_backend.list_activities(offset=0, limit=200):
        if a.user_id == user_id or a.actor_id == user_id:
            last_active = a.timestamp
            break
    return solves, attempts, last_active


def _me_response(
    app: AppState, user: UserState, token: TeamToken
) -> MeResponse:
    providers = {
        i.provider for i in app.state_backend.list_identities_for_user(user.user_id)
    }
    if app.state_backend.list_password_identities_for_user(user.user_id):
        providers.add("password")
    solves, attempts, last_active = _user_aggregates(app, user.user_id)
    competition_teams: list[CompetitionMembershipInfo] = []
    for m in app.state_backend.list_memberships(user_id=user.user_id):
        team = app.state_backend.get_team(m.team_id)
        if team is None:
            continue
        # Filter orphaned rows that point at a deleted competition.
        # The deletion path doesn't cascade memberships today, so a
        # surviving row would otherwise tile the rail with a comp
        # the /c/:id/* layout immediately 404s on.
        if app.state_backend.get_competition(m.competition_id) is None:
            continue
        competition_teams.append(
            CompetitionMembershipInfo(
                competition_id=m.competition_id,
                team_id=team.team_id,
                team_name=team.name,
                role="captain" if team.captain_user_id == user.user_id else "member",
            )
        )
    return MeResponse(
        user_id=user.user_id,
        display_name=user.display_name,
        avatar_url=user.avatar_url,
        created_at=user.created_at,
        bio=user.bio,
        country=user.country,
        website_url=user.website_url,
        timezone=user.timezone,
        social_links=dict(user.social_links),
        solves=solves,
        attempts=attempts,
        last_active_at=last_active,
        email=user.email,
        is_admin=user.is_admin,
        role=user.role,
        providers=sorted(providers),
        token_kind=token.kind,
        profile_visibility=dict(user.profile_visibility),
        competition_teams=competition_teams,
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/me", response_model=MeResponse)
    def get_me(
        ctx: tuple[UserState, TeamToken] = Depends(app.get_current_user_with_token),
    ):
        user, tok = ctx
        return _me_response(app, user, tok)

    @router.get("/me/inbox", response_model=InboxResponse)
    def get_my_inbox(
        user: UserState = Depends(app.get_current_user),
    ):
        """Pending invites/requests grouped by the action the
        calling user can take. Cheap O(N_invites) scan today —
        if the table grows past tens of thousands of rows the
        backend can index by target_user_id and (kind, team_id)
        without changing this endpoint's contract.
        """
        backend = app.state_backend

        def _is_active(inv) -> bool:
            if inv.revoked_at:
                return False
            if inv.max_uses and inv.use_count >= inv.max_uses:
                return False
            # No now_iso check here — expires_at is empty for direct/
            # join_request invites today; if/when we add TTLs they
            # should be filtered the same way.
            return True

        # Captain teams the user owns (anywhere) so we can filter
        # captain_requests in one pass without N+1 lookups.
        captain_team_ids: set[str] = set()
        for m in backend.list_memberships(user_id=user.user_id):
            team = backend.get_team(m.team_id)
            if team is not None and team.captain_user_id == user.user_id:
                captain_team_ids.add(team.team_id)

        # One scan over every invite — splits into the three
        # buckets based on kind + the calling user's relationship
        # to the row.
        incoming: list[InboxIncomingInvite] = []
        outgoing: list[InboxOutgoingRequest] = []
        cap_reqs: list[InboxCaptainRequest] = []
        comp_titles: dict[str, str] = {}

        def _comp_title(comp_id: str) -> str:
            if comp_id not in comp_titles:
                c = backend.get_competition(comp_id)
                comp_titles[comp_id] = c.title if c else ""
            return comp_titles[comp_id]

        for inv in backend.list_team_invites():
            if not _is_active(inv):
                continue
            team = backend.get_team(inv.team_id)
            if team is None:
                continue
            if inv.kind == "direct" and inv.target_user_id == user.user_id:
                captain = backend.get_user(team.captain_user_id)
                incoming.append(
                    InboxIncomingInvite(
                        invite_id=inv.invite_id,
                        competition_id=inv.competition_id,
                        competition_title=_comp_title(inv.competition_id),
                        team_id=team.team_id,
                        team_name=team.name,
                        captain_user_id=team.captain_user_id,
                        captain_display_name=(
                            captain.display_name if captain else ""
                        ),
                        created_at=inv.created_at,
                    )
                )
            elif inv.kind == "join_request":
                if inv.created_by_user_id == user.user_id:
                    captain = backend.get_user(team.captain_user_id)
                    outgoing.append(
                        InboxOutgoingRequest(
                            invite_id=inv.invite_id,
                            competition_id=inv.competition_id,
                            competition_title=_comp_title(inv.competition_id),
                            team_id=team.team_id,
                            team_name=team.name,
                            captain_user_id=team.captain_user_id,
                            captain_display_name=(
                                captain.display_name if captain else ""
                            ),
                            created_at=inv.created_at,
                        )
                    )
                elif inv.team_id in captain_team_ids:
                    requester = backend.get_user(inv.created_by_user_id)
                    cap_reqs.append(
                        InboxCaptainRequest(
                            invite_id=inv.invite_id,
                            competition_id=inv.competition_id,
                            competition_title=_comp_title(inv.competition_id),
                            team_id=team.team_id,
                            team_name=team.name,
                            requester_user_id=inv.created_by_user_id,
                            requester_display_name=(
                                requester.display_name if requester else ""
                            ),
                            created_at=inv.created_at,
                        )
                    )

        # Newest first in each bucket — most actionable on top.
        incoming.sort(key=lambda r: r.created_at, reverse=True)
        outgoing.sort(key=lambda r: r.created_at, reverse=True)
        cap_reqs.sort(key=lambda r: r.created_at, reverse=True)

        # Announcements: live now + recently expired (7d). Annotate
        # each row with the user's read state. Rows are sorted newest-
        # first so the freshest notice is always on top.
        ts = now_iso()
        cutoff = (
            datetime.now(timezone.utc) - timedelta(days=_RECENTLY_EXPIRED_DAYS)
        ).strftime("%Y-%m-%dT%H:%M:%SZ")
        ann_rows = backend.list_announcements(active_only=False, limit=10_000)
        relevant: list[InboxAnnouncement] = []
        read_ids = backend.list_read_announcement_ids(user.user_id)
        for ann in ann_rows:
            # Live now → keep. Already expired → keep iff within window.
            # Scheduled for future → also keep so users see what's
            # coming on their inbox.
            if _ann_is_active(ann, ts):
                pass
            elif ann.ends_at and ann.ends_at >= cutoff:
                pass
            elif ann.starts_at and ann.starts_at > ts:
                pass
            else:
                continue
            relevant.append(
                InboxAnnouncement(
                    announcement_id=ann.announcement_id,
                    title=ann.title,
                    body=ann.body,
                    severity=ann.severity,
                    starts_at=ann.starts_at,
                    ends_at=ann.ends_at,
                    created_at=ann.created_at,
                    updated_at=ann.updated_at,
                    created_by=ann.created_by,
                    created_by_name=ann.created_by_name,
                    is_read=ann.announcement_id in read_ids,
                )
            )
        unread = sum(1 for a in relevant if not a.is_read)
        return InboxResponse(
            incoming_invites=incoming,
            outgoing_requests=outgoing,
            captain_requests=cap_reqs,
            announcements=relevant,
            unread_announcement_count=unread,
        )

    @router.post("/me/announcements/{announcement_id}/read")
    def mark_announcement_read(
        announcement_id: str,
        user: UserState = Depends(app.get_current_user),
    ):
        """Mark a single announcement as read.

        Idempotent — re-marking returns ``{ok: true, new: false}``;
        the original ``read_at`` stays put so the audit trail isn't
        trampled. 404s on a non-existent announcement so the client
        can detect typos rather than silently writing orphan rows.
        """
        ann = app.state_backend.get_announcement(announcement_id)
        if ann is None:
            raise HTTPException(404, f"Announcement not found: {announcement_id}")
        new = app.state_backend.mark_announcement_read(
            user.user_id, announcement_id, now_iso()
        )
        return {"ok": True, "new": new}

    @router.post("/me/announcements/read-all")
    def mark_all_announcements_read(
        user: UserState = Depends(app.get_current_user),
    ):
        """Mark every currently-relevant announcement as read.

        "Relevant" matches the inbox projection above (active now or
        recently expired) — the user shouldn't be silently acking a
        long-purged row they can't see in the UI.
        """
        ts = now_iso()
        cutoff = (
            datetime.now(timezone.utc) - timedelta(days=_RECENTLY_EXPIRED_DAYS)
        ).strftime("%Y-%m-%dT%H:%M:%SZ")
        rows = app.state_backend.list_announcements(active_only=False, limit=10_000)
        ids: list[str] = []
        for ann in rows:
            if _ann_is_active(ann, ts):
                ids.append(ann.announcement_id)
            elif ann.ends_at and ann.ends_at >= cutoff:
                ids.append(ann.announcement_id)
            elif ann.starts_at and ann.starts_at > ts:
                ids.append(ann.announcement_id)
        new_count = app.state_backend.mark_announcements_read_bulk(
            user.user_id, ids, ts
        )
        return {"ok": True, "read_count": new_count}

    @router.patch("/me/profile", response_model=MeResponse)
    def patch_my_profile(
        body: ProfilePatchRequest,
        ctx: tuple[UserState, TeamToken] = Depends(app.get_current_user_with_token),
    ):
        """Partial update of the user's profile fields."""
        user, tok = ctx
        present = body.model_fields_set
        if not present:
            return _me_response(app, user, tok)
        update: dict[str, object] = {}
        for k in present:
            update[k] = getattr(body, k)
        try:
            updated = user.model_copy(update=update)
            updated = UserState.model_validate(updated.model_dump())
        except ValueError as e:
            raise HTTPException(422, str(e))
        app.state_backend.put_user(user.user_id, updated)
        # Profile changes can ripple onto every team page the user
        # captains (the captain's bio is rendered on each team's About
        # card), so fan the team-profile signal out across each
        # per-comp team they're on.
        from ctfy.server.team_signal import emit_team_profile_updated

        for m in app.state_backend.list_memberships(user_id=user.user_id):
            team = app.state_backend.get_team(m.team_id)
            if team is not None:
                emit_team_profile_updated(
                    app, team_id=team.team_id, team_name=team.name
                )
        return _me_response(app, updated, tok)

    @router.patch("/me/profile/visibility", response_model=MeResponse)
    def patch_my_profile_visibility(
        ctx: tuple[UserState, TeamToken] = Depends(app.get_current_user_with_token),
        overrides: dict[str, bool] = Body(default_factory=dict),
    ):
        user, tok = ctx
        merged = dict(user.profile_visibility)
        for k, v in overrides.items():
            if k in PROFILE_VISIBILITY_KEYS:
                merged[k] = bool(v)
        updated = user.model_copy(update={"profile_visibility": merged})
        app.state_backend.put_user(user.user_id, updated)
        from ctfy.server.team_signal import emit_team_profile_updated

        for m in app.state_backend.list_memberships(user_id=user.user_id):
            team = app.state_backend.get_team(m.team_id)
            if team is not None:
                emit_team_profile_updated(
                    app, team_id=team.team_id, team_name=team.name
                )
        return _me_response(app, updated, tok)

    @router.get("/me/export")
    def export_me(
        ctx: tuple[UserState, TeamToken] = Depends(app.get_current_user_with_token),
    ):
        """Download every piece of data the platform holds about this user."""
        user, _tok = ctx
        user_id = user.user_id
        memberships = app.state_backend.list_memberships(user_id=user_id)

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
            now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            zf.writestr(
                "README.txt",
                (
                    "ctfy account export\n"
                    f"user_id: {user_id}\n"
                    f"team_count: {len(memberships)}\n"
                    f"generated_at: {now}\n"
                    "schema_version: 3\n"
                    "\n"
                    "Files:\n"
                    "  user.json          - UserState (the human profile)\n"
                    "  teams.json         - TeamState rows for every per-comp\n"
                    "                       team the user is currently on\n"
                    "  identities.json    - OAuth + password identity metadata\n"
                    "  tokens.json        - Token metadata (no hashes)\n"
                    "  submissions.json   - Submitted flags (across every team)\n"
                    "  solves.json        - Captured flags (across every team)\n"
                    "  activity.jsonl     - Activity log (one JSON per line)\n"
                    "\n"
                    "Hashes (passwords, tokens) are intentionally omitted.\n"
                ),
            )

            zf.writestr("user.json", user.model_dump_json(indent=2))
            teams_dump = []
            for m in memberships:
                team = app.state_backend.get_team(m.team_id)
                if team is not None:
                    teams_dump.append(
                        {
                            "competition_id": m.competition_id,
                            "team": team.model_dump(),
                        }
                    )
            zf.writestr("teams.json", json.dumps(teams_dump, indent=2))

            oauth = [
                i.model_dump()
                for i in app.state_backend.list_identities_for_user(user_id)
            ]
            password = [
                {k: v for k, v in p.model_dump().items() if k != "password_hash"}
                for p in app.state_backend.list_password_identities_for_user(user_id)
            ]
            zf.writestr(
                "identities.json",
                json.dumps({"oauth": oauth, "password": password}, indent=2),
            )

            tokens = []
            for t in app.state_backend.list_tokens_for_user(
                user_id, include_revoked=True
            ):
                row = t.model_dump()
                row.pop("token_hash", None)
                row["token_id_prefix"] = (t.token_id or "")[:6]
                tokens.append(row)
            zf.writestr("tokens.json", json.dumps(tokens, indent=2))

            submissions = [
                s.model_dump()
                for s in app.state_backend.list_submissions()
                if s.user_id == user_id
            ]
            zf.writestr("submissions.json", json.dumps(submissions, indent=2))

            solves = [
                s.model_dump()
                for s in app.state_backend.list_solves()
                if s.user_id == user_id
            ]
            zf.writestr("solves.json", json.dumps(solves, indent=2))

            activity_lines: list[str] = []
            offset = 0
            chunk = 500
            while True:
                rows = app.state_backend.list_activities(
                    actor_id=user_id, offset=offset, limit=chunk
                )
                if not rows:
                    break
                activity_lines.extend(r.model_dump_json() for r in rows)
                if len(rows) < chunk:
                    break
                offset += chunk
            zf.writestr("activity.jsonl", "\n".join(activity_lines))

        body = buf.getvalue()
        log.info("Account exported", user_id=user_id, bytes=len(body))
        return Response(
            content=body,
            media_type="application/zip",
            headers={
                "Content-Disposition": (
                    f"attachment; filename=\"ctfy-export-{user_id}-{int(time.time())}.zip\""
                ),
            },
        )

    @router.delete("/me", status_code=204)
    def delete_me(
        body: DeleteMeRequest,
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        """Self-service hard delete of the calling user.

        Cascades the user's identities, tokens, and team membership.
        If the user is the captain of their current team AND no other
        members remain, the team is removed too. If other members
        remain, the captaincy is transferred to the longest-tenured
        member; the team itself stays.
        """
        user, _tok = ctx
        # Use the user's display_name as the typo-gate target — matches
        # the value the UI prompts the user to type.
        if body.confirm_display_name.strip() != (user.display_name or user.email):
            raise HTTPException(
                400,
                "confirm_display_name does not match this account's display name",
            )
        # User cleanup spans every team they are on: lone-member teams
        # are dropped along with their invites, captain-with-others
        # teams transfer captaincy to the longest-tenured remaining
        # member, plain-member teams just lose the row.
        teams_to_delete: list[str] = []
        for m in app.state_backend.list_memberships(user_id=user.user_id):
            team = app.state_backend.get_team(m.team_id)
            if team is None:
                continue
            others = [
                row
                for row in app.state_backend.list_memberships(team_id=team.team_id)
                if row.user_id != user.user_id
            ]
            if not others:
                teams_to_delete.append(team.team_id)
            elif team.captain_user_id == user.user_id:
                others.sort(key=lambda row: row.joined_at)
                new_captain = others[0].user_id
                app.state_backend.put_team(
                    team.team_id,
                    team.model_copy(update={"captain_user_id": new_captain}),
                )
        deleted = app.state_backend.delete_user(user.user_id)
        if not deleted:
            log.info(
                "User already deleted by a concurrent caller",
                user_id=user.user_id,
            )
        else:
            log.info(
                "User self-deleted",
                user_id=user.user_id,
                email=user.email,
            )
        for team_id in teams_to_delete:
            if app.state_backend.delete_team(team_id):
                from ctfy.server.team_signal import emit_team_deleted

                emit_team_deleted(
                    app, team_id=team_id, team_name=user.display_name
                )
        return Response(status_code=204)

    return router


__all__ = ["create_router", "_me_response", "_user_aggregates"]
