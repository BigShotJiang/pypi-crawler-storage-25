"""Admin dashboard aggregates — overview counters + solve matrix.

These endpoints answer "what's the whole system doing right now?" in a
single request each, saving the admin UI from orchestrating four
separate calls (nodes / teams / scoreboard / solves) just to render a
landing page.
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import paginate as list_paginate

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.constants import HEARTBEAT_TIMEOUT
from ctfy.core.enums import DIFFICULTY_RANK, InstanceStatus, PlatformEvent
from ctfy.core.state.models import NodeHealthSample
from ctfy.server.app_state import AppState
from ctfy.core.exceptions import ChallengeNotFoundError
from ctfy.server.timeseries import bucket_edges, bucketize
from ctfy.server.models import (
    Activity,
    AdminChallengeLastError,
    AdminChallengeStatsRow,
    AdminChallengeTimeseries,
    AdminChallengeTimeseriesBucket,
    AdminHealthFlags,
    AdminOverview,
    AdminOverviewCounts,
    AdminRecentError,
    AdminSilentChallenge,
    AdminSolveCell,
    AdminSolveMatrix,
    AdminSolveMatrixChallenge,
    AdminSolveMatrixTeam,
    AdminStuckInstance,
    AdminTimeseries,
    AdminTimeseriesBucket,
    AdminUnhealthyNode,
    BigLimitOffsetPage,
)


# A live instance still in STARTING this long after ``requested_at`` is
# almost certainly stuck — the dispatch/poll path either lost its node
# or the bg executor died. Surface it on the Overview so an admin can
# investigate before more pile up. 60s matches the typical READY budget
# for a Docker-container challenge.
_STUCK_STARTING_THRESHOLD_S = 60.0

# Cap on the recent-errors panel; anything beyond is noise — the admin
# should be looking at the per-challenge dashboard instead.
_RECENT_ERRORS_CAP = 50

# Minimum launches a challenge needs before we'll flag it as "silent".
# Below this we don't have enough signal to be confident the challenge
# is actually broken.
_SILENT_CHALLENGE_MIN_LAUNCHES = 3


# Cap on how many archived instance records we'll scan for the per-challenge
# aggregator. 10k records covers a hard-fought CTF day (~6 launches/min for
# 24h). Beyond that the dashboard would need a rollup table anyway.
_CHALLENGE_STATS_RECORD_CAP = 10_000


def _parse_iso(s: str) -> float | None:
    """ISO 8601 → Unix seconds. Returns None on parse failure (the admin
    timeseries should silently skip a malformed row rather than 500)."""
    if not s:
        return None
    try:
        # Tolerate the trailing-Z form ctfy uses for solved_at / submitted_at.
        return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _admin_buckets(
    timestamps: list[float], edges: list[float], bucket_s: int
) -> list[AdminTimeseriesBucket]:
    """Bucketize ``timestamps`` against ``edges`` and tag the rightmost
    bucket as ``partial=True`` (it's still accumulating)."""
    counts = bucketize(timestamps, edges, bucket=bucket_s)
    last = len(edges) - 1
    return [
        AdminTimeseriesBucket(ts=edges[i], value=counts[i], partial=(i == last))
        for i in range(len(edges))
    ]


def _percentile(sorted_values: list[float], q: float) -> float:
    """Nearest-rank percentile on a *sorted* (ascending) list. Returns 0.0
    on empty input so callers don't have to special-case it."""
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    # Nearest-rank: index = ceil(q/100 * N) - 1, clamped.
    import math

    idx = max(0, min(len(sorted_values) - 1, math.ceil(q / 100.0 * len(sorted_values)) - 1))
    return float(sorted_values[idx])


def _collect_stuck_starting(app: AppState, now: float) -> list[AdminStuckInstance]:
    out: list[AdminStuckInstance] = []
    for inst in app.state_backend.list_instances():
        if inst.status != InstanceStatus.STARTING:
            continue
        if not inst.requested_at:
            continue
        stuck_for = now - inst.requested_at
        if stuck_for < _STUCK_STARTING_THRESHOLD_S:
            continue
        out.append(
            AdminStuckInstance(
                instance_id=inst.instance_id,
                challenge_id=inst.challenge_id,
                team_id=inst.team_id,
                node_id=inst.node_id,
                requested_at=inst.requested_at,
                stuck_for_s=round(stuck_for, 1),
            )
        )
    out.sort(key=lambda r: r.stuck_for_s, reverse=True)
    return out


def _collect_recent_errors(app: AppState) -> list[AdminRecentError]:
    recs = app.state_backend.list_instance_records(
        status="", offset=0, limit=_CHALLENGE_STATS_RECORD_CAP
    )
    errs = [r for r in recs if r.stop_reason == "error"]
    errs.sort(key=lambda r: r.stopped_at, reverse=True)
    return [
        AdminRecentError(
            instance_id=r.instance_id,
            challenge_id=r.challenge_id,
            team_id=r.team_id,
            node_id=r.node_id,
            error=r.error,
            stopped_at=r.stopped_at,
        )
        for r in errs[:_RECENT_ERRORS_CAP]
    ]


def _collect_unhealthy_nodes(app: AppState, now: float) -> list[AdminUnhealthyNode]:
    out: list[AdminUnhealthyNode] = []
    for n in app.state_backend.list_nodes():
        if n.healthy:
            continue
        downtime = (now - n.last_heartbeat_ts) if n.last_heartbeat_ts else 0.0
        out.append(
            AdminUnhealthyNode(
                node_id=n.node_id,
                display_name=n.display_name,
                url=n.url,
                last_heartbeat_ts=n.last_heartbeat_ts,
                downtime_s=round(max(0.0, downtime), 1),
            )
        )
    out.sort(key=lambda r: r.downtime_s, reverse=True)
    return out


def _collect_silent_challenges(app: AppState) -> list[AdminSilentChallenge]:
    """Challenges with ≥ N launches and ≥ 1 submission but zero full solves.

    Strong signal that the challenge or its flag is broken: teams keep
    spinning it up, keep submitting, and the platform never validates
    anything. No need to wait for the post-event review — surface it
    while there's still time to fix.
    """
    flag_ids_by_cid: dict[str, set[str]] = {}
    name_by_cid: dict[str, str] = {}
    for spec in app.spec_reader.iter_specs():
        flag_ids_by_cid[spec.id] = set(spec.flags)
        name_by_cid[spec.id] = spec.name

    launches_by_cid: dict[str, int] = {}
    for r in app.state_backend.list_instance_records(
        offset=0, limit=_CHALLENGE_STATS_RECORD_CAP
    ):
        launches_by_cid[r.challenge_id] = launches_by_cid.get(r.challenge_id, 0) + 1

    submissions_by_cid: dict[str, int] = {}
    for s in app.state_backend.list_submissions():
        submissions_by_cid[s.challenge_id] = (
            submissions_by_cid.get(s.challenge_id, 0) + 1
        )

    solves_by_pair: dict[tuple[str, str], set[str]] = {}
    for s in app.state_backend.list_solves():
        solves_by_pair.setdefault((s.team_id, s.challenge_id), set()).add(s.flag_id)
    full_solvers_by_cid: dict[str, set[str]] = {}
    for (tid, cid), flags in solves_by_pair.items():
        required = flag_ids_by_cid.get(cid)
        if required and flags >= required:
            full_solvers_by_cid.setdefault(cid, set()).add(tid)

    out: list[AdminSilentChallenge] = []
    for cid, launches in launches_by_cid.items():
        if launches < _SILENT_CHALLENGE_MIN_LAUNCHES:
            continue
        submissions = submissions_by_cid.get(cid, 0)
        if submissions < 1:
            continue
        if full_solvers_by_cid.get(cid):
            continue
        out.append(
            AdminSilentChallenge(
                challenge_id=cid,
                name=name_by_cid.get(cid, cid),
                launches=launches,
                submissions=submissions,
            )
        )
    out.sort(key=lambda r: (-r.launches, r.challenge_id))
    return out


def _start_of_day_utc_ts() -> float:
    """Unix ts at 00:00:00 UTC today — used to count 'solves today'."""
    now = datetime.now(timezone.utc)
    return datetime(now.year, now.month, now.day, tzinfo=timezone.utc).timestamp()


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/admin/overview",
        response_model=AdminOverview,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_overview() -> AdminOverview:
        now = time.time()
        nodes = app.state_backend.list_nodes()
        healthy = sum(
            1
            for n in nodes
            if n.last_heartbeat_ts and (now - n.last_heartbeat_ts) < HEARTBEAT_TIMEOUT
        )
        capacity = sum(n.capacity for n in nodes)
        # Source of truth is the platform's instance state, not heartbeat
        # counts: a node's local store can hold stale ERROR-status rows that
        # were never deleted, which inflates ``n.running`` and drifts away
        # from what ``/admin/instances`` and ``/meta`` show.
        running = app.state_backend.count_instances()

        teams = app.state_backend.list_teams()
        all_solves = app.state_backend.list_solves()
        day_start = _start_of_day_utc_ts()

        solves_today = 0
        for s in all_solves:
            # ``solved_at`` is an ISO string; fall through on parse failure
            # rather than crashing the endpoint.
            try:
                ts = datetime.fromisoformat(s.solved_at).timestamp()
                if ts >= day_start:
                    solves_today += 1
            except Exception:
                continue

        return AdminOverview(
            nodes=AdminOverviewCounts(total=len(nodes), healthy=healthy),
            capacity=capacity,
            running_instances=running,
            teams_total=len(teams),
            solves_total=len(all_solves),
            solves_today=solves_today,
        )

    @router.get(
        "/admin/solve-matrix",
        response_model=AdminSolveMatrix,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_solve_matrix() -> AdminSolveMatrix:
        """Full team × challenge grid.

        Rows: teams with at least one submission OR one solve (no point
        in a blank row for teams that never tried). Columns: every spec
        in ``challenges_dir`` so the matrix shows overall coverage, not
        just challenges somebody happened to touch. Cells: sparse — only
        (team, challenge) pairs with either attempts or a solve are
        emitted.
        """
        teams = {t.team_id: t for t in app.state_backend.list_teams()}
        all_solves = app.state_backend.list_solves()
        all_submissions = app.state_backend.list_submissions()

        # Build the challenge catalog first so we know how many flags each
        # challenge declares; that gates "fully solved" below.
        flag_ids_by_challenge: dict[str, set[str]] = {}
        for spec in app.spec_reader.iter_specs():
            flag_ids_by_challenge[spec.id] = set(spec.flags)

        # Group solves per (team, challenge) so each cell can check whether
        # every declared flag was captured before marking it as solved.
        solves_by_pair: dict[tuple[str, str], list] = {}
        for s in all_solves:
            solves_by_pair.setdefault((s.team_id, s.challenge_id), []).append(s)
        attempts_by_pair: dict[tuple[str, str], int] = {}
        for s in all_submissions:
            key = (s.team_id, s.challenge_id)
            attempts_by_pair[key] = attempts_by_pair.get(key, 0) + 1

        # Fully-solved pairs + per-challenge full-solve counts.
        fully_solved_pairs: dict[tuple[str, str], list] = {}
        for key, lst in solves_by_pair.items():
            required = flag_ids_by_challenge.get(key[1])
            if required and {s.flag_id for s in lst} >= required:
                fully_solved_pairs[key] = sorted(lst, key=lambda x: x.solved_at)

        full_solves_by_cid: dict[str, list[tuple[str, str]]] = {}
        for (tid, cid) in fully_solved_pairs:
            full_solves_by_cid.setdefault(cid, []).append((tid, cid))

        # First-blood per challenge: earliest final solve wins. "Final" = the
        # latest solved_at among a team's captures; first to reach that wins.
        first_blood: dict[str, str] = {}
        for cid, pairs in full_solves_by_cid.items():
            best_team = ""
            best_ts = ""
            for (tid, _) in pairs:
                # Final-flag timestamp = latest solved_at within this pair.
                final_ts = max(s.solved_at for s in fully_solved_pairs[(tid, cid)])
                if not best_ts or final_ts < best_ts:
                    best_ts = final_ts
                    best_team = tid
            if best_team:
                first_blood[cid] = best_team

        challenge_rows = []
        for spec in app.spec_reader.iter_specs():
            challenge_rows.append(
                AdminSolveMatrixChallenge(
                    challenge_id=spec.id,
                    name=spec.name,
                    category=ChallengeSpec.CATEGORY,
                    difficulty=spec.difficulty.value,
                    solves_count=len(full_solves_by_cid.get(spec.id, [])),
                )
            )
        challenge_rows.sort(key=lambda c: (DIFFICULTY_RANK.get(c.difficulty, 99), c.challenge_id))

        # Teams that have touched anything (submitted or solved).
        active_team_ids = {tid for tid, _ in solves_by_pair.keys()} | {
            tid for tid, _ in attempts_by_pair.keys()
        }
        team_rows: list[AdminSolveMatrixTeam] = []
        for tid in active_team_ids:
            t = teams.get(tid)
            team_rows.append(
                AdminSolveMatrixTeam(
                    team_id=tid,
                    name=t.name if t else tid[:8],
                    solved=sum(1 for (x, _) in fully_solved_pairs if x == tid),
                )
            )
        team_rows.sort(key=lambda t: (-t.solved, t.name))

        cells: list[AdminSolveCell] = []
        seen_pairs: set[tuple[str, str]] = set()
        for (tid, cid), solves in fully_solved_pairs.items():
            # Report the final-flag time as the challenge solve time so
            # the grid reflects when the team finished the full challenge.
            final = max(solves, key=lambda x: x.solved_at)
            cells.append(
                AdminSolveCell(
                    team_id=tid,
                    challenge_id=cid,
                    solved=True,
                    solved_at=final.solved_at,
                    solve_time_s=final.solve_time_s,
                    attempts=attempts_by_pair.get((tid, cid), final.attempts),
                    first_blood=first_blood.get(cid) == tid,
                )
            )
            seen_pairs.add((tid, cid))

        for (tid, cid), n in attempts_by_pair.items():
            if (tid, cid) in seen_pairs:
                continue
            cells.append(
                AdminSolveCell(
                    team_id=tid,
                    challenge_id=cid,
                    solved=False,
                    attempts=n,
                )
            )

        return AdminSolveMatrix(teams=team_rows, challenges=challenge_rows, cells=cells)

    @router.get(
        "/admin/challenges/stats",
        response_model=BigLimitOffsetPage[AdminChallengeStatsRow],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_challenge_stats():
        """Per-challenge launch / error / solve aggregates.

        One row per spec — empty data yields a zeroed row so admins can spot
        challenges nobody has touched (often a sign of a metadata bug). All
        math runs against ``InstanceRecord`` (lifetime archive) plus live
        ``InstanceState`` (running count); SolveState gives the solve_rate
        denominator-vs-numerator.
        """
        records = app.state_backend.list_instance_records(
            offset=0, limit=_CHALLENGE_STATS_RECORD_CAP
        )

        # Per-challenge buckets.
        records_by_cid: dict[str, list] = {}
        for rec in records:
            records_by_cid.setdefault(rec.challenge_id, []).append(rec)

        # Live running per challenge.
        running_by_cid: dict[str, int] = {}
        for inst in app.state_backend.list_instances():
            running_by_cid[inst.challenge_id] = running_by_cid.get(inst.challenge_id, 0) + 1

        # Solves grouped by (team, challenge) → flag set, used to derive
        # the "fully solved teams" count per challenge.
        flag_ids_by_cid: dict[str, set[str]] = {}
        for spec in app.spec_reader.iter_specs():
            flag_ids_by_cid[spec.id] = set(spec.flags)
        solves_by_pair: dict[tuple[str, str], set[str]] = {}
        for s in app.state_backend.list_solves():
            solves_by_pair.setdefault((s.team_id, s.challenge_id), set()).add(s.flag_id)
        full_solvers_by_cid: dict[str, set[str]] = {}
        for (tid, cid), flags in solves_by_pair.items():
            required = flag_ids_by_cid.get(cid)
            if required and flags >= required:
                full_solvers_by_cid.setdefault(cid, set()).add(tid)

        rows: list[AdminChallengeStatsRow] = []
        for spec in app.spec_reader.iter_specs():
            recs = records_by_cid.get(spec.id, [])
            launches = len(recs)
            errors = sum(1 for r in recs if r.stop_reason == "error")
            error_rate = (errors / launches) if launches else 0.0

            # Launch durations only for rows that reached READY.
            durations = [
                r.ready_at - r.requested_at
                for r in recs
                if r.requested_at and r.ready_at and r.ready_at >= r.requested_at
            ]
            sorted_durs = sorted(durations)
            avg_launch = sum(durations) / len(durations) if durations else 0.0
            p50 = _percentile(sorted_durs, 50.0)
            p95 = _percentile(sorted_durs, 95.0)

            launching_teams = {r.team_id for r in recs if r.team_id}
            solvers = full_solvers_by_cid.get(spec.id, set())
            solve_rate = (
                len(solvers) / len(launching_teams) if launching_teams else 0.0
            )

            # Most-recent error (highest stopped_at).
            error_recs = [r for r in recs if r.stop_reason == "error"]
            last_error = None
            if error_recs:
                latest = max(error_recs, key=lambda r: r.stopped_at)
                last_error = AdminChallengeLastError(
                    ts=latest.stopped_at,
                    message=latest.error,
                    instance_id=latest.instance_id,
                )

            # Newest-first launch durations for the inline sparkline.
            recent_pairs = sorted(
                (
                    (r.requested_at, r.ready_at - r.requested_at)
                    for r in recs
                    if r.requested_at and r.ready_at and r.ready_at >= r.requested_at
                ),
                key=lambda p: p[0],
                reverse=True,
            )
            recent = [round(d, 3) for _, d in recent_pairs[:20]]

            rows.append(
                AdminChallengeStatsRow(
                    challenge_id=spec.id,
                    name=spec.name,
                    difficulty=spec.difficulty.value,
                    launches=launches,
                    errors=errors,
                    error_rate=round(error_rate, 4),
                    avg_launch_s=round(avg_launch, 3),
                    p50_launch_s=round(p50, 3),
                    p95_launch_s=round(p95, 3),
                    solve_rate=round(solve_rate, 4),
                    running_count=running_by_cid.get(spec.id, 0),
                    last_error=last_error,
                    recent_launch_durations=recent,
                )
            )

        # Sort: challenges with errors first (descending error rate), then
        # by name — admins land on problems first.
        rows.sort(key=lambda r: (-r.error_rate, -r.errors, r.challenge_id))
        return list_paginate(rows)

    @router.get(
        "/admin/health-flags",
        response_model=AdminHealthFlags,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_health_flags() -> AdminHealthFlags:
        """Four panels of "things that need an admin's attention right now":
        stuck STARTING instances, recent errors, unhealthy nodes, and
        challenges with launches+submissions but zero full solves."""
        now = time.time()
        return AdminHealthFlags(
            stuck_starting=_collect_stuck_starting(app, now),
            recent_errors=_collect_recent_errors(app),
            unhealthy_nodes=_collect_unhealthy_nodes(app, now),
            silent_challenges=_collect_silent_challenges(app),
        )

    @router.get(
        "/admin/timeseries",
        response_model=AdminTimeseries,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_timeseries(
        metric: Literal[
            "launches", "submissions", "solves", "running_instances", "teams"
        ] = Query(...),
        window: int = Query(86400, ge=60, le=7 * 86400),
        bucket: int = Query(3600, ge=60, le=86400),
    ) -> AdminTimeseries:
        """Bucketed counts for the admin Overview pulse charts.

        Window is anchored at ``now`` and walked backward into evenly-
        sized buckets; the response is oldest-first so the frontend can
        render left-to-right with the right edge as ``now``. The
        rightmost bucket is in-progress and tagged ``partial=True``.
        """
        edges = bucket_edges(now=app.clock(), window=window, bucket=bucket)
        start = edges[0] - bucket
        last_idx = len(edges) - 1

        buckets: list[AdminTimeseriesBucket]
        if metric == "launches":
            recs = app.state_backend.list_instance_records(
                offset=0, limit=_CHALLENGE_STATS_RECORD_CAP, since_ts=start
            )
            timestamps = [r.requested_at for r in recs if r.requested_at]
            buckets = _admin_buckets(timestamps, edges, bucket)
        elif metric == "submissions":
            subs = app.state_backend.list_submissions()
            timestamps = []
            for s in subs:
                ts = _parse_iso(s.submitted_at)
                if ts is not None and ts >= start:
                    timestamps.append(ts)
            buckets = _admin_buckets(timestamps, edges, bucket)
        elif metric == "solves":
            solves = app.state_backend.list_solves()
            timestamps = []
            for s in solves:
                ts = _parse_iso(s.solved_at)
                if ts is not None and ts >= start:
                    timestamps.append(ts)
            buckets = _admin_buckets(timestamps, edges, bucket)
        elif metric == "teams":
            # Cumulative team-registration count at each bucket edge.
            # Unlike the rate metrics above (which count events per
            # bucket), this is a stock — it monotonically increases as
            # new teams sign up — so the line answers "how did the
            # player base grow over the window?". Teams without a
            # parseable `created_at` (legacy rows) contribute to every
            # bucket so the line still ends at the live total.
            teams = app.state_backend.list_teams()
            registered_ts: list[float] = []
            legacy = 0
            for team in teams:
                ts = _parse_iso(team.created_at)
                if ts is None:
                    legacy += 1
                    continue
                registered_ts.append(ts)
            registered_ts.sort()
            buckets = []
            for i, edge in enumerate(edges):
                # Walk the sorted list once per pass; teams_total is
                # bounded by the cluster size (small) so this is fine.
                count = sum(1 for ts in registered_ts if ts <= edge) + legacy
                buckets.append(
                    AdminTimeseriesBucket(
                        ts=edge, value=count, partial=(i == last_idx)
                    )
                )
        else:  # running_instances
            recs = app.state_backend.list_instance_records(
                offset=0, limit=_CHALLENGE_STATS_RECORD_CAP
            )
            live = app.state_backend.list_instances()
            buckets = []
            for i, edge in enumerate(edges):
                count = 0
                for r in recs:
                    if r.requested_at and r.requested_at <= edge:
                        if not r.stopped_at or r.stopped_at >= edge:
                            count += 1
                for inst in live:
                    if inst.requested_at and inst.requested_at <= edge:
                        count += 1
                buckets.append(
                    AdminTimeseriesBucket(
                        ts=edge, value=count, partial=(i == last_idx)
                    )
                )

        return AdminTimeseries(
            metric=metric, window_s=window, bucket_s=bucket, buckets=buckets
        )

    @router.get(
        "/admin/challenges/{challenge_id}/timeseries",
        response_model=AdminChallengeTimeseries,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_challenge_timeseries(
        challenge_id: str,
        window: int = Query(86400, ge=60, le=7 * 86400),
        bucket: int = Query(3600, ge=60, le=86400),
    ) -> AdminChallengeTimeseries:
        """Per-bucket launches / errors / launch-duration percentiles for
        one challenge.

        Powers the row-level drawer on /admin/challenges. We compute
        everything in a single sweep over the challenge's archived
        records so the frontend can render two charts (error-rate and
        p50/p95 latency) without a follow-up request.
        """
        # 404 early if the spec doesn't exist — keeps the response shape
        # honest and avoids returning a confidently-empty time series for
        # a typo'd challenge id.
        if not any(
            spec.id == challenge_id
            for spec in app.spec_reader.iter_specs(challenge_id=challenge_id)
        ):
            raise ChallengeNotFoundError(challenge_id)

        edges = bucket_edges(now=app.clock(), window=window, bucket=bucket)
        n_buckets = len(edges)
        start = edges[0] - bucket
        last_idx = n_buckets - 1

        recs = app.state_backend.list_instance_records(
            challenge_id=challenge_id,
            offset=0,
            limit=_CHALLENGE_STATS_RECORD_CAP,
            since_ts=start,
        )

        # Per-bucket accumulators. Holding raw durations until the end so
        # we can do a single sort + percentile pass per bucket.
        launches_per: list[int] = [0] * n_buckets
        errors_per: list[int] = [0] * n_buckets
        durations_per: list[list[float]] = [[] for _ in range(n_buckets)]

        for r in recs:
            ts = r.requested_at
            if not ts or ts <= start or ts > edges[-1]:
                continue
            idx = int((ts - start - 1) // bucket)
            if not 0 <= idx < n_buckets:
                continue
            launches_per[idx] += 1
            if r.stop_reason == "error":
                errors_per[idx] += 1
            if r.requested_at and r.ready_at and r.ready_at >= r.requested_at:
                durations_per[idx].append(r.ready_at - r.requested_at)

        out: list[AdminChallengeTimeseriesBucket] = []
        for i, edge in enumerate(edges):
            launches = launches_per[i]
            errors = errors_per[i]
            sorted_durs = sorted(durations_per[i])
            out.append(
                AdminChallengeTimeseriesBucket(
                    ts=edge,
                    launches=launches,
                    errors=errors,
                    error_rate=round(errors / launches, 4) if launches else 0.0,
                    p50_launch_s=round(_percentile(sorted_durs, 50.0), 3),
                    p95_launch_s=round(_percentile(sorted_durs, 95.0), 3),
                    partial=(i == last_idx),
                )
            )

        return AdminChallengeTimeseries(
            challenge_id=challenge_id,
            window_s=window,
            bucket_s=bucket,
            buckets=out,
        )

    @router.get(
        "/admin/nodes/{node_id}/health-history",
        response_model=BigLimitOffsetPage[NodeHealthSample],
        dependencies=[Depends(app.require_admin)],
    )
    def node_health_history(node_id: str):
        """Uptime-kuma-style history for a single node.

        Returns oldest-first samples paginated via ``BigLimitOffsetPage``;
        callers render the series left-to-right so the newest sample sits
        at the right edge. The backend caps the materialised set at 10000
        rows (the page max) so deep pages still hit something while
        bounding memory.
        """
        rows = app.state_backend.list_health_samples(node_id, limit=10_000)
        return list_paginate(rows)

    @router.get(
        "/admin/nodes/{node_id}/events",
        response_model=list[Activity],
        dependencies=[Depends(app.require_admin)],
    )
    def node_events(node_id: str, limit: int = 50) -> list[Activity]:
        """Lifecycle events for a single node — newest-first.

        Pulls the recent ``node_*`` activity rows (registered, unhealthy,
        recovered, removed, updated) and filters them by the embedded
        ``detail.node_id`` payload field. The list_activities query API
        doesn't index payload fields, so we fetch a generous batch and
        filter in Python — fine at the expected event volume (a busy
        cluster might churn out ≪ 1k node lifecycle events per year).
        """
        limit = max(1, min(limit, 200))
        events = (
            PlatformEvent.NODE_REGISTERED.value,
            PlatformEvent.NODE_UNHEALTHY.value,
            PlatformEvent.NODE_RECOVERED.value,
            PlatformEvent.NODE_REMOVED.value,
            PlatformEvent.NODE_UPDATED.value,
        )
        rows = app.state_backend.list_activities(
            events=events,
            offset=0,
            limit=500,
        )
        matched = [r for r in rows if r.detail.node_id == node_id][:limit]
        return [Activity(**r.model_dump()) for r in matched]

    return router
