"""Per-competition team routes.

Surface (in-page registration + captain CRUD on
``/competitions/{id}``):

* ``POST /competitions/{competition_id}/teams`` —
  ``mode="solo"`` mints a 1-person team named after the user;
  ``mode="create"`` mints a multi-user team with caller as captain.
* ``POST /competitions/{competition_id}/teams/redeem`` — joins an
  existing comp team via an invite code the captain minted.
* ``POST /competitions/{competition_id}/invites`` — captain mints
  a join code (max_uses + ttl_seconds tunable).
* ``GET /competitions/{competition_id}/invites`` — captain lists.
* ``DELETE /competitions/{competition_id}/invites/{invite_id}`` —
  captain revokes.

Routes are thin: they translate request bodies to the atomic
backend ops (Phase 2b/2c) and map the typed status strings to HTTP.
The user → membership → team resolution lives on
``app.get_current_team_for_competition`` (Phase 2d).
"""

from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from fastapi_pagination import paginate as list_paginate
from pydantic import Field

from ctfy.core.log import log
from ctfy.core.models import CtfyModel
from ctfy.core.state.models import TeamInviteState, TeamState, UserState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.models import BigLimitOffsetPage, TeamDetail, TeamInfo
from ctfy.server.routes.teams import _member_infos, team_info as _team_info


# Codes are short enough for humans to retype but wide enough to resist
# guessing: 8 chars from base32 (≈40 bits of entropy).
_CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"  # no 0/1/I/L/O


def _emit_team_registered_and_backfill_linked_badges(
    app: AppState, user: UserState, team: TeamState
) -> None:
    """Common post-registration side effects: fire ``TEAM_REGISTERED``
    so the achievement engine and activity feed pick it up, and
    retroactively grant ``linked_<provider>`` for every OAuth
    identity the user already has bound (the user might have signed
    in via OAuth before having any team to credit the badge to).
    """
    from ctfy.server.achievements.catalog import get as get_catalog_entry
    from ctfy.server.event_payloads import (
        AchievementUnlockedPayload,
        TeamRegisteredPayload,
    )
    from ctfy.server.events import emit_event

    actor_name = user.display_name or user.email or user.user_id
    emit_event(
        app,
        TeamRegisteredPayload(
            team_id=team.team_id,
            team_name=team.name,
            ip="",
        ),
        actor_id=user.user_id,
        actor_name=actor_name,
        actor_type="team",
    )
    # Retroactive linked-provider grants. Each linked OAuth identity
    # earns its team a ``linked_<provider>`` badge — we run this on
    # team formation so a user who signed in days before joining a
    # comp still picks up the badge for the team they create / join.
    seen_providers: set[str] = set()
    for ident in app.state_backend.list_identities_for_user(user.user_id):
        if ident.provider in seen_providers:
            continue
        seen_providers.add(ident.provider)
        ach = get_catalog_entry(f"linked_{ident.provider}")
        if ach is None:
            continue
        record = app.state_backend.grant_achievement(
            team.team_id,
            ach.id,
            context={"source": "oauth_link", "provider": ident.provider},
        )
        if record is not None:
            emit_event(
                app,
                AchievementUnlockedPayload(
                    team_id=team.team_id,
                    team_name=team.name,
                    achievement_id=ach.id,
                    achievement_name=ach.name,
                    tier=ach.tier,
                    secret=ach.secret,
                ),
                actor_id=user.user_id,
                actor_name=actor_name,
                actor_type="team",
            )


class TeamInviteInfo(CtfyModel):
    """Public projection of a :class:`TeamInviteState`. Surfaces on
    captain CRUD endpoints. ``active`` is server-derived from the
    expires/use/revoked triple; ``competition_id`` lets the UI label
    invites per-comp.

    ``kind`` discriminates code-style (anyone-with-the-code) invites
    from directed invites/requests; ``target_user_id`` is the
    recipient for ``kind="direct"`` (set at mint time) and the
    requester for ``kind="join_request"`` (set when a member opens
    a request).
    """

    invite_id: str
    code: str
    team_id: str
    created_by_user_id: str
    created_at: str
    expires_at: str
    max_uses: int
    use_count: int
    revoked_at: str
    active: bool = True
    competition_id: str = ""
    kind: Literal["code", "direct", "join_request"] = "code"
    target_user_id: str = ""


def _to_invite_info(inv, *, now_iso_str: str) -> TeamInviteInfo:
    expired = bool(inv.expires_at and inv.expires_at <= now_iso_str)
    exhausted = bool(inv.max_uses and inv.use_count >= inv.max_uses)
    revoked = bool(inv.revoked_at)
    return TeamInviteInfo(
        invite_id=inv.invite_id,
        code=inv.code,
        team_id=inv.team_id,
        created_by_user_id=inv.created_by_user_id,
        created_at=inv.created_at,
        expires_at=inv.expires_at,
        max_uses=inv.max_uses,
        use_count=inv.use_count,
        revoked_at=inv.revoked_at,
        active=not (expired or exhausted or revoked),
        competition_id=inv.competition_id,
        kind=inv.kind,
        target_user_id=inv.target_user_id,
    )


# ---------------------------------------------------------------------------
# Inline request models — only used here.
# ---------------------------------------------------------------------------


class RegisterRequest(CtfyModel):
    """Body for ``POST /competitions/{id}/teams``.

    ``mode="solo"`` mints a 1-person team auto-named from the user's
    display name (``"<display>'s team"``). ``mode="create"`` mints
    a multi-user team with caller-supplied ``name`` (+ optional
    ``description``); the caller becomes captain.
    """

    mode: Literal["solo", "create"] = "solo"
    name: str = Field(default="", min_length=0, max_length=80)
    description: str = Field(default="", max_length=2000)


class RedeemRequest(CtfyModel):
    """Body for ``POST /competitions/{id}/teams/redeem``."""

    code: str = Field(min_length=1, max_length=64)


class TeamUpdate(CtfyModel):
    """Body for ``PATCH /competitions/{id}/team``. All fields
    optional; omitted fields keep their existing value."""

    name: str | None = Field(default=None, min_length=1, max_length=80)
    description: str | None = Field(default=None, max_length=2000)


class InviteCreate(CtfyModel):
    """Body for ``POST /competitions/{id}/invites``.

    ``max_uses=0`` means unlimited; ``ttl_seconds=0`` means never
    expires (use sparingly — non-expiring invites are credentials
    waiting to leak). Defaults give a single-use code valid for 24h.
    """

    max_uses: int = Field(default=1, ge=0, le=100)
    ttl_seconds: int = Field(default=24 * 3600, ge=0, le=30 * 24 * 3600)


class DirectInviteCreate(CtfyModel):
    """Body for ``POST /competitions/{id}/invites/direct``. The
    captain types the recipient's email exactly; the lookup is
    case-insensitive but otherwise unforgiving (no fuzzy match,
    no enumeration vectors).
    """

    email: str = Field(min_length=3, max_length=320)


def _gen_code() -> str:
    return "".join(secrets.choice(_CODE_ALPHABET) for _ in range(8))


def _solo_team_name(user: UserState) -> str:
    base = (user.display_name or user.email or "Player").strip()
    suffix = "'s team"
    if base.endswith(suffix):
        return base
    return f"{base}{suffix}"


def _team_detail(app: AppState, team) -> TeamDetail:
    info = _team_info(app, team)
    return TeamDetail(**info.model_dump(), members=_member_infos(app, team))


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.post(
        "/competitions/{competition_id}/teams",
        response_model=TeamDetail,
        status_code=201,
    )
    def register_for_competition(
        competition_id: str,
        body: RegisterRequest,
        user: UserState = Depends(app.get_current_user),
    ):
        """In-page registration entry point. Solo or named team."""
        comp = app.state_backend.get_competition(competition_id)
        if comp is None:
            raise HTTPException(404, f"Competition not found: {competition_id}")
        if comp.ends_at and comp.ends_at <= now_iso():
            raise HTTPException(409, "Competition has ended")
        # Already-on-a-team check: ``create`` mode rejects (a 409 the
        # UI translates to "switch teams via leave + redeem"); ``solo``
        # mode is idempotent and returns the existing team. The atomic
        # op enforces this even under concurrency, but we surface a
        # clean 409 for ``create`` here so the caller's named-team
        # request isn't silently swallowed.
        existing = app.state_backend.get_membership_for_competition(
            user.user_id, competition_id
        )
        if existing is not None and body.mode == "create":
            raise HTTPException(
                409,
                detail={
                    "error": "already_member",
                    "competition_id": competition_id,
                    "team_id": existing.team_id,
                },
            )
        if body.mode == "create":
            if not body.name.strip():
                raise HTTPException(422, "name is required for mode=create")
            team_name = body.name.strip()
            joined_via = "create"
            description = body.description
        else:
            team_name = _solo_team_name(user)
            joined_via = "solo"
            description = ""
        team = app.state_backend.create_team_for_competition(
            user_id=user.user_id,
            competition_id=competition_id,
            team_name=team_name,
            description=description,
            now_iso=now_iso(),
            joined_via=joined_via,
        )
        log.info(
            "Competition team registered",
            competition_id=competition_id,
            team_id=team.team_id,
            user_id=user.user_id,
            mode=body.mode,
        )
        _emit_team_registered_and_backfill_linked_badges(app, user, team)
        return _team_detail(app, team)

    @router.post(
        "/competitions/{competition_id}/teams/redeem",
        response_model=TeamDetail,
    )
    def redeem_invite(
        competition_id: str,
        body: RedeemRequest,
        user: UserState = Depends(app.get_current_user),
    ):
        """Join an existing comp team via an invite code."""
        comp = app.state_backend.get_competition(competition_id)
        if comp is None:
            raise HTTPException(404, f"Competition not found: {competition_id}")
        if comp.ends_at and comp.ends_at <= now_iso():
            raise HTTPException(409, "Competition has ended")
        team, status = app.state_backend.redeem_team_invite_for_competition(
            code=body.code,
            user_id=user.user_id,
            competition_id=competition_id,
            now_iso=now_iso(),
        )
        if status == "ok":
            log.info(
                "Competition team joined via invite",
                competition_id=competition_id,
                team_id=team.team_id,
                user_id=user.user_id,
            )
            _emit_team_registered_and_backfill_linked_badges(app, user, team)
            return _team_detail(app, team)
        if status == "unknown_code":
            raise HTTPException(404, "Unknown invite code")
        # Typed bodies for the UI to render specific messaging.
        raise HTTPException(
            409,
            detail={
                "error": status,
                "competition_id": competition_id,
            },
        )

    @router.post(
        "/competitions/{competition_id}/invites",
        response_model=TeamInviteInfo,
        status_code=201,
    )
    def mint_invite(
        competition_id: str,
        body: InviteCreate,
        captain: tuple[TeamState, UserState] = Depends(app.require_team_captain),
    ):
        """Captain mints a join code for their team in this comp."""
        team, user = captain
        ts = now_iso()
        expires_at = ""
        if body.ttl_seconds:
            expires_at = (
                datetime.now(timezone.utc) + timedelta(seconds=body.ttl_seconds)
            ).isoformat()
        # Generate a unique code with a few retries; the alphabet is
        # large enough that collisions are vanishingly rare, but the
        # backend's UNIQUE constraint catches them either way.
        for _ in range(5):
            code = _gen_code()
            if app.state_backend.get_team_invite_by_code(code) is None:
                break
        else:
            raise HTTPException(500, "Could not allocate invite code")
        inv = TeamInviteState(
            invite_id=secrets.token_urlsafe(12),
            team_id=team.team_id,
            code=code,
            created_by_user_id=user.user_id,
            created_at=ts,
            expires_at=expires_at,
            max_uses=body.max_uses,
            use_count=0,
            competition_id=competition_id,
        )
        app.state_backend.put_team_invite(inv)
        log.info(
            "Per-comp team invite minted",
            competition_id=competition_id,
            team_id=team.team_id,
            invite_id=inv.invite_id,
            max_uses=body.max_uses,
            ttl_seconds=body.ttl_seconds,
        )
        return _to_invite_info(inv, now_iso_str=ts)

    @router.get(
        "/competitions/{competition_id}/invites",
        response_model=BigLimitOffsetPage[TeamInviteInfo],
    )
    def list_invites(
        competition_id: str,
        captain: tuple[TeamState, UserState] = Depends(app.require_team_captain),
    ):
        team, _user = captain
        ts = now_iso()
        rows = [
            _to_invite_info(i, now_iso_str=ts)
            for i in app.state_backend.list_team_invites(team_id=team.team_id)
        ]
        return list_paginate(rows)

    @router.delete("/competitions/{competition_id}/invites/{invite_id}")
    def revoke_invite(
        competition_id: str,
        invite_id: str,
        captain: tuple[TeamState, UserState] = Depends(app.require_team_captain),
    ):
        team, _user = captain
        inv = app.state_backend.get_team_invite(invite_id)
        # Defensive: invite must belong to *this* team (and therefore
        # to this comp). Cross-team revoke attempt → 404.
        if inv is None or inv.team_id != team.team_id:
            raise HTTPException(404, "Invite not found")
        if inv.revoked_at:
            return {"status": "already_revoked"}
        app.state_backend.revoke_team_invite(invite_id, now_iso())
        return {"status": "revoked"}

    @router.post(
        "/competitions/{competition_id}/invites/direct",
        response_model=TeamInviteInfo,
        status_code=201,
    )
    def mint_direct_invite(
        competition_id: str,
        body: DirectInviteCreate,
        captain: tuple[TeamState, UserState] = Depends(app.require_team_captain),
    ):
        """Captain invites a specific user by exact email. Only that
        user can accept; everyone else gets ``not_invited``.

        Privacy: the email is matched exactly (case-insensitive) and
        the failure path returns a single typed error so this isn't
        a fuzzy-search side-channel.
        """
        team, user = captain
        target = app.state_backend.get_user_by_email(body.email.strip())
        if target is None:
            raise HTTPException(
                404,
                detail={
                    "error": "user_not_found",
                    "competition_id": competition_id,
                },
            )
        if target.user_id == user.user_id:
            raise HTTPException(
                400,
                detail={
                    "error": "cannot_invite_self",
                    "competition_id": competition_id,
                },
            )
        existing_membership = (
            app.state_backend.get_membership_for_competition(
                target.user_id, competition_id
            )
        )
        if existing_membership is not None:
            raise HTTPException(
                409,
                detail={
                    "error": "already_on_team",
                    "competition_id": competition_id,
                    "team_id": existing_membership.team_id,
                },
            )
        # Reject duplicate pending direct invite (same captain team
        # + same target). Captain can revoke + re-mint if they want
        # to refresh the invite.
        for prior in app.state_backend.list_team_invites(
            team_id=team.team_id
        ):
            if (
                prior.kind == "direct"
                and prior.target_user_id == target.user_id
                and not prior.revoked_at
                and (
                    not prior.max_uses
                    or prior.use_count < prior.max_uses
                )
            ):
                raise HTTPException(
                    409,
                    detail={
                        "error": "invite_already_pending",
                        "invite_id": prior.invite_id,
                    },
                )
        ts = now_iso()
        # Direct invites still need a unique ``code`` to satisfy the
        # UNIQUE constraint on the column; the value is internal
        # (the captain UI doesn't surface it as a sharable string)
        # and serves as the redeem key behind the per-recipient
        # accept route.
        for _ in range(5):
            code = _gen_code()
            if app.state_backend.get_team_invite_by_code(code) is None:
                break
        else:
            raise HTTPException(500, "Could not allocate invite code")
        inv = TeamInviteState(
            invite_id=secrets.token_urlsafe(12),
            team_id=team.team_id,
            code=code,
            created_by_user_id=user.user_id,
            created_at=ts,
            # Single-use, no expiry — the captain revokes if the
            # target stops responding.
            max_uses=1,
            use_count=0,
            competition_id=competition_id,
            kind="direct",
            target_user_id=target.user_id,
        )
        app.state_backend.put_team_invite(inv)
        log.info(
            "Direct invite minted",
            competition_id=competition_id,
            team_id=team.team_id,
            invite_id=inv.invite_id,
            captain_user_id=user.user_id,
            target_user_id=target.user_id,
        )
        return _to_invite_info(inv, now_iso_str=ts)

    @router.post(
        "/competitions/{competition_id}/invites/{invite_id}/accept",
        response_model=TeamDetail,
    )
    def accept_direct_invite(
        competition_id: str,
        invite_id: str,
        user: UserState = Depends(app.get_current_user),
    ):
        """Recipient of a direct invite accepts → joins the team.
        ``not_invited`` 403 if the calling user is not the named
        target; ``wrong_invite_kind`` 409 if someone tries to
        accept a code-style invite via this route.
        """
        comp = app.state_backend.get_competition(competition_id)
        if comp is None:
            raise HTTPException(404, f"Competition not found: {competition_id}")
        if comp.ends_at and comp.ends_at <= now_iso():
            raise HTTPException(409, "Competition has ended")
        inv = app.state_backend.get_team_invite(invite_id)
        if inv is None or inv.competition_id != competition_id:
            raise HTTPException(404, "Invite not found")
        if inv.kind != "direct":
            raise HTTPException(
                409,
                detail={
                    "error": "wrong_invite_kind",
                    "kind": inv.kind,
                },
            )
        if inv.target_user_id != user.user_id:
            raise HTTPException(
                403,
                detail={
                    "error": "not_invited",
                },
            )
        team, status = app.state_backend.redeem_team_invite_for_competition(
            code=inv.code,
            user_id=user.user_id,
            competition_id=competition_id,
            now_iso=now_iso(),
            joined_via="direct_invite_accepted",
        )
        if status == "ok":
            log.info(
                "Direct invite accepted",
                competition_id=competition_id,
                invite_id=invite_id,
                user_id=user.user_id,
                team_id=team.team_id,
            )
            return _team_detail(app, team)
        raise HTTPException(
            409,
            detail={
                "error": status,
                "competition_id": competition_id,
            },
        )

    @router.post(
        "/competitions/{competition_id}/invites/{invite_id}/decline"
    )
    def decline_direct_invite(
        competition_id: str,
        invite_id: str,
        user: UserState = Depends(app.get_current_user),
    ):
        """Recipient declines → invite is marked revoked. The captain
        can re-mint after revocation. Same auth contract as accept:
        only the named target can decline."""
        inv = app.state_backend.get_team_invite(invite_id)
        if inv is None or inv.competition_id != competition_id:
            raise HTTPException(404, "Invite not found")
        if inv.kind != "direct":
            raise HTTPException(
                409, detail={"error": "wrong_invite_kind", "kind": inv.kind}
            )
        if inv.target_user_id != user.user_id:
            raise HTTPException(403, detail={"error": "not_invited"})
        if inv.revoked_at:
            return {"status": "already_revoked"}
        app.state_backend.revoke_team_invite(invite_id, now_iso())
        log.info(
            "Direct invite declined",
            competition_id=competition_id,
            invite_id=invite_id,
            user_id=user.user_id,
        )
        return {"status": "declined"}

    # ── join requests (member → captain) ──────────────────────────────────

    @router.get(
        "/competitions/{competition_id}/teams/search",
        response_model=BigLimitOffsetPage[TeamInfo],
    )
    def search_competition_teams(
        competition_id: str,
        q: str = "",
        user: UserState = Depends(app.get_current_user),
    ):
        """Substring (case-insensitive) name match or exact ``team_id``.

        Blank ``q`` returns no rows — we don't want this endpoint
        becoming a "list every team's roster" enumeration vector.
        Authenticated users only.
        """
        comp = app.state_backend.get_competition(competition_id)
        if comp is None:
            raise HTTPException(404, f"Competition not found: {competition_id}")
        needle = q.strip()
        if not needle:
            return list_paginate([])
        needle_lower = needle.lower()
        rows: list[TeamInfo] = []
        for team in app.state_backend.list_teams(
            competition_id=competition_id
        ):
            if (
                team.team_id == needle
                or needle_lower in team.name.lower()
            ):
                rows.append(_team_info(app, team))
        return list_paginate(rows)

    @router.post(
        "/competitions/{competition_id}/teams/{team_id}/join-request",
        response_model=TeamInviteInfo,
        status_code=201,
    )
    def open_join_request(
        competition_id: str,
        team_id: str,
        user: UserState = Depends(app.get_current_user),
    ):
        """Member opens a request to join a specific team. Captain
        sees it in their inbox and approves/rejects."""
        comp = app.state_backend.get_competition(competition_id)
        if comp is None:
            raise HTTPException(404, f"Competition not found: {competition_id}")
        target_team = app.state_backend.get_team(team_id)
        if target_team is None or target_team.competition_id != competition_id:
            raise HTTPException(404, "Team not found")
        existing = app.state_backend.get_membership_for_competition(
            user.user_id, competition_id
        )
        if existing is not None:
            raise HTTPException(
                409,
                detail={
                    "error": "already_on_team",
                    "competition_id": competition_id,
                    "team_id": existing.team_id,
                },
            )
        # Reject duplicate pending request from the same user to
        # the same team. Once rejected/revoked the user can re-open.
        for prior in app.state_backend.list_team_invites(team_id=team_id):
            if (
                prior.kind == "join_request"
                and prior.created_by_user_id == user.user_id
                and not prior.revoked_at
                and (
                    not prior.max_uses
                    or prior.use_count < prior.max_uses
                )
            ):
                raise HTTPException(
                    409,
                    detail={
                        "error": "request_already_pending",
                        "invite_id": prior.invite_id,
                    },
                )
        ts = now_iso()
        # Same UNIQUE-code workaround as direct invites — generate a
        # random code so the row inserts cleanly. The value is
        # never surfaced; approve/reject act on invite_id.
        for _ in range(5):
            code = _gen_code()
            if app.state_backend.get_team_invite_by_code(code) is None:
                break
        else:
            raise HTTPException(500, "Could not allocate invite code")
        inv = TeamInviteState(
            invite_id=secrets.token_urlsafe(12),
            team_id=team_id,
            code=code,
            created_by_user_id=user.user_id,
            created_at=ts,
            max_uses=1,
            use_count=0,
            competition_id=competition_id,
            kind="join_request",
            target_user_id=user.user_id,
        )
        app.state_backend.put_team_invite(inv)
        log.info(
            "Join request opened",
            competition_id=competition_id,
            team_id=team_id,
            invite_id=inv.invite_id,
            requesting_user_id=user.user_id,
        )
        return _to_invite_info(inv, now_iso_str=ts)

    @router.post(
        "/competitions/{competition_id}/invites/{invite_id}/approve",
        response_model=TeamDetail,
    )
    def approve_join_request(
        competition_id: str,
        invite_id: str,
        captain: tuple[TeamState, UserState] = Depends(app.require_team_captain),
    ):
        """Captain approves a pending join request → requester joins
        the team. ``wrong_invite_kind`` 409 if someone tries to
        approve a code/direct invite via this route."""
        team, user = captain
        inv = app.state_backend.get_team_invite(invite_id)
        if inv is None or inv.team_id != team.team_id:
            raise HTTPException(404, "Invite not found")
        if inv.kind != "join_request":
            raise HTTPException(
                409,
                detail={
                    "error": "wrong_invite_kind",
                    "kind": inv.kind,
                },
            )
        joined_team, status = (
            app.state_backend.redeem_team_invite_for_competition(
                code=inv.code,
                user_id=inv.created_by_user_id,
                competition_id=competition_id,
                now_iso=now_iso(),
                joined_via="join_request_approved",
                # Stamp the captain (the user whose action created
                # the membership) as the inviter on the audit row,
                # not the requester themselves.
                invited_by_user_id=user.user_id,
            )
        )
        if status == "ok":
            log.info(
                "Join request approved",
                competition_id=competition_id,
                team_id=team.team_id,
                invite_id=invite_id,
                captain_user_id=user.user_id,
                requesting_user_id=inv.created_by_user_id,
            )
            return _team_detail(app, joined_team)
        raise HTTPException(
            409,
            detail={
                "error": status,
                "competition_id": competition_id,
            },
        )

    @router.post(
        "/competitions/{competition_id}/invites/{invite_id}/reject"
    )
    def reject_join_request(
        competition_id: str,
        invite_id: str,
        captain: tuple[TeamState, UserState] = Depends(app.require_team_captain),
    ):
        """Captain rejects a pending join request → invite revoked."""
        team, user = captain
        inv = app.state_backend.get_team_invite(invite_id)
        if inv is None or inv.team_id != team.team_id:
            raise HTTPException(404, "Invite not found")
        if inv.kind != "join_request":
            raise HTTPException(
                409, detail={"error": "wrong_invite_kind", "kind": inv.kind}
            )
        if inv.revoked_at:
            return {"status": "already_revoked"}
        app.state_backend.revoke_team_invite(invite_id, now_iso())
        log.info(
            "Join request rejected",
            competition_id=competition_id,
            team_id=team.team_id,
            invite_id=invite_id,
            captain_user_id=user.user_id,
            requesting_user_id=inv.created_by_user_id,
        )
        return {"status": "rejected"}

    @router.patch(
        "/competitions/{competition_id}/team", response_model=TeamDetail
    )
    def rename_team(
        competition_id: str,
        body: TeamUpdate,
        captain: tuple[TeamState, UserState] = Depends(app.require_team_captain),
    ):
        """Captain-only: rename / re-describe the team."""
        team, _user = captain
        updates: dict = {}
        if body.name is not None:
            updates["name"] = body.name
        if body.description is not None:
            updates["description"] = body.description
        if updates:
            team = team.model_copy(update=updates)
            app.state_backend.put_team(team.team_id, team)
        return _team_detail(app, team)

    @router.post(
        "/competitions/{competition_id}/team/leave", status_code=204
    )
    def leave_team(
        competition_id: str,
        team: TeamState = Depends(app.get_current_team_for_competition),
        user: UserState = Depends(app.get_current_user),
    ):
        """Drop the caller's membership for this comp. If captain
        and others remain, captaincy transfers to longest-tenured
        member; if lone member, the team is deleted."""
        status = app.state_backend.remove_from_competition_team(
            user.user_id, competition_id
        )
        # Auth dep already guaranteed membership existed at request
        # entry; "not_member" here only happens under a race we don't
        # care about (idempotent leave).
        log.info(
            "Per-comp team leave",
            competition_id=competition_id,
            user_id=user.user_id,
            team_id=team.team_id,
            status=status,
        )

    @router.delete(
        "/competitions/{competition_id}/team/members/{target_user_id}",
        status_code=204,
    )
    def kick_member(
        competition_id: str,
        target_user_id: str,
        captain: tuple[TeamState, UserState] = Depends(app.require_team_captain),
    ):
        """Captain-only: drop ``target_user_id`` from the team. Self-
        kick rejected (use ``/team/leave`` for the captaincy-transfer
        path). Target user must currently be on the captain's team."""
        team, user = captain
        if target_user_id == user.user_id:
            raise HTTPException(
                400,
                "Use /competitions/{id}/team/leave to leave your own team",
            )
        target = app.state_backend.get_user(target_user_id)
        if target is None:
            raise HTTPException(404, "User not found")
        target_membership = app.state_backend.get_membership_for_competition(
            target_user_id, competition_id
        )
        if (
            target_membership is None
            or target_membership.team_id != team.team_id
        ):
            raise HTTPException(404, "User is not a member of your team")
        app.state_backend.remove_from_competition_team(
            target_user_id, competition_id
        )
        log.info(
            "Per-comp team kick",
            competition_id=competition_id,
            captain_user_id=user.user_id,
            kicked_user_id=target_user_id,
            team_id=team.team_id,
        )

    return router


__all__ = ["create_router"]
