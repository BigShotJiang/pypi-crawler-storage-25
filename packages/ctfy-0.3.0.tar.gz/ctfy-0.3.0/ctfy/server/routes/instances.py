"""Instance lifecycle endpoints."""

from __future__ import annotations

import asyncio
import time
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse, Response
from fastapi_pagination import paginate as list_paginate

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.constants import MAX_INSTANCES_PER_TEAM
from ctfy.core.enums import InstanceStatus
from ctfy.core.exceptions import (
    CapacityExceededError,
    ChallengeNotFoundError,
    InstanceNotFoundError,
)
from ctfy.core.flag import generate_flags, generate_vars, verify_flag
from ctfy.core.log import log
from ctfy.core.state.models import InstanceState, NodeState, UserState
from ctfy.server.app_state import AppState
from ctfy.server.auth import resolve_team_for_competition
from ctfy.server.event_payloads import (
    InstanceRenewedPayload,
    InstanceStartedPayload,
    InstanceStoppedPayload,
)
from ctfy.server.events import emit_event
from ctfy.server.instance_archive import is_safe_instance_id
from ctfy.server.instance_lifecycle import archive_instance_record, start_instance_async
from ctfy.server.models import (
    BigLimitOffsetPage,
    InstanceInfo,
    InstanceRecordArtifacts,
    InstanceRecordDetail,
    InstanceRecordInfo,
    InstanceRecordInfoDetail,
    InstanceStatusResponse,
    RenewResponse,
    StartRequest,
    StartResponse,
    StopResponse,
    VerifyFlagRequest,
    VerifyFlagResponse,
)
from ctfy.server.node_ops import (
    get_node_client,
    stop_all_instances_on_node,
    stop_instance_on_node,
)
from ctfy.server.request_meta import client_ip
from ctfy.server.scheduling import pick_node


def _matches_instance(
    inst: InstanceState,
    *,
    user_team_ids: set[str],
    challenge_id: str,
    status: str,
    q: str,
    competition_id: str = "",
) -> bool:
    """Filter predicate for ``GET /instances``.

    User-scoped: an instance is included when ``inst.team_id`` belongs
    to any team the calling user is currently on (across every
    competition they're registered for). Anonymous (unowned)
    instances are never exposed to an authenticated caller.
    ``competition_id``, when non-empty, scopes the listing to one
    comp — needed so a user registered for two comps doesn't see
    comp A's instances under comp B.
    """
    if inst.team_id not in user_team_ids:
        return False
    if competition_id and inst.competition_id != competition_id:
        return False
    if challenge_id and inst.challenge_id != challenge_id:
        return False
    if status and inst.status != status:
        return False
    if q and q.lower() not in (inst.challenge_id + inst.name).lower():
        return False
    return True


def _to_info(inst: InstanceState) -> InstanceInfo:
    """Project a stored InstanceState into the public InstanceInfo model.

    Renders ``description`` with per-instance ``${VAR_X}`` substitution
    using only the public vars, and exposes the public_vars dict. Private
    vars (declared in ``spec.vars`` but not ``spec.public_vars``) are
    intentionally omitted — they exist on disk but are not part of the
    contract returned to the agent.
    """
    public_var_ids: list[str] = list((inst.spec or {}).get("public_vars") or [])
    # Filter the canonical vars dict to public ids only. Tolerates
    # missing keys (legacy rows pre-vars) by yielding an empty mapping.
    public_vars = {vid: inst.vars[vid] for vid in public_var_ids if vid in inst.vars}

    raw_description = (inst.spec or {}).get("description") or ""
    description = raw_description
    if public_var_ids and raw_description:
        try:
            spec = ChallengeSpec(**(inst.spec or {}))
            description = spec.render_description(public_vars)
        except Exception:
            # Spec hydration can fail (legacy rows, schema drift); fall
            # back to the raw template rather than 500-ing the listing.
            description = raw_description

    return InstanceInfo(
        instance_id=inst.instance_id,
        challenge_id=inst.challenge_id or inst.instance_id,
        team_id=inst.team_id,
        competition_id=inst.competition_id,
        node_id=inst.node_id,
        name=inst.name,
        category=inst.category,
        difficulty=inst.difficulty,
        status=inst.status or InstanceStatus.READY,
        started_at=inst.started_at,
        ttl=inst.ttl,
        expires_at=inst.expires_at,
        services=list(inst.surface.services) if inst.surface else [],
        description=description,
        public_vars=public_vars,
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/instances", response_model=BigLimitOffsetPage[InstanceInfo])
    def list_instances(
        user: UserState | None = Depends(app.get_current_user_or_none),
        challenge_id: str = "",
        status: str = "",
        q: str = "",
        competition_id: str = "",
    ):
        # User-scoped: an authenticated caller sees instances owned by
        # any team they're currently on. ``competition_id`` further
        # narrows to one comp's team so per-comp pages don't leak
        # other comps' instances. Anonymous callers see nothing —
        # instance listings exist for ownership-aware "your running
        # instances" views, not browsing.
        if user is None:
            return list_paginate([])
        my_team_ids = {
            m.team_id
            for m in app.state_backend.list_memberships(user_id=user.user_id)
        }
        if not my_team_ids:
            return list_paginate([])
        return list_paginate(
            [
                _to_info(inst)
                for inst in app.state_backend.list_instances()
                if _matches_instance(
                    inst,
                    user_team_ids=my_team_ids,
                    challenge_id=challenge_id,
                    status=status,
                    q=q,
                    competition_id=competition_id,
                )
            ]
        )

    @router.post("/instances", response_model=StartResponse, status_code=202)
    @app.limiter.limit(app.config.rate_limit_instance_start)
    def start_instance(
        request: Request,
        req: StartRequest,
        user: UserState = Depends(app.get_current_user),
    ):
        challenge_id = req.challenge_id
        team = resolve_team_for_competition(
            app.state_backend, user, req.competition_id
        )
        team_id = team.team_id

        # Serialize capacity/duplicate checks and state write to prevent TOCTOU races
        with app.instance_start_lock:
            team_envs = sum(1 for e in app.state_backend.list_instances() if e.team_id == team_id)
            if team_envs >= MAX_INSTANCES_PER_TEAM:
                raise CapacityExceededError(
                    f"Max {MAX_INSTANCES_PER_TEAM} concurrent instances per team"
                )

            # Generate random instance_id
            instance_id = str(uuid.uuid4())

            if app.state_backend.count_instances() >= app.max_instances:
                raise CapacityExceededError("Node at capacity")

            # Look up the full challenge spec from metadata.yaml
            spec = None
            for canonical in app.spec_reader.iter_specs(challenge_id=challenge_id):
                if canonical.id == challenge_id:
                    spec = canonical.model_copy(update={"instance_id": instance_id})
                    break
            if spec is None:
                raise ChallengeNotFoundError(challenge_id)

            # Pick a healthy worker node. No node = no challenge.
            target_node = pick_node(app)
            if target_node is None:
                raise CapacityExceededError(
                    "No healthy node available. Register a node first: "
                    "`ctfy node join` or `ctfy server invite`."
                )

            # Mint flags here, on the platform. The node only gets copies
            # to inject as $FLAG_<UPPER_ID>; it never persists or verifies
            # (step 18). Constant-time comparison happens later in
            # verify_flag. Single-flag challenges yield {"main": ...}.
            flags = generate_flags(spec.flags)
            # Mint vars (private + public) the same way. Identifier-safe
            # tokens injected as $VAR_<UPPER_ID>; per-instance unique so
            # each team's challenge has a different attack surface.
            vars_ = generate_vars(list(spec.vars) + list(spec.public_vars))

            # Write initial state (starting), return immediately.
            # ``competition_id`` is sourced from the resolved per-comp
            # team rather than the request body — the request body's
            # ``competition_id`` may be empty for the unambiguous
            # single-team caller, but the team row knows the comp.
            app.state_backend.put_instance(
                instance_id,
                InstanceState(
                    instance_id=instance_id,
                    spec=spec.model_dump(),
                    challenge_id=challenge_id,
                    status=InstanceStatus.STARTING,
                    team_id=team_id,
                    competition_id=team.competition_id,
                    node_id=target_node.node_id,
                    surface=None,
                    flags=flags,
                    vars=vars_,
                    error="",
                    name=spec.name,
                    category=ChallengeSpec.CATEGORY,
                    difficulty=spec.difficulty.value,
                    requested_at=time.time(),
                ),
                ttl=req.ttl,
            )

        app.bg_executor.submit(
            start_instance_async,
            app,
            instance_id,
            proxy_output_dir=req.proxy_output_dir,
        )

        log.info("Instance starting (async)", instance=instance_id, ttl=req.ttl)
        emit_event(
            app,
            InstanceStartedPayload(
                team_id=team_id,
                challenge_id=challenge_id,
                instance_id=instance_id,
                node_id=target_node.node_id,
                ip=client_ip(request),
            ),
            actor_id=user.user_id,
            actor_name=user.display_name or user.email or user.user_id,
            actor_type="team",
        )
        return StartResponse(instance_id=instance_id, status=InstanceStatus.STARTING)

    # ``GET /instances/resolve`` is gone in 0.2 — instance_id is the
    # canonical handle now and callers track it themselves from the
    # ``StartResponse`` they got at start time.

    # -- instance operation endpoints (with ownership via require_instance) -----

    @router.get("/instances/{instance_id:path}/status", response_model=InstanceStatusResponse)
    def get_instance_status(inst: InstanceState = Depends(app.require_instance)):
        instance_id = inst.instance_id
        status = inst.status or InstanceStatus.READY
        surface = inst.surface if status == InstanceStatus.READY else None

        cert_vol = ""
        if status == InstanceStatus.READY and inst.node_id:
            node = app.state_backend.get_node(inst.node_id)
            if node:
                try:
                    with get_node_client(app, node) as nc:
                        rt = nc.get_agent_runtime(instance_id)
                    cert_vol = rt.get("ca_volume", "") or ""
                except Exception as exc:
                    log.debug(
                        "agent-runtime lookup failed",
                        instance=instance_id,
                        error=str(exc),
                    )

        return InstanceStatusResponse(
            instance_id=instance_id,
            status=status,
            attack_surface=surface,
            error=inst.error or None,
            cert_volume=cert_vol,
        )

    @router.post("/instances/{instance_id:path}/verify-flag", response_model=VerifyFlagResponse)
    @app.limiter.limit(app.config.rate_limit_verify_flag)
    def verify_flag_route(
        request: Request,
        req: VerifyFlagRequest,
        inst: InstanceState = Depends(app.require_instance),
    ):
        # /verify-flag is functionally an oracle for the same flag store as
        # /submissions but writes no submission record. Without a rate limit
        # a leaked agent token can silently brute-force candidates here while
        # bypassing /submissions' cap entirely.
        instance_id = inst.instance_id
        flag_id = verify_flag(app.state_backend, instance_id, req.claimed_flag)
        return VerifyFlagResponse(
            correct=flag_id is not None,
            flag_id=flag_id,
        )

    @router.post("/instances/{instance_id:path}/renew", response_model=RenewResponse)
    def renew_instance(
        ttl: int = 3600,
        inst: InstanceState = Depends(app.require_instance),
        user: UserState = Depends(app.get_current_user),
    ):
        instance_id = inst.instance_id
        try:
            expires_at = app.state_backend.renew_instance(instance_id, ttl)
        except KeyError:
            raise InstanceNotFoundError(instance_id)
        team_id = inst.team_id
        challenge_id = inst.challenge_id or instance_id
        log.info("TTL renewed", instance=instance_id, ttl=ttl)
        emit_event(
            app,
            InstanceRenewedPayload(
                team_id=team_id,
                challenge_id=challenge_id,
                instance_id=instance_id,
                ttl=ttl,
            ),
            actor_id=user.user_id,
            actor_name=user.display_name or user.email or user.user_id,
            actor_type="team",
        )
        return RenewResponse(instance_id=instance_id, expires_at=expires_at)

    @router.delete("/instances/{instance_id:path}", response_model=StopResponse)
    async def stop_instance(
        request: Request,
        inst: InstanceState = Depends(app.require_instance),
        user: UserState = Depends(app.get_current_user),
    ):
        instance_id = inst.instance_id
        node_id = inst.node_id
        # Capture container stdout/stderr BEFORE removing the instance — the
        # provider tears down the container on stop and the logs would be
        # lost afterwards.
        archive_instance_record(
            app,
            inst,
            status=InstanceStatus.STOPPED,
            stop_reason="user",
        )
        app.state_backend.remove_instance(instance_id)
        if node_id:
            node = app.state_backend.get_node(node_id)
            if node:
                loop = asyncio.get_running_loop()
                try:
                    await loop.run_in_executor(
                        None,
                        lambda: stop_instance_on_node(app, node, instance_id),
                    )
                except Exception as e:
                    log.error(
                        "Remote stop failed", instance=instance_id, node=node_id, error=str(e)
                    )
                    # Fall through: the platform record is already gone; the
                    # node will eventually reap or it has already.
        challenge_id = inst.challenge_id or instance_id
        stop_team_id = inst.team_id
        log.info("Instance stopped", instance=instance_id)
        emit_event(
            app,
            InstanceStoppedPayload(
                team_id=stop_team_id,
                challenge_id=challenge_id,
                instance_id=instance_id,
                node_id=node_id or "",
                ip=client_ip(request),
            ),
            actor_id=user.user_id,
            actor_name=user.display_name or user.email or user.user_id,
            actor_type="team",
        )
        return StopResponse(instance_id=instance_id)

    @router.get(
        "/admin/instances",
        response_model=BigLimitOffsetPage[InstanceInfo],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_list_instances(node_id: str = "", status: str = ""):
        """List every instance across all teams / nodes (admin only).

        Complements the team-scoped ``GET /instances``. ``node_id``
        filters to one worker — used by the admin dashboard's
        per-node instance drawer.
        """
        items = []
        for inst in app.state_backend.list_instances():
            if node_id and inst.node_id != node_id:
                continue
            if status and inst.status != status:
                continue
            items.append(_to_info(inst))
        return list_paginate(items)

    @router.get(
        "/admin/instances/{instance_id}",
        response_model=InstanceInfo,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_get_instance(instance_id: str):
        """Look up one live instance by id (admin-scoped, no team filter).

        Used by the admin live-traffic page to resolve team_id /
        challenge_id so the header can show friendly names alongside the
        bare UUID. The path parameter is validated through the same
        allowlist that protects the pcap download to keep the surface
        consistent.
        """
        if not is_safe_instance_id(instance_id):
            raise HTTPException(status_code=400, detail="invalid instance_id")
        inst = app.state_backend.get_instance(instance_id)
        if inst is None:
            raise InstanceNotFoundError(instance_id)
        return _to_info(inst)

    @router.delete(
        "/instances",
        response_model=list[StopResponse],
        dependencies=[Depends(app.require_admin)],
    )
    async def stop_all_instances():
        """Stop all running instances across every node (admin only)."""
        loop = asyncio.get_running_loop()
        results = []
        nodes_to_wipe: dict[str, NodeState] = {}
        for inst in app.state_backend.list_instances():
            instance_id = inst.instance_id
            archive_instance_record(
                app,
                inst,
                status=InstanceStatus.STOPPED,
                stop_reason="admin_stop_all",
            )
            app.state_backend.remove_instance(instance_id)
            if inst.node_id:
                node = app.state_backend.get_node(inst.node_id)
                if node:
                    nodes_to_wipe.setdefault(inst.node_id, node)
            # Triggered by `DELETE /instances` which is admin-token guarded;
            # the admin is the effective actor, not the instance's owner team.
            emit_event(
                app,
                InstanceStoppedPayload(
                    team_id=inst.team_id,
                    challenge_id=inst.challenge_id,
                    instance_id=instance_id,
                ),
                actor_id="admin",
                actor_name="admin (stop-all)",
                actor_type="admin",
            )
            results.append(StopResponse(instance_id=instance_id))

        for node in nodes_to_wipe.values():
            try:
                await loop.run_in_executor(None, lambda n=node: stop_all_instances_on_node(app, n))
            except Exception as e:
                log.error("stop-all on node failed", node=node.node_id, error=str(e))

        return results

    # -- instance traffic ------------------------------------------------

    @router.get("/instances/{instance_id:path}/traffic")
    def get_instance_traffic(inst: InstanceState = Depends(app.require_instance)):
        """Parsed mitmproxy traffic — the flow file lives on the node."""
        instance_id = inst.instance_id
        if not inst.node_id:
            return []
        node = app.state_backend.get_node(inst.node_id)
        if not node:
            return []
        try:
            with get_node_client(app, node) as nc:
                return nc.get_traffic(instance_id)
        except Exception as e:
            log.warning(
                "Remote traffic fetch failed",
                instance=instance_id,
                node=inst.node_id,
                error=str(e),
            )
            return []

    @router.get(
        "/admin/instances/{instance_id}/pcap",
        dependencies=[Depends(app.require_admin)],
    )
    def admin_get_instance_live_pcap(instance_id: str):
        """Stream the live tcpdump capture for any running instance.

        ``instance_id`` is taken from the URL path, so we validate it
        against the same allowlist that protects on-disk lookups before
        making any further calls. Defence-in-depth: even though the
        node-side endpoint also validates, an unsafe id should never
        reach this point.
        """
        if not is_safe_instance_id(instance_id):
            raise HTTPException(status_code=400, detail="invalid instance_id")
        inst = app.state_backend.get_instance(instance_id)
        if inst is None or not inst.node_id:
            raise HTTPException(status_code=404, detail="instance not found")
        node = app.state_backend.get_node(inst.node_id)
        if not node:
            raise HTTPException(status_code=404, detail="node unavailable")
        try:
            with get_node_client(app, node) as nc:
                data = nc.get_pcap(instance_id)
        except Exception as e:
            log.warning(
                "Admin live pcap fetch failed",
                instance=instance_id,
                node=inst.node_id,
                error=str(e),
            )
            raise HTTPException(status_code=502, detail="pcap unavailable") from None
        if not data:
            raise HTTPException(status_code=404, detail="no pcap captured")
        return Response(
            content=data,
            media_type="application/vnd.tcpdump.pcap",
            headers={
                # ``instance_id`` was validated above so it cannot contain
                # quotes or CRLF — Content-Disposition header injection
                # is not possible here.
                "Content-Disposition": f'attachment; filename="{instance_id}.pcap"',
            },
        )

    @router.get(
        "/admin/instances/{instance_id}/traffic",
        dependencies=[Depends(app.require_admin)],
    )
    def admin_get_instance_traffic(instance_id: str):
        """Live mitmproxy traffic for any instance (admin-scoped).

        Mirrors the team-scoped ``GET /instances/{id}/traffic`` but skips
        the ownership check so admins can browse traffic for any team's
        running instance from the admin console.
        """
        inst = app.state_backend.get_instance(instance_id)
        if inst is None:
            raise InstanceNotFoundError(instance_id)
        if not inst.node_id:
            return []
        node = app.state_backend.get_node(inst.node_id)
        if not node:
            return []
        try:
            with get_node_client(app, node) as nc:
                return nc.get_traffic(instance_id)
        except Exception as e:
            log.warning(
                "Admin remote traffic fetch failed",
                instance=instance_id,
                node=inst.node_id,
                error=str(e),
            )
            return []

    # -- admin: archived instance history ------------------------------------

    def _record_to_info(rec) -> InstanceRecordInfo:
        return InstanceRecordInfo(
            instance_id=rec.instance_id,
            team_id=rec.team_id,
            challenge_id=rec.challenge_id,
            node_id=rec.node_id,
            name=rec.name,
            category=rec.category,
            difficulty=rec.difficulty,
            status=rec.status,
            stop_reason=rec.stop_reason,
            error=rec.error,
            started_at=rec.started_at,
            stopped_at=rec.stopped_at,
            duration_s=rec.duration_s,
            ttl=rec.ttl,
            solved=rec.solved,
            attempts=rec.attempts,
            request_count=getattr(rec, "request_count", 0),
        )

    def _live_instance_to_record_detail(inst: InstanceState) -> InstanceRecordInfoDetail:
        """Synthesize an archive-shaped detail row from a live instance.

        Used by the admin detail endpoint when the instance is still
        running and therefore has no row in ``instance_records`` yet.
        Terminal-only fields (``stop_reason``, ``stopped_at``,
        ``duration_s``, ``solved``, ``attempts``, ``artifact_dir``) stay
        at their defaults — the archive will fill them in once the
        instance terminates.
        """
        return InstanceRecordInfoDetail(
            instance_id=inst.instance_id,
            team_id=inst.team_id,
            challenge_id=inst.challenge_id,
            node_id=inst.node_id,
            name=inst.name,
            category=inst.category,
            difficulty=inst.difficulty,
            status=inst.status,
            error=inst.error,
            started_at=inst.started_at,
            ttl=inst.ttl,
            spec=inst.spec or {},
            surface=inst.surface,
        )

    @router.get(
        "/admin/instance-records",
        response_model=BigLimitOffsetPage[InstanceRecordInfo],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_list_instance_records(
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
        offset: int = 0,
        limit: int = 100,
    ):
        """List every archived instance across all teams / nodes (admin only).

        Complements the in-memory ``GET /admin/instances`` — that endpoint
        shows only the live fast-path; this one surfaces the permanent
        record of everything that ever ran.
        """
        total = app.state_backend.count_instance_records(
            team_id=team_id,
            challenge_id=challenge_id,
            node_id=node_id,
            status=status,
            since_ts=since_ts,
        )
        items = [
            _record_to_info(rec)
            for rec in app.state_backend.list_instance_records(
                team_id=team_id,
                challenge_id=challenge_id,
                node_id=node_id,
                status=status,
                since_ts=since_ts,
                offset=offset,
                limit=limit,
            )
        ]
        # fastapi-pagination's LimitOffsetPage doesn't support manual
        # construction easily, so use the shared `list_paginate` helper on
        # an over-selected slice. Our list_instance_records already applies
        # the limit — pass items through and let pagination echo them.
        from fastapi_pagination import LimitOffsetParams
        from fastapi_pagination.bases import AbstractPage

        # Build a hand-rolled page to pass limit/offset + total faithfully.
        page_cls: type[AbstractPage] = BigLimitOffsetPage
        params = LimitOffsetParams(limit=limit, offset=offset)
        return page_cls.create(items=items, total=total, params=params)

    @router.get(
        "/admin/instance-records/{instance_id}",
        response_model=InstanceRecordDetail,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_get_instance_record(instance_id: str):
        # Two data sources back this endpoint:
        #   - ``instance_records`` table  → instances that have terminated
        #     and been archived (the original use case)
        #   - live ``InstanceState`` map  → instances that are still
        #     running and therefore have no archive row yet
        # Without the live fallback the admin UI's "instances" list links
        # to a 404 for every running instance, since the list itself is
        # populated from the live map.
        rec = app.state_backend.get_instance_record(instance_id)
        if rec is None:
            live = app.state_backend.get_instance(instance_id)
            if live is None:
                raise InstanceNotFoundError(instance_id)
            detail = _live_instance_to_record_detail(live)
        else:
            detail = InstanceRecordInfoDetail(
                **_record_to_info(rec).model_dump(),
                spec=rec.spec or {},
                surface=rec.surface,
                artifact_dir=rec.artifact_dir,
            )
        artifacts = InstanceRecordArtifacts()
        archive = app.instance_archive
        if archive is not None:
            artifacts = InstanceRecordArtifacts(
                has_manifest=archive.has_artifact(instance_id, "instance.json"),
                has_container_log=archive.has_artifact(instance_id, "container.log"),
                events_count=len(archive.read_events(instance_id)),
                submissions_count=len(archive.read_submissions(instance_id)),
                traffic_count=archive.count_traffic(instance_id),
                pcap_bytes=archive.pcap_size(instance_id),
            )
        return InstanceRecordDetail(record=detail, artifacts=artifacts)

    @router.get(
        "/admin/instance-records/{instance_id}/events",
        response_model=BigLimitOffsetPage[dict],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_instance_record_events(instance_id: str):
        if app.instance_archive is None:
            return list_paginate([])
        return list_paginate(app.instance_archive.read_events(instance_id, limit=0))

    @router.get(
        "/admin/instance-records/{instance_id}/submissions",
        response_model=BigLimitOffsetPage[dict],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_instance_record_submissions(instance_id: str):
        if app.instance_archive is None:
            return list_paginate([])
        return list_paginate(app.instance_archive.read_submissions(instance_id, limit=0))

    @router.get(
        "/admin/instance-records/{instance_id}/container-log",
        dependencies=[Depends(app.require_admin)],
    )
    def admin_instance_record_container_log(instance_id: str):
        logs = ""
        if app.instance_archive is not None:
            logs = app.instance_archive.read_container_log(instance_id)
        return {"instance_id": instance_id, "logs": logs}

    @router.get(
        "/admin/instance-records/{instance_id}/traffic",
        response_model=BigLimitOffsetPage[dict],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_instance_record_traffic(instance_id: str):
        """Persisted mitmproxy flows for an archived instance."""
        if app.instance_archive is None:
            return list_paginate([])
        return list_paginate(app.instance_archive.read_traffic(instance_id, limit=0))

    @router.get(
        "/admin/instance-records/{instance_id}/pcap",
        dependencies=[Depends(app.require_admin)],
    )
    def admin_instance_record_pcap(instance_id: str):
        """Stream the archived tcpdump capture for an instance.

        Two layers of defence against path traversal:
          1. ``is_safe_instance_id`` rejects anything outside
             ``[A-Za-z0-9_-]{1,64}`` (no slashes, no ``..``).
          2. ``InstanceArchive.pcap_path`` resolves the candidate path
             and verifies it stays under the archive root before
             returning it. Any failure surfaces as a 404, not a 500.
        """
        if not is_safe_instance_id(instance_id):
            raise HTTPException(status_code=400, detail="invalid instance_id")
        archive = app.instance_archive
        if archive is None:
            raise HTTPException(status_code=404, detail="archive disabled")
        path = archive.pcap_path(instance_id)
        if path is None:
            raise HTTPException(status_code=404, detail="no pcap on file")
        return FileResponse(
            path,
            media_type="application/vnd.tcpdump.pcap",
            filename=f"{instance_id}.pcap",
        )

    return router
