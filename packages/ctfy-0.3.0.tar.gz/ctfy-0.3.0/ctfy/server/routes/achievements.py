"""Achievement catalog + per-team unlock endpoints.

Public routes:
- ``GET  /achievements/catalog`` — every badge the platform can grant.
  Secret badges are filtered out unless the requesting team has
  unlocked them, preserving the easter-egg surprise.
- ``GET  /achievements/recent-unlocks`` — newest-first global feed of
  badge unlocks (secret badges filtered out so the discovery survives).
- ``GET  /teams/{team_id}/achievements`` — a team's public unlocks
  (secret badges hidden for other viewers).
- ``GET  /me/achievements`` — current team's unlocks; returns secret
  badges they have unlocked, too.
- ``POST /easter-eggs/{egg_id}/claim`` — authenticated endpoint that the
  hidden discovery pages call to grant their bound achievement.
- ``POST /me/star-gazer/verify`` — server-side check (via GitHub's
  public API) that the caller starred the project repo, granting the
  ``star_gazer`` badge on success.

Admin routes (used by the Bug Hunter workflow + one-off awards):
- ``POST   /admin/teams/{team_id}/achievements/{achievement_id}``
- ``DELETE /admin/teams/{team_id}/achievements/{achievement_id}``
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from fastapi_pagination import paginate as list_paginate

from ctfy.core.exceptions import TeamNotFoundError
from ctfy.core.models import CtfyModel
from ctfy.core.state.models import OAuthIdentity, TeamState, TeamToken, UserState
from ctfy.server.achievements.catalog import CATALOG, points_for_tier
from ctfy.server.achievements.catalog import get as get_catalog_entry
from ctfy.server.achievements.engine import compute_progress, maybe_grant_combo
from ctfy.server.achievements.github_star import (
    StarVerifyResult,
    parse_owner_repo,
    resolve_login,
    verify_star,
)
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.event_payloads import AchievementUnlockedPayload
from ctfy.server.events import emit_event
from ctfy.server.models import BigLimitOffsetPage

# Easter-egg routing table. Each key is a public slug callers POST to;
# the value is the achievement id granted on success. Keep slugs URL-safe
# kebab-case so they survive being typed by hand. Adding a new egg = one
# line here + a hidden React route that claims it.
#
# ``star-gazer`` is intentionally NOT here — earning it requires a
# server-side GitHub API check (see ``/me/star-gazer/verify``), so the
# easter-egg endpoint cannot grant it.
_EASTER_EGGS: dict[str, str] = {
    "base64-cowboy": "base64_cowboy",
}


# Per-team rate limit window for the Star Gazer verify route. Pressing
# the button rapidly should be soaked up by the verification cache, but
# we still cap how often a single team can trigger an outbound GitHub
# call. Memory-only — the limiter resets on process restart, which is
# fine because GitHub itself enforces a cluster-wide ceiling.
_STAR_VERIFY_COOLDOWN_S = 30.0
# Cache keyed by team_id → monotonic-clock timestamp of the team's last
# attempt. ``defaultdict``-equivalent to keep insertion simple.
_star_verify_last_attempt: dict[str, float] = {}


# Rarity buckets keyed off ``earned_by_count / total_teams``. Boundaries
# are inclusive on the high side: ≥50% common, ≥25% uncommon, etc. The
# "unearned" bucket exists separately so the frontend can render an
# "untouched" indicator distinct from "common but rare-by-percentage".
def _compute_rarity(count: int, total_teams: int) -> str:
    if count <= 0:
        return "unearned"
    if total_teams <= 0:
        # Edge case: an unlock exists but no team rows do — only possible
        # mid-test or just after a cascade delete. Treat as common to
        # avoid a divide-by-zero and an alarming "mythic" label.
        return "common"
    pct = count / total_teams
    if pct >= 0.5:
        return "common"
    if pct >= 0.25:
        return "uncommon"
    if pct >= 0.10:
        return "rare"
    if pct >= 0.03:
        return "epic"
    return "mythic"


class AchievementProgress(CtfyModel):
    """Quantifiable progress toward a locked badge.

    ``current`` is what the team has so far, ``target`` is the
    threshold the rule predicate checks against. Provided only when
    the achievement has a registered progress provider (decathlete,
    centurion, completionist, sisyphus, unicorn). Time-of-day /
    first-blood / easter-egg badges return ``progress = null``
    because a fractional value would be misleading rather than
    helpful.
    """

    current: int
    target: int


class AchievementCatalogEntry(CtfyModel):
    """One badge as advertised to the frontend."""

    id: str
    name: str
    description: str
    icon: str
    tier: str
    secret: bool = False
    # Only populated for locked entries on /me/achievements — the
    # general catalog endpoint and unlocked entries don't carry it.
    progress: AchievementProgress | None = None
    # Score weight for this badge (bronze=10, silver=25, gold=50,
    # secret=100). Used by the frontend to render the "Score: X / Y"
    # header without requiring a parallel client-side tier→points map.
    points: int = 0
    # Number of distinct teams that have unlocked this badge — drives the
    # "Earned by N teams" footer and the rarity chip.
    earned_by_count: int = 0
    # Coarse rarity bucket derived from earned_by_count / count_teams().
    # One of: "common", "uncommon", "rare", "epic", "mythic", "unearned".
    rarity: str = "unearned"


class TeamAchievement(CtfyModel):
    """A badge that a team has unlocked."""

    achievement_id: str
    name: str
    description: str
    icon: str
    tier: str
    secret: bool = False
    unlocked_at: str
    context: dict[str, Any] = {}
    points: int = 0
    earned_by_count: int = 0
    rarity: str = "unearned"


class AchievementSummary(CtfyModel):
    """Aggregate roll-up for the Achievements page header."""

    unlocked_count: int = 0
    total_count: int = 0
    score: int = 0
    total_score: int = 0


class MyAchievementsResponse(CtfyModel):
    """The self-view: unlocked + locked (with secret-hiding)."""

    unlocked: list[TeamAchievement] = []
    locked: list[AchievementCatalogEntry] = []
    summary: AchievementSummary = AchievementSummary()


class RecentUnlock(CtfyModel):
    """A single row in the platform-wide recent-unlocks feed."""

    team_id: str
    team_name: str
    achievement_id: str
    name: str
    icon: str
    tier: str
    unlocked_at: str


class EasterEggClaim(CtfyModel):
    """Reply for ``POST /easter-eggs/{egg_id}/claim``.

    ``already_unlocked`` lets the page tell "first time, congrats!" from
    "you've been here before" without an extra GET round-trip.
    """

    egg_id: str
    achievement: TeamAchievement
    already_unlocked: bool = False


class StarGazerVerifyResponse(CtfyModel):
    """Reply for ``POST /me/star-gazer/verify``.

    A 200 OK body with ``verified=False`` is the friendly path: the
    user can be told *why* (no_github_identity / not_starred /
    rate_limited / lookup_failed / repo_not_configured /
    limit_exceeded) without the UI having to interpret an HTTP error
    code. Hard 4xx is reserved for auth.
    """

    verified: bool
    # ``starred`` on a successful verification, otherwise one of the
    # ``StarVerifyResult`` values plus the explicit auxiliary reasons
    # the route layers on top.
    reason: str = ""
    achievement: TeamAchievement | None = None
    already_unlocked: bool = False


def _render_unlocks(
    app: AppState,
    team_id: str,
    *,
    include_secret: bool,
    counts: dict[str, int] | None = None,
    total_teams: int | None = None,
) -> list[TeamAchievement]:
    """Join stored unlocks with catalog metadata for display.

    ``counts`` and ``total_teams`` are optional pre-fetched aggregates;
    callers that already need them for the catalog block (``get_catalog``,
    ``get_my_achievements``) pass them in to avoid a second round-trip.
    For one-off use (the public team page) this helper fetches them
    itself.
    """
    if counts is None:
        counts = app.state_backend.count_unlocks_by_achievement()
    if total_teams is None:
        total_teams = app.state_backend.count_teams()
    out: list[TeamAchievement] = []
    for row in app.state_backend.list_achievements(team_id):
        ach = get_catalog_entry(row.achievement_id)
        if ach is None:
            # Stored an id that's no longer in the catalog — skip rather
            # than make the page crash. Admin can revoke it manually.
            continue
        if ach.secret and not include_secret:
            continue
        count = counts.get(ach.id, 0)
        out.append(
            TeamAchievement(
                achievement_id=row.achievement_id,
                name=ach.name,
                description=ach.description,
                icon=ach.icon,
                tier=ach.tier,
                secret=ach.secret,
                unlocked_at=row.unlocked_at,
                context=row.context,
                points=points_for_tier(ach.tier),
                earned_by_count=count,
                rarity=_compute_rarity(count, total_teams),
            )
        )
    # Sort newest-first — matches how the UI wants to show "recent wins".
    out.sort(key=lambda a: a.unlocked_at, reverse=True)
    return out


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/achievements/catalog",
        response_model=BigLimitOffsetPage[AchievementCatalogEntry],
    )
    def get_catalog(
        user: UserState | None = Depends(app.get_current_user_or_none),
    ):
        """List every catalog entry, hiding secrets the caller hasn't earned."""
        unlocked_ids: set[str] = set()
        if user is not None:
            # Aggregate unlocks across every team the caller is on so a
            # secret badge unlocked on team A still surfaces while the
            # user is browsing on team B's behalf.
            for m in app.state_backend.list_memberships(user_id=user.user_id):
                unlocked_ids.update(
                    r.achievement_id
                    for r in app.state_backend.list_achievements(m.team_id)
                )
        counts = app.state_backend.count_unlocks_by_achievement()
        total_teams = app.state_backend.count_teams()
        items: list[AchievementCatalogEntry] = []
        for ach in CATALOG:
            if ach.secret and ach.id not in unlocked_ids:
                continue
            count = counts.get(ach.id, 0)
            items.append(
                AchievementCatalogEntry(
                    id=ach.id,
                    name=ach.name,
                    description=ach.description,
                    icon=ach.icon,
                    tier=ach.tier,
                    secret=ach.secret,
                    points=points_for_tier(ach.tier),
                    earned_by_count=count,
                    rarity=_compute_rarity(count, total_teams),
                )
            )
        return list_paginate(items)

    @router.get(
        "/achievements/recent-unlocks",
        response_model=BigLimitOffsetPage[RecentUnlock],
    )
    def get_recent_unlocks():
        """Newest-first global feed of badge unlocks.

        Public (no auth) so guests browsing the achievements page see the
        same activity. Secret badges are filtered out — they'd spoil the
        discovery for anyone who hasn't found them yet — and orphan rows
        whose team or catalog entry is gone are silently skipped. Filtering
        runs before pagination so ``total`` reflects what callers can
        actually page through.
        """
        # Soft cap on candidate rows. Filtering (secret + orphan) runs in
        # Python, so we have to materialise the candidate set before
        # paginating; older unlocks beyond this cap fall off the feed.
        # Matches ``BigLimitOffsetPage`` max so a deep page can still hit
        # rows even with heavy filtering.
        out: list[RecentUnlock] = []
        for row in app.state_backend.list_recent_achievement_unlocks(10_000):
            ach = get_catalog_entry(row.achievement_id)
            if ach is None or ach.secret:
                continue
            team = app.state_backend.get_team(row.team_id)
            if team is None:
                continue
            out.append(
                RecentUnlock(
                    team_id=row.team_id,
                    team_name=team.name,
                    achievement_id=row.achievement_id,
                    name=ach.name,
                    icon=ach.icon,
                    tier=ach.tier,
                    unlocked_at=row.unlocked_at,
                )
            )
        return list_paginate(out)

    @router.get(
        "/teams/{team_id}/achievements",
        response_model=BigLimitOffsetPage[TeamAchievement],
    )
    def list_team_achievements(team_id: str):
        """Public badges for a team — secret badges are hidden from others."""
        if not app.state_backend.get_team(team_id):
            raise TeamNotFoundError(team_id)
        return list_paginate(_render_unlocks(app, team_id, include_secret=False))

    @router.get("/me/achievements", response_model=MyAchievementsResponse)
    def get_my_achievements(user: UserState = Depends(app.get_current_user)):
        """The calling user's unlocked badges (across every team they
        are on) plus the catalog entries still locked.

        Secret badges show up here once unlocked but stay out of the
        locked list so the discovery remains fun.
        """
        counts = app.state_backend.count_unlocks_by_achievement()
        total_teams = app.state_backend.count_teams()
        # Union the unlocks from every team the user is currently on —
        # achievements were earned for the team but the badge belongs
        # to the user's collection regardless of which comp they were
        # playing when they earned it. Render via the same helper, then
        # de-duplicate by achievement_id so a badge earned on multiple
        # teams shows up once.
        unlocked_by_id: dict[str, TeamAchievement] = {}
        memberships = app.state_backend.list_memberships(user_id=user.user_id)
        for m in memberships:
            for u in _render_unlocks(
                app,
                m.team_id,
                include_secret=True,
                counts=counts,
                total_teams=total_teams,
            ):
                # Keep the earliest unlock if the same badge was won on
                # more than one team.
                existing = unlocked_by_id.get(u.achievement_id)
                if existing is None or u.unlocked_at < existing.unlocked_at:
                    unlocked_by_id[u.achievement_id] = u
        unlocked = sorted(
            unlocked_by_id.values(), key=lambda u: u.unlocked_at, reverse=True
        )
        unlocked_ids = set(unlocked_by_id)
        # Pick a representative team for progress queries (some
        # progress providers hit team-scoped storage). Captain teams
        # come first so the most-recent solo team isn't chosen on a
        # multi-comp user; falls back to the first membership otherwise.
        progress_team = None
        if memberships:
            ranked = sorted(
                memberships, key=lambda m: (0 if m.joined_via == "create" else 1, m.joined_at)
            )
            progress_team = app.state_backend.get_team(ranked[0].team_id)
        locked: list[AchievementCatalogEntry] = []
        for ach in CATALOG:
            if ach.id in unlocked_ids:
                continue
            if ach.secret:
                continue
            # Pull a (current, target) tuple via the progress registry —
            # None for badges that aren't quantifiable (time-of-day,
            # first-blood, easter eggs).
            tup = (
                compute_progress(app, progress_team, ach.id)
                if progress_team is not None
                else None
            )
            progress = (
                AchievementProgress(current=tup[0], target=tup[1])
                if tup is not None
                else None
            )
            count = counts.get(ach.id, 0)
            locked.append(
                AchievementCatalogEntry(
                    id=ach.id,
                    name=ach.name,
                    description=ach.description,
                    icon=ach.icon,
                    tier=ach.tier,
                    secret=ach.secret,
                    progress=progress,
                    points=points_for_tier(ach.tier),
                    earned_by_count=count,
                    rarity=_compute_rarity(count, total_teams),
                )
            )
        # Score totals only consider non-secret badges so the denominator
        # doesn't leak secret-tier worth (100 each — would spoil the
        # surprise). Secrets the team has earned still count toward the
        # numerator so they aren't penalised for finding them.
        total_score = sum(points_for_tier(a.tier) for a in CATALOG if not a.secret)
        score = sum(u.points for u in unlocked)
        # If a team has earned a secret badge, surface its points without
        # changing the denominator — just bumps the visible score above
        # what the locked list could ever sum to. The frontend renders
        # "Score: 175 / 950" and a team that found a secret will show
        # "Score: 275 / 950" which reads as overachievement, not a bug.
        summary = AchievementSummary(
            unlocked_count=len(unlocked),
            total_count=sum(1 for a in CATALOG if not a.secret) + sum(1 for u in unlocked if u.secret),
            score=score,
            total_score=total_score,
        )
        return MyAchievementsResponse(unlocked=unlocked, locked=locked, summary=summary)

    @router.post("/easter-eggs/{egg_id}/claim", response_model=EasterEggClaim)
    def claim_easter_egg(
        egg_id: str,
        competition_id: str = "",
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        """Grant the achievement bound to a discovered easter egg.

        Hidden discovery pages (e.g. the Base64 console-puzzle landing) call
        this on mount. Idempotent: repeat visits return the same
        achievement with ``already_unlocked=True`` so the page can
        suppress the toast on a re-render.

        Pass ``competition_id`` when the caller is on more than one
        team; single-team callers leave it empty and the route picks
        the unambiguous team.
        """
        from ctfy.server.auth import resolve_team_for_competition

        achievement_id = _EASTER_EGGS.get(egg_id)
        if achievement_id is None:
            raise HTTPException(404, f"Unknown easter egg: {egg_id}")
        ach = get_catalog_entry(achievement_id)
        if ach is None:
            raise HTTPException(500, f"Easter egg points to missing achievement: {achievement_id}")
        user, _token = ctx
        team = resolve_team_for_competition(
            app.state_backend, user, competition_id
        )

        record = app.state_backend.grant_achievement(
            team.team_id,
            achievement_id,
            context={"source": "easter_egg", "egg_id": egg_id},
        )
        already_unlocked = record is None
        if record is not None:
            emit_event(
                app,
                AchievementUnlockedPayload(
                    team_id=team.team_id,
                    team_name=team.name,
                    achievement_id=ach.id,
                    achievement_name=ach.name,
                    tier=ach.tier,
                    secret=ach.secret,
                ),
                actor_id=user.user_id,
                actor_name=user.display_name or user.email or user.user_id,
                actor_type="team",
            )

        # Re-read the canonical row so we always return the recorded
        # ``unlocked_at`` (matters for repeat visits — first call wins).
        counts = app.state_backend.count_unlocks_by_achievement()
        total_teams = app.state_backend.count_teams()
        for row in app.state_backend.list_achievements(team.team_id):
            if row.achievement_id == achievement_id:
                count = counts.get(achievement_id, 0)
                return EasterEggClaim(
                    egg_id=egg_id,
                    already_unlocked=already_unlocked,
                    achievement=TeamAchievement(
                        achievement_id=row.achievement_id,
                        name=ach.name,
                        description=ach.description,
                        icon=ach.icon,
                        tier=ach.tier,
                        secret=ach.secret,
                        unlocked_at=row.unlocked_at,
                        context=row.context,
                        points=points_for_tier(ach.tier),
                        earned_by_count=count,
                        rarity=_compute_rarity(count, total_teams),
                    ),
                )
        raise HTTPException(500, "Grant succeeded but record not found")

    def _team_achievement_payload(team_id: str, ach_id: str) -> TeamAchievement | None:
        """Render the canonical TeamAchievement row, freshly counted.

        Returns ``None`` if the team has no row for ``ach_id`` — the
        caller decides whether that's a 500 or a soft "not yet unlocked".
        """
        ach = get_catalog_entry(ach_id)
        if ach is None:
            return None
        counts = app.state_backend.count_unlocks_by_achievement()
        total_teams = app.state_backend.count_teams()
        for row in app.state_backend.list_achievements(team_id):
            if row.achievement_id != ach_id:
                continue
            count = counts.get(ach_id, 0)
            return TeamAchievement(
                achievement_id=row.achievement_id,
                name=ach.name,
                description=ach.description,
                icon=ach.icon,
                tier=ach.tier,
                secret=ach.secret,
                unlocked_at=row.unlocked_at,
                context=row.context,
                points=points_for_tier(ach.tier),
                earned_by_count=count,
                rarity=_compute_rarity(count, total_teams),
            )
        return None

    @router.post(
        "/me/star-gazer/verify", response_model=StarGazerVerifyResponse
    )
    async def verify_star_gazer(
        competition_id: str = "",
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        """Verify the caller starred ``CTFY_REPO_URL`` on GitHub.

        Side-effects on success:
        - Grant ``star_gazer`` against the per-comp team identified by
          ``competition_id``.
        - Re-evaluate the ``ambassador`` combo (which also requires
          ``linked_github``); fire it if both are now in place.

        Friendly failures (no GitHub identity, repo not configured, not
        starred yet, GitHub rate-limited) come back as 200 OK with
        ``verified=False`` + an actionable ``reason`` string. Hard 4xx
        is reserved for auth failures.
        """
        user, _token = ctx
        # Reuse the shared resolver but degrade to ``no_team`` instead
        # of a hard 403 so the frontend can show a friendly nudge.
        from ctfy.server.auth import resolve_team_for_competition

        try:
            team = resolve_team_for_competition(
                app.state_backend, user, competition_id
            )
        except HTTPException:
            return StarGazerVerifyResponse(
                verified=False, reason="no_team"
            )

        now = time.monotonic()
        last = _star_verify_last_attempt.get(team.team_id, 0.0)
        if now - last < _STAR_VERIFY_COOLDOWN_S:
            return StarGazerVerifyResponse(
                verified=False, reason="rate_limited"
            )
        _star_verify_last_attempt[team.team_id] = now

        existing = _team_achievement_payload(team.team_id, "star_gazer")
        if existing is not None:
            return StarGazerVerifyResponse(
                verified=True,
                reason="starred",
                achievement=existing,
                already_unlocked=True,
            )

        owner_repo = parse_owner_repo(app.config.repo_url)
        if owner_repo is None:
            return StarGazerVerifyResponse(
                verified=False, reason="repo_not_configured"
            )
        owner, repo = owner_repo

        # GitHub identity is bound to the *user* who clicked Verify —
        # the star is theirs to claim. Other members' identities don't
        # count for this team unless they also click Verify themselves.
        github_ident: OAuthIdentity | None = next(
            (
                i
                for i in app.state_backend.list_identities_for_user(user.user_id)
                if i.provider == "github"
            ),
            None,
        )
        if github_ident is None:
            return StarGazerVerifyResponse(
                verified=False, reason="no_github_identity"
            )

        github_pat = app.config.github_api_token.get_secret_value()

        login = github_ident.provider_login
        if not login:
            # Old identity rows predate ``provider_login`` — fall back
            # to one ``GET /user/{id}`` lookup and persist for next time.
            login = await resolve_login(
                github_ident.provider_user_id, github_pat=github_pat
            ) or ""
            if not login:
                return StarGazerVerifyResponse(
                    verified=False, reason="lookup_failed"
                )
            backfilled = github_ident.model_copy(
                update={"provider_login": login, "last_used_at": now_iso()}
            )
            app.state_backend.put_identity(backfilled)

        result = await verify_star(login, owner, repo, github_pat=github_pat)
        if result is not StarVerifyResult.STARRED:
            return StarGazerVerifyResponse(verified=False, reason=result.value)

        record = app.state_backend.grant_achievement(
            team.team_id,
            "star_gazer",
            context={"source": "star_verify", "login": login},
        )
        ach = get_catalog_entry("star_gazer")
        # ach is non-None — we ship it in the catalog. Reassure the
        # type checker.
        assert ach is not None
        already_unlocked = record is None
        if record is not None:
            emit_event(
                app,
                AchievementUnlockedPayload(
                    team_id=team.team_id,
                    team_name=team.name,
                    achievement_id=ach.id,
                    achievement_name=ach.name,
                    tier=ach.tier,
                    secret=ach.secret,
                ),
                actor_id=team.team_id,
                actor_name=team.name,
                actor_type="team",
            )
        # Try to fire the Ambassador combo — no-op unless the team
        # also has linked_github already.
        maybe_grant_combo(
            app,
            team,
            required=("star_gazer", "linked_github"),
            grant_id="ambassador",
        )

        payload = _team_achievement_payload(team.team_id, "star_gazer")
        if payload is None:
            raise HTTPException(500, "Grant succeeded but record not found")
        return StarGazerVerifyResponse(
            verified=True,
            reason="starred",
            achievement=payload,
            already_unlocked=already_unlocked,
        )

    @router.post(
        "/admin/teams/{team_id}/achievements/{achievement_id}",
        response_model=TeamAchievement,
    )
    def admin_grant(
        team_id: str,
        achievement_id: str,
        _: None = Depends(app.require_admin),
    ):
        """Admin manual grant — the Bug Hunter path + one-off awards.

        Idempotent on (team_id, achievement_id). A second POST for the
        same pair returns the existing record instead of 409; this keeps
        the admin console simple — the button is always safe to click.
        """
        if not app.state_backend.get_team(team_id):
            raise TeamNotFoundError(team_id)
        ach = get_catalog_entry(achievement_id)
        if ach is None:
            raise HTTPException(404, f"Unknown achievement: {achievement_id}")

        record = app.state_backend.grant_achievement(
            team_id,
            achievement_id,
            context={"granted_by": "admin", "at": datetime.now(timezone.utc).isoformat()},
        )
        if record is not None:
            team = app.state_backend.get_team(team_id)
            # team is not None — we checked above; reassure the type checker.
            assert team is not None
            emit_event(
                app,
                AchievementUnlockedPayload(
                    team_id=team_id,
                    team_name=team.name,
                    achievement_id=ach.id,
                    achievement_name=ach.name,
                    tier=ach.tier,
                    secret=ach.secret,
                ),
                actor_id="admin",
                actor_name="admin",
                actor_type="admin",
            )
        # Re-read to return the canonical record (whether just-created
        # or pre-existing). A list scan is fine — per-team lists are tiny.
        counts = app.state_backend.count_unlocks_by_achievement()
        total_teams = app.state_backend.count_teams()
        for row in app.state_backend.list_achievements(team_id):
            if row.achievement_id == achievement_id:
                count = counts.get(achievement_id, 0)
                return TeamAchievement(
                    achievement_id=row.achievement_id,
                    name=ach.name,
                    description=ach.description,
                    icon=ach.icon,
                    tier=ach.tier,
                    secret=ach.secret,
                    unlocked_at=row.unlocked_at,
                    context=row.context,
                    points=points_for_tier(ach.tier),
                    earned_by_count=count,
                    rarity=_compute_rarity(count, total_teams),
                )
        # Should not reach here (we just granted or it already existed).
        raise HTTPException(500, "Grant succeeded but record not found")

    @router.delete(
        "/admin/teams/{team_id}/achievements/{achievement_id}",
        status_code=204,
    )
    def admin_revoke(
        team_id: str,
        achievement_id: str,
        _: None = Depends(app.require_admin),
    ):
        """Admin revoke — also idempotent; returns 204 whether or not it existed."""
        app.state_backend.revoke_achievement(team_id, achievement_id)
        return None

    return router
