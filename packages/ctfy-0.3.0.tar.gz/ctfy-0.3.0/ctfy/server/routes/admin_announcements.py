"""Admin-only endpoints for site-wide announcements.

Owns the full announcement lifecycle: CREATE (POST), READ (GET), UPDATE
(PATCH), DELETE plus the live SSE broadcasts. Public reads of
announcements are intentionally absent — the user-facing surface is
the per-user Inbox (``/me/inbox``), where each row carries a
per-viewer ``is_read`` flag derived from the
``announcement_reads`` table.
"""

from __future__ import annotations

from typing import get_args
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from fastapi_pagination import paginate as list_paginate

from ctfy.core.enums import PlatformEvent
from ctfy.core.log import log
from ctfy.core.state.models import AnnouncementSeverity, AnnouncementState, UserState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.models import (
    AnnouncementCreate,
    AnnouncementInfo,
    AnnouncementUpdate,
    BigLimitOffsetPage,
)


def to_info(ann: AnnouncementState) -> AnnouncementInfo:
    """Project the storage row onto the API response shape."""
    return AnnouncementInfo(
        announcement_id=ann.announcement_id,
        title=ann.title,
        body=ann.body,
        severity=ann.severity,
        starts_at=ann.starts_at,
        ends_at=ann.ends_at,
        created_at=ann.created_at,
        updated_at=ann.updated_at,
        created_by=ann.created_by,
        created_by_name=ann.created_by_name,
    )


def _broadcast_announcement_event(
    app: AppState, event: PlatformEvent, announcement_id: str
) -> None:
    """Push an announcement-lifecycle frame to every connected client.

    Matches the ``meta_stats`` pattern: bypasses the activity log
    (announcement CRUD is already covered by the structured ``log.info``
    above and would clutter the team-facing Activity feed) and goes
    straight to :meth:`SSEHub.broadcast`. The single carried field is
    ``announcement_id``; subscribers refetch the list rather than
    trusting any per-frame announcement fields.
    """
    app.sse_hub.broadcast(
        event.value,
        team_id="",
        data={"announcement_id": announcement_id},
    )


_VALID_SEVERITIES = set(get_args(AnnouncementSeverity))


def _check_severity(value: str) -> None:
    if value not in _VALID_SEVERITIES:
        raise HTTPException(
            422, f"severity must be one of {sorted(_VALID_SEVERITIES)}"
        )


def _check_window(starts_at: str, ends_at: str) -> None:
    """Reject windows that close before they open.

    Empty strings are sentinels for "no bound", so any pair where one
    side is empty trivially passes.
    """
    if starts_at and ends_at and ends_at <= starts_at:
        raise HTTPException(422, "ends_at must be later than starts_at")


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/admin/announcements",
        response_model=BigLimitOffsetPage[AnnouncementInfo],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_list():
        """List every announcement — past, current, and scheduled.

        The management table needs the unfiltered set so admins can edit
        rows that haven't started yet or fix typos in expired ones.
        """
        rows = app.state_backend.list_announcements(active_only=False, limit=10_000)
        return list_paginate([to_info(r) for r in rows])

    @router.post(
        "/admin/announcements",
        response_model=AnnouncementInfo,
        status_code=201,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_create(
        req: AnnouncementCreate,
        admin: UserState = Depends(app.require_admin),
    ) -> AnnouncementInfo:
        """Create a new announcement. Returns the canonical row."""
        _check_severity(req.severity)
        _check_window(req.starts_at, req.ends_at)
        ts = now_iso()
        ann = AnnouncementState(
            announcement_id=uuid4().hex,
            title=req.title,
            body=req.body,
            severity=req.severity,  # type: ignore[arg-type]
            starts_at=req.starts_at,
            ends_at=req.ends_at,
            created_at=ts,
            updated_at=ts,
            created_by=admin.user_id,
            created_by_name=admin.display_name or admin.email or admin.user_id,
        )
        app.state_backend.put_announcement(ann)
        log.info(
            "Announcement created",
            announcement_id=ann.announcement_id,
            severity=ann.severity,
            created_by=admin.user_id,
        )
        _broadcast_announcement_event(
            app, PlatformEvent.ANNOUNCEMENT_CREATED, ann.announcement_id
        )
        return to_info(ann)

    @router.patch(
        "/admin/announcements/{announcement_id}",
        response_model=AnnouncementInfo,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_update(announcement_id: str, patch: AnnouncementUpdate) -> AnnouncementInfo:
        """Partial update: ``None`` fields preserve the current value."""
        existing = app.state_backend.get_announcement(announcement_id)
        if existing is None:
            raise HTTPException(404, f"Announcement not found: {announcement_id}")

        if patch.severity is not None:
            _check_severity(patch.severity)

        # Resolve the post-patch window so we can validate it before write.
        new_starts_at = patch.starts_at if patch.starts_at is not None else existing.starts_at
        new_ends_at = patch.ends_at if patch.ends_at is not None else existing.ends_at
        _check_window(new_starts_at, new_ends_at)

        updates: dict = {"updated_at": now_iso()}
        if patch.title is not None:
            updates["title"] = patch.title
        if patch.body is not None:
            updates["body"] = patch.body
        if patch.severity is not None:
            updates["severity"] = patch.severity
        if patch.starts_at is not None:
            updates["starts_at"] = patch.starts_at
        if patch.ends_at is not None:
            updates["ends_at"] = patch.ends_at
        merged = existing.model_copy(update=updates)
        app.state_backend.put_announcement(merged)
        log.info("Announcement updated", announcement_id=announcement_id)
        _broadcast_announcement_event(
            app, PlatformEvent.ANNOUNCEMENT_UPDATED, announcement_id
        )
        return to_info(merged)

    @router.delete(
        "/admin/announcements/{announcement_id}",
        dependencies=[Depends(app.require_admin)],
    )
    def admin_delete(announcement_id: str) -> dict:
        if not app.state_backend.delete_announcement(announcement_id):
            raise HTTPException(404, f"Announcement not found: {announcement_id}")
        log.info("Announcement deleted", announcement_id=announcement_id)
        _broadcast_announcement_event(
            app, PlatformEvent.ANNOUNCEMENT_DELETED, announcement_id
        )
        return {"status": "deleted", "announcement_id": announcement_id}

    return router
