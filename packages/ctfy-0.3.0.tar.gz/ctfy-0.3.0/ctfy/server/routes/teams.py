"""Public team endpoints — list + detail.

Post user/team-split a team is a multi-user container with a captain.
This module owns the read-only public surface; ``/me`` lives in
:mod:`ctfy.server.routes.me`, captain-driven CRUD + invites live in
:mod:`ctfy.server.routes.team_invites`, and admin user-management
lives in :mod:`ctfy.server.routes.admin_users`.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi_pagination import paginate as list_paginate

from ctfy.core.exceptions import TeamNotFoundError
from ctfy.core.state.models import TeamState, UserState
from ctfy.server.app_state import AppState
from ctfy.server.models import (
    BigLimitOffsetPage,
    TeamDetail,
    TeamInfo,
    TeamMemberInfo,
)


def _last_active_at(app: AppState, team_id: str) -> str:
    """Newest activity timestamp for a team, or empty if none recorded."""
    recent = app.state_backend.list_activities(team_id=team_id, offset=0, limit=1)
    return recent[0].timestamp if recent else ""


def _captain(app: AppState, t: TeamState) -> UserState | None:
    if not t.captain_user_id:
        return None
    return app.state_backend.get_user(t.captain_user_id)


def team_info(app: AppState, t: TeamState) -> TeamInfo:
    """Project a :class:`TeamState` onto the shared :class:`TeamInfo` shape.

    ``solves`` and ``attempts`` aggregate every member's contribution
    against this team_id (both fields stamp team_id at write time so a
    user's later move doesn't retroactively re-credit).
    """
    captain = _captain(app, t)
    return TeamInfo(
        team_id=t.team_id,
        name=t.name,
        description=t.description,
        captain_user_id=t.captain_user_id,
        captain_display_name=(captain.display_name if captain else ""),
        captain_avatar_url=(captain.avatar_url if captain else ""),
        member_count=app.state_backend.count_memberships(t.team_id),
        created_at=t.created_at,
        solves=len(app.state_backend.list_solves(t.team_id)),
        attempts=len(app.state_backend.list_submissions(team_id=t.team_id)),
        last_active_at=_last_active_at(app, t.team_id),
        competition_id=t.competition_id,
    )


def _member_infos(app: AppState, t: TeamState) -> list[TeamMemberInfo]:
    rows: list[TeamMemberInfo] = []
    for m in app.state_backend.list_memberships(team_id=t.team_id):
        u = app.state_backend.get_user(m.user_id)
        rows.append(
            TeamMemberInfo(
                user_id=m.user_id,
                display_name=(u.display_name if u else ""),
                avatar_url=(u.avatar_url if u else ""),
                is_captain=m.user_id == t.captain_user_id,
                joined_at=m.joined_at,
            )
        )
    # Captain first, then by join time.
    rows.sort(key=lambda r: (not r.is_captain, r.joined_at))
    return rows


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/teams", response_model=BigLimitOffsetPage[TeamInfo])
    def list_teams():
        return list_paginate(
            [team_info(app, t) for t in app.state_backend.list_teams()]
        )

    @router.get("/teams/{team_id}", response_model=TeamDetail)
    def get_team(team_id: str):
        t = app.state_backend.get_team(team_id)
        if not t:
            raise TeamNotFoundError(team_id)
        info = team_info(app, t)
        return TeamDetail(
            **info.model_dump(),
            members=_member_infos(app, t),
        )

    return router
