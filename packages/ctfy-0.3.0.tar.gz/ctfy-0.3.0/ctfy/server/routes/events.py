"""SSE event stream endpoint."""

from __future__ import annotations

import asyncio

from fastapi import APIRouter
from starlette.responses import StreamingResponse

from ctfy.core.constants import SSE_KEEPALIVE_INTERVAL
from ctfy.server.app_state import AppState
from ctfy.server.auth import hash_token


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/events")
    async def stream_events(token: str = ""):
        """SSE stream of platform events, filtered by team membership.

        The connecting client sees events for any team the calling
        user is on (across every per-comp competition) plus all
        global events; admin users additionally see admin-only frames.
        """
        team_ids: frozenset[str] = frozenset()
        is_admin = False
        if token:
            tok = app.state_backend.get_token_by_hash(hash_token(token))
            if tok and not tok.revoked_at:
                user = app.state_backend.get_user(tok.user_id)
                if user:
                    is_admin = bool(user.is_admin)
                    team_ids = frozenset(
                        m.team_id
                        for m in app.state_backend.list_memberships(
                            user_id=user.user_id
                        )
                    )

        client_id, queue = app.sse_hub.connect(team_ids=team_ids, is_admin=is_admin)

        async def generate():
            try:
                yield ": connected\n\n"
                while True:
                    try:
                        # ``frame`` is already a fully-formed SSE chunk
                        # (``event: <name>\ndata: {...}\n\n``) produced
                        # by :meth:`SSEHub.broadcast`. Nothing to parse
                        # or mutate — strings are immutable, so no
                        # consumer can affect what another consumer
                        # sees.
                        frame = await asyncio.wait_for(queue.get(), timeout=SSE_KEEPALIVE_INTERVAL)
                        yield frame
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"
            except asyncio.CancelledError:
                pass
            finally:
                app.sse_hub.disconnect(client_id)

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
                "Connection": "keep-alive",
            },
        )

    return router
