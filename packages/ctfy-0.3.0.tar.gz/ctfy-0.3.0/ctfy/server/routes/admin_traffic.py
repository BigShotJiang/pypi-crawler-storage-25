"""Admin-only HTTP traffic analytics.

Aggregates the persisted ``request_count`` field on every archived
:class:`InstanceRecord` into per-team and per-instance rows for the
``/admin/traffic`` dashboard. Live (still-running) instances are
surfaced as rows for navigation but do not contribute to the per-team
sum — capturing live counts would require a synchronous fan-out to
every node on each dashboard load. Live counts are still available
on-demand via ``GET /admin/instances/{id}/traffic``.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends

from ctfy.server.app_state import AppState
from ctfy.server.models import (
    AdminTrafficInstanceRow,
    AdminTrafficSummary,
    AdminTrafficTeamRow,
)


# Cap on the number of archived records we'll scan per dashboard load.
# Matches the existing _CHALLENGE_STATS_RECORD_CAP in admin_stats.py — at
# this size, the dashboard would need a precomputed rollup table anyway.
_RECORD_SCAN_CAP = 10_000


def _team_label(state) -> str:
    return state.name or state.team_id


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/admin/traffic/summary",
        response_model=AdminTrafficSummary,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_traffic_summary() -> AdminTrafficSummary:
        """Per-team and per-instance HTTP request counts.

        Sums ``InstanceRecord.request_count`` (populated at archive time
        from the mitmproxy flow file). Live instances appear in
        ``instances`` with ``live=true`` and ``request_count=0`` so admins
        can drill in, but they're not summed into the per-team totals to
        keep the endpoint cheap.
        """
        team_rows: dict[str, AdminTrafficTeamRow] = {}
        instance_rows: list[AdminTrafficInstanceRow] = []
        total_requests = 0

        # Resolve team labels once to avoid an N+1 lookup per row.
        team_names: dict[str, str] = {}
        for team in app.state_backend.list_teams():
            team_names[team.team_id] = _team_label(team)

        # 1. Archived instances — the source of truth for completed traffic.
        records = app.state_backend.list_instance_records(
            offset=0, limit=_RECORD_SCAN_CAP
        )
        for rec in records:
            if not rec.team_id:
                continue
            req_count = getattr(rec, "request_count", 0) or 0
            row = team_rows.get(rec.team_id)
            if row is None:
                row = AdminTrafficTeamRow(
                    team_id=rec.team_id,
                    team_name=team_names.get(rec.team_id, rec.team_id),
                )
                team_rows[rec.team_id] = row
            row.instance_count += 1
            row.request_count += req_count
            if rec.stopped_at > row.last_activity_at:
                row.last_activity_at = rec.stopped_at
            total_requests += req_count

            instance_rows.append(
                AdminTrafficInstanceRow(
                    instance_id=rec.instance_id,
                    team_id=rec.team_id,
                    team_name=team_names.get(rec.team_id, rec.team_id),
                    challenge_id=rec.challenge_id,
                    name=rec.name,
                    status=rec.status,
                    request_count=req_count,
                    started_at=rec.started_at,
                    stopped_at=rec.stopped_at,
                    live=False,
                )
            )

        # 2. Live instances — surfaced for navigation; counts are 0 because
        # we don't fan out to nodes here. The live tab in the UI shows
        # current flows on demand.
        for inst in app.state_backend.list_instances():
            if not inst.team_id:
                continue
            row = team_rows.get(inst.team_id)
            if row is None:
                row = AdminTrafficTeamRow(
                    team_id=inst.team_id,
                    team_name=team_names.get(inst.team_id, inst.team_id),
                )
                team_rows[inst.team_id] = row
            row.instance_count += 1
            if inst.started_at > row.last_activity_at:
                row.last_activity_at = inst.started_at

            instance_rows.append(
                AdminTrafficInstanceRow(
                    instance_id=inst.instance_id,
                    team_id=inst.team_id,
                    team_name=team_names.get(inst.team_id, inst.team_id),
                    challenge_id=inst.challenge_id,
                    name=inst.name,
                    status=inst.status,
                    request_count=0,
                    started_at=inst.started_at,
                    stopped_at=0.0,
                    live=True,
                )
            )

        teams = sorted(
            team_rows.values(),
            key=lambda r: (-r.request_count, -r.instance_count, r.team_name.lower()),
        )
        instance_rows.sort(
            key=lambda r: (-r.request_count, -r.started_at),
        )

        return AdminTrafficSummary(
            teams=teams,
            instances=instance_rows,
            total_requests=total_requests,
        )

    return router
