"""Activity log endpoint."""

from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Query

from ctfy.core.state.models import UserState
from ctfy.server.app_state import AppState
from ctfy.server.timeseries import bucket_edges
from ctfy.server.models import (
    Activity,
    ActivityTimeseries,
    ActivityTimeseriesBucket,
    BigLimitOffsetPage,
)


def _parse_iso(s: str) -> float | None:
    """ISO 8601 → Unix seconds. Returns None on parse failure so the
    timeseries silently drops a malformed row rather than 500ing on a
    single bad entry."""
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/activities", response_model=BigLimitOffsetPage[Activity])
    def list_activities(
        user: UserState = Depends(app.get_current_user),
        challenge_id: str = "",
        event: str = "",
        since: str = Query(
            "",
            description=(
                "Lower bound on timestamp (inclusive). Accepts an ISO-8601 "
                "string in the same canonical UTC-with-Z form the rows use; "
                "lexicographic comparison matches absolute time."
            ),
        ),
        until: str = Query(
            "",
            description="Upper bound on timestamp (inclusive). Same format as ``since``.",
        ),
        offset: int = 0,
        limit: int = 100,
    ):
        """Get the calling user's activity log (most recent first).

        User-scoped: rows where ``activity.actor_id == me`` aggregated
        across every team the user has ever been on. A teammate's
        events on a shared team are NOT in this feed; for a team-scoped
        view use ``/teams/{id}/activity`` (read-public). Anonymous
        requests are rejected at the auth layer.
        """
        total = app.state_backend.count_activities(
            challenge_id=challenge_id,
            event=event,
            actor_id=user.user_id,
            since=since,
            until=until,
        )
        rows = app.state_backend.list_activities(
            challenge_id=challenge_id,
            event=event,
            actor_id=user.user_id,
            since=since,
            until=until,
            offset=offset,
            limit=limit,
        )
        items = [Activity(**a.model_dump()) for a in rows]
        return {"items": items, "total": total, "offset": offset, "limit": limit}

    @router.get("/activities/timeseries", response_model=ActivityTimeseries)
    def activity_timeseries(
        user: UserState = Depends(app.get_current_user),
        window: int = Query(86400, ge=60, le=7 * 86400),
        bucket: int = Query(3600, ge=60, le=86400),
    ) -> ActivityTimeseries:
        """Bucketed event counts for the calling user's activity histogram.

        Same scope as ``/activities`` — user-scoped via ``actor_id``,
        so the chart strip on the activity page reflects exactly the
        same rows as the list below it. Buckets are oldest-first with
        the right edge anchored at ``now``; the rightmost bucket is
        flagged ``partial`` since it is still accumulating.
        """
        edges = bucket_edges(now=app.clock(), window=window, bucket=bucket)
        n_buckets = len(edges)
        start = edges[0] - bucket
        last_idx = n_buckets - 1

        # The list endpoint paginates; for the timeseries we want the
        # whole window. A 24h hot CTF day is ~10k events for one user,
        # well inside the cap.
        rows = app.state_backend.list_activities(
            actor_id=user.user_id,
            offset=0,
            limit=10_000,
        )

        per_bucket: list[dict[str, int]] = [dict() for _ in range(n_buckets)]
        events_seen: set[str] = set()
        for r in rows:
            ts = _parse_iso(r.timestamp)
            if ts is None or ts <= start or ts > edges[-1]:
                continue
            idx = int((ts - start - 1) // bucket)
            if not 0 <= idx < n_buckets:
                continue
            per_bucket[idx][r.event] = per_bucket[idx].get(r.event, 0) + 1
            events_seen.add(r.event)

        return ActivityTimeseries(
            window_s=window,
            bucket_s=bucket,
            events=sorted(events_seen),
            buckets=[
                ActivityTimeseriesBucket(
                    ts=edges[i], counts=per_bucket[i], partial=(i == last_idx)
                )
                for i in range(n_buckets)
            ],
        )

    return router
