"""Admin-only mutation endpoints for competitions.

Reads live in :mod:`ctfy.server.routes.competitions` (public). This
module owns POST / PATCH / DELETE plus an admin-flavoured GET that
returns every competition (past, current, scheduled) so the management
table can show everything in one view, plus a registrations roster
endpoint for the admin "who signed up" panel.
"""

from __future__ import annotations

from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from fastapi_pagination import paginate as list_paginate

from ctfy.core.enums import PlatformEvent
from ctfy.core.log import log
from ctfy.core.state.models import CompetitionState, UserState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.models import (
    BigLimitOffsetPage,
    CompetitionCreate,
    CompetitionInfo,
    CompetitionRegistrationInfo,
    CompetitionUpdate,
)
from ctfy.server.routes.competitions import _to_info


def _broadcast_competition_event(
    app: AppState, event: PlatformEvent, competition_id: str
) -> None:
    """Push a competition-lifecycle frame to every connected client.

    Same pattern as ``_broadcast_announcement_event``: bypass the
    activity log (CRUD is already covered by the structured ``log.info``
    above and would clutter the team-facing Activity feed) and go
    straight to :meth:`SSEHub.broadcast`. Subscribers refetch the row
    rather than trusting any per-frame fields.
    """
    app.sse_hub.broadcast(
        event.value,
        team_id="",
        data={"competition_id": competition_id},
    )


def _check_window(starts_at: str, ends_at: str) -> None:
    """Reject windows that close before they open.

    Empty strings are sentinels for "no bound", so any pair where one
    side is empty trivially passes. Mirrors ``_check_window`` in
    ``admin_announcements`` so the rule lives in one shape.
    """
    if starts_at and ends_at and ends_at <= starts_at:
        raise HTTPException(422, "ends_at must be later than starts_at")


def _check_challenge_ids(app: AppState, challenge_ids: list[str]) -> None:
    """422 when any id isn't a known spec.

    The spec registry is in-memory and small; iterating once per write
    is cheaper than building a side cache. Empty list is fine — a
    competition with no curated challenges is allowed (admin can
    populate it later).
    """
    if not challenge_ids:
        return
    known = {spec.id for spec in app.spec_reader.iter_specs()}
    unknown = [cid for cid in challenge_ids if cid not in known]
    if unknown:
        raise HTTPException(
            422, f"Unknown challenge ids: {sorted(unknown)}"
        )
    # Reject duplicate ids (shape error — the curated list is a set).
    if len(set(challenge_ids)) != len(challenge_ids):
        raise HTTPException(422, "challenge_ids contains duplicates")


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/admin/competitions",
        response_model=BigLimitOffsetPage[CompetitionInfo],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_list():
        """Every competition — past, current, and scheduled."""
        ts = now_iso()
        rows = app.state_backend.list_competitions(limit=10_000)
        return list_paginate([_to_info(app, r, ts) for r in rows])

    @router.post(
        "/admin/competitions",
        response_model=CompetitionInfo,
        status_code=201,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_create(
        req: CompetitionCreate,
        admin: UserState = Depends(app.require_admin),
    ) -> CompetitionInfo:
        _check_window(req.starts_at, req.ends_at)
        _check_challenge_ids(app, req.challenge_ids)
        ts = now_iso()
        comp = CompetitionState(
            competition_id=uuid4().hex,
            title=req.title,
            description=req.description,
            starts_at=req.starts_at,
            ends_at=req.ends_at,
            challenge_ids=list(req.challenge_ids),
            created_at=ts,
            updated_at=ts,
            created_by=admin.user_id,
            created_by_name=admin.display_name or admin.email or admin.user_id,
        )
        app.state_backend.put_competition(comp)
        log.info(
            "Competition created",
            competition_id=comp.competition_id,
            challenge_count=len(comp.challenge_ids),
            created_by=admin.user_id,
        )
        _broadcast_competition_event(
            app, PlatformEvent.COMPETITION_CREATED, comp.competition_id
        )
        return _to_info(app, comp, ts)

    @router.patch(
        "/admin/competitions/{competition_id}",
        response_model=CompetitionInfo,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_update(
        competition_id: str, patch: CompetitionUpdate
    ) -> CompetitionInfo:
        existing = app.state_backend.get_competition(competition_id)
        if existing is None:
            raise HTTPException(404, f"Competition not found: {competition_id}")

        # Resolve the post-patch window so we can validate it before write.
        new_starts_at = (
            patch.starts_at if patch.starts_at is not None else existing.starts_at
        )
        new_ends_at = patch.ends_at if patch.ends_at is not None else existing.ends_at
        _check_window(new_starts_at, new_ends_at)
        if patch.challenge_ids is not None:
            _check_challenge_ids(app, patch.challenge_ids)

        updates: dict = {"updated_at": now_iso()}
        if patch.title is not None:
            updates["title"] = patch.title
        if patch.description is not None:
            updates["description"] = patch.description
        if patch.starts_at is not None:
            updates["starts_at"] = patch.starts_at
        if patch.ends_at is not None:
            updates["ends_at"] = patch.ends_at
        if patch.challenge_ids is not None:
            updates["challenge_ids"] = list(patch.challenge_ids)
        merged = existing.model_copy(update=updates)
        app.state_backend.put_competition(merged)
        log.info("Competition updated", competition_id=competition_id)
        _broadcast_competition_event(
            app, PlatformEvent.COMPETITION_UPDATED, competition_id
        )
        return _to_info(app, merged, updates["updated_at"])

    @router.delete(
        "/admin/competitions/{competition_id}",
        dependencies=[Depends(app.require_admin)],
    )
    def admin_delete(competition_id: str) -> dict:
        if not app.state_backend.delete_competition(competition_id):
            raise HTTPException(404, f"Competition not found: {competition_id}")
        log.info("Competition deleted", competition_id=competition_id)
        _broadcast_competition_event(
            app, PlatformEvent.COMPETITION_DELETED, competition_id
        )
        return {"status": "deleted", "competition_id": competition_id}

    @router.get(
        "/admin/competitions/{competition_id}/registrations",
        response_model=BigLimitOffsetPage[CompetitionRegistrationInfo],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_list_registrations(competition_id: str):
        """Roster for the admin "who's signed up" panel.

        Per the per-comp team refactor: a team's existence with
        ``competition_id == X`` *is* the registration. Project that
        into the legacy ``CompetitionRegistrationInfo`` shape so the
        admin UI's response contract is unchanged.
        """
        if app.state_backend.get_competition(competition_id) is None:
            raise HTTPException(404, f"Competition not found: {competition_id}")
        teams = app.state_backend.list_teams(competition_id=competition_id)
        infos = [
            CompetitionRegistrationInfo(
                team_id=t.team_id,
                team_name=t.name,
                registered_at=t.created_at,
            )
            for t in teams
        ]
        return list_paginate(infos)

    return router


__all__ = ["create_router"]
