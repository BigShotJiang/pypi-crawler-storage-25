"""Challenge listing endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi_pagination import paginate as list_paginate

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.exceptions import ChallengeNotFoundError
from ctfy.core.state.models import TeamState
from ctfy.server.app_state import AppState
from ctfy.server.models import (
    BigLimitOffsetPage,
    ChallengeInfo,
    ChallengeSolveAttempt,
    ChallengeSolveAttemptsResponse,
    ChallengeTeamSolveSummary,
)


def to_challenge_info(app: AppState, spec: ChallengeSpec) -> ChallengeInfo:
    flag_ids = tuple(spec.flags)
    per_flag = {
        fid: app.state_backend.count_solves_for_flag(spec.id, fid) for fid in flag_ids
    }
    return ChallengeInfo(
        id=spec.id,
        name=spec.name,
        category=ChallengeSpec.CATEGORY,
        difficulty=spec.difficulty.value,
        description=spec.description,
        solves_count=app.state_backend.count_solves_for_challenge(spec.id, flag_ids),
        tags=spec.tags,
        flag_ids=list(flag_ids),
        flag_solves=per_flag,
        var_ids=list(spec.vars),
        public_var_ids=list(spec.public_vars),
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/challenges", response_model=BigLimitOffsetPage[ChallengeInfo])
    def list_challenges(
        difficulty: str = "",
        tag: str = "",
        q: str = "",
    ):
        specs = app.spec_reader.iter_specs(
            difficulty=difficulty or None,
            tag=tag or None,
        )
        if q:
            ql = q.lower()
            specs = (s for s in specs if ql in (s.id + s.name + s.description).lower())
        all_challenges = [to_challenge_info(app, s) for s in specs]
        return list_paginate(all_challenges)

    @router.get("/challenges/{challenge_id}", response_model=ChallengeInfo)
    def get_challenge(challenge_id: str):
        for spec in app.spec_reader.iter_specs(challenge_id=challenge_id):
            if spec.id == challenge_id:
                return to_challenge_info(app, spec)
        raise ChallengeNotFoundError(challenge_id)

    @router.get(
        "/challenges/{challenge_id}/solve-attempts",
        response_model=ChallengeSolveAttemptsResponse,
    )
    def get_challenge_solve_attempts(
        challenge_id: str,
        include_unsolved: bool = False,
        limit: int = 500,
        _viewer = Depends(app.get_current_user),
    ):
        """Per-team archived instance breakdown for one challenge.

        Powers the challenge detail page's "Solve attempts" panel: each
        archived ``InstanceRecord`` becomes one attempt row, plus a
        per-team rollup (solve count, best/total duration, first/last
        solved at). Visible to any logged-in viewer — same access posture
        as ``/activities``, which already feeds the existing solvers
        table on the same page.
        """
        if not any(
            spec.id == challenge_id
            for spec in app.spec_reader.iter_specs(challenge_id=challenge_id)
        ):
            raise ChallengeNotFoundError(challenge_id)

        capped = max(1, min(limit, 5000))
        raw = app.state_backend.list_instance_records(
            challenge_id=challenge_id, offset=0, limit=capped
        )
        if not include_unsolved:
            raw = [r for r in raw if r.solved]

        team_cache: dict[str, TeamState | None] = {}

        def _team(tid: str) -> TeamState | None:
            if tid not in team_cache:
                team_cache[tid] = app.state_backend.get_team(tid)
            return team_cache[tid]

        # Resolve a per-team display name once: post user/team-split the
        # team carries its name on TeamState; ``display_name`` (the
        # captain's friendly handle) is fetched from the captain's
        # UserState. Falls back to team_id when neither is available.
        def _captain_name(team: TeamState | None) -> str:
            if team is None or not team.captain_user_id:
                return ""
            captain = app.state_backend.get_user(team.captain_user_id)
            return captain.display_name if captain else ""

        attempts: list[ChallengeSolveAttempt] = []
        for r in raw:
            t = _team(r.team_id)
            attempts.append(
                ChallengeSolveAttempt(
                    instance_id=r.instance_id,
                    team_id=r.team_id,
                    team_name=(t.name if t else r.team_id),
                    display_name=_captain_name(t),
                    challenge_id=r.challenge_id,
                    started_at=r.started_at,
                    stopped_at=r.stopped_at,
                    duration_s=r.duration_s,
                    attempts=r.attempts,
                    solved=r.solved,
                    solved_flags=list(r.solved_flags),
                    stop_reason=r.stop_reason,
                )
            )

        # Sort attempts oldest→newest within each team so the sparkline
        # renders a stable "first relaunch ... latest" trend.
        attempts.sort(key=lambda a: a.started_at)

        grouped: dict[str, list[ChallengeSolveAttempt]] = {}
        for a in attempts:
            grouped.setdefault(a.team_id, []).append(a)

        per_team: list[ChallengeTeamSolveSummary] = []
        for tid, rows in grouped.items():
            solved_rows = [a for a in rows if a.solved]
            durations = [a.duration_s for a in solved_rows]
            starts = [a.started_at for a in solved_rows]
            per_team.append(
                ChallengeTeamSolveSummary(
                    team_id=tid,
                    team_name=rows[0].team_name,
                    display_name=rows[0].display_name,
                    solve_count=len(solved_rows),
                    attempt_count=len(rows),
                    best_duration_s=min(durations) if durations else 0.0,
                    total_duration_s=sum(durations),
                    first_solved_at=min(starts) if starts else 0.0,
                    last_solved_at=max(starts) if starts else 0.0,
                )
            )
        # Most-active teams first; tie-break by fastest best-time.
        per_team.sort(
            key=lambda s: (-s.solve_count, s.best_duration_s or float("inf"))
        )

        return ChallengeSolveAttemptsResponse(
            challenge_id=challenge_id,
            attempts=attempts,
            per_team=per_team,
            total_attempts=app.state_backend.count_instance_records(
                challenge_id=challenge_id
            ),
        )

    return router
