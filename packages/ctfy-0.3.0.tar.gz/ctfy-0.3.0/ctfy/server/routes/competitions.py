"""Public competition endpoints — list, detail, register, leaderboard.

Reads are unauthenticated so a visitor can browse upcoming events
before signing up. When the request *does* carry credentials, every
row in the listing is annotated with viewer-scoped fields
(``is_registered`` / ``my_team_*`` / ``my_rank`` / ``my_score`` /
``my_solves``) so the frontend can render rich "Mine"-style cards
without an extra round trip per competition.

Mutation (register / unregister) requires an authenticated team —
agent tokens included, since agents participate the same way humans
do. Admin CRUD lives in :mod:`ctfy.server.routes.admin_competitions`.

The competition leaderboard is a pure read-time projection: solves and
submissions stay global (the existing ``/submissions`` route is
untouched), and ``compute_scoreboard_filtered`` re-aggregates them
under (registered teams) × (curated challenges) × time window.
Registering after a solve does NOT retroactively credit it — the
per-team lower bound is ``max(competition.starts_at, registered_at)``.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from fastapi_pagination import paginate as list_paginate

from ctfy.core.competitions import phase as _comp_phase
from ctfy.core.state.models import (
    CompetitionState,
    UserState,
)
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.models import (
    BigLimitOffsetPage,
    CompetitionDetail,
    CompetitionInfo,
    ScoreboardEntry,
)
from ctfy.server.routes.challenges import to_challenge_info
from ctfy.server.routes.scoreboard import compute_scoreboard_filtered

# Soft cap on rows materialised before pagination — matches the
# announcements route for parity.
_MATERIALIZE_CAP = 10_000

# Computing a single competition's full scoreboard is O(T × S) where T
# is registered teams and S is solves per team. To keep the listing
# endpoint fast for power-users registered to many concurrent comps,
# we cap how many competitions get rank/score populated per request.
# Above this threshold the user still sees ``is_registered`` + team
# name + role, but ``my_rank`` / ``my_score`` / ``my_solves`` stay at
# the ``-1`` sentinel ("no value"). 12 is comfortably above what
# realistic users participate in concurrently.
_MAX_RANK_COMPUTE_PER_REQUEST = 12


def _to_info(
    app: AppState,
    comp: CompetitionState,
    now_ts: str,
    *,
    viewer: UserState | None = None,
    rank_budget: list[int] | None = None,
) -> CompetitionInfo:
    """Project a ``CompetitionState`` onto the listing/detail shape.

    ``viewer`` controls whether per-user fields (``is_registered`` /
    ``my_team_*`` / ``my_rank`` / ``my_score`` / ``my_solves``) get
    populated. ``rank_budget`` is a single-cell mutable counter shared
    across one request: when it hits zero we skip rank computation
    for the remaining competitions and keep the cheap fields only.
    """
    info = CompetitionInfo(
        competition_id=comp.competition_id,
        title=comp.title,
        description=comp.description,
        starts_at=comp.starts_at,
        ends_at=comp.ends_at,
        created_at=comp.created_at,
        updated_at=comp.updated_at,
        created_by=comp.created_by,
        created_by_name=comp.created_by_name,
        challenge_ids=list(comp.challenge_ids),
        phase=_comp_phase(comp, now_ts),
        registered_count=len(
            app.state_backend.list_teams(competition_id=comp.competition_id)
        ),
    )
    if viewer is None:
        return info

    membership = app.state_backend.get_membership_for_competition(
        viewer.user_id, comp.competition_id
    )
    if membership is None:
        return info
    team = app.state_backend.get_team(membership.team_id)
    if team is None:
        return info
    info.is_registered = True
    info.my_team_id = team.team_id
    info.my_team_name = team.name
    info.my_role = (
        "captain" if team.captain_user_id == viewer.user_id else "member"
    )

    # Skip rank computation for upcoming comps (no solves to count yet)
    # and when the per-request budget is exhausted.
    if info.phase == "upcoming":
        return info
    if rank_budget is not None and rank_budget[0] <= 0:
        return info
    team_filter = _competition_team_filter(app, comp)
    if team.team_id not in team_filter:
        # Defensive: registered membership without a matching team in
        # the filter would imply data drift; bail rather than crash.
        return info
    entries = compute_scoreboard_filtered(
        app,
        team_filter=team_filter,
        challenge_ids=set(comp.challenge_ids) if comp.challenge_ids else set(),
        until_iso=comp.ends_at,
    )
    if rank_budget is not None:
        rank_budget[0] -= 1
    for e in entries:
        if e.team_id == team.team_id:
            info.my_rank = e.rank
            info.my_score = e.flags_solved
            info.my_solves = e.solved
            break
    return info


def _competition_team_filter(
    app: AppState, comp: CompetitionState
) -> dict[str, str]:
    """Build the ``compute_scoreboard_filtered`` team_filter for ``comp``.

    Per the per-comp team refactor, "team exists with
    ``competition_id == comp.competition_id``" *is* the registration.
    Each entry maps team_id → ``max(starts_at, team.created_at)`` so
    the leaderboard ignores solves before the team became eligible
    (a team formed mid-event can't retroactively claim earlier
    practice solves).
    """
    teams = app.state_backend.list_teams(competition_id=comp.competition_id)
    return {
        t.team_id: max(t.created_at, comp.starts_at)
        for t in teams
    }


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/competitions",
        response_model=BigLimitOffsetPage[CompetitionInfo],
    )
    def list_competitions(
        phase: str = "",
        viewer: UserState | None = Depends(app.get_current_user_or_none),
    ):
        """List competitions, optionally filtered by phase.

        ``phase`` accepts ``"upcoming"``, ``"running"``, ``"past"``, or
        the empty string ("all"). Anything else is silently treated as
        "all". When the request is authenticated, every row carries the
        viewer's per-comp registration state and (capped) rank/score so
        the cards-and-filters frontend can render rich "Mine"-style
        rows without N+1 round trips.
        """
        valid = {"", "upcoming", "running", "past"}
        normalized = phase if phase in valid else ""
        ts = now_iso()
        rows = app.state_backend.list_competitions(
            phase=normalized,  # type: ignore[arg-type]
            now_iso=ts,
            limit=_MATERIALIZE_CAP,
        )
        # Single-cell mutable counter so ``_to_info`` can decrement it
        # whenever a rank computation lands; once it hits zero, every
        # subsequent registered comp gets the cheap fields only.
        budget = [_MAX_RANK_COMPUTE_PER_REQUEST]
        return list_paginate(
            [_to_info(app, r, ts, viewer=viewer, rank_budget=budget) for r in rows]
        )

    @router.get(
        "/competitions/{competition_id}",
        response_model=CompetitionDetail,
    )
    def get_competition(
        competition_id: str,
        viewer: UserState | None = Depends(app.get_current_user_or_none),
    ):
        comp = app.state_backend.get_competition(competition_id)
        if comp is None:
            raise HTTPException(404, f"Competition not found: {competition_id}")
        ts = now_iso()
        # Detail page always pays full rank/score cost — there's only
        # one comp, the user is on that page on purpose.
        info = _to_info(app, comp, ts, viewer=viewer)
        # Resolve curated challenge subset against the spec registry —
        # ids that no longer match a spec are silently dropped (same
        # tolerance the global /challenges list has when the challenge
        # repo is updated mid-event).
        wanted = set(comp.challenge_ids)
        challenges = []
        if wanted:
            for spec in app.spec_reader.iter_specs():
                if spec.id in wanted:
                    challenges.append(to_challenge_info(app, spec))
            # Preserve the admin's curated order from challenge_ids
            order = {cid: i for i, cid in enumerate(comp.challenge_ids)}
            challenges.sort(key=lambda c: order.get(c.id, len(order)))
        # ``registered_at`` extends ``CompetitionInfo`` only on the
        # detail payload. Resolve from the team row when registered;
        # leave empty otherwise.
        registered_at = ""
        if info.is_registered and info.my_team_id:
            team = app.state_backend.get_team(info.my_team_id)
            if team is not None:
                registered_at = team.created_at
        return CompetitionDetail(
            **info.model_dump(),
            challenges=challenges,
            registered_at=registered_at,
        )

    @router.get(
        "/competitions/{competition_id}/scoreboard",
        response_model=BigLimitOffsetPage[ScoreboardEntry],
    )
    def get_competition_scoreboard(competition_id: str):
        comp = app.state_backend.get_competition(competition_id)
        if comp is None:
            raise HTTPException(404, f"Competition not found: {competition_id}")
        team_filter = _competition_team_filter(app, comp)
        entries = compute_scoreboard_filtered(
            app,
            team_filter=team_filter,
            challenge_ids=set(comp.challenge_ids) if comp.challenge_ids else set(),
            until_iso=comp.ends_at,
        )
        return list_paginate(entries)

    return router


__all__ = ["create_router"]
