"""Public user-profile read endpoint — ``GET /users/{user_id}``.

Post user/team-split, profile fields (bio, country, social, …) live
on :class:`UserState`, not :class:`TeamState`. The team profile page
needs a way to fetch the captain user's profile so it can render the
same About card visitors used to see; this is the missing read.

Visibility rules mirror the old ``/teams/{id}`` contract: owner (the
target user themselves) and admins always see the unfiltered view;
anyone else gets the per-field scrub from
``user.profile_visibility``.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query

from ctfy.core.state.models import UserState
from ctfy.server.app_state import AppState
from ctfy.server.models import TrendPoint, UserInfo, UserSolveTrend
from ctfy.server.routes.team_profile_stats import _utc_day


def _user_info(app: AppState, u: UserState) -> UserInfo:
    """Project a :class:`UserState` onto the :class:`UserInfo` shape.

    The lifetime aggregates (solves / attempts / last_active_at) and
    current team summary are computed off the storage backend so the
    route stays a single round-trip from the caller's POV.
    """
    # Local import — ``me.py`` defines the helper that scans for
    # cross-team lifetime totals; pulling it in directly avoids
    # duplicating the loop here.
    from ctfy.server.routes.me import _user_aggregates

    solves, attempts, last_active = _user_aggregates(app, u.user_id)
    return UserInfo(
        user_id=u.user_id,
        display_name=u.display_name,
        avatar_url=u.avatar_url,
        created_at=u.created_at,
        bio=u.bio,
        country=u.country,
        website_url=u.website_url,
        timezone=u.timezone,
        social_links=dict(u.social_links),
        solves=solves,
        attempts=attempts,
        last_active_at=last_active,
    )


# Per-field scrub for non-owner non-admin viewers. Same key set as
# the old TeamState visibility map (PROFILE_VISIBILITY_KEYS in
# ``server/models.py``); the ``solves`` / ``attempts`` /
# ``last_active_at`` family also masks to 0 / "" so callers can't
# infer activity from a "private" profile.
def _apply_visibility(info: UserInfo, visibility: dict[str, bool]) -> UserInfo:
    if not visibility:
        return info
    update: dict[str, object] = {}
    if visibility.get("bio") is False:
        update["bio"] = None
    if visibility.get("country") is False:
        update["country"] = None
    if visibility.get("website_url") is False:
        update["website_url"] = None
    if visibility.get("timezone") is False:
        update["timezone"] = None
    if visibility.get("social_links") is False:
        update["social_links"] = {}
    if visibility.get("last_active_at") is False:
        update["last_active_at"] = ""
    if visibility.get("solves_count") is False:
        update["solves"] = 0
    if visibility.get("attempts_count") is False:
        update["attempts"] = 0
    if not update:
        return info
    return info.model_copy(update=update)


def _user_solve_trend(app: AppState, user_id: str, days: int) -> list[TrendPoint]:
    """Daily zero-filled solve count for ``user_id`` over the trailing
    ``days`` UTC days. Aggregates across every team the user has ever
    been on by filtering on ``solve.user_id`` rather than ``team_id`` —
    so a user who moved teams mid-comp sees their full trajectory.
    """
    today = datetime.now(timezone.utc).date()
    cutoff = (today - timedelta(days=days - 1)).isoformat()
    counts: dict[str, int] = {}
    for s in app.state_backend.list_solves():
        if s.user_id != user_id:
            continue
        d = _utc_day(s.solved_at)
        if d and d >= cutoff:
            counts[d] = counts.get(d, 0) + 1
    out: list[TrendPoint] = []
    for i in range(days - 1, -1, -1):
        d = (today - timedelta(days=i)).isoformat()
        out.append(TrendPoint(date=d, solves=counts.get(d, 0)))
    return out


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/users/{user_id}", response_model=UserInfo)
    def get_user(
        user_id: str,
        viewer: UserState | None = Depends(app.get_current_user_or_none),
    ):
        u = app.state_backend.get_user(user_id)
        if u is None:
            raise HTTPException(404, f"User not found: {user_id}")
        info = _user_info(app, u)
        # Owner + admin always see the unfiltered view.
        is_owner = viewer is not None and viewer.user_id == user_id
        is_admin = viewer is not None and viewer.is_admin
        if is_owner or is_admin:
            return info
        return _apply_visibility(info, dict(u.profile_visibility))

    @router.get("/users/{user_id}/solve-trend", response_model=UserSolveTrend)
    def get_user_solve_trend(
        user_id: str,
        days: int = Query(default=30, ge=7, le=365),
        viewer: UserState | None = Depends(app.get_current_user_or_none),
    ):
        """User-scoped daily solve count, replacing the legacy
        ``/teams/{id}/profile-stats.solve_trend`` lookup the Dashboard
        used to do via ``current_team_id``.

        Visibility: owner + admin always see the trend; for everyone
        else we honor the user's ``solve_trend`` privacy bit (mirrored
        from the team-profile field of the same name) and emit an
        empty list when it's off.
        """
        u = app.state_backend.get_user(user_id)
        if u is None:
            raise HTTPException(404, f"User not found: {user_id}")
        is_owner = viewer is not None and viewer.user_id == user_id
        is_admin = viewer is not None and viewer.is_admin
        if not (is_owner or is_admin):
            if u.profile_visibility.get("solve_trend") is False:
                return UserSolveTrend(solve_trend=[])
        return UserSolveTrend(solve_trend=_user_solve_trend(app, user_id, days))

    return router


__all__ = [
    "create_router",
    "_user_info",
    "_apply_visibility",
    "_user_solve_trend",
]
