"""Scoreboard endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi_pagination import paginate as list_paginate

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.state.models import ScoreboardSnapshotState
from ctfy.server.app_state import AppState
from ctfy.server.models import (
    BigLimitOffsetPage,
    ChallengeFlagStats,
    ChallengeStats,
    ScoreboardEntry,
    UserScoreboardEntry,
)


def _spec_flag_ids(app: AppState) -> dict[str, list[str]]:
    """Map challenge_id → declared flag ids. Cached per-call."""
    return {spec.id: list(spec.flags) for spec in app.spec_reader.iter_specs()}


def _pick_avatar(app: AppState, team_id: str) -> str:
    """Pick an avatar URL for a team using the audit-decided rule:

    1. Iterate over the team's OAuth identities.
    2. Sort by ``created_at`` ascending — earliest binding wins when
       a team has bound both GitHub and Google.
    3. Return the first ``avatar_url`` we find.

    Returns ``""`` for teams with no OAuth identity (password-only).
    The scoreboard renderer falls back to a generated initials chip.
    """
    # Avatar lives on the captain user post user/team-split; fall back
    # to any member with an OAuth avatar when the team has no captain.
    team = app.state_backend.get_team(team_id)
    if team is None:
        return ""
    user_id = team.captain_user_id
    identities = (
        app.state_backend.list_identities_for_user(user_id) if user_id else []
    )
    if not identities:
        return ""
    # Empty ``created_at`` (legacy rows pre-dating the field) sort last
    # so they don't claim to be the "earliest" binding by accident.
    by_age = sorted(
        identities,
        key=lambda i: (i.created_at == "", i.created_at),
    )
    for ident in by_age:
        if ident.avatar_url:
            return ident.avatar_url
    return ""


def compute_scoreboard_filtered(
    app: AppState,
    *,
    team_filter: dict[str, str] | None = None,
    challenge_ids: set[str] | None = None,
    until_iso: str = "",
) -> list[ScoreboardEntry]:
    """Compute a ranked scoreboard with optional filters.

    Shared by the global ``/scoreboard`` route, the snapshot background
    loop, and the per-competition leaderboard. Primary sort is
    ``flags_solved`` desc (rewards partial progress across multi-flag
    challenges); tiebreakers: more fully-solved challenges, then earlier
    ``last_solve_at``.

    Filters:
      * ``team_filter=None`` → every team participates (global path).
        ``team_filter`` as a ``dict[team_id -> since_iso]`` restricts
        to those teams and applies ``since_iso`` as a per-team lower
        bound on ``solved_at`` / ``submitted_at``. Each value is the
        time the team became eligible to score (e.g.
        ``max(competition.starts_at, registration.registered_at)``);
        an empty value means "no lower bound for this team".
      * ``challenge_ids=None`` → all spec challenges count. Otherwise
        only solves/submissions on those challenge ids are counted, and
        the ``solved`` (fully-solved) tally intersects with the subset.
      * ``until_iso=""`` → no upper bound. Otherwise solves/submissions
        with ``solved_at`` / ``submitted_at`` ≥ ``until_iso`` are
        excluded (competition window closes at this instant).
    """
    flag_ids_by_challenge = _spec_flag_ids(app)
    if challenge_ids is not None:
        # Restrict the "fully solved" map to the curated subset so a
        # competition counts a challenge only when every declared flag
        # *that exists in the spec* is captured.
        flag_ids_by_challenge = {
            cid: flags
            for cid, flags in flag_ids_by_challenge.items()
            if cid in challenge_ids
        }

    if team_filter is None:
        teams = app.state_backend.list_teams()
        team_iter: list[tuple[str, str, str]] = [
            (t.team_id, t.name, "") for t in teams
        ]
    else:
        team_iter = []
        for tid, since in team_filter.items():
            team = app.state_backend.get_team(tid)
            if team is None:
                continue
            team_iter.append((tid, team.name, since))

    def _in_window(ts: str, since: str) -> bool:
        if since and ts < since:
            return False
        if until_iso and ts >= until_iso:
            return False
        return True

    entries: list[ScoreboardEntry] = []
    for tid, team_name, since in team_iter:
        avatar = _pick_avatar(app, tid)
        all_solves = app.state_backend.list_solves(tid)
        if challenge_ids is not None or since or until_iso:
            solves = [
                s
                for s in all_solves
                if (challenge_ids is None or s.challenge_id in challenge_ids)
                and _in_window(s.solved_at, since)
            ]
        else:
            solves = all_solves
        last_active = ""
        recent = app.state_backend.list_activities(team_id=tid, offset=0, limit=1)
        if recent:
            last_active = recent[0].timestamp
        if not solves:
            entries.append(
                ScoreboardEntry(
                    team_id=tid,
                    team_name=team_name,
                    solved=0,
                    flags_solved=0,
                    attempts=0,
                    last_active_at=last_active,
                    avatar_url=avatar,
                )
            )
            continue
        last = max(s.solved_at for s in solves)
        all_subs = app.state_backend.list_submissions(team_id=tid)
        if challenge_ids is not None or since or until_iso:
            relevant_subs = [
                s
                for s in all_subs
                if (challenge_ids is None or s.challenge_id in challenge_ids)
                and _in_window(s.submitted_at, since)
            ]
        else:
            relevant_subs = all_subs
        attempts = len(relevant_subs)
        flags_solved = len(solves)
        per_chal: dict[str, set[str]] = {}
        for s in solves:
            per_chal.setdefault(s.challenge_id, set()).add(s.flag_id)
        fully_solved_count = sum(
            1
            for cid, captured in per_chal.items()
            if cid in flag_ids_by_challenge
            and set(flag_ids_by_challenge[cid]) <= captured
        )
        entries.append(
            ScoreboardEntry(
                team_id=tid,
                team_name=team_name,
                solved=fully_solved_count,
                flags_solved=flags_solved,
                attempts=attempts,
                last_solve_at=last,
                last_active_at=last_active,
                avatar_url=avatar,
            )
        )
    entries.sort(key=lambda e: (-e.flags_solved, -e.solved, e.last_solve_at))
    for i, e in enumerate(entries):
        e.rank = i + 1
    return entries


def compute_scoreboard(app: AppState) -> list[ScoreboardEntry]:
    """Backwards-compatible wrapper for the global, all-time scoreboard.

    Preserved as a thin ``compute_scoreboard_filtered`` call so the
    snapshot background loop and existing callers don't need to know
    about the filter parameters.
    """
    return compute_scoreboard_filtered(app)


def compute_user_scoreboard(app: AppState) -> list[UserScoreboardEntry]:
    """User-ranked global scoreboard — Phase 3b.

    Aggregates every solve at the user level (each ``SolveState``
    carries ``user_id``, the human who submitted). Sums across every
    team the user has ever been on, sorts by total flags solved.
    Excludes users with zero solves so the public list stays compact.

    Per-user metrics:
    * ``flags_solved`` — total individual flag captures.
    * ``solved`` — challenges where the user captured every declared
      flag.
    * ``last_solve_at`` — most recent solve timestamp (tiebreaker
      after flags + solved).
    """
    flag_ids_by_challenge = _spec_flag_ids(app)
    # ``list_solves()`` returns every solve in the system; group by
    # user_id. Solves with empty user_id (legacy pre-split rows) are
    # skipped — they don't have a human to credit.
    per_user_solves: dict[str, list] = {}
    for s in app.state_backend.list_solves():
        if not s.user_id:
            continue
        per_user_solves.setdefault(s.user_id, []).append(s)

    entries: list[UserScoreboardEntry] = []
    for user_id, solves in per_user_solves.items():
        if not solves:
            continue
        user = app.state_backend.get_user(user_id)
        if user is None:
            continue
        # Per-challenge captured flag set so we can count fully-solved
        # challenges (every declared flag for that challenge).
        per_chal: dict[str, set[str]] = {}
        for s in solves:
            per_chal.setdefault(s.challenge_id, set()).add(s.flag_id)
        fully_solved = sum(
            1
            for cid, captured in per_chal.items()
            if cid in flag_ids_by_challenge
            and set(flag_ids_by_challenge[cid]) <= captured
        )
        last_solve_at = max(s.solved_at for s in solves)
        entries.append(
            UserScoreboardEntry(
                user_id=user_id,
                display_name=user.display_name or user.email or user.user_id,
                avatar_url=user.avatar_url or "",
                country=user.country or "",
                flags_solved=len(solves),
                solved=fully_solved,
                last_solve_at=last_solve_at,
            )
        )
    # Same sort key as team scoreboard: flags_solved desc, solved
    # desc, then earliest last_solve_at as tiebreaker.
    entries.sort(key=lambda e: (-e.flags_solved, -e.solved, e.last_solve_at))
    for i, e in enumerate(entries):
        e.rank = i + 1
    return entries


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/scoreboard", response_model=BigLimitOffsetPage[ScoreboardEntry])
    @app.limiter.limit(app.config.rate_limit_scoreboard)
    def get_scoreboard(request: Request):
        return list_paginate(compute_scoreboard(app))

    @router.get(
        "/scoreboard/users",
        response_model=BigLimitOffsetPage[UserScoreboardEntry],
    )
    @app.limiter.limit(app.config.rate_limit_scoreboard)
    def get_user_scoreboard(request: Request):
        """User-ranked global scoreboard. Aggregates solves across
        every team a user has been on (post per-comp team refactor a
        user can hold N memberships). The team-ranked /scoreboard
        stays for admin overview + per-comp variant."""
        return list_paginate(compute_user_scoreboard(app))

    @router.get(
        "/scoreboard/history",
        response_model=BigLimitOffsetPage[ScoreboardSnapshotState],
    )
    @app.limiter.limit(app.config.rate_limit_scoreboard)
    def get_scoreboard_history(
        request: Request,
        team_id: str = "",
        days: int = 7,
    ):
        """Point-in-time scoreboard snapshots for chart rendering.

        Samples are captured every SCOREBOARD_SNAPSHOT_INTERVAL seconds
        by a background loop and kept permanently. Callers pass
        ``team_id`` to get one team's trend, or leave it empty for
        every team in the window.

        ``days`` defaults to 7 (the usual chart window). ``days=0``
        means "no lower bound, return everything" — useful for
        post-competition exports. Anything above 365 is clamped as an
        API-level sanity guard against an accidental multi-year scan.
        """
        import time

        if days < 0:
            days = 0
        elif days > 365:
            days = 365
        since_ts = 0.0 if days == 0 else time.time() - days * 86400.0
        return list_paginate(
            app.state_backend.list_snapshots(
                team_id=team_id,
                since_ts=since_ts,
            )
        )

    @router.get("/scoreboard/challenges", response_model=BigLimitOffsetPage[ChallengeStats])
    @app.limiter.limit(app.config.rate_limit_scoreboard)
    def get_challenge_stats(request: Request):
        result = []
        for spec in app.spec_reader.iter_specs():
            cid = spec.id
            flag_ids = tuple(spec.flags)
            solves = [s for s in app.state_backend.list_solves() if s.challenge_id == cid]
            all_subs = app.state_backend.list_submissions(challenge_id=cid)
            correct_subs = [s for s in all_subs if s.correct]
            success_rate = len(correct_subs) / len(all_subs) * 100 if all_subs else 0
            # Full-challenge solves = teams that captured every flag.
            fully_solved = app.state_backend.count_solves_for_challenge(cid, flag_ids)
            # Per-flag breakdown for the detail page.
            per_flag_counts: dict[str, int] = {fid: 0 for fid in flag_ids}
            for s in solves:
                if s.flag_id in per_flag_counts:
                    per_flag_counts[s.flag_id] += 1
            flag_stats = [
                ChallengeFlagStats(flag_id=fid, solves_count=per_flag_counts[fid])
                for fid in flag_ids
            ]
            result.append(
                ChallengeStats(
                    challenge_id=cid,
                    name=spec.name,
                    category=ChallengeSpec.CATEGORY,
                    difficulty=spec.difficulty.value,
                    solves_count=fully_solved,
                    total_attempts=len(all_subs),
                    success_rate=round(success_rate, 1),
                    flag_stats=flag_stats,
                )
            )
        return list_paginate(result)

    return router
