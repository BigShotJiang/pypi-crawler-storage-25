"""Aggregate analytics for the public team profile.

Powers the GitHub-style contribution calendar, the per-tag strength
radar, the difficulty bar chart, and the 30-day solve trend on
``/teams/:id``. One endpoint, four sections, all pre-aggregated server-
side so the browser doesn't replay every solve / submission row.

Visibility: each section is gated independently against the team's
``profile_visibility`` map. Owner + admin always see the full payload;
anyone else gets ``[]`` for sections the team marked private.
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query

from ctfy.core.exceptions import TeamNotFoundError
from ctfy.core.state.models import UserState
from ctfy.server.app_state import AppState
from ctfy.server.models import (
    CalendarBucket,
    DifficultyStat,
    ProfileStats,
    TagStat,
    TrendPoint,
)

# How many tags to surface on the radar. Beyond this the polygon
# starts to look like static and small-tag noise drowns out signal.
_MAX_TAG_AXES = 8

# Window for the solve-trend line. Keep it independent from the
# calendar window: the line is a recent-trajectory view, the heatmap
# is a year-at-a-glance.
_SOLVE_TREND_DAYS = 30


def _utc_day(iso_ts: str) -> str | None:
    """Convert an ISO-8601 timestamp into ``YYYY-MM-DD`` (UTC)."""
    if not iso_ts:
        return None
    try:
        # ``Z`` suffix is RFC3339 but not understood by fromisoformat
        # before py3.11; normalise.
        s = iso_ts[:-1] + "+00:00" if iso_ts.endswith("Z") else iso_ts
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).date().isoformat()


def _zero_filled(window_days: int, counts: dict[str, int]) -> list[CalendarBucket]:
    """Dense list of ``CalendarBucket`` covering the last ``window_days``
    UTC days, ending with today. Days with no activity get a 0 bucket
    so the frontend can render a stable 7×N grid without branching."""
    today = datetime.now(timezone.utc).date()
    out: list[CalendarBucket] = []
    for i in range(window_days - 1, -1, -1):
        d = today - timedelta(days=i)
        out.append(CalendarBucket(date=d.isoformat(), count=counts.get(d.isoformat(), 0)))
    return out


def _zero_filled_trend(window_days: int, counts: dict[str, int]) -> list[TrendPoint]:
    today = datetime.now(timezone.utc).date()
    out: list[TrendPoint] = []
    for i in range(window_days - 1, -1, -1):
        d = today - timedelta(days=i)
        out.append(TrendPoint(date=d.isoformat(), solves=counts.get(d.isoformat(), 0)))
    return out


def _compute_stats(app: AppState, team_id: str, calendar_days: int) -> ProfileStats:
    # Build a (challenge_id → spec) map from disk once. iter_specs is
    # cheap (yaml.safe_load per challenge dir) and only runs on a
    # profile fetch, so we tolerate the cost rather than caching it.
    specs = {s.id: s for s in app.spec_reader.iter_specs()}

    solves = app.state_backend.list_solves(team_id)

    # ---- Calendar — count first-time flag captures per UTC day.
    # Multi-flag challenges register on every flag day (one SolveState
    # per (team, challenge, flag)). We deliberately ignore replayed
    # submissions of an already-solved flag because they aren't
    # contributions.
    calendar_counts: dict[str, int] = {}
    cutoff = (datetime.now(timezone.utc).date() - timedelta(days=calendar_days - 1)).isoformat()
    for s in solves:
        d = _utc_day(s.solved_at)
        if d and d >= cutoff:
            calendar_counts[d] = calendar_counts.get(d, 0) + 1

    # ---- Tags — compute platform-wide totals + this team's solves.
    # Pick the top N tags by total challenge count so the radar has a
    # stable axis set across teams (one team's solves don't reshuffle
    # the polygon for another).
    tag_total = Counter[str]()
    for spec in specs.values():
        for tag in spec.tags:
            tag_total[tag] += 1

    tag_team = Counter[str]()
    seen_challenges: set[str] = set()
    for solve in solves:
        # A multi-flag solve emits one SolveState per flag; collapse to
        # one challenge so a 3-flag challenge doesn't 3× the tag count.
        if solve.challenge_id in seen_challenges:
            continue
        seen_challenges.add(solve.challenge_id)
        spec = specs.get(solve.challenge_id)
        if not spec:
            continue
        for tag in spec.tags:
            tag_team[tag] += 1

    top_tags = [tag for tag, _ in tag_total.most_common(_MAX_TAG_AXES)]
    by_tag = [
        TagStat(tag=tag, solved=tag_team.get(tag, 0), total=tag_total[tag])
        for tag in top_tags
    ]

    # ---- Difficulty — same idea, no cap (typical CTFs ship 3–4 buckets).
    diff_total = Counter[str]()
    for spec in specs.values():
        diff_total[spec.difficulty.value] += 1
    diff_team = Counter[str]()
    seen_challenges_d: set[str] = set()
    for solve in solves:
        if solve.challenge_id in seen_challenges_d:
            continue
        seen_challenges_d.add(solve.challenge_id)
        spec = specs.get(solve.challenge_id)
        if not spec:
            continue
        diff_team[spec.difficulty.value] += 1
    # Sort easy → hard by the platform's canonical order when we know
    # it; fall back to alphabetical so unknown difficulties stay stable.
    canonical_order = ("easy", "medium", "hard", "insane")
    rank = {d: i for i, d in enumerate(canonical_order)}
    diffs = sorted(
        diff_total.keys(),
        key=lambda d: (rank.get(d, len(canonical_order)), d),
    )
    by_difficulty = [
        DifficultyStat(difficulty=d, solved=diff_team.get(d, 0), total=diff_total[d])
        for d in diffs
    ]

    # ---- Solve trend — last 30 days, zero-filled.
    trend_cutoff = (
        datetime.now(timezone.utc).date() - timedelta(days=_SOLVE_TREND_DAYS - 1)
    ).isoformat()
    trend_counts: dict[str, int] = {}
    for solve in solves:
        d = _utc_day(solve.solved_at)
        if d and d >= trend_cutoff:
            trend_counts[d] = trend_counts.get(d, 0) + 1

    return ProfileStats(
        calendar=_zero_filled(calendar_days, calendar_counts),
        by_tag=by_tag,
        by_difficulty=by_difficulty,
        solve_trend=_zero_filled_trend(_SOLVE_TREND_DAYS, trend_counts),
    )


def _apply_visibility(stats: ProfileStats, visibility: dict[str, bool]) -> ProfileStats:
    """Empty out sections the team marked private. ``visibility`` keys
    here mirror the labels in :data:`PROFILE_VISIBILITY_KEYS`."""
    if not visibility:
        return stats
    update: dict[str, object] = {}
    if visibility.get("activity_calendar") is False:
        update["calendar"] = []
    if visibility.get("tag_stats") is False:
        update["by_tag"] = []
    if visibility.get("difficulty_stats") is False:
        update["by_difficulty"] = []
    if visibility.get("solve_trend") is False:
        update["solve_trend"] = []
    if not update:
        return stats
    return stats.model_copy(update=update)


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/teams/{team_id}/profile-stats", response_model=ProfileStats)
    def get_team_profile_stats(
        team_id: str,
        days: int = Query(default=365, ge=7, le=365),
        viewer: UserState | None = Depends(app.get_current_user_or_none),
    ):
        """Aggregated stats powering the public profile visualizations.

        Visibility comes from the captain user's profile_visibility map
        (post user/team-split that's where the per-field privacy lives).
        Owner = any current member of the team; admin always sees all.
        """
        team = app.state_backend.get_team(team_id)
        if not team:
            raise TeamNotFoundError(team_id)
        stats = _compute_stats(app, team_id, calendar_days=days)
        is_owner = False
        is_admin = False
        if viewer is not None:
            is_admin = viewer.is_admin
            # Owner = the viewer is on this team via *any* membership
            # (legacy default slot or per-comp). list_memberships
            # filtered by user_id is the only API that surfaces both —
            # get_membership() only checks the legacy slot and would
            # miss owners who joined the team in a competition.
            is_owner = any(
                m.team_id == team_id
                for m in app.state_backend.list_memberships(user_id=viewer.user_id)
            )
        if is_owner or is_admin:
            return stats
        captain_visibility: dict[str, bool] = {}
        if team.captain_user_id:
            captain = app.state_backend.get_user(team.captain_user_id)
            if captain is not None:
                captain_visibility = dict(captain.profile_visibility)
        return _apply_visibility(stats, captain_visibility)

    return router


# Re-export for the day-helper unit tests.
__all__ = ("create_router", "_utc_day", "_compute_stats", "_apply_visibility")
