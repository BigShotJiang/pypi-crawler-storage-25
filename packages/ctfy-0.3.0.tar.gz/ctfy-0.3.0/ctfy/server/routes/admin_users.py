"""Admin user-management endpoints.

Replaces the old ``/admin/teams/{id}/role`` surface — privilege now
lives on the user, not the team. Two endpoints:

* ``GET /admin/users`` — full listing with role + audit fields. Any
  admin can read; the table powers the AdminTeams page in the SPA.
* ``PATCH /admin/users/{user_id}/role`` — super-admin only; promote /
  demote between ``"user"`` and ``"admin"``.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from fastapi_pagination import paginate as list_paginate

from ctfy.core.exceptions import TeamNotFoundError
from ctfy.core.log import log
from ctfy.core.state.models import UserState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.event_payloads import TeamRoleChangedPayload
from ctfy.server.events import emit_event
from ctfy.server.models import (
    AdminUserInfo,
    BigLimitOffsetPage,
    UpdateUserRoleRequest,
)
from ctfy.server.routes.me import _user_aggregates


def _admin_user_info(app: AppState, u: UserState) -> AdminUserInfo:
    solves, attempts, last_active = _user_aggregates(app, u.user_id)
    return AdminUserInfo(
        user_id=u.user_id,
        display_name=u.display_name,
        avatar_url=u.avatar_url,
        created_at=u.created_at,
        bio=u.bio,
        country=u.country,
        website_url=u.website_url,
        timezone=u.timezone,
        social_links=dict(u.social_links),
        solves=solves,
        attempts=attempts,
        last_active_at=last_active,
        email=u.email,
        role=u.role,
        promoted_by=u.promoted_by,
        promoted_at=u.promoted_at,
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/admin/users",
        response_model=BigLimitOffsetPage[AdminUserInfo],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_list_users():
        rows = [_admin_user_info(app, u) for u in app.state_backend.list_users()]
        return list_paginate(rows)

    @router.get(
        "/admin/users/{user_id}",
        response_model=AdminUserInfo,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_get_user(user_id: str):
        """Single-user lookup with the same shape as the list row.

        AdminTeams' user-detail page can fetch one user by id without
        scanning the whole list — the list pagination would otherwise
        force the SPA to walk every page just to find one row by id.
        """
        target = app.state_backend.get_user(user_id)
        if target is None:
            raise HTTPException(404, "User not found")
        return _admin_user_info(app, target)

    @router.patch("/admin/users/{user_id}/role", response_model=AdminUserInfo)
    def admin_set_user_role(
        user_id: str,
        body: UpdateUserRoleRequest,
        caller: UserState = Depends(app.require_super_admin),
    ):
        """Promote or demote a user between ``user`` and ``admin``.

        Same safety rails as the legacy team-scoped endpoint:
          * can't change a super_admin (env-anchored)
          * can't change your own role
        """
        target = app.state_backend.get_user(user_id)
        if not target:
            raise TeamNotFoundError(user_id)
        if target.user_id == caller.user_id:
            raise HTTPException(400, "You cannot change your own role")
        if target.role == "super_admin":
            raise HTTPException(
                403,
                "Cannot change a super-admin's role through the API; "
                "manage CTFY_SUPER_ADMIN_EMAILS instead",
            )
        if target.role == body.role:
            return _admin_user_info(app, target)
        previous_role = target.role
        updated = target.model_copy(
            update={
                "role": body.role,
                "promoted_by": caller.user_id,
                "promoted_at": now_iso(),
            }
        )
        app.state_backend.put_user(target.user_id, updated)
        log.info(
            "User role changed",
            user_id=target.user_id,
            previous_role=previous_role,
            new_role=body.role,
            actor_id=caller.user_id,
        )
        # Role changes are user-level, not team-level — emit with an
        # empty team envelope. The activity log row still records who
        # changed whose role via actor_id / detail.
        emit_event(
            app,
            TeamRoleChangedPayload(
                team_id="",
                team_name="",
                previous_role=previous_role,
                new_role=body.role,
            ),
            actor_id=caller.user_id,
            actor_name=caller.display_name or caller.email or caller.user_id,
            actor_type="admin",
            admin_only=True,
        )
        return _admin_user_info(app, updated)

    return router


__all__ = ["create_router", "_admin_user_info"]
