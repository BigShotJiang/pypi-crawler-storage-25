"""Multi-node cluster management endpoints."""

from __future__ import annotations

import secrets
import time

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi_pagination import paginate as list_paginate

from ctfy.core.constants import HEARTBEAT_TIMEOUT
from ctfy.core.log import log
from ctfy.core.state.models import NodeHealthSample, NodeInviteState, NodeState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.auth import check_node_identity
from ctfy.server.event_payloads import (
    NodeRecoveredPayload,
    NodeRegisteredPayload,
    NodeRemovedPayload,
    NodeUpdatedPayload,
)
from ctfy.server.events import emit_event
from ctfy.server.models import (
    BigLimitOffsetPage,
    NodeHeartbeat,
    NodeInfo,
    NodePatch,
    NodeRegister,
    NodeRegisterResponse,
)
from ctfy.server.node_status import emit_node_status
from ctfy.server.request_meta import client_ip


def _node_to_info(node: NodeState, *, healthy: bool) -> NodeInfo:
    """Project a ``NodeState`` to the public ``NodeInfo`` payload.

    Strips the bearer token and back-fills ``registered_at`` for rows
    that pre-date the field — those rows have ``registered_at == ""``
    in the JSON blob; falling back to ``last_heartbeat`` keeps the
    admin UI from showing "—" on every long-running node after the
    upgrade.
    """
    info = node.model_copy(update={"healthy": healthy}).model_dump(exclude={"token"})
    if not info.get("registered_at"):
        info["registered_at"] = info.get("last_heartbeat", "") or ""
    return NodeInfo(**info)


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.post(
        "/nodes/register",
        response_model=NodeRegisterResponse,
    )
    def register_node(
        request: Request,
        req: NodeRegister,
        caller: NodeInviteState | None = Depends(app.require_invite_or_admin),
    ):
        """Register a worker node.

        Accepted auth paths:

        * **Invite token** (recommended): a one-time registration token
          minted by ``POST /nodes/invites``. Consumed atomically on
          success so the same plaintext cannot register a second node.
        * **Admin token**: operator escape hatch for the rare case where
          the platform UI / CLI cannot mint an invite first.

        Mints a single per-node bearer token used in both directions
        (heartbeat + platform→node commands) and returns it exactly
        once. Re-registration rotates the token.
        """
        node_id = req.url.rstrip("/").split("//")[-1].replace(":", "_").replace("/", "_")
        now = now_iso()
        node_token = secrets.token_urlsafe(32)
        # Preserve ``registered_at`` across re-registration. The token
        # rotates on every POST /nodes (that's by design), but the row's
        # join time should not — operators expect the admin card to keep
        # showing the original join, not move forward to "0s ago" each
        # time a node restarts and re-registers.
        existing = app.state_backend.get_node(node_id)
        registered_at = existing.registered_at if existing and existing.registered_at else now
        data = NodeState(
            node_id=node_id,
            url=req.url.rstrip("/"),
            display_name=req.display_name,
            capacity=req.capacity,
            running=0,
            healthy=True,
            last_heartbeat=now,
            last_heartbeat_ts=time.time(),
            registered_at=registered_at,
            labels=req.labels,
            token=node_token,
        )
        app.state_backend.put_node(node_id, data)

        # If the caller authenticated with an invite, burn it now that the
        # node exists. CAS on `consumed_at_ts == 0` — a parallel register
        # attempt with the same token will get None, which is preferable
        # to two nodes sharing a minted invite.
        if caller is not None:
            consumed = app.state_backend.consume_invite(caller.token_hash, node_id)
            if consumed is None:
                app.state_backend.remove_node(node_id)
                raise HTTPException(409, "Invite was consumed by a concurrent registration")

        # Registration is either via an admin-minted invite (caller set) or
        # directly by the admin token (caller is None). Either way the
        # effective actor is "admin" — the platform operator approved the
        # node joining the cluster.
        emit_event(
            app,
            NodeRegisteredPayload(node_id=node_id, url=req.url.rstrip("/")),
            actor_id="admin",
            actor_name="admin",
            actor_type="admin",
        )
        log.info(
            "Node registered",
            node_id=node_id,
            url=req.url,
            capacity=req.capacity,
            via_invite=caller is not None,
            invite_id=caller.invite_id if caller is not None else "",
            client_ip=client_ip(request),
        )
        return NodeRegisterResponse(
            **data.model_dump(exclude={"token"}),
            node_token=node_token,
        )

    @router.post("/nodes/heartbeat")
    def node_heartbeat(
        req: NodeHeartbeat,
        caller: NodeState | None = Depends(app.require_node_or_admin),
    ):
        """Heartbeat from a worker node.

        Updates running count + timestamp + the latest resource sample
        (CPU / memory / disk). Auth: per-node token (must match
        ``node_id``) or admin token.
        """
        check_node_identity(caller, req.node_id)
        node = app.state_backend.get_node(req.node_id)
        if not node:
            raise HTTPException(404, "Node not registered")
        now_ts = time.time()
        was_unhealthy = not node.healthy
        prev_last_heartbeat_ts = node.last_heartbeat_ts
        # One-way latency: time the heartbeat spent in flight from when
        # the node sampled metrics to when it landed here. ``sampled_at``
        # is 0 on pre-upgrade nodes — record 0 (= "no measurement") so
        # the chart can ignore those points.
        latency_ms = (
            max(0.0, (now_ts - req.sampled_at) * 1000.0) if req.sampled_at > 0 else 0.0
        )
        node = node.model_copy(
            update={
                "running": req.running,
                "capacity": req.capacity,
                "cpu_percent": req.cpu_percent,
                "memory_percent": req.memory_percent,
                "disk_percent": req.disk_percent,
                "healthy": True,
                "last_heartbeat": now_iso(),
                "last_heartbeat_ts": now_ts,
            }
        )
        app.state_backend.put_node(req.node_id, node)
        # Feed the uptime-kuma-style history. Ring is trimmed in the
        # same transaction as the insert (see state backend).
        sample = NodeHealthSample(
            node_id=req.node_id,
            ts=now_ts,
            healthy=True,
            cpu_percent=req.cpu_percent,
            memory_percent=req.memory_percent,
            disk_percent=req.disk_percent,
            latency_ms=latency_ms,
        )
        app.state_backend.append_health_sample(sample)
        # Push the freshest sample to admin SSE clients so the
        # NodeStatusStrip can append a slot without polling.
        emit_node_status(app, sample)
        # Recovery — the node was marked unhealthy (reconciler timeout
        # or explicit) and is now beating again. Emit a paired event so
        # the admin UI can present a closed downtime window with
        # duration. ``downtime_seconds`` ignores reconciler-detection
        # latency: it's the gap between the last successful heartbeat
        # and this one, which is what an operator actually cares about.
        if was_unhealthy:
            downtime = (
                max(0.0, now_ts - prev_last_heartbeat_ts)
                if prev_last_heartbeat_ts > 0
                else 0.0
            )
            emit_event(
                app,
                NodeRecoveredPayload(
                    node_id=req.node_id,
                    url=node.url,
                    downtime_seconds=downtime,
                ),
                actor_id="system",
                actor_name="reconciler",
                actor_type="system",
            )
            log.info(
                "Node recovered",
                node_id=req.node_id,
                downtime_seconds=round(downtime, 1),
            )
        return {"status": "ok"}

    @router.get("/nodes", response_model=BigLimitOffsetPage[NodeInfo])
    def list_nodes():
        """List all registered worker nodes."""
        now = time.time()
        result = []
        for n in app.state_backend.list_nodes():
            lb = n.last_heartbeat_ts
            healthy = bool(lb and (now - lb) < HEARTBEAT_TIMEOUT)
            result.append(_node_to_info(n, healthy=healthy))
        return list_paginate(result)

    @router.delete("/nodes/{node_id}")
    def remove_node(
        node_id: str,
        request: Request,
        caller: NodeState | None = Depends(app.require_node_or_admin),
    ):
        """Deregister a node. A per-node token may only remove its own
        node; admin may remove any node.
        """
        check_node_identity(caller, node_id)
        app.state_backend.remove_node(node_id)
        log.info(
            "Node deregistered",
            node_id=node_id,
            actor="admin" if caller is None else "node",
            client_ip=client_ip(request),
        )
        # caller is None when admin-token-authenticated, else it's the node
        # itself (per-node bearer). Record accordingly for audit.
        if caller is None:
            emit_event(
                app,
                NodeRemovedPayload(node_id=node_id),
                actor_id="admin",
                actor_name="admin",
                actor_type="admin",
            )
        else:
            emit_event(
                app,
                NodeRemovedPayload(node_id=node_id),
                actor_id=caller.node_id,
                actor_name=caller.url or caller.node_id,
                actor_type="node",
            )
        return {"status": "removed", "node_id": node_id}

    @router.get(
        "/admin/nodes/{node_id}",
        response_model=NodeInfo,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_get_node(node_id: str) -> NodeInfo:
        """Admin-scoped single-node view for the detail page.

        Returns the same NodeInfo shape as the list endpoint; the admin
        detail page pairs it with health history via the existing
        ``/admin/nodes/{id}/health-history`` route.
        """
        node = app.state_backend.get_node(node_id)
        if node is None:
            raise HTTPException(404, f"Node {node_id} not found")
        now = time.time()
        lb = node.last_heartbeat_ts
        healthy = bool(lb and (now - lb) < HEARTBEAT_TIMEOUT)
        return _node_to_info(node, healthy=healthy)

    @router.patch(
        "/admin/nodes/{node_id}",
        response_model=NodeInfo,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_patch_node(node_id: str, patch: NodePatch) -> NodeInfo:
        """Update editable node metadata (display_name, labels).

        Fields left unset on the request preserve their current value —
        PATCH semantics, not PUT. Emits ``node_updated`` with a compact
        ``labels_changed`` list so the audit feed can point reviewers at
        what changed without re-shipping the full label dict.
        """
        current = app.state_backend.get_node(node_id)
        if current is None:
            raise HTTPException(404, f"Node {node_id} not found")

        updates: dict = {}
        labels_changed: list[str] = []

        if patch.display_name is not None:
            updates["display_name"] = patch.display_name

        if patch.labels is not None:
            # Diff keys + value-changed to populate labels_changed so the
            # event payload carries the delta without the full new dict.
            old = current.labels
            new = patch.labels
            for key in set(old) | set(new):
                if old.get(key) != new.get(key):
                    labels_changed.append(key)
            updates["labels"] = new

        if not updates:
            # No-op PATCH — don't emit an event for nothing.
            return _node_to_info(current, healthy=current.healthy)

        updated = current.model_copy(update=updates)
        app.state_backend.put_node(node_id, updated)

        emit_event(
            app,
            NodeUpdatedPayload(
                node_id=node_id,
                display_name=updated.display_name,
                labels_changed=sorted(labels_changed),
            ),
            actor_id="admin",
            actor_name="admin",
            actor_type="admin",
        )
        log.info(
            "Node updated",
            node_id=node_id,
            display_name=updated.display_name,
            labels_changed=labels_changed,
        )
        return _node_to_info(updated, healthy=updated.healthy)

    return router
