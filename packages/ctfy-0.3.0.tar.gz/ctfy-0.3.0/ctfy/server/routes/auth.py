"""OAuth login + identity/token management endpoints.

Public surface (``/api/v1/auth/...``):

* ``GET  /auth/providers`` — list enabled OAuth providers (unauthenticated)
* ``GET  /auth/login/{provider}`` — 302 to the provider's authorize URL
* ``GET  /auth/callback/{provider}`` — provider hits this; we resolve the
  identity, mint a fresh user-kind token, and 302 back to the SPA with
  the token in a URL fragment.
* ``POST /auth/identities/link/{provider}`` — (user-kind only) returns
  an authorize URL that, on callback, binds the new identity to the
  caller's user instead of creating a new account.
* ``GET  /auth/identities`` — (user-kind only) list identities bound to
  the caller's user.
* ``DELETE /auth/identities/{identity_id}`` — (user-kind only) unbind;
  blocks unlinking the last identity to prevent lockout.
* ``GET  /auth/tokens`` — (user-kind only) list tokens (plaintext never
  returned).
* ``POST /auth/tokens`` — (user-kind only) mint a new agent token;
  plaintext returned exactly once.
* ``DELETE /auth/tokens/{token_id}`` — (user-kind only) revoke a token.

Post user/team-split: registration creates a fresh ``UserState`` plus a
personal ``TeamState`` (the user is the captain) plus a
``TeamMembershipState`` joining them — so the legacy "register and
you're a team" UX keeps working. Tokens and identities point at the
user; the user's current team is resolved through the membership row
on every authenticated request.
"""

from __future__ import annotations

import secrets
import uuid
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode, urlparse

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from fastapi_pagination import paginate as list_paginate

from ctfy.core.log import log
from ctfy.core.state.models import (
    OAuthIdentity,
    PasswordIdentity,
    TeamToken,
    UserState,
)
from ctfy.server.achievements.catalog import get as get_catalog_entry
from ctfy.server.achievements.engine import maybe_grant_combo
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.auth import hash_token, is_token_expired
from ctfy.server.event_payloads import AchievementUnlockedPayload
from ctfy.server.events import emit_event
from ctfy.server.models import (
    AuthTokenResponse,
    BigLimitOffsetPage,
    CreateAgentTokenRequest,
    CreateAgentTokenResponse,
    LinkedIdentity,
    LinkStartResponse,
    LoginRequest,
    OAuthProviderInfo,
    PasswordAuthInfo,
    ProvidersResponse,
    RegisterRequest,
    SetPasswordRequest,
    TokenInfo,
)
from ctfy.server.oauth.providers import OAuthProfile, OAuthProvider
from ctfy.server.oauth.state import sign_state, verify_state
from ctfy.server.password import (
    hash_password,
    needs_rehash,
    run_dummy_verify,
    validate_password_strength,
    verify_password,
)

# Providers we can render buttons for, in stable UI order. Entries not
# configured at startup simply come back with ``enabled=false``.
_PROVIDER_NAMES = ("github", "google")

# Hard ceiling on agent tokens per user (defence against mass-creation
# after a compromised user session).
_AGENT_TOKEN_LIMIT = 20

# Browser-session (kind="user") tokens live for 90 days.
_USER_TOKEN_TTL_DAYS = 90

# Default agent-token lifetime when the client omits ``expires_in_days``.
# Mirrors GitHub PAT's default.
_DEFAULT_AGENT_TOKEN_TTL_DAYS = 30


def _expiration_from_days(days: int | None) -> str:
    if not days:
        return ""
    return (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()


def _client_ip(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for", "")
    if xff:
        return xff.split(",")[0].strip()
    real = request.headers.get("x-real-ip", "")
    if real:
        return real.strip()
    return request.client.host if request.client else ""


_UA_MAX_LEN = 512


def _require_provider(app: AppState, name: str) -> OAuthProvider:
    prov = app.oauth_providers.get(name)
    if not prov:
        raise HTTPException(404, f"OAuth provider {name!r} is not configured")
    return prov


def _callback_uri(app: AppState, provider: str) -> str:
    base = app.config.oauth_redirect_base.rstrip("/")
    return f"{base}/api/v1/auth/callback/{provider}"


def _safe_redirect(raw: str) -> str:
    if not raw:
        return "/"
    parsed = urlparse(raw)
    if parsed.scheme or parsed.netloc:
        return "/"
    path = parsed.path or "/"
    if not path.startswith("/"):
        return "/"
    return path


def _frontend_redirect(raw: str) -> str:
    return _safe_redirect(raw)


def _mint_user_token(
    app: AppState, user_id: str, request: Request
) -> tuple[str, TeamToken]:
    """Create a new user-kind token for ``user_id``. Returns plaintext."""
    plaintext = f"pt_{secrets.token_urlsafe(32)}"
    tok = TeamToken(
        token_id=secrets.token_urlsafe(12),
        user_id=user_id,
        token_hash=hash_token(plaintext),
        kind="user",
        label="login",
        created_at=now_iso(),
        expires_at=_expiration_from_days(_USER_TOKEN_TTL_DAYS),
        ip_address=_client_ip(request),
        user_agent=request.headers.get("user-agent", "")[:_UA_MAX_LEN],
    )
    app.state_backend.put_token(tok)
    return plaintext, tok


def _mint_agent_token(
    app: AppState,
    user_id: str,
    label: str,
    *,
    expires_in_days: int | None = _DEFAULT_AGENT_TOKEN_TTL_DAYS,
) -> tuple[str, TeamToken]:
    plaintext = f"pa_{secrets.token_urlsafe(32)}"
    tok = TeamToken(
        token_id=secrets.token_urlsafe(12),
        user_id=user_id,
        token_hash=hash_token(plaintext),
        kind="agent",
        label=label,
        created_at=now_iso(),
        expires_at=_expiration_from_days(expires_in_days),
    )
    app.state_backend.put_token(tok)
    return plaintext, tok


def _apply_super_admin_status(app: AppState, user: UserState) -> UserState:
    """Recompute the env-anchored super_admin role from the user's email
    and ``CTFY_SUPER_ADMIN_EMAILS``.

    Anti-spoof guard: only applies when the user has at least one
    bound OAuth identity. Password registration does not verify the
    email — without this check anyone could claim ``admin@corp.com``
    by typing it into ``/auth/register``.
    """
    has_oauth = bool(app.state_backend.list_identities_for_user(user.user_id))
    if not has_oauth:
        return user
    in_env = bool(user.email) and user.email.lower() in app.super_admin_emails_lower
    if in_env and user.role != "super_admin":
        return user.model_copy(update={"role": "super_admin"})
    if not in_env and user.role == "super_admin":
        return user.model_copy(update={"role": "user"})
    return user


def _create_user(
    app: AppState,
    *,
    email: str,
    display_name: str,
    avatar_url: str = "",
    register_event_ip: str = "",
    first_user_aware: bool = False,
) -> UserState:
    """Mint a fresh user. Registration no longer auto-creates a
    "personal team"; the user joins per-comp teams later via
    ``POST /competitions/{id}/teams`` (Solo / Create / Join).

    When ``first_user_aware=True`` the user is created via
    ``put_user_first_user_aware`` so the very first registrant
    atomically earns ``role="super_admin"`` (used by the password
    path, which is the only way to bootstrap a super-admin in a
    deployment without OAuth).

    ``register_event_ip`` is unused at the moment — we used to fire a
    ``team_registered`` activity row here because the user immediately
    had a team; that audit row now belongs on the per-comp
    registration flow instead.
    """
    user_id = str(uuid.uuid4())
    ts = now_iso()
    user = UserState(
        user_id=user_id,
        email=email,
        display_name=display_name,
        avatar_url=avatar_url,
        created_at=ts,
        role="user",
    )
    if first_user_aware:
        user = app.state_backend.put_user_first_user_aware(user_id, user)
    else:
        app.state_backend.put_user(user_id, user)
    log.info(
        "User registered",
        user_id=user_id,
        email=email,
        first_user=first_user_aware and user.role == "super_admin",
    )
    return user


def _grant_linked_provider_for_each_team(
    app: AppState, user: UserState, provider: str
) -> None:
    """Grant ``linked_<provider>`` against every team the user is
    currently on. The badge is the *user's* accomplishment so each of
    their per-comp teams collects it. Idempotent per team."""
    achievement_id = f"linked_{provider}"
    ach = get_catalog_entry(achievement_id)
    if ach is None:
        return
    actor_name = user.display_name or user.email or user.user_id
    for m in app.state_backend.list_memberships(user_id=user.user_id):
        team = app.state_backend.get_team(m.team_id)
        if team is None:
            continue
        record = app.state_backend.grant_achievement(
            team.team_id,
            achievement_id,
            context={"source": "oauth_link", "provider": provider},
        )
        if record is not None:
            emit_event(
                app,
                AchievementUnlockedPayload(
                    team_id=team.team_id,
                    team_name=team.name,
                    achievement_id=ach.id,
                    achievement_name=ach.name,
                    tier=ach.tier,
                    secret=ach.secret,
                ),
                actor_id=user.user_id,
                actor_name=actor_name,
                actor_type="team",
            )
        if provider == "github":
            maybe_grant_combo(
                app,
                team,
                required=("star_gazer", "linked_github"),
                grant_id="ambassador",
                actor_user_id=user.user_id,
                actor_user_name=actor_name,
            )


def _put_identity(
    app: AppState, user: UserState, profile: OAuthProfile
) -> OAuthIdentity:
    identity = OAuthIdentity(
        identity_id=secrets.token_urlsafe(12),
        user_id=user.user_id,
        provider=profile.provider,
        provider_user_id=profile.provider_user_id,
        provider_login=profile.provider_login,
        provider_email=profile.email,
        provider_display_name=profile.display_name,
        avatar_url=profile.avatar_url,
        created_at=now_iso(),
        last_used_at=now_iso(),
    )
    app.state_backend.put_identity(identity)
    _grant_linked_provider_for_each_team(app, user, profile.provider)
    return identity


def _refresh_user_from_profile(
    app: AppState, user: UserState, profile: OAuthProfile
) -> UserState:
    """Update a user's email/name/avatar from the latest OAuth login."""
    updates = {}
    if profile.email and profile.email != user.email:
        updates["email"] = profile.email
    if profile.display_name and profile.display_name != user.display_name:
        updates["display_name"] = profile.display_name
    if profile.avatar_url and profile.avatar_url != user.avatar_url:
        updates["avatar_url"] = profile.avatar_url
    if updates:
        user = user.model_copy(update=updates)
    user = _apply_super_admin_status(app, user)
    app.state_backend.put_user(user.user_id, user)
    return user


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/auth/providers", response_model=ProvidersResponse)
    def list_providers() -> ProvidersResponse:
        providers = [
            OAuthProviderInfo(
                name=name,
                enabled=name in app.oauth_providers,
                authorize_path=f"/api/v1/auth/login/{name}",
            )
            for name in _PROVIDER_NAMES
        ]
        return ProvidersResponse(
            providers=providers,
            password_auth=PasswordAuthInfo(enabled=app.config.password_auth_enabled),
        )

    @router.get("/auth/login/{provider}")
    def login(request: Request, provider: str, redirect_to: str = "/"):
        prov = _require_provider(app, provider)
        payload = {
            "provider": provider,
            "redirect_to": _safe_redirect(redirect_to),
            "flow": "login",
        }
        state = sign_state(app.oauth_secret, payload)
        redirect_uri = _callback_uri(app, provider)
        return RedirectResponse(prov.authorize_url(state, redirect_uri), status_code=302)

    @router.get("/auth/callback/{provider}")
    async def callback(request: Request, provider: str, code: str = "", state: str = ""):
        if not code or not state:
            raise HTTPException(400, "Missing code or state")
        prov = _require_provider(app, provider)
        payload = verify_state(app.oauth_secret, state)
        if payload.get("provider") != provider:
            raise HTTPException(400, "State/provider mismatch")
        redirect_uri = _callback_uri(app, provider)
        access_token = await prov.exchange_code(code, redirect_uri)
        profile = await prov.fetch_profile(access_token)
        if not profile.email_verified:
            raise HTTPException(400, "Provider did not verify your email")

        existing = app.state_backend.get_identity_by_provider_uid(
            provider, profile.provider_user_id
        )
        link_hash = payload.get("link_token_hash")

        if existing:
            # Returning user — identity already bound to a UserState.
            user = app.state_backend.get_user(existing.user_id)
            if not user:
                # Orphan identity. Bin it and fall through to fresh signup.
                app.state_backend.remove_identity(existing.identity_id)
                user = _create_user(
                    app,
                    email=profile.email,
                    display_name=profile.display_name,
                    avatar_url=profile.avatar_url,
                    register_event_ip=_client_ip(request),
                )
                _put_identity(app, user, profile)
                user = _refresh_user_from_profile(app, user, profile)
            else:
                user = _refresh_user_from_profile(app, user, profile)
                # Touch identity last_used_at + backfill provider_login.
                updates: dict[str, str] = {"last_used_at": now_iso()}
                if not existing.provider_login and profile.provider_login:
                    updates["provider_login"] = profile.provider_login
                refreshed = existing.model_copy(update=updates)
                app.state_backend.put_identity(refreshed)
                _grant_linked_provider_for_each_team(app, user, profile.provider)
        elif link_hash:
            # Link flow: attach the new identity to the caller's existing user.
            tok = app.state_backend.get_token_by_hash(link_hash)
            if (
                not tok
                or tok.revoked_at
                or tok.kind != "user"
                or is_token_expired(tok.expires_at)
            ):
                raise HTTPException(
                    400,
                    "Link session expired — sign in again and retry the link.",
                )
            user = app.state_backend.get_user(tok.user_id)
            if not user:
                raise HTTPException(400, "Link target user missing")
            _put_identity(app, user, profile)
            user = _refresh_user_from_profile(app, user, profile)
        else:
            # Fresh sign-in. Auto-merge by verified email if a user with
            # that email already exists; otherwise provision a new user.
            merge_target = (
                app.state_backend.get_user_by_email(profile.email)
                if profile.email
                else None
            )
            if merge_target:
                user = merge_target
                _put_identity(app, user, profile)
                user = _refresh_user_from_profile(app, user, profile)
            else:
                user = _create_user(
                    app,
                    email=profile.email,
                    display_name=profile.display_name,
                    avatar_url=profile.avatar_url,
                    register_event_ip=_client_ip(request),
                )
                _put_identity(app, user, profile)
                user = _refresh_user_from_profile(app, user, profile)

        plaintext, _tok = _mint_user_token(app, user.user_id, request)
        landing = _frontend_redirect(payload.get("redirect_to", "/"))
        frag = urlencode({"token": plaintext, "redirect_to": landing})
        return RedirectResponse(f"/auth/callback#{frag}", status_code=302)

    # -- identity management (authenticated) -------------------------------

    @router.get(
        "/auth/identities",
        response_model=BigLimitOffsetPage[LinkedIdentity],
    )
    def list_identities(ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind)):
        user, _ = ctx
        out = [
            LinkedIdentity(
                identity_id=ident.identity_id,
                provider=ident.provider,
                provider_email=ident.provider_email,
                provider_display_name=ident.provider_display_name,
                avatar_url=ident.avatar_url,
                created_at=ident.created_at,
            )
            for ident in app.state_backend.list_identities_for_user(user.user_id)
        ]
        for pwd in app.state_backend.list_password_identities_for_user(user.user_id):
            out.append(
                LinkedIdentity(
                    identity_id=pwd.identity_id,
                    provider="password",
                    provider_email=pwd.email,
                    provider_display_name=pwd.display_name,
                    avatar_url="",
                    created_at=pwd.created_at,
                )
            )
        return list_paginate(out)

    @router.post("/auth/identities/link/{provider}", response_model=LinkStartResponse)
    def link_start(
        request: Request,
        provider: str,
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        _user, tok = ctx
        prov = _require_provider(app, provider)
        payload = {
            "provider": provider,
            "flow": "link",
            "link_token_hash": tok.token_hash,
            "redirect_to": "/settings",
        }
        state = sign_state(app.oauth_secret, payload)
        redirect_uri = _callback_uri(app, provider)
        return LinkStartResponse(authorize_url=prov.authorize_url(state, redirect_uri))

    @router.delete("/auth/identities/{identity_id}")
    @app.limiter.limit(app.config.rate_limit_auth_mutation)
    def unlink_identity(
        request: Request,
        identity_id: str,
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        user, _ = ctx
        ident = app.state_backend.get_identity(identity_id)
        if not ident or ident.user_id != user.user_id:
            raise HTTPException(404, "Identity not found")
        remaining_oauth = [
            i
            for i in app.state_backend.list_identities_for_user(user.user_id)
            if i.identity_id != identity_id
        ]
        has_password = bool(
            app.state_backend.list_password_identities_for_user(user.user_id)
        )
        if not remaining_oauth and not has_password:
            raise HTTPException(
                409,
                "Cannot unlink your last identity — link another provider or set a password first.",
            )
        app.state_backend.remove_identity(identity_id)
        return {"status": "ok"}

    # -- password auth (local email+password) ------------------------------

    def _require_password_auth() -> None:
        if not app.config.password_auth_enabled:
            raise HTTPException(404, "Password authentication is disabled on this server")

    @router.post("/auth/register", response_model=AuthTokenResponse)
    @app.limiter.limit(app.config.rate_limit_register)
    def register(request: Request, body: RegisterRequest) -> AuthTokenResponse:
        """Create a user + personal team + password identity + user-kind token.

        First-user bootstrap: when the backend has zero users, the new
        user is granted ``role="super_admin"`` regardless of
        ``CTFY_SUPER_ADMIN_EMAILS``. This is the only way to bootstrap a
        super-admin in a password-only deployment. Subsequent
        registrations never auto-grant any privilege because the email
        is not verified (see ``_apply_super_admin_status``).
        """
        _require_password_auth()
        validate_password_strength(body.password)
        email = body.email.lower()
        if app.state_backend.get_password_identity_by_email(email):
            raise HTTPException(409, "Email already registered")
        if app.state_backend.get_user_by_email(email):
            # An OAuth user already owns this email. Direct them to sign
            # in via OAuth and attach a password from Settings; auto-
            # merging unverified password signups into verified OAuth
            # users would enable account takeover.
            raise HTTPException(
                409,
                "This email already belongs to an account — sign in with your "
                "identity provider and add a password from Settings.",
            )
        user = _create_user(
            app,
            email=email,
            display_name=body.display_name or email,
            register_event_ip=_client_ip(request),
            first_user_aware=True,
        )
        identity = PasswordIdentity(
            identity_id=secrets.token_urlsafe(12),
            user_id=user.user_id,
            email=email,
            password_hash=hash_password(body.password),
            display_name=body.display_name,
            created_at=now_iso(),
            last_used_at=now_iso(),
        )
        app.state_backend.put_password_identity(identity)
        plaintext, _ = _mint_user_token(app, user.user_id, request)
        return AuthTokenResponse(token=plaintext, redirect_to="/")

    @router.post("/auth/login", response_model=AuthTokenResponse)
    @app.limiter.limit(app.config.rate_limit_login)
    def password_login(request: Request, body: LoginRequest) -> AuthTokenResponse:
        _require_password_auth()
        email = body.email.lower()
        ident = app.state_backend.get_password_identity_by_email(email)
        if not ident:
            run_dummy_verify(body.password)
            raise HTTPException(401, "Invalid email or password")
        if not verify_password(ident.password_hash, body.password):
            raise HTTPException(401, "Invalid email or password")
        updates: dict[str, str] = {"last_used_at": now_iso()}
        if needs_rehash(ident.password_hash):
            updates["password_hash"] = hash_password(body.password)
        app.state_backend.put_password_identity(ident.model_copy(update=updates))
        plaintext, _ = _mint_user_token(app, ident.user_id, request)
        return AuthTokenResponse(token=plaintext, redirect_to="/")

    @router.post("/auth/password")
    @app.limiter.limit(app.config.rate_limit_password_change)
    def set_password(
        request: Request,
        body: SetPasswordRequest,
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        """Set (first time) or change the caller's password."""
        _require_password_auth()
        validate_password_strength(body.new_password)
        user, _ = ctx
        existing = next(
            iter(app.state_backend.list_password_identities_for_user(user.user_id)),
            None,
        )
        if existing:
            if not body.current_password or not verify_password(
                existing.password_hash, body.current_password
            ):
                raise HTTPException(401, "Current password is incorrect")
            app.state_backend.put_password_identity(
                existing.model_copy(
                    update={
                        "password_hash": hash_password(body.new_password),
                        "last_used_at": now_iso(),
                    }
                )
            )
            return {"status": "ok"}
        if not user.email:
            raise HTTPException(
                400,
                "This account has no email on file — sign in via OAuth once to "
                "populate it, then retry.",
            )
        target_email = user.email.lower()
        if app.state_backend.get_password_identity_by_email(target_email):
            raise HTTPException(409, "A password already exists for this email")
        ident = PasswordIdentity(
            identity_id=secrets.token_urlsafe(12),
            user_id=user.user_id,
            email=target_email,
            password_hash=hash_password(body.new_password),
            display_name=user.display_name,
            created_at=now_iso(),
            last_used_at=now_iso(),
        )
        app.state_backend.put_password_identity(ident)
        return {"status": "ok"}

    @router.delete("/auth/password")
    @app.limiter.limit(app.config.rate_limit_auth_mutation)
    def remove_password(
        request: Request,
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        _require_password_auth()
        user, _ = ctx
        existing = next(
            iter(app.state_backend.list_password_identities_for_user(user.user_id)),
            None,
        )
        if not existing:
            raise HTTPException(404, "No password set on this account")
        oauth_count = len(app.state_backend.list_identities_for_user(user.user_id))
        if oauth_count == 0:
            raise HTTPException(
                409,
                "Cannot remove the last sign-in method — link an OAuth provider first.",
            )
        app.state_backend.remove_password_identity(existing.identity_id)
        return {"status": "ok"}

    # -- token management (authenticated) ----------------------------------

    def _token_info(tok: TeamToken, *, current_token_id: str = "") -> TokenInfo:
        return TokenInfo(
            token_id=tok.token_id,
            kind=tok.kind,
            label=tok.label,
            created_at=tok.created_at,
            last_used_at=tok.last_used_at,
            expires_at=tok.expires_at,
            ip_address=tok.ip_address,
            user_agent=tok.user_agent,
            is_current=bool(current_token_id) and tok.token_id == current_token_id,
        )

    @router.get(
        "/auth/tokens",
        response_model=BigLimitOffsetPage[TokenInfo],
    )
    def list_tokens(ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind)):
        user, caller_tok = ctx
        return list_paginate(
            [
                _token_info(t, current_token_id=caller_tok.token_id)
                for t in app.state_backend.list_tokens_for_user(user.user_id)
            ]
        )

    @router.post("/auth/tokens", response_model=CreateAgentTokenResponse)
    @app.limiter.limit(app.config.rate_limit_token_create)
    def create_token(
        request: Request,
        body: CreateAgentTokenRequest,
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        user, _ = ctx
        existing_agent = [
            t for t in app.state_backend.list_tokens_for_user(user.user_id, kind="agent")
        ]
        if len(existing_agent) >= _AGENT_TOKEN_LIMIT:
            raise HTTPException(
                400,
                f"Agent token limit reached ({_AGENT_TOKEN_LIMIT}); "
                "revoke an existing token first.",
            )
        ttl_days = (
            _DEFAULT_AGENT_TOKEN_TTL_DAYS
            if body.expires_in_days is None
            else body.expires_in_days
        )
        plaintext, tok = _mint_agent_token(
            app, user.user_id, body.label, expires_in_days=ttl_days
        )
        info = _token_info(tok)
        return CreateAgentTokenResponse(**info.model_dump(), token=plaintext)

    @router.delete("/auth/tokens/others")
    @app.limiter.limit(app.config.rate_limit_auth_mutation)
    def revoke_other_sessions(
        request: Request,
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        user, caller_tok = ctx
        ts = now_iso()
        count = 0
        for tok in app.state_backend.list_tokens_for_user(user.user_id):
            if tok.token_id == caller_tok.token_id:
                continue
            if app.state_backend.revoke_token(tok.token_id, ts):
                count += 1
        return {"status": "ok", "revoked": count}

    @router.delete("/auth/tokens/{token_id}")
    @app.limiter.limit(app.config.rate_limit_auth_mutation)
    def revoke_token(
        request: Request,
        token_id: str,
        ctx: tuple[UserState, TeamToken] = Depends(app.require_user_kind),
    ):
        user, caller_tok = ctx
        target = app.state_backend.get_token(token_id)
        if not target or target.user_id != user.user_id:
            raise HTTPException(404, "Token not found")
        if target.token_id == caller_tok.token_id:
            raise HTTPException(409, "Cannot revoke the token you are currently using")
        app.state_backend.revoke_token(token_id, now_iso())
        return {"status": "ok"}

    return router
