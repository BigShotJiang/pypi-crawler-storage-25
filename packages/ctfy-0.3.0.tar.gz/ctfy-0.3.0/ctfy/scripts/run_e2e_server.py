"""Boot a throwaway ctfy server for the Playwright e2e suite.

Mirrors :mod:`ctfy.scripts.capture_screenshots` but: (a) doesn't seed
demo state — the e2e tests register their own users via the public
``/auth/register`` endpoint so each spec is hermetic; (b) blocks
forever (until SIGTERM) so playwright's ``webServer`` config can
manage the lifecycle.

Usage (from ``frontend/playwright.config.ts``):

    uv run python -m ctfy.scripts.run_e2e_server --port 50101

Reads no env vars apart from what the server itself needs. Cleans
up the tmpdir on exit.
"""

from __future__ import annotations

import argparse
import os
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path


def _wait_for_health(url: str, timeout: float = 30.0) -> None:
    deadline = time.time() + timeout
    last_err: Exception | None = None
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.5) as r:
                if r.status == 200:
                    return
        except Exception as e:
            last_err = e
        time.sleep(0.3)
    raise RuntimeError(f"server never came up at {url}: {last_err}")


def _pick_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--port",
        type=int,
        default=0,
        help="Port to bind. 0 = pick a free one and print it to stdout.",
    )
    args = parser.parse_args()
    port = args.port or _pick_port()

    work = Path(tempfile.mkdtemp(prefix="ctfy-e2e-"))
    challenges_dir = work / "challenges"
    challenges_dir.mkdir()
    archive_dir = work / "archive"
    archive_dir.mkdir()
    db_path = work / "platform.sqlite3"

    # One demo challenge so the /challenges page isn't empty when an
    # e2e spec needs to assert "I see a challenge in the list".
    demo = challenges_dir / "DEMO-001"
    demo.mkdir()
    (demo / "metadata.yaml").write_text(
        "name: Demo Web Challenge\n"
        "description: A throwaway challenge for e2e tests.\n"
        "difficulty: easy\n"
        "tags:\n  - web\n"
    )

    repo_root = Path(__file__).resolve().parents[2]
    ctfy_bin = shutil.which("ctfy") or str(Path(sys.executable).parent / "ctfy")
    env = {
        **os.environ,
        "CTFY_DB_PATH": str(db_path),
        "CTFY_CHALLENGES_DIR": str(challenges_dir),
        "CTFY_INSTANCE_ARCHIVE_DIR": str(archive_dir),
        "CTFY_SERVER_HOST": "127.0.0.1",
        "CTFY_SERVER_PORT": str(port),
        # Tests can hammer auth endpoints; rate limits would just
        # add flake.
        "CTFY_RATE_LIMITING_ENABLED": "false",
        # Stable secret so any signed cookies / state survive a restart
        # within a single test run.
        "CTFY_SECRET_KEY": "e2e-test-secret-key-not-for-prod",
        "CTFY_HOST_PROJECT_ROOT": str(work),
    }

    log_path = work / "server.log"
    print(f"[e2e-server] workdir: {work}", flush=True)
    print(f"[e2e-server] port: {port}", flush=True)
    print(f"BASE_URL=http://127.0.0.1:{port}", flush=True)

    proc = subprocess.Popen(
        [ctfy_bin, "server", "start", "--port", str(port)],
        env=env,
        stdout=log_path.open("wb"),
        stderr=subprocess.STDOUT,
        cwd=str(repo_root),
        preexec_fn=os.setsid,
    )

    def _shutdown(signum: int, _frame) -> None:
        try:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
        finally:
            shutil.rmtree(work, ignore_errors=True)
        sys.exit(0)

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    try:
        _wait_for_health(f"http://127.0.0.1:{port}/api/v1/health")
    except Exception:
        sys.stderr.write(log_path.read_text(errors="replace"))
        proc.terminate()
        return 1

    print("[e2e-server] ready, waiting for SIGTERM…", flush=True)
    proc.wait()
    return proc.returncode or 0


if __name__ == "__main__":
    raise SystemExit(main())
