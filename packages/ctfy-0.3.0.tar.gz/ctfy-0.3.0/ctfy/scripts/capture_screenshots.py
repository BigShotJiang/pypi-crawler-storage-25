"""Capture the README screenshots.

Boots ctfy in a throwaway tmpdir with a small set of demo challenges and
pre-seeded state (teams, submissions, solves, activities, achievements),
then uses Playwright to render each main page and write PNGs to
``docs/screenshots/``.

Usage:

    uv sync --extra screenshots
    uv run playwright install chromium
    uv run python -m ctfy.scripts.capture_screenshots

The generated PNGs are committed — they are project assets, not build
artifacts. Re-run whenever the UI changes enough to need fresh shots.
"""

from __future__ import annotations

import hashlib
import os
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from ctfy.core.enums import PlatformEvent
from ctfy.core.state.models import (
    ActivityState,
    CompetitionState,
    OAuthIdentity,
    SolveState,
    SubmissionState,
    TeamInviteState,
    TeamMembershipState,
    TeamState,
    TeamToken,
    UserState,
)
from ctfy.core.state.sqlite import SQLiteBackend

REPO_ROOT = Path(__file__).resolve().parents[2]
OUT_DIR = REPO_ROOT / "docs" / "screenshots"

# (path, filename, locale)
# locale="en" → no localStorage override (i18next defaults to en
# unless the browser already advertises something else; the
# screenshot context always starts clean).
# locale="zh-CN" → inject the i18nextLng key the LanguageCard would
# otherwise persist, so the page renders in Chinese without an
# extra round-trip through the in-app selector.
# (path, filename, locale, full_page). Path tokens of the form
# ``{demo_team_id}`` are substituted at render time with the seeded
# demo team's id. ``full_page=True`` captures the entire scrollable
# region rather than just the 1440x900 viewport — used for pages
# whose new content sits below the fold (TeamManagementCard on
# ``/team``, captain About card on ``/teams/{id}``).
PAGES: list[tuple[str, str, str, bool]] = [
    ("/", "dashboard.png", "en", False),
    ("/challenges", "challenges.png", "en", False),
    ("/scoreboard", "scoreboard.png", "en", False),
    ("/activity", "activity.png", "en", False),
    ("/achievements", "achievements.png", "en", False),
    # Newer surfaces — capture so docs cover the full member journey:
    # the public profile editor, the danger zone, the running-instances
    # list, and the per-challenge detail page.
    ("/settings", "settings.png", "en", False),
    ("/instances", "instances.png", "en", False),
    ("/challenges/WEB-001", "challenge_detail.png", "en", False),
    # Post user/team-split: ``/team`` now hosts both the public team
    # profile (members + achievements + rank history) and the new
    # captain-driven TeamManagementCard (rename, invite codes,
    # leave). Full-page so the management card below the fold lands
    # in the shot.
    ("/team", "team.png", "en", True),
    # The Competitions feature — lists upcoming / running / past with
    # the always-on "Practice mode" card up top.
    ("/competitions", "competitions.png", "en", False),
    # Public team profile as visitors see it (captain's About card
    # sourced from GET /users/{captain_user_id}). Full-page so the
    # captain's bio + members list both fit.
    ("/teams/{demo_team_id}", "team_profile.png", "en", True),
    # Showcase the i18n switch end-to-end. zh-CN is hand-translated
    # for these pages in #312 / #314 / #315; keeping a screenshot in
    # the docs catches accidental regressions when adding new
    # English copy without a Chinese equivalent.
    ("/", "dashboard_zh.png", "zh-CN", False),
    ("/settings", "settings_zh.png", "zh-CN", False),
    ("/login", "login_zh.png", "zh-CN", False),
    ("/team", "team_zh.png", "zh-CN", True),
]


def _now() -> tuple[str, float]:
    ts = time.time()
    iso = datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(timespec="seconds")
    return iso, ts


def _pick_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _write_demo_challenges(challenges_dir: Path) -> list[dict]:
    """Lay down a handful of slim v3 challenge metadata.yaml files."""
    demo = [
        {
            "id": "WEB-001",
            "name": "SSTI in Profile Page",
            "description": "A Flask app renders user bios via Jinja2 without escaping.",
            "difficulty": "easy",
            "tags": ["web", "ssti"],
        },
        {
            "id": "PWN-004",
            "name": "Stack Smash",
            "description": "A vulnerable C binary with no stack canary. Pop a shell.",
            "difficulty": "medium",
            "tags": ["pwn", "binary"],
        },
        {
            "id": "CRYPTO-002",
            "name": "RSA with Small e",
            "description": "e=3 with a tiny message. Recover the plaintext.",
            "difficulty": "easy",
            "tags": ["crypto", "rsa"],
        },
        {
            "id": "WEB-007",
            "name": "JWT None Algorithm",
            "description": "An API trusts the alg header. Forge an admin token.",
            "difficulty": "medium",
            "tags": ["web", "jwt", "auth"],
        },
        {
            "id": "REV-003",
            "name": "Obfuscated Key Check",
            "description": "Reverse the license-key validator in the stripped binary.",
            "difficulty": "hard",
            "tags": ["rev"],
        },
    ]
    challenges_dir.mkdir(parents=True, exist_ok=True)
    for spec in demo:
        d = challenges_dir / spec["id"]
        d.mkdir(exist_ok=True)
        tags_yaml = "\n".join(f"  - {t}" for t in spec["tags"])
        (d / "metadata.yaml").write_text(
            f"name: {spec['name']}\n"
            f"description: {spec['description']}\n"
            f"difficulty: {spec['difficulty']}\n"
            f"tags:\n{tags_yaml}\n"
        )
    return demo


def _hash_token(tok: str) -> str:
    return hashlib.sha256(tok.encode()).hexdigest()


def _seed_state(db_path: Path, demo_specs: list[dict]) -> tuple[str, str]:
    """Write demo users/teams/memberships/submissions/solves/activities
    directly to SQLite.

    Returns ``(plaintext_token, demo_team_id)``. The plaintext token is
    the demo user's bearer (Playwright preloads it into localStorage);
    the team_id powers any ``{demo_team_id}`` substitution in PAGES.
    """
    backend = SQLiteBackend(str(db_path))
    iso, ts = _now()

    teams = [
        ("demo", "t_demo", "demo@example.com", "Captain Demo"),
        ("nemo-agents", "t_nemo", "nemo@example.com", "Nemo"),
        ("recon-bot", "t_recon", "recon@example.com", "Recon"),
        ("lucky13", "t_lucky", "lucky13@example.com", "Lucky"),
    ]
    team_ids: dict[str, str] = {}
    user_ids: dict[str, str] = {}
    team_tokens: dict[str, str] = {}
    for team_name, key, email, display_name in teams:
        # Post user/team-split: each demo entry is a User + a personal
        # Team + a Membership row. The user owns auth + profile + role;
        # the team owns the curated name visitors see.
        uid = str(uuid.uuid4())
        tid = str(uuid.uuid4())
        token = f"pt_{secrets.token_urlsafe(32)}"
        team_ids[key] = tid
        user_ids[key] = uid
        team_tokens[key] = token
        backend.put_user(
            uid,
            UserState(
                user_id=uid,
                email=email,
                display_name=display_name,
                avatar_url=f"https://www.gravatar.com/avatar/{_hash_token(email)}?s=128&d=retro",
                created_at=iso,
                # Admin console screenshots need at least one super-admin
                # so the promote/demote controls render in the captures.
                role="super_admin" if key == "t_demo" else "user",
                bio=(
                    "Long-time CTF organiser, occasional player. Currently "
                    "obsessed with web exploitation and side-channel pwn."
                    if key == "t_demo"
                    else None
                ),
                country="JP" if key == "t_demo" else None,
                website_url=(
                    "https://demo.example.com" if key == "t_demo" else None
                ),
                timezone="Asia/Tokyo" if key == "t_demo" else None,
                social_links=(
                    {"github": "demo-captain", "twitter": "demo_capt"}
                    if key == "t_demo"
                    else {}
                ),
            ),
        )
        backend.put_team(
            tid,
            TeamState(
                team_id=tid,
                name=team_name,
                description=(
                    "Long-running CTF team — agents and humans collaborate."
                    if key == "t_demo"
                    else ""
                ),
                created_at=iso,
                captain_user_id=uid,
            ),
        )
        backend.put_membership(
            TeamMembershipState(
                user_id=uid,
                team_id=tid,
                joined_at=iso,
            )
        )
        backend.put_token(
            TeamToken(
                token_id=secrets.token_urlsafe(12),
                user_id=uid,
                token_hash=_hash_token(token),
                kind="user",
                label="login",
                created_at=iso,
            )
        )
        backend.put_identity(
            OAuthIdentity(
                identity_id=secrets.token_urlsafe(12),
                user_id=uid,
                provider="github",
                provider_user_id=f"uid-{key}",
                provider_email=email,
                provider_display_name=display_name,
                created_at=iso,
            )
        )

    # Pre-seed an active invite + a brand-new joined member on the demo
    # team so the /team capture shows a non-empty members list AND a
    # non-empty invites list.
    extra_uid = str(uuid.uuid4())
    backend.put_user(
        extra_uid,
        UserState(
            user_id=extra_uid,
            email="newbie@example.com",
            display_name="Newbie",
            avatar_url="https://www.gravatar.com/avatar/x?s=128&d=retro",
            created_at=iso,
            role="user",
        ),
    )
    backend.put_membership(
        TeamMembershipState(
            user_id=extra_uid,
            team_id=team_ids["t_demo"],
            joined_at=iso,
        )
    )
    backend.put_team_invite(
        TeamInviteState(
            invite_id=secrets.token_urlsafe(12),
            team_id=team_ids["t_demo"],
            code="JOIN2026",
            created_by_user_id=user_ids["t_demo"],
            created_at=iso,
            expires_at="",  # never expires for the demo
            max_uses=10,
            use_count=2,
        )
    )

    # Submissions: mix of correct + wrong across teams. Drives scoreboard
    # ranks and activity feed.
    submissions: list[tuple[str, str, bool, float]] = [
        ("t_demo", "WEB-001", True, 412.0),
        ("t_demo", "PWN-004", True, 1823.0),
        ("t_demo", "CRYPTO-002", True, 205.0),
        ("t_demo", "WEB-007", False, 0.0),
        ("t_nemo", "WEB-001", True, 631.0),
        ("t_nemo", "CRYPTO-002", True, 300.0),
        ("t_nemo", "PWN-004", False, 0.0),
        ("t_recon", "WEB-001", True, 901.0),
        ("t_recon", "REV-003", False, 0.0),
        ("t_lucky", "CRYPTO-002", True, 488.0),
        ("t_lucky", "CRYPTO-002", False, 0.0),  # earlier wrong attempt
    ]
    for i, (tkey, cid, correct, solve_s) in enumerate(submissions):
        sub_iso = datetime.fromtimestamp(
            ts - 60 * (len(submissions) - i), tz=timezone.utc
        ).isoformat(timespec="seconds")
        backend.add_submission(
            SubmissionState(
                submission_id=str(uuid.uuid4()),
                team_id=team_ids[tkey],
                challenge_id=cid,
                claimed_flag="ctfy{correct}" if correct else "ctfy{wrong}",
                correct=correct,
                flag_id="main" if correct else "",
                submitted_at=sub_iso,
                solve_time_s=solve_s,
            ),
        )
        if correct:
            backend.add_solve(
                team_ids[tkey],
                cid,
                "main",
                SolveState(
                    team_id=team_ids[tkey],
                    challenge_id=cid,
                    flag_id="main",
                    solved_at=sub_iso,
                    solve_time_s=solve_s,
                    attempts=1,
                ),
            )
        backend.add_activity(
            ActivityState(
                id=str(uuid.uuid4()),
                timestamp=sub_iso,
                event=PlatformEvent.FLAG_CORRECT.value
                if correct
                else PlatformEvent.FLAG_WRONG.value,
                team_id=team_ids[tkey],
                team_name=dict((k, n) for n, k, _e, _d in teams)[tkey],
                challenge_id=cid,
                actor_id=team_ids[tkey],
                actor_name=dict((k, n) for n, k, _e, _d in teams)[tkey],
                actor_type="team",
            ),
        )

    for name, key, _email, _display in teams:
        reg_iso = datetime.fromtimestamp(ts - 3600, tz=timezone.utc).isoformat(
            timespec="seconds"
        )
        backend.add_activity(
            ActivityState(
                id=str(uuid.uuid4()),
                timestamp=reg_iso,
                event=PlatformEvent.TEAM_REGISTERED.value,
                team_id=team_ids[key],
                team_name=name,
                actor_id=user_ids[key],
                actor_name=name,
                actor_type="team",
            ),
        )

    # Unlock a handful of achievements for the demo team so the badge page
    # renders non-empty. Pick IDs that match the catalog
    # (ctfy/server/achievements/catalog.py).
    for ach_id in (
        "welcome_aboard",
        "first_blood_team",
        "early_bird",
        "rapid_fire",
    ):
        backend.grant_achievement(team_ids["t_demo"], ach_id, context={})

    # Seed a few competitions so the /competitions screenshot has
    # content across the three phase tabs (running / upcoming / past).
    competitions = [
        {
            "competition_id": str(uuid.uuid4()),
            "title": "Spring CTF 2026",
            "description": (
                "Annual qualifier — five web/pwn/crypto challenges, "
                "open to everyone, 48-hour window."
            ),
            "starts_at": datetime.fromtimestamp(
                ts - 6 * 3600, tz=timezone.utc
            ).isoformat(timespec="seconds"),
            "ends_at": datetime.fromtimestamp(
                ts + 42 * 3600, tz=timezone.utc
            ).isoformat(timespec="seconds"),
            "challenge_ids": ["WEB-001", "PWN-004", "CRYPTO-002"],
        },
        {
            "competition_id": str(uuid.uuid4()),
            "title": "Summer Crypto Sprint",
            "description": "Crypto-only mini-event, weekend slot.",
            "starts_at": datetime.fromtimestamp(
                ts + 7 * 24 * 3600, tz=timezone.utc
            ).isoformat(timespec="seconds"),
            "ends_at": datetime.fromtimestamp(
                ts + 9 * 24 * 3600, tz=timezone.utc
            ).isoformat(timespec="seconds"),
            "challenge_ids": ["CRYPTO-002"],
        },
        {
            "competition_id": str(uuid.uuid4()),
            "title": "Winter Qualifier 2025",
            "description": "Last year's qualifier — archived.",
            "starts_at": datetime.fromtimestamp(
                ts - 60 * 24 * 3600, tz=timezone.utc
            ).isoformat(timespec="seconds"),
            "ends_at": datetime.fromtimestamp(
                ts - 58 * 24 * 3600, tz=timezone.utc
            ).isoformat(timespec="seconds"),
            "challenge_ids": ["WEB-001", "REV-003"],
        },
    ]
    for c in competitions:
        backend.put_competition(
            CompetitionState(
                competition_id=c["competition_id"],
                title=c["title"],
                description=c["description"],
                starts_at=c["starts_at"],
                ends_at=c["ends_at"],
                challenge_ids=c["challenge_ids"],
                created_at=iso,
                updated_at=iso,
                created_by=user_ids["t_demo"],
                created_by_name="Captain Demo",
            )
        )
    # Demo + nemo register Solo for the running competition (Phase
    # 5e-3: per-comp team is the registration). The screenshot shows
    # a "registered" badge + non-zero count from these.
    for key in ("t_demo", "t_nemo"):
        backend.create_team_for_competition(
            user_id=user_ids[key],
            competition_id=competitions[0]["competition_id"],
            team_name=f"{key} for spring",
            now_iso=iso,
        )

    return team_tokens["t_demo"], team_ids["t_demo"]


def _wait_for_health(url: str, timeout: float = 30.0) -> None:
    import urllib.request

    deadline = time.time() + timeout
    last_err: Exception | None = None
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.5) as r:
                if r.status == 200:
                    return
        except Exception as e:
            last_err = e
        time.sleep(0.3)
    raise RuntimeError(f"server never came up at {url}: {last_err}")


def _start_server(env: dict[str, str], port: int, log_path: Path) -> subprocess.Popen:
    ctfy_bin = shutil.which("ctfy") or str(Path(sys.executable).parent / "ctfy")
    return subprocess.Popen(
        [ctfy_bin, "server", "start", "--port", str(port)],
        env=env,
        stdout=log_path.open("wb"),
        stderr=subprocess.STDOUT,
        cwd=str(REPO_ROOT),
        preexec_fn=os.setsid,
    )


def _capture(base_url: str, team_token: str, demo_team_id: str) -> None:
    from playwright.sync_api import sync_playwright

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    # Login page is captured signed-out so the form is visible
    # — every other page wants the demo team's bearer pre-loaded so
    # the React tree resolves a real user instead of bouncing to
    # /login.
    SIGNED_OUT_PATHS = {"/login"}

    with sync_playwright() as p:
        browser = p.chromium.launch()
        try:
            for path_template, filename, locale, full_page in PAGES:
                # Substitute placeholder tokens (currently just
                # ``{demo_team_id}``) before navigating.
                path = path_template.format(demo_team_id=demo_team_id)
                ctx_init = []
                if path not in SIGNED_OUT_PATHS:
                    ctx_init.append(
                        f"window.localStorage.setItem('teamKey', {team_token!r});"
                    )
                if locale and locale != "en":
                    ctx_init.append(
                        f"window.localStorage.setItem('i18nextLng', {locale!r});"
                    )
                # Pages that need to capture content below the fold
                # (TeamManagementCard on /team, captain About on
                # /teams/{id}) get a tall viewport so the AppShell's
                # ``h-dvh`` outer container expands enough for the
                # internal scroll region to render natively. Plain
                # ``full_page=True`` won't work — the app's outer
                # ``overflow-hidden`` clamps body height to dvh, so
                # Playwright sees only the viewport.
                vh = 1800 if full_page else 900
                ctx = browser.new_context(
                    viewport={"width": 1440, "height": vh}
                )
                if ctx_init:
                    ctx.add_init_script("\n".join(ctx_init))
                page = ctx.new_page()
                # The app keeps an SSE stream open, so `networkidle`
                # never settles. `domcontentloaded` + a short render
                # delay is enough for the React tree to paint.
                page.goto(f"{base_url}{path}", wait_until="domcontentloaded")
                page.wait_for_load_state("load")
                page.wait_for_timeout(1500)
                out = OUT_DIR / filename
                page.screenshot(path=str(out), full_page=False)
                size_kb = out.stat().st_size // 1024
                print(f"  {filename}: {size_kb} KB")
                ctx.close()
        finally:
            browser.close()


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="ctfy-shots-"))
    challenges_dir = work / "challenges"
    db_path = work / "platform.sqlite3"
    archive_dir = work / "archive"
    archive_dir.mkdir()

    print(f"workdir: {work}")
    try:
        demo_specs = _write_demo_challenges(challenges_dir)
        team_token, demo_team_id = _seed_state(db_path, demo_specs)

        port = _pick_port()
        env = {
            **os.environ,
            "CTFY_DB_PATH": str(db_path),
            "CTFY_CHALLENGES_DIR": str(challenges_dir),
            "CTFY_INSTANCE_ARCHIVE_DIR": str(archive_dir),
            # Admin privilege is email-driven; mark the demo team's email as
            # admin so the admin console is reachable in screenshots.
            "CTFY_SUPER_ADMIN_EMAILS": "demo@example.com",
            "CTFY_SERVER_HOST": "127.0.0.1",
            "CTFY_SERVER_PORT": str(port),
            # Disable auto-generated .env writes.
            "CTFY_HOST_PROJECT_ROOT": str(work),
        }
        base = f"http://127.0.0.1:{port}"
        log_path = work / "server.log"
        proc = _start_server(env, port, log_path)
        try:
            try:
                _wait_for_health(f"{base}/api/v1/health")
            except Exception:
                print("---- server.log ----", file=sys.stderr)
                try:
                    print(log_path.read_text(), file=sys.stderr)
                except OSError:
                    pass
                raise
            print(f"server up at {base}; capturing...")
            _capture(base, team_token, demo_team_id)
        finally:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
    finally:
        shutil.rmtree(work, ignore_errors=True)

    print(f"done — {len(PAGES)} screenshots in {OUT_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
