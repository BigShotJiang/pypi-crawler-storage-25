"""
Dev agent definition — system prompt and tool registration.
"""

from shypmate.config.project import PROJECT
from shypmate.engine.tool_registry import ToolRegistry
from shypmate.tools.file_tools import (
    list_directory,
    patch_file,
    read_file,
    search_files,
    write_file,
)
from shypmate.tools.git_tools import (
    checkout_branch,
    create_branch,
    git_changed_files,
    git_commit,
    git_diff,
    git_fetch,
    git_log,
    git_push,
    git_rebase,
    git_rebase_abort,
    git_rebase_continue,
    git_status,
)
from shypmate.tools.github_tools import (
    comment_on_pr,
    create_pull_request,
    get_pr_changed_files,
    list_ai_pull_requests,
    update_pull_request,
)
from shypmate.tools.shell_tools import (
    run_ruff_check,
    run_ruff_format,
    run_shell_command,
)
from shypmate.tools.human_tools import (
    request_human_input,
)


def _build_safety_rules() -> str:
    rules = "\n".join(f"  - {r}" for r in PROJECT.shared_service_rules)
    return f"SHARED SERVICE RULES (MUST follow):\n{rules}"


def build_system_prompt(project_context: str = "") -> str:
    """Build the system prompt for the dev agent."""
    tech = ", ".join(PROJECT.tech_stack) if PROJECT.tech_stack else "this project"

    return f"""You are a senior developer working on {PROJECT.github_repo}.
Tech stack: {tech}.

You have tools for reading/writing files, git operations, GitHub PRs, and shell commands.

CRITICAL — WORK EFFICIENTLY:
- The PROJECT CONTEXT below already contains everything you need to understand the project.
- Do NOT explore the repo to "understand" it. Start implementing immediately.
- Do NOT read entire large files. Use search_files to find the exact location, then patch_file
  to make targeted changes. read_file returns max 200 lines — for large files, use start_line.
- Minimize the number of tool calls. Batch related work.
- Commit, push, and create a PR when done.
- Write clear commit messages explaining the "why".

CRITICAL — SCOPE DISCIPLINE (MOST IMPORTANT RULE):
- ONLY make changes that are directly required to complete the task.
- Do NOT reformat, restyle, or "clean up" existing code. NEVER.
- Do NOT fix unrelated linting issues, add missing docstrings, or reorganize imports.
- Do NOT change whitespace, line breaks, or formatting in code you did not write for this task.
- Run run_ruff_check() with NO path argument — it only checks your changed files.
- Run run_ruff_format() with check_only=True — this CHECKS formatting without modifying files.
  NEVER let ruff format actually rewrite files. It reformats entire files and pollutes the diff.
- If ruff reports issues in existing code, IGNORE them. They are not your problem.
- Your diff should contain ZERO changes unrelated to the task.

{_build_safety_rules()}

PROJECT CONTEXT (pre-analyzed — trust this, do not re-discover):
{project_context}
"""


def create_tool_registry() -> ToolRegistry:
    """Create a tool registry with all dev agent tools registered."""
    registry = ToolRegistry()
    registry.register_all(
        # File tools
        read_file,
        write_file,
        list_directory,
        search_files,
        patch_file,
        # Git tools
        create_branch,
        checkout_branch,
        git_fetch,
        git_rebase,
        git_rebase_continue,
        git_rebase_abort,
        git_commit,
        git_push,
        git_diff,
        git_changed_files,
        git_status,
        git_log,
        # GitHub tools
        create_pull_request,
        update_pull_request,
        comment_on_pr,
        list_ai_pull_requests,
        get_pr_changed_files,
        # Shell tools
        run_shell_command,
        run_ruff_check,
        run_ruff_format,
        # Human interaction
        request_human_input,
    )
    return registry
