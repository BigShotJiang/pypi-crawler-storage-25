"""
Manager — persistent container that handles discovery, task planning, PR monitoring,
and container cleanup. Runs via 'shypmate start', stops via 'shypmate stop'.

Responsibilities:
1. Clone repo and generate project brief (ONE LLM call, shared with all workers)
2. Generate per-task plans (one small LLM call each)
3. Monitor PRs for stale branches and re-spawn agents
4. Clean up containers for merged/closed PRs
5. Regenerate brief when the base branch advances
"""

import logging
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger("shypmate.manager")

BRIEF_DIR = Path("/brief")


class Manager:
    def __init__(self):
        self.github_token = os.environ.get("GITHUB_TOKEN", "")
        self.repo_name = os.environ.get("GITHUB_REPO", "")
        self.base_branch = os.environ.get("BASE_BRANCH", "main")
        self.poll_interval = int(os.environ.get("POLL_INTERVAL", "60"))
        self.llm_provider_name = os.environ.get("LLM_PROVIDER", "anthropic")
        self.llm_model = os.environ.get("LLM_MODEL", "claude-sonnet-4-6")
        self.llm_max_tokens = int(os.environ.get("LLM_MAX_TOKENS", "8192"))
        self.llm_base_url = os.environ.get("LLM_BASE_URL", "")
        self.workspace = os.environ.get("WORKSPACE", "/workspace")

        self._provider = None
        self._gh_repo = None
        self._current_sha = None

    def _get_provider(self):
        """Lazy-init LLM provider."""
        if self._provider is None:
            from shypmate.engine.providers import create_provider

            api_key_var = os.environ.get("LLM_API_KEY_VAR", "")
            api_key = os.environ.get(api_key_var, "") if api_key_var else None

            self._provider = create_provider(
                provider=self.llm_provider_name,
                model=self.llm_model,
                max_tokens=self.llm_max_tokens,
                base_url=self.llm_base_url or None,
                api_key=api_key,
            )
        return self._provider

    def _get_gh_repo(self):
        """Lazy-init GitHub repo."""
        if self._gh_repo is None:
            try:
                from github import Github
                self._gh_repo = Github(self.github_token).get_repo(self.repo_name)
            except Exception as e:
                logger.error(f"GitHub connection failed: {e}")
        return self._gh_repo

    def _clone_or_fetch(self):
        """Clone the repo or fetch if already cloned."""
        from git import Repo
        from git.exc import GitCommandError

        clone_url = f"https://x-access-token:{self.github_token}@github.com/{self.repo_name}.git"
        ws = Path(self.workspace)

        if ws.joinpath(".git").exists():
            logger.info("Fetching latest...")
            repo = Repo(self.workspace)
            repo.git.fetch("--all")
        else:
            logger.info(f"Cloning {self.repo_name}...")
            try:
                repo = Repo.clone_from(clone_url, self.workspace)
            except GitCommandError as e:
                logger.error(f"Clone failed: {e}")
                return None

        # Get current base branch SHA
        try:
            repo.git.checkout(self.base_branch)
            repo.git.pull("origin", self.base_branch)
            self._current_sha = repo.head.commit.hexsha
            logger.info(f"Base branch {self.base_branch} at {self._current_sha[:8]}")
        except Exception as e:
            logger.error(f"Could not update base branch: {e}")
            self._current_sha = repo.head.commit.hexsha

        return repo

    def ensure_brief(self) -> bool:
        """Generate or refresh the project brief. Returns True if brief is ready."""
        from shypmate.manager.project_brief import (
            load_brief, save_brief, generate_brief, is_brief_current,
        )

        # Check if current brief is still valid
        existing = load_brief(BRIEF_DIR)
        if existing and self._current_sha and is_brief_current(existing, self._current_sha):
            logger.info("Brief is current, no regeneration needed")
            return True

        # Clone/fetch repo
        repo = self._clone_or_fetch()
        if not repo:
            return existing is not None  # use stale brief if available

        # Build raw context
        logger.info("Building project context...")
        sys.path.insert(0, self.workspace)
        from shypmate.context.project_context import build_project_context
        raw_context = build_project_context(self.workspace)

        # Generate brief with ONE LLM call
        logger.info("Generating project brief (1 LLM call)...")
        provider = self._get_provider()
        brief = generate_brief(
            repo_root=Path(self.workspace),
            raw_context=raw_context,
            base_branch_sha=self._current_sha or "",
            provider=provider,
        )

        save_brief(brief, BRIEF_DIR)
        logger.info("Project brief generated and saved")
        return True

    def plan_task(self, task_id: str, description: str) -> bool:
        """Generate a focused plan for a specific task."""
        from shypmate.manager.project_brief import (
            load_brief, load_task_plan, generate_task_plan, save_task_plan,
        )

        # Check if plan already exists
        existing = load_task_plan(task_id, BRIEF_DIR)
        if existing:
            logger.info(f"Task plan already exists for {task_id}")
            return True

        # Load the project brief
        brief = load_brief(BRIEF_DIR)
        if not brief:
            logger.warning("No project brief available, skipping task planning")
            return False

        # Generate plan with one small LLM call
        logger.info(f"Planning task {task_id}: {description[:60]}...")
        provider = self._get_provider()
        plan = generate_task_plan(task_id, description, brief, provider)
        save_task_plan(plan, BRIEF_DIR)
        return True

    def cleanup_merged(self):
        """Remove containers for merged/closed PRs."""
        try:
            import docker
            client = docker.from_env()
            gh_repo = self._get_gh_repo()
            if not gh_repo:
                return

            containers = client.containers.list(
                all=True, filters={"name": "shypmate-", "status": "exited"}
            )

            for c in containers:
                if c.name in ("shypmate-manager", "shypmate-verify"):
                    continue

                branch = ""
                try:
                    for env in c.attrs.get("Config", {}).get("Env", []):
                        if env.startswith("AGENT_BRANCH="):
                            branch = env.split("=", 1)[1]
                            break
                except Exception:
                    pass

                if not branch:
                    continue

                try:
                    owner = gh_repo.owner.login
                    for pr in gh_repo.get_pulls(state="all", head=f"{owner}:{branch}"):
                        if pr.merged or pr.state == "closed":
                            logger.info(f"Cleaning up {c.name} (PR {pr.state})")
                            c.remove()
                            break
                except Exception:
                    pass

        except Exception as e:
            logger.error(f"Cleanup error: {e}")

    def poll(self):
        """One poll cycle: ensure brief, plan tasks, monitor PRs, cleanup."""
        try:
            self.ensure_brief()
        except Exception as e:
            logger.error(f"Brief generation error: {e}")

        # Plan any pending tasks
        try:
            from shypmate.task_manager import list_tasks
            for task in list_tasks():
                if task.get("status") == "pending":
                    self.plan_task(task["id"], task.get("description", ""))
        except Exception as e:
            logger.debug(f"Task planning skipped: {e}")

        # Cleanup merged containers
        try:
            self.cleanup_merged()
        except Exception as e:
            logger.error(f"Cleanup error: {e}")

    def run(self):
        """Main loop — poll on interval."""
        logger.info("=" * 50)
        logger.info("Shypmate Manager started")
        logger.info(f"  Repo: {self.repo_name}")
        logger.info(f"  Base branch: {self.base_branch}")
        logger.info(f"  LLM: {self.llm_provider_name} / {self.llm_model}")
        logger.info(f"  Poll interval: {self.poll_interval}s")
        logger.info("=" * 50)

        # Initial poll immediately
        self.poll()

        while True:
            try:
                time.sleep(self.poll_interval)
                self.poll()
            except KeyboardInterrupt:
                logger.info("Manager stopped")
                break
            except Exception as e:
                logger.error(f"Poll error: {e}", exc_info=True)
                time.sleep(self.poll_interval)


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    manager = Manager()
    return manager.run()


if __name__ == "__main__":
    sys.exit(main() or 0)
