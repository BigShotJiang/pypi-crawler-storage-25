"""
Project configuration — loaded from environment variables and shypmate.yml.

shypmate is project-agnostic. All project-specific values come from:
  1. Environment variables (SHYPMATE_* prefix) — for secrets and simple identifiers
  2. shypmate.yml at the project root — for structured config (validation, rules, etc.)

Nothing in this file is hardcoded to any specific project.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


def _detect_github_repo(project_root: Path) -> str:
    """Detect the GitHub repo (owner/name) from the git remote origin URL."""
    import re
    import subprocess

    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True, text=True, cwd=project_root,
        )
        if result.returncode != 0:
            return ""
        url = result.stdout.strip()
        # Match SSH (git@github.com:owner/repo.git) or HTTPS (https://github.com/owner/repo.git)
        match = re.match(r"(?:https?://github\.com/|git@github\.com:)([^/]+/[^/]+?)(?:\.git)?$", url)
        return match.group(1) if match else ""
    except Exception:
        return ""


def _detect_base_branch(project_root: Path) -> str:
    """Detect the default branch from the git remote."""
    import subprocess

    try:
        result = subprocess.run(
            ["git", "symbolic-ref", "refs/remotes/origin/HEAD"],
            capture_output=True, text=True, cwd=project_root,
        )
        if result.returncode == 0:
            # Output: refs/remotes/origin/main -> "main"
            return result.stdout.strip().split("/")[-1]
    except Exception:
        pass
    return ""


def _detect_context_files(project_root: Path) -> tuple[str, ...]:
    """Scan for common context files that exist in the project."""
    candidates = [
        "CLAUDE.md",
        "README.md",
        "docs/README.md",
        "CONTRIBUTING.md",
        "docs/CONTRIBUTING.md",
    ]
    found = [f for f in candidates if (project_root / f).exists()]
    return tuple(found) if found else ()


def _detect_install_command(project_root: Path) -> str:
    """Detect the dependency install command from project files."""
    # Check in priority order — first match wins
    if (project_root / "requirements.txt").exists():
        return "pip install -r requirements.txt"
    if (project_root / "pyproject.toml").exists():
        return "pip install -e ."
    if (project_root / "pnpm-lock.yaml").exists():
        return "pnpm install --frozen-lockfile"
    if (project_root / "yarn.lock").exists():
        return "yarn install --frozen-lockfile"
    if (project_root / "package-lock.json").exists():
        return "npm ci"
    if (project_root / "package.json").exists():
        return "npm install"
    if (project_root / "go.mod").exists():
        return "go mod download"
    if (project_root / "Gemfile.lock").exists():
        return "bundle install"
    if (project_root / "Cargo.toml").exists():
        return "cargo fetch"
    if (project_root / "composer.json").exists():
        return "composer install"
    if (project_root / "pom.xml").exists():
        return "mvn dependency:resolve"
    if (project_root / "build.gradle").exists():
        return "gradle dependencies"
    return ""


def _detect_docker_network() -> str:
    """Detect a project Docker network from docker network ls."""
    import subprocess

    try:
        result = subprocess.run(
            ["docker", "network", "ls", "--format", "{{.Name}}"],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            return ""
        default_networks = {"bridge", "host", "none"}
        for name in result.stdout.strip().splitlines():
            if name not in default_networks:
                return name
    except Exception:
        pass
    return ""


def _detect_tech_stack(project_root: Path) -> tuple[str, ...]:
    """Detect the tech stack from project files."""
    stack = []

    markers = {
        "pyproject.toml": "Python",
        "setup.py": "Python",
        "requirements.txt": "Python",
        "package.json": "JavaScript/Node.js",
        "tsconfig.json": "TypeScript",
        "go.mod": "Go",
        "Cargo.toml": "Rust",
        "Gemfile": "Ruby",
        "pom.xml": "Java/Maven",
        "build.gradle": "Java/Gradle",
        "composer.json": "PHP",
        ".csproj": "C#/.NET",
    }

    for filename, tech in markers.items():
        if (project_root / filename).exists() and tech not in stack:
            stack.append(tech)

    # Framework detection from pyproject.toml / requirements.txt
    framework_markers = {
        "django": "Django",
        "flask": "Flask",
        "fastapi": "FastAPI",
        "react": "React",
        "nextjs": "Next.js",
        "next": "Next.js",
        "vue": "Vue",
        "angular": "Angular",
    }

    for dep_file in ["pyproject.toml", "requirements.txt", "package.json"]:
        dep_path = project_root / dep_file
        if dep_path.exists():
            try:
                content = dep_path.read_text(encoding="utf-8").lower()
                for marker, framework in framework_markers.items():
                    if marker in content and framework not in stack:
                        stack.append(framework)
            except Exception:
                pass

    # Infrastructure markers
    if (project_root / "Dockerfile").exists() or (project_root / "docker-compose.yml").exists():
        stack.append("Docker")
    if (project_root / ".github" / "workflows").exists():
        stack.append("GitHub Actions")

    return tuple(stack)


# ── LLM Provider Presets ──────────────────────────────────

LLM_PROVIDER_PRESETS = {
    "anthropic": {
        "label": "Anthropic (Claude)",
        "model": "claude-sonnet-4-6",
        "api_key_var": "ANTHROPIC_API_KEY",
        "base_url": "",
    },
    "openai": {
        "label": "OpenAI (GPT)",
        "model": "gpt-4o",
        "api_key_var": "OPENAI_API_KEY",
        "base_url": "",
    },
    "gemini": {
        "label": "Google Gemini",
        "model": "gemini-2.5-pro",
        "api_key_var": "GOOGLE_API_KEY",
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
    },
    "azure": {
        "label": "Azure OpenAI",
        "model": "gpt-4o",
        "api_key_var": "AZURE_OPENAI_API_KEY",
        "base_url": "",  # user must set their Azure endpoint
    },
    "mistral": {
        "label": "Mistral AI",
        "model": "mistral-large-latest",
        "api_key_var": "MISTRAL_API_KEY",
        "base_url": "https://api.mistral.ai/v1",
    },
    "groq": {
        "label": "Groq",
        "model": "llama-3.3-70b-versatile",
        "api_key_var": "GROQ_API_KEY",
        "base_url": "https://api.groq.com/openai/v1",
    },
    "deepseek": {
        "label": "DeepSeek",
        "model": "deepseek-chat",
        "api_key_var": "DEEPSEEK_API_KEY",
        "base_url": "https://api.deepseek.com/v1",
    },
    "together": {
        "label": "Together AI",
        "model": "meta-llama/Llama-3.3-70B-Instruct-Turbo",
        "api_key_var": "TOGETHER_API_KEY",
        "base_url": "https://api.together.xyz/v1",
    },
    "ollama": {
        "label": "Ollama (local)",
        "model": "llama3.1",
        "api_key_var": "",
        "base_url": "http://localhost:11434/v1",
    },
    "lmstudio": {
        "label": "LM Studio (local)",
        "model": "local-model",
        "api_key_var": "",
        "base_url": "http://localhost:1234/v1",
    },
    "custom": {
        "label": "Custom (OpenAI-compatible)",
        "model": "",
        "api_key_var": "",
        "base_url": "",
    },
}


def _find_project_root() -> Path:
    """Walk up from cwd to find the project root (contains shypmate.yml or .git)."""
    current = Path.cwd()
    for parent in [current, *current.parents]:
        if (parent / "shypmate.yml").exists():
            return parent
        if (parent / ".git").exists():
            return parent
    return current


def _load_yaml_config(project_root: Path) -> dict[str, Any]:
    """Load shypmate.yml from the project root. Returns empty dict if not found."""
    config_path = project_root / "shypmate.yml"
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


def _set_nested(d: dict, path: list[str], value: Any) -> None:
    """Set a nested dict value by key path. e.g. ["github", "repo"] -> d["github"]["repo"]."""
    for key in path[:-1]:
        d = d.setdefault(key, {})
    d[path[-1]] = value


# Map function names in shypmate.py to config dict paths.
# If a user defines def github_repo(), its return value is placed at config["github"]["repo"].
_PY_FUNC_CONFIG_MAP = {
    "github_repo":             ["github", "repo"],
    "base_branch":             ["github", "base_branch"],
    "docker_network":          ["docker", "network"],
    "install_command":         ["install_command"],
    "tech_stack":              ["tech_stack"],
    "context_files":           ["context_files"],
    "validation_commands":     ["validation_commands"],
    "shared_service_rules":    ["shared_service_rules"],
    "llm_provider":            ["llm", "provider"],
    "llm_model":               ["llm", "model"],
    "llm_max_tokens":          ["llm", "max_tokens"],
    "llm_base_url":            ["llm", "base_url"],
    "llm_api_key_var":         ["llm", "api_key_var"],
    "llm_pool":                ["llm", "pool"],
    "branch_prefix":           ["github", "branch_prefix"],
    "pr_title_prefix":         ["github", "pr_title_prefix"],
    "pr_label":                ["github", "pr_label"],
    "allowed_shell_prefixes":  ["shell", "allowed_prefixes"],
    "blocked_shell_patterns":  ["shell", "blocked_patterns"],
    "quota":                   ["quota"],
}


def _load_py_config(project_root: Path) -> tuple[dict[str, Any], Any]:
    """Load shypmate.py from the project root.

    Returns (config_dict, module).
    - config_dict: merged from the 'config' dict variable AND any named functions
    - module: the loaded module (for accessing hook functions like select_llm)

    Users can provide config as:
      1. A 'config' dict (like shypmate.yml but in Python)
      2. Individual functions (e.g. def github_repo(): return "owner/repo")
      3. Both — functions override the dict per-field
    """
    config_path = project_root / "shypmate.py"
    if not config_path.exists():
        return {}, None

    import importlib.util
    spec = importlib.util.spec_from_file_location("shypmate_user_config", str(config_path))
    if not spec or not spec.loader:
        return {}, None

    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception:
        return {}, None

    # Start with the config dict
    config = getattr(module, "config", {})
    config = dict(config) if isinstance(config, dict) else {}

    # Overlay any named functions — they take precedence over the config dict
    for func_name, config_path_keys in _PY_FUNC_CONFIG_MAP.items():
        func = getattr(module, func_name, None)
        if func and callable(func):
            try:
                value = func()
                if value is not None:
                    _set_nested(config, config_path_keys, value)
            except Exception:
                pass  # skip failed function calls

    return config, module


def _deep_merge(base: dict, override: dict) -> dict:
    """Merge override into base. Override values win per-key.

    For nested dicts, merge recursively. For everything else, override replaces base.
    Only non-empty override values replace base values.
    """
    result = dict(base)
    for key, val in override.items():
        if val is None or val == "" or val == [] or val == {}:
            continue  # skip empty overrides — don't clobber base
        if key in result and isinstance(result[key], dict) and isinstance(val, dict):
            result[key] = _deep_merge(result[key], val)
        else:
            result[key] = val
    return result


# Module-level reference to the loaded shypmate.py module (for hooks)
_user_module = None


def _env(key: str, default: str = "") -> str:
    """Read an SHYPMATE_ prefixed env var."""
    return os.environ.get(f"SHYPMATE_{key}", os.environ.get(key, default))


def _parse_tuple_pairs(items: list[dict[str, str]] | None) -> tuple[tuple[str, str], ...]:
    """Convert a list of {command, description} dicts to tuple of tuples."""
    if not items:
        return ()
    return tuple((item["command"], item["description"]) for item in items)


def _parse_string_list(items: list[str] | None) -> tuple[str, ...]:
    """Convert a list of strings to a tuple."""
    if not items:
        return ()
    return tuple(items)


def _parse_llm_pool(pool_list: list[dict] | None) -> tuple:
    """Parse the llm.pool list from shypmate.yml into LLMPoolEntry tuples."""
    if not pool_list:
        return ()
    entries = []
    for item in pool_list:
        provider = item.get("provider", "anthropic")
        preset = LLM_PROVIDER_PRESETS.get(provider, {})
        entries.append(LLMPoolEntry(
            provider=provider,
            model=item.get("model", preset.get("model", "")),
            max_tokens=int(item.get("max_tokens", 8192)),
            base_url=item.get("base_url", preset.get("base_url", "")),
            api_key_var=item.get("api_key_var", preset.get("api_key_var", "")),
        ))
    return tuple(entries)


@dataclass(frozen=True)
class LLMPoolEntry:
    """A single LLM provider in the pool."""
    provider: str = "anthropic"
    model: str = "claude-sonnet-4-6"
    max_tokens: int = 8192
    base_url: str = ""
    api_key_var: str = "ANTHROPIC_API_KEY"


@dataclass(frozen=True)
class ProjectConfig:
    # GitHub
    github_repo: str = ""
    github_repo_source: str = ""
    base_branch: str = "main"
    base_branch_source: str = ""

    # Docker networking — agents attach to this network to reach shared services
    docker_network: str = "bridge"

    # Branch naming
    branch_prefix: str = "shypmate/dev"

    # PR conventions
    pr_title_prefix: str = "[AI]"
    pr_label: str = "shypmate-agent"


    # Context files the agent should read for project understanding
    context_files: tuple[str, ...] = ("README.md",)
    context_files_source: str = ""

    # Validation commands (run inside agent container)
    validation_commands: tuple[tuple[str, str], ...] = ()

    # Optional validation (may fail if env not fully set up)
    optional_validation_commands: tuple[tuple[str, str], ...] = ()

    # Shared service safety rules — embedded in agent instructions
    shared_service_rules: tuple[str, ...] = ()

    # Dependency install command (e.g. "pip install -r requirements.txt", "npm ci")
    install_command: str = ""
    install_command_source: str = ""

    # Agent container image
    agent_image_name: str = "shypmate-agent"
    agent_image_tag: str = "latest"

    # Monitor
    monitor_poll_interval_seconds: int = 60
    monitor_image_name: str = "shypmate-monitor"
    monitor_image_tag: str = "latest"

    # LLM (single provider — used when no pool is defined)
    llm_provider: str = "anthropic"
    llm_model: str = "claude-sonnet-4-6"
    llm_max_tokens: int = 8192
    llm_base_url: str = ""
    llm_api_key_var: str = "ANTHROPIC_API_KEY"

    # LLM pool — multiple providers for round-robin assignment across agents
    llm_pool: tuple[LLMPoolEntry, ...] = ()

    # Agent quotas — resource limits per agent run
    # Soft quotas: pause and ask human whether to continue
    soft_max_tokens: int = 0
    soft_max_cost: float = 0.0
    soft_max_seconds: int = 0
    soft_max_iterations: int = 0
    # Hard quotas: stop immediately
    hard_max_tokens: int = 0
    hard_max_cost: float = 0.0
    hard_max_seconds: int = 0
    hard_max_iterations: int = 0

    # Language/framework hints for the agent
    tech_stack: tuple[str, ...] = ()
    tech_stack_source: str = ""

    # Shell allowlist additions (project-specific commands the agent can run)
    allowed_shell_prefixes: tuple[str, ...] = ()

    # Shell blocklist additions (project-specific commands to block)
    blocked_shell_patterns: tuple[str, ...] = ()

    # Project root path (resolved at load time)
    project_root: str = ""


def load_config() -> ProjectConfig:
    """
    Load project config from env vars + shypmate.yml + shypmate.py.

    Priority: env var > shypmate.yml > shypmate.py > auto-detect > defaults
    """
    global _user_module

    root = _find_project_root()

    # Load both config sources and merge (yml wins over py per-field)
    py_config, _user_module = _load_py_config(root)
    yml = _load_yaml_config(root)
    merged = _deep_merge(py_config, yml)

    # Keep raw sources for source tracking
    yml_raw = yml
    py_raw = py_config

    github = merged.get("github", {})
    docker = merged.get("docker", {})
    agent = merged.get("agent", {})
    monitor_cfg = merged.get("monitor", {})
    llm = merged.get("llm", {})
    shell = merged.get("shell", {})

    def _config_source(yml_path: list[str], py_path: list[str] | None = None) -> str:
        """Determine which source a config value came from (yml > py)."""
        # Check yml
        d = yml_raw
        for key in yml_path:
            if isinstance(d, dict) and key in d and d[key]:
                d = d[key]
            else:
                d = None
                break
        if d is not None:
            return "shypmate.yml"
        # Check py
        d = py_raw
        for key in (py_path or yml_path):
            if isinstance(d, dict) and key in d and d[key]:
                d = d[key]
            else:
                d = None
                break
        if d is not None:
            return "shypmate.py"
        return ""

    # ── Resolve github_repo: env > yml > py > git remote ──
    _repo_from_env = os.environ.get("SHYPMATE_GITHUB_REPO", os.environ.get("GITHUB_REPO", ""))
    _repo_from_merged = github.get("repo", "")
    if _repo_from_env:
        _github_repo, _github_repo_source = _repo_from_env, "env"
    elif _repo_from_merged:
        _github_repo = _repo_from_merged
        _github_repo_source = _config_source(["github", "repo"])
    else:
        _detected = _detect_github_repo(root)
        _github_repo, _github_repo_source = (_detected, "git remote") if _detected else ("", "")

    # ── Resolve base_branch: env > yml > py > git remote HEAD ──
    _branch_from_env = os.environ.get("SHYPMATE_BASE_BRANCH", os.environ.get("BASE_BRANCH", ""))
    _branch_from_merged = github.get("base_branch", "")
    if _branch_from_env:
        _base_branch, _base_branch_source = _branch_from_env, "env"
    elif _branch_from_merged:
        _base_branch = _branch_from_merged
        _base_branch_source = _config_source(["github", "base_branch"])
    else:
        _detected = _detect_base_branch(root)
        _base_branch, _base_branch_source = (_detected, "git remote") if _detected else ("main", "default")

    # ── Resolve context_files: yml > py > auto-detect ──
    _context_from_merged = merged.get("context_files")
    if _context_from_merged:
        _context_files = _parse_string_list(_context_from_merged)
        _context_files_source = _config_source(["context_files"])
    else:
        _detected = _detect_context_files(root)
        _context_files, _context_files_source = (_detected, "auto-detected") if _detected else (("README.md",), "default")

    # ── Resolve install_command: yml > py > auto-detect ──
    _cmd_from_merged = merged.get("install_command", "")
    _legacy_req = merged.get("requirements_file", "")
    if _cmd_from_merged:
        _install_command = _cmd_from_merged
        _install_command_source = _config_source(["install_command"])
    elif _legacy_req:
        _install_command = f"pip install -r {_legacy_req}"
        _install_command_source = _config_source(["requirements_file"]) + " (requirements_file)"
    else:
        _detected = _detect_install_command(root)
        _install_command, _install_command_source = (_detected, "auto-detected") if _detected else ("", "")

    # ── Resolve tech_stack: yml > py > auto-detect ──
    _stack_from_merged = merged.get("tech_stack")
    if _stack_from_merged:
        _tech_stack = _parse_string_list(_stack_from_merged)
        _tech_stack_source = _config_source(["tech_stack"])
    else:
        _detected = _detect_tech_stack(root)
        _tech_stack, _tech_stack_source = (_detected, "auto-detected") if _detected else ((), "")

    return ProjectConfig(
        # GitHub
        github_repo=_github_repo,
        github_repo_source=_github_repo_source,
        base_branch=_base_branch,
        base_branch_source=_base_branch_source,

        # Docker
        docker_network=_env("DOCKER_NETWORK", docker.get("network", "bridge")),

        # Branch/PR
        branch_prefix=_env("BRANCH_PREFIX", github.get("branch_prefix", "shypmate/dev")),
        pr_title_prefix=github.get("pr_title_prefix", "[AI]"),
        pr_label=github.get("pr_label", "shypmate-agent"),

        # Context files
        context_files=_context_files,
        context_files_source=_context_files_source,

        # Validation
        validation_commands=_parse_tuple_pairs(
            yml.get("validation_commands")
        ),
        optional_validation_commands=_parse_tuple_pairs(
            yml.get("optional_validation_commands")
        ),

        # Safety rules
        shared_service_rules=_parse_string_list(
            yml.get("shared_service_rules")
        ),

        # Install command
        install_command=_install_command,
        install_command_source=_install_command_source,

        # Agent image
        agent_image_name=_env("AGENT_IMAGE_NAME", agent.get("image_name", "shypmate-agent")),
        agent_image_tag=_env("AGENT_IMAGE_TAG", agent.get("image_tag", "latest")),

        # Monitor
        monitor_poll_interval_seconds=int(_env(
            "POLL_INTERVAL",
            str(monitor_cfg.get("poll_interval_seconds", 60)),
        )),
        monitor_image_name=monitor_cfg.get("image_name", "shypmate-monitor"),
        monitor_image_tag=monitor_cfg.get("image_tag", "latest"),

        # LLM — resolve provider first, then use its preset for defaults
        llm_provider=_env("LLM_PROVIDER", llm.get("provider", "anthropic")),
        llm_model=_env("LLM_MODEL", llm.get("model",
            LLM_PROVIDER_PRESETS.get(
                _env("LLM_PROVIDER", llm.get("provider", "anthropic")), {}
            ).get("model", "claude-sonnet-4-6")
        )),
        llm_max_tokens=int(_env(
            "LLM_MAX_TOKENS",
            str(llm.get("max_tokens", 8192)),
        )),
        llm_base_url=_env("LLM_BASE_URL", llm.get("base_url",
            LLM_PROVIDER_PRESETS.get(
                _env("LLM_PROVIDER", llm.get("provider", "anthropic")), {}
            ).get("base_url", "")
        )),
        llm_api_key_var=llm.get("api_key_var",
            LLM_PROVIDER_PRESETS.get(
                _env("LLM_PROVIDER", llm.get("provider", "anthropic")), {}
            ).get("api_key_var", "ANTHROPIC_API_KEY")
        ),
        llm_pool=_parse_llm_pool(llm.get("pool")),

        # Tech stack
        tech_stack=_tech_stack,
        tech_stack_source=_tech_stack_source,

        # Shell customization
        allowed_shell_prefixes=_parse_string_list(shell.get("allowed_prefixes")),
        blocked_shell_patterns=_parse_string_list(shell.get("blocked_patterns")),

        # Agent quotas
        soft_max_tokens=int(merged.get("quota", {}).get("soft", {}).get("max_tokens", 0)),
        soft_max_cost=float(merged.get("quota", {}).get("soft", {}).get("max_cost", 0)),
        soft_max_seconds=int(merged.get("quota", {}).get("soft", {}).get("max_seconds", 0)),
        soft_max_iterations=int(merged.get("quota", {}).get("soft", {}).get("max_iterations", 0)),
        hard_max_tokens=int(merged.get("quota", {}).get("hard", {}).get("max_tokens", 0)),
        hard_max_cost=float(merged.get("quota", {}).get("hard", {}).get("max_cost", 0)),
        hard_max_seconds=int(merged.get("quota", {}).get("hard", {}).get("max_seconds", 0)),
        hard_max_iterations=int(merged.get("quota", {}).get("hard", {}).get("max_iterations", 0)),

        # Project root
        project_root=str(root),
    )


def get_llm_pool(config: ProjectConfig) -> tuple[LLMPoolEntry, ...]:
    """Get the effective LLM pool. Falls back to the single LLM config if no pool is defined."""
    if config.llm_pool:
        return config.llm_pool
    return (LLMPoolEntry(
        provider=config.llm_provider,
        model=config.llm_model,
        max_tokens=config.llm_max_tokens,
        base_url=config.llm_base_url,
        api_key_var=config.llm_api_key_var,
    ),)


def get_pool_entry(config: ProjectConfig, index: int, task: str = "") -> LLMPoolEntry:
    """Get a pool entry for an agent.

    If shypmate.py defines a select_llm(task, pool, agent_index) hook,
    it is called to choose the provider. Otherwise, round-robin is used.
    """
    pool = get_llm_pool(config)

    # Check for custom selection hook in shypmate.py
    if _user_module and hasattr(_user_module, "select_llm"):
        try:
            result = _user_module.select_llm(task, list(pool), index)
            if isinstance(result, LLMPoolEntry):
                return result
        except Exception:
            pass  # fall through to round-robin

    return pool[index % len(pool)]


def get_user_hook(name: str):
    """Get a hook function from shypmate.py by name, or None if not defined."""
    if _user_module and hasattr(_user_module, name):
        return getattr(_user_module, name)
    return None


def detect_all(project_root: Path | None = None) -> dict[str, Any]:
    """Run all auto-detection and return a dict of detected values with sources."""
    root = project_root or _find_project_root()
    repo = _detect_github_repo(root)
    branch = _detect_base_branch(root)
    context = _detect_context_files(root)
    install = _detect_install_command(root)
    stack = _detect_tech_stack(root)
    network = _detect_docker_network()

    return {
        "github_repo": (repo, "git remote") if repo else ("", None),
        "base_branch": (branch, "git remote") if branch else ("main", "default"),
        "context_files": (list(context), "auto-detected") if context else (["README.md"], "default"),
        "install_command": (install, "auto-detected") if install else ("", None),
        "tech_stack": (list(stack), "auto-detected") if stack else ([], None),
        "docker_network": (network, "docker") if network else ("bridge", "default"),
    }


# Singleton — import this from anywhere
PROJECT = load_config()
