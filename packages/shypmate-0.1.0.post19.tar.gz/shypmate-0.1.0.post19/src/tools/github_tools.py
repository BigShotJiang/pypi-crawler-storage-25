"""
GitHub tools for the dev agent.

Uses PyGithub for all GitHub API operations.
"""

import json
import logging
import os
import re
from datetime import datetime, timezone

from github import Github, GithubException

logger = logging.getLogger(__name__)


def _get_github() -> Github:
    token = os.environ["GITHUB_TOKEN"]
    return Github(token)


def _get_repo(gh: Github | None = None):
    from shypmate.config.project import PROJECT
    gh = gh or _get_github()
    return gh.get_repo(PROJECT.github_repo)


# --- PR metadata block ---

_META_START = "<!-- SHYPMATE_META"
_META_END = "SHYPMATE_META -->"


def encode_pr_metadata(meta: dict) -> str:
    """Encode metadata as a hidden HTML comment block for embedding in PR body."""
    return f"{_META_START}\n{json.dumps(meta, indent=2)}\n{_META_END}"


def decode_pr_metadata(body: str) -> dict | None:
    """Extract metadata dict from a PR body, or None if not found."""
    if not body:
        return None
    match = re.search(
        rf"{re.escape(_META_START)}\s*(\{{.*?\}})\s*{re.escape(_META_END)}",
        body,
        re.DOTALL,
    )
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            return None
    return None



def create_pull_request(
    title: str,
    body: str,
    branch_name: str,
    base_branch: str = "master",
    metadata: str = "",
) -> str:
    """Create a pull request on GitHub.

    Args:
        title: PR title.
        body: PR description (markdown).
        branch_name: Head branch name.
        base_branch: Base branch to merge into (default 'master').
        metadata: JSON string of metadata to embed in PR body (optional).
    """
    try:
        repo = _get_repo()

        # Append metadata block if provided
        full_body = body
        if metadata:
            try:
                meta_dict = json.loads(metadata)
            except json.JSONDecodeError:
                meta_dict = {"raw": metadata}
            full_body += "\n\n" + encode_pr_metadata(meta_dict)

        pr = repo.create_pull(
            title=title,
            body=full_body,
            head=branch_name,
            base=base_branch,
        )
        return f"PR created: #{pr.number} — {pr.html_url}"
    except GithubException as e:
        return f"Error creating PR: {e}"



def update_pull_request(
    pr_number: int,
    title: str = "",
    body: str = "",
) -> str:
    """Update an existing pull request's title and/or body.

    Args:
        pr_number: PR number to update.
        title: New title (leave empty to keep current).
        body: New body (leave empty to keep current).
    """
    try:
        repo = _get_repo()
        pr = repo.get_pull(pr_number)
        kwargs = {}
        if title:
            kwargs["title"] = title
        if body:
            kwargs["body"] = body
        if kwargs:
            pr.edit(**kwargs)
        return f"PR #{pr_number} updated"
    except GithubException as e:
        return f"Error updating PR: {e}"



def comment_on_pr(pr_number: int, comment: str) -> str:
    """Add a comment to a pull request.

    Args:
        pr_number: PR number.
        comment: Comment body (markdown).
    """
    try:
        repo = _get_repo()
        pr = repo.get_pull(pr_number)
        pr.create_issue_comment(comment)
        return f"Comment added to PR #{pr_number}"
    except GithubException as e:
        return f"Error commenting: {e}"



def list_ai_pull_requests() -> str:
    """List all open pull requests on branches matching the ai/* prefix.

    Returns a JSON list of PR summaries.
    """
    try:
        repo = _get_repo()
        prs = repo.get_pulls(state="open")
        ai_prs = []
        for pr in prs:
            if pr.head.ref.startswith("shypmate/"):
                meta = decode_pr_metadata(pr.body or "")
                ai_prs.append({
                    "number": pr.number,
                    "title": pr.title,
                    "branch": pr.head.ref,
                    "base": pr.base.ref,
                    "created_at": pr.created_at.isoformat(),
                    "updated_at": pr.updated_at.isoformat(),
                    "metadata": meta,
                })
        return json.dumps(ai_prs, indent=2)
    except GithubException as e:
        return f"Error listing PRs: {e}"



def get_pr_metadata(pr_number: int) -> str:
    """Get the shypmate metadata embedded in a PR body.

    Args:
        pr_number: PR number.
    """
    try:
        repo = _get_repo()
        pr = repo.get_pull(pr_number)
        meta = decode_pr_metadata(pr.body or "")
        if meta:
            return json.dumps(meta, indent=2)
        return "No Shypmate metadata found in this PR."
    except GithubException as e:
        return f"Error: {e}"



def get_pr_changed_files(pr_number: int) -> str:
    """List files changed in a pull request.

    Args:
        pr_number: PR number.
    """
    try:
        repo = _get_repo()
        pr = repo.get_pull(pr_number)
        files = [f.filename for f in pr.get_files()]
        return "\n".join(files)
    except GithubException as e:
        return f"Error: {e}"
