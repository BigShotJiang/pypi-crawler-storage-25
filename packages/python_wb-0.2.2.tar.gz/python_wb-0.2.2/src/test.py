import asyncio
from datetime import datetime, timedelta

from pywb import WBClient
from pywb.types import SuppliesFiltersRequest, DateFilterRequest


async def main():
    token = "eyJhbGciOiJFUzI1NiIsImtpZCI6IjIwMjYwMzAydjEiLCJ0eXAiOiJKV1QifQ.eyJhY2MiOjEsImVudCI6MSwiZXhwIjoxNzkwMzk3MTQxLCJpZCI6IjAxOWQzMDIzLWJkMGMtNzYyNy1hZmQ4LTVmOGIwMWVmOGEwYyIsImlpZCI6MTI4NDg1NDE5LCJvaWQiOjI1MDEyNDEwOCwicyI6MTYxMjYsInNpZCI6ImJjMDRiNDUyLTlkMWMtNDM3MC1hZDUwLTc1NDQzYmJiZWQzMCIsInQiOmZhbHNlLCJ1aWQiOjEyODQ4NTQxOX0.r2N1FXLRM8PZM43PzkKa4HgrdFSYf5Nz3s2JXUPrcUOZ0RicfvWqa4JowK6FVDps8pHoqsnHDukuRLvNKqvCbQ"
    now = datetime.now().date().isoformat()
    yesterday = (datetime.now() - timedelta(days=1)).date().isoformat()
    filters = SuppliesFiltersRequest(
        dates=[
            DateFilterRequest(from_date=yesterday, till=now, type="createDate")
        ]
    )

    async with WBClient(token) as client:
        resp = await client.get_supplies_fbw(filter_data=filters)
        print(resp)


if __name__ == "__main__":
    asyncio.run(main())
