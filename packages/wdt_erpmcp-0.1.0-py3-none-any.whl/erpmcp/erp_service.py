import json
from fastmcp import FastMCP
from .WdtClient import WdtClient
import os


mcp = FastMCP("ErpApiService")
def get_client():
    appkey = os.getenv("WDT_APPKEY")
    secret = os.getenv("WDT_APPSECRET")
    sid = os.getenv("WDT_SID")

    if not all([appkey, secret, sid]):
        raise ValueError("Missing WDT environment variables")

    return WdtClient(
        appkey,
        secret,
        sid,
        os.getenv("WDT_BASE_URL", "https://api.wangdian.cn/openapi2/")
    )

@mcp.tool()
def get_erp_warehouse():
    """用于获取旺店通内所有仓库信息"""
    t = get_client()
    params = {}
    response = t.execute("warehouse_query.php", params)
    data = json.loads(response)
    return data


@mcp.tool()
def get_erp_purchase_provider():
    """用于获取旺店通内供货商信息"""
    t = get_client()
    params = {
        "column": "provider_no,provider_name"
    }
    response = t.execute("purchase_provider_query.php", params)
    data = json.loads(response)
    return data


@mcp.tool()
def get_erp_stock(warehouse_no: str, barcode: str):
    """根据仓库编号和条形码获取erp内指定商品数据"""
    t = get_client()
    params = {
        "warehouse_no": warehouse_no,
        "barcode": barcode,
    }
    response = t.execute("stock_query_detail.php", params)
    data = json.loads(response)
    return data

def main():
    mcp.run()

if __name__ == "__main__":
    main()
