"""Tests for trading module — EIP-712 signing, HMAC headers, V1 and V2."""

import base64

from polynode.trading.cosigner import build_l2_headers
from polynode.trading.eip712 import (
    build_order_payload,
    build_order_payload_v2,
    compute_amounts,
    EXCHANGE_DOMAIN,
    EXCHANGE_DOMAIN_V2,
    NEG_RISK_DOMAIN,
    NEG_RISK_DOMAIN_V2,
    ORDER_TYPES,
    ORDER_TYPES_V2,
)
from polynode.trading.constants import (
    CLOB_HOST,
    CLOB_HOST_V2,
    COLLATERAL_OFFRAMP,
    COLLATERAL_ONRAMP,
    CTF_EXCHANGE,
    CTF_EXCHANGE_V2,
    NEG_RISK_CTF_EXCHANGE,
    NEG_RISK_CTF_EXCHANGE_V2_A,
    NEG_RISK_CTF_EXCHANGE_V2_B,
    POLY_USD,
    SPENDERS,
    USDC,
    V2_SPENDERS,
)
from polynode.trading.clob_api import _clob_host
from polynode.trading.types import ExchangeVersion, SignatureType


def test_compute_amounts_buy():
    maker, taker = compute_amounts(0.55, 100, "BUY", "0.01")
    # BUY: maker pays USDC (price * size), taker gets tokens (size)
    assert maker == 55_000_000  # 0.55 * 100 * 1e6
    assert taker == 100_000_000  # 100 * 1e6


def test_compute_amounts_sell():
    maker, taker = compute_amounts(0.55, 100, "SELL", "0.01")
    # SELL: maker provides tokens (size), taker pays USDC
    assert maker == 100_000_000
    assert taker == 55_000_000


def test_build_l2_headers():
    headers = build_l2_headers(
        api_key="test_key",
        api_secret=base64.b64encode(b"test_secret").decode(),
        api_passphrase="test_pass",
        wallet_address="0x1234",
        method="POST",
        path="/order",
        body='{"test": true}',
    )
    assert headers["POLY_ADDRESS"] == "0x1234"
    assert headers["POLY_API_KEY"] == "test_key"
    assert headers["POLY_PASSPHRASE"] == "test_pass"
    assert "POLY_SIGNATURE" in headers
    assert "POLY_TIMESTAMP" in headers


def test_safe_address_derivation():
    """Verify Safe address derivation matches known addresses."""
    try:
        from polynode.trading.onboarding import derive_safe_address
        # This requires eth-account/web3 — skip if not installed
        addr = derive_safe_address("0x0000000000000000000000000000000000000001")
        assert addr.startswith("0x")
        assert len(addr) == 42
    except ImportError:
        pass  # Skip if trading deps not installed


# ── V2 constants ──


def test_v2_constants():
    """V2 CLOB host and exchange addresses are correct."""
    assert CLOB_HOST_V2 == "https://clob-v2.polymarket.com"
    assert CTF_EXCHANGE_V2 == "0xe111180000d2663c0091e4f400237545b87b996b"
    assert NEG_RISK_CTF_EXCHANGE_V2_A == "0xe2222d279d744050d28e00520010520000310f59"


def test_clob_host_routing():
    """_clob_host routes to V1 or V2 based on version."""
    assert _clob_host(ExchangeVersion.V1) == CLOB_HOST
    assert _clob_host(ExchangeVersion.V2) == CLOB_HOST_V2


# ── V2 EIP-712 domains ──


def test_v2_domain_version():
    """V2 domain uses version '2'."""
    assert EXCHANGE_DOMAIN["version"] == "1"
    assert EXCHANGE_DOMAIN_V2["version"] == "2"
    assert EXCHANGE_DOMAIN_V2["verifyingContract"] == CTF_EXCHANGE_V2


def test_v2_neg_risk_domain():
    """V2 neg-risk domain points to NegRisk V2 A exchange."""
    assert NEG_RISK_DOMAIN["verifyingContract"] == NEG_RISK_CTF_EXCHANGE
    assert NEG_RISK_DOMAIN_V2["verifyingContract"] == NEG_RISK_CTF_EXCHANGE_V2_A


# ── V2 order types ──


def test_v2_order_type_fields():
    """V2 order type has the correct fields (no taker/expiration/nonce/feeRateBps, adds timestamp/metadata/builder)."""
    v1_names = {f["name"] for f in ORDER_TYPES["Order"]}
    v2_names = {f["name"] for f in ORDER_TYPES_V2["Order"]}

    # V1-only fields
    assert "taker" in v1_names
    assert "expiration" in v1_names
    assert "nonce" in v1_names
    assert "feeRateBps" in v1_names

    # V2-only fields
    assert "timestamp" in v2_names
    assert "metadata" in v2_names
    assert "builder" in v2_names

    # Fields removed from V2
    assert "taker" not in v2_names
    assert "expiration" not in v2_names
    assert "nonce" not in v2_names
    assert "feeRateBps" not in v2_names


# ── V2 payload building ──


def test_v2_build_order_payload():
    """build_order_payload_v2 produces the correct EIP-712 message structure."""
    payload = build_order_payload_v2(
        maker="0xaaa0000000000000000000000000000000000001",
        signer="0xbbb0000000000000000000000000000000000002",
        token_id="12345",
        maker_amount=100000,
        taker_amount=5000000,
        side="BUY",
        signature_type=SignatureType.EOA,
        timestamp_ms=1712345678000,
    )

    assert payload.primary_type == "Order"
    assert payload.domain == EXCHANGE_DOMAIN_V2
    assert payload.types == ORDER_TYPES_V2

    msg = payload.message
    assert msg["salt"] == 1712345678000
    assert msg["maker"] == "0xaaa0000000000000000000000000000000000001"
    assert msg["signer"] == "0xbbb0000000000000000000000000000000000002"
    assert msg["tokenId"] == 12345
    assert msg["makerAmount"] == 100000
    assert msg["takerAmount"] == 5000000
    assert msg["side"] == 0  # BUY -> 0 for EIP-712 signing
    assert msg["signatureType"] == 0
    assert msg["timestamp"] == 1712345678000
    # metadata and builder default to zero bytes32
    assert msg["metadata"] == "0x" + "00" * 32
    assert msg["builder"] == "0x" + "00" * 32


def test_v2_build_order_payload_sell_neg_risk():
    """V2 neg-risk SELL order uses the correct domain."""
    payload = build_order_payload_v2(
        maker="0xaaa0000000000000000000000000000000000001",
        signer="0xbbb0000000000000000000000000000000000002",
        token_id="99999",
        maker_amount=200000,
        taker_amount=1000000,
        side="SELL",
        signature_type=SignatureType.POLY_GNOSIS_SAFE,
        neg_risk=True,
        timestamp_ms=1700000000000,
    )

    assert payload.domain == NEG_RISK_DOMAIN_V2
    assert payload.message["side"] == 1  # SELL -> 1
    assert payload.message["signatureType"] == 2  # POLY_GNOSIS_SAFE


def test_v1_payload_unchanged():
    """V1 build_order_payload still works the same way."""
    payload = build_order_payload(
        maker="0xaaa0000000000000000000000000000000000001",
        signer="0xbbb0000000000000000000000000000000000002",
        token_id="12345",
        maker_amount=100000,
        taker_amount=5000000,
        side="BUY",
        signature_type=SignatureType.EOA,
    )

    assert payload.domain == EXCHANGE_DOMAIN
    assert payload.types == ORDER_TYPES
    msg = payload.message
    assert "taker" in msg
    assert "expiration" in msg
    assert "nonce" in msg
    assert "feeRateBps" in msg
    assert "timestamp" not in msg
    assert "metadata" not in msg
    assert "builder" not in msg


# ── ExchangeVersion enum ──


def test_exchange_version_values():
    """ExchangeVersion enum has V1=1, V2=2."""
    assert ExchangeVersion.V1 == 1
    assert ExchangeVersion.V2 == 2


def test_trader_config_default_v1():
    """Default TraderConfig uses V1."""
    from polynode.trading.types import TraderConfig
    config = TraderConfig()
    assert config.exchange_version == ExchangeVersion.V1


def test_trader_config_v2():
    """TraderConfig can be set to V2."""
    from polynode.trading.types import TraderConfig
    config = TraderConfig(exchange_version=ExchangeVersion.V2)
    assert config.exchange_version == ExchangeVersion.V2


# ── V2 approval constants ──


def test_v2_spenders_list():
    """V2_SPENDERS contains the three V2 exchange contracts."""
    assert CTF_EXCHANGE_V2 in V2_SPENDERS
    assert NEG_RISK_CTF_EXCHANGE_V2_A in V2_SPENDERS
    assert NEG_RISK_CTF_EXCHANGE_V2_B in V2_SPENDERS
    assert len(V2_SPENDERS) == 3


def test_v1_spenders_unchanged():
    """V1 SPENDERS list is unchanged."""
    assert CTF_EXCHANGE in SPENDERS
    assert NEG_RISK_CTF_EXCHANGE in SPENDERS
    assert len(SPENDERS) == 3


def test_polyusd_constants():
    """PolyUSD and wrapping contract addresses are set."""
    assert POLY_USD == "0xc011a7e12a19f7b1f670d46f03b03f3342e82dfb"
    assert COLLATERAL_ONRAMP == "0x93070a847efef7f70739046a929d47a521f5b8ee"
    assert COLLATERAL_OFFRAMP == "0x2957922eb93258b93368531d39facca3b4dc5854"


def test_v2_approval_targets_polyusd():
    """V2 approvals should target PolyUSD (not USDC) and V2 spenders."""
    # V2 collateral is PolyUSD, not USDC
    assert POLY_USD != USDC
    # V2 spenders are distinct from V1 spenders
    for s in V2_SPENDERS:
        assert s not in SPENDERS


def test_v1_approval_targets_usdc():
    """V1 approvals target USDC and V1 spenders (sanity check)."""
    assert USDC == "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"
    assert CTF_EXCHANGE in SPENDERS


# ── Wrap / Unwrap function signatures ──


def test_wrap_function_selector():
    """wrap(address,address,uint256) has selector 0x62355638."""
    try:
        from web3 import Web3
    except ImportError:
        # Verify via manual keccak if web3 not available
        return

    selector = Web3.keccak(text="wrap(address,address,uint256)")[:4].hex()
    assert selector == "62355638"


def test_unwrap_function_exists():
    """unwrap(address,address,uint256) selector can be computed."""
    try:
        from web3 import Web3
    except ImportError:
        return

    selector = Web3.keccak(text="unwrap(address,address,uint256)")[:4].hex()
    # Just verify it's a valid 4-byte selector
    assert len(selector) == 8


def test_check_approvals_accepts_version():
    """check_approvals function signature accepts a version parameter."""
    import inspect
    from polynode.trading.onboarding import check_approvals
    sig = inspect.signature(check_approvals)
    assert "version" in sig.parameters
    # Default is V1
    assert sig.parameters["version"].default == ExchangeVersion.V1


def test_set_approvals_accepts_version():
    """set_approvals function signature accepts a version parameter."""
    import inspect
    from polynode.trading.onboarding import set_approvals
    sig = inspect.signature(set_approvals)
    assert "version" in sig.parameters
    assert sig.parameters["version"].default == ExchangeVersion.V1


def test_trader_has_wrap_unwrap_methods():
    """PolyNodeTrader has wrap, unwrap, and balance methods."""
    from polynode.trading.trader import PolyNodeTrader
    assert hasattr(PolyNodeTrader, "wrap_to_polyusd")
    assert hasattr(PolyNodeTrader, "unwrap_from_polyusd")
    assert hasattr(PolyNodeTrader, "get_polyusd_balance")
    assert hasattr(PolyNodeTrader, "get_usdce_balance")
    assert callable(getattr(PolyNodeTrader, "wrap_to_polyusd"))
    assert callable(getattr(PolyNodeTrader, "unwrap_from_polyusd"))
    assert callable(getattr(PolyNodeTrader, "get_polyusd_balance"))
    assert callable(getattr(PolyNodeTrader, "get_usdce_balance"))
