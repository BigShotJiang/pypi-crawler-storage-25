"""Trading module type definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Literal, Protocol, runtime_checkable


class SignatureType(IntEnum):
    EOA = 0
    POLY_PROXY = 1
    POLY_GNOSIS_SAFE = 2


class ExchangeVersion(IntEnum):
    V1 = 1
    V2 = 2


@runtime_checkable
class RouterSigner(Protocol):
    async def get_address(self) -> str: ...
    async def sign_typed_data(self, payload: Eip712Payload) -> str: ...


@dataclass
class Eip712Payload:
    domain: dict[str, Any]
    types: dict[str, Any]
    primary_type: str
    message: dict[str, Any]


@dataclass
class GeneratedWallet:
    private_key: str
    address: str


@dataclass
class FeeConfig:
    """Optional fee configuration for per-order fee collection via on-chain escrow."""
    fee_bps: int  # fee in basis points (e.g. 50 = 0.5%)
    affiliate: str | None = None  # partner wallet address
    affiliate_share_bps: int | None = None  # partner's share of fee in bps


@dataclass
class BuilderCredentials:
    """Polymarket builder credentials for order attribution."""
    key: str
    secret: str
    passphrase: str


@dataclass
class TraderConfig:
    polynode_key: str = ""
    db_path: str = "./polynode-trading.db"
    cosigner_url: str = "https://trade.polynode.dev"
    fallback_direct: bool = True
    default_signature_type: SignatureType = SignatureType.POLY_GNOSIS_SAFE
    rpc_url: str = "https://polygon-bor-rpc.publicnode.com"
    builder_credentials: BuilderCredentials | None = None
    exchange_version: ExchangeVersion = ExchangeVersion.V1
    fee_config: FeeConfig | None = None


@dataclass
class ReadyStatus:
    wallet: str
    funder_address: str
    signature_type: SignatureType
    safe_deployed: bool
    approvals_set: bool
    credentials_stored: bool
    credentials: dict[str, str]
    actions: list[str]


@dataclass
class LinkResult:
    wallet: str
    funder_address: str
    signature_type: SignatureType
    credentials: dict[str, str]


@dataclass
class WalletInfo:
    wallet: str
    funder_address: str
    signature_type: SignatureType
    credentials: dict[str, str]
    created_at: float


@dataclass
class WalletExport:
    wallet: str
    funder_address: str
    signature_type: SignatureType
    credentials: dict[str, str]
    safe_deployed: bool
    approvals_set: bool
    created_at: float


@dataclass
class ApprovalStatus:
    funder_address: str
    usdc: dict[str, bool]
    ctf: dict[str, bool]
    all_approved: bool


@dataclass
class BalanceInfo:
    funder_address: str
    usdc: str
    usdc_raw: str
    matic: str


OrderSide = Literal["BUY", "SELL"]
OrderType = Literal["GTC", "GTD", "FOK", "FAK"]


@dataclass
class OrderParams:
    token_id: str
    side: OrderSide
    price: float
    size: float
    type: OrderType = "GTC"
    expiration: int | None = None
    post_only: bool = False
    fee_config: FeeConfig | None = None


@dataclass
class OrderResult:
    success: bool
    order_id: str | None = None
    status: str | None = None
    error: str | None = None
    making_amount: str | None = None
    taking_amount: str | None = None
    fee_escrow_tx_hash: str | None = None
    fee_amount: str | None = None


@dataclass
class CancelResult:
    canceled: list[str] = field(default_factory=list)
    not_canceled: dict[str, str] = field(default_factory=dict)


@dataclass
class OpenOrder:
    id: str
    market: str
    asset_id: str
    side: str
    price: str
    original_size: str
    size_matched: str
    status: str
    created_at: str
    order_type: str


# ── Position Management (split/merge/convert) ──


@dataclass
class SplitParams:
    """Parameters for splitting USDC into YES + NO outcome tokens."""
    condition_id: str
    amount: float  # USDC amount (e.g. 100.0 = $100)


@dataclass
class MergeParams:
    """Parameters for merging YES + NO outcome tokens back into USDC."""
    condition_id: str
    amount: float


@dataclass
class ConvertParams:
    """Parameters for converting NO positions on selected outcomes.
    Only works on neg-risk multi-outcome markets."""
    market_id: str
    outcome_indices: list[int]  # e.g. [0, 1]
    amount: float


@dataclass
class TransactionRequest:
    """A pre-built transaction ready for submission."""
    to: str
    data: str  # hex-encoded calldata
    value: str = "0"


@dataclass
class PositionResult:
    """Result of a position management operation."""
    success: bool
    tx_hash: str | None = None
    error: str | None = None


@dataclass
class MarketMeta:
    token_id: str
    tick_size: str
    fee_rate_bps: int
    neg_risk: bool
    fetched_at: float


@dataclass
class OrderHistoryRow:
    id: int
    wallet_address: str
    order_id: str | None
    token_id: str
    side: str
    price: float
    size: float
    order_type: str
    status: str
    error_msg: str | None
    response_json: str | None
    created_at: float
    fee_amount_raw: str | None = None
    escrow_order_id: str | None = None
    fee_escrow_tx_hash: str | None = None


@dataclass
class HistoryParams:
    limit: int | None = None
    offset: int | None = None
    token_id: str | None = None
    side: OrderSide | None = None


@dataclass
class StoredCredentials:
    wallet_address: str
    funder_address: str | None
    api_key: str
    api_secret: str
    api_passphrase: str
    signature_type: SignatureType
    safe_deployed: bool
    approvals_set: bool
    created_at: float
    updated_at: float
