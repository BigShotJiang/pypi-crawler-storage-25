from typing import Any


class ServerResponse:
    """The object that should be used when creating a response to a request for a resource."""

    def __init__(
        self,
        response: Any | None = None,
        error: bool = False,
        code: int = 200,
        headers: dict[str, int | str] | None = None,
    ):
        """Creates the server response, with an error code if necessary.

        Args:
            response (str | bytes | None): The response to send to the requested clients.
            error (bool, False): Whether to send this response with an error code.
            code (int, 200): The code to send with the response. Defaults to 200 (OK).
        """
        self.response = response
        self.error = error
        self.code = code
        self.headers = headers

    def construct(self):
        """Constructs a byte string that conforms to a HTTP/1.1 request with the method."""
        res = ""
        res += f"HTTP/1.1 200 OK\r\n"
        res += f"User-Agent: sunsehttp/0.1.0\r\n"
        res += f"Accept: */*\r\n"
        res += "\r\n"  # we can allow them to edit this later
        if self.headers:
            for i in self.headers:
                res += f"{i}: {self.headers[i]}\r\n"
            if self.response:
                res += bytes(self.response) if isinstance(self.response, str) else self.response  # type: ignore
            # we can expect bytes and strs commonly here, but if we want more, we need to account for those
        return res.encode()
