"""Contains the server-side function definitions."""

from typing import Callable
import socket
import ssl
import socketserver

from .sresp import ServerResponse
from .exceptions import NonexistentMethod


class ServerRequestHandler(socketserver.BaseRequestHandler):

    def handle(self):

        path = str(self.request).split("\r\n")[0].split(" ")[1]
        if self.server.match.get(path):  # type: ignore
            self.server.match[path][1]()  # type: ignore

        else:
            raise NonexistentMethod(
                f"Method {path} does not have a specified callback."
            )


class Server:
    def __init__(self, url: str = "localhost", port: int | None = 80):
        self.url = url + str(port) if port else ""

        self.__map: dict[str, tuple[str, Callable]] = {
            "/": ("GET", self.serve)
        }  # the paths that are defined within this server
        self.queue: list[tuple[str, Callable]] = []
        self.__context = ssl._create_default_https_context()
        self._s = socketserver.TCPServer((url, port), ServerRequestHandler)  # type: ignore
        self._s.match = self.__map  # type: ignore

    def start(self):
        """Starts the server and allows the server to respond to requests."""

    def route(
        self, path: str, method: str, func: Callable[[bytes | None], ServerResponse]
    ):
        """Creates a route to access a certain resource. Function should contain a ServerResponse class as a return value, and take bytes or nothing as an argument.
        Args:
            path - str - The path that this resource can be accessed by.
            method - str - The HTTP method that this resource can be accessed by. Non-standard HTTP methods are not supported.
        """

        def adds(**kwargs):
            if path == "/":
                self.__map.pop("/")
            self.__map[path] = (method, func)

        return adds

    def _handle_callbacks(self):
        for i in self.queue:
            self.__map[i[0]][1]()  # pyright: ignore[reportCallIssue]

    def serve(self):
        """Serves a template route. By default, this just responds to the client with Hello World, with no HTML, but this method can be overridden. This is the callback that is used for the `/` route, if the / route is not overridden."""
        return ServerResponse("Hello World")

    def send_to_client(self, data: bytes):
        self._s.socket.send(data)
