"""
# sunsehttp.server
Objects and methods to help with server side application construction/ the server-side part of sunsehttp.
"""

from ._shttp import Server
from .sresp import ServerResponse
from .exceptions import NonexistentMethod
