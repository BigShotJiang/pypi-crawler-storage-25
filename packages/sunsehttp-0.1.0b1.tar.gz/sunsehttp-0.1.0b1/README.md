# sunsettp
A http (and websockets) library for python that I'm making for fun because i'm bored
planning to add async capabilities, for now it is in an alpha state
If there's any bugs, please go to https://github.com/sunset-hue/sunsehttp and create an issue.
