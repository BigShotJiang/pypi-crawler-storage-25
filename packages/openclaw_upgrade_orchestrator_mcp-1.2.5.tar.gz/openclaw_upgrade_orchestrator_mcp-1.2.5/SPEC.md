# `openclaw-upgrade-orchestrator-mcp` — Server Spec

**Version:** v1.2.3
**Status:** mock + openclaw-system backends shipped + v1.2 provider-side regression detection shipped (P08 fold-in); v1.2.3 added Phase 1B coverage + SPEC drift fix
**Tests:** 117 passing (Phase 1B added 9 server-protocol coverage tests + `build_server` exposed at top level, commit 5c6ba98)
**Last updated:** 2026-05-07 (D3 SPEC drift sweep)

---

## Goal

A user runs `claude mcp add openclaw-upgrade`, restarts Claude Desktop, and from inside Claude can:

1. Call `current_version` to confirm the backend can read the deployment.
2. Call `available_upgrades` to see what newer versions exist + which carry CRITICAL regressions.
3. Call `pre_upgrade_snapshot(target_version=...)` to capture state before upgrading.
4. Call `upgrade_guide(target_version=...)` to get a step-by-step plan with applicable regressions + mitigations.
5. After running the upgrade manually, call `post_upgrade_verify(pre_snapshot_id=...)` to diff state.
6. If something broke, call `rollback_guide(snapshot_id=...)` for recovery steps.

All without writing custom changelog scrapers. All locally — no version data leaves the operator's machine.

---

## Non-goals

- **Not an executor.** Never runs `openclaw upgrade --to ...` itself. The operator retains full agency over the actual upgrade.
- **Not a sandbox.** Doesn't roll back automatically. Detects regressions, doesn't undo them.
- **Not a generic version-matrix.** Hand-curated catalog of OpenClaw-specific regressions. Other runtimes are Custom MCP Build engagements.
- **Not a real-time monitor.** Snapshots are captured at tool-call time. For continuous monitoring, pair with `openclaw-health-mcp`.
- **Not a multi-tenant fleet manager.** Single-deployment focus for v1.0. Fleet view is v1.x candidate.

---

## Tool surface

### `current_version`

```
current_version() -> CurrentVersionInfo
```

Returns the currently-installed version + detection method (`mock`, `openclaw-system`, etc.). `notes` field set if version couldn't be detected.

### `available_upgrades`

```
available_upgrades() -> AvailableUpgradesReport
```

Lists newer-than-current versions with applicable regression counts + a `recommended_target` heuristic (highest version with no CRITICAL regressions in path).

### `pre_upgrade_snapshot`

```
pre_upgrade_snapshot(target_version: str | None = None) -> Snapshot
```

Runs every detection check. Persists the result with a unique `snapshot_id`. Used as the baseline for `post_upgrade_verify` and `rollback_guide`.

### `upgrade_guide`

```
upgrade_guide(target_version: str) -> UpgradeGuide
```

Composes the step-by-step plan: pre-upgrade prep, upgrade commands, post-upgrade verification, rollback steps, applicable known regressions with mitigations, confidence note.

### `post_upgrade_verify`

```
post_upgrade_verify(pre_snapshot_id: str) -> PostUpgradeReport
```

Captures a fresh snapshot, diffs against the stored `pre_snapshot_id`. Returns:
- `new_failures` — checks PASSed pre, FAIL post (most important)
- `recovered` — checks FAIL pre, PASS post
- `unchanged_failures` — checks FAIL in both (pre-existing issue)
- `unchanged_passes_count` — PASS in both
- `overall_outcome`: `success` / `degraded` / `regressed`

### `rollback_guide`

```
rollback_guide(snapshot_id: str) -> RollbackGuide
```

Composes the recovery plan: downgrade command + state-restore steps + risk note about data migration loss.

### `regression_catalog`

```
regression_catalog(filter_version: str | None = None) -> RegressionCatalogReport
```

Returns the catalog, optionally filtered to a specific version's applicable entries.

### `list_snapshots`

```
list_snapshots() -> SnapshotListReport
```

Lists every snapshot the backend has stored.

---

## Resource surface

| URI | Returns |
|-----|---------|
| `upgrade://current` | `current_version` info |
| `upgrade://snapshots` | All stored snapshots |
| `upgrade://catalog` | Full regression catalog |

Resources are read-only and idempotent.

---

## Prompt surface

### `plan-upgrade(target_version)`

Walks the operator through current_version + available_upgrades + upgrade_guide and produces a go/no-go recommendation.

### `verify-upgrade(pre_snapshot_id)`

Walks the operator through post_upgrade_verify and produces a per-finding action list.

---

## Backend architecture

```
┌─────────────────────────────────┐
│ MCP Server (server.py)          │
└──────────────┬──────────────────┘
               │
               ▼
┌─────────────────────────────────┐
│ Analysis (analysis.py)          │
│  - build_snapshot                │
│  - build_upgrade_guide           │
│  - build_post_upgrade_report     │
│  - build_rollback_guide          │
│  - available_upgrades_report     │
└──────┬───────────────┬──────────┘
       │               │
       ▼               ▼
┌──────────┐   ┌────────────────┐
│ Backend  │   │ Catalog +      │
│  - state │   │ Checks         │
│  - snaps │   │  - 8 entries   │
└──────────┘   │  - 6 detectors │
               └────────────────┘
```

Backends produce `DeploymentState` (single-snapshot view) + persist `Snapshot` objects. Analysis runs the check registry against state, composes domain reports.

### Backend selection

Environment variable `OPENCLAW_UPGRADE_BACKEND`:

- `mock` — synthetic 2026.4.23 deployment with R-73421 active; in-memory snapshots
- `openclaw-system` — reads disk; persists snapshots as JSON files

### `openclaw-system` paths

| Env var | Default |
|---------|---------|
| `OPENCLAW_VERSION_FILE` | `~/.openclaw/version` |
| `OPENCLAW_GATEWAY_CONFIG` | `~/.openclaw/gateway.yaml` |
| `OPENCLAW_UPGRADE_SNAPSHOT_DIR` | `~/.openclaw/upgrades/snapshots/` |

---

## Regression catalog

Hand-curated, immutable. Each entry:

```python
RegressionEntry(
    regression_id="R-...",
    version_introduced="2026.4.X",
    version_fixed="2026.4.Y",  # or None
    severity=Severity.HIGH,
    title="...",
    description="...",
    detection_check_id="check.id",  # or None for advisory-only
    mitigation="...",
    field_reports=["openclaw://field-reports/..."],
)
```

v1.0 ships with 8 entries (see README). Adding entries: append to `CATALOG` in `catalog.py`; never mutate existing entries (their `regression_id` is the public key).

### Path inclusion logic

A regression is "in path" for `current → target` if:
1. Target version is in the regression's range (post-upgrade deployment affected), OR
2. Current version is in the regression's range (current deployment affected)

OpenClaw upgrades atomically — no execution on intermediate versions — so regressions strictly between current and target are NOT included. This is intentional; over-conservative inclusion makes the recommended-target heuristic useless.

---

## Detection checks

Six checks ship in v1.0:

| check_id | Detects | Severity |
|----------|---------|----------|
| `cron.web_search_returns_results` | R-41372 silent failure | HIGH |
| `resources.cpu_under_threshold` | R-63002 CPU spike | CRITICAL |
| `resources.recent_oom_count` | R-OOM-DURING-LARGE-CONTEXT | HIGH/CRITICAL by count |
| `skills.discord_receive_registered` | R-73421 Discord breakage | HIGH |
| `gateway.expected_port_listening` | R-GATEWAY-PORT-CONFLICT | MEDIUM |
| `skills.cache_validity` | R-CLAWHUB-CACHE-POISONING | HIGH |

Check status is `PASS` / `FAIL` / `UNKNOWN` (backend can't determine) / `SKIPPED` (not applicable). UNKNOWN is intentional; partial backends should not falsely PASS.

---

## Risk scoring

Not used by this server. The risk surface here is `risk_level` on individual `RegressionEntry` items (CRITICAL / HIGH / MEDIUM / LOW / INFO). The recommended-target heuristic uses CRITICAL alone as the cutoff.

---

## Security + privacy

- **Read-only.** Never modifies version files, never executes upgrade commands, never makes additional LLM calls.
- **Local-only.** mock + openclaw-system read local files only. No network calls.
- **No telemetry.** Server doesn't phone home, doesn't write usage stats, doesn't open ports.
- **Snapshots include check evidence.** Each `CheckResult` may include an `evidence` field with deployment-state snippets. If your deployment has identifying metadata (hostnames, owner emails) that flows into check outputs, those will appear in snapshot JSONs. The default checks are conservative about this; custom checks should be reviewed.

---

## Versioning + release

- Semantic versioning
- Released to PyPI as `openclaw-upgrade-orchestrator-mcp`
- Each release tagged on GitHub with changelog entry
- CI matrix: ubuntu/macos/windows × python 3.11/3.12

---

## Future scope (post v1.0)

| Idea | Trigger to build |
|------|------------------|
| Catalog auto-fetch from upstream changelog feed | OpenClaw publishes a structured changelog API |
| Multi-step upgrade pathing | Operators encounter a regression that requires intermediate stops |
| Custom catalog packs | Operator with internal-only regressions wants merge with canonical |
| Per-environment recommendation tuning | Multi-env operator needs different bars per env (prod stricter than staging) |
| Webhook emitter on detected regression | Demand from ≥3 users |
| CI-gate integration | Operator wants to block OpenClaw-version PRs without confirmation |

Out of scope (won't build): actually running upgrades, automatic rollback, sandboxed test execution. Those are separate concerns and conflict with the read-only design.

---

## v1.2+ — Provider-side regression detection (P08 fold-in)

v1.2 added a distinct surface from v1.0's user-driven upgrade-regression catalog: **silent provider-side behavior changes** with no user-side upgrade event. The Anthropic-April-23-2026 reasoning-effort downgrade case is canonical — Anthropic ran a behavior change for ~5 weeks (Mar 4 → Apr 7) before public post-mortem; user workflows had no change to point at, but median response_length dropped 56% and latency_p95 jumped 113%.

### `record_provider_call(provider, model, latency_ms, response_length_tokens, response_headers?, request_kind?)`

Caller-side recorder. Wrap LLM client calls; after each response, call `record_provider_call` with the observed latency + response-length + headers. Server persists to backend.

```
Output: {recorded: true, provider: str, model: str}
```

Returns error on `ValidationError` (bad payload), `ValueError` (malformed int), `TypeError` (bad shape).

### `get_provider_fingerprint(provider, window_hours?: int = 1)`

Aggregate the recent window of recorded calls into a fingerprint:
- median + p95 latency_ms
- median + p95 response_length_tokens
- count of calls in window

```
Output: ProviderFingerprintReport
  provider: str
  window_hours: int
  call_count: int
  fingerprint: {latency_ms_p50, latency_ms_p95, response_length_p50, response_length_p95}
  summary: str
```

### `detect_provider_regression(provider, current_window_hours?: int = 1, baseline_window_hours?: int = 168, threshold_pct?: float = 30)`

Compare a recent window's fingerprint against a longer baseline window. If any of `latency_p95` / `response_length_median` / `latency_p50` drift exceeds `threshold_pct` (default 30%), return CRITICAL with the drift details + recommended action.

```
Output: ProviderRegressionReport
  verdict: critical | warning | ok | unknown
  fingerprint_drift: {latency_p95_change_pct, response_length_median_change_pct, ...}
  baseline_window_days: float
  recent_window_hours: float
  summary: str
```

**Buyer signal:** Phoenix discussion #10442 ("Does Phoenix have a way to detect this kind of silent drift where surface metrics look healthy but the model is actually failing?") was the explicit operator ask that drove P08 promotion. Pass 5 + Pass 7 cross-validated. Phoenix is reactive (user-initiated eval); upgrade-orch v1.2 is proactive (passive provider-fingerprint detection from recorded call data).

---

## Lineage

Part of the **[AI Production Discipline Framework](https://temurah.gumroad.com/l/ai-production-discipline-framework)** ecosystem. Upgrade regression cycles are documented as **pattern P7.x — Version-Drift Production Hazard** in the framework's Production Failure Patterns Library. v1.2's provider-side detection extends coverage to **pattern P4.3 — Post-upgrade regression cascade (provider-side variant)**.

Companion servers:
- [silentwatch-mcp](https://github.com/temurkhan13/silentwatch-mcp) — cron silent-failure detection
- [openclaw-health-mcp](https://github.com/temurkhan13/openclaw-health-mcp) — deployment health
- [openclaw-cost-tracker-mcp](https://github.com/temurkhan13/openclaw-cost-tracker-mcp) — token-cost telemetry + 429 prediction (v1.1+)
- [openclaw-skill-vetter-mcp](https://github.com/temurkhan13/openclaw-skill-vetter-mcp) — skill + agent-config security vetting (v1.1+)
- [openclaw-output-vetter-mcp](https://github.com/temurkhan13/openclaw-output-vetter-mcp) — agent-claim verification + action-outcome divergence (v1.1+ / v1.2+)
- [bash-vet-mcp](https://github.com/temurkhan13/bash-vet-mcp) — LLM-emitted shell-command vetter

For audit consulting that applies the framework to your specific system: **temur@pixelette.tech**, subject `AI audit inquiry`.
