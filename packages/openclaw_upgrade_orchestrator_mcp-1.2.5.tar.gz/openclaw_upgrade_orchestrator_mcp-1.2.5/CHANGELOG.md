# Changelog

All notable changes to `openclaw-upgrade-orchestrator-mcp` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [1.2.5] — 2026-05-08

### Added — `openclaw-upgrade-orchestrator-mcp-demo` console script (V1 of cross-product UX retrofit)

A new console script that walks through the upgrade-orchestrator's analyses against the bundled mock backend in ~30 seconds. The mock simulates a deployment at OpenClaw 2026.4.23 — a version known to be hit by the Discord-receive regression (R-73421).

The demo runs five sequential analyses:

1. Current version detection
2. Available upgrades + recommended target (heuristically skips versions with known critical regressions)
3. Regression catalog filtered to current version
4. Upgrade guide for the recommended target (pre/upgrade/post/rollback steps)
5. Pre-upgrade snapshot showing which checks would pass/fail

**Usage:**

```
$ pip install openclaw-upgrade-orchestrator-mcp
$ openclaw-upgrade-orchestrator-mcp-demo
openclaw-upgrade-orchestrator-mcp v1.2.5 · synthetic demo

  1. Current deployment state
    version: 2026.4.23

  2. Available upgrades
    recommended: 2026.5.2
    total available: 7

  3. Regressions affecting 2026.4.23
    [HIGH] R-73421-DISCORD-RECEIVE-BREAKAGE: Discord-receive callbacks not firing
       mitigation: Upgrade to 2026.4.27+ where the registration sequence is fixed.

  4. Upgrade guide · 2026.4.23 → 2026.5.2
    steps: 2 pre · 3 upgrade · 3 post · 4 rollback
       $ openclaw gateway stop
       $ openclaw upgrade --to 2026.5.2
       $ openclaw gateway start

  5. Pre-upgrade snapshot
    results: 5 pass · 1 fail
    [HIGH] skills.discord_receive_registered: Discord skill on_message hook NOT registered
```

**No external I/O.** Demo runs against the in-memory mock backend; no network, no API keys, no system inspection. Read-only — never executes any upgrade.

Adds a second console-script entry (`openclaw-upgrade-orchestrator-mcp-demo`) alongside the existing MCP server entry.

## [1.2.4] — 2026-05-08

### Added — first-run startup banner (visibility-after-install fix, V2 of cross-product UX retrofit)

When the server starts via `python -m openclaw_upgrade_orchestrator_mcp` or the console script, the first stderr line is now a one-line value-prove receipt:

```
openclaw-upgrade-orchestrator-mcp v1.2.4 ready · pre-upgrade safety: known-regression catalog + pre/post snapshots + rollback guides · read-only (never executes upgrade) · backend=mock
```

Before v1.2.4 the server started silently — operators who'd just `pip install`ed had no immediate signal of what the server actually does. The banner is the first-30-seconds value moment that was previously missing.

**Suppressible:** set `OPENCLAW_UPGRADE_QUIET=1` (or `true` / `yes`) to skip the banner.

**No protocol behavior changed.** Banner is stderr-only; stdout (the MCP JSON-RPC channel) is untouched. Pure observability addition.

## [1.2.3] — 2026-05-06

### Added — `build_server` top-level export + ergonomics

- [`5c6ba98`](https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp/commit/5c6ba98) **feat:** `build_server` is now exported from the package top level. Cross-MCP integration tests + downstream importers can now `from openclaw_upgrade_orchestrator_mcp import build_server` instead of reaching into the `.server` submodule. Also includes 9 server-protocol coverage tests added at the same time, raising `server.py` coverage 78% → 87%. No production-behavior change — pure re-export plumbing + tests.

### Changed — overnight Phase 2B docs refresh

- [`bc2aaec`](https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp/commit/bc2aaec) **docs:** SPEC.md refresh covering the v1.2 provider-side regression detection fold-in (`record_provider_call` / `get_provider_fingerprint` / `detect_provider_regression` tool specs). Pre-existing SPEC was at v1.0-era surface; now matches what's shipped.

No detection-rule or scanner changes. Patch bump republishes to PyPI so the SPEC text matches the rendered "Project description" page and the importer-ergonomics fix is available to downstream packagers.

## [1.2.2] — 2026-05-05

### Changed — Pass 5 X/Twitter citation added: active-extraction technique
- README v1.2 section now cites [Om Patel @om_patel5 on X (171K views, 1.3K likes, 195 RTs)](https://x.com/om_patel5/status/2044): *"OPUS 4.6 JUST ADMITTED ITS REASONING EFFORT IS SET TO 25 OUT OF 100"* — operator extracted the current model setting directly. **Methodologically distinct from passive latency/header fingerprinting.** Queues v1.3 backlog idea: scheduled active-extraction probes ("what is your current reasoning_effort?") + record the model's self-reported settings over time. Pure README refresh — no code changes.

## [1.2.1] — 2026-05-05

### Changed — cross-link mesh extension to 6th MCP
- README "Related" section updated to reference [openclaw-output-vetter-mcp](https://github.com/temurkhan13/openclaw-output-vetter-mcp) (v1.0.1, shipped 2026-05-04). Bundle reference updated to "5 others / 6-pack". Pure metadata refresh — no code changes.

## [1.2.0] — 2026-05-04

### Added — provider-side regression detection (P08 fold-in)

The orchestrator now detects regressions on **both** sides of the upgrade boundary: the existing v1.0 regression-catalog + pre/post-snapshot-diff feature handles **user-driven upgrade events** (you upgraded openclaw 4.23 → 4.26, here's what broke); the v1.2 fingerprint feature handles **provider-side silent changes** (Anthropic/OpenAI changed something on their end without you upgrading anything). This was filed as P08 in the venture Pipeline (see vault `Pipeline/opportunities.md`) — sourced from the [Anthropic April 23 2026 post-mortem](https://www.anthropic.com/engineering/april-23-postmortem) where Anthropic admitted silently changing Claude Code's default reasoning effort for 5 weeks (Mar 4 → Apr 7), and from [Phoenix discussion #10442](https://github.com/Arize-ai/phoenix/discussions/10442) where a Phoenix user explicitly asked for *"a way to detect this kind of silent drift where surface metrics look healthy but the model is actually failing."* Incumbent validation against Phoenix / Langfuse / Galileo confirmed they're reactive (user-initiated eval-set replay), not proactive (passive provider-fingerprint detection on every production call) — folded into this server as v1.2.

- **`ProviderCallRecord` data model** — captured-at + provider + model + latency_ms + response_length_tokens + raw response_headers + optional request_kind. One per provider response. Recorded by a small shim in your LLM client.
- **`record_provider_call()` + `get_provider_calls()` backend methods** — added to `UpgradeBackend` ABC with default no-op (graceful degrade for v1.0 backends). Implemented on `mock` (in-memory list + synthetic 7d-baseline + last-hour-regression-burst seed for demo) and `openclaw-system` (append-only `~/.openclaw/upgrades/provider-calls.jsonl`, configurable via `OPENCLAW_PROVIDER_CALLS_FILE`).
- **3 new tools**:
  - `record_provider_call` — append a call observation. Wire in your LLM client.
  - `get_provider_fingerprint` — aggregate fingerprint over a recent window: call count, latency p50/p95, response-length distribution, distinct models, most-common headers.
  - `detect_provider_regression` — diff current window vs baseline window; emit per-metric alerts (latency_p95, latency_median, response_length_median, model_version, distinct_models). Severity: ≥100% delta CRITICAL, ≥50% HIGH, ≥30% MEDIUM, ≥15% LOW; categorical metrics (model-version drift) emit HIGH alerts.
- **1 new resource** — `upgrade://provider-fingerprint` (current Anthropic 1-hour fingerprint).
- **1 new prompt** — `diagnose-provider-regression` walks all 3 fingerprint tools and asks for one specific corrective action (open a provider support ticket, switch fallback model, or accept).
- **Mock data extended** — 1000-record synthetic 7-day baseline at median latency 800ms + 50-record last-hour burst at median latency 1500ms. `detect_provider_regression` returns CRITICAL out of the box on mock.
- 13 new tests (108 total, was 95) — analysis layer + protocol wiring + end-to-end mock regression detection.

### Changed
- `pyproject.toml` description updated to lead with both regression vectors (user-driven + provider-side).
- `pyproject.toml` keywords expanded with `anthropic`, `openai`, `provider-regression`, `model-drift`, `fingerprint`.
- `server.json` description updated for MCP Registry; trimmed to ≤100 chars per validator.

### Skipped — version 1.1.0
1.1.0 was reserved for an `openclaw` backend in the original v1.0 roadmap. That backend has been split between `openclaw-system` (already shipped in v1.0) and the v1.2 provider-fingerprint feature. No 1.1.0 release was published to PyPI.

## [1.0.1] — 2026-05-04

### Changed — README v2 metadata refresh (PyPI republish)
- README repositioned with universal-first lede + "claw tax" citations (commits `fe6dc91` + `24d592c`). Patch bump republishes the new description + keyword field to PyPI. No code changes.
- README "What it does" now leads with the OpenClaw creator suspension (the "claw tax" framing) plus specific regression versions, GitHub Issues #23751 + #35296, and the HERMES.md upgrade-regression pattern.
- pyproject.toml description tightened toward universal AI runtime upgrade safety; OpenClaw catalog is now framed as one shipped reference catalog with "bring your own catalog" support for other runtimes.

## [1.0.0] — 2026-05-04

### Added
- Initial release with MCP protocol wiring + two production-ready backends.
- 8 tools: `current_version` + `available_upgrades` + `pre_upgrade_snapshot` + `upgrade_guide` + `post_upgrade_verify` + `rollback_guide` + `regression_catalog` + `list_snapshots`.
- 3 resources: `upgrade://current`, `upgrade://snapshots`, `upgrade://catalog`.
- 2 prompts: `plan-upgrade`, `verify-upgrade`.
- **`mock` backend** — synthetic 2026.4.23 deployment with active R-73421 Discord-receive breakage; 7 available newer versions; in-memory snapshot store. `_simulate_upgrade(target)` test-helper for E2E pre/post flows.
- **`openclaw-system` backend** — reads `~/.openclaw/version` (override `OPENCLAW_VERSION_FILE`) + `~/.openclaw/gateway.yaml` (override `OPENCLAW_GATEWAY_CONFIG`); persists snapshots as JSON files in `~/.openclaw/upgrades/snapshots/` (override `OPENCLAW_UPGRADE_SNAPSHOT_DIR`). Tolerates missing version file (returns version='unknown'); skips malformed snapshot files on list.
- **Hand-curated regression catalog** — 8 entries covering documented OpenClaw regressions: R-41372 (cron web-search silent fail), R-63002 (post-upgrade CPU spike, CRITICAL), R-73421 (Discord-receive breakage), R-GATEWAY-PORT-CONFLICT, R-OOM-DURING-LARGE-CONTEXT (unfixed), R-STATUS-RECONCILIATION-DRIFT, R-CLAWHUB-CACHE-POISONING, R-LOG-ROTATION-DROP (unfixed). Each entry has stable `regression_id`, version range, severity, mitigation text, and field-report links where public.
- **6 detection checks** — cron web-search results, CPU under threshold, recent OOM count, Discord receive registered, gateway port listening, skill cache validity. Each maps to one or more catalog entries via `detection_check_id`. Returns PASS / FAIL / UNKNOWN / SKIPPED for partial-data backends.
- **Risk-aware recommendation logic** — `available_upgrades` flags any version with a CRITICAL regression in path; `recommended_target` is the highest version with zero CRITICAL regressions. Path inclusion considers target + current ranges; intermediate versions excluded since OpenClaw upgrades atomically.
- **Pre/post snapshot diffing** — `post_upgrade_verify` classifies each check as `new_failure` / `recovered` / `unchanged_fail` / `unchanged_pass` and computes overall outcome (`success` / `degraded` / `regressed`).
- **Step-by-step upgrade guides** — `upgrade_guide` composes pre-upgrade, upgrade, post-upgrade, and rollback step lists. Includes shell commands where applicable + a confidence note tied to the regression severity profile of the path.
- **Calendar-version-aware version arithmetic** — robust comparison of `YYYY.M.D` and `YYYY.M.D.HOTFIX` strings; non-numeric chunks sort before numeric (so `1.2.3-rc1` is older than `1.2.3`).
- **GitHub Actions CI** — matrix testing on ubuntu/macos/windows × Python 3.11/3.12 + ruff + mypy strict-mode lint job.
- **GitHub Actions release workflow** — fires on `v*` tag push, verifies tag matches `pyproject.toml` version, builds + publishes to PyPI via Trusted Publishing.
- **`server.json`** for the official Model Context Protocol Registry submission.
- 95 tests across `test_server.py` (18 — protocol wiring, registration, dispatch correctness for all 8 tools), `test_catalog.py` (15 — version arithmetic + range membership + path inclusion edge cases), `test_checks.py` (20 — every check at PASS / FAIL / UNKNOWN / threshold boundaries), `test_analysis.py` (27 — risk-aware recommendation, snapshot building, post-upgrade diffing, end-to-end pre/post simulation with mock), `test_backends.py` (15 — mock isolation + system-backend disk persistence + malformed-file tolerance + env-var overrides).

[Unreleased]: https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp/compare/v1.2.3...HEAD
[1.2.3]: https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp/compare/v1.2.2...v1.2.3
[1.2.2]: https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp/compare/v1.2.1...v1.2.2
[1.2.1]: https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp/compare/v1.2.0...v1.2.1
[1.2.0]: https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp/compare/v1.0.1...v1.2.0
[1.0.1]: https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp/releases/tag/v1.0.0
