"""CLI entry point — run via `python -m openclaw_upgrade_orchestrator_mcp` or the console script."""
from __future__ import annotations

import asyncio
import os
import sys
from contextlib import suppress

from mcp.server.stdio import stdio_server

from openclaw_upgrade_orchestrator_mcp import __version__
from openclaw_upgrade_orchestrator_mcp.server import build_server


def _emit_startup_banner(backend: str) -> None:
    """Print a one-line value-prove banner to stderr at startup.

    Goes to stderr (stdout is reserved for MCP JSON-RPC protocol traffic).
    Suppressible via `OPENCLAW_UPGRADE_QUIET=1` for users who pipe stderr to a log file.
    """
    if os.environ.get("OPENCLAW_UPGRADE_QUIET", "").strip() in {"1", "true", "yes"}:
        return
    banner = (
        f"openclaw-upgrade-orchestrator-mcp v{__version__} ready · "
        f"pre-upgrade safety: known-regression catalog + pre/post snapshots + rollback guides · "
        f"read-only (never executes upgrade) · "
        f"backend={backend}"
    )
    print(banner, file=sys.stderr, flush=True)


def main() -> None:
    """Boot the MCP server over stdio transport.

    Backend is selected via `OPENCLAW_UPGRADE_BACKEND` (default: `mock`).
    Snapshot directory comes from `OPENCLAW_UPGRADE_SNAPSHOT_DIR`
    (default: `~/.openclaw/upgrades/snapshots/`).
    """
    backend = os.environ.get("OPENCLAW_UPGRADE_BACKEND", "mock")
    _emit_startup_banner(backend)

    async def _run() -> None:
        server = build_server(backend_name=backend)
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    with suppress(KeyboardInterrupt):
        asyncio.run(_run())


if __name__ == "__main__":
    main()
    sys.exit(0)
