"""Mock backend — synthetic deployment state + in-memory snapshot store.

Currently configured to return a 2026.4.23 deployment with a Discord-receive
breakage condition active, suitable for demoing `pre_upgrade_snapshot` +
`upgrade_guide` + `post_upgrade_verify`.

Snapshot store is in-memory and process-lived. For persistent demos use the
openclaw-system backend with a dedicated `OPENCLAW_UPGRADE_SNAPSHOT_DIR`.

v1.2 — Mock also pre-populates a ProviderCallRecord history that demonstrates
a provider-side regression (Anthropic latency p95 doubled in last hour vs
prior 7-day baseline) so `detect_provider_regression` returns CRITICAL on
mock data. Pattern source: Anthropic April 23 2026 post-mortem.
"""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

from openclaw_upgrade_orchestrator_mcp.backends.base import (
    DeploymentState,
    UpgradeBackend,
)
from openclaw_upgrade_orchestrator_mcp.types import ProviderCallRecord, Snapshot

_DEFAULT_VERSION = "2026.4.23"
_AVAILABLE_VERSIONS = [
    "2026.4.24",
    "2026.4.25",
    "2026.4.26",
    "2026.4.27",
    "2026.4.30",
    "2026.5.1",
    "2026.5.2",
]


def _build_provider_history() -> list[ProviderCallRecord]:
    """7-day baseline + last-hour regression burst on Anthropic.

    Baseline: ~1000 calls over 7 days, median latency 800ms, p95 1500ms.
    Last hour: ~50 calls at median latency 1500ms, p95 3200ms — a clear
    distribution shift `detect_provider_regression` flags as CRITICAL.
    Pattern source: the April 23 2026 reasoning-effort downgrade story.
    """
    now = datetime.now(UTC)
    out: list[ProviderCallRecord] = []

    # 7-day baseline (1 call ≈ every 10 min for last 7 days = ~1000 calls)
    # Stable median ~800ms, p95 ~1500ms.
    for i in range(1000):
        minutes_ago = 60 + i * 10  # span 60min..10060min ago = 1hr to ~7 days
        latency = 600 + (i * 13 % 1200)  # 600..1800ms range, deterministic seed
        out.append(
            ProviderCallRecord(
                captured_at=now - timedelta(minutes=minutes_ago),
                provider="anthropic",
                model="claude-sonnet-4-7",
                latency_ms=latency,
                response_length_tokens=400 + (i * 7 % 800),  # 400..1200 tokens
                response_headers={
                    "anthropic-organization-id": "org-baseline",
                    "anthropic-model-version": "claude-sonnet-4-7-20260301",
                },
                request_kind="agent",
            )
        )

    # Last-hour regression burst: ~50 calls, much higher latency
    for i in range(50):
        seconds_ago = 60 + i * 60  # within the last hour
        latency = 1200 + (i * 31 % 2400)  # 1200..3600ms range
        out.append(
            ProviderCallRecord(
                captured_at=now - timedelta(seconds=seconds_ago),
                provider="anthropic",
                model="claude-sonnet-4-7",
                latency_ms=latency,
                response_length_tokens=200 + (i * 5 % 400),  # 200..600 tokens — also dropped
                response_headers={
                    "anthropic-organization-id": "org-baseline",
                    "anthropic-model-version": "claude-sonnet-4-7-20260301",
                },
                request_kind="agent",
            )
        )

    return out


class MockBackend(UpgradeBackend):
    """Returns synthetic but realistic state; stores snapshots in-memory."""

    name = "mock"

    def __init__(self) -> None:
        self._snapshots: dict[str, Snapshot] = {}
        self._current_version = _DEFAULT_VERSION
        # User-recorded calls (via record_provider_call). Synthetic baseline
        # + regression burst is rebuilt fresh on each get_provider_calls call
        # so timestamps stay relative-to-now.
        self._user_provider_calls: list[ProviderCallRecord] = []

    async def collect_state(self) -> DeploymentState:
        # The mock state simulates a deployment that's been hit by the
        # Discord-receive regression (R-73421). Cron + skill-cache + CPU look fine.
        is_in_discord_breakage_range = self._current_version in {
            "2026.4.23",
            "2026.4.24",
            "2026.4.25",
            "2026.4.26",
        }
        return DeploymentState(
            current_version=self._current_version,
            available_versions=_AVAILABLE_VERSIONS,
            listening_ports=[18789, 18790],
            expected_gateway_port=18789,
            cpu_max_pct_15min=23.5,
            recent_oom_count_24h=0,
            skill_count=18,
            skill_cache_valid=True,
            discord_skill_receive_registered=not is_in_discord_breakage_range,
            cron_web_search_returns_results=True,
        )

    async def save_snapshot(self, snapshot: Snapshot) -> None:
        self._snapshots[snapshot.snapshot_id] = snapshot

    async def load_snapshot(self, snapshot_id: str) -> Snapshot | None:
        return self._snapshots.get(snapshot_id)

    async def list_snapshots(self) -> list[Snapshot]:
        return sorted(self._snapshots.values(), key=lambda s: s.captured_at, reverse=True)

    # ─────────── Provider-fingerprint (v1.2) ───────────

    async def record_provider_call(self, record: ProviderCallRecord) -> None:
        self._user_provider_calls.append(record)

    async def get_provider_calls(
        self,
        provider: str | None = None,
        since: datetime | None = None,
        limit: int = 10_000,
    ) -> list[ProviderCallRecord]:
        # Rebuild the synthetic seed history each call so timestamps stay
        # relative-to-now. Merge with any user-recorded calls.
        all_records = _build_provider_history() + self._user_provider_calls
        out: list[ProviderCallRecord] = []
        for r in sorted(all_records, key=lambda r: r.captured_at, reverse=True):
            if provider is not None and r.provider != provider:
                continue
            if since is not None and r.captured_at < since:
                continue
            out.append(r)
            if len(out) >= limit:
                break
        return out

    # Test-only helper: simulate the deployment having been upgraded.
    def _simulate_upgrade(self, target_version: str) -> None:
        self._current_version = target_version
