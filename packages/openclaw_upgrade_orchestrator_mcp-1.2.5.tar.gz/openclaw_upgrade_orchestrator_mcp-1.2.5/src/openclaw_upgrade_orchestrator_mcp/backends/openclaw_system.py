"""OpenClaw-system backend — reads version from disk, persists snapshots as JSON.

Reads:
  - `~/.openclaw/version` — single-line current version string
  - `~/.openclaw/gateway.yaml` — gateway port + skill count (best-effort YAML parse)
  - `~/.openclaw/upgrades/snapshots/*.json` — saved Snapshot objects
  - `~/.openclaw/upgrades/provider-calls.jsonl` — provider-call history (v1.2)

State fields not derivable from disk default to None (checks see UNKNOWN).
The MCP is read-only-static-advisor by design — runtime metrics like CPU %
or OOM count are populated by an integration layer, not by us probing /proc.

Override locations:
  - `OPENCLAW_VERSION_FILE` (default: `~/.openclaw/version`)
  - `OPENCLAW_GATEWAY_CONFIG` (default: `~/.openclaw/gateway.yaml`)
  - `OPENCLAW_UPGRADE_SNAPSHOT_DIR` (default: `~/.openclaw/upgrades/snapshots/`)
  - `OPENCLAW_PROVIDER_CALLS_FILE` (default: `~/.openclaw/upgrades/provider-calls.jsonl`, v1.2)
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from openclaw_upgrade_orchestrator_mcp.backends.base import (
    DeploymentState,
    UpgradeBackend,
)
from openclaw_upgrade_orchestrator_mcp.types import ProviderCallRecord, Snapshot

logger = logging.getLogger(__name__)

_DEFAULT_VERSION_FILE = "~/.openclaw/version"
_DEFAULT_GATEWAY_CONFIG = "~/.openclaw/gateway.yaml"
_DEFAULT_SNAPSHOT_DIR = "~/.openclaw/upgrades/snapshots/"
_DEFAULT_PROVIDER_CALLS_FILE = "~/.openclaw/upgrades/provider-calls.jsonl"


class OpenClawSystemBackend(UpgradeBackend):
    """Disk-backed: reads version + gateway config; persists snapshots as JSON."""

    name = "openclaw-system"

    def __init__(self) -> None:
        version_raw = os.environ.get("OPENCLAW_VERSION_FILE", _DEFAULT_VERSION_FILE)
        gateway_raw = os.environ.get("OPENCLAW_GATEWAY_CONFIG", _DEFAULT_GATEWAY_CONFIG)
        snap_raw = os.environ.get("OPENCLAW_UPGRADE_SNAPSHOT_DIR", _DEFAULT_SNAPSHOT_DIR)
        provider_calls_raw = os.environ.get(
            "OPENCLAW_PROVIDER_CALLS_FILE", _DEFAULT_PROVIDER_CALLS_FILE
        )
        self._version_file = Path(os.path.expanduser(version_raw))
        self._gateway_config = Path(os.path.expanduser(gateway_raw))
        self._snapshot_dir = Path(os.path.expanduser(snap_raw))
        self._provider_calls_file = Path(os.path.expanduser(provider_calls_raw))

    async def collect_state(self) -> DeploymentState:
        version = self._read_version()
        gateway_port = self._read_gateway_port()
        return DeploymentState(
            current_version=version or "unknown",
            available_versions=[],  # Disk backend doesn't query a registry; populated upstream
            listening_ports=[],
            expected_gateway_port=gateway_port,
            cpu_max_pct_15min=None,
            recent_oom_count_24h=None,
            skill_count=None,
            skill_cache_valid=None,
            discord_skill_receive_registered=None,
            cron_web_search_returns_results=None,
        )

    def _read_version(self) -> str | None:
        if not self._version_file.exists():
            return None
        try:
            return self._version_file.read_text(encoding="utf-8").strip() or None
        except OSError as exc:
            logger.warning("Could not read version file %s: %s", self._version_file, exc)
            return None

    def _read_gateway_port(self) -> int | None:
        if not self._gateway_config.exists():
            return 18789  # Documented OpenClaw default
        try:
            text = self._gateway_config.read_text(encoding="utf-8")
        except OSError:
            return 18789
        # Cheap line-by-line parse to avoid taking a yaml dep on this MCP
        for raw in text.splitlines():
            line = raw.strip()
            if line.startswith("port:"):
                value = line.split(":", 1)[1].strip()
                try:
                    return int(value)
                except ValueError:
                    return 18789
        return 18789

    async def save_snapshot(self, snapshot: Snapshot) -> None:
        self._snapshot_dir.mkdir(parents=True, exist_ok=True)
        path = self._snapshot_dir / f"{snapshot.snapshot_id}.json"
        path.write_text(snapshot.model_dump_json(indent=2), encoding="utf-8")

    async def load_snapshot(self, snapshot_id: str) -> Snapshot | None:
        path = self._snapshot_dir / f"{snapshot_id}.json"
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return Snapshot.model_validate(data)
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            logger.warning("Could not load snapshot %s: %s", path, exc)
            return None

    async def list_snapshots(self) -> list[Snapshot]:
        if not self._snapshot_dir.exists():
            return []
        out: list[Snapshot] = []
        for path in sorted(self._snapshot_dir.glob("*.json")):
            try:
                data: Any = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    out.append(Snapshot.model_validate(data))
            except (OSError, json.JSONDecodeError, ValueError) as exc:
                logger.warning("Skipping unreadable snapshot %s: %s", path, exc)
                continue
        out.sort(key=lambda s: s.captured_at, reverse=True)
        return out

    # ─────────── Provider-fingerprint (v1.2) ───────────

    async def record_provider_call(self, record: ProviderCallRecord) -> None:
        """Append a JSON-line to the provider-calls JSONL file."""
        self._provider_calls_file.parent.mkdir(parents=True, exist_ok=True)
        with self._provider_calls_file.open("a", encoding="utf-8") as f:
            f.write(record.model_dump_json() + "\n")

    async def get_provider_calls(
        self,
        provider: str | None = None,
        since: datetime | None = None,
        limit: int = 10_000,
    ) -> list[ProviderCallRecord]:
        if not self._provider_calls_file.exists():
            return []
        out: list[ProviderCallRecord] = []
        try:
            with self._provider_calls_file.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError as exc:
                        logger.warning("Skipping malformed provider-call record: %s", exc)
                        continue
                    if not isinstance(data, dict):
                        continue
                    try:
                        record = ProviderCallRecord.model_validate(data)
                    except ValueError as exc:
                        logger.warning("Skipping invalid provider-call record: %s", exc)
                        continue
                    if provider is not None and record.provider != provider:
                        continue
                    if since is not None and record.captured_at < since:
                        continue
                    out.append(record)
        except OSError as exc:
            logger.warning("Could not read provider-calls file %s: %s", self._provider_calls_file, exc)
            return []
        # Newest first; cap at limit
        out.sort(key=lambda r: r.captured_at, reverse=True)
        return out[:limit]
