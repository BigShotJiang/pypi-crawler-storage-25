"""Backend registry — pluggable deployment-state + snapshot sources."""
from __future__ import annotations

from openclaw_upgrade_orchestrator_mcp.backends.base import (
    DeploymentState,
    UpgradeBackend,
)
from openclaw_upgrade_orchestrator_mcp.backends.mock import MockBackend
from openclaw_upgrade_orchestrator_mcp.backends.openclaw_system import (
    OpenClawSystemBackend,
)

_REGISTRY: dict[str, type[UpgradeBackend]] = {
    "mock": MockBackend,
    "openclaw-system": OpenClawSystemBackend,
}


def available_backends() -> list[str]:
    return list(_REGISTRY.keys())


def get_backend(name: str) -> UpgradeBackend:
    if name not in _REGISTRY:
        raise KeyError(
            f"Unknown upgrade-orchestrator backend {name!r}; available: {available_backends()}"
        )
    return _REGISTRY[name]()


__all__ = [
    "DeploymentState",
    "UpgradeBackend",
    "available_backends",
    "get_backend",
]
