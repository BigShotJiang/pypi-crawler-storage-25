"""Backend ABC + DeploymentState shape.

A backend has three concerns:
  1. Collect a DeploymentState snapshot (the data checks consume)
  2. Persist + load Snapshot objects across calls
  3. Append + read ProviderCallRecord history (v1.2 — provider-fingerprint feature)

All three concerns are encapsulated; see `mock.py` for an in-memory impl
and `openclaw_system.py` for a JSON-on-disk impl. Concern #3 has a default
no-op implementation on this ABC so backends opt-in by overriding.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from openclaw_upgrade_orchestrator_mcp.types import ProviderCallRecord, Snapshot


class DeploymentState(BaseModel):
    """Single-snapshot view of an OpenClaw deployment.

    Each field is read by zero or more checks. Backends fill what they can
    from real sources; unknown fields default to None (checks see UNKNOWN).
    """

    model_config = ConfigDict(frozen=True)

    current_version: str
    """Currently-installed OpenClaw version, e.g., `2026.4.26`."""
    available_versions: list[str] = Field(default_factory=list)
    """Newer versions known to exist (sorted ascending)."""
    listening_ports: list[int] = Field(default_factory=list)
    """TCP ports the gateway/services are listening on."""
    expected_gateway_port: int | None = 18789
    """Configured gateway port (from gateway.yaml or default)."""
    cpu_max_pct_15min: float | None = None
    """Max CPU% over the last 15 minutes."""
    recent_oom_count_24h: int | None = None
    """OOM-kill events in the last 24h (from kernel logs / journalctl)."""
    skill_count: int | None = None
    """Number of installed ClawHub skills."""
    skill_cache_valid: bool | None = None
    """Whether the skill cache parsed cleanly (no 502-poisoning)."""
    discord_skill_receive_registered: bool | None = None
    """Whether the discord skill's on_message hook is registered (None if skill not installed)."""
    cron_web_search_returns_results: bool | None = None
    """Whether the most recent --session cron with web-search returned results (None if no such job)."""


class UpgradeBackend(ABC):
    """Abstract base for any upgrade-state + snapshot source."""

    name: str = "base"

    @abstractmethod
    async def collect_state(self) -> DeploymentState:
        """Snapshot the deployment for the checks to consume."""

    @abstractmethod
    async def save_snapshot(self, snapshot: Snapshot) -> None:
        """Persist a Snapshot. Idempotent on snapshot_id."""

    @abstractmethod
    async def load_snapshot(self, snapshot_id: str) -> Snapshot | None:
        """Load a Snapshot by id, or None if not found."""

    @abstractmethod
    async def list_snapshots(self) -> list[Snapshot]:
        """Every snapshot the backend has stored. Sorted captured_at desc."""

    # ─────────── Provider-fingerprint (v1.2) ───────────
    # Default no-ops let v1.0 backends keep working without code changes.
    # Backends with persistence override these to enable the feature.

    async def record_provider_call(self, record: ProviderCallRecord) -> None:
        """Append a provider call observation. v1.2 default: no-op (in-memory backends opt out)."""
        return

    async def get_provider_calls(
        self,
        provider: str | None = None,
        since: datetime | None = None,
        limit: int = 10_000,
    ) -> list[ProviderCallRecord]:
        """Return historical provider call records, sorted captured_at desc.

        - `provider`: filter to one provider (None = all)
        - `since`: lower bound (None = no lower bound)
        - `limit`: max records to return

        v1.2 default: empty list (backends without persistence opt out).
        """
        return []
