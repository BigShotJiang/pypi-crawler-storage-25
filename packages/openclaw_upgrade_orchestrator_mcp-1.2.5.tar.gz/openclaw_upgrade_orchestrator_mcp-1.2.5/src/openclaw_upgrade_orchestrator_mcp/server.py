"""MCP server — registers tools, resources, prompts; delegates to backends + analysis."""
from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from typing import Any

from mcp.server import Server
from mcp.types import (
    GetPromptResult,
    Prompt,
    PromptArgument,
    PromptMessage,
    Resource,
    TextContent,
    Tool,
)
from pydantic import AnyUrl, ValidationError

from openclaw_upgrade_orchestrator_mcp.analysis import (
    available_upgrades_report,
    build_post_upgrade_report,
    build_provider_fingerprint_report,
    build_provider_regression_report,
    build_rollback_guide,
    build_snapshot,
    build_upgrade_guide,
    current_version_info,
    regression_catalog_report,
    snapshot_list_report,
)
from openclaw_upgrade_orchestrator_mcp.backends import get_backend
from openclaw_upgrade_orchestrator_mcp.backends.base import UpgradeBackend
from openclaw_upgrade_orchestrator_mcp.types import ProviderCallRecord

logger = logging.getLogger(__name__)

SERVER_NAME = "openclaw-upgrade-orchestrator"


def build_server(backend_name: str = "mock") -> Server:
    backend: UpgradeBackend = get_backend(backend_name)
    server: Server = Server(SERVER_NAME)

    # ─────────────────────────── Tools ───────────────────────────

    @server.list_tools()  # type: ignore[no-untyped-call, untyped-decorator]
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="current_version",
                description=(
                    "Return the currently-installed OpenClaw version + how it was detected. "
                    "Run this first to confirm the backend can read your deployment."
                ),
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            Tool(
                name="available_upgrades",
                description=(
                    "List newer-than-current versions, flag any that carry CRITICAL "
                    "regressions, and recommend the highest version with no CRITICAL "
                    "regressions in its upgrade path."
                ),
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            Tool(
                name="pre_upgrade_snapshot",
                description=(
                    "Run every detection check against the live deployment and persist "
                    "the result as a Snapshot. Returns the snapshot_id you'll feed to "
                    "post_upgrade_verify and rollback_guide."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "target_version": {
                            "type": "string",
                            "description": "Optional — version you intend to upgrade to (stored in snapshot)",
                        },
                    },
                    "required": [],
                },
            ),
            Tool(
                name="upgrade_guide",
                description=(
                    "Compose the step-by-step upgrade plan from current → target. "
                    "Includes pre-upgrade prep steps, the upgrade itself, post-upgrade "
                    "verification, rollback steps, and any applicable known regressions "
                    "with their mitigations."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "target_version": {
                            "type": "string",
                            "description": "Target version, e.g. '2026.4.27'",
                        },
                    },
                    "required": ["target_version"],
                },
            ),
            Tool(
                name="post_upgrade_verify",
                description=(
                    "Take a fresh post-upgrade snapshot and diff against a stored "
                    "pre-upgrade snapshot. Surfaces new_failures (most important), "
                    "recovered checks, and unchanged failures. Outcome is one of "
                    "'success' / 'degraded' / 'regressed'."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pre_snapshot_id": {
                            "type": "string",
                            "description": "The snapshot_id returned by pre_upgrade_snapshot",
                        },
                    },
                    "required": ["pre_snapshot_id"],
                },
            ),
            Tool(
                name="rollback_guide",
                description=(
                    "Compose the rollback plan for a given pre-upgrade snapshot — "
                    "downgrade command + state-restore steps + risk notes about "
                    "data migration loss."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "snapshot_id": {
                            "type": "string",
                            "description": "Pre-upgrade snapshot to roll back to",
                        },
                    },
                    "required": ["snapshot_id"],
                },
            ),
            Tool(
                name="regression_catalog",
                description=(
                    "Return every known regression in the catalog, optionally filtered "
                    "to a specific version. Each entry has id + version range + severity "
                    "+ description + mitigation + linked field reports."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "filter_version": {
                            "type": "string",
                            "description": "Optional — only return regressions affecting this version",
                        },
                    },
                    "required": [],
                },
            ),
            Tool(
                name="list_snapshots",
                description="List all stored snapshots (id, captured_at, version, summary).",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            Tool(
                name="record_provider_call",
                description=(
                    "Append a single provider API call observation to the fingerprint "
                    "history (v1.2). Wire your LLM client's response into this tool to "
                    "populate the baseline that `detect_provider_regression` compares "
                    "against. One MCP call per provider response. Required: provider, "
                    "model, latency_ms, response_length_tokens. Headers + request_kind "
                    "are optional but improve fingerprint sharpness."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "provider": {
                            "type": "string",
                            "description": "anthropic | openai | gemini | ollama | bedrock | other",
                        },
                        "model": {
                            "type": "string",
                            "description": "Provider-reported model identifier, e.g. claude-sonnet-4-7",
                        },
                        "latency_ms": {
                            "type": "integer",
                            "description": "End-to-end response latency in milliseconds",
                        },
                        "response_length_tokens": {
                            "type": "integer",
                            "description": "Output token count",
                        },
                        "response_headers": {
                            "type": "object",
                            "description": (
                                "Raw response headers (model-version, anthropic-ratelimit-*, etc.). "
                                "Optional but recommended for model_version drift detection"
                            ),
                            "additionalProperties": {"type": "string"},
                        },
                        "request_kind": {
                            "type": "string",
                            "description": "Optional grouping label (extraction / chat / agent-loop)",
                        },
                    },
                    "required": ["provider", "model", "latency_ms", "response_length_tokens"],
                },
            ),
            Tool(
                name="get_provider_fingerprint",
                description=(
                    "Aggregate fingerprint over a recent window — call count, "
                    "latency median + p95, response-length distribution, distinct "
                    "models, most-common headers (v1.2). Use to inspect what the "
                    "current production-call distribution looks like."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "provider": {
                            "type": "string",
                            "description": "Provider to fingerprint (anthropic / openai / etc.)",
                        },
                        "window_hours": {
                            "type": "integer",
                            "description": "Lookback window in hours (default 1, max 720)",
                            "default": 1,
                        },
                    },
                    "required": ["provider"],
                },
            ),
            Tool(
                name="detect_provider_regression",
                description=(
                    "Compare a current window's fingerprint vs a longer baseline "
                    "window's fingerprint and flag distribution shifts (v1.2). "
                    "Catches the Anthropic-April-23-2026 pattern: provider silently "
                    "changes default reasoning effort or model behavior, no user-side "
                    "upgrade event, but production calls drift in latency / response "
                    "length / model-version headers. Emits CRITICAL / HIGH / MEDIUM / "
                    "LOW alerts per metric. The proactive complement to "
                    "`post_upgrade_verify` (which compares pre/post snapshots around "
                    "a user-driven upgrade event)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "provider": {
                            "type": "string",
                            "description": "Provider to check (anthropic / openai / etc.)",
                        },
                        "current_window_hours": {
                            "type": "integer",
                            "description": "Current window in hours (default 1)",
                            "default": 1,
                        },
                        "baseline_window_hours": {
                            "type": "integer",
                            "description": "Baseline window in hours (default 168 = 7 days)",
                            "default": 168,
                        },
                        "threshold_pct": {
                            "type": "number",
                            "description": (
                                "Percent change threshold to flag as a regression (default 30, min 5). "
                                "Lower = more sensitive."
                            ),
                            "default": 30,
                        },
                    },
                    "required": ["provider"],
                },
            ),
        ]

    @server.call_tool()  # type: ignore[untyped-decorator]
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        logger.debug("call_tool name=%s args=%s", name, arguments)

        if name == "current_version":
            state = await backend.collect_state()
            info = current_version_info(state, detection_method=backend.name)
            return _serialize(info)

        if name == "available_upgrades":
            state = await backend.collect_state()
            return _serialize(available_upgrades_report(state))

        if name == "pre_upgrade_snapshot":
            state = await backend.collect_state()
            target = arguments.get("target_version")
            target_str = str(target).strip() if target else None
            snapshot = build_snapshot(state, target_version=target_str)
            await backend.save_snapshot(snapshot)
            return _serialize(snapshot)

        if name == "upgrade_guide":
            target = str(arguments.get("target_version", "")).strip()
            if not target:
                return [TextContent(type="text", text=json.dumps({"error": "target_version is required"}))]
            state = await backend.collect_state()
            return _serialize(build_upgrade_guide(state, target))

        if name == "post_upgrade_verify":
            pre_id = str(arguments.get("pre_snapshot_id", "")).strip()
            if not pre_id:
                return [TextContent(type="text", text=json.dumps({"error": "pre_snapshot_id is required"}))]
            pre = await backend.load_snapshot(pre_id)
            if pre is None:
                return [
                    TextContent(
                        type="text",
                        text=json.dumps({"error": f"Snapshot {pre_id!r} not found"}),
                    )
                ]
            state = await backend.collect_state()
            post = build_snapshot(state, target_version=pre.target_version)
            await backend.save_snapshot(post)
            return _serialize(build_post_upgrade_report(pre, post))

        if name == "rollback_guide":
            sid = str(arguments.get("snapshot_id", "")).strip()
            if not sid:
                return [TextContent(type="text", text=json.dumps({"error": "snapshot_id is required"}))]
            loaded = await backend.load_snapshot(sid)
            if loaded is None:
                return [
                    TextContent(
                        type="text",
                        text=json.dumps({"error": f"Snapshot {sid!r} not found"}),
                    )
                ]
            return _serialize(build_rollback_guide(loaded))

        if name == "regression_catalog":
            filter_v = arguments.get("filter_version")
            filter_str = str(filter_v).strip() if filter_v else None
            return _serialize(regression_catalog_report(filter_str))

        if name == "list_snapshots":
            snapshots = await backend.list_snapshots()
            return _serialize(snapshot_list_report(snapshots))

        if name == "record_provider_call":
            try:
                record = ProviderCallRecord(
                    captured_at=datetime.now(UTC),
                    provider=str(arguments.get("provider", "")).strip().lower() or "other",
                    model=str(arguments.get("model", "")).strip() or "unknown",
                    latency_ms=max(0, int(arguments.get("latency_ms", 0))),
                    response_length_tokens=max(0, int(arguments.get("response_length_tokens", 0))),
                    response_headers={
                        str(k): str(v)
                        for k, v in (arguments.get("response_headers") or {}).items()
                    } if isinstance(arguments.get("response_headers"), dict) else {},
                    request_kind=(
                        str(arguments["request_kind"]).strip()
                        if arguments.get("request_kind") else None
                    ),
                )
            except (ValidationError, ValueError, TypeError) as exc:
                return [
                    TextContent(
                        type="text",
                        text=json.dumps({"error": f"Invalid provider-call payload: {exc}"}),
                    )
                ]
            await backend.record_provider_call(record)
            return [
                TextContent(
                    type="text",
                    text=json.dumps({
                        "recorded": True,
                        "provider": record.provider,
                        "model": record.model,
                    }),
                )
            ]

        if name == "get_provider_fingerprint":
            provider_arg = str(arguments.get("provider", "")).strip().lower()
            if not provider_arg:
                return [TextContent(type="text", text=json.dumps({"error": "provider is required"}))]
            window_hours = max(1, min(int(arguments.get("window_hours", 1)), 720))
            records = await backend.get_provider_calls(provider=provider_arg)
            return _serialize(
                build_provider_fingerprint_report(records, provider_arg, window_hours)
            )

        if name == "detect_provider_regression":
            provider_arg = str(arguments.get("provider", "")).strip().lower()
            if not provider_arg:
                return [TextContent(type="text", text=json.dumps({"error": "provider is required"}))]
            current_h = max(1, min(int(arguments.get("current_window_hours", 1)), 720))
            baseline_h = max(current_h + 1, min(int(arguments.get("baseline_window_hours", 168)), 720 * 4))
            threshold = max(5.0, min(float(arguments.get("threshold_pct", 30)), 200.0))
            records = await backend.get_provider_calls(provider=provider_arg)
            return _serialize(
                build_provider_regression_report(
                    records,
                    provider_arg,
                    current_window_hours=current_h,
                    baseline_window_hours=baseline_h,
                    threshold_pct=threshold,
                )
            )

        return [TextContent(type="text", text=json.dumps({"error": f"Unknown tool: {name}"}))]

    # ──────────────────────── Resources ───────────────────────

    @server.list_resources()  # type: ignore[no-untyped-call, untyped-decorator]
    async def list_resources() -> list[Resource]:
        return [
            Resource(
                uri=AnyUrl("upgrade://current"),
                name="Current OpenClaw version",
                description="Detected current version + detection method",
                mimeType="application/json",
            ),
            Resource(
                uri=AnyUrl("upgrade://snapshots"),
                name="Stored snapshots",
                description="All pre/post snapshots persisted by the backend",
                mimeType="application/json",
            ),
            Resource(
                uri=AnyUrl("upgrade://catalog"),
                name="Regression catalog",
                description="Full known-regression catalog (all versions)",
                mimeType="application/json",
            ),
            Resource(
                uri=AnyUrl("upgrade://provider-fingerprint"),
                name="Provider fingerprint (Anthropic, last 1 hour)",
                description=(
                    "Aggregate fingerprint of recent Anthropic API calls — latency p50/p95, "
                    "response-length distribution, distinct models, most-common headers (v1.2)"
                ),
                mimeType="application/json",
            ),
        ]

    @server.read_resource()  # type: ignore[no-untyped-call, untyped-decorator]
    async def read_resource(uri: str) -> str:
        uri_s = str(uri)
        if uri_s == "upgrade://current":
            state = await backend.collect_state()
            return current_version_info(state, detection_method=backend.name).model_dump_json(indent=2)

        if uri_s == "upgrade://snapshots":
            snapshots = await backend.list_snapshots()
            return snapshot_list_report(snapshots).model_dump_json(indent=2)

        if uri_s == "upgrade://catalog":
            return regression_catalog_report(None).model_dump_json(indent=2)

        if uri_s == "upgrade://provider-fingerprint":
            records = await backend.get_provider_calls(provider="anthropic")
            return build_provider_fingerprint_report(
                records, "anthropic", window_hours=1
            ).model_dump_json(indent=2)

        return json.dumps({"error": f"Unknown resource URI: {uri_s}"})

    # ───────────────────────── Prompts ────────────────────────

    @server.list_prompts()  # type: ignore[no-untyped-call, untyped-decorator]
    async def list_prompts() -> list[Prompt]:
        return [
            Prompt(
                name="plan-upgrade",
                description="Walk operator through deciding + planning an upgrade",
                arguments=[
                    PromptArgument(
                        name="target_version",
                        description="Target version, e.g. '2026.4.27'. Optional — falls back to recommendation.",
                        required=False,
                    ),
                ],
            ),
            Prompt(
                name="verify-upgrade",
                description="Walk operator through post-upgrade verification using a pre-upgrade snapshot",
                arguments=[
                    PromptArgument(
                        name="pre_snapshot_id",
                        description="Snapshot id captured before the upgrade",
                        required=True,
                    ),
                ],
            ),
            Prompt(
                name="diagnose-provider-regression",
                description=(
                    "Walk operator through a no-user-upgrade-event regression — when "
                    "the hosted LLM provider silently changes model behavior (v1.2)"
                ),
                arguments=[
                    PromptArgument(
                        name="provider",
                        description="anthropic / openai / gemini / etc.",
                        required=True,
                    ),
                ],
            ),
        ]

    @server.get_prompt()  # type: ignore[no-untyped-call, untyped-decorator]
    async def get_prompt(name: str, arguments: dict[str, str] | None = None) -> GetPromptResult:
        arguments = arguments or {}
        if name == "plan-upgrade":
            target = arguments.get("target_version")
            target_clause = f"target_version='{target}'" if target else "the recommended_target from available_upgrades"
            text = (
                f"Call `current_version()` and `available_upgrades()`. "
                f"Then call `upgrade_guide({target_clause})`. "
                f"Walk the operator through: (1) the chosen target version + why "
                f"(no CRITICAL regressions in path); (2) any HIGH regressions to "
                f"watch for, with their mitigations; (3) the pre-upgrade steps including "
                f"snapshot capture; (4) the upgrade command itself; (5) the post-upgrade "
                f"verification command. End with a one-line go/no-go recommendation."
            )
            return GetPromptResult(
                description="Upgrade-planning walkthrough",
                messages=[
                    PromptMessage(role="user", content=TextContent(type="text", text=text)),
                ],
            )

        if name == "verify-upgrade":
            sid = arguments.get("pre_snapshot_id", "<snapshot-id>")
            text = (
                f"Call `post_upgrade_verify(pre_snapshot_id='{sid}')`. "
                f"Then: (1) state the overall_outcome (success/degraded/regressed); "
                f"(2) for each entry in new_failures, name the check_id + severity + "
                f"the regression it likely indicates; (3) recommend rollback or proceed; "
                f"(4) if recommending proceed, list the unchanged_failures the operator "
                f"should still address. End with a one-line ticket-ready verdict."
            )
            return GetPromptResult(
                description="Post-upgrade verification walkthrough",
                messages=[
                    PromptMessage(role="user", content=TextContent(type="text", text=text)),
                ],
            )

        if name == "diagnose-provider-regression":
            provider = arguments.get("provider", "anthropic")
            text = (
                f"Call `get_provider_fingerprint(provider='{provider}', window_hours=1)` "
                f"and `detect_provider_regression(provider='{provider}', "
                f"current_window_hours=1, baseline_window_hours=168)`. Then: "
                f"(1) state the current fingerprint vs baseline at a glance "
                f"(latency p95, response-length median); (2) for each alert, name the "
                f"metric + severity + delta_pct; (3) if any alert is CRITICAL or HIGH, "
                f"recommend either (a) verify with provider status page + recent "
                f"post-mortems for known incidents, or (b) test the same prompts against "
                f"a different provider to isolate. End with one specific corrective action — "
                f"open a provider support ticket, switch to a fallback model, or "
                f"acknowledge as expected variability — not 'continue monitoring.'"
            )
            return GetPromptResult(
                description="Provider-regression diagnostic walkthrough",
                messages=[
                    PromptMessage(role="user", content=TextContent(type="text", text=text)),
                ],
            )

        return GetPromptResult(
            description=f"Unknown prompt: {name}",
            messages=[
                PromptMessage(role="user", content=TextContent(type="text", text=f"Unknown prompt: {name}")),
            ],
        )

    return server


def _serialize(model: Any) -> list[TextContent]:
    return [TextContent(type="text", text=model.model_dump_json(indent=2))]
