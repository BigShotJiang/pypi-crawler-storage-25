"""Domain models — Version, RegressionEntry, CheckResult, Snapshot, UpgradeGuide, etc.

Every model is a frozen Pydantic BaseModel; round-trips through JSON cleanly
and serves as MCP tool/resource response payloads.
"""
from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class Severity(StrEnum):
    """Severity ladder for regressions and check results."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class CheckStatus(StrEnum):
    """Outcome of running a regression check on a deployment."""

    PASS = "pass"
    FAIL = "fail"
    UNKNOWN = "unknown"
    """Backend couldn't determine state — e.g., dependency missing, file unreadable."""
    SKIPPED = "skipped"
    """Check not applicable to current version range."""


class RegressionEntry(BaseModel):
    """One known regression in the OpenClaw version history.

    Hand-curated catalog. v1.0 ships with field-report-grounded entries.
    """

    model_config = ConfigDict(frozen=True)

    regression_id: str
    """Stable id (e.g., `R-41372-CRON-WEB-SEARCH-SILENT-FAIL`)."""
    version_introduced: str
    """Earliest version exhibiting the regression (semver-like, e.g., `2026.4.23`)."""
    version_fixed: str | None = None
    """Version that fixed it (None if not yet fixed)."""
    severity: Severity
    title: str
    description: str
    """Plain-English explanation of what breaks."""
    detection_check_id: str | None = None
    """If a check exists for this regression, its check_id. None if check-only-by-symptom."""
    mitigation: str
    """Operator action: workaround, config flip, version pin, etc."""
    field_reports: list[str] = Field(default_factory=list)
    """Public field-report URLs / IDs that documented the regression."""


class CheckResult(BaseModel):
    """Result of running one detection check against a live deployment."""

    model_config = ConfigDict(frozen=True)

    check_id: str
    status: CheckStatus
    title: str
    """Headline (matches the regression's `title` for FAILs)."""
    severity: Severity
    """Severity if status==FAIL. INFO for PASS/SKIPPED."""
    evidence: str | None = None
    """Snippet of the underlying state — port binding, log line, file contents."""
    description: str | None = None


class Snapshot(BaseModel):
    """Pre-upgrade health snapshot — version + check_results at a timestamp."""

    model_config = ConfigDict(frozen=True)

    snapshot_id: str
    captured_at: datetime
    version: str
    target_version: str | None = None
    """The version the operator was about to upgrade to. Optional."""
    check_results: list[CheckResult]
    summary: str


class UpgradeStep(BaseModel):
    """One step in an UpgradeGuide.

    Steps are the human-readable instruction list the operator follows
    when running the actual upgrade.
    """

    model_config = ConfigDict(frozen=True)

    order: int
    title: str
    description: str
    command: str | None = None
    """Suggested shell command to run, when applicable."""
    rollback_command: str | None = None
    """Inverse command if this step needs reverting."""


class UpgradeGuide(BaseModel):
    """Complete upgrade plan — current version → target version, with regressions to watch."""

    model_config = ConfigDict(frozen=True)

    current_version: str
    target_version: str
    applicable_regressions: list[RegressionEntry]
    """Regressions that apply when upgrading current → target."""
    pre_upgrade_steps: list[UpgradeStep]
    upgrade_steps: list[UpgradeStep]
    post_upgrade_steps: list[UpgradeStep]
    rollback_steps: list[UpgradeStep]
    confidence_note: str
    """Plain-English caveat about how reliable this guide is for the version range."""


class CheckResultDelta(BaseModel):
    """Difference for one check between pre + post snapshots."""

    model_config = ConfigDict(frozen=True)

    check_id: str
    title: str
    pre_status: CheckStatus
    post_status: CheckStatus
    severity: Severity
    delta_kind: str
    """`new_failure` | `regression` | `recovered` | `unchanged_fail` | `unchanged_pass`."""


class PostUpgradeReport(BaseModel):
    """Result of comparing post-upgrade snapshot to pre-upgrade baseline."""

    model_config = ConfigDict(frozen=True)

    pre_snapshot_id: str
    post_snapshot_id: str
    pre_version: str
    post_version: str
    overall_outcome: str
    """`success` | `degraded` | `regressed` | `unknown`."""
    new_failures: list[CheckResultDelta]
    """Checks that newly FAIL post-upgrade. Most important field."""
    recovered: list[CheckResultDelta]
    """Checks that FAILed pre and PASS post — fixed by the upgrade."""
    unchanged_failures: list[CheckResultDelta]
    """Checks failing in both — pre-existing issue."""
    unchanged_passes_count: int
    """Bookkeeping; not enumerated to keep payload small."""
    summary: str


class RollbackGuide(BaseModel):
    """Recovery guide — what to revert to get back to a snapshot's state."""

    model_config = ConfigDict(frozen=True)

    target_snapshot_id: str
    target_version: str
    rollback_steps: list[UpgradeStep]
    risk_note: str
    """Plain-English caveat about rollback risk (data migration loss, etc.)."""


class CurrentVersionInfo(BaseModel):
    """Compact `current_version` response."""

    model_config = ConfigDict(frozen=True)

    version: str
    detected_at: datetime
    detection_method: str
    """`mock`, `version-file`, `cli-output`, etc."""
    notes: str | None = None


class AvailableUpgrade(BaseModel):
    """One newer version that the operator could upgrade to."""

    model_config = ConfigDict(frozen=True)

    version: str
    release_date: str | None = None
    release_notes_url: str | None = None
    is_current: bool = False
    has_known_critical: bool
    """True if any CRITICAL regression applies in current → this version range."""
    applicable_regression_count: int


class AvailableUpgradesReport(BaseModel):
    """Full list of available upgrades from current."""

    model_config = ConfigDict(frozen=True)

    current_version: str
    upgrades: list[AvailableUpgrade]
    recommended_target: str | None = None
    """Heuristic: highest version with no CRITICAL regressions in the path."""


class RegressionCatalogReport(BaseModel):
    """The full catalog, optionally filtered to a version."""

    model_config = ConfigDict(frozen=True)

    filter_version: str | None
    entry_count: int
    entries: list[RegressionEntry]


class SnapshotListReport(BaseModel):
    """All snapshots stored by the backend."""

    model_config = ConfigDict(frozen=True)

    snapshot_count: int
    snapshots: list[Snapshot]


# ─────────── Provider-fingerprint (v1.2) ───────────
#
# Detects regressions on the OTHER side of the upgrade boundary: when the
# hosted LLM provider (Anthropic, OpenAI, Gemini, Bedrock) silently changes
# their model behavior or default reasoning effort without the operator
# having upgraded anything locally. Sourced from per-call observation
# records (latency + response shape + headers) recorded by a small shim
# wrapping the LLM client. Closes the [Phoenix discussion #10442
# gap](https://github.com/Arize-ai/phoenix/discussions/10442) where users
# explicitly ask for passive provider-side regression detection.
#
# Pattern source: Anthropic April 23 2026 post-mortem
# (https://www.anthropic.com/engineering/april-23-postmortem) — silent
# reasoning-effort downgrade Mar 4 → Apr 7. Five weeks of degraded
# performance with no user-side change.


class ProviderCallRecord(BaseModel):
    """Single provider API call observation — what was returned when calling Anthropic/OpenAI/etc."""

    model_config = ConfigDict(frozen=True)

    captured_at: datetime
    provider: str
    """`anthropic`, `openai`, `gemini`, `ollama`, `bedrock`, `other`."""
    model: str
    """Provider-reported model identifier, e.g., `claude-sonnet-4-7`."""
    latency_ms: int
    """End-to-end response latency."""
    response_length_tokens: int
    """Length of the response (output tokens). Heuristic for response-shape drift detection."""
    response_headers: dict[str, str] = Field(default_factory=dict)
    """Raw response headers (model-version, anthropic-ratelimit-*, etc.) for fingerprinting."""
    request_kind: str | None = None
    """Optional grouping label (e.g., `extraction` / `chat` / `agent-loop`) for narrower comparisons."""


class ProviderFingerprint(BaseModel):
    """Aggregate fingerprint over a time window — the baseline future records are compared against."""

    model_config = ConfigDict(frozen=True)

    provider: str
    window_start: datetime
    window_end: datetime
    call_count: int
    median_latency_ms: float
    p95_latency_ms: float
    median_response_length_tokens: float
    p95_response_length_tokens: float
    distinct_models: list[str]
    """Distinct model identifiers seen in the window."""
    response_header_summary: dict[str, str] = Field(default_factory=dict)
    """Most-common value seen for each header during the window."""


class ProviderRegressionAlert(BaseModel):
    """One detected distribution shift between current vs baseline window."""

    model_config = ConfigDict(frozen=True)

    severity: Severity
    provider: str
    metric: str
    """`latency_p95` / `latency_median` / `response_length_median` / `model_version` / `header_change`."""
    baseline_value: str
    """Stringified baseline value for display (numbers + version strings both fit)."""
    current_value: str
    delta_pct: float | None = None
    """Percent change current vs baseline (None for non-numeric metrics like model_version)."""
    description: str


class ProviderFingerprintReport(BaseModel):
    """Composed response for `get_provider_fingerprint`."""

    model_config = ConfigDict(frozen=True)

    provider: str
    window_hours: int
    sample_count: int
    fingerprint: ProviderFingerprint | None = None
    insufficient_data: bool
    note: str | None = None


class ProviderRegressionReport(BaseModel):
    """Composed response for `detect_provider_regression`."""

    model_config = ConfigDict(frozen=True)

    provider: str
    current_window_hours: int
    baseline_window_hours: int
    current_sample_count: int
    baseline_sample_count: int
    alerts: list[ProviderRegressionAlert]
    overall_severity: Severity
    summary: str
