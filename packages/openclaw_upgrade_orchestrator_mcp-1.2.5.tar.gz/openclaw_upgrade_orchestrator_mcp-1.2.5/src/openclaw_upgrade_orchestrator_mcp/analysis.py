"""Analysis orchestrator — composes upgrade guides, captures + compares snapshots.

Pure functions over `DeploymentState`, `Snapshot`, and the regression catalog.
The MCP server.py wires backends into these functions.
"""
from __future__ import annotations

import uuid
from collections import Counter
from datetime import UTC, datetime, timedelta
from statistics import median

from openclaw_upgrade_orchestrator_mcp.backends.base import DeploymentState
from openclaw_upgrade_orchestrator_mcp.catalog import (
    _parse_version,
    _version_lt,
    all_regressions,
    regressions_for_version,
    regressions_in_path,
)
from openclaw_upgrade_orchestrator_mcp.checks import run_all_checks
from openclaw_upgrade_orchestrator_mcp.types import (
    AvailableUpgrade,
    AvailableUpgradesReport,
    CheckResult,
    CheckResultDelta,
    CheckStatus,
    CurrentVersionInfo,
    PostUpgradeReport,
    ProviderCallRecord,
    ProviderFingerprint,
    ProviderFingerprintReport,
    ProviderRegressionAlert,
    ProviderRegressionReport,
    RegressionCatalogReport,
    RegressionEntry,
    RollbackGuide,
    Severity,
    Snapshot,
    SnapshotListReport,
    UpgradeGuide,
    UpgradeStep,
)

# ─────────── Current version + available upgrades ───────────


def current_version_info(state: DeploymentState, detection_method: str) -> CurrentVersionInfo:
    return CurrentVersionInfo(
        version=state.current_version,
        detected_at=datetime.now(UTC),
        detection_method=detection_method,
        notes=None if state.current_version != "unknown" else "Could not detect version from backend.",
    )


def available_upgrades_report(state: DeploymentState) -> AvailableUpgradesReport:
    """List newer-than-current versions, flag which carry CRITICAL regressions."""
    upgrades: list[AvailableUpgrade] = []
    recommended: str | None = None
    sorted_versions = sorted(state.available_versions, key=_parse_version)
    for v in sorted_versions:
        if not _version_lt(state.current_version, v):
            continue
        applicable = regressions_in_path(state.current_version, v)
        has_critical = any(e.severity == Severity.CRITICAL for e in applicable)
        upgrades.append(
            AvailableUpgrade(
                version=v,
                release_date=None,
                release_notes_url=f"https://openclaw.example/releases/{v}",
                is_current=False,
                has_known_critical=has_critical,
                applicable_regression_count=len(applicable),
            )
        )

    # Recommend the highest version that has zero CRITICAL regressions.
    for u in reversed(upgrades):
        if not u.has_known_critical:
            recommended = u.version
            break

    return AvailableUpgradesReport(
        current_version=state.current_version,
        upgrades=upgrades,
        recommended_target=recommended,
    )


# ─────────── Pre-upgrade snapshot ───────────


def build_snapshot(
    state: DeploymentState,
    target_version: str | None,
    snapshot_id: str | None = None,
) -> Snapshot:
    """Capture all check results into a Snapshot."""
    sid = snapshot_id or f"snap-{uuid.uuid4().hex[:12]}"
    results = run_all_checks(state)
    fails = [r for r in results if r.status == CheckStatus.FAIL]
    summary = (
        f"Snapshot {sid} of OpenClaw {state.current_version}: "
        f"{len(results)} checks ran, "
        f"{len(fails)} FAIL ({sum(1 for r in fails if r.severity == Severity.CRITICAL)} CRITICAL, "
        f"{sum(1 for r in fails if r.severity == Severity.HIGH)} HIGH)."
    )
    return Snapshot(
        snapshot_id=sid,
        captured_at=datetime.now(UTC),
        version=state.current_version,
        target_version=target_version,
        check_results=results,
        summary=summary,
    )


# ─────────── Upgrade guide ───────────


def build_upgrade_guide(state: DeploymentState, target_version: str) -> UpgradeGuide:
    """Compose the step-by-step upgrade plan for current → target."""
    applicable = regressions_in_path(state.current_version, target_version)

    pre_steps = _pre_upgrade_steps(state.current_version, target_version, applicable)
    upgrade_steps = _upgrade_steps(state.current_version, target_version)
    post_steps = _post_upgrade_steps(target_version, applicable)
    rollback = _rollback_steps(state.current_version)

    confidence = _confidence_note(state.current_version, target_version, applicable)

    return UpgradeGuide(
        current_version=state.current_version,
        target_version=target_version,
        applicable_regressions=applicable,
        pre_upgrade_steps=pre_steps,
        upgrade_steps=upgrade_steps,
        post_upgrade_steps=post_steps,
        rollback_steps=rollback,
        confidence_note=confidence,
    )


def _pre_upgrade_steps(
    current: str,
    target: str,
    applicable: list[RegressionEntry],
) -> list[UpgradeStep]:
    steps: list[UpgradeStep] = [
        UpgradeStep(
            order=1,
            title="Capture a pre-upgrade snapshot",
            description=(
                f"Run `pre_upgrade_snapshot(target_version='{target}')` from this MCP. "
                f"Save the returned snapshot_id — you'll need it for verify + rollback."
            ),
            command=None,
        ),
        UpgradeStep(
            order=2,
            title="Verify backups",
            description=(
                "Confirm `~/.openclaw/` is backed up. The upgrade may rewrite "
                "skill-cache + state files; you want a restore point."
            ),
            command="cp -r ~/.openclaw ~/.openclaw.backup-$(date +%Y%m%d)",
            rollback_command="rm -rf ~/.openclaw && mv ~/.openclaw.backup-* ~/.openclaw",
        ),
    ]
    # Add a step per CRITICAL regression with mitigation
    for i, reg in enumerate(applicable):
        if reg.severity != Severity.CRITICAL:
            continue
        steps.append(
            UpgradeStep(
                order=3 + i,
                title=f"Plan around CRITICAL regression: {reg.title}",
                description=f"{reg.description}\n\nMitigation: {reg.mitigation}",
                command=None,
            )
        )
    return steps


def _upgrade_steps(current: str, target: str) -> list[UpgradeStep]:
    return [
        UpgradeStep(
            order=1,
            title="Stop the gateway",
            description="Cleanly stop the gateway before upgrading to avoid log-rotation gaps.",
            command="openclaw gateway stop",
            rollback_command="openclaw gateway start",
        ),
        UpgradeStep(
            order=2,
            title=f"Run the upgrade to {target}",
            description=f"Upgrade from {current} to {target}.",
            command=f"openclaw upgrade --to {target}",
            rollback_command=f"openclaw upgrade --to {current}",
        ),
        UpgradeStep(
            order=3,
            title="Restart the gateway",
            description="Bring the gateway back online; first start after upgrade may take 30-60s.",
            command="openclaw gateway start",
            rollback_command="openclaw gateway stop",
        ),
    ]


def _post_upgrade_steps(target: str, applicable: list[RegressionEntry]) -> list[UpgradeStep]:
    steps: list[UpgradeStep] = [
        UpgradeStep(
            order=1,
            title="Run post-upgrade verification",
            description=(
                "Call `post_upgrade_verify(snapshot_id=<your-pre-upgrade-id>)` from "
                "this MCP. Inspect the `new_failures` list — those are checks that "
                "regressed because of the upgrade."
            ),
            command=None,
        ),
        UpgradeStep(
            order=2,
            title="Confirm CRITICAL regressions are inactive",
            description=(
                "If any CRITICAL regression in this upgrade range affects post-upgrade "
                "deployments, re-check it manually. See the applicable_regressions list."
            ),
            command=None,
        ),
    ]
    # If a regression in the path needs a manual re-registration step, include it
    for reg in applicable:
        if "openclaw skill reload" in reg.mitigation:
            steps.append(
                UpgradeStep(
                    order=3,
                    title=f"Apply mitigation for {reg.regression_id}",
                    description=reg.mitigation,
                    command="openclaw skill reload discord",
                )
            )
    return steps


def _rollback_steps(current: str) -> list[UpgradeStep]:
    return [
        UpgradeStep(
            order=1,
            title="Stop the gateway",
            description="Stop running services before reverting the binary.",
            command="openclaw gateway stop",
        ),
        UpgradeStep(
            order=2,
            title=f"Downgrade to {current}",
            description=f"Revert the openclaw binary to {current}.",
            command=f"openclaw upgrade --to {current}",
        ),
        UpgradeStep(
            order=3,
            title="Restore ~/.openclaw if state was migrated",
            description=(
                "If the upgrade migrated state files (e.g., skill cache schema changed), "
                "restore the backup directory: `rm -rf ~/.openclaw && mv ~/.openclaw.backup-<date> ~/.openclaw`. "
                "If you did not back up first, expect to re-install skills manually."
            ),
            command=None,
        ),
        UpgradeStep(
            order=4,
            title="Restart the gateway and re-verify",
            description=(
                "Bring services back up and call `pre_upgrade_snapshot()` again to "
                "confirm the deployment matches your earlier snapshot."
            ),
            command="openclaw gateway start",
        ),
    ]


def _confidence_note(current: str, target: str, applicable: list[RegressionEntry]) -> str:
    if not applicable:
        return (
            "No known regressions apply to this upgrade path. Catalog v1.0.0 covers "
            "field reports through 2026-05-04; verify against the upstream changelog "
            "for issues post-cutoff."
        )
    crit = sum(1 for r in applicable if r.severity == Severity.CRITICAL)
    high = sum(1 for r in applicable if r.severity == Severity.HIGH)
    if crit > 0:
        return (
            f"Path includes {crit} CRITICAL and {high} HIGH known regression(s). "
            "Strong recommendation: pick a different target version (see "
            "`available_upgrades` for one with no CRITICAL regressions), or apply "
            "every mitigation listed before proceeding."
        )
    if high > 0:
        return (
            f"Path includes {high} HIGH regression(s) but no CRITICAL. Proceed with "
            "the listed mitigations applied; budget extra time for post-upgrade verification."
        )
    return (
        f"Path includes {len(applicable)} regression(s), all MEDIUM or below. Proceed; "
        "the post-upgrade verification step will surface anything unexpected."
    )


# ─────────── Post-upgrade verification ───────────


def build_post_upgrade_report(
    pre_snapshot: Snapshot,
    post_snapshot: Snapshot,
) -> PostUpgradeReport:
    """Diff pre + post check_results; classify each delta."""
    pre_by_id: dict[str, CheckResult] = {r.check_id: r for r in pre_snapshot.check_results}
    post_by_id: dict[str, CheckResult] = {r.check_id: r for r in post_snapshot.check_results}

    new_failures: list[CheckResultDelta] = []
    recovered: list[CheckResultDelta] = []
    unchanged_failures: list[CheckResultDelta] = []
    unchanged_passes_count = 0

    all_ids = set(pre_by_id) | set(post_by_id)
    for cid in sorted(all_ids):
        pre = pre_by_id.get(cid)
        post = post_by_id.get(cid)
        pre_status = pre.status if pre else CheckStatus.SKIPPED
        post_status = post.status if post else CheckStatus.SKIPPED
        primary = post if post is not None else pre
        title = primary.title if primary is not None else cid
        severity = primary.severity if primary is not None else Severity.INFO

        delta_kind = _classify_delta(pre_status, post_status)
        delta = CheckResultDelta(
            check_id=cid,
            title=title,
            pre_status=pre_status,
            post_status=post_status,
            severity=severity,
            delta_kind=delta_kind,
        )
        if delta_kind == "new_failure":
            new_failures.append(delta)
        elif delta_kind == "recovered":
            recovered.append(delta)
        elif delta_kind == "unchanged_fail":
            unchanged_failures.append(delta)
        elif delta_kind == "unchanged_pass":
            unchanged_passes_count += 1

    overall = _overall_outcome(new_failures, unchanged_failures)
    summary = _post_summary(pre_snapshot, post_snapshot, overall, new_failures, recovered, unchanged_failures)

    return PostUpgradeReport(
        pre_snapshot_id=pre_snapshot.snapshot_id,
        post_snapshot_id=post_snapshot.snapshot_id,
        pre_version=pre_snapshot.version,
        post_version=post_snapshot.version,
        overall_outcome=overall,
        new_failures=new_failures,
        recovered=recovered,
        unchanged_failures=unchanged_failures,
        unchanged_passes_count=unchanged_passes_count,
        summary=summary,
    )


def _classify_delta(pre: CheckStatus, post: CheckStatus) -> str:
    if pre == CheckStatus.PASS and post == CheckStatus.FAIL:
        return "new_failure"
    if pre == CheckStatus.FAIL and post == CheckStatus.PASS:
        return "recovered"
    if pre == CheckStatus.FAIL and post == CheckStatus.FAIL:
        return "unchanged_fail"
    if pre == CheckStatus.PASS and post == CheckStatus.PASS:
        return "unchanged_pass"
    return "other"


def _overall_outcome(new_failures: list[CheckResultDelta], unchanged_failures: list[CheckResultDelta]) -> str:
    if new_failures:
        # Any CRITICAL/HIGH new failure → "regressed"
        if any(d.severity in (Severity.CRITICAL, Severity.HIGH) for d in new_failures):
            return "regressed"
        return "degraded"
    if unchanged_failures:
        return "degraded"
    return "success"


def _post_summary(
    pre_snapshot: Snapshot,
    post_snapshot: Snapshot,
    overall: str,
    new_failures: list[CheckResultDelta],
    recovered: list[CheckResultDelta],
    unchanged_failures: list[CheckResultDelta],
) -> str:
    base = (
        f"Upgrade {pre_snapshot.version} → {post_snapshot.version}: {overall.upper()}. "
        f"{len(new_failures)} new failure(s), "
        f"{len(recovered)} recovered, "
        f"{len(unchanged_failures)} unchanged failure(s)."
    )
    if new_failures:
        worst = max(new_failures, key=lambda d: 0 if d.severity == Severity.CRITICAL else 1)
        base += f" Worst new failure: [{worst.severity}] {worst.title}."
    return base


# ─────────── Rollback guide ───────────


def build_rollback_guide(snapshot: Snapshot) -> RollbackGuide:
    return RollbackGuide(
        target_snapshot_id=snapshot.snapshot_id,
        target_version=snapshot.version,
        rollback_steps=_rollback_steps(snapshot.version),
        risk_note=(
            "Rolling back can lose data migrated forward (e.g., schema changes "
            "to the skill cache, new metadata fields). If you used the "
            "Verify backups step pre-upgrade, restore from that backup. "
            "Otherwise expect to re-install skills + re-emit any new state."
        ),
    )


# ─────────── Catalog access ───────────


def regression_catalog_report(filter_version: str | None = None) -> RegressionCatalogReport:
    entries = all_regressions() if filter_version is None else regressions_for_version(filter_version)
    return RegressionCatalogReport(
        filter_version=filter_version,
        entry_count=len(entries),
        entries=entries,
    )


# ─────────── Snapshot list ───────────


def snapshot_list_report(snapshots: list[Snapshot]) -> SnapshotListReport:
    return SnapshotListReport(
        snapshot_count=len(snapshots),
        snapshots=snapshots,
    )


# ─────────── Provider-fingerprint analysis (v1.2) ───────────


_MIN_SAMPLES_FOR_FINGERPRINT = 10
"""Floor below which a fingerprint isn't statistically meaningful — reported as insufficient_data."""

_DEFAULT_REGRESSION_THRESHOLD_PCT = 30.0
"""Default percent change current vs baseline to flag as a numeric regression."""


def _percentile(values: list[float], p: float) -> float:
    """Compute percentile p (0-100) from a list of floats. Linear interpolation between ranks."""
    if not values:
        return 0.0
    sorted_v = sorted(values)
    if len(sorted_v) == 1:
        return float(sorted_v[0])
    k = (len(sorted_v) - 1) * (p / 100.0)
    lo = int(k)
    hi = min(lo + 1, len(sorted_v) - 1)
    frac = k - lo
    return float(sorted_v[lo] + (sorted_v[hi] - sorted_v[lo]) * frac)


def _records_in_window(
    records: list[ProviderCallRecord],
    window_hours: int,
    now: datetime | None = None,
) -> list[ProviderCallRecord]:
    cutoff = (now or datetime.now(UTC)) - timedelta(hours=window_hours)
    return [r for r in records if r.captured_at >= cutoff]


def _records_in_baseline_window(
    records: list[ProviderCallRecord],
    current_window_hours: int,
    baseline_window_hours: int,
    now: datetime | None = None,
) -> list[ProviderCallRecord]:
    """Return records that fall in the baseline window — i.e., older than the current window
    but within `baseline_window_hours` from now. So current=last 1hr + baseline=7d means
    'records from 1hr-to-168hr ago'."""
    n = now or datetime.now(UTC)
    current_cutoff = n - timedelta(hours=current_window_hours)
    baseline_cutoff = n - timedelta(hours=baseline_window_hours)
    return [r for r in records if baseline_cutoff <= r.captured_at < current_cutoff]


def compute_fingerprint(
    records: list[ProviderCallRecord],
    provider: str,
    window_start: datetime,
    window_end: datetime,
) -> ProviderFingerprint | None:
    """Compute aggregate fingerprint over a list of records, or None if list is empty."""
    if not records:
        return None
    latencies = [float(r.latency_ms) for r in records]
    response_lengths = [float(r.response_length_tokens) for r in records]
    distinct_models = sorted({r.model for r in records})
    # Most-common header values across the window — useful for spotting model-version drift
    header_summary: dict[str, str] = {}
    seen_headers: dict[str, list[str]] = {}
    for r in records:
        for k, v in r.response_headers.items():
            seen_headers.setdefault(k, []).append(v)
    for k, vs in seen_headers.items():
        most_common, _ = Counter(vs).most_common(1)[0]
        header_summary[k] = most_common
    return ProviderFingerprint(
        provider=provider,
        window_start=window_start,
        window_end=window_end,
        call_count=len(records),
        median_latency_ms=median(latencies),
        p95_latency_ms=_percentile(latencies, 95),
        median_response_length_tokens=median(response_lengths),
        p95_response_length_tokens=_percentile(response_lengths, 95),
        distinct_models=distinct_models,
        response_header_summary=header_summary,
    )


def build_provider_fingerprint_report(
    all_records: list[ProviderCallRecord],
    provider: str,
    window_hours: int,
    now: datetime | None = None,
) -> ProviderFingerprintReport:
    n = now or datetime.now(UTC)
    window_start = n - timedelta(hours=window_hours)
    in_window = [r for r in all_records if r.provider == provider and r.captured_at >= window_start]
    if len(in_window) < _MIN_SAMPLES_FOR_FINGERPRINT:
        return ProviderFingerprintReport(
            provider=provider,
            window_hours=window_hours,
            sample_count=len(in_window),
            fingerprint=None,
            insufficient_data=True,
            note=(
                f"Insufficient sample count ({len(in_window)} < {_MIN_SAMPLES_FOR_FINGERPRINT}). "
                f"Wire your LLM client's response into `record_provider_call` to populate the "
                f"history; come back when you've accumulated more calls."
            ),
        )
    fp = compute_fingerprint(in_window, provider, window_start, n)
    return ProviderFingerprintReport(
        provider=provider,
        window_hours=window_hours,
        sample_count=len(in_window),
        fingerprint=fp,
        insufficient_data=False,
    )


def _classify_numeric_severity(delta_pct: float) -> Severity:
    abs_pct = abs(delta_pct)
    if abs_pct >= 100:
        return Severity.CRITICAL
    if abs_pct >= 50:
        return Severity.HIGH
    if abs_pct >= 30:
        return Severity.MEDIUM
    if abs_pct >= 15:
        return Severity.LOW
    return Severity.INFO


def detect_regression(
    current: ProviderFingerprint,
    baseline: ProviderFingerprint,
    threshold_pct: float = _DEFAULT_REGRESSION_THRESHOLD_PCT,
) -> list[ProviderRegressionAlert]:
    """Compare two fingerprints and flag distribution shifts as alerts.

    Numeric metrics (latency_p95, latency_median, response_length_median) flag when
    |delta_pct| >= threshold_pct. Severity ladder: ≥100% CRITICAL, ≥50% HIGH,
    ≥30% MEDIUM, ≥15% LOW, otherwise INFO (not emitted).

    Categorical metrics (model_version) flag when the most-common header value
    changes between windows.
    """
    alerts: list[ProviderRegressionAlert] = []

    def _numeric_alert(
        metric: str,
        current_v: float,
        baseline_v: float,
        higher_is_worse: bool = True,
    ) -> ProviderRegressionAlert | None:
        if baseline_v == 0:
            return None
        delta_pct = 100.0 * (current_v - baseline_v) / baseline_v
        if abs(delta_pct) < threshold_pct:
            return None
        # Direction matters for description framing
        direction = "higher" if delta_pct > 0 else "lower"
        worse = (delta_pct > 0) == higher_is_worse
        worse_label = "regression" if worse else "improvement (might still warrant verification)"
        severity = _classify_numeric_severity(delta_pct) if worse else Severity.INFO
        if severity == Severity.INFO:
            return None  # don't flood alerts with non-regressive shifts
        return ProviderRegressionAlert(
            severity=severity,
            provider=current.provider,
            metric=metric,
            baseline_value=f"{baseline_v:.1f}",
            current_value=f"{current_v:.1f}",
            delta_pct=delta_pct,
            description=(
                f"{metric} is {abs(delta_pct):.0f}% {direction} than baseline "
                f"({current_v:.1f} vs {baseline_v:.1f}) — likely {worse_label}"
            ),
        )

    a = _numeric_alert("latency_p95", current.p95_latency_ms, baseline.p95_latency_ms)
    if a:
        alerts.append(a)
    a = _numeric_alert("latency_median", current.median_latency_ms, baseline.median_latency_ms)
    if a:
        alerts.append(a)
    a = _numeric_alert(
        "response_length_median",
        current.median_response_length_tokens,
        baseline.median_response_length_tokens,
        higher_is_worse=False,  # shorter responses might mean model got dumber
    )
    if a:
        alerts.append(a)

    # Categorical: model-version header drift
    cur_version = current.response_header_summary.get("anthropic-model-version") \
        or current.response_header_summary.get("openai-model") \
        or current.response_header_summary.get("model-version")
    base_version = baseline.response_header_summary.get("anthropic-model-version") \
        or baseline.response_header_summary.get("openai-model") \
        or baseline.response_header_summary.get("model-version")
    if cur_version and base_version and cur_version != base_version:
        alerts.append(
            ProviderRegressionAlert(
                severity=Severity.HIGH,
                provider=current.provider,
                metric="model_version",
                baseline_value=str(base_version),
                current_value=str(cur_version),
                delta_pct=None,
                description=(
                    f"Model version header changed from {base_version} to {cur_version} — "
                    f"verify whether this is an intentional upgrade or a silent provider rollout"
                ),
            )
        )

    # Distinct-model-set drift (e.g., one new model started appearing)
    if set(current.distinct_models) != set(baseline.distinct_models):
        new_models = set(current.distinct_models) - set(baseline.distinct_models)
        if new_models:
            alerts.append(
                ProviderRegressionAlert(
                    severity=Severity.MEDIUM,
                    provider=current.provider,
                    metric="model_version",
                    baseline_value=", ".join(sorted(baseline.distinct_models)),
                    current_value=", ".join(sorted(current.distinct_models)),
                    delta_pct=None,
                    description=(
                        f"New model identifier(s) appeared in current window: "
                        f"{sorted(new_models)} — verify whether your client switched models"
                    ),
                )
            )

    return alerts


def _highest_severity(alerts: list[ProviderRegressionAlert]) -> Severity:
    if not alerts:
        return Severity.INFO
    order = {
        Severity.CRITICAL: 5,
        Severity.HIGH: 4,
        Severity.MEDIUM: 3,
        Severity.LOW: 2,
        Severity.INFO: 1,
    }
    return max(alerts, key=lambda a: order[a.severity]).severity


def build_provider_regression_report(
    all_records: list[ProviderCallRecord],
    provider: str,
    current_window_hours: int = 1,
    baseline_window_hours: int = 168,
    threshold_pct: float = _DEFAULT_REGRESSION_THRESHOLD_PCT,
    now: datetime | None = None,
) -> ProviderRegressionReport:
    n = now or datetime.now(UTC)
    only_provider = [r for r in all_records if r.provider == provider]
    current_records = _records_in_window(only_provider, current_window_hours, now=n)
    baseline_records = _records_in_baseline_window(
        only_provider, current_window_hours, baseline_window_hours, now=n
    )

    if (
        len(current_records) < _MIN_SAMPLES_FOR_FINGERPRINT
        or len(baseline_records) < _MIN_SAMPLES_FOR_FINGERPRINT
    ):
        return ProviderRegressionReport(
            provider=provider,
            current_window_hours=current_window_hours,
            baseline_window_hours=baseline_window_hours,
            current_sample_count=len(current_records),
            baseline_sample_count=len(baseline_records),
            alerts=[],
            overall_severity=Severity.INFO,
            summary=(
                f"Insufficient samples to compare windows "
                f"(current={len(current_records)}, baseline={len(baseline_records)}, "
                f"need ≥{_MIN_SAMPLES_FOR_FINGERPRINT} each). Accumulate more provider calls "
                f"via `record_provider_call`, or widen the windows."
            ),
        )

    current_fp = compute_fingerprint(
        current_records,
        provider,
        n - timedelta(hours=current_window_hours),
        n,
    )
    baseline_fp = compute_fingerprint(
        baseline_records,
        provider,
        n - timedelta(hours=baseline_window_hours),
        n - timedelta(hours=current_window_hours),
    )
    # compute_fingerprint returns None only on empty input; we already guarded above.
    assert current_fp is not None and baseline_fp is not None

    alerts = detect_regression(current_fp, baseline_fp, threshold_pct=threshold_pct)
    overall = _highest_severity(alerts)
    if not alerts:
        summary = (
            f"{provider}: current {current_window_hours}h window matches the prior "
            f"{baseline_window_hours}h baseline within ±{threshold_pct:.0f}% — no regression detected."
        )
    else:
        worst = max(
            alerts,
            key=lambda a: (
                {Severity.CRITICAL: 5, Severity.HIGH: 4, Severity.MEDIUM: 3, Severity.LOW: 2}[a.severity],
                abs(a.delta_pct or 0),
            ),
        )
        summary = (
            f"{provider}: {len(alerts)} alert(s) — worst is {worst.severity.upper()} on "
            f"{worst.metric}: {worst.description}"
        )

    return ProviderRegressionReport(
        provider=provider,
        current_window_hours=current_window_hours,
        baseline_window_hours=baseline_window_hours,
        current_sample_count=len(current_records),
        baseline_sample_count=len(baseline_records),
        alerts=alerts,
        overall_severity=overall,
        summary=summary,
    )
