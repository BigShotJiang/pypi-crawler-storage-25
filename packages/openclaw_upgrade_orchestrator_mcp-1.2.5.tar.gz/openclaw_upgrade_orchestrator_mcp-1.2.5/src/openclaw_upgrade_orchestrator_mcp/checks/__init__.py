"""Detection checks. Each check inspects a DeploymentState and returns a CheckResult.

Checks are referenced from the regression catalog via `detection_check_id`.
A regression with `detection_check_id=None` is "advisory only" — informational
without an automated test.

To add a check:
  1. Define `def run(state: DeploymentState) -> CheckResult` here
  2. Register it in `CHECKS: dict[str, callable]` below
  3. Reference it from a regression's `detection_check_id` in catalog.py
"""
from __future__ import annotations

from collections.abc import Callable

from openclaw_upgrade_orchestrator_mcp.backends.base import DeploymentState
from openclaw_upgrade_orchestrator_mcp.types import CheckResult, CheckStatus, Severity


def _ok(check_id: str, title: str, description: str = "") -> CheckResult:
    return CheckResult(
        check_id=check_id,
        status=CheckStatus.PASS,
        title=title,
        severity=Severity.INFO,
        description=description or None,
    )


def _fail(check_id: str, title: str, severity: Severity, evidence: str, description: str = "") -> CheckResult:
    return CheckResult(
        check_id=check_id,
        status=CheckStatus.FAIL,
        title=title,
        severity=severity,
        evidence=evidence,
        description=description or None,
    )


def _unknown(check_id: str, title: str, description: str) -> CheckResult:
    return CheckResult(
        check_id=check_id,
        status=CheckStatus.UNKNOWN,
        title=title,
        severity=Severity.INFO,
        description=description,
    )


# ─────────── Individual checks ───────────


def check_cron_web_search(state: DeploymentState) -> CheckResult:
    if state.cron_web_search_returns_results is None:
        return _unknown(
            "cron.web_search_returns_results",
            "Cron --session web-search recently returned results",
            "Backend did not report cron web-search status; cannot verify R-41372.",
        )
    if state.cron_web_search_returns_results:
        return _ok(
            "cron.web_search_returns_results",
            "Cron --session web-search returns results",
            "Most recent --session cron run with web-search produced output as expected.",
        )
    return _fail(
        "cron.web_search_returns_results",
        "Cron --session web-search silently returns empty results",
        Severity.HIGH,
        evidence="cron_web_search_returns_results=False",
        description=(
            "Field-report-#41372 pattern: cron exits 0 but the web-search tool "
            "produced no output. See R-41372-CRON-WEB-SEARCH-SILENT-FAIL."
        ),
    )


def check_cpu_under_threshold(state: DeploymentState) -> CheckResult:
    if state.cpu_max_pct_15min is None:
        return _unknown(
            "resources.cpu_under_threshold",
            "CPU under 85% for 15 min",
            "Backend did not report CPU metrics; cannot verify R-63002.",
        )
    if state.cpu_max_pct_15min < 85.0:
        return _ok(
            "resources.cpu_under_threshold",
            f"CPU under 85% (max {state.cpu_max_pct_15min:.1f}%)",
            "No sustained CPU spike that would indicate the 2026.4.8 skill-registry loop bug.",
        )
    return _fail(
        "resources.cpu_under_threshold",
        f"Sustained CPU >85% (max {state.cpu_max_pct_15min:.1f}%)",
        Severity.CRITICAL,
        evidence=f"cpu_max_pct_15min={state.cpu_max_pct_15min:.1f}",
        description=(
            "May indicate R-63002-POST-UPGRADE-CPU-SPIKE — skill-registry refresh "
            "loop became O(n²). Workaround: reduce skill count or upgrade past 2026.4.10."
        ),
    )


def check_recent_oom_count(state: DeploymentState) -> CheckResult:
    if state.recent_oom_count_24h is None:
        return _unknown(
            "resources.recent_oom_count",
            "Recent OOM-kill events (24h)",
            "Backend did not report kernel OOM events; cannot verify R-OOM-DURING-LARGE-CONTEXT.",
        )
    if state.recent_oom_count_24h == 0:
        return _ok(
            "resources.recent_oom_count",
            "No OOM-kill events in last 24h",
            "No kernel OOM-kills observed.",
        )
    severity = Severity.HIGH if state.recent_oom_count_24h <= 3 else Severity.CRITICAL
    return _fail(
        "resources.recent_oom_count",
        f"{state.recent_oom_count_24h} OOM-kill events in last 24h",
        severity,
        evidence=f"recent_oom_count_24h={state.recent_oom_count_24h}",
        description=(
            "May indicate R-OOM-DURING-LARGE-CONTEXT-2026.4.30 — sustained 200k+ "
            "token contexts trigger OOM kills. Mitigation: cap context at 150k tokens."
        ),
    )


def check_discord_receive_registered(state: DeploymentState) -> CheckResult:
    if state.discord_skill_receive_registered is None:
        return _unknown(
            "skills.discord_receive_registered",
            "Discord skill on_message hook registered",
            "Backend did not report Discord-skill state (skill may not be installed).",
        )
    if state.discord_skill_receive_registered:
        return _ok(
            "skills.discord_receive_registered",
            "Discord skill on_message hook is registered",
            "No sign of R-73421-DISCORD-RECEIVE-BREAKAGE.",
        )
    return _fail(
        "skills.discord_receive_registered",
        "Discord skill on_message hook NOT registered",
        Severity.HIGH,
        evidence="discord_skill_receive_registered=False",
        description=(
            "May indicate R-73421-DISCORD-RECEIVE-BREAKAGE on 2026.4.23-.26. "
            "Workaround: `openclaw skill reload discord`. Fix: upgrade to 2026.4.27+."
        ),
    )


def check_gateway_expected_port(state: DeploymentState) -> CheckResult:
    expected = state.expected_gateway_port
    if expected is None:
        return _unknown(
            "gateway.expected_port_listening",
            "Gateway port listening as configured",
            "Backend did not report expected gateway port.",
        )
    if not state.listening_ports:
        return _unknown(
            "gateway.expected_port_listening",
            "Gateway port listening as configured",
            "Backend did not enumerate listening ports.",
        )
    if expected in state.listening_ports:
        return _ok(
            "gateway.expected_port_listening",
            f"Gateway listening on configured port {expected}",
            "",
        )
    return _fail(
        "gateway.expected_port_listening",
        f"Gateway NOT listening on expected port {expected}",
        Severity.MEDIUM,
        evidence=f"expected={expected} listening={state.listening_ports}",
        description=(
            "May indicate R-GATEWAY-PORT-CONFLICT-2026.4.15 default-port shift. "
            "Pin the port explicitly in gateway.yaml."
        ),
    )


def check_skill_cache_validity(state: DeploymentState) -> CheckResult:
    if state.skill_cache_valid is None:
        return _unknown(
            "skills.cache_validity",
            "Skill cache parses cleanly",
            "Backend did not report skill-cache state.",
        )
    if state.skill_cache_valid:
        return _ok(
            "skills.cache_validity",
            "Skill cache valid",
            "Skill-cache files parse cleanly; no sign of R-CLAWHUB-CACHE-POISONING.",
        )
    return _fail(
        "skills.cache_validity",
        "Skill cache contains invalid entries",
        Severity.HIGH,
        evidence="skill_cache_valid=False",
        description=(
            "May indicate R-CLAWHUB-CACHE-POISONING-2026.3.28. "
            "Recovery: `rm ~/.openclaw/skill-cache/*.json` then restart gateway."
        ),
    )


# ─────────── Registry ───────────


CHECKS: dict[str, Callable[[DeploymentState], CheckResult]] = {
    "cron.web_search_returns_results": check_cron_web_search,
    "resources.cpu_under_threshold": check_cpu_under_threshold,
    "resources.recent_oom_count": check_recent_oom_count,
    "skills.discord_receive_registered": check_discord_receive_registered,
    "gateway.expected_port_listening": check_gateway_expected_port,
    "skills.cache_validity": check_skill_cache_validity,
}


def run_all_checks(state: DeploymentState) -> list[CheckResult]:
    """Run every registered check against the deployment state."""
    return [check(state) for check in CHECKS.values()]


def run_checks_for_regression_ids(
    state: DeploymentState,
    regression_check_ids: list[str | None],
) -> list[CheckResult]:
    """Run only the checks referenced by a list of regression check_ids.

    None check_ids are skipped (advisory-only regressions). Unknown check_ids
    produce a SKIPPED CheckResult so the operator sees the gap.
    """
    out: list[CheckResult] = []
    for cid in regression_check_ids:
        if cid is None:
            continue
        check = CHECKS.get(cid)
        if check is None:
            out.append(
                CheckResult(
                    check_id=cid,
                    status=CheckStatus.SKIPPED,
                    title=f"Check {cid!r} is referenced by catalog but not implemented",
                    severity=Severity.INFO,
                    description="No implementation registered for this check.",
                )
            )
            continue
        out.append(check(state))
    return out
