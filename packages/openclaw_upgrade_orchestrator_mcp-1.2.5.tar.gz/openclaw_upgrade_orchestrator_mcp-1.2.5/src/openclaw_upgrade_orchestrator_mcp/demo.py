"""Synthetic demo — `openclaw-upgrade-orchestrator-mcp-demo` console script.

Run ``openclaw-upgrade-orchestrator-mcp-demo`` after ``pip install
openclaw-upgrade-orchestrator-mcp`` to see the upgrade-orchestrator analyze a
representative deployment in ~30 seconds.

The mock backend simulates a deployment at OpenClaw 2026.4.23 — a version known
to be hit by the Discord-receive regression (R-73421). The demo walks through:

1. Current version detection
2. Available upgrades + recommended target
3. Applicable regressions for current version (from the hand-curated catalog)
4. Upgrade guide (pre/upgrade/post/rollback steps for the recommended target)
5. Pre-upgrade snapshot

This is observability-only — no I/O, no API keys. The mock backend never
executes any actual upgrade — it's a pure read-only advisor.
"""
from __future__ import annotations

import asyncio
import sys

from openclaw_upgrade_orchestrator_mcp import __version__
from openclaw_upgrade_orchestrator_mcp.analysis import (
    available_upgrades_report,
    build_snapshot,
    build_upgrade_guide,
    current_version_info,
    regression_catalog_report,
)
from openclaw_upgrade_orchestrator_mcp.backends.mock import MockBackend


def _is_tty() -> bool:
    try:
        return sys.stderr.isatty()
    except Exception:
        return False


_USE_COLOR = _is_tty()


def _c(code: str, s: str) -> str:
    return f"\033[{code}m{s}\033[0m" if _USE_COLOR else s


def _bold(s: str) -> str: return _c("1", s)
def _red(s: str) -> str: return _c("31", s)
def _yellow(s: str) -> str: return _c("33", s)
def _green(s: str) -> str: return _c("32", s)
def _cyan(s: str) -> str: return _c("36", s)
def _dim(s: str) -> str: return _c("2", s)


def _section(title: str) -> None:
    print(_bold(f"  {title}"), file=sys.stderr)


def _kv(label: str, value: str) -> None:
    print(f"    {_dim(label):<22s}{value}", file=sys.stderr)


def _note(s: str) -> None:
    print(_dim(f"    · {s}"), file=sys.stderr)


def _sev_color(severity_value: str) -> str:
    if severity_value == "critical":
        return _red(f"[{severity_value.upper()}]")
    if severity_value == "high":
        return _red(f"[{severity_value.upper()}]")
    if severity_value == "medium":
        return _yellow(f"[{severity_value.upper()}]")
    return _dim(f"[{severity_value.upper()}]")


async def _run_demo() -> int:
    print(file=sys.stderr)
    print(_bold(f"openclaw-upgrade-orchestrator-mcp v{__version__} · synthetic demo"), file=sys.stderr)
    print(_dim("    pre-upgrade safety: regression catalog + snapshot diff + rollback guide · read-only"), file=sys.stderr)
    print(file=sys.stderr)

    backend = MockBackend()
    state = await backend.collect_state()

    # 1. Current version
    cv = current_version_info(state, detection_method=backend.name)
    _section("1. Current deployment state")
    _kv("version:", cv.version)
    _kv("detection:", cv.detection_method)
    _kv("listening ports:", ", ".join(str(p) for p in state.listening_ports))
    _kv("skill count:", str(state.skill_count))
    print(file=sys.stderr)

    # 2. Available upgrades
    upgrades = available_upgrades_report(state)
    _section("2. Available upgrades")
    _kv("recommended:", _green(upgrades.recommended_target) if upgrades.recommended_target else _yellow("none"))
    _kv("total available:", str(len(upgrades.upgrades)))
    for upg in upgrades.upgrades[:4]:
        marker = "→" if upg.version == upgrades.recommended_target else " "
        if upg.has_known_critical:
            risk = _red(f"{upg.applicable_regression_count} known regression(s), at least one critical")
        elif upg.applicable_regression_count > 0:
            risk = _yellow(f"{upg.applicable_regression_count} known regression(s)")
        else:
            risk = _dim("(no known regressions)")
        print(f"    {marker} {_cyan(upg.version):<14s} {risk}", file=sys.stderr)
    print(file=sys.stderr)

    # 3. Applicable regressions for current version
    cat = regression_catalog_report(filter_version=cv.version)
    _section(f"3. Regressions affecting {cv.version}")
    if not cat.entries:
        _note(_green("no known regressions affecting this version"))
    else:
        _kv("count:", str(cat.entry_count))
        for entry in cat.entries[:3]:
            print(
                f"    {_sev_color(entry.severity.value)} "
                f"{_cyan(entry.regression_id)}: {entry.title}",
                file=sys.stderr,
            )
            _note(f"introduced {entry.version_introduced} → fixed {entry.version_fixed or '(unfixed)'}")
            _note(f"mitigation: {entry.mitigation}")
    print(file=sys.stderr)

    # 4. Upgrade guide for recommended target
    if upgrades.recommended_target:
        guide = build_upgrade_guide(state, target_version=upgrades.recommended_target)
        _section(f"4. Upgrade guide · {cv.version} → {guide.target_version}")
        _kv("regressions to watch:", str(len(guide.applicable_regressions)))
        _kv(
            "steps:",
            f"{len(guide.pre_upgrade_steps)} pre · {len(guide.upgrade_steps)} upgrade · "
            f"{len(guide.post_upgrade_steps)} post · {len(guide.rollback_steps)} rollback",
        )
        # Show first 3 upgrade steps
        for step in guide.upgrade_steps[:3]:
            print(f"    {_dim(f'step {step.order}.')} {step.title}", file=sys.stderr)
            if step.command:
                print(_dim(f"      $ {step.command}"), file=sys.stderr)
        if len(guide.upgrade_steps) > 3:
            _note(f"... and {len(guide.upgrade_steps) - 3} more upgrade steps")
        print(file=sys.stderr)

    # 5. Pre-upgrade snapshot
    snapshot = build_snapshot(state, target_version=upgrades.recommended_target)
    _section("5. Pre-upgrade snapshot (would be saved before applying)")
    _kv("snapshot_id:", snapshot.snapshot_id)
    _kv("captured_at:", snapshot.captured_at.strftime('%Y-%m-%d %H:%M:%S UTC'))
    _kv("checks run:", str(len(snapshot.check_results)))
    fail_checks = [c for c in snapshot.check_results if c.status.value == "fail"]
    pass_checks = [c for c in snapshot.check_results if c.status.value == "pass"]
    _kv("results:", f"{_green(str(len(pass_checks)) + ' pass')} · {_red(str(len(fail_checks)) + ' fail') if fail_checks else _dim('0 fail')}")
    for check in fail_checks[:2]:
        print(f"    {_sev_color(check.severity.value)} {_cyan(check.check_id)}: {check.title}", file=sys.stderr)
    print(file=sys.stderr)

    print(_dim("→ This is the mock backend (simulates a 2026.4.23 deployment hit by R-73421)."), file=sys.stderr)
    print(_dim("To use upgrade-orchestrator on YOUR deployment:"), file=sys.stderr)
    print(_dim("  1. Configure the MCP server in Claude Code / Cursor / OpenClaw"), file=sys.stderr)
    print(_dim("  2. Set OPENCLAW_UPGRADE_BACKEND=openclaw_system"), file=sys.stderr)
    print(_dim("  3. Ask: 'What regressions affect my current OpenClaw version?'"), file=sys.stderr)
    print(_dim("           or 'Build me an upgrade guide to 2026.4.30'"), file=sys.stderr)
    print(_dim("  Read-only — never executes upgrades on your behalf."), file=sys.stderr)
    print(file=sys.stderr)
    print(_dim("docs: https://github.com/temurkhan13/openclaw-upgrade-orchestrator-mcp"), file=sys.stderr)
    return 0


def main() -> None:
    sys.exit(asyncio.run(_run_demo()))


if __name__ == "__main__":
    main()
