"""openclaw-upgrade-orchestrator-mcp — safe-upgrade advisor for OpenClaw deployments."""
from openclaw_upgrade_orchestrator_mcp.server import build_server

__version__ = "1.2.5"

__all__ = ["__version__", "build_server"]
