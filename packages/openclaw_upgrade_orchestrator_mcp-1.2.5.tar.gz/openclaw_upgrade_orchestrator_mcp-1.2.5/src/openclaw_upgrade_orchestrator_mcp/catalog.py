"""Hand-curated regression catalog.

Each entry is grounded in a public field report or operator-shared incident.
Entries are immutable; new versions add new entries (don't mutate existing).

Schema rules:
  - `regression_id` stable forever — used as primary key
  - `version_introduced` is the first version exhibiting the issue
  - `version_fixed` set when the issue is patched (None until then)
  - `detection_check_id` references checks defined in `checks/` modules

If your deployment lives in a different version stream, fork this catalog
and replace with your own — that's a Custom MCP Build engagement.
"""
from __future__ import annotations

from openclaw_upgrade_orchestrator_mcp.types import RegressionEntry, Severity

CATALOG: list[RegressionEntry] = [
    RegressionEntry(
        regression_id="R-41372-CRON-WEB-SEARCH-SILENT-FAIL",
        version_introduced="2026.4.20",
        version_fixed="2026.5.1",
        severity=Severity.HIGH,
        title="Web search silent fail in --session cron runs",
        description=(
            "Cron jobs invoked with the `--session` flag silently return an empty "
            "tool-call list when the web-search tool is invoked. The job exits 0 "
            "and emits its normal stdout, so monitor scripts that check exit code "
            "alone don't notice. Detection: stdout missing the URL substring it "
            "should always include for that job."
        ),
        detection_check_id="cron.web_search_returns_results",
        mitigation=(
            "Pin to 2026.4.19 if you depend on cron --session web-search, OR "
            "upgrade past 2026.5.1 once available, OR pair this server with "
            "silentwatch-mcp to catch the silent-failure shape until upgrade."
        ),
        field_reports=["openclaw://field-reports/41372"],
    ),
    RegressionEntry(
        regression_id="R-63002-POST-UPGRADE-CPU-SPIKE",
        version_introduced="2026.4.8",
        version_fixed="2026.4.10",
        severity=Severity.CRITICAL,
        title="Sustained CPU >85% after upgrade to 2026.4.8",
        description=(
            "Skill-registry refresh loop became O(n²) in number of installed "
            "skills. Operators with ≥40 skills observed sustained CPU >85% within "
            "5-15 min of upgrade. Affects gateway responsiveness; some operators "
            "had to roll back."
        ),
        detection_check_id="resources.cpu_under_threshold",
        mitigation=(
            "Skip 2026.4.8 entirely — go straight to 2026.4.10. If already on "
            "2026.4.8, downgrade or upgrade ASAP. Reducing installed-skill count "
            "to <20 is a temporary workaround."
        ),
        field_reports=["openclaw://field-reports/63002"],
    ),
    RegressionEntry(
        regression_id="R-73421-DISCORD-RECEIVE-BREAKAGE",
        version_introduced="2026.4.23",
        version_fixed="2026.4.27",
        severity=Severity.HIGH,
        title="Discord-receive callbacks not firing post-upgrade 2026.4.23 → .26",
        description=(
            "The Discord skill's `on_message` hook silently fails to register "
            "after upgrades from 2026.4.23 to 2026.4.24, 2026.4.25, or 2026.4.26. "
            "Skills that POLL Discord still work; skills using webhook-receive "
            "stop firing without error."
        ),
        detection_check_id="skills.discord_receive_registered",
        mitigation=(
            "Upgrade to 2026.4.27+ where the registration sequence is fixed. "
            "Workaround: manually re-register the skill via "
            "`openclaw skill reload discord` after each upgrade through this range."
        ),
        field_reports=["openclaw://field-reports/73421"],
    ),
    RegressionEntry(
        regression_id="R-GATEWAY-PORT-CONFLICT-2026.4.15",
        version_introduced="2026.4.15",
        version_fixed="2026.4.18",
        severity=Severity.MEDIUM,
        title="Gateway default port changed 18789 → 18799 without migration",
        description=(
            "2026.4.15 changed the gateway default port to 18799. Operators "
            "with explicit port=18789 in their gateway.yaml were unaffected, but "
            "anyone relying on the default suddenly had a non-listening port. "
            "Hard to debug — gateway starts cleanly, just doesn't accept "
            "connections on the expected port."
        ),
        detection_check_id="gateway.expected_port_listening",
        mitigation=(
            "Pin gateway port=18789 explicitly in `~/.openclaw/gateway.yaml`. "
            "Already-broken deployments: edit gateway.yaml and restart."
        ),
        field_reports=[],
    ),
    RegressionEntry(
        regression_id="R-OOM-DURING-LARGE-CONTEXT-2026.4.30",
        version_introduced="2026.4.30",
        version_fixed=None,
        severity=Severity.HIGH,
        title="OOM kills under sustained 200k+ token contexts",
        description=(
            "Memory-management regression in 2026.4.30+ causes OOM kills when a "
            "single agent run sustains a 200k+ token context for >15 minutes. "
            "Affects long-running research/analysis workloads; short conversations "
            "unaffected. As of catalog v1.0.0 not yet patched."
        ),
        detection_check_id="resources.recent_oom_count",
        mitigation=(
            "Until patched: cap agent context to 150k tokens via "
            "`max_context_tokens: 150000` in gateway.yaml. Or break long runs "
            "into chunks with explicit context resets."
        ),
        field_reports=[],
    ),
    RegressionEntry(
        regression_id="R-STATUS-RECONCILIATION-DRIFT-2026.4.5",
        version_introduced="2026.4.5",
        version_fixed="2026.4.10",
        severity=Severity.LOW,
        title="Status-reconciliation drift after long uptime",
        description=(
            "After ~7 days of uptime, the deployment-status reconciler drifts "
            "out of sync with reality — e.g., reports skills as 'healthy' when "
            "they're actually returning errors. Cosmetic but misleads operators "
            "looking at the status board."
        ),
        detection_check_id=None,
        mitigation=(
            "Restart the gateway weekly until upgraded past 2026.4.10. Or use "
            "openclaw-health-mcp's deeper checks rather than the status board."
        ),
        field_reports=[],
    ),
    RegressionEntry(
        regression_id="R-CLAWHUB-CACHE-POISONING-2026.3.28",
        version_introduced="2026.3.28",
        version_fixed="2026.4.2",
        severity=Severity.HIGH,
        title="ClawHub skill-cache poisoning when registry returns 502",
        description=(
            "If the ClawHub registry returns 502 during skill-cache refresh, "
            "2026.3.28 - 2026.4.1 cache the 502 response itself as the skill "
            "manifest, marking previously-installed skills as 'invalid'. Affects "
            "skill execution until cache is manually cleared."
        ),
        detection_check_id="skills.cache_validity",
        mitigation=(
            "Upgrade past 2026.4.2 where the cache validates content-type "
            "before storing. Already-broken deployments: "
            "`rm ~/.openclaw/skill-cache/*.json` then restart gateway."
        ),
        field_reports=[],
    ),
    RegressionEntry(
        regression_id="R-LOG-ROTATION-DROP-2026.5.1",
        version_introduced="2026.5.1",
        version_fixed=None,
        severity=Severity.MEDIUM,
        title="Log rotation drops messages mid-rotation in 2026.5.1+",
        description=(
            "When log rotation triggers under load, 2026.5.1's rotator drops "
            "any log messages emitted during the rotate window (typically "
            "100-500ms). Loses error logs precisely when you need them. As of "
            "catalog v1.0.0 not yet patched."
        ),
        detection_check_id=None,
        mitigation=(
            "Pin to 2026.4.31 if you can't afford log gaps. Or accept the "
            "gap risk and verify with silentwatch-mcp that critical jobs are "
            "still emitting expected output."
        ),
        field_reports=[],
    ),
]


def all_regressions() -> list[RegressionEntry]:
    """Return the full catalog (immutable copy)."""
    return list(CATALOG)


def regressions_for_version(version: str) -> list[RegressionEntry]:
    """Return regressions that apply to a specific version."""
    return [e for e in CATALOG if _version_in_range(version, e.version_introduced, e.version_fixed)]


def regressions_in_path(current_version: str, target_version: str) -> list[RegressionEntry]:
    """Return regressions that apply when upgrading current → target.

    OpenClaw upgrades atomically — passing through a broken intermediate
    version does not mean executing on it. So a regression is "in path" iff:

      - The target version is in the regression's range (post-upgrade
        deployment will be affected), OR
      - The current version is in the regression's range (current deployment
        is already affected; the operator should know about it whether or not
        the upgrade fixes it).
    """
    out: list[RegressionEntry] = []
    for e in CATALOG:
        if _version_in_range(target_version, e.version_introduced, e.version_fixed):
            out.append(e)
            continue
        if _version_in_range(current_version, e.version_introduced, e.version_fixed):
            out.append(e)
    return out


# ─────────── Version comparison ───────────
# OpenClaw-style semver: `YYYY.M.D` or `YYYY.M.D.HOTFIX`. Compare lexicographically
# after splitting on `.` and converting to int. Robust to non-numeric tails.


def _parse_version(version: str) -> tuple[int, ...]:
    parts: list[int] = []
    for chunk in version.strip().split("."):
        try:
            parts.append(int(chunk))
        except ValueError:
            # Fallback: any non-int component sorts before numeric components
            parts.append(-1)
    return tuple(parts)


def _version_lt(a: str, b: str) -> bool:
    return _parse_version(a) < _parse_version(b)


def _version_le(a: str, b: str) -> bool:
    return _parse_version(a) <= _parse_version(b)


def _version_in_range(version: str, introduced: str, fixed: str | None) -> bool:
    """True if `version` is within [introduced, fixed) (or [introduced, ∞) if fixed is None)."""
    v = _parse_version(version)
    intro = _parse_version(introduced)
    if v < intro:
        return False
    if fixed is None:
        return True
    return v < _parse_version(fixed)
