"""Server protocol-wiring tests — tools, resources, prompts."""
from __future__ import annotations

import json

import pytest

from openclaw_upgrade_orchestrator_mcp.server import build_server


def test_build_server_with_mock() -> None:
    server = build_server(backend_name="mock")
    assert server is not None
    assert server.name == "openclaw-upgrade-orchestrator"


def test_build_server_invalid_backend() -> None:
    with pytest.raises(KeyError):
        build_server(backend_name="does-not-exist")


# ───────────── Tool registration ─────────────


async def test_list_tools_returns_eleven() -> None:
    from mcp.types import ListToolsRequest

    server = build_server("mock")
    handler = server.request_handlers[ListToolsRequest]
    result = await handler(ListToolsRequest(method="tools/list"))
    names = {t.name for t in result.root.tools}
    expected = {
        "current_version",
        "available_upgrades",
        "pre_upgrade_snapshot",
        "upgrade_guide",
        "post_upgrade_verify",
        "rollback_guide",
        "regression_catalog",
        "list_snapshots",
        # v1.2 — provider-fingerprint
        "record_provider_call",
        "get_provider_fingerprint",
        "detect_provider_regression",
    }
    assert names == expected


async def test_list_tools_schemas_valid() -> None:
    from mcp.types import ListToolsRequest

    server = build_server("mock")
    handler = server.request_handlers[ListToolsRequest]
    result = await handler(ListToolsRequest(method="tools/list"))
    for tool in result.root.tools:
        assert isinstance(tool.inputSchema, dict)
        assert tool.inputSchema.get("type") == "object"


# ───────────── Tool dispatch ─────────────


async def test_call_tool_current_version() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="current_version", arguments={}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["version"] == "2026.4.23"
    assert parsed["detection_method"] == "mock"


async def test_call_tool_available_upgrades() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="available_upgrades", arguments={}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["current_version"] == "2026.4.23"
    assert "upgrades" in parsed
    assert parsed["recommended_target"] is not None


async def test_call_tool_pre_upgrade_snapshot_returns_id() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="pre_upgrade_snapshot",
                arguments={"target_version": "2026.4.27"},
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "snapshot_id" in parsed
    assert parsed["target_version"] == "2026.4.27"
    assert parsed["version"] == "2026.4.23"


async def test_call_tool_upgrade_guide_requires_target() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="upgrade_guide", arguments={}),
        )
    )
    body = result.root.content[0].text
    # MCP's schema validator may catch the missing required field before our handler;
    # accept either MCP-level or our handler-level error response.
    try:
        parsed = json.loads(body)
        assert "error" in parsed
    except json.JSONDecodeError:
        assert "required" in body.lower() or "validation" in body.lower()


async def test_call_tool_upgrade_guide_with_target() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="upgrade_guide",
                arguments={"target_version": "2026.4.27"},
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["current_version"] == "2026.4.23"
    assert parsed["target_version"] == "2026.4.27"
    assert "applicable_regressions" in parsed
    assert "confidence_note" in parsed


async def test_call_tool_post_upgrade_verify_round_trips_snapshot() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]

    # Capture pre-snapshot first
    pre_result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="pre_upgrade_snapshot", arguments={}),
        )
    )
    pre_parsed = json.loads(pre_result.root.content[0].text)
    pre_id = pre_parsed["snapshot_id"]

    # Verify against the same snapshot — should produce zero new failures
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="post_upgrade_verify",
                arguments={"pre_snapshot_id": pre_id},
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["pre_snapshot_id"] == pre_id
    assert parsed["overall_outcome"] in ("success", "degraded")  # degraded if pre had unchanged failure


async def test_call_tool_post_upgrade_verify_unknown_snapshot_errors() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="post_upgrade_verify",
                arguments={"pre_snapshot_id": "ghost"},
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


async def test_call_tool_rollback_guide() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]

    # Need a snapshot first
    pre_result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="pre_upgrade_snapshot", arguments={}),
        )
    )
    pre_id = json.loads(pre_result.root.content[0].text)["snapshot_id"]

    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="rollback_guide",
                arguments={"snapshot_id": pre_id},
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["target_snapshot_id"] == pre_id
    assert parsed["target_version"] == "2026.4.23"
    assert "risk_note" in parsed


async def test_call_tool_regression_catalog() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="regression_catalog", arguments={}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["entry_count"] >= 5
    assert parsed["filter_version"] is None


async def test_call_tool_regression_catalog_filtered() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="regression_catalog",
                arguments={"filter_version": "2026.4.23"},
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    ids = {e["regression_id"] for e in parsed["entries"]}
    assert "R-73421-DISCORD-RECEIVE-BREAKAGE" in ids


async def test_call_tool_list_snapshots_empty_then_populated() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    # Initially empty
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="list_snapshots", arguments={}),
        )
    )
    assert json.loads(result.root.content[0].text)["snapshot_count"] == 0

    # Capture one
    await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="pre_upgrade_snapshot", arguments={}),
        )
    )

    # Now should be 1
    result2 = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="list_snapshots", arguments={}),
        )
    )
    assert json.loads(result2.root.content[0].text)["snapshot_count"] == 1


async def test_call_tool_unknown_returns_error() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="not_a_tool", arguments={}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


# ───────────── Resources ─────────────


async def test_list_resources_returns_four() -> None:
    from mcp.types import ListResourcesRequest

    server = build_server("mock")
    handler = server.request_handlers[ListResourcesRequest]
    result = await handler(ListResourcesRequest(method="resources/list"))
    uris = {str(r.uri) for r in result.root.resources}
    assert {
        "upgrade://current",
        "upgrade://snapshots",
        "upgrade://catalog",
        "upgrade://provider-fingerprint",
    } <= uris


# ───────────── Prompts ─────────────


async def test_list_prompts_returns_three() -> None:
    from mcp.types import ListPromptsRequest

    server = build_server("mock")
    handler = server.request_handlers[ListPromptsRequest]
    result = await handler(ListPromptsRequest(method="prompts/list"))
    names = {p.name for p in result.root.prompts}
    assert names == {"plan-upgrade", "verify-upgrade", "diagnose-provider-regression"}


# ───────────── v1.2 provider-fingerprint tools ─────────────


async def test_call_tool_record_provider_call_appends_record() -> None:
    import json as _json

    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="record_provider_call",
                arguments={
                    "provider": "anthropic",
                    "model": "claude-sonnet-4-7",
                    "latency_ms": 950,
                    "response_length_tokens": 600,
                    "response_headers": {"anthropic-model-version": "claude-sonnet-4-7-20260301"},
                },
            ),
        )
    )
    parsed = _json.loads(result.root.content[0].text)
    assert parsed.get("recorded") is True
    assert parsed.get("provider") == "anthropic"


async def test_call_tool_get_provider_fingerprint_returns_aggregate() -> None:
    import json as _json

    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="get_provider_fingerprint",
                arguments={"provider": "anthropic", "window_hours": 1},
            ),
        )
    )
    parsed = _json.loads(result.root.content[0].text)
    assert parsed["provider"] == "anthropic"
    # Mock pre-populates a regression-burst window with ≥10 samples in the last hour
    assert parsed["sample_count"] >= 10
    assert parsed["fingerprint"] is not None
    assert parsed["fingerprint"]["call_count"] >= 10


async def test_call_tool_detect_provider_regression_flags_critical_on_mock() -> None:
    """Mock pre-populates a 7d baseline at median latency ~800ms + last-hour burst at ~1500ms+
    → detect_provider_regression should flag at least one HIGH/CRITICAL alert on latency_p95."""
    import json as _json

    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="detect_provider_regression",
                arguments={
                    "provider": "anthropic",
                    "current_window_hours": 1,
                    "baseline_window_hours": 168,
                },
            ),
        )
    )
    parsed = _json.loads(result.root.content[0].text)
    assert parsed["provider"] == "anthropic"
    assert parsed["current_sample_count"] >= 10
    assert parsed["baseline_sample_count"] >= 10
    assert parsed["overall_severity"] in {"high", "critical"}
    metrics_flagged = {a["metric"] for a in parsed["alerts"]}
    assert "latency_p95" in metrics_flagged or "latency_median" in metrics_flagged


async def test_get_resource_provider_fingerprint_returns_json() -> None:
    import json as _json

    from mcp.types import ReadResourceRequest, ReadResourceRequestParams

    server = build_server("mock")
    handler = server.request_handlers[ReadResourceRequest]
    result = await handler(
        ReadResourceRequest(
            method="resources/read",
            params=ReadResourceRequestParams(uri="upgrade://provider-fingerprint"),  # type: ignore[arg-type]
        )
    )
    text = result.root.contents[0].text  # type: ignore[union-attr]
    parsed = _json.loads(text)
    assert parsed["provider"] == "anthropic"
    assert "fingerprint" in parsed


# ─────── Coverage gap fillers (overnight Phase 1B) ───────


async def test_call_tool_upgrade_guide_missing_target_returns_error() -> None:
    """Coverage: server.py:301-302 — empty target_version returns error."""
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server(backend_name="mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="upgrade_guide", arguments={"target_version": ""}
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


async def test_call_tool_post_upgrade_verify_missing_id_returns_error() -> None:
    """Coverage: server.py:308-309."""
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server(backend_name="mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="post_upgrade_verify", arguments={"pre_snapshot_id": ""}
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


async def test_call_tool_post_upgrade_verify_unknown_id_returns_error() -> None:
    """Coverage: server.py:311-317."""
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server(backend_name="mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="post_upgrade_verify",
                arguments={"pre_snapshot_id": "no-such-snapshot-12345"},
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed
    assert "not found" in parsed["error"].lower()


async def test_call_tool_rollback_guide_missing_id_returns_error() -> None:
    """Coverage: server.py:325-326."""
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server(backend_name="mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="rollback_guide", arguments={"snapshot_id": ""}
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


async def test_call_tool_rollback_guide_unknown_id_returns_error() -> None:
    """Coverage: server.py:328-334."""
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server(backend_name="mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="rollback_guide",
                arguments={"snapshot_id": "no-such-snapshot-12345"},
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


async def test_call_tool_get_provider_fingerprint_missing_provider() -> None:
    """Coverage: server.py:384-385."""
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server(backend_name="mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="get_provider_fingerprint", arguments={"provider": ""}
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


async def test_call_tool_detect_provider_regression_missing_provider() -> None:
    """Coverage: server.py:394-395."""
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server(backend_name="mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="detect_provider_regression", arguments={"provider": ""}
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


async def test_read_resource_unknown_uri_returns_error() -> None:
    """Coverage: server.py:466 — unknown URI fallback."""
    from mcp.types import ReadResourceRequest, ReadResourceRequestParams

    server = build_server(backend_name="mock")
    handler = server.request_handlers[ReadResourceRequest]
    result = await handler(
        ReadResourceRequest(
            method="resources/read",
            params=ReadResourceRequestParams(
                uri="upgrade://does-not-exist"  # type: ignore[arg-type]
            ),
        )
    )
    parsed = json.loads(result.root.contents[0].text)  # type: ignore[union-attr]
    assert "error" in parsed


async def test_get_prompt_unknown_returns_unknown() -> None:
    """Coverage: server.py — unknown prompt fallback."""
    from mcp.types import GetPromptRequest, GetPromptRequestParams

    server = build_server(backend_name="mock")
    handler = server.request_handlers[GetPromptRequest]
    result = await handler(
        GetPromptRequest(
            method="prompts/get",
            params=GetPromptRequestParams(name="not-a-prompt", arguments={}),
        )
    )
    text = result.root.messages[0].content.text
    assert "Unknown prompt" in text or "not-a-prompt" in text
