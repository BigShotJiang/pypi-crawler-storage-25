"""Tests for both backends (mock + openclaw-system)."""
from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

import pytest

from openclaw_upgrade_orchestrator_mcp.backends import available_backends, get_backend
from openclaw_upgrade_orchestrator_mcp.backends.mock import MockBackend
from openclaw_upgrade_orchestrator_mcp.backends.openclaw_system import OpenClawSystemBackend
from openclaw_upgrade_orchestrator_mcp.types import (
    CheckResult,
    CheckStatus,
    Severity,
    Snapshot,
)

# ─────────── Registry ───────────


def test_registry_includes_both_backends() -> None:
    backends = available_backends()
    assert "mock" in backends
    assert "openclaw-system" in backends


def test_get_backend_unknown_raises() -> None:
    with pytest.raises(KeyError):
        get_backend("does-not-exist")


def test_get_backend_returns_correct_name() -> None:
    assert get_backend("mock").name == "mock"
    assert get_backend("openclaw-system").name == "openclaw-system"


# ─────────── Mock backend ───────────


async def test_mock_collect_state_default_2026_4_23() -> None:
    b = MockBackend()
    state = await b.collect_state()
    assert state.current_version == "2026.4.23"
    # Default mock state simulates Discord-receive breakage
    assert state.discord_skill_receive_registered is False


async def test_mock_simulate_upgrade_changes_reported_version() -> None:
    b = MockBackend()
    b._simulate_upgrade("2026.5.2")
    state = await b.collect_state()
    assert state.current_version == "2026.5.2"
    # After leaving the breakage range, Discord receives again
    assert state.discord_skill_receive_registered is True


async def test_mock_snapshots_isolated_per_instance() -> None:
    b1 = MockBackend()
    b2 = MockBackend()
    snap = Snapshot(
        snapshot_id="s1",
        captured_at=datetime.now(UTC),
        version="2026.4.23",
        target_version=None,
        check_results=[],
        summary="test",
    )
    await b1.save_snapshot(snap)
    assert await b1.load_snapshot("s1") is not None
    assert await b2.load_snapshot("s1") is None


# ─────────── OpenClaw-system backend ───────────


async def test_system_backend_reads_version_from_file(tmp_path: Path, monkeypatch) -> None:
    version_file = tmp_path / "version"
    version_file.write_text("2026.4.27\n", encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_VERSION_FILE", str(version_file))
    monkeypatch.setenv("OPENCLAW_GATEWAY_CONFIG", str(tmp_path / "no-gateway.yaml"))
    monkeypatch.setenv("OPENCLAW_UPGRADE_SNAPSHOT_DIR", str(tmp_path / "snaps"))
    backend = OpenClawSystemBackend()
    state = await backend.collect_state()
    assert state.current_version == "2026.4.27"


async def test_system_backend_unknown_when_version_file_missing(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("OPENCLAW_VERSION_FILE", str(tmp_path / "nope"))
    monkeypatch.setenv("OPENCLAW_GATEWAY_CONFIG", str(tmp_path / "no-gateway.yaml"))
    monkeypatch.setenv("OPENCLAW_UPGRADE_SNAPSHOT_DIR", str(tmp_path / "snaps"))
    backend = OpenClawSystemBackend()
    state = await backend.collect_state()
    assert state.current_version == "unknown"


async def test_system_backend_reads_gateway_port(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "version").write_text("2026.4.27", encoding="utf-8")
    (tmp_path / "gateway.yaml").write_text("port: 18790\nother: value\n", encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_VERSION_FILE", str(tmp_path / "version"))
    monkeypatch.setenv("OPENCLAW_GATEWAY_CONFIG", str(tmp_path / "gateway.yaml"))
    monkeypatch.setenv("OPENCLAW_UPGRADE_SNAPSHOT_DIR", str(tmp_path / "snaps"))
    backend = OpenClawSystemBackend()
    state = await backend.collect_state()
    assert state.expected_gateway_port == 18790


async def test_system_backend_default_gateway_port_when_yaml_missing(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "version").write_text("2026.4.27", encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_VERSION_FILE", str(tmp_path / "version"))
    monkeypatch.setenv("OPENCLAW_GATEWAY_CONFIG", str(tmp_path / "missing.yaml"))
    monkeypatch.setenv("OPENCLAW_UPGRADE_SNAPSHOT_DIR", str(tmp_path / "snaps"))
    backend = OpenClawSystemBackend()
    state = await backend.collect_state()
    assert state.expected_gateway_port == 18789  # documented default


async def test_system_backend_persists_snapshot_to_disk(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "version").write_text("2026.4.27", encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_VERSION_FILE", str(tmp_path / "version"))
    monkeypatch.setenv("OPENCLAW_GATEWAY_CONFIG", str(tmp_path / "missing.yaml"))
    monkeypatch.setenv("OPENCLAW_UPGRADE_SNAPSHOT_DIR", str(tmp_path / "snaps"))
    backend = OpenClawSystemBackend()
    snap = Snapshot(
        snapshot_id="abc-123",
        captured_at=datetime.now(UTC),
        version="2026.4.27",
        target_version=None,
        check_results=[
            CheckResult(check_id="c1", status=CheckStatus.PASS, title="ok", severity=Severity.INFO),
        ],
        summary="test",
    )
    await backend.save_snapshot(snap)
    written = tmp_path / "snaps" / "abc-123.json"
    assert written.exists()
    data = json.loads(written.read_text(encoding="utf-8"))
    assert data["snapshot_id"] == "abc-123"


async def test_system_backend_load_snapshot_round_trip(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "version").write_text("2026.4.27", encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_VERSION_FILE", str(tmp_path / "version"))
    monkeypatch.setenv("OPENCLAW_GATEWAY_CONFIG", str(tmp_path / "missing.yaml"))
    monkeypatch.setenv("OPENCLAW_UPGRADE_SNAPSHOT_DIR", str(tmp_path / "snaps"))
    backend = OpenClawSystemBackend()
    snap = Snapshot(
        snapshot_id="rt-1",
        captured_at=datetime.now(UTC),
        version="2026.4.27",
        target_version="2026.5.2",
        check_results=[],
        summary="test",
    )
    await backend.save_snapshot(snap)
    loaded = await backend.load_snapshot("rt-1")
    assert loaded is not None
    assert loaded.snapshot_id == "rt-1"
    assert loaded.target_version == "2026.5.2"


async def test_system_backend_load_missing_returns_none(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("OPENCLAW_VERSION_FILE", str(tmp_path / "version"))
    monkeypatch.setenv("OPENCLAW_GATEWAY_CONFIG", str(tmp_path / "gw.yaml"))
    monkeypatch.setenv("OPENCLAW_UPGRADE_SNAPSHOT_DIR", str(tmp_path / "snaps"))
    backend = OpenClawSystemBackend()
    assert await backend.load_snapshot("nope") is None


async def test_system_backend_list_snapshots_skips_malformed(tmp_path: Path, monkeypatch) -> None:
    snap_dir = tmp_path / "snaps"
    snap_dir.mkdir()
    (snap_dir / "good.json").write_text(
        Snapshot(
            snapshot_id="good",
            captured_at=datetime.now(UTC),
            version="2026.4.27",
            target_version=None,
            check_results=[],
            summary="ok",
        ).model_dump_json(),
        encoding="utf-8",
    )
    (snap_dir / "broken.json").write_text("{not valid json", encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_VERSION_FILE", str(tmp_path / "version"))
    monkeypatch.setenv("OPENCLAW_GATEWAY_CONFIG", str(tmp_path / "gw.yaml"))
    monkeypatch.setenv("OPENCLAW_UPGRADE_SNAPSHOT_DIR", str(snap_dir))
    backend = OpenClawSystemBackend()
    snaps = await backend.list_snapshots()
    ids = {s.snapshot_id for s in snaps}
    assert ids == {"good"}


async def test_system_backend_list_snapshots_empty_when_dir_missing(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("OPENCLAW_VERSION_FILE", str(tmp_path / "version"))
    monkeypatch.setenv("OPENCLAW_GATEWAY_CONFIG", str(tmp_path / "gw.yaml"))
    monkeypatch.setenv("OPENCLAW_UPGRADE_SNAPSHOT_DIR", str(tmp_path / "nope"))
    backend = OpenClawSystemBackend()
    snaps = await backend.list_snapshots()
    assert snaps == []
