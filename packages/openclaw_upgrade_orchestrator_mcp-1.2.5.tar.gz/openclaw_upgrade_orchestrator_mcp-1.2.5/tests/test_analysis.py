"""Tests for the analysis orchestrator — guides + snapshots + post-upgrade reports."""
from __future__ import annotations

from datetime import UTC, datetime
from datetime import timedelta as _td

import pytest

from openclaw_upgrade_orchestrator_mcp.analysis import (
    available_upgrades_report,
    build_post_upgrade_report,
    build_provider_fingerprint_report,
    build_provider_regression_report,
    build_rollback_guide,
    build_snapshot,
    build_upgrade_guide,
    compute_fingerprint,
    current_version_info,
    detect_regression,
    regression_catalog_report,
    snapshot_list_report,
)
from openclaw_upgrade_orchestrator_mcp.backends.base import DeploymentState
from openclaw_upgrade_orchestrator_mcp.backends.mock import MockBackend
from openclaw_upgrade_orchestrator_mcp.types import (
    CheckResult,
    CheckStatus,
    ProviderCallRecord,
    Severity,
    Snapshot,
)


def _state(**overrides) -> DeploymentState:
    base = {
        "current_version": "2026.4.23",
        "available_versions": ["2026.4.24", "2026.4.25", "2026.4.27", "2026.5.2"],
        "listening_ports": [18789],
        "expected_gateway_port": 18789,
        "cpu_max_pct_15min": 23.5,
        "recent_oom_count_24h": 0,
        "skill_count": 18,
        "skill_cache_valid": True,
        "discord_skill_receive_registered": False,  # Sim being in 2026.4.23-26 breakage
        "cron_web_search_returns_results": True,
    }
    base.update(overrides)
    return DeploymentState(**base)


# ─────────── current_version_info ───────────


def test_current_version_info_known() -> None:
    info = current_version_info(_state(), detection_method="mock")
    assert info.version == "2026.4.23"
    assert info.detection_method == "mock"
    assert info.notes is None


def test_current_version_info_unknown_attaches_note() -> None:
    info = current_version_info(_state(current_version="unknown"), detection_method="mock")
    assert info.notes is not None and "Could not detect" in info.notes


# ─────────── available_upgrades_report ───────────


def test_available_upgrades_excludes_current_and_older() -> None:
    state = _state(current_version="2026.4.25", available_versions=["2026.4.20", "2026.4.25", "2026.5.2"])
    report = available_upgrades_report(state)
    versions = {u.version for u in report.upgrades}
    # Only versions strictly newer than current
    assert versions == {"2026.5.2"}


def test_available_upgrades_recommended_skips_critical() -> None:
    """If a target has any CRITICAL regression, it's not the recommended target."""
    state = _state(current_version="2026.4.7", available_versions=["2026.4.9", "2026.4.10"])
    report = available_upgrades_report(state)
    # 2026.4.9 is in the R-63002 CRITICAL range; 2026.4.10 is the fix
    assert report.recommended_target == "2026.4.10"


def test_available_upgrades_no_critical_in_path_recommends_highest() -> None:
    state = _state(
        current_version="2026.4.27",
        available_versions=["2026.5.1", "2026.5.2"],
    )
    report = available_upgrades_report(state)
    # No CRITICAL anywhere → recommended is the highest version
    assert report.recommended_target == "2026.5.2"


# ─────────── build_snapshot ───────────


def test_build_snapshot_runs_all_checks() -> None:
    state = _state()
    snapshot = build_snapshot(state, target_version="2026.4.27")
    assert snapshot.version == state.current_version
    assert snapshot.target_version == "2026.4.27"
    # 6 registered checks → 6 results
    assert len(snapshot.check_results) == 6


def test_build_snapshot_unique_id_per_call() -> None:
    state = _state()
    s1 = build_snapshot(state, target_version=None)
    s2 = build_snapshot(state, target_version=None)
    assert s1.snapshot_id != s2.snapshot_id


def test_build_snapshot_summary_counts_fails() -> None:
    state = _state(discord_skill_receive_registered=False)
    snapshot = build_snapshot(state, target_version=None)
    # 1 HIGH FAIL expected (Discord), no CRITICAL
    assert "1 FAIL" in snapshot.summary
    assert "0 CRITICAL" in snapshot.summary
    assert "1 HIGH" in snapshot.summary


# ─────────── build_upgrade_guide ───────────


def test_upgrade_guide_collects_applicable_regressions() -> None:
    state = _state(current_version="2026.4.23")
    guide = build_upgrade_guide(state, "2026.4.27")
    ids = {r.regression_id for r in guide.applicable_regressions}
    # R-41372 (current in range) and R-73421 (current in range) should both apply
    assert "R-41372-CRON-WEB-SEARCH-SILENT-FAIL" in ids
    assert "R-73421-DISCORD-RECEIVE-BREAKAGE" in ids


def test_upgrade_guide_steps_populated() -> None:
    state = _state()
    guide = build_upgrade_guide(state, "2026.4.27")
    assert len(guide.pre_upgrade_steps) >= 1
    assert len(guide.upgrade_steps) >= 3  # stop / upgrade / start
    assert len(guide.post_upgrade_steps) >= 1
    assert len(guide.rollback_steps) >= 3


def test_upgrade_guide_confidence_critical_when_critical_in_path() -> None:
    state = _state(current_version="2026.4.7")
    guide = build_upgrade_guide(state, "2026.4.9")
    # R-63002 CRITICAL is in this range
    assert "CRITICAL" in guide.confidence_note


def test_upgrade_guide_confidence_clean_when_no_regressions() -> None:
    state = _state(current_version="2026.5.5", available_versions=["2026.5.6"])
    guide = build_upgrade_guide(state, "2026.5.6")
    # No regressions in catalog apply to this future range
    if not guide.applicable_regressions:
        assert "No known regressions" in guide.confidence_note


def test_upgrade_guide_post_steps_include_discord_reload_when_relevant() -> None:
    state = _state(current_version="2026.4.23")
    guide = build_upgrade_guide(state, "2026.4.27")
    # R-73421 mentions "openclaw skill reload" → post_upgrade_steps should reference it
    has_reload_step = any(
        "discord" in (s.command or "").lower() or "reload" in (s.description or "").lower()
        for s in guide.post_upgrade_steps
    )
    assert has_reload_step


# ─────────── build_post_upgrade_report ───────────


def _snap_with_results(snapshot_id: str, version: str, results: list[CheckResult]) -> Snapshot:
    return Snapshot(
        snapshot_id=snapshot_id,
        captured_at=datetime.now(UTC),
        version=version,
        target_version=None,
        check_results=results,
        summary="test",
    )


def _result(check_id: str, status: CheckStatus, severity: Severity = Severity.HIGH) -> CheckResult:
    return CheckResult(
        check_id=check_id,
        status=status,
        title=f"check {check_id}",
        severity=severity,
    )


def test_post_upgrade_classifies_new_failure() -> None:
    pre = _snap_with_results("p", "2026.4.23", [_result("c1", CheckStatus.PASS)])
    post = _snap_with_results("q", "2026.4.27", [_result("c1", CheckStatus.FAIL, Severity.HIGH)])
    rep = build_post_upgrade_report(pre, post)
    assert len(rep.new_failures) == 1
    assert rep.new_failures[0].check_id == "c1"
    assert rep.overall_outcome == "regressed"


def test_post_upgrade_classifies_recovered() -> None:
    pre = _snap_with_results("p", "2026.4.23", [_result("c1", CheckStatus.FAIL)])
    post = _snap_with_results("q", "2026.4.27", [_result("c1", CheckStatus.PASS)])
    rep = build_post_upgrade_report(pre, post)
    assert len(rep.recovered) == 1
    assert rep.overall_outcome == "success"


def test_post_upgrade_classifies_unchanged_failure() -> None:
    pre = _snap_with_results("p", "2026.4.23", [_result("c1", CheckStatus.FAIL)])
    post = _snap_with_results("q", "2026.4.27", [_result("c1", CheckStatus.FAIL)])
    rep = build_post_upgrade_report(pre, post)
    assert len(rep.unchanged_failures) == 1
    assert rep.overall_outcome == "degraded"


def test_post_upgrade_unchanged_pass_increments_counter() -> None:
    pre = _snap_with_results("p", "2026.4.23", [_result("c1", CheckStatus.PASS)])
    post = _snap_with_results("q", "2026.4.27", [_result("c1", CheckStatus.PASS)])
    rep = build_post_upgrade_report(pre, post)
    assert rep.unchanged_passes_count == 1
    assert rep.overall_outcome == "success"


def test_post_upgrade_outcome_regressed_when_critical_new_failure() -> None:
    pre = _snap_with_results("p", "2026.4.23", [_result("c1", CheckStatus.PASS)])
    post = _snap_with_results("q", "2026.4.27", [_result("c1", CheckStatus.FAIL, Severity.CRITICAL)])
    rep = build_post_upgrade_report(pre, post)
    assert rep.overall_outcome == "regressed"


def test_post_upgrade_outcome_degraded_when_only_low_new_failure() -> None:
    pre = _snap_with_results("p", "2026.4.23", [_result("c1", CheckStatus.PASS)])
    post = _snap_with_results("q", "2026.4.27", [_result("c1", CheckStatus.FAIL, Severity.LOW)])
    rep = build_post_upgrade_report(pre, post)
    assert rep.overall_outcome == "degraded"


# ─────────── build_rollback_guide ───────────


def test_rollback_guide_has_steps_and_risk_note() -> None:
    snap = _snap_with_results("p", "2026.4.23", [_result("c1", CheckStatus.PASS)])
    guide = build_rollback_guide(snap)
    assert guide.target_version == "2026.4.23"
    assert len(guide.rollback_steps) >= 3
    assert "Rolling back" in guide.risk_note


# ─────────── catalog + snapshot list ───────────


def test_regression_catalog_unfiltered() -> None:
    rep = regression_catalog_report(None)
    assert rep.entry_count == len(rep.entries)
    assert rep.entry_count >= 5


def test_regression_catalog_filtered_to_version() -> None:
    rep = regression_catalog_report("2026.4.23")
    ids = {e.regression_id for e in rep.entries}
    assert "R-73421-DISCORD-RECEIVE-BREAKAGE" in ids


def test_snapshot_list_report_passes_through() -> None:
    snap = _snap_with_results("a", "2026.4.23", [_result("c1", CheckStatus.PASS)])
    rep = snapshot_list_report([snap])
    assert rep.snapshot_count == 1


# ─────────── End-to-end with mock backend ───────────


@pytest.fixture
def mock_backend() -> MockBackend:
    return MockBackend()


async def test_e2e_pre_upgrade_then_post_upgrade(mock_backend: MockBackend) -> None:
    """Capture pre-snapshot, simulate upgrade, capture post-snapshot, diff."""
    state = await mock_backend.collect_state()
    pre = build_snapshot(state, target_version="2026.5.2")
    await mock_backend.save_snapshot(pre)

    mock_backend._simulate_upgrade("2026.5.2")
    state2 = await mock_backend.collect_state()
    post = build_snapshot(state2, target_version=None)
    await mock_backend.save_snapshot(post)

    rep = build_post_upgrade_report(pre, post)
    # The Discord-receive failure should recover (we simulated leaving the breakage range)
    recovered_ids = {d.check_id for d in rep.recovered}
    assert "skills.discord_receive_registered" in recovered_ids
    assert rep.overall_outcome == "success"


async def test_snapshots_persist_through_backend(mock_backend: MockBackend) -> None:
    state = await mock_backend.collect_state()
    snap = build_snapshot(state, target_version="2026.5.2")
    await mock_backend.save_snapshot(snap)
    loaded = await mock_backend.load_snapshot(snap.snapshot_id)
    assert loaded is not None
    assert loaded.snapshot_id == snap.snapshot_id


async def test_load_unknown_snapshot_returns_none(mock_backend: MockBackend) -> None:
    assert await mock_backend.load_snapshot("nope") is None


async def test_list_snapshots_sorted_desc_by_captured_at(mock_backend: MockBackend) -> None:
    state = await mock_backend.collect_state()
    a = build_snapshot(state, target_version="2026.5.1")
    await mock_backend.save_snapshot(a)
    b = build_snapshot(state, target_version="2026.5.2")
    await mock_backend.save_snapshot(b)
    snaps = await mock_backend.list_snapshots()
    assert len(snaps) == 2
    # most recent first
    assert snaps[0].captured_at >= snaps[1].captured_at


# ─────────── v1.2 provider-fingerprint analysis ───────────


def _record(
    *,
    minutes_ago: int = 1,
    provider: str = "anthropic",
    model: str = "claude-sonnet-4-7",
    latency_ms: int = 800,
    response_length_tokens: int = 500,
    headers: dict[str, str] | None = None,
) -> ProviderCallRecord:
    return ProviderCallRecord(
        captured_at=datetime.now(UTC) - _td(minutes=minutes_ago),
        provider=provider,
        model=model,
        latency_ms=latency_ms,
        response_length_tokens=response_length_tokens,
        response_headers=headers or {},
    )


def test_compute_fingerprint_empty_returns_none() -> None:
    fp = compute_fingerprint([], "anthropic", datetime.now(UTC), datetime.now(UTC))
    assert fp is None


def test_compute_fingerprint_aggregates_correctly() -> None:
    records = [_record(latency_ms=ms) for ms in (500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400)]
    fp = compute_fingerprint(records, "anthropic", datetime.now(UTC), datetime.now(UTC))
    assert fp is not None
    assert fp.call_count == 10
    assert fp.median_latency_ms == pytest.approx(950.0, abs=10.0)
    # p95 of 500..1400 in 100-step list ≈ 1355
    assert 1300 < fp.p95_latency_ms < 1400


def test_provider_fingerprint_report_insufficient_data() -> None:
    records = [_record(minutes_ago=2)] * 3  # well below the 10-sample floor
    report = build_provider_fingerprint_report(records, "anthropic", window_hours=1)
    assert report.insufficient_data is True
    assert report.fingerprint is None
    assert "Insufficient" in (report.note or "")


def test_provider_fingerprint_report_filters_by_window() -> None:
    """Only records within window_hours should count toward sample_count."""
    inside = [_record(minutes_ago=5) for _ in range(15)]
    outside = [_record(minutes_ago=120) for _ in range(20)]  # 2hr ago, outside 1hr window
    report = build_provider_fingerprint_report(inside + outside, "anthropic", window_hours=1)
    assert report.insufficient_data is False
    assert report.sample_count == 15


def test_detect_regression_flags_latency_doubled() -> None:
    baseline = compute_fingerprint(
        [_record(latency_ms=800) for _ in range(20)],
        "anthropic",
        datetime.now(UTC),
        datetime.now(UTC),
    )
    current = compute_fingerprint(
        [_record(latency_ms=1800) for _ in range(20)],
        "anthropic",
        datetime.now(UTC),
        datetime.now(UTC),
    )
    assert baseline is not None and current is not None
    alerts = detect_regression(current, baseline, threshold_pct=30.0)
    assert any(a.metric == "latency_median" for a in alerts)
    # 1800 vs 800 = 125% delta → CRITICAL
    metric_to_alert = {a.metric: a for a in alerts}
    assert metric_to_alert["latency_median"].severity == Severity.CRITICAL


def test_detect_regression_no_alerts_when_within_threshold() -> None:
    baseline = compute_fingerprint(
        [_record(latency_ms=800) for _ in range(20)],
        "anthropic",
        datetime.now(UTC),
        datetime.now(UTC),
    )
    current = compute_fingerprint(
        [_record(latency_ms=850) for _ in range(20)],  # 6% delta — below threshold
        "anthropic",
        datetime.now(UTC),
        datetime.now(UTC),
    )
    assert baseline is not None and current is not None
    alerts = detect_regression(current, baseline, threshold_pct=30.0)
    assert all(a.metric != "latency_median" for a in alerts)


def test_detect_regression_flags_model_version_change() -> None:
    baseline = compute_fingerprint(
        [_record(headers={"anthropic-model-version": "v1"}) for _ in range(15)],
        "anthropic",
        datetime.now(UTC),
        datetime.now(UTC),
    )
    current = compute_fingerprint(
        [_record(headers={"anthropic-model-version": "v2"}) for _ in range(15)],
        "anthropic",
        datetime.now(UTC),
        datetime.now(UTC),
    )
    assert baseline is not None and current is not None
    alerts = detect_regression(current, baseline)
    version_alerts = [a for a in alerts if a.metric == "model_version"]
    assert len(version_alerts) >= 1
    assert version_alerts[0].severity == Severity.HIGH


def test_provider_regression_report_returns_critical_on_mock_burst() -> None:
    """End-to-end: feed the mock backend's history through build_provider_regression_report."""
    import asyncio

    backend = MockBackend()
    records = asyncio.run(backend.get_provider_calls(provider="anthropic"))
    report = build_provider_regression_report(
        records,
        "anthropic",
        current_window_hours=1,
        baseline_window_hours=168,
    )
    assert report.current_sample_count >= 10
    assert report.baseline_sample_count >= 10
    assert report.overall_severity in {Severity.HIGH, Severity.CRITICAL}
    assert any(a.metric == "latency_p95" or a.metric == "latency_median" for a in report.alerts)


def test_provider_regression_report_insufficient_samples() -> None:
    report = build_provider_regression_report(
        [],
        "anthropic",
        current_window_hours=1,
        baseline_window_hours=168,
    )
    assert report.alerts == []
    assert report.overall_severity == Severity.INFO
    assert "Insufficient" in report.summary
