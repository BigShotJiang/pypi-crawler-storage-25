"""Tests for the regression catalog + version arithmetic."""
from __future__ import annotations

from openclaw_upgrade_orchestrator_mcp.catalog import (
    _parse_version,
    _version_in_range,
    _version_le,
    _version_lt,
    all_regressions,
    regressions_for_version,
    regressions_in_path,
)
from openclaw_upgrade_orchestrator_mcp.types import Severity

# ─────────── Version arithmetic ───────────


def test_parse_version_handles_calver() -> None:
    assert _parse_version("2026.4.23") == (2026, 4, 23)


def test_parse_version_handles_hotfix_suffix() -> None:
    assert _parse_version("2026.4.23.1") == (2026, 4, 23, 1)


def test_parse_version_non_numeric_chunk_sorts_low() -> None:
    parsed = _parse_version("2026.4.23-rc1")
    assert parsed[0] == 2026
    assert parsed[2] == -1  # the "23-rc1" chunk fails int() and falls back to -1


def test_version_lt_basic() -> None:
    assert _version_lt("2026.4.10", "2026.4.20")
    assert not _version_lt("2026.4.20", "2026.4.10")
    assert not _version_lt("2026.4.20", "2026.4.20")


def test_version_le_includes_equal() -> None:
    assert _version_le("2026.4.20", "2026.4.20")
    assert _version_le("2026.4.10", "2026.4.20")
    assert not _version_le("2026.4.30", "2026.4.20")


def test_version_in_range_inclusive_low_exclusive_high() -> None:
    # Range [2026.4.20, 2026.5.1)
    assert _version_in_range("2026.4.20", "2026.4.20", "2026.5.1")  # low inclusive
    assert _version_in_range("2026.4.30", "2026.4.20", "2026.5.1")
    assert not _version_in_range("2026.5.1", "2026.4.20", "2026.5.1")  # high exclusive
    assert not _version_in_range("2026.4.19", "2026.4.20", "2026.5.1")


def test_version_in_range_open_high() -> None:
    # No fix → open-ended range
    assert _version_in_range("2026.5.10", "2026.4.30", None)
    assert _version_in_range("2030.1.1", "2026.4.30", None)


# ─────────── Catalog access ───────────


def test_catalog_nonempty() -> None:
    entries = all_regressions()
    assert len(entries) >= 5
    # Required marquee entries
    ids = {e.regression_id for e in entries}
    assert "R-41372-CRON-WEB-SEARCH-SILENT-FAIL" in ids
    assert "R-63002-POST-UPGRADE-CPU-SPIKE" in ids
    assert "R-73421-DISCORD-RECEIVE-BREAKAGE" in ids


def test_regressions_for_version_filters_by_version() -> None:
    # 2026.4.23 should be affected by R-41372 and R-73421 (both have ranges covering it)
    entries = regressions_for_version("2026.4.23")
    ids = {e.regression_id for e in entries}
    assert "R-41372-CRON-WEB-SEARCH-SILENT-FAIL" in ids
    assert "R-73421-DISCORD-RECEIVE-BREAKAGE" in ids
    # And NOT R-63002 (fixed at 2026.4.10)
    assert "R-63002-POST-UPGRADE-CPU-SPIKE" not in ids


def test_regressions_for_unaffected_version_returns_open_ended_only() -> None:
    """A version like 2030.1.1 should still match the open-ended (unfixed) regressions."""
    entries = regressions_for_version("2030.1.1")
    # R-OOM-DURING-LARGE-CONTEXT has no version_fixed — applies to all future versions
    ids = {e.regression_id for e in entries}
    assert "R-OOM-DURING-LARGE-CONTEXT-2026.4.30" in ids


def test_regressions_in_path_includes_target_range() -> None:
    """Upgrading 2026.4.7 → 2026.4.9 must include R-63002-POST-UPGRADE-CPU-SPIKE."""
    in_path = regressions_in_path("2026.4.7", "2026.4.9")
    ids = {e.regression_id for e in in_path}
    assert "R-63002-POST-UPGRADE-CPU-SPIKE" in ids


def test_regressions_in_path_includes_current_range() -> None:
    """If current is mid-regression, that regression is also in the path."""
    in_path = regressions_in_path("2026.4.23", "2026.5.5")
    ids = {e.regression_id for e in in_path}
    # R-73421 affects current → should be in path
    assert "R-73421-DISCORD-RECEIVE-BREAKAGE" in ids


def test_regressions_in_path_excludes_fully_passed() -> None:
    """A regression that ended before current is not in path."""
    in_path = regressions_in_path("2026.4.20", "2026.5.5")
    ids = {e.regression_id for e in in_path}
    # R-CLAWHUB-CACHE-POISONING was 2026.3.28 - 2026.4.2 → fully past at current=2026.4.20
    assert "R-CLAWHUB-CACHE-POISONING-2026.3.28" not in ids


def test_every_catalog_entry_has_required_fields() -> None:
    for e in all_regressions():
        assert e.regression_id.strip()
        assert e.title.strip()
        assert e.description.strip()
        assert e.mitigation.strip()
        assert isinstance(e.severity, Severity)
        assert e.version_introduced.strip()


def test_catalog_field_reports_link_format_consistent() -> None:
    for e in all_regressions():
        for fr in e.field_reports:
            # All field reports should be URL-shaped or use the openclaw:// scheme
            assert "://" in fr or fr.startswith("openclaw://"), e.regression_id
