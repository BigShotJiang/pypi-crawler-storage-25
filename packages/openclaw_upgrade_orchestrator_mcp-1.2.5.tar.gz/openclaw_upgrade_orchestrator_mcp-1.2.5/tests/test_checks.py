"""Tests for individual detection checks."""
from __future__ import annotations

from openclaw_upgrade_orchestrator_mcp.backends.base import DeploymentState
from openclaw_upgrade_orchestrator_mcp.checks import (
    CHECKS,
    check_cpu_under_threshold,
    check_cron_web_search,
    check_discord_receive_registered,
    check_gateway_expected_port,
    check_recent_oom_count,
    check_skill_cache_validity,
    run_all_checks,
)
from openclaw_upgrade_orchestrator_mcp.types import CheckStatus, Severity


def _state(**overrides) -> DeploymentState:
    base = {
        "current_version": "2026.4.23",
        "available_versions": [],
        "listening_ports": [18789],
        "expected_gateway_port": 18789,
        "cpu_max_pct_15min": 25.0,
        "recent_oom_count_24h": 0,
        "skill_count": 10,
        "skill_cache_valid": True,
        "discord_skill_receive_registered": True,
        "cron_web_search_returns_results": True,
    }
    base.update(overrides)
    return DeploymentState(**base)


# ─────────── Cron web search ───────────


def test_cron_web_search_pass() -> None:
    r = check_cron_web_search(_state(cron_web_search_returns_results=True))
    assert r.status == CheckStatus.PASS


def test_cron_web_search_fail_high() -> None:
    r = check_cron_web_search(_state(cron_web_search_returns_results=False))
    assert r.status == CheckStatus.FAIL
    assert r.severity == Severity.HIGH
    assert "R-41372" in (r.description or "")


def test_cron_web_search_unknown_when_none() -> None:
    r = check_cron_web_search(_state(cron_web_search_returns_results=None))
    assert r.status == CheckStatus.UNKNOWN


# ─────────── CPU threshold ───────────


def test_cpu_threshold_pass_under_85() -> None:
    r = check_cpu_under_threshold(_state(cpu_max_pct_15min=84.9))
    assert r.status == CheckStatus.PASS


def test_cpu_threshold_fail_over_85_critical() -> None:
    r = check_cpu_under_threshold(_state(cpu_max_pct_15min=92.5))
    assert r.status == CheckStatus.FAIL
    assert r.severity == Severity.CRITICAL


def test_cpu_threshold_unknown_when_none() -> None:
    r = check_cpu_under_threshold(_state(cpu_max_pct_15min=None))
    assert r.status == CheckStatus.UNKNOWN


# ─────────── OOM ───────────


def test_oom_pass_when_zero() -> None:
    r = check_recent_oom_count(_state(recent_oom_count_24h=0))
    assert r.status == CheckStatus.PASS


def test_oom_fail_high_when_few() -> None:
    r = check_recent_oom_count(_state(recent_oom_count_24h=2))
    assert r.status == CheckStatus.FAIL
    assert r.severity == Severity.HIGH


def test_oom_fail_critical_when_many() -> None:
    r = check_recent_oom_count(_state(recent_oom_count_24h=10))
    assert r.status == CheckStatus.FAIL
    assert r.severity == Severity.CRITICAL


# ─────────── Discord receive ───────────


def test_discord_receive_pass_when_registered() -> None:
    r = check_discord_receive_registered(_state(discord_skill_receive_registered=True))
    assert r.status == CheckStatus.PASS


def test_discord_receive_fail_high_when_not_registered() -> None:
    r = check_discord_receive_registered(_state(discord_skill_receive_registered=False))
    assert r.status == CheckStatus.FAIL
    assert r.severity == Severity.HIGH
    assert "R-73421" in (r.description or "")


def test_discord_receive_unknown_when_none() -> None:
    """No discord skill installed → check is non-applicable, not a failure."""
    r = check_discord_receive_registered(_state(discord_skill_receive_registered=None))
    assert r.status == CheckStatus.UNKNOWN


# ─────────── Gateway port ───────────


def test_gateway_port_pass_when_listening() -> None:
    r = check_gateway_expected_port(_state(expected_gateway_port=18789, listening_ports=[18789, 18790]))
    assert r.status == CheckStatus.PASS


def test_gateway_port_fail_when_not_listening() -> None:
    r = check_gateway_expected_port(_state(expected_gateway_port=18789, listening_ports=[18799]))
    assert r.status == CheckStatus.FAIL
    assert r.severity == Severity.MEDIUM


def test_gateway_port_unknown_when_no_listening_ports_reported() -> None:
    r = check_gateway_expected_port(_state(expected_gateway_port=18789, listening_ports=[]))
    assert r.status == CheckStatus.UNKNOWN


# ─────────── Skill cache ───────────


def test_skill_cache_pass_when_valid() -> None:
    r = check_skill_cache_validity(_state(skill_cache_valid=True))
    assert r.status == CheckStatus.PASS


def test_skill_cache_fail_when_invalid() -> None:
    r = check_skill_cache_validity(_state(skill_cache_valid=False))
    assert r.status == CheckStatus.FAIL
    assert r.severity == Severity.HIGH


# ─────────── Registry + run_all_checks ───────────


def test_registry_contains_expected_keys() -> None:
    expected = {
        "cron.web_search_returns_results",
        "resources.cpu_under_threshold",
        "resources.recent_oom_count",
        "skills.discord_receive_registered",
        "gateway.expected_port_listening",
        "skills.cache_validity",
    }
    assert set(CHECKS.keys()) == expected


def test_run_all_checks_returns_one_per_registered_check() -> None:
    results = run_all_checks(_state())
    assert len(results) == len(CHECKS)
    # All check_ids appear exactly once
    ids = {r.check_id for r in results}
    assert ids == set(CHECKS.keys())


def test_run_all_checks_clean_state_no_failures() -> None:
    """A clean state should produce zero FAILs."""
    results = run_all_checks(_state())
    fails = [r for r in results if r.status == CheckStatus.FAIL]
    assert fails == []
