"""Trust scoring for agents submitting tiles."""
import math
import time
from dataclasses import dataclass, field


@dataclass
class TrustScore:
    agent_id: str
    score: float = 0.5
    submissions: int = 0
    rejections: int = 0
    last_submission: float = 0.0
    decay_rate: float = 0.01  # per hour

    @property
    def acceptance_rate(self) -> float:
        total = self.submissions + self.rejections
        return self.submissions / total if total > 0 else 0.5

    @property
    def is_trusted(self) -> bool:
        return self.score >= 0.5

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "score": round(self.score, 4),
            "submissions": self.submissions,
            "rejections": self.rejections,
            "acceptance_rate": round(self.acceptance_rate, 4),
        }


class TrustManager:
    """Manage trust scores for fleet agents."""

    def __init__(self, default_score: float = 0.5, decay_rate: float = 0.01):
        self._scores: dict[str, TrustScore] = {}
        self._default_score = default_score
        self._decay_rate = decay_rate

    def get_score(self, agent_id: str) -> TrustScore:
        if agent_id not in self._scores:
            self._scores[agent_id] = TrustScore(
                agent_id=agent_id,
                score=self._default_score,
                decay_rate=self._decay_rate,
            )
        return self._scores[agent_id]

    def record_submission(self, agent_id: str, accepted: bool, quality: float = 0.7):
        """Record a tile submission. Quality 0.0-1.0."""
        ts = self.get_score(agent_id)
        ts.last_submission = time.time()

        if accepted:
            ts.submissions += 1
            # Increase trust: weighted by quality
            delta = (quality - 0.5) * 0.1
            ts.score = min(1.0, ts.score + delta)
        else:
            ts.rejections += 1
            # Decrease trust: penalty
            ts.score = max(0.0, ts.score - 0.05)

    def apply_decay(self, agent_id: str):
        """Apply time-based trust decay."""
        ts = self.get_score(agent_id)
        hours_since = (time.time() - ts.last_submission) / 3600
        ts.score = max(0.0, ts.score * math.exp(-ts.decay_rate * hours_since))

    def recover(self, agent_id: str, amount: float = 0.1):
        """Manually recover trust (e.g., after investigation)."""
        ts = self.get_score(agent_id)
        ts.score = min(1.0, ts.score + amount)

    def quarantine(self, agent_id: str) -> bool:
        """Quarantine a suspicious agent (trust < 0.2)."""
        ts = self.get_score(agent_id)
        ts.score = 0.0
        return True

    def is_quarantined(self, agent_id: str) -> bool:
        return self.get_score(agent_id).score < 0.1

    def top_agents(self, n: int = 10) -> list[TrustScore]:
        """Get top N agents by trust score."""
        scores = sorted(self._scores.values(), key=lambda s: s.score, reverse=True)
        return scores[:n]

    def blast_radius(self, agent_id: str) -> dict:
        """Calculate blast radius of a compromised agent."""
        ts = self.get_score(agent_id)
        return {
            "agent_id": agent_id,
            "trust_score": ts.score,
            "total_submissions": ts.submissions,
            "potential_bad_tiles": ts.submissions,  # worst case: all tiles bad
            "trust_impact": "HIGH" if ts.score > 0.7 else "MEDIUM" if ts.score > 0.4 else "LOW",
        }
