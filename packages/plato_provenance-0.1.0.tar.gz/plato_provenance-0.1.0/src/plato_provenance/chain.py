"""Provenance chain — hash chain verification for tile ancestry."""
import hashlib
from dataclasses import dataclass, field
from .signer import SignedTile


@dataclass
class ChainLink:
    tile_id: str
    parent_ids: list[str]
    chain_hash: str  # hash(tile_id + parent_chain_hashes)

    def to_dict(self) -> dict:
        return {"tile_id": self.tile_id, "parent_ids": self.parent_ids, "chain_hash": self.chain_hash}


class ProvenanceChain:
    """Hash chain for tile provenance. Detects tampering in ancestry."""

    def __init__(self):
        self._links: dict[str, ChainLink] = {}

    def add_tile(self, tile: SignedTile) -> ChainLink:
        """Add a tile to the chain."""
        parent_hashes = []
        for pid in tile.parents:
            if pid in self._links:
                parent_hashes.append(self._links[pid].chain_hash)
            else:
                parent_hashes.append("ORPHAN:" + pid)

        chain_input = f"{tile.tile_id}:{':'.join(sorted(parent_hashes))}"
        chain_hash = hashlib.sha256(chain_input.encode()).hexdigest()[:16]

        link = ChainLink(
            tile_id=tile.tile_id,
            parent_ids=list(tile.parents),
            chain_hash=chain_hash,
        )
        self._links[tile.tile_id] = link
        return link

    def verify_chain(self, tile_id: str, tiles: dict[str, SignedTile]) -> bool:
        """Verify the full provenance chain for a tile."""
        if tile_id not in self._links:
            return False

        link = self._links[tile_id]

        # Recompute chain hash
        parent_hashes = []
        for pid in link.parent_ids:
            if pid in self._links:
                parent_hashes.append(self._links[pid].chain_hash)
            else:
                parent_hashes.append("ORPHAN:" + pid)

        chain_input = f"{tile_id}:{':'.join(sorted(parent_hashes))}"
        expected_hash = hashlib.sha256(chain_input.encode()).hexdigest()[:16]

        return link.chain_hash == expected_hash

    def get_ancestry(self, tile_id: str, max_depth: int = 10) -> list[str]:
        """Get the ancestry chain (tile IDs) up to max_depth."""
        ancestry = []
        current = tile_id
        for _ in range(max_depth):
            if current not in self._links:
                break
            link = self._links[current]
            ancestry.append(current)
            if not link.parent_ids:
                break
            current = link.parent_ids[0]
        return ancestry

    def detect_tamper(self, tile_id: str, tiles: dict[str, SignedTile]) -> list[str]:
        """Find tiles with broken chain hashes in the ancestry."""
        broken = []
        for tid in self.get_ancestry(tile_id):
            if not self.verify_chain(tid, tiles):
                broken.append(tid)
        return broken

    @property
    def size(self) -> int:
        return len(self._links)
