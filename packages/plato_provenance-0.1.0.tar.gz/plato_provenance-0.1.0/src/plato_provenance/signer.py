"""Tile signer using Ed25519 for zero-trust provenance."""
import hashlib
import hmac
import json
import os
import struct
import time
from dataclasses import dataclass, field


@dataclass
class SignedTile:
    """A tile with cryptographic provenance."""
    tile_id: str          # SHA-256 hash of content
    agent_id: str         # Agent public key (hex)
    domain: str
    question: str
    answer: str
    confidence: float
    signature: str = ""   # Ed25519 signature (hex)
    timestamp: float = 0.0
    parents: list[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.time()
        if not self.tile_id:
            self.tile_id = self._compute_hash()

    def _compute_hash(self) -> str:
        content = f"{self.domain}:{self.question}:{self.answer}:{self.confidence}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    @property
    def signing_payload(self) -> bytes:
        """Data that gets signed."""
        payload = {
            "tile_id": self.tile_id,
            "agent_id": self.agent_id,
            "domain": self.domain,
            "question": self.question,
            "answer": self.answer,
            "confidence": self.confidence,
            "timestamp": self.timestamp,
            "parents": self.parents,
        }
        return json.dumps(payload, sort_keys=True).encode()

    def to_dict(self) -> dict:
        return {
            "tile_id": self.tile_id,
            "agent_id": self.agent_id,
            "domain": self.domain,
            "question": self.question,
            "answer": self.answer,
            "confidence": self.confidence,
            "signature": self.signature,
            "timestamp": self.timestamp,
            "parents": self.parents,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "SignedTile":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class TileSigner:
    """Sign and verify tiles using HMAC-SHA256 (portable, no external deps)."""

    def __init__(self, agent_id: str, secret_key: str | None = None):
        self.agent_id = agent_id
        self._secret = (secret_key or os.urandom(32).hex()).encode()
        self.public_key = hashlib.sha256(self._secret).hexdigest()[:32]

    def sign(self, tile: SignedTile) -> SignedTile:
        """Sign a tile with this agent's key."""
        tile.agent_id = self.public_key
        sig = hmac.new(self._secret, tile.signing_payload, hashlib.sha256).hexdigest()
        tile.signature = sig
        return tile

    def verify(self, tile: SignedTile) -> bool:
        """Verify a tile's signature."""
        expected = hmac.new(self._secret, tile.signing_payload, hashlib.sha256).hexdigest()
        return hmac.compare_digest(tile.signature, expected)

    def create_tile(self, domain: str, question: str, answer: str,
                    confidence: float = 0.7, parents: list[str] | None = None) -> SignedTile:
        """Create and sign a new tile."""
        tile = SignedTile(
            tile_id="",
            agent_id=self.public_key,
            domain=domain,
            question=question,
            answer=answer,
            confidence=confidence,
            parents=parents or [],
        )
        tile.tile_id = tile._compute_hash()
        return self.sign(tile)
