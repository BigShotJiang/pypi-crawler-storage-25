"""Audit logging for security-relevant events."""
import json
import time
from dataclasses import dataclass, field, asdict
from enum import IntEnum
from pathlib import Path


class AuditEventType(IntEnum):
    TILE_SUBMITTED = 1
    TILE_ACCEPTED = 2
    TILE_REJECTED = 3
    AGENT_REGISTERED = 4
    AGENT_QUARANTINED = 5
    AGENT_RECOVERED = 6
    KEY_ROTATED = 7
    CHAIN_TAMPER_DETECTED = 8
    TRUST_DECAY = 9


@dataclass
class AuditEvent:
    event_type: AuditEventType
    agent_id: str
    details: dict = field(default_factory=dict)
    timestamp: float = 0.0
    severity: str = "INFO"  # INFO, WARN, CRITICAL

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.time()

    def to_dict(self) -> dict:
        return {
            "event_type": self.event_type.name,
            "agent_id": self.agent_id,
            "details": self.details,
            "timestamp": self.timestamp,
            "severity": self.severity,
        }

    def to_jsonl(self) -> str:
        return json.dumps(self.to_dict())


class AuditLog:
    """Append-only audit log for security events."""

    def __init__(self, max_events: int = 10000):
        self._events: list[AuditEvent] = []
        self._max = max_events

    def log(self, event_type: AuditEventType, agent_id: str,
            details: dict | None = None, severity: str = "INFO"):
        event = AuditEvent(
            event_type=event_type,
            agent_id=agent_id,
            details=details or {},
            severity=severity,
        )
        self._events.append(event)
        if len(self._events) > self._max:
            self._events = self._events[-self._max:]

    def query(self, agent_id: str | None = None,
              event_type: AuditEventType | None = None,
              severity: str | None = None,
              limit: int = 100) -> list[AuditEvent]:
        results = self._events
        if agent_id:
            results = [e for e in results if e.agent_id == agent_id]
        if event_type:
            results = [e for e in results if e.event_type == event_type]
        if severity:
            results = [e for e in results if e.severity == severity]
        return results[-limit:]

    def count_by_type(self) -> dict[str, int]:
        counts = {}
        for e in self._events:
            name = e.event_type.name
            counts[name] = counts.get(name, 0) + 1
        return counts

    def export_jsonl(self) -> str:
        return "\n".join(e.to_jsonl() for e in self._events)

    def save(self, path: str):
        Path(path).write_text(self.export_jsonl())

    @property
    def size(self) -> int:
        return len(self._events)
