"""Tests for PLATO Provenance."""
import pytest
from plato_provenance import (
    TileSigner, SignedTile, ProvenanceChain,
    TrustManager, TrustScore, AuditLog, AuditEvent,
)
from plato_provenance.audit import AuditEventType


class TestSigning:
    def test_sign_and_verify(self):
        signer = TileSigner("agent-1")
        tile = signer.create_tile("test", "Q?", "A!", 0.8)
        assert tile.signature != ""
        assert signer.verify(tile)

    def test_tampered_tile_fails(self):
        signer = TileSigner("agent-1")
        tile = signer.create_tile("test", "Q?", "A!", 0.8)
        tile.answer = "TAMPERED"
        assert not signer.verify(tile)

    def test_different_agents(self):
        s1 = TileSigner("agent-1")
        s2 = TileSigner("agent-2")
        tile = s1.create_tile("test", "Q?", "A!", 0.8)
        assert not s2.verify(tile)  # s2 can't verify s1's tile


class TestProvenanceChain:
    def test_chain_creation(self):
        chain = ProvenanceChain()
        signer = TileSigner("agent-1")
        t1 = signer.create_tile("test", "Q1?", "A1!", 0.8)
        chain.add_tile(t1)
        assert chain.size == 1

    def test_chain_with_parents(self):
        chain = ProvenanceChain()
        signer = TileSigner("agent-1")
        t1 = signer.create_tile("test", "Q1?", "A1!", 0.8)
        chain.add_tile(t1)
        t2 = signer.create_tile("test", "Q2?", "A2!", 0.9, parents=[t1.tile_id])
        chain.add_tile(t2)
        assert chain.size == 2
        assert chain.verify_chain(t2.tile_id, {})

    def test_ancestry(self):
        chain = ProvenanceChain()
        signer = TileSigner("agent-1")
        t1 = signer.create_tile("test", "Q1?", "A1!", 0.8)
        chain.add_tile(t1)
        t2 = signer.create_tile("test", "Q2?", "A2!", 0.9, parents=[t1.tile_id])
        chain.add_tile(t2)
        t3 = signer.create_tile("test", "Q3?", "A3!", 0.85, parents=[t2.tile_id])
        chain.add_tile(t3)
        ancestry = chain.get_ancestry(t3.tile_id)
        assert len(ancestry) == 3


class TestTrustManager:
    def test_initial_score(self):
        tm = TrustManager()
        score = tm.get_score("agent-1")
        assert score.score == 0.5

    def test_good_submission_increases_trust(self):
        tm = TrustManager()
        tm.record_submission("agent-1", accepted=True, quality=0.9)
        assert tm.get_score("agent-1").score > 0.5

    def test_bad_submission_decreases_trust(self):
        tm = TrustManager()
        tm.record_submission("agent-1", accepted=False)
        assert tm.get_score("agent-1").score < 0.5

    def test_quarantine(self):
        tm = TrustManager()
        tm.quarantine("agent-1")
        assert tm.is_quarantined("agent-1")

    def test_blast_radius(self):
        tm = TrustManager()
        for _ in range(10):
            tm.record_submission("agent-1", accepted=True, quality=0.8)
        br = tm.blast_radius("agent-1")
        assert br["potential_bad_tiles"] == 10


class TestAuditLog:
    def test_log_and_query(self):
        log = AuditLog()
        log.log(AuditEventType.TILE_ACCEPTED, "agent-1", {"domain": "test"})
        log.log(AuditEventType.TILE_REJECTED, "agent-2", {"reason": "bad"})
        assert log.size == 2
        results = log.query(agent_id="agent-1")
        assert len(results) == 1

    def test_export_jsonl(self):
        log = AuditLog()
        log.log(AuditEventType.AGENT_QUARANTINED, "agent-bad", severity="CRITICAL")
        output = log.export_jsonl()
        assert "QUARANTINED" in output
        assert "CRITICAL" in output
