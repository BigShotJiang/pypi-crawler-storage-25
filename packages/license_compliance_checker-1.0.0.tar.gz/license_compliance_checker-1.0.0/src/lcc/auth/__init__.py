# Copyright 2025 Ajay Pundhir
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Authentication and authorization module."""

from lcc.auth.core import (
    Token,
    TokenData,
    User,
    UserRole,
    authenticate_user,
    create_access_token,
    create_refresh_token,
    get_current_active_user,
    get_current_user,
    get_password_hash,
    require_role,
    verify_password,
)

__all__ = [
    "User",
    "UserRole",
    "Token",
    "TokenData",
    "authenticate_user",
    "create_access_token",
    "create_refresh_token",
    "get_current_user",
    "get_current_active_user",
    "require_role",
    "get_password_hash",
    "verify_password",
]
