# Copyright 2025 Ajay Pundhir
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Filesystem helpers.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from pathlib import Path


def iter_files(root: Path, patterns: Iterable[str]) -> Iterator[Path]:
    """
    Yield files matching one of the glob patterns relative to root.
    """

    for pattern in patterns:
        yield from root.glob(pattern)

