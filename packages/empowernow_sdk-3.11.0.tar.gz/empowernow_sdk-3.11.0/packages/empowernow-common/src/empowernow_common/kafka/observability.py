"""Kafka observability: metrics collection and alert definitions.

Provides structured metrics that services can expose via ``/metrics``
(Prometheus) or ``/health/deps`` (JSON).  This is the single source of
truth for Kafka transport health metrics across the platform.

Usage
-----
from empowernow_common.kafka.observability import KafkaMetrics

metrics = KafkaMetrics.snapshot()
# {
#     "circuit_breaker_state": "closed",
#     "published_total": 1234,
#     "dropped_cb_open_total": 5,
#     "dropped_error_total": 2,
#     "retries_total": 10,
#     "producer_connected": True,
# }

alert_rules = KafkaMetrics.alert_definitions()
"""
from __future__ import annotations

from typing import Any, Dict, List


class KafkaMetrics:
    """Aggregated Kafka transport metrics."""

    @staticmethod
    def snapshot() -> Dict[str, Any]:
        """Return current metrics snapshot for scraping.

        Combines PlatformProducer metrics with circuit breaker state.
        """
        from empowernow_common.kafka.platform_producer import get_kafka_health

        health = get_kafka_health()
        cb = health.get("circuit_breaker", {})
        counters = health.get("metrics", {})

        return {
            "circuit_breaker_state": cb.get("state", "uninitialized"),
            "circuit_breaker_failure_count": cb.get("failure_count", 0),
            "published_total": counters.get("published", 0),
            "dropped_cb_open_total": counters.get("dropped_cb_open", 0),
            "dropped_error_total": counters.get("dropped_error", 0),
            "retries_total": counters.get("retries", 0),
            "producer_connected": health.get("producer_connected", False),
            "enabled": health.get("enabled", True),
        }

    @staticmethod
    def alert_definitions() -> List[Dict[str, Any]]:
        """Return structured alert rule definitions.

        These can be used to generate Prometheus AlertManager rules or
        Grafana alert rules.  Alerts fire on structured fields from the
        ``/health`` endpoint, not on HTTP status codes.
        """
        return [
            {
                "name": "kafka_circuit_breaker_open",
                "severity": "warning",
                "description": "Kafka circuit breaker is open -- events being dropped or queued",
                "condition": "circuit_breaker_state == 'open'",
                "for": "30s",
                "labels": {"component": "kafka", "team": "platform"},
            },
            {
                "name": "kafka_high_drop_rate",
                "severity": "warning",
                "description": "High rate of dropped Kafka events",
                "condition": "rate(dropped_cb_open_total[5m]) + rate(dropped_error_total[5m]) > 10",
                "for": "5m",
                "labels": {"component": "kafka", "team": "platform"},
            },
            {
                "name": "kafka_producer_disconnected",
                "severity": "critical",
                "description": "Kafka producer is not connected",
                "condition": "producer_connected == false AND enabled == true",
                "for": "2m",
                "labels": {"component": "kafka", "team": "platform"},
            },
            {
                "name": "kafka_outbox_depth_high",
                "severity": "warning",
                "description": "Event outbox has accumulated pending events",
                "condition": "outbox_pending_count > 1000",
                "for": "5m",
                "labels": {"component": "outbox", "team": "platform"},
            },
            {
                "name": "kafka_outbox_poison_messages",
                "severity": "critical",
                "description": "Dead-lettered events require operator attention",
                "condition": "outbox_dead_letter_count > 0",
                "for": "1m",
                "labels": {"component": "outbox", "team": "platform"},
            },
            {
                "name": "kafka_recovery_slow",
                "severity": "warning",
                "description": "Kafka recovery taking longer than SLO",
                "condition": "time_since_cb_opened > 120 AND circuit_breaker_state != 'closed'",
                "for": "0s",
                "labels": {"component": "kafka", "team": "platform"},
            },
        ]
