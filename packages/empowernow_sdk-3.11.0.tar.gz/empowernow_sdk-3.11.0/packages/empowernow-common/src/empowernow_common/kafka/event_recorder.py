"""EventRecorder -- durable event recording for governance-grade events.

This module provides the *business layer* abstraction for recording events
that must survive Kafka outages.  It writes events to a database outbox table
in the **same transaction** as the business state change, guaranteeing
atomicity.  A separate ``OutboxPublisher`` drains the outbox to Kafka via
``PlatformProducer``.

Usage
-----
from empowernow_common.kafka.event_recorder import EventRecorder, DurableEvent

async with db_transaction() as session:
    # business write
    session.add(my_entity)

    # durable event -- committed atomically with the business write
    await EventRecorder.record(
        session,
        DurableEvent(
            topic="audit.privileged_action",
            event_type="access_request.approved",
            aggregate_id="ar:12345",
            ordering_key="tenant:acme",
            payload={"request_id": "12345", "approver": "admin"},
            correlation_id="corr-abc",
        ),
    )

The outbox table schema is compatible with the existing UEAS
``automation_outbox`` pattern and can be extended to any service that
needs governance-grade event durability.

Design principles
-----------------
- The outbox is the source of truth; Kafka is the delivery transport.
- The business transaction owns the durability guarantee.
- Every durable event carries an idempotency key so consumers can
  deduplicate retries.
- Poison messages (events that repeatedly fail to publish) are moved
  to a dead-letter state for operator replay.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict
from uuid import UUID, uuid5

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

OUTBOX_NAMESPACE = UUID("b4c7d8e9-2345-6789-abcd-ef0123456789")


class OutboxStatus(str, Enum):
    PENDING = "pending"
    PUBLISHING = "publishing"
    SENT = "sent"
    FAILED = "failed"
    DEAD_LETTER = "dead_letter"


@dataclass
class DurableEvent:
    """A governance-grade event to be recorded in the outbox.

    All fields are set by the caller at record time.  The ``EventRecorder``
    derives ``event_id`` and ``idempotency_key`` deterministically when not
    provided, so retries of the same business operation produce the same
    event identity.
    """

    topic: str
    event_type: str
    aggregate_id: str
    payload: Dict[str, Any]
    ordering_key: str = ""
    correlation_id: str = ""
    schema_version: str = "1.0"
    event_id: str = ""
    idempotency_key: str = ""
    headers: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        if not self.correlation_id:
            self.correlation_id = uuid.uuid4().hex
        if not self.event_id:
            basis = f"{self.aggregate_id}:{self.event_type}:{self.correlation_id}"
            self.event_id = str(uuid5(OUTBOX_NAMESPACE, basis))
        if not self.idempotency_key:
            payload_hash = hashlib.sha256(
                json.dumps(self.payload, sort_keys=True, default=str).encode()
            ).hexdigest()[:16]
            self.idempotency_key = f"{self.event_id}:{payload_hash}"


class EventRecorder:
    """Records durable events into the outbox within a database transaction.

    This is intentionally a simple class with a single static-style method.
    It does NOT start or commit transactions -- the caller owns the session
    and transaction boundary.  This ensures the outbox write is atomic with
    the business state change.
    """

    DEFAULT_MAX_ATTEMPTS = 10

    @staticmethod
    async def record(
        session: "AsyncSession",
        event: DurableEvent,
        *,
        max_attempts: int = 10,
        service_name: str = "",
    ) -> str:
        """Write a durable event to the outbox table.

        Must be called inside an active database transaction (the same one
        that performs the business state change).

        Args:
            session: SQLAlchemy AsyncSession (already in a transaction).
            event: The event to record.
            max_attempts: Max publish attempts before dead-lettering.
            service_name: Originating service name for tracing.

        Returns:
            The ``event_id`` of the recorded event.
        """
        from sqlalchemy import text

        now = time.time()

        await session.execute(
            text("""
                INSERT INTO event_outbox (
                    event_id, topic, event_type, aggregate_id,
                    ordering_key, correlation_id, idempotency_key,
                    schema_version, payload_json, headers,
                    status, service_name, max_attempts,
                    attempt_count, created_at, updated_at
                ) VALUES (
                    :event_id, :topic, :event_type, :aggregate_id,
                    :ordering_key, :correlation_id, :idempotency_key,
                    :schema_version, :payload_json, :headers,
                    :status, :service_name, :max_attempts,
                    0, :created_at, :created_at
                )
                ON CONFLICT (idempotency_key) DO NOTHING
            """),
            {
                "event_id": event.event_id,
                "topic": event.topic,
                "event_type": event.event_type,
                "aggregate_id": event.aggregate_id,
                "ordering_key": event.ordering_key or event.aggregate_id,
                "correlation_id": event.correlation_id,
                "idempotency_key": event.idempotency_key,
                "schema_version": event.schema_version,
                "payload_json": json.dumps(event.payload, default=str),
                "headers": json.dumps(event.headers),
                "status": OutboxStatus.PENDING.value,
                "service_name": service_name,
                "max_attempts": max_attempts,
                "created_at": now,
            },
        )

        return event.event_id

    @staticmethod
    async def record_batch(
        session: "AsyncSession",
        events: list[DurableEvent],
        *,
        max_attempts: int = 10,
        service_name: str = "",
    ) -> list[str]:
        """Record multiple events in a single transaction.

        Returns list of event_ids.
        """
        return [
            await EventRecorder.record(
                session, event,
                max_attempts=max_attempts,
                service_name=service_name,
            )
            for event in events
        ]
