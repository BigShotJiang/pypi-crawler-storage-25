"""EmpowerNow Kafka integration.

Re-exports commonly used functions from platform_producer for convenience.

Usage
-----
from empowernow_common.kafka import publish, publish_structured, shutdown
from empowernow_common.kafka import publish_to_ifttt
from empowernow_common.kafka import get_kafka_health, EventDurability

await publish("crud.operations", key="user:123", value={...})
await publish_structured("crud.create", payload={...})
await publish_to_ifttt(event_type="identity.login", source="idp", ...)
health = get_kafka_health()  # for /health endpoints
"""
from empowernow_common.kafka.platform_producer import (
    EventDurability,
    get_kafka_health,
    publish,
    publish_structured,
    shutdown,
)
from empowernow_common.kafka.topics import TOPICS
from empowernow_common.kafka.ifttt_bridge import publish_to_ifttt
from empowernow_common.kafka.event_recorder import (
    DurableEvent,
    EventRecorder,
    OutboxStatus,
)

__all__ = [
    "DurableEvent",
    "EventDurability",
    "EventRecorder",
    "OutboxStatus",
    "get_kafka_health",
    "publish",
    "publish_structured",
    "shutdown",
    "TOPICS",
    "publish_to_ifttt",
]
