"""Event outbox table schema for governance-grade durable events.

Services that use ``EventRecorder`` must create this table.  This module
provides the SQL DDL as a string so it can be embedded in Alembic migrations
or run directly.

The schema is intentionally compatible with the existing UEAS
``automation_outbox`` pattern but uses a distinct table name
(``event_outbox``) to avoid coupling to UEAS-specific columns.
"""

EVENT_OUTBOX_DDL = """
CREATE TABLE IF NOT EXISTS event_outbox (
    event_id         VARCHAR(64)  NOT NULL,
    topic            VARCHAR(255) NOT NULL,
    event_type       VARCHAR(255) NOT NULL,
    aggregate_id     VARCHAR(255) NOT NULL,
    ordering_key     VARCHAR(255) NOT NULL DEFAULT '',
    correlation_id   VARCHAR(64)  NOT NULL DEFAULT '',
    idempotency_key  VARCHAR(128) NOT NULL,
    schema_version   VARCHAR(16)  NOT NULL DEFAULT '1.0',
    payload_json     TEXT         NOT NULL,
    headers          TEXT         NOT NULL DEFAULT '{}',
    status           VARCHAR(32)  NOT NULL DEFAULT 'pending',
    service_name     VARCHAR(128) NOT NULL DEFAULT '',
    max_attempts     INTEGER      NOT NULL DEFAULT 10,
    attempt_count    INTEGER      NOT NULL DEFAULT 0,
    last_error       TEXT,
    next_attempt_at  TIMESTAMP WITH TIME ZONE,
    published_at     TIMESTAMP WITH TIME ZONE,
    claimed_by       VARCHAR(64),
    claimed_at       TIMESTAMP WITH TIME ZONE,
    lease_expires_at TIMESTAMP WITH TIME ZONE,
    created_at       DOUBLE PRECISION NOT NULL,
    updated_at       DOUBLE PRECISION NOT NULL,

    PRIMARY KEY (event_id),
    UNIQUE (idempotency_key)
);

CREATE INDEX IF NOT EXISTS idx_event_outbox_pending
    ON event_outbox (status, next_attempt_at)
    WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS idx_event_outbox_ordering
    ON event_outbox (ordering_key, created_at)
    WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS idx_event_outbox_lease
    ON event_outbox (lease_expires_at)
    WHERE status = 'publishing';

CREATE INDEX IF NOT EXISTS idx_event_outbox_dead_letter
    ON event_outbox (status, created_at)
    WHERE status = 'dead_letter';
"""

DEAD_LETTER_TABLE_DDL = """
CREATE TABLE IF NOT EXISTS event_outbox_dead_letter (
    dead_letter_id   SERIAL       PRIMARY KEY,
    event_id         VARCHAR(64)  NOT NULL,
    topic            VARCHAR(255) NOT NULL,
    event_type       VARCHAR(255) NOT NULL,
    aggregate_id     VARCHAR(255) NOT NULL,
    ordering_key     VARCHAR(255) NOT NULL DEFAULT '',
    correlation_id   VARCHAR(64)  NOT NULL DEFAULT '',
    idempotency_key  VARCHAR(128) NOT NULL,
    schema_version   VARCHAR(16)  NOT NULL DEFAULT '1.0',
    payload_json     TEXT         NOT NULL,
    headers          TEXT         NOT NULL DEFAULT '{}',
    service_name     VARCHAR(128) NOT NULL DEFAULT '',
    attempt_count    INTEGER      NOT NULL DEFAULT 0,
    last_error       TEXT,
    dead_lettered_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    replayed_at      TIMESTAMP WITH TIME ZONE,
    created_at       DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_event_outbox_dl_replay
    ON event_outbox_dead_letter (replayed_at)
    WHERE replayed_at IS NULL;
"""
