"""Kafka health reporting for the four-concept health taxonomy.

Provides structured health status for Kafka that services integrate into
their health endpoints.  The ``critical_for_readiness`` flag is set by the
service based on its role (API vs pipeline worker).

Usage
-----
from empowernow_common.kafka.health import KafkaHealthReporter

reporter = KafkaHealthReporter(critical_for_readiness=False)  # API service
# reporter = KafkaHealthReporter(critical_for_readiness=True)  # Pipeline worker

# In health endpoint:
kafka_health = reporter.get_component_status()
# Returns:
# {
#     "status": "degraded",
#     "severity": "warning",
#     "critical_for_readiness": False,
#     "circuit_breaker": "open",
#     "metrics": {...},
# }

# For readiness check:
if reporter.is_ready():
    ...  # True for API services even when Kafka is down
"""
from __future__ import annotations

import os
from typing import Any, Dict


class KafkaHealthReporter:
    """Reports Kafka health status using the four-concept taxonomy.

    - **Liveness**: Never affected by Kafka.
    - **Readiness**: Affected only when ``critical_for_readiness=True``
      (pipeline workers).
    - **Dependency health**: Always reports structured status with severity.
    - **Startup health**: Configurable via ``required_for_startup``.
    """

    def __init__(
        self,
        critical_for_readiness: bool = False,
        required_for_startup: bool = False,
    ):
        self._critical = critical_for_readiness
        self._required_startup = required_for_startup

    @staticmethod
    def from_env() -> "KafkaHealthReporter":
        """Create from environment variables.

        ``KAFKA_CRITICAL_FOR_READINESS=true`` for pipeline workers.
        ``KAFKA_REQUIRED_FOR_STARTUP=true`` for services that must wait.
        """
        critical = os.getenv(
            "KAFKA_CRITICAL_FOR_READINESS", "false"
        ).lower() in {"1", "true", "yes"}
        startup = os.getenv(
            "KAFKA_REQUIRED_FOR_STARTUP", "false"
        ).lower() in {"1", "true", "yes"}
        return KafkaHealthReporter(
            critical_for_readiness=critical,
            required_for_startup=startup,
        )

    def get_component_status(self) -> Dict[str, Any]:
        """Return structured component status for ``/health`` endpoints.

        Always returns a dict with ``status``, ``severity``, and
        ``critical_for_readiness`` so monitoring can alert on structured
        fields rather than HTTP status codes.
        """
        from empowernow_common.kafka.platform_producer import get_kafka_health

        transport = get_kafka_health()
        cb_state = transport.get("circuit_breaker", {}).get("state", "uninitialized")
        producer_up = transport.get("producer_connected", False)
        enabled = transport.get("enabled", True)

        if not enabled:
            status = "disabled"
            severity = "info"
        elif cb_state == "open":
            status = "degraded"
            severity = "critical" if self._critical else "warning"
        elif not producer_up:
            status = "not_started"
            severity = "critical" if self._critical else "warning"
        else:
            status = "healthy"
            severity = "info"

        return {
            "status": status,
            "severity": severity,
            "critical_for_readiness": self._critical,
            "circuit_breaker": cb_state,
            "producer_connected": producer_up,
            "metrics": transport.get("metrics", {}),
        }

    def is_ready(self) -> bool:
        """Whether this service should report ready given Kafka state.

        API services (``critical_for_readiness=False``) always return True.
        Pipeline workers return True only when Kafka is healthy.
        """
        if not self._critical:
            return True

        from empowernow_common.kafka.platform_producer import get_kafka_health

        transport = get_kafka_health()
        cb_state = transport.get("circuit_breaker", {}).get("state", "uninitialized")
        return transport.get("producer_connected", False) and cb_state != "open"

    def should_block_startup(self) -> bool:
        """Whether startup should wait for Kafka."""
        return self._required_startup
