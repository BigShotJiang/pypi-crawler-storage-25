"""Shared async Kafka producer for EmpowerNow platform.

Usage
-----
from empowernow_common.kafka import publish, publish_structured

await publish("crud.operations", key="user:123", value={...})
await publish_structured("crud.create", payload={...})

The producer is lazily initialised once per process. If ``aiokafka`` is missing
or ``KAFKA_ENABLED=false``, all functions become no-ops so external users are
not forced to install Kafka dependencies.

Resilience: sends are wrapped in a ``ResilientExecutor`` from
``empowernow_common.resilience`` providing circuit breaker, capped exponential
backoff with jitter, and per-attempt timeouts. When the circuit breaker is
open, ``publish()`` returns immediately without blocking the caller. Use
``get_kafka_health()`` to expose breaker state in health endpoints.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from enum import Enum
from typing import Any, Dict, Optional

try:
    from aiokafka import AIOKafkaProducer  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    AIOKafkaProducer = None  # type: ignore

try:
    from empowernow_common.resilience import ResilientExecutor, ResilienceConfig
    from empowernow_common.resilience.circuit_breaker import CircuitBreakerOpenError

    _HAS_RESILIENCE = True
except ImportError:  # pragma: no cover
    _HAS_RESILIENCE = False
    CircuitBreakerOpenError = type(None)  # type: ignore[misc,assignment]

logger = logging.getLogger(__name__)

KAFKA_ENABLED = os.getenv("KAFKA_ENABLED", "true").lower() in {"1", "true", "yes"}
BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092").split(",")
CLIENT_ID = os.getenv("KAFKA_CLIENT_ID", "platform-producer")
SERVICE_NAME = os.getenv("SERVICE_NAME", os.getenv("HOSTNAME", "unknown-service"))

_SEND_TIMEOUT = float(os.getenv("KAFKA_SEND_TIMEOUT_SECONDS", "10"))
_CB_THRESHOLD = int(os.getenv("KAFKA_CB_THRESHOLD", "5"))
_CB_TIMEOUT = float(os.getenv("KAFKA_CB_TIMEOUT_SECONDS", "60"))
_MAX_RETRIES = int(os.getenv("KAFKA_MAX_RETRIES", "3"))
_RETRY_DELAY = float(os.getenv("KAFKA_RETRY_DELAY_SECONDS", "1.0"))
_RETRY_MAX_DELAY = float(os.getenv("KAFKA_RETRY_MAX_DELAY_SECONDS", "30.0"))
_BOOTSTRAP_COOLDOWN = float(os.getenv("KAFKA_BOOTSTRAP_COOLDOWN_SECONDS", "60"))


class EventDurability(str, Enum):
    """Declares caller intent so the transport layer can behave correctly.

    Business services should choose the durability that matches the event's
    criticality.  The *transport* (this module) only handles ``best_effort``.
    Durable classes must be persisted via ``EventRecorder`` / outbox first.
    """

    BEST_EFFORT = "best_effort"
    DURABLE_ASYNC = "durable_async"
    PIPELINE_COMMAND = "pipeline_command"
    SYNCHRONOUS_REQUIRED = "synchronous_required"


# ---------------------------------------------------------------------------
# Metrics counters -- atomicity guaranteed by the GIL for single increments.
# For strict correctness under sub-interpreter or no-GIL builds, wrap in a
# lock.  Acceptable for counters in CPython 3.12.
# ---------------------------------------------------------------------------
_metrics_lock = asyncio.Lock()
_metrics: Dict[str, int] = {
    "published": 0,
    "dropped_cb_open": 0,
    "dropped_error": 0,
}


def _inc(counter: str) -> None:
    _metrics[counter] = _metrics.get(counter, 0) + 1


# ---------------------------------------------------------------------------
# Lazy singleton producer + ResilientExecutor
# ---------------------------------------------------------------------------
_producer: Optional["AIOKafkaProducer"] = None
_executor: Optional["ResilientExecutor"] = None
_init_lock = asyncio.Lock()
_last_bootstrap_failure: float = 0.0


async def _get_executor() -> Optional["ResilientExecutor"]:
    """Lazily create the ResilientExecutor for Kafka sends.

    Uses ``_init_lock`` to prevent duplicate creation under concurrency.
    """
    global _executor
    if _executor is not None:
        return _executor

    if not _HAS_RESILIENCE:
        return None

    async with _init_lock:
        if _executor is not None:
            return _executor

        _executor = ResilientExecutor(
            name="kafka-producer",
            config=ResilienceConfig(
                timeout=_SEND_TIMEOUT,
                max_retries=_MAX_RETRIES,
                retry_delay=_RETRY_DELAY,
                retry_max_delay=_RETRY_MAX_DELAY,
                retry_backoff_factor=2.0,
                retry_jitter=0.2,
                circuit_breaker_enabled=True,
                circuit_breaker_threshold=_CB_THRESHOLD,
                circuit_breaker_timeout=_CB_TIMEOUT,
            ),
        )
        return _executor


async def _ensure_producer() -> Optional["AIOKafkaProducer"]:
    """Start producer on first use; safe for concurrent awaits.

    After a failed bootstrap, backs off for ``_BOOTSTRAP_COOLDOWN`` seconds
    to avoid blocking callers with repeated TCP timeouts when the broker is
    unreachable.
    """
    global _producer, _last_bootstrap_failure
    if _producer or not KAFKA_ENABLED or AIOKafkaProducer is None:
        return _producer

    now = time.monotonic()
    if _last_bootstrap_failure and (now - _last_bootstrap_failure) < _BOOTSTRAP_COOLDOWN:
        return None

    async with _init_lock:
        if _producer:
            return _producer
        if _last_bootstrap_failure and (now - _last_bootstrap_failure) < _BOOTSTRAP_COOLDOWN:
            return None
        try:
            _producer = AIOKafkaProducer(
                bootstrap_servers=BOOTSTRAP,
                client_id=CLIENT_ID,
                value_serializer=lambda v: json.dumps(v, ensure_ascii=False).encode(),
                key_serializer=lambda k: (
                    None if k is None
                    else k if isinstance(k, bytes)
                    else k.encode("utf-8") if isinstance(k, str)
                    else str(k).encode("utf-8")
                ),
            )
            await _producer.start()
            _last_bootstrap_failure = 0.0
            logger.info("Platform Kafka producer connected (%s)", ",".join(BOOTSTRAP))
        except Exception as exc:
            logger.error("Failed to start platform Kafka producer: %s", exc)
            _producer = None
            _last_bootstrap_failure = time.monotonic()
        return _producer


async def publish(
    topic: str,
    key: str | None,
    value: Any,
    *,
    headers: list[tuple[str, bytes]] | None = None,
) -> bool:
    """Publish *value* to *topic* using *key*.

    Returns ``True`` if sent, ``False`` if dropped (CB open, unavailable, or
    error after retries).  Never raises for ``best_effort`` callers.

    *headers* is an optional list of ``(name, value_bytes)`` tuples passed
    through to the underlying ``AIOKafkaProducer.send_and_wait``.
    """
    if not KAFKA_ENABLED:
        return False

    producer = await _ensure_producer()
    if producer is None:
        _inc("dropped_error")
        logger.error("Kafka producer unavailable - cannot publish to %s", topic)
        return False

    executor = await _get_executor()

    if executor is not None:
        try:
            async def _send() -> None:
                await producer.send_and_wait(
                    topic, key=key, value=value, headers=headers,
                )

            await executor.execute(_send)
            _inc("published")
            return True
        except CircuitBreakerOpenError:
            _inc("dropped_cb_open")
            logger.warning(
                "Kafka CB open - dropped event: topic=%s key=%s", topic, key,
            )
            return False
        except Exception as exc:
            _inc("dropped_error")
            logger.error(
                "Kafka publish failed after retries: topic=%s, key=%s, error=%s",
                topic, key, exc,
            )
            return False
    else:
        try:
            await producer.send_and_wait(
                topic, key=key, value=value, headers=headers,
            )
            _inc("published")
            return True
        except Exception as exc:
            _inc("dropped_error")
            logger.error(
                "Kafka publish failed: topic=%s, key=%s, error=%s",
                topic, key, exc,
            )
            return False


async def publish_structured(
    event_type: str,
    payload: dict,
    *,
    topic: str | None = None,
    key: str | None = None,
    correlation_id: str | None = None,
    schema_version: str = "1.0",
) -> bool:
    """Publish a structured event with a standard envelope.

    ``schema_version`` is included in the wire format so consumers can
    programmatically distinguish envelope versions during future migrations.
    Additive changes (new optional fields) do not bump the version; removing
    or renaming a field bumps the major version.

    Returns ``True`` if sent, ``False`` if dropped.
    """
    envelope = {
        "schema_version": schema_version,
        "event_id": uuid.uuid4().hex,
        "event_type": event_type,
        "correlation_id": correlation_id or uuid.uuid4().hex,
        "service": SERVICE_NAME,
        "ts": time.time(),
        "payload": payload,
    }
    return await publish(topic or event_type.split(".")[0], key, envelope)


def get_kafka_health() -> Dict[str, Any]:
    """Return Kafka transport health for use in health endpoints.

    Includes circuit breaker state, metrics counters, and producer status.
    Services should include this in their ``/health`` or ``/health/deps``
    response as a non-critical component for API services or a critical
    component for pipeline workers.
    """
    cb_state: Dict[str, Any] = {"state": "uninitialized"}

    if _executor is not None:
        executor_state = _executor.get_state()
        cb_state = executor_state.get("circuit_breaker", cb_state)

    is_open = cb_state.get("state") == "open"

    return {
        "status": "unavailable" if is_open else ("healthy" if _producer else "not_started"),
        "producer_connected": _producer is not None,
        "circuit_breaker": cb_state,
        "metrics": dict(_metrics),
        "enabled": KAFKA_ENABLED,
        "bootstrap_servers": BOOTSTRAP,
    }


async def shutdown():  # pragma: no cover
    """Gracefully stop the global producer (for ASGI lifespan hooks)."""
    global _producer
    if _producer:
        try:
            await _producer.stop()
        finally:
            _producer = None
