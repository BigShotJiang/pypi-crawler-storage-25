"""Rate limiting wrapper around slowapi.

Sets sensible defaults on signup/login that block credential-stuffing and the
sort of accidental DDOS that runs up a fly.io bill. Per-route overrides come
straight from :class:`ParbakedConfig` so you can dial them per environment.
"""

from __future__ import annotations

from fastapi import FastAPI
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from parbaked.config import ParbakedConfig


def install_rate_limiting(app: FastAPI, config: ParbakedConfig) -> Limiter:
    """Wire a per-IP rate limiter onto ``app``. Idempotent.

    Returns the configured :class:`Limiter` so the caller can pass it into
    :func:`build_auth_router` for the per-route signup/login overrides.
    """
    limiter = getattr(app.state, "limiter", None)
    if limiter is None:
        limiter = Limiter(
            key_func=get_remote_address,
            default_limits=[config.ratelimit_global],
            headers_enabled=True,
        )
        app.state.limiter = limiter
        app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
    return limiter
