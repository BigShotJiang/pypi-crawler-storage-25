"""parbaked email <sub-command> — opinionated email setup, Resend-first."""

from __future__ import annotations

from pathlib import Path

import typer

from parbaked.email._http import HTTPEmailError, post_json
from parbaked.email.base import EmailMessage

email_app = typer.Typer(help="Set up real email delivery.", no_args_is_help=True)


_SETUP_BANNER = """\
─────────────────────────────────────────────────────────────
parbaked recommends Resend (https://resend.com)
  ✓ 3,000 emails/month free, no credit card
  ✓ Send from onboarding@resend.dev — no DNS setup needed
  ✓ Upgrade to your own domain later (one DNS record)

1. Open https://resend.com/signup (signs you up with email or GitHub)
2. Create an API key at https://resend.com/api-keys
3. Paste it below — anything starting with re_
─────────────────────────────────────────────────────────────
"""


def _write_env(env_path: Path, key: str, mail_from: str | None) -> None:
    """Append or update PARBAKED_RESEND_KEY + optional PARBAKED_MAIL_FROM in .env."""
    lines: list[str] = []
    existing = env_path.read_text().splitlines() if env_path.exists() else []
    seen_key = seen_from = False
    for line in existing:
        if line.startswith("PARBAKED_RESEND_KEY="):
            lines.append(f"PARBAKED_RESEND_KEY={key}")
            seen_key = True
        elif line.startswith("PARBAKED_MAIL_FROM=") and mail_from is not None:
            lines.append(f"PARBAKED_MAIL_FROM={mail_from}")
            seen_from = True
        else:
            lines.append(line)
    if not seen_key:
        lines.append(f"PARBAKED_RESEND_KEY={key}")
    if mail_from and not seen_from:
        lines.append(f"PARBAKED_MAIL_FROM={mail_from}")
    env_path.write_text("\n".join(lines) + "\n")


@email_app.command("setup")
def setup(
    key: str = typer.Option(
        None,
        "--key",
        help="Resend API key. If omitted, you'll be prompted interactively.",
    ),
    mail_from: str = typer.Option(
        None,
        "--from",
        help="From address. Defaults to onboarding@resend.dev (sandbox).",
    ),
    env_file: Path = typer.Option(
        Path(".env"),
        "--env-file",
        help="Target .env file (default: ./.env).",
    ),
) -> None:
    """Set up Resend for real email delivery. Writes PARBAKED_RESEND_KEY to .env."""
    if key is None:
        typer.echo(_SETUP_BANNER)
        key = typer.prompt("Resend API key", hide_input=False).strip()

    if not key.startswith("re_"):
        typer.echo(
            "✗ that doesn't look like a Resend API key (should start with 're_').",
            err=True,
        )
        raise typer.Exit(1)

    _write_env(env_file, key, mail_from)
    typer.echo(f"✓ wrote PARBAKED_RESEND_KEY to {env_file.resolve()}")
    if mail_from:
        typer.echo(f"✓ wrote PARBAKED_MAIL_FROM={mail_from}")
    else:
        typer.echo("  (using Resend's sandbox sender: onboarding@resend.dev)")
        typer.echo("  Set PARBAKED_MAIL_FROM for your own domain later.")
    typer.echo("")
    typer.echo("To send a test email and confirm it works:")
    typer.echo("  parbaked email test you@example.com")


@email_app.command("test")
def test(
    recipient: str = typer.Argument(..., help="Where to send the test email"),
    key: str = typer.Option(
        None,
        "--key",
        envvar="PARBAKED_RESEND_KEY",
        help="Resend API key. Defaults to PARBAKED_RESEND_KEY env var.",
    ),
    mail_from: str = typer.Option(
        "onboarding@resend.dev",
        "--from",
        envvar="PARBAKED_MAIL_FROM",
        help="From address. Defaults to Resend's sandbox sender.",
    ),
) -> None:
    """Send a one-off test email. Useful to verify Resend is wired up."""
    if not key:
        typer.echo(
            "✗ no API key. Set PARBAKED_RESEND_KEY or pass --key. "
            "Run `parbaked email setup` for an interactive walkthrough.",
            err=True,
        )
        raise typer.Exit(1)

    msg = EmailMessage(
        to=recipient,
        subject="parbaked test email",
        body=(
            "This is a test email from parbaked.\n\n"
            "If you're seeing this, your Resend setup is working.\n"
        ),
    )
    typer.echo(f"→ sending test email to {recipient}...")
    try:
        post_json(
            "https://api.resend.com/emails",
            {
                "from": mail_from,
                "to": [msg.to],
                "subject": msg.subject,
                "text": msg.body,
            },
            headers={"Authorization": f"Bearer {key}"},
        )
    except HTTPEmailError as exc:
        typer.echo(f"✗ Resend rejected the send:\n  {exc}", err=True)
        raise typer.Exit(1) from exc

    typer.echo(f"✓ sent. Check {recipient}'s inbox.")
