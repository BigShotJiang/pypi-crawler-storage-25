# fly.io config for {{APP_NAME}} — tuned for PoCs and bill safety.
#
# Key cost-protection settings, in case you tweak them:
# - auto_stop_machines + min_machines_running=0: idle traffic → machine pauses → no compute charge
# - hard concurrency cap: keeps any single machine from being overwhelmed; combined with auto-stop
#   means a brief traffic spike doesn't trigger autoscale-to-bill
# - shared-cpu-1x + 256MB: cheapest tier; bump if you actually need it
#
# To deploy: `make deploy` (or `fly launch --copy-config --no-deploy` first time to claim the name)
# To watch logs: `make logs`

app = "{{APP_NAME}}"
primary_region = "lhr"

[build]

[http_service]
  internal_port = 8000
  force_https = true
  auto_stop_machines = "stop"
  auto_start_machines = true
  min_machines_running = 0
  processes = ["app"]

  [http_service.concurrency]
    type = "requests"
    hard_limit = 200
    soft_limit = 100

  # Health check — hits parbaked's built-in /health endpoint.
  [[http_service.checks]]
    grace_period = "10s"
    interval = "30s"
    method = "GET"
    timeout = "5s"
    path = "/health"

[[vm]]
  size = "shared-cpu-1x"
  memory = "256mb"
  cpu_kind = "shared"
