# Python
__pycache__/
*.pyc
.venv/
*.egg-info/

# parbaked
.parbaked.json
*.db
*.sqlite

# Env
.env
.env.local

# OS
.DS_Store
