"""{{APP_NAME}} — built with parbaked."""

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from parbaked import Parbaked

app = FastAPI(title="{{APP_NAME}}")

# One line. That's the whole auth setup.
parbaked = Parbaked(app)

templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request, "home.html", {"app_name": "{{APP_NAME}}"})


@app.get("/signup", response_class=HTMLResponse)
def signup_page(request: Request):
    return templates.TemplateResponse(request, "signup.html", {"app_name": "{{APP_NAME}}"})


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse(request, "login.html", {"app_name": "{{APP_NAME}}"})


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    # Server-rendered shell; the page itself checks the JWT against /auth/me
    # and redirects to /login on 401. Protecting the JSON API is what counts.
    return templates.TemplateResponse(request, "dashboard.html", {"app_name": "{{APP_NAME}}"})


# ─── write your app here ↓ ────────────────────────────────────────────────────
#
# Add your own routes below. Use `Depends(parbaked.current_user)` to require an
# authenticated active user. For per-user data, define a related SQLModel table
# keyed on `users.id` (see https://github.com/saml7n/parbaked/tree/main/examples
# for the per_user_data.py example).
#
# Example:
#
#     from fastapi import Depends
#     from parbaked.auth.models import User
#
#     @app.get("/me")
#     def me(user: User = Depends(parbaked.current_user)):
#         return {"email": user.email}
