[project]
name = "{{APP_NAME}}"
version = "0.0.1"
description = "{{APP_NAME}} — built with parbaked"
requires-python = ">=3.11"
dependencies = [
    "parbaked>=0.2",
    "uvicorn[standard]>=0.30",
    "jinja2>=3.1",
]
