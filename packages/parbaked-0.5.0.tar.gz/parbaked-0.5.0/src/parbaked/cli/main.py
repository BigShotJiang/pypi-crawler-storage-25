"""parbaked CLI.

Commands:

- ``parbaked new <name>`` — scaffold a complete runnable PoC (FastAPI +
  Jinja templates + Parbaked, ready for ``make dev``).
- ``parbaked init`` — drop a ``.env.example`` and print the integration snippet
  for an *existing* FastAPI project.
- ``parbaked version`` — print the installed version.
"""

from __future__ import annotations

import shutil
from importlib import resources
from pathlib import Path

import typer

from parbaked import __version__
from parbaked.cli.admin import admin_app
from parbaked.cli.email import email_app
from parbaked.cli.users import users_app

app = typer.Typer(
    name="parbaked",
    help="A par-baked starter for FastAPI PoC apps.",
    add_completion=False,
    no_args_is_help=True,
)
app.add_typer(users_app, name="users", help="Inspect and manage users.")
app.add_typer(admin_app, name="admin", help="Admin operations.")
app.add_typer(email_app, name="email", help="Set up real email delivery.")


_INTEGRATION_SNIPPET = """\
# main.py — drop this into your FastAPI app

from fastapi import FastAPI
from parbaked import Parbaked

app = FastAPI()
parbaked = Parbaked(app)  # ← that's literally it for dev

# Protect your own routes
@app.get("/profile")
def profile(user = Depends(parbaked.current_user)):
    return {"email": user.email}
"""


def _starter_templates_dir() -> Path:
    """Return the directory containing starter templates (packaged data)."""
    # importlib.resources.files gives a Traversable, but for shutil we need a real Path.
    pkg = resources.files("parbaked.cli.templates")
    return Path(str(pkg / "starter"))


def _render_template(content: str, app_name: str) -> str:
    return content.replace("{{APP_NAME}}", app_name)


def _validate_app_name(name: str) -> None:
    if not name:
        raise typer.BadParameter("Project name required")
    if "/" in name or "\\" in name or name.startswith("."):
        raise typer.BadParameter("Project name must be a single directory name")


@app.command()
def new(
    name: str = typer.Argument(..., help="Project name (becomes the directory)"),
    parent: Path = typer.Option(
        Path("."), "--parent", "-p", help="Parent directory for the new project"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Overwrite an existing directory of the same name"
    ),
) -> None:
    """Scaffold a complete runnable PoC under PARENT/NAME.

    Creates a FastAPI app with parbaked already wired up, Jinja signup/login/dashboard
    templates, a Makefile, and pyproject.toml. After running:

        cd NAME && make dev

    you'll have a working signup + admin approval flow at http://localhost:8000.
    """
    _validate_app_name(name)
    target = (parent / name).resolve()
    if target.exists() and not force:
        typer.echo(f"✗ {target} already exists. Use --force to overwrite.", err=True)
        raise typer.Exit(1)

    src = _starter_templates_dir()
    if not src.exists():
        typer.echo(
            f"✗ Starter templates not found at {src}. parbaked install is broken?",
            err=True,
        )
        raise typer.Exit(1)

    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)

    # Walk the templates, rendering and renaming as we go.
    rename_map = {".tpl": ""}  # strip .tpl suffix
    renamed_files = {
        "gitignore.tpl": ".gitignore",
        "pyproject.toml.tpl": "pyproject.toml",
        "fly.toml.tpl": "fly.toml",
    }

    for src_path in src.rglob("*"):
        if src_path.is_dir():
            continue
        rel = src_path.relative_to(src)

        # Explicit renames first
        if rel.name in renamed_files:
            out_rel = rel.parent / renamed_files[rel.name]
        else:
            # Generic .tpl stripping
            out_name = rel.name
            for old, new in rename_map.items():
                if out_name.endswith(old):
                    out_name = out_name[: -len(old)] + new
            out_rel = rel.parent / out_name

        out_path = target / out_rel
        out_path.parent.mkdir(parents=True, exist_ok=True)

        content = src_path.read_text()
        rendered = _render_template(content, name)
        out_path.write_text(rendered)

    typer.echo(f"✓ created {target}")
    typer.echo("")
    typer.echo("Next:")
    typer.echo(f"  cd {name}")
    typer.echo("  make dev")
    typer.echo("")
    typer.echo("Then open http://localhost:8000 to sign up.")
    typer.echo(
        "The terminal banner will show your admin password — use it at"
        " /auth/admin to approve yourself."
    )


@app.command()
def init(
    target: Path = typer.Argument(Path("."), help="Project directory to scaffold into"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing files"),
) -> None:
    """Print the 5-line integration snippet for an existing FastAPI app.

    For a brand-new project, use ``parbaked new <name>`` instead — it scaffolds
    a complete runnable app rather than just a snippet.
    """
    target = target.resolve()
    if not target.exists():
        typer.echo(f"✗ {target} does not exist", err=True)
        raise typer.Exit(1)

    typer.echo("─" * 60)
    typer.echo("Drop this into your FastAPI app:")
    typer.echo("─" * 60)
    typer.echo(_INTEGRATION_SNIPPET)
    typer.echo("")
    typer.echo("On first run, parbaked auto-generates secrets and writes")
    typer.echo(".parbaked.json — add it to your .gitignore. The terminal banner")
    typer.echo("will show your admin password and dashboard URL.")


@app.command()
def version() -> None:
    """Print the installed parbaked version."""
    typer.echo(__version__)


if __name__ == "__main__":
    app()
