"""parbaked CLI — invoked via the ``parbaked`` console script entry point."""
