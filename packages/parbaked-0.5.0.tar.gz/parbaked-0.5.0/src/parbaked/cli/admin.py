"""parbaked admin <sub-command> — manage the admin password / dashboard."""

from __future__ import annotations

import json
import secrets as _secrets
from pathlib import Path

import typer

admin_app = typer.Typer(help="Admin password / dashboard operations.", no_args_is_help=True)


@admin_app.command("reset-password")
def reset_password(
    secrets_file: Path = typer.Option(
        Path(".parbaked.json"),
        "--secrets-file",
        help="Path to the secrets JSON file (default: ./.parbaked.json)",
    ),
) -> None:
    """Generate a new admin password, write it to .parbaked.json, print once."""
    data: dict = {}
    if secrets_file.exists():
        try:
            data = json.loads(secrets_file.read_text())
        except json.JSONDecodeError:
            typer.echo(
                f"✗ {secrets_file} is corrupt — refusing to overwrite. "
                "Delete it manually or pass --secrets-file pointing elsewhere.",
                err=True,
            )
            raise typer.Exit(1) from None

    new_password = _secrets.token_urlsafe(18)
    data["admin_password"] = new_password
    secrets_file.write_text(json.dumps(data, indent=2) + "\n")

    typer.echo("New admin password:")
    typer.echo("")
    typer.echo(f"    {new_password}")
    typer.echo("")
    typer.echo(f"Saved to {secrets_file.resolve()}")
    typer.echo("Restart your app (or set PARBAKED_ADMIN_PASSWORD) for the change to take effect.")
