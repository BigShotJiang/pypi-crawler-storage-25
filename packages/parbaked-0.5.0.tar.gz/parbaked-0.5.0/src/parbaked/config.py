"""Runtime configuration for parbaked.

All settings are driven by environment variables prefixed with ``PARBAKED_``.
The consumer can either let parbaked read its own env vars, or pass an
explicit ``ParbakedConfig`` instance into :func:`build_auth_router`.
"""

from __future__ import annotations

from pydantic import EmailStr, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ParbakedConfig(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="PARBAKED_",
        env_file=".env",
        extra="ignore",
        case_sensitive=False,
    )

    # ---- Branding -------------------------------------------------------
    app_name: str = Field(default="My App", description="Used in email subjects and bodies")
    app_url: str = Field(
        default="http://localhost:8000",
        description="Public base URL — used to build approval magic links",
    )

    # ---- Auth secrets ---------------------------------------------------
    jwt_secret: str = Field(
        default="",
        description=(
            "HMAC secret for JWT signing. MUST be set in production. "
            "If empty, a random key is generated at startup (sessions reset on restart)."
        ),
    )
    jwt_algorithm: str = Field(default="HS256")
    jwt_expiry_days: int = Field(default=7)

    approval_token_secret: str = Field(
        default="",
        description=(
            "HMAC secret for admin approval magic links. Falls back to "
            "``jwt_secret`` if unset, but a separate secret is recommended."
        ),
    )
    approval_token_expiry_hours: int = Field(default=72)

    # ---- Admin ----------------------------------------------------------
    admin_email: EmailStr | None = Field(
        default=None,
        description="Where signup-approval emails are sent. Required for the approval flow.",
    )

    # ---- Email transport -----------------------------------------------
    # parbaked has one prod email path: Resend. If `resend_api_key` is set,
    # ResendEmail is used. Otherwise ConsoleEmail (prints to stdout) is used.
    # For anything else, pass your own EmailTransport into Parbaked(email=...).

    resend_api_key: str = Field(
        default="",
        description=(
            "Resend API key (re_xxx). Get one free at https://resend.com/api-keys "
            "or run `parbaked email setup`. When set, parbaked sends real email."
        ),
    )
    mail_from: str = Field(
        default="",
        description=(
            "From address for outbound emails. Defaults to onboarding@resend.dev "
            "(Resend's sandbox sender — works with no DNS setup). For your own "
            "domain, verify it at resend.com/domains and set this to hello@yourdomain.com."
        ),
    )

    # ---- Rate limiting --------------------------------------------------
    ratelimit_signup: str = Field(default="5/minute", description="Per-IP limit on /auth/signup")
    ratelimit_login: str = Field(default="10/minute", description="Per-IP limit on /auth/login")
    ratelimit_global: str = Field(
        default="100/minute",
        description="Default per-IP limit applied to all parbaked routes",
    )

    def effective_approval_secret(self) -> str:
        """Return the secret used to sign approval tokens (fallback chain)."""
        return self.approval_token_secret or self.jwt_secret

    def effective_mail_from(self) -> str:
        """From address — falls back to Resend's sandbox if unset."""
        return self.mail_from or "onboarding@resend.dev"
