"""Admin dashboard router.

A single HTML page at ``/auth/admin`` showing pending / active / rejected
users with approve / reject buttons. Gated by HTTP Basic Auth (username
``admin``, password from :class:`Parbaked`). Works even with no email
configured — that's the whole point of having a web UI alongside the
magic-link flow.
"""

from __future__ import annotations

import contextlib
import secrets
from collections.abc import Callable
from datetime import UTC, datetime
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from sqlmodel import Session, select

from parbaked.auth.models import User, UserStatus
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailTransport
from parbaked.email.templates import Templates

_basic = HTTPBasic()


def _check_admin(creds: HTTPBasicCredentials, admin_password: str) -> None:
    correct_user = secrets.compare_digest(creds.username, "admin")
    correct_pass = secrets.compare_digest(creds.password, admin_password)
    if not (correct_user and correct_pass):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin credentials",
            headers={"WWW-Authenticate": 'Basic realm="parbaked admin"'},
        )


_DASHBOARD_HTML = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>parbaked admin · {app_name}</title>
<style>
  :root {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }}
  body {{ max-width: 64rem; margin: 2rem auto; padding: 0 1.5rem; color: #111; }}
  h1 {{ font-size: 1.4rem; margin-bottom: 0.25rem; }}
  .sub {{ color: #666; font-size: 0.875rem; margin-bottom: 2rem; }}
  h2 {{ font-size: 1.05rem; margin-top: 2rem; color: #333; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 0.9rem; }}
  th, td {{ text-align: left; padding: 0.5rem 0.75rem; border-bottom: 1px solid #eee; }}
  th {{ font-weight: 600; color: #555; background: #fafafa; }}
  td.actions {{ text-align: right; }}
  button {{ font: inherit; padding: 0.35rem 0.75rem; border-radius: 4px; border: 1px solid #ccc;
           background: white; cursor: pointer; margin-left: 0.5rem; }}
  button.approve {{ background: #15803d; color: white; border-color: #15803d; }}
  button.reject {{ background: #b91c1c; color: white; border-color: #b91c1c; }}
  .empty {{ color: #888; font-style: italic; padding: 0.5rem 0.75rem; }}
  .badge {{ font-size: 0.7rem; padding: 0.1rem 0.5rem; border-radius: 999px;
           background: #eee; color: #666; text-transform: uppercase; letter-spacing: 0.04em; }}
  .badge.pending {{ background: #fef3c7; color: #92400e; }}
  .badge.active  {{ background: #dcfce7; color: #166534; }}
  .badge.rejected {{ background: #fee2e2; color: #991b1b; }}
</style>
</head>
<body>
  <h1>parbaked admin</h1>
  <p class="sub">{app_name} · {pending_summary}</p>

  <h2>Pending</h2>
  {pending_table}

  <h2>Active</h2>
  {active_table}

  <h2>Rejected</h2>
  {rejected_table}
</body>
</html>
"""


def _render_pending_row(user: User, prefix: str) -> str:
    return f"""\
      <tr>
        <td>{user.name}</td>
        <td>{user.email}</td>
        <td>{user.created_at.strftime("%Y-%m-%d %H:%M")}</td>
        <td class="actions">
          <form method="post" action="{prefix}/{user.id}/approve" style="display: inline">
            <button class="approve" type="submit">Approve</button>
          </form>
          <form method="post" action="{prefix}/{user.id}/reject" style="display: inline">
            <button class="reject" type="submit">Reject</button>
          </form>
        </td>
      </tr>"""


def _render_simple_row(user: User) -> str:
    when = (user.approved_at or user.created_at).strftime("%Y-%m-%d %H:%M")
    return f"""\
      <tr>
        <td>{user.name}</td>
        <td>{user.email}</td>
        <td>{when}</td>
        <td><span class="badge {user.status.value}">{user.status.value}</span></td>
      </tr>"""


def _table(rows: list[str], headers: list[str]) -> str:
    if not rows:
        return '<p class="empty">None</p>'
    header_row = "".join(f"<th>{h}</th>" for h in headers)
    body = "\n".join(rows)
    return f"<table><thead><tr>{header_row}</tr></thead><tbody>\n{body}\n</tbody></table>"


def build_admin_router(
    config: ParbakedConfig,
    get_session: Callable[..., Session],
    admin_password: str,
    email: EmailTransport,
    templates: Templates,
    *,
    prefix: str = "/auth/admin",
) -> APIRouter:
    router = APIRouter(prefix=prefix, tags=["admin"], include_in_schema=False)
    actions_prefix = prefix  # forms POST to /auth/admin/<id>/<action>

    def _auth(creds: HTTPBasicCredentials = Depends(_basic)) -> None:
        _check_admin(creds, admin_password)

    @router.get("", response_class=HTMLResponse, dependencies=[Depends(_auth)])
    async def dashboard(session: Session = Depends(get_session)) -> HTMLResponse:
        all_users = list(session.exec(select(User).order_by(User.created_at.desc())).all())
        # Unverified signups are deliberately hidden — they haven't proven they
        # own the email yet, so they're filed under "noise" until then.
        verified_pending = [
            u for u in all_users
            if u.status == UserStatus.pending and u.email_verified_at is not None
        ]
        unverified_count = sum(
            1 for u in all_users
            if u.status == UserStatus.pending and u.email_verified_at is None
        )
        active = [u for u in all_users if u.status == UserStatus.active]
        rejected = [u for u in all_users if u.status == UserStatus.rejected]

        pending_table = _table(
            [_render_pending_row(u, actions_prefix) for u in verified_pending],
            ["Name", "Email", "Signed up", ""],
        )
        active_table = _table(
            [_render_simple_row(u) for u in active], ["Name", "Email", "Approved", "Status"]
        )
        rejected_table = _table(
            [_render_simple_row(u) for u in rejected], ["Name", "Email", "Rejected", "Status"]
        )

        unverified_note = (
            f" · {unverified_count} unverified (hidden)" if unverified_count else ""
        )
        return HTMLResponse(
            _DASHBOARD_HTML.format(
                app_name=config.app_name,
                pending_summary=f"{len(verified_pending)} pending{unverified_note}",
                pending_table=pending_table,
                active_table=active_table,
                rejected_table=rejected_table,
            )
        )

    @router.post("/{user_id}/approve", dependencies=[Depends(_auth)])
    async def approve(
        user_id: UUID, session: Session = Depends(get_session)
    ) -> RedirectResponse:
        user = session.get(User, user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        if user.status != UserStatus.active:
            now = datetime.now(UTC)
            user.status = UserStatus.active
            user.approved_at = now
            if user.email_verified_at is None:
                user.email_verified_at = now
            session.add(user)
            session.commit()
            session.refresh(user)
            login_url = f"{config.app_url.rstrip('/')}/auth/login"
            # Email failures shouldn't block an approval — the user is active.
            with contextlib.suppress(Exception):
                email.send(templates.user_approved(user, login_url, config))
        return RedirectResponse(url=prefix, status_code=status.HTTP_303_SEE_OTHER)

    @router.post("/{user_id}/reject", dependencies=[Depends(_auth)])
    async def reject(
        user_id: UUID, session: Session = Depends(get_session)
    ) -> RedirectResponse:
        user = session.get(User, user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        if user.status != UserStatus.rejected:
            user.status = UserStatus.rejected
            session.add(user)
            session.commit()
            session.refresh(user)
            with contextlib.suppress(Exception):
                email.send(templates.user_rejected(user, config))
        return RedirectResponse(url=prefix, status_code=status.HTTP_303_SEE_OTHER)

    return router
