export interface PendingScreenProps {
  appName?: string;
}

export function PendingScreen({ appName = "this app" }: PendingScreenProps) {
  return (
    <div className="max-w-sm mx-auto p-6 rounded-lg border bg-white text-center">
      <h2 className="text-lg font-semibold mb-2">Awaiting approval</h2>
      <p className="text-sm text-gray-600">
        Thanks for signing up for {appName}. An admin needs to approve your account before you can
        sign in. We'll email you when that's done.
      </p>
    </div>
  );
}
