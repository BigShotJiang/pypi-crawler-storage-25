# parbaked — React components

Plain TypeScript / React components for the signup → login flow. Drop them into your `web/src/` directory and import.

These ship as **source**, not a compiled npm package, so you get full control over styling, error handling, and routing. Each file is intentionally small and tweakable.

## Components

- `SignupForm.tsx` — collects email/name/password, POSTs `/auth/signup`, shows the "pending approval" message on success.
- `LoginForm.tsx` — collects email/password, POSTs `/auth/login`, stashes the JWT (you decide where), redirects on success.
- `PendingScreen.tsx` — shown after signup; explains the admin-approval flow.

## Styling

Components use Tailwind classes. If you don't have Tailwind, the markup is plain enough to restyle with anything.

## Usage

```tsx
import { SignupForm } from "./parbaked/SignupForm";

export function SignupPage() {
  return (
    <SignupForm
      apiUrl="/auth/signup"
      onSuccess={() => navigate("/pending")}
    />
  );
}
```

Each component takes an `apiUrl` prop so you can point at a different mount path. The default assumes parbaked's auth router is mounted at `/auth`.
