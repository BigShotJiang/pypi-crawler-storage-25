import { FormEvent, useState } from "react";

export interface SignupFormProps {
  /** URL of the parbaked signup endpoint. Default: "/auth/signup". */
  apiUrl?: string;
  /** Called after a 201 response. Receives the parsed JSON body. */
  onSuccess?: (data: { user_id: string; status: string }) => void;
}

export function SignupForm({ apiUrl = "/auth/signup", onSuccess }: SignupFormProps) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, name, password }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.detail ?? `Signup failed (${res.status})`);
      }
      const data = await res.json();
      setSuccess(true);
      onSuccess?.(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Signup failed");
    } finally {
      setSubmitting(false);
    }
  }

  if (success) {
    return (
      <div className="max-w-sm mx-auto p-6 rounded-lg border bg-white">
        <h2 className="text-lg font-semibold mb-2">Almost there</h2>
        <p className="text-sm text-gray-600">
          Your account is awaiting admin approval. We'll email you when it's ready.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-sm mx-auto p-6 rounded-lg border bg-white space-y-4">
      <h2 className="text-lg font-semibold">Create account</h2>

      <label className="block">
        <span className="block text-sm font-medium text-gray-700">Name</span>
        <input
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="mt-1 w-full rounded border-gray-300 px-3 py-2"
          autoComplete="name"
        />
      </label>

      <label className="block">
        <span className="block text-sm font-medium text-gray-700">Email</span>
        <input
          required
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mt-1 w-full rounded border-gray-300 px-3 py-2"
          autoComplete="email"
        />
      </label>

      <label className="block">
        <span className="block text-sm font-medium text-gray-700">Password</span>
        <input
          required
          type="password"
          minLength={8}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-1 w-full rounded border-gray-300 px-3 py-2"
          autoComplete="new-password"
        />
        <span className="block text-xs text-gray-500 mt-1">8 characters minimum.</span>
      </label>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button
        type="submit"
        disabled={submitting}
        className="w-full rounded bg-black text-white py-2 font-medium disabled:opacity-50"
      >
        {submitting ? "Submitting…" : "Sign up"}
      </button>
    </form>
  );
}
