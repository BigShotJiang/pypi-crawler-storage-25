import { FormEvent, useState } from "react";

export interface LoginFormProps {
  /** URL of the parbaked login endpoint. Default: "/auth/login". */
  apiUrl?: string;
  /** Called with `{ token, user }` on success. You decide where the token lives. */
  onSuccess?: (data: { token: string; user: { id: string; email: string; name: string; status: string } }) => void;
}

export function LoginForm({ apiUrl = "/auth/login", onSuccess }: LoginFormProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.detail ?? `Login failed (${res.status})`);
      }
      const data = await res.json();
      onSuccess?.(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-sm mx-auto p-6 rounded-lg border bg-white space-y-4">
      <h2 className="text-lg font-semibold">Sign in</h2>

      <label className="block">
        <span className="block text-sm font-medium text-gray-700">Email</span>
        <input
          required
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mt-1 w-full rounded border-gray-300 px-3 py-2"
          autoComplete="email"
        />
      </label>

      <label className="block">
        <span className="block text-sm font-medium text-gray-700">Password</span>
        <input
          required
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-1 w-full rounded border-gray-300 px-3 py-2"
          autoComplete="current-password"
        />
      </label>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button
        type="submit"
        disabled={submitting}
        className="w-full rounded bg-black text-white py-2 font-medium disabled:opacity-50"
      >
        {submitting ? "Signing in…" : "Sign in"}
      </button>
    </form>
  );
}
