"""The :class:`Parbaked` one-call setup class.

Goal: ``Parbaked(app)`` should be the *only* line a PoC author has to write to
get signup-with-approval + rate limiting + an admin dashboard.

Everything is overridable — pass an explicit ``config``, ``engine``,
``email``, etc. — but the defaults are tuned so the empty-args form Just Works
in development. Secrets that aren't set via env vars are generated on first
boot and persisted to ``.parbaked.json`` (which is gitignored, like ``.env``).
"""

from __future__ import annotations

import contextlib
import json
import os
import secrets as _secrets
from collections.abc import Callable, Iterator
from pathlib import Path

from fastapi import FastAPI
from sqlalchemy.engine import Engine
from sqlmodel import Session, SQLModel, create_engine

from parbaked.admin import build_admin_router
from parbaked.auth.deps import make_current_user
from parbaked.auth.router import build_auth_router
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailTransport
from parbaked.email.console import ConsoleEmail
from parbaked.email.resend import ResendEmail
from parbaked.email.templates import Templates
from parbaked.ratelimit import install_rate_limiting

_DEFAULT_SECRETS_PATH = Path(".parbaked.json")
_DEFAULT_DATABASE_URL = "sqlite:///./parbaked.db"


class Parbaked:
    """One-call setup for the parbaked stack.

    Typical usage — zero configuration, everything auto-generated:

        from fastapi import FastAPI
        from parbaked import Parbaked

        app = FastAPI()
        parbaked = Parbaked(app)

        @app.get("/profile")
        def profile(user = Depends(parbaked.current_user)):
            return {"email": user.email}

    Every default is overridable via keyword args, env vars (``PARBAKED_*``),
    or by writing values into ``.parbaked.json`` before first boot.
    """

    def __init__(
        self,
        app: FastAPI | None = None,
        *,
        config: ParbakedConfig | None = None,
        database_url: str | None = None,
        engine: Engine | None = None,
        get_session: Callable[..., Iterator[Session]] | None = None,
        email: EmailTransport | None = None,
        templates: Templates | None = None,
        secrets_file: Path | str = _DEFAULT_SECRETS_PATH,
        admin_password: str | None = None,
        banner: bool = True,
    ) -> None:
        self._secrets_file = Path(secrets_file)
        self._generated: list[str] = []  # which secrets we auto-generated this boot

        # ---- config -----------------------------------------------------
        self.config = config or ParbakedConfig()
        stored = self._load_secrets()

        if not self.config.jwt_secret:
            self.config.jwt_secret = self._resolve_secret("jwt_secret", stored)
        if not self.config.approval_token_secret:
            self.config.approval_token_secret = self._resolve_secret(
                "approval_token_secret", stored
            )

        # Admin password: explicit arg > env > stored > generated
        env_admin = os.getenv("PARBAKED_ADMIN_PASSWORD")
        self.admin_password = (
            admin_password
            or env_admin
            or self._resolve_secret("admin_password", stored, length=18)
        )

        self._save_secrets(stored)

        # ---- DB ---------------------------------------------------------
        if engine is not None:
            self.engine = engine
        else:
            url = database_url or os.getenv("DATABASE_URL") or _DEFAULT_DATABASE_URL
            connect_args = (
                {"check_same_thread": False} if url.startswith("sqlite") else {}
            )
            self.engine = create_engine(url, connect_args=connect_args)
        self.database_url = str(self.engine.url)

        if get_session is None:

            def _default_get_session() -> Iterator[Session]:
                with Session(self.engine) as session:
                    yield session

            self.get_session = _default_get_session
        else:
            self.get_session = get_session

        # ---- email ------------------------------------------------------
        # Opinionated: ResendEmail if an API key is configured, else
        # ConsoleEmail. Anyone wanting a different provider passes their own
        # EmailTransport in.
        if email is not None:
            self.email = email
        elif self.config.resend_api_key:
            self.email = ResendEmail(self.config)
        else:
            self.email = ConsoleEmail()

        # ---- assemble ---------------------------------------------------
        self.templates = templates or Templates()
        self.current_user = make_current_user(self.config, self.get_session)

        self._installed: bool = False

        if app is not None:
            self.install(app, banner=banner)

    # -- public --------------------------------------------------------

    def install(self, app: FastAPI, *, banner: bool = True) -> None:
        """Wire the auth router, admin dashboard, rate limiting, and health
        endpoint onto ``app``.

        Also creates the ``users`` table if it doesn't exist. Idempotent — safe
        to call multiple times.
        """
        if self._installed:
            return

        SQLModel.metadata.create_all(self.engine)

        limiter = install_rate_limiting(app, self.config)
        app.include_router(
            build_auth_router(
                self.config,
                self.get_session,
                self.email,
                limiter=limiter,
                templates=self.templates,
            )
        )
        app.include_router(
            build_admin_router(
                self.config,
                self.get_session,
                self.admin_password,
                self.email,
                self.templates,
            )
        )

        # Health endpoint for fly.io / Cloudflare / k8s / any uptime probe.
        # Intentionally simple — just confirms the process is running and the
        # event loop is responsive. No DB ping (don't want to amplify upstream
        # outages by failing the health check too).
        @app.get("/health", include_in_schema=False)
        async def _health() -> dict[str, str]:
            return {"status": "ok"}

        self._installed = True
        if banner:
            self._print_banner()

    # -- internals -----------------------------------------------------

    def _resolve_secret(self, key: str, stored: dict, length: int = 32) -> str:
        if value := stored.get(key):
            return value
        value = _secrets.token_urlsafe(length)
        stored[key] = value
        self._generated.append(key)
        return value

    def _load_secrets(self) -> dict:
        if not self._secrets_file.exists():
            return {}
        try:
            return json.loads(self._secrets_file.read_text())
        except (OSError, json.JSONDecodeError):
            return {}

    def _save_secrets(self, data: dict) -> None:
        if not data:
            return
        # If we can't write the secrets file we'll just regenerate next boot.
        # Loud failure isn't worth blocking startup over.
        with contextlib.suppress(OSError):
            self._secrets_file.write_text(json.dumps(data, indent=2) + "\n")
            with contextlib.suppress(OSError):
                os.chmod(self._secrets_file, 0o600)

    def _print_banner(self) -> None:
        from parbaked import __version__

        admin_url = f"{self.config.app_url.rstrip('/')}/auth/admin"
        signup_url = f"{self.config.app_url.rstrip('/')}/auth/signup"
        email_status = (
            "Console (printed below)"
            if isinstance(self.email, ConsoleEmail)
            else f"SMTP via {self.config.smtp_host}"
        )

        width = 64
        title = f"parbaked v{__version__} is running"
        lines = [
            "",
            "╔" + "═" * width + "╗",
            "║  " + title + " " * (width - 2 - len(title)) + "║",
            "╠" + "═" * width + "╣",
            "║  " + f"{'Sign up at:':<14}{signup_url}".ljust(width - 2) + "║",
            "║  " + f"{'Admin panel:':<14}{admin_url}".ljust(width - 2) + "║",
            "║  " + f"{'Admin user:':<14}{'admin'}".ljust(width - 2) + "║",
            "║  " + f"{'Admin pass:':<14}{self.admin_password}".ljust(width - 2) + "║",
            "║  " + f"{'Email out:':<14}{email_status}".ljust(width - 2) + "║",
            "║  " + f"{'Database:':<14}{self.database_url}".ljust(width - 2) + "║",
        ]

        if self._generated:
            lines.append("║" + " " * width + "║")
            note1 = "⚠ Auto-generated secrets stored in .parbaked.json"
            note2 = "  Add it to .gitignore. For prod, set env vars instead."
            lines.append("║  " + note1.ljust(width - 2) + "║")
            lines.append("║  " + note2.ljust(width - 2) + "║")

        lines.append("╚" + "═" * width + "╝")
        lines.append("")
        print("\n".join(lines), flush=True)
