"""FastAPI dependency factory for authenticating requests.

Usage::

    from parbaked.auth import make_current_user

    current_user = make_current_user(config, get_session)

    @app.get("/me")
    def me(user: User = Depends(current_user)):
        return user
"""

from __future__ import annotations

from collections.abc import Callable
from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlmodel import Session

from parbaked.auth.jwt import InvalidTokenError, decode_jwt
from parbaked.auth.models import User, UserStatus
from parbaked.config import ParbakedConfig

_bearer = HTTPBearer(auto_error=False)


def make_current_user(
    config: ParbakedConfig, get_session: Callable[..., Session]
) -> Callable[..., User]:
    """Return a FastAPI dependency that resolves the authenticated active User.

    Raises 401 for missing/invalid tokens or deleted users.
    Raises 403 if the user exists but isn't ``active``.
    """

    async def _current_user(
        creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
        session: Session = Depends(get_session),
    ) -> User:
        if creds is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated"
            )

        try:
            payload = decode_jwt(creds.credentials, config)
            user_id = UUID(payload["sub"])
        except (InvalidTokenError, KeyError, ValueError) as exc:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
            ) from exc

        user = session.get(User, user_id)
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="User no longer exists"
            )
        if user.status != UserStatus.active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail=f"Account is {user.status.value}"
            )
        return user

    return _current_user
