"""HMAC-signed magic links.

Three audiences:

- ``parbaked-approval`` — admin clicks approve/reject from the signup email
- ``parbaked-verify`` — user clicks the link confirming they own the address

Audience-scoping means a session JWT can never be replayed as a magic link, an
approval link can never verify an email, and so on.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Literal
from uuid import UUID

import jwt

from parbaked.config import ParbakedConfig

ApprovalAction = Literal["approve", "reject"]
_AUDIENCE = "parbaked-approval"
_VERIFY_AUDIENCE = "parbaked-verify"


class InvalidApprovalToken(Exception):
    """Raised when an approval magic link is forged, malformed, or expired."""


class InvalidVerifyToken(Exception):
    """Raised when an email-verification link is forged, malformed, or expired."""


def create_approval_token(user_id: UUID, action: ApprovalAction, config: ParbakedConfig) -> str:
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign approval token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": str(user_id),
        "action": action,
        "aud": _AUDIENCE,
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC)
        + timedelta(hours=config.approval_token_expiry_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_approval_token(token: str, config: ParbakedConfig) -> tuple[UUID, ApprovalAction]:
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidApprovalToken(str(exc)) from exc

    action = payload.get("action")
    if action not in ("approve", "reject"):
        raise InvalidApprovalToken(f"Unknown approval action: {action!r}")

    try:
        user_id = UUID(payload["sub"])
    except (KeyError, ValueError) as exc:
        raise InvalidApprovalToken("Missing or malformed subject") from exc

    return user_id, action  # type: ignore[return-value]


def create_verify_token(user_id: UUID, config: ParbakedConfig) -> str:
    """Mint a magic link the user clicks to prove they own the email."""
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign verify token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": str(user_id),
        "aud": _VERIFY_AUDIENCE,
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC)
        + timedelta(hours=config.approval_token_expiry_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_verify_token(token: str, config: ParbakedConfig) -> UUID:
    """Validate a verification link, returning the user_id it's for."""
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_VERIFY_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidVerifyToken(str(exc)) from exc
    try:
        return UUID(payload["sub"])
    except (KeyError, ValueError) as exc:
        raise InvalidVerifyToken("Missing or malformed subject") from exc
