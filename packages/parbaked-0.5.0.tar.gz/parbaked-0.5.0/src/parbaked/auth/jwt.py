"""JWT issuance and verification.

Stateless session tokens keyed on the JWT secret from :class:`ParbakedConfig`.
"""

from __future__ import annotations

import secrets
from datetime import UTC, datetime, timedelta
from uuid import UUID

import jwt

from parbaked.config import ParbakedConfig


class InvalidTokenError(Exception):
    """Raised when a JWT can't be decoded or is expired."""


def _resolve_secret(config: ParbakedConfig) -> str:
    """Return the JWT secret, generating an ephemeral one if unset.

    A warning-worthy fallback: when no secret is configured, sessions reset
    on every process restart. Callers should set ``PARBAKED_JWT_SECRET`` in
    production.
    """
    if config.jwt_secret:
        return config.jwt_secret
    # In-process fallback so dev works out of the box.
    if not hasattr(_resolve_secret, "_ephemeral"):
        _resolve_secret._ephemeral = secrets.token_urlsafe(32)  # type: ignore[attr-defined]
    return _resolve_secret._ephemeral  # type: ignore[attr-defined]


def create_jwt(user_id: UUID, email: str, name: str, config: ParbakedConfig) -> str:
    payload = {
        "sub": str(user_id),
        "email": email,
        "name": name,
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC) + timedelta(days=config.jwt_expiry_days),
    }
    return jwt.encode(payload, _resolve_secret(config), algorithm=config.jwt_algorithm)


def decode_jwt(token: str, config: ParbakedConfig) -> dict:
    try:
        return jwt.decode(token, _resolve_secret(config), algorithms=[config.jwt_algorithm])
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidTokenError(str(exc)) from exc
