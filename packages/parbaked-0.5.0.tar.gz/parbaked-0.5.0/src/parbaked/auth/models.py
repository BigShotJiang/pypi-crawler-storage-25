"""SQLModel definitions for parbaked's auth tables.

parbaked owns the ``users`` table. Consumers wanting per-user app data should
add a related table keyed on ``users.id`` rather than extending this model —
SQLModel ``table=True`` subclassing is awkward.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from uuid import UUID, uuid4

from sqlmodel import Field, SQLModel


class UserStatus(StrEnum):
    """Admin-approval state for a parbaked account.

    Independent of email verification: a user has both a ``status`` (this enum)
    and an ``email_verified`` flag. They can only log in when status==active.
    The admin only sees the signup *after* the user has verified their email.
    """

    pending = "pending"  # signed up, awaiting admin approval
    active = "active"    # approved, can log in
    rejected = "rejected"  # admin rejected — cannot log in


def _utcnow() -> datetime:
    return datetime.now(UTC)


class User(SQLModel, table=True):
    __tablename__ = "users"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    email: str = Field(unique=True, index=True, max_length=255)
    name: str = Field(max_length=255)
    password_hash: str
    status: UserStatus = Field(default=UserStatus.pending)
    email_verified_at: datetime | None = Field(
        default=None,
        description=(
            "When the user proved they own this email (clicked the verification "
            "link). Until then they're invisible to the admin queue."
        ),
    )
    created_at: datetime = Field(default_factory=_utcnow)
    approved_at: datetime | None = None

    @property
    def email_verified(self) -> bool:
        return self.email_verified_at is not None
