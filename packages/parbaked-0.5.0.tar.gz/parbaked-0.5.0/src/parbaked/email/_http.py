"""Tiny stdlib-only HTTP helper for HTTP-API email transports.

Using ``urllib`` keeps the dep tree small (no httpx). The transports below
are simple POST-JSON-and-check-status calls — anything more complex (retries,
async, streaming) belongs in a proper HTTP client. We're not there yet.

Note on the User-Agent: providers (notably Resend, which sits behind
Cloudflare) reject Python's default ``Python-urllib/3.x`` UA as a bot
signature. We set a parbaked-branded UA so the request actually reaches the
upstream API.
"""

from __future__ import annotations

import json as _json
import urllib.error
import urllib.request


class HTTPEmailError(Exception):
    """Raised when an HTTP email API returns a non-2xx response."""


def _user_agent() -> str:
    from parbaked import __version__

    return f"parbaked/{__version__} (+https://github.com/saml7n/parbaked)"


def post_json(url: str, payload: dict, *, headers: dict[str, str], timeout: float = 15.0) -> bytes:
    """POST a JSON body, return the response bytes, raise on non-2xx.

    Kept private so we can swap to httpx later without touching transports.
    """
    body = _json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "User-Agent": _user_agent(),
            "Accept": "application/json",
            **headers,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 — trusted URLs
            return resp.read()
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode(errors="replace")[:500]
        raise HTTPEmailError(f"{url} returned {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise HTTPEmailError(f"{url} unreachable: {exc.reason}") from exc
