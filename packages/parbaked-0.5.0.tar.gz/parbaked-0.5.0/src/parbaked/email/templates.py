"""Plain-text email templates for the approval flow.

Templates are plain functions — override one or all by passing your own
``Templates`` instance into :func:`build_auth_router`.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from parbaked.auth.models import User
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailMessage


def render_user_verify_email(
    user: User, verify_url: str, config: ParbakedConfig
) -> EmailMessage:
    subject = f"[{config.app_name}] Confirm your email"
    body = (
        f"Hi {user.name},\n\n"
        f"Welcome to {config.app_name}! Please confirm your email address by "
        "clicking the link below:\n\n"
        f"  {verify_url}\n\n"
        f"The link expires in {config.approval_token_expiry_hours} hours.\n\n"
        "If you didn't sign up, you can ignore this email.\n"
    )
    return EmailMessage(to=user.email, subject=subject, body=body)


def render_admin_approval_request(
    user: User, approve_url: str, reject_url: str, config: ParbakedConfig
) -> EmailMessage:
    if config.admin_email is None:
        raise RuntimeError(
            "Cannot render admin approval email: PARBAKED_ADMIN_EMAIL is unset. "
            "Either set it, or stop calling this template directly — the router "
            "only invokes it when admin_email is set."
        )
    subject = f"[{config.app_name}] New signup: {user.name} ({user.email})"
    body = (
        f"A new user just signed up for {config.app_name}.\n\n"
        f"  Name:  {user.name}\n"
        f"  Email: {user.email}\n\n"
        "Approve:\n"
        f"  {approve_url}\n\n"
        "Reject:\n"
        f"  {reject_url}\n\n"
        f"Links expire in {config.approval_token_expiry_hours} hours.\n"
    )
    return EmailMessage(to=str(config.admin_email), subject=subject, body=body)


def render_user_approved(user: User, login_url: str, config: ParbakedConfig) -> EmailMessage:
    subject = f"[{config.app_name}] You're in"
    body = (
        f"Hi {user.name},\n\n"
        f"Your {config.app_name} account has been approved. "
        f"You can sign in at:\n\n  {login_url}\n\n"
        "— The team\n"
    )
    return EmailMessage(to=user.email, subject=subject, body=body)


def render_user_rejected(user: User, config: ParbakedConfig) -> EmailMessage:
    subject = f"[{config.app_name}] About your signup"
    body = (
        f"Hi {user.name},\n\n"
        f"Thanks for your interest in {config.app_name}. "
        "Unfortunately we weren't able to approve your account at this time.\n\n"
        "— The team\n"
    )
    return EmailMessage(to=user.email, subject=subject, body=body)


@dataclass
class Templates:
    """Bundle of renderers. Pass a customised instance to override copy."""

    user_verify_email: Callable[[User, str, ParbakedConfig], EmailMessage] = field(
        default=render_user_verify_email
    )
    admin_approval_request: Callable[[User, str, str, ParbakedConfig], EmailMessage] = field(
        default=render_admin_approval_request
    )
    user_approved: Callable[[User, str, ParbakedConfig], EmailMessage] = field(
        default=render_user_approved
    )
    user_rejected: Callable[[User, ParbakedConfig], EmailMessage] = field(
        default=render_user_rejected
    )
