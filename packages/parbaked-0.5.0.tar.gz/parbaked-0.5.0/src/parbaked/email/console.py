"""Console email transport — prints to stdout. Useful in dev and tests."""

from __future__ import annotations

import sys
from io import StringIO

from parbaked.email.base import EmailMessage


class ConsoleEmail:
    """Prints sent messages to stdout (or a provided file-like).

    In tests, pass ``buffer=StringIO()`` to capture messages for assertions.
    """

    def __init__(self, buffer: StringIO | None = None) -> None:
        self._buffer = buffer
        self.sent: list[EmailMessage] = []

    def send(self, message: EmailMessage) -> None:
        self.sent.append(message)
        stream = self._buffer if self._buffer is not None else sys.stdout
        divider = "─" * 60
        parts = [
            "",
            divider,
            f"To:      {message.to}",
            f"Subject: {message.subject}",
            divider,
            message.body.rstrip(),
            divider,
            "",
        ]
        stream.write("\n".join(parts) + "\n")
        if hasattr(stream, "flush"):
            stream.flush()
