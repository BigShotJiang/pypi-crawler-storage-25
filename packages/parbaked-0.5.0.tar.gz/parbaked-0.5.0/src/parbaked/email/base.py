"""Email transport protocol."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class EmailMessage:
    to: str
    subject: str
    body: str
    """Plain-text body. HTML is intentionally not in scope for v1."""


@runtime_checkable
class EmailTransport(Protocol):
    def send(self, message: EmailMessage) -> None: ...
