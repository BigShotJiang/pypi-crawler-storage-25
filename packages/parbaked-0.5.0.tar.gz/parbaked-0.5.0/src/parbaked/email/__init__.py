"""Email transports for parbaked.

parbaked ships **two** transports:

- :class:`ConsoleEmail` — dev default. Prints emails to stdout.
- :class:`ResendEmail` — prod. Resend.com — free up to 3000/month, no credit
  card, and sends from ``onboarding@resend.dev`` if you don't have your own
  domain yet.

Need a different provider? Implement the :class:`EmailTransport` protocol
yourself and pass it to ``Parbaked(email=...)``. We don't ship per-provider
classes for SendGrid/SES/Mailgun/etc. on purpose — pick one, opinion-ate hard,
keep parbaked small.
"""

from parbaked.email._http import HTTPEmailError
from parbaked.email.base import EmailMessage, EmailTransport
from parbaked.email.console import ConsoleEmail
from parbaked.email.resend import ResendEmail

__all__ = [
    "ConsoleEmail",
    "EmailMessage",
    "EmailTransport",
    "HTTPEmailError",
    "ResendEmail",
]
