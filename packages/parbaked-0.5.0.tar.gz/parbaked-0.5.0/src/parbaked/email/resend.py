"""Resend email transport — parbaked's one prod transport.

Resend is the recommended path because:
- 3,000 emails/month free, no credit card
- The ``onboarding@resend.dev`` sandbox lets you send mail without setting up
  any DNS records — perfect for weekend projects
- One env var (`PARBAKED_RESEND_KEY`) is all parbaked needs

For domain verification + your own from-address, see Resend's docs at
https://resend.com/docs/dashboard/domains/introduction. Once verified, set
``PARBAKED_MAIL_FROM=hello@yourdomain.com`` and you're done.
"""

from __future__ import annotations

from parbaked.config import ParbakedConfig
from parbaked.email._http import post_json
from parbaked.email.base import EmailMessage


class ResendEmail:
    """Sends via Resend's REST API.

    Requires:
    - ``PARBAKED_RESEND_KEY`` (the ``re_xxx`` API key from resend.com)

    Optional:
    - ``PARBAKED_MAIL_FROM`` (defaults to ``onboarding@resend.dev``, Resend's
      sandbox sender that works without DNS setup)
    """

    def __init__(self, config: ParbakedConfig) -> None:
        if not config.resend_api_key:
            raise ValueError(
                "ResendEmail requires PARBAKED_RESEND_KEY. "
                "Get a free key at https://resend.com/api-keys, or run "
                "`parbaked email setup` for an interactive walkthrough."
            )
        self.config = config

    def send(self, message: EmailMessage) -> None:
        post_json(
            "https://api.resend.com/emails",
            {
                "from": self.config.effective_mail_from(),
                "to": [message.to],
                "subject": message.subject,
                "text": message.body,
            },
            headers={"Authorization": f"Bearer {self.config.resend_api_key}"},
        )
