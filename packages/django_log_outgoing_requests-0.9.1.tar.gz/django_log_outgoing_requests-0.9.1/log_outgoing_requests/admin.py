from copy import deepcopy
from urllib.parse import urlparse

from django import forms
from django.contrib import admin
from django.utils.translation import gettext as _

from solo.admin import SingletonModelAdmin

from .conf import settings
from .models import OutgoingRequestsLog, OutgoingRequestsLogConfig
from .syntax_highlighting import highlight_body

try:
    import celery
except ImportError:
    celery = None


@admin.register(OutgoingRequestsLog)
class OutgoingRequestsLogAdmin(admin.ModelAdmin):
    list_display = (
        "hostname",
        "truncated_url",
        "params",
        "status_code",
        "method",
        "response_ms",
        "timestamp",
        "response_content_length",
    )
    list_filter = ("method", "timestamp", "status_code", "hostname")
    search_fields = ("url", "params", "hostname")
    date_hierarchy = "timestamp"
    show_full_result_count = False
    readonly_fields = (
        "url",
        "timestamp",
        "method",
        "query_params",
        "params",
        "req_headers",
        "req_content_type",
        "request_body",
        "status_code",
        "response_ms",
        "res_headers",
        "res_content_type",
        "response_content_length",
        "response_body",
        "raw_request_body",
        "raw_response_body",
        "trace",
    )

    fieldsets = [
        (
            _("Request"),
            {
                "fields": (
                    "method",
                    "url",
                    "timestamp",
                    "query_params",
                    "params",
                    "req_headers",
                    "req_content_type",
                    "req_body_encoding",
                    "request_body",
                ),
                "description": _(
                    "Details about the request made. Note that the formatted "
                    "request body may have applied cosmetic changes - for "
                    "debugging, consider looking at the raw bodies as well."
                ),
            },
        ),
        (
            _("Response"),
            {
                "fields": (
                    "status_code",
                    "response_ms",
                    "res_headers",
                    "res_content_type",
                    "res_body_encoding",
                    "response_content_length",
                    "response_body",
                ),
                "description": _(
                    "Details about the received response. Note that the formatted "
                    "response body may have applied cosmetic changes - for "
                    "debugging, consider looking at the raw bodies as well."
                ),
            },
        ),
        (
            _("Raw bodies"),
            {
                "fields": (
                    "raw_request_body",
                    "raw_response_body",
                ),
                "classes": ("collapse",),
                "description": _(
                    "The raw, unformatted bodies. These can help debugging syntax "
                    "errors."
                ),
            },
        ),
        (_("Extra"), {"fields": ("trace",)}),
    ]

    class Media:
        css = {
            "all": (
                "log_outgoing_requests/css/admin.css",
                "log_outgoing_requests/css/highlight.css",
            ),
        }

    def has_add_permission(self, request):
        return False

    def get_fieldsets(self, request, obj=None):
        fieldsets = super().get_fieldsets(request, obj)
        config = OutgoingRequestsLogConfig.get_solo()
        if not config.prettify_bodies:
            # replace the pretty-printend/highlighted bodies fields with their raw
            # equivalents
            updated_fieldsets = []
            for fieldset in fieldsets:
                label, options = fieldset
                updated_options = deepcopy(options)
                fields = list(options.get("fields", []))

                if "request_body" in fields:
                    _req_body_index = fields.index("request_body")
                    fields[_req_body_index] = "raw_request_body"

                if "response_body" in fields:
                    _resp_body_index = fields.index("response_body")
                    fields[_resp_body_index] = "raw_response_body"

                if fields:
                    updated_options["fields"] = fields
                updated_fieldsets.append((label, updated_options))

            return updated_fieldsets
        return fieldsets

    @admin.display(description=_("Query parameters"))
    def query_params(self, obj):
        return obj.query_params

    @admin.display(description=_("Request body"))
    def request_body(self, obj: OutgoingRequestsLog) -> str:
        return highlight_body(obj.request_body_decoded, obj.req_content_type)

    @admin.display(description=_("Response body"))
    def response_body(self, obj: OutgoingRequestsLog) -> str:
        return highlight_body(obj.response_body_decoded, obj.res_content_type)

    @admin.display(description=_("Request"))
    def raw_request_body(self, obj: OutgoingRequestsLog) -> str:
        return obj.request_body_decoded or "-"

    @admin.display(description=_("Response"))
    def raw_response_body(self, obj: OutgoingRequestsLog) -> str:
        return obj.response_body_decoded or "-"

    def truncated_url(self, obj):
        parsed_url = urlparse(obj.url)
        path = parsed_url.path
        max_length = 200
        path_length = len(path)

        if path_length <= max_length:
            return path

        half_length = (max_length - 3) // 2
        left_half = path[:half_length]
        right_half = path[-half_length:]
        return left_half + " \u2026 " + right_half


class ConfigAdminForm(forms.ModelForm):
    class Meta:
        model = OutgoingRequestsLogConfig
        fields = "__all__"  # noqa: DJ007
        help_texts = {
            "save_to_db": _(
                "Whether request logs should be saved to the database (default: "
                "{default})."
            ).format(default=settings.LOG_OUTGOING_REQUESTS_DB_SAVE),
            "save_body": _(
                "Whether the body of the request and response should be logged ("
                "default: {default})."
            ).format(default=settings.LOG_OUTGOING_REQUESTS_DB_SAVE_BODY),
        }


@admin.register(OutgoingRequestsLogConfig)
class OutgoingRequestsLogConfigAdmin(SingletonModelAdmin):
    form = ConfigAdminForm

    def get_fields(self, request, obj=None, *args, **kwargs):
        fields = super().get_fields(request, obj, *args, **kwargs)
        if celery is None and (obj and not obj.reset_db_save_after):
            fields.remove("reset_db_save_after")
        return fields
