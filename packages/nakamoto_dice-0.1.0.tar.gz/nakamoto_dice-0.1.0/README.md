# nakamoto-dice (Python)

```bash
pip install requests
```

```python
from nakamoto_dice import NakamotoDiceClient
import uuid

client = NakamotoDiceClient(session_id=str(uuid.uuid4()))

# Create a game on heads, 5k stake
resp = client.create_game(stake_tier=5000, position="heads")
print(resp["invoice"])  # bolt11 — pay with your wallet of choice

# Wait for someone to join, then poll resolution
import time
while True:
    g = client.get_game(resp["game_id"])
    if g.status == "complete":
        print("result:", g.result)
        break
    time.sleep(3)

# Sweep winnings
balance = client.get_winnings()
if balance.get("max_withdrawable_sats", 0) > 0:
    # Generate a bolt11 from your wallet for that amount, then:
    client.withdraw_winnings("lnbc...")
```

See [`examples/play_one_flip.py`](examples/play_one_flip.py) for a
complete worked example.

## With an affiliate code

Pass `referrer_code` at create-time and you (the agent) earn 25% of
the dice house cut on any games started under your code:

```python
client.create_game(stake_tier=5000, position="heads", referrer_code=client.get_referral()["code"])
```
