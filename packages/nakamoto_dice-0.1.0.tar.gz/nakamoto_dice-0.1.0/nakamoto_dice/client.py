"""Single-file client for Nakamoto's Dice. Sync, requests-based.

Public surface:
    client = NakamotoDiceClient(session_id="...")
    client.list_open_games(stake_tier=5000)
    client.create_game(stake_tier=5000, position="heads", referrer_code=None)
    client.join_game(game_id, position="tails")
    client.get_game(game_id)
    client.verify_game(game_id)
    client.check_payment(game_id, player_id)
    client.get_winnings()
    client.withdraw_winnings(bolt11)
    client.get_referral()
    client.withdraw_referral(bolt11)

The client makes plain HTTP calls. It does NOT pay invoices for you —
you bring your own Lightning wallet and pay the bolt11 strings the
site returns.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Optional
import json

try:
    import requests
except ImportError as e:
    raise ImportError(
        "requests is required: `pip install requests`"
    ) from e


GameType = Literal["coin_flip", "dice"]
GameStatus = Literal["waiting", "full", "resolving", "complete", "cancelled", "voided"]


@dataclass
class Player:
    id: str
    game_id: str
    player_position: str
    payment_status: str
    payout_status: str
    created_at: str
    session_id: Optional[str] = None
    client_seed: Optional[str] = None
    payout_invoice: Optional[str] = None
    refund_status: Optional[str] = None


@dataclass
class Game:
    id: str
    game_type: GameType
    stake_tier: int
    status: GameStatus
    server_seed_hash: str
    created_at: str
    server_seed: Optional[str] = None
    result: Optional[str] = None
    winner_player_id: Optional[str] = None
    house_cut_sats: Optional[int] = None
    resolved_at: Optional[str] = None
    players: list[Player] = field(default_factory=list)

    @classmethod
    def from_json(cls, d: dict) -> "Game":
        players = [Player(**p) for p in d.pop("players", [])]
        return cls(players=players, **d)


class NakamotoDiceClient:
    """Single-session client. The session_id is your bot's identity — keep
    it stable to attribute games/winnings/referral to the same wallet.
    Generate one at startup with `uuid.uuid4()`, store it, reuse forever."""

    def __init__(
        self,
        session_id: str,
        site: str = "https://nakamotosdice.com",
        timeout: int = 30,
    ):
        if not session_id:
            raise ValueError("session_id required (use uuid.uuid4())")
        self.session_id = session_id
        self.site = site.rstrip("/")
        self.timeout = timeout
        self._http = requests.Session()

    def _url(self, path: str) -> str:
        return f"{self.site}/api{path}"

    def _request(self, method: str, path: str, **kwargs) -> dict:
        r = self._http.request(method, self._url(path), timeout=self.timeout, **kwargs)
        if not r.ok:
            try:
                err = r.json()
            except Exception:
                err = {"error": r.text}
            raise RuntimeError(f"{method} {path} → {r.status_code}: {err}")
        return r.json() if r.text else {}

    def list_open_games(self, game_type: GameType = "coin_flip", stake_tier: Optional[int] = None) -> list[Game]:
        params = {"type": game_type, "status": "waiting"}
        if stake_tier:
            params["stake_tier"] = str(stake_tier)
        data = self._request("GET", "/games", params=params)
        return [Game.from_json(g) for g in data]

    def create_game(
        self,
        stake_tier: int,
        position: str,
        game_type: GameType = "coin_flip",
        client_seed: Optional[str] = None,
        referrer_code: Optional[str] = None,
    ) -> dict:
        """Create a game. Returns dict with game_id, server_seed_hash, position,
        stake_tier, invoice (bolt11 to pay), player_id."""
        body = {
            "game_type": game_type,
            "stake_tier": stake_tier,
            "position": position,
            "session_id": self.session_id,
            "client_seed": client_seed or _random_seed(),
        }
        if referrer_code:
            body["referrer_code"] = referrer_code
        return self._request("POST", "/games", json=body)

    def join_game(
        self,
        game_id: str,
        position: str,
        client_seed: Optional[str] = None,
        referrer_code: Optional[str] = None,
    ) -> dict:
        """Join an open game. Returns dict with player_id, position, invoice."""
        body = {
            "position": position,
            "session_id": self.session_id,
            "client_seed": client_seed or _random_seed(),
        }
        if referrer_code:
            body["referrer_code"] = referrer_code
        return self._request("POST", f"/games/{game_id}/join", json=body)

    def get_game(self, game_id: str) -> Game:
        return Game.from_json(self._request("GET", f"/games/{game_id}"))

    def verify_game(self, game_id: str) -> dict:
        return self._request("GET", f"/games/{game_id}/verify")

    def check_payment(self, game_id: str, player_id: str) -> dict:
        return self._request("GET", f"/games/{game_id}/payment/{player_id}")

    def get_winnings(self) -> dict:
        return self._request("GET", f"/winnings?session_id={self.session_id}")

    def withdraw_winnings(self, bolt11: str) -> dict:
        return self._request("POST", "/winnings/withdraw", json={
            "session_id": self.session_id, "bolt11": bolt11,
        })

    def get_referral(self) -> dict:
        return self._request("GET", f"/referral?session_id={self.session_id}")

    def withdraw_referral(self, bolt11: str) -> dict:
        return self._request("POST", "/referral/withdraw", json={
            "session_id": self.session_id, "bolt11": bolt11,
        })


def _random_seed() -> str:
    import secrets
    return secrets.token_hex(16)
