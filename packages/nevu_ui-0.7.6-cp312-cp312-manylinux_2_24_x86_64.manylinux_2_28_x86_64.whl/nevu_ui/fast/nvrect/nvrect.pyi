from typing import overload
from nevu_ui.fast.nvvector2 import NvVector2

import pygame
class NvRect:
    x: float
    y: float
    w: float
    h: float
    @overload
    def __init__(self): ...
    @overload
    def __init__(self, xy: NvVector2, wh: NvVector2): ...
    @overload
    def __init__(self, nvrect: "NvRect"): ...
    @overload
    def __init__(self, x: float | int, y: float | int, w: float | int, h: float | int): ...
    
    @overload
    def __getitem__(self, index: int): ...
    @overload
    def __setitem__(self, index: int, value: float | int): ...
    
    @property
    def xy(self) -> NvVector2: ...
    @property
    def yx(self) -> NvVector2: ...
    @property
    def xw(self) -> NvVector2: ...
    @property
    def yh(self) -> NvVector2: ...
    @property
    def wh(self) -> NvVector2: ...
    @property
    def hw(self) -> NvVector2: ...
    
    @property
    def xywh(self) -> "NvRect": ...
    @property
    def yxwh(self) -> NvVector2: ...
    
    @property
    def topleft(self) -> NvVector2: ...
    @property
    def topright(self) -> NvVector2: ...
    @property
    def bottomleft(self) -> NvVector2: ...
    @property
    def bottomright(self) -> NvVector2: ...
    
    @property
    def size(self) -> NvVector2: ...
    @size.setter
    def size(self, value: NvVector2 | list | tuple): ...
    
    def get_int_tuple(self) -> tuple[int, int, int, int]: ...
    def get_tuple(self) -> tuple[float, float, float, float]: ...
    def get_pygame_rect(self) -> pygame.Rect: ...
    def collide_rect(self, nvrect: "NvRect") -> bool: ...
    
    @overload
    def collide_point(self, x: float | int, y: float | int) -> bool: ...
    @overload
    def collide_point(self, xy: NvVector2 | list | tuple) -> bool: ...
    @overload
    def move_ip(self, x: float | int, y: float | int) -> None: ...
    @overload
    def move_ip(self, xy: NvVector2 | list | tuple) -> None: ...

    @property
    def left(self):
        return self.x
    
    @left.setter
    def left(self, value):
        self.x = value
    
    @property
    def top(self):
        return self.y
    
    @top.setter
    def top(self, value):
        self.y = value
    
    @property
    def right(self):
        return self.x + self.w
    
    @right.setter
    def right(self, value):
        self.w = value - self.x

    @property
    def bottom(self):
        return self.y + self.h
    
    @bottom.setter
    def bottom(self, value):
        self.h = value - self.y