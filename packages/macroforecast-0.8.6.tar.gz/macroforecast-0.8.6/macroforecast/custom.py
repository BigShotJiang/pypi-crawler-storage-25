"""Runtime registries for user-defined macroforecast extensions."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from .preprocessing.feature_blocks import (
    CUSTOM_FEATURE_BLOCK_CONTRACT_VERSION,
    CUSTOM_FEATURE_COMBINER_CONTRACT_VERSION,
    FeatureBlockCallable,
    FeatureBlockCallableResult,
    FeatureCombinerCallable,
    FeatureCombinerCallableResult,
    custom_feature_block_contract_metadata,
    custom_feature_combiner_contract_metadata,
    custom_final_z_selection_contract_metadata,
    validate_feature_block_callable_result,
    validate_feature_combiner_callable_result,
)

CUSTOM_MODEL_CONTRACT_VERSION = "custom_model_v1"
CUSTOM_PREPROCESSOR_CONTRACT_VERSION = "custom_preprocessor_v1"
TARGET_TRANSFORMER_CONTRACT_VERSION = "target_transformer_v1"

CustomModelFunction = Callable[[Any, Any, Any, dict[str, Any]], Any]
CustomPreprocessorFunction = Callable[[Any, Any, Any, dict[str, Any]], Any]
TargetTransformerFactory = Callable[[], Any]
CustomFeatureBlockFunction = FeatureBlockCallable
CustomFeatureCombinerFunction = FeatureCombinerCallable


@dataclass(frozen=True)
class CustomModelSpec:
    name: str
    function: CustomModelFunction
    description: str | None = None


@dataclass(frozen=True)
class CustomPreprocessorSpec:
    name: str
    function: CustomPreprocessorFunction
    description: str | None = None


@dataclass(frozen=True)
class TargetTransformerSpec:
    name: str
    factory: TargetTransformerFactory
    description: str | None = None
    model_scale: str = "transformed"
    forecast_scale: str = "raw"
    evaluation_scale: str = "raw"


@dataclass(frozen=True)
class CustomFeatureBlockSpec:
    name: str
    function: CustomFeatureBlockFunction
    block_kind: str
    description: str | None = None


@dataclass(frozen=True)
class CustomFeatureCombinerSpec:
    name: str
    function: CustomFeatureCombinerFunction
    description: str | None = None


_CUSTOM_MODELS: dict[str, CustomModelSpec] = {}
_CUSTOM_PREPROCESSORS: dict[str, CustomPreprocessorSpec] = {}
_TARGET_TRANSFORMERS: dict[str, TargetTransformerSpec] = {}
_CUSTOM_FEATURE_BLOCKS: dict[tuple[str, str], CustomFeatureBlockSpec] = {}
_CUSTOM_FEATURE_COMBINERS: dict[str, CustomFeatureCombinerSpec] = {}


def custom_model_contract_metadata() -> dict[str, Any]:
    required_context_fields = (
        "contract_version",
        "model_name",
        "target",
        "horizon",
        "feature_names",
        "feature_runtime_builder",
        "block_order",
        "block_roles",
        "alignment",
        "leakage_contract",
        "mode",
    )
    optional_context_fields = (
        "feature_builder",
        "legacy_feature_builder",
        "feature_dispatch_source",
        "auxiliary_payloads",
        "train_index",
        "target_train_index",
        "forecast_type",
        "forecast_object",
        "recursive_step",
        "raw_panel_iterated_step",
        "x_path_policy",
        "x_source_date",
        "scheduled_known_future_x_columns",
        "recursive_x_model_family",
        "recursive_x_model_fallback_columns",
        "raw_panel_iterated_runtime_contract",
        "raw_panel_iterated_payload_contract",
    )
    return {
        "contract_version": CUSTOM_MODEL_CONTRACT_VERSION,
        "layer": 3,
        "callable": "fn(X_train, y_train, X_test, context) -> scalar",
        "input_shape": {
            "X_train": "n_train x n_features",
            "y_train": "n_train",
            "X_test": "1 x n_features",
        },
        "return_shape": "scalar or one-element array/sequence",
        "required_context_fields": required_context_fields,
        "optional_context_fields": optional_context_fields,
        "context_fields": tuple(dict.fromkeys(required_context_fields + optional_context_fields)),
        "auxiliary_payload_contracts": (
            "fred_sd_native_frequency_block_payload_v1",
            "fred_sd_mixed_frequency_model_adapter_v1",
        ),
        "auxiliary_payload_conditions": {
            "fred_sd_native_frequency_block_payload_v1": {
                "context_key": "auxiliary_payloads.fred_sd_native_frequency_block_payload",
                "present_when": (
                    "dataset includes fred_sd and "
                    "fred_sd_mixed_frequency_representation is "
                    "native_frequency_block_payload or mixed_frequency_model_adapter"
                ),
                "contains": (
                    "contract_version",
                    "blocks",
                    "block_order",
                    "column_to_native_frequency",
                ),
            },
            "fred_sd_mixed_frequency_model_adapter_v1": {
                "context_key": "auxiliary_payloads.fred_sd_mixed_frequency_model_adapter",
                "present_when": (
                    "dataset includes fred_sd and "
                    "fred_sd_mixed_frequency_representation is mixed_frequency_model_adapter"
                ),
                "contains": (
                    "contract_version",
                    "adapter_kind",
                    "block_payload_contract",
                    "requires_registered_custom_model",
                ),
            },
        },
        "accepted_return": {
            "scalar": "single forecast value",
            "one_element_array": "array or sequence with exactly one forecast value",
        },
        "leakage_rule": "consume only Layer 2 train/pred matrices supplied by runtime",
        "routing_notes": (
            "registered custom model names are accepted as model_family values "
            "in the current Python process",
            "YAML recipes can select the registered name, but they do not import "
            "or register Python callables by themselves",
            "custom models should not read future rows, full-sample statistics, "
            "or source panels outside the supplied train/pred payload",
        ),
    }


def custom_preprocessor_contract_metadata() -> dict[str, Any]:
    return {
        "contract_version": CUSTOM_PREPROCESSOR_CONTRACT_VERSION,
        "layer": 2,
        "callable": "fn(X_train, y_train, X_test, context) -> (X_train, X_test)",
        "scope": "matrix post-processing after Layer 2 representation construction",
        "target_rule": "y_train is read-only; target-scale transforms use target_transformer",
        "context_fields": (
            "feature_names",
            "feature_builder",
            "feature_runtime_builder",
            "legacy_feature_builder",
            "feature_dispatch_source",
            "block_order",
            "block_roles",
            "alignment",
            "leakage_contract",
            "mode",
        ),
    }


def target_transformer_contract_metadata() -> dict[str, Any]:
    return {
        "contract_version": TARGET_TRANSFORMER_CONTRACT_VERSION,
        "layer": 2,
        "callable": (
            "fit(target_train, context); transform(target, context); "
            "inverse_transform_prediction(target_pred, context)"
        ),
        "scale_rule": "final forecasts and evaluation metrics must be on raw target scale",
    }


def custom_method_extension_contracts() -> dict[str, Any]:
    return {
        "layer2_feature_block": {
            "contract_version": CUSTOM_FEATURE_BLOCK_CONTRACT_VERSION,
            "temporal": custom_feature_block_contract_metadata(block_kind="temporal"),
            "rotation": custom_feature_block_contract_metadata(block_kind="rotation"),
            "factor": custom_feature_block_contract_metadata(block_kind="factor"),
        },
        "layer2_feature_combiner": {
            "contract_version": CUSTOM_FEATURE_COMBINER_CONTRACT_VERSION,
            "contract": custom_feature_combiner_contract_metadata(),
        },
        "layer2_final_z_selection": custom_final_z_selection_contract_metadata(),
        "layer2_matrix_preprocessor": custom_preprocessor_contract_metadata(),
        "layer2_target_transformer": target_transformer_contract_metadata(),
        "layer3_model": custom_model_contract_metadata(),
    }


def _validate_name(name: str, *, kind: str) -> str:
    normalized = str(name).strip()
    if not normalized:
        raise ValueError(f"custom {kind} name must be non-empty")
    if normalized.startswith("_"):
        raise ValueError(f"custom {kind} name must not start with '_'")
    return normalized


def register_model(
    name: str,
    function: CustomModelFunction | None = None,
    *,
    description: str | None = None,
):
    """Register a user-defined model function.

    The function contract is:

    ``fn(X_train, y_train, X_test, context) -> prediction``

    ``X_test`` is currently one row. The return value may be a scalar or a
    one-element sequence/array. Registered names are accepted as
    ``model_family`` values by the compiler in the current Python process.
    """

    model_name = _validate_name(name, kind="model")

    def _decorator(fn: CustomModelFunction) -> CustomModelFunction:
        if not callable(fn):
            raise TypeError("custom model function must be callable")
        _CUSTOM_MODELS[model_name] = CustomModelSpec(
            name=model_name,
            function=fn,
            description=description,
        )
        return fn

    if function is not None:
        return _decorator(function)
    return _decorator


def custom_model(
    name: str,
    function: CustomModelFunction | None = None,
    *,
    description: str | None = None,
):
    """Decorator alias for :func:`register_model`."""

    return register_model(name, function=function, description=description)


def register_preprocessor(
    name: str,
    function: CustomPreprocessorFunction | None = None,
    *,
    description: str | None = None,
):
    """Register a user-defined matrix preprocessor.

    The function contract is:

    ``fn(X_train, y_train, X_test, context) -> (X_train, X_test)``

    ``y_train`` is provided as context for target-aware feature preprocessing,
    but the training target itself is not transformed in the MVP API.
    """

    preprocessor_name = _validate_name(name, kind="preprocessor")

    def _decorator(fn: CustomPreprocessorFunction) -> CustomPreprocessorFunction:
        if not callable(fn):
            raise TypeError("custom preprocessor function must be callable")
        _CUSTOM_PREPROCESSORS[preprocessor_name] = CustomPreprocessorSpec(
            name=preprocessor_name,
            function=fn,
            description=description,
        )
        return fn

    if function is not None:
        return _decorator(function)
    return _decorator


def custom_preprocessor(name: str, function: CustomPreprocessorFunction | None = None, **kwargs):
    """Decorator alias for :func:`register_preprocessor`."""
    return register_preprocessor(name, function=function, **kwargs)


def _target_transformer_factory(transformer: Any) -> TargetTransformerFactory:
    if isinstance(transformer, type):
        return transformer
    if callable(transformer):
        try:
            sample = transformer()
        except TypeError:
            return lambda: transformer
        missing = [
            method
            for method in ("fit", "transform", "inverse_transform_prediction")
            if not hasattr(sample, method)
        ]
        if not missing:
            return transformer
        return lambda: transformer
    return lambda: transformer


def _validate_target_transformer_instance(instance: Any, *, name: str) -> None:
    missing = [
        method
        for method in ("fit", "transform", "inverse_transform_prediction")
        if not callable(getattr(instance, method, None))
    ]
    if missing:
        raise TypeError(
            f"target transformer {name!r} must provide callable methods: {missing}"
        )


def register_target_transformer(
    name: str,
    transformer: Any | None = None,
    *,
    description: str | None = None,
):
    """Register a user-defined target transformer protocol.

    MVP registration records the contract but execution is intentionally not
    wired yet. The transformer instance must provide:

    ``fit(target_train, context)``
    ``transform(target, context)``
    ``inverse_transform_prediction(target_pred, context)``

    Target transformer execution must return final forecasts and metrics on
    the raw target scale.
    """

    transformer_name = _validate_name(name, kind="target transformer")

    def _decorator(obj: Any) -> Any:
        factory = _target_transformer_factory(obj)
        _validate_target_transformer_instance(factory(), name=transformer_name)
        _TARGET_TRANSFORMERS[transformer_name] = TargetTransformerSpec(
            name=transformer_name,
            factory=factory,
            description=description,
        )
        return obj

    if transformer is not None:
        return _decorator(transformer)
    return _decorator


def target_transformer(name: str, transformer: Any | None = None, **kwargs):
    """Decorator alias for :func:`register_target_transformer`."""
    return register_target_transformer(name, transformer=transformer, **kwargs)


def _validate_feature_block_kind(block_kind: str) -> str:
    kind = str(block_kind).strip()
    if kind not in {"temporal", "rotation", "factor"}:
        raise ValueError("custom feature block kind must be one of: temporal, rotation, factor")
    return kind


def register_feature_block(
    name: str,
    function: CustomFeatureBlockFunction | None = None,
    *,
    block_kind: str = "temporal",
    description: str | None = None,
):
    """Register a user-defined Layer 2 feature-block callable.

    The callable receives a :class:`FeatureBlockCallableContext` and must return
    a :class:`FeatureBlockCallableResult`. Runtime validates stable names and
    leakage metadata before appending the returned train/pred feature frames.
    """

    block_name = _validate_name(name, kind="feature block")
    kind = _validate_feature_block_kind(block_kind)

    def _decorator(fn: CustomFeatureBlockFunction) -> CustomFeatureBlockFunction:
        if not callable(fn):
            raise TypeError("custom feature block function must be callable")
        _CUSTOM_FEATURE_BLOCKS[(kind, block_name)] = CustomFeatureBlockSpec(
            name=block_name,
            function=fn,
            block_kind=kind,
            description=description,
        )
        return fn

    if function is not None:
        return _decorator(function)
    return _decorator


def custom_feature_block(name: str, function: CustomFeatureBlockFunction | None = None, **kwargs):
    """Decorator alias for :func:`register_feature_block`."""
    return register_feature_block(name, function=function, **kwargs)


def register_feature_combiner(
    name: str,
    function: CustomFeatureCombinerFunction | None = None,
    *,
    description: str | None = None,
):
    """Register a user-defined Layer 2 feature-block combiner.

    The callable receives a :class:`FeatureCombinerCallableContext` and must
    return a :class:`FeatureCombinerCallableResult`. Runtime validates the
    final train/pred matrices, stable feature names, and leakage metadata
    before handing the resulting ``Z`` to Layer 3.
    """

    combiner_name = _validate_name(name, kind="feature combiner")

    def _decorator(fn: CustomFeatureCombinerFunction) -> CustomFeatureCombinerFunction:
        if not callable(fn):
            raise TypeError("custom feature combiner function must be callable")
        _CUSTOM_FEATURE_COMBINERS[combiner_name] = CustomFeatureCombinerSpec(
            name=combiner_name,
            function=fn,
            description=description,
        )
        return fn

    if function is not None:
        return _decorator(function)
    return _decorator


def custom_feature_combiner(name: str, function: CustomFeatureCombinerFunction | None = None, **kwargs):
    """Decorator alias for :func:`register_feature_combiner`."""
    return register_feature_combiner(name, function=function, **kwargs)


def is_custom_feature_block(name: str, *, block_kind: str | None = None) -> bool:
    block_name = str(name)
    if block_kind is not None:
        return (_validate_feature_block_kind(block_kind), block_name) in _CUSTOM_FEATURE_BLOCKS
    return any(registered_name == block_name for _, registered_name in _CUSTOM_FEATURE_BLOCKS)


def get_custom_feature_block(name: str, *, block_kind: str) -> CustomFeatureBlockSpec:
    kind = _validate_feature_block_kind(block_kind)
    try:
        return _CUSTOM_FEATURE_BLOCKS[(kind, str(name))]
    except KeyError as exc:
        raise KeyError(f"custom {kind} feature block {name!r} is not registered") from exc


def list_custom_feature_blocks(*, block_kind: str | None = None) -> tuple[str, ...]:
    if block_kind is None:
        return tuple(sorted(name for _, name in _CUSTOM_FEATURE_BLOCKS))
    kind = _validate_feature_block_kind(block_kind)
    return tuple(sorted(name for (registered_kind, name) in _CUSTOM_FEATURE_BLOCKS if registered_kind == kind))


def validate_custom_feature_block_result(result: FeatureBlockCallableResult) -> None:
    validate_feature_block_callable_result(result)


def is_custom_feature_combiner(name: str) -> bool:
    return str(name) in _CUSTOM_FEATURE_COMBINERS


def get_custom_feature_combiner(name: str) -> CustomFeatureCombinerSpec:
    try:
        return _CUSTOM_FEATURE_COMBINERS[str(name)]
    except KeyError as exc:
        raise KeyError(f"custom feature combiner {name!r} is not registered") from exc


def list_custom_feature_combiners() -> tuple[str, ...]:
    return tuple(sorted(_CUSTOM_FEATURE_COMBINERS))


def validate_custom_feature_combiner_result(result: FeatureCombinerCallableResult) -> None:
    validate_feature_combiner_callable_result(result)


def is_custom_model(name: str) -> bool:
    return str(name) in _CUSTOM_MODELS


def get_custom_model(name: str) -> CustomModelSpec:
    try:
        return _CUSTOM_MODELS[str(name)]
    except KeyError as exc:
        raise KeyError(f"custom model {name!r} is not registered") from exc


def list_custom_models() -> tuple[str, ...]:
    return tuple(sorted(_CUSTOM_MODELS))


def is_custom_preprocessor(name: str) -> bool:
    return str(name) in _CUSTOM_PREPROCESSORS


def get_custom_preprocessor(name: str) -> CustomPreprocessorSpec:
    try:
        return _CUSTOM_PREPROCESSORS[str(name)]
    except KeyError as exc:
        raise KeyError(f"custom preprocessor {name!r} is not registered") from exc


def list_custom_preprocessors() -> tuple[str, ...]:
    return tuple(sorted(_CUSTOM_PREPROCESSORS))


def is_custom_target_transformer(name: str) -> bool:
    return str(name) in _TARGET_TRANSFORMERS


def get_custom_target_transformer(name: str) -> TargetTransformerSpec:
    try:
        return _TARGET_TRANSFORMERS[str(name)]
    except KeyError as exc:
        raise KeyError(f"target transformer {name!r} is not registered") from exc


def list_custom_target_transformers() -> tuple[str, ...]:
    return tuple(sorted(_TARGET_TRANSFORMERS))


def clear_custom_models() -> None:
    """Clear custom model registry.

    Intended for tests and interactive cleanup.
    """

    _CUSTOM_MODELS.clear()


def clear_custom_preprocessors() -> None:
    """Clear custom preprocessor registry."""
    _CUSTOM_PREPROCESSORS.clear()


def clear_custom_target_transformers() -> None:
    """Clear custom target transformer registry."""
    _TARGET_TRANSFORMERS.clear()


def clear_custom_feature_blocks() -> None:
    """Clear custom feature block registry."""
    _CUSTOM_FEATURE_BLOCKS.clear()


def clear_custom_feature_combiners() -> None:
    """Clear custom feature combiner registry."""
    _CUSTOM_FEATURE_COMBINERS.clear()


def clear_custom_extensions() -> None:
    """Clear all runtime extension registries."""
    clear_custom_models()
    clear_custom_preprocessors()
    clear_custom_target_transformers()
    clear_custom_feature_blocks()
    clear_custom_feature_combiners()
