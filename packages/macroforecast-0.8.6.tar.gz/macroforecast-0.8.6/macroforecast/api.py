"""Top-level public entry points for macroforecast v0.1.

These are thin re-exports over :mod:`macroforecast.core.execution` so that the
common case ``import macroforecast; macroforecast.run("recipe.yaml")`` works without
reaching into ``macroforecast.core``.
"""
from __future__ import annotations

from .core.execution import (
    ManifestExecutionResult,
    ReplicationResult,
    execute_recipe as run,
    execute_recipe_file as run_file,
    replicate_recipe as replicate,
)

__all__ = [
    "ManifestExecutionResult",
    "ReplicationResult",
    "replicate",
    "run",
    "run_file",
]
