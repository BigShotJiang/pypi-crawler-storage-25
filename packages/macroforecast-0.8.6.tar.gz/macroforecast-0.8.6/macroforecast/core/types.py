from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import pandas as pd

@dataclass(frozen=True)
class DataType:
    """Base class for typed artifacts passed between DAG nodes."""


@dataclass(frozen=True)
class MetadataArtifact(DataType):
    values: dict[str, Any] = field(default_factory=dict)


class PanelMetadata(MetadataArtifact):
    pass


class LaggedPanelMetadata(MetadataArtifact):
    pass


class FactorMetadata(MetadataArtifact):
    pass


class SeriesMetadata(MetadataArtifact):
    pass


class FeatureMetadata(MetadataArtifact):
    pass


class ForecastMetadata(MetadataArtifact):
    pass


class TrainingMetadata(MetadataArtifact):
    pass


class ArtifactManifest(MetadataArtifact):
    pass


class DataFrameArtifact(MetadataArtifact):
    pass


class MappingArtifact(MetadataArtifact):
    pass


@dataclass(frozen=True)
class L0MetaArtifact(DataType):
    failure_policy: Literal["fail_fast", "continue_on_failure"]
    reproducibility_mode: Literal["seeded_reproducible", "exploratory"]
    compute_mode: Literal["serial", "parallel"]
    random_seed: int | None
    parallel_unit: Literal["models", "horizons", "targets", "oos_dates"] | None
    n_workers: int | Literal["auto"] | None
    gpu_deterministic: bool
    derived_study_scope: str
    derived_execution_route: str = "comparison_sweep"


@dataclass(frozen=True)
class L1DataDefinitionArtifact(DataType):
    custom_source_policy: Literal["official_only", "custom_panel_only", "official_plus_custom"]
    dataset: Literal["fred_md", "fred_qd", "fred_sd", "fred_md+fred_sd", "fred_qd+fred_sd"] | None
    frequency: Literal["monthly", "quarterly"]
    vintage_policy: Literal["current_vintage", "real_time_alfred"] | None
    target_structure: Literal["single_target", "multi_series_target"]
    target: str | None = None
    targets: tuple[str, ...] = ()
    variable_universe: (
        Literal[
            "all_variables",
            "core_variables",
            "category_variables",
            "target_specific_variables",
            "explicit_variable_list",
        ]
        | None
    ) = None
    target_geography_scope: Literal["single_state", "all_states", "selected_states"] | None = None
    predictor_geography_scope: Literal["match_target", "all_states", "selected_states", "national_only"] | None = None
    sample_start_rule: Literal["earliest_available", "fixed_date", "max_balanced"] = "max_balanced"
    sample_end_rule: Literal["latest_available", "fixed_date"] = "latest_available"
    horizon_set: Literal["standard_md", "standard_qd", "single", "custom_list", "range_up_to_h"] = "standard_md"
    target_horizons: tuple[int, ...] = ()
    regime_definition: str = "none"
    raw_panel: "Panel" = field(default_factory=lambda: Panel())
    leaf_config: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class L1RegimeMetadataArtifact(DataType):
    definition: Literal[
        "none",
        "external_nber",
        "external_user_provided",
        "estimated_markov_switching",
        "estimated_threshold",
        "estimated_structural_break",
    ]
    n_regimes: int
    regime_label_series: "Series | None" = None
    regime_probabilities: "Series | None" = None
    transition_matrix: Any | None = None
    estimation_temporal_rule: str | None = None
    estimation_metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Panel(DataType):
    data: pd.DataFrame = field(default_factory=pd.DataFrame)
    shape: tuple[Any, Any] | None = None
    column_names: tuple[str, ...] = ()
    index: pd.DatetimeIndex | None = None
    metadata: PanelMetadata = field(default_factory=PanelMetadata)


@dataclass(frozen=True)
class L2CleanPanelArtifact(Panel):
    panel: Panel = field(default_factory=Panel)
    column_metadata: dict[str, Any] = field(default_factory=dict)
    cleaning_log: dict[str, Any] = field(default_factory=dict)
    n_imputed_cells: int = 0
    n_outliers_flagged: int = 0
    n_truncated_obs: int = 0
    transform_map_applied: dict[str, int] = field(default_factory=dict)
    upstream_hashes: dict[str, str] = field(default_factory=dict)
    cleaning_temporal_rules: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class LaggedPanel(DataType):
    shape: tuple[Any, Any] | None = None
    column_names: tuple[str, ...] = ()
    n_lag: int = 0
    metadata: LaggedPanelMetadata = field(default_factory=LaggedPanelMetadata)


@dataclass(frozen=True)
class Factor(DataType):
    shape: tuple[Any, Any] | None = None
    column_names: tuple[str, ...] = ()
    extraction_method: str = ""
    metadata: FactorMetadata = field(default_factory=FactorMetadata)


@dataclass(frozen=True)
class Series(DataType):
    shape: tuple[Any] | None = None
    name: str = ""
    metadata: SeriesMetadata = field(default_factory=SeriesMetadata)


@dataclass(frozen=True)
class MaskedPanel(DataType):
    panel: Panel
    mask: Any
    mask_meaning: Literal["missing", "outlier", "both"]


@dataclass(frozen=True)
class FeatureBundle(DataType):
    X_final: Panel | LaggedPanel | Factor
    y_final: Series
    metadata: FeatureMetadata = field(default_factory=FeatureMetadata)


@dataclass(frozen=True)
class StepRef(DataType):
    step_node_id: str
    op: str
    params: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ColumnLineage(DataType):
    column_name: str
    source_variable_ids: tuple[str, ...] = ()
    step_chain: tuple[StepRef, ...] = ()
    pipeline_id: str | None = None
    cascade_depth: int = 0
    output_type: str = "Panel"


@dataclass(frozen=True)
class PipelineDefinition(DataType):
    pipeline_id: str
    endpoint_node_id: str
    source_node_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class L3FeaturesArtifact(DataType):
    X_final: Panel | LaggedPanel | Factor
    y_final: Series
    sample_index: pd.DatetimeIndex | None = None
    horizon_set: tuple[int, ...] = ()
    upstream_hashes: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class L3MetadataArtifact(DataType):
    column_lineage: dict[str, ColumnLineage] = field(default_factory=dict)
    pipeline_definitions: dict[str, PipelineDefinition] = field(default_factory=dict)
    cascade_graph: dict[str, tuple[str, ...]] = field(default_factory=dict)
    transform_chain: dict[str, tuple[StepRef, ...]] = field(default_factory=dict)
    source_variables: dict[str, tuple[str, ...]] = field(default_factory=dict)


@dataclass(frozen=True)
class ModelArtifact(DataType):
    model_id: str
    family: str
    fitted_object: Any
    framework: Literal["sklearn", "xgboost", "lightgbm", "statsmodels", "torch", "tf", "custom_r", "custom"]
    fit_metadata: dict[str, Any] = field(default_factory=dict)
    feature_names: tuple[str, ...] = ()


@dataclass(frozen=True)
class ModelArtifactSet(DataType):
    artifacts: dict[str, ModelArtifact] = field(default_factory=dict)


@dataclass(frozen=True)
class ForecastArtifact(DataType):
    forecasts: dict[tuple[str, int, Any], float]
    forecast_intervals: dict[tuple[str, int, Any, float], float] = field(default_factory=dict)
    metadata: ForecastMetadata = field(default_factory=ForecastMetadata)


@dataclass(frozen=True)
class L4ForecastsArtifact(DataType):
    forecasts: dict[tuple[str, str, int, Any], float] = field(default_factory=dict)
    forecast_intervals: dict[tuple[str, str, int, Any, float], float] = field(default_factory=dict)
    forecast_object: Literal["point", "quantile", "density"] = "point"
    sample_index: pd.DatetimeIndex | None = None
    targets: tuple[str, ...] = ()
    horizons: tuple[int, ...] = ()
    model_ids: tuple[str, ...] = ()
    upstream_hashes: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class L4ModelArtifactsArtifact(DataType):
    artifacts: dict[str, ModelArtifact] = field(default_factory=dict)
    is_benchmark: dict[str, bool] = field(default_factory=dict)
    upstream_hashes: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class L4TrainingMetadataArtifact(DataType):
    forecast_origins: tuple[Any, ...] = ()
    refit_origins: dict[str, tuple[Any, ...]] = field(default_factory=dict)
    training_window_per_origin: dict[tuple[str, Any], tuple[Any, Any]] = field(default_factory=dict)
    runtime_per_origin: dict[tuple[str, Any], float] = field(default_factory=dict)
    cache_hits_per_origin: dict[tuple[str, Any], bool] = field(default_factory=dict)
    tuning_log: dict[tuple[str, Any], dict[str, Any]] = field(default_factory=dict)
    upstream_hashes: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class MetricTable(DataType):
    df: pd.DataFrame
    metric_names: tuple[str, ...] = ()
    benchmark_id: str | None = None


@dataclass(frozen=True)
class L5EvaluationArtifact(DataType):
    metrics_table: pd.DataFrame = field(default_factory=pd.DataFrame)
    ranking_table: pd.DataFrame = field(default_factory=pd.DataFrame)
    benchmark_relative_metrics: dict[tuple[Any, ...], Any] = field(default_factory=dict)
    per_regime_metrics: dict[tuple[Any, ...], Any] | None = None
    decomposition_results: dict[str, Any] | None = None
    per_state_metrics: dict[tuple[Any, ...], Any] | None = None
    report_artifacts: dict[str, Any] = field(default_factory=dict)
    upstream_hashes: dict[str, str] = field(default_factory=dict)
    l5_axis_resolved: dict[str, Any] = field(default_factory=dict)
    # Per-(model_id, target, horizon, origin) loss panel. Required for
    # per-origin Hansen 2005 MCS / SPA / RC bootstrap; populated by
    # ``materialize_l5_minimal``. Empty when the L5 path falls back to
    # summary-only metrics (legacy behaviour).
    per_origin_loss_panel: pd.DataFrame = field(default_factory=pd.DataFrame)


@dataclass(frozen=True)
class L6TestsArtifact(DataType):
    equal_predictive_results: dict[tuple[Any, ...], Any] = field(default_factory=dict)
    nested_results: dict[tuple[Any, ...], Any] = field(default_factory=dict)
    cpa_results: dict[tuple[Any, ...], Any] = field(default_factory=dict)
    multiple_model_results: dict[str, Any] = field(default_factory=dict)
    density_results: dict[tuple[Any, ...], Any] | None = None
    direction_results: dict[tuple[Any, ...], Any] | None = None
    residual_results: dict[tuple[Any, ...], Any] | None = None
    test_metadata: dict[str, Any] = field(default_factory=dict)
    upstream_hashes: dict[str, str] = field(default_factory=dict)
    l6_axis_resolved: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class L7ImportanceArtifact(DataType):
    global_importance: dict[tuple[Any, ...], Any] = field(default_factory=dict)
    local_importance: dict[tuple[Any, ...], Any] | None = None
    group_importance: dict[tuple[Any, ...], Any] = field(default_factory=dict)
    lineage_importance: dict[tuple[Any, ...], Any] = field(default_factory=dict)
    interaction_values: dict[tuple[Any, ...], Any] | None = None
    temporal_importance: dict[tuple[Any, ...], Any] | None = None
    stability_results: dict[tuple[Any, ...], Any] | None = None
    fevd_results: dict[tuple[Any, ...], Any] | None = None
    historical_decomposition_results: dict[tuple[Any, ...], Any] | None = None
    irf_results: dict[tuple[Any, ...], Any] | None = None
    forecast_decomposition_results: dict[tuple[Any, ...], Any] | None = None
    variable_inclusion_results: dict[str, Any] = field(default_factory=dict)
    figures: dict[str, str] = field(default_factory=dict)
    computation_metadata: dict[str, Any] = field(default_factory=dict)
    upstream_hashes: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class L7TransformationAttributionArtifact(DataType):
    pipeline_contributions: dict[tuple[Any, ...], Any] = field(default_factory=dict)
    decomposition_method: str = ""
    loss_function: str = ""
    baseline_pipeline: str = ""
    summary_table: pd.DataFrame = field(default_factory=pd.DataFrame)
    figures: dict[str, str] = field(default_factory=dict)
    upstream_hashes: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class RuntimeEnvironment(DataType):
    os_name: str = ""
    python_version: str = ""
    cpu_info: str = ""
    gpu_info: str | None = None


@dataclass(frozen=True)
class L8Manifest(DataType):
    recipe_hash: str = ""
    package_version: str = ""
    python_version: str = ""
    r_version: str | None = None
    julia_version: str | None = None
    dependency_lockfile_paths: dict[str, str] = field(default_factory=dict)
    git_commit_sha: str | None = None
    git_branch_name: str | None = None
    data_revision_tag: str = ""
    random_seed_used: int | None = None
    runtime_environment: RuntimeEnvironment = field(default_factory=RuntimeEnvironment)
    runtime_duration_per_layer: dict[str, float] = field(default_factory=dict)
    cells_summary: list[Any] = field(default_factory=list)
    sweep_combination: Any | None = None


@dataclass(frozen=True)
class ExportedFile(DataType):
    path: Path
    artifact_type: str = ""
    source_sink: str = ""


@dataclass(frozen=True)
class L8ArtifactsArtifact(DataType):
    output_directory: Path = Path("./macrocast_output/default_recipe/timestamp/")
    manifest: L8Manifest = field(default_factory=L8Manifest)
    exported_files: list[ExportedFile] = field(default_factory=list)
    artifact_count: int = 0
    upstream_hashes: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class TestResult(DataType):
    test_name: str
    statistic: float
    p_value: float
    decision_at_alpha: dict[float, bool] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TestResultSet(DataType):
    results: dict[str, dict[str, TestResult]] = field(default_factory=dict)


@dataclass(frozen=True)
class ImportanceResult(DataType):
    method: str
    scope: Literal["global", "local_per_origin", "local_per_observation"]
    values: pd.DataFrame
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ImportanceResultSet(DataType):
    results: dict[str, ImportanceResult] = field(default_factory=dict)


@dataclass(frozen=True)
class DiagnosticArtifact(DataType):
    layer_hooked: str = ""
    artifact_type: Literal["table", "figure", "json"] | str = "json"
    file_paths: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    enabled: bool = False


def __getattr__(name: str) -> Any:
    if name == "LAYER_SINKS":
        from .layers.registry import LAYER_SINKS

        return LAYER_SINKS
    raise AttributeError(name)
