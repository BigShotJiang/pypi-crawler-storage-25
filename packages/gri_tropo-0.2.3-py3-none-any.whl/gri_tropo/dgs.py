"""Calculate tropospheric angle and time corrections per ITU-R 2019."""

from __future__ import annotations

import numpy as np
from gri_utils.constants import ER_M, WGS84

_DEFLECT_COEFFS = np.array([3.23, -0.242, 0.0145, -0.000438])
_EXCESS_DELAY_COEFFS = np.array(
    [2.425, -0.1345, 0.007285, -0.0002203, 3.27e-6, -1.857e-8],
)

_LN10 = np.log(10.0)


def _horner(x: np.ndarray, coeffs: np.ndarray) -> np.ndarray:
    """Evaluate sum(coeffs[i] * x**i) via Horner's method."""
    result = np.full_like(x, coeffs[-1])
    for c in coeffs[-2::-1]:
        result = result * x + c
    return result


def dgs_tropo_corrections(  # noqa: PLR0915 - single numeric pass
    emitter_loc_lla: np.ndarray,
    collector_pos_xyz: np.ndarray,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
    calc_freq_offset: bool = False,  # noqa: FBT001, FBT002 # fix once we have it
) -> tuple[float, float] | tuple[np.ndarray, np.ndarray]:
    """Calculate tropospheric angle and time corrections per ITU-R 2019.

    Defaults set according to ITU-R 2019 paper. Supports scalar or batched
    emitter inputs.

    Args:
        emitter_loc_lla: Emitter location(s) as [lat, lon, alt] in degrees and
            meters. Shape (3,) for a single point or (K, 3) for K points.
        collector_pos_xyz: Collector position in ECEF XYZ coordinates (meters).
            Shape (3,).
        n_sur: Mean surface refractivity at sea level in n-units, default to global mean
        ref_ht: Mean scale height h_0 in km, default to global mean
        calc_freq_offset: Whether to calculate frequency offset (not implemented).

    Returns:
        Tuple of (cone_correction_rad, time_correction_sec). Scalars when the
        input emitter is a single (3,) array; numpy arrays of shape (K,) when
        the input is a (K, 3) batch.
    """
    a = 1e-6 * n_sur
    b = ref_ht

    emitter_arr = np.asarray(emitter_loc_lla, dtype=np.float64)
    scalar = emitter_arr.ndim == 1
    if scalar:
        emitter_arr = emitter_arr[np.newaxis, :]

    lat_deg = emitter_arr[:, 0]
    lon_deg = emitter_arr[:, 1]
    alt_m = emitter_arr[:, 2]

    # Trig of lat/lon computed once and reused for ECEF, local up, and the
    # ellipsoid curvature radii.
    lat_rad = np.radians(lat_deg)
    lon_rad = np.radians(lon_deg)
    sin_lat = np.sin(lat_rad)
    cos_lat = np.cos(lat_rad)
    sin_lon = np.sin(lon_rad)
    cos_lon = np.cos(lon_rad)

    # WGS84 radii of curvature from sin^2(lat) (avoid recomputing sin).
    e2 = WGS84.e2
    sin2_lat = sin_lat * sin_lat
    denom = 1.0 - e2 * sin2_lat
    n_lat = WGS84.a / np.sqrt(denom)  # prime vertical
    m_lat = WGS84.a * (1.0 - e2) / (denom * np.sqrt(denom))  # meridional
    sphere_r = np.sqrt(m_lat * n_lat)  # osculating-sphere radius

    # Emitter ECEF inline (avoids a second trig computation inside lla_to_xyz).
    nlat_plus_alt = n_lat + alt_m
    ex = nlat_plus_alt * cos_lat * cos_lon
    ey = nlat_plus_alt * cos_lat * sin_lon
    ez = ((1.0 - e2) * n_lat + alt_m) * sin_lat

    # Range vector and elevation angle from each emitter toward the collector.
    cx, cy, cz = (
        float(collector_pos_xyz[0]),
        float(collector_pos_xyz[1]),
        float(collector_pos_xyz[2]),
    )
    rx = cx - ex
    ry = cy - ey
    rz = cz - ez
    range_mag = np.sqrt(rx * rx + ry * ry + rz * rz)

    # Local up unit dotted with range / |range| = sin(elev).
    up_x = cos_lat * cos_lon
    up_y = cos_lat * sin_lon
    up_z = sin_lat
    sin_elev = (up_x * rx + up_y * ry + up_z * rz) / range_mag
    np.clip(sin_elev, -1.0, 1.0, out=sin_elev)
    elev_deg = np.degrees(np.arcsin(sin_elev))
    np.maximum(elev_deg, -2.0, out=elev_deg)

    # Two polynomials in elev_deg; use Horner to avoid the power table.
    deflect_exp = _horner(elev_deg, _DEFLECT_COEFFS)
    excess_exp = _horner(elev_deg, _EXCESS_DELAY_COEFFS)

    # 10^x = exp(x * ln10); one exp is ~2x faster than np.power(10, ...).
    poly_deflect = np.exp(deflect_exp * _LN10)  # meters
    excess_delay = np.exp(excess_exp * _LN10)  # ns

    # Multiplicative corrections (cheap scalar + (K,) broadcasts).
    a_corr = 1.0 + (a * 1e6 - 315.0) * 0.0024
    b_corr = 1.0 + (b - 7.35) * (elev_deg * 0.002842 + 0.017)
    alt_ratio = alt_m / 20250.0 - 1.0
    alt_corr = alt_ratio * alt_ratio
    r_corr = 1.0 + 1.329e-7 * (sphere_r - ER_M)

    multiplicative_correction = a_corr * b_corr * alt_corr * r_corr

    poly_deflect *= multiplicative_correction
    cone_correction = np.arctan(poly_deflect / range_mag)

    time_correction = excess_delay * multiplicative_correction

    if calc_freq_offset:
        # TODO: Implement frequency offset calculation (Bart will supply)
        pass

    # Clamp time correction and convert ns -> s.
    np.clip(time_correction, 0.0, 500.0, out=time_correction)
    time_correction *= 1e-9

    if scalar:
        return float(cone_correction[0]), float(time_correction[0])
    return cone_correction, time_correction
