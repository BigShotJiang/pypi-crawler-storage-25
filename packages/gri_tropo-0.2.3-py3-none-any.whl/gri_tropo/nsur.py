"""NSur class for accessing surface refractivity data."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
from gri_utils import config

if TYPE_CHECKING:
    from collections.abc import Sequence
    from datetime import datetime

    from numpy.typing import NDArray

# Default path if not configured
_DEFAULT_DATA_DIR = Path("/data/work/tropo/n_sur")


def _parse_date_from_filename(filename: str | Path) -> tuple[int, int, int] | None:
    """Parse date from filename with yyyy_mm_dd ending.

    Args:
        filename: Filename to parse (e.g., 'n_sur_2025_03_15.npz')

    Returns:
        tuple[int, int, int] | None: (year, month, day) or None if parsing fails
    """
    name = Path(filename).stem
    # date length for yyyy-mm-dd is 10
    if len(name) < 10:  # noqa: PLR2004
        return None
    name = name[-10:]
    try:
        yyyy = int(name[0:4])
        mm = int(name[5:7])
        dd = int(name[8:10])
    except ValueError:
        return None

    return yyyy, mm, dd


class NSur:
    """Class for accessing surface refractivity data from NPZ files.

    The NSur class provides efficient access to surface refractivity data
    stored in NPZ files, with caching and optimized batch operations.
    N_sur data includes hourly values (24 hours per day).

    Attributes:
        n_sur_dir: Path to directory containing n_sur NPZ files
    """

    def __init__(self, n_sur_dir: str | Path | None = None) -> None:
        """Initialize NSur with directory path.

        Args:
            n_sur_dir: Path to directory containing n_sur NPZ files.
                If None, uses config value from gri-tropo.n_sur.data_dir.

        Raises:
            ValueError: If directory doesn't exist or no directory provided
                and none configured.
        """
        if n_sur_dir is None:
            n_sur_dir = config.get_path("gri-tropo.n_sur.data_dir")
        if n_sur_dir is None:
            n_sur_dir = _DEFAULT_DATA_DIR
        self.n_sur_dir = Path(n_sur_dir)
        if not self.n_sur_dir.exists():
            msg = f"Directory does not exist: {self.n_sur_dir}"
            raise ValueError(msg)

        # Build file dictionary mapping (year, month, day) to file path
        self._filedict: dict[tuple[int, int, int], Path] = {}
        self.set_filedict()

    def set_filedict(self) -> None:
        """Update the internal file dictionary if the npz files have changed."""
        self._filedict = {}
        files = [
            f
            for f in self.n_sur_dir.iterdir()
            if f.is_file() and f.suffix.lower() == ".npz"
        ]
        for f in files:
            date = _parse_date_from_filename(f)
            if date is None:
                continue
            self._filedict[date] = f

    def _get_file(self, dt: datetime) -> Path | None:
        """Get file path for a given datetime.

        Args:
            dt: Datetime to get file for

        Returns:
            Path to NPZ file or None if no file exists for that date
        """
        date_tuple = (dt.year, dt.month, dt.day)
        return self._filedict.get(date_tuple)

    def get_n_sur_arr(self, dt: datetime) -> NDArray | None:
        """Get surface refractivity array for a given datetime.

        Args:
            dt: Datetime to get array for

        Returns:
            Surface refractivity array (181, 360, 24) or None if no file exists
        """
        filepath = self._get_file(dt)
        if filepath is None:
            return None

        data = np.load(filepath)
        return data["n_sur"]

    def get_n_sur(
        self,
        lat: float,
        lon: float,
        dt: datetime,
        hour: int,
    ) -> float | None:
        """Get surface refractivity for a specific lat/lon/datetime/hour.

        Args:
            lat: Latitude in degrees (-90 to 90)
            lon: Longitude in degrees (0 to 359)
            dt: Datetime to get value for
            hour: Hour of day (0 to 23)

        Returns:
            Surface refractivity value or None if no file exists or invalid coordinates
        """
        arr = self.get_n_sur_arr(dt)
        if arr is None:
            return None

        # Convert lat/lon to array indices
        lat_idx = int(lat)
        lon_idx = int(lon)

        # Bounds checking
        if not (-90 <= lat_idx <= 89) or not (0 <= lon_idx < 360):  # noqa: PLR2004
            return None
        if not (0 <= hour < 24):  # noqa: PLR2004
            return None

        value = arr[lat_idx, lon_idx, hour]
        # Return None for NaN values
        if np.isnan(value):
            return None
        return float(value)

    def get_all_n_surs(
        self,
        coords: Sequence[tuple[float, float, datetime, int]],
    ) -> list[float | None]:
        """Get surface refractivity for multiple coordinates efficiently.

        This method optimizes performance by:
        1. Sorting coordinates by datetime
        2. Loading each unique date's array only once
        3. Processing all coordinates for that date
        4. Returning results in original order

        Args:
            coords: Sequence of (lat, lon, datetime, hour) tuples

        Returns:
            List of surface refractivity values (or None) in same order as input
        """
        if not coords:
            return []

        # Create indexed list to maintain original order
        indexed_coords = [
            (i, lat, lon, dt, hour) for i, (lat, lon, dt, hour) in enumerate(coords)
        ]

        # Sort by datetime (keeping original indices)
        sorted_coords = sorted(indexed_coords, key=lambda x: x[3])

        # Result array (initialized with None)
        results: list[float | None] = [None] * len(coords)

        # Process coordinates grouped by date
        current_arr: NDArray | None = None
        current_date: tuple[int, int, int] | None = None

        for orig_idx, lat, lon, dt, hour in sorted_coords:
            date_tuple = (dt.year, dt.month, dt.day)

            # Load new array if date changed
            if date_tuple != current_date:
                current_date = date_tuple
                current_arr = self.get_n_sur_arr(dt)

            # Get value if array is available
            if current_arr is not None:
                # Convert lat/lon to array indices
                lat_idx = int(lat)
                lon_idx = int(lon)

                # Bounds checking
                if (
                    -90 <= lat_idx < 90  # noqa: PLR2004
                    and 0 <= lon_idx < 360  # noqa: PLR2004
                    and 0 <= hour < 24  # noqa: PLR2004
                ):
                    value = current_arr[lat_idx, lon_idx, hour]
                    if not np.isnan(value):
                        results[orig_idx] = float(value)

        return results
