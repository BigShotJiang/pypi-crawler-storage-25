"""RefHt class for accessing reference height data."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
from gri_utils import config

if TYPE_CHECKING:
    from collections.abc import Sequence
    from datetime import datetime

    from numpy.typing import NDArray

# Default path if not configured
_DEFAULT_DATA_DIR = Path("/data/work/tropo/ref_ht")


def _parse_date_from_filename(filename: str | Path) -> tuple[int, int, int] | None:
    """Parse date from filename with yyyy_mm_dd ending.

    Args:
        filename: Filename to parse (e.g., 'ref_ht_2025_03_15.npz')

    Returns:
        tuple[int, int, int] | None: (year, month, day) or None if parsing fails
    """
    name = Path(filename).stem
    # date length for yyyy-mm-dd is 10
    if len(name) < 10:  # noqa: PLR2004
        return None
    name = name[-10:]
    try:
        yyyy = int(name[0:4])
        mm = int(name[5:7])
        dd = int(name[8:10])
    except ValueError:
        return None

    return yyyy, mm, dd


class RefHt:
    """Class for accessing reference height data from NPZ files.

    The RefHt class provides efficient access to reference height data
    stored in NPZ files, with caching and optimized batch operations.

    Attributes:
        ref_ht_dir: Path to directory containing ref_ht NPZ files
    """

    def __init__(self, ref_ht_dir: str | Path | None = None) -> None:
        """Initialize RefHt with directory path.

        Args:
            ref_ht_dir: Path to directory containing ref_ht NPZ files.
                If None, uses config value from gri-tropo.ref_ht.data_dir.

        Raises:
            ValueError: If directory doesn't exist or no directory provided
                and none configured.
        """
        if ref_ht_dir is None:
            ref_ht_dir = config.get_path("gri-tropo.ref_ht.data_dir")
        if ref_ht_dir is None:
            ref_ht_dir = _DEFAULT_DATA_DIR
        self.ref_ht_dir = Path(ref_ht_dir)
        if not self.ref_ht_dir.exists():
            msg = f"Directory does not exist: {self.ref_ht_dir}"
            raise ValueError(msg)

        # Build file dictionary mapping (year, month, day) to file path
        self._filedict: dict[tuple[int, int, int], Path] = {}
        self.set_filedict()

    def set_filedict(self) -> None:
        """Update the internal file dictionary if the npz files have changed."""
        self._filedict = {}
        files = [
            f
            for f in self.ref_ht_dir.iterdir()
            if f.is_file() and f.suffix.lower() == ".npz"
        ]
        for f in files:
            date = _parse_date_from_filename(f)
            if date is None:
                continue
            self._filedict[date] = f

    def _get_file(self, dt: datetime) -> Path | None:
        """Get file path for a given datetime.

        Args:
            dt: Datetime to get file for

        Returns:
            Path to NPZ file or None if no file exists for that date
        """
        date_tuple = (dt.year, dt.month, dt.day)
        return self._filedict.get(date_tuple)

    def get_ref_ht_arr(self, dt: datetime) -> NDArray | None:
        """Get reference height array for a given datetime.

        Args:
            dt: Datetime to get array for

        Returns:
            Reference height array (181, 360) or None if no file exists
        """
        filepath = self._get_file(dt)
        if filepath is None:
            return None

        data = np.load(filepath)
        return data["ref_ht"]

    def get_ref_ht(self, lat: float, lon: float, dt: datetime) -> float | None:
        """Get reference height for a specific lat/lon/datetime.

        Args:
            lat: Latitude in degrees (-90 to 90)
            lon: Longitude in degrees (0 to 359)
            dt: Datetime to get value for

        Returns:
            Reference height value or None if no file exists or invalid coordinates
        """
        arr = self.get_ref_ht_arr(dt)
        if arr is None:
            return None

        # Convert lat/lon to array indices
        # Latitude indexing: 0-90 at indices 0-90, -90 to -1 at indices 91-180
        lat_idx = int(lat)

        # Longitude indexing: 0-359 maps directly to indices 0-359
        lon_idx = int(lon)

        # Bounds checking
        if not (-90 <= lat_idx <= 89) or not (0 <= lon_idx < 360):  # noqa: PLR2004
            return None

        value = arr[lat_idx, lon_idx]
        # Return None for NaN values
        if np.isnan(value):
            return None
        return float(value)

    def get_all_ref_hts(
        self,
        coords: Sequence[tuple[float, float, datetime]],
    ) -> list[float | None]:
        """Get reference heights for multiple coordinates efficiently.

        This method optimizes performance by:
        1. Sorting coordinates by datetime
        2. Loading each unique date's array only once
        3. Processing all coordinates for that date
        4. Returning results in original order

        Args:
            coords: Sequence of (lat, lon, datetime) tuples

        Returns:
            List of reference height values (or None) in same order as input
        """
        if not coords:
            return []

        # Create indexed list to maintain original order
        indexed_coords = [(i, lat, lon, dt) for i, (lat, lon, dt) in enumerate(coords)]

        # Sort by datetime (keeping original indices)
        sorted_coords = sorted(indexed_coords, key=lambda x: x[3])

        # Result array (initialized with None)
        results: list[float | None] = [None] * len(coords)

        # Process coordinates grouped by date
        current_arr: NDArray | None = None
        current_date: tuple[int, int, int] | None = None

        for orig_idx, lat, lon, dt in sorted_coords:
            date_tuple = (dt.year, dt.month, dt.day)

            # Load new array if date changed
            if date_tuple != current_date:
                current_date = date_tuple
                current_arr = self.get_ref_ht_arr(dt)

            # Get value if array is available
            if current_arr is not None:
                # Convert lat/lon to array indices
                lat_idx = int(lat)
                lon_idx = int(lon)

                # Bounds checking
                if -90 <= lat_idx < 90 and 0 <= lon_idx < 360:  # noqa: PLR2004
                    value = current_arr[lat_idx, lon_idx]
                    if not np.isnan(value):
                        results[orig_idx] = float(value)

        return results
