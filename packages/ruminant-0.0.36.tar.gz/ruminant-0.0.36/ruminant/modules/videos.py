import uuid
import struct
import datetime
from .. import module, utils
from ..buf import Buf
from . import chew


def mp4_decode_language(lang_bytes):
    lang_code = int.from_bytes(lang_bytes, byteorder="big") & 0x7fff

    c1 = ((lang_code >> 10) & 0x1f) + 0x60
    c2 = ((lang_code >> 5) & 0x1f) + 0x60
    c3 = (lang_code & 0x1f) + 0x60

    return chr(c1) + chr(c2) + chr(c3)


@module.register
class IsoModule(module.RuminantModule):
    desc = "ISO Base Media files.\nThis includes may file formats like MP4, HEIC/HEIF, AVIF or JPEG2000."

    def identify(buf, ctx):
        return buf.peek(8)[4:] in (b"ftyp", b"styp", b"jP  ", b"jumb")

    def chew(self):
        file = {}

        self.mode = None

        file["type"] = "iso"
        file["atoms"] = []
        while self.buf.available() >= 8:
            file["atoms"].append(self.read_atom())

        with self.buf:
            self.parse_mdat(file["atoms"])

        return file

    def read_version(self, atom):
        version = self.buf.ru8()
        atom["data"]["version"] = version
        atom["data"]["flags"] = self.buf.ru24()
        return version

    def read_more(self, atom):
        atom["data"]["atoms"] = []

        bak = self.buf.backup()

        while self.buf.unit >= 8:
            atom["data"]["atoms"].append(self.read_atom())

        self.buf.restore(bak)
        self.buf.skipunit()

    def read_atom(self, root_context=None):
        offset = self.buf.tell()

        length = self.buf.ru32()
        if length == 0:
            pos = self.buf.tell()
            self.buf.seek(0, 2)
            length = self.buf.tell()
            self.buf.seek(pos)
        typ = self.buf.rs(4, "latin-1")

        if length == 1:
            length = self.buf.ru64() - 8

        atom = {"type": typ, "offset": offset, "length": length, "data": {}}

        length -= 8
        self.buf.pushunit()
        self.buf.setunit(length)

        if typ == "":
            pass
        elif typ in (
            "moov",
            "trak",
            "mdia",
            "minf",
            "dinf",
            "stbl",
            "udta",
            "mvex",
            "moof",
            "traf",
            "gsst",
            "gstd",
            "sinf",
            "schi",
            "cprt",
            "trkn",
            "aART",
            "iprp",
            "ipco",
            "tapt",
            "tref",
            "gmhd",
            "jp2h",
            "asoc",
            "jumb",
            "wave",
        ) or (typ[0] == "©" and self.buf.peek(8)[4:8] == b"data"):
            self.read_more(atom)
        elif typ in ("ftyp", "styp"):
            atom["data"]["major-brand"] = self.buf.rs(4, "utf-8")
            atom["data"]["minor-version"] = self.buf.ru32()
            atom["data"]["compatible-brands"] = []

            while self.buf.unit > 0:
                atom["data"]["compatible-brands"].append(self.buf.rs(4, "utf-8"))

            if atom["data"]["major-brand"] == "jp2 ":
                self.mode = "jp2"
        elif typ == "uuid":
            atom["data"]["uuid"] = str(uuid.UUID(bytes=self.buf.read(16)))
            atom["data"]["user-data"] = self.buf.rs(self.buf.unit)
            try:
                atom["data"]["user-data"] = utils.xml_to_dict(atom["data"]["user-data"])
            except Exception:
                pass
        elif typ == "mvhd":
            version = self.read_version(atom)

            if version == 0:
                creation_time = self.buf.ru32()
                modification_time = self.buf.ru32()
                timescale = self.buf.ru32()
                duration = self.buf.ru32()
            elif version == 1:
                creation_time = self.buf.ru64()
                modification_time = self.buf.ru64()
                timescale = self.buf.ru32()
                duration = self.buf.ru64()

            if version in (0, 1):
                atom["data"]["creation-time"] = utils.mp4_time_to_iso(creation_time)
                atom["data"]["modification-time"] = utils.mp4_time_to_iso(
                    modification_time
                )
                atom["data"]["timescale"] = timescale
                atom["data"]["duration"] = duration

                atom["data"]["rate"] = self.buf.rfp32()
                atom["data"]["volume"] = self.buf.rfp16()
                atom["data"]["reserved"] = self.buf.rh(10)
                atom["data"]["matrix"] = self.buf.rh(36)
                atom["data"]["pre-defined"] = self.buf.rh(24)
                atom["data"]["next-track-id"] = self.buf.ru32()
        elif typ == "tkhd":
            version = self.buf.ru8()
            atom["data"]["version"] = version
            flags = self.buf.ru24()
            atom["data"]["flags"] = {
                "raw": flags,
                "enabled": bool(flags & 1),
                "movie": bool(flags & 2),
                "preview": bool(flags & 4),
            }

            if version == 0:
                creation_time = self.buf.ru32()
                modification_time = self.buf.ru32()
                track_ID = self.buf.ru32()
                reserved1 = self.buf.rh(4)
                duration = self.buf.ru32()

            if version == 1:
                creation_time = self.buf.ru64()
                modification_time = self.buf.ru64()
                track_ID = self.buf.ru32()
                reserved1 = self.buf.rh(4)
                duration = self.buf.ru64()

            if version in (0, 1):
                atom["data"]["creation-time"] = utils.mp4_time_to_iso(creation_time)
                atom["data"]["modification-time"] = utils.mp4_time_to_iso(
                    modification_time
                )
                atom["data"]["track-id"] = track_ID
                atom["data"]["reserved1"] = reserved1
                atom["data"]["duration"] = duration

                atom["data"]["reserved2"] = self.buf.rh(8)
                atom["data"]["layer"] = self.buf.ru16()
                atom["data"]["alternate-group"] = self.buf.ru16()
                atom["data"]["volume"] = self.buf.rfp16()
                atom["data"]["reserved3"] = self.buf.rh(2)
                atom["data"]["matrix"] = self.buf.rh(36)
                atom["data"]["width"] = self.buf.rfp32()
                atom["data"]["height"] = self.buf.rfp32()
        elif typ == "edts":
            atom["data"] = self.read_atom()
        elif typ == "elst":
            version = self.read_version(atom)
            atom["data"]["entries"] = []
            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count

            for i in range(0, entry_count):
                if version == 0:
                    segment_duration = self.buf.ru32()
                    media_time = self.buf.ru32()
                elif version == 1:
                    segment_duration = self.buf.ru64()
                    media_time = self.buf.ru64()

                if version in (0, 1):
                    entry = {}
                    entry["segment-duration"] = segment_duration
                    entry["media-time"] = media_time
                    entry["media_rate_integer"] = self.buf.ru16()
                    entry["media_rate_fraction"] = self.buf.ru16()

                    atom["data"]["entries"].append(entry)
        elif typ == "mdhd":
            version = self.read_version(atom)

            if version == 0:
                creation_time = self.buf.ru32()
                modification_time = self.buf.ru32()
                timescale = self.buf.ru32()
                duration = self.buf.ru32()
            elif version == 1:
                creation_time = self.buf.ru64()
                modification_time = self.buf.ru64()
                timescale = self.buf.ru32()
                duration = self.buf.ru64()

            if version in (0, 1):
                atom["data"]["creation-time"] = utils.mp4_time_to_iso(creation_time)
                atom["data"]["modification-time"] = utils.mp4_time_to_iso(
                    modification_time
                )
                atom["data"]["timescale"] = timescale
                atom["data"]["duration"] = duration

                atom["data"]["language"] = mp4_decode_language(self.buf.read(2))
                atom["data"]["pre-defined"] = self.buf.rh(2)
        elif typ == "hdlr":
            self.read_version(atom)
            atom["data"]["pre-defined"] = self.buf.rh(4)
            atom["data"]["handler-type"] = self.buf.rs(4)
            atom["data"]["reserved"] = self.buf.rh(12)
            atom["data"]["name"] = self.buf.readunit().decode("utf-8").rstrip("\x00")
        elif typ == "vmhd":
            self.read_version(atom)
            atom["data"]["graphicsmode"] = self.buf.ru16()
            atom["data"]["opcolor"] = [self.buf.ru16() for _ in range(0, 3)]
        elif typ in ("dref", "stsd"):
            self.read_version(atom)
            entry_count = self.buf.ru32()

            atom["data"]["atoms"] = []
            for i in range(0, entry_count):
                atom["data"]["atoms"].append(self.read_atom())
        elif typ == "url ":
            version = self.buf.ru8()
            atom["data"]["version"] = version
            flags = self.buf.ru24()
            atom["data"]["flags"] = {"raw": flags, "local": bool(flags & 1)}

            atom["data"]["location"] = self.buf.readunit()[:-1].decode("utf-8")
        elif typ == "avcC":
            atom["data"]["configuration-version"] = self.buf.ru8()
            atom["data"]["avc-profile-indication"] = self.buf.ru8()
            atom["data"]["profile-compatibility"] = self.buf.ru8()
            atom["data"]["avc-level-indication"] = self.buf.ru8()
            atom["data"]["reserved1"] = self.buf.rb(6)
            atom["data"]["length-size-minus-one"] = self.buf.rb(2)

            atom["data"]["reserved2"] = self.buf.rb(3)
            atom["data"]["sequence-parameter-set-count"] = self.buf.rb(5)
            atom["data"]["sequence-parameter-sets"] = []
            for i in range(0, atom["data"]["sequence-parameter-set-count"]):
                self.buf.pasunit(self.buf.ru16())
                atom["data"]["sequence-parameter-sets"].append(self.read_h264_nalu())
                self.buf.sapunit()

            atom["data"]["picture-parameter-set-count"] = self.buf.ru8()
            atom["data"]["picture-parameter-sets"] = []
            for i in range(0, atom["data"]["picture-parameter-set-count"]):
                self.buf.pasunit(self.buf.ru16())
                atom["data"]["picture-parameter-sets"].append(self.read_h264_nalu())
                self.buf.sapunit()

            if atom["data"]["avc-profile-indication"] not in (66, 77, 88):
                atom["data"]["reserved3"] = self.buf.rb(6)
                atom["data"]["chroma-format"] = self.buf.rb(2)
                atom["data"]["reserved4"] = self.buf.rb(5)
                atom["data"]["bit-depth-luma-minus-eight"] = self.buf.rb(3)
                atom["data"]["reserved5"] = self.buf.rb(5)
                atom["data"]["bit-depth-chroma-minus-eight"] = self.buf.rb(3)

                atom["data"]["picture-parameter-set-ext-count"] = self.buf.ru8()
                atom["data"]["picture-parameter-set-exts"] = []
                for i in range(0, atom["data"]["picture-parameter-set-ext-count"]):
                    self.buf.pasunit(self.buf.ru16())
                    atom["data"]["picture-parameter-set-exts"].append(
                        self.read_h264_nalu()
                    )
                    self.buf.sapunit()
        elif typ == "colr":
            if self.mode == "jp2":
                atom["data"]["method"] = self.buf.ru8()
                atom["data"]["precedence"] = self.buf.ru8()
                atom["data"]["approx"] = self.buf.ru8()
                atom["data"]["colour"] = self.buf.rh(self.buf.unit)
            else:
                atom["data"]["color-type"] = self.buf.rs(4)

                match atom["data"]["color-type"]:
                    case "nclc":
                        atom["data"]["color-primaries"] = self.buf.ru16()
                        atom["data"]["transfer-characteristics"] = self.buf.ru16()
                        atom["data"]["matrix-coefficients"] = self.buf.ru16()
                    case "rICC" | "prof":
                        atom["data"]["icc_profile_data"] = chew(
                            b"ICC_PROFILE\x00\x00\x00" + self.buf.readunit()
                        )
                    case "nclx":
                        atom["data"]["color-primaries"] = self.buf.ru16()
                        atom["data"]["transfer-characteristics"] = self.buf.ru16()
                        atom["data"]["matrix-coefficients"] = self.buf.ru16()
                        full_range_flag = self.buf.ru8()
                        atom["data"]["full_range_flag"] = {
                            "raw": full_range_flag,
                            "full": bool(full_range_flag & 0x80),
                        }
        elif typ == "pasp":
            atom["data"]["hSpacing"] = self.buf.ru32()
            atom["data"]["vSpacing"] = self.buf.ru32()
        elif typ == "btrt":
            atom["data"]["buffer-size"] = self.buf.ru32()
            atom["data"]["max-bitrate"] = self.buf.ru32()
            atom["data"]["avg-bitrate"] = self.buf.ru32()
        elif typ == "stts":
            self.read_version(atom)
            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count
        elif typ == "stss":
            self.read_version(atom)
            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count
        elif typ == "ctts":
            self.read_version(atom)
            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count
        elif typ == "stsc":
            self.read_version(atom)
            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count
        elif typ == "stsz":
            self.read_version(atom)
            atom["data"]["sample-size"] = self.buf.ru32()
            atom["data"]["sample-count"] = self.buf.ru32()
        elif typ == "stco":
            self.read_version(atom)
            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count
        elif typ == "sgpd":
            version = self.buf.ru8()
            atom["data"]["version"] = version
            flags = self.buf.ru24()
            atom["data"]["flags"] = {
                "raw": flags,
                "variable-length": bool(flags & 1),
            }

            atom["data"]["grouping-type"] = self.buf.rs(4)

            default_length = 0
            if version == 1 and flags & 1 == 0:
                default_length = self.buf.ru32()

            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count

            atom["data"]["entries"] = []
            for i in range(0, entry_count):
                length = default_length
                if length == 0:
                    length = self.buf.ru32()

                atom["data"]["entries"].append(self.buf.rh(length))
        elif typ == "sbgp":
            self.read_version(atom)
            atom["data"]["grouping-type"] = self.buf.rs(4)

            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count

            atom["data"]["entries"] = []
            for i in range(0, entry_count):
                atom["data"]["entries"].append({
                    "sample-count": self.buf.ru32(),
                    "group_description_index": self.buf.ru32(),
                })
        elif typ == "smhd":
            self.read_version(atom)
            atom["data"]["balance"] = self.buf.rfp16()
            atom["data"]["reserved"] = self.buf.ru16()
        elif typ == "esds":
            self.read_version(atom)
            atom["data"]["descriptor"] = self.read_esds()
        elif typ == "data":
            atom["data"]["type"] = self.buf.ru32()
            self.buf.skip(4)

            match atom["data"]["type"]:
                case 0x00000001:
                    atom["data"]["payload"] = self.buf.rs(self.buf.unit)
                case 0x00000002:
                    atom["data"]["payload"] = self.buf.rs(self.buf.unit, "utf-16")
                case _:
                    with self.buf.subunit():
                        atom["data"]["payload"] = chew(self.buf)
        elif typ in ("free", "skip"):
            atom["data"]["non-zero"] = sum(self.buf.peek(self.buf.unit)) > 0
            if atom["data"]["non-zero"]:
                if self.buf.peek(3) == b"Iso":
                    atom["data"]["gpac-string"] = (
                        self.buf.readunit().decode("utf-8").rstrip("\x00")
                    )
                else:
                    with self.buf.subunit():
                        atom["data"]["content"] = chew(self.buf)
        elif typ == "co64":
            self.read_version(atom)
            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count
        elif typ == "sdtp":
            self.read_version(atom)
            atom["data"]["sample_dep_type_count"] = len(self.buf.readunit())
        elif typ == "vpcC":
            atom["data"]["profile"] = self.buf.ru8()
            atom["data"]["level"] = self.buf.ru8()
            atom["data"]["bit-depth"] = self.buf.ru8()
            atom["data"]["chroma-subsampling"] = self.buf.ru8()
            atom["data"]["video_full_range_flag"] = self.buf.ru8()
            atom["data"]["reserved"] = self.buf.rh(3)
        elif typ == "trex":
            self.read_version(atom)
            atom["data"]["track-id"] = self.buf.ru32()
            atom["data"]["default_sample_description_index"] = self.buf.ru32()
            atom["data"]["default_sample_duration"] = self.buf.ru32()
            atom["data"]["default_sample_size"] = self.buf.ru32()
            atom["data"]["default_sample_flags"] = self.buf.ru32()
        elif typ == "sidx":
            version = self.read_version(atom)
            atom["data"]["reference-id"] = self.buf.ru32()
            atom["data"]["earliest_presentation_time"] = int.from_bytes(
                self.buf.read(4 if version == 0 else 8), "big"
            )
            atom["data"]["first-offset"] = int.from_bytes(
                self.buf.read(4 if version == 0 else 8), "big"
            )
            atom["data"]["reserved"] = self.buf.rh(2)
            atom["data"]["reference-count"] = self.buf.ru16()
        elif typ == "mfhd":
            self.read_version(atom)
            atom["data"]["sequence-number"] = self.buf.ru32()
        elif typ == "tfhd":
            version = self.buf.ru8()
            atom["data"]["version"] = version
            flags = self.buf.ru24()
            atom["data"]["flags"] = {
                "raw": flags,
                "base_data_offset_present": bool(flags & 1),
                "sample_description_index_present": bool(flags & 2),
                "default_sample_duration_present": bool(flags & 8),
                "default_sample_size_present": bool(flags & 16),
                "default_sample_flags_present": bool(flags & 32),
                "no-samples": bool(flags & 65536),
                "base_is_moof": bool(flags & 131072),
            }
            atom["data"]["track-id"] = self.buf.ru32()

            if atom["data"]["flags"]["base_data_offset_present"]:
                atom["data"]["base_data_offset"] = self.buf.ru64()
            if atom["data"]["flags"]["sample_description_index_present"]:
                atom["data"]["sample_description_index"] = self.buf.ru32()
            if atom["data"]["flags"]["default_sample_duration_present"]:
                atom["data"]["default_sample_duration"] = self.buf.ru32()
            if atom["data"]["flags"]["default_sample_size_present"]:
                atom["data"]["default_sample_size"] = self.buf.ru32()
            if atom["data"]["flags"]["default_sample_flags_present"]:
                atom["data"]["default_sample_flags"] = self.buf.ru32()
        elif typ == "tfdt":
            version = self.read_version(atom)
            atom["data"]["baseMediaDecodeTime"] = int.from_bytes(
                self.buf.read(4 if version == 0 else 8), "big"
            )
        elif typ == "trun":
            version = self.buf.ru8()
            atom["data"]["version"] = version
            flags = self.buf.ru24()
            atom["data"]["flags"] = {
                "raw": flags,
                "data_offset_present": bool(flags & 1),
                "first_sample_flags_present": bool(flags & 4),
                "sample_duration_present": bool(flags & 256),
                "sample_size_present": bool(flags & 512),
                "sample_flags_present": bool(flags & 1024),
                "sample_composition_time_offsets_present": bool(flags & 2048),
            }
            atom["data"]["sample-count"] = self.buf.ru32()
        elif typ == "desc":
            atom["data"]["descriptor"] = self.buf.readunit().hex()
        elif typ == "loci":
            self.read_version(atom)
            atom["data"]["language-code"] = self.buf.ru16()
            atom["data"]["reserved"] = self.buf.rh(2)
            atom["data"]["longitude"] = self.buf.rfp32()
            atom["data"]["latitude"] = self.buf.rfp32()
            atom["data"]["altitude"] = self.buf.rfp32()
            atom["data"]["planet"] = (
                self.buf.readunit().split(b"\x00")[0].decode("utf-8")
            )
        elif typ == "hvcC":
            version = self.buf.ru8()
            atom["data"]["version"] = version

            temp = self.buf.ru8()
            atom["data"]["general_profile_space"] = (temp >> 6) & 0x03
            atom["data"]["general_tier_flag"] = (temp >> 5) & 0x01
            atom["data"]["general_profile_idc"] = temp & 0x1f

            atom["data"]["profile_compatibility_flags"] = self.buf.ru32()
            atom["data"]["constraint_indicator_flags"] = int.from_bytes(
                self.buf.read(6), "big"
            )
            atom["data"]["level-idc"] = self.buf.ru8()
            atom["data"]["min_spatial_segmentation_idc"] = self.buf.ru16()
            atom["data"]["parallelismType"] = self.buf.ru8()
            atom["data"]["chromaFormat"] = self.buf.ru8()
            atom["data"]["bitDepthLumaMinus8"] = self.buf.ru8()
            atom["data"]["bitDepthChromaMinus8"] = self.buf.ru8()
            atom["data"]["avgFrameRate"] = self.buf.rfp16()

            temp = self.buf.ru8()
            atom["data"]["constantFrameRate"] = (temp >> 6) & 0x03
            atom["data"]["numTemporalLayers"] = (temp >> 3) & 0x07
            atom["data"]["temporalIdNested"] = (temp >> 2) & 0x01
            atom["data"]["lengthSizeMinusOne"] = temp & 0x03

            atom["data"]["numOfArrays"] = self.buf.ru8()

            atom["data"]["arrays"] = []
            for i in range(0, atom["data"]["numOfArrays"]):
                array = {}
                array["array-completeness"] = self.buf.rb(1)
                array["reserved"] = self.buf.rb(1)
                array["nal-unit-type"] = utils.unraw(
                    self.buf.rb(6),
                    1,
                    {
                        0x20: "VPS",
                        0x21: "SPS",
                        0x22: "PPS",
                        0x27: "Prefix SEI",
                        0x28: "Suffix SEI",
                    },
                    True,
                )
                array["numNalus"] = self.buf.ru16()
                array["nalus"] = []
                for j in range(0, array["numNalus"]):
                    entry = {}
                    entry["nalUnitLength"] = self.buf.ru16()

                    self.buf.pasunit(entry["nalUnitLength"])

                    entry["nalUnit"] = {}
                    entry["nalUnit"]["forbidden-zero-bit"] = self.buf.rb(1)
                    entry["nalUnit"]["nal-unit-type"] = utils.unraw(
                        self.buf.rb(6),
                        1,
                        {
                            0x20: "VPS",
                            0x21: "SPS",
                            0x22: "PPS",
                            0x27: "Prefix SEI",
                            0x28: "Suffix SEI",
                        },
                        True,
                    )
                    entry["nalUnit"]["nuh-layer-id"] = self.buf.rb(6)
                    entry["nalUnit"]["nuh-temporal-id-plus-1"] = self.buf.rb(3)

                    match entry["nalUnit"]["nal-unit-type"]:
                        case "Prefix SEI":
                            vals = []
                            for i in range(0, 2):
                                val = 0
                                while True:
                                    c = self.buf.ru8()
                                    val += c

                                    if c != 0xff:
                                        break

                                vals.append(val)

                            entry["nalUnit"]["payload-type"] = utils.unraw(
                                vals[0],
                                4,
                                {
                                    0x00: "buffering_period",
                                    0x01: "pic_timing",
                                    0x05: "user_data_unregistered",
                                    0x89: "mastering_display_colour_volume",
                                    0x90: "content_light_level_info",
                                },
                                True,
                            )
                            entry["nalUnit"]["payload-size"] = vals[1]

                            self.buf.pasunit(entry["nalUnit"]["payload-size"])

                            match entry["nalUnit"]["payload-type"]:
                                case "user_data_unregistered":
                                    if (
                                        self.buf.ph(16)
                                        == "2ca2de09b51747dbbb55a4fe7fc2fc4e"
                                    ):
                                        entry["nalUnit"]["libx265-uuid"] = (
                                            self.buf.ruuid()
                                        )
                                        entry["nalUnit"]["libx265-string"] = (
                                            self.buf.rs(self.buf.unit)
                                        )
                                    else:
                                        entry["nalUnit"]["payload"] = self.buf.rh(
                                            self.buf.unit
                                        )
                                case _:
                                    entry["nalUnit"]["payload"] = self.buf.rh(
                                        self.buf.unit
                                    )
                                    entry["unknown"] = True

                            self.buf.sapunit()
                        case _:
                            entry["nalUnit"]["payload"] = self.buf.rh(self.buf.unit)
                            entry["unknown"] = True

                    self.buf.sapunit()

                    array["nalus"].append(entry)

                atom["data"]["arrays"].append(array)
        elif typ == "keys":
            self.read_version(atom)
            entry_count = self.buf.ru32()
            atom["data"]["entry-count"] = entry_count

            atom["data"]["entries"] = []
            for i in range(0, entry_count):
                length = self.buf.ru32()
                ns = self.buf.rs(4)
                value = self.buf.rs(length - 8)
                atom["data"]["entries"].append({"namespace": ns, "value": value})
        elif typ == "name":
            if self.buf.unit >= 4:
                self.read_version(atom)
            atom["data"]["name"] = self.buf.readunit().decode("utf-8")
        elif typ == "titl":
            self.read_version(atom)
            atom["data"]["reserved1"] = self.buf.rh(2)
            atom["data"]["title"] = self.buf.readunit()[:-1].decode("latin-1")
        elif typ == "cslg":
            atom["data"]["compositionToDTSShift"] = self.buf.ru32()
            atom["data"]["leastDecodeToDisplayDelta"] = self.buf.ru32()
            atom["data"]["greatestDecodeToDisplayDelta"] = self.buf.ru32()
            atom["data"]["compositionStartTime"] = self.buf.ru32()
            atom["data"]["compositionEndTime"] = self.buf.ru32()
        elif typ == "senc":
            version = self.buf.ru8()
            atom["data"]["version"] = version
            flags = self.buf.ru24()
            atom["data"]["flags"] = {
                "raw": flags,
                "use-subsample-encryption": bool(flags & 2),
            }
            atom["data"]["sample-count"] = self.buf.ru32()
        elif typ == "frma":
            atom["data"]["original-media-type"] = self.buf.rs(4)
        elif typ == "schm":
            version = self.buf.ru8()
            atom["data"]["version"] = version
            flags = self.buf.ru24()
            atom["data"]["flags"] = {"raw": flags, "has-uri": bool(flags & 1)}
            atom["data"]["type"] = self.buf.rs(4)
            atom["data"]["version"] = f"{self.buf.ru16()}.{self.buf.ru16()}"
            if flags & 1:
                atom["data"]["uri"] = self.buf.readunit().decode("utf-8")
        elif typ == "tenc":
            version = self.read_version(atom)

            atom["data"]["reserved"] = self.buf.rh(1 if version != 0 else 2)

            if version >= 1:
                atom["data"]["encrypted-blocks-per-pattern"] = self.buf.ru32()
                atom["data"]["clear-blocks-per-pattern"] = self.buf.ru32()

            atom["data"]["is-encrypted"] = self.buf.ru8()
            atom["data"]["iv-size"] = self.buf.ru8()
            atom["data"]["key-id"] = self.buf.rh(16)

            if atom["data"]["is-encrypted"] == 1 and atom["data"]["iv-size"] == 0:
                constant_iv_size = self.buf.ru8()
                atom["data"]["constant-iv-size"] = constant_iv_size
                atom["data"]["constant-iv"] = self.buf.rh(constant_iv_size)
        elif typ == "mehd":
            version = self.read_version(atom)
            atom["data"]["fragment-duration"] = (
                self.buf.ru32() if version == 0 else self.buf.ru64()
            )
        elif typ == "pssh":
            version = self.read_version(atom)

            system_id = self.buf.ruuid()
            atom["data"]["system-id"] = system_id
            atom["data"]["system-name"] = {
                "29701fe4-3cc7-4a34-8c5b-ae90c7439a47": "Netflix FairPlay",
                "9a04f079-9840-4286-ab92-e65be0885f95": "PlayReady",
                "edef8ba9-79d6-4ace-a3c8-27dcd51d21ed": "Widevine",
                "6dd8b3c3-45f4-4a68-bf3a-64168d01a4a6": "ABV DRM (MoDRM)",
                "f239e769-efa3-4850-9c16-a903c6932efb": "Adobe Primetime DRM version 4",
                "616c7469-6361-7374-2d50-726f74656374": "Alticast",
                "94ce86fb-07ff-4f43-adb8-93d2fa968ca2": "FairPlay",
                "279fe473-512c-48fe-ade8-d176fee6b40f": "Arris Titanium",
                "3d5e6d35-9b9a-41e8-b843-dd3c6e72c42c": "ChinaDRM",
                "3ea8778f-7742-4bf9-b18b-e834b2acbd47": "Clear Key AES-128",
                "be58615b-19c4-4684-88b3-c8c57e99e957": "Clear Key SAMPLE-AES",
                "e2719d58-a985-b3c9-781a-b030af78d30e": "Clear Key DASH-IF",
                "644fe7b5-260f-4fad-949a-0762ffb054b4": "CMLA (OMA DRM)",
                "37c33258-7b99-4c7e-b15d-19af74482154": "Commscope Titanium V3",
                "45d481cb-8fe0-49c0-ada9-ab2d2455b2f2": "CoreCrypt",
                "dcf4e3e3-62f1-5818-7ba6-0a6fe33ff3dd": "DigiCAP SmartXess",
                "35bf197b-530e-42d7-8b65-1b4bf415070f": "DivX DRM Series 5",
                "80a6be7e-1448-4c37-9e70-d5aebe04c8d2": "Irdeto Content Protection",
                "5e629af5-38da-4063-8977-97ffbd9902d4": "Marlin Adaptive Streaming Simple Profile V1.0",
                "6a99532d-869f-5922-9a91-113ab7b1e2f3": "MobiTV DRM",
                "adb41c24-2dbf-4a6d-958b-4457c0d27b95": "Nagra MediaAccess PRM 3.0",
                "1f83e1e8-6ee9-4f0d-ba2f-5ec4e3ed1a66": "SecureMedia",
                "992c46e6-c437-4899-b6a0-50fa91ad0e39": "SecureMedia SteelKnot",
                "a68129d3-575b-4f1a-9cba-3223846cf7c3": "Synamedia/Cisco/NDS VideoGuard DRM",
                "aa11967f-cc01-4a4a-8e99-c5d3dddfea2d": "Unitend DRM (UDRM)",
                "9a27dd82-fde2-4725-8cbc-4234aa06ec09": "Verimatrix VCAS",
                "b4413586-c58c-ffb0-94a5-d4896c1af6c3": "Viaccess-Orca DRM (VODRM)",
                "793b7956-9f94-4946-a942-23e7ef7e44b4": "VisionCrypt",
                "1077efec-c0b2-4d02-ace3-3c1e52e2fb4b": "W3C Common PSSH box",
            }.get(system_id, "Unknown")

            if version == 1:
                key_id_count = self.buf.ru32()
                atom["data"]["key-id-count"] = key_id_count

                atom["data"]["key-ids"] = []
                for i in range(0, key_id_count):
                    atom["data"]["key-ids"].append(self.buf.ruuid())

            blob_length = self.buf.ru32()
            atom["data"]["blob-length"] = blob_length

            self.buf.pushunit()
            self.buf.setunit(blob_length)

            match system_id:
                case "9a04f079-9840-4286-ab92-e65be0885f95":
                    self.buf.skip(4)
                    record_count = self.buf.ru16l()
                    atom["data"]["record-count"] = record_count

                    atom["data"]["records"] = []
                    for i in range(0, record_count):
                        record = {}
                        record_type = self.buf.ru16l()
                        record["type"] = record_type
                        record_length = self.buf.ru16l()
                        record["length"] = record_length

                        content = self.buf.read(record_length)
                        match record_type:
                            case 1:
                                record["data"] = utils.xml_to_dict(
                                    content.decode("utf16")
                                )
                            case _:
                                record["data"] = content.hex()

                        atom["data"]["records"].append(record)
                case "edef8ba9-79d6-4ace-a3c8-27dcd51d21ed":
                    atom["data"]["blob"] = {}

                    for i, v in utils.read_protobuf(self.buf, blob_length).items():
                        match i:
                            case 1:
                                atom["data"]["blob"]["algorithm"] = {
                                    "raw": v,
                                    "name": {0: "Unencrypted", 1: "AES-CTR"}.get(
                                        v, "Unknown"
                                    ),
                                }
                            case 2:
                                if "key-ids" not in atom["data"]["blob"]:
                                    atom["data"]["blob"]["key-ids"] = []

                                if isinstance(v, list):
                                    v = [utils.to_uuid(x) for x in v]
                                else:
                                    v = [utils.to_uuid(v)]

                                atom["data"]["blob"]["key-ids"].extend(v)
                            case 3:
                                atom["data"]["blob"]["provider"] = v.decode("utf-8")
                            case 4:
                                atom["data"]["blob"]["content-id"] = utils.to_uuid(v)
                            case 6:
                                atom["data"]["blob"]["policy"] = v.decode("utf-8")
                            case 7:
                                atom["data"]["blob"]["crypto-period-index"] = v
                            case 8:
                                atom["data"]["blob"]["grouped-license"] = v.hex()
                            case 9:
                                atom["data"]["blob"]["protection-scheme"] = {
                                    "raw": v,
                                    "name": {
                                        0: "Unspecified (CENC)",
                                        1667591779: "CENC",
                                        1667392305: "CBC1",
                                        1667591795: "CENS",
                                        1667392371: "CBCS",
                                    }.get(v, "Unknown"),
                                }
                case _:
                    atom["data"]["blob"] = self.buf.rh(blob_length)

            self.buf.skipunit()
            self.buf.popunit()
        elif typ == "pitm":
            version = self.read_version(atom)
            atom["data"]["item-id"] = (
                self.buf.ru32() if version > 0 else self.buf.ru16()
            )
        elif typ == "iloc":
            version = self.read_version(atom)

            temp = self.buf.ru8()
            offset_size = temp >> 4
            atom["data"]["offset-size"] = offset_size
            length_size = temp & 0x0f
            atom["data"]["length-size"] = length_size
            temp = self.buf.ru8()
            base_offset_size = temp >> 4
            atom["data"]["base-offset-size"] = base_offset_size
            index_size = temp & 0x0f
            atom["data"]["index-size"] = index_size

            item_count = self.buf.ru32() if version >= 2 else self.buf.ru16()
            atom["data"]["item-count"] = item_count

            atom["data"]["items"] = []
            for i in range(0, item_count):
                item = {}
                item["id"] = self.buf.ru32() if version >= 2 else self.buf.ru16()

                if version > 0:
                    temp = self.buf.ru16()
                    item["construction-method"] = temp & 0x0f
                    item["reserved"] = temp >> 4

                item["data-reference-index"] = self.buf.ru16()
                base_offset = int.from_bytes(self.buf.read(base_offset_size), "big")
                item["base-offset"] = base_offset

                extent_count = self.buf.ru16()
                item["extent-count"] = extent_count

                item["extents"] = []
                for j in range(0, extent_count):
                    extent = {}

                    if version > 0 and index_size > 0:
                        extent["index"] = int.from_bytes(
                            self.buf.read(index_size), "big"
                        )

                    extent["offset"] = int.from_bytes(self.buf.read(offset_size), "big")
                    extent["length"] = int.from_bytes(self.buf.read(length_size), "big")

                    item["extents"].append(extent)

                atom["data"]["items"].append(item)
        elif typ == "iinf":
            version = self.read_version(atom)
            entry_count = self.buf.ru16() if version < 1 else self.buf.ru32()
            atom["data"]["item-count"] = entry_count

            atom["data"]["items"] = []
            for i in range(0, entry_count):
                atom["data"]["items"].append(self.read_atom())

        elif typ == "infe":
            version = self.read_version(atom)
            if version < 2:
                atom["data"]["id"] = self.buf.ru16()
                atom["data"]["protection-index"] = self.buf.ru16()
                atom["data"]["name"] = self.buf.rzs()
                atom["data"]["type"] = self.buf.rzs()
                atom["data"]["encoding"] = self.buf.rzs()

            if version == 1:
                extension_type = self.buf.rs(4)
                atom["data"]["extension-type"] = extension_type
                if extension_type == "fdel":
                    atom["data"]["extension"] = {}
                    atom["data"]["extension"]["content-location"] = self.buf.rzs()
                    atom["data"]["extension"]["content-md5"] = self.buf.rzs()
                    atom["data"]["extension"]["content-length"] = self.buf.ru64()
                    atom["data"]["extension"]["transfer-length"] = self.buf.ru64()
                    count = self.buf.ru8()
                    atom["data"]["extension"]["entry-count"] = count
                    atom["data"]["extension"]["entries"] = [
                        self.buf.ru32() for j in range(0, count)
                    ]

            if version >= 2:
                atom["data"]["id"] = (
                    self.buf.ru16() if version == 2 else self.buf.ru32()
                )
                atom["data"]["protection-index"] = self.buf.ru16()
                item_type = self.buf.rs(4)
                atom["data"]["type"] = item_type
                atom["data"]["name"] = self.buf.rzs()

                match item_type:
                    case "mime":
                        atom["data"]["content-type"] = self.buf.rzs()
                        atom["data"]["content-encoding"] = self.buf.rzs()
                    case "uri ":
                        atom["data"]["uri-type"] = self.buf.rzs()
        elif typ == "ispe":
            version = self.read_version(atom)
            atom["data"]["width"] = self.buf.ru32()
            atom["data"]["height"] = self.buf.ru32()
        elif typ == "pixi":
            version = self.read_version(atom)
            channel_count = self.buf.ru8()
            atom["data"]["channel-count"] = channel_count
            atom["data"]["channel-bit-depths"] = [
                self.buf.ru8() for i in range(0, channel_count)
            ]
        elif typ == "av1C":
            temp = self.buf.ru8()
            atom["data"]["version"] = temp & 0x7f
            temp = self.buf.ru8()
            atom["data"]["seq-profile"] = temp >> 5
            atom["data"]["seq-level-idx-0"] = temp & 0x1f
            temp = self.buf.ru8()
            atom["data"]["seq-tier-0"] = bool(temp & 0x80)
            atom["data"]["high-bitdepth"] = bool(temp & 0x40)
            atom["data"]["twelve-bit"] = bool(temp & 0x20)
            atom["data"]["monochrome"] = bool(temp & 0x10)
            atom["data"]["chroma-subsampling-x"] = bool(temp & 0x08)
            atom["data"]["chroma-subsampling-y"] = bool(temp & 0x04)
            atom["data"]["chroma-sample-poisition"] = temp & 0x03
            temp = self.buf.ru8()
            atom["data"]["reserved"] = temp >> 5
            atom["data"]["initial-presentation-delay-present"] = bool(temp & 0x10)
            atom["data"]["initial-presentation-delay-minus-one"] = temp & 0x0f
        elif typ == "ipma":
            version = self.read_version(atom)
            item_count = self.buf.ru32() if version > 0 else self.buf.ru16()
            atom["data"]["item-count"] = item_count

            atom["data"]["items"] = []
            for i in range(0, item_count):
                item = {}
                item["id"] = self.buf.ru32() if version > 0 else self.buf.ru16()
                association_count = self.buf.ru8()
                item["association-count"] = association_count

                item["associations"] = []
                for j in range(0, association_count):
                    association = {}
                    if atom["data"]["flags"] & 1:
                        entry = self.buf.ru16()
                        association["essential"] = bool(entry & 0x8000)
                        association["index"] = entry & 0x7fff
                    else:
                        entry = self.buf.ru8()
                        association["essential"] = bool(entry & 0x80)
                        association["index"] = entry & 0x7f

                    item["associations"].append(association)

                atom["data"]["items"].append(item)
        elif typ == "mebx":
            atom_count = self.buf.ru64()
            atom["data"]["atom-count"] = atom_count

            atom["data"]["atoms"] = []
            for i in range(0, atom_count):
                atom["data"]["atoms"].append(self.read_atom())
        elif typ == "ilst":
            atom["entries"] = []
            while self.buf.unit:
                length = self.buf.ru32()
                i = self.buf.rs(4)
                atom["entries"].append({
                    "id": i,
                    "content": self.read_atom(root_context=i),
                })
        elif typ in ("clef", "prof", "enof"):
            self.read_version(atom)
            atom["data"]["width"] = self.buf.rfp32()
            atom["data"]["height"] = self.buf.rfp32()
        elif typ == "alis":
            self.read_version(atom)
            atom["data"]["name"] = self.buf.rzs()
        elif typ == "mpvd":
            with self.buf.subunit():
                atom["data"]["content"] = chew(self.buf)
        elif typ == "meta":
            if self.buf.pu32() == 0:
                self.buf.skip(4)

            self.read_more(atom)
        elif typ == "iref":
            version = self.read_version(atom)

            atom["data"]["from"] = self.buf.ru16() if version == 0 else self.buf.ru32()
            atom["data"]["reference-count"] = self.buf.ru16()
        elif typ == "idat":
            atom["data"]["length"] = self.buf.unit
        elif typ == "irot":
            atom["data"]["value"] = self.buf.ru8()
        elif typ == "smta":
            self.read_version(atom)
            self.read_more(atom)
        elif typ == "mdln":
            atom["data"]["model-name"] = self.buf.rs(self.buf.unit)
        elif typ == "sefd":
            # algorithm is from https://github.com/eilam-ashbell/seft-parser/blob/4083f85aad99e01af014d089bf0b0d42acf27ad4/lib/esm/classes/Seft.js
            with self.buf.sub(self.buf.unit):
                length = self.buf.available()

                self.buf.seek(length - 8)
                headers_block_length = self.buf.ru32l()
                headers_block_start_offset = length - (headers_block_length + 8)
                self.buf.seek(headers_block_start_offset + 4)
                atom["data"]["seft-version"] = self.buf.ru32l()
                record_count = self.buf.ru32l()
                atom["data"]["record-count"] = record_count

                atom["data"]["records"] = []
                for i in range(0, record_count):
                    record = {}
                    record["padding"] = self.buf.ru16l()
                    record["type"] = self.buf.ru16l()
                    offset = self.buf.ru32l()
                    record["offset"] = offset
                    record_length = self.buf.ru32l()
                    record["length"] = record_length
                    record["content"] = {}

                    with self.buf:
                        self.buf.seek(headers_block_start_offset - offset)
                        record["content"]["padding"] = self.buf.ru16l()
                        record["content"]["type"] = self.buf.ru16l()
                        key_length = self.buf.ru32l()
                        record["content"]["key-length"] = key_length
                        value_length = record_length - key_length - 8
                        record["content"]["value-length"] = value_length
                        record["content"]["name"] = self.buf.rs(key_length)
                        record["content"]["value"] = self.buf.rs(
                            value_length, "latin-1"
                        )

                    atom["data"]["records"].append(record)
        elif typ == "clap":
            atom["data"]["clean-aperture-width"] = self.buf.ru32() / self.buf.ru32()
            atom["data"]["clean-aperture-height"] = self.buf.ru32() / self.buf.ru32()
            atom["data"]["horiz-off"] = self.buf.ru32() / self.buf.ru32()
            atom["data"]["vert-off"] = self.buf.ru32() / self.buf.ru32()
        elif typ == "gmin":
            self.read_version(atom)
            atom["data"]["graphicsmode"] = self.buf.ru16()
            atom["data"]["opcolor"] = [self.buf.ru16() for _ in range(0, 3)]
            atom["data"]["balance"] = self.buf.ru16()
            atom["data"]["reserved"] = self.buf.rh(2)
        elif typ == "dac3":
            value = self.buf.ru24()
            atom["data"]["fscod"] = value >> 22
            atom["data"]["bsid"] = (value >> 17) & ((1 << 5) - 1)
            atom["data"]["bsmod"] = (value >> 14) & ((1 << 3) - 1)
            atom["data"]["acmod"] = (value >> 11) & ((1 << 3) - 1)
            atom["data"]["lfeon"] = (value >> 10) & ((1 << 1) - 1)
            atom["data"]["bit-rate-code"] = (value >> 5) & ((1 << 5) - 1)
            atom["data"]["reserved"] = value & ((1 << 5) - 1)
        elif typ == "tx3g":
            atom["data"]["reserved"] = self.buf.rh(6)
            atom["data"]["data-reference-index"] = self.buf.ru16()
            atom["data"]["display-flags"] = self.buf.rh(4)
            atom["data"]["horizontal-justification"] = self.buf.ri8()
            atom["data"]["vertical-justification"] = self.buf.ri8()
            atom["data"]["background-color"] = self.buf.rh(4)
            atom["data"]["font-id"] = self.buf.ru16()
            atom["data"]["font-face"] = self.buf.ru8()
            atom["data"]["font-size"] = self.buf.ru8()
            atom["data"]["font-color"] = self.buf.rh(4)
            atom["data"]["default-text-box-top"] = self.buf.ru16()
            atom["data"]["default-text-box-left"] = self.buf.ru16()
            atom["data"]["default-text-box-bottom"] = self.buf.ru16()
            atom["data"]["default-text-box-right"] = self.buf.ru16()
            atom["data"]["start-char"] = self.buf.ru16()
            atom["data"]["end-char"] = self.buf.ru16()
            self.read_more(atom)
        elif typ == "ftab":
            font_count = self.buf.ru16()
            atom["data"]["font-count"] = font_count

            atom["data"]["fonts"] = []
            for i in range(0, font_count):
                font = {}
                font["id"] = self.buf.ru16()
                font["name"] = self.buf.rs(self.buf.ru8())

                atom["data"]["fonts"].append(font)
        elif typ == "chap":
            atom["data"]["track-id"] = self.buf.ru32()
        elif typ == "text":
            atom["data"]["reserved"] = self.buf.rh(6)
            atom["data"]["data-reference-index"] = self.buf.ru16()
            atom["data"]["display-flags"] = self.buf.rh(4)
            atom["data"]["horizontal-justification"] = self.buf.ri8()
            atom["data"]["vertical-justification"] = self.buf.ri8()
            atom["data"]["background-color"] = self.buf.rh(4)
            atom["data"]["font-id"] = self.buf.ru16()
            atom["data"]["font-face"] = self.buf.ru8()
            atom["data"]["font-size"] = self.buf.ru8()
            atom["data"]["font-color"] = self.buf.rh(4)
            atom["data"]["default-text-box-top"] = self.buf.ru16()
            atom["data"]["default-text-box-left"] = self.buf.ru16()
            atom["data"]["default-text-box-bottom"] = self.buf.ru16()
            atom["data"]["default-text-box-right"] = self.buf.ru16()
            if self.buf.unit > 4:
                atom["data"]["start-char"] = self.buf.ru16()
                atom["data"]["end-char"] = self.buf.ru16()
            self.read_more(atom)
        elif typ == "chpl":
            chapter_count = self.buf.ru8()
            atom["data"]["chapter-count"] = chapter_count

            atom["data"]["chapters"] = []
            for i in range(0, chapter_count):
                chapter = {}
                chapter["timestamp"] = self.buf.ru64()
                chapter["title"] = self.buf.rs(self.buf.ru8())

                atom["data"]["chapters"].append(chapter)
        elif typ == "dfLa":
            self.read_version(atom)
            atom["data"]["content"] = chew(b"fLaC" + self.buf.readunit())
        elif typ == "ID32":
            self.buf.skip(6)
            atom["data"]["content"] = chew(self.buf.readunit())
        elif typ == "nmhd":
            self.read_version(atom)
        elif typ == "jP  ":
            atom["data"]["signature"] = self.buf.rh(4)
        elif typ == "ihdr":
            atom["data"]["height"] = self.buf.ru32()
            atom["data"]["width"] = self.buf.ru32()
            atom["data"]["num-components"] = self.buf.ru16()
            atom["data"]["depth"] = self.buf.ru8()
            atom["data"]["compression"] = self.buf.ru8()
            atom["data"]["colour-unknown"] = self.buf.ru8()
            atom["data"]["ipr"] = self.buf.ru8()
        elif typ == "lbl ":
            atom["data"]["string"] = self.buf.rs(self.buf.unit)
        elif typ == "xml ":
            atom["data"]["xml"] = utils.xml_to_dict(self.buf.rs(self.buf.unit))
        elif typ == "jumd":
            atom["data"]["uuid"] = utils.to_uuid(self.buf.read(16))
            toggles = self.buf.ru8()
            atom["data"]["toggles"] = {
                "raw": toggles,
                "requestable": bool(toggles & (1 << 0)),
                "label": bool(toggles & (1 << 1)),
                "id": bool(toggles & (1 << 2)),
                "signature": bool(toggles & (1 << 3)),
            }

            if atom["data"]["toggles"]["label"]:
                atom["data"]["label"] = self.buf.rzs()

            if atom["data"]["toggles"]["id"]:
                atom["data"]["id"] = self.buf.ru32()

            if atom["data"]["toggles"]["signature"]:
                atom["data"]["signature-hash"] = self.buf.rh(32)
        elif typ == "cbor":
            atom["data"]["blob"] = utils.read_cbor(self.buf)
        elif typ == "bfdb":
            flags = self.buf.ru8()
            atom["data"]["flags"] = {
                "raw": flags,
                "has-filename": bool(flags & (1 << 0)),
            }

            atom["data"]["media-type"] = self.buf.rzs()

            if atom["data"]["flags"]["has-filename"]:
                atom["data"]["filename"] = self.buf.rzs()
        elif typ == "bidb":
            with self.buf.subunit():
                atom["data"]["file"] = chew(self.buf)
        elif typ == "dOps":
            atom["data"]["version"] = self.buf.ru8()
            atom["data"]["output-channel-count"] = self.buf.ru8()
            atom["data"]["pre-skip"] = self.buf.ru16()
            atom["data"]["input-sample-rate"] = self.buf.ru32()
            atom["data"]["output-gain"] = self.buf.ri16()
            atom["data"]["channel-mapping-family"] = self.buf.ru8()

            if atom["data"]["channel-mapping-family"] != 0:
                atom["data"]["stream-count"] = self.buf.ru8()
                atom["data"]["coupled-count"] = self.buf.ru8()
                atom["data"]["channel-mapping"] = [
                    self.buf.ru8()
                    for i in range(0, atom["data"]["output-channel-count"])
                ]
        elif typ == "fiel":
            atom["data"]["field-count"] = self.buf.ru8()
            atom["data"]["field-order"] = self.buf.ru8()
        elif typ == "chnl":
            self.read_version(atom)
            atom["data"]["stream-structure"] = self.buf.ru8()
            atom["data"]["defined-layout"] = self.buf.ru8()
            atom["data"]["omitted-channels-map"] = self.buf.ru16()

            if atom["data"]["defined-layout"] == 0:
                atom["data"]["speaker-count"] = self.buf.ru8()
                for i in range(0, atom["data"]["speaker-count"]):
                    speaker = {}
                    speaker["position"] = self.buf.ru8()
                    speaker["azimuth"] = self.buf.ru8()
                    speaker["elevation"] = self.buf.ru8()

                    atom["data"]["speakers"].append(speaker)
        elif typ == "pcmC":
            # so they only give you a sample of ISO/IEC 23003-5 but it's such
            # a small standard that the sample is the whole thing
            # see https://cdn.standards.iteh.ai/samples/77752/a17f98e0bb664a939b031b6a969995d9/ISO-IEC-23003-5-2020.pdf
            self.read_version(atom)
            atom["data"]["flags"] = utils.unpack_flags(
                self.buf.ru8(), ((0, "little-endian"),)
            )
            atom["data"]["sample-size"] = self.buf.ru8()
        elif typ == "CNCV":
            atom["data"]["version-string"] = self.buf.rs(self.buf.unit)
        elif typ == "CNDM":
            atom["data"]["values"] = [
                self.buf.ri16() for i in range(0, self.buf.unit, 2)
            ]
        elif typ == "CNTH":
            self.buf.skip(8)
            with self.buf.subunit():
                atom["data"]["content"] = chew(self.buf)
        elif typ == "d263":
            atom["data"]["encoder"] = self.buf.rs(4)
            atom["data"]["decoder-version"] = self.buf.ru8()
            atom["data"]["level"] = self.buf.ru8()
            atom["data"]["profile"] = self.buf.ru8()
        elif typ == "chan":
            atom["data"]["version"] = self.buf.ru8()
            atom["data"]["flags"] = self.buf.ru24()
            atom["data"]["layout-tag"] = self.buf.ru32()
            atom["data"]["bitmap"] = self.buf.ru32()
            atom["data"]["channel-descriptor-count"] = self.buf.ru32()

            atom["data"]["channel-descriptors"] = []
            for i in range(0, atom["data"]["channel-descriptor-count"]):
                desc = {}
                desc["label"] = self.buf.ru32()
                desc["flags"] = self.buf.ru32()
                desc["coordinates"] = [self.buf.ru32l() for j in range(0, 3)]

                atom["data"]["channel-descriptors"].append(desc)
        elif typ[0] == "©" or typ in ("iods", "SDLN", "smrd"):
            if typ[:2] == "©T" and self.buf.pu16() == self.buf.unit - 4:
                length = self.buf.ru16()
                self.buf.skip(2)
                atom["data"]["payload"] = self.buf.rs(length)
            else:
                atom["data"]["payload"] = self.buf.readunit().decode("latin-1")
        elif typ in ("FIRM", "LENS"):
            atom["data"]["string"] = self.buf.rs(self.buf.unit)
        elif typ in ("hint", "cdsc", "font", "hind", "vdep", "vplx", "subt", "cdep"):
            atom["data"]["track-id"] = self.buf.ru32()
        # video sample boxes
        elif typ in ("avc1", "hvc1", "vp09", "encv", "av01", "hev1", "vvc1", "h263"):
            atom["data"]["reserved1"] = self.buf.rh(6)
            atom["data"]["data_reference_index"] = self.buf.ru16()
            atom["data"]["pre-defined1"] = self.buf.rh(2)
            atom["data"]["reserved2"] = self.buf.rh(2)
            atom["data"]["pre-defined2"] = self.buf.rh(12)
            atom["data"]["width"] = self.buf.ru16()
            atom["data"]["height"] = self.buf.ru16()
            atom["data"]["horizresolution"] = self.buf.rfp32()
            atom["data"]["vertresolution"] = self.buf.rfp32()
            atom["data"]["reserved3"] = self.buf.rh(4)
            atom["data"]["frame-count"] = self.buf.ru16()
            name_length = self.buf.ru8()
            name = self.buf.read(31)
            atom["data"]["compressorname"] = name[:name_length].decode("utf-8")
            atom["data"]["depth"] = self.buf.ru16()
            atom["data"]["pre-defined3"] = self.buf.rh(2)

            self.read_more(atom)
        # audio sample boxes
        elif typ in (
            "samr",
            "sawb",
            "mp4a",
            "drms",
            "owma",
            "ac-3",
            "ec-3",
            "mlpa",
            "dtsl",
            "dtsh",
            "dtse",
            "enca",
            "fLaC",
            "Opus",
            "ipcm",
        ):
            if typ == "mp4a" and self.buf.unit == 4:
                atom["data"]["content"] = self.buf.rh(self.buf.unit)
            else:
                # see https://github.com/sannies/mp4parser for reference
                atom["data"]["reserved1"] = self.buf.rh(6)
                atom["data"]["data-reference-index"] = self.buf.ru16()
                atom["data"]["sound-version"] = self.buf.ru16()
                atom["data"]["reserved2"] = self.buf.rh(6)
                atom["data"]["channel-count"] = self.buf.ru16()
                atom["data"]["sample-size"] = self.buf.ru16()
                atom["data"]["compression-id"] = self.buf.ru16()
                atom["data"]["packet-size"] = self.buf.ru16()

                atom["data"]["sample-rate"] = self.buf.ru32()
                if typ != "mlpa":
                    atom["data"]["sample-rate"] >>= 16

                if atom["data"]["sound-version"] >= 1:
                    atom["data"]["samples-per-packet"] = self.buf.ru32()
                    atom["data"]["bytes-per-packet"] = self.buf.ru32()
                    atom["data"]["bytes-per-frame"] = self.buf.ru32()
                    atom["data"]["bytes-per-sample"] = self.buf.ru32()

                if atom["data"]["sound-version"] >= 2:
                    atom["data"]["sound-v2-data"] = self.buf.rh(20)

                if typ != "owma":
                    self.read_more(atom)
        elif typ in ("lpcm", "beam"):
            # TODO
            pass
        elif typ[0] == "\x00" or typ in ("mdat", "wide", "jp2c"):
            pass
        else:
            atom["unknown"] = True

        self.buf.skipunit()
        self.buf.popunit()

        return atom

    def find_stream_type(self, atoms):
        t = None

        for atom in atoms:
            if t is not None:
                break

            match atom["type"]:
                case "hvc1":
                    t = "hvec"
                case "avc1":
                    t = "avc1"
                case "vp09":
                    t = "vp9"

            if t is None and "atoms" in atom["data"]:
                t = self.find_stream_type(atom["data"]["atoms"])

        return t

    def find_avcC_length(self, atoms):
        length = None

        for atom in atoms:
            if length is not None:
                break

            if atom["type"] == "avcC":
                length = atom["data"]["lengthSizeMinusOne"] & 0x03 + 1

            if length is None and "atoms" in atom["data"]:
                length = self.find_avcC_length(atom["data"]["atoms"])

        return length

    def parse_sei(self, seis):
        count = 1000  # prevent OOM from that stupid torrent

        while self.buf.unit > 0 and count > 0:
            count -= 1

            t = 0
            while True:
                b = self.buf.ru8()
                t += b
                if b != 0xff:
                    break

            l = 0
            while True:
                b = self.buf.ru8()
                l += b
                if b != 0xff:
                    break

            if l >= 65536:
                self.buf.skip(l)
                continue

            data = self.buf.read(l)
            sei = {
                "type": t,
                "length": l,
            }

            if data[:16].hex() == "dc45e9bde6d948b7962cd820d923eeef":
                sei["data"] = {
                    "uuid": data[:16].hex(),
                    "libx264-banner": data[16:-1].decode("utf-8"),
                }
                seis.append(sei)

    def parse_mdat_hvec(self, atoms):
        mdat = None
        for atom in atoms:
            if atom["type"] == "mdat":
                mdat = atom

        if mdat is None:
            return

        mdat["data"]["type"] = "hvec"

    def parse_mdat_avc1(self, atoms):
        mdat = None
        for atom in atoms:
            if atom["type"] == "mdat":
                mdat = atom

        if mdat is None:
            return

        mdat["data"]["type"] = "avc1"

        nal_length = self.find_avcC_length(atoms)
        if nal_length is None:
            return

        self.buf.seek(mdat["offset"])
        self.buf.setunit(mdat["length"])

        self.buf.skip(8)

        mdat["data"]["sei"] = []
        while self.buf.unit > 0:
            length = int.from_bytes(self.buf.read(nal_length), "big")
            if length == 0:
                break

            self.buf.pushunit()
            self.buf.setunit(length - 1)

            t = self.buf.ru8() & 0b00011111

            if t == 6:
                self.parse_sei(mdat["data"]["sei"])

            self.buf.skipunit()
            self.buf.popunit()

        if len(mdat["data"]["sei"]) == 0:
            del mdat["data"]["sei"]

    def parse_mdat(self, atoms):
        stream_type = self.find_stream_type(atoms)

        try:
            match stream_type:
                case "avc1":
                    self.parse_mdat_avc1(atoms)

                #                case "hvec":
                #                    self.parse_mdat_hvec(atoms)
                case _:
                    for atom in atoms:
                        if atom["type"] == "mdat":
                            atom["data"]["type"] = (
                                stream_type if stream_type is not None else "unknown"
                            )
                            atom["data"]["unknown"] = True

                            self.buf.seek(atom["offset"])

                            self.buf.pushunit()
                            self.buf.setunit(atom["length"])
                            self.buf.skip(8)

                            with self.buf.subunit():
                                atom["data"]["raw"] = chew(self.buf, blob_mode=True)

                            self.buf.popunit()
        except Exception:
            # sei parsing can fail with cenc extensions
            pass

    def read_esds(self):
        # see ISO/IEC 14496-1
        tlv = {}
        tlv["tag"] = utils.unraw(
            self.buf.ru8(),
            1,
            {
                0x03: "ES_Descriptor",
                0x04: "DecoderConfigDescriptor",
                0x05: "DecoderSpecificInfo",
                0x06: "SLConfigDescriptor",
            },
            True,
        )
        tlv["length"] = self.buf.rubeb()
        tlv["value"] = {}

        self.buf.pasunit(tlv["length"])

        match tlv["tag"]:
            case "ES_Descriptor":
                tlv["value"]["es-id"] = self.buf.ru16()
                tlv["value"]["stream-dependence-flag"] = self.buf.rb(1)
                tlv["value"]["url-flag"] = self.buf.rb(1)
                tlv["value"]["ocr-stream-flag"] = self.buf.rb(1)
                tlv["value"]["stream-priority"] = self.buf.rb(5)

                if tlv["value"]["stream-dependence-flag"]:
                    tlv["value"]["depends-on-es-id"] = self.buf.ru16()

                if tlv["value"]["url-flag"]:
                    tlv["value"]["url-length"] = self.buf.ru8()
                    tlv["value"]["url"] = self.buf.rs(tlv["value"]["url-length"])

                if tlv["value"]["ocr-stream-flag"]:
                    tlv["value"]["ocr-es-id"] = self.buf.ru16()

                tlv["value"]["children"] = []
                while self.buf.unit > 0:
                    tlv["value"]["children"].append(self.read_esds())
            case "DecoderConfigDescriptor":
                tlv["value"]["object-type-indictation"] = utils.unraw(
                    self.buf.ru8(),
                    1,
                    {
                        0x01: "Systems ISO/IEC 14496-1 a",
                        0x02: "Systems ISO/IEC 14496-1 b",
                        0x03: "Interaction Stream",
                        0x04: "Systems ISO/IEC 14496-1 Extended BIFS Configuration c",
                        0x05: "Systems ISO/IEC 14496-1 AFX d",
                        0x06: "Font Data Stream",
                        0x07: "Synthesized Texture Stream",
                        0x08: "Streaming Text Stream",
                        0x20: "Visual ISO/IEC 14496-2 e",
                        0x21: "Visual ITU-T Recommendation H.264 | ISO/IEC 14496-10 f",
                        0x22: "Parameter Sets for ITU-T Recommendation H.264 | ISO/IEC 14496-10 f",
                        0x40: "Audio ISO/IEC 14496-3 g",
                        0x60: "Visual ISO/IEC 13818-2 Simple Profile",
                        0x61: "Visual ISO/IEC 13818-2 Main Profile",
                        0x62: "Visual ISO/IEC 13818-2 SNR Profile",
                        0x63: "Visual ISO/IEC 13818-2 Spatial Profile",
                        0x64: "Visual ISO/IEC 13818-2 High Profile",
                        0x65: "Visual ISO/IEC 13818-2 422 Profile",
                        0x66: "Audio ISO/IEC 13818-7 Main Profile",
                        0x67: "Audio ISO/IEC 13818-7 LowComplexity Profile",
                        0x68: "Audio ISO/IEC 13818-7 Scaleable Sampling Rate Profile",
                        0x69: "Audio ISO/IEC 13818-3",
                        0x6a: "Visual ISO/IEC 11172-2",
                        0x6b: "Audio ISO/IEC 11172-3",
                        0x6c: "Visual ISO/IEC 10918-1",
                        0x6e: "Visual ISO/IEC 15444-1",
                    },
                    True,
                )
                tlv["value"]["stream-type"] = utils.unraw(
                    self.buf.rb(6),
                    1,
                    {
                        0x01: "ObjectDescriptorStream",
                        0x02: "ClockReferenceStream",
                        0x03: "SceneDescriptionStream",
                        0x04: "VisualStream",
                        0x05: "AudioStream",
                        0x06: "MPEG7Stream",
                        0x07: "IPMPStream",
                        0x08: "ObjectContentInfoStream",
                        0x09: "MPEGJStream",
                        0x0a: "Interaction Stream",
                        0x0b: "IPMPToolStream",
                    },
                    True,
                )
                tlv["value"]["up-stream"] = self.buf.rb(1)
                tlv["value"]["reserved"] = self.buf.rb(1)
                tlv["value"]["buffer-size-db"] = self.buf.ru24()
                tlv["value"]["max-bitrate"] = self.buf.ru32()
                tlv["value"]["avg-bitrate"] = self.buf.ru32()

                tlv["value"]["children"] = []
                while self.buf.unit > 0:
                    tlv["value"]["children"].append(self.read_esds())
            case "DecoderSpecificInfo":
                tlv["value"]["payload"] = self.buf.rh(self.buf.unit)
            case "SLConfigDescriptor":
                tlv["value"]["predefined"] = self.buf.ru8()

                if tlv["value"]["predefined"] == 0:
                    tlv["value"]["use-access-unit-start-flag"] = self.buf.rb(1)
                    tlv["value"]["use-access-unit-end-flag"] = self.buf.rb(1)
                    tlv["value"]["use-random-access-point-flag"] = self.buf.rb(1)
                    tlv["value"]["has-random-access-units-only-flag"] = self.buf.rb(1)
                    tlv["value"]["use-padding-flag"] = self.buf.rb(1)
                    tlv["value"]["use-timestamps-flag"] = self.buf.rb(1)
                    tlv["value"]["use-idle-flag"] = self.buf.rb(1)
                    tlv["value"]["duration-flag"] = self.buf.rb(1)
                    tlv["value"]["timestamp-resolution"] = self.buf.ru32()
                    tlv["value"]["ocr-resolution"] = self.buf.ru32()
                    tlv["value"]["timestamp-length"] = self.buf.ru8()
                    tlv["value"]["ocr-length"] = self.buf.ru8()
                    tlv["value"]["au-length"] = self.buf.ru8()
                    tlv["value"]["instant-bitrate-length"] = self.buf.ru8()
                    tlv["value"]["degradation-priority-length"] = self.buf.rb(4)
                    tlv["value"]["au-sequence-number"] = self.buf.rb(5)
                    tlv["value"]["packet-sequence-number-length"] = self.buf.rb(5)
                    tlv["value"]["reserved"] = self.buf.rb(2)

                    if tlv["value"]["duration-flag"]:
                        tlv["value"]["time-scale"] = self.buf.ru32()
                        tlv["value"]["access-unit-duration"] = self.buf.ru16()
                        tlv["value"]["composition-unit-duration"] = self.buf.ru16()

                    if not tlv["value"]["use-timestamps-flag"]:
                        tlv["value"]["start-decoding-timestamp"] = self.buf.rb(
                            tlv["value"]["timestamp-length"]
                        )
                        tlv["value"]["start-comosition-timestamp"] = self.buf.rb(
                            tlv["value"]["timestamp-length"]
                        )
            case _:
                tlv["unknown"] = True
                tlv["value"]["payload"] = self.buf.rh(self.buf.unit)

        self.buf.sapunit()

        return tlv

    def read_h264_nalu(self):
        nal = {}
        nal["forbidden-zero-bit"] = self.buf.rb(1)
        nal["ref-idc"] = self.buf.rb(2)
        # ISO/IEC 14496-10:2022 page 81
        nal["unit-type"] = utils.unraw(
            self.buf.rb(5),
            1,
            {0x07: "Sequence parameter set", 0x08: "Picture parameter set"},
            True,
        )

        match nal["unit-type"]:
            case "Sequence parameter set":
                # ISO/IEC 14496-10:2022 page 59
                nal["profile-idc"] = self.buf.ru8()
                nal["constraint-set-flags"] = [self.buf.rb(1) for i in range(0, 6)]
                nal["reserved"] = self.buf.rb(2)
                nal["level-idc"] = self.buf.ru8()
                nal["seq-parameter-set-id"] = self.buf.rue()

                if nal["profile-idc"] in (
                    44,
                    83,
                    86,
                    100,
                    110,
                    118,
                    122,
                    128,
                    134,
                    135,
                    138,
                    139,
                    244,
                ):
                    # TODO: scaling lists look annoying and like a problem for later
                    self.buf.align()
                    nal["rest"] = self.buf.rh(self.buf.unit)
                    nal["unknown"] = True
                    return nal

                # TODO: implement rest
                self.buf.align()
                nal["rest"] = self.buf.rh(self.buf.unit)
            case _:
                nal["payload"] = self.buf.rh(self.buf.unit)
                nal["unknown"] = True

        return nal


@module.register
class MatroskaModule(module.RuminantModule):
    desc = "Matroska files like WebM or MKV files."

    FIELDS = {
        0x00000027: ("Position", "uint"),
        0x00000067: ("Timestamp", "uint"),
        0x00000080: ("ChapterDisplay", "libmkv-workaround"),
        0x00000083: ("TrackType", "uint"),
        0x00000085: ("ChapString", "utf8"),
        0x00000086: ("CodecID", "ascii"),
        0x00000088: ("FlagDefault", "uint"),
        0x00000091: ("ChapterTimeStart", "uint"),
        0x00000092: ("ChapterTimeEnd", "uint"),
        0x00000098: ("ChapterFlagHidden", "uint"),
        0x0000009a: ("FlagInterlaced", "uint"),
        0x0000009c: ("FlagLacing", "uint"),
        0x0000009f: ("Channels", "uint"),
        0x000000a0: ("BlockGroup", "master"),
        0x000000a1: ("Block", "binary"),
        0x000000a3: ("SimpleBlock", "binary"),
        0x000000aa: ("CodecDecodeAll", "uint"),
        0x000000ae: ("TrackEntry", "master"),
        0x000000b0: ("PixelWidth", "uint"),
        0x000000b2: ("CueDuration", "uint"),
        0x000000b3: ("CueTime", "uint"),
        0x000000b5: ("SamplingFrequency", "float"),
        0x000000b6: ("ChapterAtom", "master"),
        0x000000b7: ("CueTrackPositions", "master"),
        0x000000b9: ("FlagEnabled", "uint"),
        0x000000ba: ("PixelHeight", "uint"),
        0x000000bb: ("CuePoint", "master"),
        0x000000bf: ("CRC-32", "hex"),
        0x000000d7: ("TrackNumber", "uint"),
        0x000000e0: ("Video", "master"),
        0x000000e1: ("Audio", "master"),
        0x000000e7: ("Timestamp", "uint"),
        0x000000ec: ("Void", "binary"),
        0x000000f0: ("CueRelativePosition", "uint"),
        0x000000f1: ("CueClusterPosition", "uint"),
        0x000000f7: ("CueTrack", "uint"),
        0x00004282: ("DocType", "ascii"),
        0x00004285: ("DocTypeReadVersion", "uint"),
        0x00004286: ("EBMLVersion", "uint"),
        0x00004287: ("DocTypeVersion", "uint"),
        0x000042f2: ("EBMLMaxIDLength", "uint"),
        0x000042f3: ("EBMLMaxSizeLength", "uint"),
        0x000042f7: ("EBMLReadVersion", "uint"),
        0x0000437c: ("ChapLanguage", "ascii"),
        0x0000437d: ("ChapLanguageBCP47", "ascii"),
        0x00004461: ("DateUTC", "date"),
        0x0000447a: ("TagLanguage", "ascii"),
        0x0000447b: ("TagLanguageBCP47", "ascii"),
        0x00004484: ("TadDefault", "uint"),
        0x00004487: ("TagString", "utf8"),
        0x00004489: ("Duration", "float"),
        0x00004598: ("ChapterFlagEnabled", "uint"),
        0x000045a3: ("TagName", "utf8"),
        0x000045b9: ("EditionEntry", "master"),
        0x000045bc: ("EditionUID", "uint"),
        0x000045bd: ("EditionFlagHidden", "uint"),
        0x000045db: ("EditionFlagDefault", "uint"),
        0x000045dd: ("EditionFlagOrdered", "uint"),
        0x0000465c: ("FileData", "blob"),
        0x00004660: ("FileMediaType", "ascii"),
        0x0000466e: ("FileName", "utf8"),
        0x000046ae: ("FileUID", "uint"),
        0x00004d80: ("MuxingApp", "utf8"),
        0x00004dbb: ("Seek", "master"),
        0x0000536e: ("Name", "utf8"),
        0x000053ab: ("SeekID", "hex"),
        0x000053ac: ("SeekPosition", "uint"),
        0x000053b8: ("VideoStereoMode", "uint"),
        0x000054b0: ("DisplayWidth", "uint"),
        0x000054b2: ("DisplayUnit", "uint"),
        0x000054ba: ("DisplayHeight", "uint"),
        0x000055aa: ("FlagForced", "uint"),
        0x000055ab: ("FlagHearingImpaired", "uint"),
        0x000055ac: ("FlagVisualImpaired", "uint"),
        0x000055ae: ("FlagOriginal", "uint"),
        0x000055b0: ("Colour", "master"),
        0x000055b1: ("MatrixCoefficients", "uint"),
        0x000055b7: ("ChromaSitingHorz", "uint"),
        0x000055b8: ("ChromaSitingVert", "uint"),
        0x000055b9: ("Range", "uint"),
        0x000055ba: ("TransferCharacteristics", "uint"),
        0x000055bb: ("Primaries", "uint"),
        0x000055ee: ("MaxBlockAdditionID", "uint"),
        0x000056aa: ("CodecDelay", "uint"),
        0x000056bb: ("SeekPreRoll", "uint"),
        0x00005741: ("WritingApp", "utf8"),
        0x000061a7: ("AttachedFile", "master"),
        0x00006264: ("BitDepth", "uint"),
        0x000063a2: ("CodecPrivate", "binary"),
        0x000063c0: ("Targets", "master"),
        0x000063c5: ("TagTrackUID", "uint"),
        0x000063ca: ("TargetType", "ascii"),
        0x000067c8: ("SimpleTarget", "master"),
        0x000068ca: ("TargetTypeValue", "uint"),
        0x00006de7: ("MinCache", "uint"),
        0x00007373: ("Tag", "master"),
        0x000073a4: ("SegmentUUID", "uuid"),
        0x000073c4: ("ChapterUID", "uint"),
        0x000073c5: ("TrackUID", "uint"),
        0x000075a2: ("DiscardPadding", "sint"),
        0x000078b5: ("OutputSamplingFrequency", "float"),
        0x00007ba9: ("Title", "utf8"),
        0x0022b59c: ("Language", "utf8"),
        0x0022b59d: ("LanguageBCP47", "ascii"),
        0x0023314f: ("TrackTimestampScale", "float"),
        0x0023e383: ("DefaultDuration", "uint"),
        0x002ad7b1: ("TimestampScale", "uint"),
        0x1043a770: ("Chapters", "master"),
        0x114d9b74: ("SeekHead", "master"),
        0x1254c367: ("Tags", "master"),
        0x1549a966: ("Info", "master"),
        0x1654ae6b: ("Tracks", "master"),
        0x18538067: ("Segment", "master"),
        0x1941a469: ("Attachments", "master"),
        0x1a45dfa3: ("EMBL", "master"),
        0x1c53bb6b: ("Cues", "skipped-master"),
        0x1f43b675: ("Cluster", "skipped-master"),
    }

    def identify(buf, ctx):
        return buf.peek(4) == b"\x1a\x45\xdf\xa3"

    def chew(self):
        meta = {}
        meta["type"] = "matroska"

        meta["tags"] = []
        while self.buf.available():
            meta["tags"].append(self.read_tag())

        return meta

    def read_vint(self, m=True):
        val = self.buf.ru8()

        mask = 0x80
        length = 1
        while length <= 8 and not (val & mask):
            mask >>= 1
            length += 1

        if length > 8:
            raise ValueError("VINT too long")

        if m:
            val &= mask - 1
        for _ in range(length - 1):
            val <<= 8
            val |= self.buf.ru8()

        return val

    def read_tag(self):
        tag_id = self.read_vint(False)
        tag_length = self.read_vint()

        tag = {}
        tag["name"], tag["type"] = self.FIELDS.get(
            tag_id, (f"Unknown ({hex(tag_id)})", "unknown")
        )

        tag["length"] = tag_length

        self.buf.pushunit()
        self.buf.setunit(tag_length)

        match tag["type"]:
            case "sint":
                tag["data"] = int.from_bytes(self.buf.readunit(), "big", signed=True)
            case "uint":
                tag["data"] = int.from_bytes(self.buf.readunit(), "big")
            case "float":
                match tag_length:
                    case 0:
                        tag["data"] = 0.0
                    case 4:
                        tag["data"] = struct.unpack(">f", self.buf.read(4))[0]
                    case 8:
                        tag["data"] = struct.unpack(">d", self.buf.read(8))[0]
                    case _:
                        raise ValueError(f"Invalid float size {tag_length}")
            case "ascii":
                tag["data"] = self.buf.rs(tag_length, "ascii")
            case "utf8":
                tag["data"] = self.buf.rs(tag_length, "utf-8")
            case "date":
                tag["data"] = (
                    datetime.datetime(2001, 1, 1, tzinfo=datetime.timezone.utc)
                    + datetime.timedelta(
                        microseconds=int.from_bytes(
                            self.buf.readunit(), "big", signed=True
                        )
                        / 1000
                    )
                ).isoformat()
            case "master":
                if tag_length == 0:
                    self.buf.popunit()
                    self.buf.pushunit()

                tag["data"] = []
                while self.buf.unit > 0:
                    tag["data"].append(self.read_tag())
            case "hex":
                tag["data"] = self.buf.rh(tag_length)
            case "uuid":
                tag["data"] = utils.to_uuid(self.buf.read(tag_length))
            case "blob":
                with self.buf.sub(tag_length):
                    tag["data"] = chew(self.buf)

                self.buf.skip(tag_length)
            case "libmkv-workaround":
                # special case for old libmkv used by old HandBrake versions
                # was fixed in f8af3e4 upstream
                with self.buf:
                    is_libmkv = False
                    try:
                        self.read_vint()
                        assert self.read_vint() < tag_length
                    except Exception:
                        is_libmkv = True

                if is_libmkv:
                    tag["name"] = "MuxingApp"
                    tag["type"] = "ascii"
                    tag["data"] = self.buf.rs(tag_length, "ascii")
                else:
                    tag["type"] = "master"

                    if tag_length == 0:
                        self.buf.popunit()
                        self.buf.pushunit()

                    tag["data"] = []
                    while self.buf.unit > 0:
                        tag["data"].append(self.read_tag())

        self.buf.skipunit()
        self.buf.popunit()

        return tag


@module.register
class OggModule(module.RuminantModule):
    desc = "Ogg files like OGG or OGV files."

    def identify(buf, ctx):
        return buf.peek(4) == b"OggS"

    def chew(self):
        meta = {}
        meta["type"] = "ogg"

        meta["packets"] = []

        slacks = {}
        streams = []
        while self.buf.peek(4) == b"OggS":
            self.buf.skip(4)
            assert self.buf.ru8() == 0, "broken Ogg page"

            flags = self.buf.ru8()
            self.buf.skip(8)
            stream_id = self.buf.ru32l()
            self.buf.skip(8)

            if stream_id not in streams:
                streams.append(stream_id)

            if flags & 0x04 and stream_id in streams:
                streams.remove(stream_id)

            segment_count = self.buf.ru8()

            for length in [self.buf.ru8() for i in range(0, segment_count)]:
                if stream_id not in slacks:
                    slacks[stream_id] = b""

                slacks[stream_id] += self.buf.read(length)

                if length != 255:
                    self.process_packet(Buf(slacks[stream_id]), stream_id, meta)
                    slacks[stream_id] = b""

        return meta

    def process_packet(self, buf, stream_id, meta):
        packet = {}
        packet["stream-id"] = stream_id
        packet["codec"] = None
        packet["type"] = None
        packet["data"] = {}

        if buf.peek(7) == b"\x01vorbis":
            buf.skip(7)
            packet["codec"] = "vorbis"
            packet["type"] = "id"

            packet["data"]["version"] = buf.ru32l()
            packet["data"]["channel-count"] = buf.ru8()
            packet["data"]["sample-rate"] = buf.ru32l()
            packet["data"]["bitrate-maximum"] = buf.ru32l()
            packet["data"]["bitrate-nominal"] = buf.ru32l()
            packet["data"]["bitrate-minimum"] = buf.ru32l()
            temp = buf.ru8()
            packet["data"]["blocksize-small"] = 2 ** (temp & 0x03)
            packet["data"]["blocksize-large"] = 2 ** (temp >> 4)
            packet["data"]["framing-flag"] = buf.ru8()
        elif buf.peek(7) == b"\x03vorbis":
            buf.skip(7)
            packet["codec"] = "vorbis"
            packet["type"] = "comment"

            packet["data"]["vendor-string"] = buf.rs(buf.ru32l())

            packet["data"]["user-strings"] = []
            for i in range(0, buf.ru32l()):
                packet["data"]["user-strings"].append(buf.rs(buf.ru32l()))

            packet["data"]["framing-flag"] = buf.ru8()
        elif buf.peek(7) == b"\x05vorbis":
            buf.skip(7)
            packet["codec"] = "vorbis"
            packet["type"] = "setup"
        elif buf.peek(8) == b"OpusHead":
            buf.skip(8)
            packet["codec"] = "opus"
            packet["type"] = "head"

            packet["data"]["version"] = buf.ru8()
            channel_count = buf.ru8()
            packet["data"]["channel-count"] = channel_count
            packet["data"]["pre-skip"] = buf.ru16l()
            packet["data"]["input-sample-rate"] = buf.ru32l()
            packet["data"]["output-gain"] = buf.ri16() / 256
            mapping = buf.ru8()
            packet["data"]["channel-mapping"] = mapping

            if mapping > 0:
                packet["data"]["stream-count"] = buf.ru8()
                packet["data"]["coupled-count"] = buf.ru8()
                packet["data"]["channel-mapping-table"] = [
                    buf.ru8() for i in range(0, channel_count)
                ]
        elif buf.peek(8) == b"OpusTags":
            buf.skip(8)
            packet["codec"] = "opus"
            packet["type"] = "tags"

            packet["data"]["vendor-string"] = buf.rs(buf.ru32l())

            packet["data"]["user-strings"] = []
            for i in range(0, buf.ru32l()):
                packet["data"]["user-strings"].append(buf.rs(buf.ru32l()))
        elif buf.peek(7) == b"\x80theora":
            buf.skip(7)
            packet["codec"] = "theora"
            packet["type"] = "id"

            packet["data"]["version"] = f"{buf.ru8()}.{buf.ru8()}.{buf.ru8()}"
            packet["data"]["frame-width"] = buf.ru16()
            packet["data"]["frame-height"] = buf.ru16()
            packet["data"]["pic-width"] = buf.ru24()
            packet["data"]["pic-height"] = buf.ru24()
            packet["data"]["pic-x"] = buf.ru8()
            packet["data"]["pic-y"] = buf.ru8()
            packet["data"]["framerate"] = buf.ru32() / buf.ru32()

            a = buf.ru24l()
            b = buf.ru24l()
            packet["data"]["aspect"] = {
                "a": a,
                "b": b,
                "rational-approximation": a / b if b != 0 else None,
            }

            packet["data"]["colorspace"] = buf.ru8()
            packet["data"]["pixel-fmt-flags"] = buf.ru8()
            packet["data"]["target-bitrate"] = buf.ru24l()
            packet["data"]["quality"] = buf.ru8()
            if buf.available() > 0:
                packet["data"]["keyframe-granule-shift"] = buf.ru8()
                packet["data"]["pixel-fmt-flags2"] = buf.ru8()
        elif buf.peek(7) == b"\x81theora":
            buf.skip(7)
            packet["codec"] = "theora"
            packet["type"] = "comment"

            packet["data"]["vendor-string"] = buf.rs(buf.ru32l())

            packet["data"]["user-strings"] = []
            for i in range(0, buf.ru32l()):
                packet["data"]["user-strings"].append(buf.rs(buf.ru32l()))
        elif buf.peek(7) == b"\x82theora":
            buf.skip(7)
            packet["codec"] = "theora"
            packet["type"] = "setup"
        else:
            return

        meta["packets"].append(packet)


@module.register
class MpegTsModule(module.RuminantModule):
    desc = (
        "MPEG transport stream files like the ones served on the web by M3U8 playlists."
    )

    def identify(buf, ctx):
        if buf.available() < 188:
            return False
        if buf.available() == 188:
            return buf.peek(1) == b"\x47"
        elif buf.available() == 204:
            return buf.peek(1) == b"\x47" and buf.peek(189)[-1] != b"\x47"
        else:
            return buf.peek(1) == b"\x47" and (
                buf.peek(189)[-1] == 0x47 or buf.peek(205)[-1] == 0x47
            )

    def read_descriptors(self, buf):
        descs = []

        while buf.unit > 0:
            desc = {}
            desc["tag"] = buf.ru8()
            desc["type"] = "unknown"
            desc["length"] = buf.ru8()
            desc["data"] = {}

            buf.pushunit()
            buf.setunit(desc["length"])

            match desc["tag"]:
                case 0x48:
                    desc["type"] = "Service Descriptor"
                    desc["data"]["service-type"] = utils.unraw(
                        buf.ru8(), 1, {1: "Digital TV", 2: "Radio"}
                    )
                    desc["data"]["provider"] = buf.rs(buf.ru8())
                    desc["data"]["service"] = buf.rs(buf.ru8())
                case 0x0a:
                    desc["type"] = "Language"
                    desc["data"]["language"] = buf.rs(3)
                    desc["data"]["audio-type"] = utils.unraw(
                        buf.ru8(),
                        1,
                        {
                            0: "Undefined",
                            1: "Main audio",
                            2: "Commentary",
                            3: "Karaoke",
                        },
                    )
                case 0x25 | 0x26:
                    if buf.peek(2) == b"\xff\xff":
                        desc["type"] = "Twitch ID3"
                    else:
                        desc["payload"] = buf.rh(buf.unit)
                        desc["unknown"] = True
                case _:
                    desc["payload"] = buf.rh(buf.unit)
                    desc["unknown"] = True

            buf.skipunit()
            buf.popunit()

            descs.append(desc)

        return descs

    def process(self, pid, buf):
        chunk = {}
        chunk["pid"] = pid
        chunk["length"] = buf.available()
        chunk["type"] = "unknown"
        chunk["data"] = {}

        if pid in (0x0000, 0x0011) or pid in self.programs:
            chunk["type"] = {0x0011: "sdt", 0x0000: "pat"}.get(pid, "pmt")

            del chunk["data"]
            chunk["psi"] = {}
            chunk["data"] = {}
            chunk["psi"]["table-id"] = buf.ru8()
            temp = buf.ru16()
            chunk["psi"]["fixed"] = temp >> 12

            chunk["psi"]["section-length"] = temp & 0x0fff
            buf.pushunit()
            buf.setunit(chunk["psi"]["section-length"] - 4)

            chunk["psi"]["transport-stream-id"] = buf.ru16()
            temp = buf.ru8()
            chunk["psi"]["reserved1"] = temp >> 6
            chunk["psi"]["version"] = (temp >> 1) & 0x1f
            chunk["psi"]["cni"] = bool(temp & 0x01)
            chunk["psi"]["section-number"] = buf.ru8()
            chunk["psi"]["last-section-number"] = buf.ru8()
            chunk["psi"]["crc-32"] = None

            match pid:
                case 0x0011:
                    chunk["data"]["original-network-id"] = buf.ru16()
                    chunk["data"]["reserved2"] = buf.ru8()

                    chunk["data"]["programs"] = []
                    while buf.unit > 0:
                        program = {}
                        program["service-id"] = buf.ru16()
                        eit = buf.ru8()
                        program["eit"] = {
                            "reserved": eit >> 2,
                            "schedule": bool(eit & 0x02),
                            "present-or-following": bool(eit & 0x01),
                        }
                        temp = buf.ru16()
                        program["running-status"] = utils.unraw(
                            (temp >> 13) & 0x07,
                            1,
                            {0: "Undefined", 1: "Not running", 4: "Running"},
                        )
                        program["scrambled"] = bool(temp & 0x1000)
                        program["descriptor-length"] = temp & 0x0fff

                        buf.pushunit()
                        buf.setunit(temp & 0x0fff)

                        program["descriptors"] = self.read_descriptors(buf)

                        buf.skipunit()
                        buf.popunit()

                        chunk["data"]["programs"].append(program)
                case 0x0000:
                    chunk["data"]["programs"] = []
                    while buf.unit > 0:
                        program = {}
                        program["program-number"] = buf.ru16()
                        program["pid"] = buf.ru16() & 0x1fff

                        self.programs[program["pid"]] = program["program-number"]

                        chunk["data"]["programs"].append(program)
                case _:
                    chunk["data"]["program-id"] = self.programs[pid]
                    temp = buf.ru16()
                    chunk["data"]["reserved"] = temp >> 13
                    chunk["data"]["pcr-id"] = temp & 0x1fff
                    chunk["data"]["program-length"] = buf.ru16() & 0x0fff

                    buf.pushunit()
                    buf.setunit(chunk["data"]["program-length"])

                    chunk["data"]["programs"] = self.read_descriptors(buf)

                    buf.skipunit()
                    buf.popunit()

                    chunk["data"]["elementary-streams"] = []
                    while buf.unit > 0:
                        es = {}
                        es["type"] = utils.unraw(
                            buf.ru8(),
                            1,
                            {
                                2: "MPEG-2 video",
                                3: "MPEG-1 audio",
                                15: "AAC audio",
                                21: "ID3 metadata",
                                27: "H.264 video",
                            },
                        )
                        es["pid"] = buf.ru16() & 0x1fff
                        self.es[es["pid"]] = es["type"]["raw"]
                        es["descriptor-length"] = buf.ru16() & 0x0fff

                        buf.pushunit()
                        buf.setunit(es["descriptor-length"])

                        es["descriptors"] = self.read_descriptors(buf)

                        buf.skipunit()
                        buf.popunit()

                        chunk["data"]["elementary-streams"].append(es)

            buf.skipunit()
            buf.popunit()

            chunk["psi"]["crc-32"] = buf.rh(4)
        else:
            chunk["unknown"] = True

        return chunk

    def chew(self):
        meta = {}
        meta["type"] = "mpeg-ts"
        meta["chunks"] = []

        self.programs = {}
        self.es = {}
        slack = {}
        starts = {}

        index = 0
        while self.buf.peek(1) == b"\x47":
            self.buf.skip(1)
            index += 1

            temp = self.buf.ru16()
            pusi = bool(temp & 0x4000)
            pid = temp & 0x1fff

            left = 184
            if self.buf.ru8() & 0x20:
                to_skip = self.buf.ru8()
                self.buf.skip(to_skip)
                left -= to_skip + 1

            if pid not in slack:
                slack[pid] = b""

            if pusi:
                offset = self.buf.ru8() + 1
                self.buf.skip(offset - 1)

                if len(slack[pid]):
                    chunk = self.process(pid, Buf(slack[pid]))
                    chunk["index"] = starts[pid]
                    chunk["blob"] = slack[pid]
                    meta["chunks"].append(chunk)

                slack[pid] = self.buf.read(left - offset)
                starts[pid] = index
            else:
                slack[pid] += self.buf.read(left)

            if (
                self.buf.peek(1) != b"\x47"
                and self.buf.available() > 16
                and self.buf.peek(17)[-1] == b"\x47"
            ):
                self.buf.skip(16)

        for key, value in slack.items():
            chunk = self.process(key, Buf(value))
            chunk["index"] = starts[key]
            chunk["blob"] = value
            meta["chunks"].append(chunk)

        meta["chunks"].sort(key=lambda x: x["index"])
        for chunk in meta["chunks"]:
            if chunk["pid"] in self.es:
                del chunk["unknown"]

                match self.es[chunk["pid"]]:
                    case 21:
                        chunk["type"] = "id3"

                        blob = chunk["blob"]
                        while blob[:3] != b"ID3":
                            blob = blob[1:]

                        chunk["data"] = chew(blob)
                    case _:
                        chunk["type"] = "es"

            del chunk["index"]
            del chunk["blob"]

        return meta


@module.register
class AsfModule(module.RuminantModule):
    desc = "Advanced Systems Format files like WMA or WMV files."

    def identify(buf, ctx):
        return (
            buf.available() > 16
            and buf.pguid() == "75b22630-668e-11cf-a6d9-00aa0062ce6c"
        )

    def read_object(self):
        obj = {}

        obj["uuid"] = self.buf.rguid()
        obj["offset"] = self.buf.tell() - 16
        obj["length"] = self.buf.ru64l()

        self.buf.pushunit()
        self.buf.setunit(obj["length"] - 24)

        obj["name"] = "Unknown"
        obj["data"] = {}
        match obj["uuid"]:
            case "75b22630-668e-11cf-a6d9-00aa0062ce6c":
                obj["name"] = "Header"
                obj["data"]["subobject-count"] = self.buf.ru32l()
                obj["data"]["reserved1"] = self.buf.ru8()
                obj["data"]["reserved2"] = self.buf.ru8()

                obj["data"]["subobjects"] = []
                for i in range(0, obj["data"]["subobject-count"]):
                    obj["data"]["subobjects"].append(self.read_object())
            case "8cabdca1-a947-11cf-8ee4-00c00c205365":
                obj["name"] = "File Properties"
                obj["data"]["file-guid"] = self.buf.rguid()
                obj["data"]["file-size"] = self.buf.ru64l()
                obj["data"]["creation-date"] = utils.filetime_to_date(self.buf.ru64l())
                obj["data"]["data-packets-count"] = self.buf.ru64l()

                temp = self.buf.ru64l()
                obj["data"]["play-duration"] = {"raw": temp, "seconds": temp / 10000000}

                temp = self.buf.ru64l()
                obj["data"]["send-duration"] = {"raw": temp, "seconds": temp / 10000000}

                temp = self.buf.ru64l()
                obj["data"]["preroll"] = {"raw": temp, "seconds": temp / 1000}

                flags = self.buf.ru32l()
                obj["data"]["flags"] = {
                    "raw": flags,
                    "live": bool(flags & (1 << 0)),
                    "huge-data-units": bool(flags & (1 << 1)),
                }

                obj["data"]["min-data-packet-size"] = self.buf.ru32l()
                obj["data"]["max-data-packet-size"] = self.buf.ru32l()
                obj["data"]["max-bitrate"] = self.buf.ru32l()
            case "5fbf03b5-a92e-11cf-8ee3-00c00c205365":
                obj["name"] = "Header Extension"
                obj["data"]["reserved1"] = self.buf.rguid()
                obj["data"]["reserved2"] = self.buf.ru16l()
                obj["data"]["subobject-size"] = self.buf.ru32l()

                self.buf.pushunit()
                self.buf.setunit(obj["data"]["subobject-size"])

                obj["data"]["subobjects"] = []
                while self.buf.unit > 0:
                    obj["data"]["subobjects"].append(self.read_object())

                self.buf.popunit()
            case "7c4346a9-efe0-4bfc-b229-393ede415c85":
                obj["name"] = "Language List"
                obj["data"]["language-count"] = self.buf.ru16l()
                obj["data"]["languages"] = [
                    self.buf.rs(self.buf.ru8(), "utf16")
                    for i in range(0, obj["data"]["language-count"])
                ]
            case "14e6a5cb-c672-4332-8399-a96952065b5a":
                obj["name"] = "Extended Stream Properties Object"
                obj["data"]["start-time-ms"] = self.buf.ru64l()
                obj["data"]["end-time-ms"] = self.buf.ru64l()
                obj["data"]["data-bitrate"] = self.buf.ru32l()
                obj["data"]["buffer-size"] = self.buf.ru32l()
                obj["data"]["initial-buffer-fullness"] = self.buf.ru32l()
                obj["data"]["alternate-data-bitrate"] = self.buf.ru32l()
                obj["data"]["alternate-buffer-size"] = self.buf.ru32l()
                obj["data"]["alternate-initial-buffer-fullness"] = self.buf.ru32l()
                obj["data"]["maximum-object-size"] = self.buf.ru32l()

                flags = self.buf.ru32l()
                obj["data"]["flags"] = {
                    "raw": flags,
                    "reliable": bool(flags & (1 << 0)),
                    "seekable": bool(flags & (1 << 1)),
                    "no-cleanpoints": bool(flags & (1 << 2)),
                    "resend-live-cleanpoints": bool(flags & (1 << 3)),
                }

                obj["data"]["stream-number"] = self.buf.ru16l()
                obj["data"]["stream-language-id-index"] = self.buf.ru16l()
                obj["data"]["avg-time-per-frame"] = self.buf.ru64l()
                obj["data"]["stream-name-count"] = self.buf.ru16l()
                obj["data"]["payload-extension-system-count"] = self.buf.ru16l()

                obj["data"]["stream-names"] = []
                for i in range(0, obj["data"]["stream-name-count"]):
                    name = {}
                    name["language-id-index"] = self.buf.ru16l()
                    name["stream-name"] = self.buf.rs(self.buf.ru16l(), "utf16")

                    obj["data"]["stream-names"].append(name)

                obj["data"]["payload-extension-systems"] = []
                for i in range(0, obj["data"]["payload-extension-system-count"]):
                    extension = {}
                    extension["system-id"] = self.buf.rguid()
                    extension["data-size"] = self.buf.ru16l()
                    extension["system-info"] = self.buf.rh(self.buf.ru32l())

                    obj["data"]["payload-extension-systems"].append(extension)

                obj["data"]["subobjects"] = []
                while self.buf.unit > 0:
                    obj["data"]["subobjects"].append(self.read_object())
            case "d2d0a440-e307-11d2-97f0-00a0c95ea850":
                obj["name"] = "Extended Content Description Object"
                obj["data"]["content-descriptor-count"] = self.buf.ru16l()

                obj["data"]["content-descriptors"] = []
                for i in range(0, obj["data"]["content-descriptor-count"]):
                    desc = {}
                    desc["name"] = self.buf.rs(self.buf.ru16l(), "utf16")

                    typ = self.buf.ru16l()
                    desc["type"] = utils.unraw(
                        typ,
                        2,
                        {
                            0: "Unicode string",
                            1: "BYTE array",
                            2: "BOOL",
                            3: "DWORD",
                            4: "QWORD",
                            5: "WORD",
                        },
                    )

                    self.buf.pushunit()
                    self.buf.setunit(self.buf.ru16l())

                    match desc["type"]["name"]:
                        case "Unicode string":
                            desc["value"] = self.buf.rs(self.buf.unit, "utf16")
                        case "BYTE array":
                            desc["value"] = self.buf.rh(self.buf.unit)
                        case "BOOL":
                            desc["value"] = bool(self.buf.ru32l())
                        case "DWORD":
                            desc["value"] = self.buf.ru32l()
                        case "QWORD":
                            desc["value"] = self.buf.ru64l()
                        case "WORD":
                            desc["value"] = self.buf.ru16l()
                        case _:
                            desc["unknown"] = True

                    self.buf.skipunit()
                    self.buf.popunit()

                    obj["data"]["content-descriptors"].append(desc)
            case "b7dc0791-a9b7-11cf-8ee6-00c00c205365":
                obj["name"] = "Stream Properties Object"

                temp = self.buf.rguid()
                obj["data"]["stream-type"] = {
                    "raw": temp,
                    "name": {
                        "bc19efc0-5b4d-11cf-a8fd-00805f5c442b": "Video Media",
                        "f8699e40-5b4d-11cf-a8fd-00805f5c442b": "Audio Media",
                    }.get(temp, "Unknown"),
                }

                temp = self.buf.rguid()
                obj["data"]["ecc-type"] = {
                    "raw": temp,
                    "name": {
                        "20fb5700-5b55-11cf-a8fd-00805f5c442b": "No Error Correction",
                        "bfc3cd50-618f-11cf-8bb2-00aa00b4e220": "Audio Spread",
                    }.get(temp, "Unknown"),
                }

                obj["data"]["time-offset"] = self.buf.ru64l()
                obj["data"]["type-specific-data-length"] = self.buf.ru32l()
                obj["data"]["ecc-data-length"] = self.buf.ru32l()

                flags = self.buf.ru16l()
                obj["data"]["flags"] = {
                    "raw": flags,
                    "stream-number": flags & 0x7f,
                    "encrypted": bool(flags & (1 << 15)),
                }

                obj["data"]["reserved"] = self.buf.ru32l()

                self.buf.pushunit()
                self.buf.setunit(obj["data"]["type-specific-data-length"])

                match obj["data"]["stream-type"]["name"]:
                    case "Video Media":
                        obj["data"]["type-specific-data"] = {}
                        obj["data"]["type-specific-data"]["image-width"] = (
                            self.buf.ru32l()
                        )
                        obj["data"]["type-specific-data"]["image-height"] = (
                            self.buf.ru32l()
                        )
                        obj["data"]["type-specific-data"]["reserved"] = self.buf.ru8()
                        obj["data"]["type-specific-data"]["format-data-length"] = (
                            self.buf.ru16l()
                        )

                        obj["data"]["type-specific-data"]["format-data"] = {}
                        obj["data"]["type-specific-data"]["format-data"][
                            "format-data-length"
                        ] = self.buf.ru32l()
                        obj["data"]["type-specific-data"]["format-data"][
                            "image-width"
                        ] = self.buf.ru32l()
                        obj["data"]["type-specific-data"]["format-data"][
                            "image-height"
                        ] = self.buf.ru32l()
                        obj["data"]["type-specific-data"]["format-data"]["reserved"] = (
                            self.buf.ru16l()
                        )
                        obj["data"]["type-specific-data"]["format-data"][
                            "bits-per-pixel"
                        ] = self.buf.ru16l()
                        obj["data"]["type-specific-data"]["format-data"][
                            "compression-id"
                        ] = self.buf.rs(4)
                        obj["data"]["type-specific-data"]["format-data"][
                            "image-size"
                        ] = self.buf.ru32l()
                        obj["data"]["type-specific-data"]["format-data"][
                            "horiz-pixels-per-meter"
                        ] = self.buf.ru32l()
                        obj["data"]["type-specific-data"]["format-data"][
                            "vert-pixels-per-meter"
                        ] = self.buf.ru32l()
                        obj["data"]["type-specific-data"]["format-data"][
                            "colors-used"
                        ] = self.buf.ru32l()
                        obj["data"]["type-specific-data"]["format-data"][
                            "important-colors"
                        ] = self.buf.ru32l()
                        obj["data"]["type-specific-data"]["format-data"][
                            "codec-specific-data"
                        ] = self.buf.rh(self.buf.unit)
                    case "Audio Media":
                        obj["data"]["type-specific-data"] = {}
                        obj["data"]["type-specific-data"]["codec-id"] = self.buf.ru16l()
                        obj["data"]["type-specific-data"]["channel-count"] = (
                            self.buf.ru16l()
                        )
                        obj["data"]["type-specific-data"]["samples-per-second"] = (
                            self.buf.ru32l()
                        )
                        obj["data"]["type-specific-data"]["avg-bytes-per-second"] = (
                            self.buf.ru32l()
                        )
                        obj["data"]["type-specific-data"]["block-alignment"] = (
                            self.buf.ru16l()
                        )
                        obj["data"]["type-specific-data"]["bits-per-sample"] = (
                            self.buf.ru16l()
                        )
                        obj["data"]["type-specific-data"]["codec-specific-data"] = (
                            self.buf.rh(self.buf.ru16l())
                        )
                    case _:
                        obj["data"]["type-specific-data"] = self.buf.rh(self.buf.unit)
                        obj["unknown"] = True

                self.buf.skipunit()
                self.buf.popunit()

                self.buf.pushunit()
                self.buf.setunit(obj["data"]["ecc-data-length"])

                match obj["data"]["ecc-type"]["name"]:
                    case "Audio Spread":
                        obj["data"]["ecc-data"] = {}
                        obj["data"]["ecc-data"]["span"] = self.buf.ru8()
                        obj["data"]["ecc-data"]["virtual-packet-length"] = (
                            self.buf.ru16l()
                        )
                        obj["data"]["ecc-data"]["virtual-channel-length"] = (
                            self.buf.ru16l()
                        )
                        obj["data"]["ecc-data"]["silence-data"] = self.buf.rh(
                            self.buf.ru16l()
                        )
                    case "No Error Correction":
                        obj["data"]["ecc-data"] = self.buf.rh(self.buf.unit)
                    case _:
                        obj["data"]["ecc-data"] = self.buf.rh(self.buf.unit)
                        obj["unknown"] = True

                self.buf.skipunit()
                self.buf.popunit()
            case "86d15240-311d-11d0-a3a4-00a0c90348f6":
                obj["name"] = "Codec List"
                obj["data"]["reserved"] = self.buf.rguid()
                obj["data"]["codec-entry-count"] = self.buf.ru32l()

                obj["data"]["codec-entries"] = []
                for i in range(0, obj["data"]["codec-entry-count"]):
                    codec = {}
                    codec["type"] = utils.unraw(
                        self.buf.ru16l(), 2, {1: "Audio", 2: "Video"}
                    )
                    codec["name"] = self.buf.rs(self.buf.ru16l() << 1, "utf16")
                    codec["description"] = self.buf.rs(self.buf.ru16l() << 1, "utf16")
                    codec["information"] = self.buf.rh(self.buf.ru16l())

                    obj["data"]["codec-entries"].append(codec)
            case "75b22636-668e-11cf-a6d9-00aa0062ce6c":
                obj["name"] = "Data"
                obj["data"]["file-guid"] = self.buf.rguid()
                obj["data"]["total-packet-count"] = self.buf.ru64l()
                obj["data"]["reserved"] = self.buf.ru16l()
            case "33000890-e5b1-11cf-89f4-00a0c90349cb":
                obj["name"] = "Simple Index"
                obj["data"]["file-guid"] = self.buf.rguid()
                obj["data"]["index-entry-time-interval"] = self.buf.ru64l()
                obj["data"]["max-packet-count"] = self.buf.ru32l()
                obj["data"]["index-entries-count"] = self.buf.ru32l()
            case _:
                obj["unknown"] = True

        self.buf.skipunit()
        self.buf.popunit()

        return obj

    def chew(self):
        meta = {}
        meta["type"] = "asf"

        meta["objects"] = []
        while self.buf.available() > 0:
            meta["objects"].append(self.read_object())

        return meta


@module.register
class SwfModule(module.RuminantModule):
    dev = True
    desc = "SWF Adobe Flash files."

    def identify(buf, ctx):
        return buf.peek(3) in (b"FWS", b"CWS", b"ZWS")

    def read_rect(
        self,
    ):
        res = {}
        res["nbits"] = self.buf.rb(5)
        res["x-min"] = self.buf.rb(res["nbits"])
        res["x-max"] = self.buf.rb(res["nbits"])
        res["y-min"] = self.buf.rb(res["nbits"])
        res["y-max"] = self.buf.rb(res["nbits"])
        self.buf.align()
        return res

    def read_matrix(self):
        mat = {}

        mat["has-scale"] = self.buf.rb(1)
        if mat["has-scale"]:
            mat["scale-bits"] = self.buf.rb(5)
            mat["scale-x"] = self.buf.rsb(mat["scale-bits"])
            mat["scale-y"] = self.buf.rsb(mat["scale-bits"])

        mat["has-rotate"] = self.buf.rb(1)
        if mat["has-rotate"]:
            mat["rotate-bits"] = self.buf.rb(5)
            mat["rotate-x"] = self.buf.rsb(mat["rotate-bits"])
            mat["rotate-y"] = self.buf.rsb(mat["rotate-bits"])

        mat["transform-bits"] = self.buf.rb(5)
        mat["transform-x"] = self.buf.rsb(mat["transform-bits"])
        mat["transform-y"] = self.buf.rsb(mat["transform-bits"])

        self.buf.align()
        return mat

    def read_color_transform(self, place_object_ver2=False):
        ct = {}

        ct["has-add"] = self.buf.rb(1)
        ct["has-mult"] = self.buf.rb(1)
        ct["bits"] = self.buf.rb(4)

        if ct["has-mult"]:
            ct["red-mult"] = self.buf.rsb(ct["bits"])
            ct["green-mult"] = self.buf.rsb(ct["bits"])
            ct["blue-mult"] = self.buf.rsb(ct["bits"])

            if place_object_ver2:
                ct["alpha-mult"] = self.buf.rsb(ct["bits"])

        if ct["has-add"]:
            ct["red-add"] = self.buf.rsb(ct["bits"])
            ct["green-add"] = self.buf.rsb(ct["bits"])
            ct["blue-add"] = self.buf.rsb(ct["bits"])

            if place_object_ver2:
                ct["alpha-add"] = self.buf.rsb(ct["bits"])

        self.buf.align()
        return ct

    def read_any_filter(self):
        # TODO: https://www.m2osw.com/swf_struct_any_filter

        filt = {}
        typ = self.buf.ru8()

        match typ:
            case _:
                raise ValueError(f"Unknown filter type {typ}")

        self.buf.align()
        return filt

    def read_tags(self):
        tags = []
        should_break = False

        while self.buf.available() >= 4 and not should_break:
            tag = {}
            temp = self.buf.ru16l()
            code = temp >> 6
            tag["length"] = temp & 0x3f

            if tag["length"] == 63:
                tag["length"] = self.buf.ru32l()

            self.buf.pasunit(tag["length"])

            tag["type"] = None
            tag["data"] = {}
            match code:
                case 0:
                    tag["type"] = "End"
                    should_break = True
                case 1:
                    tag["type"] = "ShowFrame"
                case 2:
                    tag["type"] = "DefineShape"
                    tag["data"]["id"] = self.buf.ru16l()
                    tag["data"]["fill-bits"] = self.buf.rb(4)
                    tag["data"]["line-bits"] = self.buf.rb(4)

                    tag["data"]["shapes"] = []
                    while True:
                        shape = {}

                        shape["type"] = self.buf.rb(1)

                        if shape["type"] == 0:
                            shape["reserved"] = self.buf.rb(0)
                            shape["has-line-style"] = self.buf.rb(1)
                            shape["has-fill-style1"] = self.buf.rb(1)
                            shape["has-fill-style0"] = self.buf.rb(1)
                            shape["has-move-to"] = self.buf.rb(1)

                            if not (
                                shape["reserved"]
                                or shape["has-line-style"]
                                or shape["has-fill-style1"]
                                or shape["has-fill-style0"]
                                or shape["has-move-to"]
                            ):
                                break

                            if shape["has-move-to"]:
                                shape["move-bits"] = self.buf.rb(5)
                                shape["move-x"] = self.buf.rsb(shape["move-bits"])
                                shape["move-y"] = self.buf.rsb(shape["move-bits"])

                            if shape["has-fill-style0"]:
                                shape["fill-style0"] = self.buf.rb(
                                    tag["data"]["fill-bits"]
                                )

                            if shape["has-fill-style1"]:
                                shape["fill-style1"] = self.buf.rb(
                                    tag["data"]["fill-bits"]
                                )

                            if shape["has-line-style"]:
                                shape["line-style"] = self.buf.rb(
                                    tag["data"]["line-bits"]
                                )
                        else:
                            shape["edge-type"] = self.buf.rb(1)
                            shape["coord-size"] = self.buf.rb(4) + 2

                            if shape["edge-type"] == 0:
                                shape["control-delta-x"] = self.buf.rsb(
                                    shape["coord-size"]
                                )
                                shape["control-delta-y"] = self.buf.rsb(
                                    shape["coord-size"]
                                )
                                shape["anchor-delta-x"] = self.buf.rsb(
                                    shape["coord-size"]
                                )
                                shape["anchor-delta-y"] = self.buf.rsb(
                                    shape["coord-size"]
                                )
                            else:
                                shape["has-x-and-y"] = self.buf.rb(1)

                                if shape["has-x-and-y"]:
                                    shape["delta-x"] = self.buf.rsb(shape["coord-size"])
                                    shape["delta-y"] = self.buf.rsb(shape["coord-size"])
                                else:
                                    shape["has-x-or-y"] = self.buf.rb(1)

                                    if shape["has-x-or-y"]:
                                        shape["delta-x"] = self.buf.rsb(
                                            shape["coord-size"]
                                        )
                                    else:
                                        shape["delta-y"] = self.buf.rsb(
                                            shape["coord-size"]
                                        )

                        tag["data"]["shapes"].append(shape)

                    self.buf.align()

                case 9:
                    tag["type"] = "SetBackgroundColor"
                    tag["data"]["red"] = self.buf.ru8()
                    tag["data"]["green"] = self.buf.ru8()
                    tag["data"]["blue"] = self.buf.ru8()
                case 26:
                    tag["type"] = "PlaceObject2"

                    if self.version >= 8 and code == 70:
                        tag["data"]["reserved-ver8"] = self.buf.rb(5)
                        tag["data"]["place-bitmap-caching"] = self.buf.rb(1)
                        tag["data"]["place-blend-mode"] = self.buf.rb(1)
                        tag["data"]["place-filters"] = self.buf.rb(1)

                    if self.version >= 5:
                        tag["data"]["has-actions"] = self.buf.rb(1)
                    else:
                        tag["data"]["reserved-ver5"] = self.buf.rb(1)

                    tag["data"]["has-clipping-depth"] = self.buf.rb(1)
                    tag["data"]["has-name"] = self.buf.rb(1)
                    tag["data"]["has-morph-position"] = self.buf.rb(1)
                    tag["data"]["has-color-transform"] = self.buf.rb(1)
                    tag["data"]["has-matrix"] = self.buf.rb(1)
                    tag["data"]["has-id-ref"] = self.buf.rb(1)
                    tag["data"]["has-move"] = self.buf.rb(1)
                    tag["data"]["depth"] = self.buf.ru16l()

                    if tag["data"]["has-id-ref"]:
                        tag["data"]["object-id-ref"] = self.buf.ru16l()

                    if tag["data"]["has-matrix"]:
                        tag["data"]["matrix"] = self.read_matrix()

                    if tag["data"]["has-color-transform"]:
                        tag["data"]["color-transform"] = self.read_color_transform(
                            code == 26
                        )

                    if tag["data"]["has-morph-position"]:
                        tag["data"]["morph-position"] = self.buf.ru16l()

                    if tag["data"]["has-name"]:
                        tag["data"]["name"] = self.buf.rzs()

                    if tag["data"]["has-clipping-depth"]:
                        tag["data"]["clipping-depth"] = self.buf.ru16l()

                    self.buf.align()
                case 39:
                    tag["type"] = "DefineSprite"
                    tag["data"]["sprite-id"] = self.buf.ru16l()
                    tag["data"]["frame-count"] = self.buf.ru16l()
                    tag["data"]["tags"] = self.read_tags()
                case 69:
                    tag["type"] = "FileAttributes"
                    tag["data"]["reserved1"] = self.buf.rb(1)
                    tag["data"]["use-direct-blit"] = self.buf.rb(1)
                    tag["data"]["use-gpu"] = self.buf.rb(1)
                    tag["data"]["has-metadata"] = self.buf.rb(1)
                    tag["data"]["actionscript-3"] = self.buf.rb(1)
                    tag["data"]["reserved2"] = self.buf.rb(2)
                    tag["data"]["use-network"] = self.buf.rb(1)
                    tag["data"]["reserved3"] = self.buf.rb(24)
                case 86:
                    tag["type"] = "DefineSceneAndFrameLabelData"

                    tag["data"]["scenes"] = []
                    for i in range(0, self.buf.ruleb()):
                        scene = {}
                        scene["frame-offset"] = self.buf.ruleb()
                        scene["name"] = self.buf.rzs()

                        tag["data"]["scenes"].append(scene)

                    tag["data"]["frame-labels"] = []
                    for i in range(0, self.buf.ruleb()):
                        label = {}
                        label["frame-number"] = self.buf.ruleb()
                        label["name"] = self.buf.rzs()

                        tag["data"]["frame-labels"].append(label)
                case _:
                    tag["type"] = f"Unknown ({code})"
                    tag["unknown"] = True

            self.buf.sapunit()
            tags.append(tag)

        return tags

    def chew(self):
        meta = {}
        meta["type"] = "swf"

        meta["compression"] = {"FWS": "none", "CWS": "zlib", "ZWS": "lzma"}[
            self.buf.rs(3)
        ]

        meta["version"] = self.buf.ru8()
        self.version = meta["version"]

        meta["decompressed-length"] = self.buf.ru32l()

        match meta["compression"]:
            case "none":
                pass
            case "zlib":
                fd = utils.tempfd()
                utils.stream_zlib(self.buf, fd, self.buf.available(), revert=True)
                self.buf = Buf(fd)
                self.buf.seek(0)
            case "lzma":
                fd = utils.tempfd()
                utils.stream_xz(self.buf, fd, self.buf.available())
                self.buf = Buf(fd)
                self.buf.seek(0)
            case _:
                raise ValueError("Unknown compression")

        meta["frame-size"] = self.read_rect()
        meta["frame-rate"] = self.buf.rfp16l()
        meta["frame-count"] = self.buf.ru16l()

        meta["tags"] = self.read_tags()

        return meta


@module.register
class DuckIvfModule(module.RuminantModule):
    desc = "Duck IVF video files."

    def identify(buf, ctx):
        return buf.peek(4) == b"DKIF"

    def chew(self):
        meta = {}
        meta["type"] = "duck-ivf"

        self.buf.skip(4)
        meta["version"] = self.buf.ru16l()
        meta["header-length"] = self.buf.ru16l()

        self.buf.pasunit(meta["header-length"] - 8)

        meta["format"] = self.buf.rs(4)
        meta["width"] = self.buf.ru16l()
        meta["height"] = self.buf.ru16l()
        d = self.buf.ru32l()
        n = self.buf.ru32l()
        meta["time-base"] = {"value": n / d, "denominator": d, "numerator": n}
        meta["frame-count"] = self.buf.ru32l()
        meta["unused"] = self.buf.ru32l()

        self.buf.sapunit()

        for i in range(0, meta["frame-count"]):
            self.buf.skip(self.buf.ru32l() + 8)

        return meta
