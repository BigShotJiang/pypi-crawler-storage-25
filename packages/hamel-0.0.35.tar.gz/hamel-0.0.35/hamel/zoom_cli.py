"""CLI for Zoom transcript downloads. Delegates to hamel.zoom.main."""

import typer
from hamel.zoom import main as zoom_main

app = typer.Typer()
app.command()(zoom_main)

def main():
    app()
