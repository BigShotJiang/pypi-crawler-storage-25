"""Unified X (Twitter) CLI — all commands use the official X API v2 with Bearer Token.

Commands:
  - resolve: Resolve a username to a user ID
  - fetch: Snapshot the following list for an X account
  - diff: Compare two following-list snapshots
  - latest-post: Fetch the most recent post for an account
  - likes: Fetch liked tweets for a user
  - bookmarks: Fetch your bookmarked tweets
  - screenshot: Take a screenshot of a tweet
"""

import json
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx
import typer
from rich.console import Console
from typing_extensions import Annotated

console = Console(stderr=True)

# ---------------------------------------------------------------------------
# X API v2 constants and helpers
# ---------------------------------------------------------------------------

X_API_BASE = "https://api.x.com/2"
_USERNAME_RE = re.compile(r'^[A-Za-z0-9_]{1,15}$')


def _validate_username(username: str) -> str:
    """Validate and return a sanitized X username."""
    username = username.lstrip("@").strip()
    if not _USERNAME_RE.match(username):
        console.print(f"[red]Error: Invalid X username: {username!r}[/red]")
        console.print("[dim]Usernames must be 1-15 alphanumeric characters or underscores.[/dim]")
        raise typer.Exit(1)
    return username


USER_FIELDS = "id,username,name,created_at,description,public_metrics,profile_image_url,protected"
TWEET_FIELDS = "id,text,created_at,author_id,public_metrics,entities,note_tweet"
DEFAULT_SNAPSHOT_DIR = Path.home() / ".x"

# Default username for likes/bookmarks commands.
# Override via the X_DEFAULT_USERNAME environment variable, or pass a username argument.
_FALLBACK_USERNAME = "HamelHusain"
DEFAULT_X_USERNAME = os.environ.get("X_DEFAULT_USERNAME", "").strip() or _FALLBACK_USERNAME


def _get_bearer_token() -> str:
    """Get Bearer Token from env var, exit with a clear error if missing."""
    token = os.environ.get("X_BEARER_TOKEN", "").strip()
    if not token:
        console.print("[bold red]Error: X_BEARER_TOKEN environment variable is not set.[/bold red]")
        console.print("")
        console.print("[yellow]This command requires an X (Twitter) API Bearer Token.[/yellow]")
        console.print("[yellow]The token must be set as an environment variable named X_BEARER_TOKEN.[/yellow]")
        console.print("")
        console.print("[bold]How to get a Bearer Token:[/bold]")
        console.print("  1. Go to https://developer.x.com/en/portal/dashboard")
        console.print("  2. Create or select a project/app")
        console.print("  3. Under 'Keys and Tokens', generate or copy your Bearer Token")
        console.print("")
        console.print("[bold]Then set it in your shell:[/bold]")
        console.print("  export X_BEARER_TOKEN='your_token_here'")
        console.print("")
        console.print("[dim]Tip: Add the export line to your ~/.bashrc or ~/.zshrc to persist it.[/dim]")
        raise typer.Exit(1)
    return token


def _get_user_access_token() -> str:
    """Get OAuth 2.0 user access token for endpoints that require user-context auth.

    Required for likes and bookmarks endpoints which do not support app-only
    Bearer Tokens.
    """
    token = os.environ.get("X_ACCESS_TOKEN", "").strip()
    if not token:
        console.print("[bold red]Error: X_ACCESS_TOKEN environment variable is not set.[/bold red]")
        console.print("")
        console.print("[yellow]This command requires an OAuth 2.0 user access token.[/yellow]")
        console.print("[yellow]App-only Bearer Tokens (X_BEARER_TOKEN) are not supported for[/yellow]")
        console.print("[yellow]likes and bookmarks endpoints.[/yellow]")
        console.print("")
        console.print("[bold]How to get a user access token:[/bold]")
        console.print("  1. Go to https://developer.x.com/en/portal/dashboard")
        console.print("  2. In your app settings, enable OAuth 2.0")
        console.print("  3. Complete the OAuth 2.0 Authorization Code Flow with PKCE")
        console.print("  4. See: https://docs.x.com/fundamentals/authentication/oauth-2-0/authorization-code")
        console.print("")
        console.print("[bold]Then set it in your shell:[/bold]")
        console.print("  export X_ACCESS_TOKEN='your_user_access_token_here'")
        console.print("")
        console.print("[dim]Tip: Also set X_REFRESH_TOKEN if you have one, for future token refresh support.[/dim]")
        raise typer.Exit(1)
    return token


def _auth_headers(token: str) -> dict:
    """Build API headers with a Bearer token (app-only or user-context OAuth 2.0)."""
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


def _handle_rate_limit(response: httpx.Response, verbose: bool = False) -> None:
    """Check for rate limiting and wait if needed."""
    if response.status_code == 429:
        reset_time = response.headers.get("x-rate-limit-reset")
        if reset_time:
            wait_seconds = max(int(reset_time) - int(time.time()), 1)
            if verbose:
                console.print(f"[yellow]Rate limited. Waiting {wait_seconds}s...[/yellow]")
            time.sleep(wait_seconds + 1)
        else:
            if verbose:
                console.print("[yellow]Rate limited. Waiting 60s...[/yellow]")
            time.sleep(60)


def _api_get(client: httpx.Client, url: str, params: dict, headers: dict,
             verbose: bool = False) -> dict:
    """Make a GET request with rate-limit retry.

    Retries only on 429 (rate limit). All other errors exit immediately.
    """
    max_rate_limit_waits = 5
    rate_limit_waits = 0
    response: Optional[httpx.Response] = None
    while rate_limit_waits < max_rate_limit_waits:
        try:
            response = client.get(url, params=params, headers=headers)
        except httpx.RequestError as exc:
            console.print("[bold red]Error: Network request failed.[/bold red]")
            console.print(f"[yellow]{type(exc).__name__}: {exc}[/yellow]")
            console.print("[dim]Check your internet connection and try again.[/dim]")
            raise typer.Exit(1)
        if response.status_code == 429:
            rate_limit_waits += 1
            _handle_rate_limit(response, verbose)
            continue
        if response.status_code == 401:
            is_user_auth = "/liked_tweets" in url or "/bookmarks" in url
            console.print("[bold red]Error: Authentication failed (HTTP 401 Unauthorized).[/bold red]")
            console.print("")
            if is_user_auth:
                console.print("[yellow]Your X_ACCESS_TOKEN is invalid, expired, or revoked.[/yellow]")
                console.print("[yellow]OAuth 2.0 access tokens expire after ~2 hours.[/yellow]")
                console.print("")
                console.print("[bold]To fix this:[/bold]")
                console.print("  1. Re-run the OAuth 2.0 PKCE flow to get a new access token")
                console.print("  2. Update your environment: export X_ACCESS_TOKEN='new_token_here'")
                console.print("")
                console.print("  See: https://docs.x.com/fundamentals/authentication/oauth-2-0/authorization-code")
            else:
                console.print("[yellow]Your X_BEARER_TOKEN is invalid, expired, or revoked.[/yellow]")
                console.print("")
                console.print("[bold]To fix this:[/bold]")
                console.print("  1. Go to https://developer.x.com/en/portal/dashboard")
                console.print("  2. Select your project/app")
                console.print("  3. Under 'Keys and Tokens', regenerate your Bearer Token")
                console.print("  4. Update your environment: export X_BEARER_TOKEN='new_token_here'")
            raise typer.Exit(1)
        if response.status_code == 403:
            is_likes = "/liked_tweets" in url
            is_bookmarks = "/bookmarks" in url
            console.print("[bold red]Error: Access forbidden (HTTP 403).[/bold red]")
            console.print("")
            console.print(f"[dim]Endpoint: {url}[/dim]")
            console.print("")
            if is_likes or is_bookmarks:
                endpoint_name = "likes" if is_likes else "bookmarks"
                console.print(f"[yellow]The {endpoint_name} endpoint requires OAuth 2.0 User Context auth.[/yellow]")
                console.print("[yellow]App-only Bearer Tokens are not supported for this endpoint.[/yellow]")
                console.print("")
                console.print("[bold]To fix this:[/bold]")
                console.print("  The likes and bookmarks endpoints require OAuth 2.0 Authorization")
                console.print("  Code Flow with PKCE (user-context auth), not app-only Bearer Token.")
                console.print("")
                console.print("  Required OAuth 2.0 scopes:")
                if is_bookmarks:
                    console.print("    - bookmark.read")
                else:
                    console.print("    - like.read")
                console.print("    - tweet.read")
                console.print("    - users.read")
                console.print("")
                console.print("  See: https://docs.x.com/fundamentals/authentication/oauth-2-0/authorization-code")
            else:
                console.print("[yellow]Your app may not have the required permissions for this endpoint.[/yellow]")
                console.print("")
                console.print("[bold]To fix this:[/bold]")
                console.print("  1. Go to https://developer.x.com/en/portal/dashboard")
                console.print("  2. Check your app's access level (must be at least 'Basic')")
                console.print("  3. Ensure your app has Read permissions enabled")
            raise typer.Exit(1)
        if response.status_code != 200:
            error_body = response.text
            console.print(f"[bold red]API error (HTTP {response.status_code}):[/bold red]")
            console.print(f"[red]{error_body}[/red]")
            raise typer.Exit(1)
        return response.json()
    console.print("[bold red]Error: Max retries exceeded due to rate limiting.[/bold red]")
    console.print("[yellow]The X API rate limit has been hit repeatedly. Try again later.[/yellow]")
    if response is not None:
        remaining = response.headers.get("x-rate-limit-reset")
        if remaining:
            console.print(f"[dim]Rate limit resets at Unix timestamp: {remaining}[/dim]")
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Core API functions
# ---------------------------------------------------------------------------

def resolve_username(username: str, bearer_token: str, verbose: bool = False) -> dict:
    """Resolve a username to user data via X API v2."""
    with httpx.Client(timeout=30.0) as client:
        data = _api_get(
            client,
            f"{X_API_BASE}/users/by/username/{username}",
            params={"user.fields": USER_FIELDS},
            headers=_auth_headers(bearer_token),
            verbose=verbose,
        )
    if "data" not in data:
        errors = data.get("errors", [])
        detail = errors[0].get("detail", "Unknown error") if errors else "User not found"
        console.print(f"[red]Error resolving @{username}: {detail}[/red]")
        raise typer.Exit(1)
    return data["data"]


def fetch_following(user_id: str, bearer_token: str, verbose: bool = False,
                    max_accounts: int = 50_000) -> list[dict]:
    """Fetch the full following list for a user, handling pagination."""
    following: list[dict] = []
    pagination_token = None

    with httpx.Client(timeout=30.0) as client:
        while len(following) < max_accounts:
            params: dict = {
                "max_results": 1000,
                "user.fields": USER_FIELDS,
            }
            if pagination_token:
                params["pagination_token"] = pagination_token

            data = _api_get(
                client,
                f"{X_API_BASE}/users/{user_id}/following",
                params=params,
                headers=_auth_headers(bearer_token),
                verbose=verbose,
            )

            page_users = data.get("data", [])
            following.extend(page_users)

            if verbose:
                console.print(f"[dim]  Fetched {len(following)} accounts so far...[/dim]")

            meta = data.get("meta", {})
            pagination_token = meta.get("next_token")
            if not pagination_token:
                break

    return following


def fetch_user_tweets(
    user_id: str,
    bearer_token: str,
    max_results: int = 5,
    end_time: Optional[str] = None,
    until_id: Optional[str] = None,
    verbose: bool = False,
) -> list[dict]:
    """Fetch recent tweets for a user with optional time/ID filters.

    Args:
        user_id: X user ID.
        bearer_token: API bearer token.
        max_results: Number of tweets to request (5-100).
        end_time: ISO 8601 datetime — only tweets before this time are returned.
        until_id: Post ID — only tweets with IDs older (lower) than this are returned.
        verbose: Print progress info to stderr.

    Returns:
        List of tweet dicts (may be empty).
    """
    with httpx.Client(timeout=30.0) as client:
        params: dict = {
            "max_results": max_results,
            "tweet.fields": TWEET_FIELDS,
            "exclude": "retweets,replies",
        }
        if end_time:
            params["end_time"] = end_time
        if until_id:
            params["until_id"] = until_id
        data = _api_get(
            client,
            f"{X_API_BASE}/users/{user_id}/tweets",
            params=params,
            headers=_auth_headers(bearer_token),
            verbose=verbose,
        )

    return data.get("data", [])


def _fetch_tweets_paginated(
    endpoint_url: str,
    access_token: str,
    max_results: int = 100,
    verbose: bool = False,
    label: str = "tweets",
) -> list[dict]:
    """Fetch tweets from a paginated endpoint (likes or bookmarks).

    Handles pagination, author expansion, and the X API's min page size of 5.
    Requires an OAuth 2.0 user access token (not app-only Bearer Token).
    """
    all_tweets: list[dict] = []
    pagination_token = None

    with httpx.Client(timeout=30.0) as client:
        while True:
            # X API requires max_results between 5 and 100
            page_size = max(min(max_results - len(all_tweets), 100), 5)
            params: dict = {
                "max_results": page_size,
                "tweet.fields": TWEET_FIELDS,
                "expansions": "author_id",
                "user.fields": "id,username,name",
            }
            if pagination_token:
                params["pagination_token"] = pagination_token

            data = _api_get(
                client,
                endpoint_url,
                params=params,
                headers=_auth_headers(access_token),
                verbose=verbose,
            )

            tweets = data.get("data", [])
            includes = data.get("includes", {})
            author_lookup = {u["id"]: u for u in includes.get("users", [])}

            for tweet in tweets:
                author_id = tweet.get("author_id", "")
                author = author_lookup.get(author_id, {})
                tweet["_author"] = {
                    "id": author_id,
                    "username": author.get("username", ""),
                    "name": author.get("name", ""),
                }

            all_tweets.extend(tweets)

            if verbose:
                console.print(f"[dim]  Fetched {len(all_tweets)} {label} so far...[/dim]")

            if len(all_tweets) >= max_results:
                break

            meta = data.get("meta", {})
            pagination_token = meta.get("next_token")
            if not pagination_token:
                break

    return all_tweets[:max_results]


def fetch_liked_tweets(
    user_id: str,
    access_token: str,
    max_results: int = 100,
    verbose: bool = False,
) -> list[dict]:
    """Fetch liked tweets for a user via X API v2, handling pagination."""
    return _fetch_tweets_paginated(
        f"{X_API_BASE}/users/{user_id}/liked_tweets",
        access_token, max_results, verbose, label="liked tweets",
    )


def fetch_bookmarks_list(
    user_id: str,
    access_token: str,
    max_results: int = 100,
    verbose: bool = False,
) -> list[dict]:
    """Fetch bookmarked tweets for the authenticated user via X API v2."""
    return _fetch_tweets_paginated(
        f"{X_API_BASE}/users/{user_id}/bookmarks",
        access_token, max_results, verbose, label="bookmarks",
    )


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _snapshot_path(username: str, snapshot_dir: Path, timestamp: Optional[str] = None) -> Path:
    """Generate a snapshot file path."""
    if timestamp is None:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    return snapshot_dir / f"{username}_{timestamp}.json"


def _format_post(post: dict, username: str) -> dict:
    """Format a post for output."""
    post_id = post.get("id", "")
    text = post.get("text", "")
    note = post.get("note_tweet", {})
    if note and note.get("text"):
        text = note["text"]
    return {
        "post_id": post_id,
        "text": text,
        "created_at": post.get("created_at", ""),
        "url": f"https://x.com/{username}/status/{post_id}",
        "public_metrics": post.get("public_metrics", {}),
    }


def _format_liked_tweet(tweet: dict) -> dict:
    """Format a liked/bookmarked tweet for output."""
    post_id = tweet.get("id", "")
    text = tweet.get("text", "")
    note = tweet.get("note_tweet", {})
    if note and note.get("text"):
        text = note["text"]
    author = tweet.get("_author", {})
    author_username = author.get("username", "")
    return {
        "id": post_id,
        "text": text,
        "created_at": tweet.get("created_at", ""),
        "author": {
            "id": author.get("id", ""),
            "username": author_username,
            "name": author.get("name", ""),
        },
        "public_metrics": tweet.get("public_metrics", {}),
        "url": f"https://x.com/{author_username}/status/{post_id}" if author_username else "",
    }


def _user_summary(user: dict) -> dict:
    """Extract a summary dict from a user object."""
    return {
        "id": user.get("id", ""),
        "username": user.get("username", ""),
        "name": user.get("name", ""),
        "description": user.get("description", ""),
        "public_metrics": user.get("public_metrics", {}),
    }


# ---------------------------------------------------------------------------
# CLI definition
# ---------------------------------------------------------------------------

app = typer.Typer(
    help="X (Twitter) CLI — follow tracking, likes, bookmarks, and more.\n\n"
         "All commands use the official X API v2 with a Bearer Token.\n"
         "Set the X_BEARER_TOKEN environment variable before use.",
    no_args_is_help=True,
)


@app.command()
def resolve(
    username: Annotated[str, typer.Argument(help="X username to resolve (without @)")],
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Resolve a username to a user ID and display profile info."""
    username = _validate_username(username)
    bearer = _get_bearer_token()
    user = resolve_username(username, bearer, verbose)

    output = {
        "id": user["id"],
        "username": user["username"],
        "name": user.get("name", ""),
        "created_at": user.get("created_at", ""),
        "description": user.get("description", ""),
        "public_metrics": user.get("public_metrics", {}),
        "protected": user.get("protected", False),
        "profile_image_url": user.get("profile_image_url", ""),
    }
    print(json.dumps(output, indent=2, ensure_ascii=False))


@app.command()
def fetch(
    username: Annotated[str, typer.Argument(help="X username whose following list to fetch")],
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Output file path (default: auto-generated in ~/.x/)")] = None,
    snapshot_dir: Annotated[Optional[str], typer.Option("--dir", "-d", help="Snapshot directory (default: ~/.x/)")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Fetch and store the following list for an X account.

    Creates a JSON snapshot containing the full following list with user IDs,
    usernames, and metadata. Snapshots can be compared with 'xapi diff'.
    """
    username = _validate_username(username)
    bearer = _get_bearer_token()
    sdir = Path(snapshot_dir) if snapshot_dir else DEFAULT_SNAPSHOT_DIR

    if verbose:
        console.print(f"[cyan]Resolving @{username}...[/cyan]")

    user = resolve_username(username, bearer, verbose)
    user_id = user["id"]

    if verbose:
        console.print(f"[cyan]User ID: {user_id}[/cyan]")
        console.print(f"[cyan]Fetching following list for @{username}...[/cyan]")

    following = fetch_following(user_id, bearer, verbose)

    now = datetime.now(timezone.utc)
    timestamp = now.strftime("%Y%m%d_%H%M%S")
    snapshot = {
        "watched_username": username,
        "watched_user_id": user_id,
        "fetch_timestamp": now.isoformat(),
        "following_count": len(following),
        "following": sorted(following, key=lambda u: u.get("username", "").lower()),
    }

    if output:
        out_path = Path(output)
    else:
        out_path = _snapshot_path(username, sdir, timestamp)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(snapshot, f, indent=2, ensure_ascii=False)

    if verbose:
        console.print(f"[green]Fetched {len(following)} accounts[/green]")

    console.print(f"[green]Snapshot saved: {out_path}[/green]")
    print(str(out_path))


@app.command()
def diff(
    snapshot_a: Annotated[str, typer.Argument(help="Path to the older snapshot (before)")],
    snapshot_b: Annotated[str, typer.Argument(help="Path to the newer snapshot (after)")],
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Output file path (default: stdout)")] = None,
    fetch_posts: Annotated[bool, typer.Option("--fetch-posts", "-p", help="Fetch latest post for each unfollowed account (uses snapshot_b timestamp as cutoff)")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Compare two following-list snapshots and show new follows / unfollows.

    Snapshot A is treated as the older/before state, B as the newer/after state.
    New follows = in B but not in A. Unfollows = in A but not in B.

    With --fetch-posts, fetches the latest post *before* snapshot B's timestamp
    for each unfollowed account (to see what they posted before being unfollowed).
    """
    path_a, path_b = Path(snapshot_a), Path(snapshot_b)

    for p in (path_a, path_b):
        if not p.exists():
            console.print(f"[red]Error: Snapshot not found: {p}[/red]")
            raise typer.Exit(1)

    with open(path_a, "r") as f:
        snap_a = json.load(f)
    with open(path_b, "r") as f:
        snap_b = json.load(f)

    users_a = {u["id"]: u for u in snap_a["following"]}
    users_b = {u["id"]: u for u in snap_b["following"]}

    ids_a = set(users_a.keys())
    ids_b = set(users_b.keys())

    new_follow_ids = ids_b - ids_a
    unfollow_ids = ids_a - ids_b

    new_follows = [_user_summary(users_b[uid]) for uid in sorted(new_follow_ids)]
    unfollows = [_user_summary(users_a[uid]) for uid in sorted(unfollow_ids)]

    result: dict = {
        "snapshot_before": {
            "file": str(path_a),
            "watched_username": snap_a.get("watched_username", ""),
            "fetch_timestamp": snap_a.get("fetch_timestamp", ""),
            "following_count": snap_a.get("following_count", len(users_a)),
        },
        "snapshot_after": {
            "file": str(path_b),
            "watched_username": snap_b.get("watched_username", ""),
            "fetch_timestamp": snap_b.get("fetch_timestamp", ""),
            "following_count": snap_b.get("following_count", len(users_b)),
        },
        "new_follows_count": len(new_follows),
        "unfollows_count": len(unfollows),
        "new_follows": new_follows,
        "unfollows": unfollows,
    }

    if fetch_posts and unfollows:
        bearer = _get_bearer_token()
        # Use the newer snapshot's fetch_timestamp as cutoff — the unfollowed user's
        # last post *before* the unfollow was detected.
        cutoff_time = snap_b.get("fetch_timestamp")
        if verbose:
            console.print(f"[cyan]Fetching latest posts for {len(unfollows)} unfollowed accounts...[/cyan]")
            if cutoff_time:
                console.print(f"[dim]  Using cutoff: {cutoff_time}[/dim]")
        for entry in result["unfollows"]:
            uid = entry["id"]
            uname = entry["username"]
            if verbose:
                console.print(f"[dim]  Fetching latest post for @{uname}...[/dim]")
            tweets = fetch_user_tweets(uid, bearer, max_results=5, end_time=cutoff_time, verbose=verbose)
            if tweets:
                entry["latest_post"] = _format_post(tweets[0], uname)
            else:
                entry["latest_post"] = None

    output_json = json.dumps(result, indent=2, ensure_ascii=False)

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(output_json)
        if verbose:
            console.print(f"[green]Diff saved to {output}[/green]")
    else:
        print(output_json)

    console.print(f"\n[bold]Diff: @{snap_a.get('watched_username', '?')}[/bold]")
    console.print(f"  Before: {snap_a.get('fetch_timestamp', '?')} ({snap_a.get('following_count', '?')} following)")
    console.print(f"  After:  {snap_b.get('fetch_timestamp', '?')} ({snap_b.get('following_count', '?')} following)")
    if new_follows:
        console.print(f"\n  [green]+{len(new_follows)} new follows:[/green]")
        for u in new_follows:
            console.print(f"    [green]+ @{u['username']}[/green] ({u['name']})")
    if unfollows:
        console.print(f"\n  [red]-{len(unfollows)} unfollows:[/red]")
        for u in unfollows:
            console.print(f"    [red]- @{u['username']}[/red] ({u['name']})")
    if not new_follows and not unfollows:
        console.print("\n  [dim]No changes detected.[/dim]")


@app.command(name="latest-post")
def latest_post(
    username: Annotated[str, typer.Argument(help="X username to fetch the latest post for")],
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Output file path (default: stdout)")] = None,
    before: Annotated[Optional[str], typer.Option("--before", help="ISO 8601 datetime cutoff — only posts before this time (e.g. 2026-01-15T00:00:00Z)")] = None,
    before_post: Annotated[Optional[str], typer.Option("--before-post", help="Post ID cutoff — only posts older than this post ID")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Fetch the most recent post for an X account.

    Useful for inspecting what an unfollowed account last posted.
    Excludes retweets and replies to show original content.

    Use --before to get the latest post before a specific timestamp.
    Use --before-post to get the latest post older than a specific post ID.
    """
    username = _validate_username(username)
    bearer = _get_bearer_token()

    if verbose:
        console.print(f"[cyan]Resolving @{username}...[/cyan]")

    user = resolve_username(username, bearer, verbose)
    user_id = user["id"]

    if verbose:
        console.print(f"[cyan]Fetching latest post for @{username} (ID: {user_id})...[/cyan]")
        if before:
            console.print(f"[dim]  Cutoff time: {before}[/dim]")
        if before_post:
            console.print(f"[dim]  Before post ID: {before_post}[/dim]")

    tweets = fetch_user_tweets(
        user_id,
        bearer,
        max_results=5,
        end_time=before,
        until_id=before_post,
        verbose=verbose,
    )

    if not tweets:
        console.print(f"[yellow]No recent posts found for @{username}.[/yellow]")
        raise typer.Exit(0)

    post = tweets[0]
    result = _format_post(post, username)
    output_json = json.dumps(result, indent=2, ensure_ascii=False)

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(output_json)
        if verbose:
            console.print(f"[green]Saved to {output}[/green]")
    else:
        print(output_json)


@app.command()
def likes(
    username: Annotated[Optional[str], typer.Argument(help="X username whose liked tweets to fetch (default: X_DEFAULT_USERNAME or HamelHusain)")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Output file path (default: stdout)")] = None,
    limit: Annotated[int, typer.Option("--limit", "-n", help="Maximum number of tweets to fetch")] = 100,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Fetch liked tweets for a user via the X API v2.

    Requires X_ACCESS_TOKEN (OAuth 2.0 user access token).
    Also uses X_BEARER_TOKEN to resolve the username.
    Default username: HamelHusain (override by passing a different username).
    """
    username = _validate_username(username or DEFAULT_X_USERNAME)
    bearer = _get_bearer_token()
    access_token = _get_user_access_token()

    if verbose:
        console.print(f"[cyan]Resolving @{username}...[/cyan]")

    user = resolve_username(username, bearer, verbose)
    user_id = user["id"]

    if verbose:
        console.print(f"[cyan]Fetching likes for @{username} (ID: {user_id})...[/cyan]")

    tweets = fetch_liked_tweets(user_id, access_token, max_results=limit, verbose=verbose)

    if verbose:
        console.print(f"[green]Fetched {len(tweets)} liked tweets[/green]")

    result = [_format_liked_tweet(t) for t in tweets]
    output_json = json.dumps(result, indent=2, ensure_ascii=False)

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(output_json)
        if verbose:
            console.print(f"[green]Saved to {output}[/green]")
    else:
        print(output_json)


@app.command()
def bookmarks(
    username: Annotated[Optional[str], typer.Argument(help="Your X username to resolve your user ID (default: X_DEFAULT_USERNAME or HamelHusain)")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Output file path (default: stdout)")] = None,
    limit: Annotated[int, typer.Option("--limit", "-n", help="Maximum number of tweets to fetch")] = 100,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Fetch your bookmarked tweets via the X API v2.

    Requires X_ACCESS_TOKEN (OAuth 2.0 user access token).
    Also uses X_BEARER_TOKEN to resolve the username.
    Note: You can only access your own bookmarks.
    Default username: HamelHusain (override by passing a different username).
    """
    username = _validate_username(username or DEFAULT_X_USERNAME)
    bearer = _get_bearer_token()
    access_token = _get_user_access_token()

    if verbose:
        console.print(f"[cyan]Resolving @{username}...[/cyan]")

    user = resolve_username(username, bearer, verbose)
    user_id = user["id"]

    if verbose:
        console.print(f"[cyan]Fetching bookmarks for @{username} (ID: {user_id})...[/cyan]")

    tweets = fetch_bookmarks_list(user_id, access_token, max_results=limit, verbose=verbose)

    if verbose:
        console.print(f"[green]Fetched {len(tweets)} bookmarked tweets[/green]")

    result = [_format_liked_tweet(t) for t in tweets]
    output_json = json.dumps(result, indent=2, ensure_ascii=False)

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(output_json)
        if verbose:
            console.print(f"[green]Saved to {output}[/green]")
    else:
        print(output_json)


@app.command()
def screenshot(
    url: Annotated[str, typer.Argument(help="Tweet URL (e.g., https://x.com/user/status/123)")],
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Output file path (default: tweet_<id>.png)")] = None,
    full_page: Annotated[bool, typer.Option("--full-page", "-f", help="Capture full page instead of just the tweet")] = False,
    wait: Annotated[int, typer.Option("--wait", "-w", help="Seconds to wait for page to load")] = 3,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Take a screenshot of a tweet using a headless browser.

    Requires playwright: pip install playwright && playwright install chromium
    Does not require X_BEARER_TOKEN.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        console.print("[red]Error: playwright not installed.[/red]")
        console.print("[dim]Run: pip install playwright && playwright install chromium[/dim]")
        raise typer.Exit(1)

    url = url.strip()
    if not re.match(r'https?://(twitter\.com|x\.com)/\w+/status/\d+', url):
        console.print("[red]Error: Invalid tweet URL.[/red]")
        console.print("[dim]Expected format: https://x.com/username/status/1234567890[/dim]")
        raise typer.Exit(1)

    url = url.replace("twitter.com", "x.com")

    tweet_id_match = re.search(r'/status/(\d+)', url)
    tweet_id = tweet_id_match.group(1) if tweet_id_match else "unknown"

    output_path = Path(output) if output else Path(f"tweet_{tweet_id}.png")

    if verbose:
        console.print(f"[cyan]Opening {url}...[/cyan]")

    with sync_playwright() as p:
        try:
            browser = p.chromium.launch(headless=True)
        except Exception as launch_err:
            if "Executable doesn't exist" in str(launch_err) or "browserType.launch" in str(launch_err):
                console.print("[red]Error: Playwright browser binaries not installed.[/red]")
                console.print("[dim]Run: playwright install chromium[/dim]")
                raise typer.Exit(1)
            raise
        context = browser.new_context(
            viewport={"width": 1280, "height": 900},
            device_scale_factor=2,
        )
        page = context.new_page()

        try:
            page.goto(url, wait_until="domcontentloaded", timeout=60000)

            if verbose:
                console.print("[cyan]Waiting for tweet to load...[/cyan]")

            try:
                page.locator('article[data-testid="tweet"]').first.wait_for(timeout=15000)
            except Exception:
                pass

            time.sleep(wait)

            if full_page:
                page.screenshot(path=str(output_path), full_page=True)
            else:
                tweet_element = page.locator('article[data-testid="tweet"]').first
                if tweet_element.is_visible():
                    tweet_element.screenshot(path=str(output_path))
                else:
                    if verbose:
                        console.print("[yellow]Tweet element not found, capturing viewport...[/yellow]")
                    page.screenshot(path=str(output_path))

            console.print(f"[green]Screenshot saved to {output_path}[/green]")

        except Exception as e:
            console.print(f"[red]Error taking screenshot: {e}[/red]")
            raise typer.Exit(1)
        finally:
            browser.close()


def main():
    app()


if __name__ == "__main__":
    main()
