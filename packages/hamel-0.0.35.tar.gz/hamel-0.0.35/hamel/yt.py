"""Re-export transcript/chapter functions from youtube_cli.

These functions were moved to hamel.youtube_cli to consolidate the YouTube
tooling. This module re-exports them so that hamel.writing (and anything
else that does `from hamel import yt`) continues to work.

WARNING: This file is hand-maintained. Do NOT add #|default_exp yt to
nbs/01_yt.ipynb — running nbdev_export would overwrite this shim.
"""

from hamel.youtube_cli import (
    transcribe_video as transcribe,
    transcribe_local_video,
    yt_chapters,
)

__all__ = ['yt_chapters', 'transcribe_local_video', 'transcribe']
