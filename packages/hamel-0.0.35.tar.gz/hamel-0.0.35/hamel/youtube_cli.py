"""CLI tool to manage a YouTube channel via the Data API v3 and yt-dlp for downloads.

Supports: upload, list, update metadata, schedule/unschedule/reschedule,
set thumbnails, download own videos (including private) via yt-dlp,
transcribe videos, and generate AI chapter summaries.

Does NOT support deleting videos.
"""

import json
import mimetypes
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from typing_extensions import Annotated

console = Console(stderr=True)

DEFAULT_TOKEN_PATH = Path.home() / ".youtube_oauth_token.json"
DEFAULT_CLIENT_SECRETS_PATH = Path.home() / ".youtube_client_secret.json"
YOUTUBE_SCOPES = [
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube.force-ssl",
]


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def _get_client_secrets_path() -> Path:
    """Return client secrets path from env or default."""
    env_path = os.getenv("YOUTUBE_CLIENT_SECRETS_FILE")
    if env_path:
        return Path(env_path)
    return DEFAULT_CLIENT_SECRETS_PATH


def _get_token_path() -> Path:
    """Return token storage path from env or default."""
    env_path = os.getenv("YOUTUBE_TOKEN_FILE")
    if env_path:
        return Path(env_path)
    return DEFAULT_TOKEN_PATH


def _build_credentials():
    """Load or refresh OAuth 2.0 credentials. Returns a google.oauth2.credentials.Credentials object."""
    try:
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
    except ImportError:
        console.print("[red]Error: google-auth is not installed.[/red]")
        console.print("[dim]Install with: pip install google-auth google-auth-oauthlib[/dim]")
        raise typer.Exit(1)

    token_path = _get_token_path()
    creds: Optional[Credentials] = None

    if token_path.exists():
        creds = Credentials.from_authorized_user_file(str(token_path), YOUTUBE_SCOPES)

    if creds and creds.valid:
        return creds

    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            _save_credentials(creds, token_path)
            return creds
        except Exception as exc:
            console.print(f"[yellow]Token refresh failed ({exc}); re-authenticating...[/yellow]")

    # Need fresh auth
    return _run_oauth_flow()


def _validate_client_id(client_id: str) -> None:
    """Check that a client ID looks like a valid Google OAuth client ID and exit with guidance if not."""
    if not client_id.endswith(".apps.googleusercontent.com"):
        console.print("[red]Error: YOUTUBE_CLIENT_ID does not look like a valid Google OAuth client ID.[/red]")
        console.print("")
        console.print(f"  Got:      {client_id[:40]}{'...' if len(client_id) > 40 else ''}")
        console.print("  Expected: <numbers>-<hash>.apps.googleusercontent.com")
        console.print("")
        console.print("[yellow]This value should come from Google Cloud Console → APIs & Services → Credentials.[/yellow]")
        console.print("[yellow]Look for the 'Client ID' field under your OAuth 2.0 Client ID (not the secret).[/yellow]")
        secrets_path = _get_client_secrets_path()
        if secrets_path.exists():
            console.print("")
            console.print(f"[cyan]Hint: You have a client_secret JSON file at {secrets_path}.[/cyan]")
            console.print("[cyan]Unset the env vars to use the JSON file instead:[/cyan]")
            console.print("  unset YOUTUBE_CLIENT_ID YOUTUBE_CLIENT_SECRET")
        raise typer.Exit(1)


def _run_oauth_flow():
    """Run the installed-app OAuth flow and persist the resulting token."""
    try:
        from google_auth_oauthlib.flow import InstalledAppFlow
    except ImportError:
        console.print("[red]Error: google-auth-oauthlib is not installed.[/red]")
        console.print("[dim]Install with: pip install google-auth-oauthlib[/dim]")
        raise typer.Exit(1)

    secrets_path = _get_client_secrets_path()

    # Support building client config from env vars
    client_id = os.getenv("YOUTUBE_CLIENT_ID")
    client_secret = os.getenv("YOUTUBE_CLIENT_SECRET")

    if client_id and client_secret:
        _validate_client_id(client_id)
        if secrets_path.exists():
            console.print(f"[dim]Note: Using YOUTUBE_CLIENT_ID/SECRET env vars (ignoring {secrets_path})[/dim]")
        client_config = {
            "installed": {
                "client_id": client_id,
                "client_secret": client_secret,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": ["http://localhost", "urn:ietf:wg:oauth:2.0:oob"],
            }
        }
        flow = InstalledAppFlow.from_client_config(client_config, YOUTUBE_SCOPES)
    elif client_id or client_secret:
        # One set but not the other
        missing = "YOUTUBE_CLIENT_SECRET" if client_id else "YOUTUBE_CLIENT_ID"
        console.print(f"[red]Error: {missing} is not set.[/red]")
        console.print("[yellow]Both YOUTUBE_CLIENT_ID and YOUTUBE_CLIENT_SECRET must be set together.[/yellow]")
        raise typer.Exit(1)
    elif secrets_path.exists():
        flow = InstalledAppFlow.from_client_secrets_file(str(secrets_path), YOUTUBE_SCOPES)
    else:
        console.print("[red]Error: No YouTube API OAuth credentials found.[/red]")
        console.print("")
        console.print("[yellow]To use the youtube CLI you need a Google Cloud OAuth 2.0 client ID.[/yellow]")
        console.print("")
        console.print("[bold]Option 1:[/bold] Place the client_secret JSON file (recommended):")
        console.print(f"  Download from Google Cloud Console and save to: {secrets_path}")
        console.print("")
        console.print("[bold]Option 2:[/bold] Set environment variables:")
        console.print("  export YOUTUBE_CLIENT_ID='<numbers>-<hash>.apps.googleusercontent.com'")
        console.print("  export YOUTUBE_CLIENT_SECRET='GOCSPX-...'")
        console.print("")
        console.print(f"[bold]Option 3:[/bold] Point to the JSON file with an env var:")
        console.print("  export YOUTUBE_CLIENT_SECRETS_FILE='/path/to/client_secret.json'")
        console.print("")
        console.print("[dim]How to create credentials:[/dim]")
        console.print("[dim]  1. Go to https://console.cloud.google.com/apis/credentials[/dim]")
        console.print("[dim]  2. Create an OAuth 2.0 Client ID (type: Desktop app)[/dim]")
        console.print("[dim]  3. Enable the YouTube Data API v3 at:[/dim]")
        console.print("[dim]     https://console.cloud.google.com/apis/library/youtube.googleapis.com[/dim]")
        console.print("[dim]  4. Download the JSON or copy the client ID and secret[/dim]")
        raise typer.Exit(1)

    try:
        creds = flow.run_local_server(port=0, open_browser=True)
    except Exception as exc:
        msg = str(exc)
        if "invalid_client" in msg or "unauthorized_client" in msg:
            console.print("[red]Error: Google rejected the OAuth credentials (invalid_client).[/red]")
            console.print("")
            if client_id:
                console.print(f"  Client ID used: {client_id[:40]}...")
                console.print("")
            console.print("[yellow]Common causes:[/yellow]")
            console.print("  1. The client ID or secret is wrong — double-check in Google Cloud Console")
            console.print("  2. The OAuth client was deleted or disabled in Google Cloud Console")
            console.print("  3. Env vars contain a different key (e.g. an API key) instead of an OAuth client ID")
            if secrets_path.exists() and client_id:
                console.print("")
                console.print(f"[cyan]Hint: You have a JSON file at {secrets_path}.[/cyan]")
                console.print("[cyan]Try unsetting the env vars to use the JSON file instead:[/cyan]")
                console.print("  unset YOUTUBE_CLIENT_ID YOUTUBE_CLIENT_SECRET")
            raise typer.Exit(1)
        raise

    token_path = _get_token_path()
    _save_credentials(creds, token_path)
    return creds


def _save_credentials(creds, token_path: Path) -> None:
    """Persist credentials to disk with restricted permissions."""
    token_path.parent.mkdir(parents=True, exist_ok=True)
    with open(token_path, "w", opener=lambda p, f: os.open(p, f, 0o600)) as fh:
        fh.write(creds.to_json())
    os.chmod(token_path, 0o600)


def _get_youtube_service():
    """Build and return an authenticated YouTube Data API v3 service object."""
    try:
        from googleapiclient.discovery import build
    except ImportError:
        console.print("[red]Error: google-api-python-client is not installed.[/red]")
        console.print("[dim]Install with: pip install google-api-python-client[/dim]")
        raise typer.Exit(1)

    creds = _build_credentials()
    return build("youtube", "v3", credentials=creds)


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------

def _get_my_uploads_playlist_id(youtube) -> str:
    """Return the uploads playlist ID for the authenticated user's channel."""
    resp = youtube.channels().list(part="contentDetails", mine=True).execute()
    items = resp.get("items", [])
    if not items:
        console.print("[red]Error: No YouTube channel found for this account.[/red]")
        raise typer.Exit(1)
    return items[0]["contentDetails"]["relatedPlaylists"]["uploads"]


def _fetch_video(youtube, video_id: str, parts: str = "snippet,status"):
    """Fetch a single video resource. Returns the item dict or exits with error."""
    resp = youtube.videos().list(part=parts, id=video_id).execute()
    items = resp.get("items", [])
    if not items:
        console.print(f"[red]Error: Video {video_id} not found or not accessible.[/red]")
        raise typer.Exit(1)
    return items[0]


def _parse_iso_timestamp(ts_str: str) -> datetime:
    """Parse an ISO 8601 timestamp string and ensure it is timezone-aware (UTC)."""
    # Replace 'Z' with '+00:00' for Python 3.10 compatibility
    # (fromisoformat only accepts 'Z' as UTC in Python 3.11+)
    dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _validate_future_timestamp(ts_str: str) -> str:
    """Validate and return an ISO timestamp that is in the future. Exits on error."""
    try:
        dt = _parse_iso_timestamp(ts_str)
    except ValueError:
        console.print(f"[red]Error: Invalid ISO 8601 timestamp: {ts_str}[/red]")
        console.print("[dim]Example: 2026-04-10T16:00:00Z[/dim]")
        raise typer.Exit(1)
    if dt <= datetime.now(timezone.utc):
        console.print("[red]Error: Timestamp must be in the future.[/red]")
        raise typer.Exit(1)
    return dt.isoformat()


def _format_video_row(item: dict) -> dict:
    """Extract display-friendly fields from a video resource."""
    snippet = item.get("snippet", {})
    status = item.get("status", {})
    return {
        "id": item["id"],
        "title": snippet.get("title", ""),
        "privacy": status.get("privacyStatus", ""),
        "publishAt": status.get("publishAt", ""),
        "publishedAt": snippet.get("publishedAt", ""),
        "description": (snippet.get("description", "") or "")[:80],
        "tags": ", ".join(snippet.get("tags", [])),
        "categoryId": snippet.get("categoryId", ""),
    }


# ---------------------------------------------------------------------------
# Typer app
# ---------------------------------------------------------------------------

app = typer.Typer(
    help="Manage your YouTube channel: upload, list, edit, schedule, download, transcribe, and generate chapters.",
    no_args_is_help=True,
)


@app.command()
def auth():
    """Authenticate with YouTube via OAuth 2.0.

    Opens a browser for Google login and stores the token locally.
    Re-run to refresh an expired token.
    """
    _build_credentials()
    console.print(f"[green]Authenticated successfully. Token saved to {_get_token_path()}[/green]")


@app.command()
def upload(
    file: Annotated[str, typer.Option("--file", "-f", help="Path to video file to upload")],
    title: Annotated[str, typer.Option("--title", "-t", help="Video title")],
    description: Annotated[str, typer.Option("--description", "-d", help="Video description")] = "",
    tags: Annotated[Optional[str], typer.Option("--tags", help="Comma-separated tags")] = None,
    category: Annotated[str, typer.Option("--category", help="YouTube category ID")] = "22",
    privacy: Annotated[str, typer.Option("--privacy", "-p", help="Privacy: public, private, unlisted")] = "private",
    publish_at: Annotated[Optional[str], typer.Option("--publish-at", help="Schedule publish time (ISO 8601)")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Upload a video to YouTube.

    The video is uploaded as private by default. Use --privacy to set it to public or
    unlisted, or --publish-at to schedule it for a future time.
    """
    try:
        from googleapiclient.http import MediaFileUpload
    except ImportError:
        console.print("[red]Error: google-api-python-client is not installed.[/red]")
        console.print("[dim]Install with: pip install google-api-python-client[/dim]")
        raise typer.Exit(1)

    video_path = Path(file)
    if not video_path.exists():
        console.print(f"[red]Error: File not found: {file}[/red]")
        raise typer.Exit(1)

    if privacy not in ("public", "private", "unlisted"):
        console.print(f"[red]Error: Invalid privacy status: {privacy}. Must be public, private, or unlisted.[/red]")
        raise typer.Exit(1)

    status_body: dict = {"privacyStatus": privacy}

    if publish_at:
        if privacy != "private":
            console.print("[yellow]Warning: Scheduled videos must be private. Overriding --privacy to 'private'.[/yellow]")
        validated_ts = _validate_future_timestamp(publish_at)
        status_body["privacyStatus"] = "private"
        status_body["publishAt"] = validated_ts
        if verbose:
            console.print(f"[cyan]Scheduling publish at {validated_ts}[/cyan]")

    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []

    body = {
        "snippet": {
            "title": title,
            "description": description,
            "tags": tag_list,
            "categoryId": category,
        },
        "status": status_body,
    }

    youtube = _get_youtube_service()
    media = MediaFileUpload(str(video_path), resumable=True, chunksize=10 * 1024 * 1024)

    if verbose:
        console.print(f"[cyan]Uploading {video_path.name} ({video_path.stat().st_size / 1024 / 1024:.1f} MB)...[/cyan]")

    request = youtube.videos().insert(part="snippet,status", body=body, media_body=media)

    response = None
    while response is None:
        status, response = request.next_chunk()
        if status and verbose:
            pct = int(status.progress() * 100)
            console.print(f"[cyan]  {pct}% uploaded[/cyan]")

    video_id = response["id"]
    console.print(f"[green]Uploaded: https://youtu.be/{video_id}[/green]")
    if verbose:
        console.print(f"[dim]Video ID: {video_id}[/dim]")
        console.print(f"[dim]Privacy: {response['status']['privacyStatus']}[/dim]")
        pub = response["status"].get("publishAt")
        if pub:
            console.print(f"[dim]Scheduled for: {pub}[/dim]")


@app.command(name="list")
def list_videos(
    limit: Annotated[int, typer.Option("--limit", "-n", help="Maximum number of videos to list")] = 25,
    as_json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show extra fields")] = False,
):
    """List your uploaded videos with metadata and status."""
    youtube = _get_youtube_service()
    playlist_id = _get_my_uploads_playlist_id(youtube)

    all_ids: list[str] = []
    next_page = None

    while len(all_ids) < limit:
        page_size = min(50, limit - len(all_ids))
        resp = (
            youtube.playlistItems()
            .list(
                part="contentDetails",
                playlistId=playlist_id,
                maxResults=page_size,
                pageToken=next_page,
            )
            .execute()
        )
        for item in resp.get("items", []):
            all_ids.append(item["contentDetails"]["videoId"])
        next_page = resp.get("nextPageToken")
        if not next_page:
            break

    if not all_ids:
        console.print("[yellow]No uploads found.[/yellow]")
        return

    # Fetch full video details in batches of 50
    videos: list[dict] = []
    for i in range(0, len(all_ids), 50):
        batch = all_ids[i : i + 50]
        resp = youtube.videos().list(part="snippet,status", id=",".join(batch)).execute()
        videos.extend(resp.get("items", []))

    if as_json:
        rows = [_format_video_row(v) for v in videos]
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return

    table = Table(title="Your YouTube Uploads", show_lines=False)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Title", style="bold")
    table.add_column("Privacy", style="green")
    table.add_column("Published / Scheduled")
    if verbose:
        table.add_column("Tags")
        table.add_column("Category")

    for v in videos:
        row = _format_video_row(v)
        date_col = row["publishAt"] or row["publishedAt"]
        cols = [row["id"], row["title"], row["privacy"], date_col]
        if verbose:
            cols += [row["tags"], row["categoryId"]]
        table.add_row(*cols)

    console.print(table)


@app.command()
def update(
    id: Annotated[str, typer.Option("--id", help="Video ID to update")],
    title: Annotated[Optional[str], typer.Option("--title", "-t", help="New title")] = None,
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="New description")] = None,
    tags: Annotated[Optional[str], typer.Option("--tags", help="Comma-separated tags (replaces existing)")] = None,
    category: Annotated[Optional[str], typer.Option("--category", help="Category ID")] = None,
    privacy: Annotated[Optional[str], typer.Option("--privacy", "-p", help="Privacy: public, private, unlisted")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Update metadata of an existing video.

    Fetches the current video first, merges your changes, and sends a complete
    update payload to avoid accidentally wiping fields.
    """
    if not any(x is not None for x in [title, description, tags, category, privacy]):
        console.print("[yellow]Nothing to update. Provide at least one of: --title, --description, --tags, --category, --privacy[/yellow]")
        raise typer.Exit(1)

    if privacy and privacy not in ("public", "private", "unlisted"):
        console.print(f"[red]Error: Invalid privacy status: {privacy}[/red]")
        raise typer.Exit(1)

    youtube = _get_youtube_service()
    video = _fetch_video(youtube, id)

    # Determine which parts we need to update
    parts = []
    body: dict = {"id": id}

    # Always include snippet if any snippet field changed (safe merge)
    if any(x is not None for x in [title, description, tags, category]):
        parts.append("snippet")
        current_snippet = video["snippet"]
        body["snippet"] = {
            "title": title if title is not None else current_snippet["title"],
            "description": description if description is not None else current_snippet.get("description", ""),
            "tags": [t.strip() for t in tags.split(",") if t.strip()] if tags is not None else current_snippet.get("tags", []),
            "categoryId": category if category is not None else current_snippet["categoryId"],
        }

    if privacy:
        parts.append("status")
        current_status = video["status"]
        status_body: dict = {"privacyStatus": privacy}
        if current_status.get("publishAt"):
            if privacy == "private":
                # Preserve schedule when staying private
                status_body["publishAt"] = current_status["publishAt"]
            else:
                console.print(f"[yellow]Warning: Changing privacy to '{privacy}' will clear the scheduled publish time ({current_status['publishAt']}).[/yellow]")
        body["status"] = status_body

    if verbose:
        console.print(f"[cyan]Updating parts: {', '.join(parts)}[/cyan]")

    youtube.videos().update(part=",".join(parts), body=body).execute()
    console.print(f"[green]Updated video {id}[/green]")


@app.command()
def schedule(
    id: Annotated[str, typer.Option("--id", help="Video ID to schedule")],
    publish_at: Annotated[str, typer.Option("--publish-at", help="ISO 8601 publish time (must be in the future)")],
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Schedule a private video for future publication.

    The video must be private and must never have been published before.
    """
    validated_ts = _validate_future_timestamp(publish_at)

    youtube = _get_youtube_service()
    video = _fetch_video(youtube, id)

    current_privacy = video["status"].get("privacyStatus", "")
    if current_privacy != "private":
        console.print(f"[red]Error: Video is '{current_privacy}'. Only private videos can be scheduled.[/red]")
        raise typer.Exit(1)

    body = {
        "id": id,
        "status": {
            "privacyStatus": "private",
            "publishAt": validated_ts,
        },
    }

    if verbose:
        console.print(f"[cyan]Scheduling {id} for {validated_ts}[/cyan]")

    youtube.videos().update(part="status", body=body).execute()
    console.print(f"[green]Scheduled video {id} for {validated_ts}[/green]")


@app.command()
def unschedule(
    id: Annotated[str, typer.Option("--id", help="Video ID to unschedule")],
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Unschedule a scheduled video, reverting it to a private draft.

    Clears the publishAt timestamp and keeps the video private.
    """
    youtube = _get_youtube_service()
    video = _fetch_video(youtube, id)

    current_privacy = video["status"].get("privacyStatus", "")
    current_publish_at = video["status"].get("publishAt")

    if current_privacy != "private":
        console.print(f"[red]Error: Video is '{current_privacy}', not a scheduled private video.[/red]")
        raise typer.Exit(1)

    if not current_publish_at:
        console.print("[yellow]Video is already an unscheduled private draft.[/yellow]")
        return

    body = {
        "id": id,
        "status": {
            "privacyStatus": "private",
        },
    }

    if verbose:
        console.print(f"[cyan]Unscheduling {id} (was scheduled for {current_publish_at})[/cyan]")

    youtube.videos().update(part="status", body=body).execute()
    console.print(f"[green]Unscheduled video {id} — now a private draft.[/green]")


@app.command()
def reschedule(
    id: Annotated[str, typer.Option("--id", help="Video ID to reschedule")],
    publish_at: Annotated[str, typer.Option("--publish-at", help="New ISO 8601 publish time")],
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Reschedule an unpublished private video to a new time.

    Only works while the video is still private and has never been public.
    """
    validated_ts = _validate_future_timestamp(publish_at)

    youtube = _get_youtube_service()
    video = _fetch_video(youtube, id)

    current_privacy = video["status"].get("privacyStatus", "")
    if current_privacy != "private":
        console.print(f"[red]Error: Video is '{current_privacy}'. Only private (unpublished) videos can be rescheduled.[/red]")
        raise typer.Exit(1)

    body = {
        "id": id,
        "status": {
            "privacyStatus": "private",
            "publishAt": validated_ts,
        },
    }

    if verbose:
        old_ts = video["status"].get("publishAt", "none")
        console.print(f"[cyan]Rescheduling {id}: {old_ts} -> {validated_ts}[/cyan]")

    youtube.videos().update(part="status", body=body).execute()
    console.print(f"[green]Rescheduled video {id} to {validated_ts}[/green]")


@app.command(name="set-thumbnail")
def set_thumbnail(
    id: Annotated[str, typer.Option("--id", help="Video ID")],
    file: Annotated[str, typer.Option("--file", "-f", help="Path to thumbnail image (JPEG, PNG, etc.)")],
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Set or replace the thumbnail for a video.

    Uses the thumbnails.set endpoint (not videos.update).
    """
    try:
        from googleapiclient.http import MediaFileUpload
    except ImportError:
        console.print("[red]Error: google-api-python-client is not installed.[/red]")
        console.print("[dim]Install with: pip install google-api-python-client[/dim]")
        raise typer.Exit(1)

    thumb_path = Path(file)
    if not thumb_path.exists():
        console.print(f"[red]Error: File not found: {file}[/red]")
        raise typer.Exit(1)

    youtube = _get_youtube_service()
    mime_type, _ = mimetypes.guess_type(str(thumb_path))
    if not mime_type or not mime_type.startswith("image/"):
        mime_type = "image/jpeg"
    media = MediaFileUpload(str(thumb_path), mimetype=mime_type)

    if verbose:
        console.print(f"[cyan]Uploading thumbnail for {id}...[/cyan]")

    youtube.thumbnails().set(videoId=id, media_body=media).execute()
    console.print(f"[green]Thumbnail set for video {id}[/green]")


def _download_with_ytdlp(video_url: str, output: Optional[str] = None, verbose: bool = False) -> str:
    """Download a video using yt-dlp with Chrome cookies. Returns the output file path."""
    if not shutil.which("yt-dlp"):
        console.print("[red]Error: yt-dlp not found.[/red]")
        console.print("[dim]Install with: pip install yt-dlp[/dim]")
        raise typer.Exit(1)

    cmd: list[str] = ["yt-dlp", "--cookies-from-browser", "chrome"]

    if shutil.which("node"):
        cmd += ["--js-runtimes", "node"]

    cmd += ["--merge-output-format", "mp4"]

    if output:
        cmd += ["-o", output]

    cmd.append(video_url)

    if verbose:
        console.print(f"[cyan]Running: {' '.join(cmd)}[/cyan]")

    result = subprocess.run(cmd, capture_output=not verbose, text=True)
    if result.returncode != 0:
        stderr = "" if verbose else (result.stderr or "")
        raise RuntimeError(stderr[-500:] if stderr else "yt-dlp download failed")

    # Determine the output path
    if output:
        return output
    # yt-dlp prints the destination; try to find it
    stdout = result.stdout or ""
    for line in stdout.splitlines():
        if "Destination:" in line:
            return line.split("Destination:", 1)[1].strip()
        if "has already been downloaded" in line:
            return line.split('"')[1] if '"' in line else line.strip()
    return ""


@app.command()
def download(
    id: Annotated[Optional[str], typer.Option("--id", help="YouTube video ID")] = None,
    url: Annotated[Optional[str], typer.Option("--url", "-u", help="YouTube video URL")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Output file path")] = None,
    cookies: Annotated[Optional[str], typer.Option("--cookies", help="Path to cookies.txt file for authentication")] = None,
    cookies_from_browser: Annotated[Optional[str], typer.Option("--cookies-from-browser", help="Browser to extract cookies from (e.g. 'chrome', 'firefox', 'chrome:/path/to/profile'). Defaults to 'chrome' for automatic cookie extraction.")] = None,
    format: Annotated[Optional[str], typer.Option("--format", "-f", help="yt-dlp format string (default: best)")] = None,
    no_cookies: Annotated[bool, typer.Option("--no-cookies", help="Skip automatic cookie extraction (download without authentication)")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show yt-dlp output")] = False,
):
    """Download a YouTube video (including your own private videos) using yt-dlp.

    This uses yt-dlp with browser cookies for authentication — it does NOT use the
    YouTube Data API (which has no download endpoint for uploaded video files).

    You must provide either --id or --url. By default, cookies are extracted from
    Chrome automatically (--cookies-from-browser chrome). Use --no-cookies to skip
    cookie extraction, or --cookies to provide a cookies.txt file instead.
    """
    if not shutil.which("yt-dlp"):
        console.print("[red]Error: yt-dlp not found.[/red]")
        console.print("")
        console.print("[yellow]yt-dlp is required for downloading videos. Install it with:[/yellow]")
        console.print("  pip install yt-dlp")
        console.print("  # or")
        console.print("  brew install yt-dlp")
        raise typer.Exit(1)

    if not id and not url:
        console.print("[red]Error: Provide --id or --url.[/red]")
        console.print("[dim]Example: youtube download --id VIDEO_ID[/dim]")
        console.print("[dim]Example: youtube download --url 'https://youtu.be/VIDEO_ID'[/dim]")
        raise typer.Exit(1)

    video_url = url if url else f"https://www.youtube.com/watch?v={id}"

    cmd: list[str] = ["yt-dlp"]

    if cookies:
        cookie_path = Path(cookies)
        if not cookie_path.exists():
            console.print(f"[red]Error: Cookies file not found: {cookies}[/red]")
            raise typer.Exit(1)
        cmd += ["--cookies", str(cookie_path)]
    elif not no_cookies:
        # Default to extracting cookies from Chrome for seamless auth
        browser = cookies_from_browser or "chrome"
        cmd += ["--cookies-from-browser", browser]

    # Node.js is needed to solve YouTube's n challenge (anti-download protection)
    if shutil.which("node"):
        cmd += ["--js-runtimes", "node"]

    if format:
        cmd += ["-f", format]

    # Default to mp4 output so downloaded files work with transcribe/chapters
    cmd += ["--merge-output-format", "mp4"]

    if output:
        cmd += ["-o", output]

    cmd.append(video_url)

    if verbose:
        console.print(f"[cyan]Running: {' '.join(cmd)}[/cyan]")

    result = subprocess.run(cmd, capture_output=not verbose, text=True)
    if result.returncode != 0:
        stderr = "" if verbose else (result.stderr or "")
        # Detect common auth-related errors and provide clear guidance
        if "Sign in to confirm" in stderr or "cookies" in stderr.lower():
            console.print("[red]Error: Authentication required for this video.[/red]")
            console.print("")
            console.print("[yellow]yt-dlp needs browser cookies to authenticate downloads.[/yellow]")
            console.print("The CLI automatically extracts cookies from Chrome by default.")
            console.print("")
            console.print("[bold]Make sure you are logged into YouTube in Chrome.[/bold]")
            console.print("")
            console.print("If Chrome is not at the default location, specify the profile path:")
            console.print("  youtube download --id VIDEO_ID --cookies-from-browser 'chrome:/path/to/profile'")
            console.print("")
            console.print("Alternative: use a cookies.txt file:")
            console.print("  youtube download --id VIDEO_ID --cookies ~/cookies.txt")
            console.print("")
            console.print("For Firefox:")
            console.print("  youtube download --id VIDEO_ID --cookies-from-browser firefox")
        elif "could not find" in stderr.lower() and "cookies database" in stderr.lower():
            console.print("[red]Error: Could not find browser cookies database.[/red]")
            console.print("")
            console.print("[yellow]yt-dlp could not find the Chrome cookies database at the default location.[/yellow]")
            console.print("")
            console.print("[bold]Options:[/bold]")
            console.print("  1. Specify the Chrome profile path explicitly:")
            console.print("     youtube download --id VIDEO_ID --cookies-from-browser 'chrome:/path/to/chrome/profile'")
            console.print("  2. Use Firefox instead:")
            console.print("     youtube download --id VIDEO_ID --cookies-from-browser firefox")
            console.print("  3. Use a cookies.txt file:")
            console.print("     youtube download --id VIDEO_ID --cookies ~/cookies.txt")
            console.print("  4. Skip cookie extraction (public videos only):")
            console.print("     youtube download --id VIDEO_ID --no-cookies")
        elif stderr:
            console.print(f"[red]yt-dlp error:[/red]\n{stderr[-500:]}")
        raise typer.Exit(result.returncode)

    console.print("[green]Download complete.[/green]")


# ---------------------------------------------------------------------------
# Transcript / chapter helpers (moved from hamel/yt.py)
# ---------------------------------------------------------------------------

def _extract_video_id(url: str) -> Optional[str]:
    """Extract YouTube video ID from various URL formats."""
    for pattern in [r'(?:youtube\.com/watch\?v=|youtu\.be/)([^&\n?#]+)',
                    r'youtube\.com/embed/([^&\n?#]+)',
                    r'youtube\.com/v/([^&\n?#]+)']:
        if match := re.search(pattern, url): return match.group(1)
    return url if re.match(r'^[a-zA-Z0-9_-]{11}$', url) else None


def _format_hms(seconds: float) -> str:
    """Convert seconds to HH:MM:SS format."""
    h, m, s = int(seconds // 3600), int((seconds % 3600) // 60), int(seconds % 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def _format_secs(seconds: float) -> str:
    return f"{int(seconds):d}s"


def transcribe_local_video(file_path, seconds_only=False):
    """Transcribe a local video file using Whisper."""
    import whisper

    with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_audio:
        try:
            cmd = ["ffmpeg", "-i", str(file_path), "-q:a", "0", "-map", "a",
                   temp_audio.name, "-y", "-loglevel", "error"]
            subprocess.run(cmd, check=True)
            model = whisper.load_model("large-v3-turbo")
            result = model.transcribe(temp_audio.name)
            fmt = _format_secs if seconds_only else _format_hms
            return '\n'.join(f"[{fmt(seg['start'])}] {seg['text'].strip()}"
                             for seg in result['segments'])
        finally:
            Path(temp_audio.name).unlink(missing_ok=True)


def _transcribe_via_data_api(video_id, seconds_only=False):
    """Try fetching captions via the YouTube Data API v3 (works for own videos, no IP blocking)."""
    try:
        youtube = _get_youtube_service()
    except (SystemExit, Exception):
        return None  # No OAuth credentials available

    try:
        result = youtube.captions().list(part="snippet", videoId=video_id).execute()
    except Exception:
        return None

    # Prefer English tracks; prefer manual over auto-generated
    tracks = result.get("items", [])
    if not tracks:
        return None

    en_tracks = [t for t in tracks if t["snippet"]["language"].startswith("en")]
    chosen = en_tracks or tracks
    # Prefer manual captions (trackKind != "asr") over auto-generated
    manual = [t for t in chosen if t["snippet"].get("trackKind") != "asr"]
    track = (manual or chosen)[0]

    try:
        data = youtube.captions().download(id=track["id"], tfmt="srt").execute()
    except Exception:
        return None  # 403 for videos we don't own — fall through to next method

    srt_text = data.decode() if isinstance(data, bytes) else data
    return _parse_srt(srt_text, seconds_only)


def _parse_srt(srt_text, seconds_only=False):
    """Parse SRT subtitle text into timestamped lines."""
    fmt = _format_secs if seconds_only else _format_hms
    lines = []
    for block in re.split(r'\n\n+', srt_text.strip()):
        block_lines = block.strip().split('\n')
        if len(block_lines) < 3:
            continue
        timestamp_line = block_lines[1]
        text = ' '.join(block_lines[2:]).strip()
        if not text:
            continue
        # Parse "HH:MM:SS,mmm --> HH:MM:SS,mmm"
        match = re.match(r'(\d+):(\d+):(\d+)[,.](\d+)', timestamp_line)
        if match:
            h, m, s = int(match.group(1)), int(match.group(2)), int(match.group(3))
            seconds_val = h * 3600 + m * 60 + s
            lines.append(f"[{fmt(seconds_val)}] {text}")
    return '\n'.join(lines) if lines else None


def transcribe_video(url_or_path, seconds_only=False):
    """Download YouTube transcript or transcribe local video.

    Fallback chain:
    1. YouTube Data API (captions.download) — works for own videos, no IP blocking
    2. youtube_transcript_api — works for public videos with available captions
    3. Raises an error (caller can fall back to Whisper)
    """
    path = Path(url_or_path)
    if path.exists() and path.suffix.lower() in ('.mp4', '.webm', '.mkv', '.avi', '.mov', '.flv', '.wmv', '.m4v'):
        return transcribe_local_video(url_or_path, seconds_only)

    if not (video_id := _extract_video_id(url_or_path)):
        raise ValueError(f"Could not extract video ID from '{url_or_path}'")

    # Method 1: YouTube Data API (authenticated, no IP blocking)
    result = _transcribe_via_data_api(video_id, seconds_only)
    if result:
        return result

    # Method 2: youtube_transcript_api (unauthenticated scraping)
    from youtube_transcript_api import YouTubeTranscriptApi, TranscriptsDisabled, NoTranscriptFound
    try:
        transcript_data = YouTubeTranscriptApi().fetch(video_id, languages=['en'])
        fmt = _format_secs if seconds_only else _format_hms
        return '\n'.join(f"[{fmt(e.start)}] {e.text}" for e in transcript_data)
    except (TranscriptsDisabled, NoTranscriptFound) as e:
        raise ValueError(f"{str(e)} for video: {video_id}")
    except Exception as e:
        raise ValueError(f"Could not retrieve transcript for video {video_id}: {e}")


def yt_chapters(url_or_path):
    """Generate YouTube Summary and Chapters from a video (YouTube URL or local MP4)."""
    from hamel.gem import gem
    chapter_prompt = ("Generate a succinct video summary (1-2 sentences) followed by video chapter "
                      "timestamps for this video. Format each line of the chapter summaries as "
                      "'MM:SS - Chapter Title' (e.g., '02:30 - Introduction'). Start with 00:00. "
                      "Include all major topics and transitions and be thorough - do not miss any "
                      "important topics. For the summary, do not say 'In this video, we will cover "
                      "the following topics', 'This video discusses..' or anything like that. Instead, "
                      "reference the main speaker's name if you know it. If there is a Q&A Section, "
                      "enumerate individual questions as additional chapters.")
    return gem(prompt=chapter_prompt, o=url_or_path, model="gemini-3-pro-preview")


_VIDEO_EXTENSIONS = {".mp4", ".webm", ".mkv", ".avi", ".mov", ".flv", ".wmv", ".m4v"}


@app.command()
def comment(
    id: Annotated[str, typer.Option("--id", help="Video ID to comment on")],
    text: Annotated[str, typer.Option("--text", "-t", help="Comment text")],
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show progress info")] = False,
):
    """Post a top-level comment on a video.

    The YouTube Data API does NOT support pinning — pinning is a Studio-UI-only
    action. After posting, open the video in Studio to pin the comment:
        https://studio.youtube.com/video/<VIDEO_ID>/comments
    """
    youtube = _get_youtube_service()

    body = {
        "snippet": {
            "videoId": id,
            "topLevelComment": {
                "snippet": {
                    "textOriginal": text,
                }
            },
        }
    }

    if verbose:
        console.print(f"[cyan]Posting comment on video {id}...[/cyan]")

    response = youtube.commentThreads().insert(part="snippet", body=body).execute()
    thread_id = response["id"]
    comment_id = response["snippet"]["topLevelComment"]["id"]

    console.print(f"[green]Comment posted on video {id}[/green]")
    console.print(f"[dim]Thread ID:  {thread_id}[/dim]")
    console.print(f"[dim]Comment ID: {comment_id}[/dim]")
    console.print(f"[dim]Pin in Studio: https://studio.youtube.com/video/{id}/comments[/dim]")


@app.command()
def transcribe(
    url: Annotated[str, typer.Argument(help="YouTube video URL, video ID, or local video file path")],
    seconds: Annotated[bool, typer.Option("--seconds", "-s", help="Show timestamps in seconds instead of HH:MM:SS")] = False,
):
    """Get the transcript of a YouTube video or local video file.

    For YouTube videos, this fetches the existing captions/subtitles (no AI needed).
    For local video files, this transcribes the audio using OpenAI Whisper.

    Does NOT require YouTube OAuth — works with public video transcripts.
    """
    # Handle local video files of any format
    path = Path(url)
    if path.exists() and path.suffix.lower() in _VIDEO_EXTENSIONS:
        try:
            print(transcribe_local_video(str(path), seconds_only=seconds))
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            raise typer.Exit(1)
        return

    try:
        transcript_text = transcribe_video(url, seconds_only=seconds)
        print(transcript_text)
    except Exception as e:
        error_msg = str(e)
        if "private" not in error_msg.lower() and "unplayable" not in error_msg.lower():
            console.print(f"[red]Error: {e}[/red]")
            raise typer.Exit(1)

        # Private/unplayable video — fall back to download + local transcription
        if not shutil.which("yt-dlp"):
            console.print(f"[red]Error: {e}[/red]")
            console.print("[yellow]Install yt-dlp to transcribe private videos: pip install yt-dlp[/yellow]")
            raise typer.Exit(1)

        console.print("[yellow]Video is private/unplayable — downloading via yt-dlp and transcribing locally...[/yellow]")
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = str(Path(tmpdir) / "video.mp4")
            try:
                _download_with_ytdlp(url, output=tmp_path)
            except RuntimeError as dl_err:
                console.print(f"[red]Download failed: {dl_err}[/red]")
                raise typer.Exit(1)
            print(transcribe_local_video(tmp_path, seconds_only=seconds))


@app.command()
def chapters(
    url: Annotated[str, typer.Argument(help="YouTube video URL or local video file path")],
):
    """Generate chapter summaries with timestamps for a YouTube video using AI.

    Uses Google Gemini to analyze the video and produce chapter titles with
    timestamps suitable for YouTube descriptions.

    Requires the GEMINI_API_KEY environment variable to be set.
    Does NOT require YouTube OAuth.
    """
    gemini_key = os.getenv("GEMINI_API_KEY")
    if not gemini_key:
        console.print("[red]Error: GEMINI_API_KEY environment variable is not set.[/red]")
        console.print("")
        console.print("[yellow]The 'chapters' command uses Google Gemini to generate chapter summaries.[/yellow]")
        console.print("")
        console.print("[bold]Set the environment variable:[/bold]")
        console.print("  export GEMINI_API_KEY='your-gemini-api-key'")
        console.print("")
        console.print("[dim]Get an API key at: https://aistudio.google.com/apikey[/dim]")
        raise typer.Exit(1)

    with console.status("[bold blue]Analyzing video...[/bold blue]", spinner="dots"):
        try:
            result = yt_chapters(url)
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            raise typer.Exit(1)

    if result:
        print(result)
    else:
        console.print("[yellow]Warning: No chapters generated. The video may be too short or Gemini returned empty output.[/yellow]")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    app()


if __name__ == "__main__":
    main()
