"""Shared CLI utilities for error handling and environment variables."""

import os
import sys
from typing import Optional
import typer


def die(message: str, code: int = 1) -> None:
    """Print error to stderr and exit with non-zero code."""
    typer.echo(message, err=True)
    raise typer.Exit(code)


def require_env(name: str, hint: Optional[str] = None) -> str:
    """Return env var or exit with helpful message."""
    value = os.environ.get(name)
    if value: return value
    msg = f"Error: {name} environment variable is not set."
    if hint: msg += f" {hint}"
    die(msg)
    return ""


def read_stdin_if_none(prompt: Optional[str]) -> str:
    """If prompt is None, read from stdin; error if stdin is TTY or empty."""
    if prompt is not None: return prompt
    if sys.stdin.isatty():
        die("Error: No prompt provided. Use as argument or pipe input via stdin.")
    text = sys.stdin.read().strip()
    if not text: die("Error: Empty input from stdin.")
    return text
