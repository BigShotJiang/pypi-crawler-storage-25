"""Minimal tests for CLI tools."""

import os
import re
import subprocess
import pytest

def _strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences from text."""
    return re.sub(r'\x1b\[[0-9;]*m', '', text)

def run_cli(cmd: list[str]) -> subprocess.CompletedProcess:
    """Run CLI command directly and return result with ANSI codes stripped."""
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    result.stdout = _strip_ansi(result.stdout)
    result.stderr = _strip_ansi(result.stderr)
    return result

def has_gemini_key() -> bool:
    return bool(os.environ.get("GEMINI_API_KEY"))

class TestTranscribe:
    def test_help(self):
        result = run_cli(["youtube", "transcribe", "--help"])
        assert result.returncode == 0
        assert "transcript" in result.stdout.lower()

    def test_transcribe_video(self):
        result = run_cli(["youtube", "transcribe", "https://youtu.be/vKWJprqFv0k"])
        assert result.returncode == 0
        assert len(result.stdout.strip()) > 0

    def test_transcribe_seconds(self):
        result = run_cli(["youtube", "transcribe", "https://youtu.be/vKWJprqFv0k", "--seconds"])
        assert result.returncode == 0
        assert "s]" in result.stdout

class TestChapters:
    def test_help(self):
        result = run_cli(["youtube", "chapters", "--help"])
        assert result.returncode == 0
        assert "chapter" in result.stdout.lower()

    @pytest.mark.skipif(not has_gemini_key(), reason="GEMINI_API_KEY not set")
    def test_chapters_video(self):
        result = run_cli(["youtube", "chapters", "https://youtu.be/vKWJprqFv0k"])
        assert result.returncode == 0
        assert "00:00" in result.stdout

class TestGem:
    def test_help(self):
        result = run_cli(["ai-gem", "--help"])
        assert result.returncode == 0
        assert "Gemini" in result.stdout
        assert "--image" in result.stdout
        assert "--aspect-ratio" in result.stdout
        assert "--output" in result.stdout

    @pytest.mark.skipif(not has_gemini_key(), reason="GEMINI_API_KEY not set")
    def test_gem_simple(self):
        result = run_cli(["ai-gem", "What is 2+2? Reply with just the number."])
        assert result.returncode == 0
        assert "4" in result.stdout

    @pytest.mark.skipif(not has_gemini_key(), reason="GEMINI_API_KEY not set")
    def test_gem_image(self, tmp_path):
        out = str(tmp_path / "test.png")
        result = run_cli(["ai-gem", "--image", "A red circle on white background", "-o", out])
        assert result.returncode == 0
        assert out in result.stdout
        assert os.path.exists(out)
        assert os.path.getsize(out) > 1000

    def test_gem_image_aspect_ratio_without_image(self):
        result = run_cli(["ai-gem", "hello", "--aspect-ratio", "16:9"])
        assert result.returncode == 1

    def test_gem_image_output_without_image(self):
        result = run_cli(["ai-gem", "hello", "--output", "foo.png"])
        assert result.returncode == 1

    def test_gem_image_invalid_aspect_ratio(self):
        result = run_cli(["ai-gem", "--image", "hello", "--aspect-ratio", "7:3"])
        assert result.returncode == 1

class TestAnnotateTalk:
    def test_help(self):
        result = run_cli(["ai-annotate-talk", "--help"])
        assert result.returncode == 0
        assert "YouTube video URL" in result.stdout
        assert "slide" in result.stdout.lower()

class TestZoom:
    def test_help(self):
        result = run_cli(["zoom", "--help"])
        assert result.returncode == 0
        assert "Zoom" in result.stdout
        assert "meeting" in result.stdout.lower()

class TestKit:
    def test_help(self):
        result = run_cli(["kit-broadcasts", "--help"])
        assert result.returncode == 0
        assert "Kit" in result.stdout
        assert "broadcasts" in result.stdout.lower()

class TestYouTube:
    def test_help(self):
        result = run_cli(["youtube", "--help"])
        assert result.returncode == 0
        assert "upload" in result.stdout.lower()
        assert "list" in result.stdout.lower()
        assert "download" in result.stdout.lower()
        assert "schedule" in result.stdout.lower()
        assert "transcribe" in result.stdout.lower()
        assert "chapters" in result.stdout.lower()
        assert "delete" not in result.stdout.lower()

    def test_auth_help(self):
        result = run_cli(["youtube", "auth", "--help"])
        assert result.returncode == 0
        assert "OAuth" in result.stdout or "oauth" in result.stdout.lower()

    def test_upload_help(self):
        result = run_cli(["youtube", "upload", "--help"])
        assert result.returncode == 0
        assert "--file" in result.stdout
        assert "--title" in result.stdout
        assert "--privacy" in result.stdout
        assert "--publish-at" in result.stdout

    def test_list_help(self):
        result = run_cli(["youtube", "list", "--help"])
        assert result.returncode == 0
        assert "--limit" in result.stdout
        assert "--json" in result.stdout

    def test_update_help(self):
        result = run_cli(["youtube", "update", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--title" in result.stdout
        assert "--description" in result.stdout
        assert "--tags" in result.stdout
        assert "--category" in result.stdout
        assert "--privacy" in result.stdout

    def test_schedule_help(self):
        result = run_cli(["youtube", "schedule", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--publish-at" in result.stdout

    def test_unschedule_help(self):
        result = run_cli(["youtube", "unschedule", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout

    def test_reschedule_help(self):
        result = run_cli(["youtube", "reschedule", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--publish-at" in result.stdout

    def test_set_thumbnail_help(self):
        result = run_cli(["youtube", "set-thumbnail", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--file" in result.stdout

    def test_download_help(self):
        result = run_cli(["youtube", "download", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--url" in result.stdout
        assert "--cookies" in result.stdout
        assert "--cookies-from-browser" in result.stdout
        assert "--no-cookies" in result.stdout

    def test_transcribe_help(self):
        result = run_cli(["youtube", "transcribe", "--help"])
        assert result.returncode == 0
        assert "transcript" in result.stdout.lower()
        assert "--seconds" in result.stdout

    def test_chapters_help(self):
        result = run_cli(["youtube", "chapters", "--help"])
        assert result.returncode == 0
        assert "chapter" in result.stdout.lower()
        assert "GEMINI_API_KEY" in result.stdout


class TestYouTubeUnit:
    """Unit tests for youtube_cli internals."""

    def test_parse_iso_timestamp_utc(self):
        from hamel.youtube_cli import _parse_iso_timestamp
        dt = _parse_iso_timestamp("2026-04-10T16:00:00Z")
        assert dt.year == 2026
        assert dt.month == 4
        assert dt.tzinfo is not None

    def test_parse_iso_timestamp_naive(self):
        from hamel.youtube_cli import _parse_iso_timestamp
        dt = _parse_iso_timestamp("2026-04-10T16:00:00")
        assert dt.tzinfo is not None  # Should default to UTC

    def test_validate_future_timestamp_past(self):
        from hamel.youtube_cli import _validate_future_timestamp
        from click.exceptions import Exit
        with pytest.raises(Exit):
            _validate_future_timestamp("2020-01-01T00:00:00Z")

    def test_validate_future_timestamp_invalid(self):
        from hamel.youtube_cli import _validate_future_timestamp
        from click.exceptions import Exit
        with pytest.raises(Exit):
            _validate_future_timestamp("not-a-timestamp")

    def test_validate_future_timestamp_valid(self):
        from hamel.youtube_cli import _validate_future_timestamp
        result = _validate_future_timestamp("2099-12-31T23:59:59Z")
        assert "2099" in result

    def test_format_video_row(self):
        from hamel.youtube_cli import _format_video_row
        item = {
            "id": "abc123",
            "snippet": {
                "title": "Test Video",
                "description": "A test",
                "publishedAt": "2026-01-01T00:00:00Z",
                "tags": ["tag1", "tag2"],
                "categoryId": "22",
            },
            "status": {
                "privacyStatus": "private",
                "publishAt": "2026-04-10T16:00:00Z",
            },
        }
        row = _format_video_row(item)
        assert row["id"] == "abc123"
        assert row["title"] == "Test Video"
        assert row["privacy"] == "private"
        assert row["publishAt"] == "2026-04-10T16:00:00Z"
        assert "tag1" in row["tags"]
        assert row["categoryId"] == "22"

    def test_format_video_row_minimal(self):
        from hamel.youtube_cli import _format_video_row
        item = {"id": "xyz", "snippet": {}, "status": {}}
        row = _format_video_row(item)
        assert row["id"] == "xyz"
        assert row["title"] == ""
        assert row["tags"] == ""

    def test_no_delete_command(self):
        """Verify that no delete command exists."""
        from hamel.youtube_cli import app
        command_names = [cmd.name or cmd.callback.__name__ for cmd in app.registered_commands]
        assert "delete" not in command_names


class TestYouTube:
    def test_help(self):
        result = run_cli(["youtube", "--help"])
        assert result.returncode == 0
        assert "upload" in result.stdout.lower()
        assert "list" in result.stdout.lower()
        assert "download" in result.stdout.lower()
        assert "schedule" in result.stdout.lower()
        assert "delete" not in result.stdout.lower()

    def test_auth_help(self):
        result = run_cli(["youtube", "auth", "--help"])
        assert result.returncode == 0
        assert "OAuth" in result.stdout or "oauth" in result.stdout.lower()

    def test_upload_help(self):
        result = run_cli(["youtube", "upload", "--help"])
        assert result.returncode == 0
        assert "--file" in result.stdout
        assert "--title" in result.stdout
        assert "--privacy" in result.stdout
        assert "--publish-at" in result.stdout

    def test_list_help(self):
        result = run_cli(["youtube", "list", "--help"])
        assert result.returncode == 0
        assert "--limit" in result.stdout
        assert "--json" in result.stdout

    def test_update_help(self):
        result = run_cli(["youtube", "update", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--title" in result.stdout
        assert "--description" in result.stdout
        assert "--tags" in result.stdout
        assert "--category" in result.stdout
        assert "--privacy" in result.stdout

    def test_schedule_help(self):
        result = run_cli(["youtube", "schedule", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--publish-at" in result.stdout

    def test_unschedule_help(self):
        result = run_cli(["youtube", "unschedule", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout

    def test_reschedule_help(self):
        result = run_cli(["youtube", "reschedule", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--publish-at" in result.stdout

    def test_set_thumbnail_help(self):
        result = run_cli(["youtube", "set-thumbnail", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--file" in result.stdout

    def test_download_help(self):
        result = run_cli(["youtube", "download", "--help"])
        assert result.returncode == 0
        assert "--id" in result.stdout
        assert "--url" in result.stdout
        assert "--cookies" in result.stdout
        assert "--cookies-from-browser" in result.stdout

    def test_transcribe_help(self):
        result = run_cli(["youtube", "transcribe", "--help"])
        assert result.returncode == 0
        assert "--seconds" in result.stdout

    def test_chapters_help(self):
        result = run_cli(["youtube", "chapters", "--help"])
        assert result.returncode == 0
        assert "YouTube video URL" in result.stdout or "youtube" in result.stdout.lower()


class TestYouTubeUnit:
    """Unit tests for youtube_cli internals."""

    def test_parse_iso_timestamp_utc(self):
        from hamel.youtube_cli import _parse_iso_timestamp
        dt = _parse_iso_timestamp("2026-04-10T16:00:00Z")
        assert dt.year == 2026
        assert dt.month == 4
        assert dt.tzinfo is not None

    def test_parse_iso_timestamp_naive(self):
        from hamel.youtube_cli import _parse_iso_timestamp
        dt = _parse_iso_timestamp("2026-04-10T16:00:00")
        assert dt.tzinfo is not None

    def test_validate_future_timestamp_past(self):
        from hamel.youtube_cli import _validate_future_timestamp
        from click.exceptions import Exit
        with pytest.raises(Exit):
            _validate_future_timestamp("2020-01-01T00:00:00Z")

    def test_validate_future_timestamp_invalid(self):
        from hamel.youtube_cli import _validate_future_timestamp
        from click.exceptions import Exit
        with pytest.raises(Exit):
            _validate_future_timestamp("not-a-timestamp")

    def test_validate_future_timestamp_valid(self):
        from hamel.youtube_cli import _validate_future_timestamp
        result = _validate_future_timestamp("2099-12-31T23:59:59Z")
        assert "2099" in result

    def test_format_video_row(self):
        from hamel.youtube_cli import _format_video_row
        item = {
            "id": "abc123",
            "snippet": {
                "title": "Test Video",
                "description": "A test",
                "publishedAt": "2026-01-01T00:00:00Z",
                "tags": ["tag1", "tag2"],
                "categoryId": "22",
            },
            "status": {
                "privacyStatus": "private",
                "publishAt": "2026-04-10T16:00:00Z",
            },
        }
        row = _format_video_row(item)
        assert row["id"] == "abc123"
        assert row["title"] == "Test Video"
        assert row["privacy"] == "private"
        assert row["publishAt"] == "2026-04-10T16:00:00Z"
        assert "tag1" in row["tags"]
        assert row["categoryId"] == "22"

    def test_format_video_row_minimal(self):
        from hamel.youtube_cli import _format_video_row
        item = {"id": "xyz", "snippet": {}, "status": {}}
        row = _format_video_row(item)
        assert row["id"] == "xyz"
        assert row["title"] == ""
        assert row["tags"] == ""

    def test_no_delete_command(self):
        """Verify that no delete command exists."""
        from hamel.youtube_cli import app
        command_names = [cmd.name or cmd.callback.__name__ for cmd in app.registered_commands]
        assert "delete" not in command_names
