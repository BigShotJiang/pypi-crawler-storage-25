#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import datetime
import json
import os
import pathlib
import shutil
import sys

from cryptodatahub.common.entity import Entity, EntityRole

from updaters.trust_stores import UpdaterRootCertificateTrustStore


def _default_output_dir():
    timestamp = datetime.datetime.now(datetime.UTC).strftime("%Y%m%d_%H%M%S")
    return pathlib.Path("artifacts") / f"trust_store_runs_{timestamp}"


def _trust_store_names():
    return sorted([
        owner.name.lower()
        for owner in Entity.get_items_by_role(EntityRole.CA_TRUST_STORE_OWNER)
    ])


def _root_certificate_path():
    return pathlib.Path(__file__).resolve().parent.parent / "cryptodatahub" / "common" / "root-certificate.json"


def _write_empty_root_store(root_certificate_file):
    root_certificate_file.write_text("{}\n", encoding="utf-8")


def _write_json(path, data):
    # Write atomically to avoid truncated JSON if interrupted mid-write.
    temp_path = path.with_suffix(path.suffix + ".tmp")
    temp_path.write_text(json.dumps(data, indent=4), encoding="utf-8")
    os.replace(temp_path, path)


def _load_json(path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def run_workflow(output_dir):
    root_certificate_file = _root_certificate_path()
    output_dir.mkdir(parents=True, exist_ok=True)

    backup_file = output_dir / "root-certificate.original.json"
    merged_file = output_dir / "root-certificate.merged.json"
    metadata_file = output_dir / "run-metadata.json"

    print(f"Root certificate file: {root_certificate_file}", flush=True)
    print(f"Output directory: {output_dir}", flush=True)

    shutil.copy2(root_certificate_file, backup_file)

    stores = _trust_store_names()
    print(f"Detected stores: {' '.join(stores)}", flush=True)

    results = {
        "status": "running",
        "started_at": datetime.datetime.now(datetime.UTC).isoformat(),
        "stores": stores,
        "separate": {},
        "merged": str(merged_file),
    }
    _write_json(metadata_file, results)

    try:
        for store in stores:
            print(f"Running trust store update for: {store}", flush=True)
            _write_empty_root_store(root_certificate_file)
            UpdaterRootCertificateTrustStore(trust_store_owner=Entity[store.upper()])()

            store_output = output_dir / f"root-certificate.{store}.json"
            shutil.copy2(root_certificate_file, store_output)
            results["separate"][store] = str(store_output)
            _write_json(metadata_file, results)

        print("Running merged trust store update for: all", flush=True)
        shutil.copy2(backup_file, root_certificate_file)
        UpdaterRootCertificateTrustStore(trust_store_owner=None)()
        shutil.copy2(root_certificate_file, merged_file)

        results["status"] = "completed"
        results["completed_at"] = datetime.datetime.now(datetime.UTC).isoformat()
        _write_json(metadata_file, results)
        print("Workflow completed successfully.", flush=True)
        return 0
    except Exception as exc:  # pragma: no cover
        print(f"Workflow failed: {exc}", file=sys.stderr, flush=True)
        results["status"] = "failed"
        results["failed_at"] = datetime.datetime.now(datetime.UTC).isoformat()
        results["error"] = str(exc)
        _write_json(metadata_file, results)
        # Always restore on failure so the repository file is not left empty or partial.
        shutil.copy2(backup_file, root_certificate_file)
        return 1


def build_arg_parser():
    parser = argparse.ArgumentParser(
        description=(
            "Generate one root-certificate JSON per trust store from an empty baseline, "
            "then generate the merged JSON and update the repository trust store file."
        )
    )
    parser.add_argument(
        "--output-dir",
        type=pathlib.Path,
        default=_default_output_dir(),
        help="Directory for separate and merged JSON outputs (default: artifacts/trust_store_runs_<timestamp>)",
    )
    return parser


def main():
    parser = build_arg_parser()
    args = parser.parse_args()
    return run_workflow(args.output_dir)


if __name__ == "__main__":
    raise SystemExit(main())
