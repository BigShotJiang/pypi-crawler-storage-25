#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import json
import os
import pathlib
import re
import sys


SEPARATE_FILE_RE = re.compile(r"^root-certificate\.([a-z0-9_]+)\.json$", re.IGNORECASE)


def _load_json(path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_text(path, text):
    temp_path = path.with_suffix(path.suffix + ".tmp")
    temp_path.write_text(text, encoding="utf-8")
    os.replace(temp_path, path)


def _get_trust_store_entries(item, context):
    trust_stores = item.get("trust_stores", [])
    if not isinstance(trust_stores, list):
        raise ValueError(f"{context}: trust_stores must be a list")

    owners = {}
    for trust_store in trust_stores:
        owner = trust_store.get("owner")
        if owner is None:
            raise ValueError(f"{context}: trust_store entry is missing an owner")

        if owner in owners:
            raise ValueError(f"{context}: duplicate trust_store owner {owner}")

        owners[owner] = trust_store.get("constraints", [])

    return owners


def _find_separate_files(separate_dir):
    files = []
    for path in sorted(separate_dir.glob("root-certificate.*.json")):
        match = SEPARATE_FILE_RE.match(path.name)
        if not match:
            continue

        store_name = match.group(1).upper()
        if store_name in {"MERGED", "ORIGINAL"}:
            continue

        files.append((store_name, path))

    return files


def compare_separate_to_merged(separate_dir, merged_file):
    merged_data = _load_json(merged_file)
    separate_files = _find_separate_files(separate_dir)

    if not separate_files:
        raise ValueError(
            f"No separate trust store files found in {separate_dir} "
            f"(expected files like root-certificate.apple.json)"
        )

    errors = []
    summary = []

    separate_index = {
        store_name: _load_json(path)
        for store_name, path in separate_files
    }

    def _compare_store_file(store_name, separate_file, separate_data):
        checked_local = 0
        for identifier, separate_item in separate_data.items():
            checked_local += 1
            separate_context = f"[{store_name}] Separate file {separate_file} certificate {identifier}"

            merged_item = merged_data.get(identifier)
            if merged_item is None:
                errors.append(f"[{store_name}] Missing certificate in merged file: {identifier}")
                continue

            try:
                separate_constraints_by_owner = _get_trust_store_entries(separate_item, separate_context)
                merged_constraints_by_owner = _get_trust_store_entries(
                    merged_item, f"[MERGED] Certificate {identifier}"
                )
            except ValueError as exc:
                errors.append(str(exc))
                continue

            separate_owners = set(separate_constraints_by_owner.keys())
            if separate_owners != {store_name}:
                errors.append(
                    f"[{store_name}] Separate file has unexpected owners for {identifier}: {sorted(separate_owners)}"
                )
                continue

            if store_name not in merged_constraints_by_owner:
                errors.append(f"[{store_name}] Merged file missing owner {store_name} for {identifier}")
                continue

            if merged_constraints_by_owner[store_name] != separate_constraints_by_owner[store_name]:
                errors.append(f"[{store_name}] Constraint mismatch for {identifier}")

        return checked_local

    for store_name, separate_file in separate_files:
        separate_data = separate_index[store_name]
        checked = _compare_store_file(store_name, separate_file, separate_data)
        summary.append((store_name, separate_file, checked))

    def _verify_merged_consistency():
        store_names_local = set(separate_index.keys())
        for identifier, merged_item in merged_data.items():
            try:
                merged_constraints_by_owner = _get_trust_store_entries(
                    merged_item, f"[MERGED] Certificate {identifier}"
                )
            except ValueError as exc:
                errors.append(str(exc))
                continue

            merged_store_owners = {owner for owner in merged_constraints_by_owner if owner in store_names_local}

            expected_store_owners = {
                store_name for store_name, store_data in separate_index.items() if identifier in store_data
            }

            if merged_store_owners != expected_store_owners:
                errors.append(
                    f"[MERGED] Owner list mismatch for {identifier}: "
                    f"expected {sorted(expected_store_owners)}, got {sorted(merged_store_owners)}"
                )
                continue

            for owner in expected_store_owners:
                separate_constraints = _get_trust_store_entries(
                    separate_index[owner][identifier], f"[{owner}] Separate file certificate {identifier}"
                )[owner]
                if merged_constraints_by_owner[owner] != separate_constraints:
                    errors.append(f"[MERGED] Constraint mismatch for {identifier} owner {owner}")

    _verify_merged_consistency()

    return errors, summary


def _build_report(separate_dir, merged_file, errors, summary):
    store_summaries = [
        {
            "store": store_name,
            "file": str(separate_file),
            "checked": checked,
        }
        for store_name, separate_file, checked in summary
    ]
    total_checked = sum(item["checked"] for item in store_summaries)
    return {
        "status": "passed" if not errors else "failed",
        "separate_dir": str(separate_dir),
        "merged_file": str(merged_file),
        "store_summaries": store_summaries,
        "total_checked": total_checked,
        "error_count": len(errors),
        "errors": errors,
    }


def _report_paths(separate_dir):
    return {
        "json": separate_dir / "trust-store-comparison-report.json",
        "text": separate_dir / "trust-store-comparison-report.txt",
    }


def _write_reports(separate_dir, merged_file, errors, summary):
    report = _build_report(separate_dir, merged_file, errors, summary)
    report_paths = _report_paths(separate_dir)

    _write_text(report_paths["json"], json.dumps(report, indent=4) + "\n")

    lines = [
        f"Status: {report['status'].upper()}",
        f"Separate directory: {report['separate_dir']}",
        f"Merged file: {report['merged_file']}",
        f"Total certificates checked: {report['total_checked']}",
        f"Error count: {report['error_count']}",
        "",
        "Per-store summary:",
    ]
    for item in report["store_summaries"]:
        lines.append(f"- {item['store']}: {item['checked']} certificates ({item['file']})")

    if errors:
        lines.extend([
            "",
            "Errors:",
        ])
        for error in errors:
            lines.append(f"- {error}")

    _write_text(report_paths["text"], "\n".join(lines) + "\n")

    return report_paths


def build_arg_parser():
    parser = argparse.ArgumentParser(
        description=(
            "Verify that all certificates from per-store root-certificate JSON files "
            "exist in the merged file with the proper trust-store owner and constraints."
        )
    )
    parser.add_argument(
        "--separate-dir",
        required=True,
        type=pathlib.Path,
        help="Directory containing files like root-certificate.apple.json",
    )
    parser.add_argument(
        "--merged-file",
        required=True,
        type=pathlib.Path,
        help="Path to merged root-certificate JSON (for example root-certificate.merged.json)",
    )
    return parser


def main():
    parser = build_arg_parser()
    args = parser.parse_args()

    if not args.separate_dir.is_dir():
        parser.error(f"--separate-dir is not a directory: {args.separate_dir}")

    if not args.merged_file.is_file():
        parser.error(f"--merged-file does not exist: {args.merged_file}")

    try:
        errors, summary = compare_separate_to_merged(args.separate_dir, args.merged_file)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    report_paths = _write_reports(args.separate_dir, args.merged_file, errors, summary)

    for store_name, separate_file, checked in summary:
        print(f"Checked {checked:5d} certificates from {store_name:10s} -> {separate_file}")

    if errors:
        print("\nValidation FAILED:")
        for error in errors:
            print(f" - {error}")
        print(f"\nReport written to: {report_paths['json']}")
        print(f"Text report written to: {report_paths['text']}")
        return 1

    print(
        "\nValidation PASSED: all separate trust-store certificates exist in merged JSON with proper owner/constraints."
    )
    print(f"Report written to: {report_paths['json']}")
    print(f"Text report written to: {report_paths['text']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
