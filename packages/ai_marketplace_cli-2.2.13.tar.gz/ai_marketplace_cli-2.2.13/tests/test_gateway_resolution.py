"""Tests for shared gateway URL resolution (login defaults and auth fallbacks)."""

from __future__ import annotations

from pathlib import Path

import pytest

import aimp_cli.core.config as config_module
from aimp_cli.core.config import ConfigStore, resolve_auth_context
from aimp_cli.core.errors import CliError
from aimp_cli.domain.models import LOCAL_GATEWAY_URL
from aimp_cli.utils.gateway_resolution import (
    LEGACY_CLOUD_RUN_STAGE_WARNING,
    legacy_saved_gateway_warning,
    parse_stage_public_env_file,
    resolve_fallback_gateway_url,
    resolve_login_gateway_url,
    validate_stage_public_gateway_url,
)
from aimp_cli.utils.stage_runtime_state import write_local_stage_runtime_state


def _touch_monorepo_layout(root: Path) -> None:
    (root / "packages" / "python" / "cli" / "pyproject.toml").parent.mkdir(
        parents=True, exist_ok=True
    )
    (root / "packages" / "python" / "framework" / "pyproject.toml").parent.mkdir(
        parents=True, exist_ok=True
    )
    (root / "packages" / "python" / "sdk" / "pyproject.toml").parent.mkdir(
        parents=True, exist_ok=True
    )
    (root / "packages" / "python" / "cli" / "pyproject.toml").write_text(
        "[project]\nname='cli'\n", encoding="utf-8"
    )
    (root / "packages" / "python" / "framework" / "pyproject.toml").write_text(
        "[project]\nname='fw'\n", encoding="utf-8"
    )
    (root / "packages" / "python" / "sdk" / "pyproject.toml").write_text(
        "[project]\nname='sdk'\n", encoding="utf-8"
    )


def _write_public_env(root: Path, content: str) -> Path:
    path = root / "infra" / "vm" / "stage.public.env"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def test_parse_stage_public_env_file_skips_comments_and_blank(tmp_path: Path) -> None:
    p = tmp_path / "stage.public.env"
    p.write_text(
        "\n# comment\nSTAGE_GATEWAY_PUBLIC_URL=http://example.com\n\nFOO=bar\n",
        encoding="utf-8",
    )
    assert parse_stage_public_env_file(p) == {
        "STAGE_GATEWAY_PUBLIC_URL": "http://example.com",
        "FOO": "bar",
    }


def test_resolve_login_public_file_when_no_runtime(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _touch_monorepo_layout(tmp_path)
    _write_public_env(tmp_path, "STAGE_GATEWAY_PUBLIC_URL=http://35.195.58.52\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("AIMP_GATEWAY_URL", raising=False)
    assert resolve_login_gateway_url() == "http://35.195.58.52"


def test_resolve_login_runtime_over_public_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _touch_monorepo_layout(tmp_path)
    _write_public_env(tmp_path, "STAGE_GATEWAY_PUBLIC_URL=http://35.195.58.52\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("AIMP_GATEWAY_URL", raising=False)
    write_local_stage_runtime_state(tmp_path, gateway_url="http://localhost:8080")
    assert resolve_login_gateway_url() == "http://localhost:8080"


def test_resolve_fallback_matches_login_without_flag_or_env(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _touch_monorepo_layout(tmp_path)
    _write_public_env(tmp_path, "STAGE_GATEWAY_PUBLIC_URL=http://35.195.58.52\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("AIMP_GATEWAY_URL", raising=False)
    assert resolve_fallback_gateway_url() == resolve_login_gateway_url()
    assert resolve_fallback_gateway_url() == "http://35.195.58.52"


def test_public_file_api_path_rejected(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _touch_monorepo_layout(tmp_path)
    _write_public_env(tmp_path, "STAGE_GATEWAY_PUBLIC_URL=http://35.195.58.52/api\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("AIMP_GATEWAY_URL", raising=False)
    with pytest.raises(CliError) as excinfo:
        resolve_login_gateway_url()
    assert excinfo.value.code == "invalid_stage_public_gateway_url"


def test_public_file_localhost_rejected() -> None:
    with pytest.raises(CliError) as excinfo:
        validate_stage_public_gateway_url("http://localhost:8080", source="test")
    assert excinfo.value.code == "invalid_stage_public_gateway_url"


def test_public_file_private_ip_rejected() -> None:
    with pytest.raises(CliError) as excinfo:
        validate_stage_public_gateway_url("http://10.0.0.1", source="test")
    assert excinfo.value.code == "invalid_stage_public_gateway_url"


def test_public_file_no_scheme_rejected() -> None:
    with pytest.raises(CliError) as excinfo:
        validate_stage_public_gateway_url("35.195.58.52", source="test")
    assert excinfo.value.code == "invalid_stage_public_gateway_url"


def test_resolve_login_gateway_flag_wins_over_all(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _touch_monorepo_layout(tmp_path)
    _write_public_env(tmp_path, "STAGE_GATEWAY_PUBLIC_URL=http://35.195.58.52\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AIMP_GATEWAY_URL", "http://localhost:8080")
    write_local_stage_runtime_state(tmp_path, gateway_url="http://127.0.0.1:1")
    assert resolve_login_gateway_url(gateway_flag="http://custom-gateway.example") == "http://custom-gateway.example"


def test_outside_monorepo_fallback_localhost(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("AIMP_GATEWAY_URL", raising=False)
    assert resolve_login_gateway_url() == LOCAL_GATEWAY_URL


def test_resolve_auth_context_uses_public_fallback_when_no_config(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _touch_monorepo_layout(tmp_path)
    _write_public_env(tmp_path, "STAGE_GATEWAY_PUBLIC_URL=http://35.195.58.52\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        config_module,
        "config_store",
        ConfigStore(path=tmp_path / "no-cli-config.json"),
    )
    monkeypatch.delenv("AIMP_GATEWAY_URL", raising=False)
    monkeypatch.delenv("AIMP_API_KEY", raising=False)
    ctx = resolve_auth_context(gateway=None, api_key=None)
    assert ctx.gateway_url == "http://35.195.58.52"


def test_legacy_saved_gateway_warning_for_cloud_run_config(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _touch_monorepo_layout(tmp_path)
    _write_public_env(tmp_path, "STAGE_GATEWAY_PUBLIC_URL=http://35.195.58.52\n")
    monkeypatch.chdir(tmp_path)

    warning = legacy_saved_gateway_warning("https://aimp-stage-gateway-example-ew.a.run.app")

    assert warning == LEGACY_CLOUD_RUN_STAGE_WARNING


def test_legacy_saved_gateway_warning_ignores_custom_gateway(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _touch_monorepo_layout(tmp_path)
    _write_public_env(tmp_path, "STAGE_GATEWAY_PUBLIC_URL=http://35.195.58.52\n")
    monkeypatch.chdir(tmp_path)

    assert legacy_saved_gateway_warning("https://api.customer.example") is None
