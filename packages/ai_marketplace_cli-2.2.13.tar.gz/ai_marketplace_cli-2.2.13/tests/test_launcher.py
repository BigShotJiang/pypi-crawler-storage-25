"""Tests for the interactive launcher."""

from __future__ import annotations

from collections.abc import Callable
from io import StringIO
from types import SimpleNamespace
from typing import Any, cast

import pytest
from rich.console import Console

import aimp_cli.core.launcher as launcher_module
from aimp_cli.core.launcher import (
    COMPACT_HEADER,
    LauncherActionResult,
    LauncherNavigationRequest,
    LauncherOption,
    LauncherSection,
    TerminalUI,
    _LauncherState,
    _MultiLauncherState,
)


def _require_prompt_toolkit_symbols() -> None:
    if (
        launcher_module.TextArea is Any
        or launcher_module.KeyBindings is Any
        or launcher_module.Window is Any
    ):
        pytest.skip("prompt_toolkit runtime symbols are unavailable in this environment")


def _build_sections(
    handler: Callable[[], LauncherActionResult | LauncherNavigationRequest | None],
) -> list[LauncherSection]:
    return [
        LauncherSection(
            title="Project",
            options=[
                LauncherOption(
                    key="init",
                    label="Init project",
                    description="Create a new model scaffold",
                    handler=handler,
                ),
                LauncherOption(
                    key="quit",
                    label="Quit",
                    description="Exit the launcher",
                    handler=lambda: None,
                ),
            ],
        )
    ]


def test_render_screen_wide_mode_shows_ascii_header_and_description() -> None:
    options = [
        LauncherOption(
            key="init",
            label="Create project",
            description="Create a new model scaffold",
            handler=lambda: None,
        ),
        LauncherOption(
            key="publish",
            label="Publish current project",
            description="Build and publish the current project",
            handler=lambda: None,
        ),
    ]
    screen = launcher_module._render_screen(
        _LauncherState(
            sections=[LauncherSection(title="Project", options=options)],
            options=options,
        ),
        width=110,
    )
    assert "████" in screen
    assert "Create project" in screen
    assert "Publish current project" in screen
    assert "Create a new model scaffold" in screen


def test_render_screen_compact_mode_uses_compact_header() -> None:
    option = LauncherOption(
        key="inspect",
        label="Inspect model",
        description="Review remote model metadata.",
        handler=lambda: None,
    )

    screen = launcher_module._render_screen(
        _LauncherState(
            sections=[LauncherSection(title="Models", options=[option])],
            options=[option],
        ),
        width=80,
    )

    assert "████" not in screen
    assert COMPACT_HEADER in screen
    assert "Marketplace model tooling" in screen


def test_render_screen_minimal_mode_uses_text_header() -> None:
    option = LauncherOption(
        key="login",
        label="Login",
        description="Authenticate with the platform.",
        handler=lambda: None,
    )

    screen = launcher_module._render_screen(
        _LauncherState(
            sections=[LauncherSection(title="Account", options=[option])],
            options=[option],
        ),
        width=60,
    )

    assert "████" not in screen
    assert COMPACT_HEADER not in screen
    assert "AIMP" in screen


def test_render_screen_embedded_mode_hides_header() -> None:
    options = [
        LauncherOption(
            key="private",
            label="private",
            description="Workspace only",
            handler=lambda: None,
        ),
        LauncherOption(
            key="public",
            label="public",
            description="Marketplace visible",
            handler=lambda: None,
        ),
    ]

    screen = launcher_module._render_screen(
        _LauncherState(
            sections=[LauncherSection(title="Visibility", options=options)],
            options=options,
        ),
        show_header=False,
        title="Visibility",
    )

    assert "████" not in screen
    assert COMPACT_HEADER not in screen
    assert "VISIBILITY" in screen
    assert "Workspace only" in screen


def test_render_multi_select_screen_shows_option_details() -> None:
    options = [
        LauncherOption(
            key="cpu-basic",
            label="CPU Basic",
            description="cpu-basic · $0.05/hr · CPU tier",
            handler=lambda: None,
        ),
        LauncherOption(
            key="cpu-performance",
            label="CPU Performance",
            description="cpu-performance · $0.10/hr · CPU tier",
            handler=lambda: None,
        ),
    ]

    screen = launcher_module._render_multi_select_screen(
        _MultiLauncherState(
            sections=[LauncherSection(title="Supported Hardware", options=options)],
            options=options,
            selected_keys={"cpu-performance"},
        ),
        show_header=False,
        title="Supported Hardware",
    )

    assert "SUPPORTED HARDWARE" in screen
    assert "[x] CPU Performance" in screen
    assert "[ ] CPU Basic" in screen
    assert "cpu-basic" in screen
    assert "$0.05/hr" in screen


def test_prompt_text_uses_compact_application_layout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _require_prompt_toolkit_symbols()
    captured: list[dict[str, Any]] = []

    class SpyApplication:
        def __init__(self, **kwargs: Any) -> None:
            captured.append(kwargs)
            self.output = SimpleNamespace(
                get_size=lambda: SimpleNamespace(columns=100),
            )

        def run(self) -> None:
            return None

    monkeypatch.setattr(launcher_module, "Application", SpyApplication)
    monkeypatch.setattr(launcher_module, "_PROMPT_TOOLKIT_AVAILABLE", True)
    monkeypatch.setattr(launcher_module, "has_interactive_terminal", lambda: True)

    TerminalUI().prompt_text(
        "Project name",
        title="Create project",
        subtitle="Choose the directory name for the new model project.",
    )

    application_kwargs = captured[0]
    assert application_kwargs["full_screen"] is False

    layout = application_kwargs["layout"]
    assert layout.container.__class__.__name__ == "HSplit"
    body_window, input_field, footer_window = layout.container.children

    body_window = cast(Any, body_window)
    input_field = cast(Any, input_field)
    footer_window = cast(Any, footer_window)

    assert body_window.dont_extend_height() is True
    assert getattr(input_field.height, "preferred", input_field.height) == 1
    assert input_field.dont_extend_height() is True
    assert getattr(footer_window.height, "preferred", footer_window.height) == 2
    assert footer_window.dont_extend_height() is True


def test_select_menu_keeps_full_screen_application(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _require_prompt_toolkit_symbols()
    captured: list[dict[str, Any]] = []

    class SpyApplication:
        def __init__(self, **kwargs: Any) -> None:
            captured.append(kwargs)
            self.output = SimpleNamespace(
                get_size=lambda: SimpleNamespace(columns=100),
            )

        def run(self) -> None:
            return None

    monkeypatch.setattr(launcher_module, "Application", SpyApplication)
    monkeypatch.setattr(launcher_module, "_PROMPT_TOOLKIT_AVAILABLE", True)
    monkeypatch.setattr(launcher_module, "has_interactive_terminal", lambda: True)

    TerminalUI().select_menu(
        _build_sections(lambda: None),
        title="Project",
    )

    assert captured[0]["full_screen"] is True


def test_show_detail_uses_full_screen_application(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _require_prompt_toolkit_symbols()
    captured: list[dict[str, Any]] = []

    class SpyApplication:
        def __init__(self, **kwargs: Any) -> None:
            captured.append(kwargs)
            self.output = SimpleNamespace(
                get_size=lambda: SimpleNamespace(columns=100),
            )

        def run(self) -> str:
            return "back"

    monkeypatch.setattr(launcher_module, "Application", SpyApplication)
    monkeypatch.setattr(launcher_module, "_PROMPT_TOOLKIT_AVAILABLE", True)
    monkeypatch.setattr(launcher_module, "has_interactive_terminal", lambda: True)

    result = TerminalUI().show_detail(
        LauncherActionResult(
            title="Configure Project",
            subtitle="Synchronize local project files.",
            content="Wrote: contract.toml",
            status="success",
        )
    )

    assert result == "back"
    assert captured[0]["full_screen"] is True


def test_confirm_action_uses_semantic_labels(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_select_menu(
        self,
        sections: list[LauncherSection],
        *,
        show_header: bool = True,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> LauncherOption | None:
        _ = self, show_header, title, subtitle, details
        captured["labels"] = [option.label for option in sections[0].options]
        return sections[0].options[0]

    monkeypatch.setattr(TerminalUI, "select_menu", fake_select_menu)

    confirmed = TerminalUI().confirm_action(
        "Support Vector DB?",
        confirm_label="Support Vector DB",
        cancel_label="No Vector DB",
        confirm_description="Expose vector indexing and search.",
        cancel_description="Keep execute-only behavior.",
    )

    assert confirmed is True
    assert captured["labels"] == ["Support Vector DB", "No Vector DB"]


def test_confirm_action_honors_default_order(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_select_menu(
        self,
        sections: list[LauncherSection],
        *,
        show_header: bool = True,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> LauncherOption | None:
        _ = self, show_header, title, subtitle, details
        captured["labels"] = [option.label for option in sections[0].options]
        return sections[0].options[0]

    monkeypatch.setattr(TerminalUI, "select_menu", fake_select_menu)

    confirmed = TerminalUI().confirm_action(
        "Create project?",
        default=False,
        confirm_label="Create Project",
        cancel_label="Cancel",
    )

    assert confirmed is False
    assert captured["labels"] == ["Cancel", "Create Project"]


def test_run_interactive_launcher_dispatches_then_exits(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output = StringIO()
    console = Console(file=output, force_terminal=False, width=120)
    calls: list[str] = []

    def handler() -> None:
        calls.append("init")

    responses = iter(
        [
            LauncherOption(
                key="init",
                label="Init project",
                description="Create a new model scaffold",
                handler=handler,
            ),
            LauncherOption(
                key="quit",
                label="Quit",
                description="Exit the launcher",
                handler=lambda: None,
            ),
        ]
    )
    monkeypatch.setattr(
        launcher_module,
        "select_menu",
        lambda sections, **kwargs: next(responses),
    )
    launcher_module.run_interactive_launcher(
        lambda: _build_sections(handler),
        console=console,
    )
    assert calls == ["init"]


def test_run_interactive_launcher_shows_detail_and_stays_in_menu_on_back(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output = StringIO()
    console = Console(file=output, force_terminal=False, width=120)
    calls: list[str] = []
    select_calls: list[str] = []

    def handler() -> LauncherActionResult:
        calls.append("init")
        return LauncherActionResult(
            title="Init project",
            content="Created project demo-model.",
            status="success",
        )

    responses = iter(
        [
            LauncherOption(
                key="init",
                label="Init project",
                description="Create a new model scaffold",
                handler=handler,
            ),
            LauncherOption(
                key="quit",
                label="Quit",
                description="Exit the launcher",
                handler=lambda: None,
            ),
        ]
    )

    def fake_select_menu(sections, **kwargs):
        _ = sections, kwargs
        select_calls.append("select")
        return next(responses)

    detail_calls: list[LauncherActionResult] = []

    monkeypatch.setattr(launcher_module, "select_menu", fake_select_menu)
    monkeypatch.setattr(
        launcher_module._DEFAULT_UI,
        "show_detail",
        lambda result, show_header=True: detail_calls.append(result) or "back",
    )

    nav = launcher_module.run_interactive_launcher(
        lambda: _build_sections(handler),
        console=console,
    )

    assert nav == "quit"
    assert calls == ["init"]
    assert len(select_calls) == 2
    assert detail_calls[0].content == "Created project demo-model."


def test_run_interactive_launcher_returns_home_from_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output = StringIO()
    console = Console(file=output, force_terminal=False, width=120)

    option = LauncherOption(
        key="show",
        label="Show contract",
        description="Inspect the local contract",
        handler=lambda: LauncherActionResult(
            title="Show Contract",
            content="schema_version = 2",
            status="info",
        ),
    )
    monkeypatch.setattr(
        launcher_module,
        "select_menu",
        lambda sections, **kwargs: option,
    )
    monkeypatch.setattr(
        launcher_module._DEFAULT_UI,
        "show_detail",
        lambda result, show_header=True: "home",
    )

    nav = launcher_module.run_interactive_launcher(
        lambda: [LauncherSection(title="Project", options=[option])],
        console=console,
    )

    assert nav == "home"


def test_run_interactive_launcher_falls_back_to_plain_menu(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output = StringIO()
    console = Console(file=output, force_terminal=False, width=120)

    monkeypatch.setattr(
        launcher_module,
        "select_menu",
        lambda sections, **kwargs: (_ for _ in ()).throw(RuntimeError("selector unavailable")),
    )
    monkeypatch.setattr(
        launcher_module,
        "_select_option_fallback",
        lambda sections, console, show_header=True, title=None, subtitle=None: None,
    )
    launcher_module.run_interactive_launcher(
        lambda: _build_sections(lambda: None),
        console=console,
    )
    assert "Falling back to plain menu" in output.getvalue()
