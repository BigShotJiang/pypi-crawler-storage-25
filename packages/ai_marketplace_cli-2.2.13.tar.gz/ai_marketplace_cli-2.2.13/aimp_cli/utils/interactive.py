"""High-level interactive launcher flows."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from rich.console import Console

from aimp_cli.core.config import ConfigStore
from aimp_cli.core.launcher import (
    LauncherActionResult,
    LauncherNavigationRequest,
    LauncherOption,
    LauncherSection,
    confirm_action,
    prompt_secret,
    prompt_text,
    run_interactive_launcher,
)
from aimp_cli.domain.constants import PROJECT_CONFIG_RELATIVE_PATH
from aimp_cli.utils.gateway_resolution import resolve_login_gateway_url


@dataclass(frozen=True, slots=True)
class LauncherCallbacks:
    """Command callbacks used by the interactive launcher."""

    init_project: Callable[[str], LauncherActionResult | None]
    configure_publish: Callable[[str | None], LauncherActionResult | None]
    publish_project: Callable[[], LauncherActionResult | None]
    create_fine_tune_job: Callable[[str, str], LauncherActionResult | None]
    list_jobs: Callable[[str], list[LauncherJobItem] | LauncherActionResult | None]
    get_job_detail: Callable[[str, str], LauncherActionResult | None]
    watch_job: Callable[[str, str], None]
    cancel_job: Callable[[str, str], LauncherActionResult | None]
    delete_job: Callable[[str, str], LauncherActionResult | None]
    login: Callable[[str, str], LauncherActionResult | None]
    auth: Callable[[], LauncherActionResult | None]
    logout: Callable[[], LauncherActionResult | None]
    inspect_model: Callable[[str], LauncherActionResult | None]
    pull_model: Callable[[str], LauncherActionResult | None]
    list_active_build: Callable[[str], dict[str, Any] | None]
    cancel_build: Callable[[str], LauncherActionResult | None]


@dataclass(frozen=True, slots=True)
class LauncherJobItem:
    """Structured job row used by the interactive launcher."""

    job_id: str
    job_type: str
    model_slug: str
    status: str
    created_at: str | None = None


def _find_active_fine_tune_from_launcher(
    *,
    callbacks: LauncherCallbacks,
    model_slug: str,
) -> LauncherJobItem | None:
    """Check for an active fine-tune job for the given model slug."""
    jobs_or_error = callbacks.list_jobs("fine-tune")
    if isinstance(jobs_or_error, LauncherActionResult):
        return None
    for item in jobs_or_error or []:
        if (
            item.model_slug == model_slug
            and item.job_type == "fine-tune"
            and item.status in {"queued", "running"}
        ):
            return item
    return None


def interactive_launcher(
    *,
    console: Console,
    config_store: ConfigStore,
    callbacks: LauncherCallbacks,
) -> None:
    """Run the interactive launcher flow for human TTY usage."""

    def launcher_init() -> LauncherActionResult | None:
        name = prompt_text(
            "Project name",
            console=console,
            show_header=False,
            title="Create Project",
            subtitle="Choose the directory name for the new model project.",
        )
        if name is None:
            return
        if not confirm_action(
            f"Create project '{name}'?",
            console=console,
            show_header=False,
            confirm_label="Create Project",
            cancel_label="Cancel",
            confirm_description="Scaffold a new model project with this name.",
            cancel_description="Return without creating a project.",
            title="Confirm Project Creation",
        ):
            return
        return callbacks.init_project(name)

    def launcher_publish() -> LauncherActionResult | None:
        active_build = callbacks.list_active_build("")
        if active_build is not None:
            job_id = str(active_build.get("job_id") or "").strip()
            job_status = str(active_build.get("status") or "queued").strip()
            created_at = str(active_build.get("created_at") or "").strip()
            slug = str(active_build.get("slug") or active_build.get("model_slug") or "").strip()
            subtitle = f"Job {job_id[:8]} is {job_status}"
            if created_at:
                subtitle += f" · Created {created_at}"
            confirmed = confirm_action(
                f"Cancel the active build for '{slug}' and publish again?",
                console=console,
                confirm_label="Cancel old build and publish",
                cancel_label="Keep existing build",
                confirm_description="Cancel the active build and start a fresh publish.",
                cancel_description="Keep the current build and exit.",
                title="Active Build Conflict",
                subtitle=subtitle,
            )
            if not confirmed:
                return None
            cancel_result = callbacks.cancel_build(job_id)
            if cancel_result is not None and cancel_result.status == "error":
                return cancel_result
        return callbacks.publish_project()

    def launcher_project_settings() -> LauncherNavigationRequest | LauncherActionResult | None:
        options = [
            LauncherOption(
                key="name",
                label="Name",
                description="Change the marketplace display name only.",
                handler=lambda: callbacks.configure_publish("name"),
            ),
            LauncherOption(
                key="article",
                label="Article",
                description="Change the Studio MDX article path only.",
                handler=lambda: callbacks.configure_publish("article"),
            ),
            LauncherOption(
                key="hardware",
                label="Hardware",
                description="Choose the deployment hardware tier.",
                handler=lambda: callbacks.configure_publish("hardware"),
            ),
            LauncherOption(
                key="tags",
                label="Tags",
                description="Change discovery tags only.",
                handler=lambda: callbacks.configure_publish("tags"),
            ),
            LauncherOption(
                key="visibility",
                label="Visibility",
                description="Switch between private and public listing.",
                handler=lambda: callbacks.configure_publish("visibility"),
            ),
            LauncherOption(
                key="pricing",
                label="Pricing",
                description="Change developer margin only.",
                handler=lambda: callbacks.configure_publish("pricing"),
            ),
            LauncherOption(
                key="review",
                label="Review current settings",
                description="Show the saved project settings without changing anything.",
                handler=lambda: callbacks.configure_publish("review"),
            ),
            LauncherOption(
                key="back",
                label="Back",
                description="Return to the main menu.",
                handler=lambda: None,
            ),
        ]
        nav_action = run_interactive_launcher(
            lambda: [LauncherSection(title="Project Settings", options=options)],
            console=console,
            show_header=False,
            title="Project Settings",
            subtitle="Change one project setting at a time.",
            cancel_action="back",
        )
        if nav_action == "quit":
            return LauncherNavigationRequest(action="quit")
        return None

    def launcher_fine_tune_create() -> LauncherActionResult | None:
        model_slug = prompt_text(
            "Model slug",
            console=console,
            show_header=False,
            title="Create Fine-tune Job",
            subtitle="Enter the published model slug to fine-tune.",
        )
        if model_slug is None:
            return
        active_ft = _find_active_fine_tune_from_launcher(callbacks=callbacks, model_slug=model_slug)
        if active_ft is not None:
            job_id = active_ft.job_id
            job_status = active_ft.status
            created_at = active_ft.created_at or ""
            subtitle = f"Job {job_id[:8]} is {job_status}"
            if created_at:
                subtitle += f" · Created {created_at}"
            confirmed = confirm_action(
                f"Cancel the active fine-tune for '{model_slug}' and start a new one?",
                console=console,
                confirm_label="Cancel old job",
                cancel_label="Keep existing job",
                confirm_description="Cancel the active fine-tune and start a fresh one.",
                cancel_description="Keep the current fine-tune and exit.",
                title="Active Fine-tune Conflict",
                subtitle=subtitle,
            )
            if not confirmed:
                return None
            cancel_result = callbacks.cancel_job("fine-tune", job_id)
            if cancel_result is not None and cancel_result.status == "error":
                return cancel_result
        dataset_path = prompt_text(
            "Bundle or workspace",
            console=console,
            show_header=False,
            title="Create Fine-tune Job",
            subtitle="Enter a local bundle.json path or a workspace directory that contains it.",
        )
        if dataset_path is None:
            return
        return callbacks.create_fine_tune_job(model_slug, dataset_path)

    _ACTIVE_JOB_STATUSES = {"queued", "running"}
    _TERMINAL_JOB_STATUSES = {"succeeded", "failed", "canceled"}

    def _launcher_job_action(item: LauncherJobItem) -> LauncherNavigationRequest | LauncherActionResult | None:
        """Show a per-job action submenu (View Details / Cancel / Delete)."""
        is_active = item.status in _ACTIVE_JOB_STATUSES

        def job_view_detail() -> LauncherActionResult | None:
            if item.status in _ACTIVE_JOB_STATUSES:
                callbacks.watch_job(item.job_type, item.job_id)
                return None
            return callbacks.get_job_detail(item.job_type, item.job_id)

        def job_cancel() -> LauncherActionResult | None:
            confirmed = confirm_action(
                f"Cancel job {item.job_id[:8]}?",
                console=console,
                show_header=False,
                confirm_label="Cancel Job",
                cancel_label="Keep Job",
                confirm_description=f"Cancel the {item.status} {item.job_type} job for '{item.model_slug}'.",
                cancel_description="Return without canceling.",
                title="Cancel Job",
                subtitle=f"{item.job_type} · {item.model_slug} · {item.status}",
            )
            if not confirmed:
                return None
            return callbacks.cancel_job(item.job_type, item.job_id)

        def job_delete() -> LauncherActionResult | None:
            confirmed = confirm_action(
                f"Delete job {item.job_id[:8]}?",
                console=console,
                show_header=False,
                confirm_label="Delete Job",
                cancel_label="Keep Job",
                confirm_description=f"Permanently remove the {item.job_type} job for '{item.model_slug}' from history.",
                cancel_description="Return without deleting.",
                title="Delete Job",
                subtitle=f"{item.job_type} · {item.model_slug} · {item.status}",
            )
            if not confirmed:
                return None
            return callbacks.delete_job(item.job_type, item.job_id)

        job_options: list[LauncherOption] = [
            LauncherOption(
                key="view",
                label="View Details",
                description=(
                    f"Stream live logs until this job finishes (status: {item.status})."
                    if is_active
                    else f"Show full details for job {item.job_id[:8]}."
                ),
                handler=job_view_detail,
            ),
        ]
        if is_active:
            job_options.append(
                LauncherOption(
                    key="cancel",
                    label="Cancel Job",
                    description=f"Cancel the {item.status} job and stop execution.",
                    handler=job_cancel,
                )
            )
        else:
            job_options.append(
                LauncherOption(
                    key="delete",
                    label="Delete Job",
                    description="Remove this finished job from history.",
                    handler=job_delete,
                )
            )
        job_options.append(
            LauncherOption(
                key="back",
                label="Go Back",
                description="Return to the job list.",
                handler=lambda: None,
            )
        )

        nav_action = run_interactive_launcher(
            lambda: [LauncherSection(title="Job Actions", options=job_options)],
            console=console,
            show_header=False,
            title=f"{item.model_slug} · {item.status}",
            subtitle=f"{item.job_type} · ID {item.job_id[:8]}" + (f" · Created: {item.created_at[:16].replace('T', ' ')}" if item.created_at else ""),
            cancel_action="back",
        )
        if nav_action == "quit":
            return LauncherNavigationRequest(action="quit")
        if nav_action == "home":
            return LauncherNavigationRequest(action="home")
        return None

    def launcher_jobs_browse() -> LauncherNavigationRequest | LauncherActionResult | None:
        jobs_or_error = callbacks.list_jobs("all")
        if isinstance(jobs_or_error, LauncherActionResult):
            return jobs_or_error

        jobs = jobs_or_error or []

        if not jobs:
            return LauncherActionResult(
                title="Jobs",
                content="No jobs found in the current workspace.",
                status="info",
            )

        def build_job_label(item: LauncherJobItem) -> str:
            return f"[{item.job_type}] {item.model_slug} ({item.job_id[:8]}) · {item.status}"

        def build_job_description(item: LauncherJobItem) -> str:
            created_at = item.created_at or "Unknown time"
            return f"Created: {created_at}"

        options = [
            LauncherOption(
                key=f"{item.job_type}:{item.job_id}",
                label=build_job_label(item),
                description=build_job_description(item),
                handler=lambda item=item: _launcher_job_action(item),
            )
            for item in jobs
        ]
        nav_action = run_interactive_launcher(
            lambda: [LauncherSection(title="Jobs", options=options)],
            console=console,
            show_header=False,
            title="Jobs",
            subtitle="Select a job to view details, cancel, or delete.",
            cancel_action="back",
        )
        if nav_action == "quit":
            return LauncherNavigationRequest(action="quit")
        if nav_action == "home":
            return LauncherNavigationRequest(action="home")
        return None

    def launcher_login() -> LauncherActionResult | None:
        gateway = prompt_text(
            "Gateway URL",
            console=console,
            default=resolve_login_gateway_url(gateway_flag=None),
            show_header=False,
            title="Login",
            subtitle="Enter the Gateway URL used for authentication.",
        )
        if gateway is None:
            return
        api_key = prompt_secret(
            "API key",
            console=console,
            show_header=False,
            title="Login",
            subtitle="Paste the API key for this machine.",
        )
        if api_key is None:
            return
        return callbacks.login(gateway, api_key)

    def launcher_auth() -> LauncherActionResult | None:
        return callbacks.auth()

    def launcher_logout() -> LauncherActionResult | None:
        if confirm_action(
            "Are you sure you want to log out?",
            console=console,
            show_header=False,
            confirm_label="Log Out",
            cancel_label="Keep Session",
            confirm_description="Remove stored credentials from this machine.",
            cancel_description="Stay signed in and return to the launcher.",
            title="Logout",
        ):
            return callbacks.logout()
        return None

    def launcher_session_action() -> LauncherNavigationRequest | None:
        options = [
            LauncherOption(
                key="status",
                label="View Status",
                description="Show detailed authentication and session info.",
                handler=launcher_auth,
            ),
            LauncherOption(
                key="logout",
                label="Logout",
                description="Remove stored credentials from this machine.",
                handler=launcher_logout,
            ),
            LauncherOption(
                key="back",
                label="Go Back",
                description="Return to the main menu.",
                handler=lambda: None,
            ),
        ]
        sections = [LauncherSection(title="Session", options=options)]
        nav_action = run_interactive_launcher(
            lambda: sections,
            console=console,
            show_header=False,
            title="Session",
            subtitle="Manage the current authenticated session.",
            cancel_action="back",
        )
        if nav_action == "quit":
            return LauncherNavigationRequest(action="quit")
        return None

    def sections_factory() -> list[LauncherSection]:
        config = config_store.load()
        is_auth = bool(config and config.api_key)
        username = config.username if config else None
        workspace = config.default_workspace if config else None
        has_local_project = (Path.cwd() / PROJECT_CONFIG_RELATIVE_PATH).exists()

        account_options: list[LauncherOption] = []
        if is_auth:
            label = f"Session: {username or 'active'}"
            if workspace:
                label += f" ({workspace})"
            account_options.append(
                LauncherOption(
                    key="session",
                    label=label,
                    description="Manage current session and view status.",
                    handler=launcher_session_action,
                )
            )
        else:
            account_options.append(
                LauncherOption(
                    key="login",
                    label="Login",
                    description="Authenticate with the platform.",
                    handler=launcher_login,
                )
            )

        account_options.append(
            LauncherOption(
                key="quit",
                label="Exit",
                description="Exit the launcher.",
                handler=lambda: None,
            )
        )

        project_options: list[LauncherOption]
        if has_local_project:
            project_options = [
                LauncherOption(
                    key="project-settings",
                    label="Project settings",
                    description=(
                        "Change one project setting at a time: name, article, hardware, "
                        "tags, visibility, or pricing."
                    ),
                    handler=launcher_project_settings,
                ),
                LauncherOption(
                    key="publish",
                    label="Publish project",
                    description="Build and push to the platform (pick hardware when prompted).",
                    handler=launcher_publish,
                ),
            ]
        else:
            project_options = [
                LauncherOption(
                    key="init",
                    label="Create project",
                    description="Scaffold a new model project.",
                    handler=launcher_init,
                ),
            ]

        jobs_section = LauncherSection(
            title="Workflows & Jobs",
            options=[
                LauncherOption(
                    key="fine-tune-create",
                    label="Start fine-tune job",
                    description="Upload a local fine-tune bundle or workspace and start a job.",
                    handler=launcher_fine_tune_create,
                ),
                LauncherOption(
                    key="jobs-browse",
                    label="Browse all jobs",
                    description="Browse build and fine-tune jobs without typing job IDs.",
                    handler=launcher_jobs_browse,
                ),
            ],
        )
        if not is_auth:
            jobs_section = LauncherSection(
                title="Workflows & Jobs",
                options=[
                    LauncherOption(
                        key="login-prompt",
                        label="Login required",
                        description="Authenticate with `ai login` to access job features.",
                        handler=launcher_login,
                    ),
                ],
            )

        return [
            LauncherSection(
                title="Project",
                options=project_options,
            ),
            jobs_section,
            LauncherSection(title="Account", options=account_options),
        ]

    run_interactive_launcher(sections_factory, console=console)
