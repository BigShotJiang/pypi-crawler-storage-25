"""Resolve Gateway URL with a single precedence chain for login and auth defaults."""

from __future__ import annotations

import ipaddress
import os
import re
from pathlib import Path
from urllib.parse import urlparse

from aimp_cli.core.errors import CliError, ErrorCategory, ExitCode
from aimp_cli.domain.models import LOCAL_GATEWAY_URL
from aimp_cli.utils.stage_runtime_state import discover_monorepo_root, read_stage_runtime_state

STAGE_PUBLIC_ENV_RELATIVE_PATH = Path("infra/vm/stage.public.env")
LEGACY_CLOUD_RUN_STAGE_WARNING = "Stored gateway points to legacy Cloud Run stage. Run: ai login"
_STAGE_PUBLIC_LINE = re.compile(
    r"^(?P<key>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?P<value>.*)\s*$"
)


def _strip_env_value(raw: str) -> str:
    s = raw.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ('"', "'"):
        return s[1:-1].strip()
    return s


def parse_stage_public_env_file(path: Path) -> dict[str, str]:
    """Parse a minimal KEY=VALUE env file (comments and blank lines ignored)."""
    if not path.is_file():
        return {}
    out: dict[str, str] = {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = _STAGE_PUBLIC_LINE.match(line)
        if not m:
            continue
        key, value = m.group("key"), m.group("value")
        out[key] = _strip_env_value(value)
    return out


def validate_stage_public_gateway_url(raw: str, *, source: str) -> str:
    """Validate ``STAGE_GATEWAY_PUBLIC_URL`` from the public stage file."""
    url = raw.strip()
    if not url:
        raise CliError(
            f"{source}: STAGE_GATEWAY_PUBLIC_URL is empty.",
            code="invalid_stage_public_gateway_url",
            category=ErrorCategory.ENVIRONMENT,
            exit_code=ExitCode.ENVIRONMENT,
            hint="Set a valid public gateway origin (http or https, no path suffix).",
        )
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise CliError(
            f"{source}: STAGE_GATEWAY_PUBLIC_URL must use http or https (got {parsed.scheme!r}).",
            code="invalid_stage_public_gateway_url",
            category=ErrorCategory.ENVIRONMENT,
            exit_code=ExitCode.ENVIRONMENT,
            hint="Example: http://203.0.113.10",
        )
    if not parsed.netloc or not parsed.hostname:
        raise CliError(
            f"{source}: STAGE_GATEWAY_PUBLIC_URL must include a host.",
            code="invalid_stage_public_gateway_url",
            category=ErrorCategory.ENVIRONMENT,
            exit_code=ExitCode.ENVIRONMENT,
        )
    path = parsed.path or ""
    if path not in ("", "/"):
        message = (
            f"{source}: STAGE_GATEWAY_PUBLIC_URL must not include a path "
            f"(got {path!r}; use the API origin only, not /api)."
        )
        raise CliError(
            message,
            code="invalid_stage_public_gateway_url",
            category=ErrorCategory.ENVIRONMENT,
            exit_code=ExitCode.ENVIRONMENT,
            hint="Use the gateway base URL with no trailing path.",
        )
    host = parsed.hostname
    assert host is not None
    lowered = host.lower()
    if lowered == "localhost" or lowered.endswith(".localhost"):
        raise CliError(
            f"{source}: STAGE_GATEWAY_PUBLIC_URL must not use localhost ({host!r}).",
            code="invalid_stage_public_gateway_url",
            category=ErrorCategory.ENVIRONMENT,
            exit_code=ExitCode.ENVIRONMENT,
            hint="Local development uses AIMP_GATEWAY_URL or make stage-up runtime state.",
        )
    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        return url
    if addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved:
        raise CliError(
            f"{source}: STAGE_GATEWAY_PUBLIC_URL must be a public address (got {host!r}).",
            code="invalid_stage_public_gateway_url",
            category=ErrorCategory.ENVIRONMENT,
            exit_code=ExitCode.ENVIRONMENT,
            hint="Use the public Core API origin, not a private or loopback IP.",
        )
    return url


def read_stage_public_gateway_url(monorepo_root: Path | None) -> str | None:
    """Load ``STAGE_GATEWAY_PUBLIC_URL`` from ``infra/vm/stage.public.env`` if present and valid."""
    if monorepo_root is None:
        return None
    path = monorepo_root / STAGE_PUBLIC_ENV_RELATIVE_PATH
    if not path.is_file():
        return None
    parsed = parse_stage_public_env_file(path)
    if "STAGE_GATEWAY_PUBLIC_URL" not in parsed:
        return None
    raw = parsed["STAGE_GATEWAY_PUBLIC_URL"]
    return validate_stage_public_gateway_url(raw, source=str(path))


def is_legacy_cloud_run_stage_gateway(url: str | None) -> bool:
    """Return whether a stored Gateway URL points at the retired Cloud Run stage host."""
    parsed = urlparse((url or "").strip())
    host = (parsed.hostname or "").lower()
    return host.endswith(".a.run.app")


def legacy_saved_gateway_warning(
    stored_gateway_url: str | None,
    *,
    monorepo_root: Path | None = None,
) -> str | None:
    """Warn when persisted CLI credentials still target retired Cloud Run stage.

    The saved config remains authoritative until the operator runs ``ai login`` again; this
    warning makes that drift explicit without silently rewriting credentials.
    """
    if not is_legacy_cloud_run_stage_gateway(stored_gateway_url):
        return None
    root = monorepo_root if monorepo_root is not None else discover_monorepo_root()
    public = read_stage_public_gateway_url(root)
    if public is None:
        return None
    if stored_gateway_url and stored_gateway_url.rstrip("/") != public.rstrip("/"):
        return LEGACY_CLOUD_RUN_STAGE_WARNING
    return None


def resolve_fallback_gateway_url(monorepo_root: Path | None = None) -> str:
    """Default gateway when no CLI flag, env, or saved config applies.

    Precedence: active ``logs/stage-runtime.json`` > ``infra/vm/stage.public.env`` >
    :data:`aimp_cli.domain.models.LOCAL_GATEWAY_URL`.

    Raises :class:`CliError` if the public env file sets an invalid URL.
    """
    root = monorepo_root if monorepo_root is not None else discover_monorepo_root()
    state = read_stage_runtime_state(monorepo_root=root)
    if state is not None and state.gateway_url.strip():
        return state.gateway_url.strip()
    public = read_stage_public_gateway_url(root)
    if public is not None:
        return public
    return LOCAL_GATEWAY_URL


def resolve_login_gateway_url(*, gateway_flag: str | None = None) -> str:
    """Gateway URL for ``ai login`` prompts and non-interactive login without ``--gateway``.

    Precedence: ``--gateway`` > :envvar:`AIMP_GATEWAY_URL` > active repo runtime state >
    ``infra/vm/stage.public.env`` > :data:`aimp_cli.domain.models.LOCAL_GATEWAY_URL`.

    Does not read ``~/.aimp/config.json``.
    """
    if gateway_flag and gateway_flag.strip():
        return gateway_flag.strip()
    env_url = os.getenv("AIMP_GATEWAY_URL", "").strip()
    if env_url:
        return env_url
    return resolve_fallback_gateway_url()
