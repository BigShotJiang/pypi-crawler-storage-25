"""Active Stage Gateway runtime state (repo-local, not CLI credentials).

Written by ``make stage-up`` / ``make stage-up-free``; consumed by ``ai login`` defaults.
Persisted ``~/.aimp/config.json`` remains credential storage only.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
from urllib.parse import urlparse

from pydantic import BaseModel, Field, ValidationError

from aimp_cli.domain.models import LOCAL_GATEWAY_URL

STAGE_RUNTIME_FILENAME = "stage-runtime.json"
STAGE_RUNTIME_RELATIVE_PATH = Path("logs") / STAGE_RUNTIME_FILENAME

_MONOREPO_ROOT_MARKERS = (
    Path("packages/python/cli/pyproject.toml"),
    Path("packages/python/framework/pyproject.toml"),
    Path("packages/python/sdk/pyproject.toml"),
)

StageMode = Literal["local", "quick_tunnel"]


class StageRuntimeState(BaseModel):
    """Schema for ``logs/stage-runtime.json`` (schema_version 1)."""

    schema_version: Literal[1] = 1
    mode: StageMode
    gateway_url: str
    frontend_url: str | None = None
    updated_at: str = Field(
        ...,
        description="UTC ISO-8601 timestamp when this file was written.",
    )
    ephemeral: bool | None = Field(
        None,
        description="True when the gateway URL is expected to expire (e.g. Quick Tunnel).",
    )


def discover_monorepo_root(start: Path | None = None) -> Path | None:
    """Return the AI Marketplace Platform repo root if *start* is inside it."""
    current = (start or Path.cwd()).resolve()
    for candidate in (current, *current.parents):
        if all((candidate / marker).exists() for marker in _MONOREPO_ROOT_MARKERS):
            return candidate
    return None


def stage_runtime_state_path(monorepo_root: Path) -> Path:
    return monorepo_root / STAGE_RUNTIME_RELATIVE_PATH


def is_trycloudflare_gateway_url(url: str) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return host.endswith(".trycloudflare.com") or host == "trycloudflare.com"


def read_stage_runtime_state(
    *,
    monorepo_root: Path | None = None,
) -> StageRuntimeState | None:
    """Load and validate runtime state, or return ``None`` if missing or invalid."""
    root = monorepo_root if monorepo_root is not None else discover_monorepo_root()
    if root is None:
        return None
    path = stage_runtime_state_path(root)
    if not path.is_file():
        return None
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    try:
        state = StageRuntimeState.model_validate(data)
    except ValidationError:
        return None
    if not (state.gateway_url or "").strip():
        return None
    if state.mode == "quick_tunnel" and not is_trycloudflare_gateway_url(state.gateway_url):
        return None
    return state


def clear_stage_runtime_state(monorepo_root: Path) -> None:
    """Remove runtime state if present (tunnel shutdown / ``make stage-down``)."""
    path = stage_runtime_state_path(monorepo_root)
    path.unlink(missing_ok=True)


def _utc_timestamp() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def write_local_stage_runtime_state(
    monorepo_root: Path,
    *,
    gateway_url: str | None = None,
    frontend_url: str | None = None,
) -> None:
    """Persist ``mode=local`` (``make stage-up`` / ``make stage-up-headless``)."""
    resolved_gateway = (gateway_url or os.getenv("GATEWAY_PUBLIC_URL") or "").strip() or LOCAL_GATEWAY_URL
    resolved_frontend = (frontend_url or "").strip() or None
    if not resolved_frontend:
        port = os.getenv("FRONTEND_PORT", "3000").strip() or "3000"
        resolved_frontend = f"http://localhost:{port}"
    path = stage_runtime_state_path(monorepo_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    state = StageRuntimeState(
        mode="local",
        gateway_url=resolved_gateway,
        frontend_url=resolved_frontend,
        updated_at=_utc_timestamp(),
        ephemeral=False,
    )
    path.write_text(
        state.model_dump_json(indent=2) + "\n",
        encoding="utf-8",
    )


def write_quick_tunnel_stage_runtime_state(
    monorepo_root: Path,
    *,
    gateway_url: str,
    frontend_url: str,
) -> None:
    """Persist ``mode=quick_tunnel`` after Quick Tunnel URLs are discovered."""
    path = stage_runtime_state_path(monorepo_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    state = StageRuntimeState(
        mode="quick_tunnel",
        gateway_url=gateway_url.strip(),
        frontend_url=frontend_url.strip(),
        updated_at=_utc_timestamp(),
        ephemeral=True,
    )
    path.write_text(
        state.model_dump_json(indent=2) + "\n",
        encoding="utf-8",
    )


