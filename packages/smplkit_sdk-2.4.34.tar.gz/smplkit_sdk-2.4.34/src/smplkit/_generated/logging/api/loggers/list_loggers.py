from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.http_validation_error import HTTPValidationError
from ...models.logger_list_response import LoggerListResponse
from ...types import Unset


def _get_kwargs(
    *,
    filtermanaged: Union[None, Unset, bool] = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_filtermanaged: Union[None, Unset, bool]
    if isinstance(filtermanaged, Unset):
        json_filtermanaged = UNSET
    else:
        json_filtermanaged = filtermanaged
    params["filter[managed]"] = json_filtermanaged

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/loggers",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[ErrorResponse, HTTPValidationError, LoggerListResponse]]:
    if response.status_code == 200:
        response_200 = LoggerListResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorResponse.from_dict(response.json())

        return response_429

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[ErrorResponse, HTTPValidationError, LoggerListResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    filtermanaged: Union[None, Unset, bool] = UNSET,
) -> Response[Union[ErrorResponse, HTTPValidationError, LoggerListResponse]]:
    """List Loggers

    Args:
        filtermanaged (Union[None, Unset, bool]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse, HTTPValidationError, LoggerListResponse]]
    """

    kwargs = _get_kwargs(
        filtermanaged=filtermanaged,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    filtermanaged: Union[None, Unset, bool] = UNSET,
) -> Optional[Union[ErrorResponse, HTTPValidationError, LoggerListResponse]]:
    """List Loggers

    Args:
        filtermanaged (Union[None, Unset, bool]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse, HTTPValidationError, LoggerListResponse]
    """

    return sync_detailed(
        client=client,
        filtermanaged=filtermanaged,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    filtermanaged: Union[None, Unset, bool] = UNSET,
) -> Response[Union[ErrorResponse, HTTPValidationError, LoggerListResponse]]:
    """List Loggers

    Args:
        filtermanaged (Union[None, Unset, bool]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse, HTTPValidationError, LoggerListResponse]]
    """

    kwargs = _get_kwargs(
        filtermanaged=filtermanaged,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    filtermanaged: Union[None, Unset, bool] = UNSET,
) -> Optional[Union[ErrorResponse, HTTPValidationError, LoggerListResponse]]:
    """List Loggers

    Args:
        filtermanaged (Union[None, Unset, bool]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse, HTTPValidationError, LoggerListResponse]
    """

    return (
        await asyncio_detailed(
            client=client,
            filtermanaged=filtermanaged,
        )
    ).parsed
