"""Custom exception classes."""


class JanetError(Exception):
    """Base exception."""
    pass


class AuthenticationError(JanetError):
    """Authentication failed."""
    pass


class NetworkError(JanetError):
    """Network request failed."""
    pass


class ConfigurationError(JanetError):
    """Invalid configuration."""
    pass
