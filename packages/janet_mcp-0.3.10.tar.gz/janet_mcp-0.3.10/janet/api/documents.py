"""Document API methods."""

from typing import Dict, List, Optional

from janet.api.client import APIClient
from janet.config.manager import ConfigManager


def _markdown_to_blocks(markdown: str) -> Dict:
    """Convert a plain markdown string into minimal BlockNote-compatible JSON."""
    blocks = []
    for line in markdown.splitlines():
        stripped = line.strip()
        if not stripped:
            blocks.append({"type": "paragraph", "content": []})
        else:
            blocks.append({
                "type": "paragraph",
                "content": [{"type": "text", "text": stripped}],
            })
    if not blocks:
        blocks = [{"type": "paragraph", "content": []}]
    return {"type": "doc", "content": blocks}


def _blocks_to_text(content) -> str:
    """Extract plain text from BlockNote/Tiptap JSON content."""
    if not content:
        return ""

    def _walk(node) -> List[str]:
        parts: List[str] = []
        if isinstance(node, dict):
            if node.get("type") == "text":
                parts.append(node.get("text", ""))
            for child in node.get("content", []):
                parts.extend(_walk(child))
        elif isinstance(node, list):
            for child in node:
                parts.extend(_walk(child))
        return parts

    lines: List[str] = []
    root_content = content if isinstance(content, list) else content.get("content", [])
    for block in root_content:
        text = "".join(_walk(block)).strip()
        lines.append(text)

    return "\n".join(lines).strip()


class DocumentAPI(APIClient):
    """API methods for document management."""

    def __init__(self, config_manager: ConfigManager):
        super().__init__(config_manager)

    def list_documents(self, my_docs: bool = False) -> Dict:
        """
        List documents accessible to the current user.

        Args:
            my_docs: If True, return only documents created by or shared with the user.

        Returns:
            Dictionary with 'documents' list and 'count'.
        """
        params = {"my_docs": "true" if my_docs else "false"}
        return self.get("/api/v1/documents", include_org=True, params=params)

    def get_document(self, document_id: str) -> Dict:
        """
        Get a single document with full content.

        Args:
            document_id: Document UUID.

        Returns:
            Dictionary with 'document' dict.
        """
        return self.get(f"/api/v1/documents/{document_id}", include_org=True)

    def create_document(
        self,
        title: str,
        content_json: Optional[Dict] = None,
        is_private: bool = True,
        folder_id: Optional[str] = None,
    ) -> Dict:
        """
        Create a new document.

        Args:
            title: Document title.
            content_json: BlockNote-compatible JSON content (optional).
            is_private: If True, restrict to creator only (default True).
            folder_id: Optional folder ID to place document in.

        Returns:
            Dictionary with 'document_id' and 'title'.
        """
        data: Dict = {"title": title, "is_private": is_private}
        if content_json:
            data["content"] = content_json
        if folder_id:
            data["folder_id"] = folder_id
        return self.post("/api/v1/documents", data=data, include_org=True)

    def update_document(
        self,
        document_id: str,
        title: Optional[str] = None,
        content_json: Optional[Dict] = None,
    ) -> Dict:
        """
        Update a document's title and/or content.

        Args:
            document_id: Document UUID.
            title: New title (optional).
            content_json: New BlockNote-compatible JSON content (optional).

        Returns:
            Dictionary with 'document_id' and 'updated_at'.
        """
        data: Dict = {}
        if title is not None:
            data["title"] = title
        if content_json is not None:
            data["content"] = content_json
        return self.put(f"/api/v1/documents/{document_id}", data=data, include_org=True)
