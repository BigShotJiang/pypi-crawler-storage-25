"""Folder API methods."""

from typing import Dict

from janet.api.client import APIClient
from janet.config.manager import ConfigManager


class FolderAPI(APIClient):
    """API methods for document folder management."""

    def __init__(self, config_manager: ConfigManager):
        super().__init__(config_manager)

    def list_folders(self) -> Dict:
        """List all folders visible to the current user."""
        return self.get("/api/v1/folders", include_org=True)

    def create_folder(self, name: str, is_private: bool = True) -> Dict:
        """Create a new folder."""
        return self.post("/api/v1/folders", data={"name": name, "is_private": is_private}, include_org=True)

    def delete_folder(self, folder_id: str) -> Dict:
        """Delete a folder. Documents inside move to root."""
        return self.delete(f"/api/v1/folders/{folder_id}", include_org=True)

    def add_document_to_folder(self, folder_id: str, document_id: str) -> Dict:
        """Add a document to a folder."""
        return self.post(f"/api/v1/folders/{folder_id}/documents", data={"document_id": document_id}, include_org=True)

    def remove_document_from_folder(self, folder_id: str, document_id: str) -> Dict:
        """Remove a document from a folder."""
        return self.delete(f"/api/v1/folders/{folder_id}/documents/{document_id}", include_org=True)
