"""API key authentication adapter for MCP server.

When JANET_API_KEY is set, this provides a lightweight ConfigManager-compatible
interface that uses the API key directly — no stored config file or OAuth needed.
"""

import os
from typing import Optional

from janet.config.models import AuthConfig, APIConfig, Config, OrganizationInfo


class ApiKeyConfig:
    """Mimics ConfigManager interface using an API key instead of OAuth tokens."""

    def __init__(self, api_key: str):
        self._api_key = api_key
        self._config: Optional[Config] = None
        self._org_info: Optional[OrganizationInfo] = None
        self._network_error: Optional[str] = None

    def get(self) -> Config:
        if self._config is None:
            self._config = Config(
                auth=AuthConfig(access_token=self._api_key),
                api=APIConfig(),
                selected_organization=self._org_info,
            )
        return self._config

    def is_authenticated(self) -> bool:
        return True

    def has_organization(self) -> bool:
        # With API keys, org is embedded in the key's server-side record.
        # We set a placeholder — the backend resolves the real org from the key.
        if self._org_info is None:
            self._resolve_org()
        return self._org_info is not None

    def _resolve_org(self):
        """Fetch org info from the API key's /me endpoint."""
        import time
        from janet.api.client import APIClient
        from janet.utils.errors import NetworkError

        for attempt in range(3):
            try:
                client = APIClient(self)
                resp = client.get("/api/v1/api-keys/me")
                org = resp.get("organization", {})
                if org and org.get("workos_id"):
                    self._org_info = OrganizationInfo(
                        id=org["workos_id"],
                        name=org.get("name", ""),
                        uuid=org.get("id", org["workos_id"]),
                    )
                    # Cache user info
                    user = resp.get("user", {})
                    self._user_email = user.get("email", "")
                    self._user_name = user.get("name", "")
                    # Rebuild config with org info
                    self._config = None
                    self._network_error = None
                return
            except NetworkError as e:
                self._network_error = str(e)
                if attempt < 2:
                    time.sleep(1.5 ** attempt)
            except Exception:
                return

    def load(self):
        return self.get()

    def save(self):
        pass  # No-op — API keys don't need config file writes

    def update(self, config):
        pass


def get_api_key_from_env() -> Optional[str]:
    """Get JANET_API_KEY from environment if set."""
    return os.environ.get("JANET_API_KEY")
