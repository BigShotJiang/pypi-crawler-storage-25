"""
Options and enums for ErodeObjects module
"""

# Note: ErodeObjects is a simple morphological operation module that doesn't require
# complex enums. The main configuration is handled through the StructuringElement
# setting which is managed by the core framework. This file is created for 
# consistency with the refactoring pattern but may be minimal.

# Currently no custom enums needed for ErodeObjects as it uses standard
# StructuringElement configuration from cellprofiler_core. For structuring element shapes,
# see cellprofiler_library.opts.structuring_elements
