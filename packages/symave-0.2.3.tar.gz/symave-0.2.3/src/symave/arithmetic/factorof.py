from typing import Any

from sympy import Eq, Mod, Symbol, SympifyError, simplify, sympify

from symave.base import BaseVerifier


class NontrivialFactorOfVerifier(BaseVerifier):
    def verify(self, parameters: dict[str, Any], student_expression_str: str) -> bool:
        locals_dict: dict[str, Any] = {}
        for k, v in parameters.items():
            if isinstance(v, str):
                sym = Symbol(v, integer=True)
                locals_dict[k] = sym
                locals_dict[v] = sym
            else:
                locals_dict[k] = sympify(v)

        try:
            b = sympify(student_expression_str, locals=locals_dict)
        except (SympifyError, TypeError) as exc:
            raise ValueError(  # pragma: no mutate
                f"Cannot parse expression: {student_expression_str!r}"
            ) from exc

        a = locals_dict["a"]

        if a.is_zero or not b.is_real:
            return False

        return bool(simplify(Eq(Mod(b, a), 0)))
