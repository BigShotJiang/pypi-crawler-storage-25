from symave.arithmetic.factorof import NontrivialFactorOfVerifier
from symave.base import BaseVerifier

VERIFIER_REGISTRY: dict[str, BaseVerifier] = {
    "integer1:factorof": NontrivialFactorOfVerifier(),
}


def get_verifier(handler_name: str) -> BaseVerifier:
    if handler_name not in VERIFIER_REGISTRY:
        raise ValueError(f"No verifier registered for '{handler_name}'")
    return VERIFIER_REGISTRY[handler_name]
