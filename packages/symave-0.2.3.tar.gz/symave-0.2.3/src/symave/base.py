from abc import ABC, abstractmethod
from typing import Any

class BaseVerifier(ABC):
    @abstractmethod
    def verify(
        self, parameters: dict[str, Any], student_expression_str: str
    ) -> bool: ...
