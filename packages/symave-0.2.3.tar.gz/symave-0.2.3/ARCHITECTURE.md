# Architecture

## External tools

**[Hatch](https://hatch.pypa.io/latest/).** Used for management of this library. Any task goes through Hatch.

**[SymPy](https://www.sympy.org/en/index.html).** Symbolic mathematics library that's the underlying engine of any verifier.

**Coding agents.** This library was conceived in the world of agentic vibecoding and fully accommodates to this fact by structuring all information in machine-readable specs. No particular choice is preferred one, pick your poison. 

**Code quality:** 
- code format: [Black](https://pypi.org/project/black/)
- release: [PSR](https://python-semantic-release.readthedocs.io/en/latest/#)
- linter: [Ruff](https://docs.astral.sh/ruff/)
- security compliance: [bandit](https://bandit.readthedocs.io/en/latest/)

**Versioning and changelog.** Releases follow [Conventional Commits](https://www.conventionalcommits.org/) (`feat:`, `fix:`, `chore:`, etc.). `python-semantic-release` derives the next version number from commit messages (feat → minor, fix → patch, breaking change → major) and generates GitLab release notes from them. A `CHANGELOG.md` is not maintained separately — the GitLab releases page is the changelog.

## Concepts

**Symbol.** One concise mathematical concept that is expressible in symbolic logic, has a thorough unit test suite that serves as its documentation.

**Knowledge Base (KB).** The authoritative catalog of mathematical symbols, normalized from OpenMath and related research, e.g. [neus2026-labre](https://github.com/labrem/neus2026-labre). Each symbol carries its definition, parameters, properties, and examples. The KB drives both what the library implements and how tests are written — if a symbol is not in the KB, it has no verifier and no tests.

**Symbol implementation and its definition in KB MUST be congruent.**

**Verifier.** A SymPy-backed implementation of one KB symbol's verification logic. Given a parameter dict and a student expression string, it returns whether the expression satisfies the symbol's mathematical definition. All verifiers share a single interface (`BaseVerifier`) so the registry can dispatch uniformly without knowing the concrete type.

**Registry.** A flat map from symbol ID (e.g. `integer1:factorof`) to a verifier instance. The public API surface is intentionally small: `get_verifier(id)` is the only entry point callers need. Adding a new symbol means adding an entry here alongside the implementation.

**Test suite.** One test file per KB symbol, marked with `@pytest.mark.kb_symbol`. Tests are the executable specification of a verifier — they document both correct behavior and edge cases.

**Every symbol has exactly one unit test suite that fully covers all well-known scenarios.**

**KB test registry.** A generated index that maps each symbol ID to its test file, so tooling can retrieve both spec and tests together. It is written automatically by `conftest.py` on every test run via `@kb_symbol` markers — do not edit it by hand.

**KB tooling.** Three development tools exist outside the installable package. `kb_get` retrieves a symbol's definition and its test file in LLM-friendly format — tests serve as usage documentation. `kb_pipeline` normalizes then validates `knowledge_base.json` against its schema; it runs before any edit lands. The web UI provides a local browser-based editor for the KB for non-programmatic browsing, filtering, and editing.

## Decisions log

**2026-05-16 — Single repository for library + KB.** Every new symbol requires KB, implementation, and tests in lockstep — separate repos would mean constant cross-repo coordination with no benefit at this scale.

**2026-05-16 — KB consolidated under `kb/`.** Previously spread across `data/`, `schema/`, `scripts/`, `web/`.

**2026-05-16 — KB is not packaged.** `[tool.hatch.build.targets.wheel]` scopes to `src/symave` only. The `kb/` tree is development infrastructure and must never become a packaging dependency.