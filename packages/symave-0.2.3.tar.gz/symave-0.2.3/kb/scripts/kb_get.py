# /// script
# requires-python = ">=3.14"
# dependencies = ["jsonschema", "pydantic", "pyyaml"]
# ///
"""Extract and display a KB symbol in LLM-friendly format."""

import json
import sys
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator
from pydantic import BaseModel, Field

KB_ROOT = Path(__file__).parent.parent
PROJECT_ROOT = KB_ROOT.parent
KB_PATH = KB_ROOT / "data" / "knowledge_base.json"
SCHEMA_PATH = KB_ROOT / "schema" / "knowledge_base.schema.json"
TEST_REGISTRY_PATH = KB_ROOT / "data" / "kb_test_registry.json"


class Parameter(BaseModel):
    name: str
    position: int


class Symbol(BaseModel):
    id: str
    cd: str
    name: str
    source: str = Field(exclude=True)
    description: str
    role: str | None = None
    type_signature: str | None = None
    parameters: list[Parameter] | None = None
    properties: list[str] = []
    examples: list[str] = []
    keywords: list[str] = []


def _load_and_validate() -> dict:
    kb = json.loads(KB_PATH.read_text())
    schema = json.loads(SCHEMA_PATH.read_text())
    errors = list(Draft202012Validator(schema).iter_errors(kb))
    if errors:
        for e in errors:
            print(f"schema error: {e.message}", file=sys.stderr)
        sys.exit(1)
    return kb


def main() -> None:
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <symbol-id>", file=sys.stderr)
        print("Example: integer1:factorof", file=sys.stderr)
        sys.exit(1)

    symbol_id = sys.argv[1]
    kb = _load_and_validate()
    symbols = kb["symbols"]

    if symbol_id not in symbols:
        available = "\n  ".join(sorted(symbols))
        print(f"Symbol '{symbol_id}' not found.\nAvailable:\n  {available}", file=sys.stderr)
        sys.exit(1)

    symbol = Symbol.model_validate(symbols[symbol_id])
    print("```yaml")
    print(yaml.dump(symbol.model_dump(exclude_none=True, exclude_defaults=True), allow_unicode=True, sort_keys=False), end="")
    print("```")

    if TEST_REGISTRY_PATH.exists():
        test_registry = json.loads(TEST_REGISTRY_PATH.read_text())
        if symbol_id in test_registry:
            test_file = PROJECT_ROOT / test_registry[symbol_id]
            print("\n```python")
            print(test_file.read_text(), end="")
            print("```")


if __name__ == "__main__":
    main()