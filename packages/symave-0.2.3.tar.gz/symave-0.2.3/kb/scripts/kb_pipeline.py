#!/usr/bin/env python3
# /// script
# requires-python = ">=3.14"
# dependencies = ["jsonschema"]
# ///
"""Normalize then validate knowledge_base.json."""

import json
import sys
import unicodedata
from pathlib import Path

from jsonschema import Draft202012Validator

KB_ROOT = Path(__file__).parent.parent
KB_PATH = KB_ROOT / "data" / "knowledge_base.json"
SCHEMA_PATH = KB_ROOT / "schema" / "knowledge_base.schema.json"


def normalize_description(desc: str) -> str:
    return ''.join(filter(lambda c: not unicodedata.category(c) == 'Cc', desc)).strip()


def normalize() -> None:
    if not KB_PATH.exists():
        print(f"ERROR: file not found: {KB_PATH}", file=sys.stderr)
        sys.exit(1)

    with open(KB_PATH, encoding="utf-8") as f:
        kb = json.load(f)

    changed = 0
    for symbol in kb.get("symbols", {}).values():
        desc = symbol.get("description")
        if isinstance(desc, str):
            normalized = normalize_description(desc)
            if normalized != desc:
                symbol["description"] = normalized
                changed += 1

    with open(KB_PATH, "w", encoding="utf-8") as f:
        json.dump(kb, f, indent=2, ensure_ascii=False)
        f.write("\n")

    print(f"normalize: OK — {changed} description(s) normalized")


def validate() -> None:
    for path in (KB_PATH, SCHEMA_PATH):
        if not path.exists():
            print(f"ERROR: file not found: {path}", file=sys.stderr)
            sys.exit(1)

    with open(KB_PATH, encoding="utf-8") as f:
        kb = json.load(f)

    with open(SCHEMA_PATH, encoding="utf-8") as f:
        schema = json.load(f)

    errors = _schema_errors(kb, schema) + _structural_errors(kb)
    if errors:
        print(f"validate: INVALID — {len(errors)} error(s):\n")
        for e in errors:
            print(e)
        sys.exit(1)

    print(f"validate: OK — {len(kb.get('symbols', {}))} symbols valid")


def _schema_errors(kb: dict, schema: dict) -> list[str]:
    errors = []
    for error in Draft202012Validator(schema).iter_errors(kb):
        path = " -> ".join(str(p) for p in error.absolute_path) or "(root)"
        errors.append(f"  [{path}] {error.message}")
    return errors


def _structural_errors(kb: dict) -> list[str]:
    errors = []
    for key, symbol in kb.get("symbols", {}).items():
        expected_id = f"{symbol.get('cd')}:{symbol.get('name')}"

        if key != expected_id:
            errors.append(f"  [{key}] key does not match cd:name (expected {expected_id!r})")

        if symbol.get("id") != expected_id:
            errors.append(f"  [{key}] id field {symbol.get('id')!r} does not match cd:name")

        desc = symbol.get("description", "")
        if isinstance(desc, str) and ''.join(filter(lambda c: not unicodedata.category(c) == 'Cc', desc)) != desc:
            errors.append(f"  [{key}] description contains control characters")

    return errors


if __name__ == "__main__":
    normalize()
    validate()