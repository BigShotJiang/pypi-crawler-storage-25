#!/usr/bin/env python3
# /// script
# requires-python = ">=3.14"
# ///
import json
import os
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import unquote

KB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'knowledge_base.json')
TEST_REGISTRY_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'kb_test_registry.json')
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
WEB_DIR = os.path.dirname(os.path.abspath(__file__))


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=WEB_DIR, **kwargs)

    def do_GET(self):
        if self.path == '/api/kb':
            self._serve_kb()
        elif self.path.startswith('/api/tests/'):
            symbol_id = unquote(self.path[len('/api/tests/'):])
            self._serve_tests(symbol_id)
        else:
            super().do_GET()

    def do_POST(self):
        if self.path == '/api/kb':
            self._save_kb()
        else:
            self.send_error(404)

    def _serve_kb(self):
        with open(KB_PATH, 'rb') as f:
            data = f.read()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_tests(self, symbol_id):
        if not os.path.exists(TEST_REGISTRY_PATH):
            self.send_error(404)
            return
        with open(TEST_REGISTRY_PATH, encoding='utf-8') as f:
            registry = json.loads(f.read())
        if symbol_id not in registry:
            self.send_error(404)
            return
        test_path = os.path.join(PROJECT_ROOT, registry[symbol_id])
        if not os.path.exists(test_path):
            self.send_error(404)
            return
        with open(test_path, 'rb') as f:
            data = f.read()
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _save_kb(self):
        length = int(self.headers['Content-Length'])
        body = self.rfile.read(length)
        try:
            parsed = json.loads(body)
        except json.JSONDecodeError as e:
            self.send_error(400, str(e))
            return
        with open(KB_PATH, 'w', encoding='utf-8') as f:
            json.dump(parsed, f, indent=2, ensure_ascii=False)
            f.write('\n')
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"ok":true}')

    def log_message(self, fmt, *args):
        pass


if __name__ == '__main__':
    server = HTTPServer(('localhost', 8787), Handler)
    print('KB editor running at http://localhost:8787')
    server.serve_forever()
