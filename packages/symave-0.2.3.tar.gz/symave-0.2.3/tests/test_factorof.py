import pytest

from symave.arithmetic.factorof import NontrivialFactorOfVerifier

pytestmark = pytest.mark.kb_symbol("integer1:factorof")


@pytest.fixture
def v() -> NontrivialFactorOfVerifier:
    return NontrivialFactorOfVerifier()


@pytest.mark.parametrize(
    ("a", "expr", "expected"),
    [
        (5, "10", True),
        (5, "11", False),
        (1, "99", True),
        (7, "7", True),
        (3, "10", False),
    ],
)
def test_integer(
    v: NontrivialFactorOfVerifier, a: int, expr: str, expected: bool
) -> None:
    assert v.verify({"a": a}, expr) is expected


@pytest.mark.parametrize(
    ("a", "expr", "expected"),
    [
        (0, "10", False),
        (5, "0", True),
    ],
)
def test_zero(v: NontrivialFactorOfVerifier, a: int, expr: str, expected: bool) -> None:
    assert v.verify({"a": a}, expr) is expected


@pytest.mark.parametrize(
    ("a", "expr", "expected"),
    [
        (2, "-4", True),
        (-2, "4", True),
        (-3, "-9", True),
        (3, "-7", False),
    ],
)
def test_negative(
    v: NontrivialFactorOfVerifier, a: int, expr: str, expected: bool
) -> None:
    assert v.verify({"a": a}, expr) is expected


@pytest.mark.parametrize(
    ("a", "expr", "expected"),
    [
        (2, "3/2", False),
        (2, "8/2", True),
    ],
)
def test_fractional(
    v: NontrivialFactorOfVerifier, a: int, expr: str, expected: bool
) -> None:
    assert v.verify({"a": a}, expr) is expected


def test_complex_indeterminate(v: NontrivialFactorOfVerifier) -> None:
    assert v.verify({"a": 2}, "2 + 3*I") is False


@pytest.mark.parametrize(
    ("a", "expr", "expected"),
    [
        (5, "3*(2+3)", True),
        (3, "2*(3+1)", False),
    ],
)
def test_compound_expressions(
    v: NontrivialFactorOfVerifier, a: int, expr: str, expected: bool
) -> None:
    assert v.verify({"a": a}, expr) is expected


def test_caret_power(v: NontrivialFactorOfVerifier) -> None:
    assert v.verify({"a": "x"}, "a^2") is True


@pytest.mark.parametrize(
    ("a", "expr", "expected"),
    [
        ("x", "2*a", True),
        ("x", "3*x", True),
    ],
)
def test_symbolic(
    v: NontrivialFactorOfVerifier, a: str, expr: str, expected: bool
) -> None:
    assert v.verify({"a": a}, expr) is expected


@pytest.mark.parametrize("a", [-6, 12, 1])
def test_reflexivity(v: NontrivialFactorOfVerifier, a: int) -> None:
    assert v.verify({"a": a}, str(a)) is True


def test_reflexivity_symbolic(v: NontrivialFactorOfVerifier) -> None:
    assert v.verify({"a": "x"}, "a") is True


@pytest.mark.parametrize(
    ("a", "b", "c"),
    [
        (2, 6, 12),
        (3, 9, 27),
    ],
)
def test_transitivity(v: NontrivialFactorOfVerifier, a: int, b: int, c: int) -> None:
    assert v.verify({"a": a}, str(b)) is True
    assert v.verify({"a": b}, str(c)) is True
    assert v.verify({"a": a}, str(c)) is True


@pytest.mark.parametrize(
    ("a", "b"),
    [(2, 6), (3, 12), (4, 4), (12, 3)],
)
def test_asymmetry(v: NontrivialFactorOfVerifier, a: int, b: int) -> None:
    if a == b:
        assert v.verify({"a": a}, str(b)) is True
        assert v.verify({"a": b}, str(a)) is True
    else:
        assert v.verify({"a": a}, str(b)) != v.verify({"a": b}, str(a))
