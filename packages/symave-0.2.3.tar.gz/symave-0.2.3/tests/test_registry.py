import pytest

from symave.arithmetic.factorof import NontrivialFactorOfVerifier
from symave.registry import VERIFIER_REGISTRY, get_verifier


def test_all_verifiers_have_test_suite(kb_symbols_with_tests: set[str]) -> None:
    missing = set(VERIFIER_REGISTRY) - kb_symbols_with_tests
    assert not missing, f"no test suite marked for: {missing}"
    orphaned = kb_symbols_with_tests - set(VERIFIER_REGISTRY)
    assert not orphaned, f"test suite marked for unknown symbol: {orphaned}"


def test_key_present() -> None:
    assert "integer1:factorof" in VERIFIER_REGISTRY


def test_get_verifier_returns_correct_type() -> None:
    assert isinstance(
        get_verifier("integer1:factorof"), NontrivialFactorOfVerifier
    )


def test_get_verifier_works() -> None:
    assert get_verifier("integer1:factorof").verify({"a": 2}, "4") is True


def test_unknown_key_raises() -> None:
    with pytest.raises(ValueError, match="Nonexistent"):
        get_verifier("Nonexistent")
