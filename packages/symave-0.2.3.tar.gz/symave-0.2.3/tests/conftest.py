import json
from pathlib import Path

import pytest

_REGISTRY_PATH = Path(__file__).parent.parent / "kb" / "data" / "kb_test_registry.json"


def pytest_collection_finish(session: pytest.Session) -> None:
    registry = {}
    for item in session.items:
        m = item.get_closest_marker("kb_symbol")
        if m and m.args:
            registry[m.args[0]] = str(
                Path(item.fspath).relative_to(Path(__file__).parent.parent)
            )
    _REGISTRY_PATH.write_text(json.dumps(registry, indent=2))


@pytest.fixture(scope="session")
def kb_symbols_with_tests(request: pytest.FixtureRequest) -> set[str]:
    return {
        m.args[0]
        for item in request.session.items
        for m in [item.get_closest_marker("kb_symbol")]
        if m and m.args
    }