# Contributing

## Commit messages

Follow [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/) format:

```
<type>[optional scope][optional !]: <description>

[optional body]

[optional footer(s)]
```

Common types: `feat`, `fix`, `docs`, `refactor`, `test`, `chore`.

A `!` after the type/scope denotes a breaking change.

Examples:

```
feat: add polynomial factorisation
fix(factorof): handle zero coefficient edge case
feat!: drop Python 3.13 support
```

Commit messages must describe what changed and why. Messages like "fix typo" or "try again" are not acceptable.