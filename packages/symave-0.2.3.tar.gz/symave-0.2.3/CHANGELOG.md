# CHANGELOG

<!-- version list -->

## v0.2.3 (2026-05-16)

### Bug Fixes

- PyPi publish job simplification
  ([`9cc008b`](https://gitlab.com/mzezulka/libraries/symave/-/commit/9cc008b271cbd2e1a9856ed7328adaf81e0fc61d))


## v0.2.2 (2026-05-16)

### Bug Fixes

- Improve trig condition for tag vs. main pipe
  ([`766b76a`](https://gitlab.com/mzezulka/libraries/symave/-/commit/766b76ac8e8087752a9b29e263afe07a264e35fc))


## v0.2.1 (2026-05-16)

### Bug Fixes

- Semver regexp conditional publish
  ([`8f49a2c`](https://gitlab.com/mzezulka/libraries/symave/-/commit/8f49a2c10cf171872c11ede17f82c48627e1330b))


## v0.2.0 (2026-05-16)

### Chores

- Unlimited git history depth
  ([`06c76d5`](https://gitlab.com/mzezulka/libraries/symave/-/commit/06c76d5a5762756893b848132f00113889fcdd63))

### Features

- Kb-view UI improvements, symbol data model improvements
  ([`c6f5b99`](https://gitlab.com/mzezulka/libraries/symave/-/commit/c6f5b99d4aab618a1a2fe193ec5c29bb9f698a34))


## v0.1.0 (2026-05-16)

### Bug Fixes

- Checkout main instead of using detached head
  ([`bce7463`](https://gitlab.com/mzezulka/libraries/symave/-/commit/bce7463bf95cd3c94bbead27171ba6ef10fc9b30))

- Tagging and CHANGELOG shenanigans
  ([`e667138`](https://gitlab.com/mzezulka/libraries/symave/-/commit/e6671383ead0c7774edd45b1a1b68011d045a54b))

### Chores

- Add contribution guide
  ([`33fed6f`](https://gitlab.com/mzezulka/libraries/symave/-/commit/33fed6f1883499fdfa00fb145f20c2846b53f4b2))

- Reset changelog for v0.1.0
  ([`b58a034`](https://gitlab.com/mzezulka/libraries/symave/-/commit/b58a0342164e6df2336d87623b55e4b5d6379ed0))

- Restructure KB and lock in library name: symave
  ([`4879dcb`](https://gitlab.com/mzezulka/libraries/symave/-/commit/4879dcbe90cdf21b2eea7d450a946a5e3369e766))

### Features

- Factor_of implementation
  ([`0b25c29`](https://gitlab.com/mzezulka/libraries/symave/-/commit/0b25c293d5768c371caa603822d0e45711727940))
