"""
Lock file — persists state + config for a single dependency.

File location: thirdparty/.taksa/<name>.toml

Example file:
    [download]
    state      = "DOWNLOADED"
    type       = "git"
    git_url    = "https://github.com/foo/bar.git"
    version    = "1.2.3"
    tag_prefix = "v"

    [build.Debug]
    state        = "INSTALLED"
    standard_c   = "11"
    standard_cxx = "17"

    [build.Release]
    state = "PENDING"
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

try:
    import tomllib  # Python 3.11+
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]

import tomli_w

if TYPE_CHECKING:
    from .downloaders.base import Downloader
    from .builders.base import Builder


TAKSA_DIR_NAME = ".taksa"


class LockFile:
    def __init__(self, dep_name: str, thirdparty_dir: Path) -> None:
        self._path = thirdparty_dir / TAKSA_DIR_NAME / f"{dep_name}.toml"

    @property
    def path(self) -> Path:
        return self._path

    def exists(self) -> bool:
        return self._path.exists()

    # ------------------------------------------------------------------
    # Save
    # ------------------------------------------------------------------

    def save(self, downloader: "Downloader", builder: "Builder") -> None:
        data = {
            "download": downloader.serialize(),
            "build": {
                bt.name: bs_data
                for bt, bs_data in builder.serialize().items()
            },
        }
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "wb") as f:
            tomli_w.dump(data, f)

    # ------------------------------------------------------------------
    # Load
    # ------------------------------------------------------------------

    def load(self) -> dict:
        """Return the raw parsed TOML dict. Callers use restore() for convenience."""
        with open(self._path, "rb") as f:
            return tomllib.load(f)

    def restore(self, downloader: "Downloader", builder: "Builder") -> None:
        """Deserialize the lock file and apply state + config back onto the objects."""
        if not self.exists():
            return
        data = self.load()

        if "download" in data:
            downloader.deserialize(data["download"])

        if "build" in data:
            builder.deserialize(data["build"])
