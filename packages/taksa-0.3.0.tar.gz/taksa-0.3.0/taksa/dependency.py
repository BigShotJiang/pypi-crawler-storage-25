import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse

from .configuration import Configuration, BuildType
from .state import DownloadState, BuildState
from .utils import info, fatal, mkdir
from .lock import LockFile
from .downloaders.base import Downloader
from .downloaders.git import GitDownloader
from .downloaders.curl import CurlDownloader
from .builders.base import Builder
from .builders.cmake import CMakeBuilder
from .builders.header_only import HeaderOnlyBuilder


class Dependency:
    def __init__(self, name: str, downloader: Downloader, builder: Builder):
        self.name = name
        pwd = str(os.getcwd())
        self.tp = os.path.join(pwd, Configuration.THIRDPARTY_DIR_NAME)
        self.path = Path(os.path.join(self.tp, name))
        self._downloader = downloader
        self._builder = builder
        self._lock = LockFile(name, Path(self.tp))

    # ------------------------------------------------------------------
    # Lifecycle — each method auto-saves the lock after completion
    # ------------------------------------------------------------------

    def download(self) -> None:
        self._downloader.download(self.path)
        self._lock.save(self._downloader, self._builder)

    def remove(self) -> None:
        self._downloader.remove(self.path)
        self._lock.save(self._downloader, self._builder)

    def make(self, build_type: BuildType) -> None:
        self._builder.make(build_type)
        self._lock.save(self._downloader, self._builder)

    def configure(self, build_type: BuildType) -> None:
        self._builder.configure(self.path, build_type)
        self._lock.save(self._downloader, self._builder)

    def build(self, build_type: BuildType) -> None:
        self._builder.build(build_type)
        self._lock.save(self._downloader, self._builder)

    def install(self, build_type: BuildType) -> None:
        self._builder.install(build_type)
        self._lock.save(self._downloader, self._builder)

    def clean(self, build_type: BuildType) -> None:
        self._builder.clean(build_type)
        self._lock.save(self._downloader, self._builder)

    # ------------------------------------------------------------------
    # Lock file — explicit load/save
    # ------------------------------------------------------------------

    def save_lock(self) -> None:
        """Manually flush current state to the lock file."""
        self._lock.save(self._downloader, self._builder)

    def load_lock(self) -> None:
        """Restore state + config from the lock file (if it exists)."""
        self._lock.restore(self._downloader, self._builder)

    # ------------------------------------------------------------------
    # State inspection
    # ------------------------------------------------------------------

    @property
    def download_state(self) -> DownloadState:
        return self._downloader.state

    def build_state(self, build_type: BuildType) -> BuildState:
        return self._builder.get_state(build_type)

    def status(self) -> str:
        lines = [f"[{self.name}]"]
        lines.append(f"  download : {self._downloader.state.name}")
        if self._builder.states:
            for bt, bs in self._builder.states.items():
                lines.append(f"  build    : {bt.name:<8} -> {bs.name}")
        else:
            lines.append(f"  build    : (not started)")
        return "\n".join(lines)


class CppCMakeDependency(Dependency):
    """
    Backward-compatible factory: git clone + CMake build.

    Usage (unchanged from before):
        dep = CppCMakeDependency("https://github.com/foo/bar.git")
            .set_version("1.2.3")
            .set_standard("17", "11")
    """

    def __init__(self, git_url: str):
        parsed_uri = urlparse(git_url)
        name = Path(os.path.basename(parsed_uri.path)).stem

        pwd = str(os.getcwd())
        tp = os.path.join(pwd, Configuration.THIRDPARTY_DIR_NAME)
        dep_path = Path(os.path.join(tp, name))

        downloader = GitDownloader(git_url)
        builder = CMakeBuilder(
            src=dep_path,
            install_prefix=dep_path / Configuration.INSTALL_DIR_NAME,
        )

        super().__init__(name=name, downloader=downloader, builder=builder)

        self._git_url = git_url
        self._downloader: GitDownloader = downloader
        self._builder: CMakeBuilder = builder

    # ------------------------------------------------------------------
    # Fluent setters — delegate to the underlying strategy objects
    # ------------------------------------------------------------------

    def set_version(self, version_str: str) -> "CppCMakeDependency":
        self._downloader.set_version(version_str)
        return self

    def set_tag_prefix(self, prefix: str) -> "CppCMakeDependency":
        self._downloader.set_tag_prefix(prefix)
        return self

    def set_standard(self, cpp_version: str, c_version: str) -> "CppCMakeDependency":
        self._builder.set_standard(cpp_version, c_version)
        return self

    def set_custom_build_flags(self, flags: Dict[str, str]) -> "CppCMakeDependency":
        self._builder.set_custom_build_flags(flags)
        return self

    def enable_cross_compile(
        self, system: str, arch: str, abi: str, sysroot: str
    ) -> "CppCMakeDependency":
        self._builder.enable_cross_compile(system, arch, abi, sysroot)
        return self


class HppCMakeDependency(Dependency):
    """
    Backward-compatible factory: header-only dependency.

    Two acquisition modes:
      - set_git_source()           — git clone + selective file copy
      - set_single_header_source() — direct URL download

    Factory classmethods:
      - HppCMakeDependency.from_git(...)
      - HppCMakeDependency.from_single_header(...)
    """

    def __init__(
        self,
        name: str,
        target_dir_name: Optional[str] = None,
    ):
        builder = HeaderOnlyBuilder()
        downloader: Downloader = _UninitializedDownloader(name)

        super().__init__(
            name=target_dir_name or name,
            downloader=downloader,
            builder=builder,
        )
        self._logical_name = name
        self.version: Optional[str] = None

    # ------------------------------------------------------------------
    # Fluent configuration
    # ------------------------------------------------------------------

    def set_version(self, version_str: str) -> "HppCMakeDependency":
        self.version = version_str
        if isinstance(self._downloader, GitDownloader):
            self._downloader.set_version(version_str)
        return self

    def set_git_source(
        self,
        git_url: str,
        tag_prefix: str = "",
        copy_mappings: Optional[List[Tuple[str, str]]] = None,
    ) -> "HppCMakeDependency":
        self._downloader = GitDownloader(
            git_url=git_url,
            version=self.version,
            tag_prefix=tag_prefix,
            copy_mappings=copy_mappings or [],
        )
        return self

    def set_single_header_source(
        self,
        header_url: str,
        header_filename: Optional[str] = None,
    ) -> "HppCMakeDependency":
        self._downloader = CurlDownloader(url=header_url, filename=header_filename)
        return self

    # ------------------------------------------------------------------
    # Factory classmethods
    # ------------------------------------------------------------------

    @classmethod
    def from_git(
        cls,
        name: str,
        git_url: str,
        version: str,
        copy_mappings: List[Tuple[str, str]],
        tag_prefix: str = "",
        target_dir_name: Optional[str] = None,
    ) -> "HppCMakeDependency":
        dep = cls(name=name, target_dir_name=target_dir_name)
        dep.set_version(version)
        dep.set_git_source(git_url=git_url, tag_prefix=tag_prefix, copy_mappings=copy_mappings)
        return dep

    @classmethod
    def from_single_header(
        cls,
        name: str,
        header_url: str,
        header_filename: Optional[str] = None,
        target_dir_name: Optional[str] = None,
    ) -> "HppCMakeDependency":
        dep = cls(name=name, target_dir_name=target_dir_name)
        dep.set_single_header_source(header_url=header_url, header_filename=header_filename)
        return dep


class _UninitializedDownloader(Downloader):
    """Placeholder that raises if download() is called before a source is configured."""

    def __init__(self, name: str):
        super().__init__()
        self._name = name

    def download(self, dest: Path) -> None:
        fatal(f"HppCMakeDependency '{self._name}' has no download source configured")

    def remove(self, dest: Path) -> None:
        import shutil
        dest = Path(dest)
        if dest.exists() and dest.is_dir():
            shutil.rmtree(dest)

    def serialize(self) -> dict:
        return {"type": "uninitialized", "state": self.state.name}

    def deserialize(self, data: dict) -> None:
        self.state = DownloadState[data["state"]]
