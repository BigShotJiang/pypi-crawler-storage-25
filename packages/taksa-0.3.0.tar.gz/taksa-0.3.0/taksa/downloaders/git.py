import os
import shutil
from pathlib import Path
from subprocess import run
from typing import Dict, List, Optional, Tuple

from .base import Downloader
from ..state import DownloadState
from ..utils import info, fatal, mkdir


class GitDownloader(Downloader):
    def __init__(
        self,
        git_url: str,
        version: Optional[str] = None,
        tag_prefix: str = "",
        copy_mappings: Optional[List[Tuple[str, str]]] = None,
    ):
        super().__init__()
        self.git_url = git_url
        self.version = version
        self.tag_prefix = tag_prefix
        self.copy_mappings = copy_mappings  # None means clone directly into dest

    def set_version(self, version: str) -> "GitDownloader":
        self.version = version
        return self

    def set_tag_prefix(self, prefix: str) -> "GitDownloader":
        self.tag_prefix = prefix
        return self

    def download(self, dest: Path) -> None:
        dest = Path(dest)

        if dest.exists() and any(dest.iterdir()):
            self.state = DownloadState.DOWNLOADED
            return

        self.state = DownloadState.DOWNLOADING
        try:
            if self.copy_mappings is not None:
                self._clone_and_copy(dest)
            else:
                self._clone_direct(dest)
            self.state = DownloadState.DOWNLOADED
        except Exception:
            self.state = DownloadState.FAILED
            raise

    def remove(self, dest: Path) -> None:
        dest = Path(dest)
        if dest.exists() and dest.is_dir():
            shutil.rmtree(dest)
        self.state = DownloadState.PENDING

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def serialize(self) -> dict:
        data: dict = {
            "type":       "git",
            "state":      self.state.name,
            "git_url":    self.git_url,
            "tag_prefix": self.tag_prefix,
        }
        if self.version is not None:
            data["version"] = self.version
        if self.copy_mappings:
            # Store as list of "src:dst" strings — TOML array of strings
            data["copy_mappings"] = [
                f"{src}:{dst}" for src, dst in self.copy_mappings
            ]
        return data

    def deserialize(self, data: dict) -> None:
        self.state = DownloadState[data["state"]]
        self.git_url = data.get("git_url", self.git_url)
        self.tag_prefix = data.get("tag_prefix", self.tag_prefix)
        self.version = data.get("version", self.version)
        raw_mappings = data.get("copy_mappings")
        if raw_mappings is not None:
            self.copy_mappings = [
                tuple(m.split(":", 1)) for m in raw_mappings  # type: ignore[misc]
            ]

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _clone_direct(self, dest: Path) -> None:
        info(f"Clone {dest.name} into {dest}")

        if self.version is None:
            run(["git", "clone", self.git_url, str(dest)], check=True)
            return

        tag = f"{self.tag_prefix}{self.version}"
        result = run([
            "git", "clone", "--recursive",
            "-b", tag,
            self.git_url, str(dest),
        ])

        if result.returncode != 0:
            info(
                f"Cloning with tag '{tag}' failed. "
                f"Retrying with raw version '{self.version}'"
            )
            run([
                "git", "clone", "--recursive",
                "-b", self.version,
                self.git_url, str(dest),
            ], check=True)

    def _clone_and_copy(self, dest: Path) -> None:
        assert self.copy_mappings is not None

        repo_tmp = Path(str(dest) + "_repo")

        if repo_tmp.exists():
            shutil.rmtree(repo_tmp)

        tag = None
        if self.version is not None:
            tag = f"{self.tag_prefix}{self.version}"

        info(f"Cloning '{dest.name}' from {self.git_url}")
        clone_cmd = ["git", "clone", "--recursive"]
        if tag is not None:
            clone_cmd += ["-b", tag]
        clone_cmd += [self.git_url, str(repo_tmp)]

        result = run(clone_cmd)
        if result.returncode != 0:
            fatal(f"Failed to clone {self.git_url} (tag='{tag}')")

        mkdir(dest)
        for src_rel, dst_rel in self.copy_mappings:
            src = repo_tmp / src_rel
            dst = dest / dst_rel
            if src.is_dir():
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                mkdir(dst.parent)
                shutil.copy2(src, dst)

        shutil.rmtree(repo_tmp)
