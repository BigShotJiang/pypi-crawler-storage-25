from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict

from ..state import DownloadState


class Downloader(ABC):
    def __init__(self) -> None:
        self.state: DownloadState = DownloadState.PENDING

    @abstractmethod
    def download(self, dest: Path) -> None: ...

    @abstractmethod
    def remove(self, dest: Path) -> None: ...

    @abstractmethod
    def serialize(self) -> dict: ...

    @abstractmethod
    def deserialize(self, data: dict) -> None: ...
