import shutil
import urllib.request
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from .base import Downloader
from ..state import DownloadState
from ..utils import info, mkdir


class CurlDownloader(Downloader):
    def __init__(self, url: str, filename: Optional[str] = None):
        super().__init__()
        self.url = url
        if filename is not None:
            self.filename = filename
        else:
            parsed = urlparse(url)
            self.filename = Path(parsed.path).name

    def download(self, dest: Path) -> None:
        dest = Path(dest)

        if dest.exists() and any(dest.iterdir()):
            self.state = DownloadState.DOWNLOADED
            return

        self.state = DownloadState.DOWNLOADING
        try:
            mkdir(dest)
            dst_file = dest / self.filename
            info(f"Downloading '{self.filename}' from {self.url}")
            urllib.request.urlretrieve(self.url, str(dst_file))
            self.state = DownloadState.DOWNLOADED
        except Exception:
            self.state = DownloadState.FAILED
            raise

    def remove(self, dest: Path) -> None:
        dest = Path(dest)
        if dest.exists() and dest.is_dir():
            shutil.rmtree(dest)
        self.state = DownloadState.PENDING

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def serialize(self) -> dict:
        return {
            "type":     "curl",
            "state":    self.state.name,
            "url":      self.url,
            "filename": self.filename,
        }

    def deserialize(self, data: dict) -> None:
        self.state = DownloadState[data["state"]]
        self.url = data.get("url", self.url)
        self.filename = data.get("filename", self.filename)
