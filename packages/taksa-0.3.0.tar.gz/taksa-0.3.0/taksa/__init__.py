from .dependency import Dependency
from .dependency import CppCMakeDependency
from .dependency import HppCMakeDependency
from .manager import DependencyManager
from .manager import DependecyManager  # backward-compatible alias
from .configuration import BuildType
from .state import DownloadState, BuildState
from .lock import LockFile
from .downloaders.git import GitDownloader
from .downloaders.curl import CurlDownloader
from .builders.cmake import CMakeBuilder
from .builders.header_only import HeaderOnlyBuilder
