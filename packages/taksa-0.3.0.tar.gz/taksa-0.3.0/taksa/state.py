from enum import Enum, auto


class DownloadState(Enum):
    PENDING     = auto()
    DOWNLOADING = auto()
    DOWNLOADED  = auto()
    FAILED      = auto()


class BuildState(Enum):
    PENDING     = auto()
    CONFIGURING = auto()
    CONFIGURED  = auto()
    BUILDING    = auto()
    BUILT       = auto()
    INSTALLING  = auto()
    INSTALLED   = auto()
    FAILED      = auto()
