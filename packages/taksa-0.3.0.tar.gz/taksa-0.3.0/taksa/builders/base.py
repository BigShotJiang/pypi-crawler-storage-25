from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict

from ..configuration import BuildType
from ..state import BuildState


class Builder(ABC):
    def __init__(self) -> None:
        # Tracks build state per BuildType — only populated once a build type is touched.
        self.states: Dict[BuildType, BuildState] = {}

    def _set_state(self, build_type: BuildType, state: BuildState) -> None:
        self.states[build_type] = state

    def get_state(self, build_type: BuildType) -> BuildState:
        return self.states.get(build_type, BuildState.PENDING)

    @abstractmethod
    def configure(self, src: Path, build_type: BuildType) -> None: ...

    @abstractmethod
    def build(self, build_type: BuildType) -> None: ...

    @abstractmethod
    def install(self, build_type: BuildType) -> None: ...

    @abstractmethod
    def clean(self, build_type: BuildType) -> None: ...

    @abstractmethod
    def make(self, build_type: BuildType) -> None: ...

    @abstractmethod
    def serialize(self) -> Dict[BuildType, dict]: ...

    @abstractmethod
    def deserialize(self, data: dict) -> None: ...
