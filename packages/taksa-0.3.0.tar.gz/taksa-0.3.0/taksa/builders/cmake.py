import os
import shutil
from pathlib import Path
from subprocess import run
from typing import Dict, Optional

from .base import Builder
from ..configuration import Configuration, BuildType
from ..state import BuildState
from ..utils import info, mkdir


class CMakeBuilder(Builder):
    def __init__(self, src: Path, install_prefix: Path):
        super().__init__()
        self._src = Path(src)
        self._install_prefix = Path(install_prefix)

        self._custom_build_flags: Dict[str, str] = {}
        self._select_standard_flags: Dict[str, str] = {}
        self._cross_compile_flags: Dict[str, str] = {}

    # ------------------------------------------------------------------
    # Fluent configuration
    # ------------------------------------------------------------------

    def set_standard(self, cpp_version: str, c_version: str) -> "CMakeBuilder":
        self._select_standard_flags = {
            "-DCMAKE_C_STANDARD": c_version,
            "-DCMAKE_CXX_STANDARD": cpp_version,
        }
        return self

    def set_custom_build_flags(self, flags: Dict[str, str]) -> "CMakeBuilder":
        self._custom_build_flags = flags
        return self

    def enable_cross_compile(
        self, system: str, arch: str, abi: str, sysroot: str
    ) -> "CMakeBuilder":
        c_compiler = f"{system}-{arch}-{abi}-gcc".lower()
        cxx_compiler = f"{system}-{arch}-{abi}-g++".lower()
        c_flags = f"--sysroot={sysroot} -march={arch}"
        cxx_flags = f"--sysroot={sysroot} -march={arch}"
        self._cross_compile_flags = {
            "-DCMAKE_SYSTEM_NAME": system,
            "-DCMAKE_SYSTEM_PROCESSOR": arch,
            "-DCMAKE_SYSROOT": sysroot,
            "-DCMAKE_C_COMPILER": c_compiler,
            "-DCMAKE_CXX_COMPILER": cxx_compiler,
            "-DCMAKE_C_FLAGS": c_flags,
            "-DCMAKE_CXX_FLAGS": cxx_flags,
        }
        return self

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def make(self, build_type: BuildType) -> None:
        self.configure(self._src, build_type)
        self.build(build_type)
        self.install(build_type)

    def configure(self, src: Path, build_type: BuildType) -> None:
        self._set_state(build_type, BuildState.CONFIGURING)
        try:
            build_path = self._get_build_dir_path(build_type)
            install_path = self._get_install_dir_path(build_type)

            if build_path.exists():
                shutil.rmtree(build_path)
            mkdir(build_path)

            all_flags = {
                **self._select_standard_flags,
                **self._custom_build_flags,
                **self._cross_compile_flags,
            }

            os.chdir(build_path)
            run([
                "cmake",
                f"-DCMAKE_INSTALL_PREFIX={install_path}",
                f"-DCMAKE_BUILD_TYPE={build_type.to_str()}",
                *[f"{flag}={value}" for flag, value in all_flags.items()],
                str(src),
            ], check=True)
            os.chdir(self._src.parent)
            self._set_state(build_type, BuildState.CONFIGURED)
        except Exception:
            self._set_state(build_type, BuildState.FAILED)
            raise

    def build(self, build_type: BuildType) -> None:
        self._set_state(build_type, BuildState.BUILDING)
        try:
            build_path = self._get_build_dir_path(build_type)
            if not build_path.exists():
                raise FileNotFoundError(f"Build directory not found: {build_path}")
            if any(build_path.iterdir()):
                info(f"{build_path} is not empty, skip make -j {Configuration.NPROC}")
                self._set_state(build_type, BuildState.BUILT)
                return
            os.chdir(build_path)
            run(["make", "-j", str(Configuration.NPROC)], check=True)
            os.chdir(self._src.parent)
            self._set_state(build_type, BuildState.BUILT)
        except Exception:
            self._set_state(build_type, BuildState.FAILED)
            raise

    def install(self, build_type: BuildType) -> None:
        self._set_state(build_type, BuildState.INSTALLING)
        try:
            build_path = self._get_build_dir_path(build_type)
            install_path = self._get_install_dir_path(build_type)
            if not build_path.exists():
                raise FileNotFoundError(f"Build directory not found: {build_path}")
            if install_path.exists() and any(install_path.iterdir()):
                info(f"Install directory {install_path} is not empty, skip make install")
                self._set_state(build_type, BuildState.INSTALLED)
                return
            os.chdir(build_path)
            run(["make", "install"], check=True)
            os.chdir(self._src.parent)
            self._set_state(build_type, BuildState.INSTALLED)
        except Exception:
            self._set_state(build_type, BuildState.FAILED)
            raise

    def clean(self, build_type: BuildType) -> None:
        build_path = self._get_build_dir_path(build_type)
        if build_path.exists():
            shutil.rmtree(build_path)
        self._set_state(build_type, BuildState.PENDING)

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def serialize(self) -> Dict[BuildType, dict]:
        result: Dict[BuildType, dict] = {}
        for bt, bs in self.states.items():
            entry: dict = {
                "type":  "cmake",
                "state": bs.name,
            }
            # Standard flags
            if "-DCMAKE_CXX_STANDARD" in self._select_standard_flags:
                entry["standard_cxx"] = self._select_standard_flags["-DCMAKE_CXX_STANDARD"]
            if "-DCMAKE_C_STANDARD" in self._select_standard_flags:
                entry["standard_c"] = self._select_standard_flags["-DCMAKE_C_STANDARD"]
            # Custom flags — stored as "KEY=VALUE" strings
            if self._custom_build_flags:
                entry["custom_build_flags"] = [
                    f"{k}={v}" for k, v in self._custom_build_flags.items()
                ]
            # Cross-compile flags
            if self._cross_compile_flags:
                entry["cross_compile_flags"] = [
                    f"{k}={v}" for k, v in self._cross_compile_flags.items()
                ]
            result[bt] = entry
        return result

    def deserialize(self, data: dict) -> None:
        """
        data: {
            "Debug":   {"state": "INSTALLED", "standard_cxx": "17", ...},
            "Release": {"state": "PENDING"},
        }
        """
        for bt_name, entry in data.items():
            bt = BuildType[bt_name]
            self.states[bt] = BuildState[entry["state"]]

            if "standard_cxx" in entry or "standard_c" in entry:
                self._select_standard_flags = {
                    "-DCMAKE_CXX_STANDARD": entry.get("standard_cxx", ""),
                    "-DCMAKE_C_STANDARD":   entry.get("standard_c",   ""),
                }

            raw_custom = entry.get("custom_build_flags")
            if raw_custom:
                self._custom_build_flags = dict(
                    item.split("=", 1) for item in raw_custom
                )

            raw_cross = entry.get("cross_compile_flags")
            if raw_cross:
                self._cross_compile_flags = dict(
                    item.split("=", 1) for item in raw_cross
                )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _get_build_dir_path(self, build_type: BuildType) -> Path:
        return self._install_prefix.parent / (
            Configuration.BUILD_DIR_NAME + build_type.to_path()
        )

    def _get_install_dir_path(self, build_type: BuildType) -> Path:
        return self._install_prefix.parent / (
            Configuration.INSTALL_DIR_NAME + build_type.to_path()
        )
