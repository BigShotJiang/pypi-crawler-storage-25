from pathlib import Path
from typing import Dict

from .base import Builder
from ..configuration import BuildType
from ..state import BuildState


class HeaderOnlyBuilder(Builder):
    def configure(self, src: Path, build_type: BuildType) -> None:
        self._set_state(build_type, BuildState.INSTALLED)

    def build(self, build_type: BuildType) -> None:
        self._set_state(build_type, BuildState.INSTALLED)

    def install(self, build_type: BuildType) -> None:
        self._set_state(build_type, BuildState.INSTALLED)

    def clean(self, build_type: BuildType) -> None:
        self._set_state(build_type, BuildState.PENDING)

    def make(self, build_type: BuildType) -> None:
        self._set_state(build_type, BuildState.INSTALLED)

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def serialize(self) -> Dict[BuildType, dict]:
        return {
            bt: {"type": "header_only", "state": bs.name}
            for bt, bs in self.states.items()
        }

    def deserialize(self, data: dict) -> None:
        for bt_name, entry in data.items():
            self.states[BuildType[bt_name]] = BuildState[entry["state"]]
