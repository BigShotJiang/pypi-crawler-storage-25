from .dependency import Dependency
from .configuration import BuildType


class DependencyManager:
    def __init__(self):
        self._dependencies = []

    def add_dependency(self, dependency: Dependency) -> "DependencyManager":
        self._dependencies.append(dependency)
        return self

    def download_all(self) -> None:
        for d in self._dependencies:
            d.download()

    def make_all(self, build_type: BuildType) -> None:
        for d in self._dependencies:
            d.make(build_type)


# Backward-compatible alias (typo preserved intentionally)
DependecyManager = DependencyManager
