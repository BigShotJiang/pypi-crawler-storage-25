import sys
from pathlib import Path


def info(msg: str) -> None:
    print("\033[32m[INFO] " + msg + "\033[00m", flush=True)


def fatal(msg: str) -> None:
    print("\033[31m[FATAL] " + msg + "\033[00m", flush=True)
    sys.exit(2)


def mkdir(path) -> None:
    Path(path).mkdir(parents=True, exist_ok=True)
