---
name: Bug Report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!--
Thanks for coming here to report a bug. :)

Please describe it in the sections below, fill out the correct check boxes with an "x", replacing the space inside [ ], then click the "Submit new issue" button at the bottom
-->

Details for the issue
--------------------

#### What did you do?


#### What did you expect to see?


#### What did you see instead?


Useful extra information
-------------------------

The info below often helps, please fill it out if you're able to. :)

#### What operating system are you using?

- [ ] Windows: ( _version:_ ___ )
- [ ] Linux: ( _distro:_ ___ )
- [ ] Mac OS: ( _version:_ ___ )
- [ ] Other: ___

#### I'm using python version:

- [ ] 3.10
- [ ] 3.11
- [ ] 3.12
- [ ] 3.13
- [ ] Other: ___

#### I installed PuLP via:

- [ ] pypi (python -m pip install pulp)
- [ ] github (python -m pip install -U git+https://github.com/pchtsp/vrp-model)
- [ ] Other: ___ (conda? uv?)

#### Did you also

- [ ] Tried out the latest github version: https://github.com/pchtsp/vrp-model

