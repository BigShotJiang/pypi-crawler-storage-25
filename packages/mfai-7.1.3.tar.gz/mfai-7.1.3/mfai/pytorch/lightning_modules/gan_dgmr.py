"""
This module defines the DGMRLightningModule class, which is a PyTorch Lightning module
for training a Deep Generative Model of Radar (DGMR). The model is designed for
forecasting future radar images using a Generative Adversarial Network (GAN) architecture.

The DGMRLightningModule includes:
- Initialization of model parameters and components, including the generator and discriminator.
- Forward pass method to generate predictions from input radar data.
- Discriminator and generator training steps, including loss calculations.
- Configuration of optimizers for training the generator and discriminator.

The implementation is inspired by the Skillful Nowcasting GAN from OpenClimateFix and
is modified for multiple satellite channels.
"""

from typing import Any, Literal

import torch
from einops import repeat
from lightning import LightningModule
from torch import Tensor

from mfai.pytorch.losses.gan_dgmr import (
    GridCellLoss,
    loss_hinge_disc,
    loss_hinge_gen,
)
from mfai.pytorch.models.gan_dgmr import (
    ContextConditioningStack,
    Discriminator,
    Generator,
    LatentConditioningStack,
    Sampler,
)
from mfai.pytorch.namedtensor import NamedTensor


class DGMRLightningModule(LightningModule):
    """Pytorch Lightning Module to train the GAN."""

    def __init__(
        self,
        forecast_steps: int = 18,
        input_channels: int = 1,
        gen_lr: float = 5e-5,
        disc_lr: float = 2e-4,
        conv_type: Literal["standard", "coord", "3d"] = "standard",
        grid_lambda: float = 20.0,
        beta1: float = 0.0,
        beta2: float = 0.999,
        latent_channels: int = 768,
        context_channels: int = 384,
        generation_steps: int = 6,
        precip_weight_cap: float = 24.0,
        use_attention: bool = True,
        temporal_num_layers: int = 3,
        spatial_num_layers: int = 4,
        **kwargs: Any,
    ) -> None:
        """
        From OpenClimateFix, Skillfull Nowcasting:
        https://github.com/openclimatefix/skillful_nowcasting/blob/main/dgmr/dgmr.py.

        Initialize the Deep Generative Model of Radar model.

        This is a recreation of DeepMind's Skillful Nowcasting GAN from https://arxiv.org/abs/2104.00954
        but slightly modified for multiple satellite channels.

        Args:
            forecast_steps: Number of steps to predict in the future.
            input_channels: Number of input channels per image.
            gen_lr: Learning rate for the generator.
            disc_lr: Learning rate for the discriminators, shared for both
                temporal and spatial discriminator.
            conv_type: Type of 2d convolution to use,
                see satflow/models/utils.py for options.
            grid_lambda: Lambda for the grid regularization loss.
            beta1: Beta1 for Adam optimizer.
            beta2: Beta2 for Adam optimizer.
            latent_channels: Number of channels that the latent space should be
                reshaped to, input dimension into ConvGRU, also affects the
                number of channels for other linked inputs/outputs.
            context_channels: Number of context channels (int)
            generation_steps: Number of generation steps to use in forward pass,
                in paper is 6 and the best is chosen for the loss this results
                in huge amounts of GPU memory though, so less might work better
                for training.
            precip_weight_cap: Custom ceiling for the weight function to
                compute the grid cell loss.
            use_attention: Whether to have a self-attention block in the latent
                conditioning stack or not.
            temporal_num_layers: Number of intermediate DBlock layers to use in
                the temporal discriminator.
            spatial_num_layers: Number of intermediate DBlock layers to use in
                the spatial discriminator.
            **kwargs: Allow initialization of the parameters above through key pairs

        """
        super().__init__(**kwargs)

        self.forecast_steps = forecast_steps
        self.gen_lr = gen_lr
        self.disc_lr = disc_lr
        self.beta1 = beta1
        self.beta2 = beta2
        self.grid_lambda = grid_lambda
        self.generation_steps = generation_steps

        # Definition of Loss
        self.grid_regularizer = GridCellLoss(precip_weight_cap=precip_weight_cap)

        # Definition of GAN's modules
        self.conditioning_stack = ContextConditioningStack(
            input_channels=input_channels,
            conv_type=conv_type,
            output_channels=context_channels,
        )
        self.latent_stack = LatentConditioningStack(
            input_channels=8 * input_channels,
            output_channels=latent_channels,
            use_attention=use_attention,
        )
        self.sampler = Sampler(
            forecast_steps=self.forecast_steps,
            latent_channels=latent_channels,
            context_channels=context_channels,
        )
        self.generator = Generator(
            self.conditioning_stack, self.latent_stack, self.sampler
        )
        self.discriminator = Discriminator(
            input_channels=input_channels,
            temporal_num_layers=temporal_num_layers,
            spatial_num_layers=spatial_num_layers,
        )

        self.save_hyperparameters()

        # Important: This property activates manual optimization.
        self.automatic_optimization = False

    def forward(self, x: NamedTensor, mask: Tensor = None) -> NamedTensor:
        """Apply the generator to the tensor.

        Args:
            x (NamedTensor): The past observations. `NamedTensor` of shape (B T H W C) with a feature 'rain'.
            mask (Tensor): Whether to put nan on the prediction, outside of the radar range.
               Boolean `Tensor` of shape (B H W). If True, replace the predicted value by `nan`. Default value is None.

        Returns:
            the NamedTensor that contains the prediction made by the DGMR model.
                `NamedTensor` of shape (B T H W C) with a feature 'rain'.
        """
        x_copy = x.clone()  # to avoid modifying the original tensor
        x_copy.rearrange_(
            "batch time height width features -> batch time features height width"
        )
        x_rain = x_copy["rain"].float()

        y_hat: Tensor = self.generator(x_rain)  # Apply model

        # Put nan where mask is equal to 0
        if mask is not None:
            # Create future radar mask by repeating last input radar mask:
            mask = repeat(mask, "b h w -> b t c h w", t=y_hat.shape[1], c=1)
            y_hat = torch.where(mask, float("nan"), y_hat)

        y_hat_nt = NamedTensor.new_like(y_hat, x_copy)
        y_hat_nt.rearrange_(
            "batch time features height width -> batch time height width features"
        )
        return y_hat_nt

    def discriminator_step(
        self,
        predictions: Tensor,
        images: Tensor,
        real_sequence: Tensor,
    ) -> Tensor:
        # Cat along time dimension [B, T, C, H, W]
        generated_sequence = torch.cat([images, predictions], dim=1)

        # Cat along batch for the real+generated
        concatenated_inputs = torch.cat([real_sequence, generated_sequence], dim=0)

        concatenated_outputs = self.discriminator(concatenated_inputs)

        score_real, score_generated = torch.split(
            concatenated_outputs,
            [real_sequence.shape[0], generated_sequence.shape[0]],
            dim=0,
        )
        score_real_spatial, score_real_temporal = torch.split(score_real, 1, dim=1)
        score_generated_spatial, score_generated_temporal = torch.split(
            score_generated, 1, dim=1
        )
        discriminator_loss = loss_hinge_disc(
            score_generated_spatial, score_real_spatial
        ) + loss_hinge_disc(score_generated_temporal, score_real_temporal)

        return discriminator_loss

    def generator_step(
        self,
        predictions: list[Tensor],
        images: Tensor,
        future_images: Tensor,
        real_sequence: Tensor,
    ) -> tuple[Tensor, Tensor]:
        gen_mean = torch.stack(predictions, dim=0).mean(dim=0)
        grid_cell_reg = self.grid_regularizer(gen_mean, future_images)

        # Concat along time dimension
        generated_sequences = [torch.cat([images, x], dim=1) for x in predictions]
        # Cat along batch for the real+generated, for each example in the range
        # For each of the 6 examples
        generated_scores = []
        for g_seq in generated_sequences:
            concatenated_inputs = torch.cat([real_sequence, g_seq], dim=0)
            concatenated_outputs = self.discriminator(concatenated_inputs)
            # Split along the concatenated dimension, as discrimnator concatenates along dim=1
            _, score_generated = torch.split(
                concatenated_outputs, [real_sequence.shape[0], g_seq.shape[0]], dim=0
            )
            generated_scores.append(score_generated)
        generator_disc_loss = loss_hinge_gen(torch.cat(generated_scores, dim=0))
        generator_loss = generator_disc_loss + self.grid_lambda * grid_cell_reg

        return generator_loss, grid_cell_reg

    def training_step(
        self, batch: tuple[NamedTensor, NamedTensor]
    ) -> dict[str, Tensor]:
        """Performs the training step for the batch."""
        images_nt, future_images_nt = batch
        images_nt.rearrange_(
            "batch time height width features -> batch time features height width"
        )
        future_images_nt.rearrange_(
            "batch time height width features -> batch time features height width"
        )
        images: Tensor = images_nt["rain"]
        future_images: Tensor = future_images_nt["rain"]

        real_sequence = torch.cat([images, future_images], dim=1)

        g_opt, d_opt = self.optimizers()

        # Two discriminator steps per generator step
        for _ in range(2):
            predictions = self.generator(images)
            discriminator_loss = self.discriminator_step(
                predictions, images, real_sequence
            )
            # Backward
            d_opt.zero_grad()
            self.manual_backward(discriminator_loss)
            d_opt.step()

        predictions = [self.generator(images) for _ in range(self.generation_steps)]
        generator_loss, grid_cell_reg = self.generator_step(
            predictions, images, future_images, real_sequence
        )
        g_opt.zero_grad()
        self.manual_backward(generator_loss)
        g_opt.step()

        return {
            "discriminator_loss": discriminator_loss,
            "generator_loss": generator_loss,
            "grid_cell_reg": grid_cell_reg,
        }

    def configure_optimizers(self) -> tuple[list[torch.optim.Adam], list]:
        """Return the Adam optimizers."""
        opt_g = torch.optim.Adam(
            self.generator.parameters(), lr=self.gen_lr, betas=(self.beta1, self.beta2)
        )
        opt_d = torch.optim.Adam(
            self.discriminator.parameters(),
            lr=self.disc_lr,
            betas=(self.beta1, self.beta2),
        )
        return [opt_g, opt_d], []
