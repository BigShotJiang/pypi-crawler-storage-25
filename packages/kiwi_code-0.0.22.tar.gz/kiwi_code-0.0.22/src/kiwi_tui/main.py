"""Main entry point for Autobots TUI application."""

import collections
import os
import subprocess
import sys
from pathlib import Path

from textual.app import App
from textual.binding import Binding
from loguru import logger

from kiwi_cli.logger import setup_logging
from kiwi_cli.config import ConfigManager
from kiwi_cli.client import AutobotsClientWrapper
from kiwi_cli.auth import TokenManager
# from kiwi_cli import runtime_manager
from .screens import LoginScreen, DashboardScreen, RuntimeCleanupScreen  # , RuntimeLogsScreen
from kiwi_tui.screens.runtime_cleanup import RuntimeRow
from kiwi_tui.runtime_agent import (
    RuntimeConnectArgs,
    bind_pending_to_run,
    ensure_runtime_for_run,
    http_url_from_server,
    list_known_runtimes,
    server_from_backend_url,
    start_pending_runtime,
    kill_pid,
)



class AutobotsTUI(App):
    """A modern Textual app for managing Autobots."""

    CSS = """
    Screen {
        background: $background;
        color: $foreground;
    }

    Header {
        background: $background;
        color: $foreground;
    }

    Header > HeaderTitle {
        background: $background;
        color: $foreground;
        text-style: none;
    }

    Header > HeaderIcon {
        background: $background;
        color: $brand-cyan;
    }

    Footer {
        background: $background;
        color: $foreground;
    }

    FooterKey {
        background: $background;
        color: $foreground;
    }

    FooterKey .footer-key--key {
        background: $background;
        color: $brand-cyan;
        text-style: none;
    }

    FooterKey .footer-key--description {
        background: $background;
        color: $foreground;
    }

    FooterKey:hover .footer-key--key {
        text-style: bold;
    }

    MarkdownBlock > .code_inline {
        background: $background;
        color: $brand-cyan;
        text-style: bold;
    }
    OptionList {
        background: $surface;
        border: tall $brand-cyan;
        color: $foreground;
    }

    OptionList > .option-list--option-highlighted {
        background: $background;
        color: $brand-cyan;
        text-style: bold;
    }

    Button {
        background: $background;
        color: $foreground;
        border: solid $brand-cyan;
    }

    Button:hover {
        background: $background;
        color: $brand-cyan;
    }

    Input {
        background: $background;
        color: $foreground;
        border: solid $brand-cyan;
    }

    Input:focus {
        border: solid $brand-cyan;
    }
    """

    TITLE = "Kiwi Code"
    SUB_TITLE = str("~" / Path.cwd().relative_to(Path.home())) if Path.cwd().is_relative_to(Path.home()) else str(Path.cwd())

    SCREENS = {
        "login": LoginScreen,
        "dashboard": DashboardScreen,
        # "runtime_logs": RuntimeLogsScreen,
    }
    BINDINGS = [
        # Copy: Textual uses ctrl+c / super+c at the Screen & TextArea level. Terminal-level copy
        # shortcuts vary by OS and terminal. We add ctrl+shift+c as an extra cross-platform alias.
        Binding("ctrl+shift+c", "screen.copy_text", "Copy", show=False),
        # Quit: don't use ctrl+c (reserved for copy).
        Binding("ctrl+q", "quit", "Quit", show=True),
        Binding("ctrl+o", "show_logs", "Logs", show=False),
        Binding("ctrl+l", "logout", "Logout", show=False),
    ]
    # Map backend HTTP URLs to kiwi connect server presets
    _KIWI_SERVER_MAP = {
        "https://api.meetkiwi.ai": "app",
        "https://dev.api.myautobots.com": "dev",
        "http://localhost:8000": "local",
    }

    # Max lines to keep in the runtime log buffer
    _KIWI_LOG_BUFFER_SIZE = 5000

    def __init__(
        self,
        config_manager: ConfigManager | None = None,
        token_manager: TokenManager | None = None,
        runtime_args: RuntimeConnectArgs | None = None,
    ):
        """Initialize Autobots TUI app.

        Args:
            config_manager: Configuration manager instance
            token_manager: Token manager instance
        """
        super().__init__()
        self.config_manager = config_manager or ConfigManager()
        self.config = self.config_manager.config

        # Runtime flags for this TUI session (mirrors `kiwi-runtime connect ...`).
        # Note: runtime processes themselves are tracked per *run_id* (see runtime_agent.py).
        self.runtime_args: RuntimeConnectArgs = runtime_args or RuntimeConnectArgs()
        self.pending_runtime_id: str | None = None

        self._kiwi_token = None  # Set after auth for kiwi CLI session
        # self._kiwi_pid = None  # PID of the runtime process
        # self._log_fp = None  # File pointer for tailing runtime log
        self._kiwi_log_lines = collections.deque(maxlen=self._KIWI_LOG_BUFFER_SIZE)

        # Initialize token manager
        self.token_manager = token_manager or TokenManager()

        # Check for existing tokens (locked to avoid refresh-token rotation races with other processes).
        access_token = None
        with self.token_manager.file_lock():
            tokens = self.token_manager.load_tokens()
            if tokens:
                # Check if token needs refresh
                if tokens.is_expired():
                    logger.info("Access token expired, attempting refresh")
                    # Try to refresh token
                    temp_client = AutobotsClientWrapper(base_url=self.config.backend_url)
                    success, new_tokens, message = temp_client.refresh_token(tokens.refresh_token)

                    if success and new_tokens:
                        logger.info("Token refreshed successfully")
                        self.token_manager.save_tokens(new_tokens)
                        access_token = new_tokens.access_token
                    else:
                        logger.warning(f"Token refresh failed: {message}")
                        self.token_manager.clear_tokens()
                else:
                    logger.info("Valid access token found")
                    access_token = tokens.access_token
        # Share token with kiwi CLI session
        self._kiwi_token = access_token

        # Initialize autobots client
        self.autobots_client = AutobotsClientWrapper(
            base_url=self.config.backend_url,
            access_token=access_token,
            api_key=self.config.api_key,
        )

    def copy_to_clipboard(self, text: str) -> None:
        """Copy text to the system clipboard.

        Textual's default clipboard implementation uses OSC52, which is not supported
        by macOS Terminal.app and some other terminals. On macOS we use `pbcopy` as a
        reliable fallback.
        """
        # Always update Textual's local clipboard.
        try:
            self._clipboard = text  # type: ignore[attr-defined]
        except Exception:
            pass

        if sys.platform == "darwin":
            try:
                subprocess.run(["pbcopy"], input=text.encode("utf-8"), check=False)
                return
            except Exception:
                # Fall back to Textual's OSC52 mechanism below.
                pass

        super().copy_to_clipboard(text)

    # Brand color for the kiwi cyan, kept readable on both dark and
    # light themes. Exposed to CSS as `$brand-cyan` via
    # `get_css_variables` below.
    BRAND_CYAN_DARK = "#5fffff"   # bright cyan — pops on dark backgrounds
    BRAND_CYAN_LIGHT = "#006d8a"  # deeper teal — readable on light backgrounds

    def _is_dark_theme(self) -> bool:
        """Best-effort detection of whether the active theme is dark."""
        # Newer Textual exposes registered themes via `available_themes`.
        themes = getattr(self, "available_themes", None)
        theme_name = getattr(self, "theme", None)
        if themes and theme_name and theme_name in themes:
            return bool(getattr(themes[theme_name], "dark", True))
        # Fallback for older Textual versions that only expose `dark`.
        return bool(getattr(self, "dark", True))

    def get_css_variables(self) -> dict[str, str]:
        """Inject theme-aware brand color and override palette to match kiwi-code UX.

        UX requirement: use a minimal palette (white + kiwi cyan) for UI text and
        accents across screens.
        """
        variables = super().get_css_variables()
        cyan = self.BRAND_CYAN_DARK if self._is_dark_theme() else self.BRAND_CYAN_LIGHT
        variables["brand-cyan"] = cyan

        # Two-color palette: foreground text + cyan accents. Keep readability in light theme.
        foreground = "#ffffff" if self._is_dark_theme() else "#000000"
        variables["foreground"] = foreground
        variables["text"] = foreground

        # Map most semantic colors to the brand cyan (removes scattered colors).
        for k in ("primary", "secondary", "accent", "error", "warning", "success"):
            variables[k] = cyan

        # Also align text-* semantic variants used by Markdown, notifications, etc.
        for k in ("text-warning", "text-error", "text-success"):
            variables[k] = cyan

        # Surfaces and borders: keep background dark, use cyan borders.
        bg = variables.get("background", "#000000")
        variables["surface"] = bg
        variables["boost"] = bg
        variables["primary-background"] = bg
        variables["panel"] = cyan
        variables["border"] = cyan
        variables["border-blurred"] = cyan


        # Chat UX: full-width highlight color for user-message rows.
        # Keep it subtle and theme-aware.
        variables["user-msg-bg"] = "#333333" if self._is_dark_theme() else "#e8e8e8"
        # Scrollbars: cyan thumb, dark track.
        variables["scrollbar"] = cyan
        variables["scrollbar-hover"] = cyan
        variables["scrollbar-active"] = cyan
        variables["scrollbar-background"] = bg
        variables["scrollbar-background-hover"] = bg
        variables["scrollbar-background-active"] = bg
        variables["scrollbar-corner-color"] = bg

        # Footer palette variables (Textual 8 uses these).
        variables["footer-background"] = bg
        variables["footer-foreground"] = foreground
        variables["footer-description-background"] = bg
        variables["footer-description-foreground"] = foreground

        # Cursor / selection highlight: cyan text on background (no extra colors).
        variables["block-cursor-foreground"] = cyan
        variables["block-cursor-background"] = bg
        variables["block-cursor-blurred-foreground"] = cyan
        variables["block-cursor-blurred-background"] = bg
        return variables

    def watch_theme(self, theme: str) -> None:
        """Re-resolve palette variables whenever the user switches theme."""
        try:
            self.refresh_css()
        except Exception:
            pass

    def watch_dark(self, dark: bool) -> None:
        """Re-resolve `$brand-cyan` for older Textual versions that toggle
        dark mode via the `dark` reactive instead of the theme system."""
        try:
            self.refresh_css()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Runtime (CLI agent) lifecycle helpers (per run_id)
    # ------------------------------------------------------------------

    def _effective_runtime_args(self) -> RuntimeConnectArgs:
        """Resolve runtime args for this session (derive server from backend_url)."""
        server = self.runtime_args.server or server_from_backend_url(self.config.backend_url)
        return RuntimeConnectArgs(
            server=server,
            email=self.runtime_args.email,
            token=self.runtime_args.token,
            scope=self.runtime_args.scope,
            allow_dirs=self.runtime_args.allow_dirs,
        )

    def ensure_runtime_for_run_id(self, run_id: str) -> None:
        """Ensure runtime exists for a run_id (reuse if alive)."""
        try:
            import os
            import sys

            if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("KIWI_DISABLE_RUNTIME") == "1":
                return

            # Ensure we don't spawn a runtime with an expired access token.
            # This matters because the runtime process receives a single snapshot token via `--token`.
            self._refresh_token_if_needed()

            ok, _pid, _lp, msg = ensure_runtime_for_run(
                run_id=run_id,
                python_exe=sys.executable,
                cwd=os.getcwd(),
                args=self._effective_runtime_args(),
                token_fallback=self._kiwi_token,
            )
            if ok:
                logger.info(msg)
            else:
                logger.warning(f"Runtime not started: {msg}")
        except Exception as e:
            logger.exception(f"Failed to ensure runtime for run {run_id}: {e}")

    def ensure_pending_runtime(self) -> None:
        """Start a pending runtime for the next run_id (session-scoped)."""
        try:
            import os
            import sys
            from kiwi_tui.runtime_agent import get_running_pid_for_pending

            if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("KIWI_DISABLE_RUNTIME") == "1":
                return

            pending_id = getattr(self, "pending_runtime_id", None)
            if pending_id:
                pid = get_running_pid_for_pending(pending_id)
                if pid:
                    return
                # stale pending runtime id in session; clear it and start fresh
                self.pending_runtime_id = None

            # Ensure we don't spawn a runtime with an expired access token.
            self._refresh_token_if_needed()

            ok, new_pending_id, _pid, _lp, msg = start_pending_runtime(
                python_exe=sys.executable,
                cwd=os.getcwd(),
                args=self._effective_runtime_args(),
                token_fallback=self._kiwi_token,
            )
            if ok and new_pending_id:
                self.pending_runtime_id = new_pending_id
                logger.info(msg)
            else:
                logger.warning(f"Pending runtime not started: {msg}")
        except Exception as e:
            logger.exception(f"Failed to start pending runtime: {e}")

    def bind_pending_runtime_to_run(self, run_id: str) -> None:
        """Bind current session's pending runtime to run_id (if any)."""
        pending_id = getattr(self, "pending_runtime_id", None)
        if not pending_id:
            return
        try:
            ok, _lp, msg = bind_pending_to_run(pending_id=pending_id, run_id=run_id)
            if ok:
                logger.info(msg)
                self.pending_runtime_id = None
            else:
                logger.warning(msg)
        except Exception as e:
            logger.exception(f"Failed to bind pending runtime: {e}")

    def on_mount(self) -> None:
        """Called when app is mounted."""
        logger.info("Autobots TUI on_mount called")
        logger.info(f"Backend URL: {self.config.backend_url}")

        # Set theme
        self.dark = self.config.theme == "dark"

        # Check if user is authenticated
        if self.token_manager.is_authenticated():
            logger.info("User is authenticated, showing dashboard")
            self._start_token_refresh()
            try:
                self.switch_screen("dashboard")
            except IndexError:
                self.push_screen("dashboard")
        else:
            logger.info("User not authenticated, showing login screen")
            try:
                self.switch_screen("login")
            except IndexError:
                self.push_screen("login")

# ------------------------------------------------
# COMMENTING ALL THE KIWI RUNTIME MANAGEMENT CODE 
# ------------------------------------------------

    # @property
    # def runtime_log_cmd(self) -> str:
    #     """Derive the kiwi connect command from the configured backend_url."""
    #     # Allow env var override
    #     override = os.getenv("KIWI_CODE_RUNTIME_LOG_CMD")
    #     if override:
    #         return override

    #     import sys
    #     python = f'"{sys.executable}"'

    #     backend_url = self.config.backend_url.rstrip("/")
    #     server = self._KIWI_SERVER_MAP.get(backend_url)
    #     if server:
    #         cmd = f"{python} -m kiwi_runtime connect --server {server}"
    #     else:
    #         # Custom URL — convert http(s) to ws(s)
    #         ws_url = backend_url.replace("https://", "wss://").replace("http://", "ws://")
    #         cmd = f"{python} -m kiwi_runtime connect --server {ws_url}"

    #     return cmd

    # ------------------------------------------------------------------
    # Persistent kiwi runtime (per working directory, survives TUI restarts)
    # ------------------------------------------------------------------

    # def _start_kiwi_session(self) -> None:
    #     """Start a new kiwi-runtime for this directory, or attach if already running."""
    #     existing_pid = runtime_manager.get_running_pid()
    #     if existing_pid:
    #         logger.info(f"Kiwi runtime already running (PID {existing_pid})")
    #         self._kiwi_pid = existing_pid
    #         self._start_log_tail()
    #         return

    #     cmd = self.runtime_log_cmd
    #     if not cmd:
    #         return

    #     logger.info(f"Starting kiwi runtime: {cmd}")
    #     try:
    #         env = os.environ.copy()
    #         env["PYTHONUNBUFFERED"] = "1"
    #         env["PYTHONIOENCODING"] = "utf-8"

    #         token = self._kiwi_token
    #         if token:
    #             env["KIWI_AUTH_TOKEN"] = token

    #         rt_log_path = runtime_manager.log_path()
    #         log_fp = open(rt_log_path, "a")

    #         proc = subprocess.Popen(
    #             cmd,
    #             shell=True,
    #             stdin=subprocess.DEVNULL,
    #             stdout=log_fp,
    #             stderr=subprocess.STDOUT,
    #             start_new_session=True,
    #             env=env,
    #         )
    #         log_fp.close()  # Child inherited the fd via fork

    #         runtime_manager.save_pid(proc.pid)
    #         self._kiwi_pid = proc.pid

    #         self._start_log_tail()
    #         logger.info(f"Kiwi runtime started (PID {proc.pid})")
    #     except Exception as e:
    #         logger.error(f"Failed to start kiwi runtime: {e}")

    # def _start_log_tail(self) -> None:
    #     """Open the runtime log file for tailing."""
    #     if self._log_fp is not None:
    #         return  # Already tailing

    #     rt_log_path = runtime_manager.log_path()
    #     if not rt_log_path.exists():
    #         return

    #     try:
    #         self._log_fp = open(rt_log_path, "r", encoding="utf-8", errors="replace")
    #         # Seek near end so we don't replay the entire history
    #         size = rt_log_path.stat().st_size
    #         if size > 65536:
    #             self._log_fp.seek(size - 65536)
    #         self.set_interval(0.1, self._drain_kiwi_output)
    #         logger.info("Started tailing runtime log")
    #     except OSError as e:
    #         logger.error(f"Failed to tail runtime log: {e}")

    # def _drain_kiwi_output(self) -> None:
    #     """Read new lines from the runtime log file and buffer them."""
    #     fp = self._log_fp
    #     if fp is None:
    #         return

    #     chunk = fp.read()
    #     if not chunk:
    #         # No new output — check if runtime is still alive
    #         if self._kiwi_pid:
    #             if not runtime_manager._pid_exists(self._kiwi_pid):
    #                 logger.info("Kiwi runtime exited, restarting...")
    #                 self._kiwi_pid = None
    #                 self._close_log_tail()
    #                 self._start_kiwi_session()
    #         return

    #     for line in chunk.splitlines():
    #         self._kiwi_log_lines.append(line)

    # def _close_log_tail(self) -> None:
    #     """Close the log file we are tailing (does NOT stop the runtime)."""
    #     fp = self._log_fp
    #     if fp:
    #         try:
    #             fp.close()
    #         except OSError:
    #             pass
    #         self._log_fp = None

    # def _stop_runtime(self) -> None:
    #     """Explicitly stop the kiwi-runtime for the current directory."""
    #     # Drain any remaining output before closing
    #     self._drain_kiwi_output()
    #     runtime_manager.stop_runtime()
    #     self._kiwi_pid = None
    #     self._close_log_tail()
    #     self._kiwi_log_lines.append("--- Runtime disconnected ---")

    # ------------------------------------------------------------------
    # Periodic token refresh
    # ------------------------------------------------------------------

    def _start_token_refresh(self) -> None:
        """Schedule periodic token refresh (every `refresh_interval` minutes)."""
        interval_min = self.config.refresh_interval  # default 5
        logger.info(f"Token refresh scheduled every {interval_min} minutes")
        self.set_interval(interval_min * 60, self._refresh_token_if_needed)
        # Write current tokens to shared files so runtime can read them
        # if self._kiwi_token:
        #     runtime_manager.save_token(self._kiwi_token)
        # tokens = self.token_manager.load_tokens()
        # if tokens and tokens.refresh_token:
        #     runtime_manager.save_refresh_token(tokens.refresh_token)

    def _refresh_token_if_needed(self) -> None:
        """Check token expiry and refresh if needed."""
        with self.token_manager.file_lock():
            tokens = self.token_manager.load_tokens()
            if not tokens:
                logger.debug("No tokens to refresh")
                return

            if not tokens.is_expired():
                logger.debug("Token still valid, skipping refresh")
                return

            logger.info("Token expired or near expiry, refreshing...")
            success, new_tokens, message = self.autobots_client.refresh_token(
                tokens.refresh_token
            )

            if success and new_tokens:
                logger.info("Token refreshed successfully")
                # Save to disk
                self.token_manager.save_tokens(new_tokens)
                # Update TUI client
                self.autobots_client.update_token(new_tokens.access_token)
                # Update shared state
                self._kiwi_token = new_tokens.access_token
                # Write to runtime directory so the runtime process can pick it up
                # runtime_manager.save_token(new_tokens.access_token)
                # if new_tokens.refresh_token:
                #     runtime_manager.save_refresh_token(new_tokens.refresh_token)
            else:
                logger.error(f"Token refresh failed: {message}")

    # ------------------------------------------------------------------

    # def action_toggle_runtime(self) -> None:
    #     """Toggle the kiwi-runtime: stop if running, start if stopped."""
    #     if self._kiwi_pid:
    #         self._stop_runtime()
    #         logger.info("Runtime stopped by user")
    #         self.notify("Runtime stopped (Ctrl+K to start)", severity="information")
    #     else:
    #         self._start_kiwi_session()
    #         if self._kiwi_pid:
    #             logger.info("Runtime started by user")
    #             self.notify("Runtime started", severity="information")
    #         else:
    #             self.notify("Failed to start runtime", severity="error")

    # def action_restart_runtime(self) -> None:
    #     """Restart the kiwi-runtime for the current directory."""
    #     if self._kiwi_pid:
    #         self._stop_runtime()
    #         logger.info("Runtime stopped for restart")
    #     self._start_kiwi_session()
    #     if self._kiwi_pid:
    #         logger.info("Runtime restarted by user")
    #         self.notify("Runtime restarted", severity="information")
    #     else:
    #         self.notify("Failed to restart runtime", severity="error")

    # def action_runtime_logs(self) -> None:
    #     """Show the runtime log stream."""
    #     self.push_screen("runtime_logs")

    def action_toggle_dark(self) -> None:
        """Toggle dark mode."""
        self.dark = not self.dark
        theme = "dark" if self.dark else "light"
        self.config_manager.update(theme=theme)
        logger.info(f"Theme changed to {theme}")
        self.notify(f"Theme: {theme}", severity="information")

    def action_show_logs(self) -> None:
        """Global keyboard shortcut to open CLI logs (if dashboard is active)."""
        try:
            screen = self.screen
            if hasattr(screen, "open_runtime_logs"):
                screen.open_runtime_logs()
        except Exception:
            pass

    def action_logout(self) -> None:
        """Logout user and return to login screen."""
        logger.info("User logout requested")

        # Detach from runtime logs — do NOT stop the runtime process
        # self._close_log_tail()
        # self._kiwi_pid = None

        # Clear tokens
        self.token_manager.clear_tokens()

        # Reset client to unauthenticated
        self.autobots_client = AutobotsClientWrapper(
            base_url=self.config.backend_url,
        )

        # Switch to login screen
        self.switch_screen("login")
        self.notify("Logged out successfully", severity="information")

    def _final_exit(self) -> None:
        """Exit the application (internal helper)."""
        logger.info("Autobots TUI shutting down")
        try:
            if hasattr(self, "autobots_client"):
                self.autobots_client.close()
        except Exception:
            pass
        self.exit()

    def _on_runtime_cleanup_done(self, pids_to_kill: list[int]) -> None:
        """Callback from RuntimeCleanupScreen."""
        for pid in pids_to_kill:
            try:
                kill_pid(int(pid))
            except Exception:
                pass
        self._final_exit()

    def request_quit(self) -> None:
        """Quit flow with optional runtime cleanup prompt."""
        import os

        # In headless tests or when explicitly disabled, don't show interactive prompts.
        if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("KIWI_DISABLE_RUNTIME") == "1":
            self._final_exit()
            return

        try:
            all_rt = list_known_runtimes()
        except Exception:
            all_rt = []

        alive = [r for r in all_rt if r.get("alive") and r.get("pid")]
        if not alive:
            self._final_exit()
            return

        rows: list[RuntimeRow] = []
        for r in alive:
            try:
                meta = r.get("meta") or {}
                name = None
                if isinstance(meta, dict):
                    name = meta.get("run_name")
                rows.append(
                    RuntimeRow(
                        kind=str(r.get("kind")),
                        runtime_id=str(r.get("id")),
                        pid=int(r.get("pid")),
                        alive=True,
                        log_path=str(r.get("log_path")),
                        name=name if isinstance(name, str) else None,
                        kill=False,
                    )
                )
            except Exception:
                continue

        # Show interactive prompt; the callback will exit.
        self.push_screen(RuntimeCleanupScreen(rows), callback=self._on_runtime_cleanup_done)

    def action_quit(self) -> None:
        """Quit the application."""
        self.request_quit()


def _run_tui(runtime_args: RuntimeConnectArgs | None = None):
    """Run the TUI in the terminal."""
    config_manager = ConfigManager()
    config = config_manager.load()
    setup_logging(log_level=config.log_level)

    # If the user passed `--server`, use the same value for the TUI HTTP backend
    # (do not persist to disk; this is a runtime override).
    if runtime_args and runtime_args.server:
        try:
            config.backend_url = http_url_from_server(runtime_args.server)
        except Exception:
            pass

    logger.info("=" * 60)
    logger.info("Starting Autobots TUI")
    logger.info("=" * 60)

    app = AutobotsTUI(config_manager=config_manager, runtime_args=runtime_args)
    app.run()

    logger.info("Autobots TUI terminated")


def _serve_tui(port: int = 8566):
    """Serve the TUI in the browser via textual serve."""
    import sys
    from textual_serve.server import Server

    server = Server(f"{sys.executable} -m kiwi_tui.main", port=port)
    server.serve()


def _reexec_as_kiwi() -> None:
    """Re-exec via a symlink named ``kiwi`` so the kernel-reported
    process name (``ps -o comm`` / VS Code's ``${process}``) becomes
    ``kiwi`` instead of ``python3.13``.

    ``setproctitle`` cannot change ``comm`` on macOS/Linux — only a real
    ``exec`` of a file whose basename is ``kiwi`` can. We create a stable
    symlink at ``~/.kiwi/bin/kiwi`` pointing at the current Python
    interpreter and ``execve`` through it, re-invoking ``kiwi_tui.main``.
    A one-shot env var guards against infinite re-exec.
    """
    import os
    import sys

    # Allow disabling the re-exec (useful for debugging or environments where
    # symlink-based venv detection is unreliable).
    if os.environ.get("KIWI_DISABLE_REEXEC") == "1":
        return

    # If we're running inside a virtual environment (venv/virtualenv/uv venv),
    # re-exec'ing via a symlink in ~/.kiwi/bin can break venv detection on
    # macOS/Homebrew and cause imports like `kiwi_tui` to fail. Prefer
    # correctness over process-name cosmetics.
    if sys.prefix != sys.base_prefix:
        return

    # Windows: pipx/pip install kiwi.exe as a native launcher, so the
    # process is already named "kiwi" — no re-exec needed. Creating
    # symlinks also requires Administrator / Developer Mode on Windows,
    # so we skip this path entirely.
    if sys.platform == "win32":
        return

    if os.environ.get("_KIWI_PROC_RENAMED") == "1":
        return
    exe_basename = os.path.basename(sys.executable)
    if exe_basename == "kiwi" or exe_basename.lower() == "kiwi.exe":
        return

    try:
        from pathlib import Path
        bin_dir = Path.home() / ".kiwi" / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        link = bin_dir / "kiwi"
        # Point at sys.executable directly (not realpath). The real
        # interpreter lives in the venv's bin dir alongside pyvenv.cfg;
        # resolving symlinks would land on the base interpreter and lose
        # the venv. We also inject the current site-packages into
        # PYTHONPATH below as an extra safety net for installs (e.g.
        # pipx) where sys.executable itself is a symlink.
        target = sys.executable

        needs_recreate = True
        if link.is_symlink():
            try:
                if os.readlink(link) == target:
                    needs_recreate = False
            except OSError:
                needs_recreate = True
        elif link.exists():
            needs_recreate = True
        if needs_recreate:
            try:
                link.unlink()
            except FileNotFoundError:
                pass
            link.symlink_to(target)
    except OSError:
        return

    new_env = os.environ.copy()
    new_env["_KIWI_PROC_RENAMED"] = "1"

    # Preserve access to the current interpreter's site-packages so the
    # re-exec'd Python can still import ``kiwi_tui`` even if venv auto-
    # detection doesn't kick in through the symlink.
    try:
        import site
        site_paths = [p for p in site.getsitepackages() if p]
        user_site = site.getusersitepackages()
        if user_site:
            site_paths.append(user_site)
        if site_paths:
            existing = new_env.get("PYTHONPATH", "")
            parts = site_paths + ([existing] if existing else [])
            new_env["PYTHONPATH"] = os.pathsep.join(parts)
    except Exception:
        pass

    # macOS framework builds honor this env var when determining
    # sys.executable / sys.prefix, which keeps the original venv active.
    new_env.setdefault("__PYVENV_LAUNCHER__", sys.executable)

    try:
        os.execve(
            str(link),
            [str(link), "-m", "kiwi_tui.main", *sys.argv[1:]],
            new_env,
        )
    except OSError:
        return


def main():
    """Entry point for the kiwi command."""
    _reexec_as_kiwi()

    import setproctitle
    setproctitle.setproctitle("kiwi")

    # Set the terminal tab title (OSC 0) so VS Code / iTerm show "kiwi"
    # instead of the python interpreter name.
    import sys
    if sys.stdout.isatty():
        sys.stdout.write("\033]0;kiwi\007")
        sys.stdout.flush()

    import argparse

    parser = argparse.ArgumentParser(prog="kiwi", description="Kiwi Code TUI")
    subparsers = parser.add_subparsers(dest="command")
    # Runtime (CLI agent) flags — mirrored from `kiwi-runtime connect`.
    # These are used to auto-start the runtime alongside the TUI.
    parser.add_argument(
    "--server",
        default=None,
        help=(
            "Server to connect to. Use a preset name (app, dev, local) "
            "or a full URL (e.g. https://custom.server.com)."
        ),
    )
    parser.add_argument("--email", default=None, help="Email address for runtime login (usually not needed)")
    parser.add_argument("--token", default=None, help="Access token for runtime (overrides saved TUI token)")
    parser.add_argument(
        "--scope",
        choices=["restricted", "full"],
        default="restricted",
        help="Runtime execution scope (restricted or full)",
    )
    parser.add_argument(
        "--allow",
        action="append",
        dest="allow_dirs",
        default=[],
        metavar="PATH",
        help="Additional allowed directory for restricted mode (repeatable)",
    )


    serve_parser = subparsers.add_parser("serve", help="Serve the TUI in the browser")
    serve_parser.add_argument(
        "--port", "-p", type=int, default=8566, help="Port to serve on (default: 8566)"
    )

    args = parser.parse_args()

    if args.command == "serve":
        _serve_tui(port=args.port)
    else:
        runtime_args = RuntimeConnectArgs(
            server=args.server,
            email=args.email,
            token=args.token,
            scope=args.scope,
            allow_dirs=tuple(args.allow_dirs or []),
        )
        _run_tui(runtime_args=runtime_args)


if __name__ == "__main__":
    main()
