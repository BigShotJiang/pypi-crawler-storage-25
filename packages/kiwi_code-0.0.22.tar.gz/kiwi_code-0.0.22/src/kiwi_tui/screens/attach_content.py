"""Attach content modal screen — file browser or URL input."""

from textual.app import ComposeResult
from textual.screen import ModalScreen
from textual.widgets import Static, Button, Input
from textual.containers import Vertical, Horizontal
from textual.binding import Binding


class AttachContentScreen(ModalScreen[dict]):
    """Modal for attaching content: browse files or add a URL.

    Returns a dict: {"type": "files"} to open file browser,
    {"type": "url", "url": "<value>"} for a URL, or {} if cancelled.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
    ]

    CSS = """
    AttachContentScreen {
        align: center middle;
    }

    #attach-container {
        width: 60;
        height: auto;
        max-height: 20;
        background: $surface;
        border: solid $accent;
        padding: 1 2;
    }

    #attach-title {
        width: 100%;
        text-align: center;
        text-style: bold;
        color: $primary;
        height: 1;
        margin-bottom: 1;
    }

    #url-input {
        width: 100%;
        border: solid $accent;
        margin-bottom: 1;
    }

    #url-input:focus {
        border: solid $primary;
    }

    #attach-buttons {
        height: 3;
        width: 100%;
        align: center middle;
    }

    .attach-btn {
        margin: 0 1;
        background: $boost;
        /* Default: readable neutral text; Hover/Focus: brand cyan */
        color: $foreground;
        border: solid $accent;
    }

    .attach-btn:hover, .attach-btn:focus {
        background: $boost;
        color: $brand-cyan;
    }

    #cancel-attach-btn {
        background: $surface;
        color: $foreground;
        border: solid $panel;
    }

    #cancel-attach-btn:hover, #cancel-attach-btn:focus {
        background: $surface;
        color: $brand-cyan;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="attach-container"):
            yield Static("Attach Content", id="attach-title")
            yield Input(placeholder="Paste a URL...", id="url-input")
            with Horizontal(id="attach-buttons"):
                yield Button("Add URL", id="add-url-btn", classes="attach-btn")
                yield Button("Browse Files", id="browse-files-btn", classes="attach-btn")
                yield Button("Cancel", id="cancel-attach-btn")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "add-url-btn":
            url = self.query_one("#url-input", Input).value.strip()
            if url:
                self.dismiss({"type": "url", "url": url})
            else:
                self.query_one("#url-input", Input).focus()
        elif btn_id == "browse-files-btn":
            self.dismiss({"type": "files"})
        elif btn_id == "cancel-attach-btn":
            self.dismiss({})

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "url-input":
            url = event.value.strip()
            if url:
                self.dismiss({"type": "url", "url": url})

    def action_cancel(self) -> None:
        self.dismiss({})
