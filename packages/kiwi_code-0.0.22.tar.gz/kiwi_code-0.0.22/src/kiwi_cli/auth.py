"""Authentication and token management."""

from __future__ import annotations

import json
import os
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Optional
def _lock_path_for(token_path: Path) -> Path:
    return token_path.with_suffix(".lock")


@contextmanager
def _file_lock(lock_path: Path):
    """Cross-process lock using a lockfile.

    This prevents concurrent refresh-token rotation races and avoids partial writes.
    """
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fp = open(lock_path, "a+")
    try:
        if sys.platform == "win32":
            import msvcrt
            # Lock 1 byte; blocks until available.
            msvcrt.locking(fp.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(fp.fileno(), fcntl.LOCK_EX)
        yield
    finally:
        try:
            if sys.platform == "win32":
                import msvcrt
                msvcrt.locking(fp.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(fp.fileno(), fcntl.LOCK_UN)
        finally:
            fp.close()


def _atomic_write_json(path: Path, data: dict) -> None:
    """Atomically write JSON (write temp + replace) to avoid corruption."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    if sys.platform != "win32":
        path.chmod(0o600)

from loguru import logger

from .models import AuthTokens



class TokenManager:
    """Manages authentication tokens with secure storage."""

    def __init__(self, token_path: Optional[Path] = None):
        """Initialize token manager.

        Args:
            token_path: Path to token file, defaults to ~/.kiwi/tokens.json
        """
        if token_path is None:
            token_path = Path.home() / ".kiwi" / "tokens.json"

        self.token_path = token_path
        self._tokens: Optional[AuthTokens] = None

    @contextmanager
    def file_lock(self):
        """Acquire an exclusive cross-process lock for refresh/write operations."""
        with _file_lock(_lock_path_for(self.token_path)):
            yield
    def save_tokens(self, tokens: AuthTokens) -> None:
        """Save tokens to secure storage (atomic write).

        Notes:
            Refresh flows should acquire `file_lock()` before calling this to avoid
            refresh-token rotation races across processes.

        Args:
            tokens: Authentication tokens to save
        """
        self._tokens = tokens
        data = tokens.model_dump(mode="json")
        _atomic_write_json(self.token_path, data)
        logger.info("Authentication tokens saved securely")

    def load_tokens(self) -> Optional[AuthTokens]:
        """Load tokens from storage.

        Returns:
            AuthTokens if found and valid, None otherwise
        """
        if not self.token_path.exists():
            logger.debug("No saved tokens found")
            return None

        try:
            with open(self.token_path, "r") as f:
                data = json.load(f)

            self._tokens = AuthTokens(**data)
            logger.info("Authentication tokens loaded")
            return self._tokens
        except Exception as e:
            logger.error(f"Failed to load tokens: {e}")
            return None

    def clear_tokens(self) -> None:
        """Clear stored tokens."""
        self._tokens = None

        if self.token_path.exists():
            try:
                self.token_path.unlink()
                logger.info("Authentication tokens cleared")
            except Exception as e:
                logger.error(f"Failed to clear tokens: {e}")

    @property
    def tokens(self) -> Optional[AuthTokens]:
        """Get current tokens.

        Returns:
            Current AuthTokens or None
        """
        if self._tokens is None:
            self._tokens = self.load_tokens()
        return self._tokens

    def is_authenticated(self) -> bool:
        """Check if user is authenticated with valid tokens.

        Returns:
            True if authenticated with non-expired tokens
        """
        tokens = self.tokens
        if not tokens:
            return False

        # Check if token is expired
        if tokens.is_expired():
            logger.warning("Access token is expired")
            return False

        return True

    def get_access_token(self) -> Optional[str]:
        """Get the current access token.

        Returns:
            Access token string or None
        """
        tokens = self.tokens
        if tokens and not tokens.is_expired():
            return tokens.access_token
        return None

    def get_refresh_token(self) -> Optional[str]:
        """Get the current refresh token.

        Returns:
            Refresh token string or None
        """
        tokens = self.tokens
        return tokens.refresh_token if tokens else None
