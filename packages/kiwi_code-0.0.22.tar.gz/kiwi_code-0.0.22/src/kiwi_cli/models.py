"""Pydantic models for Autobots TUI."""

from __future__ import annotations

import base64
import json
from datetime import datetime, timedelta
from enum import Enum
from typing import Optional, Any

from pydantic import BaseModel, Field


class ActionStatus(str, Enum):
    """Status of an action execution."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AutobotType(str, Enum):
    """Type of autobot."""
    CHAT = "chat"
    SEARCH = "search"
    AUTOMATION = "automation"
    ANALYSIS = "analysis"


class Autobot(BaseModel):
    """Represents an autobot instance."""
    id: str
    name: str
    type: AutobotType
    description: str
    enabled: bool = True
    created_at: datetime = Field(default_factory=datetime.now)
    last_run: Optional[datetime] = None
    run_count: int = 0


class Action(BaseModel):
    """Represents an action that can be executed."""
    id: str
    name: str
    description: str
    autobot_id: str
    parameters: dict[str, Any] = Field(default_factory=dict)


class ActionExecution(BaseModel):
    """Represents an action execution instance."""
    id: str
    action_id: str
    status: ActionStatus
    started_at: datetime = Field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    result: Optional[dict[str, Any]] = None
    error: Optional[str] = None


class AuthTokens(BaseModel):
    """Authentication tokens."""
    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expires_at: Optional[datetime] = None

    def is_expired(self) -> bool:
        """Check if access token is expired.

        Notes:
        - Prefer `expires_at` when present.
        - If `expires_at` is missing (common when the backend doesn't return expires_in),
          fall back to the JWT `exp` claim (if the access token is a JWT).
        """
        def _jwt_exp(token: str) -> datetime | None:
            try:
                parts = token.split(".")
                if len(parts) < 2:
                    return None
                payload_b64 = parts[1]
                # base64url decode with padding
                payload_b64 += "=" * (-len(payload_b64) % 4)
                payload = base64.urlsafe_b64decode(payload_b64.encode("utf-8"))
                data = json.loads(payload.decode("utf-8"))
                exp = data.get("exp")
                if not isinstance(exp, (int, float)):
                    return None
                return datetime.fromtimestamp(exp)
            except Exception:
                return None

        jwt_expires_at = _jwt_exp(self.access_token)
        effective_expires_at = self.expires_at or jwt_expires_at
        if self.expires_at and jwt_expires_at:
            # Be conservative if they disagree.
            effective_expires_at = min(self.expires_at, jwt_expires_at)

        if not effective_expires_at:
            # No expiry info; assume valid (server will decide).
            return False

        # Add 60 second buffer before expiry
        return datetime.now() >= (effective_expires_at - timedelta(seconds=60))


class LoginCredentials(BaseModel):
    """Login credentials."""
    username: str
    password: str


class AppConfig(BaseModel):
    """Application configuration."""
    backend_url: str = "https://api.meetkiwi.ai"
    api_key: Optional[str] = None
    log_level: str = "INFO"
    theme: str = "dark"
    refresh_interval: int = 5
