"""Standard Interval Arithmetic — Phase 1 inclusion function engine.

All operations are batch: inputs/outputs are (N,) or (N, K) arrays.
Intervals are represented as (lo, hi) pairs where lo <= hi element-wise.
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# Basic arithmetic
# ---------------------------------------------------------------------------


def ia_add(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    return a_lo + b_lo, a_hi + b_hi


def ia_sub(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    return a_lo - b_hi, a_hi - b_lo


def ia_mul(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    p1 = a_lo * b_lo
    p2 = a_lo * b_hi
    p3 = a_hi * b_lo
    p4 = a_hi * b_hi
    lo = np.minimum(np.minimum(p1, p2), np.minimum(p3, p4))
    hi = np.maximum(np.maximum(p1, p2), np.maximum(p3, p4))
    return lo, hi


def ia_div(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Interval division. b must not contain zero."""
    inv_lo = 1.0 / b_hi
    inv_hi = 1.0 / b_lo
    return ia_mul(a_lo, a_hi, inv_lo, inv_hi)


# ---------------------------------------------------------------------------
# Unary operations
# ---------------------------------------------------------------------------


def ia_neg(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return -hi, -lo


def ia_abs(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    abs_lo_val = np.abs(lo)
    abs_hi_val = np.abs(hi)
    contains = (lo <= 0) & (hi >= 0)
    r_lo = np.where(contains, 0.0, np.minimum(abs_lo_val, abs_hi_val))
    r_hi = np.maximum(abs_lo_val, abs_hi_val)
    return r_lo, r_hi


def ia_sqr(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """x^2 over [lo, hi]."""
    lo2 = lo * lo
    hi2 = hi * hi
    # If interval contains 0, minimum is 0
    contains_zero_mask = (lo <= 0) & (hi >= 0)
    r_lo = np.where(contains_zero_mask, 0.0, np.minimum(lo2, hi2))
    r_hi = np.maximum(lo2, hi2)
    return r_lo, r_hi


def ia_sqrt(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    lo_clamped = np.maximum(lo, 0.0)
    return np.sqrt(lo_clamped), np.sqrt(np.maximum(hi, 0.0))


def ia_pow(lo: np.ndarray, hi: np.ndarray, n: int) -> tuple[np.ndarray, np.ndarray]:
    """Integer power x^n over [lo, hi]."""
    if n == 0:
        ones = np.ones_like(lo)
        return ones, ones
    if n == 1:
        return lo.copy(), hi.copy()
    if n == 2:
        return ia_sqr(lo, hi)
    if n % 2 == 0:
        # Even power: result is non-negative
        lo_n = np.abs(lo) ** n
        hi_n = np.abs(hi) ** n
        contains = (lo <= 0) & (hi >= 0)
        r_lo = np.where(contains, 0.0, np.minimum(lo_n, hi_n))
        r_hi = np.maximum(lo_n, hi_n)
        return r_lo, r_hi
    else:
        # Odd power: monotone
        return lo**n, hi**n


# ---------------------------------------------------------------------------
# Transcendental functions
# ---------------------------------------------------------------------------


def ia_exp(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return np.exp(lo), np.exp(hi)


def ia_log(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return np.log(np.maximum(lo, 1e-300)), np.log(np.maximum(hi, 1e-300))


def ia_sin(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """sin over [lo, hi]. Handles full-period and critical-point cases."""
    sin_lo = np.sin(lo)
    sin_hi = np.sin(hi)

    width = hi - lo
    # If interval spans >= 2*pi, result is [-1, 1]
    full = width >= 2.0 * np.pi

    # Check if interval contains a maximum (pi/2 + 2*k*pi)
    # Shift so that maxima are at 0 + 2*k*pi
    shifted_max = lo - np.pi / 2.0
    k_lo_max = np.ceil(shifted_max / (2.0 * np.pi))
    next_max = k_lo_max * 2.0 * np.pi + np.pi / 2.0
    has_max = next_max <= hi

    # Check if interval contains a minimum (-pi/2 + 2*k*pi)
    shifted_min = lo + np.pi / 2.0
    k_lo_min = np.ceil(shifted_min / (2.0 * np.pi))
    next_min = k_lo_min * 2.0 * np.pi - np.pi / 2.0
    has_min = next_min <= hi

    r_lo = np.where(full, -1.0, np.where(has_min, -1.0, np.minimum(sin_lo, sin_hi)))
    r_hi = np.where(full, 1.0, np.where(has_max, 1.0, np.maximum(sin_lo, sin_hi)))
    return r_lo, r_hi


def ia_cos(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """cos over [lo, hi]. cos(x) = sin(x + pi/2)."""
    return ia_sin(lo + np.pi / 2.0, hi + np.pi / 2.0)


# ---------------------------------------------------------------------------
# Comparison / CSG helpers
# ---------------------------------------------------------------------------


def ia_min(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    return np.minimum(a_lo, b_lo), np.minimum(a_hi, b_hi)


def ia_max(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    return np.maximum(a_lo, b_lo), np.maximum(a_hi, b_hi)


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def contains_zero(lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
    """Check if each interval contains zero. Returns bool array."""
    return (lo <= 0.0) & (hi >= 0.0)


# ---------------------------------------------------------------------------
# Inclusion function implementations
# ---------------------------------------------------------------------------


class SamplingInclusion:
    """Inclusion function via vertex sampling + Lipschitz bound.

    Works for any ImplicitFunction, including mesh SDF.
    """

    def __init__(self, f, lipschitz: float = 1.0):
        self.f = f
        self.lipschitz = lipschitz

    def evaluate(self, lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Evaluate inclusion over N boxes.

        Args:
            lo: (N, 3) lower corners
            hi: (N, 3) upper corners

        Returns:
            (f_lo, f_hi): each (N,) — conservative range of f
        """
        N = lo.shape[0]

        # 8 vertices + center = 9 sample points per box
        mid = (lo + hi) * 0.5
        # Build 8 corners: all combinations of lo/hi per axis
        corners = np.empty((N * 8, 3), dtype=lo.dtype)
        idx = 0
        for i in range(2):
            for j in range(2):
                for k in range(2):
                    corners[idx * N : (idx + 1) * N, 0] = lo[:, 0] if i == 0 else hi[:, 0]
                    corners[idx * N : (idx + 1) * N, 1] = lo[:, 1] if j == 0 else hi[:, 1]
                    corners[idx * N : (idx + 1) * N, 2] = lo[:, 2] if k == 0 else hi[:, 2]
                    idx += 1

        all_points = np.concatenate([corners, mid], axis=0)  # (9N, 3)
        all_vals, _ = self.f(all_points)  # (9N,)

        # Reshape to (9, N) and take min/max over sample axis
        vals = all_vals.reshape(9, N)
        sample_min = vals.min(axis=0)  # (N,)
        sample_max = vals.max(axis=0)  # (N,)

        # Lipschitz margin: L * half-diagonal of box
        diag = np.sqrt(np.sum((hi - lo) ** 2, axis=1))  # (N,)
        margin = self.lipschitz * diag * 0.5

        f_lo = sample_min - margin
        f_hi = sample_max + margin
        return f_lo, f_hi


# ---------------------------------------------------------------------------
# Natural Interval Extension (NIA) — Phase 3
# ---------------------------------------------------------------------------


class NaturalIntervalInclusion:
    """Inclusion function via natural interval extension of analytic formulas.

    Instead of sampling + Lipschitz margin, directly evaluates the implicit
    function's formula using interval arithmetic operations. Tighter than
    SamplingInclusion for known analytic functions (no Lipschitz margin needed).

    Requires a "recipe" function that expresses f in terms of IA operations.
    """

    def __init__(self, recipe, params: dict | None = None):
        self.recipe = recipe
        self.params = params or {}

    def evaluate(self, lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        x_lo, y_lo, z_lo = lo[:, 0], lo[:, 1], lo[:, 2]
        x_hi, y_hi, z_hi = hi[:, 0], hi[:, 1], hi[:, 2]
        return self.recipe(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, self.params)


# --- NIA recipe functions ---------------------------------------------------


def sphere_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = (x-cx)² + (y-cy)² + (z-cz)² - r²"""
    cx, cy, cz = params.get("center", (0.0, 0.0, 0.0))
    r2 = params["radius"] ** 2
    # Shift to center
    dx_lo, dx_hi = x_lo - cx, x_hi - cx
    dy_lo, dy_hi = y_lo - cy, y_hi - cy
    dz_lo, dz_hi = z_lo - cz, z_hi - cz
    # Square each axis
    x2_lo, x2_hi = ia_sqr(dx_lo, dx_hi)
    y2_lo, y2_hi = ia_sqr(dy_lo, dy_hi)
    z2_lo, z2_hi = ia_sqr(dz_lo, dz_hi)
    # Sum
    s_lo = x2_lo + y2_lo + z2_lo
    s_hi = x2_hi + y2_hi + z2_hi
    return s_lo - r2, s_hi - r2


def torus_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = (sqrt(x²+y²) - R)² + z² - r²"""
    cx, cy, cz = params.get("center", (0.0, 0.0, 0.0))
    R = params["major_radius"]
    r2 = params["minor_radius"] ** 2
    # Shift to center
    dx_lo, dx_hi = x_lo - cx, x_hi - cx
    dy_lo, dy_hi = y_lo - cy, y_hi - cy
    dz_lo, dz_hi = z_lo - cz, z_hi - cz
    # x² + y²
    x2_lo, x2_hi = ia_sqr(dx_lo, dx_hi)
    y2_lo, y2_hi = ia_sqr(dy_lo, dy_hi)
    sum_xy_lo = x2_lo + y2_lo
    sum_xy_hi = x2_hi + y2_hi
    # sqrt(x² + y²)
    rho_lo, rho_hi = ia_sqrt(sum_xy_lo, sum_xy_hi)
    # rho - R
    rho_R_lo = rho_lo - R
    rho_R_hi = rho_hi - R
    # (rho - R)²
    rho_R2_lo, rho_R2_hi = ia_sqr(rho_R_lo, rho_R_hi)
    # z²
    z2_lo, z2_hi = ia_sqr(dz_lo, dz_hi)
    # (rho - R)² + z² - r²
    f_lo = rho_R2_lo + z2_lo - r2
    f_hi = rho_R2_hi + z2_hi - r2
    return f_lo, f_hi


def thin_shell_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = |x²+y²+z² - r²| - ε"""
    cx, cy, cz = params.get("center", (0.0, 0.0, 0.0))
    r2 = params["radius"] ** 2
    eps = params["epsilon"]
    dx_lo, dx_hi = x_lo - cx, x_hi - cx
    dy_lo, dy_hi = y_lo - cy, y_hi - cy
    dz_lo, dz_hi = z_lo - cz, z_hi - cz
    x2_lo, x2_hi = ia_sqr(dx_lo, dx_hi)
    y2_lo, y2_hi = ia_sqr(dy_lo, dy_hi)
    z2_lo, z2_hi = ia_sqr(dz_lo, dz_hi)
    g_lo = x2_lo + y2_lo + z2_lo - r2
    g_hi = x2_hi + y2_hi + z2_hi - r2
    abs_lo, abs_hi = ia_abs(g_lo, g_hi)
    return abs_lo - eps, abs_hi - eps


def high_freq_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = sin(ωx)·sin(ωy)·sin(ωz) - c"""
    w = params["omega"]
    c = params["offset"]
    # Scale by omega
    wx_lo, wx_hi = w * x_lo, w * x_hi
    wy_lo, wy_hi = w * y_lo, w * y_hi
    wz_lo, wz_hi = w * z_lo, w * z_hi
    # sin of each
    sx_lo, sx_hi = ia_sin(wx_lo, wx_hi)
    sy_lo, sy_hi = ia_sin(wy_lo, wy_hi)
    sz_lo, sz_hi = ia_sin(wz_lo, wz_hi)
    # sin(ωx) · sin(ωy)
    sxy_lo, sxy_hi = ia_mul(sx_lo, sx_hi, sy_lo, sy_hi)
    # · sin(ωz)
    f_lo, f_hi = ia_mul(sxy_lo, sxy_hi, sz_lo, sz_hi)
    return f_lo - c, f_hi - c


def whitney_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = x² - y²·z"""
    x2_lo, x2_hi = ia_sqr(x_lo, x_hi)
    y2_lo, y2_hi = ia_sqr(y_lo, y_hi)
    y2z_lo, y2z_hi = ia_mul(y2_lo, y2_hi, z_lo, z_hi)
    return ia_sub(x2_lo, x2_hi, y2z_lo, y2z_hi)


def cusp_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = x³ - y²"""
    x3_lo, x3_hi = ia_pow(x_lo, x_hi, 3)
    y2_lo, y2_hi = ia_sqr(y_lo, y_hi)
    return ia_sub(x3_lo, x3_hi, y2_lo, y2_hi)
