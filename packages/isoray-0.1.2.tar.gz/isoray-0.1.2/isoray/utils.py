"""Utilities — centered difference normals, etc."""

from __future__ import annotations

import numpy as np


def centered_difference_normals(f, pos: np.ndarray, h: float = 1e-5) -> np.ndarray:
    """Compute surface normals via centered difference.

    Evaluates 6N points in a single batch call to f.

    Args:
        f: ImplicitFunction — f(pos) -> (val, grad|None).
        pos: (N, 3) surface points.
        h: finite difference step size.

    Returns:
        normals: (N, 3) unit normals.
    """
    N = pos.shape[0]
    offsets = np.array(
        [[h, 0, 0], [-h, 0, 0], [0, h, 0], [0, -h, 0], [0, 0, h], [0, 0, -h]], dtype=pos.dtype
    )  # (6, 3)

    # Build all 6N query points
    all_points = (pos[None, :, :] + offsets[:, None, :]).reshape(6 * N, 3)

    all_vals, _ = f(all_points)

    v = all_vals.reshape(6, N)
    grad_x = (v[0] - v[1]) / (2.0 * h)
    grad_y = (v[2] - v[3]) / (2.0 * h)
    grad_z = (v[4] - v[5]) / (2.0 * h)

    normals = np.stack([grad_x, grad_y, grad_z], axis=1)  # (N, 3)
    norms = np.linalg.norm(normals, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)
    return normals / norms
