"""High-level render API — single-call implicit surface rendering."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from isoray.arithmetic.interval import SamplingInclusion
from isoray.renderer.camera import generate_rays, generate_rays_parallel
from isoray.renderer.image import save_depth_map, save_image
from isoray.renderer.shader import shade_lambertian
from isoray.tracer.bisection import TraceResult, bisect_trace
from isoray.tracer.ray import ray_aabb_intersect
from isoray.tracer.refine import newton_refine
from isoray.utils import centered_difference_normals


@dataclass
class RenderResult:
    """Result of a :func:`render` call.

    Attributes:
        image: (H, W, 3) uint8 RGB array.
        depth: (H, W) float64 depth values (``np.inf`` where no hit).
        hit_count: Number of rays that hit the surface.
        trace_result: Full :class:`TraceResult` for advanced inspection.
    """

    image: np.ndarray
    depth: np.ndarray
    hit_count: int
    trace_result: TraceResult


def _compute_camera(
    bounds: tuple[np.ndarray, np.ndarray],
    direction: np.ndarray,
    distance: float | None,
    target: np.ndarray | None,
    fov_deg: float,
    projection: str,
) -> tuple[np.ndarray, np.ndarray, float]:
    """Derive eye, target, and extent from bounds + direction.

    Returns:
        (eye, target, half_diag) — half_diag is the bounding-sphere radius,
        useful for computing orthographic extent.
    """
    lo, hi = bounds
    center = (lo + hi) * 0.5

    target_pt = center if target is None else target

    norm = np.linalg.norm(direction)
    if norm < 1e-12:
        raise ValueError("direction must be a non-zero vector")
    dir_unit = direction / norm

    half_diag = np.linalg.norm(hi - lo) * 0.5

    if distance is None:
        if projection == "perspective":
            fov_rad = np.deg2rad(fov_deg)
            distance = half_diag / np.tan(fov_rad * 0.45)
        else:
            # For parallel projection, place camera far enough that
            # the entire bounding box is in front of the image plane.
            distance = half_diag * 3.0
    eye = target_pt + dir_unit * distance

    return eye, target_pt, half_diag


def render(
    f: Callable[[np.ndarray], tuple[np.ndarray, np.ndarray | None]],
    bounds: tuple,
    *,
    # Camera
    direction: np.ndarray | tuple | list = (1, 1, 1),
    distance: float | None = None,
    target: np.ndarray | tuple | list | None = None,
    up: np.ndarray | tuple | list = (0, 1, 0),
    fov_deg: float = 60.0,
    projection: str = "perspective",
    # Resolution
    width: int = 512,
    height: int = 512,
    # Tracing
    lipschitz: float = 1.0,
    max_depth: int = 40,
    threshold: float = 1e-5,
    newton_iter: int = 3,
    # Output mode
    mode: str = "shaded",
    # Shading (mode="shaded" only)
    light_dir: np.ndarray | tuple | list | None = None,
    ambient: float = 0.1,
    surface_color: np.ndarray | tuple | list = (0.8, 0.5, 0.3),
    background: np.ndarray | tuple | list = (0.2, 0.2, 0.2),
    # File output
    save_to: str | Path | None = None,
) -> RenderResult:
    """Render an implicit surface with a single function call.

    Args:
        f: Implicit function. Takes ``(N, 3)`` positions, returns
            ``(val: (N,), grad: (N, 3) | None)``.
        bounds: Axis-aligned bounding box as ``(lo, hi)`` where each is
            array-like of shape ``(3,)``.
        direction: Direction from the object toward the camera.
            Does not need to be normalized. Default ``(1, 1, 1)``.
        distance: Camera distance from the target point.
            If ``None``, auto-calculated to frame the bounding box.
        target: Look-at point. If ``None``, defaults to the center of *bounds*.
        up: World up vector. Default ``(0, 1, 0)``.
        fov_deg: Vertical field of view in degrees (perspective only).
        projection: ``"perspective"`` or ``"parallel"`` (orthographic).
        width: Image width in pixels.
        height: Image height in pixels.
        lipschitz: Lipschitz constant for ``SamplingInclusion``.
        max_depth: Maximum bisection depth.
        threshold: Convergence width threshold for bisection.
        newton_iter: Newton refinement iterations (0 to disable).
        mode: ``"shaded"`` for Lambertian shading, ``"depth"`` for depth map.
        light_dir: Direction TO the light source. If ``None``, matches
            the camera direction.
        ambient: Ambient light intensity ``[0, 1]``.
        surface_color: ``(3,)`` RGB surface color in ``[0, 1]``.
        background: ``(3,)`` RGB background color in ``[0, 1]``.
        save_to: If provided, save the rendered image to this path.

    Returns:
        :class:`RenderResult` with image, depth map, hit count, and
        full trace data.

    Example::

        import numpy as np
        from isoray import render

        def my_sphere(pos):
            return np.sum(pos**2, axis=1) - 1.0, None

        result = render(my_sphere, bounds=([-1.5]*3, [1.5]*3),
                        save_to="sphere.png")
    """
    if projection not in ("perspective", "parallel"):
        raise ValueError(f"projection must be 'perspective' or 'parallel', got {projection!r}")
    if mode not in ("shaded", "depth"):
        raise ValueError(f"mode must be 'shaded' or 'depth', got {mode!r}")

    # --- Normalize inputs ---
    dir_arr = np.asarray(direction, dtype=np.float64)
    up_arr = np.asarray(up, dtype=np.float64)
    target_arr = np.asarray(target, dtype=np.float64) if target is not None else None
    lo = np.asarray(bounds[0], dtype=np.float64)
    hi = np.asarray(bounds[1], dtype=np.float64)

    # --- Camera setup ---
    eye, target_pt, half_diag = _compute_camera(
        (lo, hi), dir_arr, distance, target_arr, fov_deg, projection
    )

    # --- Ray generation ---
    if projection == "perspective":
        origins, directions = generate_rays(
            width, height, fov_deg=fov_deg, eye=eye, target=target_pt, up=up_arr
        )
    else:
        extent = half_diag * 1.1  # 10% margin
        origins, directions = generate_rays_parallel(
            width, height, extent=extent, eye=eye, target=target_pt, up=up_arr
        )

    # --- Ray-AABB intersection (with small margin) ---
    margin = (hi - lo) * 0.01
    aabb_lo = lo - margin
    aabb_hi = hi + margin
    t_min, t_max, hit_mask = ray_aabb_intersect(origins, directions, aabb_lo, aabb_hi)

    # --- Bisection trace ---
    inclusion = SamplingInclusion(f, lipschitz=lipschitz)
    result = bisect_trace(
        origins, directions, t_min, t_max, hit_mask, inclusion, f,
        max_depth=max_depth, threshold=threshold,
    )

    # --- Newton refinement ---
    if newton_iter > 0:
        result.t = newton_refine(
            result.t, origins, directions, result.hit, f,
            t_lo=result.t_lo, t_hi=result.t_hi, max_iter=newton_iter,
        )
        result.position = origins + result.t[:, None] * directions

    # --- Compute normals ---
    hit_positions = result.position[result.hit]
    if len(hit_positions) > 0:
        _, grad = f(hit_positions)
        if grad is not None:
            norms = np.linalg.norm(grad, axis=1, keepdims=True)
            result.normal[result.hit] = grad / np.maximum(norms, 1e-12)
        else:
            result.normal[result.hit] = centered_difference_normals(f, hit_positions)

    # --- Build image ---
    if mode == "shaded":
        if light_dir is None:
            light_dir_arr = eye - target_pt
        else:
            light_dir_arr = np.asarray(light_dir, dtype=np.float64)
        colors = shade_lambertian(
            result.normal, result.hit,
            light_dir=light_dir_arr, ambient=ambient,
            surface_color=surface_color, background=background,
        )
        image = (np.clip(colors, 0.0, 1.0) * 255.0).astype(np.uint8).reshape(height, width, 3)
    else:
        # Depth mode — grayscale depth map as RGB
        depth_flat = np.where(result.hit, result.t, np.nan)
        valid = depth_flat[np.isfinite(depth_flat)]
        if len(valid) == 0:
            gray = np.zeros(result.t.shape[0], dtype=np.uint8)
        else:
            d_min, d_max = valid.min(), valid.max()
            rng = d_max - d_min if d_max > d_min else 1.0
            normalized = np.where(result.hit, (depth_flat - d_min) / rng, 1.0)
            gray = (np.clip(1.0 - normalized, 0.0, 1.0) * 255.0).astype(np.uint8)
        image = np.stack([gray, gray, gray], axis=-1).reshape(height, width, 3)

    depth = np.where(result.hit, result.t, np.inf).reshape(height, width)

    # --- Save ---
    if save_to is not None:
        path = Path(save_to)
        if mode == "shaded":
            save_image(
                (image.reshape(-1, 3).astype(np.float64) / 255.0),
                path, width, height,
            )
        else:
            save_depth_map(result.t, result.hit, path, width, height)

    return RenderResult(
        image=image,
        depth=depth,
        hit_count=int(result.hit.sum()),
        trace_result=result,
    )
