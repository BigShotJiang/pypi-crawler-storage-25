# -*- coding: utf-8 -*-
#
# pyscreeps_arena - const.py
# Author: 我阅读理解一直可以的
# Template: V0.1
# Versions:
# .2025 01 01 - v0.1:
#   Created.
#
import re

VERSION = "0.6.5.x"
AUTHOR = "●ω＜🤍♪"
STEAM_ID = "1029562896"
GITHUB_NAME = "EagleBaby"
BILIBILI_NAME = "我阅读理解一直可以的"

ARENA_GREEN = "power_split"
ARENA_BLUE = "spawn_strike"
ARENA_RED = "escort_run"
ARENA_GRAY = "tutorial"

ARENA_NAMES = {
    "green": ARENA_GREEN,
    "blue" : ARENA_BLUE,
    "red"  : ARENA_RED,
    "gray" : ARENA_GRAY,
}
