"""Health check models."""

from csrd.models import BaseModel


class HealthResponse(BaseModel):
    """Health check response."""

    status: str
    service: str
