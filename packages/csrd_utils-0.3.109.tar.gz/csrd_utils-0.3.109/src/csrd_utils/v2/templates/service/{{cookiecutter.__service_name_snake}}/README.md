# {{ cookiecutter.service_name }}

{{ cookiecutter.service_description }}

## Run

```bash
uvicorn {{ cookiecutter.__service_name_snake }}:build_app --factory --port {{ cookiecutter.port }}
```

## Docker

```bash
docker compose up --build
```

## Test

```bash
pytest
```
