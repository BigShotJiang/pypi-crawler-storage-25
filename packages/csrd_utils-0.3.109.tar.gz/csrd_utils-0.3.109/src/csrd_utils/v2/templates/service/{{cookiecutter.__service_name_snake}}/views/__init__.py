from fastapi import FastAPI

from . import health_view

app = FastAPI(title="{{ cookiecutter.service_name }}")

app.include_router(health_view.router)

__all__ = ("app",)
