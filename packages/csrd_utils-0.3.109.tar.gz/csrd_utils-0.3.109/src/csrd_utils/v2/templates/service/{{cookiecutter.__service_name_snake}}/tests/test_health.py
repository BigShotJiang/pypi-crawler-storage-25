"""Health endpoint tests for {{ cookiecutter.service_name }}."""


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "service": "{{ cookiecutter.service_name }}"}
