from fastapi import APIRouter

from ..models.health import HealthResponse

router = APIRouter(tags=["Health"])



@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(status="ok", service="{{ cookiecutter.service_name }}")
