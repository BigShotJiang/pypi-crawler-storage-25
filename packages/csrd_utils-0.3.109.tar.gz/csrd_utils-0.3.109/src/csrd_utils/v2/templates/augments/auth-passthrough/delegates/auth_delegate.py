"""Auth service delegate for signup and login.

Proxies requests to the auth service's API endpoints.
This file is scaffolded once and never overwritten.
"""

from csrd.delegate import BaseDelegate

from ..models.auth_passthrough import TokenResponse, UserResponse


class AuthDelegate(BaseDelegate):
    """Delegate for the cluster auth service."""

    def __init__(self, base_url: str) -> None:
        super().__init__(base_url)

    async def signup(self, username: str, password: str) -> UserResponse:
        """Create a new user account via the auth service."""
        return await self.post(
            "/api/signup",
            json={"username": username, "password": password},
            response_model=UserResponse,
        )

    async def login(self, username: str, password: str) -> TokenResponse:
        """Authenticate and obtain a JWT token via the auth service."""
        return await self.post(
            "/api/token",
            json={"username": username, "password": password},
            response_model=TokenResponse,
        )


__all__ = ("AuthDelegate",)
