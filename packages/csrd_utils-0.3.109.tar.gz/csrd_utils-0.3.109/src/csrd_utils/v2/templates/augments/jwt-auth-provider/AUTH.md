# Authentication — Quick Reference
> Scaffolded by `jwt-auth-provider`. Safe to edit.
## Endpoints
| Endpoint | Method | Auth | Description |
|---|---|---|---|
| `/api/signup` | POST | Public | Create user (first user gets ADMIN) |
| `/api/token` | POST | Public | Issue JWT |
| `/api/verify` | POST | Public | Verify JWT, return claims |
| `/api/users/{id}` | GET | ADMIN | Get user info |
| `/api/users/{id}/roles` | GET | ADMIN | List user's authorities |
| `/api/users/{id}/roles` | POST | ADMIN | Assign role to user |
| `/.well-known/jwks.json` | GET | Public | JWKS public keys |
## First User Bootstrap
The first user to sign up gets the `ADMIN` role automatically.
Subsequent users start with no roles — assign via admin.
## Adding Authorities
1. `POST /api/signup` — create user
2. `POST /api/token` — get JWT with `authorities` claim
3. Admin: `POST /api/users/{id}/roles` with `{"role": "EDITOR"}`
4. User re-authenticates — JWT includes new role
**Naming**: `ADMIN`, `USER_READ`, `REPORTS_WRITE` (uppercase, flat)
## Key Rotation (JWKS)
Automatic RSA key rotation via `KeyRingManager`:
- New key every `JWT_KEY_ROTATION_INTERVAL` (default 24h)
- Old keys stay in JWKS for `JWT_KEY_RETENTION_PERIOD` (default 25h)
- No manual key management required
## Consumer Integration
```python
from csrd.auth import JWKSKeyProvider, create_jwt_bearer, require_authorities
auth_dep = create_jwt_bearer(
    key=JWKSKeyProvider(url=settings.auth_jwks_url),
    algorithms=[settings.jwt_algorithm],
    issuer=settings.jwt_issuer,
    audience=settings.jwt_audience,
)
```
## Custom Claims
```python
@dataclass
class TenantClaims(UserClaims):
    tenant_id: str = ""
auth_dep = create_jwt_bearer(claims_mapper=tenant_mapper, ...)
```
## Known Limitations (v1)
- No refresh token rotation
- No token revocation
- PBKDF2-SHA256 hashing (consider bcrypt for high-threat environments)
