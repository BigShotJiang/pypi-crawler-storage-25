"""Preset definitions for compose workspaces.

Each preset declares the infrastructure categories it requires (the user
picks the *specific* type within each category, e.g. postgres vs mariadb)
and a set of starter service templates.
"""

from ..models import INFRA_CATEGORIES, PresetDefinition, ServiceAugment, ServiceNode

# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

PRESET_REGISTRY: dict[str, PresetDefinition] = {
    "authenticated-cluster": PresetDefinition(
        name="authenticated-cluster",
        description="App + auth service backed by a database with JWT authentication",
        required_infra_categories=["database"],
        optional_infra_categories=["caching", "messaging"],
        workspace_augments=["jwt-auth-provider"],
        default_service_augments=["db-config"],
        optional_service_augments=[
            "delegate-config",
            "service-layer",
        ],
        services=[
            ServiceNode(
                name="app-service",
                role="app",
                port=8080,
                features=["database"],
                augments=[
                    ServiceAugment(name="jwt-auth-consumer"),
                    ServiceAugment(name="auth-passthrough"),
                    ServiceAugment(name="db-config"),
                    ServiceAugment(
                        name="crud-scaffold",
                        options={"entity_name": "item"},
                    ),
                ],
            ),
            ServiceNode(
                name="auth-service",
                role="auth",
                port=8081,
                features=["database"],
            ),
        ],
    ),
}


def list_presets() -> list[PresetDefinition]:
    """Return all registered presets in display order."""

    return list(PRESET_REGISTRY.values())


def members_for_category(category_label: str) -> list[str]:
    """Return sorted member infra types for a category label."""

    for label, members, _single in INFRA_CATEGORIES:
        if label == category_label:
            return sorted(members)
    return []
