"""Pure spec-to-content renderers for workspace artifacts.

Every function in this module is a **pure transform** from ``ComposeSpec``
(or no input) to a string.  No filesystem I/O, no spec mutations, no
side effects.  Orchestration lives in ``operations.py``.
"""

from typing import Any

from ..models import ComposeSpec, ServiceAugment, ServiceNode
from .augments import AUGMENT_REGISTRY
from .infra import (
    INFRA_REGISTRY,
    detect_configured_db,
    render_infra,
)
from .yaml_editor import dumps_yaml

WORKSPACE_MARKER_FILENAME = ".csrd-workspace"


# ---------------------------------------------------------------------------
# docker-compose.yml rendering
# ---------------------------------------------------------------------------


def _wire_feature(
    feature: str,
    *,
    svc: ServiceNode,
    infra_types: set[str],
    deps: dict[str, Any],
    env: dict[str, str],
    volumes: dict[str, None],
    spec: ComposeSpec,
) -> None:
    """Wire a single feature tag into deps/env/volumes via the infra registry.

    Special-cases sqlite (per-service volume + DB_PATH) because it has
    no shared container.  All other features are handled generically
    through the ``InfraDescriptor``.
    """

    if feature == "database":
        db = detect_configured_db({n.type for n in spec.infra})
        if db == "sqlite":
            vol_name = f"{svc.name}-data"
            volumes[vol_name] = None
            # No env var needed — settings.db_path provides the path.
            # volumes list is set on the svc_def by the caller
            return
        if db is not None:
            desc = INFRA_REGISTRY[db]
            deps.update(desc.depends_on)
            env.update(desc.service_env)
        return

    # Generic feature wiring (caching, messaging, …)
    for desc in INFRA_REGISTRY.values():
        if desc.feature == feature and desc.name in infra_types:
            deps.update(desc.depends_on)
            env.update(desc.service_env)


def _wire_augment(
    augment: ServiceAugment,
    *,
    svc: ServiceNode,
    spec: ComposeSpec,
    deps: dict[str, Any],
    env: dict[str, str],
    volumes: dict[str, None],
) -> None:
    """Wire a single service augment into deps/env/volumes via the augment registry.

    Static ``compose_env`` and ``compose_depends_on`` from the descriptor
    are applied unconditionally.  Dynamic values are resolved via the
    descriptor's resolver callbacks.  Wiring is idempotent — duplicate
    keys are silently deduplicated.
    """
    desc = AUGMENT_REGISTRY.get(augment.name)
    if desc is None:
        return

    # Static env/depends_on from descriptor
    env.update(desc.compose_env)
    for dep_name in desc.compose_depends_on:
        if dep_name != svc.name:
            deps[dep_name] = {"condition": "service_started"}

    # Dynamic env from resolver callback
    if desc.resolve_compose_env is not None:
        dynamic_env = desc.resolve_compose_env(augment, svc, spec)
        env.update(dynamic_env)
        # Auto-wire depends_on for services referenced in dynamic env
        for _key, value in dynamic_env.items():
            if value.startswith("http://"):
                host = value.split("://", 1)[1].split(":", 1)[0].split("/", 1)[0]
                if host != svc.name:
                    deps[host] = {"condition": "service_started"}

    # Dynamic depends_on from resolver (e.g. database container)
    if desc.resolve_compose_deps is not None:
        dynamic_deps = desc.resolve_compose_deps(augment, svc, spec)
        for dep_name, condition in dynamic_deps.items():
            if dep_name != svc.name:
                deps[dep_name] = (
                    condition if isinstance(condition, dict) else {"condition": condition}
                )

    # Dynamic volumes from resolver (e.g. sqlite per-service volume)
    if desc.resolve_compose_volumes is not None:
        dynamic_vols = desc.resolve_compose_volumes(augment, svc, spec)
        for vol_name in dynamic_vols:
            volumes[vol_name] = None


def _render_service(
    svc: ServiceNode,
    *,
    spec: ComposeSpec,
    base_port_offset: int,
) -> tuple[dict[str, Any], dict[str, None]]:
    """Build a compose service dict and its volumes for a single ServiceNode.

    Wiring is driven by the service's *features* list.  Each feature
    (``database``, ``caching``, ``messaging``) contributes ``depends_on``,
    ``environment``, and/or ``volumes`` entries sourced from the workspace
    infra configuration.

    Returns ``(service_dict, volumes_dict)``.
    """

    svc_def: dict[str, Any] = {
        "build": {
            "context": ".",
            "dockerfile": f"Dockerfile.{svc.name}",
        },
        "ports": [f"{svc.port + base_port_offset}:{svc.port + base_port_offset}"],
        "env_file": ".env",
    }

    deps: dict[str, Any] = {}
    env: dict[str, str] = {}
    volumes: dict[str, None] = {}
    infra_types = {n.type for n in spec.infra}

    for feature in svc.features:
        # Database wiring is now handled by augments (db-config, jwt-auth-provider)
        if feature == "database":
            continue
        _wire_feature(
            feature,
            svc=svc,
            infra_types=infra_types,
            deps=deps,
            env=env,
            volumes=volumes,
            spec=spec,
        )

    # Augment wiring (application-level concerns)
    env_owners: dict[str, str] = {}  # env_key → augment_name (collision detection)
    for augment in svc.augments:
        env_before = set(env.keys())
        _wire_augment(
            augment,
            svc=svc,
            spec=spec,
            deps=deps,
            env=env,
            volumes=volumes,
        )
        # Check for env key collisions between augments
        new_keys = set(env.keys()) - env_before
        for key in new_keys:
            if key in env_owners:
                raise ValueError(
                    f"Environment variable '{key}' on service '{svc.name}' "
                    f"is contributed by both '{env_owners[key]}' and "
                    f"'{augment.name}'. This is a conflict — augments must "
                    f"not write the same environment variable."
                )
            env_owners[key] = augment.name

    # Workspace augment wiring (e.g. jwt-auth-provider → auth-service)
    for ws_aug in spec.workspace.augments:
        desc = AUGMENT_REGISTRY.get(ws_aug.name)
        if desc is None or desc.applies_to_role != svc.role:
            continue
        synthetic = ServiceAugment(name=ws_aug.name, options=dict(ws_aug.options))
        env_before = set(env.keys())
        _wire_augment(
            synthetic,
            svc=svc,
            spec=spec,
            deps=deps,
            env=env,
            volumes=volumes,
        )
        new_keys = set(env.keys()) - env_before
        for key in new_keys:
            if key in env_owners:
                raise ValueError(
                    f"Environment variable '{key}' on service '{svc.name}' "
                    f"is contributed by both '{env_owners[key]}' and "
                    f"'{ws_aug.name}'. This is a conflict."
                )
            env_owners[key] = ws_aug.name

    # sqlite per-service volume
    if volumes:
        svc_def["volumes"] = [f"{vol}:/app/data" for vol in volumes]

    if deps:
        svc_def["depends_on"] = deps
    if env:
        svc_def["environment"] = env

    return svc_def, volumes


def _render_compose(spec: ComposeSpec) -> str:
    """Build the full ``docker-compose.yml`` content from the spec."""

    services: dict[str, Any] = {}
    volumes: dict[str, None] = {}

    # --- Infra containers first ---
    for infra_node in spec.infra:
        desc = INFRA_REGISTRY.get(infra_node.type)
        if desc is None or not desc.has_container:
            continue
        name, svc_def, vol_defs = render_infra(infra_node.type)
        services[name] = svc_def
        volumes.update(vol_defs)

    # --- Application services ---
    for svc in spec.services:
        svc_def, svc_volumes = _render_service(svc, spec=spec, base_port_offset=0)
        services[svc.name] = svc_def
        volumes.update(svc_volumes)

    payload: dict[str, Any] = {"services": services}
    if volumes:
        payload["volumes"] = volumes

    return dumps_yaml(payload)


# ---------------------------------------------------------------------------
# Env example rendering
# ---------------------------------------------------------------------------


def _render_env_example(spec: ComposeSpec) -> str:
    """Build ``.env.example`` with sensible defaults for configured infra."""

    lines = ["# Workspace defaults\n"]

    seen_features: set[str] = set()
    for infra_node in spec.infra:
        desc = INFRA_REGISTRY.get(infra_node.type)
        if desc is None or not desc.env_example_lines:
            continue
        # Avoid duplicate sections for the same feature (e.g. two DB types)
        if desc.feature in seen_features:
            continue
        seen_features.add(desc.feature)
        lines.extend(desc.env_example_lines)
        lines.append("")

    # Workspace augment env example lines (data-driven)
    for ws_aug in spec.workspace.augments:
        aug_desc = AUGMENT_REGISTRY.get(ws_aug.name)
        if aug_desc is None:
            continue

        # Dynamic resolver takes priority
        if aug_desc.resolve_env_example_lines is not None:
            example_lines = aug_desc.resolve_env_example_lines(ws_aug, spec)
            if example_lines:
                lines.extend(example_lines)
                lines.append("")
        elif aug_desc.env_example_lines:
            lines.extend(aug_desc.env_example_lines)
            lines.append("")

    return "\n".join(lines) + "\n"


def _render_readme(spec: ComposeSpec) -> str:
    """Build a starter ``README.md`` for the workspace."""

    return (
        f"# {spec.workspace.name}\n\n"
        "Generated by csrd compose.\n\n"
        "## Next steps\n\n"
        "```bash\n"
        "csrd compose validate\n"
        "csrd compose plan\n"
        "```\n"
    )


def _render_gitignore() -> str:
    """Build a default ``.gitignore`` for the workspace."""

    return (
        "# Runtime env files\n"
        ".env\n"
        "\n"
        "# Python cache\n"
        "__pycache__/\n"
        "*.py[cod]\n"
        "\n"
        "# Test and tooling cache\n"
        ".pytest_cache/\n"
        ".mypy_cache/\n"
        ".ruff_cache/\n"
    )


def _render_pyproject(spec: ComposeSpec) -> str:
    """Build a workspace-level ``pyproject.toml`` with pytest config."""

    service_src_paths = [f"src/{svc.name.replace('-', '_')}" for svc in spec.services]

    lines = [
        "[project]",
        f'name = "{spec.workspace.name}"',
        'version = "0.1.0"',
        'requires-python = ">=3.12"',
        "",
        "[tool.pytest.ini_options]",
        'testpaths = ["tests"]',
        'python_files = ["test_*.py"]',
        'python_classes = ["Test*"]',
        'python_functions = ["test_*"]',
    ]

    if service_src_paths:
        lines.append("pythonpath = [")
        for p in service_src_paths:
            lines.append(f'    "{p}",')
        lines.append("]")

    lines.append("")
    return "\n".join(lines) + "\n"


def _render_workspace_marker() -> str:
    """Build the ``.csrd-workspace`` marker file content."""

    return "workspace: csrd\n"


__all__ = [
    "WORKSPACE_MARKER_FILENAME",
    "_render_compose",
    "_render_env_example",
    "_render_gitignore",
    "_render_pyproject",
    "_render_readme",
    "_render_service",
    "_render_workspace_marker",
    "_wire_augment",
    "_wire_feature",
]
