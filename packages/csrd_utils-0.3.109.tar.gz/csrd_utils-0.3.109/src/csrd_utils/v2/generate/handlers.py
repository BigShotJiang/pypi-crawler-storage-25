"""Command handlers for generate actions."""

from contextlib import suppress
from pathlib import Path
from typing import cast

from ..compose import (
    AUGMENT_REGISTRY,
    INFRA_CATEGORIES,
    ROLE_REGISTRY,
    InfraNode,
    PresetDefinition,
    ServiceAugment,
    ServiceNode,
    available_infra,
    available_service_augments,
    available_workspace_augments,
    configured_infra,
    list_presets,
    load_spec,
    next_available_port,
    render_workspace,
    spec_file_path,
)
from ..compose import add_infra as compose_add_infra
from ..compose import add_service as compose_add_service
from ..compose import add_service_augment as compose_add_service_augment
from ..compose import add_workspace_augment as compose_add_workspace_augment
from ..compose import apply as compose_apply
from ..compose import remove_infra as compose_remove_infra
from ..compose import remove_service as compose_remove_service
from .helpers import (
    _WIZARD_INTERRUPTED,
    GoBack,
    WizardStep,
    normalize_service_name,
    prompt_multi_select,
    prompt_single_select,
    prompt_text,
    prompt_yes_no,
    resolve_workspace_name,
    run_wizard,
)

# ---------------------------------------------------------------------------
# Roles — derived from ROLE_REGISTRY
# ---------------------------------------------------------------------------

_VALID_ROLES = list(ROLE_REGISTRY.keys())

#: Roles that should exist at most once per workspace.
_SINGLETON_ROLES = {name for name, desc in ROLE_REGISTRY.items() if desc.singleton}


def _infer_role(name: str) -> str:
    """Suggest a role based on the service name."""
    if "auth" in name:
        return "auth"
    if "worker" in name or "job" in name:
        return "worker"
    return "app"


def _next_port(services: list[ServiceNode], base: int = 8080) -> int:
    """Return the next available port after existing services."""
    ports = [s.port for s in services]
    return (max(ports) + 1) if ports else base


def _resolve_implies(svc: ServiceNode) -> None:
    """Resolve augment ``implies`` transitively on a service.

    If an augment implies another (e.g. crud-scaffold → db-config),
    the implied augment is added if not already present.  Processes
    transitively until no new augments are added.
    """
    _resolve_implies_list(svc.augments)


def _resolve_implies_list(augments: list[ServiceAugment]) -> None:
    """Resolve augment ``implies`` transitively on a mutable augment list.

    Shared by ``_resolve_implies`` (ServiceNode) and the wizard step
    loop (local ``service_aug_list``).
    """
    existing = {a.name for a in augments}
    changed = True
    while changed:
        changed = False
        for aug in list(augments):
            desc = AUGMENT_REGISTRY.get(aug.name)
            if desc is None:
                continue
            for implied in desc.implies:
                if implied not in existing:
                    augments.append(ServiceAugment(name=implied))
                    existing.add(implied)
                    changed = True


def _augment_missing_infra(aug_name: str, infra_features: set[str]) -> set[str]:
    """Return infra categories missing for an augment, considering its implies chain.

    Walks the ``implies`` chain transitively and collects all
    ``requires_infra`` from the augment and its implied augments.
    Returns the set of infra categories that are required but not
    present in *infra_features*.
    """
    visited: set[str] = set()
    required: set[str] = set()
    stack = [aug_name]
    while stack:
        name = stack.pop()
        if name in visited:
            continue
        visited.add(name)
        desc = AUGMENT_REGISTRY.get(name)
        if desc is None:
            continue
        required.update(desc.requires_infra)
        stack.extend(desc.implies)
    return required - infra_features


def _available_features_for_infra(infra_choices: list[str]) -> list[str]:
    """Derive selectable features from the workspace's configured infra."""

    feats: list[str] = []
    for cat_label, cat_members, _single in INFRA_CATEGORIES:
        if any(c in cat_members for c in infra_choices):
            feats.append(cat_label)
    return feats


def cancel_ok() -> int:
    """Exit current flow as a successful cancel."""

    print("Cancelled.")
    return 0


# ---------------------------------------------------------------------------
# Shared workspace finalization
# ---------------------------------------------------------------------------


def _cleanup_workspace(state: dict[str, object]) -> None:
    """Remove a partially-created workspace directory.

    Called by ``run_wizard`` via ``on_cancel`` when the user cancels or
    an interrupt occurs after the workspace directory was created.
    Only removes directories that were freshly created during this flow
    (never touches pre-existing directories).
    """

    import shutil

    output_dir = state.get("_output_dir")
    if output_dir is None:
        return

    output_path = Path(str(output_dir))
    if output_path.exists() and not state.get("_pre_existing"):
        shutil.rmtree(output_path, ignore_errors=True)
        print(f"Cleaned up partial workspace: {output_path}")


def _finalize_workspace(
    name: str,
    *,
    infra_choices: list[str],
    services: list[ServiceNode],
    git_init: bool,
    workspace_augments: list[str] | None = None,
) -> int:
    """Create workspace, add infra/services, render, and print result.

    Shared by both manual and preset workspace creation flows.
    """

    output_dir = (Path.cwd().resolve() / name).resolve()
    compose_apply(output_dir, git_init=git_init)

    for infra_type in infra_choices:
        try:
            compose_add_infra(output_dir, InfraNode(type=infra_type))
            print(f'Added infra "{infra_type}".')
        except ValueError as exc:
            print(f"WARNING: {exc}")

    for svc in services:
        # Resolve augment implications (e.g. crud-scaffold → db-config)
        _resolve_implies(svc)

        # Auto-apply augments (e.g. structured-logging) if not already present
        existing_aug_names = {a.name for a in svc.augments}
        for aug_name, desc in AUGMENT_REGISTRY.items():
            if desc.auto_apply and aug_name not in existing_aug_names:
                svc.augments.append(ServiceAugment(name=aug_name))

        # Auto-derive features from augment prerequisites
        existing_features = set(svc.features)
        for aug in svc.augments:
            aug_desc = AUGMENT_REGISTRY.get(aug.name)
            if aug_desc is not None:
                for req in aug_desc.requires_infra:
                    if req not in existing_features:
                        svc.features.append(req)
                        existing_features.add(req)

        try:
            compose_add_service(output_dir, svc)
        except ValueError as exc:
            print(f"WARNING: {exc}")

    for aug_name in workspace_augments or []:
        try:
            compose_add_workspace_augment(output_dir, aug_name)
        except ValueError as exc:
            print(f"WARNING: {exc}")

    render_workspace(output_dir)
    print(f"Generated workspace at: {output_dir}")
    return 0


# ---------------------------------------------------------------------------
# Reusable wizard steps
# ---------------------------------------------------------------------------


def _step_workspace_name(state: dict[str, object]) -> None:
    """Wizard step: prompt for workspace name."""

    default = cast(str, state.get("default_name", "my-workspace"))
    workspace_raw = prompt_text("Workspace name", default=default)
    raw_name = workspace_raw or default

    name = resolve_workspace_name(raw_name)
    if raw_name.strip() and name != raw_name.strip():
        print(f"Normalized workspace name to: {name}")

    output_dir = (Path.cwd().resolve() / name).resolve()
    state["name"] = name
    state["_output_dir"] = output_dir
    state["_pre_existing"] = output_dir.exists()


def _step_template(state: dict[str, object]) -> None:
    """Wizard step: select a template (blank or preset) to pre-fill state."""

    presets = list_presets()
    options = ["blank", *(p.name for p in presets)]
    chosen = prompt_single_select("Start from a template:", options, auto_select=False)

    if chosen is None or chosen == "blank":
        # Blank workspace — no pre-fill
        print("  Template: blank")
        state.setdefault("infra_choices", [])
        state.setdefault("services", [])
        state.setdefault("workspace_augments", [])
        state["_preset"] = None
        return

    preset = next(p for p in presets if p.name == chosen)
    print(f"  Template: {preset.name}")
    print(f"  {preset.description}")
    state["_preset"] = preset

    # Pre-fill state from preset
    state["services"] = [s.model_copy() for s in preset.services]
    state["workspace_augments"] = list(preset.workspace_augments)

    # Resolve required infra inline (e.g. database for authenticated-cluster)
    infra_choices: list[str] = []
    for cat_label, cat_members, _single in INFRA_CATEGORIES:
        if cat_label in preset.required_infra_categories:
            sorted_members = sorted(cat_members)
            if len(sorted_members) == 1:
                print(f"  {cat_label}: {sorted_members[0]}")
                infra_choices.append(sorted_members[0])
            else:
                choice = prompt_single_select(f"Select {cat_label}:", sorted_members, inline=True)
                if choice is not None:
                    infra_choices.append(choice)

    # Optional infra categories — use preset order
    optional_cats: list[tuple[str, list[str]]] = []
    for opt_label in preset.optional_infra_categories:
        for label, cat_members, _single in INFRA_CATEGORIES:
            if label == opt_label:
                optional_cats.append((label, sorted(cat_members)))
                break
    if optional_cats:
        opt_labels = [label for label, _ in optional_cats]
        selected = prompt_multi_select("Optional infrastructure:", opt_labels, inline=True)
        for label in selected:
            opt_members = next(m for cat_l, m in optional_cats if cat_l == label)
            if len(opt_members) == 1:
                print(f"  {label}: {opt_members[0]}")
                infra_choices.append(opt_members[0])
            else:
                choice = prompt_single_select(f"Select {label}:", opt_members, inline=True)
                if choice is not None:
                    infra_choices.append(choice)

    state["infra_choices"] = infra_choices


def _ensure_infra(category: str, state: dict[str, object]) -> None:
    """Ensure an infra category is configured, prompting if needed.

    Called inline when a capability or role needs infra that hasn't been
    chosen yet.  For single-member categories (caching→redis,
    messaging→rabbitmq), auto-selects silently.  For multi-member
    categories (database), prompts once and stores the result.
    """
    infra_choices = cast(list[str], state.setdefault("infra_choices", []))
    for _label, members, _single in INFRA_CATEGORIES:
        if _label == category:
            if any(m in infra_choices for m in members):
                return  # already configured
            sorted_members = sorted(members)
            if len(sorted_members) == 1:
                print(f"  Auto-adding {category}: {sorted_members[0]}")
                infra_choices.append(sorted_members[0])
            else:
                choice = prompt_single_select(f"Select {category}:", sorted_members, inline=True)
                if choice is not None:
                    infra_choices.append(choice)
            return


# ---------------------------------------------------------------------------
# Auto-wiring helpers — generic dependency resolution
# ---------------------------------------------------------------------------


def _ensure_augment_deps(
    aug_name: str,
    *,
    service_aug_list: list[ServiceAugment],
    existing: list[ServiceNode],
    state: dict[str, object] | None,
    ws_aug_set: set[str],
    rebuild_available: object = None,
) -> None:
    """Generically ensure all dependencies for a newly-added augment.

    Walks the augment's ``requires_workspace_augment`` chain and the
    workspace augment's ``applies_to_role`` / ``requires_infra`` to
    auto-wire everything the augment needs.
    """
    desc = AUGMENT_REGISTRY.get(aug_name)
    if desc is None:
        return

    # 1. If this augment requires a workspace augment, ensure it exists
    ws_aug_name = desc.requires_workspace_augment
    if ws_aug_name and ws_aug_name not in ws_aug_set and state is not None:
        ws_augs = cast(list[str], state.setdefault("workspace_augments", []))
        if ws_aug_name not in ws_augs:
            ws_augs.append(ws_aug_name)
            ws_aug_set.add(ws_aug_name)
            print(f"  ✓ {ws_aug_name} (auto-wired for {aug_name})")

            # The workspace augment itself may need infra + a role-specific service
            ws_desc = AUGMENT_REGISTRY.get(ws_aug_name)
            if ws_desc is not None:
                for req_infra in ws_desc.requires_infra:
                    _ensure_infra(req_infra, state)

                # Auto-create a service if the workspace augment needs a role
                if ws_desc.applies_to_role:
                    services = cast(list[ServiceNode], state.get("services", []))
                    role_exists = any(s.role == ws_desc.applies_to_role for s in services) or any(
                        s.role == ws_desc.applies_to_role for s in existing
                    )
                    if not role_exists:
                        auto_port = _next_port(existing + services, base=8081)
                        auto_svc = ServiceNode(
                            name=f"{ws_desc.applies_to_role}-service",
                            role=ws_desc.applies_to_role,
                            port=auto_port,
                        )
                        services.append(auto_svc)
                        state["services"] = services
                        print(
                            f"  ✓ {ws_desc.applies_to_role}-service on port {auto_port}"
                            f" (auto-wired for {ws_aug_name})"
                        )

            if callable(rebuild_available):
                rebuild_available()

    # 2. Ensure infra required by this augment directly
    if state is not None:
        for req_infra in desc.requires_infra:
            _ensure_infra(req_infra, state)


def _collect_option_prompts(
    augment_desc: object,
    *,
    options: dict[str, str | list[str]],
    service_aug_list: list[ServiceAugment],
    role: str | None,
    existing: list[ServiceNode],
    state: dict[str, object] | None,
    ws_aug_set: set[str],
    rebuild_available: object = None,
) -> None:
    """Walk ``OptionPrompt`` descriptors and collect answers + auto-wire deps.

    Replaces the hardcoded ``if key == "crud-scaffold":`` branching.
    """
    from ..compose.augments import OptionPrompt

    prompts: list[OptionPrompt] = getattr(augment_desc, "option_prompts", [])

    def _walk(prompt_list: list[OptionPrompt]) -> None:
        for op in prompt_list:
            if op.exclude_role and op.exclude_role == role:
                continue

            affirmative = False
            if op.kind == "text":
                try:
                    answer = prompt_text(op.prompt, default=op.default)
                except KeyboardInterrupt:
                    raise
                options[op.key] = answer
                affirmative = bool(answer)
            elif op.kind == "yes_no":
                affirmative = prompt_yes_no(op.prompt)

            if affirmative and op.adds_augments:
                existing_names = {a.name for a in service_aug_list}
                for added in op.adds_augments:
                    if added not in existing_names:
                        service_aug_list.append(ServiceAugment(name=added))
                        existing_names.add(added)
                        _ensure_augment_deps(
                            added,
                            service_aug_list=service_aug_list,
                            existing=existing,
                            state=state,
                            ws_aug_set=ws_aug_set,
                            rebuild_available=rebuild_available,
                        )

            if affirmative and op.follow_ups:
                _walk(op.follow_ups)

    _walk(prompts)


def _step_services(state: dict[str, object]) -> None:
    """Wizard step: show current services, loop to add more."""

    services = cast(list[ServiceNode], state.get("services", []))
    preset = cast(PresetDefinition | None, state.get("_preset"))

    # Show existing services
    if services:
        print("  Current services:")
        for svc in services:
            aug_str = ""
            if svc.augments:
                aug_str = f" [{', '.join(a.name for a in svc.augments)}]"
            print(f"    {svc.name} ({svc.role}) :{svc.port}{aug_str}")

    # Loop to add services
    while True:
        try:
            raw = prompt_text("Add a service (name, or Enter to skip)", default="")
        except KeyboardInterrupt:
            raise

        if not raw.strip():
            break
        if raw.strip().lower() in {"back", "b"}:
            raise GoBack

        new_svc = _prompt_service(
            raw_name=raw,
            existing_services=services,
            preset=preset,
            state=state,
        )
        if new_svc is not None:
            services.append(new_svc)
            print(f'  Added service "{new_svc.name}" to spec.')

    state["services"] = services


def _step_summary(state: dict[str, object]) -> None:
    """Wizard step: show summary and ask for confirmation.

    In TTY mode, Escape raises ``GoBack`` directly from inside
    ``prompt_yes_no`` — that propagates normally and lets the wizard
    navigate back to the services step.

    A ``"no"`` answer (or EOF in piped / non-TTY mode) means the user
    wants to **cancel** the wizard, not loop back.  We raise
    ``KeyboardInterrupt`` so ``run_wizard`` invokes the cleanup callback
    and terminates cleanly.
    """

    name = cast(str, state.get("name", "workspace"))
    infra_choices = cast(list[str], state.get("infra_choices", []))
    ws_augments = cast(list[str], state.get("workspace_augments", []))
    services = cast(list[ServiceNode], state.get("services", []))

    _print_summary(name, infra_choices, ws_augments, services)

    if not prompt_yes_no("Generate?"):
        raise KeyboardInterrupt


def _step_git_init(state: dict[str, object]) -> None:
    """Wizard step: prompt for git init."""

    state["git_init"] = prompt_yes_no("Initialize git repository?")


# ---------------------------------------------------------------------------
# Service prompts (reused by workspace and add-service flows)
# ---------------------------------------------------------------------------


def _prompt_service(
    *,
    raw_name: str | None = None,
    existing_services: list[ServiceNode] | None = None,
    workspace_augments: list[str] | None = None,
    infra_choices: list[str] | None = None,
    preset: PresetDefinition | None = None,
    state: dict[str, object] | None = None,
) -> ServiceNode | None:
    """Interactively collect service details.  Returns ``None`` on cancel.

    Uses a step loop so Escape navigates back through:
    name → role → capabilities → port.

    When *state* is provided (wizard flow), infra and workspace augments
    are auto-derived from the selected role and capabilities — no upfront
    infra selection needed.  All augments are shown; selecting one that
    needs infra triggers an inline prompt.

    When *state* is ``None`` (add-service to existing workspace), falls
    back to *infra_choices* and *workspace_augments* for filtering.
    """

    existing = existing_services or []

    # Derive infra features from state or legacy params
    ws_aug_set: set[str]
    _infra: list[str]
    if state is not None:
        ws_aug_set = set(cast(list[str], state.get("workspace_augments", [])))
        _infra = cast(list[str], state.get("infra_choices", []))
    else:
        ws_aug_set = set(workspace_augments or [])
        _infra = list(infra_choices or [])

    def _recompute_infra_features() -> set[str]:
        src = cast(list[str], state.get("infra_choices", [])) if state else _infra
        feats: set[str] = set()
        for cat_label, cat_members, _single in INFRA_CATEGORIES:
            if any(c in src for c in cat_members):
                feats.add(cat_label)
        return feats

    infra_features = _recompute_infra_features()

    augment_descs = [(n, d) for n, d in sorted(AUGMENT_REGISTRY.items()) if d.scope == "service"]
    available_augs: list[tuple[str, str]] = []  # (name, description)
    disabled_aug_names: set[str] = set()  # augments shown but not selectable
    auto_apply_augs: list[str] = []  # silently added to every service

    def _build_available_augs() -> None:
        """Rebuild available augments list after infra/ws-augment changes."""
        nonlocal infra_features
        infra_features = _recompute_infra_features()
        available_augs.clear()
        disabled_aug_names.clear()
        auto_apply_augs.clear()
        for aug_name, desc in augment_descs:
            if (
                desc.requires_workspace_augment
                and desc.requires_workspace_augment not in ws_aug_set
            ):
                continue
            if desc.auto_apply:
                if aug_name not in auto_apply_augs:
                    auto_apply_augs.append(aug_name)
                continue
            if desc.hidden:
                continue
            if state is not None:
                # Wizard flow: show all augments — infra auto-wired on selection
                available_augs.append((aug_name, desc.description))
            else:
                # Existing workspace: disable augments with missing infra
                missing = _augment_missing_infra(aug_name, infra_features)
                if missing:
                    note = ", ".join(sorted(missing))
                    available_augs.append((aug_name, f"{desc.description} (requires {note})"))
                    disabled_aug_names.add(aug_name)
                else:
                    available_augs.append((aug_name, desc.description))

    _build_available_augs()

    # Preset augment scoping
    preset_defaults = set(preset.default_service_augments) if preset else set()
    preset_optionals = set(preset.optional_service_augments) if preset else set()

    # --- state for step loop ---
    name: str | None = None
    role: str | None = None
    features: list[str] = []
    service_aug_list: list[ServiceAugment] = []

    step = 0  # 0=name, 1=role, 2=capabilities, 3=port
    while step <= 3:
        try:
            if step == 0:
                # --- Name ---
                if raw_name is not None and name is None:
                    # First pass with caller-provided name — skip prompt
                    name = normalize_service_name(raw_name)
                    if name != raw_name.strip():
                        print(f"  Normalized to: {name}")
                    step = 1
                    continue

                try:
                    entered = prompt_text("Service name", default=name or "my-service")
                except GoBack:
                    return None

                name = normalize_service_name(entered)
                if name != entered.strip():
                    print(f"  Normalized to: {name}")
                step = 1

            elif step == 1:
                # --- Role (singleton roles grayed) ---
                claimed_roles = {s.role for s in existing}
                disabled_indices: set[int] = set()
                role_options: list[str] = []

                for i, r in enumerate(_VALID_ROLES):
                    if r in _SINGLETON_ROLES and r in claimed_roles:
                        role_options.append(f"{r} (already configured)")
                        disabled_indices.add(i)
                    else:
                        role_options.append(r)

                assert name is not None
                suggested = _infer_role(name)
                try:
                    chosen = prompt_single_select(
                        "Role:",
                        role_options,
                        auto_select=False,
                        disabled=disabled_indices,
                    )
                except GoBack:
                    step = 0
                    continue

                # Strip "(already configured)" suffix if present
                role = suggested if chosen is None else chosen.split(" (")[0]
                print(f"  Role: {role}")

                # Auto-wire workspace augments + infra from role descriptor
                role_desc = ROLE_REGISTRY.get(role)
                if role_desc is not None and state is not None:
                    ws_augs = cast(list[str], state.setdefault("workspace_augments", []))
                    for ws_aug_name in role_desc.implies_workspace_augments:
                        if ws_aug_name not in ws_augs:
                            ws_augs.append(ws_aug_name)
                            ws_aug_set.add(ws_aug_name)
                            print(f"  ✓ {ws_aug_name} (auto-wired for {role} role)")
                    for req_infra in role_desc.requires_infra:
                        _ensure_infra(req_infra, state)
                    if role_desc.implies_workspace_augments or role_desc.requires_infra:
                        _build_available_augs()

                step = 2

            elif step == 2:
                # --- Capabilities (augments only; features auto-derived) ---
                features = []
                service_aug_list = []

                # Auto-apply augments (e.g. structured-logging)
                for aug_name in auto_apply_augs:
                    service_aug_list.append(ServiceAugment(name=aug_name))

                capability_items: list[tuple[str, str, str]] = []  # (kind, key, label)
                # Add augments (preset-aware) — no feature items; features
                # are auto-derived from augments' requires_infra below.
                if preset and preset_defaults:
                    # Auto-apply defaults silently; show only optionals
                    for aug_name, _desc_str in available_augs:
                        if aug_name in preset_defaults:
                            service_aug_list.append(ServiceAugment(name=aug_name))
                            print(f"  ✓ {aug_name} (from template)")
                    for aug_name, desc_str in available_augs:
                        if aug_name in preset_optionals:
                            capability_items.append(
                                ("augment", aug_name, f"{aug_name} — {desc_str}")
                            )
                else:
                    for aug_name, desc_str in available_augs:
                        capability_items.append(("augment", aug_name, f"{aug_name} — {desc_str}"))

                if capability_items:
                    labels = [lbl for _, _, lbl in capability_items]
                    disabled_cap_indices = {
                        i
                        for i, (_, key, _) in enumerate(capability_items)
                        if key in disabled_aug_names
                    }
                    try:
                        selected_labels = prompt_multi_select(
                            "Capabilities:",
                            labels,
                            disabled=disabled_cap_indices,
                            auto_select_on_enter=True,
                        )
                    except GoBack:
                        step = 1
                        continue

                    # Echo selected capabilities after full-screen returns
                    if selected_labels:
                        selected_keys = [
                            capability_items[labels.index(lbl)][1] for lbl in selected_labels
                        ]
                        print(f"  Capabilities: {', '.join(selected_keys)}")

                    for lbl in selected_labels:
                        _kind, key, _ = capability_items[labels.index(lbl)]
                        aug_desc = AUGMENT_REGISTRY[key]
                        options: dict[str, str | list[str]] = {}

                        # Data-driven option prompts (replaces if/elif branching)
                        if aug_desc.option_prompts:
                            _collect_option_prompts(
                                aug_desc,
                                options=options,
                                service_aug_list=service_aug_list,
                                role=role,
                                existing=existing,
                                state=state,
                                ws_aug_set=ws_aug_set,
                                rebuild_available=_build_available_augs,
                            )

                        if aug_desc.needs_target_selection:
                            other_names = [s.name for s in existing]
                            if other_names:
                                try:
                                    targets = prompt_multi_select("Delegate targets:", other_names)
                                except (GoBack, KeyboardInterrupt):
                                    return None
                                options["targets"] = targets

                        service_aug_list.append(ServiceAugment(name=key, options=options))

                # Resolve augment implications (e.g. crud-scaffold → db-config)
                _resolve_implies_list(service_aug_list)

                # Auto-derive features from augment prerequisites
                # (e.g. db-config requires "database" → add "database" feature)
                for aug in service_aug_list:
                    desc = AUGMENT_REGISTRY.get(aug.name)
                    if desc is not None:
                        for req in desc.requires_infra:
                            if req not in features:
                                features.append(req)
                            # Auto-wire infra when in wizard flow
                            if state is not None:
                                _ensure_infra(req, state)

                if state is not None:
                    infra_features = _recompute_infra_features()

                step = 3

            elif step == 3:
                # --- Port ---
                default_port = _next_port(existing)

                try:
                    port_raw = prompt_text("Port", default=str(default_port))
                except GoBack:
                    step = 2
                    continue

                try:
                    port = int(port_raw)
                except ValueError:
                    print(f"  Invalid port '{port_raw}', defaulting to {default_port}.")
                    port = default_port

                assert name is not None
                assert role is not None
                return ServiceNode(
                    name=name,
                    role=role,
                    port=port,
                    features=features,
                    augments=service_aug_list,
                )

        except KeyboardInterrupt:
            return None

    return None


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------


def _print_summary(
    name: str,
    infra_choices: list[str],
    workspace_augments: list[str],
    services: list[ServiceNode],
) -> None:
    """Print a formatted summary of what will be generated."""

    # Build content lines first, then size the box to fit
    lines: list[str] = []
    lines.append(f" Workspace: {name}")
    if infra_choices:
        lines.append(f" Infra: {', '.join(infra_choices)}")
    if workspace_augments:
        lines.append(f" Augments: {', '.join(workspace_augments)}")
    lines.append("")
    if services:
        lines.append(" Services:")
        for svc in services:
            lines.append(f"   {svc.name} ({svc.role}) :{svc.port}")
            if svc.augments:
                aug_str = ", ".join(a.name for a in svc.augments)
                lines.append(f"     └ {aug_str}")
    else:
        lines.append(" Services: (none)")
    lines.append("")
    lines.append(" Files: docker-compose.yml, .env.example")

    width = max(len(line) for line in lines) + 4  # right padding
    width = max(width, 40)  # minimum

    print()
    print(f"┌{'─' * width}┐")
    for line in lines:
        print(f"│{line:<{width}}│")
    print(f"└{'─' * width}┘")
    print()


# ---------------------------------------------------------------------------
# Infrastructure prompts (category-based)
# ---------------------------------------------------------------------------


def _prompt_infra_categories(
    existing: set[str] | None = None,
) -> list[str]:
    """Walk through infra categories and collect specific selections.

    1. Multi-select which categories to add (database, messaging, caching).
    2. For each selected category, prompt for the specific type.
       - Single-option categories auto-select.
       - Multi-option categories (database) show a single-select.

    Escape at the category multi-select raises ``GoBack``.
    Escape at a sub-select loops back to the category multi-select.

    Returns a flat list of infra type strings.
    """

    existing = existing or set()

    # Build available categories (skip if all members are already present)
    available_categories: list[tuple[str, list[str], bool]] = []
    for label, members, single in INFRA_CATEGORIES:
        available_members = sorted(m for m in members if m not in existing)
        if available_members:
            available_categories.append((label, available_members, single))

    if not available_categories:
        return []

    while True:
        # Step 1: select categories (GoBack propagates to caller)
        cat_labels = [label for label, _, _ in available_categories]
        selected_labels = prompt_multi_select("Select infrastructure categories:", cat_labels)
        if not selected_labels:
            return []

        # Step 2: for each selected category, pick specific type
        result: list[str] = []
        restarted = False
        for label, avail_members, _single in available_categories:
            if label not in selected_labels:
                continue

            if len(avail_members) == 1:
                # Auto-select the only option
                print(f"  {label}: {avail_members[0]}")
                result.append(avail_members[0])
            else:
                try:
                    choice = prompt_single_select(f"Select {label}:", avail_members)
                except GoBack:
                    # Go back to category selection
                    restarted = True
                    break
                if choice is not None:
                    result.append(choice)

        if restarted:
            continue
        return result


# ---------------------------------------------------------------------------
# Workspace handler
# ---------------------------------------------------------------------------


def _apply_workspace(
    workspace_name: str,
    *,
    git_init: bool = False,
) -> int:
    """Create workspace, render baseline, and print result."""

    try:
        normalized = resolve_workspace_name(workspace_name)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    if workspace_name.strip() and normalized != workspace_name.strip():
        print(f"Normalized workspace name to: {normalized}")

    output_dir = (Path.cwd().resolve() / normalized).resolve()
    compose_apply(output_dir, git_init=git_init)
    print(f"Generated workspace at: {output_dir}")
    return 0


def create_workspace(default_name: str = "my-workspace") -> int:
    """Unified workspace flow using the step wizard.

    Steps: name → template → services → summary → git init.

    Infra and workspace augments are auto-derived from service roles and
    capabilities — no separate infra or augment selection steps.
    Presets pre-fill wizard state; blank starts empty.
    """

    steps: list[WizardStep] = [
        _step_workspace_name,
        _step_template,
        _step_services,
        _step_summary,
        _step_git_init,
    ]

    state: dict[str, object] = {"default_name": default_name}
    result = run_wizard(steps, on_cancel=_cleanup_workspace, initial_state=state)
    if result is None:
        return 0
    if result.get(_WIZARD_INTERRUPTED):
        return 1

    return _finalize_workspace(
        cast(str, result["name"]),
        infra_choices=cast(list[str], result.get("infra_choices", [])),
        services=cast(list[ServiceNode], result.get("services", [])),
        git_init=cast(bool, result.get("git_init", False)),
        workspace_augments=cast(list[str], result.get("workspace_augments", [])),
    )


def create_workspace_direct(
    workspace_name: str = "my-workspace",
    *,
    git_init: bool = False,
) -> int:
    """Direct (non-interactive) workspace creation."""

    return _apply_workspace(workspace_name, git_init=git_init)


def create_workspace_from_preset(default_name: str = "my-workspace") -> int:
    """Preset workspace flow — delegates to unified create_workspace."""

    return create_workspace(default_name)


# ---------------------------------------------------------------------------
# Add service handler
# ---------------------------------------------------------------------------


def add_service_interactive() -> int:
    """Prompt for service details and append to the current workspace spec."""

    workspace_dir = Path.cwd().resolve()

    # Load existing services for port awareness and augment prerequisites
    configured = configured_infra(workspace_dir)
    sp = spec_file_path(workspace_dir)
    existing_services: list[ServiceNode] = []
    ws_augments: list[str] = []
    if sp.is_file():
        spec = load_spec(sp)
        existing_services = list(spec.services)
        ws_augments = [a.name for a in spec.workspace.augments]

    try:
        svc = _prompt_service(
            existing_services=existing_services,
            workspace_augments=ws_augments,
            infra_choices=configured,
        )
    except GoBack:
        print("Cancelled.")
        return 0
    if svc is None:
        print("Cancelled.")
        return 0

    try:
        compose_add_service(workspace_dir, svc)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    # Add service augments
    for aug in svc.augments:
        try:
            compose_add_service_augment(workspace_dir, svc.name, aug.name, dict(aug.options))
        except ValueError as exc:
            print(f"WARNING: {exc}")

    render_workspace(workspace_dir)
    print(f'Added service "{svc.name}" to {workspace_dir / "csrd-compose.yaml"}')
    return 0


def add_service_direct(
    *,
    name: str,
    port: int = 8080,
    features: list[str] | None = None,
) -> int:
    """Non-interactive service addition to the current workspace spec."""

    service_name = normalize_service_name(name)
    svc = ServiceNode(name=service_name, port=port, features=features or [])

    # Auto-apply augments
    for aug_name, desc in AUGMENT_REGISTRY.items():
        if desc.auto_apply:
            svc.augments.append(ServiceAugment(name=aug_name))

    # Resolve implies and auto-derive features
    _resolve_implies(svc)

    workspace_dir = Path.cwd().resolve()
    try:
        compose_add_service(workspace_dir, svc)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Added service "{svc.name}" to {workspace_dir / "csrd-compose.yaml"}')
    return 0


# ---------------------------------------------------------------------------
# Add augment handler
# ---------------------------------------------------------------------------


def add_augment_interactive() -> int:
    """Prompt for augment scope (workspace/service), select augments, and add."""

    workspace_dir = Path.cwd().resolve()
    sp = spec_file_path(workspace_dir)
    if not sp.is_file():
        print("ERROR: No workspace found. Run from inside a workspace directory.")
        return 1

    spec = load_spec(sp)

    try:
        scope = prompt_single_select("Augment scope:", ["workspace", "service"])
    except GoBack:
        print("Cancelled.")
        return 0
    except KeyboardInterrupt:
        with suppress(KeyboardInterrupt):
            print("\nCancelled.")
        return 1

    if scope == "workspace":
        avail = available_workspace_augments(workspace_dir)
        if not avail:
            print("No workspace augments available (all added or prerequisites unmet).")
            return 0
        # Build labels with descriptions
        labels = []
        for aug_name in avail:
            desc = AUGMENT_REGISTRY.get(aug_name)
            lbl = f"{aug_name} — {desc.description}" if desc else aug_name
            labels.append(lbl)
        try:
            selected = prompt_multi_select("Workspace augments:", labels)
        except GoBack:
            print("No augments selected.")
            return 0
        except KeyboardInterrupt:
            with suppress(KeyboardInterrupt):
                print("\nCancelled.")
            return 1

        for lbl in selected:
            aug_name = avail[labels.index(lbl)]
            try:
                compose_add_workspace_augment(workspace_dir, aug_name)
                print(f'Added workspace augment "{aug_name}".')
            except ValueError as exc:
                print(f"WARNING: {exc}")

            # Auto-create service if needed
            desc = AUGMENT_REGISTRY.get(aug_name)
            if desc and desc.applies_to_role:
                spec = load_spec(sp)
                roles = {s.role for s in spec.services}
                if desc.applies_to_role not in roles:
                    port = next_available_port(spec)
                    svc_name = f"{desc.applies_to_role}-service"
                    features = _available_features_for_infra([i.type for i in spec.infra])
                    svc = ServiceNode(
                        name=svc_name,
                        role=desc.applies_to_role,
                        port=port,
                        features=features,
                    )
                    try:
                        compose_add_service(workspace_dir, svc)
                        print(
                            f"  {aug_name} requires {desc.applies_to_role} service "
                            f"— added {svc_name} on port {port}"
                        )
                    except ValueError as exc:
                        print(f"WARNING: {exc}")

    elif scope == "service":
        if not spec.services:
            print("No services in workspace. Add a service first.")
            return 0
        svc_names = [s.name for s in spec.services]
        try:
            svc_name = prompt_single_select("Which service?", svc_names)
        except GoBack:
            print("Cancelled.")
            return 0
        except KeyboardInterrupt:
            with suppress(KeyboardInterrupt):
                print("\nCancelled.")
            return 1

        if svc_name is None:
            print("Cancelled.")
            return 0

        avail = available_service_augments(workspace_dir, svc_name)
        if not avail:
            print(f"No augments available for {svc_name}.")
            return 0

        labels = []
        for aug_name in avail:
            desc = AUGMENT_REGISTRY.get(aug_name)
            lbl = f"{aug_name} — {desc.description}" if desc else aug_name
            labels.append(lbl)

        try:
            selected = prompt_multi_select("Service augments:", labels)
        except GoBack:
            print("No augments selected.")
            return 0
        except KeyboardInterrupt:
            with suppress(KeyboardInterrupt):
                print("\nCancelled.")
            return 1

        for lbl in selected:
            aug_name = avail[labels.index(lbl)]
            aug_desc = AUGMENT_REGISTRY.get(aug_name)
            options: dict[str, str | list[str]] = {}

            # Data-driven option prompts (text-only in add-augment flow)
            if aug_desc and aug_desc.option_prompts:
                for op in aug_desc.option_prompts:
                    if op.kind == "text":
                        try:
                            answer = prompt_text(op.prompt, default=op.default)
                        except KeyboardInterrupt:
                            with suppress(KeyboardInterrupt):
                                print("\nCancelled.")
                            return 1
                        options[op.key] = answer

            if aug_desc and aug_desc.needs_target_selection:
                other = [s.name for s in spec.services if s.name != svc_name]
                if other:
                    try:
                        targets = prompt_multi_select("Delegate targets:", other)
                    except (GoBack, KeyboardInterrupt):
                        with suppress(KeyboardInterrupt):
                            print("\nCancelled.")
                        return 1
                options["targets"] = targets

            try:
                compose_add_service_augment(workspace_dir, svc_name, aug_name, options or None)
                print(f'Added augment "{aug_name}" to {svc_name}.')
            except ValueError as exc:
                print(f"WARNING: {exc}")

    render_workspace(workspace_dir)
    return 0


def add_augment_direct(
    *,
    scope: str,
    augment_name: str,
    service_name: str | None = None,
    options: dict[str, str | list[str]] | None = None,
) -> int:
    """Non-interactive augment addition."""

    workspace_dir = Path.cwd().resolve()

    try:
        if scope == "workspace":
            compose_add_workspace_augment(workspace_dir, augment_name, options)
        elif scope == "service":
            if service_name is None:
                print("ERROR: --service-name required for service-scope augments.")
                return 1
            compose_add_service_augment(workspace_dir, service_name, augment_name, options)
        else:
            print(f"ERROR: Unknown scope '{scope}'. Use 'workspace' or 'service'.")
            return 1
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Added augment "{augment_name}".')
    return 0


# ---------------------------------------------------------------------------
# Remove service handler
# ---------------------------------------------------------------------------


def remove_service_interactive() -> int:
    """Prompt user to select a service to remove from the workspace."""

    workspace_dir = Path.cwd().resolve()
    sp = spec_file_path(workspace_dir)
    if not sp.is_file():
        print("ERROR: No workspace found.")
        return 1

    spec = load_spec(sp)

    if not spec.services:
        print("No services to remove.")
        return 0

    svc_names = [s.name for s in spec.services]

    try:
        chosen = prompt_single_select("Remove which service?", svc_names, auto_select=False)
    except GoBack:
        print("Cancelled.")
        return 0
    except KeyboardInterrupt:
        with suppress(KeyboardInterrupt):
            print("\nCancelled.")
        return 1

    if chosen is None:
        print("Cancelled.")
        return 0

    # Warn about dependents
    svc = next(s for s in spec.services if s.name == chosen)
    dependents: list[str] = []
    for other_svc in spec.services:
        if other_svc.name == chosen:
            continue
        for aug in other_svc.augments:
            desc = AUGMENT_REGISTRY.get(aug.name)
            if desc and desc.requires_service_in_spec == svc.role:
                dependents.append(other_svc.name)
                break
            # Check delegate targets
            targets = aug.options.get("targets", [])
            if isinstance(targets, str):
                targets = [targets]
            if chosen in targets:
                dependents.append(other_svc.name)
                break

    if dependents:
        print(f"  WARNING: {', '.join(dependents)} depend on {chosen}.")
        if not prompt_yes_no("Continue removing?", default=False):
            print("Cancelled.")
            return 0

    try:
        compose_remove_service(workspace_dir, chosen)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Removed service "{chosen}" from {workspace_dir / "csrd-compose.yaml"}')
    return 0


def remove_service_direct(*, service_name: str) -> int:
    """Non-interactive service removal."""

    workspace_dir = Path.cwd().resolve()

    try:
        compose_remove_service(workspace_dir, service_name)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Removed service "{service_name}" from {workspace_dir / "csrd-compose.yaml"}')
    return 0


# ---------------------------------------------------------------------------
# Add infra handler
# ---------------------------------------------------------------------------


def add_infra_interactive() -> int:
    """Category-based infra selection and addition to the current workspace spec."""

    workspace_dir = Path.cwd().resolve()
    avail = available_infra(workspace_dir)

    if not avail:
        print("All infrastructure types are already configured.")
        return 0

    # Determine what's already configured so categories hide filled slots
    sp = spec_file_path(workspace_dir)
    existing: set[str] = set()
    if sp.is_file():
        spec = load_spec(sp)
        existing = {i.type for i in spec.infra}

    try:
        choices = _prompt_infra_categories(existing)
    except GoBack:
        print("No infrastructure selected.")
        return 0
    except KeyboardInterrupt:
        with suppress(KeyboardInterrupt):
            print("\nCancelled.")
        return 1

    if not choices:
        print("No infrastructure selected.")
        return 0

    for infra_type in choices:
        infra = InfraNode(type=infra_type)
        try:
            compose_add_infra(workspace_dir, infra)
            print(f'Added infra "{infra_type}" to {workspace_dir / "csrd-compose.yaml"}')
        except ValueError as exc:
            print(f"WARNING: {exc}")

    render_workspace(workspace_dir)
    return 0


def add_infra_direct(*, infra_type: str) -> int:
    """Non-interactive infra addition to the current workspace spec."""

    infra = InfraNode(type=infra_type)
    workspace_dir = Path.cwd().resolve()

    try:
        compose_add_infra(workspace_dir, infra)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Added infra "{infra_type}" to {workspace_dir / "csrd-compose.yaml"}')
    return 0


# ---------------------------------------------------------------------------
# Remove infra handler
# ---------------------------------------------------------------------------


def remove_infra_interactive() -> int:
    """Prompt the user to select configured infra types to remove."""

    workspace_dir = Path.cwd().resolve()
    configured = configured_infra(workspace_dir)

    if not configured:
        print("No infrastructure is currently configured.")
        return 0

    try:
        if len(configured) == 1:
            infra_type = configured[0]
            if not prompt_yes_no(f'Remove "{infra_type}"?'):
                print("Cancelled.")
                return 0
            selected = [infra_type]
        else:
            selected = prompt_multi_select("Select infrastructure to remove:", configured)
    except GoBack:
        print("Cancelled.")
        return 0
    except KeyboardInterrupt:
        with suppress(KeyboardInterrupt):
            print("\nCancelled.")
        return 1

    if not selected:
        print("No infrastructure selected.")
        return 0

    for infra_type in selected:
        try:
            compose_remove_infra(workspace_dir, infra_type)
            print(f'Removed infra "{infra_type}" from {workspace_dir / "csrd-compose.yaml"}')
        except ValueError as exc:
            print(f"WARNING: {exc}")

    render_workspace(workspace_dir)
    return 0


def remove_infra_direct(*, infra_type: str) -> int:
    """Non-interactive infra removal from the current workspace spec."""

    workspace_dir = Path.cwd().resolve()

    try:
        compose_remove_infra(workspace_dir, infra_type)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Removed infra "{infra_type}" from {workspace_dir / "csrd-compose.yaml"}')
    return 0
