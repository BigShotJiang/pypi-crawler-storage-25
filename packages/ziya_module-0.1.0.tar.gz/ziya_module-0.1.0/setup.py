from setuptools import setup, find_packages
setup(
    name='ziya-module',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[],
    author='ZiyaAghazada',
    description='Simple python module for ZiyaAghazada',
)