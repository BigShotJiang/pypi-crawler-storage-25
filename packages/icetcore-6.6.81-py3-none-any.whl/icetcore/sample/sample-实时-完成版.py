# 导入pandas库，用于数据处理和分析
import pandas as pd
# 从icetcore库导入相关模块
from icetcore import TCoreAPI, QuoteEvent, TradeEvent, BarType, OrderStruct, OrderSide, OrderType, TimeInForce, \
    PositionEffect
# 导入os模块，用于操作系统相关功能（如文件路径操作）
import os
# 导入time模块，用于时间相关操作（如延时）
import time
# 导入glob模块，用于文件路径匹配
import glob
import warnings
# 从py_vollib.black_scholes_merton.implied_volatility导入隐含波动率计算函数
from py_vollib.black_scholes_merton.implied_volatility import implied_volatility
# 导入matplotlib.pyplot模块，用于绘图
import matplotlib.pyplot as plt

# ===============================================参数配置===============================================================
TARGET_UNDERLYING = '510050'  # 需要从查找结果提取的标的代码参数
TARGET_EXPIRY = '202511'     # 需要从查找结果提取的标的到期月份参数
starttime = "2025110501"    # 获取数据的开始时间 实时不需要结束时间
symbol_F = f"TC.F.U_SSE.{TARGET_UNDERLYING}.{TARGET_EXPIRY}" # 生成合成期货代码 用于查找Underlying Value的Close
path = "C:/AlgoMaster2/APPs64(DEV)"  # 指定应用程序路径,使用时需要替换为客户端实际安装的路径
symbol_date = "20251105"     # 查找合约列表的日期

# 全局状态标记
subscription_completed = False  # 标记1：订阅完成
data_received = False  # 标记2：数据接收完成
data_processed = False  # 标记3：数据处理完成
strategy_executed = False  # 标记4：策略执行完成
order_executed = False  # 标记5：下单执行完成
# 全局变量
symbol_list_call = []  # 看涨期权合约代码
symbol_list_put = []  # 看跌期权合约代码
Open_position = None  # 跟踪开仓位置

# 数据缓存 - 存储每个合约的最新实时数据
latest_real_time_data = {}

# ===============================================确保目录存在，防止不能保存数据===============================================================
def ensure_directories():
    """确保必要的目录存在，如果不存在则创建"""
    # 需要创建的目录列表
    directories = ['processed_data', 'smile_plots']
    # 遍历目录列表
    for dir_name in directories:
        # 检查目录是否存在
        if not os.path.exists(dir_name):
            # 如果不存在则创建目录
            os.makedirs(dir_name)
            # 打印创建目录的信息
            print(f"创建目录: {dir_name}")

# ===============================================提取行权价函数===============================================================
def extract_strike_price(symbol):
    #将合约代码按.分割
    parts = symbol.split('.')
    # 检查是否有足够的部分（至少7部分）
    if len(parts) >= 7:
        # 如果部分数大于7，说明行权价包含小数点
        if len(parts) > 7:
            # 处理带小数点的行权价（如3.1）
            return float(f"{parts[6]}.{parts[7]}")
        else:
            return float(parts[6])
    return None

# ===============================================第一部分：实时数据接收和保存===============================================================
def process_real_time_data(symbol, df, isreal):
    # 声明使用全局变量
    global data_received, latest_real_time_data
    # 只处理实时数据，并且要等订阅完成后
    if not isreal or not subscription_completed:
        return
    print(f"接收到实时数据: {symbol}, 数据行数: {len(df)}, isreal: {isreal}")
    # 检查数据框是否为空
    if df.empty:
        return
    try:
        # 只保存最后一条实时数据
        latest_data = df.tail(1).copy()
        # 更新缓存中的最新数据
        latest_real_time_data[symbol] = latest_data

        print(f"已缓存 {symbol} 的最新实时数据")

        # 检查是否所有合约都有最新的实时数据了
        total_contracts = 1 + len(symbol_list_call) + len(symbol_list_put)  # F + calls + puts
        received_contracts = len(latest_real_time_data)

        print(f"实时数据接收进度: {received_contracts}/{total_contracts}")

        # 当所有合约都有最新的实时数据时，一次性保存到文件
        if received_contracts >= total_contracts:
            print("所有合约都收到了最新实时数据，开始保存到文件...")
            save_all_real_time_data()
            data_received = True
            print("标记2: 所有合约的实时数据接收并保存完成")

    except Exception as e:
        print(f"处理实时数据 {symbol} 时发生错误: {e}")


def save_all_real_time_data():
    # 声明使用全局变量
    global latest_real_time_data

    # 确保目录存在
    ensure_directories()

    # 遍历缓存中的所有合约数据
    try:
        for symbol, latest_data in latest_real_time_data.items():
            if latest_data.empty:
                continue

            # 重试 确保目录存在 不然存不了文件
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    # 每次重试前确保目录存在
                    if not os.path.exists('processed_data'):
                        os.makedirs('processed_data')
                        print("重新创建processed_data目录")

                    # 处理数据格式
                    processed_data = latest_data.copy()

                    # 判断当前合约是否为期货合约，去除时区，然后拆分datetime，然后对数据重命名列
                    if symbol == symbol_F:
                        processed_data['DateTime'] = pd.to_datetime(processed_data['DateTime']).dt.tz_localize(None)
                        processed_data['Date'] = processed_data['DateTime'].dt.date.astype(str)
                        processed_data['Time'] = processed_data['DateTime'].dt.time.astype(str)
                        processed_data['Underlying Value'] = processed_data['Close']
                        df_final = processed_data[['Symbol', 'Date', 'Time', 'Underlying Value']]
                    else:
                    # 不是期货的就都是期权数据，同样处理
                        processed_data['DateTime'] = pd.to_datetime(processed_data['DateTime']).dt.tz_localize(None)
                        processed_data['Date'] = processed_data['DateTime'].dt.date.astype(str)
                        processed_data['Time'] = processed_data['DateTime'].dt.time.astype(str)
                        option_type = 'C' if symbol in symbol_list_call else 'P'
                        processed_data['Option Type'] = option_type
                        strike_price = extract_strike_price(symbol)
                        processed_data['Strike Price'] = strike_price
                        if 'Close' in processed_data.columns:
                            processed_data['LTP'] = processed_data['Close']

                        # 只保留自己需要的列名
                        required_columns = ['Symbol', 'Date', 'Time', 'Option Type', 'Strike Price', 'Open', 'High',
                                            'Low',
                                            'Close', 'LTP']
                        processed_data['Symbol'] = symbol
                        available_columns = [col for col in required_columns if col in processed_data.columns]
                        df_final = processed_data[available_columns]

                    # 保存到文件（追加模式）
                    filename = f"processed_data/{symbol.replace('.', '_')}.xlsx"
                    # 检查文件是否已存在，存在就读现在数据，再去重合并追加数据
                    if os.path.exists(filename):
                        try:
                            existing_df = pd.read_excel(filename, engine='openpyxl')
                            combined_df = pd.concat([existing_df, df_final], ignore_index=True)
                            combined_df = combined_df.drop_duplicates(subset=['Date', 'Time'], keep='last')
                            combined_df.to_excel(filename, index=False, engine='openpyxl')
                            print(f"实时数据已追加: {symbol}")
                        # 如果追加失败，创建新文件
                        except Exception as e:
                            print(f"追加失败，创建新文件: {e}")
                            df_final.to_excel(filename, index=False, engine='openpyxl')
                    else:
                        df_final.to_excel(filename, index=False, engine='openpyxl')
                        print(f"新文件已创建: {symbol}")

                    break  # 成功则跳出重试循环
                # 处理保存异常
                except Exception as e:
                    if attempt == max_retries - 1:
                        print(f"保存 {symbol} 数据失败 after {max_retries} 次尝试: {e}")
                    else:
                        print(f"保存 {symbol} 数据失败，第 {attempt + 1} 次重试: {e}")
                        time.sleep(0.5)

        # 清空缓存，准备接收下一批实时数据
        latest_real_time_data = {}
        print("所有实时数据保存完成，缓存已清空")

    except Exception as e:
        print(f"保存实时数据时发生错误: {e}")


# ===============================================第二部分：数据处理和合并===============================================================
def merge_contract_data():
    # 声明使用全局变量
    global data_processed

    print("开始第二部分：数据处理和合并...")

    # 确保数据接收完成
    if not data_received:
        print("数据接收未完成，跳过合并")
        return

    try:
        # 等待文件写入完成
        time.sleep(2)
        # 使用glob查找所有处理过的数据文件
        processed_files = glob.glob('processed_data/*.xlsx')
        print(f"找到 {len(processed_files)} 个数据文件")
        # 检查是否找到文件
        if len(processed_files) == 0:
            print("没有找到数据文件，跳过合并")
            return
        # 储存不同类型数据
        call_data = []
        put_data = []
        future_data = []
        # 遍历所有找到的文件
        for file_path in processed_files:
            try:
                df = pd.read_excel(file_path, engine='openpyxl')
                if df.empty:
                    continue
                # 获取文件名，据文件名判断数据类型并添加到相应列表
                filename = os.path.basename(file_path)
                if symbol_F.replace('.', '_') in filename:
                    future_data.append(df)
                    print(f"读取标的期货数据: {filename}, 行数: {len(df)}")
                elif "_C_" in filename:
                    call_data.append(df)
                    print(f"读取看涨期权数据: {filename}, 行数: {len(df)}")
                elif "_P_" in filename:
                    put_data.append(df)
                    print(f"读取看跌期权数据: {filename}, 行数: {len(df)}")

            except Exception as e:
                print(f"读取文件失败 {file_path}: {e}")

        # 合并期货数据
        future_combined = pd.DataFrame()
        if future_data:
            future_combined = pd.concat(future_data, ignore_index=True)
            future_combined = future_combined.sort_values(['Date', 'Time'])
            future_combined.to_excel('future_data_combined.xlsx', index=False, engine='openpyxl')
            print(f"标的期货数据合并完成，共 {len(future_combined)} 条记录")

        # 合并Call合约数据
        if call_data:
            call_combined = pd.concat(call_data, ignore_index=True)

            if 'Signal' not in call_combined.columns:
                call_combined['Signal'] = 0

            if not future_combined.empty:
                future_combined['merge_key'] = future_combined['Date'] + ' ' + future_combined['Time']
                call_combined['merge_key'] = call_combined['Date'] + ' ' + call_combined['Time']
                # 合并期权数据和期货数据
                call_combined = call_combined.merge(
                    future_combined[['merge_key', 'Underlying Value']],
                    on='merge_key',
                    how='left'
                )
                # 使用前向填充处理缺失的标的价值
                call_combined['Underlying Value'] = call_combined['Underlying Value'].fillna(method='ffill')
                call_combined = call_combined.drop('merge_key', axis=1)

            call_combined = call_combined.sort_values(['Date', 'Time'])
            call_combined.to_excel('call_contracts_combined.xlsx', index=False, engine='openpyxl')
            print(f"Call合约合并完成，共 {len(call_combined)} 条记录")

        # 合并Put合约数据（与Call合约类似）
        if put_data:
            put_combined = pd.concat(put_data, ignore_index=True)

            if not future_combined.empty:
                future_combined['merge_key'] = future_combined['Date'] + ' ' + future_combined['Time']
                put_combined['merge_key'] = put_combined['Date'] + ' ' + put_combined['Time']

                put_combined = put_combined.merge(
                    future_combined[['merge_key', 'Underlying Value']],
                    on='merge_key',
                    how='left'
                )

                put_combined['Underlying Value'] = put_combined['Underlying Value'].fillna(method='ffill')
                put_combined = put_combined.drop('merge_key', axis=1)

            put_combined = put_combined.sort_values(['Date', 'Time'])
            put_combined.to_excel('put_contracts_combined.xlsx', index=False, engine='openpyxl')
            print(f"Put合约合并完成，共 {len(put_combined)} 条记录")

        data_processed = True
        print("标记3: 数据处理和合并完成")

    except Exception as e:
        print(f"数据处理和合并时发生错误: {e}")


# ===============================================第三部分：IV计算和策略执行===============================================================
def calculate_implied_volatility():
    try:
        data_file = 'call_contracts_combined.xlsx'
        if not os.path.exists(data_file):
            print(f"数据文件 {data_file} 不存在，跳过IV计算")
            return False

        warnings.filterwarnings('ignore')
        sample_data = pd.read_excel(data_file, engine='openpyxl')
        sample_data = sample_data.sort_values(['Date', 'Time'])

        # 初始化IV列
        sample_data['IV'] = 0

        def calculate_iv(row):
            try:
                S = float(row['Underlying Value'])  # 标的资产价格
                K = float(row['Strike Price'])     # 行权价
                t = float(row['Time to Expiry']) / 243  # 年化时间（假设243个交易日）
                r = 0.0 # 无风险利率
                q = 0.0  # 股息率
                option_price = float(row['LTP'])  # 期权价格
                option_type = row['Option Type'].lower()  # 期权类型转为小写
                # 检查数据有效性
                if (pd.isna(S) or pd.isna(K) or pd.isna(option_price) or
                        t <= 0 or option_price <= 0 or S <= 0 or K <= 0):
                    return 0.0
                # 使用py_vollib库计算隐含波动率
                iv = implied_volatility(option_price, S, K, t, r, q, option_type)
                return iv * 100
            # 对计算失败的填入0.0001
            except Exception as e:
                return 0.0001

        # 使用apply函数直接对每一行计算IV然后保存
        sample_data['IV'] = sample_data.apply(calculate_iv, axis=1)
        sample_data.to_excel('call_contracts_with_iv.xlsx', index=False, engine='openpyxl')
        print(f"隐含波动率计算完成！")
        return True

    except Exception as e:
        print(f"计算隐含波动率时出错: {e}")
        return False

# 定义绘制波动率微笑曲线的函数
def Plot_smile(date_val, time_val, sample_data):
    try:
        # 筛选指定日期和时间的数据
        option_data = sample_data[
            (sample_data['Date'] == date_val) &
            (sample_data['Time'] == time_val)
            ]

        if option_data.empty:
            return

        # 按行权价排序以确保曲线正确
        option_data = option_data.sort_values('Strike Price')

        plt.plot(option_data['Strike Price'], option_data['IV'])
        plt.legend([f"{date_val} {time_val}"])
        plt.ylabel('Implied Volatility')
        plt.xlabel('Strike Price')

        # 确保目录存在
        if not os.path.exists('smile_plots'):
            os.makedirs('smile_plots')

        # 保存到文件夹
        filename = f"smile_plots/smile_{date_val}_{time_val}.png".replace(':', '').replace(' ', '_')
        plt.savefig(filename)
        plt.close()
        print(f"波动率微笑曲线已保存: {filename}")

    except Exception as e:
        print(f"绘制波动率微笑曲线时出错: {e}")


def execute_volatility_smile_strategy():
    global strategy_executed, Open_position

    try:
        data_file = 'call_contracts_with_iv.xlsx'
        if not os.path.exists(data_file):
            print(f"数据文件 {data_file} 不存在，跳过策略执行")
            return False

        sample_data = pd.read_excel(data_file, engine='openpyxl')
        if sample_data.empty:
            print("数据文件为空，跳过策略执行")
            return False

        # 初始化信号、损益和市值标记列
        if 'Signal' not in sample_data.columns:
            sample_data['Signal'] = 0  # 交易信号：0=无持仓，1=有持仓
        if 'PNL' not in sample_data.columns:
            sample_data['PNL'] = 0  # 平仓损益
        if 'MTM' not in sample_data.columns:
            sample_data['MTM'] = 0  # 持仓损益
        if 'Cumulative PNL' not in sample_data.columns:
            sample_data['Cumulative PNL'] = 0  # 累计损益

        # 重置全局持仓状态
        Open_position = None

        # 获取数据总行数
        total_rows = len(sample_data)

        print(f"开始执行波动率微笑交易策略，共{total_rows}行数据...")

        # 使用for循环遍历数据框的所有行，识别波动率微笑曲线中的异常凸起
        # 逐行扫描同一时间点、相邻行权价的IV（隐含波动率）差异；
        # 如果检测到"中间行权价的IV明显高于左右两边"（视为微笑曲线出现凸起bump），就建立蝶式套利组合：
        # 卖出中间2口、买入左右各1口，等到凸起消失时平仓；
        for row in range(1, total_rows - 1):  # 从第1行到倒数第2行遍历
            # 检查当前没有持仓（Signal为0）
            if sample_data.iloc[row]['Signal'] == 0:
                # 判断期权状态：价内或价外
                ITM_check = sample_data.iloc[row]['Underlying Value'] > sample_data.iloc[row]['Strike Price']
                OTM_check = sample_data.iloc[row]['Underlying Value'] < sample_data.iloc[row]['Strike Price']

                # 检查前后行是否为同一时间点
                same_time_check_ahead = (row < total_rows - 1 and
                                         sample_data.iloc[row]['Date'] == sample_data.iloc[row + 1]['Date'] and
                                         sample_data.iloc[row]['Time'] == sample_data.iloc[row + 1]['Time'])
                same_time_check_behind = (sample_data.iloc[row]['Date'] == sample_data.iloc[row - 1]['Date'] and
                                          sample_data.iloc[row]['Time'] == sample_data.iloc[row - 1]['Time'])

                # 第一种开仓条件：针对价内期权，且与前一行时间相同
                if ITM_check and same_time_check_behind:
                    # 检查波动率微笑是否存在显著凸起：当前IV比前一个高1.5以上
                    if sample_data.iloc[row]['IV'] > (sample_data.iloc[row - 1]['IV'] + 1.5):
                        # 设置信号为1（开仓）
                        sample_data.iloc[row, sample_data.columns.get_loc('Signal')] = 1
                        # 计算开仓现金流：卖出2口中档期权，买入1口高档和1口低档期权
                        sample_data.iloc[row, sample_data.columns.get_loc('PNL')] = (
                                2 * sample_data.iloc[row]['LTP'] -  # 卖出2口中档期权
                                sample_data.iloc[row + 1]['LTP'] -  # 买入1口高档期权
                                sample_data.iloc[row - 1]['LTP']  # 买入1口低档期权
                        )

                        # 记录开仓位置
                        Open_position = row
                        # 绘制开仓时的波动率微笑曲线
                        Plot_smile(sample_data.iloc[row]['Date'], sample_data.iloc[row]['Time'], sample_data)
                        # 输出开仓信息
                        if sample_data.iloc[row]['PNL'] > 0:
                            PnL = ["Money Received: INR", sample_data.iloc[row]['PNL']]
                        elif sample_data.iloc[row]['PNL'] < 0:
                            PnL = ["Money Paid: INR", -sample_data.iloc[row]['PNL']]

                        print("Position opened", "\nDate:", sample_data.iloc[row]['Date'],
                              "\nTime:", sample_data.iloc[row]['Time'],
                              "\nStrike Price:", sample_data.iloc[row]['Strike Price'],
                              "\n", PnL[0], PnL[1])

                # 第二种开仓条件：针对价外期权，且与后一行时间相同
                elif OTM_check and same_time_check_ahead:
                    # 检查波动率微笑是否存在显著凸起：当前IV比后一个高1.5以上
                    if sample_data.iloc[row]['IV'] > (sample_data.iloc[row + 1]['IV'] + 1.5):
                        # 设置信号为1（开仓）
                        sample_data.iloc[row, sample_data.columns.get_loc('Signal')] = 1
                        # 计算开仓现金流：卖出2口中档期权，买入1口高档和1口低档期权
                        sample_data.iloc[row, sample_data.columns.get_loc('PNL')] = (
                                2 * sample_data.iloc[row]['LTP'] -  # 卖出2口中档期权
                                sample_data.iloc[row + 1]['LTP'] -  # 买入1口高档期权
                                sample_data.iloc[row - 1]['LTP']  # 买入1口低档期权
                        )

                        # 记录开仓位置
                        Open_position = row
                        # 绘制开仓时的波动率微笑曲线
                        Plot_smile(sample_data.iloc[row]['Date'], sample_data.iloc[row]['Time'], sample_data)

                        # 输出开仓信息
                        if sample_data.iloc[row]['PNL'] > 0:
                            PnL = ["Money Received: INR", sample_data.iloc[row]['PNL']]  # 正值为收到权利金
                        elif sample_data.iloc[row]['PNL'] < 0:
                            PnL = ["Money Paid: INR", -sample_data.iloc[row]['PNL']]  # 负值为支付权利金

                        print("Position opened", "\nDate:", sample_data.iloc[row]['Date'],
                              "\nTime:", sample_data.iloc[row]['Time'],
                              "\nStrike Price:", sample_data.iloc[row]['Strike Price'],
                              "\n", PnL[0], PnL[1])

            # 平仓逻辑：当波动率微笑凸起消失时平仓
            # 检查是否存在未平仓部位，且当前行权价与开仓时一致
            elif (sample_data.iloc[row]['Signal'] == 1 and  # 当前有持仓
                  Open_position is not None and  # 开仓位置存在
                  sample_data.iloc[row]['Strike Price'] == sample_data.iloc[Open_position]['Strike Price']):

                # 价内期权平仓条件
                if sample_data.iloc[row]['Underlying Value'] > sample_data.iloc[row]['Strike Price']:

                    # 检查前后行时间一致性
                    same_time_check_behind = (sample_data.iloc[row]['Date'] == sample_data.iloc[row - 1]['Date'] and
                                              sample_data.iloc[row]['Time'] == sample_data.iloc[row - 1]['Time'])
                    # 检查凸起是否消失：当前IV小于前一个IV
                    if same_time_check_behind and sample_data.iloc[row]['IV'] < sample_data.iloc[row - 1]['IV']:

                        # 设置信号为0（平仓）
                        sample_data.iloc[row, sample_data.columns.get_loc('Signal')] = 0

                        # 计算平仓现金流：反向操作，买入2口中档期权，卖出1口高档和1口低档期权
                        sample_data.iloc[row, sample_data.columns.get_loc('PNL')] = (
                                -2 * sample_data.iloc[row]['LTP'] +  # 买入2口中档期权（平仓）
                                sample_data.iloc[row + 1]['LTP'] +  # 卖出1口高档期权（平仓）
                                sample_data.iloc[row - 1]['LTP']  # 卖出1口低档期权（平仓）
                        )

                        # 绘制平仓时的波动率微笑曲线
                        Plot_smile(sample_data.iloc[row]['Date'], sample_data.iloc[row]['Time'], sample_data)

                        # 输出平仓信息
                        if sample_data.iloc[row]['PNL'] > 0:
                            PnL = ["Money Received: INR", sample_data.iloc[row]['PNL']]  # 正值为平仓收入
                        elif sample_data.iloc[row]['PNL'] < 0:
                            PnL = ["Money Paid: INR", -sample_data.iloc[row]['PNL']]  # 负值为平仓支出

                        print("Position closed", "\nDate:", sample_data.iloc[row]['Date'],
                              "\nTime:", sample_data.iloc[row]['Time'],
                              "\nStrike Price:", sample_data.iloc[row]['Strike Price'],
                              "\n", PnL[0], PnL[1])

                # 价外期权平仓条件
                elif sample_data.iloc[row]['Underlying Value'] < sample_data.iloc[row]['Strike Price']:

                    # 检查前后行时间一致性
                    same_time_check_ahead = (row < total_rows - 1 and
                                             sample_data.iloc[row]['Date'] == sample_data.iloc[row + 1]['Date'] and
                                             sample_data.iloc[row]['Time'] == sample_data.iloc[row + 1]['Time'])
                    # 检查凸起是否消失：当前IV小于后一个IV
                    if same_time_check_ahead and sample_data.iloc[row]['IV'] < sample_data.iloc[row + 1]['IV']:

                        # 设置信号为0（平仓）
                        sample_data.iloc[row, sample_data.columns.get_loc('Signal')] = 0

                        # 计算平仓现金流：反向操作，买入2口中档期权，卖出1口高档和1口低档期权
                        sample_data.iloc[row, sample_data.columns.get_loc('PNL')] = (
                                -2 * sample_data.iloc[row]['LTP'] +
                                sample_data.iloc[row + 1]['LTP'] +
                                sample_data.iloc[row - 1]['LTP']
                        )

                        # 绘制平仓时的波动率微笑曲线
                        Plot_smile(sample_data.iloc[row]['Date'], sample_data.iloc[row]['Time'], sample_data)

                        # 输出平仓信息
                        if sample_data.iloc[row]['PNL'] > 0:
                            PnL = ["Money Received: INR", sample_data.iloc[row]['PNL']]
                        elif sample_data.iloc[row]['PNL'] < 0:
                            PnL = ["Money Paid: INR", -sample_data.iloc[row]['PNL']]

                        print("Position closed", "\nDate:", sample_data.iloc[row]['Date'],
                              "\nTime:", sample_data.iloc[row]['Time'],
                              "\nStrike Price:", sample_data.iloc[row]['Strike Price'],
                              "\n", PnL[0], PnL[1])

            # 计算持仓的市值标记（MTM）
            if sample_data.iloc[row]['Signal'] == 1:

                # 检查前后行时间一致性
                same_time_check_ahead = (row < total_rows - 1 and
                                         sample_data.iloc[row]['Date'] == sample_data.iloc[row + 1]['Date'] and
                                         sample_data.iloc[row]['Time'] == sample_data.iloc[row + 1]['Time'])
                same_time_check_behind = (sample_data.iloc[row]['Date'] == sample_data.iloc[row - 1]['Date'] and
                                          sample_data.iloc[row]['Time'] == sample_data.iloc[row - 1]['Time'])
                # 如果前后行时间相同，计算当前持仓市值
                if same_time_check_ahead and same_time_check_behind:
                    sample_data.iloc[row, sample_data.columns.get_loc('MTM')] = (
                            2 * sample_data.iloc[row]['LTP'] -
                            sample_data.iloc[row + 1]['LTP'] -
                            sample_data.iloc[row - 1]['LTP']
                    )

            # 持仓状态传递：如果当前有持仓，将信号传递到下一行
            if sample_data.iloc[row]['Signal'] == 1 and row < total_rows - 1:
                sample_data.iloc[row + 1, sample_data.columns.get_loc('Signal')] = 1

        # 计算累计损益：对PNL列进行累积求和
        sample_data['Cumulative PNL'] = sample_data['PNL'].cumsum()

        # 输出最终结果
        if len(sample_data) > 0:
            print("\n\nCumulative PNL from volatility smile trading strategy: INR",
                  sample_data.iloc[-1]['Cumulative PNL'])
        else:
            print("\n\nNo data available for PNL calculation")

        # 保存結果
        sample_data.to_excel('volatility_smile_trading_results.xlsx', index=False, engine='openpyxl')
        print("波動率微笑交易策略執行完成，結果已保存！")

        strategy_executed = True
        print("标记4: 策略执行完成")
        return True

    except Exception as e:
        print(f"执行波动率微笑交易策略时出错: {e}")
        return False

# ===============================================第五部分：下单执行===============================================================
def execute_trading_orders():
    global order_executed

    try:
        # 读取策略结果文件
        data_file = 'volatility_smile_trading_results.xlsx'
        if not os.path.exists(data_file):
            print(f"策略结果文件 {data_file} 不存在，跳过下单")
            return False

        sample_data = pd.read_excel(data_file, engine='openpyxl')
        if sample_data.empty:
            print("策略结果文件为空，跳过下单")
            return False

        # 获取最新信号
        row = len(sample_data) - 1
        current_signal = sample_data.iloc[row]['Signal']
        current_symbol = sample_data.iloc[row]['Symbol']

        print(f"\n=== 执行交易下单 ===")
        print(f"信号: {current_signal}, 合约: {current_symbol}")

        # 根据信号执行下单
        if current_signal == 1:  # 开仓信号
            print("执行开仓下单...")
            success = place_market_order(current_symbol, 1, 1, PositionEffect.Open)
        elif current_signal == 0:  # 平仓信号
            print("执行平仓下单...")
            success = place_market_order(current_symbol, 2, 1, PositionEffect.Close)
        else:
            print("无交易信号，跳过下单")
            success = True

        if success:
            order_executed = True
            print("标记5: 下单执行完成")

        return success

    except Exception as e:
        print(f"执行交易下单时出错: {e}")
        return False


# 下单函数 市价下单
def place_market_order(symbol, side, quantity, position_effect=PositionEffect.Open):
    try:
        # 获取账户信息
        accoutlist = api.getaccountlist()
        if not accoutlist:
            print("未找到可用的交易账户")
            return False

        account_info = accoutlist[0]

        # 设置订单属性
        OrderStruct.Account = account_info['Account']
        OrderStruct.BrokerID = account_info['BrokerID']
        OrderStruct.Symbol = symbol
        OrderStruct.Side = OrderSide.Buy if side == 1 else OrderSide.Sell
        OrderStruct.OrderQty = quantity
        OrderStruct.OrderType = OrderType.Market
        OrderStruct.TimeInForce = TimeInForce.IOC
        OrderStruct.PositionEffect = position_effect

        # 打印订单信息
        side_text = "买入" if side == 1 else "卖出"
        position_effect_text = "开仓" if position_effect == PositionEffect.Open else "平仓"
        print(f"提交市价单: {symbol}, 方向: {side_text}, 数量: {quantity}, 开平: {position_effect_text}")

        # 提交订单
        ordkey, msg = api.neworder(OrderStruct)

        if ordkey is None:
            print(f"下单失败: {msg}")
            return False

        print(f"订单提交成功, 订单ID: {ordkey}")
        return True

    except Exception as e:
        print(f"下单异常: {str(e)}")
        return False

# ===============================================遍历节点函数===============================================================
def traverse_nodes(node, target_underlying, target_expiry):
    calls = []
    puts = []

    if 'Node' in node:
        for child in node['Node']:
            c, p = traverse_nodes(child, target_underlying, target_expiry)
            calls.extend(c)
            puts.extend(p)

    if 'Contracts' in node:
        for contract in node['Contracts']:
            parts = contract.split('.')
            if (len(parts) >= 6 and
                    parts[3] == target_underlying and
                    parts[4] == target_expiry):
                if parts[5] == 'C':
                    calls.append(contract)
                elif parts[5] == 'P':
                    puts.append(contract)

    return calls, puts


# ===============================================事件处理类===============================================================
class APIEvent(TradeEvent, QuoteEvent):
    def onconnected(self, apitype: str):
        print("连线成功通知：", apitype)

    def ondisconnected(self, apitype: str):
        print("连线失败通知：", apitype)

    def onbar(self, bartype, interval, symbol, data, isreal):
        # 只在订阅完成后处理实时数据
        if subscription_completed and isreal:
            # 将数据转换为DataFrame
            df = pd.DataFrame(data)
            # 调用实时数据处理函数
            process_real_time_data(symbol, df, isreal)

# ===============================================主程序===============================================================
if __name__ == "__main__":
    ensure_directories()
    # 实时行情订阅需要传入应用程序路径和事件类
    api_event = APIEvent()
    api = TCoreAPI(apppath=path, eventclass=api_event)
    re = api.connect()

    time.sleep(2)

    try:
        # 获取合约列表
        all_symbol_his = api.getsymbolhistory(symboltype="OPT", dt=symbol_date)
        symbol_list_call, symbol_list_put = traverse_nodes(all_symbol_his, TARGET_UNDERLYING, TARGET_EXPIRY)
        symbol_list_call = list(set(symbol_list_call))
        symbol_list_put = list(set(symbol_list_put))

        print(f"找到看涨期权 {len(symbol_list_call)} 个，看跌期权 {len(symbol_list_put)} 个")

        # 订阅数据
        api.subbar(btype=BarType.MINUTE, interval=1, symbol=symbol_F, starttime=starttime, isinterval=True)
        print(f"已订阅标的期货: {symbol_F}")

        for i, symbol in enumerate(symbol_list_call):
            try:
                api.subbar(btype=BarType.MINUTE, interval=1, symbol=symbol, starttime=starttime, isinterval=True)
                print(f"({i + 1}/{len(symbol_list_call)}) 已订阅看涨期权: {symbol}")
                time.sleep(0.1)
            except Exception as e:
                print(f"订阅看涨期权 {symbol} 失败: {e}")

        for i, symbol in enumerate(symbol_list_put):
            try:
                api.subbar(btype=BarType.MINUTE, interval=1, symbol=symbol, starttime=starttime, isinterval=True)
                print(f"({i + 1}/{len(symbol_list_put)}) 已订阅看跌期权: {symbol}")
                time.sleep(0.1)
            except Exception as e:
                print(f"订阅看跌期权 {symbol} 失败: {e}")

        subscription_completed = True
        print("标记1: 订阅完成，开始接收实时数据...")

        # 主循环 - 严格按照顺序执行
        while True:
            current_time = time.time()

            # 第一步：数据接收完成后再进行数据处理
            if data_received and not data_processed:
                print("开始数据处理和合并...")
                merge_contract_data()
                data_received = False

            # 第二步：数据处理完成后再进行IV计算
            if data_processed and not strategy_executed:
                print("开始IV计算和策略执行...")
                if calculate_implied_volatility():
                    execute_volatility_smile_strategy()
                data_processed = False

            # 第五步：策略执行完成后进行下单
            if strategy_executed and not order_executed:
                print("开始执行交易下单...")
                execute_trading_orders()
                strategy_executed = False

            time.sleep(1)

    except KeyboardInterrupt:
        print("程序被用户中断")
    except Exception as e:
        print(f"程序运行异常: {e}")
    finally:
        api.disconnect()
        print("程序结束")