# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_cloudapi20160714 import models as main_models
from darabonba.model import DaraModel

class DescribePurchasedApisResponseBody(DaraModel):
    def __init__(
        self,
        page_number: int = None,
        page_size: int = None,
        purchased_apis: main_models.DescribePurchasedApisResponseBodyPurchasedApis = None,
        request_id: str = None,
        total_count: int = None,
    ):
        # The page number of the returned page.
        self.page_number = page_number
        # The number of entries returned on each page.
        self.page_size = page_size
        self.purchased_apis = purchased_apis
        # The ID of the request.
        self.request_id = request_id
        # The total number of returned entries.
        self.total_count = total_count

    def validate(self):
        if self.purchased_apis:
            self.purchased_apis.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.page_number is not None:
            result['PageNumber'] = self.page_number

        if self.page_size is not None:
            result['PageSize'] = self.page_size

        if self.purchased_apis is not None:
            result['PurchasedApis'] = self.purchased_apis.to_map()

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        if self.total_count is not None:
            result['TotalCount'] = self.total_count

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('PageNumber') is not None:
            self.page_number = m.get('PageNumber')

        if m.get('PageSize') is not None:
            self.page_size = m.get('PageSize')

        if m.get('PurchasedApis') is not None:
            temp_model = main_models.DescribePurchasedApisResponseBodyPurchasedApis()
            self.purchased_apis = temp_model.from_map(m.get('PurchasedApis'))

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        if m.get('TotalCount') is not None:
            self.total_count = m.get('TotalCount')

        return self

class DescribePurchasedApisResponseBodyPurchasedApis(DaraModel):
    def __init__(
        self,
        purchased_api: List[main_models.DescribePurchasedApisResponseBodyPurchasedApisPurchasedApi] = None,
    ):
        self.purchased_api = purchased_api

    def validate(self):
        if self.purchased_api:
            for v1 in self.purchased_api:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['PurchasedApi'] = []
        if self.purchased_api is not None:
            for k1 in self.purchased_api:
                result['PurchasedApi'].append(k1.to_map() if k1 else None)

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.purchased_api = []
        if m.get('PurchasedApi') is not None:
            for k1 in m.get('PurchasedApi'):
                temp_model = main_models.DescribePurchasedApisResponseBodyPurchasedApisPurchasedApi()
                self.purchased_api.append(temp_model.from_map(k1))

        return self

class DescribePurchasedApisResponseBodyPurchasedApisPurchasedApi(DaraModel):
    def __init__(
        self,
        api_id: str = None,
        api_name: str = None,
        deployed_time: str = None,
        description: str = None,
        group_id: str = None,
        group_name: str = None,
        modified_time: str = None,
        purchased_time: str = None,
        region_id: str = None,
        stage_name: str = None,
        visibility: str = None,
    ):
        self.api_id = api_id
        self.api_name = api_name
        self.deployed_time = deployed_time
        self.description = description
        self.group_id = group_id
        self.group_name = group_name
        self.modified_time = modified_time
        self.purchased_time = purchased_time
        self.region_id = region_id
        self.stage_name = stage_name
        self.visibility = visibility

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.api_id is not None:
            result['ApiId'] = self.api_id

        if self.api_name is not None:
            result['ApiName'] = self.api_name

        if self.deployed_time is not None:
            result['DeployedTime'] = self.deployed_time

        if self.description is not None:
            result['Description'] = self.description

        if self.group_id is not None:
            result['GroupId'] = self.group_id

        if self.group_name is not None:
            result['GroupName'] = self.group_name

        if self.modified_time is not None:
            result['ModifiedTime'] = self.modified_time

        if self.purchased_time is not None:
            result['PurchasedTime'] = self.purchased_time

        if self.region_id is not None:
            result['RegionId'] = self.region_id

        if self.stage_name is not None:
            result['StageName'] = self.stage_name

        if self.visibility is not None:
            result['Visibility'] = self.visibility

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('ApiId') is not None:
            self.api_id = m.get('ApiId')

        if m.get('ApiName') is not None:
            self.api_name = m.get('ApiName')

        if m.get('DeployedTime') is not None:
            self.deployed_time = m.get('DeployedTime')

        if m.get('Description') is not None:
            self.description = m.get('Description')

        if m.get('GroupId') is not None:
            self.group_id = m.get('GroupId')

        if m.get('GroupName') is not None:
            self.group_name = m.get('GroupName')

        if m.get('ModifiedTime') is not None:
            self.modified_time = m.get('ModifiedTime')

        if m.get('PurchasedTime') is not None:
            self.purchased_time = m.get('PurchasedTime')

        if m.get('RegionId') is not None:
            self.region_id = m.get('RegionId')

        if m.get('StageName') is not None:
            self.stage_name = m.get('StageName')

        if m.get('Visibility') is not None:
            self.visibility = m.get('Visibility')

        return self

