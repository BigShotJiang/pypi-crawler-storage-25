# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_cloudapi20160714 import models as main_models
from darabonba.model import DaraModel

class DescribeAuthorizedApisResponseBody(DaraModel):
    def __init__(
        self,
        authorized_apis: main_models.DescribeAuthorizedApisResponseBodyAuthorizedApis = None,
        page_number: int = None,
        page_size: int = None,
        request_id: str = None,
        total_count: int = None,
    ):
        self.authorized_apis = authorized_apis
        # The page number of the returned page.
        self.page_number = page_number
        # The number of entries returned per page.
        self.page_size = page_size
        # The ID of the request.
        self.request_id = request_id
        # The total number of returned entries.
        self.total_count = total_count

    def validate(self):
        if self.authorized_apis:
            self.authorized_apis.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.authorized_apis is not None:
            result['AuthorizedApis'] = self.authorized_apis.to_map()

        if self.page_number is not None:
            result['PageNumber'] = self.page_number

        if self.page_size is not None:
            result['PageSize'] = self.page_size

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        if self.total_count is not None:
            result['TotalCount'] = self.total_count

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AuthorizedApis') is not None:
            temp_model = main_models.DescribeAuthorizedApisResponseBodyAuthorizedApis()
            self.authorized_apis = temp_model.from_map(m.get('AuthorizedApis'))

        if m.get('PageNumber') is not None:
            self.page_number = m.get('PageNumber')

        if m.get('PageSize') is not None:
            self.page_size = m.get('PageSize')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        if m.get('TotalCount') is not None:
            self.total_count = m.get('TotalCount')

        return self

class DescribeAuthorizedApisResponseBodyAuthorizedApis(DaraModel):
    def __init__(
        self,
        authorized_api: List[main_models.DescribeAuthorizedApisResponseBodyAuthorizedApisAuthorizedApi] = None,
    ):
        self.authorized_api = authorized_api

    def validate(self):
        if self.authorized_api:
            for v1 in self.authorized_api:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['AuthorizedApi'] = []
        if self.authorized_api is not None:
            for k1 in self.authorized_api:
                result['AuthorizedApi'].append(k1.to_map() if k1 else None)

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.authorized_api = []
        if m.get('AuthorizedApi') is not None:
            for k1 in m.get('AuthorizedApi'):
                temp_model = main_models.DescribeAuthorizedApisResponseBodyAuthorizedApisAuthorizedApi()
                self.authorized_api.append(temp_model.from_map(k1))

        return self

class DescribeAuthorizedApisResponseBodyAuthorizedApisAuthorizedApi(DaraModel):
    def __init__(
        self,
        api_id: str = None,
        api_name: str = None,
        auth_vaild_time: str = None,
        authorization_source: str = None,
        authorized_time: str = None,
        description: str = None,
        group_id: str = None,
        group_name: str = None,
        operator: str = None,
        region_id: str = None,
        stage_name: str = None,
    ):
        self.api_id = api_id
        self.api_name = api_name
        self.auth_vaild_time = auth_vaild_time
        self.authorization_source = authorization_source
        self.authorized_time = authorized_time
        self.description = description
        self.group_id = group_id
        self.group_name = group_name
        self.operator = operator
        self.region_id = region_id
        self.stage_name = stage_name

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.api_id is not None:
            result['ApiId'] = self.api_id

        if self.api_name is not None:
            result['ApiName'] = self.api_name

        if self.auth_vaild_time is not None:
            result['AuthVaildTime'] = self.auth_vaild_time

        if self.authorization_source is not None:
            result['AuthorizationSource'] = self.authorization_source

        if self.authorized_time is not None:
            result['AuthorizedTime'] = self.authorized_time

        if self.description is not None:
            result['Description'] = self.description

        if self.group_id is not None:
            result['GroupId'] = self.group_id

        if self.group_name is not None:
            result['GroupName'] = self.group_name

        if self.operator is not None:
            result['Operator'] = self.operator

        if self.region_id is not None:
            result['RegionId'] = self.region_id

        if self.stage_name is not None:
            result['StageName'] = self.stage_name

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('ApiId') is not None:
            self.api_id = m.get('ApiId')

        if m.get('ApiName') is not None:
            self.api_name = m.get('ApiName')

        if m.get('AuthVaildTime') is not None:
            self.auth_vaild_time = m.get('AuthVaildTime')

        if m.get('AuthorizationSource') is not None:
            self.authorization_source = m.get('AuthorizationSource')

        if m.get('AuthorizedTime') is not None:
            self.authorized_time = m.get('AuthorizedTime')

        if m.get('Description') is not None:
            self.description = m.get('Description')

        if m.get('GroupId') is not None:
            self.group_id = m.get('GroupId')

        if m.get('GroupName') is not None:
            self.group_name = m.get('GroupName')

        if m.get('Operator') is not None:
            self.operator = m.get('Operator')

        if m.get('RegionId') is not None:
            self.region_id = m.get('RegionId')

        if m.get('StageName') is not None:
            self.stage_name = m.get('StageName')

        return self

