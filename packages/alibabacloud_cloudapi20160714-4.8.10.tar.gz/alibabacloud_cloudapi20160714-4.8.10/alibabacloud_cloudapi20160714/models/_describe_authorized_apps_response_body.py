# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_cloudapi20160714 import models as main_models
from darabonba.model import DaraModel

class DescribeAuthorizedAppsResponseBody(DaraModel):
    def __init__(
        self,
        authorized_apps: main_models.DescribeAuthorizedAppsResponseBodyAuthorizedApps = None,
        page_number: int = None,
        page_size: int = None,
        request_id: str = None,
        total_count: int = None,
    ):
        self.authorized_apps = authorized_apps
        # The page number of the returned page.
        self.page_number = page_number
        # The number of entries returned per page.
        self.page_size = page_size
        # The ID of the request.
        self.request_id = request_id
        # The total number of returned entries.
        self.total_count = total_count

    def validate(self):
        if self.authorized_apps:
            self.authorized_apps.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.authorized_apps is not None:
            result['AuthorizedApps'] = self.authorized_apps.to_map()

        if self.page_number is not None:
            result['PageNumber'] = self.page_number

        if self.page_size is not None:
            result['PageSize'] = self.page_size

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        if self.total_count is not None:
            result['TotalCount'] = self.total_count

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AuthorizedApps') is not None:
            temp_model = main_models.DescribeAuthorizedAppsResponseBodyAuthorizedApps()
            self.authorized_apps = temp_model.from_map(m.get('AuthorizedApps'))

        if m.get('PageNumber') is not None:
            self.page_number = m.get('PageNumber')

        if m.get('PageSize') is not None:
            self.page_size = m.get('PageSize')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        if m.get('TotalCount') is not None:
            self.total_count = m.get('TotalCount')

        return self

class DescribeAuthorizedAppsResponseBodyAuthorizedApps(DaraModel):
    def __init__(
        self,
        authorized_app: List[main_models.DescribeAuthorizedAppsResponseBodyAuthorizedAppsAuthorizedApp] = None,
    ):
        self.authorized_app = authorized_app

    def validate(self):
        if self.authorized_app:
            for v1 in self.authorized_app:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['AuthorizedApp'] = []
        if self.authorized_app is not None:
            for k1 in self.authorized_app:
                result['AuthorizedApp'].append(k1.to_map() if k1 else None)

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.authorized_app = []
        if m.get('AuthorizedApp') is not None:
            for k1 in m.get('AuthorizedApp'):
                temp_model = main_models.DescribeAuthorizedAppsResponseBodyAuthorizedAppsAuthorizedApp()
                self.authorized_app.append(temp_model.from_map(k1))

        return self

class DescribeAuthorizedAppsResponseBodyAuthorizedAppsAuthorizedApp(DaraModel):
    def __init__(
        self,
        app_description: str = None,
        app_id: int = None,
        app_name: str = None,
        auth_vaild_time: str = None,
        authorization_source: str = None,
        authorized_time: str = None,
        description: str = None,
        operator: str = None,
        stage_alias: str = None,
        stage_name: str = None,
        tag: main_models.DescribeAuthorizedAppsResponseBodyAuthorizedAppsAuthorizedAppTag = None,
    ):
        self.app_description = app_description
        self.app_id = app_id
        self.app_name = app_name
        self.auth_vaild_time = auth_vaild_time
        self.authorization_source = authorization_source
        self.authorized_time = authorized_time
        self.description = description
        self.operator = operator
        self.stage_alias = stage_alias
        self.stage_name = stage_name
        self.tag = tag

    def validate(self):
        if self.tag:
            self.tag.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.app_description is not None:
            result['AppDescription'] = self.app_description

        if self.app_id is not None:
            result['AppId'] = self.app_id

        if self.app_name is not None:
            result['AppName'] = self.app_name

        if self.auth_vaild_time is not None:
            result['AuthVaildTime'] = self.auth_vaild_time

        if self.authorization_source is not None:
            result['AuthorizationSource'] = self.authorization_source

        if self.authorized_time is not None:
            result['AuthorizedTime'] = self.authorized_time

        if self.description is not None:
            result['Description'] = self.description

        if self.operator is not None:
            result['Operator'] = self.operator

        if self.stage_alias is not None:
            result['StageAlias'] = self.stage_alias

        if self.stage_name is not None:
            result['StageName'] = self.stage_name

        if self.tag is not None:
            result['Tag'] = self.tag.to_map()

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AppDescription') is not None:
            self.app_description = m.get('AppDescription')

        if m.get('AppId') is not None:
            self.app_id = m.get('AppId')

        if m.get('AppName') is not None:
            self.app_name = m.get('AppName')

        if m.get('AuthVaildTime') is not None:
            self.auth_vaild_time = m.get('AuthVaildTime')

        if m.get('AuthorizationSource') is not None:
            self.authorization_source = m.get('AuthorizationSource')

        if m.get('AuthorizedTime') is not None:
            self.authorized_time = m.get('AuthorizedTime')

        if m.get('Description') is not None:
            self.description = m.get('Description')

        if m.get('Operator') is not None:
            self.operator = m.get('Operator')

        if m.get('StageAlias') is not None:
            self.stage_alias = m.get('StageAlias')

        if m.get('StageName') is not None:
            self.stage_name = m.get('StageName')

        if m.get('Tag') is not None:
            temp_model = main_models.DescribeAuthorizedAppsResponseBodyAuthorizedAppsAuthorizedAppTag()
            self.tag = temp_model.from_map(m.get('Tag'))

        return self

class DescribeAuthorizedAppsResponseBodyAuthorizedAppsAuthorizedAppTag(DaraModel):
    def __init__(
        self,
        tag_info: List[main_models.DescribeAuthorizedAppsResponseBodyAuthorizedAppsAuthorizedAppTagTagInfo] = None,
    ):
        self.tag_info = tag_info

    def validate(self):
        if self.tag_info:
            for v1 in self.tag_info:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['TagInfo'] = []
        if self.tag_info is not None:
            for k1 in self.tag_info:
                result['TagInfo'].append(k1.to_map() if k1 else None)

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.tag_info = []
        if m.get('TagInfo') is not None:
            for k1 in m.get('TagInfo'):
                temp_model = main_models.DescribeAuthorizedAppsResponseBodyAuthorizedAppsAuthorizedAppTagTagInfo()
                self.tag_info.append(temp_model.from_map(k1))

        return self

class DescribeAuthorizedAppsResponseBodyAuthorizedAppsAuthorizedAppTagTagInfo(DaraModel):
    def __init__(
        self,
        key: str = None,
        value: str = None,
    ):
        self.key = key
        self.value = value

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.key is not None:
            result['Key'] = self.key

        if self.value is not None:
            result['Value'] = self.value

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Key') is not None:
            self.key = m.get('Key')

        if m.get('Value') is not None:
            self.value = m.get('Value')

        return self

