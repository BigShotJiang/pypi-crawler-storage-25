#!/usr/bin/env python
# SPDX-FileCopyrightText: 2024 Abhinav Mishra
# SPDX-License-Identifier: BSD-3-Clause
"""
annotate.py
--------------------------------

Builds:
    1) protein_annotations.csv
    2) protein_sequences.fasta

from a list of protein IDs using mygene and UniProt REST, with parallelized
FASTA retrieval.
"""
# BSD 3-Clause License
#
# Copyright (c) 2025, Abhinav Mishra
# All rights reserved.
# Email: mishraabhinav36@gmail.com
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# 3. Neither the name of Abhinav Mishra nor the names of its contributors may
#    be used to endorse or promote products derived from this software without
#    specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

from __future__ import annotations

import argparse
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import mygene
import pandas as pd
import requests
from tqdm.auto import tqdm

# ---------------------------------------------------------------------
# 1. Get unique IDs from fits table
# ---------------------------------------------------------------------


def get_unique_ids(
    fits_csv: str | Path,
    id_col: str = "id",
) -> list[str]:
    df = pd.read_csv(fits_csv)
    if id_col not in df.columns:
        raise ValueError(f"Column '{id_col}' not found in {fits_csv}")
    ids = df[id_col].dropna().astype(str).unique().tolist()
    return ids


# ---------------------------------------------------------------------
# Helper: strip isoform suffixes
# ---------------------------------------------------------------------
def strip_isoform_suffix(acc: str) -> str:
    """
    Remove UniProt isoform suffixes like '-1', '-2', '-10'.
    O00231-2 → O00231
    """
    if not isinstance(acc, str):
        return acc
    # Only strip final -number pattern
    if acc.count("-") == 1 and acc.split("-")[1].isdigit():
        return acc.split("-")[0]
    return acc


# ---------------------------------------------------------------------
# 2. Annotation via mygene
# ---------------------------------------------------------------------


def fetch_annotations_with_mygene(
    ids: list[str],
    species: str = "human",
    chunk_size: int = 1000,
) -> pd.DataFrame:
    """
    Use mygene to get basic annotations.

    We try multiple scopes: symbol, entrezgene, uniprot.
    Returned fields:
        symbol, name, entrezgene, uniprot, go.BP, pathway
    """
    mg = mygene.MyGeneInfo()

    all_records: list[dict[str, Any]] = []

    # mygene is already "batch-parallelized" internally, so we just chunk
    for i in tqdm(range(0, len(ids), chunk_size), desc="mygene annotations"):
        batch = ids[i : i + chunk_size]

        res = mg.querymany(
            batch,
            scopes=["uniprot", "symbol", "entrezgene"],
            fields=[
                "symbol",
                "name",
                "entrezgene",
                "uniprot",
                "go.BP",
                "pathway",
            ],
            species=species,
            as_dataframe=False,
            returnall=False,
            verbose=False,
        )

        # res is a list of dicts
        for r in res:
            # 'query' is the original ID we asked for
            q = r.get("query")
            if q is None:
                continue

            symbol = r.get("symbol")
            name = r.get("name")
            entrez = r.get("entrezgene")
            # UniProt IDs may come as dict/list
            uni = r.get("uniprot")
            if isinstance(uni, dict):
                # e.g. {"Swiss-Prot": "P12345", "TrEMBL": [...]} or vice versa
                swiss = uni.get("Swiss-Prot")
                trembl = uni.get("TrEMBL")
                if isinstance(swiss, list):
                    swiss = swiss[0]
                if isinstance(trembl, list):
                    trembl = trembl[0]
                uniprot_acc = swiss or trembl
            elif isinstance(uni, list):
                uniprot_acc = uni[0]
            else:
                uniprot_acc = uni

            # GO BP terms
            go_bp = r.get("go", {}).get("BP", [])
            if isinstance(go_bp, dict):
                go_bp = [go_bp]
            bp_terms = []
            for bp in go_bp:
                term_id = bp.get("id")
                term_name = bp.get("term")
                if term_id and term_name:
                    bp_terms.append(f"{term_id}:{term_name}")
                elif term_name:
                    bp_terms.append(term_name)
            go_bp_str = ";".join(bp_terms) if bp_terms else ""

            # Pathway info (varies by source)
            pwy = r.get("pathway", {})
            p_terms: list[str] = []
            if isinstance(pwy, dict):
                # KEGG, Reactome, BioCarta etc.
                for src, val in pwy.items():
                    if isinstance(val, dict):
                        p_id = val.get("id")
                        p_name = val.get("name")
                        if p_id and p_name:
                            p_terms.append(f"{src}:{p_id}:{p_name}")
                        elif p_name:
                            p_terms.append(f"{src}:{p_name}")
                    elif isinstance(val, list):
                        for v in val:
                            p_id = v.get("id")
                            p_name = v.get("name")
                            if p_id and p_name:
                                p_terms.append(f"{src}:{p_id}:{p_name}")
                            elif p_name:
                                p_terms.append(f"{src}:{p_name}")
            pathway_str = ";".join(p_terms) if p_terms else ""

            all_records.append(
                {
                    "query_id": q,
                    "symbol": symbol,
                    "name": name,
                    "entrezgene": entrez,
                    "uniprot": uniprot_acc,
                    "go_bp": go_bp_str,
                    "pathway": pathway_str,
                }
            )

    annot_df = pd.DataFrame(all_records)

    # Deduplicate by query_id, keep the first best hit
    annot_df = annot_df.drop_duplicates(subset=["query_id"]).rename(
        columns={"query_id": "id"}
    )

    return annot_df


# ---------------------------------------------------------------------
# 3. Parallel UniProt FASTA download
# ---------------------------------------------------------------------


def fetch_uniprot_fasta(acc: str, timeout: float = 10.0) -> str | None:
    """
    Fetch a single UniProt FASTA entry by accession.

    Returns the FASTA string (with header + sequence) or None on failure.
    """
    if not isinstance(acc, str) or not acc:
        return None

    url = f"https://rest.uniprot.org/uniprotkb/{acc}.fasta"
    try:
        r = requests.get(url, timeout=timeout)
        if r.status_code == 200 and r.text.startswith(">"):
            return r.text.strip()
        return None
    except Exception:
        return None


def fetch_fastas_parallel(
    accessions: list[str],
    max_workers: int = 8,
) -> dict[str, str]:
    """
    Parallel UniProt FASTA retrieval for a list of accessions.

    Returns dict: {acc: fasta_text}.
    """
    accs = [a for a in sorted(set(accessions)) if isinstance(a, str) and a]

    results: dict[str, str] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(fetch_uniprot_fasta, a): a for a in accs}
        for fut in tqdm(
            as_completed(futures), total=len(futures), desc="UniProt FASTA"
        ):
            acc = futures[fut]
            fasta = fut.result()
            if fasta:
                results[acc] = fasta

    return results


def write_fastas_with_ids(
    annot_df: pd.DataFrame,
    acc_to_fasta: dict[str, str],
    out_fasta: str | Path,
    id_col: str = "id",
    uniprot_col: str = "uniprot",
) -> None:
    """
    Write FASTA where header is your own id (from id_col),
    not the UniProt header.

    For each row in annot_df:
        - take original id (e.g. O00231-2)
        - take UniProt accession (e.g. O00231)
        - get sequence from acc_to_fasta[accession]
        - strip original '>' header
        - write new header: >{id}
    """
    out_fasta = Path(out_fasta)
    out_fasta.parent.mkdir(parents=True, exist_ok=True)

    with out_fasta.open("w") as fh:
        for _, row in annot_df.iterrows():
            orig_id = str(row[id_col])
            acc = row.get(uniprot_col)
            if not isinstance(acc, str):
                continue
            fasta = acc_to_fasta.get(acc)
            if not fasta:
                continue

            lines = fasta.strip().splitlines()
            # drop original header line(s)

            # remove ambiguous variable name

            seq_lines = [line for line in lines if not line.startswith(">")]
            if not seq_lines:
                continue

            # NEW header with your ID
            fh.write(f">{orig_id}\n")
            fh.write("\n".join(seq_lines) + "\n")

    print(f"Wrote FASTA with custom IDs to {out_fasta}")


# ---------------------------------------------------------------------
# 4. Main: glue everything together
# ---------------------------------------------------------------------


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Build protein_annotations.csv and protein_sequences.fasta using mygene + UniProt (parallel)."
    )
    ap.add_argument(
        "--fits-csv",
        # required=True,
        default="../results/ec50_fits.csv",
        help="Input EC50 fits CSV with protein IDs (e.g. ec50_fits.csv).",
    )
    ap.add_argument(
        "--id-col",
        default="id",
        help="Column name for protein IDs in fits-csv.",
    )
    ap.add_argument(
        "--species",
        default="human",
        help="Species for mygene queries (e.g. 'human', 'mouse', 'rat').",
    )
    ap.add_argument(
        "--out-annot",
        default="../results/protein_annotations.csv",
        help="Output CSV for protein annotations.",
    )
    ap.add_argument(
        "--out-fasta",
        default="../results/protein_sequences.fasta",
        help="Output FASTA file for sequences.",
    )
    ap.add_argument(
        "--max-workers",
        type=int,
        default=os.cpu_count(),
        help="Maximum number of threads for parallel UniProt fetch.",
    )
    args = ap.parse_args()

    fits_path = Path(args.fits_csv)

    # 1) Get IDs
    ids = get_unique_ids(fits_path, id_col=args.id_col)
    # ids = [strip_isoform_suffix(x) for x in ids]
    print(f"Found {len(ids)} unique IDs from {fits_path}")

    # 2) Annotations with mygene
    annot_df = fetch_annotations_with_mygene(
        ids,
        species=args.species,
    )

    # -----------------------------------------------------------------
    # Align annotation table so that every original id has a row. MyGene
    # returns annotations keyed by the query (uniprot/symbol/entrezgene).
    # However, our fits table may contain isoform suffixes (e.g. O00231-2).
    # To avoid losing these IDs in downstream FASTA and annotation files,
    # we reconstruct a DataFrame where each original id is preserved.
    #
    # Strategy:
    # 1. Build a lookup by exact id from annot_df (from mygene).
    # 2. Build a lookup by stripped Uniprot accession (remove isoform suffix)
    #    for cases where the original id is an isoform of a known protein.
    # 3. Iterate over the original ids list and, for each, pick the best
    #    matching annotation (exact match first, otherwise isoform root).
    # 4. Fill missing fields with None/empty strings.
    #
    # Note: we cannot assume all original ids map uniquely to a Uniprot
    # accession; in such cases we still include the id with missing data.

    # Build exact lookup
    exact_lookup: dict[str, dict[str, Any]] = {
        str(row["id"]): row for _, row in annot_df.iterrows()
    }

    # Build isoform lookup keyed by stripped accession
    iso_lookup: dict[str, dict[str, Any]] = {}
    for _, row in annot_df.iterrows():
        uni = row.get("uniprot")
        if isinstance(uni, str):
            root = strip_isoform_suffix(uni)
            iso_lookup[root] = row

    # Determine union of annotation columns
    annot_cols = list(annot_df.columns)

    aligned_records: list[dict[str, Any]] = []
    for orig_id in ids:
        # Initialize base record with None/empty
        record: dict[str, Any] = dict.fromkeys(annot_cols)
        record["id"] = orig_id
        # Try exact match
        match = exact_lookup.get(orig_id)
        if match is None:
            # Try isoform match: use stripped id as key
            root = strip_isoform_suffix(orig_id)
            match = iso_lookup.get(root)
        if match is not None:
            for col in annot_cols:
                if col == "id":
                    # preserve original id
                    continue
                record[col] = match.get(col, None)
        aligned_records.append(record)

    aligned_df = pd.DataFrame(aligned_records)

    # Ensure consistent order
    aligned_df = aligned_df[annot_cols]

    # Save aligned annotation
    out_annot_path = Path(args.out_annot)
    out_annot_path.parent.mkdir(parents=True, exist_ok=True)
    aligned_df.to_csv(out_annot_path, index=False)
    print(f"Wrote annotations to {out_annot_path} (n={len(aligned_df)})")

    # 3) Parallel FASTA download from UniProt
    # Use the aligned_df to determine which accessions to download. If a
    # row has a uniprot accession, use that; otherwise use the stripped id.
    if "uniprot" in aligned_df.columns:
        accs = aligned_df["uniprot"].dropna().astype(str).tolist()
    else:
        accs = aligned_df["id"].dropna().astype(str).tolist()

    acc_to_fasta = fetch_fastas_parallel(
        accessions=accs,
        max_workers=args.max_workers,
    )

    write_fastas_with_ids(
        annot_df=aligned_df,
        acc_to_fasta=acc_to_fasta,
        out_fasta=args.out_fasta,
        id_col="id",
        uniprot_col="uniprot",
    )

    print("Done.")


if __name__ == "__main__":
    main()
