"""securityagent-core — DLP engine, security skills, and policy enforcement for AI coding agents."""

__version__ = "3.0.0"
