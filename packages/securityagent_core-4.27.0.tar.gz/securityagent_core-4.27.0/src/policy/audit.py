"""Append-only JSONL audit trail with agent attribution."""

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


logger = logging.getLogger(__name__)


def _summarize_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Create a loggable summary of params (truncate long values)."""
    summary = {}
    for k, v in params.items():
        if isinstance(v, str) and len(v) > 200:
            summary[k] = v[:200] + "..."
        else:
            summary[k] = v
    return summary

AUDIT_DIR = Path.home() / ".securityagent"
AUDIT_FILE = AUDIT_DIR / "skills_audit.jsonl"


class AuditTrail:
    """Append-only JSONL audit log. Every skill invocation is recorded."""

    def __init__(self, audit_file: Optional[Path] = None):
        self._file = audit_file or AUDIT_FILE
        self._file.parent.mkdir(parents=True, exist_ok=True)

    def log(
        self,
        skill_name: str,
        params: Dict,
        result: "SkillResult",
        context: "SessionContext",
    ):
        entry = {
            "timestamp": time.time(),
            "session_id": context.session_id,
            "agent_id": context.agent_id,
            "agent_type": context.agent_type,
            "trace_id": context.trace_id,
            "skill": skill_name,
            "params_summary": _summarize_params(params),
            "status": result.status.value,
            "reason": result.reason,
            "finding_count": len(result.findings),
        }
        try:
            with open(self._file, "a") as f:
                f.write(json.dumps(entry, default=str) + "\n")
        except OSError as exc:
            logger.warning("Failed to write audit log: %s", exc)

    def query(
        self,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        skill: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict]:
        """Query audit trail with optional filters."""
        if not self._file.exists():
            return []

        results: List[Dict] = []
        try:
            with open(self._file) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if session_id and entry.get("session_id") != session_id:
                        continue
                    if agent_id and entry.get("agent_id") != agent_id:
                        continue
                    if skill and entry.get("skill") != skill:
                        continue
                    results.append(entry)
        except OSError:
            pass

        return results[-limit:]
