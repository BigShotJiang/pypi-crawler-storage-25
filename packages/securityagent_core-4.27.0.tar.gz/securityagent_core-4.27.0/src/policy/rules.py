"""Default policy rule definitions."""

# Credential paths that should always be denied regardless of session policy.
# These mirror the existing SENSITIVE_FILE_PATTERNS from endpoint_agent/config/settings.py
# but are expressed as glob patterns for the policy engine.
DEFAULT_DENIED_PATHS = [
    "*/.env",
    "*/.env.*",
    "*/.aws/credentials",
    "*/.aws/config",
    "*/.ssh/id_*",
    "*/.ssh/config",
    "*/.npmrc",
    "*/.pypirc",
    "*/.netrc",
    "*/.docker/config.json",
    "*/.kube/config",
    "*/credentials.json",
    "*/secrets.yaml",
    "*/secrets.json",
    "*/terraform.tfvars",
    "*/.vault-token",
    "*/service-account.json",
    "*/private_key.json",
]

# Command patterns denied by default (cloud CLI exfil, raw sockets)
DEFAULT_DENIED_COMMANDS = [
    r"\baws\s+s3\s+(cp|sync|mv)\b",
    r"\bgcloud\s+storage\s+(cp|rsync)\b",
    r"\baz\s+storage\s+blob\s+upload\b",
    r"\b(nc|ncat|netcat|socat)\b",
]

# Read-only session preset — no exec, no network
READ_ONLY_PRESET = {
    "allowed_skills": {"secure_read", "check_policy", "analyze_prompt", "get_session_policy", "audit_log"},
    "denied_command_patterns": [".*"],  # Block all commands
}

# Standard session preset — all skills, default denials
STANDARD_PRESET = {
    "allowed_skills": {
        "secure_read", "secure_exec", "check_policy",
        "analyze_prompt", "scan_output", "get_session_policy", "audit_log",
    },
    "denied_path_patterns": DEFAULT_DENIED_PATHS,
    "denied_command_patterns": DEFAULT_DENIED_COMMANDS,
}
