"""Behavioral chain detection — correlates action sequences within a session."""

import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ChainAlert:
    """Alert raised when an action sequence matches a known attack chain."""

    pattern: str
    score: float
    actions: List[Dict]
    description: str


@dataclass
class ChainPattern:
    """Definition of a multi-step attack chain."""

    name: str
    description: str
    steps: List[Dict[str, Any]]
    window_seconds: int = 300
    min_steps_to_alert: int = 2
    score: float = 0.8


# Pre-defined attack chain patterns
CHAIN_PATTERNS = [
    ChainPattern(
        name="credential_exfil_chain",
        description="Read credentials -> archive -> upload/network",
        steps=[
            {
                "skill": "secure_read",
                "path_match": r"(credential|\.env|\.pem|\.key|id_rsa|\.aws|\.ssh)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(tar|zip|gzip|bzip2|base64)\b",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(curl|wget|nc|aws\s+s3|gcloud|az\s+storage)\b",
            },
        ],
        window_seconds=300,
        min_steps_to_alert=2,
        score=0.9,
    ),
    ChainPattern(
        name="bulk_sensitive_scan",
        description="Multiple reads of sensitive paths in rapid succession",
        steps=[
            {
                "skill": "secure_read",
                "count_threshold": 10,
                "window_seconds": 60,
            },
        ],
        window_seconds=60,
        min_steps_to_alert=1,
        score=0.7,
    ),
    ChainPattern(
        name="env_recon_then_network",
        description="Env/config reading followed by outbound network",
        steps=[
            {
                "skill": "secure_exec",
                "command_match": r"\b(env|printenv|cat\s+.*\.env)\b",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(curl|wget|nc|ncat)\b",
            },
        ],
        window_seconds=120,
        min_steps_to_alert=2,
        score=0.85,
    ),
    ChainPattern(
        name="privilege_escalation",
        description="Read sensitive system files -> modify permissions -> execute",
        steps=[
            {
                "skill": "secure_read",
                "path_match": r"(sudoers|shadow|passwd)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(chmod|chown|sudo)\b",
            },
        ],
        window_seconds=180,
        min_steps_to_alert=2,
        score=0.9,
    ),
    # --- Split-ticket patterns (from FirstOps blog) ---
    ChainPattern(
        name="split_ticket_credential_backup",
        description="Read credential files then create local copies (split-ticket step 1)",
        steps=[
            {
                "skill": "secure_read",
                "path_match": r"(\.aws|\.ssh|\.env|credential|\.kube|\.docker)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(cp|mv|rsync|ln\s+-s)\b.*\b(backup|tmp|copy|bak)\b",
            },
        ],
        window_seconds=300,
        min_steps_to_alert=2,
        score=0.85,
    ),
    ChainPattern(
        name="backup_then_upload",
        description="Find/create backup files then upload externally (split-ticket step 2)",
        steps=[
            {
                "skill": "secure_exec",
                "command_match": r"\b(find|ls|locate)\b.*(?:backup|_bak|\.bak|\.copy|_backup)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(aws\s+s3|gcloud\s+storage|az\s+storage|curl|wget|scp|rsync)\b",
            },
        ],
        window_seconds=300,
        min_steps_to_alert=2,
        score=0.9,
    ),
    # --- Supply chain patterns ---
    ChainPattern(
        name="supply_chain_injection",
        description="Read package config then modify it (dependency injection)",
        steps=[
            {
                "skill": "secure_read",
                "path_match": r"(package\.json|requirements\.txt|Gemfile|go\.mod|Cargo\.toml|pyproject\.toml)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(npm\s+install|pip\s+install|gem\s+install|go\s+get|cargo\s+add)\b",
            },
        ],
        window_seconds=180,
        min_steps_to_alert=2,
        score=0.75,
    ),
    # --- Git credential theft ---
    ChainPattern(
        name="git_credential_exfil",
        description="Read git config/credentials then push or remote add",
        steps=[
            {
                "skill": "secure_read",
                "path_match": r"(\.git/config|\.gitconfig|\.git-credentials|\.netrc)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\bgit\s+(remote\s+add|push|clone)\b",
            },
        ],
        window_seconds=120,
        min_steps_to_alert=2,
        score=0.85,
    ),
    # --- Docker/container escape ---
    ChainPattern(
        name="container_escape",
        description="Read Docker/k8s config then exec into container or mount volumes",
        steps=[
            {
                "skill": "secure_read",
                "path_match": r"(\.docker/config|\.kube/config|docker-compose|Dockerfile)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(docker\s+exec|docker\s+run.*-v|kubectl\s+exec|kubectl\s+cp)\b",
            },
        ],
        window_seconds=180,
        min_steps_to_alert=2,
        score=0.85,
    ),
    # --- Rapid exec after prompt injection detection ---
    ChainPattern(
        name="post_injection_exec_burst",
        description="Prompt flagged as risky followed by multiple exec attempts",
        steps=[
            {
                "skill": "analyze_prompt",
                "status_match": "blocked",
            },
            {
                "skill": "secure_exec",
                "count_threshold": 3,
                "window_seconds": 60,
            },
        ],
        window_seconds=120,
        min_steps_to_alert=1,
        score=0.9,
    ),
    # --- Database exfiltration ---
    ChainPattern(
        name="database_exfil",
        description="Read DB config then dump database then upload",
        steps=[
            {
                "skill": "secure_read",
                "path_match": r"(database\.yml|\.env|db\.conf|connection.*string|knexfile)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(pg_dump|mysqldump|mongodump|sqlite3\s+.*\.dump)\b",
            },
        ],
        window_seconds=300,
        min_steps_to_alert=2,
        score=0.9,
    ),
    # ─── Memory-agent attack chains ───────────────────────────────────────────
    ChainPattern(
        name="memory_poisoning_then_action",
        description="Memory write with authorization claim followed by sensitive action",
        steps=[
            {
                "skill": "memory_write",
                "command_match": r"(?i)(authorized|approved|allowed|safe\s+to|no\s+need)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(curl|wget|aws|gcloud|az|scp|rsync)\b",
            },
        ],
        window_seconds=600,
        min_steps_to_alert=2,
        score=0.95,
    ),
    ChainPattern(
        name="trust_boundary_injection_chain",
        description="Tool result with bypass instruction followed by security-sensitive action",
        steps=[
            {
                "skill": "tool_result",
                "command_match": r"(?i)(skip|bypass|ignore|don.?t\s+check)",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(rm|chmod|git\s+push|curl|docker)\b",
            },
        ],
        window_seconds=120,
        min_steps_to_alert=2,
        score=0.9,
    ),
    ChainPattern(
        name="memory_read_then_exfil",
        description="Agent retrieves memory context then sends data externally",
        steps=[
            {
                "skill": "memory_read",
                "command_match": r".*",
            },
            {
                "skill": "secure_exec",
                "command_match": r"\b(curl|wget|nc|ncat|aws\s+s3|gcloud|az\s+storage)\b.*(-d|--data|--upload|cp|mv)",
            },
        ],
        window_seconds=180,
        min_steps_to_alert=2,
        score=0.85,
    ),
]


class BehavioralChainDetector:
    """Detects multi-step attack patterns from session action history."""

    def __init__(self, patterns: Optional[List[ChainPattern]] = None):
        self._patterns = patterns or CHAIN_PATTERNS

    def check(self, context: "SessionContext") -> Optional[ChainAlert]:
        """Check the session's completed action history against chain patterns."""
        now = time.time()

        for chain in self._patterns:
            alert = self._match_chain(chain, context.action_history, now)
            if alert:
                return alert

        return None

    def pre_check(
        self,
        skill_name: str,
        params: Dict[str, Any],
        context: "SessionContext",
    ) -> Optional[ChainAlert]:
        """Predict if this action + history would form a dangerous chain."""
        # Create a hypothetical action entry
        hypothetical = {
            "skill": skill_name,
            "params_summary": params,
            "status": "allowed",
            "timestamp": time.time(),
        }
        history_plus = context.action_history + [hypothetical]

        now = time.time()
        for chain in self._patterns:
            alert = self._match_chain(chain, history_plus, now)
            if alert and alert.score >= 0.8:
                return alert

        return None

    def _match_chain(
        self,
        chain: ChainPattern,
        history: List[Dict],
        now: float,
    ) -> Optional[ChainAlert]:
        """Check if action history matches a chain pattern."""
        cutoff = now - chain.window_seconds
        recent = [a for a in history if a.get("timestamp", 0) >= cutoff]

        if not recent:
            return None

        # Handle count-based patterns (bulk access)
        if len(chain.steps) == 1 and "count_threshold" in chain.steps[0]:
            step = chain.steps[0]
            matching = [
                a
                for a in recent
                if a.get("skill") == step["skill"]
            ]
            if len(matching) >= step["count_threshold"]:
                return ChainAlert(
                    pattern=chain.name,
                    score=chain.score,
                    actions=matching[-5:],
                    description=chain.description,
                )
            return None

        # Sequence matching — find ordered matches for each step
        matched_actions = []
        step_idx = 0

        for action in recent:
            if step_idx >= len(chain.steps):
                break

            step = chain.steps[step_idx]

            if self._action_matches_step(action, step):
                matched_actions.append(action)
                step_idx += 1

        if len(matched_actions) >= chain.min_steps_to_alert:
            return ChainAlert(
                pattern=chain.name,
                score=chain.score,
                actions=matched_actions,
                description=chain.description,
            )

        return None

    def _action_matches_step(self, action: Dict, step: Dict) -> bool:
        """Check if a single action matches a chain step definition."""
        if action.get("skill") != step.get("skill"):
            return False

        # Status matching (e.g., only match blocked prompts)
        if "status_match" in step:
            if action.get("status") != step["status_match"]:
                return False

        params = action.get("params_summary", {})

        # Path matching
        if "path_match" in step:
            path = params.get("path", "") or params.get("file_path", "")
            if not re.search(step["path_match"], path, re.IGNORECASE):
                return False

        # Command matching
        if "command_match" in step:
            command = params.get("command", "")
            if not re.search(step["command_match"], command, re.IGNORECASE):
                return False

        return True
