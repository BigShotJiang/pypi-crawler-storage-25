"""Policy engine — evaluates actions against session policy + chain detection."""

from dataclasses import dataclass
from typing import Any, Dict, Optional

from policy.audit import AuditTrail
from policy.chain_detector import BehavioralChainDetector
from policy.session import SessionManager


@dataclass
class PolicyDecision:
    allowed: bool
    reason: Optional[str] = None
    rule_name: Optional[str] = None


class PolicyEngine:
    """Embeddable policy engine. No external server required.

    Evaluates every skill invocation against:
    1. Session skill allowlist
    2. Path restrictions (deny overrides allow)
    3. Command restrictions
    4. Session expiry
    5. Rate limiting
    6. Behavioral chain pre-scoring
    """

    def __init__(
        self,
        session_manager: Optional[SessionManager] = None,
        chain_detector: Optional[BehavioralChainDetector] = None,
        audit: Optional[AuditTrail] = None,
    ):
        self.session_mgr = session_manager or SessionManager()
        self.chain_detector = chain_detector or BehavioralChainDetector()
        self.audit = audit or AuditTrail()

    def evaluate(
        self,
        skill_name: str,
        params: Dict[str, Any],
        context: "SessionContext",
    ) -> PolicyDecision:
        session_policy = self.session_mgr.get_policy(context.session_id)

        # 1. Session expiry
        if session_policy.is_expired():
            return PolicyDecision(
                False, "Session expired", "session_expired"
            )

        # 2. Skill allowlist
        if not session_policy.is_skill_allowed(skill_name):
            return PolicyDecision(
                False,
                f"Skill '{skill_name}' not in session scope",
                "session_skill_allowlist",
            )

        # 3. Path restrictions
        path = params.get("path") or params.get("file_path")
        if path and not session_policy.is_path_allowed(path):
            return PolicyDecision(
                False,
                f"Path '{path}' outside session scope",
                "session_path_restriction",
            )

        # 4. Command restrictions
        command = params.get("command")
        if command and not session_policy.is_command_allowed(command):
            return PolicyDecision(
                False,
                "Command pattern not in session scope",
                "session_command_restriction",
            )

        # 5. Rate limiting
        import time

        now = time.time()
        recent_actions = [
            a
            for a in context.action_history
            if now - a.get("timestamp", 0) < 60
        ]
        if len(recent_actions) >= session_policy.max_actions_per_minute:
            return PolicyDecision(
                False,
                f"Rate limit exceeded ({session_policy.max_actions_per_minute}/min)",
                "rate_limit",
            )

        # 6. Behavioral chain pre-check
        chain_alert = self.chain_detector.pre_check(skill_name, params, context)
        if chain_alert and chain_alert.score >= 0.8:
            return PolicyDecision(
                False,
                f"Action sequence flagged: {chain_alert.pattern} — {chain_alert.description}",
                "behavioral_chain",
            )

        return PolicyDecision(True)
