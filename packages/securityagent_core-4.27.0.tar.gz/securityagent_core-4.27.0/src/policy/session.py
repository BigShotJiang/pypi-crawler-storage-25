"""Per-session least privilege policies."""

import fnmatch
import re
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

# Default skill set — all skills allowed unless explicitly restricted
_DEFAULT_SKILLS = frozenset(
    {
        "secure_read",
        "secure_exec",
        "check_policy",
        "analyze_prompt",
        "scan_output",
        "get_session_policy",
        "audit_log",
        "token_optimize",
        "compliance_report",
    }
)


@dataclass
class SessionPolicy:
    """Defines what an agent session is allowed to do."""

    session_id: str = ""
    allowed_skills: Set[str] = field(default_factory=lambda: set(_DEFAULT_SKILLS))
    allowed_path_patterns: List[str] = field(default_factory=lambda: ["**"])
    denied_path_patterns: List[str] = field(default_factory=list)
    allowed_command_patterns: List[str] = field(default_factory=lambda: ["*"])
    denied_command_patterns: List[str] = field(default_factory=list)
    max_actions_per_minute: int = 60
    expires_at: Optional[float] = None
    created_at: float = field(default_factory=time.time)

    def is_skill_allowed(self, skill_name: str) -> bool:
        return skill_name in self.allowed_skills

    def is_path_allowed(self, path: str) -> bool:
        # Deny overrides allow
        for pattern in self.denied_path_patterns:
            if fnmatch.fnmatch(path, pattern):
                return False
        if not self.allowed_path_patterns:
            return True
        return any(
            fnmatch.fnmatch(path, pattern) for pattern in self.allowed_path_patterns
        )

    def is_command_allowed(self, command: str) -> bool:
        for pattern in self.denied_command_patterns:
            if re.search(pattern, command, re.IGNORECASE):
                return False
        return True

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at


class SessionManager:
    """Manages per-session policies. Embeddable, no external store needed."""

    def __init__(self):
        self._sessions: Dict[str, SessionPolicy] = {}

    def create_session(
        self,
        session_id: str,
        allowed_skills: Optional[Set[str]] = None,
        allowed_path_patterns: Optional[List[str]] = None,
        denied_path_patterns: Optional[List[str]] = None,
        denied_command_patterns: Optional[List[str]] = None,
        max_actions_per_minute: int = 60,
        ttl_seconds: Optional[int] = None,
    ) -> SessionPolicy:
        policy = SessionPolicy(
            session_id=session_id,
            allowed_skills=allowed_skills or set(_DEFAULT_SKILLS),
            allowed_path_patterns=allowed_path_patterns or ["**"],
            denied_path_patterns=denied_path_patterns or [],
            denied_command_patterns=denied_command_patterns or [],
            max_actions_per_minute=max_actions_per_minute,
            expires_at=(time.time() + ttl_seconds) if ttl_seconds else None,
        )
        self._sessions[session_id] = policy
        return policy

    def get_policy(self, session_id: str) -> SessionPolicy:
        if session_id not in self._sessions:
            self._sessions[session_id] = SessionPolicy(session_id=session_id)
        return self._sessions[session_id]

    def revoke_session(self, session_id: str):
        self._sessions.pop(session_id, None)
