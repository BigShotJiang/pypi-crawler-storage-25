"""Bridge to Obsidian Memory Map for cross-session policy context."""

import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_VAULT_PATH = Path(__file__).resolve().parent.parent / "obsidianMemory" / "ObsidianVault"


class MemoryBridge:
    """Reads/writes session data from/to the Obsidian vault."""

    def __init__(self, vault_path: Optional[Path] = None):
        self._vault = vault_path or _VAULT_PATH

    @property
    def daily_logs_dir(self) -> Path:
        return self._vault / "daily-logs"

    def get_recent_sessions(self, days: int = 7) -> List[Dict]:
        """Read daily logs and extract session summaries."""
        logs_dir = self.daily_logs_dir
        if not logs_dir.exists():
            return []

        sessions = []
        today = datetime.now()

        for i in range(days):
            from datetime import timedelta

            date = today - timedelta(days=i)
            log_file = logs_dir / f"{date.strftime('%Y-%m-%d')}.md"
            if log_file.exists():
                try:
                    content = log_file.read_text()
                    sessions.append(
                        {
                            "date": date.strftime("%Y-%m-%d"),
                            "content": content[:2000],
                            "file": str(log_file),
                        }
                    )
                except OSError:
                    pass

        return sessions

    def get_agent_reputation(self, agent_id: str) -> Dict:
        """Check historical behavior of an agent across audit logs."""
        audit_file = Path.home() / ".securityagent" / "skills_audit.jsonl"
        if not audit_file.exists():
            return {"agent_id": agent_id, "total_actions": 0, "blocked_actions": 0}

        total = 0
        blocked = 0
        skills_used = set()

        try:
            with open(audit_file) as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                    except (json.JSONDecodeError, ValueError):
                        continue
                    if entry.get("agent_id") != agent_id:
                        continue
                    total += 1
                    if entry.get("status") == "blocked":
                        blocked += 1
                    skills_used.add(entry.get("skill", "unknown"))
        except OSError:
            pass

        return {
            "agent_id": agent_id,
            "total_actions": total,
            "blocked_actions": blocked,
            "block_rate": blocked / total if total > 0 else 0.0,
            "skills_used": sorted(skills_used),
        }

    def write_session_summary(self, context: "SessionContext"):
        """Write session summary to daily log for cross-session memory."""
        logs_dir = self.daily_logs_dir
        if not logs_dir.exists():
            try:
                logs_dir.mkdir(parents=True, exist_ok=True)
            except OSError:
                return

        today = datetime.now().strftime("%Y-%m-%d")
        log_file = logs_dir / f"{today}.md"

        total = len(context.action_history)
        blocked = sum(
            1 for a in context.action_history if a.get("status") == "blocked"
        )
        skills = set(a.get("skill", "?") for a in context.action_history)

        summary = (
            f"\n## Session {context.session_id}\n"
            f"- **Agent**: {context.agent_id} ({context.agent_type})\n"
            f"- **Trace**: {context.trace_id}\n"
            f"- **Actions**: {total} total, {blocked} blocked\n"
            f"- **Skills**: {', '.join(sorted(skills))}\n"
            f"- **Time**: {datetime.now().strftime('%H:%M:%S')}\n"
        )

        try:
            with open(log_file, "a") as f:
                f.write(summary)
        except OSError as exc:
            logger.warning("Failed to write session summary: %s", exc)
