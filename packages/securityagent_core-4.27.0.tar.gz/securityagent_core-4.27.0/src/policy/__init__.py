"""Policy engine for per-session least privilege and behavioral chain detection."""
