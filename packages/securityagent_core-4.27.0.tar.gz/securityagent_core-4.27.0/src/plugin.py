#!/usr/bin/env python3
"""
SecurityAgent DLP plugin — standalone binary entry point.

CLI-compatible with scripts/secagent_check.py.  Built into a single
binary via PyInstaller for distribution without Python dependencies.

Usage:
    plugin <file_path> [--offset N] [--limit N]
    plugin --exec "<command>"
    plugin --prompt "<prompt_text>"
    plugin --scan-output          (reads stdin)
    plugin --version

Exit codes:
    0  — clean; content/result on stdout
    1  — BLOCKED; reason JSON on stderr
    2  — I/O or argument error; message on stderr
"""

import argparse
import json
import re
import shlex
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Force-import modules that PyInstaller cannot discover automatically.
# text_extractor.py imports these lazily inside functions (_extract_pdf,
# _extract_xlsx, _extract_docx).  Importing them here at the top level
# ensures PyInstaller bundles them into the frozen binary.
# ---------------------------------------------------------------------------
import pypdf  # noqa: F401
import openpyxl  # noqa: F401
import docx  # noqa: F401

from endpoint_agent.secure_fs import ConfidentialAccessError, SecureFileSystem

__version__ = "3.0.0"


# ---------------------------------------------------------------------------
# Exec-level DLP guard
# ---------------------------------------------------------------------------


def validate_exec(command: str) -> tuple:
    """Pure validation — no sys.exit(), no I/O.

    Returns (blocked: bool, reason: str | None, patterns: list[str] | None).
    """
    # ── Layer 1: command-shape rules ──────────────────────────────────────
    # Each entry: (compiled regex, human-readable label)
    SHAPE_RULES: list[tuple[re.Pattern, str]] = [
        # Reading dotfiles / hidden files directly
        (
            re.compile(
                r'\b(cat|head|tail|less|more|tac|nl|bat|view)\s+["\']?~/?\.'
                r'|<\s*["\']?~\/?\.',
                re.IGNORECASE,
            ),
            "dotfile_read",
        ),
        # Reading canonical sensitive filenames
        (
            re.compile(
                r"\b(cat|head|tail|less|more|tac|nl|bat|strings|xxd|hexdump|od)\s+"
                r".*\b(\.env|\.pem|\.key|\.pfx|\.p12|\.jks|credentials|id_rsa|"
                r"id_ecdsa|id_ed25519|id_dsa|api_key|apikey|secret|token|"
                r"passwd|shadow|sudoers|htpasswd|auth\.json|netrc)\b",
                re.IGNORECASE,
            ),
            "sensitive_file_read",
        ),
        # grep / awk / sed extracting secrets from files
        (
            re.compile(
                r"\b(grep|awk|sed|rg|ag)\b.*\b(password|passwd|secret|api.?key|"
                r"token|credential|private.?key)\b.*(/|\./|~/)",
                re.IGNORECASE,
            ),
            "secret_grep",
        ),
        # Dumping environment variables (env exfil)
        (re.compile(r"(?<!\w)(env|printenv|set)\b(?!\s*=)", re.IGNORECASE), "env_dump"),
        (
            re.compile(
                r"\becho\s+\$(?![\?#])", re.IGNORECASE  # echo $VAR but not $? or $#
            ),
            "env_var_echo",
        ),
        (
            re.compile(
                r"\$\{?(AWS_|GCP_|AZURE_|OPENAI_|ANTHROPIC_|GEMINI_|SECRET_|"
                r"API_KEY|TOKEN|PASSWORD|PASSWD)\b",
                re.IGNORECASE,
            ),
            "env_var_access",
        ),
        # /proc filesystem — process environment reads
        (re.compile(r"/proc/\d+/environ", re.IGNORECASE), "proc_environ_read"),
        (re.compile(r"/proc/self/environ", re.IGNORECASE), "proc_environ_read"),
        # Python / Ruby / Node one-liners reading files
        (
            re.compile(
                r"\b(python\d?|ruby|node|perl)\s+.*-c\s+.*open\s*\(", re.IGNORECASE
            ),
            "scripted_file_read",
        ),
        (
            re.compile(
                r"\b(python\d?|ruby|node|perl)\s+.*-e\s+.*open\s*\(", re.IGNORECASE
            ),
            "scripted_file_read",
        ),
        # Outbound data exfiltration via curl / wget / nc
        (
            re.compile(
                r"\b(curl|wget)\b.*\s(-d|--data|--data-binary|--data-raw|"
                r"-F|--form|--upload-file|-T)\b",
                re.IGNORECASE,
            ),
            "potential_exfil_upload",
        ),
        (re.compile(r"\b(nc|ncat|netcat|socat)\b", re.IGNORECASE), "raw_socket_tool"),
        # SSH agent / key forwarding tricks
        (
            re.compile(r"\bssh-add\b|\bssh-keygen\b.*-y\b", re.IGNORECASE),
            "ssh_key_operation",
        ),
        # Homebrew / pip installs of known spy-ware agent names
        (
            re.compile(
                r"\b(pip|pip3|npm|yarn|brew)\s+install\b.*\b"
                r"(keylogger|capture|exfil|harvest|scrape)\b",
                re.IGNORECASE,
            ),
            "suspicious_install",
        ),
        # Redirecting secret-ish output to a file or pipe to curl/nc
        (
            re.compile(
                r"(password|passwd|secret|api.?key|token|credential)"
                r".*\|\s*(curl|wget|nc|socat)",
                re.IGNORECASE,
            ),
            "secret_pipe_exfil",
        ),
        # Cloud CLI uploads — aws s3 cp/sync, gcloud storage cp, az storage blob upload
        (
            re.compile(
                r"\baws\s+s3\s+(cp|sync|mv)\b",
                re.IGNORECASE,
            ),
            "cloud_cli_s3_upload",
        ),
        (
            re.compile(
                r"\bgcloud\s+storage\s+(cp|rsync)\b",
                re.IGNORECASE,
            ),
            "cloud_cli_gcs_upload",
        ),
        (
            re.compile(
                r"\baz\s+storage\s+blob\s+upload\b",
                re.IGNORECASE,
            ),
            "cloud_cli_azure_upload",
        ),
        # Base64 / encoding-based exfiltration (encode then POST)
        (
            re.compile(
                r"\bbase64\b.*\|\s*(curl|wget|nc)",
                re.IGNORECASE,
            ),
            "encoded_exfil",
        ),
        # tar/zip followed by upload — archive-then-exfil pattern
        (
            re.compile(
                r"\b(tar|zip|gzip|bzip2)\b.*\|\s*(curl|wget|nc|aws|gcloud|az)\b",
                re.IGNORECASE,
            ),
            "archive_pipe_exfil",
        ),
    ]

    for pattern, label in SHAPE_RULES:
        if pattern.search(command):
            return (True, f"exec command matches sensitive pattern: {label}", [label])

    # ── Layer 2: DLP content scan on file-path-like tokens ────────────────
    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = command.split()

    alerts: list = []

    def on_alert(**kw):
        alerts.append(kw)

    fs = SecureFileSystem(alert_callback=on_alert)

    for token in tokens:
        if not (
            token.startswith("/")
            or token.startswith("~/")
            or token.startswith("./")
            or token.startswith("../")
        ):
            continue
        expanded = str(Path(token.replace("~", str(Path.home()))).resolve())
        try:
            blocked, reason = fs._is_path_blocked(expanded)
            if blocked:
                return (True, f"exec references blocked path: {expanded}", [reason])
        except Exception:
            pass  # Best-effort; don't crash the gate

    return (False, None, None)


def check_exec(command: str) -> None:
    """CLI wrapper — calls validate_exec() then exits with code 0 or 1."""
    blocked, reason, patterns = validate_exec(command)
    if blocked:
        print(
            json.dumps({"blocked": True, "reason": reason, "patterns": patterns}),
            file=sys.stderr,
        )
        sys.exit(1)
    sys.exit(0)


# ---------------------------------------------------------------------------
# Prompt intent analysis
# ---------------------------------------------------------------------------


def validate_prompt(prompt_text: str) -> dict:
    """Pure validation — returns PromptGuard result dict, no sys.exit()."""
    alerts: list = []

    def on_alert(**kw):
        alerts.append(kw)

    from endpoint_agent.scanners.prompt_guard import PromptGuard

    guard = PromptGuard(alert_callback=on_alert)
    return guard.analyze(prompt_text)


def check_prompt(prompt_text: str) -> None:
    """CLI wrapper — calls validate_prompt() then exits with code 0 or 1."""
    result = validate_prompt(prompt_text)

    if result["should_block"]:
        print(
            json.dumps(
                {
                    "blocked": True,
                    "reason": f"prompt classified as high-risk: {', '.join(result['intent_categories'])}",
                    "risk_score": result["risk_score"],
                    "risk_level": result["risk_level"],
                    "intent_categories": result["intent_categories"],
                    "evasion_flags": result["evasion_flags"],
                }
            ),
            file=sys.stderr,
        )
        sys.exit(1)

    print(json.dumps(result))
    sys.exit(0)


# ---------------------------------------------------------------------------
# Exec output DLP scanning
# ---------------------------------------------------------------------------


def _redact_output(content: str, findings: list) -> str:
    """Replace sensitive matches in output with [REDACTED]."""
    from endpoint_agent.config.settings import CREDENTIAL_PATTERNS, DLP_PII_PATTERNS

    all_patterns: dict = {}
    all_patterns.update(DLP_PII_PATTERNS)
    all_patterns.update(CREDENTIAL_PATTERNS)

    redacted = content
    for finding in findings:
        pattern_name = finding["pattern"]
        if pattern_name in all_patterns:
            compiled = re.compile(all_patterns[pattern_name])
            redacted = compiled.sub(f"[REDACTED:{pattern_name}]", redacted)

    return redacted


def validate_output(content: str) -> tuple:
    """Pure validation — returns (redacted_content, findings), no sys.exit()."""
    alerts: list = []

    def on_alert(**kw):
        alerts.append(kw)

    from endpoint_agent.scanners.dlp_scanner import DLPScanner

    scanner = DLPScanner(alert_callback=on_alert)
    findings = scanner.scan_content(content, source="exec_output")

    if not findings:
        return (content, [])

    redacted = _redact_output(content, findings)
    return (redacted, findings)


def scan_exec_output() -> None:
    """CLI wrapper — calls validate_output() then exits with code 0 or 1."""
    content = sys.stdin.read()
    redacted, findings = validate_output(content)

    if not findings:
        sys.stdout.write(content)
        sys.exit(0)

    sys.stdout.write(redacted)
    print(
        json.dumps(
            {
                "blocked": True,
                "reason": "exec output contains sensitive data",
                "finding_count": len(findings),
                "findings": [
                    {"pattern": f["pattern"], "type": f["type"], "line": f["line"]}
                    for f in findings[:10]
                ],
            }
        ),
        file=sys.stderr,
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="SecurityAgent DLP plugin — file read gate + exec DLP gate + prompt analyzer + output scanner"
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--exec",
        dest="exec_command",
        help="Exec command to validate",
    )
    parser.add_argument(
        "--prompt",
        dest="prompt_text",
        help="Analyze prompt text for sensitive data intent",
    )
    parser.add_argument(
        "--scan-output",
        dest="scan_output",
        action="store_true",
        help="Read stdin and scan for PII/credentials in command output",
    )
    parser.add_argument(
        "--skill",
        dest="skill_name",
        help="Invoke a named skill (e.g., secure_read, secure_exec, check_policy)",
    )
    parser.add_argument(
        "--params",
        dest="skill_params",
        default="{}",
        help="JSON parameters for --skill",
    )
    parser.add_argument(
        "--mcp-server",
        dest="mcp_server",
        action="store_true",
        help="Start MCP JSON-RPC server on stdio",
    )
    parser.add_argument("file_path", nargs="?", help="Path to the file to read")
    parser.add_argument(
        "--offset", type=int, default=None, help="Start line (1-indexed)"
    )
    parser.add_argument("--limit", type=int, default=None, help="Max lines to return")
    args = parser.parse_args()

    # ── MCP server mode ──────────────────────────────────────────────────
    if args.mcp_server:
        from skills.adapters.mcp_server import main as mcp_main

        mcp_main()
        return

    # ── Skill mode ────────────────────────────────────────────────────────
    if args.skill_name:
        from skills.adapters.cli_adapter import run_skill

        result = run_skill(args.skill_name, args.skill_params)
        sys.exit(result.exit_code)

    # ── Exec mode ─────────────────────────────────────────────────────────
    if args.exec_command:
        check_exec(args.exec_command)
        return

    # ── Prompt analysis mode ──────────────────────────────────────────────
    if args.prompt_text:
        check_prompt(args.prompt_text)
        return

    # ── Output scan mode ──────────────────────────────────────────────────
    if args.scan_output:
        scan_exec_output()
        return

    # ── File mode ─────────────────────────────────────────────────────────
    if not args.file_path:
        print(
            json.dumps(
                {
                    "error": "file_path required unless using --exec, --prompt, or --scan-output"
                }
            ),
            file=sys.stderr,
        )
        sys.exit(2)

    alerts: list = []

    def on_alert(**kw):
        alerts.append(kw)

    fs = SecureFileSystem(alert_callback=on_alert)

    try:
        content = fs.secure_read(args.file_path)
    except ConfidentialAccessError as exc:
        reason = str(exc)
        findings_summary = []
        for f in exc.findings[:5]:
            findings_summary.append(f.get("pattern", "unknown"))

        print(
            json.dumps(
                {
                    "blocked": True,
                    "path": exc.path,
                    "reason": reason,
                    "patterns": findings_summary,
                }
            ),
            file=sys.stderr,
        )
        sys.exit(1)

    except (OSError, PermissionError) as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        sys.exit(2)

    # Apply offset / limit (line-based, same as OpenClaw's native read)
    if args.offset is not None or args.limit is not None:
        lines = content.splitlines(keepends=True)
        start = (args.offset - 1) if args.offset else 0
        end = (start + args.limit) if args.limit else len(lines)
        content = "".join(lines[start:end])

    sys.stdout.write(content)
    sys.exit(0)


if __name__ == "__main__":
    main()
