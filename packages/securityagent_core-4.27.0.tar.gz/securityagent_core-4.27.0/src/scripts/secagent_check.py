#!/usr/bin/env python3
"""
SecurityAgent file read gate + prompt analyzer + output scanner.

Usage:
    secagent_check.py <file_path> [--offset N] [--limit N]
    secagent_check.py --exec "<command>"
    secagent_check.py --prompt "<prompt_text>"
    secagent_check.py --scan-output          (reads stdin)

Exit codes:
    0  — clean; content/result on stdout
    1  — BLOCKED; reason on stderr as JSON
    2  — I/O or argument error; message on stderr
"""

import argparse
import json
import os
import sys

# Locate SecurityAgent root relative to this script
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
sys.path.insert(0, _ROOT)

from endpoint_agent.secure_fs import ConfidentialAccessError, SecureFileSystem
from endpoint_agent.trial_manager import TrialManager

# ---------------------------------------------------------------------------
# Exec-level DLP guard
# ---------------------------------------------------------------------------


def check_exec(command: str) -> None:
    """
    Validate a shell command against DLP rules before execution.

    Checks two layers:
      1. Regex patterns that flag dangerous command shapes (file reads of
         sensitive paths, env dumps, potential exfiltration vectors, etc.)
      2. DLP content scan on every token that looks like a file path, so
         that inline heredocs or Python -c snippets with PII are also caught.

    Exit codes (matches file-read gate):
      0 — command is clean, caller may proceed
      1 — command BLOCKED, reason on stderr as JSON
    """
    import re

    # ── Layer 1: command-shape rules ──────────────────────────────────────
    # Each entry: (compiled regex, human-readable label)
    SHAPE_RULES: list[tuple[re.Pattern, str]] = [
        # Reading dotfiles / hidden files directly
        (
            re.compile(
                r'\b(cat|head|tail|less|more|tac|nl|bat|view)\s+["\']?~/?\.'
                r'|<\s*["\']?~\/?\.',
                re.IGNORECASE,
            ),
            "dotfile_read",
        ),
        # Reading canonical sensitive filenames
        (
            re.compile(
                r"\b(cat|head|tail|less|more|tac|nl|bat|strings|xxd|hexdump|od)\s+"
                r".*\b(\.env|\.pem|\.key|\.pfx|\.p12|\.jks|credentials|id_rsa|"
                r"id_ecdsa|id_ed25519|id_dsa|api_key|apikey|secret|token|"
                r"passwd|shadow|sudoers|htpasswd|auth\.json|netrc)\b",
                re.IGNORECASE,
            ),
            "sensitive_file_read",
        ),
        # grep / awk / sed extracting secrets from files
        (
            re.compile(
                r"\b(grep|awk|sed|rg|ag)\b.*\b(password|passwd|secret|api.?key|"
                r"token|credential|private.?key)\b.*(/|\./|~/)",
                re.IGNORECASE,
            ),
            "secret_grep",
        ),
        # Dumping environment variables (env exfil)
        (re.compile(r"(?<!\w)(env|printenv|set)\b(?!\s*=)", re.IGNORECASE), "env_dump"),
        (
            re.compile(
                r"\becho\s+\$(?![\?#])", re.IGNORECASE  # echo $VAR but not $? or $#
            ),
            "env_var_echo",
        ),
        (
            re.compile(
                r"\$\{?(AWS_|GCP_|AZURE_|OPENAI_|ANTHROPIC_|GEMINI_|SECRET_|"
                r"API_KEY|TOKEN|PASSWORD|PASSWD)\b",
                re.IGNORECASE,
            ),
            "env_var_access",
        ),
        # /proc filesystem — process environment reads
        (re.compile(r"/proc/\d+/environ", re.IGNORECASE), "proc_environ_read"),
        (re.compile(r"/proc/self/environ", re.IGNORECASE), "proc_environ_read"),
        # Python / Ruby / Node one-liners reading files
        (
            re.compile(
                r"\b(python\d?|ruby|node|perl)\s+.*-c\s+.*open\s*\(", re.IGNORECASE
            ),
            "scripted_file_read",
        ),
        (
            re.compile(
                r"\b(python\d?|ruby|node|perl)\s+.*-e\s+.*open\s*\(", re.IGNORECASE
            ),
            "scripted_file_read",
        ),
        # Outbound data exfiltration via curl / wget / nc
        (
            re.compile(
                r"\b(curl|wget)\b.*\s(-d|--data|--data-binary|--data-raw|"
                r"-F|--form|--upload-file|-T)\b",
                re.IGNORECASE,
            ),
            "potential_exfil_upload",
        ),
        (re.compile(r"\b(nc|ncat|netcat|socat)\b", re.IGNORECASE), "raw_socket_tool"),
        # SSH agent / key forwarding tricks
        (
            re.compile(r"\bssh-add\b|\bssh-keygen\b.*-y\b", re.IGNORECASE),
            "ssh_key_operation",
        ),
        # Homebrew / pip installs of known spy-ware agent names
        (
            re.compile(
                r"\b(pip|pip3|npm|yarn|brew)\s+install\b.*\b"
                r"(keylogger|capture|exfil|harvest|scrape)\b",
                re.IGNORECASE,
            ),
            "suspicious_install",
        ),
        # Redirecting secret-ish output to a file or pipe to curl/nc
        (
            re.compile(
                r"(password|passwd|secret|api.?key|token|credential)"
                r".*\|\s*(curl|wget|nc|socat)",
                re.IGNORECASE,
            ),
            "secret_pipe_exfil",
        ),
        # Cloud CLI uploads — aws s3 cp/sync, gcloud storage cp, az storage blob upload
        (
            re.compile(
                r"\baws\s+s3\s+(cp|sync|mv)\b",
                re.IGNORECASE,
            ),
            "cloud_cli_s3_upload",
        ),
        (
            re.compile(
                r"\bgcloud\s+storage\s+(cp|rsync)\b",
                re.IGNORECASE,
            ),
            "cloud_cli_gcs_upload",
        ),
        (
            re.compile(
                r"\baz\s+storage\s+blob\s+upload\b",
                re.IGNORECASE,
            ),
            "cloud_cli_azure_upload",
        ),
        # Base64 / encoding-based exfiltration (encode then POST)
        (
            re.compile(
                r"\bbase64\b.*\|\s*(curl|wget|nc)",
                re.IGNORECASE,
            ),
            "encoded_exfil",
        ),
        # tar/zip followed by upload — archive-then-exfil pattern
        (
            re.compile(
                r"\b(tar|zip|gzip|bzip2)\b.*\|\s*(curl|wget|nc|aws|gcloud|az)\b",
                re.IGNORECASE,
            ),
            "archive_pipe_exfil",
        ),
    ]

    for pattern, label in SHAPE_RULES:
        if pattern.search(command):
            print(
                json.dumps(
                    {
                        "blocked": True,
                        "reason": f"exec command matches sensitive pattern: {label}",
                        "patterns": [label],
                    }
                ),
                file=sys.stderr,
            )
            sys.exit(1)

    # ── Layer 2: DLP content scan on file-path-like tokens ────────────────
    # Tokenise by whitespace and shell separators; scan any token that looks
    # like a filesystem path through SecureFileSystem's filename gate.
    import shlex
    from pathlib import Path

    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = command.split()

    # Import lazily to avoid startup cost when shape rules suffice
    alerts: list = []

    def on_alert(**kw):
        alerts.append(kw)

    from endpoint_agent.secure_fs import ConfidentialAccessError, SecureFileSystem

    fs = SecureFileSystem(alert_callback=on_alert)

    for token in tokens:
        # Only inspect tokens that look like paths
        if not (
            token.startswith("/")
            or token.startswith("~/")
            or token.startswith("./")
            or token.startswith("../")
        ):
            continue
        expanded = str(Path(token.replace("~", str(Path.home()))).resolve())
        try:
            # Use the path-only (layer 1) check — don't open the file
            blocked, reason = fs._is_path_blocked(expanded)
            if blocked:
                print(
                    json.dumps(
                        {
                            "blocked": True,
                            "reason": f"exec references blocked path: {expanded}",
                            "patterns": [reason],
                        }
                    ),
                    file=sys.stderr,
                )
                sys.exit(1)
        except Exception:
            pass  # Best-effort; don't crash the gate

    sys.exit(0)


# ---------------------------------------------------------------------------
# Prompt intent analysis
# ---------------------------------------------------------------------------


def _extract_latest_user_message(prompt_text: str) -> str:
    """Extract only the latest user message from a conversation transcript.

    Claude Code's UserPromptSubmit hook passes the full conversation context
    in $PROMPT_TEXT, not just the user's new input.  Prior assistant output
    (security discussions, example attack strings, etc.) triggers false
    positives.  This function finds the last user turn so only direct user
    intent is analyzed.

    Heuristics (tried in order):
      1. Last block after "❯" prompt marker (Claude Code's user marker)
      2. Last block after "Original prompt:" label (hook retry context)
      3. Full text if no markers found (standalone usage)
    """
    # Try "Original prompt:" first — appears when hook includes blocked context
    op_marker = "Original prompt:"
    op_idx = prompt_text.rfind(op_marker)
    if op_idx != -1:
        after = prompt_text[op_idx + len(op_marker):].strip()
        # Take until the next section break or end
        for sep in ("\n\n⏺", "\n\n❯", "\n\n  ⏺"):
            end = after.find(sep)
            if end != -1:
                return after[:end].strip()
        return after.strip()

    # Try "❯" prompt marker
    marker_idx = prompt_text.rfind("❯")
    if marker_idx != -1:
        after = prompt_text[marker_idx + 1:].strip()
        # Take until next assistant output or end
        for sep in ("\n\n⏺", "\n⏺"):
            end = after.find(sep)
            if end != -1:
                return after[:end].strip()
        return after.strip()

    return prompt_text


def check_prompt(prompt_text: str) -> None:
    """Analyze a prompt for sensitive data access intent.

    Exit codes:
        0 — prompt is benign; result JSON on stdout
        1 — prompt is BLOCKED (high risk); reason JSON on stderr
    """
    # Extract only the latest user message to avoid false positives
    # from conversation history (assistant security discussions, etc.)
    user_message = _extract_latest_user_message(prompt_text)

    alerts: list = []

    def on_alert(**kw):
        alerts.append(kw)

    from endpoint_agent.scanners.prompt_guard import PromptGuard

    guard = PromptGuard(alert_callback=on_alert)
    result = guard.analyze(user_message)

    if result["should_block"]:
        print(
            json.dumps(
                {
                    "blocked": True,
                    "reason": f"prompt classified as high-risk: {', '.join(result['intent_categories'])}",
                    "risk_score": result["risk_score"],
                    "risk_level": result["risk_level"],
                    "intent_categories": result["intent_categories"],
                    "evasion_flags": result["evasion_flags"],
                }
            ),
            file=sys.stderr,
        )
        sys.exit(1)

    # Non-blocking result on stdout (exit 0)
    print(json.dumps(result))
    sys.exit(0)


# ---------------------------------------------------------------------------
# Exec output DLP scanning
# ---------------------------------------------------------------------------


def _redact_output(content: str, findings: list) -> str:
    """Replace sensitive matches in output with [REDACTED]."""
    import re as re_mod

    from endpoint_agent.config.settings import CREDENTIAL_PATTERNS, DLP_PII_PATTERNS

    all_patterns: dict = {}
    all_patterns.update(DLP_PII_PATTERNS)
    all_patterns.update(CREDENTIAL_PATTERNS)

    redacted = content
    for finding in findings:
        pattern_name = finding["pattern"]
        if pattern_name in all_patterns:
            compiled = re_mod.compile(all_patterns[pattern_name])
            redacted = compiled.sub(f"[REDACTED:{pattern_name}]", redacted)

    return redacted


def scan_exec_output() -> None:
    """Scan command output (from stdin) for PII/credentials.

    Exit codes:
        0 — output is clean; original content on stdout
        1 — output contains sensitive data; redacted on stdout, findings on stderr
    """
    content = sys.stdin.read()

    alerts: list = []

    def on_alert(**kw):
        alerts.append(kw)

    from endpoint_agent.scanners.dlp_scanner import DLPScanner

    scanner = DLPScanner(alert_callback=on_alert)
    findings = scanner.scan_content(content, source="exec_output")

    if not findings:
        sys.stdout.write(content)
        sys.exit(0)

    redacted = _redact_output(content, findings)
    sys.stdout.write(redacted)

    print(
        json.dumps(
            {
                "blocked": True,
                "reason": "exec output contains sensitive data",
                "finding_count": len(findings),
                "findings": [
                    {"pattern": f["pattern"], "type": f["type"], "line": f["line"]}
                    for f in findings[:10]
                ],
            }
        ),
        file=sys.stderr,
    )
    sys.exit(1)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="SecurityAgent file read gate + exec DLP gate + prompt analyzer + output scanner"
    )
    parser.add_argument(
        "--exec",
        dest="exec_command",
        help="Exec command to validate",
    )
    parser.add_argument(
        "--prompt",
        dest="prompt_text",
        help="Analyze prompt text for sensitive data intent",
    )
    parser.add_argument(
        "--scan-output",
        dest="scan_output",
        action="store_true",
        help="Read stdin and scan for PII/credentials in command output",
    )
    parser.add_argument("file_path", nargs="?", help="Path to the file to read")
    parser.add_argument(
        "--offset", type=int, default=None, help="Start line (1-indexed)"
    )
    parser.add_argument("--limit", type=int, default=None, help="Max lines to return")
    args = parser.parse_args()

    # Trial check — allow everything if expired
    _tm = TrialManager()
    _trial_active, _ = _tm.is_active()

    # ---------------------------------------------------------------------------
    # Exec mode
    # ---------------------------------------------------------------------------

    if args.exec_command:
        if not _trial_active:
            sys.exit(0)
        check_exec(args.exec_command)
        return

    # ---------------------------------------------------------------------------
    # Prompt analysis mode
    # ---------------------------------------------------------------------------

    if args.prompt_text:
        if not _trial_active:
            print(
                json.dumps(
                    {"risk_level": "none", "risk_score": 0.0, "should_block": False}
                )
            )
            sys.exit(0)
        check_prompt(args.prompt_text)
        return

    # ---------------------------------------------------------------------------
    # Output scan mode
    # ---------------------------------------------------------------------------

    if args.scan_output:
        if not _trial_active:
            sys.stdout.write(sys.stdin.read())
            sys.exit(0)
        scan_exec_output()
        return

    # ----------------------------------------------------------------
    # FILE MODE
    # ----------------------------------------------------------------

    if not args.file_path:

        print(
            json.dumps(
                {
                    "error": "file_path required unless using --exec, --prompt, or --scan-output"
                }
            ),
            file=sys.stderr,
        )

        sys.exit(2)

    alerts: list = []

    def on_alert(**kw):
        alerts.append(kw)

    fs = SecureFileSystem(alert_callback=on_alert, trial_active=_trial_active)

    try:
        content = fs.secure_read(args.file_path)
    except ConfidentialAccessError as exc:
        reason = str(exc)
        findings_summary = []
        for f in exc.findings[:5]:
            findings_summary.append(f.get("pattern", "unknown"))

        print(
            json.dumps(
                {
                    "blocked": True,
                    "path": exc.path,
                    "reason": reason,
                    "patterns": findings_summary,
                }
            ),
            file=sys.stderr,
        )
        sys.exit(1)

    except (OSError, PermissionError) as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        sys.exit(2)

    # Apply offset / limit (line-based, same as OpenClaw's native read)
    if args.offset is not None or args.limit is not None:
        lines = content.splitlines(keepends=True)
        start = (args.offset - 1) if args.offset else 0
        end = (start + args.limit) if args.limit else len(lines)
        content = "".join(lines[start:end])

    sys.stdout.write(content)
    sys.exit(0)


if __name__ == "__main__":
    main()
