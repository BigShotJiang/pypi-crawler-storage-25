"""
Main orchestrator for the endpoint security agent.

Initializes all monitors, scanners, and alert handlers,
then runs them concurrently using threads.
"""

import json
import logging
import signal
import threading
from typing import List, Optional

from endpoint_agent.alerting.alert_manager import AlertManager
from endpoint_agent.alerting.console_handler import console_alert_handler
from endpoint_agent.alerting.log_handler import create_log_handler
from endpoint_agent.alerting.webhook_handler import (
    create_sns_handler,
    create_webhook_handler,
)
from endpoint_agent.cloud_bridge.lockdown import CloudLockdown
from endpoint_agent.config.settings import (
    AWS_REGION,
    CLOUD_BRIDGE_ENABLED,
    SNS_ALERT_TOPIC_ARN,
)
from endpoint_agent.monitors.behavioral_monitor import BehavioralMonitor
from endpoint_agent.monitors.file_monitor import FileMonitor
from endpoint_agent.monitors.honeypot_monitor import HoneypotMonitor
from endpoint_agent.monitors.privilege_monitor import PrivilegeMonitor
from endpoint_agent.monitors.process_monitor import ProcessMonitor
from endpoint_agent.scanners.credential_scanner import CredentialScanner
from endpoint_agent.scanners.dlp_scanner import DLPScanner
from endpoint_agent.scanners.installation_scanner import InstallationScanner
from endpoint_agent.secure_fs import SecureFileSystem
from endpoint_agent.trial_manager import TrialManager

logger = logging.getLogger(__name__)


class SecurityEngine:
    """
    Main orchestrator for the endpoint security agent.

    Manages the lifecycle of all monitors, scanners, and alert handlers.
    """

    def __init__(
        self,
        watch_dirs: List[str],
        log_file: Optional[str] = None,
        webhook_url: Optional[str] = None,
    ):
        self.watch_dirs = watch_dirs
        self._threads: List[threading.Thread] = []
        self._shutdown = threading.Event()

        # Trial check — must be first
        self.trial_manager = TrialManager()
        self.trial_active, self._trial_message = self.trial_manager.is_active()

        # Alert manager - central dispatcher
        self.alert_manager = AlertManager()
        self.alert_manager.register_handler(console_alert_handler)
        self.alert_manager.register_handler(create_log_handler(log_file))

        if webhook_url:
            self.alert_manager.register_handler(create_webhook_handler(webhook_url))

        if CLOUD_BRIDGE_ENABLED and SNS_ALERT_TOPIC_ARN:
            self.alert_manager.register_handler(
                create_sns_handler(SNS_ALERT_TOPIC_ARN, AWS_REGION)
            )

        # Cloud bridge for lockdown actions
        self.cloud_bridge = CloudLockdown()

        # DLP scanner (must be created before file_monitor)
        self.dlp_scanner: DLPScanner = DLPScanner(
            alert_callback=self.alert_manager.alert,
            trial_active=self.trial_active,
        )

        # Monitors and scanners
        self.file_monitor = FileMonitor(
            watch_dirs=watch_dirs,
            alert_callback=self.alert_manager.alert,
            dlp_scanner=self.dlp_scanner,
            trial_active=self.trial_active,
        )
        self.process_monitor = ProcessMonitor(
            alert_callback=self.alert_manager.alert,
            trial_active=self.trial_active,
        )
        self.privilege_monitor = PrivilegeMonitor(
            alert_callback=self.alert_manager.alert,
            scan_dirs=watch_dirs,
            trial_active=self.trial_active,
        )
        self.credential_scanner = CredentialScanner(
            alert_callback=self.alert_manager.alert,
            trial_active=self.trial_active,
        )
        self.installation_scanner = InstallationScanner(
            alert_callback=self.alert_manager.alert,
            trial_active=self.trial_active,
        )

        # Secure filesystem
        self.secure_fs: SecureFileSystem = SecureFileSystem(
            alert_callback=self.alert_manager.alert,
            trial_active=self.trial_active,
        )

        # Behavioral detection monitor
        self.behavioral_monitor: BehavioralMonitor = BehavioralMonitor(
            alert_callback=self.alert_manager.alert,
            trial_active=self.trial_active,
        )

        # Honeypot monitor
        self.honeypot_monitor: HoneypotMonitor = HoneypotMonitor(
            alert_callback=self.alert_manager.alert,
            trial_active=self.trial_active,
        )

    def run_watch(self):
        """Start all monitors in continuous mode."""
        logger.info("Starting SecurityAgent endpoint agent...")
        print("=" * 60)
        print("SecurityAgent - Local Endpoint Security Monitor")
        print(f"Watching: {', '.join(self.watch_dirs)}")
        print(self._trial_message)
        print("=" * 60)

        if not self.trial_active:
            print("\n*** TRIAL EXPIRED - All protection is disabled ***")
            print("Press Ctrl+C to stop.\n")
            signal.signal(signal.SIGINT, self._signal_handler)
            signal.signal(signal.SIGTERM, self._signal_handler)
            self._shutdown.wait()
            return

        print(f"\n[1/5] Checking privileges...")
        self.privilege_monitor.check_current_privileges()

        print(f"[2/5] Scanning for existing threat installations...")
        installations = self.installation_scanner.scan()
        if installations:
            print(f"  Found {len(installations)} potential threat(s)")
        else:
            print("  No known malicious installations found")

        print(f"[3/5] Starting real-time monitors...")

        # Start file system monitor (watchdog runs its own thread internally)
        self.file_monitor.start()

        # Start process monitor in a thread
        process_thread = threading.Thread(
            target=self.process_monitor.start_continuous,
            daemon=True,
            name="process-monitor",
        )
        process_thread.start()
        self._threads.append(process_thread)

        print(f"[4/5] Starting behavioral detection...")
        behavioral_thread = threading.Thread(
            target=self.behavioral_monitor.start_continuous,
            daemon=True,
            name="behavioral-monitor",
        )
        behavioral_thread.start()
        self._threads.append(behavioral_thread)

        print(f"[5/5] Deploying honeypot traps...")
        honeypot_thread = threading.Thread(
            target=self.honeypot_monitor.start_continuous,
            daemon=True,
            name="honeypot-monitor",
        )
        honeypot_thread.start()
        self._threads.append(honeypot_thread)

        # Handle SIGINT/SIGTERM
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        print("\nAll monitors active. Press Ctrl+C to stop.\n")
        self._shutdown.wait()

    def run_scan(self, directories: List[str]):
        """One-shot scan mode."""
        print("=" * 60)
        print("SecurityAgent - One-Shot Security Scan")
        print(f"Scanning: {', '.join(directories)}")
        print(self._trial_message)
        print("=" * 60)

        if not self.trial_active:
            print("\n*** TRIAL EXPIRED - All scanning is disabled ***\n")
            return

        print("\n[1/4] Checking privileges...")
        elevated = self.privilege_monitor.check_current_privileges()
        if not elevated:
            print("  Running as normal user (good)")

        print("[2/4] Scanning for malicious agent installations...")
        installations = self.installation_scanner.scan()
        print(f"  Found {len(installations)} potential threat(s)")

        print(f"[3/5] Scanning for exposed credentials...")
        all_cred_findings = []
        for directory in directories:
            findings = self.credential_scanner.scan_directory(directory)
            all_cred_findings.extend(findings)
        print(f"  Found {len(all_cred_findings)} exposed credential(s)")

        print(f"[4/5] Running DLP content scan...")
        all_dlp_findings = []
        for directory in directories:
            for root, dirs, files in __import__("os").walk(directory):
                dirs[:] = [
                    d
                    for d in dirs
                    if d not in {"node_modules", ".git", "__pycache__", ".venv", "venv"}
                ]
                for fname in files:
                    full_path = __import__("os").path.join(root, fname)
                    dlp_findings = self.dlp_scanner.scan_file(full_path)
                    all_dlp_findings.extend(dlp_findings)
        print(f"  Found {len(all_dlp_findings)} DLP finding(s)")

        print(f"[5/5] Checking file permissions...")
        self.privilege_monitor.scan_dirs = directories
        perm_findings = self.privilege_monitor.scan_file_permissions()
        print(f"  Found {len(perm_findings)} insecure permission(s)")

        # Summary
        total_issues = len(installations) + len(all_cred_findings) + len(perm_findings)
        print("\n" + "=" * 60)
        if total_issues == 0:
            print("SCAN COMPLETE: No issues found")
        else:
            print(f"SCAN COMPLETE: {total_issues} issue(s) found")
            print("  Check ~/.securityagent/audit.log for details")
        print("=" * 60)

    def run_status(self) -> dict:
        """Show current security status."""
        print("=" * 60)
        print("SecurityAgent - Security Status")
        print(self._trial_message)
        print("=" * 60)

        if not self.trial_active:
            print("\n*** TRIAL EXPIRED - All protection is disabled ***\n")
            return {"trial_active": False}

        elevated = self.privilege_monitor.check_current_privileges()
        print(
            f"\nPrivilege level: {'ELEVATED (root/admin)' if elevated else 'Normal user'}"
        )

        print("\nScanning running processes...")
        threats = self.process_monitor.scan_once()
        if threats:
            print(f"  ALERT: {len(threats)} malicious process(es) detected!")
            for t in threats:
                print(
                    f"    - PID {t['pid']}: {t['name']} (matched: {t['matched_pattern']})"
                )
        else:
            print("  No malicious processes found")

        print("\nScanning for malicious installations...")
        installations = self.installation_scanner.scan()
        if installations:
            print(f"  ALERT: {len(installations)} installation(s) found!")
            for i in installations:
                print(
                    f"    - {i['type']}: {i['path']} (matched: {i['matched_pattern']})"
                )
        else:
            print("  No malicious installations found")

        print("=" * 60)

        return {
            "elevated_privileges": elevated,
            "active_threats": threats,
            "malicious_installations": installations,
        }

    def stop(self):
        """Gracefully stop all monitors."""
        print("\nShutting down endpoint agent...")
        self.file_monitor.stop()
        self.process_monitor.stop()
        self.behavioral_monitor.stop()
        self.honeypot_monitor.stop()
        self._shutdown.set()

    def _signal_handler(self, signum, frame):
        self.stop()
