"""
Central alert dispatcher.

All monitors and scanners call alert_callback(severity, event_type, details)
which routes through this manager to registered handlers.
"""

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List

from endpoint_agent.config.settings import ALERT_DEDUP_WINDOW_SECONDS

logger = logging.getLogger(__name__)


@dataclass
class SecurityAlert:
    """Represents a single security alert."""

    timestamp: float
    severity: str
    event_type: str
    details: Dict[str, Any]
    alert_id: str = ""

    def __post_init__(self):
        if not self.alert_id:
            self.alert_id = f"{self.event_type}-{int(self.timestamp * 1000)}"


class AlertManager:
    """Central alert dispatcher. Routes alerts to registered handlers."""

    def __init__(self):
        self._handlers: List[Callable[[SecurityAlert], None]] = []
        self._alert_history: List[SecurityAlert] = []
        self._recent_keys: Dict[str, float] = {}

    def register_handler(self, handler: Callable[[SecurityAlert], None]):
        """Register an alert handler (console, log file, webhook, etc.)."""
        self._handlers.append(handler)

    def alert(self, severity: str, event_type: str, details: Dict[str, Any]):
        """Create and dispatch an alert. This is the callback passed to all monitors."""
        dedup_key = f"{event_type}:{details.get('path', '')}:{details.get('pid', '')}"
        now = time.time()

        if dedup_key in self._recent_keys:
            if now - self._recent_keys[dedup_key] < ALERT_DEDUP_WINDOW_SECONDS:
                return
        self._recent_keys[dedup_key] = now

        alert_obj = SecurityAlert(
            timestamp=now,
            severity=severity,
            event_type=event_type,
            details=details,
        )
        self._alert_history.append(alert_obj)

        for handler in self._handlers:
            try:
                handler(alert_obj)
            except Exception:
                logger.exception("Alert handler failed for %s", event_type)

    def get_history(self) -> List[SecurityAlert]:
        """Return all alerts dispatched so far."""
        return list(self._alert_history)
