"""JSON-lines audit log handler for persistent alert storage."""

import json
import logging
import os
import time

from endpoint_agent.config.settings import DEFAULT_LOG_FILE

logger = logging.getLogger(__name__)


def create_log_handler(log_file=None):
    """Factory: returns a handler function that writes alerts to a JSON log file."""
    log_path = log_file or DEFAULT_LOG_FILE
    os.makedirs(os.path.dirname(log_path), exist_ok=True)

    def log_alert_handler(alert):
        entry = {
            "timestamp": time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(alert.timestamp)
            ),
            "severity": alert.severity,
            "event_type": alert.event_type,
            "details": alert.details,
            "alert_id": alert.alert_id,
        }
        try:
            with open(log_path, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except OSError:
            logger.error("Failed to write audit log to %s", log_path)

    return log_alert_handler
