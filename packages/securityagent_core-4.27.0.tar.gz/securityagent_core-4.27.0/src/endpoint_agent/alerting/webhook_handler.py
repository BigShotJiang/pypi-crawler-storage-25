"""
Webhook and AWS SNS alert handlers for cloud-side notification.

These are optional handlers - enabled via CLI flags or environment variables.
"""

import json
import logging
from urllib.error import URLError
from urllib.request import Request, urlopen

logger = logging.getLogger(__name__)


def create_webhook_handler(webhook_url: str):
    """Factory: returns a handler that POSTs alerts to a webhook URL."""

    def webhook_alert_handler(alert):
        payload = json.dumps(
            {
                "severity": alert.severity,
                "event_type": alert.event_type,
                "details": alert.details,
                "alert_id": alert.alert_id,
            }
        ).encode("utf-8")

        req = Request(
            webhook_url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(req, timeout=5) as resp:
                logger.debug("Webhook response: %d", resp.status)
        except (URLError, OSError):
            logger.warning("Failed to send webhook alert to %s", webhook_url)

    return webhook_alert_handler


def create_sns_handler(topic_arn: str, region: str = "us-east-1"):
    """Factory: returns a handler that publishes alerts to an AWS SNS topic."""

    def sns_alert_handler(alert):
        try:
            import boto3

            client = boto3.client("sns", region_name=region)
            client.publish(
                TopicArn=topic_arn,
                Subject=f"[{alert.severity}] {alert.event_type}"[:100],
                Message=json.dumps(
                    {
                        "source": "endpoint_agent",
                        "severity": alert.severity,
                        "event_type": alert.event_type,
                        "details": alert.details,
                        "alert_id": alert.alert_id,
                    },
                    indent=2,
                ),
            )
        except Exception:
            logger.warning("Failed to publish SNS alert to %s", topic_arn)

    return sns_alert_handler
