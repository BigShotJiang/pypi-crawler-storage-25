"""Console alert handler with ANSI color-coded output."""

import os
import sys
import time

# Enable ANSI escape codes on Windows 10+
if os.name == "nt":
    os.system("")

COLORS = {
    "CRITICAL": "\033[91m",  # Red
    "WARNING": "\033[93m",  # Yellow
    "INFO": "\033[94m",  # Blue
    "RESET": "\033[0m",
}


def console_alert_handler(alert):
    """Print alerts to the terminal with color coding."""
    color = COLORS.get(alert.severity, "")
    reset = COLORS["RESET"]
    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(alert.timestamp))
    print(
        f"{color}[{alert.severity}]{reset} {ts} | {alert.event_type} | {alert.details}",
        file=sys.stderr,
    )
