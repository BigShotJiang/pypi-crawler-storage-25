"""
10-day free trial manager with HMAC-signed, machine-bound storage.

The trial auto-activates on first run. After 10 days, is_active() returns
False and all SecurityAgent protection is gracefully disabled.

Storage: ~/.securityagent/.trial (JSON with HMAC signature)
Tamper resistance:
  - HMAC key derived from machine identifiers (hostname + MAC address)
  - Editing the timestamp invalidates the HMAC → treated as expired
  - Copying to another machine → different key → treated as expired
  - Deleting the file → new trial starts (acceptable trade-off)
"""

import datetime
import hashlib
import hmac as hmac_mod
import json
import logging
import os
import pathlib
import platform
import uuid

logger = logging.getLogger(__name__)

TRIAL_DAYS = 10
TRIAL_DIR = os.path.join(str(pathlib.Path.home()), ".securityagent")
TRIAL_FILE = os.path.join(TRIAL_DIR, ".trial")


class TrialManager:
    """Manages the 10-day free trial lifecycle."""

    def __init__(self):
        self._machine_key = self._derive_machine_key()

    @staticmethod
    def _derive_machine_key() -> bytes:
        """Derive an HMAC key from machine-specific identifiers."""
        raw = f"{platform.node()}:{uuid.getnode()}".encode()
        return hashlib.sha256(raw).digest()

    def _compute_hmac(self, activated_at: str) -> str:
        """Compute HMAC-SHA256 over the activation timestamp."""
        return hmac_mod.new(
            self._machine_key, activated_at.encode(), hashlib.sha256
        ).hexdigest()

    def _activate(self) -> str:
        """Create the trial file. Returns the ISO activation timestamp."""
        activated_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        mac = self._compute_hmac(activated_at)
        payload = json.dumps({"activated_at": activated_at, "hmac": mac})
        os.makedirs(TRIAL_DIR, exist_ok=True)
        with open(TRIAL_FILE, "w") as f:
            f.write(payload)
        return activated_at

    def _load(self):
        """Load and validate the trial file.

        Returns:
            (activated_at: str | None, valid: bool)
        """
        try:
            with open(TRIAL_FILE, "r") as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError, KeyError):
            return None, False

        stored_at = data.get("activated_at", "")
        stored_hmac = data.get("hmac", "")
        expected_hmac = self._compute_hmac(stored_at)

        if not hmac_mod.compare_digest(stored_hmac, expected_hmac):
            return stored_at, False

        return stored_at, True

    def is_active(self):
        """Check trial status. Auto-activates on first run.

        Returns:
            (active: bool, message: str)
        """
        activated_at, valid = self._load()

        if activated_at is None:
            activated_at = self._activate()
            valid = True

        if not valid:
            return False, (
                "SecurityAgent trial: license file is invalid or was "
                "transferred from another machine. All protection is "
                "disabled."
            )

        activation_dt = datetime.datetime.fromisoformat(activated_at)
        now = datetime.datetime.now(datetime.timezone.utc)
        elapsed = now - activation_dt
        remaining = datetime.timedelta(days=TRIAL_DAYS) - elapsed

        if remaining.total_seconds() <= 0:
            return False, (
                "SecurityAgent trial has expired after 10 days. "
                "All protection is disabled. "
                "Contact support for a license."
            )

        days_left = remaining.days
        hours_left = remaining.seconds // 3600
        if days_left > 0:
            return True, f"SecurityAgent trial: {days_left} day(s) remaining"
        return True, f"SecurityAgent trial: {hours_left} hour(s) remaining"

    @property
    def days_remaining(self) -> int:
        """Return days remaining, or 0 if expired/invalid."""
        activated_at, valid = self._load()
        if not valid or activated_at is None:
            return 0
        activation_dt = datetime.datetime.fromisoformat(activated_at)
        now = datetime.datetime.now(datetime.timezone.utc)
        remaining = datetime.timedelta(days=TRIAL_DAYS) - (now - activation_dt)
        return max(0, remaining.days)
