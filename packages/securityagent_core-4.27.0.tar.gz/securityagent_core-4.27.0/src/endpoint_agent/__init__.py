"""Local endpoint security agent for detecting malicious AI agents."""

__version__ = "2.1.0"
