"""Tests for the central alert dispatcher."""

import time

from endpoint_agent.alerting.alert_manager import AlertManager, SecurityAlert


class TestSecurityAlert:
    def test_auto_generates_alert_id(self):
        alert = SecurityAlert(
            timestamp=1000.0,
            severity="CRITICAL",
            event_type="test_event",
            details={"key": "value"},
        )
        assert alert.alert_id == "test_event-1000000"

    def test_preserves_explicit_alert_id(self):
        alert = SecurityAlert(
            timestamp=1000.0,
            severity="WARNING",
            event_type="test_event",
            details={},
            alert_id="custom-id",
        )
        assert alert.alert_id == "custom-id"


class TestAlertManager:
    def test_dispatches_to_registered_handler(self):
        received = []
        manager = AlertManager()
        manager.register_handler(lambda alert: received.append(alert))

        manager.alert("CRITICAL", "test_event", {"path": "/tmp/test"})

        assert len(received) == 1
        assert received[0].severity == "CRITICAL"
        assert received[0].event_type == "test_event"
        assert received[0].details["path"] == "/tmp/test"

    def test_dispatches_to_multiple_handlers(self):
        received_a = []
        received_b = []
        manager = AlertManager()
        manager.register_handler(lambda alert: received_a.append(alert))
        manager.register_handler(lambda alert: received_b.append(alert))

        manager.alert("WARNING", "test", {})

        assert len(received_a) == 1
        assert len(received_b) == 1

    def test_deduplicates_within_window(self):
        received = []
        manager = AlertManager()
        manager.register_handler(lambda alert: received.append(alert))

        manager.alert("CRITICAL", "same_event", {"path": "/tmp/x"})
        manager.alert("CRITICAL", "same_event", {"path": "/tmp/x"})

        assert len(received) == 1

    def test_allows_different_events(self):
        received = []
        manager = AlertManager()
        manager.register_handler(lambda alert: received.append(alert))

        manager.alert("CRITICAL", "event_a", {"path": "/tmp/a"})
        manager.alert("CRITICAL", "event_b", {"path": "/tmp/b"})

        assert len(received) == 2

    def test_get_history(self):
        manager = AlertManager()
        manager.register_handler(lambda alert: None)

        manager.alert("INFO", "event_1", {})
        manager.alert("WARNING", "event_2", {"path": "/x"})

        history = manager.get_history()
        assert len(history) == 2
        assert history[0].event_type == "event_1"
        assert history[1].event_type == "event_2"

    def test_handler_exception_does_not_break_dispatch(self):
        received = []
        manager = AlertManager()
        manager.register_handler(lambda alert: 1 / 0)  # Raises ZeroDivisionError
        manager.register_handler(lambda alert: received.append(alert))

        manager.alert("CRITICAL", "test", {})

        assert len(received) == 1
