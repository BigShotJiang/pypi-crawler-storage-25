"""
Tests for the 10-day free trial manager.

Covers activation, expiry, HMAC tamper detection, machine-binding,
and integration with SecureFileSystem and SecurityEngine.
"""

import datetime
import hashlib
import hmac as hmac_mod
import json
import os
from unittest.mock import patch

import pytest

from endpoint_agent.trial_manager import TRIAL_DAYS, TrialManager


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_trial_file(path, activated_at, machine_key):
    """Write a properly signed trial file."""
    mac = hmac_mod.new(machine_key, activated_at.encode(), hashlib.sha256).hexdigest()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump({"activated_at": activated_at, "hmac": mac}, f)


def _machine_key(node="testhost", mac=123456789):
    """Derive the same key TrialManager would use for given node+mac."""
    raw = f"{node}:{mac}".encode()
    return hashlib.sha256(raw).digest()


@pytest.fixture()
def trial_env(tmp_path, monkeypatch):
    """Patch TrialManager to use a temp directory and stable machine identity."""
    trial_dir = str(tmp_path / ".securityagent")
    trial_file = os.path.join(trial_dir, ".trial")

    monkeypatch.setattr("endpoint_agent.trial_manager.TRIAL_DIR", trial_dir)
    monkeypatch.setattr("endpoint_agent.trial_manager.TRIAL_FILE", trial_file)
    monkeypatch.setattr("platform.node", lambda: "testhost")
    monkeypatch.setattr("uuid.getnode", lambda: 123456789)

    return trial_dir, trial_file


# ---------------------------------------------------------------------------
# Unit tests — TrialManager
# ---------------------------------------------------------------------------


class TestTrialActivation:
    """First-run activation creates a valid trial file."""

    def test_first_run_creates_trial_file(self, trial_env):
        trial_dir, trial_file = trial_env
        assert not os.path.exists(trial_file)

        tm = TrialManager()
        active, msg = tm.is_active()

        assert active is True
        assert "remaining" in msg
        assert os.path.exists(trial_file)

        with open(trial_file) as f:
            data = json.load(f)
        assert "activated_at" in data
        assert "hmac" in data

    def test_first_run_shows_10_days(self, trial_env):
        tm = TrialManager()
        active, msg = tm.is_active()
        assert active is True
        # Should show 9 or 10 days depending on timing
        assert "day(s) remaining" in msg

    def test_subsequent_call_reuses_file(self, trial_env):
        _, trial_file = trial_env
        tm = TrialManager()
        tm.is_active()

        # Read file contents
        with open(trial_file) as f:
            first_data = json.load(f)

        # Second call should NOT overwrite
        active, _ = tm.is_active()
        assert active is True

        with open(trial_file) as f:
            second_data = json.load(f)

        assert first_data["activated_at"] == second_data["activated_at"]


class TestTrialExpiry:
    """Trial expires after TRIAL_DAYS."""

    def test_expired_trial_returns_false(self, trial_env):
        _, trial_file = trial_env
        key = _machine_key()

        expired_time = (
            datetime.datetime.now(datetime.timezone.utc)
            - datetime.timedelta(days=TRIAL_DAYS + 1)
        ).isoformat()
        _write_trial_file(trial_file, expired_time, key)

        tm = TrialManager()
        active, msg = tm.is_active()

        assert active is False
        assert "expired" in msg.lower()

    def test_exactly_at_expiry_returns_false(self, trial_env):
        _, trial_file = trial_env
        key = _machine_key()

        # Exactly TRIAL_DAYS ago + 1 second to be past
        expired_time = (
            datetime.datetime.now(datetime.timezone.utc)
            - datetime.timedelta(days=TRIAL_DAYS, seconds=1)
        ).isoformat()
        _write_trial_file(trial_file, expired_time, key)

        tm = TrialManager()
        active, _ = tm.is_active()
        assert active is False

    def test_last_day_shows_hours(self, trial_env):
        _, trial_file = trial_env
        key = _machine_key()

        # 9 days and 20 hours ago → 4 hours remaining
        activated = (
            datetime.datetime.now(datetime.timezone.utc)
            - datetime.timedelta(days=TRIAL_DAYS - 1, hours=20)
        ).isoformat()
        _write_trial_file(trial_file, activated, key)

        tm = TrialManager()
        active, msg = tm.is_active()

        assert active is True
        assert "hour(s) remaining" in msg

    def test_mid_trial_shows_days(self, trial_env):
        _, trial_file = trial_env
        key = _machine_key()

        activated = (
            datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=3)
        ).isoformat()
        _write_trial_file(trial_file, activated, key)

        tm = TrialManager()
        active, msg = tm.is_active()

        assert active is True
        assert "day(s) remaining" in msg


class TestTrialTamperDetection:
    """HMAC verification catches tampering."""

    def test_tampered_timestamp_detected(self, trial_env):
        _, trial_file = trial_env
        key = _machine_key()

        # Write valid file
        activated = datetime.datetime.now(datetime.timezone.utc).isoformat()
        _write_trial_file(trial_file, activated, key)

        # Tamper: change the timestamp but keep old HMAC
        with open(trial_file) as f:
            data = json.load(f)
        data["activated_at"] = (
            datetime.datetime.now(datetime.timezone.utc)
            - datetime.timedelta(days=0)  # reset to "just now"
        ).isoformat()
        with open(trial_file, "w") as f:
            json.dump(data, f)

        tm = TrialManager()
        active, msg = tm.is_active()
        assert active is False
        assert "invalid" in msg.lower()

    def test_tampered_hmac_detected(self, trial_env):
        _, trial_file = trial_env
        key = _machine_key()

        activated = datetime.datetime.now(datetime.timezone.utc).isoformat()
        _write_trial_file(trial_file, activated, key)

        # Tamper: change the HMAC
        with open(trial_file) as f:
            data = json.load(f)
        data["hmac"] = "deadbeef" * 8
        with open(trial_file, "w") as f:
            json.dump(data, f)

        tm = TrialManager()
        active, msg = tm.is_active()
        assert active is False
        assert "invalid" in msg.lower()

    def test_different_machine_invalidates(self, trial_env, monkeypatch):
        _, trial_file = trial_env
        key = _machine_key()

        activated = datetime.datetime.now(datetime.timezone.utc).isoformat()
        _write_trial_file(trial_file, activated, key)

        # Change machine identity
        monkeypatch.setattr("platform.node", lambda: "otherhost")

        tm = TrialManager()
        active, msg = tm.is_active()
        assert active is False
        assert "invalid" in msg.lower() or "transferred" in msg.lower()


class TestTrialFileEdgeCases:
    """Edge cases: deleted files, corrupt JSON, etc."""

    def test_deleted_file_starts_new_trial(self, trial_env):
        _, trial_file = trial_env

        tm = TrialManager()
        tm.is_active()
        assert os.path.exists(trial_file)

        # Delete and retry
        os.unlink(trial_file)
        active, msg = tm.is_active()
        assert active is True
        assert os.path.exists(trial_file)

    def test_corrupt_json_starts_new_trial(self, trial_env):
        trial_dir, trial_file = trial_env
        os.makedirs(trial_dir, exist_ok=True)
        with open(trial_file, "w") as f:
            f.write("not json at all {{{{")

        tm = TrialManager()
        active, msg = tm.is_active()
        assert active is True
        assert "remaining" in msg

    def test_empty_file_starts_new_trial(self, trial_env):
        trial_dir, trial_file = trial_env
        os.makedirs(trial_dir, exist_ok=True)
        with open(trial_file, "w") as f:
            f.write("")

        tm = TrialManager()
        active, msg = tm.is_active()
        assert active is True

    def test_missing_keys_starts_new_trial(self, trial_env):
        trial_dir, trial_file = trial_env
        os.makedirs(trial_dir, exist_ok=True)
        with open(trial_file, "w") as f:
            json.dump({"foo": "bar"}, f)

        tm = TrialManager()
        active, msg = tm.is_active()
        # Empty activated_at + wrong HMAC → treated as invalid
        assert active is False


class TestDaysRemaining:
    """days_remaining property."""

    def test_fresh_trial(self, trial_env):
        tm = TrialManager()
        tm.is_active()
        assert tm.days_remaining >= 9  # 9 or 10 depending on timing

    def test_mid_trial(self, trial_env):
        _, trial_file = trial_env
        key = _machine_key()
        activated = (
            datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=3)
        ).isoformat()
        _write_trial_file(trial_file, activated, key)

        tm = TrialManager()
        assert tm.days_remaining in (6, 7)  # depends on sub-day timing

    def test_expired(self, trial_env):
        _, trial_file = trial_env
        key = _machine_key()
        activated = (
            datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=15)
        ).isoformat()
        _write_trial_file(trial_file, activated, key)

        tm = TrialManager()
        assert tm.days_remaining == 0

    def test_no_file(self, trial_env):
        tm = TrialManager()
        # No file yet, days_remaining returns 0 (file not created until is_active)
        assert tm.days_remaining == 0


# ---------------------------------------------------------------------------
# Integration tests — SecureFileSystem with expired trial
# ---------------------------------------------------------------------------


class TestExpiredTrialSecureFS:
    """SecureFileSystem passes through when trial is expired."""

    def test_expired_trial_allows_env_file(self, tmp_path):
        """A .env file is readable when trial is expired."""
        from endpoint_agent.secure_fs import SecureFileSystem

        env_file = tmp_path / ".env"
        env_file.write_text("SECRET_KEY=abc123\n")

        alerts = []
        fs = SecureFileSystem(
            alert_callback=lambda **kw: alerts.append(kw),
            trial_active=False,
        )
        content = fs.secure_read(str(env_file))
        assert "SECRET_KEY" in content
        assert len(alerts) == 0

    def test_expired_trial_allows_ssh_key(self, tmp_path):
        """An SSH key file is readable when trial is expired."""
        from endpoint_agent.secure_fs import SecureFileSystem

        key_file = tmp_path / "id_rsa"
        key_file.write_text("-----BEGIN RSA PRIVATE KEY-----\nfakekey\n")

        fs = SecureFileSystem(
            alert_callback=lambda **kw: None,
            trial_active=False,
        )
        content = fs.secure_read(str(key_file))
        assert "PRIVATE KEY" in content

    def test_expired_trial_is_blocked_returns_false(self, tmp_path):
        """is_blocked returns (False, []) when trial expired."""
        from endpoint_agent.secure_fs import SecureFileSystem

        env_file = tmp_path / ".env"
        env_file.write_text("SECRET=value\n")

        fs = SecureFileSystem(
            alert_callback=lambda **kw: None,
            trial_active=False,
        )
        blocked, findings = fs.is_blocked(str(env_file))
        assert blocked is False
        assert findings == []

    def test_active_trial_blocks_env_file(self, tmp_path):
        """Normal blocking still works when trial is active."""
        from endpoint_agent.secure_fs import ConfidentialAccessError, SecureFileSystem

        env_file = tmp_path / ".env"
        env_file.write_text("SECRET_KEY=abc123\n")

        fs = SecureFileSystem(
            alert_callback=lambda **kw: None,
            trial_active=True,
        )
        with pytest.raises(ConfidentialAccessError):
            fs.secure_read(str(env_file))


# ---------------------------------------------------------------------------
# Integration tests — scanners/monitors with expired trial
# ---------------------------------------------------------------------------


class TestExpiredTrialComponents:
    """Components return empty/no-op when trial expired."""

    def test_dlp_scanner_returns_empty(self):
        from endpoint_agent.scanners.dlp_scanner import DLPScanner

        scanner = DLPScanner(alert_callback=lambda **kw: None, trial_active=False)
        findings = scanner.scan_content("SSN: 123-45-6789", source="test")
        assert findings == []

    def test_credential_scanner_returns_empty(self, tmp_path):
        from endpoint_agent.scanners.credential_scanner import CredentialScanner

        (tmp_path / ".env").write_text("API_KEY=sk-test-1234567890")
        scanner = CredentialScanner(
            alert_callback=lambda **kw: None, trial_active=False
        )
        findings = scanner.scan_directory(str(tmp_path))
        assert findings == []

    def test_installation_scanner_returns_empty(self):
        from endpoint_agent.scanners.installation_scanner import InstallationScanner

        scanner = InstallationScanner(
            alert_callback=lambda **kw: None, trial_active=False
        )
        findings = scanner.scan()
        assert findings == []

    def test_process_monitor_returns_empty(self):
        from endpoint_agent.monitors.process_monitor import ProcessMonitor

        monitor = ProcessMonitor(alert_callback=lambda **kw: None, trial_active=False)
        threats = monitor.scan_once()
        assert threats == []

    def test_behavioral_monitor_returns_empty(self):
        from endpoint_agent.monitors.behavioral_monitor import BehavioralMonitor

        monitor = BehavioralMonitor(
            alert_callback=lambda **kw: None, trial_active=False
        )
        anomalies = monitor.scan_once()
        assert anomalies == []

    def test_honeypot_check_access_returns_empty(self):
        from endpoint_agent.monitors.honeypot_monitor import HoneypotMonitor

        monitor = HoneypotMonitor(alert_callback=lambda **kw: None, trial_active=False)
        detections = monitor.check_access()
        assert detections == []

    def test_privilege_monitor_returns_false(self):
        from endpoint_agent.monitors.privilege_monitor import PrivilegeMonitor

        monitor = PrivilegeMonitor(
            alert_callback=lambda **kw: None,
            scan_dirs=["/tmp"],
            trial_active=False,
        )
        elevated = monitor.check_current_privileges()
        assert elevated is False

    def test_privilege_monitor_perms_returns_empty(self):
        from endpoint_agent.monitors.privilege_monitor import PrivilegeMonitor

        monitor = PrivilegeMonitor(
            alert_callback=lambda **kw: None,
            scan_dirs=["/tmp"],
            trial_active=False,
        )
        findings = monitor.scan_file_permissions()
        assert findings == []
