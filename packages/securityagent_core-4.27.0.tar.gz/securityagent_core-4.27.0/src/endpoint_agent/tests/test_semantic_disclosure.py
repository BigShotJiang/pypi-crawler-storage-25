"""Tests for semantic (natural language) credential disclosure detection."""

from endpoint_agent.scanners.dlp_scanner import DLPScanner


def _make_scanner():
    alerts = []
    scanner = DLPScanner(alert_callback=lambda **kw: alerts.append(kw))
    return scanner, alerts


class TestSemanticDisclosure:
    """Natural language credential disclosure patterns."""

    def test_password_disclosure(self):
        scanner, _ = _make_scanner()
        findings = scanner.scan_content(
            "the database password is Sup3rS3cr3t!",
            source="response.txt",
        )
        sem = [f for f in findings if f["type"] == "semantic_disclosure"]
        assert len(sem) >= 1
        assert "Password" in sem[0]["pattern"]

    def test_api_key_disclosure(self):
        scanner, _ = _make_scanner()
        findings = scanner.scan_content(
            "Your API key is sk-proj-abc123def456ghi789",
            source="response.txt",
        )
        sem = [f for f in findings if f["type"] == "semantic_disclosure"]
        assert len(sem) >= 1

    def test_secret_disclosure(self):
        scanner, _ = _make_scanner()
        findings = scanner.scan_content(
            "The client secret is aB3dEf7hIj9kLmNoPq",
            source="response.txt",
        )
        sem = [f for f in findings if f["type"] == "semantic_disclosure"]
        assert len(sem) >= 1

    def test_db_creds_disclosure(self):
        scanner, _ = _make_scanner()
        findings = scanner.scan_content(
            "postgres password is xK9mN2pQ5r",
            source="response.txt",
        )
        sem = [f for f in findings if f["type"] == "semantic_disclosure"]
        assert len(sem) >= 1

    def test_placeholder_not_detected(self):
        scanner, _ = _make_scanner()
        findings = scanner.scan_content(
            "the password is changeme",
            source="response.txt",
        )
        sem = [f for f in findings if f["type"] == "semantic_disclosure"]
        assert len(sem) == 0, "Placeholder 'changeme' should be filtered"

    def test_placeholder_example_not_detected(self):
        scanner, _ = _make_scanner()
        findings = scanner.scan_content(
            "your API key is YOUR_KEY_HERE",
            source="response.txt",
        )
        sem = [f for f in findings if f["type"] == "semantic_disclosure"]
        assert len(sem) == 0, "Placeholder 'YOUR_KEY_HERE' should be filtered"

    def test_discussion_not_detected(self):
        scanner, _ = _make_scanner()
        findings = scanner.scan_content(
            "discuss how to protect passwords in the application",
            source="response.txt",
        )
        sem = [f for f in findings if f["type"] == "semantic_disclosure"]
        assert len(sem) == 0, "Discussion about passwords is not disclosure"

    def test_credentials_block(self):
        scanner, _ = _make_scanner()
        findings = scanner.scan_content(
            "credentials:\n  username: admin\n  password: xK9mN2pQ5r",
            source="response.txt",
        )
        sem = [f for f in findings if f["type"] == "semantic_disclosure"]
        assert len(sem) >= 1

    def test_low_entropy_value_filtered(self):
        scanner, _ = _make_scanner()
        findings = scanner.scan_content(
            "the password is aaaa",
            source="response.txt",
        )
        sem = [f for f in findings if f["type"] == "semantic_disclosure"]
        assert len(sem) == 0, "Low-entropy value should be filtered"
