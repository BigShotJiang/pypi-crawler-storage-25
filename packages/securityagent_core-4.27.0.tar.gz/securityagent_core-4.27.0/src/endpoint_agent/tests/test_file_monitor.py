"""Tests for the file system monitor."""

from unittest.mock import MagicMock, patch

from endpoint_agent.monitors.file_monitor import ThreatFileHandler


def _make_event(src_path, is_directory=False):
    """Create a mock file system event."""
    event = MagicMock()
    event.src_path = src_path
    event.is_directory = is_directory
    return event


def _make_move_event(src_path, dest_path, is_directory=False):
    """Create a mock file system move event."""
    event = MagicMock()
    event.src_path = src_path
    event.dest_path = dest_path
    event.is_directory = is_directory
    return event


class TestThreatFileHandler:
    def test_detects_openclaw_directory_creation(self):
        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = _make_event("/home/user/openclaw", is_directory=True)
        handler.on_created(event)

        assert len(alerts) == 1
        assert alerts[0]["severity"] == "CRITICAL"
        assert alerts[0]["event_type"] == "threat_installation_detected"
        assert alerts[0]["details"]["matched_pattern"] == "openclaw"

    def test_detects_openclaw_config_file(self):
        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = _make_event("/home/user/.openclaw", is_directory=False)
        handler.on_created(event)

        assert len(alerts) >= 1
        assert any(a["event_type"] == "threat_installation_detected" for a in alerts)

    def test_detects_sensitive_env_file_created(self):
        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = _make_event("/home/user/project/.env", is_directory=False)
        handler.on_created(event)

        assert any(a["event_type"] == "sensitive_file_created" for a in alerts)

    def test_detects_sensitive_file_modified(self):
        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = _make_event("/home/user/project/.env", is_directory=False)
        handler.on_modified(event)

        assert len(alerts) == 1
        assert alerts[0]["event_type"] == "sensitive_file_modified"

    def test_detects_pem_file_created(self):
        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = _make_event("/home/user/server.pem", is_directory=False)
        handler.on_created(event)

        assert any(a["event_type"] == "sensitive_file_created" for a in alerts)

    def test_detects_threat_on_move(self):
        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = _make_move_event(
            "/tmp/download/pkg",
            "/home/user/.openclaw",
            is_directory=True,
        )
        handler.on_moved(event)

        assert len(alerts) == 1
        assert alerts[0]["event_type"] == "threat_installation_detected"

    def test_ignores_normal_files(self):
        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = _make_event("/home/user/document.txt", is_directory=False)
        handler.on_created(event)

        assert len(alerts) == 0

    def test_ignores_events_in_skip_directories(self):
        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = _make_event("/home/user/project/node_modules/.env", is_directory=False)
        handler.on_created(event)

        assert len(alerts) == 0

    def test_ignores_directory_modify_events(self):
        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = _make_event("/home/user/project", is_directory=True)
        handler.on_modified(event)

        assert len(alerts) == 0
