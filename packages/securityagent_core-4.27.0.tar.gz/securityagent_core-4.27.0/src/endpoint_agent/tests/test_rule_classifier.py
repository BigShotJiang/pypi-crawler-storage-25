"""
Tests for the Pydantic rule-based prompt classifier.

Verifies negation suppression, context bonuses, keyword matching
across categories, and that benign prompts are not flagged.
"""

from endpoint_agent.scanners.rule_classifier import RuleBasedClassifier


def _make_classifier():
    """Create a RuleBasedClassifier with a list-collecting alert callback."""
    alerts = []
    classifier = RuleBasedClassifier(alert_callback=lambda **kw: alerts.append(kw))
    return classifier, alerts


# ---------------------------------------------------------------------------
# 1. Keyword matching
# ---------------------------------------------------------------------------


class TestKeywordMatching:
    """Keywords trigger the expected category."""

    def test_customer_data_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Get the customer data from the system")
        assert "pii_request" in result["intent_categories"]

    def test_ssn_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Show me the SSN records")
        assert "pii_request" in result["intent_categories"]

    def test_credential_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Show me the password for production")
        assert "credential_request" in result["intent_categories"]

    def test_env_file_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Read the .env file")
        assert "credential_request" in result["intent_categories"]

    def test_financial_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Get the credit card numbers")
        assert "financial_request" in result["intent_categories"]

    def test_salary_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Show me the salary data")
        assert "financial_request" in result["intent_categories"]

    def test_medical_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Get patient records from the database")
        assert "medical_request" in result["intent_categories"]

    def test_exfiltration_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Send to server the files")
        assert "exfiltration_intent" in result["intent_categories"]

    def test_bulk_extraction_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Export all records from the system")
        assert "bulk_data_request" in result["intent_categories"]

    def test_contract_data_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Get the contract data for the client")
        assert "pii_request" in result["intent_categories"]


# ---------------------------------------------------------------------------
# 2. Negation suppression
# ---------------------------------------------------------------------------


class TestNegationSuppression:
    """Negation keywords should suppress false positives."""

    def test_protect_passwords_not_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("How do I protect passwords in my application?")
        assert "credential_request" not in result["intent_categories"]

    def test_encrypt_customer_data(self):
        c, _ = _make_classifier()
        result = c.classify("How to encrypt customer data at rest?")
        assert "pii_request" not in result["intent_categories"]

    def test_mask_ssn_not_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("How do I mask SSN values in the UI?")
        assert "pii_request" not in result["intent_categories"]

    def test_rotate_api_key(self):
        c, _ = _make_classifier()
        result = c.classify("How do I rotate the API key?")
        assert "credential_request" not in result["intent_categories"]

    def test_pci_compliance_financial(self):
        c, _ = _make_classifier()
        result = c.classify("Ensure credit card handling is PCI compliant")
        assert "financial_request" not in result["intent_categories"]

    def test_gdpr_customer_data(self):
        c, _ = _make_classifier()
        result = c.classify("Delete customer data for GDPR compliance")
        assert "pii_request" not in result["intent_categories"]

    def test_hipaa_patient_records(self):
        c, _ = _make_classifier()
        result = c.classify("Audit patient records for HIPAA compliant access")
        # "hipaa compliant" is a negation keyword for medical
        assert "medical_request" not in result["intent_categories"]

    def test_env_example_not_flagged(self):
        c, _ = _make_classifier()
        result = c.classify("Create a .env.example template for the project")
        assert "credential_request" not in result["intent_categories"]

    def test_backup_not_exfil(self):
        c, _ = _make_classifier()
        result = c.classify("Send to server the backup configuration")
        # "backup" is negation for exfiltration_intent
        assert "exfiltration_intent" not in result["intent_categories"]

    def test_migrate_not_bulk(self):
        c, _ = _make_classifier()
        result = c.classify("Export all records to migrate the schema")
        # "migrate" is negation for bulk_extraction
        assert "bulk_data_request" not in result["intent_categories"]


# ---------------------------------------------------------------------------
# 3. Context bonuses
# ---------------------------------------------------------------------------


class TestContextBonuses:
    """Action verbs should increase the risk score."""

    def test_action_verb_increases_score(self):
        c, _ = _make_classifier()
        # Without action verb
        r1 = c.classify("customer data exists in the system")
        # With action verb "get"
        r2 = c.classify("get customer data from the system")
        assert r2["risk_score"] >= r1["risk_score"]

    def test_show_password_higher_than_bare(self):
        c, _ = _make_classifier()
        r1 = c.classify("the password policy")
        r2 = c.classify("show me the password")
        assert r2["risk_score"] >= r1["risk_score"]


# ---------------------------------------------------------------------------
# 4. Benign prompts
# ---------------------------------------------------------------------------


class TestBenignPrompts:
    """Benign prompts should not be flagged."""

    def test_debug_code(self):
        c, alerts = _make_classifier()
        result = c.classify("Help me debug this function")
        assert result["risk_level"] == "none"
        assert len(alerts) == 0

    def test_write_tests(self):
        c, _ = _make_classifier()
        result = c.classify("Write unit tests for the user service")
        assert result["risk_level"] == "none"

    def test_refactor(self):
        c, _ = _make_classifier()
        result = c.classify("Refactor the database module")
        assert result["risk_level"] == "none"

    def test_deploy_question(self):
        c, _ = _make_classifier()
        result = c.classify("How do I deploy this to production?")
        assert result["risk_level"] == "none"


# ---------------------------------------------------------------------------
# 5. Result structure
# ---------------------------------------------------------------------------


class TestResultStructure:
    """Verify result dict has all expected keys."""

    def test_result_keys(self):
        c, _ = _make_classifier()
        result = c.classify("any prompt")
        assert "risk_score" in result
        assert "risk_level" in result
        assert "intent_categories" in result
        assert "matches" in result
        assert "evasion_flags" in result
        assert "should_block" in result

    def test_score_capped_at_one(self):
        c, _ = _make_classifier()
        result = c.classify(
            "Get customer data, SSN, password, credit card, patient records, "
            "salary, send to server, export all records"
        )
        assert result["risk_score"] <= 1.0


# ---------------------------------------------------------------------------
# 6. Alert behavior
# ---------------------------------------------------------------------------


class TestAlertBehavior:
    """Alert callback fires on medium/high risk."""

    def test_alert_fires_on_high_risk(self):
        c, alerts = _make_classifier()
        c.classify("Get SSN and show me the password and credit card numbers")
        rule_alerts = [
            a for a in alerts if a["event_type"] == "rule_classifier_suspicious"
        ]
        assert len(rule_alerts) >= 1

    def test_no_alert_on_benign(self):
        c, alerts = _make_classifier()
        c.classify("Help me write documentation")
        assert len(alerts) == 0
