"""Tests for binary document text extraction."""

import csv
import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from endpoint_agent.scanners.text_extractor import (
    extract_text,
    extract_text_chunked,
    get_csv_header_findings,
)


# ---------------------------------------------------------------------------
# PDF extraction
# ---------------------------------------------------------------------------


class TestPDFExtraction:

    def test_extract_pdf_blank(self, tmp_path):
        from pypdf import PdfWriter

        writer = PdfWriter()
        writer.add_blank_page(width=200, height=200)
        path = tmp_path / "test.pdf"
        writer.write(str(path))

        result = extract_text(str(path))
        assert result == ""

    def test_extract_pdf_with_content(self):
        """Mock PDF extraction to verify text extraction logic."""
        mock_page = MagicMock()
        mock_page.get_text.return_value = "Patient SSN: 123-45-6789"
        mock_doc = MagicMock()
        mock_doc.is_encrypted = False
        mock_doc.__iter__ = lambda self: iter([mock_page])
        mock_doc.__enter__ = lambda self: self
        mock_doc.__exit__ = MagicMock(return_value=False)

        with patch("fitz.open", return_value=mock_doc):
            result = extract_text("fake.pdf")

        assert "123-45-6789" in result

    def test_extract_pdf_corrupted(self, tmp_path):
        path = tmp_path / "corrupt.pdf"
        path.write_bytes(b"not a pdf at all")
        result = extract_text(str(path))
        assert result == ""

    def test_chunked_pdf(self):
        mock_page1 = MagicMock()
        mock_page1.get_text.return_value = "Page 1 SSN: 123-45-6789"
        mock_page2 = MagicMock()
        mock_page2.get_text.return_value = "Page 2 clean text"
        mock_doc = MagicMock()
        mock_doc.is_encrypted = False
        mock_doc.__iter__ = lambda self: iter([mock_page1, mock_page2])
        mock_doc.__enter__ = lambda self: self
        mock_doc.__exit__ = MagicMock(return_value=False)

        with patch("fitz.open", return_value=mock_doc):
            chunks = list(extract_text_chunked("fake.pdf"))

        assert len(chunks) == 2
        assert "123-45-6789" in chunks[0]


# ---------------------------------------------------------------------------
# XLSX extraction
# ---------------------------------------------------------------------------


class TestXLSXExtraction:

    def test_extract_xlsx_with_data(self, tmp_path):
        import openpyxl

        wb = openpyxl.Workbook()
        ws = wb.active
        ws["A1"] = "Name"
        ws["B1"] = "SSN"
        ws["A2"] = "John Doe"
        ws["B2"] = "123-45-6789"
        path = tmp_path / "test.xlsx"
        wb.save(str(path))

        result = extract_text(str(path))
        assert "123-45-6789" in result
        assert "John Doe" in result

    def test_extract_xlsx_multiple_sheets(self, tmp_path):
        import openpyxl

        wb = openpyxl.Workbook()
        ws1 = wb.active
        ws1.title = "Sheet1"
        ws1["A1"] = "Data on sheet 1"
        ws2 = wb.create_sheet("Sheet2")
        ws2["A1"] = "Secret on sheet 2: 4111111111111111"
        path = tmp_path / "multi.xlsx"
        wb.save(str(path))

        result = extract_text(str(path))
        assert "Data on sheet 1" in result
        assert "4111111111111111" in result

    def test_extract_xlsx_empty(self, tmp_path):
        import openpyxl

        wb = openpyxl.Workbook()
        path = tmp_path / "empty.xlsx"
        wb.save(str(path))

        result = extract_text(str(path))
        # Empty workbook has one sheet with no data — result may be empty or minimal
        assert isinstance(result, str)

    def test_extract_xlsx_corrupted(self, tmp_path):
        path = tmp_path / "corrupt.xlsx"
        path.write_bytes(b"not an xlsx")
        result = extract_text(str(path))
        assert result == ""

    def test_chunked_xlsx(self, tmp_path):
        import openpyxl

        wb = openpyxl.Workbook()
        ws1 = wb.active
        ws1["A1"] = "Sheet1 data"
        ws2 = wb.create_sheet("Sheet2")
        ws2["A1"] = "Sheet2 data"
        path = tmp_path / "chunked.xlsx"
        wb.save(str(path))

        chunks = list(extract_text_chunked(str(path)))
        assert len(chunks) == 2

    def test_get_xlsx_headers(self, tmp_path):
        import openpyxl

        wb = openpyxl.Workbook()
        ws = wb.active
        ws["A1"] = "SSN"
        ws["B1"] = "Patient Name"
        ws["C1"] = "DOB"
        ws["A2"] = "123-45-6789"
        path = tmp_path / "headers.xlsx"
        wb.save(str(path))

        findings = get_csv_header_findings(str(path))
        patterns = [f["pattern"] for f in findings]
        assert "sensitive_column_header:ssn" in patterns
        assert "sensitive_column_header:dob" in patterns


# ---------------------------------------------------------------------------
# DOCX extraction
# ---------------------------------------------------------------------------


class TestDOCXExtraction:

    def test_extract_docx_paragraphs(self, tmp_path):
        from docx import Document

        doc = Document()
        doc.add_paragraph("Patient record: SSN 123-45-6789")
        doc.add_paragraph("Normal text here")
        path = tmp_path / "test.docx"
        doc.save(str(path))

        result = extract_text(str(path))
        assert "123-45-6789" in result
        assert "Normal text here" in result

    def test_extract_docx_tables(self, tmp_path):
        from docx import Document

        doc = Document()
        table = doc.add_table(rows=2, cols=2)
        table.cell(0, 0).text = "Name"
        table.cell(0, 1).text = "Credit Card"
        table.cell(1, 0).text = "Jane"
        table.cell(1, 1).text = "4111111111111111"
        path = tmp_path / "table.docx"
        doc.save(str(path))

        result = extract_text(str(path))
        assert "4111111111111111" in result

    def test_extract_docx_empty(self, tmp_path):
        from docx import Document

        doc = Document()
        path = tmp_path / "empty.docx"
        doc.save(str(path))

        result = extract_text(str(path))
        assert isinstance(result, str)

    def test_extract_docx_corrupted(self, tmp_path):
        path = tmp_path / "corrupt.docx"
        path.write_bytes(b"not a docx")
        result = extract_text(str(path))
        assert result == ""


# ---------------------------------------------------------------------------
# CSV extraction
# ---------------------------------------------------------------------------


class TestCSVExtraction:

    def test_extract_csv_basic(self, tmp_path):
        path = tmp_path / "data.csv"
        path.write_text("name,ssn\nJohn,123-45-6789\n")

        result = extract_text(str(path))
        assert "123-45-6789" in result

    def test_csv_header_findings(self, tmp_path):
        path = tmp_path / "patients.csv"
        path.write_text(
            "SSN,Patient Name,DOB,Notes\n123-45-6789,John,01/01/1990,none\n"
        )

        findings = get_csv_header_findings(str(path))
        patterns = [f["pattern"] for f in findings]
        assert "sensitive_column_header:ssn" in patterns
        assert "sensitive_column_header:dob" in patterns
        assert "sensitive_column_header:patient name" in patterns

    def test_csv_no_sensitive_headers(self, tmp_path):
        path = tmp_path / "clean.csv"
        path.write_text("id,color,size\n1,red,large\n")

        findings = get_csv_header_findings(str(path))
        assert findings == []

    def test_chunked_csv(self, tmp_path):
        path = tmp_path / "big.csv"
        lines = ["row,data\n"] + [f"{i},value{i}\n" for i in range(1000)]
        path.write_text("".join(lines))

        chunks = list(extract_text_chunked(str(path), chunk_size=1000))
        assert len(chunks) > 1
        full = "".join(chunks)
        assert "value999" in full


# ---------------------------------------------------------------------------
# Chunked text extraction
# ---------------------------------------------------------------------------


class TestChunkedText:

    def test_chunked_plain_text(self, tmp_path):
        path = tmp_path / "large.txt"
        content = "line\n" * 200_000  # ~1 MB
        path.write_text(content)

        chunks = list(extract_text_chunked(str(path), chunk_size=10_000))
        assert len(chunks) > 1
        full = "".join(chunks)
        assert len(full) == len(content)

    def test_chunked_preserves_lines(self, tmp_path):
        path = tmp_path / "lines.txt"
        path.write_text("line1\nline2\nline3\n")

        chunks = list(extract_text_chunked(str(path), chunk_size=8))
        full = "".join(chunks)
        assert full == "line1\nline2\nline3\n"

    def test_fallback_on_unsupported_extension(self, tmp_path):
        path = tmp_path / "data.log"
        path.write_text("SSN: 123-45-6789\n")

        result = extract_text(str(path))
        assert "123-45-6789" in result


# ---------------------------------------------------------------------------
# DLP scanner integration with binary formats
# ---------------------------------------------------------------------------


class TestDLPScannerBinaryFiles:

    def test_scan_xlsx_with_ssn(self, tmp_path):
        import openpyxl
        from endpoint_agent.scanners.dlp_scanner import DLPScanner

        wb = openpyxl.Workbook()
        ws = wb.active
        ws["A1"] = "Patient SSN: 123-45-6789"
        path = tmp_path / "patient.xlsx"
        wb.save(str(path))

        scanner = DLPScanner(alert_callback=lambda **kw: None)
        findings = scanner.scan_file(str(path))
        assert any(f["pattern"] == "SSN" for f in findings)

    def test_scan_docx_with_credit_card(self, tmp_path):
        from docx import Document
        from endpoint_agent.scanners.dlp_scanner import DLPScanner

        doc = Document()
        doc.add_paragraph("Card: 4111111111111111")
        path = tmp_path / "receipt.docx"
        doc.save(str(path))

        scanner = DLPScanner(alert_callback=lambda **kw: None)
        findings = scanner.scan_file(str(path))
        assert any(f["pattern"] == "Credit Card" for f in findings)

    def test_scan_csv_with_sensitive_headers(self, tmp_path):
        from endpoint_agent.scanners.dlp_scanner import DLPScanner

        path = tmp_path / "export.csv"
        path.write_text("SSN,Name\n123-45-6789,John\n")

        scanner = DLPScanner(alert_callback=lambda **kw: None)
        findings = scanner.scan_file(str(path))
        # Should find both the SSN content and the sensitive header
        patterns = [f["pattern"] for f in findings]
        assert "SSN" in patterns
        assert "sensitive_column_header:ssn" in patterns

    def test_scan_clean_xlsx_no_findings(self, tmp_path):
        import openpyxl
        from endpoint_agent.scanners.dlp_scanner import DLPScanner

        wb = openpyxl.Workbook()
        ws = wb.active
        ws["A1"] = "Hello"
        ws["B1"] = "World"
        path = tmp_path / "clean.xlsx"
        wb.save(str(path))

        scanner = DLPScanner(alert_callback=lambda **kw: None)
        findings = scanner.scan_file(str(path))
        assert findings == []


# ---------------------------------------------------------------------------
# SecureFS integration with binary formats
# ---------------------------------------------------------------------------


class TestSecureReadBinaryFormats:

    def test_blocks_xlsx_with_pii(self, tmp_path):
        import openpyxl
        from endpoint_agent.secure_fs import ConfidentialAccessError, SecureFileSystem

        wb = openpyxl.Workbook()
        ws = wb.active
        ws["A1"] = "SSN: 123-45-6789"
        path = tmp_path / "data.xlsx"
        wb.save(str(path))

        fs = SecureFileSystem(alert_callback=lambda **kw: None)
        with pytest.raises(ConfidentialAccessError):
            fs.secure_read(str(path))

    def test_blocks_docx_with_credentials(self, tmp_path):
        from docx import Document
        from endpoint_agent.secure_fs import ConfidentialAccessError, SecureFileSystem

        doc = Document()
        doc.add_paragraph(
            "aws_secret_access_key = wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        )
        path = tmp_path / "notes.docx"
        doc.save(str(path))

        fs = SecureFileSystem(alert_callback=lambda **kw: None)
        with pytest.raises(ConfidentialAccessError):
            fs.secure_read(str(path))

    def test_allows_clean_xlsx(self, tmp_path):
        import openpyxl
        from endpoint_agent.secure_fs import SecureFileSystem

        wb = openpyxl.Workbook()
        ws = wb.active
        ws["A1"] = "Color"
        ws["B1"] = "Count"
        ws["A2"] = "Red"
        ws["B2"] = "42"
        path = tmp_path / "colors.xlsx"
        wb.save(str(path))

        fs = SecureFileSystem(alert_callback=lambda **kw: None)
        content = fs.secure_read(str(path))
        assert "Red" in content
        assert "42" in content

    def test_allows_clean_csv(self, tmp_path):
        from endpoint_agent.secure_fs import SecureFileSystem

        path = tmp_path / "products.csv"
        path.write_text("id,name,price\n1,Widget,9.99\n")

        fs = SecureFileSystem(alert_callback=lambda **kw: None)
        content = fs.secure_read(str(path))
        assert "Widget" in content


# ---------------------------------------------------------------------------
# File monitor real-time DLP
# ---------------------------------------------------------------------------


class TestFileMonitorContentScanning:

    def test_created_document_triggers_dlp_scan(self):
        from unittest.mock import call
        from endpoint_agent.monitors.file_monitor import ThreatFileHandler

        mock_scanner = MagicMock()
        mock_scanner.scan_file.return_value = [
            {
                "type": "pii",
                "pattern": "SSN",
                "source": "/tmp/test.xlsx",
                "line": 1,
                "preview": "123-***",
            }
        ]
        alerts = []
        handler = ThreatFileHandler(
            alert_callback=lambda **kw: alerts.append(kw), dlp_scanner=mock_scanner
        )

        event = MagicMock()
        event.src_path = "/tmp/test.xlsx"
        event.is_directory = False
        handler.on_created(event)

        mock_scanner.scan_file.assert_called_once_with("/tmp/test.xlsx")
        assert any(a["event_type"] == "dlp_content_violation_realtime" for a in alerts)

    def test_non_document_skips_content_scan(self):
        from endpoint_agent.monitors.file_monitor import ThreatFileHandler

        mock_scanner = MagicMock()
        handler = ThreatFileHandler(
            alert_callback=lambda **kw: None, dlp_scanner=mock_scanner
        )

        event = MagicMock()
        event.src_path = "/tmp/test.py"
        event.is_directory = False
        handler._scan_document_content(Path("/tmp/test.py"))

        mock_scanner.scan_file.assert_not_called()

    def test_no_dlp_scanner_skips_content_scan(self):
        from endpoint_agent.monitors.file_monitor import ThreatFileHandler

        handler = ThreatFileHandler(alert_callback=lambda **kw: None)

        # Should not raise even without scanner
        handler._scan_document_content(Path("/tmp/test.xlsx"))

    def test_debounce_skips_rapid_scans(self):
        from endpoint_agent.monitors.file_monitor import ThreatFileHandler

        mock_scanner = MagicMock()
        mock_scanner.scan_file.return_value = []
        handler = ThreatFileHandler(
            alert_callback=lambda **kw: None, dlp_scanner=mock_scanner
        )

        handler._scan_document_content(Path("/tmp/test.pdf"))
        handler._scan_document_content(Path("/tmp/test.pdf"))

        assert mock_scanner.scan_file.call_count == 1

    def test_backward_compat_without_scanner(self):
        """ThreatFileHandler works without dlp_scanner (original behavior)."""
        from endpoint_agent.monitors.file_monitor import ThreatFileHandler

        alerts = []
        handler = ThreatFileHandler(alert_callback=lambda **kw: alerts.append(kw))

        event = MagicMock()
        event.src_path = "/tmp/normal.txt"
        event.is_directory = False
        handler.on_created(event)
        # Should not crash
