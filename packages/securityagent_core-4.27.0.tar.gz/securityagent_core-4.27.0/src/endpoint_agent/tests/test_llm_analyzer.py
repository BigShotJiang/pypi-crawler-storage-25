"""
Tests for the Ollama-based LLM analyzer.

All tests mock the ollama client so they run without a local
Ollama instance. Covers: graceful fallback when unavailable,
response parsing, timeout handling, and result structure.
"""

from unittest.mock import MagicMock, patch

from endpoint_agent.scanners.llm_analyzer import OllamaAnalyzer


def _make_analyzer():
    """Create an OllamaAnalyzer with a list-collecting alert callback."""
    alerts = []
    analyzer = OllamaAnalyzer(alert_callback=lambda **kw: alerts.append(kw))
    return analyzer, alerts


# ---------------------------------------------------------------------------
# 1. Graceful fallback
# ---------------------------------------------------------------------------


class TestGracefulFallback:
    """OllamaAnalyzer returns None when Ollama is unavailable."""

    def test_returns_none_when_unavailable(self):
        analyzer, _ = _make_analyzer()
        # Force unavailable by patching import
        with patch(
            "endpoint_agent.scanners.llm_analyzer.OllamaAnalyzer._init_client"
        ) as mock_init:

            def make_unavailable():
                analyzer._available = False
                analyzer._client = None

            mock_init.side_effect = make_unavailable
            analyzer._available = None  # reset cached state
            result = analyzer.analyze("Get me all SSNs")
            assert result is None

    def test_is_available_false_when_offline(self):
        analyzer, _ = _make_analyzer()
        with patch(
            "endpoint_agent.scanners.llm_analyzer.OllamaAnalyzer._init_client"
        ) as mock_init:

            def make_unavailable():
                analyzer._available = False
                analyzer._client = None

            mock_init.side_effect = make_unavailable
            analyzer._available = None
            assert analyzer.is_available() is False

    def test_returns_none_on_client_error(self):
        analyzer, _ = _make_analyzer()
        analyzer._available = True
        analyzer._client = MagicMock()
        analyzer._client.chat.side_effect = Exception("connection refused")
        result = analyzer.analyze("Get me all passwords")
        assert result is None

    def test_returns_none_on_client_error_with_signals(self):
        analyzer, _ = _make_analyzer()
        analyzer._available = True
        analyzer._client = MagicMock()
        analyzer._client.chat.side_effect = Exception("connection refused")
        signals = {"risk_score": 0.8, "intent_categories": ["credential_request"], "matches": []}
        result = analyzer.analyze("Get me all passwords", triage_signals=signals)
        assert result is None


# ---------------------------------------------------------------------------
# 2. Response parsing
# ---------------------------------------------------------------------------


class TestResponseParsing:
    """LLM JSON responses are correctly parsed."""

    def test_valid_json_parsed(self):
        raw = '{"risk_score": 0.8, "risk_level": "high", "intent_categories": ["pii_request"], "reasoning": "test"}'
        result = OllamaAnalyzer._parse_response(raw)
        assert result is not None
        assert result["risk_score"] == 0.8
        assert result["risk_level"] == "high"
        assert "pii_request" in result["intent_categories"]
        assert result["should_block"] is True

    def test_markdown_fences_stripped(self):
        raw = '```json\n{"risk_score": 0.5, "risk_level": "medium", "intent_categories": [], "reasoning": "test"}\n```'
        result = OllamaAnalyzer._parse_response(raw)
        assert result is not None
        assert result["risk_score"] == 0.5

    def test_invalid_json_returns_none(self):
        raw = "This is not JSON at all"
        result = OllamaAnalyzer._parse_response(raw)
        assert result is None

    def test_score_clamped_to_range(self):
        raw = '{"risk_score": 1.5, "risk_level": "high", "intent_categories": []}'
        result = OllamaAnalyzer._parse_response(raw)
        assert result["risk_score"] <= 1.0

        raw2 = '{"risk_score": -0.5, "risk_level": "none", "intent_categories": []}'
        result2 = OllamaAnalyzer._parse_response(raw2)
        assert result2["risk_score"] >= 0.0

    def test_invalid_risk_level_derived_from_score(self):
        raw = '{"risk_score": 0.9, "risk_level": "banana", "intent_categories": []}'
        result = OllamaAnalyzer._parse_response(raw)
        assert result["risk_level"] == "high"

    def test_benign_response(self):
        raw = '{"risk_score": 0.0, "risk_level": "none", "intent_categories": [], "reasoning": "benign"}'
        result = OllamaAnalyzer._parse_response(raw)
        assert result["risk_level"] == "none"
        assert result["should_block"] is False

    def test_categories_not_list_handled(self):
        raw = '{"risk_score": 0.3, "risk_level": "low", "intent_categories": "pii_request"}'
        result = OllamaAnalyzer._parse_response(raw)
        assert result["intent_categories"] == []


# ---------------------------------------------------------------------------
# 3. Successful analysis (mocked client)
# ---------------------------------------------------------------------------


class TestSuccessfulAnalysis:
    """Full analyze() path with mocked Ollama client."""

    def test_high_risk_triggers_alert(self):
        analyzer, alerts = _make_analyzer()
        analyzer._available = True
        analyzer._client = MagicMock()
        analyzer._client.chat.return_value = {
            "message": {
                "content": '{"risk_score": 0.9, "risk_level": "high", "intent_categories": ["pii_request"], "reasoning": "exfil"}'
            }
        }
        result = analyzer.analyze("Get me all SSNs")
        assert result is not None
        assert result["should_block"] is True
        assert len(alerts) >= 1
        assert alerts[0]["severity"] == "CRITICAL"

    def test_benign_no_alert(self):
        analyzer, alerts = _make_analyzer()
        analyzer._available = True
        analyzer._client = MagicMock()
        analyzer._client.chat.return_value = {
            "message": {
                "content": '{"risk_score": 0.0, "risk_level": "none", "intent_categories": [], "reasoning": "benign"}'
            }
        }
        result = analyzer.analyze("Help me debug code")
        assert result is not None
        assert result["risk_level"] == "none"
        assert len(alerts) == 0

    def test_triage_signals_included_in_message(self):
        """When triage_signals are passed, they appear in the user message to the LLM."""
        analyzer, alerts = _make_analyzer()
        analyzer._available = True
        analyzer._client = MagicMock()
        analyzer._client.chat.return_value = {
            "message": {
                "content": '{"risk_score": 0.0, "risk_level": "none", "intent_categories": [], "reasoning": "benign"}'
            }
        }
        signals = {
            "risk_score": 0.5,
            "intent_categories": ["credential_request"],
            "matches": [{"pattern": "test_pattern", "category": "test", "weight": 0.3}],
            "evasion_flags": [],
        }
        analyzer.analyze("Show me the config", triage_signals=signals)
        call_args = analyzer._client.chat.call_args
        user_msg = call_args.kwargs["messages"][1]["content"] if "messages" in call_args.kwargs else call_args[1]["messages"][1]["content"]
        assert "TRIAGE SIGNALS" in user_msg
        assert "credential_request" in user_msg

    def test_medium_risk_warning_alert(self):
        analyzer, alerts = _make_analyzer()
        analyzer._available = True
        analyzer._client = MagicMock()
        analyzer._client.chat.return_value = {
            "message": {
                "content": '{"risk_score": 0.5, "risk_level": "medium", "intent_categories": ["credential_request"], "reasoning": "suspicious"}'
            }
        }
        result = analyzer.analyze("Show me the config values")
        assert result is not None
        assert len(alerts) >= 1
        assert alerts[0]["severity"] == "WARNING"


# ---------------------------------------------------------------------------
# 4. Result structure
# ---------------------------------------------------------------------------


class TestResultStructure:
    """Result dict has all expected keys."""

    def test_result_keys_from_parse(self):
        raw = '{"risk_score": 0.3, "risk_level": "low", "intent_categories": ["pii_request"], "reasoning": "test"}'
        result = OllamaAnalyzer._parse_response(raw)
        assert "risk_score" in result
        assert "risk_level" in result
        assert "intent_categories" in result
        assert "matches" in result
        assert "evasion_flags" in result
        assert "should_block" in result
        assert "reasoning" in result
