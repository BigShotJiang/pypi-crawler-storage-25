"""
Tests for the behavioral detection monitor.

Uses mock psutil data to validate signal detection, scoring, history
management, memory bounds, alert emission, and AccessDenied handling.
"""

import os
import pathlib
import time
from collections import namedtuple
from unittest.mock import MagicMock, patch

import psutil
import pytest

from endpoint_agent.monitors.behavioral_monitor import (
    BehavioralMonitor,
    ProcessHistory,
    ProcessSnapshot,
    UserActivity,
)


# ---------------------------------------------------------------------------
# Mock process factory
# ---------------------------------------------------------------------------


def _make_mock_process(
    pid,
    name,
    cmdline=None,
    username="user",
    ppid=1,
    cpu_percent=1.0,
    rss=10_000_000,
    num_connections=0,
    open_files=None,
    num_fds=5,
    ctx_switches=(10, 0),
):
    """Create a mock psutil process for behavioral monitoring tests."""
    proc = MagicMock()
    proc.info = {
        "pid": pid,
        "name": name,
        "cmdline": cmdline or [name],
        "username": username,
    }
    proc.pid = pid
    proc.ppid.return_value = ppid
    proc.cpu_percent.return_value = cpu_percent

    mem = MagicMock()
    mem.rss = rss
    proc.memory_info.return_value = mem

    if open_files is None:
        proc.open_files.return_value = []
    else:
        mock_files = []
        for path in open_files:
            f = MagicMock()
            f.path = path
            mock_files.append(f)
        proc.open_files.return_value = mock_files

    mock_conns = [MagicMock() for _ in range(num_connections)]
    proc.net_connections.return_value = mock_conns

    proc.num_fds.return_value = num_fds

    pctxsw = namedtuple("pctxsw", ["voluntary", "involuntary"])
    proc.num_ctx_switches.return_value = pctxsw(*ctx_switches)

    return proc


def _run_scans(monitor, procs, count):
    """Helper: run count scan cycles with the given mock process list."""
    with patch("psutil.process_iter", return_value=procs):
        for _ in range(count):
            monitor._scan_cycle()


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------


class TestBehavioralMonitorInit:

    def test_initializes_empty_state(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        assert monitor._process_histories == {}
        assert monitor._running is False
        assert monitor._first_scan_done is False

    def test_stop_sets_flag(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        monitor._running = True
        monitor.stop()
        assert monitor._running is False


# ---------------------------------------------------------------------------
# Snapshot collection
# ---------------------------------------------------------------------------


class TestSnapshotCollection:

    def test_collects_snapshot_from_process(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3", cpu_percent=5.0, rss=50_000_000)
        snapshot = monitor._collect_snapshot(proc)

        assert snapshot is not None
        assert snapshot.pid == 100
        assert snapshot.name == "python3"
        assert snapshot.cpu_percent == 5.0
        assert snapshot.memory_rss == 50_000_000

    def test_skips_own_pid(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(os.getpid(), "python3")
        snapshot = monitor._collect_snapshot(proc)
        assert snapshot is None

    def test_skips_kernel_pids(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        for pid in (0, 1):
            proc = _make_mock_process(pid, "kernel")
            assert monitor._collect_snapshot(proc) is None

    def test_handles_access_denied_on_cpu(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "root_proc")
        proc.cpu_percent.side_effect = psutil.AccessDenied(100)
        snapshot = monitor._collect_snapshot(proc)
        assert snapshot is None

    def test_handles_access_denied_on_open_files(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "systemd")
        proc.open_files.side_effect = psutil.AccessDenied(100)

        snapshot = monitor._collect_snapshot(proc)
        assert snapshot is not None
        assert snapshot.num_open_files == -1
        assert snapshot.open_file_paths == []

    def test_handles_access_denied_on_connections(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "systemd")
        proc.net_connections.side_effect = psutil.AccessDenied(100)

        snapshot = monitor._collect_snapshot(proc)
        assert snapshot is not None
        assert snapshot.num_connections == -1


# ---------------------------------------------------------------------------
# History management
# ---------------------------------------------------------------------------


class TestHistoryManagement:

    def test_builds_history_over_multiple_scans(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3")
        _run_scans(monitor, [proc], 4)

        assert 100 in monitor._process_histories
        assert len(monitor._process_histories[100].snapshots) == 4

    def test_prunes_dead_processes(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc_a = _make_mock_process(100, "python3")
        proc_b = _make_mock_process(200, "node")

        _run_scans(monitor, [proc_a, proc_b], 2)
        assert 100 in monitor._process_histories
        assert 200 in monitor._process_histories

        # proc_b disappears
        _run_scans(monitor, [proc_a], 1)
        assert 100 in monitor._process_histories
        assert 200 not in monitor._process_histories

    def test_history_bounded_by_maxlen(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3")
        _run_scans(monitor, [proc], 100)

        from endpoint_agent.config.settings import BEHAVIORAL_HISTORY_MAX_SNAPSHOTS

        assert (
            len(monitor._process_histories[100].snapshots)
            <= BEHAVIORAL_HISTORY_MAX_SNAPSHOTS
        )

    def test_tracks_sensitive_files_across_snapshots(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3", open_files=["/home/user/.env"])
        _run_scans(monitor, [proc], 3)

        history = monitor._process_histories[100]
        assert "/home/user/.env" in history.sensitive_files_seen


# ---------------------------------------------------------------------------
# Signal detection
# ---------------------------------------------------------------------------


class TestSignalDetection:

    def test_sensitive_file_access_signal(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(
            100,
            "python3",
            open_files=[
                "/home/user/.aws/credentials",
                "/home/user/.env",
                "/home/user/.ssh/id_rsa",
            ],
        )
        _run_scans(monitor, [proc], 4)

        history = monitor._process_histories[100]
        score, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "sensitive_file_access" in signal_names
        assert score > 0

    def test_rapid_file_access_absolute(self):
        """Process with >50 open files triggers rapid_file_access signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        many_files = [f"/tmp/file{i}.dat" for i in range(55)]
        proc = _make_mock_process(100, "python3", open_files=many_files)
        _run_scans(monitor, [proc], 4)

        history = monitor._process_histories[100]
        score, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "rapid_file_access" in signal_names

    def test_rapid_file_access_spike(self):
        """File count spiking 3x above baseline triggers signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)

        # Build low baseline
        proc_low = _make_mock_process(100, "python3", open_files=["/tmp/a", "/tmp/b"])
        _run_scans(monitor, [proc_low], 6)

        # Spike to 55 files
        many_files = [f"/tmp/file{i}.dat" for i in range(55)]
        proc_high = _make_mock_process(100, "python3", open_files=many_files)
        _run_scans(monitor, [proc_high], 1)

        history = monitor._process_histories[100]
        score, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "rapid_file_access" in signal_names

    def test_network_burst_absolute(self):
        """20+ connections triggers network_burst signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3", num_connections=25)
        _run_scans(monitor, [proc], 4)

        history = monitor._process_histories[100]
        score, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "network_burst" in signal_names

    def test_network_burst_spike(self):
        """Connection count spiking 3x above baseline triggers signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)

        proc_normal = _make_mock_process(100, "python3", num_connections=2)
        _run_scans(monitor, [proc_normal], 6)

        proc_burst = _make_mock_process(100, "python3", num_connections=25)
        _run_scans(monitor, [proc_burst], 1)

        history = monitor._process_histories[100]
        score, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "network_burst" in signal_names

    def test_cpu_anomaly(self):
        """CPU spike from 2% to 80% triggers cpu_anomaly signal.

        We build a low baseline, then manually append a high-CPU snapshot
        and score before baselines absorb the spike.
        """
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)

        # Build low CPU baseline
        proc_idle = _make_mock_process(100, "python3", cpu_percent=2.0)
        _run_scans(monitor, [proc_idle], 6)

        # Append a high-CPU snapshot WITHOUT updating baselines
        proc_hot = _make_mock_process(100, "python3", cpu_percent=80.0)
        snapshot = monitor._collect_snapshot(proc_hot)
        monitor._append_snapshot(snapshot)

        # Score against the pre-update (low) baselines
        history = monitor._process_histories[100]
        score, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "cpu_anomaly" in signal_names

    def test_suspicious_lineage(self):
        """Python spawned by unknown parent triggers suspicious_lineage."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3", ppid=999)

        parent_proc = MagicMock()
        parent_proc.name.return_value = "data-exfil"

        with patch("psutil.process_iter", return_value=[proc]), patch(
            "endpoint_agent.monitors.behavioral_monitor.psutil.Process",
            return_value=parent_proc,
        ):
            for _ in range(4):
                monitor._scan_cycle()

            history = monitor._process_histories[100]
            score, signals = monitor._score_process(history)
            signal_names = [s["signal"] for s in signals]
            assert "suspicious_lineage" in signal_names

    def test_normal_lineage_no_signal(self):
        """Python spawned by bash produces no lineage signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3", ppid=50)

        parent_proc = MagicMock()
        parent_proc.name.return_value = "bash"

        with patch("psutil.process_iter", return_value=[proc]), patch(
            "endpoint_agent.monitors.behavioral_monitor.psutil.Process",
            return_value=parent_proc,
        ):
            for _ in range(4):
                monitor._scan_cycle()

        history = monitor._process_histories[100]
        score, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "suspicious_lineage" not in signal_names

    def test_non_scripting_runtime_no_lineage(self):
        """Non-scripting runtime (e.g., nginx) never triggers lineage signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "nginx", ppid=999)

        parent_proc = MagicMock()
        parent_proc.name.return_value = "unknown-launcher"

        with patch("psutil.process_iter", return_value=[proc]), patch(
            "endpoint_agent.monitors.behavioral_monitor.psutil.Process",
            return_value=parent_proc,
        ):
            for _ in range(4):
                monitor._scan_cycle()

        history = monitor._process_histories[100]
        _, signals = monitor._score_process(history)
        assert not any(s["signal"] == "suspicious_lineage" for s in signals)


# ---------------------------------------------------------------------------
# Alert behavior
# ---------------------------------------------------------------------------


class TestAlertBehavior:

    def test_no_alert_for_benign_process(self):
        alerts = []
        monitor = BehavioralMonitor(alert_callback=lambda **kw: alerts.append(kw))
        proc = _make_mock_process(100, "bash", cpu_percent=0.5, num_connections=0)
        _run_scans(monitor, [proc], 10)
        assert len(alerts) == 0

    def test_fires_alert_for_suspicious_process(self):
        alerts = []
        monitor = BehavioralMonitor(alert_callback=lambda **kw: alerts.append(kw))
        proc = _make_mock_process(
            100,
            "python3",
            open_files=[
                "/home/user/.env",
                "/home/user/.aws/credentials",
                "/home/user/.ssh/id_rsa",
            ],
            num_connections=25,
        )
        _run_scans(monitor, [proc], 6)

        assert len(alerts) >= 1
        assert alerts[0]["event_type"] == "behavioral_anomaly_detected"

    def test_critical_alert_for_highly_suspicious(self):
        """Build low baselines first, then spike all metrics simultaneously."""
        alerts = []
        monitor = BehavioralMonitor(alert_callback=lambda **kw: alerts.append(kw))

        # Phase 1: establish low baselines
        proc_normal = _make_mock_process(
            100,
            "python3",
            ppid=999,
            open_files=["/tmp/a.txt"],
            num_connections=1,
            cpu_percent=2.0,
        )
        parent_proc = MagicMock()
        parent_proc.name.return_value = "unknown-launcher"

        with patch("psutil.process_iter", return_value=[proc_normal]), patch(
            "endpoint_agent.monitors.behavioral_monitor.psutil.Process",
            return_value=parent_proc,
        ):
            for _ in range(4):
                monitor._scan_cycle()

        # Phase 2: spike everything
        many_files = [
            "/home/user/.env",
            "/home/user/.aws/credentials",
            "/home/user/.ssh/id_rsa",
            "/home/user/.ssh/id_ed25519",
        ] + [f"/tmp/exfil{i}.dat" for i in range(55)]

        proc_spike = _make_mock_process(
            100,
            "python3",
            ppid=999,
            open_files=many_files,
            num_connections=30,
            cpu_percent=85.0,
        )

        with patch("psutil.process_iter", return_value=[proc_spike]), patch(
            "endpoint_agent.monitors.behavioral_monitor.psutil.Process",
            return_value=parent_proc,
        ):
            for _ in range(3):
                monitor._scan_cycle()

        critical_alerts = [a for a in alerts if a["severity"] == "CRITICAL"]
        assert len(critical_alerts) >= 1
        assert critical_alerts[0]["details"]["anomaly_score"] >= 0.7

    def test_alert_details_contain_expected_fields(self):
        alerts = []
        monitor = BehavioralMonitor(alert_callback=lambda **kw: alerts.append(kw))
        proc = _make_mock_process(
            100,
            "python3",
            open_files=[
                "/home/user/.env",
                "/home/user/.aws/credentials",
                "/home/user/.ssh/id_rsa",
            ],
            num_connections=25,
        )
        _run_scans(monitor, [proc], 6)

        assert len(alerts) >= 1
        details = alerts[0]["details"]
        assert "pid" in details
        assert "name" in details
        assert "anomaly_score" in details
        assert "signals" in details
        assert "sensitive_files_accessed" in details
        assert "observation_window_seconds" in details
        assert "snapshot_count" in details

    def test_does_not_re_alert_same_score(self):
        """Internal dedup: should not re-alert if score hasn't increased."""
        alerts = []
        monitor = BehavioralMonitor(alert_callback=lambda **kw: alerts.append(kw))
        proc = _make_mock_process(
            100,
            "python3",
            open_files=[
                "/home/user/.env",
                "/home/user/.aws/credentials",
                "/home/user/.ssh/id_rsa",
            ],
            num_connections=25,
        )
        _run_scans(monitor, [proc], 10)

        # Should have at most a handful of alerts, not one per scan
        # (cumulative signals may cause score to gradually increase)
        assert len(alerts) <= 5

    def test_first_scan_skips_scoring(self):
        """First scan is baseline-only, no alerts should fire."""
        alerts = []
        monitor = BehavioralMonitor(alert_callback=lambda **kw: alerts.append(kw))
        proc = _make_mock_process(
            100,
            "python3",
            open_files=["/home/user/.env", "/home/user/.aws/credentials"],
            num_connections=25,
        )

        # Only 1 scan (the first/baseline scan)
        _run_scans(monitor, [proc], 1)
        assert len(alerts) == 0


# ---------------------------------------------------------------------------
# scan_once
# ---------------------------------------------------------------------------


class TestScanOnce:

    def test_scan_once_returns_anomalies(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(
            100,
            "python3",
            open_files=[
                "/home/user/.env",
                "/home/user/.aws/credentials",
                "/home/user/.ssh/id_rsa",
            ],
            num_connections=25,
        )

        # Build up history first
        _run_scans(monitor, [proc], 4)

        with patch("psutil.process_iter", return_value=[proc]):
            anomalies = monitor.scan_once()

        assert isinstance(anomalies, list)
        if anomalies:
            assert "pid" in anomalies[0]
            assert "score" in anomalies[0]
            assert "signals" in anomalies[0]

    def test_scan_once_empty_for_benign(self):
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "bash", cpu_percent=0.5)
        _run_scans(monitor, [proc], 4)

        with patch("psutil.process_iter", return_value=[proc]):
            anomalies = monitor.scan_once()

        assert anomalies == []


# ---------------------------------------------------------------------------
# Cumulative scoring (anti-spoofing)
# ---------------------------------------------------------------------------


class TestCumulativeScoring:

    def test_cumulative_file_access_builds_over_cycles(self):
        """Process accessing new files each cycle accumulates them."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        for cycle in range(25):
            files = [f"/tmp/data_{cycle}_{i}.txt" for i in range(5)]
            proc = _make_mock_process(100, "python3", open_files=files)
            _run_scans(monitor, [proc], 1)

        history = monitor._process_histories[100]
        assert len(history.total_unique_files_accessed) == 125

    def test_cumulative_file_access_triggers_signal(self):
        """Crossing cumulative threshold fires the signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        for cycle in range(24):
            files = [f"/tmp/data_{cycle}_{i}.txt" for i in range(5)]
            proc = _make_mock_process(100, "python3", open_files=files)
            _run_scans(monitor, [proc], 1)

        history = monitor._process_histories[100]
        _, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "cumulative_file_access" in signal_names

    def test_cumulative_file_below_threshold_no_signal(self):
        """Below threshold, no cumulative_file_access signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        for cycle in range(5):
            files = [f"/tmp/data_{cycle}_{i}.txt" for i in range(3)]
            proc = _make_mock_process(100, "python3", open_files=files)
            _run_scans(monitor, [proc], 1)

        history = monitor._process_histories[100]
        _, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "cumulative_file_access" not in signal_names

    def test_cumulative_network_triggers_signal(self):
        """Cumulative connections exceeding threshold fires signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3", num_connections=10)
        _run_scans(monitor, [proc], 25)  # 10 * 25 = 250 > 200

        history = monitor._process_histories[100]
        _, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "cumulative_network" in signal_names

    def test_duplicate_files_not_double_counted(self):
        """Reopening the same file should not inflate cumulative count."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        same_files = ["/tmp/same1.txt", "/tmp/same2.txt"]
        proc = _make_mock_process(100, "python3", open_files=same_files)
        _run_scans(monitor, [proc], 20)

        history = monitor._process_histories[100]
        assert len(history.total_unique_files_accessed) == 2


# ---------------------------------------------------------------------------
# Cross-process correlation (anti-spoofing)
# ---------------------------------------------------------------------------


class TestCrossProcessCorrelation:

    def test_dead_process_rolls_into_user_activity(self):
        """When a process dies, its data rolls into user-level tracking."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(
            100,
            "python3",
            username="attacker",
            open_files=["/home/user/.env"],
        )
        _run_scans(monitor, [proc], 4)
        _run_scans(monitor, [], 1)

        assert "attacker" in monitor._user_activity
        ua = monitor._user_activity["attacker"]
        assert 100 in ua.pids_seen
        assert ua.total_pids_spawned == 1

    def test_multiple_short_lived_processes_aggregate(self):
        """Multiple short-lived processes from same user aggregate."""
        alerts = []
        monitor = BehavioralMonitor(alert_callback=lambda **kw: alerts.append(kw))

        for pid in range(100, 112):
            proc = _make_mock_process(
                pid,
                "python3",
                username="attacker",
                open_files=["/home/user/.ssh/id_rsa"],
            )
            _run_scans(monitor, [proc], 4)
            _run_scans(monitor, [], 1)

        ua = monitor._user_activity["attacker"]
        assert ua.total_pids_spawned == 12
        cross_alerts = [
            a for a in alerts if a.get("event_type") == "cross_process_anomaly_detected"
        ]
        assert len(cross_alerts) >= 1

    def test_different_users_tracked_separately(self):
        """Processes from different users don't bleed into each other."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)

        proc_a = _make_mock_process(
            100, "python3", username="alice", open_files=["/home/alice/.env"]
        )
        proc_b = _make_mock_process(
            200, "python3", username="bob", open_files=["/home/bob/.env"]
        )
        _run_scans(monitor, [proc_a, proc_b], 4)
        _run_scans(monitor, [], 1)

        assert "alice" in monitor._user_activity
        assert "bob" in monitor._user_activity
        assert monitor._user_activity["alice"].total_pids_spawned == 1
        assert monitor._user_activity["bob"].total_pids_spawned == 1

    def test_expired_user_activity_pruned(self):
        """User activity older than the window is cleaned up."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)

        proc = _make_mock_process(100, "python3", username="attacker")
        _run_scans(monitor, [proc], 4)
        _run_scans(monitor, [], 1)

        monitor._user_activity["attacker"].last_updated = time.time() - 4000
        monitor._check_user_level_anomaly()
        assert "attacker" not in monitor._user_activity


# ---------------------------------------------------------------------------
# Full process tree lineage (anti-spoofing)
# ---------------------------------------------------------------------------


class TestFullProcessTree:

    def test_deep_suspicious_chain_higher_score(self):
        """Three non-standard ancestors increases lineage score."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3", ppid=999)

        def mock_process(pid):
            mock = MagicMock()
            chain_map = {
                999: ("data-exfil", 998),
                998: ("cron-job", 997),
                997: ("mystery", 1),
            }
            if pid in chain_map:
                mock.name.return_value = chain_map[pid][0]
                mock.ppid.return_value = chain_map[pid][1]
            else:
                mock.name.return_value = "launchd"
                mock.ppid.return_value = 0
            return mock

        with patch("psutil.process_iter", return_value=[proc]), patch(
            "endpoint_agent.monitors.behavioral_monitor.psutil.Process",
            side_effect=mock_process,
        ):
            for _ in range(4):
                monitor._scan_cycle()

            history = monitor._process_histories[100]
            _, signals = monitor._score_process(history)
            lineage_signals = [
                s for s in signals if s["signal"] == "suspicious_lineage"
            ]
            assert len(lineage_signals) == 1
            assert lineage_signals[0]["score"] >= 0.5

    def test_normal_parent_suspicious_grandparent(self):
        """bash parent but suspicious grandparent gives low score."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3", ppid=50)

        def mock_process(pid):
            mock = MagicMock()
            if pid == 50:
                mock.name.return_value = "bash"
                mock.ppid.return_value = 49
            elif pid == 49:
                mock.name.return_value = "data-exfil"
                mock.ppid.return_value = 1
            else:
                mock.name.return_value = "launchd"
                mock.ppid.return_value = 0
            return mock

        with patch("psutil.process_iter", return_value=[proc]), patch(
            "endpoint_agent.monitors.behavioral_monitor.psutil.Process",
            side_effect=mock_process,
        ):
            for _ in range(4):
                monitor._scan_cycle()

            # Score within mock context so lineage check can resolve parents
            history = monitor._process_histories[100]
            _, signals = monitor._score_process(history)

        lineage_signals = [s for s in signals if s["signal"] == "suspicious_lineage"]
        assert len(lineage_signals) == 1
        assert lineage_signals[0]["score"] == 0.2

    def test_chain_depth_capped(self):
        """Ancestor chain does not exceed max_depth even with infinite chain."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)

        def mock_process(pid):
            mock = MagicMock()
            mock.name.return_value = f"proc-{pid}"
            mock.ppid.return_value = pid + 1
            return mock

        with patch(
            "endpoint_agent.monitors.behavioral_monitor.psutil.Process",
            side_effect=mock_process,
        ):
            chain = monitor._get_ancestor_chain(100)

        assert len(chain) <= 10


# ---------------------------------------------------------------------------
# Document protection
# ---------------------------------------------------------------------------


class TestDocumentProtection:

    def test_detects_pdf_in_downloads(self):
        """Untrusted process opening PDF in ~/Downloads triggers document signal."""
        alerts = []
        monitor = BehavioralMonitor(alert_callback=lambda **kw: alerts.append(kw))
        doc_path = str(pathlib.Path.home() / "Downloads" / "Bank_Statement.pdf")
        proc = _make_mock_process(100, "curl", open_files=[doc_path])
        _run_scans(monitor, [proc], 4)

        history = monitor._process_histories[100]
        _, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "protected_document_access" in signal_names

    def test_trusted_reader_not_alerted(self):
        """Preview opening a protected PDF does not trigger document signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        doc_path = str(pathlib.Path.home() / "Downloads" / "Bank_Statement.pdf")
        proc = _make_mock_process(100, "Preview", open_files=[doc_path])
        _run_scans(monitor, [proc], 4)

        history = monitor._process_histories[100]
        _, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "protected_document_access" not in signal_names

    def test_bulk_access_max_score(self):
        """Opening 7 protected documents results in score 1.0 with BULK ACCESS detail."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        docs = [
            str(pathlib.Path.home() / "Downloads" / f"doc_{i}.pdf") for i in range(7)
        ]
        proc = _make_mock_process(100, "python3", open_files=docs)
        _run_scans(monitor, [proc], 4)

        history = monitor._process_histories[100]
        _, signals = monitor._score_process(history)
        doc_signals = [s for s in signals if s["signal"] == "protected_document_access"]
        assert len(doc_signals) == 1
        assert doc_signals[0]["score"] == 1.0
        assert "BULK ACCESS" in doc_signals[0]["detail"]

    def test_sensitive_name_pattern_detected(self):
        """File with sensitive name pattern in ~/Documents triggers signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        doc_path = str(pathlib.Path.home() / "Documents" / "medical_records.xlsx")
        proc = _make_mock_process(100, "node", open_files=[doc_path])
        _run_scans(monitor, [proc], 4)

        history = monitor._process_histories[100]
        _, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "protected_document_access" in signal_names

    def test_non_protected_path_ignored(self):
        """PDF in /tmp does not trigger document signal."""
        monitor = BehavioralMonitor(alert_callback=lambda **kw: None)
        proc = _make_mock_process(100, "python3", open_files=["/tmp/random.pdf"])
        _run_scans(monitor, [proc], 4)

        history = monitor._process_histories[100]
        _, signals = monitor._score_process(history)
        signal_names = [s["signal"] for s in signals]
        assert "protected_document_access" not in signal_names
