"""Tests for the credential scanner."""

import os

from endpoint_agent.scanners.credential_scanner import CredentialScanner


class TestCredentialScanner:
    def test_detects_aws_access_key(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE\n")

        alerts = []
        scanner = CredentialScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner.scan_file(str(env_file))

        assert len(findings) == 1
        assert findings[0]["pattern"] == "AWS Access Key"
        assert "AKIA" in findings[0]["preview"]
        assert "AKIAIOSFODNN7EXAMPLE" not in findings[0]["preview"]  # Redacted

    def test_detects_aws_secret_key(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text(
            "aws_secret_access_key = wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\n"
        )

        alerts = []
        scanner = CredentialScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner.scan_file(str(env_file))

        assert len(findings) >= 1
        assert any(f["pattern"] == "AWS Secret Key" for f in findings)

    def test_detects_github_token(self, tmp_path):
        config = tmp_path / "config.yaml"
        config.write_text("token: ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij\n")

        alerts = []
        scanner = CredentialScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner.scan_file(str(config))

        assert len(findings) >= 1
        assert any(f["pattern"] == "GitHub Token" for f in findings)

    def test_detects_private_key_header(self, tmp_path):
        key_file = tmp_path / "server.key"
        # .key is not in SCANNABLE_EXTENSIONS but server.key is not in SENSITIVE_FILE_PATTERNS
        # So we need to use a scannable extension
        key_file = tmp_path / "deploy.sh"
        key_file.write_text('#!/bin/bash\nKEY="-----BEGIN RSA PRIVATE KEY-----"\n')

        alerts = []
        scanner = CredentialScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner.scan_file(str(key_file))

        assert len(findings) >= 1
        assert any(f["pattern"] == "Private Key Header" for f in findings)

    def test_detects_jwt_token(self, tmp_path):
        config = tmp_path / ".env"
        config.write_text(
            "TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJzdWIiOiIxMjM0NTY3ODkwIn0."
            "dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U\n"
        )

        alerts = []
        scanner = CredentialScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner.scan_file(str(config))

        assert any(f["pattern"] == "JWT Token" for f in findings)

    def test_detects_database_url(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text(
            "DATABASE_URL=postgres://user:password@localhost:5432/mydb\n"
        )

        alerts = []
        scanner = CredentialScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner.scan_file(str(env_file))

        assert any(f["pattern"] == "Database URL" for f in findings)

    def test_skips_empty_file(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("")

        scanner = CredentialScanner(alert_callback=lambda **kw: None)
        findings = scanner.scan_file(str(env_file))

        assert len(findings) == 0

    def test_skips_non_scannable_extension(self, tmp_path):
        binary = tmp_path / "image.png"
        binary.write_text("AKIAIOSFODNN7EXAMPLE")  # Has an AWS key but wrong extension

        scanner = CredentialScanner(alert_callback=lambda **kw: None)
        findings = scanner.scan_file(str(binary))

        assert len(findings) == 0

    def test_scan_directory(self, tmp_path):
        # Create multiple files with secrets
        (tmp_path / ".env").write_text("API_KEY=AKIAIOSFODNN7EXAMPLE\n")
        (tmp_path / "config.json").write_text(
            '{"secret": "sk_live_abcdefghijklmnopqrst1234"}\n'
        )
        sub = tmp_path / "subdir"
        sub.mkdir()
        (sub / "app.py").write_text('password = "mysecretpassword123"\n')

        alerts = []
        scanner = CredentialScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner.scan_directory(str(tmp_path))

        assert len(findings) >= 2  # At least .env and config.json

    def test_redaction(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=AKIAIOSFODNN7EXAMPLE\n")

        scanner = CredentialScanner(alert_callback=lambda **kw: None)
        findings = scanner.scan_file(str(env_file))

        assert len(findings) == 1
        preview = findings[0]["preview"]
        # The full key should not appear in the preview
        assert "AKIAIOSFODNN7EXAMPLE" not in preview
        # But partial redacted form should
        assert "AKIA" in preview
        assert "****" in preview
