"""Tests for the installation scanner."""

import os

from endpoint_agent.scanners.installation_scanner import InstallationScanner


class TestInstallationScanner:
    def test_detects_openclaw_directory(self, tmp_path):
        # Create a fake openclaw installation
        (tmp_path / "openclaw").mkdir()
        (tmp_path / "openclaw" / "config.yaml").write_text("target: api")

        alerts = []
        scanner = InstallationScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner._scan_directory(str(tmp_path), max_depth=3)

        assert len(findings) >= 1
        assert any(f["matched_pattern"] == "openclaw" for f in findings)

    def test_detects_hidden_openclaw_directory(self, tmp_path):
        (tmp_path / ".openclaw").mkdir()

        alerts = []
        scanner = InstallationScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner._scan_directory(str(tmp_path), max_depth=3)

        assert any(f["matched_pattern"] == ".openclaw" for f in findings)

    def test_detects_autogpt_config_file(self, tmp_path):
        (tmp_path / "autogpt.json").write_text("{}")

        alerts = []
        scanner = InstallationScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner._scan_directory(str(tmp_path), max_depth=3)

        assert any(f["matched_pattern"] == "autogpt.json" for f in findings)

    def test_respects_max_depth(self, tmp_path):
        # Create a deep nested threat
        deep = tmp_path / "a" / "b" / "c" / "d" / "openclaw"
        deep.mkdir(parents=True)

        alerts = []
        scanner = InstallationScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner._scan_directory(str(tmp_path), max_depth=2)

        # Should not find it because it's too deep
        assert len(findings) == 0

    def test_no_false_positives_on_clean_directory(self, tmp_path):
        (tmp_path / "myproject").mkdir()
        (tmp_path / "myproject" / "app.py").write_text("print('hello')")
        (tmp_path / "readme.md").write_text("# My Project")

        alerts = []
        scanner = InstallationScanner(alert_callback=lambda **kw: alerts.append(kw))
        findings = scanner._scan_directory(str(tmp_path), max_depth=3)

        assert len(findings) == 0

    def test_fires_critical_alert(self, tmp_path):
        (tmp_path / ".openclaw").mkdir()

        alerts = []
        scanner = InstallationScanner(alert_callback=lambda **kw: alerts.append(kw))
        scanner._scan_directory(str(tmp_path), max_depth=3)

        assert len(alerts) >= 1
        assert alerts[0]["severity"] == "CRITICAL"
        assert alerts[0]["event_type"] == "malicious_agent_installation_found"
