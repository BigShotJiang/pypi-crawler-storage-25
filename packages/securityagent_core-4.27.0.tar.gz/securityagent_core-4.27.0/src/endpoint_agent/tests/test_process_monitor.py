"""Tests for the process monitor."""

from unittest.mock import MagicMock, patch

import psutil

from endpoint_agent.monitors.process_monitor import ProcessMonitor


def _make_mock_process(pid, name, cmdline=None, username="user"):
    """Create a mock psutil process with given attributes."""
    proc = MagicMock()
    info = {
        "pid": pid,
        "name": name,
        "cmdline": cmdline or [name],
        "username": username,
    }
    proc.info = info
    proc.as_dict.return_value = info
    proc.open_files.return_value = []
    return proc


class TestProcessMonitor:
    def test_detects_threat_by_process_name(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(1234, "openclaw")
        with patch("psutil.process_iter", return_value=[mock_proc]):
            threats = monitor.scan_once()

        assert len(threats) == 1
        assert threats[0]["pid"] == 1234
        assert threats[0]["matched_pattern"] == "openclaw"

    def test_detects_threat_by_cmdline(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(
            5678,
            "python3",
            cmdline=["python3", "-m", "openclaw", "--target", "api"],
        )
        with patch("psutil.process_iter", return_value=[mock_proc]):
            threats = monitor.scan_once()

        assert len(threats) == 1
        assert threats[0]["matched_pattern"] == "openclaw"

    def test_no_threats_for_normal_processes(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(100, "bash", cmdline=["bash"])
        with patch("psutil.process_iter", return_value=[mock_proc]):
            threats = monitor.scan_once()

        assert len(threats) == 0
        assert len(alerts) == 0

    def test_detects_autogpt(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(
            9999,
            "python",
            cmdline=["python", "run_auto-gpt.py"],
        )
        with patch("psutil.process_iter", return_value=[mock_proc]):
            threats = monitor.scan_once()

        assert len(threats) == 1
        assert threats[0]["matched_pattern"] == "auto-gpt"

    def test_fires_critical_alert(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(1111, "openclaw")
        with patch("psutil.process_iter", return_value=[mock_proc]):
            monitor.scan_once()

        critical = [
            a for a in alerts if a["event_type"] == "malicious_process_detected"
        ]
        assert len(critical) >= 1
        assert critical[0]["severity"] == "CRITICAL"

    def test_checks_open_sensitive_files(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_file = MagicMock()
        mock_file.path = "/home/user/project/.env"
        mock_proc = _make_mock_process(1234, "openclaw")
        mock_proc.open_files.return_value = [mock_file]

        with patch("psutil.process_iter", return_value=[mock_proc]):
            threats = monitor.scan_once()

        assert len(threats) == 1
        assert "/home/user/project/.env" in threats[0]["sensitive_files_open"]

    def test_stop_sets_flag(self):
        monitor = ProcessMonitor(alert_callback=lambda **kw: None)
        monitor.stop()
        assert monitor._running is False


class TestEnvironmentSecretDetection:
    """Tests for environment variable secret detection."""

    def test_detects_api_key_in_untrusted_process(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(1234, "curl")
        mock_proc.environ.return_value = {"GEMINI_API_KEY": "sk_live_test_1234567890"}

        with patch("psutil.process_iter", return_value=[mock_proc]), patch(
            "endpoint_agent.monitors.process_monitor.os.getpid", return_value=9999
        ):
            monitor.scan_once()

        env_alerts = [
            a for a in alerts if a["event_type"] == "env_secret_access_detected"
        ]
        assert len(env_alerts) == 1
        assert env_alerts[0]["details"]["pid"] == 1234
        assert env_alerts[0]["details"]["env_var_count"] == 1
        assert (
            env_alerts[0]["details"]["suspicious_env_vars"][0]["name"]
            == "GEMINI_API_KEY"
        )
        assert env_alerts[0]["severity"] == "WARNING"

    def test_detects_multiple_secrets_is_critical(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(1234, "python3")
        mock_proc.environ.return_value = {
            "GEMINI_API_KEY": "sk_live_test_1234567890",
            "OPENAI_SECRET": "sk_secret_abcdefghij",
            "AUTH_TOKEN": "tok_live_xyz1234567",
        }

        with patch("psutil.process_iter", return_value=[mock_proc]), patch(
            "endpoint_agent.monitors.process_monitor.os.getpid", return_value=9999
        ):
            monitor.scan_once()

        env_alerts = [
            a for a in alerts if a["event_type"] == "env_secret_access_detected"
        ]
        assert len(env_alerts) == 1
        assert env_alerts[0]["details"]["env_var_count"] == 3
        assert env_alerts[0]["severity"] == "CRITICAL"

    def test_trusted_process_ignored(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(1234, "bash")
        mock_proc.environ.return_value = {"GEMINI_API_KEY": "sk_live_test_1234567890"}

        with patch("psutil.process_iter", return_value=[mock_proc]), patch(
            "endpoint_agent.monitors.process_monitor.os.getpid", return_value=9999
        ):
            monitor.scan_once()

        env_alerts = [
            a for a in alerts if a["event_type"] == "env_secret_access_detected"
        ]
        assert len(env_alerts) == 0

    def test_trusted_subprocess_ignored_by_substring_match(self):
        """'Code Helper (Plugin)' matches trusted 'code' via substring."""
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(1234, "Code Helper (Plugin)")
        mock_proc.environ.return_value = {"OPENAI_API_KEY": "sk_live_test_1234567890"}

        with patch("psutil.process_iter", return_value=[mock_proc]), patch(
            "endpoint_agent.monitors.process_monitor.os.getpid", return_value=9999
        ):
            monitor.scan_once()

        env_alerts = [
            a for a in alerts if a["event_type"] == "env_secret_access_detected"
        ]
        assert len(env_alerts) == 0

    def test_excluded_env_var_name_ignored(self):
        """SSH_AUTH_SOCK is excluded despite matching 'auth' historically."""
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(1234, "curl")
        mock_proc.environ.return_value = {
            "SSH_AUTH_SOCK": "/private/tmp/com.apple.launchd.xxx/Listeners",
        }

        with patch("psutil.process_iter", return_value=[mock_proc]), patch(
            "endpoint_agent.monitors.process_monitor.os.getpid", return_value=9999
        ):
            monitor.scan_once()

        env_alerts = [
            a for a in alerts if a["event_type"] == "env_secret_access_detected"
        ]
        assert len(env_alerts) == 0

    def test_env_enumeration_command_detected(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(
            1234, "python3", cmdline=["python3", "-c", "printenv"]
        )
        mock_proc.environ.return_value = {}

        with patch("psutil.process_iter", return_value=[mock_proc]), patch(
            "endpoint_agent.monitors.process_monitor.os.getpid", return_value=9999
        ):
            monitor.scan_once()

        env_alerts = [
            a for a in alerts if a["event_type"] == "env_secret_access_detected"
        ]
        assert len(env_alerts) == 1
        assert env_alerts[0]["details"]["is_env_enumeration"] is True

    def test_access_denied_handled_gracefully(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(1234, "curl")
        mock_proc.environ.side_effect = psutil.AccessDenied(1234)

        with patch("psutil.process_iter", return_value=[mock_proc]), patch(
            "endpoint_agent.monitors.process_monitor.os.getpid", return_value=9999
        ):
            monitor.scan_once()

        env_alerts = [
            a for a in alerts if a["event_type"] == "env_secret_access_detected"
        ]
        assert len(env_alerts) == 0

    def test_short_values_ignored(self):
        alerts = []
        monitor = ProcessMonitor(alert_callback=lambda **kw: alerts.append(kw))

        mock_proc = _make_mock_process(1234, "curl")
        mock_proc.environ.return_value = {"API_KEY": "x"}  # len < 8

        with patch("psutil.process_iter", return_value=[mock_proc]), patch(
            "endpoint_agent.monitors.process_monitor.os.getpid", return_value=9999
        ):
            monitor.scan_once()

        env_alerts = [
            a for a in alerts if a["event_type"] == "env_secret_access_detected"
        ]
        assert len(env_alerts) == 0
