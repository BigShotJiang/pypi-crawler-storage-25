"""Tests for the honeypot-based intrusion detection monitor."""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import psutil
import pytest

from endpoint_agent.monitors.honeypot_monitor import HoneypotMonitor


def _make_mock_process(pid, name, open_files=None, username="user"):
    """Create a mock psutil process for honeypot tests."""
    proc = MagicMock()
    proc.info = {
        "pid": pid,
        "name": name,
        "cmdline": [name],
        "username": username,
    }
    if open_files is None:
        proc.open_files.return_value = []
    else:
        mock_files = []
        for path in open_files:
            f = MagicMock()
            f.path = path
            mock_files.append(f)
        proc.open_files.return_value = mock_files
    return proc


class TestHoneypotSetup:
    def test_creates_honeypot_files(self, tmp_path):
        hp_env = str(tmp_path / ".env")
        hp_cred = str(tmp_path / "credentials")
        with patch(
            "endpoint_agent.monitors.honeypot_monitor.HONEYPOT_PATHS",
            [hp_env, hp_cred],
        ):
            monitor = HoneypotMonitor(alert_callback=lambda **kw: None)
            created = monitor.setup()

        assert len(created) == 2
        assert Path(hp_env).exists()
        assert Path(hp_cred).exists()
        content = Path(hp_env).read_text()
        assert "AKIAIOSFODNN7EXAMPLE" in content

    def test_cleanup_removes_files(self, tmp_path):
        hp_env = str(tmp_path / ".env")
        with patch("endpoint_agent.monitors.honeypot_monitor.HONEYPOT_PATHS", [hp_env]):
            monitor = HoneypotMonitor(alert_callback=lambda **kw: None)
            monitor.setup()
            assert Path(hp_env).exists()
            monitor.cleanup()
            assert not Path(hp_env).exists()


class TestHoneypotDetection:
    def test_detects_honeypot_access(self, tmp_path):
        honeypot_path = str((tmp_path / ".env").resolve())
        alerts = []
        monitor = HoneypotMonitor(alert_callback=lambda **kw: alerts.append(kw))
        monitor._honeypot_paths = {honeypot_path}

        mock_proc = _make_mock_process(100, "evil_process", open_files=[honeypot_path])
        with patch("psutil.process_iter", return_value=[mock_proc]):
            detections = monitor.check_access()

        assert len(detections) == 1
        assert detections[0]["pid"] == 100
        assert detections[0]["honeypot_file"] == honeypot_path
        assert len(alerts) == 1
        assert alerts[0]["severity"] == "CRITICAL"
        assert alerts[0]["event_type"] == "honeypot_access_detected"

    def test_does_not_alert_same_pid_twice(self, tmp_path):
        honeypot_path = str((tmp_path / ".env").resolve())
        alerts = []
        monitor = HoneypotMonitor(alert_callback=lambda **kw: alerts.append(kw))
        monitor._honeypot_paths = {honeypot_path}

        mock_proc = _make_mock_process(100, "evil", open_files=[honeypot_path])
        with patch("psutil.process_iter", return_value=[mock_proc]):
            monitor.check_access()
            monitor.check_access()

        assert len(alerts) == 1

    def test_ignores_non_honeypot_files(self, tmp_path):
        honeypot_path = str((tmp_path / ".env").resolve())
        monitor = HoneypotMonitor(alert_callback=lambda **kw: None)
        monitor._honeypot_paths = {honeypot_path}

        mock_proc = _make_mock_process(100, "normal", open_files=["/tmp/regular.txt"])
        with patch("psutil.process_iter", return_value=[mock_proc]):
            detections = monitor.check_access()

        assert detections == []

    def test_skips_own_pid(self, tmp_path):
        honeypot_path = str((tmp_path / ".env").resolve())
        monitor = HoneypotMonitor(alert_callback=lambda **kw: None)
        monitor._honeypot_paths = {honeypot_path}

        mock_proc = _make_mock_process(
            os.getpid(), "python3", open_files=[honeypot_path]
        )
        with patch("psutil.process_iter", return_value=[mock_proc]):
            detections = monitor.check_access()

        assert detections == []

    def test_handles_access_denied(self, tmp_path):
        honeypot_path = str((tmp_path / ".env").resolve())
        monitor = HoneypotMonitor(alert_callback=lambda **kw: None)
        monitor._honeypot_paths = {honeypot_path}

        mock_proc = _make_mock_process(100, "root_proc")
        mock_proc.open_files.side_effect = psutil.AccessDenied(100)
        with patch("psutil.process_iter", return_value=[mock_proc]):
            detections = monitor.check_access()

        assert detections == []
