"""Tests for the security engine orchestrator."""

from unittest.mock import MagicMock, patch

from endpoint_agent.engine import SecurityEngine


class TestSecurityEngine:
    def test_initializes_all_components(self, tmp_path):
        engine = SecurityEngine(watch_dirs=[str(tmp_path)])

        assert engine.alert_manager is not None
        assert engine.file_monitor is not None
        assert engine.process_monitor is not None
        assert engine.privilege_monitor is not None
        assert engine.credential_scanner is not None
        assert engine.installation_scanner is not None

    def test_run_scan_completes(self, tmp_path):
        # Create a clean directory
        (tmp_path / "app.py").write_text("print('hello')")

        engine = SecurityEngine(watch_dirs=[str(tmp_path)])

        with patch.object(
            engine.privilege_monitor, "check_current_privileges", return_value=False
        ), patch.object(engine.installation_scanner, "scan", return_value=[]):
            engine.run_scan([str(tmp_path)])

    def test_run_scan_detects_credentials(self, tmp_path):
        (tmp_path / ".env").write_text("AWS_KEY=AKIAIOSFODNN7EXAMPLE\n")

        engine = SecurityEngine(watch_dirs=[str(tmp_path)])

        with patch.object(
            engine.privilege_monitor, "check_current_privileges", return_value=False
        ), patch.object(engine.installation_scanner, "scan", return_value=[]):
            engine.run_scan([str(tmp_path)])

        # Check that alerts were generated
        history = engine.alert_manager.get_history()
        assert any(a.event_type == "exposed_credential" for a in history)

    def test_run_status_returns_dict(self, tmp_path):
        engine = SecurityEngine(watch_dirs=[str(tmp_path)])

        with patch.object(
            engine.privilege_monitor, "check_current_privileges", return_value=False
        ), patch.object(
            engine.process_monitor, "scan_once", return_value=[]
        ), patch.object(
            engine.installation_scanner, "scan", return_value=[]
        ):
            result = engine.run_status()

        assert "elevated_privileges" in result
        assert "active_threats" in result
        assert "malicious_installations" in result

    def test_stop_sets_shutdown_event(self, tmp_path):
        engine = SecurityEngine(watch_dirs=[str(tmp_path)])

        with patch.object(engine.file_monitor, "stop"), patch.object(
            engine.process_monitor, "stop"
        ):
            engine.stop()

        assert engine._shutdown.is_set()
