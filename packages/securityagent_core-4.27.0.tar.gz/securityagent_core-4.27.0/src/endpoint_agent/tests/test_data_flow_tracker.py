"""Tests for the data flow taint tracker."""

from endpoint_agent.scanners.data_flow_tracker import DataFlowTracker


class TestDataFlowTracker:
    """Taint registration and outbound checking."""

    def _make_tracker(self):
        t = DataFlowTracker()
        t._enabled = True
        return t

    def test_register_and_exact_match(self):
        t = self._make_tracker()
        t.register_sensitive("123-45-6789", "file.txt", "SSN")
        matches = t.check_outbound("The SSN is 123-45-6789", channel="tool_call")
        assert len(matches) == 1
        assert matches[0].match_type == "exact"
        assert matches[0].similarity == 1.0

    def test_no_match_on_clean_content(self):
        t = self._make_tracker()
        t.register_sensitive("123-45-6789", "file.txt", "SSN")
        matches = t.check_outbound("The weather is nice today", channel="tool_call")
        assert len(matches) == 0

    def test_fuzzy_match_modified_value(self):
        t = self._make_tracker()
        # Register a long API key
        key = "sk-ant-api03-ABCDEFghijklmnopQRSTUVwxyz0123456789"
        t.register_sensitive(key, "config.txt", "Anthropic Key")
        # Check with slightly modified version (truncated)
        matches = t.check_outbound(
            "key: sk-ant-api03-ABCDEFghijklmnopQRSTUV",
            channel="tool_call",
        )
        # Should get a fuzzy match due to n-gram overlap
        assert len(matches) >= 1

    def test_substring_match_short_value(self):
        t = self._make_tracker()
        t.register_sensitive("hunter2", "env.txt", "password")
        matches = t.check_outbound("the password is hunter2", channel="response")
        assert len(matches) == 1
        assert matches[0].match_type in ("exact", "substring")

    def test_no_duplicate_registration(self):
        t = self._make_tracker()
        t.register_sensitive("123-45-6789", "file1.txt", "SSN")
        t.register_sensitive("123-45-6789", "file2.txt", "SSN")
        assert t.entry_count == 1

    def test_clear_registry(self):
        t = self._make_tracker()
        t.register_sensitive("123-45-6789", "file.txt", "SSN")
        assert t.entry_count == 1
        t.clear()
        assert t.entry_count == 0

    def test_stats(self):
        t = self._make_tracker()
        t.register_sensitive("123-45-6789", "file.txt", "SSN")
        t.register_sensitive("4111111111111111", "file.txt", "Credit Card")
        stats = t.get_stats()
        assert stats["total_entries"] == 2
        assert "SSN" in stats["pattern_types"]
        assert "Credit Card" in stats["pattern_types"]

    def test_disabled_tracker_no_ops(self):
        t = self._make_tracker()
        t._enabled = False
        t.register_sensitive("123-45-6789", "file.txt", "SSN")
        assert t.entry_count == 0
        matches = t.check_outbound("123-45-6789", channel="test")
        assert len(matches) == 0

    def test_cross_channel_detection(self):
        """Data from a file read should be detected in a tool call."""
        t = self._make_tracker()
        t.register_sensitive("AKIAIOSFODNN7EXAMPLE", "~/.aws/credentials", "AWS Access Key")
        matches = t.check_outbound(
            '{"query": "AKIAIOSFODNN7EXAMPLE"}',
            channel="tool_call:web_search",
        )
        assert len(matches) == 1
        assert matches[0].entry.source == "~/.aws/credentials"
        assert matches[0].entry.pattern_type == "AWS Access Key"

    def test_minimum_length_filter(self):
        """Values shorter than 4 chars should not be registered."""
        t = self._make_tracker()
        t.register_sensitive("abc", "file.txt", "short")
        assert t.entry_count == 0
