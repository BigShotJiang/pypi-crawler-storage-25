"""Tests for the privilege monitor."""

import os
import platform
import stat
from unittest.mock import patch

import pytest

from endpoint_agent.monitors.privilege_monitor import (
    PrivilegeMonitor,
    check_file_permissions,
    is_elevated,
)


class TestIsElevated:
    @pytest.mark.skipif(platform.system() == "Windows", reason="Unix-only test")
    def test_not_elevated_as_normal_user(self):
        with patch("os.geteuid", return_value=1000):
            assert is_elevated() is False

    @pytest.mark.skipif(platform.system() == "Windows", reason="Unix-only test")
    def test_elevated_as_root(self):
        with patch("os.geteuid", return_value=0):
            assert is_elevated() is True


class TestCheckFilePermissions:
    @pytest.mark.skipif(platform.system() == "Windows", reason="Unix permissions")
    def test_flags_world_readable(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("SECRET=value")
        os.chmod(str(f), 0o644)  # world-readable

        result = check_file_permissions(str(f))
        assert "world_readable" in result["issues"]

    @pytest.mark.skipif(platform.system() == "Windows", reason="Unix permissions")
    def test_flags_world_writable(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("SECRET=value")
        os.chmod(str(f), 0o666)

        result = check_file_permissions(str(f))
        assert "world_writable" in result["issues"]
        assert "world_readable" in result["issues"]

    @pytest.mark.skipif(platform.system() == "Windows", reason="Unix permissions")
    def test_safe_permissions_no_issues(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("SECRET=value")
        os.chmod(str(f), 0o600)

        result = check_file_permissions(str(f))
        assert len(result["issues"]) == 0

    def test_nonexistent_file(self):
        result = check_file_permissions("/nonexistent/path/.env")
        assert len(result["issues"]) == 0


class TestPrivilegeMonitor:
    def test_check_privileges_normal_user(self):
        alerts = []
        monitor = PrivilegeMonitor(
            alert_callback=lambda **kw: alerts.append(kw),
            scan_dirs=[],
        )

        with patch(
            "endpoint_agent.monitors.privilege_monitor.is_elevated", return_value=False
        ):
            result = monitor.check_current_privileges()

        assert result is False
        assert len(alerts) == 0

    def test_check_privileges_elevated(self):
        alerts = []
        monitor = PrivilegeMonitor(
            alert_callback=lambda **kw: alerts.append(kw),
            scan_dirs=[],
        )

        with patch(
            "endpoint_agent.monitors.privilege_monitor.is_elevated", return_value=True
        ):
            result = monitor.check_current_privileges()

        assert result is True
        assert len(alerts) == 1
        assert alerts[0]["severity"] == "CRITICAL"
        assert alerts[0]["event_type"] == "elevated_privileges_detected"

    @pytest.mark.skipif(platform.system() == "Windows", reason="Unix permissions")
    def test_scan_file_permissions_finds_issues(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("SECRET=abc")
        os.chmod(str(env_file), 0o644)

        alerts = []
        monitor = PrivilegeMonitor(
            alert_callback=lambda **kw: alerts.append(kw),
            scan_dirs=[str(tmp_path)],
        )
        findings = monitor.scan_file_permissions()

        assert len(findings) >= 1
        assert len(alerts) >= 1
