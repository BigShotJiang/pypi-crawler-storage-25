"""Tests for the tool call DLP guard."""

from endpoint_agent.scanners.tool_call_guard import ToolCallGuard


class TestToolCallGuard:
    """Tool call argument scanning."""

    def _make_guard(self):
        alerts = []
        guard = ToolCallGuard(alert_callback=lambda **kw: alerts.append(kw))
        return guard, alerts

    def test_clean_args_allowed(self):
        guard, _ = self._make_guard()
        result = guard.scan_tool_call("web_search", {"query": "python tutorials"})
        assert not result["blocked"]
        assert len(result["findings"]) == 0

    def test_ssn_in_args_blocked(self):
        guard, alerts = self._make_guard()
        result = guard.scan_tool_call(
            "slack_post",
            {"message": "Customer SSN: 123-45-6789", "channel": "#general"},
        )
        assert result["blocked"]
        assert any("SSN" in f["pattern"] for f in result["findings"])
        assert len(alerts) > 0

    def test_credit_card_in_args_blocked(self):
        guard, _ = self._make_guard()
        result = guard.scan_tool_call(
            "web_fetch",
            {"url": "https://api.example.com", "body": "card=4111111111111111"},
        )
        assert result["blocked"]

    def test_nested_args_scanned(self):
        guard, _ = self._make_guard()
        result = guard.scan_tool_call(
            "api_call",
            {"params": {"data": {"ssn": "123-45-6789"}}},
        )
        assert result["blocked"]

    def test_skip_allowlisted_tool(self):
        guard, _ = self._make_guard()
        result = guard.scan_tool_call(
            "Read",  # allowlisted
            {"file_path": "SSN: 123-45-6789"},
        )
        assert not result["blocked"]

    def test_list_args_scanned(self):
        guard, _ = self._make_guard()
        result = guard.scan_tool_call(
            "batch_process",
            {"items": ["normal text", "SSN: 123-45-6789"]},
        )
        assert result["blocked"]

    def test_empty_args_allowed(self):
        guard, _ = self._make_guard()
        result = guard.scan_tool_call("ping", {})
        assert not result["blocked"]

    def test_aws_key_in_query_blocked(self):
        guard, _ = self._make_guard()
        result = guard.scan_tool_call(
            "web_search",
            {"query": "AKIAIOSFODNN7EXAMPLE config"},
        )
        assert result["blocked"]

    def test_private_key_in_args_blocked(self):
        guard, _ = self._make_guard()
        result = guard.scan_tool_call(
            "github_create_issue",
            {"body": "-----BEGIN RSA PRIVATE KEY-----\nMIIE..."},
        )
        assert result["blocked"]
