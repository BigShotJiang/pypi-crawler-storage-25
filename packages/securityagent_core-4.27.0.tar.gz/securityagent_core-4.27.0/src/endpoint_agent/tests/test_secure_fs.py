"""
Tests for the content-aware secure filesystem interceptor.

SecureFileSystem has no configuration, no modes, no policy switches.
Every test asserts the single invariant: sensitive files are always blocked.
"""

import os
import shutil
import tempfile

import pytest

from endpoint_agent.secure_fs import ConfidentialAccessError, SecureFileSystem


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_fs():
    """Create a SecureFileSystem (no arguments — there is no configuration)."""
    alerts = []
    fs = SecureFileSystem(alert_callback=lambda **kw: alerts.append(kw))
    return fs, alerts


def _write_temp(content, suffix=".txt"):
    f = tempfile.NamedTemporaryFile(mode="w", suffix=suffix, delete=False)
    f.write(content)
    f.flush()
    f.close()
    return f.name


def _write_named(content, fname):
    """Write content to a temp file with a specific filename."""
    target = os.path.join(tempfile.mkdtemp(), fname)
    with open(target, "w") as f:
        f.write(content)
    return target


# ---------------------------------------------------------------------------
# secure_read() — content blocking
# ---------------------------------------------------------------------------


class TestSecureRead:
    """secure_read() always blocks sensitive content; clean files pass."""

    def test_returns_content_for_clean_file(self):
        fs, alerts = _make_fs()
        path = _write_temp("Hello world, nothing sensitive here.")
        try:
            content = fs.secure_read(path)
            assert content == "Hello world, nothing sensitive here."
            assert len(alerts) == 0
        finally:
            os.unlink(path)

    def test_blocks_file_with_ssn(self):
        fs, alerts = _make_fs()
        path = _write_temp("Customer SSN: 123-45-6789")
        try:
            with pytest.raises(ConfidentialAccessError) as exc_info:
                fs.secure_read(path)
            assert "SSN" in str(exc_info.value)
            assert exc_info.value.path == str(os.path.realpath(path))
            assert len(exc_info.value.findings) >= 1
        finally:
            os.unlink(path)

    def test_blocks_file_with_credit_card(self):
        fs, _ = _make_fs()
        path = _write_temp("Card: 4111111111111111")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            os.unlink(path)

    def test_blocks_file_with_api_key(self):
        fs, _ = _make_fs()
        path = _write_temp("aws_key = AKIAIOSFODNN7EXAMPLE")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            os.unlink(path)

    def test_blocks_file_with_private_key(self):
        fs, _ = _make_fs()
        path = _write_temp("-----BEGIN RSA PRIVATE KEY-----\nMIIBogIBAAJ...")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            os.unlink(path)

    def test_alert_always_fires_on_block(self):
        fs, alerts = _make_fs()
        path = _write_temp("SSN: 999-88-7777")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
            block_alerts = [a for a in alerts if a["event_type"] == "secure_fs_blocked"]
            assert len(block_alerts) == 1
            assert block_alerts[0]["details"]["action"] == "block"
        finally:
            os.unlink(path)

    def test_empty_file_returns_empty(self):
        fs, _ = _make_fs()
        path = _write_temp("")
        try:
            content = fs.secure_read(path)
            assert content == ""
        finally:
            os.unlink(path)

    def test_nonexistent_file_raises_oserror(self):
        fs, _ = _make_fs()
        with pytest.raises(OSError):
            fs.secure_read("/nonexistent/path/file.txt")


# ---------------------------------------------------------------------------
# secure_open() — context manager
# ---------------------------------------------------------------------------


class TestSecureOpen:
    """secure_open() applies same blocking rules as secure_read()."""

    def test_open_clean_file(self):
        fs, _ = _make_fs()
        path = _write_temp("Safe content only.")
        try:
            with fs.secure_open(path, "r") as f:
                data = f.read()
            assert data == "Safe content only."
        finally:
            os.unlink(path)

    def test_open_blocks_sensitive_content(self):
        fs, _ = _make_fs()
        path = _write_temp("SSN: 123-45-6789")
        try:
            with pytest.raises(ConfidentialAccessError):
                with fs.secure_open(path, "r") as f:
                    f.read()
        finally:
            os.unlink(path)

    def test_open_readlines(self):
        fs, _ = _make_fs()
        path = _write_temp("line1\nline2\nline3\n")
        try:
            with fs.secure_open(path, "r") as f:
                lines = f.readlines()
            assert len(lines) == 3
        finally:
            os.unlink(path)


# ---------------------------------------------------------------------------
# is_blocked() — non-raising pre-flight check
# ---------------------------------------------------------------------------


class TestIsBlocked:
    """is_blocked() returns (True, findings) or (False, []) without raising."""

    def test_clean_file_not_blocked(self):
        fs, _ = _make_fs()
        path = _write_temp("Nothing here.")
        try:
            blocked, findings = fs.is_blocked(path)
            assert blocked is False
            assert findings == []
        finally:
            os.unlink(path)

    def test_sensitive_content_is_blocked(self):
        fs, _ = _make_fs()
        path = _write_temp("SSN: 111-22-3333")
        try:
            blocked, findings = fs.is_blocked(path)
            assert blocked is True
            assert len(findings) >= 1
        finally:
            os.unlink(path)

    def test_nonexistent_file_not_blocked(self):
        fs, _ = _make_fs()
        blocked, findings = fs.is_blocked("/nonexistent/path.txt")
        assert blocked is False

    def test_sensitive_filename_is_blocked(self):
        fs, _ = _make_fs()
        path = _write_named("KEY=value", ".env")
        try:
            blocked, findings = fs.is_blocked(path)
            assert blocked is True
            assert any("sensitive_filename" in f.get("pattern", "") for f in findings)
        finally:
            shutil.rmtree(os.path.dirname(path))


# ---------------------------------------------------------------------------
# Filename / extension blocking (Layer 1 — no content read needed)
# ---------------------------------------------------------------------------


class TestFilenameBlocking:
    """Sensitive filenames and extensions are blocked before content is read."""

    def test_env_file_blocked_by_name(self):
        fs, _ = _make_fs()
        path = _write_named("DB_HOST=localhost\nDB_PORT=5432", ".env")
        try:
            with pytest.raises(ConfidentialAccessError) as exc_info:
                fs.secure_read(path)
            assert "sensitive_filename" in str(exc_info.value.findings)
        finally:
            shutil.rmtree(os.path.dirname(path))

    def test_env_local_blocked(self):
        fs, _ = _make_fs()
        path = _write_named("API_URL=http://localhost:3000", ".env.local")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            shutil.rmtree(os.path.dirname(path))

    def test_pem_extension_blocked(self):
        fs, _ = _make_fs()
        path = _write_temp("-----BEGIN CERTIFICATE-----\nMIIBIj...", suffix=".pem")
        try:
            with pytest.raises(ConfidentialAccessError) as exc_info:
                fs.secure_read(path)
            assert "sensitive_extension" in str(exc_info.value.findings)
        finally:
            os.unlink(path)

    def test_key_extension_blocked(self):
        fs, _ = _make_fs()
        path = _write_temp("private key material", suffix=".key")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            os.unlink(path)

    def test_p12_extension_blocked(self):
        fs, _ = _make_fs()
        path = _write_temp("cert bundle", suffix=".p12")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            os.unlink(path)

    def test_credentials_json_blocked(self):
        fs, _ = _make_fs()
        path = _write_named('{"token": "abc"}', "credentials.json")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            shutil.rmtree(os.path.dirname(path))

    def test_patient_keyword_blocked(self):
        fs, _ = _make_fs()
        path = _write_named("name,age\nJohn,45", "patient_records.csv")
        try:
            with pytest.raises(ConfidentialAccessError) as exc_info:
                fs.secure_read(path)
            assert "sensitive_filename_keyword" in str(exc_info.value.findings)
        finally:
            shutil.rmtree(os.path.dirname(path))

    def test_medical_keyword_blocked(self):
        fs, _ = _make_fs()
        path = _write_named('{"data": []}', "medical_export.json")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            shutil.rmtree(os.path.dirname(path))

    def test_ssn_keyword_blocked(self):
        fs, _ = _make_fs()
        path = _write_named("id,value\n1,xxx", "ssn_database.csv")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            shutil.rmtree(os.path.dirname(path))

    def test_clean_txt_not_blocked_by_name(self):
        fs, _ = _make_fs()
        path = _write_temp("nothing sensitive", suffix=".txt")
        try:
            content = fs.secure_read(path)
            assert "nothing sensitive" in content
        finally:
            os.unlink(path)


# ---------------------------------------------------------------------------
# HIPAA / healthcare PII content patterns (Layer 2)
# ---------------------------------------------------------------------------


class TestHIPAAPatterns:
    """Healthcare identifiers in content are always blocked."""

    def test_blocks_npi_number(self):
        fs, _ = _make_fs()
        path = _write_temp("provider npi: 1234567890")
        try:
            with pytest.raises(ConfidentialAccessError) as exc_info:
                fs.secure_read(path)
            patterns = [f["pattern"] for f in exc_info.value.findings]
            assert any("NPI" in p for p in patterns)
        finally:
            os.unlink(path)

    def test_blocks_medical_record_number(self):
        fs, _ = _make_fs()
        path = _write_temp("mrn: MRN123456")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            os.unlink(path)

    def test_blocks_ssn(self):
        fs, _ = _make_fs()
        path = _write_temp("patient SSN: 987-65-4321")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            os.unlink(path)

    def test_blocks_date_of_birth(self):
        fs, _ = _make_fs()
        path = _write_temp("dob: 01/15/1985")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            os.unlink(path)


# ---------------------------------------------------------------------------
# Unconditional blocking — no bypass path exists
# ---------------------------------------------------------------------------


class TestUnconditionalBlocking:
    """Verify there is no escape hatch: blocking cannot be disabled."""

    def test_no_constructor_arguments_accepted(self):
        """SecureFileSystem takes only alert_callback + trial_active — no policy args."""
        import inspect

        sig = inspect.signature(SecureFileSystem.__init__)
        param_names = set(sig.parameters.keys()) - {"self"}
        assert param_names == {"alert_callback", "trial_active"}, (
            f"Unexpected parameters: {param_names}. "
            "SecureFileSystem must not accept policy, mode, or flag arguments."
        )

    def test_no_set_policy_method(self):
        """There is no set_policy() — policy cannot be changed at runtime."""
        fs, _ = _make_fs()
        assert not hasattr(
            fs, "set_policy"
        ), "set_policy() must not exist — it would allow downgrading to alert mode."

    def test_no_on_violation_attribute(self):
        """There is no _on_violation toggle — it is unconditionally 'block'."""
        fs, _ = _make_fs()
        assert not hasattr(
            fs, "_on_violation"
        ), "_on_violation must not exist — blocking is not conditional."

    def test_sensitive_content_always_blocked(self):
        """SSN is blocked regardless of anything — no way around it."""
        fs, _ = _make_fs()
        path = _write_temp("SSN: 000-00-0001")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            os.unlink(path)

    def test_sensitive_filename_always_blocked(self):
        """Sensitive filenames are blocked regardless of anything."""
        fs, _ = _make_fs()
        path = _write_named("totally harmless", ".env")
        try:
            with pytest.raises(ConfidentialAccessError):
                fs.secure_read(path)
        finally:
            shutil.rmtree(os.path.dirname(path))


# ---------------------------------------------------------------------------
# ConfidentialAccessError
# ---------------------------------------------------------------------------


class TestConfidentialAccessError:
    """Error class shape."""

    def test_error_attributes(self):
        findings = [{"type": "pii", "pattern": "SSN", "source": "/test"}]
        err = ConfidentialAccessError("/test/file.txt", findings)
        assert err.path == "/test/file.txt"
        assert err.findings == findings
        assert "SSN" in str(err)
        assert isinstance(err, PermissionError)
