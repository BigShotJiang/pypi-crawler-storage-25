"""Tests for the cloud bridge lockdown module."""

from unittest.mock import MagicMock, patch

from endpoint_agent.alerting.alert_manager import SecurityAlert
from endpoint_agent.cloud_bridge.lockdown import CloudLockdown


class TestCloudLockdown:
    def test_disabled_by_default(self):
        with patch("endpoint_agent.cloud_bridge.lockdown.CLOUD_BRIDGE_ENABLED", False):
            bridge = CloudLockdown()
            assert bridge.enabled is False

    def test_enabled_with_config(self):
        with patch(
            "endpoint_agent.cloud_bridge.lockdown.CLOUD_BRIDGE_ENABLED", True
        ), patch(
            "endpoint_agent.cloud_bridge.lockdown.SNS_ALERT_TOPIC_ARN",
            "arn:aws:sns:us-east-1:123:topic",
        ):
            mock_boto3 = MagicMock()
            with patch.dict("sys.modules", {"boto3": mock_boto3}):
                bridge = CloudLockdown()
                # Force the boto3 reference
                bridge._boto3 = mock_boto3
                assert bridge.enabled is True

    def test_notify_threat_when_disabled(self):
        with patch("endpoint_agent.cloud_bridge.lockdown.CLOUD_BRIDGE_ENABLED", False):
            bridge = CloudLockdown()
            alert = SecurityAlert(
                timestamp=1000.0,
                severity="CRITICAL",
                event_type="test",
                details={},
            )
            # Should not raise
            bridge.notify_threat(alert)

    def test_notify_threat_publishes_to_sns(self):
        mock_boto3 = MagicMock()
        mock_client = MagicMock()
        mock_boto3.client.return_value = mock_client

        with patch(
            "endpoint_agent.cloud_bridge.lockdown.CLOUD_BRIDGE_ENABLED", True
        ), patch(
            "endpoint_agent.cloud_bridge.lockdown.SNS_ALERT_TOPIC_ARN",
            "arn:aws:sns:us-east-1:123:alerts",
        ):
            bridge = CloudLockdown()
            bridge._boto3 = mock_boto3

            alert = SecurityAlert(
                timestamp=1000.0,
                severity="CRITICAL",
                event_type="malicious_process_detected",
                details={"pid": 1234},
            )
            bridge.notify_threat(alert)

            mock_boto3.client.assert_called_with("sns", region_name="us-east-1")
            mock_client.publish.assert_called_once()
            call_args = mock_client.publish.call_args
            assert call_args.kwargs["TopicArn"] == "arn:aws:sns:us-east-1:123:alerts"
            assert "malicious_process_detected" in call_args.kwargs["Subject"]

    def test_trigger_key_rotation_when_disabled(self):
        with patch("endpoint_agent.cloud_bridge.lockdown.CLOUD_BRIDGE_ENABLED", False):
            bridge = CloudLockdown()
            bridge.trigger_key_rotation("AKIA1234")  # Should not raise
