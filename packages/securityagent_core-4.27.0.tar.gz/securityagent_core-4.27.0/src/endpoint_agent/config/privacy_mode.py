"""
Privacy Mode controller for AgnosticSecurity.

Enforces three privacy modes that control what data leaves the machine:
  FULL_PRIVACY  — Air-gapped: only local LLMs, all cloud calls blocked
  BALANCED      — Default: sanitized data to approved cloud LLMs
  PERMISSIVE    — Log only, no blocking (dev/testing)

Selected via ``EA_PRIVACY_MODE`` env var.  Runtime-switchable via
``get_privacy_controller().set_mode()``.
"""

import json
import os
import threading
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional

_PERSIST_DIR = Path(os.environ.get(
    "EA_STATE_DIR", str(Path.home() / ".cache" / "agnosticsecurity")
))
_PERSIST_PATH = _PERSIST_DIR / "privacy_mode.json"


class PrivacyMode(str, Enum):
    FULL_PRIVACY = "full_privacy"
    BALANCED = "balanced"
    PERMISSIVE = "permissive"


# Providers that run locally (never send data to the cloud)
_LOCAL_PROVIDERS = frozenset({"ollama"})

# All known providers
_ALL_PROVIDERS = ["ollama", "anthropic", "openai", "openrouter"]


class PrivacyController:
    """Singleton controller that enforces privacy mode across all egress points."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        env_mode = os.environ.get("EA_PRIVACY_MODE", "balanced").lower()
        try:
            self._mode = PrivacyMode(env_mode)
        except ValueError:
            self._mode = PrivacyMode.BALANCED

        # Try loading persisted mode (runtime override takes precedence)
        persisted = self._load_persisted()
        if persisted and not os.environ.get("EA_PRIVACY_MODE"):
            self._mode = persisted

    # -- public API --------------------------------------------------------

    def get_mode(self) -> PrivacyMode:
        with self._lock:
            return self._mode

    def set_mode(self, mode: PrivacyMode) -> None:
        with self._lock:
            self._mode = mode
            self._persist()

    def should_block_cloud_llm(self) -> bool:
        """True when cloud LLM calls must be rejected."""
        return self.get_mode() == PrivacyMode.FULL_PRIVACY

    def should_scan_outbound(self) -> bool:
        """True when outbound content should be scanned for sensitive data."""
        return self.get_mode() != PrivacyMode.PERMISSIVE

    def should_block_on_finding(self) -> bool:
        """False in PERMISSIVE — log findings but don't block."""
        return self.get_mode() != PrivacyMode.PERMISSIVE

    def get_effective_threshold(self, base_threshold: float) -> float:
        """Adjust DLP confidence threshold based on privacy mode.

        FULL_PRIVACY  → 0.0  (block everything going to cloud)
        BALANCED      → base (unchanged)
        PERMISSIVE    → 1.0  (nothing gets blocked)
        """
        mode = self.get_mode()
        if mode == PrivacyMode.FULL_PRIVACY:
            return 0.0
        if mode == PrivacyMode.PERMISSIVE:
            return 1.0
        return base_threshold

    def get_allowed_providers(self) -> List[str]:
        """Return list of LLM providers allowed under current mode."""
        mode = self.get_mode()
        if mode == PrivacyMode.FULL_PRIVACY:
            return list(_LOCAL_PROVIDERS)
        return list(_ALL_PROVIDERS)

    def is_provider_allowed(self, provider_name: str) -> bool:
        return provider_name.lower() in self.get_allowed_providers()

    def get_status(self) -> Dict:
        mode = self.get_mode()
        return {
            "mode": mode.value,
            "cloud_llm_blocked": mode == PrivacyMode.FULL_PRIVACY,
            "blocking_enabled": mode != PrivacyMode.PERMISSIVE,
            "scanning_enabled": mode != PrivacyMode.PERMISSIVE,
            "allowed_providers": self.get_allowed_providers(),
        }

    # -- persistence -------------------------------------------------------

    def _persist(self) -> None:
        try:
            _PERSIST_DIR.mkdir(parents=True, exist_ok=True)
            with open(_PERSIST_PATH, "w") as f:
                json.dump({"mode": self._mode.value}, f)
        except OSError:
            pass

    def _load_persisted(self) -> Optional[PrivacyMode]:
        try:
            if _PERSIST_PATH.exists():
                with open(_PERSIST_PATH) as f:
                    data = json.load(f)
                return PrivacyMode(data.get("mode", "balanced"))
        except (OSError, json.JSONDecodeError, ValueError):
            pass
        return None


# -- singleton -------------------------------------------------------------

_controller: Optional[PrivacyController] = None
_init_lock = threading.Lock()


def get_privacy_controller() -> PrivacyController:
    global _controller
    if _controller is None:
        with _init_lock:
            if _controller is None:
                _controller = PrivacyController()
    return _controller
