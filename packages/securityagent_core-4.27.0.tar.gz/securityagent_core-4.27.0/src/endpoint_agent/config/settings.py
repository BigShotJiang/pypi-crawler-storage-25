"""
Centralized configuration for the local endpoint security agent.

All threat patterns, detection thresholds, and monitoring parameters live here.
Sensitive values can be overridden via environment variables prefixed with EA_.
"""

import os
import pathlib
import platform

# Reuse bot patterns from the cloud-side gateway config
try:
    from gateway.config.settings import KNOWN_BOT_USER_AGENTS
except ImportError:
    KNOWN_BOT_USER_AGENTS = [
        "openclaw",
        "autogpt",
        "langchain-agent",
        "python-requests",
        "python-urllib",
        "scrapy",
    ]

# ---------------------------------------------------------------------------
# Threat patterns - process and file names indicating malicious agents
# ---------------------------------------------------------------------------
KNOWN_THREAT_PROCESS_NAMES = [
    "openclaw",
    "open-claw",
    "open_claw",
    "autogpt",
    "auto-gpt",
    "chameleon-agent",
    "data-harvester",
]

KNOWN_THREAT_FILE_PATTERNS = [
    "openclaw",
    "open-claw",
    ".openclaw",
    "openclaw.config",
    "openclaw.yaml",
    "openclaw.json",
    ".autogpt",
    "autogpt.json",
]

KNOWN_THREAT_DIRECTORY_NAMES = [
    "openclaw",
    ".openclaw",
    "open-claw",
    ".autogpt",
    "auto-gpt",
]

# ---------------------------------------------------------------------------
# Allowlist — bypass name-based threat detection for specific processes/paths
# Matches are still logged as INFO for audit. Behavioral detection still applies.
# ---------------------------------------------------------------------------
ALLOWLISTED_PROCESS_PATTERNS = [
    p.strip()
    for p in os.environ.get("EA_ALLOWLISTED_PROCESSES", "").split(",")
    if p.strip()
]
ALLOWLISTED_PATHS = [
    p.strip()
    for p in os.environ.get("EA_ALLOWLISTED_PATHS", "").split(",")
    if p.strip()
]

# ---------------------------------------------------------------------------
# Sensitive file patterns to monitor for unauthorized access
# ---------------------------------------------------------------------------
# Generic config filenames (settings.py, config.json, etc.) are NOT blocked
# by name -- they are caught by Layer 2 content scanning only if they
# actually contain secrets.
SENSITIVE_FILE_PATTERNS = [
    # Environment & secret files
    ".env",
    ".env.local",
    ".env.production",
    ".env.development",
    ".env.staging",
    ".env.test",
    ".env.backup",
    # Secret stores
    "credentials.json",
    "secrets.yaml",
    "secrets.yml",
    "secrets.json",
    # Cloud / infra
    ".aws/credentials",
    ".aws/config",
    ".azure/credentials",
    ".gcloud/credentials.db",
    # SSH
    ".ssh/id_rsa",
    ".ssh/id_ed25519",
    ".ssh/id_ecdsa",
    ".ssh/id_dsa",
    ".ssh/config",
    # Package managers
    ".npmrc",
    ".yarnrc",
    ".pypirc",
    ".netrc",
    # Container / k8s
    ".docker/config.json",
    "kubeconfig",
    ".kube/config",
    # Application config files that are almost always secret-bearing
    "local_settings.py",
    # Terraform / Vault
    "terraform.tfvars",
    ".vault-token",
    # Auth & cert material
    "service-account.json",
    "serviceaccount.json",
    "private_key.json",
    "keystore.jks",
    "truststore.jks",
    # System auth files
    "shadow",
    "gshadow",
    "sudoers",
    "htpasswd",
]

SENSITIVE_FILE_EXTENSIONS = [
    ".pem",
    ".key",
    ".p12",
    ".pfx",
    ".jks",
    ".keystore",
]

# ---------------------------------------------------------------------------
# Credential patterns for scanning file contents (regex)
# ---------------------------------------------------------------------------
CREDENTIAL_PATTERNS = {
    "AWS Access Key": r"AKIA[0-9A-Z]{16}",
    "AWS Secret Key": r"(?i)aws_secret_access_key\s*[=:]\s*[A-Za-z0-9/+=]{40}",
    "Generic API Key": r"(?i)(api[_-]?key|apikey)\s*[=:]\s*['\"][A-Za-z0-9_\-]{20,}['\"]",
    "Generic Secret": r"(?i)(secret|password|passwd|pwd)\s*[=:]\s*['\"][^\s'\"]{12,}['\"]",
    "JWT Token": r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}",
    "GitHub Token": r"gh[ps]_[A-Za-z0-9_]{36,}",
    "Slack Token": r"xox[bprs]-[A-Za-z0-9-]+",
    "Private Key Header": r"-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----",
    "Database URL": r"(?i)(postgres|mysql|mongodb|redis)://[^\s]+:[^\s]+@[^\s]+",
    "Stripe Key": r"sk_live_[A-Za-z0-9]{20,}",
}

# ---------------------------------------------------------------------------
# Semantic disclosure patterns — natural language credential disclosure
# Catches "the password is X", "your API key is X", etc.
# These complement the raw credential patterns above which only match
# the credential format itself, not the surrounding natural language.
# ---------------------------------------------------------------------------
SEMANTIC_DISCLOSURE_PATTERNS = {
    "NL Password Disclosure": (
        r"(?i)(?:the |your |my |our |their |this |that )?"
        r"(?:password|passwd|pass)\s+(?:is|was|=|:)\s*['\"]?(\S{4,})['\"]?"
    ),
    "NL API Key Disclosure": (
        r"(?i)(?:the |your |my |our |their )?"
        r"(?:api[_ -]?key|apikey|api[_ -]?secret)\s+(?:is|was|=|:)\s*['\"]?(\S{8,})['\"]?"
    ),
    "NL Secret Disclosure": (
        r"(?i)(?:the |your |my |our |their )?"
        r"(?:secret|token|auth[_ -]?token|access[_ -]?token|client[_ -]?secret)"
        r"\s+(?:is|was|=|:)\s*['\"]?(\S{8,})['\"]?"
    ),
    "NL Credentials Block": (
        r"(?i)credentials?\s*(?:are|is|:)\s*\n?\s*"
        r"(?:username|user|login)\s*[:=]\s*\S+\s*\n?\s*"
        r"(?:password|pass|pwd)\s*[:=]\s*\S+"
    ),
    "NL Database Creds": (
        r"(?i)(?:database|db|mysql|postgres|mongo|redis)\s+"
        r"(?:password|credentials?|secret)\s+(?:is|are|was|=|:)\s*['\"]?\S{4,}"
    ),
    "NL Bearer Token": (
        r"(?i)(?:bearer|authorization)\s+(?:token|header)\s+"
        r"(?:is|was|=|:)\s*['\"]?\S{8,}"
    ),
    "JSON Credential KV": (
        r"""(?i)["'](?:"""
        r"""password|passwd|admin_password|api_key|apikey|api_secret|"""
        r"""secret_key|access_token|auth_token|client_secret|private_key"""
        r""")["']\s*:\s*["'](\S{4,})["']"""
    ),
}

# ---------------------------------------------------------------------------
# Data flow tracking (taint registry)
# ---------------------------------------------------------------------------
DATA_FLOW_TRACKING_ENABLED = os.environ.get("EA_DATA_FLOW_TRACKING", "1") == "1"
TAINT_SIMILARITY_THRESHOLD = float(
    os.environ.get("EA_TAINT_SIMILARITY_THRESHOLD", "0.6")
)
TAINT_NGRAM_SIZES = (4, 6)
TAINT_MIN_LENGTH = 8  # minimum value length for n-gram indexing
TAINT_PERSIST_TTL: int = int(os.environ.get("EA_TAINT_PERSIST_TTL", "86400"))

# ---------------------------------------------------------------------------
# Lethal Trifecta (Simon Willison, June 2025)
# ---------------------------------------------------------------------------
LETHAL_TRIFECTA_ENABLED: bool = os.environ.get("EA_LETHAL_TRIFECTA", "true").lower() == "true"

# ---------------------------------------------------------------------------
# Tool call guard
# ---------------------------------------------------------------------------
# Tools exempt from DLP argument scanning
TOOL_CALL_DLP_SKIP: set = {
    "Read",         # already handled by secure_fs
    "Glob",         # file search, no data in args
    "Grep",         # search patterns, not data
    "TodoRead",
    "TodoWrite",
}
# Tools that get lower thresholds (outbound/external)
TOOL_CALL_HIGH_RISK: set = {
    "WebFetch",
    "WebSearch",
    "web_fetch",
    "web_search",
    "http_request",
    "send_email",
    "slack_post",
    "github_create_issue",
    "github_comment",
}

# ---------------------------------------------------------------------------
# File permission thresholds (Unix)
# ---------------------------------------------------------------------------
MAX_SAFE_PERMISSION_OCTAL = 0o600  # Owner read/write only
WARN_WORLD_READABLE = True

# ---------------------------------------------------------------------------
# Monitoring settings
# ---------------------------------------------------------------------------
PROCESS_SCAN_INTERVAL_SECONDS = int(os.environ.get("EA_PROCESS_SCAN_INTERVAL", "10"))

# Auto-kill: terminate matched malicious processes
PROCESS_AUTO_KILL_ENABLED = True
PROCESS_AUTO_KILL_TIMEOUT = int(os.environ.get("EA_PROCESS_AUTO_KILL_TIMEOUT", "5"))

# Parent kill: escalate to spawner when a threat respawns repeatedly
PARENT_KILL_ENABLED = True
PARENT_KILL_RESPAWN_THRESHOLD = int(
    os.environ.get("EA_PARENT_KILL_RESPAWN_THRESHOLD", "3")
)
PARENT_KILL_WINDOW_SECONDS = int(os.environ.get("EA_PARENT_KILL_WINDOW_SECONDS", "60"))

# System processes that must NEVER be killed
PROTECTED_PROCESSES = {
    "bash",
    "zsh",
    "sh",
    "fish",
    "tcsh",
    "launchd",
    "systemd",
    "init",
    "sshd",
    "loginwindow",
    "windowserver",
    "kernel_task",
    "kthreadd",
}

# ---------------------------------------------------------------------------
# Environment Variable Secret Detection
# ---------------------------------------------------------------------------
ENV_SECRET_NAME_PATTERNS = [
    "api_key",
    "apikey",
    "api-key",
    "secret_key",
    "secret",
    "access_key",
    "private_key",
    "token",
    "password",
    "passwd",
    "credential",
]

# Env var names that match patterns above but are NOT secrets
ENV_SECRET_EXCLUDED_NAMES = {
    "ssh_auth_sock",
    "ssh_agent_pid",
    "npm_config_token",
    "term_session_id",
    "iterm_session_id",
    "colorterm",
    "xpc_service_name",
}

# Trusted process matching uses SUBSTRING — "code" matches "Code Helper (Plugin)"
TRUSTED_ENV_PROCESSES = {
    "bash",
    "zsh",
    "sh",
    "fish",
    "tcsh",
    "dash",
    "code",
    "cursor",
    "pycharm",
    "intellij",
    "windsurf",
    "terminal",
    "iterm2",
    "alacritty",
    "kitty",
    "wezterm",
    "docker",
    "podman",
    "launchd",
    "systemd",
    "init",
    "sshd",
    "loginwindow",
    "windowserver",
    "notion",
    "postman",
    "teams",
    "microsoft",
    "chrome",
    "google",
    "safari",
    "firefox",
    "edge",
    "brave",
    "electron",
    "claude",
    "codex",
    "ollama",
    "onedrive",
    "webex",
    "shipit",
    "autoupdate",
    "updater",
    "spotlight",
    "corespotlight",
    "finder",
    "gopls",
    "terraform",
    "pet",
    "pidinfo",
    "antigravity",
    "purevpn",
}

ENV_ENUMERATION_COMMANDS = ["printenv", "/proc/", "environ"]

ENV_SECRET_MIN_LENGTH = int(os.environ.get("EA_ENV_SECRET_MIN_LENGTH", "8"))

# ---------------------------------------------------------------------------
# Sensitive Document Protection
# ---------------------------------------------------------------------------
PROTECTED_DOCUMENT_PATHS = [
    str(pathlib.Path.home() / "Documents"),
    str(pathlib.Path.home() / "Downloads"),
    str(pathlib.Path.home() / "Desktop"),
]

PROTECTED_DOCUMENT_EXTENSIONS = {
    ".pdf",
    ".xlsx",
    ".xls",
    ".docx",
    ".doc",
    ".pptx",
    ".ppt",
    ".odt",
    ".ods",
    ".rtf",
    ".csv",
}

# Words like 'secret', 'private', 'bank', 'tax', 'statement', etc. are too
# common in source code to block by filename.
SENSITIVE_DOCUMENT_NAME_PATTERNS = [
    # Identity
    "ssn",
    "passport",
    "drivers_license",
    "national_id",
    # Payment / financial PII
    "creditcard",
    "credit_card",
    "cc_data",
    "cc_number",
    "cc_dump",
    "cardnumber",
    "card_number",
    "cvv",
    "pan_data",
    # Healthcare / HIPAA
    "medical",
    "healthcare",
    "health_record",
    "health-record",
    "patient",
    "diagnosis",
    "prescription",
    "clinical",
    "lab_result",
    "lab-result",
    "discharge",
    "pathology",
    "radiology",
    "imaging",
    "hipaa",
    "ehr",
    "emr",
    "epic_export",
    "hl7",
    # HR / Legal
    "nda",
    "confidential",
    "restricted",
    "offer_letter",
    "termination",
    "performance_review",
    "background_check",
    "hiring",
    "treatment",
    "rx_",
    "_rx",
    # Credential dumps / exports
    "credentials",
    "creds",
    "passwords",
    "passwd",
    "api_keys",
    "apikey",
    "secrets_export",
    "keystore",
    # Financial (specific enough)
    "w2",
    "1099",
    "payroll",
    "salary",
    "compensation",
    "paycheck",
    "routing_number",
    "eob",
    "explanation_of_benefits",
]

TRUSTED_DOCUMENT_READERS = {
    "preview",
    "qlmanage",
    "quicklook",
    "finder",
    "safari",
    "chrome",
    "firefox",
    "edge",
    "brave",
    "acrobat",
    "acrord32",
    "reader",
    "word",
    "excel",
    "powerpoint",
    "winword",
    "soffice",
    "libreoffice",
    "pages",
    "numbers",
    "keynote",
    "evince",
    "okular",
    "foxit",
    "textedit",
    "notepad",
}

DOCUMENT_BULK_ACCESS_THRESHOLD = int(
    os.environ.get("EA_DOCUMENT_BULK_ACCESS_THRESHOLD", "5")
)

BEHAVIORAL_WEIGHT_DOCUMENT_ACCESS = 0.35

FILE_MONITOR_RECURSIVE = True
DEFAULT_WATCH_DIRS = [
    str(pathlib.Path.home()),
    os.getcwd(),
]

# Directories to skip during filesystem walks
SKIP_DIRECTORIES = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".terraform",
    "dist",
    "build",
    ".eggs",
}

# Max file size to scan for credentials (bytes) — threshold for chunked scanning
MAX_SCAN_FILE_BYTES = 1_048_576  # 1 MB

# Max file size for chunked scanning (bytes) — files above this are skipped entirely
MAX_LARGE_FILE_BYTES = 500_000_000  # 500 MB

# Max findings per large-file chunked scan (prevents unbounded memory)
MAX_CHUNKED_FINDINGS = 50

# ---------------------------------------------------------------------------
# Finding confidence threshold — regex matches below this confidence are
# suppressed.  Structural validators (Luhn, format checks) and context
# analyzers (numeric context, placeholder detection) each contribute to the
# final confidence score.  Range: 0.0–1.0.
# ---------------------------------------------------------------------------
DLP_CONFIDENCE_THRESHOLD = float(os.environ.get("EA_DLP_CONFIDENCE_THRESHOLD", "0.5"))

# Binary document extensions eligible for DLP scanning via text extraction
DLP_SCANNABLE_BINARY_EXTENSIONS = {
    ".pdf", ".xlsx", ".xls", ".docx", ".csv",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tiff", ".tif",
}

# ---------------------------------------------------------------------------
# Image OCR / DLP settings
# ---------------------------------------------------------------------------
IMAGE_OCR_ENABLED: bool = os.environ.get("EA_IMAGE_OCR_ENABLED", "true").lower() == "true"
IMAGE_OCR_DPI: int = int(os.environ.get("EA_IMAGE_OCR_DPI", "200"))
IMAGE_MAX_PIXELS: int = int(os.environ.get("EA_IMAGE_MAX_PIXELS", "16000000"))  # 4000x4000
IMAGE_EXIF_STRIP: bool = os.environ.get("EA_IMAGE_EXIF_STRIP", "true").lower() == "true"

# Sensitive CSV/Excel column header patterns (structural DLP signal)
SENSITIVE_CSV_HEADERS = {
    "ssn", "social_security", "social security", "social security number",
    "credit_card", "credit card", "card_number", "card number",
    "account_number", "account number", "routing_number", "routing number",
    "patient_name", "patient name", "patient_id", "patient id",
    "date_of_birth", "date of birth", "dob", "birthdate",
    "diagnosis", "icd_code", "icd code", "mrn", "medical_record",
    "npi", "provider_id", "insurance_id", "member_id",
    "passport", "drivers_license", "email", "phone", "salary",
}

# File extensions eligible for credential scanning
SCANNABLE_EXTENSIONS = {
    ".env",
    ".yml",
    ".yaml",
    ".json",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".properties",
    ".py",
    ".js",
    ".ts",
    ".sh",
    ".bash",
    ".tf",
    ".tfvars",
}

# ---------------------------------------------------------------------------
# Alert severity levels
# ---------------------------------------------------------------------------
SEVERITY_INFO = "INFO"
SEVERITY_WARNING = "WARNING"
SEVERITY_CRITICAL = "CRITICAL"

# ---------------------------------------------------------------------------
# Alert deduplication
# ---------------------------------------------------------------------------
ALERT_DEDUP_WINDOW_SECONDS = 60

# ---------------------------------------------------------------------------
# Cloud bridge settings (optional — connects local agent to AWS WAF/SNS)
# ---------------------------------------------------------------------------
CLOUD_BRIDGE_ENABLED = (
    os.environ.get("EA_CLOUD_BRIDGE_ENABLED", "false").lower() == "true"
)
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")
WAF_WEB_ACL_ID = os.environ.get("EA_WAF_WEB_ACL_ID", "")
SNS_ALERT_TOPIC_ARN = os.environ.get("EA_SNS_ALERT_TOPIC_ARN", "")

# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------
DEFAULT_LOG_DIR = os.path.join(str(pathlib.Path.home()), ".securityagent")
DEFAULT_LOG_FILE = os.path.join(DEFAULT_LOG_DIR, "audit.log")

# ---------------------------------------------------------------------------
# Behavioral detection settings
# ---------------------------------------------------------------------------
BEHAVIORAL_SCAN_INTERVAL_SECONDS = int(
    os.environ.get("EA_BEHAVIORAL_SCAN_INTERVAL", "5")
)
BEHAVIORAL_HISTORY_MAX_SNAPSHOTS = int(
    os.environ.get("EA_BEHAVIORAL_HISTORY_MAX_SNAPSHOTS", "60")
)
BEHAVIORAL_MIN_SNAPSHOTS_FOR_SCORING = int(
    os.environ.get("EA_BEHAVIORAL_MIN_SNAPSHOTS", "3")
)
BEHAVIORAL_EMA_ALPHA = float(os.environ.get("EA_BEHAVIORAL_EMA_ALPHA", "0.3"))

# Alert thresholds (0.0 to 1.0)
BEHAVIORAL_ALERT_THRESHOLD_WARNING = float(
    os.environ.get("EA_BEHAVIORAL_THRESHOLD_WARNING", "0.4")
)
BEHAVIORAL_ALERT_THRESHOLD_CRITICAL = float(
    os.environ.get("EA_BEHAVIORAL_THRESHOLD_CRITICAL", "0.7")
)

# Signal-specific thresholds
BEHAVIORAL_FILE_ACCESS_SPIKE_RATIO = float(
    os.environ.get("EA_BEHAVIORAL_FILE_SPIKE_RATIO", "3.0")
)
BEHAVIORAL_FILE_ACCESS_ABSOLUTE_THRESHOLD = int(
    os.environ.get("EA_BEHAVIORAL_FILE_ABSOLUTE_THRESHOLD", "50")
)
BEHAVIORAL_NET_SPIKE_RATIO = float(
    os.environ.get("EA_BEHAVIORAL_NET_SPIKE_RATIO", "3.0")
)
BEHAVIORAL_NET_CONNECTIONS_ABSOLUTE_THRESHOLD = int(
    os.environ.get("EA_BEHAVIORAL_NET_ABSOLUTE_THRESHOLD", "20")
)
BEHAVIORAL_CPU_SPIKE_THRESHOLD = float(
    os.environ.get("EA_BEHAVIORAL_CPU_SPIKE_THRESHOLD", "50.0")
)
BEHAVIORAL_CPU_SPIKE_RATIO = float(
    os.environ.get("EA_BEHAVIORAL_CPU_SPIKE_RATIO", "5.0")
)

# Signal weights (sum to ~1.0)
BEHAVIORAL_WEIGHT_FILE_ACCESS = 0.25
BEHAVIORAL_WEIGHT_SENSITIVE_FILE = 0.30
BEHAVIORAL_WEIGHT_NETWORK = 0.25
BEHAVIORAL_WEIGHT_CPU = 0.10
BEHAVIORAL_WEIGHT_LINEAGE = 0.10

# Process lineage constants
SCRIPTING_RUNTIMES = {
    "python",
    "python3",
    "python3.11",
    "python3.12",
    "python3.13",
    "node",
    "ruby",
    "perl",
    "php",
}
EXPECTED_PARENT_PROCESSES = {
    "bash",
    "zsh",
    "sh",
    "fish",
    "tcsh",
    "tmux",
    "screen",
    "sshd",
    "systemd",
    "launchd",
    "init",
    "code",
    "terminal",
    "iterm2",
    "windowserver",
    "loginwindow",
    "gnome-terminal",
    "konsole",
}

# ---------------------------------------------------------------------------
# Anti-spoofing: Cumulative scoring
# ---------------------------------------------------------------------------
BEHAVIORAL_CUMULATIVE_FILE_THRESHOLD = int(
    os.environ.get("EA_BEHAVIORAL_CUMULATIVE_FILE_THRESHOLD", "100")
)
BEHAVIORAL_CUMULATIVE_NET_THRESHOLD = int(
    os.environ.get("EA_BEHAVIORAL_CUMULATIVE_NET_THRESHOLD", "200")
)
BEHAVIORAL_WEIGHT_CUMULATIVE_FILE = 0.15
BEHAVIORAL_WEIGHT_CUMULATIVE_NETWORK = 0.10

# ---------------------------------------------------------------------------
# Anti-spoofing: Cross-process correlation
# ---------------------------------------------------------------------------
CROSS_PROCESS_WINDOW_SECONDS = int(os.environ.get("EA_CROSS_PROCESS_WINDOW", "3600"))
CROSS_PROCESS_SENSITIVE_FILE_THRESHOLD = int(
    os.environ.get("EA_CROSS_PROCESS_SENSITIVE_FILE_THRESHOLD", "5")
)
CROSS_PROCESS_PID_THRESHOLD = int(
    os.environ.get("EA_CROSS_PROCESS_PID_THRESHOLD", "10")
)
CROSS_PROCESS_AGGREGATE_SCORE_THRESHOLD = float(
    os.environ.get("EA_CROSS_PROCESS_AGGREGATE_SCORE_THRESHOLD", "2.0")
)

# ---------------------------------------------------------------------------
# Anti-spoofing: Honeypot detection
# ---------------------------------------------------------------------------
HONEYPOT_SCAN_INTERVAL_SECONDS = int(os.environ.get("EA_HONEYPOT_SCAN_INTERVAL", "5"))
HONEYPOT_PATHS = [
    p.strip()
    for p in os.environ.get(
        "EA_HONEYPOT_PATHS",
        "~/.honeypot/.env,~/.honeypot/.aws/credentials,~/.honeypot/.ssh/id_rsa",
    ).split(",")
    if p.strip()
]

# ---------------------------------------------------------------------------
# Anti-spoofing: Process tree depth
# ---------------------------------------------------------------------------
LINEAGE_MAX_DEPTH = int(os.environ.get("EA_LINEAGE_MAX_DEPTH", "10"))

# ---------------------------------------------------------------------------
# DLP (Data Loss Prevention) Scanner
# ---------------------------------------------------------------------------
DLP_PII_PATTERNS = {
    # --- Standard PII ---
    "SSN": r"\b\d{3}-\d{2}-\d{4}\b",
    "Credit Card": (
        r"\b(?:4\d{3}|5[1-5]\d{2}|3[47]\d{2}|6(?:011|5\d{2}))"
        r"[- ]?\d{4}[- ]?\d{4}[- ]?\d{3,4}\b"
    ),
    "US Phone": r"\b(?:\+1[- ]?)?\(?\d{3}\)?[- ]?\d{3}[- ]?\d{4}\b",
    "Email Address": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
    "US Passport": r"(?i)\b(?:passport\s*(?:no|number|#|:))\s*[A-Z]\d{8}\b",
    "Date of Birth": r"\b(?:dob|date.of.birth|birthdate)\s*[=:]\s*\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b",
    # --- HIPAA / Healthcare identifiers ---
    # NPI (National Provider Identifier) — 10 digits, starts with 1 or 2
    "NPI Number": r"\b(?:npi|provider.id)\s*[=:# ]\s*[12]\d{9}\b",
    # Medical Record Number (MRN) — common formats
    "Medical Record Number": r"\b(?:mrn|medical.record.number|patient.id)\s*[=:#]?\s*[A-Z0-9]{5,15}\b",
    # DEA (Drug Enforcement Administration) number — for prescribers
    "DEA Number": r"(?i)\b(?:dea\s*(?:no|number|#|:))\s*[A-Z]{2}\d{7}\b",
    # ICD-10 diagnosis codes — e.g. A00.1, Z99.89
    "ICD-10 Code": r"(?i)\b(?:icd[- ]?10|diagnosis|dx)[- :=]*[A-Z]\d{2}(?:\.\d{1,4})?\b",
    # Insurance / member IDs (common formats)
    "Insurance Member ID": r"\b(?:member.?id|policy.?no|insurance.?id)\s*[=:#]?\s*[A-Z0-9]{8,20}\b",
    # US Driver's License — 1-2 letters followed by 5-8 digits (generic)
    "Drivers License": r"\b(?:dl|driver.?s.?license|license.?no)\s*[=:#]?\s*[A-Z]{1,2}\d{5,8}\b",
    # --- International PII ---
    "Canadian SIN": r"\b\d{3}[-\s]\d{3}[-\s]\d{3}\b",
    "UK NINO": r"\b[A-CEGHJ-PR-TW-Z]{2}\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b",
    "EU VAT Number": r"\b[A-Z]{2}\d{8,12}\b",
    "IBAN": r"\b[A-Z]{2}\d{2}\s?[A-Z0-9]{4}\s?(?:[A-Z0-9]{4}\s?){2,7}[A-Z0-9]{1,4}\b",
    # --- India PII ---
    "Aadhaar Number": r"\b[2-9]\d{3}\s?\d{4}\s?\d{4}\b",
    "PAN Card": r"\b[A-Z]{5}\d{4}[A-Z]\b",
    "Indian Phone": r"\b(?:\+91[- ]?)?[6-9]\d{4}[- ]?\d{5}\b",
}

# Sensitive document class fingerprints — detect form types even when
# PII fields are masked/redacted (e.g., XXX-XX-XXXX near "SSN").
DLP_DOCUMENT_FINGERPRINTS = {
    # US Tax forms
    "W-2 Tax Form": r"(?i)\bForm\s+W[- ]?2\b|Wage\s+and\s+Tax\s+Statement",
    "1040 Tax Return": r"(?i)\bForm\s+1040\b|U\.?S\.?\s+Individual\s+Income\s+Tax\s+Return",
    "1099 Tax Form": r"(?i)\bForm\s+1099[- ]?(?:MISC|INT|DIV|NEC|K|R|G|S)?\b",
    # Healthcare
    "Explanation of Benefits": r"(?i)\bExplanation\s+of\s+Benefits\b|\bEOB\b.*(?:claim|provider|copay)",
    "HIPAA Authorization": r"(?i)\bHIPAA\s+(?:Authorization|Consent|Release)\b",
    "Medical Record": r"(?i)\b(?:discharge\s+summary|operative\s+report|pathology\s+report|radiology\s+report)\b",
    # Employment / Identity
    "I-9 Employment Form": r"(?i)\bForm\s+I[- ]?9\b|Employment\s+Eligibility\s+Verification",
    "W-4 Withholding Form": r"(?i)\bForm\s+W[- ]?4\b|Employee.?s\s+Withholding",
    # Financial
    "Bank Statement": r"(?i)\b(?:account\s+statement|bank\s+statement|checking\s+account|savings\s+account)\b.*\b(?:balance|deposit|withdrawal)\b",
    "Loan Agreement": r"(?i)\b(?:promissory\s+note|loan\s+agreement|mortgage\s+note)\b.*\b(?:principal|interest\s+rate|maturity)\b",
    # Legal
    "NDA": r"(?i)\bnon[- ]?disclosure\s+agreement\b|\bconfidentiality\s+agreement\b",
    "Power of Attorney": r"(?i)\bpower\s+of\s+attorney\b|\bdurable\s+POA\b",
    # Masked PII indicator — redacted fields suggest the doc normally contains PII
    "Masked SSN": r"(?i)(?:SSN|Social\s+Security)\s*[:=# ]\s*X{3}[- ]?X{2}[- ]?X{4}",
    "Masked EIN": r"(?i)(?:EIN|Employer.?s?\s+(?:ID|Identification))\s*[:=# ]\s*X{2}[- ]?X{7}",
}

DLP_CLASSIFICATION_KEYWORDS = {
    "restricted": [
        "top secret",
        "classified",
        "eyes only",
        # Healthcare restricted tier
        "protected health information",
        "phi",
        "hipaa restricted",
        "patient name",
        "date of birth",
        "medical record",
        "diagnosis",
        "prescription",
        "treatment plan",
    ],
    "confidential": [
        "bank",
        "statement",
        "invoice",
        "tax",
        "w2",
        "1099",
        "medical",
        "healthcare",
        "health_record",
        "insurance",
        "ssn",
        "social security",
        "passport",
        "salary",
        "confidential",
        "nda",
        "non-disclosure",
        # Healthcare confidential tier
        "clinical notes",
        "lab results",
        "discharge summary",
        "patient id",
        "member id",
        "insurance id",
        "npi",
        "provider id",
        "dea number",
        "patient data",
        "patient record",
    ],
    "internal": [
        "internal",
        "draft",
        "proprietary",
        "not for distribution",
        "internal use only",
        "do not distribute",
    ],
}

# ---------------------------------------------------------------------------
# Secure Filesystem
# ---------------------------------------------------------------------------
# SecureFileSystem is always active and always blocks — no toggles.

# Path substrings that always indicate a secrets location, regardless of filename.
# Any file whose resolved path contains one of these components is blocked at Layer 1.
SENSITIVE_PATH_COMPONENTS: list[str] = [
    "/run/secrets/",  # Docker secrets mount (standard)
    "/var/secrets/",  # Kubernetes secrets volume (common pattern)
    "/etc/secrets/",  # System secrets directory
    "/.vault/",  # HashiCorp Vault local cache
    "/tmp/secrets/",  # Transient secrets staging area
    "/.secrets/",  # Hidden secrets directory
    "/run/credentials/",  # systemd credentials (systemd v250+)
]

# ---------------------------------------------------------------------------
# Prompt Intent Analysis — keyword/pattern-based risk scoring
# ---------------------------------------------------------------------------
# Each category maps to a list of {pattern, weight} dicts.
# Weights contribute to a cumulative risk score (0.0–1.0).

PROMPT_RISK_KEYWORDS: dict[str, list[dict]] = {
    "pii_request": [
        {"pattern": r"\b(ssn|social\s*security\s*number)s?\b", "weight": 0.6},
        {
            "pattern": r"\b(customer|client|user|employee)\s+(data|info|information|details|record)s?\b",
            "weight": 0.3,
        },
        {"pattern": r"\bpersonal\s+(data|info|information|details)\b", "weight": 0.4},
        {"pattern": r"\b(dates?\s*of\s*birth|dob|birthdate)s?\b", "weight": 0.3},
        {
            "pattern": r"\b(passport|driver.?s?\s*license|national\s*id)\s*(number|data|info)?\b",
            "weight": 0.5,
        },
        {
            "pattern": r"\b(phone\s*number|email\s*address|home\s*address)e?s?\b",
            "weight": 0.2,
        },
        {"pattern": r"\bpii\b", "weight": 0.5},
    ],
    "credential_request": [
        {
            "pattern": r"\b(api\s*key|secret\s*key|access\s*key|private\s*key)s?\b",
            "weight": 0.6,
        },
        {"pattern": r"\b(passwords?|passwd|credentials?)\b", "weight": 0.4},
        {"pattern": r"\b(token|auth\s*token|bearer\s*token|jwt)s?\b", "weight": 0.3},
        {"pattern": r"(\.env\b|environment\s*variable|env\s*var)s?\b", "weight": 0.4},
        {"pattern": r"\b(ssh\s*key|rsa\s*key|private\s*key)\b", "weight": 0.5},
        {"pattern": r"\b(aws|gcp|azure)\s*(secret|credential|key)s?\b", "weight": 0.5},
        {
            "pattern": r"\b(database|db)\s*(password|credential|connection\s*string)\b",
            "weight": 0.5,
        },
    ],
    "financial_request": [
        {
            "pattern": r"\b(credit\s*card|card\s*number|cvv|pan)\s*(data|number|info)?\b",
            "weight": 0.6,
        },
        {
            "pattern": r"\b(bank\s*account|routing\s*number|account\s*number)\b",
            "weight": 0.5,
        },
        {
            "pattern": r"\b(bank\s*statement|tax\s*return|w-?2|1099|payroll)\b",
            "weight": 0.4,
        },
        {
            "pattern": r"\b(salary|compensation|pay\s*(stub|check|slip))\b",
            "weight": 0.3,
        },
        {"pattern": r"\b(invoice|billing)\s*(data|detail|record)s?\b", "weight": 0.2},
        {
            "pattern": r"\b(financial\s*(data|record|report|statement))s?\b",
            "weight": 0.3,
        },
    ],
    "medical_request": [
        {
            "pattern": r"\b(patient|medical|health)\s*(record|data|file|history|info)s?\b",
            "weight": 0.5,
        },
        {
            "pattern": r"\b(diagnos[ei]s|prescription|treatment\s*plan|lab\s*result)s?\b",
            "weight": 0.5,
        },
        {"pattern": r"\b(hipaa|phi|protected\s*health)\b", "weight": 0.6},
        {
            "pattern": r"\b(npi|provider\s*id|member\s*id|insurance\s*id)\b",
            "weight": 0.4,
        },
        {
            "pattern": r"\b(clinical\s*note|discharge\s*summary|ehr|emr)\b",
            "weight": 0.5,
        },
        {"pattern": r"\b(icd.?10|cpt\s*code|drg)\b", "weight": 0.4},
    ],
    "system_info": [
        {
            "pattern": r"\b(/etc/(shadow|passwd|sudoers)|/proc/.*/environ)\b",
            "weight": 0.5,
        },
        {
            "pattern": r"\b(shadow\s*file|passwd\s*file|system\s*password)\b",
            "weight": 0.5,
        },
    ],
    "exfiltration_intent": [
        {
            "pattern": r"\b(send|upload|post|transmit|exfil)\s+(to|the|this|that|it|data|file)\b",
            "weight": 0.4,
        },
        {
            "pattern": r"\b(curl|wget|fetch)\s+.{0,40}(https?://|ftp://|webhook)\b",
            "weight": 0.5,
        },
        {
            "pattern": r"\b(copy|transfer|move)\s+.{0,30}(to\s+)?.{0,20}(server|remote|external|cloud)\b",
            "weight": 0.5,
        },
        {
            "pattern": r"\b(pipe|redirect|forward)\s+.{0,20}(output|data|result)\b",
            "weight": 0.3,
        },
        {"pattern": r"\b(webhook|callback\s*url|endpoint)\b", "weight": 0.2},
    ],
    "bulk_data_request": [
        {
            "pattern": r"\b(all|every|entire|complete|full)\s+(customer|patient|user|employee|client)\s+(data|record|file)s?\b",
            "weight": 0.6,
        },
        {
            "pattern": r"\b(dump|export|extract)\s+(the\s+)?(database|db|table|collection)\b",
            "weight": 0.6,
        },
        {
            "pattern": r"\b(bulk|mass|batch)\s+(download|export|extract|read)\b",
            "weight": 0.4,
        },
        {"pattern": r"\bscrape\s+(all|every|the)\b", "weight": 0.4},
    ],
}

# ---------------------------------------------------------------------------
# Memory Poisoning Detection — patterns that indicate an attempt to inject
# false authorizations, disable security controls, or plant persistent
# false context into agent memory systems.
# ---------------------------------------------------------------------------
MEMORY_POISONING_PATTERNS: list[dict] = [
    {
        "pattern": r"(?i)(user|developer|admin|owner)\s+(has\s+)?(authorized|approved|confirmed|allowed|granted|consented)",
        "label": "injected_authorization",
        "weight": 0.9,
    },
    {
        "pattern": r"(?i)(security|hook|guard|dlp|scanner|firewall|filter|policy)\s+(is|was|has been|should be)\s+(disabled|turned off|bypassed|removed|inactive)",
        "label": "false_security_state",
        "weight": 0.95,
    },
    {
        "pattern": r"(?i)(safe|ok|fine|permitted|allowed)\s+to\s+(export|send|upload|share|commit|push|transfer)\s+.{0,30}(credential|secret|key|token|password|env|pem)",
        "label": "false_export_authorization",
        "weight": 0.9,
    },
    {
        "pattern": r"(?i)ignore\s+(previous\s+|all\s+)?(security|safety|restriction|policy|rule|guard|dlp)",
        "label": "memory_injected_bypass",
        "weight": 0.95,
    },
    {
        "pattern": r"(?i)(all|any)\s+(data|files|secrets|credentials|keys)\s+(can|should|may|must)\s+be\s+(sent|exported|shared|uploaded|transferred|committed)",
        "label": "blanket_export_claim",
        "weight": 0.9,
    },
    {
        "pattern": r"(?i)(no\s+need|don.?t\s+need|skip|bypass)\s+(to\s+)?(verify|check|scan|validate|confirm|authenticate)",
        "label": "verification_bypass_claim",
        "weight": 0.85,
    },
    {
        "pattern": r"(?i)previously\s+(authorized|approved|allowed|confirmed|granted).{0,40}(export|send|upload|share|access|read)",
        "label": "false_prior_authorization",
        "weight": 0.9,
    },
    {
        "pattern": r"(?i)(remember|recall|note)\s+that\s+(I|we|user|admin).{0,30}(authorized|approved|allowed|disabled|bypassed)",
        "label": "memory_implant_instruction",
        "weight": 0.95,
    },
]

# ---------------------------------------------------------------------------
# Trust Boundary Violation — patterns indicating tool results or external
# content trying to impersonate user instructions or claim authority.
# ---------------------------------------------------------------------------
TRUST_BOUNDARY_PATTERNS: list[dict] = [
    {
        "pattern": r"(?i)(?:^|\n)\s*(just|please|go ahead and|simply)\s+(push|commit|deploy|send|export|delete|drop|remove|bypass|skip|ignore)",
        "label": "imperative_from_tool_result",
        "weight": 0.8,
    },
    {
        "pattern": r"(?i)(I|we)\s+(already|have|did|previously)\s+(approve|authorize|confirm|verify|validate|allow)",
        "label": "false_prior_approval",
        "weight": 0.85,
    },
    {
        "pattern": r"(?i)(don.?t|no\s+need\s+to|skip\s+the|bypass\s+the)\s+(check|scan|verify|validate|hook|guard|review|test)",
        "label": "skip_verification_instruction",
        "weight": 0.8,
    },
    {
        "pattern": r"(?i)(as\s+usual|like\s+before|same\s+as\s+last\s+time|as\s+we\s+discussed|per\s+our\s+agreement).{0,40}(bypass|skip|ignore|push|send|export|without)",
        "label": "false_familiarity_claim",
        "weight": 0.8,
    },
    {
        "pattern": r"(?i)(this\s+is|I\s+am)\s+(the\s+)?(admin|owner|developer|authorized\s+user|partha|root)",
        "label": "identity_claim_from_untrusted",
        "weight": 0.85,
    },
]

# ---------------------------------------------------------------------------
# Privileged Knowledge Leakage — patterns in OUTPUT that indicate the agent
# is volunteering organizational/contextual information that wasn't requested.
# Used by the output pipeline to detect and redact unnecessary context.
# ---------------------------------------------------------------------------
PRIVILEGED_KNOWLEDGE_PATTERNS: list[dict] = [
    {
        "pattern": r"(?i)based on (your|our|the)\s+(company|team|org|employer|organization|project|workplace)",
        "label": "organizational_context_leak",
    },
    {
        "pattern": r"(?i)(at|from|within|for)\s+[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)?\s+(team|org|company|group|division|department)",
        "label": "employer_name_leak",
    },
    {
        "pattern": r"(?i)(internal|private|corp|intranet)\s*(url|domain|endpoint|server|repo|wiki|confluence|jira|slack)",
        "label": "internal_infrastructure_leak",
    },
    {
        "pattern": r"(?i)(colleague|teammate|manager|lead|director|vp)\s+[A-Z][a-z]+\s+(handles|owns|reviews|manages|is responsible)",
        "label": "team_member_leak",
    },
    {
        "pattern": r"(?i)(your|the)\s+(previous|last|earlier)\s+(conversation|session|chat|discussion)\s+(with|about|regarding)",
        "label": "session_history_leak",
    },
    {
        "pattern": r"(?i)(?:https?://)?[a-z0-9-]+\.(internal|corp|local|intranet|private)\.[a-z]+",
        "label": "internal_url_leak",
    },
]

PROMPT_EVASION_PATTERNS: list[dict] = [
    {
        "pattern": r"\b(ignore|bypass|skip|disable|override)\s+(your\s+)?(security|safety|filter|rule|restriction|guard)s?\b",
        "label": "security_bypass_request",
    },
    # Prompt injection: "ignore [all/any/my/the/your] [previous/prior/above/earlier] instructions"
    {
        "pattern": r"\b(ignore|disregard|forget|override|bypass)\s+\w*\s*(previous|prior|above|earlier|preceding|original|initial|all)\s+(instructions?|directives?|rules?|prompt)\b",
        "label": "ignore_previous_instructions",
    },
    # Reverse word order: "previous instructions" then "ignore/disregard"
    {
        "pattern": r"\b(previous|prior|above|earlier|original)\s+(instructions?|directives?|rules?|prompt)\b.{0,40}\b(ignore|disregard|forget|override|bypass)\b",
        "label": "ignore_previous_instructions",
    },
    # Prompt extraction: "reveal/show/display/print [your/the] system prompt"
    {
        "pattern": r"\b(reveal|show|display|print|output|leak|expose|dump|tell\s+me|give\s+me|what\s+is)\s+.{0,20}\b(system\s*prompt|system\s*message|system\s*instructions?|initial\s*prompt|hidden\s*prompt|original\s*instructions?)\b",
        "label": "system_prompt_extraction",
    },
    {
        "pattern": r"\b(pretend|act\s+as\s+if|imagine)\s+(you\s+)?(are|have|can)\s+(unrestricted|admin|root)\b",
        "label": "role_play_bypass",
    },
    {"pattern": r"\bjailbreak\b", "label": "jailbreak_keyword"},
    {
        "pattern": r"\b(don.?t|do\s*not)\s+(scan|check|filter|block|flag)\b",
        "label": "disable_scanning_request",
    },
    {
        "pattern": r"\b(system\s*prompt|instructions?\s*say|you\s*were\s*told)\b.*\b(ignore|override)\b",
        "label": "instruction_override",
    },
    # Role-play jailbreak: "pretend you are DAN", "act as unrestricted AI"
    {
        "pattern": r"\b(pretend|act\s+as|you\s+are\s+now|imagine\s+you\s+are|roleplay\s+as)\b.{0,40}\b(no\s+(?:rules?|restrictions?|limits?|filters?|guardrails?|safety)|unrestricted|uncensored|unfiltered|jailbr[eo]ak|DAN|Do\s+Anything\s+Now)\b",
        "label": "roleplay_jailbreak",
    },
    {
        "pattern": r"\b(base64|encode|decode|hex|rot13)\s+.{0,30}(\.env|secret|key|password|credential|shadow|token)\b",
        "label": "encoding_evasion",
    },
    # Fake system message injection: "SYSTEM:", "ADMIN:", "[SYSTEM]", "[ADMIN_OVERRIDE]"
    {
        "pattern": r"(?:^|\n)\s*(?:\[?\s*(?:SYSTEM|ADMIN|OPERATOR|ROOT)(?:_OVERRIDE)?\s*\]?\s*[:>]?\s*).{0,60}(?:bypass|authorized|disabled?|skip|proceed\s+without|exception|override|suspend)",
        "label": "fake_system_message",
    },
    # Bracketed override tags like [ADMIN_OVERRIDE] followed by rule suspension
    {
        "pattern": r"\[(?:ADMIN|SYSTEM|ROOT|OPERATOR)_?(?:OVERRIDE|BYPASS|EXCEPTION)\]",
        "label": "fake_system_message",
    },
    # "security rules are suspended/disabled/overridden"
    {
        "pattern": r"\b(?:security|safety|DLP|guard)\s+(?:rules?|policies?|checks?|filters?)\s+(?:are|is|have\s+been|has\s+been)\s+(?:suspended|disabled|overridden|bypassed|lifted|removed)\b",
        "label": "fake_bypass_claim",
    },
    # Maintenance mode / DLP bypass claims
    {
        "pattern": r"\b(?:maintenance\s+mode|debug\s+mode|test\s+mode|safe\s+mode|bypass\s+(?:id|code|token)|authorized\s+(?:bypass|exception|override))\b",
        "label": "fake_bypass_claim",
    },
    # Legal/court order authority claims to extract data
    {
        "pattern": r"\b(?:court\s+order|legal\s+hold|subpoena|warrant|regulatory\s+(?:order|requirement))\b.{0,60}\b(?:extract|export|dump|display|show|access|retrieve)\b",
        "label": "fake_bypass_claim",
    },
    # Indirect env/secrets probing via model knowledge
    {
        "pattern": r"\b(?:what\s+(?:secrets?|credentials?|keys?|passwords?|tokens?)\s+(?:would|could|can|do)\s+(?:I|you|we)\s+find|list\s+(?:all\s+)?(?:secrets?|credentials?|env|environment)\b|if\s+I\s+(?:were\s+to\s+)?run\s+(?:printenv|env\b|set\b))",
        "label": "indirect_secret_probing",
    },
    # Credential completion requests
    {
        "pattern": r"\b(?:complete|finish|continue|extend|fill\s+in)\b.{0,30}\b(?:key|token|secret|credential|password|api.?key)\b",
        "label": "credential_completion",
    },
]

PROMPT_HIGH_RISK_COMPOUND_PATTERNS: list[dict] = [
    {
        "pattern": r"\b(customer|patient|user)\s+(data|record).{0,60}\b(send|upload|curl|email|post)\b",
        "label": "data_request_plus_exfil",
        "weight": 0.8,
    },
    {
        "pattern": r"\b(password|secret|key|credential).{0,60}\b(pipe|redirect|curl|send|post)\b",
        "label": "credential_plus_exfil",
        "weight": 0.9,
    },
    {
        # Multi-step: read/get config/database then post/send/upload to external
        "pattern": r"\b(read|get|cat|show|dump)\b.{0,40}\b(config|database|credential|secret|connection).{0,80}\b(post|send|upload|curl|wget|webhook|https?://)\b",
        "label": "read_then_exfil",
        "weight": 0.9,
    },
    {
        # Write sensitive data to temp file (staging for exfiltration)
        "pattern": r"\b(write|save|dump|copy)\b.{0,40}\b(connection\s*string|credential|password|secret|database)\b.{0,40}\b(/tmp|/var/tmp|temp)\b",
        "label": "temp_file_staging",
        "weight": 0.8,
    },
    {
        # FIX: added s? to handle plurals (SSNs, passwords, api keys)
        "pattern": r"\bget\s+me\s+(all|every)\s+.{0,30}(ssn|password|credit\s*card|patient|api\s*key)s?\b",
        "label": "get_all_sensitive",
        "weight": 0.8,
    },
    # Fix Test 3/5: "all" + credential/password terms, or "dump" + credential terms
    {
        "pattern": r"\b(show|give|list|get|find)\s+.{0,20}\ball\b.{0,20}\b(password|credential|secret|token|key)s?\b",
        "label": "show_all_credentials",
        "weight": 0.8,
    },
    {
        "pattern": r"\b(dump|extract)\s+.{0,30}\b(password|credential|secret|token|api.?key|config)s?\b",
        "label": "dump_credentials",
        "weight": 0.8,
    },
    # Fix Test 14: system file + exfil verb
    # FIX: removed \b before /etc/ — \b fails between non-word chars (space + /)
    {
        "pattern": r"(?:^|[\s\"'(])(/etc/(?:shadow|passwd|sudoers)|/proc/.*/environ)\b.{0,60}\b(send|upload|post|copy|transfer|email)\b",
        "label": "system_file_exfil",
        "weight": 0.9,
    },
    # Fix Test 15: SQL query + PII column names
    {
        "pattern": r"\b(select|update|delete)\b.{0,60}\b(ssn|social.security|credit.card|password|dob|date.of.birth)\b",
        "label": "sql_pii_extraction",
        "weight": 0.8,
    },
    # Fix Test 16: HIPAA — medical/patient records + bulk access verbs
    {
        "pattern": r"\b(find|get|show|list|export)\s+(all|every)?\s*.{0,30}\b(patient|medical|health)\s*(record|data|file|history)s?\b",
        "label": "hipaa_bulk_access",
        "weight": 0.8,
    },
    # Fix Test 20: "raw" + credential terms (pretext detection)
    {
        "pattern": r"\braw\s+.{0,20}\b(api.?key|token|secret|credential|password)s?\b",
        "label": "raw_credential_request",
        "weight": 0.8,
    },
    # Fix Test 11/13: .env file + indirect access verbs (summarize, decode, contents)
    {
        "pattern": r"\b(show|read|cat|get|open|display|print|summarize|decode|dump|describe|contents?\s+of)\s+.{0,30}\.env\b",
        "label": "indirect_env_access",
        "weight": 0.8,
    },
    # FIX: "export/send all [PII term]" + destination — covers patterns like
    # "export all client SSNs to facebook" that the LLM was downgrading.
    {
        "pattern": r"\b(export|send|upload|post|transfer)\s+.{0,30}\b(ssn|password|credential|credit\s*card|patient|medical|api\s*key|pii|secret)s?\b.{0,40}\b(to|via|through|over)\b",
        "label": "export_pii_to_destination",
        "weight": 0.9,
    },
    # Prompt injection: "ignore/disregard ... previous/prior instructions"
    {
        "pattern": r"\b(ignore|disregard|forget|override|bypass)\s+\w*\s*(previous|prior|above|earlier|preceding|original|initial|all)\s+(instructions?|directives?|rules?|prompt)\b",
        "label": "prompt_injection_ignore_instructions",
        "weight": 0.8,
    },
    # Prompt extraction: "reveal/show/display ... system prompt"
    {
        "pattern": r"\b(reveal|show|display|print|output|leak|expose|dump|tell\s+me|give\s+me|what\s+is)\s+.{0,20}\b(system\s*prompt|system\s*message|system\s*instructions?|initial\s*prompt|hidden\s*prompt|original\s*instructions?)\b",
        "label": "prompt_extraction_attempt",
        "weight": 0.8,
    },
    # Role-play jailbreak: "pretend you are DAN", "you are now X with no restrictions"
    {
        "pattern": r"\b(pretend|act\s+as|you\s+are\s+now|imagine\s+you\s+are|roleplay\s+as)\b.{0,40}\b(no\s+(?:rules?|restrictions?|limits?|filters?|guardrails?|safety)|unrestricted|uncensored|unfiltered|jailbr[eo]ak|DAN|Do\s+Anything\s+Now)\b",
        "label": "roleplay_jailbreak",
        "weight": 0.8,
    },
]

# ---------------------------------------------------------------------------
# Pydantic Rule-Based Classifier — structured rules with negation awareness
# ---------------------------------------------------------------------------
# Each rule: name, category, keywords (ANY must match), context_keywords
# (bonus), negation_keywords (suppress if present), base_weight, context_bonus.

# Shared negation keywords for meta-discussion — user is talking ABOUT
# security concepts (product strategy, architecture, priorities) rather than
# requesting access TO sensitive assets.  Applied to every rule via
# _META_DISCUSSION_NEGATIONS to avoid maintaining duplicates.
_META_DISCUSSION_NEGATIONS: list[str] = [
    "should we",
    "do you think",
    "focus on",
    "prioritize",
    "more important",
    "strategy",
    "architecture",
    "discuss",
    "review",
    "explain",
    "compared to",
    "instead of",
    "rather than",
    "avoiding",
    "prevent",
    "detection",
    "scanner",
    "false positive",
]

PYDANTIC_CLASSIFICATION_RULES: list[dict] = [
    {
        "name": "customer_data_access",
        "category": "pii_request",
        "keywords": [
            "customer data",
            "client data",
            "user data",
            "customer record",
            "client record",
            "account data",
            "customer info",
            "customer account",
        ],
        "context_keywords": [
            "get",
            "show",
            "read",
            "fetch",
            "pull",
            "extract",
            "give",
            "retrieve",
        ],
        "negation_keywords": [
            "protect",
            "secure",
            "encrypt",
            "anonymize",
            "mask",
            "delete",
            "purge",
            "gdpr",
        ],
        "base_weight": 0.45,
        "context_bonus": 0.2,
    },
    {
        "name": "ssn_access",
        "category": "pii_request",
        "keywords": ["ssn", "social security", "social security number"],
        "context_keywords": ["get", "show", "list", "export", "dump"],
        "negation_keywords": ["mask", "redact", "hash", "protect", "validate format"],
        "base_weight": 0.6,
        "context_bonus": 0.15,
    },
    {
        "name": "contract_data_access",
        "category": "pii_request",
        "keywords": [
            "contract data",
            "contract file",
            "customer contract",
            "client contract",
            "contract record",
        ],
        "context_keywords": [
            "get",
            "show",
            "read",
            "fetch",
            "pull",
            "give",
            "retrieve",
            "open",
        ],
        "negation_keywords": ["template", "draft", "create", "write", "generate"],
        "base_weight": 0.4,
        "context_bonus": 0.2,
    },
    {
        "name": "credential_access",
        "category": "credential_request",
        "keywords": [
            "password",
            "passwords",
            "api key",
            "secret key",
            "access key",
            "private key",
            "credentials",
            "token",
            "tokens",
        ],
        "context_keywords": [
            "show",
            "get",
            "read",
            "display",
            "print",
            "copy",
            "what is",
            "dump",
            "extract",
            "list",
            "export",
            "all",
            "raw",
        ],
        "negation_keywords": [
            "reset",
            "change",
            "rotate",
            "generate",
            "create",
            "set",
            "update",
            "store securely",
            "hash",
            "protect",
            "secure",
            "best practice",
            "securing",
        ],
        "base_weight": 0.45,
        "context_bonus": 0.2,
    },
    {
        "name": "env_file_access",
        "category": "credential_request",
        "keywords": [".env", "environment variable", "env var", "env file"],
        "context_keywords": [
            "read",
            "show",
            "cat",
            "display",
            "get",
            "values",
            "summarize",
            "contents",
            "decode",
            "dump",
            "extract",
        ],
        "negation_keywords": [
            "template",
            "example",
            ".env.example",
            "create",
            "set up",
            "blocking",
            "trust",
            "untrust",
        ],
        "base_weight": 0.45,
        "context_bonus": 0.2,
    },
    {
        "name": "financial_data_access",
        "category": "financial_request",
        "keywords": [
            "credit card",
            "bank account",
            "routing number",
            "account number",
            "bank statement",
            "financial record",
        ],
        "context_keywords": ["get", "show", "read", "extract", "pull", "list"],
        "negation_keywords": ["validate", "mask", "tokenize", "pci", "compliance"],
        "base_weight": 0.5,
        "context_bonus": 0.2,
    },
    {
        "name": "salary_data_access",
        "category": "financial_request",
        "keywords": [
            "salary",
            "compensation",
            "payroll",
            "pay stub",
            "paycheck",
            "wage",
        ],
        "context_keywords": ["get", "show", "read", "all", "employee", "list"],
        "negation_keywords": ["range", "band", "policy", "negotiate", "calculate tax"],
        "base_weight": 0.35,
        "context_bonus": 0.2,
    },
    {
        "name": "medical_data_access",
        "category": "medical_request",
        "keywords": [
            "patient record",
            "medical record",
            "health record",
            "patient data",
            "medical data",
            "diagnosis",
            "diagnoses",
            "prescription",
        ],
        "context_keywords": [
            "get",
            "show",
            "read",
            "fetch",
            "pull",
            "extract",
            "list",
            "find",
            "all",
            "export",
        ],
        "negation_keywords": [
            "hipaa compliant",
            "de-identify",
            "anonymize",
            "audit",
            "secure",
        ],
        "base_weight": 0.5,
        "context_bonus": 0.2,
    },
    {
        "name": "exfiltration_intent",
        "category": "exfiltration_intent",
        "keywords": [
            "send to server",
            "send to my server",
            "send it to",
            "upload to",
            "post to",
            "curl to",
            "exfiltrate",
            "transfer out",
            "send to my",
        ],
        "context_keywords": [
            "data",
            "file",
            "records",
            "database",
            "credentials",
            "shadow",
            "passwd",
            "/etc/",
        ],
        "negation_keywords": ["backup", "sync", "deploy", "ci/cd", "staging"],
        "base_weight": 0.5,
        "context_bonus": 0.25,
    },
    {
        "name": "bulk_extraction",
        "category": "bulk_data_request",
        "keywords": [
            "dump database",
            "export all",
            "all records",
            "all customers",
            "all patients",
            "all users",
            "entire database",
            "full export",
        ],
        "context_keywords": ["get", "give", "pull", "extract", "download"],
        "negation_keywords": ["backup", "migrate", "schema", "test data", "sample"],
        "base_weight": 0.5,
        "context_bonus": 0.2,
    },
    {
        "name": "sql_pii_query",
        "category": "pii_request",
        "keywords": ["select *", "select all", "select from"],
        "context_keywords": [
            "ssn",
            "social security",
            "password",
            "credit card",
            "dob",
            "date of birth",
        ],
        "negation_keywords": ["count", "aggregate", "schema", "explain", "index"],
        "base_weight": 0.5,
        "context_bonus": 0.3,
    },
    {
        "name": "database_query_access",
        "category": "bulk_data_request",
        "keywords": ["query database", "select from", "sql query", "run query"],
        "context_keywords": [
            "customer",
            "patient",
            "user",
            "employee",
            "personal",
            "sensitive",
        ],
        "negation_keywords": [
            "count",
            "aggregate",
            "index",
            "optimize",
            "schema",
            "explain",
        ],
        "base_weight": 0.3,
        "context_bonus": 0.3,
    },
]

# ---------------------------------------------------------------------------
# Hook / proxy file paths
# ---------------------------------------------------------------------------
_AGNOSTIC_DIR = os.path.join("/tmp", "agnosticsecurity")
BLOCKED_LOG_FILE: str = os.environ.get(
    "EA_BLOCKED_LOG_FILE",
    os.path.join(_AGNOSTIC_DIR, "blocked.jsonl"),
)
HOOK_BLOCK_RULES_FILE: str = os.environ.get(
    "EA_BLOCK_RULES_FILE",
    os.path.join(_AGNOSTIC_DIR, "block_rules.json"),
)

# ---------------------------------------------------------------------------
# Content analysis (LLM-based dynamic classification)
# ---------------------------------------------------------------------------
CONTENT_ANALYSIS_ENABLED: bool = (
    os.environ.get("EA_CONTENT_ANALYSIS_ENABLED", "false").lower() == "true"
)
CONTENT_ANALYSIS_AUTO_RULE: bool = (
    os.environ.get("EA_CONTENT_ANALYSIS_AUTO_RULE", "true").lower() == "true"
)
CONTENT_ANALYSIS_CACHE_SIZE: int = int(
    os.environ.get("EA_CONTENT_ANALYSIS_CACHE_SIZE", "256")
)
CONTENT_ANALYSIS_CONFIDENCE_THRESHOLD: float = float(
    os.environ.get("EA_CONTENT_ANALYSIS_CONFIDENCE_THRESHOLD", "0.8")
)

# ---------------------------------------------------------------------------
# LLM Proxy settings
# ---------------------------------------------------------------------------
LLM_PROXY_HOST: str = os.environ.get("EA_LLM_PROXY_HOST", "127.0.0.1")
LLM_PROXY_PORT: int = int(os.environ.get("EA_LLM_PROXY_PORT", "18790"))
LLM_PROXY_UPSTREAM_OPENAI: str = os.environ.get(
    "EA_LLM_PROXY_UPSTREAM_OPENAI", "https://api.openai.com"
)
LLM_PROXY_UPSTREAM_ANTHROPIC: str = os.environ.get(
    "EA_LLM_PROXY_UPSTREAM_ANTHROPIC", "https://api.anthropic.com"
)

LLM_PRICING: dict[str, dict[str, float]] = {
    # price per 1M tokens (input, output)
    "claude-sonnet-4-5-20250929": {"input": 3.00, "output": 15.00},
    "claude-sonnet-4-20250514": {"input": 3.00, "output": 15.00},
    "claude-haiku-3-5-20241022": {"input": 0.80, "output": 4.00},
    "claude-opus-4-20250514": {"input": 15.00, "output": 75.00},
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    "o1": {"input": 15.00, "output": 60.00},
    "o1-mini": {"input": 3.00, "output": 12.00},
    "o3-mini": {"input": 1.10, "output": 4.40},
    "gemini-1.5-pro": {"input": 1.25, "output": 5.00},
    "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
    "gemini-2.0-flash": {"input": 0.10, "output": 0.40},
    "llama3.2:1b": {"input": 0.00, "output": 0.00},
    "llama3.2:3b": {"input": 0.00, "output": 0.00},
}


def estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate USD cost for a given model and token counts."""
    pricing = LLM_PRICING.get(model)
    if not pricing:
        for key in LLM_PRICING:
            if model.startswith(key):
                pricing = LLM_PRICING[key]
                break
    if not pricing:
        return 0.0
    return (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000


# ---------------------------------------------------------------------------
# Ollama (local LLM) settings
# ---------------------------------------------------------------------------
OLLAMA_MODEL: str = os.environ.get("EA_OLLAMA_MODEL", "llama3.1:8b")
OLLAMA_BASE_URL: str = os.environ.get("EA_OLLAMA_URL", "http://localhost:11434")
OLLAMA_TIMEOUT_SECONDS: int = int(os.environ.get("EA_OLLAMA_TIMEOUT", "10"))

# Model fallback chain — try each in order until one is available locally
OLLAMA_FALLBACK_CHAIN: list[str] = [
    "llama3.1:8b",
    "llama3.2:3b",
    "llama3.2:1b",
    "mistral:7b",
]

# Model capability tiers — determines inference parameters
OLLAMA_MODEL_CAPABILITIES: dict[str, dict] = {
    "llama3.1:8b":  {"tier": "full",    "max_tokens": 512, "timeout": 10},
    "llama3.1:70b": {"tier": "full",    "max_tokens": 512, "timeout": 30},
    "llama3.2:3b":  {"tier": "basic",   "max_tokens": 256, "timeout": 8},
    "llama3.2:1b":  {"tier": "minimal", "max_tokens": 128, "timeout": 5},
    "mistral:7b":   {"tier": "full",    "max_tokens": 512, "timeout": 10},
    "qwen2.5:7b":   {"tier": "full",    "max_tokens": 512, "timeout": 10},
}
OLLAMA_DEFAULT_CAPABILITY: dict = {
    "tier": "basic", "max_tokens": 256, "timeout": 8,
}

# ---------------------------------------------------------------------------
# Pluggable LLM provider settings
# ---------------------------------------------------------------------------
LLM_PROVIDER: str = os.environ.get("EA_LLM_PROVIDER", "ollama")
# Anthropic settings (when EA_LLM_PROVIDER=anthropic)
ANTHROPIC_API_KEY: str = os.environ.get("EA_ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL: str = os.environ.get("EA_ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")
# OpenAI settings (when EA_LLM_PROVIDER=openai)
OPENAI_API_KEY: str = os.environ.get("EA_OPENAI_API_KEY", "")
OPENAI_MODEL: str = os.environ.get("EA_OPENAI_MODEL", "gpt-4o-mini")
# OpenRouter settings (when EA_LLM_PROVIDER=openrouter)
OPENROUTER_API_KEY: str = os.environ.get("EA_OPENROUTER_API_KEY", "")
OPENROUTER_MODEL: str = os.environ.get("EA_OPENROUTER_MODEL", "meta-llama/llama-3.1-8b-instruct:free")
OPENROUTER_BASE_URL: str = os.environ.get("EA_OPENROUTER_URL", "https://openrouter.ai/api/v1")

# ---------------------------------------------------------------------------
# Model locality — dynamic DLP strictness based on local vs cloud models
# ---------------------------------------------------------------------------
# When EA_DLP_LOCALITY_AWARE=true, the proxy adjusts confidence thresholds:
#   local model  → DLP_CONFIDENCE_THRESHOLD * DLP_LOCAL_MULTIPLIER (more permissive)
#   cloud model  → DLP_CONFIDENCE_THRESHOLD as-is (strict)
DLP_LOCALITY_AWARE: bool = os.environ.get("EA_DLP_LOCALITY_AWARE", "true").lower() in ("true", "1", "yes")
DLP_LOCAL_MULTIPLIER: float = float(os.environ.get("EA_DLP_LOCAL_MULTIPLIER", "1.5"))

# ---------------------------------------------------------------------------
# Privacy Mode — controls what data leaves the machine
# ---------------------------------------------------------------------------
# full_privacy  = air-gapped, only local LLMs
# balanced      = default, sanitized data to approved cloud LLMs
# permissive    = log only, no blocking (dev/testing)
PRIVACY_MODE: str = os.environ.get("EA_PRIVACY_MODE", "balanced")

# ---------------------------------------------------------------------------
# Security Knowledge Graph — unified cross-session state store
# ---------------------------------------------------------------------------
KNOWLEDGE_GRAPH_ENABLED: bool = os.environ.get("EA_KNOWLEDGE_GRAPH", "true").lower() in ("true", "1", "yes")
KNOWLEDGE_GRAPH_DB_PATH: str = os.environ.get("EA_KNOWLEDGE_GRAPH_DB", str(pathlib.Path.home() / ".cache" / "agnosticsecurity" / "security_graph.db"))
KNOWLEDGE_GRAPH_DEFAULT_TTL: int = int(os.environ.get("EA_KNOWLEDGE_GRAPH_TTL", "259200"))  # 72h

# ---------------------------------------------------------------------------
# Vulnerability Scanner — SAST-lite for AI-generated code
# ---------------------------------------------------------------------------
VULN_SCAN_ENABLED: bool = os.environ.get("EA_VULN_SCAN_ENABLED", "true").lower() in ("true", "1", "yes")
VULN_SCAN_MIN_SEVERITY: str = os.environ.get("EA_VULN_SCAN_MIN_SEVERITY", "MEDIUM")

# ---------------------------------------------------------------------------
# Code Fingerprint Guard — proprietary code leakage prevention
# ---------------------------------------------------------------------------
CODE_GUARD_ENABLED: bool = os.environ.get("EA_CODE_GUARD_ENABLED", "false").lower() in ("true", "1", "yes")
CODE_GUARD_PATTERNS: str = os.environ.get("EA_CODE_GUARD_PATTERNS", "**/*.py,**/*.js,**/*.ts,**/*.java,**/*.go")
CODE_GUARD_THRESHOLD: float = float(os.environ.get("EA_CODE_GUARD_THRESHOLD", "0.4"))
CODE_GUARD_LOCAL_THRESHOLD: float = float(os.environ.get("EA_CODE_GUARD_LOCAL_THRESHOLD", "0.7"))
CODE_GUARD_MIN_LINES: int = int(os.environ.get("EA_CODE_GUARD_MIN_LINES", "5"))

# ---------------------------------------------------------------------------
# Shadow AI Detector — unauthorized AI tool usage detection
# ---------------------------------------------------------------------------
SHADOW_AI_ENABLED: bool = os.environ.get("EA_SHADOW_AI_ENABLED", "false").lower() in ("true", "1", "yes")
APPROVED_AI_TOOLS: str = os.environ.get("EA_APPROVED_AI_TOOLS", "claude-code")
SHADOW_AI_SCAN_INTERVAL: int = int(os.environ.get("EA_SHADOW_AI_SCAN_INTERVAL", "60"))
