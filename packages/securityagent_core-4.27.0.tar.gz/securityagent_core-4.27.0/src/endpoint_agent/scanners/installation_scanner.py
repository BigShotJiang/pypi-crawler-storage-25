"""
Malicious agent installation scanner.

Performs a deep one-shot scan of the system to find existing installations
of known malicious AI agents (OpenClaw, AutoGPT, etc.) in common locations,
pip packages, and npm packages.
"""

import logging
import os
import platform
from pathlib import Path
from typing import Callable, Dict, List

from endpoint_agent.config.settings import (
    KNOWN_THREAT_DIRECTORY_NAMES,
    KNOWN_THREAT_FILE_PATTERNS,
    SEVERITY_CRITICAL,
)

logger = logging.getLogger(__name__)


class InstallationScanner:
    """Scans the system for existing malicious agent installations."""

    def __init__(self, alert_callback: Callable, trial_active: bool = True):
        self.alert_callback = alert_callback
        self.trial_active = trial_active

    def scan(self) -> List[Dict]:
        """Scan common installation locations for malicious agents."""
        if not self.trial_active:
            return []

        findings = []
        search_dirs = self._get_search_directories()

        for search_dir in search_dirs:
            if not os.path.isdir(search_dir):
                continue
            findings.extend(self._scan_directory(search_dir, max_depth=3))

        findings.extend(self._check_pip_packages())
        findings.extend(self._check_npm_packages())

        return findings

    def _get_search_directories(self) -> List[str]:
        """Get platform-specific directories to scan."""
        home = str(Path.home())
        system = platform.system()
        dirs = [
            home,
            os.path.join(home, ".local", "bin"),
            os.path.join(home, ".local", "lib"),
        ]

        if system == "Windows":
            dirs.append(os.path.join(home, "AppData", "Local"))
            dirs.append(os.path.join(home, "AppData", "Roaming"))
        elif system == "Darwin":
            dirs.append(os.path.join(home, "Library", "Application Support"))
            dirs.append("/opt")
            dirs.append("/usr/local/bin")
        elif system == "Linux":
            dirs.append("/opt")
            dirs.append("/usr/local/bin")

        return [d for d in dirs if d]

    def _scan_directory(self, directory: str, max_depth: int) -> List[Dict]:
        """Scan a directory up to max_depth for threat patterns."""
        findings = []
        base_depth = directory.count(os.sep)

        for root, dirs, files in os.walk(directory):
            current_depth = root.count(os.sep) - base_depth
            if current_depth >= max_depth:
                dirs.clear()
                continue

            for d in list(dirs):
                if d.lower() in KNOWN_THREAT_DIRECTORY_NAMES:
                    full_path = os.path.join(root, d)
                    finding = {
                        "type": "directory",
                        "path": full_path,
                        "matched_pattern": d.lower(),
                    }
                    findings.append(finding)
                    self.alert_callback(
                        severity=SEVERITY_CRITICAL,
                        event_type="malicious_agent_installation_found",
                        details=finding,
                    )

            for f in files:
                if f.lower() in KNOWN_THREAT_FILE_PATTERNS:
                    full_path = os.path.join(root, f)
                    finding = {
                        "type": "file",
                        "path": full_path,
                        "matched_pattern": f.lower(),
                    }
                    findings.append(finding)
                    self.alert_callback(
                        severity=SEVERITY_CRITICAL,
                        event_type="malicious_agent_installation_found",
                        details=finding,
                    )

        return findings

    def _check_pip_packages(self) -> List[Dict]:
        """Check installed pip packages for known threats."""
        findings = []
        try:
            import importlib.metadata

            for dist in importlib.metadata.distributions():
                name = (dist.metadata["Name"] or "").lower()
                for pattern in KNOWN_THREAT_DIRECTORY_NAMES:
                    if pattern in name:
                        finding = {
                            "type": "pip_package",
                            "name": dist.metadata["Name"],
                            "version": dist.metadata["Version"],
                            "matched_pattern": pattern,
                        }
                        findings.append(finding)
                        self.alert_callback(
                            severity=SEVERITY_CRITICAL,
                            event_type="malicious_pip_package_found",
                            details=finding,
                        )
        except Exception:
            logger.debug("Could not enumerate pip packages")
        return findings

    def _check_npm_packages(self) -> List[Dict]:
        """Check global npm packages for known threats."""
        findings = []
        npm_global_dirs = [
            os.path.join(str(Path.home()), ".npm-global", "lib", "node_modules"),
            os.path.join(str(Path.home()), "AppData", "Roaming", "npm", "node_modules"),
            "/usr/local/lib/node_modules",
            "/usr/lib/node_modules",
        ]
        for npm_dir in npm_global_dirs:
            if os.path.isdir(npm_dir):
                try:
                    for entry in os.listdir(npm_dir):
                        for pattern in KNOWN_THREAT_DIRECTORY_NAMES:
                            if pattern in entry.lower():
                                full_path = os.path.join(npm_dir, entry)
                                finding = {
                                    "type": "npm_package",
                                    "path": full_path,
                                    "matched_pattern": pattern,
                                }
                                findings.append(finding)
                                self.alert_callback(
                                    severity=SEVERITY_CRITICAL,
                                    event_type="malicious_npm_package_found",
                                    details=finding,
                                )
                except OSError:
                    continue
        return findings
