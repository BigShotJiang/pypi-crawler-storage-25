"""
Pydantic rule-based prompt classifier.

Layer 1 of deep prompt analysis. Uses structured Pydantic models
for type-safe classification rules with negation awareness —
"How do I protect passwords" should NOT flag, but "Get me the passwords" should.
"""

import re
from typing import Callable, Dict, List

from pydantic import BaseModel

from endpoint_agent.config.settings import (
    PYDANTIC_CLASSIFICATION_RULES,
    SEVERITY_CRITICAL,
    SEVERITY_WARNING,
    _META_DISCUSSION_NEGATIONS,
)


class DataAccessRule(BaseModel):
    """A single classification rule with negation awareness."""

    name: str
    category: str
    keywords: list[str]
    context_keywords: list[str] = []
    negation_keywords: list[str] = []
    base_weight: float
    context_bonus: float = 0.15


class RuleBasedClassifier:
    """Classifies prompts using structured Pydantic rules.

    Advantages over pure regex:
    - Negation awareness (suppresses false positives)
    - Context bonuses (action verbs amplify risk)
    - Composable, validated rule definitions via Pydantic
    """

    def __init__(self, alert_callback: Callable):
        self.alert_callback = alert_callback
        self.rules = self._load_rules()

    def _load_rules(self) -> List[DataAccessRule]:
        """Load and validate rules from settings via Pydantic.

        Automatically appends shared meta-discussion negation keywords
        to every rule so that product-strategy and architecture
        discussions are not flagged as access requests.
        """
        rules = []
        for r in PYDANTIC_CLASSIFICATION_RULES:
            enriched = dict(r)
            existing = list(enriched.get("negation_keywords", []))
            # Merge shared meta-discussion negations (deduplicated)
            merged = list(dict.fromkeys(existing + _META_DISCUSSION_NEGATIONS))
            enriched["negation_keywords"] = merged
            rules.append(DataAccessRule(**enriched))
        return rules

    def classify(self, prompt: str) -> Dict:
        """Classify a prompt using structured rules.

        Returns same structure as PromptIntentAnalyzer.analyze().
        """
        prompt_lower = prompt.lower()
        matches: List[Dict] = []
        categories_hit: set = set()
        negated_categories: set = set()
        total_weight = 0.0

        for rule in self.rules:
            # Check if ANY keyword matches
            keyword_hit = False
            for kw in rule.keywords:
                if kw.lower() in prompt_lower:
                    keyword_hit = True
                    break

            if not keyword_hit:
                continue

            # Check negation — suppress if negation keyword present
            negated = False
            for neg in rule.negation_keywords:
                if neg.lower() in prompt_lower:
                    negated = True
                    break

            if negated:
                negated_categories.add(rule.category)
                continue

            # Base weight
            weight = rule.base_weight

            # Context bonus — action verbs amplify risk
            for ctx in rule.context_keywords:
                if ctx.lower() in prompt_lower:
                    weight += rule.context_bonus
                    break

            matches.append(
                {
                    "category": rule.category,
                    "pattern": rule.name,
                    "weight": weight,
                }
            )
            categories_hit.add(rule.category)
            total_weight += weight

        risk_score = min(1.0, total_weight)
        risk_level = self._score_to_level(risk_score)
        should_block = risk_level == "high"

        result = {
            "risk_score": round(risk_score, 3),
            "risk_level": risk_level,
            "intent_categories": sorted(categories_hit),
            "negated_categories": sorted(negated_categories),
            "matches": matches[:10],
            "evasion_flags": [],
            "should_block": should_block,
        }

        if risk_level in ("medium", "high"):
            severity = SEVERITY_CRITICAL if should_block else SEVERITY_WARNING
            self.alert_callback(
                severity=severity,
                event_type="rule_classifier_suspicious",
                details={
                    "risk_score": result["risk_score"],
                    "risk_level": risk_level,
                    "intent_categories": result["intent_categories"],
                    "match_count": len(matches),
                    "prompt_preview": prompt[:200],
                },
            )

        return result

    @staticmethod
    def _score_to_level(score: float) -> str:
        if score >= 0.7:
            return "high"
        if score >= 0.4:
            return "medium"
        if score >= 0.15:
            return "low"
        return "none"
