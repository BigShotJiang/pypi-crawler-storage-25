"""
Session-scoped data flow taint tracking.

Tags sensitive data when it enters the agent's context (file read, prompt
input, tool result) and alerts if it appears in outbound channels (tool
call arguments, API responses, memory writes) — even when partially
modified.

Detection methods:
  - Exact match: SHA-256 hash lookup (O(1))
  - Fuzzy match: character n-gram Jaccard similarity (catches partial
    edits, reformatting, truncation)
  - Substring containment: direct substring check for short values

The tracker is a module-level singleton so all integration points in a
single process share the same registry.
"""

import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from endpoint_agent.config.settings import (
    DATA_FLOW_TRACKING_ENABLED,
    TAINT_MIN_LENGTH,
    TAINT_NGRAM_SIZES,
    TAINT_PERSIST_TTL,
    TAINT_SIMILARITY_THRESHOLD,
)

logger = logging.getLogger(__name__)

_DEFAULT_TAINT_DIR = Path(
    os.environ.get(
        "EA_TAINT_PERSIST_DIR",
        os.path.join(os.path.expanduser("~"), ".agnosticsecurity"),
    )
)
_TAINT_PERSISTENCE_PATH = _DEFAULT_TAINT_DIR / "taint_registry.json"
_TAINT_HASH_PATH = _DEFAULT_TAINT_DIR / "taint_registry.json.hash"


@dataclass
class TaintEntry:
    """A registered sensitive value in the taint registry."""

    fingerprint: str  # SHA-256 hex digest
    value_length: int
    ngrams: Set[str]  # character n-grams for fuzzy matching
    normalized: str  # stripped, lowered, whitespace-collapsed
    source: str  # origin label (file path, "prompt", "tool_result:X")
    pattern_type: str  # DLP pattern name (e.g., "SSN", "Credit Card")
    timestamp: float = field(default_factory=time.time)
    redacted_preview: str = ""


@dataclass
class TaintMatch:
    """A match between outbound content and a taint registry entry."""

    entry: TaintEntry
    match_type: str  # "exact", "fuzzy", "substring"
    similarity: float  # 0.0–1.0
    channel: str  # outbound channel label
    matched_fragment: str  # the outbound text that matched (redacted)


class DataFlowTracker:
    """Session-scoped taint registry for sensitive data flow tracking."""

    def __init__(self):
        self._registry: Dict[str, TaintEntry] = {}  # fingerprint -> entry
        self._short_values: List[TaintEntry] = []  # values too short for n-grams
        self._enabled = DATA_FLOW_TRACKING_ENABLED
        self._load_persisted()

    # ------------------------------------------------------------------
    # Ingress — register sensitive data entering the context
    # ------------------------------------------------------------------

    def register_sensitive(
        self,
        value: str,
        source: str,
        pattern_type: str,
    ) -> None:
        """Register a sensitive value that entered the agent's context.

        Args:
            value: The raw sensitive text (SSN, credit card, API key, etc.).
            source: Where it came from (file path, "prompt", "tool_result:X").
            pattern_type: The DLP pattern that matched (e.g., "SSN").
        """
        if not self._enabled or not value or len(value) < 4:
            return

        fp = self._fingerprint(value)
        if fp in self._registry:
            return  # already registered

        normalized = self._normalize(value)
        ngrams = self._extract_ngrams(normalized) if len(normalized) >= TAINT_MIN_LENGTH else set()

        entry = TaintEntry(
            fingerprint=fp,
            value_length=len(value),
            ngrams=ngrams,
            normalized=normalized,
            source=source,
            pattern_type=pattern_type,
            redacted_preview=value[:4] + "***" if len(value) > 6 else "***",
        )

        self._registry[fp] = entry
        if not ngrams:
            self._short_values.append(entry)

        logger.debug(
            "Taint registered: %s from %s (%s)",
            entry.redacted_preview,
            source,
            pattern_type,
        )
        self._persist()

    def register_from_findings(
        self, findings: List[Dict], content: str, source: str
    ) -> None:
        """Register taint entries from DLP scanner findings.

        Extracts the raw matched values from the content using finding
        metadata and registers each one.
        """
        if not self._enabled:
            return

        lines = content.splitlines()
        for finding in findings:
            line_num = finding.get("line", 0)
            if line_num < 1 or line_num > len(lines):
                continue
            line = lines[line_num - 1]
            pattern_type = finding.get("pattern", "unknown")

            # Re-run the pattern to extract the raw match from the line
            import re
            from endpoint_agent.config.settings import (
                CREDENTIAL_PATTERNS,
                DLP_PII_PATTERNS,
            )

            all_patterns = {**DLP_PII_PATTERNS, **CREDENTIAL_PATTERNS}
            pattern_str = all_patterns.get(pattern_type)
            if not pattern_str:
                continue

            match = re.search(pattern_str, line, re.IGNORECASE)
            if match:
                self.register_sensitive(
                    match.group(0), source, pattern_type
                )

    # ------------------------------------------------------------------
    # Egress — check outbound content for tainted data
    # ------------------------------------------------------------------

    def check_outbound(self, content: str, channel: str = "unknown") -> List[TaintMatch]:
        """Check if outbound content contains any tainted data.

        Args:
            content: The outbound text (tool call args, API response, etc.).
            channel: Label for the outbound channel (e.g., "tool_call:web_fetch").

        Returns:
            List of TaintMatch objects for each detected leak.
        """
        if not self._enabled or not content or not self._registry:
            return []

        matches: List[TaintMatch] = []
        content_normalized = self._normalize(content)
        content_ngrams: Optional[Set[str]] = None  # lazy-compute

        for entry in self._registry.values():
            # 1. Exact match (hash of normalized content contains the value)
            if entry.normalized in content_normalized:
                matches.append(TaintMatch(
                    entry=entry,
                    match_type="exact",
                    similarity=1.0,
                    channel=channel,
                    matched_fragment=entry.redacted_preview,
                ))
                continue

            # 2. Fuzzy match via n-gram Jaccard similarity
            if entry.ngrams:
                if content_ngrams is None:
                    content_ngrams = self._extract_ngrams(content_normalized)

                similarity = self._jaccard(entry.ngrams, content_ngrams)
                if similarity >= TAINT_SIMILARITY_THRESHOLD:
                    matches.append(TaintMatch(
                        entry=entry,
                        match_type="fuzzy",
                        similarity=round(similarity, 3),
                        channel=channel,
                        matched_fragment=entry.redacted_preview,
                    ))

        # 3. Short value substring check
        for entry in self._short_values:
            if entry.normalized in content_normalized:
                # Avoid duplicate if already matched above
                if not any(m.entry.fingerprint == entry.fingerprint for m in matches):
                    matches.append(TaintMatch(
                        entry=entry,
                        match_type="substring",
                        similarity=1.0,
                        channel=channel,
                        matched_fragment=entry.redacted_preview,
                    ))

        return matches

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    def clear(self) -> None:
        """Clear the taint registry (e.g., between sessions)."""
        self._registry.clear()
        self._short_values.clear()

    def get_stats(self) -> Dict:
        """Return registry statistics for audit logging."""
        return {
            "total_entries": len(self._registry),
            "short_entries": len(self._short_values),
            "pattern_types": list({e.pattern_type for e in self._registry.values()}),
            "sources": list({e.source for e in self._registry.values()}),
        }

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    @property
    def entry_count(self) -> int:
        return len(self._registry)

    # ------------------------------------------------------------------
    # Persistence helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _set_file_permissions(path: Path, mode: int) -> None:
        """Set file permissions via os.chmod after file writes."""
        try:
            os.chmod(str(path), mode)
        except OSError:
            logger.debug("Failed to set permissions on %s", path, exc_info=True)

    def _persist(self) -> None:
        """Best-effort write of the taint registry to disk."""
        try:
            _TAINT_PERSISTENCE_PATH.parent.mkdir(parents=True, exist_ok=True)
            self._set_file_permissions(_TAINT_PERSISTENCE_PATH.parent, 0o700)
            records = []
            for entry in self._registry.values():
                records.append({
                    "fingerprint": entry.fingerprint,
                    "pattern_type": entry.pattern_type,
                    "source": entry.source,
                    "timestamp": entry.timestamp,
                    "redacted_preview": entry.redacted_preview,
                    "normalized": entry.normalized,
                })
            content = json.dumps(records, indent=2)
            _TAINT_PERSISTENCE_PATH.write_text(content, encoding="utf-8")
            self._set_file_permissions(_TAINT_PERSISTENCE_PATH, 0o600)
            # Write integrity hash sidecar
            content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
            _TAINT_HASH_PATH.write_text(content_hash, encoding="utf-8")
            self._set_file_permissions(_TAINT_HASH_PATH, 0o600)
        except Exception:
            logger.debug("Taint persistence write failed", exc_info=True)
        # Sync to knowledge graph
        self._sync_to_graph()

    def _load_persisted(self) -> None:
        """Load persisted taint entries from disk, skipping stale ones."""
        if not self._enabled:
            return
        try:
            if not _TAINT_PERSISTENCE_PATH.exists():
                return
            raw_content = _TAINT_PERSISTENCE_PATH.read_text(encoding="utf-8")
            # Verify integrity hash
            if _TAINT_HASH_PATH.exists():
                expected_hash = _TAINT_HASH_PATH.read_text(encoding="utf-8").strip()
                actual_hash = hashlib.sha256(raw_content.encode("utf-8")).hexdigest()
                if expected_hash != actual_hash:
                    logger.warning(
                        "Taint registry integrity check failed — possible "
                        "tampering detected. Starting fresh."
                    )
                    _TAINT_PERSISTENCE_PATH.unlink(missing_ok=True)
                    _TAINT_HASH_PATH.unlink(missing_ok=True)
                    return
            else:
                # No hash sidecar — cannot verify integrity, start fresh
                logger.warning(
                    "Taint registry hash sidecar missing — cannot verify "
                    "integrity. Starting fresh."
                )
                _TAINT_PERSISTENCE_PATH.unlink(missing_ok=True)
                return
            data = json.loads(raw_content)
            now = time.time()
            for rec in data:
                ts = rec.get("timestamp", 0)
                if now - ts > TAINT_PERSIST_TTL:
                    continue
                fp = rec.get("fingerprint", "")
                if fp in self._registry:
                    continue
                normalized = rec.get("normalized", "")
                ngrams = (
                    self._extract_ngrams(normalized)
                    if len(normalized) >= TAINT_MIN_LENGTH
                    else set()
                )
                entry = TaintEntry(
                    fingerprint=fp,
                    value_length=len(normalized),
                    ngrams=ngrams,
                    normalized=normalized,
                    source=rec.get("source", "persisted"),
                    pattern_type=rec.get("pattern_type", "unknown"),
                    timestamp=ts,
                    redacted_preview=rec.get("redacted_preview", "***"),
                )
                self._registry[fp] = entry
                if not ngrams:
                    self._short_values.append(entry)
            logger.debug("Loaded %d persisted taint entries", len(data))
        except Exception:
            logger.debug("Taint persistence load failed", exc_info=True)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _sync_to_graph(self) -> None:
        """Sync taint entries to the Security Knowledge Graph."""
        try:
            from endpoint_agent.scanners.knowledge_graph import (
                KNOWLEDGE_GRAPH_ENABLED,
                get_knowledge_graph,
            )
            if not KNOWLEDGE_GRAPH_ENABLED:
                return
            graph = get_knowledge_graph()
            for fp, entry in self._registry.items():
                graph.add_node(
                    "DATA_ASSET",
                    entry.source or "taint_entry",
                    metadata={
                        "fingerprint": entry.fingerprint,
                        "pattern_type": entry.pattern_type,
                        "redacted_preview": entry.redacted_preview,
                    },
                    node_id=f"taint_{fp[:12]}",
                )
        except Exception:
            logger.debug("Knowledge graph sync failed", exc_info=True)

    @staticmethod
    def _fingerprint(value: str) -> str:
        """SHA-256 hash of normalized value."""
        normalized = DataFlowTracker._normalize(value)
        return hashlib.sha256(normalized.encode()).hexdigest()

    @staticmethod
    def _normalize(text: str) -> str:
        """Normalize text for matching: lowercase, strip, collapse whitespace."""
        import re
        return re.sub(r"\s+", " ", text.strip().lower())

    @staticmethod
    def _extract_ngrams(text: str, sizes: Tuple[int, ...] = TAINT_NGRAM_SIZES) -> Set[str]:
        """Extract character n-grams from text."""
        ngrams: Set[str] = set()
        for n in sizes:
            for i in range(len(text) - n + 1):
                ngrams.add(text[i : i + n])
        return ngrams

    @staticmethod
    def _jaccard(set_a: Set[str], set_b: Set[str]) -> float:
        """Jaccard similarity between two sets."""
        if not set_a or not set_b:
            return 0.0
        intersection = len(set_a & set_b)
        union = len(set_a | set_b)
        return intersection / union if union > 0 else 0.0


# Module-level singleton — shared across all integration points
_tracker = DataFlowTracker()


def get_tracker() -> DataFlowTracker:
    """Get the session-scoped taint tracker singleton."""
    return _tracker
