"""
Code Fingerprint Guard — prevents proprietary source code from leaking
through LLM prompts and tool calls.

Fingerprints workspace source files via normalized n-gram hashing, then
checks outbound content against the fingerprint store.  Locality-aware:
stricter threshold for cloud LLMs, more permissive for local.

Usage:
    from endpoint_agent.scanners.code_fingerprint import get_fingerprint_store
    store = get_fingerprint_store()
    store.fingerprint_workspace("/path/to/repo")
    matches = store.check_content(prompt_text, locality="cloud")
"""

import glob as globlib
import hashlib
import json
import os
import re
import threading
import time
from typing import Dict, List, Optional, Set, Tuple

CODE_GUARD_ENABLED = os.environ.get(
    "EA_CODE_GUARD_ENABLED", "true"
).lower() == "true"

CODE_GUARD_PATTERNS = os.environ.get(
    "EA_CODE_GUARD_PATTERNS",
    "**/*.py,**/*.js,**/*.ts,**/*.jsx,**/*.tsx,**/*.java,**/*.go,**/*.rs,**/*.rb,**/*.cs",
)

CODE_GUARD_CLOUD_THRESHOLD = float(
    os.environ.get("EA_CODE_GUARD_THRESHOLD", "0.4")
)
CODE_GUARD_LOCAL_THRESHOLD = float(
    os.environ.get("EA_CODE_GUARD_LOCAL_THRESHOLD", "0.7")
)
CODE_GUARD_MIN_LINES = int(
    os.environ.get("EA_CODE_GUARD_MIN_LINES", "5")
)

# N-gram sizes for fingerprinting (reuses concept from data_flow_tracker.py)
_NGRAM_SIZES = (5, 8)
_MAX_FILE_SIZE = 512 * 1024  # 512 KB

# Persistence
_CACHE_DIR = os.path.join("/tmp", "agnosticsecurity")
_CACHE_FILE = os.path.join(_CACHE_DIR, "fingerprint_cache.json")
_CACHE_TTL = int(os.environ.get("EA_CODE_GUARD_CACHE_TTL", "86400"))  # 24h


# ---------------------------------------------------------------------------
# Code normalization
# ---------------------------------------------------------------------------

# Comment patterns for common languages
_SINGLE_LINE_COMMENT = re.compile(r"(?://|#).*$", re.MULTILINE)
_MULTI_LINE_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)
_STRING_LITERAL = re.compile(r"""(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|`(?:[^`\\]|\\.)*`)""")
_WHITESPACE_COLLAPSE = re.compile(r"\s+")
_IMPORT_LINE = re.compile(
    r"^\s*(?:import\s|from\s\S+\s+import|require\s*\(|"
    r"using\s|#include|package\s)",
    re.MULTILINE,
)


def _normalize_code(code: str) -> str:
    """Normalize code for fingerprinting: strip comments, imports, strings,
    collapse whitespace, lowercase."""
    text = _MULTI_LINE_COMMENT.sub(" ", code)
    text = _SINGLE_LINE_COMMENT.sub("", text)
    text = _STRING_LITERAL.sub('""', text)
    # Remove import/require lines (not proprietary)
    lines = [
        ln for ln in text.split("\n")
        if not _IMPORT_LINE.match(ln)
    ]
    text = " ".join(lines)
    text = _WHITESPACE_COLLAPSE.sub(" ", text).strip().lower()
    return text


def _extract_ngrams(text: str, sizes: Tuple[int, ...] = _NGRAM_SIZES) -> Set[str]:
    """Extract character n-grams from normalized text."""
    ngrams: Set[str] = set()
    for n in sizes:
        for i in range(len(text) - n + 1):
            ngrams.add(text[i : i + n])
    return ngrams


def _jaccard_similarity(a: Set[str], b: Set[str]) -> float:
    if not a or not b:
        return 0.0
    intersection = len(a & b)
    union = len(a | b)
    return intersection / union if union > 0 else 0.0


# ---------------------------------------------------------------------------
# Fingerprint store
# ---------------------------------------------------------------------------

class CodeFingerprint:
    __slots__ = ("path", "sha256", "ngrams", "line_count", "timestamp")

    def __init__(
        self,
        path: str,
        sha256: str,
        ngrams: Set[str],
        line_count: int,
    ) -> None:
        self.path = path
        self.sha256 = sha256
        self.ngrams = ngrams
        self.line_count = line_count
        self.timestamp = time.time()


class CodeFingerprintStore:
    """Stores fingerprints of workspace source files and checks outbound
    content for proprietary code leakage."""

    def __init__(self) -> None:
        self._fingerprints: Dict[str, CodeFingerprint] = {}
        self._lock = threading.Lock()
        self._indexed_roots: Set[str] = set()
        self._load_cache()

    def fingerprint_file(self, path: str) -> Optional[str]:
        """Fingerprint a single source file. Returns the SHA-256 hash."""
        try:
            stat = os.stat(path)
            if stat.st_size > _MAX_FILE_SIZE:
                return None
            with open(path, "r", errors="ignore") as f:
                raw = f.read()
        except (OSError, UnicodeDecodeError):
            return None

        line_count = raw.count("\n") + 1
        if line_count < CODE_GUARD_MIN_LINES:
            return None

        normalized = _normalize_code(raw)
        if len(normalized) < 20:
            return None

        sha = hashlib.sha256(normalized.encode()).hexdigest()
        ngrams = _extract_ngrams(normalized)

        with self._lock:
            self._fingerprints[path] = CodeFingerprint(
                path=path,
                sha256=sha,
                ngrams=ngrams,
                line_count=line_count,
            )
        return sha

    def fingerprint_workspace(
        self,
        root: str,
        patterns: Optional[List[str]] = None,
    ) -> int:
        """Scan a workspace directory and fingerprint all matching source files.
        Returns the number of files fingerprinted."""
        if not patterns:
            patterns = [p.strip() for p in CODE_GUARD_PATTERNS.split(",")]

        count = 0
        for pattern in patterns:
            full_pattern = os.path.join(root, pattern)
            for filepath in globlib.glob(full_pattern, recursive=True):
                if os.path.isfile(filepath):
                    if self.fingerprint_file(filepath) is not None:
                        count += 1
        return count

    def check_content(
        self,
        content: str,
        locality: str = "cloud",
    ) -> List[Dict]:
        """Check if content matches any fingerprinted proprietary code.

        Args:
            content: The text to check (prompt, tool call args, etc.)
            locality: "local" or "cloud" — affects similarity threshold

        Returns:
            List of matches with file path, similarity score, and threshold.
        """
        if not CODE_GUARD_ENABLED:
            return []
        if not self._fingerprints:
            return []

        normalized = _normalize_code(content)
        if len(normalized) < 20:
            return []

        # Check line count of the content
        content_lines = content.count("\n") + 1
        if content_lines < CODE_GUARD_MIN_LINES:
            return []

        content_hash = hashlib.sha256(normalized.encode()).hexdigest()
        content_ngrams = _extract_ngrams(normalized)

        threshold = (
            CODE_GUARD_LOCAL_THRESHOLD
            if locality == "local"
            else CODE_GUARD_CLOUD_THRESHOLD
        )

        matches = []
        with self._lock:
            for path, fp in self._fingerprints.items():
                # Exact match
                if fp.sha256 == content_hash:
                    matches.append({
                        "file": path,
                        "similarity": 1.0,
                        "threshold": threshold,
                        "match_type": "exact",
                    })
                    continue

                # Fuzzy match via Jaccard
                sim = _jaccard_similarity(content_ngrams, fp.ngrams)
                if sim >= threshold:
                    matches.append({
                        "file": path,
                        "similarity": round(sim, 3),
                        "threshold": threshold,
                        "match_type": "fuzzy",
                    })

        # Sort by similarity descending
        matches.sort(key=lambda m: m["similarity"], reverse=True)
        return matches

    def ensure_workspace_indexed(self, root: str) -> int:
        """Auto-index a workspace root if not already indexed this session.
        Returns number of files fingerprinted (0 if already indexed)."""
        real_root = os.path.realpath(root)
        if real_root in self._indexed_roots:
            return 0
        self._indexed_roots.add(real_root)
        count = self.fingerprint_workspace(real_root)
        if count > 0:
            self._save_cache()
        return count

    # ── Disk persistence ──────────────────────────────────────────────────

    def _load_cache(self) -> None:
        """Load fingerprint cache from disk if it exists and is fresh."""
        try:
            if not os.path.exists(_CACHE_FILE):
                return
            stat = os.stat(_CACHE_FILE)
            if time.time() - stat.st_mtime > _CACHE_TTL:
                return  # stale
            with open(_CACHE_FILE, "r") as f:
                data = json.load(f)
            for entry in data.get("fingerprints", []):
                # Only restore if the source file still exists with same mtime
                fpath = entry["path"]
                if not os.path.exists(fpath):
                    continue
                try:
                    current_mtime = os.stat(fpath).st_mtime
                    if abs(current_mtime - entry.get("mtime", 0)) > 1:
                        continue  # file changed since cache
                except OSError:
                    continue
                fp = CodeFingerprint(
                    path=fpath,
                    sha256=entry["sha256"],
                    ngrams=set(entry["ngrams"]),
                    line_count=entry["line_count"],
                )
                self._fingerprints[fpath] = fp
            # Restore indexed roots so we don't re-scan
            for root in data.get("indexed_roots", []):
                self._indexed_roots.add(root)
        except Exception:
            pass  # cache is best-effort

    def _save_cache(self) -> None:
        """Persist fingerprint store to disk."""
        try:
            os.makedirs(_CACHE_DIR, exist_ok=True)
            entries = []
            with self._lock:
                for fpath, fp in self._fingerprints.items():
                    try:
                        mtime = os.stat(fpath).st_mtime
                    except OSError:
                        mtime = 0
                    entries.append({
                        "path": fp.path,
                        "sha256": fp.sha256,
                        "ngrams": list(fp.ngrams),
                        "line_count": fp.line_count,
                        "mtime": mtime,
                    })
            data = {
                "fingerprints": entries,
                "indexed_roots": list(self._indexed_roots),
                "timestamp": time.time(),
            }
            with open(_CACHE_FILE, "w") as f:
                json.dump(data, f)
        except Exception:
            pass  # persistence is best-effort

    def get_stats(self) -> Dict:
        with self._lock:
            return {
                "files_fingerprinted": len(self._fingerprints),
                "total_ngrams": sum(
                    len(fp.ngrams) for fp in self._fingerprints.values()
                ),
                "indexed_roots": list(self._indexed_roots),
            }

    def clear(self) -> None:
        with self._lock:
            self._fingerprints.clear()
        self._indexed_roots.clear()
        try:
            if os.path.exists(_CACHE_FILE):
                os.unlink(_CACHE_FILE)
        except OSError:
            pass


# -- singleton -------------------------------------------------------------

_store_instance: Optional[CodeFingerprintStore] = None
_store_lock = threading.Lock()


def get_fingerprint_store() -> CodeFingerprintStore:
    global _store_instance
    if _store_instance is None:
        with _store_lock:
            if _store_instance is None:
                _store_instance = CodeFingerprintStore()
    return _store_instance
