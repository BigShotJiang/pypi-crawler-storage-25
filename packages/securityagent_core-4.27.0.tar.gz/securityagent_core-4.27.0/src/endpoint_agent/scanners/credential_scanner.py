"""
Regex-based credential scanner.

Scans file contents for exposed secrets like API keys, tokens,
private keys, and database connection strings.
"""

import logging
import os
import re
from pathlib import Path
from typing import Callable, Dict, List

from endpoint_agent.config.settings import (
    CREDENTIAL_PATTERNS,
    MAX_SCAN_FILE_BYTES,
    SCANNABLE_EXTENSIONS,
    SENSITIVE_FILE_PATTERNS,
    SEVERITY_CRITICAL,
    SKIP_DIRECTORIES,
)

logger = logging.getLogger(__name__)

_COMPILED_PATTERNS = {
    name: re.compile(pattern) for name, pattern in CREDENTIAL_PATTERNS.items()
}


class CredentialScanner:
    """Scans files for exposed secrets and credentials."""

    def __init__(self, alert_callback: Callable, trial_active: bool = True):
        self.alert_callback = alert_callback
        self.trial_active = trial_active

    def scan_directory(self, directory: str) -> List[Dict]:
        """Recursively scan a directory for exposed credentials."""
        if not self.trial_active:
            return []

        findings = []
        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRECTORIES]
            for fname in files:
                full_path = os.path.join(root, fname)
                file_findings = self.scan_file(full_path)
                findings.extend(file_findings)
        return findings

    def scan_file(self, file_path: str) -> List[Dict]:
        """Scan a single file for credential patterns."""
        findings = []
        path = Path(file_path)

        if not self._should_scan(path):
            return findings

        try:
            size = path.stat().st_size
            if size > MAX_SCAN_FILE_BYTES or size == 0:
                return findings
            content = path.read_text(errors="ignore")
        except (OSError, PermissionError):
            return findings

        for line_num, line in enumerate(content.splitlines(), start=1):
            for pattern_name, compiled_re in _COMPILED_PATTERNS.items():
                match = compiled_re.search(line)
                if match:
                    finding = {
                        "file": file_path,
                        "line": line_num,
                        "pattern": pattern_name,
                        "preview": self._redact(line.strip(), match),
                    }
                    findings.append(finding)
                    self.alert_callback(
                        severity=SEVERITY_CRITICAL,
                        event_type="exposed_credential",
                        details=finding,
                    )

        return findings

    def _should_scan(self, path: Path) -> bool:
        """Determine if a file should be scanned based on name/extension."""
        for pattern in SENSITIVE_FILE_PATTERNS:
            if path.name == pattern:
                return True
        if path.suffix in SCANNABLE_EXTENSIONS:
            return True
        return False

    @staticmethod
    def _redact(line: str, match: re.Match) -> str:
        """Redact the matched secret, showing only first/last 4 chars."""
        secret = match.group(0)
        if len(secret) > 8:
            redacted = secret[:4] + "****" + secret[-4:]
        else:
            redacted = "****"
        return line.replace(secret, redacted)
