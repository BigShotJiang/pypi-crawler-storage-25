"""
ML-based intent and context classifier for DLP findings.

Replaces hardcoded keyword-based context analysis with learned
representations. Three classifiers:

1. **IntentClassifier** — Is this prompt a security action or meta-discussion?
   Solves: "pasting a transcript about .env gets blocked"

2. **PIIContextClassifier** — Is this PII in a dangerous or benign context?
   Solves: "gradient SSN 319-42-8756" false negative, float-embedded CC

3. **FeedbackStore** — Corrections feed back into the model for retraining.
   Solves: "don't want hardcoded changes to fix things"

Architecture:
  - Uses sentence-transformers (all-MiniLM-L6-v2) for embeddings
  - Cosine similarity against labeled reference vectors (few-shot)
  - Optional sklearn LogisticRegression trained on audit log data
  - Falls back to rule-based analysis if model unavailable

Usage:
  from endpoint_agent.scanners.ml_classifier import get_classifier
  clf = get_classifier()
  result = clf.classify_intent("paste this conversation about .env testing")
  # → {"intent": "meta_discussion", "confidence": 0.87}
"""

import json
import logging
import os
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Model cache directory
# ---------------------------------------------------------------------------

_MODEL_DIR = os.environ.get(
    "EA_ML_MODEL_DIR",
    os.path.join(os.path.expanduser("~"), ".agnosticsecurity", "models"),
)
_FEEDBACK_PATH = os.environ.get(
    "EA_ML_FEEDBACK_PATH",
    os.path.join(os.path.expanduser("~"), ".agnosticsecurity", "feedback.jsonl"),
)

# ---------------------------------------------------------------------------
# Lazy-loaded sentence transformer
# ---------------------------------------------------------------------------

_encoder = None
_embedding_cache: Dict[str, "numpy.ndarray"] = {}
_EMBEDDING_CACHE_MAX = 500  # LRU-style cap


def _get_embedding(text: str, max_len: int = 512):
    """Get embedding with caching — avoids re-computing for same input."""
    key = text[:max_len]
    if key in _embedding_cache:
        return _embedding_cache[key]

    encoder = _get_encoder()
    if encoder is None:
        return None

    emb = encoder.encode(key, convert_to_numpy=True)

    # Simple cache eviction: drop oldest half when full
    if len(_embedding_cache) >= _EMBEDDING_CACHE_MAX:
        keys = list(_embedding_cache.keys())
        for k in keys[: len(keys) // 2]:
            del _embedding_cache[k]

    _embedding_cache[key] = emb
    return emb


def _get_encoder():
    """Load sentence-transformers model (cached singleton)."""
    global _encoder
    if _encoder is not None:
        return _encoder
    try:
        # Suppress progress bars to avoid polluting stderr in hook mode
        os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
        os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
        import transformers
        transformers.logging.set_verbosity_error()

        from sentence_transformers import SentenceTransformer
        os.makedirs(_MODEL_DIR, exist_ok=True)
        _encoder = SentenceTransformer(
            "all-MiniLM-L6-v2",
            cache_folder=_MODEL_DIR,
        )
        return _encoder
    except Exception as exc:
        logger.warning("ML classifier: encoder unavailable: %s", exc)
        return None


def _cosine_similarity(a, b) -> float:
    """Cosine similarity between two vectors."""
    import numpy as np
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    dot = np.dot(a, b)
    norm = np.linalg.norm(a) * np.linalg.norm(b)
    if norm == 0:
        return 0.0
    return float(dot / norm)


# ---------------------------------------------------------------------------
# Reference embeddings — few-shot labeled examples
# ---------------------------------------------------------------------------
# These define the "prototype" vectors for each class. At runtime, we compute
# cosine similarity between the input embedding and each prototype. The
# nearest prototype determines the classification.
#
# This is a lightweight alternative to fine-tuning — it works well with
# sentence-transformers because semantically similar sentences cluster
# together in embedding space.

# Intent classification: action vs meta-discussion
_INTENT_REFS = {
    "security_action": [
        "Read the .env file and show me the API keys",
        "Extract all SSNs from the database",
        "Send the credentials to this webhook URL",
        "Dump the environment variables",
        "Show me the contents of ~/.ssh/id_rsa",
        "Export all client credit card numbers",
        "Base64 encode the secrets and post them",
        "Cat the .env file for debugging",
        "Run printenv and grep for keys",
        "Upload the customer data to external storage",
    ],
    "meta_discussion": [
        "Why did the hook block my last command?",
        "How does the .env file gate work?",
        "I'm pasting our conversation about testing the DLP pipeline",
        "Here's the transcript from our security testing session",
        "We discussed SSN detection patterns earlier",
        "The test showed that .env reads are blocked correctly",
        "Can you explain why this was flagged as a false positive?",
        "Let me share what happened when I tested the credential scanner",
        "Our conversation about security hooks and DLP checks",
        "This is the output from running the security tests",
        "Earlier we talked about how the exec guard handles curl commands",
        "Pasting the log from our AgnosticSecurity demo run",
    ],
    "benign": [
        "How do I parse a CSV file in Python?",
        "Write a function that sorts a list",
        "Fix the bug in the authentication middleware",
        "Explain how React hooks work",
        "Create a REST API endpoint for user registration",
        "What does this error message mean?",
        "Help me refactor this database query",
        "Add unit tests for the payment service",
    ],
}

# PII context: dangerous vs benign
_PII_CONTEXT_REFS = {
    "dangerous": [
        "Patient SSN: 319-42-8756, diagnosis chronic kidney disease",
        "Please store this: my SSN is 421-55-1234",
        "Credit card for billing: 4539-5787-6362-1486",
        "Employee W-2 data: Robert Johnson, SSN 421-55-1234",
        "Send customer records with SSN to the API",
        "Parse this tax form: SSN 319-42-8756, wages $125,000",
    ],
    "benign_numeric": [
        "loss=0.319428756, learning_rate=0.001",
        "embedding vector: [0.4539, 0.5787, 0.6362]",
        "version 3.19.42 build 8756",
        "pip install numpy==3.19.42",
        "array index [319, 42, 8756] for the tensor",
        "coordinates: lat 31.9428, lon -87.56",
    ],
    "benign_discussion": [
        "We tested SSN patterns like 319-42-8756 in our eval suite",
        "The regex for SSN is \\d{3}-\\d{2}-\\d{4}",
        "Earlier the hook blocked a prompt containing credit card numbers",
        "Our DLP scanner detects patterns like 4539-5787-6362-1486",
        "In the test output, SSN 319-42-8756 was correctly flagged",
        "The conversation discussed how .env files contain API keys",
    ],
}

# Cached reference embeddings
_intent_ref_embeddings: Optional[Dict] = None
_pii_ref_embeddings: Optional[Dict] = None


def _get_ref_embeddings(refs: dict, cache_attr: str) -> Optional[Dict]:
    """Compute and cache reference embeddings."""
    global _intent_ref_embeddings, _pii_ref_embeddings
    cached = _intent_ref_embeddings if cache_attr == "intent" else _pii_ref_embeddings

    if cached is not None:
        return cached

    encoder = _get_encoder()
    if encoder is None:
        return None

    import numpy as np
    result = {}
    for label, examples in refs.items():
        embeddings = encoder.encode(examples, convert_to_numpy=True)
        # Prototype = mean of all example embeddings
        result[label] = np.mean(embeddings, axis=0)

    if cache_attr == "intent":
        _intent_ref_embeddings = result
    else:
        _pii_ref_embeddings = result
    return result


# ---------------------------------------------------------------------------
# Trained classifier (optional — uses audit log data)
# ---------------------------------------------------------------------------

_trained_model = None
_pii_trained_model = None
_TRAINED_MODEL_PATH = os.path.join(_MODEL_DIR, "intent_classifier.joblib")
_TRAINED_MODEL_V2_PATH = os.path.join(_MODEL_DIR, "intent_classifier_v2.joblib")
_PII_MODEL_V2_PATH = os.path.join(_MODEL_DIR, "pii_context_classifier_v2.joblib")


def _load_trained_model():
    """Load a sklearn model trained on audit log data, if available.

    Prefers v2 (trained on 1,755+ samples from audit + red-team + synthetic)
    over v1 (trained on audit only).
    """
    global _trained_model
    if _trained_model is not None:
        return _trained_model

    # Try v2 first (enhanced training), then v1
    for path in (_TRAINED_MODEL_V2_PATH, _TRAINED_MODEL_PATH):
        if os.path.exists(path):
            try:
                import joblib
                _trained_model = joblib.load(path)
                logger.info("Loaded trained intent model from %s", path)
                return _trained_model
            except Exception as exc:
                logger.warning("Failed to load trained model %s: %s", path, exc)

    return None


def _load_pii_trained_model():
    """Load the PII context classifier v2 if available."""
    global _pii_trained_model
    if _pii_trained_model is not None:
        return _pii_trained_model

    if os.path.exists(_PII_MODEL_V2_PATH):
        try:
            import joblib
            _pii_trained_model = joblib.load(_PII_MODEL_V2_PATH)
            logger.info("Loaded PII context model from %s", _PII_MODEL_V2_PATH)
            return _pii_trained_model
        except Exception as exc:
            logger.warning("Failed to load PII model: %s", exc)

    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class MLClassifier:
    """ML-based intent and context classifier."""

    def classify_intent(self, text: str) -> Dict:
        """Classify prompt intent: security_action, meta_discussion, or benign.

        Uses ensemble of prototype matching and trained model (if available).
        Prototype matching excels at meta_discussion detection (few-shot).
        Trained model excels at security_action vs benign (learned from data).

        Returns:
            {"intent": str, "confidence": float, "method": str}
        """
        # Always run prototype matching (fast, good at meta-discussion)
        proto_result = self._classify_with_prototypes(
            text, _INTENT_REFS, "intent"
        )

        # If prototype says meta_discussion with high confidence, trust it
        # (the trained model has too few meta_discussion examples to be reliable)
        if (proto_result.get("intent") == "meta_discussion"
                and proto_result.get("confidence", 0) >= 0.7):
            return proto_result

        # Try trained model (if available) for action vs benign
        trained = _load_trained_model()
        if trained is not None:
            trained_result = self._classify_with_trained(text, trained)
            # Use trained model when it's confident
            if trained_result.get("confidence", 0) >= 0.7:
                return trained_result

        # Default to prototype result
        return proto_result

    def classify_pii_context(
        self, matched_value: str, line: str, full_text: str = ""
    ) -> Dict:
        """Classify whether PII is in a dangerous or benign context.

        Uses ensemble: trained PII model v2 (if available) + prototype matching.

        Returns:
            {"context": str, "confidence": float, "is_dangerous": bool}
        """
        # Use the surrounding line + matched value as input
        context_text = line if line else matched_value
        if full_text and len(full_text) < 500:
            context_text = full_text

        # Try trained PII model first (96.6% CV F1)
        pii_model = _load_pii_trained_model()
        if pii_model is not None:
            trained_result = self._classify_with_trained(context_text, pii_model)
            if trained_result.get("confidence", 0) >= 0.55:
                intent = trained_result.get("intent", "dangerous")
                return {
                    "context": intent,
                    "confidence": trained_result["confidence"],
                    "is_dangerous": intent == "dangerous",
                    "method": "trained_pii_v2",
                }

        result = self._classify_with_prototypes(
            context_text, _PII_CONTEXT_REFS, "pii"
        )

        intent = result.get("intent", "dangerous")
        is_dangerous = intent == "dangerous"

        return {
            "context": intent,
            "confidence": result.get("confidence", 0.5),
            "is_dangerous": is_dangerous,
            "method": result.get("method", "unknown"),
        }

    def is_transcript_context(self, text: str) -> Dict:
        """Detect if text is a pasted conversation transcript.

        More sophisticated than the current length + marker heuristic.

        Returns:
            {"is_transcript": bool, "confidence": float}
        """
        encoder = _get_encoder()
        if encoder is None:
            return {"is_transcript": False, "confidence": 0.0, "method": "unavailable"}

        # Structural signals
        signals = 0
        total_signals = 5

        # 1. Length (transcripts are usually long)
        if len(text) > 1500:
            signals += 1

        # 2. Conversation markers
        markers = ["⏺", "Claude", "assistant:", "Human:", "user:",
                    "✅", "❌", "PASS", "FAIL", "Tool Result",
                    "$ ", ">>> ", "hook_audit", "blocked", "allowed"]
        marker_count = sum(1 for m in markers if m in text)
        if marker_count >= 2:
            signals += 1

        # 3. Multiple speaker turns (alternating patterns)
        import re
        turn_patterns = re.findall(
            r"(?:^|\n)(?:Human|User|Assistant|Claude|>|\$|#)\s*[:\-]?\s",
            text, re.IGNORECASE,
        )
        if len(turn_patterns) >= 2:
            signals += 1

        # 4. Semantic similarity to transcript examples
        transcript_refs = [
            "Here is the conversation transcript from our testing session",
            "Pasting the output from the security demo",
            "This is what happened when we ran the DLP tests",
        ]
        text_emb = _get_embedding(text[:500])
        if text_emb is None:
            return {"is_transcript": False, "confidence": 0.0, "method": "unavailable"}
        ref_embs = [_get_embedding(r) for r in transcript_refs]

        import numpy as np
        sims = [_cosine_similarity(text_emb, ref) for ref in ref_embs]
        max_sim = max(sims)
        if max_sim > 0.5:
            signals += 1

        # 5. Contains security tool output patterns
        tool_patterns = [".env", "SSN", "blocked", "BLOCK", "ALLOW",
                         "secagent_check", "hook_audit", "DLP"]
        tool_count = sum(1 for p in tool_patterns if p in text)
        if tool_count >= 3:
            signals += 1

        confidence = signals / total_signals
        return {
            "is_transcript": confidence >= 0.4,  # 2+ signals
            "confidence": round(confidence, 3),
            "method": "ml_structural",
        }

    def _classify_with_prototypes(
        self, text: str, refs: dict, cache_attr: str
    ) -> Dict:
        """Few-shot classification using prototype embeddings."""
        ref_embeddings = _get_ref_embeddings(refs, cache_attr)
        if ref_embeddings is None:
            return {
                "intent": "unknown",
                "confidence": 0.0,
                "method": "unavailable",
            }

        text_emb = _get_embedding(text)

        # Compute similarity to each prototype
        similarities = {}
        for label, proto in ref_embeddings.items():
            similarities[label] = _cosine_similarity(text_emb, proto)

        # Winner = highest similarity
        best_label = max(similarities, key=similarities.get)
        best_sim = similarities[best_label]

        # Confidence = how much better the winner is vs second best
        sorted_sims = sorted(similarities.values(), reverse=True)
        margin = sorted_sims[0] - sorted_sims[1] if len(sorted_sims) > 1 else 0
        # Normalize confidence: margin of 0.1+ = high confidence
        confidence = min(1.0, margin * 5 + 0.5)

        return {
            "intent": best_label,
            "confidence": round(confidence, 3),
            "similarity": round(best_sim, 3),
            "all_scores": {k: round(v, 3) for k, v in similarities.items()},
            "method": "prototype",
        }

    def _classify_with_trained(self, text: str, model) -> Dict:
        """Classification using a trained sklearn model."""
        text_emb = _get_embedding(text)
        if text_emb is None:
            return {"intent": "unknown", "confidence": 0.0, "method": "unavailable"}

        text_emb = text_emb.reshape(1, -1)
        prediction = model.predict(text_emb)[0]
        probabilities = model.predict_proba(text_emb)[0]
        confidence = float(max(probabilities))

        return {
            "intent": prediction,
            "confidence": round(confidence, 3),
            "method": "trained",
        }


# ---------------------------------------------------------------------------
# Training pipeline — learns from audit log + feedback
# ---------------------------------------------------------------------------

def train_from_audit_log(
    audit_path: str,
    feedback_path: Optional[str] = None,
    output_path: Optional[str] = None,
) -> Dict:
    """Train intent classifier from audit log data + optional corrections.

    Reads hook_audit.jsonl entries, uses action (allow/block) + detail text
    to build a training set. Feedback corrections override audit labels.

    Args:
        audit_path: Path to hook_audit.jsonl
        feedback_path: Optional path to feedback.jsonl (corrections)
        output_path: Where to save the trained model (default: _TRAINED_MODEL_PATH)

    Returns:
        {"accuracy": float, "samples": int, "classes": dict}
    """
    encoder = _get_encoder()
    if encoder is None:
        return {"error": "encoder unavailable"}

    import numpy as np
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import cross_val_score
    import joblib

    # Load audit log
    texts = []
    labels = []

    with open(audit_path) as f:
        for line in f:
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            detail = entry.get("detail", "")
            action = entry.get("action", "")
            event = entry.get("event", "")

            if not detail or len(detail) < 10:
                continue

            # Map actions to intent labels
            if action == "block":
                labels.append("security_action")
            elif action in ("allow", "warn_dev_context"):
                # Check if it's a meta-discussion or benign
                if any(kw in detail.lower() for kw in
                       ["why", "how does", "explain", "false positive",
                        "transcript", "conversation", "testing"]):
                    labels.append("meta_discussion")
                else:
                    labels.append("benign")
            else:
                continue

            texts.append(detail[:256])

    # Load feedback corrections (override audit labels)
    if feedback_path and os.path.exists(feedback_path):
        with open(feedback_path) as f:
            for line in f:
                try:
                    entry = json.loads(line)
                    texts.append(entry["text"][:256])
                    labels.append(entry["label"])
                except (json.JSONDecodeError, KeyError):
                    continue

    if len(texts) < 20:
        return {"error": f"not enough training data ({len(texts)} samples)"}

    # Encode all texts
    logger.info("Encoding %d training samples...", len(texts))
    embeddings = encoder.encode(texts, convert_to_numpy=True, show_progress_bar=False)

    # Train logistic regression
    model = LogisticRegression(max_iter=1000, C=1.0, class_weight="balanced")

    # Cross-validation score
    from collections import Counter
    class_counts = Counter(labels)

    # Only cross-validate if we have enough samples per class
    min_class = min(class_counts.values())
    cv_folds = min(5, min_class) if min_class >= 2 else 2

    if min_class >= 2:
        scores = cross_val_score(model, embeddings, labels, cv=cv_folds)
        accuracy = float(np.mean(scores))
    else:
        accuracy = -1.0  # can't cross-validate

    # Train on full data
    model.fit(embeddings, labels)

    # Save model
    save_path = output_path or _TRAINED_MODEL_PATH
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    joblib.dump(model, save_path)

    global _trained_model
    _trained_model = model

    return {
        "accuracy": round(accuracy, 3),
        "samples": len(texts),
        "classes": dict(class_counts),
        "model_path": save_path,
        "cv_folds": cv_folds,
    }


# ---------------------------------------------------------------------------
# Feedback store — corrections from users
# ---------------------------------------------------------------------------

def record_feedback(
    text: str,
    label: str,
    original_action: str = "",
    reason: str = "",
):
    """Record a correction/feedback entry for future retraining.

    Args:
        text: The prompt or content that was misclassified
        label: Correct label (security_action, meta_discussion, benign)
        original_action: What the system did (block, allow, warn)
        reason: Why this is a correction
    """
    os.makedirs(os.path.dirname(_FEEDBACK_PATH), exist_ok=True)
    entry = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "text": text[:512],
        "label": label,
        "original_action": original_action,
        "reason": reason,
    }
    with open(_FEEDBACK_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_classifier_instance: Optional[MLClassifier] = None


def get_classifier() -> MLClassifier:
    """Return the ML classifier singleton."""
    global _classifier_instance
    if _classifier_instance is None:
        _classifier_instance = MLClassifier()
    return _classifier_instance
