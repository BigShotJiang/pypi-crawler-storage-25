"""
Tool call argument DLP scanner.

Intercepts MCP tool calls, function calls, and API invocations.  Scans
tool arguments through the DLP scanner and checks against the data flow
taint registry.  This catches sensitive data being exfiltrated through
the agent's own tool calls — e.g. web_search(query="4532015112830366")
or slack_post(message="the password is hunter2").

Integration: called from secagent_check.py's handle_hook_event() for
any tool name not handled by the existing Bash/Read/Edit/Write handlers.
"""

import json
import logging
from typing import Callable, Dict, List, Tuple

from endpoint_agent.config.settings import (
    TOOL_CALL_DLP_SKIP,
    TOOL_CALL_HIGH_RISK,
)

logger = logging.getLogger(__name__)


class ToolCallGuard:
    """DLP scanner for tool call arguments and MCP parameters."""

    def __init__(self, alert_callback: Callable):
        self.alert_callback = alert_callback

    def scan_tool_call(
        self,
        tool_name: str,
        arguments: dict,
        source: str = "tool_call",
    ) -> Dict:
        """Scan a tool call's arguments for sensitive data.

        Args:
            tool_name: Name of the tool being called.
            arguments: Dict of tool arguments/parameters.
            source: Label for the source context.

        Returns:
            Dict with keys:
                - blocked: bool
                - reason: str (if blocked)
                - findings: list of DLP findings
                - taint_matches: list of taint registry matches
        """
        # Skip allowlisted tools
        if tool_name in TOOL_CALL_DLP_SKIP:
            return {"blocked": False, "findings": [], "taint_matches": []}

        # Serialize arguments to scannable text
        arg_texts = self._serialize_arguments(arguments)
        if not arg_texts:
            return {"blocked": False, "findings": [], "taint_matches": []}

        is_high_risk = tool_name in TOOL_CALL_HIGH_RISK

        # --- DLP content scan ---
        from endpoint_agent.scanners.dlp_scanner import DLPScanner

        scanner = DLPScanner(alert_callback=self.alert_callback)
        all_findings: List[Dict] = []

        for key_path, value in arg_texts:
            findings = scanner.scan_content(
                value,
                source=f"tool_call:{tool_name}:{key_path}",
            )
            for f in findings:
                f["tool_name"] = tool_name
                f["arg_path"] = key_path
            all_findings.extend(findings)

        # --- Taint registry check ---
        from endpoint_agent.scanners.data_flow_tracker import get_tracker

        tracker = get_tracker()
        all_taint_matches = []

        if tracker.is_enabled and tracker.entry_count > 0:
            for key_path, value in arg_texts:
                taint_matches = tracker.check_outbound(
                    value,
                    channel=f"tool_call:{tool_name}:{key_path}",
                )
                all_taint_matches.extend(taint_matches)

        # --- Decision ---
        blocked = False
        reasons: List[str] = []

        if all_findings:
            blocked = True
            patterns = list({f["pattern"] for f in all_findings})
            reasons.append(f"DLP findings in args: {', '.join(patterns)}")

        if all_taint_matches:
            blocked = True
            sources = list({m.entry.source for m in all_taint_matches})
            reasons.append(
                f"tainted data from [{', '.join(sources)}] "
                f"detected in tool call arguments"
            )

        if blocked:
            from endpoint_agent.config.settings import SEVERITY_CRITICAL

            self.alert_callback(
                severity=SEVERITY_CRITICAL,
                event_type="tool_call_data_leak",
                details={
                    "tool_name": tool_name,
                    "finding_count": len(all_findings),
                    "taint_match_count": len(all_taint_matches),
                    "high_risk_tool": is_high_risk,
                    "reasons": reasons,
                },
            )

        return {
            "blocked": blocked,
            "reason": "; ".join(reasons) if reasons else "",
            "findings": all_findings[:10],
            "taint_matches": [
                {
                    "source": m.entry.source,
                    "pattern_type": m.entry.pattern_type,
                    "match_type": m.match_type,
                    "similarity": m.similarity,
                    "channel": m.channel,
                }
                for m in all_taint_matches[:10]
            ],
        }

    @staticmethod
    def _serialize_arguments(
        args: dict, prefix: str = ""
    ) -> List[Tuple[str, str]]:
        """Recursively serialize dict arguments to (key_path, string_value) tuples."""
        results: List[Tuple[str, str]] = []

        if not isinstance(args, dict):
            return results

        for key, value in args.items():
            key_path = f"{prefix}.{key}" if prefix else key

            if isinstance(value, str) and len(value) >= 4:
                results.append((key_path, value))
            elif isinstance(value, dict):
                results.extend(
                    ToolCallGuard._serialize_arguments(value, key_path)
                )
            elif isinstance(value, list):
                for i, item in enumerate(value):
                    item_path = f"{key_path}[{i}]"
                    if isinstance(item, str) and len(item) >= 4:
                        results.append((item_path, item))
                    elif isinstance(item, dict):
                        results.extend(
                            ToolCallGuard._serialize_arguments(item, item_path)
                        )
            elif value is not None:
                # Convert non-string values to string for scanning
                str_val = str(value)
                if len(str_val) >= 8:
                    results.append((key_path, str_val))

        return results
