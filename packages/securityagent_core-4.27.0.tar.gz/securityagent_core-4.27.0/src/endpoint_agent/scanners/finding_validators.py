"""
Post-match validation and confidence scoring for DLP findings.

Regex matching is fast but imprecise — digit sequences in floats trigger
credit-card patterns, version numbers trigger phone patterns, placeholder
keys trigger credential patterns.  This module sits between raw regex
matches and finding emission, applying:

  1. **Structural validators** — pattern-specific checks that verify the
     match is structurally valid (Luhn checksum, SSN range rules, area
     code validation, key entropy).

  2. **Context analyzers** — examine the surrounding text to detect
     numeric arrays, floating-point contexts, placeholder patterns,
     documentation examples, and other signals that lower confidence.

  3. **Confidence scoring** — each validator and analyzer contributes a
     score adjustment.  Only findings above a configurable threshold
     are emitted.

This replaces scattered hardcoded suppression rules with a single
extensible pipeline.
"""

import math
import re
from typing import Dict, Optional


# ---------------------------------------------------------------------------
# Luhn checksum (ISO/IEC 7812-1) — validates credit card numbers
# ---------------------------------------------------------------------------

def _luhn_check(digits: str) -> bool:
    """Return True if ``digits`` passes the Luhn checksum.

    This alone eliminates ~90% of false-positive credit-card matches
    from random digit sequences (floats, embeddings, IDs).
    """
    if not digits.isdigit() or len(digits) < 2:
        return False
    total = 0
    for i, ch in enumerate(reversed(digits)):
        n = int(ch)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


# ---------------------------------------------------------------------------
# Shannon entropy — measures randomness of a string
# ---------------------------------------------------------------------------

def _shannon_entropy(s: str) -> float:
    """Return the Shannon entropy (bits per character) of *s*."""
    if not s:
        return 0.0
    length = len(s)
    freq: Dict[str, int] = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    return -sum(
        (c / length) * math.log2(c / length) for c in freq.values()
    )


# ---------------------------------------------------------------------------
# Numeric context detector
# ---------------------------------------------------------------------------

_NUMERIC_CONTEXT_RE = re.compile(
    r"[\[\(,]\s*-?\d+\.\d+\s*[,\]\)]"     # array element: [0.123, ...]
    r"|"
    r"-?\d+\.\d{6,}"                        # high-precision float
    r"|"
    # ML keywords only suppress when adjacent to numeric data (float/array),
    # not as bare words. This prevents "gradient SSN 319-42-8756" bypass.
    r"(?:embedding|vector|weight|tensor|"
    r"coefficient|param|gradient|loss|"
    r"score|prob|logit|softmax)"
    r"\s*[:=]?\s*-?\d+\.\d+",              # require trailing float value
    re.IGNORECASE,
)

_FLOAT_ADJACENT_RE = re.compile(
    r"(?<!\w)\d+\.\d{4,}"                   # float with 4+ decimal digits
)


# ---------------------------------------------------------------------------
# Valid US area codes (rough set — excludes 000, 555-01xx test range)
# ---------------------------------------------------------------------------

_INVALID_AREA_CODES = {
    "000", "555",  # reserved / fictional
    # N11 codes — not geographic phone numbers
    "211", "311", "411", "511", "611", "711", "811", "911",
}


# ---------------------------------------------------------------------------
# SSN structural rules (SSA assignment rules)
# ---------------------------------------------------------------------------

def _valid_ssn_structure(ssn: str) -> bool:
    """Check whether an SSN-shaped string is in a valid SSA range.

    Invalid ranges: 000-xx-xxxx, xxx-00-xxxx, xxx-xx-0000,
    666-xx-xxxx, 900-999-xx-xxxx.
    """
    parts = ssn.split("-")
    if len(parts) != 3:
        return False
    area, group, serial = parts
    if area == "000" or area == "666" or area >= "900":
        return False
    if group == "00":
        return False
    if serial == "0000":
        return False
    return True


# ---------------------------------------------------------------------------
# Per-pattern structural validators
# ---------------------------------------------------------------------------

_PATTERN_VALIDATORS = {}


def _register_validator(pattern_name: str):
    """Decorator to register a structural validator for a pattern name."""
    def decorator(fn):
        _PATTERN_VALIDATORS[pattern_name] = fn
        return fn
    return decorator


@_register_validator("Credit Card")
def _validate_credit_card(matched_value: str, line: str) -> float:
    """Validate credit card via Luhn checksum.

    Returns 1.0 if Luhn passes, 0.0 if it fails.
    """
    digits = re.sub(r"[- ]", "", matched_value)
    if _luhn_check(digits):
        return 1.0
    return 0.0


@_register_validator("SSN")
def _validate_ssn(matched_value: str, line: str) -> float:
    """Validate SSN against SSA assignment rules."""
    if _valid_ssn_structure(matched_value):
        return 1.0
    return 0.1  # still possible but unlikely


@_register_validator("US Phone")
def _validate_us_phone(matched_value: str, line: str) -> float:
    """Validate US phone by area code and format plausibility.

    Phone numbers are inherently low-sensitivity PII — a single phone
    in a document is normal contact info, not a DLP violation.  The
    structural score caps at 0.4 (below the default 0.5 threshold) so
    phones are only reported when users explicitly lower the threshold.
    High-sensitivity patterns (SSN, CC, credentials) surface
    independently at full confidence.
    """
    # Extract the area code (first 3 digits)
    digits = re.sub(r"[^0-9]", "", matched_value)
    # Strip leading 1 for country code
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    if len(digits) != 10:
        return 0.1
    area = digits[:3]
    if area in _INVALID_AREA_CODES:
        return 0.05
    # Phone numbers don't start with 0 or 1 in the area code
    if area[0] in ("0", "1"):
        return 0.1
    # Valid area code — structurally plausible but low sensitivity
    return 0.4


@_register_validator("Email Address")
def _validate_email(matched_value: str, line: str) -> float:
    """Email addresses are low-sensitivity PII.

    Single email addresses in documents are overwhelmingly author
    credits, contact info, or example data — not DLP violations.
    Score caps at 0.4 (below default threshold) like phone numbers.
    """
    return 0.4


@_register_validator("IBAN")
def _validate_iban(matched_value: str, line: str) -> float:
    """Basic IBAN structure validation."""
    clean = re.sub(r"\s", "", matched_value)
    if len(clean) < 15 or len(clean) > 34:
        return 0.1
    # Check digits (positions 3-4) should be numeric
    if not clean[2:4].isdigit():
        return 0.1
    return 0.8


@_register_validator("Canadian SIN")
def _validate_canadian_sin(matched_value: str, line: str) -> float:
    """Validate Canadian SIN using Luhn algorithm."""
    digits = re.sub(r"[^0-9]", "", matched_value)
    if len(digits) != 9:
        return 0.0
    # Canadian SINs use Luhn check
    if _luhn_check(digits):
        return 0.9
    return 0.2  # Could still be a SIN with typo


@_register_validator("UK NINO")
def _validate_uk_nino(matched_value: str, line: str) -> float:
    """UK NINOs have specific prefix restrictions."""
    clean = re.sub(r"\s", "", matched_value).upper()
    # Invalid prefixes: BG, GB, NK, KN, TN, NT, ZZ, and temp prefixes
    invalid_prefixes = {"BG", "GB", "NK", "KN", "TN", "NT", "ZZ"}
    prefix = clean[:2]
    if prefix in invalid_prefixes or prefix[0] in "DFIQUV" or prefix[1] in "DFIQUVO":
        return 0.1
    return 0.85


@_register_validator("Aadhaar Number")
def _validate_aadhaar(matched_value: str, line: str) -> float:
    """Aadhaar: 12 digits, first digit 2-9, no repeated digit sequences."""
    digits = re.sub(r"\s", "", matched_value)
    if len(digits) != 12:
        return 0.1
    if digits[0] in "01":
        return 0.1
    # All same digit (e.g. 222222222222)
    if len(set(digits)) == 1:
        return 0.05
    return 0.9


@_register_validator("PAN Card")
def _validate_pan(matched_value: str, line: str) -> float:
    """PAN: ABCDE1234F — 4th char indicates holder type."""
    if len(matched_value) != 10:
        return 0.1
    valid_4th = set("ABCFGHLJPT")
    return 0.9 if matched_value[3] in valid_4th else 0.3


@_register_validator("Indian Phone")
def _validate_indian_phone(matched_value: str, line: str) -> float:
    """Indian mobile: low-sensitivity PII, capped at 0.4."""
    return 0.4


@_register_validator("Generic API Key")
def _validate_api_key(matched_value: str, line: str) -> float:
    """Check entropy — placeholder/example keys have low entropy."""
    # Extract the key value (after = or :)
    m = re.search(r"[=:]\s*['\"]([^'\"]+)['\"]", matched_value)
    if not m:
        return 0.5
    key_value = m.group(1)
    entropy = _shannon_entropy(key_value)
    # Real API keys typically have entropy > 3.5 bits/char
    if entropy < 2.5:
        return 0.1
    if entropy < 3.5:
        return 0.4
    return 1.0


@_register_validator("Generic Secret")
def _validate_generic_secret(matched_value: str, line: str) -> float:
    """Check entropy of the secret value."""
    m = re.search(r"[=:]\s*['\"]([^'\"]+)['\"]", matched_value)
    if not m:
        return 0.5
    secret = m.group(1)
    entropy = _shannon_entropy(secret)
    if entropy < 2.5:
        return 0.1
    if entropy < 3.5:
        return 0.4
    return 1.0


@_register_validator("JWT Token")
def _validate_jwt(matched_value: str, line: str) -> float:
    """Validate JWT structure — must have 3 base64url segments."""
    parts = matched_value.split(".")
    if len(parts) != 3:
        return 0.2
    # Try to decode the header to verify it's valid JSON
    import base64
    import json
    try:
        # Add padding
        header = parts[0] + "=" * (4 - len(parts[0]) % 4)
        decoded = base64.urlsafe_b64decode(header)
        data = json.loads(decoded)
        if "alg" in data or "typ" in data:
            return 1.0
        return 0.6
    except Exception:
        return 0.3


# ---------------------------------------------------------------------------
# Semantic disclosure validators
# ---------------------------------------------------------------------------

_SEMANTIC_PLACEHOLDER_RE = re.compile(
    r"(?:your_|my_|the_)?\b(?:example|placeholder|changeme|password|secret|"
    r"token|key|value|here|xxx|insert|todo|fixme)\b"
    r"|^[A-Z_]{4,}$",  # ALL_CAPS_PLACEHOLDER patterns like YOUR_KEY_HERE
    re.IGNORECASE,
)


def _validate_nl_disclosure(matched_value: str, line: str) -> float:
    """Validate a natural language credential disclosure.

    High-confidence by structure (the pattern itself encodes intent),
    but filters out documentation examples and placeholder values.
    """
    # Extract the disclosed value (the part after "is"/"was"/":"/"=")
    m = re.search(r"(?:is|was|[=:])\s*['\"]?(\S+)", matched_value, re.IGNORECASE)
    if not m:
        return 0.5

    disclosed = m.group(1).strip("'\"")

    # Check for placeholder tokens
    if _SEMANTIC_PLACEHOLDER_RE.search(disclosed):
        return 0.1

    # Check entropy of the disclosed value
    entropy = _shannon_entropy(disclosed)
    if entropy < 1.5:
        return 0.1  # very low entropy = placeholder
    if entropy < 2.5:
        return 0.4  # low entropy = possibly fake

    return 0.9  # high-entropy value in a disclosure pattern = real


# Register the same validator for all NL disclosure patterns
for _nl_name in (
    "NL Password Disclosure",
    "NL API Key Disclosure",
    "NL Secret Disclosure",
    "NL Database Creds",
    "NL Bearer Token",
):
    _PATTERN_VALIDATORS[_nl_name] = _validate_nl_disclosure


@_register_validator("NL Credentials Block")
def _validate_nl_creds_block(matched_value: str, line: str) -> float:
    """Validate a multi-line credentials block disclosure.

    For creds blocks, check the VALUES (after = or :), not the keywords
    like 'password' or 'username' which are structural labels.
    """
    # Extract the values after username/password labels
    values = re.findall(r"[:=]\s*(\S+)", matched_value)
    for v in values:
        v_clean = v.strip("'\"")
        # Skip structural keywords
        if v_clean.lower() in ("admin", "root", "user", "test"):
            continue
        if _SEMANTIC_PLACEHOLDER_RE.search(v_clean):
            return 0.1
        # Check entropy of the actual credential value
        entropy = _shannon_entropy(v_clean)
        if entropy >= 2.5:
            return 0.9
    return 0.7  # has structure even if values are simple


# ---------------------------------------------------------------------------
# Context analyzer — examines surrounding text
# ---------------------------------------------------------------------------

def _analyze_context(matched_value: str, line: str, source: str) -> float:
    """Return a context confidence multiplier between 0.0 and 1.0.

    Values < 1.0 reduce confidence when the match appears in a context
    that is likely benign (numeric arrays, floats, documentation, etc.).

    Sets ``_last_context_positional`` flag so ``validate_finding`` knows
    whether suppression was from positional signals (safe, no LLM needed)
    or keyword signals (ambiguous, route to LLM for high-sensitivity PII).
    """
    global _last_context_positional
    _last_context_positional = False

    multiplier = 1.0
    positional_hit = False

    # --- Numeric / float context (POSITIONAL — structurally unambiguous) ---
    # If the line looks like it's in a numeric array or contains
    # high-precision floats, the match is likely a digit coincidence.
    # Exclude lines with currency symbols — dollar amounts like
    # "$125,450.00" produce false positives (comma-separated thousands
    # look like array elements to the regex).
    if _NUMERIC_CONTEXT_RE.search(line) and not re.search(r"[$€£¥₹]", line):
        multiplier *= 0.1
        positional_hit = True

    # If the matched digits are immediately adjacent to a decimal point,
    # they're part of a float, not a standalone number.
    match_start = line.find(matched_value)
    if match_start > 0 and line[match_start - 1] == ".":
        multiplier *= 0.05
        positional_hit = True
    # Also check if a digit run within the match follows a decimal point
    # in the broader line (e.g., the match is a substring of a float)
    digits_only = re.sub(r"[- ]", "", matched_value)
    if digits_only.isdigit() and _FLOAT_ADJACENT_RE.search(line):
        # Check if our digits overlap with a float's decimal digits
        for float_match in _FLOAT_ADJACENT_RE.finditer(line):
            float_digits = float_match.group().replace(".", "")
            if digits_only in float_digits:
                multiplier *= 0.05
                positional_hit = True
                break

    # --- JSON array context (POSITIONAL) ---
    stripped = line.strip()
    if stripped.startswith("[") or stripped.startswith("],"):
        # Likely a data array (embeddings, coordinates, etc.)
        multiplier *= 0.2
        positional_hit = True

    # --- Version number context (POSITIONAL — requires trailing digit) ---
    if re.search(r"(?:version|v)\s*[:=]?\s*\d", line, re.IGNORECASE):
        multiplier *= 0.2
        positional_hit = True

    # --- Package manager / dependency context (KEYWORD — word-bounded) ---
    if re.search(
        r"\b(?:pip|npm|gem|cargo|go\s+get|maven|gradle|nuget|composer|"
        r"requirements?|dependenc(?:y|ies)|package\.json|package-lock)\b",
        line, re.IGNORECASE,
    ):
        multiplier *= 0.2

    _last_context_positional = positional_hit
    return max(multiplier, 0.01)  # floor to avoid true zero


# Flag set by _analyze_context to communicate whether suppression was
# positional (float/array — high confidence, no LLM needed) vs keyword.
_last_context_positional = False


# ---------------------------------------------------------------------------
# Public API — validate a single finding candidate
# ---------------------------------------------------------------------------

# High-sensitivity PII types that warrant LLM verification when context
# analysis would suppress them.  Low-sensitivity types (email, phone) are
# intentionally excluded — their structural scores are already capped at
# 0.4 and don't need the extra latency.
_HIGH_SENSITIVITY_PII = {"SSN", "Credit Card", "IBAN", "Canadian SIN", "UK NINO"}

# Cache for LLM verification results to avoid redundant calls within a
# single scan pass.  Keyed by (pattern_name, matched_value).
_llm_context_cache: dict = {}


def _ml_verify_pii_context(
    pattern_name: str,
    matched_value: str,
    line: str,
    source: str,
) -> float:
    """Use ML classifier (fast) or LLM (slow fallback) to verify PII context.

    Tries ML sentence-transformer classifier first (< 50ms).  Falls back
    to LLM provider if ML is unavailable.  Falls back to 0.8 (fail closed)
    if both are unavailable.
    """
    cache_key = (pattern_name, matched_value)
    if cache_key in _llm_context_cache:
        return _llm_context_cache[cache_key]

    # --- Try ML classifier first (fast, no network) ---
    try:
        from endpoint_agent.scanners.ml_classifier import get_classifier
        clf = get_classifier()
        result = clf.classify_pii_context(matched_value, line)
        if result.get("method") != "unavailable":
            score = 0.9 if result["is_dangerous"] else 0.1
            _llm_context_cache[cache_key] = score
            return score
    except Exception:
        pass

    # --- Fallback to LLM provider (slower, more accurate) ---
    try:
        from endpoint_agent.scanners.llm_provider import get_provider
        provider = get_provider()
        if not provider.is_available():
            _llm_context_cache[cache_key] = 0.8
            return 0.8

        result = provider.verify_pii_context(
            matched_value=matched_value,
            pattern_name=pattern_name,
            line=line,
            source=source,
        )
        score = result["confidence"] if result["is_pii"] else 0.1
        _llm_context_cache[cache_key] = score
        return score
    except Exception:
        _llm_context_cache[cache_key] = 0.8
        return 0.8  # fail closed


def validate_finding(
    pattern_name: str,
    matched_value: str,
    line: str,
    source: str,
) -> float:
    """Score a regex match on a 0.0–1.0 confidence scale.

    Combines the structural validator score (if one exists for this
    pattern) with the context analyzer score.  For high-sensitivity PII
    types (SSN, CC, IBAN) where context analysis would suppress the
    finding below threshold, routes through LLM verification instead of
    silently dropping — this prevents social engineering bypass via
    keyword-stuffing (e.g. "gradient SSN 319-42-8756").

    Args:
        pattern_name: The pattern that matched (e.g. "Credit Card").
        matched_value: The raw matched text.
        line: The full line containing the match.
        source: File path or label for context analysis.

    Returns:
        Confidence score between 0.0 and 1.0.  Callers should compare
        against ``DLP_CONFIDENCE_THRESHOLD`` to decide whether to emit.
    """
    # Step 1: Structural validation (pattern-specific)
    validator = _PATTERN_VALIDATORS.get(pattern_name)
    if validator:
        structural_score = validator(matched_value, line)
    else:
        # No structural validator → assume regex match is valid
        structural_score = 0.85

    # Step 2: Context analysis (universal)
    context_multiplier = _analyze_context(matched_value, line, source)

    # Combine: structural score modulated by context
    confidence = structural_score * context_multiplier

    # Step 3: LLM verification for high-sensitivity PII that context
    # analysis would suppress via KEYWORD signals.  Positional signals
    # (float adjacency, array brackets, decimal overlap) are structurally
    # unambiguous and don't need LLM confirmation.  Keyword signals
    # (package manager names, ML terms) are ambiguous and exploitable
    # via social engineering — route these to the LLM instead.
    if (
        pattern_name in _HIGH_SENSITIVITY_PII
        and structural_score >= 0.7
        and confidence < 0.5
        and not _last_context_positional
    ):
        confidence = _ml_verify_pii_context(
            pattern_name, matched_value, line, source,
        )

    return round(confidence, 3)
