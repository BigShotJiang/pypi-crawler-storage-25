"""
PromptGuard — 3-layer prompt analysis orchestrator.

Architecture:
  Layer 0: PromptIntentAnalyzer  (regex, <50ms)  — fast signal detection
  Layer 1: RuleBasedClassifier   (Pydantic rules) — negation-aware signal detection
  Layer 2: OllamaAnalyzer        (local LLM)      — semantic intent classification

Layers 0+1 act as **triage** — they identify suspicious signals but never
block on their own.  Only the LLM (Layer 2) can make a blocking decision,
because keyword matching alone cannot distinguish genuine attack intent
from benign discussion *about* security concepts.

If the LLM is unavailable, the system falls back to triage signals but
requires a compound-pattern match (high-confidence, multi-signal) to block.
Mere keyword accumulation without the LLM is capped at "medium".
"""

from typing import Callable, Dict, List


class PromptGuard:
    """Orchestrates multi-layer prompt analysis."""

    def __init__(self, alert_callback: Callable):
        self.alert_callback = alert_callback

        from endpoint_agent.scanners.prompt_analyzer import PromptIntentAnalyzer
        from endpoint_agent.scanners.rule_classifier import RuleBasedClassifier
        from endpoint_agent.scanners.llm_analyzer import OllamaAnalyzer

        self._regex = PromptIntentAnalyzer(alert_callback=alert_callback)
        self._rules = RuleBasedClassifier(alert_callback=alert_callback)
        self._llm = OllamaAnalyzer(alert_callback=alert_callback)

    def analyze(self, prompt: str) -> Dict:
        """Run layered analysis on a prompt.

        Returns the standard result dict with an additional
        ``analysis_layers`` key listing which layers ran.
        """
        layers_used: List[str] = []

        # ── Layer 0: Regex (fast triage) ──────────────────────────────
        regex_result = self._regex.analyze(prompt)
        layers_used.append("regex")

        # ── Layer 1: Pydantic rules ───────────────────────────────────
        rule_result = self._rules.classify(prompt)
        layers_used.append("rules")

        triage_result = self._merge(regex_result, rule_result)

        # Layer 1 (rules) is negation-aware.  If it matched keywords but
        # suppressed them via negation (e.g. "protect passwords" → negation
        # keyword "protect" fires), those categories must be removed from
        # the merged result — otherwise Layer 0's raw keyword hit re-adds
        # the category that Layer 1 explicitly suppressed.
        negated = set(rule_result.get("negated_categories", []))
        if negated:
            surviving = [c for c in triage_result["intent_categories"] if c not in negated]
            triage_result["intent_categories"] = surviving
            triage_result["matches"] = [
                m for m in triage_result["matches"] if m.get("category") not in negated
            ]
            # Recompute score from surviving matches only
            if triage_result["matches"]:
                new_score = min(1.0, sum(m["weight"] for m in triage_result["matches"]))
            else:
                new_score = 0.0
            triage_result["risk_score"] = round(new_score, 3)
            triage_result["risk_level"] = (
                "high" if new_score >= 0.7 else
                "medium" if new_score >= 0.4 else
                "low" if new_score >= 0.15 else
                "none"
            )
            triage_result["should_block"] = triage_result["risk_level"] == "high"

        # Fast path: clearly benign — no signals at all
        if triage_result["risk_level"] == "none" and not triage_result.get("matches"):
            triage_result["analysis_layers"] = layers_used
            return triage_result

        # ── Layer 2: LLM makes the blocking decision ─────────────────
        # Pass triage signals so the LLM knows what was flagged and can
        # make an informed semantic judgment.
        llm_result = self._llm.analyze(prompt, triage_signals=triage_result)

        if llm_result is not None:
            layers_used.append("llm")

            # Compound matches (multi-signal, high-confidence detections like
            # prompt_injection_ignore_instructions) are deterministic and
            # reliable.  The LLM must not downgrade these — a local model
            # can be tricked into classifying obvious injection as benign.
            if self._has_compound_match(triage_result) and triage_result["should_block"]:
                # Keep the triage blocking verdict, but note the LLM ran
                triage_result["analysis_layers"] = layers_used
                return triage_result

            # FIX: Negation-aware LLM override — if Layer 1 (rule-based)
            # produced zero matches because negation keywords fired (e.g.
            # "hash", "protect", "rotate"), the LLM must not escalate past
            # medium.  Negation is a high-confidence structural signal that
            # the small local LLM (llama3.2:1b) often ignores.
            l1_negated = (
                rule_result.get("risk_score", 0) == 0
                and regex_result.get("risk_score", 0) > 0
                and llm_result.get("should_block", False)
            )
            if l1_negated:
                llm_result["risk_level"] = "medium"
                llm_result["risk_score"] = min(llm_result["risk_score"], 0.65)
                llm_result["should_block"] = False

            # For non-compound signals, LLM is the authority
            llm_result["analysis_layers"] = layers_used
            return llm_result

        # ── Fallback: LLM unavailable ────────────────────────────────
        # Without semantic analysis, keyword accumulation is unreliable
        # (discussions about security trip the same keywords as attacks).
        # Only block if a compound pattern matched — those are high-
        # confidence, multi-signal patterns unlikely to be discussion.
        triage_result["analysis_layers"] = layers_used
        if not self._has_compound_match(triage_result):
            if triage_result["risk_level"] == "high":
                triage_result["risk_level"] = "medium"
                triage_result["risk_score"] = min(triage_result["risk_score"], 0.65)
                triage_result["should_block"] = False

        return triage_result

    @staticmethod
    def _has_compound_match(result: Dict) -> bool:
        """Check if any match came from a compound pattern."""
        for match in result.get("matches", []):
            if match.get("category") == "compound":
                return True
        return False

    @staticmethod
    def _merge(a: Dict, b: Dict) -> Dict:
        """Merge two analysis results, taking the worse case.

        - risk_score: max
        - intent_categories: union
        - matches: concatenate (capped at 10)
        - evasion_flags: union
        - should_block: OR
        """
        score = max(a.get("risk_score", 0.0), b.get("risk_score", 0.0))
        score = min(1.0, score)

        cats_a = set(a.get("intent_categories", []))
        cats_b = set(b.get("intent_categories", []))
        categories = sorted(cats_a | cats_b)

        matches = (a.get("matches", []) + b.get("matches", []))[:10]

        evasion_a = set(a.get("evasion_flags", []))
        evasion_b = set(b.get("evasion_flags", []))
        evasion = sorted(evasion_a | evasion_b)

        # Derive level from merged score
        if score >= 0.7:
            level = "high"
        elif score >= 0.4:
            level = "medium"
        elif score >= 0.15:
            level = "low"
        else:
            level = "none"

        return {
            "risk_score": round(score, 3),
            "risk_level": level,
            "intent_categories": categories,
            "matches": matches,
            "evasion_flags": evasion,
            "should_block": level == "high",
        }
