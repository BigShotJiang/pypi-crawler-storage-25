"""
Shadow AI Detector — identifies unauthorized AI tool usage in the
development environment.

Scans running processes and network connections against a registry of
known AI tools.  Compares findings to an approved list
(``EA_APPROVED_AI_TOOLS``).  Unauthorized usage is logged and optionally
reported to the breach engine.

Usage:
    from endpoint_agent.scanners.shadow_ai_detector import get_shadow_ai_detector
    detector = get_shadow_ai_detector()
    report = detector.scan()
"""

import os
import platform
import re
import subprocess
import threading
import time
from typing import Callable, Dict, List, Optional, Set

SHADOW_AI_ENABLED = os.environ.get(
    "EA_SHADOW_AI_ENABLED", "false"
).lower() == "true"

APPROVED_AI_TOOLS: List[str] = [
    t.strip()
    for t in os.environ.get("EA_APPROVED_AI_TOOLS", "claude-code").split(",")
    if t.strip()
]

SHADOW_AI_SCAN_INTERVAL = int(
    os.environ.get("EA_SHADOW_AI_SCAN_INTERVAL", "60")
)

# ---------------------------------------------------------------------------
# Known AI tool signatures
# ---------------------------------------------------------------------------

_AI_TOOL_REGISTRY: Dict[str, Dict] = {
    "copilot": {
        "display_name": "GitHub Copilot",
        "process_patterns": [r"copilot", r"github[\-_]copilot"],
        "api_hosts": ["api.github.com", "copilot-proxy.githubusercontent.com"],
        "config_files": [".github/copilot"],
    },
    "cursor": {
        "display_name": "Cursor",
        "process_patterns": [r"[Cc]ursor(?:[\-_]helper)?", r"cursor\.app"],
        "api_hosts": ["api2.cursor.sh", "api.cursor.com"],
        "config_files": [".cursor"],
    },
    "claude-code": {
        "display_name": "Claude Code",
        "process_patterns": [r"claude"],
        "api_hosts": ["api.anthropic.com"],
        "config_files": [".claude"],
    },
    "continue": {
        "display_name": "Continue.dev",
        "process_patterns": [r"continue"],
        "api_hosts": [],
        "config_files": [".continue"],
    },
    "aider": {
        "display_name": "Aider",
        "process_patterns": [r"aider"],
        "api_hosts": [],
        "config_files": [".aider"],
    },
    "cody": {
        "display_name": "Sourcegraph Cody",
        "process_patterns": [r"cody", r"sourcegraph"],
        "api_hosts": ["sourcegraph.com", "cody-gateway.sourcegraph.com"],
        "config_files": [],
    },
    "tabnine": {
        "display_name": "Tabnine",
        "process_patterns": [r"tabnine", r"TabNine"],
        "api_hosts": ["api.tabnine.com"],
        "config_files": [".tabnine"],
    },
    "codeium": {
        "display_name": "Codeium",
        "process_patterns": [r"codeium", r"Codeium"],
        "api_hosts": ["api.codeium.com", "server.codeium.com"],
        "config_files": [],
    },
    "supermaven": {
        "display_name": "Supermaven",
        "process_patterns": [r"supermaven"],
        "api_hosts": ["supermaven.com"],
        "config_files": [],
    },
    "windsurf": {
        "display_name": "Windsurf",
        "process_patterns": [r"[Ww]indsurf"],
        "api_hosts": [],
        "config_files": [".windsurf"],
    },
    "replit-ai": {
        "display_name": "Replit AI",
        "process_patterns": [r"replit"],
        "api_hosts": ["replit.com"],
        "config_files": [],
    },
    "amazon-q": {
        "display_name": "Amazon Q Developer",
        "process_patterns": [r"amazon[\-_]q", r"codewhisperer"],
        "api_hosts": ["codewhisperer.us-east-1.amazonaws.com"],
        "config_files": [],
    },
}


class ShadowAIFinding:
    __slots__ = ("tool_id", "display_name", "detection_method", "detail",
                 "is_approved", "timestamp")

    def __init__(
        self,
        tool_id: str,
        display_name: str,
        detection_method: str,
        detail: str,
        is_approved: bool,
    ) -> None:
        self.tool_id = tool_id
        self.display_name = display_name
        self.detection_method = detection_method
        self.detail = detail
        self.is_approved = is_approved
        self.timestamp = time.time()

    def to_dict(self) -> Dict:
        return {
            "tool_id": self.tool_id,
            "display_name": self.display_name,
            "detection_method": self.detection_method,
            "detail": self.detail,
            "is_approved": self.is_approved,
            "timestamp": self.timestamp,
        }


class ShadowAIDetector:
    """Detects unauthorized AI tool usage via process and network scanning."""

    def __init__(self, alert_callback: Optional[Callable] = None) -> None:
        self._alert_callback = alert_callback
        self._lock = threading.Lock()
        self._last_scan: Optional[Dict] = None
        self._last_scan_time: float = 0

    def scan(self) -> Dict:
        """Run a full scan: processes + network. Returns report dict."""
        if not SHADOW_AI_ENABLED:
            return {"enabled": False, "findings": []}

        process_findings = self._scan_processes()
        network_findings = self._scan_network()

        all_findings = process_findings + network_findings
        unauthorized = [f for f in all_findings if not f.is_approved]

        report = {
            "enabled": True,
            "scan_time": time.time(),
            "total_ai_tools_detected": len(all_findings),
            "unauthorized_count": len(unauthorized),
            "approved_tools": list(APPROVED_AI_TOOLS),
            "findings": [f.to_dict() for f in all_findings],
            "unauthorized": [f.to_dict() for f in unauthorized],
        }

        with self._lock:
            self._last_scan = report
            self._last_scan_time = time.time()

        # Alert on unauthorized findings
        if unauthorized and self._alert_callback:
            self._alert_callback({
                "type": "shadow_ai_detected",
                "count": len(unauthorized),
                "tools": [f.tool_id for f in unauthorized],
            })

        return report

    def _scan_processes(self) -> List[ShadowAIFinding]:
        """Scan running processes for AI tool signatures."""
        findings: List[ShadowAIFinding] = []
        seen_tools: Set[str] = set()

        try:
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["tasklist", "/FO", "CSV"],
                    capture_output=True, text=True, timeout=10,
                )
            else:
                result = subprocess.run(
                    ["ps", "aux"],
                    capture_output=True, text=True, timeout=10,
                )
            process_output = result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            return findings

        for tool_id, info in _AI_TOOL_REGISTRY.items():
            if tool_id in seen_tools:
                continue
            for pattern in info["process_patterns"]:
                if re.search(pattern, process_output):
                    is_approved = tool_id in APPROVED_AI_TOOLS
                    findings.append(ShadowAIFinding(
                        tool_id=tool_id,
                        display_name=info["display_name"],
                        detection_method="process",
                        detail=f"Process matching '{pattern}' found",
                        is_approved=is_approved,
                    ))
                    seen_tools.add(tool_id)
                    break

        return findings

    def _scan_network(self) -> List[ShadowAIFinding]:
        """Scan network connections for known AI API endpoints."""
        findings: List[ShadowAIFinding] = []
        seen_tools: Set[str] = set()

        if platform.system() == "Windows":
            return findings  # Skip on Windows for now

        try:
            result = subprocess.run(
                ["lsof", "-i", "-n", "-P"],
                capture_output=True, text=True, timeout=10,
            )
            net_output = result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            return findings

        for tool_id, info in _AI_TOOL_REGISTRY.items():
            if tool_id in seen_tools:
                continue
            for host in info.get("api_hosts", []):
                if host in net_output:
                    is_approved = tool_id in APPROVED_AI_TOOLS
                    findings.append(ShadowAIFinding(
                        tool_id=tool_id,
                        display_name=info["display_name"],
                        detection_method="network",
                        detail=f"Connection to {host} detected",
                        is_approved=is_approved,
                    ))
                    seen_tools.add(tool_id)
                    break

        return findings

    def check_process(self, process_name: str, cmdline: str = "") -> Optional[Dict]:
        """Check a single process name against the AI tool registry.
        Returns match info or None."""
        combined = f"{process_name} {cmdline}"
        for tool_id, info in _AI_TOOL_REGISTRY.items():
            for pattern in info["process_patterns"]:
                if re.search(pattern, combined, re.IGNORECASE):
                    is_approved = tool_id in APPROVED_AI_TOOLS
                    return {
                        "tool_id": tool_id,
                        "display_name": info["display_name"],
                        "is_approved": is_approved,
                    }
        return None

    def get_last_scan(self) -> Optional[Dict]:
        with self._lock:
            return self._last_scan


# -- singleton -------------------------------------------------------------

_detector_instance: Optional[ShadowAIDetector] = None
_detector_lock = threading.Lock()


def get_shadow_ai_detector(
    alert_callback: Optional[Callable] = None,
) -> ShadowAIDetector:
    global _detector_instance
    if _detector_instance is None:
        with _detector_lock:
            if _detector_instance is None:
                _detector_instance = ShadowAIDetector(alert_callback)
    return _detector_instance
