"""
Prompt intent analyzer for pre-execution security screening.

Classifies user prompts/messages for sensitive data access intent
BEFORE they reach tool execution. Uses keyword/pattern matching
(not LLM calls) for deterministic, fast, offline analysis.

Performance target: <50ms per prompt analysis.
"""

import re
from typing import Callable, Dict, List, Tuple

from endpoint_agent.config.settings import (
    MEMORY_POISONING_PATTERNS,
    PROMPT_EVASION_PATTERNS,
    PROMPT_HIGH_RISK_COMPOUND_PATTERNS,
    PROMPT_RISK_KEYWORDS,
    SEVERITY_CRITICAL,
    SEVERITY_WARNING,
)


class PromptIntentAnalyzer:
    """Analyzes prompt text for sensitive data access intent.

    Designed for speed (<50ms) and determinism. No LLM calls,
    no network, no external dependencies.
    """

    # Patterns that indicate the surrounding text is *discussing* security
    # concepts rather than *attempting* an attack.  Matches found only inside
    # these contexts have their weight discounted.
    _DISCUSSION_CONTEXT_RE = re.compile(
        r"|".join([
            # Quoted strings (single, double, or backtick)
            r'"[^"]{10,}"',
            r"'[^']{10,}'",
            r"`[^`]{10,}`",
            # Fenced code blocks
            r"```[\s\S]*?```",
            # Lines that read like explanations / examples / hypotheticals
            r"(?:^|\n)\s*(?:for example|e\.g\.|such as|like when|an attacker (?:can|could|might|would)|"
            r"if (?:someone|an attacker|a user)|the (?:fix|issue|problem|gap|risk) (?:is|:)|"
            r"this (?:catches|detects|blocks|prevents|means)|"
            r"(?:would|could|might|should) (?:catch|detect|block|flag|trigger))[^\n]*",
            # Meta-discussion: product strategy, architecture, opinion requests,
            # comparisons — the user is talking ABOUT security concepts, not
            # requesting access TO security assets.
            r"(?:^|\n)\s*(?:"
            r"(?:should|do|can|could|would) (?:we|you|i|they) (?:focus|prioritize|consider|think|discuss|worry)|"
            r"(?:do you|what do you|what are your) (?:think|recommend|suggest)|"
            r"(?:is it|would it be) (?:better|more important|worth|wise|possible)|"
            r"(?:from a|from the) \w+ (?:perspective|standpoint|point of view)|"
            r"(?:more important|more critical|higher priority) than|"
            r"(?:instead of|rather than|compared to|as opposed to|versus|vs\.?)\b|"
            r"(?:what about|how about|what if|how does) (?:the |our |this )|"
            r"(?:why does|why is|why do|why would|why should)\b"
            r")[^\n]*",
            # Claude-style assistant output markers
            r"⏺[^\n]*",
        ]),
        re.IGNORECASE | re.MULTILINE,
    )

    def __init__(self, alert_callback: Callable):
        self.alert_callback = alert_callback
        self._compiled_keywords: Dict[str, List[Tuple[re.Pattern, float]]] = {}
        self._compiled_evasion: List[Tuple[re.Pattern, str]] = []
        self._compiled_compound: List[Tuple[re.Pattern, str, float]] = []
        self._compile_patterns()

    def _compile_patterns(self) -> None:
        """Pre-compile all regex patterns for fast matching."""
        for category, patterns in PROMPT_RISK_KEYWORDS.items():
            self._compiled_keywords[category] = [
                (re.compile(p["pattern"], re.IGNORECASE), p["weight"]) for p in patterns
            ]
        self._compiled_evasion = [
            (re.compile(p["pattern"], re.IGNORECASE), p["label"])
            for p in PROMPT_EVASION_PATTERNS
        ]
        # Memory poisoning patterns are also evasion — a prompt trying to
        # implant "user authorized X" is an injection vector.
        self._compiled_evasion.extend([
            (re.compile(p["pattern"], re.IGNORECASE), p["label"])
            for p in MEMORY_POISONING_PATTERNS
        ])
        self._compiled_compound = [
            (re.compile(p["pattern"], re.IGNORECASE), p["label"], p["weight"])
            for p in PROMPT_HIGH_RISK_COMPOUND_PATTERNS
        ]

    @classmethod
    def _strip_discussion_context(cls, text: str) -> str:
        """Remove quoted, example, and explanation text from the prompt.

        When conversation context is included in the prompt (e.g. Claude Code
        hooks pass the full transcript), the analyzer would otherwise flag
        *discussion about* injection patterns as actual attacks.  This method
        blanks out regions that look like quotes, code blocks, hypothetical
        explanations, or assistant output so only direct user intent remains.
        """
        return cls._DISCUSSION_CONTEXT_RE.sub(" ", text)

    def analyze(self, prompt: str) -> Dict:
        """Analyze a prompt for sensitive data access intent.

        Args:
            prompt: The user prompt or message text.

        Returns:
            Dict with keys:
                - risk_score: float (0.0 = benign, 1.0 = highly suspicious)
                - risk_level: str ("none" | "low" | "medium" | "high")
                - intent_categories: List[str] (matched category names)
                - matches: List[Dict] (individual pattern matches)
                - evasion_flags: List[str] (detected evasion techniques)
                - should_block: bool (True if risk_level is "high")
        """
        # Strip discussion/explanation context so that *talking about*
        # injection patterns doesn't trigger false positives.
        cleaned = self._strip_discussion_context(prompt)
        prompt_lower = cleaned.lower()
        matches: List[Dict] = []
        categories_hit: set = set()
        total_weight = 0.0

        # Phase 1: Keyword/pattern matching by category
        # Use per-category MAX weight, not sum.  Multiple keywords from the
        # same category (e.g. ".env" + "credentials" both in credential_request)
        # indicate the same intent signal, not independent threats.  Summing
        # them inflates the risk score and causes false positives on
        # meta-discussion that mentions several related terms.
        # Cross-category accumulation (different intents) still sums normally.
        # High-confidence multi-keyword attacks are caught by compound patterns
        # in Phase 2, which have their own dedicated weights (0.8–0.95).
        category_max_weight: Dict[str, float] = {}
        for category, compiled_list in self._compiled_keywords.items():
            for compiled_re, weight in compiled_list:
                if compiled_re.search(prompt_lower):
                    matches.append(
                        {
                            "category": category,
                            "pattern": compiled_re.pattern,
                            "weight": weight,
                        }
                    )
                    categories_hit.add(category)
                    category_max_weight[category] = max(
                        category_max_weight.get(category, 0.0), weight
                    )
        total_weight = sum(category_max_weight.values())

        # Phase 2: Compound patterns (multi-signal, high confidence)
        for compiled_re, label, weight in self._compiled_compound:
            if compiled_re.search(prompt_lower):
                matches.append(
                    {
                        "category": "compound",
                        "pattern": label,
                        "weight": weight,
                    }
                )
                total_weight += weight

        # Phase 3: Evasion detection
        evasion_flags: List[str] = []
        for compiled_re, label in self._compiled_evasion:
            if compiled_re.search(prompt_lower):
                evasion_flags.append(label)
                total_weight += 0.3

        # Compute risk
        risk_score = min(1.0, total_weight)
        risk_level = self._score_to_level(risk_score)
        should_block = risk_level == "high"

        result = {
            "risk_score": round(risk_score, 3),
            "risk_level": risk_level,
            "intent_categories": sorted(categories_hit),
            "matches": matches[:10],
            "evasion_flags": evasion_flags,
            "should_block": should_block,
        }

        # Fire alert if risk is medium or above
        if risk_level in ("medium", "high"):
            severity = SEVERITY_CRITICAL if should_block else SEVERITY_WARNING
            self.alert_callback(
                severity=severity,
                event_type="prompt_intent_suspicious",
                details={
                    "risk_score": result["risk_score"],
                    "risk_level": risk_level,
                    "intent_categories": result["intent_categories"],
                    "match_count": len(matches),
                    "evasion_flags": evasion_flags,
                    "prompt_preview": prompt[:200],
                },
            )

        return result

    @staticmethod
    def _score_to_level(score: float) -> str:
        """Map numeric risk score to categorical level."""
        if score >= 0.7:
            return "high"
        if score >= 0.4:
            return "medium"
        if score >= 0.15:
            return "low"
        return "none"
