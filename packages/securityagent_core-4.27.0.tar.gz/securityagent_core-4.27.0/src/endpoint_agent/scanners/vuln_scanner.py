"""
Vulnerability Scanner — SAST-lite for AI-generated code.

Scans code snippets for OWASP Top 10 vulnerabilities before they enter
the codebase.  Rule-based with simplified taint-flow analysis.
No external dependencies.

Usage:
    from endpoint_agent.scanners.vuln_scanner import scan_for_vulns
    findings = scan_for_vulns(code_string)
"""

import os
import re
from typing import Dict, List, Optional, TypedDict

VULN_SCAN_ENABLED = os.environ.get(
    "EA_VULN_SCAN_ENABLED", "true"
).lower() == "true"

VULN_SCAN_MIN_SEVERITY = os.environ.get("EA_VULN_SCAN_MIN_SEVERITY", "MEDIUM")

_SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}


class VulnFinding(TypedDict):
    category: str
    pattern_name: str
    severity: str
    cwe: str
    matched: str
    line: int
    description: str
    fix_suggestion: str


# ---------------------------------------------------------------------------
# Pattern registry
# ---------------------------------------------------------------------------

_VULN_PATTERNS: List[Dict] = []


def _p(
    category: str,
    name: str,
    pattern: str,
    severity: str,
    cwe: str,
    description: str,
    fix: str,
    flags: int = re.IGNORECASE,
) -> None:
    _VULN_PATTERNS.append({
        "category": category,
        "name": name,
        "regex": re.compile(pattern, flags),
        "severity": severity,
        "cwe": cwe,
        "description": description,
        "fix": fix,
    })


# -- SQL Injection (CWE-89) -----------------------------------------------

_p("SQL Injection", "sql_format_string",
   r"""(?:execute|cursor\.execute|db\.execute|query)\s*\(\s*f["']""",
   "CRITICAL", "CWE-89",
   "SQL query built with f-string — vulnerable to SQL injection",
   "Use parameterized queries: cursor.execute('SELECT * FROM t WHERE id = ?', (user_id,))")

_p("SQL Injection", "sql_percent_format",
   r"""(?:execute|cursor\.execute)\s*\(\s*["'].*%s.*["']\s*%""",
   "CRITICAL", "CWE-89",
   "SQL query built with %-formatting — vulnerable to SQL injection",
   "Use parameterized queries instead of string formatting")

_p("SQL Injection", "sql_string_concat",
   r"""(?:execute|cursor\.execute)\s*\(\s*["'](?:SELECT|INSERT|UPDATE|DELETE).*["']\s*\+""",
   "HIGH", "CWE-89",
   "SQL query built with string concatenation",
   "Use parameterized queries instead of concatenation")

_p("SQL Injection", "sql_format_method",
   r"""(?:execute|cursor\.execute)\s*\(\s*["'].*["']\.format\s*\(""",
   "CRITICAL", "CWE-89",
   "SQL query built with .format() — vulnerable to SQL injection",
   "Use parameterized queries: cursor.execute('SELECT ... WHERE id = ?', (val,))")

# -- XSS (CWE-79) ---------------------------------------------------------

_p("Cross-Site Scripting", "xss_innerhtml",
   r"""\.innerHTML\s*=\s*(?!['"]<)""",
   "HIGH", "CWE-79",
   "Setting innerHTML with dynamic content — vulnerable to XSS",
   "Use textContent for text, or sanitize with DOMPurify before setting innerHTML")

_p("Cross-Site Scripting", "xss_document_write",
   r"""document\.write\s*\(""",
   "HIGH", "CWE-79",
   "document.write() is vulnerable to XSS and blocks page rendering",
   "Use DOM manipulation methods (createElement, appendChild) instead")

_p("Cross-Site Scripting", "xss_dangerously_set",
   r"""dangerouslySetInnerHTML\s*=\s*\{""",
   "MEDIUM", "CWE-79",
   "dangerouslySetInnerHTML used — ensure content is sanitized",
   "Sanitize content with DOMPurify before passing to dangerouslySetInnerHTML")

_p("Cross-Site Scripting", "xss_template_literal_html",
   r"""\.innerHTML\s*=\s*`""",
   "HIGH", "CWE-79",
   "innerHTML set with template literal — may include unsanitized variables",
   "Sanitize all interpolated values or use textContent")

# -- Command Injection (CWE-78) -------------------------------------------

_p("Command Injection", "cmd_subprocess_shell",
   r"""subprocess\.(?:call|run|Popen)\s*\([^)]*shell\s*=\s*True""",
   "HIGH", "CWE-78",
   "subprocess with shell=True — vulnerable to command injection if args are dynamic",
   "Use shell=False with a list of arguments: subprocess.run(['cmd', arg1, arg2])")

_p("Command Injection", "cmd_os_system_fstring",
   r"""os\.system\s*\(\s*f["']""",
   "CRITICAL", "CWE-78",
   "os.system() with f-string — vulnerable to command injection",
   "Use subprocess.run() with shell=False and a list of arguments")

_p("Command Injection", "cmd_os_system_format",
   r"""os\.system\s*\(\s*["'].*["']\.format\s*\(""",
   "CRITICAL", "CWE-78",
   "os.system() with .format() — vulnerable to command injection",
   "Use subprocess.run() with shell=False and a list of arguments")

_p("Command Injection", "cmd_os_popen",
   r"""os\.popen\s*\(\s*(?:f["']|.*\+|.*\.format)""",
   "HIGH", "CWE-78",
   "os.popen() with dynamic arguments — vulnerable to command injection",
   "Use subprocess.run() with shell=False")

# -- Path Traversal (CWE-22) ----------------------------------------------

_p("Path Traversal", "path_traversal_dotdot",
   r"""open\s*\(.*\.\.[\\/]""",
   "HIGH", "CWE-22",
   "Path with ../ may allow directory traversal",
   "Validate paths with os.path.realpath() and check they're within the allowed directory")

_p("Path Traversal", "path_join_unsanitized",
   r"""os\.path\.join\s*\([^)]*request\.""",
   "HIGH", "CWE-22",
   "os.path.join with user-supplied path component — may allow traversal",
   "Validate the resolved path is within the intended directory using os.path.commonpath()")

_p("Path Traversal", "path_open_user_input",
   r"""open\s*\(\s*(?:request\.|args\[|params\[|user_input|filename)""",
   "HIGH", "CWE-22",
   "File opened with user-controlled path",
   "Sanitize path and verify it resolves within the allowed directory")

# -- SSRF (CWE-918) -------------------------------------------------------

_p("Server-Side Request Forgery", "ssrf_requests_user_url",
   r"""requests\.(?:get|post|put|delete|patch|head)\s*\(\s*(?:url|user_url|target_url|request\.|args\[)""",
   "HIGH", "CWE-918",
   "HTTP request with user-controlled URL — vulnerable to SSRF",
   "Validate URL against an allowlist of permitted domains")

_p("Server-Side Request Forgery", "ssrf_urllib_user_url",
   r"""urllib\.request\.urlopen\s*\(\s*(?:url|user_url|request\.)""",
   "HIGH", "CWE-918",
   "urllib.urlopen with user-controlled URL — vulnerable to SSRF",
   "Validate URL against an allowlist before making the request")

# -- Insecure Deserialization (CWE-502) ------------------------------------

_p("Insecure Deserialization", "pickle_loads",
   r"""pickle\.(?:loads?|Unpickler)\s*\(""",
   "CRITICAL", "CWE-502",
   "pickle deserialization can execute arbitrary code",
   "Use json.loads() or a safe serialization format. Never unpickle untrusted data")

_p("Insecure Deserialization", "yaml_unsafe_load",
   r"""yaml\.load\s*\([^)]*\)\s*(?!.*Loader\s*=\s*(?:Safe|Base))""",
   "HIGH", "CWE-502",
   "yaml.load() without SafeLoader can execute arbitrary code",
   "Use yaml.safe_load() or yaml.load(data, Loader=yaml.SafeLoader)")

_p("Insecure Deserialization", "marshal_loads",
   r"""marshal\.loads?\s*\(""",
   "HIGH", "CWE-502",
   "marshal deserialization of untrusted data is unsafe",
   "Use json.loads() for data interchange")

# -- Hardcoded Secrets (CWE-798) ------------------------------------------

_p("Hardcoded Secrets", "hardcoded_password_assignment",
   r"""(?:password|passwd|pwd|secret)\s*=\s*["'][^"']{8,}["']""",
   "HIGH", "CWE-798",
   "Hardcoded password/secret in source code",
   "Use environment variables or a secrets manager")

_p("Hardcoded Secrets", "hardcoded_api_key",
   r"""(?:api_key|apikey|api_secret)\s*=\s*["'][A-Za-z0-9_\-]{20,}["']""",
   "HIGH", "CWE-798",
   "Hardcoded API key in source code",
   "Use environment variables: os.environ.get('API_KEY')")

# -- Known CVE Patterns ---------------------------------------------------

_p("Known Vulnerability", "log4j_jndi",
   r"""\$\{jndi:""",
   "CRITICAL", "CVE-2021-44228",
   "Log4j JNDI lookup pattern — Log4Shell vulnerability",
   "Upgrade to Log4j 2.17.1+ or set log4j2.formatMsgNoLookups=true")

_p("Known Vulnerability", "polyfill_io",
   r"""(?:cdn\.polyfill\.io|polyfill\.io/v[23])""",
   "HIGH", "CVE-2024-38526",
   "polyfill.io domain was compromised — serves malicious code",
   "Remove polyfill.io references. Use cdnjs.cloudflare.com/polyfill or self-host")

# -- Insecure Configuration (CWE-16) --------------------------------------

_p("Insecure Configuration", "debug_mode_production",
   r"""(?:DEBUG|debug)\s*=\s*True""",
   "MEDIUM", "CWE-16",
   "Debug mode enabled — may expose sensitive information in production",
   "Set DEBUG=False in production configurations")

_p("Insecure Configuration", "cors_allow_all",
   r"""(?:CORS|cors|Access-Control-Allow-Origin).*\*""",
   "MEDIUM", "CWE-16",
   "CORS allows all origins — may allow unauthorized cross-origin requests",
   "Restrict CORS to specific trusted origins")

_p("Insecure Configuration", "ssl_verify_false",
   r"""verify\s*=\s*False""",
   "MEDIUM", "CWE-295",
   "SSL verification disabled — vulnerable to MITM attacks",
   "Keep SSL verification enabled (verify=True)")

# -- Cryptography Issues (CWE-327) ----------------------------------------

_p("Weak Cryptography", "md5_hash",
   r"""(?:hashlib\.md5|MD5\.new|md5\s*\()""",
   "MEDIUM", "CWE-327",
   "MD5 is cryptographically broken — not suitable for security",
   "Use hashlib.sha256() or hashlib.sha3_256() instead")

_p("Weak Cryptography", "sha1_hash",
   r"""hashlib\.sha1\s*\(""",
   "LOW", "CWE-327",
   "SHA-1 is deprecated for security purposes",
   "Use hashlib.sha256() or hashlib.sha3_256() instead")

_p("Weak Cryptography", "random_for_security",
   r"""random\.(?:randint|choice|random|randrange)\s*\(""",
   "MEDIUM", "CWE-330",
   "Standard random module is not cryptographically secure",
   "Use secrets.token_hex() or secrets.SystemRandom() for security-sensitive operations",
   flags=0)

# -- Import Risk -----------------------------------------------------------

_p("Risky Import", "import_ctypes",
   r"""^(?:from\s+ctypes|import\s+ctypes)""",
   "MEDIUM", "CWE-242",
   "ctypes allows calling C functions — potential for memory corruption",
   "Ensure ctypes usage is necessary and inputs are validated")

_p("Risky Import", "import_eval_exec",
   r"""(?:^|\s)(?:eval|exec)\s*\(\s*(?:request\.|input\(|sys\.argv|args)""",
   "CRITICAL", "CWE-95",
   "eval/exec on user-controlled input — code injection vulnerability",
   "Never eval/exec untrusted input. Use ast.literal_eval() for data, or a proper parser")

# ---------------------------------------------------------------------------
# Simplified taint-flow analysis
# ---------------------------------------------------------------------------

_TAINT_SOURCES = re.compile(
    r"""(\w+)\s*=\s*(?:request\.(?:args|form|json|data|get_json|values)|"""
    r"""input\s*\(|sys\.argv|os\.environ|flask\.request\.|"""
    r"""self\.request\.|cgi\.FieldStorage)""",
    re.IGNORECASE,
)

_DANGEROUS_SINKS = [
    (re.compile(r"""(?:cursor\.execute|db\.execute|conn\.execute)\s*\(.*\b{var}\b"""),
     "SQL Injection", "CWE-89", "Tainted variable reaches SQL execution"),
    (re.compile(r"""(?:subprocess\.(?:call|run|Popen)|os\.system|os\.popen)\s*\(.*\b{var}\b"""),
     "Command Injection", "CWE-78", "Tainted variable reaches command execution"),
    (re.compile(r"""open\s*\(.*\b{var}\b"""),
     "Path Traversal", "CWE-22", "Tainted variable reaches file open"),
    (re.compile(r"""requests\.(?:get|post|put|delete)\s*\(.*\b{var}\b"""),
     "SSRF", "CWE-918", "Tainted variable reaches HTTP request"),
    (re.compile(r"""(?:\.innerHTML|document\.write)\s*(?:=|\().*\b{var}\b"""),
     "XSS", "CWE-79", "Tainted variable reaches DOM output"),
]


def _taint_flow_analysis(content: str) -> List[VulnFinding]:
    """Track user-input variables to dangerous sinks."""
    findings: List[VulnFinding] = []
    lines = content.split("\n")

    # Pass 1: collect tainted variable names and their line numbers
    tainted_vars: Dict[str, int] = {}
    for i, line in enumerate(lines, 1):
        m = _TAINT_SOURCES.search(line)
        if m:
            tainted_vars[m.group(1)] = i

    if not tainted_vars:
        return findings

    # Pass 2: check if tainted vars reach dangerous sinks
    for i, line in enumerate(lines, 1):
        for var_name, source_line in tainted_vars.items():
            if var_name not in line:
                continue
            for sink_pattern, category, cwe, desc in _DANGEROUS_SINKS:
                compiled = re.compile(
                    sink_pattern.pattern.replace("{var}", re.escape(var_name)),
                    re.IGNORECASE,
                )
                m = compiled.search(line)
                if m:
                    findings.append(VulnFinding(
                        category=f"Taint Flow: {category}",
                        pattern_name=f"taint_{category.lower().replace(' ', '_')}_{var_name}",
                        severity="CRITICAL",
                        cwe=cwe,
                        matched=line.strip()[:120],
                        line=i,
                        description=f"{desc} (tainted at line {source_line})",
                        fix_suggestion=f"Sanitize '{var_name}' before use — it originates from user input at line {source_line}",
                    ))
    return findings


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def scan_for_vulns(
    content: str,
    filename: str = "",
    language: str = "",
) -> List[VulnFinding]:
    """Scan a code snippet for security vulnerabilities.

    Returns a list of VulnFinding dicts, each with category, severity,
    CWE, line number, description, and fix suggestion.
    """
    if not VULN_SCAN_ENABLED:
        return []

    min_sev = _SEVERITY_ORDER.get(VULN_SCAN_MIN_SEVERITY, 2)
    findings: List[VulnFinding] = []
    lines = content.split("\n")

    # Regex-based pattern scan
    for pat in _VULN_PATTERNS:
        sev_val = _SEVERITY_ORDER.get(pat["severity"], 3)
        if sev_val > min_sev:
            continue
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            # Skip comments
            if stripped.startswith("#") or stripped.startswith("//"):
                continue
            m = pat["regex"].search(line)
            if m:
                findings.append(VulnFinding(
                    category=pat["category"],
                    pattern_name=pat["name"],
                    severity=pat["severity"],
                    cwe=pat["cwe"],
                    matched=m.group(0)[:120],
                    line=i,
                    description=pat["description"],
                    fix_suggestion=pat["fix"],
                ))

    # Taint flow analysis
    findings.extend(_taint_flow_analysis(content))

    # Deduplicate by (line, pattern_name)
    seen = set()
    unique: List[VulnFinding] = []
    for f in findings:
        key = (f["line"], f["pattern_name"])
        if key not in seen:
            seen.add(key)
            unique.append(f)

    return unique


def scan_for_vulns_summary(content: str, filename: str = "") -> Dict:
    """Return a summary dict compatible with code_scanner's format."""
    findings = scan_for_vulns(content, filename)
    if not findings:
        return {"safe": True, "findings": [], "finding_count": 0}

    by_severity = {}
    for f in findings:
        by_severity.setdefault(f["severity"], []).append(f["pattern_name"])

    return {
        "safe": False,
        "findings": findings,
        "finding_count": len(findings),
        "by_severity": by_severity,
        "categories": list({f["category"] for f in findings}),
    }
