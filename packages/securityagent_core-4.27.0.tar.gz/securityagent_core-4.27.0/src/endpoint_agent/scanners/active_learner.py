"""Active learning pipeline — auto-retrain ML classifiers from new audit data.

Monitors hook_audit.jsonl for new entries since last training, retrains
when sufficient new data accumulates, and validates before promoting.

Usage:
    from endpoint_agent.scanners.active_learner import ActiveLearner
    learner = ActiveLearner()
    learner.check_and_retrain()  # Called periodically or via secagent train --auto

Flow:
    1. Load last training timestamp from model metadata
    2. Count new audit entries since then
    3. If >= threshold (default 200), trigger retrain
    4. Train on full dataset (old + new)
    5. Validate: new model must beat old model's CV F1
    6. If passes, promote; if not, keep old model
"""

import json
import logging
import os
import time
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)

_MODEL_DIR = os.environ.get(
    "EA_ML_MODEL_DIR",
    os.path.join(os.path.expanduser("~"), ".agnosticsecurity", "models"),
)
_METADATA_PATH = os.path.join(_MODEL_DIR, "training_metadata.json")
_INTENT_MODEL_PATH = os.path.join(_MODEL_DIR, "intent_classifier_v2.joblib")
_PII_MODEL_PATH = os.path.join(_MODEL_DIR, "pii_context_classifier_v2.joblib")

# Default audit log locations
_AUDIT_PATHS = [
    os.path.join(os.path.expanduser("~"), "AgnosticSecurity", "logs", "hook_audit.jsonl"),
    os.path.join(os.path.expanduser("~"), ".securityagent", "skills_audit.jsonl"),
]

# Minimum new entries before retraining
_RETRAIN_THRESHOLD = int(os.environ.get("EA_RETRAIN_THRESHOLD", "200"))
# Minimum F1 improvement required to promote new model
_MIN_F1_IMPROVEMENT = float(os.environ.get("EA_MIN_F1_IMPROVEMENT", "-0.02"))


def _load_metadata() -> Dict:
    """Load training metadata (last train time, metrics)."""
    if os.path.exists(_METADATA_PATH):
        try:
            with open(_METADATA_PATH) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {"last_trained_at": 0, "last_entry_count": 0, "intent_f1": 0.0, "pii_f1": 0.0}


def _save_metadata(metadata: Dict):
    """Save training metadata."""
    os.makedirs(os.path.dirname(_METADATA_PATH), exist_ok=True)
    with open(_METADATA_PATH, "w") as f:
        json.dump(metadata, f, indent=2)


def _count_entries_since(paths: list, since_ts: float) -> int:
    """Count audit log entries newer than since_ts."""
    count = 0
    for path in paths:
        if not os.path.exists(path):
            continue
        with open(path) as f:
            for line in f:
                try:
                    entry = json.loads(line)
                    ts = entry.get("ts", "")
                    # Parse ISO timestamp to epoch
                    if isinstance(ts, str) and ts:
                        import datetime
                        try:
                            dt = datetime.datetime.fromisoformat(ts)
                            if dt.timestamp() > since_ts:
                                count += 1
                        except (ValueError, TypeError):
                            count += 1  # Can't parse = assume new
                    elif isinstance(ts, (int, float)) and ts > since_ts:
                        count += 1
                except (json.JSONDecodeError, TypeError):
                    continue
    return count


def _total_entries(paths: list) -> int:
    """Count total audit entries across all paths."""
    count = 0
    for path in paths:
        if not os.path.exists(path):
            continue
        with open(path) as f:
            for _ in f:
                count += 1
    return count


class ActiveLearner:
    """Auto-retrain ML classifiers when new audit data accumulates."""

    def __init__(
        self,
        audit_paths: Optional[list] = None,
        retrain_threshold: int = _RETRAIN_THRESHOLD,
        min_f1_improvement: float = _MIN_F1_IMPROVEMENT,
    ):
        self.audit_paths = audit_paths or _AUDIT_PATHS
        self.retrain_threshold = retrain_threshold
        self.min_f1_improvement = min_f1_improvement

    def should_retrain(self) -> Dict:
        """Check if retraining is needed.

        Returns:
            {"should_retrain": bool, "new_entries": int, "total_entries": int,
             "reason": str}
        """
        metadata = _load_metadata()
        last_trained = metadata.get("last_trained_at", 0)
        new_entries = _count_entries_since(self.audit_paths, last_trained)
        total = _total_entries(self.audit_paths)

        if new_entries >= self.retrain_threshold:
            return {
                "should_retrain": True,
                "new_entries": new_entries,
                "total_entries": total,
                "reason": f"{new_entries} new entries >= threshold {self.retrain_threshold}",
            }

        return {
            "should_retrain": False,
            "new_entries": new_entries,
            "total_entries": total,
            "reason": f"{new_entries} new entries < threshold {self.retrain_threshold}",
        }

    def check_and_retrain(self) -> Dict:
        """Check if retraining is needed and do it if so.

        Returns training results or skip reason.
        """
        check = self.should_retrain()
        if not check["should_retrain"]:
            logger.info("Active learner: skip — %s", check["reason"])
            return {"action": "skipped", **check}

        logger.info("Active learner: retraining — %s", check["reason"])
        return self._retrain(check)

    def _retrain(self, check: Dict) -> Dict:
        """Execute retraining with validation gate."""
        metadata = _load_metadata()
        old_intent_f1 = metadata.get("intent_f1", 0.0)
        old_pii_f1 = metadata.get("pii_f1", 0.0)

        # Import training functions
        try:
            import sys
            # Try AgnosticSecurity training script
            train_script = os.path.join(
                os.path.expanduser("~"), "AgnosticSecurity", "scripts"
            )
            if train_script not in sys.path:
                sys.path.insert(0, train_script)

            from train_enhanced_classifier import (
                load_audit_log,
                load_red_team_evals,
                generate_synthetic_benign,
                generate_pii_training_data,
                train_intent_model,
                train_pii_model,
                AUDIT_LOG,
                EVALS_DIR,
            )
        except ImportError as e:
            return {
                "action": "error",
                "reason": f"Training script not found: {e}",
                **check,
            }

        # Load data
        audit_samples = load_audit_log(AUDIT_LOG)
        red_team_samples = load_red_team_evals(EVALS_DIR)
        synthetic = generate_synthetic_benign()
        pii_samples = generate_pii_training_data()

        intent_data = audit_samples + red_team_samples + synthetic
        if len(intent_data) < 100:
            return {
                "action": "skipped",
                "reason": f"Not enough training data ({len(intent_data)} samples)",
                **check,
            }

        # Train new models
        intent_result = train_intent_model(intent_data)
        pii_result = train_pii_model(pii_samples)

        new_intent_f1 = intent_result.get("cv_f1_macro", 0.0)
        new_pii_f1 = pii_result.get("cv_f1_macro", 0.0)

        # Validation gate: new model must not be significantly worse
        intent_ok = new_intent_f1 >= (old_intent_f1 + self.min_f1_improvement)
        pii_ok = new_pii_f1 >= (old_pii_f1 + self.min_f1_improvement)

        if intent_ok and pii_ok:
            # Promote: save metadata
            _save_metadata({
                "last_trained_at": time.time(),
                "last_entry_count": check["total_entries"],
                "intent_f1": new_intent_f1,
                "pii_f1": new_pii_f1,
                "intent_samples": intent_result.get("samples", 0),
                "pii_samples": pii_result.get("samples", 0),
                "trained_by": "active_learner",
            })

            return {
                "action": "retrained",
                "intent_f1": {"old": old_intent_f1, "new": new_intent_f1},
                "pii_f1": {"old": old_pii_f1, "new": new_pii_f1},
                "intent_samples": intent_result.get("samples", 0),
                "pii_samples": pii_result.get("samples", 0),
                **check,
            }
        else:
            # Reject: new model is worse
            reasons = []
            if not intent_ok:
                reasons.append(f"intent F1 dropped: {old_intent_f1:.3f} -> {new_intent_f1:.3f}")
            if not pii_ok:
                reasons.append(f"PII F1 dropped: {old_pii_f1:.3f} -> {new_pii_f1:.3f}")

            return {
                "action": "rejected",
                "reason": "; ".join(reasons),
                "intent_f1": {"old": old_intent_f1, "new": new_intent_f1},
                "pii_f1": {"old": old_pii_f1, "new": new_pii_f1},
                **check,
            }
