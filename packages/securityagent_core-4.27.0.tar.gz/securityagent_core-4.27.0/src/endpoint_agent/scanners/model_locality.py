"""
Model locality detector — classifies LLM traffic as local vs cloud.

Used by the LLM proxy and DLP engine to dynamically adjust strictness:
  - local model  → data stays on-prem → more permissive DLP thresholds
  - cloud model  → data leaves the network → strict DLP thresholds

Classification sources (in priority order):
  1. Destination URL/host analysis (most reliable)
  2. Model name pattern matching (provider-specific prefixes)
  3. Agent runtime detection (sniff which coding agent is running)
"""

import os
import re
import subprocess
from enum import Enum
from typing import Optional


class ModelLocality(str, Enum):
    LOCAL = "local"
    CLOUD = "cloud"
    UNKNOWN = "unknown"


# Hosts that are definitively local
_LOCAL_HOSTS = {
    "localhost", "127.0.0.1", "0.0.0.0", "::1",
    "host.docker.internal", "host.containers.internal",
}

# Patterns for local network ranges
_LOCAL_NETWORK_RE = re.compile(
    r"^(?:10\.\d+\.\d+\.\d+|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+|192\.168\.\d+\.\d+)$"
)

# Known cloud API hosts
_CLOUD_HOSTS = {
    "api.openai.com",
    "api.anthropic.com",
    "api.cohere.ai",
    "api.cohere.com",
    "generativelanguage.googleapis.com",
    "api.mistral.ai",
    "api.together.xyz",
    "api.fireworks.ai",
    "api.groq.com",
    "api.deepseek.com",
    "api.perplexity.ai",
    "openrouter.ai",
    "api.replicate.com",
    "inference.cerebras.ai",
}

# Model name patterns that indicate local execution
_LOCAL_MODEL_PATTERNS = [
    re.compile(r"^ollama/"),
    re.compile(r"^local/"),
    re.compile(r"^lm-studio/"),
    re.compile(r"^llamafile/"),
]

# Known local inference servers (port-based detection)
_LOCAL_INFERENCE_PORTS = {
    11434,  # Ollama
    1234,   # LM Studio
    8080,   # llama.cpp / llamafile
    5000,   # text-generation-webui
    3000,   # LocalAI
    8000,   # vLLM default
}

# OpenRouter models that are self-hosted / local options
_OPENROUTER_LOCAL_PREFIXES = [
    "local/",
    "self-hosted/",
]


def classify_by_url(url: str) -> ModelLocality:
    """Classify model locality from the destination URL."""
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        host = parsed.hostname or ""
        port = parsed.port

        if host in _LOCAL_HOSTS or _LOCAL_NETWORK_RE.match(host):
            return ModelLocality.LOCAL

        if port and port in _LOCAL_INFERENCE_PORTS and host in _LOCAL_HOSTS:
            return ModelLocality.LOCAL

        if host in _CLOUD_HOSTS:
            return ModelLocality.CLOUD

        # .local mDNS domains are on-prem
        if host.endswith(".local"):
            return ModelLocality.LOCAL

    except Exception:
        pass
    return ModelLocality.UNKNOWN


def classify_by_model_name(model: str, provider: str = "") -> ModelLocality:
    """Classify locality from the model identifier string."""
    if not model:
        return ModelLocality.UNKNOWN

    model_lower = model.lower()

    for pat in _LOCAL_MODEL_PATTERNS:
        if pat.search(model_lower):
            return ModelLocality.LOCAL

    # Ollama provider is always local
    if provider == "ollama":
        return ModelLocality.LOCAL

    # OpenRouter can route to local models
    if provider == "openrouter":
        for prefix in _OPENROUTER_LOCAL_PREFIXES:
            if model_lower.startswith(prefix):
                return ModelLocality.LOCAL
        return ModelLocality.CLOUD

    # Known cloud model prefixes
    cloud_prefixes = (
        "gpt-", "claude-", "gemini-", "command-", "mistral-",
        "codestral-", "o1-", "o3-", "o4-",
    )
    if any(model_lower.startswith(p) for p in cloud_prefixes):
        return ModelLocality.CLOUD

    return ModelLocality.UNKNOWN


def classify_request(
    url: str = "",
    model: str = "",
    provider: str = "",
    headers: Optional[dict] = None,
) -> ModelLocality:
    """Classify a request's model locality using all available signals.

    Combines URL analysis, model name, provider, and headers.
    Returns the highest-confidence classification.
    """
    # URL is the strongest signal
    url_result = classify_by_url(url)
    if url_result != ModelLocality.UNKNOWN:
        return url_result

    # Model name / provider is next
    model_result = classify_by_model_name(model, provider)
    if model_result != ModelLocality.UNKNOWN:
        return model_result

    # Check headers for provider hints
    if headers:
        if headers.get("anthropic-version"):
            return ModelLocality.CLOUD
        auth = headers.get("Authorization", "")
        if auth.startswith("Bearer sk-"):
            return ModelLocality.CLOUD

    return ModelLocality.UNKNOWN


# ---------------------------------------------------------------------------
# Agent runtime detection
# ---------------------------------------------------------------------------

class AgentRuntime:
    """Detected coding agent runtime and its model configuration."""

    def __init__(self, name: str, model: str = "", locality: ModelLocality = ModelLocality.UNKNOWN):
        self.name = name
        self.model = model
        self.locality = locality

    def __repr__(self):
        return f"AgentRuntime(name={self.name!r}, model={self.model!r}, locality={self.locality.value})"


def _check_process_running(name: str) -> bool:
    """Check if a process with the given name is running."""
    try:
        result = subprocess.run(
            ["pgrep", "-f", name],
            capture_output=True, timeout=2,
        )
        return result.returncode == 0
    except Exception:
        return False


def _read_json_file(path: str) -> dict:
    """Safely read a JSON file."""
    try:
        import json
        with open(os.path.expanduser(path), "r") as f:
            return json.load(f)
    except Exception:
        return {}


def detect_agent_runtime() -> AgentRuntime:
    """Detect which AI coding agent is running and infer its model.

    Checks (in order):
      1. Claude Code — looks for .claude/ config and running process
      2. Cursor — checks ~/.cursor/settings.json for model config
      3. Copilot — checks VS Code copilot settings
      4. Continue.dev — checks ~/.continue/config.json
    """
    # Claude Code
    if os.path.exists(os.path.expanduser("~/.claude")):
        if _check_process_running("claude"):
            return AgentRuntime("claude-code", "claude-sonnet-4-6", ModelLocality.CLOUD)

    # Cursor
    cursor_settings = _read_json_file("~/.cursor/settings.json")
    if cursor_settings:
        model = cursor_settings.get("cursor.model", cursor_settings.get("model", ""))
        if model:
            locality = classify_by_model_name(model)
            return AgentRuntime("cursor", model, locality)
        if _check_process_running("Cursor"):
            return AgentRuntime("cursor", "", ModelLocality.UNKNOWN)

    # Continue.dev (supports local models)
    continue_config = _read_json_file("~/.continue/config.json")
    if continue_config:
        models = continue_config.get("models", [])
        if models:
            first = models[0] if isinstance(models[0], dict) else {}
            provider = first.get("provider", "")
            model = first.get("model", "")
            if provider in ("ollama", "llamafile", "lmstudio"):
                return AgentRuntime("continue", model, ModelLocality.LOCAL)
            locality = classify_by_model_name(model, provider)
            return AgentRuntime("continue", model, locality)

    # GitHub Copilot (always cloud)
    copilot_paths = [
        "~/.config/github-copilot/settings.json",
        "~/.github-copilot/settings.json",
    ]
    for path in copilot_paths:
        if os.path.exists(os.path.expanduser(path)):
            return AgentRuntime("copilot", "copilot", ModelLocality.CLOUD)

    # Aider
    aider_config = _read_json_file("~/.aider.conf.yml")
    if aider_config:
        model = aider_config.get("model", "")
        locality = classify_by_model_name(model)
        return AgentRuntime("aider", model, locality)

    return AgentRuntime("unknown")


def get_dlp_threshold(
    base_threshold: float,
    locality: ModelLocality,
) -> float:
    """Compute effective DLP confidence threshold based on model locality.

    Local models get a higher threshold (more permissive) since data stays on-prem.
    Cloud models use the base threshold (strict).
    Unknown defaults to strict (fail safe).
    """
    from endpoint_agent.config.settings import DLP_LOCALITY_AWARE, DLP_LOCAL_MULTIPLIER

    if not DLP_LOCALITY_AWARE:
        return base_threshold

    if locality == ModelLocality.LOCAL:
        return min(base_threshold * DLP_LOCAL_MULTIPLIER, 0.95)

    # Cloud and unknown → strict
    return base_threshold
