"""
NIST SP 800-53 compliance tagger for DLP findings.

Maps DLP findings and document content to relevant NIST 800-53 control IDs
using the keyword taxonomy from control_keywords_with_scored_severity.xlsx
(converted to nist_800_53_keywords.json).

Three integration points:
  1. classify_nist_controls(text) — tag text with relevant control IDs
  2. tag_finding(finding) — enrich a DLP finding with NIST control IDs
  3. coverage_report() — which controls the DLP engine covers
"""

import json
import os
import re
from functools import lru_cache
from typing import Dict, List, Optional, Set, Tuple

# ---------------------------------------------------------------------------
# Keyword index loading (cached singleton)
# ---------------------------------------------------------------------------

_KEYWORD_INDEX: Optional[Dict] = None
_CONTROLS: Optional[Dict] = None
_FAMILIES: Optional[Dict] = None

# Search paths for the keyword JSON
_SEARCH_PATHS = [
    os.path.join(os.path.dirname(__file__), "..", "..", "..", "..",
                 "AgnosticSecurity", "nist_800_53_keywords.json"),
    os.path.join(os.path.dirname(__file__), "..", "..", "..",
                 "nist_800_53_keywords.json"),
    os.environ.get("EA_NIST_KEYWORDS_PATH", ""),
    os.path.expanduser("~/AgnosticSecurity/nist_800_53_keywords.json"),
]


def _load_index() -> Tuple[Dict, Dict, Dict]:
    """Load the keyword index from JSON. Cached after first call."""
    global _KEYWORD_INDEX, _CONTROLS, _FAMILIES
    if _KEYWORD_INDEX is not None:
        return _KEYWORD_INDEX, _CONTROLS, _FAMILIES

    for path in _SEARCH_PATHS:
        if path and os.path.exists(path):
            with open(path, "r") as f:
                data = json.load(f)
            _KEYWORD_INDEX = data["keyword_index"]
            _CONTROLS = data["controls"]
            _FAMILIES = data["families"]
            return _KEYWORD_INDEX, _CONTROLS, _FAMILIES

    # Fallback: empty index (no tagging, no crash)
    _KEYWORD_INDEX = {}
    _CONTROLS = {}
    _FAMILIES = {}
    return _KEYWORD_INDEX, _CONTROLS, _FAMILIES


# ---------------------------------------------------------------------------
# DLP pattern → NIST control mapping
# ---------------------------------------------------------------------------
# Maps AgnosticSecurity's DLP finding types to the NIST controls they enforce.
# This is the authoritative mapping — keyword tagging adds supplementary
# controls, but these are always included.

_FINDING_TO_CONTROLS = {
    # PII patterns
    "SSN": ["AC-4", "SI-10", "SC-28", "MP-6"],
    "Credit Card": ["AC-4", "SI-10", "SC-28", "SC-8"],
    "US Phone": ["AC-4", "SI-10"],
    "Email Address": ["AC-4"],
    "US Passport": ["AC-4", "SI-10", "SC-28"],
    "Date of Birth": ["AC-4", "SI-10"],
    "IBAN": ["AC-4", "SI-10", "SC-28"],
    "Canadian SIN": ["AC-4", "SI-10", "SC-28"],
    "UK NINO": ["AC-4", "SI-10", "SC-28"],
    "Drivers License": ["AC-4", "SI-10"],
    # Healthcare PII
    "NPI Number": ["AC-4", "SI-10", "SC-28"],
    "Medical Record Number": ["AC-4", "SI-10", "SC-28"],
    "DEA Number": ["AC-4", "SI-10", "SC-28"],
    "ICD-10 Code": ["AC-4", "SI-10"],
    "Insurance Member ID": ["AC-4", "SI-10"],
    # Credentials
    "AWS Access Key": ["AC-3", "IA-5", "SC-12", "SC-28"],
    "AWS Secret Key": ["AC-3", "IA-5", "SC-12", "SC-28"],
    "Generic API Key": ["AC-3", "IA-5", "SC-12"],
    "Generic Secret": ["AC-3", "IA-5", "SC-12"],
    "GitHub Token": ["AC-3", "IA-5", "SC-12"],
    "Slack Token": ["AC-3", "IA-5", "SC-12"],
    "Stripe Key": ["AC-3", "IA-5", "SC-12", "SC-28"],
    "JWT Token": ["AC-3", "IA-5", "SC-8"],
    "Private Key Header": ["AC-3", "IA-5", "SC-12", "SC-28"],
    "Database URL": ["AC-3", "IA-5", "SC-8", "SC-28"],
    # Document fingerprints
    "W-2 Tax Form": ["AC-4", "SC-28", "MP-4"],
    "1040 Tax Return": ["AC-4", "SC-28", "MP-4"],
    "1099 Tax Form": ["AC-4", "SC-28", "MP-4"],
    "Medical Record": ["AC-4", "SC-28", "MP-4"],
    "HIPAA Document": ["AC-4", "SC-28", "MP-4"],
    "I-9 Employment": ["AC-4", "SC-28", "MP-4"],
    "NDA": ["AC-4", "SC-28"],
    # Semantic disclosures
    "NL Password Disclosure": ["AC-3", "IA-5", "SC-12"],
    "NL API Key Disclosure": ["AC-3", "IA-5", "SC-12"],
    "NL Secret Disclosure": ["AC-3", "IA-5", "SC-12"],
    "NL Database Creds": ["AC-3", "IA-5", "SC-8", "SC-28"],
    "NL Bearer Token": ["AC-3", "IA-5", "SC-8"],
    "NL Credentials Block": ["AC-3", "IA-5", "SC-12"],
    # Exec guard categories
    "dotfile_read": ["AC-3", "SC-28"],
    "env_var_dump": ["AC-3", "SC-28", "IA-5"],
    "encoded_file_exfil": ["AC-4", "SC-7", "SC-8"],
    "raw_socket_exfil": ["AC-4", "SC-7"],
    "reverse_shell": ["AC-4", "SC-7", "SI-3"],
    "dns_exfil": ["AC-4", "SC-7"],
    "potential_exfil_upload": ["AC-4", "SC-7", "SC-8"],
    "curl_pipe_to_shell": ["SI-3", "CM-7"],
    "crontab_injection": ["SI-3", "CM-5"],
    "sensitive_file_discovery": ["AC-3", "SC-28"],
    "keychain_extraction": ["AC-3", "IA-5", "SC-12"],
}

# Exec guard labels to NIST families (for the audit trail)
_EXEC_GUARD_FAMILIES = {
    "AC": "Access Control",
    "IA": "Identification and Authentication",
    "SC": "System and Communications Protection",
    "SI": "System and Information Integrity",
    "CM": "Configuration Management",
    "MP": "Media Protection",
}


# ---------------------------------------------------------------------------
# 1. classify_nist_controls — tag text with relevant control IDs
# ---------------------------------------------------------------------------

def classify_nist_controls(
    text: str,
    min_severity: int = 2,
    max_controls: int = 10,
) -> List[Dict]:
    """Scan text for NIST 800-53 keyword matches.

    Returns a list of matched controls sorted by severity (highest first),
    each with: control_id, family, family_name, severity, matched_keywords.

    Args:
        text: The text to scan (document content, prompt, etc.)
        min_severity: Minimum keyword severity to include (1-5)
        max_controls: Maximum number of controls to return
    """
    keyword_index, controls, families = _load_index()
    if not keyword_index:
        return []

    text_lower = text.lower()

    # Match keywords against text
    control_hits: Dict[str, Dict] = {}

    for keyword, mappings in keyword_index.items():
        # Use word boundary matching for short keywords, substring for long ones
        if len(keyword) < 15:
            pattern = r"\b" + re.escape(keyword) + r"\b"
            if not re.search(pattern, text_lower):
                continue
        else:
            if keyword not in text_lower:
                continue

        for mapping in mappings:
            cid = mapping["control_id"]
            sev = mapping["severity"]
            if sev < min_severity:
                continue

            if cid not in control_hits:
                prefix = cid.split("-")[0]
                control_hits[cid] = {
                    "control_id": cid,
                    "family": prefix,
                    "family_name": families.get(prefix, prefix),
                    "severity": sev,
                    "matched_keywords": [keyword],
                }
            else:
                if sev > control_hits[cid]["severity"]:
                    control_hits[cid]["severity"] = sev
                if keyword not in control_hits[cid]["matched_keywords"]:
                    control_hits[cid]["matched_keywords"].append(keyword)

    # Sort by severity (descending), then by number of keyword hits
    results = sorted(
        control_hits.values(),
        key=lambda x: (x["severity"], len(x["matched_keywords"])),
        reverse=True,
    )

    return results[:max_controls]


# ---------------------------------------------------------------------------
# 2. tag_finding — enrich a DLP finding with NIST control IDs
# ---------------------------------------------------------------------------

def tag_finding(finding: Dict, context_text: str = "") -> Dict:
    """Add nist_controls field to a DLP finding.

    Combines:
      - Direct mapping from finding pattern/type to known controls
      - Keyword-based tagging from the surrounding context text

    Args:
        finding: A DLP finding dict with at minimum 'pattern' or 'label' key.
        context_text: Optional surrounding text for keyword-based enrichment.

    Returns:
        The finding dict with 'nist_controls' list added.
    """
    pattern = finding.get("pattern", finding.get("label", ""))

    # Direct mapping
    direct_controls = set(_FINDING_TO_CONTROLS.get(pattern, []))

    # Keyword-based enrichment from context
    keyword_controls = set()
    if context_text:
        matches = classify_nist_controls(context_text, min_severity=3, max_controls=5)
        for match in matches:
            keyword_controls.add(match["control_id"])

    all_controls = sorted(direct_controls | keyword_controls)

    finding["nist_controls"] = all_controls
    return finding


def tag_findings(findings: List[Dict], context_text: str = "") -> List[Dict]:
    """Tag a list of DLP findings with NIST control IDs."""
    for f in findings:
        tag_finding(f, context_text)
    return findings


# ---------------------------------------------------------------------------
# 3. coverage_report — which controls the DLP engine covers
# ---------------------------------------------------------------------------

def coverage_report() -> Dict:
    """Generate a coverage report: which NIST 800-53 controls are
    defended by AgnosticSecurity's DLP engine.

    Returns a dict with:
      - total_controls: number of controls in the taxonomy
      - covered_controls: controls with at least one DLP mapping
      - covered_families: families with at least one covered control
      - coverage_by_family: per-family breakdown
      - uncovered_controls: controls with no DLP mapping
    """
    _, controls, families = _load_index()
    if not controls:
        return {"error": "keyword index not loaded"}

    # All controls directly mapped via _FINDING_TO_CONTROLS
    covered_ids: Set[str] = set()
    for control_list in _FINDING_TO_CONTROLS.values():
        covered_ids.update(control_list)

    # Per-family breakdown
    family_stats: Dict[str, Dict] = {}
    for cid, info in controls.items():
        fam = info["family"]
        if fam not in family_stats:
            family_stats[fam] = {
                "family_name": info["family_name"],
                "total": 0,
                "covered": 0,
                "control_ids": [],
                "covered_ids": [],
            }
        family_stats[fam]["total"] += 1
        family_stats[fam]["control_ids"].append(cid)
        if cid in covered_ids:
            family_stats[fam]["covered"] += 1
            family_stats[fam]["covered_ids"].append(cid)

    # Sort families by coverage percentage
    for fam in family_stats:
        total = family_stats[fam]["total"]
        covered = family_stats[fam]["covered"]
        family_stats[fam]["coverage_pct"] = round(
            covered / total * 100, 1
        ) if total > 0 else 0.0

    covered_families = {
        fam for fam, stats in family_stats.items() if stats["covered"] > 0
    }

    return {
        "total_controls": len(controls),
        "covered_controls": len(covered_ids),
        "coverage_pct": round(len(covered_ids) / len(controls) * 100, 1)
            if controls else 0.0,
        "covered_families": len(covered_families),
        "total_families": len(family_stats),
        "coverage_by_family": {
            fam: {
                "family_name": stats["family_name"],
                "covered": stats["covered"],
                "total": stats["total"],
                "coverage_pct": stats["coverage_pct"],
            }
            for fam, stats in sorted(
                family_stats.items(),
                key=lambda x: x[1]["coverage_pct"],
                reverse=True,
            )
        },
    }
