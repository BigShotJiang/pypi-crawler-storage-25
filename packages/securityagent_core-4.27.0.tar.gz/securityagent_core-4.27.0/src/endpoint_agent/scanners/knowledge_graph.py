"""
Security Knowledge Graph — unified SQLite-backed store for cross-session
security state.

Replaces the scattered JSON persistence files (taint_registry.json,
trifecta_state.json) with a queryable graph of nodes, edges, and events.

Node types: THREAT, DATA_ASSET, AGENT, INCIDENT, POLICY, FILE, DOMAIN, SESSION
Edge types: ACCESSED, BLOCKED, EXFILTRATED, TAINTED, TRIGGERED, CORRELATED
"""

import json
import os
import sqlite3
import threading
import time
import uuid
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

_STATE_DIR = Path(os.environ.get("EA_STATE_DIR", str(Path.home() / ".cache" / "agnosticsecurity")))
_DEFAULT_DB = str(_STATE_DIR / "security_graph.db")
_DEFAULT_TTL = int(os.environ.get("EA_KNOWLEDGE_GRAPH_TTL", "259200"))  # 72h

KNOWLEDGE_GRAPH_ENABLED = os.environ.get(
    "EA_KNOWLEDGE_GRAPH", "true"
).lower() == "true"


class NodeType(str, Enum):
    THREAT = "THREAT"
    DATA_ASSET = "DATA_ASSET"
    AGENT = "AGENT"
    INCIDENT = "INCIDENT"
    POLICY = "POLICY"
    FILE = "FILE"
    DOMAIN = "DOMAIN"
    SESSION = "SESSION"


class EdgeType(str, Enum):
    ACCESSED = "ACCESSED"
    BLOCKED = "BLOCKED"
    EXFILTRATED = "EXFILTRATED"
    TAINTED = "TAINTED"
    TRIGGERED = "TRIGGERED"
    CORRELATED = "CORRELATED"


class SecurityKnowledgeGraph:
    """SQLite-backed security knowledge graph with TTL support."""

    def __init__(self, db_path: Optional[str] = None) -> None:
        self._db_path = db_path or os.environ.get(
            "EA_KNOWLEDGE_GRAPH_DB", _DEFAULT_DB
        )
        self._lock = threading.Lock()
        _STATE_DIR.mkdir(parents=True, exist_ok=True)
        self._init_db()
        self._expire_stale()
        self._migrate_legacy()

    # -- schema ------------------------------------------------------------

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS nodes (
                    id         TEXT PRIMARY KEY,
                    node_type  TEXT NOT NULL,
                    label      TEXT NOT NULL,
                    metadata   TEXT DEFAULT '{}',
                    created_at REAL NOT NULL,
                    expires_at REAL
                );
                CREATE INDEX IF NOT EXISTS idx_nodes_type
                    ON nodes(node_type);
                CREATE INDEX IF NOT EXISTS idx_nodes_expires
                    ON nodes(expires_at);

                CREATE TABLE IF NOT EXISTS edges (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_id  TEXT NOT NULL,
                    target_id  TEXT NOT NULL,
                    edge_type  TEXT NOT NULL,
                    metadata   TEXT DEFAULT '{}',
                    created_at REAL NOT NULL,
                    FOREIGN KEY (source_id) REFERENCES nodes(id),
                    FOREIGN KEY (target_id) REFERENCES nodes(id)
                );
                CREATE INDEX IF NOT EXISTS idx_edges_source
                    ON edges(source_id);
                CREATE INDEX IF NOT EXISTS idx_edges_target
                    ON edges(target_id);
                CREATE INDEX IF NOT EXISTS idx_edges_type
                    ON edges(edge_type);

                CREATE TABLE IF NOT EXISTS events (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    severity   TEXT NOT NULL,
                    details    TEXT DEFAULT '{}',
                    timestamp  REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_events_time
                    ON events(timestamp);
                CREATE INDEX IF NOT EXISTS idx_events_type
                    ON events(event_type);
            """)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path, timeout=5)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=3000")
        return conn

    # -- nodes -------------------------------------------------------------

    def add_node(
        self,
        node_type: str,
        label: str,
        metadata: Optional[Dict] = None,
        ttl_seconds: int = _DEFAULT_TTL,
        node_id: Optional[str] = None,
    ) -> str:
        nid = node_id or str(uuid.uuid4())[:12]
        now = time.time()
        expires = now + ttl_seconds if ttl_seconds > 0 else None
        meta_json = json.dumps(metadata or {})
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    """INSERT OR REPLACE INTO nodes
                       (id, node_type, label, metadata, created_at, expires_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (nid, node_type, label, meta_json, now, expires),
                )
        return nid

    def get_node(self, node_id: str) -> Optional[Dict]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM nodes WHERE id = ?", (node_id,)
            ).fetchone()
            if row:
                return self._row_to_dict(row)
        return None

    def find_nodes(
        self,
        node_type: Optional[str] = None,
        label_contains: Optional[str] = None,
        since: Optional[float] = None,
        limit: int = 100,
    ) -> List[Dict]:
        clauses: List[str] = []
        params: List[Any] = []
        if node_type:
            clauses.append("node_type = ?")
            params.append(node_type)
        if label_contains:
            clauses.append("label LIKE ?")
            params.append(f"%{label_contains}%")
        if since:
            clauses.append("created_at >= ?")
            params.append(since)

        where = " AND ".join(clauses) if clauses else "1=1"
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM nodes WHERE {where} ORDER BY created_at DESC LIMIT ?",
                params + [limit],
            ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def delete_node(self, node_id: str) -> None:
        with self._lock:
            with self._connect() as conn:
                conn.execute("DELETE FROM edges WHERE source_id = ? OR target_id = ?",
                             (node_id, node_id))
                conn.execute("DELETE FROM nodes WHERE id = ?", (node_id,))

    # -- edges -------------------------------------------------------------

    def add_edge(
        self,
        source_id: str,
        target_id: str,
        edge_type: str,
        metadata: Optional[Dict] = None,
    ) -> int:
        now = time.time()
        meta_json = json.dumps(metadata or {})
        with self._lock:
            with self._connect() as conn:
                cur = conn.execute(
                    """INSERT INTO edges
                       (source_id, target_id, edge_type, metadata, created_at)
                       VALUES (?, ?, ?, ?, ?)""",
                    (source_id, target_id, edge_type, meta_json, now),
                )
                return cur.lastrowid  # type: ignore[return-value]

    def get_related(
        self,
        node_id: str,
        edge_type: Optional[str] = None,
        direction: str = "both",
    ) -> List[Dict]:
        results = []
        with self._connect() as conn:
            if direction in ("out", "both"):
                q = "SELECT e.*, n.label as target_label, n.node_type as target_node_type FROM edges e JOIN nodes n ON e.target_id = n.id WHERE e.source_id = ?"
                params: List[Any] = [node_id]
                if edge_type:
                    q += " AND e.edge_type = ?"
                    params.append(edge_type)
                results.extend(
                    self._row_to_dict(r) for r in conn.execute(q, params).fetchall()
                )
            if direction in ("in", "both"):
                q = "SELECT e.*, n.label as source_label, n.node_type as source_node_type FROM edges e JOIN nodes n ON e.source_id = n.id WHERE e.target_id = ?"
                params = [node_id]
                if edge_type:
                    q += " AND e.edge_type = ?"
                    params.append(edge_type)
                results.extend(
                    self._row_to_dict(r) for r in conn.execute(q, params).fetchall()
                )
        return results

    # -- events ------------------------------------------------------------

    def log_event(
        self, event_type: str, severity: str, details: Optional[Dict] = None
    ) -> int:
        now = time.time()
        det_json = json.dumps(details or {})
        with self._lock:
            with self._connect() as conn:
                cur = conn.execute(
                    "INSERT INTO events (event_type, severity, details, timestamp) VALUES (?, ?, ?, ?)",
                    (event_type, severity, det_json, now),
                )
                return cur.lastrowid  # type: ignore[return-value]

    def get_events(
        self,
        event_type: Optional[str] = None,
        since: Optional[float] = None,
        limit: int = 100,
    ) -> List[Dict]:
        clauses: List[str] = []
        params: List[Any] = []
        if event_type:
            clauses.append("event_type = ?")
            params.append(event_type)
        if since:
            clauses.append("timestamp >= ?")
            params.append(since)
        where = " AND ".join(clauses) if clauses else "1=1"
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM events WHERE {where} ORDER BY timestamp DESC LIMIT ?",
                params + [limit],
            ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    # -- pattern queries ---------------------------------------------------

    def get_incident_chain(self, incident_node_id: str) -> List[Dict]:
        """Walk edges from an incident node to reconstruct the full chain."""
        visited = set()
        chain: List[Dict] = []
        queue = [incident_node_id]
        while queue:
            nid = queue.pop(0)
            if nid in visited:
                continue
            visited.add(nid)
            node = self.get_node(nid)
            if node:
                chain.append(node)
            for edge in self.get_related(nid, direction="out"):
                target = edge.get("target_id")
                if target and target not in visited:
                    queue.append(target)
        return chain

    def correlate_events(self, time_window: float = 300) -> List[List[Dict]]:
        """Find clusters of events within time_window seconds that share nodes."""
        events = self.get_events(limit=500)
        if not events:
            return []

        clusters: List[List[Dict]] = []
        used = set()

        for i, ev in enumerate(events):
            if i in used:
                continue
            cluster = [ev]
            used.add(i)
            for j in range(i + 1, len(events)):
                if j in used:
                    continue
                if abs(ev["timestamp"] - events[j]["timestamp"]) <= time_window:
                    cluster.append(events[j])
                    used.add(j)
            if len(cluster) > 1:
                clusters.append(cluster)

        return clusters

    def get_stats(self) -> Dict:
        """Return summary counts."""
        with self._connect() as conn:
            node_count = conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
            edge_count = conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
            event_count = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            type_counts = {}
            for row in conn.execute(
                "SELECT node_type, COUNT(*) as cnt FROM nodes GROUP BY node_type"
            ).fetchall():
                type_counts[row["node_type"]] = row["cnt"]
        return {
            "total_nodes": node_count,
            "total_edges": edge_count,
            "total_events": event_count,
            "nodes_by_type": type_counts,
        }

    # -- maintenance -------------------------------------------------------

    def _expire_stale(self) -> None:
        now = time.time()
        with self._lock:
            with self._connect() as conn:
                stale_ids = [
                    r["id"]
                    for r in conn.execute(
                        "SELECT id FROM nodes WHERE expires_at IS NOT NULL AND expires_at < ?",
                        (now,),
                    ).fetchall()
                ]
                if stale_ids:
                    placeholders = ",".join("?" * len(stale_ids))
                    conn.execute(
                        f"DELETE FROM edges WHERE source_id IN ({placeholders}) OR target_id IN ({placeholders})",
                        stale_ids + stale_ids,
                    )
                    conn.execute(
                        f"DELETE FROM nodes WHERE id IN ({placeholders})",
                        stale_ids,
                    )

    def _migrate_legacy(self) -> None:
        """Import taint_registry.json and trifecta_state.json on first run."""
        taint_path = _STATE_DIR / "taint_registry.json"
        trifecta_path = _STATE_DIR / "trifecta_state.json"

        # Skip migration if already done — the .migrated marker means we
        # already imported this data. Without this guard, the trifecta tracker's
        # _persist() triggers get_knowledge_graph() which re-runs migration and
        # deletes the freshly written trifecta_state.json.
        taint_migrated = taint_path.with_suffix(".migrated").exists()
        trifecta_migrated = trifecta_path.with_suffix(".migrated").exists()

        if taint_path.exists() and not taint_migrated:
            try:
                with open(taint_path) as f:
                    entries = json.load(f)
                if isinstance(entries, list):
                    for entry in entries:
                        label = entry.get("source_label", "unknown")
                        self.add_node(
                            NodeType.DATA_ASSET.value,
                            label,
                            metadata={
                                "fingerprint": entry.get("fingerprint", ""),
                                "pattern_type": entry.get("pattern_type", ""),
                                "migrated": True,
                            },
                        )
                taint_path.rename(taint_path.with_suffix(".migrated"))
            except (json.JSONDecodeError, OSError):
                pass

        if trifecta_path.exists() and not trifecta_migrated:
            try:
                with open(trifecta_path) as f:
                    state = json.load(f)
                if isinstance(state, dict):
                    session_id = self.add_node(
                        NodeType.SESSION.value,
                        "migrated_trifecta_session",
                        metadata=state,
                    )
                    for condition in ["private_data", "untrusted_input", "external_comm"]:
                        if state.get(f"{condition}_active"):
                            self.add_node(
                                NodeType.THREAT.value,
                                f"trifecta_{condition}",
                                metadata={
                                    "sources": state.get(f"{condition}_sources", []),
                                    "migrated": True,
                                },
                            )
                trifecta_path.rename(trifecta_path.with_suffix(".migrated"))
            except (json.JSONDecodeError, OSError):
                pass

    def close(self) -> None:
        pass  # connections are per-call via context manager

    # -- helpers -----------------------------------------------------------

    @staticmethod
    def _row_to_dict(row: sqlite3.Row) -> Dict:
        d = dict(row)
        for key in ("metadata", "details"):
            if key in d and isinstance(d[key], str):
                try:
                    d[key] = json.loads(d[key])
                except json.JSONDecodeError:
                    pass
        return d


# -- singleton -------------------------------------------------------------

_graph_instance: Optional[SecurityKnowledgeGraph] = None
_graph_lock = threading.Lock()


def get_knowledge_graph() -> SecurityKnowledgeGraph:
    global _graph_instance
    if _graph_instance is None:
        with _graph_lock:
            if _graph_instance is None:
                _graph_instance = SecurityKnowledgeGraph()
    return _graph_instance
