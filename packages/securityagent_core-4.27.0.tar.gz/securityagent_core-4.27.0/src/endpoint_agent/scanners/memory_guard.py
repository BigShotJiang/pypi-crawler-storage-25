"""
MemoryGuard — protects memory-augmented agents from:
  1. Memory poisoning (injected false authorizations)
  2. Trust boundary violations (tool results impersonating user)
  3. Privileged knowledge leakage (agent volunteering internal context)

Integrates into the existing hook pipeline and output pipeline.
"""

import re
from typing import Callable, Dict, List, Optional, Tuple


class MemoryGuard:
    """Scans memory writes, tool results, and outputs for memory-agent threats."""

    def __init__(self, alert_callback: Callable):
        self.alert_callback = alert_callback
        self._poisoning_patterns = self._compile_patterns("MEMORY_POISONING_PATTERNS")
        self._trust_patterns = self._compile_patterns("TRUST_BOUNDARY_PATTERNS")
        self._leakage_patterns = self._compile_patterns("PRIVILEGED_KNOWLEDGE_PATTERNS")

    @staticmethod
    def _compile_patterns(setting_name: str) -> List[Tuple[re.Pattern, str, float]]:
        """Load and compile patterns from settings."""
        from endpoint_agent.config.settings import (
            MEMORY_POISONING_PATTERNS,
            TRUST_BOUNDARY_PATTERNS,
            PRIVILEGED_KNOWLEDGE_PATTERNS,
        )
        source = {
            "MEMORY_POISONING_PATTERNS": MEMORY_POISONING_PATTERNS,
            "TRUST_BOUNDARY_PATTERNS": TRUST_BOUNDARY_PATTERNS,
            "PRIVILEGED_KNOWLEDGE_PATTERNS": PRIVILEGED_KNOWLEDGE_PATTERNS,
        }[setting_name]

        compiled = []
        for entry in source:
            try:
                regex = re.compile(entry["pattern"])
                label = entry["label"]
                weight = entry.get("weight", 0.8)
                compiled.append((regex, label, weight))
            except re.error:
                continue
        return compiled

    def scan_memory_write(self, content: str) -> Dict:
        """Scan content being written to agent memory for poisoning attempts.

        Called on PreMemoryWrite hook events or when an agent attempts to
        persist context (Claude Code memory, LangChain ConversationMemory,
        Autogen teachable agent state).

        Returns:
            Dict with keys: blocked (bool), findings (list), risk_score (float)
        """
        findings = []
        max_score = 0.0

        for regex, label, weight in self._poisoning_patterns:
            match = regex.search(content)
            if match:
                findings.append({
                    "type": "memory_poisoning",
                    "pattern": label,
                    "matched": match.group(0)[:80],
                    "weight": weight,
                })
                max_score = max(max_score, weight)

        should_block = max_score >= 0.85

        if findings:
            self.alert_callback(
                severity="CRITICAL" if should_block else "WARNING",
                event_type="memory_poisoning_detected",
                details={
                    "finding_count": len(findings),
                    "findings": findings[:5],
                    "risk_score": max_score,
                    "blocked": should_block,
                },
            )

        return {
            "blocked": should_block,
            "findings": findings,
            "risk_score": max_score,
            "reason": f"memory poisoning: {findings[0]['pattern']}" if findings else "",
        }

    def scan_trust_boundary(self, content: str, source: str = "tool_result") -> Dict:
        """Scan content from a tool result for trust boundary violations.

        Tool results should NEVER contain imperative instructions, authority
        claims, or bypass directives. These patterns indicate injection via
        tool output (MCP server response, web fetch, file content).

        Args:
            content: The tool result content to scan.
            source: Origin label (e.g. "mcp_server", "web_fetch", "file_read").

        Returns:
            Dict with keys: violated (bool), findings (list), risk_score (float)
        """
        findings = []
        max_score = 0.0

        for regex, label, weight in self._trust_patterns:
            match = regex.search(content)
            if match:
                findings.append({
                    "type": "trust_boundary_violation",
                    "pattern": label,
                    "source": source,
                    "matched": match.group(0)[:80],
                    "weight": weight,
                })
                max_score = max(max_score, weight)

        violated = max_score >= 0.75

        if findings:
            self.alert_callback(
                severity="CRITICAL" if violated else "WARNING",
                event_type="trust_boundary_violation",
                details={
                    "source": source,
                    "finding_count": len(findings),
                    "findings": findings[:5],
                    "risk_score": max_score,
                    "violated": violated,
                },
            )

        return {
            "violated": violated,
            "findings": findings,
            "risk_score": max_score,
            "reason": f"trust boundary: {findings[0]['pattern']}" if findings else "",
        }

    def scan_output_leakage(self, output: str) -> Dict:
        """Scan agent output for privileged knowledge leakage.

        Detects when an agent volunteers organizational context, internal
        infrastructure details, or team information that wasn't explicitly
        requested. This is a passive leak — no attacker needed.

        Args:
            output: The agent's response text to scan.

        Returns:
            Dict with keys: has_leakage (bool), findings (list), redacted (str)
        """
        findings = []

        for regex, label, _ in self._leakage_patterns:
            for match in regex.finditer(output):
                findings.append({
                    "type": "privileged_knowledge_leak",
                    "pattern": label,
                    "matched": match.group(0)[:80],
                    "position": match.start(),
                })

        has_leakage = len(findings) > 0

        # Redact leaked context from output
        redacted = output
        if has_leakage:
            for regex, label, _ in self._leakage_patterns:
                redacted = regex.sub("[REDACTED:internal_context]", redacted)

            self.alert_callback(
                severity="WARNING",
                event_type="privileged_knowledge_leakage",
                details={
                    "finding_count": len(findings),
                    "findings": findings[:5],
                },
            )

        return {
            "has_leakage": has_leakage,
            "findings": findings,
            "redacted": redacted,
        }
