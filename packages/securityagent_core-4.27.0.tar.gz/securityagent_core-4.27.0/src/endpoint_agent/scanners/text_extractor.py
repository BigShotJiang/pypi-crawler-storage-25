"""
Text extraction from binary document formats for DLP scanning.

Extracts readable text from PDF, XLSX, DOCX, and CSV files so the existing
regex-based DLP scanner can detect PII and credentials inside them.
Libraries are imported lazily — extraction degrades gracefully if a library
is not installed.

PDF extraction pipeline:
  1. PyMuPDF (fitz) — fast embedded text extraction
  2. Tesseract OCR  — fallback for scanned/image-based pages
  3. pypdf           — final fallback if PyMuPDF unavailable
  Encrypted PDFs are detected early and raise PasswordProtectedError.
"""

import csv
import io
import logging
from pathlib import Path
from typing import Dict, Generator, List

from endpoint_agent.config.settings import SENSITIVE_CSV_HEADERS

logger = logging.getLogger(__name__)

_DEFAULT_CHUNK_SIZE = 512_000  # ~500 KB per chunk


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract_text(path: str) -> str:
    """Extract readable text from a file, dispatching by extension.

    Returns the extracted text as a single string. For unsupported or
    unreadable formats, returns whatever ``read_text(errors='ignore')``
    produces (the previous default behaviour).
    """
    p = Path(path)
    ext = p.suffix.lower()

    try:
        if ext == ".pdf":
            return _extract_pdf(p)
        if ext == ".xlsx":
            return _extract_xlsx(p)
        if ext == ".docx":
            return _extract_docx(p)
        if ext == ".csv":
            return _extract_csv(p)
        if ext == ".ipynb":
            return _extract_notebook(p)
        if ext in (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tiff", ".tif"):
            return _extract_image(p)
    except PasswordProtectedError:
        raise  # let callers handle encrypted PDFs explicitly
    except Exception as exc:
        logger.debug("Text extraction failed for %s: %s", path, exc)
        return ""

    # Default: plain text
    return p.read_text(errors="ignore")


def extract_text_chunked(
    path: str, chunk_size: int = _DEFAULT_CHUNK_SIZE
) -> Generator[str, None, None]:
    """Yield text from a file in chunks for memory-efficient scanning.

    The chunking strategy varies by format:
      - Plain text: read ``chunk_size`` bytes, split on last newline.
      - PDF: yield one page at a time.
      - XLSX: yield one sheet at a time.
      - DOCX: yield batches of paragraphs.
      - CSV: yield batches of rows.
    """
    p = Path(path)
    ext = p.suffix.lower()

    try:
        if ext == ".pdf":
            yield from _chunked_pdf(p)
        elif ext == ".xlsx":
            yield from _chunked_xlsx(p)
        elif ext == ".docx":
            yield from _chunked_docx(p, chunk_size)
        elif ext == ".csv":
            yield from _chunked_csv(p, chunk_size)
        elif ext == ".ipynb":
            # Notebooks are typically small; yield as single chunk
            text = _extract_notebook(p)
            if text:
                yield text
        elif ext in (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tiff", ".tif"):
            text = _extract_image(p)
            if text:
                yield text
        else:
            yield from _chunked_text(p, chunk_size)
    except Exception as exc:
        logger.debug("Chunked extraction failed for %s: %s", path, exc)


def get_csv_header_findings(path: str, source: str = "") -> List[Dict]:
    """Check the first row of a CSV or XLSX for sensitive column headers.

    Returns findings in the same format as ``DLPScanner.scan_content()`` so
    they can be merged directly.
    """
    source = source or path
    p = Path(path)
    ext = p.suffix.lower()
    headers: List[str] = []

    try:
        if ext == ".csv":
            headers = _get_csv_headers(p)
        elif ext in (".xlsx", ".xls"):
            headers = _get_xlsx_headers(p)
    except Exception as exc:
        logger.debug("Header extraction failed for %s: %s", path, exc)
        return []

    findings: List[Dict] = []
    for col_name in headers:
        col_lower = col_name.strip().lower()
        if col_lower in SENSITIVE_CSV_HEADERS:
            findings.append(
                {
                    "type": "structural",
                    "pattern": f"sensitive_column_header:{col_lower}",
                    "source": source,
                    "line": 1,
                    "preview": col_name,
                }
            )
    return findings


# ---------------------------------------------------------------------------
# Jupyter Notebook extraction
# ---------------------------------------------------------------------------


def _extract_notebook(p: Path) -> str:
    """Extract scannable text from a Jupyter notebook (.ipynb).

    Parses the notebook JSON structure and extracts cell sources and
    text outputs, rather than scanning raw JSON.  This prevents false
    positives from JSON structural characters, base64-encoded images,
    and metadata while still catching real secrets that might appear
    in cell outputs (e.g. a key accidentally printed by code).

    Base64 image data and raw binary outputs are excluded since they
    cannot contain readable secrets but do contain digit sequences
    that trigger PII patterns.

    Falls back to raw text if the JSON is malformed.
    """
    import json as json_mod

    try:
        nb = json_mod.loads(p.read_text(errors="ignore"))
    except (json_mod.JSONDecodeError, UnicodeDecodeError):
        logger.debug("Notebook JSON parse failed for %s — falling back to raw text", p)
        return p.read_text(errors="ignore")

    cells = nb.get("cells", [])
    parts: List[str] = []

    for cell in cells:
        cell_type = cell.get("cell_type", "")
        if cell_type not in ("code", "markdown", "raw"):
            continue

        # --- Cell source (the user-authored code / markdown) ---
        source = cell.get("source", [])
        if isinstance(source, list):
            text = "".join(source)
        elif isinstance(source, str):
            text = source
        else:
            text = ""

        if text.strip():
            parts.append(text)

        # --- Cell outputs (only text streams and plain-text data) ---
        # Skip base64 image data, HTML renders, and binary outputs.
        for output in cell.get("outputs", []):
            output_type = output.get("output_type", "")

            if output_type == "stream":
                # stdout/stderr text
                stream_text = output.get("text", [])
                if isinstance(stream_text, list):
                    stream_text = "".join(stream_text)
                if stream_text and stream_text.strip():
                    parts.append(stream_text)

            elif output_type in ("execute_result", "display_data"):
                # Only extract text/plain — skip image/png, text/html, etc.
                data = output.get("data", {})
                plain = data.get("text/plain", "")
                if isinstance(plain, list):
                    plain = "".join(plain)
                if plain and plain.strip():
                    parts.append(plain)

            # error tracebacks are skipped — they're runtime noise

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Image extraction (OCR + QR + EXIF)
# ---------------------------------------------------------------------------


def _extract_image(p: Path) -> str:
    """Extract text from an image file via OCR, QR decoding, and EXIF.

    Pipeline:
      1. OCR — Tesseract extracts visible text (credentials on screenshots)
      2. QR/barcode — pyzbar decodes embedded QR codes (credential exfil)
      3. EXIF metadata — GPS coordinates, device info, comments

    Gracefully degrades if libraries are missing.
    """
    from endpoint_agent.config.settings import (
        IMAGE_MAX_PIXELS,
        IMAGE_OCR_ENABLED,
    )

    if not IMAGE_OCR_ENABLED:
        return ""

    parts: list[str] = []

    try:
        from PIL import Image
        from PIL.ExifTags import TAGS

        img = Image.open(p)

        # Safety: skip very large images to prevent OOM
        w, h = img.size
        if w * h > IMAGE_MAX_PIXELS:
            logger.debug("Image too large for OCR: %dx%d", w, h)
            return ""

        # ── 1. OCR via Tesseract ──────────────────────────────────────
        try:
            import pytesseract

            # Convert to RGB if needed (handles RGBA, palette, etc.)
            if img.mode not in ("RGB", "L"):
                img = img.convert("RGB")

            text = pytesseract.image_to_string(img)
            if text and text.strip():
                parts.append(text.strip())
        except ImportError:
            logger.debug("pytesseract not installed — skipping OCR")
        except Exception as exc:
            logger.debug("OCR failed for %s: %s", p, exc)

        # ── 2. QR / barcode decoding ──────────────────────────────────
        try:
            from pyzbar.pyzbar import decode as qr_decode

            codes = qr_decode(img)
            for code in codes:
                decoded = code.data.decode("utf-8", errors="ignore")
                if decoded:
                    parts.append(f"[QR:{code.type}] {decoded}")
        except ImportError:
            pass  # pyzbar optional
        except Exception as exc:
            logger.debug("QR decode failed for %s: %s", p, exc)

        # ── 3. EXIF metadata extraction ───────────────────────────────
        try:
            exif_data = img._getexif()
            if exif_data:
                exif_parts: list[str] = []
                _SENSITIVE_TAGS = {
                    "GPSInfo", "GPSLatitude", "GPSLongitude",
                    "ImageDescription", "UserComment", "XPComment",
                    "Artist", "Copyright", "Software",
                }
                for tag_id, value in exif_data.items():
                    tag_name = TAGS.get(tag_id, str(tag_id))
                    if tag_name in _SENSITIVE_TAGS:
                        exif_parts.append(f"[EXIF:{tag_name}] {value}")
                if exif_parts:
                    parts.append("\n".join(exif_parts))
        except (AttributeError, Exception):
            pass  # not all images have EXIF

    except ImportError:
        logger.debug("Pillow not installed — skipping image extraction")
        return ""
    except Exception as exc:
        logger.debug("Image extraction failed for %s: %s", p, exc)
        return ""

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# PDF extraction
# ---------------------------------------------------------------------------

_OCR_DPI = 200  # resolution for rasterizing scanned PDF pages


class PasswordProtectedError(Exception):
    """Raised when a PDF is encrypted and cannot be read."""

    def __init__(self, path: str):
        self.path = path
        super().__init__(f"PDF is password-protected: {path}")


def _ocr_page_fitz(page) -> str:
    """Rasterize a PyMuPDF page and run Tesseract OCR on it."""
    try:
        import pytesseract
        from PIL import Image
    except ImportError:
        logger.debug("pytesseract or Pillow not installed — skipping OCR")
        return ""

    try:
        pix = page.get_pixmap(dpi=_OCR_DPI)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        text = pytesseract.image_to_string(img)
        return text.strip()
    except Exception as exc:
        logger.debug("OCR failed for page: %s", exc)
        return ""


def _extract_pdf(p: Path) -> str:
    # Try PyMuPDF first (faster, better text extraction, OCR fallback)
    try:
        return _extract_pdf_fitz(p)
    except ImportError:
        pass

    # Fall back to pypdf (no OCR capability)
    from pypdf import PdfReader

    reader = PdfReader(str(p))
    if reader.is_encrypted:
        raise PasswordProtectedError(str(p))
    pages = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            pages.append(text)
    return "\n".join(pages)


def _extract_pdf_fitz(p: Path) -> str:
    """Extract text from PDF using PyMuPDF with OCR fallback for scanned pages."""
    import fitz

    doc = fitz.open(str(p))
    try:
        if doc.is_encrypted:
            raise PasswordProtectedError(str(p))

        pages = []
        for page in doc:
            text = page.get_text()
            if text and text.strip():
                pages.append(text)
            else:
                # Page has no embedded text — likely scanned/image-based
                ocr_text = _ocr_page_fitz(page)
                if ocr_text:
                    pages.append(ocr_text)
        return "\n".join(pages)
    finally:
        doc.close()


def _chunked_pdf(p: Path) -> Generator[str, None, None]:
    # Try PyMuPDF first
    try:
        yield from _chunked_pdf_fitz(p)
        return
    except ImportError:
        pass

    # Fall back to pypdf
    from pypdf import PdfReader

    reader = PdfReader(str(p))
    if reader.is_encrypted:
        raise PasswordProtectedError(str(p))
    for page in reader.pages:
        text = page.extract_text()
        if text:
            yield text


def _chunked_pdf_fitz(p: Path) -> Generator[str, None, None]:
    """Yield text per page using PyMuPDF with OCR fallback."""
    import fitz

    doc = fitz.open(str(p))
    try:
        if doc.is_encrypted:
            raise PasswordProtectedError(str(p))

        for page in doc:
            text = page.get_text()
            if text and text.strip():
                yield text
            else:
                ocr_text = _ocr_page_fitz(page)
                if ocr_text:
                    yield ocr_text
    finally:
        doc.close()


# ---------------------------------------------------------------------------
# XLSX extraction
# ---------------------------------------------------------------------------


def _extract_xlsx(p: Path) -> str:
    from openpyxl import load_workbook

    wb = load_workbook(str(p), read_only=True, data_only=True)
    parts: List[str] = []
    try:
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                cells = [str(c) if c is not None else "" for c in row]
                parts.append("\t".join(cells))
    finally:
        wb.close()
    return "\n".join(parts)


def _chunked_xlsx(p: Path) -> Generator[str, None, None]:
    from openpyxl import load_workbook

    wb = load_workbook(str(p), read_only=True, data_only=True)
    try:
        for ws in wb.worksheets:
            rows: List[str] = []
            for row in ws.iter_rows(values_only=True):
                cells = [str(c) if c is not None else "" for c in row]
                rows.append("\t".join(cells))
            if rows:
                yield "\n".join(rows)
    finally:
        wb.close()


def _get_xlsx_headers(p: Path) -> List[str]:
    from openpyxl import load_workbook

    wb = load_workbook(str(p), read_only=True, data_only=True)
    headers: List[str] = []
    try:
        ws = wb.worksheets[0]
        for row in ws.iter_rows(max_row=1, values_only=True):
            headers = [str(c) if c is not None else "" for c in row]
            break
    finally:
        wb.close()
    return headers


# ---------------------------------------------------------------------------
# DOCX extraction
# ---------------------------------------------------------------------------


def _extract_docx(p: Path) -> str:
    from docx import Document

    doc = Document(str(p))
    parts: List[str] = []
    for para in doc.paragraphs:
        if para.text:
            parts.append(para.text)
    for table in doc.tables:
        for row in table.rows:
            cells = [cell.text for cell in row.cells]
            parts.append("\t".join(cells))
    return "\n".join(parts)


def _chunked_docx(p: Path, chunk_size: int) -> Generator[str, None, None]:
    from docx import Document

    doc = Document(str(p))
    buf: List[str] = []
    buf_size = 0
    for para in doc.paragraphs:
        if para.text:
            buf.append(para.text)
            buf_size += len(para.text)
            if buf_size >= chunk_size:
                yield "\n".join(buf)
                buf.clear()
                buf_size = 0
    for table in doc.tables:
        for row in table.rows:
            cells = [cell.text for cell in row.cells]
            line = "\t".join(cells)
            buf.append(line)
            buf_size += len(line)
            if buf_size >= chunk_size:
                yield "\n".join(buf)
                buf.clear()
                buf_size = 0
    if buf:
        yield "\n".join(buf)


# ---------------------------------------------------------------------------
# CSV extraction
# ---------------------------------------------------------------------------


def _extract_csv(p: Path) -> str:
    text = p.read_text(errors="ignore")
    # CSV is already text — return as-is for regex scanning
    return text


def _chunked_csv(p: Path, chunk_size: int) -> Generator[str, None, None]:
    buf: List[str] = []
    buf_size = 0
    with open(str(p), "r", errors="ignore") as f:
        for line in f:
            buf.append(line)
            buf_size += len(line)
            if buf_size >= chunk_size:
                yield "".join(buf)
                buf.clear()
                buf_size = 0
    if buf:
        yield "".join(buf)


def _get_csv_headers(p: Path) -> List[str]:
    with open(str(p), "r", errors="ignore") as f:
        reader = csv.reader(f)
        for row in reader:
            return row
    return []


# ---------------------------------------------------------------------------
# Plain text chunked reading
# ---------------------------------------------------------------------------


def _chunked_text(p: Path, chunk_size: int) -> Generator[str, None, None]:
    leftover = ""
    with open(str(p), "r", errors="ignore") as f:
        while True:
            raw = f.read(chunk_size)
            if not raw:
                break
            chunk = leftover + raw
            last_nl = chunk.rfind("\n")
            if last_nl != -1:
                yield chunk[: last_nl + 1]
                leftover = chunk[last_nl + 1 :]
            else:
                leftover = chunk
    if leftover:
        yield leftover
