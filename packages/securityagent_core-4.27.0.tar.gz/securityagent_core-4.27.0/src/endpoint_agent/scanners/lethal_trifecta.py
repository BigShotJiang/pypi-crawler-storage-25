"""
Lethal Trifecta detector (Simon Willison, June 2025).

Flags sessions where all three conditions are simultaneously true:
  1. Access to private data (credential files, PII, env vars)
  2. Exposure to untrusted content (external URLs, user prompts, tool results)
  3. Ability to externally communicate (network tools, file upload, API calls)

When all three conditions are met, the session is in the "lethal trifecta"
state and additional restrictions should apply.
"""

import json
import logging
import os
import time
from pathlib import Path
from typing import Dict, List

from endpoint_agent.config.settings import LETHAL_TRIFECTA_ENABLED

logger = logging.getLogger(__name__)

_DEFAULT_STATE_DIR = Path(os.environ.get("EA_STATE_DIR", "/tmp/agnosticsecurity"))
_TRIFECTA_PERSISTENCE_PATH = _DEFAULT_STATE_DIR / "trifecta_state.json"


class LethalTrifectaTracker:
    """Tracks the three conditions of the Lethal Trifecta."""

    def __init__(self) -> None:
        self._has_private_data: bool = False
        self._has_untrusted_input: bool = False
        self._has_external_comm: bool = False
        self._private_data_sources: List[str] = []
        self._untrusted_input_sources: List[str] = []
        self._external_comm_tools: List[str] = []
        self._enabled = LETHAL_TRIFECTA_ENABLED
        self._load()

    # ------------------------------------------------------------------
    # Recording conditions
    # ------------------------------------------------------------------

    def record_private_data_access(self, source: str) -> None:
        """Mark condition 1: agent accessed private/sensitive data."""
        if not self._enabled:
            return
        self._has_private_data = True
        if source not in self._private_data_sources:
            self._private_data_sources.append(source)
        logger.debug("Trifecta: private data accessed via %s", source)
        self._persist()

    def record_untrusted_input(self, source: str) -> None:
        """Mark condition 2: agent processed untrusted external content."""
        if not self._enabled:
            return
        self._has_untrusted_input = True
        if source not in self._untrusted_input_sources:
            self._untrusted_input_sources.append(source)
        logger.debug("Trifecta: untrusted input from %s", source)
        self._persist()

    def record_external_comm_capability(self, tool: str) -> None:
        """Mark condition 3: agent has network egress / external comm."""
        if not self._enabled:
            return
        self._has_external_comm = True
        if tool not in self._external_comm_tools:
            self._external_comm_tools.append(tool)
        logger.debug("Trifecta: external comm capability via %s", tool)
        self._persist()

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def is_trifecta_active(self) -> bool:
        """Return True when all three conditions are simultaneously met."""
        if not self._enabled:
            return False
        return (
            self._has_private_data
            and self._has_untrusted_input
            and self._has_external_comm
        )

    def get_status(self) -> Dict:
        """Return current state of all three conditions."""
        return {
            "enabled": self._enabled,
            "trifecta_active": self.is_trifecta_active(),
            "has_private_data": self._has_private_data,
            "has_untrusted_input": self._has_untrusted_input,
            "has_external_comm": self._has_external_comm,
            "private_data_sources": list(self._private_data_sources),
            "untrusted_input_sources": list(self._untrusted_input_sources),
            "external_comm_tools": list(self._external_comm_tools),
        }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _persist(self) -> None:
        """Best-effort write of trifecta state to disk."""
        try:
            _TRIFECTA_PERSISTENCE_PATH.parent.mkdir(parents=True, exist_ok=True)
            state = {
                "has_private_data": self._has_private_data,
                "has_untrusted_input": self._has_untrusted_input,
                "has_external_comm": self._has_external_comm,
                "private_data_sources": self._private_data_sources,
                "untrusted_input_sources": self._untrusted_input_sources,
                "external_comm_tools": self._external_comm_tools,
                "timestamp": time.time(),
            }
            _TRIFECTA_PERSISTENCE_PATH.write_text(
                json.dumps(state, indent=2), encoding="utf-8"
            )
        except Exception:
            logger.debug("Trifecta persistence write failed", exc_info=True)
        # Sync to knowledge graph
        try:
            from endpoint_agent.scanners.knowledge_graph import (
                KNOWLEDGE_GRAPH_ENABLED,
                get_knowledge_graph,
            )
            if KNOWLEDGE_GRAPH_ENABLED:
                graph = get_knowledge_graph()
                session_id = graph.add_node(
                    "SESSION", "trifecta_session",
                    metadata={
                        "private_data": self._has_private_data,
                        "untrusted_input": self._has_untrusted_input,
                        "external_comm": self._has_external_comm,
                    },
                    node_id="trifecta_current",
                )
                if self._has_private_data and self._has_untrusted_input and self._has_external_comm:
                    graph.log_event("lethal_trifecta_active", "CRITICAL", {
                        "private_data_sources": self._private_data_sources,
                        "untrusted_input_sources": self._untrusted_input_sources,
                        "external_comm_tools": self._external_comm_tools,
                    })
        except Exception:
            logger.debug("Trifecta graph sync failed", exc_info=True)

    def _load(self) -> None:
        """Load persisted trifecta state from disk."""
        if not self._enabled:
            return
        try:
            if not _TRIFECTA_PERSISTENCE_PATH.exists():
                return
            state = json.loads(
                _TRIFECTA_PERSISTENCE_PATH.read_text(encoding="utf-8")
            )
            # Expire state older than 24 hours
            if time.time() - state.get("timestamp", 0) > 86400:
                return
            self._has_private_data = state.get("has_private_data", False)
            self._has_untrusted_input = state.get("has_untrusted_input", False)
            self._has_external_comm = state.get("has_external_comm", False)
            self._private_data_sources = state.get("private_data_sources", [])
            self._untrusted_input_sources = state.get("untrusted_input_sources", [])
            self._external_comm_tools = state.get("external_comm_tools", [])
        except Exception:
            logger.debug("Trifecta persistence load failed", exc_info=True)


# Module-level singleton
_trifecta_tracker: LethalTrifectaTracker | None = None


def get_trifecta_tracker() -> LethalTrifectaTracker:
    """Get the cached singleton LethalTrifectaTracker."""
    global _trifecta_tracker
    if _trifecta_tracker is None:
        _trifecta_tracker = LethalTrifectaTracker()
    return _trifecta_tracker
