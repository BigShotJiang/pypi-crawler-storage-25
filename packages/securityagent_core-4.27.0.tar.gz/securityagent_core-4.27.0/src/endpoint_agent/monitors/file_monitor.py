"""
File system monitoring using watchdog.

Watches directories for creation of malicious agent files/directories
and unauthorized access to sensitive files like .env and SSH keys.
"""

import logging
from pathlib import Path
from typing import Callable, List

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from endpoint_agent.config.settings import (
    ALLOWLISTED_PATHS,
    KNOWN_THREAT_DIRECTORY_NAMES,
    KNOWN_THREAT_FILE_PATTERNS,
    SENSITIVE_FILE_EXTENSIONS,
    SENSITIVE_FILE_PATTERNS,
    SEVERITY_CRITICAL,
    SEVERITY_INFO,
    SEVERITY_WARNING,
    SKIP_DIRECTORIES,
)

logger = logging.getLogger(__name__)


class ThreatFileHandler(FileSystemEventHandler):
    """Handles file system events and checks against threat patterns."""

    def __init__(self, alert_callback: Callable):
        self.alert_callback = alert_callback

    def on_created(self, event):
        path = Path(event.src_path)
        if self._should_skip(path):
            return
        self._check_threat_installation(path, event.is_directory)
        if not event.is_directory:
            self._check_sensitive_file(path, event_type="created")

    def on_modified(self, event):
        if event.is_directory:
            return
        path = Path(event.src_path)
        if self._should_skip(path):
            return
        self._check_sensitive_file(path, event_type="modified")

    def on_moved(self, event):
        dest = Path(event.dest_path)
        if self._should_skip(dest):
            return
        self._check_threat_installation(dest, event.is_directory)

    def _should_skip(self, path: Path) -> bool:
        """Skip events inside directories we don't care about."""
        parts = set(path.parts)
        return bool(parts & SKIP_DIRECTORIES)

    def _check_threat_installation(self, path: Path, is_directory: bool):
        """Check if a newly created file/directory matches malicious agent patterns."""
        name_lower = path.name.lower()
        path_str = str(path)
        patterns = (
            KNOWN_THREAT_DIRECTORY_NAMES if is_directory else KNOWN_THREAT_FILE_PATTERNS
        )

        for pattern in patterns:
            if pattern in name_lower:
                # Check path allowlist before firing CRITICAL
                if any(path_str.startswith(ap) for ap in ALLOWLISTED_PATHS):
                    self.alert_callback(
                        severity=SEVERITY_INFO,
                        event_type="allowlisted_path_detected",
                        details={
                            "path": path_str,
                            "matched_pattern": pattern,
                            "is_directory": is_directory,
                        },
                    )
                    return

                self.alert_callback(
                    severity=SEVERITY_CRITICAL,
                    event_type="threat_installation_detected",
                    details={
                        "path": path_str,
                        "matched_pattern": pattern,
                        "is_directory": is_directory,
                    },
                )
                return

    def _check_sensitive_file(self, path: Path, event_type: str):
        """Check if a sensitive file was created or modified."""
        name = path.name
        suffix = path.suffix

        for pattern in SENSITIVE_FILE_PATTERNS:
            if name == pattern or str(path).endswith(pattern):
                self.alert_callback(
                    severity=SEVERITY_WARNING,
                    event_type=f"sensitive_file_{event_type}",
                    details={"path": str(path), "matched_pattern": pattern},
                )
                return

        if suffix in SENSITIVE_FILE_EXTENSIONS:
            self.alert_callback(
                severity=SEVERITY_WARNING,
                event_type=f"sensitive_file_{event_type}",
                details={"path": str(path), "matched_extension": suffix},
            )


class FileMonitor:
    """Manages watchdog observers for monitored directories."""

    def __init__(
        self, watch_dirs: List[str], alert_callback: Callable, recursive: bool = True
    ):
        self.watch_dirs = watch_dirs
        self.alert_callback = alert_callback
        self.recursive = recursive
        self.observer = Observer()
        self.handler = ThreatFileHandler(alert_callback)

    def start(self):
        """Start watching all configured directories."""
        for directory in self.watch_dirs:
            if Path(directory).is_dir():
                self.observer.schedule(
                    self.handler, directory, recursive=self.recursive
                )
                logger.info("Watching directory: %s", directory)
            else:
                logger.warning("Skipping non-existent directory: %s", directory)
        self.observer.start()

    def stop(self):
        """Stop all watchers and wait for cleanup."""
        self.observer.stop()
        self.observer.join()
