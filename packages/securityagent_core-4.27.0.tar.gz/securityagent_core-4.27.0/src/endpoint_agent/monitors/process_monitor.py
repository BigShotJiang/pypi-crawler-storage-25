"""
Process detection monitor.

Uses psutil to scan running processes for known malicious agent signatures.
Detects new process spawns and checks if suspicious processes have open
handles to sensitive files.
"""

import logging
import os
import time
from typing import Callable, Dict, List, Optional, Set

import psutil

from endpoint_agent.config.settings import (
    ALLOWLISTED_PROCESS_PATTERNS,
    ENV_ENUMERATION_COMMANDS,
    ENV_SECRET_EXCLUDED_NAMES,
    ENV_SECRET_MIN_LENGTH,
    ENV_SECRET_NAME_PATTERNS,
    KNOWN_THREAT_PROCESS_NAMES,
    PARENT_KILL_ENABLED,
    PARENT_KILL_RESPAWN_THRESHOLD,
    PARENT_KILL_WINDOW_SECONDS,
    PROCESS_AUTO_KILL_ENABLED,
    PROCESS_AUTO_KILL_TIMEOUT,
    PROCESS_SCAN_INTERVAL_SECONDS,
    PROTECTED_PROCESSES,
    SENSITIVE_FILE_PATTERNS,
    SEVERITY_CRITICAL,
    SEVERITY_INFO,
    SEVERITY_WARNING,
    TRUSTED_ENV_PROCESSES,
)

logger = logging.getLogger(__name__)


class ProcessMonitor:
    """Monitors running processes for malicious agent signatures."""

    def __init__(self, alert_callback: Callable):
        self.alert_callback = alert_callback
        self._known_pids: Set[int] = set()
        self._running = False
        self._kill_history: Dict[str, List[float]] = {}
        self._env_alerted_pids: Set[int] = set()

    def scan_once(self) -> List[Dict]:
        """Perform a single scan of all running processes. Returns list of threats."""
        threats = []
        current_pids = set()

        for proc in psutil.process_iter(["pid", "name", "cmdline", "username"]):
            try:
                info = proc.info
                current_pids.add(info["pid"])
                threat = self._check_process(proc, info)
                if threat:
                    threats.append(threat)
                # Environment secret check (runs on ALL processes, not just threats)
                env_result = self._check_environment_secrets(proc, info)
                if env_result:
                    self.alert_callback(
                        severity=(
                            SEVERITY_WARNING
                            if env_result["env_var_count"] < 3
                            else SEVERITY_CRITICAL
                        ),
                        event_type="env_secret_access_detected",
                        details=env_result,
                    )
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        # Detect new processes since last scan
        if self._known_pids:
            new_pids = current_pids - self._known_pids
            for pid in new_pids:
                try:
                    proc = psutil.Process(pid)
                    info = proc.as_dict(attrs=["pid", "name", "cmdline", "username"])
                    threat = self._check_process(proc, info)
                    if threat:
                        threat["is_new_spawn"] = True
                        threats.append(threat)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

        self._known_pids = current_pids
        return threats

    def _check_process(self, proc, info) -> Optional[Dict]:
        """Check a single process against threat patterns."""
        name = (info.get("name") or "").lower()
        cmdline = " ".join(info.get("cmdline") or []).lower()

        for pattern in KNOWN_THREAT_PROCESS_NAMES:
            if pattern in name or pattern in cmdline:
                # Check allowlist before alerting or killing
                if any(
                    ap in name or ap in cmdline for ap in ALLOWLISTED_PROCESS_PATTERNS
                ):
                    self.alert_callback(
                        severity=SEVERITY_INFO,
                        event_type="allowlisted_process_detected",
                        details={
                            "pid": info["pid"],
                            "name": info.get("name"),
                            "cmdline": info.get("cmdline"),
                            "matched_pattern": pattern,
                        },
                    )
                    return None

                sensitive_files_accessed = self._check_open_files(proc)
                threat = {
                    "pid": info["pid"],
                    "name": info.get("name"),
                    "cmdline": info.get("cmdline"),
                    "username": info.get("username"),
                    "matched_pattern": pattern,
                    "sensitive_files_open": sensitive_files_accessed,
                }
                self.alert_callback(
                    severity=SEVERITY_CRITICAL,
                    event_type="malicious_process_detected",
                    details=threat,
                )
                if PROCESS_AUTO_KILL_ENABLED:
                    self._kill_process(proc, threat)
                return threat
        return None

    def _kill_process(self, proc, threat: Dict):
        """Terminate a malicious process. SIGTERM first, escalate to SIGKILL."""
        pid = threat["pid"]
        name = threat.get("name", "unknown")
        try:
            proc.terminate()
            try:
                proc.wait(timeout=PROCESS_AUTO_KILL_TIMEOUT)
            except psutil.TimeoutExpired:
                logger.warning(
                    "PID %d (%s) did not exit after SIGTERM, sending SIGKILL", pid, name
                )
                proc.kill()
                proc.wait(timeout=3)
            self.alert_callback(
                severity=SEVERITY_INFO,
                event_type="process_killed",
                details={
                    "pid": pid,
                    "name": name,
                    "matched_pattern": threat["matched_pattern"],
                },
            )
            if PARENT_KILL_ENABLED:
                should_kill_parent = self._track_kill(threat["matched_pattern"])
                if should_kill_parent:
                    self._kill_parent(proc, threat)
        except psutil.NoSuchProcess:
            logger.info("PID %d (%s) already exited before kill", pid, name)
        except psutil.AccessDenied:
            self.alert_callback(
                severity=SEVERITY_WARNING,
                event_type="process_kill_failed",
                details={
                    "pid": pid,
                    "name": name,
                    "reason": "access_denied",
                    "matched_pattern": threat["matched_pattern"],
                },
            )
        except psutil.ZombieProcess:
            logger.info("PID %d (%s) is a zombie process, skipping kill", pid, name)

    def _track_kill(self, pattern: str) -> bool:
        """Record a kill event. Returns True if respawn threshold is exceeded."""
        now = time.time()
        if pattern not in self._kill_history:
            self._kill_history[pattern] = []
        self._kill_history[pattern].append(now)
        cutoff = now - PARENT_KILL_WINDOW_SECONDS
        self._kill_history[pattern] = [
            t for t in self._kill_history[pattern] if t > cutoff
        ]
        return len(self._kill_history[pattern]) >= PARENT_KILL_RESPAWN_THRESHOLD

    def _kill_parent(self, child_proc, threat: Dict):
        """Kill the parent process that keeps respawning a malicious child."""
        try:
            ppid = child_proc.ppid()
            parent = psutil.Process(ppid)
            parent_name = parent.name().lower()

            if parent_name in PROTECTED_PROCESSES:
                self.alert_callback(
                    severity=SEVERITY_WARNING,
                    event_type="parent_kill_skipped",
                    details={
                        "parent_pid": ppid,
                        "parent_name": parent_name,
                        "child_pid": threat["pid"],
                        "reason": "protected_process",
                        "matched_pattern": threat["matched_pattern"],
                    },
                )
                return

            parent.terminate()
            try:
                parent.wait(timeout=PROCESS_AUTO_KILL_TIMEOUT)
            except psutil.TimeoutExpired:
                logger.warning(
                    "Parent PID %d (%s) did not exit after SIGTERM, sending SIGKILL",
                    ppid,
                    parent_name,
                )
                parent.kill()
                parent.wait(timeout=3)

            self.alert_callback(
                severity=SEVERITY_CRITICAL,
                event_type="parent_process_killed",
                details={
                    "parent_pid": ppid,
                    "parent_name": parent_name,
                    "child_pid": threat["pid"],
                    "matched_pattern": threat["matched_pattern"],
                    "respawn_count": len(
                        self._kill_history.get(threat["matched_pattern"], [])
                    ),
                },
            )
        except psutil.NoSuchProcess:
            logger.info("Parent process already exited")
        except psutil.AccessDenied:
            self.alert_callback(
                severity=SEVERITY_WARNING,
                event_type="parent_kill_failed",
                details={
                    "parent_pid": ppid,
                    "parent_name": parent_name,
                    "reason": "access_denied",
                    "matched_pattern": threat["matched_pattern"],
                },
            )
        except psutil.ZombieProcess:
            logger.info("Parent is a zombie process, skipping")

    def _check_open_files(self, proc) -> List[str]:
        """Check if a process has open handles to sensitive files."""
        sensitive = []
        try:
            for f in proc.open_files():
                path_lower = f.path.lower()
                for pattern in SENSITIVE_FILE_PATTERNS:
                    if pattern in path_lower:
                        sensitive.append(f.path)
                        break
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            pass
        return sensitive

    def _check_environment_secrets(self, proc, info) -> Optional[Dict]:
        """Check if an untrusted process has loaded env vars containing secrets."""
        pid = info.get("pid")
        name = (info.get("name") or "").lower()

        # Skip self, trusted processes (substring match), and already-alerted PIDs
        if pid == os.getpid():
            return None
        if any(trusted in name for trusted in TRUSTED_ENV_PROCESSES):
            return None
        if pid in self._env_alerted_pids:
            return None

        # Check for env enumeration commands in cmdline
        cmdline = " ".join(info.get("cmdline") or []).lower()
        is_env_enumeration = any(pat in cmdline for pat in ENV_ENUMERATION_COMMANDS)

        try:
            env_vars = proc.environ()
        except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
            return None

        suspicious_vars = []
        for key, value in env_vars.items():
            if len(value) < ENV_SECRET_MIN_LENGTH:
                continue
            key_lower = key.lower()
            if key_lower in ENV_SECRET_EXCLUDED_NAMES:
                continue
            for pattern in ENV_SECRET_NAME_PATTERNS:
                if pattern in key_lower:
                    preview = value[:4] + "***" if len(value) > 4 else "***"
                    suspicious_vars.append(
                        {
                            "name": key,
                            "value_length": len(value),
                            "value_preview": preview,
                        }
                    )
                    break

        if not suspicious_vars and not is_env_enumeration:
            return None

        self._env_alerted_pids.add(pid)
        return {
            "pid": pid,
            "name": info.get("name"),
            "suspicious_env_vars": suspicious_vars,
            "is_env_enumeration": is_env_enumeration,
            "env_var_count": len(suspicious_vars),
        }

    def start_continuous(self):
        """Run continuous monitoring in a loop."""
        self._running = True
        logger.info(
            "Process monitor started (interval: %ds)", PROCESS_SCAN_INTERVAL_SECONDS
        )
        while self._running:
            threats = self.scan_once()
            if threats:
                logger.warning("Found %d threat(s) in process scan", len(threats))
            time.sleep(PROCESS_SCAN_INTERVAL_SECONDS)

    def stop(self):
        """Signal the continuous monitoring loop to stop."""
        self._running = False
