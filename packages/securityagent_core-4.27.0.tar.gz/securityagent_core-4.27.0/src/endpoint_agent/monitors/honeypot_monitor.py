"""
Honeypot-based intrusion detection monitor.

Creates decoy files that mimic sensitive credentials. Any process accessing
these files is immediately flagged as malicious -- this is immune to
low-and-slow evasion since ANY access is suspicious.
"""

import logging
import os
import time
from pathlib import Path
from typing import Callable, Dict, List, Set

import psutil

from endpoint_agent.config.settings import (
    HONEYPOT_PATHS,
    HONEYPOT_SCAN_INTERVAL_SECONDS,
    SEVERITY_CRITICAL,
)

logger = logging.getLogger(__name__)

# Fake but realistic-looking content for different file types
_HONEYPOT_CONTENT = {
    ".env": (
        "# Production environment\n"
        "DATABASE_URL=postgres://admin:s3cretP@ss!@db.internal:5432/prod\n"
        "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE\n"
        "AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\n"
        "STRIPE_SECRET_KEY=sk_live_4eC39HqLyjWDarjtT1zdp7dc\n"
    ),
    "credentials": (
        "[default]\n"
        "aws_access_key_id = AKIAIOSFODNN7EXAMPLE\n"
        "aws_secret_access_key = wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\n"
        "region = us-east-1\n"
    ),
    "id_rsa": (
        "-----BEGIN RSA PRIVATE KEY-----\n"
        "HONEYPOT_FAKE_KEY_DO_NOT_USE\n"
        "MIIEowIBAAKCAQEAqFakeKeyDataHere0000000000000000000000\n"
        "-----END RSA PRIVATE KEY-----\n"
    ),
}


class HoneypotMonitor:
    """Creates and monitors decoy files to detect unauthorized access."""

    def __init__(self, alert_callback: Callable):
        self.alert_callback = alert_callback
        self._running = False
        self._honeypot_paths: Set[str] = set()
        self._alerted_pids: Set[int] = set()

    def setup(self) -> List[str]:
        """Create honeypot files. Returns list of paths created."""
        created = []
        for path_template in HONEYPOT_PATHS:
            expanded = os.path.expanduser(path_template)
            try:
                path = Path(expanded)
                path.parent.mkdir(parents=True, exist_ok=True)

                # Pick content based on filename
                filename = path.name
                content = _HONEYPOT_CONTENT.get(filename, _HONEYPOT_CONTENT[".env"])
                path.write_text(content)
                os.chmod(str(path), 0o600)

                self._honeypot_paths.add(str(path.resolve()))
                created.append(str(path))
                logger.info("Honeypot deployed: %s", path)
            except OSError:
                logger.warning("Failed to create honeypot: %s", expanded)

        return created

    def cleanup(self):
        """Remove all honeypot files."""
        for path_str in self._honeypot_paths:
            try:
                Path(path_str).unlink(missing_ok=True)
                logger.info("Honeypot removed: %s", path_str)
            except OSError:
                pass
        self._honeypot_paths.clear()

    def check_access(self) -> List[Dict]:
        """Scan all processes for open handles to honeypot files."""
        if not self._honeypot_paths:
            return []

        detections = []
        for proc in psutil.process_iter(["pid", "name", "cmdline", "username"]):
            try:
                info = proc.info
                pid = info["pid"]

                if pid == os.getpid() or pid in (0, 1):
                    continue
                if pid in self._alerted_pids:
                    continue

                open_files = proc.open_files()
                for f in open_files:
                    resolved = str(Path(f.path).resolve())
                    if resolved in self._honeypot_paths:
                        detection = {
                            "pid": pid,
                            "name": info.get("name", ""),
                            "cmdline": info.get("cmdline", []),
                            "username": info.get("username", ""),
                            "honeypot_file": resolved,
                            "original_path": f.path,
                        }
                        detections.append(detection)
                        self._alerted_pids.add(pid)

                        self.alert_callback(
                            severity=SEVERITY_CRITICAL,
                            event_type="honeypot_access_detected",
                            details=detection,
                        )
                        break

            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        return detections

    def start_continuous(self):
        """Run continuous honeypot monitoring in a loop."""
        self._running = True
        self.setup()
        logger.info(
            "Honeypot monitor started (interval: %ds, traps: %d)",
            HONEYPOT_SCAN_INTERVAL_SECONDS,
            len(self._honeypot_paths),
        )
        try:
            while self._running:
                try:
                    self.check_access()
                except Exception:
                    logger.exception("Error in honeypot check")
                time.sleep(HONEYPOT_SCAN_INTERVAL_SECONDS)
        finally:
            self.cleanup()

    def stop(self):
        """Signal the continuous monitoring loop to stop."""
        self._running = False
