"""
Behavioral detection monitor.

Detects anomalous process behavior regardless of process name by tracking
per-process metrics over time and scoring against behavioral signals:
- Rapid file access (bulk scanning / exfiltration)
- Sensitive file access patterns (.env, .aws/credentials, SSH keys)
- Network burst activity (outbound connection spikes)
- CPU anomalies (unusual resource usage)
- Suspicious process lineage (scripting runtimes with unexpected parents)

Works alongside the existing pattern-matching ProcessMonitor.
"""

import logging
import os
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Set, Tuple

import psutil

from endpoint_agent.config.settings import (
    BEHAVIORAL_ALERT_THRESHOLD_CRITICAL,
    BEHAVIORAL_ALERT_THRESHOLD_WARNING,
    BEHAVIORAL_CPU_SPIKE_RATIO,
    BEHAVIORAL_CPU_SPIKE_THRESHOLD,
    BEHAVIORAL_CUMULATIVE_FILE_THRESHOLD,
    BEHAVIORAL_CUMULATIVE_NET_THRESHOLD,
    BEHAVIORAL_EMA_ALPHA,
    BEHAVIORAL_FILE_ACCESS_ABSOLUTE_THRESHOLD,
    BEHAVIORAL_FILE_ACCESS_SPIKE_RATIO,
    BEHAVIORAL_HISTORY_MAX_SNAPSHOTS,
    BEHAVIORAL_MIN_SNAPSHOTS_FOR_SCORING,
    BEHAVIORAL_NET_CONNECTIONS_ABSOLUTE_THRESHOLD,
    BEHAVIORAL_NET_SPIKE_RATIO,
    BEHAVIORAL_SCAN_INTERVAL_SECONDS,
    BEHAVIORAL_WEIGHT_CPU,
    BEHAVIORAL_WEIGHT_CUMULATIVE_FILE,
    BEHAVIORAL_WEIGHT_CUMULATIVE_NETWORK,
    BEHAVIORAL_WEIGHT_DOCUMENT_ACCESS,
    BEHAVIORAL_WEIGHT_FILE_ACCESS,
    BEHAVIORAL_WEIGHT_LINEAGE,
    BEHAVIORAL_WEIGHT_NETWORK,
    BEHAVIORAL_WEIGHT_SENSITIVE_FILE,
    CROSS_PROCESS_AGGREGATE_SCORE_THRESHOLD,
    CROSS_PROCESS_PID_THRESHOLD,
    CROSS_PROCESS_SENSITIVE_FILE_THRESHOLD,
    CROSS_PROCESS_WINDOW_SECONDS,
    DOCUMENT_BULK_ACCESS_THRESHOLD,
    EXPECTED_PARENT_PROCESSES,
    LINEAGE_MAX_DEPTH,
    PROTECTED_DOCUMENT_EXTENSIONS,
    PROTECTED_DOCUMENT_PATHS,
    SCRIPTING_RUNTIMES,
    SENSITIVE_DOCUMENT_NAME_PATTERNS,
    SENSITIVE_FILE_PATTERNS,
    SEVERITY_CRITICAL,
    SEVERITY_WARNING,
    TRUSTED_DOCUMENT_READERS,
)

logger = logging.getLogger(__name__)


@dataclass
class ProcessSnapshot:
    """Single point-in-time measurement of a process."""

    timestamp: float
    pid: int
    name: str
    cmdline: List[str]
    username: str
    ppid: int
    cpu_percent: float
    memory_rss: int
    num_connections: int  # -1 = access denied
    num_open_files: int  # -1 = access denied
    open_file_paths: List[str]
    num_fds: int
    num_ctx_switches: int


@dataclass
class ProcessHistory:
    """Rolling time-window history for a single PID."""

    pid: int
    name: str
    first_seen: float
    snapshots: deque
    baseline_cpu: float = 0.0
    baseline_connections: float = 0.0
    baseline_open_files: float = 0.0
    alerted_score: float = 0.0
    sensitive_files_seen: Set[str] = field(default_factory=set)
    protected_documents_accessed: Set[str] = field(default_factory=set)
    # Anti-spoofing: cumulative counters
    total_unique_files_accessed: Set[str] = field(default_factory=set)
    total_connections_seen: int = 0


@dataclass
class UserActivity:
    """Aggregated activity tracking across all processes for a single user."""

    username: str
    sensitive_files_accessed: Set[str] = field(default_factory=set)
    total_pids_spawned: int = 0
    pids_seen: Set[int] = field(default_factory=set)
    aggregate_score: float = 0.0
    last_updated: float = field(default_factory=time.time)
    alerted: bool = False


class BehavioralMonitor:
    """Detects anomalous process behavior using time-series analysis."""

    def __init__(self, alert_callback: Callable):
        self.alert_callback = alert_callback
        self._running = False
        self._process_histories: Dict[int, ProcessHistory] = {}
        self._user_activity: Dict[str, UserActivity] = {}
        self._first_scan_done = False

    def start_continuous(self):
        """Run continuous behavioral monitoring in a loop."""
        self._running = True
        logger.info(
            "Behavioral monitor started (interval: %ds)",
            BEHAVIORAL_SCAN_INTERVAL_SECONDS,
        )
        while self._running:
            try:
                self._scan_cycle()
            except Exception:
                logger.exception("Error in behavioral scan cycle")
            time.sleep(BEHAVIORAL_SCAN_INTERVAL_SECONDS)

    def stop(self):
        """Signal the continuous monitoring loop to stop."""
        self._running = False

    def scan_once(self) -> List[Dict]:
        """Perform a single behavioral scan. Returns list of anomalies found."""
        self._scan_cycle()
        anomalies = []
        for history in self._process_histories.values():
            if len(history.snapshots) < BEHAVIORAL_MIN_SNAPSHOTS_FOR_SCORING:
                continue
            score, signals = self._score_process(history)
            if score >= BEHAVIORAL_ALERT_THRESHOLD_WARNING:
                anomalies.append(
                    {
                        "pid": history.pid,
                        "name": history.name,
                        "score": round(score, 3),
                        "signals": signals,
                    }
                )
        return anomalies

    # ------------------------------------------------------------------
    # Core scan cycle
    # ------------------------------------------------------------------

    def _scan_cycle(self):
        """Collect snapshots, prune dead PIDs, score processes, emit alerts.

        The cycle is split into three passes to ensure scoring uses the
        *previous* baselines (before the current snapshot shifts the EMA):
        1. Append snapshots and track sensitive files (no baseline update).
        2. Score all processes against the pre-update baselines.
        3. Update baselines with the new snapshot data.
        """
        current_pids: Set[int] = set()
        new_snapshots: Dict[int, ProcessSnapshot] = {}

        for proc in psutil.process_iter(["pid", "name", "cmdline", "username"]):
            try:
                snapshot = self._collect_snapshot(proc)
                if snapshot is None:
                    continue
                current_pids.add(snapshot.pid)
                self._append_snapshot(snapshot)
                new_snapshots[snapshot.pid] = snapshot
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        # Prune histories for dead processes
        dead_pids = set(self._process_histories.keys()) - current_pids
        for pid in dead_pids:
            self._roll_into_user_activity(self._process_histories[pid])
            del self._process_histories[pid]

        # Skip scoring on first scan (cpu_percent needs a prior call for delta)
        if not self._first_scan_done:
            self._first_scan_done = True
            # Still update baselines on first scan to seed the EMA
            for pid, snapshot in new_snapshots.items():
                if pid in self._process_histories:
                    self._update_baselines(self._process_histories[pid], snapshot)
            return

        # Score all tracked processes using pre-update baselines
        for history in self._process_histories.values():
            if len(history.snapshots) < BEHAVIORAL_MIN_SNAPSHOTS_FOR_SCORING:
                continue
            score, signals = self._score_process(history)
            if (
                score >= BEHAVIORAL_ALERT_THRESHOLD_CRITICAL
                and score > history.alerted_score
            ):
                self._emit_alert(history, score, signals, SEVERITY_CRITICAL)
                history.alerted_score = score
            elif (
                score >= BEHAVIORAL_ALERT_THRESHOLD_WARNING
                and score > history.alerted_score
            ):
                self._emit_alert(history, score, signals, SEVERITY_WARNING)
                history.alerted_score = score

        # Now update baselines with the new snapshot data
        for pid, snapshot in new_snapshots.items():
            if pid in self._process_histories:
                self._update_baselines(self._process_histories[pid], snapshot)

        # Check for cross-process user-level anomalies
        self._check_user_level_anomaly()

    # ------------------------------------------------------------------
    # Snapshot collection
    # ------------------------------------------------------------------

    def _collect_snapshot(self, proc) -> Optional[ProcessSnapshot]:
        """Gather a rich set of metrics from a single process."""
        try:
            info = proc.info
            pid = info["pid"]

            # Skip our own process and kernel PIDs
            if pid == os.getpid() or pid in (0, 1):
                return None

            cpu = proc.cpu_percent(interval=None)
            mem = proc.memory_info()
            ppid = proc.ppid()

            # Network connections
            try:
                conns = proc.net_connections()
                num_conns = len(conns)
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                num_conns = -1

            # Open files
            try:
                open_files = proc.open_files()
                num_open = len(open_files)
                file_paths = [f.path for f in open_files]
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                num_open = -1
                file_paths = []

            # File descriptor count (Unix only)
            try:
                fds = proc.num_fds()
            except (psutil.AccessDenied, AttributeError):
                fds = 0

            # Context switches
            try:
                ctx = proc.num_ctx_switches()
                total_ctx = ctx.voluntary + ctx.involuntary
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                total_ctx = 0

            return ProcessSnapshot(
                timestamp=time.time(),
                pid=pid,
                name=info.get("name") or "",
                cmdline=info.get("cmdline") or [],
                username=info.get("username") or "",
                ppid=ppid,
                cpu_percent=cpu,
                memory_rss=mem.rss,
                num_connections=num_conns,
                num_open_files=num_open,
                open_file_paths=file_paths,
                num_fds=fds,
                num_ctx_switches=total_ctx,
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return None

    # ------------------------------------------------------------------
    # History management
    # ------------------------------------------------------------------

    def _append_snapshot(self, snapshot: ProcessSnapshot):
        """Append snapshot and track sensitive files. Does NOT update baselines."""
        pid = snapshot.pid
        if pid not in self._process_histories:
            self._process_histories[pid] = ProcessHistory(
                pid=pid,
                name=snapshot.name,
                first_seen=snapshot.timestamp,
                snapshots=deque(maxlen=BEHAVIORAL_HISTORY_MAX_SNAPSHOTS),
            )
        history = self._process_histories[pid]
        history.snapshots.append(snapshot)

        # Accumulate cumulative counters (anti-spoofing)
        for path in snapshot.open_file_paths:
            history.total_unique_files_accessed.add(path)
        if snapshot.num_connections >= 0:
            history.total_connections_seen += snapshot.num_connections

        # Track sensitive file access
        for path in snapshot.open_file_paths:
            path_lower = path.lower()
            for pattern in SENSITIVE_FILE_PATTERNS:
                if pattern in path_lower:
                    history.sensitive_files_seen.add(path)
                    break

        # Track protected document access
        for path in snapshot.open_file_paths:
            if self._is_protected_document(path):
                history.protected_documents_accessed.add(path)

    def _update_baselines(self, history: ProcessHistory, snapshot: ProcessSnapshot):
        """Update rolling EMA baselines with new snapshot data."""
        alpha = BEHAVIORAL_EMA_ALPHA
        if snapshot.cpu_percent >= 0:
            history.baseline_cpu = (
                alpha * snapshot.cpu_percent + (1 - alpha) * history.baseline_cpu
            )
        if snapshot.num_connections >= 0:
            history.baseline_connections = (
                alpha * snapshot.num_connections
                + (1 - alpha) * history.baseline_connections
            )
        if snapshot.num_open_files >= 0:
            history.baseline_open_files = (
                alpha * snapshot.num_open_files
                + (1 - alpha) * history.baseline_open_files
            )

    # ------------------------------------------------------------------
    # Scoring system
    # ------------------------------------------------------------------

    def _score_process(self, history: ProcessHistory) -> Tuple[float, List[Dict]]:
        """Compute anomaly score (0.0-1.0) from weighted behavioral signals."""
        signals: List[Dict] = []
        latest = history.snapshots[-1]

        # Signal 1: Rapid file access
        self._check_file_access(latest, history, signals)

        # Signal 2: Sensitive file access patterns
        self._check_sensitive_files(history, signals)

        # Signal 3: Network burst activity
        self._check_network_burst(latest, history, signals)

        # Signal 4: CPU anomaly
        self._check_cpu_anomaly(latest, history, signals)

        # Signal 5: Suspicious process lineage
        self._check_lineage(latest, signals)

        # Signal 6: Cumulative file access (anti-spoofing)
        self._check_cumulative_file_access(history, signals)

        # Signal 7: Cumulative network activity (anti-spoofing)
        self._check_cumulative_network(history, signals)

        # Signal 8: Protected document access
        self._check_document_access(history, signals)

        if not signals:
            return 0.0, signals

        weight_map = {
            "rapid_file_access": BEHAVIORAL_WEIGHT_FILE_ACCESS,
            "sensitive_file_access": BEHAVIORAL_WEIGHT_SENSITIVE_FILE,
            "network_burst": BEHAVIORAL_WEIGHT_NETWORK,
            "cpu_anomaly": BEHAVIORAL_WEIGHT_CPU,
            "suspicious_lineage": BEHAVIORAL_WEIGHT_LINEAGE,
            "cumulative_file_access": BEHAVIORAL_WEIGHT_CUMULATIVE_FILE,
            "cumulative_network": BEHAVIORAL_WEIGHT_CUMULATIVE_NETWORK,
            "protected_document_access": BEHAVIORAL_WEIGHT_DOCUMENT_ACCESS,
        }

        total = sum(
            sig["score"] * weight_map.get(sig["signal"], 0.1) for sig in signals
        )
        return min(total, 1.0), signals

    def _check_file_access(
        self,
        latest: ProcessSnapshot,
        history: ProcessHistory,
        signals: List[Dict],
    ):
        """Check for rapid file access spikes."""
        # Spike relative to baseline
        if latest.num_open_files >= 0 and history.baseline_open_files > 0:
            ratio = latest.num_open_files / max(history.baseline_open_files, 1.0)
            if ratio > BEHAVIORAL_FILE_ACCESS_SPIKE_RATIO:
                score = min(
                    (ratio - BEHAVIORAL_FILE_ACCESS_SPIKE_RATIO)
                    / BEHAVIORAL_FILE_ACCESS_SPIKE_RATIO,
                    1.0,
                )
                signals.append(
                    {
                        "signal": "rapid_file_access",
                        "score": score,
                        "detail": (
                            f"open_files={latest.num_open_files}, "
                            f"baseline={history.baseline_open_files:.1f}, "
                            f"ratio={ratio:.1f}"
                        ),
                    }
                )
                return

        # Absolute threshold for processes with no/low baseline
        if latest.num_open_files >= BEHAVIORAL_FILE_ACCESS_ABSOLUTE_THRESHOLD:
            score = min(
                latest.num_open_files / (BEHAVIORAL_FILE_ACCESS_ABSOLUTE_THRESHOLD * 2),
                1.0,
            )
            signals.append(
                {
                    "signal": "rapid_file_access",
                    "score": score,
                    "detail": (
                        f"open_files={latest.num_open_files} exceeds "
                        f"absolute threshold {BEHAVIORAL_FILE_ACCESS_ABSOLUTE_THRESHOLD}"
                    ),
                }
            )

    def _check_sensitive_files(self, history: ProcessHistory, signals: List[Dict]):
        """Check for access to sensitive files."""
        if history.sensitive_files_seen:
            count = len(history.sensitive_files_seen)
            score = min(count * 0.3, 1.0)
            signals.append(
                {
                    "signal": "sensitive_file_access",
                    "score": score,
                    "detail": (
                        f"accessed {count} sensitive file(s): "
                        f"{list(history.sensitive_files_seen)[:5]}"
                    ),
                }
            )

    def _check_network_burst(
        self,
        latest: ProcessSnapshot,
        history: ProcessHistory,
        signals: List[Dict],
    ):
        """Check for network connection spikes."""
        if latest.num_connections < 0:
            return

        # Spike relative to baseline
        if history.baseline_connections > 0:
            ratio = latest.num_connections / max(history.baseline_connections, 1.0)
            if ratio > BEHAVIORAL_NET_SPIKE_RATIO:
                score = min(
                    (ratio - BEHAVIORAL_NET_SPIKE_RATIO) / BEHAVIORAL_NET_SPIKE_RATIO,
                    1.0,
                )
                signals.append(
                    {
                        "signal": "network_burst",
                        "score": score,
                        "detail": (
                            f"connections={latest.num_connections}, "
                            f"baseline={history.baseline_connections:.1f}, "
                            f"ratio={ratio:.1f}"
                        ),
                    }
                )
                return

        # Absolute threshold
        if latest.num_connections >= BEHAVIORAL_NET_CONNECTIONS_ABSOLUTE_THRESHOLD:
            score = min(
                latest.num_connections
                / (BEHAVIORAL_NET_CONNECTIONS_ABSOLUTE_THRESHOLD * 2),
                1.0,
            )
            signals.append(
                {
                    "signal": "network_burst",
                    "score": score,
                    "detail": (
                        f"connections={latest.num_connections} exceeds "
                        f"absolute threshold {BEHAVIORAL_NET_CONNECTIONS_ABSOLUTE_THRESHOLD}"
                    ),
                }
            )

    def _check_cpu_anomaly(
        self,
        latest: ProcessSnapshot,
        history: ProcessHistory,
        signals: List[Dict],
    ):
        """Check for CPU usage spikes."""
        if latest.cpu_percent <= BEHAVIORAL_CPU_SPIKE_THRESHOLD:
            return
        if history.baseline_cpu <= 0:
            return

        ratio = latest.cpu_percent / max(history.baseline_cpu, 0.1)
        if ratio > BEHAVIORAL_CPU_SPIKE_RATIO:
            score = min(
                (ratio - BEHAVIORAL_CPU_SPIKE_RATIO) / BEHAVIORAL_CPU_SPIKE_RATIO,
                1.0,
            )
            signals.append(
                {
                    "signal": "cpu_anomaly",
                    "score": score,
                    "detail": (
                        f"cpu={latest.cpu_percent:.1f}%, "
                        f"baseline={history.baseline_cpu:.1f}%, "
                        f"ratio={ratio:.1f}"
                    ),
                }
            )

    def _check_cumulative_file_access(
        self, history: ProcessHistory, signals: List[Dict]
    ):
        """Check for high cumulative unique file access over the observation window."""
        total = len(history.total_unique_files_accessed)
        if total >= BEHAVIORAL_CUMULATIVE_FILE_THRESHOLD:
            score = min(total / (BEHAVIORAL_CUMULATIVE_FILE_THRESHOLD * 2), 1.0)
            signals.append(
                {
                    "signal": "cumulative_file_access",
                    "score": score,
                    "detail": (
                        f"total_unique_files={total} exceeds "
                        f"threshold {BEHAVIORAL_CUMULATIVE_FILE_THRESHOLD}"
                    ),
                }
            )

    def _check_cumulative_network(self, history: ProcessHistory, signals: List[Dict]):
        """Check for high cumulative network activity over the observation window."""
        total = history.total_connections_seen
        if total >= BEHAVIORAL_CUMULATIVE_NET_THRESHOLD:
            score = min(total / (BEHAVIORAL_CUMULATIVE_NET_THRESHOLD * 2), 1.0)
            signals.append(
                {
                    "signal": "cumulative_network",
                    "score": score,
                    "detail": (
                        f"total_connections={total} exceeds "
                        f"threshold {BEHAVIORAL_CUMULATIVE_NET_THRESHOLD}"
                    ),
                }
            )

    def _is_protected_document(self, file_path: str) -> bool:
        """Check if a file is a protected document in a monitored directory."""
        path_lower = file_path.lower()
        in_protected_dir = any(
            path_lower.startswith(d.lower()) for d in PROTECTED_DOCUMENT_PATHS
        )
        if not in_protected_dir:
            return False
        # Check extension
        _, ext = os.path.splitext(path_lower)
        if ext in PROTECTED_DOCUMENT_EXTENSIONS:
            return True
        # Check filename for sensitive name patterns
        filename_lower = os.path.basename(path_lower)
        return any(pat in filename_lower for pat in SENSITIVE_DOCUMENT_NAME_PATTERNS)

    def _check_document_access(self, history: ProcessHistory, signals: List[Dict]):
        """Check for untrusted process accessing protected documents."""
        if not history.protected_documents_accessed:
            return
        # Skip trusted document readers
        name_lower = history.name.lower()
        if any(reader in name_lower for reader in TRUSTED_DOCUMENT_READERS):
            return

        count = len(history.protected_documents_accessed)
        if count >= DOCUMENT_BULK_ACCESS_THRESHOLD:
            score = 1.0
            detail = f"BULK ACCESS: {count} protected documents accessed"
        elif count >= 2:
            score = 0.7
            detail = f"{count} protected documents accessed"
        else:
            score = 0.5
            detail = f"{count} protected document accessed"

        signals.append(
            {
                "signal": "protected_document_access",
                "score": score,
                "detail": detail,
                "document_count": count,
                "documents": list(history.protected_documents_accessed)[:10],
            }
        )

    def _check_lineage(self, snapshot: ProcessSnapshot, signals: List[Dict]):
        """Check the full ancestor chain for suspicious processes."""
        proc_name = snapshot.name.lower()
        if proc_name not in SCRIPTING_RUNTIMES:
            return

        try:
            chain = self._get_ancestor_chain(snapshot.ppid)
            if not chain:
                return

            immediate_parent = chain[0].lower()

            if immediate_parent in EXPECTED_PARENT_PROCESSES:
                # Check deeper ancestors for suspicious names
                suspicious_ancestors = [
                    name
                    for name in chain[1:]
                    if name.lower() not in EXPECTED_PARENT_PROCESSES
                    and name.lower() not in SCRIPTING_RUNTIMES
                    and name.lower() not in ("", "init", "launchd", "systemd")
                ]
                if suspicious_ancestors:
                    signals.append(
                        {
                            "signal": "suspicious_lineage",
                            "score": 0.2,
                            "detail": (
                                f"process '{snapshot.name}' has expected parent "
                                f"'{immediate_parent}' but suspicious ancestor(s): "
                                f"{suspicious_ancestors[:3]}"
                            ),
                        }
                    )
                return

            # Immediate parent is unexpected
            if immediate_parent in SCRIPTING_RUNTIMES:
                score = 0.3
            else:
                score = 0.5

            # Bonus for deep chain of non-standard processes
            chain_lower = [n.lower() for n in chain]
            non_standard = [
                n
                for n in chain_lower
                if n not in EXPECTED_PARENT_PROCESSES
                and n not in ("", "init", "launchd", "systemd")
            ]
            if len(non_standard) >= 3:
                score = min(score + 0.2, 1.0)

            signals.append(
                {
                    "signal": "suspicious_lineage",
                    "score": score,
                    "detail": (
                        f"process '{snapshot.name}' (ppid={snapshot.ppid}) "
                        f"full chain: {chain[:5]}"
                    ),
                }
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    def _get_ancestor_chain(self, ppid: int) -> List[str]:
        """Walk the process tree up to init/launchd, capped at max depth."""
        chain: List[str] = []
        current_pid = ppid
        for _ in range(LINEAGE_MAX_DEPTH):
            try:
                proc = psutil.Process(current_pid)
                name = proc.name()
                chain.append(name)
                if name.lower() in ("init", "launchd", "systemd"):
                    break
                current_pid = proc.ppid()
                if current_pid in (0, 1):
                    break
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                break
        return chain

    # ------------------------------------------------------------------
    # Cross-process correlation (anti-spoofing)
    # ------------------------------------------------------------------

    def _roll_into_user_activity(self, history: ProcessHistory):
        """Roll a dying process's data into user-level activity tracking."""
        if not history.snapshots:
            return
        username = history.snapshots[-1].username
        if not username:
            return

        if username not in self._user_activity:
            self._user_activity[username] = UserActivity(username=username)

        ua = self._user_activity[username]
        ua.sensitive_files_accessed |= history.sensitive_files_seen
        ua.sensitive_files_accessed |= history.protected_documents_accessed
        ua.total_pids_spawned += 1
        ua.pids_seen.add(history.pid)
        if len(history.snapshots) >= BEHAVIORAL_MIN_SNAPSHOTS_FOR_SCORING:
            score, _ = self._score_process(history)
            ua.aggregate_score += score
        ua.last_updated = time.time()

    def _check_user_level_anomaly(self):
        """Check for cross-process anomalies at the user level."""
        now = time.time()
        for username in list(self._user_activity.keys()):
            ua = self._user_activity[username]

            # Expire old entries
            if now - ua.last_updated > CROSS_PROCESS_WINDOW_SECONDS:
                del self._user_activity[username]
                continue

            should_alert = False
            reasons = []

            if (
                len(ua.sensitive_files_accessed)
                >= CROSS_PROCESS_SENSITIVE_FILE_THRESHOLD
            ):
                should_alert = True
                reasons.append(f"sensitive_files={len(ua.sensitive_files_accessed)}")

            if ua.total_pids_spawned >= CROSS_PROCESS_PID_THRESHOLD:
                should_alert = True
                reasons.append(f"pids_spawned={ua.total_pids_spawned}")

            if ua.aggregate_score >= CROSS_PROCESS_AGGREGATE_SCORE_THRESHOLD:
                should_alert = True
                reasons.append(f"aggregate_score={ua.aggregate_score:.2f}")

            if should_alert and not ua.alerted:
                self.alert_callback(
                    severity=SEVERITY_CRITICAL,
                    event_type="cross_process_anomaly_detected",
                    details={
                        "username": username,
                        "total_pids_spawned": ua.total_pids_spawned,
                        "pids_seen": list(ua.pids_seen),
                        "sensitive_files_accessed": list(ua.sensitive_files_accessed)[
                            :20
                        ],
                        "aggregate_score": round(ua.aggregate_score, 3),
                        "reasons": reasons,
                    },
                )
                ua.alerted = True

    # ------------------------------------------------------------------
    # Alert emission
    # ------------------------------------------------------------------

    def _emit_alert(
        self,
        history: ProcessHistory,
        score: float,
        signals: List[Dict],
        severity: str,
    ):
        """Fire an alert through the shared alert callback."""
        latest = history.snapshots[-1]
        self.alert_callback(
            severity=severity,
            event_type="behavioral_anomaly_detected",
            details={
                "pid": history.pid,
                "name": history.name,
                "cmdline": latest.cmdline,
                "username": latest.username,
                "anomaly_score": round(score, 3),
                "signals": signals,
                "sensitive_files_accessed": list(history.sensitive_files_seen),
                "observation_window_seconds": round(
                    latest.timestamp - history.first_seen, 1
                ),
                "snapshot_count": len(history.snapshots),
            },
        )
