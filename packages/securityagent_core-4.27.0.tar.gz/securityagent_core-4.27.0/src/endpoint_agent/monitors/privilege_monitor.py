"""
Cross-platform privilege awareness monitor.

Detects admin/root privileges, scans sensitive files for overly
permissive permissions, and warns about security risks.
"""

import logging
import os
import platform
import stat
from pathlib import Path
from typing import Callable, Dict, List

from endpoint_agent.config.settings import (
    MAX_SAFE_PERMISSION_OCTAL,
    SENSITIVE_FILE_EXTENSIONS,
    SENSITIVE_FILE_PATTERNS,
    SEVERITY_CRITICAL,
    SEVERITY_WARNING,
    SKIP_DIRECTORIES,
)

logger = logging.getLogger(__name__)


def is_elevated() -> bool:
    """Check if the current process is running with elevated privileges."""
    system = platform.system()

    if system in ("Linux", "Darwin"):
        return os.geteuid() == 0

    if system == "Windows":
        try:
            import ctypes

            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except (AttributeError, OSError):
            return False

    return False


def check_file_permissions(file_path: str) -> Dict:
    """
    Check if a file has overly permissive permissions.

    Returns a dict with path and list of issues found.
    """
    result = {"path": file_path, "issues": []}
    path = Path(file_path)

    if not path.exists():
        return result

    system = platform.system()

    if system in ("Linux", "Darwin"):
        st = path.stat()
        mode = st.st_mode

        if mode & stat.S_IROTH:
            result["issues"].append("world_readable")
        if mode & stat.S_IWOTH:
            result["issues"].append("world_writable")
        if mode & stat.S_IRGRP:
            result["issues"].append("group_readable")

        file_perm = stat.S_IMODE(mode)
        if file_perm > MAX_SAFE_PERMISSION_OCTAL:
            result["issues"].append(f"permissions_too_open_{oct(file_perm)}")
            result["current_permissions"] = oct(file_perm)
            result["recommended_permissions"] = oct(MAX_SAFE_PERMISSION_OCTAL)

    elif system == "Windows":
        if _is_public_windows_path(file_path):
            result["issues"].append("file_in_public_location")

    return result


def _is_public_windows_path(file_path: str) -> bool:
    """Check if a file is in a commonly shared Windows directory."""
    public_prefixes = [
        os.path.expandvars(r"%PUBLIC%"),
        os.path.expandvars(r"%PROGRAMDATA%"),
        r"C:\Users\Public",
    ]
    return any(file_path.lower().startswith(p.lower()) for p in public_prefixes if p)


def _is_sensitive_file(filename: str, full_path: str) -> bool:
    """Check if a file is considered sensitive based on name or extension."""
    for pattern in SENSITIVE_FILE_PATTERNS:
        if filename == pattern or full_path.endswith(pattern):
            return True
    for ext in SENSITIVE_FILE_EXTENSIONS:
        if filename.endswith(ext):
            return True
    return False


class PrivilegeMonitor:
    """Monitors privilege levels and file permissions."""

    def __init__(self, alert_callback: Callable, scan_dirs: List[str]):
        self.alert_callback = alert_callback
        self.scan_dirs = scan_dirs

    def check_current_privileges(self) -> bool:
        """Check and alert on current privilege level. Returns True if elevated."""
        elevated = is_elevated()
        if elevated:
            self.alert_callback(
                severity=SEVERITY_CRITICAL,
                event_type="elevated_privileges_detected",
                details={
                    "platform": platform.system(),
                    "user": os.environ.get(
                        "USER", os.environ.get("USERNAME", "unknown")
                    ),
                    "message": (
                        "Running with elevated privileges. "
                        "Malicious agents on this system have full access to all files."
                    ),
                },
            )
        return elevated

    def scan_file_permissions(self) -> List[Dict]:
        """Scan monitored directories for sensitive files with bad permissions."""
        findings = []
        for scan_dir in self.scan_dirs:
            if not os.path.isdir(scan_dir):
                continue
            for root, dirs, files in os.walk(scan_dir):
                dirs[:] = [d for d in dirs if d not in SKIP_DIRECTORIES]
                for fname in files:
                    full_path = os.path.join(root, fname)
                    if _is_sensitive_file(fname, full_path):
                        result = check_file_permissions(full_path)
                        if result["issues"]:
                            findings.append(result)
                            self.alert_callback(
                                severity=SEVERITY_WARNING,
                                event_type="insecure_file_permissions",
                                details=result,
                            )
        return findings
