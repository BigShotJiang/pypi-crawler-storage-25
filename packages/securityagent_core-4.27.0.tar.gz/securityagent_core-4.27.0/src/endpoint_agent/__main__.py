"""
CLI entry point for the endpoint security agent.

Usage:
    python -m endpoint_agent watch [--watch-dirs DIR ...]
    python -m endpoint_agent scan [DIR ...]
    python -m endpoint_agent status
"""

import argparse
import logging
import sys

from endpoint_agent.config.settings import DEFAULT_WATCH_DIRS
from endpoint_agent.engine import SecurityEngine


def main():
    parser = argparse.ArgumentParser(
        prog="endpoint_agent",
        description="Local endpoint security agent - detects malicious AI agents and exposed credentials",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable debug logging",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # watch subcommand
    watch_parser = subparsers.add_parser("watch", help="Start real-time monitoring")
    watch_parser.add_argument(
        "--watch-dirs",
        nargs="+",
        default=None,
        help="Directories to monitor (default: home + cwd)",
    )
    watch_parser.add_argument(
        "--log-file",
        default=None,
        help="Path for audit log (default: ~/.securityagent/audit.log)",
    )
    watch_parser.add_argument(
        "--alert-webhook",
        default=None,
        help="Webhook URL for remote alert notifications",
    )

    # scan subcommand
    scan_parser = subparsers.add_parser(
        "scan", help="One-shot credential and threat scan"
    )
    scan_parser.add_argument(
        "directories",
        nargs="*",
        default=["."],
        help="Directories to scan (default: current directory)",
    )
    scan_parser.add_argument(
        "--log-file",
        default=None,
        help="Path for audit log",
    )

    # status subcommand
    subparsers.add_parser("status", help="Show current security status")

    args = parser.parse_args()

    # Configure logging
    log_level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "watch":
        watch_dirs = args.watch_dirs or DEFAULT_WATCH_DIRS
        engine = SecurityEngine(
            watch_dirs=watch_dirs,
            log_file=args.log_file,
            webhook_url=args.alert_webhook,
        )
        engine.run_watch()

    elif args.command == "scan":
        engine = SecurityEngine(
            watch_dirs=args.directories,
            log_file=getattr(args, "log_file", None),
        )
        engine.run_scan(args.directories)

    elif args.command == "status":
        engine = SecurityEngine(watch_dirs=DEFAULT_WATCH_DIRS)
        engine.run_status()


if __name__ == "__main__":
    main()
