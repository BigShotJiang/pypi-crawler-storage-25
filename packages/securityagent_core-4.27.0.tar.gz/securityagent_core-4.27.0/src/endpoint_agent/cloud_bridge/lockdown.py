"""
Cloud-side lockdown bridge.

Triggers cloud-side security actions (SNS notifications, key rotation signals)
in response to critical local threats. The endpoint agent only publishes events -
a Lambda subscriber on the cloud side handles actual enforcement (updating WAF
rules, revoking API keys, etc.).
"""

import json
import logging
from typing import Optional

from endpoint_agent.config.settings import (
    AWS_REGION,
    CLOUD_BRIDGE_ENABLED,
    SNS_ALERT_TOPIC_ARN,
)

logger = logging.getLogger(__name__)


class CloudLockdown:
    """Triggers cloud-side security actions in response to local threats."""

    def __init__(self):
        self._boto3 = None
        if CLOUD_BRIDGE_ENABLED:
            try:
                import boto3

                self._boto3 = boto3
                logger.info("Cloud bridge enabled (SNS topic: %s)", SNS_ALERT_TOPIC_ARN)
            except ImportError:
                logger.warning("boto3 not available; cloud bridge disabled")

    @property
    def enabled(self) -> bool:
        return self._boto3 is not None and bool(SNS_ALERT_TOPIC_ARN)

    def notify_threat(self, alert):
        """Publish a threat notification to SNS for cloud-side processing."""
        if not self.enabled:
            return

        try:
            client = self._boto3.client("sns", region_name=AWS_REGION)
            client.publish(
                TopicArn=SNS_ALERT_TOPIC_ARN,
                Subject=f"LOCAL THREAT: {alert.event_type}"[:100],
                Message=json.dumps(
                    {
                        "source": "endpoint_agent",
                        "severity": alert.severity,
                        "event_type": alert.event_type,
                        "details": alert.details,
                    }
                ),
            )
            logger.info("Cloud notification sent for %s", alert.event_type)
        except Exception:
            logger.exception("Failed to send cloud notification")

    def trigger_key_rotation(self, compromised_key_prefix: Optional[str] = None):
        """
        Signal that API keys may be compromised and should be rotated.
        Publishes to SNS; a Lambda on the cloud side handles actual rotation.
        """
        if not self.enabled:
            return

        try:
            client = self._boto3.client("sns", region_name=AWS_REGION)
            client.publish(
                TopicArn=SNS_ALERT_TOPIC_ARN,
                Subject="KEY ROTATION REQUIRED",
                Message=json.dumps(
                    {
                        "action": "rotate_keys",
                        "source": "endpoint_agent",
                        "compromised_key_prefix": compromised_key_prefix,
                    }
                ),
            )
            logger.info("Key rotation signal sent")
        except Exception:
            logger.exception("Failed to trigger key rotation")
