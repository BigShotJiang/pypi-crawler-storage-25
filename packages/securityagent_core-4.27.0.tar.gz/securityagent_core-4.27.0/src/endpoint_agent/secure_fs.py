"""
Content-aware secure filesystem interceptor.

Provides secure_read() and secure_open() that scan file content via DLPScanner
before granting access. Sensitive files are ALWAYS blocked — there are no
configuration flags, policy files, or mode switches. Security is not optional.

Two-layer protection (both always active):
  1. Filename/extension blocking — .env, .pem, credentials.json etc. are
     blocked without reading content at all.
  2. Content DLP scan — any PII or credential pattern in the file body
     raises ConfidentialAccessError before the content is returned.
"""

import logging
import re
from pathlib import Path
from typing import Callable, Dict, List, Tuple

from endpoint_agent.config.settings import (
    DLP_SCANNABLE_BINARY_EXTENSIONS,
    MAX_LARGE_FILE_BYTES,
    MAX_SCAN_FILE_BYTES,
    SENSITIVE_DOCUMENT_NAME_PATTERNS,
    SENSITIVE_FILE_EXTENSIONS,
    SENSITIVE_FILE_PATTERNS,
    SENSITIVE_PATH_COMPONENTS,
    SEVERITY_CRITICAL,
    SEVERITY_WARNING,
)
from endpoint_agent.scanners.dlp_scanner import DLPScanner

logger = logging.getLogger(__name__)


class ConfidentialAccessError(PermissionError):
    """Raised when a file read is blocked due to confidential content."""

    def __init__(self, path: str, findings: List[Dict]):
        self.path = path
        self.findings = findings
        patterns = {f["pattern"] for f in findings}
        super().__init__(
            f"Access blocked: {path} contains sensitive data ({', '.join(sorted(patterns))})"
        )


class SecureFileSystem:
    """Content-aware file access interceptor with DLP scanning.

    Blocking is unconditional. There are no on/off switches, no policy files,
    no mode arguments, and no environment variable overrides. Any file whose
    name, extension, or content matches a sensitive pattern is blocked — always.
    """

    def __init__(self, alert_callback: Callable, trial_active: bool = True):
        self.alert_callback = alert_callback
        self.trial_active = trial_active
        self.dlp = DLPScanner(alert_callback=alert_callback)

    def secure_read(self, path: str) -> str:
        """Read a file, raising ConfidentialAccessError if it is sensitive.

        Layer 1 — filename/extension: checked before the file is opened.
        Layer 2 — content DLP scan: checked on the extracted text.
        Either layer raises ConfidentialAccessError; no silent pass-through.

        Supports binary document formats (PDF, XLSX, DOCX, CSV) via text
        extraction, and files up to 500 MB via chunked scanning.
        """
        # Core file gate ALWAYS runs regardless of trial status.
        # Trial gating only affects advanced features (content DLP, LLM analysis),
        # never the path-based blocking of .env, .pem, credentials, etc.

        real_path = str(Path(path).resolve())

        # Layer 1: filename / extension / keyword check (no I/O needed)
        path_blocked, block_reason = self._is_path_blocked(real_path)
        if path_blocked:
            findings = [
                {"type": "path_block", "pattern": block_reason, "source": real_path}
            ]
            self._alert(real_path, findings)
            raise ConfidentialAccessError(real_path, findings)

        # Layer 2: content DLP scan (skipped when trial expired — path gate still active above)
        if not self.trial_active:
            return Path(real_path).read_text(errors="ignore")

        p = Path(real_path)
        try:
            size = p.stat().st_size
            if size > MAX_LARGE_FILE_BYTES:
                findings = [
                    {
                        "type": "path_block",
                        "pattern": "file_too_large_to_scan",
                        "source": real_path,
                    }
                ]
                self._alert(real_path, findings)
                raise ConfidentialAccessError(real_path, findings)
            if size == 0:
                return ""
            content = self._read_content(p, real_path, size)
        except ConfidentialAccessError:
            raise
        except (OSError, PermissionError):
            raise

        findings = self.dlp.scan_content(content, source=real_path)
        if findings:
            self._alert(real_path, findings)
            raise ConfidentialAccessError(real_path, findings)

        return content

    def _read_content(self, p: Path, real_path: str, size: int) -> str:
        """Extract text from a file, using chunked scanning for large files."""
        suffix = p.suffix.lower()
        is_binary = suffix in DLP_SCANNABLE_BINARY_EXTENSIONS

        if size > MAX_SCAN_FILE_BYTES:
            # Large file: scan in chunks, block on first finding
            from endpoint_agent.scanners.text_extractor import (
                extract_text,
                extract_text_chunked,
            )

            for chunk in extract_text_chunked(real_path):
                chunk_findings = self.dlp.scan_content(chunk, source=real_path)
                if chunk_findings:
                    self._alert(real_path, chunk_findings)
                    raise ConfidentialAccessError(real_path, chunk_findings)
            # Clean — return full extracted text
            return extract_text(real_path)

        if is_binary:
            from endpoint_agent.scanners.text_extractor import extract_text

            return extract_text(real_path)

        return p.read_text(errors="ignore")

    def secure_open(self, path: str, mode: str = "r"):
        """Secure context manager. Read modes are DLP-scanned; write modes pass through."""
        if not self.trial_active:
            return open(path, mode)
        if "r" in mode and "b" not in mode:
            content = self.secure_read(path)
            return _StringHandle(content)
        return open(path, mode)

    def is_blocked(self, path: str) -> Tuple[bool, List[Dict]]:
        """Check whether a file would be blocked, without raising.

        Returns (is_blocked, findings). Useful for pre-flight checks and audits.
        """
        if not self.trial_active:
            return False, []

        real_path = str(Path(path).resolve())

        path_blocked, block_reason = self._is_path_blocked(real_path)
        if path_blocked:
            findings = [
                {"type": "path_block", "pattern": block_reason, "source": real_path}
            ]
            return True, findings

        try:
            p = Path(real_path)
            if not p.exists() or p.stat().st_size == 0:
                return False, []
            size = p.stat().st_size
            if size > MAX_LARGE_FILE_BYTES:
                findings = [
                    {
                        "type": "path_block",
                        "pattern": "file_too_large_to_scan",
                        "source": real_path,
                    }
                ]
                return True, findings
            content = self._read_content(p, real_path, size)
        except ConfidentialAccessError:
            # _read_content found something during chunked scan
            return True, [
                {
                    "type": "path_block",
                    "pattern": "dlp_content_violation",
                    "source": real_path,
                }
            ]
        except (OSError, PermissionError):
            return False, []

        findings = self.dlp.scan_content(content, source=real_path)
        return bool(findings), findings

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _is_path_blocked(self, path: str, strict: bool = True) -> Tuple[bool, str]:
        """Return (True, reason) if the path matches any sensitive pattern.

        Checks (in order):
          1. Sensitive path components   (/run/secrets/, /.vault/, …)
          2. Sensitive filename patterns (.env, credentials.json, .ssh/id_rsa …)
          3. Sensitive file extensions   (.pem, .key, .p12, …)
          4. Sensitive filename keywords (patient, ssn, medical, confidential …)  [strict only]
          5. Sensitive filename suffix   (_key, _secret, _token, _password …)     [strict only]

        When strict=False (used for in-workspace source files), only checks 1-3
        are applied.  Checks 4-5 cause false positives on source code that
        discusses or configures API keys without containing real secrets.
        """
        p = Path(path)
        name = p.name
        suffix = p.suffix.lower()
        path_lower = path.lower()
        name_lower = name.lower()

        # 1. Path component check — catches /run/secrets/*, /.vault/*, etc.
        for component in SENSITIVE_PATH_COMPONENTS:
            if component.lower() in path_lower:
                return True, f"sensitive_path_component:{component.strip('/')}"

        # 2. Filename / path-suffix patterns
        for pattern in SENSITIVE_FILE_PATTERNS:
            if name == pattern or path_lower.endswith(pattern.lower()):
                return True, f"sensitive_filename:{pattern}"

        # 3. Sensitive extensions
        if suffix in {ext.lower() for ext in SENSITIVE_FILE_EXTENSIONS}:
            return True, f"sensitive_extension:{suffix}"

        # Checks 4-5 are skipped for in-workspace source files (strict=False)
        # to avoid false positives on .py/.ipynb files that reference API keys
        # in variable names, imports, or configuration code.
        if not strict:
            return False, ""

        # 4. Filename keywords (medical, ssn, patient, confidential …)
        #    Use word-boundary matching so short keywords like "w2" or "tax"
        #    don't false-positive on random substrings (e.g. "tmpw2cq18yr").
        for keyword in SENSITIVE_DOCUMENT_NAME_PATTERNS:
            pattern = r"(?:^|[\W_])" + re.escape(keyword) + r"(?:[\W_]|$)"
            if re.search(pattern, name_lower):
                return True, f"sensitive_filename_keyword:{keyword}"

        # 5. Sensitive filename suffixes — files ending in _key, _secret, _token, etc.
        #    Catches: gemini_key, openai_secret, stripe_token, db_password
        _SENSITIVE_SUFFIXES = (
            "_key",
            "_secret",
            "_token",
            "_password",
            "_passwd",
            "_credential",
        )
        stem_lower = p.stem.lower()
        for sfx in _SENSITIVE_SUFFIXES:
            if stem_lower.endswith(sfx):
                return True, f"sensitive_filename_suffix:{sfx}"

        return False, ""

    def _alert(self, path: str, findings: List[Dict]) -> None:
        """Fire a CRITICAL/WARNING alert for a blocked access attempt."""
        severity = SEVERITY_CRITICAL if len(findings) >= 3 else SEVERITY_WARNING
        self.alert_callback(
            severity=severity,
            event_type="secure_fs_blocked",
            details={
                "path": path,
                "finding_count": len(findings),
                "findings": findings[:10],
                "action": "block",
            },
        )


class _StringHandle:
    """In-memory file handle wrapping pre-scanned content."""

    def __init__(self, content: str):
        self._content = content
        self._lines = content.splitlines(keepends=True)

    def read(self) -> str:
        return self._content

    def readlines(self) -> List[str]:
        return self._lines

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def __iter__(self):
        return iter(self._lines)

    def close(self):
        pass
