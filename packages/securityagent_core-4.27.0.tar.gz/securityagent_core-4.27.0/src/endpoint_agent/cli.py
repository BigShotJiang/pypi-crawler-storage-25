#!/usr/bin/env python3
"""
SecureMind CLI — `secagent` command.

Usage:
    secagent init                    # Auto-detect AI tools, configure protections
    secagent init --dry-run          # Preview what would be configured
    secagent scan [DIR ...]          # One-shot credential + threat scan
    secagent watch                   # Start real-time monitoring
    secagent demo                    # Run live attack demo
    secagent demo --no-llm           # Instant demo (no Ollama needed)
    secagent train                   # Train/retrain ML classifier
    secagent status                  # Show security status
    secagent version                 # Show version info
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


VERSION = "3.1.0"
BANNER = f"""\033[96m\033[1m
  ╔═══════════════════════════════════════════╗
  ║  SecureMind — AI Agent Security (v{VERSION})  ║
  ╚═══════════════════════════════════════════╝\033[0m
"""

# ─── AI Tool Detection ─────────────────────────────────────────────────────���──

AI_TOOLS = [
    {
        "name": "Claude Code",
        "detect": [
            lambda: shutil.which("claude") is not None,
            lambda: Path.home().joinpath(".claude").is_dir(),
        ],
        "config_path": ".claude/settings.json",
        "protect": "hook",
    },
    {
        "name": "GitHub Copilot",
        "detect": [
            lambda: Path.home().joinpath(".config", "github-copilot").is_dir(),
            lambda: any(Path.home().joinpath(".vscode", "extensions").glob("github.copilot-*")),
        ],
        "config_path": ".copilotignore",
        "protect": "ignore_file",
    },
    {
        "name": "Cursor",
        "detect": [
            lambda: shutil.which("cursor") is not None,
            lambda: Path.home().joinpath(".cursor").is_dir(),
            lambda: Path("/Applications/Cursor.app").is_dir(),
        ],
        "config_path": ".cursorignore",
        "protect": "ignore_file",
    },
    {
        "name": "VS Code",
        "detect": [
            lambda: shutil.which("code") is not None,
            lambda: Path.home().joinpath(".vscode").is_dir(),
        ],
        "config_path": ".vscode/settings.json",
        "protect": "vscode_settings",
    },
    {
        "name": "Windsurf",
        "detect": [
            lambda: shutil.which("windsurf") is not None,
            lambda: Path.home().joinpath(".windsurf").is_dir(),
        ],
        "config_path": ".windsurfignore",
        "protect": "ignore_file",
    },
    {
        "name": "Aider",
        "detect": [
            lambda: shutil.which("aider") is not None,
        ],
        "config_path": ".aiderignore",
        "protect": "ignore_file",
    },
    {
        "name": "Continue",
        "detect": [
            lambda: Path.home().joinpath(".continue").is_dir(),
        ],
        "config_path": ".continueignore",
        "protect": "ignore_file",
    },
]

# Sensitive patterns to add to ignore files
IGNORE_PATTERNS = [
    "# SecureMind — Sensitive files excluded from AI context",
    ".env",
    ".env.*",
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
    "id_rsa*",
    "id_ed25519*",
    "*.credentials",
    "credentials.json",
    "service-account*.json",
    ".aws/credentials",
    ".ssh/",
    "*.secret",
    "secrets/",
    "vault/",
]

CLAUDE_HOOK_CONFIG = {
    "hooks": {
        "PreToolUse": [
            {
                "matcher": "Read|Edit|Write|Bash|WebFetch",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python3 -c \"import sys,json; from endpoint_agent.scanners.dlp_scanner import scan_content; d=json.load(sys.stdin); r=scan_content(json.dumps(d.get('tool_input',{}))); sys.exit(1 if r.get('blocked') else 0)\"",
                    }
                ],
            }
        ]
    }
}


def detect_ai_tools():
    """Detect which AI tools are installed."""
    detected = []
    for tool in AI_TOOLS:
        for check in tool["detect"]:
            try:
                if check():
                    detected.append(tool)
                    break
            except Exception:
                continue
    return detected


def cmd_init(args):
    """Auto-detect AI tools and configure DLP protections."""
    print(BANNER)
    print("  Detecting AI tools...\n")

    detected = detect_ai_tools()

    if not detected:
        print("  \033[93mNo AI coding tools detected.\033[0m")
        print("  Supported: Claude Code, Copilot, Cursor, VS Code, Windsurf, Aider, Continue")
        return

    for tool in detected:
        print(f"  \033[92m✓\033[0m {tool['name']} detected")

    print(f"\n  Found {len(detected)} AI tool(s). Configuring protections...\n")

    if args.dry_run:
        print("  \033[93m[DRY RUN] Would configure:\033[0m")
        for tool in detected:
            print(f"    • {tool['name']}: {tool['config_path']}")
        return

    cwd = Path.cwd()
    configured = 0

    for tool in detected:
        config_path = cwd / tool["config_path"]

        if tool["protect"] == "ignore_file":
            # Create or append to ignore file
            existing = config_path.read_text() if config_path.exists() else ""
            if "SecureMind" in existing:
                print(f"  \033[90m⏭ {tool['name']}: already configured\033[0m")
                continue

            config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(config_path, "a") as f:
                if existing and not existing.endswith("\n"):
                    f.write("\n")
                f.write("\n".join(IGNORE_PATTERNS) + "\n")

            print(f"  \033[92m✓\033[0m {tool['name']}: wrote {config_path}")
            configured += 1

        elif tool["protect"] == "hook":
            # Claude Code hook configuration
            config_path.parent.mkdir(parents=True, exist_ok=True)
            if config_path.exists():
                existing = json.loads(config_path.read_text())
                if "hooks" in existing:
                    print(f"  \033[90m⏭ {tool['name']}: hooks already configured\033[0m")
                    continue

            print(f"  \033[92m✓\033[0m {tool['name']}: hook config at {config_path}")
            print(f"    \033[90m(Use AgnosticSecurity's .claude/settings.json for full hook config)\033[0m")
            configured += 1

        elif tool["protect"] == "vscode_settings":
            # VS Code settings
            config_path.parent.mkdir(parents=True, exist_ok=True)
            if config_path.exists():
                existing = json.loads(config_path.read_text())
            else:
                existing = {}

            if "agnosticsecurity.enabled" in str(existing):
                print(f"  \033[90m⏭ {tool['name']}: already configured\033[0m")
                continue

            # Add search exclude for sensitive files
            search_exclude = existing.get("search.exclude", {})
            search_exclude.update({
                "**/.env": True,
                "**/.env.*": True,
                "**/*.pem": True,
                "**/*.key": True,
                "**/id_rsa*": True,
                "**/.aws/credentials": True,
            })
            existing["search.exclude"] = search_exclude
            config_path.write_text(json.dumps(existing, indent=2) + "\n")

            print(f"  \033[92m✓\033[0m {tool['name']}: updated {config_path}")
            configured += 1

    print(f"\n  \033[92mDone.\033[0m Configured {configured} tool(s).")
    print(f"  \033[90mRun `secagent status` to verify protections.\033[0m\n")


def cmd_scan(args):
    """One-shot scan for credentials and threats."""
    from endpoint_agent.config.settings import DEFAULT_WATCH_DIRS
    from endpoint_agent.engine import SecurityEngine

    dirs = args.directories or ["."]
    engine = SecurityEngine(watch_dirs=dirs, log_file=args.log_file)
    engine.run_scan(dirs)


def cmd_watch(args):
    """Start real-time monitoring."""
    from endpoint_agent.config.settings import DEFAULT_WATCH_DIRS
    from endpoint_agent.engine import SecurityEngine

    watch_dirs = args.watch_dirs or DEFAULT_WATCH_DIRS
    engine = SecurityEngine(
        watch_dirs=watch_dirs,
        log_file=args.log_file,
        webhook_url=args.alert_webhook,
    )
    engine.run_watch()


def cmd_demo(args):
    """Run the live attack demo."""
    demo_script = Path(__file__).parent.parent.parent.parent / "AgnosticSecurity" / "demo" / "live_attack_demo.py"

    # Try common locations
    candidates = [
        demo_script,
        Path.home() / "AgnosticSecurity" / "demo" / "live_attack_demo.py",
        Path.cwd() / "demo" / "live_attack_demo.py",
    ]

    for path in candidates:
        if path.exists():
            cmd = [sys.executable, str(path)]
            if args.fast:
                cmd.append("--fast")
            if args.no_llm:
                cmd.append("--no-llm")
            if args.json_output:
                cmd.append("--json")
            os.execv(sys.executable, cmd)
            return

    print("  \033[91mDemo script not found.\033[0m")
    print("  Expected at: ~/AgnosticSecurity/demo/live_attack_demo.py")
    print("  Clone: git clone https://github.com/secure-mind-live/AgnosticSecurity.git")
    sys.exit(1)


def cmd_train(args):
    """Train/retrain the ML classifier."""
    if args.auto:
        # Active learning: check if retraining is needed
        print(BANNER)
        print("  \033[1mActive Learning Check\033[0m\n")
        from endpoint_agent.scanners.active_learner import ActiveLearner
        learner = ActiveLearner()
        check = learner.should_retrain()
        print(f"  New audit entries: {check['new_entries']}")
        print(f"  Total entries:     {check['total_entries']}")
        print(f"  Threshold:         {learner.retrain_threshold}")
        print(f"  Decision:          {'RETRAIN' if check['should_retrain'] else 'SKIP'}")
        print(f"  Reason:            {check['reason']}\n")

        if check["should_retrain"]:
            result = learner.check_and_retrain()
            if result["action"] == "retrained":
                print(f"  \033[92mRetrained successfully!\033[0m")
                print(f"    Intent F1: {result['intent_f1']['old']:.3f} -> {result['intent_f1']['new']:.3f}")
                print(f"    PII F1:    {result['pii_f1']['old']:.3f} -> {result['pii_f1']['new']:.3f}")
            elif result["action"] == "rejected":
                print(f"  \033[93mNew model rejected:\033[0m {result['reason']}")
            else:
                print(f"  \033[90m{result.get('reason', 'Unknown')}\033[0m")
        else:
            print(f"  \033[90mNo retraining needed.\033[0m")
        return

    train_script = Path.home() / "AgnosticSecurity" / "scripts" / "train_enhanced_classifier.py"

    if not train_script.exists():
        print("  \033[91mTraining script not found.\033[0m")
        print("  Expected at: ~/AgnosticSecurity/scripts/train_enhanced_classifier.py")
        sys.exit(1)

    cmd = [sys.executable, str(train_script)]
    if args.eval:
        cmd.append("--eval")
    os.execv(sys.executable, cmd)


def cmd_status(args):
    """Show security status."""
    print(BANNER)
    print("  \033[1mProtection Status\033[0m\n")

    # Check AI tools
    detected = detect_ai_tools()
    print(f"  AI tools detected: {len(detected)}")
    for tool in detected:
        print(f"    \033[92m✓\033[0m {tool['name']}")

    # Check models
    model_dir = Path.home() / ".agnosticsecurity" / "models"
    v2_intent = model_dir / "intent_classifier_v2.joblib"
    v2_pii = model_dir / "pii_context_classifier_v2.joblib"

    print(f"\n  ML Models:")
    if v2_intent.exists():
        size = v2_intent.stat().st_size / 1024
        print(f"    \033[92m✓\033[0m Intent classifier v2 ({size:.0f} KB)")
    else:
        print(f"    \033[91m✗\033[0m Intent classifier — run `secagent train`")

    if v2_pii.exists():
        size = v2_pii.stat().st_size / 1024
        print(f"    \033[92m✓\033[0m PII context classifier v2 ({size:.0f} KB)")
    else:
        print(f"    \033[91m✗\033[0m PII context classifier — run `secagent train`")

    # Check sentence-transformers
    st_dir = model_dir / "sentence-transformers_all-MiniLM-L6-v2"
    if st_dir.exists() or (model_dir / "models--sentence-transformers--all-MiniLM-L6-v2").exists():
        print(f"    \033[92m✓\033[0m Sentence-transformers (all-MiniLM-L6-v2)")
    else:
        print(f"    \033[93m⚠\033[0m Sentence-transformers — will download on first use (~80MB)")

    print()


def cmd_mcp(args):
    """Start the MCP security server."""
    print(BANNER)
    transport = args.transport

    if transport == "stdio":
        print("  \033[92mStarting MCP server (stdio transport)...\033[0m")
        print("  \033[90mConnect via: {\"command\": \"secagent\", \"args\": [\"mcp\"]} in MCP client config\033[0m")
        print("  \033[90m9 security tools available. Ctrl+C to stop.\033[0m\n")

        # Add src to path for skills imports
        src_dir = Path(__file__).parent.parent
        if str(src_dir) not in sys.path:
            sys.path.insert(0, str(src_dir))

        from skills.adapters.mcp_server import MCPServer
        server = MCPServer()
        server.run()

    elif transport == "sse":
        print("  \033[92mStarting MCP server (SSE transport)...\033[0m")
        port = args.port
        print(f"  \033[90mListening on http://localhost:{port}/sse\033[0m")
        print(f"  \033[90m9 security tools available. Ctrl+C to stop.\033[0m\n")

        src_dir = Path(__file__).parent.parent
        if str(src_dir) not in sys.path:
            sys.path.insert(0, str(src_dir))

        from skills.adapters.mcp_sse_server import run_sse_server
        run_sse_server(port=port)


def cmd_version(args):
    """Show version info."""
    print(f"secagent {VERSION} (securityagent-core)")
    print(f"Python {sys.version.split()[0]}")


def main():
    parser = argparse.ArgumentParser(
        prog="secagent",
        description="SecureMind — Local-first security for AI coding agents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  secagent init              Auto-configure protections for detected AI tools
  secagent init --dry-run    Preview what would be configured
  secagent mcp               Start MCP security server (stdio)
  secagent mcp --transport sse --port 8765  Start SSE server
  secagent demo --no-llm    Run instant attack demo (no Ollama needed)
  secagent scan .            Scan current directory for secrets
  secagent train --eval      Train ML classifier and run eval
  secagent status            Show protection status
        """,
    )

    subparsers = parser.add_subparsers(dest="command")

    # init
    init_p = subparsers.add_parser("init", help="Auto-detect AI tools, configure protections")
    init_p.add_argument("--dry-run", action="store_true", help="Preview only, don't write files")

    # scan
    scan_p = subparsers.add_parser("scan", help="One-shot credential + threat scan")
    scan_p.add_argument("directories", nargs="*", help="Directories to scan")
    scan_p.add_argument("--log-file", default=None)

    # watch
    watch_p = subparsers.add_parser("watch", help="Start real-time monitoring")
    watch_p.add_argument("--watch-dirs", nargs="+", default=None)
    watch_p.add_argument("--log-file", default=None)
    watch_p.add_argument("--alert-webhook", default=None)

    # demo
    demo_p = subparsers.add_parser("demo", help="Run live attack demo")
    demo_p.add_argument("--fast", action="store_true", help="No animation delays")
    demo_p.add_argument("--no-llm", action="store_true", help="Skip LLM-dependent checks (instant)")
    demo_p.add_argument("--json", dest="json_output", action="store_true", help="JSON output")

    # train
    train_p = subparsers.add_parser("train", help="Train/retrain ML classifier")
    train_p.add_argument("--eval", action="store_true", help="Run eval after training")
    train_p.add_argument("--auto", action="store_true", help="Active learning: auto-retrain if enough new data")

    # mcp
    mcp_p = subparsers.add_parser("mcp", help="Start MCP security server")
    mcp_p.add_argument("--transport", choices=["stdio", "sse"], default="stdio",
                       help="Transport: stdio (default) or sse (HTTP)")
    mcp_p.add_argument("--port", type=int, default=8765, help="Port for SSE transport (default: 8765)")

    # status
    subparsers.add_parser("status", help="Show security status")

    # version
    subparsers.add_parser("version", help="Show version")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {
        "init": cmd_init,
        "scan": cmd_scan,
        "watch": cmd_watch,
        "demo": cmd_demo,
        "train": cmd_train,
        "mcp": cmd_mcp,
        "status": cmd_status,
        "version": cmd_version,
    }

    commands[args.command](args)


if __name__ == "__main__":
    main()
