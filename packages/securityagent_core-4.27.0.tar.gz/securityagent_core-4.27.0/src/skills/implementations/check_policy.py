"""check_policy skill — pre-flight policy check without execution."""

from typing import Any, Dict

from skills.base import BaseSkill, SkillResult, SkillStatus
from skills.context import SessionContext


class CheckPolicySkill(BaseSkill):
    name = "check_policy"
    description = (
        "Check if an action would be allowed by the current session policy "
        "without executing it. Use for pre-flight validation."
    )

    def __init__(self, policy_engine: "PolicyEngine"):
        self._policy = policy_engine

    def execute(self, params: Dict[str, Any], context: SessionContext) -> SkillResult:
        skill_name = params.get("skill", "")
        skill_params = params.get("params", {})

        if not skill_name:
            return SkillResult(
                status=SkillStatus.ERROR, reason="No skill name provided"
            )

        decision = self._policy.evaluate(skill_name, skill_params, context)

        return SkillResult(
            status=SkillStatus.ALLOWED if decision.allowed else SkillStatus.BLOCKED,
            reason=decision.reason,
            data={
                "allowed": decision.allowed,
                "rule_name": decision.rule_name,
                "skill": skill_name,
            },
        )

    def schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "skill": {
                    "type": "string",
                    "description": "Skill name to check policy for",
                },
                "params": {
                    "type": "object",
                    "description": "Parameters that would be passed to the skill",
                },
            },
            "required": ["skill"],
        }
