"""secure_read skill — DLP-gated file reading."""

from typing import Any, Dict

from skills.base import BaseSkill, SkillResult, SkillStatus
from skills.context import SessionContext


class SecureReadSkill(BaseSkill):
    name = "secure_read"
    description = (
        "Read a file with DLP filtering. Blocks sensitive filenames, "
        "extensions, and content (PII, credentials). Supports PDF, XLSX, "
        "DOCX, CSV via text extraction."
    )

    def __init__(self):
        self._fs = None

    def _get_fs(self):
        if self._fs is None:
            from endpoint_agent.secure_fs import SecureFileSystem

            self._fs = SecureFileSystem(alert_callback=lambda **kw: None)
        return self._fs

    def execute(self, params: Dict[str, Any], context: SessionContext) -> SkillResult:
        path = params.get("path") or params.get("file_path", "")
        if not path:
            return SkillResult(status=SkillStatus.ERROR, reason="No file path provided")

        try:
            from endpoint_agent.secure_fs import ConfidentialAccessError

            content = self._get_fs().secure_read(path)

            # Apply offset/limit (1-indexed, matching existing CLI behavior)
            offset = params.get("offset")
            limit = params.get("limit")
            if offset is not None or limit is not None:
                lines = content.splitlines(keepends=True)
                start = (offset - 1) if offset and offset > 0 else 0
                end = (start + limit) if limit else None
                content = "".join(lines[start:end])

            return SkillResult(status=SkillStatus.ALLOWED, data=content)

        except ConfidentialAccessError as exc:
            return SkillResult(
                status=SkillStatus.BLOCKED, reason=str(exc), findings=exc.findings
            )
        except (OSError, PermissionError) as exc:
            return SkillResult(status=SkillStatus.ERROR, reason=str(exc))

    def schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read"},
                "file_path": {"type": "string", "description": "Alias for path"},
                "offset": {
                    "type": "integer",
                    "description": "Start line (1-indexed)",
                },
                "limit": {"type": "integer", "description": "Max lines to return"},
            },
        }
