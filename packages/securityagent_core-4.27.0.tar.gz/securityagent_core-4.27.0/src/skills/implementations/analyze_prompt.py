"""analyze_prompt skill — 3-layer prompt intent analysis."""

from typing import Any, Dict

from skills.base import BaseSkill, SkillResult, SkillStatus
from skills.context import SessionContext


class AnalyzePromptSkill(BaseSkill):
    name = "analyze_prompt"
    description = (
        "Analyze a prompt for sensitive data access intent using 3-layer "
        "analysis: regex (<50ms), Pydantic rules, optional local LLM."
    )

    def execute(self, params: Dict[str, Any], context: SessionContext) -> SkillResult:
        prompt_text = params.get("prompt", "")
        if not prompt_text:
            return SkillResult(status=SkillStatus.ERROR, reason="No prompt provided")

        from plugin import validate_prompt

        result = validate_prompt(prompt_text)

        if result.get("should_block"):
            return SkillResult(
                status=SkillStatus.BLOCKED,
                reason=f"Prompt classified as high-risk: {', '.join(result.get('intent_categories', []))}",
                findings=[
                    {
                        "risk_score": result["risk_score"],
                        "risk_level": result["risk_level"],
                        "intent_categories": result["intent_categories"],
                        "evasion_flags": result.get("evasion_flags", []),
                    }
                ],
                data=result,
            )

        return SkillResult(status=SkillStatus.ALLOWED, data=result)

    def schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "Prompt text to analyze",
                },
            },
            "required": ["prompt"],
        }
