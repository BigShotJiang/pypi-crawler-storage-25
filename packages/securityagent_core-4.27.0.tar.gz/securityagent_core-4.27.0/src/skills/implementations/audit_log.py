"""audit_log skill — query the audit trail."""

from typing import Any, Dict

from skills.base import BaseSkill, SkillResult, SkillStatus
from skills.context import SessionContext


class AuditLogSkill(BaseSkill):
    name = "audit_log"
    description = "Query the security audit trail with optional filters."

    def __init__(self, audit_trail: "AuditTrail"):
        self._audit = audit_trail

    def execute(self, params: Dict[str, Any], context: SessionContext) -> SkillResult:
        entries = self._audit.query(
            session_id=params.get("session_id"),
            agent_id=params.get("agent_id"),
            skill=params.get("skill"),
            limit=params.get("limit", 100),
        )

        return SkillResult(
            status=SkillStatus.ALLOWED,
            data={"entries": entries, "count": len(entries)},
        )

    def schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Filter by session ID",
                },
                "agent_id": {
                    "type": "string",
                    "description": "Filter by agent ID",
                },
                "skill": {
                    "type": "string",
                    "description": "Filter by skill name",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max entries to return (default 100)",
                },
            },
        }
