"""scan_output skill — post-execution output DLP scanning + redaction."""

from typing import Any, Dict

from skills.base import BaseSkill, SkillResult, SkillStatus
from skills.context import SessionContext


class ScanOutputSkill(BaseSkill):
    name = "scan_output"
    description = (
        "Scan command output for PII and credentials. Returns redacted "
        "content if sensitive data is found."
    )

    def execute(self, params: Dict[str, Any], context: SessionContext) -> SkillResult:
        content = params.get("content", "")
        if not content:
            return SkillResult(status=SkillStatus.ERROR, reason="No content provided")

        from plugin import validate_output

        redacted, findings = validate_output(content)

        if findings:
            return SkillResult(
                status=SkillStatus.BLOCKED,
                reason="Output contains sensitive data",
                data=redacted,
                findings=[
                    {"pattern": f["pattern"], "type": f["type"], "line": f["line"]}
                    for f in findings[:10]
                ],
            )

        return SkillResult(status=SkillStatus.ALLOWED, data=content)

    def schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "content": {
                    "type": "string",
                    "description": "Command output to scan",
                },
            },
            "required": ["content"],
        }
