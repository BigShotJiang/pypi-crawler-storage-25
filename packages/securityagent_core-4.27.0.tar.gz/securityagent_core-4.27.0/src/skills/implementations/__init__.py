"""Security skill implementations — each wraps existing enforcement code."""
