"""secure_exec skill — command validation via shape rules + path DLP."""

from typing import Any, Dict

from skills.base import BaseSkill, SkillResult, SkillStatus
from skills.context import SessionContext


class SecureExecSkill(BaseSkill):
    name = "secure_exec"
    description = (
        "Validate a shell command against DLP rules before execution. "
        "Checks command shape patterns (exfiltration, credential access, "
        "cloud CLI uploads) and file path references."
    )

    def execute(self, params: Dict[str, Any], context: SessionContext) -> SkillResult:
        command = params.get("command", "")
        if not command:
            return SkillResult(status=SkillStatus.ERROR, reason="No command provided")

        from plugin import validate_exec

        blocked, reason, patterns = validate_exec(command)
        if blocked:
            return SkillResult(
                status=SkillStatus.BLOCKED,
                reason=reason,
                findings=[{"patterns": patterns}],
            )

        return SkillResult(status=SkillStatus.ALLOWED, data={"command": command})

    def schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Shell command to validate",
                },
            },
            "required": ["command"],
        }
