"""Token optimization skill — strip sensitive data before it reaches the LLM.

Scans content for PII, credentials, and sensitive patterns, then returns
a redacted version with token savings metrics. Two value props in one:
fewer tokens (cost savings) + better security (no data leakage).

Usage via MCP:
    tools/call: {"name": "token_optimize", "arguments": {"content": "..."}}

Returns:
    - redacted_content: cleaned text safe for LLM consumption
    - original_tokens: estimated token count of original
    - optimized_tokens: estimated token count after redaction
    - savings_pct: percentage of tokens saved
    - findings: what was redacted and why
"""

import re
from typing import Any, Dict

from skills.base import BaseSkill, SkillResult, SkillStatus


def _estimate_tokens(text: str) -> int:
    """Rough token estimate (~4 chars per token for English text)."""
    return max(1, len(text) // 4)


def _redact_pattern(text: str, pattern: re.Pattern, label: str, findings: list) -> str:
    """Replace all matches of a pattern with a redaction placeholder."""
    def replacer(match):
        findings.append({
            "type": label,
            "preview": match.group()[:4] + "***",
            "chars_removed": len(match.group()),
        })
        return f"[{label}_REDACTED]"
    return pattern.sub(replacer, text)


# Pre-compiled patterns for sensitive data
_PATTERNS = [
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "SSN"),
    (re.compile(r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b"), "CREDIT_CARD"),
    (re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"), "AWS_KEY"),
    (re.compile(r"\bsk-[a-zA-Z0-9]{20,}\b"), "API_KEY"),
    (re.compile(r"\bsk-(?:live|test)-[a-zA-Z0-9]{24,}\b"), "STRIPE_KEY"),
    (re.compile(r"\bghp_[a-zA-Z0-9]{36}\b"), "GITHUB_TOKEN"),
    (re.compile(r"\bglpat-[a-zA-Z0-9\-]{20,}\b"), "GITLAB_TOKEN"),
    (re.compile(r"\bxoxb-[0-9]+-[0-9]+-[a-zA-Z0-9]+\b"), "SLACK_TOKEN"),
    (re.compile(r"-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |DSA )?PRIVATE KEY-----"), "PRIVATE_KEY"),
    (re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+\b"), "JWT"),
    (re.compile(r"(?:password|passwd|pwd)\s*[:=]\s*['\"]?[^\s'\"]{8,}['\"]?", re.IGNORECASE), "PASSWORD"),
    (re.compile(r"(?:mongodb(?:\+srv)?|postgres(?:ql)?|mysql|redis)://[^\s]+", re.IGNORECASE), "DATABASE_URL"),
    (re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"), "EMAIL"),
    (re.compile(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"), "PHONE"),
]


class TokenOptimizeSkill(BaseSkill):
    """Strip sensitive data from content before LLM consumption."""

    name = "token_optimize"
    description = (
        "Scan content for PII and credentials, return a redacted version "
        "safe for LLM consumption with token savings metrics. "
        "Reduces cost by stripping unnecessary sensitive data."
    )

    def schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "content": {
                    "type": "string",
                    "description": "Text content to optimize (strip sensitive data)",
                },
                "mode": {
                    "type": "string",
                    "enum": ["redact", "report_only"],
                    "description": "redact: return cleaned text, report_only: just report findings",
                    "default": "redact",
                },
            },
            "required": ["content"],
        }

    def execute(self, params: Dict[str, Any], context: Any) -> SkillResult:
        content = params.get("content", "")
        mode = params.get("mode", "redact")

        if not content:
            return SkillResult(
                status=SkillStatus.ALLOWED,
                data={"redacted_content": "", "findings": [], "savings_pct": 0},
            )

        original_tokens = _estimate_tokens(content)
        findings = []
        redacted = content

        # Apply all redaction patterns
        for pattern, label in _PATTERNS:
            redacted = _redact_pattern(redacted, pattern, label, findings)

        optimized_tokens = _estimate_tokens(redacted)
        chars_saved = sum(f["chars_removed"] for f in findings)
        savings_pct = round((1 - optimized_tokens / original_tokens) * 100, 1) if original_tokens > 0 else 0

        result_data = {
            "original_tokens": original_tokens,
            "optimized_tokens": optimized_tokens,
            "tokens_saved": original_tokens - optimized_tokens,
            "savings_pct": savings_pct,
            "chars_redacted": chars_saved,
            "findings_count": len(findings),
            "findings": findings,
        }

        if mode == "redact":
            result_data["redacted_content"] = redacted

        return SkillResult(
            status=SkillStatus.ALLOWED,
            data=result_data,
            findings=findings,
            metadata={"tokens_saved": original_tokens - optimized_tokens},
        )
