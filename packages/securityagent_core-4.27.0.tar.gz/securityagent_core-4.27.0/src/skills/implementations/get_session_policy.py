"""get_session_policy skill — returns current session's permission scope."""

import time
from typing import Any, Dict

from skills.base import BaseSkill, SkillResult, SkillStatus
from skills.context import SessionContext


class GetSessionPolicySkill(BaseSkill):
    name = "get_session_policy"
    description = "Retrieve the current session's security policy scope."

    def __init__(self, session_manager: "SessionManager"):
        self._session_mgr = session_manager

    def execute(self, params: Dict[str, Any], context: SessionContext) -> SkillResult:
        policy = self._session_mgr.get_policy(context.session_id)

        data = {
            "session_id": policy.session_id,
            "allowed_skills": sorted(policy.allowed_skills),
            "allowed_path_patterns": policy.allowed_path_patterns,
            "denied_path_patterns": policy.denied_path_patterns,
            "allowed_command_patterns": policy.allowed_command_patterns,
            "denied_command_patterns": policy.denied_command_patterns,
            "max_actions_per_minute": policy.max_actions_per_minute,
            "expires_at": policy.expires_at,
            "created_at": policy.created_at,
            "time_remaining": (
                max(0, policy.expires_at - time.time())
                if policy.expires_at
                else None
            ),
        }

        return SkillResult(status=SkillStatus.ALLOWED, data=data)

    def schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {},
            "description": "No parameters needed — returns current session policy.",
        }
