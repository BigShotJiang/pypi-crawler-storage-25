"""MCP (Model Context Protocol) server — stdio JSON-RPC transport.

This is the primary agent-agnostic interface. Any MCP-compatible client
(Claude Code, Copilot, custom agents) can connect to this server.

Usage:
    python -m skills.adapters.mcp_server
"""

import json
import sys
from typing import Any, Dict, Optional

from skills.context import SessionContext
from skills.registry import build_default_registry

_JSONRPC_VERSION = "2.0"
_MCP_PROTOCOL_VERSION = "2024-11-05"
_SERVER_NAME = "securityagent"
_SERVER_VERSION = "3.1.0"


class MCPServer:
    """Stdio-based MCP JSON-RPC server."""

    def __init__(self):
        self._registry = build_default_registry()
        self._context: Optional[SessionContext] = None
        self._initialized = False

    def run(self):
        """Main loop — read JSON-RPC requests from stdin, write responses to stdout."""
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
            except json.JSONDecodeError:
                self._write_error(None, -32700, "Parse error")
                continue

            response = self._handle(request)
            if response is not None:
                self._write(response)

    def _handle(self, request: Dict) -> Optional[Dict]:
        method = request.get("method", "")
        req_id = request.get("id")
        params = request.get("params", {})

        # Notifications (no id) don't get responses
        is_notification = req_id is None

        handler = {
            "initialize": self._handle_initialize,
            "initialized": self._handle_initialized,
            "tools/list": self._handle_tools_list,
            "tools/call": self._handle_tools_call,
            "ping": self._handle_ping,
        }.get(method)

        if handler is None:
            if is_notification:
                return None
            return self._error_response(req_id, -32601, f"Method not found: {method}")

        try:
            result = handler(params)
        except Exception as exc:
            if is_notification:
                return None
            return self._error_response(req_id, -32603, str(exc))

        if is_notification:
            return None
        return {"jsonrpc": _JSONRPC_VERSION, "id": req_id, "result": result}

    def _handle_initialize(self, params: Dict) -> Dict:
        client_info = params.get("clientInfo", {})
        agent_id = client_info.get("name", "unknown")
        agent_type = client_info.get("name", "mcp_client")

        self._context = SessionContext(agent_id=agent_id, agent_type=agent_type)
        SessionContext.set_current(self._context)

        return {
            "protocolVersion": _MCP_PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": {
                "name": _SERVER_NAME,
                "version": _SERVER_VERSION,
            },
        }

    def _handle_initialized(self, params: Dict) -> Dict:
        self._initialized = True
        return {}

    def _handle_tools_list(self, params: Dict) -> Dict:
        tools = []
        for name, info in self._registry.list_skills().items():
            tools.append(
                {
                    "name": info["name"],
                    "description": info["description"],
                    "inputSchema": info["inputSchema"],
                }
            )
        return {"tools": tools}

    def _handle_tools_call(self, params: Dict) -> Dict:
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        ctx = self._context or SessionContext.current()
        result = self._registry.invoke(tool_name, arguments, ctx)

        content = []
        if result.data is not None:
            content.append(
                {"type": "text", "text": result.data if isinstance(result.data, str) else json.dumps(result.data)}
            )
        if result.reason:
            content.append({"type": "text", "text": result.reason})
        if not content:
            content.append({"type": "text", "text": result.status.value})

        return {
            "content": content,
            "isError": result.status != "allowed" and result.exit_code != 0,
        }

    def _handle_ping(self, params: Dict) -> Dict:
        return {}

    def _write(self, response: Dict):
        sys.stdout.write(json.dumps(response) + "\n")
        sys.stdout.flush()

    def _write_error(self, req_id: Any, code: int, message: str):
        self._write(self._error_response(req_id, code, message))

    def _error_response(self, req_id: Any, code: int, message: str) -> Dict:
        return {
            "jsonrpc": _JSONRPC_VERSION,
            "id": req_id,
            "error": {"code": code, "message": message},
        }


def main():
    server = MCPServer()
    server.run()


if __name__ == "__main__":
    main()
