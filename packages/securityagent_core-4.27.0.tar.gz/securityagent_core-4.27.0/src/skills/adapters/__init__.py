"""Adapters for exposing skills to different agent runtimes."""
