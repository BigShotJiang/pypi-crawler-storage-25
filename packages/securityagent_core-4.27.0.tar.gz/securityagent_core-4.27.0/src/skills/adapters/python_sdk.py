"""Python SDK — direct-import interface for LangChain, Autogen, custom agents.

Usage:
    from skills.adapters.python_sdk import SecurityAgentSDK

    sdk = SecurityAgentSDK(agent_id="my-agent", agent_type="langchain")
    result = sdk.secure_read("/path/to/file")
    if result["status"] == "blocked":
        print(result["reason"])
"""

from typing import Any, Dict, Optional

from skills.base import SkillResult
from skills.context import SessionContext
from skills.registry import SkillRegistry, build_default_registry
from policy.engine import PolicyEngine


class SecurityAgentSDK:
    """Zero-dependency Python SDK for any agent to use SecurityAgent skills."""

    def __init__(
        self,
        agent_id: str = "python_sdk",
        agent_type: str = "python_sdk",
        registry: Optional[SkillRegistry] = None,
    ):
        self._registry = registry or build_default_registry()
        self._context = SessionContext(agent_id=agent_id, agent_type=agent_type)

    @property
    def session_id(self) -> str:
        return self._context.session_id

    @property
    def policy_engine(self) -> PolicyEngine:
        return self._registry.policy

    def _invoke(self, skill: str, params: Dict[str, Any]) -> Dict[str, Any]:
        result = self._registry.invoke(skill, params, self._context)
        return result.to_dict()

    def secure_read(self, path: str, offset: int = None, limit: int = None) -> Dict:
        params: Dict[str, Any] = {"path": path}
        if offset is not None:
            params["offset"] = offset
        if limit is not None:
            params["limit"] = limit
        return self._invoke("secure_read", params)

    def secure_exec(self, command: str) -> Dict:
        return self._invoke("secure_exec", {"command": command})

    def check_policy(self, skill: str, params: Optional[Dict] = None) -> Dict:
        return self._invoke("check_policy", {"skill": skill, "params": params or {}})

    def analyze_prompt(self, prompt: str) -> Dict:
        return self._invoke("analyze_prompt", {"prompt": prompt})

    def scan_output(self, content: str) -> Dict:
        return self._invoke("scan_output", {"content": content})

    def get_session_policy(self) -> Dict:
        return self._invoke("get_session_policy", {})

    def audit_log(
        self,
        session_id: str = None,
        agent_id: str = None,
        skill: str = None,
        limit: int = 100,
    ) -> Dict:
        params: Dict[str, Any] = {"limit": limit}
        if session_id:
            params["session_id"] = session_id
        if agent_id:
            params["agent_id"] = agent_id
        if skill:
            params["skill"] = skill
        return self._invoke("audit_log", params)
