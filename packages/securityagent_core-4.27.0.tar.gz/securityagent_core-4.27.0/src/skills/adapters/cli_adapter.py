"""CLI adapter — exposes skills as command-line subcommands.

Usage:
    plugin.py --skill <name> --params '<json>'

Maps SkillResult to the existing exit code protocol (0/1/2).
"""

import json
import sys
from typing import Dict, Optional

from skills.base import SkillResult
from skills.context import SessionContext
from skills.registry import build_default_registry


def run_skill(
    skill_name: str,
    params_json: str,
    agent_id: str = "cli",
    agent_type: str = "cli",
) -> SkillResult:
    """Execute a skill from CLI arguments and handle I/O."""
    try:
        params: Dict = json.loads(params_json) if params_json else {}
    except json.JSONDecodeError as exc:
        print(json.dumps({"error": f"Invalid JSON params: {exc}"}), file=sys.stderr)
        sys.exit(2)

    context = SessionContext(agent_id=agent_id, agent_type=agent_type)
    registry = build_default_registry()
    result = registry.invoke(skill_name, params, context)

    # Output follows existing convention: data on stdout, errors on stderr
    if result.data is not None:
        if isinstance(result.data, str):
            sys.stdout.write(result.data)
        else:
            print(json.dumps(result.data))

    if result.exit_code != 0:
        print(json.dumps(result.to_dict()), file=sys.stderr)

    return result
