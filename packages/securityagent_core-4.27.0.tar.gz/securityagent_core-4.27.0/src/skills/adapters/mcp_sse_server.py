"""MCP Security Server — SSE (Server-Sent Events) HTTP transport.

Exposes the same 9 security tools as the stdio server but over HTTP,
allowing remote MCP clients to connect.

Endpoints:
    GET  /sse          — SSE stream for server-to-client messages
    POST /message      — Client-to-server JSON-RPC requests
    GET  /health       — Health check

Usage:
    secagent mcp --transport sse --port 8765
"""

import json
import queue
import threading
import uuid
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Dict, Optional

from skills.adapters.mcp_server import MCPServer


class SSEHandler(BaseHTTPRequestHandler):
    """HTTP handler for MCP SSE transport."""

    # Shared state across requests (set by run_sse_server)
    mcp_server: MCPServer = None
    sse_queues: dict = {}  # client_id -> Queue
    lock: threading.Lock = None

    def log_message(self, format, *args):
        """Suppress default logging."""
        pass

    def do_GET(self):
        if self.path == "/sse":
            self._handle_sse()
        elif self.path == "/health":
            self._handle_health()
        elif self.path == "/":
            self._handle_info()
        else:
            self.send_error(404)

    def do_POST(self):
        if self.path == "/message":
            self._handle_message()
        else:
            self.send_error(404)

    def _handle_sse(self):
        """SSE stream — server pushes events to client."""
        client_id = str(uuid.uuid4())[:8]
        q = queue.Queue()

        with self.__class__.lock:
            self.__class__.sse_queues[client_id] = q

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        # Send endpoint event so client knows where to POST
        endpoint_event = f"event: endpoint\ndata: /message?client_id={client_id}\n\n"
        self.wfile.write(endpoint_event.encode())
        self.wfile.flush()

        try:
            while True:
                try:
                    msg = q.get(timeout=30)
                    if msg is None:
                        break
                    event_data = f"event: message\ndata: {json.dumps(msg)}\n\n"
                    self.wfile.write(event_data.encode())
                    self.wfile.flush()
                except queue.Empty:
                    # Send keepalive
                    self.wfile.write(b": keepalive\n\n")
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            with self.__class__.lock:
                self.__class__.sse_queues.pop(client_id, None)

    def _handle_message(self):
        """Handle JSON-RPC request from client."""
        # Extract client_id from query string
        client_id = None
        if "?" in self.path:
            params = dict(p.split("=") for p in self.path.split("?")[1].split("&") if "=" in p)
            client_id = params.get("client_id")

        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode()

        try:
            request = json.loads(body)
        except json.JSONDecodeError:
            self._send_json(400, {"error": "Invalid JSON"})
            return

        # Process through MCP server
        response = self.__class__.mcp_server._handle(request)

        if response is not None:
            # Send response back via SSE if client is connected
            if client_id and client_id in self.__class__.sse_queues:
                self.__class__.sse_queues[client_id].put(response)

            self._send_json(200, response)
        else:
            self._send_json(202, {"status": "accepted"})

    def _handle_health(self):
        """Health check endpoint."""
        tools = self.__class__.mcp_server._registry.list_skills()
        self._send_json(200, {
            "status": "healthy",
            "server": "securityagent-mcp",
            "version": "3.1.0",
            "tools": len(tools),
            "clients": len(self.__class__.sse_queues),
        })

    def _handle_info(self):
        """Server info page."""
        tools = self.__class__.mcp_server._registry.list_skills()
        tool_names = list(tools.keys())
        self._send_json(200, {
            "name": "SecureMind MCP Security Server",
            "version": "3.1.0",
            "protocol": "MCP 2024-11-05",
            "transport": "SSE",
            "tools": tool_names,
            "endpoints": {
                "sse": "GET /sse — SSE stream",
                "message": "POST /message — JSON-RPC requests",
                "health": "GET /health — Health check",
            },
        })

    def _send_json(self, code: int, data: dict):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())


def run_sse_server(port: int = 8765):
    """Start the SSE MCP server."""
    SSEHandler.mcp_server = MCPServer()
    SSEHandler.lock = threading.Lock()
    SSEHandler.sse_queues = {}

    server = HTTPServer(("0.0.0.0", port), SSEHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Server stopped.")
        server.server_close()
