"""Agent-agnostic security skills layer for SecurityAgent."""
