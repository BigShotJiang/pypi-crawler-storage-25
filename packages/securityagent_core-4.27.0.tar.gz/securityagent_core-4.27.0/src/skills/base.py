"""Base skill interface and result types."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class SkillStatus(Enum):
    ALLOWED = "allowed"
    BLOCKED = "blocked"
    ERROR = "error"


@dataclass
class SkillResult:
    """Standardized result returned by every skill invocation."""

    status: SkillStatus
    data: Any = None
    reason: Optional[str] = None
    findings: List[Dict] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def exit_code(self) -> int:
        """Map to the existing CLI exit code convention: 0=clean, 1=blocked, 2=error."""
        return {
            SkillStatus.ALLOWED: 0,
            SkillStatus.BLOCKED: 1,
            SkillStatus.ERROR: 2,
        }[self.status]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status.value,
            "data": self.data,
            "reason": self.reason,
            "findings": self.findings,
            "metadata": self.metadata,
        }


class BaseSkill(ABC):
    """Abstract base for all security skills."""

    name: str = ""
    description: str = ""

    @abstractmethod
    def execute(
        self, params: Dict[str, Any], context: "SessionContext"
    ) -> SkillResult:
        ...

    @abstractmethod
    def schema(self) -> Dict[str, Any]:
        """Return JSON Schema for parameters (MCP tool_input_schema format)."""
        ...
