"""Skill registry — central dispatch with policy gating and audit logging."""

from typing import Any, Dict, Optional

from skills.base import BaseSkill, SkillResult, SkillStatus
from skills.context import SessionContext
from policy.engine import PolicyEngine


class SkillRegistry:
    """Central registry and dispatch for all security skills.

    Flow per invocation:
    1. Pre-flight: PolicyEngine.evaluate()
    2. Execute: skill.execute(params, context)
    3. Record: context.record_action()
    4. Post-flight: ChainDetector.check()
    5. Audit: AuditTrail.log()
    """

    def __init__(self, policy_engine: Optional[PolicyEngine] = None):
        self._skills: Dict[str, BaseSkill] = {}
        self._policy = policy_engine or PolicyEngine()

    @property
    def policy(self) -> PolicyEngine:
        return self._policy

    def register(self, skill: BaseSkill):
        self._skills[skill.name] = skill

    def list_skills(self) -> Dict[str, Dict]:
        """Return JSON Schema for all registered skills (MCP tools/list format)."""
        return {
            name: {
                "name": skill.name,
                "description": skill.description,
                "inputSchema": skill.schema(),
            }
            for name, skill in self._skills.items()
        }

    def invoke(
        self,
        skill_name: str,
        params: Dict[str, Any],
        context: Optional[SessionContext] = None,
    ) -> SkillResult:
        context = context or SessionContext.current()

        if skill_name not in self._skills:
            result = SkillResult(
                status=SkillStatus.ERROR, reason=f"Unknown skill: {skill_name}"
            )
            self._policy.audit.log(skill_name, params, result, context)
            return result

        # Pre-flight policy check (skip for check_policy itself to avoid recursion)
        if skill_name != "check_policy":
            decision = self._policy.evaluate(skill_name, params, context)
            if not decision.allowed:
                result = SkillResult(
                    status=SkillStatus.BLOCKED,
                    reason=decision.reason,
                    metadata={"rule_name": decision.rule_name},
                )
                context.record_action(skill_name, params, result)
                self._policy.audit.log(skill_name, params, result, context)
                return result

        # Execute skill
        skill = self._skills[skill_name]
        result = skill.execute(params, context)

        # Record for behavioral chain detection
        context.record_action(skill_name, params, result)

        # Post-execution chain analysis
        chain_alert = self._policy.chain_detector.check(context)
        if chain_alert:
            result.metadata["chain_alert"] = {
                "pattern": chain_alert.pattern,
                "score": chain_alert.score,
                "description": chain_alert.description,
            }

        # Audit log
        self._policy.audit.log(skill_name, params, result, context)

        return result


def build_default_registry(policy_engine: Optional[PolicyEngine] = None) -> SkillRegistry:
    """Construct a registry with all default skills wired up."""
    engine = policy_engine or PolicyEngine()
    registry = SkillRegistry(policy_engine=engine)

    from skills.implementations.secure_read import SecureReadSkill
    from skills.implementations.secure_exec import SecureExecSkill
    from skills.implementations.analyze_prompt import AnalyzePromptSkill
    from skills.implementations.scan_output import ScanOutputSkill
    from skills.implementations.check_policy import CheckPolicySkill
    from skills.implementations.get_session_policy import GetSessionPolicySkill
    from skills.implementations.audit_log import AuditLogSkill
    from skills.implementations.token_optimize import TokenOptimizeSkill
    from skills.implementations.compliance_report import ComplianceReportSkill

    registry.register(SecureReadSkill())
    registry.register(SecureExecSkill())
    registry.register(AnalyzePromptSkill())
    registry.register(ScanOutputSkill())
    registry.register(CheckPolicySkill(policy_engine=engine))
    registry.register(GetSessionPolicySkill(session_manager=engine.session_mgr))
    registry.register(AuditLogSkill(audit_trail=engine.audit))
    registry.register(TokenOptimizeSkill())
    registry.register(ComplianceReportSkill())

    return registry
