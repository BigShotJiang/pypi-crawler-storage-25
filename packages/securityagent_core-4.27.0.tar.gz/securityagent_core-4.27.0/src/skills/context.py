"""Session context for tracing, attribution, and behavioral chain detection."""

import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

_thread_local = threading.local()


def _summarize_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Create a loggable summary of params (truncate long values)."""
    summary = {}
    for k, v in params.items():
        if isinstance(v, str) and len(v) > 200:
            summary[k] = v[:200] + "..."
        else:
            summary[k] = v
    return summary


@dataclass
class SessionContext:
    """Thread-local session context that flows through every skill invocation."""

    session_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    agent_id: str = "unknown"
    agent_type: str = "unknown"
    trace_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    created_at: float = field(default_factory=time.time)
    action_history: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def record_action(
        self, skill_name: str, params: Dict, result: "SkillResult"
    ):
        self.action_history.append(
            {
                "skill": skill_name,
                "params_summary": _summarize_params(params),
                "status": result.status.value,
                "timestamp": time.time(),
                "trace_id": self.trace_id,
            }
        )

    @classmethod
    def current(cls) -> "SessionContext":
        ctx = getattr(_thread_local, "session_context", None)
        if ctx is None:
            ctx = cls()
            _thread_local.session_context = ctx
        return ctx

    @classmethod
    def set_current(cls, ctx: "SessionContext"):
        _thread_local.session_context = ctx

    @classmethod
    def clear(cls):
        _thread_local.session_context = None
