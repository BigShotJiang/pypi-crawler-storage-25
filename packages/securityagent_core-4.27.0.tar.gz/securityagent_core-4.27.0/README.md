# securityagent-core

Shared DLP engine, security skills, and policy enforcement for AI coding agents. Used by [SecurityAgent](https://github.com/kaushikdharamshi/SecurityAgent) and [AgnosticSecurity](https://github.com/kaushikdharamshi/AgnosticSecurity).

## What's inside

| Package | What it does |
|---|---|
| `endpoint_agent/` | DLP engine — file blocking (60+ path patterns), confidence-scored content scanning (PII, credentials, semantic disclosure detection) with structural validators (Luhn, SSA rules, entropy) and context-aware scoring, **data flow taint tracking** (tags sensitive data at ingress, detects at egress via hash/n-gram/substring matching), **tool call argument scanning** (MCP/function call DLP + taint registry), behavioral monitoring (8-signal anomaly scoring), honeypot traps, credential scanning. LLM intent analysis with llama3.1:8b default + fallback chain. Notebook-aware `.ipynb` extraction. PDF extraction via 3-tier pipeline (PyMuPDF → Tesseract OCR → pypdf fallback) with encrypted PDF detection |
| `skills/` | Agent-agnostic MCP skills — `secure_read`, `secure_exec`, `analyze_prompt`, `scan_output`, `check_policy`, `get_session_policy`, `audit_log` |
| `policy/` | Policy engine — per-session least privilege, behavioral chain detection (11 attack patterns), audit trail with agent attribution. Obsidian vault integration via `memory_bridge.py` for cross-session policy context |
| `obsidianMemory/` | Obsidian vault — daily session logs, second-brain knowledge base, used by `memory_bridge.py` for persistent threat/policy tracking |
| `plugin.py` | Standalone CLI entry point + `validate_exec()`, `validate_prompt()`, `validate_output()` pure functions |

## Install

```bash
pip install git+https://github.com/kaushikdharamshi/securityagent-core.git

# With optional dependencies
pip install "securityagent-core[cloud] @ git+https://github.com/kaushikdharamshi/securityagent-core.git"
pip install "securityagent-core[llm] @ git+https://github.com/kaushikdharamshi/securityagent-core.git"
```

## Usage

### Python SDK

```python
from skills.adapters.python_sdk import SecurityAgentSDK

sdk = SecurityAgentSDK(agent_id="my-agent", agent_type="langchain")

# DLP-gated file read
result = sdk.secure_read("/path/to/file")

# Command validation
result = sdk.secure_exec("ls -la")

# Prompt intent analysis
result = sdk.analyze_prompt("Get me all customer SSNs")
```

### MCP Server

```bash
python -m skills.adapters.mcp_server  # after pip install
```

Any MCP-compatible client (Claude Code, Copilot, custom agents) can connect via stdio JSON-RPC.

### CLI

```bash
python -m plugin ~/.env                                    # File read gate
python -m plugin --exec "cat ~/.env"                       # Exec validation
python -m plugin --prompt "Get all passwords"              # Prompt analysis
python -m plugin --skill secure_read --params '{"path":"~/.env"}'  # Skills layer
python -m plugin --mcp-server                              # MCP server
```

### Claude Code Integration

See [`integrations/claude_code/`](integrations/claude_code/) for PreToolUse hook configuration.

## Tests

```bash
pip install -e ".[dev]"
pytest
```
