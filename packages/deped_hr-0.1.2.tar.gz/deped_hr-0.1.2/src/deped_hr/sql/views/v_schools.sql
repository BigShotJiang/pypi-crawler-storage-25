CREATE VIEW v_schools AS
SELECT * FROM entities WHERE entity_type = 'SCHOOL';
