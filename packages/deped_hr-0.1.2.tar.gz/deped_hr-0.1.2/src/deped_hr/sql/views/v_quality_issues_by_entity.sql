CREATE VIEW v_quality_issues_by_entity AS
SELECT e.entity_id, e.entity_type, e.entity_name, e.region, e.division,
       'missing_employee_id' AS issue_type,
       SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'missing_employee_id') > 0 THEN 1 ELSE 0 END) AS issue_count
FROM entities e JOIN personnel p ON p.entity_id = e.entity_id
GROUP BY e.entity_id, e.entity_type, e.entity_name, e.region, e.division
HAVING SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'missing_employee_id') > 0 THEN 1 ELSE 0 END) > 0
UNION ALL
SELECT e.entity_id, e.entity_type, e.entity_name, e.region, e.division,
       'phone_scientific',
       SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'phone_scientific') > 0 THEN 1 ELSE 0 END)
FROM entities e JOIN personnel p ON p.entity_id = e.entity_id
GROUP BY e.entity_id, e.entity_type, e.entity_name, e.region, e.division
HAVING SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'phone_scientific') > 0 THEN 1 ELSE 0 END) > 0
UNION ALL
SELECT e.entity_id, e.entity_type, e.entity_name, e.region, e.division,
       'unmapped_position',
       SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'unmapped_position') > 0 THEN 1 ELSE 0 END)
FROM entities e JOIN personnel p ON p.entity_id = e.entity_id
GROUP BY e.entity_id, e.entity_type, e.entity_name, e.region, e.division
HAVING SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'unmapped_position') > 0 THEN 1 ELSE 0 END) > 0
UNION ALL
SELECT e.entity_id, e.entity_type, e.entity_name, e.region, e.division,
       'invalid_position',
       SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'invalid_position') > 0 THEN 1 ELSE 0 END)
FROM entities e JOIN personnel p ON p.entity_id = e.entity_id
GROUP BY e.entity_id, e.entity_type, e.entity_name, e.region, e.division
HAVING SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'invalid_position') > 0 THEN 1 ELSE 0 END) > 0
UNION ALL
SELECT e.entity_id, e.entity_type, e.entity_name, e.region, e.division,
       'invalid_date',
       SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'invalid_date') > 0 THEN 1 ELSE 0 END)
FROM entities e JOIN personnel p ON p.entity_id = e.entity_id
GROUP BY e.entity_id, e.entity_type, e.entity_name, e.region, e.division
HAVING SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'invalid_date') > 0 THEN 1 ELSE 0 END) > 0
UNION ALL
SELECT e.entity_id, e.entity_type, e.entity_name, e.region, e.division,
       'bad_email_domain',
       SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'bad_email_domain') > 0 THEN 1 ELSE 0 END)
FROM entities e JOIN personnel p ON p.entity_id = e.entity_id
GROUP BY e.entity_id, e.entity_type, e.entity_name, e.region, e.division
HAVING SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'bad_email_domain') > 0 THEN 1 ELSE 0 END) > 0
UNION ALL
SELECT e.entity_id, e.entity_type, e.entity_name, e.region, e.division,
       'invalid_email',
       SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'invalid_email') > 0 THEN 1 ELSE 0 END)
FROM entities e JOIN personnel p ON p.entity_id = e.entity_id
GROUP BY e.entity_id, e.entity_type, e.entity_name, e.region, e.division
HAVING SUM(CASE WHEN instr(COALESCE(p.data_quality_flags, ''), 'invalid_email') > 0 THEN 1 ELSE 0 END) > 0;
