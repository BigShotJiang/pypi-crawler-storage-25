CREATE VIEW v_office_personnel_summary AS
SELECT
    e.entity_type,
    e.region,
    e.division,
    COALESCE(p.sdo_office, p.ro_office) AS office_unit_name,
    COUNT(*) AS personnel_count
FROM personnel p
JOIN entities e ON e.entity_id = p.entity_id
WHERE e.entity_type != 'SCHOOL'
GROUP BY e.entity_type, e.region, e.division, COALESCE(p.sdo_office, p.ro_office);
