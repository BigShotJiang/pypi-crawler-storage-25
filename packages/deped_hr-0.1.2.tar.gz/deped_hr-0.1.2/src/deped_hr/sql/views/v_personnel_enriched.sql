CREATE VIEW v_personnel_enriched AS
SELECT
    p.*,
    e.entity_type,
    e.entity_name,
    e.region,
    e.division,
    pt.canonical_name AS position_title,
    pt.category AS position_category
FROM personnel p
JOIN entities e ON e.entity_id = p.entity_id
LEFT JOIN position_titles pt ON pt.id = p.position_title_id;
