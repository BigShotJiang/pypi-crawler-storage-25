CREATE VIEW v_personnel_per_school AS
SELECT
    e.entity_id,
    e.school_id,
    e.entity_name AS school_name,
    e.region,
    e.division,
    COUNT(*) AS total_personnel,
    SUM(CASE WHEN pt.category = 'TEACHING' THEN 1 ELSE 0 END) AS teaching_count,
    SUM(CASE WHEN pt.category = 'TEACHING_RELATED' THEN 1 ELSE 0 END) AS teaching_related_count,
    SUM(CASE WHEN pt.category = 'NON_TEACHING' THEN 1 ELSE 0 END) AS non_teaching_count,
    SUM(CASE WHEN p.is_inactive = 1 THEN 1 ELSE 0 END) AS inactive_count,
    SUM(CASE WHEN p.is_duplicate_employee_id = 1 THEN 1 ELSE 0 END) AS duplicate_count
FROM personnel p
JOIN entities e ON e.entity_id = p.entity_id
LEFT JOIN position_titles pt ON pt.id = p.position_title_id
WHERE e.entity_type = 'SCHOOL'
GROUP BY e.entity_id, e.school_id, e.entity_name, e.region, e.division;
