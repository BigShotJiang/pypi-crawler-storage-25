CREATE VIEW v_personnel_by_position_type AS
SELECT
    e.region,
    pt.canonical_name AS position_title,
    pt.category,
    COUNT(*) AS active_headcount
FROM personnel p
JOIN entities e ON e.entity_id = p.entity_id
JOIN position_titles pt ON pt.id = p.position_title_id
WHERE p.is_inactive = 0
GROUP BY e.region, pt.canonical_name, pt.category;
