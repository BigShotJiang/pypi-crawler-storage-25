CREATE INDEX idx_personnel_entity ON personnel(entity_id);
CREATE INDEX idx_personnel_school ON personnel(school_id);
CREATE INDEX idx_personnel_employee_id ON personnel(employee_id);
CREATE INDEX idx_personnel_position ON personnel(position_title_id);
CREATE INDEX idx_personnel_inactive ON personnel(is_inactive);
CREATE INDEX idx_personnel_duplicate ON personnel(is_duplicate_employee_id);
