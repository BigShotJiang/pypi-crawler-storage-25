"""Normalization helpers for personnel source fields."""

from __future__ import annotations

import re

from deped_dcp_template.cleaners import clean_text, position_issue

_TRANSFER_VALUES = {
    "transfer",
    "transferred",
    "transferred out",
    "transferred to",
    "transfer of station",
    "transfer station",
    "transferred of service",
    "transfer in",
}
_RETIREMENT_VALUES = {
    "retirement",
    "retired",
    "early retirement",
    "mandatory retirement",
    "disability retirement",
    "diability retirment under ra 8291",
}
_RESIGNATION_VALUES = {
    "resignation",
    "work abroad",
    "overseas work",
    "change of residence",
}
_END_OF_CONTRACT_VALUES = {
    "expiration of appointment or contract",
    "expiration of appoinment or contract",
    "expiration of contract",
    "contract ended",
    "end of contract",
}
_TERMINATION_APPOINTMENT_VALUES = {
    "termination of temporary appointment",
    "termination of appointment",
}
_PLACEHOLDER_VALUES = {"0", "not applicable", "n.a", r"n\a", "`"}
_REVIEW_REQUIRED_VALUES = {
    "dropping from the rolls",
    "promotion",
    "maternity leave",
    "sick leave",
    "sick leave and then retire",
    "incomplete abortion leave",
    "on-leave",
    "residency",
    "reassigned",
    "newly hired",
    "swapping",
}
_MISFILED_VALUE_PATTERNS = (
    re.compile(r"\bschool\b", re.IGNORECASE),
    re.compile(r"\bnational high school\b", re.IGNORECASE),
    re.compile(r"\bintegrated school\b", re.IGNORECASE),
)
_SCHOOL_HEAD_POSITION_PATTERNS = (
    re.compile(r"\bhead teacher\b", re.IGNORECASE),
    re.compile(r"\bprincipal\b", re.IGNORECASE),
    re.compile(r"\bschool head\b", re.IGNORECASE),
)
_SOURCE_OF_FUNDS_SEF_PATTERNS = (
    re.compile(r"\bsef\b", re.IGNORECASE),
    re.compile(r"special education fund", re.IGNORECASE),
    re.compile(r"local school board", re.IGNORECASE),
    re.compile(r"\blsb\b", re.IGNORECASE),
    re.compile(r"school board", re.IGNORECASE),
)
_VALID_RO_OFFICES = {
    "Administrative Division",
    "Curriculum and Learning Management Division",
    "Education Support Services Division",
    "Field Technical Assistance Division",
    "Finance Division",
    "Human Resource Development Division",
    "ICT Unit",
    "Legal Unit",
    "Office of the Assistant Regional Director",
    "Office of the Regional Director Proper",
    "Policy, Planning and Research Division",
    "Public Affairs Unit",
    "Quality Assurance Division",
}
_VALID_SDO_OFFICES = {
    "Office of the Schools Division Superintendent",
    "Office of the Assistant Schools Division Superintendent",
    "Legal Services",
    "Administrative Services",
    "Finance Services",
    "ICT Services",
    "Curriculum Implementation Division",
    "Schools Governance and Operations Division",
}
_RO_OFFICE_ALIASES = {
    "ADMINISTRATIVE DIVISION": "Administrative Division",
    "CURRICULUM AND LEARNING MANAGEMENT DIVISION": "Curriculum and Learning Management Division",
    "EDUCATION SUPPORT SERVICES DIVISION": "Education Support Services Division",
    "FIELD TECHNICAL ASSISTANCE DIVISION": "Field Technical Assistance Division",
    "FINANCE DIVISION": "Finance Division",
    "HRDD": "Human Resource Development Division",
    "HUMAN RESOURCE DEVELOPMENT DIVISION": "Human Resource Development Division",
    "ICT UNIT": "ICT Unit",
    "LEGAL UNIT": "Legal Unit",
    "OFFICE OF THE ASSISTANT REGIONAL DIRECTOR": "Office of the Assistant Regional Director",
    "CHIEF EDUCATION SUPERVISOR-CONCURRENT OIC, OFFICE OF THE ASSISTANT REGIONAL DIRECTOR": "Office of the Assistant Regional Director",
    "OFFICE OF THE REGIONAL DIRECTOR": "Office of the Regional Director Proper",
    "OFFICE OF THE REGIONAL DIRECTOR PROPER": "Office of the Regional Director Proper",
    "ORD": "Office of the Regional Director Proper",
    "POLICY, PLANNING AND RESEARCH DIVISION": "Policy, Planning and Research Division",
    "PUBLIC AFFAIRS UNIT": "Public Affairs Unit",
    "QUALITY ASSURANCE DIVISION": "Quality Assurance Division",
}
_RO_OFFICE_PREFIX_ALIASES = (
    ("ADMINISTRATIVE DIVISION-", "Administrative Division"),
    ("OFFICE OF THE REGIONAL DIRECTOR-", "Office of the Regional Director Proper"),
)
_SDO_OFFICE_ALIASES = {
    "OFFICE OF THE SCHOOLS DIVISION SUPERINTENDENT": "Office of the Schools Division Superintendent",
    "OFFICE OF THE SCHOOL DIVISION SUPERINTENDENT": "Office of the Schools Division Superintendent",
    "OFFICE OF THE SDS": "Office of the Schools Division Superintendent",
    "SDS": "Office of the Schools Division Superintendent",
    "OSDS": "Office of the Schools Division Superintendent",
    "OFFICE OF THE ASSISTANT SCHOOLS DIVISION SUPERINTENDENT": "Office of the Assistant Schools Division Superintendent",
    "OFFICE OF THE ASDS": "Office of the Assistant Schools Division Superintendent",
    "ASDS": "Office of the Assistant Schools Division Superintendent",
    "LEGAL SERVICES": "Legal Services",
    "LEGAL UNIT": "Legal Services",
    "LEGAL AFFAIRS": "Legal Services",
    "ADMINISTRATIVE SERVICES": "Administrative Services",
    "ADMIN. SERVICES": "Administrative Services",
    "ADMIN SERVICES": "Administrative Services",
    "FINANCE SERVICES": "Finance Services",
    "FINANCE": "Finance Services",
    "ICT SERVICES": "ICT Services",
    "ICT UNIT": "ICT Services",
    "INFORMATION AND COMMUNICATION TECHNOLOGY UNIT": "ICT Services",
    "CURRICULUM IMPLEMENTATION DIVISION": "Curriculum Implementation Division",
    "CID": "Curriculum Implementation Division",
    "SCHOOLS GOVERNANCE AND OPERATIONS DIVISION": "Schools Governance and Operations Division",
    "SCHOOL GOVERNANCE AND OPERATIONS DIVISION": "Schools Governance and Operations Division",
    "SCHOOLS GOVERNANCE AND OPERATIONAL DIVISION": "Schools Governance and Operations Division",
    "SGOD": "Schools Governance and Operations Division",
}
_SDO_OFFICE_PREFIX_ALIASES = (
    ("ADMINISTRATIVE SERVICES-", "Administrative Services"),
    ("ADMINISTRATIVE SERVICES ", "Administrative Services"),
)
_CANONICAL_CAUSE_MAP = {
    **dict.fromkeys(_TRANSFER_VALUES, "TRANSFER"),
    **dict.fromkeys(_RETIREMENT_VALUES, "RETIREMENT"),
    **dict.fromkeys(_RESIGNATION_VALUES, "RESIGNATION"),
    "death": "DEATH",
    **dict.fromkeys(_END_OF_CONTRACT_VALUES, "END_OF_CONTRACT"),
    **dict.fromkeys(_TERMINATION_APPOINTMENT_VALUES, "TERMINATION_APPOINTMENT"),
    "dismissal or removal for cause": "DISMISSAL_FOR_CAUSE",
    "abolition of office / reorganization": "ABOLITION_REORGANIZATION",
}


def _normalize_oic_key(value: str | None) -> str | None:
    cleaned = clean_text(value)
    if cleaned is None:
        return None
    return re.sub(r"[^A-Z]", "", cleaned.upper())


def _is_school_head_position(position_raw: str | None) -> bool:
    if position_raw is None:
        return False
    return any(
        pattern.search(position_raw) for pattern in _SCHOOL_HEAD_POSITION_PATTERNS
    )


def normalize_oic_designation(
    position_raw: str | None,
    is_officer_in_charge: int | None,
    raw_designation: str | None,
) -> str | None:
    """Normalize OIC designation to the allowed canonical labels only."""
    if is_officer_in_charge != 1:
        return None

    designation_key = _normalize_oic_key(raw_designation)
    if designation_key is None:
        return None
    if designation_key in {"TEACHERINCHARGE", "TIC"}:
        return "Teacher-In-Charge"
    if designation_key == "SCHOOLHEAD" and not _is_school_head_position(position_raw):
        return "School Head"
    return None


def normalize_source_of_funds(
    is_non_deped_funded: int | None, raw_value: str | None
) -> str | None:
    """Normalize source of funds to the approved canonical labels only."""
    if is_non_deped_funded != 1:
        return None

    cleaned = clean_text(raw_value)
    if cleaned is None:
        return None

    source_upper = cleaned.upper()
    if "NOT APPLICABLE" in source_upper:
        return "Not Applicable"
    if "MOOE" in source_upper:
        return "Maintenance and Other Operating Expenses (MOOE)"
    if any(pattern.search(cleaned) for pattern in _SOURCE_OF_FUNDS_SEF_PATTERNS):
        return "Special Education Fund (SEF)"
    if "GENERAL FUND" in source_upper or "MUNICIPAL FUND" in source_upper:
        return "General Fund (GF)"
    if "TRUST" in source_upper:
        return "Trust Fund (TF)"
    if "PROGRAM SUPPORT" in source_upper or re.search(
        r"\bPSF\b", cleaned, re.IGNORECASE
    ):
        return "Program Support Fund (PSF)"
    if "CAPITAL OUTLAY" in source_upper or source_upper == "CO":
        return "Capital Outlay (CO)"
    return None


def _normalize_office_name(
    raw_value: str | None,
    valid_values: set[str],
    aliases: dict[str, str],
    prefix_aliases: tuple[tuple[str, str], ...],
) -> str | None:
    cleaned = clean_text(raw_value)
    if cleaned is None:
        return None
    if cleaned in valid_values:
        return cleaned

    office_key = " ".join(cleaned.upper().split())
    alias = aliases.get(office_key)
    if alias is not None:
        return alias
    for prefix, canonical in prefix_aliases:
        if office_key.startswith(prefix):
            return canonical
    return None


def normalize_ro_office(raw_value: str | None) -> str | None:
    """Normalize RO office to the approved canonical labels only."""
    return _normalize_office_name(
        raw_value,
        _VALID_RO_OFFICES,
        _RO_OFFICE_ALIASES,
        _RO_OFFICE_PREFIX_ALIASES,
    )


def normalize_sdo_office(raw_value: str | None) -> str | None:
    """Normalize SDO office to the approved canonical labels only."""
    return _normalize_office_name(
        raw_value,
        _VALID_SDO_OFFICES,
        _SDO_OFFICE_ALIASES,
        _SDO_OFFICE_PREFIX_ALIASES,
    )


def _review_required_reason(cause_key: str) -> str | None:
    if cause_key in _REVIEW_REQUIRED_VALUES:
        return None
    if cause_key == "s":
        return "uninterpretable single-character value"
    return None


def _misfiled_reason(cleaned_raw: str, cause_key: str) -> str | None:
    if cause_key.isdigit():
        return "numeric identifier stored in separation field"
    if position_issue(cleaned_raw)[0] is not None:
        return "position title stored in separation field"
    if any(pattern.search(cleaned_raw) for pattern in _MISFILED_VALUE_PATTERNS):
        return "location or school name stored in separation field"
    if len(cleaned_raw.split()) >= 5:
        return "free-text note stored in separation field"
    return None


def _normalize_cause_key(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = clean_text(value)
    if cleaned is None:
        return None
    return " ".join(cleaned.casefold().split())


def normalize_cause_of_separation(
    raw_value: str | None,
) -> tuple[str | None, str | None, str | None]:
    """Return normalized code, quality classification, and optional note."""
    cause_key = _normalize_cause_key(raw_value)
    cleaned_raw = clean_text(raw_value)
    if cause_key is None or cleaned_raw is None:
        return None, None, None

    if cause_key in _CANONICAL_CAUSE_MAP:
        return _CANONICAL_CAUSE_MAP[cause_key], None, None
    if cause_key == "detailed":
        return None, "NOT_SEPARATED", "assignment status stored in separation field"
    if cause_key in _PLACEHOLDER_VALUES:
        return None, "UNKNOWN_PLACEHOLDER", None
    review_reason = _review_required_reason(cause_key)
    if review_reason is not None or cause_key in _REVIEW_REQUIRED_VALUES:
        return None, "REVIEW_REQUIRED", review_reason
    misfiled_reason = _misfiled_reason(cleaned_raw, cause_key)
    if misfiled_reason is not None:
        return None, "MISFILED_SOURCE_VALUE", misfiled_reason
    return None, "REVIEW_REQUIRED", "unmapped separation cause"
