"""Public personnel API."""

from __future__ import annotations

from .personnel_loader import load_personnel
from .personnel_normalization import (
    normalize_cause_of_separation,
    normalize_oic_designation,
    normalize_ro_office,
    normalize_sdo_office,
    normalize_source_of_funds,
)

__all__ = [
    "load_personnel",
    "normalize_cause_of_separation",
    "normalize_oic_designation",
    "normalize_ro_office",
    "normalize_sdo_office",
    "normalize_source_of_funds",
]
