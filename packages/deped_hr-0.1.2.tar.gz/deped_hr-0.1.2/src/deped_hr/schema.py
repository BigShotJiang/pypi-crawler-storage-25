from __future__ import annotations

import csv
import sqlite3
from contextlib import closing
from hashlib import sha256
from importlib.resources import files
from importlib.resources.abc import Traversable
from pathlib import Path

from deped_dcp_template.constants import (
    POSITION_CANONICAL,
    SCHEMA_VERSION,
    replace_position_catalog,
)

from .types import PositionCatalog, PositionLookup, SQLiteConnection

_SQL: Traversable = files("deped_hr.sql")


def _read_sql(name: str) -> str:
    return _SQL.joinpath(name).read_text()


def create_schema(conn: SQLiteConnection) -> None:
    conn.executescript(_read_sql("pragmas.sql"))
    for filename in (
        "tables/entities.sql",
        "tables/entity_aliases.sql",
        "tables/personnel.sql",
        "tables/position_titles.sql",
        "tables/date_parse_errors.sql",
        "tables/build_runs.sql",
    ):
        conn.executescript(_read_sql(filename))


def create_indexes(conn: SQLiteConnection) -> None:
    for filename in ("indexes/entities.sql", "indexes/personnel.sql"):
        conn.executescript(_read_sql(filename))


def create_views(conn: SQLiteConnection) -> None:
    for filename in (
        "views/v_schools.sql",
        "views/v_personnel_enriched.sql",
        "views/v_personnel_per_school.sql",
        "views/v_personnel_by_position_type.sql",
        "views/v_quality_issues_by_entity.sql",
        "views/v_office_personnel_summary.sql",
    ):
        conn.executescript(_read_sql(filename))


def load_position_catalog(lookups_db: str | Path) -> PositionCatalog:
    with closing(sqlite3.connect(lookups_db)) as lookup_conn:
        rows: list[tuple[str, str]] = lookup_conn.execute(
            "SELECT canonical_name, category FROM positions ORDER BY canonical_name"
        ).fetchall()
    normalized_rows: list[tuple[str, str]] = [
        (canonical_name, POSITION_CANONICAL.get(canonical_name, category))
        for canonical_name, category in rows
    ]
    replace_position_catalog(normalized_rows)
    return dict(normalized_rows)


def seed_position_titles(
    conn: SQLiteConnection, lookups_db: str | Path
) -> PositionLookup:
    catalog = load_position_catalog(lookups_db)
    conn.executemany(
        "INSERT INTO position_titles(canonical_name, category) VALUES (?, ?)",
        sorted(catalog.items()),
    )
    position_lookup: PositionLookup = {
        name: row_id
        for row_id, name in conn.execute(
            "SELECT id, canonical_name FROM position_titles"
        )
    }
    return position_lookup


def start_build_run(
    conn: SQLiteConnection, personnel_path: str | Path, lookups_path: str | Path
) -> int:
    personnel_path = Path(personnel_path)
    lookups_path = Path(lookups_path)
    personnel_hash = sha256(personnel_path.read_bytes()).hexdigest()
    lookups_hash = sha256(lookups_path.read_bytes()).hexdigest()
    with open(personnel_path, "r", encoding="utf-8-sig", newline="") as handle:
        personnel_rows = sum(1 for _ in csv.DictReader(handle))
    _sql = """--sql
        INSERT INTO build_runs(
            build_type, started_at, schema_version,
            lookups_source_file, lookups_source_hash,
            personnel_source_file, personnel_source_hash, personnel_source_rows
        ) VALUES (?, datetime('now'), ?, ?, ?, ?, ?, ?);
        """
    cursor = conn.execute(
        _sql,
        (
            "full_rebuild",
            SCHEMA_VERSION,
            lookups_path.name,
            lookups_hash,
            personnel_path.name,
            personnel_hash,
            personnel_rows,
        ),
    )
    conn.commit()
    if (v := cursor.lastrowid) is None:
        raise RuntimeError("Failed to create build run record")
    return int(v)


def complete_build_run(conn: SQLiteConnection, build_run_id: int) -> None:
    conn.execute(
        """--sql
        UPDATE build_runs
        SET completed_at = datetime('now'),
            entity_count = (SELECT COUNT(*) FROM entities),
            personnel_count = (SELECT COUNT(*) FROM personnel)
        WHERE id = ?;
        """,
        (build_run_id,),
    )
    conn.commit()
