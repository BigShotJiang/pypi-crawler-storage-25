"""Entity extraction and natural-key logic."""

from __future__ import annotations

import sqlite3
from collections import Counter
from collections.abc import Iterable
from pathlib import Path
from typing import cast

from deped_dcp_template.cleaners import clean_text, normalize_school_id
from deped_dcp_template.entities import (
    build_natural_key,
    choose_preferred_text,
    derive_entity_name,
    determine_entity_type,
)
from deped_dcp_template.io import iter_csv_rows
from rich.progress import Progress, TaskID

from .types import (
    AliasInsertRow,
    CsvRow,
    EntityAccumulator,
    EntityInsertRow,
    EntityLookup,
    EntityRecord,
)


def build_entity_record(row: CsvRow) -> EntityRecord:
    """Build the entity attributes for one source row."""
    entity_type: str = determine_entity_type(row.get("Governance Level"))
    school_id: int | None = normalize_school_id(row.get("School ID"))
    region: str | None = clean_text(row.get("Region"))
    division: str | None = clean_text(row.get("Division"))
    school_name: str | None = clean_text(row.get("School Name"))
    natural_key: str = build_natural_key(entity_type, school_id, region, division)
    entity_name: str | None = derive_entity_name(
        entity_type, school_name, region, division
    )
    return {
        "entity_type": entity_type,
        "school_id": school_id,
        "entity_name": entity_name,
        "region": region,
        "division": division,
        "natural_key": natural_key,
        "has_personnel": 1,
    }


def load_entities(
    conn: sqlite3.Connection,
    personnel_path: str | Path,
    progress: Progress | None = None,
) -> EntityLookup:
    """Extract unique entities from the personnel source and persist them."""
    accumulators: dict[str, EntityAccumulator] = {}
    task_id: TaskID | None = None
    if progress is not None:
        task_id = progress.add_task(
            f"Scan entities: {Path(personnel_path).name} (0 rows)",
            total=Path(personnel_path).stat().st_size,
        )
    csv_rows = cast(
        Iterable[tuple[int, CsvRow]], iter_csv_rows(personnel_path, progress, task_id)
    )
    for _, row in csv_rows:
        entity = build_entity_record(row)
        natural_key: str = entity["natural_key"]
        acc = accumulators.get(natural_key)
        if acc is None:
            acc = {
                "entity_type": entity["entity_type"],
                "school_id": entity["school_id"],
                "region": entity["region"],
                "division": entity["division"],
                "entity_name_counts": Counter(),
                "has_personnel": 1,
            }
            accumulators[natural_key] = acc  # type: ignore
        acc["entity_name_counts"][str(entity["entity_name"])] += 1
    if progress is not None and task_id is not None:
        progress.update(task_id, completed=Path(personnel_path).stat().st_size)

    rows: list[EntityInsertRow] = []
    for natural_key, acc in accumulators.items():
        rows.append(
            (
                acc["entity_type"],
                acc["school_id"],
                choose_preferred_text(acc["entity_name_counts"]),
                acc["region"],
                acc["division"],
                acc["has_personnel"],
                natural_key,
            )
        )

    conn.executemany(
        """--sql
        INSERT INTO entities(
            entity_type, school_id, entity_name, region, division,
            has_personnel, natural_key
        ) VALUES (?, ?, ?, ?, ?, ?, ?);
        """,
        rows,
    )
    entity_lookup: EntityLookup = {
        natural_key: entity_id
        for entity_id, natural_key in conn.execute(
            "SELECT entity_id, natural_key FROM entities"
        )
    }
    alias_rows: list[AliasInsertRow] = []
    for natural_key, acc in accumulators.items():
        entity_id = entity_lookup[natural_key]
        for alias_name in acc["entity_name_counts"]:
            alias_rows.append((entity_id, alias_name))
    if alias_rows:
        conn.executemany(
            "INSERT OR IGNORE INTO entity_aliases(entity_id, alias_name) VALUES (?, ?)",
            alias_rows,
        )
    return entity_lookup
