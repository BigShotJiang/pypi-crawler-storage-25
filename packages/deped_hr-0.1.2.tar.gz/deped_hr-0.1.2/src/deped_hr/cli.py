from __future__ import annotations

import sqlite3
from collections import Counter
from contextlib import closing
from pathlib import Path

import click
from rich.console import Console
from rich.progress import Progress

from .entities import load_entities
from .personnel import load_personnel
from .schema import (
    complete_build_run,
    create_indexes,
    create_schema,
    create_views,
    seed_position_titles,
    start_build_run,
)

CONSOLE = Console(stderr=True)


def write_unmapped_positions(
    path: str | Path, unmapped_positions: Counter[str]
) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        for position, count in unmapped_positions.most_common():
            handle.write(f"{count}\t{position}\n")


def prepare_output_db(db_path: str | Path) -> None:
    base = Path(db_path)
    for suffix in ("", "-wal", "-shm"):
        candidate = Path(f"{base}{suffix}")
        if candidate.exists():
            candidate.unlink()


def build_personnel_db(
    personnel_path: str | Path,
    lookups_path: str | Path,
    db_path: str | Path,
) -> None:
    with CONSOLE.status("Preparing personnel build...", spinner="dots"):
        prepare_output_db(db_path)
        with closing(sqlite3.connect(db_path)) as conn:
            create_schema(conn)
            build_run_id = start_build_run(conn, personnel_path, lookups_path)
            position_lookup = seed_position_titles(conn, lookups_path)
            progress = Progress(console=CONSOLE)
            with progress:
                entity_lookup = load_entities(
                    conn,
                    personnel_path=personnel_path,
                    progress=progress,
                )
                unmapped_positions = load_personnel(
                    conn,
                    personnel_path,
                    entity_lookup,
                    position_lookup,
                    progress,
                )
            with CONSOLE.status("Finalizing personnel build...", spinner="dots"):
                create_indexes(conn)
                create_views(conn)
                complete_build_run(conn, build_run_id)
                write_unmapped_positions(
                    Path(db_path).with_name("unmapped_positions.txt"),
                    unmapped_positions,
                )


@click.group()
def main() -> None:
    """Personnel database utilities."""


@main.command("build")
@click.option(
    "--personnel", required=True, type=click.Path(exists=True, dir_okay=False)
)
@click.option("--lookups", required=True, type=click.Path(exists=True, dir_okay=False))
@click.option("--db", "db_path", required=True, type=click.Path(dir_okay=False))
def build_command(personnel: str, lookups: str, db_path: str) -> None:
    build_personnel_db(personnel, lookups, db_path)
    click.echo(db_path)


@main.command("audit")
@click.option(
    "--db", "db_path", required=True, type=click.Path(exists=True, dir_okay=False)
)
def audit_command(db_path: str) -> None:
    with CONSOLE.status("Auditing personnel database...", spinner="dots"):
        with closing(sqlite3.connect(db_path)) as conn:
            unresolved = conn.execute(
                "SELECT COUNT(*) FROM personnel WHERE position_raw IS NOT NULL AND position_title_id IS NULL"
            ).fetchone()[0]
            total = conn.execute("SELECT COUNT(*) FROM personnel").fetchone()[0]
            errors = conn.execute("SELECT COUNT(*) FROM date_parse_errors").fetchone()[
                0
            ]
    click.echo(f"personnel_rows={total}")
    click.echo(f"unresolved_positions={unresolved}")
    click.echo(f"date_parse_errors={errors}")


if __name__ == "__main__":
    main()
