from __future__ import annotations

import sqlite3
from collections import Counter
from typing import TypeAlias, TypedDict

SQLiteConnection: TypeAlias = sqlite3.Connection
CsvRow: TypeAlias = dict[str, str]
NaturalKey: TypeAlias = str
EntityId: TypeAlias = int
PositionTitleId: TypeAlias = int
EntityLookup: TypeAlias = dict[NaturalKey, EntityId]
PositionLookup: TypeAlias = dict[str, PositionTitleId]
DuplicateEmployeeScope: TypeAlias = tuple[str, str, str]
PositionCatalog: TypeAlias = dict[str, str]
AliasInsertRow: TypeAlias = tuple[EntityId, str]
DateParseErrorRow: TypeAlias = tuple[str, str, int, int | None, str, str]
EntityInsertRow: TypeAlias = tuple[
    str,
    int | None,
    str | None,
    str | None,
    str | None,
    int,
    NaturalKey,
]
PersonnelInsertRow: TypeAlias = tuple[
    EntityId,
    int | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    PositionTitleId | None,
    int | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    int | None,
    str | None,
    int | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    int,
    str,
    int,
    int | None,
]


class EntityRecord(TypedDict):
    entity_type: str
    school_id: int | None
    entity_name: str | None
    region: str | None
    division: str | None
    natural_key: NaturalKey
    has_personnel: int


class EntityAccumulator(TypedDict):
    entity_type: str
    school_id: int | None
    region: str | None
    division: str | None
    entity_name_counts: Counter[str]
    has_personnel: int
