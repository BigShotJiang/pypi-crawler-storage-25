"""Personnel row loading into SQLite."""

from __future__ import annotations

import sqlite3
from collections import Counter
from collections.abc import Iterable
from pathlib import Path
from typing import cast

from deped_dcp_template.cleaners import (
    clean_deped_email,
    clean_email,
    clean_text,
    normalize_identifier,
    normalize_phone,
    normalize_school_id,
    parse_date,
    position_issue,
    to_bool_int,
    validate_normalized_email,
)
from deped_dcp_template.constants import BATCH_SIZE, PERSONNEL_SOURCE
from deped_dcp_template.entities import build_natural_key, determine_entity_type
from deped_dcp_template.io import iter_csv_rows
from deped_dcp_template.personnel import duplicate_scope_key, flush_batch
from rich.progress import Progress, TaskID

from .personnel_normalization import (
    normalize_cause_of_separation,
    normalize_oic_designation,
    normalize_ro_office,
    normalize_sdo_office,
    normalize_source_of_funds,
)
from .types import (
    CsvRow,
    DateParseErrorRow,
    DuplicateEmployeeScope,
    EntityLookup,
    PersonnelInsertRow,
    PositionLookup,
)

PERSONNEL_COLUMNS = [
    "entity_id",
    "school_id",
    "employee_id",
    "last_name",
    "first_name",
    "middle_name",
    "suffix",
    "full_name",
    "ro_office",
    "sdo_office",
    "position_raw",
    "position_title_id",
    "is_officer_in_charge",
    "oic_designation",
    "mobile_1",
    "mobile_2",
    "deped_email",
    "personal_email",
    "date_hired",
    "is_non_deped_funded",
    "source_of_funds",
    "is_inactive",
    "date_separation",
    "cause_of_separation",
    "cause_of_separation_normalized",
    "cause_of_separation_quality",
    "cause_of_separation_normalization_note",
    "detailed_from",
    "detailed_to",
    "data_quality_flags",
    "is_duplicate_employee_id",
    "source_file",
    "source_row_num",
    "source_record_id",
]
DATE_ERROR_COLUMNS = [
    "source_table",
    "source_file",
    "source_row_num",
    "source_record_id",
    "column_name",
    "raw_value",
]


def maybe_log_date_error(
    errors: list[DateParseErrorRow],
    source_table: str,
    source_file: str,
    source_row_num: int,
    source_record_id: int | None,
    column_name: str,
    raw_value: str | None,
    parsed_value: str | None,
) -> bool:
    """Log invalid date input and return whether it was invalid."""
    cleaned_raw_value = clean_text(raw_value)
    if cleaned_raw_value is None or parsed_value is not None:
        return False
    errors.append(
        (
            source_table,
            source_file,
            source_row_num,
            source_record_id,
            column_name,
            cleaned_raw_value,
        )
    )
    return True


def _build_full_name(row: CsvRow) -> str | None:
    full_name = clean_text(row.get("Personnel's Full Name"))
    if full_name is not None:
        return full_name

    name_parts = [
        clean_text(row.get("First Name")),
        clean_text(row.get("Middle Name")),
        clean_text(row.get("Last Name")),
        clean_text(row.get("Suffix")),
    ]
    return " ".join(part for part in name_parts if part) or None


def _duplicate_flag(
    seen_employee_ids: set[DuplicateEmployeeScope],
    entity_type: str,
    employee_id: str | None,
    region: str | None,
    division: str | None,
) -> int:
    duplicate_key = duplicate_scope_key(entity_type, employee_id, region, division)
    if duplicate_key is None:
        return 0
    if duplicate_key in seen_employee_ids:
        return 1
    seen_employee_ids.add(duplicate_key)
    return 0


def _append_separation_flags(
    flags: list[str],
    cause_of_separation_normalized: str | None,
    cause_of_separation_quality: str | None,
    is_inactive: int | None,
    date_separation: str | None,
) -> None:
    if cause_of_separation_quality is not None:
        flags.append(f"cause_separation_{cause_of_separation_quality.casefold()}")
    if cause_of_separation_normalized is not None and is_inactive == 0:
        flags.append("separation_status_mismatch")
    if cause_of_separation_quality == "NOT_SEPARATED" and (
        is_inactive == 1 or date_separation is not None
    ):
        flags.append("separation_status_mismatch")


def _build_personnel_row(
    row: CsvRow,
    *,
    entity_id: int,
    school_id: int | None,
    employee_id: str | None,
    position_raw: str | None,
    position_title_id: int | None,
    is_officer_in_charge: int | None,
    oic_designation: str | None,
    mobile_1: str | None,
    mobile_2: str | None,
    deped_email: str | None,
    personal_email: str | None,
    date_hired: str | None,
    is_non_deped_funded: int | None,
    source_of_funds: str | None,
    is_inactive: int | None,
    date_separation: str | None,
    cause_of_separation: str | None,
    cause_of_separation_normalized: str | None,
    cause_of_separation_quality: str | None,
    cause_of_separation_normalization_note: str | None,
    data_quality_flags: str | None,
    is_duplicate_employee_id: int,
    source_file: str,
    source_row_num: int,
    source_record_id: int | None,
) -> PersonnelInsertRow:
    return (
        entity_id,
        school_id,
        employee_id,
        clean_text(row.get("Last Name")),
        clean_text(row.get("First Name")),
        clean_text(row.get("Middle Name")),
        clean_text(row.get("Suffix")),
        _build_full_name(row),
        normalize_ro_office(row.get("RO Office")),
        normalize_sdo_office(row.get("SDO Office")),
        position_raw,
        position_title_id,
        is_officer_in_charge,
        oic_designation,
        mobile_1,
        mobile_2,
        deped_email,
        personal_email,
        date_hired,
        is_non_deped_funded,
        source_of_funds,
        is_inactive,
        date_separation,
        cause_of_separation,
        cause_of_separation_normalized,
        cause_of_separation_quality,
        cause_of_separation_normalization_note,
        clean_text(row.get("Detailed/Transferred From")),
        clean_text(row.get("Detailed/Transferred To")),
        data_quality_flags,
        is_duplicate_employee_id,
        source_file,
        source_row_num,
        source_record_id,
    )


def load_personnel(  # noqa: C901
    conn: sqlite3.Connection,
    path: str | Path,
    entity_lookup: EntityLookup,
    position_lookup: PositionLookup,
    progress: Progress | None = None,
) -> Counter[str]:
    """Load cleaned personnel data into SQLite."""
    seen_employee_ids: set[DuplicateEmployeeScope] = set()
    unmapped_positions: Counter[str] = Counter()
    rows: list[PersonnelInsertRow] = []
    date_errors: list[DateParseErrorRow] = []
    source_file = Path(path).name

    task_id: TaskID | None = None
    if progress is not None:
        task_id = progress.add_task(
            f"Load personnel: {Path(path).name} (0 rows)",
            total=Path(path).stat().st_size,
        )

    csv_rows = cast(
        Iterable[tuple[int, CsvRow]], iter_csv_rows(path, progress, task_id)
    )
    for source_row_num, row in csv_rows:
        entity_type = determine_entity_type(row.get("Governance Level"))
        school_id = normalize_school_id(row.get("School ID"))
        region = clean_text(row.get("Region"))
        division = clean_text(row.get("Division"))
        natural_key = build_natural_key(entity_type, school_id, region, division)
        entity_id = entity_lookup[natural_key]
        source_record_id = normalize_school_id(row.get("ID"))

        employee_id = normalize_identifier(row.get("Employee ID"))
        flags: list[str] = []
        if employee_id is None:
            flags.append("missing_employee_id")

        position_raw = clean_text(row.get("Position"))
        normalized_position, position_flag = position_issue(position_raw)
        if position_flag is not None:
            flags.append(position_flag)
        if position_raw and position_flag == "unmapped_position":
            unmapped_positions[position_raw] += 1

        mobile_1, mobile_1_suspicious = normalize_phone(row.get("Mobile No. 1"))
        mobile_2, mobile_2_suspicious = normalize_phone(row.get("Mobile No. 2"))
        if mobile_1_suspicious or mobile_2_suspicious:
            flags.append("phone_scientific")

        deped_email, deped_bad_domain, reclassified_email = clean_deped_email(
            row.get("DepEd Email Address")
        )
        personal_email, _ = clean_email(row.get("Personal Email Address"))
        if personal_email is None and reclassified_email is not None:
            personal_email = reclassified_email
        deped_email, invalid_deped_email = validate_normalized_email(deped_email)
        personal_email, invalid_personal_email = validate_normalized_email(
            personal_email
        )
        if deped_bad_domain:
            flags.append("bad_email_domain")
        if invalid_deped_email or invalid_personal_email:
            flags.append("invalid_email")

        date_hired = parse_date(row.get("Date Hired"))
        date_separation = parse_date(row.get("Date of Effectivity of Separation"))
        cause_of_separation = clean_text(row.get("Cause of Separation"))
        (
            cause_of_separation_normalized,
            cause_of_separation_quality,
            cause_of_separation_normalization_note,
        ) = normalize_cause_of_separation(cause_of_separation)

        invalid_date = False
        invalid_date |= maybe_log_date_error(
            date_errors,
            PERSONNEL_SOURCE,
            source_file,
            source_row_num,
            source_record_id,
            "date_hired",
            row.get("Date Hired"),
            date_hired,
        )
        invalid_date |= maybe_log_date_error(
            date_errors,
            PERSONNEL_SOURCE,
            source_file,
            source_row_num,
            source_record_id,
            "date_separation",
            row.get("Date of Effectivity of Separation"),
            date_separation,
        )
        if invalid_date:
            flags.append("invalid_date")

        is_inactive = to_bool_int(row.get("Inactive"))
        _append_separation_flags(
            flags,
            cause_of_separation_normalized,
            cause_of_separation_quality,
            is_inactive,
            date_separation,
        )

        is_duplicate_employee_id = _duplicate_flag(
            seen_employee_ids, entity_type, employee_id, region, division
        )

        position_title_id = (
            position_lookup.get(normalized_position)
            if normalized_position is not None
            else None
        )
        is_officer_in_charge = to_bool_int(row.get("Officer-in-Charge"))
        oic_designation = normalize_oic_designation(
            position_raw,
            is_officer_in_charge,
            row.get("Office of OIC Designation"),
        )
        is_non_deped_funded = to_bool_int(row.get("Non-DepEd funded"))
        source_of_funds = normalize_source_of_funds(
            is_non_deped_funded,
            row.get("Source(s) of Funds"),
        )

        rows.append(
            _build_personnel_row(
                row,
                entity_id=entity_id,
                school_id=school_id,
                employee_id=employee_id,
                position_raw=position_raw,
                position_title_id=position_title_id,
                is_officer_in_charge=is_officer_in_charge,
                oic_designation=oic_designation,
                mobile_1=mobile_1,
                mobile_2=mobile_2,
                deped_email=deped_email,
                personal_email=personal_email,
                date_hired=date_hired,
                is_non_deped_funded=is_non_deped_funded,
                source_of_funds=source_of_funds,
                is_inactive=is_inactive,
                date_separation=date_separation,
                cause_of_separation=cause_of_separation,
                cause_of_separation_normalized=cause_of_separation_normalized,
                cause_of_separation_quality=cause_of_separation_quality,
                cause_of_separation_normalization_note=cause_of_separation_normalization_note,
                data_quality_flags=",".join(dict.fromkeys(flags)) or None,
                is_duplicate_employee_id=is_duplicate_employee_id,
                source_file=source_file,
                source_row_num=source_row_num,
                source_record_id=source_record_id,
            )
        )

        if len(rows) >= BATCH_SIZE:
            flush_batch(
                conn,
                "personnel",
                PERSONNEL_COLUMNS,
                cast(list[tuple[object, ...]], rows),
            )
            flush_batch(
                conn,
                "date_parse_errors",
                DATE_ERROR_COLUMNS,
                cast(list[tuple[object, ...]], date_errors),
            )
            conn.commit()
            rows.clear()
            date_errors.clear()

    flush_batch(
        conn, "personnel", PERSONNEL_COLUMNS, cast(list[tuple[object, ...]], rows)
    )
    flush_batch(
        conn,
        "date_parse_errors",
        DATE_ERROR_COLUMNS,
        cast(list[tuple[object, ...]], date_errors),
    )
    conn.commit()
    return unmapped_positions
