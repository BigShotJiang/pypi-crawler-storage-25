# deped-hr

`deped-hr` cleans personnel CSV exports into a standalone SQLite database. It depends on the lookup artifact from [deped-dcp-template](https://github.com/justmars/deped-dcp-template).

## What This Package Owns

- Personnel row cleaning and normalization
- Entity loading for the personnel domain
- Position title seeding from `lookups.db`
- Personnel-focused views and audit outputs

This package is the source of truth for the personnel database contract only.

## Inputs And Outputs

Required inputs:

- a personnel CSV export; this needs to be placed under `/data`
- a lookup database produced by `deped-template`

Primary outputs:

- `personnel.db`
- `unmapped_positions.txt`

`personnel.db` includes normalized personnel rows, entity rows for the covered scope, date parse errors, seeded position titles, and personnel-owned views such as school/personnel summaries and quality issue rollups.

## CLI

Build the lookup database:

```sh
uv run deped-dcp-template extract \
  --templates-dir templates \
  --output artifacts/lookups.db
```

Build the personnel database using both `artifacts/lookups.db` and the personnel csv file, e.g. `data/2026-03-31-personnel.csv`:

```sh
uv run hr build \
  --personnel data/2026-03-31-personnel.csv \
  --lookups artifacts/lookups.db \
  --db artifacts/personnel.db
```

Run the lightweight audit command:

```bash
uv run hr audit \
  --db artifacts/personnel.db
```

## Nuances

- Position normalization is intentionally lookup-driven. If a raw title fails to map cleanly, it is recorded in `unmapped_positions.txt` rather than silently coerced.
- The build also applies cleaning beyond normalization: it parses dates,
  repairs or blanks invalid emails, normalizes phone numbers, reconstructs
  missing full names, normalizes employee identifiers, and emits quality flags
  for invalid or suspicious source values.
- Several high-noise personnel fields are normalized to closed canonical sets:
  `oic_designation`, `source_of_funds`, `ro_office`, and `sdo_office`. Unknown
  or polluted values are blanked rather than preserved as free text.
- Office-unit reporting should come from normalized personnel data and
  `v_office_personnel_summary`, not from the entity dimension.
- The package creates only personnel-owned views. Cross-domain analytical surfaces from the retired monolith are not part of this contract.
- Equipment-specific assumptions do not belong here. If another package needs personnel data, it should consume the `personnel.db` artifact instead of importing this package.

## Tests

Run the package tests from this directory:

```bash
uv run pytest -q
```
