from deped_dcp_template.cleaners import (
    normalize_position,
    normalize_position_key,
    position_issue,
    preprocess_position_text,
)
from deped_dcp_template.constants import POSITION_CANONICAL


def test_position_normalization_rules() -> None:
    assert normalize_position("T-III") == "Teacher III"
    assert normalize_position("ADM ASST II") == "Administrative Assistant II"
    assert normalize_position("ADMIN ASST II") == "Administrative Assistant II"
    assert (
        normalize_position("Assistant Teacher's Camp Superintendent")
        == "Assistant Teachers Camp Superintendent"
    )
    assert (
        normalize_position("Teachers Camp Superintendent")
        == "Teachers Camp Superintendent"
    )
    assert normalize_position("Directory III") == "Director III"
    assert normalize_position("Directory IV") == "Director IV"
    assert normalize_position("SHST-II") == "Teacher II"
    assert normalize_position("SHS TEACHER V") == "Teacher V"
    assert normalize_position("SHS TEACHER I") == "Teacher I"
    assert normalize_position("SHS TEACHER 1") == "Teacher I"
    assert normalize_position("Secondary School Teacher III") == "Teacher III"
    assert normalize_position("ALS SHS TEACHER I") == "Teacher I"
    assert normalize_position("Senior High School, Teacher II") == "Teacher II"
    assert normalize_position("Teacher I-JHS") == "Teacher I"
    assert normalize_position("JHST-III") == "Teacher III"
    assert normalize_position("Unknown Role") is None
    assert preprocess_position_text("Teacher III (SHS)") == "TEACHER III"
    assert normalize_position_key("PRINCIPAL 1") == "SCHOOL PRINCIPAL I"
    assert position_issue("Region V") == (None, "invalid_position")
    assert position_issue("Unknown Role") == (None, "unmapped_position")


def test_position_category_exceptions() -> None:
    assert (
        POSITION_CANONICAL["Assistant Teachers Camp Superintendent"] == "NON_TEACHING"
    )
    assert POSITION_CANONICAL["Teachers Camp Superintendent"] == "NON_TEACHING"
    assert POSITION_CANONICAL["Director III"] == "NON_TEACHING"
    assert POSITION_CANONICAL["Director IV"] == "NON_TEACHING"
    assert POSITION_CANONICAL["Public Schools District Supervisor"] == "NON_TEACHING"
    assert POSITION_CANONICAL["Vocational School Superintendent I"] == "NON_TEACHING"
    assert POSITION_CANONICAL["Schools Division Superintendent"] == "NON_TEACHING"
    assert POSITION_CANONICAL["Publication Production Supervisor"] == "NON_TEACHING"
