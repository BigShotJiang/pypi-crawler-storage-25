from deped_hr.personnel import normalize_cause_of_separation


def test_cause_of_separation_normalization_rules() -> None:
    assert normalize_cause_of_separation("TRANSFER") == ("TRANSFER", None, None)
    assert normalize_cause_of_separation("retired") == ("RETIREMENT", None, None)
    assert normalize_cause_of_separation("Overseas work") == (
        "RESIGNATION",
        None,
        None,
    )
    assert normalize_cause_of_separation("Expiration of Appoinment or Contract") == (
        "END_OF_CONTRACT",
        None,
        None,
    )
    assert normalize_cause_of_separation("Detailed") == (
        None,
        "NOT_SEPARATED",
        "assignment status stored in separation field",
    )
    assert normalize_cause_of_separation("0") == (
        None,
        "UNKNOWN_PLACEHOLDER",
        None,
    )
    assert normalize_cause_of_separation("Dropping from the Rolls") == (
        None,
        "REVIEW_REQUIRED",
        None,
    )
    assert normalize_cause_of_separation("Teacher I") == (
        None,
        "MISFILED_SOURCE_VALUE",
        "position title stored in separation field",
    )
