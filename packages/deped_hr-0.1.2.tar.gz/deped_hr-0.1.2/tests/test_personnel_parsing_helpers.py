from deped_dcp_template.cleaners import (
    clean_deped_email,
    clean_email,
    normalize_phone,
    normalize_school_id,
    parse_date,
    to_bool_int,
    validate_normalized_email,
)


def test_personnel_parsing_helpers() -> None:
    assert parse_date("3/30/2026") == "2026-03-30"
    assert parse_date("2026-13-30") is None
    assert normalize_phone("9171234567") == ("09171234567", False)
    assert normalize_phone("9.09488E+11") == ("909488000000", True)
    assert clean_email("USER@depd.gov.ph") == ("user@deped.gov.ph", True)
    assert clean_deped_email("user@gmail.com") == (None, False, "user@gmail.com")
    assert normalize_school_id("311010.0") == 311010
    assert to_bool_int("YES") == 1
    assert to_bool_int("0") == 0


def test_clean_deped_email_preserves_valid_subdomains() -> None:
    assert clean_deped_email("user@car.deped.gov.ph") == (
        "user@car.deped.gov.ph",
        False,
        None,
    )
    assert clean_deped_email("user@ncr2.deped.gov.ph") == (
        "user@ncr2.deped.gov.ph",
        False,
        None,
    )
    assert clean_deped_email("user@caraga.deped.gov.ph") == (
        "user@caraga.deped.gov.ph",
        False,
        None,
    )
    assert clean_deped_email("user@o365.deped.gov.ph") == (
        "user@o365.deped.gov.ph",
        False,
        None,
    )


def test_clean_deped_email_repairs_deped_like_gov_ph_domains() -> None:
    assert clean_deped_email("user@dped.gov.ph") == (
        "user@deped.gov.ph",
        True,
        None,
    )
    assert clean_deped_email("user@depe.gov.ph") == (
        "user@deped.gov.ph",
        True,
        None,
    )
    assert clean_deped_email("user@depeed.gov.ph") == (
        "user@deped.gov.ph",
        True,
        None,
    )
    assert clean_deped_email("user@dep.ed.gov.ph") == (
        "user@deped.gov.ph",
        True,
        None,
    )
    assert clean_deped_email("user@dee-ped.gov.ph") == (
        "user@deped.gov.ph",
        True,
        None,
    )
    assert clean_deped_email("user@car.dped.gov.ph") == (
        "user@car.deped.gov.ph",
        True,
        None,
    )


def test_validate_normalized_email_rejects_invalid_addresses() -> None:
    assert validate_normalized_email("user@deped.gov.ph") == (
        "user@deped.gov.ph",
        False,
    )
    assert validate_normalized_email("not-an-email") == (None, True)
