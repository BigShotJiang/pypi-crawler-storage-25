from deped_hr.personnel import (
    normalize_oic_designation,
    normalize_ro_office,
    normalize_sdo_office,
    normalize_source_of_funds,
)


def test_oic_designation_normalization_rules() -> None:
    assert normalize_oic_designation("Teacher III", 1, "Teacher In Charge") == (
        "Teacher-In-Charge"
    )
    assert normalize_oic_designation("Teacher III", 1, "SCHOOL HEAD") == ("School Head")
    assert normalize_oic_designation("School Principal I", 1, "School Head") is None
    assert normalize_oic_designation("Teacher III", 0, "TIC") is None


def test_source_of_funds_normalization_rules() -> None:
    assert normalize_source_of_funds(1, "Municipality / City's SEF") == (
        "Special Education Fund (SEF)"
    )
    assert normalize_source_of_funds(1, "School MOOE") == (
        "Maintenance and Other Operating Expenses (MOOE)"
    )
    assert normalize_source_of_funds(1, "Municipality / City's General Fund") == (
        "General Fund (GF)"
    )
    assert normalize_source_of_funds(1, "LGU Fund") is None
    assert normalize_source_of_funds(0, "Special Education Fund") is None


def test_ro_office_normalization_rules() -> None:
    assert normalize_ro_office("Administrative Division-Asset Management Section") == (
        "Administrative Division"
    )
    assert normalize_ro_office("HRDD") == "Human Resource Development Division"
    assert normalize_ro_office("ORD") == "Office of the Regional Director Proper"
    assert normalize_ro_office("TEACHER I") is None


def test_sdo_office_normalization_rules() -> None:
    assert normalize_sdo_office("CID") == "Curriculum Implementation Division"
    assert normalize_sdo_office("SGOD") == (
        "Schools Governance and Operations Division"
    )
    assert normalize_sdo_office("OSDS") == (
        "Office of the Schools Division Superintendent"
    )
    assert normalize_sdo_office("MAKATI HIGH SCHOOL") is None
