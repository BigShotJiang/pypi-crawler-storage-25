import sqlite3
from contextlib import closing
from pathlib import Path

from deped_dcp_template.cleaners import normalize_position

from deped_hr.cli import build_personnel_db
from tests.conftest import (
    PERSONNEL_HEADERS,
    make_lookup_db,
    sample_personnel_rows,
    write_csv,
)


def test_build_personnel_db_creates_domain_views_and_audits(tmp_path: Path) -> None:
    lookups_db = tmp_path / "lookups.db"
    personnel_csv = tmp_path / "personnel.csv"
    personnel_db = tmp_path / "personnel.db"
    make_lookup_db(lookups_db)
    write_csv(personnel_csv, PERSONNEL_HEADERS, sample_personnel_rows())

    build_personnel_db(personnel_csv, lookups_db, personnel_db)

    with closing(sqlite3.connect(personnel_db)) as conn:
        assert conn.execute("SELECT COUNT(*) FROM personnel").fetchone()[0] == 24
        assert (
            conn.execute("SELECT COUNT(*) FROM v_personnel_enriched").fetchone()[0]
            == 24
        )
        assert conn.execute("SELECT COUNT(*) FROM v_schools").fetchone()[0] == 1
        assert conn.execute("SELECT COUNT(*) FROM date_parse_errors").fetchone()[0] >= 2

        mapped_titles = conn.execute(
            """
            SELECT full_name, position_title
            FROM v_personnel_enriched
            WHERE full_name IN ('Alex Ramos', 'Jane Doe', 'John Smith', 'Pat Stone')
            ORDER BY full_name
            """
        ).fetchall()
        assert mapped_titles == [
            ("Alex Ramos", "Teacher III"),
            ("Jane Doe", "Teacher III"),
            ("John Smith", "Administrative Assistant I"),
            ("Pat Stone", None),
        ]

        issue_rows = conn.execute(
            """
            SELECT issue_type, issue_count
            FROM v_quality_issues_by_entity
            ORDER BY issue_type
            """
        ).fetchall()
        assert ("unmapped_position", 1) in issue_rows
        assert ("bad_email_domain", 1) in issue_rows
        assert ("invalid_email", 1) in issue_rows

        email_rows = conn.execute(
            """
            SELECT full_name, deped_email, personal_email, data_quality_flags
            FROM personnel
            WHERE full_name = 'Alex Ramos'
            """
        ).fetchone()
        assert email_rows == ("Alex Ramos", None, None, "invalid_email")

        normalized_rows = conn.execute(
            """
            SELECT full_name, cause_of_separation, cause_of_separation_normalized,
                   cause_of_separation_quality, cause_of_separation_normalization_note,
                   data_quality_flags
            FROM personnel
            WHERE full_name IN ('Tina Transfer', 'Dana Detail', 'Rina Review', 'Mia Misfiled')
            ORDER BY full_name
            """
        ).fetchall()
        assert normalized_rows == [
            (
                "Dana Detail",
                "Detailed",
                None,
                "NOT_SEPARATED",
                "assignment status stored in separation field",
                "cause_separation_not_separated",
            ),
            (
                "Mia Misfiled",
                "Teacher I",
                None,
                "MISFILED_SOURCE_VALUE",
                "position title stored in separation field",
                "cause_separation_misfiled_source_value",
            ),
            (
                "Rina Review",
                "Dropping from the Rolls",
                None,
                "REVIEW_REQUIRED",
                None,
                "cause_separation_review_required",
            ),
            (
                "Tina Transfer",
                "Transferred out",
                "TRANSFER",
                None,
                None,
                "separation_status_mismatch",
            ),
        ]

        oic_rows = conn.execute(
            """
            SELECT employee_id, oic_designation
            FROM personnel
            WHERE employee_id IN ('E-009', 'E-010', 'E-011', 'E-012')
            ORDER BY employee_id
            """
        ).fetchall()
        assert oic_rows == [
            ("E-009", "Teacher-In-Charge"),
            ("E-010", "School Head"),
            ("E-011", None),
            ("E-012", None),
        ]

        funding_rows = conn.execute(
            """
            SELECT employee_id, is_non_deped_funded, source_of_funds
            FROM personnel
            WHERE employee_id IN ('E-013', 'E-014', 'E-015', 'E-016')
            ORDER BY employee_id
            """
        ).fetchall()
        assert funding_rows == [
            ("E-013", 1, "Special Education Fund (SEF)"),
            ("E-014", 1, "Maintenance and Other Operating Expenses (MOOE)"),
            ("E-015", 1, None),
            ("E-016", 0, None),
        ]

        ro_office_rows = conn.execute(
            """
            SELECT employee_id, ro_office
            FROM personnel
            WHERE employee_id IN ('E-017', 'E-018', 'E-019', 'E-020')
            ORDER BY employee_id
            """
        ).fetchall()
        assert ro_office_rows == [
            ("E-017", "Administrative Division"),
            ("E-018", "Human Resource Development Division"),
            ("E-019", "Office of the Regional Director Proper"),
            ("E-020", None),
        ]

        sdo_office_rows = conn.execute(
            """
            SELECT employee_id, sdo_office
            FROM personnel
            WHERE employee_id IN ('E-021', 'E-022', 'E-023', 'E-024')
            ORDER BY employee_id
            """
        ).fetchall()
        assert sdo_office_rows == [
            ("E-021", "Curriculum Implementation Division"),
            ("E-022", "Schools Governance and Operations Division"),
            ("E-023", "Office of the Schools Division Superintendent"),
            ("E-024", None),
        ]

        build_run = conn.execute(
            """
            SELECT build_type, lookups_source_file, personnel_source_file,
                   personnel_source_rows, entity_count, personnel_count,
                   completed_at IS NOT NULL
            FROM build_runs
            """
        ).fetchone()
        assert build_run == (
            "full_rebuild",
            "lookups.db",
            "personnel.csv",
            24,
            3,
            24,
            1,
        )

    audit_path = tmp_path / "unmapped_positions.txt"
    assert audit_path.exists()
    assert "Unknown Role" in audit_path.read_text(encoding="utf-8")
    assert normalize_position("SHS TEACHER V") == "Teacher V"
