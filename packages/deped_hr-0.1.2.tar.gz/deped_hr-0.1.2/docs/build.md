# Build Guide

This page covers the expected workflow for producing the personnel artifact.

## Prerequisites

- Python 3.14+
- `uv`
- A valid personnel CSV export
- A lookup database produced by `deped-dcp-template`

## 1. Build The Lookup Database

The personnel package expects a lookup database with position metadata.

```sh
uv run deped-dcp-template extract \
  --templates-dir templates \
  --output artifacts/lookups.db
```

## 2. Build The Personnel Database

Run the personnel build from the repository root:

```sh
uv run hr build \
  --personnel data/2026-03-31-personnel.csv \
  --lookups artifacts/lookups.db \
  --db artifacts/personnel.db
```

Arguments:

- `--personnel`: source CSV file
- `--lookups`: lookup SQLite database
- `--db`: destination SQLite database

The command prints the output database path on success.

## 3. Audit The Result

Run the lightweight audit command after a build:

```sh
uv run hr audit \
  --db artifacts/personnel.db
```

Current audit output includes:

- `personnel_rows`
- `unresolved_positions`
- `date_parse_errors`

## Generated Files

The build produces:

- `artifacts/personnel.db`
- `artifacts/unmapped_positions.txt`

The text audit file lists raw positions that did not map to a canonical title.

## Cleaning Performed During Build

The build does more than load source rows verbatim. It also:

- parses date fields into ISO format and logs unparseable values
- normalizes phone numbers and flags scientific-notation-like inputs
- repairs, validates, and reclassifies email addresses when possible
- normalizes employee identifiers before duplicate detection
- reconstructs `full_name` when the source full-name field is blank
- maps raw positions into canonical lookup-backed titles
- derives separation-quality metadata and row-level quality flags
- canonicalizes high-noise office and funding fields to closed value sets

## Failure Modes

Common causes of build failure:

- Missing input files
- Invalid lookup database schema
- Invalid or malformed CSV headers
- Environment issues that prevent `uv` from resolving dependencies

If `uv run hr ...` fails before Python starts, verify the package entry point is
available in `pyproject.toml` and that your local environment can build the
project.
