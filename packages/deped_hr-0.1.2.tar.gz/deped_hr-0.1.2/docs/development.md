# Development

## Local Setup

Install project dependencies with `uv` and work from the repository root.

The package code lives under `src/deped_hr`.

## Tests

Run the test suite:

```sh
uv run pytest -q
```

Current test coverage is focused on:

- build integration in `tests/test_personnel_build_integration.py`
- parsing helpers in `tests/test_personnel_parsing_helpers.py`
- position normalization in `tests/test_personnel_position_normalization.py`
- cause normalization in `tests/test_personnel_cause_normalization.py`
- field normalization in `tests/test_personnel_field_normalization.py`

## Documentation

This repository uses Zensical for documentation. The site configuration lives in
`zensical.toml`, and Markdown sources live in `docs/`.

Build the documentation site locally with:

```sh
uv run zensical build
```

## Publishing

The `justfile` includes a `publish` target that builds and publishes the Python
package:

```sh
just publish
```

This expects the appropriate PyPI token to be available in the environment.
