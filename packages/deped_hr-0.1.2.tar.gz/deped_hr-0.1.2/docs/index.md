# DepEd HR

Builds a personnel-focused SQLite database from DepEd personnel CSV exports.
It depends on lookup data from `deped-dcp-template` and produces a standalone
artifact that downstream consumers can query without importing Python package
code.

## What This Package Owns

- Personnel row cleaning and normalization
- Entity loading for the personnel domain
- Position title seeding from the lookup database
- Personnel-owned SQL views and audit outputs

This package is the source of truth for the `personnel.db` artifact only.

## Inputs

- A personnel CSV export under `data/`
- A lookup database produced by `deped-dcp-template`

## Outputs

- `artifacts/personnel.db`
- `artifacts/unmapped_positions.txt`

`personnel.db` contains normalized personnel rows, entity rows for the covered
scope, date parse errors, seeded position titles, build metadata, and
personnel-owned analytical views.

## Main Commands

Build the lookup database:

```sh
uv run deped-dcp-template extract \
  --templates-dir templates \
  --output artifacts/lookups.db
```

Build the personnel database:

```sh
uv run hr build \
  --personnel data/2026-03-31-personnel.csv \
  --lookups artifacts/lookups.db \
  --db artifacts/personnel.db
```

Audit a built database:

```sh
uv run hr audit \
  --db artifacts/personnel.db
```

## Behavioral Notes

- Position normalization is intentionally lookup-driven.
- Unmapped roles are written to `unmapped_positions.txt` instead of being
  silently coerced.
- The build also performs cleaning for dates, emails, phones, names, employee
  identifiers, and separation-quality metadata before rows are persisted.
- Several high-noise personnel fields are normalized to closed canonical sets:
  `oic_designation`, `source_of_funds`, `ro_office`, and `sdo_office`.
- Office-unit reporting should come from normalized personnel office values and
  `v_office_personnel_summary`, not from the entity dimension.
- The package creates personnel-owned views only.
- Other systems should consume `personnel.db` as an artifact instead of
  importing internal modules.
