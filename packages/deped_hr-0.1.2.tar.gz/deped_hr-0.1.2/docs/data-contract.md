# Data Contract

The `hr` package owns the structure and semantics of the personnel artifact.

## Core Tables

The SQLite schema includes these primary tables:

- `entities`
- `entity_aliases`
- `personnel`
- `position_titles`
- `date_parse_errors`
- `build_runs`

### Entity Semantics

- `entities` is the canonical entity dimension for schools, division offices,
  and regional offices.
- Consumers that need office-level rollups should use
  `v_office_personnel_summary`, which derives office-unit groupings from
  normalized `personnel.sdo_office` and `personnel.ro_office`.

## Views

The build creates the following personnel-owned views:

- `v_schools`
- `v_personnel_enriched`
- `v_personnel_per_school`
- `v_personnel_by_position_type`
- `v_quality_issues_by_entity`
- `v_office_personnel_summary`

These views are part of the artifact contract exposed to downstream consumers.

## Build Metadata

`build_runs` records provenance for each build, including:

- Build type
- Schema version
- Source file names
- Source file hashes
- Personnel row count
- Final entity and personnel counts
- Completion timestamp

## Position Mapping

Position mapping is seeded from the lookup database. During the build:

- canonical titles are inserted into `position_titles`
- personnel records try to resolve `position_raw` to `position_title_id`
- unresolved titles remain visible for audit and quality review

Unmapped position strings are also written to `unmapped_positions.txt`.

## Field Cleaning Rules

In addition to closed-set normalization, the build applies row-level cleaning to
several raw source fields before data is stored.

### Dates

- `date_hired` and `date_separation` are parsed into ISO `YYYY-MM-DD`.
- Unparseable values are stored as `NULL` and logged to `date_parse_errors`.
- Date parse failures also add the `invalid_date` quality flag to the affected
  personnel row.

### Email Addresses

- DepEd emails are lowercased and validated.
- DepEd-like typo domains may be repaired to canonical `deped.gov.ph`
  addresses when the fix is high confidence.
- Non-DepEd emails entered in the DepEd field may be reclassified into
  `personal_email`.
- Invalid normalized emails are blanked and flagged with `invalid_email`.
- Suspicious DepEd domains are flagged with `bad_email_domain`.

### Phone Numbers

- Phone numbers are normalized into a canonical local format when possible.
- Scientific-notation-like values are preserved as cleaned digits when they can
  be interpreted and flagged with `phone_scientific`.

### Employee Identity

- `employee_id` is normalized before duplicate checks are applied.
- Missing employee IDs add the `missing_employee_id` flag.
- Duplicate detection is scoped by entity type and geographic context, then
  materialized as `is_duplicate_employee_id`.

### Names

- `full_name` is taken from the source full-name column when present.
- If the source full-name column is blank, `full_name` is reconstructed from
  first, middle, last, and suffix fields.

### Position Titles

- `position_raw` is cleaned from source text before lookup matching.
- Canonical position mapping is lookup-driven through `position_titles`.
- Clearly invalid titles are flagged as `invalid_position`.
- Unmapped but plausible titles are flagged as `unmapped_position` and written
  to `unmapped_positions.txt`.

### Separation Cause Quality

- `cause_of_separation` is preserved as cleaned source text.
- `cause_of_separation_normalized` stores the canonical code only for
  recognized values.
- `cause_of_separation_quality` and
  `cause_of_separation_normalization_note` capture review-required,
  placeholder, misfiled, and not-separated cases.
- Cross-field inconsistencies between separation cause, inactive status, and
  separation date add `separation_status_mismatch`.

## Field Normalization Rules

The build applies strict canonicalization to a small set of high-noise fields.
Values that do not match an approved canonical value or a high-confidence alias
are blanked instead of being preserved as free text.

### Officer-In-Charge

- `personnel.oic_designation` is only retained when
  `personnel.is_officer_in_charge = 1`.
- The only allowed canonical values are:
  - `School Head`
  - `Teacher-In-Charge`
- `School Head` is only retained when `position_raw` is not already a
  school-head role such as principal or head teacher.
- All other `oic_designation` values are set to `NULL`.

### Source Of Funds

- `personnel.source_of_funds` is only retained when
  `personnel.is_non_deped_funded = 1`.
- The only allowed canonical values are:
  - `General Fund (GF)`
  - `Maintenance and Other Operating Expenses (MOOE)`
  - `Capital Outlay (CO)`
  - `Special Education Fund (SEF)`
  - `Trust Fund (TF)`
  - `Program Support Fund (PSF)`
  - `Not Applicable`
- High-confidence aliases are normalized into those canonical values.
- Ambiguous or polluted values are set to `NULL`.

### Regional Office

- `personnel.ro_office` is normalized to this closed set:
  - `Administrative Division`
  - `Curriculum and Learning Management Division`
  - `Education Support Services Division`
  - `Field Technical Assistance Division`
  - `Finance Division`
  - `Human Resource Development Division`
  - `ICT Unit`
  - `Legal Unit`
  - `Office of the Assistant Regional Director`
  - `Office of the Regional Director Proper`
  - `Policy, Planning and Research Division`
  - `Public Affairs Unit`
  - `Quality Assurance Division`
- High-confidence aliases such as `HRDD` and `ORD` are mapped to their
  canonical names.
- Job titles, equipment names, school names, and other polluted values are set
  to `NULL`.

### Schools Division Office

- `personnel.sdo_office` is normalized to this closed set:
  - `Office of the Schools Division Superintendent`
  - `Office of the Assistant Schools Division Superintendent`
  - `Legal Services`
  - `Administrative Services`
  - `Finance Services`
  - `ICT Services`
  - `Curriculum Implementation Division`
  - `Schools Governance and Operations Division`
- High-confidence aliases such as `OSDS`, `ASDS`, `CID`, and `SGOD` are mapped
  to their canonical names.
- Section labels, school names, personnel titles, equipment labels, and other
  polluted values are set to `NULL`.

## Data Quality Signals

The artifact captures quality issues in two ways:

- `date_parse_errors` stores dates that failed parsing
- `v_quality_issues_by_entity` aggregates quality flags such as invalid email
  and unmapped positions

This allows consumers to use the database both for downstream reporting and for
source-data remediation work.
