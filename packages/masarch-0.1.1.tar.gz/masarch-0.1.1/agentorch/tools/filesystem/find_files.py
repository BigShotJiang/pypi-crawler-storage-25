from __future__ import annotations

import fnmatch
from pathlib import Path

from pydantic import BaseModel, Field

from agentorch.tools.base import FunctionTool, ToolError
from agentorch.tools.common import is_hidden_path, resolve_workspace_path


class FindFilesInput(BaseModel):
    pattern: str = Field(description="Glob pattern used to match file names, for example '*.py'.")
    path: str | None = Field(default=None, description="Optional directory path relative to the workspace root.")
    max_results: int = Field(default=200, ge=1, le=5000, description="Maximum number of file paths to return.")
    include_hidden: bool = Field(default=False, description="Whether to include hidden files and directories.")
    case_sensitive: bool = Field(default=False, description="Whether matching should preserve case.")


def create_find_files_tool(workspace_root: str | Path, *, name: str = "find_files") -> FunctionTool:
    root = Path(workspace_root).resolve()

    async def find_files(input: FindFilesInput):
        base = resolve_workspace_path(root, input.path, tool_name=name)
        if not base.exists():
            raise ToolError(f"Search path '{base}' does not exist.", tool_name=name)
        iterator = [base] if base.is_file() else base.rglob("*")
        pattern = input.pattern if input.case_sensitive else input.pattern.lower()
        matcher = fnmatch.fnmatchcase if input.case_sensitive else fnmatch.fnmatch
        matches = []
        for item in iterator:
            if not item.is_file():
                continue
            relative_path = item.relative_to(root)
            if not input.include_hidden and is_hidden_path(relative_path):
                continue
            relative_str = relative_path.as_posix()
            if input.case_sensitive:
                name_candidate = item.name
                path_candidate = relative_str
            else:
                name_candidate = item.name.lower()
                path_candidate = relative_str.lower()
            if matcher(name_candidate, pattern) or matcher(path_candidate, pattern):
                matches.append(relative_str)
                if len(matches) >= input.max_results:
                    break
        matches.sort()
        return {"matches": matches, "count": len(matches)}

    return FunctionTool(
        name=name,
        description="Find files in the workspace using glob-style matching.",
        input_model=FindFilesInput,
        func=find_files,
        risk_level="low",
    )
