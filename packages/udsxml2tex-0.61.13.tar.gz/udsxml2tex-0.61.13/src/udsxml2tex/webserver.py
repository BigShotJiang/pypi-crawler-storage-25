"""Local web server providing a browser-based UI for udsxml2tex (--serve mode)."""

from __future__ import annotations

import io
import logging
import os
import shutil
import tempfile
import threading
import webbrowser
import zipfile
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

try:
    from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
    from fastapi.responses import (
        FileResponse, JSONResponse, Response, StreamingResponse,
    )
    import uvicorn
    _FASTAPI_AVAILABLE = True
except ImportError:
    _FASTAPI_AVAILABLE = False

from udsxml2tex import __version__
from udsxml2tex.parser import ArxmlParser
from udsxml2tex.generator import TexGenerator

# Optional modules — imported lazily so missing them doesn't break the server
try:
    from udsxml2tex.validator import UdsValidator  # type: ignore[import]
    _VALIDATOR_AVAILABLE = True
except ImportError:
    _VALIDATOR_AVAILABLE = False

try:
    from udsxml2tex.diff import SpecDiffer  # type: ignore[import]
    _DIFFER_AVAILABLE = True
except ImportError:
    _DIFFER_AVAILABLE = False

_TEMPLATES_DIR = Path(__file__).parent / "templates"
_SAMPLES_DIR = Path(__file__).parent / "samples"

# Session-scoped state for the chat tab.
#   _CHAT_SESSIONS[session_id] = {"spec": <UdsSpecification>, "summary": {...}}
# Cleared on server restart. Single-process; not safe for multi-worker uvicorn —
# acceptable for the local-dev `udsxml2tex --serve` usage pattern.
_CHAT_SESSIONS: dict[str, dict] = {}
_CHAT_SESSIONS_LOCK = threading.Lock()
_CHAT_SESSION_LIMIT = 32  # FIFO eviction of the oldest entries past this

# Session-scoped state for repository auto-discovery uploads.
#   _REPO_SESSIONS[session_id] = {"workdir": Path, "scan": RepoScanResult,
#                                  "mode": "single"|"multi"}
# Each entry owns a temp directory on disk that lives until the session is
# evicted or the server exits. Cleared on server restart.
_REPO_SESSIONS: dict[str, dict] = {}
_REPO_SESSIONS_LOCK = threading.Lock()
_REPO_SESSION_LIMIT = 16

_SAMPLE_META: dict[str, dict] = {
    # `targets` names which input slot accepts the file (purpose-based);
    # `modes` controls which UI mode (single / multi) renders a row at all.
    # ECU1 (primary / gateway in the redundant sample) — also the default
    # fileset for single-ECU mode.
    "sample1_dcm.arxml": {
        "label": "Sample DCM ARXML — ECU1 / primary",
        "description": "Full DCM configuration: sessions, security levels, DIDs, routines, services",
        "type": "arxml",
        "targets": ["primary"],
        "modes": ["single", "multi"],
    },
    "sample1_cantp.arxml": {
        "label": "Sample CanTp ARXML — ECU1 / primary",
        "description": "CAN Transport Protocol channel and PDU configuration (CAN IDs 0x641-0x644)",
        "type": "arxml",
        "targets": ["primary"],
        "modes": ["single", "multi"],
    },
    "sample1_dem.arxml": {
        "label": "Sample DEM ARXML — ECU1 / primary",
        "description": "Diagnostic Event Manager — DTC definitions and severity levels",
        "type": "arxml",
        "targets": ["dem"],
        "modes": ["single", "multi"],
    },
    "sample1_did.c": {
        "label": "Sample DID implementation C code — ECU1 / primary",
        "description": "Example C source with DID read/write functions and global variable references",
        "type": "c",
        "targets": ["did_c"],
        "modes": ["single", "multi"],
    },
    "sample1_rid.c": {
        "label": "Sample RID implementation C code — ECU1 / primary",
        "description": "Example C source with RID start/stop/result functions and global variable references",
        "type": "c",
        "targets": ["rid_c"],
        "modes": ["single", "multi"],
    },
    # ECU2 (secondary / endpoint) — multi-ECU only. Same purpose-based
    # `targets` as sample1_* so the multi-mode samples table can render
    # the same per-purpose ECU1 / ECU2 button pair regardless of which
    # numeric prefix the user picked.
    "sample2_dcm.arxml": {
        "label": "Sample DCM ARXML — ECU2 / secondary",
        "description": "DCM for the secondary MCU; receives gateway-routed calibration DIDs and diagnostic routines",
        "type": "arxml",
        "targets": ["primary"],
        "modes": ["multi"],
    },
    "sample2_cantp.arxml": {
        "label": "Sample CanTp ARXML — ECU2 / secondary",
        "description": "CAN Transport Protocol on the inter-MCU internal bus",
        "type": "arxml",
        "targets": ["primary"],
        "modes": ["multi"],
    },
    "sample2_dem.arxml": {
        "label": "Sample DEM ARXML — ECU2 / secondary",
        "description": "DEM for the secondary MCU; secondary-side DTC values (0x910101 / 0x910202)",
        "type": "arxml",
        "targets": ["dem"],
        "modes": ["multi"],
    },
    "sample2_did.c": {
        "label": "Sample DID implementation C code — ECU2 / secondary",
        "description": "Secondary-ECU DID read/write functions, prefixed g_uds_sec_*",
        "type": "c",
        "targets": ["did_c"],
        "modes": ["multi"],
    },
    "sample2_rid.c": {
        "label": "Sample RID implementation C code — ECU2 / secondary",
        "description": "Secondary-ECU routine start/stop/result functions, prefixed Rtn_Sec_*",
        "type": "c",
        "targets": ["rid_c"],
        "modes": ["multi"],
    },
    "udsspec.cls": {
        "label": "udsspec.cls (LaTeX class file)",
        "description": "Built-in LaTeX document class for UDS specification documents (shared across ECUs in Multi-ECU mode)",
        "type": "cls",
        "targets": ["cls"],
        "modes": ["single", "multi"],
    },
    "system_redundant.yaml": {
        "label": "Sample 1+1 redundant system config (YAML)",
        "description": "Multi-ECU system config: gateway primary + endpoint secondary, with explicit routing rules (paired with sample1_*.arxml/c + sample2_*.arxml/c)",
        "type": "yaml",
        "targets": ["system_yaml"],
        "modes": ["multi"],
    },
}


def _require_fastapi() -> None:
    """Raise ImportError with helpful message if FastAPI is not installed."""
    if not _FASTAPI_AVAILABLE:
        raise ImportError(
            "The web server requires optional dependencies.\n"
            "Install them with:\n\n"
            "    pip install udsxml2tex[web]\n\n"
            "or manually:\n\n"
            "    pip install fastapi uvicorn python-multipart"
        )


def _store_chat_session(spec: object, summary: dict) -> str:
    """Stash a parsed spec under a fresh session ID; returns the ID.

    Evicts the oldest entries when the in-memory store exceeds
    `_CHAT_SESSION_LIMIT`. Threadsafe.
    """
    import secrets
    session_id = secrets.token_urlsafe(16)
    with _CHAT_SESSIONS_LOCK:
        _CHAT_SESSIONS[session_id] = {"spec": spec, "summary": summary}
        # FIFO eviction
        while len(_CHAT_SESSIONS) > _CHAT_SESSION_LIMIT:
            _CHAT_SESSIONS.pop(next(iter(_CHAT_SESSIONS)))
    return session_id


def _get_chat_session(session_id: str) -> Optional[dict]:
    """Retrieve a stashed spec by session ID, or None if expired/unknown."""
    with _CHAT_SESSIONS_LOCK:
        return _CHAT_SESSIONS.get(session_id)


def _store_repo_session(workdir: Path, scan, mode: str) -> str:
    """Stash a repo scan (+ its uploaded workdir) under a fresh session ID."""
    import secrets
    session_id = secrets.token_urlsafe(16)
    with _REPO_SESSIONS_LOCK:
        _REPO_SESSIONS[session_id] = {
            "workdir": workdir, "scan": scan, "mode": mode,
        }
        while len(_REPO_SESSIONS) > _REPO_SESSION_LIMIT:
            evicted = _REPO_SESSIONS.pop(next(iter(_REPO_SESSIONS)))
            shutil.rmtree(evicted["workdir"], ignore_errors=True)
            for d in (evicted.get("_spec_html_sites") or {}).values():
                shutil.rmtree(d, ignore_errors=True)
    return session_id


def _get_repo_session(session_id: str) -> Optional[dict]:
    """Retrieve a stashed repo scan by session ID."""
    with _REPO_SESSIONS_LOCK:
        return _REPO_SESSIONS.get(session_id)


def _safe_relpath(name: str) -> Optional[str]:
    """Sanitise a relative path: rejects absolute paths, ``..``, NULs.

    Used by the /repo/scan endpoint to preserve subdirectory structure
    from the browser's ``webkitRelativePath`` while refusing anything that
    could escape the upload's workdir.
    """
    if not name or "\x00" in name:
        return None
    # Normalise Windows separators that the browser may have produced.
    name = name.replace("\\", "/")
    p = Path(name)
    if p.is_absolute():
        return None
    parts = p.parts
    if not parts or any(part == ".." for part in parts):
        return None
    if any(part in ("", ".") for part in parts):
        return None
    return "/".join(parts)


def _save_upload(upload: "UploadFile", dest: Path) -> None:
    """Save an uploaded file to *dest* on disk."""
    content = upload.file.read()
    dest.write_bytes(content)


def _build_rtm_spec_excerpt(spec: object, traces_to: str) -> str:
    """Pluck out the parsed-ARXML slice relevant to one RTM row.

    Walks the ``traces_to`` tokens (sid:0x10, did:0xF187, ...) and
    serialises the matching elements (sub-functions, NRC list,
    sessions, security levels, DcmDspAccessTiming, DcmDspSession
    timing) as a short Markdown excerpt the LLM can read without
    blowing past its context window. Returns "(spec unavailable)"
    when no spec is bound to the session.
    """
    if spec is None:
        return "(spec unavailable — parse an ARXML first)"
    lines: list[str] = []
    seen: set[str] = set()

    def _hexint(v: str) -> Optional[int]:
        try:
            return int(v, 16) if v.lower().startswith("0x") else int(v)
        except (ValueError, AttributeError):
            return None

    for token in (traces_to or "").split(";"):
        token = token.strip()
        if not token or token in seen:
            continue
        seen.add(token)
        parts = token.split(":")
        if len(parts) < 2:
            continue
        kind = parts[0].lower()
        primary = parts[1]
        primary_int = _hexint(primary)
        if kind == "sid" and primary_int is not None:
            svc = next((s for s in getattr(spec, "services", []) or []
                          if s.service_id == primary_int), None)
            if svc is not None:
                lines.append(f"### SID {svc.service_id_hex} — {svc.short_name}")
                if svc.supported_sessions:
                    lines.append(f"- Sessions: {', '.join(svc.supported_sessions)}")
                if svc.required_security_levels:
                    lines.append(f"- Security: {', '.join(svc.required_security_levels)}")
                if svc.sub_functions:
                    sfs = [f"{sf.sub_function_id_hex} ({sf.short_name})"
                            for sf in svc.sub_functions]
                    lines.append("- Sub-functions: " + ", ".join(sfs))
                if svc.nrc_list:
                    nrcs = [f"0x{n.nrc_code:02X} ({n.nrc_name})"
                             for n in svc.nrc_list]
                    lines.append("- NRCs: " + ", ".join(nrcs))
        elif kind == "did" and primary_int is not None:
            did = next((d for d in getattr(spec, "dids", []) or []
                         if d.did_id == primary_int), None)
            if did is not None:
                lines.append(f"### DID {did.did_id_hex} — {did.short_name}")
                lines.append(
                    f"- Read: {'yes' if did.read_access else 'no'}, "
                    f"Write: {'yes' if did.write_access else 'no'}, "
                    f"Length: {did.total_byte_length or '?'} B"
                )
                if did.supported_sessions:
                    lines.append("- Sessions: " + ", ".join(did.supported_sessions))
        elif kind == "rid" and primary_int is not None:
            rt = next((r for r in getattr(spec, "routines", []) or []
                         if r.routine_id == primary_int), None)
            if rt is not None:
                lines.append(f"### RID {rt.routine_id_hex} — {rt.short_name}")
                lines.append(
                    f"- Start: {rt.start_supported}, "
                    f"Stop: {rt.stop_supported}, "
                    f"Result: {rt.result_supported}"
                )
                if rt.supported_sessions:
                    lines.append("- Sessions: " + ", ".join(rt.supported_sessions))
        elif kind == "dtc" and primary_int is not None:
            dtc = next((d for d in getattr(spec, "dtcs", []) or []
                          if d.dtc_id == primary_int), None)
            if dtc is not None:
                lines.append(f"### DTC {dtc.dtc_id_hex} — {dtc.short_name}")
        elif kind == "session" and primary_int is not None:
            s = next((s for s in getattr(spec, "sessions", []) or []
                        if s.session_id == primary_int), None)
            if s is not None:
                lines.append(f"### Session {s.session_id_hex} — {s.short_name}")
                lines.append(
                    f"- P2_max: {s.p2_server_max} s, "
                    f"P2*_max: {s.p2_star_server_max} s"
                )
        elif kind == "security" and primary_int is not None:
            sec = next((s for s in getattr(spec, "security_levels", []) or []
                          if s.security_level == primary_int), None)
            if sec is not None:
                lines.append(f"### Security Level {sec.security_level_hex} — {sec.short_name}")
                lines.append(
                    f"- Max attempts: {sec.num_max_attempts}, "
                    f"Attempt delay: {sec.attempt_delay} s, "
                    f"Boot delay: {sec.delay_time_on_boot} s, "
                    f"Counter: {'on' if sec.attempt_counter_enabled else 'off'}"
                )

    # Always include session+timing summary because most conditional
    # comments cite P2 / S3 / BS / STmin.
    timings = getattr(spec, "access_timing_rows", []) or []
    if timings:
        lines.append("\n### DcmDspAccessTiming (configured)")
        for t in timings:
            lines.append(
                f"- {t.short_name} ({t.timing_type}): "
                f"P2={t.p2_server_max*1000:.0f}ms "
                f"P2*={t.p2_star_server_max*1000:.0f}ms "
                f"S3={t.s3_server*1000:.0f}ms"
            )
    prot_rows = getattr(spec, "protocol_rows", []) or []
    if prot_rows:
        lines.append("\n### DcmDslProtocolRow")
        for p in prot_rows:
            lines.append(
                f"- {p.short_name}: type={p.protocol_type}, "
                f"priority={p.priority}, preempt_timeout={p.preempt_timeout}s"
            )
    if not lines:
        return "(no matching elements in the parsed spec)"
    return "\n".join(lines)


def _load_session_rtm(workdir: Path, spec: object) -> Optional[object]:
    """Best-effort: build an RtmDocument from CSV/YAML files in workdir.

    Used by the HTML spec routes so the rendered pages can carry RTM
    badges/warning banners without the caller having to thread the
    document through every request. Looks under ``rtm/`` and
    ``_rtm_uploads/`` (the two locations the demo and upload paths
    write to) plus the workdir root itself.
    """
    try:
        from udsxml2tex.rtm import load_rtm_document, match_to_spec
    except Exception:  # noqa: BLE001
        return None
    candidates: list[Path] = []
    for sub in (workdir, workdir / "rtm", workdir / "_rtm_uploads"):
        if not sub.exists():
            continue
        for p in sub.iterdir():
            if not p.is_file():
                continue
            n = p.name.lower()
            if n.endswith(".csv") and "rtm" in n:
                candidates.append(p)
    bib = None
    for sub in (workdir / "rtm", workdir / "_rtm_uploads", workdir):
        if not sub.exists():
            continue
        for p in sub.iterdir():
            n = p.name.lower()
            if (n.endswith(".yaml") or n.endswith(".yml")) and "source" in n:
                bib = p
                break
        if bib is not None:
            break
    if not candidates:
        return None
    try:
        doc = load_rtm_document(candidates, bib)
        match_to_spec(doc, spec)
        return doc
    except Exception:  # noqa: BLE001
        logger.exception("Failed to build RTM doc from workdir %s", workdir)
        return None


def _detect_cjk_render_support() -> tuple[bool, str]:
    """Return ``(ok, reason)``: whether the host xelatex can render CJK.

    The check passes only when *both* ``xeCJK.sty`` is on the LaTeX
    kpathsea search path *and* at least one CJK font from the template's
    fallback chain is installed. When either is missing, the caller drops
    ``ja`` from the lang stack and attaches a notes file pointing at the
    distro-specific install command.
    """
    import subprocess
    try:
        proc = subprocess.run(
            ["kpsewhich", "xeCJK.sty"],
            capture_output=True, text=True, timeout=5, check=False,
        )
        if proc.returncode != 0 or not proc.stdout.strip():
            return False, (
                "xeCJK.sty is not on the LaTeX search path. Install with "
                "'tlmgr install xecjk' or 'apt install texlive-lang-cjk'."
            )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False, (
            "kpsewhich is not on PATH — the LaTeX install appears incomplete."
        )
    candidates = (
        "Noto Serif CJK JP", "Noto Serif CJK SC",
        "IPAexMincho", "IPAMincho",
        "Hiragino Mincho ProN", "YuMincho", "MS Mincho",
    )
    try:
        proc = subprocess.run(
            ["fc-list", ":lang=ja", "family"],
            capture_output=True, text=True, timeout=5, check=False,
        )
        if proc.returncode == 0:
            haystack = proc.stdout
            if any(c in haystack for c in candidates):
                return True, ""
            return False, (
                "No supported Japanese font installed. Install one of "
                + ", ".join(candidates[:3]) + " (or any CJK font)."
            )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return True, ""


def _strip_ja_from_lang(lang_code: str) -> tuple[str, bool]:
    """Drop ``ja`` from a (possibly multilingual) lang code.

    Returns ``(new_code, dropped)``. For ``"en+ja+de"`` returns
    ``("en+de", True)``. For ``"ja"`` falls back to ``"en"``.
    """
    if "+" in lang_code:
        parts = [p for p in lang_code.split("+") if p != "ja"]
        if not parts:
            return "en", True
        if len(parts) == lang_code.count("+") + 1:
            return lang_code, False
        return "+".join(parts), True
    if lang_code == "ja":
        return "en", True
    return lang_code, False


_CJK_FALLBACK_NOTE_TMPL = (
    "Japanese was requested in the Output Languages selection, but this "
    "server's LaTeX install cannot render CJK glyphs.\n"
    "\n"
    "Reason: {reason}\n"
    "\n"
    "Japanese has been dropped from the multilingual label stack so the\n"
    "PDF still compiles cleanly. To get Japanese in the next run,\n"
    "install xeCJK + a CJK font on this server:\n"
    "\n"
    "  Debian/Ubuntu: sudo apt install texlive-lang-cjk fonts-noto-cjk\n"
    "  Fedora/RHEL:   sudo dnf install texlive-xecjk \\\n"
    "                                  google-noto-serif-cjk-jp-fonts\n"
    "  Arch Linux:    sudo pacman -S texlive-langjapanese noto-fonts-cjk\n"
    "  Any TeX Live:  sudo tlmgr install xecjk collection-langjapanese\n"
    "\n"
    "Verify with:\n"
    "  kpsewhich xeCJK.sty        # should print a path\n"
    "  fc-list :lang=ja | head    # should list a CJK font family\n"
)


def _parse_langs_form(langs_form: Optional[str]) -> list[str]:
    """Parse the ``langs`` form field into the list of lang codes the
    generator should be invoked with.

    Two input conventions are accepted:

    * ``"en+ja+de"`` (``+``-joined) — multilingual *single-document*
      mode. The returned list has one element, e.g. ``["en+ja+de"]``,
      so the caller's ``for lang_code in selected_langs`` loop runs
      exactly once. The generator's :class:`Translator` then renders
      every translatable label as a LaTeX-safe stacked
      ``\\makecell[l]{en \\\\ ja \\\\ de}`` block. The browser UI
      defaults to this mode when the user checks 2+ Output Language
      boxes.

    * ``"en,ja,de"`` (``,``-joined) — legacy multi-file mode. The
      returned list contains one monolingual code per item, so the
      caller emits one output document per language (CLI ``--langs``
      and any pre-0.47 client retain this behavior).

    Empty / None means "use the default" (``["en"]``). Unknown codes
    are silently dropped and the resulting order is deduplicated.
    """
    from udsxml2tex.i18n import MONOLINGUAL_LANGS, parse_multilingual_lang
    if not langs_form:
        return ["en"]
    raw = str(langs_form).strip()
    # "+"-joined multilingual single-doc form.
    if "+" in raw and "," not in raw and ";" not in raw:
        parts = parse_multilingual_lang(raw)
        if parts is None:
            return ["en"]
        if len(parts) == 1:
            return parts
        # Hand the multilingual code straight through unchanged so the
        # generator instantiates a single Translator(en+ja+de).
        return [raw]
    # Comma / semicolon-joined legacy multi-file form.
    seen: set[str] = set()
    out: list[str] = []
    for tok in raw.replace(";", ",").split(","):
        code = tok.strip()
        if code in MONOLINGUAL_LANGS and code not in seen:
            seen.add(code)
            out.append(code)
    return out or ["en"]


def _safe_basename(name: str, *, default: Optional[str]) -> Optional[str]:
    """Return the safe basename of `name`, or `default` if it can't be made safe.

    Drops any path components and rejects names that try to escape the work
    directory (`..`) or contain NUL / forward slashes after stripping.
    `default=None` makes a malicious name surface as None for the caller.
    """
    bn = os.path.basename(name).strip()
    if not bn or bn in ("", ".", "..") or "\x00" in bn or "/" in bn or "\\" in bn:
        return default
    return bn


def _sanitize_header(value: str, *, max_len: int = 800) -> str:
    """Coerce an arbitrary string into a single-line HTTP header value.

    Newlines / CR confuse some clients (and risk header splitting), so they
    are collapsed to spaces. Non-printable ASCII / non-Latin-1 bytes are
    replaced with ``?`` since Starlette encodes header values as latin-1.
    """
    s = " ".join(value.split())
    if len(s) > max_len:
        s = s[: max_len - 1] + "…"
    return s.encode("latin-1", "replace").decode("latin-1")


def _build_summary(spec: object) -> dict:
    """Build a JSON-serialisable summary dict from a UdsSpecification."""
    return {
        "ecu_name": spec.ecu_name,
        "protocol_name": spec.protocol_name,
        "session_count": len(spec.sessions),
        "security_level_count": len(spec.security_levels),
        "service_count": len(spec.services),
        "did_count": len(spec.dids),
        "routine_count": len(spec.routines),
        "dtc_count": len(spec.dtcs),
        "memory_range_count": len(spec.memory_ranges),
    }


def _esc(value: object) -> str:
    """Minimal HTML-escape for the summary-page renderer."""
    import html as _html
    if value is None:
        return ""
    return _html.escape(str(value), quote=True)


def _render_summary_page_html(spec: object, *, page_title: str = "") -> str:
    """Render a standalone HTML page with SID/NRC/DID/RID/DTC summary tables.

    Mirrors the per-section overview tables in the LaTeX spec template
    (`uds_spec.tex.j2`): Service Overview, NRC reference, DID Overview,
    Routine Overview, DTC Overview.
    """
    title = page_title or f"UDS Spec Summary — {spec.ecu_name}"

    # --- SID summary -------------------------------------------------
    sid_rows = []
    for svc in sorted(spec.services, key=lambda s: s.service_id):
        sid_rows.append(
            "<tr>"
            f"<td><code>{_esc(svc.service_id_hex)}</code></td>"
            f"<td>{_esc(svc.short_name)}</td>"
            f"<td>{len(svc.sub_functions)}</td>"
            f"<td>{_esc(', '.join(svc.supported_sessions) or '—')}</td>"
            f"<td>{_esc(', '.join(svc.required_security_levels) or '—')}</td>"
            f"<td>{_esc(', '.join(svc.addressing_modes) or '—')}</td>"
            f"<td>{len(svc.nrc_list)}</td>"
            "</tr>"
        )
    sid_html = (
        "<table><thead><tr>"
        "<th>SID</th><th>Service</th><th>Sub-Fn</th>"
        "<th>Sessions</th><th>Security</th><th>Addr</th><th>#NRC</th>"
        "</tr></thead><tbody>"
        + ("".join(sid_rows) or "<tr><td colspan=7 class='empty'>(no services)</td></tr>")
        + "</tbody></table>"
    )

    # --- NRC summary (aggregated across all services) ----------------
    nrc_index: dict[int, dict] = {}
    for svc in spec.services:
        for nrc in svc.nrc_list:
            entry = nrc_index.setdefault(
                nrc.nrc_code,
                {"name": nrc.nrc_name, "desc": nrc.description, "sids": []},
            )
            entry["sids"].append(svc.service_id_hex)
            if not entry["desc"] and nrc.description:
                entry["desc"] = nrc.description
    nrc_rows = []
    for code in sorted(nrc_index):
        e = nrc_index[code]
        nrc_rows.append(
            "<tr>"
            f"<td><code>0x{code:02X}</code></td>"
            f"<td>{_esc(e['name'])}</td>"
            f"<td>{_esc(e['desc'])}</td>"
            f"<td>{_esc(', '.join(sorted(set(e['sids']))))}</td>"
            "</tr>"
        )
    nrc_html = (
        "<table><thead><tr>"
        "<th>NRC</th><th>Name</th><th>Description</th><th>Used by SIDs</th>"
        "</tr></thead><tbody>"
        + ("".join(nrc_rows) or "<tr><td colspan=4 class='empty'>(no NRCs)</td></tr>")
        + "</tbody></table>"
    )

    # --- DID summary -------------------------------------------------
    did_rows = []
    for did in sorted(spec.dids, key=lambda d: d.did_id):
        access = []
        if did.read_access:
            access.append("R")
        if did.write_access:
            access.append("W")
        did_rows.append(
            "<tr>"
            f"<td><code>{_esc(did.did_id_hex)}</code></td>"
            f"<td>{_esc(did.short_name)}</td>"
            f"<td>{'/'.join(access) or '—'}</td>"
            f"<td>{_esc(did.total_byte_length)}</td>"
            f"<td>{_esc(', '.join(did.supported_sessions) or '—')}</td>"
            f"<td>{_esc(', '.join(did.required_security_levels) or '—')}</td>"
            f"<td>{len(did.data_elements)}</td>"
            "</tr>"
        )
    did_html = (
        "<table><thead><tr>"
        "<th>DID</th><th>Name</th><th>Access</th><th>Bytes</th>"
        "<th>Sessions</th><th>Security</th><th>#Elem</th>"
        "</tr></thead><tbody>"
        + ("".join(did_rows) or "<tr><td colspan=7 class='empty'>(no DIDs)</td></tr>")
        + "</tbody></table>"
    )

    # --- RID (Routine) summary --------------------------------------
    rid_rows = []
    for rtn in sorted(spec.routines, key=lambda r: r.routine_id):
        ops = []
        if rtn.start_supported:
            ops.append("Start")
        if rtn.stop_supported:
            ops.append("Stop")
        if rtn.result_supported:
            ops.append("Result")
        rid_rows.append(
            "<tr>"
            f"<td><code>{_esc(rtn.routine_id_hex)}</code></td>"
            f"<td>{_esc(rtn.short_name)}</td>"
            f"<td>{_esc(' / '.join(ops) or '—')}</td>"
            f"<td>{len(rtn.in_parameters)}</td>"
            f"<td>{len(rtn.out_parameters)}</td>"
            f"<td>{_esc(', '.join(rtn.supported_sessions) or '—')}</td>"
            f"<td>{_esc(', '.join(rtn.required_security_levels) or '—')}</td>"
            "</tr>"
        )
    rid_html = (
        "<table><thead><tr>"
        "<th>RID</th><th>Routine</th><th>Operations</th>"
        "<th>In</th><th>Out</th><th>Sessions</th><th>Security</th>"
        "</tr></thead><tbody>"
        + ("".join(rid_rows) or "<tr><td colspan=7 class='empty'>(no routines)</td></tr>")
        + "</tbody></table>"
    )

    # --- DTC summary -------------------------------------------------
    dtc_rows = []
    for dtc in sorted(spec.dtcs, key=lambda d: d.dtc_id):
        dtc_rows.append(
            "<tr>"
            f"<td><code>{_esc(dtc.dtc_id_hex)}</code></td>"
            f"<td>{_esc(dtc.short_name)}</td>"
            f"<td>{_esc(dtc.severity or '—')}</td>"
            f"<td>{_esc(dtc.dtc_kind or '—')}</td>"
            f"<td>{_esc(dtc.priority)}</td>"
            f"<td>{_esc('yes' if dtc.aging_allowed else 'no')}</td>"
            f"<td>{len(dtc.snapshot_records)}</td>"
            f"<td>{len(dtc.extended_data_records)}</td>"
            "</tr>"
        )
    dtc_html = (
        "<table><thead><tr>"
        "<th>DTC</th><th>Name</th><th>Severity</th><th>Kind</th>"
        "<th>Prio</th><th>Aging</th><th>#Snap</th><th>#ExtData</th>"
        "</tr></thead><tbody>"
        + ("".join(dtc_rows) or "<tr><td colspan=8 class='empty'>(no DTCs)</td></tr>")
        + "</tbody></table>"
    )

    # --- Header cards ------------------------------------------------
    header_cards = (
        f"<div class='cards'>"
        f"<div class='card'><div class='k'>ECU</div><div class='v'>{_esc(spec.ecu_name)}</div></div>"
        f"<div class='card'><div class='k'>Protocol</div><div class='v'>{_esc(spec.protocol_name)}</div></div>"
        f"<div class='card'><div class='k'>Sessions</div><div class='v'>{len(spec.sessions)}</div></div>"
        f"<div class='card'><div class='k'>Sec.Levels</div><div class='v'>{len(spec.security_levels)}</div></div>"
        f"<div class='card'><div class='k'>SIDs</div><div class='v'>{len(spec.services)}</div></div>"
        f"<div class='card'><div class='k'>DIDs</div><div class='v'>{len(spec.dids)}</div></div>"
        f"<div class='card'><div class='k'>RIDs</div><div class='v'>{len(spec.routines)}</div></div>"
        f"<div class='card'><div class='k'>DTCs</div><div class='v'>{len(spec.dtcs)}</div></div>"
        f"</div>"
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{_esc(title)}</title>
<style>
  body {{ font-family: Georgia, "Noto Serif", serif; max-width: 1200px;
         margin: 24px auto; padding: 0 20px; color: #1a1a1a;
         background: #fafaf7; }}
  h1 {{ font-size: 22px; border-bottom: 2px solid #333; padding-bottom: 6px;
        margin-top: 0; }}
  h2 {{ font-size: 17px; margin-top: 32px; border-bottom: 1px solid #888;
        padding-bottom: 4px; }}
  .cards {{ display: grid; grid-template-columns: repeat(auto-fit,minmax(120px,1fr));
            gap: 10px; margin: 16px 0 24px; }}
  .card {{ border: 1px solid #ccc; background: #fff; padding: 8px 10px;
           border-radius: 3px; }}
  .card .k {{ font-size: 11px; color: #666; text-transform: uppercase;
              letter-spacing: 0.5px; }}
  .card .v {{ font-size: 16px; font-weight: 600; margin-top: 2px; }}
  table {{ border-collapse: collapse; width: 100%; font-size: 13px;
           background: #fff; }}
  th, td {{ border: 1px solid #ccc; padding: 5px 8px; text-align: left;
            vertical-align: top; }}
  th {{ background: #ececea; font-weight: 600; }}
  tr:nth-child(even) td {{ background: #fafafa; }}
  td.empty {{ text-align: center; color: #888; font-style: italic; }}
  code {{ font-family: "Noto Sans Mono", Consolas, monospace; font-size: 12px;
          background: #f0f0ed; padding: 1px 4px; border-radius: 2px; }}
  .meta {{ color: #666; font-size: 12px; margin-top: -8px; }}
  nav {{ margin: 8px 0 18px; font-size: 13px; }}
  nav a {{ margin-right: 14px; color: #244; text-decoration: none;
           border-bottom: 1px dotted #888; }}
  nav a:hover {{ border-bottom-style: solid; }}
</style>
</head>
<body>
  <h1>{_esc(title)}</h1>
  <div class="meta">Generated by udsxml2tex {__version__}</div>
  <nav>
    <a href="#sid">SID summary</a>
    <a href="#nrc">NRC summary</a>
    <a href="#did">DID summary</a>
    <a href="#rid">RID summary</a>
    <a href="#dtc">DTC summary</a>
  </nav>
  {header_cards}
  <h2 id="sid">SID Summary ({len(spec.services)})</h2>
  {sid_html}
  <h2 id="nrc">NRC Summary ({len(nrc_index)})</h2>
  {nrc_html}
  <h2 id="did">DID Summary ({len(spec.dids)})</h2>
  {did_html}
  <h2 id="rid">RID (Routine) Summary ({len(spec.routines)})</h2>
  {rid_html}
  <h2 id="dtc">DTC Summary ({len(spec.dtcs)})</h2>
  {dtc_html}
</body>
</html>
"""


def _parse_arxml(
    arxml_paths: "Path | list[Path]",
    dem_path: Optional[Path] = None,
    ecu_name: Optional[str] = None,
) -> tuple:
    """Parse ARXML file(s) and return (spec, warnings_list)."""
    parser = ArxmlParser()
    if isinstance(arxml_paths, list) and len(arxml_paths) > 1:
        spec = parser.parse_multi(arxml_paths)
    else:
        path = arxml_paths[0] if isinstance(arxml_paths, list) else arxml_paths
        spec = parser.parse(path)

    if dem_path is not None:
        try:
            from udsxml2tex.dem_parser import DemParser
            DemParser().parse(dem_path, spec)
        except Exception as exc:  # noqa: BLE001
            logger.warning("DEM parse error (non-fatal): %s", exc)

    if ecu_name:
        spec.ecu_name = ecu_name

    warnings = [
        {"section": w.section, "message": w.message}
        for w in parser.warnings
    ]
    return spec, warnings


def _create_app() -> "FastAPI":
    """Build and return the FastAPI application instance."""
    _require_fastapi()

    app = FastAPI(
        title="udsxml2tex Web UI",
        version=__version__,
        description="Browser-based interface for converting AUTOSAR ARXML to UDS specification documents.",
    )

    # ------------------------------------------------------------------
    # GET /  — serve the web UI HTML page
    # ------------------------------------------------------------------

    @app.get("/")
    async def serve_ui() -> FileResponse:
        ui_path = _TEMPLATES_DIR / "web_ui.html"
        if not ui_path.exists():
            raise HTTPException(status_code=404, detail="web_ui.html not found in templates directory")
        # Disable browser caching so template/JS changes during local
        # development are picked up without users needing to hard-reload.
        return FileResponse(
            str(ui_path),
            media_type="text/html",
            headers={
                "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
                "Pragma": "no-cache",
                "Expires": "0",
            },
        )

    # ------------------------------------------------------------------
    # GET /health
    # ------------------------------------------------------------------

    @app.get("/health")
    async def health() -> JSONResponse:
        return JSONResponse({"status": "ok", "version": __version__})

    # ------------------------------------------------------------------
    # GET /samples — list available built-in sample files
    # ------------------------------------------------------------------

    @app.get("/samples")
    async def list_samples() -> JSONResponse:
        items = []
        for name, meta in _SAMPLE_META.items():
            path = _SAMPLES_DIR / name
            items.append({
                "name": name,
                "label": meta["label"],
                "description": meta["description"],
                "type": meta["type"],
                "targets": meta.get("targets", []),
                "modes": meta.get("modes", []),
                "available": path.exists(),
                "size": path.stat().st_size if path.exists() else 0,
            })
        return JSONResponse({"samples": items})

    # ------------------------------------------------------------------
    # GET /samples/{name} — download a built-in sample file
    # ------------------------------------------------------------------

    @app.get("/samples/{name}")
    async def get_sample(name: str) -> Response:
        if name not in _SAMPLE_META:
            raise HTTPException(status_code=404, detail=f"Sample '{name}' not found")
        path = _SAMPLES_DIR / name
        if not path.exists():
            raise HTTPException(status_code=404, detail=f"Sample file '{name}' is missing from installation")
        content = path.read_bytes()
        if name.endswith(".arxml"):
            media_type = "application/xml"
        elif name.endswith((".yaml", ".yml")):
            media_type = "text/yaml"
        else:
            media_type = "text/plain"
        return Response(
            content=content,
            media_type=media_type,
            headers={"Content-Disposition": f'attachment; filename="{name}"'},
        )

    # ------------------------------------------------------------------
    # POST /parse — parse uploaded ARXML and return a JSON summary
    # ------------------------------------------------------------------

    @app.post("/parse")
    async def parse_arxml(
        arxml_files: list[UploadFile] = File(...),
        dem_file: Optional[UploadFile] = File(None),
        ecu_name: Optional[str] = Form(None),
    ) -> JSONResponse:
        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_parse_")
        try:
            arxml_paths: list[Path] = []
            for i, uf in enumerate(arxml_files):
                if uf is not None and uf.filename:
                    p = Path(tmpdir) / f"input_{i}.arxml"
                    _save_upload(uf, p)
                    arxml_paths.append(p)
            if not arxml_paths:
                return JSONResponse({"success": False, "error": "No ARXML file provided"}, status_code=400)

            dem_path: Optional[Path] = None
            if dem_file is not None and dem_file.filename:
                dem_path = Path(tmpdir) / "dem.arxml"
                _save_upload(dem_file, dem_path)

            spec, warnings = _parse_arxml(arxml_paths, dem_path, ecu_name or None)
            summary = _build_summary(spec)
            # Stash the parsed spec under a fresh session ID so the Chat tab
            # can ask questions against it without re-uploading the ARXML.
            session_id = _store_chat_session(spec, summary)
            return JSONResponse({
                "success": True,
                "summary": summary,
                "warnings": warnings,
                "session_id": session_id,
            })
        except Exception as exc:  # noqa: BLE001
            logger.exception("Parse error")
            return JSONResponse({"success": False, "error": str(exc)}, status_code=400)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /generate — parse ARXML and return generated output as download
    # ------------------------------------------------------------------

    @app.post("/generate")
    async def generate_output(
        arxml_files: list[UploadFile] = File(...),
        dem_file: Optional[UploadFile] = File(None),
        format: str = Form("tex"),  # noqa: A002  # "tex" | "pdf" | "html"
        ecu_name: Optional[str] = Form(None),
        langs: Optional[str] = Form(None),
        cls_file: Optional[UploadFile] = File(None),
        did_c_files: Optional[list[UploadFile]] = File(None),
        rid_c_files: Optional[list[UploadFile]] = File(None),
    ) -> Response:
        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_gen_")
        try:
            arxml_paths: list[Path] = []
            for i, uf in enumerate(arxml_files):
                if uf is not None and uf.filename:
                    p = Path(tmpdir) / f"input_{i}.arxml"
                    _save_upload(uf, p)
                    arxml_paths.append(p)
            if not arxml_paths:
                return Response(content="No ARXML file provided", status_code=400)

            dem_path: Optional[Path] = None
            if dem_file is not None and dem_file.filename:
                dem_path = Path(tmpdir) / "dem.arxml"
                _save_upload(dem_file, dem_path)

            spec, _ = _parse_arxml(arxml_paths, dem_path, ecu_name or None)

            # Run C scanner for DID variables if DID C files were provided
            if did_c_files:
                _did_c_paths: list[Path] = []
                for uf in did_c_files:
                    if uf is not None and uf.filename:
                        p = Path(tmpdir) / f"did_c_{uf.filename}"
                        _save_upload(uf, p)
                        _did_c_paths.append(p)
                if _did_c_paths and spec.dids:
                    from udsxml2tex.c_scanner import scan_did_variables
                    scan_did_variables(_did_c_paths, spec.dids)

            # Run C scanner for RID variables if RID C files were provided
            if rid_c_files:
                _rid_c_paths: list[Path] = []
                for uf in rid_c_files:
                    if uf is not None and uf.filename:
                        p = Path(tmpdir) / f"rid_c_{uf.filename}"
                        _save_upload(uf, p)
                        _rid_c_paths.append(p)
                if _rid_c_paths and spec.routines:
                    from udsxml2tex.c_scanner import scan_rid_variables
                    scan_rid_variables(_rid_c_paths, spec.routines)

            safe_name = (spec.ecu_name or "ecu").replace(" ", "_")
            tex_gen = TexGenerator()

            fmt = format.lower()
            if fmt == "pdf":
                # 0.34.7 collapsed the dropdown — `pdf` is now an alias for
                # `tex` (the response zip already includes the compiled
                # spec.pdf). Kept so older API clients still work.
                fmt = "tex"

            selected_langs = _parse_langs_form(langs)
            cjk_note: Optional[str] = None
            if any("ja" in lc.split("+") for lc in selected_langs):
                cjk_ok, cjk_reason = _detect_cjk_render_support()
                if not cjk_ok:
                    new_langs: list[str] = []
                    dropped = False
                    for lc in selected_langs:
                        new_lc, did_drop = _strip_ja_from_lang(lc)
                        new_langs.append(new_lc)
                        dropped = dropped or did_drop
                    if dropped:
                        logger.warning(
                            "Dropped ja from lang stack (%s → %s): %s",
                            selected_langs, new_langs, cjk_reason,
                        )
                        selected_langs = new_langs
                        cjk_note = _CJK_FALLBACK_NOTE_TMPL.format(
                            reason=cjk_reason
                        )
            multi_lang = len(selected_langs) > 1
            pdf_status = "ok"
            pdf_reason = ""

            if fmt == "tex":
                # Structured tex tree + compiled spec.pdf bundled into a
                # single response ZIP. xelatex failure leaves only the
                # tex sources (with an explanatory note added to the zip).
                import subprocess
                import zipfile as _zipfile
                cls_content: Optional[bytes] = None
                if cls_file is not None and cls_file.filename:
                    cls_content = cls_file.file.read()

                out_zip = Path(tmpdir) / f"{safe_name}_uds_spec.zip"
                pdf_errors: list[str] = []
                with _zipfile.ZipFile(out_zip, "w",
                                      _zipfile.ZIP_DEFLATED) as out_zf:
                    for lang_code in selected_langs:
                        tex_dir = Path(tmpdir) / f"tex_src_{lang_code}"
                        tex_dir.mkdir()
                        tmp_zip = Path(tmpdir) / f"tex_tmp_{lang_code}.zip"
                        tex_gen.generate_structured_tex_zip(
                            spec, tmp_zip, cls_content=cls_content,
                            lang=lang_code,
                        )
                        with _zipfile.ZipFile(tmp_zip) as zf:
                            zf.extractall(tex_dir)
                        # xelatex twice for TOC + refs.
                        xelatex_err: Optional[str] = None
                        try:
                            for _ in range(2):
                                subprocess.run(
                                    ["xelatex", "-interaction=nonstopmode",
                                     "root.tex"],
                                    cwd=tex_dir,
                                    capture_output=True,
                                    timeout=60,
                                )
                            if (tex_dir / "root.pdf").exists():
                                shutil.move(
                                    str(tex_dir / "root.pdf"),
                                    str(tex_dir / "spec.pdf"),
                                )
                            else:
                                xelatex_err = (
                                    "xelatex did not produce a PDF — check "
                                    "the structured TeX preamble (xeCJK, "
                                    "Noto Serif CJK JP, biber)."
                                )
                        except FileNotFoundError:
                            xelatex_err = (
                                "xelatex not on PATH — install "
                                "texlive-xetex on the server to get the "
                                "compiled spec.pdf."
                            )
                        except subprocess.TimeoutExpired:
                            xelatex_err = (
                                "xelatex compilation timed out after 60s."
                            )

                        if xelatex_err is not None:
                            (tex_dir / "PDF_NOT_COMPILED.txt").write_text(
                                xelatex_err + "\n", encoding="utf-8"
                            )
                            pdf_errors.append(f"{lang_code}: {xelatex_err}")
                            logger.warning(
                                "PDF compilation skipped (%s): %s",
                                lang_code, xelatex_err,
                            )

                        # Strip xelatex aux files. Preserve root.log on
                        # compile failure so the user can follow the
                        # "Check log file for details" pointer.
                        aux_suffixes = {
                            ".aux", ".out", ".toc",
                            ".bcf", ".run.xml", ".fls",
                            ".fdb_latexmk",
                        }
                        if xelatex_err is None:
                            aux_suffixes.add(".log")
                        for aux in tex_dir.glob("root.*"):
                            if aux.suffix in aux_suffixes:
                                aux.unlink(missing_ok=True)

                        # Pack into the response ZIP — under <lang>/ when
                        # multiple languages were selected, at root otherwise.
                        for f in sorted(tex_dir.rglob("*")):
                            if f.is_file():
                                rel = f.relative_to(tex_dir)
                                arcname = (
                                    Path(lang_code) / rel
                                    if multi_lang else rel
                                )
                                out_zf.write(f, arcname)
                    if cjk_note:
                        out_zf.writestr("JAPANESE_NOT_RENDERED.txt", cjk_note)
                content = out_zip.read_bytes()
                filename = out_zip.name
                media_type = "application/zip"
                if pdf_errors:
                    pdf_status = "error"
                    pdf_reason = " | ".join(pdf_errors)

            elif fmt == "html":
                # generate_html_zip doesn't yet take a `lang` kwarg —
                # bundled HTML pages are language-agnostic except for the
                # overlay sections (which generate_html_zip doesn't render).
                # When multiple languages are requested we still namespace
                # the output under <lang>/ subfolders so the response
                # structure stays consistent with the tex flow.
                out_zip = Path(tmpdir) / f"{safe_name}_uds_spec_html.zip"
                if multi_lang:
                    import zipfile as _zipfile
                    with _zipfile.ZipFile(out_zip, "w",
                                          _zipfile.ZIP_DEFLATED) as out_zf:
                        for lang_code in selected_langs:
                            per_zip = (
                                Path(tmpdir)
                                / f"html_{lang_code}.zip"
                            )
                            tex_gen.generate_html_zip(spec, per_zip)
                            with _zipfile.ZipFile(per_zip) as src:
                                for name in src.namelist():
                                    data = src.read(name)
                                    out_zf.writestr(
                                        f"{lang_code}/{name}", data,
                                    )
                else:
                    tex_gen.generate_html_zip(spec, out_zip)
                content = out_zip.read_bytes()
                filename = out_zip.name
                media_type = "application/zip"

            else:
                return JSONResponse(
                    {"success": False, "error": f"Unknown format: {format}. Supported: tex, pdf, html"},
                    status_code=400,
                )

            gen_headers = {
                "Content-Disposition":
                    f'attachment; filename="{filename}"',
                "X-PDF-Compile-Status": pdf_status,
                "Access-Control-Expose-Headers": (
                    "Content-Disposition, X-PDF-Compile-Status, "
                    "X-PDF-Compile-Reason, X-CJK-Status, X-CJK-Reason"
                ),
            }
            if pdf_reason:
                gen_headers["X-PDF-Compile-Reason"] = (
                    _sanitize_header(pdf_reason)
                )
            if cjk_note:
                gen_headers["X-CJK-Status"] = "ja_dropped"
                gen_headers["X-CJK-Reason"] = _sanitize_header(cjk_reason)
            return Response(
                content=content,
                media_type=media_type,
                headers=gen_headers,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("Generate error")
            return JSONResponse({"success": False, "error": str(exc)}, status_code=400)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /repo/scan — receive a folder upload, classify ARXML/C files,
    # auto-detect single vs multi-ECU mode, return scan summary +
    # session_id for the follow-up /repo/generate call.
    # ------------------------------------------------------------------

    @app.post("/repo/scan")
    async def repo_scan(
        files: list[UploadFile] = File(...),
    ) -> JSONResponse:
        """Receive a BSW repository upload and classify its files.

        Browser side: pick a folder with ``<input type="file"
        webkitdirectory>`` and POST each file using its
        ``webkitRelativePath`` as the multipart filename. The server
        rebuilds the tree under a temp directory and runs
        :func:`repo_scanner.scan_repo`.

        Response::

            {
              "session_id": "<token>",
              "mode": "single" | "multi",
              "summary": "...",
              "ecus": [{"name": ..., "dcm": N, "cantp": N, "dem": N,
                        "doip": N, "c": N}],
              "missing_modules": ["..."],
              "cls_files": ["..."],
              "warnings": ["..."]
            }

        ``session_id`` is the handle to pass to ``/repo/generate``. The
        server holds at most :data:`_REPO_SESSION_LIMIT` sessions; the
        oldest is evicted (and its tempdir removed) when the limit is hit.
        """
        from udsxml2tex.repo_scanner import (
            detect_ecu_mode,
            partition_by_ecu,
            scan_repo,
        )

        workdir = Path(tempfile.mkdtemp(prefix="udsxml2tex_repo_"))
        saved_count = 0
        try:
            for uf in files:
                if uf is None or not uf.filename:
                    continue
                rel = _safe_relpath(uf.filename)
                if rel is None:
                    shutil.rmtree(workdir, ignore_errors=True)
                    return JSONResponse(
                        {"error": f"Rejected unsafe filename: {uf.filename!r}"},
                        status_code=400,
                    )
                dest = workdir / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                _save_upload(uf, dest)
                saved_count += 1

            if saved_count == 0:
                shutil.rmtree(workdir, ignore_errors=True)
                return JSONResponse(
                    {"error": "No files uploaded."}, status_code=400,
                )

            try:
                scan = scan_repo(workdir)
            except Exception as exc:  # noqa: BLE001
                logger.exception("repo_scan: scan_repo failed")
                shutil.rmtree(workdir, ignore_errors=True)
                return JSONResponse(
                    {"error": f"scan_repo failed: {exc}"}, status_code=500,
                )

            partitions = partition_by_ecu(scan)
            mode = "multi" if len(partitions) >= 2 else "single"

            if not scan.dcm_arxmls:
                shutil.rmtree(workdir, ignore_errors=True)
                return JSONResponse(
                    {
                        "error": (
                            "No Dcm module configuration found in the "
                            "uploaded files. Need at least one ARXML with an "
                            "ECUC-MODULE-CONFIGURATION-VALUES containing a "
                            "Dcm SHORT-NAME."
                        ),
                        "summary": scan.summary(),
                    },
                    status_code=400,
                )

            ecus_payload = [
                {
                    "name": p.name,
                    "dcm": len(p.dcm_arxmls),
                    "cantp": len(p.cantp_arxmls),
                    "dem": len(p.dem_arxmls),
                    "doip": len(p.doip_arxmls),
                    "c": len(p.c_files),
                    "has_minimum_set": p.has_minimum_set,
                }
                for p in partitions
            ]

            session_id = _store_repo_session(workdir, scan, mode)
            warnings: list[str] = []
            if scan.missing_modules:
                warnings.append(
                    f"Missing modules: {', '.join(scan.missing_modules)}"
                )
            if scan.cls_files:
                warnings.append(
                    f"{len(scan.cls_files)} .cls file(s) detected — these "
                    f"are NOT auto-loaded. Upload one via the 'LaTeX class' "
                    f"slot below to use it."
                )

            return JSONResponse({
                "session_id": session_id,
                "mode": mode,
                "summary": scan.summary(),
                "ecus": ecus_payload,
                "missing_modules": scan.missing_modules,
                "cls_files": [str(p.relative_to(workdir)) for p in scan.cls_files],
                "uploaded_files": saved_count,
                "warnings": warnings,
            })
        except Exception:
            shutil.rmtree(workdir, ignore_errors=True)
            raise

    # ------------------------------------------------------------------
    # POST /repo/scan-demo — server-side one-click load of the bundled
    # demo repo + Requirements Traceability Matrix (RTM) CSVs (no
    # upload needed).
    # ------------------------------------------------------------------

    @app.post("/repo/scan-demo")
    async def repo_scan_demo(bundle: str = Form("single")) -> JSONResponse:
        """Materialise the bundled demo repo + RTM CSVs in a temp dir,
        run scan_repo on the repo half, and return the usual /repo/scan
        payload extended with rtm_csvs + rtm_bib pointing at the copied
        files on the server filesystem.

        ``bundle`` selects the demo flavour:

        * ``single`` (default) — one-MCU ECU made of sample1_*.arxml +
          sample1_*.c, placed flat under ``demo-repo/`` so the scanner
          produces a single-ECU partition.
        * ``redundant`` — two-MCU 1+1 redundant pair built from
          sample1_* (primary, tester-facing) and sample2_* (secondary,
          gateway-routed). Each MCU lives under its own top-level
          ``primary/`` / ``secondary/`` segment so the scanner's
          per-ECU partitioner produces a 2-ECU layout.
        """
        from udsxml2tex.repo_scanner import partition_by_ecu, scan_repo

        bundle = (bundle or "single").lower().strip()
        if bundle not in ("single", "redundant"):
            return JSONResponse(
                {"error": f"Unknown bundle {bundle!r}; expected "
                          "'single' or 'redundant'."},
                status_code=400,
            )
        if bundle == "redundant":
            repo_files = {
                "demo-repo/primary/arxml/sample1_dcm.arxml":   "sample1_dcm.arxml",
                "demo-repo/primary/arxml/sample1_cantp.arxml": "sample1_cantp.arxml",
                "demo-repo/primary/arxml/sample1_dem.arxml":   "sample1_dem.arxml",
                "demo-repo/primary/src/sample1_did.c":         "sample1_did.c",
                "demo-repo/primary/src/sample1_rid.c":         "sample1_rid.c",
                "demo-repo/secondary/arxml/sample2_dcm.arxml":   "sample2_dcm.arxml",
                "demo-repo/secondary/arxml/sample2_cantp.arxml": "sample2_cantp.arxml",
                "demo-repo/secondary/arxml/sample2_dem.arxml":   "sample2_dem.arxml",
                "demo-repo/secondary/src/sample2_did.c":         "sample2_did.c",
                "demo-repo/secondary/src/sample2_rid.c":         "sample2_rid.c",
            }
        else:
            repo_files = {
                "demo-repo/arxml/sample1_dcm.arxml":   "sample1_dcm.arxml",
                "demo-repo/arxml/sample1_cantp.arxml": "sample1_cantp.arxml",
                "demo-repo/arxml/sample1_dem.arxml":   "sample1_dem.arxml",
                "demo-repo/src/sample1_did.c":         "sample1_did.c",
                "demo-repo/src/sample1_rid.c":         "sample1_rid.c",
            }
        rtm_sample_files = {
            "rtm/rtm_oem_docan_standard.csv": "rtm_oem_docan_standard.csv",
            "rtm/rtm_oem_docan_ecu.csv":      "rtm_oem_docan_ecu.csv",
            "rtm/rtm_oem_did.csv":            "rtm_oem_did.csv",
            "rtm/rtm_oem_rid.csv":            "rtm_oem_rid.csv",
            "rtm/rtm_oem_dtc.csv":            "rtm_oem_dtc.csv",
            "rtm/rtm_oem_reprogramming.csv":  "rtm_oem_reprogramming.csv",
            "rtm/rtm_oem_annex.csv":          "rtm_oem_annex.csv",
            "rtm/rtm_supplier_sample.csv":    "rtm_supplier_sample.csv",
            "rtm/rtm_sources_sample.yaml":    "rtm_sources_sample.yaml",
        }
        # RTM samples may be missing on older / partial installs —
        # skip gracefully rather than failing the demo button.
        rtm_sample_files = {
            k: v for k, v in rtm_sample_files.items()
            if (_SAMPLES_DIR / v).exists()
        }

        missing_repo = [v for v in repo_files.values()
                        if not (_SAMPLES_DIR / v).exists()]
        if missing_repo:
            return JSONResponse(
                {"error": f"Missing bundled sample(s): {', '.join(missing_repo)}"},
                status_code=500,
            )

        workdir = Path(tempfile.mkdtemp(prefix="udsxml2tex_repo_demo_"))
        try:
            for rel, src in repo_files.items():
                dest = workdir / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes((_SAMPLES_DIR / src).read_bytes())
            for rel, src in rtm_sample_files.items():
                dest = workdir / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes((_SAMPLES_DIR / src).read_bytes())

            try:
                scan = scan_repo(workdir / "demo-repo")
            except Exception as exc:  # noqa: BLE001
                logger.exception("repo_scan_demo: scan_repo failed")
                shutil.rmtree(workdir, ignore_errors=True)
                return JSONResponse(
                    {"error": f"scan_repo failed: {exc}"}, status_code=500,
                )

            partitions = partition_by_ecu(scan)
            mode = "multi" if len(partitions) >= 2 else "single"
            session_id = _store_repo_session(workdir, scan, mode)
            ecus_payload = [
                {
                    "name": p.name,
                    "dcm": len(p.dcm_arxmls),
                    "cantp": len(p.cantp_arxmls),
                    "dem": len(p.dem_arxmls),
                    "c": len(p.c_files),
                    "has_minimum_set": p.has_minimum_set,
                }
                for p in partitions
            ]
            rtm_dir = workdir / "rtm"
            rtm_csvs = [
                str(rtm_dir / "rtm_oem_docan_standard.csv"),
                str(rtm_dir / "rtm_oem_docan_ecu.csv"),
                str(rtm_dir / "rtm_oem_did.csv"),
                str(rtm_dir / "rtm_oem_rid.csv"),
                str(rtm_dir / "rtm_oem_dtc.csv"),
                str(rtm_dir / "rtm_oem_reprogramming.csv"),
                str(rtm_dir / "rtm_oem_annex.csv"),
                str(rtm_dir / "rtm_supplier_sample.csv"),
            ] if rtm_sample_files else []
            rtm_bib = str(rtm_dir / "rtm_sources_sample.yaml") \
                if rtm_sample_files else None
            return JSONResponse({
                "session_id": session_id,
                "mode": mode,
                "summary": scan.summary(),
                "ecus": ecus_payload,
                "missing_modules": scan.missing_modules,
                "cls_files": [],
                "uploaded_files": len(repo_files),
                "warnings": [],
                "rtm_csvs": rtm_csvs,
                "rtm_bib": rtm_bib,
                "is_demo": True,
            })
        except Exception:
            shutil.rmtree(workdir, ignore_errors=True)
            raise

    # ------------------------------------------------------------------
    # POST /repo/parse — parse the repo session into a UdsSpecification
    # and return a /parse-style summary. Auto-detects single/multi-ECU
    # the same way /repo/generate does and also stashes the resulting
    # spec for the chat tab (mirrors /parse).
    # ------------------------------------------------------------------

    @app.post("/repo/parse")
    async def repo_parse(
        session_id: str = Form(...),
        mode: str = Form("auto"),  # auto / single / multi
    ) -> JSONResponse:
        """Return a parsed-spec summary for a repo session.

        Single-ECU response shape mirrors /parse exactly so the Generate-
        tab Parse&Preview UI can reuse the same renderer. Multi-ECU
        responses add an ``ecus`` array with one summary per ECU.
        """
        from udsxml2tex.repo_scanner import (
            load_from_repo,
            load_system_from_repo,
        )

        session = _get_repo_session(session_id)
        if session is None:
            return JSONResponse(
                {"success": False,
                 "error": "Unknown or expired session_id. Re-run /repo/scan."},
                status_code=400,
            )
        workdir: Path = session["workdir"]
        if not workdir.exists():
            return JSONResponse(
                {"success": False,
                 "error": "Session workdir no longer exists."},
                status_code=400,
            )

        requested = (mode or "auto").lower()
        effective_mode = (
            requested if requested in ("single", "multi")
            else session["mode"]
        )

        try:
            if effective_mode == "multi":
                system, _, _ = load_system_from_repo(workdir)
                if not system.ecus:
                    return JSONResponse(
                        {"success": False,
                         "error": "No ECUs were partitioned from the repo."},
                        status_code=400,
                    )
                ecu_summaries = [
                    {"name": name, **_build_summary(cfg.spec)}
                    for name, cfg in system.ecus.items() if cfg.spec
                ]
                # Stash the FIRST ECU's spec in a chat session so the user
                # can ask questions; record the rest in `ecus` for the UI.
                first_spec = next(
                    (cfg.spec for cfg in system.ecus.values() if cfg.spec),
                    None,
                )
                chat_sid = (
                    _store_chat_session(first_spec, ecu_summaries[0])
                    if first_spec else None
                )
                return JSONResponse({
                    "success": True,
                    "mode": "multi",
                    "ecus": ecu_summaries,
                    "summary": ecu_summaries[0] if ecu_summaries else {},
                    "session_id": chat_sid,
                    "warnings": [],
                })

            # Single-ECU path
            spec, _ = load_from_repo(workdir)
            summary = _build_summary(spec)
            chat_sid = _store_chat_session(spec, summary)
            return JSONResponse({
                "success": True,
                "mode": "single",
                "summary": summary,
                "session_id": chat_sid,
                "warnings": [],
            })
        except Exception as exc:  # noqa: BLE001
            logger.exception("repo_parse failed")
            return JSONResponse(
                {"success": False, "error": f"Parse failed: {exc}"},
                status_code=500,
            )

    # ------------------------------------------------------------------
    # GET /repo/summary-page — full SID / NRC / DID / RID / DTC summary
    # rendered as a standalone HTML page (opened in a new browser tab by
    # the Parse & Preview button when parsing succeeds).
    # ------------------------------------------------------------------

    @app.get("/repo/summary-page")
    async def repo_summary_page(
        session_id: str,
        ecu: Optional[str] = None,
        mode: str = "auto",
    ) -> Response:
        from udsxml2tex.repo_scanner import (
            load_from_repo,
            load_system_from_repo,
        )

        session = _get_repo_session(session_id)
        if session is None:
            return Response(
                "<h1>Session expired</h1><p>Please re-upload the repository.</p>",
                media_type="text/html; charset=utf-8",
                status_code=400,
            )
        workdir: Path = session["workdir"]
        if not workdir.exists():
            return Response(
                "<h1>Session workdir missing</h1>",
                media_type="text/html; charset=utf-8",
                status_code=400,
            )

        requested = (mode or "auto").lower()
        effective_mode = (
            requested if requested in ("single", "multi")
            else session["mode"]
        )

        try:
            if effective_mode == "multi":
                system, _, _ = load_system_from_repo(workdir)
                ecus_with_spec = [
                    (n, c.spec) for n, c in system.ecus.items() if c.spec
                ]
                if not ecus_with_spec:
                    return Response(
                        "<h1>No ECUs parsed</h1>",
                        media_type="text/html; charset=utf-8",
                        status_code=400,
                    )
                # Pick requested ECU or default to the first.
                picked = next(
                    ((n, s) for n, s in ecus_with_spec if n == ecu),
                    ecus_with_spec[0],
                )
                name, spec = picked
                # Top-of-page picker links for other ECUs.
                links = " · ".join(
                    f"<a href='/repo/summary-page?session_id={session_id}"
                    f"&ecu={n}&mode=multi'>{_esc(n)}"
                    f"{'  (current)' if n == name else ''}</a>"
                    for n, _ in ecus_with_spec
                )
                body = _render_summary_page_html(
                    spec, page_title=f"UDS Spec Summary — {name}"
                )
                # Inject an ECU picker below the meta line.
                body = body.replace(
                    "<nav>",
                    f"<div class='meta'>Multi-ECU: {links}</div><nav>",
                    1,
                )
                return Response(body, media_type="text/html; charset=utf-8")

            spec, _ = load_from_repo(workdir)
            return Response(
                _render_summary_page_html(spec),
                media_type="text/html; charset=utf-8",
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("repo_summary_page failed")
            return Response(
                f"<h1>Summary failed</h1><pre>{_esc(exc)}</pre>",
                media_type="text/html; charset=utf-8",
                status_code=500,
            )

    # ------------------------------------------------------------------
    # GET /repo/spec-html/{session_id}/{path:path} — serve a file from
    # the multi-page HTML rendition of the parsed spec. The full site is
    # generated once on first hit and cached in a session-scoped temp
    # dir so subsequent navigations (clicking the in-sidebar Spec TOC)
    # are cheap.
    # ------------------------------------------------------------------

    @app.get("/repo/spec-html/{session_id}/{file_path:path}")
    async def repo_spec_html(
        session_id: str,
        file_path: str,
        ecu: Optional[str] = None,
        mode: str = "auto",
    ) -> Response:
        import tempfile, zipfile
        from udsxml2tex.generator import TexGenerator
        from udsxml2tex.repo_scanner import (
            load_from_repo,
            load_system_from_repo,
        )

        session = _get_repo_session(session_id)
        if session is None:
            return Response(
                "<h1>Session expired</h1>",
                media_type="text/html; charset=utf-8",
                status_code=400,
            )

        # Cache the extracted site per (session, mode) tuple. The legacy
        # per-ECU split (one site per `ecu=` value in multi mode) was
        # removed — multi mode now always renders a single unified
        # system bundle that includes every ECU.
        requested = (mode or "auto").lower()
        effective_mode = (
            requested if requested in ("single", "multi")
            else session["mode"]
        )
        cache_key = effective_mode
        site_cache = session.setdefault("_spec_html_sites", {})
        site_dir: Optional[Path] = site_cache.get(cache_key)
        if site_dir is None or not site_dir.exists():
            try:
                site_dir = Path(tempfile.mkdtemp(prefix="udsxml2tex_spec_site_"))
                with tempfile.TemporaryDirectory() as zip_tmp:
                    zip_path = Path(zip_tmp) / "spec.zip"
                    if effective_mode == "multi":
                        system, _, _ = load_system_from_repo(session["workdir"])
                        ecus_with_spec = [
                            (n, c.spec) for n, c in system.ecus.items() if c.spec
                        ]
                        if not ecus_with_spec:
                            return Response("<h1>No ECUs parsed</h1>",
                                            media_type="text/html; charset=utf-8",
                                            status_code=400)
                        first_spec = ecus_with_spec[0][1]
                        rtm_doc = _load_session_rtm(session["workdir"], first_spec)
                        from udsxml2tex.multi_ecu import generate_system_html_zip
                        generate_system_html_zip(system, zip_path, rtm=rtm_doc)
                    else:
                        spec, _ = load_from_repo(session["workdir"])
                        rtm_doc = _load_session_rtm(session["workdir"], spec)
                        TexGenerator().generate_html_zip(spec, zip_path, rtm=rtm_doc)
                    with zipfile.ZipFile(zip_path) as zf:
                        zf.extractall(site_dir)
                site_cache[cache_key] = site_dir
            except Exception as exc:  # noqa: BLE001
                logger.exception("repo_spec_html generation failed")
                return Response(
                    f"<h1>Spec render failed</h1><pre>{_esc(exc)}</pre>",
                    media_type="text/html; charset=utf-8",
                    status_code=500,
                )

        # Default to index.html when no specific path is given.
        rel = file_path or "index.html"
        target = (site_dir / rel).resolve()
        # Reject path traversal escapes outside the site dir.
        try:
            target.relative_to(site_dir.resolve())
        except ValueError:
            return Response("Forbidden", status_code=403)
        if not target.is_file():
            return Response(f"<h1>Not found</h1><p>{_esc(rel)}</p>",
                            media_type="text/html; charset=utf-8",
                            status_code=404)

        suffix = target.suffix.lower()
        media = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
        }.get(suffix, "application/octet-stream")
        return Response(target.read_bytes(), media_type=media)

    # ------------------------------------------------------------------
    # GET /repo/spec-html-zip — download the multi-page HTML rendition
    # of the parsed spec packaged as a ZIP. Wired to the Spec toolbar's
    # download button in web_ui.html.
    # ------------------------------------------------------------------

    @app.get("/repo/spec-html-zip")
    async def repo_spec_html_zip(
        session_id: str,
        ecu: Optional[str] = None,
        mode: str = "auto",
    ) -> Response:
        import tempfile
        from udsxml2tex.generator import TexGenerator
        from udsxml2tex.repo_scanner import (
            load_from_repo,
            load_system_from_repo,
        )

        session = _get_repo_session(session_id)
        if session is None:
            return JSONResponse({"error": "Session expired"}, status_code=400)
        workdir: Path = session["workdir"]
        if not workdir.exists():
            return JSONResponse({"error": "Session workdir missing"}, status_code=400)

        requested = (mode or "auto").lower()
        effective_mode = (
            requested if requested in ("single", "multi")
            else session["mode"]
        )

        try:
            if effective_mode == "multi":
                system, _, _ = load_system_from_repo(workdir)
                ecus_with_spec = [
                    (n, c.spec) for n, c in system.ecus.items() if c.spec
                ]
                if not ecus_with_spec:
                    return JSONResponse({"error": "No ECUs parsed"}, status_code=400)
                base_name = "system_uds_spec_html"
                first_spec = ecus_with_spec[0][1]
                rtm_doc = _load_session_rtm(workdir, first_spec)
                with tempfile.TemporaryDirectory() as tmpdir:
                    zip_path = Path(tmpdir) / f"{base_name}.zip"
                    from udsxml2tex.multi_ecu import generate_system_html_zip
                    generate_system_html_zip(system, zip_path, rtm=rtm_doc)
                    payload = zip_path.read_bytes()
                return Response(
                    payload,
                    media_type="application/zip",
                    headers={
                        "Content-Disposition": f'attachment; filename="{base_name}.zip"',
                    },
                )
            else:
                spec, _ = load_from_repo(workdir)
                base_name = "uds_spec_html"

            with tempfile.TemporaryDirectory() as tmpdir:
                zip_path = Path(tmpdir) / f"{base_name}.zip"
                rtm_doc = _load_session_rtm(workdir, spec)
                TexGenerator().generate_html_zip(spec, zip_path, rtm=rtm_doc)
                payload = zip_path.read_bytes()
            return Response(
                payload,
                media_type="application/zip",
                headers={
                    "Content-Disposition": f'attachment; filename="{base_name}.zip"',
                },
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("repo_spec_html_zip failed")
            return JSONResponse({"error": str(exc)}, status_code=500)

    # ------------------------------------------------------------------
    # GET /repo/spec-page — full single-page HTML rendition of the parsed
    # specification (the "HTML版仕様書"). Opened in a new browser tab from
    # the Summary toolbar when a parse has succeeded.
    # ------------------------------------------------------------------

    @app.get("/repo/spec-page")
    async def repo_spec_page(
        session_id: str,
        ecu: Optional[str] = None,
        mode: str = "auto",
    ) -> Response:
        import tempfile
        from udsxml2tex.generator import TexGenerator
        from udsxml2tex.repo_scanner import (
            load_from_repo,
            load_system_from_repo,
        )

        session = _get_repo_session(session_id)
        if session is None:
            return Response(
                "<h1>Session expired</h1><p>Please re-upload the repository.</p>",
                media_type="text/html; charset=utf-8",
                status_code=400,
            )
        workdir: Path = session["workdir"]
        if not workdir.exists():
            return Response(
                "<h1>Session workdir missing</h1>",
                media_type="text/html; charset=utf-8",
                status_code=400,
            )

        requested = (mode or "auto").lower()
        effective_mode = (
            requested if requested in ("single", "multi")
            else session["mode"]
        )

        try:
            if effective_mode == "multi":
                system, _, _ = load_system_from_repo(workdir)
                ecus_with_spec = [
                    (n, c.spec) for n, c in system.ecus.items() if c.spec
                ]
                if not ecus_with_spec:
                    return Response(
                        "<h1>No ECUs parsed</h1>",
                        media_type="text/html; charset=utf-8",
                        status_code=400,
                    )
                picked = next(
                    ((n, s) for n, s in ecus_with_spec if n == ecu),
                    ecus_with_spec[0],
                )
                _, spec = picked
            else:
                spec, _ = load_from_repo(workdir)

            with tempfile.TemporaryDirectory() as tmpdir:
                out = Path(tmpdir) / "uds_spec.html"
                TexGenerator().generate_html(spec, out)
                html = out.read_text(encoding="utf-8")
            return Response(html, media_type="text/html; charset=utf-8")
        except Exception as exc:  # noqa: BLE001
            logger.exception("repo_spec_page failed")
            return Response(
                f"<h1>Spec render failed</h1><pre>{_esc(exc)}</pre>",
                media_type="text/html; charset=utf-8",
                status_code=500,
            )

    # ------------------------------------------------------------------
    # POST /repo/generate — generate the UDS spec for a previously
    # scanned repository session. Auto-dispatches single/multi-ECU based
    # on the detected mode (or the explicit `mode` override).
    # ------------------------------------------------------------------

    @app.post("/repo/generate")
    async def repo_generate(
        session_id: str = Form(...),
        format: str = Form("tex"),  # noqa: A002
        mode: str = Form("auto"),  # auto / single / multi
        ecu_name: Optional[str] = Form(None),
        langs: Optional[str] = Form(None),
        cls_file: Optional[UploadFile] = File(None),
        rtm_files: Optional[list[UploadFile]] = File(None),
        rtm_bib_file: Optional[UploadFile] = File(None),
        rtm_server_paths: Optional[str] = Form(None),
        rtm_bib_server_path: Optional[str] = Form(None),
    ) -> Response:
        """Generate the UDS specification from a previously scanned repo.

        Reuses the workdir created by :func:`repo_scan`. Output is a ZIP
        for tex / html (multi-ECU always returns a ZIP with per-ECU + a
        system integration document), or the raw file content for the
        single-file formats md / rst / yaml / json.
        """
        from udsxml2tex.repo_scanner import (
            load_from_repo,
            load_system_from_repo,
        )

        session = _get_repo_session(session_id)
        if session is None:
            return JSONResponse(
                {"error": "Unknown or expired session_id. Re-run /repo/scan."},
                status_code=400,
            )
        workdir: Path = session["workdir"]
        if not workdir.exists():
            return JSONResponse(
                {"error": "Session workdir no longer exists."},
                status_code=400,
            )

        requested_mode = (mode or "auto").lower()
        effective_mode = (
            requested_mode if requested_mode in ("single", "multi")
            else session["mode"]
        )

        fmt = (format or "tex").strip().lower()
        if fmt == "pdf":
            fmt = "tex"

        # The custom .cls (when uploaded) is forwarded by writing it to a
        # known path in the workdir, then handing TexGenerator the bytes
        # via the structured-tex generator's `cls_content=` parameter.
        custom_cls_bytes: Optional[bytes] = None
        if cls_file is not None and cls_file.filename:
            custom_cls_bytes = cls_file.file.read()

        # RTM: collect uploaded CSV / YAML payloads into a workdir tree
        # plus the server-side paths from /repo/scan-demo (if any), then
        # load them into a single RtmDocument that gets joined against
        # the parsed spec via match_to_spec().
        rtm_doc = None
        try:
            from udsxml2tex.rtm import load_rtm_document, match_to_spec
            rtm_csv_paths: list[Path] = []
            rtm_bib_path: Optional[Path] = None
            rtm_workdir = workdir / "_rtm_uploads"
            if rtm_files or rtm_bib_file:
                rtm_workdir.mkdir(exist_ok=True)
            if rtm_files:
                for up in rtm_files:
                    if up is None or not up.filename:
                        continue
                    dest = rtm_workdir / Path(up.filename).name
                    dest.write_bytes(up.file.read())
                    rtm_csv_paths.append(dest)
            if rtm_bib_file is not None and rtm_bib_file.filename:
                rtm_bib_path = rtm_workdir / Path(rtm_bib_file.filename).name
                rtm_bib_path.write_bytes(rtm_bib_file.file.read())
            if rtm_server_paths:
                for raw in rtm_server_paths.split(","):
                    p = Path(raw.strip())
                    if p.exists():
                        rtm_csv_paths.append(p)
            if rtm_bib_server_path:
                p = Path(rtm_bib_server_path.strip())
                if p.exists() and rtm_bib_path is None:
                    rtm_bib_path = p
            if rtm_csv_paths:
                rtm_doc = load_rtm_document(rtm_csv_paths, rtm_bib_path)
        except Exception as exc:  # noqa: BLE001
            logger.warning("RTM load failed (chapter will be omitted): %s", exc)
            rtm_doc = None

        try:
            if effective_mode == "multi":
                system, _, _ = load_system_from_repo(workdir)
                # Optional ECU-name override applied to the first ECU's
                # spec so it shows in the integration document header.
                if ecu_name and system.ecus:
                    first = next(iter(system.ecus.values()))
                    if first.spec is not None:
                        first.spec.ecu_name = ecu_name

                out_dir = workdir / "_out"
                if out_dir.exists():
                    shutil.rmtree(out_dir)
                out_dir.mkdir()

                # Reuse the same code path the /system endpoint uses.
                pdf_status = "ok"
                pdf_reason = ""
                if fmt in ("tex", "html"):
                    from udsxml2tex.multi_ecu import (
                        generate_system_html_zip,
                        generate_system_structured_tex_zip,
                    )
                    sys_zip = out_dir / "system_uds_spec.zip"
                    if fmt == "tex":
                        generate_system_structured_tex_zip(
                            system, sys_zip, cls_content=custom_cls_bytes,
                        )
                        # Extract → compile root.tex → repack with PDF.
                        # Failures are non-fatal; .tex sources still ship.
                        import zipfile as _zipfile
                        sys_dir = out_dir / "_sys_src"
                        if sys_dir.exists():
                            shutil.rmtree(sys_dir)
                        sys_dir.mkdir()
                        with _zipfile.ZipFile(sys_zip) as zf:
                            zf.extractall(sys_dir)
                        root_tex = sys_dir / "root.tex"
                        sys_pdf_err: Optional[str] = None
                        if root_tex.exists():
                            try:
                                TexGenerator().compile_pdf(root_tex)
                                root_pdf = sys_dir / "root.pdf"
                                if root_pdf.exists():
                                    shutil.move(
                                        str(root_pdf),
                                        str(sys_dir / "system.pdf"),
                                    )
                                else:
                                    sys_pdf_err = (
                                        "LaTeX finished but produced no PDF "
                                        "— check the structured TeX preamble "
                                        "(xeCJK, Noto Serif CJK JP, biber)."
                                    )
                            except FileNotFoundError as exc:
                                sys_pdf_err = str(exc)
                            except RuntimeError as exc:
                                sys_pdf_err = str(exc)
                        else:
                            sys_pdf_err = (
                                "root.tex was not emitted by the system tex "
                                "generator."
                            )
                        if sys_pdf_err is not None:
                            (sys_dir / "PDF_NOT_COMPILED.txt").write_text(
                                sys_pdf_err + "\n", encoding="utf-8"
                            )
                            pdf_status = "error"
                            pdf_reason = sys_pdf_err
                            logger.warning(
                                "PDF compilation skipped: %s", sys_pdf_err,
                            )
                        # Strip xelatex aux files. Preserve root.log on
                        # compile failure so the user can follow the
                        # "Check log file for details" pointer.
                        sys_aux_suffixes = {
                            ".aux", ".out", ".toc",
                            ".bcf", ".run.xml", ".fls",
                            ".fdb_latexmk", ".bbl", ".blg",
                        }
                        if sys_pdf_err is None:
                            sys_aux_suffixes.add(".log")
                        for aux in sys_dir.glob("root.*"):
                            if aux.suffix in sys_aux_suffixes:
                                aux.unlink(missing_ok=True)
                        sys_zip.unlink(missing_ok=True)
                        with _zipfile.ZipFile(sys_zip, "w",
                                              _zipfile.ZIP_DEFLATED) as zf:
                            for f in sorted(sys_dir.rglob("*")):
                                if f.is_file():
                                    zf.write(f, f.relative_to(sys_dir))
                    else:
                        # Multi-ECU HTML — pass the session's RTM so every
                        # page carries OEM verdict badges + per-ECU RTM
                        # tables side-by-side. The RTM is matched
                        # against the *first* ECU's spec here only to
                        # populate sources; the generator re-runs
                        # match_to_spec per-ECU internally via a
                        # deepcopy so per-ECU implemented_hex is correct.
                        first_spec = next(
                            (e.spec for e in system.ecus.values() if e.spec),
                            None,
                        )
                        sys_rtm = (
                            _load_session_rtm(workdir, first_spec)
                            if first_spec is not None else None
                        )
                        generate_system_html_zip(system, sys_zip, rtm=sys_rtm)
                    content = sys_zip.read_bytes()
                    filename = sys_zip.name
                    media_type = "application/zip"
                elif fmt == "md":
                    from udsxml2tex.multi_ecu import generate_system_markdown
                    content = generate_system_markdown(system).encode("utf-8")
                    filename = "system.md"
                    media_type = "text/markdown"
                else:
                    return JSONResponse(
                        {"error": (
                            f"Multi-ECU format {fmt!r} not yet supported by "
                            f"/repo/generate. Use tex, html, or md."
                        )},
                        status_code=400,
                    )
                multi_headers = {
                    "Content-Disposition":
                        f'attachment; filename="{filename}"',
                    "X-PDF-Compile-Status": pdf_status,
                    "Access-Control-Expose-Headers": (
                        "Content-Disposition, X-PDF-Compile-Status, "
                        "X-PDF-Compile-Reason"
                    ),
                }
                if pdf_reason:
                    multi_headers["X-PDF-Compile-Reason"] = (
                        _sanitize_header(pdf_reason)
                    )
                return Response(
                    content=content,
                    media_type=media_type,
                    headers=multi_headers,
                )

            # ---- Single-ECU path ----
            spec, _ = load_from_repo(workdir)
            if ecu_name:
                spec.ecu_name = ecu_name

            if rtm_doc is not None:
                match_to_spec(rtm_doc, spec)

            safe_name = (spec.ecu_name or workdir.name or "ecu").replace(" ", "_")
            tex_gen = TexGenerator()

            selected_langs = _parse_langs_form(langs)
            cjk_note: Optional[str] = None
            if any("ja" in lc.split("+") for lc in selected_langs):
                cjk_ok, cjk_reason = _detect_cjk_render_support()
                if not cjk_ok:
                    new_langs: list[str] = []
                    dropped = False
                    for lc in selected_langs:
                        new_lc, did_drop = _strip_ja_from_lang(lc)
                        new_langs.append(new_lc)
                        dropped = dropped or did_drop
                    if dropped:
                        logger.warning(
                            "Dropped ja from lang stack (%s → %s): %s",
                            selected_langs, new_langs, cjk_reason,
                        )
                        selected_langs = new_langs
                        cjk_note = _CJK_FALLBACK_NOTE_TMPL.format(
                            reason=cjk_reason
                        )
            multi_lang = len(selected_langs) > 1
            pdf_status = "ok"
            pdf_reason = ""

            if fmt == "tex":
                import zipfile as _zipfile
                out_zip = workdir / f"{safe_name}_uds_spec.zip"
                pdf_errors: list[str] = []
                with _zipfile.ZipFile(out_zip, "w",
                                      _zipfile.ZIP_DEFLATED) as out_zf:
                    for lang_code in selected_langs:
                        tex_dir = workdir / f"_tex_src_{lang_code}"
                        if tex_dir.exists():
                            shutil.rmtree(tex_dir)
                        tex_dir.mkdir()
                        tmp_zip = workdir / f"_tex_tmp_{lang_code}.zip"
                        tex_gen.generate_structured_tex_zip(
                            spec, tmp_zip, cls_content=custom_cls_bytes,
                            lang=lang_code, rtm=rtm_doc,
                        )
                        with _zipfile.ZipFile(tmp_zip) as zf:
                            zf.extractall(tex_dir)

                        # Compile root.tex → spec.pdf (non-fatal).
                        root_tex = tex_dir / "root.tex"
                        xelatex_err: Optional[str] = None
                        if root_tex.exists():
                            try:
                                tex_gen.compile_pdf(root_tex)
                                root_pdf = tex_dir / "root.pdf"
                                if root_pdf.exists():
                                    shutil.move(
                                        str(root_pdf),
                                        str(tex_dir / "spec.pdf"),
                                    )
                                else:
                                    xelatex_err = (
                                        "LaTeX finished but produced no PDF "
                                        "— check the structured TeX preamble "
                                        "(xeCJK, Noto Serif CJK JP, biber)."
                                    )
                            except FileNotFoundError as exc:
                                xelatex_err = str(exc)
                            except RuntimeError as exc:
                                xelatex_err = str(exc)
                        else:
                            xelatex_err = (
                                "root.tex was not emitted by the tex "
                                "generator."
                            )

                        if xelatex_err is not None:
                            (tex_dir / "PDF_NOT_COMPILED.txt").write_text(
                                xelatex_err + "\n", encoding="utf-8"
                            )
                            pdf_errors.append(f"{lang_code}: {xelatex_err}")
                            logger.warning(
                                "PDF compilation skipped (%s): %s",
                                lang_code, xelatex_err,
                            )

                        # Strip xelatex aux files so the zip only carries
                        # tex sources + the final spec.pdf. On compile
                        # failure keep root.log alongside
                        # PDF_NOT_COMPILED.txt so the user can actually
                        # follow "Check log file for details".
                        aux_suffixes = {
                            ".aux", ".out", ".toc",
                            ".bcf", ".run.xml", ".fls",
                            ".fdb_latexmk", ".bbl", ".blg",
                        }
                        if xelatex_err is None:
                            aux_suffixes.add(".log")
                        for aux in tex_dir.glob("root.*"):
                            if aux.suffix in aux_suffixes:
                                aux.unlink(missing_ok=True)

                        for f in sorted(tex_dir.rglob("*")):
                            if f.is_file():
                                rel = f.relative_to(tex_dir)
                                arcname = (
                                    Path(lang_code) / rel
                                    if multi_lang else rel
                                )
                                out_zf.write(f, arcname)
                    if cjk_note:
                        out_zf.writestr("JAPANESE_NOT_RENDERED.txt", cjk_note)
                content = out_zip.read_bytes()
                filename = out_zip.name
                media_type = "application/zip"
                pdf_status = "ok" if not pdf_errors else "error"
                pdf_reason = (
                    "" if not pdf_errors else " | ".join(pdf_errors)
                )
            elif fmt == "html":
                out_zip = workdir / f"{safe_name}_uds_spec_html.zip"
                if multi_lang:
                    import zipfile as _zipfile
                    with _zipfile.ZipFile(out_zip, "w",
                                          _zipfile.ZIP_DEFLATED) as out_zf:
                        for lang_code in selected_langs:
                            per_zip = workdir / f"_html_{lang_code}.zip"
                            tex_gen.generate_html_zip(spec, per_zip, rtm=rtm_doc)
                            with _zipfile.ZipFile(per_zip) as src:
                                for name in src.namelist():
                                    data = src.read(name)
                                    out_zf.writestr(
                                        f"{lang_code}/{name}", data,
                                    )
                else:
                    tex_gen.generate_html_zip(spec, out_zip, rtm=rtm_doc)
                content = out_zip.read_bytes()
                filename = out_zip.name
                media_type = "application/zip"
            elif fmt == "md":
                if multi_lang:
                    import zipfile as _zipfile
                    out_zip = workdir / f"{safe_name}_uds_spec_md.zip"
                    with _zipfile.ZipFile(out_zip, "w",
                                          _zipfile.ZIP_DEFLATED) as out_zf:
                        for lang_code in selected_langs:
                            per_out = (
                                workdir
                                / f"{safe_name}_uds_spec_{lang_code}.md"
                            )
                            tex_gen.generate_markdown(
                                spec, per_out, lang=lang_code,
                            )
                            out_zf.write(per_out, per_out.name)
                    content = out_zip.read_bytes()
                    filename = out_zip.name
                    media_type = "application/zip"
                else:
                    out = workdir / f"{safe_name}_uds_spec.md"
                    tex_gen.generate_markdown(
                        spec, out, lang=selected_langs[0],
                    )
                    content = out.read_bytes()
                    filename = out.name
                    media_type = "text/markdown"
            elif fmt == "rst":
                if multi_lang:
                    import zipfile as _zipfile
                    out_zip = workdir / f"{safe_name}_uds_spec_rst.zip"
                    with _zipfile.ZipFile(out_zip, "w",
                                          _zipfile.ZIP_DEFLATED) as out_zf:
                        for lang_code in selected_langs:
                            per_out = (
                                workdir
                                / f"{safe_name}_uds_spec_{lang_code}.rst"
                            )
                            tex_gen.generate_rst(
                                spec, per_out, lang=lang_code,
                            )
                            out_zf.write(per_out, per_out.name)
                    content = out_zip.read_bytes()
                    filename = out_zip.name
                    media_type = "application/zip"
                else:
                    out = workdir / f"{safe_name}_uds_spec.rst"
                    tex_gen.generate_rst(
                        spec, out, lang=selected_langs[0],
                    )
                    content = out.read_bytes()
                    filename = out.name
                    media_type = "text/x-rst"
            elif fmt == "yaml":
                out = workdir / f"{safe_name}_uds_spec.yaml"
                tex_gen.generate_yaml(spec, out)
                content = out.read_bytes()
                filename = out.name
                media_type = "text/yaml"
            elif fmt == "json":
                out = workdir / f"{safe_name}_uds_spec.json"
                tex_gen.generate_json(spec, out)
                content = out.read_bytes()
                filename = out.name
                media_type = "application/json"
            else:
                return JSONResponse(
                    {"error": (
                        f"Format {fmt!r} not supported by /repo/generate. "
                        f"Use tex, html, md, rst, yaml, or json."
                    )},
                    status_code=400,
                )

            single_headers = {
                "Content-Disposition":
                    f'attachment; filename="{filename}"',
                "X-PDF-Compile-Status": pdf_status,
                "Access-Control-Expose-Headers": (
                    "Content-Disposition, X-PDF-Compile-Status, "
                    "X-PDF-Compile-Reason, X-CJK-Status, X-CJK-Reason"
                ),
            }
            if pdf_reason:
                single_headers["X-PDF-Compile-Reason"] = (
                    _sanitize_header(pdf_reason)
                )
            if cjk_note:
                single_headers["X-CJK-Status"] = "ja_dropped"
                single_headers["X-CJK-Reason"] = _sanitize_header(cjk_reason)
            return Response(
                content=content,
                media_type=media_type,
                headers=single_headers,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("repo_generate failed")
            return JSONResponse(
                {"error": f"Generation failed: {exc}"},
                status_code=500,
            )

    # ------------------------------------------------------------------
    # POST /validate — validate ARXML and return issues
    # ------------------------------------------------------------------

    @app.post("/validate")
    async def validate_arxml(
        arxml_file: UploadFile = File(...),
    ) -> JSONResponse:
        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_validate_")
        try:
            arxml_path = Path(tmpdir) / "input.arxml"
            _save_upload(arxml_file, arxml_path)

            if _VALIDATOR_AVAILABLE:
                validator = UdsValidator()
                result = validator.validate_file(arxml_path)
                return JSONResponse({"success": True, "result": result})

            # Fallback: use parser warnings as validation result
            parser = ArxmlParser()
            errors: list[dict] = []
            warnings_out: list[dict] = []
            infos: list[dict] = []

            try:
                spec = parser.parse(arxml_path)
                for w in parser.warnings:
                    warnings_out.append({
                        "severity": "warning",
                        "category": w.section,
                        "message": w.message,
                        "item_id": "",
                    })
                infos.append({
                    "severity": "info",
                    "category": "summary",
                    "message": (
                        f"Parsed successfully: {len(spec.sessions)} sessions, "
                        f"{len(spec.dids)} DIDs, {len(spec.services)} services, "
                        f"{len(spec.dtcs)} DTCs"
                    ),
                    "item_id": "",
                })
            except Exception as exc:  # noqa: BLE001
                errors.append({
                    "severity": "error",
                    "category": "parse",
                    "message": str(exc),
                    "item_id": "",
                })

            summary_parts = []
            if errors:
                summary_parts.append(f"{len(errors)} error(s)")
            if warnings_out:
                summary_parts.append(f"{len(warnings_out)} warning(s)")
            if infos:
                summary_parts.append(f"{len(infos)} info(s)")
            summary_str = ", ".join(summary_parts) if summary_parts else "No issues found"

            return JSONResponse({
                "success": True,
                "result": {
                    "errors": errors,
                    "warnings": warnings_out,
                    "infos": infos,
                    "summary": summary_str,
                },
            })
        except Exception as exc:  # noqa: BLE001
            logger.exception("Validate error")
            return JSONResponse({"success": False, "error": str(exc)}, status_code=400)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /diff — diff two ARXML files
    # ------------------------------------------------------------------

    @app.post("/diff")
    async def diff_arxml(
        arxml_a: UploadFile = File(...),
        arxml_b: UploadFile = File(...),
    ) -> JSONResponse:
        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_diff_")
        try:
            path_a = Path(tmpdir) / "spec_a.arxml"
            path_b = Path(tmpdir) / "spec_b.arxml"
            _save_upload(arxml_a, path_a)
            _save_upload(arxml_b, path_b)

            if _DIFFER_AVAILABLE:
                differ = SpecDiffer()
                diff_result = differ.diff_files(path_a, path_b)
                return JSONResponse({"success": True, "diff": diff_result})

            # Fallback: basic structural diff via parser
            parser_a = ArxmlParser()
            parser_b = ArxmlParser()

            try:
                spec_a = parser_a.parse(path_a)
            except Exception as exc:  # noqa: BLE001
                return JSONResponse(
                    {"success": False, "error": f"Failed to parse Spec A: {exc}"},
                    status_code=400,
                )

            try:
                spec_b = parser_b.parse(path_b)
            except Exception as exc:  # noqa: BLE001
                return JSONResponse(
                    {"success": False, "error": f"Failed to parse Spec B: {exc}"},
                    status_code=400,
                )

            entries = _basic_diff(spec_a, spec_b)
            added = sum(1 for e in entries if e["kind"] == "added")
            removed = sum(1 for e in entries if e["kind"] == "removed")
            changed = sum(1 for e in entries if e["kind"] == "changed")
            summary = f"{added} added, {removed} removed, {changed} changed"

            return JSONResponse({
                "success": True,
                "diff": {
                    "summary": summary,
                    "entries": entries,
                },
            })
        except Exception as exc:  # noqa: BLE001
            logger.exception("Diff error")
            return JSONResponse({"success": False, "error": str(exc)}, status_code=400)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /chat — multi-turn LLM chat against the most recently parsed spec
    # ------------------------------------------------------------------
    @app.post("/chat")
    async def chat(request: Request) -> "Response":
        """Stream an LLM chat response as Server-Sent Events.

        Request JSON body:
            session_id  (required) — ID returned by /parse
            messages    (required) — list of {role: "user"|"assistant", content: str}
            provider    (optional) — "anthropic" (default) | "openai"
            model       (optional) — model alias or full ID; "sonnet" default for
                                     Anthropic, free-form (e.g. "qwen2.5:7b") for
                                     OpenAI-compatible servers
            base_url    (optional) — base URL for OpenAI-compatible provider;
                                     accepts aliases: "ollama", "llamacpp",
                                     "lmstudio", "vllm", "openrouter"
            api_key     (optional) — override the server's API key for this call

        Response: text/event-stream emitting:
            data: {"delta": "...next chunk of text..."}
            data: {"done": true}
            data: {"error": "..."}
        """
        try:
            body = await request.json()
        except Exception:  # noqa: BLE001
            return JSONResponse(
                {"error": "Invalid JSON body"}, status_code=400
            )

        session_id = body.get("session_id")
        messages = body.get("messages") or []
        # Per-call config overrides — None means "fall back to server's default"
        # (env vars / ~/.udsxml2tex/llm.json / built-in default).
        ui_provider  = body.get("provider") or None
        ui_base_url  = body.get("base_url") or None
        ui_model     = body.get("model") or None
        ui_api_key   = body.get("api_key") or None

        if not session_id:
            return JSONResponse(
                {"error": "session_id is required (parse an ARXML first)"},
                status_code=400,
            )
        sess = _get_chat_session(session_id)
        if not sess:
            return JSONResponse(
                {"error": "Unknown or expired session_id; re-parse the ARXML"},
                status_code=404,
            )
        if not messages or messages[0].get("role") != "user":
            return JSONResponse(
                {"error": "messages must be non-empty and start with role='user'"},
                status_code=400,
            )

        spec = sess["spec"]

        try:
            from udsxml2tex.llm_integration import LLMConfig, chat_stream
        except ImportError as e:
            return JSONResponse(
                {"error": str(e)}, status_code=500,
            )

        # Build a per-request config: server defaults + UI overrides.
        cfg = LLMConfig.auto()
        if ui_provider:
            cfg.provider = ui_provider
        if ui_base_url:
            cfg.base_url = ui_base_url
        if ui_model:
            cfg.model = ui_model
        if ui_api_key:
            cfg.api_key = ui_api_key

        def _sse_iter():
            import json as _json
            try:
                for delta in chat_stream(spec, messages, config=cfg):
                    yield "data: " + _json.dumps({"delta": delta}) + "\n\n"
                yield "data: " + _json.dumps({"done": True}) + "\n\n"
            except Exception as exc:  # noqa: BLE001
                logger.exception("Chat error")
                yield "data: " + _json.dumps({"error": str(exc)}) + "\n\n"

        return StreamingResponse(
            _sse_iter(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache, no-transform",
                "X-Accel-Buffering": "no",
            },
        )

    # ------------------------------------------------------------------
    # ECU Test extensions (v0.56+) — auto-config, request/response
    # simulator, ASC log analyzer. Each endpoint operates on a
    # previously-parsed repo session (session_id from /repo/scan-demo /
    # /repo/scan).
    # ------------------------------------------------------------------
    @app.get("/ecu-test/autoconfig")
    async def ecu_test_autoconfig(session_id: str,
                                    ecu: Optional[str] = None) -> JSONResponse:
        """Read CAN configuration from the parsed spec so the ECU Test
        form can prefill Rx/Tx/Functional IDs, protocol type (CAN vs
        CAN-FD) and the OEM-mentioned bitrate.

        Tries to load multi-ECU first (returns the requested ``ecu`` or
        the first one), falls back to single-ECU.
        """
        sess = _get_repo_session(session_id)
        if sess is None:
            return JSONResponse({"error": "Unknown session"}, status_code=404)
        workdir = sess["workdir"]
        from udsxml2tex.repo_scanner import (
            load_from_repo, load_system_from_repo,
        )
        try:
            if sess["mode"] == "multi":
                system, _, _ = load_system_from_repo(workdir)
                ecus = [(n, c.spec) for n, c in system.ecus.items() if c.spec]
                if not ecus:
                    return JSONResponse({"error": "No parsed ECUs"}, status_code=400)
                if ecu:
                    name, spec = next(
                        ((n, s) for n, s in ecus if n == ecu), ecus[0],
                    )
                else:
                    name, spec = ecus[0]
            else:
                name = "primary"
                spec, _ = load_from_repo(workdir)
        except Exception as exc:  # noqa: BLE001
            return JSONResponse({"error": str(exc)}, status_code=500)

        # Derive bitrate heuristically. Production ARXML files rarely carry
        # the bus baudrate inside DcmDsl — most OEMs publish it in a
        # separate CommunicationStack ARXML. So we surface the value
        # under access_timing (`module_main_function_period`) only when
        # present and otherwise return null so the UI can fall back to a
        # sensible default (500 kbit/s).
        bitrate = None
        proto = (getattr(spec, "protocol_type", "") or "").upper()
        is_canfd = "CAN_FD" in proto or "CANFD" in proto
        return JSONResponse({
            "ecu_name": name,
            "rx_id": getattr(spec, "can_rx_id", "") or "",
            "tx_id": getattr(spec, "can_tx_id", "") or "",
            "functional_id": getattr(spec, "can_functional_id", "") or "",
            "protocol_type": proto or "UDS_ON_CAN",
            "is_can_fd": is_canfd,
            "bitrate_bps": bitrate,
            "max_block_length": getattr(spec, "max_block_length", 0) or 0,
            "ecu_name_arxml": getattr(spec, "ecu_name", "") or "",
        })

    @app.post("/ecu-test/simulate")
    async def ecu_test_simulate(request: Request) -> JSONResponse:
        """Predict the response to a user-typed UDS request, without
        any real ECU. Walks the parsed DcmDsd / DcmDspDid / DcmDspRoutine
        configuration and synthesises either a positive response stub
        or the appropriate ISO 14229-1 NRC.

        Request JSON:
            session_id    — repo session
            ecu           — (multi-ECU) which ECU to simulate; defaults to first
            request_hex   — request bytes, e.g. "22 F1 90" / "2210 03" / "31 01 02 03"

        Response JSON:
            request_hex   — normalised input
            response_hex  — synthesised reply (positive OR negative)
            verdict       — "positive" / "negative"
            decoded       — { kind, sid, sub_function?, did?, nrc?, name? }
            notes         — list[str] of human-readable hints
        """
        try:
            body = await request.json()
        except Exception:  # noqa: BLE001
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        sess = _get_repo_session(body.get("session_id") or "")
        if sess is None:
            return JSONResponse({"error": "Unknown session"}, status_code=404)
        from udsxml2tex.repo_scanner import (
            load_from_repo, load_system_from_repo,
        )
        workdir = sess["workdir"]
        try:
            if sess["mode"] == "multi":
                system, _, _ = load_system_from_repo(workdir)
                ecus = [(n, c.spec) for n, c in system.ecus.items() if c.spec]
                if not ecus:
                    return JSONResponse({"error": "No parsed ECUs"}, status_code=400)
                spec = next(
                    (s for n, s in ecus if n == body.get("ecu")), ecus[0][1],
                )
            else:
                spec, _ = load_from_repo(workdir)
        except Exception as exc:  # noqa: BLE001
            return JSONResponse({"error": str(exc)}, status_code=500)

        from udsxml2tex.ecu_simulator import simulate_request
        try:
            result = simulate_request(spec, body.get("request_hex") or "")
        except Exception as exc:  # noqa: BLE001
            logger.exception("simulate_request failed")
            return JSONResponse({"error": str(exc)}, status_code=400)
        return JSONResponse(result)

    @app.post("/ecu-test/analyze-log")
    async def ecu_test_analyze_log(
        session_id: str = Form(...),
        log_file: UploadFile = File(...),
        ecu: Optional[str] = Form(None),
    ) -> JSONResponse:
        """Analyse a CANalyzer ASC (text) or BLF (binary) log against
        the parsed spec.

        Returns a list of decoded request/response pairs with
        compliance flags (e.g. service the OEM marked as Rejected
        that the ECU returned positively).
        """
        sess = _get_repo_session(session_id)
        if sess is None:
            return JSONResponse({"error": "Unknown session"}, status_code=404)
        from udsxml2tex.repo_scanner import (
            load_from_repo, load_system_from_repo,
        )
        workdir = sess["workdir"]
        try:
            if sess["mode"] == "multi":
                system, _, _ = load_system_from_repo(workdir)
                ecus = [(n, c.spec) for n, c in system.ecus.items() if c.spec]
                if not ecus:
                    return JSONResponse({"error": "No parsed ECUs"}, status_code=400)
                spec = next(
                    (s for n, s in ecus if n == ecu), ecus[0][1],
                )
            else:
                spec, _ = load_from_repo(workdir)
        except Exception as exc:  # noqa: BLE001
            return JSONResponse({"error": str(exc)}, status_code=500)

        from udsxml2tex.ecu_log_analyzer import analyze_log_stream
        data = await log_file.read()
        name = (log_file.filename or "").lower()
        fmt = "blf" if name.endswith(".blf") else "asc"
        rtm_doc = _load_session_rtm(workdir, spec)
        try:
            report = analyze_log_stream(spec, data, fmt=fmt, rtm=rtm_doc)
        except Exception as exc:  # noqa: BLE001
            logger.exception("analyze_log_stream failed")
            return JSONResponse({"error": str(exc)}, status_code=400)
        return JSONResponse(report)

    @app.get("/ecu-test/sample-log")
    async def ecu_test_sample_log() -> Response:
        """Return the bundled sample ASC log file as a download."""
        path = _SAMPLES_DIR / "sample_uds.asc"
        if not path.exists():
            return JSONResponse(
                {"error": "Sample log not bundled in this build"},
                status_code=404,
            )
        return Response(
            content=path.read_bytes(),
            media_type="text/plain; charset=utf-8",
            headers={"Content-Disposition": 'attachment; filename="sample_uds.asc"'},
        )

    @app.get("/ecu-test/export-odx")
    async def ecu_test_export_odx(session_id: str,
                                    ecu: Optional[str] = None) -> Response:
        """Generate an ODX/PDX bundle from the session's parsed spec."""
        sess = _get_repo_session(session_id)
        if sess is None:
            return JSONResponse({"error": "Unknown session"}, status_code=404)
        from udsxml2tex.repo_scanner import (
            load_from_repo, load_system_from_repo,
        )
        workdir = sess["workdir"]
        try:
            if sess["mode"] == "multi":
                system, _, _ = load_system_from_repo(workdir)
                ecus = [(n, c.spec) for n, c in system.ecus.items() if c.spec]
                spec = next(
                    (s for n, s in ecus if n == ecu), ecus[0][1],
                )
            else:
                spec, _ = load_from_repo(workdir)
        except Exception as exc:  # noqa: BLE001
            return JSONResponse({"error": str(exc)}, status_code=500)

        import tempfile
        with tempfile.TemporaryDirectory() as tmpdir:
            pdx_path = Path(tmpdir) / f"{spec.ecu_name or 'ecu'}.pdx"
            TexGenerator().generate_pdx(spec, pdx_path)
            payload = pdx_path.read_bytes()
            fname = pdx_path.name
        return Response(
            content=payload,
            media_type="application/zip",
            headers={"Content-Disposition": f'attachment; filename="{fname}"'},
        )

    # NOTE: CDD export was intentionally NOT shipped. Vector CANalyzer /
    # CANoe (Option .DIAG, v11+) accept ODX 2.2 / PDX directly for UDS
    # response parsing, providing the same Trace-window decoding CDD
    # offers — without the proprietary binary format / partial schema.
    # Users wanting CDD-style ingestion: load the ``/ecu-test/export-odx``
    # PDX bundle in CANoe (Diagnostic/ISO TP → Configuration → ODX/PDX).

    # POST /chat/verify-rtm-condition — LLM-backed Conditional comment
    # vs. implementation verifier (per row)
    # ------------------------------------------------------------------
    @app.post("/chat/verify-rtm-condition")
    async def chat_verify_rtm_condition(request: Request) -> JSONResponse:
        """Ask the LLM whether a Conditionally-Accepted RTM Comment
        matches the implementation parsed from the session.

        Request JSON body:
            session_id  — chat session id (returned by /parse)
            req_id      — RTM row identifier (used for traceability)
            description — RTM row description (the requirement itself)
            comment     — RTM Comment column (the OEM's condition)
            traces_to   — RTM traces_to value (semi-colon separated tokens)
            provider / model / base_url / api_key — optional, identical
                semantics to /chat

        Response JSON: { verdict, rationale, evidence } per
        :func:`udsxml2tex.llm_integration.verify_rtm_condition`.
        """
        try:
            body = await request.json()
        except Exception:  # noqa: BLE001
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        session_id = body.get("session_id")
        req_id      = body.get("req_id") or ""
        description = body.get("description") or ""
        comment     = body.get("comment") or ""
        traces_to   = body.get("traces_to") or ""
        if not comment.strip():
            return JSONResponse({"error": "comment is required"}, status_code=400)

        # Accept either a chat-session id (POST /parse) or a repo-session
        # id (POST /repo/scan) — the RTM card lives in the Summary tab
        # which only knows the repo session id.
        spec = None
        sess = _get_chat_session(session_id) if session_id else None
        if sess is not None:
            spec = sess.get("spec")
        else:
            rsess = _get_repo_session(session_id) if session_id else None
            if rsess is not None:
                try:
                    from udsxml2tex.repo_scanner import (
                        load_from_repo, load_system_from_repo,
                    )
                    if rsess.get("mode") == "multi":
                        system, _, _ = load_system_from_repo(rsess["workdir"])
                        for _n, _c in system.ecus.items():
                            if _c.spec is not None:
                                spec = _c.spec
                                break
                    else:
                        spec, _ = load_from_repo(rsess["workdir"])
                except Exception:  # noqa: BLE001
                    spec = None
        spec_excerpt = _build_rtm_spec_excerpt(spec, traces_to)

        try:
            from udsxml2tex.llm_integration import LLMConfig, verify_rtm_condition
        except ImportError as e:
            return JSONResponse({"error": str(e)}, status_code=500)
        cfg = LLMConfig.auto()
        for k, attr in (("provider", "provider"), ("base_url", "base_url"),
                          ("model", "model"), ("api_key", "api_key")):
            v = body.get(k)
            if v:
                setattr(cfg, attr, v)
        try:
            import asyncio
            result = await asyncio.to_thread(
                verify_rtm_condition,
                req_id=req_id, description=description, comment=comment,
                traces_to=traces_to, spec_excerpt=spec_excerpt, config=cfg,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("verify_rtm_condition failed")
            return JSONResponse({"error": str(exc)}, status_code=500)
        return JSONResponse(result)

    # GET /rtm/conditional-entries — enumerate Conditionally-Accepted
    # RTM rows for a repo session so the UI can show per-row verify
    # buttons in the Summary tab.
    # ------------------------------------------------------------------
    @app.get("/rtm/conditional-entries")
    async def rtm_conditional_entries(session_id: str) -> JSONResponse:
        """List the RTM rows whose status is ``conditionally_accepted``
        (or ``conditional``) along with the OEM comment and trace targets.

        Designed to drive the Phase-4 RTM verifier UI: the response is
        consumed row-by-row, each item then POSTed to
        ``/chat/verify-rtm-condition`` to fetch an LLM verdict.
        """
        rsess = _get_repo_session(session_id)
        if rsess is None:
            return JSONResponse({"error": "Unknown session"}, status_code=404)
        workdir = rsess["workdir"]
        # Reuse _load_session_rtm so we walk the same directories that
        # the HTML rendering path does.
        try:
            from udsxml2tex.repo_scanner import (
                load_from_repo, load_system_from_repo,
            )
            if rsess.get("mode") == "multi":
                system, _, _ = load_system_from_repo(workdir)
                spec = next(
                    (c.spec for c in system.ecus.values() if c.spec is not None),
                    None,
                )
            else:
                spec, _ = load_from_repo(workdir)
        except Exception as exc:  # noqa: BLE001
            return JSONResponse({"error": str(exc)}, status_code=500)
        doc = _load_session_rtm(workdir, spec) if spec is not None else None
        if doc is None:
            return JSONResponse({"entries": [], "total": 0,
                                  "note": "No RTM CSVs found in session"})
        entries = []
        for e in getattr(doc, "entries", []):
            status = (getattr(e, "status", "") or "").lower()
            if status not in ("conditionally_accepted", "conditional"):
                continue
            traces = ";".join(
                getattr(t, "raw", str(t)) for t in getattr(e, "traces_to", [])
            )
            entries.append({
                "req_id": getattr(e, "req_id", ""),
                "description": getattr(e, "description", ""),
                "comment": getattr(e, "comment", ""),
                "traces_to": traces,
                "status": status,
            })
        return JSONResponse({"entries": entries, "total": len(entries)})

    # POST /rtm/gen-arxml — synthesise an AUTOSAR ECU skeleton ZIP
    # (Dcm + Dem + CanTp + PduR) from the session's RTM CSV(s). Mirrors
    # the CLI's ``--gen-arxml-from-csv`` flow but exposes it to the
    # browser so application teams can hand a placeholder Boot bundle to
    # an external supplier without dropping back to the terminal.
    # ------------------------------------------------------------------
    @app.post("/rtm/gen-arxml")
    async def rtm_gen_arxml(request: Request) -> "Response":
        """Build an AUTOSAR ECU skeleton ZIP from the session's RTM CSVs.

        Request JSON body:
            session_id  — repo session id (required)
            domain      — 'boot' (default) | 'drive' | 'both' | 'all'
            ecu_name    — AR-PACKAGE SHORT-NAME (default: 'BootECU')

        Response:
            On success: 200 with ``application/zip`` body + a
            ``Content-Disposition: attachment`` header so the browser
            triggers a download named ``<ecu_name>_<domain>_skeleton.zip``.
            On failure: 400/404/500 JSON ``{"error": "..."}``.
        """
        try:
            body = await request.json() if (await request.body()) else {}
        except Exception:  # noqa: BLE001
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

        session_id = (body.get("session_id") or "").strip()
        if not session_id:
            return JSONResponse({"error": "session_id required"}, status_code=400)
        domain = (body.get("domain") or "boot").strip().lower()
        if domain not in {"boot", "drive", "both", "all"}:
            return JSONResponse(
                {"error": "domain must be one of boot/drive/both/all"},
                status_code=400,
            )
        ecu_name = (body.get("ecu_name") or "BootECU").strip() or "BootECU"

        rsess = _get_repo_session(session_id)
        if rsess is None:
            return JSONResponse({"error": "Unknown session"}, status_code=404)
        workdir = rsess["workdir"]

        # Reuse the same RTM-CSV discovery rule as _load_session_rtm:
        # files under workdir / workdir/rtm / workdir/_rtm_uploads whose
        # name ends in .csv and contains 'rtm'.
        candidates: list[Path] = []
        for sub in (workdir, workdir / "rtm", workdir / "_rtm_uploads"):
            if not sub.exists():
                continue
            for p in sub.iterdir():
                if not p.is_file():
                    continue
                n = p.name.lower()
                if n.endswith(".csv") and "rtm" in n:
                    candidates.append(p)
        if not candidates:
            return JSONResponse(
                {"error": "No RTM CSV files found in this session "
                          "(looked under rtm/ and _rtm_uploads/)."},
                status_code=404,
            )

        try:
            from udsxml2tex.rtm import load_rtm_csvs
            from udsxml2tex.csv_to_arxml import generate_arxml_from_rtm
        except Exception as exc:  # noqa: BLE001
            return JSONResponse({"error": f"import failed: {exc}"},
                                  status_code=500)

        try:
            entries = load_rtm_csvs(candidates)
        except Exception as exc:  # noqa: BLE001
            return JSONResponse(
                {"error": f"RTM CSV parse failed: {exc}"},
                status_code=400,
            )
        if not entries:
            return JSONResponse(
                {"error": "RTM CSVs parsed to zero entries."},
                status_code=400,
            )

        try:
            zip_bytes = generate_arxml_from_rtm(
                entries,
                output_path=None,
                ecu_name=ecu_name,
                domain_filter=domain,
            )
        except ValueError as exc:
            # Most commonly: domain filter produced empty skeleton.
            return JSONResponse(
                {"error": str(exc),
                 "hint": ("Try a wider domain ('all') or check that the "
                          "CSV's traces_to column actually references the "
                          "selected domain's services / DIDs / RIDs.")},
                status_code=400,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("ARXML synthesis failed")
            return JSONResponse({"error": str(exc)}, status_code=500)

        # Sanitise the ECU name for the filename (drop anything that
        # isn't a safe filesystem-friendly char).
        import re as _re
        safe = _re.sub(r"[^A-Za-z0-9_.-]+", "_", ecu_name) or "ecu"
        fname = f"{safe}_{domain}_skeleton.zip"
        # Best-effort module list for the X-RTM-Modules header — derived
        # by peeking at the ZIP centrally so the UI doesn't have to.
        try:
            import io as _io
            import zipfile as _zf
            with _zf.ZipFile(_io.BytesIO(zip_bytes)) as _z:
                modules_in_zip = ",".join(
                    n for n in _z.namelist() if n.endswith(".arxml")
                )
        except Exception:  # noqa: BLE001
            modules_in_zip = ""
        return Response(
            content=zip_bytes,
            media_type="application/zip",
            headers={
                "Content-Disposition": f'attachment; filename="{fname}"',
                "X-RTM-Entries-Used": str(len(entries)),
                "X-RTM-CSV-Count": str(len(candidates)),
                "X-RTM-Domain": domain,
                "X-RTM-Modules": modules_in_zip,
                "Access-Control-Expose-Headers":
                    "Content-Disposition, X-RTM-Entries-Used, "
                    "X-RTM-CSV-Count, X-RTM-Domain, X-RTM-Modules",
            },
        )

    # POST /chat/bootstrap-ollama — one-click local LLM backend setup
    # ------------------------------------------------------------------
    @app.post("/chat/bootstrap-ollama")
    async def chat_bootstrap_ollama(request: Request) -> "Response":
        """Download/start Ollama and pull a model, equivalent to the
        ``--bootstrap-ollama`` CLI flag but triggered from the Chat tab.

        Request JSON body (all optional):
            model       — model tag to pull (default: qwen2.5:7b)
            port        — port for ``ollama serve`` (default: 11434)
            ctx_length  — num_ctx for the bootstrapped server (default: 24576)

        Response JSON on success:
            {
              "status": "ok",
              "ollama_path": "/home/.../ollama",
              "serve_pid": 12345,
              "serve_already_running": true,
              "model": "qwen2.5:7b",
              "model_already_present": true,
              "host": "127.0.0.1",
              "port": 11434,
              "base_url": "http://127.0.0.1:11434/v1",
              "ctx_length": 24576
            }
        Response JSON on failure: ``{"status": "error", "error": "..."}``
        (HTTP 400 for unsupported platform / bad input, 500 otherwise.)
        """
        try:
            body = await request.json() if (await request.body()) else {}
        except Exception:  # noqa: BLE001
            return JSONResponse({"status": "error", "error": "Invalid JSON body"}, status_code=400)

        try:
            from udsxml2tex.ollama_setup import bootstrap, DEFAULT_MODEL, DEFAULT_CTX
        except ImportError as e:
            return JSONResponse({"status": "error", "error": str(e)}, status_code=500)

        # If the caller didn't explicitly request a model, pick the
        # hardware-recommended one (matches the "→ recommended:" hint
        # shown next to the Chat tab's CPU/GPU/RAM summary). Falls back
        # to the ollama_setup baseline if the hardware probe fails.
        client_model = (body.get("model") or "").strip()
        if client_model:
            model = client_model
        else:
            try:
                from udsxml2tex.hardware import detect, recommended_model
                _, model = recommended_model(detect())
            except Exception:  # noqa: BLE001
                model = DEFAULT_MODEL
        try:
            port = int(body.get("port") or 11434)
            ctx_length = int(body.get("ctx_length") or DEFAULT_CTX)
        except (TypeError, ValueError):
            return JSONResponse(
                {"status": "error", "error": "port and ctx_length must be integers"},
                status_code=400,
            )

        import asyncio

        def _run():
            return bootstrap(model=model, ctx_length=ctx_length, port=port)

        try:
            result = await asyncio.to_thread(_run)
        except RuntimeError as e:
            # detect_platform raises RuntimeError for Windows / unsupported arch
            return JSONResponse({"status": "error", "error": str(e)}, status_code=400)
        except Exception as e:  # noqa: BLE001
            logger.exception("Ollama bootstrap failed")
            return JSONResponse({"status": "error", "error": str(e)}, status_code=500)

        return JSONResponse({
            "status": "ok",
            "ollama_path": str(result.ollama_path),
            "serve_pid": result.serve_pid,
            "serve_already_running": result.serve_already_running,
            "model": result.model,
            "model_already_present": result.model_already_present,
            "host": result.host,
            "port": result.port,
            "base_url": result.base_url,
            "ctx_length": result.ctx_length,
        })

    # ------------------------------------------------------------------
    # GET /chat/ollama-models — list models installed in a running Ollama
    # ------------------------------------------------------------------
    @app.get("/chat/ollama-models")
    async def chat_ollama_models(base_url: str = "http://localhost:11434") -> JSONResponse:
        """Return the list of model tags available in a running Ollama instance.

        Query params:
            base_url — Ollama base URL (default http://localhost:11434)

        Response JSON:
            {"models": ["llama3.2:3b", "qwen2.5:7b", ...]}
            {"models": [], "error": "..."}   — if Ollama is not running
        """
        import urllib.request
        import urllib.error
        import json as _json

        tags_url = base_url.rstrip("/") + "/api/tags"
        try:
            with urllib.request.urlopen(tags_url, timeout=4) as resp:
                data = _json.loads(resp.read())
            models = [m["name"] for m in data.get("models", [])]
            return JSONResponse({"models": models})
        except Exception as exc:  # noqa: BLE001
            return JSONResponse({"models": [], "error": str(exc)})

    # ------------------------------------------------------------------
    # GET /chat/ollama-loaded — models *currently in VRAM* (via /api/ps)
    # ------------------------------------------------------------------
    @app.get("/chat/ollama-loaded")
    async def chat_ollama_loaded(base_url: str = "http://localhost:11434") -> JSONResponse:
        """Return the model tags currently loaded by a running Ollama instance.

        This lets the UI default the RTM verifier (and any other bulk LLM
        task) to whatever Ollama already has in VRAM, avoiding the
        catastrophic ``unload 14b → load 7b → unload 7b → load 14b`` swap
        cycle that happens when the verifier asks for a different tag than
        the chat session left resident. Sorted by descending VRAM size so
        the largest (typically most capable) loaded model is first.

        Query params:
            base_url — Ollama base URL (default http://localhost:11434)

        Response JSON:
            {"loaded": ["qwen2.5:14b", ...], "details": [{...raw...}]}
            {"loaded": [], "error": "..."}   — Ollama not running
        """
        import urllib.request
        import urllib.error
        import json as _json

        ps_url = base_url.rstrip("/") + "/api/ps"
        try:
            with urllib.request.urlopen(ps_url, timeout=4) as resp:
                data = _json.loads(resp.read())
            models = data.get("models", []) or []
            models_sorted = sorted(
                models,
                key=lambda m: int(m.get("size_vram", 0) or 0),
                reverse=True,
            )
            return JSONResponse({
                "loaded": [m["name"] for m in models_sorted if m.get("name")],
                "details": models_sorted,
            })
        except Exception as exc:  # noqa: BLE001
            return JSONResponse({"loaded": [], "error": str(exc)})

    # ------------------------------------------------------------------
    # GET /chat/openai-models — list models from an OpenAI-compatible server
    # ------------------------------------------------------------------
    @app.get("/chat/openai-models")
    async def chat_openai_models(
        base_url: str = "http://localhost:11434/v1",
        api_key: str = "",
    ) -> JSONResponse:
        """Return model IDs from an OpenAI-compatible /v1/models endpoint.

        Query params:
            base_url — server base URL (default http://localhost:11434/v1)
            api_key  — optional Bearer token

        Response JSON:
            {"models": ["llama3.2:3b", ...]}
            {"models": [], "error": "..."}
        """
        import urllib.request
        import urllib.error
        import json as _json

        models_url = base_url.rstrip("/") + "/models"
        req = urllib.request.Request(models_url)
        if api_key:
            req.add_header("Authorization", f"Bearer {api_key}")
        try:
            with urllib.request.urlopen(req, timeout=4) as resp:
                data = _json.loads(resp.read())
            models = [m.get("id", "") for m in data.get("data", [])]
            return JSONResponse({"models": [m for m in models if m]})
        except Exception as exc:  # noqa: BLE001
            return JSONResponse({"models": [], "error": str(exc)})

    # ------------------------------------------------------------------
    # GET /chat/system-info — CPU / RAM / GPU / NPU + recommended model
    # ------------------------------------------------------------------
    @app.get("/chat/system-info")
    async def chat_system_info() -> JSONResponse:
        """Return processing-unit info to help the UI recommend a model.

        Backed by :func:`udsxml2tex.hardware.summarize_for_ui`. Returns
        a richer payload than the legacy v0.48 endpoint:

        - ``cpu``      — brand, logical/physical core counts, arch
        - ``ram_gb``   — total system RAM (GB)
        - ``gpus``     — list of {vendor, name, vram_gb, backend}
        - ``npus``     — list of {vendor, name, ollama_supported}
        - ``total_vram_gb`` / ``effective_memory_gb``
        - ``recommended_size`` / ``recommended_model``
        - ``ollama_env_overrides`` — env vars the next bootstrap will
          apply to ``ollama serve``

        The legacy ``ram_gb`` / ``recommended_size`` / ``recommended_model``
        keys remain at the top level so the existing JS code still works
        without a coordinated rollout.
        """
        try:
            from udsxml2tex.hardware import summarize_for_ui
            payload = summarize_for_ui()
        except Exception as exc:  # noqa: BLE001
            logger.exception("hardware probe failed in /chat/system-info")
            payload = {
                "cpu": {"brand": "", "logical_cores": 0,
                         "physical_cores": 0, "arch": ""},
                "ram_gb": 0.0,
                "gpus": [],
                "npus": [],
                "total_vram_gb": 0.0,
                "effective_memory_gb": 0.0,
                "recommended_size": "7b",
                "recommended_model": "qwen2.5:7b",
                "ollama_env_overrides": {},
                "error": str(exc),
            }
        # Treat 0 GB RAM (probe failed entirely) as null so the legacy
        # JS branch falls back to the "RAM unknown" message instead of
        # claiming a 0-GB machine.
        if not payload.get("ram_gb"):
            payload["ram_gb"] = None
        return JSONResponse(payload)

    # ------------------------------------------------------------------
    # POST /system/parse — multi-ECU parse + per-ECU summary (JSON only)
    # ------------------------------------------------------------------
    @app.post("/system/parse")
    async def system_parse(
        system_yaml: UploadFile = File(...),
        arxml_files: list[UploadFile] = File(...),
        c_files: Optional[list[UploadFile]] = File(None),
        no_routing_inference: str = Form("false"),
    ) -> JSONResponse:
        """Mirror of /system but returns a JSON preview instead of a ZIP.

        Loads the system config exactly as /system does, then summarises
        each ECU. Used by the Multi-ECU "Parse & Preview" button so users
        can sanity-check the per-ECU stats before committing to a full
        generate-and-download.
        """
        try:
            from udsxml2tex.multi_ecu import load_system_config
        except ImportError as exc:
            return JSONResponse(
                {"success": False,
                 "error": f"multi_ecu module not available: {exc}"},
                status_code=500,
            )

        infer = not (no_routing_inference or "").strip().lower() in (
            "1", "true", "yes",
        )

        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_system_parse_")
        try:
            workdir = Path(tmpdir)

            yaml_name = _safe_basename(
                system_yaml.filename or "system.yaml", default="system.yaml",
            )
            yaml_path = workdir / yaml_name
            _save_upload(system_yaml, yaml_path)

            for uf in arxml_files:
                if not uf or not uf.filename:
                    continue
                bn = _safe_basename(uf.filename, default=None)
                if bn is None:
                    return JSONResponse(
                        {"success": False,
                         "error": f"Rejected unsafe filename: {uf.filename!r}"},
                        status_code=400,
                    )
                _save_upload(uf, workdir / bn)
            for uf in (c_files or []):
                if not uf or not uf.filename:
                    continue
                bn = _safe_basename(uf.filename, default=None)
                if bn is None:
                    return JSONResponse(
                        {"success": False,
                         "error": f"Rejected unsafe filename: {uf.filename!r}"},
                        status_code=400,
                    )
                _save_upload(uf, workdir / bn)

            try:
                system = load_system_config(
                    yaml_path, parse_arxml=True, infer_routing=infer,
                )
            except FileNotFoundError as exc:
                return JSONResponse(
                    {"success": False,
                     "error": f"YAML refers to a file that wasn't uploaded: {exc}"},
                    status_code=400,
                )
            except Exception as exc:  # noqa: BLE001
                logger.exception("System parse failed")
                return JSONResponse(
                    {"success": False,
                     "error": f"Failed to load system config: {exc}"},
                    status_code=400,
                )

            ecus_summary: list[dict] = []
            for name, ecu in system.ecus.items():
                if not ecu.spec:
                    continue
                summary = _build_summary(ecu.spec)
                summary["name"] = name
                summary["role"] = (
                    ecu.role.value if hasattr(ecu.role, "value")
                    else str(ecu.role)
                )
                ecus_summary.append(summary)

            # Register a chat session so the Chat tab can ask questions
            # against the multi-ECU system. The current chat backend
            # accepts a single `UdsSpecification`; we expose the first
            # ECU (typically the gateway / primary) and surface the
            # multi-ECU context in the summary so the user understands
            # which ECU they are conversing about.
            session_id: Optional[str] = None
            primary_spec = next(
                (e.spec for e in system.ecus.values() if e.spec), None,
            )
            if primary_spec is not None:
                primary_name = next(
                    (n for n, e in system.ecus.items() if e.spec), ""
                )
                chat_summary = _build_summary(primary_spec)
                chat_summary["multi_ecu"] = True
                chat_summary["system_name"] = system.name or ""
                chat_summary["primary_ecu"] = primary_name
                chat_summary["all_ecus"] = [
                    s.get("name") for s in ecus_summary
                ]
                session_id = _store_chat_session(primary_spec, chat_summary)

            return JSONResponse({
                "success": True,
                "system_name": system.name or "",
                "system_description": system.description or "",
                "ecus": ecus_summary,
                "routing_rule_count": len(system.routing_rules),
                "inferred_routing_rule_count": sum(
                    1 for r in system.routing_rules if getattr(r, "inferred", False)
                ),
                "session_id": session_id,
                "summary": (
                    {
                        "ecu_name": (
                            f"{system.name or 'system'} "
                            f"(primary: {next((n for n, e in system.ecus.items() if e.spec), '?')})"
                        ),
                        "protocol_name": "Multi-ECU UDS",
                        "session_count": sum(s.get("session_count", 0) for s in ecus_summary),
                        "security_level_count": sum(s.get("security_level_count", 0) for s in ecus_summary),
                        "service_count": sum(s.get("service_count", 0) for s in ecus_summary),
                        "did_count": sum(s.get("did_count", 0) for s in ecus_summary),
                        "routine_count": sum(s.get("routine_count", 0) for s in ecus_summary),
                    }
                    if session_id else None
                ),
            })
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /system — multi-ECU (redundant / gateway) generation
    # ------------------------------------------------------------------
    @app.post("/system")
    async def system_generate(
        system_yaml: UploadFile = File(...),
        arxml_files: list[UploadFile] = File(...),
        c_files: Optional[list[UploadFile]] = File(None),
        cls_file: Optional[UploadFile] = File(None),
        format: str = Form("html"),
        no_routing_inference: str = Form("false"),
    ) -> Response:
        """Generate per-ECU specs + integration document for a multi-ECU system.

        Request:
            system_yaml         — system config (.yaml/.yml/.json). Filenames it
                                  references must match the basenames of the
                                  uploaded `arxml_files` / `c_files`.
            arxml_files         — every ARXML the system config refers to,
                                  primary + secondary + DEM, etc.
            c_files             — optional .c/.cpp/.h sources matching any
                                  per-ECU `did_c_files:` / `rid_c_files:`
                                  entries in the YAML. The scanners populate
                                  DataElement.global_variables in-place.
            format              — "html" (default) | "tex" | "pdf" | "md".
                                  `pdf` requires latexmk or pdflatex on the
                                  server.
            no_routing_inference — "true" disables ARXML coverage-gap routing
                                  inference; explicit rules are always kept.

        Response: application/zip with the same layout as
            `udsxml2tex --system <yaml> --system-output-dir <dir>`:
                <ecu_name>/spec.<ext>     — one per ECU
                system.<ext>              — integration document
        """
        fmt = (format or "html").strip().lower()
        if fmt == "pdf":
            # Collapsed dropdown alias — `tex` already bundles spec.pdf.
            fmt = "tex"
        if fmt not in ("html", "tex", "md"):
            return JSONResponse(
                {"error": f"Unsupported format {fmt!r}; use html or tex"},
                status_code=400,
            )

        try:
            from udsxml2tex.multi_ecu import (
                generate_system_html,
                generate_system_html_zip,
                generate_system_latex,
                generate_system_markdown,
                generate_system_structured_tex_zip,
                load_system_config,
            )
        except ImportError as exc:
            return JSONResponse(
                {"error": f"multi_ecu module not available: {exc}"},
                status_code=500,
            )

        infer = not (no_routing_inference or "").strip().lower() in ("1", "true", "yes")

        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_system_")
        try:
            workdir = Path(tmpdir)

            # Save the system YAML — original filename so messages stay readable.
            yaml_name = _safe_basename(
                system_yaml.filename or "system.yaml", default="system.yaml",
            )
            yaml_path = workdir / yaml_name
            _save_upload(system_yaml, yaml_path)

            # Save each ARXML using its original filename so the YAML's relative
            # `arxml_files:` entries resolve. Reject path traversal.
            for uf in arxml_files:
                if not uf or not uf.filename:
                    continue
                bn = _safe_basename(uf.filename, default=None)
                if bn is None:
                    return JSONResponse(
                        {"error": f"Rejected unsafe filename: {uf.filename!r}"},
                        status_code=400,
                    )
                _save_upload(uf, workdir / bn)

            # C source files: same flat-bucket pattern. Per-ECU assignment
            # happens via the YAML's `did_c_files:` / `rid_c_files:` lists.
            for uf in (c_files or []):
                if not uf or not uf.filename:
                    continue
                bn = _safe_basename(uf.filename, default=None)
                if bn is None:
                    return JSONResponse(
                        {"error": f"Rejected unsafe filename: {uf.filename!r}"},
                        status_code=400,
                    )
                _save_upload(uf, workdir / bn)

            # Load + parse + (optionally) infer routing.
            try:
                system = load_system_config(
                    yaml_path, parse_arxml=True, infer_routing=infer,
                )
            except FileNotFoundError as exc:
                return JSONResponse(
                    {"error": f"YAML refers to a file that wasn't uploaded: {exc}"},
                    status_code=400,
                )
            except Exception as exc:  # noqa: BLE001
                logger.exception("System config load failed")
                return JSONResponse(
                    {"error": f"Failed to load system config: {exc}"},
                    status_code=400,
                )

            # Generate per-ECU outputs + system integration doc into output dir.
            out_dir = workdir / "out"
            out_dir.mkdir()
            tex_gen = TexGenerator()

            # Optional custom LaTeX class. Forwarded to
            # generate_structured_tex_zip(cls_content=...) so it lands as
            # `custom.cls` next to the per-ECU root.tex (matches the
            # single-ECU /generate flow).
            custom_cls_bytes: Optional[bytes] = None
            if cls_file is not None and cls_file.filename:
                custom_cls_bytes = cls_file.file.read()

            # Per-ECU generation. For HTML and TeX/PDF we now emit ONE
            # unified document covering all ECUs (Option B — per-section
            # ECU interleaving), so the per-ECU loop is skipped for those
            # formats and the unified output is built below. The `md`
            # server-only format keeps per-ECU markdown sources for now.
            for name, ecu in system.ecus.items():
                if not ecu.spec:
                    continue
                if fmt in ("html", "tex"):
                    # Unified system output covers all ECUs.
                    continue
                ecu_dir = out_dir / name
                ecu_dir.mkdir(parents=True, exist_ok=True)
                if fmt == "md":
                    tex_gen.generate_markdown(ecu.spec, ecu_dir / "spec.md")

            if fmt == "tex":
                # ONE unified structured LaTeX project covering all ECUs
                # (Option B). Extract the zip into out_dir/system_unified/
                # and compile to system_unified/root.pdf with xelatex+biber.
                import subprocess
                import zipfile as _zf
                sys_zip = workdir / "system_uds_spec.zip"
                generate_system_structured_tex_zip(
                    system, sys_zip, cls_content=custom_cls_bytes,
                )
                unified_dir = out_dir / "system_unified"
                unified_dir.mkdir(parents=True, exist_ok=True)
                with _zf.ZipFile(sys_zip) as zf:
                    zf.extractall(unified_dir)
                xelatex_err: Optional[str] = None
                try:
                    for _ in range(2):
                        subprocess.run(
                            ["xelatex", "-interaction=nonstopmode",
                             "root.tex"],
                            cwd=unified_dir, capture_output=True,
                            timeout=240,
                        )
                    try:
                        subprocess.run(
                            ["biber", "root"],
                            cwd=unified_dir, capture_output=True,
                            timeout=60,
                        )
                        for _ in range(2):
                            subprocess.run(
                                ["xelatex", "-interaction=nonstopmode",
                                 "root.tex"],
                                cwd=unified_dir, capture_output=True,
                                timeout=240,
                            )
                    except FileNotFoundError:
                        pass
                except FileNotFoundError:
                    xelatex_err = (
                        "xelatex not on PATH — install texlive-xetex "
                        "(and Noto Serif CJK JP fonts) on the server to "
                        "get a compiled system PDF; the .tex sources are "
                        "still included in the response zip."
                    )
                except subprocess.TimeoutExpired:
                    xelatex_err = "xelatex compilation timed out after 240s."
                if xelatex_err is None:
                    root_pdf = unified_dir / "root.pdf"
                    if root_pdf.exists():
                        shutil.move(
                            str(root_pdf), str(unified_dir / "system.pdf"),
                        )
                    else:
                        xelatex_err = (
                            "xelatex did not produce a PDF — check the "
                            "structured TeX preamble (xeCJK, Noto Serif "
                            "CJK JP, biber)."
                        )
                if xelatex_err is not None:
                    (unified_dir / "PDF_NOT_COMPILED.txt").write_text(
                        xelatex_err + "\n", encoding="utf-8"
                    )
                # Strip xelatex aux files.
                for aux in unified_dir.glob("root.*"):
                    if aux.suffix in (
                        ".aux", ".log", ".out", ".toc", ".bcf",
                        ".run.xml", ".fls", ".fdb_latexmk", ".bbl", ".blg",
                    ):
                        aux.unlink(missing_ok=True)
            elif fmt == "html":
                # ONE unified browsable site for the whole system. To match
                # the single-ECU /generate flow (which returns the html ZIP
                # directly), we return system_html_zip's bytes as-is — the
                # downloaded file unzips straight to index.html / sections/
                # / assets/ instead of containing another nested zip.
                sys_zip = workdir / f"{system.name or 'system'}.zip"
                generate_system_html_zip(system, sys_zip)
                return Response(
                    content=sys_zip.read_bytes(),
                    media_type="application/zip",
                    headers={
                        "Content-Disposition":
                            f'attachment; filename="{system.name or "system"}.zip"',
                    },
                )
            else:  # md
                sys_text = generate_system_markdown(system)
                (out_dir / "system.md").write_text(sys_text, encoding="utf-8")

            # Bundle the whole out_dir into a single ZIP for the browser.
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for p in sorted(out_dir.rglob("*")):
                    if p.is_file():
                        zf.write(p, arcname=str(p.relative_to(out_dir)))
            buf.seek(0)

            return Response(
                content=buf.getvalue(),
                media_type="application/zip",
                headers={
                    "Content-Disposition":
                        f'attachment; filename="{system.name or "system"}.zip"',
                },
            )
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /ecu-test — no-code ECU hardware test from the browser UI
    # ------------------------------------------------------------------

    @app.post("/ecu-test")
    async def run_ecu_test(
        arxml_file: UploadFile = File(...),
        interface: str = Form("vector"),
        channel: str = Form("0"),
        bitrate: str = Form("500000"),
        fd: str = Form("0"),
        rx_id: Optional[str] = Form(None),
        tx_id: Optional[str] = Form(None),
        timeout: str = Form("2.0"),
        categories: Optional[str] = Form(None),
        formal: str = Form("0"),
        coverage: str = Form("0"),
        rationale: str = Form("0"),
    ) -> JSONResponse:
        """Accept ECU test configuration from the browser UI and run tests.

        Returns a JSON response with the run summary and a link to the HTML
        report. Requires ``pip install udsxml2tex[ecu-test]``.
        """
        try:
            from udsxml2tex.ecu_test.generator import generate_test_suite
            from udsxml2tex.ecu_test.transport import make_connection
            from udsxml2tex.ecu_test.executor import EcuTestExecutor
            from udsxml2tex.ecu_test.logger import write_reports
        except ImportError:
            return JSONResponse(
                {
                    "success": False,
                    "error": (
                        "ECU test dependencies not installed. "
                        "Run: pip install udsxml2tex[ecu-test]"
                    ),
                },
                status_code=400,
            )

        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_ecu_")
        try:
            arxml_path = Path(tmpdir) / "input.arxml"
            _save_upload(arxml_file, arxml_path)
            spec, _ = _parse_arxml([arxml_path])

            # Parse categories JSON array from form field
            cats: Optional[list] = None
            if categories:
                import json as _json
                try:
                    cats = _json.loads(categories)
                    if not cats:
                        cats = None
                except Exception:
                    cats = None

            # Formal or heuristic generator
            use_formal = formal.strip() in ("1", "true", "yes")
            if use_formal:
                from udsxml2tex.ecu_test.formal_generator import generate_formal_test_suite
                cases = generate_formal_test_suite(spec, categories=cats)
            else:
                cases = generate_test_suite(spec, categories=cats)

            # Coverage
            coverage_report = None
            if coverage.strip() in ("1", "true", "yes"):
                from udsxml2tex.ecu_test.coverage import analyze_coverage
                coverage_report = analyze_coverage(spec, cases)

            # CAN IDs
            rx = int(rx_id, 16) if rx_id and rx_id.strip() else None
            tx = int(tx_id, 16) if tx_id and tx_id.strip() else None

            try:
                conn = make_connection(
                    spec,
                    interface=interface,
                    channel=channel,
                    bitrate=int(bitrate),
                    fd=fd.strip() in ("1", "true", "yes"),
                    rx_id=rx,
                    tx_id=tx,
                )
            except ValueError as exc:
                return JSONResponse(
                    {"success": False, "error": f"CAN connection error: {exc}"},
                    status_code=400,
                )

            with EcuTestExecutor(
                conn, default_timeout=float(timeout),
            ) as exe:
                suite = exe.run(
                    cases,
                    spec_name=spec.ecu_name,
                    interface=interface,
                    channel=channel,
                )

            # LLM rationale (optional)
            rationales: Optional[dict] = None
            if rationale.strip() in ("1", "true", "yes"):
                try:
                    from udsxml2tex.llm_integration import generate_test_rationale, LLMConfig
                    rationales = generate_test_rationale(spec, cases, config=LLMConfig.auto())
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Rationale generation failed: %s", exc)

            out_dir = Path(tmpdir) / "reports"
            paths = write_reports(
                suite, out_dir=out_dir, coverage=coverage_report, rationales=rationales,
            )

            return JSONResponse({
                "success": True,
                "message": (
                    f"{suite.passed}/{suite.total} passed "
                    f"({suite.pass_rate:.0f}%) — {len(cases)} test case(s)"
                ),
                "summary": {
                    "total": suite.total,
                    "passed": suite.passed,
                    "failed": suite.failed,
                    "errors": suite.errors,
                    "pass_rate_pct": round(suite.pass_rate, 1),
                    "coverage_pct": (
                        round(coverage_report.coverage_pct(), 1)
                        if coverage_report else None
                    ),
                },
            })
        except Exception as exc:  # noqa: BLE001
            logger.exception("ECU test error")
            return JSONResponse({"success": False, "error": str(exc)}, status_code=400)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    return app


# ---------------------------------------------------------------------------
# Helper: basic structural diff (used when SpecDiffer is not available)
# ---------------------------------------------------------------------------

def _basic_diff(spec_a: object, spec_b: object) -> list[dict]:
    """Produce a list of diff entries comparing two UdsSpecification objects."""
    entries: list[dict] = []

    def _compare_items(
        items_a: list,
        items_b: list,
        category: str,
        id_fn,
        desc_fn,
    ) -> None:
        ids_a = {id_fn(x): x for x in items_a}
        ids_b = {id_fn(x): x for x in items_b}
        for key in sorted(ids_a.keys() - ids_b.keys()):
            entries.append({
                "kind": "removed",
                "category": category,
                "item_id": str(key),
                "description": desc_fn(ids_a[key]),
            })
        for key in sorted(ids_b.keys() - ids_a.keys()):
            entries.append({
                "kind": "added",
                "category": category,
                "item_id": str(key),
                "description": desc_fn(ids_b[key]),
            })
        for key in sorted(ids_a.keys() & ids_b.keys()):
            if desc_fn(ids_a[key]) != desc_fn(ids_b[key]):
                entries.append({
                    "kind": "changed",
                    "category": category,
                    "item_id": str(key),
                    "description": f"{desc_fn(ids_a[key])} → {desc_fn(ids_b[key])}",
                })

    _compare_items(
        spec_a.sessions, spec_b.sessions,
        "session",
        lambda s: s.session_id,
        lambda s: s.short_name,
    )
    _compare_items(
        spec_a.security_levels, spec_b.security_levels,
        "security_level",
        lambda s: s.security_level,
        lambda s: s.short_name,
    )
    _compare_items(
        spec_a.services, spec_b.services,
        "service",
        lambda s: s.service_id,
        lambda s: s.short_name,
    )
    _compare_items(
        spec_a.dids, spec_b.dids,
        "did",
        lambda d: d.did_id,
        lambda d: d.short_name,
    )
    _compare_items(
        spec_a.routines, spec_b.routines,
        "routine",
        lambda r: r.routine_id,
        lambda r: r.short_name,
    )
    _compare_items(
        spec_a.dtcs, spec_b.dtcs,
        "dtc",
        lambda d: d.dtc_id,
        lambda d: d.short_name,
    )
    return entries


# ---------------------------------------------------------------------------
# Helper: markdown export
# ---------------------------------------------------------------------------

def _spec_to_markdown(spec: object) -> str:
    """Render a UdsSpecification as a simple Markdown document."""
    lines: list[str] = []
    lines.append(f"# {spec.ecu_name} UDS Specification\n")
    lines.append(f"**Protocol:** {spec.protocol_name}\n")

    lines.append("\n## Diagnostic Sessions\n")
    lines.append("| ID | Name | P2 (s) | P2* (s) |")
    lines.append("|----|------|--------|---------|")
    for s in sorted(spec.sessions, key=lambda x: x.session_id):
        lines.append(f"| {s.session_id_hex} | {s.short_name} | {s.p2_server_max} | {s.p2_star_server_max} |")

    lines.append("\n## Security Levels\n")
    lines.append("| Level | Name | Seed Size | Key Size |")
    lines.append("|-------|------|-----------|----------|")
    for s in sorted(spec.security_levels, key=lambda x: x.security_level):
        lines.append(f"| {s.security_level_hex} | {s.short_name} | {s.seed_size} B | {s.key_size} B |")

    lines.append("\n## Services\n")
    lines.append("| SID | Name | Sub-Functions | NRCs |")
    lines.append("|-----|------|---------------|------|")
    for s in sorted(spec.services, key=lambda x: x.service_id):
        lines.append(f"| {s.service_id_hex} | {s.short_name} | {len(s.sub_functions)} | {len(s.nrc_list)} |")

    lines.append("\n## Data Identifiers (DIDs)\n")
    lines.append("| DID | Name | Length | Read | Write |")
    lines.append("|-----|------|--------|------|-------|")
    for d in sorted(spec.dids, key=lambda x: x.did_id):
        lines.append(
            f"| {d.did_id_hex} | {d.short_name} | {d.total_byte_length} B "
            f"| {'Yes' if d.read_access else 'No'} | {'Yes' if d.write_access else 'No'} |"
        )

    lines.append("\n## Routines\n")
    lines.append("| ID | Name | Start | Stop | Result |")
    lines.append("|----|------|-------|------|--------|")
    for r in sorted(spec.routines, key=lambda x: x.routine_id):
        lines.append(
            f"| {r.routine_id_hex} | {r.short_name} "
            f"| {'Yes' if r.start_supported else 'No'} "
            f"| {'Yes' if r.stop_supported else 'No'} "
            f"| {'Yes' if r.result_supported else 'No'} |"
        )

    lines.append("\n## DTCs\n")
    lines.append("| DTC | Name | Severity |")
    lines.append("|-----|------|----------|")
    for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
        lines.append(f"| {d.dtc_id_hex} | {d.short_name} | {d.severity} |")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helper: CSV export (returns ZIP bytes)
# ---------------------------------------------------------------------------

def _spec_to_csv_zip(spec: object) -> bytes:
    """Return a ZIP archive containing multiple CSV files for the specification."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # sessions.csv
        rows = ["id,name,p2_server_max,p2_star_server_max"]
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            rows.append(f"{s.session_id_hex},{s.short_name},{s.p2_server_max},{s.p2_star_server_max}")
        zf.writestr("sessions.csv", "\n".join(rows))

        # security_levels.csv
        rows = ["level,name,seed_size,key_size"]
        for s in sorted(spec.security_levels, key=lambda x: x.security_level):
            rows.append(f"{s.security_level_hex},{s.short_name},{s.seed_size},{s.key_size}")
        zf.writestr("security_levels.csv", "\n".join(rows))

        # services.csv
        rows = ["sid,name,sub_function_count,nrc_count"]
        for s in sorted(spec.services, key=lambda x: x.service_id):
            rows.append(f"{s.service_id_hex},{s.short_name},{len(s.sub_functions)},{len(s.nrc_list)}")
        zf.writestr("services.csv", "\n".join(rows))

        # dids.csv
        rows = ["did,name,length,read_access,write_access"]
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            rows.append(
                f"{d.did_id_hex},{d.short_name},{d.total_byte_length},"
                f"{'1' if d.read_access else '0'},{'1' if d.write_access else '0'}"
            )
        zf.writestr("dids.csv", "\n".join(rows))

        # routines.csv
        rows = ["id,name,start_supported,stop_supported,result_supported"]
        for r in sorted(spec.routines, key=lambda x: x.routine_id):
            rows.append(
                f"{r.routine_id_hex},{r.short_name},"
                f"{'1' if r.start_supported else '0'},"
                f"{'1' if r.stop_supported else '0'},"
                f"{'1' if r.result_supported else '0'}"
            )
        zf.writestr("routines.csv", "\n".join(rows))

        # dtcs.csv
        rows = ["dtc,name,severity"]
        for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
            rows.append(f"{d.dtc_id_hex},{d.short_name},{d.severity}")
        zf.writestr("dtcs.csv", "\n".join(rows))

    return buf.getvalue()


# ---------------------------------------------------------------------------
# Helper: dict export (for JSON/YAML)
# ---------------------------------------------------------------------------

def _spec_to_dict(spec: object) -> dict:
    """Convert a UdsSpecification to a plain dict for JSON/YAML serialisation."""
    return {
        "ecu_name": spec.ecu_name,
        "protocol_name": spec.protocol_name,
        "protocol_type": spec.protocol_type,
        "sessions": [
            {
                "id": s.session_id_hex,
                "name": s.short_name,
                "p2_server_max": s.p2_server_max,
                "p2_star_server_max": s.p2_star_server_max,
            }
            for s in sorted(spec.sessions, key=lambda x: x.session_id)
        ],
        "security_levels": [
            {
                "level": s.security_level_hex,
                "name": s.short_name,
                "seed_size": s.seed_size,
                "key_size": s.key_size,
            }
            for s in sorted(spec.security_levels, key=lambda x: x.security_level)
        ],
        "services": [
            {
                "sid": s.service_id_hex,
                "name": s.short_name,
                "sub_function_count": len(s.sub_functions),
                "nrc_count": len(s.nrc_list),
            }
            for s in sorted(spec.services, key=lambda x: x.service_id)
        ],
        "dids": [
            {
                "id": d.did_id_hex,
                "name": d.short_name,
                "length": d.total_byte_length,
                "read_access": d.read_access,
                "write_access": d.write_access,
            }
            for d in sorted(spec.dids, key=lambda x: x.did_id)
        ],
        "routines": [
            {
                "id": r.routine_id_hex,
                "name": r.short_name,
                "start_supported": r.start_supported,
                "stop_supported": r.stop_supported,
                "result_supported": r.result_supported,
            }
            for r in sorted(spec.routines, key=lambda x: x.routine_id)
        ],
        "dtcs": [
            {
                "id": d.dtc_id_hex,
                "name": d.short_name,
                "severity": d.severity,
            }
            for d in sorted(spec.dtcs, key=lambda x: x.dtc_id)
        ],
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _load_dotenv_if_available() -> Optional[Path]:
    """Best-effort autoload a ``.env`` file from cwd (and parents) so that
    keys like ``ANTHROPIC_API_KEY`` set in a project-local ``.env`` are
    picked up by ``udsxml2tex --serve`` without the user having to
    ``export`` them in every shell.

    Returns the path of the file that was loaded, or ``None`` when
    ``python-dotenv`` is not installed or no ``.env`` was found.
    Existing environment variables are never overwritten.
    """
    try:
        from dotenv import find_dotenv, load_dotenv  # type: ignore[import]
    except ImportError:
        return None
    path = find_dotenv(usecwd=True)
    if not path:
        return None
    load_dotenv(path, override=False)
    return Path(path)


def _probe_llm_sdks() -> None:
    """Emit one-shot WARNING logs at server startup when the optional LLM
    SDKs are missing, so users see a clear actionable hint in the
    terminal where ``--serve`` was launched instead of only discovering
    the gap when they click "Verify" in the browser.
    """
    missing: list[str] = []
    try:
        import anthropic  # noqa: F401
    except ImportError:
        missing.append("anthropic")
    try:
        import openai  # noqa: F401
    except ImportError:
        # openai is optional even with [llm] — local Ollama/llama.cpp work
        # via the HTTP fallback, so only mention it alongside anthropic.
        if "anthropic" in missing:
            missing.append("openai")
    if missing:
        logger.warning(
            "Optional LLM SDK not installed (%s). LLM-backed features "
            "(chat, RTM Verify, rationale) will return an error until "
            "you run:  pip install 'udsxml2tex[llm]'",
            ", ".join(missing),
        )
    if not os.environ.get("ANTHROPIC_API_KEY") and not os.environ.get(
            "OPENAI_API_KEY") and not os.environ.get("UDSXML2TEX_LLM_API_KEY"):
        logger.warning(
            "No LLM API key found in environment "
            "(ANTHROPIC_API_KEY / OPENAI_API_KEY / UDSXML2TEX_LLM_API_KEY). "
            "Create a .env file in this directory with e.g. "
            "ANTHROPIC_API_KEY=sk-ant-... — python-dotenv will load it "
            "automatically on the next --serve."
        )


def start_server(
    host: str = "127.0.0.1",
    port: int = 8765,
    open_browser: bool = True,
) -> None:
    """Start the uvicorn web server.

    Args:
        host: Bind address (default: 127.0.0.1).
        port: TCP port (default: 8765).
        open_browser: If True, open the browser automatically after startup.
    """
    _require_fastapi()

    # Load .env *before* _create_app() so any LLMConfig.auto() built during
    # request handling sees the variables. Logged after the uvicorn banner
    # would be too late to be actionable, so do it now.
    env_path = _load_dotenv_if_available()
    if env_path is not None:
        logger.info("Loaded environment variables from %s", env_path)
    _probe_llm_sdks()

    app = _create_app()
    url = f"http://{host}:{port}"

    if open_browser:
        def _open() -> None:
            import time
            time.sleep(0.5)
            webbrowser.open(url)

        t = threading.Thread(target=_open, daemon=True)
        t.start()

    logger.info("Starting udsxml2tex web server at %s", url)
    uvicorn.run(app, host=host, port=port)
