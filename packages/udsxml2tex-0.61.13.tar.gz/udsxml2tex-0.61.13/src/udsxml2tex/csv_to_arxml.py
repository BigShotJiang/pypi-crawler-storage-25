"""Generate an AUTOSAR ECU skeleton ZIP (Dcm + Dem + CanTp + PduR) from
an OEM requirement CSV.

Use case
--------

In a typical OEM/Tier-1 split, the application team owns the drive-cycle
diagnostic ARXMLs (Dcm/CanTp/DEM) but the **bootloader** is contracted out
to an external team that delivers a binary only. The OEM ships a
requirement-analysis CSV (loaded via :func:`udsxml2tex.rtm.load_rtm_csv`)
that lists every SID / DID / RID / DTC / Session / SecurityLevel the boot
team must implement. Until the boot team's ARXML lands, the application
team has no way to render a unified Boot+App spec — they have to choose
between leaving the boot side empty or hand-writing a stub ARXML.

This module closes that gap. Given a list of :class:`RtmEntry`, it emits a
**ZIP bundle** containing the four ARXMLs that AUTOSAR splits UDS-on-CAN
across — Dcm (services / DIDs / RIDs / sessions / security),
Dem (DTCs / EventParameters), CanTp (N-PDU mapping, BS, STmin, addressing),
and PduR (Dcm↔CanTp routing) — so:

* :class:`udsxml2tex.parser.ArxmlParser` can parse the Dcm/Dem/CanTp back in,
* :func:`udsxml2tex.multi_ecu.loader.merge_boot_spec` can fold it into
  the application spec with ``domain="boot"`` / ``"both"`` tags,
* the result becomes a contract that the application team hands to the
  boot team (and that the boot team's eventual real ARXML must satisfy).

The generated ARXML is intentionally minimal — only enough metadata to
keep ``ArxmlParser`` happy. Timing parameters (P2/P2*), security key
sizes etc. are left to the boot team's real ARXML; this file is a
*requirements skeleton*, not a configuration delivery.

The function :func:`generate_arxml_from_rtm` is the only public entry
point. The CLI wrapper lives in :mod:`udsxml2tex.cli`
(``--gen-arxml-from-csv``).
"""

from __future__ import annotations

import io
import logging
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from lxml import etree as _etree

from udsxml2tex.rtm import RtmEntry, RtmTrace

logger = logging.getLogger(__name__)

#: ZIP member filename template — keyed by module shortname for easy
#: programmatic access from tests and the web UI.
ZIP_MEMBER_NAMES: tuple[str, ...] = ("Dcm", "Dem", "CanTp", "PduR")

# Default identifier ranges considered "bootloader-domain" when the caller
# asks the generator to filter the CSV down to only boot-relevant rows.
# These come straight from ISO 14229-1: SID 0x34/0x35/0x36/0x37 are the
# upload/download family, RID 0xFF00 / 0xFF01 are eraseMemory and
# checkProgrammingDependencies, DID 0xF180-0xF1FF are the identification
# DIDs the tester reads during programming, session 0x02 is
# ProgrammingSession, and security level 0x01 is the only one strictly
# required before RequestDownload.
_BOOT_SIDS: frozenset[int] = frozenset({
    0x10,   # DiagnosticSessionControl — gateway to programming session
    0x11,   # ECUReset — required after flash
    0x22,   # ReadDataByIdentifier — for F18x identification DIDs
    0x27,   # SecurityAccess
    0x28,   # CommunicationControl (silence the bus during flash)
    0x31,   # RoutineControl — for eraseMemory / checkProgrammingDependencies
    0x34,   # RequestDownload
    0x35,   # RequestUpload
    0x36,   # TransferData
    0x37,   # RequestTransferExit
    0x3E,   # TesterPresent
    0x85,   # ControlDTCSetting (suppress DTC logging during flash)
})

# DID range observed in ISO 14229-1 Annex C.1 as identification DIDs
# (App SW version, fingerprint, ECU manufacturer SW version, …).
_BOOT_DID_RANGE: tuple[int, int] = (0xF180, 0xF1FF)

# Routine IDs reserved by ISO 14229-1 §C.4 for OEM-defined boot routines.
_BOOT_RID_RANGE: tuple[int, int] = (0xFF00, 0xFFFF)


def _is_boot_relevant_trace(trace: RtmTrace) -> bool:
    """Return True when *trace* is part of the bootloader-domain contract.

    Heuristic mirrors the ISO 14229-1 reprogramming sequence (Annex C):
    download/upload services, identification DID range, OEM-routine RID
    range, ProgrammingSession (0x02) and the first security level (0x01).
    """
    try:
        primary = int(trace.primary, 16)
    except (TypeError, ValueError):
        return False
    if trace.kind == "sid":
        return primary in _BOOT_SIDS
    if trace.kind == "did":
        return _BOOT_DID_RANGE[0] <= primary <= _BOOT_DID_RANGE[1]
    if trace.kind == "rid":
        return _BOOT_RID_RANGE[0] <= primary <= _BOOT_RID_RANGE[1]
    if trace.kind == "session":
        return primary == 0x02
    if trace.kind == "security":
        return primary in (0x01, 0x03, 0x05, 0x07, 0x09)  # odd = seed levels
    if trace.kind == "dtc":
        # Programming-related DTCs are not standardised; the caller can
        # opt-out of DTC filtering via domain_filter="all". For "boot"
        # we deliberately exclude DTCs because they are a DEM concern.
        return False
    return False


@dataclass
class _Collected:
    """Bucketed unique IDs gathered from an RtmEntry stream.

    Stored as ``{int_id: short_name}`` so the ARXML emitter can use a
    human-readable SHORT-NAME (taken from the first occurrence's
    ``resolved_name`` or the requirement description) when the CSV
    carries one.
    """
    sessions: dict[int, str] = field(default_factory=dict)
    security_levels: dict[int, str] = field(default_factory=dict)
    services: dict[int, str] = field(default_factory=dict)
    dids: dict[int, str] = field(default_factory=dict)
    rids: dict[int, str] = field(default_factory=dict)
    dtcs: dict[int, str] = field(default_factory=dict)


def _short_name_for(trace: RtmTrace, entry: RtmEntry, default_prefix: str) -> str:
    """Derive a SHORT-NAME for the ARXML container.

    Preference order:

    1. ``trace.resolved_name`` if the trace already resolved against an
       upstream spec (rare for a "we don't have the ARXML yet" workflow
       but cheap to honour).
    2. The requirement's req_id, lightly sanitised to satisfy the
       AUTOSAR SHORT-NAME identifier rules ([A-Za-z][A-Za-z0-9_]*).
    3. ``default_prefix`` + the hex id (e.g. ``Did_F184``).
    """
    if trace.resolved_name:
        return _sanitise_short_name(trace.resolved_name)
    if entry.req_id:
        cand = _sanitise_short_name(entry.req_id)
        if cand:
            return cand
    try:
        n = int(trace.primary, 16)
    except (TypeError, ValueError):
        return default_prefix
    width = 2 if trace.kind in ("sid", "session", "security") else 4
    if trace.kind == "dtc":
        width = 6
    return f"{default_prefix}_{n:0{width}X}"


def _sanitise_short_name(name: str) -> str:
    """Coerce *name* into the AUTOSAR SHORT-NAME regex [A-Za-z][A-Za-z0-9_]*.

    Replaces every disallowed character with ``_`` and prepends ``N_`` if
    the first character is not a letter. Returns ``""`` for an empty/all-
    invalid input so callers can fall back to a positional default.
    """
    if not name:
        return ""
    out_chars = []
    for ch in name:
        if ch.isalnum() or ch == "_":
            out_chars.append(ch)
        else:
            out_chars.append("_")
    out = "".join(out_chars).strip("_")
    if not out:
        return ""
    if not out[0].isalpha():
        out = "N_" + out
    return out


def _collect(entries: Iterable[RtmEntry], *,
             domain_filter: str) -> _Collected:
    """Walk *entries* and bucket their traces by element kind.

    ``domain_filter``:

    * ``"boot"``  — keep only traces matching :func:`_is_boot_relevant_trace`.
    * ``"drive"`` — keep only traces that **don't** match that heuristic.
    * ``"both"`` / ``"all"`` — keep every traced element.
    """
    coll = _Collected()
    for entry in entries:
        for tr in entry.traces_to:
            if domain_filter == "boot" and not _is_boot_relevant_trace(tr):
                continue
            if domain_filter == "drive" and _is_boot_relevant_trace(tr):
                continue
            try:
                primary = int(tr.primary, 16)
            except (TypeError, ValueError):
                continue
            if tr.kind == "session":
                coll.sessions.setdefault(primary,
                    _short_name_for(tr, entry, "Session"))
            elif tr.kind == "security":
                coll.security_levels.setdefault(primary,
                    _short_name_for(tr, entry, "SecurityLevel"))
            elif tr.kind == "sid":
                coll.services.setdefault(primary,
                    _short_name_for(tr, entry, "Service"))
            elif tr.kind == "did":
                coll.dids.setdefault(primary,
                    _short_name_for(tr, entry, "Did"))
            elif tr.kind == "rid":
                coll.rids.setdefault(primary,
                    _short_name_for(tr, entry, "Routine"))
            elif tr.kind == "dtc":
                coll.dtcs.setdefault(primary,
                    _short_name_for(tr, entry, "Dtc"))
    return coll


# ---------------------------------------------------------------------------
# ARXML emission
# ---------------------------------------------------------------------------

_AR_NS = "http://autosar.org/schema/r4.0"
_NSMAP = {None: _AR_NS}


def _el(tag: str, parent=None, text: Optional[str] = None, **attrs):
    """Tiny helper to keep the emitter readable."""
    e = _etree.SubElement(parent, f"{{{_AR_NS}}}{tag}", **attrs) if parent is not None \
        else _etree.Element(f"{{{_AR_NS}}}{tag}", nsmap=_NSMAP, **attrs)
    if text is not None:
        e.text = text
    return e


def _num_param(parent, def_ref: str, value: str) -> None:
    p = _el("ECUC-NUMERICAL-PARAM-VALUE", parent)
    _el("DEFINITION-REF", p, def_ref, attrib={"DEST": "ECUC-INTEGER-PARAM-DEF"})
    _el("VALUE", p, value)


def _emit_session_container(parent, level: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsp/DcmDspSession/DcmDspSessionRow",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsp/DcmDspSession/DcmDspSessionLevel",
               str(level))


def _emit_security_container(parent, level: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsp/DcmDspSecurity/DcmDspSecurityRow",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsp/DcmDspSecurity/DcmDspSecurityRow/DcmDspSecurityLevel",
               str(level))


def _emit_did_container(parent, did_id: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsp/DcmDspDid",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsp/DcmDspDid/DcmDspDidIdentifier",
               f"0x{did_id:04X}")


def _emit_routine_container(parent, rid: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsp/DcmDspRoutine",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsp/DcmDspRoutine/DcmDspRoutineIdentifier",
               f"0x{rid:04X}")


def _emit_sid_container(parent, sid: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsd/DcmDsdServiceTable/DcmDsdService",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsd/DcmDsdServiceTable/DcmDsdService/DcmDsdSidTabServiceId",
               f"0x{sid:02X}")


def _emit_subcontainer_group(dcmdsp_subs, group_name: str,
                             def_path: str,
                             emit_fn, items: dict) -> None:
    """Emit one of DcmDspSession / DcmDspSecurity / DcmDspDid / DcmDspRoutine."""
    if not items:
        return
    grp = _el("ECUC-CONTAINER-VALUE", dcmdsp_subs)
    _el("SHORT-NAME", grp, group_name)
    _el("DEFINITION-REF", grp, def_path,
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    sub = _el("SUB-CONTAINERS", grp)
    # Stable order: lowest ID first.
    for key in sorted(items.keys()):
        emit_fn(sub, key, items[key])


def generate_arxml_from_rtm(
    entries: Iterable[RtmEntry],
    *,
    output_path: Optional[Path] = None,
    ecu_name: str = "BootECU",
    module_short_name: str = "DcmBootSkeleton",
    domain_filter: str = "boot",
) -> bytes:
    """Build an AUTOSAR ECU skeleton **ZIP** (Dcm + Dem + CanTp + PduR) from
    *entries* and (optionally) write it to *output_path*.

    .. versionchanged:: 0.61.7
       BREAKING: previously returned a single Dcm ARXML byte-string. Now
       returns a ZIP archive containing four ARXMLs because a single
       Dcm file is insufficient to describe a UDS-on-CAN ECU — the parser
       (and any real toolchain) expects DTCs in a separate Dem file,
       transport timing in CanTp, and Dcm↔CanTp routing in PduR.

    Args:
        entries:           RtmEntry list (typically the output of
                           :func:`udsxml2tex.rtm.load_rtm_csv` /
                           :func:`load_rtm_csvs`).
        output_path:       Destination ``*.zip`` path. ``None`` skips the
                           file write (useful for tests / in-memory use).
        ecu_name:          AR-PACKAGE SHORT-NAME at the top of each member
                           ARXML — customarily ``"<EcuName>EcuC"`` so an
                           importer can tell which ECU it belongs to.
        module_short_name: Dcm ECUC-MODULE-CONFIGURATION-VALUES SHORT-NAME.
        domain_filter:     ``"boot"`` (default), ``"drive"``, ``"both"`` /
                           ``"all"``. See :func:`_collect`.

    Returns:
        The serialised ZIP bytes. Members:

        * ``Dcm_<EcuName>.arxml``  — services, sessions, security, DIDs, RIDs
        * ``Dem_<EcuName>.arxml``  — DTCs + EventParameters (only when the
          filter yielded at least one DTC)
        * ``CanTp_<EcuName>.arxml`` — one CanTpChannel with Phys/Func
          Rx-NSdu + Tx-NSdu (STANDARD addressing, BS=8, STmin=10ms,
          padding 0xCC) — ISO 15765-2 §9.4 defaults
        * ``PduR_<EcuName>.arxml`` — one Dcm→CanTp routing path per
          direction (Phys-Rx, Phys-Tx, Func-Rx)
        * ``README.txt`` — module map + warning that this is a skeleton

    Raises:
        ValueError: ``domain_filter`` is not one of the accepted values, or
                    the filter produced an empty skeleton (no traceable
                    elements). The caller should treat the latter as a
                    requirements-analysis problem to surface to the user.
    """
    if domain_filter not in {"boot", "drive", "both", "all"}:
        raise ValueError(
            f"domain_filter must be one of boot/drive/both/all, "
            f"got {domain_filter!r}"
        )
    collected = _collect(list(entries), domain_filter=domain_filter)
    total = (
        len(collected.sessions) + len(collected.security_levels)
        + len(collected.services) + len(collected.dids)
        + len(collected.rids) + len(collected.dtcs)
    )
    if total == 0:
        raise ValueError(
            "CSV produced no traceable elements after domain filter "
            f"{domain_filter!r}. Check that the CSV's traces_to column "
            "carries at least one sid:/did:/rid:/session:/security: token "
            "matching the chosen domain."
        )

    safe_ecu = _sanitise_short_name(ecu_name) or "BootECU"

    # --- Build the four module ARXMLs --------------------------------------
    dcm_bytes = _build_dcm_arxml(collected, ecu_name, module_short_name)
    dem_bytes = _build_dem_arxml(collected, ecu_name) if collected.dtcs else None
    cantp_bytes = _build_cantp_arxml(ecu_name)
    pdur_bytes = _build_pdur_arxml(ecu_name)

    # --- Wrap in a ZIP ------------------------------------------------------
    members: list[tuple[str, bytes]] = [
        (f"Dcm_{safe_ecu}.arxml", dcm_bytes),
        (f"CanTp_{safe_ecu}.arxml", cantp_bytes),
        (f"PduR_{safe_ecu}.arxml", pdur_bytes),
    ]
    if dem_bytes is not None:
        members.insert(1, (f"Dem_{safe_ecu}.arxml", dem_bytes))

    readme = (
        f"AUTOSAR ECU skeleton bundle for '{ecu_name}' "
        f"(domain={domain_filter})\n"
        f"Generated by udsxml2tex.csv_to_arxml.generate_arxml_from_rtm\n\n"
        f"Members:\n"
        + "\n".join(f"  - {name}" for name, _ in members)
        + "\n\n"
        "This is a requirements-traceability skeleton, NOT a configuration\n"
        "delivery. Timing values (P2/P2*, security key sizes, CanTp BS/STmin)\n"
        "are placeholders and MUST be reviewed against the actual ECU spec\n"
        "before being used in a real build.\n"
    ).encode("utf-8")

    zbuf = io.BytesIO()
    with zipfile.ZipFile(zbuf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, data in members:
            zf.writestr(name, data)
        zf.writestr("README.txt", readme)
    zip_bytes = zbuf.getvalue()

    if output_path is not None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(zip_bytes)
        logger.info(
            "csv_to_arxml: wrote %s "
            "(%d service(s), %d session(s), %d security level(s), "
            "%d DID(s), %d routine(s), %d DTC(s); %d ARXML member(s) in ZIP)",
            output_path,
            len(collected.services), len(collected.sessions),
            len(collected.security_levels), len(collected.dids),
            len(collected.rids), len(collected.dtcs),
            len(members),
        )
    return zip_bytes


def _build_dcm_arxml(
    collected: _Collected,
    ecu_name: str,
    module_short_name: str,
) -> bytes:
    """Serialise the Dcm ARXML for *collected*.

    Extracted from the original single-file emitter so the multi-module
    ZIP wrapper can call all four module builders in parallel.
    """
    autosar = _el("AUTOSAR")
    autosar.set(
        "{http://www.w3.org/2001/XMLSchema-instance}schemaLocation",
        "http://autosar.org/schema/r4.0 AUTOSAR_4-3-0.xsd",
    )
    ar_packages = _el("AR-PACKAGES", autosar)
    pkg = _el("AR-PACKAGE", ar_packages)
    pkg_short_name = _sanitise_short_name(ecu_name) or "BootECU"
    if not pkg_short_name.endswith("EcuC"):
        pkg_short_name = pkg_short_name + "EcuC"
    _el("SHORT-NAME", pkg, pkg_short_name)
    sub_pkgs = _el("AR-PACKAGES", pkg)
    dcm_pkg = _el("AR-PACKAGE", sub_pkgs)
    _el("SHORT-NAME", dcm_pkg, "Dcm")
    elements = _el("ELEMENTS", dcm_pkg)

    module = _el("ECUC-MODULE-CONFIGURATION-VALUES", elements)
    _el("SHORT-NAME", module, _sanitise_short_name(module_short_name)
        or "DcmBootSkeleton")
    _el("DEFINITION-REF", module,
        "/AUTOSAR/Dcm",
        attrib={"DEST": "ECUC-MODULE-DEF"})
    containers = _el("CONTAINERS", module)

    # ----- DcmDsd (services) ------------------------------------------------
    if collected.services:
        dcmdsd = _el("ECUC-CONTAINER-VALUE", containers)
        _el("SHORT-NAME", dcmdsd, "DcmDsd")
        _el("DEFINITION-REF", dcmdsd, "/AUTOSAR/Dcm/DcmDsd",
            attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
        dsd_subs = _el("SUB-CONTAINERS", dcmdsd)
        svc_tbl = _el("ECUC-CONTAINER-VALUE", dsd_subs)
        _el("SHORT-NAME", svc_tbl, "DcmDsdServiceTable")
        _el("DEFINITION-REF", svc_tbl,
            "/AUTOSAR/Dcm/DcmDsd/DcmDsdServiceTable",
            attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
        svc_subs = _el("SUB-CONTAINERS", svc_tbl)
        for sid in sorted(collected.services.keys()):
            _emit_sid_container(svc_subs, sid, collected.services[sid])

    # ----- DcmDsp (sessions / security / DIDs / routines) ------------------
    dcmdsp = _el("ECUC-CONTAINER-VALUE", containers)
    _el("SHORT-NAME", dcmdsp, "DcmDsp")
    _el("DEFINITION-REF", dcmdsp, "/AUTOSAR/Dcm/DcmDsp",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    dsp_subs = _el("SUB-CONTAINERS", dcmdsp)

    _emit_subcontainer_group(
        dsp_subs, "DcmDspSession",
        "/AUTOSAR/Dcm/DcmDsp/DcmDspSession",
        _emit_session_container, collected.sessions,
    )
    _emit_subcontainer_group(
        dsp_subs, "DcmDspSecurity",
        "/AUTOSAR/Dcm/DcmDsp/DcmDspSecurity",
        _emit_security_container, collected.security_levels,
    )
    _emit_subcontainer_group(
        dsp_subs, "DcmDspDid",
        "/AUTOSAR/Dcm/DcmDsp/DcmDspDid",
        _emit_did_container, collected.dids,
    )
    _emit_subcontainer_group(
        dsp_subs, "DcmDspRoutine",
        "/AUTOSAR/Dcm/DcmDsp/DcmDspRoutine",
        _emit_routine_container, collected.rids,
    )

    return _etree.tostring(
        autosar, xml_declaration=True, encoding="UTF-8", pretty_print=True,
    )


def _build_dem_arxml(collected: _Collected, ecu_name: str) -> bytes:
    """Serialise a Dem ARXML containing one DemDTC per collected DTC.

    Schema matches what :class:`udsxml2tex.dem_parser.DemArxmlParser`
    accepts: ``DemConfigSet`` container holding ``DemDTC_*`` siblings,
    each carrying a ``DemDtcValue`` parameter. We also emit a paired
    ``DemEventParameter`` per DTC so downstream tooling sees an event
    name; the link from event→DTC is via SHORT-NAME convention.
    """
    autosar = _el("AUTOSAR")
    autosar.set(
        "{http://www.w3.org/2001/XMLSchema-instance}schemaLocation",
        "http://autosar.org/schema/r4.0 AUTOSAR_4-3-0.xsd",
    )
    ar_packages = _el("AR-PACKAGES", autosar)
    pkg = _el("AR-PACKAGE", ar_packages)
    pkg_short_name = _sanitise_short_name(ecu_name) or "BootECU"
    if not pkg_short_name.endswith("EcuC"):
        pkg_short_name = pkg_short_name + "EcuC"
    _el("SHORT-NAME", pkg, pkg_short_name)
    sub_pkgs = _el("AR-PACKAGES", pkg)
    dem_pkg = _el("AR-PACKAGE", sub_pkgs)
    _el("SHORT-NAME", dem_pkg, "Dem")
    elements = _el("ELEMENTS", dem_pkg)

    module = _el("ECUC-MODULE-CONFIGURATION-VALUES", elements)
    _el("SHORT-NAME", module, "DemBootSkeleton")
    _el("DEFINITION-REF", module, "/AUTOSAR/Dem",
        attrib={"DEST": "ECUC-MODULE-DEF"})
    containers = _el("CONTAINERS", module)

    cfgset = _el("ECUC-CONTAINER-VALUE", containers)
    _el("SHORT-NAME", cfgset, "DemConfigSet")
    _el("DEFINITION-REF", cfgset, "/AUTOSAR/Dem/DemConfigSet",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    subs = _el("SUB-CONTAINERS", cfgset)

    for dtc_value in sorted(collected.dtcs.keys()):
        short = collected.dtcs[dtc_value] or f"DemDTC_{dtc_value:06X}"
        # DemDTC container
        cv = _el("ECUC-CONTAINER-VALUE", subs)
        _el("SHORT-NAME", cv, short if short.startswith("DemDTC") else f"DemDTC_{short}")
        _el("DEFINITION-REF", cv, "/AUTOSAR/Dem/DemConfigSet/DemDTC",
            attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
        pv = _el("PARAMETER-VALUES", cv)
        _num_param(pv,
                   "/AUTOSAR/Dem/DemConfigSet/DemDTC/DemDtcValue",
                   f"0x{dtc_value:06X}")
        # Paired DemEventParameter
        ev = _el("ECUC-CONTAINER-VALUE", subs)
        _el("SHORT-NAME", ev, f"DemEvent_{dtc_value:06X}")
        _el("DEFINITION-REF", ev,
            "/AUTOSAR/Dem/DemConfigSet/DemEventParameter",
            attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})

    return _etree.tostring(
        autosar, xml_declaration=True, encoding="UTF-8", pretty_print=True,
    )


def _build_cantp_arxml(ecu_name: str) -> bytes:
    """Serialise a minimal CanTp ARXML — one channel, Phys+Func Rx/Tx NSdu.

    Parameter values (BS=8, STmin=10ms, STANDARD addressing, padding 0xCC)
    are ISO 15765-2 §9.4 defaults safe for a 11-bit-ID CAN-FD-light setup.
    The boot team is expected to overwrite them against the real
    network-design ARXML; this skeleton exists so the parser sees a
    well-formed CanTp module rather than nothing at all.
    """
    autosar = _el("AUTOSAR")
    autosar.set(
        "{http://www.w3.org/2001/XMLSchema-instance}schemaLocation",
        "http://autosar.org/schema/r4.0 AUTOSAR_4-3-0.xsd",
    )
    ar_packages = _el("AR-PACKAGES", autosar)
    pkg = _el("AR-PACKAGE", ar_packages)
    pkg_short_name = _sanitise_short_name(ecu_name) or "BootECU"
    if not pkg_short_name.endswith("EcuC"):
        pkg_short_name = pkg_short_name + "EcuC"
    _el("SHORT-NAME", pkg, pkg_short_name)
    sub_pkgs = _el("AR-PACKAGES", pkg)
    cantp_pkg = _el("AR-PACKAGE", sub_pkgs)
    _el("SHORT-NAME", cantp_pkg, "CanTp")
    elements = _el("ELEMENTS", cantp_pkg)

    module = _el("ECUC-MODULE-CONFIGURATION-VALUES", elements)
    _el("SHORT-NAME", module, "CanTpBootSkeleton")
    _el("DEFINITION-REF", module, "/AUTOSAR/CanTp",
        attrib={"DEST": "ECUC-MODULE-DEF"})
    containers = _el("CONTAINERS", module)

    ch = _el("ECUC-CONTAINER-VALUE", containers)
    _el("SHORT-NAME", ch, "CanTpChannel_Diag")
    _el("DEFINITION-REF", ch, "/AUTOSAR/CanTp/CanTpConfig/CanTpChannel",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    ch_pv = _el("PARAMETER-VALUES", ch)
    p = _el("ECUC-TEXTUAL-PARAM-VALUE", ch_pv)
    _el("DEFINITION-REF", p,
        "/AUTOSAR/CanTp/CanTpConfig/CanTpChannel/CanTpChannelMode",
        attrib={"DEST": "ECUC-ENUMERATION-PARAM-DEF"})
    _el("VALUE", p, "FULL_DUPLEX")

    ch_subs = _el("SUB-CONTAINERS", ch)

    def _emit_nsdu(
        parent, short_name: str, kind: str, n_pdu_id: int,
    ) -> None:
        """Emit one CanTpRxNSdu or CanTpTxNSdu sub-container."""
        sdu = _el("ECUC-CONTAINER-VALUE", parent)
        _el("SHORT-NAME", sdu, short_name)
        _el("DEFINITION-REF", sdu,
            f"/AUTOSAR/CanTp/CanTpConfig/CanTpChannel/{kind}",
            attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
        pv = _el("PARAMETER-VALUES", sdu)
        # N-PDU id
        id_def = (
            "CanTpRxNPduId" if kind == "CanTpRxNSdu" else "CanTpTxNPduId"
        )
        _num_param(pv,
                   f"/AUTOSAR/CanTp/CanTpConfig/CanTpChannel/{kind}/{id_def}",
                   str(n_pdu_id))
        # CanTpDl = 8 (classic CAN frame length)
        _num_param(pv,
                   f"/AUTOSAR/CanTp/CanTpConfig/CanTpChannel/{kind}/CanTpDl",
                   "8")
        # BS / STmin only meaningful on Rx — ISO 15765-2 §6.5.5/§6.5.5.5
        if kind == "CanTpRxNSdu":
            _num_param(pv,
                       f"/AUTOSAR/CanTp/CanTpConfig/CanTpChannel/{kind}/CanTpBs",
                       "8")
            _num_param(pv,
                       f"/AUTOSAR/CanTp/CanTpConfig/CanTpChannel/{kind}/CanTpSTmin",
                       "0.010")
        # Addressing format + padding (textual / numeric)
        af = _el("ECUC-TEXTUAL-PARAM-VALUE", pv)
        af_def = (
            "CanTpRxAddressingFormat" if kind == "CanTpRxNSdu"
            else "CanTpTxAddressingFormat"
        )
        _el("DEFINITION-REF", af,
            f"/AUTOSAR/CanTp/CanTpConfig/CanTpChannel/{kind}/{af_def}",
            attrib={"DEST": "ECUC-ENUMERATION-PARAM-DEF"})
        _el("VALUE", af, "STANDARD")

        pa = _el("ECUC-TEXTUAL-PARAM-VALUE", pv)
        _el("DEFINITION-REF", pa,
            f"/AUTOSAR/CanTp/CanTpConfig/CanTpChannel/{kind}/CanTpPaddingActivation",
            attrib={"DEST": "ECUC-BOOLEAN-PARAM-DEF"})
        _el("VALUE", pa, "true")

        _num_param(pv,
                   f"/AUTOSAR/CanTp/CanTpConfig/CanTpChannel/{kind}/CanTpPaddingByte",
                   "0xCC")

    _emit_nsdu(ch_subs, "CanTpRxNSdu_PhysReq", "CanTpRxNSdu", 1)
    _emit_nsdu(ch_subs, "CanTpRxNSdu_FuncReq", "CanTpRxNSdu", 3)
    _emit_nsdu(ch_subs, "CanTpTxNSdu_PhysResp", "CanTpTxNSdu", 2)
    _emit_nsdu(ch_subs, "CanTpTxNSdu_FuncResp", "CanTpTxNSdu", 4)

    return _etree.tostring(
        autosar, xml_declaration=True, encoding="UTF-8", pretty_print=True,
    )


def _build_pdur_arxml(ecu_name: str) -> bytes:
    """Serialise a minimal PduR ARXML wiring Dcm↔CanTp.

    PduR is not parsed by udsxml2tex (no PduR parser exists yet), so this
    skeleton only needs to be structurally well-formed ARXML — a real
    AUTOSAR toolchain would consume it for routing-table generation.
    """
    autosar = _el("AUTOSAR")
    autosar.set(
        "{http://www.w3.org/2001/XMLSchema-instance}schemaLocation",
        "http://autosar.org/schema/r4.0 AUTOSAR_4-3-0.xsd",
    )
    ar_packages = _el("AR-PACKAGES", autosar)
    pkg = _el("AR-PACKAGE", ar_packages)
    pkg_short_name = _sanitise_short_name(ecu_name) or "BootECU"
    if not pkg_short_name.endswith("EcuC"):
        pkg_short_name = pkg_short_name + "EcuC"
    _el("SHORT-NAME", pkg, pkg_short_name)
    sub_pkgs = _el("AR-PACKAGES", pkg)
    pdur_pkg = _el("AR-PACKAGE", sub_pkgs)
    _el("SHORT-NAME", pdur_pkg, "PduR")
    elements = _el("ELEMENTS", pdur_pkg)

    module = _el("ECUC-MODULE-CONFIGURATION-VALUES", elements)
    _el("SHORT-NAME", module, "PduRBootSkeleton")
    _el("DEFINITION-REF", module, "/AUTOSAR/PduR",
        attrib={"DEST": "ECUC-MODULE-DEF"})
    containers = _el("CONTAINERS", module)

    tab = _el("ECUC-CONTAINER-VALUE", containers)
    _el("SHORT-NAME", tab, "PduRRoutingTable")
    _el("DEFINITION-REF", tab,
        "/AUTOSAR/PduR/PduRRoutingTables/PduRRoutingTable",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    paths = _el("SUB-CONTAINERS", tab)

    # Three routes: Phys-Rx (CanTp→Dcm), Phys-Tx (Dcm→CanTp), Func-Rx
    # (CanTp→Dcm). All emit as named ECUC-CONTAINER-VALUE with a single
    # SHORT-NAME — enough to satisfy a schema-validating consumer.
    for name in ("PduRRoute_PhysRx", "PduRRoute_PhysTx", "PduRRoute_FuncRx"):
        rp = _el("ECUC-CONTAINER-VALUE", paths)
        _el("SHORT-NAME", rp, name)
        _el("DEFINITION-REF", rp,
            "/AUTOSAR/PduR/PduRRoutingTables/PduRRoutingTable/PduRRoutingPath",
            attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})

    return _etree.tostring(
        autosar, xml_declaration=True, encoding="UTF-8", pretty_print=True,
    )
