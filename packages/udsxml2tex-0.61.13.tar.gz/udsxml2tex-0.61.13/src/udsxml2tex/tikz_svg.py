"""TikZ-UML → SVG compilation helper.

Provides a small utility that wraps a TikZ snippet in a self-contained
``standalone`` LaTeX document (with ``tikz-uml.sty`` available on
``TEXINPUTS``), compiles it with ``xelatex``, and converts the resulting
PDF to inline SVG using whichever converter is available on the host
(``pdftocairo``, ``dvisvgm``, ``pdf2svg``, ``inkscape``, or the Python
``pymupdf`` package as an in-process fallback).

When the toolchain is unavailable the helper returns ``None`` so callers
can gracefully fall back to a Mermaid block.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
import tempfile
from importlib.resources import files as _ir_files
from pathlib import Path

logger = logging.getLogger(__name__)


_STANDALONE_PREAMBLE = r"""
\documentclass[tikz, border=8pt]{standalone}
\usepackage{tikz}
\usepackage{tikz-uml}
\usepackage{amsmath}
\usepackage{amssymb}
\usetikzlibrary{positioning, fit, backgrounds, shapes.geometric,
                shapes.misc, arrows.meta, calc}
\begin{document}
"""

_STANDALONE_POSTAMBLE = r"""
\end{document}
"""


def _tikz_uml_dir() -> Path | None:
    """Return the bundled ``tikz-uml.sty`` directory or ``None``."""
    try:
        sty = _ir_files("udsxml2tex").joinpath("templates", "assets",
                                                "tikz-uml.sty")
        # importlib.resources may return a Traversable; resolve to a real
        # filesystem path the LaTeX binary can read.
        sty_path = Path(str(sty))
        if sty_path.is_file():
            return sty_path.parent
    except Exception:  # noqa: BLE001
        pass
    return None


def _pymupdf_available() -> bool:
    """Return True when the optional :mod:`pymupdf` package is importable."""
    try:
        import pymupdf  # noqa: F401
    except Exception:  # noqa: BLE001
        return False
    return True


def _convert_pdf_with_pymupdf(pdf: Path, svg: Path) -> bool:
    """Render ``pdf``'s first page to ``svg`` using PyMuPDF in-process."""
    try:
        import pymupdf  # type: ignore
    except Exception:  # noqa: BLE001
        return False
    try:
        doc = pymupdf.open(str(pdf))
        if doc.page_count == 0:
            return False
        svg_text = doc[0].get_svg_image()
        svg.write_text(svg_text, encoding="utf-8")
        return svg.exists() and svg.stat().st_size > 0
    except Exception as exc:  # noqa: BLE001
        logger.debug("pymupdf pdf->svg failed: %s", exc)
        return False


def _convert_pdf_to_svg(pdf: Path, svg: Path) -> bool:
    """Convert ``pdf`` to ``svg`` using whichever tool is available."""
    cwd = pdf.parent
    if shutil.which("pdftocairo"):
        r = subprocess.run(
            ["pdftocairo", "-svg", pdf.name, svg.name],
            cwd=cwd, capture_output=True, timeout=60,
        )
        if r.returncode == 0 and svg.exists():
            return True
    if shutil.which("dvisvgm"):
        # dvisvgm understands PDF input via its built-in PDF processor.
        r = subprocess.run(
            ["dvisvgm", "--pdf", "--no-fonts", "--output", svg.name, pdf.name],
            cwd=cwd, capture_output=True, timeout=120,
        )
        if r.returncode == 0 and svg.exists():
            return True
    if shutil.which("pdf2svg"):
        r = subprocess.run(
            ["pdf2svg", pdf.name, svg.name],
            cwd=cwd, capture_output=True, timeout=60,
        )
        if r.returncode == 0 and svg.exists():
            return True
    if shutil.which("inkscape"):
        r = subprocess.run(
            ["inkscape", pdf.name, "--export-type=svg",
             f"--export-filename={svg.name}"],
            cwd=cwd, capture_output=True, timeout=120,
        )
        if r.returncode == 0 and svg.exists():
            return True
    # In-process fallback when no external binary converter is installed.
    # PyMuPDF ships precompiled wheels (including a bundled MuPDF), so this
    # is the most reliable path on systems without Homebrew / MiKTeX extras.
    if _convert_pdf_with_pymupdf(pdf, svg):
        return True
    return False


def has_toolchain() -> bool:
    """Return ``True`` when a LaTeX engine and a PDF→SVG tool are present."""
    engine = shutil.which("xelatex") or shutil.which("lualatex") \
        or shutil.which("pdflatex")
    converter = (shutil.which("pdftocairo") or shutil.which("dvisvgm")
                 or shutil.which("pdf2svg") or shutil.which("inkscape")
                 or _pymupdf_available())
    return bool(engine and converter)


def compile_tikz_to_svg(tikz_body: str,
                        *,
                        extra_preamble: str = "",
                        svg_class: str | None = None) -> str | None:
    """Compile a TikZ snippet to inline SVG markup.

    ``tikz_body`` should contain just the ``\\begin{tikzpicture}…\\end{tikzpicture}``
    (or ``\\begin{figure}`` wrapper-free) content. The function wraps it in
    a ``standalone`` document, compiles with the first available LaTeX
    engine, then converts to SVG using the first available converter.

    Returns the SVG markup string ready to embed in HTML, or ``None`` when
    the toolchain is missing or compilation fails.
    """
    engine = (shutil.which("xelatex") or shutil.which("lualatex")
              or shutil.which("pdflatex"))
    if not engine:
        return None
    # Fast-path: skip the LaTeX compile when no PDF→SVG converter exists.
    if not (shutil.which("pdftocairo") or shutil.which("dvisvgm")
            or shutil.which("pdf2svg") or shutil.which("inkscape")
            or _pymupdf_available()):
        return None

    sty_dir = _tikz_uml_dir()
    env = os.environ.copy()
    if sty_dir is not None:
        # Prepend our directory so the bundled tikz-uml.sty is preferred.
        existing = env.get("TEXINPUTS", "")
        env["TEXINPUTS"] = f"{sty_dir}{os.pathsep}{existing}"

    tex_source = (_STANDALONE_PREAMBLE
                  + (extra_preamble + "\n" if extra_preamble else "")
                  + tikz_body.strip() + "\n"
                  + _STANDALONE_POSTAMBLE)

    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            tex = tmp / "fig.tex"
            tex.write_text(tex_source, encoding="utf-8")
            # Note: tikz-uml's \umlfragment / \umlcallself macros emit
            # benign "Extra \or" warnings via ifthen.sty under recent
            # LaTeX kernels. Those raise xelatex's return code to 1
            # even though a usable PDF is produced. Treat ``pdf.exists()``
            # as the source of truth for compile success rather than the
            # returncode (and skip ``-halt-on-error`` for the same reason).
            r1 = subprocess.run(
                [engine, "-interaction=nonstopmode", "fig.tex"],
                cwd=tmp, env=env, capture_output=True, timeout=120,
            )
            pdf = tmp / "fig.pdf"
            if not pdf.exists() or pdf.stat().st_size == 0:
                logger.debug(
                    "tikz->pdf produced no PDF (rc=%d): %s",
                    r1.returncode,
                    r1.stderr.decode(errors="replace")[:500],
                )
                return None
            svg = tmp / "fig.svg"
            if not _convert_pdf_to_svg(pdf, svg):
                logger.debug("pdf->svg conversion failed (no tool succeeded)")
                return None
            content = svg.read_text(encoding="utf-8")
    except Exception as exc:  # noqa: BLE001
        logger.debug("tikz_to_svg exception: %s", exc)
        return None

    # Strip XML prolog and DOCTYPE so the SVG can be safely inlined into
    # the HTML stream.
    content = re.sub(r"<\?xml[^?]*\?>", "", content)
    content = re.sub(r"<!DOCTYPE[^>]*>", "", content)
    content = content.strip()
    if svg_class:
        content = re.sub(
            r"<svg(\s[^>]*)?>",
            lambda m: f'<svg class="{svg_class}"{m.group(1) or ""}>',
            content, count=1,
        )
    return content
