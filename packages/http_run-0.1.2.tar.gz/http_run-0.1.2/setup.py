from setuptools import find_packages, setup

setup(
    name="http-run",
    version="0.1.2",
    packages=find_packages(),
    install_requires=["requests", "rich"],
    description="Быстрый инструмент для отправки HTTP запросов из файла",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.7",
    entry_points={"console_scripts": ["http-run=http_run.cli:main"]},
)
