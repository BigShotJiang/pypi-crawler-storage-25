import sys

import requests
from rich.console import Console
from rich.json import JSON
from rich.panel import Panel
from rich.text import Text
from rich.theme import Theme

theme = Theme(
    {
        "json.brace": "grey50",  # Скобки
        "json.key": "bold cyan",  # Ключи
        "json.str": "white",  # Строки
        "json.number": "yellow",  # Числа
        "json.bool": "magenta",  # True/False
        "json.null": "red",  # None
    }
)

console = Console(theme=theme)


def main():
    try:
        if len(sys.argv) > 1:
            file_path = sys.argv[1]

            with open(file_path, "r", encoding="utf-8") as f:
                file = f.read()

            method, url = file.split()
            method = method.lower()

            print(f"собираемся отправить {method} запрос на {url}")

            response = getattr(requests, method)(url)

            # # # #

            # Method, URL, Status and Time
            info_text = Text.assemble(
                (f" {response.request.method} ", "bold white on magenta"),
                (f" {response.url} ", "italic white"),
                " Status: ",
                (f"{response.status_code}", "bold"),
            )

            data = response.json()
            content = JSON.from_data(data, indent=4, sort_keys=True)

            panel = Panel(
                content,
                title=info_text,
                title_align="left",
                subtitle=f"[dim]Time: {response.elapsed.total_seconds():3f}s[/dim]",
                subtitle_align="right",
                border_style="bright_magenta",
                padding=(1, 2),
                expand=False,
            )

            console.print("\n", panel, "\n")

        else:
            print("Ошибка: передайте файл.")

    except:
        print("Ошибка: что-то пошло не так.")
