# http-run

Быстрый инструмент для отправки HTTP запросов из файла.

## Установка

```bash
pip install http-run
```
