#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# Plain text export for filecard.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC

from __future__ import annotations

import re

from .models import Card

_RULE = "-" * 56


def safe_filename(name: str) -> str:
    slug = name.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    return slug + ".txt"


def export_card(card: Card) -> str:
    lines: list[str] = []

    lines.append(_RULE)
    lines.append(card.name)
    lines.append(_RULE)

    def _row(label: str, value: str) -> None:
        lines.append(f"  {label:<16}{value}")

    if card.aliases:
        _row("aliases", ", ".join(card.aliases))
    if card.tags:
        _row("tags", ", ".join(card.tags))

    if card.facts:
        lines.append("")
        for key, val in card.facts.items():
            _row(key, val)

    if card.relationships:
        lines.append("")
        lines.append("  relationships")
        for role, name in card.relationships.items():
            lines.append(f"    {role:<14}{name}")

    if card.notes:
        lines.append("")
        lines.append("  notes")
        for note in card.notes:
            if (
                len(note) > 12
                and note[10:12] == "  "
                and note[:10].replace("-", "").isdigit()
            ):
                lines.append(f"    {note[:10]}  {note[12:]}")
            else:
                lines.append(f"    {note}")

    if card.events:
        lines.append("")
        lines.append("  events")
        for ev in card.events:
            lines.append(f"    {ev.timestamp[:10]}  [{ev.type}]  {ev.content}")

    lines.append("")
    lines.append(_RULE)
    lines.append(f"  created  {card.created_at[:10]}   updated  {card.updated_at[:10]}")
    lines.append(_RULE)

    return "\n".join(lines)
