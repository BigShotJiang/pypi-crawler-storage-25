#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# CLI entry point.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC

from __future__ import annotations

import sys
from pathlib import Path

import click

from .config import config_path, load_config, save_config
from .crypto import decrypt_vault, encrypt_vault, list_secret_keys
from .database import get_all, new_vault, open_vault, save_card
from .models import Card
from .prompt import prompt_event_type
from .search import find as fuzzy_find


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx: click.Context) -> None:
    if ctx.invoked_subcommand is None:
        _launch_tui()


@cli.command()
def init() -> None:
    if config_path().exists():
        raise click.ClickException(
            "Already initialised. Remove ~/.config/filecard/ to start over."
        )

    keys = list_secret_keys()
    if not keys:
        raise click.ClickException(
            "No GnuPG secret keys found. Create one with: gpg --gen-key"
        )

    click.echo("Available secret keys:")
    for i, key in enumerate(keys):
        uid = key["uids"][0] if key["uids"] else "(no uid)"
        short = key["fingerprint"][-16:]
        click.echo(f"  [{i}]  {uid}  ({short})")

    idx = click.prompt("Select key index", type=int, default=0)
    if not (0 <= idx < len(keys)):
        raise click.ClickException("Index out of range.")
    fingerprint = keys[idx]["fingerprint"]

    vault_dir = Path("~/.local/share/filecard").expanduser()
    vault_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    vault_path = vault_dir / "vault.gpg"

    try:
        encrypt_vault(new_vault(), vault_path, fingerprint)
    except RuntimeError as e:
        raise click.ClickException(str(e))

    save_config({"gpg_fingerprint": fingerprint, "vault_path": str(vault_path)})
    click.echo(f"Vault:  {vault_path}")
    click.echo(f"Config: {config_path()}")


@cli.command()
@click.argument("query")
@click.option("-m", "--message", required=True, help="Event content.")
@click.option(
    "-t",
    "--type",
    "event_type",
    default=None,
    help="Event type (meeting, call, …). Omit for menu.",
)
def log(query: str, message: str, event_type: str | None) -> None:
    if event_type is None:
        event_type = prompt_event_type()
    with open_vault(write=True) as vault:
        cards = get_all(vault)
        card = _resolve_one(cards, query)
        ev = card.log_event(content=message, type=event_type)
        save_card(vault, card)
    click.echo(f"Logged [{ev.type}] for {card.name} ({ev.timestamp[:10]}).")



@cli.command()
@click.confirmation_option(
    prompt="PERMANENTLY DESTROY the vault and config? This cannot be undone."
)
def nuke() -> None:
    import os

    try:
        cfg = load_config()
    except FileNotFoundError:
        raise click.ClickException("No config found — nothing to nuke.")

    vault_path = Path(cfg["vault_path"]).expanduser()
    if vault_path.exists():
        size = max(vault_path.stat().st_size, 4096)
        for _ in range(3):
            vault_path.write_bytes(os.urandom(size))
        vault_path.unlink()
        click.echo(f"Vault destroyed: {vault_path}")
    else:
        click.echo("Vault file not found (already gone).")

    cfg_path = config_path()
    if cfg_path.exists():
        cfg_path.unlink()
        click.echo(f"Config removed: {cfg_path}")


@cli.command()
@click.argument("query")
@click.option(
    "-o",
    "--out",
    default=None,
    help="Output file path. Default: <name>.txt in current directory.",
)
def export(query: str, out: str | None) -> None:
    from .export import export_card, safe_filename

    with open_vault() as vault:
        cards = get_all(vault)
        card = _resolve_one(cards, query)

    text = export_card(card)

    if out:
        from pathlib import Path as _Path

        _Path(out).write_text(text, encoding="utf-8")
        click.echo(f"Exported → {out}")
    else:
        click.echo(text)


def _launch_tui() -> None:
    from .tui.screen import launch_tui

    try:
        cfg = load_config()
    except FileNotFoundError:
        raise click.ClickException("No config found. Run `filecard init` first.")

    vault_path = Path(cfg["vault_path"]).expanduser()
    if not vault_path.exists():
        raise click.ClickException("Vault file not found. Run `filecard init` first.")

    try:
        vault = decrypt_vault(vault_path)
    except RuntimeError as e:
        raise click.ClickException(str(e))

    launch_tui(vault, cfg)


def _resolve_one(cards: list[Card], query: str) -> Card:
    exact = [c for c in cards if c.name.lower() == query.lower()]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1:
        _print_candidates(exact)
        raise click.Abort()

    results = fuzzy_find(cards, query)
    if not results:
        raise click.ClickException(f"No card found for '{query}'.")
    if len(results) == 1:
        return results[0][0]

    top_card, top_score = results[0]
    if top_score >= 90:
        return top_card

    _print_candidates([c for c, _ in results[:6]])
    raise click.Abort()


def _print_candidates(cards: list[Card]) -> None:
    click.echo("Ambiguous query. Did you mean:")
    for c in cards:
        click.echo(f"  {c.name}")
