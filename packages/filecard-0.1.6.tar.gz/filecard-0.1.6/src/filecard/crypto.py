#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# GnuPG wrapper for filecard.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC

from __future__ import annotations

import json
from pathlib import Path

import gnupg

_gpg: gnupg.GPG | None = None


def _get_gpg() -> gnupg.GPG:
    global _gpg
    if _gpg is None:
        _gpg = gnupg.GPG()
    return _gpg


def list_secret_keys() -> list[dict]:
    return _get_gpg().list_keys(True)


def decrypt_vault(path: Path) -> dict:
    gpg = _get_gpg()
    with open(path, "rb") as f:
        result = gpg.decrypt_file(f)
    if not result.ok:
        raise RuntimeError(f"Decryption failed: {result.status}")
    return json.loads(result.data.decode("utf-8"))


def encrypt_vault(data: dict, path: Path, fingerprint: str) -> None:
    gpg = _get_gpg()
    plaintext = json.dumps(data, ensure_ascii=False, indent=2)
    result = gpg.encrypt(
        plaintext,
        recipients=[fingerprint],
        armor=False,
        always_trust=True,
    )
    if not result.ok:
        raise RuntimeError(f"Encryption failed: {result.status}")
    tmp = path.with_suffix(".tmp")
    try:
        tmp.write_bytes(result.data)
        tmp.rename(path)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
