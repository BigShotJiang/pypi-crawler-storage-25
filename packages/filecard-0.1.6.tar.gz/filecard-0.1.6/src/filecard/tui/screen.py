#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# TUI infrastructure: colors, line editor primitive, session launcher.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC

from __future__ import annotations

import curses
import curses.ascii
from pathlib import Path
from typing import Optional

from ..backup import make_backup
from ..crypto import encrypt_vault
from ..database import get_all, save_card

PAIR_HEADER = 1
PAIR_COLHDR = 2
PAIR_STATUS = 3
PAIR_ACCENT = 4
PAIR_DIM = 5
PAIR_ACTIVE = 6


def init_colors() -> None:
    curses.start_color()
    curses.use_default_colors()

    orange = 208 if curses.COLORS >= 256 else curses.COLOR_YELLOW

    curses.init_pair(PAIR_HEADER, orange, curses.COLOR_BLACK)
    curses.init_pair(PAIR_COLHDR, -1, -1)
    curses.init_pair(PAIR_STATUS, curses.COLOR_WHITE, curses.COLOR_BLACK)
    curses.init_pair(PAIR_ACCENT, orange, -1)
    curses.init_pair(PAIR_DIM, -1, -1)
    curses.init_pair(PAIR_ACTIVE, orange, curses.COLOR_BLACK)


def line_edit(
    win,
    y: int,
    x: int,
    width: int,
    initial: str = "",
    attr: int | None = None,
) -> Optional[str]:
    if attr is None:
        attr = curses.A_REVERSE
    buf: list[str] = list(initial)
    pos: int = len(buf)
    offset: int = 0

    curses.curs_set(1)
    win.keypad(True)

    while True:
        if pos - offset >= width:
            offset = pos - width + 1
        if pos < offset:
            offset = pos

        visible = "".join(buf[offset : offset + width]).ljust(width)
        try:
            win.addstr(y, x, visible, attr)
            win.move(y, x + (pos - offset))
        except curses.error:
            pass
        win.refresh()

        key = win.getch()

        if key in (ord("\n"), ord("\r"), curses.KEY_ENTER):
            curses.curs_set(0)
            return "".join(buf)

        elif key == curses.ascii.ESC:
            win.nodelay(True)
            nk = win.getch()
            win.nodelay(False)
            if nk == -1:
                curses.curs_set(0)
                return None

        elif key == curses.KEY_RESIZE:
            curses.curs_set(0)
            return None

        elif key == curses.KEY_LEFT and pos > 0:
            pos -= 1
        elif key == curses.KEY_RIGHT and pos < len(buf):
            pos += 1
        elif key in (curses.KEY_HOME, curses.ascii.SOH):
            pos = 0
        elif key in (curses.KEY_END, curses.ascii.ENQ):
            pos = len(buf)
        elif key in (curses.KEY_BACKSPACE, curses.ascii.BS, 127):
            if pos > 0:
                buf.pop(pos - 1)
                pos -= 1
        elif key == curses.KEY_DC:
            if pos < len(buf):
                buf.pop(pos)
        elif key == curses.ascii.VT:
            buf = buf[:pos]
        elif key == curses.ascii.NAK:
            buf = []
            pos = 0
        elif 32 <= key <= 126:
            buf.insert(pos, chr(key))
            pos += 1


def launch_tui(vault: dict, cfg: dict) -> None:
    vault_path = Path(cfg["vault_path"]).expanduser()
    fingerprint = cfg["gpg_fingerprint"]

    try:
        curses.wrapper(_tui_main, vault, vault_path, fingerprint)
    finally:
        try:
            encrypt_vault(vault, vault_path, fingerprint)
            make_backup(vault_path)
        except Exception as exc:
            print(f"Warning: could not save vault: {exc}")


def _tui_main(stdscr, vault: dict, vault_path: Path, fingerprint: str) -> None:
    from .edit_view import EditScreen
    from .list_view import ListScreen

    curses.curs_set(0)
    curses.set_escdelay(25)
    stdscr.keypad(True)
    init_colors()

    list_screen = ListScreen(stdscr, vault, vault_path)
    edit_screen: Optional[EditScreen] = None
    state = "list"

    while True:
        if state == "list":
            action = list_screen.run()

            if action[0] == "quit":
                break

            elif action[0] == "edit":
                card = action[1]
                edit_screen = EditScreen(stdscr, vault, card)
                state = "edit"

            elif action[0] == "new":
                card = action[1]
                edit_screen = EditScreen(stdscr, vault, card)
                state = "edit"

        elif state == "edit":
            edit_screen.run()
            list_screen.refresh()
            state = "list"
