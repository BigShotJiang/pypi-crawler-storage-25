#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# Interactive live fuzzy picker for filecard TUI.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC

from __future__ import annotations

import curses
import curses.ascii
from typing import Optional

from rapidfuzz import fuzz
from rapidfuzz import process as fz_process

from .screen import PAIR_ACCENT, PAIR_COLHDR, PAIR_STATUS

_HINT = " Enter:select  j/k:move  Esc:cancel"
_HINT_CUSTOM = " Enter:select  j/k:move  Esc:cancel  (last row = type your own)"


def pick(
    stdscr,
    title: str,
    items: list[str],
    allow_custom: bool = False,
) -> Optional[str]:
    query = ""
    cursor = 0
    offset = 0

    while True:
        h, w = stdscr.getmaxyx()
        filtered = _filter(items, query)

        custom_row: Optional[str] = None
        if allow_custom and query.strip():
            custom_row = query.strip()
            display = filtered + [f"use: {custom_row}"]
        else:
            display = filtered

        n = len(display)
        cursor = max(0, min(cursor, n - 1))

        list_rows = max(1, h - 5)
        if cursor < offset:
            offset = cursor
        elif cursor >= offset + list_rows:
            offset = cursor - list_rows + 1

        stdscr.erase()
        _draw_title(stdscr, title, w)
        _draw_div(stdscr, 1, w)
        _draw_query(stdscr, query, w)
        _draw_div(stdscr, 3, w)
        _draw_items(stdscr, display, cursor, offset, list_rows, w, custom_row)
        _draw_hint(stdscr, h, w, allow_custom and bool(query.strip()))
        stdscr.refresh()

        key = stdscr.getch()

        if key == curses.KEY_RESIZE:
            curses.resizeterm(*stdscr.getmaxyx())
            continue

        elif key == curses.ascii.ESC:
            stdscr.nodelay(True)
            nk = stdscr.getch()
            stdscr.nodelay(False)
            if nk == -1:
                return None

        elif key in (ord("\n"), curses.KEY_ENTER):
            if not display:
                continue
            selected = display[cursor]
            if custom_row and selected == f"use: {custom_row}":
                return custom_row
            return selected

        elif key in (ord("j"), curses.KEY_DOWN):
            cursor = min(cursor + 1, max(0, n - 1))

        elif key in (ord("k"), curses.KEY_UP):
            cursor = max(cursor - 1, 0)

        elif key in (curses.KEY_BACKSPACE, curses.ascii.BS, 127):
            query = query[:-1]
            cursor = 0
            offset = 0

        elif 32 <= key <= 126:
            query += chr(key)
            cursor = 0
            offset = 0


def _filter(items: list[str], query: str) -> list[str]:
    if not query:
        return list(items)
    raw = fz_process.extract(
        query,
        items,
        scorer=fuzz.WRatio,
        limit=len(items),
        score_cutoff=40,
    )
    return [item for item, _score, _idx in sorted(raw, key=lambda x: -x[1])]



def _draw_title(stdscr, title: str, w: int) -> None:
    try:
        stdscr.addstr(
            0,
            0,
            f" {title}"[:w].ljust(w),
            curses.color_pair(PAIR_COLHDR) | curses.A_BOLD,
        )
    except curses.error:
        pass


def _draw_div(stdscr, y: int, w: int) -> None:
    try:
        stdscr.addstr(y, 0, "-" * w, curses.A_NORMAL)
    except curses.error:
        pass


def _draw_query(stdscr, query: str, w: int) -> None:
    prompt = "> "
    line = (prompt + query + "_")[:w]
    try:
        stdscr.addstr(
            2, 0, line.ljust(w), curses.color_pair(PAIR_ACCENT) | curses.A_BOLD
        )
    except curses.error:
        pass


def _draw_items(
    stdscr,
    display: list[str],
    cursor: int,
    offset: int,
    list_rows: int,
    w: int,
    custom_row: Optional[str],
) -> None:
    for i in range(list_rows):
        y = i + 4
        idx = offset + i
        if idx >= len(display):
            break
        item = display[idx]
        sel = idx == cursor
        if custom_row and item == f"use: {custom_row}":
            attr = curses.color_pair(PAIR_ACCENT)
            if sel:
                attr |= curses.A_REVERSE
        else:
            attr = curses.A_REVERSE if sel else curses.A_NORMAL
        try:
            stdscr.addstr(y, 0, f"  {item}"[:w].ljust(w), attr)
        except curses.error:
            pass

    if not display:
        try:
            stdscr.addstr(4, 0, "  (no matches)", curses.A_NORMAL)
        except curses.error:
            pass


def _draw_hint(stdscr, h: int, w: int, has_custom: bool) -> None:
    hint = _HINT_CUSTOM if has_custom else _HINT
    try:
        stdscr.addstr(h - 1, 0, hint[:w].ljust(w), curses.color_pair(PAIR_STATUS))
    except curses.error:
        pass
