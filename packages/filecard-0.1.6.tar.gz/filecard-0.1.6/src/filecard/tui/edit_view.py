#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# Edit view — tabbed card editor.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC


from __future__ import annotations

import curses
import curses.ascii
from dataclasses import dataclass

from ..database import get_all, save_card
from ..export import export_card, safe_filename
from ..models import Card, Event
from ..prompt import EVENT_TYPES, REL_ROLES, STANDARD_FACTS
from .screen import (
    PAIR_ACCENT,
    PAIR_ACTIVE,
    PAIR_COLHDR,
    PAIR_DIM,
    PAIR_STATUS,
    line_edit,
)

_TABS = ["Identity", "Facts", "Relations", "Events", "Notes"]
_HINT = " 1-5:tab  j/k:move  Enter:edit  a:add  d:del  x:export  Esc:back"


@dataclass
class Row:
    label: str
    value: str
    editable: bool
    action: bool
    key: str = ""


class EditScreen:
    def __init__(self, stdscr, vault: dict, card: Card) -> None:
        self.stdscr = stdscr
        self.vault = vault
        self.card = card
        self.tab = 0
        self.cursor = 0
        self.offset = 0

    def run(self) -> None:
        while True:
            self._draw()
            key = self.stdscr.getch()

            if key == curses.KEY_RESIZE:
                curses.resizeterm(*self.stdscr.getmaxyx())
                continue

            if key == curses.ascii.ESC:
                win = self.stdscr
                win.nodelay(True)
                nk = win.getch()
                win.nodelay(False)
                if nk == -1:
                    return

            self._handle(key)


    def _handle(self, key: int) -> None:
        for i, ch in enumerate("12345"):
            if key == ord(ch):
                self.tab = i
                self.cursor = 0
                self.offset = 0
                return

        rows = self._rows()
        n = len(rows)

        if key in (ord("j"), curses.KEY_DOWN):
            self.cursor = min(self.cursor + 1, max(0, n - 1))
            self._scroll()

        elif key in (ord("k"), curses.KEY_UP):
            self.cursor = max(self.cursor - 1, 0)
            self._scroll()

        elif key in (ord("\n"), curses.KEY_ENTER) and rows:
            row = rows[self.cursor]
            if row.editable:
                self._edit_row(row)
            elif row.action:
                self._do_action(row)

        elif key == ord("a"):
            self._do_add()

        elif key == ord("d"):
            self._do_delete()

        elif key == ord("x"):
            self._do_export()


    def _rows(self) -> list[Row]:
        if self.tab == 0:
            return self._rows_identity()
        if self.tab == 1:
            return self._rows_facts()
        if self.tab == 2:
            return self._rows_relations()
        if self.tab == 3:
            return self._rows_events()
        return self._rows_notes()

    def _rows_identity(self) -> list[Row]:
        return [
            Row("name", self.card.name, True, False),
            Row("aliases", ", ".join(self.card.aliases), True, False),
            Row("tags", ", ".join(self.card.tags), True, False),
        ]

    def _rows_facts(self) -> list[Row]:
        rows: list[Row] = []
        for k in STANDARD_FACTS:
            rows.append(Row(k, self.card.facts.get(k, ""), True, False, key=k))
        for k, v in self.card.facts.items():
            if k not in STANDARD_FACTS:
                rows.append(Row(k, v, True, False, key=k))
        rows.append(Row("+ add custom fact", "", False, True))
        return rows

    def _rows_relations(self) -> list[Row]:
        rows: list[Row] = []
        for role, name in self.card.relationships.items():
            rows.append(Row(role, name, True, False, key=role))
        rows.append(Row("+ add relation", "", False, True))
        return rows

    def _rows_events(self) -> list[Row]:
        rows: list[Row] = []
        for ev in reversed(self.card.events):
            label = f"{ev.timestamp[:10]}  [{ev.type}]"
            rows.append(Row(label, ev.content, True, False, key=ev.id))
        rows.append(Row("+ log event", "", False, True))
        return rows

    def _rows_notes(self) -> list[Row]:
        rows: list[Row] = []
        for note in self.card.notes:
            if (
                len(note) > 12
                and note[10:12] == "  "
                and note[:10].replace("-", "").isdigit()
            ):
                label = note[:10]
                text = note[12:]
                key = note[:10]
            else:
                label = "note"
                text = note
                key = ""
            rows.append(Row(label, text, True, False, key=key))
        rows.append(Row("+ add note", "", False, True))
        return rows


    def _draw(self) -> None:
        h, w = self.stdscr.getmaxyx()
        self.stdscr.erase()

        if h < 6 or w < 20:
            try:
                self.stdscr.addstr(0, 0, "Terminal too small.")
            except curses.error:
                pass
            self.stdscr.refresh()
            return

        self._draw_tabs(w)
        self._draw_divider(1, w)
        self._draw_rows(h, w)
        self._draw_divider(h - 2, w)
        self._draw_status(h, w)
        self.stdscr.refresh()

    def _draw_tabs(self, w: int) -> None:
        x = 1
        for i, name in enumerate(_TABS):
            label = f" [{i+1}:{name}] "
            if i == self.tab:
                attr = curses.color_pair(PAIR_ACCENT) | curses.A_BOLD
            else:
                attr = curses.A_NORMAL
            try:
                self.stdscr.addstr(0, x, label, attr)
            except curses.error:
                pass
            x += len(label) + 1

    def _draw_divider(self, y: int, w: int) -> None:
        try:
            self.stdscr.addstr(y, 0, "-" * w, curses.A_NORMAL)
        except curses.error:
            pass

    def _draw_rows(self, h: int, w: int) -> None:
        rows = self._rows()
        list_rows = h - 4
        lw = max(w // 3, 16)

        for i in range(list_rows):
            y = i + 2
            idx = self.offset + i
            if idx >= len(rows):
                break

            row = rows[idx]
            sel = idx == self.cursor
            self._draw_row(y, w, lw, row, sel)

    def _draw_row(self, y: int, w: int, lw: int, row: Row, selected: bool) -> None:
        if row.action:
            label = f"  {row.label}"
            attr = curses.color_pair(PAIR_COLHDR) | curses.A_BOLD
            if selected:
                attr |= curses.A_REVERSE
            try:
                self.stdscr.addstr(y, 0, label[:w].ljust(w), attr)
            except curses.error:
                pass
            return

        label_str = f"{row.label:>{lw - 3}} : "
        value_str = row.value[: (w - lw - 1)]

        label_attr = curses.color_pair(PAIR_COLHDR) | curses.A_BOLD
        value_attr = curses.A_NORMAL
        if selected:
            label_attr |= curses.A_REVERSE
            value_attr |= curses.A_REVERSE

        try:
            self.stdscr.addstr(y, 0, label_str[:lw], label_attr)
            self.stdscr.addstr(y, lw, value_str.ljust(w - lw), value_attr)
        except curses.error:
            pass

    def _draw_status(self, h: int, w: int) -> None:
        try:
            self.stdscr.addstr(
                h - 1,
                0,
                _HINT[:w].ljust(w),
                curses.color_pair(PAIR_STATUS),
            )
        except curses.error:
            pass


    def _edit_row(self, row: Row) -> None:
        h, w = self.stdscr.getmaxyx()
        lw = max(w // 3, 16)
        y = 2 + (self.cursor - self.offset)
        y = max(2, min(y, h - 3))
        edit_x = lw
        edit_w = max(w - lw - 1, 4)

        result = line_edit(
            self.stdscr,
            y,
            edit_x,
            edit_w,
            initial=row.value,
            attr=curses.color_pair(PAIR_ACTIVE) | curses.A_BOLD,
        )
        if result is None:
            return

        self._apply_edit(row, result)
        save_card(self.vault, self.card)

    def _apply_edit(self, row: Row, value: str) -> None:
        if self.tab == 0:  # Identity
            if row.label == "name":
                self.card.name = value
            elif row.label == "aliases":
                self.card.aliases = [a.strip() for a in value.split(",") if a.strip()]
            elif row.label == "tags":
                self.card.tags = [t.strip() for t in value.split(",") if t.strip()]

        elif self.tab == 1:
            if value:
                self.card.facts[row.key] = value
            elif row.key in self.card.facts:
                del self.card.facts[row.key]

        elif self.tab == 2:
            old_role = row.key
            if value:
                self.card.relationships[old_role] = value
            else:
                del self.card.relationships[old_role]

        elif self.tab == 3:
            for ev in self.card.events:
                if ev.id == row.key:
                    ev.content = value
                    break

        elif self.tab == 4:
            idx = self.cursor
            if idx < len(self.card.notes):
                if row.key:
                    self.card.notes[idx] = f"{row.key}  {value}"
                else:
                    self.card.notes[idx] = value

        self.card.touch()


    def _do_action(self, row: Row) -> None:
        if row.label == "+ add custom fact":
            self._add_custom_fact()
        elif row.label == "+ add relation":
            self._add_relation()
        elif row.label == "+ log event":
            self._add_event()
        elif row.label == "+ add note":
            self._add_note()

    def _do_add(self) -> None:
        if self.tab == 1:
            self._add_custom_fact()
        elif self.tab == 2:
            self._add_relation()
        elif self.tab == 3:
            self._add_event()
        elif self.tab == 4:
            self._add_note()

    def _do_delete(self) -> None:
        rows = self._rows()
        if not rows or self.cursor >= len(rows):
            return
        row = rows[self.cursor]
        if row.action:
            return

        if self.tab == 1 and row.key:
            if row.key not in STANDARD_FACTS:
                self.card.facts.pop(row.key, None)
                self.card.touch()
                save_card(self.vault, self.card)
                self.cursor = max(0, self.cursor - 1)

        elif self.tab == 2 and row.key:
            self.card.relationships.pop(row.key, None)
            self.card.touch()
            save_card(self.vault, self.card)
            self.cursor = max(0, self.cursor - 1)

        elif self.tab == 3 and row.key:
            self.card.events = [e for e in self.card.events if e.id != row.key]
            self.card.touch()
            save_card(self.vault, self.card)
            self.cursor = max(0, self.cursor - 1)

        elif self.tab == 4:
            note_idx = self.cursor
            if note_idx < len(self.card.notes):
                self.card.notes.pop(note_idx)
                self.card.touch()
                save_card(self.vault, self.card)
                self.cursor = max(0, self.cursor - 1)


    def _add_custom_fact(self) -> None:
        h, w = self.stdscr.getmaxyx()
        # Key.
        self._status_prompt("Custom fact key: ", h, w)
        key = line_edit(self.stdscr, h - 1, 18, w - 19)
        if not key:
            return
        key = key.strip()
        # Value.
        self._status_prompt(f"{key}: ", h, w)
        val = line_edit(self.stdscr, h - 1, len(key) + 2, w - len(key) - 3)
        if val:
            self.card.facts[key] = val
            self.card.touch()
            save_card(self.vault, self.card)

    def _add_relation(self) -> None:
        from .picker import pick

        role = pick(self.stdscr, "Relationship role", REL_ROLES, allow_custom=True)
        if not role:
            return

        card_names = sorted(c.name for c in get_all(self.vault) if c.id != self.card.id)
        h, w = self.stdscr.getmaxyx()
        if card_names:
            name = pick(
                self.stdscr,
                f"{role} → select or type name",
                card_names,
                allow_custom=True,
            )
        else:
            self._status_prompt(f"{role} → name: ", h, w)
            px = len(role) + 9
            name = line_edit(self.stdscr, h - 1, px, w - px - 1)
        if name and name.strip():
            self.card.relationships[role] = name.strip()
            self.card.touch()
            save_card(self.vault, self.card)

    def _add_event(self) -> None:
        from .picker import pick

        ev_type = pick(self.stdscr, "Event type", EVENT_TYPES, allow_custom=True)
        if not ev_type:
            return

        h, w = self.stdscr.getmaxyx()
        self._status_prompt(f"[{ev_type}] note: ", h, w)
        px = len(ev_type) + 10
        content = line_edit(self.stdscr, h - 1, px, w - px - 1)
        if content and content.strip():
            self.card.log_event(content=content.strip(), type=ev_type)
            save_card(self.vault, self.card)

    def _add_note(self) -> None:
        from datetime import date as _date

        h, w = self.stdscr.getmaxyx()
        self._status_prompt("Note: ", h, w)
        text = line_edit(self.stdscr, h - 1, 7, w - 8)
        if text and text.strip():
            dated = f"{_date.today().isoformat()}  {text.strip()}"
            self.card.notes.append(dated)
            self.card.touch()
            save_card(self.vault, self.card)


    def _do_export(self) -> None:
        from pathlib import Path

        h, w = self.stdscr.getmaxyx()
        filename = safe_filename(self.card.name)
        text = export_card(self.card)
        try:
            Path(filename).write_text(text, encoding="utf-8")
            self._status_prompt(f" Exported → {filename} ", h, w)
            self.stdscr.refresh()
            curses.napms(1400)
        except OSError as e:
            self._status_prompt(f" Export failed: {e} ", h, w)
            self.stdscr.refresh()
            curses.napms(1400)


    def _status_prompt(self, prompt: str, h: int, w: int) -> None:
        try:
            self.stdscr.addstr(
                h - 1,
                0,
                prompt[:w].ljust(w),
                curses.color_pair(PAIR_ACCENT) | curses.A_BOLD,
            )
        except curses.error:
            pass

    def _scroll(self) -> None:
        h, _ = self.stdscr.getmaxyx()
        list_rows = h - 4
        if self.cursor < self.offset:
            self.offset = self.cursor
        elif self.cursor >= self.offset + list_rows:
            self.offset = self.cursor - list_rows + 1
