#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# List view — the main screen.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC


from __future__ import annotations

import curses
import curses.ascii
from pathlib import Path
from typing import Optional

from ..database import delete_card, get_all, save_card
from ..export import export_card, safe_filename
from ..models import Card
from ..search import find as fuzzy_find
from .screen import (
    PAIR_ACCENT,
    PAIR_COLHDR,
    PAIR_DIM,
    PAIR_HEADER,
    PAIR_STATUS,
    line_edit,
)

_VERSION = "0.1.6"
_HINT_NORMAL = (
    " n:new  Enter:edit  x:export  d:del  /:search  t:tag  g/G:top/bot  q:quit"
)
_HINT_SEARCH = " type to filter   Esc:clear   Enter:edit   j/k:move"


class ListScreen:
    def __init__(self, stdscr, vault: dict, vault_path: Path) -> None:
        self.stdscr = stdscr
        self.vault = vault
        self.vault_path = vault_path
        self.cursor = 0
        self.offset = 0
        self.query = ""
        self.tag_filter = ""
        self._search_mode = False
        self.cards: list[Card] = []
        self.refresh()


    def refresh(self) -> None:
        all_cards = sorted(get_all(self.vault), key=lambda c: c.name.lower())

        if self.tag_filter:
            all_cards = [c for c in all_cards if self.tag_filter in c.tags]

        if self.query:
            self.cards = [c for c, _ in fuzzy_find(all_cards, self.query)]
        else:
            self.cards = all_cards

        self._clamp()

    def run(self) -> tuple:
        while True:
            self._draw()
            key = self.stdscr.getch()

            if key == curses.KEY_RESIZE:
                curses.resizeterm(*self.stdscr.getmaxyx())
                continue

            if self._search_mode:
                result = self._handle_search(key)
            else:
                result = self._handle(key)

            if result is not None:
                return result


    def _draw(self) -> None:
        h, w = self.stdscr.getmaxyx()
        self.stdscr.erase()

        if h < 6 or w < 20:
            try:
                self.stdscr.addstr(0, 0, "Terminal too small.")
            except curses.error:
                pass
            self.stdscr.refresh()
            return

        self._draw_header(w)
        self._draw_col_headers(w)
        self._draw_list(h, w)
        self._draw_status(h, w)
        self.stdscr.refresh()

    def _draw_header(self, w: int) -> None:
        title = f" filecard {_VERSION}"
        path_str = f" {self.vault_path} "
        gap = w - len(title) - len(path_str)
        bar = (title + (" " * max(gap, 1)) + path_str)[:w]
        try:
            self.stdscr.addstr(
                0,
                0,
                bar.ljust(w),
                curses.color_pair(PAIR_HEADER) | curses.A_BOLD,
            )
        except curses.error:
            pass

    def _draw_col_headers(self, w: int) -> None:
        nc, tc, ec = self._col_widths(w)
        hdr = f" {'Name':<{nc}} {'Tags':<{tc}} {'Organisation':<{ec}}"
        try:
            self.stdscr.addstr(
                1,
                0,
                hdr[:w].ljust(w),
                curses.color_pair(PAIR_COLHDR) | curses.A_BOLD,
            )
        except curses.error:
            pass

    def _draw_list(self, h: int, w: int) -> None:
        list_rows = h - 4
        nc, tc, ec = self._col_widths(w)

        for i in range(list_rows):
            y = i + 2
            idx = self.offset + i
            if idx >= len(self.cards):
                break

            card = self.cards[idx]
            name_str = card.name[:nc]
            tags_str = ", ".join(card.tags)[:tc]
            org_str = card.facts.get("organisation", "")[:ec]
            row = f" {name_str:<{nc}} {tags_str:<{tc}} {org_str:<{ec}}"

            attr = curses.A_REVERSE if idx == self.cursor else curses.A_NORMAL
            try:
                self.stdscr.addstr(y, 0, row[:w].ljust(w), attr)
            except curses.error:
                pass

        if not self.cards:
            msg = "  (no cards — press n to create one)"
            try:
                self.stdscr.addstr(
                    2, 0, msg, curses.color_pair(PAIR_DIM) | curses.A_BOLD
                )
            except curses.error:
                pass

    def _draw_status(self, h: int, w: int) -> None:
        try:
            self.stdscr.addstr(h - 2, 0, "-" * w, curses.A_NORMAL)
        except curses.error:
            pass

        if self._search_mode:
            indicators = []
            if self.tag_filter:
                indicators.append(f"#{self.tag_filter}")
            query_line = f" /{self.query}_"
            if indicators:
                query_line += "  " + "  ".join(indicators)
            try:
                self.stdscr.addstr(
                    h - 1,
                    0,
                    query_line[:w].ljust(w),
                    curses.color_pair(PAIR_ACCENT) | curses.A_BOLD,
                )
            except curses.error:
                pass
        else:
            hint = _HINT_NORMAL
            indicators = []
            if self.query:
                indicators.append(f"/{self.query}")
            if self.tag_filter:
                indicators.append(f"#{self.tag_filter}")
            if indicators:
                hint = "  [" + "  ".join(indicators) + "]" + hint
            try:
                self.stdscr.addstr(
                    h - 1,
                    0,
                    hint[:w].ljust(w),
                    curses.color_pair(PAIR_STATUS),
                )
            except curses.error:
                pass


    def _handle(self, key: int) -> Optional[tuple]:
        if key in (ord("q"), ord("Q")):
            return ("quit",)

        elif key in (ord("j"), curses.KEY_DOWN):
            self.cursor = min(self.cursor + 1, max(0, len(self.cards) - 1))
            self._scroll_to_cursor()

        elif key in (ord("k"), curses.KEY_UP):
            self.cursor = max(self.cursor - 1, 0)
            self._scroll_to_cursor()

        elif key == ord("g"):
            self.cursor = 0
            self.offset = 0

        elif key == ord("G"):
            self.cursor = max(0, len(self.cards) - 1)
            self._scroll_to_cursor()

        elif key in (ord("\n"), curses.KEY_ENTER) and self.cards:
            return ("edit", self.cards[self.cursor])

        elif key == ord("n"):
            result = self._do_new()
            if result:
                return result

        elif key == ord("d") and self.cards:
            self._do_delete()

        elif key == ord("x") and self.cards:
            self._do_export()

        elif key == ord("/"):
            self._search_mode = True

        elif key == ord("t"):
            self._do_tag_filter()

        elif key == curses.ascii.ESC:
            self.query = ""
            self.tag_filter = ""
            self.cursor = 0
            self.offset = 0
            self.refresh()

        return None


    def _handle_search(self, key: int) -> Optional[tuple]:
        if key == curses.ascii.ESC:
            self._search_mode = False

        elif key in (ord("\n"), curses.KEY_ENTER):
            self._search_mode = False
            if self.cards:
                return ("edit", self.cards[self.cursor])

        elif key in (ord("j"), curses.KEY_DOWN):
            self.cursor = min(self.cursor + 1, max(0, len(self.cards) - 1))
            self._scroll_to_cursor()

        elif key in (ord("k"), curses.KEY_UP):
            self.cursor = max(self.cursor - 1, 0)
            self._scroll_to_cursor()

        elif key in (curses.KEY_BACKSPACE, curses.ascii.BS, 127):
            self.query = self.query[:-1]
            self.cursor = 0
            self.offset = 0
            self.refresh()

        elif 32 <= key <= 126:
            self.query += chr(key)
            self.cursor = 0
            self.offset = 0
            self.refresh()

        return None


    def _do_new(self) -> Optional[tuple]:
        h, w = self.stdscr.getmaxyx()
        self._draw_prompt("New card name: ", h, w)
        name = line_edit(self.stdscr, h - 1, 16, w - 17)
        if not name or not name.strip():
            return None

        if any(c.name.lower() == name.lower() for c in get_all(self.vault)):
            self._flash(f" '{name}' already exists.", h, w)
            return None

        card = Card.new(name.strip())
        save_card(self.vault, card)
        self.refresh()
        for i, c in enumerate(self.cards):
            if c.id == card.id:
                self.cursor = i
                self._scroll_to_cursor()
                break
        return ("new", card)

    def _do_delete(self) -> None:
        h, w = self.stdscr.getmaxyx()
        card = self.cards[self.cursor]
        self._draw_prompt(f" Delete '{card.name}'? [y/N] ", h, w)
        self.stdscr.refresh()
        key = self.stdscr.getch()
        if key in (ord("y"), ord("Y")):
            delete_card(self.vault, card.id)
            self.refresh()
            self._clamp()

    def _do_export(self) -> None:
        h, w = self.stdscr.getmaxyx()
        card = self.cards[self.cursor]
        filename = safe_filename(card.name)
        text = export_card(card)
        try:
            Path(filename).write_text(text, encoding="utf-8")
            self._flash(f" Exported → {filename}", h, w)
        except OSError as e:
            self._flash(f" Export failed: {e}", h, w)

    def _do_tag_filter(self) -> None:
        from .picker import pick

        all_cards = get_all(self.vault)
        tags: list[str] = sorted({tag for card in all_cards for tag in card.tags})
        if not tags:
            h, w = self.stdscr.getmaxyx()
            self._flash(" No tags in vault.", h, w)
            return

        chosen = pick(self.stdscr, "Filter by tag", tags, allow_custom=False)
        if chosen is not None:
            self.tag_filter = chosen
        else:
            self.tag_filter = ""
        self.query = ""
        self.cursor = 0
        self.offset = 0
        self.refresh()


    def _col_widths(self, w: int) -> tuple[int, int, int]:
        usable = max(w - 3, 10)
        nc = int(usable * 0.40)
        tc = int(usable * 0.28)
        ec = usable - nc - tc
        return nc, tc, ec

    def _clamp(self) -> None:
        n = len(self.cards)
        self.cursor = min(self.cursor, max(0, n - 1))

    def _scroll_to_cursor(self) -> None:
        h, _ = self.stdscr.getmaxyx()
        list_rows = h - 4
        if self.cursor < self.offset:
            self.offset = self.cursor
        elif self.cursor >= self.offset + list_rows:
            self.offset = self.cursor - list_rows + 1

    def _draw_prompt(self, prompt: str, h: int, w: int) -> None:
        try:
            self.stdscr.addstr(
                h - 1,
                0,
                prompt.ljust(w),
                curses.color_pair(PAIR_ACCENT) | curses.A_BOLD,
            )
        except curses.error:
            pass

    def _flash(self, msg: str, h: int, w: int) -> None:
        try:
            self.stdscr.addstr(
                h - 1,
                0,
                msg[:w].ljust(w),
                curses.color_pair(PAIR_STATUS),
            )
        except curses.error:
            pass
        self.stdscr.refresh()
        curses.napms(1400)
