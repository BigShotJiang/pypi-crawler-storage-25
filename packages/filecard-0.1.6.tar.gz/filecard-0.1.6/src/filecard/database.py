#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# Vault operations (Create, Read, Update, Delete).
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC

from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Generator

import click

from .config import load_config
from .crypto import decrypt_vault, encrypt_vault
from .models import Card

VAULT_VERSION = 2


def new_vault() -> dict:
    return {"version": VAULT_VERSION, "cards": {}}


def get_all(vault: dict) -> list[Card]:
    return [Card.from_dict(d) for d in vault["cards"].values()]


def get_by_id(vault: dict, card_id: str) -> Card | None:
    d = vault["cards"].get(card_id)
    return Card.from_dict(d) if d is not None else None


def save_card(vault: dict, card: Card) -> None:
    vault["cards"][card.id] = card.to_dict()


def delete_card(vault: dict, card_id: str) -> bool:
    if card_id in vault["cards"]:
        del vault["cards"][card_id]
        return True
    return False


@contextmanager
def open_vault(write: bool = False) -> Generator[dict, None, None]:
    try:
        cfg = load_config()
    except FileNotFoundError as e:
        raise click.ClickException(str(e))

    vault_path = Path(cfg["vault_path"]).expanduser()
    if not vault_path.exists():
        raise click.ClickException("Vault file not found. Run `filecard init` first.")

    try:
        vault = decrypt_vault(vault_path)
    except RuntimeError as e:
        raise click.ClickException(str(e))

    yield vault

    if write:
        try:
            encrypt_vault(vault, vault_path, cfg["gpg_fingerprint"])
        except RuntimeError as e:
            raise click.ClickException(f"Failed to write vault: {e}")
