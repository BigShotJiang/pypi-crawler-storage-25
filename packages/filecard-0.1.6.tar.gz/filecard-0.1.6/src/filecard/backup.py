#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# Vault backup management.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC


from __future__ import annotations

import gzip
import shutil
from datetime import datetime
from pathlib import Path

MAX_BACKUPS = 10


def make_backup(vault_path: Path) -> None:
    if not vault_path.exists():
        return

    backup_dir = vault_path.parent / "backups"
    backup_dir.mkdir(exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = backup_dir / f"vault-{ts}.gpg.gz"

    with open(vault_path, "rb") as src:
        with gzip.open(dest, "wb") as dst:
            shutil.copyfileobj(src, dst)

    existing = sorted(backup_dir.glob("vault-*.gpg.gz"))
    for old in existing[:-MAX_BACKUPS]:
        old.unlink(missing_ok=True)
