#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# Config file.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC

from __future__ import annotations

import json
from pathlib import Path

_CONFIG_PATH = Path("~/.config/filecard/config.json")


def config_path() -> Path:
    return _CONFIG_PATH.expanduser()


def load_config() -> dict:
    p = config_path()
    if not p.exists():
        raise FileNotFoundError("No config found. Run `filecard init` first.")
    return json.loads(p.read_text())


def save_config(cfg: dict) -> None:
    p = config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, indent=2))
