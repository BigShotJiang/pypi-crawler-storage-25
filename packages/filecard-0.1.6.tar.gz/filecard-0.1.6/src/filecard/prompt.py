#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# Interactive prompt interface for filecard.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC

from __future__ import annotations

import sys

from .models import Card

_IS_TTY = sys.stdout.isatty()

_RESET = "\033[0m" if _IS_TTY else ""
_BOLD = "\033[1m" if _IS_TTY else ""
_DIM = "\033[2m" if _IS_TTY else ""
_CYAN = "\033[36m" if _IS_TTY else ""
_GREEN = "\033[32m" if _IS_TTY else ""
_YELLOW = "\033[33m" if _IS_TTY else ""
_RED = "\033[91m" if _IS_TTY else ""

_RULE = "─" * 56


def _b(s: str) -> str:
    return f"{_BOLD}{s}{_RESET}"


def _d(s: str) -> str:
    return f"{_DIM}{s}{_RESET}"


def _c(s: str) -> str:
    return f"{_CYAN}{s}{_RESET}"


def _y(s: str) -> str:
    return f"{_YELLOW}{s}{_RESET}"


def _r(s: str) -> str:
    return f"{_RED}{s}{_RESET}"


def _g(s: str) -> str:
    return f"{_GREEN}{s}{_RESET}"


def _print(s: str = "") -> None:
    print(s)


def _input(prompt: str = "") -> str:
    try:
        return input(prompt).strip()
    except EOFError:
        return ""


STANDARD_FACTS: list[str] = [
    "occupation",
    "organisation",
    "born",
    "languages",
    "location",
    "nationality",
]

EVENT_TYPES: list[str] = [
    "meeting",
    "call",
    "message",
    "observation",
    "reminder",
]

REL_ROLES: list[str] = [
    "spouse",
    "partner",
    "sibling",
    "parent",
    "child",
    "colleague",
    "aide",
    "boss",
    "employee",
    "friend",
    "contact",
]


def _menu(label: str, options: list[str], allow_custom: bool = True) -> str:
    _print(f"  {_c(label)}")
    for i, opt in enumerate(options, 1):
        _print(f"    {_y(str(i))}.  {opt}")
    if allow_custom:
        _print(f"    {_y(str(len(options) + 1))}.  other…  {_d('(type your own)')}")

    total = len(options) + (1 if allow_custom else 0)

    while True:
        raw = _input(f"  {_g('>')} ")
        if not raw.isdigit():
            _print(f"  {_r('Enter a number.')}")
            continue
        n = int(raw)
        if not (1 <= n <= total):
            _print(f"  {_r(f'Enter a number between 1 and {total}.')}")
            continue
        if allow_custom and n == total:
            custom = _input(f"  {_g('>')} ")
            if not custom:
                _print(f"  {_r('Cannot be empty.')}")
                continue
            return custom
        return options[n - 1]


def prompt_event_type() -> str:
    _print()
    result = _menu("event type", EVENT_TYPES, allow_custom=True)
    _print()
    return result


def prompt_rel_role() -> str:
    _print()
    result = _menu("relationship role", REL_ROLES, allow_custom=True)
    _print()
    return result


def _header(card: Card, is_new: bool) -> None:
    _print(_RULE)
    verb = "New card" if is_new else "Edit card"
    _print(f"  {_b(verb + ':')}  {_b(card.name)}")
    _print(_RULE)
    _print(_d("  Ctrl-C at any point: you will be asked whether to save."))
    if not is_new:
        _print(_d("  Blank input keeps the current value."))
        _print(_d("  To delete a fact use:  filecard edit --raw"))
    _print()


def _prompt_line(label: str, hint: str = "", current: str = "") -> str:
    hint_str = f"  {_d(hint)}" if hint else ""
    current_str = f"  {_y('[' + current + ']')}" if current else ""
    _print(f"  {_c(label)}{current_str}{hint_str}")
    return _input(f"  {_g('>')} ")


def _prompt_facts(existing: dict[str, str]) -> dict[str, str]:
    updated = dict(existing)

    _print(f"  {_c('facts')}  {_d('standard fields — blank to skip')}")
    _print()

    for key in STANDARD_FACTS:
        current = updated.get(key, "")
        current_str = f"  {_y('[' + current + ']')}" if current else ""
        _print(f"    {_c(key)}{current_str}")
        val = _input(f"    {_g('>')} ")
        if val:
            updated[key] = val

    _print()
    while True:
        add_more = _input(f"  {_g('>')} add a custom fact?  {_d('[y/N]')}  ").lower()
        if add_more not in ("y", "yes"):
            break
        key = _input(f"    {_g('key    >')} ")
        if not key:
            _print(f"    {_r('Key cannot be empty — skipping.')}")
            continue
        if key in STANDARD_FACTS:
            _print(f"    {_r(repr(key) + ' is a standard field — set it above.')}")
            continue
        val = _input(f"    {_g('value  >')} ")
        if val:
            updated[key] = val

    return updated


def _prompt_multiline(label: str, existing: list[str]) -> list[str]:
    if existing:
        _print(f"  {_c(label)}  {_d('existing — new lines appended, blank to finish')}")
        for i, item in enumerate(existing, 1):
            _print(f"    {_d(str(i) + '.')}  {item}")
    else:
        _print(f"  {_c(label)}  {_d('one per line, blank to finish')}")

    collected: list[str] = []
    while True:
        line = _input(f"  {_g('>')} ")
        if not line:
            break
        collected.append(line)
    return collected


def _ask_save_partial(card: Card) -> Card:
    _print()
    _print(f"  {_y('Interrupted.')}")
    try:
        answer = _input(
            f"  {_g('>')} save what you've entered so far?  {_d('[y/N]')}  "
        ).lower()
    except (EOFError, KeyboardInterrupt):
        answer = ""

    if answer in ("y", "yes"):
        card.touch()
        return card

    raise KeyboardInterrupt


def prompt_card(card: Card, *, is_new: bool = True) -> Card:
    _header(card, is_new)

    try:
        current_aliases = ", ".join(card.aliases) if card.aliases else ""
        raw = _prompt_line(
            "aliases", hint="comma-separated, blank to skip", current=current_aliases
        )
        if raw:
            card.aliases = [a.strip() for a in raw.split(",") if a.strip()]
        _print()

        current_tags = ", ".join(card.tags) if card.tags else ""
        raw = _prompt_line(
            "tags", hint="comma-separated, blank to skip", current=current_tags
        )
        if raw:
            card.tags = [t.strip() for t in raw.split(",") if t.strip()]
        _print()

        card.facts = _prompt_facts(card.facts)
        _print()

        new_notes = _prompt_multiline("notes", card.notes)
        card.notes.extend(new_notes)
        _print()

    except KeyboardInterrupt:
        return _ask_save_partial(card)

    _print(_RULE)
    card.touch()
    return card
