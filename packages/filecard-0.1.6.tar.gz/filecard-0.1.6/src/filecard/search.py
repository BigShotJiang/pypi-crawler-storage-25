#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# Fuzzy search.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC


from __future__ import annotations

from rapidfuzz import fuzz, process

from .models import Card

_DEFAULT_THRESHOLD = 60
_NUL = "\x00"


def find(
    cards: list[Card],
    query: str,
    threshold: int = _DEFAULT_THRESHOLD,
) -> list[tuple[Card, float]]:
    if not cards:
        return []

    choices: dict[str, str] = {}
    for c in cards:
        choices[c.id] = c.name
        for alias in c.aliases:
            choices[f"{c.id}{_NUL}{alias}"] = alias

    raw = process.extract(
        query,
        choices,
        scorer=fuzz.WRatio,
        limit=20,
        score_cutoff=threshold,
    )

    id_index: dict[str, Card] = {c.id: c for c in cards}
    seen: dict[str, tuple[Card, float]] = {}

    for _display, score, key in raw:
        cid = key.split(_NUL)[0]
        card = id_index.get(cid)
        if card and (cid not in seen or score > seen[cid][1]):
            seen[cid] = (card, score)

    return sorted(seen.values(), key=lambda x: x[1], reverse=True)
