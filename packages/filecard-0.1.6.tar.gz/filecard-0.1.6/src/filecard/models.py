#!/usr/bin/env python3
#
# filecard - GPG-encrypted personal dossier system for the command line.
# Core data model for filecard.
#
# Copyright (c) 2026 Sergiy Duras
# SPDX-License-Identifier: ISC

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_id() -> str:
    return str(uuid.uuid4())


@dataclass
class Event:
    id: str
    timestamp: str
    type: str
    content: str

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "type": self.type,
            "content": self.content,
        }

    @classmethod
    def new(cls, content: str, type: str = "note") -> "Event":
        return cls(id=_new_id(), timestamp=_utcnow(), type=type, content=content)

    @classmethod
    def from_dict(cls, d: dict) -> "Event":
        return cls(
            id=d["id"],
            timestamp=d["timestamp"],
            type=d.get("type", "note"),
            content=d["content"],
        )


@dataclass
class Card:
    id: str
    name: str
    aliases: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    facts: dict[str, str] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    relationships: dict[str, str] = field(default_factory=dict)
    events: list[Event] = field(default_factory=list)
    created_at: str = field(default_factory=_utcnow)
    updated_at: str = field(default_factory=_utcnow)

    @classmethod
    def new(cls, name: str) -> "Card":
        return cls(id=_new_id(), name=name)

    def touch(self) -> None:
        self.updated_at = _utcnow()

    def log_event(self, content: str, type: str = "note") -> Event:
        ev = Event.new(content=content, type=type)
        self.events.append(ev)
        self.touch()
        return ev

    def set_relationship(self, role: str, target: str) -> None:
        self.relationships[role.lower()] = target
        self.touch()

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "aliases": self.aliases,
            "tags": self.tags,
            "facts": self.facts,
            "notes": self.notes,
            "relationships": self.relationships,
            "events": [e.to_dict() for e in self.events],
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Card":
        return cls(
            id=d["id"],
            name=d["name"],
            aliases=d.get("aliases", []),
            tags=d.get("tags", []),
            facts=d.get("facts", {}),
            notes=d.get("notes", []),
            relationships=d.get("relationships", {}),
            events=[Event.from_dict(e) for e in d.get("events", [])],
            created_at=d["created_at"],
            updated_at=d["updated_at"],
        )
