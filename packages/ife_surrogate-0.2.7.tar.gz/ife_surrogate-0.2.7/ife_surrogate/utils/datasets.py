import numpy as np
from importlib import resources



def load_lc_filter_dataset():
    """
    Loads the internal LC filter dataset.
    """
    data_path = resources.files("ife_surrogate.data").joinpath("lc_filter_dataset.npz")
    
    with data_path.open("rb") as f:
        data = np.load(f)
        return dict(data)