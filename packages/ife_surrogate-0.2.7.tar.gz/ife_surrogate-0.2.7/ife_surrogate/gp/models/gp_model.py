# ------------------------------------------------------------------------------
# Project: IFE_Surrogate
# Authors: Tobias Leitgeb, Julian Tischler
# CD Lab 2025
#
# Base class for Gaussian Process Regressor Models
#
# ------------------------------------------------------------------------------
from ..kernels import Kernel

from jaxtyping import Array, Key
import typing
from abc import ABC, abstractmethod
import joblib
import numpy as np


TypeKernel = typing.TypeVar("Kernel", bound=Kernel)



class GPModel(ABC):
    r""" 
        Abstract base class of a GP, to be used as skeleton for actual GP implementations.
    """

    def __init__(self, kernel: TypeKernel, X: Array, Y: Array):
        self.kernel = kernel
        self.X = X
        self.Y = Y

    ## Must be implemented in actual model implementation, every model should have a predict method
    @abstractmethod
    def predict():
        return

    def get_attributes(self):
        return self.__dict__

    def save(self, filename="IfeSurrModel.pkl"):
        """
        Saves the model state.
        """
        state = {
            "kernel": self.kernel.to_json(),
            "X": np.array(self.X),
            "Y": np.array(self.Y),
            "params": self.kernel.get_params()
        }
        joblib.dump(state, filename)

    @staticmethod
    def load(model_class, kernel_class, filename):
        """
        Reconstructs the model from a saved state.
        """
        state = joblib.load(filename)
        dummy = [[] for p in state["params"]]
        instance = model_class(kernel=kernel_class(*dummy, priors=[]), X=state["X"], Y=state["Y"])
        instance.kernel.update_params(state["params"])
        return instance