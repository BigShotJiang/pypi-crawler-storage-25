# ------------------------------------------------------------------------------
# Project: IFE_Surrogate
# Authors: Tobias Leitgeb, Julian Tischler
# CD Lab 2025
# ------------------------------------------------------------------------------
from abc import ABC, abstractmethod
import dataclasses
import jax
from typing import Callable, Dict, Tuple, List, Set
from jaxtyping import Array, Key
from flax import struct
import numpy as np



@struct.dataclass
class Kernel(ABC):
    """
    Abstract base class for kernels in Gaussian Process (GP) regression.

    This class provides the core interface and utility functions for all kernel
    implementations, including methods to evaluate the kernel, access and
    update parameters, and sample new hyperparameters from prior distributions.

    Attributes:
        priors (Dict[str, Callable]): A dictionary mapping parameter names to 
            callable prior distributions used for sampling hyperparameters.
        param_bounds (Dict, optional): Dictionary specifying bounds for each 
            parameter. Defaults to an empty dictionary.
        exempt (Set[str]): Set of attribute names to exclude when retrieving 
            parameters (e.g., priors, param_bounds, exempt itself).

    Methods:
        evaluate(x1, x2):
            Abstract method. Computes the kernel function between two inputs.
        __call__(x1, x2):
            Calls `evaluate`, allowing the kernel object to be used as a function.
        get_priors():
            Returns the dictionary of priors for kernel hyperparameters.
        get_params():
            Returns a dictionary of the current kernel parameters, excluding
            those in `exempt`.
        sample_hyperparameters(key):
            Samples new parameter values from the prior distributions using
            a JAX random key.
        update_params(params):
            Updates kernel parameters in-place using the provided dictionary.
    """

    priors: Dict[str, Callable] = struct.field(pytree_node=False, kw_only=True)
    param_bounds: Dict = struct.field(pytree_node=False, default_factory=dict, kw_only=True)
    exempt: Set[str] = struct.field(
        pytree_node=False,
        default_factory=lambda: {'priors', 'param_bounds', 'exempt'},
        kw_only=True
    )
    
    @abstractmethod
    def evaluate(self, x1: Array, x2: Array) -> Array:
        """
        Evaluate the kernel function.

        Args:
            x1: First input data array.
            x2: Second input data array.

        Returns:
            Kernel evaluation between x1 and x2.
        """
        pass

    def __call__(self, x1: Array, x2: Array) -> Array:
        """
        Args:
            x1: First input data array.
            x2: Second input data array.

        Returns:
            Kernel evaluation between x1 and x2.
        """
        return self.evaluate(x1, x2)
    
    def get_priors(self):
        """
        Get the kernel parameters.

        Returns:
            A dictionary containing the kernel parameters.
        """
        return self.priors
    
    def get_params(self) -> Dict[str, Array]:
        return {
            f.name: getattr(self, f.name) 
            for f in dataclasses.fields(self) 
            if f.name not in self.exempt
        }
        

    def sample_hyperparameters(self, key: Key) -> Dict[str, Array]:
        assert isinstance(key, Array), "'key' must be a jax.random key"
        if not self.priors:
            jax.debug.print("No priors specified. Returning current parameters.")
            return self.get_params()

        param_keys = list(self.get_params().keys())

        subkeys = jax.random.split(key, len(param_keys))
        
        param_samples = {}
        for subkey, x in zip(subkeys, param_keys):
            if x in self.priors:
                param_samples[x] = self.priors[x].sample(subkey, getattr(self, x).shape)
            else:
                param_samples[x] = getattr(self, x)
        
        return param_samples


    def to_json(self):
        import json
        json.dump(self.to_dict())


    def to_dict(self) -> Dict:
        """Serializes the kernel to a JSON-compatible dictionary."""
        kernel_type = self.__class__.__name__

        params = self.get_params()
        serializable_params = {
            k: np.array(v).tolist() for k, v in params.items()
        }
        
        return {
            "type": kernel_type,
            "params": serializable_params
        }


    def update_params(self, params: Dict[str, Array]) -> "Kernel":
        return self.replace(**params)
    

    # @staticmethod
    # def from_dict(dict: Dict) -> "Kernel":
    #     KERNELS = {
    #         "SumKernel" : SumKerne
    #     }
    
