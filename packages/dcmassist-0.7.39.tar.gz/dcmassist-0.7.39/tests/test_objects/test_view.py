"""Tests for the View plugin."""

from __future__ import annotations

from unittest.mock import MagicMock

import jinja2
import pytest

from dcmassist.objects.view import ViewParseError, parse_view_ddl, plugin
from dcmassist.types import FQN


def test_discover_lists_schemas_then_iterates() -> None:
    cursor = MagicMock()
    sql_log: list[str] = []
    cursor.execute.side_effect = lambda sql: sql_log.append(sql)
    fetch_responses = iter(
        [
            [{"name": "PUBLIC", "database_name": "MYDB"}],
            [
                {"name": "V1", "schema_name": "PUBLIC", "database_name": "MYDB"},
                {"name": "V2", "schema_name": "PUBLIC", "database_name": "MYDB"},
            ],
        ]
    )
    cursor.fetchall.side_effect = lambda: next(fetch_responses)

    out = plugin.discover(cursor, "MYDB", None)
    assert sql_log == [
        "SHOW SCHEMAS IN DATABASE MYDB LIMIT 10000",
        "SHOW VIEWS IN SCHEMA MYDB.PUBLIC LIMIT 10000",
    ]
    assert [str(f) for f in out] == ["MYDB.PUBLIC.V1", "MYDB.PUBLIC.V2"]


def test_discover_filters_by_schema() -> None:
    cursor = MagicMock()
    sql_log: list[str] = []
    cursor.execute.side_effect = lambda sql: sql_log.append(sql)
    cursor.fetchall.return_value = [
        {"name": "V", "schema_name": "S", "database_name": "MYDB"}
    ]
    out = plugin.discover(cursor, "MYDB", ("S",))
    assert sql_log == ["SHOW VIEWS IN SCHEMA MYDB.S LIMIT 10000"]
    assert [str(f) for f in out] == ["MYDB.S.V"]


def test_get_ddl_calls_get_ddl_function() -> None:
    cursor = MagicMock()
    cursor.fetchone.return_value = ["CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS SELECT 1"]
    fqn = FQN("MYDB", "PUBLIC", "V")
    out = plugin.get_ddl(cursor, fqn)
    cursor.execute.assert_called_once_with(
        'SELECT GET_DDL(\'VIEW\', \'"MYDB"."PUBLIC"."V"\', TRUE)'
    )
    assert out.startswith("CREATE")


def test_to_define_and_invocation_macro_mode() -> None:
    out = plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS SELECT 1",
        comment="hi",
        use_macros=True,
        database="MYDB",
    )
    assert out.startswith("{{ define_view(")
    assert "raw=" not in out
    assert "database=database" in out
    assert "schema='PUBLIC'" in out
    assert "name='V'" in out
    # Body lives outside the macro call, wrapped in raw markers.
    assert "{% raw %}" in out
    assert "{% endraw %}" in out


def test_macro_round_trip_renders_full_ddl() -> None:
    """Render the macro+invocation through Jinja to confirm it produces valid
    DDL. Note: `{% raw %}` markers in the invocation are CONSUMED by this
    render pass — DCM runs the same single pass on the file we write, which
    is what the markers protect against. We check the rendered output below
    is the post-DCM-pass result."""
    out = plugin.to_define_and_invocation(
        "CREATE OR REPLACE SECURE VIEW MYDB.PUBLIC.V AS SELECT 1 AS X "
        "FROM MYDB.PUBLIC.T",
        comment="hi",
        use_macros=True,
        database="MYDB",
    )
    rendered = (
        jinja2.Environment()
        .from_string(plugin.macro_definition() + "\n" + out)
        .render(database="RUNTIME")
    )
    assert "DEFINE SECURE VIEW RUNTIME.PUBLIC.V" in rendered
    assert "COMMENT='hi'" in rendered
    assert "\nAS\n" in rendered
    assert "SELECT 1 AS X FROM RUNTIME.PUBLIC.T" in rendered
    assert "{{ database }}" not in rendered
    assert rendered.rstrip().endswith(";")


def test_body_with_jinja_braces_is_protected() -> None:
    """Literal `{{ x }}` in the body must survive DCM's render pass.

    The wrapped body in the invocation contains `{% raw %}{{ x }}{% endraw %}`;
    when DCM renders the file, the raw block keeps the `{{ x }}` literal
    intact. We exercise that single render pass here."""
    out = plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS SELECT '{{ x }}' AS LITERAL",
        comment=None,
        use_macros=True,
        database="MYDB",
    )
    # The invocation written to disk must contain raw markers so DCM's pass
    # honours the literal `{{ x }}`.
    assert "{% raw %}" in out
    assert "{% endraw %}" in out

    rendered = (
        jinja2.Environment()
        .from_string(plugin.macro_definition() + "\n" + out)
        .render(database="RUNTIME")
    )
    # After Jinja's render, the raw block is consumed but its content is
    # preserved literally — that is exactly the property the markers are
    # there to provide.
    assert "{{ x }}" in rendered


def test_body_2part_reference_is_qualified_when_schema_is_known() -> None:
    """GET_DDL only fully-qualifies the view header — bare `<schema>.<obj>`
    references in the body flow through unqualified and DCM rejects them.
    When the orchestrator passes the database's schema set, the view plugin
    rewrites them to `{{ database }}.<schema>.<obj>`."""
    out = plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.EMPLOYEE_COOKED.V AS "
        "SELECT * FROM EMPLOYEE_COOKED.WORKDAY_VIEW v WHERE v.col = 1",
        comment=None,
        use_macros=True,
        database="MYDB",
        known_schemas=frozenset({"EMPLOYEE_COOKED"}),
    )
    rendered = (
        jinja2.Environment()
        .from_string(plugin.macro_definition() + "\n" + out)
        .render(database="RUNTIME")
    )
    assert "RUNTIME.EMPLOYEE_COOKED.WORKDAY_VIEW v" in rendered
    # Table-alias references (`v.col`) must NOT be touched.
    assert "v.col = 1" in rendered


def test_body_2part_reference_left_alone_when_left_isnt_a_known_schema() -> None:
    """Without a schema match, the rewriter must not turn table-alias
    expressions like `t.col` into qualified references."""
    out = plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS SELECT t.id FROM PUBLIC.T t",
        comment=None,
        use_macros=True,
        database="MYDB",
        known_schemas=frozenset({"PUBLIC"}),
    )
    rendered = (
        jinja2.Environment()
        .from_string(plugin.macro_definition() + "\n" + out)
        .render(database="RUNTIME")
    )
    assert "RUNTIME.PUBLIC.T t" in rendered
    # The `t.id` selector must not have become `RUNTIME.t.id`.
    assert "RUNTIME.t.id" not in rendered
    assert "t.id" in rendered


def test_body_3part_reference_isnt_double_qualified() -> None:
    """Already-3-part `MYDB.SCHEMA.OBJ` should only have its database part
    swapped — the schema prefix must not be rewritten a second time."""
    out = plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS SELECT * FROM MYDB.OTHER.X",
        comment=None,
        use_macros=True,
        database="MYDB",
        known_schemas=frozenset({"PUBLIC", "OTHER"}),
    )
    rendered = (
        jinja2.Environment()
        .from_string(plugin.macro_definition() + "\n" + out)
        .render(database="RUNTIME")
    )
    assert "RUNTIME.OTHER.X" in rendered
    assert "RUNTIME.RUNTIME" not in rendered
    assert "RUNTIME.OTHER.OTHER" not in rendered


def test_body_bare_udf_call_is_qualified_when_function_is_known() -> None:
    """Bare `<funcname>(` calls in a view body are qualified to
    `{{ database }}.<schema>.<funcname>(` when the orchestrator's
    name→schema map identifies them as unambiguous user-defined callables.
    Built-in Snowflake functions don't appear in the map and are left
    alone."""
    out = plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS "
        "SELECT GET_COHORT_DAYS(SPLIT_PART(c, ' - ', 3)) FROM PUBLIC.T",
        comment=None,
        use_macros=True,
        database="MYDB",
        known_schemas=frozenset({"PUBLIC"}),
        known_functions={"GET_COHORT_DAYS": "LABOR_PLANNING_COOKED"},
    )
    rendered = (
        jinja2.Environment()
        .from_string(plugin.macro_definition() + "\n" + out)
        .render(database="RUNTIME")
    )
    assert "RUNTIME.LABOR_PLANNING_COOKED.GET_COHORT_DAYS(" in rendered
    # Built-in `SPLIT_PART` (not in the map) stays bare.
    assert "SPLIT_PART(" in rendered
    assert "RUNTIME.LABOR_PLANNING_COOKED.SPLIT_PART" not in rendered


def test_rewrites_log_records_2part_and_1part_qualifications() -> None:
    """Each rewrite must surface a one-line note in `rewrites_log` so the
    orchestrator can warn users that the body was edited. Repeated rewrites
    of the same token dedupe to keep the log readable on large views."""
    rewrites: list[str] = []
    plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS "
        "SELECT GET_COHORT_DAYS(c), GET_COHORT_DAYS(c2) "
        "FROM EMPLOYEE_COOKED.WORKDAY_VIEW UNION ALL "
        "SELECT 1, 2 FROM EMPLOYEE_COOKED.WORKDAY_VIEW",
        comment=None,
        use_macros=True,
        database="MYDB",
        known_schemas=frozenset({"PUBLIC", "EMPLOYEE_COOKED"}),
        known_functions={"GET_COHORT_DAYS": "LABOR_PLANNING_COOKED"},
        rewrites_log=rewrites,
    )
    assert any(
        "qualified 2-part reference 'EMPLOYEE_COOKED.WORKDAY_VIEW'" in r
        for r in rewrites
    ), rewrites
    assert any(
        "qualified 1-part function call 'GET_COHORT_DAYS'" in r for r in rewrites
    ), rewrites
    # Dedupe: the same 2-part reference appears twice in the body but the
    # log entry should only fire once.
    twoparts = [r for r in rewrites if "EMPLOYEE_COOKED.WORKDAY_VIEW" in r]
    assert len(twoparts) == 1, twoparts


def test_rewrites_log_left_empty_when_nothing_rewritten() -> None:
    """A view body that doesn't trigger any qualification must leave the
    log empty so the orchestrator emits no warnings."""
    rewrites: list[str] = []
    plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS SELECT 1",
        comment=None,
        use_macros=True,
        database="MYDB",
        known_schemas=frozenset({"PUBLIC"}),
        known_functions={"GET_COHORT_DAYS": "LABOR_PLANNING_COOKED"},
        rewrites_log=rewrites,
    )
    assert rewrites == []


def test_body_already_qualified_udf_call_isnt_double_qualified() -> None:
    """A function call that's already 2- or 3-part qualified must not gain
    another prefix from the function-qualification pass."""
    out = plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS "
        "SELECT LABOR_PLANNING_COOKED.GET_COHORT_DAYS(c) FROM PUBLIC.T",
        comment=None,
        use_macros=True,
        database="MYDB",
        known_schemas=frozenset({"PUBLIC", "LABOR_PLANNING_COOKED"}),
        known_functions={"GET_COHORT_DAYS": "LABOR_PLANNING_COOKED"},
    )
    rendered = (
        jinja2.Environment()
        .from_string(plugin.macro_definition() + "\n" + out)
        .render(database="RUNTIME")
    )
    # Schema-qualification should kick in (2-part → 3-part) but function-
    # qualification must not add a second prefix in front of the schema.
    assert "RUNTIME.LABOR_PLANNING_COOKED.GET_COHORT_DAYS(" in rendered
    assert "RUNTIME.LABOR_PLANNING_COOKED.LABOR_PLANNING_COOKED" not in rendered


def test_to_define_and_invocation_raw_mode() -> None:
    out = plugin.to_define_and_invocation(
        "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS SELECT 1",
        comment=None,
        use_macros=False,
        database="MYDB",
    )
    assert out.upper().startswith("DEFINE VIEW")
    assert "{{ database }}.PUBLIC.V" in out


def test_macro_definition_is_valid_jinja() -> None:
    env = jinja2.Environment()
    env.parse(plugin.macro_definition())


@pytest.mark.parametrize(
    "ddl,expected",
    [
        (
            "DEFINE VIEW MYDB.PUBLIC.V AS SELECT 1",
            {"schema": "PUBLIC", "name": "V", "body": "SELECT 1"},
        ),
        (
            "DEFINE SECURE VIEW MYDB.PUBLIC.V AS SELECT 1",
            {
                "schema": "PUBLIC",
                "name": "V",
                "secure": True,
                "body": "SELECT 1",
            },
        ),
        (
            "DEFINE RECURSIVE VIEW MYDB.PUBLIC.V AS SELECT 1",
            {
                "schema": "PUBLIC",
                "name": "V",
                "recursive": True,
                "body": "SELECT 1",
            },
        ),
        (
            "DEFINE VIEW MYDB.PUBLIC.V (A, B) AS SELECT 1, 2",
            {
                "schema": "PUBLIC",
                "name": "V",
                "column_list": "(A, B)",
                "body": "SELECT 1, 2",
            },
        ),
        (
            "DEFINE VIEW MYDB.PUBLIC.V COPY GRANTS AS SELECT 1",
            {
                "schema": "PUBLIC",
                "name": "V",
                "copy_grants": True,
                "body": "SELECT 1",
            },
        ),
        (
            "DEFINE VIEW MYDB.PUBLIC.V COMMENT='hi' AS SELECT 1",
            {
                "schema": "PUBLIC",
                "name": "V",
                "comment": "hi",
                "body": "SELECT 1",
            },
        ),
        (
            "DEFINE VIEW {{ database }}.PUBLIC.V AS SELECT 1",
            {"schema": "PUBLIC", "name": "V", "body": "SELECT 1"},
        ),
    ],
)
def test_parse_view_ddl_clauses(ddl: str, expected: dict) -> None:
    assert parse_view_ddl(ddl) == expected


@pytest.mark.parametrize(
    "ddl",
    [
        # Per-column policies not supported in v1.
        "DEFINE VIEW MYDB.PUBLIC.V (A MASKING POLICY P) AS SELECT 1",
        # Top-level row access policy not supported.
        "DEFINE VIEW MYDB.PUBLIC.V WITH ROW ACCESS POLICY P ON (A) AS SELECT 1",
        # CREATE not yet rewritten.
        "CREATE VIEW MYDB.PUBLIC.V AS SELECT 1",
        # Missing AS body.
        "DEFINE VIEW MYDB.PUBLIC.V",
    ],
)
def test_parse_view_ddl_rejects_unsupported(ddl: str) -> None:
    with pytest.raises(ViewParseError):
        parse_view_ddl(ddl)
