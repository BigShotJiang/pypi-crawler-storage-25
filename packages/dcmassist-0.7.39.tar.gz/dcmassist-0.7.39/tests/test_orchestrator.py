"""End-to-end orchestrator test against a fully mocked cursor."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from dcmassist.config import Config
from dcmassist.orchestrator import export


def _cfg(out_folder: Path, *, use_macros: bool = True) -> Config:
    return Config(
        database="MYDB",
        schemas=(),
        connection=None,
        targets=("staging",),
        default_target="staging",
        templating_defaults=(),
        configurations=("STAGING",),
        templating_configuration_keys=("environment",),
        includes=("Table",),  # narrow surface for golden test
        excludes=(),
        comment="exported by dcmassist",
        use_macros=use_macros,
        out_folder=out_folder,
        force=True,
    )


def test_export_writes_full_layout(tmp_path: Path) -> None:
    out = tmp_path / "out"

    fake_cursor = MagicMock()
    fake_conn = MagicMock()
    fake_conn.account = "AB12345"
    fake_conn.cursor.return_value = fake_cursor

    def execute_side_effect(sql, *args, **kwargs):
        fake_cursor._last_sql = sql

    def fetchall_side_effect():
        if "SHOW SCHEMAS" in fake_cursor._last_sql:
            return [
                {"name": "PUBLIC", "database_name": "MYDB"},
                {"name": "ANALYTICS", "database_name": "MYDB"},
            ]
        if "SHOW TABLES" in fake_cursor._last_sql:
            if "ANALYTICS" in fake_cursor._last_sql:
                return [
                    {"name": "T2", "schema_name": "ANALYTICS"},
                    {"name": "T3", "schema_name": "ANALYTICS"},
                ]
            return [{"name": "T1", "schema_name": "PUBLIC"}]
        return []

    def fetchone_side_effect():
        if "GET_DDL" in fake_cursor._last_sql:
            return ["CREATE OR REPLACE TABLE MYDB.PUBLIC.T1 (X INT)"]
        return None

    fake_cursor.execute.side_effect = execute_side_effect
    fake_cursor.fetchall.side_effect = fetchall_side_effect
    fake_cursor.fetchone.side_effect = fetchone_side_effect

    with patch("dcmassist.orchestrator.open_connection") as oc:
        oc.return_value = fake_conn
        code = export(_cfg(out))

    assert code == 0
    assert (out / "manifest.yml").exists()
    assert (out / "Makefile").exists()
    assert (out / "sources" / "definitions" / "table.sql").exists()
    assert (out / "sources" / "macros" / "table.sql").exists()

    log_text = (out / "dcmassist-export.log").read_text()
    assert "ANALYTICS: 2" in log_text
    assert "PUBLIC: 1" in log_text

    table_sql = (out / "sources" / "definitions" / "table.sql").read_text()
    macro_sql = (out / "sources" / "macros" / "table.sql").read_text()
    assert "{{ define_table(" in table_sql
    # Database must reach the macro as a live identifier reference, not a
    # nested string literal that would render to the inert text {{ database }}.
    assert "database=database" in table_sql
    assert "{{ database }}" not in table_sql

    # The macro + invocation must produce the expected DDL through one Jinja
    # pass — this is the regression guard for the use_macros bug.
    import jinja2

    rendered = (
        jinja2.Environment()
        .from_string(macro_sql + "\n" + table_sql)
        .render(database="RUNTIME_DB")
    )
    assert "DEFINE TABLE RUNTIME_DB.PUBLIC.T1" in rendered
    assert "{{ database }}" not in rendered

    manifest = (out / "manifest.yml").read_text()
    assert "STAGING:" in manifest
    assert "database: MYDB" in manifest
    assert "templating_config: staging" in manifest


def test_export_per_object_get_ddl_failure_continues(tmp_path: Path, capsys) -> None:
    out = tmp_path / "out"
    fake_cursor = MagicMock()
    fake_conn = MagicMock()
    fake_conn.account = "AB12345"
    fake_conn.cursor.return_value = fake_cursor

    def execute_side_effect(sql, *args, **kwargs):
        fake_cursor._last_sql = sql
        if "GET_DDL" in sql and "T_BAD" in sql:
            raise RuntimeError("permission denied")

    def fetchall_side_effect():
        if "SHOW SCHEMAS" in fake_cursor._last_sql:
            return [{"name": "PUBLIC", "database_name": "MYDB"}]
        if "SHOW TABLES" in fake_cursor._last_sql:
            return [
                {"name": "T_OK", "schema_name": "PUBLIC"},
                {"name": "T_BAD", "schema_name": "PUBLIC"},
            ]
        return []

    def fetchone_side_effect():
        if "GET_DDL" in fake_cursor._last_sql:
            return ["CREATE OR REPLACE TABLE MYDB.PUBLIC.T_OK (X INT)"]
        return None

    fake_cursor.execute.side_effect = execute_side_effect
    fake_cursor.fetchall.side_effect = fetchall_side_effect
    fake_cursor.fetchone.side_effect = fetchone_side_effect

    with patch("dcmassist.orchestrator.open_connection") as oc:
        oc.return_value = fake_conn
        code = export(_cfg(out))

    assert code == 0
    log_text = (out / "dcmassist-export.log").read_text()
    assert "T_BAD" in log_text
    assert "permission denied" in log_text
    body = (out / "sources" / "definitions" / "table.sql").read_text()
    assert "T_OK" in body
    assert "T_BAD" not in body


def test_export_no_macros_folder_when_macros_disabled(tmp_path: Path) -> None:
    """With use_macros=False the sources/macros folder must not exist."""
    out = tmp_path / "out"
    fake_cursor = MagicMock()
    fake_conn = MagicMock()
    fake_conn.account = "AB12345"
    fake_conn.cursor.return_value = fake_cursor

    def execute_side_effect(sql, *args, **kwargs):
        fake_cursor._last_sql = sql

    def fetchall_side_effect():
        if "SHOW SCHEMAS" in fake_cursor._last_sql:
            return [{"name": "PUBLIC", "database_name": "MYDB"}]
        if "SHOW TABLES" in fake_cursor._last_sql:
            return [{"name": "T1", "schema_name": "PUBLIC"}]
        return []

    def fetchone_side_effect():
        if "GET_DDL" in fake_cursor._last_sql:
            return ["CREATE OR REPLACE TABLE MYDB.PUBLIC.T1 (X INT)"]
        return None

    fake_cursor.execute.side_effect = execute_side_effect
    fake_cursor.fetchall.side_effect = fetchall_side_effect
    fake_cursor.fetchone.side_effect = fetchone_side_effect

    with patch("dcmassist.orchestrator.open_connection") as oc:
        oc.return_value = fake_conn
        code = export(_cfg(out, use_macros=False))

    assert code == 0
    assert (out / "sources" / "definitions" / "table.sql").exists()
    assert not (out / "sources" / "macros").exists()


def test_export_no_objects_returns_4_when_errors(tmp_path: Path) -> None:
    out = tmp_path / "out"
    fake_cursor = MagicMock()
    fake_conn = MagicMock()
    fake_conn.account = "AB12345"
    fake_conn.cursor.return_value = fake_cursor

    def execute_side_effect(sql, *args, **kwargs):
        fake_cursor._last_sql = sql
        if "GET_DDL" in sql:
            raise RuntimeError("denied")

    def fetchall_side_effect():
        if "SHOW SCHEMAS" in fake_cursor._last_sql:
            return [{"name": "PUBLIC", "database_name": "MYDB"}]
        if "SHOW TABLES" in fake_cursor._last_sql:
            return [{"name": "T", "schema_name": "PUBLIC"}]
        return []

    fake_cursor.execute.side_effect = execute_side_effect
    fake_cursor.fetchall.side_effect = fetchall_side_effect
    fake_cursor.fetchone.side_effect = lambda: None

    with patch("dcmassist.orchestrator.open_connection") as oc:
        oc.return_value = fake_conn
        code = export(_cfg(out))

    assert code == 4


def test_export_chunks_definitions_when_over_threshold(
    tmp_path: Path, monkeypatch
) -> None:
    """With a small DCMASSIST_EXPORT_OBJECTS_PER_FILE, a per-type DDL list
    that exceeds the threshold should split into table.sql, table2.sql, etc.,
    and the log should record one line per file plus an env-var hint."""
    monkeypatch.setenv("DCMASSIST_EXPORT_OBJECTS_PER_FILE", "2")

    out = tmp_path / "out"
    fake_cursor = MagicMock()
    fake_conn = MagicMock()
    fake_conn.account = "AB12345"
    fake_conn.cursor.return_value = fake_cursor

    counter = {"i": 0}

    def execute_side_effect(sql, *args, **kwargs):
        fake_cursor._last_sql = sql

    def fetchall_side_effect():
        if "SHOW SCHEMAS" in fake_cursor._last_sql:
            return [{"name": "PUBLIC", "database_name": "MYDB"}]
        if "SHOW TABLES" in fake_cursor._last_sql:
            return [{"name": f"T{i}", "schema_name": "PUBLIC"} for i in range(5)]
        return []

    def fetchone_side_effect():
        if "GET_DDL" in fake_cursor._last_sql:
            counter["i"] += 1
            return [f"CREATE OR REPLACE TABLE MYDB.PUBLIC.T{counter['i']} (X INT)"]
        return None

    fake_cursor.execute.side_effect = execute_side_effect
    fake_cursor.fetchall.side_effect = fetchall_side_effect
    fake_cursor.fetchone.side_effect = fetchone_side_effect

    with patch("dcmassist.orchestrator.open_connection") as oc:
        oc.return_value = fake_conn
        code = export(_cfg(out))

    assert code == 0
    defs = out / "sources" / "definitions"
    assert (defs / "table.sql").exists()
    assert (defs / "table2.sql").exists()
    assert (defs / "table3.sql").exists()
    assert not (defs / "table4.sql").exists()

    log_text = (out / "dcmassist-export.log").read_text()
    assert "2 table(s) written to table.sql" in log_text
    assert "2 table(s) written to table2.sql" in log_text
    assert "1 table(s) written to table3.sql" in log_text
    assert "DCMASSIST_EXPORT_OBJECTS_PER_FILE" in log_text


def test_export_invalid_objects_per_file_returns_5(
    tmp_path: Path, monkeypatch, capsys
) -> None:
    """A malformed env var must surface clearly and not start the export."""
    monkeypatch.setenv("DCMASSIST_EXPORT_OBJECTS_PER_FILE", "abc")
    out = tmp_path / "out"
    code = export(_cfg(out))
    assert code == 5
    assert not out.exists()
    err = capsys.readouterr().err
    assert "DCMASSIST_EXPORT_OBJECTS_PER_FILE" in err


def test_export_logs_all_config_options_at_start(tmp_path: Path) -> None:
    """The header of dcmassist-export.log records every Config field plus the
    resolved chunk size, so users can see what options were chosen and
    discover ones they didn't know about."""
    out = tmp_path / "out"

    fake_cursor = MagicMock()
    fake_conn = MagicMock()
    fake_conn.account = "AB12345"
    fake_conn.cursor.return_value = fake_cursor

    def execute_side_effect(sql, *args, **kwargs):
        fake_cursor._last_sql = sql

    def fetchall_side_effect():
        return []

    fake_cursor.execute.side_effect = execute_side_effect
    fake_cursor.fetchall.side_effect = fetchall_side_effect
    fake_cursor.fetchone.side_effect = lambda: None

    with patch("dcmassist.orchestrator.open_connection") as oc:
        oc.return_value = fake_conn
        export(_cfg(out))

    log_text = (out / "dcmassist-export.log").read_text()
    assert "export starting" in log_text
    assert "database='MYDB'" in log_text
    assert "use_macros=True" in log_text
    assert "force=True" in log_text
    assert "includes=('Table',)" in log_text
    assert "DCMASSIST_EXPORT_OBJECTS_PER_FILE=100" in log_text


def test_export_logs_warning_when_view_body_is_rewritten(tmp_path: Path) -> None:
    """The orchestrator records a `WARN` line per qualification rewrite so
    users can audit which view bodies were edited. The note includes the
    type, FQN, and the rewritten token."""
    out = tmp_path / "out"

    fake_cursor = MagicMock()
    fake_conn = MagicMock()
    fake_conn.account = "AB12345"
    fake_conn.cursor.return_value = fake_cursor

    def execute_side_effect(sql, *args, **kwargs):
        fake_cursor._last_sql = sql

    def fetchall_side_effect():
        sql = fake_cursor._last_sql
        if "SHOW SCHEMAS" in sql:
            return [
                {"name": "PUBLIC", "database_name": "MYDB"},
                {"name": "ANALYTICS", "database_name": "MYDB"},
            ]
        if "SHOW VIEWS" in sql and "PUBLIC" in sql:
            return [{"name": "V", "schema_name": "PUBLIC"}]
        if "SHOW USER FUNCTIONS" in sql or "SHOW PROCEDURES" in sql:
            return []
        return []

    def fetchone_side_effect():
        if "GET_DDL" in fake_cursor._last_sql:
            return [
                "CREATE OR REPLACE VIEW MYDB.PUBLIC.V AS "
                "SELECT * FROM ANALYTICS.OTHER_VIEW"
            ]
        return None

    fake_cursor.execute.side_effect = execute_side_effect
    fake_cursor.fetchall.side_effect = fetchall_side_effect
    fake_cursor.fetchone.side_effect = fetchone_side_effect

    cfg = Config(
        database="MYDB",
        schemas=(),
        connection=None,
        targets=("start",),
        default_target="start",
        templating_defaults=(),
        configurations=(),
        templating_configuration_keys=(),
        includes=("View",),
        excludes=(),
        comment="",
        use_macros=True,
        out_folder=out,
        force=True,
    )

    with patch("dcmassist.orchestrator.open_connection") as oc:
        oc.return_value = fake_conn
        export(cfg)

    log_text = (out / "dcmassist-export.log").read_text()
    assert "WARN" in log_text
    assert "MYDB.PUBLIC.V" in log_text
    assert "qualified 2-part reference 'ANALYTICS.OTHER_VIEW'" in log_text
