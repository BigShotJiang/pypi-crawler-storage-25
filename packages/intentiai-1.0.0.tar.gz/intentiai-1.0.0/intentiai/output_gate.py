"""IntentiAI Output Gate — validates LLM responses before they reach the user.

Sequential pipeline with early exit:
  1. PII Detection (regex, <1ms) → REDACT or REJECT
  2. Prompt Leakage (regex, <1ms) → REJECT
  3. Policy Compliance (regex, <2ms) → REJECT
  4. Content Safety (toxicity+moderation models, ~50ms) → REJECT
  5. Topic Drift (DeBERTa cosine, ~32ms) → REJECT

Usage:
    from intentiai import OutputGate

    gate = OutputGate()
    result = gate.check("LLM response text", input_query="user query")
    if result.passed:
        return result.response_text  # may be redacted
    else:
        return "I cannot provide that response."
"""

import time
from typing import Optional
import numpy as np

from .types import OutputAction, CheckResult, OutputGateResult
from .config import OutputGateConfig
from .checks.pii import PIIChecker
from .checks.prompt_leakage import PromptLeakageChecker
from .checks.policy import PolicyChecker
from .checks.content_safety import ContentSafetyChecker
from .checks.topic_drift import TopicDriftChecker


class OutputGate:
    """Validates LLM responses through a sequential check pipeline."""

    def __init__(self, config: OutputGateConfig = None, encoder=None, tokenizer=None):
        self.config = config or OutputGateConfig()

        self._pii = PIIChecker(self.config.pii) if self.config.pii.enabled else None
        self._leakage = PromptLeakageChecker(self.config.prompt_leakage) if self.config.prompt_leakage.enabled else None
        self._policy = PolicyChecker(self.config.policy) if self.config.policy.enabled else None
        self._safety = ContentSafetyChecker(self.config.content_safety) if self.config.content_safety.enabled else None
        self._drift = TopicDriftChecker(self.config.topic_drift, encoder=encoder, tokenizer=tokenizer) if self.config.topic_drift.enabled else None

    def check(
        self,
        response_text: str,
        input_query: str = "",
        input_embedding: Optional[np.ndarray] = None,
    ) -> OutputGateResult:
        """Run all enabled checks on the LLM response.

        Args:
            response_text: The LLM-generated response to validate.
            input_query: The original user query (needed for topic drift).
            input_embedding: Precomputed input embedding from input gate (optional).

        Returns:
            OutputGateResult with action, possibly redacted text, and per-check details.
        """
        t0 = time.perf_counter()
        result_text = response_text
        all_checks = []
        worst_action = OutputAction.PASS

        try:
            # 1. PII Detection (<1ms)
            if self._pii:
                pii_result = self._pii.check(result_text)
                all_checks.append(pii_result)
                if pii_result.action > worst_action:
                    worst_action = pii_result.action
                if pii_result.action == OutputAction.REDACT and "redacted_text" in pii_result.details:
                    result_text = pii_result.details["redacted_text"]
                if worst_action == OutputAction.REJECT:
                    return self._build_result(worst_action, result_text, all_checks, t0)

            # 2. Prompt Leakage (<1ms)
            if self._leakage:
                leak_result = self._leakage.check(result_text)
                all_checks.append(leak_result)
                if leak_result.action > worst_action:
                    worst_action = leak_result.action
                if worst_action == OutputAction.REJECT:
                    return self._build_result(worst_action, result_text, all_checks, t0)

            # 3. Policy Compliance (<2ms)
            if self._policy:
                policy_result = self._policy.check(result_text)
                all_checks.append(policy_result)
                if policy_result.action > worst_action:
                    worst_action = policy_result.action
                if worst_action == OutputAction.REJECT:
                    return self._build_result(worst_action, result_text, all_checks, t0)

            # 4. Content Safety (~50ms, models lazy-loaded on first call)
            if self._safety:
                safety_result = self._safety.check(result_text)
                all_checks.append(safety_result)
                if safety_result.action > worst_action:
                    worst_action = safety_result.action
                if worst_action == OutputAction.REJECT:
                    return self._build_result(worst_action, result_text, all_checks, t0)

            # 5. Topic Drift (~32ms, only if not already rejected)
            if self._drift and input_query:
                drift_result = self._drift.check(result_text, input_query, input_embedding)
                all_checks.append(drift_result)
                if drift_result.action > worst_action:
                    worst_action = drift_result.action

        except Exception as e:
            if not self.config.fail_open:
                worst_action = OutputAction.REJECT
            all_checks.append(CheckResult(
                check_name="error", passed=self.config.fail_open,
                action=OutputAction.PASS if self.config.fail_open else OutputAction.REJECT,
                details={"error": str(e)}
            ))

        return self._build_result(worst_action, result_text, all_checks, t0)

    def _build_result(self, action, text, checks, t0):
        return OutputGateResult(
            action=action,
            response_text=text,
            checks=checks,
            latency_ms=(time.perf_counter() - t0) * 1000,
        )
