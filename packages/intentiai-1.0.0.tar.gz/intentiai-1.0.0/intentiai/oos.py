"""Out-of-scope detection using Adaptive Decision Boundaries (ADB).

Based on Zhang et al. (AAAI 2021) with asymmetric boundary loss.
"""

import os
import numpy as np


def fit_mahalanobis(train_emb, train_labels, K):
    """Compute class centroids and shared precision matrix.
    Returns (centroids, cov_inv).
    """
    from sklearn.covariance import EmpiricalCovariance
    labels = np.asarray(train_labels)
    groups = {}
    for i, l in enumerate(labels):
        groups.setdefault(l, []).append(train_emb[i])
    centroids = np.zeros((K, train_emb.shape[1]))
    for l in range(K):
        if l in groups:
            centroids[l] = np.mean(groups[l], axis=0)
    residuals = train_emb - centroids[labels]
    cov_inv = EmpiricalCovariance().fit(residuals).precision_
    return centroids, cov_inv


def compute_mahalanobis_batch(test_emb, centroids, cov_inv):
    """Vectorized Mahalanobis distance to nearest centroid. Returns (N,)."""
    diffs = test_emb[:, None, :] - centroids[None, :, :]
    transformed = np.einsum("nkd,de->nke", diffs, cov_inv)
    return np.einsum("nkd,nkd->nk", transformed, diffs).min(axis=1)


def train_adb(train_emb, train_labels, centroids, K, epochs=200, lr=0.05, device=None):
    """Train ADB per-class radii with asymmetric loss. Returns (K,) radii array."""
    import torch
    import torch.nn as nn

    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    class _AdaptiveBoundary(nn.Module):
        def __init__(self, K):
            super().__init__()
            self.delta = nn.Parameter(torch.zeros(K))
        def get_radii(self):
            return nn.functional.softplus(self.delta)
        def forward(self, dists, labels):
            radii = self.get_radii()
            r = radii[labels]
            outside = (dists > r).float()
            inside = (dists <= r).float()
            # Asymmetric: 0.2 weight on shrinkage
            return (outside * (dists - r)).mean() + 0.2 * (inside * (r - dists)).mean()

    labels_t = torch.LongTensor(train_labels).to(device)
    centroids_t = torch.FloatTensor(centroids).to(device)
    emb_t = torch.FloatTensor(train_emb).to(device)
    dists = torch.norm(emb_t - centroids_t[labels_t], dim=1)

    adb = _AdaptiveBoundary(K).to(device)
    # Initialize at mean + 3*std
    with torch.no_grad():
        for k in range(K):
            mask = labels_t == k
            if mask.sum() > 0:
                cd = dists[mask]
                adb.delta.data[k] = torch.log(torch.exp(cd.mean() + 3 * cd.std()) - 1 + 1e-6)

    opt = torch.optim.Adam(adb.parameters(), lr=lr)
    for _ in range(epochs):
        opt.zero_grad()
        adb(dists, labels_t).backward()
        opt.step()

    return adb.get_radii().detach().cpu().numpy()


def adb_oos_score(test_emb, centroids, radii):
    """Compute ADB OOS scores. Returns (scores, nearest_class) tuple.
    scores: (N,) normalized distance beyond boundary (positive = OOS)
    """
    dists = np.linalg.norm(test_emb[:, None, :] - centroids[None, :, :], axis=2)
    nearest = dists.argmin(axis=1)
    nearest_dist = dists[np.arange(len(test_emb)), nearest]
    nearest_radius = radii[nearest]
    scores = (nearest_dist - nearest_radius) / (nearest_radius + 1e-8)
    return scores, nearest


def load_oos_artifacts(artifacts_dir):
    """Load ADB centroids+radii from .npz files.
    Returns dict with keys: centroids, radii.
    """
    adb_data = np.load(os.path.join(artifacts_dir, "adb.npz"))
    return {
        "centroids": adb_data["centroids"],
        "radii": adb_data["radii"],
    }
