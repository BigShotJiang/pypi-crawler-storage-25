"""Content safety detection using off-the-shelf toxicity models.

Two-model ensemble:
1. unitary/unbiased-toxic-roberta — 7 multi-label toxicity categories
2. KoalaAI/Text-Moderation — violence, self-harm, harassment categories

Combined coverage: toxicity, severe_toxicity, obscene, threat, insult,
identity_attack, sexual_explicit, violence, self-harm, harassment.
"""

import numpy as np
from typing import Optional
from ..types import CheckResult, OutputAction
from ..config import ContentSafetyConfig


# Category mapping for each model
TOXIC_ROBERTA_LABELS = [
    "toxicity", "severe_toxicity", "obscene",
    "threat", "insult", "identity_attack", "sexual_explicit"
]

KOALA_LABELS = [
    "sexual", "hate", "violence", "harassment",
    "self-harm", "sexual/minors", "hate/threatening",
    "violence/graphic", "OK"
]


class ContentSafetyChecker:
    """Detect toxic, harmful, or unsafe content using model ensemble."""

    def __init__(self, config: ContentSafetyConfig = None):
        self.config = config or ContentSafetyConfig()
        self._toxic_model = None
        self._toxic_tokenizer = None
        self._koala_model = None
        self._koala_tokenizer = None
        self._device = None

    def _ensure_models(self):
        """Lazy-load models on first use."""
        if self._toxic_model is not None:
            return
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Model 1: unitary/unbiased-toxic-roberta (7 multi-label toxicity)
        if self.config.enable_toxicity:
            try:
                self._toxic_model = AutoModelForSequenceClassification.from_pretrained(
                    self.config.toxicity_model
                ).to(self._device)
                self._toxic_tokenizer = AutoTokenizer.from_pretrained(self.config.toxicity_model)
                self._toxic_model.eval()
            except Exception as e:
                print(f"  Warning: failed to load {self.config.toxicity_model}: {e}")

        # Model 2: KoalaAI/Text-Moderation (violence, self-harm, harassment)
        if self.config.enable_moderation:
            try:
                self._koala_model = AutoModelForSequenceClassification.from_pretrained(
                    self.config.moderation_model
                ).to(self._device)
                self._koala_tokenizer = AutoTokenizer.from_pretrained(self.config.moderation_model)
                self._koala_model.eval()
            except Exception as e:
                print(f"  Warning: failed to load {self.config.moderation_model}: {e}")

    def _run_toxic_roberta(self, text: str) -> dict:
        """Run unbiased-toxic-roberta. Returns {label: probability} for 7 categories."""
        import torch
        if self._toxic_model is None:
            return {}
        enc = self._toxic_tokenizer(
            text, max_length=512, padding=True, truncation=True, return_tensors="pt"
        )
        with torch.no_grad():
            logits = self._toxic_model(
                input_ids=enc["input_ids"].to(self._device),
                attention_mask=enc["attention_mask"].to(self._device),
            ).logits
        probs = torch.sigmoid(logits).cpu().numpy()[0]  # multi-label sigmoid
        return {TOXIC_ROBERTA_LABELS[i]: float(probs[i]) for i in range(len(TOXIC_ROBERTA_LABELS))}

    def _run_koala(self, text: str) -> dict:
        """Run KoalaAI Text-Moderation. Returns {label: probability} for 9 categories."""
        import torch
        if self._koala_model is None:
            return {}
        enc = self._koala_tokenizer(
            text, max_length=512, padding=True, truncation=True, return_tensors="pt"
        )
        with torch.no_grad():
            logits = self._koala_model(
                input_ids=enc["input_ids"].to(self._device),
                attention_mask=enc["attention_mask"].to(self._device),
            ).logits
        probs = torch.softmax(logits, dim=-1).cpu().numpy()[0]  # multi-class softmax
        return {KOALA_LABELS[i]: float(probs[i]) for i in range(min(len(KOALA_LABELS), len(probs)))}

    def check(self, text: str) -> CheckResult:
        self._ensure_models()

        all_scores = {}
        flagged = []

        # Run toxicity model
        if self.config.enable_toxicity:
            toxic_scores = self._run_toxic_roberta(text)
            all_scores.update({f"toxic_{k}": v for k, v in toxic_scores.items()})
            for label, prob in toxic_scores.items():
                if prob > self.config.toxicity_threshold:
                    flagged.append({"source": "toxic-roberta", "label": label, "score": round(prob, 4)})

        # Run moderation model
        if self.config.enable_moderation:
            koala_scores = self._run_koala(text)
            all_scores.update({f"mod_{k}": v for k, v in koala_scores.items()})
            for label, prob in koala_scores.items():
                if label != "OK" and prob > self.config.moderation_threshold:
                    flagged.append({"source": "koala-moderation", "label": label, "score": round(prob, 4)})

        if not flagged:
            return CheckResult(
                check_name="content_safety", passed=True,
                action=OutputAction.PASS,
                details={"scores": all_scores}
            )

        return CheckResult(
            check_name="content_safety", passed=False,
            action=OutputAction[self.config.action],
            details={
                "flagged": flagged,
                "count": len(flagged),
                "categories": list(set(f["label"] for f in flagged)),
                "scores": all_scores,
            }
        )
