"""Configurable policy compliance checker."""

import re
from ..types import CheckResult, OutputAction
from ..config import PolicyConfig


# Built-in topic detectors for common forbidden categories
_BUILTIN_TOPICS = {
    "medical_advice": [
        re.compile(p, re.IGNORECASE) for p in [
            r"you\s+should\s+(take|stop\s+taking|increase|decrease)\s+\w+",
            r"(I\s+recommend|I\s+suggest)\s+(taking|stopping|increasing)",
            r"(diagnosis|diagnose|prescribed|dosage|medication|treatment\s+plan)",
            r"(consult|see)\s+(a|your)\s+(doctor|physician|specialist)",
        ]
    ],
    "legal_advice": [
        re.compile(p, re.IGNORECASE) for p in [
            r"you\s+should\s+(sue|file\s+a\s+lawsuit|press\s+charges)",
            r"(legal\s+action|statute\s+of\s+limitations|liability|negligence)",
            r"(I\s+recommend|I\s+suggest)\s+(hiring|consulting)\s+a\s+(lawyer|attorney)",
            r"you\s+(have|may\s+have)\s+a\s+(case|claim|right\s+to)",
        ]
    ],
    "financial_advice": [
        re.compile(p, re.IGNORECASE) for p in [
            r"you\s+should\s+(buy|sell|invest\s+in|short|hold)\s+",
            r"(I\s+recommend|I\s+suggest)\s+(buying|selling|investing)",
            r"(guaranteed\s+return|risk.free|can.t\s+lose|sure\s+bet)",
            r"(stock|crypto|bitcoin|ethereum)\s+(will|is\s+going\s+to)\s+(go\s+up|rise|moon|crash)",
        ]
    ],
}


class PolicyChecker:
    """Check LLM response against configurable policy rules."""

    def __init__(self, config: PolicyConfig = None):
        self.config = config or PolicyConfig()
        # Compile custom forbidden patterns
        self._custom_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.config.forbidden_patterns
        ]
        # Prepare keyword set (lowercase)
        self._keywords = set(k.lower() for k in self.config.forbidden_keywords)
        # Collect active topic patterns
        self._topic_patterns = {}
        for topic in self.config.forbidden_topics:
            if topic in _BUILTIN_TOPICS:
                self._topic_patterns[topic] = _BUILTIN_TOPICS[topic]

    def check(self, text: str) -> CheckResult:
        violations = []
        text_lower = text.lower()

        # Check 1: Forbidden keywords (whole-word matching)
        for kw in self._keywords:
            pattern = re.compile(r'\b' + re.escape(kw) + r'\b', re.IGNORECASE)
            if pattern.search(text):
                violations.append({"type": "keyword", "keyword": kw})

        # Check 2: Custom regex patterns
        for i, pat in enumerate(self._custom_patterns):
            match = pat.search(text)
            if match:
                violations.append({
                    "type": "custom_pattern",
                    "pattern_index": i,
                    "matched_text": match.group(),
                })

        # Check 3: Built-in topic detectors
        for topic, patterns in self._topic_patterns.items():
            for pat in patterns:
                match = pat.search(text)
                if match:
                    violations.append({
                        "type": "forbidden_topic",
                        "topic": topic,
                        "matched_text": match.group(),
                    })
                    break  # one match per topic is enough

        if not violations:
            return CheckResult(
                check_name="policy", passed=True,
                action=OutputAction.PASS, details={}
            )

        return CheckResult(
            check_name="policy", passed=False,
            action=OutputAction[self.config.action],
            details={"violations": violations, "count": len(violations)}
        )
