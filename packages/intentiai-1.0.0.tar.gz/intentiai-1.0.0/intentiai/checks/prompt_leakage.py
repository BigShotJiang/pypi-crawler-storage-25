"""Detect if LLM response reveals the system prompt."""

import re
from ..types import CheckResult, OutputAction
from ..config import PromptLeakageConfig


# Structural patterns that indicate prompt leakage (even without knowing the prompt)
_LEAKAGE_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        r"my\s+(system\s+)?instructions\s+(are|say|tell|include)",
        r"I\s+was\s+(told|instructed|programmed|configured)\s+to",
        r"my\s+(initial|original|system)\s+prompt\s+(is|says|reads|contains)",
        r"here\s+(is|are)\s+my\s+(instructions|rules|guidelines|system\s+prompt)",
        r"my\s+(instructions|rules|guidelines)\s+(state|say|are)\s+that",
        r"I\s+am\s+programmed\s+with\s+the\s+following",
        r"the\s+system\s+prompt\s+(is|says|reads|contains|states)",
        r"I\s+can\s+share\s+my\s+(instructions|prompt|rules)",
        r"sure,?\s+here\s+(is|are)\s+my\s+(system\s+)?(prompt|instructions)",
        r"my\s+role\s+is\s+defined\s+as",
    ]
]


class PromptLeakageChecker:
    """Detect system prompt leakage in LLM responses."""

    def __init__(self, config: PromptLeakageConfig = None):
        self.config = config or PromptLeakageConfig()
        self._fragments = [f.lower().strip() for f in self.config.system_prompt_fragments if f.strip()]

    @staticmethod
    def _trigram_overlap(text: str, fragment: str, threshold: float = 0.5) -> bool:
        """Check if text contains enough trigrams from the fragment."""
        import re as _re
        clean = lambda s: _re.sub(r'[^\w\s]', '', s).split()
        words_frag = clean(fragment)
        if len(words_frag) < 3:
            return fragment in text
        trigrams_frag = set(tuple(words_frag[i:i+3]) for i in range(len(words_frag)-2))
        words_text = clean(text)
        trigrams_text = set(tuple(words_text[i:i+3]) for i in range(len(words_text)-2))
        if not trigrams_frag:
            return False
        overlap = len(trigrams_frag & trigrams_text) / len(trigrams_frag)
        return overlap >= threshold

    def check(self, text: str) -> CheckResult:
        text_lower = text.lower()

        # Check 1: Known system prompt fragments (exact substring OR trigram overlap)
        for frag in self._fragments:
            if frag in text_lower or self._trigram_overlap(text_lower, frag):
                return CheckResult(
                    check_name="prompt_leakage", passed=False,
                    action=OutputAction[self.config.action],
                    details={"method": "fragment_match", "matched_fragment": frag}
                )

        # Check 2: Structural leakage patterns
        for pat in _LEAKAGE_PATTERNS:
            match = pat.search(text)
            if match:
                return CheckResult(
                    check_name="prompt_leakage", passed=False,
                    action=OutputAction[self.config.action],
                    details={"method": "structural_pattern", "matched_text": match.group()}
                )

        return CheckResult(
            check_name="prompt_leakage", passed=True,
            action=OutputAction.PASS, details={}
        )
