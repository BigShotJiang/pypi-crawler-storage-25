"""PII detection and redaction using compiled regex patterns."""

import re
from ..types import CheckResult, OutputAction
from ..config import PIIConfig


def _luhn_check(number: str) -> bool:
    """Validate credit card number with Luhn algorithm."""
    digits = [int(d) for d in number if d.isdigit()]
    if len(digits) < 13 or len(digits) > 19:
        return False
    checksum = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0


# Compiled regex patterns for each PII type
_PATTERNS = {
    "email": re.compile(
        r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'
    ),
    "phone": re.compile(
        r'(?<!\d)(\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}(?!\d)'
    ),
    "ssn": re.compile(
        r'\b\d{3}-\d{2}-\d{4}\b(?![-\d])'  # negative lookahead: not followed by more digits/dashes
    ),
    "credit_card": re.compile(
        r'\b(?:4\d{3}|5[1-5]\d{2}|3[47]\d{2}|6(?:011|5\d{2}))[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{3,4}\b'
    ),
    "ip_address": re.compile(
        r'\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b'
    ),
}


class PIIChecker:
    """Detect and optionally redact PII in text using regex patterns."""

    def __init__(self, config: PIIConfig = None):
        self.config = config or PIIConfig()
        self._active_patterns = {}
        if self.config.detect_emails:
            self._active_patterns["email"] = _PATTERNS["email"]
        if self.config.detect_phones:
            self._active_patterns["phone"] = _PATTERNS["phone"]
        if self.config.detect_ssns:
            self._active_patterns["ssn"] = _PATTERNS["ssn"]
        if self.config.detect_credit_cards:
            self._active_patterns["credit_card"] = _PATTERNS["credit_card"]
        if self.config.detect_ips:
            self._active_patterns["ip_address"] = _PATTERNS["ip_address"]

    def check(self, text: str) -> CheckResult:
        findings = []
        for pii_type, pattern in self._active_patterns.items():
            for match in pattern.finditer(text):
                value = match.group()
                # Luhn validation for credit cards
                if pii_type == "credit_card" and not _luhn_check(value):
                    continue
                findings.append({
                    "type": pii_type,
                    "value": value,
                    "span": (match.start(), match.end()),
                })

        if not findings:
            return CheckResult(
                check_name="pii", passed=True,
                action=OutputAction.PASS, details={}
            )

        action = OutputAction[self.config.action]
        redacted = text
        if action == OutputAction.REDACT:
            redacted = self._redact(text, findings)

        return CheckResult(
            check_name="pii", passed=False, action=action,
            details={
                "found": findings,
                "count": len(findings),
                "types": list(set(f["type"] for f in findings)),
                "redacted_text": redacted,
            }
        )

    def _redact(self, text: str, findings: list) -> str:
        # Sort by span start descending to replace from end (preserves positions)
        for f in sorted(findings, key=lambda x: x["span"][0], reverse=True):
            start, end = f["span"]
            text = text[:start] + self.config.redaction_string + text[end:]
        return text
