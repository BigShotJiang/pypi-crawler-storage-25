"""Topic drift detection using DeBERTa embedding cosine similarity."""

import numpy as np
from typing import Optional
from ..types import CheckResult, OutputAction
from ..config import TopicDriftConfig


class TopicDriftChecker:
    """Detect if LLM response drifted off-topic from the input query."""

    def __init__(self, config: TopicDriftConfig = None, encoder=None, tokenizer=None):
        self.config = config or TopicDriftConfig()
        self.encoder = encoder
        self.tokenizer = tokenizer
        self._device = None

    def _ensure_model(self):
        """Lazy-load the encoder if not provided."""
        if self.encoder is not None:
            return
        import torch
        from transformers import AutoModel, AutoTokenizer
        self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(self.config.encoder_name)
        self.encoder = AutoModel.from_pretrained(
            self.config.encoder_name, torch_dtype=torch.float32
        ).to(self._device)
        self.encoder.eval()

    def _encode(self, text: str) -> np.ndarray:
        """Encode text to 768-dim CLS embedding."""
        import torch
        self._ensure_model()
        device = self._device or next(self.encoder.parameters()).device
        enc = self.tokenizer(
            text, max_length=self.config.max_length,
            padding="max_length", truncation=True, return_tensors="pt"
        )
        with torch.no_grad():
            out = self.encoder(
                input_ids=enc["input_ids"].to(device),
                attention_mask=enc["attention_mask"].to(device),
            )
        return out.last_hidden_state[:, 0, :].float().cpu().numpy().flatten()

    @staticmethod
    def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a < 1e-8 or norm_b < 1e-8:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))

    def check(
        self,
        response_text: str,
        input_query: str,
        input_embedding: Optional[np.ndarray] = None,
    ) -> CheckResult:
        # Encode input query (or reuse precomputed embedding from input gate)
        if input_embedding is not None:
            emb_input = input_embedding
        else:
            emb_input = self._encode(input_query)

        # Encode response (truncated to first max_length tokens for speed)
        emb_response = self._encode(response_text)

        sim = self.cosine_similarity(emb_input, emb_response)
        passed = sim >= self.config.similarity_threshold

        return CheckResult(
            check_name="topic_drift",
            passed=passed,
            action=OutputAction.PASS if passed else OutputAction[self.config.action],
            details={
                "cosine_similarity": round(sim, 4),
                "threshold": self.config.similarity_threshold,
            },
        )
