"""Configuration models for the IntentiAI gate system."""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class PIIConfig:
    enabled: bool = True
    detect_emails: bool = True
    detect_phones: bool = True
    detect_ssns: bool = True
    detect_credit_cards: bool = True
    detect_ips: bool = True
    action: str = "REDACT"  # "REDACT" or "REJECT"
    redaction_string: str = "[REDACTED]"


@dataclass
class PromptLeakageConfig:
    enabled: bool = True
    system_prompt_fragments: List[str] = field(default_factory=list)
    action: str = "REJECT"


@dataclass
class PolicyConfig:
    enabled: bool = True
    forbidden_topics: List[str] = field(default_factory=list)
    forbidden_keywords: List[str] = field(default_factory=list)
    forbidden_patterns: List[str] = field(default_factory=list)
    action: str = "REJECT"


@dataclass
class TopicDriftConfig:
    enabled: bool = True
    similarity_threshold: float = 0.25
    encoder_name: str = "microsoft/deberta-v3-base"
    max_length: int = 64
    action: str = "REJECT"


@dataclass
class ContentSafetyConfig:
    enabled: bool = True
    toxicity_model: str = "unitary/unbiased-toxic-roberta"
    moderation_model: str = "KoalaAI/Text-Moderation"
    enable_toxicity: bool = True
    enable_moderation: bool = False  # disabled by default — high FP rate on clean text
    toxicity_threshold: float = 0.5
    moderation_threshold: float = 0.7  # raised from 0.5 to reduce FP if enabled
    action: str = "REJECT"


@dataclass
class OutputGateConfig:
    pii: PIIConfig = field(default_factory=PIIConfig)
    prompt_leakage: PromptLeakageConfig = field(default_factory=PromptLeakageConfig)
    policy: PolicyConfig = field(default_factory=PolicyConfig)
    content_safety: ContentSafetyConfig = field(default_factory=ContentSafetyConfig)
    topic_drift: TopicDriftConfig = field(default_factory=TopicDriftConfig)
    fail_open: bool = False


# ─── Input Gate Configs ───

@dataclass
class InjectionConfig:
    enabled: bool = True
    models: List[str] = field(default_factory=lambda: [
        "meta-llama/Llama-Prompt-Guard-2-86M",
        "protectai/deberta-v3-base-prompt-injection-v2",
        "deepset/deberta-v3-base-injection",
        "madhurjindal/Jailbreak-Detector",
    ])
    regex_enabled: bool = True
    threshold: float = 0.90
    intent_confidence_prefilter: float = 0.90


@dataclass
class OOSConfig:
    enabled: bool = True
    threshold: float = 0.0  # overridden by gate_config.json artifacts
    method: str = "adb"


@dataclass
class InputGateConfig:
    encoder_name: str = "microsoft/deberta-v3-base"
    max_length: int = 64
    injection: InjectionConfig = field(default_factory=InjectionConfig)
    oos: OOSConfig = field(default_factory=OOSConfig)
    fail_open: bool = False
