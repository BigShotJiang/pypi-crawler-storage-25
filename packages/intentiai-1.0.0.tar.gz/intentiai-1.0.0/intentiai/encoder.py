"""DeBERTa encoder for intent classification and embedding extraction.

Extracted from the IntentiAI training notebook. At inference time, only
DeBERTaEncoder.forward() and compute_intent_confidence() are needed.
"""

import os
import numpy as np


class DeBERTaEncoder:
    """Fine-tuned DeBERTa with classification head.

    forward() returns (logits, cls_embedding).
    """
    _nn = None  # lazy torch.nn

    def __new__(cls, *args, **kwargs):
        import torch.nn as nn
        cls._nn = nn

        # Dynamically create the actual nn.Module subclass
        class _DeBERTaEncoderModule(nn.Module):
            def __init__(self, name, n_classes):
                super().__init__()
                from transformers import AutoModel
                self.encoder = AutoModel.from_pretrained(name, torch_dtype=None)
                h = self.encoder.config.hidden_size
                self.classifier = nn.Sequential(nn.Dropout(0.1), nn.Linear(h, n_classes))

            def forward(self, input_ids, attention_mask):
                import torch
                out = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
                cls_emb = out.last_hidden_state[:, 0, :].float()
                return self.classifier(cls_emb), cls_emb

        return _DeBERTaEncoderModule(*args, **kwargs)

    @staticmethod
    def from_artifacts(artifacts_dir, num_classes, encoder_name="microsoft/deberta-v3-base", device=None):
        """Load fine-tuned weights from gate_artifacts/deberta_finetuned.pt."""
        import torch
        model = DeBERTaEncoder(encoder_name, num_classes)
        state_path = os.path.join(artifacts_dir, "deberta_finetuned.pt")
        state = torch.load(state_path, map_location="cpu", weights_only=False)
        model.load_state_dict(state)
        if device:
            model = model.to(device)
        model.eval()
        return model


def extract_embeddings(model, texts, tokenizer, max_length=64, batch_size=64, device=None):
    """Extract CLS embeddings. Returns (N, 768) numpy array."""
    import torch
    if device is None:
        device = next(model.parameters()).device
    model.eval()
    embs = []
    for i in range(0, len(texts), batch_size):
        enc = tokenizer(texts[i:i+batch_size], max_length=max_length,
                        padding="max_length", truncation=True, return_tensors="pt")
        with torch.no_grad():
            out = model.encoder(input_ids=enc["input_ids"].to(device),
                                attention_mask=enc["attention_mask"].to(device))
        embs.append(out.last_hidden_state[:, 0, :].float().cpu().numpy())
    return np.concatenate(embs)


def extract_logits(model, embeddings, batch_size=512, device=None):
    """Run classifier head on embeddings. Returns (N, K) numpy array."""
    import torch
    if device is None:
        device = next(model.parameters()).device
    model.eval()
    all_logits = []
    t = torch.FloatTensor(embeddings)
    for i in range(0, len(embeddings), batch_size):
        batch = t[i:i+batch_size].to(device)
        with torch.no_grad():
            all_logits.append(model.classifier(batch).cpu().numpy())
    return np.concatenate(all_logits)


def compute_intent_confidence(logits):
    """Max softmax probability from logits. Returns (N,) array."""
    probs = np.exp(logits - logits.max(axis=1, keepdims=True))
    probs = probs / probs.sum(axis=1, keepdims=True)
    return probs.max(axis=1)
