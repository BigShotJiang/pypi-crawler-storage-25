"""IntentiAI — The AI Safety Gate.

Define what your AI can and cannot do. We enforce it.

Usage:
    from intentiai import IntentiAI

    # Full system (input + output gate)
    gate = IntentiAI.from_artifacts("gate_artifacts/")
    input_result = gate.check_input("Transfer $500 to John")
    output_result = gate.check_output("Transfer initiated", input_query="Transfer $500")

    # Sandwich: input -> LLM -> output
    @gate.enforce
    def chat(message):
        return call_llm(message)

    # Constitution from YAML
    from intentiai import Constitution
    const = Constitution.from_yaml("constitution.yaml")
    result = const.check_output("response", input_query="query")
"""

from .types import (
    OutputAction, CheckResult, OutputGateResult,
    InputAction, InputGateResult,
)
from .config import (
    OutputGateConfig, PIIConfig, PromptLeakageConfig, PolicyConfig,
    ContentSafetyConfig, TopicDriftConfig,
    InputGateConfig, InjectionConfig, OOSConfig,
)
from .output_gate import OutputGate
from .input_gate import InputGate
from .gate import IntentiAI
from .constitution import Constitution, ConstitutionError

__version__ = "1.0.0"
__all__ = [
    # Unified
    "IntentiAI",
    # Input gate
    "InputGate", "InputAction", "InputGateResult", "InputGateConfig",
    "InjectionConfig", "OOSConfig",
    # Output gate
    "OutputGate", "OutputGateConfig", "OutputAction", "CheckResult", "OutputGateResult",
    "PIIConfig", "PromptLeakageConfig", "PolicyConfig", "ContentSafetyConfig", "TopicDriftConfig",
    # Constitution
    "Constitution", "ConstitutionError",
]
