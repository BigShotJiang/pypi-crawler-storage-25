"""IntentiAI Input Gate — validates user queries before they reach the LLM.

Pipeline:
  1. DeBERTa forward pass (~32ms) -> logits, embedding
  2. ADB OOS score (<1ms) -> oos_score, nearest_class
  3. Intent confidence pre-filter (<1ms)
  4. Injection ensemble (~35ms, skipped if conf > 0.90) -> injection_score
  5. Gate decision: BLOCK / ESCALATE / ALLOW

Usage:
    from intentiai import InputGate

    gate = InputGate.from_artifacts("gate_artifacts/")
    result = gate.check("Transfer $500 to John")
    print(result.action, result.intent, result.confidence)
"""

import os
import json
import time
import numpy as np
from typing import Optional

from .types import InputAction, InputGateResult
from .config import InputGateConfig
from .encoder import compute_intent_confidence
from .oos import adb_oos_score
from .injection import InjectionEnsemble


class InputGate:
    """Validates user queries through intent + OOS + injection detection."""

    def __init__(self, config: InputGateConfig = None):
        self.config = config or InputGateConfig()

        # Artifacts (loaded from files)
        self._centroids = None
        self._radii = None
        self._oos_threshold = 0.0
        self._inj_threshold = 0.90
        self._label_names = {}
        self._num_classes = 0
        self._artifacts_dir = None

        # Lazy-loaded models
        self._encoder = None
        self._tokenizer = None
        self._device = None
        self._injection = InjectionEnsemble(self.config.injection) if self.config.injection.enabled else None

    @classmethod
    def from_artifacts(cls, artifacts_dir: str, config: InputGateConfig = None) -> "InputGate":
        """Load from pre-trained artifacts directory.

        Expected files:
          - deberta_finetuned.pt (fine-tuned encoder weights)
          - adb.npz (centroids + radii)
          - gate_config.json (thresholds, label maps)
        """
        config = config or InputGateConfig()
        gate = cls(config=config)
        gate._artifacts_dir = artifacts_dir

        # Load gate_config.json
        config_path = os.path.join(artifacts_dir, "gate_config.json")
        with open(config_path, "r") as f:
            gate_cfg = json.load(f)

        gate._num_classes = gate_cfg["num_classes"]
        gate_section = gate_cfg.get("gate", {})
        gate._oos_threshold = gate_section.get("oos_threshold", 0.0)
        gate._inj_threshold = gate_section.get("inj_threshold", 0.90)
        gate._label_names = {int(k): v for k, v in gate_cfg.get("label_names", {}).items()}

        # Override config from artifacts
        gate.config.encoder_name = gate_cfg.get("encoder", gate.config.encoder_name)
        gate.config.max_length = gate_cfg.get("max_length", gate.config.max_length)

        # Load ADB artifacts (small numpy arrays, load immediately)
        adb_data = np.load(os.path.join(artifacts_dir, "adb.npz"))
        gate._centroids = adb_data["centroids"]
        gate._radii = adb_data["radii"]

        return gate

    def _ensure_encoder(self):
        """Lazy-load the DeBERTa encoder on first check() call."""
        if self._encoder is not None:
            return
        import torch
        from transformers import AutoTokenizer
        from .encoder import DeBERTaEncoder

        self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._tokenizer = AutoTokenizer.from_pretrained(self.config.encoder_name)
        self._encoder = DeBERTaEncoder.from_artifacts(
            self._artifacts_dir, self._num_classes,
            self.config.encoder_name, self._device
        )

    def check(self, query: str) -> InputGateResult:
        """Run the full input gate pipeline on a single query."""
        import torch
        t0 = time.perf_counter()

        try:
            self._ensure_encoder()

            # Step 1: DeBERTa forward pass
            enc = self._tokenizer(
                query, max_length=self.config.max_length,
                padding="max_length", truncation=True, return_tensors="pt"
            )
            with torch.no_grad():
                logits, cls_emb = self._encoder(
                    enc["input_ids"].to(self._device),
                    enc["attention_mask"].to(self._device),
                )

            logits_np = logits.cpu().numpy()
            emb_np = cls_emb.cpu().numpy()  # (1, 768)

            # Step 2: ADB OOS score
            if self.config.oos.enabled and self._centroids is not None:
                oos_scores, nearest = adb_oos_score(emb_np, self._centroids, self._radii)
                oos_score = float(oos_scores[0])
                nearest_class = int(nearest[0])
            else:
                oos_score = 0.0
                nearest_class = int(logits_np.argmax(axis=1)[0])

            # Step 3: Intent confidence
            intent_conf = float(compute_intent_confidence(logits_np)[0])
            intent_name = self._label_names.get(nearest_class, f"class_{nearest_class}")

            # Step 4: Injection ensemble (with pre-filter)
            injection_score = 0.0
            if self._injection:
                injection_score = self._injection.check_single(query, intent_conf)

            # Step 5: Gate decision
            if injection_score > self._inj_threshold:
                action = InputAction.BLOCK
            elif oos_score >= self._oos_threshold:
                action = InputAction.ESCALATE
            else:
                action = InputAction.ALLOW

            return InputGateResult(
                action=action,
                intent=intent_name if action == InputAction.ALLOW else None,
                intent_id=nearest_class,
                confidence=intent_conf,
                oos_score=oos_score,
                injection_score=injection_score,
                embedding=emb_np.flatten(),
                latency_ms=(time.perf_counter() - t0) * 1000,
            )

        except Exception as e:
            latency = (time.perf_counter() - t0) * 1000
            action = InputAction.ALLOW if self.config.fail_open else InputAction.ESCALATE
            return InputGateResult(
                action=action, latency_ms=latency,
                details={"error": str(e)},
            )

    @property
    def encoder(self):
        """The underlying DeBERTa encoder (for sharing with output gate)."""
        self._ensure_encoder()
        return self._encoder

    @property
    def raw_encoder(self):
        """The inner AutoModel (for TopicDriftChecker compatibility)."""
        self._ensure_encoder()
        return self._encoder.encoder

    @property
    def tokenizer(self):
        self._ensure_encoder()
        return self._tokenizer
