"""IntentiAI Constitution — YAML-based policy engine.

Define what your AI can and cannot do in a YAML file. We enforce it.

Usage:
    from intentiai import Constitution

    const = Constitution.from_yaml("constitution.yaml")
    result = const.check_output("LLM response", input_query="user query")
    const.reload()  # hot-reload after editing YAML
"""

import re
import warnings
from typing import Optional, List
import numpy as np

from .types import OutputAction, OutputGateResult
from .config import (
    OutputGateConfig, PIIConfig, PromptLeakageConfig,
    PolicyConfig, ContentSafetyConfig, TopicDriftConfig,
)
from .output_gate import OutputGate


class ConstitutionError(Exception):
    """Raised when a constitution file is invalid."""
    pass


# Known behavioral rules mapped to checker config actions
_BEHAVIORAL_KEYWORDS = {
    "system prompt": ("leakage", None),
    "reveal system": ("leakage", None),
    "reveal instruction": ("leakage", None),
    "medical advice": ("topic", "medical_advice"),
    "legal advice": ("topic", "legal_advice"),
    "financial advice": ("topic", "financial_advice"),
    "financial decision": ("topic", "financial_advice"),
}


def _parse_rewrite(rule_value: str) -> dict:
    """Parse a rewrite rule like 'add_disclaimer("text")'."""
    match = re.match(r'(\w+)\("(.+?)"\)', rule_value)
    if not match:
        raise ConstitutionError(f"Invalid rewrite syntax: {rule_value}. Expected: action(\"text\")")
    return {"action": match.group(1), "text": match.group(2)}


def _apply_behavioral_rules(rules: List[str], leakage_enabled: list,
                            forbidden_topics: list) -> List[str]:
    """Map behavioral rules to checker configs. Returns unmapped rules."""
    unmapped = []
    for rule in rules:
        rule_lower = rule.lower().strip()
        matched = False
        for keyword, (check_type, topic) in _BEHAVIORAL_KEYWORDS.items():
            if keyword in rule_lower:
                if check_type == "leakage":
                    leakage_enabled.append(True)
                elif check_type == "topic" and topic:
                    if topic not in forbidden_topics:
                        forbidden_topics.append(topic)
                matched = True
                break
        if not matched:
            unmapped.append(rule)
    return unmapped


def _build_output_config(output_rules: list, behavioral_rules: list,
                         system_prompt: str = "", competitors: list = None,
                         settings: dict = None) -> tuple:
    """Build OutputGateConfig from YAML rules. Returns (config, disclaimers, warnings)."""
    settings = settings or {}
    competitors = competitors or []
    warns = []

    # Start with everything disabled
    pii_action = settings.get("pii_action", "REJECT")
    pii_enabled = False
    leakage_enabled = []
    forbidden_topics = []
    forbidden_keywords = list(competitors)  # competitors always added if present
    forbidden_patterns = []
    safety_enabled = False
    drift_enabled = False
    disclaimers = []

    # Parse output_rules
    for rule in output_rules:
        if isinstance(rule, dict):
            if "block" in rule:
                target = rule["block"]
                if target == "contains_pii":
                    pii_enabled = True
                    pii_action = "REJECT"
                elif target == "redact_pii":
                    pii_enabled = True
                    pii_action = "REDACT"
                elif target in ("medical_advice", "legal_advice", "financial_advice"):
                    if target not in forbidden_topics:
                        forbidden_topics.append(target)
                elif target == "competitor_mention":
                    # Keywords already loaded from competitors list
                    if not competitors:
                        warns.append("'block: competitor_mention' used but no 'competitors' list defined in YAML")
                elif target == "prompt_leakage":
                    leakage_enabled.append(True)
                elif target == "toxic_content":
                    safety_enabled = True
                elif target == "topic_drift":
                    drift_enabled = True
                else:
                    # Unknown block target → add as forbidden keyword
                    forbidden_keywords.append(target)
                    warns.append(f"Unknown block target '{target}' — added as forbidden keyword")

            elif "rewrite" in rule:
                try:
                    disclaimers.append(_parse_rewrite(rule["rewrite"]))
                except ConstitutionError as e:
                    warns.append(str(e))

            elif "escalate" in rule or "route" in rule:
                # Input gate rules in output section — warn
                warns.append(f"Rule '{rule}' is an input gate rule in output_rules section")

    # Apply behavioral rules
    unmapped = _apply_behavioral_rules(behavioral_rules, leakage_enabled, forbidden_topics)
    for rule in unmapped:
        warns.append(f"Behavioral rule not mapped to any checker: '{rule}' (will be enforced via NLI in future)")

    # Build system prompt fragments for leakage detection
    fragments = []
    if system_prompt:
        # Split on sentences, use chunks of 5+ words as fragments
        sentences = re.split(r'[.!?]+', system_prompt)
        fragments = [s.strip() for s in sentences if len(s.strip().split()) >= 4]

    # Build configs
    pii = PIIConfig(enabled=pii_enabled, action=pii_action,
                    redaction_string=settings.get("redaction_string", "[REDACTED]"))
    leakage = PromptLeakageConfig(enabled=bool(leakage_enabled),
                                   system_prompt_fragments=fragments)
    policy = PolicyConfig(
        enabled=bool(forbidden_topics or forbidden_keywords or forbidden_patterns),
        forbidden_topics=forbidden_topics,
        forbidden_keywords=forbidden_keywords,
        forbidden_patterns=forbidden_patterns,
    )
    safety = ContentSafetyConfig(
        enabled=safety_enabled,
        toxicity_threshold=settings.get("toxicity_threshold", 0.5),
    )
    drift = TopicDriftConfig(
        enabled=drift_enabled,
        similarity_threshold=settings.get("drift_threshold", 0.25),
    )

    config = OutputGateConfig(
        pii=pii, prompt_leakage=leakage, policy=policy,
        content_safety=safety, topic_drift=drift,
        fail_open=settings.get("fail_open", False),
    )

    return config, disclaimers, warns


class Constitution:
    """YAML-based policy engine for IntentiAI.

    Parses a YAML constitution file and enforces the rules via the output gate.
    """

    def __init__(self, name: str, version: int, output_gate: OutputGate,
                 disclaimers: list, input_rules: list, behavioral_rules: list,
                 unmapped_warnings: list, yaml_path: str = None, raw: dict = None):
        self.name = name
        self.version = version
        self._output_gate = output_gate
        self._disclaimers = disclaimers
        self._input_rules = input_rules
        self._behavioral_rules = behavioral_rules
        self._warnings = unmapped_warnings
        self._yaml_path = yaml_path
        self._raw = raw or {}

    @classmethod
    def from_yaml(cls, path: str) -> "Constitution":
        """Load a constitution from a YAML file."""
        try:
            import yaml
        except ImportError:
            raise ConstitutionError("pyyaml is required: pip install pyyaml")

        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
        except Exception as e:
            raise ConstitutionError(f"Failed to parse YAML: {e}")

        const = cls.from_dict(data)
        const._yaml_path = path
        return const

    @classmethod
    def from_dict(cls, data: dict) -> "Constitution":
        """Build a constitution from a dictionary (parsed YAML)."""
        if not isinstance(data, dict):
            raise ConstitutionError("Constitution data must be a dictionary")

        name = data.get("name")
        version = data.get("version")
        if not name:
            raise ConstitutionError("Constitution must have a 'name' field")
        if not version:
            raise ConstitutionError("Constitution must have a 'version' field")

        output_rules = data.get("output_rules", [])
        input_rules = data.get("input_rules", [])
        behavioral_rules = data.get("behavioral_rules", [])
        system_prompt = data.get("system_prompt", "")
        competitors = data.get("competitors", [])
        settings = data.get("settings", {})

        config, disclaimers, warns = _build_output_config(
            output_rules, behavioral_rules, system_prompt, competitors, settings
        )

        for w in warns:
            warnings.warn(f"Constitution '{name}': {w}")

        gate = OutputGate(config=config)

        return cls(
            name=name, version=version, output_gate=gate,
            disclaimers=disclaimers, input_rules=input_rules,
            behavioral_rules=behavioral_rules,
            unmapped_warnings=warns, raw=data,
        )

    def check_output(self, response_text: str, input_query: str = "",
                     input_embedding: Optional[np.ndarray] = None) -> OutputGateResult:
        """Check an LLM response against the constitution's output rules."""
        result = self._output_gate.check(response_text, input_query, input_embedding)

        # Apply rewrites (disclaimers) only if the response passed
        if result.passed and self._disclaimers:
            result.response_text = self._apply_rewrites(result.response_text)

        return result

    def check_input(self, query: str):
        """Check a user query against input rules.
        Requires set_artifacts() to be called first.
        """
        if not hasattr(self, '_input_gate') or self._input_gate is None:
            raise RuntimeError(
                "Input gate not configured. Call constitution.set_artifacts('gate_artifacts/') first."
            )
        return self._input_gate.check(query)

    def set_artifacts(self, artifacts_dir: str):
        """Load input gate artifacts for check_input() support."""
        from .input_gate import InputGate
        self._input_gate = InputGate.from_artifacts(artifacts_dir)

    def reload(self):
        """Re-read the YAML file and rebuild the gate."""
        if self._yaml_path is None:
            raise ConstitutionError("Cannot reload: Constitution was not loaded from a file")
        new = Constitution.from_yaml(self._yaml_path)
        self.__dict__.update(new.__dict__)

    def _apply_rewrites(self, text: str) -> str:
        """Apply rewrite rules (disclaimers) to the response text."""
        for rewrite in self._disclaimers:
            if rewrite["action"] == "add_disclaimer":
                text = text.rstrip() + "\n\n" + rewrite["text"]
        return text

    @property
    def info(self) -> dict:
        """Get constitution metadata."""
        return {
            "name": self.name,
            "version": self.version,
            "output_rules": len(self._raw.get("output_rules", [])),
            "input_rules": len(self._input_rules),
            "behavioral_rules": len(self._behavioral_rules),
            "disclaimers": len(self._disclaimers),
            "warnings": self._warnings,
        }

    def __repr__(self):
        return f"Constitution(name='{self.name}', version={self.version})"
