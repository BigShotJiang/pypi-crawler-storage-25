"""IntentiAI — The unified AI Safety Gate.

Combines input gate + output gate into one deployable system.

Usage:
    from intentiai import IntentiAI

    gate = IntentiAI.from_artifacts("gate_artifacts/")

    # Check input
    result = gate.check_input("Transfer $500 to John")

    # Check output
    result = gate.check_output("Transfer initiated", input_query="Transfer $500")

    # Full sandwich: input -> LLM -> output
    @gate.enforce
    def chat(message):
        return call_llm(message)
"""

import functools
from typing import Callable, Optional

from .types import InputAction, InputGateResult, OutputAction, OutputGateResult
from .config import InputGateConfig, OutputGateConfig
from .input_gate import InputGate
from .output_gate import OutputGate


class IntentiAI:
    """Unified input + output safety gate."""

    def __init__(self, input_gate: InputGate = None, output_gate: OutputGate = None):
        self._input_gate = input_gate
        self._output_gate = output_gate

    @classmethod
    def from_artifacts(cls, artifacts_dir: str,
                       input_config: InputGateConfig = None,
                       output_config: OutputGateConfig = None) -> "IntentiAI":
        """Load from pre-trained artifacts directory.

        The DeBERTa encoder is shared: loaded once by InputGate,
        passed to OutputGate's TopicDriftChecker.
        """
        input_gate = InputGate.from_artifacts(artifacts_dir, input_config)
        output_config = output_config or OutputGateConfig()

        # Share encoder with output gate's topic drift checker
        output_gate = OutputGate(
            config=output_config,
            encoder=input_gate.raw_encoder,
            tokenizer=input_gate.tokenizer,
        )

        return cls(input_gate=input_gate, output_gate=output_gate)

    @classmethod
    def from_constitution(cls, yaml_path: str,
                          artifacts_dir: str = None) -> "IntentiAI":
        """Load from a YAML constitution file.

        If artifacts_dir is provided, also loads the input gate.
        """
        from .constitution import Constitution
        const = Constitution.from_yaml(yaml_path)

        input_gate = None
        if artifacts_dir:
            input_gate = InputGate.from_artifacts(artifacts_dir)

        return cls(input_gate=input_gate, output_gate=const._output_gate)

    def check_input(self, query: str) -> InputGateResult:
        """Check a user query through the input gate."""
        if self._input_gate is None:
            raise RuntimeError(
                "Input gate not configured. Use IntentiAI.from_artifacts() "
                "or provide artifacts_dir to from_constitution()."
            )
        return self._input_gate.check(query)

    def check_output(self, response_text: str, input_query: str = "",
                     input_embedding=None) -> OutputGateResult:
        """Check an LLM response through the output gate."""
        if self._output_gate is None:
            raise RuntimeError("Output gate not configured.")
        return self._output_gate.check(response_text, input_query, input_embedding)

    def check(self, query: str, response_text: str) -> dict:
        """Run both gates. Returns dict with input_result and output_result."""
        input_result = self.check_input(query)
        output_result = None

        if input_result.action == InputAction.ALLOW:
            output_result = self.check_output(
                response_text,
                input_query=query,
                input_embedding=input_result.embedding,
            )

        final_action = input_result.action.value
        if input_result.action == InputAction.ALLOW and output_result:
            final_action = output_result.action.value

        return {
            "input": input_result,
            "output": output_result,
            "action": final_action,
        }

    def enforce(self, fn: Callable = None, *,
                block_message: str = "I cannot process that request.",
                escalate_message: str = "Let me connect you with a human agent."):
        """Decorator: input gate -> fn() -> output gate.

        @gate.enforce
        def chat(message: str) -> str:
            return call_llm(message)
        """
        def decorator(func):
            @functools.wraps(func)
            def wrapper(message: str, *args, **kwargs):
                # Input gate
                if self._input_gate:
                    input_result = self._input_gate.check(message)
                    if input_result.action == InputAction.BLOCK:
                        return block_message
                    if input_result.action == InputAction.ESCALATE:
                        return escalate_message
                    input_embedding = input_result.embedding
                else:
                    input_embedding = None

                # Call the LLM
                response = func(message, *args, **kwargs)

                # Output gate
                if self._output_gate:
                    output_result = self._output_gate.check(
                        response, input_query=message,
                        input_embedding=input_embedding,
                    )
                    if output_result.action == OutputAction.REJECT:
                        return block_message
                    return output_result.response_text

                return response
            return wrapper

        if fn is not None:
            return decorator(fn)
        return decorator
