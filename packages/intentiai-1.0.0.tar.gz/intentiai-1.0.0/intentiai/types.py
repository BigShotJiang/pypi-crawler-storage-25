"""Core types for IntentiAI gate decisions."""

from enum import Enum
from dataclasses import dataclass, field
from typing import Optional
import numpy as np


# ─── Output Gate Types ───

class OutputAction(Enum):
    """Output gate decision. Severity: PASS < REDACT < REJECT."""
    PASS = "PASS"
    REDACT = "REDACT"
    REJECT = "REJECT"

    def __lt__(self, other):
        order = {OutputAction.PASS: 0, OutputAction.REDACT: 1, OutputAction.REJECT: 2}
        return order[self] < order[other]

    def __gt__(self, other):
        return other.__lt__(self)


@dataclass
class CheckResult:
    """Result from a single output gate check."""
    check_name: str
    passed: bool
    action: OutputAction
    details: dict = field(default_factory=dict)


@dataclass
class OutputGateResult:
    """Aggregated result from all output gate checks."""
    action: OutputAction
    response_text: str
    checks: list = field(default_factory=list)
    latency_ms: float = 0.0

    @property
    def passed(self) -> bool:
        return self.action == OutputAction.PASS


# ─── Input Gate Types ───

class InputAction(Enum):
    """Input gate decision. Severity: ALLOW < ESCALATE < BLOCK."""
    ALLOW = "ALLOW"
    ESCALATE = "ESCALATE"
    BLOCK = "BLOCK"

    def __lt__(self, other):
        order = {InputAction.ALLOW: 0, InputAction.ESCALATE: 1, InputAction.BLOCK: 2}
        return order[self] < order[other]

    def __gt__(self, other):
        return other.__lt__(self)


@dataclass
class InputGateResult:
    """Result from the input gate."""
    action: InputAction
    intent: Optional[str] = None
    intent_id: Optional[int] = None
    confidence: float = 0.0
    oos_score: float = 0.0
    injection_score: float = 0.0
    embedding: Optional[np.ndarray] = None
    latency_ms: float = 0.0
    details: dict = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        return self.action == InputAction.ALLOW
