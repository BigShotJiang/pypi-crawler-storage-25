"""Prompt injection detection ensemble.

4-model architecturally diverse ensemble + 19 regex heuristic patterns.
Models are lazy-loaded on first call to check().
"""

import re
import warnings
import numpy as np
from typing import List, Optional
from .config import InjectionConfig


INJECTION_PATTERNS = [
    r"ignore\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions|prompts|rules|directives)",
    r"disregard\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions|prompts|rules)",
    r"forget\s+(all\s+)?(previous|prior|your)\s+(instructions|prompts|rules|training)",
    r"(reveal|show|display|print|output)\s+(your\s+)?(system\s*prompt|instructions|original\s*prompt)",
    r"you\s+are\s+now\s+(a|an|the|DAN|unrestricted|unfiltered)",
    r"act\s+as\s+(a|an|if|though)\s+",
    r"pretend\s+(to\s+be|you\s+are|that)",
    r"\bDAN\b.*\b(mode|anything|now)\b",
    r"\bjailbreak\b",
    r"developer\s+mode",
    r"(no|without)\s+(restrictions|limitations|filters|rules|boundaries)",
    r"bypass\s+(your|all|the|any)\s+(safety|content|ethical|restrictions|filters)",
    r"override\s+(your|all|the|any)\s+(safety|instructions|programming|rules)",
    r"new\s+(instructions|rules|role|persona|identity)",
    r"from\s+now\s+on\s+(you|ignore|act|behave|respond)",
    r"do\s+not\s+follow\s+(your|any|the)\s+(rules|instructions|guidelines)",
    r"(base64|rot13|hex|morse)\s*(encode|decode|convert)",
    r"repeat\s+after\s+me",
    r"what\s+(is|are)\s+your\s+(system|initial|original)\s+(prompt|instructions|message)",
]
_compiled_patterns = [re.compile(p, re.IGNORECASE) for p in INJECTION_PATTERNS]


def regex_injection_check(texts: List[str]) -> np.ndarray:
    """Returns 1.0 if any regex pattern matches, 0.0 otherwise."""
    results = np.zeros(len(texts))
    for i, text in enumerate(texts):
        for pat in _compiled_patterns:
            if pat.search(text):
                results[i] = 1.0
                break
    return results


class InjectionEnsemble:
    """4-model ensemble + regex for injection detection. Lazy-loaded."""

    def __init__(self, config: InjectionConfig = None):
        self.config = config or InjectionConfig()
        self._models = []
        self._loaded = False
        self._device = None

    def _ensure_models(self):
        if self._loaded:
            return
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        for name in self.config.models:
            try:
                m = AutoModelForSequenceClassification.from_pretrained(
                    name, trust_remote_code=True
                ).to(self._device)
                tk = AutoTokenizer.from_pretrained(name, trust_remote_code=True)
                m.eval()
                self._models.append((name, m, tk, m.config.num_labels))
            except Exception as e:
                warnings.warn(f"Failed to load injection model {name}: {str(e)[:80]}")
        self._loaded = True

    def _run_single(self, model, tokenizer, texts, n_labels, batch_size=32):
        """Run one model, returns P(malicious) per text."""
        import torch
        model.eval()
        all_probs = []
        for i in range(0, len(texts), batch_size):
            enc = tokenizer(texts[i:i+batch_size], max_length=512, padding=True,
                            truncation=True, return_tensors="pt")
            with torch.no_grad():
                logits = model(input_ids=enc["input_ids"].to(self._device),
                               attention_mask=enc["attention_mask"].to(self._device)).logits
            probs = torch.softmax(logits, dim=-1).cpu().numpy()
            if n_labels == 3:
                mal = probs[:, 1] + probs[:, 2]
            else:
                mal = probs[:, 1]
            all_probs.append(mal)
        return np.concatenate(all_probs)

    def check(self, texts: List[str],
              intent_confidences: Optional[np.ndarray] = None) -> np.ndarray:
        """Compute injection scores. Pre-filter zeros high-confidence intents.

        Args:
            texts: list of queries
            intent_confidences: (N,) softmax confidence. If > prefilter threshold, skip ML.

        Returns:
            (N,) injection probabilities [0, 1].
        """
        scores = np.zeros(len(texts))

        # Regex layer (always runs)
        if self.config.regex_enabled:
            scores = regex_injection_check(texts)

        # Pre-filter: which texts need ML?
        if intent_confidences is not None:
            need_ml = intent_confidences <= self.config.intent_confidence_prefilter
        else:
            need_ml = np.ones(len(texts), dtype=bool)

        # ML models
        if need_ml.any() and self.config.models:
            self._ensure_models()
            ml_texts = [texts[i] for i in range(len(texts)) if need_ml[i]]
            ml_idx = np.where(need_ml)[0]

            for name, model, tok, nl in self._models:
                probs = self._run_single(model, tok, ml_texts, nl)
                scores[ml_idx] = np.maximum(scores[ml_idx], probs)

        # Zero out pre-filtered texts
        if intent_confidences is not None:
            scores[~need_ml] = 0.0

        return scores

    def check_single(self, text: str, intent_confidence: float = 0.0) -> float:
        """Check a single text. Returns injection probability."""
        confs = np.array([intent_confidence]) if intent_confidence > 0 else None
        return float(self.check([text], confs)[0])

    @property
    def loaded_models(self) -> List[str]:
        """Names of successfully loaded models."""
        return [name for name, _, _, _ in self._models]
