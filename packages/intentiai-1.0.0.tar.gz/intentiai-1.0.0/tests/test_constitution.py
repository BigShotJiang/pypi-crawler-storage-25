"""Tests for the YAML constitution engine."""

import os
import pytest
from intentiai import Constitution, ConstitutionError, OutputAction


EXAMPLE_YAML = os.path.join(os.path.dirname(__file__), "..", "examples", "banking_constitution.yaml")


def test_load_from_yaml():
    const = Constitution.from_yaml(EXAMPLE_YAML)
    assert const.name == "Banking Assistant"
    assert const.version == 1


def test_from_dict():
    const = Constitution.from_dict({
        "name": "Test Bot",
        "version": 1,
        "output_rules": [{"block": "contains_pii"}],
    })
    r = const.check_output("SSN: 123-45-6789")
    assert r.action == OutputAction.REJECT


def test_missing_name_raises():
    with pytest.raises(ConstitutionError):
        Constitution.from_dict({"version": 1})


def test_missing_version_raises():
    with pytest.raises(ConstitutionError):
        Constitution.from_dict({"name": "Bot"})


def test_empty_dict_raises():
    with pytest.raises(ConstitutionError):
        Constitution.from_dict({})


def test_competitor_keyword_blocked():
    const = Constitution.from_dict({
        "name": "Bot", "version": 1,
        "competitors": ["Chase", "Wells Fargo"],
        "output_rules": [{"block": "competitor_mention"}],
    })
    r = const.check_output("Chase offers better rates")
    assert r.action == OutputAction.REJECT


def test_disclaimer_appended():
    const = Constitution.from_dict({
        "name": "Bot", "version": 1,
        "output_rules": [{"rewrite": 'add_disclaimer("Not financial advice.")'}],
    })
    r = const.check_output("Your balance is $100")
    assert r.passed
    assert "Not financial advice." in r.response_text


def test_info_property():
    const = Constitution.from_yaml(EXAMPLE_YAML)
    info = const.info
    assert info["name"] == "Banking Assistant"
    assert info["output_rules"] > 0


def test_repr():
    const = Constitution.from_dict({"name": "Bot", "version": 2, "output_rules": []})
    assert "Bot" in repr(const)
    assert "2" in repr(const)
