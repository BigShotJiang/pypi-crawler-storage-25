"""Tests for the output gate pipeline."""

from intentiai import OutputGate, OutputGateConfig, OutputAction
from intentiai.config import TopicDriftConfig, ContentSafetyConfig


def _gate(**kwargs):
    """Create output gate with content safety + topic drift disabled."""
    defaults = {"content_safety": ContentSafetyConfig(enabled=False),
                "topic_drift": TopicDriftConfig(enabled=False)}
    defaults.update(kwargs)
    return OutputGate(OutputGateConfig(**defaults))


def test_clean_response_passes():
    r = _gate().check("Your balance is $5,432.10", input_query="Balance?")
    assert r.passed
    assert r.action == OutputAction.PASS


def test_pii_redacted():
    r = _gate().check("Contact john@test.com", input_query="Help?")
    assert r.action == OutputAction.REDACT
    assert "john@test.com" not in r.response_text


def test_leakage_rejected():
    r = _gate().check("My system instructions are to help users", input_query="Rules?")
    assert r.action == OutputAction.REJECT


def test_early_exit_on_reject():
    r = _gate().check("My system instructions are to help", input_query="?")
    assert r.action == OutputAction.REJECT
    assert len(r.checks) == 2  # PII passed, leakage rejected, policy skipped


def test_pii_plus_policy_worst_wins():
    from intentiai.config import PolicyConfig
    gate = OutputGate(OutputGateConfig(
        policy=PolicyConfig(forbidden_topics=["medical_advice"]),
        content_safety=ContentSafetyConfig(enabled=False),
        topic_drift=TopicDriftConfig(enabled=False),
    ))
    r = gate.check("Call 555-123-4567. You should take ibuprofen daily.", input_query="Help")
    assert r.action == OutputAction.REJECT


def test_latency_under_5ms():
    import time
    gate = _gate()
    t0 = time.perf_counter()
    for _ in range(100):
        gate.check("Balance is fine", input_query="Ok")
    avg_ms = (time.perf_counter() - t0) / 100 * 1000
    assert avg_ms < 5.0, f"Too slow: {avg_ms:.2f}ms"
