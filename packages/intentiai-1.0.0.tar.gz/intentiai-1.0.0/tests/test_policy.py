"""Tests for policy compliance checker."""

from intentiai.checks.policy import PolicyChecker
from intentiai.config import PolicyConfig


def test_medical_advice_blocked():
    pc = PolicyChecker(PolicyConfig(forbidden_topics=["medical_advice"]))
    assert not pc.check("You should take 500mg ibuprofen").passed


def test_legal_advice_blocked():
    pc = PolicyChecker(PolicyConfig(forbidden_topics=["legal_advice"]))
    assert not pc.check("You should sue for damages").passed


def test_financial_advice_blocked():
    pc = PolicyChecker(PolicyConfig(forbidden_topics=["financial_advice"]))
    assert not pc.check("You should buy Bitcoin, going to moon").passed


def test_clean_banking_passes():
    pc = PolicyChecker(PolicyConfig(forbidden_topics=["medical_advice"]))
    assert pc.check("Your account has been credited").passed


def test_keyword_blocked():
    pc = PolicyChecker(PolicyConfig(forbidden_keywords=["CompetitorBank"]))
    assert not pc.check("CompetitorBank offers better rates").passed


def test_keyword_clean_passes():
    pc = PolicyChecker(PolicyConfig(forbidden_keywords=["CompetitorBank"]))
    assert pc.check("We offer the best rates").passed


def test_custom_regex():
    pc = PolicyChecker(PolicyConfig(forbidden_patterns=[r"password\s+is\s+\S+"]))
    assert not pc.check("Your password is abc123").passed
    assert pc.check("Create a new password").passed


def test_combined_rules():
    pc = PolicyChecker(PolicyConfig(
        forbidden_topics=["medical_advice"],
        forbidden_keywords=["CompetitorBank"],
        forbidden_patterns=[r"internal\s+use\s+only"],
    ))
    r = pc.check("internal use only mentions CompetitorBank")
    assert not r.passed
    assert r.details["count"] >= 2
