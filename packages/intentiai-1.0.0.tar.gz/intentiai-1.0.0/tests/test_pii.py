"""Tests for PII detection and redaction."""

from intentiai.checks.pii import PIIChecker, _luhn_check
from intentiai.config import PIIConfig
from intentiai.types import OutputAction


def test_email_detected():
    r = PIIChecker().check("Contact support@bank.com")
    assert not r.passed
    assert any(f["type"] == "email" for f in r.details["found"])


def test_no_false_email():
    assert PIIChecker().check("SMTP protocol is used").passed


def test_phone_detected():
    r = PIIChecker().check("Call 555-123-4567")
    assert not r.passed
    assert any(f["type"] == "phone" for f in r.details["found"])


def test_ssn_detected():
    r = PIIChecker().check("SSN: 123-45-6789")
    assert not r.passed
    assert any(f["type"] == "ssn" for f in r.details["found"])


def test_luhn_valid():
    assert _luhn_check("4111111111111111")


def test_luhn_invalid():
    assert not _luhn_check("1234567890123456")


def test_credit_card_detected():
    r = PIIChecker().check("Card: 4111 1111 1111 1111")
    assert not r.passed
    assert any(f["type"] == "credit_card" for f in r.details["found"])


def test_ip_detected():
    r = PIIChecker().check("Server at 192.168.1.100")
    assert not r.passed
    assert any(f["type"] == "ip_address" for f in r.details["found"])


def test_clean_text_passes():
    assert PIIChecker().check("Your balance is $5,432.10").passed


def test_redaction():
    config = PIIConfig(action="REDACT", redaction_string="***")
    r = PIIChecker(config).check("Email: a@b.com Phone: 555-111-2222")
    assert "***" in r.details["redacted_text"]
    assert "a@b.com" not in r.details["redacted_text"]


def test_multiple_pii():
    r = PIIChecker().check("Email: j@t.com, SSN: 111-22-3333, Phone: 555-999-8888")
    assert len(r.details["types"]) >= 3
