from .client import AutoDataClient, AutoDataError

__version__ = "0.3.0"
__all__ = ["AutoDataClient", "AutoDataError", "__version__"]
