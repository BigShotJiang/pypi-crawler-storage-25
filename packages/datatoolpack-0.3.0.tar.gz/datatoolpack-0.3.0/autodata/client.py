"""
AutoData Python Client
======================
Official Python SDK for the AutoData ML data preparation pipeline API.

Usage::

    from autodata import AutoDataClient

    client = AutoDataClient(api_key="dtpk_...", base_url="https://autodata.datatoolpack.com")

    result = client.process(
        file_path="data.csv",
        target_columns=["price"],
        output_rows=20000,
    )
    print(result["files"])
"""

import io
import json
import os
import time
import zipfile
from typing import Dict, List, Optional, Union


try:
    import requests
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "The 'requests' package is required. Install with: pip install requests"
    ) from exc


# File extension → MIME type mapping for all formats the backend accepts
_MIME_TYPES: Dict[str, str] = {
    ".csv": "text/csv",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xls": "application/vnd.ms-excel",
    ".parquet": "application/octet-stream",
    ".json": "application/json",
    ".feather": "application/octet-stream",
    ".orc": "application/octet-stream",
}

_SUPPORTED_EXTENSIONS = set(_MIME_TYPES)

# HTTP status codes that are safe to retry (transient server / rate-limit errors)
_RETRYABLE_STATUS_CODES = {429, 502, 503, 504}


class AutoDataError(Exception):
    """Raised for API errors returned by the AutoData server.

    Attributes:
        status_code: HTTP status code (e.g. 401, 429, 500) or ``None``
                     for non-HTTP errors.
    """

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class AutoDataClient:
    """Client for the AutoData REST API v1.

    All endpoints authenticate with an API key issued from the AutoData
    dashboard.  The key is sent as a ``Bearer`` token in the
    ``Authorization`` header.

    Supported input formats: CSV, XLSX, XLS, Parquet, JSON, Feather, ORC.

    Args:
        api_key:      API key string starting with ``dtpk_``.
        base_url:     Base URL of the AutoData server (no trailing slash).
        timeout:      HTTP request timeout in seconds (default 120).
        max_retries:  Max automatic retries for transient errors
                      (429 / 502 / 503 / 504).  Default 3.

    Usage as a context manager::

        with AutoDataClient(api_key="dtpk_...") as client:
            result = client.process("data.csv", target_columns="price")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        passcode: Optional[str] = None,
        base_url: str = "https://autodata.datatoolpack.com",
        timeout: int = 120,
        max_retries: int = 3,
    ):
        if not api_key and not passcode:
            raise ValueError(
                "Either api_key or passcode is required. "
                "Get your API key from the AutoData dashboard, "
                "or use the access code assigned to your account."
            )
        if api_key and not api_key.startswith("dtpk_"):
            raise ValueError(
                "api_key must start with 'dtpk_'. "
                "Get yours from the AutoData dashboard."
            )
        self.api_key = api_key
        self.passcode = passcode
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._session = requests.Session()
        if api_key:
            self._session.headers.update({"Authorization": f"Bearer {api_key}"})
        elif passcode:
            self._session.headers.update({"X-Passcode": passcode})

    # ------------------------------------------------------------------
    # Context manager & cleanup
    # ------------------------------------------------------------------

    def __enter__(self) -> "AutoDataClient":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP session and release connections."""
        self._session.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self.base_url}/api/v1{path}"

    @staticmethod
    def _detect_mimetype(file_path: str) -> str:
        """Return the MIME type for a supported file extension."""
        ext = os.path.splitext(file_path)[1].lower()
        return _MIME_TYPES.get(ext, "application/octet-stream")

    def _raise_for_error(self, response: requests.Response) -> None:
        """Raise :class:`AutoDataError` if the response indicates failure."""
        if not response.ok:
            try:
                msg = response.json().get("error", response.text)
            except Exception:
                msg = response.text or f"HTTP {response.status_code}"
            raise AutoDataError(msg, status_code=response.status_code)

    def _request(
        self, method: str, url: str, **kwargs
    ) -> requests.Response:
        """Send an HTTP request with automatic retry on transient errors.

        Retries on 429 (rate-limit) and 502/503/504 (server hiccup) up to
        ``self.max_retries`` times with exponential back-off.  Honours the
        ``Retry-After`` header when present.
        """
        kwargs.setdefault("timeout", self.timeout)
        last_exc: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                response = self._session.request(method, url, **kwargs)
                if response.status_code not in _RETRYABLE_STATUS_CODES:
                    return response
                if attempt == self.max_retries:
                    return response  # let caller handle the error
                retry_after = int(response.headers.get("Retry-After", 0))
                wait = max(retry_after, 2 ** attempt)
            except requests.ConnectionError as exc:
                last_exc = exc
                if attempt == self.max_retries:
                    raise
                wait = 2 ** attempt
            time.sleep(wait)
        # Unreachable in practice, but keeps type checkers happy
        raise last_exc or AutoDataError("Max retries exceeded")  # type: ignore[misc]

    # ------------------------------------------------------------------
    # Core pipeline methods
    # ------------------------------------------------------------------

    def process(
        self,
        file_path: str,
        target_columns: Union[str, List[str]],
        output_rows: int = 10000,
        tools: Optional[Dict[str, bool]] = None,
        advanced_params: Optional[Dict] = None,
        wait: bool = True,
        poll_interval: int = 2,
        download_path: Optional[str] = None,
        auto_download: bool = True,
        output_preferences: Optional[List[str]] = None,
        compressed: bool = True,
    ) -> Dict:
        """Upload a data file and start the AutoData pipeline.

        Supported formats: CSV, XLSX, XLS, Parquet, JSON, Feather, ORC.

        Args:
            file_path:          Path to the input file.
            target_columns:     Target column name(s) for ML (y-columns).
            output_rows:        Desired number of rows in the output dataset.
            tools:              Dict of tool toggles.  Keys: ``anomaly``,
                                ``dtc``, ``mdh``, ``dor``, ``cds``, ``dsm``,
                                ``dsg``.  Standard tools are enabled by
                                default; anomaly and dor are off by default.
            advanced_params:    Fine-grained parameters::

                                    excluded_columns  (list[str])
                                    text_mode         (int: 0=none, 1=neural, 2=tfidf)
                                    text_cleaning     (bool)
                                    zscore_limit      (float, default 3.0)
                                    dsg_mode          (str: 'copula' | 'gan')
                                    similarity_p      (float, default 95)

            wait:               Block until processing completes (default
                                ``True``).
            poll_interval:      Seconds between status polls (default 2).
            download_path:      Directory to save results.  Defaults to
                                ``./auto_data_outputs/<session_id>/``.
            auto_download:      Set to ``False`` to skip downloading results
                                even when *wait* is ``True``.  Default
                                ``True``.
            output_preferences: Subset of filenames to download.  ``None``
                                downloads all files.
            compressed:         Download as a single ZIP archive (default
                                ``True``).

        Returns:
            Dict with ``session_id``, ``status``, and ``files`` list.

        Raises:
            FileNotFoundError:  If *file_path* does not exist.
            ValueError:         If the file format is not supported.
            AutoDataError:      On API errors.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        ext = os.path.splitext(file_path)[1].lower()
        if ext not in _SUPPORTED_EXTENSIONS:
            raise ValueError(
                f"Unsupported file format '{ext}'. "
                f"Supported: {', '.join(sorted(_SUPPORTED_EXTENSIONS))}"
            )

        config = {
            "target_columns": (
                [target_columns] if isinstance(target_columns, str) else target_columns
            ),
            "output_rows": output_rows,
            "tools": tools or {},
            "advanced_params": advanced_params or {},
        }

        mimetype = self._detect_mimetype(file_path)
        with open(file_path, "rb") as f:
            response = self._request(
                "POST",
                self._url("/process"),
                files={"file": (os.path.basename(file_path), f, mimetype)},
                data={"config": json.dumps(config)},
            )
        self._raise_for_error(response)
        result = response.json()
        session_id = result["session_id"]

        if not wait:
            return result

        try:
            final = self.wait_for_completion(
                session_id, poll_interval=poll_interval
            )
        except KeyboardInterrupt:
            print("\nInterrupted — cancelling job on server…")
            self.cancel(session_id)
            raise

        if auto_download:
            self.download_results(
                session_id,
                download_path=download_path,
                output_preferences=output_preferences,
                compressed=compressed,
            )
        return final

    def get_status(self, session_id: str) -> Dict:
        """Poll the processing status of a session.

        Returns:
            Dict with keys: ``status``, ``message``, ``current_step``,
            ``total_steps``, ``progress_percent``, ``duration_seconds``.
        """
        r = self._request("GET", self._url(f"/status/{session_id}"))
        self._raise_for_error(r)
        return r.json()

    def get_result(self, session_id: str) -> Dict:
        """Retrieve the final results of a completed session.

        Returns:
            Dict with keys: ``status``, ``files`` (list of
            ``{name, url, size, description}``), ``row_count``,
            ``duration_seconds``.
        """
        r = self._request("GET", self._url(f"/result/{session_id}"))
        self._raise_for_error(r)
        return r.json()

    def cancel(self, session_id: str) -> bool:
        """Cancel a running or queued session.

        Returns ``True`` if cancellation was acknowledged by the server.
        """
        try:
            r = self._request("POST", self._url(f"/cancel/{session_id}"))
            self._raise_for_error(r)
            return r.json().get("cancelled", False)
        except AutoDataError as e:
            print(f"Warning: cancel failed — {e}")
            return False

    def wait_for_completion(
        self, session_id: str, poll_interval: int = 2
    ) -> Dict:
        """Block until a session reaches *completed*, *error*, or *cancelled*.

        Prints progress updates to stdout.

        Raises:
            AutoDataError: On processing failure or cancellation.
        """
        print(f"Waiting for session {session_id}…")
        while True:
            data = self.get_status(session_id)
            status = data.get("status", "unknown")
            pct = data.get("progress_percent", 0)
            msg = data.get("message", "")

            if status == "completed":
                print(f"\r✓ Completed ({pct}%): {msg}     ")
                return self.get_result(session_id)
            elif status == "error":
                raise AutoDataError(f"Processing failed: {msg}")
            elif status == "cancelled":
                raise AutoDataError("Processing was cancelled")

            print(f"\r  {pct:3d}% — {msg[:60]:<60}", end="", flush=True)
            time.sleep(poll_interval)

    # ------------------------------------------------------------------
    # File download helpers
    # ------------------------------------------------------------------

    def download_results(
        self,
        session_id: str,
        download_path: Optional[str] = None,
        output_preferences: Optional[List[str]] = None,
        compressed: bool = True,
    ) -> str:
        """Download result files for a completed session.

        Args:
            session_id:         Session to download.
            download_path:      Directory to save files (created if needed).
                                Defaults to ``./auto_data_outputs/<session_id>/``.
            output_preferences: Subset of filenames to include.  ``None``
                                downloads everything.
            compressed:         If ``True`` (default), downloads a single ZIP
                                archive and extracts it.  If ``False``,
                                downloads each file individually.

        Returns:
            Absolute path to the download directory.
        """
        if not download_path:
            download_path = os.path.join(
                os.getcwd(), "auto_data_outputs", session_id
            )
        os.makedirs(download_path, exist_ok=True)

        if compressed:
            body: Dict = {}
            if output_preferences:
                body["files"] = output_preferences
            r = self._request(
                "POST",
                self._url(f"/download-archive/{session_id}"),
                json=body,
                timeout=max(self.timeout, 300),
                stream=True,
            )
            self._raise_for_error(r)
            try:
                z = zipfile.ZipFile(io.BytesIO(r.content))
                z.extractall(download_path)
                print(f"Extracted results to {download_path}")
            except zipfile.BadZipFile:
                raise AutoDataError("Server returned an invalid ZIP archive")
        else:
            result = self.get_result(session_id)
            for f in result.get("files", []):
                fname = f["name"]
                if output_preferences and fname not in output_preferences:
                    continue
                self.download_file(
                    self._url(f"/download/{session_id}/{fname}"),
                    os.path.join(download_path, fname),
                )

        return os.path.abspath(download_path)

    def download_file(self, url: str, output_path: str) -> None:
        """Download a single file by URL (absolute or server-relative).

        Args:
            url:         Full URL or path starting with ``/``.
            output_path: Local file path to write to.
        """
        if not url.startswith("http"):
            url = f"{self.base_url}{url}"
        r = self._request(
            "GET", url, stream=True, timeout=max(self.timeout, 300)
        )
        self._raise_for_error(r)
        with open(output_path, "wb") as fh:
            for chunk in r.iter_content(chunk_size=65536):
                fh.write(chunk)
        print(f"Downloaded to {output_path}")

    # ------------------------------------------------------------------
    # Account / API key management
    # ------------------------------------------------------------------

    def list_keys(self) -> List[Dict]:
        """List all active API keys for the authenticated account.

        Returns:
            List of key metadata dicts (no secret values exposed).
        """
        r = self._request("GET", self._url("/keys"))
        self._raise_for_error(r)
        return r.json().get("api_keys", [])

    def get_usage(self) -> Dict:
        """Get credit usage statistics for the current API key.

        Returns:
            Dict with ``daily_credits_used``, ``daily_credit_limit``,
            ``daily_remaining``, ``lifetime_credits_used``,
            ``lifetime_credit_limit``, ``lifetime_remaining``,
            ``daily_request_count``, ``last_used_at``.
        """
        r = self._request("GET", self._url("/usage"))
        self._raise_for_error(r)
        return r.json()

    # ------------------------------------------------------------------
    # Connector methods
    # ------------------------------------------------------------------

    def test_connector(
        self,
        connector_type: str,
        secrets: Optional[Dict] = None,
        credential_id: Optional[str] = None,
    ) -> Dict:
        """Test connectivity to an external data source.

        Args:
            connector_type: One of ``sql``, ``snowflake``, ``bigquery``,
                            ``mongodb``, ``s3``, ``gcs``, ``databricks``,
                            ``delta``, ``fabric``, ``kafka``, ``kinesis``.
            secrets:        Inline connection secrets (e.g. connection_string,
                            bucket, access keys).
            credential_id:  ID of a saved credential on the server
                            (alternative to *secrets*).

        Returns:
            Dict with ``success`` (bool) and ``message``.
        """
        body: Dict = {}
        if credential_id:
            body["credential_id"] = credential_id
        if secrets:
            body["inline_secrets"] = secrets
        r = self._request(
            "POST",
            self._url(f"/connectors/{connector_type}/test"),
            json=body,
        )
        self._raise_for_error(r)
        return r.json()

    def discover(
        self,
        connector_type: str,
        secrets: Optional[Dict] = None,
        credential_id: Optional[str] = None,
    ) -> List[str]:
        """List available tables / files in a data source.

        Returns:
            List of table or object names.
        """
        body: Dict = {}
        if credential_id:
            body["credential_id"] = credential_id
        if secrets:
            body["inline_secrets"] = secrets
        r = self._request(
            "POST",
            self._url(f"/connectors/{connector_type}/discover"),
            json=body,
        )
        self._raise_for_error(r)
        return r.json().get("tables", [])

    def preview(
        self,
        connector_type: str,
        table: str,
        secrets: Optional[Dict] = None,
        credential_id: Optional[str] = None,
        custom_query: Optional[str] = None,
    ) -> Dict:
        """Preview columns and row count of a table / file.

        Returns:
            Dict with ``columns`` (list[str]) and ``row_count`` (int or None).
        """
        body: Dict = {"table": table}
        if credential_id:
            body["credential_id"] = credential_id
        if secrets:
            body["inline_secrets"] = secrets
        if custom_query:
            body["custom_query"] = custom_query
        r = self._request(
            "POST",
            self._url(f"/connectors/{connector_type}/preview"),
            json=body,
        )
        self._raise_for_error(r)
        return r.json()

    def process_from_connector(
        self,
        connector_type: str,
        table: str,
        target_columns: Union[str, List[str]],
        secrets: Optional[Dict] = None,
        credential_id: Optional[str] = None,
        custom_query: Optional[str] = None,
        output_rows: int = 10000,
        tools: Optional[Dict[str, bool]] = None,
        advanced_params: Optional[Dict] = None,
        wait: bool = True,
        poll_interval: int = 2,
        download_path: Optional[str] = None,
        auto_download: bool = True,
        output_preferences: Optional[List[str]] = None,
        compressed: bool = True,
        incremental: bool = False,
        type_casts: Optional[Dict[str, str]] = None,
    ) -> Dict:
        """Run the AutoData pipeline on data from a connector source.

        Instead of uploading a file, the server reads data directly from
        the specified connector (database, cloud storage, etc.).

        Args:
            connector_type: Connector type (``sql``, ``s3``, ``bigquery``, …).
            table:          Table name or object key to read from.
            target_columns: Target column name(s) for ML.
            secrets:        Inline connection secrets.
            credential_id:  ID of a saved credential on the server.
            custom_query:   Optional SQL query (overrides *table*).
            output_rows:    Target row count in output dataset.
            tools:          Toggle pipeline steps (same as :meth:`process`).
            advanced_params: Fine-grained parameters (same as :meth:`process`).
            wait:           Block until processing completes.
            poll_interval:  Seconds between status polls.
            download_path:  Directory to save results.
            auto_download:  Download results automatically when done.
            output_preferences: Subset of filenames to download.
            compressed:     Download as ZIP (default ``True``).
            incremental:    Use watermark-based incremental read — only
                            fetch rows newer than the last sync.
            type_casts:     Column type overrides applied before the pipeline.
                            e.g. ``{"age": "int", "date": "datetime"}``.

        Returns:
            Dict with ``session_id``, ``status``, and (if waited) ``files``.
        """
        y_cols = [target_columns] if isinstance(target_columns, str) else target_columns
        adv = advanced_params or {}
        tls = tools or {}

        body: Dict = {
            "source_type": connector_type,
            "table": table,
            "y_columns": y_cols,
            "task_types": adv.get("task_types", ["c"] * len(y_cols)),
            "output_number": str(output_rows),
            "excluded_columns": adv.get("excluded_columns", []),
            "text_mode": adv.get("text_mode", 0),
            "text_cleaning": adv.get("text_cleaning", True),
            "mdh_mode": adv.get("mdh_mode", 1),
            "zscore_limit": adv.get("zscore_limit", 3.0),
            "similarity_p": adv.get("similarity_p", 95),
            "dsg_mode": adv.get("dsg_mode", "copula"),
            "anomaly_params": adv.get("anomaly_params", {}),
            "completion_params": {
                "output_rows": output_rows,
                "zscore_limit": adv.get("zscore_limit", 3.0),
                "dsg_mode": adv.get("dsg_mode", "copula"),
            },
        }
        # Pipeline tool toggles — backend reads these from _build_pipeline_job
        if tls:
            body["enable_anomaly_detection"] = bool(tls.get("anomaly", False))
            body["enable_dtc"] = bool(tls.get("dtc", True))
            body["enable_mdh"] = bool(tls.get("mdh", True))
            body["enable_dor"] = bool(tls.get("dor", False))
            body["enable_cds"] = bool(tls.get("cds", True))
            body["enable_dsm"] = bool(tls.get("dsm", True))
            body["enable_dsg"] = bool(tls.get("dsg", True))
        if credential_id:
            body["credential_id"] = credential_id
        if secrets:
            body["inline_secrets"] = secrets
        if custom_query:
            body["custom_query"] = custom_query
        if incremental:
            body["incremental"] = True
        if type_casts:
            body["type_casts"] = type_casts

        r = self._request(
            "POST",
            self._url("/process-connector"),
            json=body,
        )
        self._raise_for_error(r)
        result = r.json()
        session_id = result.get("session_id")

        if not wait:
            return result

        try:
            final = self.wait_for_completion(session_id, poll_interval=poll_interval)
        except KeyboardInterrupt:
            print("\nInterrupted — cancelling job on server…")
            self.cancel(session_id)
            raise

        if auto_download:
            self.download_results(
                session_id,
                download_path=download_path,
                output_preferences=output_preferences,
                compressed=compressed,
            )
        return final

    def write_output(
        self,
        session_id: str,
        connector_type: str,
        table_name: str,
        secrets: Optional[Dict] = None,
        credential_id: Optional[str] = None,
        output_stage: str = "dsg",
        if_exists: str = "replace",
        merge_keys: Optional[List[str]] = None,
    ) -> Dict:
        """Write a completed session's output to a database / storage target.

        Args:
            session_id:     ID of the completed pipeline session.
            connector_type: Target connector type.
            table_name:     Destination table or object key.
            secrets:        Inline connection secrets.
            credential_id:  ID of a saved credential.
            output_stage:   Pipeline stage to export (default ``dsg``).
            if_exists:      ``replace``, ``append``, ``fail``, or ``merge``.
            merge_keys:     Column names to match on when ``if_exists='merge'``.

        Returns:
            Dict with ``success``, ``rows_written``, and ``table``.
        """
        body: Dict = {
            "connector_type": connector_type,
            "table_name": table_name,
            "output_stage": output_stage,
            "if_exists": if_exists,
        }
        if merge_keys:
            body["merge_keys"] = merge_keys
        if credential_id:
            body["credential_id"] = credential_id
        if secrets:
            body["inline_secrets"] = secrets
        r = self._request(
            "POST",
            self._url(f"/sessions/{session_id}/write-output"),
            json=body,
        )
        self._raise_for_error(r)
        return r.json()

    def list_credentials(self) -> List[Dict]:
        """List saved credentials for the authenticated account.

        Returns:
            List of credential metadata dicts (secrets are not exposed).
        """
        r = self._request("GET", self._url("/credentials"))
        self._raise_for_error(r)
        return r.json().get("credentials", [])

    def save_credential(
        self,
        name: str,
        connector_type: str,
        secrets: Dict,
    ) -> Dict:
        """Save a new credential on the server for later reuse.

        Args:
            name:           Human-readable label.
            connector_type: Connector type (``sql``, ``s3``, …).
            secrets:        Connection secrets dict.

        Returns:
            Dict with the saved credential metadata including ``id``.
        """
        r = self._request(
            "POST",
            self._url("/credentials"),
            json={"name": name, "connector_type": connector_type, "secrets": secrets},
        )
        self._raise_for_error(r)
        return r.json().get("credential", {})

    def delete_credential(self, credential_id: str) -> bool:
        """Delete a saved credential.

        Returns:
            ``True`` if deleted successfully.
        """
        r = self._request("DELETE", self._url(f"/credentials/{credential_id}"))
        self._raise_for_error(r)
        return r.json().get("success", False)

    # ------------------------------------------------------------------
    # Schema mapping
    # ------------------------------------------------------------------

    def suggest_mapping(
        self,
        source_columns: List[str],
        target_columns: List[str],
        threshold: float = 0.6,
    ) -> Dict:
        """Auto-suggest column mapping between source and target schemas.

        Uses fuzzy string matching to propose the best column alignment.

        Args:
            source_columns: Column names from the source dataset.
            target_columns: Column names for the target schema.
            threshold:      Minimum similarity score (0–1) to include a
                            match suggestion. Default 0.6.

        Returns:
            Dict with ``mapping`` (source→target) and ``scores``.
        """
        r = self._request(
            "POST",
            self._url("/mapping/suggest"),
            json={
                "source_columns": source_columns,
                "target_columns": target_columns,
                "threshold": threshold,
            },
        )
        self._raise_for_error(r)
        return r.json()

    def apply_mapping(
        self,
        session_id: str,
        mapping: Dict[str, str],
        output_stage: str = "dsg",
    ) -> Dict:
        """Rename columns of a completed session's output using a mapping.

        Args:
            session_id:   Pipeline session whose output to rename.
            mapping:      Dict of ``{old_name: new_name}``.
            output_stage: Which pipeline stage to apply to (default ``dsg``).

        Returns:
            Dict with ``columns`` (new column list) and ``preview`` rows.
        """
        r = self._request(
            "POST",
            self._url("/mapping/apply"),
            json={
                "session_id": session_id,
                "mapping": mapping,
                "output_stage": output_stage,
            },
        )
        self._raise_for_error(r)
        return r.json()

    # ------------------------------------------------------------------
    # Sync watermarks (incremental reads)
    # ------------------------------------------------------------------

    def list_watermarks(self) -> List[Dict]:
        """List all sync watermarks for the authenticated account.

        Returns:
            List of watermark dicts with ``id``, ``connector_type``,
            ``table_name``, ``watermark_column``, ``last_value``, etc.
        """
        r = self._request("GET", self._url("/sync/watermarks/list"))
        self._raise_for_error(r)
        return r.json().get("watermarks", [])

    def reset_watermark(self, watermark_id: str) -> Dict:
        """Reset a watermark to force a full re-read on next sync.

        Args:
            watermark_id: ID of the watermark to reset.

        Returns:
            Dict with ``success`` and the updated watermark.
        """
        r = self._request(
            "POST",
            self._url(f"/sync/watermarks/{watermark_id}/reset"),
        )
        self._raise_for_error(r)
        return r.json()

    # ------------------------------------------------------------------
    # Spark (large-data) helpers
    # ------------------------------------------------------------------

    def spark_status(self) -> Dict:
        """Check if the server has PySpark enabled.

        Returns:
            Dict with ``available`` (bool) and Spark session info.
        """
        r = self._request("GET", self._url("/spark/status"))
        self._raise_for_error(r)
        return r.json()

    def spark_read(
        self,
        file_path: str,
        sample_rows: int = 20,
    ) -> Dict:
        """Read a large file via Spark on the server.

        Args:
            file_path:   Server-side path to the file.
            sample_rows: Number of sample rows to return.

        Returns:
            Dict with ``row_count``, ``columns``, ``dtypes``, ``sample``.
        """
        r = self._request(
            "POST",
            self._url("/spark/read"),
            json={"file_path": file_path, "sample_rows": sample_rows},
        )
        self._raise_for_error(r)
        return r.json()

    def spark_transform(
        self,
        file_path: str,
        output_path: str,
        operations: List[Dict],
        output_format: str = "csv",
    ) -> Dict:
        """Apply Spark transformations to a large file on the server.

        Args:
            file_path:     Server-side input file path.
            output_path:   Where to write the result.
            operations:    List of operation dicts::

                            [
                                {"op": "cast", "type_casts": {"age": "int"}},
                                {"op": "drop_nulls", "subset": ["col1"]},
                                {"op": "fill_nulls", "strategy": "mean"},
                                {"op": "normalize", "method": "minmax"},
                                {"op": "sample", "n": 50000},
                            ]

            output_format: ``csv`` or ``parquet``.

        Returns:
            Dict with output stats (row_count, columns, etc.).
        """
        r = self._request(
            "POST",
            self._url("/spark/transform"),
            json={
                "file_path": file_path,
                "output_path": output_path,
                "operations": operations,
                "output_format": output_format,
            },
        )
        self._raise_for_error(r)
        return r.json()

    # ------------------------------------------------------------------
    # Backward-compatibility alias
    # ------------------------------------------------------------------

    def cancel_session(self, session_id: str) -> bool:
        """Deprecated — use :meth:`cancel` instead."""
        return self.cancel(session_id)
