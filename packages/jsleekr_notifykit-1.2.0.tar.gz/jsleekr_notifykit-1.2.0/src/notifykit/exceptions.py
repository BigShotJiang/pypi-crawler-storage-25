"""Typed exceptions for notifykit.

Provides a hierarchy of exceptions for different failure modes,
replacing generic ValueError/RuntimeError with descriptive types.
"""

from __future__ import annotations


class NotifyKitError(Exception):
    """Base exception for all notifykit errors."""


class ConfigError(NotifyKitError):
    """Configuration file is missing, malformed, or invalid."""


class ConfigNotFoundError(ConfigError, FileNotFoundError):
    """No configuration file was found."""


class ChannelError(NotifyKitError):
    """Error in a notification channel."""


class ChannelConfigError(ChannelError):
    """Channel configuration is invalid or incomplete."""


class ChannelSendError(ChannelError):
    """Failed to send a notification through a channel."""


class TemplateError(NotifyKitError):
    """Template rendering or validation error."""


class RateLimitError(NotifyKitError):
    """Rate limit exceeded for a channel."""
