"""Message router — routes messages to channels based on level and tags."""

from __future__ import annotations

from typing import Any

from notifykit.channels.base import BaseChannel
from notifykit.channels.registry import create_channel
from notifykit.models import ChannelConfig, Message, SendResult


class Router:
    """Routes messages to appropriate channels based on level and tag matching."""

    def __init__(self, channel_configs: list[ChannelConfig]) -> None:
        self._configs = channel_configs
        self._channels: list[BaseChannel] = []
        for cfg in channel_configs:
            if cfg.enabled:
                self._channels.append(create_channel(cfg))

    @property
    def channels(self) -> list[BaseChannel]:
        return list(self._channels)

    def route(self, message: Message) -> list[BaseChannel]:
        """Determine which channels should receive this message."""
        matched = []
        for ch in self._channels:
            cfg = ch.config
            # Check level filter
            if message.level not in cfg.levels:
                continue
            # Check tag filter (if channel has tags, message must match at least one)
            if cfg.tags and not set(cfg.tags).intersection(message.tags):
                continue
            matched.append(ch)
        return matched

    def send(self, message: Message) -> list[SendResult]:
        """Route and send a message, returning results from all matched channels."""
        targets = self.route(message)
        results = []
        for ch in targets:
            result = ch._timed_send(message)
            results.append(result)
        return results

    def send_to(self, message: Message, channel_names: list[str]) -> list[SendResult]:
        """Send to specific channels by name, bypassing routing rules."""
        results = []
        for ch in self._channels:
            if ch.name in channel_names:
                result = ch._timed_send(message)
                results.append(result)
        return results
