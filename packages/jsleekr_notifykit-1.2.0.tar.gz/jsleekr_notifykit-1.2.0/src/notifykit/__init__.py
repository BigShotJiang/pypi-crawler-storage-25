"""notifykit — One command. Every notification channel."""

__version__ = "1.2.0"
