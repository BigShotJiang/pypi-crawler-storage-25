"""Notification audit log — records all send attempts."""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from notifykit.models import SendResult


@dataclass
class AuditEntry:
    """A single audit log entry."""

    timestamp: float
    channel: str
    message_id: str
    success: bool
    error: str | None = None
    elapsed_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_result(cls, result: SendResult, **extra: Any) -> "AuditEntry":
        return cls(
            timestamp=time.time(),
            channel=result.channel,
            message_id=result.message_id,
            success=result.success,
            error=result.error,
            elapsed_ms=result.elapsed_ms,
            metadata=extra,
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class AuditLog:
    """Audit log for notification sends. Supports in-memory and file-backed modes."""

    def __init__(self, log_file: str | Path | None = None) -> None:
        self._entries: list[AuditEntry] = []
        self._log_file = Path(log_file) if log_file else None
        if self._log_file:
            self._log_file.parent.mkdir(parents=True, exist_ok=True)

    def record(self, result: SendResult, **extra: Any) -> AuditEntry:
        """Record a send result in the audit log."""
        entry = AuditEntry.from_result(result, **extra)
        self._entries.append(entry)
        if self._log_file:
            self._append_to_file(entry)
        return entry

    def record_many(self, results: list[SendResult]) -> list[AuditEntry]:
        """Record multiple results."""
        return [self.record(r) for r in results]

    def query(
        self,
        channel: str | None = None,
        success: bool | None = None,
        since: float | None = None,
        limit: int | None = None,
    ) -> list[AuditEntry]:
        """Query audit entries with optional filters."""
        entries = self._entries

        if channel is not None:
            entries = [e for e in entries if e.channel == channel]
        if success is not None:
            entries = [e for e in entries if e.success == success]
        if since is not None:
            entries = [e for e in entries if e.timestamp >= since]

        entries = sorted(entries, key=lambda e: e.timestamp, reverse=True)

        if limit is not None:
            entries = entries[:limit]

        return entries

    def stats(self) -> dict[str, Any]:
        """Compute aggregate statistics."""
        total = len(self._entries)
        if total == 0:
            return {"total": 0, "success": 0, "failed": 0, "success_rate": 0.0}

        success_count = sum(1 for e in self._entries if e.success)
        failed_count = total - success_count
        avg_elapsed = sum(e.elapsed_ms for e in self._entries) / total

        by_channel: dict[str, dict[str, int]] = {}
        for e in self._entries:
            ch = by_channel.setdefault(e.channel, {"success": 0, "failed": 0})
            if e.success:
                ch["success"] += 1
            else:
                ch["failed"] += 1

        return {
            "total": total,
            "success": success_count,
            "failed": failed_count,
            "success_rate": success_count / total,
            "avg_elapsed_ms": round(avg_elapsed, 2),
            "by_channel": by_channel,
        }

    def clear(self) -> int:
        """Clear all entries. Returns count cleared."""
        count = len(self._entries)
        self._entries.clear()
        return count

    def _append_to_file(self, entry: AuditEntry) -> None:
        """Append an entry as JSON line to the log file."""
        assert self._log_file is not None
        with open(self._log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry.to_dict()) + "\n")

    def load_from_file(self) -> int:
        """Load entries from the log file. Returns count loaded."""
        if not self._log_file or not self._log_file.is_file():
            return 0

        count = 0
        skipped = 0
        with open(self._log_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    entry = AuditEntry(**data)
                    self._entries.append(entry)
                    count += 1
                except (json.JSONDecodeError, TypeError):
                    skipped += 1
                    continue
        self._skipped_lines = skipped
        return count

    @property
    def skipped_lines(self) -> int:
        """Number of corrupt lines skipped during last load_from_file()."""
        return getattr(self, "_skipped_lines", 0)

    @property
    def entries(self) -> list[AuditEntry]:
        return list(self._entries)
