"""Allow running notifykit as ``python -m notifykit``."""

from notifykit.cli import cli

cli()
