"""Click CLI for notifykit."""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import click

from notifykit import __version__
from notifykit.audit import AuditLog
from notifykit.config import (
    generate_default_config,
    load_config,
    parse_channels,
    validate_config,
)
from notifykit.models import Format, Level, Message
from notifykit.router import Router
from notifykit.templates import render


def _load_router(config_path: str | None) -> Router:
    """Load config and create a router."""
    try:
        config = load_config(config_path)
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error loading config: {e}", err=True)
        sys.exit(1)
    channels = parse_channels(config)
    return Router(channels)


def _get_audit_log() -> AuditLog:
    """Get or create the audit log."""
    log_dir = Path.cwd() / ".notifykit"
    return AuditLog(log_dir / "audit.jsonl")


@click.group()
@click.version_option(version=__version__, prog_name="notifykit")
def cli() -> None:
    """notifykit -- One command. Every notification channel."""


@cli.command()
@click.argument("body")
@click.option("-l", "--level", default="info", help="Notification level (debug/info/warning/error/critical)")
@click.option("-t", "--title", default=None, help="Message title")
@click.option("--tag", multiple=True, help="Message tags (repeatable)")
@click.option("-f", "--format", "fmt", default="plain", help="Format: plain/markdown/html")
@click.option("-c", "--config", "config_path", default=None, help="Config file path")
@click.option("--channel", multiple=True, help="Send to specific channel(s) only")
@click.option("--template", default=None, help="Template name from config")
@click.option("--var", multiple=True, help="Template variables as key=value (repeatable)")
@click.option("--dry-run", is_flag=True, help="Show routing without sending")
@click.option("--json", "as_json", is_flag=True, help="Output results as JSON (for CI)")
@click.option("-q", "--quiet", is_flag=True, help="Suppress non-error output")
def send(
    body: str,
    level: str,
    title: str | None,
    tag: tuple[str, ...],
    fmt: str,
    config_path: str | None,
    channel: tuple[str, ...],
    template: str | None,
    var: tuple[str, ...],
    dry_run: bool,
    as_json: bool,
    quiet: bool,
) -> None:
    """Send a notification message."""
    try:
        msg_level = Level.from_str(level)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    # Handle template rendering
    if template:
        try:
            config = load_config(config_path)
        except FileNotFoundError as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)
        except Exception as e:
            click.echo(f"Error loading config: {e}", err=True)
            sys.exit(1)
        templates = config.get("templates", {})
        tpl_str = templates.get(template)
        if not tpl_str:
            click.echo(f"Error: Template '{template}' not found", err=True)
            sys.exit(1)

        variables = {}
        for v in var:
            if "=" in v:
                k, val = v.split("=", 1)
                variables[k] = val
        variables.setdefault("body", body)
        variables.setdefault("level", level)
        variables.setdefault("title", title or "")
        variables.setdefault("timestamp", time.strftime("%Y-%m-%d %H:%M:%S"))
        body = render(tpl_str, variables)

    valid_formats = [f.value for f in Format]
    if fmt.lower() not in valid_formats:
        click.echo(f"Error: Invalid format '{fmt}'. Valid: {', '.join(valid_formats)}", err=True)
        sys.exit(1)

    msg = Message(
        body=body,
        level=msg_level,
        title=title,
        tags=list(tag),
        format=Format(fmt.lower()),
    )

    router = _load_router(config_path)

    if dry_run:
        targets = router.route(msg)
        if channel:
            targets = [ch for ch in targets if ch.name in channel]
        click.echo(f"Would send to {len(targets)} channel(s) [{msg_level.value}]:")
        for ch in targets:
            levels_str = ", ".join(l.value for l in ch.config.levels)
            click.echo(f"  - {ch.name} ({ch.config.type}) [accepts: {levels_str}]")
        if not targets:
            click.echo("  (no channels matched -- check level and tag filters)")
        return

    if channel:
        results = router.send_to(msg, list(channel))
    else:
        results = router.send(msg)

    audit = _get_audit_log()
    audit.record_many(results)

    if not results:
        if as_json:
            click.echo(json.dumps({"success": False, "error": "No channels matched", "results": []}))
        else:
            click.echo("No channels matched for this message.", err=True)
        sys.exit(1)

    failures = [r for r in results if r.failed]

    if as_json:
        output = {
            "success": len(failures) == 0,
            "total": len(results),
            "succeeded": len(results) - len(failures),
            "failed": len(failures),
            "results": [
                {
                    "channel": r.channel,
                    "success": r.success,
                    "elapsed_ms": round(r.elapsed_ms, 1),
                    "error": r.error,
                }
                for r in results
            ],
        }
        click.echo(json.dumps(output))
    elif not quiet:
        for r in results:
            status = click.style("OK", fg="green") if r.success else click.style("FAIL", fg="red")
            click.echo(f"  [{status}] {r.channel} ({r.elapsed_ms:.0f}ms)")
            if r.error:
                click.echo(f"       Error: {r.error}", err=True)

    if failures:
        sys.exit(1)


@cli.command()
@click.option("-c", "--config", "config_path", default=None, help="Config file path")
def test(config_path: str | None) -> None:
    """Send a test notification to all enabled channels."""
    router = _load_router(config_path)
    msg = Message(
        body="This is a test notification from notifykit.",
        level=Level.INFO,
        title="Test Notification",
        tags=["test"],
    )

    results = router.send(msg)
    for r in results:
        status = click.style("OK", fg="green") if r.success else click.style("FAIL", fg="red")
        click.echo(f"  [{status}] {r.channel}")
        if r.error:
            click.echo(f"       {r.error}", err=True)


@cli.command("channels")
@click.option("-c", "--config", "config_path", default=None, help="Config file path")
def list_channels(config_path: str | None) -> None:
    """List all configured channels."""
    try:
        config = load_config(config_path)
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error loading config: {e}", err=True)
        sys.exit(1)
    channels = parse_channels(config)

    if not channels:
        click.echo("No channels configured.")
        return

    click.echo(f"Channels ({len(channels)}):\n")
    for ch in channels:
        status = click.style("enabled", fg="green") if ch.enabled else click.style("disabled", fg="red")
        levels = ", ".join(l.value for l in ch.levels)
        click.echo(f"  {ch.name}")
        click.echo(f"    Type:   {ch.type}")
        click.echo(f"    Status: {status}")
        click.echo(f"    Levels: {levels}")
        if ch.tags:
            click.echo(f"    Tags:   {', '.join(ch.tags)}")
        if ch.rate_limit:
            click.echo(f"    Rate:   {ch.rate_limit}/min")
        click.echo()


@cli.command()
@click.option("-c", "--config", "config_path", default=None, help="Config file path")
def validate(config_path: str | None) -> None:
    """Validate the configuration file."""
    try:
        config = load_config(config_path)
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error loading config: {e}", err=True)
        sys.exit(1)

    issues = validate_config(config)
    if issues:
        click.echo(f"Found {len(issues)} issue(s):", err=True)
        for issue in issues:
            click.echo(f"  - {issue}", err=True)
        sys.exit(1)
    else:
        channels = parse_channels(config)
        enabled = [c for c in channels if c.enabled]
        click.echo(click.style("Configuration is valid.", fg="green"))
        click.echo(f"  {len(enabled)} channel(s) enabled, {len(channels) - len(enabled)} disabled")


@cli.command()
@click.option("-n", "--limit", default=20, help="Number of entries to show")
@click.option("--channel", default=None, help="Filter by channel name")
@click.option("--failures", is_flag=True, help="Show only failures")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def history(limit: int, channel: str | None, failures: bool, as_json: bool) -> None:
    """Show notification history from audit log."""
    audit = _get_audit_log()
    loaded = audit.load_from_file()

    success_filter = False if failures else None
    entries = audit.query(channel=channel, success=success_filter, limit=limit)

    if not entries:
        click.echo("No audit entries found.")
        return

    if as_json:
        data = [e.to_dict() for e in entries]
        click.echo(json.dumps(data, indent=2))
        return

    for e in entries:
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(e.timestamp))
        status = "OK" if e.success else "FAIL"
        click.echo(f"  [{ts}] {status} {e.channel} msg={e.message_id} ({e.elapsed_ms:.0f}ms)")
        if e.error:
            click.echo(f"           Error: {e.error}")


@cli.command()
@click.option("-o", "--output", default="notifykit.yaml", help="Output file name")
@click.option("--force", is_flag=True, help="Overwrite existing file")
def init(output: str, force: bool) -> None:
    """Generate a default notifykit.yaml config file."""
    path = Path(output)
    if path.exists() and not force:
        click.echo(f"File already exists: {path}. Use --force to overwrite.", err=True)
        sys.exit(1)

    content = generate_default_config()
    path.write_text(content, encoding="utf-8")
    click.echo(click.style(f"Created {path}", fg="green"))
    click.echo()
    click.echo("Next steps:")
    click.echo(f"  1. Open {path} and configure your channels")
    click.echo("  2. Uncomment and fill in the channels you want to use")
    click.echo("  3. Run 'notifykit send \"Hello!\"' to send your first notification")
    click.echo("  4. Run 'notifykit channels' to see all configured channels")
    click.echo("  5. Run 'notifykit validate' to check your config for errors")
    click.echo()
    click.echo("The console channel is already enabled - try sending a message now!")


if __name__ == "__main__":
    cli()
