"""Retry logic with exponential backoff."""

from __future__ import annotations

import time
from typing import Callable

from notifykit.models import Message, SendResult


def retry_send(
    send_fn: Callable[[Message], SendResult],
    message: Message,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    backoff_factor: float = 2.0,
) -> SendResult:
    """Retry a send function with exponential backoff.

    Args:
        send_fn: Function that sends a message and returns SendResult.
        message: The message to send.
        max_retries: Maximum number of retry attempts.
        base_delay: Initial delay in seconds.
        max_delay: Maximum delay between retries.
        backoff_factor: Multiplier for delay on each retry.

    Returns:
        The last SendResult (success or final failure).
    """
    last_result: SendResult | None = None

    for attempt in range(max_retries + 1):
        result = send_fn(message)
        if result.success:
            return result

        last_result = result

        if attempt < max_retries:
            delay = min(base_delay * (backoff_factor ** attempt), max_delay)
            time.sleep(delay)

    assert last_result is not None
    return last_result


def calculate_delay(
    attempt: int,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    backoff_factor: float = 2.0,
) -> float:
    """Calculate the delay for a given retry attempt."""
    return min(base_delay * (backoff_factor ** attempt), max_delay)
