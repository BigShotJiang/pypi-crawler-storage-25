"""YAML configuration loader with environment variable expansion."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import yaml

from notifykit.exceptions import ConfigError, ConfigNotFoundError
from notifykit.models import ChannelConfig

_ENV_PATTERN = re.compile(r"\$\{([^}]+)\}")

DEFAULT_CONFIG_PATHS = [
    "notifykit.yaml",
    "notifykit.yml",
    ".notifykit.yaml",
    ".notifykit.yml",
]


_SAFE_ENV_KEY = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_MAX_CONFIG_DEPTH = 20


def expand_env_vars(value: Any, _depth: int = 0) -> Any:
    """Recursively expand ${ENV_VAR} references in config values.

    Validates env var names to prevent injection and limits recursion depth.
    """
    if _depth > _MAX_CONFIG_DEPTH:
        raise ValueError(f"Config nesting exceeds maximum depth ({_MAX_CONFIG_DEPTH})")
    if isinstance(value, str):
        def _replace(match: re.Match) -> str:
            env_key = match.group(1)
            # Support ${VAR:-default}
            if ":-" in env_key:
                key, default = env_key.split(":-", 1)
                key = key.strip()
            else:
                key = env_key
                default = None
            # Validate env var name to prevent injection
            if not _SAFE_ENV_KEY.match(key):
                raise ValueError(
                    f"Invalid environment variable name: {key!r}. "
                    "Only alphanumeric characters and underscores allowed."
                )
            result = os.environ.get(key)
            if result is not None:
                return result
            if default is not None:
                return default
            return match.group(0)
        return _ENV_PATTERN.sub(_replace, value)
    elif isinstance(value, dict):
        return {k: expand_env_vars(v, _depth + 1) for k, v in value.items()}
    elif isinstance(value, list):
        return [expand_env_vars(item, _depth + 1) for item in value]
    return value


def find_config_file(start_dir: str | Path | None = None) -> Path | None:
    """Search for a config file in the given directory or cwd."""
    search_dir = Path(start_dir) if start_dir else Path.cwd()
    for name in DEFAULT_CONFIG_PATHS:
        candidate = search_dir / name
        if candidate.is_file():
            return candidate
    return None


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    """Load and parse a notifykit YAML config file.

    Args:
        path: Explicit path to config file. If None, searches default locations.

    Returns:
        Parsed and env-expanded configuration dictionary.

    Raises:
        FileNotFoundError: If no config file is found.
        ValueError: If the config file is invalid.
    """
    if path is None:
        found = find_config_file()
        if found is None:
            raise ConfigNotFoundError(
                "No notifykit config file found. "
                "Create notifykit.yaml or run 'notifykit init'."
            )
        path = found
    else:
        path = Path(path)

    if not path.is_file():
        raise ConfigNotFoundError(f"Config file not found: {path}")

    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict):
        raise ConfigError(f"Config file must be a YAML mapping, got {type(raw).__name__}")

    return expand_env_vars(raw)


def parse_channels(config: dict[str, Any]) -> list[ChannelConfig]:
    """Extract channel configurations from a parsed config dict."""
    channels_raw = config.get("channels", {})
    if not isinstance(channels_raw, dict):
        raise ConfigError("'channels' must be a mapping")

    channels = []
    for name, data in channels_raw.items():
        if not isinstance(data, dict):
            raise ConfigError(f"Channel '{name}' must be a mapping")
        channels.append(ChannelConfig.from_dict(name, data))
    return channels


def validate_config(config: dict[str, Any]) -> list[str]:
    """Validate a config dict and return a list of issues (empty = valid)."""
    issues: list[str] = []

    if "channels" not in config:
        issues.append("Missing 'channels' section")
        return issues

    channels = config["channels"]
    if not isinstance(channels, dict):
        issues.append("'channels' must be a mapping")
        return issues

    if not channels:
        issues.append("No channels defined")

    known_types = {"slack", "discord", "email", "telegram", "webhook", "console"}

    for name, data in channels.items():
        if not isinstance(data, dict):
            issues.append(f"Channel '{name}': must be a mapping")
            continue

        ch_type = data.get("type", name)
        if ch_type not in known_types:
            issues.append(f"Channel '{name}': unknown type '{ch_type}'")

        if ch_type == "slack" and "webhook_url" not in data.get("settings", {}):
            issues.append(f"Channel '{name}': Slack requires 'settings.webhook_url'")
        if ch_type == "discord" and "webhook_url" not in data.get("settings", {}):
            issues.append(f"Channel '{name}': Discord requires 'settings.webhook_url'")
        if ch_type == "email":
            settings = data.get("settings", {})
            for req in ("smtp_host", "from_addr", "to_addrs"):
                if req not in settings:
                    issues.append(f"Channel '{name}': Email requires 'settings.{req}'")
        if ch_type == "telegram":
            settings = data.get("settings", {})
            for req in ("bot_token", "chat_id"):
                if req not in settings:
                    issues.append(f"Channel '{name}': Telegram requires 'settings.{req}'")
        if ch_type == "webhook" and "url" not in data.get("settings", {}):
            issues.append(f"Channel '{name}': Webhook requires 'settings.url'")

    return issues


def generate_default_config() -> str:
    """Generate a default notifykit.yaml config template."""
    return """\
# notifykit configuration
# Docs: https://github.com/JSLEEKR/notifykit

channels:
  console:
    type: console
    enabled: true
    levels: [debug, info, warning, error, critical]

  # slack-alerts:
  #   type: slack
  #   enabled: true
  #   levels: [warning, error, critical]
  #   tags: [alerts]
  #   settings:
  #     webhook_url: ${SLACK_WEBHOOK_URL}
  #     channel: "#alerts"
  #     username: notifykit

  # discord-dev:
  #   type: discord
  #   enabled: true
  #   levels: [info, warning, error, critical]
  #   settings:
  #     webhook_url: ${DISCORD_WEBHOOK_URL}

  # email-ops:
  #   type: email
  #   enabled: false
  #   levels: [error, critical]
  #   settings:
  #     smtp_host: smtp.gmail.com
  #     smtp_port: 587
  #     use_tls: true
  #     username: ${EMAIL_USER}
  #     password: ${EMAIL_PASS}
  #     from_addr: alerts@example.com
  #     to_addrs:
  #       - ops@example.com

  # telegram-bot:
  #   type: telegram
  #   enabled: false
  #   levels: [error, critical]
  #   settings:
  #     bot_token: ${TELEGRAM_BOT_TOKEN}
  #     chat_id: ${TELEGRAM_CHAT_ID}

  # webhook-custom:
  #   type: webhook
  #   enabled: false
  #   settings:
  #     url: https://example.com/webhook
  #     method: POST
  #     headers:
  #       Authorization: "Bearer ${WEBHOOK_TOKEN}"

defaults:
  format: plain
  retry_count: 2
  retry_delay: 1.0

templates:
  deploy: "Deployment {{status}}: {{service}} ({{version}}) at {{timestamp}}"
  alert: "[{{level}}] {{title}}: {{body}}"
"""
