"""Telegram channel — sends via Bot API."""

from __future__ import annotations

import requests

from notifykit.channels.base import BaseChannel
from notifykit.models import Format, Message

_TELEGRAM_API = "https://api.telegram.org"


class TelegramChannel(BaseChannel):
    """Send notifications via Telegram Bot API."""

    def send(self, message: Message) -> SendResult:
        bot_token = self.config.settings.get("bot_token")
        chat_id = self.config.settings.get("chat_id")

        if not bot_token:
            return self._make_result(message, False, error="Missing bot_token")
        if not chat_id:
            return self._make_result(message, False, error="Missing chat_id")

        text_parts = []
        if message.title:
            text_parts.append(f"<b>{message.title}</b>")
        text_parts.append(message.body)
        if message.tags:
            tag_str = " ".join(f"#{t}" for t in message.tags)
            text_parts.append(f"\n{tag_str}")

        text = "\n".join(text_parts)

        parse_mode = "HTML"
        if message.format == Format.MARKDOWN:
            parse_mode = "MarkdownV2"

        url = f"{_TELEGRAM_API}/bot{bot_token}/sendMessage"
        payload = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": parse_mode,
        }

        disable_preview = self.config.settings.get("disable_preview", False)
        if disable_preview:
            payload["disable_web_page_preview"] = True

        try:
            resp = requests.post(url, json=payload, timeout=10)
        except requests.ConnectionError as exc:
            return self._make_result(message, False, error=f"Connection error: {exc}")
        except requests.Timeout as exc:
            return self._make_result(message, False, error=f"Request timed out: {exc}")
        except requests.RequestException as exc:
            return self._make_result(message, False, error=f"Request failed: {exc}")

        try:
            data = resp.json()
        except ValueError:
            data = {"raw": resp.text}

        if resp.status_code == 200 and data.get("ok"):
            return self._make_result(
                message, True, response_data=data
            )
        return self._make_result(
            message,
            False,
            error=f"Telegram returned {resp.status_code}: {data}",
            response_data=data,
        )
