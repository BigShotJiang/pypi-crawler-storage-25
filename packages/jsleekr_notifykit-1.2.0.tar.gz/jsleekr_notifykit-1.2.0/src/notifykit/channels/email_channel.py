"""Email channel — sends via SMTP."""

from __future__ import annotations

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from notifykit.channels.base import BaseChannel
from notifykit.models import Format, Message


class EmailChannel(BaseChannel):
    """Send notifications via SMTP email."""

    def send(self, message: Message) -> SendResult:
        settings = self.config.settings
        smtp_host = settings.get("smtp_host")
        smtp_port = settings.get("smtp_port", 587)
        use_tls = settings.get("use_tls", True)
        username = settings.get("username")
        password = settings.get("password")
        from_addr = settings.get("from_addr")
        to_addrs = settings.get("to_addrs", [])

        if not smtp_host:
            return self._make_result(message, False, error="Missing smtp_host")
        if not from_addr:
            return self._make_result(message, False, error="Missing from_addr")
        if not to_addrs:
            return self._make_result(message, False, error="Missing to_addrs")

        if isinstance(to_addrs, str):
            to_addrs = [to_addrs]

        subject = message.title or f"[{message.level.value.upper()}] Notification"

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = ", ".join(to_addrs)

        if message.format == Format.HTML:
            msg.attach(MIMEText(message.body, "html"))
        else:
            msg.attach(MIMEText(message.body, "plain"))

        try:
            server = smtplib.SMTP(smtp_host, smtp_port, timeout=10)
            try:
                if use_tls:
                    server.starttls()
                if username and password:
                    server.login(username, password)
                server.sendmail(from_addr, to_addrs, msg.as_string())
            finally:
                try:
                    server.quit()
                except Exception:
                    server.close()
            return self._make_result(message, True)
        except smtplib.SMTPException as exc:
            return self._make_result(message, False, error=f"SMTP error: {exc}")
