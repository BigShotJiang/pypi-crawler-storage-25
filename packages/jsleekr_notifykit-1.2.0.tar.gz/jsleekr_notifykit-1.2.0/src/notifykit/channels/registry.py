"""Channel registry — maps type names to channel classes."""

from __future__ import annotations

from typing import Type

from notifykit.channels.base import BaseChannel
from notifykit.channels.console import ConsoleChannel
from notifykit.channels.discord import DiscordChannel
from notifykit.channels.email_channel import EmailChannel
from notifykit.channels.slack import SlackChannel
from notifykit.channels.telegram import TelegramChannel
from notifykit.channels.webhook import WebhookChannel
from notifykit.models import ChannelConfig

_BUILTIN_CHANNELS: dict[str, Type[BaseChannel]] = {
    "console": ConsoleChannel,
    "slack": SlackChannel,
    "discord": DiscordChannel,
    "email": EmailChannel,
    "telegram": TelegramChannel,
    "webhook": WebhookChannel,
}

_custom_channels: dict[str, Type[BaseChannel]] = {}


def register_channel(name: str, cls: Type[BaseChannel]) -> None:
    """Register a custom channel type."""
    _custom_channels[name] = cls


def get_channel_class(type_name: str) -> Type[BaseChannel] | None:
    """Look up a channel class by type name."""
    return _custom_channels.get(type_name) or _BUILTIN_CHANNELS.get(type_name)


def create_channel(config: ChannelConfig) -> BaseChannel:
    """Create a channel instance from its config."""
    cls = get_channel_class(config.type)
    if cls is None:
        raise ValueError(f"Unknown channel type: {config.type!r}")
    return cls(config)


def list_channel_types() -> list[str]:
    """Return all known channel type names."""
    return sorted(set(_BUILTIN_CHANNELS) | set(_custom_channels))
