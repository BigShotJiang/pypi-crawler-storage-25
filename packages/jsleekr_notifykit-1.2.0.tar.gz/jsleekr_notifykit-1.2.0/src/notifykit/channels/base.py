"""Abstract base class for notification channels."""

from __future__ import annotations

import re
import time
from abc import ABC, abstractmethod

from notifykit.models import ChannelConfig, Message, SendResult

# Patterns that look like secrets in error messages
_SECRET_PATTERNS = [
    re.compile(r"(https?://hooks\.slack\.com/services/)[^\s]+", re.IGNORECASE),
    re.compile(r"(https?://discord\.com/api/webhooks/)[^\s]+", re.IGNORECASE),
    re.compile(r"(https?://api\.telegram\.org/bot)[^\s]+", re.IGNORECASE),
    re.compile(r"(Bearer\s+)[^\s]+", re.IGNORECASE),
    re.compile(r"(token[=:]\s*)[^\s,}\"']+", re.IGNORECASE),
]


def sanitize_error(error: str) -> str:
    """Remove potential secrets (webhook URLs, tokens) from error messages."""
    result = error
    for pattern in _SECRET_PATTERNS:
        result = pattern.sub(r"\1[REDACTED]", result)
    return result


class BaseChannel(ABC):
    """Abstract base for all notification channels."""

    def __init__(self, config: ChannelConfig) -> None:
        self.config = config
        self.name = config.name

    @abstractmethod
    def send(self, message: Message) -> SendResult:
        """Send a notification message through this channel.

        Args:
            message: The message to send.

        Returns:
            SendResult with success/failure details.
        """

    def _make_result(
        self,
        message: Message,
        success: bool,
        error: str | None = None,
        response_data: dict | None = None,
        elapsed_ms: float = 0.0,
    ) -> SendResult:
        """Helper to create a SendResult."""
        return SendResult(
            channel=self.name,
            success=success,
            message_id=message.id,
            error=error,
            response_data=response_data or {},
            elapsed_ms=elapsed_ms,
        )

    def _timed_send(self, message: Message) -> SendResult:
        """Wrap send with timing and error sanitization."""
        start = time.monotonic()
        try:
            result = self.send(message)
            result.elapsed_ms = (time.monotonic() - start) * 1000
            if result.error:
                result.error = sanitize_error(result.error)
            return result
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            return self._make_result(
                message, success=False,
                error=sanitize_error(str(exc)),
                elapsed_ms=elapsed,
            )

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}(name={self.name!r})>"
