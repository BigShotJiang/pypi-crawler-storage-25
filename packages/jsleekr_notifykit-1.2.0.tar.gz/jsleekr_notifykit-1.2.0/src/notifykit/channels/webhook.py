"""Generic webhook channel — sends JSON payload to any URL."""

from __future__ import annotations

import requests

from notifykit.channels.base import BaseChannel
from notifykit.models import Message, SendResult


class WebhookChannel(BaseChannel):
    """Send notifications to a generic webhook endpoint."""

    def send(self, message: Message) -> SendResult:
        url = self.config.settings.get("url")
        if not url:
            return self._make_result(message, False, error="Missing url")

        method = self.config.settings.get("method", "POST").upper()
        headers = dict(self.config.settings.get("headers", {}))
        headers.setdefault("Content-Type", "application/json")

        payload = {
            "id": message.id,
            "level": message.level.value,
            "title": message.title,
            "body": message.body,
            "tags": message.tags,
            "timestamp": message.timestamp,
            "metadata": message.metadata,
        }

        # Allow custom payload template
        custom_payload = self.config.settings.get("payload")
        if custom_payload:
            payload = custom_payload

        timeout = self.config.settings.get("timeout", 10)

        try:
            resp = requests.request(
                method, url, json=payload, headers=headers, timeout=timeout
            )
        except requests.ConnectionError as exc:
            return self._make_result(
                message, False, error=f"Connection error: {exc}"
            )
        except requests.Timeout as exc:
            return self._make_result(
                message, False, error=f"Request timed out: {exc}"
            )
        except requests.RequestException as exc:
            return self._make_result(
                message, False, error=f"Request failed: {exc}"
            )

        success_codes = self.config.settings.get("success_codes", [200, 201, 202, 204])

        if resp.status_code in success_codes:
            return self._make_result(
                message, True, response_data={"status_code": resp.status_code}
            )
        return self._make_result(
            message,
            False,
            error=f"Webhook returned {resp.status_code}: {resp.text[:200]}",
            response_data={"status_code": resp.status_code},
        )
