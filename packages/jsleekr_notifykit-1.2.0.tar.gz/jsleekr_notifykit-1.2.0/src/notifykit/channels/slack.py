"""Slack channel — sends via incoming webhook."""

from __future__ import annotations

import requests

from notifykit.channels.base import BaseChannel
from notifykit.models import Format, Level, Message

_EMOJI_MAP = {
    Level.DEBUG: ":mag:",
    Level.INFO: ":information_source:",
    Level.WARNING: ":warning:",
    Level.ERROR: ":x:",
    Level.CRITICAL: ":rotating_light:",
}


class SlackChannel(BaseChannel):
    """Send notifications to Slack via incoming webhook."""

    def send(self, message: Message) -> SendResult:
        webhook_url = self.config.settings.get("webhook_url")
        if not webhook_url:
            return self._make_result(message, False, error="Missing webhook_url")

        emoji = _EMOJI_MAP.get(message.level, "")
        blocks = []
        text_parts = []

        if message.title:
            text_parts.append(f"{emoji} *{message.title}*")
        else:
            text_parts.append(f"{emoji} *{message.level.value.upper()}*")

        text_parts.append(message.body)
        fallback_text = "\n".join(text_parts)

        # Build Block Kit payload
        if message.title:
            blocks.append({
                "type": "header",
                "text": {"type": "plain_text", "text": f"{message.title}", "emoji": True},
            })

        body_text = message.body
        if message.format == Format.PLAIN:
            body_text = message.body
        # Slack natively supports markdown

        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": body_text},
        })

        if message.tags:
            tag_str = " ".join(f"`{t}`" for t in message.tags)
            blocks.append({
                "type": "context",
                "elements": [{"type": "mrkdwn", "text": f"Tags: {tag_str}"}],
            })

        payload: dict = {"text": fallback_text, "blocks": blocks}

        channel_override = self.config.settings.get("channel")
        if channel_override:
            payload["channel"] = channel_override
        username = self.config.settings.get("username")
        if username:
            payload["username"] = username

        try:
            resp = requests.post(webhook_url, json=payload, timeout=10)
        except requests.ConnectionError as exc:
            return self._make_result(message, False, error=f"Connection error: {exc}")
        except requests.Timeout as exc:
            return self._make_result(message, False, error=f"Request timed out: {exc}")
        except requests.RequestException as exc:
            return self._make_result(message, False, error=f"Request failed: {exc}")

        if resp.status_code == 200:
            return self._make_result(
                message, True, response_data={"status_code": resp.status_code}
            )
        return self._make_result(
            message,
            False,
            error=f"Slack returned {resp.status_code}: {resp.text}",
            response_data={"status_code": resp.status_code, "body": resp.text},
        )
