"""Console channel — prints notifications to stdout/stderr."""

from __future__ import annotations

import sys

from notifykit.channels.base import BaseChannel
from notifykit.models import Level, Message


# ANSI color codes per level
_COLORS = {
    Level.DEBUG: "\033[90m",     # gray
    Level.INFO: "\033[36m",      # cyan
    Level.WARNING: "\033[33m",   # yellow
    Level.ERROR: "\033[31m",     # red
    Level.CRITICAL: "\033[35m",  # magenta
}
_RESET = "\033[0m"


class ConsoleChannel(BaseChannel):
    """Print notifications to the terminal."""

    def send(self, message: Message) -> SendResult:
        use_color = self.config.settings.get("color", True)
        stream = sys.stderr if message.level in (Level.ERROR, Level.CRITICAL) else sys.stdout

        parts = []
        level_str = message.level.value.upper()

        if use_color:
            color = _COLORS.get(message.level, "")
            parts.append(f"{color}[{level_str}]{_RESET}")
        else:
            parts.append(f"[{level_str}]")

        if message.title:
            parts.append(message.title)

        parts.append(message.body)

        line = " ".join(parts)
        print(line, file=stream)

        return self._make_result(message, success=True)
