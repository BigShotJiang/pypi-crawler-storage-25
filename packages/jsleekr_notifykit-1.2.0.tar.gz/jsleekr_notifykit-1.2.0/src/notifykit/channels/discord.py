"""Discord channel — sends via webhook."""

from __future__ import annotations

import requests

from notifykit.channels.base import BaseChannel
from notifykit.models import Level, Message

_COLOR_MAP = {
    Level.DEBUG: 0x808080,     # gray
    Level.INFO: 0x3498DB,      # blue
    Level.WARNING: 0xF39C12,   # orange
    Level.ERROR: 0xE74C3C,     # red
    Level.CRITICAL: 0x9B59B6,  # purple
}


class DiscordChannel(BaseChannel):
    """Send notifications to Discord via webhook."""

    def send(self, message: Message) -> SendResult:
        webhook_url = self.config.settings.get("webhook_url")
        if not webhook_url:
            return self._make_result(message, False, error="Missing webhook_url")

        color = _COLOR_MAP.get(message.level, 0x808080)
        embed: dict = {
            "color": color,
            "description": message.body,
        }
        if message.title:
            embed["title"] = message.title

        if message.tags:
            embed["footer"] = {"text": "Tags: " + ", ".join(message.tags)}

        payload: dict = {"embeds": [embed]}

        username = self.config.settings.get("username")
        if username:
            payload["username"] = username

        try:
            resp = requests.post(webhook_url, json=payload, timeout=10)
        except requests.ConnectionError as exc:
            return self._make_result(message, False, error=f"Connection error: {exc}")
        except requests.Timeout as exc:
            return self._make_result(message, False, error=f"Request timed out: {exc}")
        except requests.RequestException as exc:
            return self._make_result(message, False, error=f"Request failed: {exc}")

        if resp.status_code in (200, 204):
            return self._make_result(
                message, True, response_data={"status_code": resp.status_code}
            )
        return self._make_result(
            message,
            False,
            error=f"Discord returned {resp.status_code}: {resp.text}",
            response_data={"status_code": resp.status_code, "body": resp.text},
        )
