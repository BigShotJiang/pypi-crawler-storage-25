"""Core data models for notifykit."""

from __future__ import annotations

import enum
import time
import uuid
from dataclasses import dataclass, field
from typing import Any


class Level(enum.Enum):
    """Notification severity level."""

    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

    @classmethod
    def from_str(cls, value: str) -> "Level":
        """Parse a level from string, case-insensitive."""
        try:
            return cls(value.lower())
        except ValueError:
            valid = ", ".join(l.value for l in cls)
            raise ValueError(f"Invalid level '{value}'. Valid: {valid}")


class Format(enum.Enum):
    """Output format for notification body."""

    PLAIN = "plain"
    MARKDOWN = "markdown"
    HTML = "html"


@dataclass
class Message:
    """A notification message to be sent."""

    body: str
    level: Level = Level.INFO
    title: str | None = None
    tags: list[str] = field(default_factory=list)
    format: Format = Format.PLAIN
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    timestamp: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        if isinstance(self.level, str):
            self.level = Level.from_str(self.level)
        if isinstance(self.format, str):
            self.format = Format(self.format.lower())


@dataclass
class SendResult:
    """Result of sending a notification through a channel."""

    channel: str
    success: bool
    message_id: str
    error: str | None = None
    response_data: dict[str, Any] = field(default_factory=dict)
    elapsed_ms: float = 0.0

    @property
    def failed(self) -> bool:
        return not self.success

    @property
    def summary(self) -> str:
        """Human-readable one-line summary of the result."""
        status = "OK" if self.success else "FAIL"
        parts = [f"[{status}]", self.channel]
        if self.elapsed_ms > 0:
            parts.append(f"({self.elapsed_ms:.0f}ms)")
        if self.error:
            parts.append(f"- {self.error}")
        return " ".join(parts)


@dataclass
class ChannelConfig:
    """Configuration for a notification channel."""

    name: str
    type: str
    enabled: bool = True
    levels: list[Level] = field(default_factory=lambda: list(Level))
    tags: list[str] = field(default_factory=list)
    settings: dict[str, Any] = field(default_factory=dict)
    rate_limit: int | None = None  # max sends per minute
    retry_count: int = 0
    retry_delay: float = 1.0

    _SAFE_NAME = __import__("re").compile(r"^[A-Za-z0-9_-]+$")

    @classmethod
    def from_dict(cls, name: str, data: dict[str, Any]) -> "ChannelConfig":
        """Create ChannelConfig from a dictionary."""
        if not cls._SAFE_NAME.match(name):
            raise ValueError(
                f"Invalid channel name: {name!r}. "
                "Only alphanumeric characters, hyphens, and underscores allowed."
            )
        if len(name) > 64:
            raise ValueError(f"Channel name too long ({len(name)} > 64): {name!r}")
        levels = data.get("levels", [l.value for l in Level])
        parsed_levels = [Level.from_str(l) if isinstance(l, str) else l for l in levels]
        return cls(
            name=name,
            type=data.get("type", name),
            enabled=data.get("enabled", True),
            levels=parsed_levels,
            tags=data.get("tags", []),
            settings=data.get("settings", {}),
            rate_limit=data.get("rate_limit"),
            retry_count=data.get("retry_count", 0),
            retry_delay=data.get("retry_delay", 1.0),
        )
