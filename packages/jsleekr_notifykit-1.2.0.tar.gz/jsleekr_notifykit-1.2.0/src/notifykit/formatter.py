"""Message formatting — Plain, Markdown, HTML."""

from __future__ import annotations

import html as html_mod

from notifykit.models import Format, Level, Message


def format_message(message: Message, target_format: Format | None = None) -> str:
    """Format a message body for the given output format.

    If target_format is None, uses the message's own format.
    """
    fmt = target_format or message.format
    body = message.body
    title = message.title
    level = message.level.value.upper()
    tags = message.tags

    if fmt == Format.PLAIN:
        return _format_plain(body, title, level, tags)
    elif fmt == Format.MARKDOWN:
        return _format_markdown(body, title, level, tags)
    elif fmt == Format.HTML:
        return _format_html(body, title, level, tags)
    return body


def _format_plain(body: str, title: str | None, level: str, tags: list[str]) -> str:
    parts = []
    parts.append(f"[{level}]")
    if title:
        parts.append(title)
    parts.append(body)
    if tags:
        parts.append(f"(tags: {', '.join(tags)})")
    return " ".join(parts)


def _format_markdown(body: str, title: str | None, level: str, tags: list[str]) -> str:
    lines = []
    if title:
        lines.append(f"## {title}")
        lines.append("")
    lines.append(f"**Level:** {level}")
    lines.append("")
    lines.append(body)
    if tags:
        lines.append("")
        tag_str = " ".join(f"`{t}`" for t in tags)
        lines.append(f"**Tags:** {tag_str}")
    return "\n".join(lines)


def _format_html(body: str, title: str | None, level: str, tags: list[str]) -> str:
    _level_colors = {
        "DEBUG": "#808080",
        "INFO": "#3498db",
        "WARNING": "#f39c12",
        "ERROR": "#e74c3c",
        "CRITICAL": "#9b59b6",
    }
    color = _level_colors.get(level, "#808080")

    lines = []
    lines.append("<div style=\"font-family: sans-serif;\">")
    if title:
        lines.append(f"  <h2>{html_mod.escape(title)}</h2>")
    lines.append(f"  <span style=\"color: {color}; font-weight: bold;\">[{level}]</span>")
    lines.append(f"  <p>{html_mod.escape(body)}</p>")
    if tags:
        tag_html = " ".join(
            f"<code>{html_mod.escape(t)}</code>" for t in tags
        )
        lines.append(f"  <p><strong>Tags:</strong> {tag_html}</p>")
    lines.append("</div>")
    return "\n".join(lines)


def convert_format(text: str, from_fmt: Format, to_fmt: Format) -> str:
    """Basic format conversion. Limited — mainly handles plain <-> markdown/html."""
    if from_fmt == to_fmt:
        return text

    if from_fmt == Format.PLAIN and to_fmt == Format.MARKDOWN:
        return text  # plain is valid markdown

    if from_fmt == Format.PLAIN and to_fmt == Format.HTML:
        escaped = html_mod.escape(text)
        return f"<p>{escaped}</p>"

    if from_fmt == Format.HTML and to_fmt == Format.PLAIN:
        # Strip tags (simple approach)
        import re
        return re.sub(r"<[^>]+>", "", text).strip()

    if from_fmt == Format.MARKDOWN and to_fmt == Format.PLAIN:
        import re
        text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
        text = re.sub(r"\*(.+?)\*", r"\1", text)
        text = re.sub(r"`(.+?)`", r"\1", text)
        text = re.sub(r"^#+\s*", "", text, flags=re.MULTILINE)
        return text

    return text
