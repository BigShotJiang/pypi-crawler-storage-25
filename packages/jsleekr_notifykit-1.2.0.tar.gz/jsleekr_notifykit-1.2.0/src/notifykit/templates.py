"""Template engine — {{variable}} substitution."""

from __future__ import annotations

import re
from typing import Any

_TEMPLATE_PATTERN = re.compile(r"\{\{(\s*[\w.]+\s*)\}\}")


def render(template: str, variables: dict[str, Any]) -> str:
    """Render a template string by substituting {{variable}} placeholders.

    Supports dotted access: {{user.name}} looks up variables["user"]["name"]
    or variables["user.name"].

    Unresolved variables are left as-is.
    """
    def _replace(match: re.Match) -> str:
        key = match.group(1).strip()
        value = _resolve(key, variables)
        if value is None:
            return match.group(0)
        return str(value)

    return _TEMPLATE_PATTERN.sub(_replace, template)


def _resolve(key: str, variables: dict[str, Any]) -> Any:
    """Resolve a dotted key from variables dict."""
    # Try flat key first
    if key in variables:
        return variables[key]

    # Try dotted traversal
    parts = key.split(".")
    current: Any = variables
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def list_variables(template: str) -> list[str]:
    """Extract all variable names from a template string."""
    return [m.group(1).strip() for m in _TEMPLATE_PATTERN.finditer(template)]


def validate_template(template: str, available_vars: dict[str, Any]) -> list[str]:
    """Check if all template variables can be resolved. Returns unresolved names."""
    unresolved = []
    for var in list_variables(template):
        if _resolve(var, available_vars) is None:
            unresolved.append(var)
    return unresolved
