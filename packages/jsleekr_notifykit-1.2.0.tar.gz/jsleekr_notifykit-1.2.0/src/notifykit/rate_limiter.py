"""Per-channel rate limiting using token bucket algorithm."""

from __future__ import annotations

import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field


@dataclass
class _Bucket:
    """Token bucket for rate limiting."""
    max_tokens: int
    tokens: float = 0.0
    last_refill: float = field(default_factory=time.monotonic)
    refill_rate: float = 0.0  # tokens per second

    def __post_init__(self) -> None:
        self.tokens = float(self.max_tokens)
        self.refill_rate = self.max_tokens / 60.0  # per minute -> per second


class RateLimiter:
    """Per-channel rate limiter using token bucket algorithm."""

    def __init__(self) -> None:
        self._buckets: dict[str, _Bucket] = {}
        self._lock = threading.Lock()

    def configure(self, channel_name: str, max_per_minute: int) -> None:
        """Set rate limit for a channel."""
        with self._lock:
            self._buckets[channel_name] = _Bucket(max_tokens=max_per_minute)

    def allow(self, channel_name: str) -> bool:
        """Check if a send is allowed for this channel, consuming a token if so."""
        with self._lock:
            bucket = self._buckets.get(channel_name)
            if bucket is None:
                return True  # no limit configured

            now = time.monotonic()
            elapsed = now - bucket.last_refill
            bucket.tokens = min(
                bucket.max_tokens,
                bucket.tokens + elapsed * bucket.refill_rate,
            )
            bucket.last_refill = now

            if bucket.tokens >= 1.0:
                bucket.tokens -= 1.0
                return True
            return False

    def remaining(self, channel_name: str) -> int | None:
        """Get remaining tokens for a channel. None if no limit configured."""
        with self._lock:
            bucket = self._buckets.get(channel_name)
            if bucket is None:
                return None
            return int(bucket.tokens)

    def reset(self, channel_name: str | None = None) -> None:
        """Reset rate limit state for a channel or all channels."""
        with self._lock:
            if channel_name:
                bucket = self._buckets.get(channel_name)
                if bucket:
                    bucket.tokens = float(bucket.max_tokens)
                    bucket.last_refill = time.monotonic()
            else:
                for bucket in self._buckets.values():
                    bucket.tokens = float(bucket.max_tokens)
                    bucket.last_refill = time.monotonic()

    def wait_time(self, channel_name: str) -> float:
        """Return seconds to wait before next send is allowed. 0 if allowed now.

        Returns float('inf') if the channel rate limit is 0 (sends never allowed).
        """
        with self._lock:
            bucket = self._buckets.get(channel_name)
            if bucket is None:
                return 0.0
            if bucket.tokens >= 1.0:
                return 0.0
            if bucket.refill_rate <= 0:
                return float("inf")
            needed = 1.0 - bucket.tokens
            return needed / bucket.refill_rate


# Global rate limiter instance
rate_limiter = RateLimiter()
