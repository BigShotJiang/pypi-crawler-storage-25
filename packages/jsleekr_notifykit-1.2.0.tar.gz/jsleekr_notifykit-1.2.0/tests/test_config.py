"""Tests for notifykit.config."""

import os
from pathlib import Path

import pytest

from notifykit.config import (
    expand_env_vars,
    find_config_file,
    generate_default_config,
    load_config,
    parse_channels,
    validate_config,
)
from notifykit.exceptions import ConfigError, ConfigNotFoundError
from notifykit.models import ChannelConfig


class TestExpandEnvVars:
    def test_simple_expansion(self, monkeypatch):
        monkeypatch.setenv("MY_VAR", "hello")
        assert expand_env_vars("${MY_VAR}") == "hello"

    def test_default_value(self):
        result = expand_env_vars("${NONEXISTENT_VAR:-fallback}")
        assert result == "fallback"

    def test_unset_var_kept(self):
        result = expand_env_vars("${DEFINITELY_NOT_SET_XYZ}")
        assert result == "${DEFINITELY_NOT_SET_XYZ}"

    def test_nested_dict(self, monkeypatch):
        monkeypatch.setenv("DB_HOST", "localhost")
        data = {"host": "${DB_HOST}", "port": 5432}
        result = expand_env_vars(data)
        assert result == {"host": "localhost", "port": 5432}

    def test_nested_list(self, monkeypatch):
        monkeypatch.setenv("ITEM", "value")
        data = ["${ITEM}", "static"]
        result = expand_env_vars(data)
        assert result == ["value", "static"]

    def test_non_string_passthrough(self):
        assert expand_env_vars(42) == 42
        assert expand_env_vars(True) is True
        assert expand_env_vars(None) is None

    def test_multiple_vars_in_string(self, monkeypatch):
        monkeypatch.setenv("A", "hello")
        monkeypatch.setenv("B", "world")
        assert expand_env_vars("${A} ${B}") == "hello world"


class TestFindConfigFile:
    def test_finds_yaml(self, tmp_path):
        (tmp_path / "notifykit.yaml").write_text("channels: {}")
        result = find_config_file(tmp_path)
        assert result is not None
        assert result.name == "notifykit.yaml"

    def test_finds_yml(self, tmp_path):
        (tmp_path / "notifykit.yml").write_text("channels: {}")
        result = find_config_file(tmp_path)
        assert result is not None
        assert result.name == "notifykit.yml"

    def test_prefers_yaml_over_yml(self, tmp_path):
        (tmp_path / "notifykit.yaml").write_text("channels: {}")
        (tmp_path / "notifykit.yml").write_text("channels: {}")
        result = find_config_file(tmp_path)
        assert result.name == "notifykit.yaml"

    def test_returns_none_when_missing(self, tmp_path):
        assert find_config_file(tmp_path) is None


class TestLoadConfig:
    def test_load_valid(self, sample_config_yaml):
        config = load_config(sample_config_yaml)
        assert "channels" in config
        assert "console" in config["channels"]

    def test_missing_file(self):
        with pytest.raises(FileNotFoundError):
            load_config("/nonexistent/path.yaml")

    def test_invalid_yaml(self, tmp_path):
        bad = tmp_path / "bad.yaml"
        bad.write_text("not: a: valid: yaml: [")
        with pytest.raises(Exception):
            load_config(bad)

    def test_non_dict_yaml(self, tmp_path):
        bad = tmp_path / "list.yaml"
        bad.write_text("- item1\n- item2")
        with pytest.raises(ConfigError, match="must be a YAML mapping"):
            load_config(bad)

    def test_env_expansion(self, env_config_yaml, monkeypatch):
        monkeypatch.setenv("NOTIFYKIT_TEST_WEBHOOK", "https://expanded.url")
        config = load_config(env_config_yaml)
        url = config["channels"]["slack"]["settings"]["webhook_url"]
        assert url == "https://expanded.url"

    def test_env_default_value(self, env_config_yaml, monkeypatch):
        monkeypatch.setenv("NOTIFYKIT_TEST_WEBHOOK", "https://test.url")
        config = load_config(env_config_yaml)
        channel = config["channels"]["slack"]["settings"]["channel"]
        assert channel == "#general"


class TestParseChannels:
    def test_parse(self, sample_config_yaml):
        config = load_config(sample_config_yaml)
        channels = parse_channels(config)
        assert len(channels) == 3
        names = {c.name for c in channels}
        assert "console" in names
        assert "slack-alerts" in names

    def test_missing_channels_key(self):
        with pytest.raises(ConfigError, match="must be a mapping"):
            parse_channels({"channels": "not-a-dict"})

    def test_empty_config(self):
        channels = parse_channels({})
        assert channels == []

    def test_invalid_channel_entry(self):
        with pytest.raises(ConfigError, match="must be a mapping"):
            parse_channels({"channels": {"bad": "string"}})


class TestValidateConfig:
    def test_valid(self, sample_config_yaml):
        config = load_config(sample_config_yaml)
        issues = validate_config(config)
        assert issues == []

    def test_missing_channels(self):
        issues = validate_config({})
        assert any("Missing 'channels'" in i for i in issues)

    def test_empty_channels(self):
        issues = validate_config({"channels": {}})
        assert any("No channels defined" in i for i in issues)

    def test_unknown_type(self):
        issues = validate_config({"channels": {"x": {"type": "fax"}}})
        assert any("unknown type" in i for i in issues)

    def test_slack_missing_webhook(self):
        issues = validate_config({
            "channels": {"s": {"type": "slack", "settings": {}}}
        })
        assert any("webhook_url" in i for i in issues)

    def test_discord_missing_webhook(self):
        issues = validate_config({
            "channels": {"d": {"type": "discord", "settings": {}}}
        })
        assert any("webhook_url" in i for i in issues)

    def test_email_missing_fields(self):
        issues = validate_config({
            "channels": {"e": {"type": "email", "settings": {}}}
        })
        assert any("smtp_host" in i for i in issues)
        assert any("from_addr" in i for i in issues)
        assert any("to_addrs" in i for i in issues)

    def test_telegram_missing_fields(self):
        issues = validate_config({
            "channels": {"t": {"type": "telegram", "settings": {}}}
        })
        assert any("bot_token" in i for i in issues)
        assert any("chat_id" in i for i in issues)

    def test_webhook_missing_url(self):
        issues = validate_config({
            "channels": {"w": {"type": "webhook", "settings": {}}}
        })
        assert any("url" in i for i in issues)


class TestInputValidation:
    """Security: input validation for malicious config and env var injection."""

    def test_env_var_injection_rejected(self):
        """Env var names with special chars should be rejected."""
        with pytest.raises(ValueError, match="Invalid environment variable name"):
            expand_env_vars("${PATH;rm -rf /}")

    def test_env_var_spaces_rejected(self):
        """Env var names with spaces should be rejected."""
        with pytest.raises(ValueError, match="Invalid environment variable name"):
            expand_env_vars("${MY VAR}")

    def test_deeply_nested_config_rejected(self):
        """Extremely deep nesting should be rejected to prevent stack overflow."""
        # Build a dict nested 25 levels deep
        data = "value"
        for _ in range(25):
            data = {"nested": data}
        with pytest.raises(ValueError, match="nesting exceeds maximum depth"):
            expand_env_vars(data)

    def test_channel_name_injection(self):
        """Channel names with path traversal should be rejected."""
        with pytest.raises(ValueError, match="Invalid channel name"):
            ChannelConfig.from_dict("../etc/passwd", {"type": "console"})

    def test_channel_name_too_long(self):
        """Extremely long channel names should be rejected."""
        with pytest.raises(ValueError, match="Channel name too long"):
            ChannelConfig.from_dict("a" * 65, {"type": "console"})

    def test_valid_env_var_still_works(self, monkeypatch):
        """Normal env vars should still expand correctly."""
        monkeypatch.setenv("VALID_KEY_123", "works")
        assert expand_env_vars("${VALID_KEY_123}") == "works"


class TestTypedExceptions:
    """Verify typed exceptions are raised instead of generic ones."""

    def test_load_missing_raises_config_not_found(self):
        """Missing config should raise ConfigNotFoundError."""
        with pytest.raises(ConfigNotFoundError):
            load_config("/nonexistent/path.yaml")

    def test_config_not_found_is_file_not_found(self):
        """ConfigNotFoundError should also be a FileNotFoundError for compat."""
        with pytest.raises(FileNotFoundError):
            load_config("/nonexistent/path.yaml")

    def test_non_dict_raises_config_error(self, tmp_path):
        """Non-dict YAML should raise ConfigError."""
        bad = tmp_path / "list.yaml"
        bad.write_text("- item1\n- item2")
        with pytest.raises(ConfigError, match="must be a YAML mapping"):
            load_config(bad)

    def test_parse_channels_bad_mapping_raises_config_error(self):
        """parse_channels with non-dict raises ConfigError."""
        with pytest.raises(ConfigError, match="must be a mapping"):
            parse_channels({"channels": "not-a-dict"})


class TestGenerateDefaultConfig:
    def test_generates_yaml(self):
        content = generate_default_config()
        assert "channels:" in content
        assert "console:" in content
        assert "slack" in content

    def test_parseable(self, tmp_path):
        content = generate_default_config()
        f = tmp_path / "test.yaml"
        f.write_text(content)
        config = load_config(f)
        assert "channels" in config
