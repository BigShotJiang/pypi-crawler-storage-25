"""Tests for notifykit.audit."""

import json
import time

import pytest

from notifykit.audit import AuditEntry, AuditLog
from notifykit.models import SendResult

from tests.helpers import make_result as _make_result


class TestAuditEntry:
    def test_from_result(self):
        r = _make_result()
        entry = AuditEntry.from_result(r, source="test")
        assert entry.channel == "test"
        assert entry.success is True
        assert entry.metadata == {"source": "test"}
        assert entry.timestamp > 0

    def test_to_dict(self):
        r = _make_result()
        entry = AuditEntry.from_result(r)
        d = entry.to_dict()
        assert d["channel"] == "test"
        assert d["success"] is True
        assert "timestamp" in d


class TestAuditLog:
    def test_record(self):
        log = AuditLog()
        r = _make_result()
        entry = log.record(r)
        assert entry.channel == "test"
        assert len(log.entries) == 1

    def test_record_many(self):
        log = AuditLog()
        results = [_make_result(f"ch{i}") for i in range(5)]
        entries = log.record_many(results)
        assert len(entries) == 5
        assert len(log.entries) == 5

    def test_query_all(self):
        log = AuditLog()
        log.record(_make_result("a"))
        log.record(_make_result("b"))
        assert len(log.query()) == 2

    def test_query_by_channel(self):
        log = AuditLog()
        log.record(_make_result("slack"))
        log.record(_make_result("discord"))
        log.record(_make_result("slack"))
        results = log.query(channel="slack")
        assert len(results) == 2

    def test_query_by_success(self):
        log = AuditLog()
        log.record(_make_result(success=True))
        log.record(_make_result(success=False))
        log.record(_make_result(success=True))
        assert len(log.query(success=True)) == 2
        assert len(log.query(success=False)) == 1

    def test_query_with_limit(self):
        log = AuditLog()
        for i in range(10):
            log.record(_make_result(f"ch{i}"))
        assert len(log.query(limit=3)) == 3

    def test_query_since(self):
        log = AuditLog()
        log.record(_make_result())
        cutoff = time.time() + 1
        # Future entry
        r = _make_result()
        entry = log.record(r)
        entry2 = log._entries[-1]
        entry2.timestamp = cutoff + 1
        results = log.query(since=cutoff)
        assert len(results) == 1

    def test_stats_empty(self):
        log = AuditLog()
        stats = log.stats()
        assert stats["total"] == 0
        assert stats["success_rate"] == 0.0

    def test_stats(self):
        log = AuditLog()
        log.record(_make_result(success=True))
        log.record(_make_result(success=True))
        log.record(_make_result(success=False))
        stats = log.stats()
        assert stats["total"] == 3
        assert stats["success"] == 2
        assert stats["failed"] == 1
        assert abs(stats["success_rate"] - 2 / 3) < 0.01

    def test_stats_by_channel(self):
        log = AuditLog()
        log.record(_make_result("slack", True))
        log.record(_make_result("slack", False))
        log.record(_make_result("discord", True))
        stats = log.stats()
        assert stats["by_channel"]["slack"]["success"] == 1
        assert stats["by_channel"]["slack"]["failed"] == 1
        assert stats["by_channel"]["discord"]["success"] == 1

    def test_clear(self):
        log = AuditLog()
        log.record(_make_result())
        log.record(_make_result())
        count = log.clear()
        assert count == 2
        assert len(log.entries) == 0

    def test_file_backed(self, tmp_audit_file):
        log = AuditLog(tmp_audit_file)
        log.record(_make_result("ch1"))
        log.record(_make_result("ch2"))
        assert tmp_audit_file.is_file()
        content = tmp_audit_file.read_text()
        lines = [l for l in content.strip().split("\n") if l]
        assert len(lines) == 2

    def test_load_from_file(self, tmp_audit_file):
        # Write entries
        log1 = AuditLog(tmp_audit_file)
        log1.record(_make_result("a"))
        log1.record(_make_result("b"))

        # Load in new instance
        log2 = AuditLog(tmp_audit_file)
        loaded = log2.load_from_file()
        assert loaded == 2
        assert len(log2.entries) == 2

    def test_load_from_nonexistent(self, tmp_path):
        log = AuditLog(tmp_path / "nope.jsonl")
        assert log.load_from_file() == 0

    def test_load_corrupt_lines(self, tmp_audit_file):
        tmp_audit_file.write_text("not json\n{bad\n")
        log = AuditLog(tmp_audit_file)
        loaded = log.load_from_file()
        assert loaded == 0

    def test_skipped_lines_tracked(self, tmp_audit_file):
        """Corrupt lines should be counted in skipped_lines property."""
        valid = json.dumps({
            "timestamp": 1.0, "channel": "test", "message_id": "m1",
            "success": True, "error": None, "elapsed_ms": 1.0, "metadata": {},
        })
        tmp_audit_file.write_text(f"bad line\n{valid}\nalso bad\n")
        log = AuditLog(tmp_audit_file)
        loaded = log.load_from_file()
        assert loaded == 1
        assert log.skipped_lines == 2

    def test_skipped_lines_zero_on_clean_load(self, tmp_audit_file):
        """Clean files should have zero skipped lines."""
        log1 = AuditLog(tmp_audit_file)
        log1.record(_make_result())
        log2 = AuditLog(tmp_audit_file)
        log2.load_from_file()
        assert log2.skipped_lines == 0
