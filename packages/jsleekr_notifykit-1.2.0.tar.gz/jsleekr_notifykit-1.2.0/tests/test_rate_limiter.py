"""Tests for notifykit.rate_limiter."""

import time

import pytest

from notifykit.rate_limiter import RateLimiter


class TestRateLimiter:
    def test_no_limit_always_allows(self):
        rl = RateLimiter()
        assert rl.allow("unconfigured") is True

    def test_configured_allows_initial(self):
        rl = RateLimiter()
        rl.configure("ch1", max_per_minute=10)
        assert rl.allow("ch1") is True

    def test_exhausts_tokens(self):
        rl = RateLimiter()
        rl.configure("ch1", max_per_minute=3)
        assert rl.allow("ch1") is True
        assert rl.allow("ch1") is True
        assert rl.allow("ch1") is True
        assert rl.allow("ch1") is False

    def test_remaining(self):
        rl = RateLimiter()
        rl.configure("ch1", max_per_minute=5)
        assert rl.remaining("ch1") == 5
        rl.allow("ch1")
        assert rl.remaining("ch1") == 4

    def test_remaining_unconfigured(self):
        rl = RateLimiter()
        assert rl.remaining("nope") is None

    def test_reset_single(self):
        rl = RateLimiter()
        rl.configure("ch1", max_per_minute=2)
        rl.allow("ch1")
        rl.allow("ch1")
        assert rl.allow("ch1") is False
        rl.reset("ch1")
        assert rl.allow("ch1") is True

    def test_reset_all(self):
        rl = RateLimiter()
        rl.configure("a", max_per_minute=1)
        rl.configure("b", max_per_minute=1)
        rl.allow("a")
        rl.allow("b")
        assert rl.allow("a") is False
        assert rl.allow("b") is False
        rl.reset()
        assert rl.allow("a") is True
        assert rl.allow("b") is True

    def test_wait_time_zero_when_allowed(self):
        rl = RateLimiter()
        rl.configure("ch1", max_per_minute=10)
        assert rl.wait_time("ch1") == 0.0

    def test_wait_time_positive_when_exhausted(self):
        rl = RateLimiter()
        rl.configure("ch1", max_per_minute=1)
        rl.allow("ch1")
        wt = rl.wait_time("ch1")
        assert wt > 0

    def test_wait_time_unconfigured(self):
        rl = RateLimiter()
        assert rl.wait_time("nope") == 0.0

    def test_independent_channels(self):
        rl = RateLimiter()
        rl.configure("a", max_per_minute=1)
        rl.configure("b", max_per_minute=1)
        rl.allow("a")
        assert rl.allow("a") is False
        assert rl.allow("b") is True  # independent
