"""Tests for notifykit.router."""

import pytest

from notifykit.models import ChannelConfig, Level, Message
from notifykit.router import Router


def _make_configs():
    return [
        ChannelConfig(
            name="console", type="console", enabled=True,
            levels=list(Level),
        ),
        ChannelConfig(
            name="slack-alerts", type="console", enabled=True,
            levels=[Level.WARNING, Level.ERROR, Level.CRITICAL],
            tags=["alerts"],
        ),
        ChannelConfig(
            name="email-critical", type="console", enabled=True,
            levels=[Level.CRITICAL],
        ),
        ChannelConfig(
            name="disabled", type="console", enabled=False,
        ),
    ]


class TestRouter:
    def test_route_info_message(self):
        router = Router(_make_configs())
        msg = Message(body="info", level=Level.INFO)
        matched = router.route(msg)
        names = [ch.name for ch in matched]
        assert "console" in names
        assert "slack-alerts" not in names  # needs tags

    def test_route_error_with_tags(self):
        router = Router(_make_configs())
        msg = Message(body="error", level=Level.ERROR, tags=["alerts"])
        matched = router.route(msg)
        names = [ch.name for ch in matched]
        assert "console" in names
        assert "slack-alerts" in names

    def test_route_critical(self):
        router = Router(_make_configs())
        msg = Message(body="critical", level=Level.CRITICAL, tags=["alerts"])
        matched = router.route(msg)
        names = [ch.name for ch in matched]
        assert "console" in names
        assert "slack-alerts" in names
        assert "email-critical" in names

    def test_disabled_excluded(self):
        router = Router(_make_configs())
        msg = Message(body="test", level=Level.INFO)
        matched = router.route(msg)
        names = [ch.name for ch in matched]
        assert "disabled" not in names

    def test_tag_mismatch(self):
        router = Router(_make_configs())
        msg = Message(body="error", level=Level.ERROR, tags=["deploy"])
        matched = router.route(msg)
        names = [ch.name for ch in matched]
        assert "slack-alerts" not in names  # requires "alerts" tag

    def test_send_returns_results(self, capsys):
        router = Router(_make_configs())
        msg = Message(body="test", level=Level.INFO)
        results = router.send(msg)
        assert len(results) >= 1
        assert all(r.success for r in results)

    def test_send_to_specific(self, capsys):
        router = Router(_make_configs())
        msg = Message(body="test", level=Level.INFO)
        results = router.send_to(msg, ["console"])
        assert len(results) == 1
        assert results[0].channel == "console"

    def test_send_to_nonexistent(self, capsys):
        router = Router(_make_configs())
        msg = Message(body="test", level=Level.INFO)
        results = router.send_to(msg, ["nonexistent"])
        assert len(results) == 0

    def test_channels_property(self):
        configs = _make_configs()
        router = Router(configs)
        # disabled channel excluded
        assert len(router.channels) == 3

    def test_empty_router(self):
        router = Router([])
        msg = Message(body="test")
        assert router.route(msg) == []
        assert router.send(msg) == []

    def test_channel_without_tags_matches_any(self):
        """Console has no tag filter, should match any message."""
        router = Router(_make_configs())
        msg = Message(body="test", level=Level.DEBUG, tags=["random"])
        matched = router.route(msg)
        names = [ch.name for ch in matched]
        assert "console" in names
