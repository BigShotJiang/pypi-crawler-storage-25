"""Tests for notifykit.formatter."""

import pytest

from notifykit.formatter import convert_format, format_message
from notifykit.models import Format, Level, Message


class TestFormatMessage:
    def test_plain(self):
        msg = Message(body="hello", level=Level.INFO, title="Title", tags=["t1"])
        result = format_message(msg, Format.PLAIN)
        assert "[INFO]" in result
        assert "Title" in result
        assert "hello" in result
        assert "t1" in result

    def test_markdown(self):
        msg = Message(body="hello", title="Title", tags=["t1", "t2"])
        result = format_message(msg, Format.MARKDOWN)
        assert "## Title" in result
        assert "**Level:**" in result
        assert "`t1`" in result

    def test_html(self):
        msg = Message(body="hello", title="Title", level=Level.ERROR, tags=["a"])
        result = format_message(msg, Format.HTML)
        assert "<h2>" in result
        assert "Title" in result
        assert "ERROR" in result
        assert "<code>a</code>" in result

    def test_plain_no_title(self):
        msg = Message(body="no title")
        result = format_message(msg, Format.PLAIN)
        assert "[INFO]" in result
        assert "no title" in result

    def test_markdown_no_tags(self):
        msg = Message(body="body only")
        result = format_message(msg, Format.MARKDOWN)
        assert "body only" in result
        assert "Tags" not in result

    def test_html_no_tags(self):
        msg = Message(body="body only")
        result = format_message(msg, Format.HTML)
        assert "body only" in result
        assert "Tags" not in result

    def test_default_format(self):
        msg = Message(body="test", format=Format.MARKDOWN)
        result = format_message(msg)
        assert "**Level:**" in result

    def test_html_escaping(self):
        msg = Message(body="<script>alert('xss')</script>")
        result = format_message(msg, Format.HTML)
        assert "<script>" not in result
        assert "&lt;script&gt;" in result

    def test_all_levels_have_colors(self):
        for level in Level:
            msg = Message(body="test", level=level)
            result = format_message(msg, Format.HTML)
            assert level.value.upper() in result


class TestConvertFormat:
    def test_same_format(self):
        assert convert_format("hello", Format.PLAIN, Format.PLAIN) == "hello"

    def test_plain_to_markdown(self):
        result = convert_format("hello world", Format.PLAIN, Format.MARKDOWN)
        assert result == "hello world"

    def test_plain_to_html(self):
        result = convert_format("hello", Format.PLAIN, Format.HTML)
        assert "<p>" in result

    def test_html_to_plain(self):
        result = convert_format("<p>hello</p>", Format.HTML, Format.PLAIN)
        assert result == "hello"

    def test_markdown_to_plain(self):
        result = convert_format("**bold** and *italic*", Format.MARKDOWN, Format.PLAIN)
        assert "bold" in result
        assert "**" not in result
        assert "*" not in result

    def test_html_escaping_in_conversion(self):
        result = convert_format("a < b & c > d", Format.PLAIN, Format.HTML)
        assert "&lt;" in result
        assert "&amp;" in result
