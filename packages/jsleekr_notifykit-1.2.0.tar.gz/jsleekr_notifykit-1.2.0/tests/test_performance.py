"""Performance tests for notifykit — batch sending and rate limiter under load."""

from __future__ import annotations

import time

import pytest

from notifykit.channels.console import ConsoleChannel
from notifykit.models import ChannelConfig, Level, Message
from notifykit.rate_limiter import RateLimiter
from notifykit.router import Router


class TestBatchPerformance:
    """Verify that sending 100 notifications completes in reasonable time."""

    def test_100_notifications_via_router(self, capsys):
        """Send 100 messages through router to console channel."""
        configs = [
            ChannelConfig(
                name="console", type="console", enabled=True,
                levels=list(Level),
                settings={"color": False},
            ),
        ]
        router = Router(configs)

        start = time.monotonic()
        results = []
        for i in range(100):
            msg = Message(
                body=f"Batch message #{i}",
                level=Level.INFO,
                title=f"Batch {i}",
            )
            batch_results = router.send(msg)
            results.extend(batch_results)
        elapsed = time.monotonic() - start

        assert len(results) == 100
        assert all(r.success for r in results)
        # 100 console sends should complete in under 2 seconds
        assert elapsed < 2.0, f"Batch of 100 took {elapsed:.2f}s (expected < 2s)"

    def test_100_direct_channel_sends(self, capsys):
        """Send 100 messages directly to console channel."""
        cfg = ChannelConfig(
            name="perf-console", type="console", enabled=True,
            settings={"color": False},
        )
        ch = ConsoleChannel(cfg)

        start = time.monotonic()
        results = []
        for i in range(100):
            msg = Message(body=f"Direct #{i}", level=Level.INFO)
            results.append(ch._timed_send(msg))
        elapsed = time.monotonic() - start

        assert len(results) == 100
        assert all(r.success for r in results)
        assert elapsed < 2.0

    def test_100_messages_with_all_levels(self, capsys):
        """Send 100 messages across all severity levels."""
        configs = [
            ChannelConfig(
                name="all-levels", type="console", enabled=True,
                levels=list(Level),
                settings={"color": False},
            ),
        ]
        router = Router(configs)
        levels = list(Level)

        results = []
        for i in range(100):
            msg = Message(
                body=f"Level test #{i}",
                level=levels[i % len(levels)],
                tags=["perf"],
            )
            results.extend(router.send(msg))

        assert len(results) == 100
        assert all(r.success for r in results)


class TestRateLimiterUnderLoad:
    """Verify rate limiter correctness under rapid requests."""

    def test_rate_limiter_enforces_limit(self):
        """Rate limiter should block requests beyond the configured limit."""
        rl = RateLimiter()
        rl.configure("test-ch", max_per_minute=10)

        allowed = sum(1 for _ in range(20) if rl.allow("test-ch"))
        # Should allow exactly 10 (the initial bucket is full at 10)
        assert allowed == 10

    def test_rate_limiter_100_rapid_requests(self):
        """100 rapid requests should only allow up to the bucket size."""
        rl = RateLimiter()
        rl.configure("load-ch", max_per_minute=30)

        allowed = sum(1 for _ in range(100) if rl.allow("load-ch"))
        assert allowed == 30  # bucket starts full at 30

    def test_rate_limiter_wait_time_accuracy(self):
        """wait_time should return a positive value when bucket is empty."""
        rl = RateLimiter()
        rl.configure("wait-ch", max_per_minute=5)

        # Exhaust all tokens
        for _ in range(5):
            rl.allow("wait-ch")

        wait = rl.wait_time("wait-ch")
        assert wait > 0
        # At 5/min = 1 token per 12 seconds, wait should be around 12s
        assert wait <= 13.0

    def test_rate_limiter_reset_restores_capacity(self):
        """After reset, full capacity should be available again."""
        rl = RateLimiter()
        rl.configure("reset-ch", max_per_minute=10)

        # Exhaust all
        for _ in range(10):
            rl.allow("reset-ch")
        assert not rl.allow("reset-ch")

        # Reset and verify
        rl.reset("reset-ch")
        allowed_after = sum(1 for _ in range(10) if rl.allow("reset-ch"))
        assert allowed_after == 10

    def test_unconfigured_channel_always_allows(self):
        """Channels without rate limits should always be allowed."""
        rl = RateLimiter()
        allowed = sum(1 for _ in range(100) if rl.allow("no-limit"))
        assert allowed == 100
