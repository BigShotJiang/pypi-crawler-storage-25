"""Tests for notifykit.retry."""

import pytest

from notifykit.models import Message, SendResult
from notifykit.retry import calculate_delay, retry_send


def _make_send_fn(fail_count: int):
    """Create a send function that fails N times then succeeds."""
    calls = {"count": 0}

    def send_fn(msg: Message) -> SendResult:
        calls["count"] += 1
        if calls["count"] <= fail_count:
            return SendResult(
                channel="test", success=False,
                message_id=msg.id, error=f"Fail #{calls['count']}",
            )
        return SendResult(channel="test", success=True, message_id=msg.id)

    return send_fn, calls


class TestRetrySend:
    def test_success_first_try(self):
        fn, calls = _make_send_fn(0)
        msg = Message(body="test")
        result = retry_send(fn, msg, max_retries=3, base_delay=0.01)
        assert result.success
        assert calls["count"] == 1

    def test_success_after_retries(self):
        fn, calls = _make_send_fn(2)
        msg = Message(body="test")
        result = retry_send(fn, msg, max_retries=3, base_delay=0.01)
        assert result.success
        assert calls["count"] == 3

    def test_all_retries_fail(self):
        fn, calls = _make_send_fn(10)
        msg = Message(body="test")
        result = retry_send(fn, msg, max_retries=2, base_delay=0.01)
        assert not result.success
        assert calls["count"] == 3  # initial + 2 retries

    def test_zero_retries(self):
        fn, calls = _make_send_fn(1)
        msg = Message(body="test")
        result = retry_send(fn, msg, max_retries=0, base_delay=0.01)
        assert not result.success
        assert calls["count"] == 1


class TestCalculateDelay:
    def test_first_attempt(self):
        assert calculate_delay(0) == 1.0

    def test_second_attempt(self):
        assert calculate_delay(1) == 2.0

    def test_third_attempt(self):
        assert calculate_delay(2) == 4.0

    def test_max_delay_cap(self):
        delay = calculate_delay(10, base_delay=1.0, max_delay=30.0)
        assert delay == 30.0

    def test_custom_backoff(self):
        delay = calculate_delay(2, base_delay=0.5, backoff_factor=3.0)
        assert delay == 0.5 * 9  # 0.5 * 3^2
