"""Stress tests — 1000 notifications, concurrent channels, large payloads.

Verifies notifykit handles high volume without crashes, memory leaks,
or correctness issues.
"""

from __future__ import annotations

import time

import pytest

from notifykit.audit import AuditLog
from notifykit.channels.console import ConsoleChannel
from notifykit.models import ChannelConfig, Level, Message
from notifykit.rate_limiter import RateLimiter
from notifykit.router import Router
from notifykit.templates import render


class TestStress1000:
    """Send 1000 notifications through the router."""

    def test_1000_notifications_via_router(self, capsys):
        """1000 messages through router to console should complete under 5s."""
        configs = [
            ChannelConfig(
                name="console", type="console", enabled=True,
                levels=list(Level),
                settings={"color": False},
            ),
        ]
        router = Router(configs)

        start = time.monotonic()
        results = []
        for i in range(1000):
            msg = Message(
                body=f"Stress message #{i}",
                level=Level.INFO,
            )
            results.extend(router.send(msg))
        elapsed = time.monotonic() - start

        assert len(results) == 1000
        assert all(r.success for r in results)
        assert elapsed < 5.0, f"1000 sends took {elapsed:.2f}s (expected < 5s)"

    def test_1000_with_all_levels_and_tags(self, capsys):
        """1000 messages with varying levels and tags across multiple channels."""
        configs = [
            ChannelConfig(
                name="all", type="console", enabled=True,
                levels=list(Level),
                settings={"color": False},
            ),
            ChannelConfig(
                name="errors-only", type="console", enabled=True,
                levels=[Level.ERROR, Level.CRITICAL],
                settings={"color": False},
            ),
            ChannelConfig(
                name="tagged", type="console", enabled=True,
                levels=list(Level),
                tags=["special"],
                settings={"color": False},
            ),
        ]
        router = Router(configs)
        levels = list(Level)

        start = time.monotonic()
        all_results = []
        for i in range(1000):
            level = levels[i % len(levels)]
            tags = ["special"] if i % 10 == 0 else []
            msg = Message(body=f"msg {i}", level=level, tags=tags)
            all_results.extend(router.send(msg))
        elapsed = time.monotonic() - start

        assert all(r.success for r in all_results)
        assert elapsed < 10.0, f"1000 multi-channel sends took {elapsed:.2f}s"

        # Verify routing correctness
        by_channel: dict[str, int] = {}
        for r in all_results:
            by_channel[r.channel] = by_channel.get(r.channel, 0) + 1

        assert by_channel["all"] == 1000  # all levels, no tag filter
        # errors-only: ERROR + CRITICAL = 2/5 of messages
        assert by_channel["errors-only"] == 400
        # tagged: only messages with "special" tag (every 10th)
        assert by_channel["tagged"] == 100


class TestStressConcurrentChannels:
    """Multiple channels processing simultaneously."""

    def test_5_channels_1000_messages(self, capsys):
        """5 console channels each receiving all 1000 messages."""
        configs = [
            ChannelConfig(
                name=f"ch-{i}", type="console", enabled=True,
                levels=list(Level),
                settings={"color": False},
            )
            for i in range(5)
        ]
        router = Router(configs)

        results = []
        for i in range(1000):
            msg = Message(body=f"multi-ch #{i}", level=Level.INFO)
            results.extend(router.send(msg))

        assert len(results) == 5000  # 1000 msgs * 5 channels
        assert all(r.success for r in results)

        # Verify each channel got exactly 1000
        by_channel: dict[str, int] = {}
        for r in results:
            by_channel[r.channel] = by_channel.get(r.channel, 0) + 1
        for i in range(5):
            assert by_channel[f"ch-{i}"] == 1000


class TestStressAudit:
    """Stress the audit log with large volumes."""

    def test_1000_audit_entries(self, tmp_path):
        """Record and query 1000 audit entries."""
        audit = AuditLog(tmp_path / "stress.jsonl")

        from notifykit.models import SendResult

        for i in range(1000):
            result = SendResult(
                channel=f"ch-{i % 5}",
                success=i % 7 != 0,  # ~14% failure rate
                message_id=f"m-{i}",
                elapsed_ms=float(i % 100),
            )
            audit.record(result)

        assert len(audit.entries) == 1000

        stats = audit.stats()
        assert stats["total"] == 1000
        assert stats["success"] + stats["failed"] == 1000

        # Query operations should work at scale
        failures = audit.query(success=False)
        assert len(failures) > 0

        ch0_entries = audit.query(channel="ch-0")
        assert len(ch0_entries) == 200  # 1000/5

        limited = audit.query(limit=10)
        assert len(limited) == 10

    def test_audit_file_reload_1000(self, tmp_path):
        """Write 1000 entries then reload from file."""
        audit_file = tmp_path / "reload.jsonl"
        audit1 = AuditLog(audit_file)

        from notifykit.models import SendResult

        for i in range(1000):
            audit1.record(SendResult(
                channel="test", success=True, message_id=f"m-{i}",
            ))

        # Reload
        audit2 = AuditLog(audit_file)
        loaded = audit2.load_from_file()
        assert loaded == 1000
        assert len(audit2.entries) == 1000


class TestStressTemplates:
    """Stress template rendering."""

    def test_1000_template_renders(self):
        """Render a template 1000 times with different variables."""
        tpl = "Deploy {{status}}: {{service}} v{{version}} to {{env}}"

        start = time.monotonic()
        for i in range(1000):
            result = render(tpl, {
                "status": "success" if i % 2 == 0 else "failed",
                "service": f"svc-{i}",
                "version": f"1.{i}.0",
                "env": "production",
            })
            assert "svc-" in result
        elapsed = time.monotonic() - start

        assert elapsed < 2.0, f"1000 renders took {elapsed:.2f}s"


class TestStressLargePayload:
    """Test with unusually large message bodies."""

    def test_large_body_message(self, capsys):
        """A 100KB message body should send without issues."""
        large_body = "x" * 100_000
        cfg = ChannelConfig(
            name="console", type="console", enabled=True,
            settings={"color": False},
        )
        ch = ConsoleChannel(cfg)
        msg = Message(body=large_body, level=Level.INFO)
        result = ch._timed_send(msg)
        assert result.success

    def test_many_tags(self, capsys):
        """Message with 100 tags should route correctly."""
        configs = [
            ChannelConfig(
                name="all", type="console", enabled=True,
                levels=list(Level),
                settings={"color": False},
            ),
            ChannelConfig(
                name="tagged", type="console", enabled=True,
                levels=list(Level),
                tags=["tag-50"],
                settings={"color": False},
            ),
        ]
        router = Router(configs)

        tags = [f"tag-{i}" for i in range(100)]
        msg = Message(body="many tags", level=Level.INFO, tags=tags)
        results = router.send(msg)

        channel_names = {r.channel for r in results}
        assert "all" in channel_names
        assert "tagged" in channel_names  # tag-50 matches
