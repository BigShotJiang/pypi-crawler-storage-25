"""Tests for all notification channels (mock HTTP)."""

import smtplib
from unittest.mock import MagicMock, patch

import pytest
import requests
import responses

from notifykit.channels.console import ConsoleChannel
from notifykit.channels.discord import DiscordChannel
from notifykit.channels.email_channel import EmailChannel
from notifykit.channels.registry import create_channel, get_channel_class, list_channel_types, register_channel
from notifykit.channels.slack import SlackChannel
from notifykit.channels.telegram import TelegramChannel
from notifykit.channels.webhook import WebhookChannel
from notifykit.channels.base import BaseChannel
from notifykit.models import ChannelConfig, Format, Level, Message


# ── Console Channel ──


class TestConsoleChannel:
    def test_send_info(self, console_config, sample_message, capsys):
        ch = ConsoleChannel(console_config)
        result = ch.send(sample_message)
        assert result.success
        captured = capsys.readouterr()
        assert "INFO" in captured.out
        assert "Hello from tests" in captured.out

    def test_send_error_to_stderr(self, console_config, error_message, capsys):
        ch = ConsoleChannel(console_config)
        result = ch.send(error_message)
        assert result.success
        captured = capsys.readouterr()
        assert "ERROR" in captured.err

    def test_send_critical_to_stderr(self, console_config, critical_message, capsys):
        ch = ConsoleChannel(console_config)
        result = ch.send(critical_message)
        assert result.success
        captured = capsys.readouterr()
        assert "CRITICAL" in captured.err

    def test_no_color(self, sample_message, capsys):
        cfg = ChannelConfig(name="console", type="console", settings={"color": False})
        ch = ConsoleChannel(cfg)
        ch.send(sample_message)
        captured = capsys.readouterr()
        assert "\033[" not in captured.out

    def test_with_title(self, console_config, capsys):
        msg = Message(body="body text", title="My Title")
        ch = ConsoleChannel(console_config)
        ch.send(msg)
        captured = capsys.readouterr()
        assert "My Title" in captured.out

    def test_debug_level(self, console_config, capsys):
        msg = Message(body="debug info", level=Level.DEBUG)
        ch = ConsoleChannel(console_config)
        ch.send(msg)
        captured = capsys.readouterr()
        assert "DEBUG" in captured.out

    def test_warning_level(self, console_config, capsys):
        msg = Message(body="warning info", level=Level.WARNING)
        ch = ConsoleChannel(console_config)
        ch.send(msg)
        captured = capsys.readouterr()
        assert "WARNING" in captured.out


# ── Slack Channel ──


class TestSlackChannel:
    @responses.activate
    def test_send_success(self, slack_config, sample_message):
        responses.add(responses.POST, slack_config.settings["webhook_url"], status=200)
        ch = SlackChannel(slack_config)
        result = ch.send(sample_message)
        assert result.success
        assert len(responses.calls) == 1

    @responses.activate
    def test_send_failure(self, slack_config, sample_message):
        responses.add(
            responses.POST, slack_config.settings["webhook_url"],
            status=500, body="server error",
        )
        ch = SlackChannel(slack_config)
        result = ch.send(sample_message)
        assert not result.success
        assert "500" in result.error

    def test_missing_webhook_url(self, sample_message):
        cfg = ChannelConfig(name="slack", type="slack", settings={})
        ch = SlackChannel(cfg)
        result = ch.send(sample_message)
        assert not result.success
        assert "webhook_url" in result.error

    @responses.activate
    def test_with_channel_override(self, slack_config, sample_message):
        slack_config.settings["channel"] = "#test-channel"
        slack_config.settings["username"] = "bot"
        responses.add(responses.POST, slack_config.settings["webhook_url"], status=200)
        ch = SlackChannel(slack_config)
        result = ch.send(sample_message)
        assert result.success
        payload = responses.calls[0].request.body
        assert b"#test-channel" in payload

    @responses.activate
    def test_with_tags(self, slack_config):
        responses.add(responses.POST, slack_config.settings["webhook_url"], status=200)
        msg = Message(body="tagged", tags=["deploy", "prod"])
        ch = SlackChannel(slack_config)
        ch.send(msg)
        payload = responses.calls[0].request.body
        assert b"deploy" in payload

    @responses.activate
    def test_with_title(self, slack_config):
        responses.add(responses.POST, slack_config.settings["webhook_url"], status=200)
        msg = Message(body="body", title="Important")
        ch = SlackChannel(slack_config)
        ch.send(msg)
        payload = responses.calls[0].request.body
        assert b"Important" in payload


# ── Discord Channel ──


class TestDiscordChannel:
    @responses.activate
    def test_send_success(self, discord_config, sample_message):
        responses.add(responses.POST, discord_config.settings["webhook_url"], status=204)
        ch = DiscordChannel(discord_config)
        result = ch.send(sample_message)
        assert result.success

    @responses.activate
    def test_send_200_success(self, discord_config, sample_message):
        responses.add(responses.POST, discord_config.settings["webhook_url"], status=200)
        ch = DiscordChannel(discord_config)
        result = ch.send(sample_message)
        assert result.success

    @responses.activate
    def test_send_failure(self, discord_config, sample_message):
        responses.add(
            responses.POST, discord_config.settings["webhook_url"],
            status=400, body="bad request",
        )
        ch = DiscordChannel(discord_config)
        result = ch.send(sample_message)
        assert not result.success

    def test_missing_webhook(self, sample_message):
        cfg = ChannelConfig(name="discord", type="discord", settings={})
        ch = DiscordChannel(cfg)
        result = ch.send(sample_message)
        assert not result.success

    @responses.activate
    def test_with_username(self, discord_config, sample_message):
        discord_config.settings["username"] = "NotifyBot"
        responses.add(responses.POST, discord_config.settings["webhook_url"], status=204)
        ch = DiscordChannel(discord_config)
        ch.send(sample_message)
        payload = responses.calls[0].request.body
        assert b"NotifyBot" in payload

    @responses.activate
    def test_embed_color_by_level(self, discord_config):
        responses.add(responses.POST, discord_config.settings["webhook_url"], status=204)
        msg = Message(body="error!", level=Level.ERROR)
        ch = DiscordChannel(discord_config)
        ch.send(msg)
        assert len(responses.calls) == 1


# ── Telegram Channel ──


class TestTelegramChannel:
    @responses.activate
    def test_send_success(self, telegram_config, sample_message):
        url = "https://api.telegram.org/bot123:ABC/sendMessage"
        responses.add(responses.POST, url, json={"ok": True}, status=200)
        ch = TelegramChannel(telegram_config)
        result = ch.send(sample_message)
        assert result.success

    @responses.activate
    def test_send_failure(self, telegram_config, sample_message):
        url = "https://api.telegram.org/bot123:ABC/sendMessage"
        responses.add(
            responses.POST, url,
            json={"ok": False, "description": "chat not found"}, status=400,
        )
        ch = TelegramChannel(telegram_config)
        result = ch.send(sample_message)
        assert not result.success

    def test_missing_bot_token(self, sample_message):
        cfg = ChannelConfig(name="tg", type="telegram", settings={"chat_id": "123"})
        ch = TelegramChannel(cfg)
        result = ch.send(sample_message)
        assert not result.success
        assert "bot_token" in result.error

    def test_missing_chat_id(self, sample_message):
        cfg = ChannelConfig(name="tg", type="telegram", settings={"bot_token": "abc"})
        ch = TelegramChannel(cfg)
        result = ch.send(sample_message)
        assert not result.success
        assert "chat_id" in result.error

    @responses.activate
    def test_with_tags(self, telegram_config):
        url = "https://api.telegram.org/bot123:ABC/sendMessage"
        responses.add(responses.POST, url, json={"ok": True}, status=200)
        msg = Message(body="tagged", tags=["deploy"])
        ch = TelegramChannel(telegram_config)
        ch.send(msg)
        payload = responses.calls[0].request.body
        assert b"deploy" in payload

    @responses.activate
    def test_markdown_format(self, telegram_config):
        url = "https://api.telegram.org/bot123:ABC/sendMessage"
        responses.add(responses.POST, url, json={"ok": True}, status=200)
        msg = Message(body="**bold**", format=Format.MARKDOWN)
        ch = TelegramChannel(telegram_config)
        ch.send(msg)
        payload = responses.calls[0].request.body
        assert b"MarkdownV2" in payload


# ── Webhook Channel ──


class TestWebhookChannel:
    @responses.activate
    def test_send_success(self, webhook_config, sample_message):
        responses.add(responses.POST, webhook_config.settings["url"], status=200)
        ch = WebhookChannel(webhook_config)
        result = ch.send(sample_message)
        assert result.success

    @responses.activate
    def test_send_202_accepted(self, webhook_config, sample_message):
        responses.add(responses.POST, webhook_config.settings["url"], status=202)
        ch = WebhookChannel(webhook_config)
        result = ch.send(sample_message)
        assert result.success

    @responses.activate
    def test_send_failure(self, webhook_config, sample_message):
        responses.add(responses.POST, webhook_config.settings["url"], status=500)
        ch = WebhookChannel(webhook_config)
        result = ch.send(sample_message)
        assert not result.success

    def test_missing_url(self, sample_message):
        cfg = ChannelConfig(name="wh", type="webhook", settings={})
        ch = WebhookChannel(cfg)
        result = ch.send(sample_message)
        assert not result.success

    @responses.activate
    def test_custom_headers(self, webhook_config, sample_message):
        webhook_config.settings["headers"] = {"Authorization": "Bearer token123"}
        responses.add(responses.POST, webhook_config.settings["url"], status=200)
        ch = WebhookChannel(webhook_config)
        ch.send(sample_message)
        req = responses.calls[0].request
        assert req.headers["Authorization"] == "Bearer token123"

    @responses.activate
    def test_custom_method(self, webhook_config, sample_message):
        webhook_config.settings["method"] = "PUT"
        responses.add(responses.PUT, webhook_config.settings["url"], status=200)
        ch = WebhookChannel(webhook_config)
        result = ch.send(sample_message)
        assert result.success

    @responses.activate
    def test_payload_includes_message_fields(self, webhook_config, sample_message):
        responses.add(responses.POST, webhook_config.settings["url"], status=200)
        ch = WebhookChannel(webhook_config)
        ch.send(sample_message)
        import json
        payload = json.loads(responses.calls[0].request.body)
        assert payload["level"] == "info"
        assert payload["body"] == "Hello from tests"


# ── Email Channel ──


class TestEmailChannel:
    @patch("notifykit.channels.email_channel.smtplib.SMTP")
    def test_send_success(self, mock_smtp_cls, email_config, sample_message):
        mock_server = MagicMock()
        mock_smtp_cls.return_value = mock_server
        ch = EmailChannel(email_config)
        result = ch.send(sample_message)
        assert result.success
        mock_server.starttls.assert_called_once()
        mock_server.login.assert_called_once_with("user", "pass")
        mock_server.sendmail.assert_called_once()
        mock_server.quit.assert_called_once()

    @patch("notifykit.channels.email_channel.smtplib.SMTP")
    def test_send_failure(self, mock_smtp_cls, email_config, sample_message):
        mock_smtp_cls.side_effect = smtplib.SMTPException("Connection failed")
        ch = EmailChannel(email_config)
        result = ch.send(sample_message)
        assert not result.success
        assert "SMTP error" in result.error

    def test_missing_smtp_host(self, sample_message):
        cfg = ChannelConfig(name="e", type="email", settings={"from_addr": "a@b.com", "to_addrs": ["c@d.com"]})
        ch = EmailChannel(cfg)
        result = ch.send(sample_message)
        assert not result.success
        assert "smtp_host" in result.error

    def test_missing_from_addr(self, sample_message):
        cfg = ChannelConfig(name="e", type="email", settings={"smtp_host": "h", "to_addrs": ["c@d.com"]})
        ch = EmailChannel(cfg)
        result = ch.send(sample_message)
        assert not result.success
        assert "from_addr" in result.error

    def test_missing_to_addrs(self, sample_message):
        cfg = ChannelConfig(name="e", type="email", settings={"smtp_host": "h", "from_addr": "a@b.com"})
        ch = EmailChannel(cfg)
        result = ch.send(sample_message)
        assert not result.success
        assert "to_addrs" in result.error

    @patch("notifykit.channels.email_channel.smtplib.SMTP")
    def test_html_format(self, mock_smtp_cls, email_config):
        mock_server = MagicMock()
        mock_smtp_cls.return_value = mock_server
        msg = Message(body="<b>Bold</b>", format=Format.HTML, title="HTML Test")
        ch = EmailChannel(email_config)
        result = ch.send(msg)
        assert result.success

    @patch("notifykit.channels.email_channel.smtplib.SMTP")
    def test_string_to_addrs(self, mock_smtp_cls, email_config):
        mock_server = MagicMock()
        mock_smtp_cls.return_value = mock_server
        email_config.settings["to_addrs"] = "single@test.com"
        ch = EmailChannel(email_config)
        result = ch.send(Message(body="test"))
        assert result.success

    @patch("notifykit.channels.email_channel.smtplib.SMTP")
    def test_no_tls(self, mock_smtp_cls, email_config):
        mock_server = MagicMock()
        mock_smtp_cls.return_value = mock_server
        email_config.settings["use_tls"] = False
        ch = EmailChannel(email_config)
        result = ch.send(Message(body="test"))
        assert result.success
        mock_server.starttls.assert_not_called()

    @patch("notifykit.channels.email_channel.smtplib.SMTP")
    def test_no_auth(self, mock_smtp_cls, email_config):
        mock_server = MagicMock()
        mock_smtp_cls.return_value = mock_server
        del email_config.settings["username"]
        del email_config.settings["password"]
        ch = EmailChannel(email_config)
        result = ch.send(Message(body="test"))
        assert result.success
        mock_server.login.assert_not_called()


# ── Registry ──


class TestRegistry:
    def test_list_types(self):
        types = list_channel_types()
        assert "console" in types
        assert "slack" in types
        assert "discord" in types
        assert "email" in types
        assert "telegram" in types
        assert "webhook" in types

    def test_get_known_class(self):
        assert get_channel_class("console") is ConsoleChannel
        assert get_channel_class("slack") is SlackChannel

    def test_get_unknown_class(self):
        assert get_channel_class("fax") is None

    def test_create_channel(self, console_config):
        ch = create_channel(console_config)
        assert isinstance(ch, ConsoleChannel)

    def test_create_unknown_channel(self):
        cfg = ChannelConfig(name="fax", type="fax")
        with pytest.raises(ValueError, match="Unknown channel type"):
            create_channel(cfg)

    def test_register_custom(self):
        class CustomChannel(BaseChannel):
            def send(self, message):
                return self._make_result(message, True)

        register_channel("custom", CustomChannel)
        assert get_channel_class("custom") is CustomChannel
        cfg = ChannelConfig(name="my-custom", type="custom")
        ch = create_channel(cfg)
        assert isinstance(ch, CustomChannel)


# ── BaseChannel ──


class TestBaseChannel:
    def test_repr(self, console_config):
        ch = ConsoleChannel(console_config)
        assert "ConsoleChannel" in repr(ch)
        assert "console" in repr(ch)

    def test_timed_send(self, console_config, sample_message, capsys):
        ch = ConsoleChannel(console_config)
        result = ch._timed_send(sample_message)
        assert result.success
        assert result.elapsed_ms >= 0

    def test_timed_send_catches_exception(self):
        """_timed_send should catch exceptions and return a failed result."""
        class FailChannel(BaseChannel):
            def send(self, message):
                raise RuntimeError("boom")

        cfg = ChannelConfig(name="fail", type="console")
        ch = FailChannel(cfg)
        msg = Message(body="test")
        result = ch._timed_send(msg)
        assert not result.success
        assert "boom" in result.error
        assert result.elapsed_ms >= 0


class TestSecuritySanitization:
    """Security: verify that secrets are redacted from error messages."""

    def test_slack_url_redacted_in_error(self):
        """Slack webhook URLs should be redacted in error output."""
        from notifykit.channels.base import sanitize_error
        error = "Connection error: https://hooks.slack.com/services/T00/B00/xxxx123"
        sanitized = sanitize_error(error)
        assert "xxxx123" not in sanitized
        assert "[REDACTED]" in sanitized

    def test_discord_url_redacted_in_error(self):
        """Discord webhook URLs should be redacted in error output."""
        from notifykit.channels.base import sanitize_error
        error = "Failed: https://discord.com/api/webhooks/123456/secret-token-here"
        sanitized = sanitize_error(error)
        assert "secret-token-here" not in sanitized
        assert "[REDACTED]" in sanitized

    def test_telegram_token_redacted_in_error(self):
        """Telegram bot tokens should be redacted in error output."""
        from notifykit.channels.base import sanitize_error
        error = "Request failed: https://api.telegram.org/bot123:ABCsecret/sendMessage"
        sanitized = sanitize_error(error)
        assert "ABCsecret" not in sanitized
        assert "[REDACTED]" in sanitized

    def test_bearer_token_redacted(self):
        """Bearer tokens should be redacted."""
        from notifykit.channels.base import sanitize_error
        error = "Auth failed with Bearer eyJhbGciOiJIUzI1NiJ9.secret"
        sanitized = sanitize_error(error)
        assert "eyJhbGciOiJIUzI1NiJ9" not in sanitized
        assert "[REDACTED]" in sanitized

    def test_timed_send_sanitizes_errors(self):
        """_timed_send should sanitize error messages containing secrets."""
        class LeakyChannel(BaseChannel):
            def send(self, message):
                return self._make_result(
                    message, False,
                    error="Slack returned 403: https://hooks.slack.com/services/T00/B00/xxxx"
                )

        cfg = ChannelConfig(name="leak", type="console")
        ch = LeakyChannel(cfg)
        msg = Message(body="test")
        result = ch._timed_send(msg)
        assert "xxxx" not in result.error
        assert "[REDACTED]" in result.error

    def test_timed_send_sanitizes_exceptions(self):
        """_timed_send should sanitize exception messages containing secrets."""
        class ThrowChannel(BaseChannel):
            def send(self, message):
                raise RuntimeError(
                    "Connection to https://hooks.slack.com/services/T00/B00/xxxx failed"
                )

        cfg = ChannelConfig(name="throw", type="console")
        ch = ThrowChannel(cfg)
        msg = Message(body="test")
        result = ch._timed_send(msg)
        assert "xxxx" not in result.error
        assert "[REDACTED]" in result.error


class TestEdgeCases:
    """Coverage gap tests for edge cases across channels."""

    @responses.activate
    def test_slack_no_title_uses_level(self, slack_config):
        """Slack without title should fall back to level as header."""
        responses.add(responses.POST, slack_config.settings["webhook_url"], status=200)
        msg = Message(body="no title message", level=Level.WARNING)
        ch = SlackChannel(slack_config)
        ch.send(msg)
        payload = responses.calls[0].request.body
        assert b"WARNING" in payload

    @responses.activate
    def test_discord_with_tags_footer(self, discord_config):
        """Discord should include tags in embed footer."""
        responses.add(responses.POST, discord_config.settings["webhook_url"], status=204)
        msg = Message(body="tagged", title="Title", tags=["deploy", "prod"])
        ch = DiscordChannel(discord_config)
        ch.send(msg)
        import json as json_mod
        payload = json_mod.loads(responses.calls[0].request.body)
        assert "footer" in payload["embeds"][0]
        assert "deploy" in payload["embeds"][0]["footer"]["text"]

    @responses.activate
    def test_telegram_disable_preview(self, telegram_config):
        """Telegram with disable_preview should include the flag."""
        telegram_config.settings["disable_preview"] = True
        url = "https://api.telegram.org/bot123:ABC/sendMessage"
        responses.add(responses.POST, url, json={"ok": True}, status=200)
        msg = Message(body="preview test")
        ch = TelegramChannel(telegram_config)
        ch.send(msg)
        import json as json_mod
        payload = json_mod.loads(responses.calls[0].request.body)
        assert payload["disable_web_page_preview"] is True

    @responses.activate
    def test_telegram_non_json_response(self, telegram_config):
        """Telegram returning non-JSON body should handle gracefully."""
        url = "https://api.telegram.org/bot123:ABC/sendMessage"
        responses.add(responses.POST, url, body="not json", status=500)
        msg = Message(body="test")
        ch = TelegramChannel(telegram_config)
        result = ch.send(msg)
        assert not result.success

    @responses.activate
    def test_webhook_custom_payload(self, webhook_config, sample_message):
        """Webhook with custom payload template should use it."""
        webhook_config.settings["payload"] = {"custom": "data"}
        responses.add(responses.POST, webhook_config.settings["url"], status=200)
        ch = WebhookChannel(webhook_config)
        result = ch.send(sample_message)
        assert result.success
        import json as json_mod
        payload = json_mod.loads(responses.calls[0].request.body)
        assert payload == {"custom": "data"}

    @responses.activate
    def test_webhook_custom_success_codes(self, webhook_config, sample_message):
        """Webhook should respect custom success_codes."""
        webhook_config.settings["success_codes"] = [200, 201]
        responses.add(responses.POST, webhook_config.settings["url"], status=204)
        ch = WebhookChannel(webhook_config)
        result = ch.send(sample_message)
        assert not result.success  # 204 not in custom success_codes

    @responses.activate
    def test_slack_connection_error(self, slack_config, sample_message):
        """Slack should handle connection errors gracefully."""
        responses.add(
            responses.POST, slack_config.settings["webhook_url"],
            body=requests.ConnectionError("DNS resolution failed"),
        )
        ch = SlackChannel(slack_config)
        result = ch.send(sample_message)
        assert not result.success
        assert "Connection error" in result.error

    @responses.activate
    def test_discord_timeout(self, discord_config, sample_message):
        """Discord should handle timeout errors gracefully."""
        responses.add(
            responses.POST, discord_config.settings["webhook_url"],
            body=requests.Timeout("timed out"),
        )
        ch = DiscordChannel(discord_config)
        result = ch.send(sample_message)
        assert not result.success
        assert "timed out" in result.error

    @responses.activate
    def test_webhook_connection_error(self, webhook_config, sample_message):
        """Webhook should handle connection errors gracefully."""
        responses.add(
            responses.POST, webhook_config.settings["url"],
            body=requests.ConnectionError("Connection refused"),
        )
        ch = WebhookChannel(webhook_config)
        result = ch.send(sample_message)
        assert not result.success
        assert "Connection error" in result.error

    @responses.activate
    def test_telegram_timeout(self, telegram_config, sample_message):
        """Telegram should handle timeout errors gracefully."""
        url = "https://api.telegram.org/bot123:ABC/sendMessage"
        responses.add(
            responses.POST, url,
            body=requests.Timeout("request timed out"),
        )
        ch = TelegramChannel(telegram_config)
        result = ch.send(sample_message)
        assert not result.success
        assert "timed out" in result.error

    @patch("notifykit.channels.email_channel.smtplib.SMTP")
    def test_email_subject_fallback(self, mock_smtp_cls):
        """Email without title should use level-based subject."""
        mock_server = MagicMock()
        mock_smtp_cls.return_value = mock_server
        cfg = ChannelConfig(name="e", type="email", settings={
            "smtp_host": "h", "from_addr": "a@b.com",
            "to_addrs": ["c@d.com"], "use_tls": False,
        })
        ch = EmailChannel(cfg)
        msg = Message(body="no title", level=Level.ERROR)
        result = ch.send(msg)
        assert result.success
        call_args = mock_server.sendmail.call_args
        raw_msg = call_args[0][2]
        assert "ERROR" in raw_msg
