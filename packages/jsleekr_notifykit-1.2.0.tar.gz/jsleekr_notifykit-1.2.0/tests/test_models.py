"""Tests for notifykit.models."""

import pytest

from notifykit.models import ChannelConfig, Format, Level, Message, SendResult


class TestLevel:
    def test_from_str_valid(self):
        assert Level.from_str("info") == Level.INFO
        assert Level.from_str("INFO") == Level.INFO
        assert Level.from_str("Warning") == Level.WARNING

    def test_from_str_invalid(self):
        with pytest.raises(ValueError, match="Invalid level"):
            Level.from_str("unknown")

    def test_all_values(self):
        assert Level.DEBUG.value == "debug"
        assert Level.INFO.value == "info"
        assert Level.WARNING.value == "warning"
        assert Level.ERROR.value == "error"
        assert Level.CRITICAL.value == "critical"


class TestFormat:
    def test_values(self):
        assert Format.PLAIN.value == "plain"
        assert Format.MARKDOWN.value == "markdown"
        assert Format.HTML.value == "html"


class TestMessage:
    def test_defaults(self):
        msg = Message(body="hello")
        assert msg.body == "hello"
        assert msg.level == Level.INFO
        assert msg.title is None
        assert msg.tags == []
        assert msg.format == Format.PLAIN
        assert msg.id  # auto-generated
        assert msg.timestamp > 0

    def test_with_all_fields(self):
        msg = Message(
            body="test", level=Level.ERROR, title="Alert",
            tags=["prod"], format=Format.MARKDOWN,
            metadata={"key": "val"},
        )
        assert msg.level == Level.ERROR
        assert msg.title == "Alert"
        assert msg.tags == ["prod"]
        assert msg.format == Format.MARKDOWN
        assert msg.metadata == {"key": "val"}

    def test_string_level_coercion(self):
        msg = Message(body="test", level="error")
        assert msg.level == Level.ERROR

    def test_string_format_coercion(self):
        msg = Message(body="test", format="markdown")
        assert msg.format == Format.MARKDOWN

    def test_unique_ids(self):
        m1 = Message(body="a")
        m2 = Message(body="b")
        assert m1.id != m2.id


class TestSendResult:
    def test_success(self):
        r = SendResult(channel="slack", success=True, message_id="abc")
        assert r.success
        assert not r.failed
        assert r.error is None

    def test_failure(self):
        r = SendResult(channel="slack", success=False, message_id="abc", error="timeout")
        assert not r.success
        assert r.failed
        assert r.error == "timeout"

    def test_with_response_data(self):
        r = SendResult(
            channel="webhook", success=True, message_id="xyz",
            response_data={"status_code": 200},
        )
        assert r.response_data["status_code"] == 200

    def test_summary_success(self):
        r = SendResult(channel="slack", success=True, message_id="abc", elapsed_ms=120.0)
        assert r.summary == "[OK] slack (120ms)"

    def test_summary_failure_with_error(self):
        r = SendResult(channel="webhook", success=False, message_id="abc", error="timeout", elapsed_ms=5000.0)
        s = r.summary
        assert "[FAIL]" in s
        assert "webhook" in s
        assert "timeout" in s


class TestChannelConfig:
    def test_defaults(self):
        cfg = ChannelConfig(name="test", type="console")
        assert cfg.enabled is True
        assert len(cfg.levels) == len(Level)
        assert cfg.rate_limit is None

    def test_from_dict(self):
        data = {
            "type": "slack",
            "enabled": True,
            "levels": ["warning", "error"],
            "tags": ["alerts"],
            "settings": {"webhook_url": "https://example.com"},
            "rate_limit": 10,
            "retry_count": 3,
        }
        cfg = ChannelConfig.from_dict("slack-ch", data)
        assert cfg.name == "slack-ch"
        assert cfg.type == "slack"
        assert Level.WARNING in cfg.levels
        assert Level.INFO not in cfg.levels
        assert cfg.rate_limit == 10
        assert cfg.retry_count == 3

    def test_from_dict_defaults(self):
        cfg = ChannelConfig.from_dict("console", {})
        assert cfg.type == "console"
        assert cfg.enabled is True
        assert len(cfg.levels) == len(Level)
