"""Tests for notifykit.templates."""

import pytest

from notifykit.templates import list_variables, render, validate_template


class TestRender:
    def test_simple(self):
        result = render("Hello {{name}}", {"name": "World"})
        assert result == "Hello World"

    def test_multiple_vars(self):
        result = render("{{greeting}} {{name}}", {"greeting": "Hi", "name": "Bob"})
        assert result == "Hi Bob"

    def test_unresolved_kept(self):
        result = render("Hello {{name}}", {})
        assert result == "Hello {{name}}"

    def test_dotted_access(self):
        result = render("{{user.name}}", {"user": {"name": "Alice"}})
        assert result == "Alice"

    def test_flat_dotted_key(self):
        result = render("{{user.name}}", {"user.name": "Bob"})
        assert result == "Bob"

    def test_whitespace_in_braces(self):
        result = render("{{ name }}", {"name": "test"})
        assert result == "test"

    def test_numeric_value(self):
        result = render("Count: {{count}}", {"count": 42})
        assert result == "Count: 42"

    def test_mixed_resolved_and_not(self):
        result = render("{{a}} and {{b}}", {"a": "yes"})
        assert result == "yes and {{b}}"

    def test_empty_template(self):
        assert render("", {"x": "y"}) == ""

    def test_no_placeholders(self):
        assert render("plain text", {"x": "y"}) == "plain text"

    def test_nested_dotted_access(self):
        vars = {"deploy": {"env": {"name": "prod"}}}
        result = render("{{deploy.env.name}}", vars)
        assert result == "prod"

    def test_deploy_template(self):
        tpl = "Deployment {{status}}: {{service}} ({{version}}) at {{timestamp}}"
        vars = {
            "status": "success",
            "service": "api",
            "version": "1.2.3",
            "timestamp": "2026-03-28",
        }
        result = render(tpl, vars)
        assert "success" in result
        assert "api" in result
        assert "1.2.3" in result


class TestListVariables:
    def test_simple(self):
        assert list_variables("{{a}} and {{b}}") == ["a", "b"]

    def test_no_vars(self):
        assert list_variables("no vars here") == []

    def test_whitespace(self):
        assert list_variables("{{ name }}") == ["name"]

    def test_dotted(self):
        assert list_variables("{{user.name}}") == ["user.name"]


class TestValidateTemplate:
    def test_all_resolved(self):
        unresolved = validate_template("{{a}} {{b}}", {"a": 1, "b": 2})
        assert unresolved == []

    def test_some_unresolved(self):
        unresolved = validate_template("{{a}} {{b}} {{c}}", {"a": 1})
        assert "b" in unresolved
        assert "c" in unresolved

    def test_dotted_resolved(self):
        unresolved = validate_template("{{user.name}}", {"user": {"name": "A"}})
        assert unresolved == []

    def test_dotted_unresolved(self):
        unresolved = validate_template("{{user.email}}", {"user": {"name": "A"}})
        assert "user.email" in unresolved
