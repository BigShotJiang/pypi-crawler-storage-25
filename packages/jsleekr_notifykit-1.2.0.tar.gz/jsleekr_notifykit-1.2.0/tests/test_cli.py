"""Tests for notifykit.cli."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from notifykit.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def config_file(tmp_path):
    content = """\
channels:
  console:
    type: console
    enabled: true
    levels: [debug, info, warning, error, critical]

defaults:
  format: plain

templates:
  deploy: "Deployment {{status}}: {{service}}"
  alert: "[{{level}}] {{body}}"
"""
    f = tmp_path / "notifykit.yaml"
    f.write_text(content, encoding="utf-8")
    return str(f)


class TestSendCommand:
    def test_send_basic(self, runner, config_file):
        result = runner.invoke(cli, ["send", "Hello world", "-c", config_file])
        assert result.exit_code == 0

    def test_send_with_level(self, runner, config_file):
        result = runner.invoke(cli, ["send", "Warning msg", "-l", "warning", "-c", config_file])
        assert result.exit_code == 0

    def test_send_with_title(self, runner, config_file):
        result = runner.invoke(cli, ["send", "Body", "-t", "Title", "-c", config_file])
        assert result.exit_code == 0

    def test_send_with_tags(self, runner, config_file):
        result = runner.invoke(cli, ["send", "Tagged", "--tag", "deploy", "--tag", "prod", "-c", config_file])
        assert result.exit_code == 0

    def test_send_invalid_level(self, runner, config_file):
        result = runner.invoke(cli, ["send", "Bad level", "-l", "unknown", "-c", config_file])
        assert result.exit_code != 0

    def test_send_dry_run(self, runner, config_file):
        result = runner.invoke(cli, ["send", "Dry run", "--dry-run", "-c", config_file])
        assert result.exit_code == 0
        assert "Would send" in result.output

    def test_send_with_template(self, runner, config_file):
        result = runner.invoke(cli, [
            "send", "body", "-c", config_file,
            "--template", "deploy",
            "--var", "status=success", "--var", "service=api",
        ])
        assert result.exit_code == 0

    def test_send_unknown_template(self, runner, config_file):
        result = runner.invoke(cli, [
            "send", "body", "-c", config_file,
            "--template", "nonexistent",
        ])
        assert result.exit_code != 0

    def test_send_to_specific_channel(self, runner, config_file):
        result = runner.invoke(cli, ["send", "hello", "-c", config_file, "--channel", "console"])
        assert result.exit_code == 0

    def test_send_json_output(self, runner, config_file):
        result = runner.invoke(cli, ["send", "CI test", "-c", config_file, "--json"])
        assert result.exit_code == 0
        # Extract JSON line (last line, console output may precede it)
        json_line = [l for l in result.output.strip().split("\n") if l.startswith("{")][-1]
        data = json.loads(json_line)
        assert data["success"] is True
        assert data["total"] >= 1
        assert data["succeeded"] >= 1
        assert isinstance(data["results"], list)

    def test_send_json_includes_channel_details(self, runner, config_file):
        result = runner.invoke(cli, ["send", "CI test", "-c", config_file, "--json"])
        assert result.exit_code == 0
        json_line = [l for l in result.output.strip().split("\n") if l.startswith("{")][-1]
        data = json.loads(json_line)
        r = data["results"][0]
        assert "channel" in r
        assert "success" in r
        assert "elapsed_ms" in r

    def test_send_invalid_format(self, runner, config_file):
        result = runner.invoke(cli, ["send", "Bad fmt", "-f", "xml", "-c", config_file])
        assert result.exit_code != 0


class TestTestCommand:
    def test_test_sends(self, runner, config_file):
        result = runner.invoke(cli, ["test", "-c", config_file])
        assert result.exit_code == 0


class TestChannelsCommand:
    def test_list_channels(self, runner, config_file):
        result = runner.invoke(cli, ["channels", "-c", config_file])
        assert result.exit_code == 0
        assert "console" in result.output
        assert "enabled" in result.output


class TestValidateCommand:
    def test_validate_valid(self, runner, config_file):
        result = runner.invoke(cli, ["validate", "-c", config_file])
        assert result.exit_code == 0
        assert "valid" in result.output.lower()

    def test_validate_invalid(self, runner, tmp_path):
        bad = tmp_path / "bad.yaml"
        bad.write_text("channels:\n  x:\n    type: fax\n")
        result = runner.invoke(cli, ["validate", "-c", str(bad)])
        assert result.exit_code != 0

    def test_validate_missing_file(self, runner):
        result = runner.invoke(cli, ["validate", "-c", "/no/such/file.yaml"])
        assert result.exit_code != 0


class TestHistoryCommand:
    def test_history_empty(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(cli, ["history"])
        assert result.exit_code == 0
        assert "No audit entries" in result.output

    def test_history_with_data(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        log_dir = tmp_path / ".notifykit"
        log_dir.mkdir()
        entry = {
            "timestamp": 1711612800.0,
            "channel": "console",
            "message_id": "test123",
            "success": True,
            "error": None,
            "elapsed_ms": 1.5,
            "metadata": {},
        }
        (log_dir / "audit.jsonl").write_text(json.dumps(entry) + "\n")
        result = runner.invoke(cli, ["history"])
        assert result.exit_code == 0
        assert "console" in result.output

    def test_history_json(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        log_dir = tmp_path / ".notifykit"
        log_dir.mkdir()
        entry = {
            "timestamp": 1711612800.0,
            "channel": "slack",
            "message_id": "j1",
            "success": True,
            "error": None,
            "elapsed_ms": 5.0,
            "metadata": {},
        }
        (log_dir / "audit.jsonl").write_text(json.dumps(entry) + "\n")
        result = runner.invoke(cli, ["history", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 1


class TestInitCommand:
    def test_init_creates_file(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0
        assert (tmp_path / "notifykit.yaml").exists()

    def test_init_no_overwrite(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "notifykit.yaml").write_text("existing")
        result = runner.invoke(cli, ["init"])
        assert result.exit_code != 0

    def test_init_force(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "notifykit.yaml").write_text("existing")
        result = runner.invoke(cli, ["init", "--force"])
        assert result.exit_code == 0

    def test_init_custom_output(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(cli, ["init", "-o", "custom.yaml"])
        assert result.exit_code == 0
        assert (tmp_path / "custom.yaml").exists()


class TestVersion:
    def test_version(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert "1.2.0" in result.output
