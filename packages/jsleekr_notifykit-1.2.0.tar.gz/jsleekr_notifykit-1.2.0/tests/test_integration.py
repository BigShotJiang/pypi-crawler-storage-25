"""Integration tests — full send pipeline with mock channels.

Tests the complete flow: config -> parse -> router -> channels -> audit,
verifying that all components work together correctly.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest
import responses

from notifykit.audit import AuditLog
from notifykit.config import load_config, parse_channels
from notifykit.models import Format, Level, Message
from notifykit.router import Router
from notifykit.templates import render


@pytest.fixture
def integration_config(tmp_path: Path) -> Path:
    """A config with console + slack for integration tests."""
    content = """\
channels:
  console:
    type: console
    enabled: true
    levels: [debug, info, warning, error, critical]

  slack-alerts:
    type: slack
    enabled: true
    levels: [warning, error, critical]
    tags: [alerts]
    settings:
      webhook_url: https://hooks.slack.com/test/integration

  disabled-webhook:
    type: webhook
    enabled: false
    settings:
      url: https://example.com/disabled

defaults:
  format: plain
  retry_count: 2

templates:
  deploy: "Deployment {{status}}: {{service}} ({{version}})"
  alert: "[{{level}}] {{title}}: {{body}}"
"""
    f = tmp_path / "notifykit.yaml"
    f.write_text(content, encoding="utf-8")
    return f


class TestFullPipeline:
    """End-to-end: config -> router -> send -> audit."""

    def test_info_routes_to_console_only(self, integration_config, capsys):
        """Info-level message should only reach console, not slack (needs tags)."""
        config = load_config(integration_config)
        channels = parse_channels(config)
        router = Router(channels)
        audit = AuditLog()

        msg = Message(body="Service started", level=Level.INFO)
        results = router.send(msg)
        audit.record_many(results)

        assert len(results) == 1
        assert results[0].channel == "console"
        assert results[0].success
        assert audit.stats()["total"] == 1
        assert audit.stats()["success_rate"] == 1.0

    @responses.activate
    def test_error_with_tags_routes_to_console_and_slack(self, integration_config, capsys):
        """Error-level with 'alerts' tag should reach console + slack."""
        responses.add(
            responses.POST,
            "https://hooks.slack.com/test/integration",
            status=200,
        )

        config = load_config(integration_config)
        channels = parse_channels(config)
        router = Router(channels)
        audit = AuditLog()

        msg = Message(
            body="CPU at 99%",
            level=Level.ERROR,
            title="High CPU",
            tags=["alerts"],
        )
        results = router.send(msg)
        audit.record_many(results)

        channel_names = {r.channel for r in results}
        assert "console" in channel_names
        assert "slack-alerts" in channel_names
        assert all(r.success for r in results)
        assert audit.stats()["total"] == 2

    def test_disabled_channel_excluded(self, integration_config):
        """Disabled channels should not appear in routing."""
        config = load_config(integration_config)
        channels = parse_channels(config)
        router = Router(channels)

        msg = Message(body="test", level=Level.INFO)
        targets = router.route(msg)
        names = [ch.name for ch in targets]
        assert "disabled-webhook" not in names

    @responses.activate
    def test_send_to_specific_bypasses_routing(self, integration_config, capsys):
        """send_to should bypass level/tag filters."""
        responses.add(
            responses.POST,
            "https://hooks.slack.com/test/integration",
            status=200,
        )

        config = load_config(integration_config)
        router = Router(parse_channels(config))

        # Debug level normally wouldn't route to slack-alerts
        msg = Message(body="debug info", level=Level.DEBUG)
        results = router.send_to(msg, ["slack-alerts"])

        assert len(results) == 1
        assert results[0].channel == "slack-alerts"
        assert results[0].success

    def test_template_rendering_in_pipeline(self, integration_config, capsys):
        """Templates should render variables before sending."""
        config = load_config(integration_config)
        templates = config.get("templates", {})
        tpl = templates["deploy"]

        body = render(tpl, {
            "status": "success",
            "service": "api",
            "version": "2.0.0",
        })

        router = Router(parse_channels(config))
        msg = Message(body=body, level=Level.INFO, title="Deploy")
        results = router.send(msg)

        assert len(results) >= 1
        assert "success" in body
        assert "api" in body
        assert "2.0.0" in body


class TestPipelineWithAuditFile:
    """Integration with file-backed audit log."""

    @responses.activate
    def test_audit_file_records_pipeline(self, integration_config, tmp_path, capsys):
        """Full pipeline should persist results to audit file."""
        responses.add(
            responses.POST,
            "https://hooks.slack.com/test/integration",
            status=200,
        )

        config = load_config(integration_config)
        router = Router(parse_channels(config))
        audit_file = tmp_path / "audit.jsonl"
        audit = AuditLog(audit_file)

        msg = Message(
            body="Deploy complete",
            level=Level.WARNING,
            tags=["alerts"],
        )
        results = router.send(msg)
        audit.record_many(results)

        # Verify file was written
        assert audit_file.exists()
        lines = audit_file.read_text().strip().split("\n")
        assert len(lines) >= 1

        # Verify reloading from file works
        audit2 = AuditLog(audit_file)
        loaded = audit2.load_from_file()
        assert loaded == len(results)

    def test_multiple_sends_accumulate(self, integration_config, tmp_path, capsys):
        """Multiple sends should accumulate in audit log."""
        config = load_config(integration_config)
        router = Router(parse_channels(config))
        audit = AuditLog(tmp_path / "audit.jsonl")

        for i in range(5):
            msg = Message(body=f"msg {i}", level=Level.INFO)
            results = router.send(msg)
            audit.record_many(results)

        stats = audit.stats()
        assert stats["total"] == 5
        assert stats["success_rate"] == 1.0


class TestPipelineFailureHandling:
    """Integration tests for failure scenarios."""

    @responses.activate
    def test_partial_failure_records_all(self, integration_config, capsys):
        """When one channel fails, all results should still be recorded."""
        responses.add(
            responses.POST,
            "https://hooks.slack.com/test/integration",
            status=500,
            body="Internal Server Error",
        )

        config = load_config(integration_config)
        router = Router(parse_channels(config))
        audit = AuditLog()

        msg = Message(
            body="Test failure",
            level=Level.ERROR,
            tags=["alerts"],
        )
        results = router.send(msg)
        audit.record_many(results)

        # Console succeeds, slack fails
        console_result = next(r for r in results if r.channel == "console")
        slack_result = next(r for r in results if r.channel == "slack-alerts")

        assert console_result.success
        assert not slack_result.success
        assert audit.stats()["failed"] == 1
        assert audit.stats()["success"] == 1
