"""Sphinx configuration for the citests user docs.

Same setup as the sister cbcd / bnmetrics / dagsampler doc sites:
Sphinx + MyST + Furo + sphinx-autoapi, hand-authored pages in a
Diátaxis layout, internal-developer material excluded from the
rendered build.
"""

from __future__ import annotations

import importlib.metadata as _md
import sys
from pathlib import Path

# docs/source/conf.py → docs/source → docs → repo root
_REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_REPO_ROOT))

# -- Project information -----------------------------------------------------

project = "citests"
author = "Pavel Averin"

try:
    release = _md.version("citests")
except _md.PackageNotFoundError:  # pragma: no cover
    release = "0.0.0"
version = release.split("+", 1)[0]
copyright = f"2026, {author}"

# -- General configuration ---------------------------------------------------

extensions = [
    "myst_parser",
    "autoapi.extension",
    "sphinx.ext.intersphinx",
    "sphinx.ext.viewcode",
    "sphinx.ext.napoleon",
    "sphinx.ext.mathjax",
]

source_suffix = {".md": "markdown", ".rst": "restructuredtext"}

templates_path = ["_templates"]

exclude_patterns = [
    "_build",
    "_internal",
    ".ipynb_checkpoints",
    "Thumbs.db",
    ".DS_Store",
]

# -- MyST options ------------------------------------------------------------

myst_enable_extensions = [
    "amsmath",
    "dollarmath",
    "deflist",
    "colon_fence",
    "smartquotes",
    "html_image",
    "linkify",
]

myst_heading_anchors = 3
myst_dmath_double_inline = True

# -- HTML output -------------------------------------------------------------

html_theme = "furo"
html_title = f"citests {version}"
html_static_path = ["_static"]
html_theme_options = {
    "sidebar_hide_name": False,
    "navigation_with_keys": True,
    "top_of_page_buttons": ["view", "edit"],
    "source_repository": "https://github.com/averinpa/constraint-based-causal-discovery-suite/",
    "source_branch": "main",
    "source_directory": "citests/docs/source/",
    "footer_icons": [
        {
            "name": "GitHub",
            "url": "https://github.com/averinpa/constraint-based-causal-discovery-suite",
            "html": """
                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"></path></svg>
            """,
            "class": "",
        },
    ],
}

pygments_style = "tango"
pygments_dark_style = "monokai"

# -- sphinx-autoapi ----------------------------------------------------------

autoapi_type = "python"
autoapi_dirs = [str(_REPO_ROOT / "citests")]
autoapi_root = "reference/api"
autoapi_keep_files = False
autoapi_add_toctree_entry = False
autoapi_options = [
    "members",
    "undoc-members",
    "show-inheritance",
    "show-module-summary",
]
autoapi_python_class_content = "both"
autoapi_member_order = "groupwise"
# Don't exclude _register — family modules import maybe_register from it;
# excluding it leaves autoapi unable to resolve their imports.
autoapi_ignore = ["*/_internal/*", "*/_vendor/*"]

# Suppress autoapi warnings for adapter / contingency-table classes that
# are conditionally defined inside ``if _HAS_CAUSALLEARN:`` blocks. autoapi's
# static analysis can't see those branches, but the conditional definition
# is intentional in the source.
suppress_warnings = ["autoapi.python_import_resolution"]

# -- intersphinx -------------------------------------------------------------

intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
    "numpy": ("https://numpy.org/doc/stable/", None),
    "pandas": ("https://pandas.pydata.org/docs/", None),
    "scipy": ("https://docs.scipy.org/doc/scipy/", None),
}
intersphinx_disabled_reftypes = ["std:doc"]

# -- napoleon ----------------------------------------------------------------

napoleon_google_docstring = True
napoleon_numpy_docstring = True
napoleon_include_init_with_doc = False
napoleon_include_private_with_doc = False
napoleon_use_param = True
napoleon_use_rtype = True
