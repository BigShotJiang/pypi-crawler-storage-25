import argparse
import contextlib
import io
import os
import pathlib
import typing
from importlib import metadata
from typing import Any

from jacobus.const.Config import Config
from jacobus.const.Const import Const

__all__ = ["main", "run"]


def main(args: typing.Optional[list[str]] = None) -> None:
    parser: argparse.ArgumentParser
    space: argparse.Namespace
    # kwargs:dict[str, Any]
    parser = argparse.ArgumentParser(
        description=Const.const.data.get("description"),
        formatter_class=argparse.RawTextHelpFormatter,
        fromfile_prefix_chars="@",
    )
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        dest="version",
        version=metadata.version("jacobus"),
    )
    parser.add_argument(
        "path",
        nargs="?",
        help=Const.const.data["varia"].get("path-help"),
    )
    space = parser.parse_args(args)
    # kwargs = vars(space)
    run(space.path)


def run(
    path: str,
    /,
) -> None:
    root: str
    target: str
    root = str(Config.config.data["varia"].get("root", ""))
    if path and root:
        target = os.path.join(root, path)
    elif path:
        target = path
    elif root:
        target = root
    else:
        run_()
        return
    target = os.path.expanduser(target)
    target = os.path.expandvars(target)
    pathlib.Path(target).mkdir(parents=True, exist_ok=True)
    with contextlib.chdir(target):
        run_()


def run_() -> None:
    dnames: list
    ext: Any
    file: Any
    files: list
    fnames: list
    fname: Any
    index: int
    lines: list[str]
    root: Any
    stream: io.TextIOWrapper
    files = []
    for root, dnames, fnames in os.walk(os.getcwd()):
        for fname in fnames:
            file = os.path.join(root, fname)
            files.append(file)
    for file in files:
        ext = os.path.splitext(file)[1]
        fname = os.path.split(file)
        index = ext.lower() in Const.const.data["varia"]["extensions"]
        index += fname in Const.const.data["varia"]["extensions"]
        if index == 0:
            continue
        with open(file=file, mode="r") as stream:
            lines = stream.readlines()
        for index in range(len(lines)):
            lines[index] = lines[index].rstrip() + "\n"
        while len(lines) and lines[0] == "\n":
            lines.pop()
        while len(lines) and lines[-1] == "\n":
            lines.pop()
        with open(file=file, mode="w") as stream:
            stream.writelines(lines)
