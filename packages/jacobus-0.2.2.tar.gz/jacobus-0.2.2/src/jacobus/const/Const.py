import enum
import functools
import tomllib
import typing
from importlib import resources

__all__ = ["Const"]


class Const(enum.Enum):
    const = None

    @functools.cached_property
    def data(self: typing.Self) -> dict[str, typing.Any]:
        text: str
        text = resources.read_text("jacobus.const", "const.toml")
        return tomllib.loads(text)

    @classmethod
    def varia(cls: type[typing.Self]) -> dict[str, typing.Any]:
        return cls.const.data["varia"]
