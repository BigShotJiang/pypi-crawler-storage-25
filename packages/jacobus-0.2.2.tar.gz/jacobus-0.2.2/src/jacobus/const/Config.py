import enum
import functools
import tomllib
import typing
from importlib import resources

__all__ = ["Config"]


class Config(enum.Enum):
    config = None

    @functools.cached_property
    def data(self: typing.Self) -> dict[str, typing.Any]:
        text: str
        text = resources.read_text("jacobus", "config.toml")
        return tomllib.loads(text)
