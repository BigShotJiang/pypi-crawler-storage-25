"""Typed HTTP client for the Meta Quest 3 companion Unity app.

Wraps :mod:`httpx` with domain-specific request shaping and response
parsing. Accepts a ``transport`` kwarg so unit tests can inject
``httpx.MockTransport`` without spinning up a real server.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


DEFAULT_TIMEOUT_S = 10.0


@dataclass(frozen=True)
class QuestStatus:
    """Snapshot of the Quest app's current state (from ``GET /status``)."""

    recording: bool
    session_id: Optional[str]
    last_preview_capture_ns: int
    left_camera_ready: bool
    right_camera_ready: bool
    storage_free_bytes: int

    @classmethod
    def from_json(cls, payload: dict) -> "QuestStatus":
        return cls(
            recording=bool(payload["recording"]),
            session_id=payload.get("session_id"),
            last_preview_capture_ns=int(payload.get("last_preview_capture_ns", 0)),
            left_camera_ready=bool(payload.get("left_camera_ready", False)),
            right_camera_ready=bool(payload.get("right_camera_ready", False)),
            storage_free_bytes=int(payload.get("storage_free_bytes", 0)),
        )


class QuestHttpClient:
    """Thin typed façade over the Quest's HTTP surface (port 14045)."""

    def __init__(
        self,
        host: str,
        port: int = 14045,
        *,
        timeout_s: float = DEFAULT_TIMEOUT_S,
        transport: Optional[httpx.BaseTransport] = None,
    ) -> None:
        self._base_url = f"http://{host}:{port}"
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout_s,
            transport=transport,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "QuestHttpClient":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    def status(self) -> QuestStatus:
        """Fetch a fresh ``QuestStatus`` snapshot from the Quest."""
        response = self._client.get("/status")
        response.raise_for_status()
        return QuestStatus.from_json(response.json())

    def start_recording(
        self,
        *,
        session_id: str,
        host_mono_ns: int,
        width: int,
        height: int,
        fps: int,
    ) -> "RecordingStartResponse":
        response = self._client.post(
            "/recording/start",
            json={
                "session_id": session_id,
                "host_mono_ns": host_mono_ns,
                "resolution": {"width": width, "height": height},
                "fps": fps,
            },
        )
        if response.status_code == 409:
            raise RecordingAlreadyActive(response.json().get("error", ""))
        response.raise_for_status()
        return RecordingStartResponse.from_json(response.json())

    def stop_recording(self) -> "RecordingStopResponse":
        response = self._client.post("/recording/stop", json={})
        response.raise_for_status()
        return RecordingStopResponse.from_json(response.json())

    def clock_sync(self, host_mono_ns: int) -> None:
        """POST host's monotonic clock to Quest so server-side deltaNs is set.

        Streaming-mode adapters call this on connect — without it
        Quest's PassthroughCameraRecorder._deltaNs stays zero and every
        X-Frame-Capture-Ns header carries raw Quest uptime instead of
        the host clock projection, which breaks cross-modal alignment.

        Best-effort: HTTP errors are logged but do not propagate. Worst
        case capture_ns leaks raw Quest uptime — post-hoc tooling can
        still recover absolute alignment via the SampleEvent's
        ``quest_native_ns`` channel.
        """
        try:
            response = self._client.post(
                "/clock/sync", json={"host_mono_ns": int(host_mono_ns)}
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("POST /clock/sync failed: %s", exc)

    def delete_recording(self) -> None:
        """Tell the Quest to clean up the just-pulled session files.

        Best-effort: we swallow HTTP errors because the files are already on disk.
        """
        try:
            response = self._client.delete("/recording/files")
            response.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("DELETE /recording/files failed: %s", exc)

    def download_file(
        self,
        path: str,
        dest,
        *,
        max_retries: int = 3,
        chunk_size: int = 64 * 1024,
    ) -> int:
        """Download a binary resource, streaming to ``dest`` on disk.

        Resumes with ``Range`` headers on transient failure up to
        ``max_retries`` times. Returns the total number of bytes written.
        The caller is responsible for verifying the expected size against
        the value returned by ``/recording/stop``.
        """
        from pathlib import Path

        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)

        written = 0
        expected_total: Optional[int] = None

        for attempt in range(max_retries):
            headers = {}
            mode = "wb"
            if written > 0:
                headers["Range"] = f"bytes={written}-"
                mode = "ab"

            try:
                with self._client.stream("GET", path, headers=headers) as response:
                    response.raise_for_status()
                    if expected_total is None:
                        cl = response.headers.get("Content-Length")
                        cr = response.headers.get("Content-Range")
                        if cr and "/" in cr:
                            expected_total = int(cr.rsplit("/", 1)[1])
                        elif cl is not None and written == 0:
                            expected_total = int(cl)
                    with open(dest, mode) as fh:
                        for chunk in response.iter_bytes(chunk_size):
                            fh.write(chunk)
                            written += len(chunk)
                if expected_total is None or written >= expected_total:
                    return written
            except httpx.HTTPError:
                if attempt == max_retries - 1:
                    raise
                continue

        return written


class RecordingAlreadyActive(RuntimeError):
    """Raised when POST /recording/start returns 409."""


@dataclass(frozen=True)
class RecordingStartResponse:
    session_id: str
    quest_mono_ns_at_start: int
    delta_ns: int
    started: bool

    @classmethod
    def from_json(cls, payload: dict) -> "RecordingStartResponse":
        return cls(
            session_id=str(payload["session_id"]),
            quest_mono_ns_at_start=int(payload["quest_mono_ns_at_start"]),
            delta_ns=int(payload["delta_ns"]),
            started=bool(payload["started"]),
        )


@dataclass(frozen=True)
class PerEyeSummary:
    frame_count: int
    bytes: int
    last_capture_ns: int

    @classmethod
    def from_json(cls, payload: dict) -> "PerEyeSummary":
        return cls(
            frame_count=int(payload["frame_count"]),
            bytes=int(payload["bytes"]),
            last_capture_ns=int(payload["last_capture_ns"]),
        )


@dataclass(frozen=True)
class RecordingStopResponse:
    session_id: str
    left: PerEyeSummary
    right: PerEyeSummary
    duration_s: float

    @classmethod
    def from_json(cls, payload: dict) -> "RecordingStopResponse":
        return cls(
            session_id=str(payload["session_id"]),
            left=PerEyeSummary.from_json(payload["left"]),
            right=PerEyeSummary.from_json(payload["right"]),
            duration_s=float(payload["duration_s"]),
        )
