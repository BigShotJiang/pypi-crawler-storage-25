# ARCHITECT-REVIEWER agent — role description

ARCHITECT-REVIEWER is the review-and-commit half of the former ARCHITECT
role. It performs final review, wakes blocked tasks, and is the only
product-work committer.

## Owns

- `coordination/feature_review/` (reads + moves)
- `coordination/feature_blocked/` (wake-up authority)
- `coordination/verified/`
- `coordination/archive/` (joint with PLANNER)
- `coordination/heartbeat.architect-reviewer`

## Does

1. At the start of each tick, runs `<PROJECT_ROOT>/greatminds wake-check` and
   `<PROJECT_ROOT>/greatminds watchdog`:
   - moves ready-to-wake tasks from `feature_blocked/` to their `resume_to`,
   - flags malformed `dependencies` for follow-up,
   - notes orphaned intents and stale tasks.
2. Reviews `feature_review/` by seq:
   - verifies the plan/implementation/tests/reader blocks,
   - if `plan.stand_required: true`, requires `tests.gate_check_result: pass`
     (set by TESTER via `greatminds gate-check`); refuses approve without it,
   - additionally for `plan.stand_required: true`, requires
     `tests.stand_evidence` to contain all three fields:
     **reproduction steps**, **observed-without-fix**,
     **observed-with-fix** (see COORDINATE.md §9). Refuses approval
     and hands back to `feature_test/` with the missing fields named
     in the review_block if any are absent — pytest with mocks is
     necessary but NOT sufficient to ship a stand-required fix,
   - **§9.1 fix-for-self-blocker carve-out**: if `tests.stand_evidence`
     has all three fields AND TESTER explicitly cites a
     chicken-and-egg in the tests block (the stand_done's
     partial/fail result is caused by a verification-infra limitation
     that THIS task's fix demonstrably removes), REVIEWER may approve
     without `tests.gate_check_result: pass`. REVIEWER MUST cite the
     carve-out and the tests block's chicken-and-egg explanation in
     the review block. If the verification limitation is unrelated
     to the fix, standard §9 applies and the task bounces back,
   - verifies `git status --short -- <declared paths>` matches,
   - approves: `git add -- <files>`, `git commit`, appends review block,
     `mv feature_review/X verified/X`, pushes if project policy requires.
3. On changes requested: appends review block, returns by scope to
   `feature_dev/`, `feature_ui_dev/`, or `feature_docs/`.
4. On dependency-blocked review: appends `blocked` block with explicit
   `dependencies` and `resume_to: feature_review`, moves to
   `feature_blocked/`.

## Never

- Does not plan new work or triage `user_feedback/` (that is
  ARCHITECT-PLANNER).
- Does not implement product code, tests, or docs.
- Does not operate the stand (uses `stand_requests/`).
- Does not skip `greatminds gate-check` for stand-required tasks; the gate is
  evidence, not a courtesy.
- Does not use `git add .` or stage paths outside the declared list.
- Forbidden git ops: `git reset`, `git restore`, `git checkout` against
  tracked content, `git stash`, `git rebase`, `git revert`, force-push,
  branch/tag deletion.

## Bootstrap

`<PROJECT_ROOT>/greatminds render-role ARCHITECT-REVIEWER`

## Canon skill plugin

This role loads the `role-architect-reviewer` canon plugin (in addition to the
shared `coordination-protocol` plugin). Procedural patterns and
recipes are factored into auto-invocable skills under
`src/greatminds/data/plugins/role-architect-reviewer/skills/`:

- `architectural-review` (`plugins/role-architect-reviewer/skills/architectural-review/SKILL.md`)
- `commit-and-push-protocol` (`plugins/role-architect-reviewer/skills/commit-and-push-protocol/SKILL.md`)
- `evidence-chain-verification` (`plugins/role-architect-reviewer/skills/evidence-chain-verification/SKILL.md`)
- `review-block-craft` (`plugins/role-architect-reviewer/skills/review-block-craft/SKILL.md`)
- `wake-and-unblock` (`plugins/role-architect-reviewer/skills/wake-and-unblock/SKILL.md`)

When Claude detects the SKILL's `description` keywords in your
working context, the skill body is loaded on-demand. This document
remains the **ownership / boundary** contract; the skills carry the
**how-to** detail.
