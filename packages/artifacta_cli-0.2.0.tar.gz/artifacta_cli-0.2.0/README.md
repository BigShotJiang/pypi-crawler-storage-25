# Artifacta

**The artifact store purpose-built for AI agents.**

Artifacta gives your agents a single `push` / `pull` interface over durable,
deduplicated, session-aware storage — so you can stop writing S3 glue code
and `/tmp` hacks between pipeline steps.

- **CLI** — `artifacta push`, `pull`, `ls`, `link`, `session`, `whoami`
- **Python SDK** — `from artifacta import Client`
- **REST API** — every language; see [docs.artifacta.io](https://docs.artifacta.io)

Both the CLI binary and the Python SDK ship in this one package.

---

## Install

```bash
pip install artifacta-cli
```

Requires Python 3.10+. After install you get the `artifacta` binary on your
PATH and `from artifacta import Client` in Python.

Verify:

```bash
artifacta --version
```

---

## Authenticate

Sign up at [app.artifacta.io/signup](https://app.artifacta.io/signup). Copy
your API key from the onboarding screen (keys start with `ak_live_`), then:

```bash
artifacta login
# Paste your ak_live_... key when prompted
```

Or set the environment variable — recommended for agents and CI, since every
sub-process inherits it automatically:

```bash
export ARTIFACTA_API_KEY="ak_live_..."
```

Confirm:

```bash
artifacta whoami
```

---

## Push → list → pull

```bash
# Upload a file, tagged with a session
artifacta push report.pdf --session demo-run

# List everything in that session
artifacta ls --session demo-run

# Pull it back later, from any machine
artifacta pull art_2xk9f7v3m1p0 -o ./downloads/
```

### Same thing from Python

```python
from artifacta import Client

client = Client()  # reads ARTIFACTA_API_KEY from env

artifact = client.push("report.pdf", session_id="demo-run")
print(artifact.id)  # art_2xk9f7v3m1p0

result = client.list(session_id="demo-run")
for a in result.artifacts:
    print(a.id, a.filename)

client.pull(artifact.id, output="./downloads/")
```

### Share a file with a human

```bash
artifacta push slides.pdf --session demo-run --link
# → https://dl.artifacta.io/lnk_... (expires in 7 days)
```

---

## Agent patterns

Set the session and key once in your orchestrator; every sub-agent inherits them:

```bash
export ARTIFACTA_API_KEY="ak_live_..."
export ARTIFACTA_SESSION_ID="$(artifacta session new)"

python agent_a.py   # pushes inherit ARTIFACTA_SESSION_ID automatically
python agent_b.py   # same session, zero flag passing
```

Auto-JSON when stdout is piped, human-readable on a TTY:

```bash
artifacta ls --session demo-run | jq '.artifacts[].id'
```

---

## Plans

| | Free | Pro ($20/mo) |
|---|---|---|
| Storage | 1 GB | 100 GB |
| Requests | 10,000 / month | 1,000,000 / month |
| Max TTL | 90 days | 365 days |
| Presigned uploads (> 500 MB) | — | ✓ |
| API keys | 10 | 50 |

Upgrade from the [dashboard](https://app.artifacta.io/dashboard/usage).

---

## Links

- **Docs:** [docs.artifacta.io](https://docs.artifacta.io)
- **Dashboard:** [app.artifacta.io](https://app.artifacta.io)
- **Status:** [status.artifacta.io](https://status.artifacta.io)
- **Support:** [support@artifacta.io](mailto:support@artifacta.io)

## License

MIT
