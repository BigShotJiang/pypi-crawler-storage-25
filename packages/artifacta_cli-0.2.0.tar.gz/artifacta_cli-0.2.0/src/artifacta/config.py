"""Configuration management — TOML config file + environment variable overrides.

Precedence: env var > config file > default.
Config path: ~/.config/artifacta/config.toml (XDG convention).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib  # type: ignore[import-not-found]
    except ImportError:
        import tomli as tomllib  # type: ignore[import-not-found,no-redef]


def _config_dir() -> Path:
    """Return ~/.config/artifacta (respects XDG_CONFIG_HOME)."""
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return Path(base) / "artifacta"


def _config_path() -> Path:
    return _config_dir() / "config.toml"


def load_config() -> dict[str, Any]:
    """Load config from TOML file. Returns empty sections if file doesn't exist."""
    path = _config_path()
    if not path.exists():
        return {"auth": {}, "defaults": {}}
    with open(path, "rb") as f:
        data = tomllib.load(f)
    data.setdefault("auth", {})
    data.setdefault("defaults", {})
    return data


def save_config(data: dict[str, Any]) -> None:
    """Write config dict to TOML file. Creates directory if needed."""
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    for section, values in data.items():
        if isinstance(values, dict) and values:
            lines.append(f"[{section}]")
            for k, v in values.items():
                if isinstance(v, str):
                    lines.append(f'{k} = "{v}"')
                elif isinstance(v, bool):
                    lines.append(f"{k} = {'true' if v else 'false'}")
                elif isinstance(v, (int, float)):
                    lines.append(f"{k} = {v}")
                else:
                    lines.append(f'{k} = "{v}"')
            lines.append("")
    path.write_text("\n".join(lines) + "\n")


def get_api_key() -> str | None:
    """Return API key with env var taking precedence over config file."""
    env_key = os.environ.get("ARTIFACTA_API_KEY")
    if env_key:
        return env_key
    cfg = load_config()
    return cfg.get("auth", {}).get("api_key") or None


def get_api_url() -> str:
    """Return API base URL with env var taking precedence over config file."""
    env_url = os.environ.get("ARTIFACTA_API_URL")
    if env_url:
        return env_url
    cfg = load_config()
    return cfg.get("auth", {}).get("api_url") or "https://api.artifacta.io"


def get_config_value(key: str) -> str | None:
    """Get a dotted config key like 'defaults.ttl'."""
    cfg = load_config()
    parts = key.split(".", 1)
    if len(parts) == 2:
        return cfg.get(parts[0], {}).get(parts[1])
    # Check top-level sections for flat keys
    for section in cfg.values():
        if isinstance(section, dict) and key in section:
            return section[key]
    return None


def set_config_value(key: str, value: str) -> None:
    """Set a dotted config key like 'defaults.ttl'."""
    cfg = load_config()
    parts = key.split(".", 1)
    if len(parts) == 2:
        section, field = parts
        cfg.setdefault(section, {})[field] = value
    else:
        cfg.setdefault("defaults", {})[key] = value
    save_config(cfg)
