"""Artifacta Python SDK — Client class and typed response objects.

Usage:
    from artifacta import Client

    client = Client()  # reads ARTIFACTA_API_KEY from env or config
    artifact = client.push("report.pdf", session_id="run_q4")
"""

from __future__ import annotations

import json
import mimetypes
import os
import secrets
import string
from pathlib import Path
from typing import Any

import httpx

from artifacta import __version__
from artifacta.config import get_api_key, get_api_url
from artifacta.errors import AuthenticationError, InvalidRequestError, raise_for_error_response

SESSION_ID_CHARSET = string.ascii_lowercase + string.digits


class Artifact:
    """Typed wrapper around an artifact API response.

    All API response fields are accessible as attributes.
    """

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def id(self) -> str:
        return self._data["artifact_id"]

    @property
    def filename(self) -> str:
        return self._data["filename"]

    @property
    def content_type(self) -> str:
        return self._data["content_type"]

    @property
    def size_bytes(self) -> int:
        return self._data["size_bytes"]

    @property
    def content_hash(self) -> str:
        return self._data["content_hash"]

    @property
    def session_id(self) -> str | None:
        return self._data.get("session_id")

    @property
    def agent_id(self) -> str | None:
        return self._data.get("agent_id")

    @property
    def metadata(self) -> dict[str, Any]:
        return self._data.get("metadata", {})

    @property
    def expires_at(self) -> str | None:
        return self._data.get("expires_at")

    @property
    def created_at(self) -> str:
        return self._data["created_at"]

    def to_dict(self) -> dict[str, Any]:
        """Return the raw API response dict."""
        return dict(self._data)

    def __repr__(self) -> str:
        return f"Artifact(id={self.id!r}, filename={self.filename!r}, size_bytes={self.size_bytes})"


class Link:
    """Typed wrapper around a download link API response."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def link_id(self) -> str:
        return self._data["link_id"]

    @property
    def url(self) -> str:
        return self._data["url"]

    @property
    def artifact_id(self) -> str:
        return self._data["artifact_id"]

    @property
    def expires_at(self) -> str:
        return self._data["expires_at"]

    @property
    def created_at(self) -> str:
        return self._data["created_at"]

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)

    def __repr__(self) -> str:
        return f"Link(link_id={self.link_id!r}, url={self.url!r})"


class Session:
    """Typed wrapper around a session list entry."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def session_id(self) -> str:
        return self._data["session_id"]

    @property
    def artifact_count(self) -> int:
        return self._data["artifact_count"]

    @property
    def is_sealed(self) -> bool:
        return self._data["is_sealed"]

    @property
    def first_artifact_at(self) -> str | None:
        return self._data.get("first_artifact_at")

    @property
    def last_artifact_at(self) -> str | None:
        return self._data.get("last_artifact_at")

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)

    def __repr__(self) -> str:
        return f"Session(session_id={self.session_id!r}, artifact_count={self.artifact_count})"


class ListResult:
    """Result of a list() call with pagination metadata.

    Supports iteration and len() for backward compatibility with code
    that treated list() results as a plain list.
    """

    def __init__(
        self,
        artifacts: list[Artifact],
        has_more: bool = False,
        next_cursor: str | None = None,
    ) -> None:
        self.artifacts = artifacts
        self.has_more = has_more
        self.next_cursor = next_cursor

    def __iter__(self):
        return iter(self.artifacts)

    def __len__(self) -> int:
        return len(self.artifacts)

    def __getitem__(self, index: int) -> Artifact:
        return self.artifacts[index]

    def __repr__(self) -> str:
        return f"ListResult(count={len(self.artifacts)}, has_more={self.has_more})"


class SealInfo:
    """Typed wrapper around a session seal API response."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def session_id(self) -> str:
        return self._data["session_id"]

    @property
    def status(self) -> str:
        return self._data["status"]

    @property
    def sealed_at(self) -> str:
        return self._data["sealed_at"]

    @property
    def artifact_count(self) -> int:
        return self._data["artifact_count"]

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)

    def __repr__(self) -> str:
        return f"SealInfo(session_id={self.session_id!r}, artifact_count={self.artifact_count})"


class TenantInfo:
    """Typed wrapper around a whoami API response."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def tenant_name(self) -> str:
        return self._data["tenant_name"]

    @property
    def plan(self) -> str:
        return self._data["plan"]

    @property
    def api_key_last_4(self) -> str:
        return self._data["api_key_last_4"]

    @property
    def usage_requests_month(self) -> int:
        return self._data["usage_requests_month"]

    @property
    def plan_requests_limit_month(self) -> int:
        return self._data["plan_requests_limit_month"]

    @property
    def usage_storage_bytes(self) -> int:
        return self._data["usage_storage_bytes"]

    @property
    def plan_storage_limit_bytes(self) -> int:
        return self._data["plan_storage_limit_bytes"]

    @property
    def active_links(self) -> int:
        return self._data["active_links"]

    @property
    def max_active_links(self) -> int:
        return self._data["max_active_links"]

    @property
    def rate_limit_sustained(self) -> int:
        return self._data["rate_limit_sustained"]

    @property
    def rate_limit_burst(self) -> int:
        return self._data["rate_limit_burst"]

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)

    def __repr__(self) -> str:
        return f"TenantInfo(tenant_name={self.tenant_name!r}, plan={self.plan!r})"


class Client:
    """Artifacta SDK client.

    Args:
        api_key: Explicit API key. Overrides env var and config file.
        base_url: API base URL. Overrides ARTIFACTA_API_URL env var and config file.
        session_id: Default session ID for push/list operations.
            Falls back to ARTIFACTA_SESSION_ID env var.
        agent_id: Default agent ID for push/list operations.
            Falls back to ARTIFACTA_AGENT_ID env var.

    Raises:
        AuthenticationError: If no API key is found in any source.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        session_id: str | None = None,
        agent_id: str | None = None,
    ) -> None:
        # Resolve API key: explicit > env var > config file
        self._api_key = api_key or get_api_key()
        if not self._api_key:
            raise AuthenticationError()

        # Resolve base URL: explicit > env var > config file > default
        self._base_url = base_url or get_api_url()

        # Resolve default session_id: explicit > env var > None
        self._default_session_id = session_id or os.environ.get("ARTIFACTA_SESSION_ID") or None

        # Resolve default agent_id: explicit > env var > None
        self._default_agent_id = agent_id or os.environ.get("ARTIFACTA_AGENT_ID") or None

    def _build_http_client(self) -> httpx.Client:
        """Build an httpx client with auth and user-agent headers."""
        return httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "User-Agent": f"artifacta-sdk/{__version__}",
            },
            timeout=30.0,
        )

    def _request(self, method: str, path: str, **kwargs: object) -> httpx.Response:
        """Make an HTTP request and return the raw response.

        Raises typed ArtifactaError subclasses on 4xx/5xx responses.
        """
        from artifacta.errors import ArtifactaError

        client = self._build_http_client()
        try:
            resp = client.request(method, path, **kwargs)  # type: ignore[arg-type]
        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
            raise ArtifactaError(code="network_error", message=str(exc), status=0) from exc
        finally:
            client.close()

        if resp.status_code >= 400:
            try:
                body = resp.json()
            except (ValueError, KeyError):
                raise ArtifactaError(
                    code="unknown", message=resp.text, status=resp.status_code
                )
            raise_for_error_response(resp.status_code, body)

        return resp

    def _resolve_session_id(self, session_id: str | None) -> str | None:
        """Resolve session_id: explicit param > constructor default > env default."""
        return session_id if session_id is not None else self._default_session_id

    def _resolve_agent_id(self, agent_id: str | None) -> str | None:
        """Resolve agent_id: explicit param > constructor default > env default."""
        return agent_id if agent_id is not None else self._default_agent_id

    # --- Push methods ---

    def push(
        self,
        path: str | Path | None = None,
        *,
        content: bytes | None = None,
        filename: str | None = None,
        session_id: str | None = None,
        agent_id: str | None = None,
        metadata: dict[str, str] | None = None,
        ttl: str | None = None,
        idempotency_key: str | None = None,
        presigned: bool = False,
    ) -> Artifact:
        """Upload an artifact from a file path or bytes.

        Provide either ``path`` (file on disk) or ``content`` + ``filename`` (bytes in memory).
        Set ``presigned=True`` for large files (up to 5 GB, Pro plan required).

        Returns:
            Artifact object with all fields accessible as attributes.
        """
        resolved_session = self._resolve_session_id(session_id)
        resolved_agent = self._resolve_agent_id(agent_id)

        if path is not None and content is not None:
            raise InvalidRequestError("Provide either 'path' or 'content', not both.")

        if path is not None:
            file_path = Path(path)
            file_bytes = file_path.read_bytes()
            file_name = filename or file_path.name
            content_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
        elif content is not None:
            if not filename:
                raise InvalidRequestError("'filename' is required when pushing bytes content.")
            file_bytes = content
            file_name = filename
            content_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
        else:
            raise InvalidRequestError("Provide either 'path' or 'content'.")

        if presigned:
            return self._push_presigned(
                file_bytes, file_name, content_type,
                resolved_session, resolved_agent, metadata, ttl,
            )

        # Build multipart form data
        files = {"file": (file_name, file_bytes, content_type)}
        data: dict[str, str] = {}
        if resolved_session:
            data["session_id"] = resolved_session
        if resolved_agent:
            data["agent_id"] = resolved_agent
        if metadata:
            data["metadata"] = json.dumps(metadata)
        if ttl:
            data["ttl"] = ttl

        headers: dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        resp = self._request("POST", "/v1/artifacts", files=files, data=data, headers=headers)
        return Artifact(resp.json())

    def push_dict(
        self,
        data: dict[str, Any],
        *,
        filename: str = "data.json",
        session_id: str | None = None,
        agent_id: str | None = None,
        metadata: dict[str, str] | None = None,
        ttl: str | None = None,
        idempotency_key: str | None = None,
    ) -> Artifact:
        """Serialize a dict to JSON and push as an artifact.

        Sets content_type to application/json.
        """
        try:
            content = json.dumps(data).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise InvalidRequestError(f"Data is not JSON-serializable: {exc}") from exc

        return self.push(
            content=content,
            filename=filename,
            session_id=session_id,
            agent_id=agent_id,
            metadata=metadata,
            ttl=ttl,
            idempotency_key=idempotency_key,
        )

    # --- Pull methods ---

    def pull(
        self,
        artifact_id: str,
        *,
        output: str | Path = ".",
    ) -> Path:
        """Download an artifact to disk.

        Args:
            artifact_id: The artifact ID to download.
            output: Directory or file path to save to. If a directory,
                the artifact's original filename is used.

        Returns:
            Path to the downloaded file.
        """
        # Get artifact metadata for filename
        meta_resp = self._request("GET", f"/v1/artifacts/{artifact_id}")
        artifact_data = meta_resp.json()

        # Get download URL
        dl_resp = self._request("GET", f"/v1/artifacts/{artifact_id}/download-url")
        download_url = dl_resp.json()["download_url"]

        # Download the file bytes
        file_bytes = self._download_bytes(download_url)

        # Determine output path
        out_path = Path(output)
        if out_path.is_dir() or str(output).endswith("/"):
            out_path.mkdir(parents=True, exist_ok=True)
            out_path = out_path / artifact_data["filename"]
        else:
            out_path.parent.mkdir(parents=True, exist_ok=True)

        out_path.write_bytes(file_bytes)
        return out_path

    def pull_bytes(self, artifact_id: str) -> bytes:
        """Download artifact content as bytes in memory.

        No file is written to disk.

        Raises:
            ArtifactNotFoundError: If the artifact does not exist.
            ArtifactExpiredError: If the artifact has expired.
        """
        dl_resp = self._request("GET", f"/v1/artifacts/{artifact_id}/download-url")
        download_url = dl_resp.json()["download_url"]
        return self._download_bytes(download_url)

    def pull_dict(self, artifact_id: str) -> dict[str, Any]:
        """Download artifact content and deserialize as JSON.

        Raises:
            InvalidRequestError: If content is not valid JSON.
            ArtifactNotFoundError: If the artifact does not exist.
            ArtifactExpiredError: If the artifact has expired.
        """
        content = self.pull_bytes(artifact_id)
        try:
            return json.loads(content.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise InvalidRequestError("Artifact content is not valid JSON") from exc

    # --- Extended methods ---

    def list(
        self,
        *,
        session_id: str | None = None,
        agent_id: str | None = None,
        metadata: dict[str, str] | None = None,
        limit: int = 50,
        auto_paginate: bool = True,
        cursor: str | None = None,
    ) -> ListResult:
        """List artifacts with optional filters.

        Args:
            session_id: Filter by session ID.
            agent_id: Filter by agent ID.
            metadata: Key-value pairs for metadata filter (AND semantics).
                Single key works on all tiers. Multiple keys require Pro plan
                (raises QuotaExceededError on Free tier).
            limit: Page size per request.
            auto_paginate: If True (default), fetches all pages. If False,
                fetches one page — use .next_cursor for the next page.
            cursor: Pagination cursor from a previous ListResult.next_cursor.

        Returns:
            ListResult with .artifacts, .has_more, .next_cursor.
            Supports iteration (for art in result) and len(result).
        """
        resolved_session = self._resolve_session_id(session_id)
        resolved_agent = self._resolve_agent_id(agent_id)

        params: dict[str, str | int] = {"limit": limit}
        if resolved_session is not None:
            params["session_id"] = resolved_session
        if resolved_agent is not None:
            params["agent_id"] = resolved_agent
        if metadata:
            for key, value in metadata.items():
                params[f"metadata.{key}"] = value

        all_artifacts: list[Artifact] = []
        current_cursor = cursor

        while True:
            if current_cursor:
                params["cursor"] = current_cursor
            resp = self._request("GET", "/v1/artifacts", params=params)
            body = resp.json()
            for item in body.get("artifacts", []):
                all_artifacts.append(Artifact(item))

            has_more = body.get("has_more", False)
            next_cursor = body.get("next_cursor")

            if not auto_paginate or not has_more or not next_cursor:
                return ListResult(all_artifacts, has_more, next_cursor)

            current_cursor = next_cursor

    def get(self, artifact_id: str) -> Artifact:
        """Get a single artifact's metadata.

        Raises:
            ArtifactNotFoundError: If the artifact does not exist.
            ArtifactExpiredError: If the artifact has expired.
        """
        resp = self._request("GET", f"/v1/artifacts/{artifact_id}")
        return Artifact(resp.json())

    def delete(self, artifact_id: str) -> dict[str, Any]:
        """Soft-delete an artifact.

        Returns confirmation dict with artifact_id, deleted, deleted_at.
        Treats already-deleted artifacts as success (idempotent).
        """
        from artifacta.errors import ArtifactDeletedError

        try:
            resp = self._request("DELETE", f"/v1/artifacts/{artifact_id}")
            return resp.json()
        except ArtifactDeletedError:
            return {"artifact_id": artifact_id, "deleted": True}

    def create_link(
        self,
        artifact_id: str,
        *,
        expires_in: int | None = None,
    ) -> Link:
        """Create a shareable download link for an artifact.

        Args:
            artifact_id: The artifact to create a link for.
            expires_in: Link expiry in seconds. Defaults to 7 days if not specified.

        Returns:
            Link object with .url, .expires_at, etc.
        """
        json_body: dict[str, int] | None = None
        if expires_in is not None:
            json_body = {"expires_in": expires_in}
        resp = self._request("POST", f"/v1/artifacts/{artifact_id}/links", json=json_body)
        return Link(resp.json())

    def list_sessions(
        self,
        *,
        created_after: str | None = None,
        created_before: str | None = None,
        limit: int | None = None,
    ) -> list[Session]:
        """List sessions with auto-pagination.

        Returns:
            List of Session objects with .session_id, .artifact_count, .is_sealed, etc.
        """
        all_sessions: list[Session] = []
        cursor = None

        while True:
            params: dict[str, str] = {}
            if created_after is not None:
                params["created_after"] = created_after
            if created_before is not None:
                params["created_before"] = created_before
            if limit is not None:
                params["limit"] = str(limit)
            if cursor is not None:
                params["after"] = cursor

            query_string = "&".join(f"{k}={v}" for k, v in params.items())
            path = "/v1/sessions"
            if query_string:
                path = f"{path}?{query_string}"

            resp = self._request("GET", path)
            data = resp.json()
            for entry in data.get("sessions", []):
                all_sessions.append(Session(entry))

            if not data.get("has_more"):
                break
            cursor = data.get("next_cursor")
            if cursor is None:
                break

        return all_sessions

    def seal_session(self, session_id: str) -> SealInfo:
        """Seal a session (idempotent).

        Returns:
            SealInfo object with .session_id, .sealed_at, .artifact_count.
        """
        resp = self._request("POST", f"/v1/sessions/{session_id}/seal")
        return SealInfo(resp.json())

    def whoami(self) -> TenantInfo:
        """Return current tenant identity, plan, and usage.

        Raises:
            AuthenticationError: If the API key is invalid or revoked.
        """
        resp = self._request("GET", "/v1/whoami")
        return TenantInfo(resp.json())

    def _push_presigned(
        self,
        file_bytes: bytes,
        filename: str,
        content_type: str,
        session_id: str | None,
        agent_id: str | None,
        metadata: dict[str, str] | None,
        ttl: str | None,
    ) -> Artifact:
        """Three-step presigned upload: upload-url → PUT → complete."""
        from artifacta.errors import ArtifactaError

        # Step 1: Get presigned upload URL
        body: dict[str, Any] = {
            "filename": filename,
            "content_type": content_type,
            "size_bytes": len(file_bytes),
        }
        if session_id:
            body["session_id"] = session_id
        if agent_id:
            body["agent_id"] = agent_id
        if metadata:
            body["metadata"] = metadata
        if ttl:
            body["ttl"] = ttl

        resp = self._request("POST", "/v1/artifacts/upload-url", json=body)
        url_data = resp.json()

        # Step 2: PUT file to presigned URL
        try:
            upload_resp = httpx.request(
                url_data.get("upload_method", "PUT"),
                url_data["upload_url"],
                content=file_bytes,
                headers=url_data.get("upload_headers", {}),
                timeout=300.0,
            )
            upload_resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
            raise ArtifactaError(code="network_error", message=str(exc), status=0) from exc
        except httpx.HTTPStatusError as exc:
            raise ArtifactaError(
                code="upload_failed",
                message=f"Presigned upload failed with status {exc.response.status_code}",
                status=exc.response.status_code,
            ) from exc

        # Step 3: Complete
        artifact_id = url_data["artifact_id"]
        complete_resp = self._request("POST", f"/v1/artifacts/{artifact_id}/complete")
        return Artifact(complete_resp.json())

    def _download_bytes(self, url: str) -> bytes:
        """Download raw bytes from a presigned URL."""
        from artifacta.errors import ArtifactaError

        try:
            resp = httpx.get(url, timeout=300.0, follow_redirects=True)
            resp.raise_for_status()
            return resp.content
        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
            raise ArtifactaError(code="network_error", message=str(exc), status=0) from exc
        except httpx.HTTPStatusError as exc:
            raise ArtifactaError(
                code="download_failed",
                message=f"Download failed with status {exc.response.status_code}",
                status=exc.response.status_code,
            ) from exc

    @staticmethod
    def session_new() -> str:
        """Generate a new session ID.

        Returns a session ID string in ``ses_`` + 12 lowercase alphanumeric format.
        No Client instance or server call required.
        """
        return "ses_" + "".join(secrets.choice(SESSION_ID_CHARSET) for _ in range(12))


# Module-level convenience alias
session_new = Client.session_new
