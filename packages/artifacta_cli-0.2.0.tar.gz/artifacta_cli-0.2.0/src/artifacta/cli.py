"""Artifacta CLI entrypoint."""

from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import secrets
import string
import sys

import click

from artifacta.client import (
    EXIT_CLIENT_ERROR,
    EXIT_NETWORK_ERROR,
    EXIT_SERVER_ERROR,
    ArtifactaAPIError,
    ArtifactaNetworkError,
    api_request,
    download_bytes,
    upload_bytes_to_presigned,
)
from artifacta.config import (
    get_api_key,
    get_config_value,
    load_config,
    save_config,
    set_config_value,
)


def _err(msg: str) -> None:
    """Print error message to stderr."""
    click.echo(msg, err=True)


def _print_upgrade_url(exc: ArtifactaAPIError) -> None:
    """Print the `upgrade_url` from a tier-gated API error on its own line.

    Tier-gated endpoints (presigned uploads, --ttl never, multi-metadata
    filters, link count / expiry caps, quota overruns) attach an
    `upgrade_url` field to their error body (see AF_STRIPE-P1.3). Calling
    this right after the `_err(f"✗ {exc.message}")` line keeps the exit-code
    semantics unchanged while giving developers a direct upgrade path.

    No-op when the error did not carry `upgrade_url`.
    """
    if exc.upgrade_url:
        _err(f"  Upgrade at: {exc.upgrade_url}")


def _emit_api_error(
    exc: ArtifactaAPIError, use_json: bool, *, human_message: str | None = None
) -> None:
    """Emit an API error according to output mode, then exit.

    Behaviour (AC-1.4.9 "stdout redirected → data on stdout is JSON-only;
    stderr has human format including upgrade URL"):

    - Always write the human message (`✗ <message>` + optional
      `  Upgrade at: <url>`) to stderr. This is the observability channel
      a developer sees regardless of how stdout is being consumed.
    - Additionally, when `use_json=True` (either `--json` or auto-JSON
      because stdout is piped/redirected), emit the full error body as
      JSON to stdout so scripts and agents can parse it. The JSON body
      preserves `upgrade_url` when the server sent it (AC-1.4.3 / T-1.4.2).

    `human_message` overrides the default `exc.message` for the stderr line
    only — used when a command wants to prettify the error (e.g. resolve
    `artifact_not_found` to the requested ID) without changing the JSON
    body. The JSON shape always reflects the raw server response.

    Always raises SystemExit with the exception's exit code.
    """
    # Human half — always to stderr.
    _err(f"✗ {human_message if human_message is not None else exc.message}")
    _print_upgrade_url(exc)

    # JSON half — only when the caller is in JSON mode.
    if use_json:
        error_body: dict = {
            "error": {
                "code": exc.code,
                "message": exc.message,
                "status": exc.status,
            }
        }
        if exc.upgrade_url:
            error_body["error"]["upgrade_url"] = exc.upgrade_url
        click.echo(json.dumps(error_body))

    raise SystemExit(exc.exit_code)


# Sentry DSN for the `artifacta-cli` project. DSNs are public keys by design —
# they only grant permission to send events, not read them. Telemetry is strictly
# opt-in via ARTIFACTA_TELEMETRY=1; the sentry_sdk import is deferred so it's
# never loaded when telemetry is off.
_SENTRY_CLI_DSN = "https://b918841fa318cb99b27c66df6d4a41d4@o4511250119196672.ingest.us.sentry.io/4511250147770368"

_API_KEY_PATTERN = __import__("re").compile(r"ak_live_[A-Za-z0-9]{32}")
_SENSITIVE_KEYS = frozenset({"api_key", "apikey", "authorization", "token", "password"})


def _sentry_scrub(obj):
    """Recursively redact API-key values and sensitive field names from a Sentry event."""
    if isinstance(obj, str):
        return _API_KEY_PATTERN.sub("ak_live_[REDACTED]", obj)
    if isinstance(obj, dict):
        return {
            k: ("[REDACTED]" if isinstance(k, str) and k.lower() in _SENSITIVE_KEYS else _sentry_scrub(v))
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [_sentry_scrub(item) for item in obj]
    if isinstance(obj, tuple):
        return tuple(_sentry_scrub(item) for item in obj)
    return obj


def _sentry_before_send(event, hint):
    """Sentry callback — scrub the entire event payload before transmission."""
    try:
        return _sentry_scrub(event)
    except Exception:
        # Never block error reporting on scrubber failure — but drop the event
        # rather than send one that might still contain a key.
        return None


def _init_sentry() -> None:
    """Initialize Sentry for CLI error telemetry if user has opted in.

    Security: disables default-PII + local-variable capture (which would
    otherwise ship the user's API key in stack-frame locals) and layers a
    `before_send` scrubber as defense-in-depth.
    """
    if os.getenv("ARTIFACTA_TELEMETRY") != "1":
        return
    import sentry_sdk

    sentry_sdk.init(
        dsn=_SENTRY_CLI_DSN,
        traces_sample_rate=0.0,
        send_default_pii=False,
        include_local_variables=False,
        before_send=_sentry_before_send,
    )


# CLI-PRE-01: emit `epilog` verbatim, no indent, no word-wrap. Click's
# default formatter indents the epilog two spaces and rewraps each
# paragraph, which breaks the QA smoke greps anchored on `^Common workflow:`,
# `^Environment variables:`, and `^Examples:`.
class _EpilogGroup(click.Group):
    def format_epilog(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        if self.epilog:
            formatter.write_paragraph()
            formatter.write(self.epilog.rstrip() + "\n")


class _EpilogCommand(click.Command):
    def format_epilog(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        if self.epilog:
            formatter.write_paragraph()
            formatter.write(self.epilog.rstrip() + "\n")


# CLI-PRE-06: render root commands in workflow order rather than Click's
# default alphabetical. The data-plane loop (push → pull → ls) goes first
# so a first-time reader of `artifacta --help` sees the canonical product
# story, not utility commands like `auth` and `config`. Subgroups stay
# alphabetical — they have ≤ 3 commands each and ordering doesn't help.
#
# Adding a new top-level command means deciding where it belongs in the
# workflow, not appending. test_root_command_order_matches_workflow fails
# if a new command isn't slotted in deliberately — that's by design.
_ROOT_COMMAND_ORDER = (
    "push", "pull", "ls", "inspect", "link", "rm",
    "session", "whoami", "auth", "config",
)


class _WorkflowOrderedRootGroup(_EpilogGroup):
    def list_commands(self, ctx: click.Context) -> list[str]:
        registered = set(self.commands)
        ordered = [name for name in _ROOT_COMMAND_ORDER if name in registered]
        # Surface anything new and unranked at the end, alphabetically,
        # so a forgotten command is at least visible (the dev test will
        # still fail and prompt the engineer to slot it in properly).
        leftovers = sorted(registered - set(ordered))
        return ordered + leftovers


_ROOT_EPILOG = """\
Common workflow:
  artifacta auth login --key ak_live_xxx     # one-time setup
  artifacta push report.pdf                  # upload an artifact
  artifacta ls                               # browse what you've uploaded
  artifacta pull <artifact_id>               # download it back

Environment variables:
  ARTIFACTA_API_KEY     API key (alternative to `auth login`)
  ARTIFACTA_API_URL     API base URL (default: https://api.artifacta.io)
  ARTIFACTA_SESSION_ID  Default session_id for push
  ARTIFACTA_AGENT_ID    Default agent_id for push
  ARTIFACTA_TTL         Default artifact TTL (e.g. 30d, 24h)
  ARTIFACTA_OUTPUT      Force output mode: `json` or `human`
  ARTIFACTA_TELEMETRY   Set to `1` to enable Sentry error reporting (opt-in)

Exit codes:
  0  success
  1  client error (bad input, not found, unauthorized)
  2  server error (5xx)
  3  network error (connection refused, timeout)

Examples:
  artifacta auth login --key ak_live_xxx
  artifacta push report.pdf
  artifacta ls --session ses_abc
  artifacta pull art_abc123def456
"""

_AUTH_GROUP_EPILOG = """\
ARTIFACTA_API_KEY env var is an alternative to `auth login`. Tools that already have
the key in env do not need to log in.

Examples:
  artifacta auth login --key ak_live_xxx
  echo "ak_live_xxx" | artifacta auth login
"""

_AUTH_LOGIN_EPILOG = """\
The key is stored in `~/.config/artifacta/config.json` (or `$XDG_CONFIG_HOME/artifacta/config.json`).
ARTIFACTA_API_KEY env var takes precedence over the stored key.

Examples:
  artifacta auth login --key ak_live_xxx
  echo "ak_live_xxx" | artifacta auth login
  artifacta auth login < /path/to/key.txt
"""

_CONFIG_GROUP_EPILOG = """\
Examples:
  artifacta config set defaults.ttl 30d
  artifacta config get defaults.ttl
  artifacta config set defaults.session ses_abc
"""

_CONFIG_SET_EPILOG = """\
Examples:
  artifacta config set defaults.ttl 30d
  artifacta config set defaults.session ses_abc
  artifacta config set defaults.agent agent-prod
"""

_CONFIG_GET_EPILOG = """\
Examples:
  artifacta config get defaults.ttl
  artifacta config get defaults.session
  artifacta config get auth.api_key
"""

_PUSH_EPILOG = """\
When reading from stdin (`-`), --name is required. Use --presigned for files
larger than ~500 MB (Pro plan). The artifact ID is printed to stdout on success.

Retry safety: when --idempotency-key is omitted, push derives a stable key
from (file content hash, filename, session, agent). Identical retries within
the API's 24h dedup window return the same artifact_id instead of creating
duplicates. Pass --idempotency-key explicitly to override.

Examples:
  artifacta push report.pdf
  artifacta push report.pdf --session ses_abc --meta stage=final
  artifacta push - --name out.json --content-type application/json
  cat report.pdf | artifacta push -
"""

_PULL_EPILOG = """\
If -o is omitted, the file is saved to the current directory using the original filename.
Use `-o -` to write to stdout.

Examples:
  artifacta pull art_abc123def456
  artifacta pull art_abc123def456 -o /tmp/report.pdf
  artifacta pull art_abc123def456 -o -
"""

_LS_EPILOG = """\
Results are sorted by created_at DESC. Use --after <cursor> to paginate when
has_more is true.

Examples:
  artifacta ls
  artifacta ls --session ses_abc
  artifacta ls --agent agent-prod --limit 100
  artifacta ls --after eyJjcmVhdGVkX2F0...
"""

_INSPECT_EPILOG = """\
Returns: artifact_id, filename, content_type, size_bytes, content_hash,
created_at, expires_at, session_id, agent_id, metadata.

Examples:
  artifacta inspect art_abc123def456
  artifacta inspect art_abc123def456 --json
  artifacta inspect art_abc123def456 | jq .metadata
"""

_RM_EPILOG = """\
Warning: `--session` deletes every artifact in that session. Use `--dry-run` to preview.

Examples:
  artifacta rm art_abc123def456
  artifacta rm art_abc123def456 --yes
  artifacta rm --session ses_abc --dry-run
  artifacta rm --session ses_abc --yes
"""

_LINK_EPILOG = """\
The signed URL is printed to stdout on success. Free plan max expiry: 30d.
Pro plan max expiry: 90d.

Examples:
  artifacta link art_abc123def456
  artifacta link art_abc123def456 --expires 24h
  artifacta link art_abc123def456 --expires 7d --json
"""

_WHOAMI_EPILOG = """\
Use this as a "is my key working?" check. Returns tenant, plan, current usage,
and rate limits.

Examples:
  artifacta whoami
  artifacta whoami --json
  artifacta whoami --json | jq .plan
"""

_SESSION_GROUP_EPILOG = """\
A session groups related artifacts (e.g., one agent run, one workflow). Set
--session on push, list/filter by it, and seal it when the work is complete.

Examples:
  artifacta session new
  artifacta session ls
  artifacta session seal ses_abc
"""

_SESSION_NEW_EPILOG = """\
Examples:
  artifacta session new
  artifacta session new | tee /tmp/sid.txt
  artifacta session new | xargs -I {} artifacta push report.pdf --session {}
"""

_SESSION_LS_EPILOG = """\
Examples:
  artifacta session ls
  artifacta session ls --limit 50
  artifacta session ls --json | jq '.sessions[].session_id'
"""

_SESSION_SEAL_EPILOG = """\
Warning: Sealing is irreversible. Sealed sessions cannot accept new artifacts.

Examples:
  artifacta session seal ses_abc
  artifacta session seal ses_abc --json
  artifacta session ls --json | jq -r '.sessions[0].session_id' | xargs artifacta session seal
"""


@click.group(cls=_WorkflowOrderedRootGroup, epilog=_ROOT_EPILOG)
@click.version_option(package_name="artifacta-cli")
def main() -> None:
    """Artifacta — artifact store for AI agents."""
    _init_sentry()


# --- auth group ---


@main.group(cls=_EpilogGroup, epilog=_AUTH_GROUP_EPILOG)
def auth() -> None:
    """Manage authentication."""


@auth.command("login", cls=_EpilogCommand, epilog=_AUTH_LOGIN_EPILOG)
@click.option("--key", default=None, help="API key (non-interactive)")
def auth_login(key: str | None) -> None:
    """Authenticate with an API key."""
    if key is None:
        if not sys.stdin.isatty():
            # CLI-PRE-03: when stdin is piped (CI scripts, agents), read the
            # key from stdin instead of blocking on click.prompt forever.
            key = sys.stdin.readline().strip()
            if not key:
                _err("✗ No API key provided on stdin.")
                raise SystemExit(EXIT_CLIENT_ERROR)
        else:
            key = click.prompt("API key", hide_input=True)

    # Validate the key against the API server
    try:
        api_request("GET", "/v1/whoami", api_key=key)
    except ArtifactaAPIError as exc:
        if exc.status == 401:
            _err("✗ Invalid API key. Check your key at https://artifacta.io/settings/keys")
            raise SystemExit(EXIT_CLIENT_ERROR)
        _err(f"✗ Authentication failed. ({exc.message})")
        raise SystemExit(EXIT_CLIENT_ERROR)
    except ArtifactaNetworkError:
        _err("✗ Authentication failed.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    # Store in config file
    cfg = load_config()
    cfg.setdefault("auth", {})["api_key"] = key
    cfg.setdefault("defaults", {})
    save_config(cfg)

    last_4 = key[-4:] if len(key) >= 4 else key
    click.echo(f"✓ Authenticated (key ending in ...{last_4})")


# --- config group ---


@main.group("config", cls=_EpilogGroup, epilog=_CONFIG_GROUP_EPILOG)
def config_group() -> None:
    """Manage CLI configuration."""


@config_group.command("set", cls=_EpilogCommand, epilog=_CONFIG_SET_EPILOG)
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str) -> None:
    """Set a configuration value (e.g., defaults.ttl 30d)."""
    set_config_value(key, value)
    click.echo(f"✓ Set {key} = {value}")


@config_group.command("get", cls=_EpilogCommand, epilog=_CONFIG_GET_EPILOG)
@click.argument("key")
def config_get(key: str) -> None:
    """Get a configuration value."""
    val = get_config_value(key)
    if val is None:
        _err(f"✗ Key '{key}' not found in config.")
        raise SystemExit(EXIT_CLIENT_ERROR)
    click.echo(val)


# --- push ---

SESSION_ID_CHARSET = string.ascii_lowercase + string.digits


def _generate_session_id() -> str:
    """Generate ses_ + 12 lowercase alphanumeric characters."""
    return "ses_" + "".join(secrets.choice(SESSION_ID_CHARSET) for _ in range(12))


def _resolve_output_mode(json_flag: bool, human_flag: bool) -> bool:
    """Determine if output should be JSON, respecting flags and ARTIFACTA_OUTPUT env var."""
    if human_flag:
        return False
    if json_flag:
        return True
    env_output = os.environ.get("ARTIFACTA_OUTPUT", "").lower()
    if env_output == "json":
        return True
    if env_output == "human":
        return False
    return not sys.stdout.isatty()


@main.command(cls=_EpilogCommand, epilog=_PUSH_EPILOG)
@click.argument("file", default=None, required=False)
@click.option("--session", "session_id", default=None, help="Attach to a session")
@click.option("--new-session", "new_session", is_flag=True, default=False, help="Auto-generate a session ID")
@click.option("--agent", "agent_id", default=None, help="Tag with agent ID")
@click.option("--meta", multiple=True, help="Metadata key=value (repeatable)")
@click.option("--ttl", default=None, help="Override default TTL (e.g., 30d, 24h)")
@click.option("--name", "filename", default=None, help="Override filename (required for stdin)")
@click.option("--content-type", "content_type", default=None, help="Override content type")
@click.option("--idempotency-key", "idempotency_key", default=None, help="Idempotency key for retry safety")
@click.option("--presigned", is_flag=True, default=False, help="Use presigned URL upload (large files)")
@click.option("--link", "create_link", is_flag=True, default=False, help="Create a 7-day download link after upload")
@click.option("--json", "json_flag", is_flag=True, default=False, help="Output as JSON")
@click.option("--human", "human_flag", is_flag=True, default=False, help="Force human output")
def push(
    file: str | None,
    session_id: str | None,
    new_session: bool,
    agent_id: str | None,
    meta: tuple[str, ...],
    ttl: str | None,
    filename: str | None,
    content_type: str | None,
    idempotency_key: str | None,
    presigned: bool,
    create_link: bool,
    json_flag: bool,
    human_flag: bool,
) -> None:
    """Upload a file as an artifact. Use '-' to read from stdin."""
    use_json = _resolve_output_mode(json_flag, human_flag)

    if not get_api_key():
        _err("✗ No API key configured. Run `artifacta auth login` or set ARTIFACTA_API_KEY.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    # Read file content
    if file is None or file == "-":
        # Stdin mode
        if filename is None:
            _err("✗ --name is required when reading from stdin.")
            raise SystemExit(EXIT_CLIENT_ERROR)
        file_data = sys.stdin.buffer.read()
    else:
        import pathlib

        path = pathlib.Path(file)
        if not path.exists():
            _err(f"✗ File not found: {file}")
            raise SystemExit(EXIT_CLIENT_ERROR)
        file_data = path.read_bytes()
        if filename is None:
            filename = path.name

    # Auto-detect content type
    if content_type is None:
        ct, _ = mimetypes.guess_type(filename or "")
        content_type = ct or "application/octet-stream"

    # Resolve session
    generated_session_id = None
    if new_session:
        generated_session_id = _generate_session_id()
        session_id = generated_session_id
    elif session_id is None:
        session_id = os.environ.get("ARTIFACTA_SESSION_ID") or None

    # Resolve agent
    if agent_id is None:
        agent_id = os.environ.get("ARTIFACTA_AGENT_ID") or None

    # Resolve TTL
    if ttl is None:
        ttl = os.environ.get("ARTIFACTA_TTL") or None

    # Parse metadata
    metadata: dict[str, str] = {}
    for item in meta:
        if "=" not in item:
            _err(f"✗ Invalid metadata format: '{item}'. Use key=value.")
            raise SystemExit(EXIT_CLIENT_ERROR)
        k, v = item.split("=", 1)
        metadata[k] = v

    if presigned:
        # Presigned three-step flow: upload-url → PUT to R2 → complete
        data = _push_presigned(
            file_data, filename or "unnamed", content_type,
            session_id, agent_id, metadata, ttl, use_json,
        )
    else:
        # CLI-PRE-05: when --idempotency-key is omitted, derive a stable
        # default from (file_hash | filename | session | agent). Identical
        # retries of the same push (e.g. an agent retry after a network
        # blip) hit the API server's 24h dedup window and return the same
        # artifact_id instead of creating a duplicate row. Apply only on
        # the direct multipart path — the presigned flow dedups
        # server-side at `complete` time and does not need this header.
        if idempotency_key is None:
            idempotency_key = _auto_idempotency_key(
                file_data, filename or "unnamed", session_id, agent_id,
            )
        # Direct multipart upload
        data = _push_direct(
            file_data, filename or "unnamed", content_type,
            session_id, agent_id, metadata, ttl, idempotency_key, use_json,
        )

    # Inject session_id into output if --new-session was used
    if generated_session_id:
        data["session_id"] = generated_session_id

    # Create download link if --link was requested
    link_data = None
    if create_link:
        try:
            link_data = api_request(
                "POST",
                f"/v1/artifacts/{data['artifact_id']}/links",
                json={"expires_in": 604800},  # 7 days
            )
        except (ArtifactaAPIError, ArtifactaNetworkError) as exc:
            msg = exc.message if isinstance(exc, ArtifactaAPIError) else "Network error"
            _err(f"⚠ Link creation failed: {msg}")
            _err(f"  Create manually: artifacta link {data['artifact_id']}")

    if use_json:
        if link_data:
            data["link"] = {
                "link_id": link_data["link_id"],
                "url": link_data["url"],
                "expires_at": link_data["expires_at"],
            }
        click.echo(json.dumps(data))
    else:
        _err(f"✓ Uploaded {data['artifact_id']}")
        _err(f"  Filename:  {data['filename']}")
        _err(f"  Size:      {_format_bytes(data['size_bytes'])}")
        _err(f"  Hash:      {data['content_hash']}")
        expires_display = data.get("expires_at") or "never"
        _err(f"  Expires:   {expires_display}")
        if generated_session_id:
            _err(f"  Session:   {generated_session_id}")
        if link_data:
            click.echo(link_data["url"])
        else:
            # Data to stdout for scripting
            click.echo(data["artifact_id"])


def _auto_idempotency_key(
    file_data: bytes,
    filename: str,
    session_id: str | None,
    agent_id: str | None,
) -> str:
    """Derive a stable Idempotency-Key from the upload's identity.

    Per CLI-PRE-05 spec: `sha256(sha256(file)|filename|session|agent)[:32]`.
    Identical inputs produce the same 32-char hex key, so an agent retry
    of the same push hits the API's 24h dedup window. Truncating to 32
    chars keeps the header value short while preserving 128 bits of
    collision resistance — sufficient for the dedup window. The double
    SHA-256 prevents length-extension games on the joined identity
    string.
    """
    file_hash = hashlib.sha256(file_data).hexdigest()
    identity = f"{file_hash}|{filename}|{session_id or ''}|{agent_id or ''}"
    return hashlib.sha256(identity.encode()).hexdigest()[:32]


def _push_direct(
    file_data: bytes,
    filename: str,
    content_type: str,
    session_id: str | None,
    agent_id: str | None,
    metadata: dict[str, str],
    ttl: str | None,
    idempotency_key: str | None,
    use_json: bool,
) -> dict:
    """Upload via direct multipart POST."""
    files = {"file": (filename, file_data, content_type)}
    form_data: dict[str, str] = {"filename": filename}
    if session_id:
        form_data["session_id"] = session_id
    if agent_id:
        form_data["agent_id"] = agent_id
    if ttl:
        form_data["ttl"] = ttl
    if metadata:
        form_data["metadata"] = json.dumps(metadata)

    extra_headers: dict[str, str] = {}
    if idempotency_key:
        extra_headers["Idempotency-Key"] = idempotency_key

    try:
        return api_request(
            "POST", "/v1/artifacts",
            files=files, data=form_data,
            headers=extra_headers,
        )
    except ArtifactaAPIError as exc:
        human: str | None = None
        if exc.code == "session_sealed":
            human = f'Session "{session_id}" is sealed. No new artifacts can be added.'
        _emit_api_error(exc, use_json, human_message=human)
        # Unreachable — _emit_api_error always raises SystemExit.
        raise SystemExit(EXIT_CLIENT_ERROR)
    except ArtifactaNetworkError:
        _err("✗ Network error. Check your connection and API URL.")
        raise SystemExit(EXIT_NETWORK_ERROR)


def _push_presigned(
    file_data: bytes,
    filename: str,
    content_type: str,
    session_id: str | None,
    agent_id: str | None,
    metadata: dict[str, str],
    ttl: str | None,
    use_json: bool,
) -> dict:
    """Upload via presigned URL three-step flow: upload-url → PUT → complete."""

    # Step 1: Get presigned upload URL
    body: dict = {
        "filename": filename,
        "content_type": content_type,
        "size_bytes": len(file_data),
    }
    if session_id:
        body["session_id"] = session_id
    if agent_id:
        body["agent_id"] = agent_id
    if metadata:
        body["metadata"] = metadata
    if ttl:
        body["ttl"] = ttl

    try:
        url_data = api_request("POST", "/v1/artifacts/upload-url", json=body)
    except ArtifactaAPIError as exc:
        _emit_api_error(exc, use_json)
    except ArtifactaNetworkError:
        _err("✗ Network error. Check your connection and API URL.")
        raise SystemExit(EXIT_NETWORK_ERROR)

    # Step 2: PUT file to presigned URL
    try:
        upload_bytes_to_presigned(
            url_data["upload_url"],
            file_data,
            method=url_data.get("upload_method", "PUT"),
            headers=url_data.get("upload_headers", {}),
        )
    except ArtifactaNetworkError:
        _err("✗ Network error during presigned upload.")
        raise SystemExit(EXIT_NETWORK_ERROR)
    except ArtifactaAPIError as exc:
        _err(f"✗ Presigned upload failed: {exc.message}")
        raise SystemExit(exc.exit_code)

    # Step 3: Complete the upload
    artifact_id = url_data["artifact_id"]
    try:
        return api_request("POST", f"/v1/artifacts/{artifact_id}/complete")
    except ArtifactaAPIError as exc:
        _err(f"✗ {exc.message}")
        raise SystemExit(exc.exit_code)
    except ArtifactaNetworkError:
        _err("✗ Network error during upload completion.")
        raise SystemExit(EXIT_NETWORK_ERROR)


# --- whoami ---


def _format_bytes(b: int) -> str:
    """Format bytes into human-readable form."""
    if b >= 1_073_741_824:
        return f"{b / 1_073_741_824:.1f} GB"
    if b >= 1_048_576:
        return f"{b / 1_048_576:.1f} MB"
    if b >= 1024:
        return f"{b / 1024:.1f} KB"
    return f"{b} B"


@main.command(cls=_EpilogCommand, epilog=_WHOAMI_EPILOG)
@click.option("--json", "json_flag", is_flag=True, default=False, help="Output as JSON")
@click.option("--human", "human_flag", is_flag=True, default=False, help="Force human output")
def whoami(json_flag: bool, human_flag: bool) -> None:
    """Show authenticated tenant identity, plan, and usage."""
    use_json = _resolve_output_mode(json_flag, human_flag)

    if not get_api_key():
        _err("✗ No API key configured. Run `artifacta auth login` or set ARTIFACTA_API_KEY.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    try:
        data = api_request("GET", "/v1/whoami")
    except ArtifactaAPIError as exc:
        if exc.status == 401:
            _err("✗ Authentication failed. Check your key at https://artifacta.io/settings/keys")
            raise SystemExit(EXIT_CLIENT_ERROR)
        _err(f"✗ {exc.message}")
        raise SystemExit(exc.exit_code)
    except ArtifactaNetworkError:
        _err("✗ Authentication failed.")
        raise SystemExit(EXIT_NETWORK_ERROR)

    if use_json:
        click.echo(json.dumps(data))
    else:
        _err(f"Tenant:     {data['tenant_name']}")
        _err(f"Plan:       {data['plan']}")
        _err(f"API Key:    ...{data['api_key_last_4']}")
        req_used = data["usage_requests_month"]
        req_limit = data["plan_requests_limit_month"]
        _err(f"Requests:   {req_used:,} / {req_limit:,} this month")
        stor_used = _format_bytes(data["usage_storage_bytes"])
        stor_limit = _format_bytes(data["plan_storage_limit_bytes"])
        _err(f"Storage:    {stor_used} / {stor_limit}")
        # AF_CLI-10.1: Show active link quota
        if "active_links" in data and "max_active_links" in data:
            _err(f"Links:      {data['active_links']}/{data['max_active_links']} active")
        # AF_CLI-10.3: Show rate limits
        if "rate_limit_sustained" in data:
            rl_sus = data["rate_limit_sustained"]
            rl_burst = data["rate_limit_burst"]
            _err(f"Rate limit: {rl_sus}/s ({rl_burst} burst)")
        # Data to stdout for scripting
        click.echo(data["tenant_name"])


def _handle_api_error(
    exc: ArtifactaAPIError,
    resource_type: str = "Artifact",
    resource_id: str = "",
    *,
    use_json: bool = False,
) -> None:
    """Handle common API errors with user-friendly messages.

    When `use_json=True` (either `--json` flag or stdout is piped/redirected),
    emit a JSON error body to stdout that preserves the server-side fields
    including `upgrade_url` (AC-1.4.3). Otherwise print a resource-aware
    human message to stderr followed by the upgrade URL if present.
    """
    if use_json:
        _emit_api_error(exc, True)
        return  # unreachable — _emit_api_error raises

    if exc.code == "artifact_not_found":
        human = f'Artifact "{resource_id}" not found.'
    elif exc.code == "artifact_expired":
        human = f'Artifact "{resource_id}" has expired.'
    elif exc.code == "artifact_already_deleted":
        human = f'Artifact "{resource_id}" has been deleted.'
    elif exc.code == "session_not_found":
        human = f'Session "{resource_id}" not found (no artifacts with this session_id).'
    else:
        human = exc.message
    _emit_api_error(exc, False, human_message=human)


# --- pull ---


@main.command(cls=_EpilogCommand, epilog=_PULL_EPILOG)
@click.argument("artifact_id")
@click.option("-o", "--output", "output_path", default=None, help="Output path (use '-' for stdout)")
@click.option("--json", "json_flag", is_flag=True, default=False, help="Output as JSON")
@click.option("--human", "human_flag", is_flag=True, default=False, help="Force human output")
def pull(artifact_id: str, output_path: str | None, json_flag: bool, human_flag: bool) -> None:
    """Download an artifact to the local filesystem."""
    import pathlib

    use_json = _resolve_output_mode(json_flag, human_flag)

    if not get_api_key():
        _err("✗ No API key configured. Run `artifacta auth login` or set ARTIFACTA_API_KEY.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    # Get download URL
    try:
        dl_info = api_request("GET", f"/v1/artifacts/{artifact_id}/download-url")
    except ArtifactaAPIError as exc:
        _handle_api_error(exc, resource_id=artifact_id, use_json=use_json)
    except ArtifactaNetworkError:
        _err("✗ Network error. Check your connection and API URL.")
        raise SystemExit(EXIT_NETWORK_ERROR)

    # Download the file
    try:
        file_data = download_bytes(dl_info["download_url"])
    except ArtifactaNetworkError:
        _err("✗ Download failed. Network error.")
        raise SystemExit(EXIT_NETWORK_ERROR)
    except ArtifactaAPIError as exc:
        _err(f"✗ Download failed: {exc.message}")
        raise SystemExit(EXIT_CLIENT_ERROR)

    filename = dl_info.get("filename", "download")
    # Security: strip any path components the server may have included so a
    # malicious or compromised API cannot cause pull to write outside the
    # user's destination directory (e.g. filename="../../../tmp/evil").
    safe_name = pathlib.Path(filename).name or "download"

    # Output to stdout
    if output_path == "-":
        sys.stdout.buffer.write(file_data)
        return

    # Determine output file path
    if output_path is None:
        dest = pathlib.Path(safe_name)
    else:
        dest = pathlib.Path(output_path)
        if dest.is_dir():
            dest = dest / safe_name

    dest.write_bytes(file_data)

    if use_json:
        click.echo(json.dumps({
            "artifact_id": artifact_id,
            "filename": filename,
            "size_bytes": len(file_data),
            "path": str(dest),
        }))
    else:
        _err(f"✓ Downloaded {filename} ({_format_bytes(len(file_data))})")
        _err(f"  Saved to: {dest}")
        click.echo(str(dest))


# --- ls ---


@main.command("ls", cls=_EpilogCommand, epilog=_LS_EPILOG)
@click.option("--session", "session_id", default=None, help="Filter by session_id")
@click.option("--agent", "agent_id", default=None, help="Filter by agent_id")
@click.option("--meta", multiple=True, help="Filter by metadata key=value (repeatable)")
@click.option("--created-after", "created_after", default=None, help="Filter by date (ISO 8601)")
@click.option("--created-before", "created_before", default=None, help="Filter by date (ISO 8601)")
@click.option("--limit", "limit", default=None, type=int, help="Max results (default: 50)")
@click.option("--after", "cursor", default=None, help="Pagination cursor")
@click.option("--json", "json_flag", is_flag=True, default=False, help="Output as JSON")
@click.option("--human", "human_flag", is_flag=True, default=False, help="Force human output")
def ls(
    session_id: str | None,
    agent_id: str | None,
    meta: tuple[str, ...],
    created_after: str | None,
    created_before: str | None,
    limit: int | None,
    cursor: str | None,
    json_flag: bool,
    human_flag: bool,
) -> None:
    """List artifacts with optional filters."""
    use_json = _resolve_output_mode(json_flag, human_flag)

    if not get_api_key():
        _err("✗ No API key configured. Run `artifacta auth login` or set ARTIFACTA_API_KEY.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    # Build query params
    params: dict[str, str] = {}
    if session_id:
        params["session_id"] = session_id
    if agent_id:
        params["agent_id"] = agent_id
    if created_after:
        params["created_after"] = created_after
    if created_before:
        params["created_before"] = created_before
    if limit is not None:
        params["limit"] = str(limit)
    if cursor:
        params["cursor"] = cursor
    for m in meta:
        if "=" not in m:
            _err(f"✗ Invalid metadata filter: '{m}'. Use key=value.")
            raise SystemExit(EXIT_CLIENT_ERROR)
        key, value = m.split("=", 1)
        params[f"metadata.{key}"] = value

    try:
        data = api_request("GET", "/v1/artifacts", params=params)
    except ArtifactaAPIError as exc:
        _emit_api_error(exc, use_json)
    except ArtifactaNetworkError:
        _err("✗ Network error. Check your connection and API URL.")
        raise SystemExit(EXIT_NETWORK_ERROR)

    artifacts = data.get("artifacts", [])

    if use_json:
        click.echo(json.dumps(data))
    else:
        if not artifacts:
            _err("No artifacts found.")
            return

        # Tabular output
        _err(f"{'ARTIFACT ID':<24}{'FILENAME':<24}{'SIZE':<10}{'CREATED':<21}{'EXPIRES'}")
        total_bytes = 0
        for art in artifacts:
            aid = art["artifact_id"]
            fname = art["filename"][:22]
            size_str = _format_bytes(art["size_bytes"])
            total_bytes += art["size_bytes"]
            created = art["created_at"][:16].replace("T", " ") if art.get("created_at") else ""
            expires = art["expires_at"][:10] if art.get("expires_at") else "never"
            _err(f"{aid:<24}{fname:<24}{size_str:<10}{created:<21}{expires}")

        _err(f"\n{len(artifacts)} artifact{'s' if len(artifacts) != 1 else ''}, {_format_bytes(total_bytes)} total")

        if data.get("has_more"):
            _err(f"More results available. Use --after {data['next_cursor']}")


# --- inspect ---


@main.command(cls=_EpilogCommand, epilog=_INSPECT_EPILOG)
@click.argument("artifact_id")
@click.option("--json", "json_flag", is_flag=True, default=False, help="Output as JSON")
@click.option("--human", "human_flag", is_flag=True, default=False, help="Force human output")
def inspect(artifact_id: str, json_flag: bool, human_flag: bool) -> None:
    """Show detailed metadata for a single artifact."""
    use_json = _resolve_output_mode(json_flag, human_flag)

    if not get_api_key():
        _err("✗ No API key configured. Run `artifacta auth login` or set ARTIFACTA_API_KEY.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    try:
        data = api_request("GET", f"/v1/artifacts/{artifact_id}")
    except ArtifactaAPIError as exc:
        _handle_api_error(exc, resource_id=artifact_id, use_json=use_json)
    except ArtifactaNetworkError:
        _err("✗ Network error. Check your connection and API URL.")
        raise SystemExit(EXIT_NETWORK_ERROR)

    if use_json:
        click.echo(json.dumps(data))
    else:
        _err(f"Artifact:     {data['artifact_id']}")
        _err(f"Filename:     {data['filename']}")
        _err(f"Content-Type: {data['content_type']}")
        _err(f"Size:         {_format_bytes(data['size_bytes'])}")
        _err(f"Hash:         {data['content_hash']}")
        _err(f"Created:      {data['created_at']}")
        _err(f"Expires:      {data['expires_at'] or 'never'}")
        if data.get("session_id"):
            _err(f"Session:      {data['session_id']}")
        if data.get("agent_id"):
            _err(f"Agent:        {data['agent_id']}")
        metadata = data.get("metadata", {})
        if metadata:
            _err("Metadata:")
            for k, v in metadata.items():
                _err(f"  {k}: {v}")
        # Data to stdout
        click.echo(data["artifact_id"])


# --- rm ---


@main.command("rm", cls=_EpilogCommand, epilog=_RM_EPILOG)
@click.argument("artifact_ids", nargs=-1)
@click.option("--session", "session_ids", multiple=True, help="Delete all artifacts in session(s)")
@click.option("--force", "--yes", "force", is_flag=True, default=False,
              help="Skip confirmation prompt")
@click.option("--dry-run", "dry_run", is_flag=True, default=False,
              help="Show what would be deleted, do not delete.")
@click.option("--json", "json_flag", is_flag=True, default=False, help="Output as JSON")
@click.option("--human", "human_flag", is_flag=True, default=False, help="Force human output")
def rm(
    artifact_ids: tuple[str, ...],
    session_ids: tuple[str, ...],
    force: bool,
    dry_run: bool,
    json_flag: bool,
    human_flag: bool,
) -> None:
    """Delete one or more artifacts by ID or session."""
    use_json = _resolve_output_mode(json_flag, human_flag)

    if not get_api_key():
        _err("✗ No API key configured. Run `artifacta auth login` or set ARTIFACTA_API_KEY.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    if not artifact_ids and not session_ids:
        _err("✗ Provide artifact IDs or --session flag.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    # Collect artifact IDs to delete (and, for dry-run, the per-artifact
    # summaries returned by the lookup so we can render the same tabular
    # output as `ls` per AC-PRE-02 #5/#6).
    ids_to_delete: list[str] = list(artifact_ids)
    session_summaries_by_id: dict[str, dict] = {}

    # Resolve --session: list artifacts then collect IDs
    for sid in session_ids:
        try:
            data = api_request("GET", "/v1/artifacts", params={"session_id": sid, "limit": "200"})
        except ArtifactaAPIError as exc:
            _err(f"✗ {exc.message}")
            raise SystemExit(exc.exit_code)
        except ArtifactaNetworkError:
            _err("✗ Network error.")
            raise SystemExit(EXIT_NETWORK_ERROR)

        session_artifacts = data.get("artifacts", [])
        if not session_artifacts:
            _err(f'✗ No artifacts found for session "{sid}".')
            continue
        for art in session_artifacts:
            ids_to_delete.append(art["artifact_id"])
            if dry_run:
                session_summaries_by_id[art["artifact_id"]] = art

    if not ids_to_delete:
        _err("No artifacts to delete.")
        return

    # --dry-run overrides --force: even with both flags, no DELETE is sent.
    # We do issue lookups for any explicit IDs we don't already have summaries
    # for, so the table can show filename / size / created / expires.
    if dry_run:
        ordered_summaries: list[dict] = []
        for aid in ids_to_delete:
            cached = session_summaries_by_id.pop(aid, None)
            if cached is not None:
                ordered_summaries.append(cached)
                continue
            try:
                summary = api_request("GET", f"/v1/artifacts/{aid}")
            except ArtifactaAPIError as exc:
                _handle_api_error(exc, resource_id=aid, use_json=use_json)
            except ArtifactaNetworkError:
                _err("✗ Network error. Check your connection and API URL.")
                raise SystemExit(EXIT_NETWORK_ERROR)
            ordered_summaries.append(summary)

        total_bytes = sum(s.get("size_bytes", 0) for s in ordered_summaries)
        count = len(ordered_summaries)

        if use_json:
            click.echo(json.dumps({
                "would_delete": ordered_summaries,
                "count": count,
                "total_bytes": total_bytes,
            }))
        else:
            _err(f"{'WOULD DELETE':<24}{'FILENAME':<24}{'SIZE':<10}{'CREATED':<21}{'EXPIRES'}")
            for art in ordered_summaries:
                aid = art["artifact_id"]
                fname = (art.get("filename") or "")[:22]
                size_str = _format_bytes(art.get("size_bytes", 0))
                created = art["created_at"][:16].replace("T", " ") if art.get("created_at") else ""
                expires = art["expires_at"][:10] if art.get("expires_at") else "never"
                _err(f"{aid:<24}{fname:<24}{size_str:<10}{created:<21}{expires}")
            _err(f"\n{count} artifact{'s' if count != 1 else ''} would be deleted, "
                 f"{_format_bytes(total_bytes)} total")
            for art in ordered_summaries:
                click.echo(art["artifact_id"])
        return

    # Confirmation prompt
    if not force:
        _err(f"About to delete {len(ids_to_delete)} artifact{'s' if len(ids_to_delete) != 1 else ''}.")
        if not click.confirm("Continue?", default=False, err=True):
            _err("Cancelled.")
            return

    # Delete each artifact
    deleted = []
    failed = []
    for aid in ids_to_delete:
        try:
            result = api_request("DELETE", f"/v1/artifacts/{aid}")
            deleted.append(result)
        except ArtifactaAPIError as exc:
            if exc.code == "artifact_already_deleted":
                deleted.append({"artifact_id": aid, "deleted": True, "deleted_at": "already_deleted"})
            else:
                failed.append({"artifact_id": aid, "error": exc.code, "message": exc.message})
        except ArtifactaNetworkError:
            failed.append({"artifact_id": aid, "error": "network_error", "message": "Network error"})

    if use_json:
        click.echo(json.dumps({"deleted": deleted, "failed": failed}))
    else:
        for d in deleted:
            _err(f"✓ Deleted {d['artifact_id']}")
        for f in failed:
            _err(f"✗ Failed {f['artifact_id']}: {f['message']}")
        _err(f"\n{len(deleted)} deleted, {len(failed)} failed")


# --- link ---


def _parse_expires_duration(duration: str) -> int:
    """Parse a duration string (e.g., '7d', '24h') into seconds."""
    import re

    match = re.match(r"^(\d+)(d|h|m|s)$", duration)
    if not match:
        return -1

    value = int(match.group(1))
    unit = match.group(2)
    multipliers = {"d": 86400, "h": 3600, "m": 60, "s": 1}
    return value * multipliers[unit]


@main.command(cls=_EpilogCommand, epilog=_LINK_EPILOG)
@click.argument("artifact_id")
@click.option("--expires", "expires_duration", default=None, help="Link expiry (default: 7d, max: 30d free / 90d Pro)")
@click.option("--json", "json_flag", is_flag=True, default=False, help="Output as JSON")
@click.option("--human", "human_flag", is_flag=True, default=False, help="Force human output")
def link(artifact_id: str, expires_duration: str | None, json_flag: bool, human_flag: bool) -> None:
    """Generate a temporary download link for an artifact."""
    use_json = _resolve_output_mode(json_flag, human_flag)

    if not get_api_key():
        _err("✗ No API key configured. Run `artifacta auth login` or set ARTIFACTA_API_KEY.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    # Build request body
    body: dict = {}
    if expires_duration:
        expires_in = _parse_expires_duration(expires_duration)
        if expires_in < 0:
            _err(f"✗ Invalid duration format: '{expires_duration}'. Use e.g., 7d, 24h, 60m.")
            raise SystemExit(EXIT_CLIENT_ERROR)
        body["expires_in"] = expires_in

    try:
        data = api_request(
            "POST", f"/v1/artifacts/{artifact_id}/links",
            json=body if body else None,
        )
    except ArtifactaAPIError as exc:
        _handle_api_error(exc, resource_id=artifact_id, use_json=use_json)
    except ArtifactaNetworkError:
        _err("✗ Network error.")
        raise SystemExit(EXIT_NETWORK_ERROR)

    if use_json:
        click.echo(json.dumps(data))
    else:
        _err(f"✓ Download link created")
        _err(f"  URL:        {data['url']}")
        _err(f"  Expires at: {data['expires_at']}")
        # Data to stdout for scripting
        click.echo(data["url"])


# --- session group ---


@main.group(cls=_EpilogGroup, epilog=_SESSION_GROUP_EPILOG)
def session() -> None:
    """Manage sessions."""


@session.command("new", cls=_EpilogCommand, epilog=_SESSION_NEW_EPILOG)
def session_new() -> None:
    """Generate a new session ID (local operation, no server call)."""
    sid = _generate_session_id()
    click.echo(sid)


@session.command("ls", cls=_EpilogCommand, epilog=_SESSION_LS_EPILOG)
@click.option("--limit", type=int, default=None, help="Max results per page")
@click.option("--after", default=None, help="Pagination cursor")
@click.option("--created-after", default=None, help="Filter: first artifact after this ISO timestamp")
@click.option("--created-before", default=None, help="Filter: first artifact before this ISO timestamp")
@click.option("--json", "json_flag", is_flag=True, default=False, help="Output as JSON")
@click.option("--human", "human_flag", is_flag=True, default=False, help="Force human output")
def session_ls(limit: int | None, after: str | None, created_after: str | None,
               created_before: str | None, json_flag: bool, human_flag: bool) -> None:
    """List sessions with artifact counts and seal status."""
    use_json = _resolve_output_mode(json_flag, human_flag)

    if not get_api_key():
        _err("✗ No API key configured. Run `artifacta auth login` or set ARTIFACTA_API_KEY.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    query_params: dict[str, str] = {}
    if limit is not None:
        query_params["limit"] = str(limit)
    if after is not None:
        query_params["after"] = after
    if created_after is not None:
        query_params["created_after"] = created_after
    if created_before is not None:
        query_params["created_before"] = created_before

    query_string = "&".join(f"{k}={v}" for k, v in query_params.items())
    path = "/v1/sessions"
    if query_string:
        path = f"{path}?{query_string}"

    try:
        data = api_request("GET", path)
    except ArtifactaAPIError as exc:
        _err(f"✗ {exc.message}")
        raise SystemExit(exc.exit_code)
    except ArtifactaNetworkError:
        _err("✗ Network error. Check your connection and API URL.")
        raise SystemExit(EXIT_NETWORK_ERROR)

    if use_json:
        click.echo(json.dumps(data))
    else:
        sessions = data.get("sessions", [])
        if not sessions:
            _err("No sessions found.")
            return

        _err(f"{'SESSION ID':<24}{'ARTIFACTS':>10}{'SEALED':>8}  LAST ACTIVITY")
        for s in sessions:
            sid = s["session_id"]
            count = s["artifact_count"]
            sealed = "yes" if s["is_sealed"] else "no"
            last = s["last_artifact_at"][:16].replace("T", " ") if s.get("last_artifact_at") else ""
            _err(f"{sid:<24}{count:>10}{sealed:>8}  {last}")

        _err(f"\n{len(sessions)} session{'s' if len(sessions) != 1 else ''}")
        if data.get("has_more"):
            _err(f"More results available. Use --after {data['next_cursor']}")


@session.command("seal", cls=_EpilogCommand, epilog=_SESSION_SEAL_EPILOG)
@click.argument("session_id")
@click.option("--json", "json_flag", is_flag=True, default=False, help="Output as JSON")
@click.option("--human", "human_flag", is_flag=True, default=False, help="Force human output")
def session_seal(session_id: str, json_flag: bool, human_flag: bool) -> None:
    """Seal a session to prevent new artifact uploads."""
    use_json = _resolve_output_mode(json_flag, human_flag)

    if not get_api_key():
        _err("✗ No API key configured. Run `artifacta auth login` or set ARTIFACTA_API_KEY.")
        raise SystemExit(EXIT_CLIENT_ERROR)

    try:
        data = api_request("POST", f"/v1/sessions/{session_id}/seal")
    except ArtifactaAPIError as exc:
        _handle_api_error(exc, resource_id=session_id, use_json=use_json)
    except ArtifactaNetworkError:
        _err("✗ Network error.")
        raise SystemExit(EXIT_NETWORK_ERROR)

    if use_json:
        click.echo(json.dumps(data))
    else:
        _err(f"✓ Session \"{session_id}\" sealed")
        _err(f"  Artifacts: {data['artifact_count']}")
        _err(f"  Sealed at: {data['sealed_at']}")
        click.echo(session_id)


if __name__ == "__main__":
    main()
