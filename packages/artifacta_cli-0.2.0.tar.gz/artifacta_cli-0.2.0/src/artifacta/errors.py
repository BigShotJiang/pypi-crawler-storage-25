"""Artifacta SDK error hierarchy.

Maps 1:1 to the API error code taxonomy. Agents catch specific exceptions
to decide retry vs. abort vs. branch.

Usage:
    from artifacta import Client, ArtifactaError, RateLimitedError

    try:
        client.push("file.txt", session_id="run_1")
    except RateLimitedError as e:
        time.sleep(e.retry_after_seconds)
    except ArtifactaError as e:
        print(f"Error {e.code}: {e.message}")
"""

from __future__ import annotations


class ArtifactaError(Exception):
    """Base exception for all Artifacta SDK errors.

    Attributes:
        code: API error code string (e.g., "artifact_not_found").
        message: Human-readable error description.
        status: HTTP status code from the API response.
    """

    def __init__(self, code: str, message: str, status: int) -> None:
        self.code = code
        self.message = message
        self.status = status
        super().__init__(message)


class AuthenticationError(ArtifactaError):
    """Raised when authentication fails (invalid, missing, or revoked API key)."""

    def __init__(self, message: str = "No API key found. Set ARTIFACTA_API_KEY or run `artifacta auth login`.") -> None:
        super().__init__(code="unauthorized", message=message, status=401)


class InvalidRequestError(ArtifactaError):
    """Raised for malformed or invalid requests (400)."""

    def __init__(self, message: str = "Invalid request.") -> None:
        super().__init__(code="invalid_request", message=message, status=400)


class ArtifactNotFoundError(ArtifactaError):
    """Raised when the requested artifact does not exist (404)."""

    def __init__(self, message: str = "Artifact not found.") -> None:
        super().__init__(code="artifact_not_found", message=message, status=404)


class ArtifactExpiredError(ArtifactaError):
    """Raised when the artifact's TTL has expired (410)."""

    def __init__(self, message: str = "Artifact has expired.") -> None:
        super().__init__(code="artifact_expired", message=message, status=410)


class ArtifactDeletedError(ArtifactaError):
    """Raised when the artifact has been soft-deleted (410)."""

    def __init__(self, message: str = "Artifact has been deleted.") -> None:
        super().__init__(code="artifact_already_deleted", message=message, status=410)


class SessionSealedError(ArtifactaError):
    """Raised when attempting to write to a sealed session (409)."""

    def __init__(self, message: str = "Session is sealed.") -> None:
        super().__init__(code="session_sealed", message=message, status=409)


class SessionNotFoundError(ArtifactaError):
    """Raised when the requested session does not exist (404)."""

    def __init__(self, message: str = "Session not found.") -> None:
        super().__init__(code="session_not_found", message=message, status=404)


class QuotaExceededError(ArtifactaError):
    """Raised when tenant storage or request quota is exceeded (429)."""

    def __init__(self, message: str = "Quota exceeded.") -> None:
        super().__init__(code="quota_exceeded", message=message, status=429)


class TTLExceedsPlanLimitError(ArtifactaError):
    """Raised when the requested TTL exceeds the plan's maximum (400)."""

    def __init__(self, message: str = "TTL exceeds plan limit.") -> None:
        super().__init__(code="ttl_exceeds_plan_limit", message=message, status=400)


class RateLimitedError(ArtifactaError):
    """Raised when the tenant is rate-limited (429).

    Attributes:
        retry_after_seconds: Number of seconds to wait before retrying.
    """

    def __init__(self, message: str = "Rate limited.", retry_after_seconds: float = 1.0) -> None:
        super().__init__(code="rate_limited", message=message, status=429)
        self.retry_after_seconds = retry_after_seconds


class FileTooLargeError(ArtifactaError):
    """Raised when the uploaded file exceeds the size limit (413)."""

    def __init__(self, message: str = "File too large.") -> None:
        super().__init__(code="file_too_large", message=message, status=413)


class UploadNotFoundError(ArtifactaError):
    """Raised when a pending upload is not found (404)."""

    def __init__(self, message: str = "Upload not found.") -> None:
        super().__init__(code="upload_not_found", message=message, status=404)


# Mapping from API error code string → exception subclass
ERROR_CODE_MAP: dict[str, type[ArtifactaError]] = {
    "unauthorized": AuthenticationError,
    "invalid_request": InvalidRequestError,
    "artifact_not_found": ArtifactNotFoundError,
    "artifact_expired": ArtifactExpiredError,
    "artifact_already_deleted": ArtifactDeletedError,
    "session_sealed": SessionSealedError,
    "session_not_found": SessionNotFoundError,
    "quota_exceeded": QuotaExceededError,
    "ttl_exceeds_plan_limit": TTLExceedsPlanLimitError,
    "rate_limited": RateLimitedError,
    "file_too_large": FileTooLargeError,
    "upload_not_found": UploadNotFoundError,
}


def raise_for_error_response(status: int, body: dict) -> None:
    """Parse an API error response and raise the appropriate typed exception.

    Args:
        status: HTTP status code.
        body: Parsed JSON response body (expected shape: {"error": {"code": ..., "message": ...}}).
    """
    err = body.get("error", {})
    code = err.get("code", "unknown")
    message = err.get("message", "Unknown error")

    exc_cls = ERROR_CODE_MAP.get(code, ArtifactaError)

    if exc_cls is RateLimitedError:
        retry_after = err.get("retry_after_seconds", 1.0)
        raise RateLimitedError(message=message, retry_after_seconds=retry_after)

    if exc_cls is ArtifactaError:
        # Unknown code — use base class with actual code/status
        raise ArtifactaError(code=code, message=message, status=status)

    # For typed subclasses, instantiate with just message
    exc = exc_cls(message=message)
    exc.status = status  # Preserve actual HTTP status
    raise exc
