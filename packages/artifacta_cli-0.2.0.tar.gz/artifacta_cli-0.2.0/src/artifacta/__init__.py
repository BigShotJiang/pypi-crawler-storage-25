"""Artifacta — artifact store for AI agents."""

__version__ = "0.2.0"

# Lazy imports for SDK public API — avoids circular imports at module load time

_LAZY_IMPORTS = {
    # sdk.py
    "Client": "artifacta.sdk",
    "Artifact": "artifacta.sdk",
    "Link": "artifacta.sdk",
    "Session": "artifacta.sdk",
    "ListResult": "artifacta.sdk",
    "SealInfo": "artifacta.sdk",
    "TenantInfo": "artifacta.sdk",
    "session_new": "artifacta.sdk",
    # errors.py
    "ArtifactaError": "artifacta.errors",
    "AuthenticationError": "artifacta.errors",
    "InvalidRequestError": "artifacta.errors",
    "ArtifactNotFoundError": "artifacta.errors",
    "ArtifactExpiredError": "artifacta.errors",
    "ArtifactDeletedError": "artifacta.errors",
    "SessionSealedError": "artifacta.errors",
    "SessionNotFoundError": "artifacta.errors",
    "QuotaExceededError": "artifacta.errors",
    "TTLExceedsPlanLimitError": "artifacta.errors",
    "RateLimitedError": "artifacta.errors",
    "FileTooLargeError": "artifacta.errors",
    "UploadNotFoundError": "artifacta.errors",
}


def __getattr__(name: str) -> object:
    module_path = _LAZY_IMPORTS.get(name)
    if module_path is not None:
        import importlib
        mod = importlib.import_module(module_path)
        return getattr(mod, name)
    raise AttributeError(f"module 'artifacta' has no attribute {name!r}")


__all__ = ["__version__", "Client", "session_new", *list(_LAZY_IMPORTS.keys())]
