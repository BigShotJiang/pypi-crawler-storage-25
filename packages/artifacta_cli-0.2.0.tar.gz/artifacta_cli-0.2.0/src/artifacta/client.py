"""HTTP client for the Artifacta API.

Used by both the CLI and the Python SDK.
"""

from __future__ import annotations

import httpx

from artifacta import __version__
from artifacta.config import get_api_key, get_api_url

# Exit codes per spec
EXIT_SUCCESS = 0
EXIT_CLIENT_ERROR = 1
EXIT_SERVER_ERROR = 2
EXIT_NETWORK_ERROR = 3


class ArtifactaAPIError(Exception):
    """Raised when the API returns an error response.

    Args:
        code: Error taxonomy value (e.g. "quota_exceeded").
        message: Human-readable description.
        status: HTTP status code.
        upgrade_url: Optional canonical upgrade URL surfaced by tier-gated
            errors (see AF_STRIPE-P1.3 / P1.4). When present, the CLI
            prints it on the line after the error message so developers
            running `artifacta push --ttl never`, `--presigned`, etc. get
            a direct link to upgrade.
    """

    def __init__(
        self,
        code: str,
        message: str,
        status: int,
        upgrade_url: str | None = None,
    ) -> None:
        self.code = code
        self.message = message
        self.status = status
        self.upgrade_url = upgrade_url
        super().__init__(message)

    @property
    def exit_code(self) -> int:
        if 400 <= self.status < 500:
            return EXIT_CLIENT_ERROR
        return EXIT_SERVER_ERROR


class ArtifactaNetworkError(Exception):
    """Raised on connection/timeout failures."""

    exit_code = EXIT_NETWORK_ERROR


def _build_client(api_key: str | None = None, api_url: str | None = None) -> httpx.Client:
    """Build an httpx client with auth headers."""
    key = api_key or get_api_key()
    url = api_url or get_api_url()
    headers = {"User-Agent": f"artifacta-cli/{__version__}"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    return httpx.Client(base_url=url, headers=headers, timeout=30.0)


def api_request(
    method: str,
    path: str,
    *,
    api_key: str | None = None,
    api_url: str | None = None,
    **kwargs: object,
) -> dict:
    """Make an API request. Returns parsed JSON body.

    Raises ArtifactaAPIError on 4xx/5xx, ArtifactaNetworkError on connection issues.
    """
    client = _build_client(api_key=api_key, api_url=api_url)
    try:
        resp = client.request(method, path, **kwargs)  # type: ignore[arg-type]
    except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
        raise ArtifactaNetworkError(str(exc)) from exc
    finally:
        client.close()

    if resp.status_code >= 400:
        try:
            body = resp.json()
            err = body.get("error", {})
            raise ArtifactaAPIError(
                code=err.get("code", "unknown"),
                message=err.get("message", resp.text),
                status=resp.status_code,
                upgrade_url=err.get("upgrade_url"),
            )
        except (ValueError, KeyError):
            raise ArtifactaAPIError(
                code="unknown",
                message=resp.text,
                status=resp.status_code,
            )

    return resp.json()


def upload_bytes_to_presigned(url: str, data: bytes, method: str = "PUT",
                              headers: dict[str, str] | None = None) -> None:
    """Upload bytes to a presigned URL."""
    try:
        resp = httpx.request(method, url, content=data, headers=headers or {}, timeout=300.0)
        resp.raise_for_status()
    except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
        raise ArtifactaNetworkError(str(exc)) from exc
    except httpx.HTTPStatusError as exc:
        raise ArtifactaAPIError(
            code="upload_failed",
            message=f"Presigned upload failed with status {exc.response.status_code}",
            status=exc.response.status_code,
        ) from exc


def download_bytes(url: str) -> bytes:
    """Download raw bytes from a URL. Used for artifact file downloads from presigned URLs."""
    try:
        resp = httpx.get(url, timeout=300.0, follow_redirects=True)
        resp.raise_for_status()
        return resp.content
    except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
        raise ArtifactaNetworkError(str(exc)) from exc
    except httpx.HTTPStatusError as exc:
        raise ArtifactaAPIError(
            code="download_failed",
            message=f"Download failed with status {exc.response.status_code}",
            status=exc.response.status_code,
        ) from exc
