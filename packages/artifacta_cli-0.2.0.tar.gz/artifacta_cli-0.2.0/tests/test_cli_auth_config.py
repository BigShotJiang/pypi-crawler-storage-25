"""Tests for CLI auth and config commands (AF_CLI-4.1)."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from artifacta.cli import main


@pytest.fixture
def runner():
    return CliRunner(mix_stderr=False)


@pytest.fixture
def tmp_config(tmp_path, monkeypatch):
    """Redirect config to a temp directory."""
    config_dir = tmp_path / ".config" / "artifacta"
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    return config_dir


# --- auth login ---


class TestAuthLogin:
    def test_login_with_key_flag_success(self, runner, tmp_config):
        """Non-interactive login with --key validates and stores key."""
        whoami_response = {
            "tenant_name": "Test",
            "plan": "free",
            "api_key_last_4": "ab12",
            "usage_requests_month": 0,
            "plan_requests_limit_month": 10000,
            "usage_storage_bytes": 0,
            "plan_storage_limit_bytes": 1073741824,
        }
        with patch("artifacta.cli.api_request", return_value=whoami_response) as mock_req:
            result = runner.invoke(main, ["auth", "login", "--key", "ak_live_" + "x" * 32])

        assert result.exit_code == 0
        assert "Authenticated" in result.output
        assert "...xxxx" in result.output
        mock_req.assert_called_once_with("GET", "/v1/whoami", api_key="ak_live_" + "x" * 32)

        # Verify config file was created
        config_file = tmp_config / "config.toml"
        assert config_file.exists()
        content = config_file.read_text()
        assert "ak_live_" in content

    def test_login_interactive_prompt(self, runner, tmp_config):
        """Interactive login prompts for key."""
        key = "ak_live_" + "a" * 32
        whoami_response = {"tenant_name": "Test", "plan": "free",
                           "api_key_last_4": "aaaa",
                           "usage_requests_month": 0, "plan_requests_limit_month": 10000,
                           "usage_storage_bytes": 0, "plan_storage_limit_bytes": 1073741824}
        with patch("artifacta.cli.api_request", return_value=whoami_response):
            result = runner.invoke(main, ["auth", "login"], input=key + "\n")

        assert result.exit_code == 0
        assert "Authenticated" in result.output

    def test_login_invalid_key(self, runner, tmp_config):
        """Invalid key returns error message and exit code 1."""
        from artifacta.client import ArtifactaAPIError

        with patch("artifacta.cli.api_request",
                    side_effect=ArtifactaAPIError("unauthorized", "Invalid API key.", 401)):
            result = runner.invoke(main, ["auth", "login", "--key", "bad_key"])

        assert result.exit_code == 1
        assert "Invalid API key" in result.stderr
        assert "https://artifacta.io/settings/keys" in result.stderr

    def test_login_network_error(self, runner, tmp_config):
        """Network failure returns error and exit code 1."""
        from artifacta.client import ArtifactaNetworkError

        with patch("artifacta.cli.api_request",
                    side_effect=ArtifactaNetworkError("Connection refused")):
            result = runner.invoke(main, ["auth", "login", "--key", "ak_live_" + "x" * 32])

        assert result.exit_code == 1
        assert "Authentication failed" in result.stderr


# --- CLI-PRE-03: auth login reads stdin when piped ---


class TestAuthLoginStdin:
    """When stdin is non-TTY, `auth login` (no --key) reads the key from stdin
    instead of blocking on click.prompt forever. CI scripts and agents rely
    on this for `echo $KEY | artifacta auth login`."""

    WHOAMI_OK = {
        "tenant_name": "Test", "plan": "free", "api_key_last_4": "aaaa",
        "usage_requests_month": 0, "plan_requests_limit_month": 10000,
        "usage_storage_bytes": 0, "plan_storage_limit_bytes": 1073741824,
    }

    def test_piped_key_no_trailing_newline_authenticates(self, runner, tmp_config):
        key = "ak_live_" + "a" * 32
        with patch("artifacta.cli.api_request", return_value=self.WHOAMI_OK) as mock_req:
            result = runner.invoke(main, ["auth", "login"], input=key)
        assert result.exit_code == 0, result.stderr
        assert "Authenticated" in result.output
        mock_req.assert_called_once_with("GET", "/v1/whoami", api_key=key)

    def test_piped_key_trailing_newline_stripped(self, runner, tmp_config):
        """`echo $KEY | artifacta auth login` — the trailing \\n must not
        leak into the stored key (which would later cause 401s)."""
        key = "ak_live_" + "b" * 32
        with patch("artifacta.cli.api_request", return_value=self.WHOAMI_OK) as mock_req:
            result = runner.invoke(main, ["auth", "login"], input=key + "\n")
        assert result.exit_code == 0
        mock_req.assert_called_once_with("GET", "/v1/whoami", api_key=key)

    def test_piped_key_crlf_stripped(self, runner, tmp_config):
        """Windows-style CRLF line endings are stripped along with LF."""
        key = "ak_live_" + "c" * 32
        with patch("artifacta.cli.api_request", return_value=self.WHOAMI_OK) as mock_req:
            result = runner.invoke(main, ["auth", "login"], input=key + "\r\n")
        assert result.exit_code == 0
        mock_req.assert_called_once_with("GET", "/v1/whoami", api_key=key)

    def test_empty_stdin_exits_one_without_saving(self, runner, tmp_config):
        """Empty piped input must NOT silently save an empty key."""
        with patch("artifacta.cli.api_request") as mock_req:
            result = runner.invoke(main, ["auth", "login"], input="")
        assert result.exit_code == 1
        assert "key" in result.stderr.lower()
        mock_req.assert_not_called()
        assert not (tmp_config / "config.toml").exists()

    def test_whitespace_only_stdin_exits_one(self, runner, tmp_config):
        """Whitespace-only input is treated as empty after strip()."""
        with patch("artifacta.cli.api_request") as mock_req:
            result = runner.invoke(main, ["auth", "login"], input="   \n")
        assert result.exit_code == 1
        mock_req.assert_not_called()

    def test_only_first_line_of_stdin_is_consumed(self, runner, tmp_config):
        """Multi-line stdin uses only the first line; later lines are ignored."""
        key = "ak_live_" + "d" * 32
        with patch("artifacta.cli.api_request", return_value=self.WHOAMI_OK) as mock_req:
            result = runner.invoke(main, ["auth", "login"],
                                   input=f"{key}\nshould-be-ignored\n")
        assert result.exit_code == 0
        mock_req.assert_called_once_with("GET", "/v1/whoami", api_key=key)

    def test_key_flag_wins_over_piped_stdin(self, runner, tmp_config):
        """`--key` is the documented primary interface; if both are supplied,
        --key wins and stdin is never read."""
        flag_key = "ak_live_" + "e" * 32
        piped_key = "ak_live_" + "f" * 32
        with patch("artifacta.cli.api_request", return_value=self.WHOAMI_OK) as mock_req:
            result = runner.invoke(main, ["auth", "login", "--key", flag_key],
                                   input=piped_key)
        assert result.exit_code == 0
        mock_req.assert_called_once_with("GET", "/v1/whoami", api_key=flag_key)


# --- config ---


class TestConfig:
    def test_config_set_and_get(self, runner, tmp_config):
        """Set a config value and retrieve it."""
        result = runner.invoke(main, ["config", "set", "defaults.ttl", "30d"])
        assert result.exit_code == 0
        assert "Set defaults.ttl = 30d" in result.output

        result = runner.invoke(main, ["config", "get", "defaults.ttl"])
        assert result.exit_code == 0
        assert result.output.strip() == "30d"

    def test_config_set_output_format(self, runner, tmp_config):
        """Set output_format config."""
        result = runner.invoke(main, ["config", "set", "defaults.output_format", "json"])
        assert result.exit_code == 0

        result = runner.invoke(main, ["config", "get", "defaults.output_format"])
        assert result.output.strip() == "json"

    def test_config_get_missing_key(self, runner, tmp_config):
        """Getting a nonexistent key returns error."""
        result = runner.invoke(main, ["config", "get", "nonexistent.key"])
        assert result.exit_code == 1
        assert "not found" in result.stderr


# --- env var precedence ---


class TestEnvVarPrecedence:
    def test_api_key_env_overrides_config(self, tmp_config, monkeypatch):
        """ARTIFACTA_API_KEY env var takes precedence over config file."""
        from artifacta.config import get_api_key, save_config

        # Write a key to config
        save_config({"auth": {"api_key": "ak_live_config_key_config_key_cccc"}, "defaults": {}})

        # Set env var
        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_env_key_env_key_env_keyy")

        assert get_api_key() == "ak_live_env_key_env_key_env_keyy"

    def test_api_key_falls_back_to_config(self, tmp_config, monkeypatch):
        """Without env var, api_key comes from config file."""
        from artifacta.config import get_api_key, save_config

        monkeypatch.delenv("ARTIFACTA_API_KEY", raising=False)
        save_config({"auth": {"api_key": "ak_live_from_config_file_xxxxx32"}, "defaults": {}})

        assert get_api_key() == "ak_live_from_config_file_xxxxx32"

    def test_api_url_env_overrides_default(self, monkeypatch):
        """ARTIFACTA_API_URL env var overrides default."""
        from artifacta.config import get_api_url

        monkeypatch.setenv("ARTIFACTA_API_URL", "http://localhost:8000")
        assert get_api_url() == "http://localhost:8000"

    def test_api_url_default(self, tmp_config, monkeypatch):
        """Default API URL is https://api.artifacta.io."""
        from artifacta.config import get_api_url

        monkeypatch.delenv("ARTIFACTA_API_URL", raising=False)
        assert get_api_url() == "https://api.artifacta.io"


# --- config file structure ---


class TestConfigFileStructure:
    def test_config_file_toml_structure(self, runner, tmp_config):
        """Config file has correct TOML structure after login."""
        whoami_response = {"tenant_name": "Test", "plan": "free",
                           "api_key_last_4": "ab12",
                           "usage_requests_month": 0, "plan_requests_limit_month": 10000,
                           "usage_storage_bytes": 0, "plan_storage_limit_bytes": 1073741824}
        key = "ak_live_" + "z" * 32
        with patch("artifacta.cli.api_request", return_value=whoami_response):
            runner.invoke(main, ["auth", "login", "--key", key])

        config_file = tmp_config / "config.toml"
        content = config_file.read_text()
        assert "[auth]" in content
        assert f'api_key = "{key}"' in content

    def test_config_dir_created(self, runner, tmp_config):
        """Config directory is created on first login."""
        assert not tmp_config.exists()

        whoami_response = {"tenant_name": "Test", "plan": "free",
                           "api_key_last_4": "ab12",
                           "usage_requests_month": 0, "plan_requests_limit_month": 10000,
                           "usage_storage_bytes": 0, "plan_storage_limit_bytes": 1073741824}
        with patch("artifacta.cli.api_request", return_value=whoami_response):
            runner.invoke(main, ["auth", "login", "--key", "ak_live_" + "a" * 32])

        assert tmp_config.exists()
        assert (tmp_config / "config.toml").exists()
