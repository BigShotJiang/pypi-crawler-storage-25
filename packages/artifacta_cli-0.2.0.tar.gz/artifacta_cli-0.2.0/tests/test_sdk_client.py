"""Tests for AF_CLI-5.1 — Python SDK Client and Authentication."""

from __future__ import annotations

import re

import httpx
import pytest
import respx

from artifacta import __version__


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch, tmp_path: object) -> None:
    """Clear all Artifacta env vars and config for test isolation."""
    monkeypatch.delenv("ARTIFACTA_API_KEY", raising=False)
    monkeypatch.delenv("ARTIFACTA_API_URL", raising=False)
    monkeypatch.delenv("ARTIFACTA_SESSION_ID", raising=False)
    monkeypatch.delenv("ARTIFACTA_AGENT_ID", raising=False)
    # Point config dir to tmp to prevent reading real config
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))


class TestClientCreation:
    """Test Client() initialization and credential resolution."""

    def test_explicit_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        client = Client(api_key="ak_live_test1234567890abcdef12345678")
        assert client._api_key == "ak_live_test1234567890abcdef12345678"

    def test_env_var_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_envkey1234567890abcdef1234")
        client = Client()
        assert client._api_key == "ak_live_envkey1234567890abcdef1234"

    def test_config_file_api_key(self, monkeypatch: pytest.MonkeyPatch, tmp_path: object) -> None:
        from pathlib import Path

        from artifacta.sdk import Client

        config_dir = Path(str(tmp_path)) / "artifacta"
        config_dir.mkdir(parents=True)
        (config_dir / "config.toml").write_text('[auth]\napi_key = "ak_live_cfgkey1234567890abcdef1234"\n')
        client = Client()
        assert client._api_key == "ak_live_cfgkey1234567890abcdef1234"

    def test_explicit_key_overrides_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_envkey1234567890abcdef1234")
        client = Client(api_key="ak_live_explicit1234567890abcdef12")
        assert client._api_key == "ak_live_explicit1234567890abcdef12"

    def test_no_key_raises_authentication_error(self) -> None:
        from artifacta.sdk import AuthenticationError, Client

        with pytest.raises(AuthenticationError):
            Client()

    def test_authentication_error_has_fields(self) -> None:
        from artifacta.sdk import AuthenticationError

        err = AuthenticationError()
        assert err.code == "unauthorized"
        assert err.status == 401
        assert "API key" in err.message


class TestBaseUrl:
    """Test base URL resolution."""

    def test_explicit_base_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        client = Client(base_url="https://custom.api.dev")
        assert client._base_url == "https://custom.api.dev"

    def test_env_var_base_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        monkeypatch.setenv("ARTIFACTA_API_URL", "https://env.api.dev")
        client = Client()
        assert client._base_url == "https://env.api.dev"

    def test_default_base_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        client = Client()
        assert client._base_url == "https://api.artifacta.io"


class TestEnvDefaults:
    """Test session_id and agent_id env var defaults."""

    def test_session_id_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        monkeypatch.setenv("ARTIFACTA_SESSION_ID", "ses_from_env_12")
        client = Client()
        assert client._default_session_id == "ses_from_env_12"

    def test_agent_id_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        monkeypatch.setenv("ARTIFACTA_AGENT_ID", "my_agent")
        client = Client()
        assert client._default_agent_id == "my_agent"

    def test_explicit_session_id_overrides_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        monkeypatch.setenv("ARTIFACTA_SESSION_ID", "ses_from_env_12")
        client = Client(session_id="ses_explicit_12")
        assert client._default_session_id == "ses_explicit_12"

    def test_explicit_agent_id_overrides_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        monkeypatch.setenv("ARTIFACTA_AGENT_ID", "env_agent")
        client = Client(agent_id="explicit_agent")
        assert client._default_agent_id == "explicit_agent"

    def test_missing_env_gives_none(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        client = Client()
        assert client._default_session_id is None
        assert client._default_agent_id is None


class TestHttpHeaders:
    """Test that the client sends correct headers on requests."""

    @respx.mock
    def test_authorization_header(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        client = Client(base_url="https://mock.api.dev")

        route = respx.get("https://mock.api.dev/v1/whoami").mock(
            return_value=httpx.Response(200, json={"tenant_name": "test"})
        )
        resp = client._request("GET", "/v1/whoami")
        assert route.called
        req = route.calls[0].request
        assert req.headers["authorization"] == "Bearer ak_live_test1234567890abcdef12345678"

    @respx.mock
    def test_user_agent_header(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from artifacta.sdk import Client

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
        client = Client(base_url="https://mock.api.dev")

        route = respx.get("https://mock.api.dev/v1/whoami").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        client._request("GET", "/v1/whoami")
        req = route.calls[0].request
        assert req.headers["user-agent"] == f"artifacta-sdk/{__version__}"


class TestSessionNew:
    """Test Client.session_new() static method."""

    def test_returns_ses_prefix(self) -> None:
        from artifacta.sdk import Client

        sid = Client.session_new()
        assert sid.startswith("ses_")

    def test_correct_length(self) -> None:
        from artifacta.sdk import Client

        sid = Client.session_new()
        # ses_ (4 chars) + 12 alphanumeric = 16 chars total
        assert len(sid) == 16

    def test_valid_characters(self) -> None:
        from artifacta.sdk import Client

        sid = Client.session_new()
        suffix = sid[4:]
        assert re.match(r"^[a-z0-9]{12}$", suffix)

    def test_uniqueness(self) -> None:
        from artifacta.sdk import Client

        ids = {Client.session_new() for _ in range(100)}
        assert len(ids) == 100

    def test_no_instance_required(self) -> None:
        """session_new is a static method — no Client instance or server call needed."""
        from artifacta.sdk import Client

        # Should work without any env vars or config
        sid = Client.session_new()
        assert sid.startswith("ses_")

    def test_same_format_as_cli(self) -> None:
        """Session IDs must match the CLI's _generate_session_id format."""
        from artifacta.cli import _generate_session_id
        from artifacta.sdk import Client

        cli_id = _generate_session_id()
        sdk_id = Client.session_new()
        # Both should be ses_ + 12 lowercase alphanumeric
        assert re.match(r"^ses_[a-z0-9]{12}$", cli_id)
        assert re.match(r"^ses_[a-z0-9]{12}$", sdk_id)


class TestModuleLevelImports:
    """Test that public API is importable from the package root."""

    def test_import_client(self) -> None:
        from artifacta import Client

        assert Client is not None

    def test_import_session_new(self) -> None:
        from artifacta import session_new

        sid = session_new()
        assert sid.startswith("ses_")

    def test_import_authentication_error(self) -> None:
        from artifacta import AuthenticationError

        assert issubclass(AuthenticationError, Exception)
