"""Tests for CLI pull, ls, inspect commands (AF_CLI-4.3)."""

from __future__ import annotations

import json
from unittest.mock import patch, MagicMock

import pytest
from click.testing import CliRunner

from artifacta.cli import main
from artifacta.client import ArtifactaAPIError, ArtifactaNetworkError

ARTIFACT_ID = "art_tEsT1234567890Ab"

DOWNLOAD_INFO = {
    "download_url": "https://r2.example.com/presigned-get?sig=xxx",
    "expires_in": 3600,
    "filename": "report.pdf",
    "content_type": "application/pdf",
    "size_bytes": 1024,
}

ARTIFACT_DATA = {
    "artifact_id": ARTIFACT_ID,
    "filename": "report.pdf",
    "content_type": "application/pdf",
    "size_bytes": 1024,
    "content_hash": "sha256:abc123",
    "session_id": "ses_abc123",
    "agent_id": "agent-1",
    "metadata": {"model": "claude-sonnet"},
    "expires_at": "2026-05-01T10:00:00+00:00",
    "created_at": "2026-04-01T10:00:00+00:00",
}

LIST_RESPONSE = {
    "artifacts": [ARTIFACT_DATA],
    "next_cursor": None,
    "has_more": False,
}

LIST_RESPONSE_PAGINATED = {
    "artifacts": [ARTIFACT_DATA],
    "next_cursor": "abc123cursor",
    "has_more": True,
}


@pytest.fixture
def runner():
    return CliRunner()


def _patch_key():
    return patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32)


# ============================================================================
# pull
# ============================================================================


class TestPull:
    def test_pull_to_current_dir(self, runner, tmp_path):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DOWNLOAD_INFO) as mock_api, \
             patch("artifacta.cli.download_bytes", return_value=b"file content"):
            result = runner.invoke(main, ["pull", ARTIFACT_ID, "--human"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Downloaded" in result.output

    def test_pull_to_output_dir(self, runner, tmp_path):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DOWNLOAD_INFO), \
             patch("artifacta.cli.download_bytes", return_value=b"file content"):
            result = runner.invoke(
                main, ["pull", ARTIFACT_ID, "-o", str(tmp_path), "--human"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert (tmp_path / "report.pdf").exists()
            assert (tmp_path / "report.pdf").read_bytes() == b"file content"

    def test_pull_to_stdout(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DOWNLOAD_INFO), \
             patch("artifacta.cli.download_bytes", return_value=b"raw file data"):
            result = runner.invoke(main, ["pull", ARTIFACT_ID, "-o", "-"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "raw file data" in result.output

    def test_pull_json_output(self, runner, tmp_path):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DOWNLOAD_INFO), \
             patch("artifacta.cli.download_bytes", return_value=b"file content"):
            result = runner.invoke(
                main, ["pull", ARTIFACT_ID, "-o", str(tmp_path), "--json"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            body = json.loads(result.output)
            assert body["artifact_id"] == ARTIFACT_ID
            assert body["filename"] == "report.pdf"
            assert "path" in body

    def test_pull_not_found(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=ArtifactaAPIError(
                 "artifact_not_found", "Not found", 404)):
            result = runner.invoke(main, ["pull", ARTIFACT_ID, "--human"])
            assert result.exit_code == 1
            assert "not found" in result.output.lower()

    def test_pull_expired(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=ArtifactaAPIError(
                 "artifact_expired", "Expired", 410)):
            result = runner.invoke(main, ["pull", ARTIFACT_ID, "--human"])
            assert result.exit_code == 1
            assert "expired" in result.output.lower()

    def test_pull_no_key(self, runner):
        with patch("artifacta.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["pull", ARTIFACT_ID, "--human"])
            assert result.exit_code == 1

    def test_pull_network_error(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=ArtifactaNetworkError("conn refused")):
            result = runner.invoke(main, ["pull", ARTIFACT_ID, "--human"])
            assert result.exit_code == 3

    def test_pull_rejects_path_traversal_filename(self, runner, tmp_path):
        """QA-CLI-500: a malicious server-provided filename cannot escape dest dir.

        If the API returns filename='../../../evil.txt', the CLI must strip the
        path components and write strictly inside the output directory.
        """
        malicious_download = {**DOWNLOAD_INFO, "filename": "../../../evil-qa500.txt"}
        outdir = tmp_path / "outdir"
        outdir.mkdir()
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=malicious_download), \
             patch("artifacta.cli.download_bytes", return_value=b"should stay contained"):
            result = runner.invoke(
                main, ["pull", ARTIFACT_ID, "-o", str(outdir), "--human"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            # File must land inside outdir with the basename only — never at
            # tmp_path/evil-qa500.txt or any ancestor.
            assert (outdir / "evil-qa500.txt").exists()
            assert (outdir / "evil-qa500.txt").read_bytes() == b"should stay contained"
            # Verify escape paths were NOT written
            assert not (tmp_path / "evil-qa500.txt").exists()
            assert not (tmp_path.parent / "evil-qa500.txt").exists()

    def test_pull_rejects_path_traversal_with_no_output_flag(self, runner, tmp_path, monkeypatch):
        """QA-CLI-500 (no -o variant): traversal is stripped even without an output flag."""
        malicious_download = {**DOWNLOAD_INFO, "filename": "../../../outside-cwd.txt"}
        monkeypatch.chdir(tmp_path)
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=malicious_download), \
             patch("artifacta.cli.download_bytes", return_value=b"stays in cwd"):
            result = runner.invoke(main, ["pull", ARTIFACT_ID, "--human"], catch_exceptions=False)
            assert result.exit_code == 0
            # File lands in cwd (tmp_path), not in any ancestor dir
            assert (tmp_path / "outside-cwd.txt").exists()
            assert not (tmp_path.parent / "outside-cwd.txt").exists()


# ============================================================================
# ls
# ============================================================================


class TestLs:
    def test_ls_basic(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE):
            result = runner.invoke(main, ["ls", "--human"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "1 artifact" in result.output

    def test_ls_json(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE):
            result = runner.invoke(main, ["ls", "--json"], catch_exceptions=False)
            assert result.exit_code == 0
            body = json.loads(result.output)
            assert "artifacts" in body
            assert "next_cursor" in body
            assert "has_more" in body

    def test_ls_json_shape_last_page(self, runner):
        """Last page: next_cursor is null, has_more is false."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE):
            result = runner.invoke(main, ["ls", "--json"], catch_exceptions=False)
            body = json.loads(result.output)
            assert body["next_cursor"] is None
            assert body["has_more"] is False

    def test_ls_json_shape_with_more(self, runner):
        """Paginated: next_cursor is a string, has_more is true."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE_PAGINATED):
            result = runner.invoke(main, ["ls", "--json"], catch_exceptions=False)
            body = json.loads(result.output)
            assert body["next_cursor"] == "abc123cursor"
            assert body["has_more"] is True

    def test_ls_empty(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value={"artifacts": [], "next_cursor": None, "has_more": False}):
            result = runner.invoke(main, ["ls", "--human"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "No artifacts found" in result.output

    def test_ls_with_session_filter(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE) as mock_api:
            result = runner.invoke(main, ["ls", "--session", "ses_abc", "--json"], catch_exceptions=False)
            assert result.exit_code == 0
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["params"]["session_id"] == "ses_abc"

    def test_ls_with_agent_filter(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE) as mock_api:
            result = runner.invoke(main, ["ls", "--agent", "agent-1", "--json"], catch_exceptions=False)
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["params"]["agent_id"] == "agent-1"

    def test_ls_with_meta_filter(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE) as mock_api:
            result = runner.invoke(main, ["ls", "--meta", "model=claude", "--json"], catch_exceptions=False)
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["params"]["metadata.model"] == "claude"

    def test_ls_with_date_filters(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE) as mock_api:
            result = runner.invoke(
                main,
                ["ls", "--created-after", "2026-01-01", "--created-before", "2026-12-31", "--json"],
                catch_exceptions=False,
            )
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["params"]["created_after"] == "2026-01-01"
            assert call_kwargs["params"]["created_before"] == "2026-12-31"

    def test_ls_with_limit(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE) as mock_api:
            result = runner.invoke(main, ["ls", "--limit", "10", "--json"], catch_exceptions=False)
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["params"]["limit"] == "10"

    def test_ls_with_cursor(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE) as mock_api:
            result = runner.invoke(main, ["ls", "--after", "abc123", "--json"], catch_exceptions=False)
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["params"]["cursor"] == "abc123"

    def test_ls_with_multi_meta_filter(self, runner):
        """Multiple --meta flags send all metadata params to API (AF_CLI-9.1)."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE) as mock_api:
            result = runner.invoke(
                main,
                ["ls", "--meta", "model=claude", "--meta", "status=complete", "--json"],
                catch_exceptions=False,
            )
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["params"]["metadata.model"] == "claude"
            assert call_kwargs["params"]["metadata.status"] == "complete"

    def test_ls_meta_value_with_equals(self, runner):
        """--meta equation=a=b parses as key=equation, value=a=b (AF_CLI-9.1)."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE) as mock_api:
            result = runner.invoke(
                main,
                ["ls", "--meta", "equation=a=b", "--json"],
                catch_exceptions=False,
            )
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["params"]["metadata.equation"] == "a=b"

    def test_ls_invalid_meta(self, runner):
        with _patch_key():
            result = runner.invoke(main, ["ls", "--meta", "badformat", "--human"])
            assert result.exit_code == 1

    def test_ls_tabular_output(self, runner):
        """Human output shows tabular header."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE):
            result = runner.invoke(main, ["ls", "--human"], catch_exceptions=False)
            assert "ARTIFACT ID" in result.output
            assert "FILENAME" in result.output

    def test_ls_pagination_hint(self, runner):
        """Shows cursor hint when more results available."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE_PAGINATED):
            result = runner.invoke(main, ["ls", "--human"], catch_exceptions=False)
            assert "More results available" in result.output
            assert "abc123cursor" in result.output

    def test_ls_no_key(self, runner):
        with patch("artifacta.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["ls", "--human"])
            assert result.exit_code == 1

    def test_ls_human_no_json_on_stdout(self, runner):
        """--human outputs only the table, no JSON dump (AF_CLI-8.2 regression)."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE):
            result = runner.invoke(main, ["ls", "--human"], catch_exceptions=False)
            assert result.exit_code == 0
            # Table header should be present
            assert "ARTIFACT ID" in result.output
            # JSON object must NOT appear in output
            for line in result.output.strip().splitlines():
                line = line.strip()
                if line.startswith("{"):
                    pytest.fail(f"Unexpected JSON in --human output: {line}")

    def test_ls_json_no_table(self, runner):
        """--json outputs only JSON, no tabular header."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE):
            result = runner.invoke(main, ["ls", "--json"], catch_exceptions=False)
            assert result.exit_code == 0
            body = json.loads(result.output.strip())
            assert "artifacts" in body
            assert "ARTIFACT ID" not in result.output

    def test_ls_auto_json(self, runner):
        """CliRunner stdout is not a tty, so auto-JSON kicks in without --json flag."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LIST_RESPONSE):
            result = runner.invoke(main, ["ls"], catch_exceptions=False)
            # Should output JSON because CliRunner stdout is not a tty
            body = json.loads(result.output)
            assert "artifacts" in body


# ============================================================================
# inspect
# ============================================================================


class TestInspect:
    def test_inspect_success(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=ARTIFACT_DATA):
            result = runner.invoke(main, ["inspect", ARTIFACT_ID, "--human"], catch_exceptions=False)
            assert result.exit_code == 0
            assert ARTIFACT_ID in result.output

    def test_inspect_shows_all_fields(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=ARTIFACT_DATA):
            result = runner.invoke(main, ["inspect", ARTIFACT_ID, "--human"], catch_exceptions=False)
            assert "report.pdf" in result.output
            assert "application/pdf" in result.output
            assert "sha256:" in result.output
            assert "ses_abc123" in result.output
            assert "agent-1" in result.output
            assert "model" in result.output  # metadata key
            assert "claude-sonnet" in result.output  # metadata value

    def test_inspect_json(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=ARTIFACT_DATA):
            result = runner.invoke(main, ["inspect", ARTIFACT_ID, "--json"], catch_exceptions=False)
            body = json.loads(result.output)
            assert body["artifact_id"] == ARTIFACT_ID
            assert body["filename"] == "report.pdf"

    def test_inspect_not_found(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=ArtifactaAPIError(
                 "artifact_not_found", "Not found", 404)):
            result = runner.invoke(main, ["inspect", ARTIFACT_ID, "--human"])
            assert result.exit_code == 1
            assert "not found" in result.output.lower()

    def test_inspect_expired(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=ArtifactaAPIError(
                 "artifact_expired", "Expired", 410)):
            result = runner.invoke(main, ["inspect", ARTIFACT_ID, "--human"])
            assert result.exit_code == 1
            assert "expired" in result.output.lower()

    def test_inspect_no_key(self, runner):
        with patch("artifacta.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["inspect", ARTIFACT_ID, "--human"])
            assert result.exit_code == 1

    def test_inspect_auto_json(self, runner):
        """Auto-JSON on non-tty stdout."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=ARTIFACT_DATA):
            result = runner.invoke(main, ["inspect", ARTIFACT_ID], catch_exceptions=False)
            body = json.loads(result.output)
            assert body["artifact_id"] == ARTIFACT_ID
