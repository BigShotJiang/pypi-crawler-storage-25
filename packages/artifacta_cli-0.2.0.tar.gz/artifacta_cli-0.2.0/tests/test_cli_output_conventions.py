"""Tests for CLI output conventions and env vars (AF_CLI-4.5).

Verifies cross-command consistency of auto-JSON, stderr/stdout split,
exit codes, and environment variable behavior.
"""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from artifacta.cli import main, _resolve_output_mode
from artifacta.client import ArtifactaAPIError, ArtifactaNetworkError

UPLOAD_RESPONSE = {
    "artifact_id": "art_tEsT1234567890Ab",
    "filename": "report.pdf",
    "content_type": "application/pdf",
    "size_bytes": 1024,
    "content_hash": "sha256:abcdef1234567890",
    "session_id": None,
    "agent_id": None,
    "metadata": {},
    "expires_at": "2026-05-02T00:00:00+00:00",
    "created_at": "2026-04-02T00:00:00+00:00",
}

WHOAMI_RESPONSE = {
    "tenant_name": "Test Tenant",
    "plan": "free",
    "api_key_last_4": "ab12",
    "usage_requests_month": 42,
    "plan_requests_limit_month": 10000,
    "usage_storage_bytes": 1048576,
    "plan_storage_limit_bytes": 1073741824,
}


@pytest.fixture
def runner():
    return CliRunner(mix_stderr=False)


@pytest.fixture
def tmp_file(tmp_path):
    f = tmp_path / "test.txt"
    f.write_bytes(b"test content")
    return str(f)


# --- _resolve_output_mode unit tests ---


class TestResolveOutputMode:
    def test_json_flag_true(self):
        assert _resolve_output_mode(json_flag=True, human_flag=False) is True

    def test_human_flag_true(self):
        assert _resolve_output_mode(json_flag=False, human_flag=True) is False

    def test_human_overrides_json(self):
        """--human takes precedence over --json."""
        assert _resolve_output_mode(json_flag=True, human_flag=True) is False

    def test_env_json(self, monkeypatch):
        monkeypatch.setenv("ARTIFACTA_OUTPUT", "json")
        assert _resolve_output_mode(json_flag=False, human_flag=False) is True

    def test_env_human(self, monkeypatch):
        monkeypatch.setenv("ARTIFACTA_OUTPUT", "human")
        assert _resolve_output_mode(json_flag=False, human_flag=False) is False

    def test_env_ignored_when_human_flag(self, monkeypatch):
        monkeypatch.setenv("ARTIFACTA_OUTPUT", "json")
        assert _resolve_output_mode(json_flag=False, human_flag=True) is False


# --- Exit code consistency ---


class TestExitCodes:
    def test_exit_0_on_success_push(self, runner, tmp_file):
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])
        assert result.exit_code == 0

    def test_exit_0_on_success_whoami(self, runner):
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["whoami", "--json"])
        assert result.exit_code == 0

    def test_exit_1_on_client_error_push(self, runner, tmp_file):
        err = ArtifactaAPIError("invalid_request", "Bad input", 400)
        with patch("artifacta.cli.api_request", side_effect=err), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file])
        assert result.exit_code == 1

    def test_exit_2_on_server_error_push(self, runner, tmp_file):
        err = ArtifactaAPIError("unknown", "Internal error", 500)
        with patch("artifacta.cli.api_request", side_effect=err), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file])
        assert result.exit_code == 2

    def test_exit_3_on_network_error_push(self, runner, tmp_file):
        with patch("artifacta.cli.api_request", side_effect=ArtifactaNetworkError("timeout")), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file])
        assert result.exit_code == 3

    def test_exit_3_on_network_error_whoami(self, runner, monkeypatch):
        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_" + "x" * 32)
        with patch("artifacta.cli.api_request", side_effect=ArtifactaNetworkError("timeout")):
            result = runner.invoke(main, ["whoami"])
        assert result.exit_code == 3


# --- Human output goes to stderr, data to stdout ---


class TestStderrStdoutSplit:
    def test_push_human_stderr_data_stdout(self, runner, tmp_file):
        """Push human output: decorations on stderr, artifact ID on stdout."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--human"])

        assert "✓ Uploaded" in result.stderr
        assert "art_tEsT1234567890Ab" in result.output.strip()

    def test_whoami_human_stderr_data_stdout(self, runner):
        """Whoami human output: decorations on stderr, tenant name on stdout."""
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["whoami", "--human"])

        assert "Tenant:" in result.stderr
        assert "Test Tenant" in result.output.strip()

    def test_push_json_all_to_stdout(self, runner, tmp_file):
        """Push JSON: all data to stdout, nothing decorative on stderr."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        body = json.loads(result.output)
        assert body["artifact_id"] == "art_tEsT1234567890Ab"

    def test_whoami_json_all_to_stdout(self, runner):
        """Whoami JSON: all data to stdout."""
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["whoami", "--json"])

        body = json.loads(result.output)
        assert body["tenant_name"] == "Test Tenant"


# --- Orchestrator env var integration ---


class TestOrchestratorEnvVars:
    def test_orchestrator_session_propagation(self, runner, tmp_file, monkeypatch):
        """Setting ARTIFACTA_SESSION_ID results in artifacts tagged with that session."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        monkeypatch.setenv("ARTIFACTA_SESSION_ID", "orchestrator_run_42")
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["session_id"] == "orchestrator_run_42"

    def test_explicit_session_overrides_env(self, runner, tmp_file, monkeypatch):
        """--session flag overrides ARTIFACTA_SESSION_ID."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        monkeypatch.setenv("ARTIFACTA_SESSION_ID", "env_session")
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--session", "explicit_session", "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["session_id"] == "explicit_session"

    def test_agent_env_var_used(self, runner, tmp_file, monkeypatch):
        """ARTIFACTA_AGENT_ID is used when --agent is not provided."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        monkeypatch.setenv("ARTIFACTA_AGENT_ID", "sub_agent_7")
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["agent_id"] == "sub_agent_7"

    def test_ttl_env_var_used(self, runner, tmp_file, monkeypatch):
        """ARTIFACTA_TTL is used when --ttl is not provided."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        monkeypatch.setenv("ARTIFACTA_TTL", "90d")
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["ttl"] == "90d"
