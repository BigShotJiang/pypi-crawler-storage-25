"""Tests for SDK list_sessions() method and Session response object (AF_CLI-7.2)."""

from unittest.mock import MagicMock, patch

import pytest

from artifacta.sdk import Client, Session


def _make_session_entry(sid="ses_abc123", count=5, sealed=False):
    return {
        "session_id": sid,
        "artifact_count": count,
        "is_sealed": sealed,
        "first_artifact_at": "2026-04-01T10:00:00+00:00",
        "last_artifact_at": "2026-04-02T15:00:00+00:00",
    }


def _mock_response(json_data, status_code=200):
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.is_success = status_code < 400
    return resp


class TestSessionObject:

    def test_properties(self):
        data = _make_session_entry("ses_x", 10, True)
        s = Session(data)
        assert s.session_id == "ses_x"
        assert s.artifact_count == 10
        assert s.is_sealed is True
        assert s.first_artifact_at == "2026-04-01T10:00:00+00:00"
        assert s.last_artifact_at == "2026-04-02T15:00:00+00:00"

    def test_to_dict(self):
        data = _make_session_entry()
        s = Session(data)
        d = s.to_dict()
        assert d == data
        # Ensure it's a copy
        d["session_id"] = "modified"
        assert s.session_id == "ses_abc123"

    def test_repr(self):
        s = Session(_make_session_entry("ses_test", 3))
        assert "ses_test" in repr(s)
        assert "3" in repr(s)


class TestListSessions:

    def test_returns_sessions(self):
        page = {
            "sessions": [_make_session_entry("ses_1"), _make_session_entry("ses_2")],
            "next_cursor": None,
            "has_more": False,
        }
        with patch.object(Client, "_request", return_value=_mock_response(page)):
            client = Client(api_key="ak_live_" + "a" * 32)
            sessions = client.list_sessions()

        assert len(sessions) == 2
        assert isinstance(sessions[0], Session)
        assert sessions[0].session_id == "ses_1"
        assert sessions[1].session_id == "ses_2"

    def test_auto_pagination(self):
        page1 = {
            "sessions": [_make_session_entry("ses_1")],
            "next_cursor": "cursor_abc",
            "has_more": True,
        }
        page2 = {
            "sessions": [_make_session_entry("ses_2")],
            "next_cursor": None,
            "has_more": False,
        }
        responses = [_mock_response(page1), _mock_response(page2)]
        with patch.object(Client, "_request", side_effect=responses):
            client = Client(api_key="ak_live_" + "a" * 32)
            sessions = client.list_sessions()

        assert len(sessions) == 2
        assert sessions[0].session_id == "ses_1"
        assert sessions[1].session_id == "ses_2"

    def test_created_after_filter(self):
        page = {
            "sessions": [_make_session_entry()],
            "next_cursor": None,
            "has_more": False,
        }
        with patch.object(Client, "_request", return_value=_mock_response(page)) as mock_req:
            client = Client(api_key="ak_live_" + "a" * 32)
            client.list_sessions(created_after="2026-03-01")

        call_path = mock_req.call_args[0][1]
        assert "created_after=2026-03-01" in call_path

    def test_created_before_filter(self):
        page = {
            "sessions": [],
            "next_cursor": None,
            "has_more": False,
        }
        with patch.object(Client, "_request", return_value=_mock_response(page)) as mock_req:
            client = Client(api_key="ak_live_" + "a" * 32)
            client.list_sessions(created_before="2026-04-01")

        call_path = mock_req.call_args[0][1]
        assert "created_before=2026-04-01" in call_path

    def test_limit_option(self):
        page = {
            "sessions": [],
            "next_cursor": None,
            "has_more": False,
        }
        with patch.object(Client, "_request", return_value=_mock_response(page)) as mock_req:
            client = Client(api_key="ak_live_" + "a" * 32)
            client.list_sessions(limit=10)

        call_path = mock_req.call_args[0][1]
        assert "limit=10" in call_path

    def test_empty_result(self):
        page = {
            "sessions": [],
            "next_cursor": None,
            "has_more": False,
        }
        with patch.object(Client, "_request", return_value=_mock_response(page)):
            client = Client(api_key="ak_live_" + "a" * 32)
            sessions = client.list_sessions()

        assert sessions == []


class TestModuleImports:

    def test_import_session(self):
        from artifacta import Session as S
        assert S is Session
