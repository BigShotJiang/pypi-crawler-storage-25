"""Tests for `artifacta session ls` CLI command (AF_CLI-7.2)."""

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from artifacta.cli import main


SESSIONS_RESPONSE = {
    "sessions": [
        {
            "session_id": "ses_abc123",
            "artifact_count": 5,
            "is_sealed": False,
            "first_artifact_at": "2026-04-01T10:00:00+00:00",
            "last_artifact_at": "2026-04-02T15:30:00+00:00",
        },
        {
            "session_id": "ses_def456",
            "artifact_count": 12,
            "is_sealed": True,
            "first_artifact_at": "2026-03-28T08:00:00+00:00",
            "last_artifact_at": "2026-04-01T12:00:00+00:00",
        },
    ],
    "next_cursor": None,
    "has_more": False,
}


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def mock_key(monkeypatch):
    monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_" + "a" * 32)
    monkeypatch.setenv("ARTIFACTA_API_URL", "http://localhost:8000")


class TestSessionLsHuman:

    def test_shows_table(self, runner, mock_key):
        with patch("artifacta.cli.api_request", return_value=SESSIONS_RESPONSE):
            result = runner.invoke(main, ["session", "ls", "--human"])

        assert result.exit_code == 0
        assert "SESSION ID" in result.output
        assert "ses_abc123" in result.output
        assert "ses_def456" in result.output
        assert "2 sessions" in result.output

    def test_shows_sealed_status(self, runner, mock_key):
        with patch("artifacta.cli.api_request", return_value=SESSIONS_RESPONSE):
            result = runner.invoke(main, ["session", "ls", "--human"])

        lines = result.output.strip().split("\n")
        # ses_abc123 is not sealed, ses_def456 is sealed
        abc_line = [l for l in lines if "ses_abc123" in l][0]
        def_line = [l for l in lines if "ses_def456" in l][0]
        assert "no" in abc_line
        assert "yes" in def_line

    def test_empty_no_sessions(self, runner, mock_key):
        empty_resp = {"sessions": [], "next_cursor": None, "has_more": False}
        with patch("artifacta.cli.api_request", return_value=empty_resp):
            result = runner.invoke(main, ["session", "ls", "--human"])

        assert "No sessions found" in result.output

    def test_has_more_shows_cursor(self, runner, mock_key):
        resp = {
            "sessions": [SESSIONS_RESPONSE["sessions"][0]],
            "next_cursor": "abc123cursor",
            "has_more": True,
        }
        with patch("artifacta.cli.api_request", return_value=resp):
            result = runner.invoke(main, ["session", "ls", "--human"])

        assert "More results available" in result.output
        assert "abc123cursor" in result.output


class TestSessionLsJson:

    def test_json_output(self, runner, mock_key):
        with patch("artifacta.cli.api_request", return_value=SESSIONS_RESPONSE):
            result = runner.invoke(main, ["session", "ls", "--json"])

        data = json.loads(result.output.strip())
        assert "sessions" in data
        assert len(data["sessions"]) == 2

    def test_auto_json_on_pipe(self, runner, mock_key):
        """Default (non-TTY) should output JSON."""
        with patch("artifacta.cli.api_request", return_value=SESSIONS_RESPONSE):
            result = runner.invoke(main, ["session", "ls"])

        data = json.loads(result.output.strip())
        assert "sessions" in data


class TestSessionLsOptions:

    def test_limit_option(self, runner, mock_key):
        with patch("artifacta.cli.api_request", return_value=SESSIONS_RESPONSE) as mock_req:
            runner.invoke(main, ["session", "ls", "--limit", "10"])

        call_path = mock_req.call_args[0][1]
        assert "limit=10" in call_path

    def test_after_option(self, runner, mock_key):
        with patch("artifacta.cli.api_request", return_value=SESSIONS_RESPONSE) as mock_req:
            runner.invoke(main, ["session", "ls", "--after", "cursor123"])

        call_path = mock_req.call_args[0][1]
        assert "after=cursor123" in call_path

    def test_created_after_option(self, runner, mock_key):
        with patch("artifacta.cli.api_request", return_value=SESSIONS_RESPONSE) as mock_req:
            runner.invoke(main, ["session", "ls", "--created-after", "2026-03-01T00:00:00Z"])

        call_path = mock_req.call_args[0][1]
        assert "created_after=2026-03-01T00:00:00Z" in call_path

    def test_created_before_option(self, runner, mock_key):
        with patch("artifacta.cli.api_request", return_value=SESSIONS_RESPONSE) as mock_req:
            runner.invoke(main, ["session", "ls", "--created-before", "2026-04-01T00:00:00Z"])

        call_path = mock_req.call_args[0][1]
        assert "created_before=2026-04-01T00:00:00Z" in call_path

    def test_no_key_exits_1(self, runner):
        with patch("artifacta.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["session", "ls", "--human"])
        assert result.exit_code == 1
        assert "No API key" in result.output
