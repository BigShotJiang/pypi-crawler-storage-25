"""Tests for CLI push command (AF_CLI-4.2)."""

from __future__ import annotations

import json
import re
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from artifacta.cli import main
from artifacta.client import ArtifactaAPIError, ArtifactaNetworkError

UPLOAD_RESPONSE = {
    "artifact_id": "art_tEsT1234567890Ab",
    "filename": "report.pdf",
    "content_type": "application/pdf",
    "size_bytes": 1024,
    "content_hash": "sha256:abcdef1234567890",
    "session_id": None,
    "agent_id": None,
    "metadata": {},
    "expires_at": "2026-05-02T00:00:00+00:00",
    "created_at": "2026-04-02T00:00:00+00:00",
}


@pytest.fixture
def runner():
    return CliRunner(mix_stderr=False)


@pytest.fixture
def tmp_file(tmp_path):
    """Create a temp file for upload tests."""
    f = tmp_path / "report.pdf"
    f.write_bytes(b"fake pdf content")
    return str(f)


class TestPushBasic:
    def test_push_file_success_human(self, runner, tmp_file):
        """Push a file, human output shows artifact ID on stderr."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--human"])

        assert result.exit_code == 0
        assert "art_tEsT1234567890Ab" in result.stderr
        assert "✓ Uploaded" in result.stderr
        # stdout has artifact ID for scripting
        assert "art_tEsT1234567890Ab" in result.output

    def test_push_file_success_json(self, runner, tmp_file):
        """Push with --json outputs JSON to stdout."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        assert result.exit_code == 0
        body = json.loads(result.output)
        assert body["artifact_id"] == "art_tEsT1234567890Ab"
        assert body["filename"] == "report.pdf"

    def test_push_auto_json_when_piped(self, runner, tmp_file):
        """Auto-JSON: Click CliRunner is not a TTY, so auto-JSON applies."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file])

        assert result.exit_code == 0
        # CliRunner stdout is not a tty → auto-JSON
        body = json.loads(result.output)
        assert body["artifact_id"] == "art_tEsT1234567890Ab"

    def test_push_uses_filename_from_path(self, runner, tmp_file):
        """Push auto-detects filename from file path."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        assert result.exit_code == 0
        form_data = calls[0]["data"]
        assert form_data["filename"] == "report.pdf"


class TestPushStdin:
    def test_push_stdin_with_name(self, runner):
        """Push from stdin with --name."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(
                main, ["push", "-", "--name", "data.json", "--json"],
                input=b'{"key": "value"}',
            )

        assert result.exit_code == 0
        body = json.loads(result.output)
        assert body["artifact_id"] == "art_tEsT1234567890Ab"

    def test_push_stdin_requires_name(self, runner):
        """Push from stdin without --name fails."""
        with patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", "-"], input=b"data")

        assert result.exit_code == 1
        assert "--name is required" in result.stderr


class TestPushFlags:
    def test_push_with_session(self, runner, tmp_file):
        """--session flag passes session_id to API."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--session", "my_session", "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["session_id"] == "my_session"

    def test_push_with_new_session(self, runner, tmp_file):
        """--new-session generates a ses_ prefixed session ID."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--new-session", "--json"])

        assert result.exit_code == 0
        session_id = calls[0]["data"]["session_id"]
        assert session_id.startswith("ses_")
        assert len(session_id) == 16  # ses_ + 12 chars

    def test_push_new_session_in_json_output(self, runner, tmp_file):
        """--new-session includes session_id in JSON output."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--new-session", "--json"])

        assert result.exit_code == 0
        body = json.loads(result.output)
        assert "session_id" in body
        assert body["session_id"].startswith("ses_")

    def test_push_new_session_capturable_via_jq(self, runner, tmp_file):
        """Session ID from --new-session is extractable from JSON output."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--new-session", "--json"])

        body = json.loads(result.output)
        session_id = body["session_id"]
        assert re.match(r"^ses_[a-z0-9]{12}$", session_id)

    def test_push_with_agent(self, runner, tmp_file):
        """--agent flag passes agent_id to API."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--agent", "agent-007", "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["agent_id"] == "agent-007"

    def test_push_with_metadata(self, runner, tmp_file):
        """--meta flag passes metadata as JSON string."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(
                main,
                ["push", tmp_file, "--meta", "model=claude", "--meta", "stage=final", "--json"],
            )

        assert result.exit_code == 0
        metadata = json.loads(calls[0]["data"]["metadata"])
        assert metadata == {"model": "claude", "stage": "final"}

    def test_push_with_ttl(self, runner, tmp_file):
        """--ttl flag passes TTL to API."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--ttl", "7d", "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["ttl"] == "7d"

    def test_push_with_idempotency_key(self, runner, tmp_file):
        """--idempotency-key passes header to API."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(
                main, ["push", tmp_file, "--idempotency-key", "my-key-123", "--json"],
            )

        assert result.exit_code == 0
        assert calls[0]["headers"]["Idempotency-Key"] == "my-key-123"

    def test_push_with_content_type_override(self, runner, tmp_file):
        """--content-type overrides auto-detection."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(
                main,
                ["push", tmp_file, "--content-type", "text/plain", "--json"],
            )

        assert result.exit_code == 0
        # The file tuple should use the overridden content type
        file_tuple = calls[0]["files"]["file"]
        assert file_tuple[2] == "text/plain"

    def test_push_with_name_override(self, runner, tmp_file):
        """--name overrides filename from path."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(
                main, ["push", tmp_file, "--name", "custom.pdf", "--json"],
            )

        assert result.exit_code == 0
        assert calls[0]["data"]["filename"] == "custom.pdf"

    def test_push_presigned_calls_upload_url(self, runner, tmp_file):
        """--presigned flag triggers three-step presigned upload flow."""
        url_resp = {
            "artifact_id": "art_test1234",
            "status": "pending",
            "upload_url": "https://r2.test/put",
            "upload_expires_at": "2026-04-03T12:00:00Z",
            "upload_method": "PUT",
            "upload_headers": {},
        }
        complete_resp = {
            "artifact_id": "art_test1234",
            "filename": "test.txt",
            "content_type": "text/plain",
            "size_bytes": 5,
            "content_hash": "sha256:abc",
            "session_id": None,
            "agent_id": None,
            "metadata": {},
            "expires_at": "2026-05-03T00:00:00Z",
            "created_at": "2026-04-03T00:00:00Z",
        }

        def mock_api(method, path, **kwargs):
            if "upload-url" in path:
                return url_resp
            if "complete" in path:
                return complete_resp
            raise AssertionError(f"Unexpected: {method} {path}")

        with patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32), \
             patch("artifacta.cli.api_request", side_effect=mock_api), \
             patch("artifacta.cli.upload_bytes_to_presigned"):
            result = runner.invoke(main, ["push", tmp_file, "--presigned"])

        assert result.exit_code == 0


class TestPushEnvVars:
    def test_push_session_from_env(self, runner, tmp_file, monkeypatch):
        """ARTIFACTA_SESSION_ID env var sets default session."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        monkeypatch.setenv("ARTIFACTA_SESSION_ID", "env_session_42")
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["session_id"] == "env_session_42"

    def test_push_session_flag_overrides_env(self, runner, tmp_file, monkeypatch):
        """Explicit --session overrides ARTIFACTA_SESSION_ID."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        monkeypatch.setenv("ARTIFACTA_SESSION_ID", "env_session")
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--session", "flag_session", "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["session_id"] == "flag_session"

    def test_push_agent_from_env(self, runner, tmp_file, monkeypatch):
        """ARTIFACTA_AGENT_ID env var sets default agent."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        monkeypatch.setenv("ARTIFACTA_AGENT_ID", "env_agent_1")
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["agent_id"] == "env_agent_1"

    def test_push_agent_flag_overrides_env(self, runner, tmp_file, monkeypatch):
        """Explicit --agent overrides ARTIFACTA_AGENT_ID."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        monkeypatch.setenv("ARTIFACTA_AGENT_ID", "env_agent")
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--agent", "flag_agent", "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["agent_id"] == "flag_agent"

    def test_push_ttl_from_env(self, runner, tmp_file, monkeypatch):
        """ARTIFACTA_TTL env var sets default TTL."""
        calls = []

        def mock_request(method, path, **kwargs):
            calls.append(kwargs)
            return UPLOAD_RESPONSE

        monkeypatch.setenv("ARTIFACTA_TTL", "7d")
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        assert result.exit_code == 0
        assert calls[0]["data"]["ttl"] == "7d"


class TestPushErrors:
    def test_push_no_api_key(self, runner, tmp_file):
        """Push without API key returns exit code 1."""
        with patch("artifacta.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["push", tmp_file])

        assert result.exit_code == 1
        assert "No API key" in result.stderr

    def test_push_sealed_session(self, runner, tmp_file):
        """Sealed session returns specific error message."""
        err = ArtifactaAPIError("session_sealed", "Session sealed", 409)
        with patch("artifacta.cli.api_request", side_effect=err), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(
                main, ["push", tmp_file, "--session", "sealed_session"],
            )

        assert result.exit_code == 1
        assert "sealed" in result.stderr

    def test_push_file_too_large(self, runner, tmp_file):
        """File too large returns specific error message."""
        err = ArtifactaAPIError(
            "file_too_large",
            "File exceeds 500 MB limit. Upgrade to Pro for presigned uploads up to 5 GB.",
            413,
        )
        with patch("artifacta.cli.api_request", side_effect=err), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file])

        assert result.exit_code == 1
        assert "500 MB" in result.stderr

    def test_push_network_error(self, runner, tmp_file):
        """Network error returns exit code 3."""
        with patch("artifacta.cli.api_request", side_effect=ArtifactaNetworkError("timeout")), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file])

        assert result.exit_code == 3
        assert "Network error" in result.stderr

    def test_push_server_error(self, runner, tmp_file):
        """Server error returns exit code 2."""
        err = ArtifactaAPIError("unknown", "Internal server error", 500)
        with patch("artifacta.cli.api_request", side_effect=err), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file])

        assert result.exit_code == 2

    def test_push_file_not_found(self, runner):
        """Push non-existent file returns exit code 1."""
        with patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", "/nonexistent/file.pdf"])

        assert result.exit_code == 1
        assert "File not found" in result.stderr

    def test_push_invalid_metadata_format(self, runner, tmp_file):
        """Invalid metadata (no =) returns exit code 1."""
        with patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--meta", "bad_format"])

        assert result.exit_code == 1
        assert "Invalid metadata" in result.stderr


class TestPushIdempotency:
    def test_idempotency_replay_returns_same_id(self, runner, tmp_file):
        """Idempotency replay returns same artifact_id, exit code 0."""
        # Both calls return the same response (simulating replay)
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(
                main,
                ["push", tmp_file, "--idempotency-key", "replay-key", "--json"],
            )

        assert result.exit_code == 0
        body = json.loads(result.output)
        assert body["artifact_id"] == "art_tEsT1234567890Ab"


class TestPushOutputFormat:
    def test_push_human_output_has_size(self, runner, tmp_file):
        """Human output shows size in readable format."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--human"])

        assert result.exit_code == 0
        assert "Size:" in result.stderr
        assert "1.0 KB" in result.stderr

    def test_push_human_output_has_hash(self, runner, tmp_file):
        """Human output shows content hash."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--human"])

        assert result.exit_code == 0
        assert "Hash:" in result.stderr
        assert "sha256:" in result.stderr

    def test_push_human_output_has_expiry(self, runner, tmp_file):
        """Human output shows expiry date."""
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--human"])

        assert result.exit_code == 0
        assert "Expires:" in result.stderr

    def test_push_artifacta_output_json_env(self, runner, tmp_file, monkeypatch):
        """ARTIFACTA_OUTPUT=json forces JSON output."""
        monkeypatch.setenv("ARTIFACTA_OUTPUT", "json")
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file])

        assert result.exit_code == 0
        body = json.loads(result.output)
        assert body["artifact_id"] == "art_tEsT1234567890Ab"

    def test_push_human_flag_overrides_output_env(self, runner, tmp_file, monkeypatch):
        """--human overrides ARTIFACTA_OUTPUT=json."""
        monkeypatch.setenv("ARTIFACTA_OUTPUT", "json")
        with patch("artifacta.cli.api_request", return_value=UPLOAD_RESPONSE), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--human"])

        assert result.exit_code == 0
        assert "✓ Uploaded" in result.stderr


LINK_RESPONSE = {
    "link_id": "lnk_tEsT12345678901234",
    "url": "https://dl.artifacta.io/lnk_tEsT12345678901234",
    "artifact_id": "art_tEsT1234567890Ab",
    "expires_at": "2026-04-09T00:00:00+00:00",
    "created_at": "2026-04-02T00:00:00+00:00",
}


class TestPushLink:
    """Tests for push --link flag (AF_CLI-8.5)."""

    def test_push_link_json(self, runner, tmp_file):
        """--link in JSON mode includes link key with link_id, url, expires_at."""
        def mock_api_request(method, path, **kwargs):
            if method == "POST" and "/links" in path:
                return dict(LINK_RESPONSE)
            return dict(UPLOAD_RESPONSE)

        with patch("artifacta.cli.api_request", side_effect=mock_api_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--link", "--json"])

        assert result.exit_code == 0
        body = json.loads(result.output)
        assert "link" in body
        assert body["link"]["link_id"] == "lnk_tEsT12345678901234"
        assert body["link"]["url"] == "https://dl.artifacta.io/lnk_tEsT12345678901234"
        assert body["link"]["expires_at"] == "2026-04-09T00:00:00+00:00"

    def test_push_link_human(self, runner, tmp_file):
        """--link in human mode prints the download URL to stdout."""
        def mock_api_request(method, path, **kwargs):
            if method == "POST" and "/links" in path:
                return dict(LINK_RESPONSE)
            return dict(UPLOAD_RESPONSE)

        with patch("artifacta.cli.api_request", side_effect=mock_api_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--link", "--human"])

        assert result.exit_code == 0
        assert "✓ Uploaded" in result.stderr
        assert "https://dl.artifacta.io/lnk_tEsT12345678901234" in result.output

    def test_push_no_link(self, runner, tmp_file):
        """Without --link, no link is created and no link in output."""
        with patch("artifacta.cli.api_request", return_value=dict(UPLOAD_RESPONSE)) as mock_req, \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])

        assert result.exit_code == 0
        body = json.loads(result.output)
        assert "link" not in body
        # Only one API call (upload), no link call
        assert mock_req.call_count == 1

    def test_push_link_failure_graceful(self, runner, tmp_file):
        """If link creation fails, upload still succeeds with a warning."""
        call_count = 0
        def mock_api_request(method, path, **kwargs):
            nonlocal call_count
            call_count += 1
            if method == "POST" and "/links" in path:
                raise ArtifactaAPIError("rate_limited", "Too many requests", 429)
            return dict(UPLOAD_RESPONSE)

        with patch("artifacta.cli.api_request", side_effect=mock_api_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--link", "--human"])

        assert result.exit_code == 0
        assert "✓ Uploaded" in result.stderr
        assert "Link creation failed" in result.stderr
        assert "artifacta link art_tEsT1234567890Ab" in result.stderr


# --- CLI-PRE-05: auto-generated Idempotency-Key on `push` ---


import hashlib  # noqa: E402 — co-located with the tests that need it.

from artifacta.cli import _auto_idempotency_key  # noqa: E402


class TestPushAutoIdempotencyKey:
    """When --idempotency-key is omitted, push derives a stable key from
    (file_hash | filename | session | agent) so an agent retry of the
    same upload returns the same artifact_id within the API's 24h dedup
    window. User-supplied --idempotency-key always wins. Presigned path
    is unaffected."""

    @staticmethod
    def _capturing_mock():
        calls: list[dict] = []

        def mock_request(method, path, **kwargs):
            calls.append({"method": method, "path": path, **kwargs})
            return UPLOAD_RESPONSE

        return calls, mock_request

    @staticmethod
    def _expected_key(file_data: bytes, filename: str,
                      session_id: str | None, agent_id: str | None) -> str:
        """Mirror the production formula exactly (CLI-PRE-05 spec)."""
        h = hashlib.sha256(file_data).hexdigest()
        identity = f"{h}|{filename}|{session_id or ''}|{agent_id or ''}"
        return hashlib.sha256(identity.encode()).hexdigest()[:32]

    def test_helper_matches_spec_formula(self):
        """Direct unit on the helper — every other test relies on this
        formula being correct, so make the failure point obvious."""
        got = _auto_idempotency_key(b"hello", "report.pdf", None, None)
        want = self._expected_key(b"hello", "report.pdf", None, None)
        assert got == want
        assert len(got) == 32

    def test_auto_key_present_on_direct_upload(self, runner, tmp_file):
        """AC-05.7: every direct upload carries an Idempotency-Key, even
        when the user did not pass --idempotency-key."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])
        assert result.exit_code == 0
        sent = calls[0]["headers"]["Idempotency-Key"]
        # The fixture writes b"fake pdf content" with filename report.pdf.
        assert sent == self._expected_key(b"fake pdf content", "report.pdf", None, None)

    def test_auto_key_is_at_most_64_chars(self, runner, tmp_file):
        """AC-05.5: API server validation caps the header at 64 chars."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            result = runner.invoke(main, ["push", tmp_file, "--json"])
        assert result.exit_code == 0
        assert len(calls[0]["headers"]["Idempotency-Key"]) <= 64

    def test_auto_key_deterministic_across_invocations(self, runner, tmp_file):
        """AC-05.4: same file + args => same key. No timestamp, no randomness."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            r1 = runner.invoke(main, ["push", tmp_file, "--json"])
            r2 = runner.invoke(main, ["push", tmp_file, "--json"])
        assert r1.exit_code == 0 and r2.exit_code == 0
        k1 = calls[0]["headers"]["Idempotency-Key"]
        k2 = calls[1]["headers"]["Idempotency-Key"]
        assert k1 == k2

    def test_session_changes_auto_key(self, runner, tmp_file):
        """AC-05.2: changing --session changes the key (different identity)."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            runner.invoke(main, ["push", tmp_file, "--session", "ses_aaa", "--json"])
            runner.invoke(main, ["push", tmp_file, "--session", "ses_bbb", "--json"])
        assert calls[0]["headers"]["Idempotency-Key"] != calls[1]["headers"]["Idempotency-Key"]

    def test_agent_changes_auto_key(self, runner, tmp_file):
        """Agent id is part of identity — different agents must dedupe separately."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            runner.invoke(main, ["push", tmp_file, "--agent", "agent-A", "--json"])
            runner.invoke(main, ["push", tmp_file, "--agent", "agent-B", "--json"])
        assert calls[0]["headers"]["Idempotency-Key"] != calls[1]["headers"]["Idempotency-Key"]

    def test_filename_changes_auto_key(self, runner, tmp_file):
        """Filename is part of identity — same bytes, different name => different key."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            runner.invoke(main, ["push", tmp_file, "--name", "a.pdf", "--json"])
            runner.invoke(main, ["push", tmp_file, "--name", "b.pdf", "--json"])
        assert calls[0]["headers"]["Idempotency-Key"] != calls[1]["headers"]["Idempotency-Key"]

    def test_user_idempotency_key_wins(self, runner, tmp_file):
        """AC-05.3: user --idempotency-key is forwarded as-is, not the auto-key."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            runner.invoke(main, ["push", tmp_file, "--idempotency-key", "user-supplied-001", "--json"])
        assert calls[0]["headers"]["Idempotency-Key"] == "user-supplied-001"

    def test_stdin_push_uses_content_hash(self, runner):
        """AC-05.6: stdin retries with same content also dedupe."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            r1 = runner.invoke(main, ["push", "-", "--name", "out.json", "--json"],
                               input="hello-stdin")
            r2 = runner.invoke(main, ["push", "-", "--name", "out.json", "--json"],
                               input="hello-stdin")
        assert r1.exit_code == 0 and r2.exit_code == 0
        assert calls[0]["headers"]["Idempotency-Key"] == calls[1]["headers"]["Idempotency-Key"]
        # And the value is the formula applied to the stdin bytes.
        assert calls[0]["headers"]["Idempotency-Key"] == self._expected_key(
            b"hello-stdin", "out.json", None, None,
        )

    def test_stdin_different_content_changes_key(self, runner):
        """Different stdin bytes must produce different auto-keys."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            runner.invoke(main, ["push", "-", "--name", "out.json", "--json"],
                          input="content-A")
            runner.invoke(main, ["push", "-", "--name", "out.json", "--json"],
                          input="content-B")
        assert calls[0]["headers"]["Idempotency-Key"] != calls[1]["headers"]["Idempotency-Key"]

    def test_session_env_var_participates_in_auto_key(self, runner, tmp_file, monkeypatch):
        """ARTIFACTA_SESSION_ID and --session must produce the same auto-key
        for the same value (so an env-var setup and a flag-based setup
        dedupe against each other)."""
        calls, mock_request = self._capturing_mock()
        with patch("artifacta.cli.api_request", side_effect=mock_request), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32):
            monkeypatch.setenv("ARTIFACTA_SESSION_ID", "ses_envtest")
            runner.invoke(main, ["push", tmp_file, "--json"])
            monkeypatch.delenv("ARTIFACTA_SESSION_ID")
            runner.invoke(main, ["push", tmp_file, "--session", "ses_envtest", "--json"])
        assert calls[0]["headers"]["Idempotency-Key"] == calls[1]["headers"]["Idempotency-Key"]

    def test_presigned_path_does_not_inject_auto_key(self, runner, tmp_file):
        """AC-05.8: presigned uploads dedupe at `complete` time server-side
        and must NOT carry an Idempotency-Key. The API server's presigned
        endpoint doesn't accept one."""
        url_resp = {
            "artifact_id": "art_test1234",
            "status": "pending",
            "upload_url": "https://r2.test/put",
            "upload_expires_at": "2026-04-03T12:00:00Z",
            "upload_method": "PUT",
            "upload_headers": {},
        }
        complete_resp = dict(UPLOAD_RESPONSE)
        captured: list[dict] = []

        def mock_api(method, path, **kwargs):
            captured.append({"method": method, "path": path,
                             "headers": kwargs.get("headers")})
            if "upload-url" in path:
                return url_resp
            return complete_resp

        with patch("artifacta.cli.api_request", side_effect=mock_api), \
             patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32), \
             patch("artifacta.cli.upload_bytes_to_presigned"):
            result = runner.invoke(main, ["push", tmp_file, "--presigned", "--json"])

        assert result.exit_code == 0
        for call in captured:
            headers = call["headers"] or {}
            assert "Idempotency-Key" not in headers, (
                f"Idempotency-Key leaked into presigned call to {call['path']}"
            )
