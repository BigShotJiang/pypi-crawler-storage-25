"""Tests for AF_CLI-5.3 — SDK Extended Methods (list, get, delete, create_link, seal_session, whoami)."""

from __future__ import annotations

from typing import Any

import httpx
import pytest
import respx

MOCK_API = "https://mock.api.dev"
MOCK_KEY = "ak_live_test1234567890abcdef12345678"

MOCK_ARTIFACT: dict[str, Any] = {
    "artifact_id": "art_abc1234567890x",
    "filename": "report.pdf",
    "content_type": "application/pdf",
    "size_bytes": 1024,
    "content_hash": "sha256:abcdef1234567890",
    "session_id": "ses_test12345678",
    "agent_id": "test_agent",
    "metadata": {"model": "claude-sonnet"},
    "expires_at": "2026-05-01T00:00:00Z",
    "created_at": "2026-04-02T12:00:00Z",
}

MOCK_WHOAMI: dict[str, Any] = {
    "tenant_name": "acme",
    "plan": "pro",
    "api_key_last_4": "5678",
    "usage_requests_month": 42,
    "plan_requests_limit_month": 10000,
    "usage_storage_bytes": 1048576,
    "plan_storage_limit_bytes": 10737418240,
}

MOCK_LINK: dict[str, Any] = {
    "link_id": "lnk_abc12345678901234xx",
    "url": "https://dl.artifacta.io/lnk_abc12345678901234xx",
    "artifact_id": "art_abc1234567890x",
    "expires_at": "2026-04-03T12:00:00Z",
    "created_at": "2026-04-02T12:00:00Z",
}

MOCK_SEAL: dict[str, Any] = {
    "session_id": "ses_test12345678",
    "status": "sealed",
    "sealed_at": "2026-04-02T12:30:00Z",
    "artifact_count": 5,
}


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch, tmp_path: object) -> None:
    monkeypatch.setenv("ARTIFACTA_API_KEY", MOCK_KEY)
    monkeypatch.delenv("ARTIFACTA_API_URL", raising=False)
    monkeypatch.delenv("ARTIFACTA_SESSION_ID", raising=False)
    monkeypatch.delenv("ARTIFACTA_AGENT_ID", raising=False)
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))


def _make_client():
    from artifacta.sdk import Client
    return Client(base_url=MOCK_API)


class TestList:
    """Test client.list()."""

    @respx.mock
    def test_list_returns_artifacts(self) -> None:
        respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(200, json={
                "artifacts": [MOCK_ARTIFACT, MOCK_ARTIFACT],
                "next_cursor": None,
                "has_more": False,
            })
        )

        client = _make_client()
        results = client.list()
        assert len(results) == 2
        assert results[0].id == "art_abc1234567890x"

    @respx.mock
    def test_list_with_session_filter(self) -> None:
        route = respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(200, json={
                "artifacts": [MOCK_ARTIFACT],
                "next_cursor": None,
                "has_more": False,
            })
        )

        client = _make_client()
        client.list(session_id="ses_test12345678")

        req = route.calls[0].request
        assert "session_id=ses_test12345678" in str(req.url)

    @respx.mock
    def test_list_with_metadata_filter(self) -> None:
        route = respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(200, json={
                "artifacts": [],
                "next_cursor": None,
                "has_more": False,
            })
        )

        client = _make_client()
        client.list(metadata={"model": "claude-sonnet"})

        req = route.calls[0].request
        url_str = str(req.url)
        assert "metadata.model=claude-sonnet" in url_str

    @respx.mock
    def test_list_multiple_metadata_keys_sent_to_server(self) -> None:
        """Multi-key metadata sends all params to server (AF_CLI-9.1)."""
        route = respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(200, json={
                "artifacts": [],
                "next_cursor": None,
                "has_more": False,
            })
        )

        client = _make_client()
        client.list(metadata={"k1": "v1", "k2": "v2"})

        req = route.calls[0].request
        url_str = str(req.url)
        assert "metadata.k1=v1" in url_str
        assert "metadata.k2=v2" in url_str

    @respx.mock
    def test_list_multi_metadata_free_tier_raises_quota_exceeded(self) -> None:
        """Multi-key metadata on Free tier raises QuotaExceededError (AF_CLI-9.1)."""
        from artifacta.errors import QuotaExceededError

        respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(403, json={
                "error": {
                    "code": "quota_exceeded",
                    "message": "Multiple metadata filters require a Pro plan. "
                               "Filter by one metadata key on Free, or upgrade at "
                               "https://app.artifacta.io/billing",
                    "status": 403,
                },
            })
        )

        client = _make_client()
        with pytest.raises(QuotaExceededError):
            client.list(metadata={"k1": "v1", "k2": "v2"})

    @respx.mock
    def test_list_auto_pagination(self) -> None:
        page1 = httpx.Response(200, json={
            "artifacts": [MOCK_ARTIFACT],
            "next_cursor": "cursor_abc123",
            "has_more": True,
        })
        art2 = dict(MOCK_ARTIFACT, artifact_id="art_xyz9876543210x")
        page2 = httpx.Response(200, json={
            "artifacts": [art2],
            "next_cursor": None,
            "has_more": False,
        })

        route = respx.get(f"{MOCK_API}/v1/artifacts").mock(side_effect=[page1, page2])

        client = _make_client()
        results = client.list()
        assert len(results) == 2
        assert results[0].id == "art_abc1234567890x"
        assert results[1].id == "art_xyz9876543210x"
        assert route.call_count == 2

    @respx.mock
    def test_list_env_session_default(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ARTIFACTA_SESSION_ID", "ses_env_default1")

        route = respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(200, json={
                "artifacts": [],
                "next_cursor": None,
                "has_more": False,
            })
        )

        client = _make_client()
        client.list()

        req = route.calls[0].request
        assert "session_id=ses_env_default1" in str(req.url)


    @respx.mock
    def test_list_auto_paginate_returns_listresult(self) -> None:
        """Auto-paginate returns ListResult with has_more=False (AF_CLI-8.4)."""
        page1 = httpx.Response(200, json={
            "artifacts": [MOCK_ARTIFACT],
            "next_cursor": "cur_1",
            "has_more": True,
        })
        art2 = dict(MOCK_ARTIFACT, artifact_id="art_page2item00000x")
        page2 = httpx.Response(200, json={
            "artifacts": [art2],
            "next_cursor": None,
            "has_more": False,
        })
        respx.get(f"{MOCK_API}/v1/artifacts").mock(side_effect=[page1, page2])

        client = _make_client()
        result = client.list()

        from artifacta.sdk import ListResult
        assert isinstance(result, ListResult)
        assert len(result) == 2
        assert result.has_more is False
        assert result.next_cursor is None

    @respx.mock
    def test_list_manual_pagination(self) -> None:
        """auto_paginate=False returns one page with has_more and next_cursor (AF_CLI-8.4)."""
        respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(200, json={
                "artifacts": [MOCK_ARTIFACT],
                "next_cursor": "cursor_page2",
                "has_more": True,
            })
        )

        client = _make_client()
        result = client.list(auto_paginate=False)

        assert len(result) == 1
        assert result.has_more is True
        assert result.next_cursor == "cursor_page2"

    @respx.mock
    def test_list_iteration_backward_compat(self) -> None:
        """ListResult supports for-in iteration (AF_CLI-8.4)."""
        respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(200, json={
                "artifacts": [MOCK_ARTIFACT],
                "next_cursor": None,
                "has_more": False,
            })
        )

        client = _make_client()
        result = client.list()
        collected = [art for art in result]
        assert len(collected) == 1
        assert collected[0].id == "art_abc1234567890x"

    @respx.mock
    def test_list_indexing_backward_compat(self) -> None:
        """ListResult supports result[0] indexing (AF_CLI-8.4)."""
        respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(200, json={
                "artifacts": [MOCK_ARTIFACT],
                "next_cursor": None,
                "has_more": False,
            })
        )

        client = _make_client()
        result = client.list()
        assert result[0].id == "art_abc1234567890x"

    @respx.mock
    def test_list_manual_cursor_param(self) -> None:
        """cursor param is passed to the API request (AF_CLI-8.4)."""
        route = respx.get(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(200, json={
                "artifacts": [],
                "next_cursor": None,
                "has_more": False,
            })
        )

        client = _make_client()
        client.list(auto_paginate=False, cursor="cursor_page2")

        req = route.calls[0].request
        assert "cursor=cursor_page2" in str(req.url)


class TestGet:
    """Test client.get()."""

    @respx.mock
    def test_get_returns_artifact(self) -> None:
        respx.get(f"{MOCK_API}/v1/artifacts/art_abc1234567890x").mock(
            return_value=httpx.Response(200, json=MOCK_ARTIFACT)
        )

        client = _make_client()
        artifact = client.get("art_abc1234567890x")
        assert artifact.id == "art_abc1234567890x"
        assert artifact.filename == "report.pdf"

    @respx.mock
    def test_get_404_raises(self) -> None:
        from artifacta.errors import ArtifactNotFoundError

        respx.get(f"{MOCK_API}/v1/artifacts/art_missing123456xx").mock(
            return_value=httpx.Response(
                404, json={"error": {"code": "artifact_not_found", "message": "Not found"}}
            )
        )

        client = _make_client()
        with pytest.raises(ArtifactNotFoundError):
            client.get("art_missing123456xx")

    @respx.mock
    def test_get_410_raises(self) -> None:
        from artifacta.errors import ArtifactExpiredError

        respx.get(f"{MOCK_API}/v1/artifacts/art_expired12345678").mock(
            return_value=httpx.Response(
                410, json={"error": {"code": "artifact_expired", "message": "Expired"}}
            )
        )

        client = _make_client()
        with pytest.raises(ArtifactExpiredError):
            client.get("art_expired12345678")


class TestDelete:
    """Test client.delete()."""

    @respx.mock
    def test_delete_returns_confirmation(self) -> None:
        respx.delete(f"{MOCK_API}/v1/artifacts/art_abc1234567890x").mock(
            return_value=httpx.Response(200, json={
                "artifact_id": "art_abc1234567890x",
                "deleted": True,
                "deleted_at": "2026-04-02T13:00:00Z",
            })
        )

        client = _make_client()
        result = client.delete("art_abc1234567890x")
        assert result["deleted"] is True

    @respx.mock
    def test_delete_already_deleted_no_error(self) -> None:
        respx.delete(f"{MOCK_API}/v1/artifacts/art_deleted12345678").mock(
            return_value=httpx.Response(
                410, json={"error": {"code": "artifact_already_deleted", "message": "Already deleted"}}
            )
        )

        client = _make_client()
        result = client.delete("art_deleted12345678")
        assert result["deleted"] is True


class TestCreateLink:
    """Test client.create_link()."""

    @respx.mock
    def test_create_link_returns_link(self) -> None:
        respx.post(f"{MOCK_API}/v1/artifacts/art_abc1234567890x/links").mock(
            return_value=httpx.Response(201, json=MOCK_LINK)
        )

        client = _make_client()
        link = client.create_link("art_abc1234567890x")
        assert link.url == "https://dl.artifacta.io/lnk_abc12345678901234xx"
        assert link.expires_at == "2026-04-03T12:00:00Z"
        assert link.link_id == "lnk_abc12345678901234xx"

    @respx.mock
    def test_create_link_with_expires_in(self) -> None:
        route = respx.post(f"{MOCK_API}/v1/artifacts/art_abc1234567890x/links").mock(
            return_value=httpx.Response(201, json=MOCK_LINK)
        )

        client = _make_client()
        client.create_link("art_abc1234567890x", expires_in=86400)

        req = route.calls[0].request
        import json
        body = json.loads(req.content)
        assert body["expires_in"] == 86400

    @respx.mock
    def test_create_link_no_body_when_no_expires(self) -> None:
        route = respx.post(f"{MOCK_API}/v1/artifacts/art_abc1234567890x/links").mock(
            return_value=httpx.Response(201, json=MOCK_LINK)
        )

        client = _make_client()
        client.create_link("art_abc1234567890x")

        req = route.calls[0].request
        # No json body or null body
        assert req.content in (b"", b"null")


class TestSealSession:
    """Test client.seal_session()."""

    @respx.mock
    def test_seal_returns_seal_info(self) -> None:
        respx.post(f"{MOCK_API}/v1/sessions/ses_test12345678/seal").mock(
            return_value=httpx.Response(200, json=MOCK_SEAL)
        )

        client = _make_client()
        seal = client.seal_session("ses_test12345678")
        assert seal.session_id == "ses_test12345678"
        assert seal.artifact_count == 5
        assert seal.status == "sealed"
        assert seal.sealed_at == "2026-04-02T12:30:00Z"

    @respx.mock
    def test_seal_idempotent(self) -> None:
        """Sealing an already-sealed session returns success."""
        respx.post(f"{MOCK_API}/v1/sessions/ses_test12345678/seal").mock(
            return_value=httpx.Response(200, json=MOCK_SEAL)
        )

        client = _make_client()
        seal1 = client.seal_session("ses_test12345678")
        seal2 = client.seal_session("ses_test12345678")
        assert seal1.session_id == seal2.session_id


class TestWhoami:
    """Test client.whoami()."""

    @respx.mock
    def test_whoami_returns_tenant_info(self) -> None:
        respx.get(f"{MOCK_API}/v1/whoami").mock(
            return_value=httpx.Response(200, json=MOCK_WHOAMI)
        )

        client = _make_client()
        info = client.whoami()
        assert info.tenant_name == "acme"
        assert info.plan == "pro"
        assert info.api_key_last_4 == "5678"
        assert info.usage_requests_month == 42
        assert info.plan_requests_limit_month == 10000
        assert info.usage_storage_bytes == 1048576
        assert info.plan_storage_limit_bytes == 10737418240

    @respx.mock
    def test_whoami_unauthorized_raises(self) -> None:
        from artifacta.errors import AuthenticationError

        respx.get(f"{MOCK_API}/v1/whoami").mock(
            return_value=httpx.Response(
                401, json={"error": {"code": "unauthorized", "message": "Invalid API key"}}
            )
        )

        client = _make_client()
        with pytest.raises(AuthenticationError):
            client.whoami()


class TestResponseObjects:
    """Test Link, SealInfo, TenantInfo response objects."""

    def test_link_to_dict(self) -> None:
        from artifacta.sdk import Link

        link = Link(MOCK_LINK)
        d = link.to_dict()
        assert d == MOCK_LINK

    def test_link_repr(self) -> None:
        from artifacta.sdk import Link

        link = Link(MOCK_LINK)
        assert "lnk_" in repr(link)

    def test_seal_info_to_dict(self) -> None:
        from artifacta.sdk import SealInfo

        seal = SealInfo(MOCK_SEAL)
        d = seal.to_dict()
        assert d == MOCK_SEAL

    def test_tenant_info_to_dict(self) -> None:
        from artifacta.sdk import TenantInfo

        info = TenantInfo(MOCK_WHOAMI)
        d = info.to_dict()
        assert d == MOCK_WHOAMI

    def test_tenant_info_repr(self) -> None:
        from artifacta.sdk import TenantInfo

        info = TenantInfo(MOCK_WHOAMI)
        r = repr(info)
        assert "acme" in r
        assert "pro" in r


class TestModuleLevelImports:
    """Verify new response objects importable from package root."""

    def test_import_link(self) -> None:
        from artifacta import Link
        assert Link is not None

    def test_import_seal_info(self) -> None:
        from artifacta import SealInfo
        assert SealInfo is not None

    def test_import_tenant_info(self) -> None:
        from artifacta import TenantInfo
        assert TenantInfo is not None
