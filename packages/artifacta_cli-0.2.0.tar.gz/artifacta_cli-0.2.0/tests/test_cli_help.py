"""Tests for `--help` epilog content (CLI-PRE-01).

These are a CI gate against three regressions:
- a new command shipping without an Examples block,
- the root reference content (Common workflow / Environment variables /
  Exit codes) drifting from the spec,
- the verbatim destructive-action warnings on `rm` and `session seal`
  being changed (those strings are part of the user-facing contract).
"""

from __future__ import annotations

import pytest
from click.testing import CliRunner

from artifacta.cli import main

# 13 commands the spec requires to carry an Examples block.
LEAF_COMMANDS = [
    ["push"],
    ["pull"],
    ["ls"],
    ["inspect"],
    ["rm"],
    ["link"],
    ["whoami"],
    ["session", "new"],
    ["session", "ls"],
    ["session", "seal"],
    ["auth", "login"],
    ["config", "set"],
    ["config", "get"],
]

# 4 groups (root + 3 subgroups) — root is required to carry the reference
# blocks; subgroups carry their behavioural callouts per spec Part C.
GROUPS = [
    [],  # root
    ["auth"],
    ["config"],
    ["session"],
]


def _help(argv: list[str]) -> str:
    runner = CliRunner()
    result = runner.invoke(main, argv + ["--help"])
    assert result.exit_code == 0, f"--help failed for {argv!r}: {result.output}"
    return result.output


# ---- Examples blocks on every command ----


@pytest.mark.parametrize("argv", LEAF_COMMANDS, ids=lambda a: " ".join(a) or "root")
def test_command_has_examples_block(argv):
    out = _help(argv)
    assert "\nExamples:\n" in out, f"`artifacta {' '.join(argv)} --help` is missing Examples block"


@pytest.mark.parametrize("argv", LEAF_COMMANDS, ids=lambda a: " ".join(a) or "root")
def test_command_has_three_examples(argv):
    """AC-01.A.2: every Examples block carries >=3 invocation lines (happy
    path, agent use case, pipe/stdin where applicable). Counts any line in
    the block that mentions `artifacta `, which catches the canonical form
    AND piped variants like `cat foo | artifacta push -`."""
    out = _help(argv)
    after_examples = out.split("\nExamples:\n", 1)[1]
    example_lines = [
        ln for ln in after_examples.splitlines() if "artifacta " in ln
    ]
    assert len(example_lines) >= 3, (
        f"`artifacta {' '.join(argv)} --help` has {len(example_lines)} example(s); "
        f"need >=3"
    )


# ---- Root-help reference content (Common workflow / Env vars / Exit codes) ----


def test_root_has_examples_block():
    out = _help([])
    assert "\nExamples:\n" in out


def test_root_has_common_workflow_block():
    out = _help([])
    assert "\nCommon workflow:\n" in out


def test_root_has_environment_variables_block():
    out = _help([])
    assert "\nEnvironment variables:\n" in out


def test_root_has_exit_codes_block():
    out = _help([])
    assert "\nExit codes:\n" in out


@pytest.mark.parametrize(
    "var",
    [
        "ARTIFACTA_API_KEY",
        "ARTIFACTA_API_URL",
        "ARTIFACTA_SESSION_ID",
        "ARTIFACTA_AGENT_ID",
        "ARTIFACTA_TTL",
        "ARTIFACTA_OUTPUT",
        "ARTIFACTA_TELEMETRY",
    ],
)
def test_root_lists_env_var(var):
    out = _help([])
    env_block = out.split("\nEnvironment variables:\n", 1)[1].split("\n\n", 1)[0]
    assert var in env_block, f"{var} is not listed under Environment variables"


def test_root_exit_codes_block_has_four_codes():
    out = _help([])
    block = out.split("\nExit codes:\n", 1)[1].split("\n\n", 1)[0]
    code_lines = [
        ln for ln in block.splitlines()
        if ln.strip() and ln.lstrip()[0:1] in {"0", "1", "2", "3"}
    ]
    assert len(code_lines) == 4, f"Expected 4 exit-code lines, got {len(code_lines)}: {block!r}"


def test_root_blocks_appear_before_examples():
    out = _help([])
    cw = out.find("\nCommon workflow:\n")
    ev = out.find("\nEnvironment variables:\n")
    ec = out.find("\nExit codes:\n")
    ex = out.find("\nExamples:\n")
    assert 0 < cw < ex, "Common workflow must precede Examples"
    assert 0 < ev < ex, "Environment variables must precede Examples"
    assert 0 < ec < ex, "Exit codes must precede Examples"


# ---- Verbatim destructive-action warnings (contract — wording is non-negotiable) ----


def test_rm_help_carries_verbatim_destructive_warning():
    out = _help(["rm"])
    assert (
        "Warning: `--session` deletes every artifact in that session. "
        "Use `--dry-run` to preview." in out
    )


def test_session_seal_help_carries_verbatim_irreversibility_warning():
    out = _help(["session", "seal"])
    assert (
        "Warning: Sealing is irreversible. Sealed sessions cannot accept new artifacts."
        in out
    )


# ---- Behavioural callouts on commands the spec lists ----


def test_push_help_mentions_stdin_name_requirement():
    out = _help(["push"])
    low = out.lower()
    assert "stdin" in low and "--name" in out and "required" in low


def test_push_help_mentions_presigned_for_large_files():
    assert "presigned" in _help(["push"]).lower()


def test_pull_help_mentions_default_output_behavior():
    low = _help(["pull"]).lower()
    assert "current directory" in low or "original filename" in low


def test_ls_help_mentions_sort_order():
    assert "created_at" in _help(["ls"]).lower()


def test_ls_help_mentions_pagination_cursor():
    assert "after" in _help(["ls"]).lower() and "cursor" in _help(["ls"]).lower()


def test_inspect_help_lists_returned_fields():
    out = _help(["inspect"]).lower()
    for field in ["artifact_id", "filename", "content_type", "size_bytes",
                  "content_hash", "created_at", "expires_at", "metadata"]:
        assert field in out, f"inspect --help is missing field name {field!r}"


def test_link_help_mentions_stdout_url():
    assert "stdout" in _help(["link"]).lower()


def test_whoami_help_describes_return_fields():
    low = _help(["whoami"]).lower()
    assert any(s in low for s in ("tenant", "plan", "usage"))


def test_auth_login_help_mentions_config_storage():
    out = _help(["auth", "login"])
    assert ".config/artifacta" in out or "XDG_CONFIG_HOME" in out


def test_auth_group_help_mentions_api_key_env_var():
    assert "ARTIFACTA_API_KEY" in _help(["auth"])


def test_session_group_help_defines_what_a_session_is():
    assert "session" in _help(["session"]).lower()


# ---- Hygiene: no $VAR placeholders that won't expand for copy-paste users ----


def test_root_help_has_no_shell_variable_placeholders():
    """Spec note: examples should use literal placeholders (`ses_abc`), not
    `$VAR` references that won't expand for copy-paste users."""
    import re

    out = _help([])
    matches = re.findall(r"\$[A-Z]+", out)
    assert matches == [], f"Found shell-variable placeholders in root help: {matches}"


# ---- Registry-level guarantee: every command/group has a non-empty epilog ----


@pytest.mark.parametrize("argv", LEAF_COMMANDS + GROUPS, ids=lambda a: " ".join(a) or "root")
def test_every_command_has_non_empty_epilog(argv):
    """Walk Click's registry and assert each command/group carries an epilog.

    This catches the "shipped a new command and forgot to add help text"
    regression at CI time rather than in QA.
    """
    cmd = main
    for name in argv:
        cmd = cmd.get_command(None, name)
        assert cmd is not None, f"Command not found: artifacta {' '.join(argv)}"
    assert cmd.epilog and cmd.epilog.strip(), (
        f"`artifacta {' '.join(argv) or '(root)'}` has no epilog"
    )


# ---- CLI-PRE-06: workflow-ranked root command order ----


_EXPECTED_ROOT_ORDER = [
    "push", "pull", "ls", "inspect", "link", "rm",
    "session", "whoami", "auth", "config",
]


def _commands_section_lines(out: str) -> list[str]:
    """Extract the command-name column from a `Commands:` section, stopping
    at the first blank line that ends the block."""
    lines = out.splitlines()
    try:
        start = lines.index("Commands:") + 1
    except ValueError:
        return []
    names: list[str] = []
    for line in lines[start:]:
        if not line.strip():
            break
        # `  push     Upload a file...` → "push"
        names.append(line.split()[0])
    return names


def test_root_command_order_matches_workflow():
    """Root `--help` lists commands in canonical workflow order
    (data-plane loop first, utilities last). If a new command ships
    without being slotted into _ROOT_COMMAND_ORDER in cli.py, this
    test fails — that's by design."""
    out = _help([])
    assert _commands_section_lines(out) == _EXPECTED_ROOT_ORDER


def test_root_has_exactly_ten_commands():
    """Adding a new top-level command without updating
    _ROOT_COMMAND_ORDER (or removing one without cleaning up) is a
    deliberate decision. Make it a forced conversation by failing here."""
    assert len(_commands_section_lines(_help([]))) == 10


def test_session_subgroup_uses_default_alphabetical_order():
    """Subgroups intentionally keep Click's default order: with ≤3 commands
    each, workflow ordering offers no signal."""
    assert _commands_section_lines(_help(["session"])) == ["ls", "new", "seal"]


def test_config_subgroup_uses_default_alphabetical_order():
    assert _commands_section_lines(_help(["config"])) == ["get", "set"]


def test_auth_subgroup_lists_only_login():
    assert _commands_section_lines(_help(["auth"])) == ["login"]


def test_root_command_order_is_stable_across_invocations():
    """No randomness, no env-var influence — same output every time."""
    out1 = _help([])
    out2 = _help([])
    assert _commands_section_lines(out1) == _commands_section_lines(out2)
