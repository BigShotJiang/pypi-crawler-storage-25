"""Tests for AF_CLI-5.4 — SDK Error Hierarchy and Package Distribution."""

from __future__ import annotations

import httpx
import pytest
import respx


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch, tmp_path: object) -> None:
    """Clear Artifacta env vars for test isolation."""
    monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_test1234567890abcdef12345678")
    monkeypatch.delenv("ARTIFACTA_API_URL", raising=False)
    monkeypatch.delenv("ARTIFACTA_SESSION_ID", raising=False)
    monkeypatch.delenv("ARTIFACTA_AGENT_ID", raising=False)
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))


class TestErrorHierarchy:
    """Test that the error hierarchy is correctly structured."""

    def test_artifacta_error_base(self) -> None:
        from artifacta.errors import ArtifactaError

        err = ArtifactaError(code="test", message="Test error", status=400)
        assert err.code == "test"
        assert err.message == "Test error"
        assert err.status == 400
        assert str(err) == "Test error"

    def test_all_subclasses_extend_base(self) -> None:
        from artifacta.errors import (
            ArtifactaError,
            ArtifactDeletedError,
            ArtifactExpiredError,
            ArtifactNotFoundError,
            AuthenticationError,
            FileTooLargeError,
            InvalidRequestError,
            QuotaExceededError,
            RateLimitedError,
            SessionNotFoundError,
            SessionSealedError,
            TTLExceedsPlanLimitError,
            UploadNotFoundError,
        )

        subclasses = [
            AuthenticationError,
            InvalidRequestError,
            ArtifactNotFoundError,
            ArtifactExpiredError,
            ArtifactDeletedError,
            SessionSealedError,
            SessionNotFoundError,
            QuotaExceededError,
            TTLExceedsPlanLimitError,
            RateLimitedError,
            FileTooLargeError,
            UploadNotFoundError,
        ]
        for cls in subclasses:
            assert issubclass(cls, ArtifactaError), f"{cls.__name__} is not a subclass of ArtifactaError"

    def test_authentication_error_defaults(self) -> None:
        from artifacta.errors import AuthenticationError

        err = AuthenticationError()
        assert err.code == "unauthorized"
        assert err.status == 401

    def test_rate_limited_error_retry_after(self) -> None:
        from artifacta.errors import RateLimitedError

        err = RateLimitedError(retry_after_seconds=5.0)
        assert err.code == "rate_limited"
        assert err.status == 429
        assert err.retry_after_seconds == 5.0

    def test_rate_limited_error_default_retry(self) -> None:
        from artifacta.errors import RateLimitedError

        err = RateLimitedError()
        assert err.retry_after_seconds == 1.0


class TestErrorCodeMapping:
    """Verify every API error code maps to exactly one exception subclass."""

    def test_all_documented_codes_mapped(self) -> None:
        from artifacta.errors import ERROR_CODE_MAP

        documented_codes = {
            "invalid_request",
            "unauthorized",
            "quota_exceeded",
            "artifact_not_found",
            "session_not_found",
            "session_sealed",
            "artifact_expired",
            "artifact_already_deleted",
            "file_too_large",
            "rate_limited",
            "upload_not_found",
            "ttl_exceeds_plan_limit",
        }
        assert set(ERROR_CODE_MAP.keys()) == documented_codes

    def test_each_code_maps_to_unique_class(self) -> None:
        from artifacta.errors import ERROR_CODE_MAP

        classes = list(ERROR_CODE_MAP.values())
        # Each class maps to exactly one code (no two codes share a class)
        assert len(set(classes)) == len(classes)


class TestRaiseForErrorResponse:
    """Test raise_for_error_response parses API errors correctly."""

    def test_raises_artifact_not_found(self) -> None:
        from artifacta.errors import ArtifactNotFoundError, raise_for_error_response

        with pytest.raises(ArtifactNotFoundError) as exc_info:
            raise_for_error_response(404, {"error": {"code": "artifact_not_found", "message": "Not found"}})
        assert exc_info.value.code == "artifact_not_found"
        assert exc_info.value.message == "Not found"

    def test_raises_rate_limited_with_retry_after(self) -> None:
        from artifacta.errors import RateLimitedError, raise_for_error_response

        with pytest.raises(RateLimitedError) as exc_info:
            raise_for_error_response(429, {
                "error": {"code": "rate_limited", "message": "Too fast", "retry_after_seconds": 3.5}
            })
        assert exc_info.value.retry_after_seconds == 3.5

    def test_raises_session_sealed(self) -> None:
        from artifacta.errors import SessionSealedError, raise_for_error_response

        with pytest.raises(SessionSealedError):
            raise_for_error_response(409, {"error": {"code": "session_sealed", "message": "Sealed"}})

    def test_raises_quota_exceeded(self) -> None:
        from artifacta.errors import QuotaExceededError, raise_for_error_response

        with pytest.raises(QuotaExceededError):
            raise_for_error_response(429, {"error": {"code": "quota_exceeded", "message": "Over limit"}})

    def test_unknown_code_raises_base(self) -> None:
        from artifacta.errors import ArtifactaError, raise_for_error_response

        with pytest.raises(ArtifactaError) as exc_info:
            raise_for_error_response(500, {"error": {"code": "some_new_code", "message": "Internal"}})
        assert exc_info.value.code == "some_new_code"
        assert exc_info.value.status == 500

    def test_raises_all_typed_errors(self) -> None:
        """Each error code in the map raises its correct exception type."""
        from artifacta.errors import ERROR_CODE_MAP, raise_for_error_response

        for code, expected_cls in ERROR_CODE_MAP.items():
            if code == "rate_limited":
                continue  # Tested separately due to retry_after
            with pytest.raises(expected_cls):
                raise_for_error_response(400, {"error": {"code": code, "message": "test"}})


class TestClientErrorIntegration:
    """Test that Client._request raises typed errors from API responses."""

    @respx.mock
    def test_client_raises_typed_error(self) -> None:
        from artifacta.errors import ArtifactNotFoundError
        from artifacta.sdk import Client

        client = Client(base_url="https://mock.api.dev")
        respx.get("https://mock.api.dev/v1/artifacts/art_missing123456").mock(
            return_value=httpx.Response(
                404, json={"error": {"code": "artifact_not_found", "message": "Not found"}}
            )
        )
        with pytest.raises(ArtifactNotFoundError):
            client._request("GET", "/v1/artifacts/art_missing123456")

    @respx.mock
    def test_client_raises_rate_limited_with_retry(self) -> None:
        from artifacta.errors import RateLimitedError
        from artifacta.sdk import Client

        client = Client(base_url="https://mock.api.dev")
        respx.post("https://mock.api.dev/v1/artifacts").mock(
            return_value=httpx.Response(
                429, json={"error": {"code": "rate_limited", "message": "Slow down", "retry_after_seconds": 2.0}}
            )
        )
        with pytest.raises(RateLimitedError) as exc_info:
            client._request("POST", "/v1/artifacts")
        assert exc_info.value.retry_after_seconds == 2.0

    @respx.mock
    def test_client_catches_as_base_class(self) -> None:
        from artifacta.errors import ArtifactaError
        from artifacta.sdk import Client

        client = Client(base_url="https://mock.api.dev")
        respx.get("https://mock.api.dev/v1/artifacts/art_gone1234567890").mock(
            return_value=httpx.Response(
                410, json={"error": {"code": "artifact_expired", "message": "Expired"}}
            )
        )
        with pytest.raises(ArtifactaError) as exc_info:
            client._request("GET", "/v1/artifacts/art_gone1234567890")
        assert exc_info.value.code == "artifact_expired"


class TestPackageImports:
    """Verify all error classes are importable from the artifacta package root."""

    def test_import_artifacta_error(self) -> None:
        from artifacta import ArtifactaError
        assert ArtifactaError is not None

    def test_import_authentication_error(self) -> None:
        from artifacta import AuthenticationError
        assert AuthenticationError is not None

    def test_import_all_subclasses(self) -> None:
        from artifacta import (
            ArtifactDeletedError,
            ArtifactExpiredError,
            ArtifactNotFoundError,
            AuthenticationError,
            FileTooLargeError,
            InvalidRequestError,
            QuotaExceededError,
            RateLimitedError,
            SessionNotFoundError,
            SessionSealedError,
            TTLExceedsPlanLimitError,
            UploadNotFoundError,
        )
        # All should be importable without error
        assert all([
            AuthenticationError, InvalidRequestError, ArtifactNotFoundError,
            ArtifactExpiredError, ArtifactDeletedError, SessionSealedError,
            SessionNotFoundError, QuotaExceededError, TTLExceedsPlanLimitError,
            RateLimitedError, FileTooLargeError, UploadNotFoundError,
        ])

    def test_import_client_and_error(self) -> None:
        """The canonical import from the spec: from artifacta import Client, ArtifactaError"""
        from artifacta import Client, ArtifactaError
        assert Client is not None
        assert ArtifactaError is not None
