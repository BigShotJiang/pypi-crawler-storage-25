"""Tests for `rm --dry-run` (CLI-PRE-02) and `--yes` alias (CLI-PRE-04)."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from artifacta.cli import main

ARTIFACT_ID = "art_tEsT1234567890Ab"
ARTIFACT_ID_2 = "art_sEcOnD567890Ab12"

# Full artifact response shape (matches what GET /v1/artifacts/<id> returns).
INSPECT_RESPONSE_1 = {
    "artifact_id": ARTIFACT_ID,
    "filename": "report.pdf",
    "content_type": "application/pdf",
    "size_bytes": 1024,
    "content_hash": "sha256:abc",
    "session_id": None,
    "agent_id": None,
    "metadata": {},
    "created_at": "2026-04-02T10:00:00+00:00",
    "expires_at": "2026-05-02T10:00:00+00:00",
}
INSPECT_RESPONSE_2 = {
    "artifact_id": ARTIFACT_ID_2,
    "filename": "data.json",
    "content_type": "application/json",
    "size_bytes": 2048,
    "content_hash": "sha256:def",
    "session_id": None,
    "agent_id": None,
    "metadata": {},
    "created_at": "2026-04-02T11:00:00+00:00",
    "expires_at": None,
}

# Session-list shape (artifacts inside `artifacts` envelope).
SESSION_LIST_RESPONSE = {
    "artifacts": [
        {
            "artifact_id": ARTIFACT_ID,
            "filename": "report.pdf",
            "size_bytes": 1024,
            "created_at": "2026-04-02T10:00:00+00:00",
            "expires_at": "2026-05-02T10:00:00+00:00",
        },
        {
            "artifact_id": ARTIFACT_ID_2,
            "filename": "data.json",
            "size_bytes": 2048,
            "created_at": "2026-04-02T11:00:00+00:00",
            "expires_at": None,
        },
    ],
    "next_cursor": None,
    "has_more": False,
}

DELETE_RESPONSE = {
    "artifact_id": ARTIFACT_ID,
    "deleted": True,
    "deleted_at": "2026-04-02T12:00:00+00:00",
}


@pytest.fixture
def runner():
    return CliRunner(mix_stderr=False)


def _patch_key():
    return patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32)


# ============================================================================
# Explicit IDs + --dry-run
# ============================================================================


class TestRmDryRunExplicitIds:
    def test_explicit_ids_makes_no_delete_call(self, runner):
        """`rm <id> <id> --dry-run` only GETs (no DELETE) and exits 0."""
        calls: list[tuple[str, str]] = []

        def mock_api(method, path, **kwargs):
            calls.append((method, path))
            if path == f"/v1/artifacts/{ARTIFACT_ID}":
                return INSPECT_RESPONSE_1
            if path == f"/v1/artifacts/{ARTIFACT_ID_2}":
                return INSPECT_RESPONSE_2
            raise AssertionError(f"Unexpected call: {method} {path}")

        with _patch_key(), patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(main, ["rm", ARTIFACT_ID, ARTIFACT_ID_2, "--dry-run"])

        assert result.exit_code == 0
        # Exactly two GETs, no DELETE.
        assert len(calls) == 2
        assert all(method == "GET" for method, _ in calls)
        assert not any(method == "DELETE" for method, _ in calls)

    def test_explicit_ids_json_shape(self, runner):
        """JSON output matches `{would_delete, count, total_bytes}` shape."""

        def mock_api(method, path, **kwargs):
            if path == f"/v1/artifacts/{ARTIFACT_ID}":
                return INSPECT_RESPONSE_1
            if path == f"/v1/artifacts/{ARTIFACT_ID_2}":
                return INSPECT_RESPONSE_2
            raise AssertionError(f"Unexpected: {method} {path}")

        with _patch_key(), patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(
                main, ["rm", ARTIFACT_ID, ARTIFACT_ID_2, "--dry-run", "--json"],
            )

        assert result.exit_code == 0
        body = json.loads(result.output)
        assert set(body.keys()) == {"would_delete", "count", "total_bytes"}
        assert body["count"] == 2
        assert body["total_bytes"] == 1024 + 2048
        assert len(body["would_delete"]) == 2
        assert body["would_delete"][0]["artifact_id"] == ARTIFACT_ID
        assert body["would_delete"][1]["artifact_id"] == ARTIFACT_ID_2

    def test_explicit_ids_human_table_header(self, runner):
        """Human output uses `WOULD DELETE` header, not `ARTIFACT ID`."""

        def mock_api(method, path, **kwargs):
            if path == f"/v1/artifacts/{ARTIFACT_ID}":
                return INSPECT_RESPONSE_1
            raise AssertionError(f"Unexpected: {method} {path}")

        with _patch_key(), patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(main, ["rm", ARTIFACT_ID, "--dry-run", "--human"])

        assert result.exit_code == 0
        assert "WOULD DELETE" in result.stderr
        assert "FILENAME" in result.stderr
        assert "SIZE" in result.stderr
        # The IDs are still printed to stdout for scripting.
        assert ARTIFACT_ID in result.output

    def test_explicit_ids_human_totals(self, runner):
        """Human output prints totals (count + total size)."""

        def mock_api(method, path, **kwargs):
            if path == f"/v1/artifacts/{ARTIFACT_ID}":
                return INSPECT_RESPONSE_1
            if path == f"/v1/artifacts/{ARTIFACT_ID_2}":
                return INSPECT_RESPONSE_2
            raise AssertionError(f"Unexpected: {method} {path}")

        with _patch_key(), patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(
                main, ["rm", ARTIFACT_ID, ARTIFACT_ID_2, "--dry-run", "--human"],
            )

        assert result.exit_code == 0
        # 1024 + 2048 = 3072 bytes -> 3.0 KB
        assert "2 artifacts would be deleted" in result.stderr
        assert "3.0 KB" in result.stderr


# ============================================================================
# --session + --dry-run
# ============================================================================


class TestRmDryRunSession:
    def test_session_lists_and_does_not_delete(self, runner):
        """`rm --session ses_x --dry-run` lists session artifacts, no DELETE."""
        calls: list[tuple[str, str]] = []

        def mock_api(method, path, **kwargs):
            calls.append((method, path))
            if method == "GET" and path == "/v1/artifacts":
                return SESSION_LIST_RESPONSE
            raise AssertionError(f"Unexpected: {method} {path}")

        with _patch_key(), patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(
                main, ["rm", "--session", "ses_abc", "--dry-run", "--json"],
            )

        assert result.exit_code == 0
        # Only the list call, no per-ID GET, no DELETE.
        assert len(calls) == 1
        assert calls[0] == ("GET", "/v1/artifacts")
        body = json.loads(result.output)
        assert body["count"] == 2
        assert body["total_bytes"] == 1024 + 2048

    def test_session_human_totals(self, runner):
        """Session dry-run prints totals at the bottom."""

        def mock_api(method, path, **kwargs):
            if method == "GET" and path == "/v1/artifacts":
                return SESSION_LIST_RESPONSE
            raise AssertionError(f"Unexpected: {method} {path}")

        with _patch_key(), patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(
                main, ["rm", "--session", "ses_abc", "--dry-run", "--human"],
            )

        assert result.exit_code == 0
        assert "WOULD DELETE" in result.stderr
        assert "2 artifacts would be deleted" in result.stderr
        assert "3.0 KB" in result.stderr


# ============================================================================
# Mixed: explicit IDs + --session + --dry-run
# ============================================================================


class TestRmDryRunMixed:
    def test_mixed_inputs_combines_all(self, runner):
        """Explicit IDs + --session: both are listed, counted, totaled."""
        # Use a session-list with one artifact and an explicit ID for another.
        single_session = {
            "artifacts": [
                {
                    "artifact_id": ARTIFACT_ID_2,
                    "filename": "data.json",
                    "size_bytes": 2048,
                    "created_at": "2026-04-02T11:00:00+00:00",
                    "expires_at": None,
                },
            ],
            "next_cursor": None,
            "has_more": False,
        }

        def mock_api(method, path, **kwargs):
            if method == "GET" and path == "/v1/artifacts":
                return single_session
            if method == "GET" and path == f"/v1/artifacts/{ARTIFACT_ID}":
                return INSPECT_RESPONSE_1
            raise AssertionError(f"Unexpected: {method} {path}")

        with _patch_key(), patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(
                main,
                ["rm", ARTIFACT_ID, "--session", "ses_abc", "--dry-run", "--json"],
            )

        assert result.exit_code == 0
        body = json.loads(result.output)
        assert body["count"] == 2
        assert body["total_bytes"] == 1024 + 2048
        ids = [a["artifact_id"] for a in body["would_delete"]]
        assert set(ids) == {ARTIFACT_ID, ARTIFACT_ID_2}


# ============================================================================
# --dry-run + --force: dry-run wins, no DELETE
# ============================================================================


class TestRmDryRunForceOverride:
    def test_dry_run_overrides_force(self, runner):
        """`rm <id> --force --dry-run` does not call DELETE."""
        calls: list[tuple[str, str]] = []

        def mock_api(method, path, **kwargs):
            calls.append((method, path))
            if path == f"/v1/artifacts/{ARTIFACT_ID}":
                return INSPECT_RESPONSE_1
            raise AssertionError(f"Unexpected: {method} {path}")

        with _patch_key(), patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(
                main, ["rm", ARTIFACT_ID, "--force", "--dry-run", "--json"],
            )

        assert result.exit_code == 0
        # Only GET, no DELETE.
        assert all(method == "GET" for method, _ in calls)
        assert not any(method == "DELETE" for method, _ in calls)
        body = json.loads(result.output)
        assert body["count"] == 1


# ============================================================================
# Sanity: non-dry-run path still calls DELETE
# ============================================================================


class TestRmNonDryRunUnchanged:
    def test_non_dry_run_still_deletes(self, runner):
        """Without --dry-run, DELETE is still called (regression guard)."""
        calls: list[tuple[str, str]] = []

        def mock_api(method, path, **kwargs):
            calls.append((method, path))
            if method == "DELETE":
                return DELETE_RESPONSE
            raise AssertionError(f"Unexpected: {method} {path}")

        with _patch_key(), patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(main, ["rm", ARTIFACT_ID, "--force", "--json"])

        assert result.exit_code == 0
        assert any(method == "DELETE" for method, _ in calls)


# ============================================================================
# CLI-PRE-04: --yes is an alias for --force
# ============================================================================


class TestRmYesAlias:
    def test_yes_alias_behaves_identically_to_force(self, runner):
        """`rm <id> --yes` and `rm <id> --force` produce the same exit code and effect."""
        # Both invocations should DELETE without prompting.
        with _patch_key(), patch("artifacta.cli.api_request", return_value=DELETE_RESPONSE):
            result_force = runner.invoke(main, ["rm", ARTIFACT_ID, "--force", "--json"])
            result_yes = runner.invoke(main, ["rm", ARTIFACT_ID, "--yes", "--json"])

        assert result_force.exit_code == result_yes.exit_code == 0
        # Same JSON shape — both call DELETE once and emit `deleted` array.
        body_force = json.loads(result_force.output)
        body_yes = json.loads(result_yes.output)
        assert body_force.keys() == body_yes.keys() == {"deleted", "failed"}
        assert len(body_force["deleted"]) == len(body_yes["deleted"]) == 1

    def test_yes_listed_in_rm_help(self, runner):
        """`rm --help` advertises both `--force` and `--yes` so agents can discover the alias."""
        result = runner.invoke(main, ["rm", "--help"])
        assert result.exit_code == 0
        assert "--force" in result.output
        assert "--yes" in result.output
