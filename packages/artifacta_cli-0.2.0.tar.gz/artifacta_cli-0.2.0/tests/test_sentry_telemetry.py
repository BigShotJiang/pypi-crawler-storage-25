"""Tests for CLI Sentry telemetry opt-in wiring."""

import sys
from unittest.mock import patch

from artifacta.cli import _init_sentry, _sentry_scrub, _sentry_before_send


def test_telemetry_unset_does_not_import_sentry(monkeypatch):
    """With ARTIFACTA_TELEMETRY unset, sentry_sdk is never loaded."""
    monkeypatch.delenv("ARTIFACTA_TELEMETRY", raising=False)
    sys.modules.pop("sentry_sdk", None)

    _init_sentry()

    assert "sentry_sdk" not in sys.modules


def test_telemetry_zero_does_not_import_sentry(monkeypatch):
    """With ARTIFACTA_TELEMETRY=0, sentry_sdk is never loaded."""
    monkeypatch.setenv("ARTIFACTA_TELEMETRY", "0")
    sys.modules.pop("sentry_sdk", None)

    _init_sentry()

    assert "sentry_sdk" not in sys.modules


def test_telemetry_one_initializes_sentry_with_pii_safeguards(monkeypatch):
    """With ARTIFACTA_TELEMETRY=1, sentry_sdk.init is called with the CLI DSN
    AND PII safeguards: no default PII, no local variable capture, scrubber."""
    monkeypatch.setenv("ARTIFACTA_TELEMETRY", "1")

    with patch("sentry_sdk.init") as mock_init:
        _init_sentry()

    mock_init.assert_called_once()
    kwargs = mock_init.call_args.kwargs
    assert kwargs["dsn"].startswith("https://")
    assert "ingest.us.sentry.io" in kwargs["dsn"]
    assert kwargs["traces_sample_rate"] == 0.0
    # QA-CLI-502 — the three PII safeguards
    assert kwargs["send_default_pii"] is False
    assert kwargs["include_local_variables"] is False
    assert callable(kwargs["before_send"])


def test_sentry_scrub_redacts_api_key_in_strings():
    """QA-CLI-502: api keys matching ak_live_<32alnum> are replaced everywhere."""
    key = "ak_live_" + "a" * 32
    event = {
        "message": f"authorized with {key}",
        "extra": {"some_field": f"leading {key} trailing"},
        "breadcrumbs": [{"data": {"payload": f"x={key};y=z"}}],
    }
    scrubbed = _sentry_scrub(event)
    import json
    blob = json.dumps(scrubbed)
    assert key not in blob
    assert "ak_live_[REDACTED]" in blob


def test_sentry_scrub_redacts_sensitive_keys_regardless_of_value():
    """QA-CLI-502: field names like api_key/authorization/token redact regardless of value shape."""
    event = {
        "extra": {
            "api_key": "whatever the value is",
            "Authorization": "Bearer xyz",
            "request": {"token": "nested token here"},
        }
    }
    scrubbed = _sentry_scrub(event)
    assert scrubbed["extra"]["api_key"] == "[REDACTED]"
    assert scrubbed["extra"]["Authorization"] == "[REDACTED]"
    assert scrubbed["extra"]["request"]["token"] == "[REDACTED]"


def test_sentry_before_send_swallows_scrubber_errors_and_drops_event():
    """QA-CLI-502 defense-in-depth: if the scrubber raises, drop the event
    rather than risk sending one that still contains a key."""
    with patch("artifacta.cli._sentry_scrub", side_effect=RuntimeError("boom")):
        result = _sentry_before_send({"message": "irrelevant"}, hint=None)
    assert result is None
