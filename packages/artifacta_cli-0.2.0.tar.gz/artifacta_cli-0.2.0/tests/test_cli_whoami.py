"""Tests for CLI whoami command (AF_CLI-4.6, updated for AF_CLI-4.5 output conventions)."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from artifacta.cli import main

WHOAMI_RESPONSE = {
    "tenant_name": "Test Tenant",
    "plan": "free",
    "api_key_last_4": "ab12",
    "usage_requests_month": 42,
    "plan_requests_limit_month": 10000,
    "usage_storage_bytes": 1048576,
    "plan_storage_limit_bytes": 1073741824,
}


@pytest.fixture
def runner():
    return CliRunner(mix_stderr=False)


class TestWhoamiHuman:
    def test_whoami_human_output(self, runner):
        """Human output shows tenant info on stderr (--human forces it in piped context)."""
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami", "--human"])

        assert result.exit_code == 0
        assert "Test Tenant" in result.stderr
        assert "free" in result.stderr
        assert "...ab12" in result.stderr
        assert "42" in result.stderr
        assert "10,000" in result.stderr

    def test_whoami_human_forced(self, runner):
        """--human flag forces human output even when stdout is piped."""
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami", "--human"])

        assert result.exit_code == 0
        assert "Tenant:" in result.stderr
        assert "Plan:" in result.stderr

    def test_whoami_human_data_to_stdout(self, runner):
        """Human mode puts tenant name on stdout for scripting."""
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami", "--human"])

        assert result.exit_code == 0
        assert "Test Tenant" in result.output

    def test_whoami_storage_formatting(self, runner):
        """Storage bytes are formatted in human-readable units."""
        resp = {**WHOAMI_RESPONSE, "usage_storage_bytes": 1048576}
        with patch("artifacta.cli.api_request", return_value=resp):
            result = runner.invoke(main, ["whoami", "--human"])

        assert "1.0 MB" in result.stderr
        assert "1.0 GB" in result.stderr  # plan limit

    def test_whoami_auto_json_when_piped(self, runner):
        """Without --human, piped stdout triggers auto-JSON (CliRunner is not a tty)."""
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["tenant_name"] == "Test Tenant"


class TestWhoamiJSON:
    def test_whoami_json_flag(self, runner):
        """--json flag outputs valid JSON with all expected fields."""
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["tenant_name"] == "Test Tenant"
        assert data["plan"] == "free"
        assert data["api_key_last_4"] == "ab12"
        assert data["usage_requests_month"] == 42
        assert data["plan_requests_limit_month"] == 10000
        assert data["usage_storage_bytes"] == 1048576
        assert data["plan_storage_limit_bytes"] == 1073741824

    def test_whoami_json_has_all_fields(self, runner):
        """JSON output has exactly the expected fields."""
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami", "--json"])

        data = json.loads(result.output)
        expected_keys = {
            "tenant_name", "plan", "api_key_last_4",
            "usage_requests_month", "plan_requests_limit_month",
            "usage_storage_bytes", "plan_storage_limit_bytes",
        }
        assert set(data.keys()) == expected_keys


class TestWhoamiErrors:
    def test_whoami_no_key_configured(self, runner, monkeypatch):
        """No API key anywhere returns specific missing-key message and exit 1."""
        monkeypatch.delenv("ARTIFACTA_API_KEY", raising=False)
        with patch("artifacta.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["whoami"])

        assert result.exit_code == 1
        assert "No API key configured" in result.stderr
        assert "artifacta auth login" in result.stderr

    def test_whoami_invalid_key(self, runner, monkeypatch):
        """Invalid key (401 from server) returns exit code 1."""
        from artifacta.client import ArtifactaAPIError

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_" + "x" * 32)
        with patch("artifacta.cli.api_request",
                    side_effect=ArtifactaAPIError("unauthorized", "Invalid API key.", 401)):
            result = runner.invoke(main, ["whoami"])

        assert result.exit_code == 1
        assert "Authentication failed" in result.stderr

    def test_whoami_network_error(self, runner, monkeypatch):
        """Network failure returns exit code 3."""
        from artifacta.client import ArtifactaNetworkError

        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_" + "x" * 32)
        with patch("artifacta.cli.api_request",
                    side_effect=ArtifactaNetworkError("Connection refused")):
            result = runner.invoke(main, ["whoami"])

        assert result.exit_code == 3
        assert "Authentication failed" in result.stderr


class TestWhoamiEnvVar:
    def test_whoami_with_env_key(self, runner, monkeypatch):
        """Works with ARTIFACTA_API_KEY env var."""
        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_" + "x" * 32)
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami"])

        assert result.exit_code == 0
        # Auto-JSON in piped context (CliRunner is not a tty)
        data = json.loads(result.output)
        assert data["tenant_name"] == "Test Tenant"

    def test_whoami_with_config_auth(self, runner, tmp_path, monkeypatch):
        """Works with config file authentication."""
        monkeypatch.delenv("ARTIFACTA_API_KEY", raising=False)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))

        from artifacta.config import save_config
        save_config({"auth": {"api_key": "ak_live_" + "y" * 32}, "defaults": {}})

        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami"])

        assert result.exit_code == 0


class TestWhoamiOutputEnvVar:
    def test_whoami_artifacta_output_json(self, runner, monkeypatch):
        """ARTIFACTA_OUTPUT=json forces JSON output."""
        monkeypatch.setenv("ARTIFACTA_OUTPUT", "json")
        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_" + "x" * 32)
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["tenant_name"] == "Test Tenant"

    def test_whoami_human_overrides_output_env(self, runner, monkeypatch):
        """--human overrides ARTIFACTA_OUTPUT=json."""
        monkeypatch.setenv("ARTIFACTA_OUTPUT", "json")
        monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_" + "x" * 32)
        with patch("artifacta.cli.api_request", return_value=WHOAMI_RESPONSE):
            result = runner.invoke(main, ["whoami", "--human"])

        assert result.exit_code == 0
        assert "Tenant:" in result.stderr
