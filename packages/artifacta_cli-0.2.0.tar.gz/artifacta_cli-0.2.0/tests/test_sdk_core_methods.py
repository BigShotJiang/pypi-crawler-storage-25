"""Tests for AF_CLI-5.2 — SDK Core Methods (push, push_dict, pull, pull_bytes, pull_dict)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest
import respx

MOCK_API = "https://mock.api.dev"
MOCK_KEY = "ak_live_test1234567890abcdef12345678"

MOCK_ARTIFACT_RESPONSE: dict[str, Any] = {
    "artifact_id": "art_abc1234567890x",
    "filename": "report.pdf",
    "content_type": "application/pdf",
    "size_bytes": 1024,
    "content_hash": "sha256:abcdef1234567890",
    "session_id": "ses_test12345678",
    "agent_id": "test_agent",
    "metadata": {"model": "claude-sonnet"},
    "expires_at": "2026-05-01T00:00:00Z",
    "created_at": "2026-04-02T12:00:00Z",
}


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("ARTIFACTA_API_KEY", MOCK_KEY)
    monkeypatch.delenv("ARTIFACTA_API_URL", raising=False)
    monkeypatch.delenv("ARTIFACTA_SESSION_ID", raising=False)
    monkeypatch.delenv("ARTIFACTA_AGENT_ID", raising=False)
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))


def _make_client():
    from artifacta.sdk import Client
    return Client(base_url=MOCK_API)


class TestArtifactObject:
    """Test the Artifact response wrapper."""

    def test_all_fields_accessible(self) -> None:
        from artifacta.sdk import Artifact

        art = Artifact(MOCK_ARTIFACT_RESPONSE)
        assert art.id == "art_abc1234567890x"
        assert art.filename == "report.pdf"
        assert art.content_type == "application/pdf"
        assert art.size_bytes == 1024
        assert art.content_hash == "sha256:abcdef1234567890"
        assert art.session_id == "ses_test12345678"
        assert art.agent_id == "test_agent"
        assert art.metadata == {"model": "claude-sonnet"}
        assert art.expires_at == "2026-05-01T00:00:00Z"
        assert art.created_at == "2026-04-02T12:00:00Z"

    def test_to_dict(self) -> None:
        from artifacta.sdk import Artifact

        art = Artifact(MOCK_ARTIFACT_RESPONSE)
        d = art.to_dict()
        assert d == MOCK_ARTIFACT_RESPONSE
        # Must return a copy
        d["artifact_id"] = "changed"
        assert art.id == "art_abc1234567890x"

    def test_repr(self) -> None:
        from artifacta.sdk import Artifact

        art = Artifact(MOCK_ARTIFACT_RESPONSE)
        r = repr(art)
        assert "art_abc1234567890x" in r
        assert "report.pdf" in r


class TestPushFromFile:
    """Test client.push(path=...)."""

    @respx.mock
    def test_push_file_returns_artifact(self, tmp_path: Path) -> None:
        test_file = tmp_path / "report.pdf"
        test_file.write_bytes(b"PDF content here")

        route = respx.post(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(201, json=MOCK_ARTIFACT_RESPONSE)
        )

        client = _make_client()
        artifact = client.push(str(test_file), session_id="ses_test12345678")

        assert route.called
        assert artifact.id == "art_abc1234567890x"
        assert artifact.filename == "report.pdf"

    @respx.mock
    def test_push_file_sends_multipart(self, tmp_path: Path) -> None:
        test_file = tmp_path / "data.txt"
        test_file.write_bytes(b"hello world")

        route = respx.post(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(201, json=MOCK_ARTIFACT_RESPONSE)
        )

        client = _make_client()
        client.push(str(test_file), session_id="ses_test12345678")

        req = route.calls[0].request
        assert b"multipart/form-data" in req.headers["content-type"].encode()

    @respx.mock
    def test_push_with_metadata(self, tmp_path: Path) -> None:
        test_file = tmp_path / "out.json"
        test_file.write_bytes(b"{}")

        route = respx.post(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(201, json=MOCK_ARTIFACT_RESPONSE)
        )

        client = _make_client()
        client.push(str(test_file), session_id="s", metadata={"key": "val"})

        req = route.calls[0].request
        body = req.content.decode("utf-8", errors="replace")
        assert "key" in body


class TestPushFromBytes:
    """Test client.push(content=b"...", filename="...")."""

    @respx.mock
    def test_push_bytes(self) -> None:
        route = respx.post(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(201, json=MOCK_ARTIFACT_RESPONSE)
        )

        client = _make_client()
        artifact = client.push(content=b"binary data", filename="blob.bin", session_id="s")

        assert route.called
        assert artifact.id == "art_abc1234567890x"

    def test_push_bytes_requires_filename(self) -> None:
        from artifacta.errors import InvalidRequestError

        client = _make_client()
        with pytest.raises(InvalidRequestError, match="filename"):
            client.push(content=b"data")

    def test_push_neither_path_nor_content_raises(self) -> None:
        from artifacta.errors import InvalidRequestError

        client = _make_client()
        with pytest.raises(InvalidRequestError):
            client.push()

    def test_push_both_path_and_content_raises(self, tmp_path: Path) -> None:
        from artifacta.errors import InvalidRequestError

        f = tmp_path / "x.txt"
        f.write_text("x")
        client = _make_client()
        with pytest.raises(InvalidRequestError, match="not both"):
            client.push(str(f), content=b"x", filename="x.txt")


class TestPushDict:
    """Test client.push_dict(data, ...)."""

    @respx.mock
    def test_push_dict_serializes_json(self) -> None:
        route = respx.post(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(201, json=MOCK_ARTIFACT_RESPONSE)
        )

        client = _make_client()
        artifact = client.push_dict({"score": 0.95}, session_id="s")

        assert route.called
        assert artifact.id == "art_abc1234567890x"
        # Verify it was sent as multipart with JSON content
        req = route.calls[0].request
        body = req.content.decode("utf-8", errors="replace")
        assert "score" in body

    @respx.mock
    def test_push_dict_default_filename(self) -> None:
        route = respx.post(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(201, json=MOCK_ARTIFACT_RESPONSE)
        )

        client = _make_client()
        client.push_dict({"k": "v"}, session_id="s")

        req = route.calls[0].request
        body = req.content.decode("utf-8", errors="replace")
        assert "data.json" in body

    @respx.mock
    def test_push_dict_custom_filename(self) -> None:
        route = respx.post(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(201, json=MOCK_ARTIFACT_RESPONSE)
        )

        client = _make_client()
        client.push_dict({"k": "v"}, filename="results.json", session_id="s")

        req = route.calls[0].request
        body = req.content.decode("utf-8", errors="replace")
        assert "results.json" in body

    def test_push_dict_rejects_non_serializable(self) -> None:
        from artifacta.errors import InvalidRequestError

        client = _make_client()
        with pytest.raises(InvalidRequestError, match="not JSON-serializable"):
            client.push_dict({"fn": lambda x: x}, session_id="s")  # type: ignore[dict-item]


class TestPull:
    """Test client.pull(artifact_id, output=...)."""

    @respx.mock
    def test_pull_to_directory(self, tmp_path: Path) -> None:
        respx.get(f"{MOCK_API}/v1/artifacts/art_abc1234567890x").mock(
            return_value=httpx.Response(200, json=MOCK_ARTIFACT_RESPONSE)
        )
        respx.get(f"{MOCK_API}/v1/artifacts/art_abc1234567890x/download-url").mock(
            return_value=httpx.Response(200, json={"download_url": "https://r2.example.com/file.pdf"})
        )
        respx.get("https://r2.example.com/file.pdf").mock(
            return_value=httpx.Response(200, content=b"PDF BYTES")
        )

        client = _make_client()
        result = client.pull("art_abc1234567890x", output=str(tmp_path))

        assert result == tmp_path / "report.pdf"
        assert result.read_bytes() == b"PDF BYTES"

    @respx.mock
    def test_pull_to_specific_file(self, tmp_path: Path) -> None:
        target = tmp_path / "custom_name.pdf"
        respx.get(f"{MOCK_API}/v1/artifacts/art_abc1234567890x").mock(
            return_value=httpx.Response(200, json=MOCK_ARTIFACT_RESPONSE)
        )
        respx.get(f"{MOCK_API}/v1/artifacts/art_abc1234567890x/download-url").mock(
            return_value=httpx.Response(200, json={"download_url": "https://r2.example.com/f.pdf"})
        )
        respx.get("https://r2.example.com/f.pdf").mock(
            return_value=httpx.Response(200, content=b"PDF BYTES")
        )

        client = _make_client()
        result = client.pull("art_abc1234567890x", output=str(target))

        assert result == target
        assert target.read_bytes() == b"PDF BYTES"


class TestPullBytes:
    """Test client.pull_bytes(artifact_id)."""

    @respx.mock
    def test_pull_bytes_returns_content(self) -> None:
        respx.get(f"{MOCK_API}/v1/artifacts/art_abc1234567890x/download-url").mock(
            return_value=httpx.Response(200, json={"download_url": "https://r2.example.com/file.bin"})
        )
        respx.get("https://r2.example.com/file.bin").mock(
            return_value=httpx.Response(200, content=b"\x00\x01\x02\x03")
        )

        client = _make_client()
        result = client.pull_bytes("art_abc1234567890x")
        assert result == b"\x00\x01\x02\x03"

    @respx.mock
    def test_pull_bytes_404_raises_not_found(self) -> None:
        from artifacta.errors import ArtifactNotFoundError

        respx.get(f"{MOCK_API}/v1/artifacts/art_missing123456xx/download-url").mock(
            return_value=httpx.Response(
                404, json={"error": {"code": "artifact_not_found", "message": "Not found"}}
            )
        )

        client = _make_client()
        with pytest.raises(ArtifactNotFoundError):
            client.pull_bytes("art_missing123456xx")

    @respx.mock
    def test_pull_bytes_410_raises_expired(self) -> None:
        from artifacta.errors import ArtifactExpiredError

        respx.get(f"{MOCK_API}/v1/artifacts/art_expired12345678/download-url").mock(
            return_value=httpx.Response(
                410, json={"error": {"code": "artifact_expired", "message": "Expired"}}
            )
        )

        client = _make_client()
        with pytest.raises(ArtifactExpiredError):
            client.pull_bytes("art_expired12345678")


class TestPullDict:
    """Test client.pull_dict(artifact_id)."""

    @respx.mock
    def test_pull_dict_returns_parsed_json(self) -> None:
        payload = {"results": [1, 2, 3], "score": 0.95}
        respx.get(f"{MOCK_API}/v1/artifacts/art_abc1234567890x/download-url").mock(
            return_value=httpx.Response(200, json={"download_url": "https://r2.example.com/data.json"})
        )
        respx.get("https://r2.example.com/data.json").mock(
            return_value=httpx.Response(200, content=json.dumps(payload).encode())
        )

        client = _make_client()
        result = client.pull_dict("art_abc1234567890x")
        assert result == payload

    @respx.mock
    def test_pull_dict_invalid_json_raises(self) -> None:
        from artifacta.errors import InvalidRequestError

        respx.get(f"{MOCK_API}/v1/artifacts/art_abc1234567890x/download-url").mock(
            return_value=httpx.Response(200, json={"download_url": "https://r2.example.com/bad.txt"})
        )
        respx.get("https://r2.example.com/bad.txt").mock(
            return_value=httpx.Response(200, content=b"not json {{")
        )

        client = _make_client()
        with pytest.raises(InvalidRequestError, match="not valid JSON"):
            client.pull_dict("art_abc1234567890x")

    @respx.mock
    def test_pull_dict_binary_content_raises(self) -> None:
        from artifacta.errors import InvalidRequestError

        respx.get(f"{MOCK_API}/v1/artifacts/art_abc1234567890x/download-url").mock(
            return_value=httpx.Response(200, json={"download_url": "https://r2.example.com/bin"})
        )
        respx.get("https://r2.example.com/bin").mock(
            return_value=httpx.Response(200, content=b"\x80\x81\x82\x83")
        )

        client = _make_client()
        with pytest.raises(InvalidRequestError, match="not valid JSON"):
            client.pull_dict("art_abc1234567890x")

    @respx.mock
    def test_pull_dict_404_raises_not_found(self) -> None:
        from artifacta.errors import ArtifactNotFoundError

        respx.get(f"{MOCK_API}/v1/artifacts/art_missing123456xx/download-url").mock(
            return_value=httpx.Response(
                404, json={"error": {"code": "artifact_not_found", "message": "Not found"}}
            )
        )

        client = _make_client()
        with pytest.raises(ArtifactNotFoundError):
            client.pull_dict("art_missing123456xx")

    @respx.mock
    def test_pull_dict_410_raises_expired(self) -> None:
        from artifacta.errors import ArtifactExpiredError

        respx.get(f"{MOCK_API}/v1/artifacts/art_expired12345678/download-url").mock(
            return_value=httpx.Response(
                410, json={"error": {"code": "artifact_expired", "message": "Expired"}}
            )
        )

        client = _make_client()
        with pytest.raises(ArtifactExpiredError):
            client.pull_dict("art_expired12345678")


class TestSessionIdOverride:
    """Verify explicit session_id overrides env var default."""

    @respx.mock
    def test_explicit_session_overrides_env(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        monkeypatch.setenv("ARTIFACTA_SESSION_ID", "ses_from_env_12")

        route = respx.post(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(201, json=MOCK_ARTIFACT_RESPONSE)
        )

        client = _make_client()
        f = tmp_path / "x.txt"
        f.write_text("hello")
        client.push(str(f), session_id="ses_explicit_12")

        req = route.calls[0].request
        body = req.content.decode("utf-8", errors="replace")
        assert "ses_explicit_12" in body
        assert "ses_from_env_12" not in body

    @respx.mock
    def test_env_session_used_when_no_explicit(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        monkeypatch.setenv("ARTIFACTA_SESSION_ID", "ses_from_env_12")

        route = respx.post(f"{MOCK_API}/v1/artifacts").mock(
            return_value=httpx.Response(201, json=MOCK_ARTIFACT_RESPONSE)
        )

        client = _make_client()
        f = tmp_path / "x.txt"
        f.write_text("hello")
        client.push(str(f))

        req = route.calls[0].request
        body = req.content.decode("utf-8", errors="replace")
        assert "ses_from_env_12" in body
