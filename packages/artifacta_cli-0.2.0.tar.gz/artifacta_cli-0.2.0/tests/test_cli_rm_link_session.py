"""Tests for CLI rm, link, session commands (AF_CLI-4.4)."""

from __future__ import annotations

import json
from unittest.mock import patch, call

import pytest
from click.testing import CliRunner

from artifacta.cli import main
from artifacta.client import ArtifactaAPIError, ArtifactaNetworkError

ARTIFACT_ID = "art_tEsT1234567890Ab"
ARTIFACT_ID_2 = "art_sEcOnD567890Ab12"

DELETE_RESPONSE = {
    "artifact_id": ARTIFACT_ID,
    "deleted": True,
    "deleted_at": "2026-04-02T10:00:00+00:00",
}

LINK_RESPONSE = {
    "link_id": "lnk_abcdefghij1234567890",
    "url": "https://dl.artifacta.io/lnk_abcdefghij1234567890",
    "artifact_id": ARTIFACT_ID,
    "expires_at": "2026-04-09T10:00:00+00:00",
    "created_at": "2026-04-02T10:00:00+00:00",
}

SEAL_RESPONSE = {
    "session_id": "pipeline_run_42",
    "status": "sealed",
    "sealed_at": "2026-04-02T10:00:00+00:00",
    "artifact_count": 5,
}

LIST_WITH_ARTIFACTS = {
    "artifacts": [
        {"artifact_id": ARTIFACT_ID, "filename": "a.pdf", "size_bytes": 100},
        {"artifact_id": ARTIFACT_ID_2, "filename": "b.pdf", "size_bytes": 200},
    ],
    "next_cursor": None,
    "has_more": False,
}


@pytest.fixture
def runner():
    return CliRunner()


def _patch_key():
    return patch("artifacta.cli.get_api_key", return_value="ak_live_" + "a" * 32)


# ============================================================================
# rm
# ============================================================================


class TestRm:
    def test_rm_single_artifact(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DELETE_RESPONSE):
            result = runner.invoke(main, ["rm", ARTIFACT_ID, "--force", "--human"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Deleted" in result.output

    def test_rm_multiple_artifacts(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DELETE_RESPONSE):
            result = runner.invoke(
                main, ["rm", ARTIFACT_ID, ARTIFACT_ID_2, "--force", "--human"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert "2 deleted" in result.output

    def test_rm_session(self, runner):
        """--session lists artifacts then deletes each."""
        def mock_api(method, path, **kwargs):
            if method == "GET":
                return LIST_WITH_ARTIFACTS
            if method == "DELETE":
                return DELETE_RESPONSE
            return {}

        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=mock_api):
            result = runner.invoke(
                main, ["rm", "--session", "ses_abc", "--force", "--human"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert "2 deleted" in result.output

    def test_rm_session_empty(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value={"artifacts": [], "next_cursor": None, "has_more": False}):
            result = runner.invoke(
                main, ["rm", "--session", "ses_empty", "--force", "--human"],
                catch_exceptions=False,
            )
            assert "No artifacts" in result.output

    def test_rm_confirmation_prompt_yes(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DELETE_RESPONSE):
            result = runner.invoke(
                main, ["rm", ARTIFACT_ID, "--human"],
                input="y\n",
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert "Deleted" in result.output

    def test_rm_confirmation_prompt_no(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DELETE_RESPONSE):
            result = runner.invoke(
                main, ["rm", ARTIFACT_ID, "--human"],
                input="n\n",
                catch_exceptions=False,
            )
            assert "Cancelled" in result.output

    def test_rm_force_skips_prompt(self, runner):
        """--force should not prompt."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DELETE_RESPONSE):
            result = runner.invoke(
                main, ["rm", ARTIFACT_ID, "--force", "--human"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            # No "Continue?" prompt in output
            assert "Continue?" not in result.output

    def test_rm_json_output(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=DELETE_RESPONSE):
            result = runner.invoke(
                main, ["rm", ARTIFACT_ID, "--force", "--json"],
                catch_exceptions=False,
            )
            body = json.loads(result.output)
            assert "deleted" in body
            assert len(body["deleted"]) == 1

    def test_rm_already_deleted(self, runner):
        """Already-deleted artifact should not fail the whole batch."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=ArtifactaAPIError(
                 "artifact_already_deleted", "Already deleted", 410)):
            result = runner.invoke(
                main, ["rm", ARTIFACT_ID, "--force", "--human"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert "1 deleted" in result.output

    def test_rm_no_args(self, runner):
        with _patch_key():
            result = runner.invoke(main, ["rm", "--force", "--human"])
            assert result.exit_code == 1

    def test_rm_no_key(self, runner):
        with patch("artifacta.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["rm", ARTIFACT_ID, "--force", "--human"])
            assert result.exit_code == 1


# ============================================================================
# link
# ============================================================================


class TestLink:
    def test_link_default_expiry(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LINK_RESPONSE):
            result = runner.invoke(main, ["link", ARTIFACT_ID, "--human"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "dl.artifacta.io" in result.output

    def test_link_custom_expiry(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LINK_RESPONSE) as mock_api:
            result = runner.invoke(
                main, ["link", ARTIFACT_ID, "--expires", "7d", "--human"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["json"]["expires_in"] == 604800  # 7 days in seconds

    def test_link_custom_expiry_hours(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LINK_RESPONSE) as mock_api:
            result = runner.invoke(
                main, ["link", ARTIFACT_ID, "--expires", "24h", "--json"],
                catch_exceptions=False,
            )
            call_kwargs = mock_api.call_args[1]
            assert call_kwargs["json"]["expires_in"] == 86400

    def test_link_json_output(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LINK_RESPONSE):
            result = runner.invoke(main, ["link", ARTIFACT_ID, "--json"], catch_exceptions=False)
            body = json.loads(result.output)
            assert body["link_id"] == "lnk_abcdefghij1234567890"
            assert body["url"].startswith("https://dl.artifacta.io/")

    def test_link_invalid_expires(self, runner):
        with _patch_key():
            result = runner.invoke(main, ["link", ARTIFACT_ID, "--expires", "invalid", "--human"])
            assert result.exit_code == 1

    def test_link_not_found(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=ArtifactaAPIError(
                 "artifact_not_found", "Not found", 404)):
            result = runner.invoke(main, ["link", ARTIFACT_ID, "--human"])
            assert result.exit_code == 1
            assert "not found" in result.output.lower()

    def test_link_no_key(self, runner):
        with patch("artifacta.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["link", ARTIFACT_ID, "--human"])
            assert result.exit_code == 1

    def test_link_human_outputs_url_to_stdout(self, runner):
        """Human mode outputs URL to stdout for scripting."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=LINK_RESPONSE):
            result = runner.invoke(main, ["link", ARTIFACT_ID, "--human"], catch_exceptions=False)
            # The last line of stdout should be the URL
            lines = result.output.strip().split("\n")
            assert "dl.artifacta.io" in lines[-1]


# ============================================================================
# session
# ============================================================================


class TestSession:
    def test_session_new(self, runner):
        result = runner.invoke(main, ["session", "new"], catch_exceptions=False)
        assert result.exit_code == 0
        sid = result.output.strip()
        assert sid.startswith("ses_")
        assert len(sid) == 16  # ses_ + 12 chars

    def test_session_new_format_consistent(self, runner):
        """Generated ID should match ses_ + 12 lowercase alphanumeric."""
        import re

        result = runner.invoke(main, ["session", "new"], catch_exceptions=False)
        sid = result.output.strip()
        assert re.match(r"^ses_[a-z0-9]{12}$", sid)

    def test_session_new_no_api_call(self, runner):
        """session new is purely local — no API call needed."""
        with patch("artifacta.cli.api_request") as mock_api:
            result = runner.invoke(main, ["session", "new"], catch_exceptions=False)
            mock_api.assert_not_called()
            assert result.exit_code == 0

    def test_session_seal(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=SEAL_RESPONSE):
            result = runner.invoke(
                main, ["session", "seal", "pipeline_run_42", "--human"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert "sealed" in result.output.lower()
            assert "5" in result.output  # artifact count

    def test_session_seal_json(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", return_value=SEAL_RESPONSE):
            result = runner.invoke(
                main, ["session", "seal", "pipeline_run_42", "--json"],
                catch_exceptions=False,
            )
            body = json.loads(result.output)
            assert body["session_id"] == "pipeline_run_42"
            assert body["status"] == "sealed"
            assert body["artifact_count"] == 5

    def test_session_seal_not_found(self, runner):
        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=ArtifactaAPIError(
                 "session_not_found", "No artifacts", 404)):
            result = runner.invoke(main, ["session", "seal", "nonexistent", "--human"])
            assert result.exit_code == 1
            assert "not found" in result.output.lower()

    def test_session_seal_not_found_message(self, runner):
        """Error message should include session_id."""
        with _patch_key(), \
             patch("artifacta.cli.api_request", side_effect=ArtifactaAPIError(
                 "session_not_found", "No artifacts", 404)):
            result = runner.invoke(main, ["session", "seal", "my_session", "--human"])
            assert "my_session" in result.output

    def test_session_seal_no_key(self, runner):
        with patch("artifacta.cli.get_api_key", return_value=None):
            result = runner.invoke(main, ["session", "seal", "some_session", "--human"])
            assert result.exit_code == 1
