"""Tests for `artifacta push --presigned` CLI command (AF_CLI-7.3)."""

import json
from unittest.mock import patch, call

import pytest
from click.testing import CliRunner

from artifacta.cli import main
from artifacta.client import ArtifactaAPIError


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def mock_key(monkeypatch):
    monkeypatch.setenv("ARTIFACTA_API_KEY", "ak_live_" + "a" * 32)
    monkeypatch.setenv("ARTIFACTA_API_URL", "http://localhost:8000")


UPLOAD_URL_RESPONSE = {
    "artifact_id": "art_tEsT1234567890",
    "status": "pending",
    "upload_url": "https://r2.test/presigned-put",
    "upload_expires_at": "2026-04-03T12:00:00+00:00",
    "upload_method": "PUT",
    "upload_headers": {"Content-Type": "application/octet-stream"},
}

COMPLETE_RESPONSE = {
    "artifact_id": "art_tEsT1234567890",
    "filename": "test.bin",
    "content_type": "application/octet-stream",
    "size_bytes": 100,
    "content_hash": "sha256:abc123",
    "session_id": None,
    "agent_id": None,
    "metadata": {},
    "expires_at": "2026-05-03T00:00:00+00:00",
    "created_at": "2026-04-03T00:00:00+00:00",
}


class TestPresignedFreeTier:

    def test_free_tier_quota_exceeded(self, runner, mock_key, tmp_path):
        test_file = tmp_path / "test.bin"
        test_file.write_bytes(b"hello")

        exc = ArtifactaAPIError(
            "quota_exceeded",
            "Presigned uploads require a Pro plan. Upgrade at https://app.artifacta.io/dashboard/usage?intent=upgrade",
            403,
        )
        with patch("artifacta.cli.api_request", side_effect=exc):
            result = runner.invoke(main, ["push", str(test_file), "--presigned", "--human"])

        assert result.exit_code == 1
        assert "Presigned uploads require a Pro plan" in result.output

    def test_free_tier_quota_exceeded_prints_upgrade_url(self, runner, mock_key, tmp_path):
        """AF_STRIPE-P1.4: CLI surfaces upgrade_url on a line after the error."""
        test_file = tmp_path / "test.bin"
        test_file.write_bytes(b"hello")

        exc = ArtifactaAPIError(
            "quota_exceeded",
            "Presigned uploads require a Pro plan.",
            403,
            upgrade_url="https://app.artifacta.io/dashboard/usage?intent=upgrade",
        )
        with patch("artifacta.cli.api_request", side_effect=exc):
            result = runner.invoke(
                main, ["push", str(test_file), "--presigned", "--human"]
            )

        assert result.exit_code == 1
        # Error message and the upgrade_url should both appear, on separate
        # lines, with upgrade_url after the ✗ line.
        assert "✗ Presigned uploads require a Pro plan." in result.output
        assert (
            "Upgrade at: https://app.artifacta.io/dashboard/usage?intent=upgrade"
            in result.output
        )
        err_idx = result.output.index("✗ Presigned uploads")
        url_idx = result.output.index(
            "Upgrade at: https://app.artifacta.io/dashboard/usage?intent=upgrade"
        )
        assert url_idx > err_idx

    def test_free_tier_quota_json_error_includes_upgrade_url(
        self, runner, mock_key, tmp_path
    ):
        """AC-1.4.3 / T-1.4.2: `--json` emits JSON error body on stdout,
        preserving `upgrade_url` so scripts/agents can parse it."""
        test_file = tmp_path / "test.bin"
        test_file.write_bytes(b"hello")

        exc = ArtifactaAPIError(
            "quota_exceeded",
            "Presigned uploads require a Pro plan.",
            403,
            upgrade_url="https://app.artifacta.io/dashboard/usage?intent=upgrade",
        )
        with patch("artifacta.cli.api_request", side_effect=exc):
            result = runner.invoke(
                main, ["push", str(test_file), "--presigned", "--json"]
            )

        assert result.exit_code == 1
        # Click's CliRunner merges stdout and stderr by default; the JSON
        # line lives somewhere in result.output. Parse every line and find
        # the one that decodes to our error body.
        parsed = None
        for line in result.output.splitlines():
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                parsed = json.loads(line)
                break
            except json.JSONDecodeError:
                continue
        assert parsed is not None, f"No JSON line in output: {result.output!r}"
        assert parsed["error"]["code"] == "quota_exceeded"
        assert parsed["error"]["status"] == 403
        assert (
            parsed["error"]["upgrade_url"]
            == "https://app.artifacta.io/dashboard/usage?intent=upgrade"
        )


class TestPresignedProTier:

    def test_presigned_success(self, runner, mock_key, tmp_path):
        test_file = tmp_path / "test.bin"
        test_file.write_bytes(b"hello")

        def mock_api_request(method, path, **kwargs):
            if path == "/v1/artifacts/upload-url":
                return UPLOAD_URL_RESPONSE
            if path.endswith("/complete"):
                return COMPLETE_RESPONSE
            raise AssertionError(f"Unexpected call: {method} {path}")

        with patch("artifacta.cli.api_request", side_effect=mock_api_request), \
             patch("artifacta.cli.upload_bytes_to_presigned") as mock_upload:
            result = runner.invoke(main, ["push", str(test_file), "--presigned", "--human"])

        assert result.exit_code == 0
        assert "art_tEsT1234567890" in result.output
        mock_upload.assert_called_once()

    def test_presigned_json_output(self, runner, mock_key, tmp_path):
        test_file = tmp_path / "test.bin"
        test_file.write_bytes(b"hello")

        def mock_api_request(method, path, **kwargs):
            if path == "/v1/artifacts/upload-url":
                return UPLOAD_URL_RESPONSE
            if path.endswith("/complete"):
                return COMPLETE_RESPONSE
            raise AssertionError(f"Unexpected call: {method} {path}")

        with patch("artifacta.cli.api_request", side_effect=mock_api_request), \
             patch("artifacta.cli.upload_bytes_to_presigned"):
            result = runner.invoke(main, ["push", str(test_file), "--presigned", "--json"])

        data = json.loads(result.output.strip())
        assert data["artifact_id"] == "art_tEsT1234567890"

    def test_presigned_passes_session_and_ttl(self, runner, mock_key, tmp_path):
        test_file = tmp_path / "test.bin"
        test_file.write_bytes(b"hello")

        captured_body = {}

        def mock_api_request(method, path, **kwargs):
            if path == "/v1/artifacts/upload-url":
                captured_body.update(kwargs.get("json", {}))
                return UPLOAD_URL_RESPONSE
            if path.endswith("/complete"):
                return COMPLETE_RESPONSE
            raise AssertionError(f"Unexpected call: {method} {path}")

        with patch("artifacta.cli.api_request", side_effect=mock_api_request), \
             patch("artifacta.cli.upload_bytes_to_presigned"):
            result = runner.invoke(main, [
                "push", str(test_file), "--presigned",
                "--session", "ses_test123",
                "--ttl", "90d",
            ])

        assert result.exit_code == 0
        assert captured_body["session_id"] == "ses_test123"
        assert captured_body["ttl"] == "90d"


class TestPresignedImport:

    def test_upload_bytes_to_presigned_importable(self):
        from artifacta.client import upload_bytes_to_presigned
        assert callable(upload_bytes_to_presigned)
