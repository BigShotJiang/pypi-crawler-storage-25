CAPABILITY = "ditto"
