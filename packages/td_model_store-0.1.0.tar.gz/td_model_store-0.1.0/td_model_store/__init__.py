"""td-model-store: Store and load ML models in Treasure Data Plazma."""

from .model_store import save_model
from .model_loader import load_model

__version__ = "0.1.0"
__all__ = ["save_model", "load_model"]
