"""Load ML models from Treasure Data Plazma via pytd."""

import base64
import logging
import os
import tempfile

import pandas as pd
import pytd

from .model_store import _resolve_apikey

logger = logging.getLogger(__name__)


def _reconstruct_model(model_bytes, model_type, model_format):
    """Reconstruct a model from bytes."""
    suffix = f".{model_format}"

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
        f.write(model_bytes)
        tmp = f.name

    if model_type == "xgboost":
        import xgboost as xgb
        model = xgb.XGBClassifier()
        model.load_model(tmp)

    elif model_type == "lightgbm":
        import lightgbm as lgb
        model = lgb.Booster(model_file=tmp)

    elif model_type == "catboost":
        from catboost import CatBoost
        model = CatBoost()
        model.load_model(tmp)

    else:
        os.unlink(tmp)
        raise ValueError(f"Unsupported model type: {model_type}")

    os.unlink(tmp)
    return model


def load_model(
    database,
    table="ml_model_store",
    model_name=None,
    session_id=None,
    apikey=None,
    endpoint="https://api.treasuredata.com",
):
    """Load an ML model from a Treasure Data table.

    Parameters
    ----------
    database : str
        Source TD database name.
    table : str, default "ml_model_store"
        Source table name.
    model_name : str, optional
        Filter by model name. If not provided, loads the latest session.
    session_id : int, optional
        Load a specific session. If not provided, loads the max session_id
        (optionally filtered by model_name).
    apikey : str, optional
        TD API key. Falls back to TD_API_KEY or TDX_API_KEY* env vars.
    endpoint : str, default "https://api.treasuredata.com"
        TD API endpoint.

    Returns
    -------
    model
        The reconstructed ML model (XGBoost, LightGBM, or CatBoost).
    """
    apikey = _resolve_apikey(apikey)
    client = pytd.Client(apikey=apikey, endpoint=endpoint, database=database)

    # Build query to find the right session
    if session_id is not None:
        where = f"session_id = {session_id}"
    elif model_name is not None:
        where = (
            f"model_name = '{model_name}' AND session_id = ("
            f"SELECT MAX(session_id) FROM {table} WHERE model_name = '{model_name}')"
        )
    else:
        where = f"session_id = (SELECT MAX(session_id) FROM {table})"

    query = f"""
    SELECT session_id, model_name, model_type, model_format,
           chunk_index, total_chunks, chunk_data
    FROM {table}
    WHERE {where}
    ORDER BY chunk_index
    """

    result = client.query(query)
    df = pd.DataFrame(**result)

    if df.empty:
        raise ValueError(
            f"No model found in {database}.{table} "
            f"(session_id={session_id}, model_name={model_name})"
        )

    # Extract metadata from first row
    model_type = df["model_type"].iloc[0]
    model_format = df["model_format"].iloc[0]
    model_name_loaded = df["model_name"].iloc[0]
    session_id_loaded = df["session_id"].iloc[0]
    total_chunks = int(df["total_chunks"].iloc[0])

    # Reassemble
    df = df.sort_values("chunk_index").reset_index(drop=True)
    if len(df) != total_chunks:
        raise ValueError(
            f"Expected {total_chunks} chunks, got {len(df)}. Data may be corrupted."
        )

    model_b64 = "".join(df["chunk_data"].tolist())
    model_bytes = base64.b64decode(model_b64)

    # Reconstruct
    model = _reconstruct_model(model_bytes, model_type, model_format)

    logger.info(
        "Loaded model '%s' (type=%s) from %s.%s | session_id=%s | chunks=%d | size=%d bytes",
        model_name_loaded, model_type, database, table, session_id_loaded, total_chunks, len(model_bytes)
    )
    return model
