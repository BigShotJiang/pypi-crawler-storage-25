"""Save ML models to Treasure Data Plazma via pytd."""

import base64
import logging
import math
import tempfile
import time
import os
from datetime import datetime, timezone

import pandas as pd
import pytd

logger = logging.getLogger(__name__)

# bulk_import CSV field limit is 131072 chars (128 KB)
MAX_CHUNK_SIZE = 130_000

DEFAULT_MODEL_NAMES = {
    "xgboost": "xgboost_model",
    "lightgbm": "lightgbm_model",
    "catboost": "catboost_model",
}


def _detect_model_type(model):
    """Detect model type from the model object."""
    cls_name = type(model).__module__ + "." + type(model).__name__

    if "xgboost" in cls_name.lower():
        return "xgboost"
    elif "lightgbm" in cls_name.lower():
        return "lightgbm"
    elif "catboost" in cls_name.lower():
        return "catboost"
    else:
        raise ValueError(
            f"Unsupported model type: {type(model).__name__}. "
            "Supported: XGBoost, LightGBM, CatBoost."
        )


def _serialize_model(model, model_type):
    """Serialize a model to bytes."""
    if model_type == "xgboost":
        with tempfile.NamedTemporaryFile(suffix=".ubj", delete=False) as f:
            model.save_model(f.name)
            tmp = f.name
        with open(tmp, "rb") as f:
            data = f.read()
        os.unlink(tmp)
        return data, "ubj"

    elif model_type == "lightgbm":
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
            tmp = f.name
        model.booster_.save_model(tmp)
        with open(tmp, "rb") as f:
            data = f.read()
        os.unlink(tmp)
        return data, "txt"

    elif model_type == "catboost":
        with tempfile.NamedTemporaryFile(suffix=".cbm", delete=False) as f:
            tmp = f.name
        model.save_model(tmp)
        with open(tmp, "rb") as f:
            data = f.read()
        os.unlink(tmp)
        return data, "cbm"


def save_model(
    model,
    database,
    table="ml_model_store",
    model_name=None,
    session_id=None,
    apikey=None,
    endpoint="https://api.treasuredata.com",
    chunk_size=MAX_CHUNK_SIZE,
):
    """Save an ML model to a Treasure Data table.

    Parameters
    ----------
    model : XGBClassifier/XGBRegressor, LGBMClassifier/LGBMRegressor,
            CatBoostClassifier/CatBoostRegressor
        Trained model to store.
    database : str
        Target TD database name.
    table : str, default "ml_model_store"
        Target table name.
    model_name : str, optional
        Name tag for the model. Defaults to e.g. "xgboost_model".
    session_id : int, optional
        Unique session identifier. Defaults to current unix timestamp.
    apikey : str, optional
        TD API key. Falls back to TD_API_KEY or TDX_API_KEY* env vars.
    endpoint : str, default "https://api.treasuredata.com"
        TD API endpoint.
    chunk_size : int, default 130000
        Max chars per chunk (must be < 131072).

    Returns
    -------
    dict
        Metadata: session_id, model_name, model_type, num_chunks, size_bytes.
    """
    # Resolve API key
    apikey = _resolve_apikey(apikey)

    # Detect model type
    model_type = _detect_model_type(model)

    # Defaults
    if model_name is None:
        model_name = DEFAULT_MODEL_NAMES[model_type]
    if session_id is None:
        session_id = int(time.time())

    # Serialize
    model_bytes, fmt = _serialize_model(model, model_type)
    model_b64 = base64.b64encode(model_bytes).decode("utf-8")

    # Chunk
    total_size = len(model_b64)
    num_chunks = math.ceil(total_size / chunk_size)

    now_ts = int(time.time())
    rows = []
    for i in range(num_chunks):
        chunk_data = model_b64[i * chunk_size : (i + 1) * chunk_size]
        rows.append({
            "time": now_ts,
            "session_id": session_id,
            "model_name": model_name,
            "model_type": model_type,
            "model_format": fmt,
            "chunk_index": i,
            "total_chunks": num_chunks,
            "chunk_data": chunk_data,
            "created_at": datetime.now(timezone.utc).isoformat(),
        })

    df = pd.DataFrame(rows)

    # Upload
    client = pytd.Client(apikey=apikey, endpoint=endpoint, database=database)
    client.load_table_from_dataframe(
        df,
        destination=f"{database}.{table}",
        writer="bulk_import",
        if_exists="append",
    )

    meta = {
        "session_id": session_id,
        "model_name": model_name,
        "model_type": model_type,
        "model_format": fmt,
        "num_chunks": num_chunks,
        "size_bytes": len(model_bytes),
    }
    logger.info(
        "Saved model '%s' (type=%s) to %s.%s | session_id=%s | chunks=%d | size=%d bytes",
        model_name, model_type, database, table, session_id, num_chunks, len(model_bytes)
    )
    return meta


def _resolve_apikey(apikey):
    """Resolve TD API key from arg, env vars."""
    if apikey:
        return apikey
    if os.environ.get("TD_API_KEY"):
        return os.environ["TD_API_KEY"]
    # Fallback: TDX_API_KEY__* (Treasure Studio)
    for k, v in os.environ.items():
        if k.startswith("TDX_API_KEY"):
            return v
    raise ValueError(
        "No API key provided. Pass apikey= or set TD_API_KEY env var."
    )
