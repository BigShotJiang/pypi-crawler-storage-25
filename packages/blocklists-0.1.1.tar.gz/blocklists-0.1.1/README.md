# blocklists

Python package with swearlists and general blocklists for text filtering.