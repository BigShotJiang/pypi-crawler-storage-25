swearlist = [
    "fuck","fucking","fucker","motherfucker","shit","shithead","crap",
    "damn","bitch","bastard","asshole","ass","arse","cock","cocksucker",
    "dick","dickhead","pussy","twat","slut","whore","faggot","nigger",
    "nigga","bollocks","bugger","wanker","prick","douche","douchebag",
    "clit","dildo","tit","tits","piss","pissed","shitface","shitfaced",
    "jackass","moron","idiot","dumbass","jerk","retard","skank","slutty",
    "bitchy","arsehole","cockhead","pisshead","bollockses","twats",
    "shitstorm","shitbag","cunt","motherfucking","asshat","dickwad",
    "dickbag","cum","cumshot","cumdumpster","spastic","numbnuts",
    "shitbagger","fuckface","fuckwad","ballbag","twatwaffle","shitlicker",
    "assclown","cockwomble","arsewipe","pissflaps","titfuck","dickface",
    "fucknut","shitlicking","cumguzzler","knobhead","wankstain","prickface",
    "dickhead","cocksplat","shitdick","arsehole","twatface","fuckinghell",
    "dickweed","cuntface","pisshead","fudgepacker","dingleberry","tosser",
    "bollockshead","dicklicker","twatlicker","shitstain","arsebandit",
    "pisscunt","cumslut","shitkicker","assmunch","shitweasel","fartknocker",
    "shite","shitter","poopface","craphead","arseface"
]
def detectswear(msg):
    return any(swear in msg for swear in swearlist)