import { fileURLToPath, URL } from "node:url";

import { defineConfig } from "vite";
// @ts-ignore
import vue from "@vitejs/plugin-vue";
// @ts-ignore
import vueJsx from "@vitejs/plugin-vue-jsx";
import { name, version } from "./package.json";
import { execSync } from "child_process";
import { viteStaticCopy } from "vite-plugin-static-copy";
import { dirname, join } from "path";
import { version as pyodideVersion } from "pyodide";

let wantsSmallBuild = process.env.YACV_SMALL_BUILD == "true";

// Helper to safely get git info
function getGitInfo(command: string, fallback: string): string {
  try {
    return execSync(command, { stdio: "pipe" }).toString().trim();
  } catch (e) {
    return fallback;
  }
}

// https://vitejs.dev/config/
export default defineConfig({
  base: "",
  plugins: [
    vue({
      template: {
        compilerOptions: {
          isCustomElement: (tag: string) => tag == "model-viewer",
        },
      },
    }),
    vueJsx(),
    viteStaticCopyPyodide(),
  ],
  optimizeDeps: { exclude: ["pyodide"] },
  resolve: {
    alias: {
      // @ts-ignore
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  build: {
    assetsDir: ".", // Support deploying to a subdirectory using relative URLs
    cssCodeSplit: false, // Small enough to inline
    chunkSizeWarningLimit: 1024, // KB. Three.js is big. Draco is even bigger but not likely to be used.
    sourcemap: true, // For debugging production
    rollupOptions: {
      external: wantsSmallBuild
        ? [
            // Exclude some large optional dependencies if small build is requested (for embedding in python package)
            "pyodide",
            /.*\/pyodide-worker.*/,
            "monaco-editor",
            /monaco-editor\/.*/,
            "@guolao/vue-monaco-editor",
            /three\/examples\/jsm\/libs\/draco\/draco_(en|de)coder\.js/,
          ]
        : [],
    },
  },
  worker: {
    format: "es", // Use ES modules for workers (IIFE is not supported with code-splitting)
  },
  define: {
    __APP_NAME__: JSON.stringify(name),
    __APP_VERSION__: JSON.stringify(version),
    __APP_GIT_SHA__: JSON.stringify(getGitInfo("git rev-parse HEAD", "unknown")),
    __APP_GIT_DIRTY__: JSON.stringify(getGitInfo("git diff --quiet || echo dirty", "")),
    __YACV_SMALL_BUILD__: JSON.stringify(wantsSmallBuild),
  },
});

function viteStaticCopyPyodide() {
  // @ts-ignore
  const pyodideDir = dirname(fileURLToPath(import.meta.resolve("pyodide")));
  const pyodideInc = [];
  for (let glob of ["**", "!**/*.{md,html}", "!**/*.d.ts", "!**/*.whl", "!**/node_modules"]) {
    pyodideInc.push(join(pyodideDir, glob));
  }
  return viteStaticCopy({
    targets: wantsSmallBuild
      ? []
      : [
          {
            src: pyodideInc,
            dest: "pyodide-v" + pyodideVersion, // It would be better to use hashed names instead of folder...
          },
        ],
  });
}
