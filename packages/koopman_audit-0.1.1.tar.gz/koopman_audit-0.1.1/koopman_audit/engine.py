"""
EDMD Engine — Core Koopman operator computation for compliance verification.

Mathematical specification:
- Hankel delay embedding: H[i,j] = x(j + (i-1)*τ)
- Koopman regression: K = X' @ X^T @ (X @ X^T + λI)^{-1}
- Rank gate: G(K) = 1[rank(K) >= r*]
"""

import numpy as np
from scipy.linalg import svd, eigvals
from dataclasses import dataclass
from typing import Optional, Dict, List
import hashlib
import json
import time


@dataclass
class EDMDConfig:
    """Configuration for EDMD pipeline."""
    d: int = 5           # embedding dimension
    tau: int = 1         # delay lag
    min_tokens: int = 25
    lambda_prior: float = 0.88
    lambda_reg: Optional[float] = None  # None = use calibrated prior
    rank_threshold: int = 5  # r* = full rank required


@dataclass
class GateResult:
    """Result of compliance gate computation."""
    pass_gate: bool
    rank_achieved: int
    rank_required: int
    lambda_hat: float
    tail_gap: float
    sigma_min: float
    K: np.ndarray
    eigenvalues: np.ndarray
    audit_hash: str
    diagnostics: Dict


def build_hankel(x: np.ndarray, d: int, tau: int = 1) -> np.ndarray:
    """
    Construct Hankel delay-embedding matrix.
    
    H[i,j] = x(j + i*tau) for i in [0, d-1], j in [0, m-1]
    
    Args:
        x: Input signal (token-level entropy or logits)
        d: Embedding dimension (rows)
        tau: Delay lag
        
    Returns:
        H: Hankel matrix of shape (d, m)
    """
    T = len(x)
    m = T - (d - 1) * tau
    if m < 1:
        raise ValueError(
            f"Sequence too short: T={T}, need T >= {d + (d-1)*(tau-1)}"
        )
    
    H = np.zeros((d, m))
    for i in range(d):
        H[i, :] = x[i * tau: i * tau + m]
    
    return H


def lift_observables(H: np.ndarray) -> np.ndarray:
    """
    Apply observable dictionary lift.
    
    Current implementation: linear identity lift.
    Extendable to: polynomial, RBF, or learned dictionaries.
    
    Args:
        H: Hankel matrix (d, m)
        
    Returns:
        Psi: Lifted observables (d, m) for linear case
    """
    # Linear lift: identity
    # Future: Add polynomial cross-terms, RBF centers
    return H


def compute_koopman(X: np.ndarray, Xp: np.ndarray, lam: float) -> np.ndarray:
    """
    Tikhonov-regularized Koopman operator regression.
    
    K_λ = X' @ X^T @ (X @ X^T + λI)^{-1}
    
    Args:
        X: Snapshot matrix at time t (N x m)
        Xp: Snapshot matrix at time t+1 (N x m)
        lam: Regularization parameter
        
    Returns:
        K: Koopman operator (N x N)
    """
    G = X @ X.T  # Gram matrix
    K = Xp @ X.T @ np.linalg.inv(G + lam * np.eye(G.shape[0]))
    return K


def compute_gate(x: np.ndarray, config: EDMDConfig) -> GateResult:
    """
    Full EDMD pipeline: signal → compliance gate decision.
    
    Args:
        x: Input signal (entropy trace or logit sequence)
        config: EDMD configuration
        
    Returns:
        GateResult with compliance decision and diagnostics
    """
    # Validate min_tokens constraint
    if len(x) < config.min_tokens:
        raise ValueError(
            f"min_tokens={config.min_tokens} not met: got {len(x)}"
        )
    
    # Step 1: Delay embedding
    H = build_hankel(x, config.d, config.tau)
    
    # Step 2: Observable lift
    Psi = lift_observables(H)
    
    # Step 3: Snapshot matrices
    X = Psi[:, :-1]   # X_t
    Xp = Psi[:, 1:]   # X_{t+1}
    
    # Step 4: Koopman regression
    lam = config.lambda_reg if config.lambda_reg is not None else config.lambda_prior
    K = compute_koopman(X, Xp, lam)
    
    # Step 5: Singular value decomposition
    sv = svd(K, compute_uv=False)
    rank_achieved = int(np.sum(sv > 1e-10))
    
    # Tail gap: Δ = σ_{r*} - σ_{r*+1}
    if len(sv) > config.rank_threshold:
        tail_gap = float(sv[config.rank_threshold - 1] - sv[config.rank_threshold])
    else:
        tail_gap = float(sv[-1]) if len(sv) > 0 else 0.0
    
    sigma_min = float(sv[rank_achieved - 1]) if rank_achieved > 0 else 0.0
    
    # Step 6: Eigendecomposition
    eigs = eigvals(K)
    
    # Step 7: Compliance gate decision
    # Pass if: rank >= r* (full rank achieved)
    pass_gate = rank_achieved >= config.rank_threshold
    
    # Step 8: Deterministic audit hash
    payload = {
        "rank": rank_achieved,
        "lambda_used": round(float(lam), 6),
        "tail_gap": round(tail_gap, 6),
        "sigma_min": round(sigma_min, 6),
        "timestamp": time.time(),
    }
    audit_hash = "sha256:" + hashlib.sha256(
        json.dumps(payload, sort_keys=True).encode()
    ).hexdigest()
    
    diagnostics = {
        "matrix_shape": list(K.shape),
        "singular_values": sv.tolist(),
        "condition_number": float(np.linalg.cond(K)),
        "lambda_reg": lam,
    }
    
    return GateResult(
        pass_gate=pass_gate,
        rank_achieved=rank_achieved,
        rank_required=config.rank_threshold,
        lambda_hat=float(lam),
        tail_gap=tail_gap,
        sigma_min=sigma_min,
        K=K,
        eigenvalues=eigs,
        audit_hash=audit_hash,
        diagnostics=diagnostics,
    )


def aggregate_layers(
    layer_signals: Dict[int, np.ndarray],
    config: EDMDConfig,
    weight_by_frobenius: bool = True
) -> Dict:
    """
    Multi-layer Koopman aggregation.
    
    R_weighted = Σ(w_l * rank_l) / Σ(w_l * d)
    
    Args:
        layer_signals: Dict mapping layer index to signal array
        config: EDMD configuration
        weight_by_frobenius: Weight by Frobenius norm of Hankel
        
    Returns:
        Aggregation results with per-layer and combined metrics
    """
    results = {}
    weights = {}
    
    for layer_idx, signal in layer_signals.items():
        try:
            gate = compute_gate(signal, config)
            results[layer_idx] = gate
            
            # Weight computation
            if weight_by_frobenius:
                H = build_hankel(signal, config.d, config.tau)
                weights[layer_idx] = float(np.linalg.norm(H, 'fro'))
            else:
                weights[layer_idx] = 1.0
        except ValueError as e:
            # Insufficient tokens for this layer
            results[layer_idx] = None
            weights[layer_idx] = 0.0
    
    # Filter valid results
    valid_layers = {l: r for l, r in results.items() if r is not None}
    
    if not valid_layers:
        return {
            "per_layer": {},
            "aggregated_rank_score": 0.0,
            "all_pass": False,
            "error": "No valid layers",
        }
    
    # Weighted aggregation
    total_w = sum(weights[l] for l in valid_layers)
    R_weighted = sum(
        weights[l] * (valid_layers[l].rank_achieved / config.d)
        for l in valid_layers
    ) / total_w if total_w > 0 else 0.0
    
    return {
        "per_layer": {
            l: {
                "rank": r.rank_achieved,
                "lambda_hat": r.lambda_hat,
                "tail_gap": r.tail_gap,
                "pass": r.pass_gate,
                "audit_hash": r.audit_hash,
            }
            for l, r in valid_layers.items()
        },
        "aggregated_rank_score": round(R_weighted, 6),
        "all_pass": all(r.pass_gate for r in valid_layers.values()),
        "layer_weights": {l: round(w, 4) for l, w in weights.items()},
    }


def calibrate_lambda(
    signals: List[np.ndarray],
    d: int = 5,
    tau: int = 1,
    lambda_bounds: tuple = (0.1, 5.0),
) -> Dict:
    """
    Calibrate optimal lambda that maximizes full-rank consistency.
    
    Args:
        signals: List of training signals
        d: Embedding dimension
        tau: Delay lag
        lambda_bounds: (min, max) for lambda search
        
    Returns:
        Calibration results with optimal lambda
    """
    from scipy.optimize import minimize_scalar
    
    def objective(lam):
        """Maximize full-rank proportion (minimize negative)."""
        ranks = []
        for x in signals:
            try:
                H = build_hankel(x, d, tau)
                X = H[:, :-1]
                Xp = H[:, 1:]
                K = compute_koopman(X, Xp, lam)
                sv = svd(K, compute_uv=False)
                ranks.append(np.sum(sv > 1e-10))
            except ValueError:
                ranks.append(0)
        
        # Return negative (we want to maximize)
        return -np.mean(np.array(ranks) == d)
    
    result = minimize_scalar(
        objective,
        bounds=lambda_bounds,
        method='bounded',
        options={'xatol': 1e-4}
    )
    
    # Evaluate at optimal lambda
    final_ranks = []
    for x in signals:
        try:
            H = build_hankel(x, d, tau)
            X = H[:, :-1]
            Xp = H[:, 1:]
            K = compute_koopman(X, Xp, result.x)
            sv = svd(K, compute_uv=False)
            final_ranks.append(int(np.sum(sv > 1e-10)))
        except ValueError:
            final_ranks.append(0)
    
    rank_dist = {}
    for r in set(final_ranks):
        rank_dist[int(r)] = int(np.sum(np.array(final_ranks) == r))
    
    return {
        "lambda_hat": round(result.x, 6),
        "full_rank_rate": round(np.mean(np.array(final_ranks) == d), 4),
        "n_trials": len(signals),
        "rank_distribution": rank_dist,
    }
