"""
daemon.py — Koopman Audit Gate Daemon
systemd-compatible service for continuous compliance verification
"""

import argparse
import asyncio
import json
import logging
import signal
import sys
from pathlib import Path
from typing import Optional

from .engine import EDMDConfig, compute_gate
from .proof_ledger import ProofLedger


class KoopmanDaemon:
    """systemd-compatible daemon for Koopman compliance gate."""
    
    def __init__(
        self,
        config_path: Optional[Path] = None,
        ledger_path: Optional[Path] = None,
        log_level: str = "INFO"
    ):
        self.config = self._load_config(config_path)
        self.ledger = ProofLedger(ledger_path) if ledger_path else ProofLedger()
        self.logger = self._setup_logging(log_level)
        self.running = False
        
    def _load_config(self, config_path: Optional[Path]) -> EDMDConfig:
        """Load configuration from file or use defaults."""
        if config_path and config_path.exists():
            import configparser
            parser = configparser.ConfigParser()
            parser.read(config_path)
            
            gate_section = parser.get("gate", {})
            return EDMDConfig(
                d=gate_section.getint("d", 5),
                tau=gate_section.getint("tau", 1),
                min_tokens=gate_section.getint("min_tokens", 25),
                lambda_prior=gate_section.getfloat("lambda_prior", 0.88),
                lambda_reg=gate_section.getfloat("lambda_reg", None)
            )
        return EDMDConfig()
    
    def _setup_logging(self, log_level: str) -> logging.Logger:
        """Configure systemd-compatible logging."""
        logger = logging.getLogger("koopman-audit")
        logger.setLevel(getattr(logging, log_level.upper()))
        
        # Systemd journal format
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "%(name)s[%(process)d]: %(levelname)s %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    async def run_gate(self, signal_data: list[float]) -> dict:
        """Execute compliance gate on signal data."""
        try:
            result = compute_gate(signal_data, self.config)
            
            # Append to ledger
            entry_id = self.ledger.append(
                session_id=f"daemon_{asyncio.get_event_loop().time()}",
                gate_result={
                    "pass": result.pass_gate,
                    "rank": result.rank_achieved,
                    "target": result.rank_target,
                    "eigenvalues": result.eigenvalues.tolist() if hasattr(result.eigenvalues, 'tolist') else list(result.eigenvalues),
                    "tail_gap": result.tail_gap
                },
                model_info={"source": "daemon", "version": "0.1.0"}
            )
            
            self.logger.info(
                f"Gate result: rank={result.rank_achieved}/{result.rank_target}, "
                f"pass={result.pass_gate}, entry={entry_id[:8]}..."
            )
            
            return {
                "pass": result.pass_gate,
                "rank": result.rank_achieved,
                "entry_id": entry_id
            }
            
        except Exception as e:
            self.logger.error(f"Gate execution failed: {e}")
            raise
    
    async def run(self):
        """Main daemon loop."""
        self.running = True
        self.logger.info("Koopman Audit Daemon started")
        
        # Setup signal handlers for systemd
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, self._signal_handler)
        
        # Main loop - process gates on demand or schedule
        while self.running:
            try:
                # Example: run gate on test signal
                # In production, this would receive data from socket/pipe/queue
                test_signal = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
                await self.run_gate(test_signal)
                
                # Sleep interval (configurable)
                await asyncio.sleep(60)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Daemon loop error: {e}")
                await asyncio.sleep(5)
        
        self.logger.info("Koopman Audit Daemon stopped")
    
    def _signal_handler(self):
        """Handle shutdown signals from systemd."""
        self.logger.info("Received shutdown signal")
        self.running = False


def main():
    parser = argparse.ArgumentParser(description="Koopman Audit Gate Daemon")
    parser.add_argument(
        "--config", "-c",
        type=Path,
        help="Path to configuration file"
    )
    parser.add_argument(
        "--ledger", "-l",
        type=Path,
        help="Path to proof ledger file"
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Logging level"
    )
    
    args = parser.parse_args()
    
    daemon = KoopmanDaemon(
        config_path=args.config,
        ledger_path=args.ledger,
        log_level=args.log_level
    )
    
    try:
        asyncio.run(daemon.run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
