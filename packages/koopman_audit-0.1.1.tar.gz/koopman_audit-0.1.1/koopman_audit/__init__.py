"""
Koopman Audit — Mathematically verifiable audit layer for LLM inference.

The first Koopman operator-based compliance verification system for AI.
Provides real-time behavioral certification via Extended Dynamic Mode 
Decomposition (EDMD) with cryptographically hash-chained audit trails.

Validated on SmolLM2-360M (N=9 trials, 100% full rank):
- Benign: λ̂ = 0.8425 ± 0.0375
- Hallucination: λ̂ = 0.8268 ± 0.0143  
- Jailbreak: λ̂ = 0.8752 ± 0.0284

Reference: P-001 Provisional Patent, April 12, 2026
"""

from .engine import (
    EDMDConfig,
    build_hankel,
    lift_observables,
    compute_koopman,
    compute_gate,
    aggregate_layers,
    GateResult,
    calibrate_lambda,
)

from .proof_ledger import (
    ProofLedger,
    LedgerEntry,
)

__version__ = "0.1.0"
__all__ = [
    "EDMDConfig",
    "build_hankel",
    "lift_observables", 
    "compute_koopman",
    "compute_gate",
    "aggregate_layers",
    "GateResult",
    "calibrate_lambda",
    "ProofLedger",
    "LedgerEntry",
]
