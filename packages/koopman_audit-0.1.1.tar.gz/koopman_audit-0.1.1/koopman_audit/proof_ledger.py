"""
Proof Ledger — Append-Only Audit Log for Compliance Verification

Hash-chained ledger with NIST AI RMF export capability.
"""

import json
import hashlib
import time
import uuid
from pathlib import Path
from typing import Optional, Dict, List, Any, Tuple
from dataclasses import dataclass


@dataclass
class LedgerEntry:
    """Single entry in the proof ledger."""
    entry_id: str
    session_id: str
    timestamp_iso: str
    timestamp_unix: float
    model_id: str
    prompt_hash: str
    category: str
    gate_result: Dict
    metadata: Dict
    prev_hash: str
    entry_hash: str


class ProofLedger:
    """
    Append-only, hash-chained audit log for behavioral verification.
    
    Each entry links to the previous via prev_hash (blockchain-style).
    Provides tamper detection and NIST AI RMF compliance reporting.
    """
    
    def __init__(self, path: Path = Path("./proof_ledger.jsonl")):
        self.path = Path(path)
        self._prev_hash = self._load_tail_hash()
    
    def _load_tail_hash(self) -> str:
        """Load hash of last entry (or GENESIS if empty)."""
        if not self.path.exists():
            return "GENESIS"
        
        with open(self.path, "rb") as f:
            lines = f.read().splitlines()
        
        if not lines:
            return "GENESIS"
        
        try:
            last = json.loads(lines[-1])
            return last.get("entry_hash", "GENESIS")
        except json.JSONDecodeError:
            return "GENESIS"
    
    def append(
        self,
        session_id: str,
        gate_result: Dict,
        model_id: str,
        prompt_hash: str,
        category: str,
        metadata: Optional[Dict] = None
    ) -> str:
        """
        Append new entry to ledger.
        
        Args:
            session_id: UUID for this inference session
            gate_result: Output from compute_gate()
            model_id: Model identifier (e.g., "gemma-4-26b")
            prompt_hash: SHA256 hash of input prompt
            category: Behavioral category (benign/hallucination/jailbreak)
            metadata: Optional additional metadata
            
        Returns:
            entry_id: UUID of created entry
        """
        entry = {
            "entry_id": str(uuid.uuid4()),
            "session_id": session_id,
            "timestamp_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "timestamp_unix": time.time(),
            "model_id": model_id,
            "prompt_hash": prompt_hash,
            "category": category,
            "gate_result": gate_result,
            "metadata": metadata or {},
            "prev_hash": self._prev_hash,
        }
        
        # Deterministic entry hash (excluding the hash itself)
        canonical = json.dumps(entry, sort_keys=True, ensure_ascii=True)
        entry["entry_hash"] = "sha256:" + hashlib.sha256(
            canonical.encode("utf-8")
        ).hexdigest()
        
        # Append to ledger
        with open(self.path, "a") as f:
            f.write(json.dumps(entry) + "\n")
        
        self._prev_hash = entry["entry_hash"]
        return entry["entry_id"]
    
    def verify_chain(self) -> Tuple[bool, List[str]]:
        """
        Verify hash chain integrity.
        
        Returns:
            (is_valid, error_messages)
        """
        if not self.path.exists():
            return True, []
        
        errors = []
        prev = "GENESIS"
        
        with open(self.path) as f:
            for i, line in enumerate(f):
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError as e:
                    errors.append(f"Line {i}: Invalid JSON - {e}")
                    continue
                
                stored_hash = entry.pop("entry_hash", None)
                if not stored_hash:
                    errors.append(f"Entry {i}: Missing entry_hash")
                    continue
                
                # Recompute hash
                canonical = json.dumps(entry, sort_keys=True, ensure_ascii=True)
                computed = "sha256:" + hashlib.sha256(
                    canonical.encode("utf-8")
                ).hexdigest()
                
                # Verify chain linkage
                if entry.get("prev_hash") != prev:
                    errors.append(f"Entry {i}: prev_hash mismatch (tampering detected)")
                
                # Verify hash integrity
                if stored_hash != computed:
                    errors.append(f"Entry {i}: entry_hash mismatch (data tampered)")
                
                prev = stored_hash
        
        return (len(errors) == 0, errors)
    
    def get_entries(
        self,
        model_id: Optional[str] = None,
        category: Optional[str] = None,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> List[Dict]:
        """
        Query ledger entries with filters.
        
        Args:
            model_id: Filter by model
            category: Filter by behavioral category
            start_time: Unix timestamp (inclusive)
            end_time: Unix timestamp (inclusive)
            
        Returns:
            List of matching entries
        """
        if not self.path.exists():
            return []
        
        results = []
        with open(self.path) as f:
            for line in f:
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                
                # Apply filters
                if model_id and entry.get("model_id") != model_id:
                    continue
                if category and entry.get("category") != category:
                    continue
                if start_time and entry.get("timestamp_unix", 0) < start_time:
                    continue
                if end_time and entry.get("timestamp_unix", 0) > end_time:
                    continue
                
                results.append(entry)
        
        return results
    
    def export_nist_rmf_report(self) -> Dict:
        """
        Export ledger as NIST AI RMF MAP/MEASURE/MANAGE evidence package.
        
        Returns:
            NIST RMF compliant report dictionary
        """
        entries = self.get_entries()
        
        if not entries:
            return {
                "nist_rmf_function": "MEASURE",
                "subcategory": "MS-2.5 | MS-2.6",
                "total_inferences": 0,
                "compliant_inferences": 0,
                "compliance_rate": 0.0,
                "rank_gate_metric": "EDMD Koopman full-rank (d=5)",
                "calibration_source": "SmolLM2-360M, N=9 trials, 100% full rank",
                "chain_integrity": True,
            }
        
        total = len(entries)
        compliant = sum(
            1 for e in entries
            if e.get("gate_result", {}).get("pass", False)
        )
        
        # Per-category breakdown
        categories = {}
        for e in entries:
            cat = e.get("category", "unknown")
            if cat not in categories:
                categories[cat] = {"total": 0, "compliant": 0}
            categories[cat]["total"] += 1
            if e.get("gate_result", {}).get("pass", False):
                categories[cat]["compliant"] += 1
        
        chain_valid, _ = self.verify_chain()
        
        return {
            "nist_rmf_function": "MEASURE",
            "subcategory": "MS-2.5 | MS-2.6",
            "total_inferences": total,
            "compliant_inferences": compliant,
            "compliance_rate": round(compliant / total, 4) if total else 0.0,
            "rank_gate_metric": "EDMD Koopman full-rank (d=5)",
            "calibration_source": "SmolLM2-360M, N=9 trials, 100% full rank",
            "chain_integrity": chain_valid,
            "category_breakdown": {
                cat: {
                    "total": data["total"],
                    "compliant": data["compliant"],
                    "rate": round(data["compliant"] / data["total"], 4)
                }
                for cat, data in categories.items()
            },
            "entries": entries,
        }
    
    def get_statistics(self) -> Dict:
        """Get summary statistics of ledger contents."""
        entries = self.get_entries()
        
        if not entries:
            return {"total_entries": 0}
        
        # Lambda statistics
        lambdas = [
            e.get("gate_result", {}).get("lambda_hat", 0.0)
            for e in entries
        ]
        
        # Tail gap statistics
        tail_gaps = [
            e.get("gate_result", {}).get("tail_gap", 0.0)
            for e in entries
            if "tail_gap" in e.get("gate_result", {})
        ]
        
        return {
            "total_entries": len(entries),
            "models": list(set(e.get("model_id") for e in entries)),
            "categories": list(set(e.get("category") for e in entries)),
            "lambda_mean": float(np.mean(lambdas)) if lambdas else 0.0,
            "lambda_std": float(np.std(lambdas)) if lambdas else 0.0,
            "tail_gap_mean": float(np.mean(tail_gaps)) if tail_gaps else 0.0,
            "first_entry": min(e.get("timestamp_iso") for e in entries),
            "last_entry": max(e.get("timestamp_iso") for e in entries),
        }
