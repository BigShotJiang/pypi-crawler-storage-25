"""CLI entry point for koopman-audit package."""

import sys
from .daemon import main as daemon_main

if __name__ == "__main__":
    daemon_main()
