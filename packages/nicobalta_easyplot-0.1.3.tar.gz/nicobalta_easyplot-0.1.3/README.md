# EZplot

A simple wrapper around matplotlib for quick and readable plots in one single line.

## Installation

```bash
pip install nicobalta-easyplot
```

```python
import nicobalta_easyplot
```

## Example

```python
simple_graph(
    [x1, x2],
    [y1, y2],
    colors=["blue", "red"],
    labels=["curve 1", "curve 2"],
    title="Multiple plots"
)
```

## simple_graph parameters

- `X, Y`: data to plot
- `colors`: list of colors
- `linestyles`: list of line styles
- `linewidths`: list of line widths
- `labels`: list of labels
- `labels`: list of markers
- `size`: size of the plot
- `title`: plot title
- `xaxis`: title of x axis
- `yaxis`: title of y axis
- `ticks`: ticks of the plot

## License

MIT

## Versions

See [CHANGELOG.md](./CHANGELOG.md) for details.