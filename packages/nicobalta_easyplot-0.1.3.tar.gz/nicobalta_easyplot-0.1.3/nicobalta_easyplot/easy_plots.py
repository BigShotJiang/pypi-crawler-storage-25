from typing import Sequence
import numpy as np
import matplotlib.pyplot as plt

def simple_graph(
    X: Sequence[Sequence[float]] | Sequence[float] | np.ndarray,
    Y: Sequence[Sequence[float]] | Sequence[float] | np.ndarray,
    colors: Sequence[str | None] | None = None,
    linestyles: Sequence[str | None] | None = None,
    linewidths: Sequence[float] | None = None,
    labels: Sequence[str | None] | None = None,
    markers: Sequence[str | None] | None = None,
    markersizes: Sequence[float] | None = None,
    size: tuple[float, float] | None = None,
    title: str | None = None,
    xaxis: str | None = None,
    yaxis: str | None = None,
    ticks: Sequence[float] | None = None
) -> None:
    """
    Creates a simple plot in one function, with basic settings available

    Parameters
    ----------
    X : list of arrays
        X data for each plot.
    Y : list of arrays
        Y data for each plot.
    colors : list of str, optional
        Colors for each curve.
    linestyles : list of str, optional
        Line styles ('-', '--', '-.', ':').
    linewidths : list of float, optional
        Width of each line.
    labels : list of str, optional
        Labels for legend.
    size : tuple, optional
        Figure size (width, height).
    title : str, optional
        Plot title.
    xaxis : str, optional
        X-axis label.
    yaxis : str, optional
        Y-axis label.
    ticks : tuple, optional
        Tick spacing (x_major, y_major, x_minor, y_minor).

    Returns
    -------
    None
    """
    
    # Verifications
    plot_arrays = len(X)
    
    if len(Y) != plot_arrays:
        raise ValueError("X and Y must contain the same number of elements to plot")
    
    if colors is not None and len(colors) is not plot_arrays:
        raise ValueError(f"Incorrect number of colors (expected {plot_arrays}, got {len(colors)})")
    
    if linestyles is not None and len(linestyles) is not plot_arrays:
        raise ValueError(f"Incorrect number of line styles (expected {plot_arrays}, got {len(linestyles)})")
    
    if linewidths is not None and len(linewidths) is not plot_arrays:
        raise ValueError(f"Incorrect number of line widths (expected {plot_arrays}, got {len(linewidths)})")
    
    if markers is not None and len(markers) is not plot_arrays:
        raise ValueError(f"Incorrect number of line widths (expected {plot_arrays}, got {len(markers)})")
    
    if markersizes is not None and len(markersizes) is not plot_arrays:
        raise ValueError(f"Incorrect number of line widths (expected {plot_arrays}, got {len(markersizes)})")
    
    if labels is not None and len(labels) is not plot_arrays:
        raise ValueError(f"Incorrect number of labels (expected {plot_arrays}, got {len(labels)})")
    
    if size is not None and len(size) is not 2:
        raise ValueError(f"'size' parameter needs a two-elements array (expected 2, got {len(size)})")
    
    if ticks is not None and len(ticks) is not 4:
        raise ValueError(f"'ticks' parameter needs a four-elements array (expected 4, got {len(ticks)})")
    
    # Creation of figure
    if size is not None:
        fig, ax = plt.subplots(figsize=(size[0],size[1]))
    else:
        fig, ax = plt.subplots()

    # Data detection
    if not isinstance(X[0], (list, tuple, np.ndarray)):
        X = [X]
        Y = [Y]

    # Data
    for p in range(len(X)):
        kwargs = {}
        x = X[p]
        y = Y[p]

        if colors is not None and colors[p] is not None:
            kwargs["color"] = colors[p]

        if linestyles is not None and linestyles[p] is not None:
            kwargs["linestyle"] = linestyles[p]

        if linewidths is not None and linewidths[p] is not None:
            kwargs["linewidth"] = linewidths[p]

        if markers is not None and markers[p] is not None:
            kwargs["marker"] = markers[p]

        if markersizes is not None and markersizes[p] is not None:
            kwargs["markersize"] = markersizes[p]

        if labels is not None and labels[p] is not None:
            kwargs["label"] = labels[p]

        ax.plot(x, y, **kwargs)

    # Figure
    if title is not None:
        ax.set_title(title)

    if xaxis is not None:
        ax.set_xlabel(xaxis)

    if yaxis is not None:
        ax.set_ylabel(yaxis)

    if ticks is not None:
        ax.xaxis.set_major_locator(plt.MultipleLocator(ticks[0]))
        ax.yaxis.set_major_locator(plt.MultipleLocator(ticks[1]))

        if (ticks[2] != 0 and ticks[3] != 0):
            ax.xaxis.set_minor_locator(plt.MultipleLocator(ticks[2]))
            ax.yaxis.set_minor_locator(plt.MultipleLocator(ticks[3]))

            ax.grid(which="both")
        
        else: ax.grid(which="major")

    if labels:
        ax.legend()

    plt.show()
