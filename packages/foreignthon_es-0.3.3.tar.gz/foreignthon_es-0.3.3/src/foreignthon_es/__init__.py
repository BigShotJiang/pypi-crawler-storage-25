from importlib.resources import files
from importlib.metadata import version, metadata, PackageNotFoundError

try:
    package_name = (__package__ or "").replace("_", "-")
    __version__ = version(package_name)

    pkg_metadata = metadata(package_name)

    # 1. Grab names from BOTH possible fields (Author and Author-email)
    raw_authors = pkg_metadata.get_all("Author") or []
    raw_emails = pkg_metadata.get_all("Author-email") or []

    # 2. Combine them into one single, clean list of unique names
    # This strips out the extra email brackets so you just get the clean names
    combined = []
    for item in (raw_authors + raw_emails):
        # Extracts just the name if it looks like "Name <email@domain.com>"
        clean_name = item.split("<")[0].strip()
        if clean_name and clean_name not in combined:
            combined.append(clean_name)

    __authors__ = combined

except PackageNotFoundError:
    __version__ = "0.0.0"
    __authors__ = []

def get_pack_path():
    return files(__name__) / "es.json"