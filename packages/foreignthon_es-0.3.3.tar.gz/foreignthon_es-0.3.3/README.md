# foreignthon-es

Spanish language pack for [ForeignThon](https://foreignthon.keshavanand.net/) — write Python in Español.

---

## Install

```bash
pip install foreignthon foreignthon-es
```

---

## Example

**`fizzbuzz.es.py`**

```python
def fizzbuzz(n):
    para i en dist(1, n + 1):
        si i % 15 == 0:
            imprimir("FizzBuzz")
        osi i % 3 == 0:
            imprimir("Fizz")
        osi i % 5 == 0:
            imprimir("Buzz")
        sino:
            imprimir(i)

fizzbuzz(20)
```

Compiles to standard Python:

```python
def fizzbuzz(n):
    for i in range(1, n + 1):
        if i % 15 == 0:
            print("FizzBuzz")
        elif i % 3 == 0:
            print("Fizz")
        elif i % 5 == 0:
            print("Buzz")
        else:
            print(i)

fizzbuzz(20)
```

Run it directly:

```bash
fpy run fizzbuzz.es.py
```

---

## Keyword reference

| Python | Español |
|---|---|
| `if` | `si` |
| `else` | `sino` |
| `elif` | `osi` |
| `for` | `para` |
| `while` | `mientras` |
| `def` | `def` |
| `class` | `clase` |
| `return` | `retornar` |
| `import` | `importar` |
| `True` | `Verda` |
| `False` | `Falso` |
| `None` | `Nada` |
| `print` | `imprimir` |
| `input` | `entrada` |
| `len` | `lon` |
| `range` | `dist` |

Full mapping: [`src/foreignthon_es/es.json`](https://git.keshavanand.net/foreign-thon/foreignthon-es/raw/branch/main/src/foreignthon_es/es.json)

---

## Start a project

```bash
fpy new myproject --lang es
cd myproject
fpy run src/main.es.py
```

---

## Documentation

→ [foreignthon.keshavanand.net](https://foreignthon.keshavanand.net/)

---

## Contributing

Found a missing translation or a better keyword choice? Open an issue or PR — no access to the core repo needed.

---

## License

GPL v3
