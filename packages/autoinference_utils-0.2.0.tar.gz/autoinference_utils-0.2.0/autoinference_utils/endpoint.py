"""Composable endpoint abstractions for inference server subprocess deployments.

These are plain Python objects, not Modal classes — deployments compose them
rather than inheriting from them. The ``!!!`` prefix on startup-failure prints
is a grep-able crash signal for log-watching agents (e.g. the recipe smoke
runner) so they can short-circuit instead of waiting for the full health-check
timeout.
"""

from __future__ import annotations

import http.server
import json
import os
import shlex
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from abc import ABC
from typing import Any, Callable, Literal, Mapping, Optional, Sequence

BENCH_MODE_ENV = "ENDPOINT_BENCH_MODE"
DUMMY_WEIGHTS_ENV = "ENDPOINT_DUMMY"
BENCH_MODE_PORT_OFFSET = 10000

# Endpoint class names whose servers emit OAI streaming chunks that
# sglang.bench_serving can't parse. deploy_and_bench auto-injects
# --openai-stream-compat for deployments importing any of these.
ENDPOINTS_REQUIRING_OAI_STREAM_COMPAT: tuple[str, ...] = ("TRTLLMEndpoint",)


class Endpoint(ABC):
    """A thing with a URL that you can start and stop."""

    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    def __enter__(self):
        try:
            self.start()
        except BaseException as exc:
            print(
                f"[endpoint] !!! start() failed: {type(exc).__name__}: {exc}",
                flush=True,
            )
            raise
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
        return False

    def start(self):
        return

    def stop(self):
        return


class SGLangEndpoint(Endpoint):
    """Manages an SGLang server subprocess on the local machine."""

    DEFAULT_OPERATIONAL_ARGS: dict[str, str] = {
        "--enable-metrics": "",
        "--decode-log-interval": "1",
        "--enable-cache-report": "",
        "--model-loader-extra-config": (
            '{"enable_multithread_load":true,"num_threads":64}'
        ),
    }

    def __init__(
        self,
        *,
        model_path: str,
        worker_port: int = 8000,
        tp: Optional[int] = None,
        ep: Optional[int] = None,
        dp: Optional[int] = None,
        speculative_model_path: Optional[str] = None,
        load_format: Optional[str] = None,
        nnodes: int = 1,
        node_rank: int = 0,
        dist_init_host: Optional[str] = None,
        dist_init_port: int = 1234,
        disaggregation_mode: Optional[Literal["prefill", "decode"]] = None,
        prefill_bootstrap_port: int = 8998,
        launcher_module: str = "sglang.launch_server",
        extra_server_args: Optional[dict[str, str]] = None,
        health_timeout: float = 20 * 60,
        health_poll_interval: float = 5.0,
        health_request_timeout: float = 5.0,
    ):
        # In bench mode SGLang runs on worker_port + 10000 and a /bench proxy
        # listens on the original worker_port; both fall through to the same
        # port when bench mode is off.
        self.bench_mode = os.environ.get(BENCH_MODE_ENV) == "1"
        self.listen_port = worker_port
        sglang_port = (
            worker_port + BENCH_MODE_PORT_OFFSET if self.bench_mode else worker_port
        )
        super().__init__(base_url=f"http://localhost:{sglang_port}")

        self.worker_port = sglang_port
        self.model_path = model_path
        self.tp = tp
        self.ep = ep
        self.dp = dp
        self.speculative_model_path = speculative_model_path
        self.load_format = load_format
        self.nnodes = nnodes
        self.node_rank = node_rank
        self.dist_init_host = dist_init_host
        self.dist_init_port = dist_init_port
        self.disaggregation_mode = disaggregation_mode
        self.prefill_bootstrap_port = prefill_bootstrap_port
        self.launcher_module = launcher_module
        self.extra_server_args = (
            dict(extra_server_args) if extra_server_args else {}
        )
        self.health_timeout = health_timeout
        self.health_poll_interval = health_poll_interval
        self.health_request_timeout = health_request_timeout
        self._proc: Optional[subprocess.Popen] = None
        self._bench_server: Optional[http.server.ThreadingHTTPServer] = None

        if self.disaggregation_mode not in (None, "prefill", "decode"):
            raise ValueError(
                "disaggregation_mode must be None, 'prefill', or 'decode'"
            )

        if os.environ.get(DUMMY_WEIGHTS_ENV) == "1":
            if (
                self.load_format is None
                and "--load-format" not in self.extra_server_args
            ):
                self.load_format = "dummy"
            self.extra_server_args.setdefault("--model-loader-extra-config", "{}")

    def _build_cmd(self) -> list[str]:
        cmd = [
            "python", "-m", self.launcher_module,
            "--host", "0.0.0.0",
            "--port", str(self.worker_port),
            "--model-path", self.model_path,
        ]

        if self.speculative_model_path is not None:
            cmd.extend(
                ["--speculative-draft-model-path", self.speculative_model_path]
            )
        if self.load_format is not None:
            cmd.extend(["--load-format", self.load_format])
        if self.tp is not None:
            cmd.extend(["--tp", str(self.tp)])
        if self.ep is not None:
            cmd.extend(["--ep", str(self.ep)])
        if self.dp is not None:
            cmd.extend(["--dp", str(self.dp), "--enable-dp-attention"])

        if self.disaggregation_mode is not None:
            cmd.extend(["--disaggregation-mode", self.disaggregation_mode])
            if self.disaggregation_mode == "prefill":
                cmd.extend(
                    [
                        "--disaggregation-bootstrap-port",
                        str(self.prefill_bootstrap_port),
                    ]
                )

        if self.nnodes > 1:
            if self.dist_init_host is None:
                raise ValueError("dist_init_host is required when nnodes > 1")
            cmd.extend(
                [
                    "--nnodes", str(self.nnodes),
                    "--node-rank", str(self.node_rank),
                    "--dist-init-addr",
                    f"{self.dist_init_host}:{self.dist_init_port}",
                ]
            )

        merged = {**self.DEFAULT_OPERATIONAL_ARGS, **self.extra_server_args}
        for key, value in merged.items():
            if value == "":
                cmd.append(key)
            else:
                cmd.extend([key, *value.split()])

        return cmd

    def health_check(self) -> str | None:
        url = f"http://127.0.0.1:{self.worker_port}/health"
        return _health_check(
            url,
            request_timeout=self.health_request_timeout,
            process=self._proc,
        )

    def start(self):
        cmd = self._build_cmd()
        print(f"[endpoint] starting: {shlex.join(cmd)}")
        self._proc = subprocess.Popen(cmd)
        wait_ready(
            self._proc,
            port=self.worker_port,
            timeout=self.health_timeout,
            poll_interval=self.health_poll_interval,
            request_timeout=self.health_request_timeout,
        )
        if self.bench_mode:
            self._bench_server = start_bench_proxy(
                listen_port=self.listen_port,
                upstream_port=self.worker_port,
            )

    def stop(self):
        if self._bench_server is not None:
            self._bench_server.shutdown()
            self._bench_server = None
        terminate_process(self._proc)
        self._proc = None


class VLLMEndpoint(Endpoint):
    """Manages a vLLM server subprocess on the local machine."""

    def __init__(
        self,
        *,
        model: str,
        worker_port: int = 8000,
        extra_server_args: Optional[dict[str, str]] = None,
        health_timeout: float = 20 * 60,
        health_poll_interval: float = 5.0,
        health_request_timeout: float = 5.0,
    ):
        super().__init__(base_url=f"http://localhost:{worker_port}")
        self.model = model
        self.worker_port = worker_port
        self.extra_server_args = (
            dict(extra_server_args) if extra_server_args else {}
        )
        self.health_timeout = health_timeout
        self.health_poll_interval = health_poll_interval
        self.health_request_timeout = health_request_timeout
        self._proc: Optional[subprocess.Popen] = None

    def _build_cmd(self) -> list[str]:
        cmd = [
            "python", "-m", "vllm.entrypoints.openai.api_server",
            "--host", "0.0.0.0",
            "--port", str(self.worker_port),
            "--model", self.model,
        ]
        for key, value in self.extra_server_args.items():
            if value == "":
                cmd.append(key)
            else:
                cmd.extend([key, *value.split()])
        return cmd

    def start(self):
        if (
            os.environ.get(BENCH_MODE_ENV) == "1"
            or os.environ.get(DUMMY_WEIGHTS_ENV) == "1"
        ):
            raise NotImplementedError(
                "bench_mode and dummy weights are not supported for VLLMEndpoint"
            )
        cmd = self._build_cmd()
        print(f"[vllm] starting: {shlex.join(cmd)}")
        self._proc = subprocess.Popen(cmd)
        wait_ready(
            self._proc,
            port=self.worker_port,
            timeout=self.health_timeout,
            poll_interval=self.health_poll_interval,
            request_timeout=self.health_request_timeout,
        )

    def stop(self):
        terminate_process(self._proc)
        self._proc = None


class TRTLLMEndpoint(Endpoint):
    """Manages a TensorRT-LLM OpenAI-compatible server subprocess."""

    def __init__(
        self,
        *,
        model: str,
        worker_port: int = 8000,
        extra_server_args: Optional[dict[str, str]] = None,
        health_timeout: float = 20 * 60,
        health_poll_interval: float = 5.0,
        health_request_timeout: float = 5.0,
    ):
        if os.environ.get(BENCH_MODE_ENV) == "1":
            raise NotImplementedError(
                f"{BENCH_MODE_ENV}=1 (--mode colocated) is only supported by "
                "SGLangEndpoint today. TRTLLMEndpoint does not yet wire up the "
                "bench-mode proxy; run the benchmark from a separate worker "
                "or switch the deployment to SGLang."
            )
        super().__init__(base_url=f"http://localhost:{worker_port}")
        self.model = model
        self.worker_port = worker_port
        self.extra_server_args = (
            dict(extra_server_args) if extra_server_args else {}
        )
        self.health_timeout = health_timeout
        self.health_poll_interval = health_poll_interval
        self.health_request_timeout = health_request_timeout
        self._proc: Optional[subprocess.Popen] = None

    def _build_cmd(self) -> list[str]:
        cmd = [
            "trtllm-serve",
            self.model,
            "--host", "0.0.0.0",
            "--port", str(self.worker_port),
        ]
        for key, value in self.extra_server_args.items():
            if value == "":
                cmd.append(key)
            else:
                cmd.extend([key, *value.split()])
        return cmd

    def health_check(self) -> str | None:
        url = f"http://127.0.0.1:{self.worker_port}/health"
        return _health_check(
            url,
            request_timeout=self.health_request_timeout,
            process=self._proc,
        )

    def start(self):
        cmd = self._build_cmd()
        print(f"[trtllm] starting: {shlex.join(cmd)}")
        self._proc = subprocess.Popen(cmd)
        wait_ready(
            self._proc,
            port=self.worker_port,
            timeout=self.health_timeout,
            poll_interval=self.health_poll_interval,
            request_timeout=self.health_request_timeout,
        )

    def stop(self):
        terminate_process(self._proc)
        self._proc = None


class RouterEndpoint(Endpoint):
    """Manages an SGLang router process for PD disaggregation."""

    def __init__(
        self,
        *,
        pd_config: Sequence[tuple[str, str]],
        worker_port: int = 8000,
        router_port: int = 9000,
        prefill_bootstrap_port: int = 8998,
        api_key: Optional[str] = None,
        health_timeout: float = 10 * 60,
        health_poll_interval: float = 5.0,
    ):
        super().__init__(base_url=f"http://localhost:{router_port}")
        self.pd_config = list(pd_config)
        self.worker_port = worker_port
        self.router_port = router_port
        self.prefill_bootstrap_port = prefill_bootstrap_port
        self.api_key = api_key
        self.health_timeout = health_timeout
        self.health_poll_interval = health_poll_interval
        self._proc: Optional[subprocess.Popen] = None

    def _build_cmd(self) -> list[str]:
        cmd = [
            "python", "-m", "sglang_router.launch_router",
            "--host", "0.0.0.0",
            "--port", str(self.router_port),
            "--prefill-policy", "cache_aware",
            "--decode-policy", "round_robin",
            "--max-concurrent-requests", "128",
            "--rate-limit-tokens-per-second", "0",
            "--queue-size", "0",
            "--health-check-timeout-secs", "600",
            "--log-level", "info",
            "--disable-circuit-breaker",
            "--request-timeout-secs", "3600",
        ]

        if self.api_key is not None:
            cmd.extend(["--api-key", self.api_key])

        if any(role in ("prefill", "decode") for role, _ in self.pd_config):
            cmd.append("--pd-disaggregation")

        for role, node_ip in self.pd_config:
            node_url = f"http://{node_ip}:{self.worker_port}"
            if role == "prefill":
                cmd.extend(
                    ["--prefill", node_url, str(self.prefill_bootstrap_port)]
                )
            elif role == "decode":
                cmd.extend(["--decode", node_url])
            elif role == "worker":
                cmd.extend(["--worker-urls", node_url])
            else:
                raise ValueError(f"invalid pd_config role: {role}")

        return cmd

    def start(self):
        for _, node_ip in self.pd_config:
            _wait_ready_url(
                f"http://{node_ip}:{self.worker_port}/health",
                timeout=self.health_timeout,
                poll_interval=self.health_poll_interval,
            )

        cmd = self._build_cmd()
        print(f"[router] starting: {shlex.join(cmd)}")
        self._proc = subprocess.Popen(cmd)
        _wait_ready_url(
            f"http://localhost:{self.router_port}/health",
            timeout=self.health_timeout,
            poll_interval=self.health_poll_interval,
        )

    def stop(self):
        terminate_process(self._proc)
        self._proc = None


# When ENDPOINT_BENCH_MODE=1, SGLangEndpoint runs SGLang on worker_port+10000
# and this proxy listens on worker_port. POST /bench shells out to a benchmark
# task via run_bench(); every other path is forwarded to the upstream server.

def start_bench_proxy(
    *,
    listen_port: int,
    upstream_port: int,
) -> http.server.ThreadingHTTPServer:
    handler_cls = type(
        "BenchProxyHandler",
        (_BenchProxyHandler,),
        {"upstream_port": upstream_port},
    )
    server = http.server.ThreadingHTTPServer(
        ("0.0.0.0", listen_port), handler_cls
    )
    thread = threading.Thread(
        target=server.serve_forever, daemon=True, name="bench-proxy"
    )
    thread.start()
    print(
        f"[bench-proxy] listening on :{listen_port}, "
        f"forwarding to :{upstream_port}"
    )
    return server


class _BenchProxyHandler(http.server.BaseHTTPRequestHandler):
    upstream_port: int = 8000

    def log_message(self, format, *args):
        return

    def do_GET(self):
        self._proxy("GET")

    def do_POST(self):
        if self.path == "/bench":
            self._handle_bench()
        else:
            self._proxy("POST")

    def do_PUT(self):
        self._proxy("PUT")

    def do_DELETE(self):
        self._proxy("DELETE")

    def _handle_bench(self):
        try:
            payload = self._read_json_body()
        except (ValueError, json.JSONDecodeError) as exc:
            return self._send_json(
                400, {"ok": False, "error": f"bad body: {exc}"}
            )

        benchmark = payload.get("benchmark") or ""
        args = payload.get("args") or []
        target = (
            payload.get("target")
            or f"http://localhost:{self.upstream_port}"
        )
        output_dir = payload.get("output_dir") or "/tmp/bench-output"

        if not benchmark:
            return self._send_json(
                400, {"ok": False, "error": "benchmark is required"}
            )
        if not isinstance(args, list):
            return self._send_json(
                400, {"ok": False, "error": "args must be a list"}
            )

        rc, body = run_bench(benchmark, list(args), target, output_dir)
        status = 200 if rc == 0 else 500
        self._send_raw(status, "application/json", body)

    def _proxy(self, method: str):
        url = f"http://localhost:{self.upstream_port}{self.path}"
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else None
        forward_headers = {
            k: v
            for k, v in self.headers.items()
            if k.lower() not in ("host", "content-length", "connection")
        }
        req = urllib.request.Request(
            url, data=body, method=method, headers=forward_headers
        )
        try:
            with urllib.request.urlopen(req, timeout=3600) as resp:
                self.send_response(resp.getcode())
                for k, v in resp.headers.items():
                    if k.lower() not in (
                        "transfer-encoding",
                        "connection",
                        "content-length",
                    ):
                        self.send_header(k, v)
                data = resp.read()
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
        except urllib.error.HTTPError as exc:
            data = exc.read()
            self.send_response(exc.code)
            self.send_header(
                "Content-Type",
                exc.headers.get("Content-Type", "text/plain"),
            )
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except urllib.error.URLError as exc:
            self._send_json(502, {"error": f"upstream unreachable: {exc}"})

    def _read_json_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw)

    def _send_json(self, status: int, obj: Mapping[str, Any]):
        self._send_raw(
            status, "application/json", json.dumps(obj).encode()
        )

    def _send_raw(self, status: int, content_type: str, body: bytes):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def run_bench(
    benchmark: str, args: list[str], target: str, output_dir: str
) -> tuple[int, bytes]:
    """Run a benchmark task (an ``invoke`` @task in
    autoinference.tools.benchmarks) as a subprocess. Used by the in-container
    /bench proxy and the Modal bench worker (--target mode). stdout/stderr
    stream to the container's own stdout so Modal logs capture them live;
    returns (rc, run_report.json body) at the end."""
    os.makedirs(output_dir, exist_ok=True)

    search_root = _benchmarks_search_root()
    if search_root is None:
        return 500, json.dumps(
            {
                "ok": False,
                "error": (
                    "autoinference.tools.benchmarks not importable in container"
                ),
                "volume_path": output_dir,
            }
        ).encode()

    cmd = [
        sys.executable, "-m", "invoke",
        "--search-root", search_root,
        "-c", "tasks",
        benchmark, *[str(a) for a in args],
    ]
    env = {
        **os.environ,
        "AUTOINFERENCE_BENCH_TARGET": target,
        "AUTOINFERENCE_BENCH_OUTPUT_DIR": output_dir,
    }
    print(f"[runner] $ {shlex.join(cmd)}", flush=True)
    rc = subprocess.call(cmd, env=env)

    report_path = os.path.join(output_dir, "run_report.json")
    if os.path.exists(report_path):
        with open(report_path, "rb") as fp:
            return rc, fp.read()

    payload = {
        "ok": False,
        "error": (
            f"invoke exited {rc} without run_report.json — "
            f"see Modal logs for the {benchmark} task output."
        ),
        "volume_path": output_dir,
    }
    return rc or 1, json.dumps(payload).encode()


def _benchmarks_search_root() -> str | None:
    try:
        import autoinference.tools.benchmarks.tasks as tasks_mod
    except Exception:
        return None
    return os.path.dirname(os.path.abspath(tasks_mod.__file__))


def wait_ready(
    process: subprocess.Popen,
    *,
    port: int,
    timeout: float,
    health_path: str = "/health",
    poll_interval: float = 5.0,
    request_timeout: float = 5.0,
) -> None:
    """Poll an HTTP health endpoint until ready, raising if the process dies."""
    deadline = time.time() + timeout
    url = f"http://127.0.0.1:{port}{health_path}"
    last_error = "no response yet"

    while time.time() < deadline:
        try:
            error = _health_check(
                url, request_timeout=request_timeout, process=process
            )
        except subprocess.CalledProcessError as exc:
            print(
                f"[endpoint] !!! server process exited with code "
                f"{exc.returncode} before health check passed; cmd={exc.cmd}",
                flush=True,
            )
            raise
        if error is None:
            return
        last_error = error
        time.sleep(poll_interval)

    print(
        f"[endpoint] !!! health check timed out after {timeout}s; "
        f"last={last_error}",
        flush=True,
    )
    raise TimeoutError(
        f"Health check timed out after {timeout}s for {url}. "
        f"Last error: {last_error}"
    )


def warmup_chat_completions(
    *,
    port: int,
    payload: Mapping[str, Any],
    headers: Mapping[str, str] | None = None,
    successful_requests: int = 3,
    request_timeout: float = 30.0,
    max_attempts_per_request: int = 2,
    retry_delay: float = 1.0,
) -> None:
    """Warm the OpenAI chat completions endpoint with strict retries."""
    url = f"http://127.0.0.1:{port}/v1/chat/completions"
    request_headers = {"Content-Type": "application/json"}
    if headers:
        request_headers.update(headers)

    for request_idx in range(successful_requests):
        for attempt in range(max_attempts_per_request):
            try:
                _post_json(
                    url,
                    payload=payload,
                    headers=request_headers,
                    timeout=request_timeout,
                )
                break
            except (
                urllib.error.HTTPError,
                urllib.error.URLError,
                TimeoutError,
                OSError,
            ) as exc:
                if attempt + 1 == max_attempts_per_request:
                    detail = (
                        _format_http_error(exc)
                        if isinstance(exc, urllib.error.HTTPError)
                        else f"{type(exc).__name__}: {exc}"
                    )
                    raise RuntimeError(
                        f"warmup request {request_idx + 1}/"
                        f"{successful_requests}: {detail}"
                    ) from exc
            time.sleep(retry_delay)


def start_heartbeat_thread(
    health_check_fn: Callable[[], str | None],
    *,
    on_failure: Callable[[], None],
    poll_interval: float = 5.0,
    max_consecutive_failures: int = 3,
) -> threading.Thread:
    def _loop():
        consecutive_failures = 0
        while True:
            time.sleep(poll_interval)
            try:
                error = health_check_fn()
            except subprocess.CalledProcessError as exc:
                print(
                    f"[heartbeat] server process exited with code "
                    f"{exc.returncode}"
                )
                on_failure()
                return
            if error is None:
                consecutive_failures = 0
                continue
            consecutive_failures += 1
            print(
                f"[heartbeat] {error} "
                f"({consecutive_failures}/{max_consecutive_failures})"
            )
            if consecutive_failures >= max_consecutive_failures:
                print(
                    "[heartbeat] sustained health-check failure, "
                    "invoking on_failure"
                )
                on_failure()
                return

    t = threading.Thread(target=_loop, daemon=True)
    t.start()
    return t


def terminate_process(
    process: subprocess.Popen | None,
    *,
    terminate_timeout: float = 10.0,
) -> None:
    """Terminate a subprocess cleanly, then kill it if needed."""
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=terminate_timeout)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def sgl_sleep(port: int) -> None:
    _post_json(
        f"http://127.0.0.1:{port}/release_memory_occupation",
        payload={},
        headers={"Content-Type": "application/json"},
    )


def sgl_wake(port: int) -> None:
    _post_json(
        f"http://127.0.0.1:{port}/resume_memory_occupation",
        payload={},
        headers={"Content-Type": "application/json"},
    )


def _health_check(
    url: str,
    *,
    request_timeout: float = 5.0,
    process: subprocess.Popen | None = None,
) -> str | None:
    """Single health-check attempt. Returns None on success, an error string
    on transient failure, and raises subprocess.CalledProcessError if the
    process under watch has exited."""
    if process is not None:
        _raise_if_exited(process)
    try:
        status = _get_status(url, timeout=request_timeout)
        if 200 <= status < 300:
            return None
        return f"health check returned status {status}"
    except urllib.error.HTTPError as exc:
        return _format_http_error(exc)
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return f"{type(exc).__name__}: {exc}"


def _raise_if_exited(process: subprocess.Popen) -> None:
    if (rc := process.poll()) is not None:
        raise subprocess.CalledProcessError(rc, cmd=process.args)


def _wait_ready_url(
    url: str,
    *,
    timeout: float,
    poll_interval: float = 5.0,
    request_timeout: float = 5.0,
) -> None:
    """Poll a URL until it returns 2xx (no subprocess to watch)."""
    deadline = time.time() + timeout
    last_error = "no response yet"
    while time.time() < deadline:
        error = _health_check(url, request_timeout=request_timeout)
        if error is None:
            return
        last_error = error
        time.sleep(poll_interval)
    raise TimeoutError(
        f"Timed out after {timeout}s waiting for {url}. "
        f"Last error: {last_error}"
    )


def _get_status(url: str, *, timeout: float) -> int:
    req = urllib.request.Request(url, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.getcode()


def _post_json(
    url: str,
    *,
    payload: Mapping[str, Any],
    headers: Mapping[str, str],
    timeout: float | None = None,
) -> int:
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=body, headers=dict(headers), method="POST"
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.getcode()


def _format_http_error(exc: urllib.error.HTTPError) -> str:
    body = exc.read().decode("utf-8", errors="replace").strip()
    if body:
        return f"status {exc.code}: {body[:500]}"
    return f"status {exc.code}"
