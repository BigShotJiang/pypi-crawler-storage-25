# autoinference-utils

Shared endpoint abstractions (`SGLangEndpoint`, `VLLMEndpoint`) for autoinference deployments.

## Publishing

Bump `version` in `pyproject.toml` and merge to `main` — CI publishes automatically via trusted publishing.

To publish manually: `cd autoinference_utils && uv build && uv publish`
