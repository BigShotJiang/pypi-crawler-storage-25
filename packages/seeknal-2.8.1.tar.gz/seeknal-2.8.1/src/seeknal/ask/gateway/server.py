"""Seeknal Ask Gateway — Starlette ASGI server.

Provides WebSocket, SSE, and REST endpoints for interacting with
the seeknal ask agent over HTTP. Uses pydantic-ai's agent.iter()
for streaming responses.

Usage:
    seeknal gateway start --project path --port 8000
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from pathlib import Path
from typing import Any, Callable

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, StreamingResponse
from starlette.routing import Mount, Route, WebSocketRoute
from starlette.staticfiles import StaticFiles
from starlette.websockets import WebSocket, WebSocketDisconnect

from seeknal.ask.gateway.pairing import (
    FilePairingStore,
    PublicSessionStore,
    TelegramLinkStore,
)
from seeknal.ask.gateway.session_manager import SessionManager
from seeknal.ask.gateway.sse import SSEBroadcaster
from seeknal.ask.gateway.tenant import (
    DEFAULT_TENANT,
    InvalidTenantError,
    make_workflow_id,
    resolve_tenant,
    resolve_tenant_ws,
    scoped_key,
    task_queue_for_tenant,
)

# Validate session IDs: alphanumeric, hyphens, underscores, max 128 chars
_SESSION_ID_RE = re.compile(r"^[a-zA-Z0-9_-]{1,128}$")

# Upload constraints (kept here so they're easy to surface in error responses)
_UPLOAD_MAX_BYTES = 200 * 1024 * 1024  # 200 MB
_UPLOAD_ALLOWED_SUFFIXES = {".xlsx", ".csv", ".tsv", ".json"}
_UPLOAD_IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif"}
_IMAGE_MAX_BYTES = 20 * 1024 * 1024  # 20 MB

session_manager = SessionManager()
sse_broadcaster = SSEBroadcaster()

# Per-session locks to serialize concurrent runs on the same (tenant, session_id).
# Prevents message history corruption (last-writer-wins on JSON files)
# and garbled SSE event streams from interleaved responses.
# Uses LRU eviction to prevent unbounded memory growth.
_session_locks: dict[str, tuple[asyncio.Lock, float]] = {}
_LOCK_IDLE_TTL = 1800  # 30 minutes


def _get_session_lock(
    session_id: str, tenant_id: str = DEFAULT_TENANT
) -> asyncio.Lock:
    """Get or create an asyncio.Lock for a (tenant, session_id) with LRU tracking."""
    key = scoped_key(tenant_id, session_id)
    now = time.monotonic()
    if key in _session_locks:
        lock, _ = _session_locks[key]
        _session_locks[key] = (lock, now)
        return lock
    lock = asyncio.Lock()
    _session_locks[key] = (lock, now)
    return lock


def _evict_idle_locks() -> int:
    """Remove locks that have been idle for longer than _LOCK_IDLE_TTL.

    Returns the number of evicted entries.
    """
    now = time.monotonic()
    stale = [
        key for key, (lock, last_access) in _session_locks.items()
        if now - last_access > _LOCK_IDLE_TTL and not lock.locked()
    ]
    for key in stale:
        del _session_locks[key]
    return len(stale)


def _validate_session_id(session_id: str) -> bool:
    return bool(_SESSION_ID_RE.match(session_id))


def _publish_event(
    session_id: str, event: dict, tenant_id: str = DEFAULT_TENANT
) -> None:
    """Publish an event to all SSE subscribers for this (tenant, session_id)."""
    sse_broadcaster.publish_sync(session_id, json.dumps(event), tenant_id=tenant_id)


def _safe_resolve_tenant(request: Request) -> tuple[str, JSONResponse | None]:
    """Resolve tenant from a request, returning (tenant_id, error_response).

    On success: ``(tenant_id, None)``.
    On invalid format: ``(DEFAULT_TENANT, 400 JSONResponse)`` — callers
    must check the error response before using the tenant_id.
    """
    try:
        return resolve_tenant(request), None
    except InvalidTenantError as exc:
        return DEFAULT_TENANT, JSONResponse({"error": str(exc)}, status_code=400)


# ---------------------------------------------------------------------------
# Agent execution (shared by WebSocket, SSE, and REST)
# ---------------------------------------------------------------------------


async def _run_agent_streaming(
    project_path: Path,
    session_id: str,
    question: str,
    provider: str | None = None,
    model: str | None = None,
    tenant_id: str = DEFAULT_TENANT,
    auto_approve: bool = False,
    include_web: bool = False,
):
    """Run agent and yield JSON event dicts as they occur.

    This generator is the sole owner of SSE broadcast — every event
    yielded is also published to ``sse_broadcaster`` so that SSE
    subscribers on ``/events/{session_id}`` receive events in real-time.

    A per-(tenant, session) ``asyncio.Lock`` serializes concurrent runs
    to prevent message history corruption.
    """
    lock = _get_session_lock(session_id, tenant_id=tenant_id)
    async with lock:
        try:
            async for event in _run_agent_inner(
                project_path, session_id, question, provider, model,
                tenant_id=tenant_id, auto_approve=auto_approve,
                include_web=include_web,
            ):
                _publish_event(session_id, event, tenant_id=tenant_id)
                yield event
        except Exception as exc:
            error_event = {"type": "error", "data": str(exc)}
            _publish_event(session_id, error_event, tenant_id=tenant_id)
            yield error_event
            raise
        finally:
            done_event = {"type": "done", "data": ""}
            _publish_event(session_id, done_event, tenant_id=tenant_id)
            yield done_event


async def _run_agent_inner(
    project_path: Path,
    session_id: str,
    question: str,
    provider: str | None = None,
    model: str | None = None,
    tenant_id: str = DEFAULT_TENANT,
    auto_approve: bool = False,
    include_web: bool = False,
):
    """Inner agent execution without locking or SSE publishing."""
    from pydantic_ai import Agent
    from pydantic_ai._agent_graph import End, UserPromptNode
    from pydantic_ai.messages import (
        FunctionToolCallEvent,
        FunctionToolResultEvent,
        PartDeltaEvent,
        TextPartDelta,
    )

    from seeknal.ask.agents.agent import create_agent
    from seeknal.ask.sessions import SessionStore

    store = SessionStore(project_path, tenant_id=tenant_id)
    if store.get(session_id) is None:
        store.create(name=session_id)

    message_history = store.load_messages(session_id)

    agent, deps, _, _ = create_agent(
        project_path, provider=provider, model=model,
        environment="gateway", include_web=include_web,
    )

    # Auto-grant all approval gates (for Telegram and other headless channels)
    if auto_approve:
        from seeknal.ask.agents.tools._context import get_tool_context
        ctx = get_tool_context()
        ctx.require_report_approval = False
        ctx.require_proof_publish_approval = False
        ctx.require_proof_edit_approval = False
        ctx.require_seeknal_report_publish_approval = False

    text_buffer: list[str] = []
    result = None

    try:
        async with agent.iter(
            question, deps=deps, message_history=message_history,
        ) as run:
            async for node in run:
                if isinstance(node, UserPromptNode):
                    continue

                elif Agent.is_model_request_node(node):
                    async with node.stream(run.ctx) as stream:
                        async for event in stream:
                            if isinstance(event, PartDeltaEvent):
                                if isinstance(event.delta, TextPartDelta):
                                    text_buffer.append(event.delta.content_delta)
                                    yield {
                                        "type": "token",
                                        "data": event.delta.content_delta,
                                    }

                elif Agent.is_call_tools_node(node):
                    # Flush reasoning
                    if text_buffer:
                        yield {
                            "type": "reasoning",
                            "data": "".join(text_buffer),
                        }
                        text_buffer.clear()

                    async with node.stream(run.ctx) as handle_stream:
                        async for event in handle_stream:
                            if isinstance(event, FunctionToolCallEvent):
                                yield {
                                    "type": "tool_start",
                                    "data": {
                                        "name": event.part.tool_name,
                                        "args": event.part.args_as_dict(),
                                    },
                                }
                            elif isinstance(event, FunctionToolResultEvent):
                                content = event.result.content
                                yield {
                                    "type": "tool_end",
                                    "data": {
                                        "name": event.result.tool_name,
                                        "output": str(content)[:2000] if content else "",
                                    },
                                }

                elif isinstance(node, End):
                    break

            result = run.result

        # Final answer
        if text_buffer:
            answer = "".join(text_buffer)
        else:
            answer = result.output or ""

        if answer:
            yield {"type": "answer", "data": answer}

    finally:
        # Always save conversation — even when the consumer closes the generator
        # early (e.g. Telegram breaking on answer event). Without this, session
        # history is lost and the agent can't reference prior messages.
        if result is not None:
            try:
                all_messages = result.all_messages()
                store.save_messages(session_id, all_messages)
                msg_count = len([m for m in all_messages if hasattr(m, 'parts')])
                store.update(
                    session_id,
                    message_count=msg_count,
                    last_question=question[:200],
                    status="active",
                )
            except Exception:
                import logging
                logging.getLogger(__name__).exception(
                    "[gateway] failed to save session %s", session_id
                )


# ---------------------------------------------------------------------------
# Route handlers
# ---------------------------------------------------------------------------


async def health(request: Request) -> JSONResponse:
    return JSONResponse({"status": "ok", "service": "seeknal-ask-gateway"})


def _make_session_store(
    app_state, tenant_id: str = DEFAULT_TENANT
) -> "SessionStore":  # noqa: F821
    """Construct a tenant-scoped SessionStore from app.state."""
    from seeknal.ask.sessions import SessionStore

    sessions_dir = getattr(app_state, "sessions_dir", None)
    if sessions_dir:
        return SessionStore(sessions_dir=Path(sessions_dir), tenant_id=tenant_id)
    project_path = getattr(app_state, "project_path", None)
    if project_path:
        return SessionStore(Path(project_path), tenant_id=tenant_id)
    raise RuntimeError("SessionStore requires project_path or sessions_dir")


async def list_sessions(request: Request) -> JSONResponse:
    tenant_id, err = _safe_resolve_tenant(request)
    if err:
        return err
    store = _make_session_store(request.app.state, tenant_id=tenant_id)
    sessions = store.list()
    return JSONResponse(sessions)


async def ask_oneshot(request: Request) -> JSONResponse:
    """One-shot question → JSON response."""
    tenant_id, err = _safe_resolve_tenant(request)
    if err:
        return err
    body = await request.json()
    question = body.get("question", "")
    session_id = body.get("session_id", "default")
    if not question:
        return JSONResponse({"error": "question is required"}, status_code=400)
    if not _validate_session_id(session_id):
        return JSONResponse({"error": "invalid session_id"}, status_code=400)

    project_path = Path(request.app.state.project_path)
    events = []
    answer = ""
    async for event in _run_agent_streaming(
        project_path, session_id, question, tenant_id=tenant_id,
    ):
        events.append(event)
        if event["type"] == "answer":
            answer = event["data"]

    return JSONResponse({"answer": answer, "events": events})


async def websocket_endpoint(websocket: WebSocket) -> None:
    """WebSocket streaming per session."""
    session_id = websocket.path_params["session_id"]
    if not _validate_session_id(session_id):
        await websocket.close(code=4000, reason="invalid session_id")
        return

    try:
        tenant_id = resolve_tenant_ws(websocket)
    except InvalidTenantError as exc:
        await websocket.close(code=4001, reason=str(exc))
        return

    await websocket.accept()
    project_path = Path(websocket.app.state.project_path)
    await session_manager.connect(session_id, websocket)

    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            question = msg.get("question", "")
            if not question:
                await websocket.send_text(
                    json.dumps({"type": "error", "data": "question is required"})
                )
                continue

            async for event in _run_agent_streaming(
                project_path, session_id, question, tenant_id=tenant_id,
            ):
                await websocket.send_text(json.dumps(event))

    except WebSocketDisconnect:
        pass
    finally:
        await session_manager.disconnect(session_id, websocket)


async def sse_endpoint(request: Request) -> StreamingResponse:
    """SSE event stream for a session.

    Sends keepalive events every 30 seconds during idle periods.
    Stays open across multiple turns — client decides when to close.
    Safety-valve timeout (10 minutes idle) prevents infinite hangs.
    """
    session_id = request.path_params["session_id"]
    if not _validate_session_id(session_id):
        return JSONResponse({"error": "invalid session_id"}, status_code=400)

    tenant_id, err = _safe_resolve_tenant(request)
    if err:
        return err

    queue = sse_broadcaster.subscribe(session_id, tenant_id=tenant_id)

    # Safety-valve: max 10 minutes total to prevent infinite hangs
    _MAX_SSE_DURATION = 600  # seconds
    _KEEPALIVE_INTERVAL = 30  # seconds

    async def event_generator():
        import time

        start = time.monotonic()
        try:
            while True:
                # Check safety-valve timeout
                elapsed = time.monotonic() - start
                if elapsed >= _MAX_SSE_DURATION:
                    yield 'data: {"type": "keepalive"}\n\n'
                    break

                # Check client disconnect
                if await request.is_disconnected():
                    break

                try:
                    event = await asyncio.wait_for(
                        queue.get(), timeout=_KEEPALIVE_INTERVAL,
                    )
                    yield f"data: {event}\n\n"

                    # Reset safety-valve timer on each event (idle timeout, not total)
                    start = time.monotonic()

                except asyncio.TimeoutError:
                    # Send keepalive and continue loop
                    yield 'data: {"type": "keepalive"}\n\n'

        except asyncio.CancelledError:
            pass
        finally:
            sse_broadcaster.unsubscribe(session_id, queue, tenant_id=tenant_id)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Session history endpoint
# ---------------------------------------------------------------------------


async def session_history(request: Request) -> JSONResponse:
    """Return conversation history as raw SSE-format events for UI replay.

    Converts pydantic-ai message objects into the same event format
    that ``_run_agent_inner`` yields during live streaming.
    """
    session_id = request.path_params["session_id"]
    if not _validate_session_id(session_id):
        return JSONResponse({"error": "invalid session_id"}, status_code=400)

    tenant_id, err = _safe_resolve_tenant(request)
    if err:
        return err

    store = _make_session_store(request.app.state, tenant_id=tenant_id)
    if store.get(session_id) is None:
        return JSONResponse([])

    messages = store.load_messages(session_id)
    if not messages:
        return JSONResponse([])

    events = _messages_to_events(messages)
    return JSONResponse(events)


def _messages_to_events(messages: list) -> list[dict]:
    """Convert pydantic-ai message history to SSE event format."""
    from pydantic_ai.messages import (
        ModelRequest,
        ModelResponse,
        TextPart,
        ToolCallPart,
        ToolReturnPart,
        UserPromptPart,
    )

    events: list[dict] = []

    for msg in messages:
        if isinstance(msg, ModelRequest):
            for part in msg.parts:
                if isinstance(part, UserPromptPart):
                    events.append({"type": "user_message", "data": part.content})
                elif isinstance(part, ToolReturnPart):
                    events.append({
                        "type": "tool_end",
                        "data": {
                            "name": part.tool_name,
                            "output": str(part.content)[:2000] if part.content else "",
                        },
                    })
        elif isinstance(msg, ModelResponse):
            for part in msg.parts:
                if isinstance(part, TextPart):
                    events.append({"type": "answer", "data": part.content})
                elif isinstance(part, ToolCallPart):
                    events.append({
                        "type": "tool_start",
                        "data": {
                            "name": part.tool_name,
                            "args": part.args_as_dict() if hasattr(part, 'args_as_dict') else {},
                        },
                    })

    return events


# ---------------------------------------------------------------------------
# Temporal endpoint
# ---------------------------------------------------------------------------


async def temporal_start(request: Request) -> JSONResponse:
    """Start an agent workflow via Temporal.

    Requires the gateway to have been started with ``--temporal``.
    Returns 503 if Temporal is not enabled or connected.
    """
    if not hasattr(request.app.state, "temporal_client") or not request.app.state.temporal_client:
        return JSONResponse(
            {"error": "Temporal not enabled. Start gateway with --temporal"},
            status_code=503,
        )

    tenant_id, err = _safe_resolve_tenant(request)
    if err:
        return err

    body = await request.json()
    question = body.get("question", "")
    session_id = body.get("session_id", "default")
    if not question:
        return JSONResponse({"error": "question is required"}, status_code=400)
    if not _validate_session_id(session_id):
        return JSONResponse({"error": "invalid session_id"}, status_code=400)

    from seeknal.ask.gateway.temporal import AgentWorkflowInput, AgentWorkflow

    # Project path: request body > worker_project_path > app config
    project_path = str(
        body.get("project_path")
        or getattr(request.app.state, "worker_project_path", None)
        or request.app.state.project_path
    )

    # Push URL: request body > app config (allows external services to override SSE delivery)
    push_url = (
        body.get("push_url")
        or getattr(request.app.state, "callback_base_url", None)
    )
    api_key = (
        body.get("api_key")
        or getattr(request.app.state, "callback_auth_token", None)
    )

    # Task queue: request body override > tenant-derived > app config fallback.
    # Tenant routing is the normal path; the body.task_queue override is an
    # escape hatch for internal clients that want to bypass it.
    task_queue = (
        body.get("task_queue")
        or task_queue_for_tenant(tenant_id)
    )
    workflow_id = make_workflow_id(tenant_id, session_id)

    client = request.app.state.temporal_client
    handle = await client.start_workflow(
        AgentWorkflow.run,
        AgentWorkflowInput(
            session_id=session_id,
            question=question,
            project_path=project_path,
            callback_url=push_url,
            callback_auth_token=api_key,
            tenant_id=tenant_id,
        ),
        id=workflow_id,
        task_queue=task_queue,
    )

    return JSONResponse({
        "workflow_id": handle.id,
        "session_id": session_id,
    })


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------


async def chat_ui(request: Request) -> FileResponse:
    """Serve the chat UI HTML file."""
    static_dir = Path(__file__).parent / "static"
    return FileResponse(static_dir / "chat.html", media_type="text/html")


async def upload_file(request: Request) -> JSONResponse:
    """Accept a multipart file upload, stage it on disk, return a reference path.

    The staged file is written under
    ``{project}/target/ask_ingest/_staging/{tenant}/{uuid}/{filename}`` and
    the returned ``path`` can be passed directly to the ``read_tabular``
    tool. Tenant is resolved via the standard ``X-Tenant-ID`` header path
    so uploads from different tenants stay isolated on disk.
    """
    import uuid as _uuid

    tenant_id, err = _safe_resolve_tenant(request)
    if err:
        return err

    project_path_raw = getattr(request.app.state, "project_path", None)
    if not project_path_raw:
        return JSONResponse(
            {"error": "upload requires gateway to be started with --project"},
            status_code=503,
        )
    project_path = Path(project_path_raw)

    content_type = request.headers.get("content-type", "")
    if "multipart/form-data" not in content_type.lower():
        return JSONResponse(
            {"error": "content-type must be multipart/form-data"},
            status_code=400,
        )

    try:
        form = await request.form()
    except Exception as exc:
        return JSONResponse({"error": f"invalid form data: {exc}"}, status_code=400)

    upload = form.get("file")
    if upload is None or not hasattr(upload, "read") or not hasattr(upload, "filename"):
        return JSONResponse(
            {"error": "no 'file' field in multipart form"},
            status_code=400,
        )

    original_name = Path(upload.filename or "upload").name
    suffix = Path(original_name).suffix.lower()
    is_image = suffix in _UPLOAD_IMAGE_SUFFIXES
    if suffix not in _UPLOAD_ALLOWED_SUFFIXES and not is_image:
        return JSONResponse(
            {
                "error": (
                    f"unsupported file extension '{suffix}'. "
                    f"Allowed: "
                    f"{', '.join(sorted(_UPLOAD_ALLOWED_SUFFIXES | _UPLOAD_IMAGE_SUFFIXES))}"
                ),
            },
            status_code=400,
        )

    # Images get a tighter size cap because Gemini vision rejects very large
    # payloads and it keeps us honest about phone-camera screenshots.
    size_cap = _IMAGE_MAX_BYTES if is_image else _UPLOAD_MAX_BYTES

    staging_dir = (
        project_path
        / "target"
        / "ask_ingest"
        / "_staging"
        / tenant_id
        / _uuid.uuid4().hex[:12]
    )
    staging_dir.mkdir(parents=True, exist_ok=True)
    staged_path = staging_dir / original_name

    total = 0
    try:
        with staged_path.open("wb") as fh:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > size_cap:
                    fh.close()
                    staged_path.unlink(missing_ok=True)
                    cap_mb = size_cap / 1024 / 1024
                    return JSONResponse(
                        {"error": f"file exceeds {cap_mb:.0f} MB limit"},
                        status_code=413,
                    )
                fh.write(chunk)
    except Exception as exc:
        staged_path.unlink(missing_ok=True)
        return JSONResponse({"error": f"failed to stage upload: {exc}"}, status_code=500)
    finally:
        try:
            await upload.close()
        except Exception:
            pass

    return JSONResponse(
        {
            "path": str(staged_path),
            "filename": original_name,
            "size": total,
            "kind": "image" if is_image else "tabular",
            "next": (
                "POST /record with {\"text\": \"ingest the image at "
                f"{staged_path}\"}} to route into the record-entry skill."
                if is_image
                else "Pass the path to read_tabular / write_ingested_table via "
                "the ask agent."
            ),
        }
    )


async def post_record(request: Request) -> JSONResponse:
    """Accept a free-form record text (or image-path prompt) and run the agent.

    Payload: {"text": "/record fitra, 1 mie ayam", "session_id": "..."}

    The agent will route the request through the ``record-entry`` skill —
    parsing the text with ``parse_record`` or reading any image path via
    ``extract_from_image``, then asking the user until the draft is
    complete, then writing via ``write_ingested_table``.
    """
    tenant_id, err = _safe_resolve_tenant(request)
    if err:
        return err

    project_path_raw = getattr(request.app.state, "project_path", None)
    if not project_path_raw:
        return JSONResponse(
            {"error": "record requires gateway started with --project"},
            status_code=503,
        )

    try:
        body = await request.json()
    except Exception as exc:
        return JSONResponse({"error": f"invalid JSON: {exc}"}, status_code=400)

    text = (body.get("text") or "").strip()
    session_id = body.get("session_id", "default")
    if not text:
        return JSONResponse({"error": "text is required"}, status_code=400)
    if not _validate_session_id(session_id):
        return JSONResponse({"error": "invalid session_id"}, status_code=400)

    project_path = Path(project_path_raw)
    prompt = (
        "The user wants to record an event. Load the 'record-entry' skill "
        "and walk through parse → propose_record_table → ask_user (strict) "
        "→ write_ingested_table.\n\nUser input:\n"
        f"{text}"
    )

    events: list = []
    answer = ""
    async for event in _run_agent_streaming(
        project_path, session_id, prompt, tenant_id=tenant_id,
    ):
        events.append(event)
        if event["type"] == "answer":
            answer = event["data"]

    return JSONResponse({"answer": answer, "events": events})


async def publish_event_callback(request: Request) -> JSONResponse:
    """Receive streaming chunk from on-prem worker and publish to SSE.

    Called by the on-prem Temporal worker via HTTP POST for each streaming
    event (token, tool_start, tool_end, answer, done).
    Authenticated via shared secret (CALLBACK_AUTH_TOKEN env var).
    The worker sets ``X-Tenant-ID`` so events route to the right
    tenant-scoped subscribers.
    """
    # Authenticate callback request
    expected_token = getattr(request.app.state, "callback_auth_token", None)
    if expected_token:
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer ") or auth_header[7:] != expected_token:
            return JSONResponse({"error": "unauthorized"}, status_code=401)

    session_id = request.path_params["session_id"]
    if not _validate_session_id(session_id):
        return JSONResponse({"error": "invalid session_id"}, status_code=400)

    tenant_id, err = _safe_resolve_tenant(request)
    if err:
        return err

    body = await request.json()
    event_json = json.dumps(body)

    broadcaster = request.app.state.broadcaster
    await broadcaster.publish(session_id, event_json, tenant_id=tenant_id)

    return JSONResponse({"status": "published"})


def create_gateway_app(
    project_path: str | Path | None = None,
    lifespan: Callable | None = None,
    temporal_client: Any = None,
    redis_url: str | None = None,
    callback_base_url: str | None = None,
    callback_auth_token: str | None = None,
    sessions_dir: str | Path | None = None,
) -> Starlette:
    """Create the Starlette ASGI application.

    Args:
        project_path: Path to the seeknal project directory. Required for
            in-process agent execution (``/ask``, ``/ws``, Telegram). Pass
            ``None`` for backend-only mode (Temporal-only dispatch).
        lifespan: Optional async context manager for startup/shutdown hooks.
        temporal_client: Optional connected Temporal client for workflow
            submission via ``POST /temporal/start``.
        redis_url: Optional Redis URL for multi-replica mode.
        callback_base_url: Base URL for on-prem worker event callbacks.
        callback_auth_token: Shared secret for authenticating callback POSTs.
        sessions_dir: Optional direct path for session storage. When set,
            session files go here instead of ``<project>/.seeknal/sessions/``.
            Used in backend mode where no project is available.
    """
    # Backend-only mode: no project_path means no in-process agent execution.
    # Only Temporal dispatch, SSE fan-out, and session listing work.
    backend_only = project_path is None

    routes = [
        Route("/", chat_ui),
        Route("/health", health),
        Route("/sessions", list_sessions),
        Route("/sessions/{session_id}/history", session_history),
        Route("/temporal/start", temporal_start, methods=["POST"]),
        Route("/events/{session_id}", sse_endpoint),
        # Internal callback for on-prem worker to push streaming events
        Route(
            "/internal/events/{session_id}/publish",
            publish_event_callback,
            methods=["POST"],
        ),
    ]

    # In-process agent execution routes are only available when a project
    # is configured. In backend-only mode the client must use /temporal/start.
    if not backend_only:
        routes.insert(4, Route("/ask", ask_oneshot, methods=["POST"]))
        routes.append(Route("/upload", upload_file, methods=["POST"]))
        routes.append(Route("/record", post_record, methods=["POST"]))
        routes.append(WebSocketRoute("/ws/{session_id}", websocket_endpoint))

    # Mount static files if directory exists
    static_dir = Path(__file__).parent / "static"
    if static_dir.is_dir():
        routes.append(Mount("/static", StaticFiles(directory=str(static_dir)), name="static"))

    # Wrap user lifespan to include lock eviction task and Redis setup
    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def _lifespan(app):
        redis_broadcaster = None

        # Initialize Redis-backed components if redis_url is set
        if redis_url:
            from redis.asyncio import Redis
            from seeknal.ask.gateway.redis_backend import (
                RedisSSEBroadcaster,
            )

            redis_client = Redis.from_url(redis_url)
            redis_broadcaster = RedisSSEBroadcaster(redis_client)
            app.state.broadcaster = redis_broadcaster
            app.state.redis_client = redis_client
            app.state.redis_enabled = True
            if project_path is not None:
                app.state.pairing_store = FilePairingStore(Path(project_path).resolve())
                app.state.telegram_link_store = TelegramLinkStore(Path(project_path).resolve())
                app.state.public_session_store = PublicSessionStore(Path(project_path).resolve())
            else:
                pair_base = Path(app.state.sessions_dir).resolve().parent
                app.state.pairing_store = FilePairingStore(base_dir=pair_base)
                app.state.telegram_link_store = TelegramLinkStore(base_dir=pair_base)
                app.state.public_session_store = PublicSessionStore(base_dir=pair_base)
            await redis_broadcaster.start_listener()
        else:
            app.state.broadcaster = sse_broadcaster
            app.state.redis_client = None
            app.state.redis_enabled = False
            if project_path is not None:
                app.state.pairing_store = FilePairingStore(Path(project_path).resolve())
                app.state.telegram_link_store = TelegramLinkStore(Path(project_path).resolve())
                app.state.public_session_store = PublicSessionStore(Path(project_path).resolve())
            else:
                pair_base = Path(app.state.sessions_dir).resolve().parent
                app.state.pairing_store = FilePairingStore(base_dir=pair_base)
                app.state.telegram_link_store = TelegramLinkStore(base_dir=pair_base)
                app.state.public_session_store = PublicSessionStore(base_dir=pair_base)

        async def _eviction_loop():
            while True:
                await asyncio.sleep(300)  # every 5 minutes
                _evict_idle_locks()
                await app.state.pairing_store.cleanup_expired_codes()

        eviction_task = asyncio.create_task(_eviction_loop())
        try:
            if lifespan is not None:
                async with lifespan(app):
                    yield
            else:
                yield
        finally:
            eviction_task.cancel()
            try:
                await eviction_task
            except asyncio.CancelledError:
                pass
            if redis_broadcaster:
                await redis_broadcaster.stop_listener()
            if app.state.redis_client:
                await app.state.redis_client.close()

    app = Starlette(routes=routes, lifespan=_lifespan)
    app.state.project_path = str(project_path) if project_path is not None else None
    app.state.backend_only = backend_only
    # Resolve sessions dir for backend-only mode (no project path available).
    if sessions_dir is not None:
        app.state.sessions_dir = str(sessions_dir)
    elif backend_only:
        default_dir = Path.home() / ".seeknal" / "gateway-sessions"
        default_dir.mkdir(parents=True, exist_ok=True)
        app.state.sessions_dir = str(default_dir)
    else:
        app.state.sessions_dir = None
    app.state.callback_base_url = callback_base_url
    app.state.callback_auth_token = callback_auth_token
    if temporal_client is not None:
        app.state.temporal_client = temporal_client
    return app
