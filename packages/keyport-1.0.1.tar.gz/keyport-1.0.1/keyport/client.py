from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

from .exceptions import KeyPortAuthError, KeyPortConfigError, KeyPortError, KeyPortRateLimitError
from .types import LicenseDetailResponse, ValidateResponse


class KeyPort:
    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.keyport.sbs/api/v1",
        timeout: float = 10.0,
    ):
        if not api_key:
            raise KeyPortConfigError("KeyPort: api_key is required")
        self._client = httpx.Client(
            base_url=base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "keyport-python/1.0.0",
            },
        )

    @classmethod
    def from_config_file(cls, path: str | Path, **overrides: Any) -> "KeyPort":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        api_key = overrides["api_key"] if "api_key" in overrides else data.get("api_key")
        if not api_key:
            raise KeyPortConfigError("KeyPort config file must include api_key")
        base_url = overrides["base_url"] if "base_url" in overrides else data.get("base_url")
        timeout = overrides["timeout"] if "timeout" in overrides else data.get("timeout")
        return cls(
            api_key,
            base_url=base_url or "https://api.keyport.sbs/api/v1",
            timeout=float(timeout) if timeout is not None else 10.0,
        )

    def validate(self, license_key: str, version: str | None = None, device_id: str | None = None) -> ValidateResponse:
        if not license_key:
            raise KeyPortConfigError("license_key is required")
        payload: dict[str, Any] = {"license_key": license_key}
        if version:
            payload["version"] = version
        if device_id:
            payload["device_id"] = device_id
        return self._request("POST", "/validate", payload)

    def get_license(self, license_key: str) -> LicenseDetailResponse:
        if not license_key:
            raise KeyPortConfigError("license_key is required")
        return self._request("GET", f"/license/{quote(license_key, safe='')}")

    def _request(self, method: str, path: str, data: dict[str, Any] | None = None):
        try:
            response = self._client.request(method, path, json=data)
            if response.status_code == 401:
                raise KeyPortAuthError()
            if response.status_code == 429:
                try:
                    retry_after = int(response.headers.get("Retry-After", "60"))
                except ValueError:
                    retry_after = 60
                message = response.json().get("message", "Rate limit exceeded") if response.headers.get("content-type", "").startswith("application/json") else "Rate limit exceeded"
                raise KeyPortRateLimitError(retry_after, message)
            response.raise_for_status()
            return response.json()
        except httpx.TimeoutException as exc:
            raise KeyPortError("Request timed out", 408, "timeout") from exc
        except httpx.HTTPError as exc:
            if isinstance(exc, KeyPortError):
                raise
            raise KeyPortError(str(exc)) from exc

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "KeyPort":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
