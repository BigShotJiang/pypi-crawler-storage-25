class KeyPortError(Exception):
    def __init__(self, message: str, status: int | None = None, code: str | None = None):
        super().__init__(message)
        self.status = status
        self.code = code


class KeyPortAuthError(KeyPortError):
    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, 401, "invalid_api_key")


class KeyPortRateLimitError(KeyPortError):
    def __init__(self, retry_after: int, message: str = "Rate limit exceeded"):
        super().__init__(message, 429, "rate_limit_exceeded")
        self.retry_after = retry_after


class KeyPortConfigError(KeyPortError):
    def __init__(self, message: str):
        super().__init__(message, None, "config_error")
