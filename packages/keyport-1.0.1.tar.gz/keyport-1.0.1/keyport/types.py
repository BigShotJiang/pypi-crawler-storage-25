from __future__ import annotations

from typing import Any, Literal, TypedDict

LicenseStatus = Literal[
    "active",
    "expired",
    "revoked",
    "license_not_found",
    "ip_blocked",
    "ip_not_registered",
    "ip_limit_reached",
    "invalid_api_key",
    "product_not_found",
    "product_archived",
    "product_disabled",
    "org_suspended",
    "billing_suspended",
    "rate_limit_exceeded",
]


class ValidateResponse(TypedDict, total=False):
    valid: bool
    status: LicenseStatus
    expires: str | None
    ip_registered: bool
    ip_count: int | None
    max_ips: int | None
    version: str | None
    version_valid: bool | None
    custom: dict[str, Any] | None
    signature: str | None
    message: str
    retry_after: int


class LicenseDetailResponse(TypedDict):
    id: str
    organization_id: str
    product_id: str
    global_customer_id: str
    license_key: str
    status: str
    expires_at: str | None
    is_lifetime: bool
    ip_system_enabled: bool
    max_ips: int | None
    current_unique_ip_count: int
    notes: str | None
    version_pin_mode: str | None
    version_pinned: str | None
    version_range_min: str | None
    version_range_max: str | None
    revoked_at: str | None
    created_at: str
    updated_at: str
    customer_email: str | None
    customer_name: str | None
    customer_discord_id: str | None
