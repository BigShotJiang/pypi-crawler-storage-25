# keyport-python

Official Python SDK for the live KeyPort public API.

## Install

```bash
pip install keyport
```

## Direct API key usage

```python
from keyport import KeyPort

client = KeyPort("kp_live_xxx")
result = client.validate("LICENSE-KEY", version="1.2.0")
```

## Config file usage

```json
{
  "api_key": "kp_live_xxx",
  "base_url": "https://api.keyport.sbs/api/v1",
  "timeout": 10
}
```

```python
from keyport import KeyPort

client = KeyPort.from_config_file("keyport.json")
detail = client.get_license("LICENSE-KEY")
```

## API key in code, rest from config

```python
from keyport import KeyPort

client = KeyPort.from_config_file(
    "keyport.json",
    api_key="kp_live_from_env",
)
```

## Supported operations

- `validate(license_key, version=None, device_id=None)`
- `get_license(license_key)`
