from pathlib import Path

from keyport.client import KeyPort
from keyport.exceptions import KeyPortConfigError


def test_config_loader_requires_api_key(tmp_path: Path) -> None:
    path = tmp_path / "config.json"
    path.write_text('{"base_url":"https://api.keyport.sbs/api/v1"}', encoding="utf-8")
    try:
        KeyPort.from_config_file(path)
        assert False
    except KeyPortConfigError:
        assert True


def test_config_loader_builds_client(tmp_path: Path) -> None:
    path = tmp_path / "config.json"
    path.write_text('{"api_key":"kp_live_test"}', encoding="utf-8")

    client = KeyPort.from_config_file(path)

    assert isinstance(client, KeyPort)


def test_config_loader_allows_api_key_override(tmp_path: Path) -> None:
    path = tmp_path / "config.json"
    path.write_text(
        '{"api_key":"kp_live_file","base_url":"https://example.com/api/v1","timeout":5}',
        encoding="utf-8",
    )

    client = KeyPort.from_config_file(path, api_key="kp_live_override")

    assert isinstance(client, KeyPort)
