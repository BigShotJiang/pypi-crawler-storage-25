"""Tests for chisel.storage — all CRUD operations per table."""

import sqlite3
import time


class TestDatabaseInit:
    def test_creates_database_file(self, storage):
        assert storage.db_path.exists()

    def test_wal_mode(self, storage):
        conn = sqlite3.connect(str(storage.db_path))
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        conn.close()
        assert mode == "wal"

    def test_all_tables_exist(self, storage):
        expected = {
            "code_units", "test_units", "test_edges", "commits",
            "commit_files", "blame_cache", "co_changes", "churn_stats",
            "file_hashes", "test_results", "meta", "branch_co_changes",
            "file_locks",
        }
        conn = sqlite3.connect(str(storage.db_path))
        tables = {
            r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        conn.close()
        assert expected.issubset(tables)

    def test_indexes_exist(self, storage):
        expected_indexes = {
            "idx_code_units_file", "idx_test_units_file", "idx_test_edges_code",
            "idx_commit_files_file", "idx_blame_cache_hash", "idx_churn_stats_file",
            "idx_co_changes_file_b",
        }
        conn = sqlite3.connect(str(storage.db_path))
        indexes = {
            r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='index'"
            ).fetchall()
        }
        conn.close()
        assert expected_indexes.issubset(indexes)


class TestCodeUnits:
    def test_upsert_and_get(self, storage):
        storage.upsert_code_unit("f.py:foo:func", "f.py", "foo", "func", 1, 10, "abc")
        unit = storage.get_code_unit("f.py:foo:func")
        assert unit["name"] == "foo"
        assert unit["unit_type"] == "func"
        assert unit["line_start"] == 1
        assert unit["line_end"] == 10

    def test_upsert_overwrites(self, storage):
        storage.upsert_code_unit("f.py:foo:func", "f.py", "foo", "func", 1, 10, "abc")
        storage.upsert_code_unit("f.py:foo:func", "f.py", "foo", "func", 5, 20, "def")
        unit = storage.get_code_unit("f.py:foo:func")
        assert unit["line_start"] == 5
        assert unit["content_hash"] == "def"

    def test_get_by_file(self, storage):
        storage.upsert_code_unit("f.py:a:func", "f.py", "a", "func")
        storage.upsert_code_unit("f.py:b:func", "f.py", "b", "func")
        storage.upsert_code_unit("g.py:c:func", "g.py", "c", "func")
        units = storage.get_code_units_by_file("f.py")
        assert len(units) == 2

    def test_delete_by_file(self, storage):
        storage.upsert_code_unit("f.py:a:func", "f.py", "a", "func")
        storage.upsert_code_unit("f.py:b:func", "f.py", "b", "func")
        storage.delete_code_units_by_file("f.py")
        assert storage.get_code_units_by_file("f.py") == []

    def test_get_nonexistent(self, storage):
        assert storage.get_code_unit("nope") is None


class TestTestUnits:
    def test_upsert_and_get(self, storage):
        storage.upsert_test_unit("t.py:test_x", "t.py", "test_x", "pytest", 1, 5, "h1")
        unit = storage.get_test_unit("t.py:test_x")
        assert unit["framework"] == "pytest"

    def test_get_all(self, storage):
        storage.upsert_test_unit("t1.py:a", "t1.py", "a", "pytest")
        storage.upsert_test_unit("t2.py:b", "t2.py", "b", "jest")
        all_units = storage.get_all_test_units()
        assert len(all_units) == 2


class TestTestEdges:
    def test_upsert_and_get_for_test(self, storage):
        storage.upsert_code_unit("c1", "f.py", "foo", "func")
        storage.upsert_test_unit("t1", "t.py", "test_foo")
        storage.upsert_test_edge("t1", "c1", "import", 2.0)
        edges = storage.get_edges_for_test("t1")
        assert len(edges) == 1
        assert edges[0]["weight"] == 2.0

    def test_get_for_code(self, storage):
        storage.upsert_code_unit("c1", "f.py", "foo", "func")
        storage.upsert_test_unit("t1", "t.py", "test_a")
        storage.upsert_test_unit("t2", "t.py", "test_b")
        storage.upsert_test_edge("t1", "c1", "call")
        storage.upsert_test_edge("t2", "c1", "import")
        edges = storage.get_edges_for_code("c1")
        assert len(edges) == 2

    def test_upsert_updates_weight(self, storage):
        storage.upsert_code_unit("c1", "f.py", "foo", "func")
        storage.upsert_test_unit("t1", "t.py", "test_a")
        storage.upsert_test_edge("t1", "c1", "call", 1.0)
        storage.upsert_test_edge("t1", "c1", "call", 5.0)
        edges = storage.get_edges_for_test("t1")
        assert edges[0]["weight"] == 5.0


class TestCommits:
    def test_upsert_and_get(self, storage):
        storage.upsert_commit("abc123", "Alice", "a@b.com", "2026-01-01", "fix bug")
        c = storage.get_commit("abc123")
        assert c["author"] == "Alice"
        assert c["message"] == "fix bug"


class TestCommitFiles:
    def test_upsert_and_get_for_file(self, storage):
        storage.upsert_commit("abc", "A", "a@b.com", "2026-01-01", "msg")
        storage.upsert_commit_file("abc", "f.py", 10, 3)
        commits = storage.get_commits_for_file("f.py")
        assert len(commits) == 1
        assert commits[0]["insertions"] == 10
        assert commits[0]["deletions"] == 3

    def test_multiple_commits_for_file(self, storage):
        storage.upsert_commit("a", date="2026-01-01")
        storage.upsert_commit("b", date="2026-02-01")
        storage.upsert_commit_file("a", "f.py", 5, 2)
        storage.upsert_commit_file("b", "f.py", 3, 1)
        commits = storage.get_commits_for_file("f.py")
        assert len(commits) == 2
        assert commits[0]["date"] > commits[1]["date"]


class TestBlameCache:
    def test_store_and_get(self, storage):
        storage.store_blame("f.py", 1, 10, "abc", "Alice", "a@b.com", "2026-01-01", "hash1")
        blocks = storage.get_blame("f.py", "hash1")
        assert len(blocks) == 1
        assert blocks[0]["author"] == "Alice"

    def test_get_wrong_hash_returns_empty(self, storage):
        storage.store_blame("f.py", 1, 10, "abc", "Alice", "a@b.com", "2026-01-01", "hash1")
        assert storage.get_blame("f.py", "wrong_hash") == []

    def test_invalidate(self, storage):
        storage.store_blame("f.py", 1, 10, "abc", "Alice", "a@b.com", "2026-01-01", "hash1")
        storage.invalidate_blame("f.py")
        assert storage.get_blame("f.py", "hash1") == []

    def test_upsert_same_line_start(self, storage):
        storage.store_blame("f.py", 1, 5, "abc", "Alice", "a@b.com", "2026-01-01", "h1")
        storage.store_blame("f.py", 1, 8, "def", "Bob", "b@b.com", "2026-02-01", "h2")
        blocks = storage.get_blame("f.py", "h2")
        assert len(blocks) == 1
        assert blocks[0]["author"] == "Bob"


class TestCoChanges:
    def test_upsert_and_get(self, storage):
        storage.upsert_co_change("a.py", "b.py", 5, "abc123")
        results = storage.get_co_changes("a.py", min_count=3)
        assert len(results) == 1
        assert results[0]["co_commit_count"] == 5

    def test_min_count_filter(self, storage):
        storage.upsert_co_change("a.py", "b.py", 2)
        assert storage.get_co_changes("a.py", min_count=3) == []

    def test_sorted_pair_keys(self, storage):
        storage.upsert_co_change("z.py", "a.py", 4)
        results = storage.get_co_changes("z.py", min_count=1)
        assert len(results) == 1
        assert results[0]["file_a"] == "a.py"

    def test_query_from_either_side(self, storage):
        storage.upsert_co_change("a.py", "b.py", 5)
        assert len(storage.get_co_changes("b.py", min_count=1)) == 1


class TestMeta:
    def test_get_set(self, storage):
        assert storage.get_meta("k") is None
        storage.set_meta("k", "v")
        assert storage.get_meta("k") == "v"
        storage.set_meta("k", "v2")
        assert storage.get_meta("k") == "v2"

    def test_get_co_change_query_min_defaults(self, storage):
        assert storage.get_co_change_query_min() == 3

    def test_get_co_change_query_min_from_meta(self, storage):
        storage.set_meta("co_change_query_min", "2")
        assert storage.get_co_change_query_min() == 2

    def test_co_changes_visible_when_meta_aligns(self, storage):
        storage.upsert_co_change("a.py", "b.py", 2)
        storage.set_meta("co_change_query_min", "2")
        qm = storage.get_co_change_query_min()
        assert len(storage.get_co_changes("a.py", min_count=qm)) == 1


class TestChurnStats:
    def test_upsert_and_get(self, storage):
        storage.upsert_churn_stat("f.py", "foo", 10, 3, 50, 20, "2026-01-01", 0.82)
        stat = storage.get_churn_stat("f.py", "foo")
        assert stat["commit_count"] == 10
        assert stat["churn_score"] == 0.82

    def test_file_level_stat(self, storage):
        storage.upsert_churn_stat("f.py", None, 5, 2, 30, 10, "2026-01-01", 0.5)
        stat = storage.get_churn_stat("f.py")
        assert stat["commit_count"] == 5

    def test_get_all(self, storage):
        storage.upsert_churn_stat("a.py", "", 5, 2, 10, 5, "2026-01-01", 0.8)
        storage.upsert_churn_stat("b.py", "", 3, 1, 5, 2, "2026-01-01", 0.3)
        all_stats = storage.get_all_churn_stats()
        assert len(all_stats) == 2
        assert all_stats[0]["churn_score"] >= all_stats[1]["churn_score"]

    def test_get_all_for_file(self, storage):
        storage.upsert_churn_stat("f.py", "", 5, 2, 10, 5, "2026-01-01", 0.8)
        storage.upsert_churn_stat("f.py", "foo", 3, 1, 5, 2, "2026-01-01", 0.3)
        storage.upsert_churn_stat("g.py", "", 1, 1, 1, 0, "2026-01-01", 0.1)
        stats = storage.get_all_churn_stats("f.py")
        assert len(stats) == 2


class TestTestResults:
    def test_record_and_query(self, storage):
        storage.record_test_result("t.py:test_a", True, duration_ms=120)
        storage.record_test_result("t.py:test_a", False, duration_ms=80)
        rates = storage.get_test_failure_rates()
        assert len(rates) == 1
        assert rates[0]["test_id"] == "t.py:test_a"
        assert rates[0]["total_runs"] == 2
        assert rates[0]["failures"] == 1

    def test_all_passed(self, storage):
        storage.record_test_result("t.py:test_b", True)
        storage.record_test_result("t.py:test_b", True)
        rates = storage.get_test_failure_rates()
        assert rates[0]["failures"] == 0

    def test_multiple_tests(self, storage):
        storage.record_test_result("t1", True)
        storage.record_test_result("t2", False)
        storage.record_test_result("t2", False)
        rates = {r["test_id"]: r for r in storage.get_test_failure_rates()}
        assert rates["t1"]["failures"] == 0
        assert rates["t2"]["failures"] == 2

    def test_empty_results(self, storage):
        assert storage.get_test_failure_rates() == []

    def test_cleanup_orphaned_results(self, storage):
        # Record result for a test that exists
        storage.upsert_test_unit("t.py:test_a", "t.py", "test_a", "pytest")
        storage.record_test_result("t.py:test_a", True)
        # Record result for a test that does NOT exist
        storage.record_test_result("gone:test_z", False)
        cleaned = storage.cleanup_orphaned_test_results()
        assert cleaned == 1
        # Existing test's results should remain
        rates = storage.get_test_failure_rates()
        assert len(rates) == 1
        assert rates[0]["test_id"] == "t.py:test_a"

    def test_cleanup_no_orphans(self, storage):
        storage.upsert_test_unit("t.py:test_a", "t.py", "test_a", "pytest")
        storage.record_test_result("t.py:test_a", True)
        assert storage.cleanup_orphaned_test_results() == 0


class TestStats:
    def test_empty_db(self, storage):
        stats = storage.get_stats()
        assert stats["code_units"] == 0
        assert stats["test_results"] == 0
        assert len(stats) == 12

    def test_counts_data(self, storage):
        storage.upsert_code_unit("f.py:foo:func", "f.py", "foo", "func")
        storage.upsert_code_unit("f.py:bar:func", "f.py", "bar", "func")
        storage.upsert_test_unit("t.py:test_a", "t.py", "test_a", "pytest")
        stats = storage.get_stats()
        assert stats["code_units"] == 2
        assert stats["test_units"] == 1


class TestHasAnalysisData:
    def test_empty_db(self, storage):
        assert storage.has_analysis_data() is False

    def test_with_code_units(self, storage):
        storage.upsert_code_unit("f.py:foo:func", "f.py", "foo", "func")
        assert storage.has_analysis_data() is True


class TestFileHashes:
    def test_set_and_get(self, storage):
        storage.set_file_hash("f.py", "abc123")
        assert storage.get_file_hash("f.py") == "abc123"

    def test_update(self, storage):
        storage.set_file_hash("f.py", "old")
        storage.set_file_hash("f.py", "new")
        assert storage.get_file_hash("f.py") == "new"

    def test_get_nonexistent(self, storage):
        assert storage.get_file_hash("nope.py") is None


class TestBatchQueries:
    def test_get_edges_for_code_batch(self, storage):
        storage.upsert_code_unit("c1", "f.py", "foo", "func")
        storage.upsert_code_unit("c2", "g.py", "bar", "func")
        storage.upsert_test_unit("t1", "t.py", "test_foo")
        storage.upsert_test_unit("t2", "t.py", "test_bar")
        storage.upsert_test_unit("t3", "t.py", "test_both")
        storage.upsert_test_edge("t1", "c1", "import", 1.0)
        storage.upsert_test_edge("t3", "c1", "call", 0.5)
        storage.upsert_test_edge("t2", "c2", "import", 0.8)

        result = storage.get_edges_for_code_batch(["c1", "c2"])
        assert set(result.keys()) == {"c1", "c2"}
        assert len(result["c1"]) == 2
        assert len(result["c2"]) == 1
        assert result["c2"][0]["test_id"] == "t2"

    def test_get_edges_for_code_batch_empty(self, storage):
        assert storage.get_edges_for_code_batch([]) == {}

    def test_get_edges_for_code_batch_missing_ids(self, storage):
        result = storage.get_edges_for_code_batch(["no_such_id", "also_missing"])
        assert result == {"no_such_id": [], "also_missing": []}

    def test_get_code_units_by_files_batch(self, storage):
        storage.upsert_code_unit("f.py:a:func", "f.py", "a", "func")
        storage.upsert_code_unit("f.py:b:class", "f.py", "b", "class")
        storage.upsert_code_unit("g.py:c:func", "g.py", "c", "func")

        result = storage.get_code_units_by_files_batch(["f.py", "g.py"])
        assert set(result.keys()) == {"f.py", "g.py"}
        assert len(result["f.py"]) == 2
        assert len(result["g.py"]) == 1
        names = {u["name"] for u in result["f.py"]}
        assert names == {"a", "b"}

    def test_get_co_changes_batch(self, storage):
        storage.upsert_co_change("a.py", "b.py", 5, "hash1")
        storage.upsert_co_change("a.py", "c.py", 4, "hash2")
        storage.upsert_co_change("b.py", "d.py", 3, "hash3")

        result = storage.get_co_changes_batch(["a.py", "b.py"], min_count=3)
        assert set(result.keys()) == {"a.py", "b.py"}
        # a.py co-changes with b.py (5) and c.py (4)
        assert len(result["a.py"]) == 2
        # b.py co-changes with a.py (5) and d.py (3)
        assert len(result["b.py"]) == 2
        counts_a = sorted([r["co_commit_count"] for r in result["a.py"]], reverse=True)
        assert counts_a == [5, 4]

    def test_get_churn_stats_batch(self, storage):
        storage.upsert_churn_stat("a.py", "", 10, 3, 50, 20, "2026-01-01", 0.82)
        storage.upsert_churn_stat("b.py", "", 5, 2, 30, 10, "2026-01-01", 0.45)
        # Function-level stat should be ignored (unit_name != "")
        storage.upsert_churn_stat("a.py", "foo", 3, 1, 10, 5, "2026-01-01", 0.3)

        result = storage.get_churn_stats_batch(["a.py", "b.py", "missing.py"])
        assert set(result.keys()) == {"a.py", "b.py", "missing.py"}
        assert result["a.py"]["churn_score"] == 0.82
        assert result["a.py"]["commit_count"] == 10
        assert result["b.py"]["churn_score"] == 0.45
        assert result["missing.py"] is None

    def test_get_blame_batch(self, storage):
        storage.store_blame("f.py", 1, 10, "abc", "Alice", "a@b.com", "2026-01-01", "h1")
        storage.store_blame("f.py", 11, 20, "def", "Bob", "b@b.com", "2026-02-01", "h1")
        storage.store_blame("g.py", 1, 5, "ghi", "Carol", "c@b.com", "2026-01-15", "h2")

        result = storage.get_blame_batch([("f.py", "h1"), ("g.py", "h2")])
        assert set(result.keys()) == {"f.py", "g.py"}
        assert len(result["f.py"]) == 2
        assert result["f.py"][0]["author"] == "Alice"
        assert result["f.py"][1]["author"] == "Bob"
        assert len(result["g.py"]) == 1
        assert result["g.py"][0]["author"] == "Carol"


class TestFileLocks:
    def test_acquire_and_release(self, storage):
        acquired, holder, expires_at = storage.acquire_file_lock("a.py", "agent-1")
        assert acquired is True
        assert holder is None
        assert expires_at > time.time()

        lock = storage.get_file_lock("a.py")
        assert lock is not None
        assert lock["agent_id"] == "agent-1"

        released = storage.release_file_lock("a.py", "agent-1")
        assert released is True
        assert storage.get_file_lock("a.py") is None

    def test_cannot_acquire_someone_elses_lock(self, storage):
        storage.acquire_file_lock("a.py", "agent-1")
        acquired, holder, _ = storage.acquire_file_lock("a.py", "agent-2")
        assert acquired is False
        assert holder == "agent-1"

    def test_reacquire_after_release(self, storage):
        storage.acquire_file_lock("a.py", "agent-1")
        storage.release_file_lock("a.py", "agent-1")
        acquired, holder, _ = storage.acquire_file_lock("a.py", "agent-2")
        assert acquired is True
        assert holder is None

    def test_refresh_extends_ttl(self, storage):
        storage.acquire_file_lock("a.py", "agent-1", ttl=10)
        ok, new_exp = storage.refresh_file_lock("a.py", "agent-1", ttl=300)
        assert ok is True
        assert new_exp > time.time() + 100

    def test_refresh_wrong_agent_fails(self, storage):
        storage.acquire_file_lock("a.py", "agent-1", ttl=10)
        ok, _ = storage.refresh_file_lock("a.py", "agent-2", ttl=300)
        assert ok is False

    def test_release_wrong_agent_fails(self, storage):
        storage.acquire_file_lock("a.py", "agent-1")
        released = storage.release_file_lock("a.py", "agent-2")
        assert released is False
        assert storage.get_file_lock("a.py") is not None

    def test_expired_locks_cleaned_up(self, storage):
        storage.acquire_file_lock("a.py", "agent-1", ttl=1)
        time.sleep(1.1)
        assert storage.get_file_lock("a.py") is None

    def test_list_all_locks(self, storage):
        storage.acquire_file_lock("a.py", "agent-1")
        storage.acquire_file_lock("b.py", "agent-2")
        locks = storage.list_file_locks()
        assert len(locks) == 2

    def test_list_locks_filtered_by_agent(self, storage):
        storage.acquire_file_lock("a.py", "agent-1")
        storage.acquire_file_lock("b.py", "agent-2")
        locks = storage.list_file_locks("agent-1")
        assert len(locks) == 1
        assert locks[0]["file_path"] == "a.py"

    def test_acquire_with_purpose(self, storage):
        storage.acquire_file_lock("a.py", "agent-1", purpose="refactoring auth")
        lock = storage.get_file_lock("a.py")
        assert lock["purpose"] == "refactoring auth"

    def test_reacquire_same_agent_extends(self, storage):
        """Same agent re-acquiring should extend TTL (upsert behavior)."""
        storage.acquire_file_lock("a.py", "agent-1", ttl=10)
        acquired, holder, expires_at_1 = storage.acquire_file_lock(
            "a.py", "agent-1", ttl=300,
        )
        assert acquired is True
        assert holder is None
        assert expires_at_1 > time.time() + 100


class TestOptimize:
    def test_optimize_does_not_corrupt_db(self, storage):
        storage.upsert_code_unit("u1", "src/app.py", "App", "class",
                                  line_start=1, line_end=10)
        result = storage.optimize(wal_size_threshold_bytes=0)
        assert result["optimized"] is True
        # Ensure data is still readable after optimize / potential VACUUM
        units = storage.get_code_units_by_file("src/app.py")
        assert len(units) == 1
        assert units[0]["name"] == "App"
