import pytest
import math
import numpy as np
from raygeo import Geometry
from raygeo.path import (
    get_total_distance_from_array,
    extract_overcut_rows,
    _segment_length_from_row,
    _partial_segment_from_row,
)

from raygeo import (
    CMD_TYPE_MOVE,
    CMD_TYPE_LINE,
    CMD_TYPE_ARC,
    CMD_TYPE_BEZIER,
    COL_TYPE,
    COL_X,
    COL_Y,
    COL_Z,
    COL_I,
    COL_J,
    COL_CW,
    GEO_ARRAY_COLS,
)


@pytest.fixture
def empty_geometry():
    return Geometry()


@pytest.fixture
def sample_geometry():
    geo = Geometry()
    geo.move_to(0, 0)
    geo.line_to(10, 10)
    geo.arc_to(20, 0, i=5, j=-10)
    return geo


def test_initialization(empty_geometry):
    assert len(empty_geometry) == 0
    assert empty_geometry.last_move_to == (0.0, 0.0, 0.0)
    assert empty_geometry.uniform_scalable is True


def test_add_commands(empty_geometry):
    empty_geometry.move_to(5, 5)
    assert len(empty_geometry) == 1
    empty_geometry.line_to(10, 10)
    assert len(empty_geometry) == 2
    empty_geometry._sync_to_numpy()
    assert empty_geometry.data is not None
    assert empty_geometry.data[0, COL_TYPE] == CMD_TYPE_MOVE
    assert empty_geometry.data[1, COL_TYPE] == CMD_TYPE_LINE


def test_simplify_wrapper(sample_geometry):
    """Tests that simplify returns a valid Geometry."""
    sample_geometry._sync_to_numpy()
    result = sample_geometry.simplify(tolerance=0.5)
    assert isinstance(result, Geometry)


def test_clear_commands(sample_geometry):
    sample_geometry.clear()
    assert len(sample_geometry) == 0
    assert sample_geometry.is_empty()


def test_move_to(sample_geometry):
    sample_geometry.move_to(15, 15)
    sample_geometry._sync_to_numpy()
    assert sample_geometry.data is not None
    last_row = sample_geometry.data[-1]
    assert last_row[COL_TYPE] == CMD_TYPE_MOVE
    assert (last_row[COL_X : COL_Z + 1] == (15.0, 15.0, 0.0)).all()


def test_line_to(sample_geometry):
    sample_geometry.line_to(20, 20)
    sample_geometry._sync_to_numpy()
    assert sample_geometry.data is not None
    last_row = sample_geometry.data[-1]
    assert last_row[COL_TYPE] == CMD_TYPE_LINE
    assert (last_row[COL_X : COL_Z + 1] == (20.0, 20.0, 0.0)).all()


def test_close_path(sample_geometry):
    sample_geometry.move_to(5, 5, -1.0)
    sample_geometry.close_path()
    sample_geometry._sync_to_numpy()
    assert sample_geometry.data is not None
    last_row = sample_geometry.data[-1]
    assert last_row[COL_TYPE] == CMD_TYPE_LINE
    assert (last_row[COL_X : COL_Z + 1] == sample_geometry.last_move_to).all()
    assert (last_row[COL_X : COL_Z + 1] == (5.0, 5.0, -1.0)).all()


def test_arc_to():
    geo = Geometry()
    geo.move_to(0, 0)
    geo.line_to(10, 10)
    geo.arc_to(20, 0, i=5, j=-10)
    geo.arc_to(5, 5, 2, 3, clockwise=False)
    geo._sync_to_numpy()
    assert geo.data is not None
    last_row = geo.data[-1]
    assert last_row[COL_TYPE] == CMD_TYPE_ARC
    assert (last_row[COL_X : COL_Z + 1] == (5.0, 5.0, 0.0)).all()
    assert last_row[6] == 0.0  # Clockwise is False


def test_bezier_to(empty_geometry):
    empty_geometry.bezier_to(10, 10, c1x=2, c1y=2, c2x=8, c2y=8)
    empty_geometry._sync_to_numpy()
    assert empty_geometry.data is not None
    last_row = empty_geometry.data[-1]
    assert last_row[COL_TYPE] == CMD_TYPE_BEZIER
    assert (last_row[1:4] == (10.0, 10.0, 0.0)).all()
    assert (last_row[4:8] == (2.0, 2.0, 8.0, 8.0)).all()


def test_serialization_deserialization(sample_geometry):
    geo_dict = sample_geometry.dump()
    new_geo = Geometry.from_dict(geo_dict)
    assert new_geo == sample_geometry


def test_copy_method(sample_geometry):
    """Tests the deep copy functionality of the Geometry class."""
    # Set a flag to ensure it's copied
    sample_geometry.uniform_scalable = False

    original_geo = sample_geometry
    copied_geo = original_geo.copy()

    # Check for initial equality and deep copy semantics
    assert copied_geo is not original_geo
    assert copied_geo == original_geo
    assert copied_geo.last_move_to == original_geo.last_move_to
    # Check that configuration flags are preserved
    assert copied_geo.uniform_scalable is False

    # Modify the original and check that the copy is unaffected
    original_geo.line_to(100, 100)
    assert copied_geo != original_geo
    assert len(copied_geo) == 3
    assert len(original_geo) == 4


def test_distance(sample_geometry):
    """
    Tests that the distance calculation correctly computes true arc length.
    """
    # The test must now expect the true distance, not an approximation.
    dist_line = math.hypot(10 - 0, 10 - 0)

    # Arc parameters for manual length calculation:
    # Center is (10,10) + (5,-10) = (15,0). Radius = dist from center to start.
    radius = math.hypot(10 - 15, 10 - 0)  # sqrt((-5)^2 + 10^2) = sqrt(125)
    start_angle = math.atan2(10 - 0, 10 - 15)  # atan2(10, -5)
    end_angle = math.atan2(0 - 0, 20 - 15)  # atan2(0, 5) -> 0

    # The default for arc_to is clockwise=True.
    # For a clockwise arc from a larger angle (start_angle in Q2) to a smaller
    # one (end_angle on the axis), the span is just the difference.
    angle_span = start_angle - end_angle
    dist_arc = radius * angle_span

    expected_dist = dist_line + dist_arc

    assert sample_geometry.distance() == pytest.approx(expected_dist)
    # Also test the query function directly
    assert get_total_distance_from_array(
        sample_geometry.data
    ) == pytest.approx(expected_dist)


def test_area():
    # Test case 1: Empty and open paths
    assert Geometry().area() == 0.0
    assert Geometry.from_points([(0, 0), (10, 10)], close=False).area() == 0.0

    # Test case 2: Simple 10x10 CCW square
    square = Geometry.from_points([(0, 0), (10, 0), (10, 10), (0, 10)])
    assert square.area() == pytest.approx(100.0)

    # Test case 3: Simple 10x10 CW square (should have same positive area)
    square_cw = Geometry.from_points([(0, 0), (0, 10), (10, 10), (10, 0)])
    assert square_cw.area() == pytest.approx(100.0)

    # Test case 4: Shape with a hole
    # Outer CCW square (0,0) -> (10,10)
    geo_with_hole = Geometry.from_points([(0, 0), (10, 0), (10, 10), (0, 10)])
    # Inner CW square (hole) (2,2) -> (8,8)
    hole = Geometry.from_points([(2, 2), (2, 8), (8, 8), (8, 2)])
    geo_with_hole.extend(hole)  # Use extend to merge numpy data
    # Expected area = 100 - (6*6) = 64
    assert geo_with_hole.area() == pytest.approx(64.0)

    # Test case 5: Two separate shapes
    geo_two_shapes = Geometry.from_points([(0, 0), (5, 0), (5, 5), (0, 5)])
    second_shape = Geometry.from_points(
        [(10, 10), (15, 10), (15, 15), (10, 15)]
    )
    geo_two_shapes.extend(second_shape)  # Use extend to merge numpy data
    # Expected area = 25 + 25 = 50
    assert geo_two_shapes.area() == pytest.approx(50.0)


def test_segments():
    """Tests the segments() method for extracting point lists."""
    # Test case 1: Empty geometry
    geo_empty = Geometry()
    assert geo_empty.segments() == []

    # Test case 2: Single open path
    geo_open = Geometry()
    geo_open.move_to(0, 0, 1)
    geo_open.line_to(10, 0, 2)
    geo_open.arc_to(10, 10, i=0, j=5, z=3)
    expected_open = [[(0, 0, 1), (10, 0, 2), (10, 10, 3)]]
    assert geo_open.segments() == expected_open

    # Test case 3: Single closed path
    geo_closed = Geometry.from_points([(0, 0), (10, 0), (0, 10)])
    expected_closed = [[(0, 0, 0), (10, 0, 0), (0, 10, 0), (0, 0, 0)]]
    assert geo_closed.segments() == expected_closed

    # Test case 4: Multiple disjoint segments
    geo_multi = Geometry()
    # Segment 1
    geo_multi.move_to(0, 0)
    geo_multi.line_to(1, 1)
    # Segment 2
    geo_multi.move_to(10, 10)
    geo_multi.line_to(11, 11)
    geo_multi.line_to(12, 12)
    expected_multi = [
        [(0, 0, 0), (1, 1, 0)],
        [(10, 10, 0), (11, 11, 0), (12, 12, 0)],
    ]
    assert geo_multi.segments() == expected_multi

    # Test case 5: Path starting with a LineTo (implicit start at 0,0,0)
    geo_implicit_start = Geometry()
    geo_implicit_start.line_to(5, 5)
    geo_implicit_start.line_to(10, 0)
    expected_implicit = [[(0, 0, 0), (5, 5, 0), (10, 0, 0)]]
    assert geo_implicit_start.segments() == expected_implicit


def test_from_points():
    """Tests the Geometry.from_points classmethod."""
    # Test case 1: Empty list
    geo_empty = Geometry.from_points([])
    assert geo_empty.is_empty()

    # Test case 2: Single point
    geo_single = Geometry.from_points([(10, 20)])
    assert len(geo_single) == 1
    geo_single._sync_to_numpy()
    assert geo_single.data is not None
    assert geo_single.data[0, COL_TYPE] == CMD_TYPE_MOVE
    assert (geo_single.data[0, 1:4] == (10, 20, 0)).all()
    assert geo_single.last_move_to == (10, 20, 0)

    # Test case 3: Triangle (closed by default)
    points = [(0, 0), (10, 0), (5, 10)]
    geo_triangle = Geometry.from_points(points)
    assert len(geo_triangle) == 4
    geo_triangle._sync_to_numpy()
    assert geo_triangle.data is not None
    assert geo_triangle.data[0, COL_TYPE] == CMD_TYPE_MOVE
    assert (geo_triangle.data[0, 1:4] == (0, 0, 0)).all()
    assert geo_triangle.data[3, COL_TYPE] == CMD_TYPE_LINE
    assert (geo_triangle.data[3, 1:4] == (0, 0, 0)).all()

    # Test case 4: Triangle (open)
    geo_triangle_open = Geometry.from_points(points, close=False)
    assert len(geo_triangle_open) == 3
    geo_triangle_open._sync_to_numpy()
    assert geo_triangle_open.data is not None
    assert (
        geo_triangle_open.data[-1, 1:4] != geo_triangle_open.data[0, 1:4]
    ).any()

    # Test case 5: Points with Z coordinates (closed)
    points_3d = [(0, 0, 1), (10, 0, 2), (5, 10, 3)]
    geo_3d = Geometry.from_points(points_3d)
    assert len(geo_3d) == 4
    geo_3d._sync_to_numpy()
    assert geo_3d.data is not None
    assert (geo_3d.data[0, 1:4] == (0, 0, 1)).all()
    assert (geo_3d.data[3, 1:4] == (0, 0, 1)).all()
    assert geo_3d.last_move_to == (0, 0, 1)


def test_dump_and_load(sample_geometry):
    """
    Tests the dump() and load() methods for space-efficient serialization.
    """
    # Test with a non-empty geometry
    geo_with_bezier = Geometry()
    geo_with_bezier.move_to(0, 0)
    geo_with_bezier.line_to(10, 10)
    geo_with_bezier.arc_to(20, 0, i=5, j=-10)
    geo_with_bezier.bezier_to(30, 10, c1x=22, c1y=2, c2x=28, c2y=8)
    dumped_data = geo_with_bezier.dump()
    loaded_geo = Geometry.load(dumped_data)

    assert dumped_data["last_move_to"] == list(geo_with_bezier.last_move_to)
    assert len(dumped_data["commands"]) == 4
    assert dumped_data["commands"][0] == ["M", 0.0, 0.0, 0.0]
    assert dumped_data["commands"][1] == ["L", 10.0, 10.0, 0.0]
    assert dumped_data["commands"][2] == ["A", 20.0, 0.0, 0.0, 5.0, -10.0, 1]
    assert dumped_data["commands"][3] == ["B", 30.0, 10.0, 0.0, 22, 2, 28, 8]

    assert loaded_geo == geo_with_bezier

    # Test with an empty geometry
    empty_geo = Geometry()
    dumped_empty = empty_geo.dump()
    loaded_empty = Geometry.load(dumped_empty)

    assert dumped_empty["last_move_to"] == [0.0, 0.0, 0.0]
    assert dumped_empty["commands"] == []
    assert loaded_empty.is_empty()
    assert loaded_empty.last_move_to == (0.0, 0.0, 0.0)


def test_map_to_frame_wrapper():
    """Tests that map_to_frame() returns a Geometry."""
    geo = Geometry.from_points([(0, 0), (1, 1)])
    origin = (10, 10)
    p_width = (20, 10)
    p_height = (10, 30)
    result = geo.map_to_frame(origin, p_width, p_height)
    assert isinstance(result, Geometry)


# --- Force Bezier Conversion Tests ---


def test_force_beziers_init():
    """Test that the configuration flag is stored correctly."""
    geo = Geometry()
    assert geo.uniform_scalable is True


def test_arc_to_as_bezier():
    """Test that arc_to_as_bezier creates Bezier commands."""
    geo = Geometry()
    geo.move_to(0, 0)

    # Create a simple 90 degree arc
    # Start (0,0), Center (10,0), End (10,10)
    # i=10, j=0. Clockwise=False (CCW)
    geo.arc_to_as_bezier(10, 10, i=10, j=0, clockwise=False)

    # Force sync
    geo._sync_to_numpy()
    data = geo.data
    assert data is not None

    assert len(data) > 1
    assert data[0, COL_TYPE] == CMD_TYPE_MOVE

    # Check that subsequent commands are BEZIER, not ARC
    for i in range(1, len(data)):
        assert data[i, COL_TYPE] == CMD_TYPE_BEZIER

    # Check endpoints of the last segment match the requested arc end
    last_row = data[-1]
    assert math.isclose(last_row[COL_X], 10.0)
    assert math.isclose(last_row[COL_Y], 10.0)


def test_extend_preserves_uniform_scalable():
    """
    Test that extending a geometry preserves the uniform_scalable flag.
    """
    # Source geometry with an arc
    source = Geometry()
    source.move_to(0, 0)
    source.arc_to(10, 0, i=5, j=0, clockwise=True)  # Semi-circle

    # Destination geometry
    dest = Geometry()
    dest.extend(source)

    dest._sync_to_numpy()
    data = dest.data
    assert data is not None

    # Should contain Moves and Arcs
    assert np.any(data[:, COL_TYPE] == CMD_TYPE_MOVE)
    assert np.any(data[:, COL_TYPE] == CMD_TYPE_ARC)
    assert not dest.uniform_scalable


def test_load_preserves_uniform_scalable(sample_geometry):
    """
    Test that loading from a dump preserves the uniform_scalable flag.
    """
    # sample_geometry contains an arc
    dumped = sample_geometry.dump()

    # Load
    loaded = Geometry.load(dumped)

    loaded._sync_to_numpy()
    data = loaded.data
    assert data is not None

    assert np.any(data[:, COL_TYPE] == CMD_TYPE_ARC)
    assert not loaded.uniform_scalable

    # Check that endpoint is preserved
    last_row = data[-1]
    # sample_geometry ends at (20, 0)
    assert math.isclose(last_row[COL_X], 20.0)
    assert math.isclose(last_row[COL_Y], 0.0)


# --- Wrapper Method Tests ---
# These tests verify that the Geometry methods correctly wrap and call the
# underlying stateless functions from other modules.


def test_close_gaps_wrapper(sample_geometry):
    """Tests the Geometry.close_gaps() wrapper method."""
    result = sample_geometry.close_gaps(tolerance=1e-5)
    assert result is sample_geometry


def test_cleanup_wrapper(sample_geometry):
    """Tests the Geometry.cleanup() wrapper method."""
    result = sample_geometry.cleanup(tolerance=1e-5)
    assert result is sample_geometry


def test_split_inner_and_outer_contours_wrapper(sample_geometry):
    """Tests the Geometry.split_inner_and_outer_contours() wrapper method."""
    result = sample_geometry.split_inner_and_outer_contours()
    assert isinstance(result, tuple)
    assert len(result) == 2


def test_is_closed_wrapper(sample_geometry):
    """Tests the Geometry.is_closed() wrapper method."""
    result = sample_geometry.is_closed(tolerance=1e-5)
    assert isinstance(result, bool)


def test_remove_inner_edges_wrapper(sample_geometry):
    """Tests the Geometry.remove_inner_edges() wrapper method."""
    result = sample_geometry.remove_inner_edges()
    assert isinstance(result, Geometry)


def test_split_into_contours_wrapper(sample_geometry):
    """Tests the Geometry.split_into_contours() wrapper method."""
    result = sample_geometry.split_into_contours()
    assert isinstance(result, list)


def test_split_into_components_wrapper(sample_geometry):
    """Tests the Geometry.split_into_components() wrapper method."""
    result = sample_geometry.split_into_components()
    assert isinstance(result, list)


def test_encloses_wrapper(sample_geometry):
    """Tests the Geometry.encloses() wrapper method."""
    other_geo = Geometry()
    result = sample_geometry.encloses(other_geo)
    assert isinstance(result, bool)


def test_has_self_intersections_wrapper(sample_geometry):
    """Tests the Geometry.has_self_intersections() wrapper method."""
    result = sample_geometry.has_self_intersections(fail_on_t_junction=True)
    assert isinstance(result, bool)


def test_intersects_with_wrapper(sample_geometry):
    """Tests the Geometry.intersects_with() wrapper method."""
    other_geo = Geometry()
    other_geo.line_to(1, 1)
    result = sample_geometry.intersects_with(other_geo)
    assert isinstance(result, bool)


def test_grow_wrapper(sample_geometry):
    """Tests the Geometry.grow() wrapper method."""
    result = sample_geometry.grow(amount=5.0)
    assert isinstance(result, Geometry)


def test_transform_wrapper(sample_geometry):
    """
    Tests that Geometry.transform() correctly transforms geometry data.
    """
    matrix = np.identity(4)
    sample_geometry._sync_to_numpy()
    sample_geometry.transform(matrix)
    # Identity matrix should leave geometry unchanged
    assert sample_geometry.data is not None


def test_flip_x():
    """Tests that flip_x() correctly inverts X coordinates."""
    geo = Geometry()
    geo.move_to(0, 0)
    geo.line_to(10, 10)
    geo.arc_to(20, 5, i=5, j=-5, clockwise=False)
    geo.bezier_to(30, 10, c1x=22, c1y=2, c2x=28, c2y=8)

    # Sync to get original data
    geo._sync_to_numpy()
    assert geo.data is not None
    original_data = geo.data.copy()

    # Apply flip_x
    result = geo.flip_x()

    assert result is geo

    # Check that X coordinates are inverted
    # MoveTo: (0, 0) -> (0, 0)
    assert math.isclose(geo.data[0, COL_X], 0.0)
    assert math.isclose(geo.data[0, COL_Y], 0.0)

    # LineTo: (10, 10) -> (-10, 10)
    assert math.isclose(geo.data[1, COL_X], -10.0)
    assert math.isclose(geo.data[1, COL_Y], 10.0)

    # ArcTo: (20, 5) -> (-20, 5)
    assert math.isclose(geo.data[2, COL_X], -20.0)
    assert math.isclose(geo.data[2, COL_Y], 5.0)

    # BezierTo: (30, 10) -> (-30, 10)
    assert math.isclose(geo.data[3, COL_X], -30.0)
    assert math.isclose(geo.data[3, COL_Y], 10.0)

    # Flipping twice should return to original
    geo.flip_x()
    np.testing.assert_allclose(geo.data, original_data, atol=1e-9)


def test_flip_y():
    """Tests that flip_y() correctly inverts Y coordinates."""
    geo = Geometry()
    geo.move_to(0, 0)
    geo.line_to(10, 10)
    geo.arc_to(20, 5, i=5, j=-5, clockwise=False)
    geo.bezier_to(30, 10, c1x=22, c1y=2, c2x=28, c2y=8)

    # Sync to get original data
    geo._sync_to_numpy()
    assert geo.data is not None
    original_data = geo.data.copy()

    # Apply flip_y
    result = geo.flip_y()

    assert result is geo

    # Check that Y coordinates are inverted
    # MoveTo: (0, 0) -> (0, 0)
    assert math.isclose(geo.data[0, COL_X], 0.0)
    assert math.isclose(geo.data[0, COL_Y], 0.0)

    # LineTo: (10, 10) -> (10, -10)
    assert math.isclose(geo.data[1, COL_X], 10.0)
    assert math.isclose(geo.data[1, COL_Y], -10.0)

    # ArcTo: (20, 5) -> (20, -5)
    assert math.isclose(geo.data[2, COL_X], 20.0)
    assert math.isclose(geo.data[2, COL_Y], -5.0)

    # BezierTo: (30, 10) -> (30, -10)
    assert math.isclose(geo.data[3, COL_X], 30.0)
    assert math.isclose(geo.data[3, COL_Y], -10.0)

    # Flipping twice should return to original
    geo.flip_y()
    np.testing.assert_allclose(geo.data, original_data, atol=1e-9)


def test_get_command_at_valid_index():
    """Tests get_command_at() with valid indices."""
    geo = Geometry()
    geo.move_to(0, 0, 1)
    geo.line_to(10, 10, 2)
    geo.arc_to(20, 0, i=5, j=-10, clockwise=False, z=3)
    geo.bezier_to(30, 10, c1x=22, c1y=2, c2x=28, c2y=8, z=4)

    cmd0 = geo.get_command_at(0)
    assert cmd0 == (CMD_TYPE_MOVE, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0)

    cmd1 = geo.get_command_at(1)
    assert cmd1 == (CMD_TYPE_LINE, 10.0, 10.0, 2.0, 0.0, 0.0, 0.0, 0.0)

    cmd2 = geo.get_command_at(2)
    assert cmd2 == (CMD_TYPE_ARC, 20.0, 0.0, 3.0, 5.0, -10.0, 0.0, 0.0)

    cmd3 = geo.get_command_at(3)
    assert cmd3 == (CMD_TYPE_BEZIER, 30.0, 10.0, 4.0, 22.0, 2.0, 28.0, 8.0)


def test_get_command_at_negative_index():
    """Tests get_command_at() with negative index."""
    geo = Geometry()
    geo.move_to(0, 0)
    assert geo.get_command_at(-1) is None


def test_get_command_at_out_of_bounds():
    """Tests get_command_at() with index out of bounds."""
    geo = Geometry()
    geo.move_to(0, 0)
    geo.line_to(10, 10)
    assert geo.get_command_at(2) is None
    assert geo.get_command_at(100) is None


def test_get_command_at_empty_geometry():
    """Tests get_command_at() on empty geometry."""
    geo = Geometry()
    assert geo.get_command_at(0) is None


def test_iter_commands():
    """Tests iter_commands() yields all commands correctly."""
    geo = Geometry()
    geo.move_to(0, 0, 1)
    geo.line_to(10, 10, 2)
    geo.arc_to(20, 0, i=5, j=-10, clockwise=False, z=3)
    geo.bezier_to(30, 10, c1x=22, c1y=2, c2x=28, c2y=8, z=4)

    commands = list(geo.iter_commands())

    assert len(commands) == 4
    assert commands[0] == (CMD_TYPE_MOVE, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0)
    assert commands[1] == (CMD_TYPE_LINE, 10.0, 10.0, 2.0, 0.0, 0.0, 0.0, 0.0)
    assert commands[2] == (CMD_TYPE_ARC, 20.0, 0.0, 3.0, 5.0, -10.0, 0.0, 0.0)
    assert commands[3] == (
        CMD_TYPE_BEZIER,
        30.0,
        10.0,
        4.0,
        22.0,
        2.0,
        28.0,
        8.0,
    )


def test_iter_commands_empty_geometry():
    """Tests iter_commands() on empty geometry."""
    geo = Geometry()
    commands = list(geo.iter_commands())
    assert commands == []


def test_iter_commands_with_pending_data():
    """Tests iter_commands() syncs pending data before iteration."""
    geo = Geometry()
    geo.move_to(5, 5, 1)
    geo.line_to(15, 15, 2)

    commands = list(geo.iter_commands())

    assert len(commands) == 2
    assert commands[0] == (CMD_TYPE_MOVE, 5.0, 5.0, 1.0, 0.0, 0.0, 0.0, 0.0)
    assert commands[1] == (CMD_TYPE_LINE, 15.0, 15.0, 2.0, 0.0, 0.0, 0.0, 0.0)


def test_iter_commands_clockwise_arc():
    """Tests iter_commands() with clockwise arc."""
    geo = Geometry()
    geo.move_to(10, 10)
    geo.arc_to(15, 10, i=0, j=-5, clockwise=True)

    commands = list(geo.iter_commands())

    assert len(commands) == 2
    assert commands[0] == (CMD_TYPE_MOVE, 10.0, 10.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    assert commands[1] == (CMD_TYPE_ARC, 15.0, 10.0, 0.0, 0.0, -5.0, 1.0, 0.0)


def test_upgrade_to_scalable_on_scalable_geo():
    """
    Tests that upgrade_to_scalable does nothing on an already scalable
    geometry.
    """
    geo = Geometry()
    geo.move_to(0, 0)
    geo.line_to(10, 10)
    geo.bezier_to(20, 0, c1x=12, c1y=12, c2x=18, c2y=2)
    assert geo.data is not None
    original_data = geo.data.copy()

    assert geo.uniform_scalable is True
    result = geo.upgrade_to_scalable()

    assert result is geo
    assert geo.uniform_scalable is True
    np.testing.assert_array_equal(geo.data, original_data)


def test_upgrade_to_scalable_on_empty_geo():
    """Tests that upgrade_to_scalable handles empty geometry gracefully."""
    geo = Geometry()
    assert geo.is_empty()
    assert geo.uniform_scalable is True

    result = geo.upgrade_to_scalable()

    assert result is geo
    assert geo.is_empty()
    assert geo.uniform_scalable is True


def test_upgrade_to_scalable_converts_arcs():
    """Tests the core functionality of converting arcs to beziers."""
    geo = Geometry()
    geo.move_to(0, 0)
    geo.line_to(10, 10)  # Preserved command
    geo.arc_to(20, 0, i=5, j=-10, clockwise=True)  # Command to be converted

    # Initial state check
    assert geo.uniform_scalable is False

    # Perform the upgrade
    result = geo.upgrade_to_scalable()
    assert result is geo

    # Final state check
    assert geo.uniform_scalable is True
    assert geo.data is not None

    # Check command types
    command_types = geo.data[:, COL_TYPE]
    assert CMD_TYPE_ARC not in command_types
    assert CMD_TYPE_BEZIER in command_types
    assert CMD_TYPE_LINE in command_types
    assert CMD_TYPE_MOVE in command_types

    # Check path integrity
    # The last bezier should end where the arc ended.
    final_point = geo.data[-1, COL_X : COL_Z + 1]
    np.testing.assert_allclose(final_point, [20.0, 0.0, 0.0], atol=1e-9)


def test_upgrade_to_scalable_multiple_arcs():
    """Tests upgrading a geometry with multiple arcs and segments."""
    geo = Geometry()
    geo.move_to(0, 0)
    geo.arc_to(10, 10, i=10, j=0, clockwise=False)  # 90 deg CCW arc
    geo.line_to(20, 10)
    geo.arc_to(30, 0, i=0, j=-10, clockwise=True)  # 90 deg CW arc
    final_end_point = (30.0, 0.0, 0.0)

    assert geo.uniform_scalable is False

    geo.upgrade_to_scalable()

    assert geo.uniform_scalable is True
    assert geo.data is not None
    assert CMD_TYPE_ARC not in geo.data[:, COL_TYPE]

    # Verify that the final endpoint of the entire path is preserved
    final_point_after = geo.data[-1, COL_X : COL_Z + 1]
    np.testing.assert_allclose(final_point_after, final_end_point, atol=1e-9)


def test_upgrade_to_scalable_is_idempotent():
    """
    Tests that calling upgrade_to_scalable multiple times has no extra effect.
    """
    geo = Geometry()
    geo.move_to(0, 0)
    geo.arc_to(10, 10, i=10, j=0, clockwise=False)

    # First call
    geo.upgrade_to_scalable()
    assert geo.data is not None
    data_after_first_call = geo.data.copy()
    assert geo.uniform_scalable is True
    assert CMD_TYPE_ARC not in data_after_first_call[:, COL_TYPE]

    # Second call
    geo.upgrade_to_scalable()
    data_after_second_call = geo.data

    # The data should be identical
    np.testing.assert_array_equal(
        data_after_first_call, data_after_second_call
    )


def test_linearize_approximation():
    """
    Test that linearize() converts curves to lines within tolerance.
    """
    geo = Geometry()
    geo.move_to(0, 0)
    # 90 degree arc of radius 10
    geo.arc_to(10, 10, i=10, j=0, clockwise=False)

    # Use a coarse tolerance to see visible simplification
    geo.linearize(tolerance=0.1)

    assert geo.data is not None
    cmd_types = geo.data[:, COL_TYPE]

    # Should contain no Arcs
    assert CMD_TYPE_ARC not in cmd_types
    # Should contain Lines
    assert CMD_TYPE_LINE in cmd_types

    # The end point should still be (10, 10)
    end_point = geo.data[-1, COL_X : COL_Z + 1]
    np.testing.assert_allclose(end_point, (10.0, 10.0, 0.0), atol=1e-6)


def test_fit_arcs_approximation():
    """
    Test that fit_arcs() reconstructs arcs from dense points.
    """
    # Create a dense polyline that approximates a circle
    points = []
    radius = 10.0
    center = (0.0, 0.0)
    for i in range(101):
        angle = (i / 100.0) * (np.pi / 2)  # 0 to 90 degrees
        x = center[0] + radius * math.cos(angle)
        y = center[1] + radius * math.sin(angle)
        points.append((x, y, 0.0))

    geo = Geometry.from_points(points, close=False)

    # Before fitting, it should be all Lines
    assert geo.data is not None
    assert np.all(geo.data[1:, COL_TYPE] == CMD_TYPE_LINE)

    # Fit arcs with a reasonable tolerance
    geo.fit_arcs(tolerance=0.1)

    # After fitting, it should contain Arcs
    assert geo.data is not None
    cmd_types = geo.data[:, COL_TYPE]
    assert CMD_TYPE_ARC in cmd_types

    # Should have significantly fewer commands than 100 lines
    assert len(geo.data) < 10


def test_fit_arcs_mixed_geometry():
    """
    Test fitting on geometry that has both straight lines and curves.
    """
    geo = Geometry()
    geo.move_to(0, 0)
    geo.line_to(10, 0)  # Straight line
    geo.arc_to(20, 10, i=0, j=10, clockwise=False)  # 90 deg arc
    assert geo.data is not None
    original_data = geo.data.copy()

    # Fitting arcs should process both the line and the arc segments.
    # Note: Because the fitting process is not perfectly lossless (it relies on
    # heuristics and tolerances), splitting may occur or very minor floating
    # point differences may be introduced. We check for semantic equivalence
    # rather than strict binary equality.
    geo.fit_arcs(tolerance=0.1)

    assert geo.data is not None

    # 1. Verify the endpoints are preserved
    # The last point should still be (20, 10, 0)
    final_end_point = geo.data[-1, COL_X : COL_Z + 1]
    original_end_point = original_data[-1, COL_X : COL_Z + 1]
    np.testing.assert_allclose(final_end_point, original_end_point, atol=1e-6)

    # 2. Verify we still have Arcs and Lines
    cmd_types = geo.data[:, COL_TYPE]
    assert CMD_TYPE_ARC in cmd_types
    assert CMD_TYPE_LINE in cmd_types

    # 3. Verify the number of commands didn't explode (it shouldn't degrade
    # to polylines). Original was 3 commands (Move, Line, Arc).
    # Result should be close to that (e.g., <= 5 if the arc got split).
    assert len(geo.data) <= 5


def test_fit_curves_preserves_beziers():
    geo = Geometry()
    geo.move_to(0, 0)
    geo.bezier_to(10, 10, c1x=2, c1y=5, c2x=8, c2y=5)
    geo.line_to(15, 10)

    geo.fit_curves(tolerance=0.1, beziers=True, arcs=True)

    assert geo.data is not None
    cmd_types = geo.data[:, COL_TYPE]
    assert CMD_TYPE_BEZIER in cmd_types


def test_fit_curves_delegates_to_fit_arcs():
    geo = Geometry()
    geo.move_to(0, 0)
    for i in range(100):
        angle = 2 * math.pi * i / 100
        geo.line_to(10 * math.cos(angle), 10 * math.sin(angle))

    geo.fit_arcs(tolerance=0.1)

    assert geo.data is not None
    cmd_types = geo.data[:, COL_TYPE]
    assert CMD_TYPE_ARC in cmd_types


class TestToPolygons:
    def test_empty_geometry(self):
        geo = Geometry()
        polygons = geo.to_polygons()
        assert polygons == []

    def test_single_triangle(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo.line_to(10, 0)
        geo.line_to(5, 10)
        geo.close_path()

        polygons = geo.to_polygons()
        assert len(polygons) == 1
        assert len(polygons[0]) >= 3

    def test_single_square(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo.line_to(10, 0)
        geo.line_to(10, 10)
        geo.line_to(0, 10)
        geo.close_path()

        polygons = geo.to_polygons()
        assert len(polygons) == 1
        assert len(polygons[0]) >= 3

    def test_multiple_segments(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo.line_to(10, 0)
        geo.line_to(10, 10)
        geo.line_to(0, 10)
        geo.close_path()
        geo.move_to(20, 0)
        geo.line_to(30, 0)
        geo.line_to(30, 10)
        geo.line_to(20, 10)
        geo.close_path()

        polygons = geo.to_polygons()
        assert len(polygons) == 2

    def test_with_arc(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo.line_to(10, 0)
        geo.arc_to(10, 10, 0, 5, clockwise=False)
        geo.line_to(0, 10)
        geo.close_path()

        polygons = geo.to_polygons(tolerance=0.5)
        assert len(polygons) == 1
        assert len(polygons[0]) >= 3

    def test_open_path(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo.line_to(10, 0)
        geo.line_to(10, 10)

        polygons = geo.to_polygons()
        assert len(polygons) == 1

    def test_tolerance_affects_cleaning(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo.line_to(10, 0)
        geo.line_to(10, 10)
        geo.line_to(0, 10)
        geo.close_path()

        polygons_low_tol = geo.to_polygons(tolerance=0.01)
        polygons_high_tol = geo.to_polygons(tolerance=1.0)

        assert len(polygons_low_tol) == 1
        assert len(polygons_high_tol) == 1

    def test_nested_geometry(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo.line_to(20, 0)
        geo.line_to(20, 20)
        geo.line_to(0, 20)
        geo.close_path()
        geo.move_to(5, 5)
        geo.line_to(15, 5)
        geo.line_to(15, 15)
        geo.line_to(5, 15)
        geo.close_path()

        polygons = geo.to_polygons()
        assert len(polygons) == 2


class TestAppendData:
    def test_appends_rows_to_existing_geometry(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo.line_to(10, 0)
        geo._sync_to_numpy()
        assert geo.data is not None
        original_len = len(geo.data)

        extra = np.array([[CMD_TYPE_LINE, 10.0, 10.0, 0.0, 0, 0, 0, 0]])
        geo.append_data(extra)

        assert geo.data is not None
        assert len(geo.data) == original_len + 1
        np.testing.assert_array_equal(geo.data[-1], extra[0])

    def test_appends_multiple_rows(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo._sync_to_numpy()
        assert geo.data is not None

        rows = np.array(
            [
                [CMD_TYPE_LINE, 5.0, 0.0, 0.0, 0, 0, 0, 0],
                [CMD_TYPE_LINE, 5.0, 5.0, 0.0, 0, 0, 0, 0],
                [CMD_TYPE_LINE, 0.0, 5.0, 0.0, 0, 0, 0, 0],
            ]
        )
        geo.append_data(rows)

        assert geo.data is not None
        assert len(geo.data) == 4

    def test_sets_data_when_empty(self):
        geo = Geometry()
        rows = np.array([[CMD_TYPE_LINE, 1.0, 2.0, 0.0, 0, 0, 0, 0]])
        geo.append_data(rows)

        assert geo.data is not None
        assert len(geo.data) == 1
        np.testing.assert_array_equal(geo.data[0], rows[0])

    def test_none_is_noop(self):
        geo = Geometry()
        geo.move_to(1, 1)
        geo._sync_to_numpy()
        assert geo.data is not None
        original = geo.data.copy()

        geo.append_data(None)

        assert geo.data is not None
        np.testing.assert_array_equal(geo.data, original)

    def test_empty_array_is_noop(self):
        geo = Geometry()
        geo.move_to(1, 1)
        geo._sync_to_numpy()
        assert geo.data is not None
        original = geo.data.copy()

        geo.append_data(np.empty((0, GEO_ARRAY_COLS)))

        assert geo.data is not None
        np.testing.assert_array_equal(geo.data, original)

    def test_does_not_mutate_input(self):
        geo = Geometry()
        geo.move_to(0, 0)
        geo._sync_to_numpy()

        rows = np.array([[CMD_TYPE_LINE, 5.0, 5.0, 0.0, 0, 0, 0, 0]])
        original_rows = rows.copy()
        geo.append_data(rows)

        np.testing.assert_array_equal(rows, original_rows)


# --- _segment_length_from_row Tests ---


class TestSegmentLengthFromRow:
    def test_move_length_is_euclidean(self):
        row = np.array([CMD_TYPE_MOVE, 3.0, 4.0, 0.0, 0, 0, 0, 0])
        length = _segment_length_from_row(row, (0.0, 0.0, 0.0))
        assert length == pytest.approx(5.0)

    def test_line_length(self):
        row = np.array([CMD_TYPE_LINE, 3.0, 4.0, 0.0, 0, 0, 0, 0])
        length = _segment_length_from_row(row, (0.0, 0.0, 0.0))
        assert length == pytest.approx(5.0)

    def test_arc_ccw_quarter_circle(self):
        # Center at (0,0), start at (10,0), end at (0,10), CCW
        row = np.array([CMD_TYPE_ARC, 0.0, 10.0, 0.0, -10.0, 0.0, 0.0, 0.0])
        length = _segment_length_from_row(row, (10.0, 0.0, 0.0))
        assert length == pytest.approx(math.pi * 10 / 2)

    def test_arc_cw_quarter_circle(self):
        # Center at (0,0), start at (0,10), end at (10,0), CW
        row = np.array([CMD_TYPE_ARC, 10.0, 0.0, 0.0, 0.0, -10.0, 1.0, 0.0])
        length = _segment_length_from_row(row, (0.0, 10.0, 0.0))
        assert length == pytest.approx(math.pi * 10 / 2)

    def test_arc_full_circle_ccw(self):
        # Start and end at same point → full circle
        row = np.array([CMD_TYPE_ARC, 10.0, 0.0, 0.0, -10.0, 0.0, 0.0, 0.0])
        length = _segment_length_from_row(row, (10.0, 0.0, 0.0))
        assert length == pytest.approx(2 * math.pi * 10)

    def test_arc_full_circle_cw(self):
        row = np.array([CMD_TYPE_ARC, 10.0, 0.0, 0.0, -10.0, 0.0, 1.0, 0.0])
        length = _segment_length_from_row(row, (10.0, 0.0, 0.0))
        assert length == pytest.approx(2 * math.pi * 10)

    def test_arc_zero_radius_returns_zero(self):
        row = np.array([CMD_TYPE_ARC, 5.0, 5.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        length = _segment_length_from_row(row, (5.0, 5.0, 0.0))
        assert length == 0.0

    def test_bezier_length_approximates_true_length(self):
        # Quadratic-like bezier: (0,0)→(10,0) with control points
        row = np.array(
            [
                CMD_TYPE_BEZIER,
                10.0,
                0.0,
                0.0,
                5.0,
                3.0,
                5.0,
                -3.0,
            ]
        )
        length = _segment_length_from_row(row, (0.0, 0.0, 0.0))
        assert length > 10.0
        assert length < 20.0

    def test_bezier_colinear_is_line_length(self):
        # Control points on the line from (0,0) to (10,0)
        row = np.array(
            [
                CMD_TYPE_BEZIER,
                10.0,
                0.0,
                0.0,
                3.0,
                0.0,
                7.0,
                0.0,
            ]
        )
        length = _segment_length_from_row(row, (0.0, 0.0, 0.0))
        assert length == pytest.approx(10.0, abs=0.01)


# --- _partial_segment_from_row Tests ---


class TestPartialSegmentFromRow:
    def test_line_at_halfway(self):
        row = np.array([CMD_TYPE_LINE, 10.0, 10.0, 2.0, 0, 0, 0, 0])
        result = _partial_segment_from_row(row, (0.0, 0.0, 0.0), 0.5)
        assert result is not None
        assert result[COL_TYPE] == CMD_TYPE_LINE
        assert result[COL_X] == pytest.approx(5.0)
        assert result[COL_Y] == pytest.approx(5.0)
        assert result[COL_Z] == pytest.approx(1.0)

    def test_line_at_zero(self):
        row = np.array([CMD_TYPE_LINE, 10.0, 0.0, 0.0, 0, 0, 0, 0])
        result = _partial_segment_from_row(row, (0.0, 0.0, 0.0), 0.0)
        assert result is not None
        assert result[COL_X] == pytest.approx(0.0)
        assert result[COL_Y] == pytest.approx(0.0)

    def test_line_at_one(self):
        row = np.array([CMD_TYPE_LINE, 10.0, 20.0, 3.0, 0, 0, 0, 0])
        result = _partial_segment_from_row(row, (0.0, 0.0, 0.0), 1.0)
        assert result is not None
        assert result[COL_X] == pytest.approx(10.0)
        assert result[COL_Y] == pytest.approx(20.0)
        assert result[COL_Z] == pytest.approx(3.0)

    def test_arc_partial_ccw(self):
        # Quarter circle CCW from (10,0) to (0,10), center (0,0)
        row = np.array([CMD_TYPE_ARC, 0.0, 10.0, 0.0, -10.0, 0.0, 0.0, 0.0])
        result = _partial_segment_from_row(row, (10.0, 0.0, 0.0), 0.5)
        assert result is not None
        assert result[COL_TYPE] == CMD_TYPE_ARC
        assert result[COL_X] == pytest.approx(
            10 * math.cos(math.pi / 4), abs=1e-6
        )
        assert result[COL_Y] == pytest.approx(
            10 * math.sin(math.pi / 4), abs=1e-6
        )

    def test_arc_partial_cw(self):
        # Quarter circle CW from (0,10) to (10,0), center (0,0)
        row = np.array([CMD_TYPE_ARC, 10.0, 0.0, 0.0, 0.0, -10.0, 1.0, 0.0])
        result = _partial_segment_from_row(row, (0.0, 10.0, 0.0), 0.5)
        assert result is not None
        cx, cy = 0.0, 0.0
        start_angle = math.pi / 2
        end_angle = 0.0
        angle_span = end_angle - start_angle
        mid_angle = start_angle + 0.5 * angle_span
        assert result[COL_X] == pytest.approx(
            cx + 10 * math.cos(mid_angle), abs=1e-6
        )
        assert result[COL_Y] == pytest.approx(
            cy + 10 * math.sin(mid_angle), abs=1e-6
        )

    def test_arc_preserves_ij_and_cw(self):
        row = np.array([CMD_TYPE_ARC, 0.0, 10.0, 0.0, -10.0, 0.0, 0.0, 0.0])
        result = _partial_segment_from_row(row, (10.0, 0.0, 0.0), 0.3)
        assert result is not None
        assert result[COL_I] == pytest.approx(-10.0)
        assert result[COL_J] == pytest.approx(0.0)
        assert result[COL_CW] == pytest.approx(0.0)

    def test_bezier_partial_midpoint(self):
        # Simple bezier from (0,0) to (10,0) with symmetric controls
        row = np.array(
            [
                CMD_TYPE_BEZIER,
                10.0,
                0.0,
                0.0,
                3.0,
                3.0,
                7.0,
                3.0,
            ]
        )
        result = _partial_segment_from_row(row, (0.0, 0.0, 0.0), 0.5)
        assert result is not None
        assert result[COL_TYPE] == CMD_TYPE_BEZIER
        assert result[COL_X] == pytest.approx(5.0)
        assert result[COL_Y] == pytest.approx(2.25)

    def test_bezier_partial_z_interpolation(self):
        row = np.array(
            [
                CMD_TYPE_BEZIER,
                10.0,
                0.0,
                4.0,
                3.0,
                3.0,
                7.0,
                3.0,
            ]
        )
        result = _partial_segment_from_row(row, (0.0, 0.0, 0.0), 0.5)
        assert result is not None
        assert result[COL_Z] == pytest.approx(2.0)

    def test_move_returns_none(self):
        row = np.array([CMD_TYPE_MOVE, 5.0, 5.0, 0.0, 0, 0, 0, 0])
        result = _partial_segment_from_row(row, (0.0, 0.0, 0.0), 0.5)
        assert result is None


# --- extract_overcut_rows Tests ---


class TestExtractOvercutRows:
    @staticmethod
    def _make_square(size=10.0):
        return np.array(
            [
                [CMD_TYPE_MOVE, 0.0, 0.0, 0.0, 0, 0, 0, 0],
                [CMD_TYPE_LINE, size, 0.0, 0.0, 0, 0, 0, 0],
                [CMD_TYPE_LINE, size, size, 0.0, 0, 0, 0, 0],
                [CMD_TYPE_LINE, 0.0, size, 0.0, 0, 0, 0, 0],
                [CMD_TYPE_LINE, 0.0, 0.0, 0.0, 0, 0, 0, 0],
            ]
        )

    def test_returns_none_for_none_data(self):
        assert extract_overcut_rows(None, 5.0) is None

    def test_returns_none_for_short_data(self):
        data = np.array([[CMD_TYPE_MOVE, 0.0, 0.0, 0.0, 0, 0, 0, 0]])
        assert extract_overcut_rows(data, 5.0) is None

    def test_returns_none_for_zero_length(self):
        data = self._make_square()
        assert extract_overcut_rows(data, 0.0) is None

    def test_returns_none_for_negative_length(self):
        data = self._make_square()
        assert extract_overcut_rows(data, -1.0) is None

    def test_exactly_one_side(self):
        data = self._make_square(10.0)
        result = extract_overcut_rows(data, 10.0)
        assert result is not None
        assert len(result) == 1
        np.testing.assert_array_equal(result[0], data[1])

    def test_two_full_sides(self):
        data = self._make_square(10.0)
        result = extract_overcut_rows(data, 20.0)
        assert result is not None
        assert len(result) == 2
        np.testing.assert_array_equal(result[0], data[1])
        np.testing.assert_array_equal(result[1], data[2])

    def test_partial_second_side(self):
        data = self._make_square(10.0)
        result = extract_overcut_rows(data, 15.0)
        assert result is not None
        assert len(result) == 2
        np.testing.assert_array_equal(result[0], data[1])
        assert result[1][COL_TYPE] == CMD_TYPE_LINE
        assert result[1][COL_X] == pytest.approx(10.0)
        assert result[1][COL_Y] == pytest.approx(5.0)

    def test_with_arc_segment(self):
        # MoveTo(10,0), ArcTo CCW to (-10,0) via center (0,0), i=-10
        # That's a semicircle of radius 10, length π·10 ≈ 31.4
        data = np.array(
            [
                [CMD_TYPE_MOVE, 10.0, 0.0, 0.0, 0, 0, 0, 0],
                [
                    CMD_TYPE_ARC,
                    -10.0,
                    0.0,
                    0.0,
                    -10.0,
                    0.0,
                    0.0,
                    0.0,
                ],
            ]
        )
        result = extract_overcut_rows(data, math.pi * 5)
        assert result is not None
        assert len(result) == 1
        assert result[0][COL_TYPE] == CMD_TYPE_ARC
        assert result[0][COL_X] == pytest.approx(0.0, abs=1e-6)
        assert result[0][COL_Y] == pytest.approx(10.0, abs=1e-6)

    def test_skips_zero_length_segments(self):
        # Line to same point has zero length and should be skipped
        data = np.array(
            [
                [CMD_TYPE_MOVE, 0.0, 0.0, 0.0, 0, 0, 0, 0],
                [CMD_TYPE_LINE, 0.0, 0.0, 0.0, 0, 0, 0, 0],
                [CMD_TYPE_LINE, 5.0, 0.0, 0.0, 0, 0, 0, 0],
            ]
        )
        result = extract_overcut_rows(data, 3.0)
        assert result is not None
        assert len(result) == 1
        assert result[0][COL_X] == pytest.approx(3.0)

    def test_length_exceeds_perimeter(self):
        data = self._make_square(10.0)
        result = extract_overcut_rows(data, 999.0)
        assert result is not None
        assert len(result) == 4

    def test_with_bezier_segment(self):
        # Bezier from (0,0) to (10,0) with controls on the line
        data = np.array(
            [
                [CMD_TYPE_MOVE, 0.0, 0.0, 0.0, 0, 0, 0, 0],
                [
                    CMD_TYPE_BEZIER,
                    10.0,
                    0.0,
                    0.0,
                    3.0,
                    0.0,
                    7.0,
                    0.0,
                ],
            ]
        )
        result = extract_overcut_rows(data, 5.0)
        assert result is not None
        assert len(result) == 1
        assert result[0][COL_TYPE] == CMD_TYPE_BEZIER
        assert result[0][COL_X] == pytest.approx(5.0, abs=0.1)
        assert result[0][COL_Y] == pytest.approx(0.0, abs=0.1)

    def test_returns_stacked_array(self):
        data = self._make_square(10.0)
        result = extract_overcut_rows(data, 25.0)
        assert result is not None
        assert result.shape[1] == GEO_ARRAY_COLS
        assert result.ndim == 2
