# -*- coding: utf-8 -*-
"""Driver for the Gigatronics 8540C power meter family."""

import numpy as np
from scuq import *
from copy import deepcopy

from mpylab.device.powermeter import POWERMETER as PWRMTR


def linav_dB(dbvals):
    """
    Input: sequence of dB-scaled values
    Output: dB-scaled lin-average of the input sequence
    
    Example: linav_dB([0,-10]) -> -0.301
    """
    linmean = np.mean(np.power(10., 0.1 * np.asarray(dbvals)))
    return 10 * np.log10(linmean)


def linav_lin(linvals):
    """
    Input: sequence of lin-scaled values
    Output: lin-scaled lin-average of the input sequence
    
    Example: linav_lin([0,-10]) -> -5
    """
    linmean = np.mean(np.asarray(linvals))
    return linmean


class POWERMETER(PWRMTR):
    """
    Driver for the Gigatronics 854X powermeter
    """
    conftmpl = deepcopy(PWRMTR.conftmpl)

    def __init__(self, **kw):
        PWRMTR.__init__(self, **kw)
        self._internal_unit = 'dBm'
        self.linav = linav_dB
        self.ch_tup = ('', 'A', 'B')
        self.chsel = "AP"
        self._cmds = {
            'SetFreq': [],
            'GetFreq': [],
            'ZeroOn': [],
            'ZeroOff': [],
            'Quit': [],
            'GetDescription': [('*IDN?', r'(?P<IDN>.*)')]
        }

    def _build_channel_cmds(self):
        prefix = f"{self.ch_tup[self.channel]}E"
        self._cmds.update({
            'SetFreq': [(f"{prefix} FR {{freq}} HZ", None)],
            'ZeroOn': [(f"{prefix} ZE", None)],
        })

    def _get_sensor_type(self):
        """
        return the type of the attached sensor as a string.
        """
        self._lock()
        cmd = f"TEST EEPROM {self.ch_tup[self.channel]} TYPE?"
        tmpl = r'(?P<SENSOR>\d+)'
        dct = self.query(cmd, tmpl)
        self._unlock()
        return dct['SENSOR']

    def Zero(self, state='on'):
        """Run zeroing sequence and return status."""
        self.error = 0
        self._lock()
        self.error, _ = PWRMTR.Zero(self, state=state)
        self._unlock()
        return self.error, 0

    def Init(self, ini=None, channel=None):  # , N=10, trg_threshold=0):
        """Initialize the selected meter channel and apply presets."""
        if channel is None:
            self.channel = 1
        else:
            self.channel = channel
        self.chsel = "AP"
        if self.channel != 1:
            self.chsel = "BP"
            self.channel = 2
        self._build_channel_cmds()

        try:
            # read gpib address fom ini-file to register instance
            self.get_config(ini, self.channel)

            self.value = None
            self.error = PWRMTR.Init(self, ini, self.channel)  # run init from parent class
            self.dev.write("TR3")

            sec = f'channel_{self.channel}'
            try:
                self.levelunit = self.conf[sec]['unit']
            except KeyError:
                self.levelunit = self._internal_unit
            self._cmds['Preset'] = [('PR', None)]

            # key, vals, actions
            presets = [('filter', [], [])]  # TODO: fill with information from ini-file

            self._apply_presets(presets, sec)

            dct = self._do_cmds('Preset', locals())
            self._update(dct)
            self.update_internal_unit()

            self._sensor = self._get_sensor_type()
            # time.sleep(.7)
        except:
            raise

        return self.error

    def update_internal_unit(self):
        """Read meter output mode and update internal unit/averaging behavior."""
        # get internal unit
        tup = ('W', 'dBm', '%', 'dB')
        ans = self.dev.ask(f'{self.ch_tup[self.channel]}P SM')
        ans = int(ans[-1])
        self._internal_unit = tup[ans]
        # Here, the appropriate average routine is set up
        if self._internal_unit in ['dB', 'dBm']:
            self.linav = linav_dB
        else:
            self.linav = linav_lin
        # self._fbuf_on()

    def Trigger(self):
        """Trigger measurement acquisition (no-op for this backend)."""
        self.error = 0
        return self.error

    def _lock(self):
        # vpp43.lock(self.dev.vi, pyvisa.constants.AccessModes.exclusive_lock, 2000)
        self.dev.lock_excl(timeout=2000)

    def _unlock(self):
        # vpp43.unlock(self.dev.vi)
        self.dev.unlock()

    def GetData(self):
        """Read one power sample and return it as quantity with mismatch uncertainty."""
        self._lock()
        self.SetFreq(self.freq)
        self.dev.write(self.chsel)
        ans = self.dev.read()
        self._unlock()
        self.value = self.linav([float(ans)])
        swr_err = self.get_standard_mismatch_uncertainty()
        self.power = float(self.value)
        power_value = float(self.power)
        iu = self._internal_unit
        if isinstance(iu, str):
            power_value, power_unit = self.convert.c2scuq(iu, power_value)   # iu ist a str 'dbm', ...
        elif isinstance(iu, units.Unit):  # iu is a scuq unit
            power_unit = iu
        else:
            raise TypeError(f"_internal_unit must be str or scuq Unit, got {type(iu).__name__}: {iu!r}")

        obj = quantities.Quantity(power_unit,
                                  ucomponents.UncertainInput(power_value, power_value * swr_err))
        return self.error, obj  # TODO: include other uncertainties

    def GetDataNB(self, retrigger):
        """Return data and optionally retrigger for the next read."""
        self.err, v = self.GetData()
        if retrigger:
            self.Trigger()
        return self.error, v

    def SetFreq(self, freq):
        """Set measurement frequency in Hz."""
        self.error = 0
        self.freq = freq
        self.error, freq = PWRMTR.SetFreq(self, freq)
        return self.error, freq

    def GetDescription(self):
        """Return instrument identification string."""
        self.error = 0
        self._lock()
        self.error, des = PWRMTR.GetDescription(self)
        self._unlock()
        return self.error, des

    def Quit(self):
        """Close the driver and return status."""
        self.error = 0
        return self.error


def test_init(cha):
    """Create and initialize a test instance for one channel."""
    import io
    from mpylab.tools.util import format_block
    inst = POWERMETER()
    ini = format_block("""
                    [DESCRIPTION]
                    description: 'GigaTronics 8542C Universal Power Meter'
                    type:        'POWERMETER'
                    vendor:      'GigaTronics'
                    serialnr:
                    deviceid:
                    driver:

                    [Init_Value]
                    fstart: 100e3
                    fstop: 18e9
                    fstep: 1
                    gpib: 13
                    virtual: 0
                    nr_of_channels: 2

                    [Channel_1]
                    name: A
                    unit: dBm
                    filter: -1
                    #resolution: 
                    rangemode: auto
                    #manrange: 
                    swr1: 1.1
                    swr2: 1.1
                    trg_threshold: 0.5

                    [Channel_2]
                    name: B
                    unit: 'W'
                    swr1: 1.1
                    swr2: 1.1
                    """)
    ini = io.StringIO(ini)
    inst.Init(ini, cha)
    return inst


def main():
    """Start the standalone Qt test UI for this power meter driver."""
    import io
    import sys
    from PySide6 import QtWidgets
    from mpylab.tools.util import format_block
    from mpylab.device.powermeter_ui import PowerMeterWidget as UI

    try:
        ini = sys.argv[1]
    except IndexError:
        ini = format_block("""
                        [DESCRIPTION]
                        description: 'GigaTronics 8542C Universal Power Meter'
                        type:        'POWERMETER'
                        vendor:      'GigaTronics'
                        serialnr:
                        deviceid:
                        driver:

                        [Init_Value]
                        fstart: 100e3
                        fstop: 18e9
                        fstep: 1
                        gpib: 13
                        virtual: 0
                        nr_of_channels: 2

                        [Channel_1]
                        name: A
                        unit: dBm
                        filter: -1
                        #resolution: 
                        rangemode: auto
                        #manrange: 
                        swr: 1.1
                        trg_threshold: 0.5

                        [Channel_2]
                        name: B
                        unit: 'W'
                        trg_threshold: 0.5
                        """)
        ini = io.StringIO(ini)

    pm = POWERMETER()
    app = QtWidgets.QApplication(sys.argv)
    ui = UI(pm, ini=ini)
    ui.show()
    sys.exit(app.exec())



if __name__ == '__main__':
    #    main()
    import sys
    import time

    ch = int(sys.argv[1])
    pm1 = test_init(ch)
    pm1.SetFreq(50e6)
    time.sleep(5)

    try:
        i = 0
        while True:
            pm1.Trigger()
            print(f"{i} PM{ch} {pm1.GetData()}")
            i += 1
    finally:
        pm1.Quit()
