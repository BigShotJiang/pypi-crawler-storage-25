# -*- coding: utf-8 -*-

"""mpylab.device.powermeter2c module."""
import time
from mpylab.device.powermeter import POWERMETER as PM


class POWERMETER(PM):
    """POWERMETER class."""
    instances = {}

    def __init__(self, SearchPaths=None):
        POWERMETER.conftmpl['channel_%d'].setdefault('trg_threshold', float)
        PM.__init__(self, SearchPaths=SearchPaths)
        self.lasttrigger = None
        self.istriggered = False

    def Init(self, ini=None, channel=None, ignore_bus=False):
        """Init method."""
        self.error = PM.Init(self, ini=ini, channel=channel, ignore_bus=ignore_bus)
        self.ch = channel
        self.trg_threshold = self.conf[f'channel_{channel}']['trg_threshold']
        self.gpib = self.conf['init_value']['gpib']
        virtual = self.conf['init_value'].get('virtual', False)
        if self.gpib and not virtual:  # ignore virtual instruments
            key = self._hash()  # here: gbib_ch
            if key in POWERMETER.instances:
                raise RuntimeWarning(f"2Ch Powermeter: Instance allready in use: {key}")
            POWERMETER.instances.setdefault(key, self)  # register this instance
        return self.error

    def Trigger(self):
        """
        Trigger the instrument. The Trigger is send only if no trigger was send from an othe instance 'inst' of the same instrument
        within (now-self.trg_threshold) and now.
        """
        now = time.time()
        for inst in self._crossref():
            if inst.lasttrigger and (now - inst.lasttrigger) <= self.trg_threshold:
                # print "do not send trigger from %d_%d"%(self.gpib,self.ch)
                self.istriggered = True
                self.error = 0
                break
        else:
            # print "send trigger from %d_%d"%(self.gpib,self.ch)
            self.error = PM.Trigger(self)
            self.istriggered = True
            self.lasttrigger = time.time()
            self.xrefdata = None
        return self.error

    def GetData(self):
        """GetData method."""
        now = time.time()
        for inst in self._crossref():
            if inst.lasttrigger and (now - inst.lasttrigger) <= self.trg_threshold:
                mine = self.xrefdata
                self.error = 0
                break
        else:
            self.error, obj = PM.GetData(self)
            mine = obj[self.ch]
            self.istriggered = False
            for inst in self._crossref():
                inst._setxrefdata(obj[inst.ch])
        return self.error, mine

    def GetDataNB(self, retrigger):
        """GetDataNB method."""
        self.error, obj = PM.GetDataNB(self, retrigger)

    def Quit(self):
        """Quit method."""
        PM.Quit(self)
        del POWERMETER.instances[self._hash()]  # remove this instance

    def _hash(self):
        return f"{self.gpib}_{self.ch}"

    def _crossref(self):
        """
        return a list of instances with same gpib but different ch than 'self'
        """
        instances = []
        for key, val in list(POWERMETER.instances.items()):
            g, c = list(map(int, key.split('_')))
            if g == self.gpib and c != self.ch:
                instances.append(val)
        return instances

    def _setxrefdata(self, data):
        self.xrefdata = data
