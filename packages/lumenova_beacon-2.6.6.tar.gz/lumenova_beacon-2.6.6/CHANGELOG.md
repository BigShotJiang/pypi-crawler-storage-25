# Changelog

## Unreleased

### New Features

- **Proxy, mTLS, and Custom CA Bundle Support** — `BeaconClient` now accepts `proxies`, `cert`, and an extended `verify` kwarg that flow through every SDK HTTP call: OTLP trace export (HTTP exporter) **and** all REST API operations (datasets, evaluations, experiments, guardrails, governance, llm_configs, prompts, probes, masking integration). Environment fallbacks: `BEACON_PROXIES` (URL string or JSON dict), `BEACON_CLIENT_CERT`/`BEACON_CLIENT_KEY` (path or path pair), `BEACON_VERIFY` (bool-like token or CA-bundle path). `proxies` accepts a requests-style dict (`{http, https, all}`) or a single URL string applied to both schemes; `cert` accepts a combined PEM path or a `(cert_path, key_path)` tuple; `verify` accepts `True`/`False`/`<CA-bundle path>`. Validation runs at construction time — missing CA paths, malformed JSON, unrecognized dict keys (`{"htps": ...}`, `{"no": ...}`), typo'd bool tokens, unsupported proxy URL schemes, and orphan `BEACON_CLIENT_KEY` raise `ConfigurationError` so misconfiguration cannot silently downgrade TLS or bypass the proxy.

### Notable Behavior

- gRPC extra OTLP endpoints (configured via `BEACON_EXTRA_OTLP_ENDPOINTS`) do **not** inherit the new `proxies`/`cert` settings (a warning is emitted when any of `proxies`, `cert`, or `verify=<CA path>` is configured alongside a gRPC extra), and reject `verify=False` with a `ConfigurationError` rather than silently keeping TLS verification on. Configure gRPC extras via the standard `grpc_proxy` / `https_proxy` env vars and `OTEL_EXPORTER_OTLP_CERTIFICATE` / `_CLIENT_CERTIFICATE` / `_CLIENT_KEY`, and use the gRPC channel's own insecure-channel mechanism when verification must be off.
- The OTLP requests session disables `trust_env` whenever any of `proxies`, `verify=False`, or a CA-bundle path is configured — `HTTPS_PROXY` / `HTTP_PROXY` / `REQUESTS_CA_BUNDLE` env vars cannot silently override the explicit Beacon config. The httpx-based REST path does the same when explicit proxies are set.
- `verify=False` suppresses `urllib3.InsecureRequestWarning` only within Beacon's own session — unrelated libraries (boto3, third-party SDKs) using urllib3 are unaffected.
- The `no` / `no_proxy` dict key is rejected with a `ConfigurationError`; use the standard `NO_PROXY` environment variable to bypass the proxy for specific hosts.
- `proxies` URL strings are scheme-validated at construction time (`http`, `https`, `socks4`, `socks5`, `socks5h`); other schemes raise `ConfigurationError` rather than silently dropping spans at export time.

### Dependencies

- **`httpx` floor bump from `>=0.23.0` to `>=0.25.0`.** Required for the modern `proxy=` / `mounts=` kwargs used by the per-scheme proxy translator. If you were pinned to httpx 0.23/0.24, upgrade httpx alongside the SDK.

## 2.7.0

A breaking-change release that collapses the dual single-/multi-score evaluator API onto a single multi-score format. Single-score evaluators are now expressed as a one-element `scores_config`, matching how the backend now stores and serves every evaluator.

### Breaking Changes

- **`Evaluator.score_config` removed.** Use `scores_config: list[dict]` for both single- and multi-score evaluators. A single-score evaluator is `scores_config=[{"name": "<score name>", "is_primary": True, "type": "percent", ...}]`. The `score_config` parameter is gone from `Evaluator.create`, `Evaluator.acreate`, `Evaluator.update`, `Evaluator.aupdate`, and from the `Evaluator.__init__` constructor and `_from_dict` deserializer.
- **`EvaluationRun.score_data` and `EvaluationRun.score` removed.** Use `scores_data: dict[str, dict]` keyed by score name. Backend-side migrations have already collapsed all stored single-score runs into one-key `scores_data` whose key is the evaluator's name; existing servers will return the new shape only.
- **`EvaluationRun.__repr__` now shows `scores_data` instead of the legacy `score`.**

### Migration

```python
# Before (single-score)
ev = Evaluator.create(
    name="Answer Quality",
    score_config={"type": "percent", "scoring_instructions": "Rate 0..1"},
)
run = ...  # run.score_data == {"type": "percent", "value": 0.8}

# After
ev = Evaluator.create(
    name="Answer Quality",
    scores_config=[
        {
            "name": "Answer Quality",
            "is_primary": True,
            "type": "percent",
            "scoring_instructions": "Rate 0..1",
        }
    ],
)
run = ...  # run.scores_data == {"Answer Quality": {"type": "percent", "value": 0.8}}
```

For code evaluators, the executable `evaluate(...)` function must return `{"scores": {"<score name>": <value>}}` (was `{"score": <value>}`). The score name in the returned dict must match a `name` in `scores_config`.

## 2.6.2

A consumer-surface release: a brand-new probes module, a much richer evaluations API now matched to the backend, expanded prompts and datasets models, governance enrichments (content reinjection, `@tool` support, async-stream state propagation), and a number of correctness and security fixes around tracing, OTLP export, and AWS AgentCore.

### New Features

- **Probes Module** — New `lumenova_beacon.probes` package for running SDK-mode probes against target systems. Includes a built-in and callable runner (`Probe.run` / `Probe.arun`), per-event response caching to avoid duplicate non-idempotent target hits, PID-qualified runner IDs to prevent claim collisions across processes, and a `headers={...}` auth model (`AuthSchemeHint.CUSTOM_HEADERS`, `BuiltInAuth(headers=...)`) that accepts arbitrary name/value pairs published by Beacon.

- **Evaluations Parity with Backend** — Major expansion of the evaluations module to close drift with the backend evaluator API. Adds `EvaluationRunStatus.WARNING`, `EvaluatorType.SYSTEM_PROBE`, `SourceType.TARGET_SYSTEM`, `ExperimentStepType.PYTHON`, and `ProbeMode`. `Evaluator` gains `scores_config`, `probe_mode`, `current_version`, `version_count`, `commit_message`, and `skip_version` (on update). `EvaluationRun` gains `scores_data`. `Evaluation` gains `target_system_id`, `probe_config`, `evaluator_version_id` / `_mode` / `_number`, `agent_config`, `reference_dataset_id`, `auto_run_delay_seconds`, `category`, and `created_by` / `created_by_info`.

- **JSONata & Python Extraction Engines** — `VariableMapping` now supports JSONata and Python pipeline steps for transforming dataset columns into evaluator inputs, with a new `VariableMapping.chain(*steps)` constructor for multi-step pipelines. Malformed shapes are now rejected at the SDK boundary with a typed `TypeError` instead of an opaque backend 422.

- **Guardrail Metadata** — `Guardrail.apply` and `Guardrail.aapply` accept an optional `metadata` dict (query, retrieval/grounding context, etc.) that is forwarded as-is to the apply endpoint and round-tripped into the v2 response, enabling RAG and grounded evaluation policies without dropping to raw HTTP.

- **Prompts API Expansion** — `Prompt` now supports a `category` field on create/update, a `prompt_type` filter on `list` / `alist`, and a new `list_versions` / `alist_versions` method returning `PromptVersion` dataclasses.

- **Datasets API Expansion** — `Dataset` model now exposes category, metadata, remote/connector source fields (`source_type`, `source_connector_type`, etc.) and import-tracking fields (`import_status`, `import_progress`, etc.). Record listing accepts a `search` parameter, and a new `bulk_delete_records` method removes records in bulk. `ColumnDefinition` gains `default_mapping`.

- **Governance Content Reinjection** — Governance policies returning an `output` value now rewrite the offending tool kwargs or LLM message in place rather than being silently dropped. Chat-model wrapping (`invoke` / `ainvoke`) is now atomic — partial setup failure rolls back to an unmodified model and raises `GovernanceConfigurationError` instead of leaving a half-governed instance.

- **`@governance` on LangChain `@tool` Functions** — The `@governance` decorator now detects `BaseTool` instances and wraps the tool's inner function/coroutine, preserving tool identity so LangChain agents still recognise it. Both stacking orders (`@governance` over `@tool` and vice versa) are now supported.

- **User Attribute Metadata Fallback** — `user_email`, `user_name`, and `user_id` now resolve through a chain: explicit param → client config → `metadata` dict → `None`. Applies to `BeaconLangGraphHandler`, `BeaconCallbackHandler`, `BeaconCrewAIListener`, `BeaconStrandsHandler`, `BeaconLangGraphGovernanceHandler`, and the `@governance` decorator.

### Bug Fixes

- Authorization headers are no longer forwarded to endpoints configured via `BEACON_EXTRA_OTLP_ENDPOINTS`, preventing API credential leaks to third-party collectors.
- LangGraph `astream` and `astream_events` now correctly propagate node state for `@governance(include_state=True)`, `set_agent_state()`, and tool/LLM evaluation. Previously the async dispatcher boundary dropped state silently and spammed `ContextVar reset failed` warnings.
- AWS AgentCore checkpointer compatibility: configurable keys (e.g. `actor_id`) are now forwarded into `get_state` / `aget_state`, fixing `InvalidConfigError` during checkpoint resolution.
- Experiment external-agent run progress bar now reflects the true total via `record_count` / `total_runs` instead of the partial count visible on the first poll, and the default `max_concurrency` is raised from 1 to 3 to avoid serialising trivial agents on HTTP round-trips.
- Governance client and `BeaconClient` config resolution now happen at invocation time rather than at decoration, so dynamic config changes are picked up and `BeaconClient` no longer needs to exist before decorated modules are imported.
- LangChain handler serialization no longer emits noisy `WARNING` logs for legitimately cyclic user data, and now detects cycles routed through custom objects (e.g. a `model_dump()` returning a self-referential dict). `Span.set_attribute` wraps `json.dumps` so cyclic-input `ValueError`s no longer leak into user code.
- Numerous silent-failure and error-handling fixes across tracing, LangChain integration, governance reinjection, and DTO validation; production assertions replaced with guards-and-warnings, and several debug-level logs upgraded to warning where data loss was masked.

### Improvements

- `BEACON_EXTRA_OTLP_ENDPOINTS` now auto-detects protocol per endpoint: port 4318 selects the HTTP/protobuf exporter (with `/v1/traces` appended), all others use gRPC. ImportError handling is per-endpoint so mixed-exporter environments degrade gracefully.
- Integration extras (`[langchain]`, `[strands]`) now contain only the packages the integration code actually imports — example-only dependencies moved to `[examples]`, the stale `crewai` version pin in examples is fixed, and the unused `black` dependency is removed.
- Dependency bounds relaxed to match the SDK's actual API surface, reducing version-conflict risk for downstream installs. `typing-extensions` is dropped from core dependencies (no longer imported anywhere in `lumenova_beacon`). Core mins lowered (`httpx>=0.23`, `tenacity>=8.1`); dev/test mins lowered (`pytest>=7`, `pytest-asyncio>=0.21`, `ruff>=0.1`, `mypy>=1.0`, `ipython>=8.0`, `respx>=0.20`, `boto3>=1.20`, `litellm>=1.50`). The `[opentelemetry]` extra is no longer exact-pinned to `==1.38.0` and now allows `>=1.38.0,<2.0` across the API/SDK/exporter packages; the `opentelemetry-instrumentation-*` packages in `[examples]` are similarly relaxed to `>=0.59b0,<1.0`. No upper bounds elsewhere, per library-packaging convention.
- Read-only DTOs (`PaginatedResponse`, `ColumnDefinition`, `ChatMessage`, experiment DTOs, `VariableMapping`, `ProcessorStep`) are now `frozen=True`, preventing accidental post-construction mutation that bypasses validators.
- New `BeaconClient.timestamp_override` setter and `PromptType.from_api_id()` helper. `VariableMapping` round-trips unknown server-side fields via `_extra` so `from_dict → to_dict` is non-lossy and forward-compatible with backend additions.

## 2.5.0

### Breaking Changes

- **Renamed LangGraph Integration Classes** — `BeaconCallbackHandler` is now `BeaconLangGraphHandler` and `LangGraphBeaconConfig` is now `BeaconLangGraphConfig` for consistent naming across all integrations. The old names still work but emit deprecation warnings.

### New Features

- **Agentic Governance** — New governance subsystem for real-time policy enforcement on LLM calls, tool invocations, and agent handoffs. Supports `@governance` decorator for framework-agnostic use, `BeaconLangGraphGovernanceHandler` for LangChain/LangGraph workflows, configurable violation thresholds, and OPA/Rego policy evaluation with per-policy verdict details.
- **AWS Secrets Manager Support** — API keys can now be resolved from AWS Secrets Manager via `BEACON_AWS_SECRET_NAME`, `BEACON_AWS_SECRET_KEY`, and `BEACON_AWS_REGION` environment variables, enabling zero-code configuration in deployment environments.
- **Extra OTLP Endpoints** — New `BEACON_EXTRA_OTLP_ENDPOINTS` environment variable allows sending traces to additional gRPC OTLP endpoints alongside the primary Beacon endpoint.
- **Parallel Handoff Tracing** — LangGraph integration now supports parallel agent handoffs via a new `StateAccessor`, correctly tracing concurrent sub-agent invocations within the same graph.
- **Interrupt & Resume in Handoffs** — When a handoff exits via `GraphInterrupt`, child trace IDs are automatically preserved and reused on resume, maintaining trace continuity across human-in-the-loop interrupt cycles.
- **Stack Trace Capture** — New optional `record_stacktrace` parameter on spans captures full exception tracebacks for easier debugging.
- **Experiment Run Progress** — Experiment runs now support progress tracking with real-time status updates.
- **Environment Parameter** — `BeaconClient` accepts a new `environment` parameter, propagated as a resource attribute on all exported spans.
- **Custom User Identity** — Callback handlers now accept `user_email` and `user_name` for associating traces with specific users.

### Bug Fixes

- Fixed resumed handoff nodes incorrectly appearing as agent type instead of their original node type
- Fixed handoff span becoming a root span when no active tool was found in the parent context
- Fixed handoff event parent spans not being set correctly
- Fixed cancel events inside handoff contexts not being traced properly
- Fixed multiple independent invocations with the same handler incorrectly sharing a single trace
- Fixed `tool_calls` format in LiteLLM integration
- Fixed autodetection of parallel handoffs in LangGraph workflows

### Improvements

- Governance configuration is integrated directly into `BeaconLangGraphConfig`, so tracing and policy enforcement can be set up in one place
- Handoff detection is now automatic — no need to manually specify which nodes are handoffs
- LangGraph integration stores Beacon metadata under a `_beacon` key in graph state for cleaner state management
- Refactored CrewAI, LiteLLM, and Strands integrations for consistency and improved test coverage

## 2.4.0

### New Features

- **Strands Agents Integration** — Native tracing support for AWS Strands Agents, capturing agent interactions and tool calls automatically
- **CrewAI Integration** — Native tracing support for CrewAI multi-agent workflows, replacing the previous LiteLLM-based approach
- **Eager Span Export** — Spans can now be exported in real time as they are created, enabling live trace visibility instead of waiting for the full trace to complete
- **LangGraph Interrupt & Resume Support** — Traces now capture human-in-the-loop interruptions and checkpoint data in LangGraph workflows, preserving conversational context across pauses and resumptions
- **Agent Handoff Tracing** — Added support for tracing agent-to-agent handoffs, tracking when one agent delegates work to another
- **Guardrails Module** — New SDK module for interacting with guardrail configurations
- **Isolated Trace Provider** — Beacon can now use its own isolated OpenTelemetry TracerProvider, avoiding conflicts with existing infrastructure tracing pipelines
- **Experiments API Overhaul** — Fully redesigned experiments module with support for running experiments, managing variants, and updated type definitions
- **Datasets & Evaluations SDK** — Expanded SDK support for managing datasets and evaluations, including new CRUD operations and richer type support

### Bug Fixes

- Fixed spans not being properly finished when a context manager handler fails
- Fixed resource attributes missing from eagerly exported spans
- Restored sensitive data masking in the span export pipeline, which was accidentally removed during a prior refactor
- Various stability fixes in the client, configuration handling, and LangChain integration

### Improvements

- Added database callback support to the client for custom span persistence
- LangChain integration now supports async configuration retrieval for better performance in async workflows

## 2.3.0

### New Features

- **LangGraph Interrupt & Cancel Support** — Traces now capture human-in-the-loop interrupt and cancellation events in LangGraph workflows, enabling visibility into paused and cancelled agent runs
- **OTEL gen_ai Semantic Conventions** — Span attributes for LangChain and LiteLLM integrations now follow the OpenTelemetry gen_ai semantic conventions for better interoperability with standard observability tools

### Improvements

- Removed content size limits on traced data, so full inputs and outputs are now captured without truncation

## 2.2.0

### Improvements

- Improved automatic model name capture in the LangChain integration, providing more accurate model attribution across traced LLM calls

## 2.1.0

### New Features

- **Singleton Client** — The SDK now supports a singleton client pattern, so multiple parts of an application can share the same Beacon client without manual wiring
- **Async Context Manager** — `BeaconClient` can now be used as an async context manager (`async with`) for cleaner resource management
- **Multiple Trace Providers** — Added support for registering multiple OpenTelemetry trace providers, enabling side-by-side tracing pipelines

### Improvements

- Enhanced error handling with more descriptive warnings and error messages for common misconfiguration scenarios
- Various stability fixes in the client and LangChain integration

## 2.0.0

### Breaking Changes

- **OTLP Pipeline Rewrite** — The span export pipeline has been completely rewritten to use OpenTelemetry's native OTLP protocol, replacing the previous custom transport. This is a breaking change for custom transport configurations.

### New Features

- **Time to First Token (TTFT) Tracking** — LangChain and LiteLLM integrations now automatically capture time-to-first-token metrics for streaming LLM responses
- **Agent & Environment Tracing** — LangChain integration now captures agent type and execution environment metadata on traced spans

### Bug Fixes

- Fixed SSL verification errors when sending traces with `BEACON_VERIFY=false`

## 1.3.0

### Breaking Changes

- **Renamed Callback Handlers** — `BeaconOtelCallbackHandler` is now `BeaconCallbackHandler`, and `BeaconOtelLiteLLMLogger` is now `BeaconLiteLLMLogger`. The old names are removed.

### Bug Fixes

- Fixed LangChain function calls not nesting correctly under their parent tool call spans
- Fixed API key not being sent correctly in certain request configurations

## 1.2.0

### Improvements

- **Python 3.10 Support** — Lowered the minimum Python version requirement from 3.12 to 3.10, broadening compatibility
- **Lazy Imports** — LangChain callback handler is now lazily imported, so installing the SDK no longer requires `langchain-core` unless you actually use the integration
- Removed `project_id` from the SDK interface — project association is now handled server-side

## 1.1.0

### New Features

- **OTLP Ingestion Endpoint** — The SDK now sends traces to any standard OTLP ingestion endpoint, enabling broader compatibility with OpenTelemetry-based backends

### Improvements

- Removed `project_id` from the SDK configuration, client, and data models — project association is now handled server-side

## 1.0.0

### Features

- **Core Tracing** — Manual span creation, `@trace` decorator, and context manager APIs for instrumenting Python applications
- **LangChain Integration** — Automatic tracing for LangChain chains, agents, tools, and LLM calls via `BeaconCallbackHandler`
- **LiteLLM Integration** — Callback logger for tracing LiteLLM completions across multiple LLM providers
- **Datasets** — SDK support for creating, listing, and managing datasets and dataset items
- **Experiments** — SDK support for creating and managing A/B testing experiments
- **Evaluations** — SDK support for running and tracking model evaluations
- **Prompts** — SDK support for fetching, rendering, and versioning prompt templates
- **Sensitive Data Masking** — Built-in masking engine for redacting PII and sensitive content from traced spans, with Presidio-based guardrails integration
- **File & HTTP Transport** — Traces can be exported via HTTP (OTLP) or saved to local JSON files for offline analysis
