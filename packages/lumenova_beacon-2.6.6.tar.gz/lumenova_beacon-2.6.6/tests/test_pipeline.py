"""Tests for the variable-mapping extraction-engine primitives in lumenova_beacon._pipeline."""

from __future__ import annotations

import pytest

from lumenova_beacon._pipeline import (
    MAX_EXPR_LEN,
    MAX_PIPELINE_STEPS,
    DataMode,
    ExtractionEngine,
    ProcessorKind,
    ProcessorStep,
    VariableMapping,
    _normalize_variable_mappings,
)


# ---------------------------------------------------------------------------
# ProcessorStep
# ---------------------------------------------------------------------------


class TestProcessorStep:
    """Engine/kind compatibility, expr length cap, string coercion."""

    @pytest.mark.parametrize(
        "engine,kind",
        [
            (ExtractionEngine.JSONPATH, ProcessorKind.EXTRACT_PATH),
            (ExtractionEngine.JSONATA, ProcessorKind.EXTRACT_PATH),
            (ExtractionEngine.JSONATA, ProcessorKind.FILTER),
            (ExtractionEngine.JSONATA, ProcessorKind.COMBINE),
            (ExtractionEngine.JSONATA, ProcessorKind.RESHAPE),
            (ExtractionEngine.PYTHON, ProcessorKind.EXTRACT_PATH),
            (ExtractionEngine.PYTHON, ProcessorKind.FILTER),
            (ExtractionEngine.PYTHON, ProcessorKind.COMBINE),
            (ExtractionEngine.PYTHON, ProcessorKind.RESHAPE),
        ],
    )
    def test_valid_engine_kind_pairs(
        self, engine: ExtractionEngine, kind: ProcessorKind
    ) -> None:
        step = ProcessorStep(engine=engine, expr="x", kind=kind)
        assert step.engine is engine
        assert step.kind is kind

    @pytest.mark.parametrize(
        "kind",
        [ProcessorKind.FILTER, ProcessorKind.COMBINE, ProcessorKind.RESHAPE],
    )
    def test_jsonpath_rejects_non_extract_kinds(self, kind: ProcessorKind) -> None:
        with pytest.raises(ValueError, match="not supported on engine='jsonpath'"):
            ProcessorStep(engine=ExtractionEngine.JSONPATH, expr="$.x", kind=kind)

    def test_expr_at_cap_accepted(self) -> None:
        step = ProcessorStep(engine=ExtractionEngine.JSONATA, expr="x" * MAX_EXPR_LEN)
        assert len(step.expr) == MAX_EXPR_LEN

    def test_expr_over_cap_rejected(self) -> None:
        with pytest.raises(ValueError, match="exceeds maximum"):
            ProcessorStep(engine=ExtractionEngine.JSONATA, expr="x" * (MAX_EXPR_LEN + 1))

    def test_string_engine_coerced_to_enum(self) -> None:
        step = ProcessorStep(engine="python", expr="def extract(d): return d")  # type: ignore[arg-type]
        assert step.engine is ExtractionEngine.PYTHON

    def test_string_kind_coerced_to_enum(self) -> None:
        step = ProcessorStep(engine=ExtractionEngine.JSONATA, expr="x", kind="filter")  # type: ignore[arg-type]
        assert step.kind is ProcessorKind.FILTER

    def test_unknown_engine_string_rejected(self) -> None:
        with pytest.raises(ValueError):
            ProcessorStep(engine="haskell", expr="x")  # type: ignore[arg-type]

    def test_unknown_kind_string_rejected(self) -> None:
        with pytest.raises(ValueError):
            ProcessorStep(engine=ExtractionEngine.JSONATA, expr="x", kind="explode")  # type: ignore[arg-type]

    def test_to_dict_wire_shape(self) -> None:
        step = ProcessorStep(
            engine=ExtractionEngine.JSONATA,
            expr="messages.content",
            kind=ProcessorKind.EXTRACT_PATH,
        )
        assert step.to_dict() == {
            "kind": "extract_path",
            "engine": "jsonata",
            "expr": "messages.content",
        }

    def test_from_dict_round_trip(self) -> None:
        original = ProcessorStep(
            engine=ExtractionEngine.PYTHON,
            expr="def extract(d): return d",
            kind=ProcessorKind.RESHAPE,
        )
        assert ProcessorStep.from_dict(original.to_dict()) == original


# ---------------------------------------------------------------------------
# VariableMapping — wire shape per engine
# ---------------------------------------------------------------------------


class TestVariableMappingWireShape:
    """The MR !337 invariant: jsonpath → json_path, others → pipeline, never both."""

    def test_jsonpath_emits_legacy_field(self) -> None:
        mapping = VariableMapping.jsonpath("$.input")
        wire = mapping.to_dict()
        assert wire["json_path"] == "$.input"
        assert "pipeline" not in wire

    def test_jsonata_emits_pipeline_only(self) -> None:
        mapping = VariableMapping.jsonata("messages.content")
        wire = mapping.to_dict()
        assert "json_path" not in wire
        assert wire["pipeline"] == [
            {"kind": "extract_path", "engine": "jsonata", "expr": "messages.content"}
        ]

    def test_python_emits_pipeline_only(self) -> None:
        mapping = VariableMapping.python("def extract(data):\n    return data")
        wire = mapping.to_dict()
        assert "json_path" not in wire
        assert wire["pipeline"][0]["engine"] == "python"

    def test_chained_pipeline_preserves_order(self) -> None:
        mapping = VariableMapping(
            data_mode=DataMode.RAW,
            pipeline=[
                ProcessorStep(engine=ExtractionEngine.JSONATA, expr="$.x"),
                ProcessorStep(
                    engine=ExtractionEngine.PYTHON,
                    expr="def extract(d): return d",
                    kind=ProcessorKind.RESHAPE,
                ),
            ],
        )
        wire = mapping.to_dict()
        assert [step["engine"] for step in wire["pipeline"]] == ["jsonata", "python"]
        assert [step["kind"] for step in wire["pipeline"]] == ["extract_path", "reshape"]

    def test_reduced_emits_reduced_fields(self) -> None:
        mapping = VariableMapping.reduced(
            reduced_fields=["input", "output"], format_as_conversation=True
        )
        wire = mapping.to_dict()
        assert wire["data_mode"] == "reduced"
        assert wire["reduced_fields"] == ["input", "output"]
        assert wire["format_as_conversation"] is True

    def test_fixed_emits_is_fixed_only(self) -> None:
        wire = VariableMapping.fixed("constant").to_dict()
        assert wire["is_fixed"] is True
        assert wire["fixed_value"] == "constant"
        assert "pipeline" not in wire and "json_path" not in wire

    def test_from_column_emits_column(self) -> None:
        wire = VariableMapping.from_column("input").to_dict()
        assert wire["column"] == "input"


# ---------------------------------------------------------------------------
# VariableMapping — validators
# ---------------------------------------------------------------------------


class TestVariableMappingValidators:
    def test_pipeline_and_json_path_together_rejected(self) -> None:
        with pytest.raises(ValueError, match="Set either 'pipeline' or 'json_path'"):
            VariableMapping(
                data_mode=DataMode.RAW,
                json_path="$.x",
                pipeline=[ProcessorStep(engine=ExtractionEngine.JSONATA, expr="y")],
            )

    def test_pipeline_with_reduced_mode_rejected(self) -> None:
        with pytest.raises(ValueError, match="data_mode='raw'"):
            VariableMapping(
                data_mode=DataMode.REDUCED,
                pipeline=[ProcessorStep(engine=ExtractionEngine.JSONATA, expr="y")],
            )

    def test_is_fixed_with_pipeline_rejected(self) -> None:
        with pytest.raises(ValueError, match="mutually exclusive"):
            VariableMapping(
                is_fixed=True,
                fixed_value="x",
                pipeline=[ProcessorStep(engine=ExtractionEngine.JSONATA, expr="y")],
            )

    def test_is_fixed_with_json_path_rejected(self) -> None:
        with pytest.raises(ValueError, match="mutually exclusive"):
            VariableMapping(is_fixed=True, fixed_value="x", json_path="$.x")

    def test_is_fixed_with_column_rejected(self) -> None:
        with pytest.raises(ValueError, match="mutually exclusive"):
            VariableMapping(is_fixed=True, fixed_value="x", column="col")

    def test_pipeline_length_cap(self) -> None:
        steps = [
            ProcessorStep(engine=ExtractionEngine.JSONATA, expr="x")
            for _ in range(MAX_PIPELINE_STEPS + 1)
        ]
        with pytest.raises(ValueError, match="exceeds maximum"):
            VariableMapping(data_mode=DataMode.RAW, pipeline=steps)

    def test_pipeline_at_cap_accepted(self) -> None:
        steps = [
            ProcessorStep(engine=ExtractionEngine.JSONATA, expr="x")
            for _ in range(MAX_PIPELINE_STEPS)
        ]
        mapping = VariableMapping(data_mode=DataMode.RAW, pipeline=steps)
        assert len(mapping.pipeline or []) == MAX_PIPELINE_STEPS

    def test_data_mode_string_coerced_to_enum(self) -> None:
        mapping = VariableMapping(data_mode="raw", json_path="$.x")  # type: ignore[arg-type]
        assert mapping.data_mode is DataMode.RAW


# ---------------------------------------------------------------------------
# VariableMapping — round-trip
# ---------------------------------------------------------------------------


class TestVariableMappingRoundTrip:
    def test_jsonpath_round_trip(self) -> None:
        original = VariableMapping.jsonpath("$.input")
        round_trip = VariableMapping.from_dict(original.to_dict())
        assert round_trip.to_dict() == original.to_dict()

    def test_jsonata_round_trip(self) -> None:
        original = VariableMapping.jsonata(
            "$join(messages.content, ' ')", kind=ProcessorKind.RESHAPE
        )
        round_trip = VariableMapping.from_dict(original.to_dict())
        assert round_trip.to_dict() == original.to_dict()

    def test_python_round_trip(self) -> None:
        original = VariableMapping.python(
            "def extract(data):\n    return data['x']"
        )
        round_trip = VariableMapping.from_dict(original.to_dict())
        assert round_trip.to_dict() == original.to_dict()

    def test_fixed_round_trip(self) -> None:
        original = VariableMapping.fixed("constant")
        round_trip = VariableMapping.from_dict(original.to_dict())
        assert round_trip.is_fixed is True
        assert round_trip.fixed_value == "constant"


# ---------------------------------------------------------------------------
# _normalize_variable_mappings
# ---------------------------------------------------------------------------


class TestNormalizeVariableMappings:
    def test_none_passes_through(self) -> None:
        assert _normalize_variable_mappings(None) is None

    def test_empty_dict_passes_through(self) -> None:
        assert _normalize_variable_mappings({}) == {}

    def test_typed_mapping_serialized(self) -> None:
        out = _normalize_variable_mappings({"q": VariableMapping.jsonpath("$.x")})
        assert out == {"q": {"data_mode": "raw", "json_path": "$.x"}}

    def test_legacy_dict_passes_through(self) -> None:
        legacy = {"q": {"data_mode": "raw", "json_path": "$.x"}}
        assert _normalize_variable_mappings(legacy) == legacy

    def test_bare_string_passes_through(self) -> None:
        assert _normalize_variable_mappings({"q": "column_name"}) == {"q": "column_name"}

    def test_mixed_shapes_each_handled_independently(self) -> None:
        mixed = {
            "typed": VariableMapping.jsonata("$.a"),
            "legacy_dict": {"data_mode": "raw", "json_path": "$.b"},
            "column": "col_c",
        }
        out = _normalize_variable_mappings(mixed)
        assert out is not None
        assert out["typed"] == {
            "data_mode": "raw",
            "pipeline": [
                {"kind": "extract_path", "engine": "jsonata", "expr": "$.a"}
            ],
        }
        assert out["legacy_dict"] == {"data_mode": "raw", "json_path": "$.b"}
        assert out["column"] == "col_c"


# ---------------------------------------------------------------------------
# Anti-bug guard for MR !337 (inverted check)
# ---------------------------------------------------------------------------


class TestInvertedCheckGuard:
    """A non-jsonpath pipeline must never carry a json_path field on the wire."""

    def test_jsonata_to_dict_omits_json_path_field(self) -> None:
        wire = VariableMapping.jsonata("$.x").to_dict()
        assert "json_path" not in wire

    def test_python_to_dict_omits_json_path_field(self) -> None:
        wire = VariableMapping.python("def extract(d): return d").to_dict()
        assert "json_path" not in wire

    def test_construction_rejects_python_pipeline_with_json_path(self) -> None:
        with pytest.raises(ValueError, match="Set either 'pipeline' or 'json_path'"):
            VariableMapping(
                data_mode=DataMode.RAW,
                json_path="$.x",
                pipeline=[
                    ProcessorStep(engine=ExtractionEngine.PYTHON, expr="def extract(d): return d")
                ],
            )


# ---------------------------------------------------------------------------
# Frozen-instance immutability
# ---------------------------------------------------------------------------


class TestImmutability:
    def test_processor_step_frozen(self) -> None:
        step = ProcessorStep(engine=ExtractionEngine.JSONATA, expr="x")
        with pytest.raises(Exception):  # FrozenInstanceError subclasses AttributeError
            step.expr = "mutated"  # type: ignore[misc]

    def test_variable_mapping_frozen(self) -> None:
        mapping = VariableMapping.jsonpath("$.x")
        with pytest.raises(Exception):
            mapping.json_path = "mutated"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# New validators added in fix-up pass
# ---------------------------------------------------------------------------


class TestEmptyPipelineRejected:
    def test_construction_rejects_empty_pipeline(self) -> None:
        with pytest.raises(ValueError, match="pipeline cannot be empty"):
            VariableMapping(data_mode=DataMode.RAW, pipeline=[])

    def test_chain_with_no_steps_rejected(self) -> None:
        with pytest.raises(ValueError, match="chain requires at least one step"):
            VariableMapping.chain()


class TestFixedValueRequired:
    def test_is_fixed_without_fixed_value_rejected(self) -> None:
        with pytest.raises(ValueError, match="requires a non-None fixed_value"):
            VariableMapping(is_fixed=True)

    def test_fixed_constructor_round_trips(self) -> None:
        wire = VariableMapping.fixed("hello").to_dict()
        assert wire == {"data_mode": "reduced", "is_fixed": True, "fixed_value": "hello"}


class TestChainConstructor:
    def test_single_step_chain(self) -> None:
        mapping = VariableMapping.chain(
            ProcessorStep(engine=ExtractionEngine.JSONATA, expr="$.x")
        )
        wire = mapping.to_dict()
        assert wire["pipeline"][0]["engine"] == "jsonata"
        assert "json_path" not in wire

    def test_multi_step_chain_preserves_order(self) -> None:
        mapping = VariableMapping.chain(
            ProcessorStep(engine=ExtractionEngine.JSONATA, expr="$.a"),
            ProcessorStep(
                engine=ExtractionEngine.PYTHON,
                expr="def extract(d): return d",
                kind=ProcessorKind.RESHAPE,
            ),
        )
        engines = [s["engine"] for s in mapping.to_dict()["pipeline"]]
        assert engines == ["jsonata", "python"]

    def test_chain_respects_pipeline_length_cap(self) -> None:
        many = [
            ProcessorStep(engine=ExtractionEngine.JSONATA, expr="x")
            for _ in range(MAX_PIPELINE_STEPS + 1)
        ]
        with pytest.raises(ValueError, match="exceeds maximum"):
            VariableMapping.chain(*many)


class TestExtraFieldRoundTrip:
    """Unknown server-side keys survive a from_dict → to_dict round-trip."""

    def test_unknown_keys_captured_in_extra(self) -> None:
        parsed = VariableMapping.from_dict(
            {"data_mode": "raw", "json_path": "$.x", "future_field": 42}
        )
        assert parsed._extra == {"future_field": 42}

    def test_round_trip_preserves_unknown_keys(self) -> None:
        original = {"data_mode": "raw", "json_path": "$.x", "future_field": 42}
        wire = VariableMapping.from_dict(original).to_dict()
        assert wire["future_field"] == 42
        assert wire["json_path"] == "$.x"

    def test_typed_field_overrides_extra_with_same_name(self) -> None:
        # If a server response somehow includes an 'extras' field that
        # matches a typed name, the typed attribute wins on re-emit.
        parsed = VariableMapping.from_dict(
            {"data_mode": "raw", "json_path": "$.x", "future": "preserved"}
        )
        wire = parsed.to_dict()
        assert wire["json_path"] == "$.x"
        assert wire["future"] == "preserved"

    def test_extras_excludes_known_keys_even_when_falsey(self) -> None:
        parsed = VariableMapping.from_dict(
            {"data_mode": "raw", "json_path": "$.x", "format_as_conversation": False}
        )
        # known key, regardless of value, never lands in _extra
        assert "format_as_conversation" not in parsed._extra


class TestNormalizeInputValidation:
    """Top-level and per-value input shapes are validated; otherwise users see opaque BE 422s."""

    @pytest.mark.parametrize("bad", [["list"], "str-mapping", 42, object()])
    def test_top_level_non_mapping_rejected(self, bad: object) -> None:
        with pytest.raises(TypeError, match="must be a Mapping"):
            _normalize_variable_mappings(bad)  # type: ignore[arg-type]

    @pytest.mark.parametrize(
        "bad_value",
        [[1, 2, 3], 42, object(), {1, 2}, b"bytes-not-str"],
    )
    def test_per_value_garbage_rejected(self, bad_value: object) -> None:
        with pytest.raises(TypeError, match="must be a VariableMapping"):
            _normalize_variable_mappings({"name": bad_value})

    def test_mapping_proxytype_value_normalized_to_dict(self) -> None:
        # collections.OrderedDict is a Mapping; should pass through as a dict copy.
        from collections import OrderedDict

        out = _normalize_variable_mappings(
            {"name": OrderedDict([("data_mode", "raw"), ("json_path", "$.x")])}
        )
        assert out is not None
        assert out["name"] == {"data_mode": "raw", "json_path": "$.x"}
        assert isinstance(out["name"], dict)
