"""Tests for evaluation model deserialization (focused on schema-drift fields).

These tests cover the multi-score, version, and probe fields added to round-trip
shapes returned by the Beacon backend. They exercise ``_from_dict`` and the
HTTP payload construction in ``acreate`` (mocked via respx) so they do not
require a live API.
"""

import json
from unittest.mock import MagicMock, patch

import pytest
import respx

from lumenova_beacon.evaluations.models import Evaluation, EvaluationRun, Evaluator
from lumenova_beacon.evaluations.types import (
    EvaluationRunStatus,
    ExtractionEngine,
    ProcessorKind,
    ProcessorStep,
    VariableMapping,
)

BEACON_URL = "https://beacon.test"


def _transport():
    transport = MagicMock()
    transport.headers = {"Authorization": "Bearer test-key"}
    transport.timeout = 30
    transport.verify = True
    return transport


@pytest.fixture
def beacon_env():
    with (
        patch(
            "lumenova_beacon.evaluations.models.get_base_url",
            return_value=BEACON_URL,
        ),
        patch(
            "lumenova_beacon.evaluations.models.get_transport",
            return_value=_transport(),
        ),
    ):
        yield


class TestEvaluatorFromDict:
    def test_multi_score_evaluator(self):
        data = {
            "id": "eval-1",
            "name": "Multi-Score LLM",
            "evaluator_type": "llm-as-judge",
            "is_predefined": False,
            "scores_config": [
                {"name": "accuracy", "type": "percent", "is_primary": True},
                {"name": "relevance", "type": "percent", "is_primary": False},
            ],
            "current_version": 3,
            "version_count": 3,
        }
        evaluator = Evaluator._from_dict(data)
        assert evaluator.scores_config is not None
        assert len(evaluator.scores_config) == 2
        assert evaluator.scores_config[0]["name"] == "accuracy"
        assert evaluator.current_version == 3
        assert evaluator.version_count == 3
        assert evaluator.probe_mode is None

    def test_system_probe_evaluator(self):
        data = {
            "id": "eval-2",
            "name": "Security Probe",
            "evaluator_type": "system-probe",
            "is_predefined": False,
            "probe_mode": "systematic",
            "prompt_template": "Probe instructions here",
        }
        evaluator = Evaluator._from_dict(data)
        assert evaluator.evaluator_type == "system-probe"
        assert evaluator.probe_mode == "systematic"
        assert evaluator.prompt_template == "Probe instructions here"

class TestEvaluationRunFromDict:
    def test_warning_status(self):
        data = {
            "id": "run-1",
            "evaluation_id": "ev-1",
            "evaluation_name": "Quality Check",
            "status": "WARNING",
            "created_at": "2025-01-15T10:00:00Z",
        }
        run = EvaluationRun._from_dict(data)
        assert run.status is EvaluationRunStatus.WARNING

    def test_multi_score_result(self):
        data = {
            "id": "run-2",
            "evaluation_id": "ev-2",
            "evaluation_name": "Multi-Score",
            "status": "COMPLETED",
            "created_at": "2025-01-15T10:00:00Z",
            "scores_data": {
                "accuracy": {"type": "percent", "value": 0.92},
                "relevance": {"type": "percent", "value": 0.85},
            },
        }
        run = EvaluationRun._from_dict(data)
        assert run.scores_data is not None
        assert run.scores_data["accuracy"] == {"type": "percent", "value": 0.92}


def _evaluation_response(**overrides):
    """Build a backend-shaped EvaluationRead body for respx responses."""
    body = {
        "id": "eval-100",
        "name": "Probe Eval",
        "evaluator_id": "evaluator-1",
        "variable_mappings": {},
        "active": False,
        "created_at": "2025-01-15T10:00:00Z",
        "project_id": "proj-1",
    }
    body.update(overrides)
    return body


class TestEvaluationFromDict:
    def test_system_probe_evaluation_roundtrip(self):
        data = _evaluation_response(
            source_type="target_system",
            target_system_id="ts-42",
            probe_config={"max_requests": 50, "instructions": "Probe carefully"},
            evaluator_version_id="ver-7",
            evaluator_version_mode="pinned",
            evaluator_version_number=7,
            category="security",
            auto_run_delay_seconds=5,
            agent_config={"max_steps": 20, "timeout_seconds": 600},
            reference_dataset_id="ref-ds-1",
            created_by="actor-1",
            created_by_info={
                "id": "actor-1",
                "name": "Andrei",
                "email": "a@x.io",
                "actor_type": "user",
            },
        )
        evaluation = Evaluation._from_dict(data)
        assert evaluation.source_type == "target_system"
        assert evaluation.target_system_id == "ts-42"
        assert evaluation.probe_config == {
            "max_requests": 50,
            "instructions": "Probe carefully",
        }
        assert evaluation.evaluator_version_id == "ver-7"
        assert evaluation.evaluator_version_mode == "pinned"
        assert evaluation.evaluator_version_number == 7
        assert evaluation.category == "security"
        assert evaluation.auto_run_delay_seconds == 5
        assert evaluation.agent_config == {"max_steps": 20, "timeout_seconds": 600}
        assert evaluation.reference_dataset_id == "ref-ds-1"
        assert evaluation.created_by == "actor-1"
        assert evaluation.created_by_info is not None
        assert evaluation.created_by_info["name"] == "Andrei"

    def test_legacy_trace_evaluation_unchanged(self):
        data = _evaluation_response(
            source_type="full_trace",
            filter_rules={"logic": "AND", "rules": []},
            active=True,
        )
        evaluation = Evaluation._from_dict(data)
        assert evaluation.source_type == "full_trace"
        assert evaluation.target_system_id is None
        assert evaluation.probe_config is None
        assert evaluation.evaluator_version_id is None
        assert evaluation.evaluator_version_mode is None
        assert evaluation.category is None
        assert evaluation.agent_config is None


@respx.mock
@pytest.mark.asyncio
async def test_acreate_system_probe_payload(beacon_env):
    """``Evaluation.acreate`` forwards system-probe + version-pinning kwargs as
    JSON fields on the POST body — this is the wire-level proof that PR #2's
    new kwargs reach the backend, not just the SDK in-memory model.
    """
    route = respx.post(f"{BEACON_URL}/api/v1/evaluations").respond(
        200,
        json=_evaluation_response(
            source_type="target_system",
            target_system_id="ts-1",
            probe_config={"max_requests": 10},
            evaluator_version_id="ver-3",
            evaluator_version_mode="pinned",
        ),
    )

    evaluation = await Evaluation.acreate(
        name="Probe Eval",
        evaluator_id="evaluator-1",
        variable_mappings={},
        source_type="target_system",
        target_system_id="ts-1",
        probe_config={"max_requests": 10},
        evaluator_version_id="ver-3",
        evaluator_version_mode="pinned",
    )

    assert route.called
    sent = respx.calls.last.request
    payload = json.loads(sent.content)
    assert payload["source_type"] == "target_system"
    assert payload["target_system_id"] == "ts-1"
    assert payload["probe_config"] == {"max_requests": 10}
    assert payload["evaluator_version_id"] == "ver-3"
    assert payload["evaluator_version_mode"] == "pinned"
    # Sanity: non-passed kwargs stay out of the body
    assert "category" not in payload
    assert "agent_config" not in payload

    assert evaluation.target_system_id == "ts-1"
    assert evaluation.evaluator_version_mode == "pinned"


@respx.mock
@pytest.mark.asyncio
async def test_acreate_omits_unset_optional_fields(beacon_env):
    """A trace-based evaluation should not leak system-probe keys."""
    respx.post(f"{BEACON_URL}/api/v1/evaluations").respond(
        200,
        json=_evaluation_response(
            source_type="full_trace",
            filter_rules={"logic": "AND", "rules": []},
            active=True,
        ),
    )

    await Evaluation.acreate(
        name="Trace Eval",
        evaluator_id="evaluator-1",
        variable_mappings={},
        filter_rules={"logic": "AND", "rules": []},
        active=True,
    )

    payload = json.loads(respx.calls.last.request.content)
    for absent in (
        "target_system_id",
        "probe_config",
        "evaluator_version_id",
        "evaluator_version_mode",
        "agent_config",
        "reference_dataset_id",
        "category",
        "auto_run_delay_seconds",
    ):
        assert absent not in payload


@respx.mock
@pytest.mark.asyncio
async def test_acreate_serializes_typed_variable_mappings(beacon_env):
    """Typed ``VariableMapping`` instances are normalized to wire-format dicts on POST."""
    respx.post(f"{BEACON_URL}/api/v1/evaluations").respond(
        200,
        json=_evaluation_response(source_type="full_trace"),
    )

    await Evaluation.acreate(
        name="Typed Mappings",
        evaluator_id="evaluator-1",
        variable_mappings={
            "question": VariableMapping.jsonpath("$.input"),
            "answer": VariableMapping.jsonata("messages.content"),
            "summary": VariableMapping.python("def extract(d): return d['x']"),
            # Mix in a legacy dict and a bare string to confirm passthrough.
            "legacy": {"data_mode": "raw", "json_path": "$.legacy"},
            "column": "col_x",
        },
    )

    payload = json.loads(respx.calls.last.request.content)
    mappings = payload["variable_mappings"]

    # JSONPath uses the legacy field, never `pipeline`.
    assert mappings["question"] == {"data_mode": "raw", "json_path": "$.input"}

    # JSONata / Python use `pipeline`, never `json_path`.
    assert mappings["answer"] == {
        "data_mode": "raw",
        "pipeline": [
            {"kind": "extract_path", "engine": "jsonata", "expr": "messages.content"}
        ],
    }
    assert "json_path" not in mappings["answer"]
    assert mappings["summary"]["pipeline"][0]["engine"] == "python"
    assert "json_path" not in mappings["summary"]

    # Legacy passthrough untouched.
    assert mappings["legacy"] == {"data_mode": "raw", "json_path": "$.legacy"}
    assert mappings["column"] == "col_x"


@respx.mock
@pytest.mark.asyncio
async def test_acreate_serializes_chained_pipeline(beacon_env):
    """A chained ``ProcessorStep`` pipeline survives serialization in step order."""
    respx.post(f"{BEACON_URL}/api/v1/evaluations").respond(
        200,
        json=_evaluation_response(source_type="full_trace"),
    )

    await Evaluation.acreate(
        name="Chained Pipeline",
        evaluator_id="evaluator-1",
        variable_mappings={
            "answer": VariableMapping(
                data_mode="raw",
                pipeline=[
                    ProcessorStep(
                        engine=ExtractionEngine.JSONATA, expr="messages.content"
                    ),
                    ProcessorStep(
                        engine=ExtractionEngine.PYTHON,
                        kind=ProcessorKind.RESHAPE,
                        expr="def extract(data): return ' '.join(data)",
                    ),
                ],
            ),
        },
    )

    payload = json.loads(respx.calls.last.request.content)
    pipeline = payload["variable_mappings"]["answer"]["pipeline"]
    assert [s["engine"] for s in pipeline] == ["jsonata", "python"]
    assert pipeline[1]["kind"] == "reshape"


@respx.mock
@pytest.mark.asyncio
async def test_aupdate_normalizes_typed_variable_mappings(beacon_env):
    """``aupdate`` runs the same normalization shim as ``acreate``."""
    respx.put(f"{BEACON_URL}/api/v1/evaluations/eval-100").respond(
        200,
        json=_evaluation_response(source_type="full_trace"),
    )

    evaluation = Evaluation._from_dict(_evaluation_response(source_type="full_trace"))
    await evaluation.aupdate(
        variable_mappings={"question": VariableMapping.python("def extract(d): return d")},
    )

    payload = json.loads(respx.calls.last.request.content)
    assert payload["variable_mappings"]["question"]["pipeline"][0]["engine"] == "python"
    assert "json_path" not in payload["variable_mappings"]["question"]


def test_typed_variable_mapping_helper_parses_pipeline_response():
    """``Evaluation.typed_variable_mapping`` parses the raw response into a typed view."""
    data = _evaluation_response(
        source_type="full_trace",
        variable_mappings={
            "answer": {
                "data_mode": "raw",
                "pipeline": [
                    {"kind": "extract_path", "engine": "python", "expr": "def extract(d): return d"}
                ],
            },
            "column": "col_x",
        },
    )
    evaluation = Evaluation._from_dict(data)

    typed_pipeline = evaluation.typed_variable_mapping("answer")
    assert isinstance(typed_pipeline, VariableMapping)
    assert typed_pipeline.pipeline is not None
    assert typed_pipeline.pipeline[0].engine is ExtractionEngine.PYTHON

    typed_column = evaluation.typed_variable_mapping("column")
    assert typed_column.column == "col_x"

    # Raw attribute is unchanged — backwards-compat sentinel.
    assert evaluation.variable_mappings["column"] == "col_x"
