"""Tests for evaluation type definitions."""

import pytest

from lumenova_beacon.evaluations.types import (
    CodeParameter,
    EvaluationRunStatus,
    EvaluatorType,
    ProbeMode,
    ScoreType,
    SourceType,
)


class TestEvaluationRunStatus:
    def test_all_values(self):
        assert EvaluationRunStatus.PENDING == "PENDING"
        assert EvaluationRunStatus.RUNNING == "RUNNING"
        assert EvaluationRunStatus.COMPLETED == "COMPLETED"
        assert EvaluationRunStatus.WARNING == "WARNING"
        assert EvaluationRunStatus.FAILED == "FAILED"
        assert EvaluationRunStatus.CANCELLED == "CANCELLED"

    def test_has_six_members(self):
        assert len(EvaluationRunStatus) == 6

    def test_warning_constructible_from_wire_value(self):
        assert EvaluationRunStatus("WARNING") is EvaluationRunStatus.WARNING


class TestEvaluatorType:
    def test_all_values(self):
        assert EvaluatorType.LLM_AS_JUDGE == "llm-as-judge"
        assert EvaluatorType.CODE == "code"
        assert EvaluatorType.AGENT_AS_JUDGE == "agent-as-judge"
        assert EvaluatorType.SYSTEM_PROBE == "system-probe"

    def test_has_four_members(self):
        assert len(EvaluatorType) == 4

    def test_system_probe_constructible_from_wire_value(self):
        assert EvaluatorType("system-probe") is EvaluatorType.SYSTEM_PROBE


class TestProbeMode:
    def test_all_values(self):
        assert ProbeMode.EXPLORATORY == "exploratory"
        assert ProbeMode.SYSTEMATIC == "systematic"

    def test_rejects_unknown_mode(self):
        with pytest.raises(ValueError):
            ProbeMode("unknown")


class TestSourceType:
    def test_all_values(self):
        assert SourceType.FULL_TRACE == "full_trace"
        assert SourceType.SPANS == "spans"
        assert SourceType.TARGET_SYSTEM == "target_system"

    def test_has_three_members(self):
        assert len(SourceType) == 3

    def test_target_system_constructible_from_wire_value(self):
        assert SourceType("target_system") is SourceType.TARGET_SYSTEM


class TestScoreType:
    def test_all_values(self):
        assert ScoreType.PERCENT == "percent"
        assert ScoreType.NUMERIC == "numeric"
        assert ScoreType.CATEGORICAL == "categorical"


class TestCodeParameter:
    def test_from_dict_full(self):
        param = CodeParameter.from_dict(
            {
                "name": "threshold",
                "type_hint": "float",
                "has_default": True,
                "default_value": 0.5,
            }
        )
        assert param.name == "threshold"
        assert param.type_hint == "float"
        assert param.has_default is True
        assert param.default_value == 0.5

    def test_from_dict_minimal(self):
        param = CodeParameter.from_dict({"name": "x"})
        assert param.name == "x"
        assert param.type_hint is None
        assert param.has_default is False
        assert param.default_value is None
