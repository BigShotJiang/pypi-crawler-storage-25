"""Tests for _bounded_cache_set in langchain integration."""

from __future__ import annotations

from lumenova_beacon.tracing.integrations.langchain import (
    _bounded_cache_set,
    _MAX_CACHE_SIZE,
)


class TestBoundedCacheSet:
    """Test _bounded_cache_set insertion and eviction behavior."""

    def test_basic_insertion(self):
        cache: dict = {}
        _bounded_cache_set(cache, "key1", "value1")
        assert cache == {"key1": "value1"}

    def test_multiple_insertions(self):
        cache: dict = {}
        _bounded_cache_set(cache, "a", 1)
        _bounded_cache_set(cache, "b", 2)
        _bounded_cache_set(cache, "c", 3)
        assert cache == {"a": 1, "b": 2, "c": 3}

    def test_overwrite_existing_key(self):
        cache: dict = {"key": "old"}
        _bounded_cache_set(cache, "key", "new")
        assert cache["key"] == "new"

    def test_evicts_oldest_entry_when_full(self):
        cache: dict = {f"k{i}": i for i in range(_MAX_CACHE_SIZE)}
        assert len(cache) == _MAX_CACHE_SIZE

        _bounded_cache_set(cache, "new_key", "new_value")

        assert len(cache) == _MAX_CACHE_SIZE
        assert "k0" not in cache  # oldest entry evicted
        assert cache["new_key"] == "new_value"
        assert cache["k1"] == 1  # second-oldest still present

    def test_evicts_only_one_entry(self):
        cache: dict = {f"k{i}": i for i in range(_MAX_CACHE_SIZE)}
        _bounded_cache_set(cache, "new", "val")
        assert len(cache) == _MAX_CACHE_SIZE

    def test_no_eviction_below_capacity(self):
        cache: dict = {f"k{i}": i for i in range(_MAX_CACHE_SIZE - 1)}
        _bounded_cache_set(cache, "new", "val")
        assert len(cache) == _MAX_CACHE_SIZE
        assert "k0" in cache  # nothing evicted

    def test_overwrite_existing_key_at_capacity_does_not_evict(self):
        cache: dict = {f"k{i}": i for i in range(_MAX_CACHE_SIZE)}
        assert len(cache) == _MAX_CACHE_SIZE

        # Overwrite an existing key — should NOT evict
        _bounded_cache_set(cache, "k0", "updated")

        assert len(cache) == _MAX_CACHE_SIZE
        assert cache["k0"] == "updated"
        assert "k1" in cache  # no eviction happened

    def test_max_cache_size_is_positive(self):
        assert _MAX_CACHE_SIZE > 0
