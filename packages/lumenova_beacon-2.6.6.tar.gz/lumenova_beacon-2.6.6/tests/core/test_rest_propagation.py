"""Per-module smoke tests: ``transport.httpx_kwargs(...)`` must reach the
``httpx.AsyncClient`` (or ``httpx.Client``) constructor unchanged for every
REST CRUD module.

These tests are deliberately thin — one method per module — because the goal
is to catch wiring regressions, not to retest each model's full behavior:

- A future refactor that renames ``httpx_kwargs`` and forgets a caller site
  would silently produce no proxy / no cert / no custom CA bundle in
  production for that module, while the existing per-module tests (which
  mock the transport with a bare ``MagicMock``) would still pass.
- Pinning the splat at the constructor with concrete kwarg values guards
  against accidental ``verify=transport.verify`` regressions that would
  drop the new cert/proxies/trust_env plumbing.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch


SENTINEL_KWARGS = {
    "verify": "/etc/corp-ca.pem",
    "cert": ("/etc/client.pem", "/etc/client.key"),
    "proxy": "http://corp-proxy:8080",
    "trust_env": False,
}


def _make_transport(*, with_token: bool = True) -> MagicMock:
    """Build a transport stub whose ``httpx_kwargs`` returns SENTINEL_KWARGS."""
    transport = MagicMock()
    transport.timeout = 10.0
    transport.headers = (
        {"Authorization": "Bearer test-token"} if with_token else {}
    )
    transport.httpx_kwargs.return_value = dict(SENTINEL_KWARGS)
    return transport


def _async_client_context(mock_response: MagicMock) -> MagicMock:
    """Build a MagicMock that mimics ``async with httpx.AsyncClient(...) as c:``."""
    inner = MagicMock()
    inner.get = AsyncMock(return_value=mock_response)
    inner.post = AsyncMock(return_value=mock_response)
    inner.put = AsyncMock(return_value=mock_response)
    inner.delete = AsyncMock(return_value=mock_response)
    inner.patch = AsyncMock(return_value=mock_response)

    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=inner)
    ctx.__aexit__ = AsyncMock(return_value=None)
    return ctx


def _ok_response(payload: object) -> MagicMock:
    response = MagicMock()
    response.status_code = 200
    response.raise_for_status = MagicMock()
    response.json = MagicMock(return_value=payload)
    return response


def _assert_propagated(async_client_cls: MagicMock) -> None:
    """Verify SENTINEL_KWARGS reached httpx.AsyncClient unchanged."""
    assert async_client_cls.called, "httpx.AsyncClient was never constructed"
    kwargs = async_client_cls.call_args.kwargs
    for key, expected in SENTINEL_KWARGS.items():
        assert kwargs.get(key) == expected, (
            f"expected kwarg {key!r}={expected!r} to reach httpx.AsyncClient, "
            f"got {kwargs.get(key)!r} (full kwargs: {kwargs!r})"
        )


# ---------------------------------------------------------------------------
# Datasets
# ---------------------------------------------------------------------------


async def test_datasets_alist_propagates_httpx_kwargs():
    from lumenova_beacon.datasets.models import Dataset

    transport = _make_transport()
    payload = {
        "datasets": [],
        "total": 0,
        "page": 1,
        "page_size": 20,
        "total_pages": 0,
    }
    async_client_cls = MagicMock(return_value=_async_client_context(_ok_response(payload)))

    with (
        patch("lumenova_beacon.datasets.models.get_transport", return_value=transport),
        patch("lumenova_beacon.datasets.models.get_base_url", return_value="https://api.test.com"),
        patch("lumenova_beacon.datasets.models.httpx.AsyncClient", async_client_cls),
    ):
        await Dataset.alist()

    _assert_propagated(async_client_cls)
    transport.httpx_kwargs.assert_called_with(async_client=True)


# ---------------------------------------------------------------------------
# Evaluations
# ---------------------------------------------------------------------------


async def test_evaluations_alist_propagates_httpx_kwargs():
    from lumenova_beacon.evaluations.models import Evaluation

    transport = _make_transport()
    payload = {
        "evaluations": [],
        "total": 0,
        "page": 1,
        "page_size": 20,
        "total_pages": 0,
    }
    async_client_cls = MagicMock(return_value=_async_client_context(_ok_response(payload)))

    with (
        patch("lumenova_beacon.evaluations.models.get_transport", return_value=transport),
        patch("lumenova_beacon.evaluations.models.get_base_url", return_value="https://api.test.com"),
        patch("lumenova_beacon.evaluations.models.httpx.AsyncClient", async_client_cls),
    ):
        await Evaluation.alist(page=1, page_size=20)

    _assert_propagated(async_client_cls)
    transport.httpx_kwargs.assert_called_with(async_client=True)


# ---------------------------------------------------------------------------
# Experiments
# ---------------------------------------------------------------------------


async def test_experiments_alist_propagates_httpx_kwargs():
    from lumenova_beacon.experiments.models import Experiment

    transport = _make_transport()
    payload = {
        "items": [],
        "total": 0,
        "page": 1,
        "page_size": 20,
        "total_pages": 0,
    }
    async_client_cls = MagicMock(return_value=_async_client_context(_ok_response(payload)))

    with (
        patch("lumenova_beacon.experiments.models.get_transport", return_value=transport),
        patch("lumenova_beacon.experiments.models.get_base_url", return_value="https://api.test.com"),
        patch("lumenova_beacon.experiments.models.httpx.AsyncClient", async_client_cls),
    ):
        await Experiment.alist()

    _assert_propagated(async_client_cls)
    transport.httpx_kwargs.assert_called_with(async_client=True)


# ---------------------------------------------------------------------------
# LLM Configs
# ---------------------------------------------------------------------------


async def test_llm_configs_alist_propagates_httpx_kwargs():
    from lumenova_beacon.llm_configs.models import LLMConfig

    transport = _make_transport()
    payload: list[dict] = []
    async_client_cls = MagicMock(return_value=_async_client_context(_ok_response(payload)))

    with (
        patch("lumenova_beacon.llm_configs.models.get_transport", return_value=transport),
        patch("lumenova_beacon.llm_configs.models.get_base_url", return_value="https://api.test.com"),
        patch(
            "lumenova_beacon.llm_configs.models._aget_project_id",
            new=AsyncMock(return_value="proj-1"),
        ),
        patch("lumenova_beacon.llm_configs.models.httpx.AsyncClient", async_client_cls),
    ):
        await LLMConfig.alist()

    _assert_propagated(async_client_cls)
    transport.httpx_kwargs.assert_called_with(async_client=True)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------


async def test_prompts_alist_propagates_httpx_kwargs():
    from lumenova_beacon.prompts.models import Prompt

    transport = _make_transport()
    payload = {"data": [], "total": 0, "page": 1, "page_size": 10}
    async_client_cls = MagicMock(return_value=_async_client_context(_ok_response(payload)))

    with (
        patch("lumenova_beacon.prompts.models.get_transport", return_value=transport),
        patch("lumenova_beacon.prompts.models.get_base_url", return_value="https://api.test.com"),
        patch("lumenova_beacon.prompts.models.httpx.AsyncClient", async_client_cls),
    ):
        await Prompt.alist()

    _assert_propagated(async_client_cls)
    transport.httpx_kwargs.assert_called_with(async_client=True)


# ---------------------------------------------------------------------------
# Probes
# ---------------------------------------------------------------------------


async def test_probes_shared_client_propagates_httpx_kwargs():
    from lumenova_beacon.probes import _beacon_client as beacon_client_mod

    transport = _make_transport()
    async_client_cls = MagicMock(return_value=_async_client_context(_ok_response({})))

    with (
        patch.object(beacon_client_mod, "get_transport", return_value=transport),
        patch.object(beacon_client_mod.httpx, "AsyncClient", async_client_cls),
    ):
        async with beacon_client_mod.shared_beacon_client():
            pass

    _assert_propagated(async_client_cls)
    transport.httpx_kwargs.assert_called_with(async_client=True)


# ---------------------------------------------------------------------------
# Masking integration (Beacon Guardrails)
# ---------------------------------------------------------------------------


async def test_masking_integration_propagates_httpx_kwargs():
    from lumenova_beacon.masking.integrations import beacon_guardrails

    transport = _make_transport()
    async_client_cls = MagicMock(
        return_value=_async_client_context(
            _ok_response({"masked_text": "[REDACTED]"})
        )
    )

    with (
        patch.object(beacon_guardrails, "_get_transport", return_value=transport),
        patch.object(beacon_guardrails, "_get_base_url", return_value="https://api.test.com"),
        patch.object(beacon_guardrails.httpx, "AsyncClient", async_client_cls),
    ):
        client = beacon_guardrails.BeaconGuardrailsClient()
        await client.mask_text_async("some text")

    _assert_propagated(async_client_cls)
    transport.httpx_kwargs.assert_called_with(async_client=True)


# ---------------------------------------------------------------------------
# Sync paths: governance and guardrails are already tested with concrete
# propagation in tests/governance and tests/guardrails. The masking
# integration's sync path is covered here for completeness.
# ---------------------------------------------------------------------------


def test_masking_integration_sync_propagates_httpx_kwargs():
    from lumenova_beacon.masking.integrations import beacon_guardrails

    transport = _make_transport()

    client_cls = MagicMock()
    response = _ok_response({"masked_text": "[REDACTED]"})
    sync_client = MagicMock()
    sync_client.post = MagicMock(return_value=response)
    client_cls.return_value.__enter__ = MagicMock(return_value=sync_client)
    client_cls.return_value.__exit__ = MagicMock(return_value=None)

    with (
        patch.object(beacon_guardrails, "_get_transport", return_value=transport),
        patch.object(beacon_guardrails, "_get_base_url", return_value="https://api.test.com"),
        patch.object(beacon_guardrails.httpx, "Client", client_cls),
    ):
        client = beacon_guardrails.BeaconGuardrailsClient()
        client.mask_text("some text")

    kwargs = client_cls.call_args.kwargs
    for key, expected in SENTINEL_KWARGS.items():
        assert kwargs.get(key) == expected
    # sync path: httpx_kwargs() called without async_client.
    transport.httpx_kwargs.assert_called_with()


# ---------------------------------------------------------------------------
# Mutating methods (POST/PUT/DELETE)
#
# The ``alist`` tests above cover the GET path. Mutating methods are wired
# independently (one ``async with httpx.AsyncClient(...) as client:`` block
# per call site), so each must be exercised separately or a regression that
# drops the splat in, e.g., ``Dataset._acreate`` would slip past tests that
# only exercise ``Dataset.alist``. We patch ``_from_dict`` (or the analog) so
# the test asserts on the constructor kwargs without depending on response
# schema details.
# ---------------------------------------------------------------------------


async def test_datasets_acreate_propagates_httpx_kwargs():
    from lumenova_beacon.datasets import models as datasets_models

    transport = _make_transport()
    response_payload = {
        "id": "ds-1",
        "name": "test",
        "column_schema": [{"name": "c"}],
    }
    async_client_cls = MagicMock(
        return_value=_async_client_context(_ok_response(response_payload))
    )

    with (
        patch.object(datasets_models, "get_transport", return_value=transport),
        patch.object(datasets_models, "get_base_url", return_value="https://api.test.com"),
        patch.object(datasets_models.httpx, "AsyncClient", async_client_cls),
        # Skip server response parsing — we only care that the POST splat happened.
        patch.object(
            datasets_models.Dataset, "_update_from_response", lambda self, data: None
        ),
    ):
        await datasets_models.Dataset.acreate(
            name="test", column_schema=[{"name": "c"}]
        )

    _assert_propagated(async_client_cls)


async def test_datasets_adelete_propagates_httpx_kwargs():
    """DELETE has no response body to parse — pure constructor-kwargs check."""
    from lumenova_beacon.datasets import models as datasets_models

    transport = _make_transport()
    async_client_cls = MagicMock(return_value=_async_client_context(_ok_response({})))

    with (
        patch.object(datasets_models, "get_transport", return_value=transport),
        patch.object(datasets_models, "get_base_url", return_value="https://api.test.com"),
        patch.object(datasets_models.httpx, "AsyncClient", async_client_cls),
    ):
        # id=... sets _is_new=False in __init__, so adelete doesn't refuse the call.
        dataset = datasets_models.Dataset(
            name="test", id="ds-1", column_schema=[{"name": "c"}]
        )
        await dataset.adelete()

    _assert_propagated(async_client_cls)


async def test_experiments_acreate_propagates_httpx_kwargs():
    from lumenova_beacon.experiments import models as experiments_models

    transport = _make_transport()
    async_client_cls = MagicMock(
        return_value=_async_client_context(_ok_response({"id": "exp-1"}))
    )

    with (
        patch.object(experiments_models, "get_transport", return_value=transport),
        patch.object(experiments_models, "get_base_url", return_value="https://api.test.com"),
        patch.object(experiments_models.httpx, "AsyncClient", async_client_cls),
        patch.object(
            experiments_models.Experiment, "_from_dict", classmethod(lambda cls, data: None)
        ),
    ):
        await experiments_models.Experiment.acreate(
            name="x", dataset_id="ds-1", steps=[],
        )

    _assert_propagated(async_client_cls)


async def test_evaluations_acreate_propagates_httpx_kwargs():
    from lumenova_beacon.evaluations import models as evaluations_models

    transport = _make_transport()
    async_client_cls = MagicMock(
        return_value=_async_client_context(_ok_response({"id": "ev-1"}))
    )

    with (
        patch.object(evaluations_models, "get_transport", return_value=transport),
        patch.object(evaluations_models, "get_base_url", return_value="https://api.test.com"),
        patch.object(evaluations_models.httpx, "AsyncClient", async_client_cls),
        patch.object(
            evaluations_models.Evaluation, "_from_dict", classmethod(lambda cls, data: None)
        ),
    ):
        await evaluations_models.Evaluation.acreate(
            name="ev",
            evaluator_id="e1",
            variable_mappings={"x": "y"},
            dataset_id="ds-1",
        )

    _assert_propagated(async_client_cls)


async def test_prompts_acreate_propagates_httpx_kwargs():
    from lumenova_beacon.prompts import models as prompts_models

    transport = _make_transport()
    async_client_cls = MagicMock(
        return_value=_async_client_context(_ok_response({"id": "p-1"}))
    )

    with (
        patch.object(prompts_models, "get_transport", return_value=transport),
        patch.object(prompts_models, "get_base_url", return_value="https://api.test.com"),
        patch.object(prompts_models.httpx, "AsyncClient", async_client_cls),
        patch.object(
            prompts_models.Prompt, "_from_dict", classmethod(lambda cls, data: None)
        ),
    ):
        await prompts_models.Prompt.acreate(name="p", template="hello {name}")

    _assert_propagated(async_client_cls)


# ---------------------------------------------------------------------------
# Mounts branch end-to-end through a REST call
#
# ``_proxies_to_httpx`` emits ``mounts={...}`` when http and https proxies
# differ. The translator is unit-tested in test_transport.py, but never
# exercised end-to-end through a REST call — a caller that forgot to splat
# ``transport.httpx_kwargs()`` and instead built ``{"proxy": ...}`` by hand
# would silently lose the per-scheme mounts. Pin one REST call to the
# mounts shape to catch that.
# ---------------------------------------------------------------------------


async def test_datasets_alist_propagates_mounts_kwarg():
    from lumenova_beacon.datasets.models import Dataset

    mounts_sentinel = {"http://": object(), "https://": object()}
    transport = MagicMock()
    transport.timeout = 10.0
    transport.headers = {"Authorization": "Bearer test-token"}
    transport.httpx_kwargs.return_value = {
        "verify": True,
        "mounts": mounts_sentinel,
        "trust_env": False,
    }

    payload = {
        "datasets": [], "total": 0, "page": 1, "page_size": 20, "total_pages": 0,
    }
    async_client_cls = MagicMock(return_value=_async_client_context(_ok_response(payload)))

    with (
        patch("lumenova_beacon.datasets.models.get_transport", return_value=transport),
        patch("lumenova_beacon.datasets.models.get_base_url", return_value="https://api.test.com"),
        patch("lumenova_beacon.datasets.models.httpx.AsyncClient", async_client_cls),
    ):
        await Dataset.alist()

    kwargs = async_client_cls.call_args.kwargs
    assert kwargs.get("mounts") is mounts_sentinel
    assert kwargs.get("trust_env") is False


# ---------------------------------------------------------------------------
# Regression guard: a bare ``MagicMock`` transport would let a future caller
# silently drop the splat. Verify that ``**MagicMock()`` evaluates to ``{}``
# so future readers understand WHY the per-module smoke tests above use a
# real-looking transport with ``httpx_kwargs.return_value = {...}``.
# ---------------------------------------------------------------------------


def test_documentation_bare_magicmock_splats_empty():
    """If `transport.httpx_kwargs(...)` is a bare MagicMock and gets splatted
    as ``**transport.httpx_kwargs(...)``, the kwargs reduce to {} — a future
    refactor dropping the splat would not be caught by tests that mock the
    transport this way. Hence the explicit return_value above."""
    bare = MagicMock()
    result = bare.httpx_kwargs.return_value

    def _accept_kwargs(**kw):
        return kw

    assert _accept_kwargs(**result) == {}
