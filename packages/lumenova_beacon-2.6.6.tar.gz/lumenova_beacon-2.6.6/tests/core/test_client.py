"""Tests for BeaconClient."""

import logging
import os

from unittest.mock import patch

import pytest

from lumenova_beacon import BeaconClient
from lumenova_beacon.core.transport import FileTransport, HTTPTransport
from lumenova_beacon.exceptions import ConfigurationError
from lumenova_beacon.tracing.trace import TraceContext
from lumenova_beacon.types import SpanKind, SpanType


@pytest.fixture
def cert_files(tmp_path):
    """Real on-disk dummy cert/key/CA files so path-validation tests pass.

    Path validation in `_normalize_verify` / `_normalize_cert` rejects missing
    files (a typo would otherwise silently drop spans after a one-shot warning).
    These fixtures produce real files so tests that exercise the happy path do
    not collide with that validation.
    """
    files = {
        "cert": tmp_path / "client.pem",
        "crt": tmp_path / "client.crt",
        "key": tmp_path / "client.key",
        "ca": tmp_path / "corp-ca.pem",
        "env_cert": tmp_path / "env-client.pem",
        "env_crt": tmp_path / "env.crt",
        "env_key": tmp_path / "env.key",
        "param_cert": tmp_path / "param-client.pem",
        "param_ca": tmp_path / "param-ca.pem",
        "env_ca": tmp_path / "env-ca.pem",
    }
    for path in files.values():
        path.write_text("dummy-pem")
    return {name: str(path) for name, path in files.items()}


class TestBeaconClientInitialization:
    """Test BeaconClient initialization."""

    def test_init_with_endpoint(self):
        """Test initialization with HTTP endpoint."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            api_key="test-key",
            auto_instrument_opentelemetry=False,
        )

        assert client.config.endpoint == "https://api.test.com"
        assert client.config.api_key == "test-key"
        assert isinstance(client.transport, HTTPTransport)
        assert client.transport.endpoint == "https://api.test.com"

    def test_init_with_file_directory(self, temp_span_directory):
        """Test initialization with file directory."""
        client = BeaconClient(
            file_directory=str(temp_span_directory),
            auto_instrument_opentelemetry=False,
        )

        assert client.config.file_directory == str(temp_span_directory)
        assert isinstance(client.transport, FileTransport)
        assert client.transport.directory == temp_span_directory

    def test_init_file_only_mode(self, temp_span_directory):
        """Test that file-only mode sets up FileSpanExporter without errors."""
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("BEACON_ENDPOINT", None)
            client = BeaconClient(
                file_directory=str(temp_span_directory),
            )

            assert isinstance(client.transport, FileTransport)
            assert client.config.endpoint == ''

    def test_init_with_env_vars(self):
        """Test initialization with environment variables."""
        with patch.dict(
            os.environ,
            {
                "BEACON_ENDPOINT": "https://env.test.com",
                "BEACON_API_KEY": "env-key",
                "BEACON_SESSION_ID": "env-session",
                "BEACON_SERVICE_NAME": "env-service",
            },
        ):
            client = BeaconClient(auto_instrument_opentelemetry=False)

            assert client.config.endpoint == "https://env.test.com"
            assert client.config.api_key == "env-key"
            assert client.config.session_id == "env-session"
            assert client.config.service_name == "env-service"

    def test_init_params_override_env_vars(self):
        """Test that constructor parameters override environment variables."""
        with patch.dict(
            os.environ,
            {
                "BEACON_ENDPOINT": "https://env.test.com",
                "BEACON_API_KEY": "env-key",
                "BEACON_SERVICE_NAME": "env-service",
            },
        ):
            client = BeaconClient(
                endpoint="https://param.test.com",
                api_key="param-key",
                service_name="param-service",
                auto_instrument_opentelemetry=False,
            )

            assert client.config.endpoint == "https://param.test.com"
            assert client.config.api_key == "param-key"
            assert client.config.service_name == "param-service"

    def test_init_with_verify_ssl(self):
        """Test initialization with SSL verification options."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=False,
            auto_instrument_opentelemetry=False,
        )

        assert client.config.verify is False
        assert client.transport.verify is False

    def test_init_with_verify_env_var(self):
        """Test SSL verification from environment variable."""
        with patch.dict(os.environ, {"BEACON_VERIFY": "false"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
            assert client.config.verify is False

    def test_init_with_custom_headers(self):
        """Test initialization with custom headers."""
        custom_headers = {"X-Custom-Header": "test-value"}
        client = BeaconClient(
            endpoint="https://api.test.com",
            headers=custom_headers,
            auto_instrument_opentelemetry=False,
        )

        assert "X-Custom-Header" in client.transport.headers
        assert client.transport.headers["X-Custom-Header"] == "test-value"

    def test_init_sets_current_client(self):
        """Test that initialization sets the current client in context."""
        from lumenova_beacon.core.client import get_client

        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )

        assert get_client() == client

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_init_with_auto_instrument(self, mock_setup):
        """Test initialization with auto instrumentation enabled."""
        BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=True,
        )

        mock_setup.assert_called_once()

    def test_init_without_auto_instrument(self):
        """Test initialization with auto instrumentation disabled."""
        with patch(
            "lumenova_beacon.core.client.BeaconClient._setup_opentelemetry"
        ) as mock_setup:
            BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )

            mock_setup.assert_not_called()


class TestBeaconClientSpanCreation:
    """Test BeaconClient span creation methods."""

    @pytest.fixture
    def client(self):
        """Create a test client."""
        return BeaconClient(
            endpoint="https://api.test.com",
            session_id="test-session",
            auto_instrument_opentelemetry=False,
        )

    def test_create_span_basic(self, client):
        """Test creating a basic span."""
        span = client.create_span("test_operation")

        assert span.name == "test_operation"
        assert span.kind == SpanKind.INTERNAL
        assert span.span_type == SpanType.SPAN
        assert span.session_id == "test-session"
        assert span.trace_id is not None
        assert span.span_id is not None
        assert span.parent_id is None

    def test_create_span_with_custom_kind_and_type(self, client):
        """Test creating a span with custom kind and type."""
        span = client.create_span(
            "llm_call",
            kind=SpanKind.CLIENT,
            span_type=SpanType.GENERATION,
        )

        assert span.name == "llm_call"
        assert span.kind == SpanKind.CLIENT
        assert span.span_type == SpanType.GENERATION

    def test_create_span_with_explicit_session_id(self, client):
        """Test creating a span with explicit session ID."""
        span = client.create_span(
            "test_op",
            session_id="custom-session",
        )

        assert span.session_id == "custom-session"

    def test_create_span_with_parent_context(self, client):
        """Test creating a span with parent context."""
        # Create parent span and set it in context
        parent_span = client.create_span("parent_operation")
        parent_span.start()

        from lumenova_beacon.tracing.trace import set_current_span

        set_current_span(parent_span)

        # Create child span
        child_span = client.create_span("child_operation")

        assert child_span.parent_id == parent_span.span_id
        assert child_span.trace_id == parent_span.trace_id
        assert child_span.session_id == parent_span.session_id

    def test_create_span_without_auto_parent(self, client):
        """Test creating a span without auto-parenting.

        When auto_parent=False, the span should not have a parent_id set,
        but it may still share the trace_id from the current context.
        """
        # Create parent span and set it in context
        parent_span = client.create_span("parent_operation")

        from lumenova_beacon.tracing.trace import set_current_span

        set_current_span(parent_span)

        # Create child span with auto_parent=False
        child_span = client.create_span("child_operation", auto_parent=False)

        # With auto_parent=False, no parent_id is set
        assert child_span.parent_id is None
        # Note: trace_id can still be inherited from context
        # The key difference is that there's no parent-child relationship

    def test_trace_context_manager(self, client):
        """Test creating a trace context manager."""
        trace_ctx = client.trace("operation_name")

        assert isinstance(trace_ctx, TraceContext)
        assert trace_ctx.span.name == "operation_name"
        assert trace_ctx.client == client

    def test_trace_context_manager_starts_span(self, client):
        """Test that trace context manager starts the span."""
        trace_ctx = client.trace("operation_name")

        assert trace_ctx.span.start_time is not None

    def test_trace_context_manager_with_params(self, client):
        """Test trace context manager with custom parameters."""
        trace_ctx = client.trace(
            "llm_call",
            kind=SpanKind.CLIENT,
            span_type=SpanType.GENERATION,
        )

        assert trace_ctx.span.kind == SpanKind.CLIENT
        assert trace_ctx.span.span_type == SpanType.GENERATION


class TestBeaconClientSampling:
    """Test BeaconClient sampling methods."""

    @pytest.fixture
    def client(self):
        """Create a test client."""
        return BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )

    def test_should_sample_when_enabled(self, client):
        """Test should_sample returns True when enabled."""
        assert client.should_sample() is True

    def test_should_sample_when_disabled(self):
        """Test should_sample returns False when disabled."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            enabled=False,
            auto_instrument_opentelemetry=False,
        )

        assert client.should_sample() is False


class TestBeaconClientUtilityMethods:
    """Test BeaconClient utility methods."""

    def test_get_base_url_http_transport(self):
        """Test getting base URL with HTTP transport."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )

        assert client.get_base_url() == "https://api.test.com"

    def test_get_base_url_file_transport_raises_error(self, temp_span_directory):
        """Test that get_base_url raises error with file transport."""
        client = BeaconClient(
            file_directory=str(temp_span_directory),
            auto_instrument_opentelemetry=False,
        )

        with pytest.raises(ConfigurationError) as exc_info:
            client.get_base_url()

        assert "HTTPTransport" in str(exc_info.value)

    def test_flush_method(self):
        """Test flush method (currently no-op)."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )

        # Should not raise any errors
        client.flush()


class TestGetClient:
    """Test get_client() function."""

    def test_get_client_returns_existing(self):
        """Test that get_client returns existing client."""
        from lumenova_beacon.core.client import get_client

        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )

        retrieved = get_client()
        assert retrieved == client

    def test_get_client_creates_new_when_none(self):
        """Test that get_client creates new client when none exists."""
        from lumenova_beacon.core.client import _current_client, get_client

        # Clear the current client
        _current_client.set(None)

        # Mock the environment to provide required config
        with patch.dict(os.environ, {"BEACON_ENDPOINT": "https://api.test.com"}):
            with patch(
                "lumenova_beacon.core.client.BeaconClient._setup_opentelemetry"
            ):
                retrieved = get_client()
                assert isinstance(retrieved, BeaconClient)


class TestOpenTelemetrySetup:
    """Test OpenTelemetry auto-instrumentation setup."""

    def test_setup_opentelemetry_runs_without_error(self):
        """Test that OpenTelemetry setup completes without error."""
        # Simply verify the client can be created with auto_instrument=True
        # The setup method should handle all cases gracefully
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=True,
        )

        # Client should be created successfully
        assert client is not None
        assert client.config.endpoint == "https://api.test.com"

    def test_setup_opentelemetry_disabled(self):
        """Test that OpenTelemetry setup can be disabled."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )

        # Client should be created successfully
        assert client is not None

    def test_manual_setup_opentelemetry_call(self):
        """Test that _setup_opentelemetry can be called manually."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )

        # Calling setup manually should not raise
        client._setup_opentelemetry()

    def test_setup_opentelemetry_errors_when_not_installed(self, caplog):
        """Test that an error is logged when OpenTelemetry is not installed."""
        import lumenova_beacon.core.client as client_module

        with patch.object(client_module, '_beacon_global_exporter_added', False):
            with patch.dict("sys.modules", {"opentelemetry": None, "opentelemetry.trace": None,
                                             "opentelemetry.sdk.trace": None,
                                             "opentelemetry.sdk.trace.export": None,
                                             "opentelemetry.sdk.resources": None}):
                with caplog.at_level(logging.ERROR, logger="lumenova_beacon.core.client"):
                    BeaconClient(
                        endpoint="https://api.test.com",
                        auto_instrument_opentelemetry=True,
                    )

        assert any(
            "OpenTelemetry SDK not installed" in record.message
            and record.levelno == logging.ERROR
            for record in caplog.records
        )

    def test_setup_litellm_warns_when_not_installed(self, caplog):
        """Test that a warning is logged when litellm is not installed."""
        with patch.dict("sys.modules", {"litellm": None}):
            with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    auto_instrument_opentelemetry=False,
                    auto_instrument_litellm=True,
                )

        assert any(
            "litellm not installed" in record.message
            and record.levelno == logging.WARNING
            for record in caplog.records
        )


class TestEagerExportConfig:
    """Test eager_export configuration."""

    def test_eager_export_defaults_to_true(self):
        """Test that eager_export defaults to True."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )
        assert client.config.eager_export is True

    def test_eager_export_explicit_false(self):
        """Test that eager_export can be set to False explicitly."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            eager_export=False,
            auto_instrument_opentelemetry=False,
        )
        assert client.config.eager_export is False

    def test_eager_export_explicit_true(self):
        """Test that eager_export can be set to True explicitly."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            eager_export=True,
            auto_instrument_opentelemetry=False,
        )
        assert client.config.eager_export is True

    def test_eager_export_env_var_false(self):
        """Test eager_export resolved from BEACON_EAGER_EXPORT=false."""
        with patch.dict(os.environ, {"BEACON_EAGER_EXPORT": "false"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
            assert client.config.eager_export is False

    def test_eager_export_env_var_zero(self):
        """Test eager_export resolved from BEACON_EAGER_EXPORT=0."""
        with patch.dict(os.environ, {"BEACON_EAGER_EXPORT": "0"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
            assert client.config.eager_export is False

    def test_eager_export_env_var_no(self):
        """Test eager_export resolved from BEACON_EAGER_EXPORT=no."""
        with patch.dict(os.environ, {"BEACON_EAGER_EXPORT": "no"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
            assert client.config.eager_export is False

    def test_eager_export_env_var_true(self):
        """Test eager_export resolved from BEACON_EAGER_EXPORT=true."""
        with patch.dict(os.environ, {"BEACON_EAGER_EXPORT": "true"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
            assert client.config.eager_export is True

    def test_eager_export_param_overrides_env_var(self):
        """Test that explicit param overrides env var."""
        with patch.dict(os.environ, {"BEACON_EAGER_EXPORT": "false"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                eager_export=True,
                auto_instrument_opentelemetry=False,
            )
            assert client.config.eager_export is True

    def test_trace_context_receives_eager_export(self):
        """Test that client.trace() returns a TraceContext with eager_export enabled."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            eager_export=True,
            auto_instrument_opentelemetry=False,
        )
        trace_ctx = client.trace("test_op")
        assert trace_ctx.client.config.eager_export is True

    def test_trace_context_receives_eager_export_false(self):
        """Test that client.trace() returns a TraceContext with eager_export disabled."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            eager_export=False,
            auto_instrument_opentelemetry=False,
        )
        trace_ctx = client.trace("test_op")
        assert trace_ctx.client.config.eager_export is False


class TestEnvironmentConfig:
    """Test environment configuration."""

    def test_environment_explicit_param(self):
        """Test that environment can be set via constructor param."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            environment="production",
            auto_instrument_opentelemetry=False,
        )
        assert client.config.environment == "production"

    def test_environment_env_var_fallback(self):
        """Test that environment falls back to BEACON_ENVIRONMENT env var."""
        with patch.dict(os.environ, {"BEACON_ENVIRONMENT": "staging"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
            assert client.config.environment == "staging"

    def test_environment_param_overrides_env_var(self):
        """Test that explicit param overrides BEACON_ENVIRONMENT env var."""
        with patch.dict(os.environ, {"BEACON_ENVIRONMENT": "staging"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                environment="production",
                auto_instrument_opentelemetry=False,
            )
            assert client.config.environment == "production"

    def test_environment_defaults_to_none(self):
        """Test that environment defaults to None when not set."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )
        assert client.config.environment is None

    def test_environment_propagated_to_spans(self):
        """Test that environment is set as span attribute on created spans."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            environment="production",
            auto_instrument_opentelemetry=False,
        )
        span = client.create_span("test_op")
        assert span.attributes.get("deployment.environment.name") == "production"

    def test_environment_not_set_on_spans_when_none(self):
        """Test that no environment attribute is set when environment is None."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )
        span = client.create_span("test_op")
        assert "deployment.environment.name" not in span.attributes

    def test_environment_in_env_var_init_test(self):
        """Test that BEACON_ENVIRONMENT is picked up alongside other env vars."""
        with patch.dict(
            os.environ,
            {
                "BEACON_ENDPOINT": "https://env.test.com",
                "BEACON_API_KEY": "env-key",
                "BEACON_ENVIRONMENT": "development",
            },
        ):
            client = BeaconClient(auto_instrument_opentelemetry=False)
            assert client.config.environment == "development"


class TestBeaconIsolatedEnvVar:
    """Test BEACON_ISOLATED environment variable support."""

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_isolated_defaults_to_false(self, mock_setup):
        BeaconClient(endpoint="https://api.test.com")
        mock_setup.assert_called_once_with(isolated=False)

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_isolated_env_var_true(self, mock_setup):
        with patch.dict(os.environ, {"BEACON_ISOLATED": "true"}):
            BeaconClient(endpoint="https://api.test.com")
        mock_setup.assert_called_once_with(isolated=True)

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_isolated_env_var_1(self, mock_setup):
        with patch.dict(os.environ, {"BEACON_ISOLATED": "1"}):
            BeaconClient(endpoint="https://api.test.com")
        mock_setup.assert_called_once_with(isolated=True)

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_isolated_env_var_yes(self, mock_setup):
        with patch.dict(os.environ, {"BEACON_ISOLATED": "yes"}):
            BeaconClient(endpoint="https://api.test.com")
        mock_setup.assert_called_once_with(isolated=True)

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_isolated_param_overrides_env_var_false(self, mock_setup):
        with patch.dict(os.environ, {"BEACON_ISOLATED": "false"}):
            BeaconClient(endpoint="https://api.test.com", isolated=True)
        mock_setup.assert_called_once_with(isolated=True)

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_isolated_env_var_false(self, mock_setup):
        with patch.dict(os.environ, {"BEACON_ISOLATED": "false"}):
            BeaconClient(endpoint="https://api.test.com")
        mock_setup.assert_called_once_with(isolated=False)


class TestApiKeyAwsResolution:
    """Test API key resolution cascade: param > env > AWS."""

    def test_api_key_param_takes_precedence_over_aws(self):
        with patch.dict(os.environ, {"BEACON_AWS_SECRET_NAME": "my-secret"}):
            with patch("lumenova_beacon.core.secrets.resolve_aws_secret") as mock_aws:
                client = BeaconClient(
                    endpoint="https://api.test.com",
                    api_key="explicit-key",
                    auto_instrument_opentelemetry=False,
                )
                mock_aws.assert_not_called()
                assert client.config.api_key == "explicit-key"

    def test_api_key_env_var_takes_precedence_over_aws(self):
        with patch.dict(os.environ, {
            "BEACON_ENDPOINT": "https://api.test.com",
            "BEACON_API_KEY": "env-key",
            "BEACON_AWS_SECRET_NAME": "my-secret",
        }):
            with patch("lumenova_beacon.core.secrets.resolve_aws_secret") as mock_aws:
                client = BeaconClient(auto_instrument_opentelemetry=False)
                mock_aws.assert_not_called()
                assert client.config.api_key == "env-key"

    @patch("lumenova_beacon.core.secrets.resolve_aws_secret", return_value="aws-key")
    def test_api_key_falls_through_to_aws(self, mock_aws):
        with patch.dict(os.environ, {
            "BEACON_ENDPOINT": "https://api.test.com",
            "BEACON_AWS_SECRET_NAME": "my-secret",
        }, clear=False):
            # Remove BEACON_API_KEY if present
            os.environ.pop("BEACON_API_KEY", None)
            client = BeaconClient(auto_instrument_opentelemetry=False)
            assert client.config.api_key == "aws-key"

    @patch("lumenova_beacon.core.secrets.resolve_aws_secret", return_value=None)
    def test_api_key_aws_failure_returns_none(self, mock_aws):
        with patch.dict(os.environ, {
            "BEACON_ENDPOINT": "https://api.test.com",
            "BEACON_AWS_SECRET_NAME": "my-secret",
        }, clear=False):
            os.environ.pop("BEACON_API_KEY", None)
            client = BeaconClient(auto_instrument_opentelemetry=False)
            assert client.config.api_key is None


class TestExtraOtlpEndpoints:
    """Test BEACON_EXTRA_OTLP_ENDPOINTS environment variable support."""

    @patch("lumenova_beacon.core.client.BeaconClient._setup_additional_otlp_endpoints")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_no_additional_endpoints_by_default(self, mock_otel, mock_extra):
        BeaconClient(endpoint="https://api.test.com")
        mock_extra.assert_called_once()

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_single_additional_endpoint(self, mock_otel, mock_exporter_cls, mock_add):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            BeaconClient(endpoint="https://api.test.com")
        mock_exporter_cls.assert_called_once()
        mock_add.assert_called_once()

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_multiple_additional_endpoints(self, mock_otel, mock_exporter_cls, mock_add):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector1:4317,http://collector2:4317",
        }):
            BeaconClient(endpoint="https://api.test.com")
        assert mock_exporter_cls.call_count == 2
        assert mock_add.call_count == 2

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_authorization_header_excluded(self, mock_otel, mock_exporter_cls, mock_add):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            BeaconClient(endpoint="https://api.test.com", api_key="secret-key")
        mock_exporter_cls.assert_called_once()
        call_headers = mock_exporter_cls.call_args[1]["headers"]
        assert "Authorization" not in call_headers
        assert "authorization" not in call_headers

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_empty_env_var_ignored(self, mock_otel, mock_add):
        with patch.dict(os.environ, {"BEACON_EXTRA_OTLP_ENDPOINTS": ""}):
            BeaconClient(endpoint="https://api.test.com")
        mock_add.assert_not_called()

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_http_endpoint_on_port_4318(self, mock_otel, mock_http_exporter_cls, mock_add):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4318",
        }):
            BeaconClient(endpoint="https://api.test.com")
        mock_http_exporter_cls.assert_called_once()
        call_kwargs = mock_http_exporter_cls.call_args[1]
        assert call_kwargs["endpoint"] == "http://collector:4318/v1/traces"
        mock_add.assert_called_once()

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_http_endpoint_no_double_suffix(self, mock_otel, mock_http_exporter_cls, mock_add):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4318/v1/traces",
        }):
            BeaconClient(endpoint="https://api.test.com")
        mock_http_exporter_cls.assert_called_once()
        call_kwargs = mock_http_exporter_cls.call_args[1]
        assert call_kwargs["endpoint"] == "http://collector:4318/v1/traces"

    @patch("lumenova_beacon.core.client.BeaconClient._setup_additional_otlp_endpoints")
    def test_endpoints_not_added_when_otel_disabled(self, mock_extra):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        mock_extra.assert_not_called()


class TestProxiesConfig:
    """Test `proxies` argument and `BEACON_PROXIES` env var support."""

    def test_proxies_defaults_to_none(self):
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )
        assert client.config.proxies is None

    def test_proxies_dict_param(self):
        proxies = {"http": "http://p:8080", "https": "https://p:8443"}
        client = BeaconClient(
            endpoint="https://api.test.com",
            proxies=proxies,
            auto_instrument_opentelemetry=False,
        )
        assert client.config.proxies == proxies

    def test_proxies_empty_dict_normalizes_to_none(self):
        client = BeaconClient(
            endpoint="https://api.test.com",
            proxies={},
            auto_instrument_opentelemetry=False,
        )
        assert client.config.proxies is None

    def test_proxies_string_param_expands(self):
        client = BeaconClient(
            endpoint="https://api.test.com",
            proxies="http://corp-proxy:8080",
            auto_instrument_opentelemetry=False,
        )
        assert client.config.proxies == {
            "http": "http://corp-proxy:8080",
            "https": "http://corp-proxy:8080",
        }

    def test_proxies_whitespace_string_normalizes_to_none(self):
        client = BeaconClient(
            endpoint="https://api.test.com",
            proxies="   ",
            auto_instrument_opentelemetry=False,
        )
        assert client.config.proxies is None

    def test_proxies_env_var_url(self):
        with patch.dict(os.environ, {"BEACON_PROXIES": "http://corp-proxy:8080"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.proxies == {
            "http": "http://corp-proxy:8080",
            "https": "http://corp-proxy:8080",
        }

    def test_proxies_env_var_json(self):
        with patch.dict(os.environ, {
            "BEACON_PROXIES": '{"http": "http://p1:8080", "https": "http://p2:8080"}',
        }):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.proxies == {
            "http": "http://p1:8080",
            "https": "http://p2:8080",
        }

    def test_proxies_param_overrides_env_var(self):
        with patch.dict(os.environ, {"BEACON_PROXIES": "http://env-proxy:9999"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                proxies={"http": "http://param:8080", "https": "http://param:8080"},
                auto_instrument_opentelemetry=False,
            )
        assert client.config.proxies == {
            "http": "http://param:8080",
            "https": "http://param:8080",
        }

    def test_proxies_empty_env_var_ignored(self):
        with patch.dict(os.environ, {"BEACON_PROXIES": ""}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.proxies is None

    def test_proxies_empty_param_falls_back_to_env(self):
        with patch.dict(os.environ, {"BEACON_PROXIES": "http://env-proxy:9999"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                proxies="",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.proxies == {
            "http": "http://env-proxy:9999",
            "https": "http://env-proxy:9999",
        }

    def test_proxies_whitespace_param_falls_back_to_env(self):
        """Whitespace-only is indistinguishable from empty for a config-file
        emitter, so it should also fall through to the env var."""
        with patch.dict(os.environ, {"BEACON_PROXIES": "http://env-proxy:9999"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                proxies="   ",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.proxies == {
            "http": "http://env-proxy:9999",
            "https": "http://env-proxy:9999",
        }

    def test_proxies_invalid_json_env_var_raises(self):
        with patch.dict(os.environ, {"BEACON_PROXIES": "{not valid json"}):
            with pytest.raises(ConfigurationError, match="Invalid JSON"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    auto_instrument_opentelemetry=False,
                )

    def test_proxies_non_dict_json_raises(self):
        with patch.dict(os.environ, {"BEACON_PROXIES": "[1, 2, 3]"}):
            with pytest.raises(ConfigurationError, match="must be an object"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    auto_instrument_opentelemetry=False,
                )

    def test_proxies_unsupported_type_raises(self):
        with pytest.raises(ConfigurationError, match="proxies must be"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies=12345,
                auto_instrument_opentelemetry=False,
            )

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_session_has_proxies(self, mock_exporter_cls):
        client = BeaconClient(
            endpoint="https://api.test.com",
            proxies={"http": "http://p:8080", "https": "http://p:8080"},
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        mock_exporter_cls.assert_called_once()
        passed_session = mock_exporter_cls.call_args.kwargs["session"]
        assert passed_session is not None
        assert passed_session.proxies == {
            "http": "http://p:8080",
            "https": "http://p:8080",
        }

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_no_session_when_no_proxies_or_verify(self, mock_exporter_cls):
        """No custom session should be built when verify=True/path/cert and no proxies set."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        assert "session" not in mock_exporter_cls.call_args.kwargs

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_session_combines_proxies_and_verify_false(self, mock_exporter_cls):
        """verify=False + proxies share a single _BeaconSession that forces verify=False."""
        import requests

        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=False,
            proxies="http://p:8080",
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        passed_session = mock_exporter_cls.call_args.kwargs["session"]
        assert passed_session is not None
        assert passed_session.proxies == {
            "http": "http://p:8080",
            "https": "http://p:8080",
        }
        assert isinstance(passed_session, requests.Session)
        assert type(passed_session) is not requests.Session

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_session_forces_verify_false_on_request(self, mock_exporter_cls):
        """Regression: the OTLP exporter calls session.post(verify=...) explicitly, so the
        subclass override must use kwargs['verify'] = False, not setdefault, otherwise the
        exporter's default verify=True wins and SSL verification stays on."""
        from unittest.mock import MagicMock

        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=False,
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        passed_session = mock_exporter_cls.call_args.kwargs["session"]
        # Simulate the exporter's call: session.post(..., verify=True, ...).
        # Stub the parent class's request so we can inspect what was forwarded.
        with patch("requests.Session.request", return_value=MagicMock()) as parent:
            passed_session.request("POST", "http://example.invalid", verify=True)
        assert parent.call_args.kwargs["verify"] is False

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_extra_http_endpoint_uses_proxies(
        self, mock_otel, mock_http_exporter_cls, mock_add
    ):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4318",
        }):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies={"http": "http://p:8080", "https": "http://p:8080"},
            )
        mock_http_exporter_cls.assert_called_once()
        call_kwargs = mock_http_exporter_cls.call_args.kwargs
        assert "session" in call_kwargs
        assert call_kwargs["session"].proxies == {
            "http": "http://p:8080",
            "https": "http://p:8080",
        }

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_extra_grpc_endpoint_does_not_pass_session(
        self, mock_otel, mock_grpc_exporter_cls, mock_add
    ):
        """gRPC extra endpoints honor grpc_proxy/https_proxy env vars, not BEACON_PROXIES."""
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies="http://p:8080",
            )
        mock_grpc_exporter_cls.assert_called_once()
        assert "session" not in mock_grpc_exporter_cls.call_args.kwargs


class TestVerifyNormalization:
    """Test `_normalize_verify` directly — bool-token coercion, case-insensitivity, paths."""

    @pytest.mark.parametrize(
        "token",
        ["true", "TRUE", "True", "1", "yes", "YES", "on", "enable", "enabled"],
    )
    def test_truthy_tokens(self, token):
        with patch.dict(os.environ, {"BEACON_VERIFY": token}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.verify is True

    @pytest.mark.parametrize(
        "token",
        ["false", "FALSE", "False", "0", "no", "NO", "off", "disable", "disabled"],
    )
    def test_falsy_tokens(self, token):
        with patch.dict(os.environ, {"BEACON_VERIFY": token}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.verify is False

    @pytest.mark.parametrize("typo", ["treu", "fasle", "yeah", "nope"])
    def test_unrecognized_token_without_path_chars_raises(self, typo):
        """A bareword that isn't a known token and has no path separators is
        almost certainly a typo. Reject loudly so it doesn't get silently
        passed to `requests` as a CA-bundle path that fails at export time."""
        with pytest.raises(ConfigurationError, match="not a recognized boolean token"):
            BeaconClient(
                endpoint="https://api.test.com",
                verify=typo,
                auto_instrument_opentelemetry=False,
            )

    def test_whitespace_only_string_falls_back_to_default(self):
        client = BeaconClient(
            endpoint="https://api.test.com",
            verify="   ",
            auto_instrument_opentelemetry=False,
        )
        assert client.config.verify is True

    def test_empty_string_param_falls_back_to_env(self):
        with patch.dict(os.environ, {"BEACON_VERIFY": "false"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                verify="",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.verify is False

    def test_whitespace_param_falls_back_to_env(self):
        """Whitespace-only is treated as "not provided" so config emitters
        that default to "  " don't silently swallow the env fallback."""
        with patch.dict(os.environ, {"BEACON_VERIFY": "false"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                verify="   ",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.verify is False

    def test_unsupported_type_raises(self):
        with pytest.raises(ConfigurationError, match="verify must be"):
            BeaconClient(
                endpoint="https://api.test.com",
                verify=123,
                auto_instrument_opentelemetry=False,
            )


class TestCertificateConfig:
    """Test `cert` argument, CA-bundle `verify` paths, and matching env vars."""

    def test_cert_defaults_to_none(self):
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )
        assert client.config.cert is None

    def test_verify_defaults_to_true(self):
        client = BeaconClient(
            endpoint="https://api.test.com",
            auto_instrument_opentelemetry=False,
        )
        assert client.config.verify is True

    def test_verify_false_keeps_bool(self):
        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=False,
            auto_instrument_opentelemetry=False,
        )
        assert client.config.verify is False

    def test_verify_path_param(self, cert_files):
        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=cert_files["ca"],
            auto_instrument_opentelemetry=False,
        )
        assert client.config.verify == cert_files["ca"]

    def test_verify_env_var_bool_token(self):
        with patch.dict(os.environ, {"BEACON_VERIFY": "false"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.verify is False

    def test_verify_env_var_path(self, cert_files):
        with patch.dict(os.environ, {"BEACON_VERIFY": cert_files["ca"]}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.verify == cert_files["ca"]

    def test_verify_param_overrides_env_var(self, cert_files):
        with patch.dict(os.environ, {"BEACON_VERIFY": cert_files["env_ca"]}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                verify=cert_files["param_ca"],
                auto_instrument_opentelemetry=False,
            )
        assert client.config.verify == cert_files["param_ca"]

    def test_verify_missing_path_raises(self, tmp_path):
        """A typo'd CA-bundle path must fail loudly at config time. Otherwise
        the OTLP exporter would emit one warning before BatchSpanProcessor's
        deduplicated logging silently drops every subsequent export."""
        missing = str(tmp_path / "does-not-exist.pem")
        with pytest.raises(ConfigurationError, match="does not exist"):
            BeaconClient(
                endpoint="https://api.test.com",
                verify=missing,
                auto_instrument_opentelemetry=False,
            )

    def test_cert_string_param(self, cert_files):
        client = BeaconClient(
            endpoint="https://api.test.com",
            cert=cert_files["cert"],
            auto_instrument_opentelemetry=False,
        )
        assert client.config.cert == cert_files["cert"]

    def test_cert_tuple_param(self, cert_files):
        client = BeaconClient(
            endpoint="https://api.test.com",
            cert=(cert_files["crt"], cert_files["key"]),
            auto_instrument_opentelemetry=False,
        )
        assert client.config.cert == (cert_files["crt"], cert_files["key"])

    def test_cert_list_normalizes_to_tuple(self, cert_files):
        client = BeaconClient(
            endpoint="https://api.test.com",
            cert=[cert_files["crt"], cert_files["key"]],
            auto_instrument_opentelemetry=False,
        )
        assert client.config.cert == (cert_files["crt"], cert_files["key"])

    def test_cert_env_var_alone(self, cert_files):
        with patch.dict(os.environ, {"BEACON_CLIENT_CERT": cert_files["cert"]}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.cert == cert_files["cert"]

    def test_cert_env_vars_pair_to_tuple(self, cert_files):
        with patch.dict(os.environ, {
            "BEACON_CLIENT_CERT": cert_files["crt"],
            "BEACON_CLIENT_KEY": cert_files["key"],
        }):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.cert == (cert_files["crt"], cert_files["key"])

    def test_cert_key_env_var_alone_raises(self, cert_files):
        """BEACON_CLIENT_KEY without BEACON_CLIENT_CERT is a misconfig — surface it."""
        with patch.dict(os.environ, {"BEACON_CLIENT_KEY": cert_files["key"]}):
            with pytest.raises(ConfigurationError, match="BEACON_CLIENT_KEY"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    auto_instrument_opentelemetry=False,
                )

    def test_cert_param_overrides_env_var(self, cert_files):
        with patch.dict(os.environ, {"BEACON_CLIENT_CERT": cert_files["env_cert"]}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                cert=cert_files["param_cert"],
                auto_instrument_opentelemetry=False,
            )
        assert client.config.cert == cert_files["param_cert"]

    @pytest.mark.parametrize(
        "bad_cert",
        [
            ("only-one-element",),
            ("a", "b", "c"),
            ("a", 123),
            ("", "key"),
            42,
        ],
    )
    def test_cert_invalid_shape_raises(self, bad_cert):
        with pytest.raises(ConfigurationError, match="cert must be"):
            BeaconClient(
                endpoint="https://api.test.com",
                cert=bad_cert,
                auto_instrument_opentelemetry=False,
            )

    def test_cert_missing_path_string_raises(self, tmp_path):
        missing = str(tmp_path / "missing-client.pem")
        with pytest.raises(ConfigurationError, match="cert file does not exist"):
            BeaconClient(
                endpoint="https://api.test.com",
                cert=missing,
                auto_instrument_opentelemetry=False,
            )

    def test_cert_missing_path_in_tuple_raises(self, tmp_path, cert_files):
        missing_key = str(tmp_path / "missing.key")
        with pytest.raises(ConfigurationError, match="cert key file does not exist"):
            BeaconClient(
                endpoint="https://api.test.com",
                cert=(cert_files["crt"], missing_key),
                auto_instrument_opentelemetry=False,
            )

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_passes_ca_bundle_path_directly(self, mock_exporter_cls, cert_files):
        """CA-bundle path goes through the exporter's certificate_file kwarg.

        The exporter calls session.post(..., verify=self._certificate_file) explicitly,
        and requests.merge_setting lets that explicit kwarg win over session.verify.
        Routing through certificate_file is what actually takes effect.

        A custom session is still built so trust_env=False blocks a stray
        REQUESTS_CA_BUNDLE from shadowing the explicit path.
        """
        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=cert_files["ca"],
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        call_kwargs = mock_exporter_cls.call_args.kwargs
        assert call_kwargs["certificate_file"] == cert_files["ca"]
        assert call_kwargs["session"].trust_env is False

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_passes_client_cert_string_directly(self, mock_exporter_cls, cert_files):
        client = BeaconClient(
            endpoint="https://api.test.com",
            cert=cert_files["cert"],
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        call_kwargs = mock_exporter_cls.call_args.kwargs
        assert call_kwargs["client_certificate_file"] == cert_files["cert"]
        assert "client_key_file" not in call_kwargs
        assert "session" not in call_kwargs

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_passes_client_cert_tuple_directly(self, mock_exporter_cls, cert_files):
        client = BeaconClient(
            endpoint="https://api.test.com",
            cert=(cert_files["crt"], cert_files["key"]),
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        call_kwargs = mock_exporter_cls.call_args.kwargs
        assert call_kwargs["client_certificate_file"] == cert_files["crt"]
        assert call_kwargs["client_key_file"] == cert_files["key"]
        assert "session" not in call_kwargs

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_combines_verify_path_cert_and_proxies(self, mock_exporter_cls, cert_files):
        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=cert_files["ca"],
            cert=(cert_files["crt"], cert_files["key"]),
            proxies="http://p:8080",
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        call_kwargs = mock_exporter_cls.call_args.kwargs
        assert call_kwargs["certificate_file"] == cert_files["ca"]
        assert call_kwargs["client_certificate_file"] == cert_files["crt"]
        assert call_kwargs["client_key_file"] == cert_files["key"]
        # Proxies still go through a session (no native exporter kwarg for them).
        assert call_kwargs["session"].proxies == {
            "http": "http://p:8080",
            "https": "http://p:8080",
        }

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_verify_path_via_env_var_takes_effect(self, mock_exporter_cls, cert_files):
        """BEACON_VERIFY=/path should reach the exporter's certificate_file kwarg
        through the same plumbing as the constructor param."""
        with patch.dict(os.environ, {"BEACON_VERIFY": cert_files["ca"]}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                auto_instrument_opentelemetry=False,
            )
            client._create_otlp_exporter()
        assert mock_exporter_cls.call_args.kwargs["certificate_file"] == cert_files["ca"]

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_requests_ca_bundle_env_does_not_shadow_explicit_verify_path(
        self, mock_exporter_cls, cert_files
    ):
        """A stray REQUESTS_CA_BUNDLE in the env must not override the explicit
        CA-bundle path. trust_env=False on the session blocks env merging."""
        with patch.dict(os.environ, {"REQUESTS_CA_BUNDLE": "/etc/wrong-ca.pem"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                verify=cert_files["ca"],
                auto_instrument_opentelemetry=False,
            )
            client._create_otlp_exporter()
        call_kwargs = mock_exporter_cls.call_args.kwargs
        assert call_kwargs["certificate_file"] == cert_files["ca"]
        assert call_kwargs["session"].trust_env is False

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_verify_false_with_cert(self, mock_exporter_cls, cert_files):
        """verify=False + cert: session subclass plus exporter-level client cert kwargs."""
        import requests

        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=False,
            cert=cert_files["cert"],
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        call_kwargs = mock_exporter_cls.call_args.kwargs
        assert call_kwargs["client_certificate_file"] == cert_files["cert"]
        session = call_kwargs["session"]
        assert isinstance(session, requests.Session)
        assert type(session) is not requests.Session  # subclass forcing verify=False

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_otlp_exporter_omits_certificate_file_when_verify_is_false(
        self, mock_exporter_cls
    ):
        """Regression: the OTLP HTTP exporter coerces `certificate_file=False` to
        True, so we must never pass that kwarg when verify=False. Belt-and-braces
        against a future refactor that wires `certificate_file=self.config.verify`
        directly and silently re-enables TLS verification."""
        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=False,
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        call_kwargs = mock_exporter_cls.call_args.kwargs
        assert "certificate_file" not in call_kwargs

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_extra_http_endpoint_uses_cert(
        self, mock_otel, mock_http_exporter_cls, mock_add, cert_files
    ):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4318",
        }):
            BeaconClient(
                endpoint="https://api.test.com",
                cert=(cert_files["crt"], cert_files["key"]),
            )
        mock_http_exporter_cls.assert_called_once()
        call_kwargs = mock_http_exporter_cls.call_args.kwargs
        assert call_kwargs["client_certificate_file"] == cert_files["crt"]
        assert call_kwargs["client_key_file"] == cert_files["key"]

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_extra_grpc_endpoint_does_not_pass_cert_session(
        self, mock_otel, mock_grpc_exporter_cls, mock_add, cert_files
    ):
        """gRPC extra endpoints honor OTEL_EXPORTER_OTLP_CLIENT_* env vars, not BEACON_CLIENT_*."""
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            BeaconClient(
                endpoint="https://api.test.com",
                cert=cert_files["cert"],
            )
        mock_grpc_exporter_cls.assert_called_once()
        call_kwargs = mock_grpc_exporter_cls.call_args.kwargs
        assert "session" not in call_kwargs
        assert "client_certificate_file" not in call_kwargs
        assert "client_key_file" not in call_kwargs


class TestCertEmptyStringFallback:
    """`cert=""` (config-file emitters that render unset values as "") must
    fall back to BEACON_CLIENT_CERT/_KEY, the same way verify and proxies do.
    Otherwise mTLS gets silently disabled by an empty Helm/YAML template."""

    def test_empty_cert_param_falls_back_to_env(self, cert_files):
        with patch.dict(os.environ, {"BEACON_CLIENT_CERT": cert_files["env_cert"]}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                cert="",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.cert == cert_files["env_cert"]

    def test_empty_cert_param_falls_back_to_env_pair(self, cert_files):
        with patch.dict(os.environ, {
            "BEACON_CLIENT_CERT": cert_files["env_crt"],
            "BEACON_CLIENT_KEY": cert_files["env_key"],
        }):
            client = BeaconClient(
                endpoint="https://api.test.com",
                cert="",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.cert == (cert_files["env_crt"], cert_files["env_key"])

    def test_whitespace_cert_param_falls_back_to_env(self, cert_files):
        """Whitespace-only is indistinguishable from empty for a config emitter."""
        with patch.dict(os.environ, {"BEACON_CLIENT_CERT": cert_files["env_cert"]}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                cert="   ",
                auto_instrument_opentelemetry=False,
            )
        assert client.config.cert == cert_files["env_cert"]


class TestProxiesEnvOverrideResistance:
    """The OTLP HTTP exporter calls session.post() without a per-request
    proxies kwarg, so HTTPS_PROXY/HTTP_PROXY env vars would normally override
    session.proxies via requests.merge_environment_settings. The session must
    set trust_env=False and inject proxies at request time to keep the
    explicit kwarg authoritative."""

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_session_has_trust_env_disabled_when_proxies_set(self, mock_exporter_cls):
        client = BeaconClient(
            endpoint="https://api.test.com",
            proxies="http://p:8080",
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        session = mock_exporter_cls.call_args.kwargs["session"]
        assert session.trust_env is False

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_session_forces_proxies_on_request(self, mock_exporter_cls):
        """Regression: requests merges per-request proxies over session.proxies,
        but env-derived proxies merged in by merge_environment_settings would
        still win over session.proxies even with trust_env=False if they were
        present elsewhere. The override pushes the explicit proxies into the
        per-request kwargs so merge_setting locks them in."""
        from unittest.mock import MagicMock

        client = BeaconClient(
            endpoint="https://api.test.com",
            proxies={"http": "http://p:8080", "https": "http://p:8080"},
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        session = mock_exporter_cls.call_args.kwargs["session"]
        with patch("requests.Session.request", return_value=MagicMock()) as parent:
            session.request("POST", "http://example.invalid")
        assert parent.call_args.kwargs["proxies"] == {
            "http": "http://p:8080",
            "https": "http://p:8080",
        }

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_https_proxy_env_does_not_leak_through(self, mock_exporter_cls):
        """End-to-end: with HTTPS_PROXY set in the environment AND an explicit
        proxies kwarg, the session must still send to the explicit proxy."""
        from unittest.mock import MagicMock

        with patch.dict(os.environ, {"HTTPS_PROXY": "http://env-proxy:9999"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                proxies={"https": "http://explicit:8080"},
                auto_instrument_opentelemetry=False,
            )
            client._create_otlp_exporter()
            session = mock_exporter_cls.call_args.kwargs["session"]
            with patch("requests.Session.request", return_value=MagicMock()) as parent:
                session.request("POST", "https://example.invalid")
        assert parent.call_args.kwargs["proxies"] == {"https": "http://explicit:8080"}


class TestProxiesErrorMessageDoesNotLeakCredentials:
    """Malformed BEACON_PROXIES JSON must not echo the raw value into the
    exception message — proxy URLs commonly contain user:password credentials
    that would otherwise be captured by structured loggers / Sentry verbatim."""

    def test_invalid_json_error_omits_raw_text(self):
        # JSON-looking input with embedded credentials and a missing brace.
        bad = '{"https": "http://user:secret-pw@proxy:8080"'
        with patch.dict(os.environ, {"BEACON_PROXIES": bad}):
            with pytest.raises(ConfigurationError) as excinfo:
                BeaconClient(
                    endpoint="https://api.test.com",
                    auto_instrument_opentelemetry=False,
                )
        assert "secret-pw" not in str(excinfo.value)
        assert "user:secret-pw" not in str(excinfo.value)
        assert "proxy:8080" not in str(excinfo.value)


class TestGrpcExtrasSilentDropWarning:
    """When an extra OTLP endpoint resolves to gRPC, the client's proxies /
    cert / verify-path settings are not propagated (those need OTel + grpc env
    vars). Emit a startup warning so users don't think their explicit
    kwargs apply to that endpoint. `verify=False` is the exception: see
    ``TestGrpcExtrasVerifyFalseRejected`` — it is rejected with a
    ``ConfigurationError`` rather than warned, because silently keeping TLS
    verification on contradicts an explicit "off" intent."""

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_warns_when_proxies_set_and_grpc_extra_present(
        self, mock_otel, mock_grpc_cls, mock_add, caplog
    ):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    proxies="http://p:8080",
                )
        assert any(
            "is gRPC" in r.message and "proxies/cert/verify" in r.message
            for r in caplog.records
        )

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_warns_when_cert_set_and_grpc_extra_present(
        self, mock_otel, mock_grpc_cls, mock_add, caplog, cert_files
    ):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    cert=cert_files["cert"],
                )
        assert any(
            "is gRPC" in r.message and "proxies/cert/verify" in r.message
            for r in caplog.records
        )

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_warns_when_verify_path_set_and_grpc_extra_present(
        self, mock_otel, mock_grpc_cls, mock_add, caplog, cert_files
    ):
        """A custom CA-bundle path also needs OTEL_EXPORTER_OTLP_CERTIFICATE on
        gRPC; assert the warning fires (not just for verify=False)."""
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    verify=cert_files["ca"],
                )
        assert any(
            "is gRPC" in r.message and "proxies/cert/verify" in r.message
            for r in caplog.records
        )

    @patch("lumenova_beacon.core.client.BeaconClient.add_span_exporter")
    @patch("opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter")
    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_no_warning_when_no_sensitive_settings(
        self, mock_otel, mock_grpc_cls, mock_add, caplog
    ):
        """A bare gRPC extra with default verify/no cert/no proxies should not warn."""
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
                BeaconClient(endpoint="https://api.test.com")
        assert not any("is gRPC" in r.message for r in caplog.records)


class TestGrpcExtrasVerifyFalseRejected:
    """``verify=False`` plus a gRPC extra endpoint is rejected with
    ConfigurationError. The gRPC exporter ignores the SDK verify setting and
    would keep TLS verification on, contradicting the user's explicit "off"
    intent — exactly the kind of silent security downgrade config-time
    validation exists to prevent."""

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_grpc_extra_with_verify_false_raises(self, mock_otel):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4317",
        }):
            with pytest.raises(ConfigurationError, match="verify=False"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    verify=False,
                )

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_http_extra_with_verify_false_accepted(self, mock_otel):
        """An HTTP extra (port 4318) honors verify=False through the HTTP
        exporter, so it must NOT raise."""
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": "http://collector:4318",
        }):
            BeaconClient(
                endpoint="https://api.test.com",
                verify=False,
            )

    @patch("lumenova_beacon.core.client.BeaconClient._setup_opentelemetry")
    def test_mixed_endpoints_raise_if_any_is_grpc(self, mock_otel):
        with patch.dict(os.environ, {
            "BEACON_EXTRA_OTLP_ENDPOINTS": (
                "http://http-collector:4318,http://grpc-collector:4317"
            ),
        }):
            with pytest.raises(ConfigurationError, match="verify=False"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    verify=False,
                )


class TestProxiesDictValidation:
    """A dict that parses but contains typo'd keys (e.g. `htps` for `https`) or
    empty values would otherwise pass through to `requests` and silently call
    out unproxied. Reject loudly at config time."""

    def test_unknown_dict_key_raises(self):
        with pytest.raises(ConfigurationError, match="unrecognized key"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies={"htps": "http://corp:8080"},
                auto_instrument_opentelemetry=False,
            )

    def test_unknown_json_dict_key_raises(self):
        with patch.dict(os.environ, {"BEACON_PROXIES": '{"htps": "http://corp:8080"}'}):
            with pytest.raises(ConfigurationError, match="unrecognized key"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    auto_instrument_opentelemetry=False,
                )

    def test_empty_string_value_raises(self):
        with pytest.raises(ConfigurationError, match="non-empty string"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies={"https": ""},
                auto_instrument_opentelemetry=False,
            )

    def test_non_string_value_raises(self):
        with pytest.raises(ConfigurationError, match="non-empty string"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies={"https": 8080},
                auto_instrument_opentelemetry=False,
            )

    def test_no_proxy_dict_key_rejected(self):
        """The `no` key cannot be plumbed through both transports cleanly
        (httpx has no first-class equivalent; the OTLP session disables env
        merging). Accepting it would silently violate user intent — reject it
        and point users at the NO_PROXY env var."""
        with pytest.raises(ConfigurationError, match="NO_PROXY"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies={"https": "http://p:8080", "no": "localhost"},
                auto_instrument_opentelemetry=False,
            )

    def test_no_proxy_long_form_dict_key_rejected(self):
        with pytest.raises(ConfigurationError, match="NO_PROXY"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies={"https": "http://p:8080", "no_proxy": "localhost"},
                auto_instrument_opentelemetry=False,
            )

    def test_no_proxy_json_env_rejected(self):
        with patch.dict(
            os.environ,
            {"BEACON_PROXIES": '{"https": "http://p:8080", "no": "localhost"}'},
        ):
            with pytest.raises(ConfigurationError, match="NO_PROXY"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    auto_instrument_opentelemetry=False,
                )


class TestProxiesUrlSchemeValidation:
    """A proxy URL with an unsupported scheme (or no scheme at all) would
    otherwise pass config and only surface as a per-request transport error,
    where BatchSpanProcessor's deduplicated logging hides span loss. Reject at
    config time."""

    def test_string_form_missing_scheme_raises(self):
        with pytest.raises(ConfigurationError, match="unsupported scheme"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies="corp-proxy:8080",
                auto_instrument_opentelemetry=False,
            )

    def test_string_form_typo_scheme_raises(self):
        with pytest.raises(ConfigurationError, match="unsupported scheme"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies="htp://corp-proxy:8080",
                auto_instrument_opentelemetry=False,
            )

    def test_string_form_unsupported_scheme_raises(self):
        with pytest.raises(ConfigurationError, match="unsupported scheme"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies="ftp://corp-proxy:8080",
                auto_instrument_opentelemetry=False,
            )

    def test_string_form_missing_host_raises(self):
        with pytest.raises(ConfigurationError, match="missing the host"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies="http://",
                auto_instrument_opentelemetry=False,
            )

    def test_dict_value_unsupported_scheme_raises(self):
        with pytest.raises(ConfigurationError, match="unsupported scheme"):
            BeaconClient(
                endpoint="https://api.test.com",
                proxies={"https": "ftp://corp:8080"},
                auto_instrument_opentelemetry=False,
            )

    def test_env_json_dict_value_unsupported_scheme_raises(self):
        with patch.dict(
            os.environ, {"BEACON_PROXIES": '{"https": "ftp://corp:8080"}'}
        ):
            with pytest.raises(ConfigurationError, match="unsupported scheme"):
                BeaconClient(
                    endpoint="https://api.test.com",
                    auto_instrument_opentelemetry=False,
                )

    def test_socks5_scheme_accepted(self):
        client = BeaconClient(
            endpoint="https://api.test.com",
            proxies="socks5://corp:1080",
            auto_instrument_opentelemetry=False,
        )
        assert client.transport.proxies == {
            "http": "socks5://corp:1080",
            "https": "socks5://corp:1080",
        }

    def test_error_does_not_echo_proxy_url_for_dict_value(self):
        """Error messages must not echo the URL — proxies commonly embed
        ``user:password@host`` credentials."""
        with pytest.raises(ConfigurationError) as excinfo:
            BeaconClient(
                endpoint="https://api.test.com",
                proxies={"https": "ftp://user:secret-pw@corp:8080"},
                auto_instrument_opentelemetry=False,
            )
        assert "secret-pw" not in str(excinfo.value)
        assert "user:" not in str(excinfo.value)


class TestSessionTrustEnvAndWarnings:
    """The custom session must disable env-based merging unconditionally (not
    just when explicit proxies are set), and the warning telling the operator
    that env proxy vars are being ignored must fire whenever the session is
    built — otherwise verify=False alone would still let HTTPS_PROXY silently
    redirect plaintext-disabled traffic."""

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_trust_env_disabled_when_only_verify_false(self, mock_exporter_cls):
        client = BeaconClient(
            endpoint="https://api.test.com",
            verify=False,
            auto_instrument_opentelemetry=False,
        )
        client._create_otlp_exporter()
        session = mock_exporter_cls.call_args.kwargs["session"]
        assert session.trust_env is False

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_https_proxy_env_does_not_leak_when_only_verify_false(self, mock_exporter_cls):
        """End-to-end: verify=False with HTTPS_PROXY in env must NOT route
        through the env proxy (trust_env=False blocks merge_environment_settings)."""
        from unittest.mock import MagicMock

        with patch.dict(os.environ, {"HTTPS_PROXY": "http://env-proxy:9999"}):
            client = BeaconClient(
                endpoint="https://api.test.com",
                verify=False,
                auto_instrument_opentelemetry=False,
            )
            client._create_otlp_exporter()
            session = mock_exporter_cls.call_args.kwargs["session"]
            with patch("requests.Session.request", return_value=MagicMock()) as parent:
                session.request("POST", "https://example.invalid")
        # No proxies kwarg injected (no explicit proxies configured) — and
        # trust_env=False prevents the parent from picking up HTTPS_PROXY.
        assert "proxies" not in parent.call_args.kwargs or not parent.call_args.kwargs["proxies"]

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_env_proxy_warning_fires_with_verify_false_alone(
        self, mock_exporter_cls, caplog
    ):
        with patch.dict(os.environ, {"HTTPS_PROXY": "http://env-proxy:9999"}):
            with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
                client = BeaconClient(
                    endpoint="https://api.test.com",
                    verify=False,
                    auto_instrument_opentelemetry=False,
                )
                client._create_otlp_exporter()
        assert any(
            "ignoring HTTPS_PROXY" in r.message
            for r in caplog.records
        )

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_env_ca_bundle_warning_fires_with_explicit_verify_path(
        self, mock_exporter_cls, caplog, cert_files
    ):
        """trust_env=False blocks REQUESTS_CA_BUNDLE/CURL_CA_BUNDLE/SSL_CERT_FILE
        when the user has set an explicit verify path. The warning must name
        which env vars are being ignored."""
        env = {
            "REQUESTS_CA_BUNDLE": "/etc/wrong-ca.pem",
            "CURL_CA_BUNDLE": "/etc/other-ca.pem",
            "SSL_CERT_FILE": "/etc/yet-another-ca.pem",
        }
        with patch.dict(os.environ, env):
            with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
                client = BeaconClient(
                    endpoint="https://api.test.com",
                    verify=cert_files["ca"],
                    auto_instrument_opentelemetry=False,
                )
                client._create_otlp_exporter()
        message = next(
            r.message for r in caplog.records if "ignoring" in r.message
        )
        assert "REQUESTS_CA_BUNDLE" in message
        assert "CURL_CA_BUNDLE" in message
        assert "SSL_CERT_FILE" in message

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_env_ca_bundle_warning_fires_with_verify_false(
        self, mock_exporter_cls, caplog
    ):
        with patch.dict(os.environ, {"REQUESTS_CA_BUNDLE": "/etc/wrong-ca.pem"}):
            with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
                client = BeaconClient(
                    endpoint="https://api.test.com",
                    verify=False,
                    auto_instrument_opentelemetry=False,
                )
                client._create_otlp_exporter()
        assert any(
            "REQUESTS_CA_BUNDLE" in r.message
            for r in caplog.records
        )

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_env_ca_bundle_warning_silent_when_only_proxies_configured(
        self, mock_exporter_cls, caplog
    ):
        """A stray REQUESTS_CA_BUNDLE alongside proxy config is NOT ignored
        (plain proxies leave verify behavior at the default), so no warning."""
        env = {
            "REQUESTS_CA_BUNDLE": "/etc/some-ca.pem",
            "HTTPS_PROXY": "http://env-proxy:9999",
        }
        with patch.dict(os.environ, env):
            with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
                client = BeaconClient(
                    endpoint="https://api.test.com",
                    proxies="http://explicit-proxy:8080",
                    auto_instrument_opentelemetry=False,
                )
                client._create_otlp_exporter()
        warning = next(
            (r.message for r in caplog.records if "ignoring" in r.message),
            "",
        )
        # HTTPS_PROXY is shadowed (and warned); REQUESTS_CA_BUNDLE is not.
        assert "HTTPS_PROXY" in warning
        assert "REQUESTS_CA_BUNDLE" not in warning

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_urllib3_disable_warnings_is_logged(self, mock_exporter_cls, caplog):
        """Warning suppression is now scoped to Beacon's session (not
        process-wide), but the operator should still see one log line."""
        with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
            client = BeaconClient(
                endpoint="https://api.test.com",
                verify=False,
                auto_instrument_opentelemetry=False,
            )
            client._create_otlp_exporter()
        assert any(
            "InsecureRequestWarning suppressed" in r.message
            for r in caplog.records
        )

    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_urllib3_disable_warnings_log_emitted_once(self, mock_exporter_cls, caplog):
        """Repeated exporter builds (primary + extra HTTP endpoints) must not
        re-emit the same suppression notice."""
        with caplog.at_level(logging.WARNING, logger="lumenova_beacon.core.client"):
            client = BeaconClient(
                endpoint="https://api.test.com",
                verify=False,
                auto_instrument_opentelemetry=False,
            )
            client._create_otlp_exporter()
            client._create_otlp_exporter()
            client._create_otlp_exporter()
        matches = [
            r for r in caplog.records
            if "InsecureRequestWarning suppressed" in r.message
        ]
        assert len(matches) == 1

    def test_urllib3_warning_suppressed_only_within_session(self):
        """The suppression must NOT leak to non-Beacon urllib3 usage. After
        constructing the client, an unrelated InsecureRequestWarning should
        still be observable by a normal warnings.catch_warnings() block."""
        import warnings as _warnings

        import urllib3

        BeaconClient(
            endpoint="https://api.test.com",
            verify=False,
            auto_instrument_opentelemetry=False,
        )

        # Outside any Beacon session.request() call, the filter should still
        # let InsecureRequestWarning through.
        with _warnings.catch_warnings(record=True) as recorded:
            _warnings.simplefilter("always")
            _warnings.warn(
                "test", category=urllib3.exceptions.InsecureRequestWarning
            )
        assert any(
            issubclass(r.category, urllib3.exceptions.InsecureRequestWarning)
            for r in recorded
        )


class TestOTLPExporterKwargContract:
    """Every other OTLP test patches the exporter class with a MagicMock, so a
    silent kwarg rename in the OTel SDK (e.g. ``certificate_file`` →
    ``ca_certificate_file``) would pass mocked tests but explode in production.

    Pin the contract: the names we pass must exist as parameters of the real
    exporter signature."""

    def test_http_exporter_accepts_kwargs_we_pass(self):
        import inspect

        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter,
        )

        params = inspect.signature(OTLPSpanExporter).parameters
        # Names that ``_build_http_exporter_kwargs`` and ``_create_otlp_exporter``
        # emit. If any of these vanishes from the upstream signature, fail
        # loudly here rather than at first export.
        required = {
            "endpoint",
            "headers",
            "timeout",
            "certificate_file",
            "client_certificate_file",
            "client_key_file",
            "session",
        }
        missing = required - set(params)
        assert not missing, (
            f"OTLPSpanExporter (HTTP) signature is missing expected kwargs: "
            f"{sorted(missing)}. The SDK passes these in "
            f"_build_http_exporter_kwargs / _create_otlp_exporter — silent "
            f"rename in upstream OTel would drop them. Update the SDK to use "
            f"the new names."
        )
