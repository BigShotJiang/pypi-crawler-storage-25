"""Probe-test shared fixtures."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture(autouse=True)
def _stub_beacon_transport():
    """Auto-mock ``get_transport`` so ``shared_beacon_client`` can construct
    a real httpx.AsyncClient without needing real Beacon credentials.

    Unit tests short-circuit higher up by patching individual
    ``_beacon_client`` functions, so the real httpx client built here is
    never exercised. Integration tests override this fixture's ``patch``
    by re-patching the same target inside their own ``beacon_env`` context
    — ``unittest.mock.patch`` stacks naturally, with the inner patch
    taking precedence.
    """
    transport = MagicMock()
    transport.headers = {}
    transport.timeout = 30
    transport.verify = True
    with (
        patch(
            "lumenova_beacon.probes._beacon_client.get_transport",
            return_value=transport,
        ),
        patch(
            "lumenova_beacon.probes._beacon_client.get_base_url",
            return_value="https://beacon.test",
        ),
    ):
        yield
