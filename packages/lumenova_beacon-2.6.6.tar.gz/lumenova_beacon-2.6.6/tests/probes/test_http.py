"""Unit tests for the built-in HTTP dispatcher (path A)."""

from __future__ import annotations

import httpx
import pytest
import pytest_asyncio
import respx

from lumenova_beacon.exceptions import ProbeError, ProbeValidationError
from lumenova_beacon.probes._http import (
    MAX_BODY_BYTES,
    BuiltInAuth,
    _build_headers,
    _decode_capped,
    _redact_headers,
    rewrite_url,
    dispatch_builtin,
)
from lumenova_beacon.probes.types import (
    AuthSchemeHint,
    ProbeHttpErrorResponse,
    ProbeHttpRequest,
    ProbeHttpSuccessResponse,
    TargetSystemRef,
)


@pytest_asyncio.fixture
async def http_client():
    """Real httpx.AsyncClient — respx intercepts at the transport layer."""
    async with httpx.AsyncClient() as client:
        yield client


def _request(
    *,
    method: str = "GET",
    url: str = "https://target.example/orders",
    headers: dict[str, str] | None = None,
    body: str | None = None,
) -> ProbeHttpRequest:
    return ProbeHttpRequest(
        id="evt-1",
        evaluation_run_id="run-1",
        seq=1,
        method=method,
        url=url,
        request_headers=headers or {},
        request_body=body,
    )


def _target(
    scheme: AuthSchemeHint = AuthSchemeHint.NONE,
    *,
    auth_metadata: dict | None = None,
    name: str = "orders-api",
) -> TargetSystemRef:
    return TargetSystemRef(
        id="t1",
        name=name,
        base_url=None,
        auth_scheme_hint=scheme,
        auth_metadata=auth_metadata or {},
    )


class TestBuildHeaders:
    def test_none_scheme_does_not_inject(self):
        headers = _build_headers(
            {"X-Trace": "abc"},
            _target(AuthSchemeHint.NONE),
            BuiltInAuth(),
        )
        assert headers == {"X-Trace": "abc"}

    def test_custom_headers_single_pair_injected(self):
        headers = _build_headers(
            {},
            _target(AuthSchemeHint.CUSTOM_HEADERS),
            BuiltInAuth(headers={"X-API-Key": "k1"}),
        )
        assert headers == {"X-API-Key": "k1"}

    def test_custom_headers_multiple_pairs_all_injected(self):
        headers = _build_headers(
            {},
            _target(AuthSchemeHint.CUSTOM_HEADERS),
            BuiltInAuth(
                headers={"X-API-Key": "k1", "X-Tenant-Id": "tenant-1"},
            ),
        )
        assert headers == {"X-API-Key": "k1", "X-Tenant-Id": "tenant-1"}

    def test_bearer_injects_authorization(self):
        headers = _build_headers(
            {},
            _target(AuthSchemeHint.BEARER),
            BuiltInAuth(bearer_token="t1"),
        )
        assert headers == {"Authorization": "Bearer t1"}

    def test_sdk_auth_overrides_agent_collision_case_insensitive(self):
        # Agent supplied a lowercase variant — SDK still wins.
        headers = _build_headers(
            {"x-api-key": "agent-supplied"},
            _target(AuthSchemeHint.CUSTOM_HEADERS),
            BuiltInAuth(headers={"X-API-Key": "user-key"}),
        )
        # The SDK's casing is used, the agent's variant is dropped.
        assert "X-API-Key" in headers
        assert headers["X-API-Key"] == "user-key"
        assert "x-api-key" not in headers

    def test_empty_headers_for_scheme_skips_injection(self):
        # Defensive: the validator should reject this case before we get
        # here, but if it does, we shouldn't crash.
        headers = _build_headers(
            {"X-Trace": "abc"},
            _target(AuthSchemeHint.CUSTOM_HEADERS),
            BuiltInAuth(headers={}),
        )
        assert headers == {"X-Trace": "abc"}


class TestRedactHeaders:
    def test_default_sensitive_headers_redacted_case_insensitive(self):
        headers = _redact_headers(
            {
                "Authorization": "Bearer secret",
                "X-Api-Key": "secret",
                "Content-Type": "application/json",
                "Cookie": "session=abc",
            }
        )
        assert headers["Authorization"] == "[REDACTED]"
        assert headers["X-Api-Key"] == "[REDACTED]"
        assert headers["Cookie"] == "[REDACTED]"
        # Non-sensitive headers pass through unchanged.
        assert headers["Content-Type"] == "application/json"


class TestDecodeCapped:
    def test_short_body_passes_through(self):
        assert _decode_capped(b"hello") == "hello"

    def test_oversized_body_truncated_with_marker(self):
        buf = b"x" * (MAX_BODY_BYTES + 1024)
        out = _decode_capped(buf)
        assert out.endswith("... [truncated]")
        assert len(out.encode("utf-8")) <= MAX_BODY_BYTES

    def test_binary_body_replaced_with_placeholder(self):
        # Invalid UTF-8 sequence (lone continuation byte).
        buf = b"\x80\x81\x82\x83"
        out = _decode_capped(buf)
        assert "binary body" in out
        assert "4 bytes" in out


class TestDispatchBuiltinSuccess:
    @respx.mock
    async def test_get_with_custom_headers_injection(self, http_client):
        route = respx.get("https://target.example/orders").respond(
            200,
            json={"orders": []},
        )

        result = await dispatch_builtin(
            _request(),
            target=_target(AuthSchemeHint.CUSTOM_HEADERS),
            auth=BuiltInAuth(
                headers={"X-API-Key": "user-key", "X-Tenant-Id": "tenant-1"},
            ),
            client=http_client,
        )

        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 200
        assert route.called
        assert route.calls.last.request.headers["X-API-Key"] == "user-key"
        assert route.calls.last.request.headers["X-Tenant-Id"] == "tenant-1"

    @respx.mock
    async def test_post_body_passes_through(self, http_client):
        route = respx.post("https://target.example/orders").respond(
            201,
            json={"id": "o1"},
        )

        result = await dispatch_builtin(
            _request(method="POST", body='{"customer":"alice"}'),
            target=_target(AuthSchemeHint.NONE),
            auth=BuiltInAuth(),
            client=http_client,
        )

        assert result.status_code == 201
        assert route.calls.last.request.content == b'{"customer":"alice"}'

    @respx.mock
    async def test_4xx_is_a_success_response(self, http_client):
        respx.get("https://target.example/orders").respond(403)

        result = await dispatch_builtin(
            _request(),
            target=_target(AuthSchemeHint.NONE),
            auth=BuiltInAuth(),
            client=http_client,
        )

        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 403

    @respx.mock
    async def test_5xx_is_a_success_response(self, http_client):
        respx.get("https://target.example/orders").respond(500)

        result = await dispatch_builtin(
            _request(),
            target=_target(AuthSchemeHint.NONE),
            auth=BuiltInAuth(),
            client=http_client,
        )

        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 500

    @respx.mock
    async def test_response_headers_redacted(self, http_client):
        respx.get("https://target.example/orders").respond(
            200,
            headers={
                "Set-Cookie": "session=secret",
                "Content-Type": "application/json",
            },
            json={},
        )

        result = await dispatch_builtin(
            _request(),
            target=_target(AuthSchemeHint.NONE),
            auth=BuiltInAuth(),
            client=http_client,
        )

        assert result.response_headers["set-cookie"] == "[REDACTED]"
        assert result.response_headers["content-type"] == "application/json"


class TestDispatchBuiltinErrors:
    @respx.mock
    async def test_connect_error_becomes_error_response(self, http_client, caplog):
        import logging

        caplog.set_level(logging.WARNING, logger="lumenova_beacon.probes._http")
        respx.get("https://target.example/orders").mock(
            side_effect=httpx.ConnectError("connect refused"),
        )

        result = await dispatch_builtin(
            _request(),
            target=_target(AuthSchemeHint.NONE),
            auth=BuiltInAuth(),
            client=http_client,
        )

        assert isinstance(result, ProbeHttpErrorResponse)
        assert "ConnectError" in result.error
        assert "connect refused" in result.error
        # Local visibility — not just silent PATCH-back to Beacon.
        assert any("Probe dispatch failed" in r.message for r in caplog.records)

    @respx.mock
    async def test_timeout_becomes_error_response(self, http_client):
        respx.get("https://target.example/orders").mock(
            side_effect=httpx.ReadTimeout("timed out"),
        )

        result = await dispatch_builtin(
            _request(),
            target=_target(AuthSchemeHint.NONE),
            auth=BuiltInAuth(),
            client=http_client,
        )

        assert isinstance(result, ProbeHttpErrorResponse)
        assert "ReadTimeout" in result.error

    @respx.mock
    async def test_invalid_url_raises_probe_error(self, http_client):
        # Programmer error (bad URL config) must surface as ProbeError so
        # the user fixes the setup, not silently report as "target
        # unreachable".
        respx.get("https://target.example/orders").mock(
            side_effect=httpx.InvalidURL("malformed"),
        )

        with pytest.raises(ProbeError) as exc:
            await dispatch_builtin(
                _request(),
                target=_target(AuthSchemeHint.NONE),
                auth=BuiltInAuth(),
                client=http_client,
            )
        assert "InvalidURL" in str(exc.value)

    @respx.mock
    async def test_unsupported_protocol_raises_probe_error(self, http_client):
        respx.get("https://target.example/orders").mock(
            side_effect=httpx.UnsupportedProtocol("ftp:// is not supported"),
        )

        with pytest.raises(ProbeError) as exc:
            await dispatch_builtin(
                _request(),
                target=_target(AuthSchemeHint.NONE),
                auth=BuiltInAuth(),
                client=http_client,
            )
        assert "UnsupportedProtocol" in str(exc.value)


class TestRewriteUrl:
    def test_replaces_scheme_host_port(self):
        out = rewrite_url(
            "https://example.com/orders",
            "http://localhost:8005",
        )
        assert out == "http://localhost:8005/orders"

    def test_preserves_query_and_fragment(self):
        out = rewrite_url(
            "https://example.com/orders?q=1#frag",
            "http://localhost:8005",
        )
        assert out == "http://localhost:8005/orders?q=1#frag"

    def test_relative_path_is_appended(self):
        out = rewrite_url("/orders", "http://localhost:8005")
        assert out == "http://localhost:8005/orders"

    def test_base_url_path_prefix_is_concatenated(self):
        out = rewrite_url(
            "https://example.com/orders",
            "http://localhost:8005/api/v2",
        )
        assert out == "http://localhost:8005/api/v2/orders"

    def test_base_url_trailing_slash_is_normalised(self):
        out = rewrite_url(
            "https://example.com/orders",
            "http://localhost:8005/",
        )
        assert out == "http://localhost:8005/orders"

    def test_root_request_path_with_base_prefix(self):
        out = rewrite_url("/", "http://localhost:8005/api")
        assert out == "http://localhost:8005/api/"


class TestDispatchBuiltinBaseUrl:
    @respx.mock
    async def test_base_url_overrides_request_host(self, http_client):
        # The agent guessed example.com; the SDK should hit localhost.
        target_route = respx.get("http://localhost:8005/orders").respond(200)
        # Make sure the original URL is *not* hit.
        respx.get("https://example.com/orders").mock(
            side_effect=AssertionError("original URL must not be called"),
        )

        await dispatch_builtin(
            _request(url="https://example.com/orders"),
            target=_target(AuthSchemeHint.NONE),
            auth=BuiltInAuth(),
            client=http_client,
            base_url="http://localhost:8005",
        )

        assert target_route.called

    @respx.mock
    async def test_base_url_with_path_prefix(self, http_client):
        target_route = respx.get(
            "http://localhost:8005/api/v2/orders",
        ).respond(200)

        await dispatch_builtin(
            _request(url="https://example.com/orders"),
            target=_target(AuthSchemeHint.NONE),
            auth=BuiltInAuth(),
            client=http_client,
            base_url="http://localhost:8005/api/v2",
        )

        assert target_route.called


@pytest.mark.parametrize(
    "scheme,auth_kwargs,expected_header,expected_value",
    [
        (
            AuthSchemeHint.CUSTOM_HEADERS,
            {"headers": {"X-API-Key": "k"}},
            "X-API-Key",
            "k",
        ),
        (
            AuthSchemeHint.BEARER,
            {"bearer_token": "t"},
            "Authorization",
            "Bearer t",
        ),
    ],
)
@respx.mock
async def test_auth_injection_per_scheme(
    scheme,
    auth_kwargs,
    expected_header,
    expected_value,
    http_client,
):
    route = respx.get("https://target.example/orders").respond(200)

    await dispatch_builtin(
        _request(),
        target=_target(scheme),
        auth=BuiltInAuth(**auth_kwargs),
        client=http_client,
    )

    assert route.calls.last.request.headers[expected_header] == expected_value


class TestBuiltInAuthInvariant:
    """BuiltInAuth must hold at most one auth shape. Mixing
    ``headers`` with ``bearer_token`` is a programmer error and
    rejected at construction (defence-in-depth behind the higher-level
    kwarg validators)."""

    def test_neither_set_is_ok(self):
        auth = BuiltInAuth()
        assert dict(auth.headers) == {}
        assert auth.bearer_token is None

    def test_headers_only_is_ok(self):
        auth = BuiltInAuth(headers={"X-API-Key": "k1"})
        assert dict(auth.headers) == {"X-API-Key": "k1"}
        assert auth.bearer_token is None

    def test_bearer_only_is_ok(self):
        auth = BuiltInAuth(bearer_token="t1")
        assert auth.bearer_token == "t1"
        assert dict(auth.headers) == {}

    def test_both_set_raises(self):
        with pytest.raises(ProbeValidationError) as exc:
            BuiltInAuth(
                headers={"X-API-Key": "k1"},
                bearer_token="t1",
            )
        assert "OR" in str(exc.value)


class TestResolveAuthHeaderExhaustiveness:
    """The dispatcher's own auth-scheme guard must fire if a future
    enum value bypasses the higher-level validator."""

    def test_unknown_scheme_in_dispatcher_raises(self):
        from enum import Enum
        from unittest.mock import MagicMock

        from lumenova_beacon.probes._http import _resolve_auth_headers

        class FutureScheme(str, Enum):
            OAUTH2 = "oauth2"

        target = MagicMock()
        target.name = "future-target"
        target.auth_scheme_hint = FutureScheme.OAUTH2

        with pytest.raises(ProbeValidationError) as exc:
            _resolve_auth_headers(target, BuiltInAuth())
        assert "Unhandled auth_scheme_hint" in str(exc.value)


class TestStreamingBodyCap:
    """The dispatcher reads target replies in chunks and stops at
    MAX_BODY_BYTES so a 10 GB target response can't OOM the SDK."""

    @respx.mock
    async def test_oversized_response_is_truncated_at_wire_boundary(self, http_client):
        # 5x the cap ensures truncation regardless of chunk size.
        big = "x" * (MAX_BODY_BYTES * 5)
        respx.get("https://target.example/orders").respond(200, text=big)

        result = await dispatch_builtin(
            _request(),
            target=_target(AuthSchemeHint.NONE),
            auth=BuiltInAuth(),
            client=http_client,
        )

        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.response_body.endswith("... [truncated]")
        # Wire payload never exceeds the cap (marker is counted against budget).
        assert len(result.response_body.encode("utf-8")) <= MAX_BODY_BYTES
