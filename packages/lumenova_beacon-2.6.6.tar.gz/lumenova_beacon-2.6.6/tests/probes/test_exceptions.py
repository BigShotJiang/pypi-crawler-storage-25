"""Tests for probe exception hierarchy."""

import pytest

from lumenova_beacon.exceptions import (
    BeaconError,
    ProbeAlreadyClaimedError,
    ProbeAuthMissingError,
    ProbeError,
    ProbeNotFoundError,
    ProbeRunFailed,
    ProbeValidationError,
)


class TestProbeError:
    def test_inherits_from_beacon_error(self):
        assert issubclass(ProbeError, BeaconError)

    def test_can_raise_and_catch(self):
        with pytest.raises(ProbeError):
            raise ProbeError("boom")

    def test_can_catch_as_beacon_error(self):
        with pytest.raises(BeaconError):
            raise ProbeError("boom")

    def test_message_preserved(self):
        with pytest.raises(ProbeError) as exc:
            raise ProbeError("some message")
        assert str(exc.value) == "some message"


@pytest.mark.parametrize(
    "exc_cls",
    [
        ProbeNotFoundError,
        ProbeValidationError,
        ProbeAlreadyClaimedError,
        ProbeAuthMissingError,
        ProbeRunFailed,
    ],
)
class TestProbeSubclasses:
    def test_inherits_from_probe_error(self, exc_cls):
        assert issubclass(exc_cls, ProbeError)

    def test_inherits_from_beacon_error(self, exc_cls):
        assert issubclass(exc_cls, BeaconError)

    def test_can_raise_and_catch_as_self(self, exc_cls):
        with pytest.raises(exc_cls):
            raise exc_cls("x")

    def test_can_catch_as_probe_error(self, exc_cls):
        with pytest.raises(ProbeError):
            raise exc_cls("x")

    def test_can_catch_as_beacon_error(self, exc_cls):
        with pytest.raises(BeaconError):
            raise exc_cls("x")

    def test_message_preserved(self, exc_cls):
        with pytest.raises(exc_cls) as info:
            raise exc_cls("hello")
        assert str(info.value) == "hello"
