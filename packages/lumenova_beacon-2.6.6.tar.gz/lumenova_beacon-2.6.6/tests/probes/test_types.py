"""Tests for probe type definitions."""

import pytest

from lumenova_beacon.exceptions import ProbeValidationError
from lumenova_beacon.probes.types import (
    AuthSchemeHint,
    ProbeClaimResponse,
    ProbeHttpErrorResponse,
    ProbeHttpRequest,
    ProbeHttpSuccessResponse,
    ProbeResponseKind,
    ProbeRunStatus,
    RunStatusSnapshot,
    TargetSystemRef,
)


class TestAuthSchemeHint:
    def test_all_values(self):
        assert AuthSchemeHint.NONE == "none"
        assert AuthSchemeHint.CUSTOM_HEADERS == "custom_headers"
        assert AuthSchemeHint.BEARER == "bearer"

    def test_has_three_members(self):
        assert len(AuthSchemeHint) == 3

    def test_is_string(self):
        assert isinstance(AuthSchemeHint.NONE, str)

    def test_unknown_value_raises(self):
        with pytest.raises(ValueError):
            AuthSchemeHint("oauth2")

    @pytest.mark.parametrize(
        "wire,expected",
        [
            ("none", AuthSchemeHint.NONE),
            ("custom_headers", AuthSchemeHint.CUSTOM_HEADERS),
            ("bearer", AuthSchemeHint.BEARER),
            (None, AuthSchemeHint.NONE),
        ],
    )
    def test_from_wire(self, wire, expected):
        assert AuthSchemeHint.from_wire(wire) is expected

    def test_from_wire_unknown_raises_validation_error(self):
        with pytest.raises(ProbeValidationError) as exc:
            AuthSchemeHint.from_wire("oauth2")
        assert "custom_headers" in str(exc.value)

    def test_from_wire_non_str_raises_validation_error(self):
        with pytest.raises(ProbeValidationError):
            AuthSchemeHint.from_wire(42)


class TestProbeResponseKind:
    def test_all_values(self):
        assert ProbeResponseKind.RESPONSE == "response"
        assert ProbeResponseKind.ERROR == "error"

    def test_has_two_members(self):
        assert len(ProbeResponseKind) == 2


class TestTargetSystemRef:
    def test_from_dict_full(self):
        target = TargetSystemRef.from_dict(
            {
                "id": "t1",
                "name": "orders-api",
                "base_url": "https://orders.internal.example.com",
                "auth_scheme_hint": "custom_headers",
                "auth_metadata": {
                    "headers": [
                        {"name": "X-Tenant-Key"},
                        {"name": "X-Trace"},
                    ],
                    "sensitive_headers": ["X-Custom"],
                    "sensitive_body_fields": ["internal_token"],
                },
            }
        )
        assert target.id == "t1"
        assert target.name == "orders-api"
        assert target.base_url == "https://orders.internal.example.com"
        assert target.auth_scheme_hint is AuthSchemeHint.CUSTOM_HEADERS
        assert target.auth_metadata["headers"][0]["name"] == "X-Tenant-Key"

    def test_from_dict_defaults_to_none_scheme(self):
        target = TargetSystemRef.from_dict(
            {
                "id": "t1",
                "name": "public-api",
                "base_url": "https://api.example.com",
            }
        )
        assert target.auth_scheme_hint is AuthSchemeHint.NONE
        assert target.auth_metadata == {}

    def test_from_dict_treats_null_scheme_as_none(self):
        target = TargetSystemRef.from_dict(
            {
                "id": "t1",
                "name": "x",
                "base_url": "https://x",
                "auth_scheme_hint": None,
            }
        )
        assert target.auth_scheme_hint is AuthSchemeHint.NONE

    def test_is_immutable(self):
        target = TargetSystemRef(id="t1", name="x", base_url="https://x")
        with pytest.raises(Exception):
            target.name = "y"

    def test_base_url_optional_for_sdk_callable_mode(self):
        target = TargetSystemRef.from_dict(
            {
                "id": "t1",
                "name": "opaque",
                "base_url": None,
                "auth_scheme_hint": "none",
            }
        )
        assert target.base_url is None


class TestProbeHttpRequest:
    def test_from_dict_full(self):
        req = ProbeHttpRequest.from_dict(
            {
                "id": "e1",
                "evaluation_run_id": "r1",
                "seq": 42,
                "method": "post",
                "url": "https://target.example.com/orders",
                "request_headers": {"Content-Type": "application/json"},
                "request_body": '{"limit":5}',
                "lens": "Input Validation",
                "tool_name": "make_http_request",
            }
        )
        assert req.method == "POST"
        assert req.request_headers == {"Content-Type": "application/json"}
        assert req.lens == "Input Validation"

    def test_from_dict_minimal(self):
        req = ProbeHttpRequest.from_dict(
            {
                "id": "e1",
                "evaluation_run_id": "r1",
                "seq": 1,
                "method": "GET",
                "url": "https://target.example.com/",
            }
        )
        assert req.request_headers == {}
        assert req.request_body is None

    def test_method_uppercased(self):
        req = ProbeHttpRequest.from_dict(
            {
                "id": "e1",
                "evaluation_run_id": "r1",
                "seq": 1,
                "method": "patch",
                "url": "https://x/",
            }
        )
        assert req.method == "PATCH"

    def test_headers_copied_not_aliased(self):
        headers = {"X-Foo": "bar"}
        req = ProbeHttpRequest.from_dict(
            {
                "id": "e1",
                "evaluation_run_id": "r1",
                "seq": 1,
                "method": "GET",
                "url": "https://x/",
                "request_headers": headers,
            }
        )
        headers["X-Foo"] = "mutated"
        assert req.request_headers == {"X-Foo": "bar"}


class TestProbeHttpSuccessResponse:
    def test_fields_non_optional_where_required(self):
        resp = ProbeHttpSuccessResponse(
            duration_ms=147,
            status_code=200,
            response_headers={"Content-Type": "application/json"},
            response_body='{"ok":true}',
        )
        assert resp.kind is ProbeResponseKind.RESPONSE
        assert resp.status_code == 200
        assert resp.response_headers == {"Content-Type": "application/json"}
        assert resp.response_body == '{"ok":true}'

    def test_default_response_headers_empty_dict(self):
        resp = ProbeHttpSuccessResponse(duration_ms=10, status_code=204)
        assert resp.response_headers == {}
        assert resp.response_body is None

    def test_to_dict(self):
        resp = ProbeHttpSuccessResponse(
            duration_ms=50,
            status_code=200,
            response_headers={"X-RateLimit": "1000"},
            response_body="{}",
        )
        assert resp.to_dict() == {
            "kind": "response",
            "status_code": 200,
            "response_headers": {"X-RateLimit": "1000"},
            "response_body": "{}",
            "duration_ms": 50,
        }

    def test_is_immutable(self):
        resp = ProbeHttpSuccessResponse(duration_ms=1, status_code=200)
        with pytest.raises(Exception):
            resp.status_code = 500


class TestProbeHttpErrorResponse:
    def test_fields(self):
        resp = ProbeHttpErrorResponse(
            duration_ms=5000,
            error="ConnectError: dns failed",
        )
        assert resp.kind is ProbeResponseKind.ERROR
        assert resp.error == "ConnectError: dns failed"

    def test_to_dict(self):
        resp = ProbeHttpErrorResponse(
            duration_ms=30000,
            error="TimeoutException: read timeout",
        )
        assert resp.to_dict() == {
            "kind": "error",
            "error": "TimeoutException: read timeout",
            "duration_ms": 30000,
        }

    def test_is_immutable(self):
        resp = ProbeHttpErrorResponse(duration_ms=1, error="x")
        with pytest.raises(Exception):
            resp.error = "y"


class TestProbeRunStatus:
    def test_all_values(self):
        assert ProbeRunStatus.PENDING == "PENDING"
        assert ProbeRunStatus.RUNNING == "RUNNING"
        assert ProbeRunStatus.COMPLETED == "COMPLETED"
        assert ProbeRunStatus.FAILED == "FAILED"
        assert ProbeRunStatus.CANCELLED == "CANCELLED"

    def test_has_five_members(self):
        assert len(ProbeRunStatus) == 5

    @pytest.mark.parametrize(
        "wire,expected",
        [
            ("PENDING", ProbeRunStatus.PENDING),
            ("pending", ProbeRunStatus.PENDING),
            ("Running", ProbeRunStatus.RUNNING),
            ("COMPLETED", ProbeRunStatus.COMPLETED),
        ],
    )
    def test_from_wire_case_insensitive(self, wire, expected):
        assert ProbeRunStatus.from_wire(wire) is expected

    def test_from_wire_unknown_raises_validation_error(self):
        with pytest.raises(ProbeValidationError) as exc:
            ProbeRunStatus.from_wire("queued")
        # Error lists the valid set to aid debugging.
        assert "COMPLETED" in str(exc.value)

    def test_from_wire_non_str_raises_validation_error(self):
        with pytest.raises(ProbeValidationError):
            ProbeRunStatus.from_wire(None)
        with pytest.raises(ProbeValidationError):
            ProbeRunStatus.from_wire(42)

    @pytest.mark.parametrize(
        "status,terminal",
        [
            (ProbeRunStatus.PENDING, False),
            (ProbeRunStatus.RUNNING, False),
            (ProbeRunStatus.COMPLETED, True),
            (ProbeRunStatus.FAILED, True),
            (ProbeRunStatus.CANCELLED, True),
        ],
    )
    def test_is_terminal(self, status, terminal):
        assert status.is_terminal is terminal


class TestProbeClaimResponse:
    def test_from_dict_full(self):
        claim = ProbeClaimResponse.from_dict(
            {
                "run_id": "r1",
                "runner_id": "laptop:42",
                "evaluation_id": "e1",
                "target_system": {
                    "id": "t1",
                    "name": "orders-api",
                    "base_url": "https://orders.internal",
                    "auth_scheme_hint": "bearer",
                    "auth_metadata": {"sensitive_headers": ["X-Custom"]},
                },
            }
        )
        assert claim.run_id == "r1"
        assert claim.target_system.name == "orders-api"
        assert claim.target_system.auth_scheme_hint is AuthSchemeHint.BEARER

    def test_is_immutable(self):
        claim = ProbeClaimResponse(
            run_id="r",
            runner_id="u",
            evaluation_id="e",
            target_system=TargetSystemRef(id="t", name="x", base_url="https://x"),
        )
        with pytest.raises(Exception):
            claim.run_id = "z"


class TestRunStatusSnapshot:
    def test_from_dict_running(self):
        snap = RunStatusSnapshot.from_dict({"id": "r1", "status": "RUNNING"})
        assert snap.status is ProbeRunStatus.RUNNING
        assert snap.is_terminal is False

    def test_from_dict_terminal_with_error(self):
        snap = RunStatusSnapshot.from_dict(
            {
                "id": "r1",
                "status": "FAILED",
                "error_message": "ProbeSdkTimeout",
            }
        )
        assert snap.status is ProbeRunStatus.FAILED
        assert snap.error_message == "ProbeSdkTimeout"
        assert snap.is_terminal is True

    def test_from_dict_accepts_lowercase_status(self):
        snap = RunStatusSnapshot.from_dict({"id": "r1", "status": "completed"})
        assert snap.status is ProbeRunStatus.COMPLETED

    def test_from_dict_unknown_status_raises_validation(self):
        with pytest.raises(ProbeValidationError):
            RunStatusSnapshot.from_dict({"id": "r1", "status": "NEW_SERVER_STATE"})

    def test_is_immutable(self):
        snap = RunStatusSnapshot(id="r", status=ProbeRunStatus.PENDING)
        with pytest.raises(Exception):
            snap.id = "z"


class TestFromDictSchemaDrift:
    """A backend response missing a required field must raise
    ``ProbeValidationError`` (with the field name + version-mismatch
    hint), not bare ``KeyError`` from deep inside parsing."""

    def test_target_system_missing_id(self):
        with pytest.raises(ProbeValidationError) as exc:
            TargetSystemRef.from_dict({"name": "x"})
        assert "id" in str(exc.value)
        assert "version mismatch" in str(exc.value)

    def test_probe_http_request_missing_url(self):
        with pytest.raises(ProbeValidationError) as exc:
            ProbeHttpRequest.from_dict(
                {
                    "id": "e1",
                    "evaluation_run_id": "r1",
                    "seq": 1,
                    "method": "GET",
                }
            )
        assert "url" in str(exc.value)

    def test_probe_claim_response_missing_target_system(self):
        with pytest.raises(ProbeValidationError) as exc:
            ProbeClaimResponse.from_dict(
                {
                    "run_id": "r1",
                    "runner_id": "u1",
                    "evaluation_id": "e1",
                }
            )
        assert "target_system" in str(exc.value)

    def test_run_status_snapshot_missing_status(self):
        with pytest.raises(ProbeValidationError) as exc:
            RunStatusSnapshot.from_dict({"id": "r1"})
        assert "status" in str(exc.value)


class TestProbeHttpRequestSeqValidator:
    def test_negative_seq_rejected(self):
        with pytest.raises(ProbeValidationError):
            ProbeHttpRequest(
                id="e1",
                evaluation_run_id="r1",
                seq=-1,
                method="GET",
                url="https://x/",
            )

    def test_zero_seq_accepted(self):
        # seq=0 is a valid wire value (first event in a run).
        req = ProbeHttpRequest(
            id="e1",
            evaluation_run_id="r1",
            seq=0,
            method="GET",
            url="https://x/",
        )
        assert req.seq == 0


class TestProbeHttpRequestMethodValidator:
    def test_unknown_method_rejected(self):
        with pytest.raises(ProbeValidationError) as exc:
            ProbeHttpRequest(
                id="e1",
                evaluation_run_id="r1",
                seq=1,
                method="FROBNICATE",
                url="https://x/",
            )
        assert "FROBNICATE" in str(exc.value)

    def test_from_dict_unknown_method_rejected(self):
        with pytest.raises(ProbeValidationError):
            ProbeHttpRequest.from_dict(
                {
                    "id": "e1",
                    "evaluation_run_id": "r1",
                    "seq": 1,
                    "method": "frobnicate",
                    "url": "https://x/",
                }
            )


class TestResponseValidators:
    def test_negative_duration_ms_rejected_on_success(self):
        with pytest.raises(ProbeValidationError):
            ProbeHttpSuccessResponse(duration_ms=-1, status_code=200)

    def test_negative_duration_ms_rejected_on_error(self):
        with pytest.raises(ProbeValidationError):
            ProbeHttpErrorResponse(duration_ms=-1, error="x")

    def test_status_code_below_100_rejected(self):
        with pytest.raises(ProbeValidationError):
            ProbeHttpSuccessResponse(duration_ms=10, status_code=99)

    def test_status_code_at_or_above_600_rejected(self):
        with pytest.raises(ProbeValidationError):
            ProbeHttpSuccessResponse(duration_ms=10, status_code=600)

    @pytest.mark.parametrize("status_code", [100, 200, 301, 404, 500, 599])
    def test_in_range_status_codes_accepted(self, status_code):
        resp = ProbeHttpSuccessResponse(duration_ms=10, status_code=status_code)
        assert resp.status_code == status_code


class TestTargetSystemRefValidators:
    def test_empty_id_rejected(self):
        with pytest.raises(ProbeValidationError):
            TargetSystemRef(id="", name="orders")

    def test_empty_name_rejected(self):
        with pytest.raises(ProbeValidationError):
            TargetSystemRef(id="t1", name="")
