"""Integration tests for the SDK probe runner.

Exercises the full wire path: fake Beacon via respx, plus either a
fake target served via respx (path A — built-in dispatcher) or an
in-process ``target_callable`` (path B).
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import httpx
import pytest
import respx

from lumenova_beacon.exceptions import ProbeAlreadyClaimedError
from lumenova_beacon.probes.models import Probe
from lumenova_beacon.probes.types import (
    ProbeHttpErrorResponse,
    ProbeHttpRequest,
    ProbeHttpSuccessResponse,
    ProbeRunStatus,
)

BEACON_URL = "https://beacon.test"


def _transport():
    transport = MagicMock()
    transport.headers = {"Authorization": "Bearer beacon-key"}
    transport.timeout = 30
    transport.verify = True
    return transport


@pytest.fixture
def beacon_env():
    with (
        patch(
            "lumenova_beacon.probes._beacon_client.get_base_url",
            return_value=BEACON_URL,
        ),
        patch(
            "lumenova_beacon.probes._beacon_client.get_transport",
            return_value=_transport(),
        ),
    ):
        yield


def _claim_body():
    return {
        "run_id": "run-42",
        "runner_id": "echoed",
        "evaluation_id": "eval-1",
        "target_system": {
            "id": "t1",
            "name": "orders-api",
            "base_url": None,
            "auth_scheme_hint": "none",
            "auth_metadata": {},
        },
    }


@respx.mock
async def test_full_loop_happy_path(beacon_env):
    """Claim → 2 pending events → callable invoked → PATCH → terminal."""
    claim_route = respx.post(
        f"{BEACON_URL}/api/v1/evaluation-runs/eval-1/claim-probe",
    ).respond(200, json=_claim_body())

    list_route = respx.get(f"{BEACON_URL}/api/v1/probe-requests").mock(
        side_effect=[
            httpx.Response(
                200,
                json=[
                    {
                        "id": "event-1",
                        "evaluation_run_id": "run-42",
                        "seq": 1,
                        "method": "GET",
                        "url": "https://target.internal/orders",
                        "request_headers": {},
                        "request_body": None,
                    },
                    {
                        "id": "event-2",
                        "evaluation_run_id": "run-42",
                        "seq": 2,
                        "method": "POST",
                        "url": "https://target.internal/orders",
                        "request_headers": {"Content-Type": "application/json"},
                        "request_body": '{"customer":"alice"}',
                    },
                ],
            ),
            httpx.Response(200, json=[]),
        ],
    )

    patch_1 = respx.patch(
        f"{BEACON_URL}/api/v1/probe-requests/event-1",
    ).respond(200, json={})
    patch_2 = respx.patch(
        f"{BEACON_URL}/api/v1/probe-requests/event-2",
    ).respond(200, json={})
    refresh_route = respx.get(
        f"{BEACON_URL}/api/v1/evaluation-runs/run-42",
    ).respond(200, json={"id": "run-42", "status": "COMPLETED"})

    seen: list[ProbeHttpRequest] = []

    def my_target(request: ProbeHttpRequest) -> ProbeHttpSuccessResponse:
        seen.append(request)
        if request.method == "GET":
            return ProbeHttpSuccessResponse(
                duration_ms=12,
                status_code=200,
                response_body='{"orders": [{"id": "o1"}]}',
            )
        return ProbeHttpSuccessResponse(
            duration_ms=15,
            status_code=201,
            response_body='{"id": "o3"}',
        )

    result = await Probe.arun(
        "eval-1",
        target_callable=my_target,
        poll_interval=0,
    )
    assert result.status is ProbeRunStatus.COMPLETED

    assert claim_route.called
    assert list_route.call_count == 2

    # The callable saw both requests with full payloads.
    assert {req.id for req in seen} == {"event-1", "event-2"}

    patch_1_body = json.loads(patch_1.calls[0].request.content)
    assert patch_1_body["kind"] == "response"
    assert patch_1_body["status_code"] == 200
    assert json.loads(patch_1_body["response_body"]) == {"orders": [{"id": "o1"}]}

    patch_2_body = json.loads(patch_2.calls[0].request.content)
    assert patch_2_body["kind"] == "response"
    assert patch_2_body["status_code"] == 201

    assert refresh_route.called


@respx.mock
async def test_callable_raises_becomes_error_patch(beacon_env):
    """Exception inside the user's callable → ERROR-kind PATCH, run continues."""
    respx.post(
        f"{BEACON_URL}/api/v1/evaluation-runs/eval-1/claim-probe",
    ).respond(200, json=_claim_body())

    respx.get(f"{BEACON_URL}/api/v1/probe-requests").mock(
        side_effect=[
            httpx.Response(
                200,
                json=[
                    {
                        "id": "event-1",
                        "evaluation_run_id": "run-42",
                        "seq": 1,
                        "method": "GET",
                        "url": "https://target.internal/orders",
                        "request_headers": {},
                        "request_body": None,
                    }
                ],
            ),
            httpx.Response(200, json=[]),
        ],
    )

    patch_route = respx.patch(
        f"{BEACON_URL}/api/v1/probe-requests/event-1",
    ).respond(200, json={})
    respx.get(f"{BEACON_URL}/api/v1/evaluation-runs/run-42").respond(
        200,
        json={"id": "run-42", "status": "COMPLETED"},
    )

    def boom(_request):
        raise RuntimeError("dns failed")

    await Probe.arun("eval-1", target_callable=boom, poll_interval=0)

    body = json.loads(patch_route.calls[0].request.content)
    assert body["kind"] == "error"
    assert "RuntimeError" in body["error"]
    assert "dns failed" in body["error"]


@respx.mock
async def test_callable_returns_error_response(beacon_env):
    """Callable explicitly returns a ProbeHttpErrorResponse — passes through."""
    respx.post(
        f"{BEACON_URL}/api/v1/evaluation-runs/eval-1/claim-probe",
    ).respond(200, json=_claim_body())

    respx.get(f"{BEACON_URL}/api/v1/probe-requests").mock(
        side_effect=[
            httpx.Response(
                200,
                json=[
                    {
                        "id": "event-1",
                        "evaluation_run_id": "run-42",
                        "seq": 1,
                        "method": "GET",
                        "url": "https://target.internal/orders",
                        "request_headers": {},
                        "request_body": None,
                    }
                ],
            ),
            httpx.Response(200, json=[]),
        ],
    )

    patch_route = respx.patch(
        f"{BEACON_URL}/api/v1/probe-requests/event-1",
    ).respond(200, json={})
    respx.get(f"{BEACON_URL}/api/v1/evaluation-runs/run-42").respond(
        200,
        json={"id": "run-42", "status": "COMPLETED"},
    )

    def explicit_error(_request):
        return ProbeHttpErrorResponse(duration_ms=5, error="ConnectError")

    await Probe.arun("eval-1", target_callable=explicit_error, poll_interval=0)

    body = json.loads(patch_route.calls[0].request.content)
    assert body["kind"] == "error"
    assert body["error"] == "ConnectError"


@respx.mock
async def test_claim_409_surfaces_as_already_claimed(beacon_env):
    respx.post(
        f"{BEACON_URL}/api/v1/evaluation-runs/eval-1/claim-probe",
    ).respond(409, json={"detail": "claimed by another-runner"})

    def _ok(_):
        return ProbeHttpSuccessResponse(duration_ms=1, status_code=200)

    with pytest.raises(ProbeAlreadyClaimedError):
        await Probe.arun("eval-1", target_callable=_ok, poll_interval=0)


def _claim_body_with_auth(
    scheme: str = "custom_headers",
    auth_metadata: dict | None = None,
) -> dict:
    body = _claim_body()
    body["target_system"]["auth_scheme_hint"] = scheme
    if auth_metadata is not None:
        body["target_system"]["auth_metadata"] = auth_metadata
    return body


@pytest.mark.parametrize(
    "scheme,auth_metadata,kwargs,expected_header,expected_value",
    [
        (
            "custom_headers",
            {"headers": [{"name": "X-API-Key"}]},
            {"headers": {"X-API-Key": "user-key"}},
            "X-API-Key",
            "user-key",
        ),
        (
            "bearer",
            {},
            {"bearer_token": "user-token"},
            "Authorization",
            "Bearer user-token",
        ),
    ],
)
@respx.mock
async def test_full_loop_builtin_dispatcher(
    scheme,
    auth_metadata,
    kwargs,
    expected_header,
    expected_value,
    beacon_env,
):
    """Path A — no callable, SDK fires httpx itself with kwarg auth.

    Parametrized over both auth schemes to catch a copy-paste flip in
    the validator/dispatcher (e.g. swapping headers with bearer_token
    branches) end-to-end, not just at the unit level.
    """
    respx.post(
        f"{BEACON_URL}/api/v1/evaluation-runs/eval-1/claim-probe",
    ).respond(200, json=_claim_body_with_auth(scheme, auth_metadata))

    respx.get(f"{BEACON_URL}/api/v1/probe-requests").mock(
        side_effect=[
            httpx.Response(
                200,
                json=[
                    {
                        "id": "event-1",
                        "evaluation_run_id": "run-42",
                        "seq": 1,
                        "method": "GET",
                        "url": "https://target.internal/orders",
                        "request_headers": {},
                        "request_body": None,
                    }
                ],
            ),
            httpx.Response(200, json=[]),
        ],
    )

    target_route = respx.get("https://target.internal/orders").respond(
        200,
        json={"orders": []},
    )
    patch_route = respx.patch(
        f"{BEACON_URL}/api/v1/probe-requests/event-1",
    ).respond(200, json={})
    respx.get(f"{BEACON_URL}/api/v1/evaluation-runs/run-42").respond(
        200,
        json={"id": "run-42", "status": "COMPLETED"},
    )

    result = await Probe.arun("eval-1", poll_interval=0, **kwargs)
    assert result.status is ProbeRunStatus.COMPLETED

    assert target_route.called
    sent_headers = target_route.calls.last.request.headers
    assert sent_headers[expected_header] == expected_value

    body = json.loads(patch_route.calls[0].request.content)
    assert body["kind"] == "response"
    assert body["status_code"] == 200


@respx.mock
async def test_builtin_dispatcher_target_connect_error_is_error_kind(beacon_env):
    """Path A — target unreachable → kind=error PATCH, run continues."""
    respx.post(
        f"{BEACON_URL}/api/v1/evaluation-runs/eval-1/claim-probe",
    ).respond(200, json=_claim_body_with_auth("none"))

    respx.get(f"{BEACON_URL}/api/v1/probe-requests").mock(
        side_effect=[
            httpx.Response(
                200,
                json=[
                    {
                        "id": "event-1",
                        "evaluation_run_id": "run-42",
                        "seq": 1,
                        "method": "GET",
                        "url": "https://target.internal/orders",
                        "request_headers": {},
                        "request_body": None,
                    }
                ],
            ),
            httpx.Response(200, json=[]),
        ],
    )

    respx.get("https://target.internal/orders").mock(
        side_effect=httpx.ConnectError("connect refused"),
    )
    patch_route = respx.patch(
        f"{BEACON_URL}/api/v1/probe-requests/event-1",
    ).respond(200, json={})
    respx.get(f"{BEACON_URL}/api/v1/evaluation-runs/run-42").respond(
        200,
        json={"id": "run-42", "status": "COMPLETED"},
    )

    await Probe.arun("eval-1", poll_interval=0)

    body = json.loads(patch_route.calls[0].request.content)
    assert body["kind"] == "error"
    assert "ConnectError" in body["error"]
