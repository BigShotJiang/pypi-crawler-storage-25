"""Tests for probes._beacon_client — the Beacon API surface."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from lumenova_beacon.exceptions import (
    ProbeAlreadyClaimedError,
    ProbeError,
    ProbeNotFoundError,
    ProbeValidationError,
)
from lumenova_beacon.probes._beacon_client import (
    claim,
    list_pending_requests,
    post_response,
    refresh_run,
)
from lumenova_beacon.probes.types import (
    AuthSchemeHint,
    ProbeHttpErrorResponse,
    ProbeHttpRequest,
    ProbeHttpSuccessResponse,
    ProbeRunStatus,
)


def _mock_transport():
    transport = MagicMock()
    transport.headers = {"Authorization": "Bearer beacon-key"}
    transport.timeout = 30
    transport.verify = True
    return transport


def _mock_response(data=None, status_code=200):
    response = MagicMock(spec=httpx.Response)
    response.status_code = status_code
    response.json = MagicMock(return_value=data if data is not None else {})
    response.text = "" if data is None else str(data)
    response.raise_for_status = MagicMock()
    return response


def _error_response(
    status_code: int, detail: str = "nope", *, json_is_dict: bool = True
):
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    if json_is_dict:
        resp.json = MagicMock(return_value={"detail": detail})
    else:
        # Non-dict JSON body (e.g., a bare string or array)
        resp.json = MagicMock(return_value=detail)
    resp.text = detail
    resp.raise_for_status = MagicMock(
        side_effect=httpx.HTTPStatusError(
            f"HTTP {status_code}",
            request=MagicMock(),
            response=resp,
        ),
    )
    return resp


def _make_async_client(
    post=None,
    get=None,
    patch_method=None,
    side_effect=None,
):
    """Return an AsyncMock httpx.AsyncClient with distinct per-verb mocks."""
    mock_client = AsyncMock()
    mock_client.post = AsyncMock(
        return_value=post,
        side_effect=side_effect if post is None else None,
    )
    mock_client.get = AsyncMock(
        return_value=get,
        side_effect=side_effect if get is None else None,
    )
    mock_client.patch = AsyncMock(
        return_value=patch_method,
        side_effect=side_effect if patch_method is None else None,
    )
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    return mock_client


def _patches():
    return [
        patch(
            "lumenova_beacon.probes._beacon_client.get_base_url",
            return_value="https://beacon.test",
        ),
        patch(
            "lumenova_beacon.probes._beacon_client.get_transport",
            return_value=_mock_transport(),
        ),
    ]


SAMPLE_CLAIM_RESPONSE = {
    "run_id": "run-1",
    "runner_id": "laptop:42",
    "evaluation_id": "eval-1",
    "target_system": {
        "id": "t1",
        "name": "orders-api",
        "base_url": "https://orders.internal",
        "auth_scheme_hint": "custom_headers",
        "auth_metadata": {"headers": [{"name": "X-API-Key"}]},
    },
}


class TestClaim:
    async def test_happy_path_returns_claim_response(self):
        mock_client = _make_async_client(post=_mock_response(SAMPLE_CLAIM_RESPONSE))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            result = await claim("eval-1", runner_id="laptop:42")

        assert result.run_id == "run-1"
        assert result.target_system.auth_scheme_hint is AuthSchemeHint.CUSTOM_HEADERS
        # Claim uses POST, not GET/PATCH.
        assert mock_client.post.call_count == 1
        assert mock_client.get.call_count == 0
        assert mock_client.patch.call_count == 0

    async def test_posts_runner_id_to_correct_url(self):
        mock_client = _make_async_client(post=_mock_response(SAMPLE_CLAIM_RESPONSE))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            await claim("eval-1", runner_id="laptop:42")

        call = mock_client.post.call_args
        assert call.args[0] == (
            "https://beacon.test/api/v1/evaluation-runs/eval-1/claim-probe"
        )
        assert call.kwargs["json"] == {"runner_id": "laptop:42"}

    async def test_409_becomes_already_claimed_error(self):
        mock_client = _make_async_client(
            post=_error_response(409, "already claimed by laptop:99"),
        )
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeAlreadyClaimedError) as exc:
                await claim("eval-1", runner_id="laptop:42")
        assert "already claimed" in str(exc.value)

    async def test_409_non_dict_json_body_does_not_crash(self):
        # Server sometimes returns a bare-string or array JSON body; must not
        # crash the handler with AttributeError.
        mock_client = _make_async_client(
            post=_error_response(409, "some-string-detail", json_is_dict=False),
        )
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeAlreadyClaimedError):
                await claim("eval-1", runner_id="laptop:42")

    async def test_409_with_non_json_body_falls_back_to_text(self):
        # An nginx HTML error page hits the JSON parse fallback path —
        # the handler must surface ProbeAlreadyClaimedError with the text
        # body, not crash with ValueError from json().
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = 409
        resp.json = MagicMock(side_effect=ValueError("not json"))
        resp.text = "<html><body>Conflict</body></html>"
        resp.raise_for_status = MagicMock(
            side_effect=httpx.HTTPStatusError(
                "HTTP 409",
                request=MagicMock(),
                response=resp,
            ),
        )
        mock_client = _make_async_client(post=resp)
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeAlreadyClaimedError) as exc:
                await claim("eval-1", runner_id="laptop:42")
        assert "Conflict" in str(exc.value)

    async def test_500_error_body_is_truncated(self):
        # A multi-KB 5xx body must not pollute log lines / exception messages.
        big = "x" * 5000
        mock_client = _make_async_client(post=_error_response(500, big))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeError) as exc:
                await claim("eval-1", runner_id="laptop:42")
        assert "[truncated]" in str(exc.value)
        assert len(str(exc.value)) < 1000  # well under the original 5KB body

    async def test_404_becomes_not_found(self):
        mock_client = _make_async_client(post=_error_response(404, "no such run"))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeNotFoundError):
                await claim("eval-missing", runner_id="laptop:42")

    async def test_422_becomes_validation_error(self):
        mock_client = _make_async_client(post=_error_response(422, "bad runner_id"))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeValidationError):
                await claim("eval-1", runner_id="")

    async def test_500_does_not_retry(self):
        # HTTPStatusError is caught in-function and converted to Probe* before
        # tenacity can see it — so 5xx is single-shot (design, see module docstring).
        mock_client = _make_async_client(post=_error_response(500, "boom"))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeError):
                await claim("eval-1", runner_id="laptop:42")
        assert mock_client.post.call_count == 1


class TestListPendingRequests:
    async def test_happy_path_returns_parsed_list(self):
        events = [
            {
                "id": "e1",
                "evaluation_run_id": "run-1",
                "seq": 1,
                "method": "GET",
                "url": "https://target/orders",
                "request_headers": {},
                "request_body": None,
            },
            {
                "id": "e2",
                "evaluation_run_id": "run-1",
                "seq": 2,
                "method": "POST",
                "url": "https://target/orders",
                "request_headers": {"Content-Type": "application/json"},
                "request_body": '{"x":1}',
            },
        ]
        mock_client = _make_async_client(get=_mock_response(events))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            result = await list_pending_requests("laptop:42")

        assert len(result) == 2
        assert isinstance(result[0], ProbeHttpRequest)

    async def test_empty_response(self):
        mock_client = _make_async_client(get=_mock_response([]))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            assert await list_pending_requests("laptop:42") == []

    async def test_passes_runner_id_and_limit(self):
        mock_client = _make_async_client(get=_mock_response([]))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            await list_pending_requests("laptop:42", limit=5)

        call = mock_client.get.call_args
        assert call.args[0] == "https://beacon.test/api/v1/probe-requests"
        assert call.kwargs["params"] == {"runner_id": "laptop:42", "limit": 5}

    async def test_default_limit(self):
        mock_client = _make_async_client(get=_mock_response([]))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            await list_pending_requests("laptop:42")
        assert mock_client.get.call_args.kwargs["params"]["limit"] == 10

    async def test_404_becomes_not_found(self):
        mock_client = _make_async_client(get=_error_response(404, "unknown runner"))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeNotFoundError):
                await list_pending_requests("unknown")


class TestPostResponse:
    async def test_happy_path_success_body(self):
        mock_client = _make_async_client(patch_method=_mock_response({}))
        response = ProbeHttpSuccessResponse(
            duration_ms=147,
            status_code=200,
            response_headers={"Content-Type": "application/json"},
            response_body='{"ok":true}',
        )
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            await post_response("e1", response)

        call = mock_client.patch.call_args
        assert call.args[0] == "https://beacon.test/api/v1/probe-requests/e1"
        body = call.kwargs["json"]
        assert body["kind"] == "response"
        assert body["status_code"] == 200
        assert body["duration_ms"] == 147

    async def test_happy_path_error_body(self):
        mock_client = _make_async_client(patch_method=_mock_response({}))
        response = ProbeHttpErrorResponse(
            duration_ms=5000,
            error="ConnectError: dns failed",
        )
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            await post_response("e1", response)

        body = mock_client.patch.call_args.kwargs["json"]
        assert body["kind"] == "error"
        assert body["error"] == "ConnectError: dns failed"

    async def test_4xx_does_not_retry(self):
        mock_client = _make_async_client(
            patch_method=_error_response(409, "row completed")
        )
        response = ProbeHttpErrorResponse(duration_ms=1, error="x")
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeError):
                await post_response("e1", response)
        assert mock_client.patch.call_count == 1


class TestRefreshRun:
    async def test_happy_path_running(self):
        mock_client = _make_async_client(
            get=_mock_response(
                {"id": "run-1", "status": "RUNNING"},
            )
        )
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            snap = await refresh_run("run-1")

        assert snap.status is ProbeRunStatus.RUNNING
        assert snap.is_terminal is False

    async def test_terminal_completed(self):
        mock_client = _make_async_client(
            get=_mock_response(
                {"id": "run-1", "status": "COMPLETED"},
            )
        )
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            snap = await refresh_run("run-1")
        assert snap.is_terminal is True

    async def test_terminal_failed_with_error(self):
        mock_client = _make_async_client(
            get=_mock_response(
                {"id": "run-1", "status": "FAILED", "error_message": "timeout"},
            )
        )
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            snap = await refresh_run("run-1")
        assert snap.error_message == "timeout"

    async def test_uses_generic_evaluation_runs_endpoint(self):
        mock_client = _make_async_client(
            get=_mock_response(
                {"id": "run-1", "status": "RUNNING"},
            )
        )
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            await refresh_run("run-1")

        assert mock_client.get.call_args.args[0] == (
            "https://beacon.test/api/v1/evaluation-runs/run-1"
        )

    async def test_404_becomes_not_found(self):
        mock_client = _make_async_client(get=_error_response(404, "gone"))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeNotFoundError):
                await refresh_run("run-missing")


class TestNetworkErrorHandling:
    async def test_claim_surfaces_network_error_as_probe_error(self):
        mock_client = _make_async_client(side_effect=httpx.ConnectError("dns"))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeError):
                await claim("eval-1", runner_id="x")


class TestTenacityRetryBehavior:
    """Pin the retry shape so a future change to ``_retry_*`` decorators
    is loud rather than silent."""

    async def test_claim_retries_network_error_until_success(self):
        # ConnectError on first two attempts, succeeds on the third.
        mock_client = AsyncMock()
        attempts = {"count": 0}

        async def flaky_post(*args, **kwargs):
            attempts["count"] += 1
            if attempts["count"] < 3:
                raise httpx.ConnectError("transient")
            return _mock_response(SAMPLE_CLAIM_RESPONSE)

        mock_client.post = AsyncMock(side_effect=flaky_post)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
            patch(
                "tenacity.nap.sleep",
                return_value=None,  # skip wait between retries
            ),
        ):
            result = await claim("eval-1", runner_id="laptop:42")

        assert attempts["count"] == 3
        assert result.run_id == "run-1"

    async def test_claim_retries_exhausted_after_three_attempts(self):
        mock_client = _make_async_client(
            side_effect=httpx.ConnectError("permanent"),
        )
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
            patch(
                "tenacity.nap.sleep",
                return_value=None,
            ),
        ):
            with pytest.raises(ProbeError):
                await claim("eval-1", runner_id="laptop:42")

        # Three attempts (default _retry_idempotent stop_after_attempt=3).
        assert mock_client.post.call_count == 3

    async def test_post_response_does_not_retry_on_read_timeout(self):
        # PATCH is a write — only connect-phase errors are retry-safe;
        # read-phase errors leave server state ambiguous.
        mock_client = _make_async_client(
            side_effect=httpx.ReadTimeout("response lost"),
        )
        response = ProbeHttpErrorResponse(duration_ms=1, error="x")
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
            patch(
                "tenacity.nap.sleep",
                return_value=None,
            ),
        ):
            with pytest.raises(ProbeError):
                await post_response("e1", response)

        assert mock_client.patch.call_count == 1  # no retries

    async def test_post_response_retries_on_connect_error(self):
        mock_client = AsyncMock()
        attempts = {"count": 0}

        async def flaky_patch(*args, **kwargs):
            attempts["count"] += 1
            if attempts["count"] < 2:
                raise httpx.ConnectError("connect refused")
            return _mock_response({})

        mock_client.patch = AsyncMock(side_effect=flaky_patch)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        response = ProbeHttpSuccessResponse(duration_ms=1, status_code=200)
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
            patch(
                "tenacity.nap.sleep",
                return_value=None,
            ),
        ):
            await post_response("e1", response)

        assert attempts["count"] == 2  # retried connect-phase failure


class TestSchemaDriftHandling:
    """Server returning an item missing a required field must surface as
    ProbeValidationError, not a bare KeyError from deep inside parsing."""

    async def test_list_pending_requests_with_missing_field_raises_validation(self):
        # Item lacks "evaluation_run_id".
        bad_item = {
            "id": "e1",
            "seq": 1,
            "method": "GET",
            "url": "https://target/x",
            "request_headers": {},
        }
        mock_client = _make_async_client(get=_mock_response([bad_item]))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeValidationError) as exc:
                await list_pending_requests("laptop:42")
        assert "evaluation_run_id" in str(exc.value)
        assert "version mismatch" in str(exc.value)

    async def test_claim_with_missing_field_raises_validation(self):
        bad_claim = {"run_id": "r1", "runner_id": "u1"}  # missing evaluation_id
        mock_client = _make_async_client(post=_mock_response(bad_claim))
        with (
            _patches()[0],
            _patches()[1],
            patch(
                "httpx.AsyncClient",
                return_value=mock_client,
            ),
        ):
            with pytest.raises(ProbeValidationError) as exc:
                await claim("eval-1", runner_id="x")
        assert "evaluation_id" in str(exc.value)
