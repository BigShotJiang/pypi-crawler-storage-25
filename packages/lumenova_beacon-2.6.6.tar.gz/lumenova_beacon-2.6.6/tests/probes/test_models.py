"""Unit tests for the SDK probe runner loop (both paths)."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from lumenova_beacon.exceptions import (
    ProbeAuthMissingError,
    ProbeError,
    ProbeRunFailed,
    ProbeValidationError,
)
from lumenova_beacon.probes._http import BuiltInAuth
from lumenova_beacon.probes.models import (
    MAX_DISPATCH_ATTEMPTS,
    MIN_POLL_INTERVAL_SECONDS,
    Probe,
    _BuiltInDispatcher,
    _CallableDispatcher,
    _DispatchOutcome,
    _dispatch_one,
    _invoke_target,
    _normalise_return,
    _validate_builtin_auth,
    _validate_path_choice,
    make_runner_id,
)
from lumenova_beacon.probes.types import (
    AuthSchemeHint,
    ProbeClaimResponse,
    ProbeHttpErrorResponse,
    ProbeHttpRequest,
    ProbeHttpResponse,
    ProbeHttpSuccessResponse,
    ProbeRunStatus,
    RunStatusSnapshot,
    TargetSystemRef,
)


def _claim_resp(
    target_name: str = "orders-api",
    auth_scheme_hint: AuthSchemeHint = AuthSchemeHint.NONE,
    auth_metadata: dict | None = None,
) -> ProbeClaimResponse:
    return ProbeClaimResponse(
        run_id="run-1",
        runner_id="runner",
        evaluation_id="eval-1",
        target_system=TargetSystemRef(
            id="t1",
            name=target_name,
            base_url=None,
            auth_scheme_hint=auth_scheme_hint,
            auth_metadata=auth_metadata or {},
        ),
    )


def _req(seq: int = 1, id: str = "e1") -> ProbeHttpRequest:
    return ProbeHttpRequest(
        id=id,
        evaluation_run_id="run-1",
        seq=seq,
        method="GET",
        url="https://target.example/orders",
    )


def _success(status_code: int = 200) -> ProbeHttpSuccessResponse:
    return ProbeHttpSuccessResponse(
        duration_ms=10,
        status_code=status_code,
        response_headers={},
        response_body="{}",
    )


def _ok_callable(_request: ProbeHttpRequest) -> ProbeHttpSuccessResponse:
    return _success()


class TestMakeRunnerId:
    def test_ends_with_run_id(self):
        runner_id = make_runner_id("eval-abc")
        assert runner_id.endswith(":eval-abc")

    def test_stable_across_calls_for_same_evaluation(self):
        assert make_runner_id("eval-1") == make_runner_id("eval-1")

    def test_differs_across_evaluations(self):
        assert make_runner_id("eval-1") != make_runner_id("eval-2")

    def test_includes_pid_to_disambiguate_concurrent_processes(self):
        import os

        runner_id = make_runner_id("eval-1")
        # Two SDK processes on the same host with the same run_id would
        # otherwise collide on Beacon's idempotent claim and race on PATCH.
        assert f":{os.getpid()}:" in runner_id


class TestArunCallablePath:
    """Path B — user supplies a target_callable."""

    async def test_claim_then_terminal(self):
        terminal = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED)
        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=AsyncMock(return_value=[]),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=terminal),
            ),
        ):
            result = await Probe.arun(
                "eval-1",
                target_callable=_ok_callable,
                poll_interval=0,
            )

        assert result.status is ProbeRunStatus.COMPLETED

    async def test_dispatches_pending_then_terminates(self):
        terminal = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED)
        list_mock = AsyncMock(side_effect=[[_req(1), _req(2, "e2")], []])
        seen: list[ProbeHttpRequest] = []

        def callable_(req):
            seen.append(req)
            return _success()

        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=list_mock,
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=terminal),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.post_response",
                new=AsyncMock(),
            ) as post_resp,
        ):
            await Probe.arun("eval-1", target_callable=callable_, poll_interval=0)

        assert {req.id for req in seen} == {"e1", "e2"}
        assert post_resp.call_count == 2
        assert {call.args[0] for call in post_resp.call_args_list} == {"e1", "e2"}


class TestArunBuiltInPath:
    """Path A — SDK fires HTTP itself, auth from kwargs."""

    async def test_none_scheme_no_auth_kwarg_required(self):
        terminal = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED)
        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(
                    return_value=_claim_resp(auth_scheme_hint=AuthSchemeHint.NONE),
                ),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=AsyncMock(return_value=[]),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=terminal),
            ),
        ):
            result = await Probe.arun("eval-1", poll_interval=0)
        assert result.status is ProbeRunStatus.COMPLETED

    async def test_dispatches_through_builtin_with_headers(self):
        terminal = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED)
        list_mock = AsyncMock(side_effect=[[_req(1)], []])

        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(
                    return_value=_claim_resp(
                        auth_scheme_hint=AuthSchemeHint.CUSTOM_HEADERS,
                        auth_metadata={"headers": [{"name": "X-API-Key"}]},
                    ),
                ),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=list_mock,
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=terminal),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.post_response",
                new=AsyncMock(),
            ) as post_resp,
            patch(
                "lumenova_beacon.probes.models.dispatch_builtin",
                new=AsyncMock(return_value=_success()),
            ) as dispatch,
        ):
            await Probe.arun(
                "eval-1",
                headers={"X-API-Key": "k1"},
                poll_interval=0,
            )

        dispatch.assert_awaited_once()
        post_resp.assert_awaited_once()
        # Auth was threaded into BuiltInAuth, not silently dropped.
        kwargs = dispatch.await_args.kwargs
        assert isinstance(kwargs["auth"], BuiltInAuth)
        assert dict(kwargs["auth"].headers) == {"X-API-Key": "k1"}
        assert kwargs["auth"].bearer_token is None


class TestArunTerminalFailed:
    async def test_failed_run_raises_probe_run_failed(self):
        terminal = RunStatusSnapshot(
            id="run-1",
            status=ProbeRunStatus.FAILED,
            error_message="ProbeSdkTimeout",
        )
        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=AsyncMock(return_value=[]),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=terminal),
            ),
        ):
            with pytest.raises(ProbeRunFailed) as exc:
                await Probe.arun(
                    "eval-1",
                    target_callable=_ok_callable,
                    poll_interval=0,
                )

        assert "ProbeSdkTimeout" in str(exc.value)

    async def test_cancelled_run_returns_normally(self):
        terminal = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.CANCELLED)
        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=AsyncMock(return_value=[]),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=terminal),
            ),
        ):
            result = await Probe.arun(
                "eval-1",
                target_callable=_ok_callable,
                poll_interval=0,
            )
        assert result.status is ProbeRunStatus.CANCELLED


class TestArunTimeout:
    async def test_max_runtime_exceeded_raises(self):
        running = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.RUNNING)
        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=AsyncMock(return_value=[]),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=running),
            ),
        ):
            with pytest.raises(ProbeError) as exc:
                await Probe.arun(
                    "eval-1",
                    target_callable=_ok_callable,
                    poll_interval=0.05,
                    max_runtime_seconds=0.01,
                )
        assert "did not terminate" in str(exc.value)


class TestPollIntervalClamp:
    async def test_negative_clamped_to_minimum(self):
        terminal = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED)
        sleep_calls: list[float] = []

        async def _capture_sleep(seconds):
            sleep_calls.append(seconds)

        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=AsyncMock(side_effect=[[], []]),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(
                    side_effect=[
                        RunStatusSnapshot(id="run-1", status=ProbeRunStatus.RUNNING),
                        terminal,
                    ]
                ),
            ),
            patch(
                "lumenova_beacon.probes.models.asyncio.sleep",
                new=AsyncMock(side_effect=_capture_sleep),
            ),
        ):
            await Probe.arun(
                "eval-1",
                target_callable=_ok_callable,
                poll_interval=-1,
            )

        assert all(s >= MIN_POLL_INTERVAL_SECONDS for s in sleep_calls)


class TestInvokeTarget:
    async def test_sync_callable_returning_success(self):
        def fn(_req):
            return _success(status_code=204)

        result = await _invoke_target(fn, _req())
        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 204

    async def test_async_callable_returning_success(self):
        async def fn(_req):
            return _success(status_code=201)

        result = await _invoke_target(fn, _req())
        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 201

    async def test_callable_raising_becomes_error_response(self):
        def fn(_req):
            raise RuntimeError("boom")

        result = await _invoke_target(fn, _req())
        assert isinstance(result, ProbeHttpErrorResponse)
        assert "RuntimeError" in result.error
        assert "boom" in result.error

    async def test_callable_returning_wrong_type_raises_validation_error(self):
        # Programmer error — callable contract violation must halt the run
        # rather than be silently reported as a target failure.
        def fn(_req):
            return 42

        with pytest.raises(ProbeValidationError) as exc:
            await _invoke_target(fn, _req())
        assert "expected ProbeHttpSuccessResponse" in str(exc.value)
        assert "int" in str(exc.value)

    async def test_sync_callable_returning_coroutine_is_awaited(self):
        # Sync fn that returns a coroutine (decorator-wrapped async fn,
        # `lambda r: helper(r)` where helper is async, etc.) is honoured.
        async def inner(_req):
            return _success(status_code=205)

        def outer(req):
            return inner(req)

        result = await _invoke_target(outer, _req())
        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 205

    def test_normalise_return_rejects_unknown_type(self):
        # Direct unit on the helper — same contract, no try/except wrapping.
        with pytest.raises(ProbeValidationError) as exc:
            _normalise_return({"oops": "dict"}, started=0.0)
        assert "dict" in str(exc.value)

    async def test_callable_returning_str_wraps_as_success(self):
        def fn(_req):
            return "hello from my LLM"

        result = await _invoke_target(fn, _req())
        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 200
        assert result.response_body == "hello from my LLM"

    async def test_callable_returning_httpx_response_converts(self):
        import httpx

        def fn(_req):
            return httpx.Response(
                201,
                headers={"Content-Type": "application/json"},
                text='{"ok": true}',
            )

        result = await _invoke_target(fn, _req())
        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 201
        assert result.response_body == '{"ok": true}'
        assert result.response_headers["content-type"] == "application/json"

    async def test_callable_returning_5xx_httpx_response_is_still_success_kind(self):
        # 5xx is a *reply*, not a transport error — agent decides what it means.
        import httpx

        def fn(_req):
            return httpx.Response(503, text="service unavailable")

        result = await _invoke_target(fn, _req())
        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 503

    async def test_callable_returning_requests_response_converts(self):
        from datetime import timedelta

        from requests.models import Response as RequestsResponse

        def fn(_req):
            r = RequestsResponse()
            r.status_code = 202
            r._content = b'{"queued": true}'
            r.headers["Content-Type"] = "application/json"
            r.elapsed = timedelta(milliseconds=42)
            return r

        result = await _invoke_target(fn, _req())
        assert isinstance(result, ProbeHttpSuccessResponse)
        assert result.status_code == 202
        assert result.response_body == '{"queued": true}'
        assert result.response_headers["Content-Type"] == "application/json"
        assert result.duration_ms == 42


class TestDispatchOne:
    async def test_invokes_callable_dispatcher_then_patches(self):
        with patch(
            "lumenova_beacon.probes.models._beacon_client.post_response",
            new=AsyncMock(),
        ) as post_resp:
            outcome = await _dispatch_one(
                _req(),
                _CallableDispatcher(_ok_callable),
                {},
                {},
                AsyncMock(),
            )

        post_resp.assert_awaited_once()
        assert post_resp.call_args.args[0] == "e1"
        assert outcome is _DispatchOutcome.DISPATCHED

    async def test_patches_even_on_callable_error(self):
        def boom(_req):
            raise RuntimeError("connect refused")

        with patch(
            "lumenova_beacon.probes.models._beacon_client.post_response",
            new=AsyncMock(),
        ) as post_resp:
            outcome = await _dispatch_one(
                _req(),
                _CallableDispatcher(boom),
                {},
                {},
                AsyncMock(),
            )

        post_resp.assert_awaited_once()
        sent_response = post_resp.call_args.args[1]
        assert isinstance(sent_response, ProbeHttpErrorResponse)
        assert "connect refused" in sent_response.error
        assert outcome is _DispatchOutcome.DISPATCHED

    async def test_post_response_failure_is_logged_and_attempt_count_bumped(
        self, caplog
    ):
        import logging

        caplog.set_level(logging.ERROR, logger="lumenova_beacon.probes.models")
        attempts: dict[str, int] = {}
        cache: dict[str, ProbeHttpResponse] = {}

        with patch(
            "lumenova_beacon.probes.models._beacon_client.post_response",
            new=AsyncMock(side_effect=ProbeError("beacon down")),
        ):
            outcome = await _dispatch_one(
                _req(),
                _CallableDispatcher(_ok_callable),
                attempts,
                cache,
                AsyncMock(),
            )

        assert attempts["e1"] == 1
        assert outcome is _DispatchOutcome.PATCH_FAILED
        # Response was cached so a re-poll replays the PATCH without re-firing target.
        assert "e1" in cache
        assert any(
            "failed to report to Beacon" in record.message for record in caplog.records
        )

    async def test_cache_replay_avoids_target_re_dispatch(self, caplog):
        # Critical safety property for non-idempotent targets: when
        # PATCH-back failed previously, the next attempt must NOT re-fire
        # the target — it should replay the cached response.
        import logging

        caplog.set_level(logging.ERROR, logger="lumenova_beacon.probes.models")
        attempts: dict[str, int] = {"e1": 1}
        cached_resp = _success(status_code=201)
        cache: dict[str, ProbeHttpResponse] = {"e1": cached_resp}
        invocations: list = []

        def fn(req):
            invocations.append(req)
            return _success()  # different from cached — proves cache wins

        with patch(
            "lumenova_beacon.probes.models._beacon_client.post_response",
            new=AsyncMock(),
        ) as post_resp:
            outcome = await _dispatch_one(
                _req(),
                _CallableDispatcher(fn),
                attempts,
                cache,
                AsyncMock(),
            )

        assert invocations == []  # target NOT re-fired
        # Cached response — not the new _success — was PATCHed.
        assert post_resp.call_args.args[1] is cached_resp
        assert outcome is _DispatchOutcome.DISPATCHED
        # Cache cleared after successful PATCH.
        assert "e1" not in cache

    async def test_skips_after_max_dispatch_attempts(self, caplog):
        import logging

        caplog.set_level(logging.WARNING, logger="lumenova_beacon.probes.models")
        attempts = {"e1": MAX_DISPATCH_ATTEMPTS}
        invoked: list = []

        def callable_(req):
            invoked.append(req)
            return _success()

        with patch(
            "lumenova_beacon.probes.models._beacon_client.post_response",
            new=AsyncMock(),
        ) as post_resp:
            outcome = await _dispatch_one(
                _req(),
                _CallableDispatcher(callable_),
                attempts,
                {},
                AsyncMock(),
            )

        assert invoked == []
        post_resp.assert_not_awaited()
        assert outcome is _DispatchOutcome.SKIPPED
        assert any("Skipping event" in record.message for record in caplog.records)

    async def test_not_found_marks_event_done(self):
        from lumenova_beacon.exceptions import ProbeNotFoundError

        attempts: dict[str, int] = {}
        cache: dict[str, ProbeHttpResponse] = {"e1": _success()}

        with patch(
            "lumenova_beacon.probes.models._beacon_client.post_response",
            new=AsyncMock(side_effect=ProbeNotFoundError("event terminal")),
        ):
            outcome = await _dispatch_one(
                _req(),
                _CallableDispatcher(_ok_callable),
                attempts,
                cache,
                AsyncMock(),
            )

        assert attempts["e1"] == MAX_DISPATCH_ATTEMPTS
        assert outcome is _DispatchOutcome.SKIPPED
        # Cache cleared on terminal-server-side path.
        assert "e1" not in cache

    async def test_validation_error_propagates(self):
        attempts: dict[str, int] = {}
        with patch(
            "lumenova_beacon.probes.models._beacon_client.post_response",
            new=AsyncMock(side_effect=ProbeValidationError("schema drift")),
        ):
            with pytest.raises(ProbeValidationError):
                await _dispatch_one(
                    _req(),
                    _CallableDispatcher(_ok_callable),
                    attempts,
                    {},
                    AsyncMock(),
                )

    async def test_builtin_dispatcher_threads_through_post_response(self):
        target = TargetSystemRef(
            id="t1",
            name="orders",
            auth_scheme_hint=AuthSchemeHint.CUSTOM_HEADERS,
        )
        dispatcher = _BuiltInDispatcher(
            target=target,
            auth=BuiltInAuth(headers={"X-API-Key": "k1"}),
            base_url=None,
            client=MagicMock(),
        )
        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.post_response",
                new=AsyncMock(),
            ) as post_resp,
            patch(
                "lumenova_beacon.probes.models.dispatch_builtin",
                new=AsyncMock(return_value=_success(status_code=204)),
            ) as dispatch,
        ):
            outcome = await _dispatch_one(_req(), dispatcher, {}, {}, AsyncMock())

        dispatch.assert_awaited_once()
        post_resp.assert_awaited_once()
        assert post_resp.call_args.args[1].status_code == 204
        assert outcome is _DispatchOutcome.DISPATCHED


class TestValidatePathChoice:
    def test_callable_alone_is_ok(self):
        _validate_path_choice(_ok_callable, None, None, None)

    def test_headers_alone_is_ok(self):
        _validate_path_choice(None, {"X-API-Key": "k1"}, None, None)

    def test_bearer_alone_is_ok(self):
        _validate_path_choice(None, None, "t1", None)

    def test_base_url_alone_is_ok(self):
        # Path A with auth_scheme=none + URL override: callable=None,
        # auth kwargs=None, base_url present.
        _validate_path_choice(None, None, None, "http://localhost:8005")

    def test_headers_plus_base_url_is_ok(self):
        _validate_path_choice(
            None,
            {"X-API-Key": "k1"},
            None,
            "http://localhost:8005",
        )

    def test_neither_is_ok(self):
        # Path A with auth_scheme=none and no override.
        _validate_path_choice(None, None, None, None)

    def test_callable_with_headers_is_rejected(self):
        with pytest.raises(ProbeError) as exc:
            _validate_path_choice(_ok_callable, {"X-API-Key": "k1"}, None, None)
        assert "Not both" in str(exc.value)

    def test_callable_with_bearer_token_is_rejected(self):
        with pytest.raises(ProbeError) as exc:
            _validate_path_choice(_ok_callable, None, "t1", None)
        assert "Not both" in str(exc.value)

    def test_callable_with_base_url_is_rejected(self):
        with pytest.raises(ProbeError) as exc:
            _validate_path_choice(_ok_callable, None, None, "http://localhost:8005")
        assert "Not both" in str(exc.value)


class TestValidateBuiltinAuth:
    def _target(
        self,
        scheme: AuthSchemeHint,
        *,
        auth_metadata: dict | None = None,
    ) -> TargetSystemRef:
        return TargetSystemRef(
            id="t1",
            name="orders",
            auth_scheme_hint=scheme,
            auth_metadata=auth_metadata or {},
        )

    def test_none_scheme_no_kwargs_is_ok(self):
        _validate_builtin_auth(self._target(AuthSchemeHint.NONE), None, None)

    def test_none_scheme_with_kwarg_rejected(self):
        with pytest.raises(ProbeError) as exc:
            _validate_builtin_auth(
                self._target(AuthSchemeHint.NONE),
                {"X-API-Key": "k1"},
                None,
            )
        assert "auth_scheme_hint='none'" in str(exc.value)

    def test_custom_headers_scheme_with_headers_is_ok(self):
        target = self._target(
            AuthSchemeHint.CUSTOM_HEADERS,
            auth_metadata={"headers": [{"name": "X-API-Key"}]},
        )
        _validate_builtin_auth(target, {"X-API-Key": "k1"}, None)

    def test_custom_headers_scheme_missing_kwarg_raises_auth_missing(self):
        target = self._target(
            AuthSchemeHint.CUSTOM_HEADERS,
            auth_metadata={"headers": [{"name": "X-API-Key"}]},
        )
        with pytest.raises(ProbeAuthMissingError) as exc:
            _validate_builtin_auth(target, None, None)
        msg = str(exc.value)
        assert "headers=" in msg
        assert "orders" in msg
        assert "target_callable" in msg

    def test_custom_headers_scheme_missing_one_raises(self):
        target = self._target(
            AuthSchemeHint.CUSTOM_HEADERS,
            auth_metadata={
                "headers": [{"name": "X-API-Key"}, {"name": "X-Tenant-Id"}],
            },
        )
        with pytest.raises(ProbeAuthMissingError) as exc:
            _validate_builtin_auth(target, {"X-API-Key": "k1"}, None)
        assert "X-Tenant-Id" in str(exc.value)

    def test_custom_headers_case_insensitive_match(self):
        target = self._target(
            AuthSchemeHint.CUSTOM_HEADERS,
            auth_metadata={"headers": [{"name": "X-API-Key"}]},
        )
        # User passes lowercase — should still satisfy the requirement.
        _validate_builtin_auth(target, {"x-api-key": "k1"}, None)

    def test_custom_headers_scheme_with_bearer_kwarg_rejected(self):
        target = self._target(
            AuthSchemeHint.CUSTOM_HEADERS,
            auth_metadata={"headers": [{"name": "X-API-Key"}]},
        )
        with pytest.raises(ProbeError) as exc:
            _validate_builtin_auth(target, None, "t1")
        assert "drop bearer_token" in str(exc.value)

    def test_bearer_scheme_with_token_is_ok(self):
        _validate_builtin_auth(
            self._target(AuthSchemeHint.BEARER),
            None,
            "t1",
        )

    def test_bearer_scheme_missing_kwarg_raises_auth_missing(self):
        with pytest.raises(ProbeAuthMissingError) as exc:
            _validate_builtin_auth(self._target(AuthSchemeHint.BEARER), None, None)
        assert "bearer_token=" in str(exc.value)

    def test_bearer_scheme_with_headers_rejected(self):
        with pytest.raises(ProbeError) as exc:
            _validate_builtin_auth(
                self._target(AuthSchemeHint.BEARER),
                {"X-API-Key": "k1"},
                None,
            )
        assert "drop headers" in str(exc.value)


class TestArunRejectsConflictingKwargs:
    async def test_callable_plus_headers_raises_immediately(self):
        # Should fail before the claim — i.e. without any Beacon HTTP.
        with pytest.raises(ProbeError) as exc:
            await Probe.arun(
                "eval-1",
                target_callable=_ok_callable,
                headers={"X-API-Key": "k1"},
            )
        assert "Not both" in str(exc.value)


class TestArunValidatesAuthAfterClaim:
    async def test_missing_headers_for_custom_headers_scheme_raises(self):
        with patch(
            "lumenova_beacon.probes.models._beacon_client.claim",
            new=AsyncMock(
                return_value=_claim_resp(
                    auth_scheme_hint=AuthSchemeHint.CUSTOM_HEADERS,
                    auth_metadata={"headers": [{"name": "X-API-Key"}]},
                ),
            ),
        ):
            with pytest.raises(ProbeAuthMissingError) as exc:
                await Probe.arun("eval-1", poll_interval=0)
        assert "headers=" in str(exc.value)


class TestValidateBuiltinAuthExhaustiveness:
    """A future AuthSchemeHint added without a branch in
    ``_validate_builtin_auth`` must surface the SDK gap, not silently
    let dispatch proceed without auth."""

    def test_unknown_scheme_raises_probe_error(self):
        from enum import Enum

        class FutureScheme(str, Enum):
            OAUTH2 = "oauth2"

        target = MagicMock()
        target.name = "future-target"
        target.auth_scheme_hint = FutureScheme.OAUTH2

        with pytest.raises(ProbeError) as exc:
            _validate_builtin_auth(target, None, None)
        assert "Unhandled auth_scheme_hint" in str(exc.value)


class TestRunLoopGatherIsolation:
    """One bad event in a batch must not cancel siblings mid-flight —
    otherwise their PATCH-backs never happen and the agent re-dispatches
    them on the next poll, multiplying side effects on the user's target."""

    async def test_one_failing_dispatch_does_not_kill_siblings(self):
        terminal = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED)
        list_mock = AsyncMock(
            side_effect=[
                [_req(1, "ok-1"), _req(2, "boom"), _req(3, "ok-2")],
                [],
            ]
        )

        post_calls: list[str] = []

        async def fake_post_response(event_id, response, *, client):
            post_calls.append(event_id)

        def callable_(req):
            if req.id == "boom":
                raise RuntimeError("target exploded")
            return _success()

        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=list_mock,
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=terminal),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.post_response",
                new=fake_post_response,
            ),
        ):
            await Probe.arun("eval-1", target_callable=callable_, poll_interval=0)

        # All three events were PATCHed back — boom posted an ERROR-kind
        # response (callable raised, which _invoke_target catches), and the
        # two siblings completed normally.
        assert set(post_calls) == {"ok-1", "boom", "ok-2"}


class TestRunLoopAttemptCap:
    """Under permanent PATCH-back failures, the loop must give up on the
    failing event after MAX_DISPATCH_ATTEMPTS rather than re-hitting the
    user's target on every poll cycle."""

    async def test_target_hit_only_once_under_permanent_patch_failure(self):
        """With the response cache, the user's target is hit exactly once
        per event, even when PATCH-back fails repeatedly. The attempt
        cap bounds PATCH retries; the cache prevents target re-dispatch
        between retries — critical for non-idempotent targets like POST
        /charge or /transfer."""

        invocations: list[str] = []

        def callable_(req):
            invocations.append(req.id)
            return _success()

        # Pending always returns [stuck] for many polls; eventually
        # returns [] so refresh can terminate the run. Generously
        # over-provisioned so the loop doesn't run out of mock data
        # while exercising both PATCH_FAILED and SKIPPED paths.
        list_results: list[list[ProbeHttpRequest]] = [[_req(1, "stuck")]] * (
            MAX_DISPATCH_ATTEMPTS + 3
        ) + [[]] * 20
        statuses = [
            RunStatusSnapshot(id="run-1", status=ProbeRunStatus.RUNNING)
        ] * 3 + [RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED)]

        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=AsyncMock(side_effect=list_results),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(side_effect=statuses),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.post_response",
                new=AsyncMock(side_effect=ProbeError("beacon down")),
            ),
        ):
            await Probe.arun("eval-1", target_callable=callable_, poll_interval=0)

        # Target is hit exactly once per event despite the event appearing
        # in many pending lists — the response cache replays the PATCH
        # without re-firing the callable.
        assert invocations == ["stuck"]


class TestRunLoopBackoff:
    """When no event makes progress in a poll cycle (all SKIPPED or
    PATCH_FAILED), the loop must sleep before re-polling — otherwise it
    tight-spins against Beacon while orphaned events persist
    server-side."""

    async def test_loop_sleeps_when_all_dispatches_fail(self):
        sleep_calls: list[float] = []

        async def fake_sleep(seconds):
            sleep_calls.append(seconds)

        list_results: list[list[ProbeHttpRequest]] = [[_req(1)]] * 2 + [[]] * 10
        statuses = [
            RunStatusSnapshot(id="run-1", status=ProbeRunStatus.RUNNING),
            RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED),
        ]

        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=AsyncMock(side_effect=list_results),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(side_effect=statuses),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.post_response",
                new=AsyncMock(side_effect=ProbeError("beacon down")),
            ),
            patch(
                "lumenova_beacon.probes.models.asyncio.sleep",
                new=AsyncMock(side_effect=fake_sleep),
            ),
        ):
            await Probe.arun("eval-1", target_callable=_ok_callable, poll_interval=0)

        # At least one sleep happened before the PATCH-failed poll
        # advanced — the back-off path was taken.
        assert len(sleep_calls) >= 2


class TestRunLoopBaseExceptionPropagation:
    """KeyboardInterrupt / asyncio.CancelledError class exceptions
    (BaseException subclasses, not Exception) must propagate out of the
    runner loop rather than being swallowed by gather's capture. This
    guards Ctrl-C and process-shutdown paths."""

    async def test_cancelled_error_propagates_from_dispatch(self):
        async def my_target(_req):
            raise asyncio.CancelledError("user pressed Ctrl-C")

        list_mock = AsyncMock(side_effect=[[_req(1)], []])
        terminal = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED)

        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=list_mock,
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=terminal),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.post_response",
                new=AsyncMock(),
            ),
        ):
            with pytest.raises(asyncio.CancelledError):
                await Probe.arun(
                    "eval-1",
                    target_callable=my_target,
                    poll_interval=0,
                )


class TestRunLoopUnexpectedException:
    """An exception escaping _dispatch_one indicates a bug; the loop
    should log it loudly and continue so one bad event doesn't kill the
    whole run, but the failure is visible in the logs."""

    async def test_unexpected_exception_logged_and_run_continues(self, caplog):
        import logging

        caplog.set_level(logging.ERROR, logger="lumenova_beacon.probes.models")

        list_mock = AsyncMock(side_effect=[[_req(1)], []])
        terminal = RunStatusSnapshot(id="run-1", status=ProbeRunStatus.COMPLETED)

        # KeyError from post_response isn't in _dispatch_one's catch
        # list (httpx.HTTPError, ProbeError, ProbeNotFoundError,
        # ProbeValidationError) so it escapes the function.
        with (
            patch(
                "lumenova_beacon.probes.models._beacon_client.claim",
                new=AsyncMock(return_value=_claim_resp()),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.list_pending_requests",
                new=list_mock,
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.refresh_run",
                new=AsyncMock(return_value=terminal),
            ),
            patch(
                "lumenova_beacon.probes.models._beacon_client.post_response",
                new=AsyncMock(side_effect=KeyError("unexpected")),
            ),
        ):
            result = await Probe.arun(
                "eval-1",
                target_callable=_ok_callable,
                poll_interval=0,
            )

        assert result.status is ProbeRunStatus.COMPLETED
        assert any(
            "Unexpected exception escaped probe dispatch" in r.message
            for r in caplog.records
        )
