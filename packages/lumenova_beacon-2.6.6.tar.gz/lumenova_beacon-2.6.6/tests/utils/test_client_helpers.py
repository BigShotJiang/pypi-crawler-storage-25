"""Tests for lumenova_beacon.utils.client_helpers.resolve_user_attr."""

import pytest

from lumenova_beacon.utils.client_helpers import resolve_user_attr


class TestResolveUserAttr:
    def test_explicit_wins_over_config_and_metadata(self):
        result = resolve_user_attr("explicit", "config", {"user_email": "meta"}, "user_email")
        assert result == "explicit"

    def test_config_wins_over_metadata(self):
        result = resolve_user_attr(None, "config", {"user_email": "meta"}, "user_email")
        assert result == "config"

    def test_metadata_fallback(self):
        result = resolve_user_attr(None, None, {"user_email": "meta"}, "user_email")
        assert result == "meta"

    def test_all_none(self):
        result = resolve_user_attr(None, None, None, "user_email")
        assert result is None

    def test_empty_metadata(self):
        result = resolve_user_attr(None, None, {}, "user_email")
        assert result is None

    def test_metadata_missing_key(self):
        result = resolve_user_attr(None, None, {"other_key": "val"}, "user_email")
        assert result is None

    def test_metadata_none_value(self):
        result = resolve_user_attr(None, None, {"user_email": None}, "user_email")
        assert result is None

    @pytest.mark.parametrize("key", ["user_email", "user_name", "user_id"])
    def test_all_user_attr_keys(self, key):
        result = resolve_user_attr(None, None, {key: f"from-meta-{key}"}, key)
        assert result == f"from-meta-{key}"
