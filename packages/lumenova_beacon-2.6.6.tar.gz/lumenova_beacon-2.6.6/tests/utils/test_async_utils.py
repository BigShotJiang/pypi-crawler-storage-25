"""Tests for run_sync utility."""

from __future__ import annotations

import asyncio

import pytest

from lumenova_beacon.utils.async_utils import run_sync


class TestRunSync:
    """Test run_sync handles both event-loop scenarios."""

    def test_basic_coroutine(self):
        """run_sync executes a coroutine when no event loop is running."""

        async def add(a: int, b: int) -> int:
            return a + b

        assert run_sync(add(2, 3)) == 5

    def test_error_propagation(self):
        """Exceptions from the coroutine propagate through run_sync."""

        async def fail():
            raise ValueError("boom")

        with pytest.raises(ValueError, match="boom"):
            run_sync(fail())

    def test_nested_loop(self):
        """run_sync works when called from inside a running event loop."""

        async def outer():
            async def inner():
                return 42

            # Calling run_sync from inside a running loop
            # should use the ThreadPoolExecutor fallback
            return run_sync(inner())

        result = asyncio.run(outer())
        assert result == 42

    def test_nested_loop_error_propagation(self):
        """Errors propagate correctly through the ThreadPoolExecutor path."""

        async def outer():
            async def inner():
                raise RuntimeError("nested fail")

            return run_sync(inner())

        with pytest.raises(RuntimeError, match="nested fail"):
            asyncio.run(outer())
