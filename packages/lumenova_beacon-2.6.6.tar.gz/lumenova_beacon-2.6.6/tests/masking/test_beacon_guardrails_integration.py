"""Tests for ``create_beacon_masking_function``'s error-handling boundary.

The factory previously swallowed every exception (including
``ConfigurationError`` and ``MaskingValidationError``) and returned the
**unmasked** value. That meant a misconfigured ``verify=/wrong/ca.pem`` or a
deliberate server-side validation rejection silently emitted unredacted PII.

The narrowed catch must:
- propagate ``ConfigurationError`` (config mistakes — silent fallback would
  defeat the entire masking guarantee);
- propagate ``MaskingValidationError`` / ``MaskingNotFoundError`` (API said
  "no" — the operator needs to see it);
- swallow ONLY transient transport errors (``httpx.RequestError``), returning
  the original value so telemetry doesn't block on a momentary network blip.
"""

from __future__ import annotations

import logging

from unittest.mock import MagicMock, patch

import httpx
import pytest

from lumenova_beacon.exceptions import (
    ConfigurationError,
    MaskingAPIError,
    MaskingNotFoundError,
    MaskingValidationError,
)
from lumenova_beacon.masking.integrations.beacon_guardrails import (
    create_beacon_masking_function,
)
from lumenova_beacon.masking.types import MaskingMode, PIIType


def _make_request_error_response(status: int) -> MagicMock:
    """Construct a fake httpx.HTTPStatusError carrying the given status."""
    response = MagicMock(spec=httpx.Response)
    response.status_code = status
    response.text = "stub"
    response.json = MagicMock(return_value={"detail": "stub"})
    request = MagicMock(spec=httpx.Request)
    return httpx.HTTPStatusError("err", request=request, response=response)


class TestNarrowedExceptionCatch:
    def _patched_mask_text(self, exception):
        """Patch BeaconGuardrailsClient.mask_text to raise the given exception."""
        return patch(
            "lumenova_beacon.masking.integrations.beacon_guardrails."
            "BeaconGuardrailsClient.mask_text",
            side_effect=exception,
        )

    def test_transient_network_error_returns_unmasked_with_log(self, caplog):
        """A wrapped httpx.RequestError must be the ONLY swallowed case."""
        network_error = httpx.ConnectError("connection refused")
        masking_api_error = MaskingAPIError("transient")
        masking_api_error.__cause__ = network_error

        fn = create_beacon_masking_function(
            pii_types=[PIIType.EMAIL_ADDRESS],
            mode=MaskingMode.REDACT,
        )

        with self._patched_mask_text(masking_api_error):
            with caplog.at_level(
                logging.WARNING,
                logger="lumenova_beacon.masking.integrations.beacon_guardrails",
            ):
                result = fn("alice@example.com")

        assert result == "alice@example.com"
        assert any("transient network error" in r.message for r in caplog.records)

    def test_validation_error_propagates(self):
        """The API rejected the request — silently dropping it would emit
        unmasked PII. The user must see the failure."""
        validation_error = MaskingValidationError("invalid payload")
        validation_error.__cause__ = _make_request_error_response(422)

        fn = create_beacon_masking_function(
            pii_types=[PIIType.EMAIL_ADDRESS],
            mode=MaskingMode.REDACT,
        )

        with self._patched_mask_text(validation_error):
            with pytest.raises(MaskingValidationError):
                fn("alice@example.com")

    def test_not_found_error_propagates(self):
        not_found = MaskingNotFoundError("not found")
        not_found.__cause__ = _make_request_error_response(404)

        fn = create_beacon_masking_function(pii_types=[PIIType.EMAIL_ADDRESS])

        with self._patched_mask_text(not_found):
            with pytest.raises(MaskingNotFoundError):
                fn("alice@example.com")

    def test_masking_api_error_with_http_cause_propagates(self):
        """Generic MaskingAPIError with an HTTPStatusError cause is a server
        failure (5xx); it must propagate, not silently emit PII."""
        api_error = MaskingAPIError("server error")
        api_error.__cause__ = _make_request_error_response(500)

        fn = create_beacon_masking_function(pii_types=[PIIType.EMAIL_ADDRESS])

        with self._patched_mask_text(api_error):
            with pytest.raises(MaskingAPIError):
                fn("alice@example.com")

    def test_configuration_error_propagates(self):
        """ConfigurationError from transport setup (e.g. bad CA path) must NOT
        be swallowed — letting it through would emit unmasked PII for the rest
        of the process lifetime."""
        config_error = ConfigurationError("verify CA bundle path does not exist")

        fn = create_beacon_masking_function(pii_types=[PIIType.EMAIL_ADDRESS])

        with self._patched_mask_text(config_error):
            with pytest.raises(ConfigurationError):
                fn("alice@example.com")
