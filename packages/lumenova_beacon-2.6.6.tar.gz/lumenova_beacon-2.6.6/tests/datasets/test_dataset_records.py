"""Tests for Dataset records, _update_from_response, and acreate payload."""

from __future__ import annotations

from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from lumenova_beacon.datasets.models import Dataset, DatasetRecord
from lumenova_beacon.exceptions import DatasetError, DatasetValidationError


def _make_saved_dataset(**overrides) -> Dataset:
    """Create a Dataset instance that appears already saved (not _is_new)."""
    defaults = {
        "name": "test-dataset",
        "description": "Test",
        "id": "ds-123",
    }
    defaults.update(overrides)
    ds = Dataset.__new__(Dataset)
    ds.id = defaults["id"]
    ds.name = defaults["name"]
    ds.description = defaults["description"]
    ds._is_new = False
    return ds


def _mock_transport():
    t = MagicMock()
    t.verify = True
    t.headers = {"Authorization": "Bearer test"}
    t.timeout = 30
    return t


class TestBulkDeleteRecords:
    """Test Dataset.abulk_delete_records / bulk_delete_records."""

    @pytest.mark.asyncio
    async def test_abulk_delete_records_success(self):
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 204
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        ds = _make_saved_dataset()
        record_ids = ["rec-1", "rec-2", "rec-3"]

        with patch("lumenova_beacon.datasets.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.datasets.models.get_transport", return_value=_mock_transport()), \
             patch("lumenova_beacon.datasets.models.httpx.AsyncClient", return_value=mock_client):
            await ds.abulk_delete_records(record_ids)

        mock_client.post.assert_called_once()
        call_args = mock_client.post.call_args
        assert "/api/v1/datasets/ds-123/records/bulk-delete" in call_args.args[0]
        assert call_args.kwargs["json"] == {"record_ids": ["rec-1", "rec-2", "rec-3"]}

    @pytest.mark.asyncio
    async def test_abulk_delete_records_empty_record_ids_raises(self):
        ds = _make_saved_dataset()
        with pytest.raises(DatasetValidationError, match="record_ids must not be empty"):
            await ds.abulk_delete_records([])

    @pytest.mark.asyncio
    async def test_abulk_delete_records_unsaved_dataset_raises(self):
        ds = Dataset.__new__(Dataset)
        ds._is_new = True

        with pytest.raises(DatasetError, match="hasn't been saved yet"):
            await ds.abulk_delete_records(["rec-1"])

    @pytest.mark.asyncio
    async def test_abulk_delete_records_http_error(self):
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_response.text = '{"detail": "Not found"}'

        error = httpx.HTTPStatusError(
            "Not found", request=MagicMock(spec=httpx.Request), response=mock_response,
        )
        mock_response.raise_for_status.side_effect = error

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        ds = _make_saved_dataset()

        with patch("lumenova_beacon.datasets.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.datasets.models.get_transport", return_value=_mock_transport()), \
             patch("lumenova_beacon.datasets.models.httpx.AsyncClient", return_value=mock_client):
            with pytest.raises(Exception):
                await ds.abulk_delete_records(["rec-1"])

    @pytest.mark.asyncio
    async def test_abulk_delete_records_network_error(self):
        mock_client = AsyncMock()
        mock_client.post.side_effect = httpx.ConnectError("connection refused")
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        ds = _make_saved_dataset()

        with patch("lumenova_beacon.datasets.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.datasets.models.get_transport", return_value=_mock_transport()), \
             patch("lumenova_beacon.datasets.models.httpx.AsyncClient", return_value=mock_client):
            with pytest.raises(DatasetError, match="Failed to bulk delete"):
                await ds.abulk_delete_records(["rec-1"])


class TestDatasetRecordSearch:
    """Test that the search parameter is correctly passed through to the HTTP request."""

    @pytest.mark.asyncio
    async def test_alist_passes_search_param(self):
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "records": [
                {
                    "id": "rec-1",
                    "dataset_id": "ds-123",
                    "data": {"prompt": "matching result"},
                    "created_at": "2025-01-01T00:00:00Z",
                    "updated_at": "2025-01-01T00:00:00Z",
                }
            ],
            "total": 1,
            "page": 1,
            "page_size": 50,
            "total_pages": 1,
        }

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("lumenova_beacon.datasets.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.datasets.models.get_transport", return_value=_mock_transport()), \
             patch("lumenova_beacon.datasets.models.httpx.AsyncClient", return_value=mock_client):
            records, pagination = await DatasetRecord.alist(
                dataset_id="ds-123", search="matching",
            )

        mock_client.get.assert_called_once()
        call_kwargs = mock_client.get.call_args.kwargs
        assert call_kwargs["params"]["search"] == "matching"
        assert len(records) == 1
        assert pagination.total == 1

    @pytest.mark.asyncio
    async def test_alist_omits_search_when_none(self):
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "records": [],
            "total": 0,
            "page": 1,
            "page_size": 50,
            "total_pages": 0,
        }

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("lumenova_beacon.datasets.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.datasets.models.get_transport", return_value=_mock_transport()), \
             patch("lumenova_beacon.datasets.models.httpx.AsyncClient", return_value=mock_client):
            await DatasetRecord.alist(dataset_id="ds-123")

        call_kwargs = mock_client.get.call_args.kwargs
        assert "search" not in call_kwargs["params"]

    @pytest.mark.asyncio
    async def test_dataset_alist_records_delegates_search(self):
        """Test that Dataset.alist_records passes search to DatasetRecord.alist."""
        ds = _make_saved_dataset()

        with patch.object(DatasetRecord, "alist", new_callable=AsyncMock) as mock_alist:
            mock_alist.return_value = ([], MagicMock())
            await ds.alist_records(search="test query")

        mock_alist.assert_called_once_with(
            dataset_id="ds-123", page=1, page_size=50, search="test query",
        )

    @pytest.mark.asyncio
    async def test_dataset_alist_with_empty_string_search_sends_param(self):
        """Regression: search='' should be included in params, not omitted."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "datasets": [],
            "total": 0,
            "page": 1,
            "page_size": 20,
            "total_pages": 0,
        }

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("lumenova_beacon.datasets.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.datasets.models.get_transport", return_value=_mock_transport()), \
             patch("lumenova_beacon.datasets.models.httpx.AsyncClient", return_value=mock_client):
            await Dataset.alist(search="")

        call_kwargs = mock_client.get.call_args.kwargs
        assert "search" in call_kwargs["params"]


class TestDatasetUpdateFromResponse:
    """Test Dataset._update_from_response populates all new fields."""

    def test_all_new_fields_populated(self):
        ds = _make_saved_dataset()
        data = {
            "id": "ds-123",
            "name": "updated",
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-06-01T12:00:00Z",
            "record_count": 42,
            "column_schema": [{"name": "col1"}],
            "project_id": "proj-1",
            "source_dataset_id": "ds-src",
            "version_number": 3,
            "root_dataset_id": "ds-root",
            "commit_message": "v3",
            "is_current": True,
            "category": "evaluation",
            "metadata": {"key": "value"},
            "source_type": "remote",
            "source_integration_id": "int-1",
            "source_query": "SELECT *",
            "source_connector_type": "snowflake",
            "import_status": "completed",
            "import_error": None,
            "import_progress": 100,
            "import_total": 100,
            "import_started_at": "2025-06-01T10:00:00Z",
        }
        ds._update_from_response(data)

        assert ds.name == "updated"
        assert ds.record_count == 42
        assert ds.category == "evaluation"
        assert ds.metadata == {"key": "value"}
        assert ds.source_type == "remote"
        assert ds.source_integration_id == "int-1"
        assert ds.source_query == "SELECT *"
        assert ds.source_connector_type == "snowflake"
        assert ds.import_status == "completed"
        assert ds.import_error is None
        assert ds.import_progress == 100
        assert ds.import_total == 100
        assert isinstance(ds.import_started_at, datetime)

    def test_missing_optional_fields_default_to_none(self):
        ds = _make_saved_dataset()
        data = {
            "id": "ds-123",
            "name": "minimal",
            "created_at": "2025-01-01T00:00:00Z",
        }
        ds._update_from_response(data)

        assert ds.category is None
        assert ds.metadata is None
        assert ds.source_type is None
        assert ds.import_status is None
        assert ds.import_started_at is None


class TestDatasetCreatePayload:
    """Test Dataset._acreate sends category and metadata in the payload."""

    @pytest.mark.asyncio
    async def test_acreate_includes_category_and_metadata(self):
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 201
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "id": "ds-new",
            "name": "test",
            "created_at": "2025-01-01T00:00:00Z",
        }

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        ds = Dataset(name="test", category="evaluation", metadata={"env": "prod"})

        with patch("lumenova_beacon.datasets.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.datasets.models.get_transport", return_value=_mock_transport()), \
             patch("lumenova_beacon.datasets.models.httpx.AsyncClient", return_value=mock_client):
            await ds.asave()

        payload = mock_client.post.call_args.kwargs["json"]
        assert payload["category"] == "evaluation"
        assert payload["metadata"] == {"env": "prod"}

    @pytest.mark.asyncio
    async def test_acreate_omits_category_and_metadata_when_none(self):
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 201
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "id": "ds-new",
            "name": "test",
            "created_at": "2025-01-01T00:00:00Z",
        }

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        ds = Dataset(name="test")

        with patch("lumenova_beacon.datasets.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.datasets.models.get_transport", return_value=_mock_transport()), \
             patch("lumenova_beacon.datasets.models.httpx.AsyncClient", return_value=mock_client):
            await ds.asave()

        payload = mock_client.post.call_args.kwargs["json"]
        assert "category" not in payload
        assert "metadata" not in payload
