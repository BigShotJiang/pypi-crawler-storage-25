"""Tests for PromptVersion._from_dict and Prompt.list_versions."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from lumenova_beacon.prompts.types import PromptType, PromptVersion


class TestPromptTypeFromApiId:
    """Test PromptType.from_api_id resolves correctly."""

    def test_text_from_api_id(self):
        assert PromptType.from_api_id(1) == PromptType.TEXT

    def test_chat_from_api_id(self):
        assert PromptType.from_api_id(2) == PromptType.CHAT

    def test_invalid_api_id_raises(self):
        with pytest.raises(ValueError, match="Unknown prompt type API ID: 99"):
            PromptType.from_api_id(99)


class TestPromptVersionFromDict:
    """Test PromptVersion._from_dict handles snake_case, camelCase, and falsy values."""

    def test_snake_case_fields(self):
        data = {
            "id": "v-1",
            "prompt_id": "p-1",
            "version": 3,
            "content": {"template": "hello"},
            "commit_message": "initial",
            "created_at": "2025-01-01T00:00:00Z",
            "usage_count": 10,
        }
        v = PromptVersion._from_dict(data)
        assert v.id == "v-1"
        assert v.prompt_id == "p-1"
        assert v.version == 3
        assert v.content == {"template": "hello"}
        assert v.commit_message == "initial"
        assert v.created_at == datetime(2025, 1, 1, tzinfo=timezone.utc)
        assert v.usage_count == 10

    def test_usage_count_zero_not_treated_as_missing(self):
        """Regression: usage_count=0 must not fall through to camelCase fallback."""
        data = {
            "id": "v-3",
            "prompt_id": "p-3",
            "version": 1,
            "usage_count": 0,
        }
        v = PromptVersion._from_dict(data)
        assert v.usage_count == 0

    def test_empty_string_prompt_id_not_treated_as_missing(self):
        """Regression: prompt_id='' must not fall through to camelCase fallback."""
        data = {
            "id": "v-4",
            "prompt_id": "",
            "version": 1,
        }
        v = PromptVersion._from_dict(data)
        assert v.prompt_id == ""

    def test_empty_string_created_at_parsed_as_none(self):
        """Empty created_at string is parsed as None by parse_iso_datetime."""
        data = {
            "id": "v-5",
            "prompt_id": "p-5",
            "version": 1,
            "created_at": "",
        }
        v = PromptVersion._from_dict(data)
        assert v.created_at is None

    def test_commit_message_none(self):
        data = {
            "id": "v-6",
            "prompt_id": "p-6",
            "version": 1,
        }
        v = PromptVersion._from_dict(data)
        assert v.commit_message is None

    def test_defaults_when_optional_fields_absent(self):
        data = {
            "id": "v-7",
            "version": 2,
        }
        v = PromptVersion._from_dict(data)
        assert v.prompt_id == ""
        assert v.content == {}
        assert v.commit_message is None
        assert v.created_at is None
        assert v.usage_count == 0


class TestPromptListVersions:
    """Test Prompt.alist_versions / list_versions HTTP integration."""

    @pytest.mark.asyncio
    async def test_alist_versions_success(self):
        from lumenova_beacon.prompts.models import Prompt

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = [
            {
                "id": "v-1",
                "prompt_id": "p-1",
                "version": 2,
                "content": {"template": "hi"},
                "commit_message": "update",
                "created_at": "2025-01-01T00:00:00Z",
                "usage_count": 3,
            },
            {
                "id": "v-2",
                "prompt_id": "p-1",
                "version": 1,
                "content": {"template": "hello"},
                "commit_message": "initial",
                "created_at": "2024-12-01T00:00:00Z",
                "usage_count": 10,
            },
        ]
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = AsyncMock()
        mock_client_instance.get.return_value = mock_response
        mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
        mock_client_instance.__aexit__ = AsyncMock(return_value=False)

        prompt = Prompt.__new__(Prompt)
        prompt.id = "p-1"

        with patch("lumenova_beacon.prompts.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.prompts.models.get_transport") as mock_transport, \
             patch("lumenova_beacon.prompts.models.httpx.AsyncClient", return_value=mock_client_instance):
            mock_t = MagicMock()
            mock_t.verify = True
            mock_t.headers = {"Authorization": "Bearer test"}
            mock_t.timeout = 30
            mock_transport.return_value = mock_t

            versions = await prompt.alist_versions()

        assert len(versions) == 2
        assert versions[0].id == "v-1"
        assert versions[0].version == 2
        assert versions[1].usage_count == 10

        mock_client_instance.get.assert_called_once()
        call_url = mock_client_instance.get.call_args.args[0]
        assert "/api/v1/prompts/p-1/versions/" in call_url

    @pytest.mark.asyncio
    async def test_alist_versions_http_error(self):
        from lumenova_beacon.prompts.models import Prompt
        from lumenova_beacon.exceptions import PromptNotFoundError

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_response.text = '{"detail": "Not found"}'

        error = httpx.HTTPStatusError(
            "Not found", request=MagicMock(spec=httpx.Request), response=mock_response,
        )

        mock_client_instance = AsyncMock()
        mock_client_instance.get.return_value = mock_response
        mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
        mock_client_instance.__aexit__ = AsyncMock(return_value=False)
        mock_response.raise_for_status.side_effect = error

        prompt = Prompt.__new__(Prompt)
        prompt.id = "p-missing"

        with patch("lumenova_beacon.prompts.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.prompts.models.get_transport") as mock_transport, \
             patch("lumenova_beacon.prompts.models.httpx.AsyncClient", return_value=mock_client_instance):
            mock_t = MagicMock()
            mock_t.verify = True
            mock_t.headers = {}
            mock_t.timeout = 30
            mock_transport.return_value = mock_t

            with pytest.raises(PromptNotFoundError):
                await prompt.alist_versions()


class TestPromptListWithType:
    """Test Prompt.alist sends prompt_type filter correctly."""

    @pytest.mark.asyncio
    async def test_alist_with_prompt_type_chat(self):
        from lumenova_beacon.prompts.models import Prompt
        from lumenova_beacon.prompts.types import PromptType

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": [], "total": 0}
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = AsyncMock()
        mock_client_instance.get.return_value = mock_response
        mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
        mock_client_instance.__aexit__ = AsyncMock(return_value=False)

        with patch("lumenova_beacon.prompts.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.prompts.models.get_transport") as mock_transport, \
             patch("lumenova_beacon.prompts.models.httpx.AsyncClient", return_value=mock_client_instance):
            mock_t = MagicMock()
            mock_t.verify = True
            mock_t.headers = {}
            mock_t.timeout = 30
            mock_transport.return_value = mock_t

            await Prompt.alist(prompt_type=PromptType.CHAT)

        call_kwargs = mock_client_instance.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params", {})
        assert params["prompt_type"] == 2

    @pytest.mark.asyncio
    async def test_alist_with_prompt_type_text(self):
        from lumenova_beacon.prompts.models import Prompt
        from lumenova_beacon.prompts.types import PromptType

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": [], "total": 0}
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = AsyncMock()
        mock_client_instance.get.return_value = mock_response
        mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
        mock_client_instance.__aexit__ = AsyncMock(return_value=False)

        with patch("lumenova_beacon.prompts.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.prompts.models.get_transport") as mock_transport, \
             patch("lumenova_beacon.prompts.models.httpx.AsyncClient", return_value=mock_client_instance):
            mock_t = MagicMock()
            mock_t.verify = True
            mock_t.headers = {}
            mock_t.timeout = 30
            mock_transport.return_value = mock_t

            await Prompt.alist(prompt_type=PromptType.TEXT)

        call_kwargs = mock_client_instance.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params", {})
        assert params["prompt_type"] == 1

    @pytest.mark.asyncio
    async def test_alist_with_empty_string_search_sends_param(self):
        """Regression: search='' should be included in params, not omitted."""
        from lumenova_beacon.prompts.models import Prompt

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": [], "total": 0}
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = AsyncMock()
        mock_client_instance.get.return_value = mock_response
        mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
        mock_client_instance.__aexit__ = AsyncMock(return_value=False)

        with patch("lumenova_beacon.prompts.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.prompts.models.get_transport") as mock_transport, \
             patch("lumenova_beacon.prompts.models.httpx.AsyncClient", return_value=mock_client_instance):
            mock_t = MagicMock()
            mock_t.verify = True
            mock_t.headers = {}
            mock_t.timeout = 30
            mock_transport.return_value = mock_t

            await Prompt.alist(search="")

        call_kwargs = mock_client_instance.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params", {})
        assert "search" in params

    @pytest.mark.asyncio
    async def test_alist_without_prompt_type_omits_param(self):
        from lumenova_beacon.prompts.models import Prompt

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": [], "total": 0}
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = AsyncMock()
        mock_client_instance.get.return_value = mock_response
        mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
        mock_client_instance.__aexit__ = AsyncMock(return_value=False)

        with patch("lumenova_beacon.prompts.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.prompts.models.get_transport") as mock_transport, \
             patch("lumenova_beacon.prompts.models.httpx.AsyncClient", return_value=mock_client_instance):
            mock_t = MagicMock()
            mock_t.verify = True
            mock_t.headers = {}
            mock_t.timeout = 30
            mock_transport.return_value = mock_t

            await Prompt.alist()

        call_kwargs = mock_client_instance.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params", {})
        assert "prompt_type" not in params


class TestPromptFromDict:
    """Test Prompt._from_dict handles category and type fields."""

    def test_from_dict_includes_category(self):
        from lumenova_beacon.prompts.models import Prompt

        data = {
            "id": "p-1",
            "name": "test",
            "type": 1,
            "versions": [{"version_number": 1, "content": {"template": "hi"}}],
            "category": "production",
        }
        prompt = Prompt._from_dict(data)
        assert prompt.category == "production"

    def test_from_dict_category_none_when_absent(self):
        from lumenova_beacon.prompts.models import Prompt

        data = {
            "id": "p-2",
            "name": "test",
            "type": 2,
            "versions": [{"version_number": 1, "content": {}}],
        }
        prompt = Prompt._from_dict(data)
        assert prompt.category is None

    def test_from_dict_maps_api_type_to_prompt_type(self):
        from lumenova_beacon.prompts.models import Prompt
        from lumenova_beacon.prompts.types import PromptType

        data = {
            "id": "p-3",
            "name": "chat-prompt",
            "type": 2,
            "versions": [{"version_number": 1, "content": {}}],
        }
        prompt = Prompt._from_dict(data)
        assert prompt.type == PromptType.CHAT


class TestPromptCreateFalsyValues:
    """Regression: empty-string and empty-list values must be included in the create payload."""

    @pytest.mark.asyncio
    async def test_acreate_includes_empty_description(self):
        from lumenova_beacon.prompts.models import Prompt

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "id": "p-new",
            "name": "test",
            "type": 1,
            "versions": [{"version_number": 1, "content": {"template": "hi"}}],
        }
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("lumenova_beacon.prompts.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.prompts.models.get_transport") as mock_transport, \
             patch("lumenova_beacon.prompts.models.httpx.AsyncClient", return_value=mock_client):
            mock_t = MagicMock()
            mock_t.verify = True
            mock_t.headers = {}
            mock_t.timeout = 30
            mock_transport.return_value = mock_t

            await Prompt.acreate(name="test", template="hi", description="", tags=[], message="")

        payload = mock_client.post.call_args.kwargs["json"]
        assert payload["description"] == ""
        assert payload["tags"] == []
        assert payload["commit_message"] == ""

    @pytest.mark.asyncio
    async def test_acreate_omits_none_values(self):
        from lumenova_beacon.prompts.models import Prompt

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "id": "p-new",
            "name": "test",
            "type": 1,
            "versions": [{"version_number": 1, "content": {"template": "hi"}}],
        }
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("lumenova_beacon.prompts.models.get_base_url", return_value="http://test"), \
             patch("lumenova_beacon.prompts.models.get_transport") as mock_transport, \
             patch("lumenova_beacon.prompts.models.httpx.AsyncClient", return_value=mock_client):
            mock_t = MagicMock()
            mock_t.verify = True
            mock_t.headers = {}
            mock_t.timeout = 30
            mock_transport.return_value = mock_t

            await Prompt.acreate(name="test", template="hi")

        payload = mock_client.post.call_args.kwargs["json"]
        assert "description" not in payload
        assert "tags" not in payload
        assert "commit_message" not in payload
