"""Tests for Guardrail.apply / aapply payload construction."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from lumenova_beacon.guardrails import Guardrail
from lumenova_beacon.guardrails.models import DEFAULT_CACHE


GUARDRAIL_ID = '00000000-0000-0000-0000-000000000007'


@pytest.fixture
def transport():
    t = MagicMock()
    t.headers = {'Authorization': 'Bearer test-key', 'Content-Type': 'application/json'}
    t.timeout = 10.0
    t.verify = True
    t.proxies = None
    t.cert = None
    # Real dict so the ** splat at the call site works.
    t.httpx_kwargs.return_value = {'verify': True}
    return t


@pytest.fixture
def _patch_transport(transport):
    with (
        patch(
            'lumenova_beacon.guardrails.models.get_transport',
            return_value=transport,
        ),
        patch(
            'lumenova_beacon.guardrails.models.get_base_url',
            return_value='https://api.test.com',
        ),
    ):
        yield


@pytest.fixture
def ok_response():
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = 200
    resp.text = '{"outputs": []}'
    resp.json.return_value = {'outputs': []}
    return resp


def _posted_payload(mock_post):
    return mock_post.call_args.kwargs['json']


def _patch_sync_client(ok_response):
    """Return a context manager mocking httpx.Client(...) → client.post(...).

    Yields the post-mock so tests can inspect call args. The Client constructor
    itself is also tracked via the returned ``client_cls`` MagicMock — useful
    for asserting which kwargs (verify, cert, proxy, …) were threaded in.
    """
    mock_post = MagicMock(return_value=ok_response)
    mock_client = MagicMock()
    mock_client.post = mock_post
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=None)
    client_cls = MagicMock(return_value=mock_client)
    return patch(
        'lumenova_beacon.guardrails.models.httpx.Client', client_cls
    ), client_cls, mock_post


class TestApplyPayload:
    def test_apply_without_metadata_omits_field(self, _patch_transport, ok_response):
        ctx, _client_cls, mock_post = _patch_sync_client(ok_response)
        with ctx:
            Guardrail(GUARDRAIL_ID).apply('hello world')

            payload = _posted_payload(mock_post)
            assert payload['content'] == [{'text': 'hello world'}]
            assert 'metadata' not in payload['content'][0]
            assert payload['cache'] == DEFAULT_CACHE

    def test_apply_with_metadata_forwards_dict(self, _patch_transport, ok_response):
        metadata = {
            'query': 'What is the capital of France?',
            'context': [
                'Paris is the capital and largest city of France.',
                'France is a country in Western Europe.',
            ],
        }
        ctx, _client_cls, mock_post = _patch_sync_client(ok_response)
        with ctx:
            Guardrail(GUARDRAIL_ID).apply('hello world', metadata=metadata)

            payload = _posted_payload(mock_post)
            assert payload['content'][0]['text'] == 'hello world'
            assert payload['content'][0]['metadata'] == metadata

    def test_apply_with_partial_metadata_query_only(self, _patch_transport, ok_response):
        metadata = {'query': 'just a query'}
        ctx, _client_cls, mock_post = _patch_sync_client(ok_response)
        with ctx:
            Guardrail(GUARDRAIL_ID).apply('text', metadata=metadata)

            payload = _posted_payload(mock_post)
            assert payload['content'][0]['metadata'] == {'query': 'just a query'}

    def test_apply_with_partial_metadata_context_only(self, _patch_transport, ok_response):
        metadata = {'context': ['s1']}
        ctx, _client_cls, mock_post = _patch_sync_client(ok_response)
        with ctx:
            Guardrail(GUARDRAIL_ID).apply('text', metadata=metadata)

            payload = _posted_payload(mock_post)
            assert payload['content'][0]['metadata'] == {'context': ['s1']}

    def test_apply_metadata_does_not_disturb_default_cache(self, _patch_transport, ok_response):
        ctx, _client_cls, mock_post = _patch_sync_client(ok_response)
        with ctx:
            Guardrail(GUARDRAIL_ID).apply('text', metadata={'query': 'q', 'context': []})

            payload = _posted_payload(mock_post)
            assert payload['cache'] == DEFAULT_CACHE

    def test_apply_metadata_alongside_explicit_cache(self, _patch_transport, ok_response):
        custom_cache = {'ttl': 60, 's-maxage': 120, 'no-cache': False, 'no-store': False}
        metadata = {'query': 'q', 'context': ['src']}
        ctx, _client_cls, mock_post = _patch_sync_client(ok_response)
        with ctx:
            Guardrail(GUARDRAIL_ID).apply('text', cache=custom_cache, metadata=metadata)

            payload = _posted_payload(mock_post)
            assert payload['cache'] == custom_cache
            assert payload['content'][0]['metadata'] == metadata

    def test_apply_url(self, _patch_transport, ok_response):
        ctx, _client_cls, mock_post = _patch_sync_client(ok_response)
        with ctx:
            Guardrail(GUARDRAIL_ID).apply('text')

            url = mock_post.call_args.args[0]
            assert url == f'https://api.test.com/api/v1/guardrail/{GUARDRAIL_ID}/apply'


class TestApplyTransportKwargsPropagation:
    """Guardrail.apply must thread transport's verify/cert/proxy into httpx.Client."""

    def test_apply_threads_httpx_kwargs(self, transport, ok_response):
        transport.httpx_kwargs.return_value = {
            'verify': '/etc/ca.pem',
            'cert': ('/c.pem', '/k.pem'),
            'proxy': 'http://corp-proxy:8080',
            'trust_env': False,
        }
        with (
            patch(
                'lumenova_beacon.guardrails.models.get_transport',
                return_value=transport,
            ),
            patch(
                'lumenova_beacon.guardrails.models.get_base_url',
                return_value='https://api.test.com',
            ),
        ):
            ctx, client_cls, _post = _patch_sync_client(ok_response)
            with ctx:
                Guardrail(GUARDRAIL_ID).apply('text')

            kwargs = client_cls.call_args.kwargs
            assert kwargs['verify'] == '/etc/ca.pem'
            assert kwargs['cert'] == ('/c.pem', '/k.pem')
            assert kwargs['proxy'] == 'http://corp-proxy:8080'
            assert kwargs['trust_env'] is False
            assert kwargs['timeout'] == 10.0
        # httpx_kwargs was invoked without async_client (sync path).
        transport.httpx_kwargs.assert_called_with()


class TestAApplyTransportKwargsPropagation:
    """Guardrail.aapply must thread transport's verify/cert/proxy into httpx.AsyncClient."""

    async def test_aapply_threads_httpx_kwargs(self, transport, ok_response):
        transport.httpx_kwargs.return_value = {
            'verify': '/etc/ca.pem',
            'cert': ('/c.pem', '/k.pem'),
            'proxy': 'http://corp-proxy:8080',
            'trust_env': False,
        }
        mock_async_post = AsyncMock(return_value=ok_response)
        mock_client_ctx = MagicMock()
        mock_client_ctx.__aenter__ = AsyncMock(
            return_value=MagicMock(post=mock_async_post)
        )
        mock_client_ctx.__aexit__ = AsyncMock(return_value=None)
        async_client_cls = MagicMock(return_value=mock_client_ctx)

        with (
            patch(
                'lumenova_beacon.guardrails.models.get_transport',
                return_value=transport,
            ),
            patch(
                'lumenova_beacon.guardrails.models.get_base_url',
                return_value='https://api.test.com',
            ),
            patch(
                'lumenova_beacon.guardrails.models.httpx.AsyncClient',
                async_client_cls,
            ),
        ):
            await Guardrail(GUARDRAIL_ID).aapply('text')

        kwargs = async_client_cls.call_args.kwargs
        assert kwargs['verify'] == '/etc/ca.pem'
        assert kwargs['cert'] == ('/c.pem', '/k.pem')
        assert kwargs['proxy'] == 'http://corp-proxy:8080'
        assert kwargs['trust_env'] is False
        assert kwargs['timeout'] == 10.0
        # async path requests AsyncHTTPTransport from the translator.
        transport.httpx_kwargs.assert_called_with(async_client=True)


class TestAapplyPayload:
    async def test_aapply_without_metadata_omits_field(self, _patch_transport, ok_response):
        mock_async_post = AsyncMock(return_value=ok_response)
        mock_client_ctx = MagicMock()
        mock_client_ctx.__aenter__ = AsyncMock(return_value=MagicMock(post=mock_async_post))
        mock_client_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch(
            'lumenova_beacon.guardrails.models.httpx.AsyncClient',
            return_value=mock_client_ctx,
        ):
            await Guardrail(GUARDRAIL_ID).aapply('hello world')

            payload = mock_async_post.call_args.kwargs['json']
            assert payload['content'] == [{'text': 'hello world'}]
            assert 'metadata' not in payload['content'][0]

    async def test_aapply_with_metadata_forwards_dict(self, _patch_transport, ok_response):
        metadata = {
            'query': 'What is the capital of France?',
            'context': ['Paris is the capital and largest city of France.'],
        }
        mock_async_post = AsyncMock(return_value=ok_response)
        mock_client_ctx = MagicMock()
        mock_client_ctx.__aenter__ = AsyncMock(return_value=MagicMock(post=mock_async_post))
        mock_client_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch(
            'lumenova_beacon.guardrails.models.httpx.AsyncClient',
            return_value=mock_client_ctx,
        ):
            await Guardrail(GUARDRAIL_ID).aapply('hello world', metadata=metadata)

            payload = mock_async_post.call_args.kwargs['json']
            assert payload['content'][0]['metadata'] == metadata


class TestBuildPayload:
    def test_build_payload_omits_metadata_when_none(self):
        g = Guardrail(GUARDRAIL_ID)
        payload = g._build_payload('text')
        assert payload == {
            'content': [{'text': 'text'}],
            'cache': DEFAULT_CACHE,
        }

    def test_build_payload_includes_metadata_when_provided(self):
        g = Guardrail(GUARDRAIL_ID)
        metadata = {'query': 'q', 'context': ['s1']}
        payload = g._build_payload('text', metadata=metadata)
        assert payload['content'][0]['metadata'] == metadata

    def test_build_payload_empty_metadata_dict_is_forwarded(self):
        """An explicit empty dict is still forwarded (only `None` omits the key)."""
        g = Guardrail(GUARDRAIL_ID)
        payload = g._build_payload('text', metadata={})
        assert payload['content'][0]['metadata'] == {}
