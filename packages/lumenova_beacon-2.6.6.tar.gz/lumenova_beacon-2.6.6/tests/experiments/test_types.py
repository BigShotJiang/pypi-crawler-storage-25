"""Tests for experiment type definitions."""

from datetime import datetime, timezone

from lumenova_beacon.experiments.types import (
    EnrichedRecord,
    ExperimentRun,
    ExperimentRunStats,
    ExperimentRunStatus,
    ExperimentStatus,
    ExperimentStep,
    ExperimentStepType,
    StepRunSummary,
    VariableMapping,
)


class TestExperimentStatus:
    def test_all_values(self):
        assert ExperimentStatus.DRAFT == 1
        assert ExperimentStatus.QUEUED == 2
        assert ExperimentStatus.RUNNING == 3
        assert ExperimentStatus.COMPLETED == 4
        assert ExperimentStatus.FAILED == 5
        assert ExperimentStatus.STOPPED == 6
        assert ExperimentStatus.COMPLETED_WITH_ERRORS == 7
        assert ExperimentStatus.WAITING_FOR_EXTERNAL == 8

    def test_has_eight_members(self):
        assert len(ExperimentStatus) == 8

    def test_construct_from_int(self):
        assert ExperimentStatus(7) == ExperimentStatus.COMPLETED_WITH_ERRORS
        assert ExperimentStatus(8) == ExperimentStatus.WAITING_FOR_EXTERNAL


class TestExperimentStepType:
    def test_all_values(self):
        assert ExperimentStepType.PROMPT == "prompt"
        assert ExperimentStepType.LLM == "llm"
        assert ExperimentStepType.EVALUATION == "evaluation"
        assert ExperimentStepType.PYTHON == "python"
        assert ExperimentStepType.EXTERNAL_AGENT == "external_agent"

    def test_has_five_members(self):
        assert len(ExperimentStepType) == 5

    def test_is_string(self):
        assert isinstance(ExperimentStepType.PROMPT, str)

    def test_python_step_constructible(self):
        step = ExperimentStep(
            step_type="python",
            output_column="py_out",
            config={"code": "def run(x): return x"},
        )
        assert step.step_type == ExperimentStepType.PYTHON
        assert step.to_dict()["step_type"] == "python"


class TestExperimentRunStatus:
    def test_all_values(self):
        assert ExperimentRunStatus.PENDING == "pending"
        assert ExperimentRunStatus.RUNNING == "running"
        assert ExperimentRunStatus.COMPLETED == "completed"
        assert ExperimentRunStatus.FAILED == "failed"

    def test_has_four_members(self):
        assert len(ExperimentRunStatus) == 4

    def test_is_string(self):
        assert isinstance(ExperimentRunStatus.PENDING, str)


class TestExperimentStep:
    def test_to_dict(self):
        step = ExperimentStep(
            step_type=ExperimentStepType.LLM,
            output_column="llm_output",
            config={"model_config_id": "abc", "variable_mappings": {"input": "col1"}},
        )
        result = step.to_dict()
        assert result == {
            "step_type": "llm",
            "output_column": "llm_output",
            "config": {
                "model_config_id": "abc",
                "variable_mappings": {"input": "col1"},
            },
        }

    def test_to_dict_with_string_step_type(self):
        step = ExperimentStep(
            step_type="external_agent",
            output_column="output",
            config={},
        )
        result = step.to_dict()
        assert result["step_type"] == "external_agent"

    def test_from_dict_full(self):
        data = {
            "id": "step-123",
            "experiment_id": "exp-456",
            "position": 2,
            "step_type": "prompt",
            "output_column": "rendered",
            "config": {"prompt_content": "Hello {{name}}"},
            "created_at": "2025-01-15T10:00:00Z",
            "updated_at": "2025-01-15T11:00:00Z",
        }
        step = ExperimentStep.from_dict(data)
        assert step.id == "step-123"
        assert step.experiment_id == "exp-456"
        assert step.position == 2
        assert step.step_type == "prompt"
        assert step.output_column == "rendered"
        assert step.config == {"prompt_content": "Hello {{name}}"}
        assert step.created_at == datetime(2025, 1, 15, 10, 0, tzinfo=timezone.utc)
        assert step.updated_at == datetime(2025, 1, 15, 11, 0, tzinfo=timezone.utc)

    def test_from_dict_minimal(self):
        data = {
            "step_type": "llm",
            "output_column": "output",
        }
        step = ExperimentStep.from_dict(data)
        assert step.step_type == "llm"
        assert step.output_column == "output"
        assert step.config == {}
        assert step.id is None
        assert step.position is None

    def test_roundtrip(self):
        original = ExperimentStep(
            step_type=ExperimentStepType.EVALUATION,
            output_column="eval_score",
            config={"evaluator_id": "eval-1"},
        )
        serialized = original.to_dict()
        restored = ExperimentStep.from_dict(serialized)
        assert restored.step_type == "evaluation"
        assert restored.output_column == "eval_score"
        assert restored.config == {"evaluator_id": "eval-1"}


class TestExperimentRun:
    def test_from_dict_full(self):
        data = {
            "id": "run-001",
            "experiment_id": "exp-001",
            "record_id": "rec-001",
            "step_id": "step-001",
            "configuration_id": None,
            "status": "completed",
            "result": {"output": "hello", "tokens": 10},
            "error": None,
            "execution_time_ms": 150,
            "started_at": "2025-01-15T10:00:00Z",
            "completed_at": "2025-01-15T10:00:01Z",
            "created_at": "2025-01-15T09:59:00Z",
            "updated_at": "2025-01-15T10:00:01Z",
        }
        run = ExperimentRun.from_dict(data)
        assert run.id == "run-001"
        assert run.experiment_id == "exp-001"
        assert run.record_id == "rec-001"
        assert run.step_id == "step-001"
        assert run.configuration_id is None
        assert run.status == ExperimentRunStatus.COMPLETED
        assert run.result == {"output": "hello", "tokens": 10}
        assert run.error is None
        assert run.execution_time_ms == 150
        assert run.started_at is not None
        assert run.completed_at is not None

    def test_from_dict_minimal(self):
        data = {
            "id": "run-002",
            "experiment_id": "exp-001",
            "record_id": "rec-002",
            "status": "pending",
        }
        run = ExperimentRun.from_dict(data)
        assert run.id == "run-002"
        assert run.status == ExperimentRunStatus.PENDING
        assert run.step_id is None
        assert run.result is None
        assert run.execution_time_ms is None

    def test_from_dict_failed(self):
        data = {
            "id": "run-003",
            "experiment_id": "exp-001",
            "record_id": "rec-003",
            "status": "failed",
            "error": "LLM timeout",
            "execution_time_ms": 30000,
        }
        run = ExperimentRun.from_dict(data)
        assert run.status == ExperimentRunStatus.FAILED
        assert run.error == "LLM timeout"

    def test_from_dict_with_configuration_label(self):
        data = {
            "id": "run-004",
            "experiment_id": "exp-001",
            "record_id": "rec-004",
            "status": "completed",
            "configuration_label": "B",
        }
        run = ExperimentRun.from_dict(data)
        assert run.configuration_label == "B"

    def test_from_dict_without_configuration_label(self):
        data = {
            "id": "run-005",
            "experiment_id": "exp-001",
            "record_id": "rec-005",
            "status": "pending",
        }
        run = ExperimentRun.from_dict(data)
        assert run.configuration_label is None


class TestExperimentRunStats:
    def test_from_dict_full(self):
        data = {
            "experiment_id": "exp-001",
            "total_runs": 300,
            "pending_runs": 50,
            "running_runs": 10,
            "completed_runs": 230,
            "failed_runs": 10,
            "avg_execution_time_ms": 250.5,
            "min_execution_time_ms": 50,
            "max_execution_time_ms": 5000,
        }
        stats = ExperimentRunStats.from_dict(data)
        assert stats.experiment_id == "exp-001"
        assert stats.total_runs == 300
        assert stats.pending_runs == 50
        assert stats.running_runs == 10
        assert stats.completed_runs == 230
        assert stats.failed_runs == 10
        assert stats.avg_execution_time_ms == 250.5
        assert stats.min_execution_time_ms == 50
        assert stats.max_execution_time_ms == 5000

    def test_from_dict_no_timing(self):
        data = {
            "experiment_id": "exp-002",
            "total_runs": 0,
            "pending_runs": 0,
            "running_runs": 0,
            "completed_runs": 0,
            "failed_runs": 0,
        }
        stats = ExperimentRunStats.from_dict(data)
        assert stats.avg_execution_time_ms is None
        assert stats.min_execution_time_ms is None
        assert stats.max_execution_time_ms is None


class TestStepRunSummary:
    def test_from_dict_full(self):
        data = {
            "step_id": "step-001",
            "step_position": 0,
            "step_type": "llm",
            "output_column": "llm_output",
            "status": "completed",
            "output": "Generated text",
            "error_message": None,
            "execution_time_ms": 200,
            "execution_metadata": {"model": "gpt-4", "tokens": 50},
        }
        summary = StepRunSummary.from_dict(data)
        assert summary.step_id == "step-001"
        assert summary.step_position == 0
        assert summary.step_type == "llm"
        assert summary.output_column == "llm_output"
        assert summary.status == ExperimentRunStatus.COMPLETED
        assert summary.output == "Generated text"
        assert summary.error_message is None
        assert summary.execution_time_ms == 200
        assert summary.execution_metadata == {"model": "gpt-4", "tokens": 50}

    def test_from_dict_failed(self):
        data = {
            "step_id": "step-002",
            "step_position": 1,
            "step_type": "evaluation",
            "output_column": "eval_score",
            "status": "failed",
            "error_message": "Evaluator timeout",
        }
        summary = StepRunSummary.from_dict(data)
        assert summary.status == ExperimentRunStatus.FAILED
        assert summary.error_message == "Evaluator timeout"
        assert summary.output is None


class TestEnrichedRecord:
    def test_from_dict_full(self):
        data = {
            "record_id": "rec-001",
            "data": {"input": "hello", "category": "greeting"},
            "overall_status": "success",
            "step_runs": [
                {
                    "step_id": "step-001",
                    "step_position": 0,
                    "step_type": "prompt",
                    "output_column": "rendered",
                    "status": "completed",
                    "output": "Rendered: hello",
                },
                {
                    "step_id": "step-002",
                    "step_position": 1,
                    "step_type": "llm",
                    "output_column": "response",
                    "status": "completed",
                    "output": "Hi there!",
                    "execution_time_ms": 150,
                },
            ],
        }
        record = EnrichedRecord.from_dict(data)
        assert record.record_id == "rec-001"
        assert record.data == {"input": "hello", "category": "greeting"}
        assert record.overall_status == "success"
        assert len(record.step_runs) == 2
        assert record.step_runs[0].step_type == "prompt"
        assert record.step_runs[1].output == "Hi there!"

    def test_from_dict_no_step_runs(self):
        data = {
            "record_id": "rec-002",
            "data": {"input": "test"},
            "overall_status": "pending",
        }
        record = EnrichedRecord.from_dict(data)
        assert record.step_runs == []

    def test_from_dict_empty_data(self):
        data = {
            "record_id": "rec-003",
            "overall_status": "pending",
        }
        record = EnrichedRecord.from_dict(data)
        assert record.data == {}
        assert record.step_runs == []


class TestExperimentStepVariableMappingNormalization:
    """``ExperimentStep.to_dict()`` normalizes typed mappings inside ``config``.

    The mixed shape (typed VariableMapping + legacy column-name string + dict)
    is the realistic case — bare-string column shorthand has been the standard
    experiments idiom for a long time.
    """

    def test_typed_mapping_serialized_inside_config(self):
        step = ExperimentStep(
            step_type=ExperimentStepType.LLM,
            output_column="response",
            config={
                "model_config_id": "cfg-1",
                "variable_mappings": {
                    "input": VariableMapping.jsonata("input.text"),
                },
            },
        )
        wire_config = step.to_dict()["config"]
        wire_mappings = wire_config["variable_mappings"]
        assert wire_mappings["input"] == {
            "data_mode": "raw",
            "pipeline": [
                {"kind": "extract_path", "engine": "jsonata", "expr": "input.text"}
            ],
        }
        # Other config keys are untouched.
        assert wire_config["model_config_id"] == "cfg-1"

    def test_bare_string_passes_through(self):
        step = ExperimentStep(
            step_type=ExperimentStepType.LLM,
            output_column="response",
            config={"variable_mappings": {"input": "text_column"}},
        )
        wire_mappings = step.to_dict()["config"]["variable_mappings"]
        assert wire_mappings == {"input": "text_column"}

    def test_legacy_dict_passes_through(self):
        legacy_mappings = {"input": {"data_mode": "raw", "json_path": "$.x"}}
        step = ExperimentStep(
            step_type=ExperimentStepType.LLM,
            output_column="response",
            config={"variable_mappings": legacy_mappings},
        )
        assert step.to_dict()["config"]["variable_mappings"] == legacy_mappings

    def test_mixed_typed_and_legacy_normalized_independently(self):
        step = ExperimentStep(
            step_type=ExperimentStepType.LLM,
            output_column="response",
            config={
                "variable_mappings": {
                    "typed": VariableMapping.python(
                        "def extract(data): return data['x']"
                    ),
                    "column": "rendered_prompt",
                    "legacy": {"data_mode": "raw", "json_path": "$.legacy"},
                },
            },
        )
        wire = step.to_dict()["config"]["variable_mappings"]
        assert wire["typed"]["pipeline"][0]["engine"] == "python"
        assert "json_path" not in wire["typed"]
        assert wire["column"] == "rendered_prompt"
        assert wire["legacy"] == {"data_mode": "raw", "json_path": "$.legacy"}

    def test_step_without_variable_mappings_unchanged(self):
        step = ExperimentStep(
            step_type=ExperimentStepType.PYTHON,
            output_column="out",
            config={"code": "def run(x): return x"},
        )
        assert step.to_dict()["config"] == {"code": "def run(x): return x"}

    def test_to_dict_does_not_mutate_input_config(self):
        original_mappings = {
            "input": VariableMapping.jsonata("input.text"),
        }
        config = {"model_config_id": "cfg-1", "variable_mappings": original_mappings}
        step = ExperimentStep(
            step_type=ExperimentStepType.LLM,
            output_column="response",
            config=config,
        )
        step.to_dict()
        # The user's original config dict should still hold the typed mapping,
        # so calling to_dict() twice (e.g. retry path) is idempotent.
        assert isinstance(
            step.config["variable_mappings"]["input"], VariableMapping
        )
        # Calling again still produces a wire-format dict.
        wire = step.to_dict()["config"]["variable_mappings"]["input"]
        assert isinstance(wire, dict)
        assert wire["pipeline"][0]["engine"] == "jsonata"
