"""Tests for the BeaconLangGraphGovernanceHandler and GovernanceClient."""

from __future__ import annotations

from unittest.mock import MagicMock, patch
from uuid import UUID, uuid4

import httpx
import pytest

from lumenova_beacon.exceptions import (
    GovernanceError,
    GovernanceNotFoundError,
    GovernanceValidationError,
    GovernanceViolationError,
)
from lumenova_beacon.governance.client import GovernanceClient
from lumenova_beacon.governance.integrations.langchain import BeaconLangGraphGovernanceHandler


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def transport():
    """Mock HTTPTransport returned by get_transport()."""
    t = MagicMock()
    t.headers = {'Authorization': 'Bearer test-key', 'Content-Type': 'application/json'}
    t.timeout = 10.0
    t.verify = True
    t.proxies = None
    t.cert = None
    # Real dict so the ** splat at the call site works.
    t.httpx_kwargs.return_value = {'verify': True}
    return t


def _patch_sync_client(mock_resp=None, side_effect=None):
    """Build a patch() target that mocks httpx.Client(...) as a context manager.

    Returns (patcher, client_cls_mock, post_mock). The post_mock's call_args
    captures what client.post(...) was invoked with; the client_cls_mock's
    call_args captures the Client constructor's kwargs (verify, cert, proxy,
    timeout, ...).
    """
    post_mock = MagicMock(return_value=mock_resp, side_effect=side_effect)
    inner = MagicMock()
    inner.post = post_mock
    inner.__enter__ = MagicMock(return_value=inner)
    inner.__exit__ = MagicMock(return_value=None)
    client_cls = MagicMock(return_value=inner)
    patcher = patch(
        'lumenova_beacon.governance.client.httpx.Client', client_cls
    )
    return patcher, client_cls, post_mock


@pytest.fixture
def mock_beacon_client():
    """Mock BeaconClient returned by get_client() in handler/decorator init."""
    mock_client = MagicMock()
    mock_client.config.session_id = 'test-session'
    mock_client.config.environment = 'test'
    return mock_client


@pytest.fixture
def _patch_transport(transport, mock_beacon_client):
    """Patch get_transport, get_base_url, and get_client for all tests in this module."""
    with (
        patch(
            'lumenova_beacon.governance.client.get_transport',
            return_value=transport,
        ),
        patch(
            'lumenova_beacon.governance.client.get_base_url',
            return_value='https://api.test.com',
        ),
        patch(
            'lumenova_beacon.core.client.get_client',
            return_value=mock_beacon_client,
        ),
    ):
        yield


@pytest.fixture
def governance_client(_patch_transport):
    return GovernanceClient()


@pytest.fixture
def allow_response():
    """Governance allow response using the flat format."""
    return {
        'decision': 'allow',
        'message': None,
        'rules_evaluated': [{'name': 'default-allow'}],
        'latency_ms': 5.2,
    }


@pytest.fixture
def block_response():
    """Governance block response using the flat format."""
    return {
        'decision': 'block',
        'message': 'tool not permitted',
        'rules_evaluated': [{'name': 'block-dangerous-tools'}],
        'latency_ms': 3.1,
    }


@pytest.fixture
def run_id():
    return uuid4()


# ---------------------------------------------------------------------------
# GovernanceClient tests
# ---------------------------------------------------------------------------


class TestGovernanceClient:
    def test_evaluate_builds_correct_payload(self, governance_client):
        """Verify the request payload matches the backend schema with nested tool."""
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.text = '{}'
        mock_resp.json.return_value = {
            'decision': 'allow', 'message': None, 'rules_evaluated': [], 'latency_ms': 1.0,
        }

        patcher, _cls, mock_post = _patch_sync_client(mock_resp=mock_resp)
        with patcher:
            governance_client.evaluate(
                phase='pre',
                type_='tool',
                stack_ids=['stack-1'],
                extra={'tool': {'name': 'search', 'parameters': {'query': 'test'}}},
            )

            mock_post.assert_called_once()
            payload = mock_post.call_args.kwargs['json']
            assert payload['stack_ids'] == ['stack-1']
            assert payload['input']['phase'] == 'pre'
            assert payload['input']['type'] == 'tool'
            # Tool data is nested under input.tool
            assert payload['input']['tool']['name'] == 'search'
            assert payload['input']['tool']['parameters'] == {'query': 'test'}

    def test_evaluate_url(self, governance_client):
        """Verify the endpoint URL is correct."""
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.text = '{}'
        mock_resp.json.return_value = {'decision': 'allow', 'message': None, 'rules_evaluated': [], 'latency_ms': 0}

        patcher, _cls, mock_post = _patch_sync_client(mock_resp=mock_resp)
        with patcher:
            governance_client.evaluate(
                phase='pre', type_='tool', stack_ids=['test'],
            )
            url = mock_post.call_args.args[0]
            assert url == 'https://api.test.com/api/v1/governance/evaluate'

    def test_evaluate_missing_stack_ids_and_tags_raises(self, governance_client):
        """When both stack_ids and tags are None, a validation error is raised."""
        with pytest.raises(GovernanceValidationError, match='(?i)at least one'):
            governance_client.evaluate(
                phase='pre', type_='llm',
                stack_ids=None, tags=None,
            )

    def test_evaluate_with_tags_only(self, governance_client):
        """When only tags are provided, stack_ids should not appear in the payload."""
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.text = '{}'
        mock_resp.json.return_value = {'decision': 'allow', 'message': None, 'rules_evaluated': [], 'latency_ms': 0}

        patcher, _cls, mock_post = _patch_sync_client(mock_resp=mock_resp)
        with patcher:
            governance_client.evaluate(
                phase='pre', type_='tool', tags=['env:prod'],
            )
            payload = mock_post.call_args.kwargs['json']
            assert payload['tags'] == ['env:prod']
            assert 'stack_ids' not in payload

    def test_evaluate_with_both_stack_ids_and_tags(self, governance_client):
        """When both stack_ids and tags are provided, both appear in the payload."""
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.text = '{}'
        mock_resp.json.return_value = {'decision': 'allow', 'message': None, 'rules_evaluated': [], 'latency_ms': 0}

        patcher, _cls, mock_post = _patch_sync_client(mock_resp=mock_resp)
        with patcher:
            governance_client.evaluate(
                phase='pre', type_='tool',
                stack_ids=['s1'], tags=['t1'],
            )
            payload = mock_post.call_args.kwargs['json']
            assert payload['stack_ids'] == ['s1']
            assert payload['tags'] == ['t1']

    def test_evaluate_404_raises_not_found(self, governance_client):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 404
        mock_resp.json.return_value = {'detail': 'Not found'}
        mock_resp.text = '{"detail": "Not found"}'
        error = httpx.HTTPStatusError('Not found', request=MagicMock(), response=mock_resp)
        patcher, _cls, _post = _patch_sync_client(side_effect=error)
        with patcher:
            with pytest.raises(GovernanceNotFoundError):
                governance_client.evaluate(
                    phase='pre', type_='tool', stack_ids=['test'],
                )

    def test_evaluate_422_raises_validation(self, governance_client):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 422
        mock_resp.json.return_value = {'detail': 'Invalid input'}
        mock_resp.text = '{"detail": "Invalid input"}'
        error = httpx.HTTPStatusError('Validation', request=MagicMock(), response=mock_resp)
        patcher, _cls, _post = _patch_sync_client(side_effect=error)
        with patcher:
            with pytest.raises(GovernanceValidationError):
                governance_client.evaluate(
                    phase='pre', type_='tool', stack_ids=['test'],
                )

    def test_evaluate_connection_error(self, governance_client):
        patcher, _cls, _post = _patch_sync_client(
            side_effect=httpx.ConnectError('Connection refused')
        )
        with patcher:
            with pytest.raises(GovernanceError, match='Failed to connect'):
                governance_client.evaluate(
                    phase='pre', type_='tool', stack_ids=['test'],
                )

    def test_evaluate_custom_timeout(self, governance_client):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.text = '{}'
        mock_resp.json.return_value = {'decision': 'allow', 'message': None, 'rules_evaluated': [], 'latency_ms': 0}
        patcher, client_cls, _post = _patch_sync_client(mock_resp=mock_resp)
        with patcher:
            governance_client.evaluate(
                phase='pre', type_='tool', stack_ids=['test'], timeout=2.0,
            )
            # Timeout now lives on the httpx.Client constructor, not on .post().
            assert client_cls.call_args.kwargs['timeout'] == 2.0


# ---------------------------------------------------------------------------
# Transport-kwargs propagation tests
# ---------------------------------------------------------------------------


class TestGovernanceTransportKwargsPropagation:
    """The governance client must splat ``transport.httpx_kwargs()`` into both
    sync ``httpx.Client(...)`` and async ``httpx.AsyncClient(...)`` constructor
    calls. A regression that dropped the splat (or rebuilt the dict by hand)
    would silently lose proxies/cert/verify config — exactly the silent
    failure the MR sets out to prevent."""

    def _ok_response(self):
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = 200
        resp.text = '{}'
        resp.json.return_value = {
            'decision': 'allow', 'message': None,
            'rules_evaluated': [], 'latency_ms': 0,
        }
        return resp

    def test_evaluate_splats_full_httpx_kwargs(self, transport, _patch_transport):
        # Rich kwargs that exercise every knob the MR adds.
        transport.httpx_kwargs.return_value = {
            'verify': '/etc/ca.pem',
            'cert': ('/etc/c.pem', '/etc/k.pem'),
            'proxy': 'http://corp:8080',
            'trust_env': False,
        }
        patcher, client_cls, _ = _patch_sync_client(mock_resp=self._ok_response())
        with patcher:
            GovernanceClient().evaluate(
                phase='pre', type_='tool', stack_ids=['s'],
            )
        kwargs = client_cls.call_args.kwargs
        assert kwargs['verify'] == '/etc/ca.pem'
        assert kwargs['cert'] == ('/etc/c.pem', '/etc/k.pem')
        assert kwargs['proxy'] == 'http://corp:8080'
        assert kwargs['trust_env'] is False
        # transport.httpx_kwargs() was actually consulted (sync flavor).
        transport.httpx_kwargs.assert_called_with()

    def test_evaluate_splats_mounts_branch(self, transport, _patch_transport):
        """Split http/https translates to ``mounts`` per scheme; the dict must
        reach AsyncClient/Client unchanged or per-scheme routing breaks."""
        mounts_sentinel = {'http://': object(), 'https://': object()}
        transport.httpx_kwargs.return_value = {
            'verify': True, 'mounts': mounts_sentinel,
        }
        patcher, client_cls, _ = _patch_sync_client(mock_resp=self._ok_response())
        with patcher:
            GovernanceClient().evaluate(
                phase='pre', type_='tool', stack_ids=['s'],
            )
        assert client_cls.call_args.kwargs['mounts'] is mounts_sentinel

    @pytest.mark.asyncio
    async def test_aevaluate_splats_full_httpx_kwargs(
        self, transport, _patch_transport
    ):
        transport.httpx_kwargs.return_value = {
            'verify': '/etc/ca.pem',
            'cert': ('/etc/c.pem', '/etc/k.pem'),
            'proxy': 'http://corp:8080',
            'trust_env': False,
        }
        # Async context-manager mock.
        async_inner = MagicMock()
        async_inner.post = MagicMock(return_value=self._ok_response())

        async def _aenter(_self):
            return async_inner

        async def _aexit(_self, *exc):
            return None

        async_inner.__aenter__ = _aenter
        async_inner.__aexit__ = _aexit
        async_cls = MagicMock(return_value=async_inner)

        # Make post awaitable.
        async def _post(*args, **kwargs):
            return self._ok_response()
        async_inner.post = _post

        with patch('lumenova_beacon.governance.client.httpx.AsyncClient', async_cls):
            await GovernanceClient().aevaluate(
                phase='pre', type_='tool', stack_ids=['s'],
            )
        kwargs = async_cls.call_args.kwargs
        assert kwargs['verify'] == '/etc/ca.pem'
        assert kwargs['cert'] == ('/etc/c.pem', '/etc/k.pem')
        assert kwargs['proxy'] == 'http://corp:8080'
        assert kwargs['trust_env'] is False
        # Async path must request the async-flavor kwargs.
        transport.httpx_kwargs.assert_called_with(async_client=True)


# ---------------------------------------------------------------------------
# Default result parser tests
# ---------------------------------------------------------------------------


class TestDefaultResultParser:
    def test_decision_allow(self):
        assert BeaconLangGraphGovernanceHandler._default_result_parser(
            {'decision': 'allow'}
        ) is True

    def test_decision_block(self):
        assert BeaconLangGraphGovernanceHandler._default_result_parser(
            {'decision': 'block', 'message': 'no'}
        ) is False

    def test_decision_apply_guardrail(self):
        """apply_guardrail is not block, so it should be allowed."""
        assert BeaconLangGraphGovernanceHandler._default_result_parser(
            {'decision': 'apply_guardrail'}
        ) is True

    def test_backward_compat_nested_decision(self):
        """Old nested format should still work via backward compat."""
        assert BeaconLangGraphGovernanceHandler._default_result_parser(
            {'decision': {'action': 'allow'}}
        ) is True
        assert BeaconLangGraphGovernanceHandler._default_result_parser(
            {'decision': {'action': 'block'}}
        ) is False

    def test_empty_result_blocks(self):
        # Missing `decision` key is now treated as fail-closed: a malformed
        # backend response that omits the field must not implicitly allow.
        assert BeaconLangGraphGovernanceHandler._default_result_parser({}) is False


# ---------------------------------------------------------------------------
# BeaconLangGraphGovernanceHandler tests
# ---------------------------------------------------------------------------


class TestBeaconLangGraphGovernanceHandler:
    def _make_handler(self, _patch_transport, **kwargs):
        kwargs.setdefault('stack_ids', ['test-stack'])
        return BeaconLangGraphGovernanceHandler(**kwargs)

    def _serialized_tool(self, name='search'):
        return {'name': name, 'id': ['langchain', 'tools', name]}

    def _serialized_llm(self, model='gpt-4'):
        return {'name': 'ChatOpenAI', 'kwargs': {'model_name': model}}

    def _human_msg(self, text='Hello'):
        msg = MagicMock()
        msg.type = 'human'
        msg.content = text
        return msg

    # -- User attribute metadata fallback --

    def test_user_attrs_from_metadata_fallback(self, _patch_transport, mock_beacon_client):
        mock_beacon_client.config.user_email = None
        mock_beacon_client.config.user_name = None
        mock_beacon_client.config.user_id = None
        handler = self._make_handler(
            _patch_transport,
            metadata={"user_email": "meta@test.com", "user_name": "Meta", "user_id": "m-1"},
        )
        assert handler._user_email == "meta@test.com"
        assert handler._user_name == "Meta"
        assert handler._user_id == "m-1"

    def test_config_user_attrs_override_metadata(self, _patch_transport, mock_beacon_client):
        mock_beacon_client.config.user_email = "config@test.com"
        mock_beacon_client.config.user_name = "Config"
        mock_beacon_client.config.user_id = "c-1"
        handler = self._make_handler(
            _patch_transport,
            metadata={"user_email": "meta@test.com", "user_name": "Meta", "user_id": "m-1"},
        )
        assert handler._user_email == "config@test.com"
        assert handler._user_name == "Config"
        assert handler._user_id == "c-1"

    # -- Tool pre-execution: payload structure --

    def test_on_tool_start_payload_structure(
        self, _patch_transport, allow_response, run_id,
    ):
        """Verify the extra payload uses nested tool object matching Rego format."""
        handler = self._make_handler(_patch_transport, stack_ids=['stack-1'])
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('send_email'),
                '',
                run_id=run_id,
                inputs={'to': 'x@y.com', 'subject': 'Hi'},
            )
            call_kwargs = mock_eval.call_args.kwargs
            assert call_kwargs['phase'] == 'pre'
            assert call_kwargs['type_'] == 'tool'
            tool = call_kwargs['extra']['tool']
            assert tool['name'] == 'send_email'
            assert tool['parameters'] == {'to': 'x@y.com', 'subject': 'Hi'}
            assert 'output' not in tool  # pre-execution has no output

    # -- Tool post-execution: payload structure --

    def test_on_tool_end_payload_structure(
        self, _patch_transport, allow_response, run_id,
    ):
        """Verify post-execution includes tool.output and tool.parameters."""
        handler = self._make_handler(_patch_transport)
        handler._runs[str(run_id)] = {
            'tool_name': 'read_file',
            'parameters': {'path': '/data/f.csv'},
        }
        output = MagicMock()
        output.content = 'Employee record: Jane Doe'
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_tool_end(output, run_id=run_id)
            tool = mock_eval.call_args.kwargs['extra']['tool']
            assert tool['name'] == 'read_file'
            assert tool['parameters'] == {'path': '/data/f.csv'}
            assert tool['output'] == 'Employee record: Jane Doe'

    # -- Tool pre-execution: blocked --

    def test_on_tool_start_blocked(self, _patch_transport, block_response, run_id):
        handler = self._make_handler(_patch_transport, stack_ids=['stack-1'])
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError, match="tool 'search'"):
                handler.on_tool_start(
                    self._serialized_tool(),
                    '{"query": "test"}',
                    run_id=run_id,
                )

    # -- Tool pre-execution: allowed --

    def test_on_tool_start_allowed(self, _patch_transport, allow_response, run_id):
        handler = self._make_handler(_patch_transport, stack_ids=['stack-1'])
        with patch.object(handler._client, 'evaluate', return_value=allow_response):
            handler.on_tool_start(
                self._serialized_tool(),
                '{"query": "test"}',
                run_id=run_id,
            )

    # -- Tool pre-execution: fail-open --

    def test_on_tool_start_fail_open(self, _patch_transport, run_id):
        handler = self._make_handler(_patch_transport, fail_open=True)
        with patch.object(
            handler._client, 'evaluate', side_effect=GovernanceError('unreachable')
        ):
            handler.on_tool_start(
                self._serialized_tool(), '{}', run_id=run_id,
            )

    # -- Tool pre-execution: fail-closed --

    def test_on_tool_start_fail_closed(self, _patch_transport, run_id):
        handler = self._make_handler(_patch_transport, fail_open=False)
        with patch.object(
            handler._client, 'evaluate', side_effect=GovernanceError('unreachable')
        ):
            with pytest.raises(GovernanceError, match='unreachable'):
                handler.on_tool_start(
                    self._serialized_tool(), '{}', run_id=run_id,
                )

    # -- Tool args extraction --

    def test_on_tool_start_extracts_args_from_kwargs_inputs(
        self, _patch_transport, allow_response, run_id,
    ):
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool(), '', run_id=run_id,
                inputs={'query': 'test', 'limit': 10},
            )
            tool = mock_eval.call_args.kwargs['extra']['tool']
            assert tool['parameters'] == {'query': 'test', 'limit': 10}

    def test_on_tool_start_parses_json_input_str(
        self, _patch_transport, allow_response, run_id,
    ):
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool(), '{"query": "test"}', run_id=run_id,
            )
            tool = mock_eval.call_args.kwargs['extra']['tool']
            assert tool['parameters'] == {'query': 'test'}

    def test_on_tool_start_non_json_input_str(
        self, _patch_transport, allow_response, run_id,
    ):
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool(), 'plain text', run_id=run_id,
            )
            tool = mock_eval.call_args.kwargs['extra']['tool']
            assert tool['parameters'] == {}

    # -- Tool post-execution --

    def test_on_tool_end_blocked(self, _patch_transport, block_response, run_id):
        handler = self._make_handler(_patch_transport)
        handler._runs[str(run_id)] = {'tool_name': 'search', 'parameters': {}}
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_end('result text', run_id=run_id)

    def test_on_tool_end_extracts_content_attribute(
        self, _patch_transport, allow_response, run_id,
    ):
        handler = self._make_handler(_patch_transport)
        handler._runs[str(run_id)] = {'tool_name': 'search', 'parameters': {}}
        output = MagicMock()
        output.content = 'actual tool result'
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_tool_end(output, run_id=run_id)
            tool = mock_eval.call_args.kwargs['extra']['tool']
            assert tool['output'] == 'actual tool result'

    def test_on_tool_end_gets_name_from_kwargs(
        self, _patch_transport, allow_response, run_id,
    ):
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_tool_end('result', run_id=run_id, name='calc')
            tool = mock_eval.call_args.kwargs['extra']['tool']
            assert tool['name'] == 'calc'

    # -- Tool error cleans up --

    def test_on_tool_error_cleans_up(self, _patch_transport, run_id):
        handler = self._make_handler(_patch_transport)
        handler._runs[str(run_id)] = {'tool_name': 'search', 'parameters': {}}
        handler.on_tool_error(RuntimeError('boom'), run_id=run_id)
        assert str(run_id) not in handler._runs

    # -- LLM pre-execution: payload structure --

    def test_on_chat_model_start_payload_structure(
        self, _patch_transport, allow_response, run_id,
    ):
        """Verify the extra payload uses nested llm object."""
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_chat_model_start(
                self._serialized_llm(),
                [[self._human_msg('Tell me a secret')]],
                run_id=run_id,
            )
            call_kwargs = mock_eval.call_args.kwargs
            assert call_kwargs['phase'] == 'pre'
            assert call_kwargs['type_'] == 'llm'
            llm = call_kwargs['extra']['llm']
            assert llm['model_name'] == 'gpt-4'
            assert llm['last_user_content'] == 'Tell me a secret'
            assert call_kwargs['extra']['context']['model_call_count'] == 1

    # -- LLM pre-execution: blocked --

    def test_on_chat_model_start_blocked(self, _patch_transport, block_response, run_id):
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError, match="LLM 'gpt-4'"):
                handler.on_chat_model_start(
                    self._serialized_llm(),
                    [[self._human_msg('Hello')]],
                    run_id=run_id,
                )

    def test_model_call_count_increments(self, _patch_transport, allow_response):
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_chat_model_start(
                self._serialized_llm(), [[self._human_msg()]], run_id=uuid4(),
            )
            handler.on_chat_model_start(
                self._serialized_llm(), [[self._human_msg()]], run_id=uuid4(),
            )
            calls = mock_eval.call_args_list
            assert calls[0].kwargs['extra']['context']['model_call_count'] == 1
            assert calls[1].kwargs['extra']['context']['model_call_count'] == 2

    # -- on_llm_start (non-chat) --

    def test_on_llm_start_payload(self, _patch_transport, allow_response, run_id):
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_llm_start(
                self._serialized_llm(), ['Hello, how are you?'], run_id=run_id,
            )
            llm = mock_eval.call_args.kwargs['extra']['llm']
            assert mock_eval.call_args.kwargs['extra']['context']['model_call_count'] == 1
            assert llm['last_user_content'] == 'Hello, how are you?'

    # -- LLM post-execution --

    def test_on_llm_end_blocked(self, _patch_transport, block_response, run_id):
        handler = self._make_handler(_patch_transport)
        handler._runs[str(run_id)] = {'model_name': 'gpt-4', 'last_user_content': 'hello'}
        mock_response = MagicMock()
        mock_response.llm_output = {'token_usage': {'prompt_tokens': 10, 'completion_tokens': 20}}
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError):
                handler.on_llm_end(mock_response, run_id=run_id)

    def test_on_llm_end_payload(self, _patch_transport, allow_response, run_id):
        handler = self._make_handler(_patch_transport)
        handler._model_call_count = 3
        handler._runs[str(run_id)] = {'model_name': 'gpt-4', 'last_user_content': 'What is AI?'}
        mock_response = MagicMock()
        mock_response.llm_output = None
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_llm_end(mock_response, run_id=run_id)
            llm = mock_eval.call_args.kwargs['extra']['llm']
            assert mock_eval.call_args.kwargs['extra']['context']['model_call_count'] == 3
            assert llm['model_name'] == 'gpt-4'
            assert llm['last_user_content'] == 'What is AI?'

    # -- LLM error cleans up --

    def test_on_llm_error_cleans_up(self, _patch_transport, run_id):
        handler = self._make_handler(_patch_transport)
        handler._runs[str(run_id)] = {'model_name': 'gpt-4'}
        handler.on_llm_error(RuntimeError('boom'), run_id=run_id)
        assert str(run_id) not in handler._runs

    # -- Disabled hooks --

    def test_disabled_hook_skips_evaluation(self, _patch_transport, run_id):
        handler = self._make_handler(_patch_transport, enabled_hooks={'pre_tool'})
        with patch.object(handler._client, 'evaluate') as mock_eval:
            handler.on_chat_model_start(
                self._serialized_llm(), [[self._human_msg()]], run_id=run_id,
            )
            mock_eval.assert_not_called()

    def test_disabled_post_tool_skips_evaluation(self, _patch_transport, run_id):
        handler = self._make_handler(_patch_transport, enabled_hooks={'pre_tool'})
        handler._runs[str(run_id)] = {'tool_name': 'search', 'parameters': {}}
        with patch.object(handler._client, 'evaluate') as mock_eval:
            handler.on_tool_end('result', run_id=run_id)
            mock_eval.assert_not_called()

    # -- Custom result parser --

    def test_custom_result_parser(self, _patch_transport, run_id):
        def custom_parser(r):
            return r.get('verdict') != 'deny'
        handler = self._make_handler(
            _patch_transport,
            stack_ids=['test-stack'],
            result_parser=custom_parser,
        )
        response = {'verdict': 'deny', 'latency_ms': 1.0, 'rules_evaluated': []}
        with patch.object(handler._client, 'evaluate', return_value=response):
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=run_id)

    def test_custom_result_parser_allows(self, _patch_transport, run_id):
        def custom_parser(r):
            return r.get('verdict') != 'deny'
        handler = self._make_handler(
            _patch_transport,
            stack_ids=['test-stack'],
            result_parser=custom_parser,
        )
        response = {'verdict': 'ok', 'latency_ms': 1.0, 'rules_evaluated': []}
        with patch.object(handler._client, 'evaluate', return_value=response):
            handler.on_tool_start(self._serialized_tool(), '{}', run_id=run_id)

    # -- Violation error metadata --

    def test_violation_error_metadata(self, _patch_transport, run_id):
        handler = self._make_handler(_patch_transport)
        response = {
            'decision': 'block',
            'message': 'not allowed',
            'rules_evaluated': [{'name': 'policy-a', 'version': 2}],
            'latency_ms': 7.5,
        }
        with patch.object(handler._client, 'evaluate', return_value=response):
            with pytest.raises(GovernanceViolationError) as exc_info:
                handler.on_tool_start(
                    self._serialized_tool('dangerous_tool'), '{}', run_id=run_id,
                )
            err = exc_info.value
            assert err.result['decision'] == 'block'
            assert err.policies == [{'name': 'policy-a', 'version': 2}]
            assert err.latency_ms == 7.5
            assert 'not allowed' in str(err)

    def test_violation_error_includes_message(self, _patch_transport, run_id):
        """The decision message should appear in the exception string."""
        handler = self._make_handler(_patch_transport)
        response = {
            'decision': 'block',
            'message': 'Cannot send internal data to external recipients',
            'rules_evaluated': [],
            'latency_ms': 2.0,
        }
        with patch.object(handler._client, 'evaluate', return_value=response):
            with pytest.raises(GovernanceViolationError, match='Cannot send internal data'):
                handler.on_tool_start(
                    self._serialized_tool('send_email'), '{}', run_id=run_id,
                )

    def test_violation_error_no_message(self, _patch_transport, run_id):
        """When decision has no message, the error should still be clear."""
        handler = self._make_handler(_patch_transport)
        response = {
            'decision': 'block',
            'message': None,
            'rules_evaluated': [],
            'latency_ms': 1.0,
        }
        with patch.object(handler._client, 'evaluate', return_value=response):
            with pytest.raises(GovernanceViolationError, match="tool 'search'") as exc_info:
                handler.on_tool_start(
                    self._serialized_tool(), '{}', run_id=run_id,
                )
            # Should NOT have a trailing ": " when no message
            assert str(exc_info.value).endswith('at pre')

    # -- Default parser: missing decision key (now fail-closed) --

    def test_default_parser_missing_decision_blocks(self, _patch_transport, run_id):
        # A malformed backend response that omits `decision` must block —
        # previously this implicitly allowed via dict.get('decision', 'allow').
        handler = self._make_handler(_patch_transport)
        response = {'some_other_key': True, 'latency_ms': 1.0, 'rules_evaluated': []}
        with patch.object(handler._client, 'evaluate', return_value=response):
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=run_id)

    # -- Truncation --

    def test_large_tool_output_truncated(self, _patch_transport, allow_response, run_id):
        handler = self._make_handler(_patch_transport)
        handler._runs[str(run_id)] = {'tool_name': 'search', 'parameters': {}}
        output = MagicMock()
        output.content = 'x' * 10000
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_tool_end(output, run_id=run_id)
            tool = mock_eval.call_args.kwargs['extra']['tool']
            assert len(tool['output']) == 4096

    # -- Direct kwargs --

    def test_kwargs_shorthand(self, _patch_transport):
        handler = self._make_handler(
            _patch_transport, stack_ids=['s1'], tags=['t1'], fail_open=False, timeout=3.0,
        )
        assert handler._stack_ids == ['s1']
        assert handler._tags == ['t1']
        assert handler._fail_open is False
        assert handler._timeout == 3.0

    # -- raise_error --

    def test_raise_error_attribute(self, _patch_transport):
        handler = self._make_handler(_patch_transport)
        assert handler.raise_error is True

    # -- on_violation: invalid value --

    def test_invalid_on_violation_raises(self, _patch_transport):
        with pytest.raises(ValueError, match="on_violation must be one of"):
            self._make_handler(_patch_transport, on_violation='invalid')

    # -- Invocation chain: in-flight action visible at pre-evaluation --

    def test_pre_tool_payload_includes_current_tool_in_chain(
        self, _patch_transport, allow_response, run_id,
    ):
        """pre_tool evaluation must see the in-flight tool in invocation_chain."""
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('send_email'),
                '',
                run_id=run_id,
                inputs={'to': 'x@y.com'},
            )
            chain = mock_eval.call_args.kwargs['extra']['context']['invocation_chain']
            assert chain[-1] == {'action': 'send_email', 'type': 'tool'}

    def test_pre_llm_payload_includes_current_llm_in_chain(
        self, _patch_transport, allow_response, run_id,
    ):
        """pre_llm evaluation must see the in-flight LLM call in invocation_chain."""
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval:
            handler.on_chat_model_start(
                self._serialized_llm(),
                [[self._human_msg('Hi')]],
                run_id=run_id,
            )
            chain = mock_eval.call_args.kwargs['extra']['context']['invocation_chain']
            assert chain[-1] == {'action': 'gpt-4', 'type': 'llm'}

    def test_chain_records_llm_then_tool_sequence(
        self, _patch_transport, allow_response,
    ):
        """A typical LLM -> tool flow leaves both entries in the chain."""
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response):
            handler.on_chat_model_start(
                self._serialized_llm(),
                [[self._human_msg('Hi')]],
                run_id=uuid4(),
            )
            tool_run = uuid4()
            handler.on_tool_start(
                self._serialized_tool('send_email'),
                '',
                run_id=tool_run,
                inputs={'to': 'x@y.com'},
            )
            handler.on_tool_end('ok', run_id=tool_run)
        assert list(handler._invocation_chain) == [
            {'action': 'gpt-4', 'type': 'llm'},
            {'action': 'send_email', 'type': 'tool'},
        ]

    def test_chain_includes_blocked_action(
        self, _patch_transport, block_response, run_id,
    ):
        """Blocked actions stay in the chain — semantics are 'attempted', not 'completed'."""
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(
                    self._serialized_tool('drop_table'),
                    '{}',
                    run_id=run_id,
                )
        assert list(handler._invocation_chain) == [
            {'action': 'drop_table', 'type': 'tool'},
        ]

    def test_chain_single_append_per_callback_action(
        self, _patch_transport, allow_response, run_id,
    ):
        """on_tool_start + on_tool_end together add exactly one chain entry."""
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=allow_response):
            handler.on_tool_start(
                self._serialized_tool('search'),
                '{}',
                run_id=run_id,
            )
            handler.on_tool_end('result', run_id=run_id)
        assert list(handler._invocation_chain) == [
            {'action': 'search', 'type': 'tool'},
        ]


# ---------------------------------------------------------------------------
# Graceful stop tests
# ---------------------------------------------------------------------------


class TestGracefulStop:
    def _make_handler(self, _patch_transport, **kwargs):
        kwargs.setdefault('stack_ids', ['test-stack'])
        return BeaconLangGraphGovernanceHandler(**kwargs)

    def _serialized_tool(self, name='search'):
        return {'name': name, 'id': ['langchain', 'tools', name]}

    def _serialized_llm(self, model='gpt-4'):
        return {'name': 'ChatOpenAI', 'kwargs': {'model_name': model}}

    def _human_msg(self, text='Hello'):
        msg = MagicMock()
        msg.type = 'human'
        msg.content = text
        return msg

    def test_on_violation_raise_is_default(self, _patch_transport):
        handler = self._make_handler(_patch_transport)
        assert handler._on_violation == 'raise'

    def test_violation_count_starts_at_zero(self, _patch_transport):
        handler = self._make_handler(_patch_transport)
        assert handler.violation_count == 0

    def test_violation_count_increments(self, _patch_transport, block_response, run_id):
        handler = self._make_handler(_patch_transport)
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=run_id)
        assert handler.violation_count == 1

    def test_on_violation_stop_sets_stopped_flag(self, _patch_transport, block_response, run_id):
        handler = self._make_handler(_patch_transport, on_violation='stop')
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=run_id)
        assert handler._stopped is True

    def test_stopped_handler_blocks_tool_without_api_call(
        self, _patch_transport, run_id,
    ):
        handler = self._make_handler(_patch_transport, on_violation='stop')
        handler._stopped = True
        with patch.object(handler._client, 'evaluate') as mock_eval:
            with pytest.raises(GovernanceViolationError, match='Agent stopped'):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=run_id)
            mock_eval.assert_not_called()

    def test_stopped_handler_blocks_llm_without_api_call(
        self, _patch_transport, run_id,
    ):
        handler = self._make_handler(_patch_transport, on_violation='stop')
        handler._stopped = True
        with patch.object(handler._client, 'evaluate') as mock_eval:
            with pytest.raises(GovernanceViolationError, match='Agent stopped'):
                handler.on_chat_model_start(
                    self._serialized_llm(),
                    [[self._human_msg()]],
                    run_id=run_id,
                )
            mock_eval.assert_not_called()

    def test_stopped_handler_blocks_on_llm_start(
        self, _patch_transport, run_id,
    ):
        handler = self._make_handler(_patch_transport, on_violation='stop')
        handler._stopped = True
        with patch.object(handler._client, 'evaluate') as mock_eval:
            with pytest.raises(GovernanceViolationError, match='Agent stopped'):
                handler.on_llm_start(
                    self._serialized_llm(), ['Hello'], run_id=run_id,
                )
            mock_eval.assert_not_called()

    def test_max_violations_escalates_to_stop(self, _patch_transport, block_response):
        handler = self._make_handler(
            _patch_transport, on_violation='raise', max_violations=2,
        )
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            # First violation: raise (not stopped)
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=uuid4())
            assert handler._stopped is False
            assert handler.violation_count == 1

            # Second violation: escalates to stop
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=uuid4())
            assert handler._stopped is True
            assert handler.violation_count == 2

    def test_max_violations_subsequent_calls_blocked(
        self, _patch_transport, block_response,
    ):
        handler = self._make_handler(
            _patch_transport, on_violation='raise', max_violations=1,
        )
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=uuid4())

        # Now stopped — next call blocked without API call
        with patch.object(handler._client, 'evaluate') as mock_eval:
            with pytest.raises(GovernanceViolationError, match='Agent stopped'):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=uuid4())
            mock_eval.assert_not_called()

    def test_reset_clears_state(self, _patch_transport, block_response):
        handler = self._make_handler(_patch_transport, on_violation='stop')
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=uuid4())
        assert handler._stopped is True
        assert handler.violation_count == 1

        handler.reset()
        assert handler._stopped is False
        assert handler.violation_count == 0

    def test_raise_mode_does_not_set_stopped(self, _patch_transport, block_response):
        handler = self._make_handler(_patch_transport, on_violation='raise')
        with patch.object(handler._client, 'evaluate', return_value=block_response):
            with pytest.raises(GovernanceViolationError):
                handler.on_tool_start(self._serialized_tool(), '{}', run_id=uuid4())
        assert handler._stopped is False
        assert handler.violation_count == 1


# ---------------------------------------------------------------------------
# Trace context propagation tests
# ---------------------------------------------------------------------------


class TestTraceContextPropagation:
    def _make_handler(self, _patch_transport, **kwargs):
        kwargs.setdefault('stack_ids', ['test-stack'])
        return BeaconLangGraphGovernanceHandler(**kwargs)

    def _serialized_tool(self, name='search'):
        return {'name': name, 'id': ['langchain', 'tools', name]}

    def _serialized_llm(self, model='gpt-4'):
        return {'name': 'ChatOpenAI', 'kwargs': {'model_name': model}}

    def _human_msg(self, text='Hello'):
        msg = MagicMock()
        msg.type = 'human'
        msg.content = text
        return msg

    def test_trace_context_forwarded_on_tool_start(
        self, _patch_transport, allow_response,
    ):
        """When tracing is active, trace_id and span_id are sent to the API."""
        handler = self._make_handler(_patch_transport)
        mock_span = MagicMock()
        mock_span.span_id = 'span-xyz'
        with (
            patch('lumenova_beacon.governance.integrations.langchain.get_current_trace_id', return_value='trace-abc'),
            patch('lumenova_beacon.governance.integrations.langchain.get_current_span', return_value=mock_span),
            patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval,
        ):
            handler.on_tool_start(self._serialized_tool(), '{}', run_id=uuid4())
            assert mock_eval.call_args.kwargs['trace_id'] == 'trace-abc'
            assert mock_eval.call_args.kwargs['span_id'] == 'span-xyz'

    def test_trace_context_forwarded_on_tool_end(
        self, _patch_transport, allow_response,
    ):
        handler = self._make_handler(_patch_transport)
        run_id = uuid4()
        handler._runs[str(run_id)] = {'tool_name': 'search', 'parameters': {}}
        mock_span = MagicMock()
        mock_span.span_id = 'span-456'
        with (
            patch('lumenova_beacon.governance.integrations.langchain.get_current_trace_id', return_value='trace-123'),
            patch('lumenova_beacon.governance.integrations.langchain.get_current_span', return_value=mock_span),
            patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval,
        ):
            handler.on_tool_end('result', run_id=run_id)
            assert mock_eval.call_args.kwargs['trace_id'] == 'trace-123'
            assert mock_eval.call_args.kwargs['span_id'] == 'span-456'

    def test_trace_context_forwarded_on_llm_start(
        self, _patch_transport, allow_response,
    ):
        handler = self._make_handler(_patch_transport)
        mock_span = MagicMock()
        mock_span.span_id = 'span-llm'
        with (
            patch('lumenova_beacon.governance.integrations.langchain.get_current_trace_id', return_value='trace-llm'),
            patch('lumenova_beacon.governance.integrations.langchain.get_current_span', return_value=mock_span),
            patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval,
        ):
            handler.on_chat_model_start(
                self._serialized_llm(), [[self._human_msg()]], run_id=uuid4(),
            )
            assert mock_eval.call_args.kwargs['trace_id'] == 'trace-llm'
            assert mock_eval.call_args.kwargs['span_id'] == 'span-llm'

    def test_none_when_no_tracing_active(
        self, _patch_transport, allow_response,
    ):
        """When no tracing handler is active, trace_id and span_id are None."""
        handler = self._make_handler(_patch_transport)
        with (
            patch('lumenova_beacon.governance.integrations.langchain.get_current_trace_id', return_value=None),
            patch('lumenova_beacon.governance.integrations.langchain.get_current_span', return_value=None),
            patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval,
        ):
            handler.on_tool_start(self._serialized_tool(), '{}', run_id=uuid4())
            assert mock_eval.call_args.kwargs['trace_id'] is None
            assert mock_eval.call_args.kwargs['span_id'] is None

    def test_trace_context_read_at_evaluation_time(
        self, _patch_transport, allow_response,
    ):
        """Context is read at evaluation time, not at handler construction."""
        # Construct handler with no trace context.
        with (
            patch('lumenova_beacon.governance.integrations.langchain.get_current_trace_id', return_value=None),
            patch('lumenova_beacon.governance.integrations.langchain.get_current_span', return_value=None),
        ):
            handler = self._make_handler(_patch_transport)

        # Now set trace context and trigger evaluation.
        mock_span = MagicMock()
        mock_span.span_id = 'span-late'
        with (
            patch('lumenova_beacon.governance.integrations.langchain.get_current_trace_id', return_value='trace-late'),
            patch('lumenova_beacon.governance.integrations.langchain.get_current_span', return_value=mock_span),
            patch.object(handler._client, 'evaluate', return_value=allow_response) as mock_eval,
        ):
            handler.on_tool_start(self._serialized_tool(), '{}', run_id=uuid4())
            assert mock_eval.call_args.kwargs['trace_id'] == 'trace-late'
            assert mock_eval.call_args.kwargs['span_id'] == 'span-late'


# ---------------------------------------------------------------------------
# Agent state capture
# ---------------------------------------------------------------------------


class TestAgentStateCapture:
    """Tests for ``include_state`` / state_filter / per-run isolation."""

    def _make_handler(self, _patch_transport, **kwargs):
        kwargs.setdefault('stack_ids', ['test-stack'])
        return BeaconLangGraphGovernanceHandler(**kwargs)

    def _serialized_tool(self, name='search'):
        return {'name': name, 'id': ['langchain', 'tools', name]}

    @pytest.fixture
    def node_kwargs(self):
        """Kwargs that look like a graph-node-level on_chain_start."""
        return {
            'metadata': {'langgraph_node': 'extract', 'langgraph_step': 1},
            'tags': ['graph:step:1'],
        }

    def test_state_omitted_when_include_state_false(
        self, _patch_transport, allow_response, run_id, node_kwargs,
    ):
        """Explicit opt-out: state never appears in context even when captured upstream."""
        handler = self._make_handler(_patch_transport, include_state=False)
        handler.on_chain_start(
            {}, {'documentation_type': 'technical'}, run_id=run_id, **node_kwargs,
        )
        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert 'state' not in ctx

    def test_node_state_captured_and_forwarded(
        self, _patch_transport, allow_response, run_id, node_kwargs,
    ):
        """Node-level on_chain_start populates state visible to a tool fired inside."""
        handler = self._make_handler(_patch_transport, include_state=True)
        handler.on_chain_start(
            {}, {'documentation_type': 'technical', 'name': 'API'},
            run_id=run_id, **node_kwargs,
        )
        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}',
                run_id=uuid4(), parent_run_id=run_id,
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert ctx['state'] == {
                'documentation_type': 'technical',
                'name': 'API',
            }

    def test_seq_step_inputs_not_captured(
        self, _patch_transport, allow_response, run_id,
    ):
        """RunnableSeq steps inside a node must not overwrite the node's state."""
        handler = self._make_handler(_patch_transport, include_state=True)
        # Node start
        handler.on_chain_start(
            {}, {'documentation_type': 'technical'},
            run_id=run_id,
            metadata={'langgraph_node': 'extract'},
            tags=['graph:step:1'],
        )
        # Inner seq step inputs are noisy — must be ignored
        inner_run_id = uuid4()
        handler.on_chain_start(
            {}, {'noise': 'should-not-appear'},
            run_id=inner_run_id,
            parent_run_id=run_id,
            metadata={'langgraph_node': 'extract'},
            tags=['seq:step:2'],
        )
        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert ctx['state'] == {'documentation_type': 'technical'}

    def test_non_dict_inputs_skipped(
        self, _patch_transport, allow_response, run_id, node_kwargs,
    ):
        """When inputs is not a mapping (e.g. Command(resume=...)), no capture."""
        handler = self._make_handler(_patch_transport, include_state=True)
        handler.on_chain_start({}, 'a string input', run_id=run_id, **node_kwargs)
        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert 'state' not in ctx

    def test_state_filter_applied(
        self, _patch_transport, allow_response, run_id, node_kwargs,
    ):
        """state_filter runs before serialization and can drop fields."""
        handler = self._make_handler(
            _patch_transport, include_state=True,
            state_filter=lambda s: {k: v for k, v in s.items() if k != 'secret'},
        )
        handler.on_chain_start(
            {}, {'documentation_type': 'technical', 'secret': 'pii'},
            run_id=run_id, **node_kwargs,
        )
        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert ctx['state'] == {'documentation_type': 'technical'}

    def test_oversized_state_returns_truncation_marker(
        self, _patch_transport, allow_response, run_id, node_kwargs,
    ):
        """Above state_max_bytes the value is replaced with a marker, not dropped."""
        big = 'x' * 4096
        handler = self._make_handler(
            _patch_transport, include_state=True, state_max_bytes=512,
        )
        handler.on_chain_start(
            {}, {'huge': big}, run_id=run_id, **node_kwargs,
        )
        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert ctx['state']['_state_truncated'] is True
            assert ctx['state']['_state_size_bytes'] > 512

    def test_basemessage_coerced(
        self, _patch_transport, allow_response, run_id, node_kwargs,
    ):
        """LangChain BaseMessage objects in state are coerced to JSON-safe dicts."""
        from langchain_core.messages import HumanMessage

        handler = self._make_handler(_patch_transport, include_state=True)
        handler.on_chain_start(
            {}, {'messages': [HumanMessage(content='hello world')]},
            run_id=run_id, **node_kwargs,
        )
        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert ctx['state']['messages'] == [
                {'type': 'human', 'content': 'hello world'},
            ]

    def test_on_chain_end_releases_state(
        self, _patch_transport, run_id, node_kwargs,
    ):
        """on_chain_end pops the per-run state so it does not leak."""
        handler = self._make_handler(_patch_transport, include_state=True)
        handler.on_chain_start({}, {'k': 'v'}, run_id=run_id, **node_kwargs)
        assert run_id in handler._node_state
        handler.on_chain_end({}, run_id=run_id)
        assert run_id not in handler._node_state
        assert run_id not in handler._chain_parents
        assert run_id not in handler._cv_tokens

    def test_on_chain_error_releases_state(
        self, _patch_transport, run_id, node_kwargs,
    ):
        """GraphInterrupt and other chain errors must clean up too."""
        handler = self._make_handler(_patch_transport, include_state=True)
        handler.on_chain_start({}, {'k': 'v'}, run_id=run_id, **node_kwargs)
        handler.on_chain_error(RuntimeError('boom'), run_id=run_id)
        assert run_id not in handler._node_state
        assert run_id not in handler._cv_tokens

    def test_reset_clears_state_maps(
        self, _patch_transport, run_id, node_kwargs,
    ):
        """handler.reset() clears node_state and chain_parents along with the rest."""
        handler = self._make_handler(_patch_transport, include_state=True)
        handler.on_chain_start({}, {'k': 'v'}, run_id=run_id, **node_kwargs)
        handler.reset()
        assert handler._node_state == {}
        assert handler._chain_parents == {}
        assert handler._cv_tokens == {}

    def test_per_run_isolation_under_parallel_sends(
        self, _patch_transport, allow_response, node_kwargs,
    ):
        """Two simultaneous nodes keep distinct state without cross-talk."""
        handler = self._make_handler(_patch_transport, include_state=True)
        run_a, run_b = uuid4(), uuid4()
        handler.on_chain_start({}, {'branch': 'A'}, run_id=run_a, **node_kwargs)
        handler.on_chain_start({}, {'branch': 'B'}, run_id=run_b, **node_kwargs)
        # The most recent active node owns the contextvar at this thread; B wins.
        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}',
                run_id=uuid4(), parent_run_id=run_b,
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert ctx['state'] == {'branch': 'B'}
        # Both branches still have their state stored independently.
        assert handler._node_state[run_a] == {'branch': 'A'}
        assert handler._node_state[run_b] == {'branch': 'B'}

    def test_set_agent_state_replaces_captured_state(
        self, _patch_transport, allow_response, run_id, node_kwargs,
    ):
        """The public set_agent_state() helper replaces what was auto-captured."""
        from lumenova_beacon.governance import set_agent_state

        handler = self._make_handler(_patch_transport, include_state=True)
        handler.on_chain_start(
            {}, {'documentation_type': 'business'},
            run_id=run_id, **node_kwargs,
        )
        set_agent_state({'documentation_type': 'technical', 'reviewed': True})
        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert ctx['state'] == {
                'documentation_type': 'technical',
                'reviewed': True,
            }

    def test_set_agent_state_noop_without_handler(self):
        """Calling set_agent_state outside a node is a silent no-op."""
        from lumenova_beacon.governance import set_agent_state

        # Should not raise.
        set_agent_state({'anything': 1})

    def test_wrap_path_includes_state(
        self, _patch_transport, allow_response, run_id, node_kwargs,
    ):
        """The wrap path goes through _build_extra → _build_context, so state lands too."""
        handler = self._make_handler(_patch_transport, include_state=True)
        handler.on_chain_start(
            {}, {'documentation_type': 'technical'},
            run_id=run_id, **node_kwargs,
        )

        def inner(*, query: str) -> str:
            return f'res:{query}'

        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler._run_sync_tool('search', inner, (), {'query': 'ok'})
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert ctx['state'] == {'documentation_type': 'technical'}

    @pytest.mark.parametrize(
        'callback',
        [
            'on_tool_start',
            'on_tool_end',
            'on_llm_start',
            'on_chat_model_start',
            'on_llm_end',
        ],
    )
    def test_parent_run_id_is_load_bearing_for_state_resolution(
        self, _patch_transport, allow_response, run_id, callback,
    ):
        """Regression guard: tool/LLM run_ids are not in _chain_parents, so
        every callback site that calls _build_extra must seed
        lookup_state_for with parent_run_id, not run_id. Locally clear
        the ContextVar fallback so only the kwarg path can succeed.
        """
        from langchain_core.outputs import LLMResult

        from lumenova_beacon.governance._state import _active_node_run_id

        handler = self._make_handler(_patch_transport, include_state=True)
        handler._node_state[run_id] = {'documentation_type': 'technical'}
        handler._chain_parents[run_id] = None
        _active_node_run_id.set(None)

        def fire(parent: 'UUID | None') -> dict:
            cb_run_id = uuid4()
            kwargs = {'run_id': cb_run_id}
            if parent is not None:
                kwargs['parent_run_id'] = parent
            if callback == 'on_tool_start':
                handler.on_tool_start(
                    self._serialized_tool('save'), '{}', **kwargs,
                )
            elif callback == 'on_tool_end':
                handler._runs[str(cb_run_id)] = {
                    'tool_name': 'save', 'parameters': {},
                }
                handler.on_tool_end('output', name='save', **kwargs)
            elif callback == 'on_llm_start':
                handler.on_llm_start(
                    {'name': 'gpt', 'id': ['langchain', 'llms', 'openai']},
                    ['hi'], **kwargs,
                )
            elif callback == 'on_chat_model_start':
                handler.on_chat_model_start(
                    {'name': 'gpt', 'id': ['langchain', 'chat_models', 'openai']},
                    [[]], **kwargs,
                )
            elif callback == 'on_llm_end':
                handler._runs[str(cb_run_id)] = {'model_name': 'gpt'}
                handler.on_llm_end(LLMResult(generations=[[]]), **kwargs)
            else:  # pragma: no cover — parametrize guard
                raise AssertionError(f'unhandled callback {callback}')

        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            fire(parent=run_id)
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert ctx['state'] == {'documentation_type': 'technical'}, (
                f'{callback} dropped state when parent_run_id was provided'
            )

        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval_no_parent:
            fire(parent=None)
            ctx = mock_eval_no_parent.call_args.kwargs['extra']['context']
            assert 'state' not in ctx, (
                f'{callback} resolved state without a parent_run_id seed'
            )


# ---------------------------------------------------------------------------
# State capture under async streaming (astream / astream_events)
# ---------------------------------------------------------------------------


class TestAgentStateCaptureAsync:
    """Regression tests for the cross-Context bridge added so that
    ``astream`` / ``astream_events`` carry node state into governance
    evaluations.

    LangChain's async dispatcher offloads sync callbacks via
    ``run_in_executor(copy_context().run, ...)`` so the ContextVar set
    in ``on_chain_start`` lives only inside that copied Context and
    does not reach user code. The handler now resolves state via the
    LangChain config bridge (``var_child_runnable_config``) which is
    set inline by ``Runnable.ainvoke``/``astream`` in the user task's
    Context — surviving the dispatcher boundary.
    """

    def _make_handler(self, _patch_transport, **kwargs):
        kwargs.setdefault('stack_ids', ['test-stack'])
        return BeaconLangGraphGovernanceHandler(**kwargs)

    def _serialized_tool(self, name='search'):
        return {'name': name, 'id': ['langchain', 'tools', name]}

    @pytest.mark.asyncio
    async def test_state_visible_under_astream_events(
        self, _patch_transport, allow_response,
    ):
        """A LangGraph node driven by ``astream_events`` carries state to
        governance evaluations even though on_chain_start runs in a
        copied Context. The config-bridge fallback in
        ``_resolve_active_state`` finds the captured state via the live
        ``CallbackManagerForChainRun`` set in user code's Context.
        """
        pytest.importorskip('langgraph')
        from typing import TypedDict

        from langgraph.graph import StateGraph

        class S(TypedDict, total=False):
            documentation_type: str
            reviewed: bool

        handler = self._make_handler(_patch_transport, include_state=True)

        captured: list[dict] = []

        def fake_evaluate(**kwargs):
            captured.append(kwargs.get('extra', {}))
            return allow_response

        async def node(state: S) -> S:
            # Fire a tool callback from within the node so the handler
            # builds a governance payload while the node is in flight.
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            return state

        builder = StateGraph(S)
        builder.add_node('extract', node)
        builder.set_entry_point('extract')
        builder.set_finish_point('extract')
        graph = builder.compile()

        with patch.object(
            handler._client, 'evaluate', side_effect=fake_evaluate,
        ):
            async for _ in graph.astream_events(
                {'documentation_type': 'technical'},
                config={'callbacks': [handler]},
                version='v2',
            ):
                pass

        # Find the on_tool_start evaluation we triggered manually.
        tool_evals = [
            e for e in captured
            if isinstance(e, dict) and 'tool' in e
        ]
        assert tool_evals, 'no tool evaluation captured'
        assert tool_evals[0]['context']['state'] == {
            'documentation_type': 'technical',
        }

    @pytest.mark.asyncio
    async def test_set_agent_state_under_astream(
        self, _patch_transport, allow_response,
    ):
        """``set_agent_state`` writes into the live handler under async
        streaming, replacing what on_chain_start auto-captured."""
        pytest.importorskip('langgraph')
        from typing import TypedDict

        from langgraph.graph import StateGraph

        from lumenova_beacon.governance import set_agent_state

        class S(TypedDict, total=False):
            documentation_type: str
            reviewed: bool

        handler = self._make_handler(_patch_transport, include_state=True)
        captured: list[dict] = []

        def fake_evaluate(**kwargs):
            captured.append(kwargs.get('extra', {}))
            return allow_response

        async def node(state: S) -> S:
            set_agent_state(
                {'documentation_type': 'technical', 'reviewed': True},
            )
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            return state

        builder = StateGraph(S)
        builder.add_node('extract', node)
        builder.set_entry_point('extract')
        builder.set_finish_point('extract')
        graph = builder.compile()

        with patch.object(
            handler._client, 'evaluate', side_effect=fake_evaluate,
        ):
            async for _ in graph.astream(
                {'documentation_type': 'business'},
                config={'callbacks': [handler]},
            ):
                pass

        tool_evals = [
            e for e in captured
            if isinstance(e, dict) and 'tool' in e
        ]
        assert tool_evals, 'no tool evaluation captured'
        assert tool_evals[0]['context']['state'] == {
            'documentation_type': 'technical',
            'reviewed': True,
        }

    @pytest.mark.asyncio
    async def test_decorator_include_state_under_astream(
        self, _patch_transport, allow_response,
    ):
        """A ``@governance(include_state=True)`` async function called
        from inside a node receives state under ``astream``.

        Exercises the decorator's resolution path in
        ``decorators.py::_make_invocation_context_resolver`` — distinct
        from the handler-callback path covered above. Without the
        config bridge the decorator silently ships ``context`` without
        ``state`` because ``on_chain_start``'s ContextVar set runs in a
        copied Context that never reaches the decorated function.
        """
        pytest.importorskip('langgraph')
        from typing import TypedDict

        from langgraph.graph import StateGraph

        from lumenova_beacon.governance import governance

        class S(TypedDict, total=False):
            documentation_type: str

        handler = self._make_handler(_patch_transport, include_state=True)

        captured: list[dict] = []

        async def fake_aevaluate(**kwargs):
            captured.append(kwargs.get('extra', {}))
            return allow_response

        @governance(stack_ids=['s1'], include_state=True)
        async def decorated_tool(query: str) -> str:
            return 'ok'

        async def node(state: S) -> S:
            await decorated_tool(query='hi')
            return state

        builder = StateGraph(S)
        builder.add_node('extract', node)
        builder.set_entry_point('extract')
        builder.set_finish_point('extract')
        graph = builder.compile()

        with patch(
            'lumenova_beacon.governance.client.GovernanceClient.aevaluate',
            side_effect=fake_aevaluate,
        ):
            async for _ in graph.astream(
                {'documentation_type': 'technical'},
                config={'callbacks': [handler]},
            ):
                pass

        decorator_evals = [
            e for e in captured if isinstance(e, dict) and 'tool' in e
        ]
        assert decorator_evals, 'no decorator evaluation captured'
        # Both pre and post fire — assert all of them saw the state.
        for eva in decorator_evals:
            assert eva['context'].get('state') == {
                'documentation_type': 'technical',
            }, f'decorator eval missing state: {eva}'

    @pytest.mark.asyncio
    async def test_parallel_send_branches_isolate_state_under_astream(
        self, _patch_transport, allow_response,
    ):
        """Parallel ``Send`` fanout under ``astream``: each branch's
        tool evaluation sees only its own branch's state.

        The original code's hesitation about parent-walks was that they
        could mask races between Send branches. The fix uses the
        per-task ``var_child_runnable_config``, so each branch's seed
        run_id belongs to its own task and the walk only traverses that
        branch's ancestry. This test would fail if the walk leaked
        across branches (e.g., walked through a shared graph-level
        parent into a sibling's state entry).
        """
        pytest.importorskip('langgraph')
        from typing import TypedDict

        from langgraph.graph import END, START, StateGraph
        from langgraph.types import Send

        from lumenova_beacon.governance import set_agent_state

        class S(TypedDict, total=False):
            branch: str

        handler = self._make_handler(_patch_transport, include_state=True)

        captured_per_branch: list[tuple[str, dict]] = []

        def fake_evaluate(**kwargs):
            extra = kwargs.get('extra', {})
            state = extra.get('context', {}).get('state') or {}
            tool = extra.get('tool', {})
            captured_per_branch.append(
                (tool.get('name', '<no-tool>'), dict(state)),
            )
            return allow_response

        async def worker(state: S) -> S:
            # Override state with the branch label so the lookup must
            # round-trip through `set_agent_state` -> handler._node_state.
            set_agent_state({'branch': state['branch'], 'reviewed': True})
            handler.on_tool_start(
                self._serialized_tool(f'save_{state["branch"]}'),
                '{}', run_id=uuid4(),
            )
            # Return empty dict to avoid LastValue reducer collisions
            # between the two parallel branches; this test cares about
            # what the *governance evaluation* sees per branch, not the
            # final graph state.
            return {}

        def fan_out(_state):
            # No type hint on _state — LangGraph evaluates conditional-edges
            # callables' annotations at module scope, where the locally-
            # scoped TypedDict ``S`` is not visible.
            return [
                Send('worker', {'branch': 'A'}),
                Send('worker', {'branch': 'B'}),
            ]

        builder = StateGraph(S)
        builder.add_node('worker', worker)
        builder.add_conditional_edges(START, fan_out, ['worker'])
        builder.add_edge('worker', END)
        graph = builder.compile()

        with patch.object(
            handler._client, 'evaluate', side_effect=fake_evaluate,
        ):
            async for _ in graph.astream(
                {}, config={'callbacks': [handler]},
            ):
                pass

        # Filter to the two manual tool evals (one per branch).
        branch_evals = {
            tool: state
            for tool, state in captured_per_branch
            if tool.startswith('save_')
        }
        assert set(branch_evals) == {'save_A', 'save_B'}, (
            f'expected one eval per branch, got {captured_per_branch}'
        )
        assert branch_evals['save_A']['branch'] == 'A', (
            f'branch A leaked: {branch_evals}'
        )
        assert branch_evals['save_B']['branch'] == 'B', (
            f'branch B leaked: {branch_evals}'
        )

    @pytest.mark.asyncio
    async def test_set_agent_state_walks_nested_runnable_under_astream(
        self, _patch_transport, allow_response,
    ):
        """``set_agent_state`` called from a nested Runnable inside the
        node walks ``_chain_parents`` to reach the node's state entry.

        The inner ``RunnableLambda`` fires its own ``on_chain_start``,
        registering its run_id in ``_chain_parents`` but not in
        ``_node_state`` (only node-level chain starts populate state).
        The seed run_id from the config bridge points at the inner
        runnable, so the walk in
        ``_resolve_active_handler_and_node_run_id`` must climb at least
        one level to find the node entry — otherwise the override is
        written to a dead key and never surfaces.
        """
        pytest.importorskip('langgraph')
        from typing import TypedDict

        from langchain_core.runnables import RunnableLambda
        from langgraph.graph import StateGraph

        from lumenova_beacon.governance import set_agent_state

        class S(TypedDict, total=False):
            documentation_type: str

        handler = self._make_handler(_patch_transport, include_state=True)
        captured: list[dict] = []

        def fake_evaluate(**kwargs):
            captured.append(kwargs.get('extra', {}))
            return allow_response

        async def inner(payload: dict) -> dict:
            set_agent_state({'documentation_type': 'overridden'})
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            return payload

        inner_runnable = RunnableLambda(inner)

        async def node(state: S) -> S:
            await inner_runnable.ainvoke({'x': 1})
            return state

        builder = StateGraph(S)
        builder.add_node('extract', node)
        builder.set_entry_point('extract')
        builder.set_finish_point('extract')
        graph = builder.compile()

        with patch.object(
            handler._client, 'evaluate', side_effect=fake_evaluate,
        ):
            async for _ in graph.astream(
                {'documentation_type': 'original'},
                config={'callbacks': [handler]},
            ):
                pass

        tool_evals = [e for e in captured if isinstance(e, dict) and 'tool' in e]
        assert tool_evals, 'no tool evaluation captured'
        assert tool_evals[0]['context']['state'] == {
            'documentation_type': 'overridden',
        }

    @pytest.mark.asyncio
    async def test_no_contextvar_reset_warning_under_astream(
        self, _patch_transport, allow_response, caplog,
    ):
        """The ``ContextVar reset failed`` WARN is gone under async
        streaming — the failure is silenced at DEBUG level since the
        config-bridge handles state propagation."""
        pytest.importorskip('langgraph')
        from typing import TypedDict

        from langgraph.graph import StateGraph

        class S(TypedDict, total=False):
            x: int

        handler = self._make_handler(_patch_transport, include_state=True)

        async def node(state: S) -> S:
            return state

        builder = StateGraph(S)
        builder.add_node('n', node)
        builder.set_entry_point('n')
        builder.set_finish_point('n')
        graph = builder.compile()

        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ), caplog.at_level('WARNING'):
            async for _ in graph.astream(
                {'x': 1}, config={'callbacks': [handler]},
            ):
                pass

        warns = [
            r.getMessage()
            for r in caplog.records
            if r.levelname == 'WARNING'
        ]
        assert not any(
            'ContextVar reset failed' in m for m in warns
        ), f'unexpected reset WARN: {warns}'


# ---------------------------------------------------------------------------
# State capture under sync invoke() — local-ContextVar fallback path
# ---------------------------------------------------------------------------


class TestAgentStateCaptureSyncInvoke:
    """Integration coverage for the sync invoke path. The async tests
    above exercise the LangChain config bridge; this class drives a
    real ``StateGraph`` through ``graph.invoke(...)`` so a regression
    that breaks the local-ContextVar fallback (e.g., the bridge
    returning ``scope_active=True`` with ``bridge_handler is None`` for
    the sync code path) cannot pass while the async tests still do.
    """

    def _make_handler(self, _patch_transport, **kwargs):
        kwargs.setdefault('stack_ids', ['test-stack'])
        return BeaconLangGraphGovernanceHandler(**kwargs)

    def _serialized_tool(self, name='search'):
        return {'name': name, 'id': ['langchain', 'tools', name]}

    def test_state_visible_under_sync_invoke(
        self, _patch_transport, allow_response,
    ):
        """A LangGraph node driven by sync ``invoke`` carries state to
        governance evaluations via the local-ContextVar fallback.
        """
        pytest.importorskip('langgraph')
        from typing import TypedDict

        from langgraph.graph import StateGraph

        class S(TypedDict, total=False):
            documentation_type: str

        handler = self._make_handler(_patch_transport, include_state=True)

        captured: list[dict] = []

        def fake_evaluate(**kwargs):
            captured.append(kwargs.get('extra', {}))
            return allow_response

        def node(state: S) -> S:
            handler.on_tool_start(
                self._serialized_tool('save'), '{}', run_id=uuid4(),
            )
            return state

        builder = StateGraph(S)
        builder.add_node('extract', node)
        builder.set_entry_point('extract')
        builder.set_finish_point('extract')
        graph = builder.compile()

        with patch.object(
            handler._client, 'evaluate', side_effect=fake_evaluate,
        ):
            graph.invoke(
                {'documentation_type': 'technical'},
                config={'callbacks': [handler]},
            )

        tool_evals = [
            e for e in captured if isinstance(e, dict) and 'tool' in e
        ]
        assert tool_evals, 'no tool evaluation captured'
        assert tool_evals[0]['context']['state'] == {
            'documentation_type': 'technical',
        }
        assert 'state_unavailable' not in tool_evals[0]['context']


# ---------------------------------------------------------------------------
# Diagnostic-log coverage for state-resolution failure paths
# ---------------------------------------------------------------------------


class TestStateResolutionDiagnostics:
    """Lock in the loud-failure side of the resolution chain. A regression
    that silences these signals would let state-resolution failures
    pass without operator-visible signal — which is the failure mode
    that hides ``include_state=True`` users from missing state under
    async streaming.
    """

    def _make_handler(self, _patch_transport, **kwargs):
        kwargs.setdefault('stack_ids', ['test-stack'])
        return BeaconLangGraphGovernanceHandler(**kwargs)

    def test_runnable_config_var_missing_warns_once_on_version_skew(
        self, _patch_transport, caplog, monkeypatch,
    ):
        """When langchain_core is installed but var_child_runnable_config
        cannot be imported, log WARN once. Subsequent calls stay silent.
        """
        pytest.importorskip('langchain_core.runnables.config')

        import langchain_core.runnables.config as cfg_mod

        from lumenova_beacon.governance import _state as governance_state

        monkeypatch.setattr(governance_state, '_var_child_runnable_config', None)
        monkeypatch.setattr(governance_state, '_runnable_config_warned', False)
        monkeypatch.delattr(cfg_mod, 'var_child_runnable_config', raising=False)

        with caplog.at_level('WARNING', logger='lumenova_beacon.governance._state'):
            assert governance_state._get_runnable_config_var() is None
            assert governance_state._get_runnable_config_var() is None

        skew_warnings = [
            r for r in caplog.records
            if r.levelname == 'WARNING'
            and 'var_child_runnable_config is unavailable' in r.getMessage()
        ]
        assert len(skew_warnings) == 1, (
            f'expected exactly one WARN on version skew, got {len(skew_warnings)}: '
            f'{[r.getMessage() for r in skew_warnings]}'
        )

    def test_no_state_resolved_logs_diagnostic_at_debug(
        self, _patch_transport, allow_response, caplog,
    ):
        """When include_state=True but no node ran, ship context without
        state and emit a DEBUG line that names every fallback we tried.
        """
        from lumenova_beacon.governance._state import _active_node_run_id

        handler = self._make_handler(_patch_transport, include_state=True)
        _active_node_run_id.set(None)

        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval, caplog.at_level(
            'DEBUG', logger='lumenova_beacon.governance.integrations.langchain',
        ):
            handler.on_tool_start(
                {'name': 'save', 'id': ['langchain', 'tools', 'save']},
                '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert 'state' not in ctx

        diagnostics = [
            r.getMessage() for r in caplog.records
            if r.levelname == 'DEBUG'
            and 'no state resolved' in r.getMessage()
        ]
        assert len(diagnostics) == 1, (
            f'expected one no-state-resolved DEBUG, got: {diagnostics}'
        )
        msg = diagnostics[0]
        assert 'scope_active=' in msg
        assert 'cfg_run_id=' in msg
        assert 'cfg_parent_run_id=' in msg
        assert 'local_node_run_id=' in msg

    def test_lookup_state_for_aborts_on_cycle(
        self, _patch_transport, caplog, monkeypatch,
    ):
        """A cycle in ``_chain_parents`` must terminate the walk, return
        ``None``, and emit a single WARN. Without the bound a stray
        cycle (introduced by a future refactor of on_chain_start
        bookkeeping) would hang the walk for every governance
        evaluation.
        """
        from lumenova_beacon.governance import _state as governance_state
        from lumenova_beacon.governance._state import lookup_state_for

        monkeypatch.setattr(
            governance_state, '_CHAIN_PARENTS_WALK_MAX', 4,
        )

        handler = self._make_handler(_patch_transport, include_state=True)
        a, b, c = uuid4(), uuid4(), uuid4()
        # a -> b -> c -> a (no run carries state, so the walk is forced
        # to traverse the full cycle).
        handler._chain_parents[a] = b
        handler._chain_parents[b] = c
        handler._chain_parents[c] = a

        with caplog.at_level(
            'WARNING', logger='lumenova_beacon.governance._state',
        ):
            assert lookup_state_for(handler, a) is None

        cycle_warns = [
            r.getMessage() for r in caplog.records
            if r.levelname == 'WARNING'
            and '_chain_parents walk exceeded' in r.getMessage()
        ]
        assert len(cycle_warns) == 1, (
            f'expected one cycle WARN, got {cycle_warns}'
        )
        assert 'cycle or pathological chain depth' in cycle_warns[0]

    def test_set_agent_state_aborts_on_cycle(
        self, _patch_transport, caplog, monkeypatch,
    ):
        """``set_agent_state`` walks ``_chain_parents`` from
        ``_active_node_run_id``; a cycle must abort cleanly so the call
        becomes a no-op rather than hanging the user node.
        """
        from lumenova_beacon.governance import _state as governance_state
        from lumenova_beacon.governance._state import (
            _active_handler,
            _active_node_run_id,
            set_agent_state,
        )

        monkeypatch.setattr(
            governance_state, '_CHAIN_PARENTS_WALK_MAX', 4,
        )

        handler = self._make_handler(_patch_transport, include_state=True)
        a, b = uuid4(), uuid4()
        handler._chain_parents[a] = b
        handler._chain_parents[b] = a  # cycle, no _node_state entries

        _active_handler.set(handler)
        _active_node_run_id.set(a)

        with caplog.at_level(
            'WARNING', logger='lumenova_beacon.governance._state',
        ):
            set_agent_state({'documentation_type': 'technical'})

        # No _node_state entry was reachable, so set_agent_state must
        # have fallen through to the no-op log path — it is *not*
        # allowed to silently write to a dead key.
        assert handler._node_state == {}
        cycle_warns = [
            r.getMessage() for r in caplog.records
            if r.levelname == 'WARNING'
            and '_chain_parents walk exceeded' in r.getMessage()
        ]
        # Walk runs once per seed (run_id, parent_run_id); the cycle
        # trips the bound on the first seed and stops.
        assert cycle_warns, f'expected at least one cycle WARN: {caplog.records}'
        for msg in cycle_warns:
            assert 'cycle or pathological chain depth' in msg

    def test_resolve_active_node_handles_non_dict_config(
        self, _patch_transport, caplog, monkeypatch,
    ):
        """A non-dict ``var_child_runnable_config.get()`` falls back to
        local ContextVars and WARNs once. Guards against a future
        langchain_core change that swaps the bridge value's shape from
        beneath us — without this branch the bridge would silently
        appear active to ``_resolve_active_node`` and downstream callers
        would treat us as inside a Runnable scope when we aren't.
        """
        from contextvars import ContextVar

        from lumenova_beacon.governance import _state as governance_state

        fake_var: ContextVar = ContextVar('fake_runnable_cfg', default=None)
        fake_var.set('not-a-dict')
        monkeypatch.setattr(governance_state, '_var_child_runnable_config', fake_var)
        monkeypatch.setattr(governance_state, '_malformed_cfg_warned', False)

        with caplog.at_level('WARNING', logger='lumenova_beacon.governance._state'):
            handler, run_id, parent_run_id, scope_active = (
                governance_state._resolve_active_node()
            )
            # Second call must stay silent — warn-once.
            governance_state._resolve_active_node()

        assert (handler, run_id, parent_run_id, scope_active) == (None, None, None, False)
        skew_warns = [
            r for r in caplog.records
            if r.levelname == 'WARNING'
            and 'returned a str, not a' in r.getMessage()
        ]
        assert len(skew_warns) == 1, (
            f'expected one malformed-cfg WARN, got: '
            f'{[r.getMessage() for r in skew_warns]}'
        )

    def test_resolve_active_node_handles_missing_callbacks_key(
        self, _patch_transport, caplog, monkeypatch,
    ):
        """A bridge config without a ``callbacks`` entry falls back to
        local ContextVars and WARNs once. Same protection as the
        non-dict branch — the bridge looks active but is unusable.
        """
        from contextvars import ContextVar

        from lumenova_beacon.governance import _state as governance_state

        fake_var: ContextVar = ContextVar('fake_runnable_cfg', default=None)
        fake_var.set({'tags': ['x'], 'metadata': {}})
        monkeypatch.setattr(governance_state, '_var_child_runnable_config', fake_var)
        monkeypatch.setattr(governance_state, '_malformed_cfg_warned', False)

        with caplog.at_level('WARNING', logger='lumenova_beacon.governance._state'):
            result = governance_state._resolve_active_node()
            governance_state._resolve_active_node()

        assert result == (None, None, None, False)
        skew_warns = [
            r for r in caplog.records
            if r.levelname == 'WARNING'
            and 'no `callbacks` entry' in r.getMessage()
        ]
        assert len(skew_warns) == 1, (
            f'expected one missing-callbacks WARN, got: '
            f'{[r.getMessage() for r in skew_warns]}'
        )

    def test_set_agent_state_warns_when_handler_present_but_unresolved(
        self, _patch_transport, caplog, monkeypatch,
    ):
        """When a handler is registered but the walk can't anchor a
        node (cycle / walk-cap), ``set_agent_state`` discards the user's
        mutation and logs WARN — DEBUG would let the silent-drop go
        unnoticed in production.
        """
        from lumenova_beacon.governance import _state as governance_state
        from lumenova_beacon.governance._state import (
            _active_handler,
            _active_node_run_id,
            set_agent_state,
        )

        monkeypatch.setattr(governance_state, '_CHAIN_PARENTS_WALK_MAX', 4)

        handler = self._make_handler(_patch_transport, include_state=True)
        a, b = uuid4(), uuid4()
        handler._chain_parents[a] = b
        handler._chain_parents[b] = a  # cycle, no _node_state entry

        _active_handler.set(handler)
        _active_node_run_id.set(a)

        with caplog.at_level('WARNING', logger='lumenova_beacon.governance._state'):
            set_agent_state({'documentation_type': 'technical'})

        drop_warns = [
            r.getMessage() for r in caplog.records
            if r.levelname == 'WARNING'
            and 'dropping state mutation' in r.getMessage()
        ]
        assert len(drop_warns) == 1, (
            f'expected one drop WARN, got: {drop_warns}'
        )

    def test_set_agent_state_outside_graph_stays_at_debug(
        self, caplog,
    ):
        """The opposite case of the test above: outside any graph,
        ``set_agent_state`` is a silent no-op (DEBUG only). Verifies
        the two no-op cases — ``handler is None`` (legitimate, debug)
        vs. ``handler present + run_id None`` (regression, warn) — are
        correctly split.
        """
        from lumenova_beacon.governance import set_agent_state

        with caplog.at_level('WARNING', logger='lumenova_beacon.governance._state'):
            set_agent_state({'k': 'v'})

        assert not [
            r for r in caplog.records if r.levelname == 'WARNING'
        ], 'unexpected WARN when set_agent_state called outside a graph'

    def test_state_unavailable_marker_when_node_active_but_state_missing(
        self, _patch_transport, allow_response, run_id,
    ):
        """``input.context.state_unavailable=True`` fires when a node
        is apparently active but state lookup fails. OPA policies that
        negate against ``input.context.state`` can read this marker to
        fail-closed instead of silently flipping allow/block.
        """
        from lumenova_beacon.governance._state import _active_node_run_id

        handler = self._make_handler(_patch_transport, include_state=True)
        # Local ContextVar set (graph context detected) but the run_id
        # has no state entry and no parents to walk into.
        _active_node_run_id.set(run_id)

        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                {'name': 'save', 'id': ['langchain', 'tools', 'save']},
                '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert 'state' not in ctx
            assert ctx.get('state_unavailable') is True

    def test_no_state_unavailable_marker_when_outside_graph(
        self, _patch_transport, allow_response,
    ):
        """The inverse: when no node was apparently active (callback
        fired outside a graph entirely), the marker stays absent.
        Otherwise every plain LangChain agent run with the default
        ``include_state=True`` would emit ``state_unavailable=True``
        for every evaluation — useless noise to policies.
        """
        from lumenova_beacon.governance._state import _active_node_run_id

        handler = self._make_handler(_patch_transport, include_state=True)
        _active_node_run_id.set(None)

        with patch.object(
            handler._client, 'evaluate', return_value=allow_response,
        ) as mock_eval:
            handler.on_tool_start(
                {'name': 'save', 'id': ['langchain', 'tools', 'save']},
                '{}', run_id=uuid4(),
            )
            ctx = mock_eval.call_args.kwargs['extra']['context']
            assert 'state' not in ctx
            assert 'state_unavailable' not in ctx
