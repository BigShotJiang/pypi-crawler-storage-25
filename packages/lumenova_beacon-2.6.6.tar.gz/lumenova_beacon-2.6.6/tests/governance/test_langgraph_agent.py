"""Tests for BeaconLangGraphAgent (governance wrapper around a compiled graph)."""

from __future__ import annotations

from typing import Annotated, Sequence, TypedDict
from unittest.mock import MagicMock, patch

import pytest

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    ToolMessage,
)
from langchain_core.tools import tool

pytest.importorskip('langgraph')

from langgraph.checkpoint.memory import MemorySaver  # noqa: E402
from langgraph.graph import END, StateGraph, add_messages  # noqa: E402
from langgraph.prebuilt import ToolNode  # noqa: E402

from lumenova_beacon.exceptions import (
    GovernanceConfigurationError,
    GovernanceViolationError,
)
from lumenova_beacon.governance import BeaconLangGraphAgent, GovernanceConfig


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@tool
def send_email(to: str, subject: str) -> str:
    """Send an email."""
    return f'sent to {to}'


@tool
def get_weather(location: str) -> str:
    """Get the weather."""
    return f'sunny in {location}'


class _MessagesState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]


class _HistoryState(TypedDict):
    history: Annotated[Sequence[BaseMessage], add_messages]


def _planned_agent_node(planned: list[BaseMessage]):
    """Return a node that emits the next planned message each call."""
    idx = {'i': 0}

    def call_model(state: _MessagesState) -> dict:
        msg = planned[idx['i']]
        idx['i'] += 1
        return {'messages': [msg]}

    return call_model


def _should_continue(state: _MessagesState) -> str:
    last = state['messages'][-1]
    if isinstance(last, AIMessage) and last.tool_calls:
        return 'tools'
    return END


def _build_graph(
    planned: list[BaseMessage],
    *,
    tools_list: list = None,
    state_cls: type = _MessagesState,
    state_key: str = 'messages',
):
    tools_list = tools_list or [send_email, get_weather]

    def call_model(state):
        i = getattr(call_model, '_i', 0)
        msg = planned[i]
        setattr(call_model, '_i', i + 1)
        return {state_key: [msg]}

    setattr(call_model, '_i', 0)

    workflow = StateGraph(state_cls)
    workflow.add_node('agent', call_model)
    workflow.add_node('tools', ToolNode(tools_list, messages_key=state_key))
    workflow.set_entry_point('agent')

    def cont(state):
        last = state[state_key][-1]
        if isinstance(last, AIMessage) and last.tool_calls:
            return 'tools'
        return END

    workflow.add_conditional_edges('agent', cont, {'tools': 'tools', END: END})
    workflow.add_edge('tools', 'agent')
    return workflow.compile(checkpointer=MemorySaver())


@pytest.fixture
def mock_governance_client():
    """Patch governance evaluation + get_client so no real backend / config is needed."""
    response = {
        'decision': 'block',
        'message': 'send_email is forbidden',
        'rules_evaluated': [{'name': 'no-emails'}],
        'latency_ms': 1.0,
    }

    async def _async_response(*args, **kwargs):
        return response

    client = MagicMock()
    client.config = MagicMock(
        session_id=None,
        environment=None,
        user_email=None,
        user_name=None,
        user_id=None,
        record_stacktrace=False,
    )
    client.timestamp_override = None
    client.should_sample = MagicMock(return_value=False)

    with (
        patch(
            'lumenova_beacon.tracing.integrations.langchain.get_client',
            return_value=client,
        ),
        patch(
            'lumenova_beacon.core.client.get_client',
            return_value=client,
        ),
        patch(
            'lumenova_beacon.governance.client.get_transport',
            return_value=MagicMock(
                headers={'Authorization': 'Bearer test'},
                timeout=10.0,
                verify=True,
            ),
        ),
        patch(
            'lumenova_beacon.governance.client.get_base_url',
            return_value='https://api.test.com',
        ),
        patch(
            'lumenova_beacon.governance.integrations.langchain.evaluate_or_fail_open',
            return_value=response,
        ),
        patch(
            'lumenova_beacon.governance.integrations.langchain.aevaluate_or_fail_open',
            side_effect=_async_response,
        ),
    ):
        yield response


@pytest.fixture
def gov_config():
    return GovernanceConfig(stack_ids=['s1'], enabled_hooks={'pre_tool', 'post_tool'})


# ---------------------------------------------------------------------------
# raise mode
# ---------------------------------------------------------------------------


class TestRaiseMode:
    def test_invoke_raises(self, mock_governance_client, gov_config):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-raise-1',
            governance=gov_config,
            violation_mode='raise',
        )
        with pytest.raises(GovernanceViolationError) as exc_info:
            agent.invoke({'messages': [HumanMessage(content='go')]})
        assert exc_info.value.phase == 'pre_tool'
        assert exc_info.value.tool_call_id == 'call_1'

    @pytest.mark.asyncio
    async def test_ainvoke_raises(self, mock_governance_client, gov_config):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-raise-2',
            governance=gov_config,
            violation_mode='raise',
        )
        with pytest.raises(GovernanceViolationError):
            await agent.ainvoke({'messages': [HumanMessage(content='go')]})

    def test_stream_raises(self, mock_governance_client, gov_config):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-raise-3',
            governance=gov_config,
            violation_mode='raise',
        )
        with pytest.raises(GovernanceViolationError):
            for _ in agent.stream({'messages': [HumanMessage(content='go')]}):
                pass


# ---------------------------------------------------------------------------
# state mode — tool-phase reconciliation
# ---------------------------------------------------------------------------


class TestStateModeToolPhase:
    def test_invoke_appends_tool_messages_for_all_unanswered_calls(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}},
                {'id': 'call_2', 'name': 'get_weather', 'args': {'location': 'london'}},
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-state-tool-1',
            governance=gov_config,
            violation_mode='state',
        )
        result = agent.invoke({'messages': [HumanMessage(content='go')]})

        tool_messages = [m for m in result['messages'] if isinstance(m, ToolMessage)]
        assert len(tool_messages) == 2
        ids = {m.tool_call_id for m in tool_messages}
        assert ids == {'call_1', 'call_2'}

        blocked = next(m for m in tool_messages if m.tool_call_id == 'call_1')
        assert 'send_email is forbidden' in str(blocked.content)
        assert blocked.additional_kwargs['beacon_governance_violation'] is True

        sibling = next(m for m in tool_messages if m.tool_call_id == 'call_2')
        assert 'Skipped' in str(sibling.content)
        assert sibling.additional_kwargs['beacon_governance_violation_sibling'] is True

    def test_state_persisted_via_checkpointer(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-state-tool-2',
            governance=gov_config,
            violation_mode='state',
        )
        agent.invoke({'messages': [HumanMessage(content='go')]})

        state = graph.get_state(agent.beacon_config.get_config())
        tools = [m for m in state.values['messages'] if isinstance(m, ToolMessage)]
        assert any(m.tool_call_id == 'call_1' for m in tools)

    def test_stream_closes_cleanly(self, mock_governance_client, gov_config):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-state-tool-3',
            governance=gov_config,
            violation_mode='state',
        )
        chunks = list(agent.stream({'messages': [HumanMessage(content='go')]}))
        # Final chunk is our reconciliation update.
        assert any('messages' in chunk for chunk in chunks)


# ---------------------------------------------------------------------------
# state mode — LLM-phase reconciliation
# ---------------------------------------------------------------------------


class TestStateModeLLMPhase:
    def test_invoke_appends_ai_message_for_llm_block(
        self,
        mock_governance_client,
        gov_config,
    ):
        # Enable LLM hooks for this test.
        gov_config_llm = GovernanceConfig(
            stack_ids=['s1'],
            enabled_hooks={'pre_llm'},
        )

        # Use a real chat model wrapper that triggers on_chat_model_start.
        from langchain_core.language_models.fake_chat_models import FakeListChatModel

        fake_llm = FakeListChatModel(responses=['final answer'])

        def call_model(state):
            return {'messages': [fake_llm.invoke(state['messages'])]}

        workflow = StateGraph(_MessagesState)
        workflow.add_node('agent', call_model)
        workflow.set_entry_point('agent')
        workflow.add_edge('agent', END)
        graph = workflow.compile(checkpointer=MemorySaver())

        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-state-llm-1',
            governance=gov_config_llm,
            violation_mode='state',
        )
        result = agent.invoke({'messages': [HumanMessage(content='go')]})
        ai_messages = [m for m in result['messages'] if isinstance(m, AIMessage)]
        # Last AIMessage is the synthetic violation message.
        violation = ai_messages[-1]
        assert violation.additional_kwargs.get('beacon_governance_violation') is True
        assert violation.additional_kwargs.get('phase') == 'pre_llm'
        assert 'send_email is forbidden' in str(violation.content)


# ---------------------------------------------------------------------------
# emit mode
# ---------------------------------------------------------------------------


class TestEmitMode:
    @pytest.mark.asyncio
    async def test_astream_events_yields_custom_event(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-emit-1',
            governance=gov_config,
            violation_mode='emit',
        )

        violation_events = []
        async for event in agent.astream_events(
            {'messages': [HumanMessage(content='go')]},
        ):
            if event.get('name') == 'beacon.governance.violation':
                violation_events.append(event)

        assert len(violation_events) == 1
        ev = violation_events[0]
        assert ev['event'] == 'on_custom_event'
        assert ev['data']['phase'] == 'pre_tool'
        assert ev['data']['tool_call_id'] == 'call_1'
        assert 'send_email is forbidden' in ev['data']['message']
        assert ev['data']['policies']

    def test_invoke_falls_back_to_state(self, mock_governance_client, gov_config):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-emit-2',
            governance=gov_config,
            violation_mode='emit',
        )
        result = agent.invoke({'messages': [HumanMessage(content='go')]})
        tools = [m for m in result['messages'] if isinstance(m, ToolMessage)]
        assert any(m.tool_call_id == 'call_1' for m in tools)


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_non_violation_errors_propagate(self, mock_governance_client, gov_config):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-edge-1',
            governance=gov_config,
            violation_mode='state',
        )

        # Make the graph raise something else, governance unrelated.
        with patch.object(
            graph,
            'invoke',
            side_effect=GovernanceConfigurationError('bad config'),
        ):
            with pytest.raises(GovernanceConfigurationError):
                agent.invoke({'messages': [HumanMessage(content='go')]})

    def test_custom_state_key(self, mock_governance_client, gov_config):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph(
            [ai],
            state_cls=_HistoryState,
            state_key='history',
        )
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-edge-2',
            governance=gov_config,
            violation_mode='state',
            violation_state_key='history',
        )
        result = agent.invoke({'history': [HumanMessage(content='go')]})
        assert 'history' in result
        tools = [m for m in result['history'] if isinstance(m, ToolMessage)]
        assert any(m.tool_call_id == 'call_1' for m in tools)

    def test_caller_config_is_merged_not_replaced(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(content='no tools')
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-edge-3',
            governance=gov_config,
            violation_mode='state',
        )

        extra_cb = MagicMock()
        observed: list[dict] = []
        original_invoke = graph.invoke

        def spy(input, config=None, **kw):
            observed.append(config)
            return original_invoke(input, config=config, **kw)

        with patch.object(graph, 'invoke', side_effect=spy):
            agent.invoke(
                {'messages': [HumanMessage(content='go')]},
                config={'tags': ['user-tag'], 'callbacks': [extra_cb]},
            )

        assert observed, 'graph.invoke was not called'
        merged = observed[0]
        assert 'user-tag' in merged.get('tags', [])
        assert extra_cb in merged.get('callbacks', [])
        # Beacon's own handlers should still be present.
        assert len(merged['callbacks']) >= 2

    def test_invalid_violation_mode_rejected(self, mock_governance_client, gov_config):
        with pytest.raises(ValueError, match='violation_mode'):
            BeaconLangGraphAgent(
                graph=_build_graph([AIMessage(content='ok')]),
                thread_id='t-edge-4',
                governance=gov_config,
                violation_mode='oops',  # type: ignore[arg-type]
            )

    def test_post_hoc_violation_raises_when_toolnode_swallows(
        self,
        mock_governance_client,
        gov_config,
    ):
        """ToolNode(handle_tool_errors=True) catches the GovernanceViolationError,
        but the wrapper should still surface it via the post-hoc violation_count
        snapshot + handler.last_violation.
        """
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )

        # Build a graph where ToolNode swallows tool errors.
        def call_model(state):
            i = getattr(call_model, '_i', 0)
            setattr(call_model, '_i', i + 1)
            return {'messages': [ai] if i == 0 else [AIMessage(content='done')]}

        workflow = StateGraph(_MessagesState)
        workflow.add_node('agent', call_model)
        workflow.add_node('tools', ToolNode([send_email, get_weather], handle_tool_errors=True))
        workflow.set_entry_point('agent')

        def cont(state):
            last = state['messages'][-1]
            if isinstance(last, AIMessage) and last.tool_calls:
                return 'tools'
            return END

        workflow.add_conditional_edges('agent', cont, {'tools': 'tools', END: END})
        workflow.add_edge('tools', 'agent')
        graph = workflow.compile(checkpointer=MemorySaver())

        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-posthoc-raise',
            governance=gov_config,
            violation_mode='raise',
        )
        with pytest.raises(GovernanceViolationError) as exc_info:
            agent.invoke({'messages': [HumanMessage(content='go')]})
        assert exc_info.value.phase == 'pre_tool'
        assert exc_info.value.tool_call_id == 'call_1'

    def test_post_hoc_no_violation_returns_result(
        self,
        mock_governance_client,
        gov_config,
    ):
        """When no violation occurs, the wrapper returns the graph result unchanged."""
        # Make the mocked governance evaluation allow everything.
        mock_governance_client['decision'] = 'allow'
        mock_governance_client['message'] = None

        ai = AIMessage(content='hello world')
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-posthoc-allow',
            governance=gov_config,
            violation_mode='raise',
        )
        result = agent.invoke({'messages': [HumanMessage(content='hi')]})
        assert 'messages' in result
        assert any(
            isinstance(m, AIMessage) and m.content == 'hello world' for m in result['messages']
        )

    def test_chunk_based_reconciliation_when_state_rolls_back(
        self,
        mock_governance_client,
        gov_config,
    ):
        """If graph.get_state can't see the AIMessage (superstep rollback path),
        the wrapper should recover it from the streamed chunk and still emit
        a proper ToolMessage instead of a fallback AIMessage.
        """
        from unittest.mock import patch

        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-chunk-fallback',
            governance=gov_config,
            violation_mode='state',
        )

        # Simulate the rollback: make _read_state_messages return only the
        # HumanMessage, as if the agent's superstep was rolled back.
        original_read = agent._read_state_messages
        first_call = {'done': False}

        def stubbed_read(config):
            # On the reconciliation read, return state WITHOUT the AIMessage.
            if not first_call['done']:
                first_call['done'] = True
                return [HumanMessage(content='go')]
            return original_read(config)

        with patch.object(agent, '_read_state_messages', side_effect=stubbed_read):
            messages = list(agent.stream({'messages': [HumanMessage(content='go')]}))

        # The reconciliation chunk should contain a ToolMessage answering call_1,
        # NOT a fallback AIMessage — because the chunk-derived seen_messages
        # supplied the missing AIMessage.
        final_chunk = messages[-1]
        assert 'messages' in final_chunk
        reconciled = final_chunk['messages']
        tool_msgs = [m for m in reconciled if isinstance(m, ToolMessage)]
        assert any(m.tool_call_id == 'call_1' for m in tool_msgs), (
            f'expected a ToolMessage for call_1; got {reconciled}'
        )

    def test_openai_invariant_after_state_recovery(
        self,
        mock_governance_client,
        gov_config,
    ):
        """After a tool-phase block, every tool_call has a ToolMessage."""
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}},
                {'id': 'call_2', 'name': 'get_weather', 'args': {'location': 'london'}},
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-edge-5',
            governance=gov_config,
            violation_mode='state',
        )
        result = agent.invoke({'messages': [HumanMessage(content='go')]})

        last_ai = next(m for m in reversed(result['messages']) if isinstance(m, AIMessage))
        ai_idx = result['messages'].index(last_ai)
        tool_msgs_after = [
            m for m in result['messages'][ai_idx + 1 :] if isinstance(m, ToolMessage)
        ]
        answered = {m.tool_call_id for m in tool_msgs_after}
        declared = {tc['id'] for tc in last_ai.tool_calls}
        assert declared - answered == set(), f'Unanswered tool_calls remain: {declared - answered}'


# ---------------------------------------------------------------------------
# Handler-level: last_violation is stamped on every raise site
# ---------------------------------------------------------------------------


class TestLastViolation:
    """Direct tests for BeaconLangGraphGovernanceHandler.last_violation.

    The wrapper's post-hoc swallow detection (when ToolNode(handle_tool_errors=True)
    catches the exception) depends on `last_violation` being set before every
    raise.  Without these tests, a regression dropping `_last_violation = err`
    from any of the 6 raise sites would only be caught implicitly.
    """

    @staticmethod
    def _build_handler(enabled_hooks=None):
        from lumenova_beacon.governance.integrations.langchain import (
            BeaconLangGraphGovernanceHandler,
        )

        return BeaconLangGraphGovernanceHandler(
            stack_ids=['s1'],
            enabled_hooks=enabled_hooks or {'pre_tool', 'post_tool'},
            agent_name='test',
        )

    def test_last_violation_set_on_callback_tool_start(self, mock_governance_client):
        handler = self._build_handler()
        with pytest.raises(GovernanceViolationError):
            handler.on_tool_start(
                serialized={'name': 'send_email'},
                input_str='to=a@b',
                tool_call_id='call_42',
            )
        assert handler.last_violation is not None
        assert handler.last_violation.phase == 'pre_tool'
        assert handler.last_violation.tool_call_id == 'call_42'

    def test_last_violation_set_on_callback_chat_model_start(
        self,
        mock_governance_client,
    ):
        handler = self._build_handler(enabled_hooks={'pre_llm'})
        with pytest.raises(GovernanceViolationError):
            handler.on_chat_model_start(
                serialized={'name': 'gpt-4o-mini'},
                messages=[[HumanMessage(content='hi')]],
            )
        assert handler.last_violation is not None
        assert handler.last_violation.phase == 'pre_llm'
        assert handler.last_violation.tool_call_id is None

    def test_reset_clears_last_violation(self, mock_governance_client):
        handler = self._build_handler()
        with pytest.raises(GovernanceViolationError):
            handler.on_tool_start(
                serialized={'name': 'send_email'},
                input_str='to=a@b',
                tool_call_id='call_1',
            )
        assert handler.last_violation is not None
        handler.reset()
        assert handler.last_violation is None
        assert handler.violation_count == 0

    def test_last_violation_preserved_across_wrapper_post_hoc(
        self,
        mock_governance_client,
        gov_config,
    ):
        """End-to-end: post-hoc swallow recovers full phase/tool_call_id."""
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_99', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )

        def call_model(state):
            i = getattr(call_model, '_i', 0)
            setattr(call_model, '_i', i + 1)
            return {'messages': [ai] if i == 0 else [AIMessage(content='done')]}

        workflow = StateGraph(_MessagesState)
        workflow.add_node('agent', call_model)
        workflow.add_node(
            'tools',
            ToolNode([send_email, get_weather], handle_tool_errors=True),
        )
        workflow.set_entry_point('agent')

        def cont(state):
            last = state['messages'][-1]
            if isinstance(last, AIMessage) and last.tool_calls:
                return 'tools'
            return END

        workflow.add_conditional_edges('agent', cont, {'tools': 'tools', END: END})
        workflow.add_edge('tools', 'agent')
        graph = workflow.compile(checkpointer=MemorySaver())

        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-last-violation-e2e',
            governance=gov_config,
            violation_mode='raise',
        )
        with pytest.raises(GovernanceViolationError) as exc_info:
            agent.invoke({'messages': [HumanMessage(content='go')]})
        # The handler-side last_violation matches the raised exception.
        handler = agent.beacon_config.governance_handler
        assert handler.last_violation is exc_info.value
        assert handler.last_violation.phase == 'pre_tool'
        assert handler.last_violation.tool_call_id == 'call_99'


# ---------------------------------------------------------------------------
# Stateless graph (no checkpointer) — wrapper degrades gracefully
# ---------------------------------------------------------------------------


class TestStatelessGraph:
    """Graphs compiled without a checkpointer must not crash the wrapper."""

    @staticmethod
    def _stateless_graph_with_blocked_tool(ai: AIMessage):
        def call_model(state):
            i = getattr(call_model, '_i', 0)
            setattr(call_model, '_i', i + 1)
            return {'messages': [ai] if i == 0 else [AIMessage(content='done')]}

        setattr(call_model, '_i', 0)

        workflow = StateGraph(_MessagesState)
        workflow.add_node('agent', call_model)
        workflow.add_node('tools', ToolNode([send_email, get_weather]))
        workflow.set_entry_point('agent')

        def cont(state):
            last = state['messages'][-1]
            if isinstance(last, AIMessage) and last.tool_calls:
                return 'tools'
            return END

        workflow.add_conditional_edges('agent', cont, {'tools': 'tools', END: END})
        workflow.add_edge('tools', 'agent')
        return workflow.compile()  # no checkpointer

    def test_invoke_state_mode_degrades_to_ai_message(
        self,
        mock_governance_client,
        gov_config,
    ):
        """Without a checkpointer the wrapper cannot read state and has no
        stream chunks to recover the AIMessage from on the invoke path —
        it degrades to a single AIMessage carrying the policy message
        rather than crashing.
        """
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = self._stateless_graph_with_blocked_tool(ai)
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-stateless-1',
            governance=gov_config,
            violation_mode='state',
        )
        result = agent.invoke({'messages': [HumanMessage(content='go')]})
        assert 'messages' in result
        ai_messages = [m for m in result['messages'] if isinstance(m, AIMessage)]
        assert ai_messages, 'expected at least one AIMessage in degraded result'
        synthetic = ai_messages[-1]
        assert synthetic.additional_kwargs.get('beacon_governance_violation') is True
        assert 'send_email is forbidden' in str(synthetic.content)

    def test_stream_state_mode_recovers_via_chunks(
        self,
        mock_governance_client,
        gov_config,
    ):
        """Streaming entry points capture the AIMessage from chunks before
        the violation fires, so the wrapper can synthesise a proper
        ToolMessage even without a checkpointer.
        """
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = self._stateless_graph_with_blocked_tool(ai)
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-stateless-2',
            governance=gov_config,
            violation_mode='state',
        )
        chunks = list(agent.stream({'messages': [HumanMessage(content='go')]}))
        terminal = chunks[-1]
        assert isinstance(terminal, dict) and 'messages' in terminal
        tool_msgs = [m for m in terminal['messages'] if isinstance(m, ToolMessage)]
        assert any(
            m.tool_call_id == 'call_1' and m.additional_kwargs.get('beacon_governance_violation')
            for m in tool_msgs
        )


# ---------------------------------------------------------------------------
# Post-hoc swallow path — state mode does not duplicate ToolNode's ToolMessage
# ---------------------------------------------------------------------------


class TestPostHocStateMode:
    def test_state_mode_does_not_duplicate_toolnode_error_message(
        self,
        mock_governance_client,
        gov_config,
    ):
        """ToolNode(handle_tool_errors=True) writes its own error ToolMessage.
        In state mode the wrapper must NOT append a second one with the same
        tool_call_id — that would either duplicate or shift downstream
        consumer expectations.
        """
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )

        def call_model(state):
            i = getattr(call_model, '_i', 0)
            setattr(call_model, '_i', i + 1)
            return {'messages': [ai] if i == 0 else [AIMessage(content='done')]}

        workflow = StateGraph(_MessagesState)
        workflow.add_node('agent', call_model)
        workflow.add_node(
            'tools',
            ToolNode([send_email, get_weather], handle_tool_errors=True),
        )
        workflow.set_entry_point('agent')

        def cont(state):
            last = state['messages'][-1]
            if isinstance(last, AIMessage) and last.tool_calls:
                return 'tools'
            return END

        workflow.add_conditional_edges('agent', cont, {'tools': 'tools', END: END})
        workflow.add_edge('tools', 'agent')
        graph = workflow.compile(checkpointer=MemorySaver())

        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-posthoc-state',
            governance=gov_config,
            violation_mode='state',
        )
        result = agent.invoke({'messages': [HumanMessage(content='go')]})

        tool_msgs = [
            m
            for m in result['messages']
            if isinstance(m, ToolMessage) and m.tool_call_id == 'call_1'
        ]
        # Exactly one ToolMessage for call_1: ToolNode's own error message.
        # The wrapper must not have appended a Beacon-flagged duplicate.
        assert len(tool_msgs) == 1, (
            f'Expected exactly one ToolMessage for call_1; got {len(tool_msgs)}'
        )
        # And the surviving message is ToolNode's, not Beacon's.
        assert not tool_msgs[0].additional_kwargs.get('beacon_governance_violation')


# ---------------------------------------------------------------------------
# _persist_config strips callbacks / tags from update_state writes
# (regression coverage for commit 21651a8)
# ---------------------------------------------------------------------------


class TestPersistConfigStripsCallbacks:
    def test_update_state_called_without_callbacks_or_tags(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-persist-strip',
            governance=gov_config,
            violation_mode='state',
        )

        captured: list[dict] = []
        original_update = graph.update_state

        def spy(config, *args, **kwargs):
            captured.append(config)
            return original_update(config, *args, **kwargs)

        with patch.object(graph, 'update_state', side_effect=spy):
            agent.invoke(
                {'messages': [HumanMessage(content='go')]},
                config={'tags': ['user-tag'], 'callbacks': [MagicMock()]},
            )

        assert captured, 'graph.update_state was not called'
        for cfg in captured:
            assert 'callbacks' not in cfg, (
                f'callbacks must be stripped on persist path; got {cfg!r}'
            )
            assert 'tags' not in cfg, f'tags must be stripped on persist path; got {cfg!r}'


# ---------------------------------------------------------------------------
# Sync stream_events: added in langgraph 1.1 — gracefully skip on older
# installs where Pregel only implements astream_events.
# ---------------------------------------------------------------------------


def _pregel_has_stream_events() -> bool:
    """Probe whether the installed langgraph version exposes sync stream_events."""
    g = _build_graph([AIMessage(content='ok')])
    return hasattr(g, 'stream_events')


_REASON_NO_SYNC_STREAM_EVENTS = (
    'langgraph<1.1 only ships astream_events; sync stream_events was '
    'added in 1.1 — skipping the sync-events tests.'
)


class TestSyncStreamEvents:
    def test_method_is_always_exposed_on_wrapper(
        self,
        mock_governance_client,
        gov_config,
    ):
        """The wrapper advertises sync ``stream_events`` regardless of
        langgraph version.  Calls into it will AttributeError from the
        underlying graph on langgraph<1.1 — same failure mode as calling
        the bare compiled graph.
        """
        agent = BeaconLangGraphAgent(
            graph=_build_graph([AIMessage(content='ok')]),
            thread_id='t-sync-events-exposed',
            governance=gov_config,
            violation_mode='raise',
        )
        assert hasattr(agent, 'stream_events')
        assert callable(agent.stream_events)

    @pytest.mark.skipif(
        not _pregel_has_stream_events(),
        reason=_REASON_NO_SYNC_STREAM_EVENTS,
    )
    def test_stream_events_sync_walks_without_crashing(
        self,
        mock_governance_client,
        gov_config,
    ):
        # Use the allow-everything decision so the stream completes.
        mock_governance_client['decision'] = 'allow'
        mock_governance_client['message'] = None

        ai = AIMessage(content='hi')
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-sync-events',
            governance=gov_config,
            violation_mode='raise',
        )

        events = []
        for event in agent.stream_events(
            {'messages': [HumanMessage(content='go')]},
        ):
            events.append(event)
            if len(events) >= 1:
                break
        assert events, 'stream_events should yield at least one event'

    @pytest.mark.skipif(
        not _pregel_has_stream_events(),
        reason=_REASON_NO_SYNC_STREAM_EVENTS,
    )
    def test_stream_events_sync_raises_on_violation(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-sync-events-raise',
            governance=gov_config,
            violation_mode='raise',
        )
        with pytest.raises(GovernanceViolationError):
            for _ in agent.stream_events(
                {'messages': [HumanMessage(content='go')]},
            ):
                pass


# ---------------------------------------------------------------------------
# Stream emit mode: does not yield a state-shaped chunk after the event
# (regression coverage for the _stream_iter_sync asymmetry fix)
# ---------------------------------------------------------------------------


class TestStreamEmitMode:
    def test_emit_mode_stream_does_not_yield_state_chunk(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-stream-emit',
            governance=gov_config,
            violation_mode='emit',
        )

        chunks = list(agent.stream({'messages': [HumanMessage(content='go')]}))

        # The terminal yield is the synthesised event, not a state-shaped dict.
        violation_events = [
            c
            for c in chunks
            if isinstance(c, dict) and c.get('name') == 'beacon.governance.violation'
        ]
        assert violation_events, 'expected a synthesised violation event'

        # And there should be no trailing {messages: [...]} chunk produced by
        # the wrapper itself (the only legitimate `messages` chunks are those
        # emitted by graph.stream before the violation fired).
        terminal = chunks[-1]
        assert not (
            isinstance(terminal, dict) and 'messages' in terminal and 'event' not in terminal
        ), f'emit-mode stream must not yield a state-shaped chunk; got {terminal!r}'


# ---------------------------------------------------------------------------
# Async coverage: ainvoke + state, astream × state/emit
# ---------------------------------------------------------------------------


class TestAsyncDispatch:
    """Mirror the sync state/emit coverage on the async entry points.

    The async streaming helpers are near-duplicates of the sync ones; a
    dropped ``await`` or a missing ``async`` would silently produce
    coroutine-shaped state values. Behavioural assertions here lock the
    contract so the duplication does not drift.
    """

    @pytest.mark.asyncio
    async def test_ainvoke_state_mode_appends_tool_messages(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}},
                {'id': 'call_2', 'name': 'get_weather', 'args': {'location': 'london'}},
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-ainvoke-state',
            governance=gov_config,
            violation_mode='state',
        )
        result = await agent.ainvoke({'messages': [HumanMessage(content='go')]})

        tool_messages = [m for m in result['messages'] if isinstance(m, ToolMessage)]
        ids = {m.tool_call_id for m in tool_messages}
        assert ids == {'call_1', 'call_2'}
        blocked = next(m for m in tool_messages if m.tool_call_id == 'call_1')
        assert blocked.additional_kwargs['beacon_governance_violation'] is True

    @pytest.mark.asyncio
    async def test_astream_state_mode_yields_reconciliation(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-astream-state',
            governance=gov_config,
            violation_mode='state',
        )
        chunks = [c async for c in agent.astream({'messages': [HumanMessage(content='go')]})]

        terminal = chunks[-1]
        assert isinstance(terminal, dict) and 'messages' in terminal
        appended = terminal['messages']
        assert any(
            isinstance(m, ToolMessage) and m.tool_call_id == 'call_1' for m in appended
        )

    @pytest.mark.asyncio
    async def test_astream_emit_mode_yields_event(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-astream-emit',
            governance=gov_config,
            violation_mode='emit',
        )
        chunks = [c async for c in agent.astream({'messages': [HumanMessage(content='go')]})]

        events = [
            c for c in chunks
            if isinstance(c, dict) and c.get('name') == 'beacon.governance.violation'
        ]
        assert len(events) == 1
        assert events[0]['event'] == 'on_custom_event'
        assert events[0]['data']['phase'] == 'pre_tool'
        assert events[0]['data']['tool_call_id'] == 'call_1'

        terminal = chunks[-1]
        assert not (
            isinstance(terminal, dict) and 'messages' in terminal and 'event' not in terminal
        ), f'astream emit must not yield a state-shaped chunk; got {terminal!r}'


# ---------------------------------------------------------------------------
# Post lifecycles (post_tool, post_llm)
# ---------------------------------------------------------------------------


class TestPostLifecycles:
    """Coverage for the ``post_tool`` / ``post_llm`` block paths.

    The pre-* paths fire from the corresponding ``on_*_start`` callbacks;
    post-* fire from ``on_*_end`` after the action has already produced an
    output.  A typo in the lifecycle string assembled by ``_enforce``
    would only surface here.
    """

    def test_post_tool_block_carries_post_tool_phase(self, mock_governance_client):
        cfg = GovernanceConfig(stack_ids=['s1'], enabled_hooks={'post_tool'})
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_pt', 'name': 'get_weather', 'args': {'location': 'london'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-post-tool',
            governance=cfg,
            violation_mode='state',
        )
        result = agent.invoke({'messages': [HumanMessage(content='go')]})

        tool_msgs = [
            m for m in result['messages']
            if isinstance(m, ToolMessage)
            and m.additional_kwargs.get('beacon_governance_violation')
        ]
        assert tool_msgs, 'expected at least one Beacon-flagged ToolMessage'
        # post_tool fires after the tool ran — the violation carries phase='post_tool'.
        handler = agent.beacon_config.governance_handler
        assert handler.last_violation is not None
        assert handler.last_violation.phase == 'post_tool'

    def test_post_llm_block_carries_post_llm_phase(self, mock_governance_client):
        cfg = GovernanceConfig(stack_ids=['s1'], enabled_hooks={'post_llm'})

        from langchain_core.language_models.fake_chat_models import FakeListChatModel
        fake_llm = FakeListChatModel(responses=['final answer'])

        def call_model(state):
            return {'messages': [fake_llm.invoke(state['messages'])]}

        workflow = StateGraph(_MessagesState)
        workflow.add_node('agent', call_model)
        workflow.set_entry_point('agent')
        workflow.add_edge('agent', END)
        graph = workflow.compile(checkpointer=MemorySaver())

        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-post-llm',
            governance=cfg,
            violation_mode='state',
        )
        result = agent.invoke({'messages': [HumanMessage(content='go')]})

        violations = [
            m for m in result['messages']
            if isinstance(m, AIMessage)
            and m.additional_kwargs.get('beacon_governance_violation')
        ]
        assert violations, 'expected at least one Beacon-flagged AIMessage'
        assert violations[-1].additional_kwargs.get('phase') == 'post_llm'

        handler = agent.beacon_config.governance_handler
        assert handler.last_violation is not None
        assert handler.last_violation.phase == 'post_llm'


# ---------------------------------------------------------------------------
# Sibling reconciliation against pre-seeded checkpoint state
# ---------------------------------------------------------------------------


class TestPreSeededStateReconciliation:
    """Reconciliation when the open AIMessage is already in the checkpoint.

    The headline state-mode test routes through chunk capture because the
    failing superstep rolls the AIMessage back.  This test seeds the
    checkpoint directly via ``update_state`` so the source pick walks the
    *state* branch in ``_build_messages_from_sources`` — guarding the
    unanswered-set logic that is otherwise dead in CI.
    """

    def test_reconciliation_reads_from_pre_seeded_state(
        self,
        mock_governance_client,
        gov_config,
    ):
        # Build a graph whose entry point goes straight to 'tools' so the
        # agent step does not overwrite the pre-seeded AIMessage.
        tools_only = StateGraph(_MessagesState)
        tools_only.add_node('tools', ToolNode([send_email, get_weather]))
        tools_only.set_entry_point('tools')
        tools_only.add_edge('tools', END)
        graph = tools_only.compile(checkpointer=MemorySaver())

        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-preseed',
            governance=gov_config,
            violation_mode='state',
        )

        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}},
                {'id': 'call_2', 'name': 'get_weather', 'args': {'location': 'london'}},
            ],
        )
        # Seed state with a HumanMessage + AIMessage carrying two open tool_calls.
        graph.update_state(
            agent.beacon_config.get_config(),
            {'messages': [HumanMessage(content='go'), ai]},
        )
        # Invoke with input=None continues from the seeded checkpoint.
        result = agent.invoke(None)

        tool_messages = [m for m in result['messages'] if isinstance(m, ToolMessage)]
        ids = {m.tool_call_id for m in tool_messages}
        assert ids == {'call_1', 'call_2'}, (
            f'every open tool_call must get a synthetic ToolMessage; got ids={ids!r}'
        )

    def test_already_answered_tool_call_falls_through_to_ai_message(
        self,
        mock_governance_client,
        gov_config,
    ):
        """If every open tool_call is already answered when the block fires,
        the wrapper degrades to a single AIMessage instead of synthesising
        ToolMessages with duplicate tool_call_ids."""
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_done', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        # Use the wrapper's internal builder directly so we don't have to
        # engineer an end-to-end "already answered" flow through ToolNode.
        exc = GovernanceViolationError(
            message='blocked',
            phase='pre_tool',
            tool_call_id='call_done',
        )
        agent = BeaconLangGraphAgent(
            _build_graph([AIMessage(content='ok')]),
            thread_id='t-answered',
            governance=gov_config,
            violation_mode='state',
        )
        out = agent._build_messages_from_sources(
            state_messages=[ai, ToolMessage(content='done', tool_call_id='call_done')],
            seen_messages=None,
            exc=exc,
        )
        assert len(out) == 1
        assert isinstance(out[0], AIMessage)
        assert out[0].additional_kwargs.get('beacon_governance_violation') is True


# ---------------------------------------------------------------------------
# _build_event run_id fallback chain (synthesised marker on fall-through)
# ---------------------------------------------------------------------------


class TestBuildEvent:
    """Direct tests for the three-step run_id resolution in ``_build_event``."""

    def _agent(self, gov_config):
        return BeaconLangGraphAgent(
            _build_graph([AIMessage(content='ok')]),
            thread_id='t-build-event',
            governance=gov_config,
            violation_mode='emit',
        )

    def test_run_id_uses_root_span_id_when_available(
        self, mock_governance_client, gov_config,
    ):
        agent = self._agent(gov_config)
        agent.beacon_config._handler._root_span_id = 'span-1'
        exc = GovernanceViolationError(message='b', phase='pre_tool', tool_call_id='c')

        event = agent._build_event(exc, {'configurable': {'thread_id': 'tid-1'}})

        assert event['run_id'] == 'span-1'
        assert event['metadata'] == {}  # not synthesised

    def test_run_id_falls_back_to_thread_id(self, mock_governance_client, gov_config):
        agent = self._agent(gov_config)
        agent.beacon_config._handler._root_span_id = None
        exc = GovernanceViolationError(message='b', phase='pre_tool')

        event = agent._build_event(exc, {'configurable': {'thread_id': 'tid-2'}})

        assert event['run_id'] == 'tid-2'
        assert event['metadata'] == {}

    def test_run_id_synthesised_marker_on_full_fallthrough(
        self, mock_governance_client, gov_config,
    ):
        agent = self._agent(gov_config)
        agent.beacon_config._handler._root_span_id = None
        exc = GovernanceViolationError(message='b', phase='pre_tool')

        event = agent._build_event(exc, {})

        # uuid4 hex-with-dashes is 36 chars.
        assert len(event['run_id']) == 36
        assert event['metadata'] == {'beacon.run_id_synthesized': True}


# ---------------------------------------------------------------------------
# Async stateless graph degradation (no async checkpointer)
# ---------------------------------------------------------------------------


class TestStatelessGraphAsync:
    @staticmethod
    def _stateless_graph(ai: AIMessage):
        def call_model(state):
            i = getattr(call_model, '_i', 0)
            setattr(call_model, '_i', i + 1)
            return {'messages': [ai] if i == 0 else [AIMessage(content='done')]}

        workflow = StateGraph(_MessagesState)
        workflow.add_node('agent', call_model)
        workflow.add_node('tools', ToolNode([send_email, get_weather]))
        workflow.set_entry_point('agent')

        def cont(state):
            last = state['messages'][-1]
            if isinstance(last, AIMessage) and last.tool_calls:
                return 'tools'
            return END

        workflow.add_conditional_edges('agent', cont, {'tools': 'tools', END: END})
        workflow.add_edge('tools', 'agent')
        return workflow.compile()  # no checkpointer

    @pytest.mark.asyncio
    async def test_ainvoke_state_mode_degrades_to_ai_message(
        self,
        mock_governance_client,
        gov_config,
    ):
        """Mirrors the sync stateless ``invoke`` degradation on the async
        path: without a checkpointer and without chunk capture, the
        wrapper synthesises a single AIMessage carrying the policy
        message rather than raising.
        """
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = self._stateless_graph(ai)
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-async-stateless',
            governance=gov_config,
            violation_mode='state',
        )
        # No raise; falls through the ValueError("No checkpointer set") branch.
        result = await agent.ainvoke({'messages': [HumanMessage(content='go')]})
        ai_messages = [m for m in result['messages'] if isinstance(m, AIMessage)]
        assert ai_messages, 'expected at least one AIMessage in degraded result'
        synthetic = ai_messages[-1]
        assert synthetic.additional_kwargs.get('beacon_governance_violation') is True

    @pytest.mark.asyncio
    async def test_astream_state_mode_recovers_via_chunks(
        self,
        mock_governance_client,
        gov_config,
    ):
        """The streaming async path captures the AIMessage via chunks
        before the violation fires, so reconciliation can still emit a
        ToolMessage even without a checkpointer.
        """
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = self._stateless_graph(ai)
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-async-stateless-stream',
            governance=gov_config,
            violation_mode='state',
        )
        chunks = [c async for c in agent.astream({'messages': [HumanMessage(content='go')]})]
        terminal = chunks[-1]
        assert isinstance(terminal, dict) and 'messages' in terminal
        tool_msgs = [m for m in terminal['messages'] if isinstance(m, ToolMessage)]
        assert any(
            m.tool_call_id == 'call_1'
            and m.additional_kwargs.get('beacon_governance_violation')
            for m in tool_msgs
        )


# ---------------------------------------------------------------------------
# agent.last_violation surfacing on the swallow path
# ---------------------------------------------------------------------------


class TestAgentLastViolation:
    def test_last_violation_surfaces_handler_violation(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_last', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-agent-lastviol',
            governance=gov_config,
            violation_mode='state',
        )
        assert agent.last_violation is None
        agent.invoke({'messages': [HumanMessage(content='go')]})

        # After a state-mode block the wrapper completed cleanly but
        # last_violation must still expose the underlying error so callers
        # can correlate the synthetic ToolMessages with the original.
        assert agent.last_violation is not None
        assert agent.last_violation.phase == 'pre_tool'
        assert agent.last_violation.tool_call_id == 'call_last'


# ---------------------------------------------------------------------------
# Chunk walk: bounded recursion + cycle guard
# ---------------------------------------------------------------------------


class TestChunkWalkSafety:
    def test_cyclic_dict_does_not_recurse_forever(self):
        cyclic: dict = {'messages': [AIMessage(content='hi')]}
        cyclic['self'] = cyclic  # self-reference

        result = BeaconLangGraphAgent._extract_messages_from_chunk(cyclic)

        assert len(result) == 1
        assert isinstance(result[0], AIMessage)

    def test_cyclic_list_does_not_recurse_forever(self):
        inner: list = [AIMessage(content='hi')]
        inner.append(inner)  # self-reference

        result = BeaconLangGraphAgent._extract_messages_from_chunk(inner)

        assert len(result) == 1
        assert isinstance(result[0], AIMessage)

    def test_excessive_depth_truncates(self):
        # Build a chain of nested dicts deeper than _CHUNK_WALK_MAX_DEPTH.
        from lumenova_beacon.governance.integrations.langgraph_agent import (
            _CHUNK_WALK_MAX_DEPTH,
        )
        leaf = AIMessage(content='deep')
        node: dict = {'leaf': leaf}
        for _ in range(_CHUNK_WALK_MAX_DEPTH + 5):
            node = {'next': node}

        # Should not raise RecursionError; returns whatever it reaches.
        result = BeaconLangGraphAgent._extract_messages_from_chunk(node)
        assert isinstance(result, list)  # may be empty due to truncation


# ---------------------------------------------------------------------------
# _extract_tool_call_id fallback chain (top-level kwarg vs inputs dict)
# ---------------------------------------------------------------------------


class TestExtractToolCallId:
    def _build_handler(self):
        from lumenova_beacon.governance.integrations.langchain import (
            BeaconLangGraphGovernanceHandler,
        )
        return BeaconLangGraphGovernanceHandler(stack_ids=['s1'], agent_name='test')

    def test_top_level_kwarg_wins(self, mock_governance_client):
        handler = self._build_handler()
        got = handler._extract_tool_call_id({'tool_call_id': 'call_top'})
        assert got == 'call_top'

    def test_falls_back_to_inputs_dict(self, mock_governance_client):
        handler = self._build_handler()
        got = handler._extract_tool_call_id({'inputs': {'tool_call_id': 'call_nested'}})
        assert got == 'call_nested'

    def test_returns_none_when_missing(self, mock_governance_client):
        handler = self._build_handler()
        assert handler._extract_tool_call_id({'inputs': {}}) is None
        assert handler._extract_tool_call_id({}) is None


# ---------------------------------------------------------------------------
# Constructor validation (governance=None no-op, non-graph inputs)
# ---------------------------------------------------------------------------


class TestConstructorValidation:
    def test_governance_none_is_rejected(self, mock_governance_client):
        """Without a GovernanceConfig the wrapper has nothing to enforce —
        accepting None would silently turn the wrapper into a passthrough.
        """
        with pytest.raises(ValueError, match='governance'):
            BeaconLangGraphAgent(
                graph=_build_graph([AIMessage(content='ok')]),
                thread_id='t-no-gov',
                governance=None,  # type: ignore[arg-type]
            )

    def test_non_graph_input_is_rejected(self, mock_governance_client, gov_config):
        for bad in (None, 'not a graph', 42, lambda x: x):
            with pytest.raises(TypeError, match='compiled LangGraph'):
                BeaconLangGraphAgent(
                    graph=bad,
                    thread_id='t-bad-graph',
                    governance=gov_config,
                )


# ---------------------------------------------------------------------------
# Reconciliation does not emit a second top-level trace (output-side check)
# ---------------------------------------------------------------------------


class TestReconciliationNoSecondTrace:
    def test_user_callback_sees_one_root_chain_start(
        self,
        mock_governance_client,
        gov_config,
    ):
        """Output-side regression for commit 21651a8.

        :meth:`_persist_config` strips ``callbacks`` from the config used for
        ``update_state`` so the user's tracer does not see the reconciliation
        as a second top-level run.  ``TestPersistConfigStripsCallbacks``
        asserts the *input* (the stripped dict); this test installs a real
        counting callback on the merged config and asserts the *output*:
        the user only ever sees one root-level ``on_chain_start``.
        """
        from langchain_core.callbacks import BaseCallbackHandler

        class _RootChainCounter(BaseCallbackHandler):
            def __init__(self) -> None:
                self.root_starts: list[str] = []

                self.starts: list[str] = []

            def on_chain_start(self, serialized, inputs, *, run_id, parent_run_id=None, **kwargs):
                name = (serialized or {}).get('name', '')
                self.starts.append(name)
                if parent_run_id is None:
                    self.root_starts.append(name)

        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        graph = _build_graph([ai])
        agent = BeaconLangGraphAgent(
            graph,
            thread_id='t-no-second-trace',
            governance=gov_config,
            violation_mode='state',
        )

        counter = _RootChainCounter()
        agent.invoke(
            {'messages': [HumanMessage(content='go')]},
            config={'callbacks': [counter]},
        )

        # The original invoke fires exactly one root chain_start; reconciliation
        # via update_state must not produce a second one for the user.
        assert len(counter.root_starts) == 1, (
            f'reconciliation leaked into user callbacks; root starts: {counter.root_starts!r}'
        )


# ---------------------------------------------------------------------------
# astream_events post-hoc swallow (ToolNode handle_tool_errors=True)
# ---------------------------------------------------------------------------


def _build_swallowing_graph(ai: AIMessage):
    """Graph whose ToolNode catches the GovernanceViolationError silently."""

    def call_model(state):
        i = getattr(call_model, '_i', 0)
        setattr(call_model, '_i', i + 1)
        return {'messages': [ai] if i == 0 else [AIMessage(content='done')]}

    workflow = StateGraph(_MessagesState)
    workflow.add_node('agent', call_model)
    workflow.add_node(
        'tools',
        ToolNode([send_email, get_weather], handle_tool_errors=True),
    )
    workflow.set_entry_point('agent')

    def cont(state):
        last = state['messages'][-1]
        if isinstance(last, AIMessage) and last.tool_calls:
            return 'tools'
        return END

    workflow.add_conditional_edges('agent', cont, {'tools': 'tools', END: END})
    workflow.add_edge('tools', 'agent')
    return workflow.compile(checkpointer=MemorySaver())


class TestAstreamEventsPostHoc:
    """astream_events × violation_mode under ToolNode(handle_tool_errors=True).

    The non-streaming entry points have their own coverage
    (``TestEdgeCases.test_post_hoc_violation_raises_when_toolnode_swallows``
    and ``TestPostHocStateMode``).  This class locks the contract that the
    streaming-events helpers also surface the post-hoc swallow.
    """

    @pytest.mark.asyncio
    async def test_raise_mode_surfaces_swallowed_violation(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        agent = BeaconLangGraphAgent(
            _build_swallowing_graph(ai),
            thread_id='t-astream-events-raise',
            governance=gov_config,
            violation_mode='raise',
        )
        with pytest.raises(GovernanceViolationError):
            async for _event in agent.astream_events(
                {'messages': [HumanMessage(content='go')]},
            ):
                pass

    @pytest.mark.asyncio
    async def test_emit_mode_yields_violation_event(
        self,
        mock_governance_client,
        gov_config,
    ):
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        agent = BeaconLangGraphAgent(
            _build_swallowing_graph(ai),
            thread_id='t-astream-events-emit',
            governance=gov_config,
            violation_mode='emit',
        )
        events = []
        async for event in agent.astream_events(
            {'messages': [HumanMessage(content='go')]},
        ):
            events.append(event)

        violation_events = [
            e for e in events
            if isinstance(e, dict) and e.get('name') == 'beacon.governance.violation'
        ]
        assert len(violation_events) == 1, (
            f'expected one synthesised event from the post-hoc swallow; '
            f'got {len(violation_events)}'
        )

    @pytest.mark.asyncio
    async def test_state_mode_completes_without_extra_event(
        self,
        mock_governance_client,
        gov_config,
    ):
        """In state mode, post-hoc paths do not reconcile (ToolNode already
        wrote its own error ToolMessage).  The events stream must complete
        without raising and without yielding a synthesised violation event.
        """
        ai = AIMessage(
            content='',
            tool_calls=[
                {'id': 'call_1', 'name': 'send_email', 'args': {'to': 'a@b', 'subject': 'hi'}}
            ],
        )
        agent = BeaconLangGraphAgent(
            _build_swallowing_graph(ai),
            thread_id='t-astream-events-state',
            governance=gov_config,
            violation_mode='state',
        )
        events = []
        async for event in agent.astream_events(
            {'messages': [HumanMessage(content='go')]},
        ):
            events.append(event)

        violation_events = [
            e for e in events
            if isinstance(e, dict) and e.get('name') == 'beacon.governance.violation'
        ]
        assert violation_events == [], (
            'state mode must not synthesise a violation event when ToolNode '
            "has already written its own error ToolMessage; got "
            f'{violation_events!r}'
        )
        # And the swallowed violation is still observable via the wrapper.
        assert agent.last_violation is not None


# ---------------------------------------------------------------------------
# Post-hoc synthetic placeholder when handler.last_violation is unset
# ---------------------------------------------------------------------------


class TestPostHocSyntheticPlaceholder:
    def test_synthesises_placeholder_when_last_violation_missing(
        self,
        mock_governance_client,
        gov_config,
    ):
        """SDK skew: handler increments ``violation_count`` but does not
        store ``last_violation``.  ``_post_hoc_violation`` must still
        return a :class:`GovernanceViolationError` so the wrapper's
        ``violation_mode`` dispatch fires — returning ``None`` would let
        raise mode silently succeed and emit mode silently drop the event.
        """
        agent = BeaconLangGraphAgent(
            graph=_build_graph([AIMessage(content='ok')]),
            thread_id='t-posthoc-placeholder',
            governance=gov_config,
            violation_mode='raise',
        )
        handler = agent.beacon_config.governance_handler
        assert handler is not None

        # Simulate the SDK-skew condition: counter ahead of snapshot, slot empty.
        handler._violation_count = 5
        handler._last_violation = None

        exc = agent._post_hoc_violation(before=0)

        assert isinstance(exc, GovernanceViolationError)
        # The synthesised placeholder is honest about the missing context.
        assert exc.phase is None
        assert 'not recorded' in str(exc).lower()
