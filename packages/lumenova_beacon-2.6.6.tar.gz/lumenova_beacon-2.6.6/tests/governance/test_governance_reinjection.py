"""Tests for governance-driven content reinjection.

Covers:
- ``parse_outcome`` extraction of the backend's ``output`` field
- ``@governance`` decorator applying the replacement to plain functions
  and LangChain ``@tool`` instances, both sync and async, across pre and
  post phases
- ``BeaconLangGraphGovernanceHandler.wrap()`` for tools and chat models
- The callback path leaving content unchanged while emitting a warning
- LangGraph helpers delegating to the handler
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch
from uuid import uuid4

import pytest

from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.tools import tool

from lumenova_beacon.governance import (
    BeaconLangGraphGovernanceHandler,
    governance,
    wrap_chat_model,
    wrap_tool_node,
)
from lumenova_beacon.governance._helpers import EnforcementOutcome, parse_outcome


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def transport():
    t = MagicMock()
    t.headers = {'Authorization': 'Bearer test-key', 'Content-Type': 'application/json'}
    t.timeout = 10.0
    t.verify = True
    return t


@pytest.fixture
def mock_beacon_client():
    mock_client = MagicMock()
    mock_client.config.session_id = 'test-session'
    mock_client.config.environment = 'test'
    mock_client.config.user_id = None
    mock_client.config.user_email = None
    mock_client.config.user_name = None
    return mock_client


@pytest.fixture
def _patch_transport(transport, mock_beacon_client):
    with (
        patch(
            'lumenova_beacon.governance.client.get_transport',
            return_value=transport,
        ),
        patch(
            'lumenova_beacon.governance.client.get_base_url',
            return_value='https://api.test.com',
        ),
        patch(
            'lumenova_beacon.core.client.get_client',
            return_value=mock_beacon_client,
        ),
    ):
        yield


def _allow_with_output(output: str | None) -> dict:
    return {
        'decision': 'allow',
        'message': None,
        'rules_evaluated': [],
        'latency_ms': 1.0,
        **({'output': output} if output is not None else {}),
    }


# ---------------------------------------------------------------------------
# parse_outcome
# ---------------------------------------------------------------------------


class TestParseOutcome:
    def test_none_response_is_allowed_no_replacement(self):
        outcome = parse_outcome(None)
        assert outcome == EnforcementOutcome(allowed=True, replacement=None)

    def test_allow_without_output(self):
        outcome = parse_outcome(_allow_with_output(None))
        assert outcome == EnforcementOutcome(allowed=True, replacement=None)

    def test_allow_with_output(self):
        outcome = parse_outcome(_allow_with_output('redacted'))
        assert outcome == EnforcementOutcome(allowed=True, replacement='redacted')

    def test_block_drops_output(self):
        resp = {
            'decision': 'block',
            'message': 'nope',
            'rules_evaluated': [],
            'latency_ms': 1.0,
            'output': 'should be ignored',
        }
        outcome = parse_outcome(resp)
        assert outcome == EnforcementOutcome(allowed=False, replacement=None)

    def test_non_string_output_raises_reinjection_error(self):
        # Mirrors the fail-closed contract in `_wrapping.py`: a malformed
        # `output` (e.g. policy emits a dict instead of a string) cannot be
        # silently allowed through, since that would leak the very content
        # the policy meant to replace.
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        resp = _allow_with_output(None)
        resp['output'] = {'not': 'a string'}  # type: ignore[assignment]
        with pytest.raises(GovernanceReinjectionError, match='must be a string'):
            parse_outcome(resp)

    def test_allow_with_output_target(self):
        resp = _allow_with_output('REDACTED')
        resp['output_target'] = 'body'
        outcome = parse_outcome(resp)
        assert outcome == EnforcementOutcome(
            allowed=True, replacement='REDACTED', target='body',
        )

    def test_allow_without_output_target_defaults_to_none(self):
        outcome = parse_outcome(_allow_with_output('REDACTED'))
        assert outcome.target is None

    def test_non_string_output_target_is_dropped(self, caplog):
        resp = _allow_with_output('REDACTED')
        resp['output_target'] = 42  # type: ignore[assignment]
        with caplog.at_level('WARNING'):
            outcome = parse_outcome(resp)
        assert outcome.replacement == 'REDACTED'
        assert outcome.target is None
        assert any('output_target' in r.getMessage() for r in caplog.records)

    def test_empty_string_output_target_is_dropped(self, caplog):
        resp = _allow_with_output('REDACTED')
        resp['output_target'] = ''
        with caplog.at_level('WARNING'):
            outcome = parse_outcome(resp)
        assert outcome.target is None
        assert any('output_target' in r.getMessage() for r in caplog.records)


# ---------------------------------------------------------------------------
# apply_tool_kwargs_replacement — explicit target
# ---------------------------------------------------------------------------


class TestApplyToolKwargsReplacementWithTarget:
    """Direct tests for the explicit-target substitution path."""

    def test_target_hits_replaces_only_named_kwarg(self):
        from lumenova_beacon.governance._wrapping import apply_tool_kwargs_replacement
        new_kwargs = apply_tool_kwargs_replacement(
            {'to': 'a@b.com', 'subject': 'Hi', 'body': 'PII inside'},
            'CLEAN',
            tool_name='send_email',
            target='body',
        )
        assert new_kwargs == {'to': 'a@b.com', 'subject': 'Hi', 'body': 'CLEAN'}

    def test_target_missing_kwarg_raises_reinjection_error(self):
        # An explicit target that does not match a kwarg fails closed; the
        # policy author was specific about which field to overwrite, and a
        # heuristic fallback could rewrite the wrong field while leaving
        # the sensitive one through.
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_tool_kwargs_replacement
        with pytest.raises(GovernanceReinjectionError, match="target 'body'"):
            apply_tool_kwargs_replacement(
                {'query': 'pii'},
                'CLEAN',
                tool_name='search',
                target='body',
            )

    def test_target_non_string_kwarg_raises_reinjection_error(self):
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_tool_kwargs_replacement
        with pytest.raises(GovernanceReinjectionError, match="target 'count'"):
            apply_tool_kwargs_replacement(
                {'query': 'pii', 'count': 10},
                'CLEAN',
                tool_name='search',
                target='count',
            )

    def test_target_none_multi_string_no_input_raises_reinjection_error(self):
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_tool_kwargs_replacement
        # Multi-kwarg, no target → fails closed instead of silently letting
        # unsanitized content reach the tool.
        with pytest.raises(GovernanceReinjectionError, match='disambiguate'):
            apply_tool_kwargs_replacement(
                {'a': 'one', 'b': 'two'},
                'CLEAN',
                tool_name='multi',
                target=None,
            )

    def test_target_none_multi_string_with_input_still_raises(self):
        # Previously the SDK would silently rewrite `input` here; that is a
        # security bug because the policy may have intended to scrub
        # `query` instead. Multi-string ambiguity must always raise.
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_tool_kwargs_replacement
        with pytest.raises(GovernanceReinjectionError, match='disambiguate'):
            apply_tool_kwargs_replacement(
                {'query': 'dangerous', 'input': 'metadata'},
                'CLEAN',
                tool_name='search',
                target=None,
            )


# ---------------------------------------------------------------------------
# @governance decorator
# ---------------------------------------------------------------------------


class TestGovernanceDecorator:
    def test_decorator_post_replaces_return_value(self, _patch_transport):
        resp = _allow_with_output('MASKED')
        with patch(
            'lumenova_beacon.governance.decorators.evaluate_or_fail_open',
            return_value=resp,
        ):
            @governance(stack_ids=['s1'])
            def read_file(path: str) -> str:
                return f'contents of {path} with PII'

            assert read_file(path='/tmp/secrets') == 'MASKED'

    def test_decorator_pre_replaces_single_string_kwarg(self, _patch_transport):
        resp = _allow_with_output('REDACTED-QUERY')
        captured = {}

        with patch(
            'lumenova_beacon.governance.decorators.evaluate_or_fail_open',
            return_value=resp,
        ):
            @governance(stack_ids=['s1'], enabled_hooks={'pre_tool'})
            def search(query: str) -> str:
                captured['query'] = query
                return 'ok'

            search(query='original')

        assert captured['query'] == 'REDACTED-QUERY'

    def test_decorator_pre_multi_kwargs_with_input_still_raises(self, _patch_transport):
        # Even when one of the string kwargs is named `input`, the SDK
        # must not silently pick it: the policy might have intended to
        # substitute `meta`. Force `output_target` instead.
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        resp = _allow_with_output('CLEAN')

        with patch(
            'lumenova_beacon.governance.decorators.evaluate_or_fail_open',
            return_value=resp,
        ):
            @governance(stack_ids=['s1'], enabled_hooks={'pre_tool'})
            def multi(input: str, meta: str) -> str:
                return 'ok'

            with pytest.raises(GovernanceReinjectionError, match='disambiguate'):
                multi(input='dirty', meta='keep-me')

    def test_decorator_pre_multi_kwargs_no_input_raises(self, _patch_transport):
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        resp = _allow_with_output('UNAPPLICABLE')

        with patch(
            'lumenova_beacon.governance.decorators.evaluate_or_fail_open',
            return_value=resp,
        ):
            @governance(stack_ids=['s1'], enabled_hooks={'pre_tool'})
            def two_strings(a: str, b: str) -> str:
                return 'ok'

            with pytest.raises(GovernanceReinjectionError):
                two_strings(a='one', b='two')

    def test_decorator_pre_explicit_target_replaces_named_kwarg(self, _patch_transport):
        resp = _allow_with_output('REDACTED')
        resp['output_target'] = 'body'
        captured = {}

        with patch(
            'lumenova_beacon.governance.decorators.evaluate_or_fail_open',
            return_value=resp,
        ):
            @governance(stack_ids=['s1'], enabled_hooks={'pre_tool'})
            def send_email(to: str, subject: str, body: str) -> str:
                captured['to'] = to
                captured['subject'] = subject
                captured['body'] = body
                return 'sent'

            send_email(to='a@b.com', subject='Hi', body='PII inside')

        assert captured['to'] == 'a@b.com'
        assert captured['subject'] == 'Hi'
        assert captured['body'] == 'REDACTED'

    @pytest.mark.asyncio
    async def test_decorator_async_post_replaces(self, _patch_transport):
        resp = _allow_with_output('ASYNC-MASKED')
        with patch(
            'lumenova_beacon.governance.decorators.aevaluate_or_fail_open',
            return_value=resp,
        ):
            @governance(stack_ids=['s1'])
            async def aread(path: str) -> str:
                return f'contents of {path}'

            assert await aread(path='/etc/secret') == 'ASYNC-MASKED'

    def test_decorator_on_langchain_tool_replaces_return(self, _patch_transport):
        resp = _allow_with_output('LC-MASKED')
        with patch(
            'lumenova_beacon.governance.decorators.evaluate_or_fail_open',
            return_value=resp,
        ):
            @governance(stack_ids=['s1'])
            @tool
            def search_db(query: str) -> str:
                """Search."""
                return f'raw results for {query}'

            result = search_db.invoke({'query': 'pii in results'})
            assert result == 'LC-MASKED'


# ---------------------------------------------------------------------------
# handler.wrap()
# ---------------------------------------------------------------------------


class TestHandlerWrap:
    def test_wrap_tool_post_replaces_return(self, _patch_transport):
        resp = _allow_with_output('WRAPPED-MASKED')
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])

        @tool
        def read_file(path: str) -> str:
            """Read a file."""
            return 'RAW WITH PII'

        wrapped = handler.wrap(read_file)

        with patch.object(handler, '_evaluate_or_fail_open', return_value=resp):
            out = wrapped.invoke({'path': '/tmp/a'})

        assert out == 'WRAPPED-MASKED'

    def test_wrap_chat_model_post_replaces_content(self, _patch_transport):
        resp = _allow_with_output('CLEAN ANSWER')
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])

        model = FakeListChatModel(responses=['AI answer with SSN 123-45-6789'])
        wrapped = handler.wrap(model)

        with patch.object(handler, '_evaluate_or_fail_open', return_value=resp):
            result = wrapped.invoke('hello')

        assert isinstance(result, AIMessage)
        assert result.content == 'CLEAN ANSWER'

    def test_wrap_chat_model_pre_rewrites_human_message(self, _patch_transport):
        resp = _allow_with_output('sanitized question')
        handler = BeaconLangGraphGovernanceHandler(
            stack_ids=['s1'], enabled_hooks={'pre_llm'},
        )
        captured = {}

        class RecordingModel(FakeListChatModel):
            def _generate(self, messages, stop=None, run_manager=None, **kwargs):
                captured['last_human'] = messages[-1].content
                return super()._generate(messages, stop=stop, run_manager=run_manager, **kwargs)

        model = RecordingModel(responses=['ok'])
        wrapped = handler.wrap(model)

        with patch.object(handler, '_evaluate_or_fail_open', return_value=resp):
            wrapped.invoke([HumanMessage(content='my email is a@b.com')])

        assert captured['last_human'] == 'sanitized question'

    def test_wrap_list_of_tools(self, _patch_transport):
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])

        @tool
        def a(x: str) -> str:
            """a"""
            return f'a-{x}'

        @tool
        def b(y: str) -> str:
            """b"""
            return f'b-{y}'

        wrapped = handler.wrap([a, b])
        assert isinstance(wrapped, list)
        assert len(wrapped) == 2


# ---------------------------------------------------------------------------
# Callback path remains observer-only
# ---------------------------------------------------------------------------


class TestCallbackObserverOnly:
    def test_callback_on_tool_end_warns_when_output_present(self, _patch_transport, caplog):
        resp = _allow_with_output('would-be-replacement')
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])

        with patch.object(handler, '_evaluate_or_fail_open', return_value=resp):
            with caplog.at_level('WARNING'):
                handler.on_tool_end('raw output', run_id=uuid4(), name='read_file')

        messages = [r.getMessage() for r in caplog.records]
        assert any('output' in m and 'callback' in m.lower() for m in messages), messages


# ---------------------------------------------------------------------------
# LangGraph helpers
# ---------------------------------------------------------------------------


class TestLangGraphHelpers:
    def test_wrap_tool_node_accepts_sequence(self, _patch_transport):
        @tool
        def a(x: str) -> str:
            """a"""
            return f'a-{x}'

        result = wrap_tool_node([a], stack_ids=['s1'])
        assert isinstance(result, list)
        assert len(result) == 1

    def test_wrap_chat_model_helper(self, _patch_transport):
        resp = _allow_with_output('CLEAN')
        model = FakeListChatModel(responses=['AI answer'])
        wrapped = wrap_chat_model(model, stack_ids=['s1'])

        with patch(
            'lumenova_beacon.governance.integrations.langchain.evaluate_or_fail_open',
            return_value=resp,
        ):
            out = wrapped.invoke('hi')

        assert out.content == 'CLEAN'

    def test_wrap_helpers_reject_handler_with_conflicting_kwargs(self, _patch_transport):
        h = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        with pytest.raises(ValueError, match='handler'):
            wrap_chat_model(
                FakeListChatModel(responses=['x']),
                handler=h,
                stack_ids=['other'],
            )

    def test_wrap_tool_node_preserves_publicly_exposed_config(self, _patch_transport):
        pytest.importorskip('langgraph')
        from langgraph.prebuilt import ToolNode

        @tool
        def a(x: str) -> str:
            """a"""
            return f'a-{x}'

        # tags is one of the few ToolNode constructor kwargs that gets
        # mirrored onto the instance as a public attribute, so it round-
        # trips through our introspection-based rebuild.
        original = ToolNode([a], tags=['governance-test'])
        wrapped = wrap_tool_node(original, stack_ids=['s1'])
        assert isinstance(wrapped, ToolNode)
        assert wrapped.tags == ['governance-test']
        assert list(wrapped.tools_by_name) == ['a']


# ---------------------------------------------------------------------------
# EnforcementOutcome invariants
# ---------------------------------------------------------------------------


class TestEnforcementOutcomeInvariants:
    def test_block_with_replacement_rejected(self):
        with pytest.raises(ValueError, match='blocked outcomes'):
            EnforcementOutcome(allowed=False, replacement='x')

    def test_target_without_replacement_rejected(self):
        with pytest.raises(ValueError, match='target is only meaningful'):
            EnforcementOutcome(allowed=True, replacement=None, target='body')


# ---------------------------------------------------------------------------
# default_result_parser strict decision allowlist
# ---------------------------------------------------------------------------


class TestDecisionAllowlist:
    def test_unknown_decision_treated_as_block(self, caplog):
        from lumenova_beacon.governance._helpers import default_result_parser
        with caplog.at_level('WARNING'):
            allowed = default_result_parser({'decision': 'BLOCK'})
        assert allowed is False
        assert any('unknown decision' in r.getMessage() for r in caplog.records)

    def test_typo_deny_treated_as_block(self):
        from lumenova_beacon.governance._helpers import default_result_parser
        assert default_result_parser({'decision': 'deny'}) is False

    def test_canonical_allow_passes(self):
        from lumenova_beacon.governance._helpers import default_result_parser
        assert default_result_parser({'decision': 'allow'}) is True

    def test_canonical_block_blocks(self):
        from lumenova_beacon.governance._helpers import default_result_parser
        assert default_result_parser({'decision': 'block'}) is False

    def test_apply_guardrail_passes(self):
        from lumenova_beacon.governance._helpers import default_result_parser
        assert default_result_parser({'decision': 'apply_guardrail'}) is True

    def test_missing_decision_key_treated_as_block(self, caplog):
        # A backend bug that omits `decision` must not become an implicit
        # allow. Previously the default `result.get('decision', 'allow')`
        # let this slip through.
        from lumenova_beacon.governance._helpers import default_result_parser
        with caplog.at_level('WARNING'):
            allowed = default_result_parser({'message': 'no decision'})
        assert allowed is False
        assert any('missing `decision`' in r.getMessage() for r in caplog.records)

    def test_block_with_output_does_not_reinject_through_parse_outcome(self):
        # Combined check: a block with a typo must drop the output too.
        resp = {'decision': 'BLOCK', 'output': 'should not leak'}
        outcome = parse_outcome(resp)
        assert outcome.allowed is False
        assert outcome.replacement is None


# ---------------------------------------------------------------------------
# Substitution rules failing closed
# ---------------------------------------------------------------------------


class TestReinjectionFailsClosed:
    def test_apply_tool_return_replacement_unsupported_type_raises(self):
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_tool_return_replacement
        with pytest.raises(GovernanceReinjectionError, match='neither'):
            apply_tool_return_replacement({'arbitrary': 'dict'}, 'CLEAN')

    def test_apply_tool_return_preserves_toolmessage_metadata(self):
        from langchain_core.messages import ToolMessage

        from lumenova_beacon.governance._wrapping import apply_tool_return_replacement
        original = ToolMessage(
            content='dirty', tool_call_id='abc',
            additional_kwargs={'k': 'v'},
        )
        new = apply_tool_return_replacement(original, 'CLEAN')
        assert isinstance(new, ToolMessage)
        assert new.content == 'CLEAN'
        assert new.tool_call_id == 'abc'
        assert new.additional_kwargs == {'k': 'v'}

    def test_apply_llm_return_preserves_aimessage_tool_calls(self):
        from lumenova_beacon.governance._wrapping import apply_llm_return_replacement
        original = AIMessage(
            content='dirty answer',
            tool_calls=[
                {'name': 'fetch', 'args': {'q': 'x'}, 'id': '1', 'type': 'tool_call'},
            ],
        )
        new = apply_llm_return_replacement(original, 'CLEAN')
        assert isinstance(new, AIMessage)
        assert new.content == 'CLEAN'
        assert new.tool_calls == original.tool_calls

    def test_apply_llm_messages_no_human_raises(self):
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_llm_messages_replacement
        with pytest.raises(GovernanceReinjectionError, match='no human message'):
            apply_llm_messages_replacement([AIMessage(content='only ai')], 'CLEAN')


# ---------------------------------------------------------------------------
# Idempotency on double-wrap
# ---------------------------------------------------------------------------


class TestDoubleWrapIdempotent:
    def test_governance_decorator_applied_twice_is_no_op(self, _patch_transport):
        resp = _allow_with_output('REPLACE')
        call_count = {'n': 0}

        with patch(
            'lumenova_beacon.governance.decorators.evaluate_or_fail_open',
            side_effect=lambda *a, **kw: (call_count.update(n=call_count['n'] + 1), resp)[1],
        ):
            @governance(stack_ids=['s1'])
            @governance(stack_ids=['s1'])
            def f(x: str) -> str:
                return x

            f(x='hi')

        # Pre + post = 2 calls if single-wrapped, 4 if double-wrapped.
        assert call_count['n'] == 2

    def test_handler_wrap_tool_twice_is_no_op(self, _patch_transport):
        resp = _allow_with_output(None)
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])

        @tool
        def t(x: str) -> str:
            """t"""
            return x

        wrapped_once = handler.wrap(t)
        wrapped_twice = handler.wrap(wrapped_once)
        assert wrapped_once is wrapped_twice
        assert wrapped_once.func is wrapped_twice.func

        call_count = {'n': 0}
        with patch.object(
            handler, '_evaluate_or_fail_open',
            side_effect=lambda *a, **kw: (call_count.update(n=call_count['n'] + 1), resp)[1],
        ):
            wrapped_twice.invoke({'x': 'hi'})
        # Pre + post on a single-wrap = 2 evaluations.
        assert call_count['n'] == 2

    def test_handler_wrap_chat_model_twice_is_no_op(self, _patch_transport):
        resp = _allow_with_output(None)
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        model = FakeListChatModel(responses=['ans'])

        wrapped_once = handler.wrap(model)
        wrapped_twice = handler.wrap(wrapped_once)
        assert wrapped_once is wrapped_twice

        call_count = {'n': 0}
        with patch.object(
            handler, '_evaluate_or_fail_open',
            side_effect=lambda *a, **kw: (call_count.update(n=call_count['n'] + 1), resp)[1],
        ):
            wrapped_twice.invoke('hi')
        assert call_count['n'] == 2


# ---------------------------------------------------------------------------
# Observer-only warning rate-limiting per (context, phase)
# ---------------------------------------------------------------------------


class TestObserverWarningPerKey:
    def test_warning_fires_once_per_action_phase(self, _patch_transport, caplog):
        resp = _allow_with_output('would-replace')
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])

        with patch.object(handler, '_evaluate_or_fail_open', return_value=resp):
            with caplog.at_level('WARNING'):
                # Same (action, phase) twice → only one warning.
                handler.on_tool_end('out', run_id=uuid4(), name='read_file')
                handler.on_tool_end('out', run_id=uuid4(), name='read_file')
                # Different action → second warning.
                handler.on_tool_end('out', run_id=uuid4(), name='send_email')

        warnings = [r for r in caplog.records if 'callback' in r.getMessage().lower()]
        assert len(warnings) == 2


# ---------------------------------------------------------------------------
# state_filter exception → state omitted (no PII leak)
# ---------------------------------------------------------------------------


class TestStateFilterFailsClosed:
    def test_filter_exception_omits_state(self, caplog):
        from lumenova_beacon.governance._state import serialize_state
        def buggy(s):
            raise RuntimeError('oops')
        with caplog.at_level('WARNING'):
            result = serialize_state({'pii': 'leak'}, buggy, 32 * 1024)
        assert result is None
        assert any(
            'omitting `input.context.state`' in r.getMessage()
            for r in caplog.records
        )


# ---------------------------------------------------------------------------
# GovernanceConfig validation
# ---------------------------------------------------------------------------


class TestGovernanceConfigValidation:
    def test_negative_state_max_bytes_rejected(self):
        from lumenova_beacon.governance import GovernanceConfig
        with pytest.raises(ValueError, match='state_max_bytes'):
            GovernanceConfig(stack_ids=['s1'], state_max_bytes=0)
        with pytest.raises(ValueError, match='state_max_bytes'):
            GovernanceConfig(stack_ids=['s1'], state_max_bytes=-1)


# ---------------------------------------------------------------------------
# Block + output: block must win on every wrapped surface
# ---------------------------------------------------------------------------


class TestBlockOverridesOutputEndToEnd:
    """When a policy returns block AND output, every surface must raise
    GovernanceViolationError before any reinjection can run. Verifying
    only at parse_outcome would let a refactor that reorders enforce()
    and parse_outcome() pass tests while leaking unsanitized content."""

    @staticmethod
    def _block_with_output() -> dict:
        return {
            'decision': 'block',
            'message': 'nope',
            'rules_evaluated': [],
            'latency_ms': 1.0,
            'output': 'should never reach the tool',
        }

    def test_decorator_block_with_output_does_not_call_inner(self, _patch_transport):
        from lumenova_beacon.exceptions import GovernanceViolationError
        called = {'n': 0}

        with patch(
            'lumenova_beacon.governance.decorators.evaluate_or_fail_open',
            return_value=self._block_with_output(),
        ):
            @governance(stack_ids=['s1'])
            def read_file(path: str) -> str:
                called['n'] += 1
                return 'inner'

            with pytest.raises(GovernanceViolationError):
                read_file(path='/tmp/x')

        assert called['n'] == 0

    def test_handler_wrap_tool_block_with_output_raises_before_inner(self, _patch_transport):
        from lumenova_beacon.exceptions import GovernanceViolationError
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        called = {'n': 0}

        @tool
        def read_file(path: str) -> str:
            """read"""
            called['n'] += 1
            return 'raw'

        wrapped = handler.wrap(read_file)

        with patch.object(handler, '_evaluate_or_fail_open', return_value=self._block_with_output()):
            with pytest.raises(GovernanceViolationError):
                wrapped.invoke({'path': '/tmp/x'})

        assert called['n'] == 0

    def test_handler_wrap_chat_model_block_with_output_raises(self, _patch_transport):
        from lumenova_beacon.exceptions import GovernanceViolationError
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        model = FakeListChatModel(responses=['ai answer'])
        wrapped = handler.wrap(model)

        with patch.object(handler, '_evaluate_or_fail_open', return_value=self._block_with_output()):
            with pytest.raises(GovernanceViolationError):
                wrapped.invoke('hi')


# ---------------------------------------------------------------------------
# Async handler.wrap()
# ---------------------------------------------------------------------------


class TestHandlerWrapAsync:
    @pytest.mark.asyncio
    async def test_wrap_tool_async_post_replaces(self, _patch_transport):
        resp = _allow_with_output('ASYNC-MASKED')
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])

        @tool
        async def aread(path: str) -> str:
            """async read"""
            return f'raw {path}'

        wrapped = handler.wrap(aread)

        with patch(
            'lumenova_beacon.governance.integrations.langchain.aevaluate_or_fail_open',
            return_value=resp,
        ):
            out = await wrapped.ainvoke({'path': '/tmp/a'})

        assert out == 'ASYNC-MASKED'

    @pytest.mark.asyncio
    async def test_wrap_chat_model_async_post_replaces(self, _patch_transport):
        resp = _allow_with_output('ASYNC-CLEAN')
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        model = FakeListChatModel(responses=['ai answer with PII'])
        wrapped = handler.wrap(model)

        with patch(
            'lumenova_beacon.governance.integrations.langchain.aevaluate_or_fail_open',
            return_value=resp,
        ):
            out = await wrapped.ainvoke('hi')

        assert out.content == 'ASYNC-CLEAN'


# ---------------------------------------------------------------------------
# Chat-batching list-of-lists message shape
# ---------------------------------------------------------------------------


class TestApplyLLMMessagesListOfLists:
    def test_replaces_last_human_in_first_inner_batch(self):
        from lumenova_beacon.governance._wrapping import apply_llm_messages_replacement
        batch_a = [HumanMessage(content='dirty A')]
        batch_b = [HumanMessage(content='dirty B')]
        out = apply_llm_messages_replacement([batch_a, batch_b], 'CLEAN')
        assert out[0][0].content == 'CLEAN'
        # Second batch is left untouched — only the first is rewritten.
        assert out[1][0].content == 'dirty B'

    def test_empty_inner_batch_raises(self):
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_llm_messages_replacement
        with pytest.raises(GovernanceReinjectionError, match='empty inner'):
            apply_llm_messages_replacement([[]], 'CLEAN')


# ---------------------------------------------------------------------------
# handler.wrap() raises on tools that override _run/_arun directly
# ---------------------------------------------------------------------------


class TestHandlerWrapRaisesOnUnwrappableTool:
    def test_tool_without_func_or_coroutine_raises_configuration_error(self, _patch_transport):
        from langchain_core.tools import BaseTool

        from lumenova_beacon.exceptions import GovernanceConfigurationError

        class CustomTool(BaseTool):
            name: str = 'custom'
            description: str = 'd'

            def _run(self, **kwargs):
                return 'raw'

        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        with pytest.raises(GovernanceConfigurationError, match='neither func'):
            handler.wrap(CustomTool())


# ---------------------------------------------------------------------------
# Stream / batch bypass warning
# ---------------------------------------------------------------------------


class TestStreamBatchBypassWarning:
    def test_stream_emits_one_time_warning(self, _patch_transport, caplog):
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        model = FakeListChatModel(responses=['ans1', 'ans2'])
        wrapped = handler.wrap(model)

        with caplog.at_level('WARNING'):
            list(wrapped.stream('hi'))
            list(wrapped.stream('again'))

        bypass = [
            r for r in caplog.records
            if 'stream' in r.getMessage() and 'bypasses' in r.getMessage()
        ]
        # One-time per method per wrapped instance.
        assert len(bypass) == 1

    def test_batch_emits_one_time_warning(self, _patch_transport, caplog):
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        model = FakeListChatModel(responses=['a', 'b'])
        wrapped = handler.wrap(model)

        with caplog.at_level('WARNING'):
            wrapped.batch(['hi'])
            wrapped.batch(['again'])

        bypass = [
            r for r in caplog.records
            if 'batch' in r.getMessage() and 'bypasses' in r.getMessage()
        ]
        assert len(bypass) == 1


# ---------------------------------------------------------------------------
# Default result parser fail-closed on missing key (regression for #8)
# ---------------------------------------------------------------------------


class TestParseOutcomeMissingDecisionKey:
    def test_missing_decision_key_yields_block_outcome(self):
        # parse_outcome must mirror the parser fail-closed default rather
        # than treating an absent key as allow.
        outcome = parse_outcome({'message': 'no decision', 'output': 'leak'})
        assert outcome.allowed is False


# ---------------------------------------------------------------------------
# Async fail-closed (regression: silent fail-open on async wrap path)
# ---------------------------------------------------------------------------


class TestAsyncFailClosed:
    """Verify GovernanceError propagates on the async wrap path when
    ``fail_open=False``. The sync equivalent exists in
    test_governance_decorator.py — without async coverage a regression
    that swallows GovernanceError in `_run_async_tool` would silently
    fail-open in production async LangGraph flows.
    """

    @pytest.mark.asyncio
    async def test_async_wrap_tool_fail_closed_propagates(self, _patch_transport):
        from lumenova_beacon.exceptions import GovernanceError

        handler = BeaconLangGraphGovernanceHandler(
            stack_ids=['s1'], fail_open=False,
        )

        @tool
        async def my_tool(query: str) -> str:
            """async tool"""
            return f'ok-{query}'

        wrapped = handler.wrap(my_tool)

        async def boom(*a, **kw):
            raise GovernanceError('upstream down')

        with patch(
            'lumenova_beacon.governance.integrations.langchain.aevaluate_or_fail_open',
            side_effect=boom,
        ):
            with pytest.raises(GovernanceError, match='upstream down'):
                await wrapped.ainvoke({'query': 'hi'})

    @pytest.mark.asyncio
    async def test_async_wrap_chat_model_fail_closed_propagates(self, _patch_transport):
        from lumenova_beacon.exceptions import GovernanceError

        handler = BeaconLangGraphGovernanceHandler(
            stack_ids=['s1'], fail_open=False,
        )
        model = FakeListChatModel(responses=['ans'])
        wrapped = handler.wrap(model)

        async def boom(*a, **kw):
            raise GovernanceError('upstream down')

        with patch(
            'lumenova_beacon.governance.integrations.langchain.aevaluate_or_fail_open',
            side_effect=boom,
        ):
            with pytest.raises(GovernanceError, match='upstream down'):
                await wrapped.ainvoke('hi')


# ---------------------------------------------------------------------------
# Decorator type_='llm' messages-kwarg path
# ---------------------------------------------------------------------------


class TestDecoratorLLMMessagesPath:
    """Cover the @governance(type_='llm') branch in `_apply_pre_replacement`.

    The decorator routes a ``messages=`` kwarg through
    ``apply_llm_messages_replacement`` (rewriting the last human message)
    rather than the tool-style kwarg heuristic. Without this test, a
    regression that reordered the ``'messages' in kwargs`` check could
    silently fall back to the kwarg path and substitute the wrong value.
    """

    def test_decorator_llm_messages_kwarg_replaces_last_human(self, _patch_transport):
        from lumenova_beacon.governance._helpers import EnforcementOutcome

        captured: dict = {}

        @governance(type_='llm', stack_ids=['s1'])
        def call_llm(messages):
            captured['messages'] = messages
            return AIMessage(content='ok')

        with patch(
            'lumenova_beacon.governance.decorators.parse_outcome',
            return_value=EnforcementOutcome(
                allowed=True, replacement='SANITIZED', target=None,
            ),
        ), patch(
            'lumenova_beacon.governance.decorators.evaluate_or_fail_open',
            return_value=_allow_with_output('SANITIZED'),
        ):
            call_llm(messages=[HumanMessage(content='my SSN is 123-45-6789')])

        rewritten = captured['messages']
        assert isinstance(rewritten, list)
        assert rewritten[-1].content == 'SANITIZED'


# ---------------------------------------------------------------------------
# ContextVar reset failure (out-of-order release)
# ---------------------------------------------------------------------------


class TestContextVarResetFailure:
    """Cross-Context reset failure is logged at DEBUG, not WARN.

    Under ``astream_events`` LangChain offloads sync callbacks via
    ``run_in_executor(copy_context().run, ...)`` so on_chain_start and
    on_chain_end fire in different copied Contexts and ContextVar.reset
    raises. The set in the copied Context never reaches the user task's
    Context — the LangChain config bridge in ``_resolve_active_state``
    is what carries node identity to user code in async mode — so the
    failure is benign and logged at DEBUG.
    """

    def test_release_reset_failure_logs_debug_only(self, _patch_transport, caplog):
        from lumenova_beacon.governance._state import (
            _active_handler,
            _active_node_run_id,
        )

        handler = BeaconLangGraphGovernanceHandler(
            stack_ids=['s1'], include_state=True,
        )
        run_id = uuid4()
        meta = {'langgraph_node': 'n'}
        tags = ['graph:step:1']
        handler.on_chain_start({}, {'k': 'v'}, run_id=run_id, metadata=meta, tags=tags)
        assert run_id in handler._node_state, 'precondition: state captured'

        # Burn a fresh pair of tokens (ContextVar.reset on a token that has
        # already been used raises ValueError) and swap them in so the
        # handler's release path hits the failure branch.
        spent_node_token = _active_node_run_id.set(uuid4())
        _active_node_run_id.reset(spent_node_token)
        spent_handler_token = _active_handler.set(handler)
        _active_handler.reset(spent_handler_token)
        handler._cv_tokens[run_id] = (spent_node_token, spent_handler_token)

        with caplog.at_level('WARNING'):
            handler.on_chain_end({}, run_id=run_id)

        # No WARN should be emitted — the failure is expected under
        # async dispatch and is logged at DEBUG.
        warns = [r.getMessage() for r in caplog.records if r.levelname == 'WARNING']
        assert not any(
            'ContextVar reset' in m for m in warns
        ), f'unexpected reset WARN: {warns}'

        # ``_release_chain`` must pop per-run state regardless of reset
        # outcome; the pop is the safety net that prevents stale state
        # leaking into a later run with the same ContextVar still
        # pointing at this run_id. A regression that skipped the pop on
        # the failure path would silently flip these assertions.
        assert run_id not in handler._node_state
        assert run_id not in handler._chain_parents
        assert run_id not in handler._cv_tokens


# ---------------------------------------------------------------------------
# apply_llm_messages_replacement direct-shape coverage
# ---------------------------------------------------------------------------


class TestApplyLLMMessagesReplacementShapes:
    def test_bare_string_returns_replacement(self):
        from lumenova_beacon.governance._wrapping import apply_llm_messages_replacement
        assert apply_llm_messages_replacement('original', 'CLEAN') == 'CLEAN'

    def test_bare_human_message_is_rewritten(self):
        from lumenova_beacon.governance._wrapping import apply_llm_messages_replacement
        msg = HumanMessage(content='my SSN is 123')
        out = apply_llm_messages_replacement(msg, 'CLEAN')
        assert isinstance(out, HumanMessage)
        assert out.content == 'CLEAN'

    def test_bare_non_human_message_raises(self):
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_llm_messages_replacement
        with pytest.raises(GovernanceReinjectionError, match='no human message'):
            apply_llm_messages_replacement(AIMessage(content='ai'), 'CLEAN')


# ---------------------------------------------------------------------------
# model_copy ValidationError surfaces as GovernanceReinjectionError
# ---------------------------------------------------------------------------


class TestModelCopyValidationFailure:
    """The Pydantic v2 ``model_copy(update={'content': replacement})`` path
    in `apply_tool_return_replacement` / `apply_llm_return_replacement`
    catches ``(TypeError, ValueError)`` and re-raises as
    GovernanceReinjectionError so callers see a uniform fail-closed
    contract. Pydantic skips validators on ``update=`` by default; we
    trigger the catch by making ``model_copy`` itself raise.
    """

    def test_tool_return_model_copy_failure_raises_reinjection_error(self):
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_tool_return_replacement

        class FakeMessage:
            content = 'RAW WITH PII'

            def model_copy(self, **_kwargs):
                raise TypeError('frozen instance refuses model_copy')

        with pytest.raises(GovernanceReinjectionError, match='could not copy'):
            apply_tool_return_replacement(FakeMessage(), 'CLEAN')

    def test_llm_return_model_copy_failure_raises_reinjection_error(self):
        from lumenova_beacon.exceptions import GovernanceReinjectionError
        from lumenova_beacon.governance._wrapping import apply_llm_return_replacement

        class BrokenAIMessage(AIMessage):
            def model_copy(self, **_kwargs):
                raise ValueError('field validator rejected replacement')

        original = BrokenAIMessage(content='RAW')
        with pytest.raises(GovernanceReinjectionError, match='could not copy'):
            apply_llm_return_replacement(original, 'CLEAN')


# ---------------------------------------------------------------------------
# Async streaming bypass-warning paths
# ---------------------------------------------------------------------------


class TestAsyncBypassWarnings:
    """Cover the async-gen (`astream`) and coroutine (`abatch`) branches in
    `_install_bypass_warnings`. Without these, a regression in the
    iteration-shape dispatch could hang or drop items silently in
    production.
    """

    @pytest.mark.asyncio
    async def test_astream_emits_one_time_warning(self, _patch_transport, caplog):
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        model = FakeListChatModel(responses=['ans1', 'ans2'])
        wrapped = handler.wrap(model)

        with caplog.at_level('WARNING'):
            async for _ in wrapped.astream('hi'):
                pass
            async for _ in wrapped.astream('again'):
                pass

        bypass = [
            r for r in caplog.records
            if 'astream' in r.getMessage() and 'bypasses' in r.getMessage()
        ]
        assert len(bypass) == 1

    @pytest.mark.asyncio
    async def test_abatch_emits_one_time_warning(self, _patch_transport, caplog):
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        model = FakeListChatModel(responses=['a', 'b'])
        wrapped = handler.wrap(model)

        with caplog.at_level('WARNING'):
            await wrapped.abatch(['hi'])
            await wrapped.abatch(['again'])

        bypass = [
            r for r in caplog.records
            if 'abatch' in r.getMessage() and 'bypasses' in r.getMessage()
        ]
        assert len(bypass) == 1


# ---------------------------------------------------------------------------
# bind_tools / with_structured_output / bind derive-warning
# ---------------------------------------------------------------------------


class TestRunnableCompositionDeriveWarning:
    """Calling `bind_tools` / `with_structured_output` / `bind` /
    `configurable_fields` on a wrapped chat model returns a *new* Runnable
    that does NOT carry governance. The wrapper installs a one-time WARN
    on these methods so the silent bypass is observable.
    """

    def test_bind_tools_emits_one_time_derive_warning(self, _patch_transport, caplog):
        handler = BeaconLangGraphGovernanceHandler(stack_ids=['s1'])
        model = FakeListChatModel(responses=['ans'])
        wrapped = handler.wrap(model)

        @tool
        def echo(x: str) -> str:
            """echo"""
            return x

        with caplog.at_level('WARNING'):
            try:
                wrapped.bind_tools([echo])
            except (NotImplementedError, AttributeError):
                # FakeListChatModel may not implement bind_tools; the WARN
                # fires in our wrapper before the underlying call runs.
                pass

        derive = [
            r for r in caplog.records
            if 'bind_tools' in r.getMessage() and 'governance' in r.getMessage()
        ]
        assert len(derive) >= 1


# ---------------------------------------------------------------------------
# Empty ToolNode regression
# ---------------------------------------------------------------------------


class TestEmptyToolNodeWrap:
    """`_extract_tools` previously raised TypeError on a ToolNode whose
    `tools_by_name == {}` because the truthy check fell through to the
    wrong-shape branch.
    """

    def test_empty_toolnode_returns_empty_list_via_helper(self):
        from lumenova_beacon.governance.integrations.langgraph import _extract_tools

        class _EmptyToolNodeShape:
            tools_by_name: dict = {}

        assert _extract_tools(_EmptyToolNodeShape()) == []


# ---------------------------------------------------------------------------
# _ensure_handler explicit fail_open=None preservation
# ---------------------------------------------------------------------------


class TestEnsureHandlerExplicitNone:
    """`_ensure_handler` previously coerced ``fail_open=None`` to ``True``,
    silently flipping fail-closed to fail-open for callers that passed an
    explicit None from a config object. The fix drops _UNSET keys and lets
    the constructor default apply for unsupplied kwargs.
    """

    def test_no_explicit_fail_open_uses_constructor_default(self, _patch_transport):
        # No fail_open passed: handler uses its own default (True).
        wrapped_model = wrap_chat_model(
            FakeListChatModel(responses=['ans']),
            stack_ids=['s1'],
        )
        # Just exercising the path to ensure no error.
        assert wrapped_model is not None
