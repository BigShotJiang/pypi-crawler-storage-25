"""BeaconLangGraphAgent wrapper: three modes for handling governance violations.

Shows the same compiled graph handled three different ways:

    raise  -- bubble GovernanceViolationError up to the caller
    state  -- append a ToolMessage / AIMessage so the agent can recover
    emit   -- yield a synthesised event from astream_events for UI consumers

Requirements:
    pip install lumenova-beacon[langchain]
    pip install langchain-openai langgraph
"""

from __future__ import annotations

import asyncio
from typing import Annotated, Sequence, TypedDict

from langchain_core.messages import BaseMessage, HumanMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph, add_messages
from langgraph.prebuilt import ToolNode

from lumenova_beacon import BeaconClient
from lumenova_beacon.exceptions import GovernanceViolationError
from lumenova_beacon.governance import BeaconLangGraphAgent, GovernanceConfig

import dotenv


# --- Tools ---


@tool
def get_weather(location: str) -> str:
    """Get the current weather for a location."""
    return {'london': 'Cloudy, 61F', 'tokyo': 'Rainy, 68F'}.get(
        location.lower(), f'No data for {location}',
    )


@tool
def send_email(to: str, subject: str, body: str) -> str:
    """Send an email to a recipient."""
    # The governance policy in this example blocks any call to send_email.
    return f'Email sent to {to}: {subject}'


# --- Graph ---


class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]


tools = [get_weather, send_email]
llm = ChatOpenAI(model='gpt-4o-mini', temperature=0).bind_tools(tools)


def call_model(state: AgentState) -> dict:
    return {'messages': [llm.invoke(state['messages'])]}


def should_continue(state: AgentState) -> str:
    last = state['messages'][-1]
    return 'tools' if getattr(last, 'tool_calls', None) else END


workflow = StateGraph(AgentState)
workflow.add_node('agent', call_model)
workflow.add_node('tools', ToolNode(tools))
workflow.set_entry_point('agent')
workflow.add_conditional_edges('agent', should_continue, {'tools': 'tools', END: END})
workflow.add_edge('tools', 'agent')
app = workflow.compile(checkpointer=MemorySaver())


# --- Three modes ---


QUERY = "What's the weather in London, then email admin@example.com about it"


def demo_raise() -> None:
    print('\n--- violation_mode=raise ---')
    agent = BeaconLangGraphAgent(
        graph=app,
        thread_id='wrapper-demo-raise',
        agent_name='governed-agent',
        governance=GovernanceConfig(stack_ids=['governed-agent-001']),
        violation_mode='raise',
    )
    try:
        agent.invoke({'messages': [HumanMessage(content=QUERY)]})
    except GovernanceViolationError as exc:
        print(f'Caught: {exc}')
        print(f'  phase        = {exc.phase}')
        print(f'  tool_call_id = {exc.tool_call_id}')
        print(f'  policies     = {exc.policies}')


def demo_state() -> None:
    print('\n--- violation_mode=state ---')
    agent = BeaconLangGraphAgent(
        graph=app,
        thread_id='wrapper-demo-state',
        agent_name='governed-agent',
        governance=GovernanceConfig(stack_ids=['governed-agent-001']),
        violation_mode='state',
    )
    result = agent.invoke({'messages': [HumanMessage(content=QUERY)]})
    for msg in result['messages']:
        marker = ' [governance]' if msg.additional_kwargs.get(
            'beacon_governance_violation',
        ) else ''
        print(f'{type(msg).__name__}{marker}: {str(msg.content)[:80]}')


async def demo_emit() -> None:
    print('\n--- violation_mode=emit (astream_events) ---')
    agent = BeaconLangGraphAgent(
        graph=app,
        thread_id='wrapper-demo-emit',
        agent_name='governed-agent',
        governance=GovernanceConfig(stack_ids=['governed-agent-001']),
        violation_mode='emit',
    )
    async for event in agent.astream_events(
        {'messages': [HumanMessage(content=QUERY)]},
    ):
        if event.get('name') == 'beacon.governance.violation':
            data = event['data']
            print(f'governance event: phase={data["phase"]} '
                  f'policies={data["policies"]} message={data["message"]!r}')


if __name__ == '__main__':
    dotenv.load_dotenv()
    BeaconClient()  # initialise the global client
    demo_raise()
    demo_state()
    asyncio.run(demo_emit())
