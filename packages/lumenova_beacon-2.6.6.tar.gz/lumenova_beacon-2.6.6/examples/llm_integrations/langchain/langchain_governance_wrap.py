"""Governance via handler.wrap(...) on a LangGraph agent.

Demonstrates the explicit content-reinjection path:
- Construct ONE BeaconLangGraphGovernanceHandler instance.
- Wrap tools and chat model on the INSTANCE (not the class).
- All wrapped targets share the handler's violation counter and stopped flag.

Compare with langchain_governance_agent.py, which uses the integrated
BeaconLangGraphConfig + GovernanceConfig path. Use handler.wrap(...) when you
want policy `output` rewrites to actually replace tool/LLM content; the
callback path can only block, not substitute.

`wrap` is an INSTANCE method. `BeaconLangGraphGovernanceHandler.wrap(tool)`
called on the class will fail because `self` must be bound.

Requirements:
    pip install lumenova-beacon[langchain]
    pip install langchain-openai langgraph
"""

from typing import Annotated, Sequence, TypedDict

import dotenv
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph, add_messages
from langgraph.prebuilt import ToolNode

from lumenova_beacon import BeaconLangGraphGovernanceHandler
from lumenova_beacon.exceptions import GovernanceViolationError

dotenv.load_dotenv()


# --- Tools ---


@tool
def get_weather(location: str) -> str:
    """Get the current weather for a location."""
    return {'london': 'Cloudy, 61F', 'tokyo': 'Rainy, 68F'}.get(
        location.lower(), f'No data for {location}'
    )


@tool
def send_email(to: str, subject: str, body: str) -> str:
    """Send an email to a recipient."""
    return f'Email sent to {to}: {subject}'


# --- Handler instance (owns shared violation state) ---

handler = BeaconLangGraphGovernanceHandler(
    stack_ids=['my-policy-stack'],
    fail_open=True,
    on_violation='raise',
    max_violations=3,
)

# Wrap THROUGH the instance. NOT BeaconLangGraphGovernanceHandler.wrap(...).
wrapped_tools = handler.wrap([get_weather, send_email])
wrapped_llm = handler.wrap(ChatOpenAI(model='gpt-4o-mini', temperature=0))
llm_with_tools = wrapped_llm.bind_tools(wrapped_tools)


# --- Agent graph using wrapped objects ---


class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]


def call_model(state: AgentState):
    return {'messages': [llm_with_tools.invoke(state['messages'])]}


def should_continue(state: AgentState):
    last = state['messages'][-1]
    return 'tools' if getattr(last, 'tool_calls', None) else END


workflow = StateGraph(AgentState)
workflow.add_node('agent', call_model)
workflow.add_node('tools', ToolNode(wrapped_tools))
workflow.set_entry_point('agent')
workflow.add_conditional_edges('agent', should_continue, {'tools': 'tools', END: END})
workflow.add_edge('tools', 'agent')
app = workflow.compile()


if __name__ == '__main__':
    query = 'Weather in London, then email admin@example.com about it'
    print(f'Query: {query}')

    try:
        result = app.invoke({'messages': [HumanMessage(content=query)]})
        print(f'Response: {result["messages"][-1].content}')
    except GovernanceViolationError as e:
        print('\nBlocked by governance policy:')
        print(f'  Message:  {e}')
        print(f'  Policies: {e.policies}')
        print(f'  Latency:  {e.latency_ms:.1f}ms')
    finally:
        # Shared across all wrapped targets via closure.
        print(f'\nGovernance violations: {handler.violation_count}')
