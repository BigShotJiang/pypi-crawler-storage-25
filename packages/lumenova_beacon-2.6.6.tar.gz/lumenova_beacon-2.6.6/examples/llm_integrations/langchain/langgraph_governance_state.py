"""Governance policies that read agent state via ``input.context.state``.

Demonstrates the two-step documentation-writer use case:
    1. Node ``extract_attrs`` infers ``documentation_type`` and ``name``
       from the user's message and writes them into graph state.
    2. Node ``save`` calls the ``save_documentation`` tool. A governance
       policy reads ``input.context.state.documentation_type`` and the
       caller's role from ``input.context.metadata.user_role`` (the
       SDK forwards arbitrary handler metadata under
       ``input.context.metadata``) and blocks business users from
       saving technical docs.

Wire-up:
    - ``BeaconLangGraphConfig`` creates a tracing handler and a
      governance handler with ``include_state=True``.
    - The governance handler captures node-level state from
      ``on_chain_start`` (graph-step boundaries only — RunnableSeq inner
      steps are filtered out) and forwards it as ``input.context.state``.
    - The OPA stack ``doc-stack`` is expected to define a Rego rule
      similar to::

          deny[msg] {
              input.context.metadata.user_role == "business"
              input.context.state.documentation_type == "technical"
              msg := "business users cannot save technical documentation"
          }

Requirements:
    pip install lumenova-beacon[langchain]
    pip install langchain-openai langgraph
"""

from typing import Annotated, Sequence, TypedDict

from langchain_core.messages import BaseMessage, HumanMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph, add_messages
from langgraph.prebuilt import ToolNode

from lumenova_beacon import BeaconClient
from lumenova_beacon.exceptions import GovernanceViolationError
from lumenova_beacon.governance import GovernanceConfig, set_agent_state
from lumenova_beacon.tracing.integrations.langchain import BeaconLangGraphConfig

import dotenv

dotenv.load_dotenv()


client = BeaconClient()


@tool
def save_documentation(name: str, body: str) -> str:
    """Persist a documentation entry with the given name and body."""
    return f'Saved documentation {name!r} ({len(body)} chars)'


class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]
    documentation_type: str | None
    name: str | None


def _classify(text: str) -> str:
    technical_markers = ('api', 'endpoint', 'sdk', 'sql', 'schema', 'integration')
    return 'technical' if any(m in text.lower() for m in technical_markers) else 'business'


def _extract_name(text: str) -> str:
    words = text.strip().split()
    return ' '.join(w.capitalize() for w in words[:4]) or 'Untitled'


def extract_attrs(state: AgentState) -> AgentState:
    last = state['messages'][-1]
    text = last.content if isinstance(last.content, str) else str(last.content)
    enriched = {
        **state,
        'documentation_type': _classify(text),
        'name': _extract_name(text),
    }
    # Optional: tell the governance handler about the enriched values so
    # downstream policies see the *result* of this node, not the snapshot
    # captured at the start of the node. Without this call, the handler
    # would still expose what the node received as input — fine for many
    # use cases, but here we want the policy to evaluate derived fields.
    set_agent_state(enriched)
    return enriched


tools = [save_documentation]
tool_node = ToolNode(tools)

llm = ChatOpenAI(model='gpt-4o-mini', temperature=0)
llm_with_tools = llm.bind_tools(tools)


def save_node(state: AgentState):
    response = llm_with_tools.invoke(state['messages'])
    return {'messages': [response]}


def should_continue(state: AgentState):
    last_message = state['messages'][-1]
    if hasattr(last_message, 'tool_calls') and last_message.tool_calls:
        return 'tools'
    return END


workflow = StateGraph(AgentState)
workflow.add_node('extract', extract_attrs)
workflow.add_node('save', save_node)
workflow.add_node('tools', tool_node)
workflow.set_entry_point('extract')
workflow.add_edge('extract', 'save')
workflow.add_conditional_edges('save', should_continue, {'tools': 'tools', END: END})
workflow.add_edge('tools', 'save')

app = workflow.compile()


beacon = BeaconLangGraphConfig(
    graph=app,
    thread_id='doc-agent-1',
    agent_name='doc-agent',
    environment='development',
    metadata={'user_role': 'business'},
    governance=GovernanceConfig(
        stack_ids=['doc-stack'],
        fail_open=True,
        include_state=True,
        # state_filter is optional — narrow what reaches the policy when the
        # full state contains values you do not want sent over the wire:
        state_filter=lambda s: {
            k: v for k, v in s.items()
            if k in {'documentation_type', 'name'}
        },
    ),
)


if __name__ == '__main__':
    query = 'Please save a technical guide about our SDK API endpoints'
    print(f'Query: {query}')

    config = beacon.get_config()
    try:
        result = app.invoke(
            {
                'messages': [HumanMessage(content=query)],
                'documentation_type': None,
                'name': None,
            },
            config=config,
        )
        print(f'Response: {result["messages"][-1].content}')
    except GovernanceViolationError as e:
        print('\nBlocked by governance policy:')
        print(f'  Message:  {e}')
        print(f'  Policies: {e.policies}')

    if beacon.governance_handler:
        print(f'\nGovernance violations: {beacon.governance_handler.violation_count}')
