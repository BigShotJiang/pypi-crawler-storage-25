"""Main client for the Lumenova Beacon SDK."""

from __future__ import annotations

import copy
import json
import logging
import os
import threading

from contextvars import ContextVar
from datetime import datetime
from typing import TYPE_CHECKING, Any, Callable


if TYPE_CHECKING:
    from opentelemetry.sdk.trace import TracerProvider as OtelTracerProvider

from lumenova_beacon.core.config import BeaconConfig
from lumenova_beacon.core.transport import FileTransport, HTTPTransport
from lumenova_beacon.exceptions import ConfigurationError
from lumenova_beacon.masking.engine import apply_masking
from lumenova_beacon.tracing.span import Span
from lumenova_beacon.tracing.trace import TraceContext, get_current_span, get_current_trace_id
from lumenova_beacon.types import SpanKind, SpanType


logger = logging.getLogger(__name__)


class _UserIdentitySpanProcessor:
    """SpanProcessor that injects user identity attributes into every span.

    This ensures instrumentor-created spans (LangChain, CrewAI, etc.) carry
    user identity even though they don't go through BeaconClient.create_span().
    """

    def __init__(self, identity_attrs: dict[str, str]):
        self._identity_attrs = identity_attrs

    def on_start(self, span, parent_context=None):
        for key, value in self._identity_attrs.items():
            span.set_attribute(key, value)

    def on_end(self, span):
        pass

    def shutdown(self):
        pass

    def force_flush(self, timeout_millis=None):
        return True


# Task-local client instance using contextvars (isolated per async context)
_current_client: ContextVar['BeaconClient | None'] = ContextVar('current_client', default=None)

# Lock protecting module-level mutable state (_singleton_client, _beacon_global_exporter_added, _export_failure_warned)
_global_lock = threading.Lock()

# Module-level singleton client (persists across async contexts)
_singleton_client: 'BeaconClient | None' = None

# Global flag to track if Beacon OTLP exporter has been added (prevents duplicates)
_beacon_global_exporter_added: bool = False

# Track export failures to warn users (only warn once to avoid log spam)
_export_failure_warned: bool = False


_PROXY_DICT_KEYS = {"http", "https", "all"}
# Keys we reject explicitly with a pointer to the right mechanism. ``no``/
# ``no_proxy`` cannot be wired through both transports cleanly (requests
# Session honors ``no_proxy`` only via env merging, which we disable; httpx
# has no first-class equivalent), so accepting it would silently violate
# the user's intent. Direct them to the standard NO_PROXY env var instead.
_PROXY_DICT_REJECTED_KEYS = {"no", "no_proxy"}

# Schemes the proxy translator supports. Other schemes (e.g. ``ftp://``,
# ``mailto:``, or a typo'd ``htp://``) would otherwise pass config and only
# surface later as per-request transport errors; BatchSpanProcessor
# deduplicates export failures, so spans drop near-silently.
_PROXY_URL_SCHEMES = {"http", "https", "socks4", "socks5", "socks5h"}


def _validate_proxy_url(url: str, *, field: str) -> None:
    """Validate that ``url`` parses to a supported proxy scheme + host.

    ``field`` describes the source for error messages (e.g.
    ``"proxies['https']"`` or ``"BEACON_PROXIES"``). The URL string itself is
    never echoed — proxy URLs commonly embed credentials.
    """
    from urllib.parse import urlparse

    try:
        parsed = urlparse(url)
    except ValueError as e:
        raise ConfigurationError(
            f"{field} could not be parsed as a URL"
        ) from e
    scheme = (parsed.scheme or "").lower()
    if scheme not in _PROXY_URL_SCHEMES:
        raise ConfigurationError(
            f"{field} has unsupported scheme {scheme!r}; "
            f"expected one of {sorted(_PROXY_URL_SCHEMES)}"
        )
    if not parsed.netloc:
        raise ConfigurationError(
            f"{field} is missing the host portion (expected scheme://host[:port])"
        )


def _validate_proxies_dict(d: dict) -> dict[str, str] | None:
    """Validate a proxies dict and return it normalized, or None if empty.

    Catches the common typo case (e.g. `{"htps": "..."}` for `https`) where
    requests would silently fall back to a direct (unproxied) connection
    because no scheme key matches.
    """
    if not d:
        return None
    validated: dict[str, str] = {}
    for key, val in d.items():
        if not isinstance(key, str):
            raise ConfigurationError(
                f"proxies dict has unrecognized key {key!r}; "
                f"expected one of {sorted(_PROXY_DICT_KEYS)}"
            )
        key_lower = key.lower()
        if key_lower in _PROXY_DICT_REJECTED_KEYS:
            raise ConfigurationError(
                f"proxies dict key {key!r} is not supported by the SDK "
                "(no first-class equivalent in httpx, and the OTLP session "
                "disables env-based proxy merging). Use the NO_PROXY env "
                "var to bypass the proxy for specific hosts."
            )
        if key_lower not in _PROXY_DICT_KEYS:
            raise ConfigurationError(
                f"proxies dict has unrecognized key {key!r}; "
                f"expected one of {sorted(_PROXY_DICT_KEYS)}"
            )
        if not isinstance(val, str) or not val.strip():
            # Do not echo val — proxy URLs can contain user:password.
            raise ConfigurationError(
                f"proxies[{key!r}] must be a non-empty string"
            )
        stripped = val.strip()
        _validate_proxy_url(stripped, field=f"proxies[{key_lower!r}]")
        validated[key_lower] = stripped
    return validated


def _normalize_proxies(value: dict[str, str] | str | None) -> dict[str, str] | None:
    """Return a requests-compatible proxies dict, or None.

    Accepts a dict (validated), a single URL string (applied to both http and
    https), or a JSON-encoded dict.

    Raises ConfigurationError on malformed JSON, unsupported types, unknown
    dict keys, or empty values — a misconfigured proxy must fail loudly so
    spans do not silently bypass it.
    """
    if value is None:
        return None
    if isinstance(value, dict):
        return _validate_proxies_dict(value)
    if not isinstance(value, str):
        raise ConfigurationError(
            f"proxies must be a dict, URL string, or None; got {type(value).__name__}"
        )
    text = value.strip()
    if not text:
        return None
    # Treat anything that opens with a JSON structural character as JSON so
    # `[1, 2, 3]` errors out instead of being silently treated as a URL.
    if text[0] in "{[":
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as e:
            # Do not echo the raw text — proxy URLs can contain user:password.
            raise ConfigurationError(
                f"Invalid JSON in proxies/BEACON_PROXIES at line {e.lineno} "
                f"column {e.colno}: {e.msg}"
            ) from e
        if not isinstance(parsed, dict):
            raise ConfigurationError(
                f"proxies/BEACON_PROXIES JSON must be an object, got {type(parsed).__name__}"
            )
        return _validate_proxies_dict(parsed)
    _validate_proxy_url(text, field="proxies")
    return {"http": text, "https": text}


_VERIFY_BOOL_TRUE_TOKENS = {"true", "1", "yes", "on", "enable", "enabled"}
_VERIFY_BOOL_FALSE_TOKENS = {"false", "0", "no", "off", "disable", "disabled"}
_VERIFY_BOOL_TOKENS = _VERIFY_BOOL_TRUE_TOKENS | _VERIFY_BOOL_FALSE_TOKENS

# Characters that signal a string is a filesystem path rather than a typo'd
# boolean token. Anything without these AND not in the token set is rejected
# loudly — e.g. `BEACON_VERIFY=none` is more likely a typo for `false` than a
# file literally named "none".
_PATH_HINT_CHARS = frozenset('/\\.~')


def _normalize_verify(value: bool | str | None) -> bool | str | None:
    """Return a requests-compatible verify value.

    Accepts a bool (passed through), a string (bool-like tokens are coerced
    to bool, path-like strings are validated and returned as CA-bundle paths),
    or None. Empty / whitespace-only strings return None so the caller can
    fall back to the env var or the default.

    Raises ConfigurationError on unrecognized tokens (which are usually typos)
    and on CA-bundle paths that do not exist — a typo'd path would otherwise
    only surface as a one-shot export warning before all spans drop silently.
    """
    if value is None or isinstance(value, bool):
        return value
    if not isinstance(value, str):
        raise ConfigurationError(
            f"verify must be a bool, path string, or None; got {type(value).__name__}"
        )
    text = value.strip()
    if not text:
        return None
    lowered = text.lower()
    if lowered in _VERIFY_BOOL_TOKENS:
        return lowered in _VERIFY_BOOL_TRUE_TOKENS
    if not any(c in text for c in _PATH_HINT_CHARS):
        raise ConfigurationError(
            f"verify={value!r} is not a recognized boolean token and does not "
            f"look like a filesystem path. Use one of "
            f"{sorted(_VERIFY_BOOL_TOKENS)} or a path to a CA bundle PEM file."
        )
    if not os.path.isfile(text):
        raise ConfigurationError(
            f"verify CA bundle path does not exist: {text!r}"
        )
    return text


def _normalize_cert(
    value: str | tuple[str, str] | list[str] | None,
) -> str | tuple[str, str] | None:
    """Return a requests-compatible cert value.

    Accepts None, a string path (combined cert+key PEM), or a 2-element
    tuple/list of (cert_path, key_path).

    Raises ConfigurationError on malformed shapes or missing files — silently
    dropping client auth would downgrade mTLS without the user's knowledge,
    and a missing path would only surface as a one-shot export warning before
    all spans drop silently via the BatchSpanProcessor's deduplicated logging.
    """
    if value is None:
        return None
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        if not os.path.isfile(text):
            raise ConfigurationError(
                f"cert file does not exist: {text!r}"
            )
        return text
    if isinstance(value, (tuple, list)):
        if len(value) == 2 and all(isinstance(p, str) and p.strip() for p in value):
            cert_path, key_path = value[0].strip(), value[1].strip()
            if not os.path.isfile(cert_path):
                raise ConfigurationError(
                    f"cert file does not exist: {cert_path!r}"
                )
            if not os.path.isfile(key_path):
                raise ConfigurationError(
                    f"cert key file does not exist: {key_path!r}"
                )
            return (cert_path, key_path)
        raise ConfigurationError(
            f"cert must be a path string or a (cert_path, key_path) pair; got {value!r}"
        )
    raise ConfigurationError(
        f"cert must be a path string or a (cert_path, key_path) pair; "
        f"got {type(value).__name__}"
    )


def _make_beacon_session(
    proxies: dict[str, str] | None,
    force_verify_false: bool,
):
    """Build a requests.Session that resists per-request and env overrides.

    The OTLP HTTP exporter calls ``session.post(url, verify=..., cert=...)``
    with explicit kwargs and does not forward a ``proxies=`` kwarg. Because
    ``requests.Session.request`` calls ``merge_environment_settings``,
    per-request kwargs win over session attributes, and env vars
    (``HTTPS_PROXY`` / ``HTTP_PROXY`` / ``REQUESTS_CA_BUNDLE``) win when the
    corresponding session attribute is unset. So we override ``request`` to
    force the values we want, and set ``trust_env=False`` unconditionally so
    env-injected proxies and CA bundles cannot silently replace what the user
    explicitly configured — including the ``verify=False`` case where a stray
    ``HTTPS_PROXY`` would otherwise route plaintext-disabled traffic through
    an unintended proxy, and the ``verify=<CA-path>`` case where a stray
    ``REQUESTS_CA_BUNDLE`` would shadow the explicit path.

    When ``force_verify_false`` is set, ``urllib3.InsecureRequestWarning`` is
    suppressed only for the duration of this session's requests via a
    ``warnings.catch_warnings()`` block — process-wide
    ``urllib3.disable_warnings`` would silence warnings for unrelated
    libraries (boto3, third-party SDKs, etc.) using urllib3.
    """
    import warnings

    import requests
    import urllib3

    forced_proxies = dict(proxies) if proxies else None

    class _BeaconSession(requests.Session):
        def request(self, method, url, **req_kwargs):
            if forced_proxies is not None:
                req_kwargs['proxies'] = forced_proxies
            if force_verify_false:
                req_kwargs['verify'] = False
                with warnings.catch_warnings():
                    warnings.simplefilter(
                        'ignore', urllib3.exceptions.InsecureRequestWarning
                    )
                    return super().request(method, url, **req_kwargs)
            return super().request(method, url, **req_kwargs)

    session = _BeaconSession()
    session.trust_env = False
    if forced_proxies is not None:
        session.proxies = forced_proxies
    return session


class BeaconClient:
    """Main client for creating and sending spans."""

    def __init__(
        self,
        endpoint: str | None = None,
        api_key: str | None = None,
        file_directory: str | None = None,
        session_id: str | None = None,
        user_email: str | None = None,
        user_name: str | None = None,
        user_id: str | None = None,
        service_name: str | None = None,
        environment: str | None = None,
        auto_instrument_opentelemetry: bool = True,
        isolated: bool = False,
        auto_instrument_litellm: bool = False,
        masking_function: Callable[[Any], Any] | None = None,
        verify: bool | str | None = None,
        proxies: dict[str, str] | str | None = None,
        cert: str | tuple[str, str] | None = None,
        eager_export: bool | None = None,
        record_stacktrace: bool = False,
        database_callback: Callable[[Span], None] | None = None,
        **kwargs,
    ):
        """Initialize the Beacon client.

        Configuration priority (constructor params override env vars):
        - Constructor parameters take precedence
        - Environment variables as fallback

        Spans are sent via OpenTelemetry's OTLPSpanExporter to the /v1/traces endpoint.
        Authentication is handled via 'headers' parameter or OTEL_EXPORTER_OTLP_HEADERS env var.

        Args:
            endpoint: Base server URL (e.g., "https://api.example.com"). Falls back to BEACON_ENDPOINT.
            api_key: API key for authentication (falls back to BEACON_API_KEY)
            file_directory: Directory to save span files (File mode)
            session_id: Default session ID for all spans (falls back to BEACON_SESSION_ID)
            user_email: Default user email for attribution (falls back to BEACON_USER_EMAIL)
            user_name: Default user display name for attribution (falls back to BEACON_USER_NAME)
            user_id: Default user ID for attribution (falls back to BEACON_USER_ID)
            service_name: Logical service name for OpenTelemetry resource (falls back to BEACON_SERVICE_NAME)
            environment: Deployment environment name (e.g., "production", "staging"). Falls back to BEACON_ENVIRONMENT.
            auto_instrument_opentelemetry: Automatically set up OpenTelemetry integration (default: True)
            auto_instrument_litellm: Automatically set up LiteLLM integration (default: False)
            masking_function: Custom function to mask sensitive data before transmission (optional)
            verify: SSL certificate verification applied to all SDK HTTP calls
                (OTLP trace export and REST API operations — guardrails,
                governance, evaluations, etc.). True (default) verifies against
                the system CA store, False disables verification, and a string
                is treated as a path to a CA bundle PEM file (must exist at
                config time). Falls back to BEACON_VERIFY (accepts bool-like
                tokens or a path). Invalid types, unrecognized tokens (likely
                typos), and missing CA bundle paths raise ConfigurationError —
                a typo'd path would otherwise only surface as a one-shot
                warning before all spans drop silently. Has no effect on extra
                gRPC OTLP endpoints — set OTEL_EXPORTER_OTLP_CERTIFICATE for a
                custom CA bundle on those.
            proxies: HTTP(S) proxy configuration applied to all SDK HTTP calls
                (OTLP trace export and REST API operations). Accepts a
                requests-style dict with keys in {http, https, all} (e.g.
                {"http": "http://proxy:8080", "https": "..."}) or a single URL
                string applied to both http and https. Falls back to
                BEACON_PROXIES (URL string or JSON dict). Invalid types,
                malformed JSON, unknown dict keys, and empty values raise
                ConfigurationError. Has no effect on extra gRPC OTLP endpoints —
                set `grpc_proxy`/`https_proxy` env vars for those. The `no` /
                `no_proxy` dict key is rejected (httpx has no first-class
                equivalent and the OTLP session disables env merging); use the
                NO_PROXY environment variable to bypass the proxy for specific
                hosts.
            cert: Client certificate for mutual TLS, applied to all SDK HTTP
                calls (OTLP trace export and REST API operations). Either a
                path to a combined cert+key PEM, or a (cert_path, key_path)
                tuple. Path(s) must exist at config time. Falls back to
                BEACON_CLIENT_CERT (and BEACON_CLIENT_KEY when keys are
                separate); BEACON_CLIENT_KEY without BEACON_CLIENT_CERT raises
                ConfigurationError, as do malformed shapes and missing files.
                Has no effect on extra gRPC OTLP endpoints — set
                OTEL_EXPORTER_OTLP_CLIENT_CERTIFICATE / _CLIENT_KEY (and
                OTEL_EXPORTER_OTLP_CERTIFICATE for a custom CA bundle) for
                those.
            record_stacktrace: Capture full stack traces when recording exceptions (default: False)
            database_callback: Callback function for direct database export (internal use only)
            **kwargs: Additional configuration options (timeout, enabled, headers, etc.)
        """

        # Store database callback for internal use
        self._database_callback = database_callback

        # Suppress repeated verify=False warnings across the primary endpoint
        # and any extra HTTP endpoints — fired once per client instance.
        self._verify_false_warned = False

        # Empty / whitespace-only strings are treated as "not provided" so
        # config-file emitters that default to "" (or "  ") don't suppress the
        # env fallback.
        def _is_unset(v: object) -> bool:
            return v is None or (isinstance(v, str) and not v.strip())

        verify = _normalize_verify(
            verify if not _is_unset(verify) else os.getenv('BEACON_VERIFY')
        )
        if verify is None:
            verify = True

        endpoint = endpoint if endpoint is not None else os.getenv('BEACON_ENDPOINT', '')
        api_key = api_key if api_key is not None else os.getenv('BEACON_API_KEY')

        # Third-tier fallback: AWS Secrets Manager (only if no api_key yet)
        if api_key is None:
            from lumenova_beacon.core.secrets import resolve_api_key_from_aws
            api_key = resolve_api_key_from_aws()

        service_name = service_name if service_name is not None else os.getenv('BEACON_SERVICE_NAME', os.getenv('OTEL_SERVICE_NAME'))
        session_id = session_id if session_id is not None else os.getenv('BEACON_SESSION_ID')
        user_email = user_email if user_email is not None else os.getenv('BEACON_USER_EMAIL')
        user_name = user_name if user_name is not None else os.getenv('BEACON_USER_NAME')
        user_id = user_id if user_id is not None else os.getenv('BEACON_USER_ID')
        environment = environment if environment is not None else os.getenv('BEACON_ENVIRONMENT')

        # Resolve eager_export from env var
        if eager_export is None:
            eager_export_env = os.getenv('BEACON_EAGER_EXPORT', 'true').lower()
            eager_export = eager_export_env not in ('false', '0', 'no')

        # Resolve isolated from env var (constructor param overrides)
        if not isolated:
            isolated_env = os.getenv('BEACON_ISOLATED', 'false').lower()
            isolated = isolated_env not in ('false', '0', 'no')

        proxies = _normalize_proxies(
            proxies if not _is_unset(proxies) else os.getenv('BEACON_PROXIES')
        )

        if _is_unset(cert):
            env_cert = os.getenv('BEACON_CLIENT_CERT')
            env_key = os.getenv('BEACON_CLIENT_KEY')
            if env_cert and env_key:
                cert = (env_cert, env_key)
            elif env_cert:
                cert = env_cert
            elif env_key:
                raise ConfigurationError(
                    "BEACON_CLIENT_KEY is set without BEACON_CLIENT_CERT — "
                    "both are required to assemble a (cert, key) pair for mTLS"
                )
        cert = _normalize_cert(cert)

        # Build headers - start with custom headers if provided, then add auth
        headers = dict(kwargs.pop('headers', {}))
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        config = BeaconConfig(
            endpoint=endpoint,
            api_key=api_key,
            file_directory=file_directory or '',
            session_id=session_id,
            user_email=user_email,
            user_name=user_name,
            user_id=user_id,
            service_name=service_name,
            environment=environment,
            verify=verify,
            masking_function=masking_function,
            headers=headers,
            eager_export=eager_export,
            record_stacktrace=record_stacktrace,
            proxies=proxies,
            cert=cert,
            **kwargs,
        )

        # Skip validation if database_callback is provided (internal mode)
        if not database_callback:
            config.validate()
        self.config = config

        # Configure logger to always show warnings, and show debug when debug=True
        # This ensures export failures are visible to users even without debug mode
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)

        if config.debug:
            logger.setLevel(logging.DEBUG)
            for h in logger.handlers:
                h.setLevel(logging.DEBUG)
        else:
            # Ensure WARNING level so critical errors are visible
            if logger.level == logging.NOTSET or logger.level > logging.WARNING:
                logger.setLevel(logging.WARNING)
            for h in logger.handlers:
                if h.level == logging.NOTSET or h.level > logging.WARNING:
                    h.setLevel(logging.WARNING)

        if config.file_directory:
            # File mode: file_directory is provided
            self.transport = FileTransport(
                directory=config.file_directory,
                filename_pattern=config.file_filename_pattern,
                pretty_print=config.file_pretty_print,
            )
        else:
            # HTTP mode: endpoint is provided
            self.transport = HTTPTransport(
                endpoint=config.endpoint,
                api_key=config.api_key,
                timeout=config.timeout,
                headers=config.headers,
                verify=config.verify,
                proxies=config.proxies,
                cert=config.cert,
            )

        global _singleton_client
        _current_client.set(self)
        with _global_lock:
            _singleton_client = self

        # Timestamp override for seeding historical data
        self._timestamp_override: datetime | None = None

        # Store OTEL resource for span export (built from service_name + session_id)
        self._otel_resource = None

        # Store reference to the TracerProvider Beacon is using (may differ from global)
        self._otel_provider: 'OtelTracerProvider | None' = None

        # Automatically set up OpenTelemetry integration if requested
        if auto_instrument_opentelemetry:
            self._setup_opentelemetry(isolated=isolated)
            self._setup_additional_otlp_endpoints()

        # Automatically set up LiteLLM integration if requested
        if auto_instrument_litellm:
            self._setup_litellm()


    def _check_endpoint_connectivity(self) -> None:
        """Check if the endpoint is reachable and log WARNING if not.

        This is called during setup to provide early warning about connectivity
        issues that would prevent spans from being exported.
        """
        import socket

        from urllib.parse import urlparse

        parsed = urlparse(self.config.endpoint)
        host = parsed.hostname
        if not host:
            logger.warning(
                f"Invalid endpoint URL: {self.config.endpoint}. "
                "Spans will not be exported."
            )
            return

        port = parsed.port or (443 if parsed.scheme == 'https' else 80)

        try:
            socket.create_connection((host, port), timeout=5)
        except socket.gaierror as e:
            logger.warning(
                f"DNS resolution failed for {host}: {e}. "
                "Spans will not be exported until this is resolved."
            )
        except socket.timeout:
            logger.warning(
                f"Connection to {host}:{port} timed out. "
                "Spans may not be exported if the endpoint is unreachable."
            )
        except (ConnectionRefusedError, OSError) as e:
            logger.warning(
                f"Cannot connect to {self.config.endpoint}: {e}. "
                "Spans will not be exported until this is resolved."
            )

    def _setup_opentelemetry(self, isolated: bool = False) -> None:
        """Automatically configure OpenTelemetry to export spans.

        Sets up either OTLPSpanExporter (HTTP mode) or FileSpanExporter (file-only mode).
        This is called automatically when auto_instrument_opentelemetry=True (default).

        Args:
            isolated: If True, create a new TracerProvider without touching the global.
                      If False (default), attach to existing global or create new global.

        Note:
            If OpenTelemetry SDK is not installed, this method logs a warning
            and returns without raising an error (optional dependency).
        """
        global _beacon_global_exporter_added

        try:
            from opentelemetry import trace
            from opentelemetry.sdk.resources import Resource
            from opentelemetry.sdk.trace import SpanLimits, TracerProvider
            from opentelemetry.sdk.trace.export import BatchSpanProcessor
        except ImportError:
            logger.error(
                'OpenTelemetry SDK not installed — spans will NOT be exported. '
                'Install with: pip install lumenova-beacon[opentelemetry]'
            )
            return

        # Enable OpenTelemetry logging to surface export errors
        # Always enable WARNING level; DEBUG level only when debug=True
        import logging as stdlib_logging
        otel_logger = stdlib_logging.getLogger('opentelemetry')

        # Ensure OTel logger has a handler so messages are visible
        if not otel_logger.handlers:
            handler = stdlib_logging.StreamHandler()
            formatter = stdlib_logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            otel_logger.addHandler(handler)

        if self.config.debug:
            otel_logger.setLevel(stdlib_logging.DEBUG)
            for h in otel_logger.handlers:
                h.setLevel(stdlib_logging.DEBUG)
        else:
            # Ensure at least WARNING level so export errors are visible
            if otel_logger.level == stdlib_logging.NOTSET or otel_logger.level > stdlib_logging.WARNING:
                otel_logger.setLevel(stdlib_logging.WARNING)
            for h in otel_logger.handlers:
                if h.level == stdlib_logging.NOTSET or h.level > stdlib_logging.WARNING:
                    h.setLevel(stdlib_logging.WARNING)

        # Build the resource for this client (used in export_span regardless of provider)
        try:
            from importlib.metadata import version as pkg_version
            sdk_version = pkg_version("lumenova-beacon")
        except ImportError:
            from lumenova_beacon import __version__
            sdk_version = __version__
        resource_attrs = {
            "service.name": self.config.service_name or "unknown_service",
            "telemetry.sdk.name": "lumenova-beacon",
            "telemetry.sdk.version": sdk_version,
            "telemetry.sdk.language": "python",
        }
        if self.config.session_id:
            resource_attrs["beacon.session.id"] = self.config.session_id
        if self.config.user_email:
            resource_attrs["user.email"] = self.config.user_email
        if self.config.user_name:
            resource_attrs["user.name"] = self.config.user_name
        if self.config.user_id:
            resource_attrs["user.id"] = self.config.user_id
        if self.config.environment:
            resource_attrs["deployment.environment.name"] = self.config.environment
        self._otel_resource = Resource.create(resource_attrs)

        # Build user identity attributes to inject into all spans
        user_identity_attrs = {}
        if self.config.user_email:
            user_identity_attrs["user.email"] = self.config.user_email
        if self.config.user_name:
            user_identity_attrs["user.name"] = self.config.user_name
        if self.config.user_id:
            user_identity_attrs["user.id"] = self.config.user_id

        # Non-isolated path: reuse existing global provider if present
        if not isolated:
            with _global_lock:
                if _beacon_global_exporter_added:
                    logger.debug('Beacon already registered with global provider, skipping')
                    return
                current_provider = trace.get_tracer_provider()
                if isinstance(current_provider, TracerProvider):
                    self._otel_provider = current_provider
                    # Add user identity processor so instrumentor spans carry user info
                    if user_identity_attrs:
                        current_provider.add_span_processor(
                            _UserIdentitySpanProcessor(user_identity_attrs)
                        )
                    _beacon_global_exporter_added = True
                    logger.info('Using existing TracerProvider for Beacon span export')
                    return

        # Create exporter — only needed when creating a new provider
        exporter = self._create_exporter()
        if exporter is None:
            return

        # Configure span limits to allow unlimited attribute value length
        # Default OTEL limit is 4096 chars which truncates large JSON outputs
        span_limits = SpanLimits(max_attribute_length=None)

        # Create a new TracerProvider (isolated, or no existing global)
        try:
            provider = TracerProvider(resource=self._otel_resource, span_limits=span_limits)
            provider.add_span_processor(BatchSpanProcessor(exporter))
            self._otel_provider = provider

            if not isolated:
                with _global_lock:
                    trace.set_tracer_provider(provider)
                    _beacon_global_exporter_added = True
                # Add user identity processor to global provider
                if user_identity_attrs:
                    provider.add_span_processor(
                        _UserIdentitySpanProcessor(user_identity_attrs)
                    )
                logger.info('OpenTelemetry integration configured automatically')
            else:
                logger.info('OpenTelemetry integration configured with isolated TracerProvider')
                # When isolated, also inject user identity into the global provider
                # so that instrumentor spans (which use the global provider) carry user info
                if user_identity_attrs:
                    global_provider = trace.get_tracer_provider()
                    if isinstance(global_provider, TracerProvider):
                        global_provider.add_span_processor(
                            _UserIdentitySpanProcessor(user_identity_attrs)
                        )

            if self.config.endpoint:
                self._check_endpoint_connectivity()
        except Exception as e:
            logger.error('Failed to set up OpenTelemetry provider: %s', e, exc_info=True)

    def _create_exporter(self):
        """Create the appropriate span exporter based on configuration.

        Returns:
            FileSpanExporter for file-only mode, OTLPSpanExporter for HTTP mode,
            or None if creation fails.
        """
        if self.config.endpoint:
            return self._create_otlp_exporter()

        if self.config.file_directory:
            from lumenova_beacon.tracing.exporters.opentelemetry import FileSpanExporter
            logger.info(f"File-only mode: spans will be exported to {self.config.file_directory}")
            return FileSpanExporter(
                directory=self.config.file_directory,
                filename_pattern=self.config.file_filename_pattern,
                pretty_print=self.config.file_pretty_print,
            )

        return None

    def _setup_litellm(self) -> None:
        """Automatically configure LiteLLM to send spans to Beacon.

        This method creates a BeaconLiteLLMLogger and registers it with
        litellm.callbacks. This is called automatically when
        auto_instrument_litellm=True is set (default: False).

        Note:
            If litellm is not installed, this method logs a warning
            and returns without raising an error (optional dependency).

            If a BeaconLiteLLMLogger is already registered, this method
            skips registration to avoid duplicates.
        """
        try:
            import litellm
        except ImportError:
            logger.warning(
                'litellm not installed. Skipping automatic instrumentation. '
                'Install with: pip install litellm'
            )
            return

        # Check if BeaconLiteLLMLogger is already registered
        if litellm.callbacks:
            for callback in litellm.callbacks:
                if callback.__class__.__name__ == 'BeaconLiteLLMLogger':
                    logger.debug('LiteLLM already has BeaconLiteLLMLogger registered, skipping auto-setup')
                    return

        try:
            from lumenova_beacon.tracing.integrations.litellm import BeaconLiteLLMLogger

            # Create logger instance (it will use this client via get_client())
            beacon_logger = BeaconLiteLLMLogger()

            # Register with LiteLLM
            if litellm.callbacks is None:
                litellm.callbacks = [beacon_logger]
            else:
                litellm.callbacks.append(beacon_logger)

            logger.info('LiteLLM integration configured automatically')
        except Exception as e:
            # User explicitly opted in via auto_instrument_litellm=True — if
            # setup fails they need the full stack trace, not just a one-line
            # warning.
            logger.error(
                'Failed to set up LiteLLM integration: %s', e, exc_info=True
            )

    def _build_http_exporter_kwargs(self) -> dict[str, Any]:
        """Build OTLP HTTP exporter kwargs derived from verify/cert/proxies config.

        Shared by the primary endpoint and extra HTTP endpoints. CA-bundle path
        and client cert go via the exporter's native ``certificate_file`` /
        ``client_certificate_file`` / ``client_key_file`` kwargs because the
        exporter calls ``session.post(..., verify=..., cert=...)`` with explicit
        kwargs on every export — those win over session attributes via
        ``requests.merge_setting``, so session-level wiring would not actually
        take effect. A custom ``requests.Session`` is built only when proxies
        are set or verify=False is requested (the latter still needs a
        request-level override because the exporter coerces
        ``certificate_file=False`` to True).
        """
        kwargs: dict[str, Any] = {}

        if isinstance(self.config.verify, str):
            kwargs["certificate_file"] = self.config.verify
        if isinstance(self.config.cert, str):
            kwargs["client_certificate_file"] = self.config.cert
        elif isinstance(self.config.cert, tuple):
            kwargs["client_certificate_file"] = self.config.cert[0]
            kwargs["client_key_file"] = self.config.cert[1]

        # Build the custom session whenever an env var could silently override
        # explicit config: a CA-bundle path is shadowed by REQUESTS_CA_BUNDLE,
        # explicit proxies by HTTPS_PROXY/HTTP_PROXY, and verify=False by a
        # trusted env CA bundle. ``trust_env=False`` on the session blocks
        # all three.
        verify_is_path = isinstance(self.config.verify, str)
        if self.config.proxies or self.config.verify is False or verify_is_path:
            if self.config.verify is False and not self._verify_false_warned:
                # InsecureRequestWarning is suppressed only within the session's
                # request() override (see _make_beacon_session) — operators
                # watching other libraries' urllib3 warnings remain unaffected.
                logger.warning(
                    "TLS verification disabled for OTLP exports — "
                    "InsecureRequestWarning suppressed for Beacon's session only."
                )
                self._verify_false_warned = True

            # ``trust_env=False`` on the custom session blocks env-injected
            # proxies and CA bundles, but operators expect a heads-up when an
            # env var they set is being intentionally ignored — fires whether
            # the trigger was explicit proxies, verify=False, or a verify path.
            shadowed_env_vars = [
                name for name in (
                    'HTTPS_PROXY', 'HTTP_PROXY', 'https_proxy', 'http_proxy'
                ) if os.environ.get(name)
            ]
            # CA-bundle env vars only matter when explicit verify config is in
            # play (a path or False); plain proxy config doesn't override them.
            if verify_is_path or self.config.verify is False:
                shadowed_env_vars.extend(
                    name for name in (
                        'REQUESTS_CA_BUNDLE', 'CURL_CA_BUNDLE', 'SSL_CERT_FILE'
                    ) if os.environ.get(name)
                )
            if shadowed_env_vars:
                logger.warning(
                    "Beacon session ignoring %s env var(s) for OTLP HTTP "
                    "exports (explicit proxies/verify config takes precedence).",
                    ", ".join(shadowed_env_vars),
                )

            kwargs["session"] = _make_beacon_session(
                proxies=self.config.proxies,
                force_verify_false=self.config.verify is False,
            )

        return kwargs

    def _create_otlp_exporter(self):
        """Create and configure an OTLP exporter.

        Returns:
            Configured OTLPSpanExporter instance

        Raises:
            ImportError: If OTLP exporter package is not installed
        """
        try:
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        except ImportError:
            logger.error(
                "OTLP exporter not installed. "
                "Install with: pip install opentelemetry-exporter-otlp-proto-http"
            )
            raise

        endpoint = self.config.endpoint.rstrip('/')
        if not endpoint.endswith('/v1/traces'):
            endpoint = f"{endpoint}/v1/traces"

        headers = dict(self.config.headers)
        if self.config.session_id:
            headers["x-beacon-session-id"] = self.config.session_id

        exporter_kwargs: dict[str, Any] = {
            "endpoint": endpoint,
            "headers": headers,
            "timeout": int(self.config.timeout),
            **self._build_http_exporter_kwargs(),
        }

        # Temporarily clear OTEL env vars so OTLPSpanExporter doesn't read them
        # internally and overwrite our explicit endpoint/headers. These env vars are
        # intended for the global (infra) provider — not for Beacon's isolated exporter.
        _saved_otlp_headers = os.environ.pop('OTEL_EXPORTER_OTLP_HEADERS', None)
        _saved_otlp_endpoint = os.environ.pop('OTEL_EXPORTER_OTLP_ENDPOINT', None)
        try:
            exporter = OTLPSpanExporter(**exporter_kwargs)
        finally:
            if _saved_otlp_headers is not None:
                os.environ['OTEL_EXPORTER_OTLP_HEADERS'] = _saved_otlp_headers
            if _saved_otlp_endpoint is not None:
                os.environ['OTEL_EXPORTER_OTLP_ENDPOINT'] = _saved_otlp_endpoint
        return exporter

    def add_span_exporter(self, exporter) -> None:
        """Add an additional span exporter to the TracerProvider.

        Allows sending spans to multiple OTLP-compatible destinations
        in parallel. The exporter is wrapped in a BatchSpanProcessor
        and added to the existing TracerProvider.

        Args:
            exporter: An OpenTelemetry SpanExporter instance

        Raises:
            RuntimeError: If no TracerProvider is configured
        """
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        provider = self._otel_provider or trace.get_tracer_provider()
        if not isinstance(provider, TracerProvider):
            raise RuntimeError(
                "No TracerProvider configured. "
                "Ensure BeaconClient is initialized with auto_instrument_opentelemetry=True."
            )

        processor = BatchSpanProcessor(exporter)
        provider.add_span_processor(processor)
        logger.info("Added additional span exporter to TracerProvider")

    def _setup_additional_otlp_endpoints(self) -> None:
        """Configure additional OTLP exporter endpoints from BEACON_EXTRA_OTLP_ENDPOINTS.

        Parses a comma-separated list of OTLP endpoint URLs and creates an
        OTLPSpanExporter for each. The protocol is auto-detected from the port:
        port 4318 uses HTTP/protobuf, everything else uses gRPC.

        Headers are shared except for the Authorization header, which is
        excluded from extra endpoints.

        Example:
            BEACON_EXTRA_OTLP_ENDPOINTS=http://grpc-collector:4317,http://http-collector:4318
        """
        endpoints_raw = os.getenv('BEACON_EXTRA_OTLP_ENDPOINTS')
        if not endpoints_raw:
            return

        endpoints = [ep.strip() for ep in endpoints_raw.split(',') if ep.strip()]
        if not endpoints:
            return

        from urllib.parse import urlparse

        # Refuse `verify=False` when any extra endpoint resolves to gRPC: the
        # gRPC exporter ignores the SDK's verify setting and would keep TLS
        # verification on, contradicting the user's explicit "off" intent.
        # This must run before the per-endpoint try/except below — silently
        # downgrading a verify=False intent to "verify on for gRPC" is exactly
        # the kind of security-relevant silent failure config-time validation
        # exists to prevent.
        if self.config.verify is False:
            for endpoint in endpoints:
                port = urlparse(endpoint.rstrip('/')).port
                if port != 4318:
                    raise ConfigurationError(
                        f"verify=False is incompatible with the gRPC extra OTLP "
                        f"endpoint {endpoint!r}: the gRPC exporter does not honor "
                        f"the SDK verify setting and would keep TLS verification "
                        f"on. Use the gRPC channel's own insecure-channel "
                        f"mechanism (e.g. an insecure scheme), point the "
                        f"endpoint at the HTTP exporter on port 4318, or remove "
                        f"verify=False."
                    )

        for endpoint in endpoints:
            try:
                url = endpoint.rstrip('/')
                parsed = urlparse(url)
                port = parsed.port

                # Auto-detect protocol: port 4318 → HTTP/protobuf, else → gRPC
                is_http = port == 4318
                if is_http:
                    try:
                        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                            OTLPSpanExporter,
                        )
                    except ImportError:
                        logger.warning(
                            'HTTP OTLP exporter not installed for endpoint %s. '
                            'Install with: pip install opentelemetry-exporter-otlp-proto-http',
                            endpoint,
                        )
                        continue

                    if not url.endswith('/v1/traces'):
                        url = f"{url}/v1/traces"
                else:
                    try:
                        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
                            OTLPSpanExporter,
                        )
                    except ImportError:
                        logger.warning(
                            'gRPC OTLP exporter not installed for endpoint %s. '
                            'Install with: pip install opentelemetry-exporter-otlp-proto-grpc',
                            endpoint,
                        )
                        continue

                # Share headers but exclude authorization for extra endpoints
                headers = {
                    k: v for k, v in self.config.headers.items()
                    if k.lower() != "authorization"
                }
                if self.config.session_id:
                    headers["x-beacon-session-id"] = self.config.session_id

                exporter_kwargs: dict[str, Any] = {
                    "endpoint": url,
                    "headers": headers,
                    "timeout": int(self.config.timeout),
                }
                # HTTP extras share the verify/cert/proxies plumbing with the
                # primary endpoint. gRPC extras are configured via the standard
                # grpc_proxy/https_proxy and OTEL_EXPORTER_OTLP_* env vars
                # (BEACON_PROXIES / BEACON_CLIENT_CERT do not propagate into
                # those — set them yourself if you need gRPC mTLS or proxying).
                if is_http:
                    exporter_kwargs.update(self._build_http_exporter_kwargs())
                elif (
                    self.config.proxies
                    or self.config.cert
                    or isinstance(self.config.verify, str)
                ):
                    # verify=False on gRPC is rejected up-front (above) — only
                    # the path/cert/proxies combinations reach here, where the
                    # gRPC exporter would simply ignore them silently.
                    logger.warning(
                        "Endpoint %s is gRPC; BeaconClient proxies/cert/verify "
                        "settings are NOT applied to it. Use grpc_proxy / "
                        "https_proxy env vars for proxying and "
                        "OTEL_EXPORTER_OTLP_CERTIFICATE / _CLIENT_CERTIFICATE / "
                        "_CLIENT_KEY env vars for mTLS on this endpoint.",
                        endpoint,
                    )

                exporter = OTLPSpanExporter(**exporter_kwargs)
                self.add_span_exporter(exporter)
                protocol = "HTTP" if is_http else "gRPC"
                logger.info("Added additional OTLP endpoint (%s): %s", protocol, endpoint)
            except ImportError as e:
                logger.error(
                    "OTLP exporter package missing for endpoint %s: %s",
                    endpoint, e,
                )
            except ConfigurationError as e:
                logger.error(
                    "Invalid configuration for OTLP endpoint %s: %s",
                    endpoint, e,
                )
            except Exception as e:
                # Span data loss for an extra endpoint is a user-visible
                # incident, not a warning. exc_info=True so the root cause
                # is recoverable from logs.
                logger.error(
                    "Failed to add OTLP endpoint %s: %s",
                    endpoint, e, exc_info=True,
                )

    @property
    def timestamp_override(self) -> 'datetime | None':
        """Timestamp override for seeding historical data, or None for real-time."""
        return self._timestamp_override

    @timestamp_override.setter
    def timestamp_override(self, value: 'datetime | None') -> None:
        self._timestamp_override = value

    @property
    def otel_provider(self) -> 'OtelTracerProvider':
        """Return the TracerProvider Beacon is exporting spans to.

        Returns the stored isolated provider when initialized with isolated=True,
        otherwise falls back to the global TracerProvider.
        """
        from opentelemetry import trace as _trace
        from opentelemetry.sdk.trace import TracerProvider as _SDKTracerProvider
        if self._otel_provider is not None:
            return self._otel_provider
        provider = _trace.get_tracer_provider()
        if not isinstance(provider, _SDKTracerProvider):
            raise RuntimeError(
                "No SDK TracerProvider configured. "
                "Ensure BeaconClient is initialized with auto_instrument_opentelemetry=True, "
                "or that a global SDK TracerProvider is set before accessing otel_provider."
            )
        return provider

    def should_sample(self) -> bool:
        """Determine if the current operation should be sampled.

        Returns:
            True if should sample, False otherwise
        """
        if not self.config.enabled:
            return False
        return True

    def create_span(
        self,
        name: str,
        *,
        kind: SpanKind = SpanKind.INTERNAL,
        span_type: SpanType = SpanType.SPAN,
        auto_parent: bool = True,
        session_id: str | None = None,
        user_email: str | None = None,
        user_name: str | None = None,
        user_id: str | None = None,
    ) -> Span:
        """Create a new span.

        Args:
            name: Name of the span
            kind: Type of span (default: INTERNAL)
            span_type: Type of span (default: SPAN)
            auto_parent: Automatically set parent from context (default: True)
            session_id: Session ID (optional, inherits from parent or client default)
            user_email: User email for attribution (optional, inherits from parent or client default)
            user_name: User display name for attribution (optional, inherits from parent or client default)
            user_id: User ID for attribution (optional, inherits from parent or client default)

        Returns:
            New Span instance
        """
        trace_id = get_current_trace_id()
        parent_id = None

        if auto_parent:
            # Check SDK's ContextVar for current span
            current_span = get_current_span()
            if current_span:
                trace_id = current_span.trace_id
                parent_id = current_span.span_id

                # Inherit session_id from parent if not explicitly provided
                if session_id is None:
                    session_id = current_span.session_id

                # Inherit user identity from parent if not explicitly provided
                if user_email is None:
                    user_email = current_span.user_email
                if user_name is None:
                    user_name = current_span.user_name
                if user_id is None:
                    user_id = current_span.user_id

        # Fall back to client defaults if no parent and no explicit value provided
        if session_id is None:
            session_id = self.config.session_id
        if user_email is None:
            user_email = self.config.user_email
        if user_name is None:
            user_name = self.config.user_name
        if user_id is None:
            user_id = self.config.user_id

        span = Span(
            name=name,
            trace_id=trace_id,
            parent_id=parent_id,
            kind=kind,
            span_type=span_type,
            session_id=session_id,
            user_email=user_email,
            user_name=user_name,
            user_id=user_id,
            record_stacktrace=self.config.record_stacktrace,
        )

        if self.config.environment:
            span.set_attribute("deployment.environment.name", self.config.environment)

        return span

    def trace(
        self,
        name: str,
        *,
        kind: SpanKind = SpanKind.INTERNAL,
        span_type: SpanType = SpanType.SPAN,
        session_id: str | None = None,
        user_email: str | None = None,
        user_name: str | None = None,
        user_id: str | None = None,
    ) -> TraceContext:
        """Create a span and return a context manager for it.

        Usage:
            with client.trace("operation_name"):
                # Your code here
                pass

        Args:
            name: Name of the span
            kind: Type of span (default: INTERNAL)
            span_type: Type of span (default: SPAN)
            session_id: Session ID (optional, stored in attributes)
            user_email: User email for attribution (optional)
            user_name: User display name for attribution (optional)
            user_id: User ID for attribution (optional)

        Returns:
            TraceContext that can be used as a context manager
        """
        span = self.create_span(
            name=name,
            kind=kind,
            span_type=span_type,
            session_id=session_id,
            user_email=user_email,
            user_name=user_name,
            user_id=user_id,
        )
        span.start()
        return TraceContext(span, client=self)

    def _apply_masking_to_span(self, span: Span) -> Span:
        """Apply the configured masking function to a span's attributes.

        Creates a deep copy of the span to preserve the original, then
        applies masking to the copy's attributes.

        Args:
            span: The span to mask

        Returns:
            A new span with masked attributes
        """
        masked_span = copy.deepcopy(span)
        masked_span.attributes = apply_masking(
            dict(span.attributes), self.config.masking_function
        )
        return masked_span

    @staticmethod
    def _submit_to_processor(provider: 'OtelTracerProvider', otel_span) -> bool:
        """Submit a ReadableSpan to the provider's span processor.

        Uses the private _active_span_processor attribute from the OTEL SDK.
        Centralised here so breakage from OTEL SDK updates is isolated to one place.
        """
        if hasattr(provider, '_active_span_processor'):
            provider._active_span_processor.on_end(otel_span)
            return True
        logger.warning(
            "TracerProvider has no _active_span_processor — "
            "this may indicate an incompatible OpenTelemetry SDK version. "
            "Spans will not be exported."
        )
        return False

    def export_span(self, span: Span) -> bool:
        """Export a span via database callback or OpenTelemetry exporter.

        This method either calls the database callback (if provided) or
        converts the Beacon span to an OpenTelemetry ReadableSpan and
        sends it through the configured TracerProvider's span processors.

        Args:
            span: The Beacon span to export

        Returns:
            True if export succeeded, False otherwise
        """
        # Apply masking if configured
        if self.config.masking_function is not None:
            span = self._apply_masking_to_span(span)

        # If database callback is provided, use it for direct export
        if self._database_callback:
            try:
                self._database_callback(span)
                logger.debug(
                    f"Exported span via database callback: name={span.name}, "
                    f"trace_id={span.trace_id}, span_id={span.span_id}"
                )
                return True
            except Exception as e:
                logger.error(f"Database callback failed for span {span.span_id}: {e}", exc_info=True)
                return False

        # Otherwise, use OpenTelemetry export
        try:
            from opentelemetry import trace
            from opentelemetry.sdk.trace import TracerProvider

            provider = self._otel_provider or trace.get_tracer_provider()
            if not isinstance(provider, TracerProvider):
                logger.warning("No OpenTelemetry TracerProvider configured, cannot export span")
                return False

            # Convert Beacon span to OTel ReadableSpan using client's resource
            otel_span = span.to_otel_span(resource=self._otel_resource)

            if self._submit_to_processor(provider, otel_span):
                logger.debug(
                    f"Queued span for export: name={span.name}, "
                    f"trace_id={span.trace_id}, span_id={span.span_id}"
                )
                return True
            return False
        except ImportError:
            logger.warning("OpenTelemetry SDK not installed, cannot export span")
            return False
        except Exception as e:
            logger.error(f"Failed to export span: {e}")
            return False

    def export_eager_span(self, span: Span) -> bool:
        """Export an eager (incomplete) span with end_time=0.

        Used by integrations (e.g. LangChain) to send span metadata
        before the operation completes. The backend's upsert logic
        will merge this with the complete span later.

        Args:
            span: The Beacon span to eagerly export

        Returns:
            True if export succeeded, False otherwise
        """
        if not self.config.eager_export:
            return False

        # Apply masking if configured
        if self.config.masking_function is not None:
            span = self._apply_masking_to_span(span)

        try:
            from opentelemetry import trace
            from opentelemetry.sdk.trace import TracerProvider

            provider = self._otel_provider or trace.get_tracer_provider()
            if not isinstance(provider, TracerProvider):
                logger.warning("No OpenTelemetry TracerProvider configured, cannot eager-export span")
                return False

            otel_span = span.to_otel_span_eager(resource=self._otel_resource)

            if self._submit_to_processor(provider, otel_span):
                logger.debug(
                    f"Eager-exported span: name={span.name}, "
                    f"trace_id={span.trace_id}, span_id={span.span_id}"
                )
                return True
            return False
        except ImportError:
            logger.warning("OpenTelemetry SDK not installed, cannot eager-export span")
            return False
        except Exception as e:
            logger.error(f"Failed to eager-export span: {e}")
            return False

    def export_spans(self, spans: list[Span]) -> int:
        """Export multiple spans via the configured OpenTelemetry exporter.

        Args:
            spans: List of Beacon spans to export

        Returns:
            Number of spans successfully exported
        """
        count = 0
        for span in spans:
            if self.export_span(span):
                count += 1
        return count

    def flush(self, timeout_millis: int = 30000) -> bool:
        """Flush all pending spans to the backend.

        This forces the OpenTelemetry BatchSpanProcessor to export any
        buffered spans immediately.

        Args:
            timeout_millis: Maximum time to wait for flush in milliseconds

        Returns:
            True if flush succeeded, False otherwise
        """
        logger.debug(f"Flushing spans (timeout={timeout_millis}ms)...")
        try:
            from opentelemetry import trace
            from opentelemetry.sdk.trace import TracerProvider

            global _export_failure_warned

            provider = self._otel_provider or trace.get_tracer_provider()
            if isinstance(provider, TracerProvider):
                result = provider.force_flush(timeout_millis)
                if result:
                    logger.debug("Flush completed successfully")
                else:
                    # Only warn once to avoid log spam on repeated failures
                    with _global_lock:
                        if not _export_failure_warned:
                            logger.warning(
                                f"OTLP export failed - spans are not being sent to {self.config.endpoint}. "
                                "This usually means the endpoint is unreachable (DNS failure, network issue, or wrong URL). "
                                "Check your BEACON_ENDPOINT configuration and network connectivity."
                            )
                            _export_failure_warned = True
                        else:
                            logger.debug("Flush returned False (export failure already reported)")
                return result
            logger.debug("No TracerProvider to flush")
            return True  # No provider to flush
        except ImportError:
            logger.debug("OpenTelemetry not installed, nothing to flush")
            return True  # OpenTelemetry not installed, nothing to flush
        except Exception as e:
            logger.error(f"Failed to flush spans: {e}", exc_info=True)
            return False

    def __enter__(self) -> 'BeaconClient':
        """Enter sync context manager.

        Returns:
            Self for use in with statement
        """
        return self

    def __exit__(self, _exc_type, _exc_val, _exc_tb) -> None:
        """Exit sync context manager, flushing pending spans."""
        self.flush()

    async def __aenter__(self) -> 'BeaconClient':
        """Enter async context manager.

        Returns:
            Self for use in async with statement
        """
        return self

    async def __aexit__(self, _exc_type, _exc_val, _exc_tb) -> None:
        """Exit async context manager, flushing pending spans."""
        self.flush()

    def get_base_url(self) -> str:
        """Get the base URL for API requests.

        Returns the base endpoint URL (e.g., "https://api.example.com").

        Returns:
            Base URL string

        Raises:
            ConfigurationError: If transport is not HTTPTransport
        """
        if not isinstance(self.transport, HTTPTransport):
            raise ConfigurationError(
                'Dataset operations require HTTPTransport. '
                'File transport is not supported for datasets.'
            )

        return self.transport.endpoint


def get_client() -> 'BeaconClient':
    """Get the current Beacon client or init a new one.

    Priority:
    1. Current async context (ContextVar) - for span context propagation
    2. Module-level singleton - persists across async contexts
    3. Create new client - only if neither exists

    Returns:
        BeaconClient instance
    """
    # First check async context
    client = _current_client.get()
    if client is not None:
        return client

    # Fall back to module-level singleton (persists across async contexts)
    with _global_lock:
        if _singleton_client is not None:
            return _singleton_client

    # Create new client (will set both _current_client and _singleton_client)
    return BeaconClient()
