"""Type definitions for evaluation operations."""

from dataclasses import dataclass
from enum import Enum
from typing import Any

from lumenova_beacon._pipeline import (
    DataMode,
    ExtractionEngine,
    ProcessorKind,
    ProcessorStep,
    VariableMapping,
)


__all__ = [
    "CodeParameter",
    "DataMode",
    "EvaluationRunStatus",
    "EvaluatorType",
    "ExtractionEngine",
    "ProbeMode",
    "ProcessorKind",
    "ProcessorStep",
    "ScoreType",
    "SourceType",
    "VariableMapping",
]


class EvaluationRunStatus(str, Enum):
    """Evaluation run status enum matching API values."""

    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    WARNING = "WARNING"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class ScoreType(str, Enum):
    """Score type enum for evaluators.

    Evaluators can produce scores in different formats:
    - PERCENT: A float between 0.0 and 1.0 (the UI displays this as a percentage)
    - NUMERIC: An arbitrary numeric value
    - CATEGORICAL: A discrete value from a predefined list (e.g., "pass", "fail")
    """

    PERCENT = "percent"
    NUMERIC = "numeric"
    CATEGORICAL = "categorical"


class EvaluatorType(str, Enum):
    """Evaluator type enum.

    Four types of evaluators are supported:
    - LLM_AS_JUDGE: Uses an LLM with a prompt template to evaluate
    - CODE: Uses custom Python code to evaluate
    - AGENT_AS_JUDGE: Uses an AI agent with tools to evaluate
    - SYSTEM_PROBE: Drives a probe runner against a target system; requires
      ``probe_mode`` ('exploratory' | 'systematic') on the evaluator
    """

    LLM_AS_JUDGE = "llm-as-judge"
    CODE = "code"
    AGENT_AS_JUDGE = "agent-as-judge"
    SYSTEM_PROBE = "system-probe"


class ProbeMode(str, Enum):
    """Probe mode for system-probe evaluators."""

    EXPLORATORY = "exploratory"
    SYSTEMATIC = "systematic"


class SourceType(str, Enum):
    """Source type for evaluations.

    Determines how input data is sourced for evaluation:
    - FULL_TRACE: Evaluates the entire trace
    - SPANS: Evaluates specific spans matching filter criteria
    - TARGET_SYSTEM: Drives a probe against an external target system
      (system-probe evaluations); requires ``target_system_id`` and
      ``probe_config`` on the Evaluation
    """

    FULL_TRACE = "full_trace"
    SPANS = "spans"
    TARGET_SYSTEM = "target_system"


@dataclass
class CodeParameter:
    """Parameter extracted from a code evaluator function signature.

    Attributes:
        name: Parameter name
        type_hint: Python type hint (e.g., 'str', 'int', 'dict')
        has_default: Whether the parameter has a default value
        default_value: Default value if has_default is True
    """

    name: str
    type_hint: str | None = None
    has_default: bool = False
    default_value: Any = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CodeParameter":
        """Create a CodeParameter from API response data."""
        return cls(
            name=data["name"],
            type_hint=data.get("type_hint"),
            has_default=data.get("has_default", False),
            default_value=data.get("default_value"),
        )
