"""Custom exceptions for the Beacon SDK."""

from __future__ import annotations

from typing import Literal


GovernancePhase = Literal['pre_tool', 'post_tool', 'pre_llm', 'post_llm']


class BeaconError(Exception):
    """Base exception for all Beacon SDK errors."""

    pass


class ConfigurationError(BeaconError):
    """Raised when configuration is invalid or incomplete."""

    pass


class TransportError(BeaconError):
    """Base exception for transport-related errors."""

    pass


class HTTPTransportError(TransportError):
    """Raised when HTTP transport encounters an error."""

    def __init__(self, message: str, status_code: int | None = None):
        """Initialize HTTP transport error.

        Args:
            message: Error message
            status_code: HTTP status code if available
        """
        super().__init__(message)
        self.status_code = status_code


class FileTransportError(TransportError):
    """Raised when file transport encounters an error."""

    pass


class SpanError(BeaconError):
    """Raised when span operations fail."""

    pass


class DatasetError(BeaconError):
    """Base exception for dataset-related errors."""

    pass


class DatasetNotFoundError(DatasetError):
    """Raised when a dataset or record is not found (404)."""

    pass


class DatasetValidationError(DatasetError):
    """Raised when dataset/record validation fails (422)."""

    pass


class PromptError(BeaconError):
    """Base exception for prompt-related errors."""

    pass


class PromptNotFoundError(PromptError):
    """Raised when a prompt is not found (404)."""

    pass


class PromptValidationError(PromptError):
    """Raised when prompt validation fails (422)."""

    pass


class PromptCompilationError(PromptError):
    """Raised when template rendering/compilation fails."""

    pass


class PromptNetworkError(PromptError):
    """Raised when network request fails after retries."""

    pass


class MaskingError(BeaconError):
    """Base exception for masking-related errors."""

    pass


class MaskingAPIError(MaskingError):
    """Raised when masking API call fails."""

    pass


class MaskingNotFoundError(MaskingError):
    """Raised when masking resource is not found (404)."""

    pass


class MaskingValidationError(MaskingError):
    """Raised when masking validation fails (422)."""

    pass


class ExperimentError(BeaconError):
    """Base exception for experiment-related errors."""

    pass


class ExperimentNotFoundError(ExperimentError):
    """Raised when an experiment is not found (404)."""

    pass


class ExperimentValidationError(ExperimentError):
    """Raised when experiment validation fails (422)."""

    pass


class EvaluationError(BeaconError):
    """Base exception for evaluation-related errors."""

    pass


class EvaluationNotFoundError(EvaluationError):
    """Raised when an evaluation or evaluation run is not found (404)."""

    pass


class EvaluationValidationError(EvaluationError):
    """Raised when evaluation validation fails (422)."""

    pass


class LLMConfigError(BeaconError):
    """Base exception for LLM configuration-related errors."""

    pass


class LLMConfigNotFoundError(LLMConfigError):
    """Raised when an LLM configuration is not found (404)."""

    pass


class GuardrailError(BeaconError):
    """Base exception for guardrail-related errors."""

    pass


class GuardrailNotFoundError(GuardrailError):
    """Raised when a guardrail is not found (404)."""

    pass


class GuardrailValidationError(GuardrailError):
    """Raised when guardrail validation fails (422)."""

    pass


class GovernanceError(BeaconError):
    """Base exception for governance-related errors."""

    pass


class GovernanceNotFoundError(GovernanceError):
    """Raised when a governance resource is not found (404)."""

    pass


class GovernanceValidationError(GovernanceError):
    """Raised when governance validation fails (422)."""

    pass


class GovernanceConfigurationError(GovernanceError):
    """Raised when governance is wired up in a way that cannot enforce.

    Distinct from :class:`GovernanceError` (transport/API failure) and
    :class:`GovernanceViolationError` (policy blocked the call). Fires
    when the SDK detects that ``handler.wrap()`` (or the LangGraph
    helpers) cannot install governance on the target — for example, a
    ``BaseTool`` subclass that overrides ``_run``/``_arun`` directly
    so there is no inner callable to rebind. Surfacing this as an
    error prevents the ambiguous "looks governed but isn't" state.
    """

    pass


class GovernanceReinjectionError(GovernanceError):
    """Raised when the SDK cannot apply a policy-supplied ``output``
    replacement to the current call.

    Distinct from :class:`GovernanceError` (transport/API failure) and
    :class:`GovernanceViolationError` (policy blocked the call). This
    error fires when the policy returned an allow decision *with* an
    ``output`` substitution but the SDK could not determine where to
    place it — for example, a tool with no string kwargs and no
    ``input`` key, an LLM message list with no human message, or a
    return-value type that does not support content swapping. Failing
    closed surfaces the misconfiguration instead of leaking unsanitized
    content downstream.
    """

    pass


class GovernanceViolationError(GovernanceError):
    """Raised when a governance policy blocks an action.

    This exception is raised inside LangChain callbacks to prevent
    execution of tools or LLM calls that violate governance policies.

    Attributes:
        result: The raw OPA/Rego result dict.
        policies: List of policies that were evaluated.
        latency_ms: Evaluation latency in milliseconds.
        phase: Governance lifecycle phase that produced the block
            (``'pre_tool'``, ``'post_tool'``, ``'pre_llm'``, ``'post_llm'``)
            or ``None`` when raised from a non-lifecycle context (e.g. a
            pre-existing stopped-state guard).
        tool_call_id: For tool-phase blocks, the ``tool_call_id`` of the
            blocked call.  ``None`` for LLM-phase blocks.
    """

    def __init__(
        self,
        message: str,
        result: dict | None = None,
        policies: list | None = None,
        latency_ms: float = 0.0,
        phase: GovernancePhase | None = None,
        tool_call_id: str | None = None,
    ):
        super().__init__(message)
        self.result = result or {}
        self.policies = policies or []
        self.latency_ms = latency_ms
        self.phase: GovernancePhase | None = phase
        self.tool_call_id = tool_call_id


class ProbeError(BeaconError):
    """Base exception for probe-related errors."""

    pass


class ProbeNotFoundError(ProbeError):
    """Raised when a probe evaluation run is not found (404)."""

    pass


class ProbeValidationError(ProbeError):
    """Raised when probe API input validation fails (422)."""

    pass


class ProbeAlreadyClaimedError(ProbeError):
    """Raised when a probe run is already claimed by a different runner (409)."""

    pass


class ProbeAuthMissingError(ProbeError):
    """Raised when ``Probe.run`` is invoked with the built-in dispatcher
    (no ``target_callable``) but the auth kwarg the target's
    ``auth_scheme_hint`` requires (``api_key=`` or ``bearer_token=``) is
    missing."""

    pass


class ProbeRunFailed(ProbeError):
    """Raised when a probe run transitions to FAILED while the runner is serving it."""

    pass
