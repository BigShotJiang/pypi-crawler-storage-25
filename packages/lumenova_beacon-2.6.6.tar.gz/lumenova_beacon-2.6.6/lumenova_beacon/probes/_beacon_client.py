"""Async httpx wrappers over Beacon's probe endpoints.

Each public function delegates to a ``_*_raw`` helper that owns the
HTTP call. The retry decorator is applied to the raw helper so tenacity
sees the underlying ``httpx`` exceptions (``ConnectError`` /
``ConnectTimeout`` / etc.) and can decide to retry them. The public
function then catches whatever escapes the retry loop and maps it to a
``Probe*`` exception. Wrapping at the public layer would mask the
exception type from tenacity and break the retry contract.

All functions accept an optional ``client: httpx.AsyncClient`` so the
runner can construct one client per ``Probe.arun`` invocation and amortise
the TLS handshake / connection-pool cost across many polls. When
``client=None`` (the default) an ephemeral client is created per call —
the path used by tests and one-off API callers.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import NoReturn

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from lumenova_beacon.exceptions import (
    ProbeAlreadyClaimedError,
    ProbeError,
    ProbeNotFoundError,
    ProbeValidationError,
)
from lumenova_beacon.probes.types import (
    ProbeClaimResponse,
    ProbeHttpRequest,
    ProbeHttpResponse,
    RunStatusSnapshot,
)
from lumenova_beacon.utils.client_helpers import get_base_url, get_transport
from lumenova_beacon.utils.http_errors import (
    HTTPErrorHandler,
    _safe_detail,
    truncate_body,
)

logger = logging.getLogger(__name__)

_error_handler = HTTPErrorHandler(
    not_found_exc=ProbeNotFoundError,
    validation_exc=ProbeValidationError,
    base_exc=ProbeError,
)

# Idempotent reads (claim is idempotent on same runner_id; list/refresh
# are GETs) can retry any transport-layer error. Exponential backoff
# (1-10s, 3 attempts) is the standard Beacon-SDK retry shape; if it
# changes here it should match the shape used by datasets/evaluations.
_retry_idempotent = retry(
    retry=retry_if_exception_type((httpx.NetworkError, httpx.TimeoutException)),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    stop=stop_after_attempt(3),
    reraise=True,
)

# Non-idempotent writes (PATCH /probe-requests/{id}) only retry on
# connect-phase errors where we know the request never reached the
# server. Read-phase errors (timeout reading the response, network
# error after sending the body) leave the server state ambiguous —
# retrying could double-apply the update. The runner loop's per-event
# attempt cap is the second line of defence.
_retry_idempotent_write = retry(
    retry=retry_if_exception_type((httpx.ConnectError, httpx.ConnectTimeout)),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    stop=stop_after_attempt(3),
    reraise=True,
)


@asynccontextmanager
async def _ensure_client(
    client: httpx.AsyncClient | None,
) -> AsyncIterator[httpx.AsyncClient]:
    """Yield ``client`` if provided, else open and close an ephemeral one."""
    if client is not None:
        yield client
        return
    async with shared_beacon_client() as ephemeral:
        yield ephemeral


@asynccontextmanager
async def shared_beacon_client() -> AsyncIterator[httpx.AsyncClient]:
    """Construct a shared httpx client for Beacon API calls within one run.

    The runner opens this once at the top of ``Probe.arun`` and threads
    the resulting client through every ``_beacon_client`` call so the
    TLS handshake and connection pool are reused across all polls. Uses
    ``get_transport`` so test-level patches on ``get_transport`` apply
    to the shared client as well.
    """
    transport = get_transport("Probe operations")
    async with httpx.AsyncClient(**transport.httpx_kwargs(async_client=True)) as client:
        yield client


def _handle_http_error(e: httpx.HTTPStatusError) -> NoReturn:
    """Map claim-specific 409 → ProbeAlreadyClaimedError, else delegate.

    Used by ``claim()`` only — the other endpoint wrappers go through
    ``_error_handler.handle`` directly because they don't issue 409.
    """
    if e.response.status_code == 409:
        detail = _safe_detail(e.response)
        raise ProbeAlreadyClaimedError(
            f"Run already claimed: {truncate_body(detail)}"
        ) from e
    _error_handler.handle(e)


@_retry_idempotent
async def _claim_raw(
    run_id: str,
    runner_id: str,
    *,
    client: httpx.AsyncClient | None,
) -> ProbeClaimResponse:
    base_url = get_base_url()
    transport = get_transport("Probe operations")
    url = f"{base_url}/api/v1/evaluation-runs/{run_id}/claim-probe"
    async with _ensure_client(client) as http:
        response = await http.post(
            url,
            json={"runner_id": runner_id},
            headers=transport.headers,
            timeout=transport.timeout,
        )
        response.raise_for_status()
        return ProbeClaimResponse.from_dict(response.json())


async def claim(
    run_id: str,
    runner_id: str,
    *,
    client: httpx.AsyncClient | None = None,
) -> ProbeClaimResponse:
    """Claim a probe evaluation run. Idempotent on same ``runner_id``; a
    claim by a different runner on a RUNNING run returns 409."""
    try:
        claim_response = await _claim_raw(run_id, runner_id, client=client)
    except httpx.HTTPStatusError as e:
        _handle_http_error(e)
    except httpx.HTTPError as e:
        raise ProbeError(f"Failed to claim probe run {run_id}: {e}") from e
    logger.debug(
        "Claimed probe run %s (runner_id=%s, target=%s)",
        claim_response.run_id,
        runner_id,
        claim_response.target_system.name,
    )
    return claim_response


@_retry_idempotent
async def _list_pending_requests_raw(
    runner_id: str,
    limit: int,
    *,
    client: httpx.AsyncClient | None,
) -> list[ProbeHttpRequest]:
    base_url = get_base_url()
    transport = get_transport("Probe operations")
    url = f"{base_url}/api/v1/probe-requests"
    async with _ensure_client(client) as http:
        response = await http.get(
            url,
            params={"runner_id": runner_id, "limit": limit},
            headers=transport.headers,
            timeout=transport.timeout,
        )
        response.raise_for_status()
        data = response.json()
        return [ProbeHttpRequest.from_dict(item) for item in data]


async def list_pending_requests(
    runner_id: str,
    limit: int = 10,
    *,
    client: httpx.AsyncClient | None = None,
) -> list[ProbeHttpRequest]:
    try:
        return await _list_pending_requests_raw(runner_id, limit, client=client)
    except httpx.HTTPStatusError as e:
        _error_handler.handle(e)
    except httpx.HTTPError as e:
        raise ProbeError(f"Failed to list pending probe requests: {e}") from e


@_retry_idempotent_write
async def _post_response_raw(
    event_id: str,
    response_body: ProbeHttpResponse,
    *,
    client: httpx.AsyncClient | None,
) -> None:
    base_url = get_base_url()
    transport = get_transport("Probe operations")
    url = f"{base_url}/api/v1/probe-requests/{event_id}"
    async with _ensure_client(client) as http:
        resp = await http.patch(
            url,
            json=response_body.to_dict(),
            headers=transport.headers,
            timeout=transport.timeout,
        )
        resp.raise_for_status()


async def post_response(
    event_id: str,
    response_body: ProbeHttpResponse,
    *,
    client: httpx.AsyncClient | None = None,
) -> None:
    try:
        await _post_response_raw(event_id, response_body, client=client)
    except httpx.HTTPStatusError as e:
        _error_handler.handle(e)
    except httpx.HTTPError as e:
        raise ProbeError(
            f"Failed to post probe response for event {event_id}: {e}"
        ) from e
    logger.debug(
        "Posted probe response for event %s (kind=%s, duration=%d ms)",
        event_id,
        response_body.kind.value,
        response_body.duration_ms,
    )


@_retry_idempotent
async def _refresh_run_raw(
    run_id: str,
    *,
    client: httpx.AsyncClient | None,
) -> RunStatusSnapshot:
    base_url = get_base_url()
    transport = get_transport("Probe operations")
    url = f"{base_url}/api/v1/evaluation-runs/{run_id}"
    async with _ensure_client(client) as http:
        response = await http.get(
            url,
            headers=transport.headers,
            timeout=transport.timeout,
        )
        response.raise_for_status()
        return RunStatusSnapshot.from_dict(response.json())


async def refresh_run(
    run_id: str,
    *,
    client: httpx.AsyncClient | None = None,
) -> RunStatusSnapshot:
    try:
        return await _refresh_run_raw(run_id, client=client)
    except httpx.HTTPStatusError as e:
        _error_handler.handle(e)
    except httpx.HTTPError as e:
        raise ProbeError(f"Failed to refresh run {run_id}: {e}") from e
