"""Wire types for probe execution."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, ClassVar, Literal, get_args

from lumenova_beacon.exceptions import ProbeValidationError


class AuthSchemeHint(str, Enum):
    """Auth scheme the probe target advertises.

    The built-in dispatcher (path A) inspects this to decide which
    headers to inject from the user's kwargs:

    - ``CUSTOM_HEADERS`` — the user passes a ``headers={"X-API-Key":
      "...", ...}`` mapping. The dispatcher injects every key/value
      pair on each request. The set of expected names is published in
      ``target.auth_metadata.headers``.
    - ``BEARER`` — the user passes ``bearer_token="..."`` and the
      dispatcher injects ``Authorization: Bearer <token>``.
    - ``NONE`` — no header injection.
    """

    NONE = "none"
    CUSTOM_HEADERS = "custom_headers"
    BEARER = "bearer"

    @classmethod
    def from_wire(cls, value: Any) -> AuthSchemeHint:
        if value is None:
            return cls.NONE
        if not isinstance(value, str):
            raise ProbeValidationError(
                f"Expected auth_scheme_hint as str, got {type(value).__name__}"
            )
        try:
            return cls(value)
        except ValueError as e:
            raise ProbeValidationError(
                f"Unknown auth_scheme_hint {value!r}; expected one of "
                f"{sorted(s.value for s in cls)}"
            ) from e


class ProbeResponseKind(str, Enum):
    RESPONSE = "response"
    ERROR = "error"


class ProbeRunStatus(str, Enum):
    """Lifecycle state of a probe evaluation run on the Beacon side."""

    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

    @classmethod
    def from_wire(cls, value: Any) -> ProbeRunStatus:
        if not isinstance(value, str):
            raise ProbeValidationError(
                f"Expected run status as str, got {type(value).__name__}"
            )
        try:
            return cls(value.upper())
        except ValueError as e:
            raise ProbeValidationError(
                f"Unknown probe run status {value!r}; expected one of "
                f"{sorted(s.value for s in cls)}"
            ) from e

    @property
    def is_terminal(self) -> bool:
        return self in {
            ProbeRunStatus.COMPLETED,
            ProbeRunStatus.FAILED,
            ProbeRunStatus.CANCELLED,
        }


HttpMethod = Literal[
    "GET",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "HEAD",
    "OPTIONS",
]
_HTTP_METHODS: frozenset[str] = frozenset(get_args(HttpMethod))


def _require_field(data: dict[str, Any], field_name: str, owner: str) -> Any:
    try:
        return data[field_name]
    except KeyError as e:
        raise ProbeValidationError(
            f"{owner} payload missing required field {field_name!r}; "
            f"SDK/Beacon version mismatch?"
        ) from e


def _require_non_empty(value: Any, field_name: str, owner: str) -> str:
    if not isinstance(value, str) or not value:
        raise ProbeValidationError(
            f"{owner}.{field_name} must be a non-empty string, got {value!r}"
        )
    return value


@dataclass(frozen=True)
class TargetSystemRef:
    """Diagnostic reference to the target the SDK is probing.

    In SDK callable mode the URL/auth fields are informational only — the
    user's ``target_callable`` owns the connection. ``base_url`` is
    therefore optional.
    """

    id: str
    name: str
    base_url: str | None = None
    auth_scheme_hint: AuthSchemeHint = AuthSchemeHint.NONE
    auth_metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _require_non_empty(self.id, "id", "TargetSystemRef")
        _require_non_empty(self.name, "name", "TargetSystemRef")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetSystemRef:
        return cls(
            id=_require_field(data, "id", "TargetSystemRef"),
            name=_require_field(data, "name", "TargetSystemRef"),
            base_url=data.get("base_url"),
            auth_scheme_hint=AuthSchemeHint.from_wire(data.get("auth_scheme_hint")),
            auth_metadata=data.get("auth_metadata") or {},
        )


@dataclass(frozen=True)
class ProbeHttpRequest:
    """One HTTP call the agent wants the runner to make against the target.

    Constructed from Beacon's ``/api/v1/probe-requests`` payload via
    :meth:`from_dict`. ``method`` is normalised to upper-case there;
    callers building this directly should use upper-case method names.
    """

    id: str
    evaluation_run_id: str
    seq: int
    method: HttpMethod
    url: str
    request_headers: dict[str, str] = field(default_factory=dict)
    request_body: str | None = None
    lens: str | None = None
    tool_name: str | None = None

    def __post_init__(self) -> None:
        if self.seq < 0:
            raise ProbeValidationError(
                f"ProbeHttpRequest.seq must be >= 0, got {self.seq}"
            )
        if self.method not in _HTTP_METHODS:
            raise ProbeValidationError(
                f"ProbeHttpRequest.method must be one of "
                f"{sorted(_HTTP_METHODS)}, got {self.method!r}"
            )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProbeHttpRequest:
        return cls(
            id=_require_field(data, "id", "ProbeHttpRequest"),
            evaluation_run_id=_require_field(
                data,
                "evaluation_run_id",
                "ProbeHttpRequest",
            ),
            seq=_require_field(data, "seq", "ProbeHttpRequest"),
            method=str(_require_field(data, "method", "ProbeHttpRequest")).upper(),
            url=_require_field(data, "url", "ProbeHttpRequest"),
            request_headers=dict(data.get("request_headers") or {}),
            request_body=data.get("request_body"),
            lens=data.get("lens"),
            tool_name=data.get("tool_name"),
        )


@dataclass(frozen=True)
class ProbeHttpSuccessResponse:
    """Target replied — possibly with a non-2xx status. The agent judges."""

    duration_ms: int
    status_code: int
    response_headers: dict[str, str] = field(default_factory=dict)
    response_body: str | None = None
    kind: ClassVar[Literal[ProbeResponseKind.RESPONSE]] = ProbeResponseKind.RESPONSE

    def __post_init__(self) -> None:
        if self.duration_ms < 0:
            raise ProbeValidationError(
                f"ProbeHttpSuccessResponse.duration_ms must be >= 0, "
                f"got {self.duration_ms}"
            )
        if not 100 <= self.status_code < 600:
            raise ProbeValidationError(
                f"ProbeHttpSuccessResponse.status_code must be 100..599, "
                f"got {self.status_code}"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": ProbeResponseKind.RESPONSE.value,
            "status_code": self.status_code,
            "response_headers": self.response_headers,
            "response_body": self.response_body,
            "duration_ms": self.duration_ms,
        }


@dataclass(frozen=True)
class ProbeHttpErrorResponse:
    """Target never replied — DNS/TLS/timeout/connect refused/etc."""

    duration_ms: int
    error: str
    kind: ClassVar[Literal[ProbeResponseKind.ERROR]] = ProbeResponseKind.ERROR

    def __post_init__(self) -> None:
        if self.duration_ms < 0:
            raise ProbeValidationError(
                f"ProbeHttpErrorResponse.duration_ms must be >= 0, "
                f"got {self.duration_ms}"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": ProbeResponseKind.ERROR.value,
            "error": self.error,
            "duration_ms": self.duration_ms,
        }


ProbeHttpResponse = ProbeHttpSuccessResponse | ProbeHttpErrorResponse


@dataclass(frozen=True)
class ProbeClaimResponse:
    run_id: str
    runner_id: str
    evaluation_id: str
    target_system: TargetSystemRef

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProbeClaimResponse:
        return cls(
            run_id=_require_field(data, "run_id", "ProbeClaimResponse"),
            runner_id=_require_field(data, "runner_id", "ProbeClaimResponse"),
            evaluation_id=_require_field(data, "evaluation_id", "ProbeClaimResponse"),
            target_system=TargetSystemRef.from_dict(
                _require_field(data, "target_system", "ProbeClaimResponse"),
            ),
        )


@dataclass(frozen=True)
class RunStatusSnapshot:
    """Lifecycle snapshot polled by the runner loop."""

    id: str
    status: ProbeRunStatus
    error_message: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RunStatusSnapshot:
        return cls(
            id=_require_field(data, "id", "RunStatusSnapshot"),
            status=ProbeRunStatus.from_wire(
                _require_field(data, "status", "RunStatusSnapshot"),
            ),
            error_message=data.get("error_message"),
        )

    @property
    def is_terminal(self) -> bool:
        return self.status.is_terminal
