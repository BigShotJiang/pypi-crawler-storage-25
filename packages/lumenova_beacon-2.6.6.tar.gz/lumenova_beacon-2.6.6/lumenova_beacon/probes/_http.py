"""Built-in HTTP dispatcher for path A — `Probe.run` without a callable.

The user supplies auth as an explicit kwarg on ``Probe.run`` (``headers=``
for ``custom_headers`` schemes, ``bearer_token=`` for ``bearer``); the
dispatcher injects the right headers per the target's
``auth_scheme_hint`` and fires httpx against the agent-supplied URL.

No environment variables, TOML files, or other ambient credential
stores are consulted — auth is path A's kwarg or path B's callable, and
nothing else.
"""

from __future__ import annotations

import logging
import time
import urllib.parse
from collections.abc import Mapping
from dataclasses import dataclass, field

import httpx

from lumenova_beacon.exceptions import ProbeError, ProbeValidationError
from lumenova_beacon.probes.types import (
    AuthSchemeHint,
    ProbeHttpErrorResponse,
    ProbeHttpRequest,
    ProbeHttpResponse,
    ProbeHttpSuccessResponse,
    TargetSystemRef,
)

logger = logging.getLogger(__name__)

# Cap response bodies sent back to Beacon. The dispatcher streams the
# target's reply and stops reading once this many bytes are buffered, so
# pathological multi-GB responses can't OOM the SDK before truncation.
# The truncation marker is counted against the budget so the wire
# payload never exceeds MAX_BODY_BYTES.
MAX_BODY_BYTES = 65536
_TRUNCATION_MARKER = "... [truncated]"

# Headers whose values get scrubbed before posting back. Sensitive
# headers should never reach Beacon's storage. Comparison is
# case-insensitive. Only response headers are forwarded to Beacon (the
# request headers the dispatcher sent are not echoed back).
_DEFAULT_SENSITIVE_HEADERS = frozenset(
    {
        "authorization",
        "proxy-authorization",
        "cookie",
        "set-cookie",
        "x-api-key",
        "x-auth-token",
    },
)
_REDACTED_VALUE = "[REDACTED]"


@dataclass(frozen=True)
class BuiltInAuth:
    """Path-A auth resolved from kwargs at ``Probe.run`` entry.

    Carries the user's secrets for at most one auth scheme:

    - ``headers`` is a ``{name: value}`` map for ``custom_headers``
      targets. Every entry is injected on each request.
    - ``bearer_token`` populates ``Authorization: Bearer <token>`` for
      ``bearer`` targets.

    Both-set is a programmer error and rejected at construction; all-empty
    is fine and produces no header injection (used when
    ``auth_scheme_hint`` is ``none``).
    """

    headers: Mapping[str, str] = field(default_factory=dict)
    bearer_token: str | None = None

    def __post_init__(self) -> None:
        if self.headers and self.bearer_token is not None:
            raise ProbeValidationError(
                "BuiltInAuth: pass headers= OR bearer_token=, not both."
            )


async def dispatch_builtin(
    request: ProbeHttpRequest,
    *,
    target: TargetSystemRef,
    auth: BuiltInAuth,
    client: httpx.AsyncClient,
    base_url: str | None = None,
) -> ProbeHttpResponse:
    """Fire ``request`` against the target with auth injection.

    When ``base_url`` is set, the agent-supplied URL's scheme + host +
    port are replaced with those of ``base_url`` (any path prefix on
    ``base_url`` is preserved and prepended to the request path). This
    is the runtime override for SDK mode where the agent often guesses
    URLs from docs rather than reading a stored ``target.base_url``.

    Returns ``ProbeHttpSuccessResponse`` for any HTTP reply (including
    4xx/5xx — those are valid responses, not errors) or
    ``ProbeHttpErrorResponse`` for transport-layer failures (DNS, TLS,
    timeout, connect refused). SDK / config errors (invalid URL,
    unsupported protocol, locally-malformed HTTP) raise ``ProbeError``
    so the user fixes their setup rather than seeing fake "target
    unreachable" results.

    The ``client`` kwarg is required — the runner constructs one
    ``httpx.AsyncClient`` with appropriate timeouts and reuses it for
    every dispatch in the run, so connection pooling and TLS handshakes
    are amortised across the full poll cycle.
    """
    url = rewrite_url(request.url, base_url) if base_url else request.url
    headers = _build_headers(request.request_headers, target, auth)
    started = time.monotonic()
    try:
        async with client.stream(
            request.method,
            url,
            headers=headers,
            content=request.request_body,
        ) as response:
            status_code = response.status_code
            response_headers = _redact_headers(dict(response.headers))
            body = await _read_capped_body(response)
    except (
        httpx.InvalidURL,
        httpx.UnsupportedProtocol,
        httpx.LocalProtocolError,
    ) as exc:
        raise ProbeError(
            f"Probe dispatch SDK error ({type(exc).__name__}): {exc}",
        ) from exc
    except httpx.RequestError as exc:
        duration_ms = int((time.monotonic() - started) * 1000)
        logger.warning(
            "Probe dispatch failed: %s %s -> %s: %s",
            request.method,
            url,
            type(exc).__name__,
            exc,
        )
        return ProbeHttpErrorResponse(
            duration_ms=duration_ms,
            error=f"{type(exc).__name__}: {exc}",
        )

    duration_ms = int((time.monotonic() - started) * 1000)
    return ProbeHttpSuccessResponse(
        duration_ms=duration_ms,
        status_code=status_code,
        response_headers=response_headers,
        response_body=body,
    )


def rewrite_url(request_url: str, base_url: str) -> str:
    """Replace scheme + host + port of ``request_url`` with those of ``base_url``.

    Public helper for the path-B custom callable: when the agent's URL
    points at the wrong host (common in SDK mode where Beacon doesn't
    know the real URL), call ``rewrite_url(request.url, MY_BASE)`` to
    keep the agent's path/query/fragment but route the call at your
    real base. Path/query/fragment from the request are preserved; if
    ``base_url`` carries a path prefix (e.g. ``https://api.example.com/v2``) it
    is concatenated before the request's path.
    """
    base = urllib.parse.urlsplit(base_url)
    req = urllib.parse.urlsplit(request_url)
    base_path = base.path.rstrip("/")
    req_path = req.path or ""
    if req_path and not req_path.startswith("/"):
        req_path = "/" + req_path
    return urllib.parse.urlunsplit(
        (base.scheme, base.netloc, base_path + req_path, req.query, req.fragment),
    )


def _build_headers(
    request_headers: Mapping[str, str],
    target: TargetSystemRef,
    auth: BuiltInAuth,
) -> dict[str, str]:
    """Merge agent-supplied headers with SDK-injected auth.

    SDK auth always wins on case-insensitive collisions — the agent
    cannot accidentally clobber values the user passed via kwarg.
    """
    out: dict[str, str] = dict(request_headers)
    for name, value in _resolve_auth_headers(target, auth):
        for key in list(out.keys()):
            if key.lower() == name.lower():
                del out[key]
        out[name] = value
    return out


def _resolve_auth_headers(
    target: TargetSystemRef,
    auth: BuiltInAuth,
) -> list[tuple[str, str]]:
    scheme = target.auth_scheme_hint
    if scheme is AuthSchemeHint.CUSTOM_HEADERS:
        return list(auth.headers.items())
    if scheme is AuthSchemeHint.BEARER:
        if auth.bearer_token is None:
            return []
        return [("Authorization", f"Bearer {auth.bearer_token}")]
    if scheme is AuthSchemeHint.NONE:
        return []
    raise ProbeValidationError(
        f"Unhandled auth_scheme_hint={scheme!r}; SDK out of date?"
    )


def _redact_headers(headers: dict[str, str]) -> dict[str, str]:
    return {
        name: (_REDACTED_VALUE if name.lower() in _DEFAULT_SENSITIVE_HEADERS else value)
        for name, value in headers.items()
    }


async def _read_capped_body(response: httpx.Response) -> str:
    """Stream-read up to ``MAX_BODY_BYTES`` + 1 bytes, then decode.

    Reading +1 byte past the cap lets us detect overflow without buffering
    the whole reply. Pathological 10 GB target responses stop at
    ``MAX_BODY_BYTES + chunk_size`` instead of OOM-ing the SDK.
    """
    cap = MAX_BODY_BYTES
    buf = bytearray()
    async for chunk in response.aiter_bytes():
        remaining = cap + 1 - len(buf)
        if remaining <= 0:
            break
        if len(chunk) > remaining:
            buf.extend(chunk[:remaining])
            break
        buf.extend(chunk)
        if len(buf) > cap:
            break
    return _decode_capped(bytes(buf))


def _decode_capped(buf: bytes) -> str:
    """Decode bytes as UTF-8; truncate if over cap; placeholder if binary."""
    try:
        text = buf.decode("utf-8")
    except UnicodeDecodeError:
        size = len(buf)
        logger.debug(
            "Probe response body is binary, %d bytes; reporting placeholder",
            size,
        )
        return f"<binary body, {size} bytes>"
    if len(buf) <= MAX_BODY_BYTES:
        return text
    keep = MAX_BODY_BYTES - len(_TRUNCATION_MARKER.encode("utf-8"))
    return buf[:keep].decode("utf-8", errors="ignore") + _TRUNCATION_MARKER
