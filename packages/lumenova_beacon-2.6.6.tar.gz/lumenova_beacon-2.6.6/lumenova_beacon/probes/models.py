"""``Probe`` — the runner-loop entry point.

Two equally valid paths:

- **Built-in HTTP dispatcher** (path A) — pass ``headers=`` (a mapping
  of header-name → value for ``custom_headers`` targets) or
  ``bearer_token=`` directly to :meth:`Probe.run`. The SDK fires httpx
  itself and injects the right headers per the target's
  ``auth_scheme_hint``. Easiest path for plain HTTP targets.

- **Custom callable** (path B) — pass ``target_callable=fn``. The user's
  function receives a :class:`ProbeHttpRequest` and returns a
  :class:`ProbeHttpSuccessResponse` or :class:`ProbeHttpErrorResponse`.
  Use this when you need non-HTTP transports, custom auth flows, or
  mocks.

The two paths are mutually exclusive — passing both ``target_callable``
and an auth kwarg is a programmer error and raises immediately.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import os
import socket
import time
from collections.abc import Awaitable, Callable, Mapping
from enum import Enum
from typing import Any

import httpx

from lumenova_beacon.exceptions import (
    ProbeAuthMissingError,
    ProbeError,
    ProbeNotFoundError,
    ProbeRunFailed,
    ProbeValidationError,
)
from lumenova_beacon.probes import _beacon_client
from lumenova_beacon.probes._http import BuiltInAuth, dispatch_builtin
from lumenova_beacon.probes.types import (
    AuthSchemeHint,
    ProbeClaimResponse,
    ProbeHttpErrorResponse,
    ProbeHttpRequest,
    ProbeHttpResponse,
    ProbeHttpSuccessResponse,
    ProbeResponseKind,
    ProbeRunStatus,
    RunStatusSnapshot,
    TargetSystemRef,
)
from lumenova_beacon.utils.async_utils import run_sync

logger = logging.getLogger(__name__)

# Floor for the inter-poll sleep. Below this, the polling loop becomes
# a tight CPU spin (especially when poll_interval=0 in tests). 50 ms is
# well below interactive perception but still gives the event loop room
# to schedule sibling tasks.
MIN_POLL_INTERVAL_SECONDS = 0.05
DEFAULT_REQUEST_TIMEOUT_SECONDS = 30.0
# Wall-clock cap when the user doesn't supply one. Picked as a sane
# default that's longer than typical agent runs but short enough to
# guarantee the runner doesn't hang forever if Beacon stops responding
# (the agent has its own server-side timeout, but it can't always reach
# the SDK to signal termination — so the SDK enforces its own ceiling).
DEFAULT_MAX_RUNTIME_SECONDS = 3600.0
# Cap per-event dispatch attempts. Without this, a permanent PATCH-back
# failure would re-dispatch the same event against the user's target on
# every poll cycle — non-idempotent targets (POST /charge, /transfer)
# would be hit repeatedly. Three attempts gives transient blips a
# chance while bounding the blast radius of a real failure.
#
# Combined with the per-event response cache in _run_loop, the user's
# target is hit at most once per event even when PATCH-back retries —
# subsequent attempts replay the cached response.
MAX_DISPATCH_ATTEMPTS = 3

TargetReturn = ProbeHttpResponse | httpx.Response | str
"""Acceptable return types for ``target_callable``.

The SDK normalises each variant into a ``ProbeHttpResponse``:

- ``ProbeHttpSuccessResponse`` / ``ProbeHttpErrorResponse`` — returned as-is.
- ``httpx.Response`` or ``requests.Response`` — auto-converted to
  ``ProbeHttpSuccessResponse`` using the response's ``elapsed`` for
  ``duration_ms``. Any HTTP status (including 4xx/5xx) maps to a
  "response" kind — those are valid replies, not errors. Use this
  when your callable already does an httpx/requests call and you
  just want to return the result. ``requests`` support is a soft
  import — no hard dependency, so its type isn't statically listed
  in the alias above (the runtime check covers it).
- ``str`` — wrapped as ``ProbeHttpSuccessResponse(status_code=200,
  response_body=<str>)`` with wall-clock duration. Useful for non-HTTP
  targets (LLMs, in-process functions, mocks) where you just want to
  hand a string back to the agent.

A return of any other type is a contract violation and raises
``ProbeValidationError`` so the run halts loudly rather than reporting
fake "target error" results.
"""

TargetCallable = Callable[
    [ProbeHttpRequest],
    TargetReturn | Awaitable[TargetReturn],
]


class _DispatchOutcome(Enum):
    """Discriminated result of one ``_dispatch_one`` call.

    The runner loop uses this to (1) accurately count successfully-served
    requests for the terminal log, and (2) decide whether to back off
    before re-polling. Returning ``None`` from every code path made the
    loop spin against Beacon when every event was a no-op.
    """

    DISPATCHED = "dispatched"  # target hit (or replayed from cache) + PATCH succeeded
    SKIPPED = "skipped"  # over attempt cap or already terminal server-side
    PATCH_FAILED = "patch_failed"  # transient PATCH failure, will retry next poll


def make_runner_id(run_id: str) -> str:
    """Per-process identifier: ``<hostname>:<pid>:<run_id>``.

    PID disambiguates two SDK processes on the same host that happen to
    share a ``run_id`` — without it, both would pass Beacon's
    idempotent-on-runner_id claim and then race on PATCH-back.
    """
    return f"{socket.gethostname()}:{os.getpid()}:{run_id}"


class Probe:
    """One-shot SDK-mode probe runner.

    ``Probe.run`` (sync) / ``Probe.arun`` (async) claim a specific
    evaluation run, dispatch every pending HTTP request to either the
    built-in httpx dispatcher (path A) or the user-supplied
    ``target_callable`` (path B), and PATCH the response back. Returns
    the terminal :class:`RunStatusSnapshot`.

    Path A — let the SDK fire HTTP itself::

        from lumenova_beacon import Probe
        Probe.run(
            "<run_id>",
            headers={"X-API-Key": "<your-api-key>"},
        )

    Path B — own the connection yourself::

        from lumenova_beacon import Probe, ProbeHttpSuccessResponse
        import httpx

        def my_target(request):
            # Your callable owns auth — set it however your transport demands.
            response = httpx.request(
                request.method, request.url,
                headers=request.request_headers,
                content=request.request_body, timeout=30.0,
            )
            return ProbeHttpSuccessResponse(
                duration_ms=int(response.elapsed.total_seconds() * 1000),
                status_code=response.status_code,
                response_headers=dict(response.headers),
                response_body=response.text,
            )

        Probe.run("<run_id>", target_callable=my_target)
    """

    @classmethod
    async def arun(
        cls,
        run_id: str,
        *,
        target_callable: TargetCallable | None = None,
        headers: Mapping[str, str] | None = None,
        bearer_token: str | None = None,
        base_url: str | None = None,
        poll_interval: float = 1.0,
        max_runtime_seconds: float | None = DEFAULT_MAX_RUNTIME_SECONDS,
        request_timeout: float = DEFAULT_REQUEST_TIMEOUT_SECONDS,
    ) -> RunStatusSnapshot:
        _validate_path_choice(target_callable, headers, bearer_token, base_url)

        poll_interval = max(MIN_POLL_INTERVAL_SECONDS, poll_interval)
        runner_id = make_runner_id(run_id)
        logger.info(
            "Claiming probe run %s as runner %s",
            run_id,
            runner_id,
        )

        async with _beacon_client.shared_beacon_client() as beacon_http:
            claim = await _beacon_client.claim(
                run_id,
                runner_id,
                client=beacon_http,
            )
            logger.info(
                "Claimed run %s (target=%s)",
                claim.run_id,
                claim.target_system.name,
            )

            dispatcher: _Dispatcher
            if target_callable is None:
                _validate_builtin_auth(claim.target_system, headers, bearer_token)
                async with _build_target_client(request_timeout) as target_http:
                    dispatcher = _BuiltInDispatcher(
                        target=claim.target_system,
                        auth=BuiltInAuth(
                            headers=dict(headers or {}),
                            bearer_token=bearer_token,
                        ),
                        base_url=base_url,
                        client=target_http,
                    )
                    return await _run_loop(
                        claim,
                        runner_id,
                        dispatcher,
                        poll_interval=poll_interval,
                        max_runtime_seconds=max_runtime_seconds,
                        beacon_http=beacon_http,
                    )
            else:
                dispatcher = _CallableDispatcher(target_callable)
                return await _run_loop(
                    claim,
                    runner_id,
                    dispatcher,
                    poll_interval=poll_interval,
                    max_runtime_seconds=max_runtime_seconds,
                    beacon_http=beacon_http,
                )

    @classmethod
    def run(
        cls,
        run_id: str,
        *,
        target_callable: TargetCallable | None = None,
        headers: Mapping[str, str] | None = None,
        bearer_token: str | None = None,
        base_url: str | None = None,
        poll_interval: float = 1.0,
        max_runtime_seconds: float | None = DEFAULT_MAX_RUNTIME_SECONDS,
        request_timeout: float = DEFAULT_REQUEST_TIMEOUT_SECONDS,
        verbose: bool = False,
    ) -> RunStatusSnapshot:
        """Sync wrapper over :meth:`arun`.

        Args:
            run_id: Probe evaluation run ID to claim (shown in the UI).
            target_callable: *(Path B)* Function (sync or async) that
                takes a :class:`ProbeHttpRequest` and returns a
                :class:`ProbeHttpSuccessResponse` or
                :class:`ProbeHttpErrorResponse`. When provided, the user's
                callable owns the connection and is responsible for any
                auth handling. Mutually exclusive with ``headers`` /
                ``bearer_token``.
            headers: *(Path A)* Required when the target's
                ``auth_scheme_hint`` is ``custom_headers`` and no
                ``target_callable`` is supplied. Mapping of
                ``{header_name: value}`` — the SDK injects every entry
                on each outbound request. Must cover every header name
                listed in ``target.auth_metadata.headers``.
            bearer_token: *(Path A)* Required when the target's
                ``auth_scheme_hint`` is ``bearer`` and no
                ``target_callable`` is supplied. The SDK injects this as
                ``Authorization: Bearer <bearer_token>``.
            base_url: *(Path A, optional)* When set, every dispatched
                request's scheme + host + port are replaced with those
                of ``base_url`` (path/query are preserved; a path prefix
                on ``base_url`` is concatenated). Use this when the
                agent doesn't know the real URL of your system on the
                machine running the SDK — common in SDK mode where
                Beacon doesn't store the target URL.
            poll_interval: Seconds between polls when no events are pending
                (minimum 0.05s).
            max_runtime_seconds: Wall-clock cap on the whole run. Defaults
                to 1 hour. Pass ``None`` to disable (relies on the
                server-side agent timeout).
            request_timeout: Per-HTTP-call read timeout for the built-in
                dispatcher (path A). Ignored when ``target_callable`` is
                supplied — the callable owns its own timeouts.
            verbose: When ``True``, switches the auto-configured logger
                to ``DEBUG`` level. Has no effect when the host script
                already configured its own logging.

        Returns:
            Terminal :class:`RunStatusSnapshot` with status ``COMPLETED`` or
            ``CANCELLED``.

        Raises:
            ProbeError: Conflicting kwargs (``target_callable`` + auth
                kwarg), Beacon API failure, wall-clock timeout, or other
                unrecoverable condition.
            ProbeAuthMissingError: Path A was selected but the auth kwarg
                the target's ``auth_scheme_hint`` requires is missing.
            ProbeRunFailed: The run transitioned to ``FAILED``.
        """
        _maybe_configure_basic_logging(verbose=verbose)
        return run_sync(
            cls.arun(
                run_id,
                target_callable=target_callable,
                headers=headers,
                bearer_token=bearer_token,
                base_url=base_url,
                poll_interval=poll_interval,
                max_runtime_seconds=max_runtime_seconds,
                request_timeout=request_timeout,
            )
        )


def _build_target_client(request_timeout: float) -> httpx.AsyncClient:
    """Construct a shared httpx client for path-A target dispatch.

    Separates connect-phase from read-phase timeouts: a slow target
    that's reachable but trickling bytes shouldn't be confused with one
    that's unreachable. ``verify=True`` is the httpx default; a future
    kwarg could expose user-controlled TLS settings if needed.
    """
    timeout = httpx.Timeout(
        connect=min(5.0, request_timeout),
        read=request_timeout,
        write=request_timeout,
        pool=request_timeout,
    )
    return httpx.AsyncClient(timeout=timeout)


async def _run_loop(
    claim: ProbeClaimResponse,
    runner_id: str,
    dispatcher: _Dispatcher,
    *,
    poll_interval: float,
    max_runtime_seconds: float | None,
    beacon_http: httpx.AsyncClient,
) -> RunStatusSnapshot:
    """Drive the claim → dispatch → PATCH loop until terminal."""
    deadline = (
        time.monotonic() + max_runtime_seconds
        if max_runtime_seconds is not None
        else None
    )
    request_count = 0
    # Per-event attempt counter. Once an event hits MAX_DISPATCH_ATTEMPTS
    # it's skipped permanently — Beacon will surface the orphan via the
    # server-side agent timeout.
    attempts: dict[str, int] = {}
    # Per-event response cache. Populated when the target call succeeded
    # but PATCH-back failed; on the next attempt the cached response is
    # replayed instead of re-firing the user's target. Critical for
    # non-idempotent targets (POST /charge): without it, a flaky Beacon
    # connection could cause the same target call to fire up to
    # MAX_DISPATCH_ATTEMPTS times.
    response_cache: dict[str, ProbeHttpResponse] = {}
    while True:
        if deadline is not None and time.monotonic() > deadline:
            raise ProbeError(
                f"Run {claim.run_id} did not terminate within {max_runtime_seconds}s",
            )

        pending = await _beacon_client.list_pending_requests(
            runner_id,
            client=beacon_http,
        )
        if pending:
            results = await asyncio.gather(
                *[
                    _dispatch_one(
                        req,
                        dispatcher,
                        attempts,
                        response_cache,
                        beacon_http,
                    )
                    for req in pending
                ],
                return_exceptions=True,
            )
            for r in results:
                # Schema-drift / programmer-error: surface to caller.
                if isinstance(r, ProbeValidationError):
                    raise r
                # KeyboardInterrupt / SystemExit / asyncio.CancelledError —
                # re-raise so Ctrl-C and process shutdown propagate cleanly
                # rather than being swallowed by gather's capture.
                if isinstance(r, BaseException) and not isinstance(r, Exception):
                    raise r
                if isinstance(r, Exception):
                    # _dispatch_one is supposed to convert per-event errors
                    # into PATCH_FAILED; an exception escaping it is a bug.
                    # Log loudly and continue so one bad event doesn't kill
                    # the whole run.
                    logger.error(
                        "Unexpected exception escaped probe dispatch: %s",
                        r,
                        exc_info=r,
                    )
            request_count += sum(1 for r in results if r is _DispatchOutcome.DISPATCHED)
            if not any(r is _DispatchOutcome.DISPATCHED for r in results):
                # All events skipped or PATCH-back failed transiently —
                # back off before re-polling so the loop doesn't tight-spin
                # against Beacon while orphaned events persist server-side.
                await asyncio.sleep(poll_interval)
            continue

        snap = await _beacon_client.refresh_run(
            claim.run_id,
            client=beacon_http,
        )
        if snap.is_terminal:
            logger.info(
                "Run %s %s (%d requests served)",
                claim.run_id,
                snap.status.value,
                request_count,
            )
            if snap.status is ProbeRunStatus.FAILED:
                raise ProbeRunFailed(
                    snap.error_message or f"Run {claim.run_id} failed",
                )
            return snap

        await asyncio.sleep(poll_interval)


def _maybe_configure_basic_logging(*, verbose: bool) -> None:
    """Bootstrap stdout logging when the host script hasn't configured any.

    Without this, a copy-paste ``Probe.run("...")`` script prints
    nothing while the agent works on the Beacon side — confusing because
    the UI shows progress but the terminal looks frozen. We only set up
    a handler when there are none, so users with their own logging
    config (frameworks, libraries, daemons) aren't double-handled.

    httpx/httpcore log every HTTP call at INFO level. Most of those are
    the runner loop polling Beacon for pending requests — noise that
    drowns out the per-dispatch lines users actually want to see. We
    raise their floor to WARNING so only the SDK's own ``[seq N] ...``
    line appears for each target call. ``verbose=True`` opts back into
    the full firehose for debugging.
    """
    root = logging.getLogger()
    if root.handlers:
        return
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )
    if not verbose:
        logging.getLogger("httpx").setLevel(logging.WARNING)
        logging.getLogger("httpcore").setLevel(logging.WARNING)


def _validate_path_choice(
    target_callable: TargetCallable | None,
    headers: Mapping[str, str] | None,
    bearer_token: str | None,
    base_url: str | None,
) -> None:
    """Reject ambiguous kwarg combinations at entry.

    Either path A (auth kwargs and/or base_url override, no callable)
    or path B (callable, none of the path-A kwargs). Mixing both is a
    programmer error — the callable owns the connection so a base_url
    or auth kwarg has nothing to apply to.
    """
    if target_callable is not None and (
        headers or bearer_token is not None or base_url is not None
    ):
        raise ProbeError(
            "Pass either target_callable= (you own the connection and "
            "any auth) or headers=/bearer_token=/base_url= (the SDK "
            "fires HTTP and injects auth). Not both.",
        )


def _validate_builtin_auth(
    target: TargetSystemRef,
    headers: Mapping[str, str] | None,
    bearer_token: str | None,
) -> None:
    """For path A, ensure the auth kwarg matches the target's scheme."""
    scheme = target.auth_scheme_hint
    if scheme is AuthSchemeHint.NONE:
        if headers or bearer_token is not None:
            raise ProbeError(
                f"Target \"{target.name}\" has auth_scheme_hint='none' but "
                "an auth kwarg was passed. Drop the kwarg, or pass "
                "target_callable= to manage auth yourself.",
            )
        return
    if scheme is AuthSchemeHint.CUSTOM_HEADERS:
        if bearer_token is not None:
            raise ProbeError(
                f'Target "{target.name}" expects headers= '
                "(auth_scheme_hint='custom_headers'); drop bearer_token=.",
            )
        expected_names = _expected_header_names(target)
        if not headers:
            raise ProbeAuthMissingError(
                _missing_headers_message(target, expected_names, set()),
            )
        provided = {name.lower() for name in headers}
        missing = sorted(
            name for name in expected_names if name.lower() not in provided
        )
        if missing:
            raise ProbeAuthMissingError(
                _missing_headers_message(target, expected_names, set(missing)),
            )
        return
    if scheme is AuthSchemeHint.BEARER:
        if headers:
            raise ProbeError(
                f'Target "{target.name}" expects bearer_token= '
                "(auth_scheme_hint='bearer'); drop headers=.",
            )
        if bearer_token is None:
            raise ProbeAuthMissingError(
                _missing_auth_message(target, "bearer_token"),
            )
        return
    # Defensive: a future AuthSchemeHint added without a branch here
    # would otherwise let dispatch proceed without auth, producing
    # mysterious 401s from the target. Surface the SDK gap immediately.
    raise ProbeError(f"Unhandled auth_scheme_hint={scheme!r}; SDK out of date?")


def _expected_header_names(target: TargetSystemRef) -> list[str]:
    """Pull the ordered list of header names Beacon expects the user to
    supply for a ``custom_headers`` target.

    Beacon publishes these in ``auth_metadata.headers`` as
    ``[{"name": "..."}]``; missing or malformed values fall back to an
    empty list, leaving validation to the target itself.
    """
    raw = target.auth_metadata.get("headers")
    if not isinstance(raw, list):
        return []
    out: list[str] = []
    for entry in raw:
        if isinstance(entry, dict):
            name = entry.get("name")
            if isinstance(name, str) and name.strip():
                out.append(name.strip())
    return out


def _missing_auth_message(target: TargetSystemRef, kwarg: str) -> str:
    return (
        f'Target "{target.name}" requires {kwarg}= '
        f"(auth_scheme_hint='{target.auth_scheme_hint.value}'). "
        f"Either:\n"
        f'    Probe.run("<run_id>", {kwarg}="<your-secret>")\n'
        f"Or supply your own dispatcher:\n"
        f'    Probe.run("<run_id>", target_callable=my_target)'
    )


def _missing_headers_message(
    target: TargetSystemRef,
    expected: list[str],
    missing: set[str],
) -> str:
    if not expected:
        # Target has no published header names — the user just hasn't
        # passed any headers at all.
        sample = '"X-API-Key": "<your-key>"'
    else:
        sample = ", ".join(f'"{name}": "<value>"' for name in expected)
    if missing:
        missing_clause = f" Missing entries: {sorted(missing)!r}."
    else:
        missing_clause = ""
    return (
        f'Target "{target.name}" requires headers= '
        f"(auth_scheme_hint='custom_headers').{missing_clause} Either:\n"
        f'    Probe.run("<run_id>", headers={{{sample}}})\n'
        f"Or supply your own dispatcher:\n"
        f'    Probe.run("<run_id>", target_callable=my_target)'
    )


class _Dispatcher:
    async def execute(self, request: ProbeHttpRequest) -> ProbeHttpResponse:
        raise NotImplementedError


class _BuiltInDispatcher(_Dispatcher):
    def __init__(
        self,
        *,
        target: TargetSystemRef,
        auth: BuiltInAuth,
        base_url: str | None,
        client: httpx.AsyncClient,
    ) -> None:
        self._target = target
        self._auth = auth
        self._base_url = base_url
        self._client = client

    async def execute(self, request: ProbeHttpRequest) -> ProbeHttpResponse:
        return await dispatch_builtin(
            request,
            target=self._target,
            auth=self._auth,
            client=self._client,
            base_url=self._base_url,
        )


class _CallableDispatcher(_Dispatcher):
    def __init__(self, target_callable: TargetCallable) -> None:
        self._target_callable = target_callable

    async def execute(self, request: ProbeHttpRequest) -> ProbeHttpResponse:
        return await _invoke_target(self._target_callable, request)


async def _dispatch_one(
    request: ProbeHttpRequest,
    dispatcher: _Dispatcher,
    attempts: dict[str, int],
    response_cache: dict[str, ProbeHttpResponse],
    beacon_http: httpx.AsyncClient,
) -> _DispatchOutcome:
    """Dispatch one event and PATCH the response back.

    Returns a :class:`_DispatchOutcome` so the caller can distinguish
    real progress from skips and transient PATCH failures (used to
    decide whether to back off before re-polling). Raises
    ``ProbeValidationError`` on schema drift / programmer error so the
    runner can halt.

    Behaviour:

    - If the event hit ``MAX_DISPATCH_ATTEMPTS`` previously, return
      ``SKIPPED`` without contacting the target.
    - If a previous attempt cached a response (target succeeded but
      PATCH-back failed), replay just the PATCH; do not re-fire the
      target.
    - Otherwise dispatch the target, log, then PATCH.

    On PATCH failures: 404 marks the event done (server already
    terminal); 422 raises (schema drift); transport-layer errors bump
    the attempt counter, cache the response, and return
    ``PATCH_FAILED``.
    """
    if attempts.get(request.id, 0) >= MAX_DISPATCH_ATTEMPTS:
        logger.warning(
            "Skipping event %s (seq %d) after %d failed PATCH attempts",
            request.id,
            request.seq,
            MAX_DISPATCH_ATTEMPTS,
        )
        return _DispatchOutcome.SKIPPED

    cached = response_cache.get(request.id)
    if cached is not None:
        response = cached
        replayed = True
    else:
        response = await dispatcher.execute(request)
        _log_dispatch(request, response)
        replayed = False

    try:
        await _beacon_client.post_response(
            request.id,
            response,
            client=beacon_http,
        )
    except ProbeNotFoundError:
        # Event already terminal server-side (agent timed out, run
        # cancelled, etc.); free the cache and don't re-dispatch.
        response_cache.pop(request.id, None)
        attempts[request.id] = MAX_DISPATCH_ATTEMPTS
        logger.info(
            "Event %s no longer pending on Beacon; skipping further attempts",
            request.id,
        )
        return _DispatchOutcome.SKIPPED
    except ProbeValidationError:
        # Our payload didn't match the schema — bug, surface to the
        # caller via _run_loop so the user can fix it.
        raise
    except (httpx.HTTPError, ProbeError) as e:
        # Cache the response so the next attempt replays the PATCH
        # without re-firing the target.
        response_cache[request.id] = response
        attempts[request.id] = attempts.get(request.id, 0) + 1
        logger.error(
            "Target call for event %s (seq %d, %s %s) %s but failed to "
            "report to Beacon (attempt %d/%d): %s",
            request.id,
            request.seq,
            request.method,
            request.url,
            "result replayed from cache" if replayed else "succeeded",
            attempts[request.id],
            MAX_DISPATCH_ATTEMPTS,
            e,
        )
        return _DispatchOutcome.PATCH_FAILED

    response_cache.pop(request.id, None)
    return _DispatchOutcome.DISPATCHED


async def _invoke_target(
    target_callable: TargetCallable,
    request: ProbeHttpRequest,
) -> ProbeHttpResponse:
    """Invoke the user's callable, normalising sync/async + exception paths.

    Sync callables run on a worker thread so they don't block the runner
    loop. The return value is coerced via ``_normalise_return`` —
    typed responses pass through, ``httpx.Response`` and ``str`` are
    wrapped, anything else raises ``ProbeValidationError`` so a contract
    violation halts the run rather than reporting fake errors.

    SDK-fatal exceptions (``MemoryError``, ``RecursionError``,
    ``BaseException`` subclasses like ``KeyboardInterrupt``) propagate
    rather than being captured as a target error — those mean the SDK
    or interpreter is in an unstable state, not the target.
    """
    started = time.monotonic()
    try:
        if inspect.iscoroutinefunction(target_callable):
            result = await target_callable(request)
        else:
            result = await asyncio.to_thread(target_callable, request)
            if inspect.isawaitable(result):
                # Sync callable returning a coroutine (e.g. a decorator-wrapped
                # async fn, or `lambda r: some_async_helper(r)`) — honour it.
                result = await result
    except (MemoryError, RecursionError):
        raise
    except Exception as exc:  # noqa: BLE001
        duration_ms = int((time.monotonic() - started) * 1000)
        return ProbeHttpErrorResponse(
            duration_ms=duration_ms,
            error=f"{type(exc).__name__}: {exc}",
        )

    return _normalise_return(result, started=started)


def _normalise_return(
    result: Any,
    *,
    started: float,
) -> ProbeHttpResponse:
    """Coerce any ``TargetReturn`` value into a ``ProbeHttpResponse``."""
    if isinstance(result, (ProbeHttpSuccessResponse, ProbeHttpErrorResponse)):
        return result

    if isinstance(result, httpx.Response) or _is_requests_response(result):
        return _from_response_object(result, started=started)

    if isinstance(result, str):
        duration_ms = int((time.monotonic() - started) * 1000)
        return ProbeHttpSuccessResponse(
            duration_ms=duration_ms,
            status_code=200,
            response_body=result,
        )

    raise ProbeValidationError(
        f"target_callable returned {type(result).__name__!s}; expected "
        "ProbeHttpSuccessResponse, ProbeHttpErrorResponse, "
        "httpx.Response, requests.Response, or str."
    )


def _is_requests_response(obj: Any) -> bool:
    """Soft check for ``requests.Response`` without making ``requests`` a
    hard dependency. Returns ``False`` (not raises) when the optional
    library isn't installed."""
    try:
        from requests.models import Response as RequestsResponse
    except ImportError:
        return False
    return isinstance(obj, RequestsResponse)


def _from_response_object(
    response: Any,
    *,
    started: float,
) -> ProbeHttpSuccessResponse:
    """Convert a finished ``httpx.Response`` or ``requests.Response`` to a
    ``ProbeHttpSuccessResponse``.

    The two libs share the relevant attribute surface: ``status_code``,
    ``headers``, ``text``, ``elapsed`` (a ``timedelta``). Any HTTP
    status (including 4xx/5xx) is a valid "response" — those are
    replies, not errors. ``response.elapsed`` provides ``duration_ms``
    when available; we fall back to wall-clock time since ``started``
    if the response was constructed manually (e.g. test mocks) or if
    httpx raises because the body wasn't read yet.
    """
    elapsed = None
    try:
        elapsed = response.elapsed
    except (AttributeError, RuntimeError):
        pass
    duration_ms = (
        int(elapsed.total_seconds() * 1000)
        if elapsed is not None
        else int((time.monotonic() - started) * 1000)
    )
    try:
        body = response.text
    except UnicodeDecodeError:
        size = len(response.content)
        logger.debug(
            "target_callable response body is binary, %d bytes; reporting placeholder",
            size,
        )
        body = f"<binary body, {size} bytes>"
    return ProbeHttpSuccessResponse(
        duration_ms=duration_ms,
        status_code=response.status_code,
        response_headers=dict(response.headers),
        response_body=body,
    )


def _log_dispatch(
    request: ProbeHttpRequest,
    response: Any,
) -> None:
    outcome = (
        str(response.status_code)
        if response.kind is ProbeResponseKind.RESPONSE
        else f"ERROR ({response.error})"
    )
    logger.info(
        "[seq %d] %s %s -> %s (%d ms)",
        request.seq,
        request.method,
        request.url,
        outcome,
        response.duration_ms,
    )
