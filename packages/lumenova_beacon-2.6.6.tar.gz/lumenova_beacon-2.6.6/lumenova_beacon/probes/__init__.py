"""SDK-mode probe execution.

    >>> from lumenova_beacon.probes import Probe
    >>> Probe.run("<run-id-from-the-ui>")  # blocks until run terminal

The SDK claims a probe evaluation run on Beacon, polls for pending HTTP
events the server-side agent wants executed, runs them against the user's
target with local credentials, redacts sensitive data, and PATCHes the
response back. The agent (LangGraph + LLM + scoring) runs on Beacon and is
unaware of the transport mode.
"""

from lumenova_beacon.probes._http import rewrite_url
from lumenova_beacon.probes.models import Probe
from lumenova_beacon.probes.types import (
    AuthSchemeHint,
    ProbeClaimResponse,
    ProbeHttpErrorResponse,
    ProbeHttpRequest,
    ProbeHttpResponse,
    ProbeHttpSuccessResponse,
    ProbeResponseKind,
    ProbeRunStatus,
    RunStatusSnapshot,
    TargetSystemRef,
)

__all__ = [
    "AuthSchemeHint",
    "Probe",
    "ProbeClaimResponse",
    "ProbeHttpErrorResponse",
    "ProbeHttpRequest",
    "ProbeHttpResponse",
    "ProbeHttpSuccessResponse",
    "ProbeResponseKind",
    "ProbeRunStatus",
    "RunStatusSnapshot",
    "TargetSystemRef",
    "rewrite_url",
]
