"""HTTP utility classes and functions for centralized error handling."""

import json
from typing import NoReturn

import httpx

# Cap exception messages so a multi-MB nginx error page or HTML traceback
# doesn't end up concatenated into a Probe* / Dataset* exception message
# (which then propagates into logs and tracebacks).
MAX_ERROR_BODY_BYTES = 512


def truncate_body(text: str) -> str:
    if len(text) <= MAX_ERROR_BODY_BYTES:
        return text
    return text[:MAX_ERROR_BODY_BYTES] + "... [truncated]"


def _safe_detail(response: httpx.Response) -> str:
    """Best-effort detail extraction from an error response.

    Tries JSON's ``detail`` first, falls back to text. Both stages are
    guarded so a malformed body or undecodable bytes don't mask the
    original HTTP error.
    """
    try:
        body = response.json()
    except (ValueError, json.JSONDecodeError):
        body = None
    if isinstance(body, dict) and "detail" in body:
        detail = body["detail"]
        if isinstance(detail, str):
            return detail
    try:
        return response.text
    except UnicodeDecodeError:
        return response.content[:MAX_ERROR_BODY_BYTES].decode(
            "utf-8", errors="replace",
        )


class HTTPErrorHandler:
    """Centralized HTTP error handling for consistent error mapping.

    This class provides a reusable way to map HTTP status codes to
    domain-specific exceptions across different modules (datasets, prompts, etc.).

    Example:
        >>> from lumenova_beacon.exceptions import (
        ...     DatasetError, DatasetNotFoundError, DatasetValidationError
        ... )
        >>> handler = HTTPErrorHandler(
        ...     not_found_exc=DatasetNotFoundError,
        ...     validation_exc=DatasetValidationError,
        ...     base_exc=DatasetError
        ... )
        >>> try:
        ...     # Some HTTP request that returns 404
        ...     pass
        ... except httpx.HTTPStatusError as e:
        ...     handler.handle(e)  # Raises DatasetNotFoundError
    """

    def __init__(
        self,
        not_found_exc: type[Exception],
        validation_exc: type[Exception],
        base_exc: type[Exception],
    ):
        """Initialize the error handler with exception types.

        Args:
            not_found_exc: Exception to raise for 404 errors
            validation_exc: Exception to raise for 422 errors
            base_exc: Exception to raise for all other errors
        """
        self.not_found_exc = not_found_exc
        self.validation_exc = validation_exc
        self.base_exc = base_exc

    def handle(self, e: httpx.HTTPStatusError) -> NoReturn:
        """Handle HTTP status errors by raising appropriate exceptions.

        Args:
            e: The HTTP status error to handle

        Raises:
            not_found_exc: If status code is 404
            validation_exc: If status code is 422
            base_exc: For all other status codes
        """
        detail = _safe_detail(e.response)
        truncated = truncate_body(detail)
        if e.response.status_code == 404:
            raise self.not_found_exc(f"Not found: {truncated}") from e
        if e.response.status_code == 422:
            raise self.validation_exc(f"Validation error: {truncated}") from e
        raise self.base_exc(
            f"API error ({e.response.status_code}): {truncated}",
        ) from e
