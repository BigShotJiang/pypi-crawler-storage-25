"""Async utilities for bridging sync and async code."""

from __future__ import annotations

import asyncio
import atexit
import concurrent.futures
import logging
from typing import Any, Coroutine, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")

# Reused across run_sync calls so each invocation doesn't pay the cost of
# spawning + tearing down an OS thread. Created lazily on first use.
_executor: concurrent.futures.ThreadPoolExecutor | None = None


def _get_executor() -> concurrent.futures.ThreadPoolExecutor:
    global _executor
    if _executor is None:
        _executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="beacon-run-sync",
        )
        atexit.register(_executor.shutdown, wait=False)
    return _executor


def run_sync(coro: Coroutine[Any, Any, T]) -> T:
    """Run an async coroutine from synchronous code.

    Handles both cases:
    - No running event loop: uses ``asyncio.run()``
    - Inside a running event loop (e.g. Jupyter, async frameworks):
      submits to a reused worker thread that owns its own loop

    Args:
        coro: The coroutine to execute.

    Returns:
        The coroutine's return value.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        # No running loop — the simple path
        return asyncio.run(coro)

    # Already inside a running loop (Jupyter, async web framework, etc.)
    # Catch BaseException (not just Exception) so KeyboardInterrupt /
    # SystemExit / asyncio.CancelledError still trigger coro.close() —
    # otherwise the "coroutine was never awaited" warning the cleanup
    # was meant to prevent fires anyway.
    try:
        return _get_executor().submit(asyncio.run, coro).result()
    except BaseException:
        try:
            coro.close()
        except Exception:
            # Don't mask the original exception with a cleanup failure —
            # log the close error and re-raise the original below.
            logger.exception("Failed to close coroutine during run_sync cleanup")
        raise
