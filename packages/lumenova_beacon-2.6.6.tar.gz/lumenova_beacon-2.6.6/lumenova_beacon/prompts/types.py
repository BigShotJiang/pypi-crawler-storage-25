"""Type definitions for prompt management."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any

from lumenova_beacon.utils.datetime import parse_iso_datetime


class PromptType(str, Enum):
    """Enum for prompt types."""

    TEXT = 'text'
    CHAT = 'chat'

    @property
    def api_id(self) -> int:
        """Return the integer ID used by the API for this prompt type."""
        return _PROMPT_TYPE_API_IDS[self]

    @classmethod
    def from_api_id(cls, api_id: int) -> PromptType:
        """Resolve a PromptType from the integer ID used by the API."""
        try:
            return _REVERSE_PROMPT_TYPE_API_IDS[api_id]
        except KeyError:
            raise ValueError(f"Unknown prompt type API ID: {api_id}") from None


_PROMPT_TYPE_API_IDS = {PromptType.TEXT: 1, PromptType.CHAT: 2}
_REVERSE_PROMPT_TYPE_API_IDS = {v: k for k, v in _PROMPT_TYPE_API_IDS.items()}


@dataclass(frozen=True)
class ChatMessage:
    """Single message in a chat prompt."""

    role: str
    content: str

    def to_dict(self) -> dict[str, str]:
        return {'role': self.role, 'content': self.content}


@dataclass(frozen=True)
class PromptVersion:
    """A single version of a prompt."""

    id: str
    prompt_id: str
    version: int
    content: dict[str, Any]
    commit_message: str | None
    created_at: datetime | None
    usage_count: int

    @classmethod
    def _from_dict(cls, data: dict[str, Any]) -> PromptVersion:
        return cls(
            id=data['id'],
            prompt_id=data.get('prompt_id', ''),
            version=data['version'],
            content=data.get('content', {}),
            commit_message=data.get('commit_message'),
            created_at=parse_iso_datetime(data.get('created_at')),
            usage_count=data.get('usage_count', 0),
        )
