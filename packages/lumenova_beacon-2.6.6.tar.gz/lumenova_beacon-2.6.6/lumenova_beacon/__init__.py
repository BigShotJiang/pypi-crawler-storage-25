"""Lumenova Beacon SDK - A Python SDK for observability tracing with OpenTelemetry-compatible span export."""

from lumenova_beacon._pipeline import (
    DataMode,
    ExtractionEngine,
    ProcessorKind,
    ProcessorStep,
    VariableMapping,
)
from lumenova_beacon.core.client import BeaconClient, get_client
from lumenova_beacon.core.config import BeaconConfig
from lumenova_beacon.probes import (
    Probe,
    ProbeHttpErrorResponse,
    ProbeHttpRequest,
    ProbeHttpSuccessResponse,
    rewrite_url,
)
from lumenova_beacon.tracing.decorators import trace


__version__ = '0.1.0'

__all__ = [
    # Core client
    'BeaconClient',
    'BeaconConfig',
    'get_client',
    'trace',
    # Probes (system-probe SDK callable mode)
    'Probe',
    'ProbeHttpErrorResponse',
    'ProbeHttpRequest',
    'ProbeHttpSuccessResponse',
    'rewrite_url',
    # Variable-mapping extraction engines
    'DataMode',
    'ExtractionEngine',
    'ProcessorKind',
    'ProcessorStep',
    'VariableMapping',
    # LangChain/LangGraph integration (lazy-loaded)
    'BeaconLangGraphHandler',
    'BeaconLangGraphConfig',
    'get_beacon_handler',
    # Deprecated aliases (backward compatibility)
    'BeaconCallbackHandler',
    'LangGraphBeaconConfig',
    # Governance integration (lazy-loaded)
    'BeaconLangGraphAgent',
    'BeaconLangGraphGovernanceHandler',
    'GovernanceConfig',
    'governance',
    # Strands Agents integration (lazy-loaded)
    'BeaconStrandsHandler',
    # CrewAI integration (lazy-loaded)
    'BeaconCrewAIListener',
    # LiteLLM integration (lazy-loaded)
    'BeaconLiteLLMLogger',
]


def __getattr__(name: str) -> type:
    """Lazy import for optional integration classes.

    This allows the core package to be imported without optional dependencies
    like langchain-core, while still providing a convenient import path.

    Args:
        name: The attribute name being accessed.

    Returns:
        The requested class if it's a lazy-loaded integration.

    Raises:
        AttributeError: If the attribute doesn't exist.
        ImportError: If the required optional dependency is not installed.
    """
    if name in ('BeaconLangGraphHandler', 'BeaconCallbackHandler'):
        from lumenova_beacon.tracing.integrations.langchain import BeaconLangGraphHandler

        if name == 'BeaconCallbackHandler':
            import warnings

            warnings.warn(
                'BeaconCallbackHandler is deprecated, use BeaconLangGraphHandler instead',
                DeprecationWarning,
                stacklevel=2,
            )
        return BeaconLangGraphHandler

    if name == 'get_beacon_handler':
        from lumenova_beacon.tracing.integrations.langchain import get_beacon_handler

        return get_beacon_handler

    if name in ('BeaconLangGraphConfig', 'LangGraphBeaconConfig'):
        from lumenova_beacon.tracing.integrations.langchain import BeaconLangGraphConfig

        if name == 'LangGraphBeaconConfig':
            import warnings

            warnings.warn(
                'LangGraphBeaconConfig is deprecated, use BeaconLangGraphConfig instead',
                DeprecationWarning,
                stacklevel=2,
            )
        return BeaconLangGraphConfig

    if name == 'BeaconLangGraphGovernanceHandler':
        from lumenova_beacon.governance.integrations.langchain import BeaconLangGraphGovernanceHandler

        return BeaconLangGraphGovernanceHandler

    if name == 'BeaconLangGraphAgent':
        from lumenova_beacon.governance.integrations.langgraph_agent import BeaconLangGraphAgent

        return BeaconLangGraphAgent

    if name == 'GovernanceConfig':
        from lumenova_beacon.governance.config import GovernanceConfig

        return GovernanceConfig

    if name == 'governance':
        from lumenova_beacon.governance.decorators import governance

        return governance

    if name == 'BeaconStrandsHandler':
        from lumenova_beacon.tracing.integrations.strands import BeaconStrandsHandler

        return BeaconStrandsHandler

    if name == 'BeaconCrewAIListener':
        from lumenova_beacon.tracing.integrations.crewai import BeaconCrewAIListener

        return BeaconCrewAIListener

    if name == 'BeaconLiteLLMLogger':
        from lumenova_beacon.tracing.integrations.litellm import BeaconLiteLLMLogger

        return BeaconLiteLLMLogger

    raise AttributeError(f'module {__name__!r} has no attribute {name!r}')
