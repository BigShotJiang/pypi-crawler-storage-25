"""Variable-mapping extraction-engine primitives shared by Evaluation and Experiment.

The Beacon backend supports three extraction engines per variable-mapping value:

- ``jsonpath`` — straightforward path access (e.g. ``$.input.messages[0].content``).
- ``jsonata`` — structural transforms (filter, join, aggregate, reshape).
- ``python`` — general-purpose code via a top-level ``def extract(data):`` function.

Wire-format invariant the SDK enforces: a single mapping carries either a
legacy ``json_path`` string (used by JSONPath-only callers) **or** a
``pipeline`` array of typed steps, never both. The convenience constructors
(``VariableMapping.jsonpath``, ``.jsonata``, ``.python``, ``.chain``) make this
choice for the caller; ``VariableMapping.__post_init__`` rejects the both-set
shape to defend against the inverted-check bug class fixed in
lumenova-guardrails MR !337.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Union


MAX_EXPR_LEN = 65_536
"""Maximum expression length in characters; mirrors backend ``ProcessorStep.expr`` cap."""

MAX_PIPELINE_STEPS = 32
"""Maximum number of steps in a single pipeline; mirrors backend ``PreviewPipelineRequest``."""


_KNOWN_VARIABLE_MAPPING_KEYS = frozenset(
    {
        "data_mode",
        "json_path",
        "pipeline",
        "reduced_fields",
        "format_as_conversation",
        "input_selection",
        "output_selection",
        "column",
        "is_fixed",
        "fixed_value",
    }
)


class ExtractionEngine(str, Enum):
    """Engine that interprets a variable-mapping expression.

    - ``JSONPATH``: legacy single-path extractor; only supports ``EXTRACT_PATH``.
    - ``JSONATA``: full JSONata language; supports all kinds.
    - ``PYTHON``: sandboxed Python ``def extract(data):`` function; supports all kinds.
    """

    JSONPATH = "jsonpath"
    JSONATA = "jsonata"
    PYTHON = "python"


class ProcessorKind(str, Enum):
    """Pipeline-step kind. UX hint only — backend dispatches purely on engine."""

    EXTRACT_PATH = "extract_path"
    FILTER = "filter"
    COMBINE = "combine"
    RESHAPE = "reshape"


class DataMode(str, Enum):
    """Variable-mapping data mode.

    - ``RAW``: pass the raw trace data through (with optional path/pipeline extraction).
    - ``REDUCED``: server-side reduce to span-summary fields (``reduced_fields``).
    """

    RAW = "raw"
    REDUCED = "reduced"


def _coerce_kind(kind: ProcessorKind | str) -> ProcessorKind:
    return ProcessorKind(kind) if isinstance(kind, str) else kind


@dataclass(frozen=True)
class ProcessorStep:
    """One step in a JSON preprocessing pipeline.

    Mirrors the backend ``ProcessorStep`` Pydantic model. ``kind`` is a UX hint;
    the dispatcher routes purely on ``engine``. Frozen so post-construction
    mutation can't bypass the construction-time validators.

    Attributes:
        engine: Expression language used by this step.
        expr: Expression to evaluate against the step's input.
        kind: Step-kind hint (``extract_path`` by default).
    """

    engine: ExtractionEngine = ExtractionEngine.JSONATA
    expr: str = ""
    kind: ProcessorKind = ProcessorKind.EXTRACT_PATH

    def __post_init__(self) -> None:
        if isinstance(self.engine, str):
            object.__setattr__(self, "engine", ExtractionEngine(self.engine))
        if isinstance(self.kind, str):
            object.__setattr__(self, "kind", ProcessorKind(self.kind))
        if len(self.expr) > MAX_EXPR_LEN:
            raise ValueError(
                f"expr length {len(self.expr)} exceeds maximum {MAX_EXPR_LEN}"
            )
        if self.engine is ExtractionEngine.JSONPATH and self.kind is not ProcessorKind.EXTRACT_PATH:
            raise ValueError(
                f"kind={self.kind.value!r} is not supported on engine='jsonpath'; "
                "use engine='jsonata' or engine='python' for filter/combine/reshape steps."
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind.value,
            "engine": self.engine.value,
            "expr": self.expr,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProcessorStep:
        """Construct from a wire-format dict (validates on construction)."""
        return cls(
            engine=ExtractionEngine(data.get("engine", ExtractionEngine.JSONATA.value)),
            expr=data.get("expr", ""),
            kind=ProcessorKind(data.get("kind", ProcessorKind.EXTRACT_PATH.value)),
        )


@dataclass(frozen=True)
class VariableMapping:
    """Typed builder for a single variable-mapping value.

    Pick a convenience constructor when possible — they emit the correct wire
    shape by construction and cannot produce the inverted-check bug class:

    - ``VariableMapping.jsonpath(expr)`` → emits ``json_path`` (legacy field).
    - ``VariableMapping.jsonata(expr)`` → emits a one-step ``pipeline``.
    - ``VariableMapping.python(expr)`` → emits a one-step ``pipeline``.
    - ``VariableMapping.chain(*steps)`` → emits a multi-step ``pipeline``.
    - ``VariableMapping.reduced(...)`` → emits ``data_mode='reduced'`` with
      span-reduction fields (no expression).
    - ``VariableMapping.fixed(value)`` → emits a fixed literal value.
    - ``VariableMapping.from_column(name)`` → emits a dataset-column reference
      (experiment-step config and dataset-based evaluations only — trace
      evaluations have no column concept).

    Existing dict-shaped ``variable_mappings`` continue to work; this dataclass
    is purely additive.

    Frozen: the dataclass is immutable, so the construction-time validators
    cannot be bypassed by post-construction attribute assignment. Unknown
    server-side fields parsed via ``from_dict`` are captured in ``_extra`` and
    re-emitted by ``to_dict``, so a ``from_dict → to_dict`` round-trip
    preserves any keys the SDK does not yet model.
    """

    data_mode: DataMode = DataMode.REDUCED
    json_path: str | None = None
    pipeline: list[ProcessorStep] | None = None
    reduced_fields: list[str] | None = None
    format_as_conversation: bool = False
    input_selection: str | None = None
    output_selection: str | None = None
    column: str | None = None
    is_fixed: bool = False
    fixed_value: str | None = None
    _extra: dict[str, Any] = field(default_factory=dict, repr=False, compare=False)

    def __post_init__(self) -> None:
        if isinstance(self.data_mode, str):
            object.__setattr__(self, "data_mode", DataMode(self.data_mode))

        if self.is_fixed:
            if self.fixed_value is None:
                raise ValueError(
                    "is_fixed=True requires a non-None fixed_value; "
                    "pass VariableMapping.fixed(value) instead."
                )
            if (
                self.pipeline is not None
                or self.json_path is not None
                or self.column is not None
            ):
                raise ValueError(
                    "is_fixed=True is mutually exclusive with pipeline / json_path / column"
                )
            return

        if self.pipeline is not None and self.json_path is not None:
            raise ValueError(
                "Set either 'pipeline' or 'json_path', not both. The two fields "
                "are mutually exclusive on the wire; pipeline supersedes json_path."
            )

        if self.pipeline is not None:
            if len(self.pipeline) == 0:
                raise ValueError(
                    "pipeline cannot be empty; omit it (or use json_path / "
                    "VariableMapping.reduced) when there is no extraction step."
                )
            if len(self.pipeline) > MAX_PIPELINE_STEPS:
                raise ValueError(
                    f"pipeline length {len(self.pipeline)} exceeds maximum {MAX_PIPELINE_STEPS}"
                )
            if self.data_mode is not DataMode.RAW:
                raise ValueError(
                    "pipeline requires data_mode='raw'; reduced mode reads span-summary fields"
                )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to the per-variable wire shape.

        Emits either ``json_path`` or ``pipeline`` (never both). Unknown
        server-side fields captured by ``from_dict`` are re-emitted so a
        ``from_dict → to_dict`` round-trip is non-lossy. Typed fields override
        any same-name key carried in ``_extra``.
        """
        # Carry forward unknown fields first so explicit attributes take precedence.
        out: dict[str, Any] = dict(self._extra)
        out["data_mode"] = self.data_mode.value
        if self.is_fixed:
            out["is_fixed"] = True
            if self.fixed_value is not None:
                out["fixed_value"] = self.fixed_value
            return out

        if self.column is not None:
            out["column"] = self.column

        if self.pipeline is not None:
            out["pipeline"] = [step.to_dict() for step in self.pipeline]
            out.pop("json_path", None)
        elif self.json_path is not None:
            out["json_path"] = self.json_path
            out.pop("pipeline", None)

        if self.reduced_fields is not None:
            out["reduced_fields"] = list(self.reduced_fields)
        if self.format_as_conversation:
            out["format_as_conversation"] = True
        if self.input_selection is not None:
            out["input_selection"] = self.input_selection
        if self.output_selection is not None:
            out["output_selection"] = self.output_selection
        return out

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VariableMapping:
        """Parse a wire-format mapping dict into a typed VariableMapping.

        Unknown server-side keys are captured in ``_extra`` and re-emitted by
        ``to_dict``, so a ``from_dict → to_dict`` round-trip preserves fields
        the SDK does not yet model. The raw dict from
        ``Evaluation.variable_mappings`` remains the authoritative source of
        truth; use this typed view as a convenience.
        """
        pipeline_raw = data.get("pipeline")
        pipeline = (
            [ProcessorStep.from_dict(step) for step in pipeline_raw]
            if pipeline_raw is not None
            else None
        )
        extras = {k: v for k, v in data.items() if k not in _KNOWN_VARIABLE_MAPPING_KEYS}
        return cls(
            data_mode=DataMode(data.get("data_mode", DataMode.REDUCED.value)),
            json_path=data.get("json_path"),
            pipeline=pipeline,
            reduced_fields=list(data["reduced_fields"]) if data.get("reduced_fields") else None,
            format_as_conversation=bool(data.get("format_as_conversation", False)),
            input_selection=data.get("input_selection"),
            output_selection=data.get("output_selection"),
            column=data.get("column"),
            is_fixed=bool(data.get("is_fixed", False)),
            fixed_value=data.get("fixed_value"),
            _extra=extras,
        )

    # === Convenience constructors ===

    @classmethod
    def jsonpath(
        cls,
        expr: str,
        *,
        data_mode: DataMode | str = DataMode.RAW,
        reduced_fields: list[str] | None = None,
    ) -> VariableMapping:
        if len(expr) > MAX_EXPR_LEN:
            raise ValueError(
                f"expr length {len(expr)} exceeds maximum {MAX_EXPR_LEN}"
            )
        return cls(
            data_mode=DataMode(data_mode) if isinstance(data_mode, str) else data_mode,
            json_path=expr,
            reduced_fields=reduced_fields,
        )

    @classmethod
    def jsonata(
        cls,
        expr: str,
        *,
        kind: ProcessorKind | str = ProcessorKind.EXTRACT_PATH,
    ) -> VariableMapping:
        """Build a single-step JSONata mapping."""
        return cls(
            data_mode=DataMode.RAW,
            pipeline=[
                ProcessorStep(
                    engine=ExtractionEngine.JSONATA, expr=expr, kind=_coerce_kind(kind)
                )
            ],
        )

    @classmethod
    def python(
        cls,
        expr: str,
        *,
        kind: ProcessorKind | str = ProcessorKind.EXTRACT_PATH,
    ) -> VariableMapping:
        """Build a single-step Python mapping. ``expr`` must define ``def extract(data):``."""
        return cls(
            data_mode=DataMode.RAW,
            pipeline=[
                ProcessorStep(
                    engine=ExtractionEngine.PYTHON, expr=expr, kind=_coerce_kind(kind)
                )
            ],
        )

    @classmethod
    def chain(cls, *steps: ProcessorStep) -> VariableMapping:
        """Build a multi-step pipeline mapping. Engines may mix freely (e.g. JSONata → Python)."""
        if not steps:
            raise ValueError(
                "chain requires at least one step; use VariableMapping.reduced() or "
                "VariableMapping.jsonpath() if no pipeline is needed."
            )
        return cls(data_mode=DataMode.RAW, pipeline=list(steps))

    @classmethod
    def reduced(
        cls,
        *,
        reduced_fields: list[str] | None = None,
        format_as_conversation: bool = False,
        input_selection: str | None = None,
        output_selection: str | None = None,
    ) -> VariableMapping:
        """Build a reduced-mode mapping that reads span-summary fields."""
        return cls(
            data_mode=DataMode.REDUCED,
            reduced_fields=reduced_fields,
            format_as_conversation=format_as_conversation,
            input_selection=input_selection,
            output_selection=output_selection,
        )

    @classmethod
    def fixed(cls, value: str) -> VariableMapping:
        return cls(is_fixed=True, fixed_value=value)

    @classmethod
    def from_column(cls, name: str) -> VariableMapping:
        """Build a dataset-column reference.

        Meaningful for experiment-step ``config`` and dataset-based evaluations.
        Trace evaluations have no column concept and the backend will reject
        the field — use ``jsonpath`` / ``jsonata`` for trace data instead.
        """
        return cls(column=name)


# Type alias used by Evaluation/Experiment surfaces to widen their argument types.
VariableMappingValue = Union[VariableMapping, Mapping[str, Any], str]
"""Per-variable value in a ``variable_mappings`` dict: typed, raw dict, or column-name string."""

VariableMappingsArg = Mapping[str, VariableMappingValue]
"""Argument type for ``variable_mappings`` parameters across the SDK."""


def _normalize_variable_mappings(
    mappings: VariableMappingsArg | None,
) -> dict[str, Any] | None:
    """Convert a mixed mappings dict to wire-format dicts.

    - ``VariableMapping`` instances are converted via ``to_dict()``.
    - Raw ``Mapping`` values pass through as ``dict`` (legacy callers).
    - Bare ``str`` values pass through unchanged (column-name shorthand used
      by experiments).
    - ``None`` returns ``None`` so callers can skip the payload key entirely.

    Raises ``TypeError`` for anything else (lists, ints, sets, etc.) so users
    fail fast at the SDK boundary instead of seeing an opaque backend 422.
    """
    if mappings is None:
        return None
    if not isinstance(mappings, Mapping):
        raise TypeError(
            f"variable_mappings must be a Mapping, got {type(mappings).__name__}"
        )
    out: dict[str, Any] = {}
    for name, value in mappings.items():
        if isinstance(value, VariableMapping):
            out[name] = value.to_dict()
        elif isinstance(value, str):
            out[name] = value
        elif isinstance(value, Mapping):
            out[name] = dict(value)
        else:
            raise TypeError(
                f"variable_mappings[{name!r}] must be a VariableMapping, Mapping, or str; "
                f"got {type(value).__name__}"
            )
    return out
