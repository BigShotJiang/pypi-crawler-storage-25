"""Decorator for automatic governance policy evaluation.

Provides a ``@governance`` decorator analogous to ``@trace`` that wraps
any function with pre/post governance evaluation against the Beacon API.

Usage:
    from lumenova_beacon.governance import governance

    # Without parentheses (requires stack_ids/tags set elsewhere or will
    # raise at call time):
    @governance
    def my_tool(query: str) -> str:
        ...

    # With configuration:
    @governance(stack_ids=['my-stack'], fail_open=False)
    def send_email(to: str, body: str) -> bool:
        ...

    # Async support:
    @governance(tags=['env:prod'])
    async def async_tool(data: dict) -> dict:
        ...

    # Wrapping LangChain tools (governance on top of @tool):
    from langchain_core.tools import tool

    @governance(stack_ids=['my-stack'])
    @tool
    def search_db(query: str) -> str:
        \"\"\"Search the database.\"\"\"
        ...
"""

from __future__ import annotations

import functools
import inspect
import logging

from collections.abc import Callable
from typing import Any, TypeVar, cast, overload
from uuid import UUID

from lumenova_beacon.exceptions import GovernanceConfigurationError
from lumenova_beacon.governance._helpers import (
    aevaluate_or_fail_open,
    enforce,
    evaluate_or_fail_open,
    get_sdk_version,
    parse_outcome,
    truncate,
)
from lumenova_beacon.governance._state import (
    _active_handler,
    _active_node_run_id,
    _resolve_active_node,
    lookup_state_for,
    serialize_state,
)
from lumenova_beacon.governance._wrapping import (
    apply_llm_messages_replacement,
    apply_llm_return_replacement,
    apply_tool_kwargs_replacement,
    apply_tool_return_replacement,
)
from lumenova_beacon.governance.client import GovernanceClient
from lumenova_beacon.tracing.trace import get_current_span, get_current_trace_id
from lumenova_beacon.utils.client_helpers import resolve_user_attr


try:
    from langchain_core.tools import BaseTool as _LangChainBaseTool
except ImportError:
    _LangChainBaseTool = None

logger = logging.getLogger(__name__)

F = TypeVar('F', bound=Callable[..., Any])

_DEFAULT_HOOKS = frozenset({'pre_tool', 'post_tool', 'pre_llm', 'post_llm'})
_DEFAULT_STATE_MAX_BYTES = 32 * 1024
_GOVERNED_SENTINEL = '__beacon_governed__'


def _make_invocation_context_resolver(
    session_id: str | None,
    environment: str | None,
    metadata: dict[str, Any] | None,
    agent_id: str | None,
    agent_name: str | None,
    include_state: bool,
    state_filter: Callable[[dict[str, Any]], dict[str, Any]] | None,
    state_max_bytes: int,
) -> Callable[[], tuple[GovernanceClient, dict[str, Any], dict[str, Any]]]:
    """Create a closure that resolves client, source, and context at invocation time."""

    def _resolve() -> tuple[GovernanceClient, dict[str, Any], dict[str, Any]]:
        from lumenova_beacon.core.client import get_client

        client = GovernanceClient()
        beacon_client = get_client()
        resolved_session_id = session_id if session_id is not None else beacon_client.config.session_id
        resolved_environment = environment if environment is not None else beacon_client.config.environment
        source = _build_source(agent_id, agent_name)
        context = _build_context(
            resolved_session_id, resolved_environment, metadata,
            user_id=resolve_user_attr(None, beacon_client.config.user_id, metadata, "user_id"),
            user_email=resolve_user_attr(None, beacon_client.config.user_email, metadata, "user_email"),
            user_name=resolve_user_attr(None, beacon_client.config.user_name, metadata, "user_name"),
        )
        if include_state:
            # See `_resolve_active_state` for resolution rationale: the
            # config bridge inside a Runnable scope, local ContextVars
            # only when no scope is active. Tool/LLM run_ids are not in
            # `_chain_parents`, so the bridge path also seeds with
            # parent_run_id.
            handler, run_id, parent_run_id, scope_active = _resolve_active_node()
            if scope_active:
                seeds: tuple[UUID | None, ...] = (run_id, parent_run_id)
            else:
                if handler is None:
                    handler = _active_handler.get()
                seeds = (run_id, _active_node_run_id.get())
            raw_state: dict[str, Any] | None = None
            for seed in seeds:
                raw_state = lookup_state_for(handler, seed)
                if raw_state is not None:
                    break
            scope_detected = (
                (scope_active and handler is not None)
                or any(s is not None for s in seeds)
            )
            if raw_state is not None:
                serialized = serialize_state(raw_state, state_filter, state_max_bytes)
                if serialized is not None:
                    context['state'] = serialized
                elif scope_detected:
                    context['state_unavailable'] = True
            elif scope_detected:
                # A node was apparently active but state didn't resolve
                # (bridge regression, walk-cap, multi-handler skew).
                # Surface a marker so OPA policies can fail-closed
                # rather than negate against an absent ref.
                context['state_unavailable'] = True
                logger.debug(
                    'governance(include_state=True): scope detected but no '
                    'state resolved (scope_active=%s, run_id=%s, '
                    'parent_run_id=%s, local_node_run_id=%s); shipping '
                    'context with state_unavailable=True',
                    scope_active, run_id, parent_run_id,
                    _active_node_run_id.get(),
                )
        return client, source, context

    return _resolve


def _wrap_langchain_tool(
    tool_instance: Any,
    func_name: str,
    pre_hook_name: str,
    post_hook_name: str,
    hooks: set[str],
    type_: str,
    stack_ids: list[str] | None,
    tags: list[str] | None,
    fail_open: bool,
    timeout: float | None,
    result_parser: Callable[[dict[str, Any]], bool] | None,
    resolve_ctx: Callable[[], tuple[GovernanceClient, dict[str, Any], dict[str, Any]]],
) -> Any:
    """Wrap a LangChain ``BaseTool``'s inner func/coroutine with governance checks.

    Replaces ``tool_instance.func`` and/or ``tool_instance.coroutine`` with
    governed wrappers while preserving the tool's identity and metadata.
    """
    if getattr(tool_instance, _GOVERNED_SENTINEL, False):
        logger.debug(
            '@governance applied to LangChain tool %r is a no-op: '
            'already governed.',
            getattr(tool_instance, 'name', '(unknown)'),
        )
        return tool_instance

    original_func = getattr(tool_instance, 'func', None)
    original_coroutine = getattr(tool_instance, 'coroutine', None)

    if original_func is None and original_coroutine is None:
        raise GovernanceConfigurationError(
            f'@governance applied to LangChain tool '
            f'{getattr(tool_instance, "name", "(unknown)")!r} but neither '
            f'func nor coroutine is set. Custom BaseTool subclasses that '
            f'override _run/_arun directly are not supported by the '
            f'@governance decorator — apply @governance to the inner '
            f'function before building the BaseTool, or use '
            f'BeaconLangGraphGovernanceHandler.wrap() with a tool that '
            f'exposes a func/coroutine.'
        )

    if original_func is not None:
        @functools.wraps(original_func)
        def governed_func(*args: Any, **kwargs: Any) -> Any:
            client, source, context = resolve_ctx()
            call_kwargs = kwargs

            if pre_hook_name in hooks:
                extra: dict[str, Any] = {
                    type_: {'name': func_name, 'parameters': dict(call_kwargs)},
                    'source': source,
                    'context': context,
                }
                trace_id, span_id = _get_trace_context()
                resp = evaluate_or_fail_open(
                    client, 'pre', type_,
                    stack_ids, tags, extra, timeout, fail_open,
                    trace_id=trace_id, span_id=span_id,
                )
                enforce(resp, 'pre', f"{type_} '{func_name}'", result_parser)
                outcome = parse_outcome(resp, result_parser)
                if outcome.replacement is not None:
                    call_kwargs = _apply_pre_replacement(
                        type_, call_kwargs, outcome.replacement, func_name,
                        target=outcome.target,
                    )

            result = original_func(*args, **call_kwargs)

            if post_hook_name in hooks:
                post_extra: dict[str, Any] = {
                    type_: {
                        'name': func_name,
                        'parameters': dict(call_kwargs),
                        'output': truncate(str(result)),
                    },
                    'source': source,
                    'context': context,
                }
                trace_id, span_id = _get_trace_context()
                resp = evaluate_or_fail_open(
                    client, 'post', type_,
                    stack_ids, tags, post_extra, timeout, fail_open,
                    trace_id=trace_id, span_id=span_id,
                )
                enforce(resp, 'post', f"{type_} '{func_name}'", result_parser)
                outcome = parse_outcome(resp, result_parser)
                if outcome.replacement is not None:
                    result = _apply_post_replacement(type_, result, outcome.replacement)

            return result

        setattr(governed_func, _GOVERNED_SENTINEL, True)
        tool_instance.func = governed_func

    if original_coroutine is not None:
        @functools.wraps(original_coroutine)
        async def governed_coroutine(*args: Any, **kwargs: Any) -> Any:
            client, source, context = resolve_ctx()
            call_kwargs = kwargs

            if pre_hook_name in hooks:
                extra: dict[str, Any] = {
                    type_: {'name': func_name, 'parameters': dict(call_kwargs)},
                    'source': source,
                    'context': context,
                }
                trace_id, span_id = _get_trace_context()
                resp = await aevaluate_or_fail_open(
                    client, 'pre', type_,
                    stack_ids, tags, extra, timeout, fail_open,
                    trace_id=trace_id, span_id=span_id,
                )
                enforce(resp, 'pre', f"{type_} '{func_name}'", result_parser)
                outcome = parse_outcome(resp, result_parser)
                if outcome.replacement is not None:
                    call_kwargs = _apply_pre_replacement(
                        type_, call_kwargs, outcome.replacement, func_name,
                        target=outcome.target,
                    )

            result = await original_coroutine(*args, **call_kwargs)

            if post_hook_name in hooks:
                post_extra: dict[str, Any] = {
                    type_: {
                        'name': func_name,
                        'parameters': dict(call_kwargs),
                        'output': truncate(str(result)),
                    },
                    'source': source,
                    'context': context,
                }
                trace_id, span_id = _get_trace_context()
                resp = await aevaluate_or_fail_open(
                    client, 'post', type_,
                    stack_ids, tags, post_extra, timeout, fail_open,
                    trace_id=trace_id, span_id=span_id,
                )
                enforce(resp, 'post', f"{type_} '{func_name}'", result_parser)
                outcome = parse_outcome(resp, result_parser)
                if outcome.replacement is not None:
                    result = _apply_post_replacement(type_, result, outcome.replacement)

            return result

        setattr(governed_coroutine, _GOVERNED_SENTINEL, True)
        tool_instance.coroutine = governed_coroutine

    try:
        object.__setattr__(tool_instance, _GOVERNED_SENTINEL, True)
    except (AttributeError, TypeError) as exc:
        # Some BaseTool subclasses block extra attribute assignment; the
        # per-callable sentinels above are the fallback. Log so a second
        # @governance won't silently double-evaluate when func/coroutine
        # gets swapped back to an unsentinelled callable.
        logger.debug(
            '@governance(%r): could not stamp instance sentinel '
            '(%s: %s); idempotency relies on per-callable sentinel.',
            getattr(tool_instance, 'name', '(unknown)'),
            type(exc).__name__, exc,
        )

    return tool_instance


def _apply_pre_replacement(
    type_: str,
    kwargs: dict[str, Any],
    replacement: str,
    tool_name: str,
    target: str | None = None,
) -> dict[str, Any]:
    """Apply pre-phase reinjection per type.

    For ``type_='llm'`` with a ``messages`` kwarg, substitution targets
    the last human message and ``target`` is ignored (the deterministic
    site wins). Otherwise — both ``type_='tool'`` and ``type_='llm'``
    without a ``messages`` kwarg — delegates to
    :func:`apply_tool_kwargs_replacement`, which uses ``target`` to pick
    the kwarg to overwrite (raising on mismatch) and falls back to the
    single-string-kwarg heuristic when ``target is None``.
    """
    if type_ == 'llm' and 'messages' in kwargs:
        new = dict(kwargs)
        new['messages'] = apply_llm_messages_replacement(kwargs['messages'], replacement)
        return new
    return apply_tool_kwargs_replacement(
        kwargs, replacement, tool_name=tool_name, target=target,
    )


def _apply_post_replacement(type_: str, result: Any, replacement: str) -> Any:
    """Apply post-phase reinjection per type."""
    if type_ == 'llm':
        return apply_llm_return_replacement(result, replacement)
    return apply_tool_return_replacement(result, replacement)


def _get_trace_context() -> tuple[str | None, str | None]:
    """Read current trace_id and span_id from ContextVars."""
    trace_id = get_current_trace_id()
    span = get_current_span()
    return trace_id, span.span_id if span is not None else None


def _build_source(
    agent_id: str | None,
    agent_name: str | None,
) -> dict[str, Any]:
    """Build the ``input.source`` dict."""
    source: dict[str, Any] = {'sdk_version': get_sdk_version()}
    if agent_id:
        source['agent_id'] = agent_id
    if agent_name:
        source['agent_name'] = agent_name
    return source


def _build_context(
    session_id: str | None,
    environment: str | None,
    metadata: dict[str, Any] | None,
    user_id: str | None = None,
    user_email: str | None = None,
    user_name: str | None = None,
) -> dict[str, Any]:
    """Build the ``input.context`` dict."""
    ctx: dict[str, Any] = {}
    if session_id:
        ctx['session_id'] = session_id
    if environment:
        ctx['environment'] = environment
    if user_id:
        ctx['user_id'] = user_id
    if user_email:
        ctx['user_email'] = user_email
    if user_name:
        ctx['user_name'] = user_name
    if metadata:
        ctx['metadata'] = metadata
    return ctx


# Type overloads for proper type hints in both usage patterns.
@overload
def governance(_func: F) -> F: ...


@overload
def governance(
    _func: None = None,
    *,
    name: str | None = None,
    type_: str = 'tool',
    stack_ids: list[str] | None = None,
    tags: list[str] | None = None,
    fail_open: bool = True,
    enabled_hooks: set[str] | None = None,
    result_parser: Callable[[dict[str, Any]], bool] | None = None,
    timeout: float | None = None,
    agent_id: str | None = None,
    agent_name: str | None = None,
    session_id: str | None = None,
    environment: str | None = None,
    metadata: dict[str, Any] | None = None,
    include_state: bool = True,
    state_filter: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    state_max_bytes: int = _DEFAULT_STATE_MAX_BYTES,
) -> Callable[[F], F]: ...


def governance(
    _func: Callable | None = None,
    *,
    name: str | None = None,
    type_: str = 'tool',
    stack_ids: list[str] | None = None,
    tags: list[str] | None = None,
    fail_open: bool = True,
    enabled_hooks: set[str] | None = None,
    result_parser: Callable[[dict[str, Any]], bool] | None = None,
    timeout: float | None = None,
    agent_id: str | None = None,
    agent_name: str | None = None,
    session_id: str | None = None,
    environment: str | None = None,
    metadata: dict[str, Any] | None = None,
    include_state: bool = True,
    state_filter: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    state_max_bytes: int = _DEFAULT_STATE_MAX_BYTES,
) -> Callable[[F], F] | F:
    """Decorator to enforce governance policies on function calls.

    Evaluates governance policies before and/or after the decorated function
    executes.  Raises
    :class:`~lumenova_beacon.exceptions.GovernanceViolationError` if a
    policy blocks the action.

    This decorator supports three usage patterns:

    - ``@governance`` — bare decorator (no parentheses)
    - ``@governance()`` — empty parentheses
    - ``@governance(stack_ids=['s1'], ...)`` — with configuration

    When decorating a LangChain ``@tool``-decorated function (a ``BaseTool``
    instance), governance wrapping is applied to the tool's inner function
    while preserving the tool's identity.  The tool remains a valid
    ``BaseTool`` recognised by LangChain agents::

        @governance(stack_ids=['my-stack'])
        @tool
        def search_db(query: str) -> str:
            \"\"\"Search the database.\"\"\"
            ...

    Args:
        _func: The function being decorated (when used without parentheses).
        name: Custom name sent to the governance API.  Defaults to the
            decorated function's ``__name__``, or the tool's ``name``
            attribute for LangChain tools.
        type_: ``'tool'`` (default) or ``'llm'``.  Determines the payload
            shape and which ``enabled_hooks`` keys apply.
        stack_ids: Explicit policy stack IDs.  At least one of ``stack_ids``
            or ``tags`` must be provided.
        tags: Tag-based policy stack discovery.
        fail_open: Allow the action when the governance API is unreachable.
        enabled_hooks: Which hooks to evaluate.  Relevant keys depend on
            ``type_``: ``'pre_tool'``/``'post_tool'`` for tools,
            ``'pre_llm'``/``'post_llm'`` for LLM calls.
        result_parser: Custom ``(result_dict) -> bool`` parser.
        timeout: Override request timeout in seconds.
        agent_id: Agent identifier, included in ``input.source``.
        agent_name: Human-readable agent name, included in ``input.source``.
        session_id: Override session ID. Defaults to ``BeaconClient.config.session_id``.
        environment: Override environment. Defaults to ``BeaconClient.config.environment``.
        metadata: Custom metadata included in ``input.context.metadata``.
        include_state: When ``True`` (default), include the enclosing
            LangGraph node's state as ``input.context.state`` on each
            evaluation. Resolved from a
            :class:`~lumenova_beacon.governance.integrations.langchain.BeaconLangGraphGovernanceHandler`
            registered for the current async context — the decorator
            cannot capture state on its own. No-op when no such handler
            is active.
        state_filter: Optional ``(state_dict) -> dict`` callable applied
            before serialization. Use it to redact or whitelist fields.
        state_max_bytes: Cap on the JSON-serialized state size. Default
            32 KiB. When exceeded, a truncation marker replaces the value.

    Returns:
        The decorated function (or a decorator if called with arguments).
    """
    hooks = set(enabled_hooks) if enabled_hooks is not None else set(_DEFAULT_HOOKS)

    resolve_ctx = _make_invocation_context_resolver(
        session_id, environment, metadata, agent_id, agent_name,
        include_state, state_filter, state_max_bytes,
    )

    def decorator(func: F) -> F:
        # Short-circuit double-decoration on plain functions and tools alike.
        if getattr(func, _GOVERNED_SENTINEL, False):
            logger.debug(
                '@governance applied to %r is a no-op: already governed.',
                getattr(func, '__name__', repr(func)),
            )
            return func

        # --- LangChain tool detection ---
        if _LangChainBaseTool is not None and isinstance(func, _LangChainBaseTool):
            tool_name = name or func.name
            return cast(F, _wrap_langchain_tool(
                tool_instance=func,
                func_name=tool_name,
                pre_hook_name=f'pre_{type_}',
                post_hook_name=f'post_{type_}',
                hooks=hooks,
                type_=type_,
                stack_ids=stack_ids,
                tags=tags,
                fail_open=fail_open,
                timeout=timeout,
                result_parser=result_parser,
                resolve_ctx=resolve_ctx,
            ))

        # --- Plain function path ---
        func_name = name or func.__name__
        pre_hook_name = f'pre_{type_}'
        post_hook_name = f'post_{type_}'

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            client, source, context = resolve_ctx()
            call_kwargs = kwargs

            # Pre-execution check.
            if pre_hook_name in hooks:
                extra: dict[str, Any] = {
                    type_: {'name': func_name, 'parameters': dict(call_kwargs)},
                    'source': source,
                    'context': context,
                }
                trace_id, span_id = _get_trace_context()
                resp = evaluate_or_fail_open(
                    client, 'pre', type_,
                    stack_ids, tags, extra, timeout, fail_open,
                    trace_id=trace_id, span_id=span_id,
                )
                enforce(resp, 'pre', f"{type_} '{func_name}'", result_parser)
                outcome = parse_outcome(resp, result_parser)
                if outcome.replacement is not None:
                    call_kwargs = _apply_pre_replacement(
                        type_, call_kwargs, outcome.replacement, func_name,
                        target=outcome.target,
                    )

            result = func(*args, **call_kwargs)

            # Post-execution check.
            if post_hook_name in hooks:
                post_extra: dict[str, Any] = {
                    type_: {
                        'name': func_name,
                        'parameters': dict(call_kwargs),
                        'output': truncate(str(result)),
                    },
                    'source': source,
                    'context': context,
                }
                trace_id, span_id = _get_trace_context()
                resp = evaluate_or_fail_open(
                    client, 'post', type_,
                    stack_ids, tags, post_extra, timeout, fail_open,
                    trace_id=trace_id, span_id=span_id,
                )
                enforce(resp, 'post', f"{type_} '{func_name}'", result_parser)
                outcome = parse_outcome(resp, result_parser)
                if outcome.replacement is not None:
                    result = _apply_post_replacement(type_, result, outcome.replacement)

            return result

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            client, source, context = resolve_ctx()
            call_kwargs = kwargs

            # Pre-execution check.
            if pre_hook_name in hooks:
                extra: dict[str, Any] = {
                    type_: {'name': func_name, 'parameters': dict(call_kwargs)},
                    'source': source,
                    'context': context,
                }
                trace_id, span_id = _get_trace_context()
                resp = await aevaluate_or_fail_open(
                    client, 'pre', type_,
                    stack_ids, tags, extra, timeout, fail_open,
                    trace_id=trace_id, span_id=span_id,
                )
                enforce(resp, 'pre', f"{type_} '{func_name}'", result_parser)
                outcome = parse_outcome(resp, result_parser)
                if outcome.replacement is not None:
                    call_kwargs = _apply_pre_replacement(
                        type_, call_kwargs, outcome.replacement, func_name,
                        target=outcome.target,
                    )

            result = await func(*args, **call_kwargs)

            # Post-execution check.
            if post_hook_name in hooks:
                post_extra: dict[str, Any] = {
                    type_: {
                        'name': func_name,
                        'parameters': dict(call_kwargs),
                        'output': truncate(str(result)),
                    },
                    'source': source,
                    'context': context,
                }
                trace_id, span_id = _get_trace_context()
                resp = await aevaluate_or_fail_open(
                    client, 'post', type_,
                    stack_ids, tags, post_extra, timeout, fail_open,
                    trace_id=trace_id, span_id=span_id,
                )
                enforce(resp, 'post', f"{type_} '{func_name}'", result_parser)
                outcome = parse_outcome(resp, result_parser)
                if outcome.replacement is not None:
                    result = _apply_post_replacement(type_, result, outcome.replacement)

            return result

        if inspect.iscoroutinefunction(func):
            setattr(async_wrapper, _GOVERNED_SENTINEL, True)
            return cast(F, async_wrapper)
        setattr(sync_wrapper, _GOVERNED_SENTINEL, True)
        return cast(F, sync_wrapper)

    # Detect how the decorator is being used.
    if _func is None:
        # Called with parentheses: @governance() or @governance(stack_ids=[...])
        return decorator
    else:
        # Called without parentheses: @governance
        return decorator(cast(F, _func))
