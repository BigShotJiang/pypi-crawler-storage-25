"""Shared content-reinjection helpers used by governance surfaces.

The three SDK surfaces that can reinject policy-sanitized content into
agent execution — the ``@governance`` decorator, the callback handler's
``wrap(...)`` method, and the LangGraph integration — share the same
rules for how a policy's ``output`` string is substituted for the
original tool arguments, tool output, or LLM content. That substitution
logic lives here so the rules cannot diverge across surfaces.

The API contract for ``output`` is a single string. Agent tools and LLM
calls take structured arguments and return structured values, so the
SDK needs a deterministic recipe for turning that string into a
replacement at each hook point. When a policy returns ``output`` but the
shape of the call does not allow substitution at any of the rules below,
the helpers raise :class:`GovernanceReinjectionError` to fail closed
rather than silently let unsanitized content through. Rules:

- **Tool pre-phase (kwargs replacement):**
    * If the policy declared an explicit ``output_target`` (surfaced as
      ``target`` on the parsed outcome) and that name maps to a string
      kwarg, replace that kwarg's value with the policy output. This is
      the deterministic path for multi-parameter tools.
    * Else if the tool was invoked with exactly one kwarg whose value is
      a string, replace that kwarg's value with the policy output.
    * Else raise :class:`GovernanceReinjectionError`. An explicit target
      that does not match a string kwarg fails closed (rather than
      silently falling back to the heuristic) — falling back would risk
      rewriting a different field while the sensitive one passes through.
      Multi-string-kwarg calls without ``output_target`` are also
      ambiguous: policies must disambiguate.

- **Tool post-phase (return value replacement):**
    * If the return value is a string, substitute the policy output.
    * If the return value is a Pydantic-style object with a non-None
      ``content`` attribute and a ``model_copy`` method (e.g. a
      LangChain ``ToolMessage``), return a copy with ``content``
      swapped while preserving the object's other fields. Objects that
      define ``content=None`` are not eligible — the substitution
      target is the existing content value, and ``None`` is treated as
      "no content surface to replace."
    * Otherwise raise :class:`GovernanceReinjectionError`.

- **LLM pre-phase (messages replacement):**
    * Replace the last human message's ``content`` with the policy
      output. Supports ``str``, a single ``BaseMessage``, a list of
      ``BaseMessage``, or LangChain's chat-batching list-of-lists shape.
    * If no human message exists in the structure, raise
      :class:`GovernanceReinjectionError`.

- **LLM post-phase (AIMessage replacement):**
    * Swap ``AIMessage.content`` while preserving ``tool_calls``,
      ``usage_metadata`` and other metadata.
    * If the result is neither a string nor a Pydantic-style message,
      raise :class:`GovernanceReinjectionError`.
"""

from __future__ import annotations

import logging

from typing import Any

from lumenova_beacon.exceptions import GovernanceReinjectionError


logger = logging.getLogger(__name__)


def apply_tool_kwargs_replacement(
    kwargs: dict[str, Any],
    replacement: str,
    *,
    tool_name: str | None = None,
    target: str | None = None,
) -> dict[str, Any]:
    """Return a new kwargs dict with ``replacement`` substituted.

    Follows the tool pre-phase rules from the module docstring. Always
    returns a new dict so callers can pass it forward without aliasing
    the original. ``target`` is the policy-declared kwarg name from
    ``response['output_target']``; when provided and matching a string
    kwarg it takes priority over the heuristic rules.
    """
    new_kwargs = dict(kwargs)

    if target is not None:
        if target in new_kwargs and isinstance(new_kwargs[target], str):
            new_kwargs[target] = replacement
            return new_kwargs
        # The policy explicitly named a kwarg; falling back to the heuristic
        # would risk rewriting a different field while leaving the one the
        # author meant to replace untouched. That defeats the purpose of
        # output_target — fail closed instead so the misconfiguration is
        # visible at runtime.
        raise GovernanceReinjectionError(
            f'Governance reinjection target {target!r} is not a string '
            f'kwarg of tool {tool_name or "(unknown)"!r} '
            f'(kwargs={sorted(new_kwargs.keys())}). Either correct the '
            f'policy\'s `output_target` to name a string kwarg, or remove '
            f'`output_target` to fall back to the single-string-kwarg '
            f'heuristic.'
        )

    string_keys = [k for k, v in new_kwargs.items() if isinstance(v, str)]
    if len(string_keys) == 1:
        new_kwargs[string_keys[0]] = replacement
        return new_kwargs

    if len(string_keys) > 1:
        # Picking a key by convention (e.g. always 'input') would silently
        # rewrite the wrong field when the policy intended a different one,
        # leaving the sensitive kwarg unsubstituted. Force the policy to be
        # explicit via output_target.
        raise GovernanceReinjectionError(
            f'Governance reinjection cannot disambiguate among multiple '
            f'string kwargs (tool={tool_name or "(unknown)"!r} '
            f'string_kwargs={sorted(string_keys)}): policy must declare '
            f'`output_target` to choose which one to substitute.'
        )

    raise GovernanceReinjectionError(
        f'Governance reinjection could not map policy output onto tool '
        f'kwargs (tool={tool_name or "(unknown)"!r} kwargs={sorted(new_kwargs.keys())}): '
        f'no string parameter to substitute. Have the tool expose a '
        f'string argument the policy can substitute into.'
    )


def apply_tool_return_replacement(
    result: Any,
    replacement: str,
) -> Any:
    """Return a replacement for a tool's output per the post-phase rules."""
    if isinstance(result, str):
        return replacement

    content_attr = getattr(result, 'content', None)
    if content_attr is not None and hasattr(result, 'model_copy'):
        try:
            return result.model_copy(update={'content': replacement})
        except (TypeError, ValueError) as exc:
            # Pydantic raises ValidationError (a ValueError subclass) when
            # the substituted content fails the model's field validators;
            # frozen instances or required-field issues surface as TypeError.
            # Returning a bare string instead would change the tool's return
            # type and break downstream LangGraph consumers — surface the
            # error so the misconfiguration is visible.
            raise GovernanceReinjectionError(
                f'Governance reinjection could not copy tool result of type '
                f'{type(result).__name__}: {exc}. Either relax the model\'s '
                f'validators or have the policy emit the replacement on a '
                f'string-returning tool.'
            ) from exc

    raise GovernanceReinjectionError(
        f'Governance reinjection cannot apply a string replacement to a '
        f'tool result of type {type(result).__name__}: the value is neither '
        f'a string nor a Pydantic-style object with a `content` attribute. '
        f'Have the tool return a string or a `ToolMessage`-like object.'
    )


def apply_llm_messages_replacement(
    messages: Any,
    replacement: str,
) -> Any:
    """Replace the last human message's content with ``replacement``.

    ``messages`` may be a list of ``BaseMessage`` objects, a list of
    lists (LangChain's chat batching shape), or a single string/BaseMessage.
    Returns a new structure of the same shape; raises
    :class:`GovernanceReinjectionError` when no human message is present
    in the structure.
    """
    try:
        from langchain_core.messages import BaseMessage
    except ImportError as exc:
        # The integration module raises ImportError at import time when
        # langchain-core is missing, so reaching this branch means a
        # partial/broken install rather than the documented "decorator on
        # a plain function" case. Fail closed.
        raise GovernanceReinjectionError(
            'langchain-core is required to reinject LLM prompts but is '
            'unavailable; install lumenova-beacon[langchain] or pin a '
            'compatible langchain-core.'
        ) from exc

    if isinstance(messages, str):
        return replacement

    if isinstance(messages, BaseMessage):
        if messages.type == 'human':
            return messages.model_copy(update={'content': replacement})
        raise GovernanceReinjectionError(
            f'Governance reinjection found no human message to replace '
            f'(message type={messages.type!r}); prompt cannot be substituted.'
        )

    if not isinstance(messages, list) or not messages:
        raise GovernanceReinjectionError(
            'Governance reinjection found no human message to replace in '
            'pre-LLM messages: input is empty or not a message list.'
        )

    first = messages[0]
    if isinstance(first, list):
        if not first:
            raise GovernanceReinjectionError(
                'Governance reinjection found an empty inner message batch; '
                'cannot substitute prompt.'
            )
        new_first = _replace_last_human(first, replacement)
        return [new_first, *messages[1:]]

    return _replace_last_human(messages, replacement)


def _replace_last_human(messages: list[Any], replacement: str) -> list[Any]:
    try:
        from langchain_core.messages import BaseMessage
    except ImportError as exc:
        raise GovernanceReinjectionError(
            'langchain-core is required to reinject LLM prompts but is '
            'unavailable.'
        ) from exc

    for idx in range(len(messages) - 1, -1, -1):
        msg = messages[idx]
        if isinstance(msg, BaseMessage) and msg.type == 'human':
            new_msg = msg.model_copy(update={'content': replacement})
            return [*messages[:idx], new_msg, *messages[idx + 1:]]

    raise GovernanceReinjectionError(
        'Governance reinjection found no human message to replace in '
        'pre-LLM messages; prompt cannot be substituted. Ensure the call '
        'carries a HumanMessage or use a tool-targeted policy instead.'
    )


def apply_llm_return_replacement(
    result: Any,
    replacement: str,
) -> Any:
    """Replace an AIMessage result's ``content`` while preserving metadata."""
    if isinstance(result, str):
        return replacement

    try:
        from langchain_core.messages import BaseMessage
    except ImportError as exc:
        raise GovernanceReinjectionError(
            'langchain-core is required to reinject non-string LLM results '
            'but is unavailable.'
        ) from exc

    if isinstance(result, BaseMessage):
        try:
            return result.model_copy(update={'content': replacement})
        except (TypeError, ValueError) as exc:
            raise GovernanceReinjectionError(
                f'Governance reinjection could not copy LLM message of type '
                f'{type(result).__name__}: {exc}.'
            ) from exc

    content_attr = getattr(result, 'content', None)
    if content_attr is not None and hasattr(result, 'model_copy'):
        try:
            return result.model_copy(update={'content': replacement})
        except (TypeError, ValueError) as exc:
            raise GovernanceReinjectionError(
                f'Governance reinjection could not copy LLM result of type '
                f'{type(result).__name__}: {exc}.'
            ) from exc

    raise GovernanceReinjectionError(
        f'Governance reinjection cannot apply a string replacement to an '
        f'LLM result of type {type(result).__name__}: the value is neither '
        f'a string nor a Pydantic-style message with a `content` attribute.'
    )
