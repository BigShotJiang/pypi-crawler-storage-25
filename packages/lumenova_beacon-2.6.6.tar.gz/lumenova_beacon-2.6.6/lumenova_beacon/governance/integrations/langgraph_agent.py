"""High-level LangGraph wrapper with native governance event handling.

:class:`BeaconLangGraphAgent` owns a
:class:`~lumenova_beacon.tracing.integrations.langchain.BeaconLangGraphConfig`
internally and exposes the six standard LangGraph entry points
(``invoke`` / ``stream`` / ``stream_events`` + async equivalents) so
callers do not have to thread ``config=`` through every call site.
``stream_events`` requires ``langgraph>=1.1`` — earlier versions only
implement the async variant and a call into the sync method will
``AttributeError`` from the underlying graph.

The wrapper catches :class:`GovernanceViolationError` at the outer
boundary and dispatches based on ``violation_mode``:

* ``'raise'`` — re-raise as-is (default; matches the bare
  ``BeaconLangGraphConfig`` behaviour).
* ``'state'`` — append phase-appropriate messages to the agent state
  via the checkpointer and return / yield gracefully.  Tool-phase
  blocks emit one ``ToolMessage`` per unanswered ``tool_call_id`` to
  preserve the OpenAI conversation invariant: the blocked id carries
  the policy message, sibling ids in the same batch carry a skip
  marker.
* ``'emit'`` — yield a synthesised ``on_custom_event`` (LangChain
  ``astream_events`` v2 shape) on streaming entry points.  On
  ``invoke`` / ``ainvoke`` (no event stream): when the violation
  propagates out of ``graph.invoke``, the wrapper falls back to
  ``'state'`` reconciliation; when ``ToolNode(handle_tool_errors=True)``
  swallowed it (post-hoc detection), the wrapper logs at WARN and
  leaves :attr:`last_violation` set rather than duplicating the
  ``ToolMessage`` ToolNode already wrote.

Only :class:`GovernanceViolationError` is intercepted.  Configuration,
reinjection, validation, and transport errors always propagate.
"""

from __future__ import annotations

import logging
import uuid

from collections.abc import AsyncIterator, Iterator
from typing import TYPE_CHECKING, Any, Literal

from lumenova_beacon.exceptions import GovernanceViolationError


try:
    from langchain_core.messages import AIMessage, BaseMessage, ToolMessage
except ImportError as exc:  # pragma: no cover - import guard
    raise ImportError(
        'langchain-core is required for BeaconLangGraphAgent. '
        'Install it with: pip install langchain-core'
    ) from exc


if TYPE_CHECKING:
    from lumenova_beacon.governance.config import GovernanceConfig
    from lumenova_beacon.tracing.integrations.langchain import BeaconLangGraphConfig


logger = logging.getLogger(__name__)


_VIOLATION_EVENT_NAME = 'beacon.governance.violation'
_SIBLING_SKIP_TEMPLATE = (
    'Skipped: another tool call in this batch was blocked by governance policy {policies}.'
)
# Bounds the recursive walk through stream chunks / event payloads when we
# search for BaseMessage instances. LangGraph state in practice nests only a
# few levels (node_name → state_diff → message-list); 32 leaves comfortable
# headroom while guarding against pathological / cyclic user state.
_CHUNK_WALK_MAX_DEPTH = 32


class BeaconLangGraphAgent:
    """LangGraph wrapper with native governance event handling.

    Wraps a compiled LangGraph and the matching
    :class:`BeaconLangGraphConfig` so callers can invoke / stream
    without remembering to pass ``config=``, and pick how
    :class:`GovernanceViolationError` is surfaced.

    Args:
        graph: Compiled LangGraph (must have a checkpointer — required by
            :class:`BeaconLangGraphConfig`).
        thread_id: LangGraph thread ID for checkpointing.
        governance: Governance configuration. Required — without it the
            wrapper has nothing to do.
        violation_mode: How to surface ``GovernanceViolationError``.

            * ``'raise'`` (default) — re-raise to the caller.
            * ``'state'`` — append phase-appropriate messages to state via
              the checkpointer and return / yield cleanly.
            * ``'emit'`` — yield a synthesised custom event from streaming
              entry points; falls back to ``'state'`` for ``invoke`` /
              ``ainvoke`` which have no event stream.
        violation_state_key: State key the wrapper appends messages to in
            ``'state'`` / ``'emit'`` modes.  Defaults to ``'messages'`` —
            override when the agent state uses a different field name.
        agent_name: Forwarded to :class:`BeaconLangGraphConfig`.
        session_id: Forwarded to :class:`BeaconLangGraphConfig`.
        user_email: Forwarded to :class:`BeaconLangGraphConfig`.
        user_name: Forwarded to :class:`BeaconLangGraphConfig`.
        user_id: Forwarded to :class:`BeaconLangGraphConfig`.
        environment: Forwarded to :class:`BeaconLangGraphConfig`.
        metadata: Forwarded to :class:`BeaconLangGraphConfig`.
        autodetect_handoffs: Forwarded to :class:`BeaconLangGraphConfig`.
        record_stacktrace: Forwarded to :class:`BeaconLangGraphConfig`.

    Example::

        agent = BeaconLangGraphAgent(
            graph=app,
            thread_id='t1',
            governance=GovernanceConfig(stack_ids=['my-stack']),
            violation_mode='state',
        )
        result = agent.invoke({'messages': [HumanMessage('Hi')]})
        # On a tool-phase violation, ``result['messages']`` ends with
        # synthetic ToolMessages instead of raising.

    Concurrency: the wrapper shares a single
    :class:`BeaconLangGraphGovernanceHandler` across all calls on this
    instance, and that handler's ``last_violation`` / ``violation_count``
    are single-slot.  Concurrent ``ainvoke`` / ``astream`` calls against
    the same wrapper can see each other's snapshots — create one
    wrapper per request if concurrent governance state needs to be
    distinguished.
    """

    def __init__(
        self,
        graph: Any,
        thread_id: str,
        *,
        governance: 'GovernanceConfig',
        violation_mode: Literal['raise', 'state', 'emit'] = 'raise',
        violation_state_key: str = 'messages',
        agent_name: str | None = None,
        session_id: str | None = None,
        user_email: str | None = None,
        user_name: str | None = None,
        user_id: str | None = None,
        environment: str | None = None,
        metadata: dict[str, Any] | None = None,
        autodetect_handoffs: bool = False,
        record_stacktrace: bool | None = None,
    ):
        if violation_mode not in ('raise', 'state', 'emit'):
            raise ValueError(
                f"violation_mode must be one of 'raise', 'state', 'emit'; got {violation_mode!r}"
            )
        if governance is None:
            raise ValueError(
                'BeaconLangGraphAgent requires a GovernanceConfig — without it '
                'the wrapper has nothing to enforce and would silently pass every '
                'call through. Pass governance=GovernanceConfig(stack_ids=[...]).'
            )
        if not callable(getattr(graph, 'invoke', None)) or not callable(
            getattr(graph, 'ainvoke', None)
        ):
            raise TypeError(
                'BeaconLangGraphAgent expects a compiled LangGraph (an object '
                'exposing both invoke and ainvoke). '
                f'Got {type(graph).__name__!r} which is missing one of those '
                'methods — pass the result of workflow.compile(...).'
            )

        from lumenova_beacon.tracing.integrations.langchain import (
            BeaconLangGraphConfig,
        )

        self._graph = graph
        self._violation_mode = violation_mode
        self._violation_state_key = violation_state_key
        self._beacon_config = BeaconLangGraphConfig(
            graph=graph,
            thread_id=thread_id,
            agent_name=agent_name,
            session_id=session_id,
            user_email=user_email,
            user_name=user_name,
            user_id=user_id,
            environment=environment,
            metadata=metadata,
            autodetect_handoffs=autodetect_handoffs,
            governance=governance,
            record_stacktrace=record_stacktrace,
        )

    # ------------------------------------------------------------------
    # Escape hatches
    # ------------------------------------------------------------------

    @property
    def beacon_config(self) -> 'BeaconLangGraphConfig':
        """Underlying :class:`BeaconLangGraphConfig` for advanced use."""
        return self._beacon_config

    @property
    def graph(self) -> Any:
        """The compiled LangGraph being wrapped."""
        return self._graph

    @property
    def last_violation(self) -> GovernanceViolationError | None:
        """Most recent :class:`GovernanceViolationError` raised under this wrapper.

        Mirrors :attr:`BeaconLangGraphGovernanceHandler.last_violation` so
        callers can detect violations that did not surface through the
        return value — notably ``emit`` mode on ``invoke`` / ``ainvoke``
        (no event stream) and the ``ToolNode(handle_tool_errors=True)``
        swallow path, where the wrapper logs but does not raise.

        Snapshot the property before the call and compare after; relying
        on identity is more reliable than a count delta because the
        handler instance is shared with anyone holding ``beacon_config``.
        """
        handler = self._beacon_config.governance_handler
        return handler.last_violation if handler is not None else None

    # ------------------------------------------------------------------
    # Sync entry points
    # ------------------------------------------------------------------

    def invoke(self, input: Any, *, config: Any = None, **kwargs: Any) -> Any:
        """Invoke the graph with beacon config attached.

        Surfaces governance violations two ways:

        1. The exception propagates out of ``graph.invoke``
           (``ToolNode(handle_tool_errors=False)``) — caught at the
           ``try/except`` and dispatched per ``violation_mode``.
        2. ``ToolNode(handle_tool_errors=True)`` catches the exception
           and emits its own error ``ToolMessage`` — the wrapper notices
           via a pre/post ``violation_count`` snapshot.  In ``raise``
           mode it re-raises.  In ``state`` and ``emit`` mode the
           wrapper leaves ToolNode's reconciliation in place rather
           than duplicating it; ``emit`` logs at WARN (no event stream
           on ``invoke``/``ainvoke``), ``state`` logs at INFO.
        """
        merged = self._merge_config(self._beacon_config.get_config(), config)
        before = self._violation_count_snapshot()
        try:
            result = self._graph.invoke(input, config=merged, **kwargs)
        except GovernanceViolationError as exc:
            if self._violation_mode == 'raise':
                raise
            messages, persisted = self._reconcile_state_sync(merged, exc)
            if not persisted:
                return {self._violation_state_key: messages}
            try:
                return self._graph.get_state(self._persist_config(merged)).values
            except ValueError as e:
                if 'No checkpointer set' in str(e):
                    return {self._violation_state_key: messages}
                # Surface the original violation, not the read-back failure;
                # the ValueError is preserved as __cause__.
                raise exc from e
        return self._handle_post_hoc(result, merged, before)

    def stream(
        self,
        input: Any,
        *,
        config: Any = None,
        **kwargs: Any,
    ) -> Iterator[Any]:
        """Stream from the graph with beacon config attached.

        Note: in ``violation_mode='emit'``, on a governance block the
        iterator yields the synthesised event dict
        (``{'event': 'on_custom_event', 'name': 'beacon.governance.violation', ...}``)
        alongside the regular state chunks.  Consumers that index into
        ``chunk[<state_key>]`` should branch on ``chunk.get('event')``
        first.  Use :meth:`stream_events` if a pure event stream is
        preferable.
        """
        merged = self._merge_config(self._beacon_config.get_config(), config)
        return self._stream_iter_sync(input, merged, kwargs)

    def stream_events(
        self,
        input: Any,
        *,
        config: Any = None,
        version: str = 'v2',
        **kwargs: Any,
    ) -> Iterator[dict[str, Any]]:
        """Stream LangChain events from the graph with beacon config attached.

        Requires ``langgraph>=1.1`` — the underlying ``Pregel.stream_events``
        method was added in 1.1; on older installs this call propagates an
        ``AttributeError`` from the graph.
        """
        merged = self._merge_config(self._beacon_config.get_config(), config)
        return self._stream_events_iter_sync(input, merged, version, kwargs)

    # ------------------------------------------------------------------
    # Async entry points
    # ------------------------------------------------------------------

    async def ainvoke(
        self,
        input: Any,
        *,
        config: Any = None,
        **kwargs: Any,
    ) -> Any:
        """Async invoke the graph (supports async checkpointers)."""
        merged = self._merge_config(await self._beacon_config.aget_config(), config)
        before = self._violation_count_snapshot()
        try:
            result = await self._graph.ainvoke(input, config=merged, **kwargs)
        except GovernanceViolationError as exc:
            if self._violation_mode == 'raise':
                raise
            messages, persisted = await self._reconcile_state_async(merged, exc)
            if not persisted:
                return {self._violation_state_key: messages}
            try:
                state = await self._graph.aget_state(self._persist_config(merged))
                return state.values
            except ValueError as e:
                if 'No checkpointer set' in str(e):
                    return {self._violation_state_key: messages}
                # Surface the original violation, not the read-back failure;
                # the ValueError is preserved as __cause__.
                raise exc from e
        return self._handle_post_hoc(result, merged, before)

    async def astream(
        self,
        input: Any,
        *,
        config: Any = None,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        """Async stream from the graph.

        Shares the same ``emit``-mode caveat as :meth:`stream`: on a
        violation the iterator yields a synthesised event dict mixed in
        with state chunks.
        """
        merged = self._merge_config(await self._beacon_config.aget_config(), config)
        async for chunk in self._stream_iter_async(input, merged, kwargs):
            yield chunk

    async def astream_events(
        self,
        input: Any,
        *,
        config: Any = None,
        version: str = 'v2',
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """Async stream LangChain events from the graph."""
        merged = self._merge_config(await self._beacon_config.aget_config(), config)
        async for event in self._stream_events_iter_async(input, merged, version, kwargs):
            yield event

    # ------------------------------------------------------------------
    # Streaming helpers (sync)
    # ------------------------------------------------------------------

    def _stream_iter_sync(
        self,
        input: Any,
        config: dict[str, Any],
        kwargs: dict[str, Any],
    ) -> Iterator[Any]:
        before = self._violation_count_snapshot()
        seen: list[BaseMessage] = []
        try:
            for chunk in self._graph.stream(input, config=config, **kwargs):
                seen.extend(self._extract_messages_from_chunk(chunk))
                yield chunk
        except GovernanceViolationError as exc:
            if self._violation_mode == 'raise':
                raise
            if self._violation_mode == 'emit':
                yield self._build_event(exc, config)
            messages, _persisted = self._reconcile_state_sync(config, exc, seen_messages=seen)
            if self._violation_mode == 'state':
                yield {self._violation_state_key: messages}
            return
        # Post-hoc: ToolNode swallowed an in-flight violation.
        exc = self._post_hoc_violation(before)
        if exc is None:
            return
        if self._violation_mode == 'raise':
            raise exc
        if self._violation_mode == 'emit':
            yield self._build_event(exc, config)

    def _stream_events_iter_sync(
        self,
        input: Any,
        config: dict[str, Any],
        version: str,
        kwargs: dict[str, Any],
    ) -> Iterator[dict[str, Any]]:
        before = self._violation_count_snapshot()
        seen: list[BaseMessage] = []
        try:
            for event in self._graph.stream_events(
                input,
                config=config,
                version=version,
                **kwargs,
            ):
                seen.extend(self._extract_messages_from_event(event))
                yield event
        except GovernanceViolationError as exc:
            if self._violation_mode == 'raise':
                raise
            if self._violation_mode == 'emit':
                yield self._build_event(exc, config)
            messages, _persisted = self._reconcile_state_sync(config, exc, seen_messages=seen)
            if self._violation_mode == 'state':
                yield {self._violation_state_key: messages}
            return
        # Post-hoc: ToolNode swallowed an in-flight violation.
        exc = self._post_hoc_violation(before)
        if exc is None:
            return
        if self._violation_mode == 'raise':
            raise exc
        if self._violation_mode == 'emit':
            yield self._build_event(exc, config)

    # ------------------------------------------------------------------
    # Streaming helpers (async)
    # ------------------------------------------------------------------

    async def _stream_iter_async(
        self,
        input: Any,
        config: dict[str, Any],
        kwargs: dict[str, Any],
    ) -> AsyncIterator[Any]:
        before = self._violation_count_snapshot()
        seen: list[BaseMessage] = []
        try:
            async for chunk in self._graph.astream(input, config=config, **kwargs):
                seen.extend(self._extract_messages_from_chunk(chunk))
                yield chunk
        except GovernanceViolationError as exc:
            if self._violation_mode == 'raise':
                raise
            if self._violation_mode == 'emit':
                yield self._build_event(exc, config)
            messages, _persisted = await self._reconcile_state_async(config, exc, seen_messages=seen)
            if self._violation_mode == 'state':
                yield {self._violation_state_key: messages}
            return
        exc = self._post_hoc_violation(before)
        if exc is None:
            return
        if self._violation_mode == 'raise':
            raise exc
        if self._violation_mode == 'emit':
            yield self._build_event(exc, config)

    async def _stream_events_iter_async(
        self,
        input: Any,
        config: dict[str, Any],
        version: str,
        kwargs: dict[str, Any],
    ) -> AsyncIterator[dict[str, Any]]:
        before = self._violation_count_snapshot()
        seen: list[BaseMessage] = []
        try:
            async for event in self._graph.astream_events(
                input,
                config=config,
                version=version,
                **kwargs,
            ):
                seen.extend(self._extract_messages_from_event(event))
                yield event
        except GovernanceViolationError as exc:
            if self._violation_mode == 'raise':
                raise
            if self._violation_mode == 'emit':
                yield self._build_event(exc, config)
            messages, _persisted = await self._reconcile_state_async(config, exc, seen_messages=seen)
            if self._violation_mode == 'state':
                yield {self._violation_state_key: messages}
            return
        exc = self._post_hoc_violation(before)
        if exc is None:
            return
        if self._violation_mode == 'raise':
            raise exc
        if self._violation_mode == 'emit':
            yield self._build_event(exc, config)

    # ------------------------------------------------------------------
    # State reconciliation
    # ------------------------------------------------------------------

    def _reconcile_state_sync(
        self,
        config: dict[str, Any],
        exc: GovernanceViolationError,
        *,
        seen_messages: list[BaseMessage] | None = None,
    ) -> tuple[list[BaseMessage], bool]:
        """Build the reconciliation messages and persist them.

        Returns ``(messages, persisted)``.  ``persisted`` is ``True`` only
        when ``update_state`` succeeded; on a stateless graph or a
        checkpointer write failure it is ``False`` so callers can fall
        back to returning ``messages`` directly instead of reading back
        a state that does not contain them.
        """
        messages = self._build_messages(config, exc, seen_messages=seen_messages)
        if not messages:
            return [], False
        persisted = self._persist_messages_sync(config, messages)
        return messages, persisted

    async def _reconcile_state_async(
        self,
        config: dict[str, Any],
        exc: GovernanceViolationError,
        *,
        seen_messages: list[BaseMessage] | None = None,
    ) -> tuple[list[BaseMessage], bool]:
        messages = await self._abuild_messages(config, exc, seen_messages=seen_messages)
        if not messages:
            return [], False
        persisted = await self._persist_messages_async(config, messages)
        return messages, persisted

    def _persist_messages_sync(
        self,
        config: dict[str, Any],
        messages: list[BaseMessage],
    ) -> bool:
        try:
            self._graph.update_state(
                self._persist_config(config),
                {self._violation_state_key: messages},
            )
            return True
        except ValueError as exc:
            if 'No checkpointer set' in str(exc):
                logger.debug(
                    'BeaconLangGraphAgent: skipping update_state; graph has no checkpointer',
                )
            else:
                logger.warning(
                    'BeaconLangGraphAgent: update_state failed',
                    exc_info=True,
                )
            return False
        except Exception:
            logger.warning(
                'BeaconLangGraphAgent: update_state failed',
                exc_info=True,
            )
            return False

    async def _persist_messages_async(
        self,
        config: dict[str, Any],
        messages: list[BaseMessage],
    ) -> bool:
        try:
            await self._graph.aupdate_state(
                self._persist_config(config),
                {self._violation_state_key: messages},
            )
            return True
        except ValueError as exc:
            if 'No checkpointer set' in str(exc):
                logger.debug(
                    'BeaconLangGraphAgent: skipping aupdate_state; graph has no checkpointer',
                )
            else:
                logger.warning(
                    'BeaconLangGraphAgent: aupdate_state failed',
                    exc_info=True,
                )
            return False
        except Exception:
            logger.warning(
                'BeaconLangGraphAgent: aupdate_state failed',
                exc_info=True,
            )
            return False

    @staticmethod
    def _persist_config(config: dict[str, Any]) -> dict[str, Any]:
        """Return a copy of ``config`` with the tracer + governance callbacks
        stripped.  Used for both ``update_state`` writes and ``get_state``
        reads of the existing checkpoint.

        Why: LangGraph's ``update_state`` fires the configured callback
        chain (``on_chain_start`` / ``on_chain_end`` on a synthetic
        ``LangGraphUpdateState`` runnable).  The Beacon tracer attached
        to the original invoke config would treat that as a fresh root
        span and emit a *second* top-level trace whose only payload is
        the reconciliation write.  Dropping ``callbacks`` (and ``tags``,
        which propagate to those callbacks) keeps the reconciliation
        invisible to the tracer while still using the right ``thread_id``
        to land on the existing checkpoint.  ``get_state`` does not fire
        callbacks, but using the same helper keeps both paths consistent.
        """
        if not isinstance(config, dict):
            return config
        return {k: v for k, v in config.items() if k not in ('callbacks', 'tags')}

    def _read_state_messages(
        self,
        config: dict[str, Any],
    ) -> list[BaseMessage] | None:
        """Return the messages list from the checkpointer.

        Returns ``[]`` for the explicit-empty / stateless cases (graph has
        no checkpointer, state value is not a list).  Returns ``None`` when
        ``graph.get_state`` raises an unexpected error — callers can then
        treat the read as inconclusive instead of assuming an empty state,
        which would otherwise silently route the reconciliation through
        the LLM-phase fallback for tool-phase violations.
        """
        try:
            state = self._graph.get_state(self._persist_config(config))
        except ValueError as exc:
            if 'No checkpointer set' in str(exc):
                logger.debug(
                    'BeaconLangGraphAgent: skipping state read; graph has no checkpointer',
                )
                return []
            logger.warning(
                'BeaconLangGraphAgent: graph.get_state failed during reconciliation',
                exc_info=True,
            )
            return None
        except Exception:
            logger.warning(
                'BeaconLangGraphAgent: graph.get_state failed during reconciliation',
                exc_info=True,
            )
            return None
        return self._extract_state_messages(state)

    async def _aread_state_messages(
        self,
        config: dict[str, Any],
    ) -> list[BaseMessage] | None:
        """Async counterpart of :meth:`_read_state_messages`.

        Uses ``graph.aget_state`` so async-only checkpointers
        (e.g. ``AsyncPostgresSaver``) work — the sync ``get_state`` on
        those raises rather than returning real data, which would route
        every async reconciliation through the ``state_read_failed``
        fallback.
        """
        try:
            state = await self._graph.aget_state(self._persist_config(config))
        except ValueError as exc:
            if 'No checkpointer set' in str(exc):
                logger.debug(
                    'BeaconLangGraphAgent: skipping state read; graph has no checkpointer',
                )
                return []
            logger.warning(
                'BeaconLangGraphAgent: graph.aget_state failed during reconciliation',
                exc_info=True,
            )
            return None
        except Exception:
            logger.warning(
                'BeaconLangGraphAgent: graph.aget_state failed during reconciliation',
                exc_info=True,
            )
            return None
        return self._extract_state_messages(state)

    def _extract_state_messages(self, state: Any) -> list[BaseMessage]:
        values = getattr(state, 'values', None) or {}
        msgs = values.get(self._violation_state_key)
        return list(msgs) if isinstance(msgs, list) else []

    def _build_messages(
        self,
        config: dict[str, Any],
        exc: GovernanceViolationError,
        *,
        seen_messages: list[BaseMessage] | None = None,
    ) -> list[BaseMessage]:
        """Return the message list to append for this violation.

        Phase dispatch:

        * LLM-phase block → single :class:`AIMessage`.
        * Tool-phase block → one :class:`ToolMessage` per unanswered
          ``tool_call_id`` in the last :class:`AIMessage`'s ``tool_calls``.

        Edge cases (every call already answered, ``blocked_id`` outside
        the unanswered set, missing ``tool_call_id`` metadata) are
        logged at INFO/WARN and degrade to the closest valid shape —
        see :meth:`_build_messages_from_sources`.

        ``seen_messages`` is a list of messages observed in the stream
        chunks before the exception fired.  Used as a fallback when
        ``graph.get_state`` can't see the agent's ``AIMessage`` because
        the failing superstep rolled it back (typical for ``stream`` +
        ``handle_tool_errors=False``).  When the agent's ``AIMessage`` is
        only in ``seen_messages``, the wrapper re-appends it so the
        synthesised ``ToolMessage`` has a matching ``AIMessage`` ahead
        of it (OpenAI invariant).
        """
        state_messages = self._read_state_messages(config)
        return self._build_messages_from_sources(state_messages, seen_messages, exc)

    async def _abuild_messages(
        self,
        config: dict[str, Any],
        exc: GovernanceViolationError,
        *,
        seen_messages: list[BaseMessage] | None = None,
    ) -> list[BaseMessage]:
        """Async counterpart of :meth:`_build_messages`.

        Routes the state read through ``aget_state`` so async-only
        checkpointers work; reconciliation shape is otherwise identical.
        """
        state_messages = await self._aread_state_messages(config)
        return self._build_messages_from_sources(state_messages, seen_messages, exc)

    def _build_messages_from_sources(
        self,
        state_messages: list[BaseMessage] | None,
        seen_messages: list[BaseMessage] | None,
        exc: GovernanceViolationError,
    ) -> list[BaseMessage]:
        phase = exc.phase
        is_tool_phase = phase in ('pre_tool', 'post_tool')
        is_llm_phase = phase in ('pre_llm', 'post_llm')

        # Treat a failed state read as "unknown" rather than "empty" so
        # phase inference doesn't silently downgrade a tool-phase block
        # to an AIMessage when we couldn't read state. The transient-error
        # case (None) is distinguished from the explicit-empty stateless
        # case ([]) by _read_state_messages.
        state_read_failed = state_messages is None
        if state_read_failed:
            state_messages = []

        # Source picking: prefer state if it has an open AIMessage, fall back
        # to chunk-observed messages otherwise (superstep-rollback path).
        source = state_messages
        prefix_missing: list[BaseMessage] = []
        if seen_messages and self._last_open_ai_message(state_messages) is None:
            if self._last_open_ai_message(seen_messages) is not None:
                source = seen_messages
                # Re-append messages seen in chunks. The add_messages reducer
                # dedupes by BaseMessage.id, so re-sending messages already
                # present in state is a no-op; comparing by Python id() here
                # would never match because state messages were deserialised
                # from the checkpointer and have different object identity.
                prefix_missing = list(seen_messages)

        # exc.phase can be None on older callback paths (the stopped-state
        # guard before phase plumbing landed) — infer from message shape and
        # warn so SDK skew is visible. If state read also failed we have no
        # signal at all; default to tool-phase to preserve the OpenAI
        # tool_call invariant whenever a tool_call_id is set, else LLM-phase.
        if not is_tool_phase and not is_llm_phase:
            if self._last_open_ai_message(source) is not None:
                is_tool_phase = True
                inferred = 'pre_tool'
            elif state_read_failed and exc.tool_call_id is not None:
                is_tool_phase = True
                inferred = 'pre_tool (state read failed; defaulted from tool_call_id)'
            else:
                is_llm_phase = True
                inferred = 'pre_llm'
            logger.warning(
                'BeaconLangGraphAgent: GovernanceViolationError.phase was %r; '
                'inferred %r from message shape. This points at an SDK skew — '
                'handler should always stamp phase via _enforce / _raise_if_stopped.',
                phase,
                inferred,
            )

        if is_llm_phase:
            return [self._build_ai_message(exc)]

        # Tool phase — reconcile every unanswered tool_call_id.
        last_ai = self._last_open_ai_message(source)
        if last_ai is None:
            logger.info(
                'BeaconLangGraphAgent: tool-phase governance block with no '
                'AIMessage carrying open tool_calls visible (likely a '
                'rolled-back superstep with no chunk capture); appending a '
                'single AIMessage with the policy message instead.',
            )
            return [self._build_ai_message(exc)]

        unanswered = self._unanswered_tool_call_ids(source, last_ai)
        if not unanswered:
            logger.info(
                'BeaconLangGraphAgent: tool-phase block but every tool_call '
                'on the last AIMessage is already answered; appending an '
                'AIMessage instead to keep the violation visible.',
            )
            return prefix_missing + [self._build_ai_message(exc)]

        blocked_id = exc.tool_call_id
        if blocked_id is None:
            logger.info(
                'BeaconLangGraphAgent: tool-phase governance block carried no '
                'tool_call_id; reconciling broadly with policy ToolMessages '
                'for every unanswered call %r. This usually indicates the '
                'handler did not stamp tool_call_id on the violation (older '
                'callback path) — operationally fine but downstream consumers '
                'cannot tell which call was the offending one.',
                sorted(unanswered),
            )
        if blocked_id is not None and blocked_id not in unanswered:
            logger.warning(
                'BeaconLangGraphAgent: blocked tool_call_id %r is not '
                "among the last AIMessage's unanswered tool_calls %r; "
                'attaching an explicit ToolMessage for the blocked id '
                'and treating the unanswered ones as siblings.',
                blocked_id,
                sorted(unanswered),
            )
            out: list[BaseMessage] = list(prefix_missing)
            out.append(self._build_tool_message(exc, blocked_id))
            for tc_id in unanswered:
                out.append(self._build_sibling_tool_message(exc, tc_id))
            return out

        out: list[BaseMessage] = list(prefix_missing)
        for tc_id in unanswered:
            if blocked_id is not None and tc_id == blocked_id:
                out.append(self._build_tool_message(exc, tc_id))
            elif blocked_id is None:
                # No blocked id metadata — treat every unanswered call as
                # the blocked one. Rare (older callback path); the policy
                # message is still attached so the agent can recover.
                out.append(self._build_tool_message(exc, tc_id))
            else:
                out.append(self._build_sibling_tool_message(exc, tc_id))
        return out

    # ------------------------------------------------------------------
    # Message factories
    # ------------------------------------------------------------------

    @staticmethod
    def _build_ai_message(exc: GovernanceViolationError) -> AIMessage:
        return AIMessage(
            content=str(exc),
            additional_kwargs={
                'beacon_governance_violation': True,
                'policies': exc.policies,
                'latency_ms': exc.latency_ms,
                'phase': exc.phase,
            },
        )

    @staticmethod
    def _build_tool_message(
        exc: GovernanceViolationError,
        tool_call_id: str,
    ) -> ToolMessage:
        return ToolMessage(
            content=str(exc),
            tool_call_id=tool_call_id,
            additional_kwargs={
                'beacon_governance_violation': True,
                'policies': exc.policies,
                'latency_ms': exc.latency_ms,
            },
        )

    @staticmethod
    def _build_sibling_tool_message(
        exc: GovernanceViolationError,
        tool_call_id: str,
    ) -> ToolMessage:
        return ToolMessage(
            content=_SIBLING_SKIP_TEMPLATE.format(policies=exc.policies),
            tool_call_id=tool_call_id,
            additional_kwargs={'beacon_governance_violation_sibling': True},
        )

    # ------------------------------------------------------------------
    # Event factory (emit mode)
    # ------------------------------------------------------------------

    def _build_event(
        self,
        exc: GovernanceViolationError,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        run_id = self._beacon_config.root_span_id
        configurable = config.get('configurable', {}) if isinstance(config, dict) else {}
        if not run_id:
            run_id = configurable.get('thread_id')
        synthesised = False
        if not run_id:
            run_id = str(uuid.uuid4())
            synthesised = True
            logger.warning(
                'BeaconLangGraphAgent: no root_span_id or configurable.thread_id '
                'available when building governance event; using random uuid %r. '
                'Downstream consumers will not be able to correlate this event '
                'with the originating trace.',
                run_id,
            )
        # ``beacon.run_id_synthesized`` lets consumers branch — e.g. skip
        # trace-correlation lookups they know will miss.
        metadata = {'beacon.run_id_synthesized': True} if synthesised else {}
        return {
            'event': 'on_custom_event',
            'name': _VIOLATION_EVENT_NAME,
            'run_id': run_id,
            'data': {
                'message': str(exc),
                'result': exc.result,
                'policies': exc.policies,
                'latency_ms': exc.latency_ms,
                'phase': exc.phase,
                'tool_call_id': exc.tool_call_id,
            },
            'tags': [],
            'metadata': metadata,
            'parent_ids': [],
        }

    # ------------------------------------------------------------------
    # State inspection helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_messages_from_chunk(chunk: Any) -> list[BaseMessage]:
        """Recursively collect ``BaseMessage`` instances from a stream chunk.

        Handles both ``stream_mode='updates'`` (``{node_name: state_diff}``)
        and ``stream_mode='values'`` (full state dict) shapes.  Used to
        recover the agent's ``AIMessage`` when ``ToolNode(handle_tool_errors=False)``
        causes the superstep — and the agent's checkpointer write — to
        roll back.

        Bounded by :data:`_CHUNK_WALK_MAX_DEPTH` and tracks visited
        container objects by ``id`` so a cyclic / pathological user state
        cannot trigger a ``RecursionError`` mid-stream — the wrapper is
        in the violation-handling path here and must not fail.
        """
        out: list[BaseMessage] = []
        BeaconLangGraphAgent._walk_chunk(chunk, out, set(), 0)
        return out

    @staticmethod
    def _walk_chunk(
        value: Any,
        out: list[BaseMessage],
        seen: set[int],
        depth: int,
    ) -> None:
        if depth > _CHUNK_WALK_MAX_DEPTH:
            logger.warning(
                'BeaconLangGraphAgent: chunk walk depth exceeded %d; '
                'truncating message extraction.',
                _CHUNK_WALK_MAX_DEPTH,
            )
            return
        if isinstance(value, BaseMessage):
            out.append(value)
            return
        if isinstance(value, (dict, list, tuple)):
            ident = id(value)
            if ident in seen:
                return
            seen.add(ident)
            iterable = value.values() if isinstance(value, dict) else value
            for child in iterable:
                BeaconLangGraphAgent._walk_chunk(child, out, seen, depth + 1)

    @staticmethod
    def _extract_messages_from_event(event: Any) -> list[BaseMessage]:
        """Pull ``BaseMessage`` instances from an ``astream_events`` event.

        We only inspect ``on_chain_end`` events whose ``data.output`` carries
        messages — that's where LangGraph emits node-completion state diffs.
        Token-stream events (``on_chat_model_stream``) are skipped to avoid
        treating each token chunk as a separate message.
        """
        if not isinstance(event, dict):
            return []
        if event.get('event') != 'on_chain_end':
            return []
        data = event.get('data') or {}
        output = data.get('output')
        if output is None:
            return []
        return BeaconLangGraphAgent._extract_messages_from_chunk(output)

    @staticmethod
    def _last_open_ai_message(messages: list[Any]) -> AIMessage | None:
        """Return the most recent AIMessage that has unanswered tool_calls.

        "Unanswered" means at least one of the AIMessage's ``tool_calls``
        does not have a matching :class:`ToolMessage` later in the list.

        Returns ``None`` as soon as the most recent tool-calling AIMessage
        has every call answered — older AIMessages are not consulted.
        Agentic loops mark the latest AI turn as the "active" one; an
        earlier turn with stale unanswered calls is by construction
        invalid state and should not drive reconciliation.
        """
        for idx in range(len(messages) - 1, -1, -1):
            msg = messages[idx]
            if not isinstance(msg, AIMessage):
                continue
            tool_calls = getattr(msg, 'tool_calls', None) or []
            if not tool_calls:
                continue
            tail = messages[idx + 1 :]
            answered = {
                getattr(m, 'tool_call_id', None) for m in tail if isinstance(m, ToolMessage)
            }
            ids = {
                tc.get('id') if isinstance(tc, dict) else getattr(tc, 'id', None)
                for tc in tool_calls
            }
            ids.discard(None)
            if ids - answered:
                return msg
            return None
        return None

    @staticmethod
    def _unanswered_tool_call_ids(
        messages: list[Any],
        ai_message: AIMessage,
    ) -> list[str]:
        try:
            ai_index = messages.index(ai_message)
        except ValueError:
            ai_index = len(messages) - 1
        tail = messages[ai_index + 1 :]
        answered = {getattr(m, 'tool_call_id', None) for m in tail if isinstance(m, ToolMessage)}
        ordered: list[str] = []
        seen: set[str] = set()
        for tc in getattr(ai_message, 'tool_calls', None) or []:
            tc_id = tc.get('id') if isinstance(tc, dict) else getattr(tc, 'id', None)
            if tc_id is None or tc_id in seen or tc_id in answered:
                continue
            seen.add(tc_id)
            ordered.append(tc_id)
        return ordered

    # ------------------------------------------------------------------
    # Post-hoc violation detection (ToolNode handle_tool_errors=True path)
    # ------------------------------------------------------------------

    def _violation_count_snapshot(self) -> int:
        handler = self._beacon_config.governance_handler
        return handler.violation_count if handler is not None else 0

    def _post_hoc_violation(self, before: int) -> GovernanceViolationError | None:
        """Return the swallowed violation, or ``None`` if none happened.

        Detects the ``ToolNode(handle_tool_errors=True)`` case: the
        governance handler raised, ``ToolNode`` caught the exception
        and emitted its own error ``ToolMessage`` — so the wrapper's
        ``try/except`` never fires.  Compare ``violation_count`` before
        and after the call; if it incremented, fetch
        ``handler.last_violation`` to recover the original error with
        full ``phase`` / ``tool_call_id`` / ``policies`` context.
        """
        handler = self._beacon_config.governance_handler
        if handler is None or handler.violation_count <= before:
            return None
        exc = handler.last_violation
        if exc is None:
            logger.warning(
                'BeaconLangGraphAgent: violation_count incremented but no '
                'last_violation was stored on the handler; synthesising a '
                'placeholder GovernanceViolationError so violation_mode '
                'dispatch still fires. Original phase / tool_call_id / '
                'policies are lost — this indicates an SDK version skew.',
            )
            return GovernanceViolationError(
                'Governance violation detected but its details were not '
                'recorded by the handler (SDK version skew).',
            )
        return exc

    def _handle_post_hoc(
        self,
        result: Any,
        config: dict[str, Any],
        before: int,
    ) -> Any:
        """Apply the post-hoc dispatch for non-streaming entry points.

        ``state`` mode is a no-op on the swallow path because
        ``ToolNode`` has already written its own error ``ToolMessage``
        to the state; appending Beacon-flagged ``ToolMessage``s on top
        would either duplicate (same ``tool_call_id``) or shift
        downstream consumers' expectations.

        ``emit`` mode on ``invoke``/``ainvoke`` cannot deliver an event
        (no event stream), and adding a Beacon ``ToolMessage`` would
        duplicate ToolNode's reconciliation the same way.  We log at
        WARN and leave :attr:`last_violation` on the wrapper so callers
        can detect the swallowed violation programmatically.
        """
        exc = self._post_hoc_violation(before)
        if exc is None:
            return result
        if self._violation_mode == 'raise':
            raise exc
        log_method = logger.warning if self._violation_mode == 'emit' else logger.info
        log_method(
            'BeaconLangGraphAgent: governance violation caught by '
            'ToolNode(handle_tool_errors=True); wrapper reconciliation '
            "skipped to avoid duplicating ToolNode's error ToolMessage. "
            'violation_mode=%s (no event stream on invoke/ainvoke when '
            'emit). phase=%s tool_call_id=%s policies=%s',
            self._violation_mode,
            exc.phase,
            exc.tool_call_id,
            self._policy_summary(exc.policies),
        )
        return result

    @staticmethod
    def _policy_summary(policies: Any) -> list[Any]:
        """Render a ``rules_evaluated`` list compactly for log output.

        The OPA payload uses different label keys depending on the rule
        shape — ``name``, ``rule``, ``message`` or just ``stack_name``.
        Walk the common ones and fall back to the full dict if nothing
        matches, so log lines stay informative instead of showing ``None``.
        """
        out = []
        for p in policies or []:
            if isinstance(p, dict):
                for key in (
                    'name',
                    'rule',
                    'rego_path',
                    'id',
                    'path',
                    'rule_name',
                    'message',
                    'stack_name',
                ):
                    v = p.get(key)
                    if v:
                        out.append(v)
                        break
                else:
                    out.append(p)
            else:
                out.append(p)
        return out

    # ------------------------------------------------------------------
    # Config merging
    # ------------------------------------------------------------------

    @staticmethod
    def _merge_config(
        base: dict[str, Any],
        override: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Merge a caller-supplied LangChain config into beacon's base config.

        * ``callbacks`` lists are concatenated (beacon's handlers first so
          they observe before any user-supplied tracers).
        * ``configurable`` and ``metadata`` dicts are shallow-merged with
          caller values taking precedence.
        * ``tags`` lists are concatenated and de-duplicated.
        * Other keys: caller wins.
        """
        if not override:
            return base

        merged = dict(base)
        for key, value in override.items():
            if key == 'callbacks':
                base_cbs = list(base.get('callbacks') or [])
                extra = value if isinstance(value, list) else [value]
                merged['callbacks'] = base_cbs + list(extra)
            elif key in ('configurable', 'metadata'):
                combined = dict(base.get(key) or {})
                if isinstance(value, dict):
                    combined.update(value)
                merged[key] = combined
            elif key == 'tags':
                base_tags = list(base.get('tags') or [])
                extra_tags = list(value or [])
                seen: set[str] = set()
                merged_tags: list[str] = []
                for tag in base_tags + extra_tags:
                    if tag in seen:
                        continue
                    seen.add(tag)
                    merged_tags.append(tag)
                merged['tags'] = merged_tags
            else:
                merged[key] = value
        return merged
