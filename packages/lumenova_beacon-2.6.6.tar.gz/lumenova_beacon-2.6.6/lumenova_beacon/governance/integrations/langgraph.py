"""LangGraph helpers for governance content reinjection.

Exposes two convenience wrappers:

- :func:`wrap_tool_node` — takes an existing LangGraph ``ToolNode`` (or a
  plain list of tools) and returns one whose tools enforce governance
  and apply any policy-supplied replacement to tool kwargs and output.
- :func:`wrap_chat_model` — takes a LangChain ``BaseChatModel`` and
  returns it with governance installed around ``invoke`` / ``ainvoke``.

Both helpers defer to
:class:`lumenova_beacon.governance.integrations.langchain.BeaconLangGraphGovernanceHandler`
— either the one passed in (so violation state is shared across the
run) or a fresh handler built from the supplied ``stack_ids`` / ``tags``.
"""

from __future__ import annotations

import inspect
import logging

from collections.abc import Callable, Sequence
from typing import Any

from lumenova_beacon.governance.integrations.langchain import (
    BeaconLangGraphGovernanceHandler,
)


try:
    from langchain_core.language_models import BaseChatModel
    from langchain_core.tools import BaseTool
except ImportError as exc:
    raise ImportError(
        'langchain-core is required for the LangGraph governance helpers. '
        'Install it with: pip install langchain-core'
    ) from exc

logger = logging.getLogger(__name__)


_UNSET: Any = object()


def _ensure_handler(
    handler: BeaconLangGraphGovernanceHandler | None,
    **handler_kwargs: Any,
) -> BeaconLangGraphGovernanceHandler:
    if handler is not None:
        # Anything still _UNSET means the wrapper caller did not supply that
        # kwarg; only explicitly-provided ones conflict with the handler.
        explicit = {k: v for k, v in handler_kwargs.items() if v is not _UNSET}
        if explicit:
            raise ValueError(
                f'wrap helpers received an explicit handler alongside '
                f'configuration kwargs {sorted(explicit)}. The handler\'s '
                f'own configuration is used; remove the conflicting kwargs '
                f'to silence this error.'
            )
        return handler
    # Drop unset kwargs so the handler constructor's documented defaults
    # apply. Mapping _UNSET to None and then patching fail_open back to
    # True silently overrode a caller who explicitly passed fail_open=None
    # (e.g. from a config object) — for a security feature, flipping
    # fail-closed to fail-open on a None is the wrong default.
    resolved = {k: v for k, v in handler_kwargs.items() if v is not _UNSET}
    return BeaconLangGraphGovernanceHandler(**resolved)


def wrap_chat_model(
    model: BaseChatModel,
    *,
    handler: BeaconLangGraphGovernanceHandler | None = None,
    stack_ids: list[str] | None = _UNSET,
    tags: list[str] | None = _UNSET,
    fail_open: bool = _UNSET,
    enabled_hooks: set[str] | None = _UNSET,
    result_parser: Callable[[dict[str, Any]], bool] | None = _UNSET,
    timeout: float | None = _UNSET,
    agent_id: str | None = _UNSET,
    agent_name: str | None = _UNSET,
    session_id: str | None = _UNSET,
    environment: str | None = _UNSET,
    metadata: dict[str, Any] | None = _UNSET,
) -> BaseChatModel:
    """Install governance around a LangChain chat model's invoke paths.

    Thin wrapper over
    :meth:`BeaconLangGraphGovernanceHandler.wrap` that lets callers
    provide configuration directly without instantiating a handler first.
    If ``handler`` is supplied, supplying any other keyword argument
    raises ``ValueError`` — the handler's own configuration is used and
    silently dropping conflicting kwargs would surprise the caller.
    """
    h = _ensure_handler(
        handler,
        stack_ids=stack_ids,
        tags=tags,
        fail_open=fail_open,
        enabled_hooks=enabled_hooks,
        result_parser=result_parser,
        timeout=timeout,
        agent_id=agent_id,
        agent_name=agent_name,
        session_id=session_id,
        environment=environment,
        metadata=metadata,
    )
    return h.wrap(model)  # type: ignore[return-value]


def wrap_tool_node(
    tool_node: Any,
    *,
    handler: BeaconLangGraphGovernanceHandler | None = None,
    stack_ids: list[str] | None = _UNSET,
    tags: list[str] | None = _UNSET,
    fail_open: bool = _UNSET,
    enabled_hooks: set[str] | None = _UNSET,
    result_parser: Callable[[dict[str, Any]], bool] | None = _UNSET,
    timeout: float | None = _UNSET,
    agent_id: str | None = _UNSET,
    agent_name: str | None = _UNSET,
    session_id: str | None = _UNSET,
    environment: str | None = _UNSET,
    metadata: dict[str, Any] | None = _UNSET,
) -> Any:
    """Return a governance-wrapped ``ToolNode`` (or list of tools).

    Accepts either a ``langgraph.prebuilt.ToolNode`` instance or a
    plain ``Sequence[BaseTool]``. Each tool has its inner
    ``func``/``coroutine`` replaced with a governance-wrapped version
    that applies policy reinjection to both arguments and output.

    For a ``ToolNode`` input, the returned object is a fresh
    ``ToolNode`` built from the wrapped tools. Constructor kwargs that
    the original ``ToolNode`` exposes as public attributes (e.g.
    ``tags``, ``name``) are copied across via reflection on
    ``inspect.signature(ToolNode)``. Constructor kwargs that the
    original does NOT expose as a same-named attribute (notably
    ``handle_tool_errors``, ``messages_key``, ``wrap_tool_call`` —
    ``ToolNode`` stores these internally) cannot be recovered and the
    new ``ToolNode`` falls back to its constructor defaults for those
    parameters; a DEBUG log records each drop. Items in a ``Sequence``
    input that are not ``BaseTool`` instances are filtered out.
    """
    h = _ensure_handler(
        handler,
        stack_ids=stack_ids,
        tags=tags,
        fail_open=fail_open,
        enabled_hooks=enabled_hooks,
        result_parser=result_parser,
        timeout=timeout,
        agent_id=agent_id,
        agent_name=agent_name,
        session_id=session_id,
        environment=environment,
        metadata=metadata,
    )

    tools = _extract_tools(tool_node)
    wrapped = [h.wrap(t) for t in tools]

    try:
        from langgraph.prebuilt import ToolNode
    except ImportError:
        ToolNode = None  # type: ignore[assignment,misc]

    # Sequence inputs are returned as a plain list. Check ToolNode first —
    # some langgraph versions make ToolNode iterable, so a Sequence-first
    # dispatch could shadow the ToolNode branch.
    if ToolNode is not None and isinstance(tool_node, ToolNode):
        return _rebuild_toolnode(tool_node, wrapped)

    return wrapped


def _rebuild_toolnode(original: Any, wrapped_tools: list[BaseTool]) -> Any:
    """Construct a fresh ``ToolNode`` from ``wrapped_tools``, copying any
    public configuration that the new constructor accepts.

    Uses ``inspect.signature`` rather than a hard-coded list so future
    langgraph versions that add new ``ToolNode`` kwargs are handled
    automatically. Only attributes present on ``original.__dict__``
    (i.e. set via the constructor on the instance) are copied — checking
    ``hasattr`` would also pull in class-level ``Runnable`` properties
    like ``name`` / ``tags`` that return derived defaults rather than
    constructor-supplied values, which would silently diverge the
    rebuilt node from the original.
    """
    from langgraph.prebuilt import ToolNode

    try:
        params = inspect.signature(ToolNode).parameters
    except (TypeError, ValueError) as exc:
        # A future langgraph might wrap ToolNode in a way that makes
        # signature() fail. Enumerate the original's instance attributes so
        # operators see exactly which configuration is being dropped —
        # silently switching `handle_tool_errors` from False to the
        # constructor default of True would change runtime tool-error
        # propagation semantics without any visible signal.
        try:
            dropped = sorted(vars(original).keys())
        except TypeError:
            dropped = []
        logger.warning(
            'wrap_tool_node: inspect.signature(ToolNode) failed (%s: %s); '
            'rebuilding with tools only — the following original-instance '
            'attributes will not be preserved on the new ToolNode: %s',
            type(exc).__name__, exc, dropped,
        )
        return ToolNode(wrapped_tools)

    instance_attrs = vars(original)
    extras: dict[str, Any] = {}
    for name in params:
        if name in ('self', 'tools'):
            continue
        if name in instance_attrs:
            extras[name] = instance_attrs[name]
        else:
            logger.debug(
                'wrap_tool_node: original ToolNode did not set %r on the '
                'instance; leaving the new ToolNode\'s default for that '
                'parameter.',
                name,
            )

    return ToolNode(wrapped_tools, **extras)


def _extract_tools(target: Any) -> list[BaseTool]:
    if isinstance(target, Sequence) and not isinstance(target, str):
        return [t for t in target if isinstance(t, BaseTool)]

    tools_by_name = getattr(target, 'tools_by_name', None)
    if tools_by_name is not None:
        # Truthy check would mis-route an empty ToolNode (`tools_by_name={}`)
        # to the "wrong shape" branch below, even though it is a valid input
        # whose only quirk is having no tools to wrap.
        return list(tools_by_name.values())

    raise TypeError(
        f'wrap_tool_node() expects a ToolNode or Sequence[BaseTool]; '
        f'got {type(target).__name__}'
    )
