"""LangChain/LangGraph governance callback handler.

This module provides a callback handler that enforces governance policies
on LangChain agent actions by calling the Beacon governance evaluation
endpoint before and/or after tool and LLM invocations.

Usage:
    from lumenova_beacon import BeaconClient, BeaconLangGraphHandler
    from lumenova_beacon.governance import BeaconLangGraphGovernanceHandler

    client = BeaconClient()

    tracer = BeaconLangGraphHandler()
    governance = BeaconLangGraphGovernanceHandler(stack_ids=['my-stack-id'])

    llm = ChatOpenAI()
    response = llm.invoke("Hello", config={"callbacks": [tracer, governance]})

Input format sent to the governance API (matches Rego policy expectations)::

    # Tool pre-execution:
    {"phase": "pre", "type": "tool",
     "source": {"agent_id": "my-agent", "framework": "langchain"},
     "context": {"session_id": "sess-1", "environment": "production"},
     "tool": {"name": "send_email", "parameters": {"to": "x@y.com"}}}

    # Tool post-execution:
    {"phase": "post", "type": "tool",
     "source": {"agent_id": "my-agent"},
     "tool": {"name": "read_file", "parameters": {"path": "/data/f.csv"},
              "output": "file contents..."}}

    # LLM pre-execution:
    {"phase": "pre", "type": "llm",
     "source": {"agent_id": "my-agent"},
     "context": {"model_call_count": 2},
     "llm": {"model_name": "gpt-4", "last_user_content": "..."}}

    # LLM post-execution:
    {"phase": "post", "type": "llm",
     "context": {"model_call_count": 2},
     "llm": {"model_name": "gpt-4"}}

OPA/Rego policies return ``{"decision": "allow"}`` or
``{"decision": "block", "message": "..."}``.
"""

from __future__ import annotations

import json
import logging

from collections import deque
from collections.abc import Callable, Sequence
from contextvars import Token
from typing import Any, Literal, cast
from uuid import UUID

from lumenova_beacon.exceptions import (
    GovernanceConfigurationError,
    GovernancePhase,
    GovernanceViolationError,
)
from lumenova_beacon.governance._helpers import (
    aevaluate_or_fail_open,
    default_result_parser,
    evaluate_or_fail_open,
    get_sdk_version,
    is_allowed,
    parse_outcome,
    truncate,
)
from lumenova_beacon.governance._state import (
    _active_handler,
    _active_node_run_id,
    _resolve_active_node,
    lookup_state_for,
    serialize_state,
)
from lumenova_beacon.governance._wrapping import (
    apply_llm_messages_replacement,
    apply_llm_return_replacement,
    apply_tool_kwargs_replacement,
    apply_tool_return_replacement,
)
from lumenova_beacon.governance.client import GovernanceClient
from lumenova_beacon.tracing.trace import get_current_span, get_current_trace_id
from lumenova_beacon.utils.client_helpers import resolve_user_attr


try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.language_models import BaseChatModel
    from langchain_core.messages import BaseMessage
    from langchain_core.outputs import LLMResult
    from langchain_core.tools import BaseTool
except ImportError:
    raise ImportError(
        'langchain-core is required for the governance callback handler. '
        'Install it with: pip install langchain-core'
    )

logger = logging.getLogger(__name__)

_DEFAULT_HOOKS = frozenset({'pre_tool', 'post_tool', 'pre_llm', 'post_llm'})
_VALID_ON_VIOLATION = ('raise', 'stop')
_INVOCATION_CHAIN_MAX = 10
_DEFAULT_STATE_MAX_BYTES = 32 * 1024

# Sentinel attribute name marking a function/model as already governed,
# so a second wrap() call short-circuits instead of double-evaluating.
_GOVERNED_SENTINEL = '__beacon_governed__'


class BeaconLangGraphGovernanceHandler(BaseCallbackHandler):
    """LangChain callback handler that enforces governance policies.

    Intercepts tool and LLM lifecycle events, calls the Beacon governance
    evaluation endpoint (``POST /api/v1/governance/evaluate``), and raises
    :class:`~lumenova_beacon.exceptions.GovernanceViolationError` to block
    actions that violate governance policies.

    Attaching this handler as a LangChain callback observes and blocks
    only — content reinjection (substituting a policy-supplied ``output``
    into tool kwargs / LLM messages / return values) requires
    :meth:`wrap` (or the LangGraph helpers ``wrap_tool_node`` and
    ``wrap_chat_model``). When a callback-attached handler observes a
    response that carries a non-null ``output`` it logs a one-time WARN
    per (action, phase) pair so the misuse is visible.

    The handler follows the same pattern as
    :class:`~lumenova_beacon.tracing.integrations.langchain.BeaconLangGraphHandler`:
    constructor params allow per-handler overrides, but defaults for
    ``session_id`` and ``environment`` are pulled from the active
    :class:`~lumenova_beacon.core.client.BeaconClient` config.

    Args:
        stack_ids: Explicit policy stack IDs to evaluate against. At least
            one of ``stack_ids`` or ``tags`` must be provided.
        tags: Tag-based policy stack discovery.
        fail_open: When ``True`` (default), allow the action if the governance
            API is unreachable or returns an unexpected error.
        enabled_hooks: Set of hook names that should trigger evaluation.
            Valid values: ``'pre_tool'``, ``'post_tool'``, ``'pre_llm'``,
            ``'post_llm'``. Defaults to all four.
        result_parser: Optional callable ``(result_dict) -> bool`` that
            determines whether the response allows the action.
        timeout: Override the transport timeout (in seconds) for governance
            evaluation calls.
        debug: When ``True``, enable DEBUG-level logging for the governance
            handler and client.
        on_violation: Strategy when a policy blocks an action.
            ``'raise'`` (default) raises ``GovernanceViolationError``.
            ``'stop'`` sets a stopped flag and raises, preventing all
            subsequent tool/LLM calls from proceeding.
        max_violations: After this many violations, escalate to ``'stop'``
            regardless of the ``on_violation`` setting. ``None`` disables.
        agent_id: Identifier for the agent, included in ``input.source``.
        agent_name: Human-readable agent name, included in ``input.source``.
        session_id: Override session ID. Defaults to ``BeaconClient.config.session_id``.
        environment: Override environment. Defaults to ``BeaconClient.config.environment``.
        metadata: Custom metadata dict included in ``input.context.metadata``.
        include_state: When ``True`` (default), capture LangGraph node-level
            state from ``on_chain_start`` callbacks and forward it to policies
            as ``input.context.state``. State can carry PII — provide a
            ``state_filter`` or set this to ``False`` if that's a concern.
        state_filter: Optional ``(state_dict) -> dict`` callable applied
            before serialization. Use it to redact or whitelist fields.
        state_max_bytes: Cap on the JSON-serialized state size. When
            exceeded, a truncation marker replaces the state value rather
            than dropping fields silently. Default 32 KiB.
    """

    # Tell LangChain to propagate exceptions raised in callbacks.
    raise_error = True

    def __init__(
        self,
        *,
        stack_ids: list[str] | None = None,
        tags: list[str] | None = None,
        fail_open: bool = True,
        enabled_hooks: set[str] | None = None,
        result_parser: Callable[[dict[str, Any]], bool] | None = None,
        timeout: float | None = None,
        debug: bool = False,
        on_violation: str = 'raise',
        max_violations: int | None = None,
        agent_id: str | None = None,
        agent_name: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
        metadata: dict[str, Any] | None = None,
        include_state: bool = True,
        state_filter: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
        state_max_bytes: int = _DEFAULT_STATE_MAX_BYTES,
    ):
        super().__init__()

        if on_violation not in _VALID_ON_VIOLATION:
            raise ValueError(
                f'on_violation must be one of {_VALID_ON_VIOLATION!r}, got {on_violation!r}'
            )

        self._stack_ids = stack_ids
        self._tags = tags
        self._fail_open = fail_open
        self._enabled_hooks: set[str] = (
            set(enabled_hooks) if enabled_hooks is not None else set(_DEFAULT_HOOKS)
        )
        self._result_parser = result_parser
        self._timeout = timeout
        self._debug = debug
        self._on_violation = on_violation
        self._max_violations = max_violations

        # Source context
        self._agent_id = agent_id
        self._agent_name = agent_name

        # Context — defaults from BeaconClient (same pattern as BeaconLangGraphHandler)
        from lumenova_beacon.core.client import get_client

        client = get_client()
        self._session_id = session_id if session_id is not None else client.config.session_id
        self._environment = environment if environment is not None else client.config.environment
        self._metadata = metadata
        self._user_email = resolve_user_attr(None, client.config.user_email, metadata, "user_email")
        self._user_name = resolve_user_attr(None, client.config.user_name, metadata, "user_name")
        self._user_id = resolve_user_attr(None, client.config.user_id, metadata, "user_id")

        self._client = GovernanceClient()
        # Minimal run tracking so post-execution hooks can reference the
        # tool name and parameters (not available in on_tool_end signature).
        self._runs: dict[str, dict[str, Any]] = {}
        # Track model call count across the handler lifetime (useful for
        # policies that limit the number of LLM round-trips).
        self._model_call_count: int = 0
        # Graceful stop state.
        self._violation_count: int = 0
        self._stopped: bool = False
        # Invocation chain — bounded list of recent actions for sequence-aware policies.
        self._invocation_chain: deque[dict[str, str]] = deque(maxlen=_INVOCATION_CHAIN_MAX)
        # Agent state capture (opt-in via include_state).
        self._include_state = include_state
        self._state_filter = state_filter
        self._state_max_bytes = state_max_bytes
        # run_id -> raw state snapshot (kept raw here; serialized on emit so
        # state_filter changes between calls take effect immediately).
        self._node_state: dict[UUID, dict[str, Any]] = {}
        # run_id -> parent_run_id, recorded for every chain start. Used
        # as a walk source by both `lookup_state_for` (read path) and
        # `_resolve_active_handler_and_node_run_id` (write path for
        # set_agent_state) to find the enclosing node's state from a
        # descendant run id (tool, sub-chain, LLM call). The walk is
        # race-safe under parallel `Send` because the seed run_id comes
        # from LangChain's per-task `var_child_runnable_config` (or a
        # callback's own kwargs), so it already belongs to the active
        # branch — the walk only traverses that branch's ancestry.
        self._chain_parents: dict[UUID, UUID | None] = {}
        # run_id -> ContextVar reset tokens, so on_chain_end can restore the
        # previous active node/handler values without leaking across nodes.
        self._cv_tokens: dict[UUID, tuple[Token, Token]] = {}
        # Track which (context, phase) pairs we have already warned about
        # when a callback-attached handler observes an `output` it cannot
        # apply. A per-pair set rather than a single bool means a later
        # misconfiguration on a different tool/phase still surfaces — we
        # only suppress the duplicate-warning case for the same surface.
        self._reinjection_warned_keys: set[tuple[str, str]] = set()
        # Most recent GovernanceViolationError raised by _enforce /
        # _raise_if_stopped / the callback-level "already stopped" guards.
        # Set before each raise so wrappers that need to recover violations
        # ToolNode swallowed via handle_tool_errors=True (the exception
        # never reaches graph.invoke's caller) can fetch the original
        # error.  Never auto-cleared — callers compare against a snapshot
        # of ``violation_count`` to know whether ``last_violation`` is fresh.
        self._last_violation: GovernanceViolationError | None = None

        if self._debug:
            self._enable_debug_logging()

        logger.debug(
            'Initialized BeaconLangGraphGovernanceHandler: stack_ids=%s tags=%s fail_open=%s '
            'enabled_hooks=%s timeout=%s agent_id=%s agent_name=%s session_id=%s '
            'environment=%s on_violation=%s max_violations=%s',
            self._stack_ids,
            self._tags,
            self._fail_open,
            self._enabled_hooks,
            self._timeout,
            self._agent_id,
            self._agent_name,
            self._session_id,
            self._environment,
            self._on_violation,
            self._max_violations,
        )

    # ------------------------------------------------------------------
    # Public properties / methods
    # ------------------------------------------------------------------

    @property
    def violation_count(self) -> int:
        """Number of governance violations encountered so far."""
        return self._violation_count

    @property
    def last_violation(self) -> GovernanceViolationError | None:
        """Most recent :class:`GovernanceViolationError` raised by this handler.

        Set immediately before every raise (callback ``on_*`` guards,
        :meth:`_enforce`, :meth:`_raise_if_stopped`).  Useful for callers
        that wrap the graph and need to detect violations that
        ``ToolNode(handle_tool_errors=True)`` caught and converted into
        a ``ToolMessage`` — in that case the exception never reaches
        ``graph.invoke``'s caller, but :attr:`violation_count` increments
        and ``last_violation`` holds the original error with full
        ``result`` / ``policies`` / ``phase`` / ``tool_call_id`` context.

        Snapshot ``violation_count`` before the call you want to monitor
        and compare after — ``last_violation`` is only fresh if the
        count incremented.  Never auto-cleared; use :meth:`reset` to wipe.
        """
        return self._last_violation

    def reset(self) -> None:
        """Reset violation count, stopped state, and per-run state tracking."""
        self._violation_count = 0
        self._stopped = False
        self._last_violation = None
        self._node_state.clear()
        self._chain_parents.clear()
        # Tokens belong to ContextVars that are scoped per-task; clearing
        # the dict drops our references but cannot reset other tasks'
        # ContextVar values from this thread. Callers concerned about
        # bleed-through should construct a fresh handler per run instead.
        self._cv_tokens.clear()

    def update_node_state(self, run_id: UUID, state: dict[str, Any]) -> None:
        """Replace the captured state for ``run_id``.

        Public method (not underscore-prefixed) because
        :func:`set_agent_state` calls it from a sibling module — keeps
        cross-module mutation off ``self._node_state`` directly.
        """
        self._node_state[run_id] = state

    def get_node_state(self, run_id: UUID) -> dict[str, Any] | None:
        """Return captured state for ``run_id``, or ``None``."""
        return self._node_state.get(run_id)

    # ------------------------------------------------------------------
    # Source & context builders
    # ------------------------------------------------------------------

    def _build_source(self) -> dict[str, Any]:
        """Build the ``input.source`` dict for governance evaluation."""
        source: dict[str, Any] = {'framework': 'langchain'}
        if self._agent_id:
            source['agent_id'] = self._agent_id
        if self._agent_name:
            source['agent_name'] = self._agent_name
        source['sdk_version'] = get_sdk_version()
        return source

    def _build_context(self, parent_run_id: UUID | None = None) -> dict[str, Any]:
        """Build the ``input.context`` dict for governance evaluation.

        ``parent_run_id`` (callback path) seeds the ancestor walk for
        state resolution; the wrap path passes ``None`` so the
        LangChain config bridge resolves instead.
        """
        ctx: dict[str, Any] = {}
        if self._session_id:
            ctx['session_id'] = self._session_id
        if self._environment:
            ctx['environment'] = self._environment
        if self._user_id:
            ctx['user_id'] = self._user_id
        if self._user_email:
            ctx['user_email'] = self._user_email
        if self._user_name:
            ctx['user_name'] = self._user_name
        ctx['model_call_count'] = self._model_call_count
        if self._metadata:
            ctx['metadata'] = self._metadata
        if self._invocation_chain:
            ctx['invocation_chain'] = list(self._invocation_chain)
        if self._include_state:
            state, scope_detected = self._resolve_active_state(parent_run_id)
            if state is not None:
                serialized = serialize_state(
                    state, self._state_filter, self._state_max_bytes,
                )
                if serialized is not None:
                    ctx['state'] = serialized
                elif scope_detected:
                    # Filter or budget killed the state, but a node was
                    # active. `serialize_state` already WARNs on filter
                    # failure; the marker keeps the policy-payload
                    # signal symmetric with the no-resolution branch.
                    ctx['state_unavailable'] = True
            elif scope_detected:
                # A node was apparently active but state didn't resolve
                # (bridge failure, walk-cap, etc.). Surface a marker so
                # OPA policies can fail-closed instead of negating
                # against an absent ref.
                ctx['state_unavailable'] = True
        return ctx

    def _resolve_active_state(
        self, parent_run_id: UUID | None = None,
    ) -> tuple[dict[str, Any] | None, bool]:
        """Return ``(state, scope_detected)`` for the enclosing node.

        ``scope_detected`` is ``True`` when we found evidence a
        LangGraph node was in flight — the caller can use it to surface
        a ``state_unavailable`` marker on the policy payload so an OPA
        policy negating against ``input.context.state`` can fail-closed
        rather than silently flip on a resolution regression.

        Resolution order (canonical source — cross-references in
        ``_state.py`` and ``decorators.py`` defer to this docstring):

          1. Callback path. Each callback site (``on_tool_start`` etc.)
             passes ``kwargs['parent_run_id']`` here, *not* its own
             ``run_id`` — tool/LLM run_ids are never registered in
             ``self._chain_parents`` (only chain starts populate it),
             so seeding with ``run_id`` would always miss. The walk
             climbs ``self._chain_parents`` from the parent until it
             hits a run with state in ``self._node_state``.
          2. Else (the wrap path, or any caller without a parent_run_id
             kwarg) ask the LangChain config bridge — survives
             ``astream`` / ``astream_events`` where ``on_chain_start``'s
             ContextVar set runs in a copied Context that never reaches
             user code. The bridge exposes both the live run_id and its
             parent; we seed the walk with both. Only trust the
             bridge's seeds when the bridge picked *this* handler — if
             a different handler is attached to the live scope, its
             run_ids may not be in ``self._chain_parents``
             (multi-handler ambiguity).
          3. If the bridge reports no active Runnable scope, or if the
             bridge handler is not us, fall back to
             ``_active_node_run_id`` for callers running outside any
             Runnable scope (sync ``invoke`` paths, helpers between
             runs).
        """
        if parent_run_id is not None:
            state = lookup_state_for(self, parent_run_id)
            scope_detected = state is not None or parent_run_id in self._chain_parents
            return state, scope_detected
        bridge_handler, cfg_run_id, cfg_parent_run_id, scope_active = (
            _resolve_active_node()
        )
        bridge_for_self = scope_active and bridge_handler is self
        if bridge_for_self:
            seeds: tuple[UUID | None, ...] = (cfg_run_id, cfg_parent_run_id)
        else:
            seeds = (_active_node_run_id.get(),)
        scope_detected = bridge_for_self or any(s is not None for s in seeds)
        for seed in seeds:
            if seed is None:
                continue
            state = lookup_state_for(self, seed)
            if state is not None:
                return state, True
        logger.debug(
            'governance handler: include_state=True but no state resolved '
            '(scope_active=%s, bridge_is_self=%s, cfg_run_id=%s, '
            'cfg_parent_run_id=%s, local_node_run_id=%s, scope_detected=%s); '
            'shipping context without state',
            scope_active, bridge_handler is self, cfg_run_id,
            cfg_parent_run_id, _active_node_run_id.get(), scope_detected,
        )
        return None, scope_detected

    def _build_extra(
        self,
        action_data: dict[str, Any],
        parent_run_id: UUID | None = None,
    ) -> dict[str, Any]:
        """Build the full extra dict with source, context, and action data.

        ``parent_run_id`` (when supplied) seeds the ancestor walk for
        state resolution. Pass ``kwargs['parent_run_id']`` from
        callbacks; the wrap path passes ``None`` and lets the LangChain
        config bridge resolve.
        """
        extra: dict[str, Any] = dict(action_data)
        extra['source'] = self._build_source()
        extra['context'] = self._build_context(parent_run_id)
        return extra

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _enable_debug_logging() -> None:
        """Configure governance loggers to emit DEBUG output to stderr."""
        governance_logger = logging.getLogger('lumenova_beacon.governance')
        if not governance_logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter('[governance] %(levelname)s %(message)s'))
            governance_logger.addHandler(handler)
        governance_logger.setLevel(logging.DEBUG)

    @staticmethod
    def _default_result_parser(result: dict[str, Any]) -> bool:
        """Default result parser.

        Delegates to :func:`~lumenova_beacon.governance._helpers.default_result_parser`.
        """
        return default_result_parser(result)

    def _is_allowed(self, response: dict[str, Any]) -> bool:
        return is_allowed(response, self._result_parser)

    def _evaluate_or_fail_open(
        self,
        phase: str,
        type_: str,
        extra: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Call the governance API; return the response or ``None`` on fail-open."""
        trace_id = get_current_trace_id()
        span = get_current_span()
        span_id = span.span_id if span is not None else None
        return evaluate_or_fail_open(
            self._client,
            phase,
            type_,
            self._stack_ids,
            self._tags,
            extra,
            self._timeout,
            self._fail_open,
            trace_id=trace_id,
            span_id=span_id,
        )

    def _enforce(
        self,
        response: dict[str, Any] | None,
        phase: Literal['pre', 'post'],
        context_msg: str,
        *,
        from_wrap: bool = False,
        kind: Literal['tool', 'llm'] | None = None,
        tool_call_id: str | None = None,
    ) -> None:
        """Raise if the response blocks the action, respecting the violation strategy.

        ``from_wrap`` suppresses the "callback cannot reinject" warning on
        callers that *will* apply the replacement themselves (the
        ``wrap()`` paths). Without this flag, every successful wrap-path
        reinjection would log a WARN claiming the replacement was discarded.

        ``kind`` (``'tool'`` or ``'llm'``) is combined with ``phase`` to form
        the lifecycle string (e.g. ``'pre_tool'``) stamped on the raised
        :class:`GovernanceViolationError` so consumers like
        :class:`BeaconLangGraphAgent` can dispatch on phase. ``tool_call_id``
        is only meaningful for tool-phase blocks.
        """
        lifecycle = cast(GovernancePhase, f'{phase}_{kind}') if kind else None
        # If already stopped, block immediately without calling the API.
        if self._stopped:
            err = GovernanceViolationError(
                message='Agent stopped due to governance violations',
                result={},
                policies=[],
                latency_ms=0.0,
                phase=lifecycle,
                tool_call_id=tool_call_id,
            )
            self._last_violation = err
            raise err

        if response is None:
            logger.debug('Governance enforce skipped: no response (fail-open path)')
            return

        if not from_wrap and response.get('output') is not None:
            warn_key = (context_msg, phase)
            if warn_key not in self._reinjection_warned_keys:
                self._reinjection_warned_keys.add(warn_key)
                logger.warning(
                    'Governance policy returned an `output` replacement for '
                    '%s at %s but this handler is attached as a LangChain '
                    'callback. Callbacks cannot modify tool args, tool output, '
                    'or LLM output — the replacement is being discarded. Use '
                    'BeaconLangGraphGovernanceHandler.wrap(tool_or_chat_model), '
                    'the @governance decorator, or `wrap_tool_node` / '
                    '`wrap_chat_model` from `lumenova_beacon.governance` to '
                    'apply reinjection.',
                    context_msg, phase,
                )

        if not self._is_allowed(response):
            self._violation_count += 1
            rego_message = response.get('message', '')

            msg = f'Governance policy blocked {context_msg} at {phase}'
            if rego_message:
                msg = f'{msg}: {rego_message}'

            logger.debug(
                'Governance BLOCKED: %s at %s | decision=%s rules=%s',
                context_msg,
                phase,
                response.get('decision'),
                response.get('rules_evaluated'),
            )

            # Determine effective strategy.
            strategy = self._on_violation
            if self._max_violations is not None and self._violation_count >= self._max_violations:
                strategy = 'stop'

            if strategy == 'stop':
                self._stopped = True

            err = GovernanceViolationError(
                message=msg,
                result=response,
                policies=response.get('rules_evaluated', []),
                latency_ms=response.get('latency_ms', 0.0),
                phase=lifecycle,
                tool_call_id=tool_call_id,
            )
            self._last_violation = err
            raise err
        logger.debug('Governance ALLOWED: %s at %s', context_msg, phase)

    @staticmethod
    def _truncate(value: str) -> str:
        """Truncate a string for inclusion in evaluation payloads."""
        return truncate(value)

    @staticmethod
    def _get_parameters(input_str: str, kwargs: dict[str, Any]) -> dict[str, Any]:
        """Extract tool arguments as a dict from callback parameters.

        LangChain passes tool args in several ways depending on version
        and tool type.  Try ``kwargs['inputs']``, ``kwargs['tool_input']``,
        then fall back to JSON-parsing ``input_str``.
        """
        parameters = kwargs.get('inputs') or kwargs.get('tool_input')
        if isinstance(parameters, dict) and parameters:
            return parameters
        # Fall back to JSON-parsing the input_str positional argument.
        if isinstance(input_str, str) and input_str:
            try:
                parsed = json.loads(input_str)
                if isinstance(parsed, dict):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                pass
        return {}

    @staticmethod
    def _extract_output_str(output: Any) -> str:
        """Extract a string from a tool output.

        LangChain tool outputs may be ``ToolMessage`` objects (with a
        ``.content`` attribute), plain strings, or arbitrary objects.
        """
        if hasattr(output, 'content'):
            return str(output.content)
        return str(output)

    @staticmethod
    def _extract_last_user_content(messages: list[list[BaseMessage]]) -> str:
        """Walk message batches in reverse to find the last human message."""
        if not messages:
            return ''
        for msg in reversed(messages[0]):
            if msg.type == 'human':
                content = msg.content
                return str(content) if content else ''
        return ''

    # ------------------------------------------------------------------
    # Tool callbacks
    # ------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        **kwargs: Any,
    ) -> None:
        """Pre-execution governance check for tool invocations."""
        tool_call_id = self._extract_tool_call_id(kwargs)
        # Block immediately if stopped.
        if self._stopped:
            err = GovernanceViolationError(
                message='Agent stopped due to governance violations',
                result={},
                policies=[],
                latency_ms=0.0,
                phase='pre_tool',
                tool_call_id=tool_call_id,
            )
            self._last_violation = err
            raise err

        run_id = kwargs.get('run_id')
        name = serialized.get('name') or kwargs.get('name', 'unknown')
        parameters = self._get_parameters(input_str, kwargs)

        if run_id is not None:
            self._runs[str(run_id)] = {
                'tool_name': name,
                'parameters': parameters,
                'tool_call_id': tool_call_id,
            }
        logger.debug(
            'on_tool_start: tool=%s run_id=%s parameters=%s',
            name,
            run_id,
            parameters,
        )

        self._invocation_chain.append({'action': name, 'type': 'tool'})

        if 'pre_tool' not in self._enabled_hooks:
            logger.debug('on_tool_start: pre_tool hook disabled, skipping')
            return

        tool_data: dict[str, Any] = {
            'name': name,
            'parameters': parameters,
        }
        extra = self._build_extra(
            {'tool': tool_data}, parent_run_id=kwargs.get('parent_run_id'),
        )
        resp = self._evaluate_or_fail_open('pre', 'tool', extra)
        self._enforce(
            resp,
            'pre',
            f"tool '{name}'",
            kind='tool',
            tool_call_id=tool_call_id,
        )

    def on_tool_end(
        self,
        output: Any,
        **kwargs: Any,
    ) -> None:
        """Post-execution governance check for tool invocations."""
        run_id = kwargs.get('run_id')
        run_data = self._runs.pop(str(run_id), {}) if run_id else {}
        tool_name = kwargs.get('name') or run_data.get('tool_name', 'unknown')
        tool_call_id = (
            self._extract_tool_call_id(kwargs)
            or run_data.get('tool_call_id')
        )
        output_str = self._extract_output_str(output)

        logger.debug(
            'on_tool_end: tool=%s run_id=%s output_len=%d',
            tool_name,
            run_id,
            len(output_str),
        )

        if 'post_tool' not in self._enabled_hooks:
            logger.debug('on_tool_end: post_tool hook disabled, skipping')
            return

        tool_data: dict[str, Any] = {
            'name': tool_name,
            'parameters': run_data.get('parameters', {}),
            'output': self._truncate(output_str),
        }
        extra = self._build_extra(
            {'tool': tool_data}, parent_run_id=kwargs.get('parent_run_id'),
        )
        resp = self._evaluate_or_fail_open('post', 'tool', extra)
        self._enforce(
            resp,
            'post',
            f"tool '{tool_name}'",
            kind='tool',
            tool_call_id=tool_call_id,
        )

    def on_tool_error(
        self,
        error: BaseException,
        **kwargs: Any,
    ) -> None:
        """Clean up run tracking on tool error."""
        run_id = kwargs.get('run_id')
        logger.debug('on_tool_error: run_id=%s error=%s', run_id, error)
        if run_id is not None:
            self._runs.pop(str(run_id), None)
        # Drop the trailing chain entry so sequence-aware policies don't
        # see a failed tool as if it had completed successfully.
        if self._invocation_chain and self._invocation_chain[-1].get('type') == 'tool':
            self._invocation_chain.pop()

    # ------------------------------------------------------------------
    # LLM callbacks
    # ------------------------------------------------------------------

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        **kwargs: Any,
    ) -> None:
        """Pre-execution governance check for non-chat LLM calls."""
        if self._stopped:
            err = GovernanceViolationError(
                message='Agent stopped due to governance violations',
                result={},
                policies=[],
                latency_ms=0.0,
                phase='pre_llm',
            )
            self._last_violation = err
            raise err

        run_id = kwargs.get('run_id')
        model_name = self._extract_model_name(serialized, **kwargs)
        self._model_call_count += 1
        if run_id is not None:
            self._runs[str(run_id)] = {'model_name': model_name}
        logger.debug(
            'on_llm_start: model=%s run_id=%s call_count=%d',
            model_name,
            run_id,
            self._model_call_count,
        )

        self._invocation_chain.append({'action': model_name, 'type': 'llm'})

        if 'pre_llm' not in self._enabled_hooks:
            logger.debug('on_llm_start: pre_llm hook disabled, skipping')
            return

        last_prompt = prompts[-1] if prompts else ''
        llm_data: dict[str, Any] = {
            'model_name': model_name,
            'last_user_content': self._truncate(last_prompt),
        }
        extra = self._build_extra(
            {'llm': llm_data}, parent_run_id=kwargs.get('parent_run_id'),
        )
        resp = self._evaluate_or_fail_open('pre', 'llm', extra)
        self._enforce(resp, 'pre', f"LLM '{model_name}'", kind='llm')

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[BaseMessage]],
        **kwargs: Any,
    ) -> None:
        """Pre-execution governance check for chat model calls."""
        if self._stopped:
            err = GovernanceViolationError(
                message='Agent stopped due to governance violations',
                result={},
                policies=[],
                latency_ms=0.0,
                phase='pre_llm',
            )
            self._last_violation = err
            raise err

        run_id = kwargs.get('run_id')
        model_name = self._extract_model_name(serialized, **kwargs)
        self._model_call_count += 1

        last_user_content = self._extract_last_user_content(messages)
        if run_id is not None:
            self._runs[str(run_id)] = {
                'model_name': model_name,
                'last_user_content': self._truncate(last_user_content),
            }
        logger.debug(
            'on_chat_model_start: model=%s call_count=%d run_id=%s last_user_content=%s',
            model_name,
            self._model_call_count,
            run_id,
            last_user_content[:200] if last_user_content else '(none)',
        )

        self._invocation_chain.append({'action': model_name, 'type': 'llm'})

        if 'pre_llm' not in self._enabled_hooks:
            logger.debug('on_chat_model_start: pre_llm hook disabled, skipping')
            return

        llm_data: dict[str, Any] = {
            'model_name': model_name,
            'last_user_content': self._truncate(last_user_content),
        }
        extra = self._build_extra(
            {'llm': llm_data}, parent_run_id=kwargs.get('parent_run_id'),
        )
        resp = self._evaluate_or_fail_open('pre', 'llm', extra)
        self._enforce(resp, 'pre', f"LLM '{model_name}'", kind='llm')

    def on_llm_end(
        self,
        response: LLMResult,
        **kwargs: Any,
    ) -> None:
        """Post-execution governance check for LLM calls."""
        run_id = kwargs.get('run_id')
        run_data = self._runs.pop(str(run_id), {}) if run_id else {}

        # Resolve model name with fallbacks (mirrors observability handler).
        model_name = run_data.get('model_name')

        if not model_name or model_name == 'unknown':
            if response.llm_output and isinstance(response.llm_output, dict):
                model_name = response.llm_output.get('model_name') or response.llm_output.get(
                    'model'
                )

        if not model_name or model_name == 'unknown':
            if response.generations and response.generations[0]:
                gen = response.generations[0][0]
                if hasattr(gen, 'message') and hasattr(gen.message, 'response_metadata'):
                    meta = gen.message.response_metadata
                    if meta:
                        model_name = meta.get('model_name') or meta.get('model')

        if not model_name:
            model_name = 'unknown'

        logger.debug(
            'on_llm_end: model=%s run_id=%s call_count=%d',
            model_name,
            run_id,
            self._model_call_count,
        )

        if 'post_llm' not in self._enabled_hooks:
            logger.debug('on_llm_end: post_llm hook disabled, skipping')
            return

        llm_data: dict[str, Any] = {
            'model_name': model_name,
        }

        last_user_content = run_data.get('last_user_content', '')
        if last_user_content:
            llm_data['last_user_content'] = last_user_content

        # Include token usage if available.
        if response.llm_output and isinstance(response.llm_output, dict):
            usage = response.llm_output.get('token_usage') or {}
            if usage:
                llm_data['token_usage'] = {
                    'input_tokens': usage.get('prompt_tokens'),
                    'output_tokens': usage.get('completion_tokens'),
                    'total_tokens': usage.get('total_tokens'),
                }

        extra = self._build_extra(
            {'llm': llm_data}, parent_run_id=kwargs.get('parent_run_id'),
        )
        resp = self._evaluate_or_fail_open('post', 'llm', extra)
        self._enforce(resp, 'post', f"LLM '{model_name}'", kind='llm')

    def on_llm_error(
        self,
        error: BaseException,
        **kwargs: Any,
    ) -> None:
        """Clean up run tracking on LLM error."""
        run_id = kwargs.get('run_id')
        logger.debug('on_llm_error: run_id=%s error=%s', run_id, error)
        if run_id is not None:
            self._runs.pop(str(run_id), None)
        if self._invocation_chain and self._invocation_chain[-1].get('type') == 'llm':
            self._invocation_chain.pop()

    # ------------------------------------------------------------------
    # Chain callbacks (LangGraph node-level state capture)
    # ------------------------------------------------------------------

    @staticmethod
    def _is_node_start(
        metadata: dict[str, Any] | None,
        tags: list[str] | None,
    ) -> bool:
        """Return ``True`` when this chain start is a graph-node boundary.

        Mirrors the tracer's distinction between graph-level node steps
        (tagged ``graph:step:N``, with ``langgraph_*`` metadata keys) and
        the various sub-chains LangChain emits inside a node's
        RunnableSeq (tagged ``seq:step:N``). Capturing state on anything
        other than a node boundary would let inner-chain inputs clobber
        the node's actual state before tools fire.
        """
        has_lg_meta = bool(
            metadata
            and any(
                isinstance(k, str) and k.startswith('langgraph_') for k in metadata
            )
        )
        if not has_lg_meta:
            return False
        tag_list = tags or []
        is_graph_step = any(
            isinstance(t, str) and t.startswith('graph:step:') for t in tag_list
        )
        is_seq_step = any(
            isinstance(t, str) and t.startswith('seq:step:') for t in tag_list
        )
        return is_graph_step and not is_seq_step

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: Any,
        **kwargs: Any,
    ) -> None:
        """Capture LangGraph node state and register the active node."""
        if not self._include_state:
            return
        run_id = kwargs.get('run_id')
        if run_id is None:
            return
        parent_run_id = kwargs.get('parent_run_id')
        metadata = kwargs.get('metadata')
        tags = kwargs.get('tags')

        self._chain_parents[run_id] = parent_run_id

        if not self._is_node_start(metadata, tags):
            return
        if not isinstance(inputs, dict):
            logger.debug(
                'on_chain_start: node-level inputs is %s, not a dict; skipping state capture',
                type(inputs).__name__,
            )
            return

        self._node_state[run_id] = inputs
        node_token = _active_node_run_id.set(run_id)
        handler_token = _active_handler.set(self)
        self._cv_tokens[run_id] = (node_token, handler_token)
        logger.debug(
            'on_chain_start: captured node state for run_id=%s (keys=%s)',
            run_id,
            list(inputs.keys()),
        )

    def on_chain_end(
        self,
        outputs: Any,
        **kwargs: Any,
    ) -> None:
        """Release per-node state at chain completion."""
        if not self._include_state:
            return
        self._release_chain(kwargs.get('run_id'))

    def on_chain_error(
        self,
        error: BaseException,
        **kwargs: Any,
    ) -> None:
        """Release per-node state on chain failure (including GraphInterrupt)."""
        if not self._include_state:
            return
        self._release_chain(kwargs.get('run_id'))

    def _release_chain(self, run_id: UUID | None) -> None:
        if run_id is None:
            return
        self._chain_parents.pop(run_id, None)
        self._node_state.pop(run_id, None)
        tokens = self._cv_tokens.pop(run_id, None)
        if tokens is None:
            return
        node_token, handler_token = tokens
        # `reset()` only succeeds in the same Context that produced the
        # token. Under astream / parallel Send, on_chain_start runs in a
        # copied Context (`run_in_executor(copy_context().run, ...)`)
        # and reset here raises — harmless because the read path uses
        # the LangChain config bridge instead of these ContextVars.
        try:
            _active_node_run_id.reset(node_token)
        except (ValueError, LookupError, RuntimeError) as exc:
            logger.debug(
                'on_chain_end: node ContextVar reset skipped for run_id=%s '
                '(%s) — created in a different Context (expected under '
                'astream_events / parallel Send).',
                run_id, exc,
            )
        try:
            _active_handler.reset(handler_token)
        except (ValueError, LookupError, RuntimeError) as exc:
            logger.debug(
                'on_chain_end: handler ContextVar reset skipped for run_id=%s '
                '(%s) — created in a different Context (expected under '
                'astream_events / parallel Send).',
                run_id, exc,
            )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_model_name(serialized: dict[str, Any], **kwargs: Any) -> str:
        """Extract the model name from serialized LangChain kwargs or invocation_params."""
        model_kwargs = serialized.get('kwargs', {})
        model_name = (
            model_kwargs.get('model_name')
            or model_kwargs.get('model')
            or model_kwargs.get('deployment_name')
        )
        if not model_name:
            invocation_params = kwargs.get('invocation_params', {})
            model_name = (
                invocation_params.get('model_name')
                or invocation_params.get('model')
                or invocation_params.get('azure_deployment')
            )
        return model_name or 'unknown'

    # ------------------------------------------------------------------
    # Content reinjection (handler.wrap)
    # ------------------------------------------------------------------

    def wrap(
        self,
        target: 'BaseTool | BaseChatModel | Sequence[BaseTool]',
    ) -> 'BaseTool | BaseChatModel | list[BaseTool]':
        """Install governance on a tool, chat model, or tool list (in place).

        Unlike callback attachment, which can only observe and block,
        ``wrap()`` rebinds the target's inner callable so the policy's
        ``output`` replacement is actually applied to tool arguments,
        tool output, LLM prompt messages, and LLM output.

        **This mutates the input.** ``BaseTool`` instances have their
        ``func``/``coroutine`` attributes replaced; ``BaseChatModel``
        instances have ``invoke``/``ainvoke`` rebound on the instance.
        Pass a fresh tool/model if you also need an unwrapped reference.
        For a ``Sequence`` input, every element is wrapped in place and
        a new ``list`` of the same elements is returned.

        Wrapping is idempotent: a target already wrapped by this or any
        other ``BeaconLangGraphGovernanceHandler`` is returned unchanged
        with a DEBUG log, instead of double-evaluating governance.

        ``stream`` / ``astream`` on a wrapped chat model are NOT
        rebound — streaming bypasses governance. Callers that need
        governance on streamed output should keep the original model
        and add a post-stream evaluation step themselves, or call
        ``invoke`` / ``ainvoke`` on the wrapped instance.

        The wrapped target shares this handler's state: stack IDs,
        fail-open behaviour, violation counter, stopped flag, and
        invocation chain. Blocking via a wrapped target raises
        :class:`GovernanceViolationError` identically to callback-based
        blocking.
        """
        if isinstance(target, BaseTool):
            return self._wrap_tool(target)
        if isinstance(target, BaseChatModel):
            return self._wrap_chat_model(target)
        if isinstance(target, Sequence) and not isinstance(target, str):
            return [self._wrap_tool(t) for t in target]
        raise TypeError(
            f'handler.wrap() expects a BaseTool, BaseChatModel, or list of '
            f'BaseTools; got {type(target).__name__}'
        )

    def _wrap_tool(self, tool: 'BaseTool') -> 'BaseTool':
        """Install governance on a BaseTool's inner func/coroutine."""
        func_name = tool.name

        if getattr(tool, _GOVERNED_SENTINEL, False):
            logger.debug(
                'handler.wrap(%r) is a no-op: tool is already governed.',
                func_name,
            )
            return tool

        original_func = getattr(tool, 'func', None)
        original_coroutine = getattr(tool, 'coroutine', None)

        if original_func is None and original_coroutine is None:
            raise GovernanceConfigurationError(
                f'handler.wrap({func_name!r}) cannot install governance: '
                f'tool has neither func nor coroutine set. BaseTool '
                f'subclasses that override _run/_arun directly cannot be '
                f'wrapped this way — apply @governance to the inner '
                f'function before building the BaseTool, or expose a '
                f'func/coroutine.'
            )

        handler = self

        if original_func is not None:
            def governed_func(*args: Any, **kwargs: Any) -> Any:
                return handler._run_sync_tool(func_name, original_func, args, kwargs)
            setattr(governed_func, _GOVERNED_SENTINEL, True)
            tool.func = governed_func

        if original_coroutine is not None:
            async def governed_coroutine(*args: Any, **kwargs: Any) -> Any:
                return await handler._run_async_tool(
                    func_name, original_coroutine, args, kwargs,
                )
            setattr(governed_coroutine, _GOVERNED_SENTINEL, True)
            tool.coroutine = governed_coroutine

        # Mark the tool itself so subsequent wrap() calls short-circuit
        # even if a caller ever swaps func/coroutine back.
        try:
            object.__setattr__(tool, _GOVERNED_SENTINEL, True)
        except (AttributeError, TypeError) as exc:
            # Some BaseTool subclasses block extra attribute assignment;
            # the per-callable sentinel above is the fallback. Log so a
            # second wrap() won't quietly double-evaluate against a tool
            # whose func/coroutine got swapped back to an unsentinelled
            # callable.
            logger.debug(
                'handler.wrap(%r): could not stamp instance sentinel '
                '(%s: %s); idempotency relies on per-callable sentinel.',
                func_name, type(exc).__name__, exc,
            )

        return tool

    def _run_sync_tool(
        self,
        tool_name: str,
        inner: Callable[..., Any],
        args: tuple,
        kwargs: dict[str, Any],
    ) -> Any:
        self._raise_if_stopped(phase='pre_tool')
        self._invocation_chain.append({'action': tool_name, 'type': 'tool'})
        call_kwargs = kwargs

        if 'pre_tool' in self._enabled_hooks:
            extra = self._build_extra({
                'tool': {'name': tool_name, 'parameters': dict(call_kwargs)},
            })
            resp = self._evaluate_or_fail_open('pre', 'tool', extra)
            self._enforce(
                resp, 'pre', f"tool '{tool_name}'",
                from_wrap=True, kind='tool',
            )
            outcome = parse_outcome(resp, self._result_parser)
            if outcome.replacement is not None:
                call_kwargs = apply_tool_kwargs_replacement(
                    call_kwargs, outcome.replacement, tool_name=tool_name,
                    target=outcome.target,
                )

        result = inner(*args, **call_kwargs)

        if 'post_tool' in self._enabled_hooks:
            extra = self._build_extra({
                'tool': {
                    'name': tool_name,
                    'parameters': dict(call_kwargs),
                    'output': self._truncate(str(result)),
                },
            })
            resp = self._evaluate_or_fail_open('post', 'tool', extra)
            self._enforce(
                resp, 'post', f"tool '{tool_name}'",
                from_wrap=True, kind='tool',
            )
            outcome = parse_outcome(resp, self._result_parser)
            if outcome.replacement is not None:
                result = apply_tool_return_replacement(result, outcome.replacement)

        return result

    async def _run_async_tool(
        self,
        tool_name: str,
        inner: Callable[..., Any],
        args: tuple,
        kwargs: dict[str, Any],
    ) -> Any:
        self._raise_if_stopped(phase='pre_tool')
        self._invocation_chain.append({'action': tool_name, 'type': 'tool'})
        call_kwargs = kwargs

        trace_id = get_current_trace_id()
        span = get_current_span()
        span_id = span.span_id if span is not None else None

        if 'pre_tool' in self._enabled_hooks:
            extra = self._build_extra({
                'tool': {'name': tool_name, 'parameters': dict(call_kwargs)},
            })
            resp = await aevaluate_or_fail_open(
                self._client, 'pre', 'tool',
                self._stack_ids, self._tags, extra,
                self._timeout, self._fail_open,
                trace_id=trace_id, span_id=span_id,
            )
            self._enforce(
                resp, 'pre', f"tool '{tool_name}'",
                from_wrap=True, kind='tool',
            )
            outcome = parse_outcome(resp, self._result_parser)
            if outcome.replacement is not None:
                call_kwargs = apply_tool_kwargs_replacement(
                    call_kwargs, outcome.replacement, tool_name=tool_name,
                    target=outcome.target,
                )

        result = await inner(*args, **call_kwargs)

        if 'post_tool' in self._enabled_hooks:
            extra = self._build_extra({
                'tool': {
                    'name': tool_name,
                    'parameters': dict(call_kwargs),
                    'output': self._truncate(str(result)),
                },
            })
            resp = await aevaluate_or_fail_open(
                self._client, 'post', 'tool',
                self._stack_ids, self._tags, extra,
                self._timeout, self._fail_open,
                trace_id=trace_id, span_id=span_id,
            )
            self._enforce(
                resp, 'post', f"tool '{tool_name}'",
                from_wrap=True, kind='tool',
            )
            outcome = parse_outcome(resp, self._result_parser)
            if outcome.replacement is not None:
                result = apply_tool_return_replacement(result, outcome.replacement)

        return result

    def _wrap_chat_model(self, model: 'BaseChatModel') -> 'BaseChatModel':
        """Install governance on a BaseChatModel's ``invoke``/``ainvoke``.

        Only the non-streaming entry points are rebound. Two classes of
        method emit a one-time bypass WARN on first call so a silently
        ungoverned path is visible to operators:

        * ``stream`` / ``astream`` / ``batch`` / ``abatch`` — do not
          route through ``invoke`` and so bypass governance entirely.
        * ``bind_tools`` / ``with_structured_output`` / ``bind`` /
          ``configurable_fields`` — these Runnable-composition methods
          return a *new* instance (typically a ``RunnableBinding``) that
          does not carry the governed ``invoke``. Standard LangGraph
          ReAct flows use ``bind_tools(...)`` heavily; the WARN points
          callers at re-wrapping the derived instance.

        Callers that need governance on streamed output or on a derived
        Runnable should wrap the relevant instance themselves, or add a
        post-call evaluation step around the original (unwrapped) model.

        Wrapping is idempotent: a model already wrapped is returned
        unchanged with a DEBUG log.
        """
        if getattr(model, _GOVERNED_SENTINEL, False):
            logger.debug(
                'handler.wrap(%s) is a no-op: chat model is already governed.',
                type(model).__name__,
            )
            return model

        handler = self
        original_invoke = model.invoke
        original_ainvoke = model.ainvoke

        def governed_invoke(input: Any, config: Any = None, **kwargs: Any) -> Any:
            return handler._run_sync_llm(model, original_invoke, input, config, kwargs)

        async def governed_ainvoke(input: Any, config: Any = None, **kwargs: Any) -> Any:
            return await handler._run_async_llm(
                model, original_ainvoke, input, config, kwargs,
            )

        # BaseChatModel is a Pydantic model that blocks direct attribute
        # assignment for names outside its declared fields. Bypass that
        # using `object.__setattr__` so the governed methods replace the
        # class-bound originals on this specific instance. The sequence
        # must be atomic: a partial mutation (invoke governed, ainvoke
        # untouched) silently bypasses governance on the async path —
        # the worst failure mode for a security feature.
        try:
            object.__setattr__(model, 'invoke', governed_invoke)
        except (AttributeError, TypeError) as exc:
            raise GovernanceConfigurationError(
                f'handler.wrap({type(model).__name__}): could not rebind '
                f'invoke ({type(exc).__name__}: {exc}). The chat model '
                f'class blocks instance attribute assignment; governance '
                f'cannot be installed on this instance.'
            ) from exc
        try:
            object.__setattr__(model, 'ainvoke', governed_ainvoke)
        except (AttributeError, TypeError) as exc:
            # Roll back the invoke rebinding so the caller doesn't end up
            # with a half-governed model (sync governed, async bypassing).
            try:
                object.__setattr__(model, 'invoke', original_invoke)
            except (AttributeError, TypeError):
                pass
            raise GovernanceConfigurationError(
                f'handler.wrap({type(model).__name__}): could not rebind '
                f'ainvoke ({type(exc).__name__}: {exc}). Rolled back the '
                f'invoke rebinding so the model is not half-governed.'
            ) from exc

        # Wrap stream/batch entry points with a one-time WARN so a caller
        # who switched from invoke to streaming gets a visible signal
        # that governance is not applied. Best-effort: streaming is
        # already a documented bypass; failure here demotes us from
        # "warn on use" to "no warning" but does not change the
        # governance status of invoke/ainvoke.
        self._install_bypass_warnings(model)

        try:
            object.__setattr__(model, _GOVERNED_SENTINEL, True)
        except (AttributeError, TypeError) as exc:
            # The sentinel is the cross-handler idempotency marker. If we
            # cannot stamp it, a second wrap() call on this same instance
            # would double-evaluate governance (every invoke runs policy
            # twice). Surface so the caller can decide whether to ignore
            # the duplicate evaluation cost or use a different model.
            raise GovernanceConfigurationError(
                f'handler.wrap({type(model).__name__}): invoke/ainvoke '
                f'were rebound but the governed-sentinel could not be '
                f'stamped ({type(exc).__name__}: {exc}); a subsequent '
                f'wrap() on this instance would double-evaluate.'
            ) from exc
        return model

    def _install_bypass_warnings(self, model: 'BaseChatModel') -> None:
        """Wrap streaming and Runnable-composition entry points to emit a
        one-time bypass WARN.

        Two categories of bypass are covered:

        - **Streaming / batching** (``stream``, ``astream``, ``batch``,
          ``abatch``): bypass governance because they don't route through
          ``invoke``. Each shape (sync function, sync generator, coroutine,
          async generator) gets the matching wrapper so iteration
          semantics are preserved. ``inspect`` introspection picks the
          right wrapper; we treat coroutine functions that can be
          ``async for``-iterated as async generators because some
          ``BaseChatModel`` subclasses expose ``astream`` as a coroutine
          returning an async iterator rather than as an async generator
          function directly.
        - **Runnable composition** (``bind_tools``, ``bind``,
          ``with_structured_output``, ``configurable_fields``): return
          *new* Runnable instances that do not carry the governed
          ``invoke``/``ainvoke``. The caller must wrap the derived
          instance themselves; the WARN makes that need visible the
          first time one of these methods is called on a wrapped model.
        """
        import inspect

        warned: set[str] = set()

        def warn_once(name: str, kind: str) -> None:
            if name in warned:
                return
            warned.add(name)
            if kind == 'derive':
                logger.warning(
                    'BaseChatModel.%s() returns a derived Runnable that does '
                    'NOT carry governance — wrap the returned instance with '
                    'the same handler.wrap() / wrap_chat_model() to enforce '
                    'policies on its invoke/ainvoke.',
                    name,
                )
            else:
                logger.warning(
                    'BaseChatModel.%s() bypasses governance — only '
                    'invoke/ainvoke run policy evaluation. Call '
                    'invoke/ainvoke or add a post-call governance step '
                    'around the unwrapped model.',
                    name,
                )

        def wrap_sync(name: str, kind: str, original: Callable[..., Any]) -> Callable[..., Any]:
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                warn_once(name, kind)
                return original(*args, **kwargs)
            return sync_wrapper

        def wrap_sync_gen(name: str, kind: str, original: Callable[..., Any]) -> Callable[..., Any]:
            def sync_gen_wrapper(*args: Any, **kwargs: Any) -> Any:
                warn_once(name, kind)
                yield from original(*args, **kwargs)
            return sync_gen_wrapper

        def wrap_coroutine(name: str, kind: str, original: Callable[..., Any]) -> Callable[..., Any]:
            async def coroutine_wrapper(*args: Any, **kwargs: Any) -> Any:
                warn_once(name, kind)
                return await original(*args, **kwargs)
            return coroutine_wrapper

        def wrap_async_gen(name: str, kind: str, original: Callable[..., Any]) -> Callable[..., Any]:
            async def async_gen_wrapper(*args: Any, **kwargs: Any) -> Any:
                warn_once(name, kind)
                async for item in original(*args, **kwargs):
                    yield item
            return async_gen_wrapper

        # (method_name, kind) — kind 'stream' covers true bypass paths,
        # 'derive' covers methods that return a fresh ungoverned Runnable.
        targets: tuple[tuple[str, str], ...] = (
            ('stream', 'stream'),
            ('astream', 'stream'),
            ('batch', 'stream'),
            ('abatch', 'stream'),
            ('bind_tools', 'derive'),
            ('bind', 'derive'),
            ('with_structured_output', 'derive'),
            ('configurable_fields', 'derive'),
        )
        for name, kind in targets:
            original = getattr(model, name, None)
            if original is None or not callable(original):
                continue
            if inspect.isasyncgenfunction(original):
                wrapped = wrap_async_gen(name, kind, original)
            elif inspect.iscoroutinefunction(original):
                wrapped = wrap_coroutine(name, kind, original)
            elif inspect.isgeneratorfunction(original):
                wrapped = wrap_sync_gen(name, kind, original)
            else:
                wrapped = wrap_sync(name, kind, original)
            try:
                object.__setattr__(model, name, wrapped)
            except (AttributeError, TypeError) as exc:
                logger.warning(
                    'handler.wrap: could not install bypass warning on %s.%s '
                    '(%s: %s); calls to that method will silently bypass '
                    'governance.',
                    type(model).__name__, name, type(exc).__name__, exc,
                )

    def _run_sync_llm(
        self,
        model: 'BaseChatModel',
        inner: Callable[..., Any],
        input: Any,
        config: Any,
        kwargs: dict[str, Any],
    ) -> Any:
        self._raise_if_stopped(phase='pre_llm')
        model_name = self._chat_model_name(model)
        self._model_call_count += 1
        self._invocation_chain.append({'action': model_name, 'type': 'llm'})
        effective_input = input

        if 'pre_llm' in self._enabled_hooks:
            last_user_content = self._extract_last_user_from_input(effective_input)
            extra = self._build_extra({
                'llm': {
                    'model_name': model_name,
                    'last_user_content': self._truncate(last_user_content),
                },
            })
            resp = self._evaluate_or_fail_open('pre', 'llm', extra)
            self._enforce(
                resp, 'pre', f"LLM '{model_name}'",
                from_wrap=True, kind='llm',
            )
            outcome = parse_outcome(resp, self._result_parser)
            if outcome.replacement is not None:
                effective_input = apply_llm_messages_replacement(
                    effective_input, outcome.replacement,
                )

        result = inner(effective_input, config=config, **kwargs)

        if 'post_llm' in self._enabled_hooks:
            extra = self._build_extra({'llm': {'model_name': model_name}})
            resp = self._evaluate_or_fail_open('post', 'llm', extra)
            self._enforce(
                resp, 'post', f"LLM '{model_name}'",
                from_wrap=True, kind='llm',
            )
            outcome = parse_outcome(resp, self._result_parser)
            if outcome.replacement is not None:
                result = apply_llm_return_replacement(result, outcome.replacement)

        return result

    async def _run_async_llm(
        self,
        model: 'BaseChatModel',
        inner: Callable[..., Any],
        input: Any,
        config: Any,
        kwargs: dict[str, Any],
    ) -> Any:
        self._raise_if_stopped(phase='pre_llm')
        model_name = self._chat_model_name(model)
        self._model_call_count += 1
        self._invocation_chain.append({'action': model_name, 'type': 'llm'})
        effective_input = input

        trace_id = get_current_trace_id()
        span = get_current_span()
        span_id = span.span_id if span is not None else None

        if 'pre_llm' in self._enabled_hooks:
            last_user_content = self._extract_last_user_from_input(effective_input)
            extra = self._build_extra({
                'llm': {
                    'model_name': model_name,
                    'last_user_content': self._truncate(last_user_content),
                },
            })
            resp = await aevaluate_or_fail_open(
                self._client, 'pre', 'llm',
                self._stack_ids, self._tags, extra,
                self._timeout, self._fail_open,
                trace_id=trace_id, span_id=span_id,
            )
            self._enforce(
                resp, 'pre', f"LLM '{model_name}'",
                from_wrap=True, kind='llm',
            )
            outcome = parse_outcome(resp, self._result_parser)
            if outcome.replacement is not None:
                effective_input = apply_llm_messages_replacement(
                    effective_input, outcome.replacement,
                )

        result = await inner(effective_input, config=config, **kwargs)

        if 'post_llm' in self._enabled_hooks:
            extra = self._build_extra({'llm': {'model_name': model_name}})
            resp = await aevaluate_or_fail_open(
                self._client, 'post', 'llm',
                self._stack_ids, self._tags, extra,
                self._timeout, self._fail_open,
                trace_id=trace_id, span_id=span_id,
            )
            self._enforce(
                resp, 'post', f"LLM '{model_name}'",
                from_wrap=True, kind='llm',
            )
            outcome = parse_outcome(resp, self._result_parser)
            if outcome.replacement is not None:
                result = apply_llm_return_replacement(result, outcome.replacement)

        return result

    def _raise_if_stopped(
        self,
        *,
        phase: GovernancePhase | None = None,
        tool_call_id: str | None = None,
    ) -> None:
        if self._stopped:
            err = GovernanceViolationError(
                message='Agent stopped due to governance violations',
                result={},
                policies=[],
                latency_ms=0.0,
                phase=phase,
                tool_call_id=tool_call_id,
            )
            self._last_violation = err
            raise err

    @staticmethod
    def _extract_tool_call_id(kwargs: dict[str, Any]) -> str | None:
        """Pull ``tool_call_id`` from LangChain's ``on_tool_*`` callback kwargs.

        LangChain core surfaces the id either as a top-level kwarg
        (``kwargs['tool_call_id']``) or nested inside ``kwargs['inputs']``
        depending on version. Returns ``None`` if neither is present.
        """
        tool_call_id = kwargs.get('tool_call_id')
        if tool_call_id is not None:
            return str(tool_call_id)
        inputs = kwargs.get('inputs')
        if isinstance(inputs, dict):
            nested = inputs.get('tool_call_id')
            if nested is not None:
                return str(nested)
        return None

    @staticmethod
    def _chat_model_name(model: 'BaseChatModel') -> str:
        return (
            getattr(model, 'model_name', None)
            or getattr(model, 'model', None)
            or getattr(model, 'deployment_name', None)
            or type(model).__name__
        )

    @staticmethod
    def _extract_last_user_from_input(input: Any) -> str:
        """Extract the last human-authored text from a chat-model input."""
        if isinstance(input, str):
            return input
        if isinstance(input, BaseMessage):
            return str(input.content) if input.type == 'human' else ''
        if isinstance(input, list):
            for msg in reversed(input):
                if isinstance(msg, BaseMessage) and msg.type == 'human':
                    return str(msg.content) if msg.content else ''
                if isinstance(msg, tuple) and len(msg) == 2 and msg[0] == 'human':
                    return str(msg[1]) if msg[1] else ''
        return ''
