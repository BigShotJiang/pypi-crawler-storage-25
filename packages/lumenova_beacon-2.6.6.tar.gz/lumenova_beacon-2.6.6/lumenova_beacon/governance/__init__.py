"""Beacon governance integration for LangChain/LangGraph agents."""

from lumenova_beacon.governance._state import set_agent_state
from lumenova_beacon.governance.config import GovernanceConfig
from lumenova_beacon.governance.decorators import governance


__all__ = [
    'BeaconLangGraphAgent',
    'BeaconLangGraphGovernanceHandler',
    'GovernanceConfig',
    'governance',
    'set_agent_state',
    'wrap_chat_model',
    'wrap_tool_node',
]


def __getattr__(name: str):  # pragma: no cover - simple lazy import shim
    if name == 'BeaconLangGraphGovernanceHandler':
        from lumenova_beacon.governance.integrations.langchain import (
            BeaconLangGraphGovernanceHandler,
        )
        return BeaconLangGraphGovernanceHandler
    if name == 'BeaconLangGraphAgent':
        from lumenova_beacon.governance.integrations.langgraph_agent import (
            BeaconLangGraphAgent,
        )
        return BeaconLangGraphAgent
    if name in ('wrap_chat_model', 'wrap_tool_node'):
        from lumenova_beacon.governance.integrations import langgraph
        return getattr(langgraph, name)
    raise AttributeError(f'module {__name__!r} has no attribute {name!r}')
