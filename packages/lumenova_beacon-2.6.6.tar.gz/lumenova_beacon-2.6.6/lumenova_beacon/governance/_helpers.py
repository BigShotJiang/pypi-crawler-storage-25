"""Shared helpers for governance evaluation logic.

Used by both the callback handler and the ``@governance`` decorator.
"""

from __future__ import annotations

import logging

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from lumenova_beacon.exceptions import (
    GovernanceError,
    GovernanceReinjectionError,
    GovernanceViolationError,
)
from lumenova_beacon.governance.client import GovernanceClient


logger = logging.getLogger(__name__)

MAX_EXTRA_VALUE_LENGTH = 4096

_KNOWN_DECISIONS = frozenset({'allow', 'block', 'apply_guardrail'})


@dataclass(frozen=True)
class EnforcementOutcome:
    """Result of parsing a governance evaluation response.

    Encodes three legal states: ``allowed=True, replacement=None`` (allow
    unchanged), ``allowed=True, replacement=str`` (allow with substitution,
    optionally targeted by ``target``), or ``allowed=False`` (block; the
    SDK surface raises :class:`GovernanceViolationError`). The constructor
    rejects two illegal combinations: a blocked outcome carrying a
    replacement, and a target without a replacement.
    """

    allowed: bool
    replacement: str | None
    target: str | None = None

    def __post_init__(self) -> None:
        if not self.allowed and self.replacement is not None:
            raise ValueError(
                'EnforcementOutcome: blocked outcomes must not carry a replacement'
            )
        if self.target is not None and self.replacement is None:
            raise ValueError(
                'EnforcementOutcome: target is only meaningful with a replacement'
            )


def get_sdk_version() -> str:
    """Return the SDK version string, or ``'unknown'`` if unavailable."""
    try:
        from lumenova_beacon import __version__

        return __version__
    except ImportError:
        return 'unknown'


def truncate(value: str, max_length: int = MAX_EXTRA_VALUE_LENGTH) -> str:
    """Truncate a string for inclusion in evaluation payloads."""
    if len(value) > max_length:
        return value[:max_length]
    return value


def default_result_parser(result: dict[str, Any]) -> bool:
    """Default result parser for the new flat response format.

    The backend returns ``{"decision": "allow|block|apply_guardrail", ...}``.
    A decision value that is not one of the known canonical strings — or
    a missing ``decision`` key entirely — is treated as ``block`` and a
    WARN is logged so operators can see the policy/SDK contract drift.
    (This is independent of the ``fail_open`` flag, which governs how
    transport-level errors are handled; this branch handles malformed
    *responses*.) Without it, a typo like ``"BLOCK"`` or ``"deny"`` or a
    malformed backend response that omitted ``decision`` would silently
    allow the action through.
    """
    if 'decision' not in result:
        logger.warning(
            'Governance response missing `decision` key (keys=%s); treating as block',
            sorted(result.keys()),
        )
        return False
    decision = result['decision']
    if isinstance(decision, dict):
        # Backward-compat for the old nested format.
        if 'action' not in decision:
            logger.warning(
                'Governance response nested decision missing `action` key; treating as block',
            )
            return False
        nested = decision['action']
        if nested not in _KNOWN_DECISIONS:
            logger.warning(
                'Governance response carried unknown nested decision %r; treating as block',
                nested,
            )
            return False
        return nested != 'block'
    if decision not in _KNOWN_DECISIONS:
        logger.warning(
            'Governance response carried unknown decision %r (expected one of %s); '
            'treating as block',
            decision,
            sorted(_KNOWN_DECISIONS),
        )
        return False
    return decision != 'block'


def is_allowed(
    response: dict[str, Any],
    result_parser: Callable[[dict[str, Any]], bool] | None = None,
) -> bool:
    """Check whether a governance response allows the action."""
    parser = result_parser or default_result_parser
    allowed = parser(response)
    logger.debug(
        'Governance result parsing: response=%s allowed=%s parser=%s',
        response, allowed,
        'custom' if result_parser else 'default',
    )
    return allowed


def evaluate_or_fail_open(
    client: GovernanceClient,
    phase: str,
    type_: str,
    stack_ids: list[str] | None,
    tags: list[str] | None,
    extra: dict[str, Any],
    timeout: float | None,
    fail_open: bool,
    trace_id: str | None = None,
    span_id: str | None = None,
) -> dict[str, Any] | None:
    """Call the governance API; return the response or ``None`` on fail-open."""
    logger.debug(
        'Governance evaluation: phase=%s type=%s stack_ids=%s tags=%s extra_keys=%s',
        phase, type_, stack_ids, tags, list(extra.keys()),
    )
    logger.debug('Governance evaluation extra payload: %s', extra)
    try:
        resp = client.evaluate(
            phase=phase,
            type_=type_,
            stack_ids=stack_ids,
            tags=tags,
            extra=extra,
            timeout=timeout,
            trace_id=trace_id,
            span_id=span_id,
        )
        logger.debug(
            'Governance evaluation succeeded: latency_ms=%s decision=%s',
            resp.get('latency_ms'), resp.get('decision'),
        )
        return resp
    except GovernanceError as e:
        if not fail_open:
            logger.debug('Governance API error (fail-closed), re-raising: %s', e)
            raise
        logger.warning('Governance API error, failing open: %s', e)
        return None


async def aevaluate_or_fail_open(
    client: GovernanceClient,
    phase: str,
    type_: str,
    stack_ids: list[str] | None,
    tags: list[str] | None,
    extra: dict[str, Any],
    timeout: float | None,
    fail_open: bool,
    trace_id: str | None = None,
    span_id: str | None = None,
) -> dict[str, Any] | None:
    """Async version of :func:`evaluate_or_fail_open`."""
    logger.debug(
        'Governance async evaluation: phase=%s type=%s stack_ids=%s tags=%s extra_keys=%s',
        phase, type_, stack_ids, tags, list(extra.keys()),
    )
    logger.debug('Governance async evaluation extra payload: %s', extra)
    try:
        resp = await client.aevaluate(
            phase=phase,
            type_=type_,
            stack_ids=stack_ids,
            tags=tags,
            extra=extra,
            timeout=timeout,
            trace_id=trace_id,
            span_id=span_id,
        )
        logger.debug(
            'Governance async evaluation succeeded: latency_ms=%s decision=%s',
            resp.get('latency_ms'), resp.get('decision'),
        )
        return resp
    except GovernanceError as e:
        if not fail_open:
            logger.debug('Governance async API error (fail-closed), re-raising: %s', e)
            raise
        logger.warning('Governance async API error, failing open: %s', e)
        return None


def parse_outcome(
    response: dict[str, Any] | None,
    result_parser: Callable[[dict[str, Any]], bool] | None = None,
) -> EnforcementOutcome:
    """Parse a governance response into an :class:`EnforcementOutcome`.

    Returns ``allowed=False`` with no replacement for blocked responses,
    ``allowed=True, replacement=None`` when the policy did not specify
    an output, otherwise an allowed outcome carrying the replacement
    string and optional target kwarg name. ``response is None`` represents
    the fail-open path (governance API unreachable) and is treated as
    allowed with no replacement so wrappers pass content through unchanged.
    """
    if response is None:
        return EnforcementOutcome(allowed=True, replacement=None)
    allowed = is_allowed(response, result_parser)
    if not allowed:
        return EnforcementOutcome(allowed=False, replacement=None)
    raw_output = response.get('output')
    if raw_output is None:
        return EnforcementOutcome(allowed=True, replacement=None)
    if not isinstance(raw_output, str):
        # Mirrors the fail-closed contract documented in
        # `_wrapping.py`: every reinjection rule there raises
        # GovernanceReinjectionError when the response shape doesn't
        # admit substitution. Silently allowing the original (potentially
        # sensitive) content through on a malformed `output` would leak
        # the very value the policy meant to replace.
        raise GovernanceReinjectionError(
            f'Governance response `output` must be a string but got '
            f'{type(raw_output).__name__}; refusing to substitute. Either '
            f'fix the policy to emit a string or omit `output` to allow '
            f'the original content through unchanged.'
        )
    raw_target = response.get('output_target')
    target: str | None
    if raw_target is None:
        target = None
    elif isinstance(raw_target, str) and raw_target:
        target = raw_target
    else:
        logger.warning(
            'Governance response `output_target` was invalid (type=%s, empty=%s); ignoring',
            type(raw_target).__name__,
            raw_target == '',
        )
        target = None
    return EnforcementOutcome(allowed=True, replacement=raw_output, target=target)


def enforce(
    response: dict[str, Any] | None,
    phase: str,
    context_msg: str,
    result_parser: Callable[[dict[str, Any]], bool] | None = None,
) -> None:
    """Raise ``GovernanceViolationError`` if the response blocks the action."""
    if response is None:
        logger.debug('Governance enforce skipped: no response (fail-open path)')
        return
    if not is_allowed(response, result_parser):
        rego_message = response.get('message', '')

        msg = f'Governance policy blocked {context_msg} at {phase}'
        if rego_message:
            msg = f'{msg}: {rego_message}'

        logger.debug(
            'Governance BLOCKED: %s at %s | decision=%s rules=%s',
            context_msg, phase, response.get('decision'),
            response.get('rules_evaluated'),
        )
        raise GovernanceViolationError(
            message=msg,
            result=response,
            policies=response.get('rules_evaluated', []),
            latency_ms=response.get('latency_ms', 0.0),
        )
    logger.debug('Governance ALLOWED: %s at %s', context_msg, phase)
