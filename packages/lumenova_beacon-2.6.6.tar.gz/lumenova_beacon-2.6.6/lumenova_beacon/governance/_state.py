"""Agent state capture for governance policies.

Resolution order is documented canonically on
:meth:`BeaconLangGraphGovernanceHandler._resolve_active_state` in
``integrations.langchain``; cross-references in this module defer to it.

Why store ``run_id`` (not the state value) in the ContextVar:
parallel ``Send`` branches each get their own copied Context, so a
state-valued ContextVar would either need per-branch reset gymnastics
or risk one branch reading another's snapshot. Keying state on
``run_id`` and stashing the dict on the shared handler instance lets
the per-task ``var_child_runnable_config`` (which carries the branch's
own run_id) resolve back to the correct branch's state without any
cross-branch coupling.
"""

from __future__ import annotations

import json
import logging

from contextvars import ContextVar
from typing import TYPE_CHECKING, Any, Callable
from uuid import UUID


try:
    from langchain_core.documents import Document  # type: ignore[import-not-found]
    from langchain_core.messages import BaseMessage  # type: ignore[import-not-found]
except ImportError:
    Document = None  # type: ignore[assignment,misc]
    BaseMessage = None  # type: ignore[assignment,misc]


if TYPE_CHECKING:
    from lumenova_beacon.governance.integrations.langchain import (
        BeaconLangGraphGovernanceHandler,
    )


logger = logging.getLogger(__name__)


_DEFAULT_STATE_MAX_BYTES = 32 * 1024
_MAX_SERIALIZATION_DEPTH = 8
_MESSAGE_CONTENT_MAX = 2048


_active_node_run_id: ContextVar[UUID | None] = ContextVar(
    'beacon_active_node_run_id', default=None,
)
_active_handler: ContextVar['BeaconLangGraphGovernanceHandler | None'] = ContextVar(
    'beacon_active_governance_handler', default=None,
)


_var_child_runnable_config: Any = None  # cached ContextVar from langchain_core
_runnable_config_warned = False
_malformed_cfg_warned = False

# Fixed bound for `_chain_parents` walks. Decoupled from `len(_chain_parents)`
# so a concurrent `Send` branch popping entries mid-walk cannot pull the cap
# below a legitimate ancestry depth and trigger a spurious warning.
_CHAIN_PARENTS_WALK_MAX = 1024


def _get_runnable_config_var() -> Any:
    """Return ``var_child_runnable_config`` or ``None``.

    WARN-once only on a true version skew (langchain_core importable
    but the symbol missing). Silent when langchain_core itself is
    absent — every entry path to this function has already imported a
    langchain handler class, so absence at runtime would be a paired
    failure already surfaced upstream.
    """
    global _var_child_runnable_config, _runnable_config_warned
    if _var_child_runnable_config is not None:
        return _var_child_runnable_config
    try:
        from langchain_core.runnables.config import (
            var_child_runnable_config,
        )
    except ImportError as exc:
        if not _runnable_config_warned:
            _runnable_config_warned = True
            try:
                import langchain_core  # noqa: F401
            except ImportError:
                pass
            else:
                logger.warning(
                    'governance: langchain_core is installed but '
                    'var_child_runnable_config is unavailable (%s). '
                    'State propagation under astream / astream_events '
                    'is disabled. Likely a langchain_core version skew.',
                    exc,
                )
        return None
    _var_child_runnable_config = var_child_runnable_config
    return _var_child_runnable_config


def _resolve_active_node() -> tuple[
    'BeaconLangGraphGovernanceHandler | None', UUID | None, UUID | None, bool,
]:
    """Return ``(handler, run_id, parent_run_id, scope_active)`` from the LangChain config bridge — see ``_resolve_active_state``."""
    global _malformed_cfg_warned
    var = _get_runnable_config_var()
    if var is None:
        return None, None, None, False
    cfg = var.get()
    if cfg is None:
        return None, None, None, False
    if not isinstance(cfg, dict):
        if not _malformed_cfg_warned:
            _malformed_cfg_warned = True
            logger.warning(
                'governance: var_child_runnable_config returned a %s, not a '
                'dict. Falling back to local ContextVars. Likely a '
                'langchain_core version skew.',
                type(cfg).__name__,
            )
        # Treat as "no scope" so the local ContextVar fallback runs —
        # the bridge is unusable, but local state may still resolve.
        return None, None, None, False
    manager = cfg.get('callbacks')
    if manager is None:
        if not _malformed_cfg_warned:
            _malformed_cfg_warned = True
            logger.warning(
                'governance: runnable config has no `callbacks` entry '
                '(keys=%s). Falling back to local ContextVars. Likely a '
                'langchain_core version skew.',
                sorted(cfg.keys()),
            )
        return None, None, None, False
    handlers = getattr(manager, 'handlers', None) or []
    # Local import to avoid a circular import: integrations.langchain
    # imports from this module.
    from lumenova_beacon.governance.integrations.langchain import (
        BeaconLangGraphGovernanceHandler,
    )
    handler = next(
        (h for h in handlers if isinstance(h, BeaconLangGraphGovernanceHandler)),
        None,
    )
    run_id = getattr(manager, 'run_id', None)
    parent_run_id = getattr(manager, 'parent_run_id', None)
    return handler, run_id, parent_run_id, True


def set_agent_state(state: dict[str, Any]) -> None:
    """Set/replace the agent state for the enclosing LangGraph node; no-op outside a node, last write wins."""
    handler, run_id = _resolve_active_handler_and_node_run_id()
    if handler is None and run_id is None:
        # No graph context detected — caller is outside a LangGraph node
        # (unit test, plain LangChain agent, etc.). Expected and silent.
        logger.debug(
            'set_agent_state called outside a LangGraph node — no-op',
        )
        return
    if run_id is None:
        # Handler is registered but the walk could not anchor on a node.
        # Means a cycle / walk-cap tripped, or the user called from a
        # context that lost the bridge. The user's state mutation is
        # being discarded — surface at WARN.
        logger.warning(
            'set_agent_state: handler is registered but no enclosing node '
            'could be resolved; dropping state mutation. Likely a '
            '_chain_parents walk-cap (see prior WARN) or a multi-handler '
            'configuration where the bridge picked a different handler.',
        )
        return
    handler.update_node_state(run_id, state)


def _resolve_active_handler_and_node_run_id() -> tuple[
    'BeaconLangGraphGovernanceHandler | None', UUID | None,
]:
    """Return ``(handler, enclosing-node run_id)`` by walking ``_chain_parents`` upward — see ``_resolve_active_state``."""
    handler, run_id, parent_run_id, scope_active = _resolve_active_node()
    if not scope_active:
        if handler is None:
            handler = _active_handler.get()
        if run_id is None:
            run_id = _active_node_run_id.get()
    if handler is None:
        return None, None

    for seed in (run_id, parent_run_id):
        cursor: UUID | None = seed
        steps = 0
        while cursor is not None:
            if cursor in handler._node_state:
                return handler, cursor
            cursor = handler._chain_parents.get(cursor)
            steps += 1
            if steps > _CHAIN_PARENTS_WALK_MAX:
                logger.warning(
                    'governance: _chain_parents walk exceeded %d steps from '
                    'seed=%s; giving up on this seed (cycle or pathological '
                    'chain depth). set_agent_state will be a no-op for this '
                    'call.',
                    _CHAIN_PARENTS_WALK_MAX, seed,
                )
                break
    return handler, None


def lookup_state_for(
    handler: 'BeaconLangGraphGovernanceHandler | None',
    run_id: UUID | None,
) -> dict[str, Any] | None:
    """Return state for the closest node ancestor of ``run_id`` by walking ``_chain_parents``, or ``None``."""
    if handler is None or run_id is None:
        return None
    cursor: UUID | None = run_id
    steps = 0
    while cursor is not None:
        state = handler.get_node_state(cursor)
        if state is not None:
            return state
        cursor = handler._chain_parents.get(cursor)
        steps += 1
        if steps > _CHAIN_PARENTS_WALK_MAX:
            logger.warning(
                'governance: _chain_parents walk exceeded %d steps from '
                'run_id=%s; giving up (cycle or pathological chain depth).',
                _CHAIN_PARENTS_WALK_MAX, run_id,
            )
            return None
    return None


def serialize_state(
    raw: Any,
    state_filter: Callable[[dict[str, Any]], dict[str, Any]] | None,
    state_max_bytes: int,
) -> dict[str, Any] | None:
    """Apply ``state_filter``, JSON-coerce, and budget-cap; return ``None`` when not a mapping (Rego distinguishes absent from ``{}``), or a truncation marker dict when over budget."""
    if not isinstance(raw, dict):
        return None

    try:
        filtered = state_filter(raw) if state_filter is not None else raw
    except Exception:
        # The user installed state_filter to redact PII before state leaves
        # the process. Sending raw state on filter failure would defeat that
        # contract, so omit state entirely and warn loudly. Note: omitting
        # `input.context.state` is not equivalent to sending an empty dict
        # — Rego's `not input.context.state.X` evaluates to *true* when
        # state is absent (negation of an undefined ref). Policies that
        # negate against state may flip allow/block on filter failure.
        logger.warning(
            'state_filter raised; omitting `input.context.state` from this '
            'evaluation. Policies that negate against state fields may '
            'evaluate differently. Install a defensive filter or set '
            'include_state=False.',
            exc_info=True,
        )
        return None

    if not isinstance(filtered, dict):
        logger.warning(
            'state_filter returned a non-dict (%s); skipping state',
            type(filtered).__name__,
        )
        return None

    safe = _serialize_for_json(filtered)
    if not isinstance(safe, dict):
        return None

    encoded = json.dumps(safe, default=str)
    if len(encoded.encode('utf-8')) > state_max_bytes:
        return {
            '_state_truncated': True,
            '_state_size_bytes': len(encoded.encode('utf-8')),
        }
    return safe


def _serialize_for_json(
    obj: Any,
    *,
    _depth: int = 0,
    _seen: set[int] | None = None,
) -> Any:
    """JSON-coerce a value; deliberately diverges from the tracer's serializer (smaller BaseMessage shape, 2 KiB content truncation) to fit the governance budget."""
    if _depth > _MAX_SERIALIZATION_DEPTH:
        return '<max depth exceeded>'

    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj

    if isinstance(obj, UUID):
        return str(obj)

    if _seen is None:
        _seen = set()
    obj_id = id(obj)
    if obj_id in _seen:
        return '<circular reference>'
    _seen.add(obj_id)

    def recurse(value: Any) -> Any:
        return _serialize_for_json(value, _depth=_depth + 1, _seen=_seen)

    try:
        if BaseMessage is not None and isinstance(obj, BaseMessage):
            content = obj.content if hasattr(obj, 'content') else str(obj)
            text = str(content)
            if len(text) > _MESSAGE_CONTENT_MAX:
                text = text[:_MESSAGE_CONTENT_MAX] + '…'
            result: dict[str, Any] = {
                'type': obj.type if hasattr(obj, 'type') else 'unknown',
                'content': text,
            }
            tool_calls = getattr(obj, 'tool_calls', None)
            if tool_calls:
                result['tool_calls'] = recurse(tool_calls)
            tool_call_id = getattr(obj, 'tool_call_id', None)
            if tool_call_id:
                result['tool_call_id'] = tool_call_id
            return result

        if Document is not None and isinstance(obj, Document):
            return {
                'page_content': obj.page_content,
                'metadata': recurse(getattr(obj, 'metadata', {})),
            }

        if isinstance(obj, dict):
            return {str(k): recurse(v) for k, v in obj.items()}

        if isinstance(obj, (list, tuple, set)):
            return [recurse(item) for item in obj]

        if hasattr(obj, 'model_dump'):
            # Narrow the catch to the documented Pydantic v1/v2 incompatibility
            # surfaces (TypeError: bad signature, ValueError: validation,
            # AttributeError: missing helper) so genuine framework bugs
            # (RecursionError, MemoryError, KeyboardInterrupt) propagate
            # instead of being demoted to a str() fallback.
            try:
                return recurse(obj.model_dump(mode='json'))
            except (TypeError, ValueError, AttributeError):
                logger.debug(
                    'state serializer: model_dump(mode="json") failed for %s; '
                    'trying model_dump() without mode',
                    type(obj).__name__, exc_info=True,
                )
                try:
                    return recurse(obj.model_dump())
                except (TypeError, ValueError, AttributeError):
                    logger.debug(
                        'state serializer: model_dump() also failed for %s; '
                        'falling through',
                        type(obj).__name__, exc_info=True,
                    )
        if hasattr(obj, 'dict'):
            try:
                return recurse(obj.dict())
            except (TypeError, ValueError, AttributeError):
                logger.debug(
                    'state serializer: .dict() failed for %s; falling back to str()',
                    type(obj).__name__, exc_info=True,
                )

        try:
            return str(obj)
        except Exception:
            # Reaching this branch means __str__ itself raised — the object
            # is deeply broken and policies will see only a placeholder.
            # Surface at WARN so the operator can investigate; a DEBUG log
            # would let a critical state-payload corruption pass silently.
            logger.warning(
                'state serializer: str() failed for %s; emitting placeholder. '
                'Policies will not see this field\'s value.',
                type(obj).__name__, exc_info=True,
            )
            return f'<unserializable {type(obj).__name__}>'
    finally:
        _seen.discard(obj_id)


__all__ = [
    'lookup_state_for',
    'serialize_state',
    'set_agent_state',
]
