# SPDX-License-Identifier: AGPL-3.0-or-later
# Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SCPN Phase Orchestrator — JAX-accelerated UPDE engine

"""GPU-accelerated Kuramoto solver via JAX JIT compilation.

Raises ImportError if JAX is not installed. Check HAS_JAX before use.
Usage:
    from scpn_phase_orchestrator.upde.jax_engine import HAS_JAX
    if HAS_JAX:
        from scpn_phase_orchestrator.upde.jax_engine import JaxUPDEEngine
        engine = JaxUPDEEngine(n, dt=0.01)
"""

from __future__ import annotations

from math import isfinite
from numbers import Integral, Real
from typing import TYPE_CHECKING, TypeAlias

import numpy as np
from numpy.typing import NDArray

__all__ = ["JaxUPDEEngine", "HAS_JAX"]

FloatArray: TypeAlias = NDArray[np.float64]

TWO_PI = 2.0 * np.pi

try:
    import jax.numpy as jnp  # pragma: no cover
    from jax import jit  # pragma: no cover

    HAS_JAX = True  # pragma: no cover
except ImportError:  # pragma: no cover
    HAS_JAX = False  # pragma: no cover

if TYPE_CHECKING:
    import jax.numpy as jnp


def _validate_positive_int(value: object, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral) or value < 1:
        raise ValueError(f"{name} must be a positive integer, got {value!r}")
    return int(value)


def _validate_positive_float(value: object, *, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite positive real, got {value!r}")
    value = float(value)
    if not isfinite(value) or value <= 0.0:
        raise ValueError(f"{name} must be a finite positive real, got {value!r}")
    return value


def _validate_finite_float(value: object, *, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite real, got {value!r}")
    value = float(value)
    if not isfinite(value):
        raise ValueError(f"{name} must be a finite real, got {value!r}")
    return value


def _validate_array(value: object, *, name: str, shape: tuple[int, ...]) -> FloatArray:
    try:
        array = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a finite array with shape {shape}") from exc
    if array.shape != shape:
        raise ValueError(f"{name} shape must be {shape}, got {array.shape}")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} must contain only finite values")
    return np.ascontiguousarray(array, dtype=np.float64)


def _validate_method(value: object) -> str:
    if not isinstance(value, str) or value not in ("euler", "rk4"):
        raise ValueError(f"unsupported method {value!r}")
    return value


# type ignore: JAX tracer callables need dynamic signatures for jit wrapping.
def _build_jax_step():  # type: ignore[no-untyped-def]  # pragma: no cover
    """Build JIT-compiled Kuramoto step function."""

    @jit
    # type ignore: JAX tracer callable signatures are intentionally dynamic.
    def _kuramoto_step(phases, omegas, knm, zeta, psi, alpha, dt):  # type: ignore[no-untyped-def]
        diff = phases[jnp.newaxis, :] - phases[:, jnp.newaxis]
        coupling = jnp.sum(knm * jnp.sin(diff - alpha), axis=1)
        dphi = omegas + coupling
        dphi = dphi + zeta * jnp.sin(psi - phases)
        new_phases = phases + dt * dphi
        return new_phases % (2.0 * jnp.pi)

    @jit
    # type ignore: JAX tracer callable signatures are intentionally dynamic.
    def _kuramoto_rk4(phases, omegas, knm, zeta, psi, alpha, dt):  # type: ignore[no-untyped-def]
        # type ignore: nested derivative keeps JAX tracer polymorphism.
        def deriv(p):  # type: ignore[no-untyped-def]
            """Kuramoto coupling derivative at given phases."""
            diff = p[jnp.newaxis, :] - p[:, jnp.newaxis]
            coupling = jnp.sum(knm * jnp.sin(diff - alpha), axis=1)
            return omegas + coupling + zeta * jnp.sin(psi - p)

        k1 = deriv(phases)
        k2 = deriv(phases + 0.5 * dt * k1)
        k3 = deriv(phases + 0.5 * dt * k2)
        k4 = deriv(phases + dt * k3)
        new_phases = phases + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
        return new_phases % (2.0 * jnp.pi)

    return _kuramoto_step, _kuramoto_rk4


# type ignore: JAX tracer callables need dynamic signatures for jit wrapping.
def _build_jax_sl_step():  # type: ignore[no-untyped-def]  # pragma: no cover
    """Build JIT-compiled Stuart-Landau step function."""

    @jit
    # type ignore: JAX tracer callable signatures are intentionally dynamic.
    def _sl_rk4(state, omegas, mu, knm, knm_r, zeta, psi, alpha, epsilon, dt):  # type: ignore[no-untyped-def]
        n = omegas.shape[0]

        # type ignore: nested derivative keeps JAX tracer polymorphism.
        def deriv(s):  # type: ignore[no-untyped-def]
            """Stuart-Landau coupled (phase, amplitude) derivative."""
            th, am = s[:n], s[n:]
            diff = th[jnp.newaxis, :] - th[:, jnp.newaxis]
            phase_coupling = jnp.sum(knm * jnp.sin(diff - alpha), axis=1)
            amp_coupling = jnp.sum(
                knm_r * jnp.maximum(am, 0.0)[jnp.newaxis, :] * jnp.cos(diff - alpha),
                axis=1,
            )
            dtheta = omegas + phase_coupling + zeta * jnp.sin(psi - th)
            dr = (mu - am * am) * am + epsilon * amp_coupling
            return jnp.concatenate([dtheta, dr])

        k1 = deriv(state)
        k2 = deriv(state + 0.5 * dt * k1)
        k3 = deriv(state + 0.5 * dt * k2)
        k4 = deriv(state + dt * k3)
        new_state = state + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
        new_theta = new_state[:n] % (2.0 * jnp.pi)
        new_r = jnp.maximum(new_state[n:], 0.0)
        return jnp.concatenate([new_theta, new_r])

    return _sl_rk4


class JaxUPDEEngine:  # pragma: no cover
    """JAX-accelerated Kuramoto/UPDE integrator.

    GPU-compiled via jax.jit. First call triggers XLA compilation
    (~1-3s), subsequent calls run at native speed.
    """

    def __init__(self, n: int, dt: float = 0.01, method: str = "rk4") -> None:
        if not HAS_JAX:
            msg = "JAX not installed. Install with: pip install jax jaxlib"
            raise ImportError(msg)
        self._n = _validate_positive_int(n, name="n")
        self._dt = _validate_positive_float(dt, name="dt")
        self._method = _validate_method(method)
        euler_fn, rk4_fn = _build_jax_step()
        self._euler = euler_fn
        self._rk4 = rk4_fn

    def step(
        self,
        phases: FloatArray,
        omegas: FloatArray,
        knm: FloatArray,
        zeta: float,
        psi: float,
        alpha: FloatArray,
    ) -> FloatArray:
        """Advance phases by one Kuramoto step on GPU via JIT-compiled JAX."""
        phases = _validate_array(phases, name="phases", shape=(self._n,))
        omegas = _validate_array(omegas, name="omegas", shape=(self._n,))
        knm = _validate_array(knm, name="knm", shape=(self._n, self._n))
        alpha = _validate_array(alpha, name="alpha", shape=(self._n, self._n))
        zeta = _validate_finite_float(zeta, name="zeta")
        psi = _validate_finite_float(psi, name="psi")

        jp = jnp.asarray(phases)
        jo = jnp.asarray(omegas)
        jk = jnp.asarray(knm)
        ja = jnp.asarray(alpha)

        if self._method == "rk4":
            result = self._rk4(jp, jo, jk, zeta, psi, ja, self._dt)
        else:
            result = self._euler(jp, jo, jk, zeta, psi, ja, self._dt)

        return np.asarray(result)


class JaxStuartLandauEngine:  # pragma: no cover
    """JAX-accelerated Stuart-Landau integrator (RK4 only)."""

    def __init__(self, n: int, dt: float = 0.01) -> None:
        if not HAS_JAX:
            msg = "JAX not installed. Install with: pip install jax jaxlib"
            raise ImportError(msg)
        self._n = _validate_positive_int(n, name="n")
        self._dt = _validate_positive_float(dt, name="dt")
        self._sl_rk4 = _build_jax_sl_step()

    def step(
        self,
        state: FloatArray,
        omegas: FloatArray,
        mu: FloatArray,
        knm: FloatArray,
        knm_r: FloatArray,
        zeta: float,
        psi: float,
        alpha: FloatArray,
        epsilon: float = 1.0,
    ) -> FloatArray:
        """Advance Stuart-Landau state by one RK4 step via JIT-compiled JAX."""
        state = _validate_array(state, name="state", shape=(2 * self._n,))
        omegas = _validate_array(omegas, name="omegas", shape=(self._n,))
        mu = _validate_array(mu, name="mu", shape=(self._n,))
        knm = _validate_array(knm, name="knm", shape=(self._n, self._n))
        knm_r = _validate_array(knm_r, name="knm_r", shape=(self._n, self._n))
        alpha = _validate_array(alpha, name="alpha", shape=(self._n, self._n))
        zeta = _validate_finite_float(zeta, name="zeta")
        psi = _validate_finite_float(psi, name="psi")
        epsilon = _validate_finite_float(epsilon, name="epsilon")

        js = jnp.asarray(state)
        result = self._sl_rk4(
            js,
            jnp.asarray(omegas),
            jnp.asarray(mu),
            jnp.asarray(knm),
            jnp.asarray(knm_r),
            zeta,
            psi,
            jnp.asarray(alpha),
            epsilon,
            self._dt,
        )
        return np.asarray(result)
