# SPDX-License-Identifier: AGPL-3.0-or-later
# Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SCPN Phase Orchestrator — Stuart-Landau oscillator model

from __future__ import annotations

import threading
from numbers import Integral, Real
from typing import TypeAlias

import numpy as np
from numpy.typing import NDArray

from scpn_phase_orchestrator._compat import TWO_PI

__all__ = ["StuartLandauEngine"]

# Type alias for the ODE parameter bundle passed to _derivative
FloatArray: TypeAlias = NDArray[np.float64]
_Params = tuple[
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    float,
    float,
    FloatArray,
    float,
]
_ValidatedStep = tuple[
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    float,
    float,
    FloatArray,
    float,
]


def _validate_positive_int(value: object, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral) or value < 1:
        raise ValueError(f"{name} must be >= 1 as a non-boolean integer, got {value!r}")
    return int(value)


def _validate_positive_float(value: object, *, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be positive finite real, got {value!r}")
    coerced = float(value)
    if not np.isfinite(coerced) or coerced <= 0.0:
        raise ValueError(f"{name} must be positive finite real, got {value!r}")
    return coerced


def _validate_finite_float(value: object, *, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be finite real, got {value!r}")
    coerced = float(value)
    if not np.isfinite(coerced):
        raise ValueError(f"{name} must be finite real, got {value!r}")
    return coerced


def _validate_phase_drive_float(value: object, *, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"zeta and psi must be finite; {name} got {value!r}")
    coerced = float(value)
    if not np.isfinite(coerced):
        raise ValueError(f"zeta and psi must be finite; {name} got {value!r}")
    return coerced


def _validate_state_array(
    value: object,
    *,
    name: str,
    shape: tuple[int, ...],
    finite_message: str,
) -> FloatArray:
    try:
        arr = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a finite float array") from exc
    if arr.shape != shape:
        expected = ", ".join(str(part) for part in shape)
        raise ValueError(f"{name}.shape={arr.shape}, expected ({expected},)")
    if not np.all(np.isfinite(arr)):
        raise ValueError(finite_message)
    return np.ascontiguousarray(arr, dtype=np.float64)


class StuartLandauEngine:
    """Coupled Stuart-Landau (phase-amplitude) integrator.

    State vector layout: state[:n] = phases θ, state[n:] = amplitudes r.

    Phase ODE (Acebrón et al. 2005, Rev. Mod. Phys. 77(1)):
        dθ_i/dt = ω_i + Σ_j K_ij sin(θ_j - θ_i - α_ij) + ζ sin(Ψ - θ_i)

    Amplitude ODE:
        dr_i/dt = (μ_i - r_i²)·r_i + ε Σ_j K^r_ij · r_j · cos(θ_j - θ_i - α_ij)
    """

    # Dormand-Prince (1980) Butcher tableau — same as UPDEEngine
    _DP_A = np.array(
        [
            [0, 0, 0, 0, 0, 0, 0],
            [1 / 5, 0, 0, 0, 0, 0, 0],
            [3 / 40, 9 / 40, 0, 0, 0, 0, 0],
            [44 / 45, -56 / 15, 32 / 9, 0, 0, 0, 0],
            [19372 / 6561, -25360 / 2187, 64448 / 6561, -212 / 729, 0, 0, 0],
            [9017 / 3168, -355 / 33, 46732 / 5247, 49 / 176, -5103 / 18656, 0, 0],
            [35 / 384, 0, 500 / 1113, 125 / 192, -2187 / 6784, 11 / 84, 0],
        ]
    )
    _DP_B4 = np.array(
        [5179 / 57600, 0, 7571 / 16695, 393 / 640, -92097 / 339200, 187 / 2100, 1 / 40]
    )
    _DP_B5 = np.array([35 / 384, 0, 500 / 1113, 125 / 192, -2187 / 6784, 11 / 84, 0])
    _DP_C = np.array([0, 1 / 5, 3 / 10, 4 / 5, 8 / 9, 1, 1])

    def __init__(
        self,
        n_oscillators: int,
        dt: float,
        method: str = "euler",
        atol: float = 1e-6,
        rtol: float = 1e-3,
    ):
        n_oscillators = _validate_positive_int(
            n_oscillators,
            name="n_oscillators",
        )
        dt = _validate_positive_float(dt, name="dt")
        atol = _validate_positive_float(atol, name="atol")
        rtol = _validate_positive_float(rtol, name="rtol")
        if method not in ("euler", "rk4", "rk45"):
            msg = f"Unknown method {method!r}, expected 'euler', 'rk4', or 'rk45'"
            raise ValueError(msg)
        self._n = n_oscillators
        self._dt = dt
        self._method = method
        self._atol = atol
        self._rtol = rtol
        self._last_dt = dt

        self._use_rust = False
        try:  # pragma: no cover
            import spo_kernel  # noqa: PLC0415

            self._rust = spo_kernel.PyStuartLandauStepper(
                n_oscillators, dt=dt, method=method, n_substeps=1, atol=atol, rtol=rtol
            )
            self._use_rust = True
        except ImportError:  # pragma: no cover — Rust FFI optional
            pass

        n = n_oscillators
        self._phase_diff = np.empty((n, n), dtype=np.float64)
        self._sin_diff = np.empty((n, n), dtype=np.float64)
        self._cos_diff = np.empty((n, n), dtype=np.float64)
        self._scratch_dtheta = np.empty(n, dtype=np.float64)
        self._scratch_dr = np.empty(n, dtype=np.float64)
        self._scratch_deriv = np.empty(2 * n, dtype=np.float64)

        if method == "rk45":
            self._ks = [np.empty(2 * n, dtype=np.float64) for _ in range(7)]
            self._err_buf = np.empty(2 * n, dtype=np.float64)

        # Serialise concurrent step() callers on this instance so the
        # pre-allocated scratch arrays above are not shared across threads.
        self._lock = threading.RLock()

    @property
    def last_dt(self) -> float:
        """Last accepted timestep (adapts with RK45)."""
        return self._last_dt

    def step(
        self,
        state: FloatArray,
        omegas: FloatArray,
        mu: FloatArray,
        knm: FloatArray,
        knm_r: FloatArray,
        zeta: float,
        psi: float,
        alpha: FloatArray,
        epsilon: float = 1.0,
    ) -> FloatArray:
        """Advance (θ, r) by one timestep. Returns new state (2N,)."""
        (
            state,
            omegas,
            mu,
            knm,
            knm_r,
            zeta,
            psi,
            alpha,
            epsilon,
        ) = self._validate(state, omegas, mu, knm, knm_r, zeta, psi, alpha, epsilon)
        with self._lock:
            if self._use_rust:  # pragma: no cover
                result = np.asarray(
                    self._rust.step(
                        state,
                        omegas,
                        mu,
                        knm.ravel(),
                        knm_r.ravel(),
                        zeta,
                        psi,
                        alpha.ravel(),
                        epsilon,
                    )
                )
                self._last_dt = self._rust.last_dt
                return result
            p: _Params = (omegas, mu, knm, knm_r, zeta, psi, alpha, epsilon)
            if self._method == "euler":
                return self._euler_step(state, p)
            if self._method == "rk45":
                return self._rk45_step(state, p)
            return self._rk4_step(state, p)

    def compute_order_parameter(self, state: FloatArray) -> tuple[float, float]:
        """Amplitude-weighted Kuramoto: Z = mean(r_i · exp(i·θ_i))."""
        n = self._n
        z = np.mean(state[n:] * np.exp(1j * state[:n]))
        return float(np.abs(z)), float(np.angle(z) % TWO_PI)

    def compute_mean_amplitude(self, state: FloatArray) -> float:
        """Mean amplitude across all oscillators."""
        return float(np.mean(state[self._n :]))

    def _validate(
        self,
        state: FloatArray,
        omegas: FloatArray,
        mu: FloatArray,
        knm: FloatArray,
        knm_r: FloatArray,
        zeta: float,
        psi: float,
        alpha: FloatArray,
        epsilon: float = 1.0,
    ) -> _ValidatedStep:
        n = self._n
        state = _validate_state_array(
            state,
            name="state",
            shape=(2 * n,),
            finite_message="state contains NaN or Inf",
        )
        omegas = _validate_state_array(
            omegas,
            name="omegas",
            shape=(n,),
            finite_message="omegas contain NaN/Inf",
        )
        mu = _validate_state_array(
            mu,
            name="mu",
            shape=(n,),
            finite_message="mu contains NaN/Inf",
        )
        knm = _validate_state_array(
            knm,
            name="knm",
            shape=(n, n),
            finite_message="knm contains NaN/Inf",
        )
        knm_r = _validate_state_array(
            knm_r,
            name="knm_r",
            shape=(n, n),
            finite_message="knm_r contains NaN/Inf",
        )
        alpha = _validate_state_array(
            alpha,
            name="alpha",
            shape=(n, n),
            finite_message="alpha contains NaN/Inf",
        )
        zeta = _validate_phase_drive_float(zeta, name="zeta")
        psi = _validate_phase_drive_float(psi, name="psi")
        epsilon = _validate_finite_float(epsilon, name="epsilon")
        return state, omegas, mu, knm, knm_r, zeta, psi, alpha, epsilon

    def _derivative(self, state: FloatArray, p: _Params) -> FloatArray:
        omegas, mu, knm, knm_r, zeta, psi, alpha, epsilon = p
        n = self._n
        theta = state[:n]
        r = state[n:]

        np.subtract(
            theta[np.newaxis, :],
            theta[:, np.newaxis],
            out=self._phase_diff,
        )

        # Phase coupling: Sakaguchi-Kuramoto dθ/dt term
        np.sin(self._phase_diff - alpha, out=self._sin_diff)
        np.sum(knm * self._sin_diff, axis=1, out=self._scratch_dtheta)
        self._scratch_dtheta += omegas
        if zeta != 0.0:
            self._scratch_dtheta += zeta * np.sin(psi - theta)

        # Clamp r >= 0 for coupling: intermediate RK stages can produce
        # negative amplitudes that flip the coupling sign (P1-1 audit fix).
        r_clamped = np.maximum(r, 0.0)

        # Amplitude coupling: ε Σ K^r_ij r_j cos(θ_j - θ_i - α_ij)
        # cos term: in-phase neighbours amplify, anti-phase suppress
        np.cos(self._phase_diff - alpha, out=self._cos_diff)
        np.sum(
            knm_r * self._cos_diff * r_clamped[np.newaxis, :],
            axis=1,
            out=self._scratch_dr,
        )
        self._scratch_dr *= epsilon
        # Stuart-Landau normal form: (μ - r²)r is the Hopf term
        # μ > 0 → supercritical bifurcation, stable limit cycle r=√μ
        self._scratch_dr += (mu - r * r) * r

        self._scratch_deriv[:n] = self._scratch_dtheta
        self._scratch_deriv[n:] = self._scratch_dr
        return self._scratch_deriv

    def _post_step(self, state: FloatArray) -> FloatArray:
        n = self._n
        state[:n] %= TWO_PI  # Phase on S¹
        np.maximum(state[n:], 0.0, out=state[n:])  # r >= 0 (physical amplitude)
        return state

    def _euler_step(self, state: FloatArray, p: _Params) -> FloatArray:
        deriv = self._derivative(state, p)
        return self._post_step(state + self._dt * deriv)

    def _rk4_step(self, state: FloatArray, p: _Params) -> FloatArray:
        dt = self._dt
        k1 = self._derivative(state, p).copy()
        k2 = self._derivative(state + 0.5 * dt * k1, p).copy()
        k3 = self._derivative(state + 0.5 * dt * k2, p).copy()
        k4 = self._derivative(state + dt * k3, p)
        weighted = k1 + 2.0 * k2 + 2.0 * k3 + k4
        return self._post_step(state + (dt / 6.0) * weighted)

    def _rk45_step(self, state: FloatArray, p: _Params) -> FloatArray:
        dt = self._last_dt
        A = self._DP_A
        ks = self._ks
        max_reject = 3

        for _ in range(max_reject + 1):
            ks[0][:] = self._derivative(state, p)
            for i in range(1, 7):
                stage = state + dt * np.dot(A[i, :i], np.array(ks[:i]))
                ks[i][:] = self._derivative(stage, p)

            ks_arr = np.array(ks)
            y5 = state + dt * np.dot(self._DP_B5, ks_arr)
            y4 = state + dt * np.dot(self._DP_B4, ks_arr)

            np.subtract(y5, y4, out=self._err_buf)
            np.abs(self._err_buf, out=self._err_buf)
            scale = self._atol + self._rtol * np.maximum(np.abs(state), np.abs(y5))
            err_norm = float(np.max(self._err_buf / scale))

            if err_norm <= 1.0:
                # PI controller: exponent -1/5 for 5th-order method
                factor = min(5.0, 0.9 * err_norm ** (-0.2)) if err_norm > 0.0 else 5.0
                self._last_dt = min(dt * factor, self._dt * 10.0)
                return self._post_step(y5.copy())

            factor = max(0.2, 0.9 * err_norm ** (-0.25))  # pragma: no cover
            dt = dt * factor  # pragma: no cover

        self._last_dt = dt  # pragma: no cover
        return self._post_step(y5.copy())  # pragma: no cover
