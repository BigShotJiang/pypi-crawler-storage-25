# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ServiceAccountUpdateParams"]


class ServiceAccountUpdateParams(TypedDict, total=False):
    organization_id: Required[str]
    """Organization ID or label identifier"""

    description: str
    """Optional description of the service account"""

    name: str
    """Service account name"""

    x_client_request_id: Annotated[str, PropertyInfo(alias="X-Client-Request-ID")]
