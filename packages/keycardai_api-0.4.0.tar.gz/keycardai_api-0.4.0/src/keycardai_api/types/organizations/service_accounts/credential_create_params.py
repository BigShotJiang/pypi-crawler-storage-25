# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from ...._utils import PropertyInfo

__all__ = ["CredentialCreateParams"]


class CredentialCreateParams(TypedDict, total=False):
    organization_id: Required[str]
    """Organization ID or label identifier"""

    name: Required[str]
    """Credential name"""

    description: str
    """Optional description of the credential"""

    x_client_request_id: Annotated[str, PropertyInfo(alias="X-Client-Request-ID")]
