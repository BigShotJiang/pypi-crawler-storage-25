"""Type definitions for the Veto SDK.

Mirrors @veto/shared types from the TypeScript SDK.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional


AgentStatus = Literal["active", "suspended", "revoked"]
AuthorizationOutcome = Literal["allowed", "denied", "escalated"]


@dataclass
class Agent:
    id: str
    name: str
    description: Optional[str]
    workspace_id: str
    status: AgentStatus
    created_at: str
    updated_at: str


@dataclass
class ParameterConstraint:
    regex: Optional[str] = None
    enum: Optional[List[str]] = None
    min: Optional[float] = None
    max: Optional[float] = None


@dataclass
class RateLimitConfig:
    max_calls: int
    window_seconds: int
    current_count: Optional[int] = None


@dataclass
class TimeWindowConfig:
    allowed_hours: Optional[List[int]] = None
    allowed_days: Optional[List[int]] = None
    timezone: Optional[str] = None


@dataclass
class PolicyRule:
    type: Literal[
        "tool_allowlist", "tool_denylist", "parameter_constraint", "rate_limit", "time_based"
    ]
    tools: Optional[List[str]] = None
    parameters: Optional[Dict[str, ParameterConstraint]] = None
    rate_limit: Optional[RateLimitConfig] = None
    time_window: Optional[TimeWindowConfig] = None


@dataclass
class Policy:
    id: str
    agent_id: str
    name: str
    rules: List[PolicyRule]
    priority: int
    enabled: bool
    created_at: str
    updated_at: str


@dataclass
class AuthorizationResult:
    allowed: bool
    outcome: AuthorizationOutcome
    matched_policy_id: Optional[str]
    reason: str
    evaluated_at: str


@dataclass
class AuditLogEntry:
    id: str
    agent_id: Optional[str]
    action: str
    tool_name: str
    parameters: Dict[str, Any]
    result: AuthorizationOutcome
    policy_id: Optional[str]
    reason: str
    latency_ms: int
    timestamp: str


@dataclass
class CreateAgentInput:
    name: str
    description: Optional[str] = None


@dataclass
class CreatePolicyInput:
    agent_id: str
    name: str
    rules: List[PolicyRule]
    priority: int = 0
    enabled: bool = True


@dataclass
class UpdatePolicyInput:
    name: Optional[str] = None
    rules: Optional[List[PolicyRule]] = None
    priority: Optional[int] = None
    enabled: Optional[bool] = None


@dataclass
class Pagination:
    limit: int
    offset: int
    count: int
    total: int


@dataclass
class PaginatedAuditLogResponse:
    data: List[AuditLogEntry]
    pagination: Pagination
