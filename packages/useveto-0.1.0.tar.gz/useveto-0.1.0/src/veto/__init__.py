"""Veto — Runtime authorization for AI agents."""

from veto.client import AsyncVetoClient, VetoClient
from veto.errors import RateLimitError, UnauthorizedError, VetoError
from veto.types import (
    Agent,
    AgentStatus,
    AuditLogEntry,
    AuthorizationOutcome,
    AuthorizationResult,
    CreateAgentInput,
    CreatePolicyInput,
    PaginatedAuditLogResponse,
    Policy,
    PolicyRule,
    UpdatePolicyInput,
)

__all__ = [
    "AsyncVetoClient",
    "VetoClient",
    "VetoError",
    "UnauthorizedError",
    "RateLimitError",
    "Agent",
    "AgentStatus",
    "AuditLogEntry",
    "AuthorizationOutcome",
    "AuthorizationResult",
    "CreateAgentInput",
    "CreatePolicyInput",
    "PaginatedAuditLogResponse",
    "Policy",
    "PolicyRule",
    "UpdatePolicyInput",
]

__version__ = "0.1.0"
