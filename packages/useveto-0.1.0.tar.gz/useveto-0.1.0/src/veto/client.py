"""Veto API client — runtime authorization for AI agents."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

from veto.errors import RateLimitError, UnauthorizedError, VetoError
from veto.types import (
    Agent,
    AuditLogEntry,
    AuthorizationResult,
    CreateAgentInput,
    CreatePolicyInput,
    PaginatedAuditLogResponse,
    Pagination,
    Policy,
    PolicyRule,
    UpdatePolicyInput,
)

DEFAULT_ENDPOINT = "https://api.veto.tools"
DEFAULT_TIMEOUT = 5.0  # seconds


class VetoClient:
    """Client for the Veto authorization API.

    Usage::

        from veto import VetoClient

        client = VetoClient(api_key="veto_...")
        result = client.authorize("agent-id", "file.write", {"path": "/etc/passwd"})
        if not result.allowed:
            print(f"Blocked: {result.reason}")
    """

    def __init__(
        self,
        api_key: str,
        *,
        endpoint: str = DEFAULT_ENDPOINT,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._endpoint = endpoint.rstrip("/")
        self._http = httpx.Client(
            base_url=self._endpoint,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "useveto-python/0.1.0",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> VetoClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Authorization ──

    def authorize(
        self,
        agent_id: str,
        tool_name: str,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> AuthorizationResult:
        """Check if an agent is authorized to call a tool.

        This is the primary method — the whole reason Veto exists.
        """
        data = self._request(
            "POST",
            "/v1/authorize",
            json={
                "agent_id": agent_id,
                "tool_name": tool_name,
                "parameters": parameters or {},
            },
        )
        return AuthorizationResult(
            allowed=data["allowed"],
            outcome=data["outcome"],
            matched_policy_id=data.get("matchedPolicyId"),
            reason=data["reason"],
            evaluated_at=data["evaluatedAt"],
        )

    # ── Agents CRUD ──

    def create_agent(self, input: CreateAgentInput) -> Agent:
        data = self._request(
            "POST",
            "/v1/agents",
            json={"name": input.name, "description": input.description},
        )
        return _parse_agent(data)

    def list_agents(self) -> List[Agent]:
        data = self._request("GET", "/v1/agents?limit=200")
        return [_parse_agent(a) for a in data["data"]]

    def get_agent(self, agent_id: str) -> Agent:
        data = self._request("GET", f"/v1/agents/{agent_id}")
        return _parse_agent(data)

    def delete_agent(self, agent_id: str) -> None:
        self._request("DELETE", f"/v1/agents/{agent_id}")

    # ── Policies CRUD ──

    def create_policy(self, input: CreatePolicyInput) -> Policy:
        data = self._request(
            "POST",
            "/v1/policies",
            json={
                "agent_id": input.agent_id,
                "name": input.name,
                "rules": [_serialize_rule(r) for r in input.rules],
                "priority": input.priority,
                "enabled": input.enabled,
            },
        )
        return _parse_policy(data)

    def list_policies(self, agent_id: Optional[str] = None) -> List[Policy]:
        query = f"?agent_id={agent_id}" if agent_id else ""
        data = self._request("GET", f"/v1/policies{query}")
        return [_parse_policy(p) for p in data["data"]]

    def get_policy(self, policy_id: str) -> Policy:
        data = self._request("GET", f"/v1/policies/{policy_id}")
        return _parse_policy(data)

    def update_policy(self, policy_id: str, input: UpdatePolicyInput) -> Policy:
        body: Dict[str, Any] = {}
        if input.name is not None:
            body["name"] = input.name
        if input.rules is not None:
            body["rules"] = [_serialize_rule(r) for r in input.rules]
        if input.priority is not None:
            body["priority"] = input.priority
        if input.enabled is not None:
            body["enabled"] = input.enabled
        data = self._request("PATCH", f"/v1/policies/{policy_id}", json=body)
        return _parse_policy(data)

    def delete_policy(self, policy_id: str) -> None:
        self._request("DELETE", f"/v1/policies/{policy_id}")

    # ── Audit Logs ──

    def query_audit_log(
        self,
        *,
        agent_id: Optional[str] = None,
        action: Optional[str] = None,
        tool_name: Optional[str] = None,
        result: Optional[str] = None,
        from_time: Optional[str] = None,
        to_time: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> PaginatedAuditLogResponse:
        params: Dict[str, str] = {}
        if agent_id:
            params["agent_id"] = agent_id
        if action:
            params["action"] = action
        if tool_name:
            params["tool_name"] = tool_name
        if result:
            params["result"] = result
        if from_time:
            params["from"] = from_time
        if to_time:
            params["to"] = to_time
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/v1/audit-logs?{query}" if query else "/v1/audit-logs"
        data = self._request("GET", path)

        entries = [_parse_audit_log(e) for e in data["data"]]
        pagination = Pagination(
            limit=data["pagination"]["limit"],
            offset=data["pagination"]["offset"],
            count=data["pagination"]["count"],
            total=data["pagination"]["total"],
        )
        return PaginatedAuditLogResponse(data=entries, pagination=pagination)

    # ── HTTP layer ──

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        try:
            response = self._http.request(method, path, json=json)
        except httpx.TimeoutException as exc:
            raise VetoError(
                "Request timed out", code="TIMEOUT", status_code=408
            ) from exc
        except httpx.HTTPError as exc:
            raise VetoError(
                f"Request failed: {exc}", code="NETWORK_ERROR", status_code=0
            ) from exc

        if response.status_code == 204:
            return None

        if not response.is_success:
            self._handle_error(response)

        return response.json()

    def _handle_error(self, response: httpx.Response) -> None:
        try:
            body = response.json()
            message = body.get("error", {}).get("message", response.reason_phrase)
            code = body.get("error", {}).get("code", "UNKNOWN")
        except Exception:
            message = response.reason_phrase or "Unknown error"
            code = "UNKNOWN"

        if response.status_code == 401:
            raise UnauthorizedError(message)
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "60")) * 1000
            raise RateLimitError(message, retry_after_ms=retry_after)

        raise VetoError(message, code=code, status_code=response.status_code)


# ── Async client ──


class AsyncVetoClient:
    """Async client for the Veto authorization API.

    Usage::

        from veto import AsyncVetoClient

        async with AsyncVetoClient(api_key="veto_...") as client:
            result = await client.authorize("agent-id", "file.write", {"path": "/tmp"})
    """

    def __init__(
        self,
        api_key: str,
        *,
        endpoint: str = DEFAULT_ENDPOINT,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._endpoint = endpoint.rstrip("/")
        self._http = httpx.AsyncClient(
            base_url=self._endpoint,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "useveto-python/0.1.0",
            },
            timeout=timeout,
        )

    async def close(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> AsyncVetoClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ── Authorization ──

    async def authorize(
        self,
        agent_id: str,
        tool_name: str,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> AuthorizationResult:
        data = await self._request(
            "POST",
            "/v1/authorize",
            json={
                "agent_id": agent_id,
                "tool_name": tool_name,
                "parameters": parameters or {},
            },
        )
        return AuthorizationResult(
            allowed=data["allowed"],
            outcome=data["outcome"],
            matched_policy_id=data.get("matchedPolicyId"),
            reason=data["reason"],
            evaluated_at=data["evaluatedAt"],
        )

    # ── Agents CRUD ──

    async def create_agent(self, input: CreateAgentInput) -> Agent:
        data = await self._request(
            "POST",
            "/v1/agents",
            json={"name": input.name, "description": input.description},
        )
        return _parse_agent(data)

    async def list_agents(self) -> List[Agent]:
        data = await self._request("GET", "/v1/agents?limit=200")
        return [_parse_agent(a) for a in data["data"]]

    async def get_agent(self, agent_id: str) -> Agent:
        data = await self._request("GET", f"/v1/agents/{agent_id}")
        return _parse_agent(data)

    async def delete_agent(self, agent_id: str) -> None:
        await self._request("DELETE", f"/v1/agents/{agent_id}")

    # ── Policies CRUD ──

    async def create_policy(self, input: CreatePolicyInput) -> Policy:
        data = await self._request(
            "POST",
            "/v1/policies",
            json={
                "agent_id": input.agent_id,
                "name": input.name,
                "rules": [_serialize_rule(r) for r in input.rules],
                "priority": input.priority,
                "enabled": input.enabled,
            },
        )
        return _parse_policy(data)

    async def list_policies(self, agent_id: Optional[str] = None) -> List[Policy]:
        query = f"?agent_id={agent_id}" if agent_id else ""
        data = await self._request("GET", f"/v1/policies{query}")
        return [_parse_policy(p) for p in data["data"]]

    async def get_policy(self, policy_id: str) -> Policy:
        data = await self._request("GET", f"/v1/policies/{policy_id}")
        return _parse_policy(data)

    async def update_policy(self, policy_id: str, input: UpdatePolicyInput) -> Policy:
        body: Dict[str, Any] = {}
        if input.name is not None:
            body["name"] = input.name
        if input.rules is not None:
            body["rules"] = [_serialize_rule(r) for r in input.rules]
        if input.priority is not None:
            body["priority"] = input.priority
        if input.enabled is not None:
            body["enabled"] = input.enabled
        data = await self._request("PATCH", f"/v1/policies/{policy_id}", json=body)
        return _parse_policy(data)

    async def delete_policy(self, policy_id: str) -> None:
        await self._request("DELETE", f"/v1/policies/{policy_id}")

    # ── Audit Logs ──

    async def query_audit_log(
        self,
        *,
        agent_id: Optional[str] = None,
        action: Optional[str] = None,
        tool_name: Optional[str] = None,
        result: Optional[str] = None,
        from_time: Optional[str] = None,
        to_time: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> PaginatedAuditLogResponse:
        params: Dict[str, str] = {}
        if agent_id:
            params["agent_id"] = agent_id
        if action:
            params["action"] = action
        if tool_name:
            params["tool_name"] = tool_name
        if result:
            params["result"] = result
        if from_time:
            params["from"] = from_time
        if to_time:
            params["to"] = to_time
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/v1/audit-logs?{query}" if query else "/v1/audit-logs"
        data = await self._request("GET", path)

        entries = [_parse_audit_log(e) for e in data["data"]]
        pagination = Pagination(
            limit=data["pagination"]["limit"],
            offset=data["pagination"]["offset"],
            count=data["pagination"]["count"],
            total=data["pagination"]["total"],
        )
        return PaginatedAuditLogResponse(data=entries, pagination=pagination)

    # ── HTTP layer ──

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        try:
            response = await self._http.request(method, path, json=json)
        except httpx.TimeoutException as exc:
            raise VetoError(
                "Request timed out", code="TIMEOUT", status_code=408
            ) from exc
        except httpx.HTTPError as exc:
            raise VetoError(
                f"Request failed: {exc}", code="NETWORK_ERROR", status_code=0
            ) from exc

        if response.status_code == 204:
            return None

        if not response.is_success:
            self._handle_error(response)

        return response.json()

    def _handle_error(self, response: httpx.Response) -> None:
        try:
            body = response.json()
            message = body.get("error", {}).get("message", response.reason_phrase)
            code = body.get("error", {}).get("code", "UNKNOWN")
        except Exception:
            message = response.reason_phrase or "Unknown error"
            code = "UNKNOWN"

        if response.status_code == 401:
            raise UnauthorizedError(message)
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "60")) * 1000
            raise RateLimitError(message, retry_after_ms=retry_after)

        raise VetoError(message, code=code, status_code=response.status_code)


# ── Parsing helpers (camelCase API → snake_case Python) ──


def _parse_agent(data: Dict[str, Any]) -> Agent:
    return Agent(
        id=data["id"],
        name=data["name"],
        description=data.get("description"),
        workspace_id=data.get("workspaceId", ""),
        status=data["status"],
        created_at=data["createdAt"],
        updated_at=data["updatedAt"],
    )


def _parse_policy(data: Dict[str, Any]) -> Policy:
    rules = [_parse_rule(r) for r in data.get("rules", [])]
    return Policy(
        id=data["id"],
        agent_id=data["agentId"],
        name=data["name"],
        rules=rules,
        priority=data["priority"],
        enabled=data["enabled"],
        created_at=data["createdAt"],
        updated_at=data["updatedAt"],
    )


def _parse_rule(data: Dict[str, Any]) -> PolicyRule:
    from veto.types import ParameterConstraint, RateLimitConfig, TimeWindowConfig

    params = None
    if data.get("parameters"):
        params = {
            k: ParameterConstraint(
                regex=v.get("regex"),
                enum=v.get("enum"),
                min=v.get("min"),
                max=v.get("max"),
            )
            for k, v in data["parameters"].items()
        }

    rate_limit = None
    if data.get("rateLimit"):
        rl = data["rateLimit"]
        rate_limit = RateLimitConfig(
            max_calls=rl["maxCalls"],
            window_seconds=rl["windowSeconds"],
            current_count=rl.get("currentCount"),
        )

    time_window = None
    if data.get("timeWindow"):
        tw = data["timeWindow"]
        time_window = TimeWindowConfig(
            allowed_hours=tw.get("allowedHours"),
            allowed_days=tw.get("allowedDays"),
            timezone=tw.get("timezone"),
        )

    return PolicyRule(
        type=data["type"],
        tools=data.get("tools"),
        parameters=params,
        rate_limit=rate_limit,
        time_window=time_window,
    )


def _serialize_rule(rule: PolicyRule) -> Dict[str, Any]:
    """Serialize a PolicyRule to API-compatible JSON (camelCase)."""
    out: Dict[str, Any] = {"type": rule.type}
    if rule.tools is not None:
        out["tools"] = rule.tools
    if rule.parameters is not None:
        out["parameters"] = {
            k: {
                **({"regex": v.regex} if v.regex is not None else {}),
                **({"enum": v.enum} if v.enum is not None else {}),
                **({"min": v.min} if v.min is not None else {}),
                **({"max": v.max} if v.max is not None else {}),
            }
            for k, v in rule.parameters.items()
        }
    if rule.rate_limit is not None:
        out["rateLimit"] = {
            "maxCalls": rule.rate_limit.max_calls,
            "windowSeconds": rule.rate_limit.window_seconds,
        }
    if rule.time_window is not None:
        tw: Dict[str, Any] = {}
        if rule.time_window.allowed_hours is not None:
            tw["allowedHours"] = rule.time_window.allowed_hours
        if rule.time_window.allowed_days is not None:
            tw["allowedDays"] = rule.time_window.allowed_days
        if rule.time_window.timezone is not None:
            tw["timezone"] = rule.time_window.timezone
        out["timeWindow"] = tw
    return out


def _parse_audit_log(data: Dict[str, Any]) -> AuditLogEntry:
    return AuditLogEntry(
        id=data["id"],
        agent_id=data.get("agentId"),
        action=data["action"],
        tool_name=data["toolName"],
        parameters=data.get("parameters", {}),
        result=data["result"],
        policy_id=data.get("policyId"),
        reason=data["reason"],
        latency_ms=data["latencyMs"],
        timestamp=data["timestamp"],
    )
