"""Custom error classes for the Veto SDK."""

from __future__ import annotations


class VetoError(Exception):
    """Base error for all Veto SDK errors."""

    def __init__(self, message: str, code: str = "UNKNOWN", status_code: int = 500) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code


class UnauthorizedError(VetoError):
    """Raised when authentication fails (invalid/expired API key)."""

    def __init__(self, message: str = "Unauthorized") -> None:
        super().__init__(message, code="UNAUTHORIZED", status_code=401)


class RateLimitError(VetoError):
    """Raised when the API rate limit is exceeded."""

    def __init__(
        self, message: str = "Rate limit exceeded", retry_after_ms: int = 60000
    ) -> None:
        super().__init__(message, code="RATE_LIMITED", status_code=429)
        self.retry_after_ms = retry_after_ms
