"""Tests for the Veto Python SDK client."""

import pytest
import respx
from httpx import Response

from veto import (
    AsyncVetoClient,
    CreateAgentInput,
    CreatePolicyInput,
    PolicyRule,
    RateLimitError,
    UnauthorizedError,
    UpdatePolicyInput,
    VetoClient,
    VetoError,
)

API = "https://api.veto.tools"


# ── Sync client tests ──


class TestAuthorize:
    @respx.mock
    def test_allowed(self):
        respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                200,
                json={
                    "allowed": True,
                    "outcome": "allowed",
                    "matchedPolicyId": "policy-1",
                    "reason": 'Allowed by policy "Default"',
                    "evaluatedAt": "2026-04-04T12:00:00Z",
                },
            )
        )

        client = VetoClient(api_key="veto_test123")
        result = client.authorize("agent-1", "file.read", {"path": "/tmp"})

        assert result.allowed is True
        assert result.outcome == "allowed"
        assert result.matched_policy_id == "policy-1"
        assert result.reason == 'Allowed by policy "Default"'
        client.close()

    @respx.mock
    def test_denied(self):
        respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                200,
                json={
                    "allowed": False,
                    "outcome": "denied",
                    "matchedPolicyId": None,
                    "reason": "No policy explicitly allows this action (default deny)",
                    "evaluatedAt": "2026-04-04T12:00:00Z",
                },
            )
        )

        client = VetoClient(api_key="veto_test123")
        result = client.authorize("agent-1", "file.delete")

        assert result.allowed is False
        assert result.outcome == "denied"
        assert result.matched_policy_id is None
        client.close()

    @respx.mock
    def test_sends_correct_body(self):
        route = respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                200,
                json={
                    "allowed": True,
                    "outcome": "allowed",
                    "matchedPolicyId": "p1",
                    "reason": "ok",
                    "evaluatedAt": "2026-04-04T12:00:00Z",
                },
            )
        )

        client = VetoClient(api_key="veto_test123")
        client.authorize("agent-1", "email.send", {"to": "user@example.com"})

        request = route.calls[0].request
        body = request.read()
        import json

        parsed = json.loads(body)
        assert parsed["agent_id"] == "agent-1"
        assert parsed["tool_name"] == "email.send"
        assert parsed["parameters"]["to"] == "user@example.com"
        client.close()


class TestErrors:
    @respx.mock
    def test_unauthorized(self):
        respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                401,
                json={"error": {"code": "UNAUTHORIZED", "message": "Invalid API key"}},
            )
        )

        client = VetoClient(api_key="veto_bad")
        with pytest.raises(UnauthorizedError) as exc_info:
            client.authorize("agent-1", "file.read")
        assert exc_info.value.status_code == 401
        client.close()

    @respx.mock
    def test_rate_limited(self):
        respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                429,
                json={"error": {"code": "RATE_LIMITED", "message": "Slow down"}},
                headers={"Retry-After": "30"},
            )
        )

        client = VetoClient(api_key="veto_test123")
        with pytest.raises(RateLimitError) as exc_info:
            client.authorize("agent-1", "file.read")
        assert exc_info.value.retry_after_ms == 30000
        client.close()

    @respx.mock
    def test_server_error(self):
        respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                500,
                json={"error": {"code": "INTERNAL_ERROR", "message": "Something broke"}},
            )
        )

        client = VetoClient(api_key="veto_test123")
        with pytest.raises(VetoError) as exc_info:
            client.authorize("agent-1", "file.read")
        assert exc_info.value.status_code == 500
        client.close()


class TestAgents:
    @respx.mock
    def test_create_agent(self):
        respx.post(f"{API}/v1/agents").mock(
            return_value=Response(
                201,
                json={
                    "id": "agent-1",
                    "name": "Test Bot",
                    "description": "A test agent",
                    "workspaceId": "ws-1",
                    "status": "active",
                    "createdAt": "2026-04-04T12:00:00Z",
                    "updatedAt": "2026-04-04T12:00:00Z",
                },
            )
        )

        client = VetoClient(api_key="veto_test123")
        agent = client.create_agent(CreateAgentInput(name="Test Bot", description="A test agent"))
        assert agent.id == "agent-1"
        assert agent.name == "Test Bot"
        assert agent.status == "active"
        client.close()

    @respx.mock
    def test_list_agents(self):
        respx.get(f"{API}/v1/agents?limit=200").mock(
            return_value=Response(
                200,
                json={
                    "data": [
                        {
                            "id": "a1",
                            "name": "Bot 1",
                            "description": None,
                            "workspaceId": "ws-1",
                            "status": "active",
                            "createdAt": "2026-04-04T12:00:00Z",
                            "updatedAt": "2026-04-04T12:00:00Z",
                        }
                    ],
                    "pagination": {"limit": 200, "offset": 0, "count": 1, "total": 1},
                },
            )
        )

        client = VetoClient(api_key="veto_test123")
        agents = client.list_agents()
        assert len(agents) == 1
        assert agents[0].name == "Bot 1"
        client.close()

    @respx.mock
    def test_delete_agent(self):
        respx.delete(f"{API}/v1/agents/agent-1").mock(
            return_value=Response(204)
        )

        client = VetoClient(api_key="veto_test123")
        client.delete_agent("agent-1")  # should not raise
        client.close()


class TestPolicies:
    @respx.mock
    def test_create_policy(self):
        respx.post(f"{API}/v1/policies").mock(
            return_value=Response(
                201,
                json={
                    "id": "pol-1",
                    "agentId": "agent-1",
                    "name": "Allow reads",
                    "rules": [{"type": "tool_allowlist", "tools": ["file.read"]}],
                    "priority": 10,
                    "enabled": True,
                    "createdAt": "2026-04-04T12:00:00Z",
                    "updatedAt": "2026-04-04T12:00:00Z",
                },
            )
        )

        client = VetoClient(api_key="veto_test123")
        policy = client.create_policy(
            CreatePolicyInput(
                agent_id="agent-1",
                name="Allow reads",
                rules=[PolicyRule(type="tool_allowlist", tools=["file.read"])],
                priority=10,
            )
        )
        assert policy.id == "pol-1"
        assert policy.rules[0].type == "tool_allowlist"
        assert policy.rules[0].tools == ["file.read"]
        client.close()

    @respx.mock
    def test_update_policy(self):
        respx.patch(f"{API}/v1/policies/pol-1").mock(
            return_value=Response(
                200,
                json={
                    "id": "pol-1",
                    "agentId": "agent-1",
                    "name": "Updated",
                    "rules": [{"type": "tool_allowlist", "tools": ["*"]}],
                    "priority": 20,
                    "enabled": True,
                    "createdAt": "2026-04-04T12:00:00Z",
                    "updatedAt": "2026-04-04T13:00:00Z",
                },
            )
        )

        client = VetoClient(api_key="veto_test123")
        policy = client.update_policy("pol-1", UpdatePolicyInput(name="Updated", priority=20))
        assert policy.name == "Updated"
        assert policy.priority == 20
        client.close()


class TestAuditLogs:
    @respx.mock
    def test_query_audit_log(self):
        respx.get(f"{API}/v1/audit-logs?agent_id=agent-1&limit=10").mock(
            return_value=Response(
                200,
                json={
                    "data": [
                        {
                            "id": "log-1",
                            "agentId": "agent-1",
                            "action": "authorize",
                            "toolName": "file.read",
                            "parameters": {"path": "/tmp"},
                            "result": "allowed",
                            "policyId": "pol-1",
                            "reason": "Allowed",
                            "latencyMs": 3,
                            "timestamp": "2026-04-04T12:00:00Z",
                        }
                    ],
                    "pagination": {"limit": 10, "offset": 0, "count": 1, "total": 1},
                },
            )
        )

        client = VetoClient(api_key="veto_test123")
        response = client.query_audit_log(agent_id="agent-1", limit=10)
        assert len(response.data) == 1
        assert response.data[0].tool_name == "file.read"
        assert response.pagination.total == 1
        client.close()


class TestContextManager:
    @respx.mock
    def test_sync_context_manager(self):
        respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                200,
                json={
                    "allowed": True,
                    "outcome": "allowed",
                    "matchedPolicyId": None,
                    "reason": "ok",
                    "evaluatedAt": "2026-04-04T12:00:00Z",
                },
            )
        )

        with VetoClient(api_key="veto_test123") as client:
            result = client.authorize("agent-1", "file.read")
            assert result.allowed is True


# ── Async client tests ──


class TestAsyncAuthorize:
    @respx.mock
    @pytest.mark.asyncio
    async def test_allowed(self):
        respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                200,
                json={
                    "allowed": True,
                    "outcome": "allowed",
                    "matchedPolicyId": "policy-1",
                    "reason": "Allowed",
                    "evaluatedAt": "2026-04-04T12:00:00Z",
                },
            )
        )

        async with AsyncVetoClient(api_key="veto_test123") as client:
            result = await client.authorize("agent-1", "file.read")
            assert result.allowed is True
            assert result.outcome == "allowed"

    @respx.mock
    @pytest.mark.asyncio
    async def test_denied(self):
        respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                200,
                json={
                    "allowed": False,
                    "outcome": "denied",
                    "matchedPolicyId": None,
                    "reason": "Default deny",
                    "evaluatedAt": "2026-04-04T12:00:00Z",
                },
            )
        )

        async with AsyncVetoClient(api_key="veto_test123") as client:
            result = await client.authorize("agent-1", "file.delete")
            assert result.allowed is False

    @respx.mock
    @pytest.mark.asyncio
    async def test_unauthorized(self):
        respx.post(f"{API}/v1/authorize").mock(
            return_value=Response(
                401,
                json={"error": {"code": "UNAUTHORIZED", "message": "Bad key"}},
            )
        )

        async with AsyncVetoClient(api_key="veto_bad") as client:
            with pytest.raises(UnauthorizedError):
                await client.authorize("agent-1", "file.read")
