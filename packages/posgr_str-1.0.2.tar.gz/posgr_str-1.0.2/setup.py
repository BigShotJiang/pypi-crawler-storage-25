from setuptools import setup, find_packages

setup(
  name='posgr-str',
  version='1.0.2',
  author='SuJ0',
  author_email='petr.zaporozhets@bk.ru',
  description='This is the simplest module for quick work with files.',
  long_description_content_type='text/markdown',
  packages=find_packages(),
  install_requires=['requests>=2.25.1'],
  classifiers=[
    'Programming Language :: Python :: 3',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent'
  ],
  keywords='files speedfiles ',
  project_urls={
    'GitHub': 'https://github.com/SuJoDev'
  },
  python_requires='>=3.6'
)