import os
import sys
import subprocess
import re
def install_requirements():
    """Menginstal PyQt6 dan PyInstaller secara otomatis melalui terminal jika belum ada."""
    print("[INFO] Memeriksa library yang dibutuhkan...")
    packages = {"PyQt6": "PyQt6", "PyInstaller": "pyinstaller"}
    
    for module_name, pip_name in packages.items():
        try:
            if module_name == "PyQt6":
                import PyQt6.QtCore
            else:
                import PyInstaller
        except ImportError:
            print(f"[!] {pip_name} belum terinstal. Memulai instalasi otomatis...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", pip_name])
            
    print("[INFO] Semua dependency siap. Meluncurkan antarmuka (GUI)...")

install_requirements()

from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QLineEdit, QPushButton,
                             QFileDialog, QComboBox, QTextEdit, QMessageBox, QFrame,
                             QGraphicsOpacityEffect)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QPropertyAnimation, QTimer
from PyQt6.QtGui import QIcon, QFont, QPixmap
class MetaConverter:
    def __init__(self):
        self.konversi_rules = [
            (r'--', '#'),
            (r'\[([^\[]*?)\s+untuk\s+(\w+)\s+dalam\s+([^\]]+?)(?:\s+jika\s+([^\]]+?))?\]', lambda m: self._convert_list_comprehension(m)),
            (r'\{([^\[]*?)\s+untuk\s+(\w+)\s+dalam\s+([^\}]+?)(?:\s+jika\s+([^\}]+?))?\}', lambda m: self._convert_dict_comprehension(m)),
            (r'\bmasukan\s*\(', 'input('), (r'\bbaca\s*\(', 'input('),
            (r'\bmeta\s*\(', 'print('), (r'\bcetak\s*\(', 'print('), (r'\btulis\s*\(', 'print('),
            (r'\bteks\s*\(', 'str('), (r'\bbilangan\s*\(', 'int('), (r'\bangka\s*\(', 'int('), (r'\bdesimal\s*\(', 'float('),
            (r'\blist\s*\(', 'list('), (r'\bdictionary\s*\(', 'dict('), (r'\btuple\s*\(', 'tuple('), (r'\bset\s*\(', 'set('), (r'\bbenar_salah\s*\(', 'bool('),
            (r'\bakar\s*\(', 'math.sqrt('), (r'\babsolut\s*\(', 'abs('), (r'\bbulatkan\s*\(', 'round('), (r'\bpangkat\s*\(', 'pow('),
            (r'\bmaksimal\s*\(', 'max('), (r'\bminimal\s*\(', 'min('), (r'\bjumlah\s*\(', 'sum('),
            (r'\brentang\s*\(', 'range('), (r'\bpanjang\s*\(', 'len('), (r'\btipe\s*\(', 'type('), (r'\benumerasi\s*\(', 'enumerate('),
            (r'\bzip\s*\(', 'zip('), (r'\bpetakan\s*\(', 'map('), (r'\bsaring\s*\(', 'filter('), (r'\burutkan\s*\(', 'sorted('),
            (r'^(\s*)dari\s+([\w\.]+)\s+import\s+(.+)$', r'\1from \2 import \3'), (r'^(\s*)import\s+(.+)$', r'\1import \2'),
            (r'^(\s*)modul\s+(\w+)\s*\((.*)\)\s*:?$', r'\1def \2(\3):'), (r'^(\s*)modul\s+(\w+)\s*:?$', r'\1def \2():'), (r'^(\s*)fungsi\s+(\w+)\s*\((.*)\)\s*:?$', r'\1def \2(\3):'),
            (r'^(\s*)kembalikan\s+(.+)$', r'\1return \2'), (r'^(\s*)kembalikan\s*$', r'\1return'), (r'^(\s*)fungsi\s+(.+)$', r'\1return \2'),
            (r'^(\s*)jika\s+(.+?)\s+maka\s*:?$', r'\1if \2:'), (r'^(\s*)atau\s+jika\s+(.+?)\s+maka\s*:?$', r'\1elif \2:'), (r'^(\s*)selain\s+itu\s*:?$', r'\1else:'),
            (r'^(\s*)untuk\s+(\w+)\s+dalam\s+(.+?)\s*:?$', r'\1for \2 in \3:'), (r'^(\s*)selama\s+(.+?)\s*:?$', r'\1while \2:'),
            (r'^(\s*)berhenti\s*$', r'\1break'), (r'^(\s*)lanjut\s*$', r'\1continue'),
            (r'^(\s*)kelas\s+(\w+)(?:\((.+)\))?\s*:?$', r'\1class \2(\3):'), (r'(\s*)diri\.', r'\1self.'), (r'(\s*)diri\b', r'\1self'),
            (r'^(\s*)coba\s*:?$', r'\1try:'), (r'^(\s*)kecuali\s*(.+?)?\s*:?$', r'\1except \2:'), (r'^(\s*)akhirnya\s*:?$', r'\1finally:'), (r'^(\s*)naikkan\s+(.+)$', r'\1raise \2'),
            (r'^(\s*)dengan\s+(.+?)\s+sebagai\s+(\w+)\s*:?$', r'\1with \2 as \3:'),
            (r'\bbenar\b', 'True'), (r'\bsalah\b', 'False'), (r'\bkosong\b', 'None'), (r'\bnull\b', 'None'),
            (r'\bdan\b', 'and'), (r'\batau\b', 'or'), (r'\btidak\b', 'not'), (r'\bdi\b', 'in'), (r'\badalah\b', 'is'),
            (r'\.tambah\(', '.append('), (r'\.masukkan\(', '.insert('), (r'\.hapus\(', '.remove('), (r'\.bersihkan\(', '.clear('), (r'\.pop\(', '.pop('),
            (r'\.panjang\(\)', '.__len__()'), (r'\.index\(', '.index('), (r'\.urutkan\(', '.sort('), (r'\.balik\(', '.reverse('), (r'\.perluas\(', '.extend('), (r'\.salin\(\)', '.copy()'),
            (r'\.jadikan_besar\(\)', '.upper()'), (r'\.jadikan_kecil\(\)', '.lower()'), (r'\.jadikan_kapital\(\)', '.capitalize()'), (r'\.jadikan_judul\(\)', '.title()'),
            (r'\.ganti\(', '.replace('), (r'\.pisah\(', '.split('), (r'\.gabung\(', '.join('), (r'\.strip\(', '.strip('), (r'\.lstrip\(', '.lstrip('), (r'\.rstrip\(', '.rstrip('),
            (r'\.cari\(', '.find('), (r'\.hitung\(', '.count('), (r'\.mulai_dengan\(', '.startswith('), (r'\.akhir_dengan\(', '.endswith('), (r'\.format\(', '.format('),
            (r'\.ambil\(', '.get('), (r'\.kunci\(\)', '.keys()'), (r'\.nilai\(\)', '.values()'), (r'\.item\(\)', '.items()'), (r'\.perbarui\(', '.update('), (r'\.popitem\(\)', '.popitem()'),
        ]

    def _convert_list_comprehension(self, m):
        expr, var, iterable = m.group(1), m.group(2), m.group(3)
        cond = m.group(4)
        res = f"[{expr} for {var} in {iterable}"
        return res + f" if {cond}]" if cond else res + "]"

    def _convert_dict_comprehension(self, m):
        expr, var, iterable = m.group(1), m.group(2), m.group(3)
        cond = m.group(4)
        res = f"{{{expr} for {var} in {iterable}"
        return res + f" if {cond}}}" if cond else res + "}"

    def convert_file(self, input_path, output_path):
        with open(input_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        with open(output_path, 'w', encoding='utf-8') as f:
            for line in lines:
                for pattern, replacement in self.konversi_rules:
                    line = re.sub(pattern, replacement, line) if callable(replacement) else re.sub(pattern, replacement, line)
                f.write(line)
class CompilerWorker(QThread):
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(bool)

    def __init__(self, meta_file, icon_file, out_dir, app_type, build_type, version_file):
        super().__init__()
        self.meta_file = meta_file
        self.icon_file = icon_file
        self.out_dir = out_dir
        self.app_type = app_type
        self.build_type = build_type
        self.version_file = version_file

    def ensure_vscodeignore(self, workspace_dir):
        ignore_path = os.path.join(workspace_dir, '.vscodeignore')
        if not os.path.exists(ignore_path):
            with open(ignore_path, 'w') as f: f.write("build/\ndist/\n*.spec\n__pycache__/\n")
            self.log_signal.emit(f"[INFO] File .vscodeignore ditambahkan di {workspace_dir}")

    def generate_version_info(self, version_str):
        parts = version_str.split('.')
        while len(parts) < 4: parts.append('0')
        v_tuple = f"({parts[0]}, {parts[1]}, {parts[2]}, {parts[3]})"
        return f"""# UTF-8
VSVersionInfo(
  ffi=FixedFileInfo(filevers={v_tuple}, prodvers={v_tuple}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1, subtype=0x0, date=(0, 0)),
  kids=[StringFileInfo([StringTable('040904B0', [StringStruct('FileVersion', '{version_str}'), StringStruct('ProductVersion', '{version_str}')])]), VarFileInfo([VarStruct('Translation', [1033, 1200])])]
)"""

    def run(self):
        try:
            self.log_signal.emit("[1/3] Membaca dan Mengonversi .meta ke .py...")
            base_name = os.path.splitext(os.path.basename(self.meta_file))[0]
            py_file_path = os.path.join(self.out_dir, f"{base_name}.py")
            self.ensure_vscodeignore(self.out_dir)

            MetaConverter().convert_file(self.meta_file, py_file_path)
            self.log_signal.emit(f"[SUKSES] Berhasil membuat file Python: {py_file_path}")

            self.log_signal.emit("\n[2/3] Memulai PyInstaller (Proses ini mungkin memakan waktu)...")
            pyinstaller_cmd = ["pyinstaller", "--noconfirm", f"--distpath={self.out_dir}", f"--workpath={os.path.join(self.out_dir, 'build')}", f"--specpath={self.out_dir}"]

            if self.build_type == "One File (.exe tunggal)": pyinstaller_cmd.append("--onefile")
            else: pyinstaller_cmd.append("--onedir")

            if self.app_type == "GUI (Windowed)": pyinstaller_cmd.append("--noconsole")
            if self.icon_file and os.path.exists(self.icon_file): pyinstaller_cmd.append(f"--icon={self.icon_file}")

            if self.version_file and os.path.exists(self.version_file):
                with open(self.version_file, 'r', encoding='utf-8') as vf: v_text = vf.read().strip()
                if re.match(r'^\d+(\.\d+){0,3}$', v_text):
                    gen_v_path = os.path.join(self.out_dir, 'version_info.txt')
                    with open(gen_v_path, 'w', encoding='utf-8') as gvf: gvf.write(self.generate_version_info(v_text))
                    pyinstaller_cmd.append(f"--version-file={gen_v_path}")
                    self.log_signal.emit(f"[INFO] Mengaplikasikan versi: {v_text}")

            pyinstaller_cmd.append(py_file_path)
            process = subprocess.Popen(pyinstaller_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)

            for line in process.stdout:
                if line.strip(): self.log_signal.emit(line.strip())
            process.wait()

            if process.returncode == 0:
                self.log_signal.emit("\n[3/3] BUILD SELESAI!")
                self.log_signal.emit(f"[SUKSES] Cek direktori output: {self.out_dir}")
                self.finished_signal.emit(True)
            else:
                self.log_signal.emit("\n[ERROR] PyInstaller gagal melakukan build.")
                self.finished_signal.emit(False)
        except Exception as e:
            self.log_signal.emit(f"\n[CRITICAL ERROR] {str(e)}")
            self.finished_signal.emit(False)
class SplashScreen(QWidget):
    def __init__(self, main_window, icon_path):
        super().__init__()
        self.main_window = main_window
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.SplashScreen)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.resize(300, 300)

        layout = QVBoxLayout(self)
        self.label = QLabel()
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pixmap = QPixmap(icon_path)
        if not pixmap.isNull():
            self.label.setPixmap(pixmap.scaled(200, 200, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        else:
            self.label.setText("Meta Compiler")
            self.label.setStyleSheet("color: #8AB4F8; font-size: 32px; font-weight: bold;")
            
        layout.addWidget(self.label)
        self.opacity_effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.opacity_effect)
        self.opacity_effect.setOpacity(0)

        self.animation = QPropertyAnimation(self.opacity_effect, b"opacity")

    def start_animation(self):
        self.animation.setDuration(1500)
        self.animation.setStartValue(0.0)
        self.animation.setEndValue(1.0)
        self.animation.finished.connect(self.hold_splash)
        self.animation.start()

    def hold_splash(self):
        self.animation.finished.disconnect()
        QTimer.singleShot(1500, self.fade_out)

    def fade_out(self):
        self.animation.setDuration(1000)
        self.animation.setStartValue(1.0)
        self.animation.setEndValue(0.0)
        self.animation.finished.connect(self.show_main_window)
        self.animation.start()
    def show_main_window(self):
        self.close()
        self.main_window.show()
class MetaCompilerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Meta to Executable Compiler")
        self.resize(600, 600)
        self.icon_path = os.path.join(os.path.dirname(__file__), "icons", "icon.ico")
        if os.path.exists(self.icon_path):
            self.setWindowIcon(QIcon(self.icon_path))
        self.setStyleSheet("""
            QMainWindow { background-color: #202124; }
            QLabel { color: #E8EAED; font-size: 12px; font-family: 'Segoe UI', Arial; }
            QLineEdit { background-color: #2D2E30; color: #E8EAED; border: 1px solid #5F6368; border-radius: 4px; padding: 6px; font-size: 12px; }
            QPushButton { background-color: #3C4043; color: #E8EAED; border: 1px solid #5F6368; border-radius: 4px; padding: 6px 10px; font-weight: bold; }
            QPushButton:hover { background-color: #5F6368; }
            QPushButton#compileBtn { background-color: #8AB4F8; color: #202124; font-size: 13px; padding: 10px; border: none; font-weight: bold; }
            QPushButton#compileBtn:hover { background-color: #aecbfa; }
            QPushButton#compileBtn:disabled { background-color: #5F6368; color: #9AA0A6; }
            QComboBox { background-color: #2D2E30; color: #E8EAED; border: 1px solid #5F6368; border-radius: 4px; padding: 5px; font-size: 12px; }
            QComboBox::drop-down { border: none; }
            QComboBox QAbstractItemView { background-color: #2D2E30; color: #E8EAED; selection-background-color: #5F6368; border: 1px solid #5F6368; }
            QTextEdit { background-color: #171717; color: #4CAF50; font-family: Consolas, monospace; border: 1px solid #5F6368; border-radius: 4px; padding: 8px; font-size: 11px; }
            QFrame#mainFrame { background-color: #292A2D; border-radius: 8px; }
            QMessageBox { background-color: #2D2E30; }
            QMessageBox QLabel { color: #E8EAED; }
            QMessageBox QPushButton { background-color: #8AB4F8; color: #202124; min-width: 70px; }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        header_layout = QHBoxLayout()
        title_label = QLabel("Meta Compiler")
        title_label.setStyleSheet("color: #8AB4F8; font-size: 20px; font-weight: bold;")
        subtitle_label = QLabel("Convert & Build")
        subtitle_label.setStyleSheet("color: #9AA0A6; font-size: 12px;")
        header_layout.addWidget(title_label)
        header_layout.addWidget(subtitle_label)
        header_layout.addStretch()
        main_layout.addLayout(header_layout)
        frame = QFrame()
        frame.setObjectName("mainFrame")
        frame_layout = QVBoxLayout(frame)
        frame_layout.setSpacing(10)
        frame_layout.setContentsMargins(15, 15, 15, 15)

        self.meta_entry = self.create_row(frame_layout, "1. File .meta:", self.browse_meta)
        self.icon_entry = self.create_row(frame_layout, "2. Icon (.ico):", self.browse_icon)
        if os.path.exists(self.icon_path): self.icon_entry.setText(self.icon_path)
        self.outdir_entry = self.create_row(frame_layout, "3. Folder Output:", self.browse_output, is_dir=True)
        self.version_entry = self.create_row(frame_layout, "4. Versi (.txt) [Opsional]:", self.browse_version)

        app_layout = QHBoxLayout()
        app_label = QLabel("5. Tipe Aplikasi:")
        app_label.setFixedWidth(130)
        self.app_combo = QComboBox()
        self.app_combo.addItems(["Terminal (Console)", "GUI (Windowed)"])
        app_layout.addWidget(app_label)
        app_layout.addWidget(self.app_combo)
        frame_layout.addLayout(app_layout)

        build_layout = QHBoxLayout()
        build_label = QLabel("6. Format Build:")
        build_label.setFixedWidth(130)
        self.build_combo = QComboBox()
        self.build_combo.addItems(["One File (.exe tunggal)", "One Directory (Folder + Dependencies)"])
        build_layout.addWidget(build_label)
        build_layout.addWidget(self.build_combo)
        frame_layout.addLayout(build_layout)

        self.compile_btn = QPushButton("START COMPILE")
        self.compile_btn.setObjectName("compileBtn")
        self.compile_btn.clicked.connect(self.start_compilation)
        frame_layout.addWidget(self.compile_btn)

        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        frame_layout.addWidget(self.log_box)

        main_layout.addWidget(frame)
        self.log_message("Sistem inisialisasi selesai. Menunggu input pengguna...")

    def create_row(self, parent_layout, label_text, browse_func, is_dir=False):
        row_layout = QHBoxLayout()
        label = QLabel(label_text)
        label.setFixedWidth(130)
        entry = QLineEdit()
        btn = QPushButton("Browse")
        btn.clicked.connect(lambda: browse_func(entry))
        row_layout.addWidget(label)
        row_layout.addWidget(entry)
        row_layout.addWidget(btn)
        parent_layout.addLayout(row_layout)
        return entry

    def browse_meta(self, entry):
        file, _ = QFileDialog.getOpenFileName(self, "Pilih File Meta", "", "Meta Files (*.meta)")
        if file: entry.setText(file)

    def browse_icon(self, entry):
        file, _ = QFileDialog.getOpenFileName(self, "Pilih Icon", "", "Icon Files (*.ico)")
        if file: entry.setText(file)

    def browse_output(self, entry):
        directory = QFileDialog.getExistingDirectory(self, "Pilih Direktori Output")
        if directory: entry.setText(directory)
        
    def browse_version(self, entry):
        file, _ = QFileDialog.getOpenFileName(self, "Pilih File Teks Versi", "", "Text Files (*.txt)")
        if file: entry.setText(file)

    def log_message(self, text):
        self.log_box.append(text)
        scrollbar = self.log_box.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def start_compilation(self):
        meta_file = self.meta_entry.text().strip()
        out_dir = self.outdir_entry.text().strip()
        if not meta_file or not out_dir:
            QMessageBox.warning(self, "Error", "File Meta dan Direktori Output harus diisi!")
            return
        self.compile_btn.setEnabled(False)
        self.compile_btn.setText("COMPILING...")
        self.log_box.clear()
        self.worker = CompilerWorker(meta_file, self.icon_entry.text().strip(), out_dir, self.app_combo.currentText(), self.build_combo.currentText(), self.version_entry.text().strip())
        self.worker.log_signal.connect(self.log_message)
        self.worker.finished_signal.connect(self.on_compilation_finished)
        self.worker.start()
    def on_compilation_finished(self, success):
        self.compile_btn.setEnabled(True)
        self.compile_btn.setText("START COMPILE")
        if success: QMessageBox.information(self, "Sukses", "Kompilasi selesai dengan sukses!")
if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = MetaCompilerApp()
    icon_file = os.path.join(os.path.dirname(__file__), "icons", "icon.png")
    splash = SplashScreen(main_window, icon_file)
    if sys.platform == "win32":
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    splash.show()
    splash.start_animation()
    sys.exit(app.exec())
def run_gui():
    """Fungsi entry point untuk menjalankan aplikasi dari terminal."""
    app = QApplication(sys.argv)
    if sys.platform == "win32":
        try:
            from ctypes import windll
            windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    main_window = MetaCompilerApp()
    icon_file = os.path.join(os.path.dirname(__file__), "icons", "icon.png")
    splash = SplashScreen(main_window, icon_file)
    splash.show()
    splash.start_animation()
    sys.exit(app.exec())
if __name__ == "__main__":
    run_gui()