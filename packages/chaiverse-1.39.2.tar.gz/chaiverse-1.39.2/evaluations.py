from chaiverse import config
from chaiverse.cli_utils.login_cli import auto_authenticate
from chaiverse.http_client import SubmitterClient


@auto_authenticate
def get_model_evaluation(submission_id, developer_key=None):
    http_client = SubmitterClient(developer_key)
    response = http_client.get(endpoint=config.EVAL_ENDPOINT, submission_id=submission_id)
    return response


@auto_authenticate
def trigger_evaluation_jobs(submission_id, tasks, developer_key=None):
    http_client = SubmitterClient(developer_key)
    response = http_client.post(
        endpoint=config.EVAL_JOBS_ENDPOINT,
        submission_id=submission_id,
        json={"tasks": tasks},
    )
    return response


