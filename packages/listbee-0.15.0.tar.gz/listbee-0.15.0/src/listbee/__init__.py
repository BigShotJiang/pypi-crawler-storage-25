"""ListBee Python SDK — sell anything, payment collected, digital delivery handled.

Usage:
    from listbee import ListBee

    client = ListBee(api_key="lb_...")
    listing = client.listings.create(name="SEO Playbook", price=2999)
    client.listings.set_deliverables(
        listing.slug,
        deliverables=[{"type": "url", "value": "https://example.com/ebook.pdf"}],
    )
    listing = client.listings.publish(listing.slug)
    print(listing.url)
"""

from httpx import AsyncClient as DefaultAsyncHttpxClient
from httpx import Client as DefaultHttpxClient

from listbee._client import AsyncListBee, ListBee
from listbee._exceptions import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    ForbiddenError,
    InternalServerError,
    ListBeeError,
    NotFoundError,
    PartialCreationError,
    PayloadTooLargeError,
    RateLimitError,
    ValidationError,
    WebhookVerificationError,
)
from listbee.checkout_field import CheckoutField
from listbee.deliverable import Deliverable
from listbee.helpers import (
    ParsedWebhookEvent,
    format_price,
    from_minor,
    parse_webhook_event,
    resolve_action,
    resolve_action_async,
    to_minor,
)
from listbee.types import (
    AccountReadiness,
    AccountResponse,
    AccountStats,
    Action,
    ActionCode,
    ActionKind,
    ActionPriority,
    ActionResolve,
    ApiKeyResponse,
    BlurMode,
    CheckoutFieldResponse,
    CheckoutFieldType,
    CursorPage,
    CustomerResponse,
    DeliverableResponse,
    DeliverableStatus,
    DeliverableType,
    FaqItem,
    FileResponse,
    ListingReadiness,
    ListingResponse,
    ListingStatus,
    OrderResponse,
    OrderStatus,
    PaymentStatus,
    Review,
    StripeConnectSessionResponse,
    WebhookEventResponse,
    WebhookEventType,
    WebhookReadiness,
    WebhookResponse,
    WebhookTestResponse,
)
from listbee.webhooks import verify_signature

__all__ = [
    "DefaultHttpxClient",
    "DefaultAsyncHttpxClient",
    "Deliverable",
    "ListBee",
    "AsyncListBee",
    "ListBeeError",
    "APIStatusError",
    "APIConnectionError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ForbiddenError",
    "NotFoundError",
    "ConflictError",
    "PayloadTooLargeError",
    "ValidationError",
    "RateLimitError",
    "InternalServerError",
    "PartialCreationError",
    "WebhookVerificationError",
    "verify_signature",
    "format_price",
    "to_minor",
    "from_minor",
    "resolve_action",
    "resolve_action_async",
    "parse_webhook_event",
    "ParsedWebhookEvent",
    "AccountReadiness",
    "AccountResponse",
    "AccountStats",
    "Action",
    "ActionCode",
    "ActionKind",
    "ActionPriority",
    "ActionResolve",
    "ApiKeyResponse",
    "BlurMode",
    "CheckoutField",
    "CheckoutFieldResponse",
    "CheckoutFieldType",
    "CursorPage",
    "CustomerResponse",
    "DeliverableResponse",
    "DeliverableStatus",
    "DeliverableType",
    "FaqItem",
    "FileResponse",
    "ListingReadiness",
    "ListingResponse",
    "ListingStatus",
    "OrderResponse",
    "OrderStatus",
    "PaymentStatus",
    "Review",
    "StripeConnectSessionResponse",
    "WebhookEventResponse",
    "WebhookEventType",
    "WebhookReadiness",
    "WebhookResponse",
    "WebhookTestResponse",
]
