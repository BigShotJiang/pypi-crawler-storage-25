#include "synthesis.hpp"

#include <cstddef>
#include <exception>
#include <istream>
#include <memory>
#include <optional>
#include <ostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "../chemistry/chemistry.hpp"
#include "../utility/serialization.hpp"
#include "bb_lib.hpp"
#include "chemical_space.hpp"
#include "int_lib.hpp"
#include "postfix_notation.hpp"
#include "rxn_lib.hpp"

namespace prexsyn::chemspace {

void ChemicalSpaceSynthesis::serialize(std::ostream &os) const {
    boost::archive::binary_oarchive oa(os);
    oa << postfix_notation_;
}

std::unique_ptr<ChemicalSpaceSynthesis>
ChemicalSpaceSynthesis::deserialize(std::istream &is, const ChemicalSpace &cs,
                                    std::optional<size_t> max_outcomes) {
    std::unique_ptr<ChemicalSpaceSynthesis> result{new ChemicalSpaceSynthesis(cs)};
    boost::archive::binary_iarchive ia(is);
    PostfixNotation pn;
    ia >> pn;
    auto recons_result = result->add_postfix_notation(pn, max_outcomes);
    if (!recons_result) {
        throw std::runtime_error(
            "failed to deserialize synthesis, did you provide the same chemical space? " +
            recons_result.message);
    }
    return result;
}

size_t ChemicalSpaceSynthesis::count_building_blocks() const {
    size_t count = 0;
    for (const auto &token : postfix_notation_.tokens()) {
        if (token.type == PostfixNotation::Token::Type::BuildingBlock) {
            ++count;
        }
    }
    return count;
}

size_t ChemicalSpaceSynthesis::count_reactions() const {
    size_t count = 0;
    for (const auto &token : postfix_notation_.tokens()) {
        if (token.type == PostfixNotation::Token::Type::Reaction) {
            ++count;
        }
    }
    return count;
}

std::vector<std::shared_ptr<Molecule>> ChemicalSpaceSynthesis::products() const {
    const static std::vector<std::shared_ptr<Molecule>> empty_result{};
    if (synthesis_->stack_size() == 0) {
        return empty_result;
    }
    const auto &top = synthesis_->stack_top();
    std::vector<std::shared_ptr<Molecule>> result;
    result.reserve(top->size());
    for (size_t i = 0; i < top->size(); ++i) {
        result.push_back(top->at(i));
    }
    return result;
}

using Result = ChemicalSpaceSynthesis::Result;

Result ChemicalSpaceSynthesis::add_building_block(BuildingBlockLibrary::Index index) noexcept {
    try {
        const auto &bb_item = cs_.bb_lib().get(index);
        synthesis_->push(bb_item.molecule);
        postfix_notation_.append(bb_item.index, PostfixNotation::Token::Type::BuildingBlock);
        return Result::ok();
    } catch (const std::exception &e) {
        return Result::error(e.what());
    }
}

Result ChemicalSpaceSynthesis::add_building_block(const std::string &index) noexcept {
    try {
        const auto &bb_item = cs_.bb_lib().get(index);
        synthesis_->push(bb_item.molecule);
        postfix_notation_.append(bb_item.index, PostfixNotation::Token::Type::BuildingBlock);
        return Result::ok();
    } catch (const std::exception &e) {
        return Result::error(e.what());
    }
}

Result ChemicalSpaceSynthesis::add_reaction(ReactionLibrary::Index index,
                                            std::optional<size_t> max_outcomes) noexcept {
    try {
        const auto &rxn_item = cs_.rxn_lib().get(index);
        synthesis_->push(rxn_item.reaction, max_outcomes);
        postfix_notation_.append(rxn_item.index, PostfixNotation::Token::Type::Reaction);
        return Result::ok();
    } catch (const std::exception &e) {
        return Result::error(e.what());
    }
}

Result ChemicalSpaceSynthesis::add_reaction(const std::string &index,
                                            std::optional<size_t> max_outcomes) noexcept {
    try {
        const auto &rxn_item = cs_.rxn_lib().get(index);
        synthesis_->push(rxn_item.reaction, max_outcomes);
        postfix_notation_.append(rxn_item.index, PostfixNotation::Token::Type::Reaction);
        return Result::ok();
    } catch (const std::exception &e) {
        return Result::error(e.what());
    }
}

Result ChemicalSpaceSynthesis::add_postfix_notation(const PostfixNotation &pfn,
                                                    std::optional<size_t> max_outcomes) noexcept {
    size_t count_operations = 0;
    auto result = Result::ok();
    for (const auto &token : pfn.tokens()) {
        if (token.type == PostfixNotation::Token::Type::BuildingBlock) {
            result = add_building_block(token.index);
            if (result) {
                count_operations++;
            } else {
                break;
            }
        } else if (token.type == PostfixNotation::Token::Type::Reaction) {
            result = add_reaction(token.index, max_outcomes);
            if (result) {
                count_operations++;
            } else {
                break;
            }
        }
    }

    if (!result) {
        for (size_t i = 0; i < count_operations; ++i) {
            undo();
        }
    }
    return result;
};

Result ChemicalSpaceSynthesis::add_intermediate(IntermediateLibrary::Index index,
                                                std::optional<size_t> max_outcomes) noexcept {
    try {
        const auto &int_item = cs_.int_lib().get(index);
        return add_postfix_notation(int_item.postfix_notation, max_outcomes);
    } catch (const std::exception &e) {
        return Result::error(e.what());
    }
}

Result ChemicalSpaceSynthesis::add_intermediate(const std::string &identifier,
                                                std::optional<size_t> max_outcomes) noexcept {
    try {
        const auto &int_item = cs_.int_lib().get(identifier);
        return add_intermediate(int_item.index, max_outcomes);
    } catch (const std::exception &e) {
        return Result::error(e.what());
    }
}

Result ChemicalSpaceSynthesis::undo() noexcept {
    try {
        postfix_notation_.pop_back();
        synthesis_->undo();
        return Result::ok();
    } catch (const std::exception &e) {
        return Result::error(e.what());
    }
}

} // namespace prexsyn::chemspace
