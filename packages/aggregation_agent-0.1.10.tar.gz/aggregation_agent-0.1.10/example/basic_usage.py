from dotenv import load_dotenv
load_dotenv()

from aggregation_agent import AggregationAgent

# =============================================================================
# 1. Define each input component separately
# =============================================================================

domain_name = "Mortgage Servicing"

domain_description = (
    "Business Purpose:\n"
    "- Manage mortgage loans post-origination through payoff or foreclosure.\n"
    "- Ensure timely payment collection and regulatory compliance.\n"
    "- Support borrowers with escrow management and loan modifications.\n\n"
    "Core Business Activities:\n"
    "- Process mortgage payments (principal, interest, taxes, insurance).\n"
    "- Manage escrow disbursements for taxes and insurance.\n"
    "- Track delinquencies, defaults, and foreclosures.\n"
    "- Handle borrower communications and support.\n"
    "- Process loan modifications, forbearance, and payoffs."
)

entity_name = "Borrower Profile"

entity_description = (
    "Contains personal and financial details of borrowers "
    "applying for or servicing mortgage loans."
)

# Pre-computed sample data — list of records (NOT integer-indexed)
sample_data = [
    {
        "BorrowerId": 1, "FirstName": "Mary", "LastName": "Schneider",
        "CreditScore": 391, "DateOfBirth": "2023-05-11",
        "EmploymentStatus": "Unemployed", "Address": "123 Main St",
        "Email": "cheryl54@example.com", "ContactNumber": "261.754.0781",
        "SocialSecurityNumber": "123-45-6789",
    },
    {
        "BorrowerId": 2, "FirstName": "John", "LastName": "Smith",
        "CreditScore": 720, "DateOfBirth": "1985-03-22",
        "EmploymentStatus": "Employed", "Address": "456 Oak Ave",
        "Email": "john.smith@example.com", "ContactNumber": "555.123.4567",
        "SocialSecurityNumber": "987-65-4321",
    },
    {
        "BorrowerId": 3, "FirstName": "Jane", "LastName": "Doe",
        "CreditScore": 650, "DateOfBirth": "1990-07-15",
        "EmploymentStatus": "Self-Employed", "Address": "789 Pine Rd",
        "Email": "jane.doe@example.com", "ContactNumber": "555.987.6543",
        "SocialSecurityNumber": "456-78-9012",
    },
]

# Pre-computed table metadata (from DataFrame analysis or DB catalog)
table_metadata = {
    "table_info": {"row_count": 100},
    "table_columns_info": {
        "BorrowerId": {
            "data_type": "integer",
            "null_percentage": 0.0,
            "distinct_count": 100,
            "freq/top5": [(1, 1), (2, 1), (3, 1), (4, 1), (5, 1)],
            "min/max_value": [(1, 100)],
            "date_distribution": [],
        },
        "FirstName": {
            "data_type": "string",
            "null_percentage": 0.0,
            "distinct_count": 85,
            "freq/top5": [("John", 5), ("Mary", 4), ("Jane", 3)],
            "min/max_value": [],
            "date_distribution": [],
        },
        "LastName": {
            "data_type": "string",
            "null_percentage": 0.0,
            "distinct_count": 90,
            "freq/top5": [("Smith", 6), ("Doe", 3)],
            "min/max_value": [],
            "date_distribution": [],
        },
        "CreditScore": {
            "data_type": "integer",
            "null_percentage": 0.0,
            "distinct_count": 95,
            "freq/top5": [(720, 3), (650, 2), (700, 2)],
            "min/max_value": [(300, 850)],
            "date_distribution": [],
        },
        "DateOfBirth": {
            "data_type": "date",
            "null_percentage": 0.0,
            "distinct_count": 100,
            "freq/top5": [("1985-03-22", 2), ("1990-07-15", 2), ("1978-11-03", 1), ("1992-06-28", 1), ("1965-09-14", 1)],
            "min/max_value": [("1950-01-01", "2000-12-31")],
            "date_distribution": [("1950-1960", 8), ("1960-1970", 15), ("1970-1980", 22), ("1980-1990", 30), ("1990-2000", 25)],
        },
        "EmploymentStatus": {
            "data_type": "string",
            "null_percentage": 0.0,
            "distinct_count": 3,
            "freq/top5": [("Employed", 60), ("Self-Employed", 25), ("Unemployed", 15)],
            "min/max_value": [],
            "date_distribution": [],
        },
        "Address": {
            "data_type": "string",
            "null_percentage": 2.0,
            "distinct_count": 98,
            "freq/top5": [("123 Main St", 2), ("456 Oak Ave", 1), ("789 Pine Rd", 1), ("321 Elm Blvd", 1), ("654 Maple Dr", 1)],
            "min/max_value": [("100 Acorn Ln", "999 Zephyr Way")],
            "date_distribution": [],
        },
        "Email": {
            "data_type": "string",
            "null_percentage": 1.0,
            "distinct_count": 99,
            "freq/top5": [("cheryl54@example.com", 1), ("john.smith@example.com", 1), ("jane.doe@example.com", 1), ("bob.jones@example.com", 1), ("alice.w@example.com", 1)],
            "min/max_value": [("alice.w@example.com", "zara.k@example.com")],
            "date_distribution": [],
        },
        "ContactNumber": {
            "data_type": "string",
            "null_percentage": 5.0,
            "distinct_count": 95,
            "freq/top5": [("555.123.4567", 2), ("555.987.6543", 1), ("261.754.0781", 1), ("555.222.3333", 1), ("555.444.5555", 1)],
            "min/max_value": [("200.100.0001", "999.999.9999")],
            "date_distribution": [],
        },
        "SocialSecurityNumber": {
            "data_type": "string",
            "null_percentage": 0.0,
            "distinct_count": 100,
            "freq/top5": [("123-45-6789", 1), ("987-65-4321", 1), ("456-78-9012", 1), ("111-22-3333", 1), ("444-55-6666", 1)],
            "min/max_value": [("100-00-0001", "999-99-9999")],
            "date_distribution": [],
        },
    },
}

# Column descriptions
column_descriptions = {
    "BorrowerId": "Unique identifier for the borrower",
    "FirstName": "Borrower's first name",
    "LastName": "Borrower's last name",
    "CreditScore": "Borrower's credit score from credit bureau sources",
    "DateOfBirth": "Borrower's date of birth",
    "EmploymentStatus": "Current employment status (e.g., employed, self-employed, unemployed)",
    "Address": "Residential address of the borrower",
    "Email": "Email address for communication",
    "ContactNumber": "Primary phone number",
    "SocialSecurityNumber": "Government issued identification number",
}

# Semantic-to-column mappings
mappings = {
    "Borrower Identifier": "BorrowerId",
    "First Name": "FirstName",
    "Last Name": "LastName",
    "Credit Score": "CreditScore",
    "Date of Birth": "DateOfBirth",
    "Employment Status": "EmploymentStatus",
    "Borrower Address": "Address",
    "Email Address": "Email",
    "Phone Number": "ContactNumber",
    "Government ID Number": "SocialSecurityNumber",
}

# Use case (optional)
use_case = {
    "name": "delinquency_prediction",
    "description": "Predict borrower delinquency risk based on profile attributes.",
}

modelling_approach = "classification"

# =============================================================================
# 2. Assemble the task data payload (matches TaskDataInput schema)
# =============================================================================

task_data = {
    "domain_name": domain_name,
    "domain_description": domain_description,
    "entity_name": entity_name,
    "entity_description": entity_description,
    "sample_data": sample_data,
    "table_metadata": table_metadata,
    "column_descriptions": column_descriptions,
    "mappings": mappings,
    "use_case": use_case,
    "modelling_approach": modelling_approach,
}

# =============================================================================
# 3. Initialize and execute the agent
# =============================================================================

agent = AggregationAgent()
result = agent(task_data)

# 4. Print the suggested aggregation strategy
print(result)
