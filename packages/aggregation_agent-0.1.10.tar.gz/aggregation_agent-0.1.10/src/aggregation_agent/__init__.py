"""
StepFn Aggregation Agent Package

A modular, LLM-driven data aggregation agent that provides intelligent
aggregation strategies and column mapping recommendations.

Features:
- LLM-driven aggregation strategy selection
- Intelligent column mapping suggestions
- Centralized sfn_blueprint integration
- Configurable AI provider management
- Independent usage or orchestrator integration
"""

from .agent import AggregationAgent
from .config import DEFAULT_AI_PROVIDER, DEFAULT_AI_TASK_TYPE
from .models import TaskDataInput, TableMetadata, UseCaseInfo

__version__ = "0.1.7"
__author__ = "StepFn AI"
__email__ = "rajesh@stepfunction.ai"

__all__ = [
    "AggregationAgent",
    "TaskDataInput",
    "TableMetadata",
    "UseCaseInfo",
    "DEFAULT_AI_PROVIDER",
    "DEFAULT_AI_TASK_TYPE",
]
