"""
Data models for the Aggregation Agent

This module defines all Pydantic models used for:
- Input data validation (strict, no backward compatibility)
- Column configuration and metadata
"""

import json
import logging
from enum import Enum
from typing import Any, Dict, List, Optional, Union

import pandas as pd
from pydantic import BaseModel, Field, field_validator

logger = logging.getLogger(__name__)

# Type mapping: raw DB/pandas types to logical types
NUMERICAL_RAW_TYPES = {
    "bigint", "bigserial", "byteint", "decimal", "double precision", "double",
    "float", "float4", "float64", "float8", "int", "int4", "int64", "int8",
    "integer", "number", "numeric", "real", "serial", "smallint", "smallserial",
}
DATETIME_RAW_TYPES = {
    "timestamp without time zone", "timestamp with time zone", "date", "time",
    "timestamp", "time without time zone", "time with time zone", "interval",
}
BOOLEAN_RAW_TYPES = {"boolean", "bool"}


def map_raw_dtype_to_logical(raw_type: str) -> str:
    """Map a raw data type string to a logical type (TEXT, NUMERICAL, DATETIME, BOOLEAN)."""
    raw_lower = raw_type.lower().strip()
    if raw_lower in NUMERICAL_RAW_TYPES:
        return "NUMERICAL"
    if raw_lower in DATETIME_RAW_TYPES:
        return "DATETIME"
    if raw_lower in BOOLEAN_RAW_TYPES:
        return "BOOLEAN"
    return "TEXT"


# =============================================================================
# ENUMS
# =============================================================================


class DataType(str, Enum):
    """Supported data types for aggregation."""
    TEXT = "TEXT"
    NUMERICAL = "NUMERICAL"
    DATETIME = "DATETIME"
    BOOLEAN = "BOOLEAN"
    CATEGORICAL = "CATEGORICAL"


class AggregationMethod(str, Enum):
    """Supported aggregation methods."""
    UNIQUE_COUNT = "Unique Count"
    MODE = "Mode"
    LAST_VALUE = "Last Value"
    MIN = "Min"
    MAX = "Max"
    SUM = "Sum"
    MEAN = "Mean"
    MEDIAN = "Median"


# =============================================================================
# INPUT MODELS
# =============================================================================


class UseCaseInfo(BaseModel):
    """Use case information."""
    name: Optional[str] = None
    description: Optional[str] = None


class TableMetadata(BaseModel):
    """Pre-computed table metadata."""
    table_info: Dict[str, Any] = Field(..., description="Table-level info (row_count, etc.)")
    table_columns_info: Dict[str, Any] = Field(..., description="Per-column statistics")

    model_config = {"extra": "ignore"}


class TaskDataInput(BaseModel):
    """
    Validated input for the aggregation agent's execute_task().

    Strict schema — no backward compatibility. All fields must match
    the expected format or validation will fail.

    Required:
        - domain_name, domain_description: Business context
        - entity_name, entity_description: Entity context
        - sample_data: Sample rows (normalized from int-indexed to records)
        - table_metadata: Pre-computed table and column statistics
        - column_descriptions: Column name to description mapping
        - mappings: Semantic name to actual column name mapping
    """

    # Required: domain info
    domain_name: str = Field(..., min_length=1, description="Business domain name")
    domain_description: str = Field(..., min_length=1, description="Domain description")

    # Required: entity info
    entity_name: str = Field(..., min_length=1, description="Entity name")
    entity_description: str = Field(..., min_length=1, description="Entity description")

    # Required: data
    sample_data: List[Dict[str, Any]] = Field(
        ..., description="Sample data rows in records format"
    )
    table_metadata: TableMetadata = Field(
        ..., description="Pre-computed table metadata"
    )
    column_descriptions: Dict[str, str] = Field(
        ..., description="Column name to description mapping"
    )
    mappings: Dict[str, str] = Field(
        ..., description="Semantic name to actual column name mapping"
    )

    # Optional: context
    use_case: Optional[UseCaseInfo] = Field(None, description="Use case info")
    modelling_approach: Optional[str] = Field(None, description="ML modelling approach")

    # Optional: workflow
    workflow_storage_path: Optional[str] = Field(None)
    workflow_id: Optional[str] = Field(None)

    # Optional: customer/user pass-through
    customer_id: Optional[Any] = Field(None)
    customer_name: Optional[str] = Field(None)
    username: Optional[str] = Field(None)

    model_config = {"extra": "ignore"}

    # =========================================================================
    # Validators
    # =========================================================================

    @field_validator("sample_data", mode="before")
    @classmethod
    def normalize_sample_data(cls, v):
        """Convert integer-indexed sample_data to records format.

        Input (incorrect):
            {"col_a": {0: val0, 1: val1}, "col_b": {0: val0, 1: val1}}
        Output (correct):
            [{"col_a": val0, "col_b": val0}, {"col_a": val1, "col_b": val1}]
        """
        if isinstance(v, list):
            return v
        if isinstance(v, dict):
            first_val = next(iter(v.values()), None)
            if isinstance(first_val, dict):
                df = pd.DataFrame(v)
                return json.loads(df.to_json(orient="records"))
        raise ValueError(
            "sample_data must be a list of records or a column-indexed dict "
            "with integer keys (e.g. {col: {0: val, 1: val}})"
        )

    @field_validator("table_metadata", mode="before")
    @classmethod
    def normalize_table_metadata(cls, v):
        """Convert table_columns_info values from dict to list of {key, value} pairs.

        Input:
            {"COL": {"data_type": "number", "null_percentage": 0.0, ...}}
        Output:
            {"COL": [{"key": "data_type", "value": "number"}, ...]}
        """
        if not isinstance(v, dict):
            raise ValueError("table_metadata must be a dict")
        columns_info = v.get("table_columns_info", {})
        normalized = {}
        for col_name, col_info in columns_info.items():
            if isinstance(col_info, dict):
                normalized[col_name] = [
                    {"key": k, "value": val} for k, val in col_info.items()
                ]
            elif isinstance(col_info, list):
                normalized[col_name] = col_info
            else:
                raise ValueError(
                    f"table_columns_info['{col_name}'] must be a dict or list, "
                    f"got {type(col_info).__name__}"
                )
        v = dict(v)
        v["table_columns_info"] = normalized
        return v

    # =========================================================================
    # Helper methods
    # =========================================================================

    def get_column_descriptions(self) -> Dict[str, str]:
        """Get column name to description mapping."""
        return self.column_descriptions

    def get_feature_dtypes(self) -> Dict[str, str]:
        """Extract feature data types from table_metadata, mapped to logical types.

        Maps raw DB types (number, float, int, etc.) to logical types
        (NUMERICAL, TEXT, DATETIME, BOOLEAN).
        """
        dtypes = {}
        for col_name, col_info in self.table_metadata.table_columns_info.items():
            raw_type = None
            if isinstance(col_info, list):
                for item in col_info:
                    if isinstance(item, dict) and item.get("key") == "data_type":
                        raw_type = item["value"]
                        break
            if raw_type:
                dtypes[col_name] = map_raw_dtype_to_logical(raw_type)
            else:
                dtypes[col_name] = "TEXT"
        return dtypes

    def get_entity_description_dict(self) -> Dict[str, str]:
        """Return entity description as {entity_name: entity_description} dict."""
        return {self.entity_name: self.entity_description}

    def get_table_category(self) -> str:
        """Get the table category (entity name)."""
        return self.entity_name

    def get_use_case_string(self) -> Optional[str]:
        """Extract use case as a string for prompt usage."""
        if self.use_case is None:
            return None
        desc = self.use_case.description
        name = self.use_case.name or ""
        if desc:
            return f"{name}: {desc}" if name else desc
        return name if name else None

    def get_sample_data_json(self) -> str:
        """Get sample data as a JSON string in records format."""
        return json.dumps(self.sample_data, indent=4, default=str)

    def get_table_metadata_json(self) -> str:
        """Get table metadata as a JSON string."""
        return json.dumps(self.table_metadata.model_dump(), indent=4, default=str)
