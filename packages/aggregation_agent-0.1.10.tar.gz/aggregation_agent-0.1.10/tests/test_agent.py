import pytest
import pandas as pd
from unittest.mock import MagicMock, patch
import json
from aggregation_agent.agent import AggregationAgent
from aggregation_agent.config import AggregationConfig


@pytest.fixture
def agent():
    """Fixture to create an AggregationAgent with OpenAI provider."""
    config = AggregationConfig(
        provider="openai",
        model="gpt-4o-mini",
    )
    agent = AggregationAgent(config=config)
    yield agent


@pytest.fixture
def valid_task_data():
    """Valid task data matching the strict TaskDataInput schema."""
    return {
        "domain_name": "Test Domain",
        "domain_description": "A test domain description.",
        "entity_name": "Test Entity",
        "entity_description": "A test entity description.",
        "sample_data": [
            {"col1": 1, "col2": 3},
            {"col1": 2, "col2": 4},
        ],
        "table_metadata": {
            "table_info": {"row_count": 100},
            "table_columns_info": {
                "col1": {
                    "data_type": "number",
                    "null_percentage": 0.0,
                    "distinct_count": 100,
                    "freq/top5": [],
                    "min/max_value": [(1, 100)],
                    "date_distribution": [],
                },
                "col2": {
                    "data_type": "number",
                    "null_percentage": 0.0,
                    "distinct_count": 50,
                    "freq/top5": [],
                    "min/max_value": [(1, 50)],
                    "date_distribution": [],
                },
            },
        },
        "column_descriptions": {
            "col1": "First column",
            "col2": "Second column",
        },
        "mappings": {},
    }


def test_clean_json_string(agent):
    """Test the _clean_json_string method."""
    json_string = '```json\n{"key": [{"method": "Sum"}]}\n```'
    data_df = pd.DataFrame({"key": [1]})
    dtype_dict = {"key": "NUMERICAL"}
    agent.allowed_methods["NUMERICAL"] = ["Sum"]
    cleaned_json = agent._clean_json_string(json_string, data_df, dtype_dict)
    assert cleaned_json == {"key": [{"method": "Sum"}]}

    # Test with invalid JSON
    with pytest.raises(ValueError):
        agent._clean_json_string("not a json string", data_df, dtype_dict)


def test_get_dataframe_metadata(agent):
    """Test the _get_dataframe_metadata method produces list format."""
    data = {
        "col1": [1, 2, 3, 4, 5],
        "col2": ["A", "B", "A", "C", "B"],
        "col3": [1.1, 2.2, 3.3, 4.4, 5.5],
        "col4": [True, False, True, True, False],
        "col5": pd.to_datetime(
            ["2023-01-01", "2023-01-02", "2023-01-03", "2023-01-04", "2023-01-05"]
        ),
    }
    df = pd.DataFrame(data)
    metadata = agent._get_dataframe_metadata(df)

    assert metadata["table_info"]["row_count"] == 5
    assert "col1" in metadata["table_columns_info"]

    # table_columns_info values should be list of {key, value} pairs
    col1_info = metadata["table_columns_info"]["col1"]
    assert isinstance(col1_info, list)
    assert col1_info[0]["key"] == "data_type"
    assert col1_info[0]["value"] == "Int64"

    # Find distinct_count for col2
    col2_info = metadata["table_columns_info"]["col2"]
    distinct_entry = next(item for item in col2_info if item["key"] == "distinct_count")
    assert distinct_entry["value"] == 3


@patch("aggregation_agent.agent.AggregationAgent._get_group_by_field")
def test_execute_task_no_groupby(mock_get_group_by_field, agent, valid_task_data):
    """Test execute_task when the LLM fails to suggest a group-by column."""
    mock_get_group_by_field.return_value = ([], {})

    result = agent.execute_task(valid_task_data)
    assert not result["success"]
    assert "No valid group by column found" in result["error"]


def test_execute_task_invalid_input(agent):
    """Test execute_task with invalid input (missing required fields)."""
    result = agent.execute_task({"domain_name": "Test"})
    assert not result["success"]
    assert "Input validation failed" in result["error"]


def test_execute_task_old_format_rejected(agent):
    """Test that old format with 'file' key and no sample_data fails validation."""
    old_format = {
        "file": "dummy.csv",
        "domain_name": "test",
        "domain_description": "test",
        "column_description": {},
        "entity_description": {},
        "mappings": {},
        "table_category": "test",
    }
    result = agent.execute_task(old_format)
    assert not result["success"]
    assert "Input validation failed" in result["error"]
