import pytest
from pydantic import ValidationError
from aggregation_agent.models import (
    TaskDataInput,
    TableMetadata,
    UseCaseInfo,
    DataType,
    AggregationMethod,
    map_raw_dtype_to_logical,
)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def valid_task_data():
    """Minimal valid task data matching the strict schema."""
    return {
        "domain_name": "Wine Quality",
        "domain_description": "Evaluate wine quality based on chemical properties.",
        "entity_name": "Menu Item",
        "entity_description": "Represents food and beverage items.",
        "sample_data": [
            {"batch_no": 1, "fixed_acidity": 7.4, "quality": 5},
            {"batch_no": 2, "fixed_acidity": 6.3, "quality": 6},
        ],
        "table_metadata": {
            "table_info": {"row_count": 1599},
            "table_columns_info": {
                "BATCH_NO": {
                    "data_type": "number",
                    "null_percentage": 0.0,
                    "distinct_count": 1599,
                    "freq/top5": [(1, 1), (2, 1)],
                    "min/max_value": [(1, 1599)],
                    "date_distribution": [],
                },
                "FIXED_ACIDITY": {
                    "data_type": "float",
                    "null_percentage": 0.0,
                    "distinct_count": 96,
                    "freq/top5": [(7.2, 67)],
                    "min/max_value": [(4.6, 15.9)],
                    "date_distribution": [],
                },
                "QUALITY": {
                    "data_type": "number",
                    "null_percentage": 0.0,
                    "distinct_count": 6,
                    "freq/top5": [(5, 681), (6, 638)],
                    "min/max_value": [(3, 8)],
                    "date_distribution": [],
                },
            },
        },
        "column_descriptions": {
            "BATCH_NO": "Unique identifier for each batch.",
            "FIXED_ACIDITY": "Fixed acidity level of the wine.",
            "QUALITY": "Quality rating of the wine.",
        },
        "mappings": {"MenuItemID": "quality"},
    }


@pytest.fixture
def int_indexed_sample_data():
    """sample_data in incorrect integer-indexed format."""
    return {
        "batch_no": {0: 1, 1: 2, 2: 3},
        "fixed_acidity": {0: 7.4, 1: 6.3, 2: 5.9},
        "quality": {0: 5, 1: 6, 2: 5},
    }


# =============================================================================
# TaskDataInput validation tests
# =============================================================================


def test_valid_input(valid_task_data):
    """Valid input should pass validation."""
    validated = TaskDataInput(**valid_task_data)
    assert validated.domain_name == "Wine Quality"
    assert validated.entity_name == "Menu Item"
    assert len(validated.sample_data) == 2
    assert isinstance(validated.sample_data, list)


def test_sample_data_normalization(valid_task_data, int_indexed_sample_data):
    """Integer-indexed sample_data should be normalized to records format."""
    valid_task_data["sample_data"] = int_indexed_sample_data
    validated = TaskDataInput(**valid_task_data)

    assert isinstance(validated.sample_data, list)
    assert len(validated.sample_data) == 3
    assert validated.sample_data[0]["batch_no"] == 1
    assert validated.sample_data[1]["fixed_acidity"] == 6.3


def test_table_metadata_normalization(valid_task_data):
    """table_columns_info dict values should be normalized to list of {key, value}."""
    validated = TaskDataInput(**valid_task_data)

    batch_info = validated.table_metadata.table_columns_info["BATCH_NO"]
    assert isinstance(batch_info, list)
    assert batch_info[0] == {"key": "data_type", "value": "number"}
    assert batch_info[1] == {"key": "null_percentage", "value": 0.0}


def test_already_list_metadata_unchanged(valid_task_data):
    """table_columns_info already in list format should pass through unchanged."""
    valid_task_data["table_metadata"]["table_columns_info"]["BATCH_NO"] = [
        {"key": "data_type", "value": "number"},
        {"key": "null_percentage", "value": 0.0},
    ]
    validated = TaskDataInput(**valid_task_data)
    batch_info = validated.table_metadata.table_columns_info["BATCH_NO"]
    assert batch_info == [
        {"key": "data_type", "value": "number"},
        {"key": "null_percentage", "value": 0.0},
    ]


# =============================================================================
# Missing required fields
# =============================================================================


def test_missing_domain_name(valid_task_data):
    del valid_task_data["domain_name"]
    with pytest.raises(ValidationError, match="domain_name"):
        TaskDataInput(**valid_task_data)


def test_missing_entity_name(valid_task_data):
    del valid_task_data["entity_name"]
    with pytest.raises(ValidationError, match="entity_name"):
        TaskDataInput(**valid_task_data)


def test_missing_sample_data(valid_task_data):
    del valid_task_data["sample_data"]
    with pytest.raises(ValidationError, match="sample_data"):
        TaskDataInput(**valid_task_data)


def test_missing_table_metadata(valid_task_data):
    del valid_task_data["table_metadata"]
    with pytest.raises(ValidationError, match="table_metadata"):
        TaskDataInput(**valid_task_data)


def test_missing_column_descriptions(valid_task_data):
    del valid_task_data["column_descriptions"]
    with pytest.raises(ValidationError, match="column_descriptions"):
        TaskDataInput(**valid_task_data)


def test_missing_mappings(valid_task_data):
    del valid_task_data["mappings"]
    with pytest.raises(ValidationError, match="mappings"):
        TaskDataInput(**valid_task_data)


# =============================================================================
# Old format keys should NOT work (no backward compat)
# =============================================================================


def test_old_column_description_key_rejected(valid_task_data):
    """'column_description' (singular) should not be accepted."""
    del valid_task_data["column_descriptions"]
    valid_task_data["column_description"] = {"BATCH_NO": "some desc"}
    with pytest.raises(ValidationError, match="column_descriptions"):
        TaskDataInput(**valid_task_data)


def test_old_file_key_rejected(valid_task_data):
    """'file' key should be ignored (extra='ignore'), sample_data still required."""
    valid_task_data["file"] = "some.csv"
    # Should still work because sample_data is present and extra is ignored
    validated = TaskDataInput(**valid_task_data)
    assert len(validated.sample_data) == 2


# =============================================================================
# Helper method tests
# =============================================================================


def test_get_column_descriptions(valid_task_data):
    validated = TaskDataInput(**valid_task_data)
    descs = validated.get_column_descriptions()
    assert descs == valid_task_data["column_descriptions"]


def test_get_feature_dtypes(valid_task_data):
    validated = TaskDataInput(**valid_task_data)
    dtypes = validated.get_feature_dtypes()
    assert dtypes["BATCH_NO"] == "NUMERICAL"
    assert dtypes["FIXED_ACIDITY"] == "NUMERICAL"
    assert dtypes["QUALITY"] == "NUMERICAL"


def test_get_entity_description_dict(valid_task_data):
    validated = TaskDataInput(**valid_task_data)
    result = validated.get_entity_description_dict()
    assert result == {"Menu Item": "Represents food and beverage items."}


def test_get_table_category(valid_task_data):
    validated = TaskDataInput(**valid_task_data)
    assert validated.get_table_category() == "Menu Item"


def test_get_use_case_string_none(valid_task_data):
    validated = TaskDataInput(**valid_task_data)
    assert validated.get_use_case_string() is None


def test_get_use_case_string_name_only(valid_task_data):
    valid_task_data["use_case"] = {"name": "wine_quality_classification", "description": None}
    validated = TaskDataInput(**valid_task_data)
    assert validated.get_use_case_string() == "wine_quality_classification"


def test_get_use_case_string_with_description(valid_task_data):
    valid_task_data["use_case"] = {"name": "classify", "description": "Wine quality classification"}
    validated = TaskDataInput(**valid_task_data)
    assert validated.get_use_case_string() == "classify: Wine quality classification"


def test_get_sample_data_json(valid_task_data):
    validated = TaskDataInput(**valid_task_data)
    json_str = validated.get_sample_data_json()
    import json
    parsed = json.loads(json_str)
    assert isinstance(parsed, list)
    assert len(parsed) == 2


def test_get_table_metadata_json(valid_task_data):
    validated = TaskDataInput(**valid_task_data)
    json_str = validated.get_table_metadata_json()
    import json
    parsed = json.loads(json_str)
    assert parsed["table_info"]["row_count"] == 1599


# =============================================================================
# Type mapping tests
# =============================================================================


def test_map_raw_dtype_numerical():
    assert map_raw_dtype_to_logical("number") == "NUMERICAL"
    assert map_raw_dtype_to_logical("float") == "NUMERICAL"
    assert map_raw_dtype_to_logical("int") == "NUMERICAL"
    assert map_raw_dtype_to_logical("INTEGER") == "NUMERICAL"
    assert map_raw_dtype_to_logical("decimal") == "NUMERICAL"


def test_map_raw_dtype_datetime():
    assert map_raw_dtype_to_logical("date") == "DATETIME"
    assert map_raw_dtype_to_logical("timestamp") == "DATETIME"
    assert map_raw_dtype_to_logical("time") == "DATETIME"


def test_map_raw_dtype_boolean():
    assert map_raw_dtype_to_logical("boolean") == "BOOLEAN"
    assert map_raw_dtype_to_logical("bool") == "BOOLEAN"


def test_map_raw_dtype_text_fallback():
    assert map_raw_dtype_to_logical("string") == "TEXT"
    assert map_raw_dtype_to_logical("varchar") == "TEXT"
    assert map_raw_dtype_to_logical("unknown") == "TEXT"


# =============================================================================
# Enum tests
# =============================================================================


def test_data_type_enum():
    assert DataType.TEXT.value == "TEXT"
    assert DataType.NUMERICAL.value == "NUMERICAL"


def test_aggregation_method_enum():
    assert AggregationMethod.SUM.value == "Sum"
    assert AggregationMethod.MEAN.value == "Mean"
    assert AggregationMethod.UNIQUE_COUNT.value == "Unique Count"


# =============================================================================
# Extra fields ignored
# =============================================================================


def test_extra_fields_ignored(valid_task_data):
    """Extra fields not in the schema should be silently ignored."""
    valid_task_data["some_random_field"] = "should be ignored"
    valid_task_data["customer_id"] = 449
    validated = TaskDataInput(**valid_task_data)
    assert validated.customer_id == 449
