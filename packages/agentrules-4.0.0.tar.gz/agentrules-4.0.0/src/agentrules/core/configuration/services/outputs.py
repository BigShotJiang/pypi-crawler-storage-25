"""Output preference helpers."""

from __future__ import annotations

from agentrules.core.utils.constants import (
    DEFAULT_RULES_FILENAME,
    DEFAULT_RULES_TREE_MAX_DEPTH,
    DEFAULT_SNAPSHOT_FILENAME,
)

from ..models import CLIConfig, OutputPreferences
from ..utils import coerce_positive_int, normalize_output_filename, normalize_rules_filename


def get_output_preferences(config: CLIConfig) -> OutputPreferences:
    return config.outputs


def set_generate_cursorignore(config: CLIConfig, enabled: bool) -> None:
    config.outputs.generate_cursorignore = bool(enabled)


def should_generate_cursorignore(config: CLIConfig, default: bool = False) -> bool:
    return bool(config.outputs.generate_cursorignore) if config.outputs else default


def set_generate_agent_scaffold(config: CLIConfig, enabled: bool) -> None:
    config.outputs.generate_agent_scaffold = bool(enabled)


def should_generate_agent_scaffold(config: CLIConfig, default: bool = False) -> bool:
    return bool(config.outputs.generate_agent_scaffold) if config.outputs else default


def set_generate_phase_outputs(config: CLIConfig, enabled: bool) -> None:
    config.outputs.generate_phase_outputs = bool(enabled)


def should_generate_phase_outputs(config: CLIConfig, default: bool = True) -> bool:
    return bool(config.outputs.generate_phase_outputs) if config.outputs else default


def set_generate_snapshot(config: CLIConfig, enabled: bool) -> None:
    config.outputs.generate_snapshot = bool(enabled)


def should_generate_snapshot(config: CLIConfig, default: bool = True) -> bool:
    return bool(config.outputs.generate_snapshot) if config.outputs else default


def get_rules_filename(config: CLIConfig, default: str = DEFAULT_RULES_FILENAME) -> str:
    current = config.outputs.rules_filename if config.outputs else None
    normalized = normalize_rules_filename(current, default=default)
    if config.outputs:
        config.outputs.rules_filename = normalized
    return normalized


def set_rules_filename(config: CLIConfig, name: str) -> None:
    config.outputs.rules_filename = normalize_rules_filename(name, default=DEFAULT_RULES_FILENAME)


def get_snapshot_filename(config: CLIConfig, default: str = DEFAULT_SNAPSHOT_FILENAME) -> str:
    current = config.outputs.snapshot_filename if config.outputs else None
    normalized = normalize_output_filename(current, default=default)
    if config.outputs:
        config.outputs.snapshot_filename = normalized
    return normalized


def set_snapshot_filename(config: CLIConfig, name: str) -> None:
    config.outputs.snapshot_filename = normalize_output_filename(name, default=DEFAULT_SNAPSHOT_FILENAME)


def get_rules_tree_max_depth(
    config: CLIConfig,
    default: int = DEFAULT_RULES_TREE_MAX_DEPTH,
) -> int:
    current = config.outputs.rules_tree_max_depth if config.outputs else None
    normalized = coerce_positive_int(current, minimum=1, default=default) or default
    if config.outputs:
        config.outputs.rules_tree_max_depth = normalized
    return normalized


def set_rules_tree_max_depth(config: CLIConfig, value: int | None) -> None:
    normalized = coerce_positive_int(value, minimum=1, default=DEFAULT_RULES_TREE_MAX_DEPTH)
    config.outputs.rules_tree_max_depth = normalized or DEFAULT_RULES_TREE_MAX_DEPTH
