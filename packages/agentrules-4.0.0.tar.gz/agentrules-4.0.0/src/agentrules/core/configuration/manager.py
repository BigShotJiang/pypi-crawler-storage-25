"""High-level facade for runtime configuration operations."""

from __future__ import annotations

from collections.abc import Mapping, MutableMapping
from typing import Any

from agentrules.core.agents.codex import CodexProcessLaunchConfig
from agentrules.core.utils.constants import (
    DEFAULT_RULES_FILENAME,
    DEFAULT_RULES_TREE_MAX_DEPTH,
    DEFAULT_SNAPSHOT_FILENAME,
)
from agentrules.core.utils.provider_capabilities import uses_runtime_native_web_search

from .constants import RULES_FILENAME_ENV_VAR
from .environment import EnvironmentManager
from .models import CLIConfig, CodexConfig, CodexHomeStrategy, ExclusionOverrides, OutputPreferences, ResearcherMode
from .repository import ConfigRepository, TomlConfigRepository
from .services import codex, exclusions, features, outputs, phase_models, providers
from .services import logging as logging_service
from .utils import normalize_rules_filename


class ConfigManager:
    """Coordinates persistence, policy helpers, and environment behavior."""

    def __init__(
        self,
        repository: ConfigRepository | None = None,
        environ: MutableMapping[str, str] | None = None,
    ) -> None:
        self._repository = repository or TomlConfigRepository()
        self._environment = EnvironmentManager(environ)

    # ------------------------------------------------------------------
    # Core persistence helpers
    # ------------------------------------------------------------------
    def load(self) -> CLIConfig:
        return self._repository.load()

    def save(self, config: CLIConfig) -> None:
        self._repository.save(config)

    def apply_config_to_environment(self, config: CLIConfig | None = None) -> None:
        cfg = config or self._repository.load()
        self._environment.apply_provider_credentials(cfg)
        self._environment.apply_codex_runtime(cfg)

    # ------------------------------------------------------------------
    # Provider credentials
    # ------------------------------------------------------------------
    def set_provider_key(self, provider: str, api_key: str | None) -> CLIConfig:
        config = self._repository.load()
        providers.set_provider_key(config, provider, api_key)
        if provider == "tavily":
            if api_key:
                features.set_researcher_mode(config, "on")
            else:
                from . import model_presets

                researcher_config = model_presets.get_model_config_for_phase("researcher", config.models)
                if not uses_runtime_native_web_search(researcher_config):
                    features.set_researcher_mode(config, "off")
        self._repository.save(config)
        self._environment.apply_provider_credentials(config)
        return config

    def get_current_provider_keys(self) -> dict[str, str | None]:
        config = self._repository.load()
        return providers.current_provider_keys(config)

    def get_provider_availability(self) -> dict[str, bool]:
        config = self._repository.load()
        return providers.current_provider_availability(config, self._environment.getenv)

    def has_tavily_credentials(self, config: CLIConfig | None = None) -> bool:
        cfg = config or self._repository.load()
        return providers.has_tavily_credentials(cfg, self._environment.getenv)

    # ------------------------------------------------------------------
    # Codex runtime settings
    # ------------------------------------------------------------------
    def get_codex_config(self) -> CodexConfig:
        config = self._repository.load()
        normalized = codex.get_codex_config(config)
        self._repository.save(config)
        return normalized

    def set_codex_cli_path(self, cli_path: str | None) -> CLIConfig:
        config = self._repository.load()
        codex.set_codex_cli_path(config, cli_path)
        self._repository.save(config)
        self._environment.apply_codex_runtime(config)
        return config

    def set_codex_home_strategy(self, strategy: str | None) -> CLIConfig:
        config = self._repository.load()
        codex.set_codex_home_strategy(config, strategy)
        self._repository.save(config)
        self._environment.apply_codex_runtime(config)
        return config

    def set_codex_managed_home(self, managed_home: str | None) -> CLIConfig:
        config = self._repository.load()
        codex.set_codex_managed_home(config, managed_home)
        self._repository.save(config)
        self._environment.apply_codex_runtime(config)
        return config

    def get_codex_home_strategy(self) -> CodexHomeStrategy:
        config = self._repository.load()
        normalized = codex.get_codex_home_strategy(config)
        self._repository.save(config)
        return normalized

    def get_managed_codex_home(self) -> str:
        config = self._repository.load()
        normalized = codex.get_managed_codex_home(config)
        self._repository.save(config)
        return normalized

    def get_effective_codex_home(self) -> str | None:
        config = self._repository.load()
        return codex.get_effective_codex_home(config, self._environment.getenv_for_codex_runtime)

    def resolve_codex_executable(self) -> str | None:
        config = self._repository.load()
        return codex.resolve_codex_executable(config)

    def is_codex_available(self) -> bool:
        config = self._repository.load()
        return codex.is_codex_available(config)

    def build_codex_launch_config(
        self,
        *,
        cwd: str | None = None,
        config_overrides: Mapping[str, Any] | None = None,
    ) -> CodexProcessLaunchConfig:
        config = self._repository.load()
        return codex.build_codex_launch_config(
            config,
            self._environment.getenv_for_codex_runtime,
            cwd=cwd,
            config_overrides=config_overrides,
        )

    # ------------------------------------------------------------------
    # Phase model overrides
    # ------------------------------------------------------------------
    def set_phase_model(self, phase: str, preset_key: str | None) -> CLIConfig:
        config = self._repository.load()
        phase_models.set_phase_model(config, phase, preset_key)
        self._repository.save(config)
        return config

    def get_model_overrides(self) -> dict[str, str]:
        config = self._repository.load()
        return phase_models.get_model_overrides(config)

    # ------------------------------------------------------------------
    # Researcher feature toggles
    # ------------------------------------------------------------------
    def set_researcher_mode(self, mode: str | None) -> CLIConfig:
        config = self._repository.load()
        features.set_researcher_mode(config, mode)
        self._repository.save(config)
        return config

    def get_researcher_mode(self, default: ResearcherMode = "off") -> ResearcherMode:
        config = self._repository.load()
        previous = config.features.researcher_mode
        normalized = features.get_researcher_mode(config, default)
        if normalized != previous:
            self._repository.save(config)
        return normalized

    def is_researcher_enabled(self) -> bool:
        from . import model_presets

        config = self._repository.load()
        has_credentials = self.has_tavily_credentials(config)
        offline_mode = self._environment.is_truthy("OFFLINE")
        researcher_config = model_presets.get_model_config_for_phase("researcher", config.models)
        return features.is_researcher_enabled(
            config,
            offline_mode=offline_mode,
            has_tavily_credentials=has_credentials,
            supports_runtime_native_research=uses_runtime_native_web_search(researcher_config),
        )

    # ------------------------------------------------------------------
    # Logging preferences
    # ------------------------------------------------------------------
    def set_logging_verbosity(self, verbosity: str | None) -> CLIConfig:
        config = self._repository.load()
        logging_service.set_logging_verbosity(config, verbosity)
        self._repository.save(config)
        return config

    def get_logging_verbosity(self) -> str | None:
        config = self._repository.load()
        return logging_service.get_logging_verbosity(config)

    def resolve_log_level(self, default: int | None = None) -> int:
        config = self._repository.load()
        return self._environment.resolve_log_level(config, default)

    # ------------------------------------------------------------------
    # Output preferences
    # ------------------------------------------------------------------
    def get_output_preferences(self) -> OutputPreferences:
        config = self._repository.load()
        return outputs.get_output_preferences(config)

    def set_generate_cursorignore(self, enabled: bool) -> CLIConfig:
        config = self._repository.load()
        outputs.set_generate_cursorignore(config, enabled)
        self._repository.save(config)
        return config

    def should_generate_cursorignore(self, default: bool = False) -> bool:
        config = self._repository.load()
        return outputs.should_generate_cursorignore(config, default)

    def set_generate_agent_scaffold(self, enabled: bool) -> CLIConfig:
        config = self._repository.load()
        outputs.set_generate_agent_scaffold(config, enabled)
        self._repository.save(config)
        return config

    def should_generate_agent_scaffold(self, default: bool = False) -> bool:
        config = self._repository.load()
        return outputs.should_generate_agent_scaffold(config, default)

    def set_generate_phase_outputs(self, enabled: bool) -> CLIConfig:
        config = self._repository.load()
        outputs.set_generate_phase_outputs(config, enabled)
        self._repository.save(config)
        return config

    def should_generate_phase_outputs(self, default: bool = True) -> bool:
        config = self._repository.load()
        return outputs.should_generate_phase_outputs(config, default)

    def set_generate_snapshot(self, enabled: bool) -> CLIConfig:
        config = self._repository.load()
        outputs.set_generate_snapshot(config, enabled)
        self._repository.save(config)
        return config

    def should_generate_snapshot(self, default: bool = True) -> bool:
        config = self._repository.load()
        return outputs.should_generate_snapshot(config, default)

    def get_rules_filename(self, default: str | None = None) -> str:
        config = self._repository.load()
        fallback = default if default is not None else DEFAULT_RULES_FILENAME
        previous = config.outputs.rules_filename
        normalized = outputs.get_rules_filename(config, fallback)
        if normalized != previous:
            self._repository.save(config)
        return normalized

    def resolve_rules_filename(
        self,
        override: str | None = None,
        *,
        default: str | None = None,
    ) -> str:
        configured = self.get_rules_filename(default=default)
        env_override = self._environment.getenv(RULES_FILENAME_ENV_VAR)
        resolved_from_env = normalize_rules_filename(env_override, default=configured)
        return normalize_rules_filename(override, default=resolved_from_env)

    def set_rules_filename(self, name: str) -> CLIConfig:
        config = self._repository.load()
        outputs.set_rules_filename(config, name)
        self._repository.save(config)
        return config

    def get_snapshot_filename(self, default: str | None = None) -> str:
        config = self._repository.load()
        previous = config.outputs.snapshot_filename
        normalized = outputs.get_snapshot_filename(config, default or DEFAULT_SNAPSHOT_FILENAME)
        if normalized != previous:
            self._repository.save(config)
        return normalized

    def set_snapshot_filename(self, name: str) -> CLIConfig:
        config = self._repository.load()
        outputs.set_snapshot_filename(config, name)
        self._repository.save(config)
        return config

    def get_rules_tree_max_depth(self, default: int = DEFAULT_RULES_TREE_MAX_DEPTH) -> int:
        config = self._repository.load()
        previous = config.outputs.rules_tree_max_depth
        normalized = outputs.get_rules_tree_max_depth(config, default)
        if normalized != previous:
            self._repository.save(config)
        return normalized

    def set_rules_tree_max_depth(self, value: int | None) -> CLIConfig:
        config = self._repository.load()
        outputs.set_rules_tree_max_depth(config, value)
        self._repository.save(config)
        return config

    # ------------------------------------------------------------------
    # Exclusions management
    # ------------------------------------------------------------------
    def get_exclusion_overrides(self) -> ExclusionOverrides:
        config = self._repository.load()
        return exclusions.get_exclusion_overrides(config)

    def get_effective_exclusions(self) -> tuple[set[str], set[str], set[str]]:
        config = self._repository.load()
        return exclusions.get_effective_exclusions(config)

    def get_managed_output_relative_paths(
        self,
        *,
        rules_filename: str | None = None,
        snapshot_filename: str | None = None,
    ) -> set[str]:
        config = self._repository.load()
        return exclusions.get_managed_output_relative_paths(
            config,
            rules_filename=rules_filename,
            snapshot_filename=snapshot_filename,
        )

    def add_exclusion_entry(self, kind: str, value: str) -> str | None:
        config = self._repository.load()
        normalized = exclusions.add_exclusion_entry(config, kind, value)
        if normalized is not None:
            self._repository.save(config)
        return normalized

    def remove_exclusion_entry(self, kind: str, value: str) -> str | None:
        config = self._repository.load()
        normalized = exclusions.remove_exclusion_entry(config, kind, value)
        if normalized is not None:
            self._repository.save(config)
        return normalized

    def reset_exclusions(self) -> CLIConfig:
        config = self._repository.load()
        exclusions.reset_exclusions(config)
        self._repository.save(config)
        return config

    def set_respect_gitignore(self, enabled: bool) -> CLIConfig:
        config = self._repository.load()
        exclusions.set_respect_gitignore(config, enabled)
        self._repository.save(config)
        return config

    def should_respect_gitignore(self, default: bool = True) -> bool:
        config = self._repository.load()
        return exclusions.should_respect_gitignore(config, default)

    def get_tree_max_depth(self, default: int = 5) -> int:
        config = self._repository.load()
        return exclusions.get_tree_max_depth(config, default)

    def set_tree_max_depth(self, value: int | None) -> CLIConfig:
        config = self._repository.load()
        exclusions.set_tree_max_depth(config, value)
        self._repository.save(config)
        return config

    def reset_tree_max_depth(self) -> CLIConfig:
        config = self._repository.load()
        exclusions.reset_tree_max_depth(config)
        self._repository.save(config)
        return config
