"""PathCourse API client."""

import os
import httpx
from typing import List, Optional, Union

from pathcourse.models import ChatMessage, ChatResponse, EmbeddingResponse, PCH_FAST, PCH_EMBED
from pathcourse.exceptions import (
    PathCourseError,
    AuthenticationError,
    RateLimitError,
    InsufficientBalanceError,
    ModelNotInTierError,
    ModelNotFoundError,
    InferenceUnavailableError,
    GatewayError,
)

DEFAULT_BASE_URL = "https://gateway.pathcoursehealth.com"
DEFAULT_TIMEOUT = 60.0


class PathCourseClient:
    """
    Synchronous client for the PathCourse AI gateway.

    Usage:
        from pathcourse import PathCourseClient, PCH_FAST

        client = PathCourseClient(api_key="your-key")
        response = client.chat(
            model=PCH_FAST,
            messages=[{"role": "user", "content": "Hello"}]
        )
        print(response.text)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key or os.environ.get("PCH_API_KEY")
        if not self.api_key:
            raise AuthenticationError(
                "No API key provided. Pass api_key= or set PCH_API_KEY env var."
            )
        self.base_url = (base_url or os.environ.get("PCH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=self.timeout,
        )

    def chat(
        self,
        messages: List[Union[ChatMessage, dict]],
        model: str = PCH_FAST,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs,
    ) -> ChatResponse:
        """
        Send a chat completion request.

        Args:
            messages: List of ChatMessage objects or dicts with 'role' and 'content'.
            model: Model name constant (e.g. PCH_FAST, PCH_PRO, PCH_CODER).
            temperature: Sampling temperature 0.0-1.0.
            max_tokens: Maximum tokens in the response.

        Returns:
            ChatResponse with .text convenience accessor.
        """
        normalized = []
        for m in messages:
            if isinstance(m, ChatMessage):
                normalized.append({"role": m.role, "content": m.content})
            else:
                normalized.append(m)

        payload = {
            "model": model,
            "messages": normalized,
            "temperature": temperature,
            "max_tokens": max_tokens,
            **kwargs,
        }

        try:
            resp = self._client.post("/v1/chat/completions", json=payload)
        except httpx.TimeoutException:
            raise PathCourseError("Request timed out. Try increasing timeout=.")
        except httpx.RequestError as e:
            raise GatewayError(f"Connection error: {e}")

        self._raise_for_status(resp)
        data = resp.json()

        choice = data["choices"][0]
        return ChatResponse(
            id=data.get("id", ""),
            model=data.get("model", model),
            content=choice["message"]["content"],
            usage=data.get("usage", {}),
        )

    def embed(
        self,
        input: Union[str, List[str]],
        model: str = PCH_EMBED,
    ) -> EmbeddingResponse:
        """
        Generate text embeddings.

        Args:
            input: A string or list of strings to embed.
            model: Embedding model (default: PCH_EMBED).

        Returns:
            EmbeddingResponse with .embeddings list.
        """
        if isinstance(input, str):
            input = [input]

        payload = {"model": model, "input": input}

        try:
            resp = self._client.post("/v1/embeddings", json=payload)
        except httpx.TimeoutException:
            raise PathCourseError("Embedding request timed out.")
        except httpx.RequestError as e:
            raise GatewayError(f"Connection error: {e}")

        self._raise_for_status(resp)
        data = resp.json()

        embeddings = [d["embedding"] for d in data.get("data", [])]
        return EmbeddingResponse(
            embeddings=embeddings,
            model=data.get("model", model),
            usage=data.get("usage", {}),
        )

    def translate(
        self,
        text: str,
        target_language: str,
        source_language: Optional[str] = None,
    ) -> dict:
        """
        Translate text using pch-translate.

        Args:
            text: Text to translate.
            target_language: ISO language code (e.g. 'en', 'fr', 'de').
            source_language: Optional source language (auto-detected if omitted).

        Returns:
            dict with translated_text, source_language, target_language, usage.
        """
        payload = {
            "model": "pch-translate",
            "text": text,
            "target_language": target_language,
        }
        if source_language:
            payload["source_language"] = source_language

        try:
            resp = self._client.post("/v1/translate", json=payload)
        except httpx.TimeoutException:
            raise PathCourseError("Translation request timed out.")
        except httpx.RequestError as e:
            raise GatewayError(f"Connection error: {e}")

        self._raise_for_status(resp)
        return resp.json()

    def extract(
        self,
        text: str,
        entity_types: List[str],
    ) -> dict:
        """
        Extract named entities using pch-extract (zero-shot NER).

        Args:
            text: Text to extract entities from.
            entity_types: List of entity type labels (e.g. ['PERSON', 'ORG', 'DATE']).

        Returns:
            dict with entities list and usage.
        """
        payload = {
            "model": "pch-extract",
            "text": text,
            "entity_types": entity_types,
        }

        try:
            resp = self._client.post("/v1/extract", json=payload)
        except httpx.TimeoutException:
            raise PathCourseError("Extraction request timed out.")
        except httpx.RequestError as e:
            raise GatewayError(f"Connection error: {e}")

        self._raise_for_status(resp)
        return resp.json()

    # ── Provisioning ────────────────────────────────────────────────────────
    def claim_key(self, tx_hash: str, wallet: str, poll: bool = True) -> dict:
        """
        Retrieve your API key after depositing USDC to the PCH treasury wallet.

        Polls GET /v1/keys/claim until the key is ready. With poll=True (default)
        this method blocks through the 202 provisioning window; with poll=False
        it returns whatever the first response gives.

        Args:
            tx_hash: The Base L2 transaction hash of the USDC deposit.
            wallet:  The wallet address the USDC was sent from.
            poll:    If True, retry on 202 Accepted until 200 or attempts exhaust.

        Returns:
            dict with api_key, tier, balance_usdc, agent_id.
        """
        import time
        max_attempts = 10 if poll else 1
        last_data = None
        for attempt in range(max_attempts):
            try:
                resp = self._client.get(
                    "/v1/keys/claim",
                    params={"tx_hash": tx_hash, "wallet": wallet},
                )
            except httpx.RequestError as e:
                raise GatewayError(f"Connection error: {e}")

            if resp.status_code == 200:
                return resp.json()

            data = resp.json() if resp.text else {}
            last_data = data

            if resp.status_code == 202 and poll:
                time.sleep(data.get("retry_after_seconds", 15))
                continue
            if resp.status_code == 404 and data.get("error") == "payment_not_found" and poll and attempt < 3:
                time.sleep(30)
                continue
            if resp.status_code >= 400:
                self._raise_for_status(resp)

            if not poll:
                return data

        raise PathCourseError(
            "API key provisioning timed out. "
            "Verify the transaction has confirmed on Base and retry.",
            status_code=504,
            response=last_data,
        )

    def get_balance(self) -> dict:
        """
        Get your current USDC balance on the PathCourse platform.

        Returns:
            dict with balance_usdc, tier, low_balance (bool), topup instructions.
        """
        return self._get_json("/v1/balance")

    # ── Discovery (public, no auth required) ────────────────────────────────
    def get_models(self) -> dict:
        """List all available models (OpenAI-compatible shape)."""
        return self._get_json("/v1/models")

    def get_pricing(self) -> dict:
        """Fetch the current machine-readable rate sheet."""
        return self._get_json("/v1/pricing")

    # ── Usage & accounting ──────────────────────────────────────────────────
    def get_usage(
        self,
        limit: int = 50,
        model: Optional[str] = None,
        since: Optional[str] = None,
    ) -> dict:
        """
        Fetch your spend history from the PCH ledger.

        Args:
            limit: Max records to return (1..500).
            model: Optional model filter (e.g. 'pch-fast').
            since: Optional ISO-8601 cutoff timestamp.
        """
        params = {"limit": limit}
        if model: params["model"] = model
        if since: params["since"] = since
        return self._get_json("/v1/usage", params=params)

    def get_runway(self) -> dict:
        """Balance-runway forecast: days of service remaining at current burn."""
        return self._get_json("/v1/obs/runway")

    # ── Spend cap ───────────────────────────────────────────────────────────
    def set_budget(self, daily_limit_usdc: float) -> dict:
        """
        Set a daily USDC spend cap, enforced server-side. Pass 0 to remove.
        Resets at midnight UTC.
        """
        return self._post_json("/v1/budget", {"daily_limit_usdc": daily_limit_usdc})

    def get_budget(self) -> dict:
        """Read the current daily spend cap and today's running total."""
        return self._get_json("/v1/budget")

    # ── Webhook alerts ──────────────────────────────────────────────────────
    def register_webhook(self, url: str, threshold_usdc: float = 25.0) -> dict:
        """
        Register a URL to receive balance_low / balance_floor events when your
        balance crosses the threshold.
        """
        return self._post_json(
            "/v1/webhook",
            {"url": url, "threshold_usdc": threshold_usdc},
        )

    def get_webhook(self) -> dict:
        """Read the currently-registered webhook config."""
        return self._get_json("/v1/webhook")

    def delete_webhook(self) -> dict:
        """Remove the registered webhook."""
        try:
            resp = self._client.delete("/v1/webhook")
        except httpx.RequestError as e:
            raise GatewayError(f"Connection error: {e}")
        self._raise_for_status(resp)
        return resp.json()

    # ── Internal helpers ────────────────────────────────────────────────────
    def _get_json(self, path: str, params: Optional[dict] = None) -> dict:
        try:
            resp = self._client.get(path, params=params or {})
        except httpx.RequestError as e:
            raise GatewayError(f"Connection error: {e}")
        self._raise_for_status(resp)
        return resp.json()

    def _post_json(self, path: str, body: dict) -> dict:
        try:
            resp = self._client.post(path, json=body)
        except httpx.RequestError as e:
            raise GatewayError(f"Connection error: {e}")
        self._raise_for_status(resp)
        return resp.json()

    def rerank(
        self,
        query: str,
        documents: List[str],
        top_n: Optional[int] = None,
    ) -> dict:
        """
        Rerank documents by relevance to a query using pch-rerank.

        Args:
            query: The search query.
            documents: List of document strings to rank.
            top_n: Optional number of top results to return.

        Returns:
            dict with ranked results list and usage.
        """
        payload = {
            "model": "pch-rerank",
            "query": query,
            "documents": documents,
        }
        if top_n is not None:
            payload["top_n"] = top_n

        try:
            resp = self._client.post("/v1/rerank", json=payload)
        except httpx.TimeoutException:
            raise PathCourseError("Rerank request timed out.")
        except httpx.RequestError as e:
            raise GatewayError(f"Connection error: {e}")

        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, response: httpx.Response):
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key.", status_code=401)
        if response.status_code == 402:
            raise InsufficientBalanceError(
                "Insufficient USDC balance. Top up at the treasury wallet.",
                status_code=402, response=response.json() if response.text else None,
            )
        if response.status_code == 403:
            raise ModelNotInTierError(
                "Model not available for your certification tier. Upgrade or choose a different model.",
                status_code=403, response=response.json() if response.text else None,
            )
        if response.status_code == 429:
            raise RateLimitError("Rate limit exceeded.", status_code=429)
        if response.status_code == 404:
            raise ModelNotFoundError("Model not found.", status_code=404)
        if response.status_code == 503:
            raise InferenceUnavailableError(
                "Inference service temporarily unavailable for this model.",
                status_code=503,
            )
        if response.status_code >= 500:
            raise GatewayError(
                f"Gateway error {response.status_code}: {response.text}",
                status_code=response.status_code,
            )
        if response.status_code >= 400:
            raise PathCourseError(
                f"Request error {response.status_code}: {response.text}",
                status_code=response.status_code,
            )

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
