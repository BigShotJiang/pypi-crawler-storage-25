import hashlib
import json
import os
from pathlib import Path
from typing import Dict, Optional, Set

STATE_DIR = ".starspace"
STATE_FILE = ".starspace/state.json"

def get_state_path(root: Path) -> Path:
    return root / STATE_FILE

def load_local_state(root: Path) -> Dict[str, str]:
    """Load the last known state from .starspace/state.json."""
    state_path = get_state_path(root)
    if not state_path.exists():
        return {}
    try:
        with open(state_path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}

def save_local_state(root: Path, state: Dict[str, str]):
    """Save the current state to .starspace/state.json."""
    state_dir = root / STATE_DIR
    state_dir.mkdir(exist_ok=True)
    state_path = get_state_path(root)
    with open(state_path, "w") as f:
        json.dump(state, f, indent=2)

def compute_sha256(file_path: Path) -> str:
    """Compute SHA-256 hash of a file."""
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

def compute_local_state(root: Path, ignore_dirs: Set[str], ignore_files: Set[str], allowed_ext: Set[str], max_size: int) -> Dict[str, str]:
    """Compute SHA-256 hashes for all files in the root directory, respecting ignore rules."""
    # Avoid circular import by importing inside the function
    from starspace_cli.commands.sync import should_ignore
    
    state = {}
    for dirpath, dirs, fnames in os.walk(root):
        # Modify dirs in-place to skip ignored directories
        dirs[:] = [d for d in dirs if d not in ignore_dirs and d != STATE_DIR]
        
        for f in fnames:
            fp = Path(dirpath) / f
            try:
                rel = fp.relative_to(root)
            except ValueError:
                continue
            
            if should_ignore(rel):
                continue
                
            try:
                if fp.stat().st_size > max_size:
                    continue
                state[rel.as_posix()] = compute_sha256(fp)
            except (OSError, ValueError, FileNotFoundError):
                continue
                
    return state

def compare_states(local_state: Dict[str, str], remote_state: Dict[str, str]):
    """Compare local and remote states to find differences."""
    added = []
    modified = []
    deleted = []
    
    for path, remote_hash in remote_state.items():
        if path not in local_state:
            added.append(path)
        elif local_state[path] != remote_hash:
            modified.append(path)
            
    for path in local_state:
        if path not in remote_state:
            deleted.append(path)
            
    return {
        "added": added,
        "modified": modified,
        "deleted": deleted
    }
