"""StarSpace CLI exception types and exit-code mapping.

Exit codes are part of the CLI contract - scripts and AI agents depend on them
to dispatch on outcomes without parsing stdout. They MUST stay stable.

  0  success
  1  user error (bad arg, missing config, file not found locally, validation)
  2  server error (5xx from API)
  3  auth error (401/403)
  4  quota / rate limit (429)
"""
from __future__ import annotations

from typing import Any, Optional


class StarSpaceError(Exception):
    """Raised for any non-2xx response from the StarSpace API.

    Carries the structured error fields (code, message, hint, details) plus
    the originating HTTP status. The CLI top-level handler reads `exit_code`
    to set the process exit code.
    """

    def __init__(
        self,
        message: str,
        *,
        code: str = "unknown_error",
        hint: Optional[str] = None,
        details: Optional[dict] = None,
        status_code: Optional[int] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.hint = hint
        self.details = details
        self.status_code = status_code

    @property
    def exit_code(self) -> int:
        s = self.status_code or 0
        if s in (401, 403):
            return 3
        if s == 429:
            return 4
        if 500 <= s < 600:
            return 2
        return 1

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.hint:
            out["hint"] = self.hint
        if self.details:
            out["details"] = self.details
        if self.status_code is not None:
            out["status"] = self.status_code
        return out
