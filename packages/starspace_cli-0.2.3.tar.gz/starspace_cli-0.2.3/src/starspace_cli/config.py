"""StarSpace CLI configuration loading.

Lookup precedence:
    1. Environment variables (STARSPACE_WORKSPACE_ID, STARSPACE_WORKSPACE_API_KEY,
       STARSPACE_BASE_URL) - including those loaded from a local .env via python-dotenv.
    2. Project-scoped config: ./.starspace/config.json (if present).
    3. Global config: ~/.config/starspace/config.json on Linux/macOS,
       %APPDATA%/starspace/config.json on Windows. Resolved via platformdirs when
       available; falls back to ~/.config/starspace/config.json otherwise.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv


PROJECT_CONFIG_REL = Path(".starspace") / "config.json"
GLOBAL_CONFIG_FILENAME = "config.json"
APP_NAME = "starspace"


@dataclass
class Config:
    workspace_id: str
    api_key: str
    base_url: Optional[str] = None
    source: str = "env"  # "env" | "project" | "global"


def project_config_path(root: Optional[Path] = None) -> Path:
    return (root or Path.cwd()) / PROJECT_CONFIG_REL


def global_config_path() -> Path:
    """Return the OS-appropriate global config path.

    Uses platformdirs.user_config_dir if installed; otherwise falls back to
    ~/.config/starspace/config.json (the value documented in the plan).
    """
    try:
        from platformdirs import user_config_dir  # type: ignore

        return Path(user_config_dir(APP_NAME, appauthor=False)) / GLOBAL_CONFIG_FILENAME
    except ImportError:
        return Path.home() / ".config" / APP_NAME / GLOBAL_CONFIG_FILENAME


def _read_json_config(path: Path) -> dict:
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def write_global_config(workspace_id: str, api_key: str, base_url: Optional[str] = None) -> Path:
    """Persist config to the global config file. Creates parent dirs."""
    return _write_config(global_config_path(), workspace_id, api_key, base_url)


def write_project_config(workspace_id: str, api_key: str, base_url: Optional[str] = None, root: Optional[Path] = None) -> Path:
    """Persist config to ./.starspace/config.json. Creates parent dirs."""
    return _write_config(project_config_path(root), workspace_id, api_key, base_url)


def _write_config(path: Path, workspace_id: str, api_key: str, base_url: Optional[str]) -> Path:
    payload = {"workspace_id": workspace_id, "api_key": api_key}
    if base_url:
        payload["base_url"] = base_url
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


def load_config(allow_partial: bool = False) -> Config:
    """Resolve a Config object from env vars, project config, or global config.

    Raises ValueError if required fields are missing and allow_partial is False.
    """
    load_dotenv()

    env_workspace = os.getenv("STARSPACE_WORKSPACE_ID")
    env_api_key = os.getenv("STARSPACE_WORKSPACE_API_KEY")
    env_base_url = os.getenv("STARSPACE_BASE_URL")

    if env_workspace and env_api_key:
        return Config(
            workspace_id=env_workspace,
            api_key=env_api_key,
            base_url=env_base_url,
            source="env",
        )

    project_path = project_config_path()
    if project_path.exists():
        data = _read_json_config(project_path)
        ws = env_workspace or data.get("workspace_id")
        ak = env_api_key or data.get("api_key")
        base = env_base_url or data.get("base_url")
        if ws and ak:
            return Config(workspace_id=ws, api_key=ak, base_url=base, source="project")

    global_path = global_config_path()
    if global_path.exists():
        data = _read_json_config(global_path)
        ws = env_workspace or data.get("workspace_id")
        ak = env_api_key or data.get("api_key")
        base = env_base_url or data.get("base_url")
        if ws and ak:
            return Config(workspace_id=ws, api_key=ak, base_url=base, source="global")

    if allow_partial:
        return Config(
            workspace_id=env_workspace or "",
            api_key=env_api_key or "",
            base_url=env_base_url,
            source="env",
        )

    if not env_workspace and not project_path.exists() and not global_path.exists():
        raise ValueError(
            "No StarSpace config found. Run `starspace init` to set up your workspace, "
            "or set STARSPACE_WORKSPACE_ID and STARSPACE_WORKSPACE_API_KEY in your environment."
        )

    if not (env_workspace or _config_has(project_path, "workspace_id") or _config_has(global_path, "workspace_id")):
        raise ValueError("STARSPACE_WORKSPACE_ID is not set (env, project config, or global config)")
    if not (env_api_key or _config_has(project_path, "api_key") or _config_has(global_path, "api_key")):
        raise ValueError("STARSPACE_WORKSPACE_API_KEY is not set (env, project config, or global config)")

    raise ValueError("Could not resolve workspace_id and api_key from any source")


def _config_has(path: Path, key: str) -> bool:
    if not path.exists():
        return False
    return bool(_read_json_config(path).get(key))
