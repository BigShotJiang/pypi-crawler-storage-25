"""`starspace doctor` - diagnostics for "why isn't this working".

Checks (in order):
    1. Config exists somewhere (env, project, or global).
    2. API key is valid against /whoami.
    3. Base URL is reachable.
    4. MCP client config files are writable (or absent - that's fine, we'd create them).
    5. Local sync state exists (.starspace/state.json).
"""

from __future__ import annotations

import os
import platform
from pathlib import Path
from typing import List, Tuple

import requests
import typer

from starspace_cli import output
from starspace_cli.client import StarSpaceClient, resolve_base_url
from starspace_cli.config import Config, load_config
from starspace_cli.errors import StarSpaceError


CheckResult = Tuple[str, str, str]  # (status, label, detail)
OK = "ok"
WARN = "warn"
FAIL = "fail"


def _claude_desktop_config_path() -> Path:
    system = platform.system()
    if system == "Darwin":
        return Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    if system == "Windows":
        return Path(os.environ.get("APPDATA", str(Path.home()))) / "Claude" / "claude_desktop_config.json"
    return Path.home() / ".config" / "Claude" / "claude_desktop_config.json"


def _cursor_mcp_config_path() -> Path:
    return Path.home() / ".cursor" / "mcp.json"


def _check_writable(path: Path) -> CheckResult:
    if path.exists():
        if os.access(path, os.W_OK):
            return (OK, str(path), "exists and writable")
        return (FAIL, str(path), "exists but not writable")
    parent = path.parent
    if parent.exists():
        if os.access(parent, os.W_OK):
            return (OK, str(path), "parent dir writable; will be created on `starspace connect`")
        return (FAIL, str(path), f"parent dir {parent} is not writable")
    return (WARN, str(path), f"parent dir {parent} does not exist; will be created on `starspace connect`")


def _format_status(status: str) -> str:
    if status == OK:
        return typer.style("✓ ok  ", fg=typer.colors.GREEN)
    if status == WARN:
        return typer.style("! warn", fg=typer.colors.YELLOW)
    return typer.style("✗ fail", fg=typer.colors.RED)


def doctor():
    """Run StarSpace CLI diagnostics."""
    if not output.STATE.json_output:
        typer.echo("StarSpace CLI diagnostics\n")

    results: List[CheckResult] = []

    try:
        cfg: Config = load_config()
        results.append((OK, "config", f"loaded from {cfg.source} (workspace: {cfg.workspace_id})"))
    except ValueError as e:
        results.append((FAIL, "config", str(e)))
        cfg = None  # type: ignore

    base = resolve_base_url(cfg.base_url if cfg else None)
    try:
        r = requests.get(f"{base}/functions/v1/whoami", timeout=10)
        if r.status_code in (200, 401, 405):
            results.append((OK, "base url", f"{base} reachable ({r.status_code})"))
        else:
            results.append((WARN, "base url", f"{base} returned {r.status_code}"))
    except requests.RequestException as e:
        results.append((FAIL, "base url", f"{base} unreachable: {e}"))

    if cfg:
        try:
            client = StarSpaceClient(api_key=cfg.api_key, base_url=cfg.base_url)
            info = client.whoami()
            tier = info.get("tier", "free")
            prefix = info.get("key_prefix", "")
            ws = info.get("workspace_id", "")
            if ws and cfg.workspace_id and ws != cfg.workspace_id:
                results.append((
                    FAIL,
                    "api key",
                    f"key belongs to workspace {ws}, but config says {cfg.workspace_id}",
                ))
            else:
                results.append((OK, "api key", f"valid (tier: {tier}, prefix: {prefix})"))
        except StarSpaceError as e:
            detail = f"[{e.code}] {e.message}"
            if e.hint:
                detail = f"{detail} - hint: {e.hint}"
            results.append((FAIL, "api key", detail))
        except Exception as e:
            results.append((FAIL, "api key", str(e)))
    else:
        results.append((WARN, "api key", "skipped (no config)"))

    results.append(_with_label(_check_writable(_claude_desktop_config_path()), "claude desktop"))
    results.append(_with_label(_check_writable(_cursor_mcp_config_path()), "cursor mcp"))

    state_path = Path.cwd() / ".starspace" / "state.json"
    if state_path.exists():
        try:
            mtime = state_path.stat().st_mtime
            from datetime import datetime
            ts = datetime.fromtimestamp(mtime).isoformat(timespec="seconds")
            results.append((OK, "sync state", f"{state_path} - last updated {ts}"))
        except OSError as e:
            results.append((WARN, "sync state", f"{state_path} unreadable: {e}"))
    else:
        results.append((WARN, "sync state", f"{state_path} not found (run `starspace push` to create)"))

    fails = sum(1 for s, _, _ in results if s == FAIL)
    warns = sum(1 for s, _, _ in results if s == WARN)

    if output.STATE.json_output:
        output.result({
            "checks": [{"status": s, "label": l, "detail": d} for s, l, d in results],
            "summary": {
                "passed": sum(1 for s, _, _ in results if s == OK),
                "warnings": warns,
                "failures": fails,
            },
        })
        if fails:
            raise typer.Exit(code=1)
        return

    label_width = max(len(label) for _, label, _ in results)
    for status, label, detail in results:
        typer.echo(f"  {_format_status(status)}  {label:<{label_width}}  {detail}")

    typer.echo("")
    if fails:
        typer.echo(typer.style(f"{fails} failure(s), {warns} warning(s)", fg=typer.colors.RED))
        raise typer.Exit(code=1)
    if warns:
        typer.echo(typer.style(f"{warns} warning(s) - should still work", fg=typer.colors.YELLOW))
    else:
        typer.echo(typer.style("all checks passed", fg=typer.colors.GREEN))


def _with_label(result: CheckResult, label: str) -> CheckResult:
    status, _, detail = result
    return (status, label, detail)
