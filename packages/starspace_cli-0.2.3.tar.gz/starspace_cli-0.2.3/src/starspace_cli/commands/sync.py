import io
import json as _json
import os
import shutil
import zipfile
from pathlib import Path
from typing import Optional

import typer

from starspace_cli import output
from starspace_cli.client import StarSpaceClient
from starspace_cli.config import load_config
from starspace_cli import state as state_utils

app = typer.Typer()

# ── Configuration ────────────────────────────────────────────────
IGNORE_DIRS = {
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "node_modules",
    ".mypy_cache",
    ".pytest_cache",
    ".cursor",
    ".vscode",
    "data",
    "dist",
    "build",
    ".next",
    "coverage",
    ".nuxt",
    ".turbo",
    ".cache",
    ".branches",
    ".temp",
    ".starspace",
}

IGNORE_FILES = {".env", ".DS_Store", "Thumbs.db"}

ALLOWED_EXT = {
    ".py",
    ".md",
    ".txt",
    ".json",
    ".yaml",
    ".yml",
    ".sh",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".mjs",
    ".cjs",
    ".html",
    ".css",
    ".scss",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".rs",
    ".go",
    ".sql",
    ".toml",
    ".lock",
}

DEFAULT_MAX_FILE_SIZE = 1_000_000  # 1 MB
BATCH_SIZE = 500


def should_ignore(rel: Path) -> Optional[str]:
    """Return None if included, or a skip reason string."""
    for part in rel.parts:
        if part in IGNORE_DIRS:
            return f"ignored_dir:{part}"
    if rel.name in IGNORE_FILES:
        return "ignored_file"
    if rel.suffix and rel.suffix not in ALLOWED_EXT:
        return f"extension:{rel.suffix or '(none)'}"
    if not rel.suffix and rel.name not in {"Dockerfile", "Makefile", "LICENSE", ".gitignore", ".prewarm", ".prettierignore"}:
        return "no_allowed_extension"
    return None


def collect_files(
    root: Path,
    max_size: int,
) -> tuple[list[tuple[Path, Path]], dict[str, int]]:
    """Return (included (abs, rel), skip_reason_counts)."""
    all_included: list[tuple[Path, Path]] = []
    skip_counts: dict[str, int] = {}

    def bump(reason: str) -> None:
        skip_counts[reason] = skip_counts.get(reason, 0) + 1
        output.verbose(f"skip: {reason}")

    for dirpath, dirs, fnames in os.walk(root):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for f in fnames:
            fp = Path(dirpath) / f
            try:
                rel = fp.relative_to(root)
            except ValueError:
                continue
            reason = should_ignore(rel)
            if reason:
                bump(str(reason))
                continue
            try:
                size = fp.stat().st_size
            except OSError as e:
                bump(f"stat_error:{e}")
                continue
            if size > max_size:
                bump(f"too_large:{size}")
                output.verbose(f"  path: {rel}")
                continue
            all_included.append((fp, rel))

    return all_included, skip_counts


def _resolve_workspace_id(workspace_id: Optional[str]) -> tuple[str, "Config"]:
    """Load config + resolve workspace id, raising typer.Exit on error."""
    try:
        config = load_config()
    except ValueError as e:
        raise output.fail(str(e), exit_code=1)

    ws_id = workspace_id or config.workspace_id
    if not ws_id:
        raise output.fail("workspace id required (pass --workspace-id or run `starspace init`)", exit_code=1)
    return ws_id, config


@app.command()
def sync(
    workspace_id: Optional[str] = typer.Option(None, help="Override STARSPACE_WORKSPACE_ID from .env"),
    delete: bool = typer.Option(False, "--delete", help="Remove remote files not present locally (single-batch syncs only)"),
    root: Path = typer.Option(Path.cwd(), help="Root directory to scan (default: current directory)"),
    max_file_size: int = typer.Option(DEFAULT_MAX_FILE_SIZE, help=f"Max file size in bytes (default: {DEFAULT_MAX_FILE_SIZE})"),
    force: bool = typer.Option(False, "--force", "-f", help="Force pull even if local changes exist"),
):
    """Pull then push (bidirectional sync)."""
    output.info("Starting bidirectional sync...")

    try:
        pull(workspace_id=workspace_id, root=root, force=force)
    except typer.Exit as e:
        if e.exit_code != 0:
            output.info("Pull failed, aborting sync.")
            raise

    push(workspace_id=workspace_id, delete=delete, root=root, max_file_size=max_file_size)


def _push_internal(
    workspace_id: Optional[str] = None,
    delete: bool = False,
    root: Path = Path.cwd(),
    max_file_size: int = DEFAULT_MAX_FILE_SIZE,
):
    """Internal implementation shared by sync and push."""
    ws_id, config = _resolve_workspace_id(workspace_id)
    client = StarSpaceClient(api_key=config.api_key, base_url=config.base_url)
    root_path = root.resolve()

    all_files, skip_counts = collect_files(root_path, max_file_size)
    total_skips = sum(skip_counts.values())
    output.info(f"included: {len(all_files)} file(s), skipped: {total_skips}")

    if skip_counts:
        for k, v in sorted(skip_counts.items()):
            output.verbose(f"  {k}: {v}")

    if not all_files:
        output.result(
            {"pushed": 0, "skipped": total_skips, "batches": 0, "deleted_missing": False},
            human="nothing to sync",
        )
        return

    current_state = state_utils.compute_local_state(root_path, IGNORE_DIRS, IGNORE_FILES, ALLOWED_EXT, max_file_size)

    pushed = 0
    batches = 0
    for i in range(0, len(all_files), BATCH_SIZE):
        batch = all_files[i : i + BATCH_SIZE]
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for fp, rel in batch:
                zf.write(fp, rel.as_posix())
            if i + BATCH_SIZE >= len(all_files):
                metadata = {
                    "state": current_state,
                    "timestamp": os.path.getmtime(root_path),
                }
                zf.writestr("metadata.json", _json.dumps(metadata))
        buf.seek(0)

        should_delete = delete and len(all_files) <= BATCH_SIZE
        batches += 1
        response = client.sync_files(ws_id, buf, delete_missing=should_delete)
        output.info(f"Batch {batches}: {response.status_code} ({len(batch)} files)")
        try:
            output.verbose(f"  response: {response.json()}")
        except Exception:
            pass
        pushed += len(batch)

    state_utils.save_local_state(root_path, current_state)
    output.result(
        {
            "pushed": pushed,
            "skipped": total_skips,
            "batches": batches,
            "deleted_missing": delete,
        },
        human="Push successful. Local state updated.",
    )


@app.command()
def status(
    workspace_id: Optional[str] = typer.Option(None, help="Override STARSPACE_WORKSPACE_ID from .env"),
    root: Path = typer.Option(Path.cwd(), help="Root directory to scan"),
):
    """Show differences between local and remote state."""
    ws_id, config = _resolve_workspace_id(workspace_id)
    client = StarSpaceClient(api_key=config.api_key, base_url=config.base_url)
    root_path = root.resolve()

    local_state = state_utils.load_local_state(root_path)
    remote_state = client.get_remote_state(ws_id)
    diff = state_utils.compare_states(local_state, remote_state)

    in_sync = not any(diff.values())
    payload = {
        "in_sync": in_sync,
        "to_pull": diff["added"],
        "modified": diff["modified"],
        "to_push": diff["deleted"],
    }

    if output.STATE.json_output:
        output.result(payload)
        return

    if in_sync:
        typer.echo("Local and remote are in sync.")
        return

    if diff["added"]:
        typer.echo(f"\nRemote files to pull ({len(diff['added'])}):")
        for p in diff["added"]:
            typer.echo(f"  + {p}")

    if diff["modified"]:
        typer.echo(f"\nModified files ({len(diff['modified'])}):")
        for p in diff["modified"]:
            typer.echo(f"  M {p}")

    if diff["deleted"]:
        typer.echo(f"\nLocal files not on remote ({len(diff['deleted'])}):")
        for p in diff["deleted"]:
            typer.echo(f"  - {p}")


@app.command()
def pull(
    workspace_id: Optional[str] = typer.Option(None, help="Override STARSPACE_WORKSPACE_ID from .env"),
    root: Path = typer.Option(Path.cwd(), help="Root directory"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite local changes"),
):
    """Pull files from remote and apply locally."""
    ws_id, config = _resolve_workspace_id(workspace_id)
    client = StarSpaceClient(api_key=config.api_key, base_url=config.base_url)
    root_path = root.resolve()

    current_local = state_utils.compute_local_state(root_path, IGNORE_DIRS, IGNORE_FILES, ALLOWED_EXT, DEFAULT_MAX_FILE_SIZE)
    last_known_local = state_utils.load_local_state(root_path)

    local_diff = state_utils.compare_states(last_known_local, current_local)
    has_local_changes = any(local_diff.values())

    if has_local_changes and not force:
        raise output.fail(
            "You have local changes. Commit/Push or use --force to overwrite.",
            exit_code=1,
        )

    output.info(f"Pulling files from workspace {ws_id}...")
    remote_state = client.get_remote_state(ws_id)
    diff = state_utils.compare_states(last_known_local, remote_state)
    files_to_pull = diff["added"] + diff["modified"]

    if not files_to_pull:
        output.result({"pulled": 0, "files": []}, human="No remote changes to pull.")
        return

    response = client.pull_files(ws_id, files_to_pull)

    temp_dir = root_path / ".starspace" / "temp"
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
    temp_dir.mkdir(parents=True, exist_ok=True)

    try:
        with zipfile.ZipFile(io.BytesIO(response.content)) as zf:
            zf.extractall(temp_dir)

        for item in temp_dir.rglob("*"):
            if item.is_file():
                rel_path = item.relative_to(temp_dir)
                dest_path = root_path / rel_path
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(item), str(dest_path))

        new_remote_state = client.get_remote_state(ws_id)
        state_utils.save_local_state(root_path, new_remote_state)
        output.result(
            {"pulled": len(files_to_pull), "files": files_to_pull},
            human=f"Pull successful. {len(files_to_pull)} file(s) updated.",
        )
    finally:
        if temp_dir.exists():
            shutil.rmtree(temp_dir)


@app.command()
def push(
    workspace_id: Optional[str] = typer.Option(None, help="Override STARSPACE_WORKSPACE_ID from .env"),
    delete: bool = typer.Option(False, "--delete", help="Remove remote files not present locally"),
    root: Path = typer.Option(Path.cwd(), help="Root directory"),
    max_file_size: int = typer.Option(DEFAULT_MAX_FILE_SIZE, help="Max file size"),
):
    """Push local files to remote."""
    _push_internal(workspace_id=workspace_id, delete=delete, root=root, max_file_size=max_file_size)
