"""`starspace whoami` - print the identity behind the current API key."""

from __future__ import annotations

import typer

from starspace_cli import output
from starspace_cli.client import StarSpaceClient
from starspace_cli.config import load_config


def whoami():
    """Show the user, workspace, tier, and key prefix for the current credentials."""
    try:
        cfg = load_config()
    except ValueError as e:
        raise output.fail(str(e), exit_code=1)

    client = StarSpaceClient(api_key=cfg.api_key, base_url=cfg.base_url)
    info = client.whoami()  # StarSpaceError bubbles to main() on auth failure

    payload = {
        "user_id": info.get("user_id"),
        "workspace_id": info.get("workspace_id"),
        "tier": info.get("tier"),
        "key_prefix": info.get("key_prefix"),
        "config_source": cfg.source,
    }

    human = (
        f"user_id:      {payload['user_id']}\n"
        f"workspace_id: {payload['workspace_id']}\n"
        f"tier:         {payload['tier']}\n"
        f"key_prefix:   {payload['key_prefix']}\n"
        f"config:       loaded from {payload['config_source']}"
    )
    output.result(payload, human=human)
