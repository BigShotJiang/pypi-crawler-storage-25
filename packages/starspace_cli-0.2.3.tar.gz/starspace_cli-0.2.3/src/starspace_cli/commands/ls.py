"""`starspace ls [path]` - list files in the remote workspace."""

from __future__ import annotations

from typing import Optional

import typer

from starspace_cli import output
from starspace_cli.client import StarSpaceClient
from starspace_cli.config import load_config


def _fmt_bytes(n: Optional[int]) -> str:
    if n is None:
        return "-"
    n = int(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024  # type: ignore[assignment]
    return f"{n:.1f} PB"


def ls(
    path: Optional[str] = typer.Argument(None, help="Optional path prefix to filter (e.g., src/)"),
    workspace_id: Optional[str] = typer.Option(None, help="Override workspace from config"),
    limit: int = typer.Option(1000, help="Max files to list (default 1000, server cap 10000)"),
    sort: str = typer.Option("path", "--sort", "-s", help="Sort by: path | size | updated"),
):
    """List files in the remote workspace, optionally under a path prefix."""
    try:
        cfg = load_config()
    except ValueError as e:
        raise output.fail(str(e), exit_code=1)

    ws_id = workspace_id or cfg.workspace_id
    if not ws_id:
        raise output.fail("workspace id required", exit_code=1)

    client = StarSpaceClient(api_key=cfg.api_key, base_url=cfg.base_url)
    items = client.list_files(ws_id, prefix=path, limit=limit)

    if sort == "size":
        items.sort(key=lambda x: x.get("size_bytes") or 0, reverse=True)
    elif sort == "updated":
        items.sort(key=lambda x: x.get("updated_at") or "", reverse=True)
    # path sort is the server default

    if output.STATE.json_output:
        output.result({"workspace_id": ws_id, "prefix": path, "items": items, "count": len(items)})
        return

    if not items:
        typer.echo(f"no files found{' under ' + path if path else ''}")
        return

    for item in items:
        size = item.get("size_bytes")
        updated = (item.get("updated_at") or "")[:19]  # trim to seconds
        path_str = item.get("file_path", "")
        typer.echo(f"  {_fmt_bytes(size):>10}  {updated}  {path_str}")
    typer.echo(f"\n{len(items)} file(s)")
