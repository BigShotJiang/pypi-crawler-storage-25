"""`starspace convert sandbox` - demote an Indexed workspace to Sandbox.

Sandbox workspaces share the same persistent virtual filesystem as Indexed
ones, but skip the embedding pipeline: no `ask` / `search` tools, no chunk
storage, no Gemini calls on file write. Trade-off: files stay, semantic
retrieval goes away. Use this when you've hit the per-tier indexed-files
cap and don't need search on this workspace.

Promotion (Sandbox → Indexed) is not supported in v1 - it would require
re-running the chunker + embed pipeline over every existing file. Create
a new Indexed workspace if you need search again.
"""

from __future__ import annotations

from typing import Optional

import typer

from starspace_cli import output
from starspace_cli.client import StarSpaceClient
from starspace_cli.config import load_config


app = typer.Typer(
    help="Convert workspace flavor (currently: Indexed → Sandbox only).",
    no_args_is_help=True,
)


@app.command("sandbox")
def to_sandbox(
    workspace_id: Optional[str] = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace UUID to convert. Defaults to the one in your config.",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip the confirmation prompt (destructive: drops chunks).",
    ),
):
    """Demote an Indexed workspace to Sandbox. Drops chunks/embeddings, keeps files."""
    try:
        cfg = load_config()
    except ValueError as e:
        raise output.fail(str(e), exit_code=1)

    ws_id = workspace_id or cfg.workspace_id
    if not ws_id:
        raise output.fail("workspace id required", exit_code=1)

    client = StarSpaceClient(api_key=cfg.api_key, base_url=cfg.base_url)

    # Look up the workspace first so we can show context + short-circuit
    # if it's already a sandbox.
    current = client.get_workspace(ws_id)
    current_type = current.get("workspace_type") or "indexed"
    name = current.get("name") or ws_id

    if current_type == "sandbox":
        output.result(
            current,
            human=f"Workspace '{name}' is already a Sandbox - nothing to do.",
        )
        return

    if not yes:
        # AlertDialog-equivalent: explicit warning + confirm. The user
        # could have a multi-thousand-chunk workspace with real Gemini cost
        # tied up in those embeddings; one extra Enter beats an "oops".
        output.info(
            "This will:\n"
            "  • Delete every chunk + embedding for this workspace (drops `ask` and `search`).\n"
            "  • Keep every file in workspace_file_index (no data loss).\n"
            "  • Decrement your account indexed_files_used by the workspace's file count.\n"
            "\n"
            "You cannot promote back to Indexed from the CLI in v1.\n"
        )
        typer.confirm(f"Convert '{name}' ({ws_id}) to Sandbox?", abort=True)

    output.info(f"Converting workspace {ws_id} → sandbox...")
    updated = client.convert_to_sandbox(ws_id)

    output.result(
        updated,
        human=(
            f"✓ Workspace '{name}' converted to Sandbox.\n"
            f"  Files preserved, embeddings dropped.\n"
            f"  `ask` and `search` are no longer available on this workspace -\n"
            f"  use `run_readonly` with rg/grep, or create a new Indexed workspace."
        ),
    )
