"""`starspace summary` - workspace at a glance.

File count, total size, last activity, top extensions, largest files,
most-recent edits. Backed by the get_workspace_summary RPC so it's one
round-trip even on a many-thousand-file workspace.
"""

from __future__ import annotations

from typing import Optional

import typer

from starspace_cli import output
from starspace_cli.client import StarSpaceClient
from starspace_cli.config import load_config


def _fmt_bytes(n: Optional[int]) -> str:
    if n is None:
        return "-"
    val = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if val < 1024:
            return f"{val:.0f} {unit}" if unit == "B" else f"{val:.1f} {unit}"
        val /= 1024
    return f"{val:.1f} PB"


def summary(
    workspace_id: Optional[str] = typer.Option(None, help="Override workspace from config"),
):
    """Show a one-screen summary of the workspace."""
    try:
        cfg = load_config()
    except ValueError as e:
        raise output.fail(str(e), exit_code=1)

    ws_id = workspace_id or cfg.workspace_id
    if not ws_id:
        raise output.fail("workspace id required", exit_code=1)

    client = StarSpaceClient(api_key=cfg.api_key, base_url=cfg.base_url)
    data = client.get_summary(ws_id)

    # Workspace metadata for the flavor badge. Best-effort: a transient
    # error here shouldn't sink the whole summary.
    workspace_type = "indexed"
    workspace_name: Optional[str] = None
    try:
        meta = client.get_workspace(ws_id)
        workspace_type = meta.get("workspace_type") or "indexed"
        workspace_name = meta.get("name")
    except Exception:  # noqa: BLE001 - best-effort metadata fetch
        pass

    if output.STATE.json_output:
        output.result({**data, "workspace_type": workspace_type, "name": workspace_name})
        return

    file_count = data.get("file_count", 0)
    total_bytes = data.get("total_size_bytes", 0)
    dir_count = data.get("dir_count", 0)
    last = data.get("last_indexed_at") or "-"

    type_badge = "Indexed (ask/search enabled)" if workspace_type == "indexed" else "Sandbox (no embeddings)"
    if workspace_name:
        typer.echo(f"workspace:    {workspace_name} ({ws_id})")
    else:
        typer.echo(f"workspace:    {ws_id}")
    typer.echo(f"flavor:       {type_badge}")
    typer.echo(f"files:        {file_count}")
    typer.echo(f"size:         {_fmt_bytes(total_bytes)}")
    typer.echo(f"directories:  {dir_count}")
    typer.echo(f"last update:  {last}")

    root_folders = data.get("root_folders") or []
    if root_folders:
        typer.echo("\nTop-level folders:")
        for folder in root_folders[:10]:
            typer.echo(f"  {folder}")

    extensions = data.get("extensions") or {}
    if isinstance(extensions, dict) and extensions:
        sorted_exts = sorted(extensions.items(), key=lambda kv: kv[1], reverse=True)
        typer.echo("\nTop extensions:")
        for ext, count in sorted_exts[:10]:
            typer.echo(f"  {count:>5}  {ext}")

    largest = data.get("largest_files") or []
    if largest:
        typer.echo("\nLargest files:")
        for entry in largest[:10]:
            size = entry.get("size_bytes") or 0
            path = entry.get("path") or entry.get("file_path") or "-"
            typer.echo(f"  {_fmt_bytes(size):>10}  {path}")

    recent = data.get("recent_files") or []
    if recent:
        typer.echo("\nRecent edits:")
        for entry in recent[:10]:
            ts = (entry.get("updated_at") or "")[:19]
            path = entry.get("path") or entry.get("file_path") or "-"
            typer.echo(f"  {ts}  {path}")
