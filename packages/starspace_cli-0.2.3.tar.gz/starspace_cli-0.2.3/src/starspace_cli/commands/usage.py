"""`starspace usage` - credits remaining, storage, and burn-by-kind.

Backed by GET /v1/workspaces/:id/usage. Plain output is a one-screen
breakdown; --json passes the raw response through for scripts.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import typer

from starspace_cli import output
from starspace_cli.client import StarSpaceClient
from starspace_cli.config import load_config


def _fmt_bytes(n: Optional[int]) -> str:
    if n is None:
        return "-"
    val = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if val < 1024:
            return f"{val:.0f} {unit}" if unit == "B" else f"{val:.1f} {unit}"
        val /= 1024
    return f"{val:.1f} PB"


def _pct(used: int, limit: int) -> str:
    if not limit:
        return ""
    return f" ({100.0 * used / limit:.0f}%)"


def usage(
    workspace_id: Optional[str] = typer.Option(None, help="Override workspace from config"),
):
    """Show credit + storage burn for the workspace."""
    try:
        cfg = load_config()
    except ValueError as e:
        raise output.fail(str(e), exit_code=1)

    ws_id = workspace_id or cfg.workspace_id
    if not ws_id:
        raise output.fail("workspace id required", exit_code=1)

    client = StarSpaceClient(api_key=cfg.api_key, base_url=cfg.base_url)
    data: Dict[str, Any] = client.get_usage(ws_id)

    if output.STATE.json_output:
        output.result(data)
        return

    credits = data.get("credits", {}) or {}
    storage = data.get("storage", {}) or {}
    workspaces = data.get("workspaces", {}) or {}
    indexed_files = data.get("indexed_files", {}) or {}
    requests_data = data.get("requests", {}) or {}

    tier = data.get("tier") or "free"
    workspace_type = data.get("workspace_type") or "indexed"
    remaining = credits.get("remaining")
    limit = credits.get("limit")

    typer.echo(f"workspace: {ws_id}")
    typer.echo(f"flavor:    {workspace_type}")
    typer.echo(f"tier:      {tier}")
    typer.echo("")
    typer.echo("Credits")
    typer.echo(f"  remaining:    {remaining if remaining is not None else '-'}{('/' + str(limit)) if limit else ''}")
    if credits.get("recharge_interval"):
        typer.echo(f"  recharge:     {credits['recharge_interval']} (last: {credits.get('recharged_at') or '-'})")

    used_bytes = storage.get("used_bytes") or 0
    limit_bytes = storage.get("limit_bytes") or 0
    typer.echo("")
    typer.echo("Storage")
    typer.echo(f"  used:         {_fmt_bytes(used_bytes)}{_pct(used_bytes, limit_bytes)}")
    typer.echo(f"  limit:        {_fmt_bytes(limit_bytes)}")
    if storage.get("max_file_size_bytes"):
        typer.echo(f"  max file:     {_fmt_bytes(storage['max_file_size_bytes'])}")

    # Workspaces: split by flavor when present (newer API), else fall back to
    # the legacy combined `used`/`limit` shape.
    indexed_used = workspaces.get("indexed_used", workspaces.get("used", 0))
    indexed_limit = workspaces.get("indexed_limit", workspaces.get("limit", 0))
    sandbox_used = workspaces.get("sandbox_used")
    sandbox_limit = workspaces.get("sandbox_limit")
    typer.echo("")
    typer.echo("Workspaces")
    typer.echo(f"  indexed:      {indexed_used}/{indexed_limit}")
    if sandbox_used is not None and sandbox_limit is not None:
        typer.echo(f"  sandbox:      {sandbox_used}/{sandbox_limit}")

    if indexed_files:
        files_used = int(indexed_files.get("used") or 0)
        ws_cap = int(indexed_files.get("max_per_workspace") or 0)
        acc_cap = int(indexed_files.get("max_per_account") or 0)
        typer.echo("")
        typer.echo("Indexed files")
        typer.echo(f"  per workspace cap:  {ws_cap}")
        typer.echo(f"  account aggregate:  {files_used}/{acc_cap}{_pct(files_used, acc_cap)}")

    last_24h = (requests_data.get("last_24h") or {}).get("user") or {}
    last_7d = (requests_data.get("last_7d") or {}).get("user") or {}
    last_30d = (requests_data.get("last_30d") or {}).get("user") or {}

    def _row(label: str, agg: Dict[str, Any]) -> None:
        total = agg.get("total", 0)
        cred = agg.get("credits_used", 0)
        typer.echo(f"  {label:<14}{total:>6} reqs   {cred:>6} credits")

    typer.echo("")
    typer.echo("Requests")
    _row("last 24h:", last_24h)
    _row("last 7d:", last_7d)
    _row("last 30d:", last_30d)

    by_kind: Dict[str, Dict[str, int]] = (last_30d.get("by_kind") or {})
    if by_kind:
        typer.echo("")
        typer.echo("By kind (last 30d)")
        for kind, agg in sorted(by_kind.items(), key=lambda kv: -(kv[1].get("count") or 0)):
            count = agg.get("count", 0)
            cred = agg.get("credits", 0)
            typer.echo(f"  {kind:<18}{count:>6} reqs   {cred:>6} credits")
