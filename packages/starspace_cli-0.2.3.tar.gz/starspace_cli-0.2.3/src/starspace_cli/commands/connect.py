"""`starspace connect <client>` - emit MCP config snippets for chat clients.

v1 ships only `--print` (the default): we output a JSON snippet with the user's
workspace_id baked in plus a one-line instruction telling them which file to
paste it into per OS. Auto-edit is deferred to v2 - a broken auto-edit corrupts
user-critical config files and is a support nightmare.
"""

from __future__ import annotations

import json as _json
import platform

import typer

from starspace_cli import output
from starspace_cli.client import resolve_base_url
from starspace_cli.config import load_config


CHATGPT_DOCS_URL = "https://platform.openai.com/docs/mcp"
SUPPORTED_CLIENTS = ("claude", "chatgpt", "cursor")


def _claude_desktop_path() -> str:
    system = platform.system()
    if system == "Darwin":
        return "~/Library/Application Support/Claude/claude_desktop_config.json"
    if system == "Windows":
        return "%APPDATA%\\Claude\\claude_desktop_config.json"
    return "~/.config/Claude/claude_desktop_config.json"


def _mcp_server_url(base: str) -> str:
    return f"{base}/functions/v1/mcp-run-v1"


def _build_mcp_snippet(server_url: str, api_key: str) -> dict:
    return {
        "mcpServers": {
            "starspace": {
                "url": server_url,
                "headers": {
                    "Authorization": f"Bearer {api_key}",
                },
            }
        }
    }


def connect(
    client_name: str = typer.Argument(
        ...,
        help=f"Target MCP client. One of: {', '.join(SUPPORTED_CLIENTS)}.",
        metavar="CLIENT",
    ),
    print_only: bool = typer.Option(
        True,
        "--print/--no-print",
        help="Print the config snippet instead of editing the client's config file. "
        "v1 only supports --print; --no-print is reserved for v2.",
    ),
):
    """Generate an MCP config snippet for Claude Desktop, Cursor, or ChatGPT."""

    target = client_name.lower()
    if target not in SUPPORTED_CLIENTS:
        raise output.fail(
            f"unknown client '{client_name}'. Supported: {', '.join(SUPPORTED_CLIENTS)}.",
            exit_code=1,
        )

    if not print_only:
        raise output.fail(
            "--no-print (auto-edit) is not supported in v1. "
            "Use the printed snippet to edit your client config manually.",
            exit_code=2,
        )

    try:
        cfg = load_config()
    except ValueError as e:
        raise output.fail(f"{e}\nRun `starspace init` first.", exit_code=1)

    base = resolve_base_url(cfg.base_url)
    server_url = _mcp_server_url(base)

    if target == "chatgpt":
        payload = {
            "client": "chatgpt",
            "server_url": server_url,
            "workspace_id": cfg.workspace_id,
            "auth_header": f"Bearer {cfg.api_key}",
            "docs_url": CHATGPT_DOCS_URL,
        }
        human = (
            "ChatGPT connects via the Connectors UI (no local config file to edit).\n\n"
            "Connector URL:\n"
            f"  {server_url}\n\n"
            "Workspace ID:\n"
            f"  {cfg.workspace_id}\n\n"
            "API key (Authorization header):\n"
            f"  Bearer {cfg.api_key}\n\n"
            + f"Setup docs: {CHATGPT_DOCS_URL}"
        )
        output.result(payload, human=human)
        return

    snippet = _build_mcp_snippet(server_url, cfg.api_key)

    if target == "claude":
        target_path = _claude_desktop_path()
        client_label = "Claude Desktop"
    else:  # cursor
        target_path = "~/.cursor/mcp.json"
        client_label = "Cursor"

    payload = {
        "client": target,
        "config_file": target_path,
        "server_url": server_url,
        "snippet": snippet,
    }
    human = (
        f"# {client_label} MCP config snippet\n\n"
        f"{_json.dumps(snippet, indent=2)}\n\n"
        + f"Paste the block above into the `mcpServers` object of:\n"
        f"  {target_path}\n\n"
        "If the file already has other entries under `mcpServers`, merge the\n"
        "`starspace` key in alongside them - don't replace the whole object.\n"
        f"Restart {client_label} for the change to take effect."
    )
    output.result(payload, human=human)
