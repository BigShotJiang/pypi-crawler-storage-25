"""`starspace mcp ...` - invoke the workspace MCP server (mcp-run-v1).

The same tools that ChatGPT, Claude Desktop, and other MCP clients see when
they connect via OAuth are exposed here over the workspace API key. This is
useful for:
    - quick scripted sanity checks ("does my API key see the right tools?")
    - shell pipelines that want to drop into MCP without writing a connector
    - debugging tools/list output and tool argument schemas

All subcommands share the same auth surface as the rest of the CLI - they
pull the workspace API key + base URL from env / project / global config.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

import typer

from starspace_cli import output
from starspace_cli.client import StarSpaceClient
from starspace_cli.config import load_config
from starspace_cli.errors import StarSpaceError


app = typer.Typer(
    name="mcp",
    help="Invoke the workspace MCP server (the same surface ChatGPT-style connectors see).",
    no_args_is_help=True,
)


def _client() -> StarSpaceClient:
    try:
        cfg = load_config()
    except ValueError as exc:
        raise output.fail(str(exc), exit_code=1)
    return StarSpaceClient(api_key=cfg.api_key, base_url=cfg.base_url)


def _parse_arg_kv(items: List[str]) -> Dict[str, Any]:
    """Parse `--arg key=value` pairs. Values are JSON-decoded if possible.

    Examples:
        --arg query=hello                → {"query": "hello"}
        --arg start_line=1 --arg end_line=200
                                         → {"start_line": 1, "end_line": 200}
        --arg files='["a.txt","b.txt"]'  → {"files": ["a.txt","b.txt"]}
    """
    parsed: Dict[str, Any] = {}
    for item in items:
        if "=" not in item:
            raise output.fail(
                f"--arg requires key=value form, got: {item!r}",
                exit_code=2,
            )
        key, _, raw = item.partition("=")
        key = key.strip()
        if not key:
            raise output.fail(f"--arg has empty key: {item!r}", exit_code=2)
        try:
            parsed[key] = json.loads(raw)
        except json.JSONDecodeError:
            # Not valid JSON → treat as a plain string. This is the common case
            # for query strings, file paths, etc.
            parsed[key] = raw
    return parsed


def _render_tool_result(result: Dict[str, Any]) -> None:
    """Pretty-print an MCP tool result. Honors --json globally."""
    if output.STATE.json_output:
        output.result(result)
        return

    content = result.get("content") or []
    rendered_any = False
    for chunk in content:
        if not isinstance(chunk, dict):
            continue
        if chunk.get("type") == "text":
            text = chunk.get("text") or ""
            # Some tools return JSON strings inside text/plain - pretty-print
            # those so users don't see a wall of escape characters.
            try:
                parsed = json.loads(text)
                typer.echo(json.dumps(parsed, indent=2))
            except (ValueError, TypeError):
                typer.echo(text)
            rendered_any = True
        elif chunk.get("type") == "image":
            typer.echo(f"[image: {chunk.get('mimeType', 'unknown')}]")
            rendered_any = True
        else:
            typer.echo(json.dumps(chunk, indent=2))
            rendered_any = True

    if not rendered_any:
        # Tool returned no displayable content - fall back to dumping the full
        # result so callers can still see structuredContent / metadata.
        typer.echo(json.dumps(result, indent=2))


@app.command("tools")
def tools(
    readonly: bool = typer.Option(
        False,
        "--readonly",
        help="Use the read-only route (the same surface a workspace:read OAuth token sees).",
    ),
) -> None:
    """List the MCP tools available to your API key."""
    client = _client()
    tool_list = client.mcp_tools_list(readonly=readonly)

    if output.STATE.json_output:
        output.result({"tools": tool_list})
        return

    if not tool_list:
        typer.echo("No MCP tools available for this principal.")
        return

    for tool in tool_list:
        name = tool.get("name") or "?"
        title = tool.get("title") or ""
        desc = (tool.get("description") or "").strip().splitlines()
        scopes: List[str] = []
        for scheme in tool.get("securitySchemes") or []:
            if isinstance(scheme, dict):
                scopes.extend(s for s in (scheme.get("scopes") or []) if isinstance(s, str))

        line = f"{name:<22}"
        if title:
            line += f" {title}"
        if scopes:
            line += f"  [{' '.join(scopes)}]"
        typer.echo(line)
        if desc:
            typer.echo(f"    {desc[0]}")


@app.command("call")
def call(
    tool_name: str = typer.Argument(..., help="Name of the MCP tool (e.g. search, fetch, run)"),
    arg: List[str] = typer.Option(
        [],
        "--arg",
        "-a",
        help="Tool argument as key=value (repeatable). Values are JSON-decoded when possible.",
    ),
    arg_json: Optional[str] = typer.Option(
        None,
        "--arg-json",
        help="Pass the entire arguments object as a single JSON blob (overrides --arg).",
    ),
    readonly: bool = typer.Option(
        False,
        "--readonly",
        help="Hit the read-only route (forbids write tools - useful for safety).",
    ),
) -> None:
    """Invoke an MCP tool by name."""
    if arg_json is not None:
        try:
            arguments = json.loads(arg_json)
        except json.JSONDecodeError as exc:
            raise output.fail(f"--arg-json is not valid JSON: {exc}", exit_code=2)
        if not isinstance(arguments, dict):
            raise output.fail("--arg-json must decode to an object", exit_code=2)
    else:
        arguments = _parse_arg_kv(arg)

    client = _client()
    try:
        result = client.mcp_call(tool_name, arguments, readonly=readonly)
    except StarSpaceError as exc:
        raise output.fail(exc)
    _render_tool_result(result)


@app.command("search")
def search(
    query: str = typer.Argument(..., help="Search query"),
    limit: Optional[int] = typer.Option(
        None, "--limit", "-n", help="Max results, 1–50 (default 10)"
    ),
    path_prefix: Optional[str] = typer.Option(
        None, "--path-prefix", help="Restrict to files under this directory"
    ),
    file_glob: Optional[str] = typer.Option(
        None, "--file-glob", help="Restrict to files matching this glob (e.g. '*.ts', '**/auth/*.py')"
    ),
    mode: Optional[str] = typer.Option(
        None, "--mode", help="exact | semantic | debug | auto (default auto)"
    ),
) -> None:
    """Hybrid + LLM-reranked workspace search. See `mcp call search` for the raw shape."""
    args: Dict[str, Any] = {"query": query}
    if limit is not None:
        args["limit"] = limit
    if path_prefix is not None:
        args["path_prefix"] = path_prefix
    if file_glob is not None:
        args["file_glob"] = file_glob
    if mode is not None:
        args["mode"] = mode
    client = _client()
    try:
        result = client.mcp_call("search", args, readonly=True)
    except StarSpaceError as exc:
        raise output.fail(exc)
    _render_tool_result(result)


@app.command("fetch")
def fetch(
    document_id: str = typer.Argument(..., help="Document id from search results (e.g. file:src/app.ts)"),
    start_line: Optional[int] = typer.Option(None, "--start-line", help="1-indexed first line"),
    end_line: Optional[int] = typer.Option(None, "--end-line", help="1-indexed last line"),
) -> None:
    """Shortcut for `mcp call fetch --arg id=<id>` - fetch a single document."""
    args: Dict[str, Any] = {"id": document_id}
    if start_line is not None:
        args["start_line"] = start_line
    if end_line is not None:
        args["end_line"] = end_line
    client = _client()
    try:
        result = client.mcp_call("fetch", args, readonly=True)
    except StarSpaceError as exc:
        raise output.fail(exc)
    _render_tool_result(result)


@app.command("ask")
def ask(
    question: str = typer.Argument(..., help="Natural-language question about the workspace"),
    limit: Optional[int] = typer.Option(
        None,
        "--limit",
        "-n",
        help="How many search excerpts to feed the synthesizer, 1–12 (default 6)",
    ),
    path_prefix: Optional[str] = typer.Option(
        None,
        "--path-prefix",
        help="Restrict the underlying search to this directory prefix",
    ),
) -> None:
    """Ask a natural-language question; returns a synthesized answer with citations.

    Server-side pipeline: semantic search → top excerpts → Gemini Flash
    synthesis → structured response. Use this when you have a *question*
    about the codebase; use `mcp search` when you want the candidate
    file list.
    """
    args: Dict[str, Any] = {"question": question}
    if limit is not None:
        args["limit"] = limit
    if path_prefix is not None:
        args["path_prefix"] = path_prefix
    client = _client()
    try:
        result = client.mcp_call("ask", args, readonly=True)
    except StarSpaceError as exc:
        raise output.fail(exc)
    _render_tool_result(result)


@app.command("run")
def run(
    command: str = typer.Argument(..., help="Shell command to run inside the workspace sandbox"),
    readonly: bool = typer.Option(
        False,
        "--readonly",
        help="Route via the /readonly endpoint, which forbids workspace mutations.",
    ),
) -> None:
    """Run a shell command via the MCP `run` tool.

    With `--readonly`, the call is routed through `/mcp-run-v1/readonly` -
    the route itself enforces read-only capabilities, so the same `run` tool
    becomes mutation-free. (`run_readonly` is only registered on the writable
    route, where it provides the same hardcoded readonly behavior.)
    """
    client = _client()
    try:
        result = client.mcp_call("run", {"command": command}, readonly=readonly)
    except StarSpaceError as exc:
        raise output.fail(exc)
    _render_tool_result(result)


@app.command("summary")
def summary() -> None:
    """Shortcut for `mcp call workspace_summary` - the structured JSON the
    indexer maintains.

    Distinct from the top-level `starspace summary` which uses the workspace-
    management endpoint. Both work; this one goes through MCP for parity with
    what an LLM would see.
    """
    client = _client()
    try:
        result = client.mcp_call("workspace_summary", {}, readonly=True)
    except StarSpaceError as exc:
        raise output.fail(exc)
    _render_tool_result(result)


@app.command("health")
def health() -> None:
    """Shortcut for `mcp call server_health`."""
    client = _client()
    try:
        result = client.mcp_call("server_health", {}, readonly=True)
    except StarSpaceError as exc:
        raise output.fail(exc)
    _render_tool_result(result)
