"""`starspace cat <path>` - print a remote file to stdout."""

from __future__ import annotations

from typing import Optional

import typer

from starspace_cli import output
from starspace_cli.client import StarSpaceClient
from starspace_cli.config import load_config


def cat(
    path: str = typer.Argument(..., help="File path within the workspace (e.g., src/main.ts)"),
    workspace_id: Optional[str] = typer.Option(None, help="Override workspace from config"),
):
    """Stream a remote file's content to stdout.

    Honors --json: emits the full file record (path, content, hash, etc.) as JSON.
    Without --json, prints just the content so it pipes cleanly into less/grep.
    """
    try:
        cfg = load_config()
    except ValueError as e:
        raise output.fail(str(e), exit_code=1)

    ws_id = workspace_id or cfg.workspace_id
    if not ws_id:
        raise output.fail("workspace id required", exit_code=1)

    client = StarSpaceClient(api_key=cfg.api_key, base_url=cfg.base_url)
    data = client.get_file(ws_id, path)

    if output.STATE.json_output:
        output.result(data)
        return

    # Print content directly so the command is pipe-friendly. Trailing newline
    # only if the content didn't already end with one.
    content = data.get("content", "")
    if content and not content.endswith("\n"):
        content += "\n"
    typer.echo(content, nl=False)
