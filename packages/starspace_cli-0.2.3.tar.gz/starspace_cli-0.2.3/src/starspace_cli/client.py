import json
import os
from io import BytesIO
from typing import Any, Dict, Optional

import requests

from starspace_cli.errors import StarSpaceError

DEFAULT_BASE_URL = "https://api.starspace.run"


def resolve_base_url(override: Optional[str] = None) -> str:
    """Resolve the StarSpace API base URL.

    Precedence: explicit override → STARSPACE_BASE_URL env → default.
    Trailing slashes are stripped so callers can append paths cleanly.
    """
    base = (override or os.getenv("STARSPACE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
    return base


def _check(response: requests.Response) -> None:
    """Raise StarSpaceError with parsed body if the response is not 2xx.

    Handles both the new structured shape ({"error": {"code", "message",
    "hint", "details"}}) and the legacy shape ({"error": "..."}).
    """
    if response.ok:
        return

    code = "http_error"
    message = f"HTTP {response.status_code}"
    hint: Optional[str] = None
    details: Optional[dict] = None

    try:
        body = response.json()
    except ValueError:
        body = None

    if isinstance(body, dict):
        err = body.get("error")
        if isinstance(err, dict):
            code = err.get("code") or code
            message = err.get("message") or message
            hint = err.get("hint")
            details = err.get("details") if isinstance(err.get("details"), dict) else None
        elif isinstance(err, str):
            message = err
        # Pull through `reason` / extra keys for diagnostic value
        if not details and isinstance(body, dict):
            extras = {k: v for k, v in body.items() if k != "error"}
            details = extras or None

    raise StarSpaceError(
        message,
        code=code,
        hint=hint,
        details=details,
        status_code=response.status_code,
    )


class StarSpaceClient:
    def __init__(self, api_key: str, base_url: Optional[str] = None):
        self.api_key = api_key
        self.host = resolve_base_url(base_url)
        self.workspaces_url = f"{self.host}/functions/v1/workspace-management/v1/workspaces"

    # Backwards compat: existing callers reference `self.base_url`.
    @property
    def base_url(self) -> str:
        return self.workspaces_url

    def whoami(self) -> Dict[str, Any]:
        """Validate the API key against /whoami; returns {user_id, workspace_id, tier, key_prefix}."""
        url = f"{self.host}/functions/v1/whoami"
        response = requests.get(
            url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=15,
        )
        _check(response)
        return response.json()

    def sync_files(
        self,
        workspace_id: str,
        zip_buffer: BytesIO,
        delete_missing: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> requests.Response:
        """Sync files to the StarSpace workspace by uploading a zip buffer."""
        url = f"{self.workspaces_url}/{workspace_id}/files/sync"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/zip",
            "x-delete-missing": str(delete_missing).lower(),
        }
        params = {"delete_missing": str(delete_missing).lower()}
        zip_buffer.seek(0)
        response = requests.post(url, headers=headers, params=params, data=zip_buffer)
        _check(response)
        return response

    def get_remote_state(self, workspace_id: str) -> Dict[str, str]:
        """Get the current state (hashes) of files in the remote workspace."""
        url = f"{self.workspaces_url}/{workspace_id}/files/state"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = requests.get(url, headers=headers)
        _check(response)
        data = response.json()
        return {k: v["hash"] for k, v in data.get("files", {}).items()}

    def pull_files(self, workspace_id: str, requested_files: list[str]) -> requests.Response:
        """Pull files from the StarSpace workspace as a zip."""
        url = f"{self.workspaces_url}/{workspace_id}/files/pull"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {"requested_files": requested_files}
        response = requests.post(url, headers=headers, json=payload, stream=True)
        _check(response)
        return response

    def get_summary(self, workspace_id: str) -> Dict[str, Any]:
        """Workspace summary - file count, total size, top dirs/exts, last activity."""
        url = f"{self.workspaces_url}/{workspace_id}/summary"
        response = requests.get(url, headers={"Authorization": f"Bearer {self.api_key}"})
        _check(response)
        return response.json()

    def get_workspace(self, workspace_id: str) -> Dict[str, Any]:
        """Return the workspace row - id, name, workspace_type, owner_id, settings, …"""
        url = f"{self.workspaces_url}/{workspace_id}"
        response = requests.get(url, headers={"Authorization": f"Bearer {self.api_key}"})
        _check(response)
        return response.json()

    def convert_to_sandbox(self, workspace_id: str) -> Dict[str, Any]:
        """Demote an Indexed workspace to Sandbox.

        Drops every chunk + symbol row for the workspace, flips workspace_type
        to 'sandbox', decrements the per-account indexed_files_used counter.
        Files in workspace_file_index are preserved - only the embedding/search
        layer goes away. Returns the updated workspace row.
        """
        url = f"{self.workspaces_url}/{workspace_id}/convert-to-sandbox"
        response = requests.post(
            url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=60,
        )
        _check(response)
        return response.json()

    def get_usage(self, workspace_id: str) -> Dict[str, Any]:
        """Credit + storage burn for the principal. Last 24h/7d/30d aggregated by api_kind."""
        url = f"{self.workspaces_url}/{workspace_id}/usage"
        response = requests.get(url, headers={"Authorization": f"Bearer {self.api_key}"})
        _check(response)
        return response.json()

    def list_files(
        self,
        workspace_id: str,
        prefix: Optional[str] = None,
        limit: int = 1000,
    ) -> list[Dict[str, Any]]:
        """List files in the workspace; returns [{file_path, size_bytes, content_hash, updated_at}]."""
        url = f"{self.workspaces_url}/{workspace_id}/files"
        params: Dict[str, Any] = {"limit": str(limit)}
        if prefix:
            params["prefix"] = prefix
        response = requests.get(
            url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            params=params,
        )
        _check(response)
        return response.json().get("items", [])

    def get_file(self, workspace_id: str, file_path: str) -> Dict[str, Any]:
        """Read a single file; returns {file_path, content, size_bytes, content_hash, updated_at}."""
        # The path may contain slashes - pass through as-is. requests handles encoding.
        url = f"{self.workspaces_url}/{workspace_id}/files/{file_path}"
        response = requests.get(url, headers={"Authorization": f"Bearer {self.api_key}"})
        _check(response)
        return response.json()

    # ----- MCP (mcp-run-v1) -----
    #
    # The MCP endpoint speaks JSON-RPC 2.0 over a single POST. Authentication is
    # the same workspace API key as the rest of the CLI uses - mcp-run-v1 accepts
    # it as a Bearer token. See supabase/functions/mcp-run-v1/lib/auth.ts:
    # `authenticateRequest` validates the token via the
    # `validate_workspace_api_key` RPC.
    #
    # The transport layer requires a specific MCP-Protocol-Version header and
    # expects the client to advertise both `application/json` and
    # `text/event-stream` in Accept. The server may stream the response as SSE
    # (`data: {…json…}` lines) when the underlying tool emits chunked content;
    # we re-assemble whichever form comes back into a single Python dict.

    # We send the OLDEST protocol version the server's SUPPORTED set contains,
    # not the newest. The deployed mcp-run-v1 may lag the local source by a
    # release or two; "2025-03-26" is in every SUPPORTED_PROTOCOL_VERSIONS set
    # we've ever shipped, so the CLI keeps working across server versions. The
    # CLI doesn't depend on any newer-protocol features today; if it ever does,
    # bump this in lockstep with a confirmed mcp-run-v1 deploy.
    MCP_PROTOCOL_VERSION = "2025-03-26"
    MCP_DEFAULT_PATH = "/functions/v1/mcp-run-v1"
    MCP_READONLY_PATH = "/functions/v1/mcp-run-v1/readonly"

    def _mcp_url(self, readonly: bool = False) -> str:
        path = self.MCP_READONLY_PATH if readonly else self.MCP_DEFAULT_PATH
        return f"{self.host}{path}"

    def _mcp_headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "MCP-Protocol-Version": self.MCP_PROTOCOL_VERSION,
        }

    @staticmethod
    def _parse_mcp_response(response: requests.Response) -> Dict[str, Any]:
        """Decode either a plain JSON-RPC body or an SSE stream into a single envelope.

        mcp-run-v1 returns text/event-stream for tool calls; non-streamed methods
        come back as application/json. Both share the JSON-RPC 2.0 envelope shape.
        """
        ctype = (response.headers.get("Content-Type") or "").lower()
        text = response.text
        if "application/json" in ctype:
            return response.json()

        # SSE: collect the LAST `data:` line that contains a JSON-RPC envelope
        # with our id (tool calls only emit one). Earlier lines may be progress
        # notifications which don't carry result/error.
        last_payload: Optional[Dict[str, Any]] = None
        for raw in text.splitlines():
            if not raw.startswith("data:"):
                continue
            payload_str = raw[len("data:"):].strip()
            if not payload_str or payload_str == "[DONE]":
                continue
            try:
                payload = json.loads(payload_str)
            except ValueError:
                continue
            if isinstance(payload, dict) and ("result" in payload or "error" in payload):
                last_payload = payload
        if last_payload is not None:
            return last_payload

        # Fall back to attempting JSON parse - some intermediaries strip the
        # event-stream framing.
        try:
            return response.json()
        except ValueError as exc:
            raise StarSpaceError(
                "MCP server returned an unparseable response",
                code="mcp_decode_error",
                details={"content_type": ctype, "body_head": text[:500]},
                status_code=response.status_code,
            ) from exc

    def mcp_rpc(
        self,
        method: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        request_id: Any = 1,
        readonly: bool = False,
    ) -> Dict[str, Any]:
        """Send a single JSON-RPC 2.0 method call to mcp-run-v1.

        Returns the parsed envelope ({"jsonrpc","id","result"} or {"...","error"}).
        Raises StarSpaceError if the HTTP call itself fails or the JSON-RPC
        envelope reports an error.
        """
        body = {"jsonrpc": "2.0", "id": request_id, "method": method, "params": params or {}}
        response = requests.post(
            self._mcp_url(readonly=readonly),
            headers=self._mcp_headers(),
            json=body,
            timeout=120,
        )
        _check(response)
        envelope = self._parse_mcp_response(response)

        if isinstance(envelope, dict) and isinstance(envelope.get("error"), dict):
            err = envelope["error"]
            raise StarSpaceError(
                err.get("message") or "MCP error",
                code=str(err.get("code") or "mcp_error"),
                details=err.get("data") if isinstance(err.get("data"), dict) else None,
                status_code=response.status_code,
            )
        return envelope

    def mcp_tools_list(self, *, readonly: bool = False) -> list[Dict[str, Any]]:
        """Return the list of MCP tools the principal can see."""
        envelope = self.mcp_rpc("tools/list", request_id=1, readonly=readonly)
        result = envelope.get("result") or {}
        tools = result.get("tools")
        return tools if isinstance(tools, list) else []

    def mcp_call(
        self,
        tool_name: str,
        arguments: Optional[Dict[str, Any]] = None,
        *,
        readonly: bool = False,
        request_id: Any = 2,
    ) -> Dict[str, Any]:
        """Invoke an MCP tool. Returns the inner `result` dict (with `content`)."""
        envelope = self.mcp_rpc(
            "tools/call",
            {"name": tool_name, "arguments": arguments or {}},
            request_id=request_id,
            readonly=readonly,
        )
        result = envelope.get("result") or {}
        if not isinstance(result, dict):
            raise StarSpaceError(
                "MCP tool returned an unexpected result shape",
                code="mcp_bad_result",
                details={"result": result},
            )
        if result.get("isError"):
            text = ""
            for chunk in result.get("content") or []:
                if isinstance(chunk, dict) and chunk.get("type") == "text":
                    text = str(chunk.get("text") or "")
                    break
            raise StarSpaceError(
                text or "MCP tool reported an error",
                code="mcp_tool_error",
                details={"result": result},
            )
        return result
