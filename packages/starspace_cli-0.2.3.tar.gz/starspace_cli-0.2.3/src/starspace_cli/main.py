import sys
from importlib import metadata as _metadata

import typer

from starspace_cli import output
from starspace_cli.commands import cat as cat_cmd
from starspace_cli.commands import connect as connect_cmd
from starspace_cli.commands import convert as convert_cmd
from starspace_cli.commands import doctor as doctor_cmd
from starspace_cli.commands import init as init_cmd
from starspace_cli.commands import ls as ls_cmd
from starspace_cli.commands import mcp as mcp_cmd
from starspace_cli.commands import summary as summary_cmd
from starspace_cli.commands import sync
from starspace_cli.commands import usage as usage_cmd
from starspace_cli.commands import whoami as whoami_cmd
from starspace_cli.errors import StarSpaceError


def _resolve_version() -> str:
    try:
        return _metadata.version("starspace-cli")
    except _metadata.PackageNotFoundError:
        return "unknown"


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"starspace-cli {_resolve_version()}")
        raise typer.Exit()

app = typer.Typer(
    help="StarSpace CLI - manage your StarSpace workspaces.",
    no_args_is_help=True,
    # Disable rich traceback formatting so unhandled exceptions hit our
    # main() wrapper instead of being pretty-printed by typer.
    pretty_exceptions_enable=False,
)


@app.callback()
def root(
    version: bool = typer.Option(
        False,
        "--version",
        help="Print the CLI version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit machine-readable JSON output. Errors go to stderr as JSON.",
    ),
    verbose: bool = typer.Option(
        False,
        "-v",
        "--verbose",
        help="Verbose diagnostic logging to stderr.",
    ),
) -> None:
    """Top-level callback - wires global flags into the output module."""
    output.configure(json_output=json_output, verbose=verbose)


# Onboarding
app.command()(init_cmd.init)
app.command()(doctor_cmd.doctor)
app.command()(connect_cmd.connect)

# Read commands
app.command()(whoami_cmd.whoami)
app.command()(summary_cmd.summary)
app.command()(usage_cmd.usage)
app.command()(ls_cmd.ls)
app.command()(cat_cmd.cat)

# Sync
app.command()(sync.sync)
app.command()(sync.status)
app.command()(sync.pull)
app.command()(sync.push)

# MCP
app.add_typer(mcp_cmd.app, name="mcp")

# Workspace flavor conversion (Indexed → Sandbox)
app.add_typer(convert_cmd.app, name="convert")


def main() -> None:
    """Process entrypoint. Catches StarSpaceError so unhandled API errors
    map to documented exit codes instead of leaking a Python traceback.

    Typer (0.9+) re-raises typer.Exit from its __call__, so we have to
    convert it into sys.exit ourselves rather than letting it propagate.
    """
    try:
        app()
    except StarSpaceError as e:
        exit_code = output.fail(e).exit_code
        sys.exit(exit_code)
    except typer.Exit as e:
        sys.exit(e.exit_code)
    except KeyboardInterrupt:
        sys.stderr.write("\nInterrupted.\n")
        sys.exit(130)


if __name__ == "__main__":
    main()
