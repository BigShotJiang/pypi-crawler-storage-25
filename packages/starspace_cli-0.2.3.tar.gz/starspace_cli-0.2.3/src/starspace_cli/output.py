"""Output helpers - every command prints through these so the global
`--json` flag toggles between human-readable and JSON output.
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from typing import Any, Optional

import typer

from starspace_cli.errors import StarSpaceError


@dataclass
class OutputState:
    """Process-global flags set by the top-level Typer callback."""

    json_output: bool = False
    verbose: bool = False


STATE = OutputState()


def configure(json_output: bool = False, verbose: bool = False) -> None:
    STATE.json_output = json_output
    STATE.verbose = verbose


def say(text: str, *, err: bool = False) -> None:
    """Print human-readable text. Suppressed in --json mode (errors still go to stderr)."""
    if STATE.json_output and not err:
        return
    typer.echo(text, err=err)


def info(text: str) -> None:
    """Diagnostic / progress lines. Always to stderr; suppressed in --json mode."""
    if STATE.json_output:
        return
    typer.echo(text, err=True)


def verbose(text: str) -> None:
    """Only printed when --verbose is set. Always to stderr."""
    if not STATE.verbose:
        return
    typer.echo(text, err=True)


def result(data: Any, *, human: Optional[str] = None) -> None:
    """Final command output. JSON in --json mode; `human` text otherwise (or pretty-print of data if no human supplied)."""
    if STATE.json_output:
        typer.echo(json.dumps(data, default=str))
        return
    if human is not None:
        typer.echo(human)
    else:
        typer.echo(json.dumps(data, indent=2, default=str))


def fail(error: StarSpaceError | str, *, exit_code: int = 1) -> "typer.Exit":
    """Print a CLI error and return a typer.Exit (caller raises it).

    Accepts a StarSpaceError (preserving code/hint/exit_code) or a plain string.
    Recognized error codes get richer rendering:

      - `indexed_file_limit`: show the workspace/account scope, current/limit
        counts, and a copy-pastable `starspace convert sandbox` command when
        the API returned a workspace_id in details.
    """
    if isinstance(error, str):
        err = StarSpaceError(error, code="cli_error")
        err.status_code = None
        code = exit_code
    else:
        err = error
        code = error.exit_code

    if STATE.json_output:
        typer.echo(json.dumps({"error": err.to_dict()}), err=True)
    else:
        typer.echo(f"error [{err.code}]: {err.message}", err=True)
        if err.hint:
            typer.echo(f"  hint: {err.hint}", err=True)

        # Surface the indexed-files cap context inline (not just under
        # --verbose) - it's the actionable bit.
        if err.code == "indexed_file_limit" and isinstance(err.details, dict):
            d = err.details
            scope = d.get("scope") or "workspace"
            current = d.get("current")
            limit = d.get("limit")
            tier = d.get("tier")
            ws_id = d.get("workspaceId") or d.get("workspace_id")
            line = f"  cap:  {scope}"
            if current is not None and limit is not None:
                line += f" {current}/{limit}"
            if tier:
                line += f" (tier: {tier})"
            typer.echo(line, err=True)
            typer.echo("  next steps:", err=True)
            typer.echo("    Upgrade:             https://starspace.run/pricing", err=True)
            if ws_id:
                typer.echo(f"    Convert to Sandbox:  starspace convert sandbox -w {ws_id}", err=True)
            else:
                typer.echo("    Convert to Sandbox:  starspace convert sandbox", err=True)

        if err.details and STATE.verbose:
            typer.echo(f"  details: {json.dumps(err.details, default=str)}", err=True)

    return typer.Exit(code=code)
