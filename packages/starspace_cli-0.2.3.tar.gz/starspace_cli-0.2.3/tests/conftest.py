"""Pytest fixtures for starspace-cli tests.

Live tests need a real workspace API key to talk to api.starspace.run. To
keep secrets out of the repo, the key MUST come from one of:

    - the env var STARSPACE_TEST_API_KEY
    - the env var STARSPACE_WORKSPACE_API_KEY (the same one the CLI itself uses)
    - a gitignored .env.test in starspace-cli/ (loaded by python-dotenv)

Tests that need the live key are decorated with `@pytest.mark.live` and skip
automatically when no key is found, so unit-only test runs (e.g. CI without
secrets) still pass.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import pytest
from dotenv import load_dotenv


def _load_env_test() -> None:
    """Load starspace-cli/.env.test if present. Gitignored - never commit it."""
    here = Path(__file__).resolve().parent.parent
    candidate = here / ".env.test"
    if candidate.exists():
        load_dotenv(candidate)


_load_env_test()


def _resolve_api_key() -> Optional[str]:
    return (
        os.getenv("STARSPACE_TEST_API_KEY")
        or os.getenv("STARSPACE_WORKSPACE_API_KEY")
    )


def _resolve_workspace_id() -> Optional[str]:
    return (
        os.getenv("STARSPACE_TEST_WORKSPACE_ID")
        or os.getenv("STARSPACE_WORKSPACE_ID")
    )


def _resolve_base_url() -> str:
    return os.getenv("STARSPACE_BASE_URL") or "https://api.starspace.run"


@pytest.fixture(scope="session")
def live_api_key() -> str:
    key = _resolve_api_key()
    if not key:
        pytest.skip(
            "live MCP tests require STARSPACE_TEST_API_KEY (or STARSPACE_WORKSPACE_API_KEY) to be set"
        )
    return key


@pytest.fixture(scope="session")
def live_workspace_id() -> str:
    ws = _resolve_workspace_id()
    if not ws:
        pytest.skip(
            "live MCP tests require STARSPACE_TEST_WORKSPACE_ID (or STARSPACE_WORKSPACE_ID) to be set"
        )
    return ws


@pytest.fixture(scope="session")
def live_base_url() -> str:
    return _resolve_base_url()


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers",
        "live: hits the deployed StarSpace API; requires STARSPACE_TEST_API_KEY",
    )
