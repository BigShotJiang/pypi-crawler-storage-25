"""Live integration tests against the deployed mcp-run-v1 endpoint.

These tests require a real workspace API key in the environment (see conftest).
They prove the CLI's MCP wiring works end-to-end against api.starspace.run:
    - tools/list returns the expected tool surface
    - workspace_summary returns structured JSON
    - run_readonly executes shell commands inside the sandbox
    - search responds without erroring (results may be empty for a fresh ws)

They are intentionally low-credit (only read-ish tools) so test runs stay
cheap. None of them mutate the workspace.
"""
from __future__ import annotations

import os

import pytest

from starspace_cli.client import StarSpaceClient


pytestmark = pytest.mark.live


@pytest.fixture(scope="module")
def client(live_api_key: str, live_base_url: str) -> StarSpaceClient:
    return StarSpaceClient(api_key=live_api_key, base_url=live_base_url)


def test_tools_list_includes_core_tools(client: StarSpaceClient) -> None:
    tools = client.mcp_tools_list()
    names = {t.get("name") for t in tools if isinstance(t, dict)}
    # These four are the public "always present for any workspace" tools.
    # If any of them disappear, mcp-run-v1's surface has regressed.
    for required in ("search", "fetch", "workspace_summary", "run_readonly"):
        assert required in names, f"missing required MCP tool: {required} (got {sorted(names)})"


def test_readonly_route_blocks_write_tool_execution(client: StarSpaceClient) -> None:
    """The /readonly route must not expose write tools at all.

    The bug being guarded against: previously Hono saw the request path with
    the function-name prefix, so `app.all("/readonly/*")` never matched and the
    catch-all applied write capabilities. tools/list advertised write_file /
    apply_patch / edit_file and tools/call ran them. Fixed by detecting
    /readonly inside the catch-all (see supabase/functions/mcp-run-v1/index.ts
    and isReadonlyMcpPath in lib/auth.ts).
    """
    from starspace_cli.errors import StarSpaceError

    # tools/list must not advertise write tools on the readonly surface.
    tools = client.mcp_tools_list(readonly=True)
    names = {t.get("name") for t in tools if isinstance(t, dict)}
    for forbidden in ("write_file", "apply_patch", "edit_file"):
        assert forbidden not in names, (
            f"/readonly tools/list exposed write tool {forbidden!r}: {sorted(names)}"
        )

    # tools/call for one of those write tools must error (Method not found,
    # since the tool was never registered on the readonly route's MCP server).
    with pytest.raises(StarSpaceError):
        client.mcp_call(
            "write_file",
            {"path": "test_must_not_be_written.txt", "content": "nope"},
            readonly=True,
        )


def test_workspace_summary_returns_structured_json(client: StarSpaceClient) -> None:
    result = client.mcp_call("workspace_summary", {}, readonly=True)
    text = result["content"][0]["text"]
    import json
    parsed = json.loads(text)
    assert "workspace_id" in parsed
    assert "file_count" in parsed
    assert isinstance(parsed["file_count"], int)


def test_run_readonly_executes_a_simple_command(client: StarSpaceClient) -> None:
    # On /readonly the `run` tool is the readonly variant - the route carries
    # the capability restriction, so a separate `run_readonly` tool isn't
    # registered there. (`run_readonly` does exist on the writable surface.)
    result = client.mcp_call("run", {"command": "echo hello-from-test"}, readonly=True)
    text = result["content"][0]["text"]
    assert "hello-from-test" in text


def test_search_handles_empty_query_gracefully(client: StarSpaceClient) -> None:
    # A made-up token that's unlikely to match anything; the call must still
    # succeed with an empty (or non-empty) result list, not raise.
    result = client.mcp_call("search", {"query": "zzzz_search_token_xyz_nomatch"}, readonly=True)
    text = result["content"][0]["text"]
    import json
    parsed = json.loads(text)
    assert "results" in parsed
    assert isinstance(parsed["results"], list)
