"""Live integration tests for the mcp-run-v1 OAuth Dynamic Client Registration
endpoint, focused on the tenant-less / workspace-pickable code path.

Each successful DCR call leaves a row in `oauth_clients`. That's intentional -
DCR cleanup happens through the consent / revoke flow, not from this test
suite - but it does mean these tests gradually accumulate test rows on the
shared test workspace. Keep the test count low.
"""
from __future__ import annotations

import os
from typing import Any, Dict, Optional

import pytest
import requests


pytestmark = pytest.mark.live


SUPABASE_PROJECT_REF_ENV = "STARSPACE_TEST_SUPABASE_PROJECT_REF"
SUPABASE_ANON_KEY_ENV = "STARSPACE_TEST_SUPABASE_ANON_KEY"


def _register_dcr(base_url: str, body: Dict[str, Any]) -> Dict[str, Any]:
    response = requests.post(
        f"{base_url}/functions/v1/mcp-run-v1/oauth/register",
        json=body,
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


def _public_lookup(client_id: str) -> Optional[Dict[str, Any]]:
    """Look up the freshly-registered client via get_oauth_client_public.

    Returns None if neither a Supabase project ref nor anon key is configured -
    the caller should xfail/skip in that case rather than failing the test.
    """
    project_ref = os.getenv(SUPABASE_PROJECT_REF_ENV)
    anon_key = os.getenv(SUPABASE_ANON_KEY_ENV)
    if not project_ref or not anon_key:
        return None
    response = requests.post(
        f"https://{project_ref}.supabase.co/rest/v1/rpc/get_oauth_client_public",
        json={"p_client_id": client_id},
        headers={
            "apikey": anon_key,
            "Authorization": f"Bearer {anon_key}",
            "Content-Type": "application/json",
        },
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


def test_tenantless_dcr_registers_a_workspace_pickable_client(live_base_url: str) -> None:
    """DCR against /oauth/register with no workspace context creates a
    workspace-pickable client (workspace_id NULL, metadata.workspace_pickable
    true). The response itself is the bare RFC 7591 shape - workspace metadata
    only shows up on the consent-side lookup, which we cover separately."""
    body = {
        "client_name": "starspace-cli pytest tenant-less",
        "redirect_uris": ["https://example.com/cb-tenantless"],
        "scope": "workspace:read workspace:ask offline_access",
        "client_uri": "https://example.com/tenantless-test",
        "software_id": "starspace-cli-test-tenantless",
    }

    payload = _register_dcr(live_base_url, body)

    assert payload.get("client_id", "").startswith("oc_"), (
        f"DCR response missing client_id: {payload}"
    )
    assert payload.get("token_endpoint_auth_method") == "none", payload
    assert payload.get("redirect_uris") == ["https://example.com/cb-tenantless"], payload
    assert "offline_access" in payload.get("scope", ""), payload

    looked_up = _public_lookup(payload["client_id"])
    if looked_up is None:
        pytest.skip(
            f"set {SUPABASE_PROJECT_REF_ENV} and {SUPABASE_ANON_KEY_ENV} to assert "
            "the workspace_pickable / workspace_id shape via get_oauth_client_public"
        )

    assert looked_up.get("workspace_id") is None, looked_up
    metadata = looked_up.get("metadata") or {}
    assert metadata.get("workspace_pickable") is True, looked_up
    assert metadata.get("dcr") is True, looked_up


def test_workspace_bound_dcr_still_pins_to_workspace(live_base_url: str, live_workspace_id: str) -> None:
    """Existing workspace-bound DCR path: when the request carries a
    `resource` URL with /workspace/<id>, the resulting client is pinned to
    that workspace and metadata.workspace_pickable is false."""
    body = {
        "client_name": "starspace-cli pytest workspace-bound",
        "redirect_uris": ["https://example.com/cb-bound"],
        "scope": "workspace:read",
        "resource": f"{live_base_url}/functions/v1/mcp-run-v1/workspace/{live_workspace_id}",
    }

    payload = _register_dcr(live_base_url, body)

    assert payload.get("client_id", "").startswith("oc_"), payload

    looked_up = _public_lookup(payload["client_id"])
    if looked_up is None:
        pytest.skip(
            f"set {SUPABASE_PROJECT_REF_ENV} and {SUPABASE_ANON_KEY_ENV} to assert "
            "the workspace_pickable / workspace_id shape via get_oauth_client_public"
        )

    assert looked_up.get("workspace_id") == live_workspace_id, looked_up
    metadata = looked_up.get("metadata") or {}
    assert metadata.get("workspace_pickable") is False, looked_up
