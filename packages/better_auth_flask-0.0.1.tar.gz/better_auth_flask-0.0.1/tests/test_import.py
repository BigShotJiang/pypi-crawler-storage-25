import better_auth.flask


def test_import():
    assert better_auth.flask.__name__ == "better_auth.flask"
