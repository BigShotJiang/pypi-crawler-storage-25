"""Flask integration namespace."""
