"""QQ channel implementation using botpy SDK."""

import asyncio
from collections import deque
import os
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import unquote, urlparse
from urllib.request import url2pathname

from loguru import logger

from mira_engine.bus.events import OutboundMessage
from mira_engine.bus.queue import MessageBus
from mira_engine.channels.base import BaseChannel
from mira_engine.config.schema import QQConfig

try:
    import botpy
    from botpy.message import C2CMessage, GroupMessage

    QQ_AVAILABLE = True
except ImportError:
    QQ_AVAILABLE = False
    botpy = None
    C2CMessage = None
    GroupMessage = None

if TYPE_CHECKING:
    from botpy.message import C2CMessage, GroupMessage


def _make_bot_class(channel: "QQChannel") -> "type[botpy.Client]":
    """Create a botpy Client subclass bound to the given channel."""
    intents = botpy.Intents(public_messages=True, direct_message=True)

    class _Bot(botpy.Client):
        def __init__(self):
            # Disable botpy's file log — mira uses loguru; default "botpy.log" fails on read-only fs
            super().__init__(intents=intents, ext_handlers=False)

        async def on_ready(self):
            logger.info("QQ bot ready: {}", self.robot.name)

        async def on_c2c_message_create(self, message: "C2CMessage"):
            await channel._on_message(message, is_group=False)

        async def on_group_at_message_create(self, message: "GroupMessage"):
            await channel._on_message(message, is_group=True)

        async def on_direct_message_create(self, message):
            await channel._on_message(message, is_group=False)

    return _Bot


class QQChannel(BaseChannel):
    """QQ channel using botpy SDK with WebSocket connection."""

    name = "qq"

    def __init__(self, config: QQConfig, bus: MessageBus):
        super().__init__(config, bus)
        self.config: QQConfig = config
        self._client: "botpy.Client | None" = None
        self._processed_ids: deque = deque(maxlen=1000)
        self._msg_seq: int = 1  # 消息序列号，避免被 QQ API 去重
        self._chat_type_cache: dict[str, str] = {}

    async def start(self) -> None:
        """Start the QQ bot."""
        if not QQ_AVAILABLE:
            logger.error("QQ SDK not installed. Run: pip install qq-botpy")
            return

        if not self.config.app_id or not self.config.secret:
            logger.error("QQ app_id and secret not configured")
            return

        self._running = True
        BotClass = _make_bot_class(self)
        self._client = BotClass()
        logger.info("QQ bot started (C2C & Group supported)")
        await self._run_bot()

    async def _run_bot(self) -> None:
        """Run the bot connection with auto-reconnect."""
        while self._running:
            try:
                await self._client.start(appid=self.config.app_id, secret=self.config.secret)
            except Exception as e:
                logger.warning("QQ bot error: {}", e)
            if self._running:
                logger.info("Reconnecting QQ bot in 5 seconds...")
                await asyncio.sleep(5)

    async def stop(self) -> None:
        """Stop the QQ bot."""
        self._running = False
        if self._client:
            try:
                await self._client.close()
            except Exception:
                pass
        logger.info("QQ bot stopped")

    async def send(self, msg: OutboundMessage) -> None:
        """Send a message through QQ."""
        if not self._client:
            logger.warning("QQ client not initialized")
            return

        try:
            msg_id = msg.metadata.get("message_id")
            self._msg_seq += 1
            msg_type = self._chat_type_cache.get(msg.chat_id, "c2c")
            use_markdown = getattr(self.config, "msg_format", "text") == "markdown"
            if msg_type == "group":
                if use_markdown:
                    await self._client.api.post_group_message(
                        group_openid=msg.chat_id,
                        msg_type=2,
                        markdown={"content": msg.content},
                        msg_id=msg_id,
                        msg_seq=self._msg_seq,
                    )
                else:
                    await self._client.api.post_group_message(
                        group_openid=msg.chat_id,
                        msg_type=0,
                        content=msg.content,
                        msg_id=msg_id,
                        msg_seq=self._msg_seq,
                    )
            else:
                if use_markdown:
                    await self._client.api.post_c2c_message(
                        openid=msg.chat_id,
                        msg_type=2,
                        markdown={"content": msg.content},
                        msg_id=msg_id,
                        msg_seq=self._msg_seq,
                    )
                else:
                    await self._client.api.post_c2c_message(
                        openid=msg.chat_id,
                        msg_type=0,
                        content=msg.content,
                        msg_id=msg_id,
                        msg_seq=self._msg_seq,
                    )
        except Exception as e:
            logger.error("Error sending QQ message: {}", e)

    async def _on_message(self, data: "C2CMessage | GroupMessage", is_group: bool = False) -> None:
        """Handle incoming message from QQ."""
        try:
            # Dedup by message ID
            if data.id in self._processed_ids:
                return
            self._processed_ids.append(data.id)

            content = (data.content or "").strip()
            if not content:
                return

            if is_group:
                chat_id = data.group_openid
                user_id = data.author.member_openid
                self._chat_type_cache[chat_id] = "group"
            else:
                chat_id = str(getattr(data.author, 'id', None) or getattr(data.author, 'user_openid', 'unknown'))
                user_id = chat_id
                self._chat_type_cache[chat_id] = "c2c"

            ack = getattr(self.config, "ack_message", "").strip()
            if ack and self._client:
                self._msg_seq += 1
                if is_group:
                    await self._client.api.post_group_message(
                        group_openid=chat_id,
                        msg_type=0,
                        content=ack,
                        msg_id=data.id,
                        msg_seq=self._msg_seq,
                    )
                else:
                    await self._client.api.post_c2c_message(
                        openid=chat_id,
                        msg_type=0,
                        content=ack,
                        msg_id=data.id,
                        msg_seq=self._msg_seq,
                    )

            await self._handle_message(
                sender_id=user_id,
                chat_id=chat_id,
                content=content,
                metadata={"message_id": data.id},
            )
        except Exception:
            logger.exception("Error handling QQ message")

    async def _read_media_bytes(self, media_path: str) -> tuple[bytes | None, str | None]:
        path = media_path
        if media_path.startswith("file://"):
            parsed = urlparse(media_path)
            if parsed.netloc and not parsed.path:
                # Handles non-standard forms like file://C:\Users\foo\bar.jpg
                path = unquote(parsed.netloc)
            else:
                path_part = parsed.path
                if parsed.netloc and parsed.netloc.lower() != "localhost":
                    path_part = f"//{parsed.netloc}{path_part}"
                path = unquote(url2pathname(path_part))
            if os.name == "nt" and path.startswith("/") and len(path) > 2 and path[2] == ":":
                # Normalize /C:/foo.jpg -> C:/foo.jpg
                path = path[1:]
        fp = Path(path)
        if not fp.exists() or not fp.is_file():
            return None, None
        try:
            return fp.read_bytes(), fp.name
        except Exception:
            return None, None
