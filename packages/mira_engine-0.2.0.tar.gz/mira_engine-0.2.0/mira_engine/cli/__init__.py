"""CLI module for mira."""
