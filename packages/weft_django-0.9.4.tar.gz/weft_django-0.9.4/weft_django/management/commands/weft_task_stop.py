"""Django management command for graceful Weft task stop."""

from __future__ import annotations

from django.core.management.base import BaseCommand, CommandError

from weft_django.client import stop


class Command(BaseCommand):
    help = "Gracefully stop a Weft task"

    def add_arguments(self, parser) -> None:  # type: ignore[override]
        parser.add_argument("tid")

    def handle(self, *args, **options) -> None:  # type: ignore[override]
        if not stop(options["tid"]):
            raise CommandError(f"Failed to stop task: {options['tid']}")
        self.stdout.write(options["tid"])
