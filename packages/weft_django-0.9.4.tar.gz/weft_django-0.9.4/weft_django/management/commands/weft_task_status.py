"""Django management command for one Weft task status."""

from __future__ import annotations

import json
from dataclasses import asdict

from django.core.management.base import BaseCommand, CommandError

from weft_django.client import status


class Command(BaseCommand):
    help = "Show one Weft task snapshot"

    def add_arguments(self, parser) -> None:  # type: ignore[override]
        parser.add_argument("tid")

    def handle(self, *args, **options) -> None:  # type: ignore[override]
        snapshot = status(options["tid"])
        if snapshot is None:
            raise CommandError(f"Unknown task: {options['tid']}")
        self.stdout.write(json.dumps(asdict(snapshot), ensure_ascii=False))
