"""Django management command for Weft task status overview."""

from __future__ import annotations

import json
from dataclasses import asdict

from django.core.management.base import BaseCommand

from weft.commands import tasks as task_cmd

from weft_django.conf import resolve_context_override


class Command(BaseCommand):
    help = "Show recent Weft task snapshots"

    def handle(self, *args, **options) -> None:  # type: ignore[override]
        snapshots = task_cmd.list_tasks(
            include_terminal=True,
            context_path=resolve_context_override(),
        )
        self.stdout.write(
            json.dumps([snapshot.to_dict() for snapshot in snapshots], ensure_ascii=False)
        )
