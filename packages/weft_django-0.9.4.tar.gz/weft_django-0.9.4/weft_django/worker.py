"""Django bootstrap wrapper for registered Weft tasks."""

from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Any


logger = logging.getLogger(__name__)


def _normalize_envelope(work_item: Any) -> dict[str, Any]:
    if isinstance(work_item, dict):
        payload = work_item.get("payload")
        if isinstance(payload, dict) and "task_name" in payload:
            return payload
        if "task_name" in work_item:
            return work_item
    raise ValueError("Registered Django task work item must contain a payload envelope")


def run_registered_task(work_item: Any = None) -> Any:
    """Bootstrap Django, resolve the registered task, and execute it."""

    import django
    from django.db import close_old_connections

    from weft_django.registry import get_task

    django.setup()
    close_old_connections()
    try:
        envelope = _normalize_envelope(work_item)
        task_name = envelope.get("task_name")
        if not isinstance(task_name, str) or not task_name:
            raise ValueError("Registered task envelope is missing task_name")
        task = get_task(task_name)
        call = envelope.get("call")
        call = call if isinstance(call, Mapping) else {}
        args = call.get("args")
        kwargs = call.get("kwargs")
        call_args = list(args) if isinstance(args, list) else []
        call_kwargs = dict(kwargs) if isinstance(kwargs, dict) else {}
        logger.info(
            "Executing registered Django task",
            extra={
                "task_name": task_name,
                "tid": envelope.get("tid"),
                "submitter_request_id": envelope.get("request_id"),
            },
        )
        return task.func(*call_args, **call_kwargs)
    finally:
        close_old_connections()
