"""Django-facing client helpers layered over `weft.client`."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from django.db import transaction

from weft.client import SubmittedTask, TaskEvent, TaskResult, TaskSnapshot, WeftClient
from weft.commands import specs as spec_cmd
from weft.core.pipelines import compile_linear_pipeline, load_pipeline_spec_payload
from weft.core.taskspec import TaskSpec, apply_bundle_root_to_taskspec_payload

from weft_django.conf import (
    get_default_task_settings,
    merge_metadata,
    resolve_context_override,
)
from weft_django.registry import get_task


@dataclass(slots=True)
class WeftSubmission:
    """Lightweight Django-facing result handle."""

    client: WeftClient
    submitted: SubmittedTask
    _cached_result: TaskResult | None = None
    _cached_snapshot: TaskSnapshot | None = None

    @property
    def tid(self) -> str:
        return self.submitted.tid

    @property
    def name(self) -> str:
        return self.submitted.name

    def status(self) -> TaskSnapshot | None:
        if self._cached_snapshot is None:
            self._cached_snapshot = self.client.status(self.tid)
        return self._cached_snapshot

    def wait(self, timeout: float | None = None) -> TaskSnapshot | None:
        if self._cached_result is None:
            self._cached_result = self.client.result(self.tid, timeout=timeout)
        self._cached_snapshot = self.client.status(self.tid)
        return self._cached_snapshot

    def result(self, timeout: float | None = None) -> TaskResult:
        if self._cached_result is None:
            self._cached_result = self.client.result(self.tid, timeout=timeout)
            self._cached_snapshot = self.client.status(self.tid)
        return self._cached_result

    def stop(self) -> bool:
        return self.client.stop(self.tid)

    def kill(self) -> bool:
        return self.client.kill(self.tid)

    def events(self, *, follow: bool = False) -> Any:
        return self.client.events(self.tid, follow=follow, include_output=True)


@dataclass(slots=True)
class WeftDeferredSubmission:
    """Handle for submission deferred until transaction commit."""

    name: str
    submission: WeftSubmission | None = None

    @property
    def tid(self) -> str | None:
        if self.submission is None:
            return None
        return self.submission.tid

    def bind(self, submission: WeftSubmission) -> WeftSubmission:
        self.submission = submission
        return submission


class DjangoWeftClient:
    """Small Django-native wrapper over the core Weft client."""

    def __init__(self, core_client: WeftClient) -> None:
        self.core_client = core_client

    def status(self, tid: str) -> TaskSnapshot | None:
        return self.core_client.status(tid)

    def result(self, tid: str, timeout: float | None = None) -> TaskResult:
        return self.core_client.result(tid, timeout=timeout)

    def stop(self, tid: str) -> bool:
        return self.core_client.stop(tid)

    def kill(self, tid: str) -> bool:
        return self.core_client.kill(tid)


def get_core_client() -> WeftClient:
    return WeftClient.from_context(resolve_context_override())


def get_client() -> DjangoWeftClient:
    return DjangoWeftClient(get_core_client())


def _clone_taskspec(
    taskspec: TaskSpec,
    *,
    template: bool,
) -> dict[str, Any]:
    payload = taskspec.model_dump(mode="json")
    bundle_root = taskspec.get_bundle_root()
    if bundle_root is not None:
        apply_bundle_root_to_taskspec_payload(payload, bundle_root)
    return payload


def _apply_taskspec_overrides(
    taskspec: TaskSpec,
    overrides: Mapping[str, Any] | None,
    *,
    decorated_task: Any | None = None,
) -> TaskSpec:
    if not overrides:
        return taskspec
    payload = _clone_taskspec(taskspec, template=taskspec.tid is None)
    spec_section = payload.setdefault("spec", {})
    metadata = payload.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
        payload["metadata"] = metadata
    if not isinstance(spec_section, dict):
        raise ValueError("TaskSpec spec section must be a mapping")

    if "metadata" in overrides:
        metadata.update(dict(overrides["metadata"] or {}))
    if "timeout" in overrides:
        spec_section["timeout"] = overrides["timeout"]
    if "stream_output" in overrides:
        spec_section["stream_output"] = overrides["stream_output"]
    if "name" in overrides and overrides["name"]:
        payload["name"] = overrides["name"]
    if "env" in overrides:
        env = spec_section.get("env")
        env = env if isinstance(env, dict) else {}
        env.update(dict(overrides["env"] or {}))
        spec_section["env"] = env
    if "working_dir" in overrides:
        spec_section["working_dir"] = overrides["working_dir"]
    if "runner" in overrides or "runner_options" in overrides:
        runner = spec_section.get("runner")
        runner = runner if isinstance(runner, dict) else {}
        runner_name = overrides.get("runner", runner.get("name"))
        if decorated_task is not None and runner_name not in (None, "", "host"):
            raise ValueError("Decorated Django tasks only support runner='host' in v1")
        if runner_name:
            runner["name"] = runner_name
        options = runner.get("options")
        options = options if isinstance(options, dict) else {}
        if "runner_options" in overrides:
            options.update(dict(overrides["runner_options"] or {}))
        runner["options"] = options
        spec_section["runner"] = runner

    updated = TaskSpec.model_validate(
        payload,
        context={"template": taskspec.tid is None, "auto_expand": False},
    )
    updated.set_bundle_root(taskspec.get_bundle_root())
    return updated


def _submission_from_core(
    core_client: WeftClient,
    submitted: SubmittedTask,
) -> WeftSubmission:
    return WeftSubmission(client=core_client, submitted=submitted)


def _maybe_wait(submission: WeftSubmission, overrides: Mapping[str, Any] | None) -> WeftSubmission:
    if overrides and overrides.get("wait"):
        submission.result()
    return submission


def _build_limits(
    *,
    memory_mb: int | None,
    cpu_percent: int | None,
) -> dict[str, Any] | None:
    limits: dict[str, Any] = {}
    if memory_mb is not None:
        limits["memory_mb"] = memory_mb
    if cpu_percent is not None:
        limits["cpu_percent"] = cpu_percent
    return limits or None


def build_registered_task_taskspec(
    task: Any,
    *,
    envelope: Mapping[str, Any],
    overrides: Mapping[str, Any] | None,
    embed_envelope: bool,
) -> TaskSpec:
    default_task_settings = get_default_task_settings()
    metadata = merge_metadata(
        default_task_settings.get("metadata"),
        task.metadata,
        overrides.get("metadata") if overrides else None,
    )
    if task.description:
        metadata.setdefault("description", task.description)
    metadata.setdefault("django_app_label", task.app_label)
    metadata.setdefault("callable_ref", task.callable_ref)

    timeout = (
        overrides.get("timeout")
        if overrides and "timeout" in overrides
        else task.timeout
        if task.timeout is not None
        else default_task_settings.get("timeout")
    )
    stream_output = (
        overrides.get("stream_output")
        if overrides and "stream_output" in overrides
        else task.stream_output
        if task.stream_output is not None
        else default_task_settings.get("stream_output", False)
    )
    runner = task.runner or default_task_settings.get("runner", "host")
    if runner != "host":
        raise ValueError("Decorated Django tasks only support runner='host' in v1")
    runner_options = merge_metadata(
        default_task_settings.get("runner_options"),
        task.runner_options,
    )
    working_dir = task.working_dir or default_task_settings.get("working_dir")
    env = merge_metadata(default_task_settings.get("env"), task.env)
    memory_mb = (
        task.memory_mb
        if task.memory_mb is not None
        else default_task_settings.get("memory_mb")
    )
    cpu_percent = (
        task.cpu_percent
        if task.cpu_percent is not None
        else default_task_settings.get("cpu_percent")
    )
    limits = _build_limits(memory_mb=memory_mb, cpu_percent=cpu_percent)
    spec_payload: dict[str, Any] = {
        "name": task.name,
        "spec": {
            "type": "function",
            "function_target": "weft_django.worker:run_registered_task",
            "runner": {
                "name": "host",
                "options": runner_options,
            },
            "args": [{"payload": dict(envelope)}] if embed_envelope else [],
            "keyword_args": {},
            "env": env,
            "working_dir": working_dir,
            "stream_output": bool(stream_output),
        },
        "metadata": metadata,
    }
    context_override = resolve_context_override()
    if context_override is not None:
        spec_payload["spec"]["weft_context"] = str(context_override)
    if timeout is not None:
        spec_payload["spec"]["timeout"] = timeout
    if limits is not None:
        spec_payload["spec"]["limits"] = limits
    taskspec = TaskSpec.model_validate(
        spec_payload,
        context={"template": True, "auto_expand": False},
    )
    return _apply_taskspec_overrides(taskspec, overrides, decorated_task=task)


def submit_registered_task(
    task: Any,
    *,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    overrides: Mapping[str, Any] | None = None,
) -> WeftSubmission:
    envelope = task.build_envelope(*args, **kwargs)
    taskspec = build_registered_task_taskspec(
        task,
        envelope=envelope,
        overrides=overrides,
        embed_envelope=False,
    )
    core_client = get_core_client()
    submitted = core_client.submit_taskspec(
        taskspec,
        work_payload={"payload": envelope},
    )
    return _maybe_wait(_submission_from_core(core_client, submitted), overrides)


def submit_registered_task_on_commit(
    task: Any,
    *,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    overrides: Mapping[str, Any] | None = None,
) -> WeftDeferredSubmission:
    if overrides and overrides.get("wait"):
        raise ValueError("enqueue_on_commit(..., wait=True) is not supported")
    deferred = WeftDeferredSubmission(name=task.name)

    def _submit() -> None:
        deferred.bind(
            submit_registered_task(
                task,
                args=args,
                kwargs=kwargs,
                overrides=overrides,
            )
        )

    transaction.on_commit(_submit)
    return deferred


def submit_taskspec(
    taskspec: TaskSpec,
    *,
    work_payload: Any = None,
    **overrides: Any,
) -> WeftSubmission:
    updated = _apply_taskspec_overrides(taskspec, overrides or None)
    core_client = get_core_client()
    submitted = core_client.submit_taskspec(updated, work_payload=work_payload)
    return _maybe_wait(_submission_from_core(core_client, submitted), overrides or None)


def submit_taskspec_on_commit(
    taskspec: TaskSpec,
    *,
    work_payload: Any = None,
    **overrides: Any,
) -> WeftDeferredSubmission:
    if overrides.get("wait"):
        raise ValueError("submit_taskspec_on_commit(..., wait=True) is not supported")
    deferred = WeftDeferredSubmission(name=taskspec.name)

    def _submit() -> None:
        deferred.bind(submit_taskspec(taskspec, work_payload=work_payload, **overrides))

    transaction.on_commit(_submit)
    return deferred


def _resolve_reference_taskspec(reference: str | Any) -> TaskSpec:
    resolved = spec_cmd.resolve_spec_reference(
        reference,
        spec_type=spec_cmd.SPEC_TYPE_TASK,
        context_path=resolve_context_override(),
    )
    taskspec = TaskSpec.model_validate(
        resolved.payload,
        context={"template": True, "auto_expand": False},
    )
    taskspec.set_bundle_root(resolved.bundle_root)
    return taskspec


def submit_spec_reference(
    reference: str | Any,
    *,
    input: Any = None,
    **overrides: Any,
) -> WeftSubmission:
    return submit_taskspec(_resolve_reference_taskspec(reference), work_payload=input, **overrides)


def submit_spec_reference_on_commit(
    reference: str | Any,
    *,
    input: Any = None,
    **overrides: Any,
) -> WeftDeferredSubmission:
    if overrides.get("wait"):
        raise ValueError(
            "submit_spec_reference_on_commit(..., wait=True) is not supported"
        )
    deferred = WeftDeferredSubmission(name=str(reference))

    def _submit() -> None:
        deferred.bind(submit_spec_reference(reference, input=input, **overrides))

    transaction.on_commit(_submit)
    return deferred


def _resolve_compiled_pipeline(reference: str | Any) -> Any:
    resolved = spec_cmd.resolve_spec_reference(
        reference,
        spec_type=spec_cmd.SPEC_TYPE_PIPELINE,
        context_path=resolve_context_override(),
    )
    pipeline_spec = load_pipeline_spec_payload(resolved.payload)
    context = get_core_client().context

    def _load_pipeline_stage(task_name: str) -> dict[str, Any]:
        stage_ref = spec_cmd.resolve_named_spec(
            task_name,
            spec_type=spec_cmd.SPEC_TYPE_TASK,
            context_path=context.root,
        )
        return apply_bundle_root_to_taskspec_payload(
            dict(stage_ref.payload),
            stage_ref.bundle_root,
        )

    return compile_linear_pipeline(
        pipeline_spec,
        context=context,
        task_loader=_load_pipeline_stage,
        source_ref=str(resolved.path),
    )


def submit_pipeline_reference(
    reference: str | Any,
    *,
    input: Any = None,
    **overrides: Any,
) -> WeftSubmission:
    compiled = _resolve_compiled_pipeline(reference)
    taskspec = _apply_taskspec_overrides(compiled.pipeline_taskspec, overrides or None)
    work_payload = input if input is not None else compiled.bootstrap_input_fallback
    core_client = get_core_client()
    submitted = core_client.submit_taskspec(
        taskspec,
        work_payload=work_payload,
        seed_start_envelope=False,
        allow_internal_runtime=True,
    )
    return _maybe_wait(_submission_from_core(core_client, submitted), overrides or None)


def submit_pipeline_reference_on_commit(
    reference: str | Any,
    *,
    input: Any = None,
    **overrides: Any,
) -> WeftDeferredSubmission:
    if overrides.get("wait"):
        raise ValueError(
            "submit_pipeline_reference_on_commit(..., wait=True) is not supported"
        )
    deferred = WeftDeferredSubmission(name=str(reference))

    def _submit() -> None:
        deferred.bind(submit_pipeline_reference(reference, input=input, **overrides))

    transaction.on_commit(_submit)
    return deferred


def _resolve_task(task: str | Any) -> Any:
    if isinstance(task, str):
        return get_task(task)
    return task


def enqueue(
    task: str | Any,
    *args: Any,
    _overrides: Mapping[str, Any] | None = None,
    **kwargs: Any,
) -> WeftSubmission:
    return submit_registered_task(
        _resolve_task(task),
        args=args,
        kwargs=kwargs,
        overrides=_overrides,
    )


def enqueue_on_commit(
    task: str | Any,
    *args: Any,
    _overrides: Mapping[str, Any] | None = None,
    **kwargs: Any,
) -> WeftDeferredSubmission:
    return submit_registered_task_on_commit(
        _resolve_task(task),
        args=args,
        kwargs=kwargs,
        overrides=_overrides,
    )


def status(tid: str) -> TaskSnapshot | None:
    try:
        return get_core_client().status(tid)
    except ValueError:
        return None


def result(tid: str, timeout: float | None = None) -> TaskResult:
    return get_core_client().result(tid, timeout=timeout)


def stop(tid: str) -> bool:
    try:
        return get_core_client().stop(tid)
    except ValueError:
        return False


def kill(tid: str) -> bool:
    try:
        return get_core_client().kill(tid)
    except ValueError:
        return False
