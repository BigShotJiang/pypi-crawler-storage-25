<br/>

<div align="center">
  <img src="public/marziel-logo.png" alt="Marziel OS" width="200"/>
  <h1>🧠 Marziel OS — v1.0.1</h1>
  <p><strong>Private AI Operating System — runs entirely on your hardware.</strong></p>
  <p>
    <a href="https://pypi.org/project/marziel/"><img src="https://img.shields.io/pypi/v/marziel?color=blue&label=PyPI" alt="PyPI"/></a>
    <a href="https://github.com/efops/marziel"><img src="https://img.shields.io/github/stars/efops/marziel?style=social" alt="GitHub Stars"/></a>
    <a href="https://huggingface.co/efops/marziel-8b-custom"><img src="https://img.shields.io/badge/🤗%20Model-marziel--8b-yellow" alt="HuggingFace"/></a>
    <a href="https://github.com/efops/marziel/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-MIT-green" alt="MIT License"/></a>
  </p>
</div>

> One command to boot your own AI OS — with MarzielFlow adaptive inference, 3-tier encrypted memory, and autonomous process management.

Marziel OS is a **private AI operating system** that transforms your machine into an intelligent, self-managing system. It features an AI kernel with persistent event loop, 3-tier memory (working → long-term → episodic), Unix-like process management, MarzielFlow adaptive inference optimization (T/Z distribution quantization, fuzzy logic, attention sink), TurboQuant KV cache compression, real-time maritime intelligence, and 12-route semantic intent routing — all without sending a single byte to the cloud.

## Quick Install

```bash
pip install marziel
marziel serve
```

That's it. The right engine is auto-installed for your hardware. The first run downloads the model from Hugging Face. Everything is automatic.

## What's New in v1.0.1

### 🧠 Marziel OS — The AI Kernel

Marziel is no longer just a chatbot. It's now a **persistent operating system** with:

```
  ╔══════════════════════════════════════════════════════════╗
  ║  🧠 Marziel OS v1.0 — Private Intelligence OS          ║
  ╚══════════════════════════════════════════════════════════╝

     Kernel:     active (heartbeat: 60s)
     Engine:     marziel-v6 (CUDA, 52.9 tok/s)
     Flow:       5 components (T/Z + ABQ + Fuzzy + Sink + Spec)
     Memory:     working=0 | long-term=2.4KB | episodic=156KB
     Processes:  0 running, 0 queued
     Security:   Sentinel active (anti-fingerprint, encrypted)
```

### 🔬 MarzielFlow — 5-Component Adaptive Inference

| Component | What It Does | Impact |
|-----------|-------------|--------|
| **Speculative Decoding** | Prompt lookup draft/verify | Higher throughput |
| **T/Z Distribution Quantization** | Per-layer distribution detection + Lloyd-Max boundaries | Better quality at lower bits |
| **Adaptive Bit-Width (ABQ)** | 2/3/4-bit per layer by sensitivity | 2.88-bit avg, memory savings |
| **Fuzzy Logic Controller** | Mamdani-style adaptive resource control | Smooth parameter adaptation |
| **Attention Sink Cache** | StreamingLLM: 4 sink tokens + 1024 rolling window | 75% memory savings |

### 🖥️ OS API

```
GET  /os/status       — Full kernel + engine + memory status
GET  /os/memory       — 3-tier memory (working, long-term, episodic)
GET  /os/ps           — Process list (like Unix ps)
GET  /os/top          — Real-time resource monitor
POST /os/recall       — Semantic memory recall
POST /os/remember     — Store encrypted persistent memory
POST /os/schedule     — Schedule recurring tasks
POST /os/kill/:pid    — Kill a process
```

## Features

| Feature | Description |
|---------|-------------|
| 🧠 **AI OS Kernel** | Persistent event loop, heartbeat, task scheduler, signal bus |
| 💾 **3-Tier Memory** | Working (volatile) → Long-Term (AES-256 encrypted) → Episodic (permanent summaries) |
| ⚙️ **Process Manager** | Unix-like `ps`, `top`, `kill` with priority scheduling |
| 🔬 **MarzielFlow** | 5-component adaptive inference optimization pipeline |
| ⚡ **TurboQuant** | PolarQuant + QJL 3-bit KV cache compression (3x memory reduction) |
| 🧠 **AI Chat** | Conversational AI with personality, code generation, data analysis |
| 📡 **Maritime Intelligence** | Real-time GDACS, GDELT, NASA EONET, AIS, market data, bunker prices |
| 💰 **Market Data** | Live Brent crude, BDI, EU Carbon, freight rates, forex, 12-port bunker prices |
| 🚢 **Vessel Integration** | AIS tracking, fleet management, voyage data, maintenance records |
| 🔌 **Third-Party Connectors** | MarineTraffic, VesselFinder, Spire, Datalastic, or any REST API |
| 🔍 **Web Search** | Live internet results via DuckDuckGo — always up-to-date answers |
| 🌐 **Browser Control** | Headless Chromium automation — navigate, click, type, screenshot |
| 🔗 **URL Analysis** | Share any link — reads, extracts, and analyzes content |
| 🐙 **GitHub Analysis** | Paste any repo URL — get architecture, languages, README analysis |
| ⚡ **Autonomous Agent** | Multi-step reasoning with bash, file, web, browser, and maritime tools |
| 📑 **Hybrid RAG** | Upload documents → reasoning + vector search → answers with citations |
| 🔒 **100% Private** | Everything runs locally. Zero cloud dependency |
| 🛡️ **Sentinel Security** | Anti-fingerprinting, encrypted storage, secure memory wipe, zero telemetry |

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      MARZIEL OS v1.0                        │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ INTENT SHELL (12 semantic routes)                    │   │
│  │ "check vessels" → parse → schedule → report          │   │
│  └──────────────────────────────────────────────────────┘   │
│                           │                                 │
│  ┌────────────┐  ┌────────▼───────┐  ┌──────────────────┐  │
│  │ PROCESS    │  │ KERNEL         │  │ MEMORY MANAGER   │  │
│  │ MANAGER    │  │                │  │                  │  │
│  │            │  │ Event Loop     │  │ Working Memory   │  │
│  │ Task Queue │◄─┤ Scheduler      ├─►│ Long-Term (AES)  │  │
│  │ PID Table  │  │ Signal Bus     │  │ Episodic (JSONL) │  │
│  │ Lifecycle  │  │ Heartbeat      │  │ Semantic Recall  │  │
│  └────────────┘  └────────────────┘  └──────────────────┘  │
│                           │                                 │
│  ┌────────────────────────▼─────────────────────────────┐  │
│  │ INFERENCE ENGINE                                      │  │
│  │ MarzielEngine + MarzielFlow + TurboQuant              │  │
│  │ ┌──────────────────────────────────────────────────┐  │  │
│  │ │ T/Z Quant │ ABQ │ Fuzzy │ Sink Cache │ Spec Dec │  │  │
│  │ └──────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────┘  │
│                           │                                 │
│  ┌────────────────────────▼─────────────────────────────┐  │
│  │ NEURONS (Axon + Dendrite + 8 Synapse types)           │  │
│  │ SENTINEL (Security: anti-fingerprint, encrypted vault) │  │
│  └───────────────────────────────────────────────────────┘  │
│                    YOUR MACHINE                             │
└─────────────────────────────────────────────────────────────┘
```

## Maritime Intelligence (Enterprise)

Marziel integrates real-time maritime data from multiple global sources:

```
┌───────────────────────────────────────────────────────────┐
│                   MARZIEL MARITIME INTEL                   │
├───────────────────────────────────────────────────────────┤
│  OSINT (Free APIs)         │  Platform Integration        │
│  ─────────────────         │  ────────────────────        │
│  📡 GDACS — Disasters      │  🚢 Fleet Vessels            │
│  📰 GDELT — Geopolitics    │  🗺️  Active Voyages          │
│  🌍 NASA EONET — Climate   │  ⚠️  Risk Zones              │
│  💰 Yahoo Finance — Market │  🏗️  Maintenance             │
│  💱 ExchangeRate — Forex   │  📋 Incidents                │
│  🚢 AISStream — Tracking   │  ⛽ Fuel Records             │
│                            │  🏭 Port Directory           │
├───────────────────────────────────────────────────────────┤
│  Third-Party Connectors (Enterprise)                      │
│  ─────────────────────────────────                        │
│  MarineTraffic · VesselFinder · Spire Maritime            │
│  Datalastic · OpenWeather · Custom REST API               │
└───────────────────────────────────────────────────────────┘
```

### Maritime API Endpoints

```
GET  /api/maritime/report           — Full intelligence report
GET  /api/maritime/data/market      — Live market data
GET  /api/maritime/data/bunker      — 12-port bunker prices
GET  /api/maritime/data/fx          — Exchange rates
GET  /api/maritime/data/gdacs       — Disaster events
GET  /api/maritime/data/gdelt       — Geopolitical news
GET  /api/maritime/data/nasa        — Natural events
GET  /api/maritime/data/ais         — Vessel tracking
GET  /api/maritime/data/vessels     — Fleet data
GET  /api/maritime/data/voyages     — Voyage data
GET  /api/maritime/data/risk-zones  — Active risk zones
GET  /api/maritime/data/ports       — Port directory
GET  /api/maritime/connectors       — List connectors
POST /api/maritime/connectors/query — Query third-party services
```

## Requirements

- **RAM**: 8GB minimum (16GB recommended)
- **Disk**: ~5GB for the model
- **Python**: 3.10–3.14
- **Supported platforms**:

| Platform | Engine | Model | Auto-installed |
|---|---|---|---|
| Apple Silicon (M1–M4) | MLX | MLX 4-bit (4.5GB) | `mlx-lm` |
| NVIDIA GPU (any) | Marziel Engine | GGUF Q4_K_M (4.8GB) | `llama-cpp-python` |
| CPU (any x86/ARM) | llama.cpp | GGUF Q4_K_M (4.8GB) | `llama-cpp-python` |

- **Linux**: Ubuntu, Debian, Arch, Fedora, RHEL, Alpine — any distro with glibc
- **macOS**: Intel (llama.cpp) or Apple Silicon (MLX)
- **Windows**: WSL2 recommended

## Usage

```bash
# Install and boot
pip install marziel
marziel serve

# Check OS status
curl http://localhost:8001/os/status

# Store a memory
curl -X POST http://localhost:8001/os/remember \
  -H "Content-Type: application/json" \
  -d '{"key": "preference", "value": "maritime focus", "tier": "long_term"}'

# Recall a memory
curl -X POST http://localhost:8001/os/recall \
  -H "Content-Type: application/json" \
  -d '{"query": "preference", "tier": "auto"}'

# Schedule a recurring task
curl -X POST http://localhost:8001/os/schedule \
  -H "Content-Type: application/json" \
  -d '{"name": "vessel_monitor", "interval_seconds": 300}'

# Process management
curl http://localhost:8001/os/ps      # List processes
curl http://localhost:8001/os/top     # Resource monitor
```

Then open **http://localhost:8001** — your private AI OS dashboard.

## Pricing

| Plan | Price | Features |
|------|-------|----------|
| **Free** | €0/mo | AI Chat, Web Search, URL Analysis, GitHub Analysis, OS Status |
| **Pro** | €20/mo | + Agent Mode, Browser Control, Process Management, Scheduling |
| **Enterprise** | €199/mo | + Maritime Intelligence, Connectors, Reports, Custom Fine-tuning |

## Links

- 🌐 Website: [marziel.com](https://marziel.com)
- 💻 GitHub: [github.com/efops/marziel](https://github.com/efops/marziel)
- 🤗 Model: [huggingface.co/efops/marziel-8b-custom](https://huggingface.co/efops/marziel-8b-custom)
- 📦 PyPI: [pypi.org/project/marziel](https://pypi.org/project/marziel/)

## Contact

📧 info@efkan-isazade.com

## License

MIT License

---

Built with ❤️ by Efe (Efkan Isazade)
