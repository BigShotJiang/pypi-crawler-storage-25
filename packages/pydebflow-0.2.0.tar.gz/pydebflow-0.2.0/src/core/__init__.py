# Core simulation engine
