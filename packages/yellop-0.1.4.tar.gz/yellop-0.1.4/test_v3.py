import httpx
import asyncio
import sys

async def test_url(url, with_enrichment):
    params = [("query", "bars"), ("location", "NY"), ("limit", "1")]
    if with_enrichment:
        params.append(("enrichment", "contacts_n_leads"))
    # We must not use API key? Or use the valid API key NGRmNjk3MjdkYjFhNDBiMjg5MGM5NzgyZTJlZGVlMGR8ZTUwOTI5NTQ1Nw
    api_key = "NGRmNjk3MjdkYjFhNDBiMjg5MGM5NzgyZTJlZGVlMGR8ZTUwOTI5NTQ1Nw"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url, params=params, headers={"X-API-KEY": api_key})
            print(f"URL: {url}, Enrichment: {with_enrichment} -> Status: {response.status_code}")
    except Exception as e:
        print(f"URL: {url}, Enrichment: {with_enrichment} -> Error: {e}")

async def main():
    u1 = "https://api.app.outscraper.com/yellow-pages/search-v3"
    u2 = "https://api.app.outscraper.com/yellowpages-search"
    await test_url(u1, False)
    await test_url(u1, True)
    await test_url(u2, False)
    await test_url(u2, True)

asyncio.run(main())
