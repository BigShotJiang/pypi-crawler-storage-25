import httpx
import asyncio
import sys

async def main():
    enrichment = ["contacts_n_leads"]
    params = [("query", "bars"), ("location", "NY"), ("async", "true"), ("limit", "1")]
    for e in enrichment:
        params.append(("enrichment", e))
    
    url = "https://api.app.outscraper.com/yellowpages-search"
    api_key = sys.argv[1]
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url, params=params, headers={"X-API-KEY": api_key})
            print(f"Status: {response.status_code}")
            print(f"Response: {response.text}")
    except Exception as e:
        print(f"Error: {e.__class__.__name__}: {e}")

asyncio.run(main())
