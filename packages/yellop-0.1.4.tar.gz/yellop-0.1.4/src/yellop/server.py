import os
import httpx
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from typing import List, Optional
from mcp.server.fastmcp import FastMCP

# Create the MCP server
mcp = FastMCP("Yellow Pages Scraper")

# Define the base Outscraper API endpoint for Yellow Pages
# For standard search it is usually https://api.app.outscraper.com/yellowpages-search
OUTSCRAPER_API_URL = "https://api.app.outscraper.com/yellowpages-search"

@mcp.tool()
async def search_yellow_pages(
    query: List[str],
    location: str = "New York, NY",
    limit: int = 500,
    region: Optional[str] = None,
    enrichment: Optional[List[str]] = None,
    fields: Optional[str] = None,
    outscraper_api_key: Optional[str] = None,
) -> str:
    """
    Search Yellow Pages via Outscraper.
    
    Args:
        query: Categories to search for (e.g., ["bars", "restaurants"]). Supports up to 1000 categories.
        location: The parameter specifies where to search.
        limit: The limit of items to get from one query.
        region: The country to use for website (e.g., US, UK, CA).
        enrichment: Data enrichments to apply (e.g., ["contacts_n_leads", "company_websites_finder"]). 
                   Note applying enrichments will increase response time.
        fields: Which fields to include with each item. E.g. "name,phone,website"
        outscraper_api_key: The API key for Outscraper. If not provided here, it will look for the OUTSCRAPER_API_KEY environment variable.
    """
    api_key = outscraper_api_key or os.environ.get("OUTSCRAPER_API_KEY")
    if not api_key:
        return "Error: Outscraper API key is required. Please provide it via the 'outscraper_api_key' parameter or 'OUTSCRAPER_API_KEY' environment variable."

    params = []
    
    # Add queries (multiple query parameters with the same name 'query')
    for q in query:
        params.append(("query", q))
        
    params.append(("location", location))
    params.append(("limit", str(limit)))
    
    # We enforce sync behavior because MCP tools should return data back directly 
    # (unless the client explicitly handles async Task IDs).
    params.append(("async", "false"))
    
    if region:
        params.append(("region", region))
        
    if enrichment:
        for e in enrichment:
            params.append(("enrichment", e))
            
    if fields:
        params.append(("fields", fields))

    headers = {
        "X-API-KEY": api_key,
        "Accept": "application/json"
    }

    try:
        # Given Outscraper's async results limit when sync is forced, we use a generous timeout
        async with httpx.AsyncClient(timeout=180.0) as client:
            response = await client.get(
                OUTSCRAPER_API_URL,
                params=params,
                headers=headers
            )
            response.raise_for_status()
            data = response.json()
            
            # The API usually wraps the results in a 'data' array. We can format it nicely
            import json
            return json.dumps(data, indent=2, ensure_ascii=False)
            
    except httpx.HTTPStatusError as e:
        error_msg = f"HTTP Error {e.response.status_code}: {e.response.text}"
        return f"Error executing Yellow Pages search: {error_msg}"
    except Exception as e:
        return f"Error executing Yellow Pages search: {str(e)}"
        
    return "Error: Unexpected execution path."

EMAILS_AND_CONTACTS_URL = "https://api.app.outscraper.com/emails-and-contacts"

@mcp.tool()
async def find_emails_and_contacts(
    query: List[str],
    preferredContacts: Optional[List[str]] = None,
    contactsPerCompany: int = 3,
    emailsPerContact: int = 1,
    skipContacts: int = 0,
    generalEmails: Optional[bool] = None,
    fields: Optional[str] = None,
    outscraper_api_key: Optional[str] = None,
) -> str:
    """
    Finds emails, social links, phones, and other contacts from websites.
    
    Args:
        query: Domains or links (e.g., ["outscraper.com"]).
        preferredContacts: Preferred contacts (e.g., ["decision makers", "technical", "sales"]).
        contactsPerCompany: The number of Contacts per one company.
        emailsPerContact: The number of email addresses per one contact.
        skipContacts: Number of contacts to skip.
        generalEmails: whether to include only general email (info@, support@) or personal.
        fields: Which fields to include with each item. E.g. "query,name".
        outscraper_api_key: The API key for Outscraper.
    """
    api_key = outscraper_api_key or os.environ.get("OUTSCRAPER_API_KEY")
    if not api_key:
        return "Error: Outscraper API key is required. Please provide it via the 'outscraper_api_key' parameter or 'OUTSCRAPER_API_KEY' environment variable."

    params = []
    
    for q in query:
        params.append(("query", q))
        
    if preferredContacts:
        for p in preferredContacts:
            params.append(("preferredContacts", p))
            
    params.append(("contactsPerCompany", str(contactsPerCompany)))
    params.append(("emailsPerContact", str(emailsPerContact)))
    params.append(("skipContacts", str(skipContacts)))
    
    # We enforce sync behavior for MCP
    params.append(("async", "false"))
    
    if generalEmails is not None:
        params.append(("generalEmails", "true" if generalEmails else "false"))
        
    if fields:
        params.append(("fields", fields))

    headers = {
        "X-API-KEY": api_key,
        "Accept": "application/json"
    }

    try:
        async with httpx.AsyncClient(timeout=180.0) as client:
            response = await client.get(
                EMAILS_AND_CONTACTS_URL,
                params=params,
                headers=headers
            )
            response.raise_for_status()
            data = response.json()
            
            import json
            return json.dumps(data, indent=2, ensure_ascii=False)
            
    except httpx.HTTPStatusError as e:
        error_msg = f"HTTP Error {e.response.status_code}: {e.response.text}"
        return f"Error executing emails and contacts search: {error_msg}"
    except Exception as e:
        return f"Error executing emails and contacts search: {str(e)}"
        
    return "Error: Unexpected execution path."

@mcp.tool()
def send_email(receiver_email: str, subject: str, content: str) -> str:
    """
    Send an email. Configuration is loaded from environment variables (SMTP_SERVER, SMTP_PORT, SMTP_SENDER_EMAIL, SMTP_AUTH_CODE).
    
    Args:
        receiver_email: The exact email address of the recipient to send the message to.
        subject: The subject or title of the email.
        content: The plain text content or body of the email.
    """
    smtp_server = os.environ.get("SMTP_SERVER", "smtp.qq.com")
    port_str = os.environ.get("SMTP_PORT", "465")
    try:
        smtp_port = int(port_str)
    except ValueError:
        smtp_port = 465
        
    sender_email = os.environ.get("SMTP_SENDER_EMAIL")
    auth_code = os.environ.get("SMTP_AUTH_CODE")

    if not sender_email or not auth_code:
        return "Error: SMTP_SENDER_EMAIL and SMTP_AUTH_CODE environment variables must be configured."

    message = MIMEText(content, "plain", "utf-8")
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = Header(subject, "utf-8")

    try:
        if smtp_port == 465:
            server = smtplib.SMTP_SSL(smtp_server, smtp_port)
        else:
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            
        server.login(sender_email, auth_code)
        server.sendmail(sender_email, receiver_email, message.as_string())
        return f"✅ 邮件已成功发送至 {receiver_email}！"
    except Exception as e:
        return f"❌ 邮件发送失败: {str(e)}"
    finally:
        try:
            server.quit()
        except:
            pass

def main():
    """Main entry point for running the server."""
    mcp.run()

if __name__ == "__main__":
    main()
