import outscraper
import inspect
from outscraper import ApiClient

print(dir(outscraper))
print(dir(ApiClient))

import inspect
print(inspect.signature(ApiClient.yellow_pages_search))
