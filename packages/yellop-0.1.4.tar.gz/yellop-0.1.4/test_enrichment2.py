import httpx
import asyncio
import sys

async def main():
    enrichment = ["contacts_n_leads"]
    params = [("query", "bars"), ("location", "NY"), ("async", "false"), ("limit", "1")]
    for e in enrichment:
        params.append(("enrichment", e))
    
    url = "https://api.app.outscraper.com/yellowpages-search"
    api_key = sys.argv[1]
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            print("Sending request to Outscraper API...")
            response = await client.get(url, params=params, headers={"X-API-KEY": api_key})
            print(f"Status: {response.status_code}")
            print(f"Response: {response.text}")
    except Exception as e:
        print(f"Error: {e}")

asyncio.run(main())
