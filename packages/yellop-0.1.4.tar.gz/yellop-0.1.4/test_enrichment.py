import httpx
import asyncio

async def main():
    enrichment = ["contacts_n_leads"]
    params = [("query", "bars"), ("location", "NY"), ("async", "false")]
    for e in enrichment:
        params.append(("enrichment", e))
    
    print(params)
    
    url = "https://api.app.outscraper.com/yellowpages-search"
    async with httpx.AsyncClient() as client:
        # We don't have an API key, so if the URL is correct we should get 401. 
        # If the URL is wrong we will get 404.
        response = await client.get(url, params=params, headers={"X-API-KEY": "fake"})
        print(response.status_code, response.text)

asyncio.run(main())
