import httpx
import asyncio

async def main():
    url = "https://api.app.outscraper.com/yellowpages-search"
    api_key = "NGRmNjk3MjdkYjFhNDBiMjg5MGM5NzgyZTJlZGVlMGR8ZTUwOTI5NTQ1Nw"
    params = [("query", "restaurants"), ("location", "NY"), ("async", "false"), ("limit", "1"), ("enrichment", "contacts_n_leads")]
    
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            print(f"Requesting {params}...")
            response = await client.get(url, params=params, headers={"X-API-KEY": api_key})
            print(f"Status: {response.status_code}")
            try:
                print(f"JSON: {response.json()}")
            except:
                print(f"Text: {response.text}")
    except Exception as e:
        print(f"Error: {e}")

asyncio.run(main())
