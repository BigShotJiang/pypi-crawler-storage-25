"""v0.8.0 Task 26: score_result view migrated to atoms + i18n."""
from unittest.mock import MagicMock

import pytest

from polily.core.db import PolilyDB
from polily.core.event_store import EventRow, upsert_event
from polily.core.events import EventBus
from polily.tui.service import PolilyService


@pytest.fixture
def svc(tmp_path):
    cfg = MagicMock()
    cfg.tui.heartbeat_seconds = 5.0  # Phase 0 Task 14: real float for Textual timer
    cfg.wallet.starting_balance = 100.0
    db = PolilyDB(tmp_path / "s.db")
    upsert_event(
        EventRow(event_id="ev1", title="Test Event", updated_at="now"),
        db,
    )
    yield PolilyService(config=cfg, db=db, event_bus=EventBus())
    db.close()


async def test_score_result_uses_polily_zone(svc):
    from polily.tui.app import PolilyApp
    from polily.tui.views.score_result import ScoreResultView
    from polily.tui.widgets.polily_zone import PolilyZone

    app = PolilyApp(service=svc)
    app._restart_daemon = lambda: None
    async with app.run_test() as pilot:
        await pilot.pause()
        view = ScoreResultView(event_id="ev1", service=svc)
        await app.mount(view)
        await pilot.pause()
        zones = list(view.query(PolilyZone))
        assert len(zones) >= 1, (
            f"expected at least 1 PolilyZone, found {len(zones)}"
        )


async def test_score_result_chinese_labels(svc):
    from textual.widgets import Static

    from polily.tui.app import PolilyApp
    from polily.tui.views.score_result import ScoreResultView

    app = PolilyApp(service=svc)
    app._restart_daemon = lambda: None
    async with app.run_test() as pilot:
        await pilot.pause()
        view = ScoreResultView(event_id="ev1", service=svc)
        await app.mount(view)
        await pilot.pause()
        texts = []
        for s in view.query(Static):
            val = getattr(s, "renderable", None) or getattr(s, "content", None)
            if val:
                texts.append(str(val))
        joined = " ".join(texts)
        found = any(
            lbl in joined
            for lbl in ("评分", "结构", "市场", "事件", "流动性", "深度")
        )
        assert found, f"no expected Chinese label. Sample: {joined[:200]}"


async def test_score_result_preserves_existing_bindings(svc):
    """Q1 regression: escape/backspace must still work for go-back."""
    from polily.tui.views.score_result import ScoreResultView

    keys = {b.key for b in ScoreResultView.BINDINGS}
    for k in ("escape", "backspace"):
        assert k in keys, f"binding '{k}' missing: {keys}"


async def test_score_result_vertical_scroll_bounded(svc):
    """Regression: scroll must be height-bounded so action bar stays visible."""
    from textual.containers import VerticalScroll

    from polily.tui.app import PolilyApp
    from polily.tui.views.score_result import ScoreResultView

    app = PolilyApp(service=svc)
    app._restart_daemon = lambda: None
    async with app.run_test(size=(120, 40)) as pilot:
        await pilot.pause()
        view = ScoreResultView(event_id="ev1", service=svc)
        await app.mount(view)
        await pilot.pause()
        scrolls = list(view.query(VerticalScroll))
        assert len(scrolls) >= 1, "ScoreResultView must contain a VerticalScroll"
        scroll_height = scrolls[0].size.height
        app_height = app.size.height
        assert scroll_height <= app_height, (
            f"VerticalScroll height ({scroll_height}) exceeds app "
            f"height ({app_height}); zones are overflowing"
        )


def test_score_result_banner_active_returns_none():
    from datetime import UTC, datetime, timedelta
    from unittest.mock import MagicMock

    from polily.tui.views.score_result import _banner_for_event_state
    now = datetime(2026, 4, 22, 12, 0, tzinfo=UTC)
    future = (now + timedelta(days=7)).isoformat()
    event = MagicMock()
    event.closed = 0
    m = MagicMock()
    m.closed = 0
    m.end_date = future
    m.resolved_outcome = None
    assert _banner_for_event_state(event, [m], now=now) is None


def test_score_result_banner_awaiting_full_settlement():
    from datetime import UTC, datetime, timedelta
    from unittest.mock import MagicMock

    from polily.tui.views.score_result import _banner_for_event_state
    now = datetime(2026, 4, 22, 12, 0, tzinfo=UTC)
    past = (now - timedelta(hours=1)).isoformat()
    event = MagicMock()
    event.closed = 0
    m = MagicMock()
    m.closed = 0
    m.end_date = past
    m.resolved_outcome = None
    assert _banner_for_event_state(event, [m], now=now) == "待全部结算"


def test_score_result_banner_resolved():
    from unittest.mock import MagicMock

    from polily.tui.views.score_result import _banner_for_event_state
    event = MagicMock()
    event.closed = 1
    assert _banner_for_event_state(event, []) == "已结算"
