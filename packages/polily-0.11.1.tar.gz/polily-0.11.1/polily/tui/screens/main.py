"""MainScreen: Sidebar navigation + Content area with view switching.

v0.8.0 Task 32 migration:
- Sidebar menu items now carry Nerd Font glyphs (via
  `polily.tui.widgets.sidebar.MENU_ICONS`) — no colour / layout change.
- MainScreen subscribes to `TOPIC_SCAN_UPDATED` so the status bar reflects
  background scan progress without polling (bus callback hops through
  `call_from_thread` because scans publish from worker / daemon threads).
- Global bindings (`q`, `?`, `escape`) intentionally live on the App
  (see `polily.tui.bindings.GLOBAL_BINDINGS` + `PolilyApp.BINDINGS`).
  MainScreen only declares screen-local bindings (digit menu jumps,
  `r` refresh, up/down nav).
"""


import contextlib

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Footer, Header, Static

from polily.core.events import (
    TOPIC_HEARTBEAT,
    TOPIC_MONITOR_UPDATED,
    TOPIC_POSITION_UPDATED,
    TOPIC_PRICE_UPDATED,
    TOPIC_SCAN_UPDATED,
    TOPIC_WALLET_UPDATED,
)
from polily.tui._dispatch import dispatch_to_ui
from polily.tui.service import AnalysisInProgressError, PolilyService
from polily.tui.views.archived_events import ArchivedEventsView, ViewArchivedDetail
from polily.tui.views.event_detail import (
    AnalyzeRequested,
    BackToList,
    CancelAnalysisRequested,
    EventDetailView,
    RescoreEventRequested,
    SwitchVersionRequested,
)
from polily.tui.views.monitor_list import MonitorListView, ViewMonitorDetail
from polily.tui.views.paper_status import PaperStatusView, ViewTradeDetail
from polily.tui.views.scan_log import (
    AddEventRequested,
    BackToScanLog,
    CancelScanRequested,
    OpenEventFromLog,
    OpenEventScoreResult,
    RescoreRequested,
    ScanLogDetailView,
    ScanLogView,
    StepInfo,
    ViewScanLogDetail,
)
from polily.tui.views.score_result import (
    AddToMonitorRequested,
    BackToTasks,
    ScoreResultView,
    ScoreViewRescore,
)
from polily.tui.widgets.sidebar import MenuSelected, Sidebar


class MainScreen(Screen):
    """Main screen with sidebar navigation and content area."""

    BINDINGS = [
        Binding("0", "show_tasks", show=False),
        Binding("1", "show_monitor", show=False),
        Binding("2", "show_paper", show=False),
        Binding("3", "show_wallet", show=False),
        Binding("4", "show_history", show=False),
        Binding("5", "show_archive", show=False),
        Binding("6", "show_config", show=False),
        Binding("7", "show_changelog", show=False),
        Binding("up", "menu_prev", show=False),
        Binding("down", "menu_next", show=False),
    ]

    DEFAULT_CSS = """
    MainScreen {
        background: $surface;
    }
    MainScreen #status-bar {
        background: $panel;
        color: $text-muted;
        padding: 0 1;
        height: 1;
    }
    """

    MENU_ORDER = ["tasks", "monitor", "paper", "wallet", "history",
                  "archive", "config", "changelog"]

    def __init__(self, service: PolilyService):
        super().__init__()
        self.service = service
        self._loading = False
        self._current_menu = "tasks"
        self._analyzing_event_id: str | None = None
        self._analyzing = False

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static("就绪", id="status-bar")
        with Horizontal(id="main-container"):
            yield Sidebar(id="sidebar")
            with Vertical(id="content-area"):
                yield ScanLogView(self.service)
        yield Footer()

    def on_mount(self) -> None:
        sidebar = self.query_one("#sidebar", Sidebar)
        sidebar.set_active_menu("tasks")
        monitor = self.service.get_monitor_count()
        paper = len(self.service.get_open_trades())
        archive_count = len(self.service.get_archived_events())
        history = self.service.get_history_count()
        sidebar.update_counts(monitor, paper, archive_count, history)
        # Poll heartbeat: check every 5s
        self.set_interval(5, self._check_poll_heartbeat)
        self._check_poll_heartbeat()
        # Bus heartbeat: the EventBus is process-local, but the daemon
        # runs in a SEPARATE process and writes prices / positions /
        # scan_logs / monitor flags to SQLite on its own cadence. Without
        # this heartbeat the TUI would never hear the daemon's changes
        # (the daemon's bus publishes fall on deaf ears). Every few
        # seconds we re-fire all the topics views subscribe to, so each
        # view re-reads DB and picks up cross-process writes. Payloads
        # omit `event_id` / `status` so per-event filters treat them as
        # match-all (see EventDetailView._on_price_update,
        # MainScreen._on_scan_updated).
        # Heartbeat cadence: matches daemon poll_job interval — no point going
        # faster, the daemon only writes new prices every 30s. But spacing
        # it 5s makes the TUI feel responsive when the user DID change
        # something and a bus event is imminent. Configurable via tui.heartbeat_seconds.
        self.set_interval(self.service.config.tui.heartbeat_seconds, self._bus_heartbeat)
        # Scan lifecycle updates (running / completed / failed) publish
        # to the event bus from worker threads; reflect them in the
        # status bar + tasks sidebar pill without manual polling.
        bus = getattr(self.service, "event_bus", None)
        if bus is not None:
            bus.subscribe(TOPIC_SCAN_UPDATED, self._on_scan_updated)
            bus.subscribe(TOPIC_POSITION_UPDATED, self._on_position_or_wallet_update)
            bus.subscribe(TOPIC_WALLET_UPDATED, self._on_position_or_wallet_update)

    def on_unmount(self) -> None:
        bus = getattr(self.service, "event_bus", None)
        if bus is not None:
            with contextlib.suppress(Exception):
                bus.unsubscribe(TOPIC_SCAN_UPDATED, self._on_scan_updated)
            with contextlib.suppress(Exception):
                bus.unsubscribe(TOPIC_POSITION_UPDATED, self._on_position_or_wallet_update)
            with contextlib.suppress(Exception):
                bus.unsubscribe(TOPIC_WALLET_UPDATED, self._on_position_or_wallet_update)

    def _on_scan_updated(self, payload: dict) -> None:
        """Bus callback: runs on publisher thread — must hop to UI thread.

        Payload shape (per polily.core.events): {scan_id, event_id, status}.
        We mark the 'tasks' sidebar pill 'has new data' on terminal status
        transitions (completed/failed) so the user sees the pill without
        navigating there first.
        """
        status = (payload or {}).get("status") or ""
        if status not in ("completed", "failed"):
            return
        with contextlib.suppress(Exception):
            dispatch_to_ui(self.app, self._mark_tasks_has_new)

    def _mark_tasks_has_new(self) -> None:
        if self._current_menu == "tasks":
            return  # user's already looking at it — no pill needed
        with contextlib.suppress(Exception):
            self.query_one("#sidebar", Sidebar).mark_new_data("tasks")

    def _on_position_or_wallet_update(self, payload: dict) -> None:
        """Bus callback: refresh sidebar counts when positions or wallet state
        changes. Bridges daemon-side auto-resolution (ResolutionHandler writes
        positions/wallet_transactions but doesn't publish on TUI's bus — the
        5s heartbeat republishes for us) and user-side trade/reset paths.

        Uses dispatch_to_ui to hop to the UI thread safely.
        """
        with contextlib.suppress(Exception):
            dispatch_to_ui(self.app, self.refresh_sidebar_counts)

    def _bus_heartbeat(self) -> None:
        """Bridge cross-process daemon writes to TUI views via bus fan-out.

        The bus is in-memory per-process; daemon publishes to its own bus
        and the TUI never hears. This re-publishes match-all heartbeats
        on the TUI's bus so each subscribing view calls its own
        `_render_all` path, re-reading whatever the daemon just wrote to
        SQLite. Rendering with unchanged data is idempotent and cheap.
        """
        bus = getattr(self.service, "event_bus", None)
        if bus is None:
            return
        payload = {"source": "heartbeat"}
        for topic in (
            TOPIC_PRICE_UPDATED,
            TOPIC_POSITION_UPDATED,
            TOPIC_WALLET_UPDATED,
            TOPIC_MONITOR_UPDATED,
            TOPIC_SCAN_UPDATED,
            TOPIC_HEARTBEAT,  # SF10 — pure heartbeat for views needing timer refresh
        ):
            with contextlib.suppress(Exception):
                bus.publish(topic, payload)

    def _check_poll_heartbeat(self) -> None:
        """Check if poll daemon process is alive via PID file.

        Only updates the `● POLL` sidebar indicator. View refresh is
        handled by `_bus_heartbeat` on the same cadence — keeping the
        two concerns separated (PID liveness vs. DB re-read) avoids the
        earlier inconsistency where half the views silently missed the
        poll-heartbeat refresh because they didn't define `refresh_data`.
        """
        try:
            alive = self._is_daemon_alive()
            self.query_one("#sidebar", Sidebar).set_poll_status(alive)
        except Exception:
            import logging
            logging.getLogger(__name__).debug("heartbeat error", exc_info=True)

    @staticmethod
    def _is_daemon_alive() -> bool:
        """Check if the scheduler daemon is running via launchctl.

        v0.9.0: was reading `data/scheduler.pid`; now goes through
        `launchctl_query.is_daemon_running()` so launchctl's view of the
        world (crash-loop, stale registration, etc.) is the source of
        truth.
        """
        from polily.daemon.launchctl_query import is_daemon_running
        return is_daemon_running()


    def _update_progress(self, steps: list[StepInfo]):
        """Main thread: update live progress if ScanLogView is visible."""
        try:
            log_view = self.query_one("#content-area").query_one(ScanLogView)
            log_view.update_live_progress(steps)
        except Exception:
            pass
        if steps:
            latest = steps[-1]
            if latest.status == "running":
                self.query_one("#status-bar", Static).update(f"{latest.name}...")

    # --- Add event by URL ---

    def on_add_event_requested(self, message: AddEventRequested) -> None:
        if self._loading:
            return
        self._loading = True
        self._add_url = message.url
        self.query_one("#status-bar", Static).update("获取事件...")
        if self._current_menu == "tasks":
            self._navigate_to("tasks")
        self.run_worker(self._do_add_event, name="add_event", thread=True, exclusive=True)

    async def _do_add_event(self):
        self.service.on_progress = lambda steps: self.app.call_from_thread(
            self._update_progress, steps
        )
        try:
            result = await self.service.add_event_by_url(self._add_url)
        except Exception as e:
            self.app.call_from_thread(self._on_add_failed, str(e))
            return
        if result is None:
            self.app.call_from_thread(self._on_add_failed, "事件未找到或链接无效")
            return
        self.app.call_from_thread(self._on_add_complete, result)

    def _on_add_complete(self, result):
        self._loading = False
        event = result["event"]
        score = result["event_score"].total
        self.query_one("#status-bar", Static).update(
            f"评分完成: {event.title[:30]} ({score:.0f}分)"
        )
        self._switch_view(
            ScoreResultView(event_id=event.event_id, service=self.service)
        )
        self.refresh_sidebar_counts()

    def _on_add_failed(self, error: str):
        self._loading = False
        self.query_one("#status-bar", Static).update(f"添加失败: {error[:60]}")
        if self._current_menu == "tasks":
            self._navigate_to("tasks")

    def _switch_view(self, view, menu_id: str = ""):
        content = self.query_one("#content-area")
        for child in list(content.children):
            child.remove()
        content.mount(view)
        self.set_timer(0.1, lambda: self._focus_table(view))
        if menu_id:
            sidebar = self.query_one("#sidebar", Sidebar)
            sidebar.set_active_menu(menu_id)
            sidebar.clear_new_data(menu_id)

    def _focus_table(self, view):
        try:
            from textual.widgets import DataTable
            table = view.query_one(DataTable)
            table.focus()
        except Exception:
            try:
                from textual.containers import VerticalScroll
                scroll = view.query_one(VerticalScroll)
                scroll.focus()
            except Exception:
                view.focus()

    def refresh_sidebar_counts(self):
        monitor = self.service.get_monitor_count()
        paper = len(self.service.get_open_trades())
        archive_count = len(self.service.get_archived_events())
        history = self.service.get_history_count()
        self.query_one("#sidebar", Sidebar).update_counts(monitor, paper, archive_count, history)

    # --- Message handlers ---

    def on_menu_selected(self, message: MenuSelected) -> None:
        self._navigate_to(message.menu_id)

    def on_switch_version_requested(self, message: SwitchVersionRequested) -> None:
        is_analyzing = self._analyzing and self._analyzing_event_id == message.event_id
        self._switch_view(EventDetailView(
            event_id=message.event_id,
            service=self.service,
            analyzing=is_analyzing,
            version_idx=message.version_idx,
        ))

    def on_view_scan_log_detail(self, message: ViewScanLogDetail) -> None:
        self._switch_view(ScanLogDetailView(message.log_entry, db=self.service.db))

    def on_analyze_requested(self, message: AnalyzeRequested) -> None:
        self._analyzing_event_id = message.event_id
        self._analyzing = True
        # Get event title for status bar
        detail = self.service.get_event_detail(message.event_id)
        title_short = (detail["event"].title[:30] if detail else message.event_id[:30])
        self.query_one("#status-bar", Static).update(f"AI 分析中: {title_short}...")
        self._switch_view(EventDetailView(
            event_id=message.event_id, service=self.service, analyzing=True,
        ))
        self.run_worker(self._do_analyze, name="analyze", thread=True, exclusive=True)

    def _cancel_analysis(self):
        """Cancel the running AI analysis — triggered by Esc during analysis."""
        if not self._analyzing:
            return
        self._analyzing = False
        self.service.cancel_analysis()
        self.query_one("#status-bar", Static).update("分析已取消")
        if self._analyzing_event_id:
            self._switch_view(EventDetailView(
                event_id=self._analyzing_event_id, service=self.service,
            ))
            self._analyzing_event_id = None

    async def _do_analyze(self):
        import os
        os.environ["POLILY_TUI"] = "1"
        try:
            event_id = self._analyzing_event_id
            self.service.on_progress = lambda steps: self.app.call_from_thread(
                self._update_progress, steps
            )

            def _heartbeat(elapsed: float, status: str):
                self.app.call_from_thread(self._update_heartbeat, elapsed, status)

            # v0.7.0: PolilyService.analyze_event owns the full scan_logs
            # lifecycle (running → completed/failed). We don't write a
            # separate scan_log row here any more.
            await self.service.analyze_event(
                event_id,
                on_heartbeat=_heartbeat,
            )
            self.app.call_from_thread(self._on_analysis_complete, event_id)
        except AnalysisInProgressError as e:
            # Invariant guard hit — another analysis is already running
            # for this event. Surface a friendly notify, not an error modal.
            self.app.call_from_thread(self._on_analysis_failed, str(e))
        except Exception as e:
            error_msg = str(e)
            if "cancelled" in error_msg.lower():
                return  # already handled by _cancel_analysis
            self.app.call_from_thread(self._on_analysis_failed, error_msg)
        finally:
            os.environ.pop("POLILY_TUI", None)
            self._analyzing = False

    def _update_heartbeat(self, elapsed: float, status: str):
        """Update status bar with heartbeat info during AI analysis."""
        title = (self._analyzing_event_id or "")[:25]
        mins = int(elapsed) // 60
        secs = int(elapsed) % 60
        time_str = f"{mins}:{secs:02d}" if mins else f"{secs}s"

        if status == "unresponsive":
            self.query_one("#status-bar", Static).update(
                f"[red]AI 可能遇到问题 ({time_str})[/red] {title} [dim]Esc 取消[/dim]"
            )
        elif status == "long":
            self.query_one("#status-bar", Static).update(
                f"AI 深度分析中，请耐心等待 ({time_str}) {title} [dim]Esc 取消[/dim]"
            )
        elif status == "searching":
            self.query_one("#status-bar", Static).update(
                f"AI 正在搜索分析中 ({time_str}) {title} [dim]Esc 取消[/dim]"
            )
        else:
            self.query_one("#status-bar", Static).update(
                f"AI 分析中 ({time_str}) {title} [dim]Esc 取消[/dim]"
            )

    def _on_analysis_complete(self, event_id: str):
        self.query_one("#status-bar", Static).update("分析完成")
        self.query_one("#sidebar", Sidebar).mark_new_data("tasks")
        self._switch_view(EventDetailView(event_id=event_id, service=self.service))

    def _on_analysis_failed(self, error: str):
        error_short = error[:80] if len(error) > 80 else error
        self.query_one("#status-bar", Static).update(f"分析失败: {error_short}")
        if self._analyzing_event_id:
            self._switch_view(EventDetailView(
                event_id=self._analyzing_event_id, service=self.service,
            ))

    def on_cancel_analysis_requested(self, message: CancelAnalysisRequested) -> None:
        self._cancel_analysis()

    def on_cancel_scan_requested(self, message: CancelScanRequested) -> None:
        """Cancel a running scan from the 待办 zone."""
        ok = self.service.cancel_running_scan(message.scan_id)
        if ok:
            self.notify("已取消分析")
        else:
            self.notify("无法取消——该行不在 running 状态", severity="warning")
        # Re-render the scan log view so the row flips to cancelled
        if self._current_menu == "tasks":
            self._navigate_to("tasks")

    def on_open_event_from_log(self, message: OpenEventFromLog) -> None:
        """Navigate to EventDetailView from a log context.

        Triggered by Enter in ScanLogDetailView (分析详情) and
        ScoreResultView (评分结果). Both second-level detail pages hand
        off here to show the full event.
        """
        self._switch_view(
            EventDetailView(event_id=message.event_id, service=self.service)
        )

    def on_open_event_score_result(self, message: OpenEventScoreResult) -> None:
        """Navigate directly to ScoreResultView (评分结果) from an
        add_event scan_log row — shortcut for the scoring workflow."""
        self._switch_view(
            ScoreResultView(event_id=message.event_id, service=self.service)
        )

    def on_rescore_requested(self, message: RescoreRequested) -> None:
        """Re-score an event by its event_id (looks up slug from DB)."""
        from polily.core.event_store import get_event
        event = get_event(message.event_id, self.service.db)
        if event and event.slug:
            url = f"https://polymarket.com/event/{event.slug}"
            self.on_add_event_requested(AddEventRequested(url))

    def on_rescore_event_requested(self, message: RescoreEventRequested) -> None:
        """Re-score event from EventDetailView button."""
        self._rescore_by_event_id(message.event_id)

    def on_score_view_rescore(self, message: ScoreViewRescore) -> None:
        """Re-score event from ScoreResultView button."""
        self._rescore_by_event_id(message.event_id)

    def on_add_to_monitor_requested(self, message: AddToMonitorRequested) -> None:
        """Add event to monitoring from ScoreResultView."""
        self.service.toggle_monitor(message.event_id, enable=True)
        self.refresh_sidebar_counts()
        self._ensure_daemon()
        self._navigate_to("monitor")

    def _ensure_daemon(self) -> None:
        """Auto-start daemon if not running."""
        try:
            from polily.daemon.scheduler import ensure_daemon_running
            if ensure_daemon_running():
                self.notify("后台监控已自动启动")
        except Exception:
            pass

    def on_back_to_tasks(self, message: BackToTasks) -> None:
        self._navigate_to("tasks")

    def _rescore_by_event_id(self, event_id: str) -> None:
        from polily.core.event_store import get_event
        event = get_event(event_id, self.service.db)
        if event and event.slug:
            url = f"https://polymarket.com/event/{event.slug}"
            self.on_add_event_requested(AddEventRequested(url))

    def on_view_monitor_detail(self, message: ViewMonitorDetail) -> None:
        """Navigate to event detail from monitor list."""
        self._switch_view(
            EventDetailView(event_id=message.event_id, service=self.service)
        )

    def on_view_archived_detail(self, message: ViewArchivedDetail) -> None:
        """Row-click in ArchivedEventsView → push EventDetailView for retrospective view."""
        self._switch_view(
            EventDetailView(event_id=message.event_id, service=self.service)
        )

    def on_view_trade_detail(self, message: ViewTradeDetail) -> None:
        """Navigate to event detail from portfolio."""
        self._switch_view(
            EventDetailView(event_id=message.event_id, service=self.service)
        )

    def on_back_to_scan_log(self, message: BackToScanLog) -> None:
        self._navigate_to("tasks")

    def on_back_to_list(self, message: BackToList) -> None:
        self._navigate_to(self._current_menu)

    def _navigate_to(self, menu_id: str):
        if menu_id == "tasks":
            self._switch_view(ScanLogView(self.service), "tasks")
        elif menu_id == "monitor":
            self._switch_view(MonitorListView(service=self.service), "monitor")
        elif menu_id == "paper":
            self._switch_view(PaperStatusView(self.service), "paper")
        elif menu_id == "wallet":
            from polily.tui.views.wallet import WalletView
            self._switch_view(WalletView(self.service), "wallet")
        elif menu_id == "history":
            from polily.tui.views.history import HistoryView
            self._switch_view(HistoryView(self.service), "history")
        elif menu_id == "archive":
            self._switch_view(ArchivedEventsView(self.service), "archive")
        elif menu_id == "config":
            from polily.tui.views.config import ConfigView
            self._switch_view(ConfigView(self.service), "config")
        elif menu_id == "changelog":
            from polily.tui.views.changelog import ChangelogView
            self._switch_view(ChangelogView(), "changelog")
        self._current_menu = menu_id

    def action_show_tasks(self) -> None:
        self._navigate_to("tasks")

    def action_show_monitor(self) -> None:
        self._navigate_to("monitor")

    def action_show_paper(self) -> None:
        self._navigate_to("paper")

    def action_show_wallet(self) -> None:
        self._navigate_to("wallet")

    def action_show_history(self) -> None:
        self._navigate_to("history")

    def action_show_archive(self) -> None:
        self._navigate_to("archive")

    def action_show_config(self) -> None:
        self._navigate_to("config")

    def action_show_changelog(self) -> None:
        self._navigate_to("changelog")

    def action_menu_prev(self) -> None:
        idx = self.MENU_ORDER.index(self._current_menu) if self._current_menu in self.MENU_ORDER else 0
        idx = (idx - 1) % len(self.MENU_ORDER)
        self._navigate_to(self.MENU_ORDER[idx])

    def action_menu_next(self) -> None:
        idx = self.MENU_ORDER.index(self._current_menu) if self._current_menu in self.MENU_ORDER else 0
        idx = (idx + 1) % len(self.MENU_ORDER)
        self._navigate_to(self.MENU_ORDER[idx])
