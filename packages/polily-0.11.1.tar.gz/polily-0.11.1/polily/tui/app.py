"""Polily TUI — interactive terminal interface (Textual)."""

from textual.app import App

from polily.tui.bindings import GLOBAL_BINDINGS
from polily.tui.screens.main import MainScreen
from polily.tui.service import PolilyService
from polily.tui.theme import register_polily_theme


class PolilyApp(App):
    """Polily — A Polymarket Monitoring Agent That Actually Works (interactive TUI)."""

    TITLE = "Polily"
    SUB_TITLE = "A Polymarket Monitoring Agent That Actually Works"
    CSS_PATH = ["css/tokens.tcss", "css/app.tcss"]

    BINDINGS = GLOBAL_BINDINGS

    def __init__(self, service: PolilyService | None = None):
        super().__init__()
        self.service = service or PolilyService()

    def on_mount(self) -> None:
        register_polily_theme(self)  # NEW: register brand theme
        self._restart_daemon()
        self.push_screen(MainScreen(self.service))

    def _restart_daemon(self) -> None:
        """Restart scheduler daemon on every TUI launch.

        Previously only started the daemon if it wasn't already running. Now
        we always restart (when there are auto-monitored events) so the
        daemon picks up the latest code the user has committed. New daemon
        writes a fresh `data/logs/poll-v<ver>-<ts>.log`; old logs are kept.
        """
        from polily.core.monitor_store import get_active_monitors
        monitors = get_active_monitors(self.service.db)
        if not monitors:
            return
        try:
            from polily.daemon.scheduler import restart_daemon
            if restart_daemon():
                self.notify("后台监控已重启 (已加载最新代码)")
        except Exception:
            pass  # non-fatal — daemon can be started manually

    async def action_quit(self) -> None:
        """Kill everything and exit immediately."""
        self.exit()

    async def action_back(self) -> None:
        """Pop current screen if any; else no-op."""
        if len(self.screen_stack) > 1:
            self.pop_screen()

    async def action_help(self) -> None:
        """Placeholder for help overlay — Phase 3 actual overlay widget.
        For now, notify."""
        self.notify("帮助面板 v0.8.0 后续版本提供", severity="information")


def run_tui(service: PolilyService | None = None) -> None:
    """Entry point for TUI mode.

    If `service` is provided, the TUI uses it directly (avoids double-loading
    config from db when the CLI already built one for the yaml regen hook).
    Otherwise the TUI builds its own PolilyService.

    If service construction fails with ConfigValidationError (db.config has
    invalid values that Pydantic refuses), show FatalConfigScreen instead of
    the normal app — user must run a CLI escape hatch
    (`polily config reset --all` / `polily config reset <key>`) and relaunch.
    Per design §7.3 / Q4.
    """
    if service is None:
        from polily.core.config import ConfigValidationError
        try:
            service = PolilyService()
        except ConfigValidationError as e:
            from polily.tui.views._config_fatal_screen import FatalConfigScreen

            error_message = str(e)

            class _FatalApp(App):
                def on_mount(self) -> None:
                    self.push_screen(FatalConfigScreen(error_message=error_message))

            _FatalApp().run()
            import os

            from polily.tui.terminal_cleanup import cleanup_terminal
            # _FatalApp's driver is already torn down by app.run() returning,
            # so the canonical path is unreachable; cleanup_terminal falls
            # back to writing DECRST sequences directly. See R5-B.
            cleanup_terminal(app=None)
            os._exit(1)

    app = PolilyApp(service=service)
    try:
        app.run()
    finally:
        # Force-kill all child processes and exit immediately.
        # claude CLI (used by AI agents) spawns Node.js subprocesses that
        # survive normal Python shutdown (sys.exit, atexit). os._exit bypasses
        # all cleanup but is the only reliable way to terminate. SQLite writes
        # are committed before reaching this point. See README Limitations.
        # R5-B: cleanup_terminal restores mouse-tracking + alt-screen modes
        # before os._exit so the user's terminal isn't left spewing raw SGR
        # escape sequences. By the time `app.run()` returns, Textual has
        # already torn the driver down, so the fallback path applies.
        import os

        from polily.tui.terminal_cleanup import cleanup_terminal
        cleanup_terminal(app)
        os._exit(0)
