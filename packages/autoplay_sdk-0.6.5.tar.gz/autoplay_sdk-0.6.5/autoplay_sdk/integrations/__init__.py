"""Vendor-specific integration recipes (constants, URL helpers, templates)."""

from autoplay_sdk.integrations.intercom import (
    INTERCOM_WEBHOOK_TOPICS,
    INTERCOM_WEBHOOK_TOPIC_USER_CREATED,
    INTERCOM_WEBHOOK_TOPIC_USER_REPLIED,
    intercom_chatbot_webhook_url,
)

__all__ = [
    "INTERCOM_WEBHOOK_TOPICS",
    "INTERCOM_WEBHOOK_TOPIC_USER_CREATED",
    "INTERCOM_WEBHOOK_TOPIC_USER_REPLIED",
    "intercom_chatbot_webhook_url",
]
