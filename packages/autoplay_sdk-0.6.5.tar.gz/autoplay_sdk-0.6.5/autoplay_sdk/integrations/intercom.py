"""Intercom integration recipe — webhook topics, URL builder, optional reactive snippet.

Use these constants when configuring Intercom Developer Hub so your subscription
matches what :class:`~autoplay_sdk.chatbot.BaseChatbotWriter` subclasses expect.

Session linking is driven by **outbound Intercom webhooks** to
``POST /chatbot-webhook/{product_id}`` (``conversation.user.created``,
``conversation.user.replied``). The optional reactive browser snippet calls
``POST /sessions/link`` only if you still need client-side linking.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Webhook topics (must stay aligned with IntercomChatbot parsing)
# ---------------------------------------------------------------------------

INTERCOM_WEBHOOK_TOPIC_USER_CREATED = "conversation.user.created"
INTERCOM_WEBHOOK_TOPIC_USER_REPLIED = "conversation.user.replied"

INTERCOM_WEBHOOK_TOPICS: tuple[str, ...] = (
    INTERCOM_WEBHOOK_TOPIC_USER_CREATED,
    INTERCOM_WEBHOOK_TOPIC_USER_REPLIED,
)


def intercom_chatbot_webhook_url(connector_host: str, product_id: str) -> str:
    """Build ``POST /chatbot-webhook/{product_id}`` URL for Intercom outbound webhooks.

    Args:
        connector_host: Connector hostname (``event-connector-xxxx.onrender.com``) or
            full origin (``https://event-connector-xxxx.onrender.com``). A trailing
            slash is stripped.
        product_id: Autoplay product id (path segment, no slashes).

    Returns:
        Absolute HTTPS URL with no trailing slash before ``/chatbot-webhook/``.
    """
    host = connector_host.strip().rstrip("/")
    if not host:
        raise ValueError("connector_host must be non-empty")
    if not product_id or "/" in product_id:
        raise ValueError("product_id must be non-empty and must not contain '/'")
    if host.startswith("http://") or host.startswith("https://"):
        base = host
    else:
        base = f"https://{host}"
    return f"{base}/chatbot-webhook/{product_id}"


# ---------------------------------------------------------------------------
# Optional: browser-assisted snippet (``POST /sessions/link``)
# ---------------------------------------------------------------------------

_REACTIVE_FETCH_PATH = "/sessions/link"

REACTIVE_SESSION_LINK_SCRIPT_TEMPLATE = """\
<script>
window.Intercom("onConversationStarted", function (data) {{
  var sessionId = typeof posthog !== "undefined" ? posthog.get_session_id() : null;
  if (!sessionId || !data.conversation_id) return;
  fetch("https://{connector_hostname}" + "{fetch_path}", {{
    method: "POST",
    headers: {{ "Content-Type": "application/json" }},
    body: JSON.stringify({{
      product_id: "{product_id}",
      session_id: sessionId,
      conversation_id: data.conversation_id,
    }}),
  }}).catch(function (e) {{
    console.warn("[autoplay] session link failed:", e);
  }});
}});
</script>"""


def _normalize_hostname_for_fetch(connector_host: str) -> str:
    """Return host[:port] without scheme or path for ``https://`` + host fetches."""
    h = connector_host.strip().rstrip("/")
    if h.startswith("https://"):
        h = h[8:]
    elif h.startswith("http://"):
        h = h[7:]
    h = h.split("/")[0]
    return h


def format_reactive_session_link_script(
    connector_host: str,
    product_id: str,
) -> str:
    """Return HTML/JS snippet for ``onConversationStarted`` → ``POST /sessions/link``.

    Prefer configuring Intercom webhooks to ``/chatbot-webhook/{product_id}``;
    use this only when you still need the browser to pass ``conversation_id``.
    """
    hostname = _normalize_hostname_for_fetch(connector_host)
    return REACTIVE_SESSION_LINK_SCRIPT_TEMPLATE.format(
        connector_hostname=hostname,
        product_id=product_id.replace('"', '\\"'),
        fetch_path=_REACTIVE_FETCH_PATH,
    )
