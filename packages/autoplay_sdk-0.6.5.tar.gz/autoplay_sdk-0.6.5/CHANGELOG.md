# Changelog

All notable changes to `autoplay_sdk` are documented here.

This project follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) style: **Added** / **Changed** / **Deprecated** / **Removed** / **Fixed** / **Security** where applicable, plus **Documentation** for user-facing doc-only updates.

---

## [0.6.5] — 2026-04-23

### Changed

- **`onboard_product`** / **`onboard_product_sync`** require a **`contact_email`** keyword argument (valid email string). The event connector **`POST /products`** API requires **`contact_email`** on every new registration and re-registration.
- **Render `PRODUCTS_CONFIG`:** `contact_email` is normalized on every row written via the SDK (including `serialize_products_config` / `put_products_config_on_render`).

### Breaking changes

- Call sites must pass **`contact_email=`** when using **`onboard_product`** / **`onboard_product_sync`**, **`OnboardingRunParams`**, **`build_register_payload_from_cli`**, **`post_register_product_cli`**, and **`python scripts/onboard_customer.py`** (**`--contact-email`**).

---

## [0.6.4] — 2026-04-23

### Added

- **`SlimAction`** — optional per-action identity fields: `session_id`, `user_id` (PostHog distinct / identified id), and `email`, in line with batch-level `ActionsPayload` fields. Each object in `actions` lists (SSE stream, push webhook JSON, and `ActionsPayload.from_dict` parsing) can include this metadata.
- **`RedisEventBuffer`** — JSON serialization for Redis storage now includes the new per-action identity fields on each action so drain/round-trip does not strip them.

### Documentation

- **Payload schema** and **Typed payloads** — per-action `session_id` / `user_id` / `email` documented; payload schema notes that push webhooks use the same `actions` object shape as the SSE stream.

### Breaking changes

None. New fields are optional and default to `None` when absent from JSON.

---

## [0.6.2] — 2026-04-16

### Added

- **Interactive terminal UX for `POST /products`** (`post_register_product_payload`) — when stdout is a TTY, shows a Rich stderr spinner during registration and prints success or failure on stdout; suppressed in CI and non-interactive runs.

### Changed

- **`run_product_onboarding`** performs a **single** `POST /products` to the connector. The connector dual-writes Redis + Render `PRODUCTS_CONFIG` when `RENDER_API_KEY` / `RENDER_SERVICE_ID` are set on the connector; `OnboardingRunResult.render_sync_performed` is true when the connector response includes `dual_write`.
- **`unkey.py` is now a default dependency** — `pip install autoplay-sdk` installs everything needed for `autoplay_sdk.admin` / `onboard_product` (Unkey key creation), without an extra.

### Removed

- **`[admin]` optional extra** — use `pip install autoplay-sdk` (not `autoplay-sdk[admin]`).

---

## [0.6.1] — 2026-04-14

### Added

- **`ConversationEvent`** (`autoplay_sdk.chatbot`) — dataclass produced by chatbot session-link webhook parsing (`conversation_id`, `external_id`, `email`).
- **`BaseChatbotWriter` session-link webhook flow** — `SESSION_LINK_WEBHOOK_TOPICS`, `extract_conversation_event()` (topic allowlist + dispatch), and `_parse_session_link_webhook_payload()` hook (default `None`). Platform subclasses override only `_parse_session_link_webhook_payload`; do not override `extract_conversation_event`.
- **`autoplay_sdk.integrations.intercom`** — `INTERCOM_WEBHOOK_TOPICS`, `intercom_chatbot_webhook_url()`, optional `format_reactive_session_link_script()` for copy-paste reactive Intercom setup. This subpackage does **not** emit log records.

### Removed

- **`format_proactive_session_start_script`** and the proactive **`/sessions/start`** snippet template — Intercom linking is webhook-driven (`POST /chatbot-webhook/{product_id}`). Use `intercom_chatbot_webhook_url()` and `INTERCOM_WEBHOOK_TOPICS`; optional **`format_reactive_session_link_script`** remains for `POST /sessions/link` if you still need browser-assisted linking.

### Documentation

- **Logging** — [Logging reference](docs/sdk/logging.mdx): logger hierarchy under `autoplay_sdk.*`, application-owned configuration (the SDK does not call `logging.basicConfig`), guidance for third-party `BaseChatbotWriter` subclasses, and cross-link to this changelog for observability history.
- **README** — Logging section expanded with hierarchy note, link to the logging reference, and pointer to `SdkMetricsHook` for metrics alongside logs.
- **[Intercom integration](docs/integrations/intercom.mdx)** — SDK reference (webhook topics, URL builder, optional reactive `/sessions/link` snippet).

### Breaking changes

- Importing or calling **`format_proactive_session_start_script`** from `autoplay_sdk.integrations.intercom` raises `AttributeError` (symbol removed).

### Deprecations

None.

---

## [0.6.0] — 2026-04-13

### Documentation

- **BaseChatbotWriter — Note body format** — Mintlify [chatbot-writer](https://github.com/Autoplay-AI/real-time-poc/blob/main/later-rho-event-connector/src/customer_sdk/docs/sdk/chatbot-writer.mdx) now documents the full plain-text contract for `_post_note` bodies (header via `format_chatbot_note_header`, sorted 1-based action lines, binning vs post-link, empty list, summary notes). `_format_note` docstring points to that page as the single source of truth.

- **Logging** — New [logging](https://github.com/Autoplay-AI/real-time-poc/blob/main/later-rho-event-connector/src/customer_sdk/docs/sdk/logging.mdx) reference page (module loggers, `%` formatting, `exc_info`, structured `extra`, secrets guidance including HTTP bodies, common logging mistakes). Quickstart links to it for discoverability.

### Bug fixes / observability

- `BaseChatbotWriter` — pre-link flush failure `warning` now includes structured `extra` (`session_id`, `product_id`, `conversation_id`).

- `BaseChatbotWriter` — post-link debounced flush: if `_post_note` returns no part id after the debounce buffer was popped, logs a `warning` with the same `extra` shape and explains that this flush is not retried automatically.

### Breaking changes

None.

### Deprecations

None.

---

## [0.5.0] — 2026-04-10

### New features

- **`ActionsPayload.merge(payloads)`** — class method that merges a non-empty list of `ActionsPayload` objects for the same session into one. Actions are concatenated and re-indexed from `0`; `user_id`/`email` resolved from the first non-`None` value; `forwarded_at` set to the latest timestamp. Raises `ValueError` on empty input.

- **`AsyncAgentContextWriter(debounce_ms=N)`** — new optional constructor parameter for a per-session trailing-edge accumulation window. When `> 0`, multiple `add()` calls arriving within the window are merged via `ActionsPayload.merge()` before `write_actions` is called, reducing destination API calls during event bursts. Default is `0` (no debounce — existing behaviour unchanged).

- **`BaseChatbotWriter`** (`autoplay_sdk.chatbot`) — new public base class providing the complete pre-link/post-link delivery policy for building chatbot destinations. Subclass it and implement `_post_note` and `_redact_part`; pre-link buffering (sliding window), at-link flush (binned note), and post-link debouncing are all included. `IntercomChatbot` in the event connector already extends this class.

### Breaking changes

None. All changes are additive:

- `AsyncAgentContextWriter.__init__` gains `debounce_ms: int = 0` — existing code passing positional or keyword arguments is unaffected.
- `ActionsPayload.merge()` is a new class method; no existing method is renamed or removed.
- `BaseChatbotWriter` is a new public export; no existing symbols are removed.

### Deprecations

None.

### Bug fixes / error handling improvements

- `BaseChatbotWriter.on_session_linked` — now no-ops when the same `conversation_id` is passed again (idempotent guard). The product worker includes the conv_id on every batch for already-linked sessions; without this guard, each batch would cancel the in-flight 150ms post-link debounce task and restart the window, causing notes to be delayed indefinitely during fast user interactions.

- `BaseChatbotWriter.on_session_linked` — pre-link buffer (`_pending`) is now only cleared after `_post_note` confirms success (returns a non-`None` part id). Previously the buffer was popped before the API call; a transient Intercom failure would permanently lose those events. On failure the buffer is now preserved and the `_conv_map` entry is rolled back so the next `on_session_linked` call retries automatically.

- `BaseChatbotWriter.write_actions`: the post-link debounce `asyncio.Task` now has a `done_callback` that logs any unhandled exception at `ERROR` level with structured `extra` (previously silent — Python only emitted a `DEBUG`-level "Task exception was never retrieved").

- `AsyncAgentContextWriter._flush_session` done-callback: now includes `product_id` in the log message and `extra` dict for structured log filtering.

### Migration notes

**`AsyncAgentContextWriter` + `BaseChatbotWriter` — avoid double-debouncing**

`BaseChatbotWriter` already coalesces rapid `write_actions()` calls via its `post_link_debounce_s` window (default 150 ms). When wiring an `AsyncAgentContextWriter` to a `BaseChatbotWriter` subclass, keep `debounce_ms=0` (the default):

```python
# CORRECT — BaseChatbotWriter handles debouncing; no stacking needed
writer = AsyncAgentContextWriter(
    summarizer=summarizer,
    write_actions=chatbot_subclass.write_actions_cb,
    overwrite_with_summary=overwrite_cb,
    debounce_ms=0,   # ← default, explicit for clarity
)

# AVOID — stacks two debounce windows, adds latency without benefit
writer = AsyncAgentContextWriter(..., debounce_ms=200)
```

Use `debounce_ms > 0` only when `write_actions` points to a raw destination with no internal coalescing (e.g. a direct Zendesk or Salesforce API call).

---

## [0.4.0] — 2026-04-09

### Bug fixes

- Fixed TOCTOU race in `RedisEventBuffer._get_redis()`: concurrent callers could each create their own connection pool; now serialised with `asyncio.Lock` and double-checked locking.
- Fixed `AsyncSessionSummarizer.flush()` cancellation safety: replaced sequential `for q in queues: await q.join()` with `asyncio.gather(*[asyncio.shield(q.join()) for q in queues])` so all queues are drained even when the caller is cancelled.

### Other

- Added `CHANGELOG.md` to document breaking changes and new features going forward.

---

## [0.3.0] — 2026-04-09

### Breaking changes

- **`AsyncSessionSummarizer.get_context(session_id)` is now `async`** — callers must `await` it.
- **`AsyncSessionSummarizer.reset(session_id)` is now `async`** — callers must `await` it.
- **`AsyncSessionSummarizer.active_sessions` is now an `async` property** — callers must `await` it.
- **`AsyncSessionSummarizer.add()` now returns immediately** — the LLM call is dispatched to a background worker queue rather than awaited inline. Code that relied on the LLM having completed by the time `await add()` returned must call `await summarizer.flush()` before inspecting state.

### New features

- **`AsyncSessionSummarizer.flush()`** — waits for all queued payloads to be fully processed; cancellation-safe via `asyncio.gather` + `asyncio.shield`.
- **`SdkMetricsHook` protocol** (`autoplay_sdk.metrics`) — a `@runtime_checkable Protocol` that customers can implement to receive Prometheus / Datadog / OTEL counters for: dropped events, summarizer latency, Redis operation latency, queue depth, and semaphore timeouts.
- **`metrics=` constructor parameter** on `ConnectorClient`, `AsyncConnectorClient`, `AsyncSessionSummarizer`, and `RedisEventBuffer`.
- **`initial_backoff_s`, `max_backoff_s`, `max_retries` constructor parameters** on both SSE clients — exposes and documents the reconnect policy with configurable jitter-backed exponential backoff.
- **Per-session ordering guarantee in `AsyncSessionSummarizer`** — each session now has its own `asyncio.Queue` + background `asyncio.Task` worker, ensuring that concurrent `add()` calls for the same session are always processed in arrival order, even if an earlier LLM call fails.
- **`py.typed` marker** — the package is now PEP 561-compliant; static type-checkers will find type stubs automatically.

### Bug fixes (v0.2.x → v0.3.0)

The following 24 items were addressed across two audit passes:

**Concurrency & correctness**
- Fixed `AsyncSessionSummarizer` ordering bug: concurrent adds during an LLM failure could produce out-of-order `on_summary` callbacks (replaced single lock with per-session queue).
- Fixed TOCTOU race in `RedisEventBuffer._get_redis()`: concurrent callers could each create their own connection pool; now serialised with `asyncio.Lock` and double-checked locking.
- Replaced `asyncio.Semaphore._value` (private API, breaks across CPython minor versions) with an explicit `_TrackedSemaphore` counter.
- Replaced `asyncio.get_event_loop()` (deprecated) with `asyncio.get_running_loop()` in `app.py` and `async_client.py`.
- Replaced `asyncio.ensure_future()` with `loop.create_task()` in `async_client.py`.
- Added `done_callback` on fire-and-forget `asyncio.Task`s to log unhandled exceptions instead of silently swallowing them.

**Error handling**
- `RedisEventBuffer._payload_from_json()` now wraps `json.loads` in `try/except json.JSONDecodeError`; corrupt ZSET members no longer crash the drain loop.
- `ConnectorClient` now sets `self._running = False` on `KeyboardInterrupt` so callers can inspect the state after shutdown.
- All `except` clauses that were swallowing exceptions now pass `exc_info=True` to the logger so tracebacks appear in structured logs.

**Data structures**
- `RedisEventBuffer` ZSET members now carry a unique UUID prefix, preventing silent deduplication when two events arrive at the same millisecond timestamp.
- `SessionSummarizer` now deletes `_history[session_id]` and `_counts[session_id]` after summarisation to prevent unbounded memory growth.
- `AsyncConnectorClient._session_semaphores` changed from plain `dict` to `collections.OrderedDict` with LRU eviction to cap memory when many short-lived sessions are processed.

**Redis connection management**
- Extracted `LazyRedisClient` helper (`storage/_redis.py`) so all storage modules share one lazily-initialised, thread-safe Redis client instead of each implementing the same racy pattern.
- `session_store` now uses `LazyRedisClient` and exposes a `SessionState.from_redis_link()` classmethod that owns the full reconstruction logic (preventing silent field omissions on restore).
- `SessionState` gains an `error: Optional[str]` field to surface last-known error reason through the API.

**Logging & observability**
- Replaced custom `_JsonFormatter` in `app.py` that ignored `extra={}` fields with a correct implementation that merges them into the JSON line.
- All structured log calls now use `extra={}` dicts consistently.
- Metrics instrumentation added at every observability-relevant site: event drops, queue depth, semaphore timeouts, summarizer latency, Redis add/drain latency.

**Package hygiene**
- Added `__all__` exports to `__init__.py` so `from autoplay_sdk import *` is well-defined.
- Added `__version__ = "0.3.0"` to `__init__.py`.
- Added `py.typed` marker for PEP 561 compliance.
- Removed dead `_dropped_count` / `_total_count` metrics fields that were incremented but never surfaced.
- Standardised public API: `on_drop` callback signature is now consistent across `ConnectorClient`, `AsyncConnectorClient`, and `RedisEventBuffer`.

---

## [0.2.0] — prior

Initial internal release. No changelog maintained at this version.
