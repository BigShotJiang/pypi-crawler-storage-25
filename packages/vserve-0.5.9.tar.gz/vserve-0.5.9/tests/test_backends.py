"""Tests for the backend registry and protocol."""

from pathlib import Path
from unittest.mock import Mock

import pytest

from vserve.backends import register, get_backend, get_backend_by_name, available_backends, any_backend_running, running_backend
from vserve.backends.protocol import Backend
from vserve.backends.vllm import VllmBackend


@pytest.fixture(autouse=True)
def _clean_registry():
    """Reset registry before each test."""
    from vserve.backends import _BACKENDS
    saved = _BACKENDS.copy()
    _BACKENDS.clear()
    yield
    _BACKENDS.clear()
    _BACKENDS.extend(saved)


def _make_mock_backend(name: str, can_serve_result: bool = True, has_binary: bool = True) -> Mock:
    b = Mock(spec=Backend)
    b.name = name
    b.display_name = name
    b.can_serve.return_value = can_serve_result
    b.find_entrypoint.return_value = Path("/fake/bin") if has_binary else None
    return b


def test_register_and_get_backend_by_name():
    b = _make_mock_backend("test")
    register(b)
    assert get_backend_by_name("test") is b


def test_get_backend_by_name_unknown():
    with pytest.raises(KeyError):
        get_backend_by_name("nonexistent")


def test_get_backend_auto_detect():
    b1 = _make_mock_backend("a", can_serve_result=False)
    b2 = _make_mock_backend("b", can_serve_result=True)
    register(b1)
    register(b2)

    model = Mock()
    assert get_backend(model) is b2


def test_get_backend_no_match():
    b = _make_mock_backend("a", can_serve_result=False)
    register(b)

    model = Mock()
    with pytest.raises(ValueError, match="No backend"):
        get_backend(model)


def test_available_backends_filters_missing():
    b1 = _make_mock_backend("installed", has_binary=True)
    b2 = _make_mock_backend("missing", has_binary=False)
    register(b1)
    register(b2)

    result = available_backends()
    assert len(result) == 1
    assert result[0].name == "installed"


# --- VllmBackend tests ---


class TestVllmBackend:
    def test_identity(self):
        b = VllmBackend()
        assert b.name == "vllm"
        assert b.display_name == "vLLM"

    def test_can_serve_safetensors(self, fake_model_dir):
        b = VllmBackend()
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)
        assert b.can_serve(m) is True

    def test_can_serve_uppercase_safetensors_suffix(self, tmp_path):
        b = VllmBackend()
        model_dir = tmp_path / "models" / "user" / "UppercaseWeights"
        model_dir.mkdir(parents=True)
        (model_dir / "model.SAFETENSORS").write_bytes(b"\0")

        from vserve.models import ModelInfo
        m = ModelInfo(
            path=model_dir, provider="user", model_name="UppercaseWeights",
            architecture="TestLM", model_type="test", quant_method=None,
            max_position_embeddings=4096, is_moe=False, model_size_gb=0.1,
        )
        assert b.can_serve(m) is True

    def test_cannot_serve_gguf_only(self, tmp_path):
        b = VllmBackend()
        model_dir = tmp_path / "models" / "user" / "Model-GGUF"
        model_dir.mkdir(parents=True)
        (model_dir / "model-Q4_K_M.gguf").write_bytes(b"\0" * 100)

        from vserve.models import ModelInfo
        m = ModelInfo(
            path=model_dir, provider="user", model_name="Model-GGUF",
            architecture="unknown", model_type="unknown", quant_method=None,
            max_position_embeddings=4096, is_moe=False, model_size_gb=0.1,
        )
        assert b.can_serve(m) is False

    def test_cannot_serve_config_only_root(self, tmp_path):
        b = VllmBackend()
        model_dir = tmp_path / "models" / "user" / "Model"
        model_dir.mkdir(parents=True)
        (model_dir / "config.json").write_text("{}")

        from vserve.models import detect_model

        m = detect_model(model_dir)

        assert b.can_serve(m) is False

    def test_health_url(self):
        b = VllmBackend()
        assert b.health_url(8888) == "http://localhost:8888/health"

    def test_quant_flag(self):
        b = VllmBackend()
        assert "gptq_marlin" in b.quant_flag("gptq")
        assert "fp8" in b.quant_flag("fp8")
        assert b.quant_flag(None) == ""
        assert b.quant_flag("compressed-tensors") == ""

    def test_tune_delegates_to_probe(self, fake_model_dir):
        b = VllmBackend()
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)

        mock_gpu = Mock()
        mock_gpu.vram_total_gb = 48.0

        result = b.tune(m, mock_gpu, gpu_mem_util=0.90)
        assert "limits" in result
        assert "tool_call_parser" in result

    def test_detect_tools(self, fake_model_dir):
        b = VllmBackend()
        result = b.detect_tools(fake_model_dir)
        assert "tool_call_parser" in result
        assert "reasoning_parser" in result

    def test_start_stop_delegates(self, mocker, tmp_path):
        b = VllmBackend()
        mock_start = mocker.patch("vserve.serve.start_vllm")
        mock_stop = mocker.patch("vserve.serve.stop_vllm")
        mocker.patch("vserve.serve.is_vllm_running", return_value=True)

        cfg_path = tmp_path / "test.yaml"
        cfg_path.write_text("model: test\n")
        b.start(cfg_path)
        mock_start.assert_called_once_with(cfg_path, non_interactive=False)

        b.stop()
        mock_stop.assert_called_once_with(non_interactive=False)

        assert b.is_running() is True

    def test_build_config_basic(self, fake_model_dir):
        b = VllmBackend()
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)

        choices = {
            "context": 8192,
            "kv_dtype": "auto",
            "slots": 4,
            "batched_tokens": None,
            "gpu_mem_util": 0.90,
            "port": 8888,
            "tools": False,
            "tool_parser": None,
            "reasoning_parser": None,
        }
        cfg = b.build_config(m, choices)
        assert cfg["max-model-len"] == 8192
        assert cfg["max-num-seqs"] == 4
        assert cfg["kv-cache-dtype"] == "auto"
        assert cfg["gpu-memory-utilization"] == 0.90
        assert "enable-auto-tool-choice" not in cfg
        assert "trust-remote-code" not in cfg

    def test_build_config_trust_remote_code_explicit(self, fake_model_dir):
        b = VllmBackend()
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)

        choices = {
            "context": 8192,
            "kv_dtype": "auto",
            "slots": 4,
            "batched_tokens": None,
            "gpu_mem_util": 0.90,
            "port": 8888,
            "tools": False,
            "tool_parser": None,
            "reasoning_parser": None,
            "trust_remote_code": True,
        }
        cfg = b.build_config(m, choices)
        assert cfg["trust-remote-code"] is True

    def test_build_config_with_tools(self, fake_model_dir):
        b = VllmBackend()
        b.available_tool_parsers = Mock(return_value={"hermes"})  # type: ignore[method-assign]
        b.available_reasoning_parsers = Mock(return_value={"qwen3"})  # type: ignore[method-assign]
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)

        choices = {
            "context": 8192,
            "kv_dtype": "auto",
            "slots": 4,
            "batched_tokens": 4096,
            "gpu_mem_util": 0.90,
            "port": 8888,
            "tools": True,
            "tool_parser": "hermes",
            "reasoning_parser": "qwen3",
        }
        cfg = b.build_config(m, choices)
        assert cfg["enable-auto-tool-choice"] is True
        assert cfg["tool-call-parser"] == "hermes"
        assert cfg["reasoning-parser"] == "qwen3"
        assert cfg["max-num-batched-tokens"] == 4096

    def test_build_config_with_sota_scheduler_and_cache_knobs(self, fake_model_dir):
        b = VllmBackend()
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)

        choices = {
            "context": 8192,
            "kv_dtype": "turboquant_k8v4",
            "slots": 4,
            "batched_tokens": 12288,
            "gpu_mem_util": 0.90,
            "port": 8888,
            "tools": False,
            "tool_parser": None,
            "reasoning_parser": None,
            "performance_mode": "throughput",
            "optimization_level": 2,
            "block_size": 16,
            "kv_cache_memory_bytes": 12 * 1024**3,
            "enable_prefix_caching": True,
        }

        cfg = b.build_config(m, choices)

        assert cfg["kv-cache-dtype"] == "turboquant_k8v4"
        assert cfg["max-num-batched-tokens"] == 12288
        assert cfg["performance-mode"] == "throughput"
        assert cfg["optimization-level"] == 2
        assert cfg["block-size"] == 16
        assert cfg["kv-cache-memory-bytes"] == 12 * 1024**3
        assert cfg["enable-prefix-caching"] is True

    def test_build_config_defaults_safe_batched_tokens_for_hybrid_models(self, tmp_path):
        b = VllmBackend()
        from vserve.models import ModelInfo

        model_dir = tmp_path / "models" / "Qwen" / "Qwen3.6-35B-A3B-FP8"
        model_dir.mkdir(parents=True)
        (model_dir / "config.json").write_text(
            """
{
  "architectures": ["Qwen3_5MoeForConditionalGeneration"],
  "model_type": "qwen3_5_moe",
  "text_config": {
    "model_type": "qwen3_5_moe_text",
    "full_attention_interval": 4,
    "layer_types": ["linear_attention", "linear_attention", "full_attention"]
  }
}
""".strip()
            + "\n",
        )
        m = ModelInfo(
            path=model_dir,
            provider="Qwen",
            model_name="Qwen3.6-35B-A3B-FP8",
            architecture="Qwen3_5MoeForConditionalGeneration",
            model_type="qwen3_5_moe",
            quant_method="fp8",
            max_position_embeddings=262144,
            is_moe=True,
            model_size_gb=34.9,
        )

        cfg = b.build_config(
            m,
            {
                "context": 262144,
                "kv_dtype": "fp8",
                "slots": 1,
                "batched_tokens": None,
                "gpu_mem_util": 0.95,
                "port": 8888,
                "tools": False,
                "tool_parser": None,
                "reasoning_parser": None,
            },
        )

        assert cfg["max-num-batched-tokens"] == 4096

    def test_build_config_reasoning_without_tools(self, fake_model_dir):
        b = VllmBackend()
        b.available_reasoning_parsers = Mock(return_value={"qwen3"})  # type: ignore[method-assign]
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)

        choices = {
            "context": 8192,
            "kv_dtype": "auto",
            "slots": 4,
            "batched_tokens": None,
            "gpu_mem_util": 0.90,
            "port": 8888,
            "tools": False,
            "tool_parser": None,
            "reasoning_parser": "qwen3",
        }
        cfg = b.build_config(m, choices)
        assert cfg["reasoning-parser"] == "qwen3"
        assert "enable-auto-tool-choice" not in cfg

    def test_build_config_rejects_unknown_tool_parser(self, fake_model_dir, mocker):
        b = VllmBackend()
        mocker.patch.object(b, "available_tool_parsers", return_value={"hermes"})
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)

        choices = {
            "context": 4096,
            "kv_dtype": "auto",
            "slots": 1,
            "gpu_mem_util": 0.9,
            "port": 8888,
            "tools": True,
            "tool_parser": "qwen-3",
            "reasoning_parser": None,
        }

        import pytest
        with pytest.raises(ValueError, match="Unknown vLLM tool parser"):
            b.build_config(m, choices)

    def test_build_config_rejects_unknown_reasoning_parser(self, fake_model_dir, mocker):
        b = VllmBackend()
        mocker.patch.object(b, "available_reasoning_parsers", return_value={"qwen3"})
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)

        choices = {
            "context": 4096,
            "kv_dtype": "auto",
            "slots": 1,
            "gpu_mem_util": 0.9,
            "port": 8888,
            "tools": False,
            "tool_parser": None,
            "reasoning_parser": "qwen-3",
        }

        import pytest
        with pytest.raises(ValueError, match="Unknown vLLM reasoning parser"):
            b.build_config(m, choices)

    def test_build_config_rejects_parser_when_runtime_introspection_uncertain(self, fake_model_dir, mocker):
        b = VllmBackend()
        mocker.patch.object(b, "available_tool_parsers", return_value=None)
        from vserve.models import detect_model
        m = detect_model(fake_model_dir)

        choices = {
            "context": 4096,
            "kv_dtype": "auto",
            "slots": 1,
            "gpu_mem_util": 0.9,
            "port": 8888,
            "tools": True,
            "tool_parser": "hermes",
            "reasoning_parser": None,
        }

        with pytest.raises(RuntimeError, match="Could not inspect installed vLLM tool parsers"):
            b.build_config(m, choices)

    def test_available_parsers_use_configured_runtime_python(self, mocker, tmp_path):
        b = VllmBackend()
        runtime_python = tmp_path / "venv" / "bin" / "python"
        mocker.patch("vserve.config.cfg", return_value=Mock(vllm_python=runtime_python))
        run = mocker.patch(
            "subprocess.run",
            return_value=Mock(
                returncode=0,
                stdout='{"tool_parsers": ["hermes"], "reasoning_parsers": ["qwen3"]}',
                stderr="",
            ),
        )

        assert b.available_tool_parsers() == {"hermes"}
        assert b.available_reasoning_parsers() == {"qwen3"}
        assert run.call_args.args[0][0] == str(runtime_python)
        assert run.call_count == 1

    def test_parser_probe_supports_vllm_020_manager_paths(self, mocker, tmp_path):
        b = VllmBackend()
        runtime_python = tmp_path / "venv" / "bin" / "python"
        mocker.patch("vserve.config.cfg", return_value=Mock(vllm_python=runtime_python))
        run = mocker.patch(
            "subprocess.run",
            return_value=Mock(
                returncode=0,
                stdout='{"tool_parsers": ["hermes"], "reasoning_parsers": ["qwen3"]}',
                stderr="",
            ),
        )

        assert b.available_tool_parsers() == {"hermes"}
        script = run.call_args.args[0][2]
        assert "vllm.tool_parsers" in script
        assert "list_registered" in script

    def test_find_entrypoint_missing(self, mocker):
        b = VllmBackend()
        mock_c = Mock()
        mock_c.vllm_bin = Path("/nonexistent/vllm")
        mocker.patch("vserve.config.cfg", return_value=mock_c)
        assert b.find_entrypoint() is None

    def test_find_entrypoint_exists(self, mocker, tmp_path):
        b = VllmBackend()
        vllm_bin = tmp_path / "venv" / "bin" / "vllm"
        vllm_bin.parent.mkdir(parents=True)
        vllm_bin.touch()
        mock_c = Mock()
        mock_c.vllm_bin = vllm_bin
        mocker.patch("vserve.config.cfg", return_value=mock_c)
        assert b.find_entrypoint() == vllm_bin

    def test_doctor_checks_returns_callables(self):
        b = VllmBackend()
        checks = b.doctor_checks()
        assert len(checks) >= 2
        for desc, fn in checks:
            assert isinstance(desc, str)
            assert callable(fn)

    def test_service_identity(self):
        b = VllmBackend()
        assert b.service_name == "vllm"
        assert b.service_user == "vllm"

    def test_configured_service_identity(self, mocker):
        b = VllmBackend()
        mocker.patch(
            "vserve.config.cfg",
            return_value=Mock(service_name="custom-vllm", service_user="svc-vllm", vllm_root=Path("/opt/vllm")),
        )
        assert b.service_name == "custom-vllm"
        assert b.service_user == "svc-vllm"


# --- Auto-registration ---


def test_default_backends_registered():
    """Built-in backends are registered after _register_defaults."""
    from vserve.backends import _register_defaults
    _register_defaults()

    from vserve.backends import _BACKENDS
    names = [b.name for b in _BACKENDS]
    assert "vllm" in names
    assert "llamacpp" in names


def test_duplicate_registration_prevented():
    """register() with same name is idempotent."""
    b1 = _make_mock_backend("dedup")
    b2 = _make_mock_backend("dedup")
    register(b1)
    register(b2)
    from vserve.backends import _BACKENDS
    assert sum(1 for b in _BACKENDS if b.name == "dedup") == 1


# --- any_backend_running / running_backend ---


def test_any_backend_running_true():
    b = _make_mock_backend("running")
    b.is_running.return_value = True
    register(b)
    assert any_backend_running() is True


def test_any_backend_running_false():
    b = _make_mock_backend("stopped")
    b.is_running.return_value = False
    register(b)
    assert any_backend_running() is False


def test_any_backend_running_exception_handled():
    b = _make_mock_backend("broken")
    b.is_running.side_effect = RuntimeError("no systemctl")
    register(b)
    assert any_backend_running() is False


def test_probe_running_backend_partial_failure_with_successful_false_probe():
    from vserve.backends import probe_running_backend

    broken = _make_mock_backend("broken")
    broken.is_running.side_effect = RuntimeError("dbus error")
    idle = _make_mock_backend("idle")
    idle.is_running.return_value = False
    register(broken)
    register(idle)

    backend, probe_failed = probe_running_backend()

    assert backend is None
    assert probe_failed is True


def test_running_backend_returns_correct():
    b1 = _make_mock_backend("idle")
    b1.is_running.return_value = False
    b2 = _make_mock_backend("active")
    b2.is_running.return_value = True
    register(b1)
    register(b2)
    result = running_backend()
    assert result is not None
    assert result.name == "active"


def test_running_backend_none_when_all_stopped():
    b = _make_mock_backend("stopped")
    b.is_running.return_value = False
    register(b)
    assert running_backend() is None
