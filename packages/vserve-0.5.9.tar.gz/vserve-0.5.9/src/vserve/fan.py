"""GPU fan curve daemon — temperature-based with quiet hours."""

import logging
import os
import signal
import stat
import threading
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path

from vserve.config import cfg

LOG_PATH: Path  # resolved lazily
PID_PATH: Path
STATE_PATH: Path
_paths_resolved = False


def _resolve_paths() -> None:
    global LOG_PATH, PID_PATH, STATE_PATH, _paths_resolved
    if _paths_resolved:
        return
    c = cfg()
    LOG_PATH = c.logs_dir / "vserve-fan.log"
    PID_PATH = c.run_dir / "vserve-fan.pid"
    STATE_PATH = c.run_dir / "vserve-fan.json"
    _paths_resolved = True

MIN_FAN = 30
POLL_INTERVAL = 5
SUBPROCESS_TIMEOUT = 10
MAX_CONSECUTIVE_FAILURES = 30  # 30 × 5s = 2.5 min → exit for systemd restart
FAILURE_RESET_THRESHOLD = 5   # force re-apply after 5 failures
HYSTERESIS = 4  # °C deadband — ramp-down requires temp to drop this much below ramp-up threshold
MAX_RAMP_PER_CYCLE = 5  # max fan % change per poll cycle to avoid audible jumps
SMOOTHING_SAMPLES = 3   # moving average window for temperature readings

_log = logging.getLogger("vserve.fan")

# Piecewise-linear curve: (temp_C, fan_%).
# Shallow at low temps, steep near throttle zone.
# Used for non-quiet hours (cap=100%).
_CURVE = [
    (35, 30),
    (55, 35),
    (65, 50),
    (75, 75),
    (80, 100),
]

EMERGENCY_TEMP = 88  # ignore quiet hours above this
_O_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)


def _configured_gpu_index() -> int:
    try:
        return int(getattr(cfg(), "gpu_index", 0) or 0)
    except Exception:
        return 0


def _write_state_file(path: Path, content: str) -> None:
    """Write fan daemon state without following symlinks."""
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC | _O_NOFOLLOW, 0o644)
    except OSError as exc:
        if getattr(exc, "errno", None) == 40:
            raise PermissionError(f"Refusing to use symlink as vserve fan state file: {path}") from None
        raise
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            raise PermissionError(f"Refusing to use non-regular vserve fan state file: {path}")
        try:
            os.fchmod(fd, 0o644)
        except PermissionError:
            pass
        os.write(fd, content.encode())
        os.fsync(fd)
    finally:
        os.close(fd)


def read_state() -> dict | None:
    """Read the running daemon's config. Returns None if not running."""
    _resolve_paths()
    if not STATE_PATH.exists():
        return None
    import json
    try:
        data = json.loads(STATE_PATH.read_text())
    except (ValueError, OSError):
        return None
    if not isinstance(data, dict):
        return None
    fixed = data.get("fixed")
    if fixed is not None:
        if isinstance(fixed, bool) or not isinstance(fixed, int):
            return None
        return data
    for key in ("quiet_start", "quiet_end", "quiet_max"):
        value = data.get(key)
        if isinstance(value, bool) or not isinstance(value, int):
            return None
    return data


def _interpolate_curve(temp: int, cap: int) -> int:
    """Evaluate the piecewise-linear curve, scaling to the given cap."""
    if temp <= _CURVE[0][0]:
        return MIN_FAN
    if temp >= _CURVE[-1][0]:
        return cap

    # Find the segment
    for i in range(len(_CURVE) - 1):
        t0, s0 = _CURVE[i]
        t1, s1 = _CURVE[i + 1]
        if t0 <= temp <= t1:
            frac = (temp - t0) / (t1 - t0)
            raw = s0 + frac * (s1 - s0)
            return min(int(raw), cap)
    return cap  # shouldn't reach here


def compute_fan_speed(
    temp: int,
    hour: int,
    quiet_start: int = 9,
    quiet_end: int = 18,
    quiet_max: int = 60,
) -> int:
    """Map GPU temperature to fan speed using piecewise-linear curve.

    During quiet hours, the curve is scaled so the max output is quiet_max
    instead of 100%, with a smooth ramp (no hard cap cliff).
    Emergency override at EMERGENCY_TEMP always returns 100%.
    """
    if temp >= EMERGENCY_TEMP:
        return 100

    if quiet_start < quiet_end:
        in_quiet = quiet_start <= hour < quiet_end
    else:  # wraps midnight, e.g. 22:00-06:00
        in_quiet = hour >= quiet_start or hour < quiet_end
    cap = quiet_max if in_quiet else 100

    return _interpolate_curve(temp, cap)


def _nvml_init():
    """Initialize NVML and return the GPU handle."""
    import pynvml  # type: ignore[import-untyped]
    pynvml.nvmlInit()
    return pynvml.nvmlDeviceGetHandleByIndex(_configured_gpu_index())


def _get_gpu_temp() -> int:
    """Read GPU temperature via NVML."""
    import pynvml
    pynvml.nvmlInit()
    try:
        h = pynvml.nvmlDeviceGetHandleByIndex(_configured_gpu_index())
        return pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU)
    finally:
        pynvml.nvmlShutdown()


def _apply_fan(percent: int, handle: object) -> None:
    """Set fan speed via NVML for all exposed fans."""
    import pynvml
    for i in range(pynvml.nvmlDeviceGetNumFans(handle)):
        pynvml.nvmlDeviceSetFanSpeed_v2(handle, i, percent)  # type: ignore[arg-type]


def _set_manual_control(handle: object) -> None:
    """Switch all exposed fans to manual control."""
    import pynvml
    for i in range(pynvml.nvmlDeviceGetNumFans(handle)):
        pynvml.nvmlDeviceSetFanControlPolicy(handle, i, 1)  # type: ignore[arg-type]


def _restore_auto_control(handle: object) -> None:
    """Restore default fan control policy for all exposed fans."""
    import pynvml

    restore_default = getattr(pynvml, "nvmlDeviceSetDefaultFanSpeed_v2", None)
    for i in range(pynvml.nvmlDeviceGetNumFans(handle)):
        if restore_default is not None:
            try:
                restore_default(handle, i)  # type: ignore[misc]
                continue
            except Exception:
                pass
        pynvml.nvmlDeviceSetFanControlPolicy(handle, i, 0)  # type: ignore[arg-type]


def _setup_logging() -> None:
    if _log.handlers:
        return
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(LOG_PATH, maxBytes=2 * 1024 * 1024, backupCount=2)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S",
    ))
    _log.addHandler(handler)
    _log.setLevel(logging.INFO)


def run_daemon(quiet_start: int = 9, quiet_end: int = 18, quiet_max: int = 60) -> None:
    """Main fan curve loop. Blocks until SIGTERM."""
    import json
    from vserve.lock import VserveLock, LockHeld

    _resolve_paths()
    _setup_logging()

    try:
        _fan_lock = VserveLock("fan", "fan daemon")
        _fan_lock.acquire()
    except LockHeld as exc:
        _log.error("Another fan daemon is running: %s", exc.message())
        return
    except PermissionError as exc:
        _log.error("Lock permission denied: %s", exc)
        return

    def _cleanup_state_files() -> None:
        try:
            PID_PATH.unlink(missing_ok=True)
        except OSError:
            pass
        try:
            STATE_PATH.unlink(missing_ok=True)
        except OSError:
            pass

    try:
        PID_PATH.parent.mkdir(parents=True, exist_ok=True)
        _write_state_file(PID_PATH, str(os.getpid()))
        _write_state_file(STATE_PATH, json.dumps({
            "quiet_start": quiet_start,
            "quiet_end": quiet_end,
            "quiet_max": quiet_max,
        }))
    except OSError:
        _cleanup_state_files()
        _fan_lock.release()
        _log.exception("Failed to initialize fan daemon state files")
        return

    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    signal.signal(signal.SIGINT, lambda *_: stop.set())

    import pynvml
    handle = None
    nvml_started = False
    try:
        pynvml.nvmlInit()
        nvml_started = True
        handle = pynvml.nvmlDeviceGetHandleByIndex(_configured_gpu_index())

        # Enable manual fan control via NVML — no X11/Xvfb needed
        _set_manual_control(handle)

        current_speed = -1
        consecutive_failures = 0
        temp_history: list[int] = []
        _log.info(
            "Fan daemon started (quiet %02d:00-%02d:00 cap %d%%)",
            quiet_start, quiet_end, quiet_max,
        )

        while not stop.is_set():
            try:
                raw_temp = pynvml.nvmlDeviceGetTemperature(
                    handle, pynvml.NVML_TEMPERATURE_GPU,
                )

                # Temperature smoothing — moving average
                temp_history.append(raw_temp)
                if len(temp_history) > SMOOTHING_SAMPLES:
                    temp_history.pop(0)
                temp = sum(temp_history) // len(temp_history)

                hour = datetime.now().hour
                target = compute_fan_speed(temp, hour, quiet_start, quiet_end, quiet_max)

                # Hysteresis — only ramp down if temp dropped enough
                if target < current_speed and current_speed != -1:
                    ramp_down_temp = compute_fan_speed(
                        temp + HYSTERESIS, hour, quiet_start, quiet_end, quiet_max,
                    )
                    if ramp_down_temp >= current_speed:
                        target = current_speed  # hold — not cool enough yet

                # Rate limiting — max change per cycle
                if current_speed != -1:
                    delta = target - current_speed
                    if abs(delta) > MAX_RAMP_PER_CYCLE:
                        target = current_speed + (MAX_RAMP_PER_CYCLE if delta > 0 else -MAX_RAMP_PER_CYCLE)

                target = max(MIN_FAN, min(100, target))

                if target != current_speed:
                    _apply_fan(target, handle)
                    _log.info("temp=%d°C (raw=%d) hour=%02d:00 fan=%d%%", temp, raw_temp, hour, target)
                    current_speed = target

                consecutive_failures = 0
            except Exception:
                consecutive_failures += 1
                if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                    _log.critical(
                        "Too many consecutive failures (%d), exiting for restart",
                        consecutive_failures,
                    )
                    break
                if consecutive_failures >= FAILURE_RESET_THRESHOLD:
                    current_speed = -1  # force re-apply on next success
                if consecutive_failures <= 3 or consecutive_failures % 10 == 0:
                    _log.exception("Fan update failed (%d consecutive)", consecutive_failures)

            stop.wait(timeout=POLL_INTERVAL)
    except Exception:
        _log.exception("Fan daemon failed during startup")
    finally:
        # Restore auto fan control via NVML — best effort
        restored = False
        if handle is not None:
            try:
                _restore_auto_control(handle)
                restored = True
            except Exception:
                _log.exception("Failed to restore auto fan control")
        if nvml_started:
            try:
                pynvml.nvmlShutdown()
            except Exception:
                pass
        _cleanup_state_files()
        _fan_lock.release()
        if restored:
            _log.info("Fan daemon stopped, auto control restored")
        else:
            _log.warning("Fan daemon stopped, auto control NOT restored — run: vserve fan off")


def run_fixed_daemon(speed: int) -> None:
    """Hold GPU fan at a fixed speed. Blocks until SIGTERM."""
    import json
    from vserve.lock import VserveLock, LockHeld

    _resolve_paths()
    _setup_logging()

    try:
        _fan_lock = VserveLock("fan", f"fan fixed {speed}%")
        _fan_lock.acquire()
    except LockHeld as exc:
        _log.error("Another fan daemon is running: %s", exc.message())
        return
    except PermissionError as exc:
        _log.error("Lock permission denied: %s", exc)
        return

    def _cleanup_state_files() -> None:
        try:
            PID_PATH.unlink(missing_ok=True)
        except OSError:
            pass
        try:
            STATE_PATH.unlink(missing_ok=True)
        except OSError:
            pass

    try:
        PID_PATH.parent.mkdir(parents=True, exist_ok=True)
        _write_state_file(PID_PATH, str(os.getpid()))
        _write_state_file(STATE_PATH, json.dumps({"fixed": speed}))
    except OSError:
        _cleanup_state_files()
        _fan_lock.release()
        _log.exception("Failed to initialize fixed fan daemon state files")
        return

    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    signal.signal(signal.SIGINT, lambda *_: stop.set())

    import pynvml
    handle = None
    nvml_started = False
    try:
        pynvml.nvmlInit()
        nvml_started = True
        handle = pynvml.nvmlDeviceGetHandleByIndex(_configured_gpu_index())

        _set_manual_control(handle)
        _apply_fan(speed, handle)
        _log.info("Fan fixed at %d%%", speed)

        while not stop.is_set():
            try:
                _apply_fan(speed, handle)
            except Exception:
                _log.exception("Fan re-apply failed")
            stop.wait(timeout=POLL_INTERVAL)
    except Exception:
        _log.exception("Fan fixed daemon failed during startup")
    finally:
        restored = False
        if handle is not None:
            try:
                _restore_auto_control(handle)
                restored = True
            except Exception:
                _log.exception("Failed to restore auto fan control")
        if nvml_started:
            try:
                pynvml.nvmlShutdown()
            except Exception:
                pass
        _cleanup_state_files()
        _fan_lock.release()
        if restored:
            _log.info("Fan fixed daemon stopped, auto control restored")
        else:
            _log.warning("Fan fixed daemon stopped, auto control NOT restored — run: vserve fan off")


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument("--quiet-start", type=int, default=9)
    p.add_argument("--quiet-end", type=int, default=18)
    p.add_argument("--quiet-max", type=int, default=60)
    p.add_argument("--fixed", type=int, default=None, help="Hold a fixed fan speed")
    args = p.parse_args()
    if args.fixed is not None:
        run_fixed_daemon(args.fixed)
    else:
        run_daemon(args.quiet_start, args.quiet_end, args.quiet_max)
