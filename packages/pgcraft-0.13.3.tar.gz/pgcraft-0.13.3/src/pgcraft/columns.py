"""Primary key column wrapper for pgcraft factories."""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import Column
from sqlalchemy.schema import DefaultClause, FetchedValue

if TYPE_CHECKING:
    from collections.abc import Iterator


class PrimaryKeyColumns:
    """Thin wrapper around a list of primary key columns.

    Provides convenient access to the first column's key (the most
    common operation) while still supporting iteration for unpacking
    into ``Table(...)`` constructors.

    Args:
        columns: The underlying primary key column list.

    """

    def __init__(self, columns: list[Column]) -> None:
        """Store the column list."""
        self._columns = columns

    @property
    def first(self) -> Column:
        """Return the first primary key column.

        Raises:
            IndexError: If there are no columns.

        """
        return self._columns[0]

    @property
    def first_key(self) -> str:
        """Return ``first.key``, defaulting to ``"id"`` when empty.

        This replaces the repeated
        ``ctx.pk_columns[0].key if ctx.pk_columns else "id"`` pattern.
        """
        if self._columns:
            return self._columns[0].key
        return "id"

    def make_derived(self, *, name: str | None = None) -> Column:
        """Return a fresh ``Column`` matching the first PK column.

        Multi-table dimension factories (``PGCraftAppendOnly``,
        ``PGCraftEAV``) need to declare PK columns on derived tables
        (root, attributes, entity, attribute) and on the user-facing
        view proxy.  Each of those columns must honor whichever PK
        plugin the user chose — ``UUIDV4PKPlugin`` should produce
        UUID PKs everywhere, not just on the user's own table.

        The new column copies the first PK column's type and
        ``server_default`` (e.g. ``gen_random_uuid()`` for UUID
        plugins).  ``primary_key=True`` is set unconditionally.

        Args:
            name: Override for the column name.  Defaults to the
                first PK column's name.

        Returns:
            A fresh :class:`~sqlalchemy.Column` not yet attached to
            any table.

        """
        pk = self.first
        sd = pk.server_default
        # DefaultClause is bound to its column, so we re-wrap its arg
        # in a fresh instance.  Other FetchedValue subclasses
        # (Identity, Computed, etc.) are passed through as-is.
        if isinstance(sd, DefaultClause):
            cloned: FetchedValue | None = DefaultClause(
                sd.arg, for_update=sd.for_update
            )
        else:
            cloned = sd
        return Column(
            name or pk.name,
            pk.type,
            primary_key=True,
            server_default=cloned,
        )

    def __iter__(self) -> Iterator[Column]:
        """Yield each primary key column."""
        return iter(self._columns)

    def __len__(self) -> int:
        """Return the number of primary key columns."""
        return len(self._columns)

    def __repr__(self) -> str:
        """Return a developer-friendly representation."""
        return f"PrimaryKeyColumns({self._columns!r})"
