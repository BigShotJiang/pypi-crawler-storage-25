"""Declarative PostgreSQL extension management for pgcraft.

:class:`PGExtension` describes a PostgreSQL extension that the
application requires.  :func:`register_pg_extension` stores it in
``metadata.info`` so the Alembic comparator can emit
``CREATE EXTENSION IF NOT EXISTS`` when the extension is missing from
the database.

Extensions are never dropped automatically.  Removing an extension
from metadata simply stops pgcraft from ensuring it is present; the
extension itself remains installed until a DBA drops it manually.

Usage::

    from pgcraft.pg_extension import PGExtension, register_pg_extension

    # Standalone registration
    register_pg_extension(metadata, PGExtension("btree_gist"))
    register_pg_extension(metadata, PGExtension("pg_cron", schema="cron"))

    # Alembic wiring (call once in env.py)
    from pgcraft.pg_extension import register_pg_extension_alembic_events
    register_pg_extension_alembic_events()

Alembic autogenerate then emits::

    op.execute("CREATE EXTENSION IF NOT EXISTS btree_gist")
"""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from alembic.operations.ops import MigrateOperation
from sqlalchemy import MetaData

from pgcraft.errors import PGCraftValidationError

if TYPE_CHECKING:
    from sqlalchemy import Connection

_alembic_registered = False


@dataclass(frozen=True)
class PGExtension:
    """Describe a PostgreSQL extension to install.

    Args:
        name: Extension name, e.g. ``"btree_gist"``.
        schema: Schema in which to install the extension.  When
            ``None`` the database default (usually ``public``) is used.
        cascade: When ``True``, adds ``CASCADE`` so dependent
            extensions are installed automatically.

    """

    name: str
    schema: str | None = None
    cascade: bool = False

    def to_sql_create(self) -> str:
        """Render ``CREATE EXTENSION IF NOT EXISTS`` DDL.

        Returns:
            A complete ``CREATE EXTENSION`` SQL string.

        """
        parts = [f"CREATE EXTENSION IF NOT EXISTS {self.name}"]
        if self.schema is not None:
            parts.append(f"SCHEMA {self.schema}")
        if self.cascade:
            parts.append("CASCADE")
        return " ".join(parts)


@dataclass
class PGExtensions:
    """Container for all extensions registered on a MetaData.

    Stored under ``metadata.info["pg_extensions"]`` by
    :func:`register_pg_extension`.
    """

    extensions: list[PGExtension] = field(default_factory=list)

    @classmethod
    def extract(cls, metadata: object) -> "PGExtensions | None":
        """Return registered extensions or ``None`` if none exist.

        Args:
            metadata: SQLAlchemy :class:`~sqlalchemy.MetaData`, or
                ``None``.

        Returns:
            The :class:`PGExtensions` holder or ``None``.

        """
        if metadata is None or not isinstance(metadata, MetaData):
            return None
        return metadata.info.get("pg_extensions")


def assert_pg_extension_declared(
    metadata: MetaData,
    name: str,
) -> None:
    """Raise if *name* has not been declared as a required extension.

    Call this inside a plugin's ``run()`` method to give a clear error
    when the user forgot to register the extension in metadata (e.g. via
    a :class:`~pgcraft.ext.pg_cron.PGCronExtension`).

    In the declarative model flow, extensions are configured via
    ``pgcraft_configure_metadata`` which runs after all models are
    imported.  If a plugin calls this check at class-definition time and
    the extension is not yet in metadata but a
    :class:`~pgcraft.config.PGCraftConfig` is present on
    ``metadata.info``, the config's extension hooks are run eagerly so
    that the check can succeed.  The full ``pgcraft_configure_metadata``
    call in ``env.py`` will overwrite any interim state with the final
    correct values.

    Args:
        metadata: The :class:`~sqlalchemy.MetaData` to check.
        name: The PostgreSQL extension name to require.

    Raises:
        PGCraftValidationError: If *name* is not declared and cannot
            be resolved from the registered config.

    """
    holder = PGExtensions.extract(metadata)
    if holder is not None and any(e.name == name for e in holder.extensions):
        return

    # Declarative flow: the config is present but configure_metadata hasn't
    # been called yet.  Run extension hooks eagerly so the check can proceed.
    cfg = metadata.info.get("pgcraft_config")
    if cfg is not None:
        for ext in cfg._resolved_extensions():  # noqa: SLF001
            ext.configure_metadata(metadata)
        holder = PGExtensions.extract(metadata)
        if holder is not None and any(
            e.name == name for e in holder.extensions
        ):
            return

    msg = (
        f"Plugin requires PostgreSQL extension {name!r}, but it is not "
        f"declared in metadata.  Register it via "
        f"register_pg_extension(metadata, PGExtension({name!r})) or "
        f"config.use(PGCronExtension()) for pg_cron."
    )
    raise PGCraftValidationError(msg)


def register_pg_extension(
    metadata: MetaData,
    ext: PGExtension,
) -> None:
    """Store *ext* in *metadata* for Alembic autogenerate.

    Args:
        metadata: SQLAlchemy :class:`~sqlalchemy.MetaData` to
            register on.
        ext: The extension to register.

    """
    holder: PGExtensions | None = metadata.info.get("pg_extensions")
    if holder is None:
        holder = PGExtensions()
        metadata.info["pg_extensions"] = holder
    holder.extensions.append(ext)


# ---------------------------------------------------------------------------
# Alembic integration
# ---------------------------------------------------------------------------


@dataclass
class CreateExtensionOp(MigrateOperation):
    """Alembic operation: create a PostgreSQL extension.

    Inherits from :class:`alembic.operations.ops.MigrateOperation`
    so that pgcraft's Alembic rewriter passes it through during
    ``process_revision_directives`` traversal without error.
    """

    extension: PGExtension

    def to_sql(self) -> list[str]:
        """Return the DDL statement for this operation."""
        return [self.extension.to_sql_create()]

    def reverse(self) -> "CreateExtensionOp":
        """Return a no-op downgrade: extensions are never dropped automatically.

        The downgrade renderer emits a SQL comment instead of a DROP
        statement so that autogenerate does not accidentally remove an
        extension that other objects may depend on.
        """
        return self


def _fetch_current_extensions(connection: "Connection") -> set[str]:
    """Return extension names currently installed in the database.

    Args:
        connection: Active database connection.

    Returns:
        Set of installed extension names.

    """
    from sqlalchemy import text  # noqa: PLC0415

    rows = connection.execute(
        text("SELECT extname FROM pg_extension")
    ).fetchall()
    return {row.extname for row in rows}


def register_pg_extension_alembic_events() -> None:
    """Register pgcraft's extension comparator and renderer with Alembic.

    Call once in ``env.py`` alongside
    :func:`~pgcraft.alembic.register.pgcraft_alembic_hook`::

        from pgcraft.pg_extension import register_pg_extension_alembic_events
        register_pg_extension_alembic_events()

    Safe to call multiple times; subsequent calls are no-ops.
    """
    global _alembic_registered  # noqa: PLW0603
    if _alembic_registered:
        return
    _alembic_registered = True

    from alembic.autogenerate.api import AutogenContext  # noqa: PLC0415
    from alembic.autogenerate.compare import comparators  # noqa: PLC0415
    from alembic.autogenerate.render import renderers  # noqa: PLC0415
    from alembic.operations.ops import UpgradeOps  # noqa: PLC0415

    def _compare_extensions(
        autogen_context: AutogenContext,
        upgrade_ops: UpgradeOps,
        _schemas: object,
    ) -> None:
        holder = PGExtensions.extract(autogen_context.metadata)
        if not holder:
            return
        assert autogen_context.connection is not None  # noqa: S101
        current = _fetch_current_extensions(autogen_context.connection)
        seen: set[str] = set()
        for ext in holder.extensions:
            if ext.name in seen:
                continue
            seen.add(ext.name)
            if ext.name not in current:
                upgrade_ops.ops.append(CreateExtensionOp(extension=ext))

    def _render_extension_op(
        _autogen_context: AutogenContext,
        op: CreateExtensionOp,
    ) -> list[str]:
        return [f'op.execute("{cmd}")' for cmd in op.to_sql()]

    comparators.dispatch_for("schema")(_compare_extensions)
    renderers.dispatch_for(CreateExtensionOp)(_render_extension_op)
