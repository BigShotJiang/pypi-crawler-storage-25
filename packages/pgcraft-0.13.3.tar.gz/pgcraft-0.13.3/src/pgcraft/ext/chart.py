"""Chart extension for pgcraft ledgers.

:class:`ChartExtension` wires the :func:`pgcraft_date_bin
<pgcraft.ext.ledger.date_bin.construct_pgcraft_date_bin_function>` polyfill
into the pgcraft lifecycle.  Register it on a
:class:`~pgcraft.config.PGCraftConfig` to make the ledger chart
function builders usable::

    from pgcraft.config import PGCraftConfig
    from pgcraft.ext.chart import ChartExtension

    config = PGCraftConfig()
    config.use(ChartExtension())

After registration, ``pgcraft_date_bin`` lives in the extension's
schema (``"pgcraft"`` by default).  The ledger chart function
builders find it via ``metadata.info["pgcraft_chart_schema"]`` and
call into it with the correct schema qualification.

Without this extension, the chart function builders raise
:class:`~pgcraft.errors.PGCraftValidationError` with a message
pointing the user at ``config.use(ChartExtension())``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from sqlalchemy_declarative_extensions import (
    Schemas,
    register_function,
)
from sqlalchemy_declarative_extensions.dialects.postgresql import (
    Function,
    FunctionSecurity,
    FunctionVolatility,
)

from pgcraft.errors import PGCraftValidationError
from pgcraft.ext.ledger.date_bin import construct_pgcraft_date_bin_function
from pgcraft.extension import PGCraftExtension

if TYPE_CHECKING:
    from sqlalchemy import MetaData

__all__ = [
    "CHART_EXTENSION_NAME",
    "CHART_SCHEMA_KEY",
    "ChartExtension",
    "assert_chart_extension_declared",
]


CHART_EXTENSION_NAME = "pgcraft-chart"
"""Canonical name for :class:`ChartExtension`."""

CHART_SCHEMA_KEY = "pgcraft_chart_schema"
"""``metadata.info`` key holding the chart extension's schema."""


@dataclass
class ChartExtension(PGCraftExtension):
    """Register the ``pgcraft_date_bin`` polyfill into metadata.

    When registered on a :class:`~pgcraft.config.PGCraftConfig`:

    - ``configure_metadata`` creates :func:`pgcraft_date_bin
      <pgcraft.ext.ledger.date_bin.construct_pgcraft_date_bin_function>`
      in *schema* and stores *schema* under
      ``metadata.info["pgcraft_chart_schema"]`` so the ledger chart
      function builders can resolve the helper without a
      user-supplied override.
    - *schema* is also added to ``metadata.info["schemas"]`` so
      Alembic autogenerate creates it.

    Ledger chart function builders
    (:func:`~pgcraft.ext.ledger.chart_functions.construct_ledger_chart_function`
    and friends) call :func:`assert_chart_extension_declared`
    internally and raise :class:`~pgcraft.errors.PGCraftValidationError`
    when this extension is absent.

    Args:
        name: Extension name.  Defaults to ``"pgcraft-chart"``.
        schema: Schema in which the polyfill function lives.
            Defaults to ``"pgcraft"``.

    """

    name: str = CHART_EXTENSION_NAME
    schema: str = "pgcraft"

    def configure_metadata(self, metadata: MetaData) -> None:
        """Register the polyfill, schema, and marker on *metadata*."""
        existing_schemas: Schemas | None = metadata.info.get("schemas")
        if existing_schemas is None:
            metadata.info["schemas"] = Schemas(ignore_unspecified=True).are(
                self.schema
            )
        else:
            # ``Schemas.are(...)`` replaces the tuple rather than merging.
            # Accumulate so earlier-registered schemas (from tables/views)
            # survive this call.
            names = {s.name for s in existing_schemas.schemas}
            names.add(self.schema)
            metadata.info["schemas"] = existing_schemas.are(*sorted(names))

        metadata.info[CHART_SCHEMA_KEY] = self.schema

        spec = construct_pgcraft_date_bin_function()
        existing_fns = metadata.info.get("functions")
        if existing_fns is not None:
            for fn in existing_fns:
                if fn.name == spec["name"] and fn.schema == self.schema:
                    return
        register_function(
            metadata,
            Function(
                spec["name"],
                spec["definition"],
                returns=spec.get("returns", "void"),
                language=spec.get("language", "sql"),
                schema=self.schema,
                parameters=spec.get("parameters", []),
                security=spec.get("security", FunctionSecurity.invoker),
                volatility=spec.get("volatility", FunctionVolatility.VOLATILE),
            ),
        )


def assert_chart_extension_declared(metadata: MetaData) -> None:
    """Raise if :class:`ChartExtension` is not registered on *metadata*.

    Called by the ledger chart function builders to give a clear
    error when the user forgot to register the extension on their
    :class:`~pgcraft.config.PGCraftConfig`.

    Mirrors :func:`~pgcraft.pg_extension.assert_pg_extension_declared`:
    if the marker is absent but a
    :class:`~pgcraft.config.PGCraftConfig` is present on
    ``metadata.info``, the config's extension hooks are run eagerly
    so the check can succeed.

    Args:
        metadata: The :class:`~sqlalchemy.MetaData` to check.

    Raises:
        PGCraftValidationError: If the extension is not declared
            and cannot be resolved from the registered config.

    """
    if metadata.info.get(CHART_SCHEMA_KEY):
        return

    cfg = metadata.info.get("pgcraft_config")
    if cfg is not None:
        for ext in cfg._resolved_extensions():  # noqa: SLF001
            ext.configure_metadata(metadata)
        if metadata.info.get(CHART_SCHEMA_KEY):
            return

    msg = (
        "Ledger chart functions require ChartExtension to be registered. "
        "Add `config.use(ChartExtension())` to your PGCraftConfig "
        "(from pgcraft.ext.chart import ChartExtension)."
    )
    raise PGCraftValidationError(msg)
