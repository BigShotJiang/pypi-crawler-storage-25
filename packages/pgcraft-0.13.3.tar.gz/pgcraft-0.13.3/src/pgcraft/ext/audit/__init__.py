r"""Audit/history query helpers.

These helpers return SQLAlchemy :class:`~sqlalchemy.Select`\ s without
registering anything on metadata.  Pass the result to
:class:`~pgcraft.views.view.PGCraftPlainView` (or
:class:`~pgcraft.views.view.PGCraftMaterializedView`) to expose it as
a view, or execute it directly against a connection.

Two dimension layouts are supported, each with its own pair of
helpers:

- **Append-only (SCD Type 2)** -- :func:`construct_append_only_diff_query`,
  :func:`construct_append_only_changed_between_query`.  Each row is a full
  version.  For
  :class:`~pgcraft.factory.dimension.append_only.PGCraftAppendOnly`
  factories, pass ``factory.ctx["attributes"]``.
- **EAV** -- :func:`construct_eav_diff_query`,
  :func:`construct_eav_changed_between_query`.  Each row is one attribute's
  value at a point in time.  For
  :class:`~pgcraft.factory.dimension.eav.PGCraftEAV` factories, pass
  ``factory.ctx["attribute"]``.
"""

from pgcraft.ext.audit.queries import (
    construct_append_only_changed_between_query,
    construct_append_only_diff_query,
    construct_eav_changed_between_query,
    construct_eav_diff_query,
)

__all__ = [
    "construct_append_only_changed_between_query",
    "construct_append_only_diff_query",
    "construct_eav_changed_between_query",
    "construct_eav_diff_query",
]
