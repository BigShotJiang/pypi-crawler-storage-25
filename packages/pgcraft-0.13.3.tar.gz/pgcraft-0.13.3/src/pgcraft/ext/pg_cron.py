"""pg_cron extension for pgcraft.

:class:`PGCronExtension` wires pg_cron support into the pgcraft
lifecycle.  Register it on a :class:`~pgcraft.config.PGCraftConfig` to
enable declarative cron job scheduling via
:class:`~pgcraft.ext.cron.base.CronJob` and
:class:`~pgcraft.ext.refresh.plugin.IncrementalRefreshPlugin`.

Usage::

    from pgcraft.config import PGCraftConfig
    from pgcraft.ext.pg_cron import PGCronExtension

    config = PGCraftConfig()
    config.use(PGCronExtension())

After registration, any :class:`~pgcraft.ext.cron.base.CronJob` stored in
metadata (e.g. by :class:`~pgcraft.ext.refresh.plugin.IncrementalRefreshPlugin`
with a ``schedule`` argument) will be diffed against the live ``cron.job``
table during ``alembic revision --autogenerate``.  Alembic emits
``op.execute("SELECT cron.schedule(...)")`` for new or changed jobs.

The extension also auto-declares the ``pg_cron`` PostgreSQL extension in
metadata so that the Alembic comparator can emit
``CREATE EXTENSION IF NOT EXISTS pg_cron CASCADE`` when needed.

Convenience re-exports::

    from pgcraft.ext.pg_cron import (
        PGCronExtension,
        CronJob,
        register_cron_job,
        PGExtension,
        register_pg_extension,
    )
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from pgcraft.ext.cron.base import CronJob, register_cron_job
from pgcraft.extension import PGCraftExtension
from pgcraft.pg_extension import PGExtension, register_pg_extension

if TYPE_CHECKING:
    from sqlalchemy import MetaData

__all__ = [
    "CronJob",
    "PGCronExtension",
    "PGExtension",
    "register_cron_job",
    "register_pg_extension",
]

_PG_CRON_EXTENSION = PGExtension("pg_cron", schema="cron", cascade=True)


@dataclass
class PGCronExtension(PGCraftExtension):
    """Wire pg_cron support into the pgcraft lifecycle.

    When registered on a :class:`~pgcraft.config.PGCraftConfig`:

    - ``configure_metadata`` declares ``pg_cron`` as a required
      PostgreSQL extension so Alembic can create it when absent.
    - ``configure_alembic`` registers the cron job comparator and
      renderer so ``alembic revision --autogenerate`` emits
      ``SELECT cron.schedule(...)`` for new or changed jobs, and
      the extension comparator so
      ``CREATE EXTENSION IF NOT EXISTS pg_cron CASCADE`` is emitted
      when pg_cron is missing.

    Plugins that use pg_cron (e.g.
    :class:`~pgcraft.ext.refresh.plugin.IncrementalRefreshPlugin` with a
    ``schedule`` argument) call
    :func:`~pgcraft.pg_extension.assert_pg_extension_declared` to
    verify this extension is registered, giving a clear error message
    when it is absent.

    Args:
        name: Extension name.  Defaults to ``"pg_cron"``.

    """

    name: str = "pg_cron"

    def configure_metadata(self, metadata: MetaData) -> None:
        """Declare pg_cron as a required PostgreSQL extension."""
        register_pg_extension(metadata, _PG_CRON_EXTENSION)

    def configure_alembic(self) -> None:
        """Register cron and extension Alembic comparators/renderers."""
        from pgcraft.ext.cron.alembic import (  # noqa: PLC0415
            register_cron_alembic_events,
        )
        from pgcraft.pg_extension import (  # noqa: PLC0415
            register_pg_extension_alembic_events,
        )

        register_cron_alembic_events()
        register_pg_extension_alembic_events()
