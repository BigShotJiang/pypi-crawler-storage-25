"""Pre-built features composed from pgcraft primitives.

Each submodule under :mod:`pgcraft.ext` bundles tables, views,
functions, plugins, and extensions that solve a specific problem
(ledgers, audit queries, state machines, materialized-view refresh,
cron, row-level security, PostgREST, etc.) using the declarative
primitives exposed at the top level of :mod:`pgcraft`.

Import the specific submodule you need — this package does not
re-export symbols.
"""
