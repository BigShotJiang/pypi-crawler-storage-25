"""Function spec builder for ledger factories.

Provides :func:`ledger_event_function` which compiles a
:class:`~pgcraft.ext.ledger.events.LedgerEvent` into a
:class:`LedgerFunctionSpec` ready to unpack into
:class:`~pgcraft.functions.PGCraftFunction`.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, NotRequired, TypedDict

from sqlalchemy.dialects import postgresql as pg_dialect
from sqlalchemy_declarative_extensions.dialects.postgresql import (
    FunctionSecurity,
    FunctionVolatility,
)

if TYPE_CHECKING:
    from sqlalchemy import Column, Table

    from pgcraft.factory.context import ContextSource

from pgcraft.errors import PGCraftValidationError
from pgcraft.ext.ledger.events import (
    LedgerEvent,
    ParamCollector,
    _desired_table_ref,
    _input_table_ref,
)
from pgcraft.utils.query import compile_query
from pgcraft.utils.template import load_template

_TEMPLATES = (
    Path(__file__).resolve().parents[2] / "plugins" / "templates" / "ledger"
)


def _pg_type_str(col: Column) -> str:
    """Return the PostgreSQL type string for *col*.

    Args:
        col: A SQLAlchemy :class:`~sqlalchemy.Column`.

    Returns:
        Compiled PostgreSQL type string.

    """
    return col.type.compile(dialect=pg_dialect.dialect())


class LedgerFunctionSpec(TypedDict):
    """Specification for a ledger PostgreSQL function.

    Returned by :func:`ledger_event_function`.  Pass directly as
    ``__funcspec__`` on a :class:`~pgcraft.declarative.PGCraftFunctionMixin`
    subclass::

        class InventoryAdjust(PGCraftFunctionMixin, Base):
            __table_args__ = {"schema": "private"}
            __funcspec__ = ledger_event_function(inventory, adjust_event)

    Attributes:
        name: Unqualified function name.
        definition: SQL function body.
        parameters: List of ``FunctionParam`` instances.
        returns: Return type string (e.g. ``"SETOF schema.table"``).
        security: Security mode.
        volatility: Optional volatility
            (``STABLE`` / ``IMMUTABLE`` / ``VOLATILE``).
            Defaults to ``VOLATILE`` when omitted.

    Note:
        Schema is intentionally excluded. Pass it via ``__table_args__``
        (declarative) or read it from ``source.ctx.schemaname``
        (imperative).

    """

    name: str
    definition: str
    language: str
    parameters: list
    returns: str
    security: FunctionSecurity
    volatility: NotRequired[FunctionVolatility]


def _validate_single_event(
    event: LedgerEvent,
    root_table: Table,
) -> None:
    """Validate one event against the root table columns.

    Args:
        event: The event to validate.
        root_table: The ledger backing table.

    Raises:
        PGCraftValidationError: If any validation rule is violated.

    """
    if event.desired is not None and not event.diff_keys:
        msg = (
            f"LedgerEvent {event.name!r}: "
            f"diff_keys is required when desired is set."
        )
        raise PGCraftValidationError(msg)

    if event.existing is not None and event.desired is None:
        msg = (
            f"LedgerEvent {event.name!r}: existing requires desired to be set."
        )
        raise PGCraftValidationError(msg)

    col_names = {c.key for c in root_table.columns}
    for key in event.diff_keys:
        if key not in col_names:
            msg = (
                f"LedgerEvent {event.name!r}: "
                f"diff_key {key!r} is not a column on "
                f"the ledger table.  Available columns: "
                f"{sorted(col_names)}"
            )
            raise PGCraftValidationError(msg)


def ledger_event_function(
    source: ContextSource,
    event: LedgerEvent,
    *,
    view_key: str = "api",
) -> LedgerFunctionSpec:
    """Build a :class:`LedgerFunctionSpec` for a single ledger event.

    The spec contains the SQL function body generated from the event
    lambdas and all metadata needed to register a PostgreSQL function
    via :class:`~pgcraft.functions.PGCraftFunction`.

    Args:
        source: A :class:`~pgcraft.factory.ledger.PGCraftLedger`
            instance or a :class:`~pgcraft.declarative.PGCraftBase`
            subclass using ``PGCraftLedger`` as its factory.
        event: The :class:`~pgcraft.ext.ledger.events.LedgerEvent` to
            compile into a function.
        view_key: Context key for the API view (default ``"api"``).

    Returns:
        A :class:`LedgerFunctionSpec` ready to pass to
        :class:`~pgcraft.functions.PGCraftFunction`.

    Raises:
        PGCraftValidationError: If event configuration is invalid.

    """
    ctx = source.ctx
    # raw_table: the backing table.  Used for the INSERT (bypasses the
    # INSTEAD OF trigger so all rows land in one statement, which is
    # required for the double-entry balance check).
    raw_table: Table = ctx["raw_table"]
    # view_table (__root__): the writable view over raw_table.  Used for
    # the RETURNS type so the function is created AFTER the table (views
    # are created after tables in migration ordering).
    view_table: Table = ctx["__root__"]
    api_view = ctx[view_key]
    schema: str = ctx.schemaname

    _validate_single_event(event, raw_table)

    api_view_fullname = f"{api_view.schema or 'api'}.{ctx.tablename}"
    backing_table = f"{schema}.{raw_table.name}"

    # Run input lambda with ParamCollector.
    collector = ParamCollector()
    input_select = event.input(collector)
    input_sql = compile_query(input_select)

    template_ctx: dict = {
        "input_sql": input_sql,
        "api_view": api_view_fullname,
        "backing_table": backing_table,
        "diff_mode": event.desired is not None,
    }

    if event.desired is not None:
        # Build input table ref and run desired.
        input_ref = _input_table_ref(input_select)
        desired_select = event.desired(input_ref)
        desired_sql = compile_query(desired_select)

        # Build desired table ref and run existing.
        desired_ref = _desired_table_ref(desired_select)

        if event.existing is not None:
            existing_select = event.existing(raw_table, desired_ref)
            existing_sql = compile_query(existing_select)
        else:
            # No existing: empty select with same columns.
            existing_sql = (
                "SELECT "
                + ", ".join(
                    f"NULL::{_pg_type_str(raw_table.c[k])}"
                    if k in {c.key for c in raw_table.columns}
                    else "NULL"
                    for k in [
                        col.name for col in desired_select.selected_columns
                    ]
                )
                + " WHERE false"
            )

        # Compute column lists.
        desired_col_names = [
            col.name for col in desired_select.selected_columns
        ]
        all_cols = list(desired_col_names)

        # Existing cols: diff_keys + value, with NULL
        # padding for any extra columns (e.g. reason).
        existing_col_names = (
            [col.name for col in existing_select.selected_columns]
            if event.existing is not None
            else []
        )
        existing_cols_padded: list[str] = []
        for col_name in all_cols:
            if col_name in existing_col_names:
                existing_cols_padded.append(col_name)
            else:
                existing_cols_padded.append(f"NULL AS {col_name}")

        # Passthrough cols: in desired but not diff_keys or value.
        passthrough_cols = [
            c
            for c in desired_col_names
            if c not in event.diff_keys and c != "value"
        ]

        template_ctx.update(
            desired_sql=desired_sql,
            existing_sql=existing_sql,
            all_cols=all_cols,
            desired_cols=", ".join(desired_col_names),
            existing_cols=", ".join(existing_cols_padded),
            diff_keys=list(event.diff_keys),
            passthrough_cols=passthrough_cols,
        )
    else:
        # Simple mode: columns from input select.
        all_cols = [col.name for col in input_select.selected_columns]
        template_ctx["all_cols"] = all_cols

    fn_body: str = load_template(_TEMPLATES / "event.plpgsql.mako").render(
        **template_ctx
    )

    fn_name = f"{schema}_{ctx.tablename}_{event.name}"

    return LedgerFunctionSpec(
        name=fn_name,
        definition=fn_body,
        language="plpgsql",
        parameters=collector.function_params,
        returns=f"SETOF {schema}.{view_table.name}",
        security=FunctionSecurity.definer,
    )
