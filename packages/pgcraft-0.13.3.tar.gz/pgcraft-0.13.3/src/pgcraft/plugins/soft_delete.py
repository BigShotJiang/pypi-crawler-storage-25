"""Soft-delete plugin for pgcraft dimensions.

Intercepts the INSTEAD OF DELETE trigger on the API view and converts
it into a timestamp-based soft-delete.  The API view is filtered to
hide soft-deleted rows, keeping the interface clean.

The exact soft-delete behaviour depends on the factory type:

- **Simple** (``table_key="raw_table"``): ``UPDATE raw_table SET
  deleted_at = now() WHERE id = OLD.id``.
- **AppendOnly** (``table_key="attributes"``): inserts a new attributes
  version with ``deleted_at = now()`` and updates the root FK pointer.
- **EAV**: not supported -- EAV entity tables are auto-generated and
  do not expose user columns.  Use a wrapping view or a dedicated
  ``deleted_at`` in the EAV schema instead.
- **Ledger**: not applicable -- ledger rows are immutable by design.

Usage::

    # Simple dimension
    class Users(Base):
        __tablename__ = "users"
        __table_args__ = {"schema": "public"}
        __plugins__ = [SoftDeletePlugin()]

        name = Column(String, nullable=False)
        deleted_at = Column(DateTime(timezone=True), nullable=True)

    # AppendOnly dimension
    class Students(Base):
        __tablename__ = "students"
        __table_args__ = {"schema": "public"}
        __factory__ = PGCraftAppendOnly
        __plugins__ = [SoftDeletePlugin(table_key="attributes")]

        name = Column(String, nullable=False)
        deleted_at = Column(DateTime(timezone=True), nullable=True)

The ``deleted_at`` column **must** be declared on the model with
``nullable=True``.  The plugin will raise
:class:`~pgcraft.errors.PGCraftValidationError` if it is absent or
non-nullable.

After soft-deletion the row remains in the backing table with
``deleted_at`` set.  The view ``{tablename}`` only shows rows where
``deleted_at IS NULL``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import DateTime

from pgcraft.errors import PGCraftValidationError
from pgcraft.plugin import Dynamic, Plugin, produces, requires

if TYPE_CHECKING:
    from pgcraft.factory.context import FactoryContext


@produces("deleted_at_column")
@requires("primary", Dynamic("table_key"))
class SoftDeletePlugin(Plugin):
    """Convert physical deletes into ``deleted_at`` timestamp updates.

    Validates that the nominated *column_name* exists and is a
    nullable ``DateTime`` column in the nominated backing table,
    stores ``ctx["deleted_at_column"]`` so the factory's
    ``InsteadOfTriggerPlugin`` ops builder can use a soft-delete
    template, and patches the registered view to add a
    ``WHERE deleted_at IS NULL`` filter.

    Ordering: placed in ``extra_plugins`` so the topological sort
    positions it after the view plugin (needs ``primary``) but before
    :class:`~pgcraft.plugins.trigger.InsteadOfTriggerPlugin`
    (which reads ``deleted_at_column`` from ctx).

    Args:
        column_name: Name of the soft-delete timestamp column
            (default ``"deleted_at"``).
        table_key: Key in ``ctx`` for the table whose column is
            validated.  Use ``"raw_table"`` for
            :class:`~pgcraft.factory.dimension.simple.PGCraftSimple`
            (default) and ``"attributes"`` for
            :class:`~pgcraft.factory.dimension.append_only.PGCraftAppendOnly`.

    Raises:
        PGCraftValidationError: If *column_name* is missing from the
            target table, is not a ``DateTime`` column, or is
            ``NOT NULL``.

    """

    def __init__(
        self,
        column_name: str = "deleted_at",
        table_key: str = "raw_table",
    ) -> None:
        """Store the column name and target table key."""
        self.column_name = column_name
        self.table_key = table_key

    def run(self, ctx: FactoryContext) -> None:
        """Validate the column, store it in ctx, and patch the view."""
        table = ctx[self.table_key]
        col_names = {c.name for c in table.columns}

        if self.column_name not in col_names:
            msg = (
                f"SoftDeletePlugin: column {self.column_name!r} is not "
                f"present in table {table.name!r} "
                f"(table_key={self.table_key!r}).  Add "
                f"Column({self.column_name!r}, DateTime(timezone=True), "
                f"nullable=True) to the model."
            )
            raise PGCraftValidationError(msg)

        col = table.c[self.column_name]
        if not isinstance(col.type, DateTime):
            msg = (
                f"SoftDeletePlugin: column {self.column_name!r} must be "
                f"a DateTime column, got {type(col.type).__name__!r}."
            )
            raise PGCraftValidationError(msg)
        if not col.nullable:
            msg = (
                f"SoftDeletePlugin: column {self.column_name!r} must be "
                f"nullable=True so active rows have deleted_at IS NULL."
            )
            raise PGCraftValidationError(msg)

        # Store for the factory's InsteadOfTriggerPlugin ops_builder.
        ctx["deleted_at_column"] = self.column_name

        # Patch the already-registered view to filter soft-deleted rows.
        views_holder = ctx.metadata.info.get("views")
        if views_holder is not None:
            for view in views_holder.views:
                if view.name == ctx.tablename and view.schema == ctx.schemaname:
                    view.definition = (
                        view.definition.rstrip()
                        + f"\nWHERE {self.column_name} IS NULL"
                    )
                    break
