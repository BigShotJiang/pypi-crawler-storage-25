"""Declarative and imperative PostgreSQL function registration.

:class:`PGCraftFunction` works both imperatively and as a declarative
base class, mirroring how :class:`~pgcraft.declarative.PGCraftView`
and :class:`~pgcraft.views.view.PGCraftPlainView` work for views.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, ClassVar

from sqlalchemy_declarative_extensions import register_function
from sqlalchemy_declarative_extensions.dialects.postgresql import (
    Function,
    FunctionParam,
    FunctionSecurity,
    FunctionVolatility,
)

from pgcraft.declarative import _parse_table_args
from pgcraft.errors import PGCraftValidationError

if TYPE_CHECKING:
    from sqlalchemy import MetaData


@dataclass(frozen=True)
class FunctionOptions:
    """Options for :class:`PGCraftFunction` declarative subclasses.

    Set on a subclass via ``__options__``.

    Attributes:
        returns: Return type string.
        language: Function language (``"sql"``, ``"plpgsql"``, ...).
        parameters: List of ``FunctionParam`` instances from
            ``sqlalchemy_declarative_extensions.dialects.postgresql``.
        security: ``FunctionSecurity.invoker`` or
            ``FunctionSecurity.definer``.
        volatility: Volatility classification.

    """

    returns: str = "void"
    language: str = "sql"
    parameters: list[FunctionParam] = field(default_factory=list)
    security: FunctionSecurity = FunctionSecurity.invoker
    volatility: FunctionVolatility = FunctionVolatility.VOLATILE


class PGCraftFunction:
    """Register a PostgreSQL function on SQLAlchemy metadata.

    Works both imperatively (direct instantiation) and as a declarative
    base class (subclassing).

    **Imperative usage** (``metadata`` read from class when omitted)::

        class FunctionBase(PGCraftFunction):
            metadata = Base.metadata

        spec = ledger_event_function(source, event)
        FunctionBase(
            spec["name"],
            source.ctx.schemaname,
            spec["definition"],
            parameters=spec["parameters"],
            returns=spec["returns"],
            security=spec["security"],
        )

    Or with explicit metadata::

        PGCraftFunction(
            name="inventory_adjust",
            schema="private",
            definition="...",
            metadata=metadata,
            returns="SETOF private.inventory_raw",
            parameters=[...],
            security=FunctionSecurity.definer,
        )

    **Declarative usage:**

    .. code-block:: python

        class FunctionBase(PGCraftFunction):
            metadata = metadata

        class InventoryAdjust(FunctionBase):
            __funcname__ = "inventory_adjust"
            __table_args__ = {"schema": "private"}
            __definition__ = "..."
            __options__ = FunctionOptions(
                returns="SETOF private.inventory_raw",
                parameters=[...],
                security=FunctionSecurity.definer,
            )

    In both cases a
    ``sqlalchemy_declarative_extensions.dialects.postgresql.Function``
    is registered on the provided ``MetaData`` instance so that
    Alembic autogeneration picks it up.

    Args:
        name: Unqualified function name.
        schema: PostgreSQL schema.
        metadata: SQLAlchemy ``MetaData`` to register on.
        definition: SQL (or PL/pgSQL) function body.
        returns: Return type string (default ``"void"``).
        language: Function language (default ``"sql"``).
        parameters: List of ``FunctionParam`` instances from
            ``sqlalchemy_declarative_extensions.dialects.postgresql``
            (default ``[]``).
        security: Security mode — ``FunctionSecurity.invoker`` or
            ``FunctionSecurity.definer``
            (default ``FunctionSecurity.invoker``).
        volatility: Volatility classification
            (default ``FunctionVolatility.VOLATILE``).

    """

    # Set on project-level base subclasses by __init_subclass__.
    metadata: ClassVar[MetaData]
    # Set on declarative subclasses by __init_subclass__, and on
    # imperative instances by __init__.
    function: Function

    def __init__(  # noqa: PLR0913
        self,
        name: str,
        schema: str,
        definition: str,
        *,
        metadata: MetaData | None = None,
        returns: str = "void",
        language: str = "sql",
        parameters: list[FunctionParam] | None = None,
        security: FunctionSecurity = FunctionSecurity.invoker,
        volatility: FunctionVolatility = FunctionVolatility.VOLATILE,
    ) -> None:
        """Create and register the function.

        ``metadata`` may be omitted when called on a subclass that
        declares ``metadata`` as a class attribute::

            class FunctionBase(PGCraftFunction):
                metadata = Base.metadata

            FunctionBase(**ledger_event_function(source, event))

        """
        if metadata is None:
            for klass in type(self).__mro__:
                if "metadata" in klass.__dict__:
                    metadata = klass.__dict__["metadata"]
                    break
        if metadata is None:
            msg = (
                f"{type(self).__name__}: metadata must be provided "
                f"or set as a class attribute on the base class."
            )
            raise PGCraftValidationError(msg)
        fn = Function(
            name,
            definition,
            returns=returns,
            language=language,
            schema=schema,
            parameters=parameters or [],
            security=security,
            volatility=volatility,
        )
        register_function(metadata, fn)
        self.function = fn
        self.name = name
        self.schema = schema

    def __init_subclass__(cls, **kwargs: Any) -> None:  # noqa: ANN401
        """Register the function when a concrete subclass is defined."""
        super().__init_subclass__(**kwargs)

        # Direct subclasses of PGCraftFunction are project-level bases
        # (e.g. the user's ``FunctionBase``). Stop here.
        if PGCraftFunction in cls.__bases__:
            return

        # Skip intermediate classes that have no __funcname__.
        if not hasattr(cls, "__funcname__"):
            return

        # Resolve metadata from MRO (set on the base class).
        md: MetaData | None = None
        for klass in cls.__mro__:
            if "metadata" in klass.__dict__:
                md = klass.__dict__["metadata"]
                break
        if md is None:
            msg = (
                f"{cls.__name__}: base class must define "
                f"'metadata' before declaring function classes."
            )
            raise PGCraftValidationError(msg)

        schema, _ = _parse_table_args(cls)
        if schema is None:
            msg = (
                f"{cls.__name__} must specify a schema via "
                f"__table_args__ = {{'schema': '...'}} "
                f"or as the final dict in a tuple __table_args__."
            )
            raise PGCraftValidationError(msg)

        definition: str = getattr(cls, "__definition__", "")
        options: FunctionOptions = cls.__dict__.get(
            "__options__", FunctionOptions()
        )

        fn = Function(
            cls.__funcname__,
            definition,
            returns=options.returns,
            language=options.language,
            schema=schema,
            parameters=options.parameters,
            security=options.security,
            volatility=options.volatility,
        )
        register_function(md, fn)
        cls.function = fn
