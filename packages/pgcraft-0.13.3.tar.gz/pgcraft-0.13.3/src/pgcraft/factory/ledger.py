"""Ledger resource factory."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, ClassVar

from sqlalchemy import Column, DateTime, Integer, Numeric, Table, select, text
from sqlalchemy.dialects.postgresql import UUID

from pgcraft.errors import PGCraftValidationError
from pgcraft.factory.base import ResourceFactory
from pgcraft.plugin import Plugin, produces, requires, singleton
from pgcraft.plugins.check import TableCheckPlugin
from pgcraft.plugins.column_name import construct_column_name_plugin
from pgcraft.plugins.fk import TableFKPlugin
from pgcraft.plugins.index import TableIndexPlugin
from pgcraft.plugins.ledger import (
    _NAMING_DEFAULTS as _LEDGER_NAMING,
)
from pgcraft.plugins.protect import RawTableProtectionPlugin
from pgcraft.plugins.trigger import InsteadOfTriggerPlugin, TriggerOp
from pgcraft.plugins.view import ViewPlugin
from pgcraft.utils.naming import resolve_name
from pgcraft.utils.query import compile_query
from pgcraft.utils.template import load_template

if TYPE_CHECKING:
    from collections.abc import Callable

    from sqlalchemy import MetaData
    from sqlalchemy.schema import SchemaItem
    from sqlalchemy.types import TypeEngine

    from pgcraft.check import PGCraftCheck
    from pgcraft.factory.context import FactoryContext
    from pgcraft.index import PGCraftIndex
    from pgcraft.plugin import Plugin as PluginType

_TEMPLATES = (
    Path(__file__).resolve().parents[1] / "plugins" / "templates" / "ledger"
)

_VALUE_TYPES: dict[str, type[TypeEngine]] = {
    "integer": Integer,
    "numeric": Numeric,
}

_FACTORY_NAMING_DEFAULTS = {
    "ledger_raw_table": "%(table_name)s_raw",
}


@produces("entry_id_column")
@singleton("__entry_id__")
class UUIDEntryIDPlugin(Plugin):
    """Provide a UUIDv4 entry ID column for ledger tables.

    Stores a :class:`~sqlalchemy.Column` in ``ctx["entry_id_column"]``
    that downstream table plugins splice into the table definition.
    The column uses PostgreSQL's ``gen_random_uuid()`` as a server
    default so callers can omit it for single-entry inserts while
    still providing an explicit value to correlate multi-row entries.

    Args:
        column_name: Name of the entry ID column
            (default ``"entry_id"``).

    """

    def __init__(self, column_name: str = "entry_id") -> None:
        """Store the column name."""
        self._column_name = column_name

    def run(self, ctx: FactoryContext) -> None:
        """Store the entry ID column and inject it."""
        col = Column(
            self._column_name,
            UUID(as_uuid=True),
            nullable=False,
            server_default=text("gen_random_uuid()"),
        )
        ctx["entry_id_column"] = col
        ctx.injected_columns.append(col)


@produces("raw_table")
@requires("pk_columns", "entry_id_column", "created_at_column")
@singleton("__table__")
class LedgerTablePlugin(Plugin):
    """Create a ledger raw table with a value column.

    Combines ``ctx["pk_columns"]``, ``ctx.injected_columns``
    (provided by upstream plugins like ``UUIDEntryIDPlugin``,
    ``CreatedAtPlugin``, and ``DoubleEntryPlugin``), a ``value``
    column, and ``ctx.table_items`` (dimension columns) into a
    single append-only table named ``{tablename}_raw``.

    The writable view ``{tablename}`` is created by
    :func:`LedgerViewPlugin`.

    Args:
        value_type: Type for the value column. Must be
            ``"integer"`` or ``"numeric"`` (default ``"integer"``).

    Raises:
        PGCraftValidationError: If *value_type* is not a
            recognised type.

    """

    def __init__(
        self,
        value_type: str = "integer",
    ) -> None:
        """Store configuration."""
        if value_type not in _VALUE_TYPES:
            msg = (
                f"Unknown value_type {value_type!r}. "
                f"Must be one of: {sorted(_VALUE_TYPES)}"
            )
            raise PGCraftValidationError(msg)
        self.value_type = value_type

    def run(self, ctx: FactoryContext) -> None:
        """Create the ledger raw table and store it in ctx."""
        pk_columns = ctx["pk_columns"]
        created_at_col = ctx["created_at_column"]
        sa_type = _VALUE_TYPES[self.value_type]

        raw_name = resolve_name(
            ctx.metadata,
            "ledger_raw_table",
            {
                "table_name": ctx.tablename,
                "schema": ctx.schemaname,
            },
            _FACTORY_NAMING_DEFAULTS,
        )
        table = Table(
            raw_name,
            ctx.metadata,
            *pk_columns,
            *ctx.injected_columns,
            Column(
                created_at_col,
                DateTime(timezone=True),
                server_default="now()",
            ),
            Column("value", sa_type(), nullable=False),
            *ctx.table_items,
            schema=ctx.schemaname,
        )
        ctx["raw_table"] = table


def LedgerViewPlugin() -> ViewPlugin:  # noqa: N802
    """Create a configured ViewPlugin for ledger dimensions.

    Registers ``{tablename}`` as a view over ``{tablename}_raw``
    and stores the proxy in ``ctx["primary"]``.

    Returns:
        A :class:`~pgcraft.plugins.view.ViewPlugin` configured
        for ledger passthrough views.

    """

    def _query(ctx: FactoryContext) -> str:
        raw = ctx["raw_table"]
        return compile_query(select(raw))

    def _proxy(ctx: FactoryContext) -> list[Column]:
        raw = ctx["raw_table"]
        return [
            Column(c.name, c.type, primary_key=c.primary_key)
            for c in raw.columns
        ]

    return ViewPlugin(
        query_builder=_query,
        proxy_builder=_proxy,
        extra_requires=[
            "raw_table",
            "pk_columns",
            "entry_id_column",
            "created_at_column",
        ],
    )


def _make_ledger_ops_builder(
    table_key: str,
    view_key: str,
) -> Callable[[FactoryContext], list[TriggerOp]]:
    """Return an ops builder for ledger dimensions."""

    def build(ctx: FactoryContext) -> list[TriggerOp]:
        raw_table = ctx[table_key]
        base_fullname = f"{ctx.schemaname}.{raw_table.name}"
        entry_id_col = ctx["entry_id_column"]
        dim_cols = ctx.dim_column_names

        # Include injected columns that have no server default and are not
        # entry_id (already handled). This picks up e.g. the `direction`
        # column added by DoubleEntryPlugin which must be provided by the
        # caller — unlike `created_at` which has a server default.
        injected_writable = [
            col.key
            for col in ctx.injected_columns
            if col.key != entry_id_col.name and col.server_default is None
        ]
        all_cols = [
            entry_id_col.name,
            "value",
            *dim_cols,
            *injected_writable,
        ]
        new_col_exprs = []
        for c in all_cols:
            if c == entry_id_col.name:
                default = entry_id_col.server_default.arg.text
                new_col_exprs.append(f"COALESCE(NEW.{c}, {default})")
            else:
                new_col_exprs.append(f"NEW.{c}")

        view_proxy = ctx[view_key]
        view_schema = view_proxy.schema or ctx.schemaname
        view_fullname = f"{view_schema}.{ctx.tablename}"
        template_vars = {
            "base_table": base_fullname,
            "cols": ", ".join(all_cols),
            "new_cols": ", ".join(new_col_exprs),
            "view": view_fullname,
        }

        return [
            TriggerOp(
                "insert",
                load_template(_TEMPLATES / "insert.plpgsql.mako").render(
                    **template_vars
                ),
            ),
            TriggerOp(
                "update",
                load_template(_TEMPLATES / "reject_update.plpgsql.mako").render(
                    **template_vars
                ),
            ),
            TriggerOp(
                "delete",
                load_template(_TEMPLATES / "reject_delete.plpgsql.mako").render(
                    **template_vars
                ),
            ),
        ]

    return build


class PGCraftLedger(ResourceFactory):
    """Create a ledger: append-only table with a value column.

    Internal plugins (always present):

    1. :class:`UUIDEntryIDPlugin` -- UUID entry ID for correlating
       related entries.
    2. :class:`~pgcraft.plugins.column_name.construct_column_name_plugin` --
       ``created_at`` column name.
    3. :class:`LedgerTablePlugin` -- raw backing table
       (``{tablename}_raw``).
    4. :class:`LedgerViewPlugin` -- writable view (``{tablename}``).
    5. :class:`~pgcraft.plugins.protect.RawTableProtectionPlugin` --
       blocks direct DML on the raw table.
    6. :class:`~pgcraft.plugins.trigger.InsteadOfTriggerPlugin`
       -- INSTEAD OF triggers on the dimension view.

    A :class:`~pgcraft.plugins.pk.SerialPKPlugin` is auto-added
    when no user plugin produces ``pk_columns``.

    Pass a
    :class:`~pgcraft.ext.postgrest.plugin.PostgRESTPlugin`
    via ``extra_plugins`` to expose this table through a
    PostgREST API view with INSERT triggers.
    Use :func:`~pgcraft.ext.ledger.queries.construct_ledger_balance_query`,
    :func:`~pgcraft.ext.ledger.queries.construct_ledger_latest_query`, and
    :func:`~pgcraft.ext.ledger.functions.ledger_event_function` with
    :class:`~pgcraft.functions.PGCraftFunction` for derived
    views and event functions.

    """

    _FK_TARGET_KEY: ClassVar[str] = "raw_table"

    _INTERNAL_PLUGINS: ClassVar[list[PluginType]] = [
        UUIDEntryIDPlugin(),
        construct_column_name_plugin("created_at_column", "created_at"),
        LedgerTablePlugin(),
        LedgerViewPlugin(),
        TableCheckPlugin("raw_table"),
        TableIndexPlugin("raw_table"),
        TableFKPlugin("raw_table"),
        RawTableProtectionPlugin("raw_table"),
        InsteadOfTriggerPlugin(
            ops_builder=_make_ledger_ops_builder("raw_table", "primary"),
            naming_defaults=_LEDGER_NAMING,
            function_key="ledger_function",
            trigger_key="ledger_trigger",
            view_key="primary",
            extra_requires=[
                "raw_table",
                "entry_id_column",
            ],
        ),
    ]

    def __init__(  # noqa: PLR0913
        self,
        tablename: str,
        schemaname: str,
        metadata: MetaData,
        schema_items: list[SchemaItem | PGCraftCheck | PGCraftIndex],
        *,
        config: object | None = None,
        plugins: list[PluginType] | None = None,
        extra_plugins: list[PluginType] | None = None,
    ) -> None:
        """Create the ledger and register it on *metadata*.

        Args:
            tablename: Name of the ledger table.
            schemaname: PostgreSQL schema for generated objects.
            metadata: SQLAlchemy ``MetaData`` to register on.
            schema_items: Dimension column definitions.
            config: Optional global config.
            plugins: If given, replaces ``DEFAULT_PLUGINS``.
            extra_plugins: Appended to resolved plugin list.

        """
        super().__init__(
            tablename,
            schemaname,
            metadata,
            schema_items,
            config=config,
            plugins=plugins,
            extra_plugins=extra_plugins,
        )
