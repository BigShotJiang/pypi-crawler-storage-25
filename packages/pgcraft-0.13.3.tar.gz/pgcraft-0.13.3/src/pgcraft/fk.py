"""Foreign key support for pgcraft dimensions.

Provides :class:`PGCraftForeignKey` — an inline single-column FK
passed directly to a ``Column(...)`` constructor, analogous to
SQLAlchemy's ``ForeignKey``.  Accepts either a two-part
``"dimension.column"`` reference (resolved via the registry) or a
fully-qualified ``"schema.table.column"`` reference.

"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from sqlalchemy.sql.schema import SchemaItem

from pgcraft.errors import PGCraftValidationError

if TYPE_CHECKING:
    from sqlalchemy import MetaData
    from sqlalchemy.sql.base import SchemaEventTarget


@dataclass(frozen=True)
class DimensionRef:
    """Registry entry for a dimension's FK-targetable table.

    Stored in ``metadata.info["pgcraft_dimensions"]`` keyed by
    dimension name (``tablename``).

    Args:
        schema: PostgreSQL schema name.
        table: Physical table name for FK targets.

    """

    schema: str
    table: str


def register_dimension(
    metadata: MetaData,
    name: str,
    ref: DimensionRef,
) -> None:
    """Register a dimension for FK resolution.

    Args:
        metadata: SQLAlchemy MetaData instance.
        name: Dimension name (``tablename``).
        ref: The dimension's FK target info.

    """
    registry: dict[str, DimensionRef] = metadata.info.setdefault(
        "pgcraft_dimensions", {}
    )
    registry[name] = ref


def resolve_fk_reference(
    metadata: MetaData,
    reference: str,
) -> str:
    """Resolve a ``"dimension.column"`` reference.

    Looks up the dimension name in the registry and expands it
    to ``"schema.table.column"``.

    Args:
        metadata: SQLAlchemy MetaData for registry lookup.
        reference: Two-part ``"dimension.column"`` string.

    Returns:
        Fully qualified ``"schema.table.column"`` string.

    Raises:
        PGCraftValidationError: If the reference does not
            contain exactly one dot, or names an unknown
            dimension.

    """
    parts = reference.split(".")
    if len(parts) != 2:  # noqa: PLR2004
        msg = (
            f"FK reference {reference!r} must be "
            f"'dimension.column' format. "
            f"Use PGCraftForeignKey with a three-part "
            f"'schema.table.column' reference instead."
        )
        raise PGCraftValidationError(msg)

    dim_name, col_name = parts
    registry: dict[str, DimensionRef] = metadata.info.get(
        "pgcraft_dimensions", {}
    )
    if dim_name not in registry:
        known = sorted(registry)
        msg = (
            f"FK reference {reference!r} names unknown "
            f"dimension {dim_name!r}. "
            f"Known dimensions: {known}. "
            f"Use a three-part 'schema.table.column' reference "
            f"for tables outside pgcraft."
        )
        raise PGCraftValidationError(msg)

    ref = registry[dim_name]
    return f"{ref.schema}.{ref.table}.{col_name}"


_INLINE_FK_INFO_KEY = "pgcraft_fks"


class PGCraftForeignKey(SchemaItem):
    """Inline single-column FK with pgcraft dimension resolution.

    Pass directly to a ``Column`` constructor like SQLAlchemy's
    ``ForeignKey``.  The *reference* string accepts two formats:

    - ``"dimension.column"`` — resolved via the dimension registry
      at factory time (two dot-separated parts)::

          Column("user_id", Integer, PGCraftForeignKey("users.id"))

    - ``"schema.table.column"`` — passed through directly::

          Column("user_id", Integer,
                 PGCraftForeignKey("public.users_raw.id"))

    Args:
        reference: Target reference string.
        ondelete: ON DELETE action (e.g. ``"CASCADE"``).
        onupdate: ON UPDATE action (e.g. ``"CASCADE"``).

    """

    inherit_cache = False
    __visit_name__ = "pgcraft_foreign_key"

    def __init__(
        self,
        reference: str,
        *,
        ondelete: str | None = None,
        onupdate: str | None = None,
    ) -> None:
        """Store the reference and optional referential actions."""
        self.reference = reference
        self.ondelete = ondelete
        self.onupdate = onupdate

    def _set_parent(
        self,
        parent: SchemaEventTarget,
        **_kwargs: Any,  # noqa: ANN401
    ) -> None:
        """Attach this FK marker to the parent column's info dict."""
        # pgcraft only uses this marker on Column objects.
        from sqlalchemy import Column  # noqa: PLC0415

        assert isinstance(parent, Column)  # noqa: S101
        parent.info.setdefault(_INLINE_FK_INFO_KEY, []).append(self)

    def __repr__(self) -> str:
        """Return a readable representation."""
        return f"PGCraftForeignKey({self.reference!r})"
