"""pgcraft: configuration-driven PostgreSQL framework.

This top-level module exposes only the declarative primitives you
compose to describe a schema (bases, views, columns, foreign keys,
indexes, checks, types, plugin/extension base classes, config).

Three-bucket boundary:

* Declarative primitives — right here at :mod:`pgcraft`.
* Migration glue — see :mod:`pgcraft.alembic` (wired into your
  project's ``env.py``).
* Pre-built features composed from the primitives — see
  :mod:`pgcraft.ext` (ledgers, audit, state machines, refresh,
  cron, row-level security, PostgREST, etc.).
"""

from pgcraft.check import PGCraftCheck
from pgcraft.config import PGCraftConfig
from pgcraft.declarative import (
    PGCraftBase,
    PGCraftFunctionMixin,
    PGCraftView,
    PGCraftViewMixin,
    ViewOptions,
)
from pgcraft.extension import PGCraftExtension
from pgcraft.fk import PGCraftForeignKey
from pgcraft.functions import FunctionOptions
from pgcraft.index import PGCraftIndex
from pgcraft.plugin import Dynamic, MinPGVersion, Plugin
from pgcraft.types import IntEnum, TextEnum
from pgcraft.utils.naming_convention import (
    construct_pgcraft_naming_conventions_dict,
)

__all__ = [
    "Dynamic",
    "FunctionOptions",
    "IntEnum",
    "MinPGVersion",
    "PGCraftBase",
    "PGCraftCheck",
    "PGCraftConfig",
    "PGCraftExtension",
    "PGCraftForeignKey",
    "PGCraftFunctionMixin",
    "PGCraftIndex",
    "PGCraftView",
    "PGCraftViewMixin",
    "Plugin",
    "TextEnum",
    "ViewOptions",
    "construct_pgcraft_naming_conventions_dict",
]
