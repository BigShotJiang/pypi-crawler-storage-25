<!-- rye:signed:2026-04-01T05:06:43Z:d0a894c22a7ecd5216049dcfb7c77fc16dad93e5c613851e46a2b382ec9315b9:-baAT07oiKIrPWww2Nzx7bSdBX2n160CcXcUx8JZSRX4CTy86Pi3XbJxEih9XpSGoVRulQiqyusYzrnOIEoXBQ:6ea18199041a1ea8 -->
<!-- rye:unsigned -->

# Base Execute Only

Narrow operating context for threads that only need to execute tools.

```xml
<directive name="base_execute_only" version="2.0.0" extends="agent/core/base">
  <metadata>
    <description>Narrow Rye agent context — extends general agent base, execute only</description>
    <category>rye/agent/core</category>
    <author>rye-os</author>
    <context>
      <system>rye/agent/core/Identity</system>
      <system>rye/agent/core/Behavior</system>
      <suppress>agent/core/Behavior</suppress>
    </context>
    <permissions>
      <execute>*</execute>
    </permissions>
  </metadata>
</directive>
```
