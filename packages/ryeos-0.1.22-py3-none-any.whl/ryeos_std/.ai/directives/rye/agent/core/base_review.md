<!-- rye:signed:2026-04-01T05:06:43Z:794b11b1c52ba6548ce4a8b1cb9a65133bc05d7d0abae7da6f058474b942ad63:_fykbO9iz5KdoiVU8O4Xr4L6gfL1ewDQDfIUYIf_ddmak9Lbk5Px4i8UGfDmAotfQCQfVn7AYGnZU56xW5BIAw:6ea18199041a1ea8 -->
<!-- rye:unsigned -->

# Base Review

Operating context for review and analysis threads with read-only file access.

```xml
<directive name="base_review" version="2.0.0" extends="agent/core/base">
  <metadata>
    <description>Rye review context — extends general agent base, read-only file access</description>
    <category>rye/agent/core</category>
    <author>rye-os</author>
    <context>
      <system>rye/agent/core/Identity</system>
      <system>rye/agent/core/Behavior</system>
      <suppress>agent/core/Behavior</suppress>
    </context>
    <permissions>
      <fetch>*</fetch>
      <execute>
        <tool>rye.file-system.read</tool>
        <tool>rye.file-system.glob</tool>
        <tool>rye.file-system.grep</tool>
        <knowledge>*</knowledge>
      </execute>
    </permissions>
  </metadata>
</directive>
```
