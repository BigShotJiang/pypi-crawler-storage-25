# rye:signed:2026-04-01T05:06:43Z:b55d5c8d563369effee41e171ab40e64a34a85b4b5ece5689bb8380992c447fe:Lv3jtq4gspz1jx8mUbHfrHzBOrxpCGVYN_rMFeA1q2zWF_rOHpQDouUj5TPw0fMKRzTIxdKy7SbbygNLlvxPDw:6ea18199041a1ea8
"""Thread system package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/agent/threads"
__tool_description__ = "Thread system package init"
