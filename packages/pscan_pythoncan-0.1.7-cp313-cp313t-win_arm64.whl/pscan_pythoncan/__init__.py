import logging
import time
import can
from can.broadcastmanager import (
    LimitedDurationCyclicSendTaskABC,
    ModifiableCyclicTaskABC,
    RestartableCyclicTaskABC,
)
from typing import Optional, List, Tuple, Sequence, Union, Callable

# Import the native extension
from . import pscan_pythoncan_ext

log = logging.getLogger("can.pscan")


class PscanCyclicSendTask(
    LimitedDurationCyclicSendTaskABC,
    ModifiableCyclicTaskABC,
    RestartableCyclicTaskABC,
):
    """Native periodic send task for PSCAN devices.

    Runs on a dedicated OS thread with precise timing (no GIL).
    Supports start/stop/restart and live data modification.
    """

    def __init__(
        self,
        dev,
        messages: Union[Sequence[can.Message], can.Message],
        period: float,
        duration: Optional[float] = None,
        autostart: bool = True,
        modifier_callback: Optional[Callable[[can.Message], None]] = None,
    ):
        super().__init__(messages, period, duration)
        self._dev = dev
        self._task_id: Optional[int] = None
        self._modifier_callback = modifier_callback

        if autostart:
            self.start()

    def _msgs_to_tuples(self) -> list:
        """Convert can.Message list to native-compatible frame tuples."""
        result = []
        for msg in self.messages:
            if msg.is_fd or getattr(msg, "bitrate_switch", False):
                raise NotImplementedError("CAN FD and Bitrate Switching (BRS) are not yet supported by PSCAN-USB")
                
            if self._modifier_callback is not None:
                self._modifier_callback(msg)
            result.append((
                msg.arbitration_id,
                msg.is_extended_id,
                msg.is_remote_frame,
                msg.dlc,
                list(msg.data),
            ))
        return result

    def start(self) -> None:
        """Start (or restart) the periodic send task on a dedicated OS thread."""
        # Stop any existing task first
        if self._task_id is not None:
            try:
                self._dev.stop_periodic(self._task_id)
            except Exception:
                pass
            self._task_id = None

        period_us = int(self.period * 1_000_000)
        duration_ms = int(self.duration * 1000) if self.duration is not None else None
        frame_tuples = self._msgs_to_tuples()

        self._task_id = self._dev.start_periodic(frame_tuples, period_us, duration_ms)

    def stop(self) -> None:
        """Stop the periodic send task."""
        if self._task_id is not None:
            try:
                self._dev.stop_periodic(self._task_id)
            except Exception:
                pass
            self._task_id = None

    def modify_data(self, messages: Union[Sequence[can.Message], can.Message]) -> None:
        """Update the frame data without stopping/restarting the task.

        The native thread will pick up the new data on its next send cycle.
        """
        messages = self._check_and_convert_messages(messages)
        self._check_modified_messages(messages)
        self.messages = messages

        if self._task_id is not None:
            frame_tuples = self._msgs_to_tuples()
            self._dev.modify_periodic(self._task_id, frame_tuples)


class PscanBus(can.BusABC):
    """
    PSCAN Hardware interface for python-can.

    Provides native USB access to PSCAN CAN adapters via a compiled backend.

    Usage::

        # Auto-detect single device
        bus = can.Bus(interface='pscan', bitrate=500000)

        # Open by user-friendly name
        bus = can.Bus(interface='pscan', name='MyBMS', bitrate=500000)

        # Open by serial number
        bus = can.Bus(interface='pscan', serial='P1P.IN:XFG:H001', bitrate=500000)

        # With options
        bus = can.Bus(interface='pscan', bitrate=250000, sample_point=800, listen_only=True)
    """

    def __init__(
        self,
        channel: str = 'PSCAN_USB1',
        serial: str = None,
        name: str = None,
        bitrate: int = 500000,
        sample_point: int = 875,
        listen_only: bool = False,
        loopback: bool = False,
        led_mode: int = 1,
        can_filters=None,
        **kwargs
    ):
        """
        :param channel: Channel name (used for python-can compatibility)
        :param serial: Serial number of the PSCAN device
        :param name: User-friendly device name (alternative to serial)
        :param bitrate: Bitrate in bps (default: 500000)
        :param sample_point: Sample point in permille (default: 875 = 87.5%)
        :param listen_only: Enable listen-only mode (no TX, no ACK)
        :param loopback: Enable loopback mode (TX frames are echoed to RX)
        :param led_mode: Set LED visualization mode (0=Off, 1=On [default], 2=ActiveOnly)
        :param can_filters: Message filters, see :meth:`~can.BusABC.set_filters`
        """
        if kwargs.get("fd", False):
            raise NotImplementedError("CAN FD (fd=True) is not yet supported by PSCAN-USB")
        if "data_bitrate" in kwargs:
            raise NotImplementedError("CAN FD data_bitrate configuration is not supported since PSCAN-USB handles Classic CAN")
        if kwargs.get("bitrate_switch", False):
            raise NotImplementedError("CAN FD bitrate switching (bitrate_switch=True) is not supported since PSCAN-USB handles Classic CAN")
            
        # Priority: name > serial > auto-detect first device
        if name:
            self._dev = pscan_pythoncan_ext.NativePscanDevice.open_by_name(name)
            self.channel_info = f"PSCAN: name={name}"
        else:
            self._dev = pscan_pythoncan_ext.NativePscanDevice(serial)
            self.channel_info = f"PSCAN: {serial or 'Auto'}"

        # Set CAN controller mode before starting bus
        ctrlmode = 0
        if listen_only:
            ctrlmode |= 0x02  # CAN_CTRLMODE_LISTENONLY
        if loopback:
            ctrlmode |= 0x01  # CAN_CTRLMODE_LOOPBACK
        if ctrlmode != 0:
            self._dev.set_mode(ctrlmode)

        self._dev.set_bitrate(bitrate, sample_point)
        
        # Explicitly configure physical indicator LED behavior
        try:
            self._dev.set_led_mode(led_mode)
        except Exception as e:
            log.warning(f"Failed to set initial LED mode: {e}")
            
        self._dev.set_bus_state(True)
        self._listen_only = listen_only

        # Call super().__init__ last — it sets _is_shutdown=False and applies filters
        super().__init__(channel=channel, can_filters=can_filters, **kwargs)

    def send(self, msg: can.Message, timeout: Optional[float] = None) -> None:
        """Transmit a CAN message.

        :param msg: Message to send
        :param timeout: Timeout in seconds (default: 0.05s = 50ms)
        :raises can.CanOperationError: If send fails
        :raises NotImplementedError: If CAN FD message is passed
        """
        if self._listen_only:
            raise can.CanOperationError("Cannot send in listen-only mode")

        if msg.is_fd or getattr(msg, "bitrate_switch", False):
            raise NotImplementedError("CAN FD and Bitrate Switching (BRS) are not yet supported by PSCAN-USB")

        if msg.is_error_frame:
            raise can.CanOperationError("PSCAN hardware does not support transmitting error frames")

        # Convert timeout: None -> 50ms default, else seconds -> ms
        if timeout is None:
            timeout_ms = 50
        else:
            timeout_ms = max(1, int(timeout * 1000))

        try:
            self._dev.send_frame(
                msg.arbitration_id,
                msg.is_extended_id,
                msg.is_remote_frame,
                msg.dlc,
                bytes(msg.data),  # PyO3 borrows &[u8] directly from bytes (zero-copy)
                timeout_ms
            )
        except Exception as e:
            raise can.CanOperationError(f"Send failed: {e}") from e

    def _recv_internal(self, timeout: Optional[float]) -> Tuple[Optional[can.Message], bool]:
        """
        Read a message from the hardware.

        Returns (message, already_filtered) tuple.
        Handles multi-frame USB reads via native-side buffering.
        """
        # With the native Condvar background thread, blocking uses 0% CPU.
        # For timeout=None, BusABC.recv() loops calling _recv_internal until a
        # message arrives. We use 1-second slices so shutdown is detected promptly.
        if timeout is None:
            timeout_ms = 1000  # 1 second slices; BusABC.recv() loops on None
        elif timeout <= 0:
            timeout_ms = 0     # Non-blocking: returns instantly from Condvar if empty
        else:
            timeout_ms = max(1, int(timeout * 1000))

        try:
            res = self._dev.receive_frame(timeout_ms)
            if res is None:
                return None, False

            ts_us, arb_id, is_ext, is_rtr, is_err, dlc, data = res

            msg = can.Message(
                timestamp=ts_us / 1_000_000.0,
                arbitration_id=arb_id,
                is_extended_id=is_ext,
                is_remote_frame=is_rtr,
                is_error_frame=is_err,
                dlc=dlc,
                data=bytes(data[:dlc]),  # Slice fixed [u8;8] array to actual DLC
                channel=self.channel_info,
            )
            return msg, True  # True = filtering already done natively
        except Exception as e:
            log.error("Error receiving CAN frame: %s", e)
            raise can.CanOperationError(f"Receive failed: {e}") from e

    def _apply_filters(self, filters) -> None:
        """Push filters to the native backend for high-performance filtering.

        Filters are applied natively before frames reach Python,
        using pscan-core's SoftFilter/SoftFilterSet implementation.

        :param filters: List of filter dicts with 'can_id', 'can_mask', and optional 'extended' keys.
        """
        if not filters:
            self._dev.clear_filters()
            return

        native_filters = []
        for f in filters:
            can_id = f.get('can_id', 0)
            can_mask = f.get('can_mask', 0)
            extended = f.get('extended', None)  # None = match both std and ext
            native_filters.append((can_id, can_mask, extended))

        self._dev.set_filters(native_filters)

    @property
    def state(self) -> can.BusState:
        """Return the current state of the CAN bus hardware.

        Mapping: ErrorActive -> ACTIVE, ErrorWarning/Passive -> PASSIVE, BusOff -> ERROR
        """
        try:
            state_val, _, _ = self._dev.get_bus_state()
            if state_val == 0:  # ErrorActive
                return can.BusState.ACTIVE
            elif state_val in (1, 2):  # ErrorWarning, ErrorPassive
                return can.BusState.PASSIVE
            else:  # BusOff(3), Stopped(4), Sleeping(5)
                return can.BusState.ERROR
        except Exception:
            return can.BusState.ERROR

    @state.setter
    def state(self, new_state: can.BusState) -> None:
        """Set the bus state.

        :param new_state: ACTIVE to go bus-on, ERROR to go bus-off
        """
        if new_state == can.BusState.ACTIVE:
            self._dev.set_bus_state(True)
        elif new_state == can.BusState.ERROR:
            self._dev.set_bus_state(False)
        else:
            # PASSIVE — set listen-only mode
            self._dev.set_mode(0x02)

    def flush_tx_buffer(self) -> None:
        """Discard all pending messages in the TX queue."""
        self._dev.flush_tx_queue()

    @property
    def name(self) -> str:
        """The 15-character physical name tag stored on the device ROM."""
        return self._dev.get_device_name()

    @name.setter
    def name(self, val: str) -> None:
        """Update the physical short-name stored in the adapter hardware."""
        self._dev.set_device_name(val)

    @property
    def led_mode(self) -> int:
        """Get or Set current Native USB LED Mode (0=Off, 1=On, 2=ActiveOnly)"""
        return self._dev.get_led_mode()

    @led_mode.setter
    def led_mode(self, mode: int) -> None:
        self._dev.set_led_mode(mode)

    @property
    def capabilities(self) -> dict:
        """A dictionary mapping core hardware limits parsed directly from the adapter."""
        return self._dev.get_device_capabilities()

    @staticmethod
    def _detect_available_configs() -> List[dict]:
        """Detect all connected PSCAN devices.

        :return: List of configs suitable for PscanBus constructor.
        """
        try:
            serials = pscan_pythoncan_ext.list_devices()
            return [
                {"interface": "pscan", "channel": "PSCAN_USB1", "serial": sn}
                for sn in serials
            ]
        except Exception:
            return []

    @staticmethod
    def list_pscan_devices() -> List[str]:
        """List serial numbers of all connected PSCAN devices.
        
        This is a PSCAN-specific feature outside of the standard python-can API.
        
        :return: List of device serial number strings.
        """
        try:
            return pscan_pythoncan_ext.list_devices()
        except Exception:
            return []
            
    def get_device_info(self) -> Tuple[str, str, int]:
        """Get hardware version, firmware version, and channel count of this PSCAN adapter.
        
        This is a PSCAN-specific feature outside of the standard python-can API.
        
        :return: Tuple of (hardware_version, firmware_version, channel_count)
        """
        try:
            return self._dev.get_device_info()
        except Exception as e:
            log.error(f"Failed to get device info: {e}")
            return ("Unknown", "Unknown", 0)

    def _send_periodic_internal(
        self,
        msgs,
        period: float,
        duration: Optional[float] = None,
        autostart: bool = True,
        modifier_callback=None,
    ):
        """Override to use native periodic send instead of pure Python threading."""
        return PscanCyclicSendTask(
            dev=self._dev,
            messages=msgs,
            period=period,
            duration=duration,
            autostart=autostart,
            modifier_callback=modifier_callback,
        )

    def shutdown(self) -> None:
        """Shut down the bus: stop periodic tasks, stop bus, release device."""
        if self._is_shutdown:
            return

        # Stop all periodic tasks FIRST
        if self._dev is not None:
            try:
                self._dev.stop_all_periodic()
            except Exception as e:
                log.warning("Error stopping periodic tasks: %s", e)

        # Device cleanup, before super().shutdown() sets the guard flag
        if self._dev is not None:
            try:
                self._dev.set_bus_state(False)
            except Exception as e:
                log.warning("Error during bus shutdown: %s", e)
            finally:
                self._dev = None

        super().shutdown()
