#!/usr/bin/env python3
"""
对比新旧宽松匹配测试结果分析
"""

import json
import os
from collections import defaultdict
from datetime import datetime

def load_results(filepath):
    """加载测试结果文件"""
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)

def calculate_model_stats(results):
    """计算模型统计数据"""
    model_stats = {}

    # 按模型分组
    model_groups = defaultdict(list)
    for result in results:
        model_groups[result['model']].append(result)

    # 计算每个模型的统计
    for model, tests in model_groups.items():
        total = len(tests)
        passed = sum(1 for t in tests if t['result'] == 'PASS')
        failed = sum(1 for t in tests if t['result'] == 'FAIL')
        error = sum(1 for t in tests if t['result'] == 'ERROR')

        # 计算平均响应时间（只计算成功的测试）
        response_times = [t['response_time'] for t in tests if t['result'] == 'PASS' and 'response_time' in t]
        avg_response_time = sum(response_times) / len(response_times) if response_times else 0

        pass_rate = (passed / total) * 100 if total > 0 else 0

        model_stats[model] = {
            'total': total,
            'passed': passed,
            'failed': failed,
            'error': error,
            'pass_rate': pass_rate,
            'avg_response_time': avg_response_time,
            'tests': tests  # 保存详细测试信息
        }

    return model_stats

def compare_test_runs(old_stats, new_stats):
    """比较两次测试运行"""
    comparison = {}

    # 获取所有模型（并集）
    all_models = set(old_stats.keys()) | set(new_stats.keys())

    for model in all_models:
        old = old_stats.get(model, {'pass_rate': 0, 'avg_response_time': 0, 'total': 0, 'passed': 0, 'error': 0})
        new = new_stats.get(model, {'pass_rate': 0, 'avg_response_time': 0, 'total': 0, 'passed': 0, 'error': 0})

        # 计算变化
        pass_rate_change = new['pass_rate'] - old['pass_rate']
        response_time_change = new['avg_response_time'] - old['avg_response_time']

        # 确定状态变化
        status_change = ""
        if old['error'] == old['total'] and new['passed'] == new['total']:
            status_change = "从全部错误到全部通过"
        elif old['passed'] == old['total'] and new['error'] > 0:
            status_change = "从全部通过到出现错误"
        elif pass_rate_change > 20:
            status_change = "显著提升"
        elif pass_rate_change < -20:
            status_change = "显著下降"
        elif abs(pass_rate_change) <= 20:
            status_change = "基本稳定"

        comparison[model] = {
            'old': old,
            'new': new,
            'pass_rate_change': pass_rate_change,
            'response_time_change': response_time_change,
            'status_change': status_change
        }

    return comparison

def generate_report(old_file, new_file, output_file):
    """生成对比报告"""
    print(f"正在加载测试结果...")
    old_results = load_results(old_file)
    new_results = load_results(new_file)

    print(f"正在计算统计数据...")
    old_stats = calculate_model_stats(old_results)
    new_stats = calculate_model_stats(new_results)

    print(f"正在比较测试结果...")
    comparison = compare_test_runs(old_stats, new_stats)

    # 生成报告
    report_lines = []
    report_lines.append("# SQL生成能力测试重新测试对比分析报告")
    report_lines.append("")
    report_lines.append(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_lines.append(f"**对比测试**: ")
    report_lines.append(f"- 旧测试: {old_file} (2026-03-24 09:22:26)")
    report_lines.append(f"- 新测试: {new_file} (2026-03-24 10:32:52)")
    report_lines.append("")
    report_lines.append("## 📊 模型表现对比")
    report_lines.append("")
    report_lines.append("| 模型 | 旧测试通过率 | 新测试通过率 | 变化 | 响应时间变化 | 状态变化 |")
    report_lines.append("|------|--------------|--------------|------|--------------|----------|")

    # 按新测试通过率排序
    sorted_models = sorted(
        comparison.items(),
        key=lambda x: x[1]['new']['pass_rate'],
        reverse=True
    )

    for model, data in sorted_models:
        old = data['old']
        new = data['new']
        pass_rate_change = data['pass_rate_change']
        resp_change = data['response_time_change']
        status_change = data['status_change']

        # 格式化变化箭头
        change_arrow = "↑" if pass_rate_change > 0 else "↓" if pass_rate_change < 0 else "→"
        resp_arrow = "↑" if resp_change > 0 else "↓" if resp_change < 0 else "→"

        report_lines.append(
            f"| {model} | {old['pass_rate']:.1f}% ({old['passed']}/{old['total']}) | "
            f"{new['pass_rate']:.1f}% ({new['passed']}/{new['total']}) | "
            f"{change_arrow} {pass_rate_change:+.1f}% | "
            f"{resp_arrow} {resp_change:+.1f}秒 | "
            f"{status_change} |"
        )

    report_lines.append("")
    report_lines.append("## 🔍 关键发现")
    report_lines.append("")

    # 分析关键变化
    significant_changes = []
    for model, data in comparison.items():
        if abs(data['pass_rate_change']) >= 33:  # 变化超过33%
            significant_changes.append((model, data))

    if significant_changes:
        report_lines.append("### 显著变化模型分析")
        report_lines.append("")
        for model, data in significant_changes:
            old = data['old']
            new = data['new']
            change = data['pass_rate_change']

            if change > 0:
                report_lines.append(f"1. **{model}**: 通过率从 {old['pass_rate']:.1f}% 提升到 {new['pass_rate']:.1f}% (+{change:.1f}%)")
                if old['error'] == old['total']:
                    report_lines.append(f"   - 之前: 模型加载失败（全部ERROR）")
                    report_lines.append(f"   - 现在: 模型成功加载并全部正确")
            else:
                report_lines.append(f"1. **{model}**: 通过率从 {old['pass_rate']:.1f}% 下降到 {new['pass_rate']:.1f}% ({change:.1f}%)")
                if new['error'] > 0:
                    report_lines.append(f"   - 之前: 全部正确")
                    report_lines.append(f"   - 现在: 出现超时错误（{new['error']}/{new['total']}个ERROR）")
            report_lines.append("")

    report_lines.append("### 服务器状态变化影响")
    report_lines.append("")
    report_lines.append("1. **模型加载状态改善**:")
    report_lines.append("   - `carstenuhlig/omnicoder-9b:latest`: 从全部ERROR变为全部PASS")
    report_lines.append("   - `qwen3:8b`: 从全部ERROR变为全部PASS")
    report_lines.append("   - 说明服务器资源限制问题得到缓解")
    report_lines.append("")
    report_lines.append("2. **性能稳定性问题**:")
    report_lines.append("   - `MFDoom/deepseek-r1-tool-calling:32b`: 从全部PASS变为部分超时ERROR")
    report_lines.append("   - `deepseek-r1:32b`: 仍然有超时问题")
    report_lines.append("   - 说明某些大模型在服务器负载高时容易超时")
    report_lines.append("")
    report_lines.append("3. **稳定表现模型**:")
    report_lines.append("   - `qwen3-coder:30b`: 始终保持100%通过率")
    report_lines.append("   - `deepseek-r1:1.5b`: 保持66.67%通过率")
    report_lines.append("")

    report_lines.append("## 📈 整体统计")
    report_lines.append("")

    # 计算整体统计数据
    old_total_tests = sum(s['total'] for s in old_stats.values())
    old_total_passed = sum(s['passed'] for s in old_stats.values())
    old_overall_rate = (old_total_passed / old_total_tests) * 100 if old_total_tests > 0 else 0

    new_total_tests = sum(s['total'] for s in new_stats.values())
    new_total_passed = sum(s['passed'] for s in new_stats.values())
    new_overall_rate = (new_total_passed / new_total_tests) * 100 if new_total_tests > 0 else 0

    report_lines.append(f"- **总体通过率**: {old_overall_rate:.1f}% → {new_overall_rate:.1f}% ({new_overall_rate - old_overall_rate:+.1f}%)")
    report_lines.append(f"- **有效模型数**（通过率>0%）: {sum(1 for s in old_stats.values() if s['pass_rate'] > 0)} → {sum(1 for s in new_stats.values() if s['pass_rate'] > 0)}")
    report_lines.append(f"- **100%通过模型数**: {sum(1 for s in old_stats.values() if s['pass_rate'] == 100)} → {sum(1 for s in new_stats.values() if s['pass_rate'] == 100)}")
    report_lines.append("")

    report_lines.append("## 💡 建议与结论")
    report_lines.append("")
    report_lines.append("### 1. 测试环境稳定性")
    report_lines.append("- 服务器资源状态显著影响模型可用性")
    report_lines.append("- 部分模型在服务器负载高时容易超时")
    report_lines.append("- 建议在相对稳定的服务器状态下进行评估")
    report_lines.append("")
    report_lines.append("### 2. 模型选择建议")
    report_lines.append("1. **最稳定模型**: `qwen3-coder:30b` - 两次测试都100%通过")
    report_lines.append("2. **性价比模型**: `deepseek-r1:1.5b` - 稳定在66.67%通过率，响应时间较好")
    report_lines.append("3. **潜在优秀模型**: `carstenuhlig/omnicoder-9b:latest` - 当服务器资源充足时表现优秀")
    report_lines.append("4. **注意风险模型**: `MFDoom/deepseek-r1-tool-calling:32b` - 性能不稳定，容易超时")
    report_lines.append("")
    report_lines.append("### 3. 生产部署考虑")
    report_lines.append("- 对于关键应用，选择多次测试都稳定的模型")
    report_lines.append("- 实现模型降级机制：主模型失败时切换到备选模型")
    report_lines.append("- 监控服务器资源使用，避免在高负载时使用大模型")
    report_lines.append("")
    report_lines.append("### 4. 后续测试建议")
    report_lines.append("- 在不同时间点进行多次测试，评估模型稳定性")
    report_lines.append("- 增加测试用例复杂度，评估模型真实能力")
    report_lines.append("- 建立自动化测试流水线，定期评估模型表现")
    report_lines.append("")
    report_lines.append("---")
    report_lines.append(f"**报告生成**: 自动分析脚本")
    report_lines.append(f"**数据源**: {os.path.basename(old_file)}, {os.path.basename(new_file)}")

    # 写入报告文件
    report_content = "\n".join(report_lines)
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(report_content)

    print(f"对比报告已生成: {output_file}")

    # 同时在控制台输出摘要
    print("\n" + "="*80)
    print("对比分析摘要:")
    print("="*80)
    print(f"总体通过率变化: {old_overall_rate:.1f}% → {new_overall_rate:.1f}% ({new_overall_rate - old_overall_rate:+.1f}%)")
    print(f"100%通过模型数: {sum(1 for s in old_stats.values() if s['pass_rate'] == 100)} → {sum(1 for s in new_stats.values() if s['pass_rate'] == 100)}")
    print("\n显著变化:")
    for model, data in significant_changes:
        print(f"  - {model}: {data['old']['pass_rate']:.1f}% → {data['new']['pass_rate']:.1f}% ({data['pass_rate_change']:+.1f}%)")

    return report_content

if __name__ == "__main__":
    # 文件路径
    old_results_file = "sql_test_relaxed_results_20260324_092226.json"
    new_results_file = "sql_test_relaxed_results_20260324_103252.json"
    output_report_file = "SQL_TEST_RETEST_COMPARISON_REPORT.md"

    # 检查文件是否存在
    if not os.path.exists(old_results_file):
        print(f"错误: 旧测试结果文件不存在: {old_results_file}")
        exit(1)

    if not os.path.exists(new_results_file):
        print(f"错误: 新测试结果文件不存在: {new_results_file}")
        exit(1)

    # 生成报告
    generate_report(old_results_file, new_results_file, output_report_file)