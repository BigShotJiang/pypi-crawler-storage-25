#!/usr/bin/env python3
"""Test cleaner on actual qwen3 responses"""

import re
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import SQLResponseCleaner

# Actual qwen3 responses from test results
qwen_responses = [
    # Test case 1
    ("""SELECT *语句。不过有时候可能需要注意是否需要考虑性能或者是否有特定的列需要排除，但用户没有提到这些，所以直接选所有列就可以了。

然后，我需要检查是否有其他可能的表名或者别名，但根据提供的信息，原表名明确是auto_base_daxueshezhi，所以直接使用这个表名。另外，用户可能希望结果中包含所有字段，所以不需要添加WHERE子句或者其他条件。

最后，确保SQL语法正确，没有拼写错误。所以最终的SQL应该是SELECT * FROM auto_base_daxueshezhi;。这样就能获取到该表的所有记录了。""",
     "SELECT * FROM auto_base_daxueshezhi"),

    # Test case 2 (already extracts SQL)
    ("""SELECT * FROM auto_xuekechuangxin WHERE xueyuanname = '计算机学院';。同时，需要检查是否有其他表可能也涉及创新团队，但根据现有数据，只有这个表符合。确保没有遗漏其他可能的表，比如主题7中的教师信息表或者其他主题，但根据描述，其他表不涉及创新团队。因此，最终的SQL语句应该是正确的。""",
     "SELECT * FROM auto_xuekechuangxin WHERE xueyuanname = '计算机学院'"),

    # Test case 3
    ("""SELECT xueyuanname, SUM(zdjj) AS total_zdjj FROM 表名 GROUP BY xueyuanname ORDER BY total_zdjj DESC。

不过需要注意几点：1. 表名是否正确，用户提到的是“科研项目到账经费表”，但原表名是auto_caiji_kyjxm_zdjj，可能需要确认是否使用原表名还是用户提供的中文表名。但通常在实际数据库中，表名是英文的，所以可能应该使用原表名。不过用户可能在查询时使用中文表名，所以需要确认。但根据问题描述，用户可能直接使用原表名，所以这里可能需要使用auto_caiji_kyjxm_zdjj。

2. 字段名是否正确，比如纵向项目到账经费可能对应zdjj，但需要确认是否有其他字段名，比如zdjje或者类似的。但根据提供的资料，表中的字段包括zdjj，所以假设正确。

3. 是否需要处理NULL值？比如，如果某个院系没有纵向项目，那么SUM可能会返回NULL，但用户可能希望这些院系不显示，或者显示为0。不过通常SUM会忽略NULL，所以可能不需要特别处理。

综上，生成的SQL应该是：

SELECT xueyuanname, SUM(zdjj) AS total_zdjj
FROM auto_caiji_kyjxm_zdjj""",
     "SELECT xueyuanname, SUM(zdjj) AS total_zdjj FROM auto_caiji_kyjxm_zdjj"),
]

cleaner = SQLResponseCleaner()

print("Testing updated cleaner on qwen3 responses")
print("=" * 80)

for i, (response, expected) in enumerate(qwen_responses):
    print(f"\nTest case {i+1}:")
    print(f"Response length: {len(response)}")
    print(f"Expected SQL: {expected}")

    cleaned = cleaner.clean_sql_response(response)
    print(f"Cleaned SQL: {cleaned}")
    print(f"Cleaned length: {len(cleaned)}")

    # Check if expected SQL is in cleaned
    if expected in cleaned:
        print("✓ Expected SQL found in cleaned output")
    else:
        print("✗ Expected SQL NOT found in cleaned output")

    # Check if likely SQL
    is_likely = cleaner.is_likely_sql(cleaned)
    print(f"Is likely SQL? {is_likely}")

    # Try to extract SQL using our improved logic manually
    print("\nManual extraction attempt:")
    # Look for SELECT ... FROM pattern with reasonable distance
    pattern = r'SELECT\s+.+?\s+FROM\s+\S+'
    matches = list(re.finditer(pattern, response, re.IGNORECASE | re.DOTALL))
    print(f"  Found {len(matches)} SELECT ... FROM patterns")
    for j, match in enumerate(matches):
        print(f"  Match {j}: pos={match.start()}-{match.end()}, text={repr(match.group()[:50])}...")
        # Check distance between SELECT and FROM
        text = match.group()
        from_pos = text.upper().find('FROM')
        if from_pos != -1:
            between = text[:from_pos]
            chinese = re.findall(r'[\u4e00-\u9fff]', between)
            print(f"    SELECT-FROM distance: {len(between)} chars, Chinese chars: {len(chinese)}")

    print("-" * 40)

print("\n" + "=" * 80)
print("Summary: Cleaner needs to better handle SQL embedded in Chinese reasoning")