#!/usr/bin/env python3
"""
分析SQL测试结果并重新评分（清理生成的SQL后）
"""

import json
import os
import re
from typing import List, Dict, Any
from dataclasses import dataclass, asdict
import glob


@dataclass
class CleanedResult:
    model_name: str
    test_case_id: int
    original_sql: str
    cleaned_sql: str
    expected_sql: str
    response_time: float
    error_message: str
    passed: bool


@dataclass
class ModelScore:
    model_name: str
    total_tests: int
    passed_tests: int
    passed_rate: float
    avg_response_time: float
    total_response_time: float


def clean_sql(sql: str) -> str:
    """清理SQL语句：去除think标签、多余空白、分号等"""
    if not sql:
        return sql

    # 去除<think>...</think>标签及其内容
    sql = re.sub(r'</?think>', '', sql, flags=re.IGNORECASE)

    # 去除可能的XML标签
    sql = re.sub(r'<[^>]+>', '', sql)

    # 去除SQL代码块标记
    sql = re.sub(r'```sql|```', '', sql, flags=re.IGNORECASE)

    # 去除首尾空白
    sql = sql.strip()

    # 去除末尾分号（如果存在）
    if sql.endswith(';'):
        sql = sql[:-1].strip()

    # 标准化空格：多个空格替换为单个空格
    sql = re.sub(r'\s+', ' ', sql)

    # 标准化逗号：中文逗号替换为英文逗号
    sql = sql.replace('，', ',')

    # 去除引号差异：统一使用单引号
    sql = sql.replace('"', "'")

    return sql


def normalize_sql(sql: str) -> str:
    """进一步标准化SQL以便比较"""
    sql = clean_sql(sql)

    # 统一大小写（关键词大写）
    keywords = ['SELECT', 'FROM', 'WHERE', 'GROUP BY', 'ORDER BY', 'JOIN',
                'INNER JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'ON', 'AND', 'OR',
                'AS', 'SUM', 'COUNT', 'AVG', 'MAX', 'MIN', 'HAVING', 'DISTINCT']

    # 将关键词转换为大写（不区分大小写）
    for kw in keywords:
        pattern = re.compile(rf'\b{kw}\b', re.IGNORECASE)
        sql = pattern.sub(kw, sql)

    # 去除多余空格
    sql = re.sub(r'\s+', ' ', sql).strip()

    return sql


def load_results(results_dir: str = "full_db_results") -> List[Dict[str, Any]]:
    """加载最新的测试结果文件"""
    result_files = glob.glob(os.path.join(results_dir, "sql_test_results_*.json"))
    if not result_files:
        print(f"在 {results_dir} 中未找到结果文件")
        return []

    # 使用最新的文件
    latest_file = max(result_files, key=os.path.getctime)
    print(f"加载结果文件: {latest_file}")

    with open(latest_file, 'r', encoding='utf-8') as f:
        return json.load(f)


def analyze_results(results: List[Dict[str, Any]]) -> List[CleanedResult]:
    """分析结果并重新评分"""
    cleaned_results = []

    for result in results:
        original_sql = result.get("generated_sql", "")
        expected_sql = result.get("expected_sql", "")

        # 清理生成的SQL
        cleaned_sql = clean_sql(original_sql)

        # 标准化SQL以进行比较
        normalized_cleaned = normalize_sql(cleaned_sql)
        normalized_expected = normalize_sql(expected_sql)

        # 检查是否通过
        passed = normalized_cleaned == normalized_expected

        cleaned_result = CleanedResult(
            model_name=result["model_name"],
            test_case_id=result["test_case_id"],
            original_sql=original_sql,
            cleaned_sql=cleaned_sql,
            expected_sql=expected_sql,
            response_time=result["response_time"],
            error_message=result.get("error_message", ""),
            passed=passed
        )
        cleaned_results.append(cleaned_result)

    return cleaned_results


def calculate_scores(cleaned_results: List[CleanedResult]) -> List[ModelScore]:
    """计算模型得分"""
    scores_dict = {}

    for result in cleaned_results:
        model_name = result.model_name

        if model_name not in scores_dict:
            scores_dict[model_name] = {
                "total": 0,
                "passed": 0,
                "total_time": 0.0
            }

        scores_dict[model_name]["total"] += 1
        scores_dict[model_name]["total_time"] += result.response_time

        if result.passed:
            scores_dict[model_name]["passed"] += 1

    model_scores = []
    for model_name, data in scores_dict.items():
        passed_rate = data["passed"] / data["total"] if data["total"] > 0 else 0
        avg_response_time = data["total_time"] / data["total"] if data["total"] > 0 else 0

        model_scores.append(ModelScore(
            model_name=model_name,
            total_tests=data["total"],
            passed_tests=data["passed"],
            passed_rate=passed_rate,
            avg_response_time=avg_response_time,
            total_response_time=data["total_time"]
        ))

    # 按通过率降序排序，如果通过率相同则按响应时间升序排序
    model_scores.sort(key=lambda x: (-x.passed_rate, x.avg_response_time))
    return model_scores


def generate_report(cleaned_results: List[CleanedResult], scores: List[ModelScore], output_dir: str = "full_db_results"):
    """生成分析报告"""
    os.makedirs(output_dir, exist_ok=True)

    # 保存清理后的结果
    cleaned_file = os.path.join(output_dir, "cleaned_results.json")
    with open(cleaned_file, 'w', encoding='utf-8') as f:
        cleaned_data = [asdict(result) for result in cleaned_results]
        json.dump(cleaned_data, f, ensure_ascii=False, indent=2)

    # 生成排行榜
    leaderboard_file = os.path.join(output_dir, "cleaned_leaderboard.txt")
    with open(leaderboard_file, 'w', encoding='utf-8') as f:
        f.write("=" * 80 + "\n")
        f.write("SQL生成能力排行榜（清理后评分）\n")
        f.write("=" * 80 + "\n\n")

        f.write("模型排名:\n")
        f.write("-" * 80 + "\n")
        for i, score in enumerate(scores, 1):
            f.write(f"第{i}名: {score.model_name}\n")
            f.write(f"   通过率: {score.passed_rate:.2%} ({score.passed_tests}/{score.total_tests})\n")
            f.write(f"   平均响应时间: {score.avg_response_time:.2f}秒\n")
            f.write(f"   总响应时间: {score.total_response_time:.2f}秒\n")
            f.write("\n")

        # 按测试用例统计
        f.write("\n" + "=" * 80 + "\n")
        f.write("测试用例统计:\n")
        f.write("-" * 80 + "\n")

        case_stats = {}
        for result in cleaned_results:
            case_id = result.test_case_id
            if case_id not in case_stats:
                case_stats[case_id] = {"total": 0, "passed": 0}
            case_stats[case_id]["total"] += 1
            if result.passed:
                case_stats[case_id]["passed"] += 1

        for case_id in sorted(case_stats.keys()):
            data = case_stats[case_id]
            pass_rate = data["passed"] / data["total"] if data["total"] > 0 else 0
            f.write(f"测试用例 {case_id}: 通过率 {pass_rate:.2%} ({data['passed']}/{data['total']})\n")

    print(f"清理后的结果保存到: {cleaned_file}")
    print(f"排行榜保存到: {leaderboard_file}")

    # 显示排行榜
    print("\n" + "=" * 80)
    print("清理后排行榜")
    print("=" * 80)
    for i, score in enumerate(scores, 1):
        print(f"{i}. {score.model_name}: {score.passed_rate:.2%} ({score.passed_tests}/{score.total_tests}), "
              f"平均响应时间: {score.avg_response_time:.2f}秒")


def main():
    """主函数"""
    results_dir = "full_db_results"

    # 加载原始结果
    raw_results = load_results(results_dir)
    if not raw_results:
        print("未找到结果文件")
        return

    print(f"加载了 {len(raw_results)} 条测试结果")

    # 分析结果
    cleaned_results = analyze_results(raw_results)

    # 计算得分
    scores = calculate_scores(cleaned_results)

    # 生成报告
    generate_report(cleaned_results, scores, results_dir)

    # 显示一些示例
    print("\n" + "=" * 80)
    print("SQL清理示例:")
    print("=" * 80)

    for i, result in enumerate(cleaned_results[:3]):
        print(f"\n示例 {i+1}:")
        print(f"  模型: {result.model_name}")
        print(f"  原始SQL: {result.original_sql[:100]}...")
        print(f"  清理后SQL: {result.cleaned_sql}")
        print(f"  预期SQL: {result.expected_sql}")
        print(f"  是否通过: {result.passed}")


if __name__ == "__main__":
    main()