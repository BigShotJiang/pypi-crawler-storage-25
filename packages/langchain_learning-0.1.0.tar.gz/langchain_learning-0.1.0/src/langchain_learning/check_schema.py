#!/usr/bin/env python3
import json
import sys

def main():
    file_path = "data/json/json.json"
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        if isinstance(data, dict) and "data" in data:
            tables = data["data"]
            print("数据结构摘要:")
            print(f"文件类型: dict，包含键: {list(data.keys())}")
            print(f"表数量: {len(tables)}")
        elif isinstance(data, list):
            tables = data
            print("数据结构摘要:")
            print(f"文件类型: list")
            print(f"表数量: {len(tables)}")
        else:
            print(f"未知数据结构类型: {type(data)}")
            return

        # 显示前5个表
        print("\n前5个表的结构:")
        for i, table in enumerate(tables[:5], 1):
            table_name = table.get("表名", "未知表")
            table_label = table.get("标签", "")
            fields = table.get("字段列表", [])
            print(f"\n{i}. 表名: {table_name}")
            if table_label:
                print(f"   标签: {table_label}")
            print(f"   字段数: {len(fields)}")
            # 显示前3个字段
            for j, field in enumerate(fields[:3], 1):
                field_name = field.get("列名") or field.get("列名（枚举字段）") or field.get("列名（日期字段）") or "未知字段"
                data_type = field.get("数据类型", "")
                remark = field.get("备注", "")
                print(f"     字段{j}: {field_name} ({data_type}) - {remark}")
            if len(fields) > 3:
                print(f"     ... 还有 {len(fields)-3} 个字段")

        # 统计字段类型
        field_types = {}
        total_fields = 0
        for table in tables:
            fields = table.get("字段列表", [])
            for field in fields:
                data_type = field.get("数据类型", "")
                if data_type:
                    field_types[data_type] = field_types.get(data_type, 0) + 1
                total_fields += 1

        print(f"\n总体统计:")
        print(f"总表数: {len(tables)}")
        print(f"总字段数: {total_fields}")
        print(f"字段类型分布:")
        for dtype, count in sorted(field_types.items(), key=lambda x: x[1], reverse=True):
            print(f"  {dtype}: {count}")

    except Exception as e:
        print(f"加载文件失败: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()