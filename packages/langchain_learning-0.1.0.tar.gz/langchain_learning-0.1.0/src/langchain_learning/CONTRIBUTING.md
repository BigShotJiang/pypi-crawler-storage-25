# Contributing to LangChain Learning Project

Thank you for your interest in contributing! This project is a learning resource for LangChain and vector databases, and contributions that improve the educational value are welcome.

## Code of Conduct

Please be respectful and constructive in all interactions.

## How to Contribute

### 1. Report Bugs
- Use the GitHub issue tracker
- Include a clear description
- Add steps to reproduce
- Specify your environment

### 2. Suggest Enhancements
- Describe the enhancement
- Explain why it would be useful
- Provide examples if possible

### 3. Contribute Code

#### Fork and Clone
1. Fork the repository
2. Clone your fork:
   ```bash
   git clone https://github.com/YOUR_USERNAME/langchain-learning.git
   cd langchain-learning
   ```

#### Set Up Development Environment
1. Create virtual environment:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Linux/Mac
   # or .venv\Scripts\activate  # Windows
   ```

2. Install dependencies:
   ```bash
   pip install -e ".[dev]"
   ```

3. Set up pre-commit hooks (optional):
   ```bash
   pre-commit install
   ```

#### Create a Branch
```bash
git checkout -b feature/your-feature-name
```

#### Make Changes
- Follow the project structure
- Write tests for new functionality
- Update documentation
- Follow coding standards

#### Test Your Changes
```bash
# Run tests
python scripts/test.py

# Format code
python scripts/format.py
```

#### Commit Changes
Use conventional commit messages:
```
type(scope): description

body

footer
```

Types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`

#### Push and Create Pull Request
1. Push to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```

2. Create a pull request on GitHub
3. Fill out the PR template
4. Request review

## Development Guidelines

### Code Standards
- Follow PEP 8 (Python)
- Use type hints
- Write docstrings for public APIs
- Keep functions focused and small

### Testing
- Write unit tests for new functionality
- Maintain or improve test coverage
- Test edge cases and error conditions

### Documentation
- Update README.md for significant changes
- Add docstrings to new functions/classes
- Update examples if APIs change

### Project Structure
```
langchain-learning/
├── src/                    # Source code
│   ├── core/              # Core functionality
│   ├── chains/            # LangChain chains
│   ├── agents/            # LangChain agents
│   └── utils/             # Utility functions
├── examples/              # Example scripts
├── tests/                 # Test code
├── docs/                  # Documentation
├── data/                  # Data files
└── config/                # Configuration
```

## Types of Contributions

### 1. New Examples
- Add to `examples/` directory
- Follow naming convention
- Include clear comments
- Add to examples/README.md

### 2. Core Improvements
- Refactor existing code
- Add error handling
- Improve performance
- Enhance security

### 3. Documentation
- Fix typos and errors
- Add explanations
- Create tutorials
- Translate documentation

### 4. Tests
- Add missing tests
- Improve test coverage
- Add integration tests
- Fix flaky tests

## Review Process

1. **Initial Review**: Maintainers review for completeness and standards
2. **Feedback**: Suggestions for improvements
3. **Revision**: Address review comments
4. **Approval**: At least one maintainer approves
5. **Merge**: PR is merged into main branch

## Getting Help

- Check existing documentation
- Look at similar examples
- Ask questions in issues
- Be specific about what you need help with

## Recognition

Contributors will be acknowledged in:
- GitHub contributors list
- Project README (for significant contributions)
- Release notes

## License

By contributing, you agree that your contributions will be licensed under the project's MIT license.