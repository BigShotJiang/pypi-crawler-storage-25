#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')

from examples.model_sql_comprehensive_test_full_db_optimized import SQLEvaluator

def test_alias_removal():
    """测试别名移除功能"""
    print("测试SQL标准化中的别名移除...")

    test_cases = [
        # (输入SQL, 期望输出)
        ("SELECT year, SUM(number_1) as total_students FROM table GROUP BY year",
         "SELECT YEAR, SUM(NUMBER_1) FROM TABLE GROUP BY YEAR"),

        ("SELECT xueyuanname, SUM(money_1) total_money FROM table GROUP BY xueyuanname",
         "SELECT XUEYUANNAME, SUM(MONEY_1) FROM TABLE GROUP BY XUEYUANNAME"),

        ("SELECT year AS year_alias, number_1 FROM table",
         "SELECT YEAR, NUMBER_1 FROM TABLE"),

        ("SELECT t1.year, t2.number_1 FROM table1 t1 JOIN table2 t2 ON t1.id = t2.id",
         "SELECT T1.YEAR, T2.NUMBER_1 FROM TABLE1 T1 JOIN TABLE2 T2 ON T1.ID = T2.ID"),

        ("SELECT COUNT(*) as count, AVG(score) average_score FROM students",
         "SELECT COUNT(*), AVG(SCORE) FROM STUDENTS"),

        # 测试字段名标准化
        ("SELECT xueyuanName, projectlevelName FROM table",
         "SELECT XUEYUANNAME, PROJECTLEVELNAME FROM TABLE"),
    ]

    for i, (input_sql, expected) in enumerate(test_cases, 1):
        result = SQLEvaluator.normalize_sql(input_sql)
        if result == expected:
            print(f"测试 {i}: 通过")
        else:
            print(f"测试 {i}: 失败")
            print(f"  输入: {input_sql}")
            print(f"  结果: {result}")
            print(f"  期望: {expected}")

    print("\n测试字段名标准化...")
    field_test_cases = [
        ("SELECT xueyuanName FROM table", "select xueyuanname from table"),
        ("SELECT XUEYUANNAME FROM table", "select xueyuanname from table"),
        ("SELECT money1 FROM table", "select money_1 from table"),
        ("SELECT chuguotime FROM table", "select chuguo_time from table"),
    ]

    for i, (input_sql, expected) in enumerate(field_test_cases, 1):
        result = SQLEvaluator.normalize_field_names(input_sql)
        if result == expected:
            print(f"字段测试 {i}: 通过")
        else:
            print(f"字段测试 {i}: 失败")
            print(f"  输入: {input_sql}")
            print(f"  结果: {result}")
            print(f"  期望: {expected}")

if __name__ == '__main__':
    test_alias_removal()