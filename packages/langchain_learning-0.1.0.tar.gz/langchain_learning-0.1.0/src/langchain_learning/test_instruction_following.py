#!/usr/bin/env python3
"""测试不同模型的指令遵循能力"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from langchain_openai import ChatOpenAI
import json

# 读取schema
schema_file = "data/json/compressed_schema.json"
with open(schema_file, 'r', encoding='utf-8') as f:
    schema_data = json.load(f)
    # 转换为文本格式（模仿主文件中的格式）
    schema_text = json.dumps(schema_data, ensure_ascii=False, indent=2)

# 简单提示词 - 极简版本
simple_prompt = f"""数据库schema:
{schema_text}

用户查询: 查询所有院系名称

生成SQL语句，只输出SQL，不要有任何其他文本:"""

# 模型列表
models_to_test = [
    "qwen3:8b",
    "gemma3:27b",
    "qwen3:32b",
    "qwen3:30b-a3b-instruct-2507-q4_K_M",
    "carstenuhlig/omnicoder-9b:q4_k_m",
    "HridaAI/hrida-t2sql-128k:latest"
]

SERVER_URL = "http://10.254.2.127:8001/v1"

for model in models_to_test:
    print(f"\n{'='*60}")
    print(f"测试模型: {model}")
    print(f"{'='*60}")

    try:
        chat = ChatOpenAI(
            base_url=SERVER_URL,
            api_key="ollama",
            model=model,
            temperature=0,
            max_tokens=200,
            timeout=60
        )

        response = chat.invoke(simple_prompt)
        content = response.content

        print(f"响应类型: {type(content)}")
        print(f"响应长度: {len(content)}")
        print(f"响应内容: {repr(content[:200])}")

        # 检查是否包含非SQL内容
        has_chinese = any('\u4e00' <= c <= '\u9fff' for c in content)
        has_think = '<think>' in content.lower()
        has_explanation = any(word in content.lower() for word in ['首先', '然后', '需要', '应该', 'select'])

        print(f"包含中文: {has_chinese}")
        print(f"包含<think>: {has_think}")
        print(f"包含解释: {has_explanation}")

        # 检查是否是纯SQL
        content_lower = content.lower().strip()
        is_pure_sql = (content_lower.startswith('select') or content_lower.startswith('insert') or
                       content_lower.startswith('update') or content_lower.startswith('delete') or
                       content_lower.startswith('with'))

        if not is_pure_sql:
            print("⚠️  警告: 响应可能不是纯SQL")

    except Exception as e:
        print(f"❌ 错误: {e}")