#!/usr/bin/env python3
"""测试SQL清洗器如何处理gemma3:27b的输出"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import SQLResponseCleaner

# gemma3:27b的实际输出（从之前测试中复制）
gemma_response = """```sql
SELECT DISTINCT
  field1name
FROM auto_base_daxueshezhi
UNION
SELECT DISTINCT
  field2name
FROM auto_jiaoshigongcheng
UNION
SELECT DISTINCT
  field1name
FROM auto_jiaoshi
UNION
SELECT DISTINCT
  field2name
FROM auto_jiaoshi
UNION
SELECT DISTINCT
  field11name
FROM auto_jiaoshizhuanlishouquanqingkuang
UNION
SELECT DISTINCT
  field2name
FROM auto_zhuanyezhuanrenjiaoshirongyu
UNION
SELECT DISTINCT
  field1name
FROM auto_base_daxueshezhi
```"""

print("原始响应:")
print(gemma_response)
print(f"\n原始响应长度: {len(gemma_response)}")

# 测试清洗器
cleaner = SQLResponseCleaner()
cleaned = cleaner.clean_sql_response(gemma_response)

print(f"\n清洗后的SQL:")
print(cleaned)
print(f"清洗后长度: {len(cleaned)}")

# 检查是否看起来像SQL
is_likely = cleaner.is_likely_sql(cleaned)
print(f"\n看起来像SQL吗? {is_likely}")

# 测试qwen3:8b的输出
qwen_response = """<think>
好的，我现在需要帮用户生成一个SQL查询，用来统计每个年度每个院系的科研项目到账经费，并计算年度内院系经费排名。首先，我得仔细分析用户的需求，确保理解正确。

用户提到的“科研项目到账经费”可能涉及多个表，但根据提供的主题分类，科研项目相关的表可能在主题6“科研项目”下。不过，用户提供的表信息中，主题6的表是“科研项目”，但描述里没有明确提到经费字段。不过，可能需要查看其他表是否有相关字段，比如“大学设置基本条件表”中的“教学科研仪器设备金额”可能和经费有关，但不确定是否是到账经费。或者可能用户指的是科研项目中的经费到账情况，但表中没有明确字段。

这里可能存在信息不全的情况，因为用户提供的表结构中，科研项目相关的表可能没有直接记录到账经费的字段。例如，主题6的“科研项目”表可能包含项目金额或经费信息，但根据用户提供的描述，该表的字段包括项目名称、负责人、项目类型、经费、起止时间等，其中“经费”字段可能就是到账经费。因此，假设存在一个表，比如“科研项目”表，其中包含“经费”字段，用于计算每个院系的年度经费总额。

接下来，我需要确定如何连接表。假设“科研项目”表中有一个字段是“所属院系”（可能对应到“xueyuanname”），而“年度”可能在“起止时间”字段中提取，比如起始年份。或者可能有一个“年度”字段。但根据用户提供的表结构，比如“科研项目”表的字段包括“year”吗？根据用户提供的表结构，主题6的“科研项目”表的字段可能包括“year”吗？需要再检查用户提供的表信息。

在用户提供的主题6的“科研项目”表中，关键字段包括“project_name”、“responsible_person”、“project_type”、“funds”、“start_time”、“end_time”、“year”等。例如，表1的描述是“科研项目表，包含字段：project_name, responsible_person, project_type, funds, start_time, end_time, year”。所以，这里有一个“year”字段，可能表示项目所在的年度。同时，“funds”字段可能代表该项目的经费金额。

因此，用户需要统计每个年度每个院系的"""

print(f"\n{'='*80}")
print("测试qwen3:8b输出（包含推理）:")
print(f"响应长度: {len(qwen_response)}")
cleaned_qwen = cleaner.clean_sql_response(qwen_response)
print(f"清洗后: {cleaned_qwen[:200]}...")
print(f"清洗后长度: {len(cleaned_qwen)}")
is_likely_qwen = cleaner.is_likely_sql(cleaned_qwen)
print(f"看起来像SQL吗? {is_likely_qwen}")