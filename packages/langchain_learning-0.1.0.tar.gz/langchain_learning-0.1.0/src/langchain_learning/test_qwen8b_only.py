#!/usr/bin/env python3
"""
只测试qwen3:8b模型的前几个测试用例
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import (
    SQLGenerationTesterFullDBOptimized, TestCase, create_test_cases_for_full_db,
    TestResultRecord, TestResult, SQLEvaluator, SQLResponseCleaner
)
import time

def main():
    # 只取前3个测试用例
    all_cases = create_test_cases_for_full_db()
    test_cases = all_cases[:3]  # 前3个

    print(f"测试 qwen3:8b 模型，使用 {len(test_cases)} 个测试用例")

    # 加载schema
    from examples.model_sql_comprehensive_test_full_db_optimized import FullDatabaseSchemaLoader
    schema_loader = FullDatabaseSchemaLoader("data/json/compressed_schema.json")
    full_schema_text = schema_loader.load_full_schema()

    # 初始化测试器
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url="http://10.254.2.127:8001/v1",
        timeout=30,
        full_schema_text=full_schema_text
    )

    # 测试模型
    model_name = "qwen3:8b"
    results = []

    for test_case in test_cases:
        print(f"\n测试用例 {test_case.id}: {test_case.name}")
        print(f"查询: {test_case.natural_language_query}")

        try:
            raw_sql, cleaned_sql, response_time = tester.generate_sql(model_name, test_case.natural_language_query)

            # 评估
            evaluator = SQLEvaluator()
            result, match_type = evaluator.evaluate_sql(raw_sql, test_case.expected_sql)

            print(f"生成SQL (原始): {raw_sql[:100]}...")
            print(f"清理后SQL: {cleaned_sql}")
            print(f"期望SQL: {test_case.expected_sql}")
            print(f"结果: {result.value}, 匹配类型: {match_type}, 响应时间: {response_time:.2f}秒")

            record = TestResultRecord(
                test_case_id=test_case.id,
                model_name=model_name,
                generated_sql=raw_sql,
                cleaned_sql=cleaned_sql,
                expected_sql=test_case.expected_sql,
                result=result,
                response_time=response_time,
                error_message=None,
                match_type=match_type
            )
            results.append(record)

        except Exception as e:
            print(f"错误: {e}")
            record = TestResultRecord(
                test_case_id=test_case.id,
                model_name=model_name,
                generated_sql="",
                cleaned_sql="",
                expected_sql=test_case.expected_sql,
                result=TestResult.ERROR,
                response_time=0.0,
                error_message=str(e),
                match_type="error"
            )
            results.append(record)

    # 显示统计
    print("\n" + "="*80)
    print("测试结果统计")
    print("="*80)

    total = len(results)
    passed = sum(1 for r in results if r.result == TestResult.PASS)
    partial = sum(1 for r in results if r.result == TestResult.PARTIAL)
    failed = sum(1 for r in results if r.result == TestResult.FAIL)
    errors = sum(1 for r in results if r.result == TestResult.ERROR)

    print(f"总测试: {total}")
    print(f"通过: {passed} ({passed/total*100:.1f}%)")
    print(f"部分通过: {partial} ({partial/total*100:.1f}%)")
    print(f"失败: {failed} ({failed/total*100:.1f}%)")
    print(f"错误: {errors} ({errors/total*100:.1f}%)")

    # 保存结果
    output_dir = "qwen8b_simple_test"
    os.makedirs(output_dir, exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H%M%S")

    import json
    from dataclasses import asdict

    results_file = os.path.join(output_dir, f"results_{timestamp}.json")
    with open(results_file, 'w', encoding='utf-8') as f:
        json_data = []
        for result in results:
            result_dict = asdict(result)
            result_dict["result"] = result.result.value
            json_data.append(result_dict)
        json.dump(json_data, f, ensure_ascii=False, indent=2)

    print(f"\n结果保存到: {results_file}")

if __name__ == "__main__":
    main()