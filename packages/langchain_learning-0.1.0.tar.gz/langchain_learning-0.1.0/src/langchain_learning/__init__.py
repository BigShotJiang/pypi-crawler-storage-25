"""LangChain Learning - A structured learning project for LangChain and vector databases."""

__version__ = "0.1.0"