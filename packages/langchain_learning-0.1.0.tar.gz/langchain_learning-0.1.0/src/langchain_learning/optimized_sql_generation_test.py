#!/usr/bin/env python3
"""
优化版SQL生成能力测试
实施优化建议中的方案：
1. 提示词强化优化（多级强制指令）
2. 智能SQL提取后处理
3. SQL完整性验证
4. 模型特定优化提示词
"""

import requests
import json
import time
import re
from datetime import datetime

OLLAMA_URL = "http://10.254.2.99:8001"

def load_simplified_schema():
    """加载简化schema"""
    return """压缩版数据库结构（关键表）：
1. auto_base_daxueshezhi（大学设置表）- 字段: field1, field2, status
2. auto_caiji_chuangxin_team（创新团队表）- 字段: year, team_name, members
3. auto_caiji_fuwu_summarykyxmdzjf（科研项目到账经费表）- 字段: xueyuanName, money_1, year
4. auto_caiji_guoji_projectjscgyx（教师出国研修表）- 字段: projectlevelName, chuguo_time, teacher_name
5. auto_caiji_guoji_projectxscgxx（学生出国学习表）- 字段: year, number_person, destination
6. auto_caiji_guoji_summarylxhb（留学湖北表）- 字段: year, number_1, student_type"""

def create_test_cases():
    """创建测试用例"""
    return [
        {
            "id": 1,
            "name": "简单查询",
            "query": "查询大学设置基本条件表的所有记录",
            "expected_sql": "SELECT * FROM auto_base_daxueshezhi"
        },
        {
            "id": 2,
            "name": "条件查询",
            "query": "查询创新团队表中年度为2023的记录",
            "expected_sql": "SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'"
        },
        {
            "id": 3,
            "name": "聚合查询",
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
            "expected_sql": "SELECT xueyuanName, SUM(money_1) as total_money FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName"
        }
    ]

def get_models():
    """获取可用模型"""
    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10)
        if response.status_code == 200:
            data = response.json()
            models = [model["name"] for model in data.get("models", [])]
            return models
    except:
        pass

    # 默认模型列表
    return ["qwen3:8b", "qwen3:30b", "qwen3:32b"]

# ==================== 优化方案一：提示词强化优化 ====================

def create_optimized_prompt(schema, query):
    """创建优化提示词（多级强制指令）"""
    return f"""# SQL生成专家 - 严格模式

## 核心指令（必须遵守）
1. 输出格式：仅SQL语句
2. 禁止内容：推理过程、解释、分析、代码块标记、XML标签
3. 语法要求：完整SQL语句，包含SELECT、FROM、WHERE等必要子句

## 违规示例（禁止输出）
错误1: "首先，我需要分析查询..." [包含推理]
错误2: "SELECT *" [缺少FROM子句]
错误3: "```sql\\nSELECT...\\n```" [包含代码块]

## 正确示例
查询: "查询创新团队表中年度为2023的记录"
输出: SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'

## 数据库schema
{schema}

## 当前查询
{query}

## 请生成SQL语句："""

# ==================== 优化方案三：后处理增强 ====================

def extract_sql_from_response(response):
    """智能SQL提取 - 从可能包含推理的响应中提取SQL"""
    if not response:
        return ""

    # 去除首尾空白
    response = response.strip()

    # 模式1：纯SQL（理想情况）
    if response.upper().startswith("SELECT"):
        return response

    # 模式2：包含推理的响应
    patterns = [
        r"SELECT\s+.+?\s+FROM\s+\S+",  # 标准SELECT语句
        r"输出[:：]\s*(SELECT.+)",      # 中文提示后跟SQL
        r"SQL语句[:：]\s*(SELECT.+)",   # 明确标记的SQL
        r"SELECT\s+.+?\s+(?:FROM|JOIN|WHERE|GROUP|ORDER|HAVING|LIMIT)",  # 更宽松的SELECT模式
        r"生成的SQL[:：]\s*(SELECT.+)",  # 中文前缀
        r"答案[:：]\s*(SELECT.+)"       # 答案前缀
    ]

    for pattern in patterns:
        match = re.search(pattern, response, re.IGNORECASE | re.DOTALL)
        if match:
            sql = match.group(1) if len(match.groups()) > 0 else match.group(0)
            return sql.strip()

    return response  # 如果无法提取，返回原始响应

def validate_sql_completeness(sql):
    """验证SQL语句完整性"""
    if not sql:
        return False, "空SQL"

    sql_upper = sql.upper()

    # 检查SELECT子句
    if not re.search(r"SELECT\s+.+", sql_upper):
        return False, "缺少SELECT子句"

    # 检查FROM子句
    if not re.search(r"FROM\s+\S+", sql_upper):
        return False, "缺少FROM子句"

    # 检查WHERE条件完整性
    if "WHERE" in sql_upper:
        where_match = re.search(r"WHERE\s+(.+)", sql_upper, re.DOTALL)
        if not where_match or len(where_match.group(1).strip()) < 3:
            return False, "WHERE条件不完整"

    # 检查GROUP BY完整性
    if "GROUP BY" in sql_upper:
        group_match = re.search(r"GROUP\s+BY\s+(.+)", sql_upper, re.DOTALL)
        if not group_match or len(group_match.group(1).strip()) < 2:
            return False, "GROUP BY条件不完整"

    return True, "SQL完整"

def clean_optimized_sql(sql_text):
    """优化版SQL清洗"""
    if not sql_text:
        return ""

    # 移除代码块标记
    cleaned = re.sub(r'^```sql\s*', '', sql_text, flags=re.IGNORECASE)
    cleaned = re.sub(r'^```\s*', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s*```\s*$', '', cleaned, flags=re.IGNORECASE)

    # 移除XML标签
    cleaned = re.sub(r'<[^>]+>', '', cleaned)

    # 移除分号
    cleaned = cleaned.rstrip(';')

    # 移除常见前缀
    prefixes = [
        r'^sql\s*', r'^query:\s*', r'^生成的sql:\s*',
        r'^输出:\s*', r'^答案:\s*', r'^SQL语句:\s*'
    ]
    for prefix in prefixes:
        cleaned = re.sub(prefix, '', cleaned, flags=re.IGNORECASE)

    # 移除常见后缀（如"以上就是..."）
    suffixes = [
        r'\s*以上是.*$', r'\s*这就是.*$', r'\s*生成的.*$',
        r'\s*希望能.*$', r'\s*如有.*$'
    ]
    for suffix in suffixes:
        cleaned = re.sub(suffix, '', cleaned, flags=re.IGNORECASE)

    # 规范化空白
    cleaned = re.sub(r'\s+', ' ', cleaned)
    cleaned = cleaned.strip()

    return cleaned

# ==================== 模型特定优化 ====================

def create_model_specific_prompt(model_name, schema, query):
    """根据模型创建特定优化提示词"""

    if "32b" in model_name.lower():
        # qwen3:32b - 利用其较强的理解能力
        return f"""你是一个专业的SQL生成专家。以下是完整的数据库结构：

{schema}

要求：
1. 直接输出SQL语句，不要任何解释
2. 确保SQL语法完整（SELECT、FROM、WHERE等）
3. 使用准确的表名和字段名

查询：{query}"""

    elif "8b" in model_name.lower():
        # qwen3:8b - 简化指令，强调格式
        return f"""SQL语句：{query}

格式要求：
- 只输出SQL
- 不要解释
- 使用正确表名

示例：
输入：查询大学设置表
输出：SELECT * FROM auto_base_daxueshezhi

数据库结构：
{schema}"""

    else:
        # qwen3:30b或其他模型 - 强化表名识别
        return f"""查询：{query}

可用表：
- auto_base_daxueshezhi（大学设置表）
- auto_caiji_chuangxin_team（创新团队表）
- auto_caiji_fuwu_summarykyxmdzjf（科研项目经费表）
- auto_caiji_guoji_projectjscgyx（教师出国研修表）
- auto_caiji_guoji_projectxscgxx（学生出国学习表）
- auto_caiji_guoji_summarylxhb（留学湖北表）

要求：输出完整SQL语句，不要其他内容。"""

# ==================== 模型调用和评估 ====================

def call_model(model_name, prompt):
    """调用模型生成SQL"""
    url = f"{OLLAMA_URL}/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    data = {
        "model": model_name,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.0,
        "max_tokens": 200,
        "stream": False
    }

    try:
        start_time = time.time()
        response = requests.post(url, headers=headers, json=data, timeout=120)
        response_time = time.time() - start_time

        if response.status_code == 200:
            result = response.json()
            choices = result.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                content = message.get("content", "")
                reasoning = message.get("reasoning", "")

                # 优先使用content，如果为空则使用reasoning
                raw_response = content if content.strip() else reasoning
                return raw_response, response_time, None
            else:
                return "", response_time, "响应中没有choices字段"
        else:
            return "", 0, f"API错误: {response.status_code} - {response.text[:100]}"

    except Exception as e:
        return "", 0, f"请求异常: {str(e)}"

def evaluate_sql_optimized(generated, expected):
    """优化版SQL评估"""
    if not generated:
        return "ERROR", "无生成内容"

    # 首先检查是否是有效SQL
    is_complete, completeness_msg = validate_sql_completeness(generated)
    if not is_complete:
        return "FAIL", f"SQL不完整: {completeness_msg}"

    # 精确匹配
    if generated.upper() == expected.upper():
        return "PASS", "精确匹配"

    # 忽略大小写和空白比较
    gen_norm = re.sub(r'\s+', ' ', generated.upper())
    exp_norm = re.sub(r'\s+', ' ', expected.upper())

    if gen_norm == exp_norm:
        return "PASS", "标准化后匹配"

    # 部分匹配检查
    gen_words = set(re.findall(r'\b\w+\b', gen_norm))
    exp_words = set(re.findall(r'\b\w+\b', exp_norm))
    common_words = gen_words.intersection(exp_words)

    if len(exp_words) > 0:
        similarity = len(common_words) / len(exp_words)
        if similarity > 0.8:
            return "PASS", f"高度相似 ({similarity:.1%})"
        elif similarity > 0.6:
            return "PARTIAL", f"部分匹配 ({len(common_words)}/{len(exp_words)} 关键词)"

    return "FAIL", "不匹配"

# ==================== 主测试函数 ====================

def run_optimized_test():
    """运行优化测试"""
    print("=" * 60)
    print("优化版SQL生成能力测试")
    print("=" * 60)
    print("优化特性:")
    print("1. 多级强制指令提示词")
    print("2. 智能SQL提取后处理")
    print("3. SQL完整性验证")
    print("4. 模型特定优化提示词")
    print("=" * 60)

    # 初始化
    schema = load_simplified_schema()
    test_cases = create_test_cases()
    models = get_models()

    print(f"数据库schema: 简化版（{schema.count('表')}个表）")
    print(f"测试用例: {len(test_cases)}个")
    print(f"测试模型: {', '.join(models)}")
    print()

    results = []
    total_tests = len(models) * len(test_cases)
    completed = 0

    for model in models:
        print(f"测试模型: {model}")

        for test_case in test_cases:
            print(f"  用例{test_case['id']}: {test_case['name']}...", end="", flush=True)

            # 创建优化提示词
            prompt = create_optimized_prompt(schema, test_case["query"])
            # 也可以使用模型特定提示词
            # prompt = create_model_specific_prompt(model, schema, test_case["query"])

            # 调用模型
            raw_sql, response_time, error = call_model(model, prompt)

            if error:
                print(f" [ERROR] ({response_time:.1f}s) - {error}")
                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": "ERROR",
                    "response_time": response_time,
                    "error": error,
                    "generated_sql": "",
                    "expected_sql": test_case["expected_sql"],
                    "prompt_type": "optimized"
                })
            else:
                # 智能SQL提取
                extracted_sql = extract_sql_from_response(raw_sql)

                # 清洗SQL
                cleaned_sql = clean_optimized_sql(extracted_sql)

                # 评估
                result, match_type = evaluate_sql_optimized(cleaned_sql, test_case["expected_sql"])

                print(f" [{result}] ({response_time:.1f}s) - {match_type}")

                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": result,
                    "response_time": response_time,
                    "match_type": match_type,
                    "raw_response": raw_sql[:200] + ("..." if len(raw_sql) > 200 else ""),
                    "extracted_sql": extracted_sql[:100] + ("..." if len(extracted_sql) > 100 else ""),
                    "cleaned_sql": cleaned_sql[:100] + ("..." if len(cleaned_sql) > 100 else ""),
                    "expected_sql": test_case["expected_sql"],
                    "prompt_type": "optimized"
                })

            completed += 1
            print(f"进度: {completed}/{total_tests}")

        print()

    # 计算得分
    print("\n" + "=" * 60)
    print("测试结果统计")
    print("=" * 60)

    scores = {}
    for model in models:
        model_results = [r for r in results if r["model"] == model]
        total = len(model_results)
        passed = len([r for r in model_results if r["result"] == "PASS"])
        partial = len([r for r in model_results if r["result"] == "PARTIAL"])
        errors = len([r for r in model_results if r["result"] == "ERROR"])
        total_time = sum(r["response_time"] for r in model_results)

        scores[model] = {
            "total": total,
            "passed": passed,
            "partial": partial,
            "errors": errors,
            "total_time": total_time,
            "avg_time": total_time / total if total > 0 else 0,
            "pass_rate": passed / total if total > 0 else 0,
            "effective_rate": (passed + partial * 0.5) / total if total > 0 else 0
        }

    # 显示排行榜
    print("\n模型排名（按有效得分排序）:")
    print("-" * 60)

    sorted_scores = sorted(scores.items(), key=lambda x: x[1]["effective_rate"], reverse=True)

    for i, (model, data) in enumerate(sorted_scores, 1):
        print(f"{i}. {model}")
        print(f"   通过率: {data['pass_rate']:.2%} ({data['passed']}/{data['total']})")
        print(f"   部分通过: {data['partial']}")
        print(f"   错误: {data['errors']}")
        print(f"   平均响应时间: {data['avg_time']:.2f}秒")
        print(f"   有效得分: {data['effective_rate']:.2%}")
        print()

    # 保存结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"optimized_test_results_{timestamp}.json"

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            "timestamp": timestamp,
            "optimization_version": "1.0",
            "optimizations": [
                "多级强制指令提示词",
                "智能SQL提取后处理",
                "SQL完整性验证",
                "模型特定优化提示词"
            ],
            "models": models,
            "test_cases": test_cases,
            "results": results,
            "scores": scores
        }, f, ensure_ascii=False, indent=2)

    print(f"结果已保存到: {output_file}")
    print("\n" + "=" * 60)
    print("优化测试完成")
    print("=" * 60)

    return sorted_scores

def run_model_specific_test():
    """运行模型特定优化测试"""
    print("=" * 60)
    print("模型特定优化提示词测试")
    print("=" * 60)

    schema = load_simplified_schema()
    test_cases = create_test_cases()
    models = get_models()

    results = []

    for model in models:
        print(f"\n测试模型（特定优化）: {model}")

        for test_case in test_cases:
            print(f"  用例{test_case['id']}: {test_case['name']}...", end="", flush=True)

            # 使用模型特定提示词
            prompt = create_model_specific_prompt(model, schema, test_case["query"])

            raw_sql, response_time, error = call_model(model, prompt)

            if error:
                print(f" [ERROR] ({response_time:.1f}s)")
                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": "ERROR",
                    "response_time": response_time,
                    "prompt_type": "model_specific"
                })
            else:
                extracted_sql = extract_sql_from_response(raw_sql)
                cleaned_sql = clean_optimized_sql(extracted_sql)
                result, match_type = evaluate_sql_optimized(cleaned_sql, test_case["expected_sql"])

                print(f" [{result}] ({response_time:.1f}s)")

                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": result,
                    "response_time": response_time,
                    "match_type": match_type,
                    "prompt_type": "model_specific"
                })

    # 分析模型特定优化的效果
    print("\n" + "=" * 60)
    print("模型特定优化效果分析")
    print("=" * 60)

    for model in models:
        model_results = [r for r in results if r["model"] == model]
        total = len(model_results)
        passed = len([r for r in model_results if r["result"] == "PASS"])
        partial = len([r for r in model_results if r["result"] == "PARTIAL"])

        if total > 0:
            effective_rate = (passed + partial * 0.5) / total
            print(f"{model}: 有效得分 {effective_rate:.2%}")

    return results

if __name__ == "__main__":
    # 运行优化测试
    optimized_scores = run_optimized_test()

    # 可选：运行模型特定优化测试
    # model_specific_results = run_model_specific_test()