#!/usr/bin/env python3
"""
简单测试服务器连接和模型响应
"""

import requests
import json
import time

def test_server_connection(base_url: str = "http://10.254.2.127:8001"):
    """测试服务器连接"""
    print(f"测试服务器: {base_url}")

    # 测试1: 根路径
    print("\n1. 测试根路径...")
    try:
        start = time.time()
        response = requests.get(base_url, timeout=10)
        elapsed = time.time() - start
        print(f"   状态: {response.status_code} (耗时: {elapsed:.2f}s)")
        if response.status_code == 200:
            print(f"   响应: {response.text[:100]}...")
    except Exception as e:
        print(f"   错误: {e}")

    # 测试2: 获取模型列表
    print("\n2. 获取模型列表...")
    try:
        start = time.time()
        response = requests.get(f"{base_url}/v1/models", timeout=15)
        elapsed = time.time() - start
        print(f"   状态: {response.status_code} (耗时: {elapsed:.2f}s)")
        if response.status_code == 200:
            data = response.json()
            models = data.get("data", [])
            print(f"   找到 {len(models)} 个模型:")
            for i, model in enumerate(models[:5]):
                print(f"     {i+1}. {model['id']}")
            if len(models) > 5:
                print(f"     ... 还有 {len(models)-5} 个模型")
    except Exception as e:
        print(f"   错误: {e}")

    # 测试3: 测试Text2SQL模型
    print("\n3. 测试Text2SQL模型...")
    test_models = ["HridaAI/hrida-t2sql-128k:latest", "a-kore/Arctic-Text2SQL-R1-7B:latest"]

    for model_name in test_models:
        print(f"\n   测试模型: {model_name}")
        url = f"{base_url}/v1/chat/completions"
        headers = {"Content-Type": "application/json"}

        # 简单的测试查询
        data = {
            "model": model_name,
            "messages": [
                {"role": "system", "content": "你是一个SQL专家。"},
                {"role": "user", "content": "查询test表的所有数据，只输出SQL语句"}
            ],
            "max_tokens": 50,
            "temperature": 0.0
        }

        try:
            start = time.time()
            response = requests.post(url, headers=headers, json=data, timeout=30)
            elapsed = time.time() - start
            print(f"     状态: {response.status_code} (耗时: {elapsed:.2f}s)")

            if response.status_code == 200:
                result = response.json()
                content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
                print(f"     响应: {content[:80]}...")
            else:
                print(f"     错误: {response.text[:100]}...")

        except Exception as e:
            print(f"     错误: {e}")

def main():
    """主函数"""
    print("=" * 60)
    print("服务器连接测试")
    print("=" * 60)

    test_server_connection()

    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)

if __name__ == "__main__":
    main()