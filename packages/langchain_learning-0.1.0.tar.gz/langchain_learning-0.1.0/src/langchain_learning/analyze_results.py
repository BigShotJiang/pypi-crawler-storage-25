#!/usr/bin/env python3
import json
import csv
from collections import defaultdict

def main():
    # 读取结果文件
    results_file = "comprehensive_results/sql_test_results_20260323_090140.json"
    scores_file = "comprehensive_results/sql_test_scores_20260323_090140.json"

    with open(results_file, 'r', encoding='utf-8') as f:
        results = json.load(f)

    with open(scores_file, 'r', encoding='utf-8') as f:
        scores = json.load(f)

    # 按模型分组结果
    model_results = defaultdict(list)
    for result in results:
        model_results[result["model_name"]].append(result)

    # 按测试用例分组结果
    case_results = defaultdict(list)
    for result in results:
        case_results[result["test_case_id"]].append(result)

    print("=" * 80)
    print("SQL生成能力测试结果分析")
    print("=" * 80)

    # 显示模型排名
    print("\n模型排名（按通过率）:")
    print("-" * 80)
    for i, score in enumerate(scores, 1):
        print(f"{i}. {score['model_name']}: {score['passed_rate']:.2%} ({score['passed_tests']}/{score['total_tests']})")

    # 分析每个模型的详细表现
    print("\n" + "=" * 80)
    print("各模型详细表现:")
    print("=" * 80)

    for model_name in sorted(model_results.keys()):
        model_data = model_results[model_name]
        passed = sum(1 for r in model_data if r["result"] == "PASS")
        total = len(model_data)
        pass_rate = passed / total if total > 0 else 0

        print(f"\n{model_name}:")
        print(f"  通过率: {pass_rate:.2%} ({passed}/{total})")

        # 显示通过的测试用例
        passed_cases = [r for r in model_data if r["result"] == "PASS"]
        if passed_cases:
            print("  通过的测试用例:")
            for case in passed_cases:
                print(f"    - 测试用例 {case['test_case_id']}: {case['generated_sql'][:50]}...")
        else:
            print("  无通过的测试用例")

        # 显示典型问题
        failed_cases = [r for r in model_data if r["result"] == "FAIL"][:2]
        if failed_cases:
            print("  典型失败案例:")
            for case in failed_cases:
                expected = case["expected_sql"]
                generated = case["generated_sql"]
                # 简化显示
                if len(generated) > 50:
                    generated = generated[:50] + "..."
                print(f"    - 测试用例 {case['test_case_id']}:")
                print(f"      预期: {expected}")
                print(f"      生成: {generated}")

    # 分析测试用例难度
    print("\n" + "=" * 80)
    print("测试用例通过率分析:")
    print("=" * 80)

    for case_id in sorted(case_results.keys()):
        case_data = case_results[case_id]
        passed = sum(1 for r in case_data if r["result"] == "PASS")
        total = len(case_data)
        pass_rate = passed / total if total > 0 else 0

        # 获取一个示例的预期SQL
        sample = case_data[0]
        print(f"\n测试用例 {case_id}:")
        print(f"  通过率: {pass_rate:.2%} ({passed}/{total})")
        print(f"  预期SQL: {sample['expected_sql']}")

        # 哪些模型通过了
        passed_models = [r["model_name"] for r in case_data if r["result"] == "PASS"]
        if passed_models:
            print(f"  通过的模型: {', '.join(passed_models)}")

    # 输出格式问题统计
    print("\n" + "=" * 80)
    print("输出格式问题分析:")
    print("=" * 80)

    format_issues = {
        "包含代码块标记 (```sql)": 0,
        "包含分号": 0,
        "包含额外解释文本": 0,
        "纯SQL输出": 0
    }

    for result in results:
        sql = result["generated_sql"]
        if "```sql" in sql or "```" in sql:
            format_issues["包含代码块标记 (```sql)"] += 1
        elif ";" in sql and result["result"] == "FAIL":
            # 检查是否仅因分号而失败
            expected = result["expected_sql"]
            generated_clean = sql.replace(";", "").strip()
            if generated_clean == expected:
                format_issues["包含分号"] += 1
        elif len(sql) > 200 or "SELECT" not in sql or "FROM" not in sql:
            format_issues["包含额外解释文本"] += 1
        else:
            format_issues["纯SQL输出"] += 1

    for issue, count in format_issues.items():
        percentage = count / len(results) * 100
        print(f"{issue}: {count}次 ({percentage:.1f}%)")

    # 生成建议
    print("\n" + "=" * 80)
    print("改进建议:")
    print("=" * 80)
    print("1. 加强提示工程: 要求模型只输出纯SQL，不要代码块标记和分号")
    print("2. 后处理清洗: 添加后处理步骤去除代码块标记和分号")
    print("3. 使用语义相似度评估: 而非精确字符串匹配")
    print("4. 提供示例: 在prompt中提供正确的输出格式示例")
    print("5. 模型筛选: 优先使用在简单测试中表现良好的模型")

if __name__ == "__main__":
    main()