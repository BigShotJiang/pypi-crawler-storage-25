#!/usr/bin/env python3
"""检查服务器模型列表"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 导入现有代码中的类
from examples.model_sql_comprehensive_test_full_db_optimized import OllamaModelFetcher

def main():
    server_url = "http://10.254.2.99:8001"
    print(f"检查服务器: {server_url}")

    fetcher = OllamaModelFetcher(base_url=server_url)

    try:
        all_models = fetcher.get_available_models()
        print(f"获取到 {len(all_models)} 个模型")

        # 显示所有模型
        print("\n所有模型列表:")
        for i, model in enumerate(all_models, 1):
            size_str = f" ({model.size:,}B)" if model.size else ""
            embed_tag = " [嵌入模型]" if model.is_embedding_model else ""
            print(f"  {i}. {model.name}{size_str}{embed_tag}")

        # 筛选适合SQL生成的模型
        suitable_models = fetcher.filter_suitable_models(all_models)
        print(f"\n适合SQL生成的模型: {len(suitable_models)} 个")

        for i, model in enumerate(suitable_models, 1):
            size_str = f" ({model.size:,}B)" if model.size else ""
            print(f"  {i}. {model.name}{size_str}")

        # 嵌入模型列表
        embedding_models = [m for m in all_models if m.is_embedding_model]
        print(f"\n嵌入模型: {len(embedding_models)} 个")
        for i, model in enumerate(embedding_models, 1):
            print(f"  {i}. {model.name}")

        print(f"\n总计: {len(all_models)} 个模型")
        print(f"  - 适合SQL生成: {len(suitable_models)} 个")
        print(f"  - 嵌入模型: {len(embedding_models)} 个")

    except Exception as e:
        print(f"检查失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()