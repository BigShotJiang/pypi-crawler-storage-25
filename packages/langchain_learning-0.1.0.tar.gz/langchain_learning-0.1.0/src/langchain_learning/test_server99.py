#!/usr/bin/env python3
import requests
import json

def check_server(server_url):
    print(f"检查服务器: {server_url}")
    try:
        # 获取模型列表
        response = requests.get(f"{server_url}/api/tags", timeout=10)
        if response.status_code == 200:
            data = response.json()
            models = data.get('models', [])
            print(f"可用模型数量: {len(models)}")
            for i, model in enumerate(models[:10], 1):
                name = model.get('name', '未知')
                print(f"{i}. {name}")
            return models
        else:
            print(f"获取失败: {response.status_code}")
            return []
    except Exception as e:
        print(f"错误: {e}")
        return []

# 检查两个服务器
print("=== 检查服务器 10.254.2.127 ===")
models_127 = check_server("http://10.254.2.127:8001")

print("\n=== 检查服务器 10.254.2.99 ===")
models_99 = check_server("http://10.254.2.99:8001")

# 比较模型
if models_127 and models_99:
    names_127 = {m.get('name') for m in models_127}
    names_99 = {m.get('name') for m in models_99}

    print(f"\n=== 模型比较 ===")
    print(f"127服务器有 {len(names_127)} 个模型")
    print(f"99服务器有 {len(names_99)} 个模型")
    print(f"共同模型: {len(names_127 & names_99)}")
    print(f"仅在127: {len(names_127 - names_99)}")
    print(f"仅在99: {len(names_99 - names_127)}")