#!/usr/bin/env python3
"""
测试强制指令对qwen3模型的影响
"""

import requests
import json
import time
import sys
import os

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import SQLGenerationTesterFullDBOptimized

def test_with_simple_query():
    """测试简单查询"""
    OLLAMA_URL = "http://10.254.2.99:8001"

    # 初始化测试器（使用简化schema）
    schema_text = """压缩版数据库结构（按主题分类）

数据库主题概览：
1. 基础信息：大学基本信息相关表（41个表）
2. 数据采集：各类数据采集表（34个表）
3. 科研项目：科研项目管理相关表（10个表）

主题1：基础信息
  表1：auto_base_daxueshezhi（大学设置表）
    原表名：auto_base_daxueshezhi
    描述：大学设置基本条件表
    关键字段（3个）：
      - field1: NVARCHAR(n), 备注: 条件名称
      - field2: INT, 备注: 条件值
      - status: INT, 备注: 状态"""

    print("初始化测试器...")
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url=f"{OLLAMA_URL}/v1",
        timeout=60,
        full_schema_text=schema_text
    )

    # 测试查询
    test_query = "查询大学设置基本条件表的所有记录"
    print(f"\n测试查询: {test_query}")

    # 方法1：使用测试器的generate_sql方法（修改后的）
    print("\n方法1：使用测试器的generate_sql方法")
    try:
        raw_response, cleaned_sql, response_time = tester.generate_sql(
            "qwen3:8b", test_query
        )
        print(f"响应时间: {response_time:.2f}秒")
        print(f"原始响应长度: {len(raw_response)} 字符")
        print(f"原始响应前200字符: {raw_response[:200]}...")
        print(f"清洗后SQL: {cleaned_sql}")
    except Exception as e:
        print(f"方法1失败: {e}")

    # 方法2：直接调用API进行更详细的检查
    print("\n" + "=" * 60)
    print("方法2：直接API调用分析")
    print("=" * 60)

    # 获取完整的提示词
    full_prompt = tester.prompt_template.invoke({"query": test_query})
    prompt_text = full_prompt.to_string()

    print(f"提示词大小: {len(prompt_text)} 字符")
    print(f"\n提示词开头300字符:")
    print("-" * 60)
    print(prompt_text[:300])
    print("-" * 60)

    # 检查关键指令
    check_instructions = [
        "输出格式：仅SQL语句，不要推理过程",
        "不要推理过程",
        "示例13：禁止推理过程",
        "只输出纯SQL语句"
    ]

    print("\n指令检查:")
    for instruction in check_instructions:
        found = instruction in prompt_text
        print(f"  {instruction}: {'✓' if found else '✗'}")

    # 直接调用OpenAI兼容API
    url = f"{OLLAMA_URL}/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    # 尝试不同的配置
    configs = [
        ("默认配置", {"model": "qwen3:8b", "messages": [{"role": "user", "content": prompt_text}], "temperature": 0.0, "max_tokens": 200}),
        ("增加max_tokens", {"model": "qwen3:8b", "messages": [{"role": "user", "content": prompt_text}], "temperature": 0.0, "max_tokens": 400}),
        ("使用系统消息", {"model": "qwen3:8b", "messages": [{"role": "system", "content": "你是一个SQL专家，只输出SQL语句，不要推理。"}, {"role": "user", "content": test_query}], "temperature": 0.0, "max_tokens": 200}),
    ]

    for config_name, data in configs:
        print(f"\n{config_name}:")
        print(f"  请求数据大小: {len(json.dumps(data))} 字节")

        try:
            start_time = time.time()
            response = requests.post(url, headers=headers, json=data, timeout=60)
            response_time = time.time() - start_time

            print(f"  响应时间: {response_time:.2f}秒")
            print(f"  状态码: {response.status_code}")

            if response.status_code == 200:
                result = response.json()
                choices = result.get("choices", [])
                if choices:
                    message = choices[0].get("message", {})
                    content = message.get("content", "")
                    reasoning = message.get("reasoning", "")

                    print(f"  content字段长度: {len(content)}")
                    print(f"  reasoning字段长度: {len(reasoning)}")

                    if content:
                        print(f"  content前100字符: {content[:100]}...")
                    elif reasoning:
                        print(f"  reasoning前100字符: {reasoning[:100]}...")

                    # 检查是否包含SQL
                    import re
                    sql_pattern = r'SELECT\s+.+?\s+FROM\s+\S+'
                    combined = content + " " + reasoning
                    sql_match = re.search(sql_pattern, combined, re.IGNORECASE)

                    if sql_match:
                        print(f"  找到SQL: {sql_match.group()}")
                    else:
                        # 检查是否至少有关键字
                        if "SELECT" in combined.upper():
                            print(f"  有SELECT关键字但未匹配完整模式")
                        else:
                            print(f"  未找到SQL")
            else:
                print(f"  错误: {response.text[:200]}")

        except Exception as e:
            print(f"  请求异常: {e}")

def main():
    print("测试强制指令对qwen3模型的影响")
    print("=" * 60)
    print("注意：qwen3模型默认启用推理模式，此测试检查强制指令是否有效")
    print("=" * 60)

    test_with_simple_query()

    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)

if __name__ == "__main__":
    main()