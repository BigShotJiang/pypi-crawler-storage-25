#!/usr/bin/env python3
"""
测试max_tokens对SQL生成的影响
"""

import requests
import time

OLLAMA_URL = "http://10.254.2.99:8001"

def test_with_different_tokens(model_name, prompt, max_tokens_list):
    """测试不同max_tokens设置"""
    url = f"{OLLAMA_URL}/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    results = {}

    for max_tokens in max_tokens_list:
        data = {
            "model": model_name,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
            "max_tokens": max_tokens,
            "stream": False
        }

        try:
            start_time = time.time()
            response = requests.post(url, headers=headers, json=data, timeout=60)
            response_time = time.time() - start_time

            if response.status_code == 200:
                result = response.json()
                choices = result.get("choices", [])
                if choices:
                    message = choices[0].get("message", {})
                    content = message.get("content", "")
                    reasoning = message.get("reasoning", "")
                    raw_response = content if content.strip() else reasoning

                    results[max_tokens] = {
                        "response": raw_response,
                        "response_time": response_time,
                        "length": len(raw_response),
                        "truncated": len(raw_response) >= max_tokens * 0.9  # 如果接近max_tokens，可能被截断
                    }
            else:
                results[max_tokens] = {
                    "error": f"API错误: {response.status_code}",
                    "response_time": response_time
                }

        except Exception as e:
            results[max_tokens] = {
                "error": str(e),
                "response_time": 0
            }

        # 短暂暂停
        time.sleep(2)

    return results

def main():
    # 测试提示词
    prompt = """# SQL生成专家

## 强制指令
输出格式：仅SQL语句，不要推理过程

## 数据库schema
压缩版数据库结构（关键表）：
1. auto_base_daxueshezhi（大学设置表）- 字段: field1, field2, status

## 当前查询
查询大学设置基本条件表的所有记录

## 请生成SQL语句："""

    model = "qwen3:32b"
    max_tokens_list = [50, 100, 200, 300, 500]

    print(f"测试模型: {model}")
    print(f"测试不同的max_tokens值: {max_tokens_list}")
    print("-" * 60)

    results = test_with_different_tokens(model, prompt, max_tokens_list)

    for max_tokens, data in results.items():
        print(f"\nmax_tokens = {max_tokens}:")
        if "error" in data:
            print(f"  错误: {data['error']}")
        else:
            print(f"  响应长度: {data['length']} 字符")
            print(f"  响应时间: {data['response_time']:.2f}秒")
            print(f"  可能截断: {data['truncated']}")
            print(f"  响应前100字符: {data['response'][:100]}...")

            # 检查是否包含SQL
            if "SELECT" in data['response'].upper():
                print("  ✓ 包含SQL")
            else:
                print("  ✗ 不包含SQL")

if __name__ == "__main__":
    main()