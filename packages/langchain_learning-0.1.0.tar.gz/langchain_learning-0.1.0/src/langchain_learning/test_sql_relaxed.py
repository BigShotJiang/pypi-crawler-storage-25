#!/usr/bin/env python3
"""宽松匹配版SQL生成测试"""

import time
import json
import re
import requests
from typing import List, Tuple, Dict

def normalize_sql(sql: str) -> str:
    """
    规范化SQL语句，用于宽松匹配

    规则：
    1. 转换为大写（可选，这里保持原样）
    2. 移除分号
    3. 移除SQL代码块标记 (```sql, ```)
    4. 移除推理标记 (</think>, <think>)
    5. 标准化空格（移除多余空格和换行）
    6. 移除常见前缀/后缀
    7. 忽略列别名差异（通过后处理评估）
    """
    if not sql:
        return ""

    # 1. 移除推理标记
    sql = re.sub(r'</?think>', '', sql, flags=re.IGNORECASE)

    # 2. 移除代码块标记
    sql = re.sub(r'```sql|```', '', sql, flags=re.IGNORECASE)

    # 3. 移除分号
    sql = sql.rstrip(';')

    # 4. 移除首尾空格和换行
    sql = sql.strip()

    # 5. 标准化空格：将多个空格/换行/制表符替换为单个空格
    sql = re.sub(r'\s+', ' ', sql)

    # 6. 移除常见的非SQL前缀
    prefixes = [
        "sql",
        "query:",
        "answer:",
        "response:",
        "generated sql:",
        "here is the sql:",
        "the sql query is:",
        "select"
    ]

    for prefix in prefixes:
        if sql.lower().startswith(prefix):
            sql = sql[len(prefix):].strip()

    return sql

def compare_sql_relaxed(generated: str, expected: str) -> Dict[str, any]:
    """
    宽松比较两个SQL语句

    返回比较结果和详细信息
    """
    if not generated or generated.startswith("ERROR:"):
        return {"match": False, "reason": "无输出或错误", "details": generated}

    # 规范化SQL
    gen_norm = normalize_sql(generated)
    exp_norm = normalize_sql(expected)

    # 完全匹配
    if gen_norm == exp_norm:
        return {"match": True, "reason": "完全匹配", "details": ""}

    # 检查是否语义等价
    # 1. 检查SELECT子句
    gen_select = extract_select_clause(gen_norm)
    exp_select = extract_select_clause(exp_norm)

    # 2. 检查FROM子句
    gen_from = extract_from_clause(gen_norm)
    exp_from = extract_from_clause(exp_norm)

    # 3. 检查WHERE条件
    gen_where = extract_where_clause(gen_norm)
    exp_where = extract_where_clause(exp_norm)

    # 4. 检查GROUP BY
    gen_group = extract_group_by_clause(gen_norm)
    exp_group = extract_group_by_clause(exp_norm)

    # 基础检查：表名是否正确
    if gen_from.lower() != exp_from.lower():
        return {
            "match": False,
            "reason": "表名错误",
            "details": f"生成表名: {gen_from}, 预期表名: {exp_from}"
        }

    # SELECT * 的简单情况
    if exp_norm.upper() == "SELECT * FROM " + exp_from.upper():
        if gen_norm.upper().startswith("SELECT * FROM " + exp_from.upper()):
            # 检查是否有额外的WHERE条件（不应该有）
            if gen_where and not exp_where:
                return {"match": False, "reason": "多余WHERE条件", "details": gen_where}
            return {"match": True, "reason": "SELECT * 语义匹配", "details": ""}

    # WHERE条件检查
    if exp_where and not gen_where:
        return {"match": False, "reason": "缺少WHERE条件", "details": f"预期: {exp_where}"}

    if gen_where and not exp_where:
        return {"match": False, "reason": "多余WHERE条件", "details": f"生成: {gen_where}"}

    # GROUP BY检查
    if exp_group and not gen_group:
        return {"match": False, "reason": "缺少GROUP BY", "details": f"预期: {exp_group}"}

    if gen_group and not exp_group:
        return {"match": False, "reason": "多余GROUP BY", "details": f"生成: {gen_group}"}

    # 如果所有关键元素都匹配，考虑为语义正确
    key_elements_correct = True
    issues = []

    if gen_select.lower() != exp_select.lower():
        # 检查是否只是别名差异
        gen_select_base = re.sub(r'\s+as\s+\w+', '', gen_select, flags=re.IGNORECASE)
        exp_select_base = re.sub(r'\s+as\s+\w+', '', exp_select, flags=re.IGNORECASE)

        if gen_select_base.lower() != exp_select_base.lower():
            key_elements_correct = False
            issues.append(f"SELECT子句不同: 生成={gen_select}, 预期={exp_select}")

    if gen_where and exp_where and gen_where.lower() != exp_where.lower():
        key_elements_correct = False
        issues.append(f"WHERE条件不同: 生成={gen_where}, 预期={exp_where}")

    if gen_group and exp_group and gen_group.lower() != exp_group.lower():
        key_elements_correct = False
        issues.append(f"GROUP BY不同: 生成={gen_group}, 预期={exp_group}")

    if key_elements_correct and not issues:
        return {"match": True, "reason": "语义匹配（忽略别名差异）", "details": "; ".join(issues) if issues else ""}
    else:
        return {
            "match": False,
            "reason": "语义不匹配",
            "details": "; ".join(issues) if issues else f"生成: {gen_norm}, 预期: {exp_norm}"
        }

def extract_select_clause(sql: str) -> str:
    """提取SELECT子句"""
    match = re.search(r'SELECT\s+(.*?)\s+FROM', sql, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()
    return ""

def extract_from_clause(sql: str) -> str:
    """提取FROM子句（表名）"""
    # 查找FROM后面的表名
    match = re.search(r'FROM\s+(\S+)', sql, re.IGNORECASE)
    if match:
        return match.group(1).strip()

    # 如果没有FROM，尝试其他模式
    match = re.search(r'FROM\s+([^\s;]+)', sql, re.IGNORECASE)
    if match:
        return match.group(1).strip()

    return ""

def extract_where_clause(sql: str) -> str:
    """提取WHERE子句"""
    match = re.search(r'WHERE\s+(.*?)(?:\s+GROUP BY|\s+ORDER BY|;|$)', sql, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()
    return ""

def extract_group_by_clause(sql: str) -> str:
    """提取GROUP BY子句"""
    match = re.search(r'GROUP BY\s+(.*?)(?:\s+ORDER BY|;|$)', sql, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()
    return ""

def get_ollama_models(base_url: str = "http://10.254.2.99:8001") -> List[str]:
    """获取Ollama服务器上的所有模型"""
    try:
        response = requests.get(f"{base_url}/v1/models", timeout=10)
        if response.status_code == 200:
            models = response.json().get("data", [])
            return [model.get("id") for model in models if model.get("id")]
        return []
    except Exception as e:
        print(f"获取模型列表失败: {e}")
        return []

def generate_sql_simple(model_name: str, query: str, schema_text: str = None) -> Tuple[str, float]:
    """生成SQL语句（简化版）"""

    # 简化的schema，只包含几个关键表
    if not schema_text:
        schema_text = """数据库表结构：
1. auto_base_daxueshezhi (大学设置基本条件表)
   - zongguimo: INT (总规模)
   - yanjiusheng: INT (研究生)
   - zhishaoyou5jieshuoshiyanjiusheng: NVARCHAR(n) (至少拥有5届硕士研究生)

2. auto_caiji_chuangxin_team (创新团队表)
   - year: NVARCHAR(n) (年度)
   - name: NVARCHAR(n) (团队名称)
   - level: NVARCHAR(n) (级别)

3. auto_caiji_fuwu_summarykyxmdzjf (科研项目到账经费表)
   - xueyuanName: NVARCHAR(n) (所属院系)
   - money_1: DECIMAL (纵向项目到账经费)
   - year: NVARCHAR(n) (年度)
"""

    prompt = f"""根据以下数据库表结构和自然语言查询，生成正确的SQL语句。

只生成纯SQL语句，不要有任何额外的解释、注释或文本。

数据库表结构：
{schema_text}

自然语言查询：
{query}

SQL语句："""

    # 使用OpenAI兼容API
    url = "http://10.254.2.99:8001/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "model": model_name,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.0,
        "max_tokens": 512,
        "stream": False
    }

    start_time = time.time()
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        response_time = time.time() - start_time

        if response.status_code == 200:
            result = response.json()
            content = result.get("choices", [{}])[0].get("message", {}).get("content", "").strip()

            return content, response_time
        else:
            error_msg = f"HTTP {response.status_code}: {response.text}"
            return f"ERROR: {error_msg}", response_time

    except Exception as e:
        response_time = time.time() - start_time
        return f"ERROR: {str(e)}", response_time

def run_test_suite():
    """运行测试套件（宽松匹配版）"""

    print("=" * 80)
    print("宽松匹配版SQL生成能力测试")
    print("=" * 80)

    # 获取模型列表
    models = get_ollama_models()
    if not models:
        print("没有找到可用模型")
        return

    print(f"找到 {len(models)} 个模型:")
    for i, model in enumerate(models, 1):
        print(f"  {i}. {model}")

    # 测试用例
    test_cases = [
        {
            "id": 1,
            "name": "简单SELECT查询",
            "query": "查询大学设置基本条件表的所有记录",
            "expected": "SELECT * FROM auto_base_daxueshezhi"
        },
        {
            "id": 2,
            "name": "带WHERE条件的查询",
            "query": "查询创新团队表中年度为2023的记录",
            "expected": "SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'"
        },
        {
            "id": 3,
            "name": "聚合查询",
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
            "expected": "SELECT xueyuanName, SUM(money_1) as total_money_1 FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName"
        }
    ]

    print(f"\n测试用例 ({len(test_cases)} 个):")
    for case in test_cases:
        print(f"  {case['id']}. {case['name']}: {case['query']}")

    # 运行测试
    results = []

    for model_idx, model_name in enumerate(models, 1):
        print(f"\n[{model_idx}/{len(models)}] 测试模型: {model_name}")

        for case in test_cases:
            print(f"  测试用例 {case['id']}: {case['name']}...", end="", flush=True)

            sql, resp_time = generate_sql_simple(model_name, case["query"])

            # 评估结果（宽松匹配）
            if sql.startswith("ERROR:"):
                result = "ERROR"
                comparison = {"match": False, "reason": "模型错误", "details": sql}
            else:
                comparison = compare_sql_relaxed(sql, case["expected"])
                if comparison["match"]:
                    result = "PASS"
                else:
                    result = "FAIL"

            results.append({
                "model": model_name,
                "test_case_id": case["id"],
                "test_case_name": case["name"],
                "query": case["query"],
                "expected_sql": case["expected"],
                "generated_sql": sql,
                "normalized_generated": normalize_sql(sql) if not sql.startswith("ERROR:") else "",
                "normalized_expected": normalize_sql(case["expected"]),
                "result": result,
                "response_time": resp_time,
                "comparison_result": comparison
            })

            print(f" {result} ({resp_time:.2f}s) - {comparison['reason']}")

    # 保存结果
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    output_file = f"sql_test_relaxed_results_{timestamp}.json"

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # 计算统计
    model_stats = {}
    for result in results:
        model = result["model"]
        if model not in model_stats:
            model_stats[model] = {"total": 0, "passed": 0, "total_time": 0.0}

        model_stats[model]["total"] += 1
        model_stats[model]["total_time"] += result["response_time"]

        if result["result"] == "PASS":
            model_stats[model]["passed"] += 1

    # 显示排行榜
    print("\n" + "=" * 80)
    print("排行榜（宽松匹配）")
    print("=" * 80)

    sorted_models = sorted(
        model_stats.items(),
        key=lambda x: (x[1]["passed"] / x[1]["total"], -x[1]["total_time"] / x[1]["total"]),
        reverse=True
    )

    for i, (model_name, stats) in enumerate(sorted_models, 1):
        passed_rate = stats["passed"] / stats["total"] if stats["total"] > 0 else 0
        avg_time = stats["total_time"] / stats["total"] if stats["total"] > 0 else 0

        print(f"{i}. {model_name}")
        print(f"   通过率: {passed_rate:.2%} ({stats['passed']}/{stats['total']})")
        print(f"   平均响应时间: {avg_time:.2f}秒")

    # 生成详细报告
    report_file = f"sql_test_relaxed_report_{timestamp}.txt"
    with open(report_file, "w", encoding="utf-8") as f:
        f.write("宽松匹配版SQL生成能力测试报告\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"测试时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"服务器地址: http://10.254.2.99:8001\n")
        f.write(f"测试模型数: {len(models)}\n")
        f.write(f"测试用例数: {len(test_cases)}\n")
        f.write(f"匹配策略: 宽松语义匹配\n\n")

        f.write("匹配规则说明:\n")
        f.write("1. 移除分号、代码块标记、推理标记\n")
        f.write("2. 标准化空格和换行\n")
        f.write("3. 检查关键SQL元素（SELECT, FROM, WHERE, GROUP BY）\n")
        f.write("4. 允许列别名差异\n")
        f.write("5. 允许条件顺序差异\n\n")

        f.write("模型排名:\n")
        f.write("-" * 80 + "\n")
        for i, (model_name, stats) in enumerate(sorted_models, 1):
            passed_rate = stats["passed"] / stats["total"] if stats["total"] > 0 else 0
            avg_time = stats["total_time"] / stats["total"] if stats["total"] > 0 else 0

            f.write(f"第{i}名: {model_name}\n")
            f.write(f"  通过率: {passed_rate:.2%} ({stats['passed']}/{stats['total']})\n")
            f.write(f"  平均响应时间: {avg_time:.2f}秒\n\n")

        f.write("\n详细结果:\n")
        f.write("=" * 80 + "\n")
        for model_name in models:
            f.write(f"\n{model_name}:\n")
            f.write("-" * 40 + "\n")

            model_results = [r for r in results if r["model"] == model_name]
            for result in sorted(model_results, key=lambda x: x["test_case_id"]):
                f.write(f"测试用例 {result['test_case_id']}: {result['test_case_name']}\n")
                f.write(f"  查询: {result['query']}\n")
                f.write(f"  预期SQL: {result['expected_sql']}\n")
                f.write(f"  生成SQL: {result['generated_sql']}\n")
                f.write(f"  规范化后: {result['normalized_generated']}\n")
                f.write(f"  预期规范化: {result['normalized_expected']}\n")
                f.write(f"  匹配结果: {result['comparison_result']['reason']}\n")
                if result['comparison_result']['details']:
                    f.write(f"  匹配详情: {result['comparison_result']['details']}\n")
                f.write(f"  最终结果: {result['result']} (响应时间: {result['response_time']:.2f}秒)\n\n")

    print(f"\n结果已保存到: {output_file}")
    print(f"报告已保存到: {report_file}")

    # 对比严格匹配和宽松匹配的结果
    print("\n" + "=" * 80)
    print("匹配策略对比分析")
    print("=" * 80)

    # 加载之前的严格匹配结果
    strict_file = "sql_test_simple_results_20260324_091140.json"
    try:
        with open(strict_file, "r", encoding="utf-8") as f:
            strict_results = json.load(f)

        print(f"加载了严格匹配结果: {strict_file}")

        # 对比每个模型的表现
        comparison_stats = {}
        for result in results:
            model = result["model"]
            if model not in comparison_stats:
                comparison_stats[model] = {"strict_passes": 0, "relaxed_passes": 0, "total": 0}

            comparison_stats[model]["total"] += 1
            if result["result"] == "PASS":
                comparison_stats[model]["relaxed_passes"] += 1

        # 计算严格匹配的通过数
        for strict_result in strict_results:
            model = strict_result["model"]
            if model in comparison_stats:
                if strict_result["result"] == "PASS":
                    comparison_stats[model]["strict_passes"] += 1

        print("\n匹配策略对比:")
        print("模型                严格匹配通过率  宽松匹配通过率  提升")
        print("-" * 70)

        for model_name, stats in comparison_stats.items():
            strict_rate = stats["strict_passes"] / stats["total"] if stats["total"] > 0 else 0
            relaxed_rate = stats["relaxed_passes"] / stats["total"] if stats["total"] > 0 else 0
            improvement = relaxed_rate - strict_rate

            print(f"{model_name[:20]:20} {strict_rate:>15.1%} {relaxed_rate:>15.1%} {improvement:>10.1%}")

    except FileNotFoundError:
        print(f"未找到严格匹配结果文件: {strict_file}")

    print(f"\n测试完成!")

if __name__ == "__main__":
    run_test_suite()