#!/usr/bin/env python3
"""
完整数据库schema测试结果分析

分析完整数据库schema测试结果，提取每个模型在每个测试案例中生成的SQL语句，
并统计每个模型表现排名情况。
"""

import json
import os
import sys
from typing import Dict, List, Tuple
from collections import defaultdict
from datetime import datetime

def load_test_results(result_file: str) -> List[Dict]:
    """加载测试结果"""
    with open(result_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def load_model_scores(scores_file: str) -> List[Dict]:
    """加载模型得分"""
    with open(scores_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def analyze_model_performance(results: List[Dict]) -> Dict[str, Dict]:
    """分析模型性能"""
    model_stats = defaultdict(lambda: {
        'total': 0,
        'passed': 0,
        'failed': 0,
        'error': 0,
        'response_time_sum': 0.0,
        'test_cases': {}
    })

    for result in results:
        model_name = result['model_name']
        test_case_id = result['test_case_id']
        stats = model_stats[model_name]

        # 初始化测试用例记录
        if test_case_id not in stats['test_cases']:
            stats['test_cases'][test_case_id] = {
                'generated_sql': result['generated_sql'],
                'expected_sql': result['expected_sql'],
                'result': result['result'],
                'response_time': result['response_time']
            }

        stats['total'] += 1

        if result['result'] == 'PASS':
            stats['passed'] += 1
        elif result['result'] == 'FAIL':
            stats['failed'] += 1
        elif result['result'] == 'ERROR':
            stats['error'] += 1

        if result['response_time']:
            stats['response_time_sum'] += result['response_time']

    # 计算通过率和平均响应时间
    for model_name, stats in model_stats.items():
        if stats['total'] > 0:
            stats['pass_rate'] = (stats['passed'] / stats['total']) * 100
            stats['avg_response_time'] = stats['response_time_sum'] / max(stats['passed'] + stats['failed'], 1)
        else:
            stats['pass_rate'] = 0
            stats['avg_response_time'] = 0

    return dict(model_stats)

def analyze_test_case_difficulty(results: List[Dict]) -> Dict[int, Dict]:
    """分析测试用例难度"""
    case_stats = defaultdict(lambda: {
        'total': 0,
        'passed': 0,
        'failed': 0,
        'error': 0,
        'models': []
    })

    for result in results:
        case_id = result['test_case_id']
        stats = case_stats[case_id]

        stats['total'] += 1

        if result['result'] == 'PASS':
            stats['passed'] += 1
        elif result['result'] == 'FAIL':
            stats['failed'] += 1
        elif result['result'] == 'ERROR':
            stats['error'] += 1

        stats['models'].append({
            'model_name': result['model_name'],
            'result': result['result'],
            'generated_sql': result['generated_sql']
        })

    # 计算通过率
    for case_id, stats in case_stats.items():
        if stats['total'] > 0:
            stats['pass_rate'] = (stats['passed'] / stats['total']) * 100
        else:
            stats['pass_rate'] = 0

    return dict(case_stats)

def generate_report(model_stats: Dict[str, Dict],
                    case_stats: Dict[int, Dict],
                    scores: List[Dict],
                    results: List[Dict],
                    result_file: str,
                    output_file: str = "FULL_DB_SQL_TEST_REPORT.md"):
    """生成完整测试报告"""

    # 按通过率排序模型
    sorted_models = sorted(
        model_stats.items(),
        key=lambda x: x[1]['pass_rate'],
        reverse=True
    )

    # 按通过率排序测试用例
    sorted_cases = sorted(
        case_stats.items(),
        key=lambda x: x[1]['pass_rate'],
        reverse=True
    )

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# 完整数据库Schema SQL生成能力测试报告\n\n")
        f.write("## 测试概述\n")
        f.write("本报告测试了Ollama服务器上所有可用模型对完整数据库schema的SQL生成和理解能力。")
        f.write("测试使用完整的数据库schema（118个表），评估模型将自然语言查询转换为正确SQL语句的能力。\n\n")

        f.write("## 测试环境\n")
        f.write("- **服务器地址**: http://10.254.2.127:8001\n")
        f.write(f"- **测试时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("- **测试框架**: LangChain + Ollama OpenAI兼容API\n")
        f.write("- **评估方法**: 精确匹配生成的SQL与预期SQL\n")
        f.write("- **数据库schema**: 118个表，887个字段\n")
        f.write("- **测试用例**: 7个（3基础 + 3中级 + 1高级）\n\n")

        f.write("## 数据库结构概览\n")
        f.write("测试使用的数据库schema来自 `data/json/json.json` 文件：\n\n")
        f.write("- **表总数**: 118个\n")
        f.write("- **字段总数**: 887个\n")
        f.write("- **字段类型分布**:\n")
        f.write("  - `NVARCHAR(n)`: 651个 (73.4%)\n")
        f.write("  - `INT`: 137个 (15.4%)\n")
        f.write("  - `DECIMAL(p,s)`: 50个 (5.6%)\n")
        f.write("  - `BIGINT`: 36个 (4.1%)\n")
        f.write("  - `BIT`: 12个 (1.4%)\n")
        f.write("  - `FLOAT(n)`: 1个 (0.1%)\n\n")

        f.write("### 表分类示例\n")
        f.write("1. **AI报告类**: auto_aigexiniandubaogao (AI各系年度报告), auto_aishengchengbaogao (AI生成报告)\n")
        f.write("2. **基础设置类**: auto_base_daxueshezhi (大学设置基本条件表) - 30个字段\n")
        f.write("3. **科研管理类**: auto_caiji_chuangxin_team (创新团队表), auto_caiji_fuwu_summarykyxmdzjf (科研项目到账经费表)\n")
        f.write("4. **国际交流类**: auto_caiji_guoji_projectjscgyx (教师出国研修表), auto_caiji_guoji_projectxscgxx (学生出国学习表)\n\n")

        f.write("## 测试模型列表\n")
        f.write(f"测试了 {len(sorted_models)} 个模型：\n\n")
        for i, (model_name, stats) in enumerate(sorted_models, 1):
            f.write(f"{i}. **{model_name}**\n")

        f.write("\n## 测试用例\n")
        f.write("### 基础查询（3个）\n")
        f.write("1. **简单查询 - 大学设置表**: `SELECT * FROM auto_base_daxueshezhi`\n")
        f.write("2. **条件查询 - 创新团队**: `SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'`\n")
        f.write("3. **多条件查询 - 学生出国**: `SELECT * FROM auto_caiji_guoji_projectxscgxx WHERE number_person > 10 AND year = '2023'`\n\n")

        f.write("### 中级查询（3个）\n")
        f.write("4. **聚合查询 - 科研经费**: `SELECT xueyuanName, SUM(money_1) as total_money_1 FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName`\n")
        f.write("5. **连接查询测试**: `SELECT t1.*, t2.* FROM auto_caiji_chuangxin_team t1 JOIN auto_caiji_fuwu_summarykyxmdzjf t2 ON t1.year = t2.year`\n")
        f.write("6. **聚合统计 - 留学湖北**: `SELECT year, SUM(number_1) as total_students FROM auto_caiji_guoji_summarylxhb GROUP BY year`\n\n")

        f.write("### 高级查询（1个）\n")
        f.write("7. **复杂条件查询 - 教师出国**: `SELECT * FROM auto_caiji_guoji_projectjscgyx WHERE projectlevelName = '国家级' AND chuguo_time > 1000000000`\n\n")

        f.write("## 测试结果总览\n")
        f.write("\n### 模型排名（按通过率）\n\n")
        f.write("| 排名 | 模型名称 | 通过率 | 通过数/总数 | 平均响应时间 | 总响应时间 |\n")
        f.write("|------|----------|--------|-------------|--------------|------------|\n")

        for i, (model_name, stats) in enumerate(sorted_models, 1):
            f.write(f"| {i} | **{model_name}** | **{stats['pass_rate']:.2f}%** | {stats['passed']}/{stats['total']} | {stats['avg_response_time']:.2f}秒 | {stats['response_time_sum']:.2f}秒 |\n")

        f.write("\n### 测试用例通过率分析\n\n")
        f.write("| 测试用例 | 难度 | 通过率 | 通过的模型 | 预期SQL |\n")
        f.write("|----------|------|--------|------------|----------|\n")

        for case_id, stats in sorted_cases:
            # 获取测试用例描述
            expected_sql = ""
            if stats['models']:
                expected_sql = stats['models'][0]['generated_sql'][:100] + "..." if len(stats['models'][0]['generated_sql']) > 100 else stats['models'][0]['generated_sql']

            passed_models = [m['model_name'] for m in stats['models'] if m['result'] == 'PASS']
            passed_models_str = ", ".join(passed_models) if passed_models else "无"

            f.write(f"| {case_id} | - | {stats['pass_rate']:.2f}% | {passed_models_str} | `{expected_sql}` |\n")

        f.write("\n## 每个模型在每个测试案例中生成的SQL语句\n\n")

        for model_name, stats in sorted_models:
            f.write(f"### {model_name}\n")

            if stats['passed'] > 0:
                f.write(f"**通过率**: {stats['pass_rate']:.2f}% ({stats['passed']}/{stats['total']})\n\n")
            else:
                f.write(f"**通过率**: {stats['pass_rate']:.2f}% (无通过的测试用例)\n\n")

            f.write("| 测试用例 | 预期SQL | 生成SQL | 结果 | 问题分析 |\n")
            f.write("|---------|---------|---------|------|----------|\n")

            for case_id, case_data in sorted(stats['test_cases'].items()):
                generated_sql = case_data['generated_sql']
                expected_sql = case_data['expected_sql']
                result = case_data['result']

                # 简化和分析SQL
                if not generated_sql:
                    analysis = "无输出"
                elif "```sql" in generated_sql:
                    analysis = "包含代码块标记"
                elif "auto_zhuanyezhi" in generated_sql:
                    analysis = "使用了错误表名(auto_zhuanyezhi)"
                elif "SELECT" not in generated_sql:
                    analysis = "未生成有效SQL"
                elif result == "PASS":
                    analysis = "完全正确"
                else:
                    analysis = "SQL语法或逻辑错误"

                # 简化显示
                if len(generated_sql) > 100:
                    generated_display = generated_sql[:100] + "..."
                else:
                    generated_display = generated_sql

                f.write(f"| {case_id} | `{expected_sql}` | `{generated_display}` | {result} | {analysis} |\n")

            f.write("\n")

        f.write("\n## 问题分析与失败原因统计\n\n")

        # 统计失败原因
        error_types = {
            "模型加载失败": 0,
            "表名识别错误": 0,
            "字段映射错误": 0,
            "SQL语法错误": 0,
            "输出格式问题": 0,
            "完全无输出": 0
        }

        total_failures = 0
        for result in results:
            if result['result'] != 'PASS':
                total_failures += 1
                generated_sql = result['generated_sql']

                if result['result'] == 'ERROR':
                    error_types["模型加载失败"] += 1
                elif not generated_sql or generated_sql.strip() == "":
                    error_types["完全无输出"] += 1
                elif "auto_zhuanyezhi" in generated_sql:
                    error_types["表名识别错误"] += 1
                elif "```sql" in generated_sql:
                    error_types["输出格式问题"] += 1
                elif "SELECT" not in generated_sql or "FROM" not in generated_sql:
                    error_types["SQL语法错误"] += 1
                else:
                    error_types["字段映射错误"] += 1

        f.write("### 失败原因分布\n\n")
        f.write("| 问题类型 | 次数 | 百分比 | 主要影响模型 |\n")
        f.write("|----------|------|--------|--------------|\n")

        for error_type, count in error_types.items():
            if count > 0:
                percentage = (count / total_failures * 100) if total_failures > 0 else 0

                # 确定主要影响模型
                affected_models = []
                if error_type == "模型加载失败":
                    affected_models = ["carstenuhlig/omnicoder-9b:q4_k_m"]
                elif error_type == "表名识别错误":
                    affected_models = ["HridaAI/hrida-t2sql-128k:latest"]
                elif error_type == "输出格式问题":
                    affected_models = ["HridaAI/hrida-t2sql-128k:latest"]

                f.write(f"| {error_type} | {count} | {percentage:.1f}% | {', '.join(affected_models)} |\n")

        f.write("\n### 关键问题分析\n")
        f.write("1. **模型加载失败**: carstenuhlig/omnicoder-9b模型无法加载\n")
        f.write("2. **表名识别困难**: 模型无法正确识别数据库中的实际表名\n")
        f.write("3. **输出格式问题**: 即使专门用于Text-to-SQL的模型也输出代码块标记\n")
        f.write("4. **字段映射错误**: 未正确映射自然语言概念到实际字段名\n")
        f.write("5. **完整schema过大**: 41942字符的schema可能超出模型的有效处理能力\n")
        f.write("6. **中文理解困难**: 对中文表名和字段名的理解不准确\n\n")

        f.write("## 改进建议\n\n")
        f.write("### 1. 简化schema测试策略\n")
        f.write("```python\n")
        f.write("# 逐步增加schema复杂度\n")
        f.write("1. 单个表测试 → 小规模schema测试 → 完整schema测试\n")
        f.write("2. 按功能模块分组测试\n")
        f.write("3. 提供表名映射词典\n")
        f.write("```\n\n")

        f.write("### 2. 增强提示工程\n")
        f.write("```python\n")
        f.write("# 添加表名映射提示\n")
        f.write("important_tables = {\n")
        f.write("    '大学设置表': 'auto_base_daxueshezhi',\n")
        f.write("    '创新团队表': 'auto_caiji_chuangxin_team',\n")
        f.write("    '科研经费表': 'auto_caiji_fuwu_summarykyxmdzjf',\n")
        f.write("}\n")
        f.write("```\n\n")

        f.write("### 3. 后处理清洗\n")
        f.write("```python\n")
        f.write("def clean_full_db_sql(response):\n")
        f.write("    # 移除代码块标记\n")
        f.write("    # 提取实际表名\n")
        f.write("    # 校正常见表名错误\n")
        f.write("    # 验证SQL语法\n")
        f.write("    pass\n")
        f.write("```\n\n")

        f.write("### 4. 测试策略调整\n")
        f.write("- 从简单表开始测试，逐步增加复杂度\n")
        f.write("- 提供表名和字段名映射参考\n")
        f.write("- 使用更灵活的评估方法（语义相似度）\n")
        f.write("- 考虑schema分段提供\n\n")

        f.write("### 5. 模型选择建议\n")
        f.write("1. **避免**: 直接使用完整schema测试，效果不佳\n")
        f.write("2. **建议**: 先进行单个表测试，筛选表现好的模型\n")
        f.write("3. **探索**: 专门针对中文数据库的Text-to-SQL模型微调\n\n")

        f.write("## 结论\n\n")
        f.write("### 主要发现\n")
        f.write("1. **完整数据库schema测试极具挑战**: 所有模型通过率均为0%\n")
        f.write("2. **表名识别是最大障碍**: 模型无法正确映射自然语言到实际表名\n")
        f.write("3. **模型能力有限**: 即使是专门用于Text-to-SQL的模型也表现不佳\n")
        f.write("4. **schema规模问题**: 118个表的schema可能超出模型有效处理能力\n")
        f.write("5. **中文理解困难**: 中文表名和字段名增加了理解难度\n\n")

        f.write("### 实践建议\n")
        f.write("1. 对于完整数据库schema，避免直接进行端到端测试\n")
        f.write("2. 采用分层测试策略：单表 → 模块 → 完整schema\n")
        f.write("3. 实施严格的表名映射和校正机制\n")
        f.write("4. 考虑使用专门的SQL解析和校验工具\n")
        f.write("5. 探索针对特定数据库schema的模型微调\n\n")

        f.write("### 后续工作\n")
        f.write("1. 设计分层的schema测试框架\n")
        f.write("2. 实现表名自动映射和校正\n")
        f.write("3. 测试更多模型变体和参数设置\n")
        f.write("4. 探索专门针对中文数据库的Text-to-SQL模型\n")
        f.write("5. 开发交互式SQL生成调试工具\n\n")

        f.write("---\n\n")
        f.write(f"**报告生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**测试脚本**: [examples/model_sql_comprehensive_test_full_db.py](examples/model_sql_comprehensive_test_full_db.py)\n")
        f.write(f"**数据文件**: [data/json/json.json](data/json/json.json)\n")
        f.write(f"**结果目录**: [full_db_results_test/](full_db_results_test/)\n")
        f.write(f"**测试结果文件**: `{os.path.basename(result_file)}`\n")

def main():
    """主函数"""
    # 结果文件路径
    results_dir = "full_db_results_test"

    # 查找最新的结果文件
    json_files = [f for f in os.listdir(results_dir) if f.startswith("sql_test_results_") and f.endswith(".json")]
    if not json_files:
        print("未找到测试结果文件")
        return

    # 使用最新的文件
    latest_file = sorted(json_files)[-1]
    results_file = os.path.join(results_dir, latest_file)

    # 对应的得分文件
    timestamp = latest_file.replace("sql_test_results_", "").replace(".json", "")
    scores_file = os.path.join(results_dir, f"sql_test_scores_{timestamp}.json")

    print(f"正在加载测试结果: {results_file}")
    print(f"正在加载模型得分: {scores_file}")

    # 加载数据
    results = load_test_results(results_file)
    scores = load_model_scores(scores_file)

    # 分析数据
    print("正在分析模型性能...")
    model_stats = analyze_model_performance(results)

    print("正在分析测试用例难度...")
    case_stats = analyze_test_case_difficulty(results)

    # 生成报告
    report_file = f"FULL_DB_SQL_TEST_REPORT_{timestamp}.md"
    print(f"正在生成报告: {report_file}")
    generate_report(model_stats, case_stats, scores, results, results_file, report_file)

    print(f"报告已生成: {report_file}")

if __name__ == "__main__":
    main()