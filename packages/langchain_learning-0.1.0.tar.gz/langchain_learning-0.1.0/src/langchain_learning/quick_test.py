#!/usr/bin/env python3
"""快速测试：简化提示词测试模型响应"""

import requests
import time
import json

def test_model_simple(model_name="gemma3:27b"):
    """使用简化提示词测试模型"""
    url = "http://10.254.2.99:8001/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    # 简化提示词：只包含查询和少量表信息
    prompt = """你是一个SQL生成助手。根据以下信息生成SQL：

数据库中有以下表：
- auto_base_daxueshezhi (大学设置基本条件表)
- auto_caiji_chuangxin_team (创新团队表)

查询：查询大学设置基本条件表的所有记录

只输出SQL语句，不要解释。"""

    data = {
        "model": model_name,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.0,
        "max_tokens": 100,
        "stream": False
    }

    print(f"测试模型: {model_name}")
    print(f"提示词长度: {len(prompt)} 字符")

    try:
        start_time = time.time()
        response = requests.post(url, headers=headers, json=data, timeout=120)
        response_time = time.time() - start_time
        print(f"响应时间: {response_time:.2f}秒")
        print(f"状态码: {response.status_code}")

        response.raise_for_status()
        response_data = response.json()

        # 提取响应
        choices = response_data.get("choices", [])
        if choices:
            message = choices[0].get("message", {})
            content = message.get("content", "")
            print(f"生成的SQL: {content}")
            return True, content, response_time
        else:
            print(f"响应中没有choices字段")
            return False, "", response_time

    except requests.exceptions.Timeout as e:
        print(f"请求超时: {e}")
        return False, "", 0
    except requests.exceptions.RequestException as e:
        print(f"请求异常: {e}")
        return False, "", 0
    except Exception as e:
        print(f"其他错误: {e}")
        return False, "", 0

def test_multiple_models():
    """测试多个模型"""
    models = ["gemma3:27b", "glm-4.7-flash:q4_K_M", "qwen3:8b"]

    results = {}
    for model in models:
        print(f"\n{'='*60}")
        print(f"测试模型: {model}")
        print(f"{'='*60}")

        success, sql, rt = test_model_simple(model)
        results[model] = {
            "success": success,
            "sql": sql,
            "response_time": rt
        }

        # 模型间延迟
        if model != models[-1]:
            delay = 10
            print(f"\n等待 {delay} 秒...")
            time.sleep(delay)

    return results

if __name__ == "__main__":
    print("快速测试：简化提示词测试模型SQL生成能力")
    print("=" * 60)

    results = test_multiple_models()

    print(f"\n{'='*60}")
    print("测试结果汇总:")
    print("=" * 60)

    for model, result in results.items():
        status = "成功" if result["success"] else "失败"
        print(f"{model}: {status}, 响应时间: {result['response_time']:.2f}秒")
        if result["success"] and result["sql"]:
            print(f"  生成的SQL: {result['sql'][:100]}...")