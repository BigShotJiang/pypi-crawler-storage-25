#!/usr/bin/env python3
"""检查测试用例与schema的匹配情况"""

import json
import re

def extract_table_names(sql):
    """从SQL中提取表名"""
    # 简单的表名提取
    tables = set()

    # 查找FROM和JOIN后面的表名
    from_matches = re.findall(r'FROM\s+(\w+)', sql, re.IGNORECASE)
    join_matches = re.findall(r'JOIN\s+(\w+)', sql, re.IGNORECASE)

    tables.update(from_matches)
    tables.update(join_matches)

    # 检查是否有别名
    for table in list(tables):
        # 如果有空格，可能是表名+别名
        if ' ' in table:
            tables.remove(table)
            tables.add(table.split()[0])

    return list(tables)

def main():
    # 加载schema
    with open("data/json/compressed_schema.json", 'r', encoding='utf-8') as f:
        schema_data = json.load(f)

    # 收集所有表名
    all_tables = set()
    if "themes" in schema_data:
        for theme in schema_data["themes"]:
            for table in theme["tables"]:
                all_tables.add(table["original_name"])

    print(f"Schema中表总数: {len(all_tables)}")

    # 加载测试用例
    with open("test_cases_complex.json", 'r', encoding='utf-8') as f:
        test_cases = json.load(f)

    print(f"测试用例总数: {len(test_cases)}")

    # 检查每个测试用例
    print("\n测试用例表名匹配检查:")
    all_test_tables = set()

    for tc in test_cases:
        sql = tc["expected_sql"]
        tables = extract_table_names(sql)

        print(f"\n测试用例 {tc['id']}: {tc['name']}")
        print(f"  难度: {tc['difficulty']}")
        print(f"  使用表: {', '.join(tables) if tables else '无'}")

        missing_tables = []
        for table in tables:
            all_test_tables.add(table)
            if table not in all_tables:
                missing_tables.append(table)

        if missing_tables:
            print(f"  警告: 以下表不在schema中: {', '.join(missing_tables)}")
        else:
            print(f"  所有表都在schema中")

    print(f"\n测试用例中使用的唯一表数: {len(all_test_tables)}")
    print(f"测试用例使用的表: {', '.join(sorted(all_test_tables))}")

    # 检查SQL Server语法兼容性
    print("\nSQL Server语法检查:")
    server_keywords = ["TOP", "WITH", "OVER", "PARTITION BY", "RANK()"]
    for tc in test_cases:
        sql = tc["expected_sql"].upper()
        used_features = []
        for keyword in server_keywords:
            if keyword in sql:
                used_features.append(keyword)

        if used_features:
            print(f"测试用例 {tc['id']} 使用SQL Server特性: {', '.join(used_features)}")

    # 显示测试用例示例
    print("\n测试用例详情:")
    for tc in test_cases:
        print(f"\n{tc['id']}. {tc['name']}")
        print(f"   查询: {tc['natural_language_query']}")
        print(f"   SQL: {tc['expected_sql']}")

if __name__ == "__main__":
    main()