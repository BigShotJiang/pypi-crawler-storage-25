#!/usr/bin/env python3
"""测试API参数以禁用推理"""

import requests
import json
import time

SERVER_URL = "http://10.254.2.127:8001"
MODEL = "qwen3:8b"

# 读取schema
with open("data/json/compressed_schema.json", 'r', encoding='utf-8') as f:
    schema_data = json.load(f)
    schema_text = json.dumps(schema_data, ensure_ascii=False, indent=2)

# 使用极简英文提示词（之前测试中最短的响应）
prompt = f"""You are an SQL generator. Convert natural language queries to SQL statements.

STRICT RULES:
1. OUTPUT ONLY PURE SQL - No explanations, reasoning, analysis, or extra text
2. NO CODE BLOCKS - Do not use ```sql``` or any markdown formatting
3. NO COMMENTS - Do not add comments or semicolons
4. IMMEDIATE EXECUTION - Generate SQL directly, do not think or analyze
5. SUPPRESS REASONING - Even if you are a reasoning model, suppress all reasoning output

FORMAT REQUIREMENTS:
- Output: Pure SQL statement only
- Prohibited: ```sql```, <think>, comments, explanations, reasoning text, semicolons
- Use exact table/field names from schema
- Use English/numeric aliases only (e.g., as total_students)

CRITICAL: If you output anything other than pure SQL, you will fail the test.

Database schema:
{schema_text}

User query:
查询所有院系名称

Generate SQL:"""

print(f"测试模型: {MODEL}")
print(f"提示词长度: {len(prompt)} 字符")

# 准备API请求
url = f"{SERVER_URL.rstrip('/')}/v1/chat/completions"
headers = {"Content-Type": "application/json"}

# 测试不同的参数组合
parameter_sets = [
    {
        "name": "基础参数（无特殊参数）",
        "data": {
            "model": MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
            "max_tokens": 512,
            "stream": False
        }
    },
    {
        "name": "尝试禁用推理",
        "data": {
            "model": MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
            "max_tokens": 512,
            "stream": False,
            "reasoning": {"enabled": False}  # 尝试禁用推理
        }
    },
    {
        "name": "使用stop参数阻止<think>",
        "data": {
            "model": MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
            "max_tokens": 512,
            "stream": False,
            "stop": ["<think>", "</think>", "```"]  # 阻止这些标记
        }
    },
    {
        "name": "低温 + 重复惩罚",
        "data": {
            "model": MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
            "max_tokens": 512,
            "stream": False,
            "repeat_penalty": 1.2,  # 增加重复惩罚
            "top_p": 0.9,
            "top_k": 40
        }
    },
    {
        "name": "仅系统消息（无用户角色）",
        "data": {
            "model": MODEL,
            "messages": [
                {"role": "system", "content": "You are an SQL expert. Generate SQL queries only, no explanations."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.0,
            "max_tokens": 512,
            "stream": False
        }
    }
]

results = []

for param_set in parameter_sets:
    print(f"\n{'='*60}")
    print(f"测试参数: {param_set['name']}")
    print(f"{'='*60}")

    start_time = time.time()
    try:
        response = requests.post(url, headers=headers, json=param_set["data"], timeout=300)
        response_time = time.time() - start_time

        if response.status_code != 200:
            print(f"  [错误] API返回状态码: {response.status_code}")
            print(f"        响应: {response.text[:200]}")
            results.append({
                "name": param_set["name"],
                "success": False,
                "status_code": response.status_code,
                "error": response.text[:200],
                "response_time": response_time
            })
            continue

        response_data = response.json()

        # 提取响应
        choices = response_data.get("choices", [])
        if not choices:
            print(f"  [错误] API响应中没有choices字段")
            results.append({
                "name": param_set["name"],
                "success": False,
                "error": "No choices in response",
                "response_time": response_time
            })
            continue

        message = choices[0].get("message", {})
        raw_response = message.get("content", "")

        print(f"  响应时间: {response_time:.2f}秒")
        print(f"  响应长度: {len(raw_response)} 字符")
        print(f"  响应内容: {repr(raw_response[:200])}")

        # 分析响应
        contains_think = '<think>' in raw_response.lower()
        contains_code_block = '```' in raw_response
        starts_with_select = raw_response.strip().upper().startswith('SELECT')

        print(f"  分析结果:")
        print(f"    - 包含<think>: {contains_think}")
        print(f"    - 包含代码块标记: {contains_code_block}")
        print(f"    - 以SELECT开头: {starts_with_select}")

        # 判断是否成功
        success = starts_with_select and not contains_think and not contains_code_block
        status = "[成功]" if success else "[失败]"
        print(f"  {status}")

        results.append({
            "name": param_set["name"],
            "success": True,
            "follows_instructions": success,
            "response_time": response_time,
            "response_length": len(raw_response),
            "contains_think": contains_think,
            "contains_code_block": contains_code_block,
            "starts_with_select": starts_with_select,
            "raw_response_preview": raw_response[:200]
        })

    except Exception as e:
        response_time = time.time() - start_time
        print(f"  [错误] 请求失败: {e}")
        results.append({
            "name": param_set["name"],
            "success": False,
            "error": str(e),
            "response_time": response_time
        })

    # 在请求之间添加延迟
    time.sleep(5)

# 打印汇总结果
print(f"\n{'='*80}")
print("API参数测试汇总")
print("=" * 80)

for result in results:
    if result.get("success", False):
        status = "[遵循]" if result.get("follows_instructions", False) else "[未遵循]"
        issues = []
        if result.get("contains_think", False):
            issues.append("<think>标签")
        if result.get("contains_code_block", False):
            issues.append("代码块标记")
        if not result.get("starts_with_select", False):
            issues.append("不以SELECT开头")

        issue_text = f" ({', '.join(issues)})" if issues else ""
        print(f"{status} {result['name']}: {result['response_time']:.1f}秒{issue_text}")
    else:
        print(f"[错误] {result['name']}: {result.get('error', '未知错误')}")

# 保存结果
timestamp = time.strftime("%Y%m%d_%H%M%S")
output_file = f"api_parameters_test_results_{timestamp}.json"
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump({
        "timestamp": timestamp,
        "server_url": SERVER_URL,
        "model": MODEL,
        "results": results
    }, f, ensure_ascii=False, indent=2)

print(f"\n结果已保存到: {output_file}")