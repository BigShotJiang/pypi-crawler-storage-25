#!/usr/bin/env python3
"""
测试优化后的提示词效果
"""

import os
import json
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import (
    SQLGenerationTesterFullDBOptimized, TestCase, TestResult, TestResultRecord
)

def load_schema():
    """加载数据库schema"""
    schema_file = "data/json/compressed_schema.json"
    with open(schema_file, 'r', encoding='utf-8') as f:
        schema_data = json.load(f)

    # 转换为文本格式（与FullDatabaseSchemaLoader类似）
    lines = []
    lines.append("# 数据库schema（共118个表）")

    for theme in schema_data.get('themes', []):
        theme_name = theme.get('name', '未知主题')
        theme_desc = theme.get('description', '')
        lines.append(f"\n## 主题: {theme_name}")
        if theme_desc:
            lines.append(f"描述: {theme_desc}")

        for table in theme.get('tables', []):
            table_name = table.get('original_name', '')
            table_label = table.get('label', '')
            table_desc = table.get('description', '')

            lines.append(f"\n### 表: {table_name}")
            lines.append(f"标签: {table_label}")
            if table_desc:
                lines.append(f"描述: {table_desc}")

            key_fields = table.get('key_fields', [])
            if key_fields:
                lines.append("关键字段:")
                for field in key_fields:
                    field_name = field.get('name', '')
                    field_type = field.get('type', '')
                    field_remark = field.get('remark', '')
                    lines.append(f"  - {field_name} ({field_type}): {field_remark}")

    return '\n'.join(lines)

def test_single_query():
    """测试单个查询"""
    print("=" * 60)
    print("测试优化后的提示词效果")
    print("=" * 60)

    # 加载schema
    print("加载数据库schema...")
    schema_text = load_schema()
    print(f"Schema大小: {len(schema_text)} 字符")

    # 初始化测试器
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url="http://10.254.2.127:8001",
        timeout=120,
        full_schema_text=schema_text
    )

    # 测试查询
    test_queries = [
        {
            "query": "查询大学设置基本条件表的所有记录",
            "expected": "SELECT * FROM auto_base_daxueshezhi",
            "name": "简单SELECT查询"
        },
        {
            "query": "查询创新团队表中所属院系为计算机学院的记录",
            "expected": "SELECT * FROM auto_caiji_chuangxin_team WHERE xueyuanname = '计算机学院'",
            "name": "WHERE条件查询"
        },
        {
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和，并按照经费总额降序排列",
            "expected": "SELECT xueyuanname, SUM(money_1) as total_money FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanname ORDER BY total_money DESC",
            "name": "GROUP BY聚合查询"
        }
    ]

    # 测试模型
    test_model = "gemma3:27b"  # 选择一个表现较好的模型

    print(f"\n测试模型: {test_model}")
    print("-" * 40)

    for test in test_queries:
        print(f"\n测试: {test['name']}")
        print(f"查询: {test['query']}")
        print(f"预期SQL: {test['expected']}")

        try:
            # 生成SQL
            raw_response, cleaned_sql, response_time = tester.generate_sql(
                model_name=test_model,
                query=test['query']
            )

            print(f"原始响应: {raw_response[:200]}...")
            print(f"清洗后SQL: {cleaned_sql}")
            print(f"响应时间: {response_time:.2f}秒")

            # 简单评估
            if cleaned_sql.strip() == test['expected'].strip():
                print("✅ 测试通过!")
            else:
                print("❌ 测试失败")
                # 检查是否为部分匹配
                if test['expected'].split()[0].upper() == 'SELECT' and cleaned_sql.split()[0].upper() == 'SELECT':
                    print("  但生成了SQL语句，需要进一步评估")

        except Exception as e:
            print(f"❌ 生成SQL时出错: {e}")

        print("-" * 40)

def test_dynamic_schema():
    """测试动态schema选择功能"""
    print("\n" + "=" * 60)
    print("测试动态schema选择功能")
    print("=" * 60)

    # 加载schema
    schema_text = load_schema()

    # 初始化测试器
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url="http://10.254.2.127:8001",
        timeout=120,
        full_schema_text=schema_text
    )

    # 测试不同的查询
    test_queries = [
        "查询大学设置基本条件表的所有记录",
        "查询创新团队表中所属院系为计算机学院的记录",
        "统计留学湖北表中2023年度每个省份的在籍外国留学生总人数"
    ]

    for query in test_queries:
        print(f"\n查询: {query}")

        # 提取相关schema
        relevant_schema = tester.extract_relevant_schema(query, top_k=3)

        print("相关schema (前500字符):")
        print(relevant_schema[:500] + "...")
        print(f"总长度: {len(relevant_schema)} 字符")

        # 构建提示词
        prompt = tester.build_prompt(query)
        print(f"提示词长度: {len(prompt)} 字符")

        # 检查是否包含完整的schema
        if "相关表schema（根据查询自动筛选" in prompt:
            print("✅ 动态schema选择生效")
        else:
            print("⚠️  可能使用了完整schema")

def main():
    """主函数"""
    try:
        # 测试动态schema选择
        test_dynamic_schema()

        # 测试实际SQL生成
        test_single_query()

    except Exception as e:
        print(f"测试过程中出错: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()