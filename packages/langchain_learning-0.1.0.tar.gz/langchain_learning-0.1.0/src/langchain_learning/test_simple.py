#!/usr/bin/env python3
import requests
import json

# 测试Ollama服务器连接
base_url = "http://10.254.2.127:8001"
try:
    # 测试API/tags
    response = requests.get(f"{base_url}/api/tags", timeout=5)
    if response.status_code == 200:
        data = response.json()
        print(f"服务器连接成功！获取到 {len(data.get('models', []))} 个模型")
        for model in data.get('models', [])[:5]:
            print(f"  - {model.get('name')}")
    else:
        print(f"服务器响应异常: {response.status_code}")
except Exception as e:
    print(f"连接服务器失败: {e}")

# 测试qwen3:8b模型是否可用
try:
    # 检查模型是否存在
    response = requests.post(f"{base_url}/api/show", json={"name": "qwen3:8b"}, timeout=5)
    if response.status_code == 200:
        print("qwen3:8b 模型可用")
    else:
        print(f"qwen3:8b 模型可能不存在: {response.status_code}")
except Exception as e:
    print(f"检查模型失败: {e}")