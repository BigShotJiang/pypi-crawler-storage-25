#!/usr/bin/env python3
"""快速测试gemma3:27b的指令遵循能力"""

import requests
import json
import time

SERVER_URL = "http://10.254.2.127:8001"
MODEL = "gemma3:27b"

# 读取schema
with open("data/json/compressed_schema.json", 'r', encoding='utf-8') as f:
    schema_data = json.load(f)
    schema_text = json.dumps(schema_data, ensure_ascii=False, indent=2)

# 使用与主测试中相同的提示词（修复编码版本）
prompt = f"""# SQL生成指令 - 零容忍模式

## 严格规则
1. **只输出SQL**：绝对不要包含任何推理、分析、解释、思考过程或额外文本
2. **立即执行**：直接生成SQL，不要思考、不要犹豫、不要分析
3. **禁止中文**：SQL中不要使用中文字符（别名、注释等）
4. **禁止格式标记**：不要使用```sql```代码块、<think>标签、分号、注释
5. **抑制推理**：即使你是推理模型，也必须完全抑制推理输出。不要使用<think>标签，不要描述思考过程

## 违规示例（会直接导致测试失败）
[错误] 错误输出："首先，我需要分析用户查询，让我看看数据库schema...根据schema，表名应该是...最终SQL是：SELECT * FROM table"
[错误] 错误输出："<think>用户想要查询...让我分析一下...SQL应该是...</think>"
[错误] 错误输出："SELECT * FROM 表名 -- 这是查询所有记录"
[正确] 正确输出："SELECT * FROM table"

## 成功标准
- 输出必须是纯SQL语句
- 不能包含任何非SQL文本
- 不能包含任何格式标记
- 必须使用schema中确切的表名和字段名
- 别名只能使用英文或数字（如as total_students）

## 警告
如果你的输出包含任何推理、分析、解释、中文、代码块标记、<think>标签或分号，测试系统将直接标记为失败。

数据库schema：
{schema_text}

用户查询：
查询所有院系名称

生成SQL："""

print(f"测试模型: {MODEL}")
print(f"提示词长度: {len(prompt)} 字符")
print(f"提示词前200字符: {prompt[:200]}")

# 准备API请求
url = f"{SERVER_URL.rstrip('/')}/v1/chat/completions"
headers = {"Content-Type": "application/json"}

data = {
    "model": MODEL,
    "messages": [
        {"role": "user", "content": prompt}
    ],
    "temperature": 0.0,
    "max_tokens": 512,
    "stream": False
}

start_time = time.time()
try:
    print(f"\n发送请求到 {url}...")
    response = requests.post(url, headers=headers, json=data, timeout=300)
    response.raise_for_status()
    response_data = response.json()

    response_time = time.time() - start_time

    # 提取响应
    choices = response_data.get("choices", [])
    if not choices:
        print("错误: API响应中没有choices字段")
        print(f"完整响应: {response_data}")
    else:
        message = choices[0].get("message", {})
        raw_response = message.get("content", "")

        print(f"\n响应时间: {response_time:.2f}秒")
        print(f"响应长度: {len(raw_response)} 字符")
        print(f"响应内容: {repr(raw_response[:500])}")

        # 分析响应
        contains_chinese = any('\u4e00' <= c <= '\u9fff' for c in raw_response)
        contains_think = '<think>' in raw_response.lower()
        contains_explanation = any(word in raw_response.lower() for word in ['首先', '然后', '需要', '应该', '让我'])
        starts_with_select = raw_response.strip().upper().startswith('SELECT')

        print(f"\n分析结果:")
        print(f"  包含中文: {contains_chinese}")
        print(f"  包含<think>: {contains_think}")
        print(f"  包含解释文本: {contains_explanation}")
        print(f"  以SELECT开头: {starts_with_select}")

        if starts_with_select and not contains_chinese and not contains_think and not contains_explanation:
            print("[成功] 模型成功遵循指令: 输出纯SQL")
        else:
            print("[失败] 模型未遵循指令: 输出包含非SQL内容")

except Exception as e:
    print(f"请求失败: {e}")
    import traceback
    traceback.print_exc()