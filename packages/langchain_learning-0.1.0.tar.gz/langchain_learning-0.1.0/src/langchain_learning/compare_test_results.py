#!/usr/bin/env python3
"""
对比原始测试和改进测试的结果
"""

import json
import os
from typing import Dict, List, Tuple
from collections import defaultdict

def load_results(result_file: str) -> List[Dict]:
    """加载测试结果"""
    with open(result_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def analyze_model_performance(results: List[Dict]) -> Dict[str, Dict]:
    """分析模型性能"""
    model_stats = defaultdict(lambda: {
        'total': 0,
        'passed': 0,
        'failed': 0,
        'error': 0,
        'partial': 0,
        'response_time_sum': 0.0
    })

    for result in results:
        model_name = result['model_name']
        stats = model_stats[model_name]
        stats['total'] += 1

        if result['result'] == 'PASS':
            stats['passed'] += 1
        elif result['result'] == 'PARTIAL':
            stats['partial'] += 1
        elif result['result'] == 'FAIL':
            stats['failed'] += 1
        elif result['result'] == 'ERROR':
            stats['error'] += 1

        if 'response_time' in result and result['response_time']:
            stats['response_time_sum'] += result['response_time']

    # 计算通过率和平均响应时间
    for model_name, stats in model_stats.items():
        if stats['total'] > 0:
            stats['pass_rate'] = (stats['passed'] / stats['total']) * 100
            stats['partial_rate'] = (stats['partial'] / stats['total']) * 100
            stats['composite_score'] = stats['pass_rate'] + (stats['partial_rate'] * 0.5)
            stats['avg_response_time'] = stats['response_time_sum'] / max(stats['passed'] + stats['failed'] + stats['partial'], 1)
        else:
            stats['pass_rate'] = 0
            stats['partial_rate'] = 0
            stats['composite_score'] = 0
            stats['avg_response_time'] = 0

    return dict(model_stats)

def compare_results(original_results: Dict[str, Dict], improved_results: Dict[str, Dict]) -> Dict[str, Dict]:
    """比较两个测试结果"""
    comparison = {}

    # 找出所有模型（并集）
    all_models = set(original_results.keys()) | set(improved_results.keys())

    for model_name in all_models:
        original = original_results.get(model_name, {})
        improved = improved_results.get(model_name, {})

        comparison[model_name] = {
            'original': {
                'pass_rate': original.get('pass_rate', 0),
                'passed': original.get('passed', 0),
                'total': original.get('total', 0),
                'composite_score': original.get('composite_score', 0),
                'avg_response_time': original.get('avg_response_time', 0)
            },
            'improved': {
                'pass_rate': improved.get('pass_rate', 0),
                'passed': improved.get('passed', 0),
                'partial': improved.get('partial', 0),
                'total': improved.get('total', 0),
                'composite_score': improved.get('composite_score', 0),
                'avg_response_time': improved.get('avg_response_time', 0)
            },
            'improvement': {
                'pass_rate_change': improved.get('pass_rate', 0) - original.get('pass_rate', 0),
                'composite_score_change': improved.get('composite_score', 0) - original.get('composite_score', 0),
                'avg_response_time_change': improved.get('avg_response_time', 0) - original.get('avg_response_time', 0)
            }
        }

    return comparison

def print_comparison_report(comparison: Dict[str, Dict]):
    """打印比较报告"""
    print("=" * 100)
    print("SQL生成能力测试改进效果对比报告")
    print("=" * 100)
    print("\n")

    # 按综合得分改进排序
    sorted_models = sorted(
        comparison.items(),
        key=lambda x: x[1]['improvement']['composite_score_change'],
        reverse=True
    )

    print("模型改进效果排名：")
    print("-" * 100)
    print(f"{'模型名称':<40} {'原始通过率':<12} {'改进通过率':<12} {'改进幅度':<12} {'综合得分改进':<15}")
    print("-" * 100)

    for model_name, data in sorted_models:
        original = data['original']
        improved = data['improved']
        improvement = data['improvement']

        print(f"{model_name:<40} "
              f"{original['pass_rate']:>10.1f}% "
              f"{improved['pass_rate']:>10.1f}% "
              f"{improvement['pass_rate_change']:>+10.1f}% "
              f"{improvement['composite_score_change']:>+13.1f}%")

    print("\n" + "=" * 100)
    print("详细分析：")
    print("=" * 100)

    for model_name, data in sorted_models:
        original = data['original']
        improved = data['improved']
        improvement = data['improvement']

        print(f"\n模型: {model_name}")
        print(f"  原始测试: 通过率 {original['pass_rate']:.1f}% ({original['passed']}/{original['total']}), "
              f"综合得分 {original['composite_score']:.1f}%")
        print(f"  改进测试: 通过率 {improved['pass_rate']:.1f}% ({improved['passed']}/{improved['total']}), "
              f"部分通过 {improved.get('partial', 0)}个, "
              f"综合得分 {improved['composite_score']:.1f}%")

        if improvement['pass_rate_change'] > 0:
            print(f"  [IMPROVED] 改进效果: 通过率提升 {improvement['pass_rate_change']:+.1f}%, "
                  f"综合得分提升 {improvement['composite_score_change']:+.1f}%")
        else:
            print(f"  [NO CHANGE] 无明显改进或下降")

def main():
    """主函数"""
    # 原始测试结果文件路径
    original_file = "comprehensive_results/sql_test_results_20260323_090140.json"
    improved_file = "improved_results/sql_test_results_20260323_092104.json"

    if not os.path.exists(original_file):
        print(f"原始测试结果文件不存在: {original_file}")
        return

    if not os.path.exists(improved_file):
        print(f"改进测试结果文件不存在: {improved_file}")
        return

    print("正在加载测试结果...")
    original_results = load_results(original_file)
    improved_results = load_results(improved_file)

    print("正在分析模型性能...")
    original_stats = analyze_model_performance(original_results)
    improved_stats = analyze_model_performance(improved_results)

    print("正在比较结果...")
    comparison = compare_results(original_stats, improved_stats)

    print_comparison_report(comparison)

    # 总结改进效果
    print("\n" + "=" * 100)
    print("改进措施效果总结：")
    print("=" * 100)
    print("1. 后处理清洗器：成功去除代码块标记(```sql)和分号，使HridaAI模型通过率从0%提升到37.5%")
    print("2. 多级评估策略：增加清洗后匹配、标准化匹配和语义相似度评估")
    print("3. 部分匹配评估：识别部分正确的SQL查询")
    print("4. 自动筛选嵌入模型：避免测试不适合的模型")
    print("5. 增强提示工程：添加格式控制示例和few-shot学习")
    print("\n仍存在的问题：")
    print("1. JOIN查询、子查询、复杂条件查询仍然普遍失败")
    print("2. 某些模型（如omnicoder）服务器端加载失败")
    print("3. 语义相似度评估的精度仍需改进")
    print("\n进一步优化建议：")
    print("1. 针对复杂查询设计专门的测试用例和提示模板")
    print("2. 实现更精细的SQL语法树解析和比较")
    print("3. 考虑使用专门的SQL解析库进行语义评估")
    print("4. 优化超时设置和错误处理机制")

if __name__ == "__main__":
    main()