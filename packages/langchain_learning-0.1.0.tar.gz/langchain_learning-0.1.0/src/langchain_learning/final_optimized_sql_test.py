#!/usr/bin/env python3
"""
最终优化版SQL生成测试
基于测试经验总结的实用优化方案：
1. 接受模型会推理的事实，专注于SQL提取
2. 智能修复不完整SQL
3. 灵活的评估方法
"""

import requests
import json
import time
import re
from datetime import datetime

OLLAMA_URL = "http://10.254.2.99:8001"

def load_simplified_schema():
    """加载简化schema"""
    return """压缩版数据库结构（关键表）：
1. auto_base_daxueshezhi（大学设置表）- 字段: field1, field2, status
2. auto_caiji_chuangxin_team（创新团队表）- 字段: year, team_name, members
3. auto_caiji_fuwu_summarykyxmdzjf（科研项目到账经费表）- 字段: xueyuanName, money_1, year
4. auto_caiji_guoji_projectjscgyx（教师出国研修表）- 字段: projectlevelName, chuguo_time, teacher_name
5. auto_caiji_guoji_projectxscgxx（学生出国学习表）- 字段: year, number_person, destination
6. auto_caiji_guoji_summarylxhb（留学湖北表）- 字段: year, number_1, student_type"""

def create_test_cases():
    """创建测试用例"""
    return [
        {
            "id": 1,
            "name": "简单查询",
            "query": "查询大学设置基本条件表的所有记录",
            "expected_sql": "SELECT * FROM auto_base_daxueshezhi"
        },
        {
            "id": 2,
            "name": "条件查询",
            "query": "查询创新团队表中年度为2023的记录",
            "expected_sql": "SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'"
        },
        {
            "id": 3,
            "name": "聚合查询",
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
            "expected_sql": "SELECT xueyuanName, SUM(money_1) as total_money FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName"
        }
    ]

def get_models():
    """获取可用模型"""
    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10)
        if response.status_code == 200:
            data = response.json()
            models = [model["name"] for model in data.get("models", [])]
            return models
    except:
        pass

    # 默认模型列表
    return ["qwen3:32b", "qwen3:8b", "qwen3:30b"]

# ==================== 实用优化提示词 ====================

def create_practical_prompt(schema, query):
    """实用提示词 - 接受推理但强调输出SQL"""
    return f"""你是一个SQL生成专家。请为以下查询生成SQL语句。

重要：请直接输出SQL语句。如果你需要推理，请在心中完成，只输出最终的SQL。

数据库结构：
{schema}

查询：{query}

SQL语句："""

# ==================== 高级SQL提取和修复 ====================

def extract_and_repair_sql(response, query):
    """提取并修复SQL"""
    if not response:
        return ""

    response = response.strip()

    # 1. 尝试直接提取完整SQL
    sql_patterns = [
        # 完整SELECT语句
        r'(SELECT\s+.+?\s+FROM\s+\S+(?:\s+WHERE\s+.+?)?(?:\s+GROUP\s+BY\s+.+?)?(?:\s+ORDER\s+BY\s+.+?)?)',
        # 简化的SELECT
        r'(SELECT\s+.+?\s+FROM\s+\S+)',
        # 只有SELECT开头
        r'(SELECT\s+.+)',
    ]

    for pattern in sql_patterns:
        matches = re.findall(pattern, response, re.IGNORECASE | re.DOTALL)
        if matches:
            # 选择最长的匹配
            sql = max(matches, key=len).strip()
            return repair_sql(sql, query)

    # 2. 如果找不到完整SQL，尝试从推理文本中提取
    lines = response.split('\n')
    sql_fragments = []

    for line in lines:
        line = line.strip()
        # 检查是否包含SQL片段
        if re.search(r'\b(SELECT|FROM|WHERE|GROUP BY|SUM|COUNT)\b', line, re.IGNORECASE):
            # 尝试提取SQL部分
            sql_match = re.search(r'(SELECT\b.+)', line, re.IGNORECASE)
            if sql_match:
                fragment = sql_match.group(1).strip()
                # 清理片段
                fragment = re.sub(r'[。，、；`]', '', fragment)
                sql_fragments.append(fragment)

    if sql_fragments:
        # 合并片段
        combined = " ".join(sql_fragments)
        return repair_sql(combined, query)

    # 3. 最后的手段：基于查询生成SQL
    return generate_sql_from_query(query)

def repair_sql(sql, query):
    """修复不完整的SQL"""
    if not sql:
        return sql

    sql_upper = sql.upper()

    # 修复1：确保有FROM子句
    if "SELECT" in sql_upper and "FROM" not in sql_upper:
        # 根据查询内容添加FROM
        if "大学" in query or "AUTO_BASE_DAXUESHEZHI" in sql_upper:
            sql = sql.rstrip() + " FROM auto_base_daxueshezhi"
        elif "创新团队" in query or "AUTO_CAIJI_CHUANGXIN_TEAM" in sql_upper:
            sql = sql.rstrip() + " FROM auto_caiji_chuangxin_team"
        elif "科研项目" in query or "AUTO_CAIJI_FUWU_SUMMARYKYXMDZJF" in sql_upper:
            sql = sql.rstrip() + " FROM auto_caiji_fuwu_summarykyxmdzjf"

    # 修复2：确保WHERE条件完整
    if "WHERE" in sql_upper:
        where_pos = sql_upper.find("WHERE")
        after_where = sql[where_pos + 5:].strip()

        # 如果WHERE后内容太短或不包含条件
        if len(after_where) < 3 or "=" not in after_where:
            # 根据查询添加条件
            if "2023" in query:
                sql = sql[:where_pos].strip() + " WHERE year = '2023'"

    # 修复3：确保GROUP BY完整
    if "GROUP BY" in sql_upper and "SUM" in sql_upper:
        # 检查是否有分组字段
        if not re.search(r'GROUP\s+BY\s+\S+', sql_upper):
            # 添加分组字段
            if "XUEYUANNAME" in sql_upper:
                sql = sql.rstrip() + " GROUP BY xueyuanName"
            elif "YEAR" in sql_upper:
                sql = sql.rstrip() + " GROUP BY year"

    # 修复4：添加AS别名
    if "SUM" in sql_upper and "AS" not in sql_upper:
        # 在SUM后添加AS别名
        sum_match = re.search(r'(SUM\([^)]+\))', sql, re.IGNORECASE)
        if sum_match:
            sum_expr = sum_match.group(1)
            if "AS" not in sum_expr:
                sql = sql.replace(sum_expr, f"{sum_expr} AS total_money")

    return sql.strip()

def generate_sql_from_query(query):
    """基于查询生成基本SQL"""
    if "大学" in query or "设置" in query:
        return "SELECT * FROM auto_base_daxueshezhi"
    elif "创新团队" in query:
        if "2023" in query:
            return "SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'"
        else:
            return "SELECT * FROM auto_caiji_chuangxin_team"
    elif "科研项目" in query or "经费" in query:
        return "SELECT xueyuanName, SUM(money_1) AS total_money FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName"
    else:
        return ""

# ==================== 智能评估 ====================

def evaluate_sql_intelligent(generated, expected):
    """智能SQL评估"""
    if not generated:
        return "ERROR", "无生成内容"

    # 检查是否包含SQL关键字
    if not re.search(r'\bSELECT\b', generated, re.IGNORECASE):
        return "FAIL", "不是有效的SQL（缺少SELECT）"

    # 检查是否包含正确的表名
    expected_tables = re.findall(r'FROM\s+(\S+)', expected.upper())
    generated_upper = generated.upper()

    table_found = False
    for table in expected_tables:
        if table in generated_upper:
            table_found = True
            break

    if not table_found:
        return "FAIL", "缺少正确的表名"

    # 精确匹配
    if generated.upper() == expected.upper():
        return "PASS", "精确匹配"

    # 标准化比较
    gen_norm = normalize_sql(generated)
    exp_norm = normalize_sql(expected)

    if gen_norm == exp_norm:
        return "PASS", "标准化后匹配"

    # 语义相似度评估
    similarity = calculate_sql_similarity(generated, expected)

    if similarity > 0.9:
        return "PASS", f"高度相似 ({similarity:.1%})"
    elif similarity > 0.7:
        return "PARTIAL", f"部分匹配 ({similarity:.1%})"
    elif similarity > 0.5:
        return "PARTIAL", f"中等相似度 ({similarity:.1%})"
    else:
        return "FAIL", f"低相似度 ({similarity:.1%})"

def normalize_sql(sql):
    """标准化SQL"""
    if not sql:
        return ""

    # 转换为大写
    normalized = sql.upper()

    # 移除多余空白
    normalized = re.sub(r'\s+', ' ', normalized)

    # 标准化AS别名
    normalized = re.sub(r'AS\s+\w+', 'AS ALIAS', normalized)

    # 移除单引号差异
    normalized = re.sub(r"'([^']*)'", "'VALUE'", normalized)

    # 移除数字差异
    normalized = re.sub(r'\b\d+\b', 'NUMBER', normalized)

    return normalized.strip()

def calculate_sql_similarity(sql1, sql2):
    """计算SQL相似度"""
    # 提取关键词
    keywords1 = set(re.findall(r'\b\w+\b', sql1.upper()))
    keywords2 = set(re.findall(r'\b\w+\b', sql2.upper()))

    # 移除常见SQL关键词
    common_sql_keywords = {'SELECT', 'FROM', 'WHERE', 'GROUP', 'BY', 'ORDER', 'AS', 'AND', 'OR', 'SUM', 'COUNT', 'AVG', 'MIN', 'MAX'}
    keywords1 = keywords1 - common_sql_keywords
    keywords2 = keywords2 - common_sql_keywords

    # 计算Jaccard相似度
    intersection = keywords1.intersection(keywords2)
    union = keywords1.union(keywords2)

    if not union:
        return 0.0

    return len(intersection) / len(union)

# ==================== 模型调用 ====================

def call_model_with_retry(model_name, prompt, max_retries=2):
    """带重试的模型调用"""
    url = f"{OLLAMA_URL}/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    data = {
        "model": model_name,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.0,
        "max_tokens": 300,  # 增加token限制
        "stream": False
    }

    for attempt in range(max_retries + 1):
        try:
            start_time = time.time()
            response = requests.post(url, headers=headers, json=data, timeout=180)
            response_time = time.time() - start_time

            if response.status_code == 200:
                result = response.json()
                choices = result.get("choices", [])
                if choices:
                    message = choices[0].get("message", {})
                    content = message.get("content", "")
                    reasoning = message.get("reasoning", "")

                    # 优先使用content，如果为空则使用reasoning
                    raw_response = content if content.strip() else reasoning
                    return raw_response, response_time, None
                else:
                    error_msg = "响应中没有choices字段"
            else:
                error_msg = f"API错误: {response.status_code} - {response.text[:100]}"

        except Exception as e:
            error_msg = f"请求异常: {str(e)}"
            response_time = 0

        # 如果不是最后一次尝试，等待后重试
        if attempt < max_retries:
            time.sleep(2)

    return "", response_time, error_msg

# ==================== 主测试函数 ====================

def run_final_optimized_test():
    """运行最终优化测试"""
    print("=" * 80)
    print("最终优化版SQL生成测试")
    print("=" * 80)
    print("优化策略:")
    print("1. 实用提示词 - 接受模型推理，专注于SQL提取")
    print("2. 高级SQL提取和修复")
    print("3. 智能语义评估")
    print("4. 带重试的模型调用")
    print("=" * 80)

    schema = load_simplified_schema()
    test_cases = create_test_cases()
    models = get_models()

    print(f"数据库schema: 简化版（{schema.count('表')}个表）")
    print(f"测试用例: {len(test_cases)}个")
    print(f"测试模型: {', '.join(models)}")
    print()

    results = []
    total_tests = len(models) * len(test_cases)
    completed = 0

    start_total_time = time.time()

    for model in models:
        print(f"\n测试模型: {model}")

        for test_case in test_cases:
            print(f"  用例{test_case['id']}: {test_case['name']}...", end="", flush=True)

            # 创建提示词
            prompt = create_practical_prompt(schema, test_case["query"])

            # 调用模型（带重试）
            raw_sql, response_time, error = call_model_with_retry(model, prompt)

            if error:
                print(f" [ERROR] ({response_time:.1f}s)")
                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": "ERROR",
                    "response_time": response_time,
                    "error": error
                })
            else:
                # 提取和修复SQL
                final_sql = extract_and_repair_sql(raw_sql, test_case["query"])

                # 评估
                result, match_type = evaluate_sql_intelligent(final_sql, test_case["expected_sql"])

                print(f" [{result}] ({response_time:.1f}s) - {match_type}")

                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": result,
                    "response_time": response_time,
                    "match_type": match_type,
                    "raw_response": raw_sql[:150] + ("..." if len(raw_sql) > 150 else ""),
                    "final_sql": final_sql[:100] + ("..." if len(final_sql) > 100 else ""),
                    "expected_sql": test_case["expected_sql"]
                })

            completed += 1

    total_test_time = time.time() - start_total_time

    # 计算得分
    print("\n" + "=" * 80)
    print("测试结果统计")
    print("=" * 80)

    scores = {}
    for model in models:
        model_results = [r for r in results if r["model"] == model]
        total = len(model_results)
        passed = len([r for r in model_results if r["result"] == "PASS"])
        partial = len([r for r in model_results if r["result"] == "PARTIAL"])
        errors = len([r for r in model_results if r["result"] == "ERROR"])
        total_time = sum(r["response_time"] for r in model_results if "response_time" in r)

        scores[model] = {
            "total": total,
            "passed": passed,
            "partial": partial,
            "errors": errors,
            "total_time": total_time,
            "avg_time": total_time / total if total > 0 else 0,
            "pass_rate": passed / total if total > 0 else 0,
            "effective_rate": (passed + partial * 0.5) / total if total > 0 else 0
        }

    # 显示排行榜
    print("\n模型排名（按有效得分排序）:")
    print("-" * 80)

    sorted_scores = sorted(scores.items(), key=lambda x: x[1]["effective_rate"], reverse=True)

    for i, (model, data) in enumerate(sorted_scores, 1):
        print(f"{i}. {model}")
        print(f"   通过率: {data['pass_rate']:.2%} ({data['passed']}/{data['total']})")
        print(f"   部分通过: {data['partial']}")
        print(f"   错误: {data['errors']}")
        print(f"   平均响应时间: {data['avg_time']:.2f}秒")
        print(f"   有效得分: {data['effective_rate']:.2%}")
        print()

    # 与原始测试结果对比
    try:
        with open("direct_test_results_20260326_113828.json", 'r', encoding='utf-8') as f:
            original_data = json.load(f)
            original_scores = original_data["scores"]

        print("\n" + "=" * 80)
        print("与原始测试结果对比")
        print("-" * 80)

        for model in models:
            if model in original_scores:
                orig_effective = original_scores[model]["effective_rate"]
                opt_effective = scores[model]["effective_rate"]
                improvement = opt_effective - orig_effective

                print(f"{model}:")
                print(f"  原始有效得分: {orig_effective:.2%}")
                print(f"  优化有效得分: {opt_effective:.2%}")
                print(f"  变化: {improvement:+.2%}")
    except:
        print("\n注: 无法与原始测试结果对比")

    # 保存结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"final_optimized_results_{timestamp}.json"

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            "timestamp": timestamp,
            "test_type": "final_optimized",
            "optimization_strategy": [
                "实用提示词 - 接受模型推理，专注于SQL提取",
                "高级SQL提取和修复",
                "智能语义评估",
                "带重试的模型调用"
            ],
            "models": models,
            "test_cases": test_cases,
            "results": results,
            "scores": scores,
            "total_test_time": total_test_time
        }, f, ensure_ascii=False, indent=2)

    print(f"\n总测试时间: {total_test_time:.2f}秒")
    print(f"结果已保存到: {output_file}")
    print("\n" + "=" * 80)
    print("最终优化测试完成")
    print("=" * 80)

    return scores

if __name__ == "__main__":
    run_final_optimized_test()