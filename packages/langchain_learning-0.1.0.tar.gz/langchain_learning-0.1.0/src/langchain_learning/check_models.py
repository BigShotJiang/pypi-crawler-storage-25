#!/usr/bin/env python3
"""检查服务器上的模型"""

import requests
import json

SERVER_URL = "http://10.254.2.127:8001"

try:
    print(f"正在从服务器 {SERVER_URL} 获取模型列表...")
    response = requests.get(f"{SERVER_URL}/api/tags", timeout=10)
    response.raise_for_status()
    data = response.json()

    models = []
    if "models" in data:
        for model_data in data["models"]:
            model_name = model_data.get("name", "")
            if model_name:
                # 检查是否为嵌入模型
                is_embedding = any(keyword in model_name.lower() for keyword in ['embed', 'bge', 'nomic-embed'])
                models.append((model_name, is_embedding))

    print(f"找到 {len(models)} 个模型:")
    for model_name, is_embedding in models:
        embedding_flag = " [嵌入模型]" if is_embedding else ""
        print(f"  - {model_name}{embedding_flag}")

    # 过滤掉嵌入模型
    non_embedding = [name for name, is_embedding in models if not is_embedding]
    print(f"\n非嵌入模型: {len(non_embedding)} 个")
    for model in non_embedding:
        print(f"  - {model}")

except Exception as e:
    print(f"获取模型失败: {e}")