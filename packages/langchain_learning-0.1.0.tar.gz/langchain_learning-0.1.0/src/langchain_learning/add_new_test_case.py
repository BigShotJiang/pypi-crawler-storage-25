#!/usr/bin/env python3
import json

# 加载现有测试用例
with open('test_cases_merged.json', 'r', encoding='utf-8') as f:
    test_cases = json.load(f)

# 新测试用例
new_test_case = {
    "id": len(test_cases) + 1,
    "name": "聚合查询 - 留学湖北",
    "natural_language_query": "统计留学湖北表中每个年度的在籍外国留学生总人数",
    "expected_sql": "SELECT year, SUM(number_1) as total_students FROM auto_caiji_guoji_summarylxhb GROUP BY year",
    "difficulty": "intermediate",
    "description": "GROUP BY和SUM聚合查询，按年度统计留学生总数"
}

# 添加新测试用例
test_cases.append(new_test_case)

# 保存更新后的文件
output_file = 'test_cases_merged_v2.json'
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(test_cases, f, ensure_ascii=False, indent=2)

print(f"添加新测试用例成功: {output_file}")
print(f"现在共有 {len(test_cases)} 个测试用例:")
for case in test_cases:
    print(f"  - ID {case['id']}: {case['name']}")