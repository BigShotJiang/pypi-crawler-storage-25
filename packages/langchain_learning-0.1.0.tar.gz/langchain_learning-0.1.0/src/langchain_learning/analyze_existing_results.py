#!/usr/bin/env python3
"""分析现有SQL生成测试结果，计算模型通过率，分析通过率低的原因"""

import json
import os
import sys
from collections import defaultdict
from typing import Dict, List, Tuple

def load_results(file_path: str) -> List[Dict]:
    """加载测试结果文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def analyze_model_performance(results: List[Dict]) -> Dict[str, Dict]:
    """分析每个模型的性能"""
    model_stats = defaultdict(lambda: {
        'total': 0,
        'pass': 0,
        'partial': 0,
        'fail': 0,
        'error': 0,
        'response_times': [],
        'error_types': defaultdict(int),
        'match_types': defaultdict(int),
        'test_cases': defaultdict(lambda: {'total': 0, 'pass': 0, 'partial': 0, 'fail': 0, 'error': 0})
    })

    for result in results:
        model = result['model_name']
        test_id = result['test_case_id']
        result_type = result['result']
        match_type = result.get('match_type', 'unknown')
        error_msg = result.get('error_message')

        stats = model_stats[model]
        stats['total'] += 1
        stats['test_cases'][test_id]['total'] += 1

        if result_type == 'PASS':
            stats['pass'] += 1
            stats['test_cases'][test_id]['pass'] += 1
        elif result_type == 'PARTIAL':
            stats['partial'] += 1
            stats['test_cases'][test_id]['partial'] += 1
        elif result_type == 'FAIL':
            stats['fail'] += 1
            stats['test_cases'][test_id]['fail'] += 1
        elif result_type == 'ERROR':
            stats['error'] += 1
            stats['test_cases'][test_id]['error'] += 1

            # 分析错误类型
            if error_msg:
                if 'timeout' in error_msg.lower():
                    stats['error_types']['timeout'] += 1
                elif 'connection' in error_msg.lower():
                    stats['error_types']['connection'] += 1
                elif '拒绝' in error_msg:
                    stats['error_types']['connection_refused'] += 1
                else:
                    stats['error_types']['other'] += 1

        # 记录匹配类型
        stats['match_types'][match_type] += 1

        # 记录响应时间（如果不是错误）
        if result_type != 'ERROR' and 'response_time' in result:
            stats['response_times'].append(result['response_time'])

    return model_stats

def calculate_pass_rates(model_stats: Dict[str, Dict]) -> List[Tuple[str, float, float, Dict]]:
    """计算通过率（包括部分通过）"""
    model_rates = []

    for model, stats in model_stats.items():
        total = stats['total']
        if total == 0:
            continue

        pass_rate = stats['pass'] / total
        partial_rate = stats['partial'] / total
        fail_rate = stats['fail'] / total
        error_rate = stats['error'] / total

        # 综合得分：通过率 + 部分通过率 * 0.5
        composite_score = pass_rate + partial_rate * 0.5

        model_rates.append((
            model,
            composite_score,
            pass_rate,
            partial_rate,
            fail_rate,
            error_rate,
            stats
        ))

    # 按综合得分降序排序
    model_rates.sort(key=lambda x: x[1], reverse=True)
    return model_rates

def analyze_low_performance_models(model_rates: List[Tuple], threshold: float = 0.5):
    """分析通过率低的模型（低于阈值）"""
    low_performers = []

    for model_info in model_rates:
        model, composite_score, pass_rate, partial_rate, fail_rate, error_rate, stats = model_info
        if composite_score < threshold:
            low_performers.append(model_info)

    return low_performers

def generate_report(model_rates: List[Tuple], low_performers: List[Tuple], output_file: str = None):
    """生成分析报告"""
    report_lines = []

    report_lines.append("=" * 80)
    report_lines.append("SQL生成能力测试结果分析报告")
    report_lines.append("=" * 80)
    report_lines.append(f"分析时间: 2026-04-01")
    report_lines.append(f"测试结果文件: {sys.argv[1] if len(sys.argv) > 1 else '未指定'}")
    report_lines.append(f"模型总数: {len(model_rates)}")
    report_lines.append(f"通过率阈值 (低于50%认为通过率差): 0.5")
    report_lines.append("")

    # 模型排行榜
    report_lines.append("模型排行榜 (按综合得分排序):")
    report_lines.append("-" * 80)
    report_lines.append(f"{'排名':<4} {'模型名称':<30} {'综合得分':<10} {'通过率':<10} {'部分通过率':<12} {'失败率':<10} {'错误率':<10}")
    report_lines.append("-" * 80)

    for i, (model, composite_score, pass_rate, partial_rate, fail_rate, error_rate, stats) in enumerate(model_rates, 1):
        report_lines.append(
            f"{i:<4} {model:<30} {composite_score:.2%} {'':<2} {pass_rate:.2%} {'':<2} {partial_rate:.2%} {'':<2} {fail_rate:.2%} {'':<2} {error_rate:.2%}"
        )

    report_lines.append("")

    # 低性能模型分析
    if low_performers:
        report_lines.append("通过率低的模型分析 (综合得分 < 50%):")
        report_lines.append("-" * 80)

        for model_info in low_performers:
            model, composite_score, pass_rate, partial_rate, fail_rate, error_rate, stats = model_info

            report_lines.append(f"\n模型: {model}")
            report_lines.append(f"  综合得分: {composite_score:.2%} (通过率: {pass_rate:.2%}, 部分通过率: {partial_rate:.2%})")
            report_lines.append(f"  总测试数: {stats['total']}")
            report_lines.append(f"  通过: {stats['pass']}, 部分通过: {stats['partial']}, 失败: {stats['fail']}, 错误: {stats['error']}")

            # 分析主要原因
            if stats['error'] > 0:
                report_lines.append(f"  主要问题: 连接/超时错误 ({stats['error']} 个错误)")
                if stats['error_types']:
                    report_lines.append(f"  错误类型分布:")
                    for err_type, count in stats['error_types'].items():
                        report_lines.append(f"    - {err_type}: {count} 次")

            elif stats['fail'] > 0:
                report_lines.append(f"  主要问题: SQL生成错误 ({stats['fail']} 个失败)")
                # 分析匹配类型
                if stats['match_types']:
                    report_lines.append(f"  失败类型分布:")
                    for match_type, count in stats['match_types'].items():
                        if match_type not in ['exact', 'cleaned_exact', 'normalized', 'field_normalized', 'semantic']:
                            report_lines.append(f"    - {match_type}: {count} 次")

            # 分析测试用例表现
            report_lines.append(f"  各测试用例表现:")
            for test_id, test_stats in stats['test_cases'].items():
                if test_stats['total'] > 0:
                    test_pass_rate = (test_stats['pass'] + test_stats['partial'] * 0.5) / test_stats['total']
                    if test_pass_rate < 0.5:
                        report_lines.append(f"    测试用例 {test_id}: 得分 {test_pass_rate:.2%} (通过 {test_stats['pass']}, 部分 {test_stats['partial']}, 失败 {test_stats['fail']}, 错误 {test_stats['error']})")

    else:
        report_lines.append("没有通过率低于50%的模型。")

    report_lines.append("")
    report_lines.append("=" * 80)

    report_text = "\n".join(report_lines)

    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report_text)
        print(f"报告已保存到: {output_file}")

    print(report_text)

    return report_text

def main():
    if len(sys.argv) < 2:
        print("用法: python analyze_existing_results.py <结果文件路径> [输出报告路径]")
        print("示例: python analyze_existing_results.py examples/full_db_results_all_models/sql_test_results_20260327_151142.json")
        sys.exit(1)

    results_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None

    if not os.path.exists(results_file):
        print(f"错误: 结果文件不存在: {results_file}")
        sys.exit(1)

    print(f"正在分析结果文件: {results_file}")
    results = load_results(results_file)
    print(f"加载了 {len(results)} 条测试记录")

    # 分析模型性能
    model_stats = analyze_model_performance(results)
    print(f"分析了 {len(model_stats)} 个模型的性能")

    # 计算通过率
    model_rates = calculate_pass_rates(model_stats)

    # 分析低性能模型
    low_performers = analyze_low_performance_models(model_rates, threshold=0.5)

    # 生成报告
    if output_file:
        generate_report(model_rates, low_performers, output_file)
    else:
        generate_report(model_rates, low_performers)

if __name__ == "__main__":
    main()