#!/usr/bin/env python3
"""
基于原始成功版本的优化测试
使用原始提示词结构，但添加优化建议中的关键元素
"""

import requests
import json
import time
import re
from datetime import datetime

OLLAMA_URL = "http://10.254.2.99:8001"

def load_simplified_schema():
    """加载简化schema"""
    return """压缩版数据库结构（关键表）：
1. auto_base_daxueshezhi（大学设置表）- 字段: field1, field2, status
2. auto_caiji_chuangxin_team（创新团队表）- 字段: year, team_name, members
3. auto_caiji_fuwu_summarykyxmdzjf（科研项目到账经费表）- 字段: xueyuanName, money_1, year
4. auto_caiji_guoji_projectjscgyx（教师出国研修表）- 字段: projectlevelName, chuguo_time, teacher_name
5. auto_caiji_guoji_projectxscgxx（学生出国学习表）- 字段: year, number_person, destination
6. auto_caiji_guoji_summarylxhb（留学湖北表）- 字段: year, number_1, student_type"""

def create_test_cases():
    """创建测试用例"""
    return [
        {
            "id": 1,
            "name": "简单查询",
            "query": "查询大学设置基本条件表的所有记录",
            "expected_sql": "SELECT * FROM auto_base_daxueshezhi"
        },
        {
            "id": 2,
            "name": "条件查询",
            "query": "查询创新团队表中年度为2023的记录",
            "expected_sql": "SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'"
        },
        {
            "id": 3,
            "name": "聚合查询",
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
            "expected_sql": "SELECT xueyuanName, SUM(money_1) as total_money FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName"
        }
    ]

def get_models():
    """获取可用模型"""
    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10)
        if response.status_code == 200:
            data = response.json()
            models = [model["name"] for model in data.get("models", [])]
            return models
    except:
        pass

    # 默认模型列表
    return ["qwen3:32b", "qwen3:8b", "qwen3:30b"]

# ==================== 基于原始版本的优化提示词 ====================

def create_original_optimized_prompt(schema, query):
    """基于原始成功版本的优化提示词"""
    return f"""# SQL生成专家

## 强制指令（必须严格遵守）
输出格式：仅SQL语句，不要推理过程

## 核心原则
1. 完全基于数据库schema，不添加不存在的表或字段
2. 只输出纯SQL语句，不要解释、注释、推理过程或额外文本
3. 使用标准SQL语法

## 格式要求
- 输出格式：纯SQL语句
- 禁止内容：代码块标记、XML标签、注释、解释文本、推理过程、分号、中文别名
- 字段格式：完全按照schema中的字段名
- 表名格式：完全按照schema中的表名

## 违规示例
错误输出：首先，我需要分析查询...（包含推理）
正确输出：SELECT * FROM auto_base_daxueshezhi

## 数据库schema
{schema}

## 当前查询
{query}

## 请生成SQL语句："""

# ==================== 优化的后处理 ====================

def extract_sql_robust(response):
    """鲁棒的SQL提取函数"""
    if not response:
        return ""

    response = response.strip()

    # 如果已经是纯SQL，直接返回
    if response.upper().startswith("SELECT"):
        return response

    # 尝试多种模式提取SQL
    patterns = [
        # 完整SELECT语句（原始成功版本使用的模式）
        r'(SELECT\s+.+?\s+FROM\s+\S+(?:\s+WHERE\s+.+?)?(?:\s+GROUP\s+BY\s+.+?)?(?:\s+ORDER\s+BY\s+.+?)?)',
        # 包含聚合函数的SELECT
        r'(SELECT\s+.+?\s+,\s*SUM\(.+?\)\s+FROM\s+\S+(?:\s+GROUP\s+BY\s+.+?)?)',
        # 简化的SELECT语句
        r'(SELECT\s+.+?\s+FROM\s+\S+)',
        # 在推理文本中查找SQL
        r'SQL语句[:：]\s*(SELECT.+)',
        r'输出[:：]\s*(SELECT.+)',
        r'答案[:：]\s*(SELECT.+)',
    ]

    for pattern in patterns:
        match = re.search(pattern, response, re.IGNORECASE | re.DOTALL)
        if match:
            sql = match.group(1).strip()
            # 清理可能的尾随标点
            sql = re.sub(r'[。，、；]$', '', sql)
            return sql

    # 如果以上都失败，尝试逐行查找包含SQL关键字的行
    lines = response.split('\n')
    for line in lines:
        line = line.strip()
        # 检查是否看起来像SQL
        if re.search(r'\bSELECT\b.*\bFROM\b', line, re.IGNORECASE):
            # 提取SELECT到行尾
            select_match = re.search(r'(SELECT.+)', line, re.IGNORECASE)
            if select_match:
                return select_match.group(1).strip()

    # 最后的手段：返回以SELECT开头的部分
    select_start = response.upper().find("SELECT")
    if select_start != -1:
        return response[select_start:].strip()

    return response  # 返回原始响应

def clean_sql_original_style(sql_text):
    """原始风格的SQL清洗"""
    if not sql_text:
        return ""

    # 移除代码块标记
    cleaned = re.sub(r'^```sql\s*', '', sql_text, flags=re.IGNORECASE)
    cleaned = re.sub(r'^```\s*', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s*```\s*$', '', cleaned, flags=re.IGNORECASE)

    # 移除XML标签
    cleaned = re.sub(r'<[^>]+>', '', cleaned)

    # 移除分号
    cleaned = cleaned.rstrip(';')

    # 移除常见前缀
    prefixes = [r'^sql\s*', r'^query:\s*', r'^生成的sql:\s*']
    for prefix in prefixes:
        cleaned = re.sub(prefix, '', cleaned, flags=re.IGNORECASE)

    # 提取第一个SELECT语句（原始方法）
    select_match = re.search(r'SELECT\s+.+?\s+FROM\s+\S+', cleaned, re.IGNORECASE | re.DOTALL)
    if select_match:
        cleaned = select_match.group(0)

    # 规范化空白
    cleaned = re.sub(r'\s+', ' ', cleaned)
    cleaned = cleaned.strip()

    return cleaned

# ==================== 评估函数 ====================

def evaluate_sql_original_style(generated, expected):
    """原始风格的SQL评估"""
    if not generated:
        return "ERROR", "无生成内容"

    # 简单检查是否包含SQL关键字（原始方法）
    if not re.search(r'SELECT\s+.+?\s+FROM', generated, re.IGNORECASE):
        return "FAIL", "不是有效的SQL"

    # 精确匹配
    if generated.upper() == expected.upper():
        return "PASS", "精确匹配"

    # 忽略大小写和空白比较
    gen_norm = re.sub(r'\s+', ' ', generated.upper())
    exp_norm = re.sub(r'\s+', ' ', expected.upper())

    if gen_norm == exp_norm:
        return "PASS", "标准化后匹配"

    # 部分匹配检查（原始方法）
    gen_words = set(re.findall(r'\b\w+\b', gen_norm))
    exp_words = set(re.findall(r'\b\w+\b', exp_norm))
    common_words = gen_words.intersection(exp_words)

    if len(exp_words) > 0 and len(common_words) / len(exp_words) > 0.7:
        return "PARTIAL", f"部分匹配 ({len(common_words)}/{len(exp_words)} 关键词)"

    return "FAIL", "不匹配"

# ==================== 模型调用 ====================

def call_model(model_name, prompt):
    """调用模型生成SQL"""
    url = f"{OLLAMA_URL}/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    data = {
        "model": model_name,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.0,
        "max_tokens": 200,
        "stream": False
    }

    try:
        start_time = time.time()
        response = requests.post(url, headers=headers, json=data, timeout=120)
        response_time = time.time() - start_time

        if response.status_code == 200:
            result = response.json()
            choices = result.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                content = message.get("content", "")
                reasoning = message.get("reasoning", "")

                # 优先使用content，如果为空则使用reasoning
                raw_response = content if content.strip() else reasoning
                return raw_response, response_time, None
            else:
                return "", response_time, "响应中没有choices字段"
        else:
            return "", 0, f"API错误: {response.status_code} - {response.text[:100]}"

    except Exception as e:
        return "", 0, f"请求异常: {str(e)}"

# ==================== 主测试函数 ====================

def run_original_optimized_test():
    """运行基于原始版本的优化测试"""
    print("=" * 60)
    print("基于原始成功版本的优化测试")
    print("=" * 60)
    print("优化特性:")
    print("1. 基于原始成功提示词结构")
    print("2. 强化强制指令和违规示例")
    print("3. 鲁棒的SQL提取后处理")
    print("=" * 60)

    schema = load_simplified_schema()
    test_cases = create_test_cases()
    models = get_models()

    print(f"数据库schema: 简化版（{schema.count('表')}个表）")
    print(f"测试用例: {len(test_cases)}个")
    print(f"测试模型: {', '.join(models)}")
    print()

    results = []
    total_tests = len(models) * len(test_cases)
    completed = 0

    for model in models:
        print(f"测试模型: {model}")

        for test_case in test_cases:
            print(f"  用例{test_case['id']}: {test_case['name']}...", end="", flush=True)

            # 创建提示词
            prompt = create_original_optimized_prompt(schema, test_case["query"])

            # 调用模型
            raw_sql, response_time, error = call_model(model, prompt)

            if error:
                print(f" [ERROR] ({response_time:.1f}s)")
                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": "ERROR",
                    "response_time": response_time,
                    "error": error,
                    "generated_sql": "",
                    "expected_sql": test_case["expected_sql"]
                })
            else:
                # 提取SQL
                extracted_sql = extract_sql_robust(raw_sql)

                # 清洗SQL
                cleaned_sql = clean_sql_original_style(extracted_sql)

                # 评估
                result, match_type = evaluate_sql_original_style(cleaned_sql, test_case["expected_sql"])

                print(f" [{result}] ({response_time:.1f}s) - {match_type}")

                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": result,
                    "response_time": response_time,
                    "match_type": match_type,
                    "raw_response": raw_sql[:200] + ("..." if len(raw_sql) > 200 else ""),
                    "extracted_sql": extracted_sql[:100] + ("..." if len(extracted_sql) > 100 else ""),
                    "cleaned_sql": cleaned_sql[:100] + ("..." if len(cleaned_sql) > 100 else ""),
                    "expected_sql": test_case["expected_sql"]
                })

            completed += 1
            print(f"进度: {completed}/{total_tests}")

        print()

    # 计算得分
    print("\n" + "=" * 60)
    print("测试结果统计")
    print("=" * 60)

    scores = {}
    for model in models:
        model_results = [r for r in results if r["model"] == model]
        total = len(model_results)
        passed = len([r for r in model_results if r["result"] == "PASS"])
        partial = len([r for r in model_results if r["result"] == "PARTIAL"])
        errors = len([r for r in model_results if r["result"] == "ERROR"])
        total_time = sum(r["response_time"] for r in model_results)

        scores[model] = {
            "total": total,
            "passed": passed,
            "partial": partial,
            "errors": errors,
            "total_time": total_time,
            "avg_time": total_time / total if total > 0 else 0,
            "pass_rate": passed / total if total > 0 else 0,
            "effective_rate": (passed + partial * 0.5) / total if total > 0 else 0
        }

    # 显示排行榜
    print("\n模型排名（按有效得分排序）:")
    print("-" * 60)

    sorted_scores = sorted(scores.items(), key=lambda x: x[1]["effective_rate"], reverse=True)

    for i, (model, data) in enumerate(sorted_scores, 1):
        print(f"{i}. {model}")
        print(f"   通过率: {data['pass_rate']:.2%} ({data['passed']}/{data['total']})")
        print(f"   部分通过: {data['partial']}")
        print(f"   错误: {data['errors']}")
        print(f"   平均响应时间: {data['avg_time']:.2f}秒")
        print(f"   有效得分: {data['effective_rate']:.2%}")
        print()

    # 保存结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"original_optimized_results_{timestamp}.json"

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            "timestamp": timestamp,
            "test_type": "original_optimized",
            "models": models,
            "test_cases": test_cases,
            "results": results,
            "scores": scores
        }, f, ensure_ascii=False, indent=2)

    print(f"结果已保存到: {output_file}")
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)

    return sorted_scores

# ==================== 对比测试 ====================

def compare_with_original():
    """与原始测试结果对比"""
    print("=" * 80)
    print("优化测试与原始测试对比")
    print("=" * 80)

    # 读取原始测试结果
    try:
        with open("direct_test_results_20260326_113828.json", 'r', encoding='utf-8') as f:
            original_results = json.load(f)
        print("✓ 已加载原始测试结果")
    except:
        print("✗ 无法加载原始测试结果")
        original_results = None

    # 运行优化测试
    print("\n运行基于原始版本的优化测试...")
    optimized_scores = run_original_optimized_test()

    if original_results:
        print("\n" + "=" * 80)
        print("优化效果对比")
        print("=" * 80)

        original_scores = original_results["scores"]

        for model in ["qwen3:32b", "qwen3:8b", "qwen3:30b"]:
            if model in original_scores:
                orig_effective = original_scores[model]["effective_rate"]
                opt_effective = dict(optimized_scores).get(model, {}).get("effective_rate", 0)

                print(f"\n{model}:")
                print(f"  原始测试有效得分: {orig_effective:.2%}")
                print(f"  优化测试有效得分: {opt_effective:.2%}")

                improvement = opt_effective - orig_effective
                if improvement > 0:
                    print(f"  ✓ 优化提升: {improvement:.2%}")
                elif improvement < 0:
                    print(f"  ✗ 优化下降: {improvement:.2%}")
                else:
                    print(f"  ⚠ 无变化")

if __name__ == "__main__":
    # 运行优化测试
    run_original_optimized_test()

    # 可选：与原始测试对比
    # compare_with_original()