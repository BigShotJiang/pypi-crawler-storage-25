#!/usr/bin/env python3
"""测试服务器连接和模型响应"""

import requests
import json
import time

def test_model_generation(model_name="gemma3:27b"):
    """测试模型生成能力"""
    url = "http://10.254.2.99:8001/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    # 简单提示
    prompt = "你好，请回复'Hello World'"

    data = {
        "model": model_name,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.0,
        "max_tokens": 50,
        "stream": False
    }

    print(f"测试模型: {model_name}")
    print(f"发送请求到: {url}")

    try:
        start_time = time.time()
        response = requests.post(url, headers=headers, json=data, timeout=60)
        response_time = time.time() - start_time
        print(f"响应时间: {response_time:.2f}秒")
        response.raise_for_status()

        response_data = response.json()
        print(f"状态码: {response.status_code}")

        # 提取响应内容
        choices = response_data.get("choices", [])
        if choices:
            message = choices[0].get("message", {})
            content = message.get("content", "")
            print(f"模型响应: {content[:100]}...")
        else:
            print(f"响应中没有choices字段: {response_data}")

        return True

    except requests.exceptions.RequestException as e:
        print(f"请求失败: {e}")
        return False
    except Exception as e:
        print(f"其他错误: {e}")
        return False

def test_unload_api(model_name="gemma3:27b"):
    """测试卸载API"""
    url = "http://10.254.2.99:8001/api/unload"
    payload = {"model": model_name}

    print(f"\n测试卸载模型: {model_name}")

    try:
        response = requests.post(url, json=payload, timeout=10)
        print(f"卸载响应状态码: {response.status_code}")
        print(f"卸载响应内容: {response.text[:200]}")
        return True
    except requests.exceptions.RequestException as e:
        print(f"卸载请求失败: {e}")
        return False

def test_multiple_requests(model_name="gemma3:27b"):
    """测试同一个模型的多个请求"""
    url = "http://10.254.2.99:8001/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    print(f"\n测试模型 {model_name} 的多个请求...")

    for i in range(3):
        prompt = f"测试请求 #{i+1}: 请回复数字 {i+1}"

        data = {
            "model": model_name,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.0,
            "max_tokens": 10,
            "stream": False
        }

        print(f"\n请求 #{i+1}: {prompt}")
        try:
            start_time = time.time()
            response = requests.post(url, headers=headers, json=data, timeout=30)
            response_time = time.time() - start_time
            response.raise_for_status()

            response_data = response.json()
            choices = response_data.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                content = message.get("content", "")
                print(f"  响应 #{i+1}: {content[:50]}... (耗时: {response_time:.2f}s)")
            else:
                print(f"  响应 #{i+1}: 无choices字段")

        except requests.exceptions.RequestException as e:
            print(f"  请求 #{i+1} 失败: {e}")
            return False
        except Exception as e:
            print(f"  请求 #{i+1} 错误: {e}")
            return False

    return True

if __name__ == "__main__":
    print("测试服务器连接和模型响应")
    print("=" * 50)

    # 测试第一个模型
    success = test_model_generation("gemma3:27b")

    if success:
        print("\n第一个模型测试成功")

        # 测试同一个模型的多个请求
        print("\n" + "=" * 50)
        print("测试同一个模型的多个请求")
        test_multiple_requests("gemma3:27b")

        # 测试卸载功能
        print("\n" + "=" * 50)
        print("测试卸载功能")
        test_unload_api("gemma3:27b")

        # 测试第二个模型
        print("\n" + "=" * 50)
        print("测试第二个模型")
        success2 = test_model_generation("glm-4.7-flash:q4_K_M")
        if success2:
            print("\n第二个模型测试成功")
        else:
            print("\n第二个模型测试失败")
    else:
        print("\n第一个模型测试失败")