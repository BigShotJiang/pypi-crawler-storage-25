#!/usr/bin/env python3
"""测试表别名修复"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 由于文件名包含连字符，无法直接导入模块
# 改为直接执行文件并提取所需函数
import importlib.util
import importlib.machinery

def import_from_file(file_path, function_names):
    """从文件导入指定函数"""
    module_name = os.path.basename(file_path).replace('.py', '').replace('-', '_')
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    functions = {}
    for name in function_names:
        if hasattr(module, name):
            functions[name] = getattr(module, name)
        else:
            raise ImportError(f"函数 {name} 在 {file_path} 中未找到")

    return functions

# 导入所需函数
file_path = os.path.join(os.path.dirname(__file__), "examples", "model-test-lenient.py")
functions = import_from_file(file_path, ["normalize_sql_semantic_enhanced", "compare_sql_semantic"])
normalize_sql_semantic_enhanced = functions["normalize_sql_semantic_enhanced"]
compare_sql_semantic = functions["compare_sql_semantic"]

def test_alias_star():
    """测试alias.*与*的等价性"""

    # 测试用例7: 子查询
    generated = "SELECT s.* FROM students s WHERE s.score > (SELECT AVG(score) FROM students)"
    expected = "SELECT * FROM students WHERE score > (SELECT AVG(score) FROM students)"

    print("测试用例7: 子查询")
    print(f"生成的SQL: {generated}")
    print(f"预期SQL: {expected}")

    # 测试标准化
    gen_norm = normalize_sql_semantic_enhanced(generated)
    exp_norm = normalize_sql_semantic_enhanced(expected)

    print(f"\n标准化后的生成SQL: {gen_norm}")
    print(f"标准化后的预期SQL: {exp_norm}")

    # 测试比较
    result = compare_sql_semantic(generated, expected)
    print(f"\n比较结果: {'通过' if result else '失败'}")

    return result

def test_other_cases():
    """测试其他相关案例"""

    test_cases = [
        # (生成SQL, 预期SQL, 描述)
        ("SELECT students.* FROM students WHERE score > 80",
         "SELECT * FROM students WHERE score > 80",
         "students.* 与 *"),

        ("SELECT o.*, c.name FROM orders o JOIN customers c ON o.customer_id = c.customer_id",
         "SELECT orders.*, c.name FROM orders JOIN customers c ON orders.customer_id = c.customer_id",
         "JOIN查询中的别名"),

        ("SELECT s.name, s.email FROM students s WHERE s.age > 18",
         "SELECT name, email FROM students WHERE age > 18",
         "表别名在列名中"),
    ]

    all_passed = True
    for gen, exp, desc in test_cases:
        print(f"\n测试: {desc}")
        print(f"生成: {gen}")
        print(f"预期: {exp}")

        gen_norm = normalize_sql_semantic_enhanced(gen)
        exp_norm = normalize_sql_semantic_enhanced(exp)

        print(f"标准化生成: {gen_norm}")
        print(f"标准化预期: {exp_norm}")

        result = compare_sql_semantic(gen, exp)
        print(f"结果: {'通过' if result else '失败'}")

        if not result:
            all_passed = False

    return all_passed

if __name__ == "__main__":
    print("=" * 60)
    print("测试表别名修复")
    print("=" * 60)

    print("\n1. 测试主要用例 (测试用例7)")
    case7_passed = test_alias_star()

    print("\n" + "=" * 60)
    print("\n2. 测试其他相关案例")
    other_passed = test_other_cases()

    print("\n" + "=" * 60)
    print("\n总结:")
    print(f"测试用例7: {'通过' if case7_passed else '失败'}")
    print(f"其他案例: {'全部通过' if other_passed else '有失败'}")

    if case7_passed and other_passed:
        print("\n✅ 所有测试通过!")
        sys.exit(0)
    else:
        print("\n❌ 测试失败!")
        sys.exit(1)