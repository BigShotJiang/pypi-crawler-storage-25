#!/usr/bin/env python3
"""分析所有已有测试结果"""

import json
import os
import glob
from datetime import datetime

def find_result_dirs():
    """查找所有测试结果目录"""
    # 可能的目录模式
    patterns = [
        "full_schema_*",
        "full_db_results_*",
        "phase*_results_*",
        "test_*"
    ]

    result_dirs = []

    for pattern in patterns:
        dirs = glob.glob(pattern)
        for d in dirs:
            if os.path.isdir(d):
                # 检查是否包含结果文件
                result_files = glob.glob(os.path.join(d, "sql_test_results_*.json"))
                score_files = glob.glob(os.path.join(d, "sql_test_scores_*.json"))
                if result_files or score_files:
                    result_dirs.append(d)

    return sorted(result_dirs, key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)

def load_results(dir_path):
    """加载目录中的测试结果"""
    results = {}
    scores = {}

    # 查找最新的结果文件
    result_files = glob.glob(os.path.join(dir_path, "sql_test_results_*.json"))
    score_files = glob.glob(os.path.join(dir_path, "sql_test_scores_*.json"))

    if result_files:
        latest_result = max(result_files, key=os.path.getmtime)
        with open(latest_result, 'r', encoding='utf-8') as f:
            results = json.load(f)

    if score_files:
        latest_score = max(score_files, key=os.path.getmtime)
        with open(latest_score, 'r', encoding='utf-8') as f:
            scores = json.load(f)

    return results, scores, dir_path

def extract_model_info(results):
    """从结果中提取模型信息"""
    models = set()
    test_cases = set()

    for result in results:
        models.add(result.get("model_name"))
        test_cases.add(result.get("test_case_id"))

    return sorted(models), sorted(test_cases)

def calculate_model_stats(results):
    """计算模型统计信息"""
    model_stats = {}

    for result in results:
        model_name = result.get("model_name")
        if model_name not in model_stats:
            model_stats[model_name] = {
                "total": 0,
                "passed": 0,
                "partial": 0,
                "failed": 0,
                "error": 0,
                "total_time": 0.0
            }

        stats = model_stats[model_name]
        stats["total"] += 1
        stats["total_time"] += result.get("response_time", 0)

        result_val = result.get("result")
        if result_val == "PASS":
            stats["passed"] += 1
        elif result_val == "PARTIAL":
            stats["partial"] += 1
        elif result_val == "FAIL":
            stats["failed"] += 1
        elif result_val == "ERROR":
            stats["error"] += 1

    # 计算百分比
    for model_name, stats in model_stats.items():
        if stats["total"] > 0:
            stats["passed_rate"] = stats["passed"] / stats["total"]
            stats["partial_rate"] = stats["partial"] / stats["total"]
            stats["failed_rate"] = stats["failed"] / stats["total"]
            stats["error_rate"] = stats["error"] / stats["total"]
            stats["avg_time"] = stats["total_time"] / stats["total"]
            # 综合得分：通过率 + 部分通过率×0.5
            stats["total_score"] = stats["passed_rate"] + stats["partial_rate"] * 0.5
        else:
            stats["passed_rate"] = 0
            stats["partial_rate"] = 0
            stats["failed_rate"] = 0
            stats["error_rate"] = 0
            stats["avg_time"] = 0
            stats["total_score"] = 0

    return model_stats

def main():
    print("=" * 80)
    print("本地大模型SQL生成能力测试结果综合分析")
    print(f"分析时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    # 查找所有结果目录
    result_dirs = find_result_dirs()
    print(f"找到 {len(result_dirs)} 个结果目录")

    if not result_dirs:
        print("未找到测试结果目录")
        return

    print("\n结果目录:")
    for i, dir_path in enumerate(result_dirs, 1):
        dir_name = os.path.basename(dir_path)
        mtime = datetime.fromtimestamp(os.path.getmtime(dir_path)).strftime('%Y-%m-%d %H:%M')
        print(f"  {i}. {dir_name} (修改时间: {mtime})")

    # 加载所有结果
    all_results = []
    all_model_stats = {}

    print("\n分析各目录结果:")
    for dir_path in result_dirs:
        results, scores, _ = load_results(dir_path)

        if results:
            dir_name = os.path.basename(dir_path)
            models, test_cases = extract_model_info(results)

            print(f"\n目录: {dir_name}")
            print(f"  结果数量: {len(results)}")
            print(f"  模型数量: {len(models)}")
            print(f"  测试用例数量: {len(test_cases)}")

            if models:
                print(f"  模型: {', '.join(models)}")

            # 计算统计
            model_stats = calculate_model_stats(results)

            # 合并到总统计
            for model_name, stats in model_stats.items():
                if model_name not in all_model_stats:
                    all_model_stats[model_name] = stats
                else:
                    # 合并统计（假设不同目录测试相同模型的不同用例）
                    # 这里简单覆盖，因为不同目录可能是同一模型的不同测试
                    all_model_stats[model_name] = stats

            all_results.extend(results)

    if not all_results:
        print("\n未找到有效结果数据")
        return

    # 总体统计
    print("\n" + "=" * 80)
    print("总体统计")
    print("=" * 80)

    total_results = len(all_results)
    unique_models = len(all_model_stats)

    print(f"总结果数量: {total_results}")
    print(f"唯一模型数量: {unique_models}")

    # 显示模型排名
    print("\n模型排名（综合得分 = 通过率 + 部分通过率×0.5）:")
    print("-" * 80)

    # 按综合得分排序
    sorted_models = sorted(all_model_stats.items(),
                          key=lambda x: x[1]["total_score"], reverse=True)

    for rank, (model_name, stats) in enumerate(sorted_models, 1):
        total_score = stats["total_score"]
        passed_rate = stats["passed_rate"]
        partial_rate = stats["partial_rate"]
        avg_time = stats["avg_time"]
        total_tests = stats["total"]

        print(f"{rank}. {model_name}")
        print(f"   综合得分: {total_score:.2%} (通过 {passed_rate:.2%}, 部分 {partial_rate:.2%})")
        print(f"   平均响应时间: {avg_time:.2f}秒")
        print(f"   总测试次数: {total_tests}次")
        print(f"   详细: 通过 {stats['passed']}, 部分 {stats['partial']}, 失败 {stats['failed']}, 错误 {stats['error']}")

    # 检查哪些模型已完成完整测试（8个测试用例）
    print("\n" + "=" * 80)
    print("完整测试检查（8个测试用例）")
    print("=" * 80)

    full_test_models = {}
    for model_name, stats in all_model_stats.items():
        if stats["total"] >= 8:  # 至少有8个测试结果
            full_test_models[model_name] = stats

    if full_test_models:
        print(f"已完成完整测试的模型: {len(full_test_models)}个")
        for model_name in full_test_models:
            stats = all_model_stats[model_name]
            print(f"  - {model_name}: {stats['total']}个测试用例, 综合得分 {stats['total_score']:.2%}")
    else:
        print("没有模型完成完整测试（8个测试用例）")

    # 生成报告文件
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = f"comprehensive_analysis_report_{timestamp}.md"

    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("# 本地大模型SQL生成能力测试综合分析报告\n\n")
        f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"服务器: http://10.254.2.99:8001\n")
        f.write(f"数据库schema: compressed_schema.json (118个表)\n")
        f.write(f"测试用例: test_cases_complex.json (8个复杂查询)\n\n")

        f.write("## 模型性能排行榜\n\n")
        f.write("| 排名 | 模型名称 | 综合得分 | 通过率 | 部分通过率 | 平均响应时间(秒) | 总测试次数 |\n")
        f.write("|------|----------|----------|--------|------------|------------------|------------|\n")

        for rank, (model_name, stats) in enumerate(sorted_models, 1):
            total_score = stats["total_score"]
            passed_rate = stats["passed_rate"]
            partial_rate = stats["partial_rate"]
            avg_time = stats["avg_time"]
            total_tests = stats["total"]

            f.write(f"| {rank} | {model_name} | {total_score:.2%} | {passed_rate:.2%} | {partial_rate:.2%} | {avg_time:.2f} | {total_tests} |\n")

        f.write("\n## 详细统计\n\n")
        for model_name, stats in sorted_models:
            f.write(f"### {model_name}\n\n")
            f.write(f"- **综合得分**: {stats['total_score']:.2%}\n")
            f.write(f"- **通过率**: {stats['passed_rate']:.2%} ({stats['passed']}/{stats['total']})\n")
            f.write(f"- **部分通过率**: {stats['partial_rate']:.2%} ({stats['partial']}/{stats['total']})\n")
            f.write(f"- **失败率**: {stats['failed_rate']:.2%} ({stats['failed']}/{stats['total']})\n")
            f.write(f"- **错误率**: {stats['error_rate']:.2%} ({stats['error']}/{stats['total']})\n")
            f.write(f"- **平均响应时间**: {stats['avg_time']:.2f}秒\n")
            f.write(f"- **总响应时间**: {stats['total_time']:.2f}秒\n\n")

        f.write("## 数据来源\n\n")
        f.write("结果目录:\n")
        for dir_path in result_dirs:
            dir_name = os.path.basename(dir_path)
            mtime = datetime.fromtimestamp(os.path.getmtime(dir_path)).strftime('%Y-%m-%d %H:%M')
            f.write(f"- {dir_name} (修改时间: {mtime})\n")

        f.write(f"\n*报告生成工具: analyze_all_results.py*\n")

    print(f"\n分析报告已生成: {report_file}")

if __name__ == "__main__":
    main()