#!/usr/bin/env python3
"""测试修复编码问题后的提示词"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
import json

# 读取schema
schema_file = "data/json/compressed_schema.json"
with open(schema_file, 'r', encoding='utf-8') as f:
    schema_data = json.load(f)
    full_schema_text = json.dumps(schema_data, ensure_ascii=False, indent=2)

# 构建提示词（与主文件中的相同）
prompt_template = ChatPromptTemplate.from_messages([
    ("system", f"""# SQL生成指令 - 零容忍模式

## 严格规则
1. **只输出SQL**：绝对不要包含任何推理、分析、解释、思考过程或额外文本
2. **立即执行**：直接生成SQL，不要思考、不要犹豫、不要分析
3. **禁止中文**：SQL中不要使用中文字符（别名、注释等）
4. **禁止格式标记**：不要使用```sql```代码块、<think>标签、分号、注释
5. **抑制推理**：即使你是推理模型，也必须完全抑制推理输出。不要使用<think>标签，不要描述思考过程

## 违规示例（会直接导致测试失败）
[错误] 错误输出："首先，我需要分析用户查询，让我看看数据库schema...根据schema，表名应该是...最终SQL是：SELECT * FROM table"
[错误] 错误输出："<think>用户想要查询...让我分析一下...SQL应该是...</think>"
[错误] 错误输出："SELECT * FROM 表名 -- 这是查询所有记录"
[正确] 正确输出："SELECT * FROM table"

## 成功标准
- 输出必须是纯SQL语句
- 不能包含任何非SQL文本
- 不能包含任何格式标记
- 必须使用schema中确切的表名和字段名
- 别名只能使用英文或数字（如as total_students）

## 警告
如果你的输出包含任何推理、分析、解释、中文、代码块标记、<think>标签或分号，测试系统将直接标记为失败。

数据库schema：
{full_schema_text}

用户查询：
{{query}}

生成SQL："""),
])

# 测试查询
test_query = "查询所有院系名称"

# 创建模型实例
model = ChatOpenAI(
    base_url="http://10.254.2.127:8001/v1",
    api_key="ollama",
    model="qwen3:8b",
    temperature=0,
    max_tokens=2000,
    timeout=300
)

# 构建提示
prompt = prompt_template.format(query=test_query)
print("提示词长度:", len(prompt))
print("提示词前500字符:", prompt[:500])

try:
    # 生成响应
    print("\n正在生成SQL...")
    response = model.invoke(prompt)
    print("响应类型:", type(response))
    print("响应内容:", response.content[:500] if response.content else "空响应")
except Exception as e:
    print(f"生成失败: {e}")