#!/usr/bin/env python3
"""宽松匹配版SQL生成测试 - 针对服务器10.254.2.127:8001"""

import time
import json
import re
import requests
from typing import List, Tuple, Dict

def normalize_sql(sql: str) -> str:
    """
    规范化SQL语句，用于宽松匹配

    规则：
    1. 转换为大写（可选，这里保持原样）
    2. 移除分号
    3. 移除SQL代码块标记 (```sql, ```)
    4. 移除推理标记 (</think>, <think>)
    5. 标准化空格（移除多余空格和换行）
    6. 移除常见前缀/后缀
    7. 忽略列别名差异（通过后处理评估）
    """
    if not sql:
        return ""

    # 1. 移除推理标记
    sql = re.sub(r'</?think>', '', sql, flags=re.IGNORECASE)

    # 2. 移除代码块标记
    sql = re.sub(r'```sql|```', '', sql, flags=re.IGNORECASE)

    # 3. 移除分号
    sql = sql.rstrip(';')

    # 4. 移除首尾空格和换行
    sql = sql.strip()

    # 5. 标准化空格：将多个空格/换行/制表符替换为单个空格
    sql = re.sub(r'\s+', ' ', sql)

    # 6. 移除常见的非SQL前缀
    prefixes = [
        "sql",
        "query:",
        "answer:",
        "response:",
        "generated sql:",
        "here is the sql:",
        "the sql query is:",
        "select"
    ]

    for prefix in prefixes:
        if sql.lower().startswith(prefix):
            sql = sql[len(prefix):].strip()

    return sql

def compare_sql_relaxed(generated: str, expected: str) -> Dict[str, any]:
    """
    宽松比较两个SQL语句

    返回比较结果和详细信息
    """
    if not generated or generated.startswith("ERROR:"):
        return {"match": False, "reason": "无输出或错误", "details": generated}

    # 规范化SQL
    gen_norm = normalize_sql(generated)
    exp_norm = normalize_sql(expected)

    # 完全匹配
    if gen_norm == exp_norm:
        return {"match": True, "reason": "完全匹配", "details": ""}

    # 检查是否语义等价
    # 1. 检查SELECT子句
    gen_select = extract_select_clause(gen_norm)
    exp_select = extract_select_clause(exp_norm)

    # 2. 检查FROM子句
    gen_from = extract_from_clause(gen_norm)
    exp_from = extract_from_clause(exp_norm)

    # 3. 检查WHERE条件
    gen_where = extract_where_clause(gen_norm)
    exp_where = extract_where_clause(exp_norm)

    # 4. 检查GROUP BY
    gen_group = extract_group_by_clause(gen_norm)
    exp_group = extract_group_by_clause(exp_norm)

    # 基础检查：表名是否正确
    if gen_from.lower() != exp_from.lower():
        return {
            "match": False,
            "reason": "表名错误",
            "details": f"生成表名: {gen_from}, 预期表名: {exp_from}"
        }

    # SELECT检查：允许别名差异
    if not check_select_equivalent(gen_select, exp_select):
        return {
            "match": False,
            "reason": "SELECT子句不匹配",
            "details": f"生成SELECT: {gen_select}, 预期SELECT: {exp_select}"
        }

    # WHERE检查：允许条件顺序差异
    if gen_where and exp_where:
        if not check_where_equivalent(gen_where, exp_where):
            return {
                "match": False,
                "reason": "WHERE条件不匹配",
                "details": f"生成WHERE: {gen_where}, 预期WHERE: {exp_where}"
            }
    elif gen_where != exp_where:  # 一个有WHERE一个没有
        return {
            "match": False,
            "reason": "WHERE条件缺失或不匹配",
            "details": f"生成WHERE: {gen_where}, 预期WHERE: {exp_where}"
        }

    # GROUP BY检查
    if gen_group.lower() != exp_group.lower():
        return {
            "match": False,
            "reason": "GROUP BY不匹配",
            "details": f"生成GROUP BY: {gen_group}, 预期GROUP BY: {exp_group}"
        }

    # 所有关键元素都匹配，认为是语义等价
    return {"match": True, "reason": "语义匹配（忽略别名差异）", "details": ""}

def extract_select_clause(sql: str) -> str:
    """提取SELECT子句（简化版）"""
    match = re.search(r'SELECT\s+(.*?)(?=\s+FROM|$)', sql, re.IGNORECASE)
    return match.group(1) if match else ""

def extract_from_clause(sql: str) -> str:
    """提取FROM子句（简化版）"""
    match = re.search(r'FROM\s+(\S+)', sql, re.IGNORECASE)
    return match.group(1) if match else ""

def extract_where_clause(sql: str) -> str:
    """提取WHERE子句（简化版）"""
    match = re.search(r'WHERE\s+(.*?)(?=\s+(GROUP BY|ORDER BY|LIMIT|$))', sql, re.IGNORECASE)
    return match.group(1) if match else ""

def extract_group_by_clause(sql: str) -> str:
    """提取GROUP BY子句（简化版）"""
    match = re.search(r'GROUP BY\s+(.*?)(?=\s+(ORDER BY|LIMIT|$))', sql, re.IGNORECASE)
    return match.group(1) if match else ""

def check_select_equivalent(gen_select: str, exp_select: str) -> bool:
    """检查SELECT子句是否等价（允许别名差异）"""
    # 简化检查：移除别名
    gen_clean = re.sub(r'\s+AS\s+\w+|\s+\w+\s*$', '', gen_select, flags=re.IGNORECASE)
    exp_clean = re.sub(r'\s+AS\s+\w+|\s+\w+\s*$', '', exp_select, flags=re.IGNORECASE)

    # 检查聚合函数
    if 'SUM(' in exp_clean or 'COUNT(' in exp_clean or 'AVG(' in exp_clean:
        # 对于聚合查询，需要更严格的检查
        # 但这里简化：只要都有聚合函数就认为匹配
        has_agg_gen = any(func in gen_clean.upper() for func in ['SUM(', 'COUNT(', 'AVG(', 'MAX(', 'MIN('])
        has_agg_exp = any(func in exp_clean.upper() for func in ['SUM(', 'COUNT(', 'AVG(', 'MAX(', 'MIN('])
        return has_agg_gen == has_agg_exp

    return gen_clean == exp_clean

def check_where_equivalent(gen_where: str, exp_where: str) -> bool:
    """检查WHERE条件是否等价（允许顺序差异）"""
    # 简化检查：拆分成单个条件
    gen_conds = [cond.strip() for cond in re.split(r'\s+AND\s+|\s+OR\s+', gen_where, flags=re.IGNORECASE)]
    exp_conds = [cond.strip() for cond in re.split(r'\s+AND\s+|\s+OR\s+', exp_where, flags=re.IGNORECASE)]

    # 排序后比较（简化方法）
    return sorted(gen_conds) == sorted(exp_conds)

def get_ollama_models(base_url: str = "http://10.254.2.127:8001") -> List[str]:
    """获取Ollama服务器上的所有模型"""
    try:
        response = requests.get(f"{base_url}/v1/models", timeout=10)
        if response.status_code == 200:
            models = response.json().get("data", [])
            # 过滤掉明显是嵌入模型的
            filtered_models = []
            for model in models:
                model_id = model.get("id", "")
                if model_id:
                    # 排除嵌入模型
                    if any(embed in model_id.lower() for embed in ['embed', 'bge', 'nomic-embed']):
                        print(f"  跳过嵌入模型: {model_id}")
                    else:
                        filtered_models.append(model_id)
            return filtered_models
        return []
    except Exception as e:
        print(f"获取模型列表失败: {e}")
        return []

def generate_sql_simple(model_name: str, query: str, schema_text: str = None) -> Tuple[str, float]:
    """生成SQL语句（简化版）"""

    # 简化的schema，只包含几个关键表
    if not schema_text:
        schema_text = """数据库表结构：
1. auto_base_daxueshezhi (大学设置基本条件表)
   - zongguimo: INT (总规模)
   - yanjiusheng: INT (研究生)
   - zhishaoyou5jieshuoshiyanjiusheng: NVARCHAR(n) (至少拥有5届硕士研究生)

2. auto_caiji_chuangxin_team (创新团队表)
   - year: NVARCHAR(n) (年度)
   - name: NVARCHAR(n) (团队名称)
   - level: NVARCHAR(n) (级别)

3. auto_caiji_fuwu_summarykyxmdzjf (科研项目到账经费表)
   - xueyuanName: NVARCHAR(n) (所属院系)
   - money_1: DECIMAL (纵向项目到账经费)
   - year: NVARCHAR(n) (年度)
"""

    prompt = f"""根据以下数据库表结构和自然语言查询，生成正确的SQL语句。

只生成纯SQL语句，不要有任何额外的解释、注释或文本。

数据库表结构：
{schema_text}

自然语言查询：
{query}

SQL语句："""

    # 使用OpenAI兼容API
    url = "http://10.254.2.127:8001/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "model": model_name,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.0,
        "max_tokens": 512,
        "stream": False
    }

    start_time = time.time()
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        response_time = time.time() - start_time

        if response.status_code == 200:
            result = response.json()
            content = result.get("choices", [{}])[0].get("message", {}).get("content", "").strip()

            return content, response_time
        else:
            error_msg = f"HTTP {response.status_code}: {response.text}"
            return f"ERROR: {error_msg}", response_time

    except Exception as e:
        response_time = time.time() - start_time
        return f"ERROR: {e}", response_time

def run_test_suite():
    """运行测试套件（宽松匹配版）"""

    print("=" * 80)
    print("宽松匹配版SQL生成能力测试 - 服务器: 10.254.2.127:8001")
    print("=" * 80)

    # 获取模型列表
    models = get_ollama_models()
    if not models:
        print("没有找到可用模型")
        return

    print(f"找到 {len(models)} 个模型:")
    for i, model in enumerate(models, 1):
        print(f"  {i}. {model}")

    # 测试用例
    test_cases = [
        {
            "id": 1,
            "name": "简单SELECT查询",
            "query": "查询大学设置基本条件表的所有记录",
            "expected": "SELECT * FROM auto_base_daxueshezhi"
        },
        {
            "id": 2,
            "name": "带WHERE条件的查询",
            "query": "查询创新团队表中年度为2023的记录",
            "expected": "SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'"
        },
        {
            "id": 3,
            "name": "聚合查询",
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
            "expected": "SELECT xueyuanName, SUM(money_1) as total_money_1 FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName"
        }
    ]

    print(f"\n测试用例 ({len(test_cases)} 个):")
    for case in test_cases:
        print(f"  {case['id']}. {case['name']}: {case['query']}")

    # 运行测试
    results = []

    for model_idx, model_name in enumerate(models, 1):
        print(f"\n[{model_idx}/{len(models)}] 测试模型: {model_name}")

        for case in test_cases:
            print(f"  测试用例 {case['id']}: {case['name']}... ", end="")

            start_time = time.time()
            generated_sql, response_time = generate_sql_simple(model_name, case["query"])
            elapsed = time.time() - start_time

            comparison = compare_sql_relaxed(generated_sql, case["expected"])
            result = "PASS" if comparison["match"] else "FAIL"

            if "ERROR:" in generated_sql:
                result = "ERROR"

            print(f"{result} ({response_time:.2f}s)")

            # 保存结果
            results.append({
                "model": model_name,
                "test_case_id": case["id"],
                "test_case_name": case["name"],
                "query": case["query"],
                "expected_sql": case["expected"],
                "generated_sql": generated_sql,
                "normalized_generated": normalize_sql(generated_sql),
                "normalized_expected": normalize_sql(case["expected"]),
                "result": result,
                "response_time": response_time,
                "comparison_result": comparison
            })

            # 如果是错误，显示详细信息
            if result == "ERROR" and "ERROR:" in generated_sql:
                print(f"     错误信息: {generated_sql[:100]}...")

    # 保存结果
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    result_file = f"sql_test_relaxed_results_server127_{timestamp}.json"
    report_file = f"sql_test_relaxed_report_server127_{timestamp}.txt"

    with open(result_file, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # 生成报告
    with open(report_file, "w", encoding="utf-8") as f:
        f.write(f"宽松匹配版SQL生成能力测试报告\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"测试时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"服务器地址: http://10.254.2.127:8001\n")
        f.write(f"测试模型数: {len(models)}\n")
        f.write(f"测试用例数: {len(test_cases)}\n")
        f.write(f"匹配策略: 宽松语义匹配\n\n")

        # 计算模型统计
        model_stats = {}
        for result in results:
            model = result["model"]
            if model not in model_stats:
                model_stats[model] = {"total": 0, "passed": 0, "response_times": []}

            model_stats[model]["total"] += 1
            if result["result"] == "PASS":
                model_stats[model]["passed"] += 1
            model_stats[model]["response_times"].append(result["response_time"])

        # 排序模型（按通过率）
        sorted_models = sorted(
            model_stats.items(),
            key=lambda x: (x[1]["passed"] / x[1]["total"] if x[1]["total"] > 0 else 0),
            reverse=True
        )

        f.write("模型排名:\n")
        f.write("-" * 80 + "\n")
        rank = 1
        for model, stats in sorted_models:
            total = stats["total"]
            passed = stats["passed"]
            pass_rate = (passed / total * 100) if total > 0 else 0
            avg_time = sum(stats["response_times"]) / len(stats["response_times"]) if stats["response_times"] else 0

            f.write(f"第{rank}名: {model}\n")
            f.write(f"  通过率: {pass_rate:.2f}% ({passed}/{total})\n")
            f.write(f"  平均响应时间: {avg_time:.2f}秒\n\n")
            rank += 1

        # 详细结果
        f.write("\n详细结果:\n")
        f.write("=" * 80 + "\n")
        for model in models:
            f.write(f"\n{model}:\n")
            f.write("-" * 40 + "\n")

            model_results = [r for r in results if r["model"] == model]
            for result in model_results:
                f.write(f"测试用例 {result['test_case_id']}: {result['test_case_name']}\n")
                f.write(f"  查询: {result['query']}\n")
                f.write(f"  预期SQL: {result['expected_sql']}\n")
                f.write(f"  生成SQL: {result['generated_sql'][:200]}\n")
                f.write(f"  结果: {result['result']} (响应时间: {result['response_time']:.2f}秒)\n")
                f.write(f"  匹配详情: {result['comparison_result']['reason']}\n\n")

    print(f"\n测试完成!")
    print(f"结果已保存到: {result_file}")
    print(f"报告已保存到: {report_file}")

    # 打印摘要
    print("\n" + "=" * 80)
    print("测试摘要:")
    print("=" * 80)
    for rank, (model, stats) in enumerate(sorted_models, 1):
        total = stats["total"]
        passed = stats["passed"]
        pass_rate = (passed / total * 100) if total > 0 else 0
        print(f"{rank}. {model}: {pass_rate:.1f}% ({passed}/{total})")

if __name__ == "__main__":
    run_test_suite()