#!/usr/bin/env python3
"""
最终调试测试 - 直接API调用测试
"""

import requests
import json
import time
import sys

def load_compressed_schema():
    """加载压缩schema"""
    try:
        with open("data/json/compressed_schema.json", "r", encoding="utf-8") as f:
            data = json.load(f)

        themes = data.get("themes", [])
        print(f"压缩schema加载成功: {len(themes)}个主题")

        # 简化schema显示
        schema_text = "压缩版数据库结构（按主题分类）\n\n"
        for i, theme in enumerate(themes[:3], 1):  # 只取前3个主题
            theme_name = theme.get("name", "未知")
            tables = theme.get("tables", [])
            schema_text += f"主题{i}: {theme_name} ({len(tables)}个表)\n"

        return schema_text
    except Exception as e:
        print(f"加载schema失败: {e}")
        return "数据库schema加载失败"

def test_simple_query():
    """测试简单查询"""
    url = "http://10.254.2.99:8001/v1/chat/completions"

    # 加载schema
    schema_text = load_compressed_schema()

    # 构建提示词（简化版）
    system_prompt = """你是一个SQL生成专家。根据数据库schema和用户查询生成SQL语句。
只输出SQL语句，不要解释、注释、代码块标记或分号。
禁止使用中文别名。

数据库schema:
{schema}

示例：
查询："查询所有用户信息"
正确输出：SELECT id, name, email FROM users

当前查询：{query}
请生成SQL语句："""

    user_query = "查询大学设置基本条件表的所有记录"
    prompt = system_prompt.format(schema=schema_text[:1000], query=user_query)  # 限制schema长度

    print(f"提示词大小: {len(prompt)} 字符")
    print(f"提示词预览:\n{prompt[:500]}...")

    data = {
        "model": "qwen3:8b",
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.0,
        "max_tokens": 200,
        "stream": False
    }

    try:
        print(f"\n发送请求到 {url}...")
        start_time = time.time()
        response = requests.post(url, json=data, timeout=60)
        response_time = time.time() - start_time

        print(f"响应时间: {response_time:.2f}秒")
        print(f"状态码: {response.status_code}")

        if response.status_code == 200:
            result = response.json()
            print(f"完整响应:\n{json.dumps(result, indent=2, ensure_ascii=False)}")

            # 提取内容
            choices = result.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                content = message.get("content", "")
                reasoning = message.get("reasoning", "")

                print(f"\nContent字段: {content}")
                print(f"\nReasoning字段 (前200字符): {reasoning[:200]}...")

                # 尝试提取SQL
                import re
                sql_pattern = r'SELECT\s+.+?\s+FROM\s+\S+'
                all_text = content + " " + reasoning
                sql_match = re.search(sql_pattern, all_text, re.IGNORECASE)

                if sql_match:
                    print(f"\n提取的SQL: {sql_match.group()}")
                else:
                    print(f"\n未找到SQL语句")
        else:
            print(f"错误响应: {response.text}")

    except Exception as e:
        print(f"请求失败: {e}")
        import traceback
        traceback.print_exc()

def main():
    print("=" * 60)
    print("最终调试测试 - 直接API调用")
    print("=" * 60)

    test_simple_query()

if __name__ == "__main__":
    main()