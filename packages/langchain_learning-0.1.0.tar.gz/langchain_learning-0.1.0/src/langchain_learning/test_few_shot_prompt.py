#!/usr/bin/env python3
"""测试包含few-shot示例的提示词"""

import requests
import json
import time

SERVER_URL = "http://10.254.2.127:8001"

# 测试的模型
MODELS_TO_TEST = ["qwen3:8b", "gemma3:27b"]

# 读取schema
print("读取数据库schema...")
with open("data/json/compressed_schema.json", 'r', encoding='utf-8') as f:
    schema_data = json.load(f)
    schema_text = json.dumps(schema_data, ensure_ascii=False, indent=2)

# 提取一些示例表名用于示例
# 从schema中获取前几个表名
table_names = []
for theme in schema_data.get("themes", []):
    for table in theme.get("tables", []):
        table_names.append(table.get("table_name", ""))
        if len(table_names) >= 5:
            break
    if len(table_names) >= 5:
        break

example_table = table_names[0] if table_names else "auto_base_daxueshezhi"

# 定义few-shot提示词
few_shot_prompt = f"""# SQL生成助手

你是一个SQL专家。根据用户查询和数据库schema生成SQL语句。

## 重要规则
1. **只输出SQL语句**，不要有任何解释、推理、分析或额外文本
2. **不要使用代码块标记**（如```sql```）
3. **不要使用<think>标签**或任何推理标签
4. **不要添加分号或注释**
5. **直接生成SQL**，不要思考过程

## 示例

数据库schema（部分）:
{table_names[:3]}

示例1:
用户查询: 查询{table_names[0]}表的所有记录
SQL: SELECT * FROM {table_names[0]}

示例2:
用户查询: 查询{table_names[1]}表中id为1的记录
SQL: SELECT * FROM {table_names[1]} WHERE id = 1

## 实际任务

完整数据库schema:
{schema_text}

用户查询:
{{query}}

生成SQL（只输出SQL语句）:"""

# 另一个变体：结构化few-shot
structured_prompt = f"""# SQL生成任务

你将被给予一个数据库schema和一个自然语言查询。你的任务是生成相应的SQL语句。

## 输出格式要求
- 只输出SQL语句
- 不要包含任何其他文本
- 不要使用markdown代码块
- 不要使用XML/HTML标签
- 不要添加分号

## 示例

输入:
数据库schema: 包含表{table_names[0]}、{table_names[1]}等
查询: 获取{table_names[0]}表的所有数据

输出:
SELECT * FROM {table_names[0]}

输入:
数据库schema: 包含表{table_names[0]}、{table_names[1]}等
查询: 从{table_names[1]}表中选择id为1的记录

输出:
SELECT * FROM {table_names[1]} WHERE id = 1

## 实际任务

数据库schema:
{schema_text}

查询:
{{query}}

SQL:"""

# 定义提示词变体
PROMPT_VARIANTS = {
    "few_shot": {
        "name": "Few-shot示例提示词",
        "template": few_shot_prompt
    },
    "structured_few_shot": {
        "name": "结构化Few-shot提示词",
        "template": structured_prompt
    },
    "direct_command": {
        "name": "直接命令提示词",
        "template": f"""根据以下数据库schema生成SQL查询。只输出SQL语句，不要有任何其他文本。

数据库schema:
{schema_text}

查询: {{query}}

SQL:"""
    }
}

# 测试查询
test_query = "查询所有院系名称"

print(f"测试查询: {test_query}")
print(f"将测试 {len(MODELS_TO_TEST)} 个模型和 {len(PROMPT_VARIANTS)} 种提示词变体")
print("=" * 80)

all_results = []

for model in MODELS_TO_TEST:
    print(f"\n测试模型: {model}")
    print("=" * 60)

    for variant_key, variant in PROMPT_VARIANTS.items():
        print(f"\n提示词变体: {variant['name']}")
        print("-" * 40)

        # 构建消息
        prompt = variant["template"].format(query=test_query)

        # 准备API请求
        url = f"{SERVER_URL.rstrip('/')}/v1/chat/completions"
        headers = {"Content-Type": "application/json"}

        data = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
            "max_tokens": 512,
            "stream": False
        }

        start_time = time.time()
        try:
            response = requests.post(url, headers=headers, json=data, timeout=300)
            response.raise_for_status()
            response_data = response.json()

            response_time = time.time() - start_time

            # 提取响应
            choices = response_data.get("choices", [])
            if not choices:
                print(f"  [错误] API响应中没有choices字段")
                all_results.append({
                    "model": model,
                    "variant": variant_key,
                    "success": False,
                    "error": "No choices in response",
                    "response_time": response_time
                })
                continue

            message = choices[0].get("message", {})
            raw_response = message.get("content", "")

            print(f"  响应时间: {response_time:.2f}秒")
            print(f"  响应长度: {len(raw_response)} 字符")
            print(f"  响应内容: {repr(raw_response[:150])}")

            # 分析响应
            contains_think = '<think>' in raw_response.lower()
            contains_code_block = '```' in raw_response
            starts_with_select = raw_response.strip().upper().startswith('SELECT')
            contains_chinese = any('\u4e00' <= c <= '\u9fff' for c in raw_response)

            # 判断是否遵循指令
            follows_instructions = (starts_with_select and
                                   not contains_think and
                                   not contains_code_block)

            if follows_instructions:
                print(f"  [成功] 模型遵循指令: 输出纯SQL")
            else:
                issues = []
                if not starts_with_select:
                    issues.append("不以SELECT开头")
                if contains_think:
                    issues.append("包含<think>标签")
                if contains_code_block:
                    issues.append("包含代码块标记")
                if contains_chinese and not starts_with_select:
                    issues.append("包含中文")
                print(f"  [失败] 模型未遵循指令: {', '.join(issues)}")

            all_results.append({
                "model": model,
                "variant": variant_key,
                "variant_name": variant["name"],
                "success": True,
                "follows_instructions": follows_instructions,
                "response_time": response_time,
                "response_length": len(raw_response),
                "contains_chinese": contains_chinese,
                "contains_think": contains_think,
                "contains_explanation": contains_chinese,  # 中文可能表示解释
                "contains_code_block": contains_code_block,
                "starts_with_select": starts_with_select,
                "raw_response_preview": raw_response[:200]
            })

        except Exception as e:
            response_time = time.time() - start_time
            print(f"  [错误] 请求失败: {e}")
            all_results.append({
                "model": model,
                "variant": variant_key,
                "variant_name": variant["name"],
                "success": False,
                "error": str(e),
                "response_time": response_time
            })

        # 在请求之间添加延迟
        time.sleep(5)

    # 在模型之间添加更长延迟
    if model != MODELS_TO_TEST[-1]:
        delay = 15
        print(f"\n等待 {delay} 秒后测试下一个模型...")
        time.sleep(delay)

# 打印汇总结果
print(f"\n{'='*80}")
print("测试完成汇总")
print("=" * 80)

for model in MODELS_TO_TEST:
    print(f"\n模型: {model}")
    model_results = [r for r in all_results if r["model"] == model and r.get("success", False)]

    for result in model_results:
        status = "[遵循]" if result.get("follows_instructions", False) else "[未遵循]"
        issues = []
        if not result.get("starts_with_select", False):
            issues.append("不以SELECT开头")
        if result.get("contains_think", False):
            issues.append("<think>标签")
        if result.get("contains_code_block", False):
            issues.append("代码块标记")
        if result.get("contains_chinese", False) and not result.get("starts_with_select", False):
            issues.append("中文")

        issue_text = f" ({', '.join(issues)})" if issues else ""
        print(f"  {status} {result['variant_name']}: {result['response_time']:.1f}秒{issue_text}")

# 保存结果
timestamp = time.strftime("%Y%m%d_%H%M%S")
output_file = f"few_shot_prompt_test_results_{timestamp}.json"
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump({
        "timestamp": timestamp,
        "server_url": SERVER_URL,
        "test_query": test_query,
        "results": all_results
    }, f, ensure_ascii=False, indent=2)

print(f"\n结果已保存到: {output_file}")