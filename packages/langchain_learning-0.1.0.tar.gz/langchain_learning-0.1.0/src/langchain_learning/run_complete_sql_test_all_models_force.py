#!/usr/bin/env python3
"""完整SQL生成能力测试（所有8个模型，完整8个测试用例）- 强制重新测试版本"""

import os
import sys
import json
import time
import subprocess
import glob
import requests
from datetime import datetime

# 服务器配置
SERVER_URL = "http://10.254.2.127:8001"
SCHEMA_FILE = "data/json/compressed_schema.json"
TEST_CASES_FILE = "test_cases_complex.json"
OUTPUT_BASE_DIR = "full_db_complete_test_all_models_force"

# 模型列表（从服务器获取）
ALL_MODELS = [
    "qwen3.5:27b",
    "gemma3:27b",
    "glm-4.7-flash:q4_K_M",
    "deepseek-r1:14b",
    "qwen3:14b",
    "qwen3:32b",
    "qwen3:8b",
    "qwen3:30b"
]

# 超时配置（秒）
MODEL_TIMEOUTS = {
    "qwen3:8b": 300,      # 5分钟
    "qwen3:14b": 400,     # 6.5分钟
    "deepseek-r1:14b": 400,
    "qwen3.5:27b": 600,   # 10分钟
    "gemma3:27b": 900,    # 15分钟（可能超时）
    "glm-4.7-flash:q4_K_M": 600,
    "qwen3:30b": 600,
    "qwen3:32b": 900,     # 15分钟
    "carstenuhlig/omnicoder-9b:q4_k_m": 600,
    "HridaAI/hrida-t2sql-128k:latest": 600,
    "qwen3:30b-a3b-instruct-2507-q4_K_M": 600,
}

def get_available_models_from_server():
    """从Ollama服务器获取可用模型列表（跳过嵌入模型）"""
    try:
        print(f"正在从服务器 {SERVER_URL} 获取模型列表...")
        # 尝试通过API/tags获取
        response = requests.get(f"{SERVER_URL}/api/tags", timeout=10)
        response.raise_for_status()
        data = response.json()

        models = []
        if "models" in data:
            for model_data in data["models"]:
                model_name = model_data.get("name", "")
                if model_name:
                    # 检查是否为嵌入模型
                    is_embedding = any(keyword in model_name.lower() for keyword in ['embed', 'bge', 'nomic-embed'])
                    if not is_embedding:
                        models.append(model_name)

        if models:
            print(f"从服务器获取到 {len(models)} 个非嵌入模型")
            return models
        else:
            print("未能从服务器获取模型，使用默认列表")
            return ALL_MODELS
    except Exception as e:
        print(f"从服务器获取模型失败: {e}")
        print("使用默认模型列表")
        return ALL_MODELS

def run_single_model_test(model_name, timeout, output_dir):
    """运行单个模型的完整测试"""
    print(f"\n正在测试模型: {model_name}")
    print(f"超时设置: {timeout}秒")

    # 构建命令
    cmd = [
        "python", "examples/model_sql_comprehensive_test_full_db_optimized.py",
        "--ollama-url", SERVER_URL,
        "--schema-file", SCHEMA_FILE,
        "--test-cases", TEST_CASES_FILE,
        "--timeout", str(timeout),
        "--output-dir", output_dir,
        "--skip-model-fetch",
        "--default-models", model_name
    ]

    cmd_str = " ".join(cmd)
    print(f"执行命令: {cmd_str}")

    # 运行命令
    start_time = time.time()
    result = subprocess.run(cmd_str, shell=True, capture_output=True, text=True)
    end_time = time.time()
    elapsed = end_time - start_time

    # 记录结果
    test_result = {
        "model": model_name,
        "timeout": timeout,
        "elapsed_time": elapsed,
        "returncode": result.returncode,
        "success": result.returncode == 0,
        "start_time": start_time,
        "end_time": end_time
    }

    if result.returncode == 0:
        print(f"模型 {model_name} 测试成功，耗时: {elapsed:.1f}秒")
    else:
        print(f"模型 {model_name} 测试失败，退出码: {result.returncode}")
        print(f"标准错误: {result.stderr[:500]}...")

    return test_result

def main():
    print("=" * 80)
    print("本地大模型SQL生成能力完整测试（自动获取模型）- 强制重新测试")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    # 检查文件
    if not os.path.exists(SCHEMA_FILE):
        print(f"错误: schema文件不存在: {SCHEMA_FILE}")
        sys.exit(1)

    if not os.path.exists(TEST_CASES_FILE):
        print(f"错误: 测试用例文件不存在: {TEST_CASES_FILE}")
        sys.exit(1)

    # 创建主输出目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    main_output_dir = f"{OUTPUT_BASE_DIR}_{timestamp}"
    os.makedirs(main_output_dir, exist_ok=True)

    print(f"主输出目录: {main_output_dir}")

    # 获取可用模型并测试所有非嵌入模型
    print("\n获取服务器上的可用模型...")
    models_to_test = get_available_models_from_server()
    # 测试所有非嵌入模型（跳过嵌入模型）
    # 不再限制数量，测试所有模型
    models_skipped = []
    print(f"需要测试的模型: {len(models_to_test)}个")

    print(f"\n需要测试的模型: {len(models_to_test)}个")
    print(f"跳过的模型: {len(models_skipped)}个")

    # 准备测试
    print(f"\n准备测试 {len(models_to_test)} 个模型...")

    # 保存测试计划
    test_plan = {
        "timestamp": timestamp,
        "server_url": SERVER_URL,
        "schema_file": SCHEMA_FILE,
        "test_cases_file": TEST_CASES_FILE,
        "models_to_test": models_to_test,
        "models_skipped": models_skipped,
        "timeout_config": MODEL_TIMEOUTS
    }

    plan_file = os.path.join(main_output_dir, "test_plan.json")
    with open(plan_file, 'w', encoding='utf-8') as f:
        json.dump(test_plan, f, ensure_ascii=False, indent=2)

    print(f"测试计划已保存: {plan_file}")

    # 逐个测试模型
    print(f"\n开始逐个测试模型...")
    all_results = []

    for i, model in enumerate(models_to_test, 1):
        print(f"\n{'='*60}")
        print(f"[{i}/{len(models_to_test)}] 测试模型: {model}")
        print(f"{'='*60}")

        # 为每个模型创建单独的输出目录
        model_safe_name = model.replace(':', '_').replace('.', '_')
        model_output_dir = os.path.join(main_output_dir, f"model_{model_safe_name}")

        # 获取超时设置
        timeout = MODEL_TIMEOUTS.get(model, 600)

        # 运行测试
        model_result = run_single_model_test(model, timeout, model_output_dir)
        all_results.append(model_result)

        # 保存进度
        progress = {
            "completed": i,
            "total": len(models_to_test),
            "current_model": model,
            "results_so_far": all_results
        }

        progress_file = os.path.join(main_output_dir, f"progress_{i}.json")
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress, f, ensure_ascii=False, indent=2)

        # 在模型之间添加延迟（让服务器休息）
        if i < len(models_to_test):
            delay = 30  # 30秒
            print(f"\n等待 {delay} 秒后测试下一个模型...")
            time.sleep(delay)

    # 汇总结果
    print(f"\n{'='*80}")
    print("测试完成汇总")
    print(f"{'='*80}")

    successful = [r for r in all_results if r["success"]]
    failed = [r for r in all_results if not r["success"]]

    print(f"成功测试: {len(successful)}/{len(all_results)} 个模型")
    print(f"失败测试: {len(failed)}/{len(all_results)} 个模型")

    if failed:
        print(f"\n失败的模型:")
        for result in failed:
            print(f"  - {result['model']} (耗时: {result['elapsed_time']:.1f}秒)")

    # 合并所有结果（不包含跳过的模型）
    print(f"\n合并所有测试结果...")
    final_dir = merge_all_results(main_output_dir, models_to_test)

    # 生成最终报告
    print(f"\n生成最终报告...")
    generate_final_report(main_output_dir, final_dir, all_results)

    print(f"\n测试完成!")
    print(f"主目录: {main_output_dir}")
    print(f"最终结果目录: {final_dir}")

def merge_all_results(main_dir, tested_models):
    """合并所有测试结果"""
    final_dir = os.path.join(main_dir, "FINAL_RESULTS")
    os.makedirs(final_dir, exist_ok=True)

    all_results = []
    all_scores = []

    # 合并新测试的结果
    for model in tested_models:
        model_safe_name = model.replace(':', '_').replace('.', '_')
        model_dir = os.path.join(main_dir, f"model_{model_safe_name}")

        if os.path.exists(model_dir):
            # 查找结果文件
            result_files = glob.glob(os.path.join(model_dir, "sql_test_results_*.json"))
            score_files = glob.glob(os.path.join(model_dir, "sql_test_scores_*.json"))

            if result_files:
                latest_result = max(result_files, key=os.path.getmtime)
                with open(latest_result, 'r', encoding='utf-8') as f:
                    results = json.load(f)
                    all_results.extend(results)

            if score_files:
                latest_score = max(score_files, key=os.path.getmtime)
                with open(latest_score, 'r', encoding='utf-8') as f:
                    scores = json.load(f)
                    all_scores.extend(scores)

    # 保存合并结果
    if all_results:
        final_results_file = os.path.join(final_dir, "all_models_results.json")
        with open(final_results_file, 'w', encoding='utf-8') as f:
            json.dump(all_results, f, ensure_ascii=False, indent=2)
        print(f"合并结果保存到: {final_results_file}")

    if all_scores:
        final_scores_file = os.path.join(final_dir, "all_models_scores.json")
        with open(final_scores_file, 'w', encoding='utf-8') as f:
            json.dump(all_scores, f, ensure_ascii=False, indent=2)
        print(f"合并得分保存到: {final_scores_file}")

    return final_dir

def generate_final_report(main_dir, final_dir, test_results):
    """生成最终报告"""
    report_file = os.path.join(final_dir, "FINAL_REPORT.md")

    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("# 本地大模型SQL生成能力完整测试最终报告 - 强制重新测试\n\n")
        f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"服务器: {SERVER_URL}\n")
        f.write(f"数据库schema: {SCHEMA_FILE} (118个表)\n")
        f.write(f"测试用例: {TEST_CASES_FILE} (8个复杂查询)\n")
        f.write(f"显卡: Tesla V100-SXM2-32GB\n\n")

        # 测试概况
        f.write("## 测试概况\n\n")
        f.write(f"- **测试模型总数**: {len(ALL_MODELS)}\n")
        f.write(f"- **重新测试模型**: {len(test_results)}\n")
        f.write(f"- **强制重新测试**: 是（忽略现有结果）\n")

        if test_results:
            successful = sum(1 for r in test_results if r["success"])
            f.write(f"- **测试成功**: {successful}/{len(test_results)}\n")
            f.write(f"- **测试失败**: {len(test_results) - successful}/{len(test_results)}\n\n")

        # 模型列表
        f.write("## 测试模型列表\n\n")
        f.write("| 模型名称 | 大小 | 状态 | 备注 |\n")
        f.write("|----------|------|------|------|\n")

        for model in ALL_MODELS:
            status = "已测试"
            note = ""

            # 检查是否在测试结果中
            test_result = next((r for r in test_results if r["model"] == model), None)
            if test_result:
                status = "重新测试" + (" ✓" if test_result["success"] else " ✗")
                note = f"耗时: {test_result['elapsed_time']:.1f}秒"

            # 估算模型大小
            if "8b" in model.lower():
                size = "8B"
            elif "14b" in model.lower():
                size = "14B"
            elif "27b" in model.lower():
                size = "27B"
            elif "30b" in model.lower():
                size = "30B"
            elif "32b" in model.lower():
                size = "32B"
            else:
                size = "未知"

            f.write(f"| {model} | {size} | {status} | {note} |\n")

        f.write("\n## 后续步骤\n\n")
        f.write("1. 查看详细测试结果: `all_models_results.json`\n")
        f.write("2. 查看模型得分: `all_models_scores.json`\n")
        f.write("3. 分析每个模型的SQL生成能力\n")
        f.write("4. 比较不同模型在复杂查询上的表现\n\n")

        f.write("## 测试配置\n\n")
        f.write("- **测试框架**: `model_sql_comprehensive_test_full_db_optimized.py`\n")
        f.write("- **评估方法**: 精确匹配 + 清洗后匹配 + 标准化匹配 + 语义相似度\n")
        f.write("- **部分匹配阈值**: 70%关键元素匹配\n")
        f.write("- **模型卸载**: 每个模型测试后自动卸载，防止显存OOM\n")
        f.write("- **超时配置**: 根据模型大小动态调整 (300-900秒)\n\n")

        f.write("## 测试用例详情\n\n")
        f.write("8个测试用例涵盖不同难度级别:\n")
        f.write("- **基础查询** (2个): 简单SELECT和WHERE条件\n")
        f.write("- **中级查询** (2个): GROUP BY聚合和HAVING过滤\n")
        f.write("- **高级查询** (3个): JOIN连接、子查询、多表聚合\n")
        f.write("- **专家级查询** (1个): 窗口函数(RANK() OVER)\n\n")

        f.write("*报告生成工具: run_complete_sql_test_all_models_force.py*\n")

    print(f"最终报告已生成: {report_file}")

if __name__ == "__main__":
    main()