#!/usr/bin/env python3
"""
快速SQL生成测试 - 验证优化效果
"""

import os
import sys
import time
import json

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import (
    FullDatabaseSchemaLoader, SQLGenerationTesterFullDBOptimized,
    TestCase, TestResult, SQLEvaluator, SQLResponseCleaner
)

def main():
    print("快速SQL生成测试 - 验证优化效果")
    print("=" * 60)

    # 1. 加载压缩schema
    schema_file = "data/json/compressed_schema.json"
    print(f"加载schema文件: {schema_file}")
    schema_loader = FullDatabaseSchemaLoader(schema_file)
    full_schema_text = schema_loader.load_full_schema()

    # 显示schema信息
    if "压缩版数据库结构" in full_schema_text:
        print("✓ 使用压缩版schema")
    print(f"Schema大小: {len(full_schema_text)} 字符")

    # 2. 初始化测试器
    ollama_url = "http://10.254.2.99:8001"
    print(f"Ollama服务器: {ollama_url}")

    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url=f"{ollama_url}/v1",
        timeout=120,  # 120秒超时
        full_schema_text=full_schema_text
    )

    # 3. 创建测试用例 - 测试中文别名禁止
    test_cases = [
        TestCase(
            id=1,
            name="测试中文别名禁止",
            natural_language_query="统计留学湖北表中每个年度的在籍外国留学生总人数",
            expected_sql="SELECT year, SUM(number_1) as total_students FROM auto_caiji_guoji_summarylxhb GROUP BY year",
            difficulty="intermediate",
            description="测试是否生成中文别名"
        ),
        TestCase(
            id=2,
            name="测试字段名大小写",
            natural_language_query="查询学院名称和经费总和",
            expected_sql="SELECT xueyuanName, SUM(money_1) as total_money FROM research_funding GROUP BY xueyuanName",
            difficulty="intermediate",
            description="测试字段名大小写一致性"
        ),
        TestCase(
            id=3,
            name="简单查询测试",
            natural_language_query="查询大学设置基本条件表的所有记录",
            expected_sql="SELECT * FROM auto_base_daxueshezhi",
            difficulty="basic",
            description="简单SELECT查询"
        ),
    ]

    # 4. 测试每个用例
    model_name = "qwen3:8b"
    print(f"\n测试模型: {model_name}")

    for test_case in test_cases:
        print(f"\n[{test_case.id}] {test_case.name}")
        print(f"  查询: {test_case.natural_language_query}")
        print(f"  预期SQL: {test_case.expected_sql}")
        print("  正在生成SQL...")

        try:
            # 使用测试器的generate_sql方法
            raw_sql, cleaned_sql, response_time = tester.generate_sql(
                model_name, test_case.natural_language_query
            )

            print(f"  响应时间: {response_time:.2f}秒")
            print(f"  原始响应: {raw_sql[:100]}..." if len(raw_sql) > 100 else f"  原始响应: {raw_sql}")
            print(f"  清洗后SQL: {cleaned_sql}")

            # 检查是否包含中文别名
            if " AS " in cleaned_sql.upper():
                # 查找别名部分
                import re
                as_matches = re.findall(r'AS\s+([^\s,]+)', cleaned_sql, re.IGNORECASE)
                for alias in as_matches:
                    # 检查是否包含中文字符
                    if re.search(r'[\u4e00-\u9fff]', alias):
                        print(f"  ⚠️  警告: 检测到中文别名: '{alias}'")
                    else:
                        print(f"  ✓ 别名正常: '{alias}'")

            # 评估SQL
            result, match_type = SQLEvaluator.evaluate_sql(raw_sql, test_case.expected_sql)
            print(f"  评估结果: {result.value} ({match_type})")

            # 检查字段名大小写问题
            cleaner = SQLResponseCleaner()
            if cleaner.is_likely_sql(cleaned_sql):
                # 简单检查字段名
                if "xueyuanname" in cleaned_sql.lower() and "xueyuanName" in test_case.expected_sql:
                    print(f"  ⚠️  注意: 字段名大小写可能不一致")

        except Exception as e:
            print(f"  ❌ 错误: {e}")
            import traceback
            traceback.print_exc()

    print("\n" + "=" * 60)
    print("测试完成")

if __name__ == "__main__":
    main()