#!/usr/bin/env python3
"""测试检测逻辑修复"""

import sys
import os

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from run_complete_sql_test_all_models import check_existing_results

# 测试模型列表
test_models = [
    "qwen3.5:27b",      # 在test_two_models中有完整结果
    "gemma3:27b",       # 在test_two_models中有完整结果
    "qwen3:8b",         # 应有完整结果
    "qwen3:32b",        # 应有完整结果
    "glm-4.7-flash:q4_K_M",  # 应无完整结果
    "deepseek-r1:14b",  # 应无完整结果
    "qwen3:14b",        # 应无完整结果
    "qwen3:30b",        # 应无完整结果
]

print("测试检测逻辑修复")
print("=" * 60)

for model in test_models:
    has_complete, dir_path = check_existing_results(model)
    status = "[YES]" if has_complete else "[NO]"
    print(f"{model:30} {status:10} {dir_path or ''}")