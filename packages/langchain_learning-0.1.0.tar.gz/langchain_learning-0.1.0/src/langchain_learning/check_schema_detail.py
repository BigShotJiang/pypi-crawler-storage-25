#!/usr/bin/env python3
import json
import sys
from examples.model_sql_comprehensive_test_full_db import FullDatabaseSchemaLoader

def main():
    loader = FullDatabaseSchemaLoader("data/json/json.json")
    schema_text = loader.load_full_schema()

    print("Schema text preview (first 1000 chars):")
    print("-" * 80)
    print(schema_text[:1000])
    print("-" * 80)

    print(f"\nSchema length: {len(schema_text)} characters")
    print(f"Number of '表名:' occurrences: {schema_text.count('表名:')}")
    print(f"Number of '表 ' occurrences: {schema_text.count('表 ')}")
    print(f"Number of '字段:' occurrences: {schema_text.count('字段:')}")

    # Check if tables are listed
    lines = schema_text.split('\n')
    table_lines = [line for line in lines if '表名:' in line or '表 ' in line]
    print(f"\nTable-related lines (first 10):")
    for i, line in enumerate(table_lines[:10], 1):
        print(f"  {i}. {line}")

    # Check the actual data file
    print("\n" + "=" * 80)
    print("Checking original JSON file structure:")
    with open("data/json/json.json", 'r', encoding='utf-8') as f:
        data = json.load(f)

    if isinstance(data, dict):
        print(f"Top-level keys: {list(data.keys())}")
        if "data" in data:
            tables = data["data"]
            print(f"Number of tables in 'data' key: {len(tables)}")
            if tables:
                first_table = tables[0]
                print(f"First table keys: {list(first_table.keys())}")
                print(f"First table name: {first_table.get('表名', 'N/A')}")
    elif isinstance(data, list):
        print(f"Data is a list with {len(data)} elements")
        if data:
            first_item = data[0]
            print(f"First item type: {type(first_item)}")
            if isinstance(first_item, dict):
                print(f"First item keys: {list(first_item.keys())}")

if __name__ == "__main__":
    main()