#!/usr/bin/env python3
import json

# 加载两个测试用例文件
with open('test_case_simple.json', 'r', encoding='utf-8') as f:
    simple_cases = json.load(f)

with open('test_case_aggregate.json', 'r', encoding='utf-8') as f:
    aggregate_cases = json.load(f)

# 合并测试用例
merged_cases = simple_cases + aggregate_cases

# 确保ID唯一
for i, case in enumerate(merged_cases):
    case['id'] = i + 1

# 保存合并文件
output_file = 'test_cases_merged.json'
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(merged_cases, f, ensure_ascii=False, indent=2)

print(f"创建合并测试用例文件: {output_file}")
print(f"包含 {len(merged_cases)} 个测试用例:")
for case in merged_cases:
    print(f"  - ID {case['id']}: {case['name']}")