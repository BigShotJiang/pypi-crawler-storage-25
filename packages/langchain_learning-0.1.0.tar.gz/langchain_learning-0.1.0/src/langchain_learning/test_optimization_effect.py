#!/usr/bin/env python3
"""
测试优化效果（对比优化前后的SQL生成质量）
"""
import os
import json
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import (
    SQLGenerationTesterFullDBOptimized
)

def load_schema():
    """加载数据库schema"""
    schema_file = "data/json/compressed_schema.json"
    with open(schema_file, 'r', encoding='utf-8') as f:
        schema_data = json.load(f)

    # 转换为文本格式
    lines = []
    lines.append("# 数据库schema（共118个表）")

    for theme in schema_data.get('themes', []):
        theme_name = theme.get('name', '未知主题')
        theme_desc = theme.get('description', '')
        lines.append(f"\n## 主题: {theme_name}")
        if theme_desc:
            lines.append(f"描述: {theme_desc}")

        for table in theme.get('tables', []):
            table_name = table.get('original_name', '')
            table_label = table.get('label', '')
            table_desc = table.get('description', '')

            lines.append(f"\n### 表: {table_name}")
            lines.append(f"标签: {table_label}")
            if table_desc:
                lines.append(f"描述: {table_desc}")

            key_fields = table.get('key_fields', [])
            if key_fields:
                lines.append("关键字段:")
                for field in key_fields:
                    field_name = field.get('name', '')
                    field_type = field.get('type', '')
                    field_remark = field.get('remark', '')
                    lines.append(f"  - {field_name} ({field_type}): {field_remark}")

    return '\n'.join(lines)

def load_test_cases():
    """加载测试用例"""
    test_cases_file = "test_cases_complex.json"
    with open(test_cases_file, 'r', encoding='utf-8') as f:
        test_cases = json.load(f)
    return test_cases

def test_single_model():
    """测试单个模型的优化效果"""
    print("=" * 80)
    print("测试优化效果 (gemma3:27b)")
    print("=" * 80)

    # 加载schema
    print("加载数据库schema...")
    schema_text = load_schema()
    print(f"Schema大小: {len(schema_text)} 字符")

    # 加载测试用例
    print("加载测试用例...")
    test_cases = load_test_cases()
    print(f"测试用例数量: {len(test_cases)}")

    # 初始化测试器（使用优化后的提示词）
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url="http://10.254.2.127:8001",
        timeout=180,
        full_schema_text=schema_text
    )

    # 测试模型
    test_model = "gemma3:27b"
    print(f"\n测试模型: {test_model}")
    print("-" * 80)

    results = []
    for i, test_case in enumerate(test_cases, 1):
        query = test_case["natural_language_query"]
        expected = test_case["expected_sql"]
        name = test_case.get("name", f"测试用例{i}")

        print(f"\n[{i}/{len(test_cases)}] {name}")
        print(f"查询: {query}")
        print(f"预期SQL: {expected}")

        try:
            # 生成SQL（使用优化后的提示词）
            raw_response, cleaned_sql, response_time = tester.generate_sql(
                model_name=test_model,
                query=query,
                two_stage=False  # 先测试单阶段
            )

            print(f"生成的SQL: {cleaned_sql}")
            print(f"响应时间: {response_time:.2f}秒")

            # 评估结果（修复版本）
            try:
                evaluation_result = tester.evaluator.evaluate_sql(cleaned_sql, expected)
                # evaluate_sql返回的是(TestResult, match_type)元组
                if isinstance(evaluation_result, tuple) and len(evaluation_result) >= 2:
                    result_obj = evaluation_result[0]
                    match_type = evaluation_result[1]
                    result = result_obj.name if hasattr(result_obj, 'name') else str(result_obj)
                else:
                    result = "UNKNOWN"
                    match_type = ""
                    print(f"评估结果解析异常: {type(evaluation_result)}")

                print(f"评估结果: {result} ({match_type})")
            except Exception as e:
                print(f"评估失败: {e}")
                result = "ERROR"
                match_type = "evaluation_error"

            similarity = 0  # 简化，不计算相似度

            results.append({
                "test_id": i,
                "query": query,
                "expected": expected,
                "generated": cleaned_sql,
                "result": result,
                "match_type": match_type,
                "response_time": response_time,
                "similarity": similarity
            })

        except Exception as e:
            print(f"生成SQL时出错: {e}")
            import traceback
            traceback.print_exc()
            results.append({
                "test_id": i,
                "query": query,
                "expected": expected,
                "generated": "",
                "result": "ERROR",
                "match_type": "error",
                "response_time": 0,
                "similarity": 0
            })

    # 统计结果
    print("\n" + "=" * 80)
    print("测试结果统计")
    print("=" * 80)

    total = len(results)
    passed = sum(1 for r in results if r["result"] == "PASS")
    partial = sum(1 for r in results if r["result"] == "PARTIAL")
    failed = sum(1 for r in results if r["result"] == "FAIL")
    error = sum(1 for r in results if r["result"] == "ERROR")
    not_sql = sum(1 for r in results if r.get("match_type") == "not_sql")

    passed_rate = passed / total if total > 0 else 0
    partial_rate = partial / total if total > 0 else 0
    avg_time = sum(r["response_time"] for r in results) / total if total > 0 else 0

    print(f"测试总数: {total}")
    print(f"通过: {passed} ({passed_rate*100:.1f}%)")
    print(f"部分通过: {partial} ({partial_rate*100:.1f}%)")
    print(f"失败: {failed} ({failed/total*100 if total>0 else 0:.1f}%)")
    print(f"错误: {error} ({error/total*100 if total>0 else 0:.1f}%)")
    print(f"非SQL: {not_sql} ({not_sql/total*100 if total>0 else 0:.1f}%)")
    print(f"平均响应时间: {avg_time:.2f}秒")
    print(f"综合得分: {passed_rate + (partial_rate * 0.5):.4f}")

    # 与基准比较
    print("\n" + "=" * 80)
    print("与基准对比 (优化前 vs 优化后)")
    print("=" * 80)
    print("基准测试结果 (full_db_complete_test_all_models_force_20260403_102448):")
    print("  - gemma3:27b: 综合得分 0.1875, 通过率 12.5%, 部分通过率 12.5%")
    print("  - 平均响应时间: 69.39秒")
    print(f"\n优化后测试结果:")
    print(f"  - 综合得分: {passed_rate + (partial_rate * 0.5):.4f}")
    print(f"  - 通过率: {passed_rate:.3f}")
    print(f"  - 部分通过率: {partial_rate:.3f}")
    print(f"  - 平均响应时间: {avg_time:.2f}秒")

    # 计算改进百分比
    baseline_score = 0.1875
    current_score = passed_rate + (partial_rate * 0.5)
    improvement = ((current_score - baseline_score) / baseline_score * 100) if baseline_score > 0 else 100

    print(f"\n性能改进: {improvement:+.1f}%")
    if improvement > 0:
        print("优化效果明显!")
    else:
        print("需要进一步优化")

    # 保存结果
    output_dir = f"optimization_test_{test_model}_{int(time.time())}"
    os.makedirs(output_dir, exist_ok=True)

    results_file = os.path.join(output_dir, "optimization_results.json")
    with open(results_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"\n详细结果已保存到: {results_file}")
    return results

if __name__ == "__main__":
    import time as time_module
    test_single_model()