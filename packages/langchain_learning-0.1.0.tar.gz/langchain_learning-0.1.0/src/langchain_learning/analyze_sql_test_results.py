#!/usr/bin/env python3
"""
SQL测试结果分析脚本
用于分析 full_db_complete_test_all_models_force_* 目录中的测试结果
"""

import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Any
import glob

def find_latest_test_directory() -> str:
    """查找最新的测试结果目录"""
    pattern = "full_db_complete_test_all_models_force_*"
    dirs = glob.glob(pattern)
    if not dirs:
        print("错误: 未找到测试结果目录")
        sys.exit(1)

    # 按修改时间排序，获取最新的目录
    latest_dir = max(dirs, key=os.path.getmtime)
    return latest_dir

def load_test_results(test_dir: str) -> Dict[str, Any]:
    """加载测试结果"""
    results_dir = os.path.join(test_dir, "FINAL_RESULTS")

    # 加载得分数据
    scores_file = os.path.join(results_dir, "all_models_scores.json")
    with open(scores_file, 'r', encoding='utf-8') as f:
        scores = json.load(f)

    # 加载详细结果（可选）
    results_file = os.path.join(results_dir, "all_models_results.json")
    with open(results_file, 'r', encoding='utf-8') as f:
        detailed_results = json.load(f)

    return {
        "scores": scores,
        "detailed_results": detailed_results,
        "test_dir": test_dir,
        "results_dir": results_dir
    }

def calculate_composite_score(score_data: Dict) -> float:
    """计算综合得分: passed_rate + (partial_rate * 0.5)"""
    passed_rate = score_data.get("passed_rate", 0)
    partial_rate = score_data.get("partial_rate", 0)
    return passed_rate + (partial_rate * 0.5)

def generate_leaderboard(scores: List[Dict]) -> List[Dict]:
    """生成排行榜"""
    leaderboard = []
    for score in scores:
        model_data = {
            "model_name": score["model_name"],
            "total_tests": score["total_tests"],
            "passed_tests": score["passed_tests"],
            "partial_tests": score["partial_tests"],
            "passed_rate": score["passed_rate"],
            "partial_rate": score["partial_rate"],
            "composite_score": calculate_composite_score(score),
            "avg_response_time": score.get("avg_response_time", 0),
            "total_response_time": score.get("total_response_time", 0)
        }
        leaderboard.append(model_data)

    # 按综合得分排序
    leaderboard.sort(key=lambda x: x["composite_score"], reverse=True)

    # 添加排名
    for i, model in enumerate(leaderboard):
        model["rank"] = i + 1

    return leaderboard

def analyze_test_cases(detailed_results: List[Dict]) -> Dict:
    """分析测试用例的难度和通过情况"""
    test_case_stats = {}

    for result in detailed_results:
        test_id = result["test_case_id"]
        if test_id not in test_case_stats:
            test_case_stats[test_id] = {
                "total_attempts": 0,
                "passes": 0,
                "partial_passes": 0,
                "fails": 0,
                "not_sql": 0,
                "results": []
            }

        stats = test_case_stats[test_id]
        stats["total_attempts"] += 1
        stats["results"].append({
            "model": result["model_name"],
            "result": result["result"],
            "match_type": result.get("match_type", "")
        })

        if result["result"] == "PASS":
            stats["passes"] += 1
        elif result["result"] == "PARTIAL":
            stats["partial_passes"] += 1
        elif result.get("match_type") == "not_sql":
            stats["not_sql"] += 1
        else:
            stats["fails"] += 1

    return test_case_stats

def print_leaderboard(leaderboard: List[Dict]):
    """打印排行榜"""
    print("=" * 120)
    print("SQL生成能力排行榜")
    print("=" * 120)
    print(f"{'排名':<4} {'模型名称':<50} {'综合得分':<10} {'通过率':<8} {'部分通过率':<10} {'平均响应时间(秒)':<18}")
    print("-" * 120)

    for model in leaderboard:
        rank = model["rank"]
        name = model["model_name"]
        composite = model["composite_score"]
        passed_rate = model["passed_rate"]
        partial_rate = model["partial_rate"]
        avg_time = model["avg_response_time"]

        # 高亮显示前三名（使用文本标记而非特殊字符）
        if rank == 1:
            rank_str = f"1st {rank}"
        elif rank == 2:
            rank_str = f"2nd {rank}"
        elif rank == 3:
            rank_str = f"3rd {rank}"
        else:
            rank_str = f"   {rank}"

        print(f"{rank_str:<6} {name:<50} {composite:<10.4f} {passed_rate:<8.3f} {partial_rate:<10.3f} {avg_time:<18.2f}")

    print("=" * 120)
    print("综合得分公式: passed_rate + (partial_rate × 0.5)")
    print("=" * 120)

def print_test_case_analysis(test_case_stats: Dict):
    """打印测试用例分析"""
    print("\n" + "=" * 80)
    print("测试用例难度分析")
    print("=" * 80)

    # 按测试ID排序
    sorted_test_ids = sorted(test_case_stats.keys())

    # 分类测试用例
    simple_cases = [1, 2]  # 简单查询
    medium_cases = [3, 4]  # 中等查询
    complex_cases = [5, 6, 7]  # 复杂查询
    expert_cases = [8]  # 专家级查询

    categories = {
        "简单查询": simple_cases,
        "中等查询": medium_cases,
        "复杂查询": complex_cases,
        "专家级查询": expert_cases
    }

    for category_name, test_ids in categories.items():
        print(f"\n{category_name} (用例ID: {', '.join(map(str, test_ids))}):")
        print("-" * 40)

        total_attempts = 0
        total_passes = 0
        total_partial = 0

        for test_id in test_ids:
            if test_id in test_case_stats:
                stats = test_case_stats[test_id]
                total_attempts += stats["total_attempts"]
                total_passes += stats["passes"]
                total_partial += stats["partial_passes"]

                pass_rate = (stats["passes"] / stats["total_attempts"]) * 100 if stats["total_attempts"] > 0 else 0
                partial_rate = (stats["partial_passes"] / stats["total_attempts"]) * 100 if stats["total_attempts"] > 0 else 0

                print(f"  用例{test_id}: 通过 {stats['passes']}/{stats['total_attempts']} ({pass_rate:.1f}%), "
                      f"部分通过 {stats['partial_passes']}/{stats['total_attempts']} ({partial_rate:.1f}%)")

        if total_attempts > 0:
            overall_pass_rate = (total_passes / total_attempts) * 100
            overall_partial_rate = (total_partial / total_attempts) * 100
            print(f"  总计: 通过 {total_passes}/{total_attempts} ({overall_pass_rate:.1f}%), "
                  f"部分通过 {total_partial}/{total_attempts} ({overall_partial_rate:.1f}%)")

def print_model_recommendations(leaderboard: List[Dict]):
    """打印模型推荐"""
    print("\n" + "=" * 80)
    print("模型使用推荐")
    print("=" * 80)

    if len(leaderboard) >= 3:
        top3 = leaderboard[:3]

        print("\n推荐使用 (按优先级排序):")
        for i, model in enumerate(top3):
            name = model["model_name"]
            score = model["composite_score"]
            passed = model["passed_tests"]
            total = model["total_tests"]
            avg_time = model["avg_response_time"]

            recommendation = f"{i+1}. {name}"
            if i == 0:
                recommendation += " (综合表现最佳)"
            elif i == 1:
                recommendation += " (表现优秀)"
            elif i == 2:
                recommendation += " (表现良好)"

            print(f"  {recommendation}")
            print(f"     综合得分: {score:.4f}, 通过: {passed}/{total}, 平均响应: {avg_time:.2f}秒")

    # 找出最快的模型
    fast_models = [m for m in leaderboard if m["avg_response_time"] > 0]
    if fast_models:
        fastest = min(fast_models, key=lambda x: x["avg_response_time"])
        print(f"\n最快模型: {fastest['model_name']}")
        print(f"   平均响应时间: {fastest['avg_response_time']:.2f}秒")

    # 找出准确率最高的模型
    accurate_models = [m for m in leaderboard if m["passed_rate"] > 0]
    if accurate_models:
        most_accurate = max(accurate_models, key=lambda x: x["passed_rate"])
        if most_accurate["passed_rate"] > 0:
            print(f"\n最准确模型: {most_accurate['model_name']}")
            print(f"   通过率: {most_accurate['passed_rate']:.3f}")

def main():
    """主函数"""
    print("开始分析SQL测试结果...")

    # 查找最新测试目录
    test_dir = find_latest_test_directory()
    print(f"使用测试目录: {test_dir}")

    # 加载数据
    data = load_test_results(test_dir)
    scores = data["scores"]
    detailed_results = data["detailed_results"]

    # 生成排行榜
    leaderboard = generate_leaderboard(scores)

    # 分析测试用例
    test_case_stats = analyze_test_cases(detailed_results)

    # 打印结果
    print_leaderboard(leaderboard)
    print_test_case_analysis(test_case_stats)
    print_model_recommendations(leaderboard)

    # 保存排行榜到文件
    output_file = os.path.join(data["results_dir"], "LEADERBOARD.json")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(leaderboard, f, ensure_ascii=False, indent=2)

    print(f"\n排行榜已保存到: {output_file}")
    print(f"详细分析报告: {os.path.join(data['results_dir'], 'DETAILED_ANALYSIS.md')}")

if __name__ == "__main__":
    main()