#!/usr/bin/env python3
"""
测试单个模型和单个查询
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import (
    SQLGenerationTesterFullDBOptimized, TestCase, FullDatabaseSchemaLoader
)
import time

def test_single_query(model_name, server_url="http://10.254.2.127:8001"):
    print(f"测试模型: {model_name}")
    print(f"服务器: {server_url}")

    # 加载schema
    schema_loader = FullDatabaseSchemaLoader("data/json/compressed_schema.json")
    full_schema_text = schema_loader.load_full_schema()

    # 初始化测试器
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url=f"{server_url}/v1",
        timeout=60,
        full_schema_text=full_schema_text
    )

    # 创建简单测试用例
    test_case = TestCase(
        id=1,
        name="简单查询 - 大学设置表",
        natural_language_query="查询大学设置基本条件表的所有记录",
        expected_sql="SELECT * FROM auto_base_daxueshezhi",
        difficulty="basic",
        description="简单SELECT查询"
    )

    print(f"查询: {test_case.natural_language_query}")
    print(f"期望SQL: {test_case.expected_sql}")

    try:
        start_time = time.time()
        raw_sql, cleaned_sql, response_time = tester.generate_sql(model_name, test_case.natural_language_query)
        elapsed = time.time() - start_time

        print(f"\n生成成功!")
        print(f"原始响应: {raw_sql}")
        print(f"清理后SQL: {cleaned_sql}")
        print(f"响应时间: {response_time:.2f}秒")
        print(f"总时间: {elapsed:.2f}秒")

        # 简单检查
        if "SELECT" in cleaned_sql.upper() and "FROM" in cleaned_sql.upper():
            print("[OK] 看起来像有效的SQL语句")
            if "auto_base_daxueshezhi" in cleaned_sql.lower():
                print("[OK] 包含正确的表名")
            else:
                print("[WARN] 表名可能不正确")
        else:
            print("[ERROR] 不是有效的SQL语句")

        return True, raw_sql, cleaned_sql

    except Exception as e:
        print(f"\n生成失败: {e}")
        return False, str(e), ""

if __name__ == "__main__":
    # 测试几个模型
    models_to_test = [
        "a-kore/Arctic-Text2SQL-R1-7B:latest",
        "HridaAI/hrida-t2sql-128k:latest",
        "deepseek-r1:8b",
        "carstenuhlig/omnicoder-9b:q4_k_m"
    ]

    for model in models_to_test:
        print("\n" + "="*80)
        success, raw, cleaned = test_single_query(model)
        if not success:
            print(f"模型 {model} 测试失败")
        print("="*80)
        time.sleep(2)  # 短暂间隔