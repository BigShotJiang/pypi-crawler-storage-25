#!/usr/bin/env python3
"""
优化版SQL生成测试 v2
基于测试结果分析的修正版本：
1. 简化提示词，避免过于复杂
2. 增强SQL提取能力
3. 调整评估逻辑
"""

import requests
import json
import time
import re
from datetime import datetime

OLLAMA_URL = "http://10.254.2.99:8001"

def load_simplified_schema():
    """加载简化schema"""
    return """压缩版数据库结构（关键表）：
1. auto_base_daxueshezhi（大学设置表）- 字段: field1, field2, status
2. auto_caiji_chuangxin_team（创新团队表）- 字段: year, team_name, members
3. auto_caiji_fuwu_summarykyxmdzjf（科研项目到账经费表）- 字段: xueyuanName, money_1, year
4. auto_caiji_guoji_projectjscgyx（教师出国研修表）- 字段: projectlevelName, chuguo_time, teacher_name
5. auto_caiji_guoji_projectxscgxx（学生出国学习表）- 字段: year, number_person, destination
6. auto_caiji_guoji_summarylxhb（留学湖北表）- 字段: year, number_1, student_type"""

def create_test_cases():
    """创建测试用例"""
    return [
        {
            "id": 1,
            "name": "简单查询",
            "query": "查询大学设置基本条件表的所有记录",
            "expected_sql": "SELECT * FROM auto_base_daxueshezhi"
        },
        {
            "id": 2,
            "name": "条件查询",
            "query": "查询创新团队表中年度为2023的记录",
            "expected_sql": "SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'"
        },
        {
            "id": 3,
            "name": "聚合查询",
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
            "expected_sql": "SELECT xueyuanName, SUM(money_1) as total_money FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName"
        }
    ]

def get_models():
    """获取可用模型"""
    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10)
        if response.status_code == 200:
            data = response.json()
            models = [model["name"] for model in data.get("models", [])]
            return models
    except:
        pass

    # 默认模型列表
    return ["qwen3:32b", "qwen3:8b", "qwen3:30b"]

# ==================== 优化的提示词 ====================

def create_simple_direct_prompt(schema, query):
    """简单直接的提示词 - 基于原始成功版本"""
    return f"""# SQL生成专家

## 重要指令
只输出SQL语句，不要任何解释、推理过程或额外文本。

## 数据库schema
{schema}

## 查询
{query}

## SQL语句："""

def create_strict_prompt(schema, query):
    """严格模式提示词 - 明确禁止推理"""
    return f"""你是一个SQL生成专家。请将以下中文查询转换为SQL语句。

要求：
1. 只输出SQL语句，不要任何其他内容
2. 不要解释、分析或推理
3. 使用标准SQL语法
4. 基于提供的schema

数据库结构：
{schema}

查询：{query}

SQL："""

# ==================== 增强的SQL提取 ====================

def extract_sql_enhanced(response):
    """增强版SQL提取"""
    if not response:
        return ""

    response = response.strip()

    # 尝试直接提取完整SQL
    patterns = [
        # 完整SELECT语句
        r"(SELECT\s+.+?\s+FROM\s+\S+(?:\s+WHERE\s+.+?)?(?:\s+GROUP\s+BY\s+.+?)?(?:\s+ORDER\s+BY\s+.+?)?(?:\s+LIMIT\s+.+?)?)",
        # 包含JOIN的语句
        r"(SELECT\s+.+?\s+(?:FROM|JOIN).+?)",
        # 简化的SELECT语句
        r"(SELECT\s+.+?\s+FROM\s+\S+)",
        # 以SELECT开头
        r"(SELECT\s+.+)",
    ]

    for pattern in patterns:
        matches = re.findall(pattern, response, re.IGNORECASE | re.DOTALL)
        if matches:
            # 选择最长的匹配（可能是最完整的）
            longest_match = max(matches, key=len)
            return longest_match.strip()

    # 如果找不到完整SQL，尝试从推理文本中提取
    lines = response.split('\n')
    sql_candidates = []

    for line in lines:
        line = line.strip()
        # 检查是否包含SQL关键字
        if re.search(r'\b(SELECT|FROM|WHERE|GROUP BY|ORDER BY|JOIN)\b', line, re.IGNORECASE):
            # 尝试提取SQL片段
            sql_match = re.search(r'(\bSELECT\b.+)$', line, re.IGNORECASE | re.DOTALL)
            if sql_match:
                sql_candidates.append(sql_match.group(1).strip())

    if sql_candidates:
        # 返回最长的候选
        return max(sql_candidates, key=len)

    return response  # 返回原始响应

def clean_sql_basic(sql_text):
    """基础SQL清洗"""
    if not sql_text:
        return ""

    # 移除代码块标记
    cleaned = re.sub(r'^```sql\s*', '', sql_text, flags=re.IGNORECASE)
    cleaned = re.sub(r'^```\s*', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s*```\s*$', '', cleaned, flags=re.IGNORECASE)

    # 移除XML标签
    cleaned = re.sub(r'<[^>]+>', '', cleaned)

    # 移除分号
    cleaned = cleaned.rstrip(';')

    # 移除常见前缀
    prefixes = [
        r'^sql\s*', r'^query:\s*', r'^生成的sql:\s*',
        r'^输出:\s*', r'^答案:\s*', r'^SQL语句:\s*',
        r'^SQL:\s*'
    ]
    for prefix in prefixes:
        cleaned = re.sub(prefix, '', cleaned, flags=re.IGNORECASE)

    # 规范化空白
    cleaned = re.sub(r'\s+', ' ', cleaned)
    cleaned = cleaned.strip()

    return cleaned

def repair_incomplete_sql(sql):
    """修复不完整的SQL"""
    if not sql:
        return sql

    sql_upper = sql.upper()

    # 检查是否有SELECT但没有FROM
    if "SELECT" in sql_upper and "FROM" not in sql_upper:
        # 尝试根据查询内容添加FROM
        if "AUTO_BASE_DAXUESHEZHI" in sql_upper or "大学" in sql:
            return sql + " FROM auto_base_daxueshezhi"
        elif "AUTO_CAIJI_CHUANGXIN_TEAM" in sql_upper or "创新团队" in sql:
            return sql + " FROM auto_caiji_chuangxin_team"
        elif "AUTO_CAIJI_FUWU_SUMMARYKYXMDZJF" in sql_upper or "科研项目" in sql:
            return sql + " FROM auto_caiji_fuwu_summarykyxmdzjf"

    # 检查是否有WHERE但没有条件
    if "WHERE" in sql_upper:
        where_pos = sql_upper.find("WHERE")
        after_where = sql[where_pos + 5:].strip()
        if len(after_where) < 3 or after_where.upper() in ["", "''", "' '"]:
            # 移除空的WHERE
            sql = sql[:where_pos].strip()

    return sql

# ==================== 评估函数 ====================

def evaluate_sql_flexible(generated, expected):
    """灵活的SQL评估"""
    if not generated:
        return "ERROR", "无生成内容"

    # 检查是否包含SQL关键字
    if not re.search(r'\bSELECT\b', generated, re.IGNORECASE):
        return "FAIL", "不是有效的SQL（缺少SELECT）"

    # 精确匹配
    if generated.upper() == expected.upper():
        return "PASS", "精确匹配"

    # 忽略大小写和空白比较
    gen_norm = re.sub(r'\s+', ' ', generated.upper())
    exp_norm = re.sub(r'\s+', ' ', expected.upper())

    if gen_norm == exp_norm:
        return "PASS", "标准化后匹配"

    # 检查是否包含必要的表名
    expected_tables = re.findall(r'FROM\s+(\S+)', expected.upper())
    for table in expected_tables:
        if table not in gen_norm:
            return "FAIL", f"缺少表名: {table}"

    # 部分匹配检查
    gen_words = set(re.findall(r'\b\w+\b', gen_norm))
    exp_words = set(re.findall(r'\b\w+\b', exp_norm))
    common_words = gen_words.intersection(exp_words)

    if len(exp_words) > 0:
        similarity = len(common_words) / len(exp_words)
        if similarity > 0.7:
            return "PARTIAL", f"部分匹配 ({len(common_words)}/{len(exp_words)} 关键词)"
        elif similarity > 0.5:
            return "PARTIAL", f"低相似度 ({similarity:.1%})"

    return "FAIL", "不匹配"

# ==================== 模型调用 ====================

def call_model(model_name, prompt):
    """调用模型生成SQL"""
    url = f"{OLLAMA_URL}/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    data = {
        "model": model_name,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.0,
        "max_tokens": 200,
        "stream": False
    }

    try:
        start_time = time.time()
        response = requests.post(url, headers=headers, json=data, timeout=120)
        response_time = time.time() - start_time

        if response.status_code == 200:
            result = response.json()
            choices = result.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                content = message.get("content", "")
                reasoning = message.get("reasoning", "")

                # 优先使用content，如果为空则使用reasoning
                raw_response = content if content.strip() else reasoning
                return raw_response, response_time, None
            else:
                return "", response_time, "响应中没有choices字段"
        else:
            return "", 0, f"API错误: {response.status_code} - {response.text[:100]}"

    except Exception as e:
        return "", 0, f"请求异常: {str(e)}"

# ==================== 主测试函数 ====================

def run_test_with_prompt(prompt_type="simple"):
    """使用指定提示词类型运行测试"""
    print("=" * 60)
    print(f"SQL生成测试 - {prompt_type}提示词")
    print("=" * 60)

    schema = load_simplified_schema()
    test_cases = create_test_cases()
    models = get_models()

    results = []
    total_tests = len(models) * len(test_cases)
    completed = 0

    for model in models:
        print(f"\n测试模型: {model}")

        for test_case in test_cases:
            print(f"  用例{test_case['id']}: {test_case['name']}...", end="", flush=True)

            # 选择提示词类型
            if prompt_type == "simple":
                prompt = create_simple_direct_prompt(schema, test_case["query"])
            else:
                prompt = create_strict_prompt(schema, test_case["query"])

            raw_sql, response_time, error = call_model(model, prompt)

            if error:
                print(f" [ERROR] ({response_time:.1f}s)")
                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": "ERROR",
                    "response_time": response_time,
                    "error": error,
                    "prompt_type": prompt_type
                })
            else:
                # 提取SQL
                extracted = extract_sql_enhanced(raw_sql)

                # 清洗
                cleaned = clean_sql_basic(extracted)

                # 修复不完整SQL
                repaired = repair_incomplete_sql(cleaned)

                # 评估
                result, match_type = evaluate_sql_flexible(repaired, test_case["expected_sql"])

                print(f" [{result}] ({response_time:.1f}s)")

                results.append({
                    "model": model,
                    "test_id": test_case["id"],
                    "test_name": test_case["name"],
                    "result": result,
                    "response_time": response_time,
                    "match_type": match_type,
                    "raw_response": raw_sql[:150],
                    "extracted_sql": extracted[:100],
                    "repaired_sql": repaired[:100],
                    "expected_sql": test_case["expected_sql"],
                    "prompt_type": prompt_type
                })

            completed += 1

    # 计算得分
    scores = {}
    for model in models:
        model_results = [r for r in results if r["model"] == model]
        total = len(model_results)
        passed = len([r for r in model_results if r["result"] == "PASS"])
        partial = len([r for r in model_results if r["result"] == "PARTIAL"])
        total_time = sum(r["response_time"] for r in model_results if r["response_time"])

        scores[model] = {
            "total": total,
            "passed": passed,
            "partial": partial,
            "avg_time": total_time / total if total > 0 else 0,
            "pass_rate": passed / total if total > 0 else 0,
            "effective_rate": (passed + partial * 0.5) / total if total > 0 else 0
        }

    # 显示结果
    print("\n" + "=" * 60)
    print(f"测试结果 ({prompt_type}提示词)")
    print("=" * 60)

    sorted_scores = sorted(scores.items(), key=lambda x: x[1]["effective_rate"], reverse=True)

    for i, (model, data) in enumerate(sorted_scores, 1):
        print(f"{i}. {model}")
        print(f"   通过率: {data['pass_rate']:.2%} ({data['passed']}/{data['total']})")
        print(f"   部分通过: {data['partial']}")
        print(f"   平均响应时间: {data['avg_time']:.2f}秒")
        print(f"   有效得分: {data['effective_rate']:.2%}")
        print()

    # 保存结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"optimized_v2_{prompt_type}_results_{timestamp}.json"

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            "timestamp": timestamp,
            "prompt_type": prompt_type,
            "models": models,
            "test_cases": test_cases,
            "results": results,
            "scores": scores
        }, f, ensure_ascii=False, indent=2)

    print(f"结果已保存到: {output_file}")

    return results, scores

def compare_optimizations():
    """比较不同优化策略"""
    print("=" * 80)
    print("SQL生成优化策略比较测试")
    print("=" * 80)

    # 运行两种提示词测试
    print("\n1. 运行简单直接提示词测试...")
    simple_results, simple_scores = run_test_with_prompt("simple")

    print("\n2. 运行严格模式提示词测试...")
    strict_results, strict_scores = run_test_with_prompt("strict")

    # 比较结果
    print("\n" + "=" * 80)
    print("优化策略比较结果")
    print("=" * 80)

    models = get_models()
    for model in models:
        simple_score = simple_scores.get(model, {}).get("effective_rate", 0)
        strict_score = strict_scores.get(model, {}).get("effective_rate", 0)

        print(f"\n{model}:")
        print(f"  简单提示词有效得分: {simple_score:.2%}")
        print(f"  严格提示词有效得分: {strict_score:.2%}")

        if simple_score > strict_score:
            print(f"  ✓ 简单提示词效果更好 ({simple_score-strict_score:.1%}优势)")
        elif strict_score > simple_score:
            print(f"  ✓ 严格提示词效果更好 ({strict_score-simple_score:.1%}优势)")
        else:
            print(f"  ⚠ 两种提示词效果相同")

    # 总体评估
    simple_avg = sum(simple_scores.get(m, {}).get("effective_rate", 0) for m in models) / len(models)
    strict_avg = sum(strict_scores.get(m, {}).get("effective_rate", 0) for m in models) / len(models)

    print(f"\n总体平均:")
    print(f"  简单提示词: {simple_avg:.2%}")
    print(f"  严格提示词: {strict_avg:.2%}")

    if simple_avg > strict_avg:
        print(f"推荐使用简单直接提示词策略")
    else:
        print(f"推荐使用严格模式提示词策略")

    return simple_results, strict_results, simple_scores, strict_scores

if __name__ == "__main__":
    # 运行比较测试
    compare_optimizations()