#!/usr/bin/env python3
"""
测试清理器对实际模型响应的处理
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import SQLResponseCleaner

def test_actual_responses():
    """测试实际响应"""
    cleaner = SQLResponseCleaner()

    # 从测试结果文件中读取实际响应
    import json
    with open('full_db_results_qwen8b/sql_test_results_20260325_092025.json', 'r', encoding='utf-8') as f:
        results = json.load(f)

    for i, result in enumerate(results):
        if i >= 3:  # 只测试前3个
            break

        test_id = result['test_case_id']
        generated = result['generated_sql']
        original_cleaned = result['cleaned_sql']

        print(f"\n=== 测试用例 {test_id} ===")
        print(f"原始生成的SQL (长度: {len(generated)}):")
        print(repr(generated[:200]) + ('...' if len(generated) > 200 else ''))
        print()

        # 使用我们的清理器
        cleaned = cleaner.clean_sql_response(generated)
        print(f"清理后的SQL (长度: {len(cleaned)}):")
        print(repr(cleaned))
        print()

        print(f"原清理结果 (长度: {len(original_cleaned)}):")
        print(repr(original_cleaned[:200]) + ('...' if len(original_cleaned) > 200 else ''))
        print()

        print(f"看起来像SQL吗? {cleaner.is_likely_sql(cleaned)}")
        print()

if __name__ == "__main__":
    test_actual_responses()