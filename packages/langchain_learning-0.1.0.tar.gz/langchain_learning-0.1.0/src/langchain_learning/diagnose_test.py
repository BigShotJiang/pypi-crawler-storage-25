#!/usr/bin/env python3
"""诊断测试框架问题"""

import requests
import time
import json

class SimpleTester:
    def __init__(self, base_url="http://10.254.2.99:8001"):
        self.base_url = base_url.rstrip('/')
        self.api_url = f"{self.base_url}/v1"

    def test_single_request(self, model_name, query, timeout=60):
        """测试单个请求"""
        url = f"{self.api_url}/chat/completions"
        headers = {"Content-Type": "application/json"}

        # 简化提示
        prompt = f"""根据以下数据库schema，将中文查询转换为SQL语句：

数据库schema包含118个表，分为8个主题。

查询：{query}

只输出SQL语句，不要解释。"""

        data = {
            "model": model_name,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.0,
            "max_tokens": 512,
            "stream": False
        }

        print(f"\n测试模型: {model_name}")
        print(f"查询: {query}")

        try:
            start_time = time.time()
            response = requests.post(url, headers=headers, json=data, timeout=timeout)
            response_time = time.time() - start_time
            print(f"响应时间: {response_time:.2f}秒")
            print(f"状态码: {response.status_code}")

            response.raise_for_status()
            response_data = response.json()

            # 提取响应
            choices = response_data.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                content = message.get("content", "")
                print(f"生成SQL: {content[:200]}...")
                return True, content, response_time
            else:
                print(f"响应中没有choices字段")
                return False, "", response_time

        except requests.exceptions.RequestException as e:
            print(f"请求异常: {type(e).__name__}: {e}")
            return False, "", 0
        except Exception as e:
            print(f"其他异常: {type(e).__name__}: {e}")
            return False, "", 0

    def test_multiple_requests(self, model_name, queries, timeout=30):
        """测试同一个模型的多个请求"""
        print(f"\n{'='*60}")
        print(f"测试模型 {model_name} 的多个请求")
        print(f"{'='*60}")

        results = []
        for i, query in enumerate(queries):
            print(f"\n请求 #{i+1}/{len(queries)}")
            success, sql, rt = self.test_single_request(model_name, query, timeout)
            results.append((success, sql, rt))

            # 短暂延迟
            if i < len(queries) - 1:
                print("等待2秒...")
                time.sleep(2)

        return results

    def test_unload(self, model_name):
        """测试卸载模型"""
        url = f"{self.base_url}/api/unload"
        payload = {"model": model_name}

        print(f"\n尝试卸载模型: {model_name}")
        try:
            response = requests.post(url, json=payload, timeout=10)
            print(f"卸载响应状态码: {response.status_code}")
            print(f"卸载响应: {response.text[:100]}")
            return response.status_code == 200
        except Exception as e:
            print(f"卸载失败: {e}")
            return False

def main():
    tester = SimpleTester()

    # 测试查询集
    test_queries = [
        "查询大学设置基本条件表的所有记录",
        "查询创新团队表中所属院系为计算机学院的记录",
        "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和"
    ]

    # 测试第一个模型
    model1 = "glm-4.7-flash:q4_K_M"
    print(f"测试模型: {model1}")
    results1 = tester.test_multiple_requests(model1, test_queries, timeout=60)

    # 统计结果
    success_count = sum(1 for success, _, _ in results1 if success)
    print(f"\n模型 {model1} 测试结果: {success_count}/{len(results1)} 成功")

    # 测试卸载
    if success_count > 0:
        tester.test_unload(model1)

    # 测试第二个模型
    print(f"\n{'='*60}")
    model2 = "gemma3:27b"
    print(f"测试第二个模型: {model2}")

    # 只测试一个查询
    success, sql, rt = tester.test_single_request(model2, test_queries[0], timeout=60)

    if success:
        print(f"模型 {model2} 第一个查询测试成功")
        tester.test_unload(model2)
    else:
        print(f"模型 {model2} 第一个查询测试失败")

if __name__ == "__main__":
    main()