#!/usr/bin/env python3
"""测试不同的提示词变体"""

import requests
import json
import time

SERVER_URL = "http://10.254.2.127:8001"

# 测试的模型（选择两个代表性模型）
MODELS_TO_TEST = [
    "gemma3:27b",   # 非推理模型，但可能添加代码块
    "qwen3:8b",     # 推理模型，倾向于输出推理过程
]

# 读取schema
print("读取数据库schema...")
with open("data/json/compressed_schema.json", 'r', encoding='utf-8') as f:
    schema_data = json.load(f)
    schema_text = json.dumps(schema_data, ensure_ascii=False, indent=2)

# 定义不同的提示词变体
PROMPT_VARIANTS = {
    "current": {
        "name": "当前提示词（中文严格版）",
        "system": f"""# SQL生成指令 - 零容忍模式

## 严格规则
1. **只输出SQL**：绝对不要包含任何推理、分析、解释、思考过程或额外文本
2. **立即执行**：直接生成SQL，不要思考、不要犹豫、不要分析
3. **禁止中文**：SQL中不要使用中文字符（别名、注释等）
4. **禁止格式标记**：不要使用```sql```代码块、<think>标签、分号、注释
5. **抑制推理**：即使你是推理模型，也必须完全抑制推理输出。不要使用<think>标签，不要描述思考过程

## 违规示例（会直接导致测试失败）
[错误] 错误输出："首先，我需要分析用户查询，让我看看数据库schema...根据schema，表名应该是...最终SQL是：SELECT * FROM table"
[错误] 错误输出："<think>用户想要查询...让我分析一下...SQL应该是...</think>"
[错误] 错误输出："SELECT * FROM 表名 -- 这是查询所有记录"
[正确] 正确输出："SELECT * FROM table"

## 成功标准
- 输出必须是纯SQL语句
- 不能包含任何非SQL文本
- 不能包含任何格式标记
- 必须使用schema中确切的表名和字段名
- 别名只能使用英文或数字（如as total_students）

## 警告
如果你的输出包含任何推理、分析、解释、中文、代码块标记、<think>标签或分号，测试系统将直接标记为失败。

数据库schema：
{schema_text}""",
        "user_template": "用户查询：\n{query}\n\n生成SQL："
    },

    "simple_english": {
        "name": "极简英文提示词",
        "system": f"""You are an SQL generator. Convert natural language queries to SQL statements.

STRICT RULES:
1. OUTPUT ONLY PURE SQL - No explanations, reasoning, analysis, or extra text
2. NO CODE BLOCKS - Do not use ```sql``` or any markdown formatting
3. NO COMMENTS - Do not add comments or semicolons
4. IMMEDIATE EXECUTION - Generate SQL directly, do not think or analyze
5. SUPPRESS REASONING - Even if you are a reasoning model, suppress all reasoning output

FORMAT REQUIREMENTS:
- Output: Pure SQL statement only
- Prohibited: ```sql```, <think>, comments, explanations, reasoning text, semicolons
- Use exact table/field names from schema
- Use English/numeric aliases only (e.g., as total_students)

CRITICAL: If you output anything other than pure SQL, you will fail the test.

Database schema:
{schema_text}""",
        "user_template": "User query:\n{query}\n\nGenerate SQL:"
    },

    "system_user_separate": {
        "name": "系统/用户分离英文提示词",
        "system": f"""You are an SQL expert. Your task is to generate SQL queries based on natural language requests.

IMPORTANT INSTRUCTIONS:
- Output ONLY the SQL query, nothing else
- Do NOT include any explanations, reasoning, or commentary
- Do NOT use markdown code blocks (```sql```)
- Do NOT include <think> tags or similar reasoning tags
- Do NOT add semicolons or comments
- Generate the SQL directly without any preamble

The database schema is provided below. Use the exact table and column names from the schema.

Database schema:
{schema_text}""",
        "user_template": "Generate an SQL query for: {query}"
    },

    "explicit_format": {
        "name": "明确格式要求提示词",
        "system": f"""Generate SQL queries. Follow these exact output format rules:

OUTPUT FORMAT: PURE SQL ONLY

WHAT TO OUTPUT:
- Only the SQL statement
- No additional text
- No explanations
- No reasoning
- No markdown
- No code blocks
- No <think> tags
- No comments
- No semicolons

WHAT NOT TO OUTPUT:
- Do not say "Here is the SQL:"
- Do not say "The SQL query is:"
- Do not say "SELECT ..."
- Do not add any text before or after the SQL

EXAMPLE CORRECT OUTPUT:
SELECT * FROM table_name

EXAMPLE INCORRECT OUTPUT:
```sql
SELECT * FROM table_name
```

EXAMPLE INCORRECT OUTPUT:
First, I need to analyze the query... The SQL is: SELECT * FROM table_name

Database schema:
{schema_text}""",
        "user_template": "Query: {query}\n\nSQL:"
    }
}

# 测试查询
test_query = "查询所有院系名称"

print(f"测试查询: {test_query}")
print(f"将测试 {len(MODELS_TO_TEST)} 个模型和 {len(PROMPT_VARIANTS)} 种提示词变体")
print("=" * 80)

all_results = []

for model in MODELS_TO_TEST:
    print(f"\n测试模型: {model}")
    print("=" * 60)

    for variant_key, variant in PROMPT_VARIANTS.items():
        print(f"\n提示词变体: {variant['name']}")
        print("-" * 40)

        # 构建消息
        messages = [
            {"role": "system", "content": variant["system"]},
            {"role": "user", "content": variant["user_template"].format(query=test_query)}
        ]

        # 准备API请求
        url = f"{SERVER_URL.rstrip('/')}/v1/chat/completions"
        headers = {"Content-Type": "application/json"}

        data = {
            "model": model,
            "messages": messages,
            "temperature": 0.0,
            "max_tokens": 512,
            "stream": False
        }

        start_time = time.time()
        try:
            response = requests.post(url, headers=headers, json=data, timeout=300)
            response.raise_for_status()
            response_data = response.json()

            response_time = time.time() - start_time

            # 提取响应
            choices = response_data.get("choices", [])
            if not choices:
                print(f"  [错误] API响应中没有choices字段")
                all_results.append({
                    "model": model,
                    "variant": variant_key,
                    "success": False,
                    "error": "No choices in response",
                    "response_time": response_time
                })
                continue

            message = choices[0].get("message", {})
            raw_response = message.get("content", "")

            print(f"  响应时间: {response_time:.2f}秒")
            print(f"  响应长度: {len(raw_response)} 字符")
            print(f"  响应内容: {repr(raw_response[:150])}")

            # 分析响应
            contains_chinese = any('\u4e00' <= c <= '\u9fff' for c in raw_response)
            contains_think = '<think>' in raw_response.lower()
            contains_explanation = any(word in raw_response.lower() for word in ['首先', 'then', 'need', 'should', 'let me', 'analysis', 'think', 'reasoning', 'explanation', 'here is'])
            contains_code_block = '```' in raw_response
            starts_with_select = raw_response.strip().upper().startswith('SELECT')

            # 判断是否遵循指令
            follows_instructions = (starts_with_select and
                                   not contains_chinese and
                                   not contains_think and
                                   not contains_explanation and
                                   not contains_code_block)

            if follows_instructions:
                print(f"  [成功] 模型遵循指令: 输出纯SQL")
            else:
                issues = []
                if not starts_with_select:
                    issues.append("不以SELECT开头")
                if contains_chinese:
                    issues.append("包含中文")
                if contains_think:
                    issues.append("包含<think>标签")
                if contains_explanation:
                    issues.append("包含解释文本")
                if contains_code_block:
                    issues.append("包含代码块标记")
                print(f"  [失败] 模型未遵循指令: {', '.join(issues)}")

            all_results.append({
                "model": model,
                "variant": variant_key,
                "variant_name": variant["name"],
                "success": True,
                "follows_instructions": follows_instructions,
                "response_time": response_time,
                "response_length": len(raw_response),
                "contains_chinese": contains_chinese,
                "contains_think": contains_think,
                "contains_explanation": contains_explanation,
                "contains_code_block": contains_code_block,
                "starts_with_select": starts_with_select,
                "raw_response_preview": raw_response[:200]
            })

        except Exception as e:
            response_time = time.time() - start_time
            print(f"  [错误] 请求失败: {e}")
            all_results.append({
                "model": model,
                "variant": variant_key,
                "variant_name": variant["name"],
                "success": False,
                "error": str(e),
                "response_time": response_time
            })

        # 在请求之间添加延迟
        time.sleep(5)

    # 在模型之间添加更长延迟
    if model != MODELS_TO_TEST[-1]:
        delay = 15
        print(f"\n等待 {delay} 秒后测试下一个模型...")
        time.sleep(delay)

# 打印汇总结果
print(f"\n{'='*80}")
print("测试完成汇总")
print("=" * 80)

# 按模型和变体显示结果
for model in MODELS_TO_TEST:
    print(f"\n模型: {model}")
    model_results = [r for r in all_results if r["model"] == model and r.get("success", False)]

    for result in model_results:
        status = "[遵循]" if result.get("follows_instructions", False) else "[未遵循]"
        issues = []
        if result.get("contains_chinese", False):
            issues.append("中文")
        if result.get("contains_think", False):
            issues.append("<think>标签")
        if result.get("contains_explanation", False):
            issues.append("解释文本")
        if result.get("contains_code_block", False):
            issues.append("代码块标记")
        if not result.get("starts_with_select", False):
            issues.append("不以SELECT开头")

        issue_text = f" ({', '.join(issues)})" if issues else ""
        print(f"  {status} {result['variant_name']}: {result['response_time']:.1f}秒{issue_text}")

# 保存结果
timestamp = time.strftime("%Y%m%d_%H%M%S")
output_file = f"prompt_variants_test_results_{timestamp}.json"
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump({
        "timestamp": timestamp,
        "server_url": SERVER_URL,
        "test_query": test_query,
        "results": all_results
    }, f, ensure_ascii=False, indent=2)

print(f"\n结果已保存到: {output_file}")