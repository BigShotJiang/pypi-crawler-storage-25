#!/usr/bin/env python3
import json

with open('data/json/compressed_schema.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"主题数: {len(data['themes'])}")
total_tables = sum(len(theme['tables']) for theme in data['themes'])
print(f"总表数: {total_tables}")

# 打印每个主题的表数
for i, theme in enumerate(data['themes']):
    print(f"主题 {i+1}: {theme['name']} - {len(theme['tables'])} 个表")