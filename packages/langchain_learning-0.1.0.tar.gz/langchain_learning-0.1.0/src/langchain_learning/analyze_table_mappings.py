#!/usr/bin/env python3
"""
分析数据库schema中的中文标签与表名映射关系
"""

import json
import os
import sys

def analyze_schema_mappings():
    """分析schema中的所有表名和中文标签映射"""
    schema_file = "data/json/compressed_schema.json"

    print("=" * 80)
    print("数据库表名与中文标签映射分析")
    print("=" * 80)

    with open(schema_file, 'r', encoding='utf-8') as f:
        schema_data = json.load(f)

    # 收集所有表信息
    all_tables = []
    theme_counts = {}

    for theme in schema_data.get('themes', []):
        theme_name = theme.get('name', '未知主题')
        theme_desc = theme.get('description', '')
        tables = theme.get('tables', [])

        theme_counts[theme_name] = len(tables)

        for table in tables:
            table_name = table.get('original_name', '')
            table_label = table.get('label', '')
            table_desc = table.get('description', '')
            keywords = table.get('keywords', [])

            # 从表名提取可能的拼音部分（去掉auto_前缀）
            table_name_clean = table_name.replace('auto_', '')

            # 从标签提取关键词（中文）
            label_keywords = []
            if table_label:
                # 简单的分词：按空格、下划线、中文分隔符分割
                import re
                label_parts = re.split(r'[ _\-，,。、（）()]+', table_label)
                label_keywords = [part.strip() for part in label_parts if part.strip()]

            all_tables.append({
                'theme': theme_name,
                'table_name': table_name,
                'table_label': table_label,
                'table_desc': table_desc,
                'keywords': keywords,
                'label_keywords': label_keywords,
                'clean_name': table_name_clean
            })

    print(f"总表数: {len(all_tables)}")
    print(f"主题分布:")
    for theme, count in theme_counts.items():
        print(f"  - {theme}: {count}个表")

    print("\n" + "=" * 80)
    print("测试用例相关表分析")
    print("=" * 80)

    # 重点关注测试用例中的表
    test_tables = [
        "auto_base_daxueshezhi",
        "auto_caiji_chuangxin_team",
        "auto_caiji_fuwu_summarykyxmdzjf"
    ]

    for table_name in test_tables:
        matching = [t for t in all_tables if t['table_name'] == table_name]
        if matching:
            table = matching[0]
            print(f"\n表: {table['table_name']}")
            print(f"主题: {table['theme']}")
            print(f"中文标签: {table['table_label']}")
            print(f"描述: {table['table_desc'][:100]}...")
            print(f"关键词: {', '.join(table['keywords'][:5])}")
            print(f"标签关键词: {', '.join(table['label_keywords'])}")

            # 分析标签与表名的关系
            label_chinese = ''.join([c for c in table['table_label'] if '\u4e00' <= c <= '\u9fff'])
            print(f"纯中文标签: {label_chinese}")

            # 提取可能的拼音缩写
            clean_parts = table['clean_name'].split('_')
            print(f"表名部分: {clean_parts}")

    print("\n" + "=" * 80)
    print("中文标签模式分析")
    print("=" * 80)

    # 分析常见的中文标签模式
    label_patterns = {}
    for table in all_tables:
        label = table['table_label']
        if label:
            # 检查标签是否包含"表"字
            if '表' in label:
                pattern = '包含"表"字'
            elif '信息' in label:
                pattern = '包含"信息"'
            elif '统计' in label:
                pattern = '包含"统计"'
            elif '报告' in label:
                pattern = '包含"报告"'
            elif '设置' in label:
                pattern = '包含"设置"'
            elif '团队' in label:
                pattern = '包含"团队"'
            elif '项目' in label:
                pattern = '包含"项目"'
            else:
                pattern = '其他'

            label_patterns[pattern] = label_patterns.get(pattern, 0) + 1

    print("中文标签常见模式:")
    for pattern, count in sorted(label_patterns.items(), key=lambda x: x[1], reverse=True):
        print(f"  - {pattern}: {count}个表")

    print("\n" + "=" * 80)
    print("生成中文-表名映射表")
    print("=" * 80)

    # 生成推荐的映射表
    recommended_mappings = {}

    for table in all_tables:
        table_name = table['table_name']
        table_label = table['table_label']

        if table_label:
            # 主映射：完整标签 -> 表名
            recommended_mappings[table_label] = table_name

            # 子映射：标签中的关键词 -> 表名
            for keyword in table['label_keywords']:
                if keyword and len(keyword) >= 2:  # 至少2个字符
                    recommended_mappings[keyword] = table_name

            # 从描述中提取可能的中文术语
            desc = table['table_desc']
            if desc:
                # 简单的提取：取前20个字符中的中文词
                import re
                chinese_words = re.findall(r'[\u4e00-\u9fff]{2,}', desc[:50])
                for word in chinese_words[:3]:  # 取前3个
                    recommended_mappings[word] = table_name

    # 去重并排序
    unique_mappings = {}
    for chinese, table in recommended_mappings.items():
        if chinese not in unique_mappings:
            unique_mappings[chinese] = table
        else:
            # 如果有冲突，保留更长的中文术语
            if len(chinese) > len([k for k, v in unique_mappings.items() if v == table][0]):
                # 找到当前映射的key并替换
                for k, v in list(unique_mappings.items()):
                    if v == table and len(k) < len(chinese):
                        del unique_mappings[k]
                        unique_mappings[chinese] = table
                        break

    print(f"生成 {len(unique_mappings)} 个中文-表名映射")

    # 保存映射表
    output_file = "data/json/chinese_table_mappings.json"
    os.makedirs(os.path.dirname(output_file), exist_ok=True)

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            'mappings': unique_mappings,
            'table_count': len(all_tables),
            'generated_time': '2026-04-03'
        }, f, ensure_ascii=False, indent=2)

    print(f"\n映射表已保存到: {output_file}")

    # 显示部分映射示例
    print("\n映射表示例（前20个）:")
    mappings_list = list(unique_mappings.items())[:20]
    for i, (chinese, table) in enumerate(mappings_list, 1):
        print(f"{i:2d}. {chinese:20s} -> {table}")

    return unique_mappings, all_tables

if __name__ == "__main__":
    analyze_schema_mappings()