#!/usr/bin/env python3
"""创建只包含测试用例相关表的最小schema"""
import json
import os

def create_mini_schema():
    # 加载压缩schema
    with open('data/json/compressed_schema.json', 'r', encoding='utf-8') as f:
        full_schema = json.load(f)

    # 测试用例使用的表
    needed_tables = {
        'auto_base_daxueshezhi',  # 简单查询
        'auto_caiji_fuwu_summarykyxmdzjf',  # 聚合查询
        'auto_caiji_guoji_summarylxhb',  # 留学湖北聚合查询
    }

    # 创建新的schema结构
    mini_schema = {
        "themes": []
    }

    # 创建一个主题包含所有需要的表
    theme = {
        "name": "测试用例相关表",
        "description": "测试用例使用的数据表",
        "tables": []
    }

    # 在所有主题中查找需要的表
    found_tables = set()
    for original_theme in full_schema['themes']:
        for table in original_theme['tables']:
            if table['original_name'] in needed_tables:
                theme['tables'].append(table)
                found_tables.add(table['original_name'])

    # 如果没有找到任何表，保留一个空主题
    if theme['tables']:
        mini_schema['themes'].append(theme)
    else:
        # 如果没找到，至少保留一个表用于测试
        print("警告：未找到任何需要的表，使用第一个表作为示例")
        for original_theme in full_schema['themes']:
            if original_theme['tables']:
                theme['tables'].append(original_theme['tables'][0])
                mini_schema['themes'].append(theme)
                break

    # 输出mini schema
    output_file = 'data/json/mini_schema.json'
    os.makedirs(os.path.dirname(output_file), exist_ok=True)

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(mini_schema, f, ensure_ascii=False, indent=2)

    print(f"创建mini schema完成: {output_file}")
    print(f"包含 {len(theme['tables'])} 个表:")
    for table in theme['tables']:
        print(f"  - {table['original_name']} ({table['label']})")

    # 计算大小
    import sys
    size = sys.getsizeof(json.dumps(mini_schema, ensure_ascii=False))
    print(f"schema大小: {size / 1024:.1f} KB")

if __name__ == '__main__':
    create_mini_schema()