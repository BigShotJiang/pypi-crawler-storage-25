#!/usr/bin/env python3
"""测试评估器的字段名标准化功能"""
import sys
sys.path.insert(0, '.')

from examples.model_sql_comprehensive_test_full_db_optimized import SQLEvaluator, TestResult

def test_field_normalization():
    """测试字段名标准化匹配"""
    print("测试字段名标准化评估逻辑...")

    # 测试用例：字段名大小写不一致，但应该通过field_normalized匹配
    test_cases = [
        # (生成的SQL, 预期SQL, 是否应该匹配)
        (
            "SELECT xueyuanName, SUM(money_1) as total_money_1 FROM table GROUP BY xueyuanName",
            "SELECT xueyuanname, SUM(money_1) as total_money_1 FROM table GROUP BY xueyuanname",
            True  # 应该匹配（字段名标准化后一致）
        ),
        (
            "SELECT XueyuanName, ProjectLevelName FROM table",
            "SELECT xueyuanname, projectlevelname FROM table",
            True
        ),
        (
            "SELECT XUEYUANNAME, PROJECTLEVELNAME FROM table",
            "SELECT xueyuanname, projectlevelname FROM table",
            True
        ),
        (
            "SELECT xueyuanname, money1 FROM table",
            "SELECT xueyuanname, money_1 FROM table",
            True  # money1标准化为money_1
        ),
        (
            "SELECT chuguotime FROM table",
            "SELECT chuguo_time FROM table",
            True  # chuguotime标准化为chuguo_time
        ),
        (
            "SELECT wrong_field FROM table",  # 不存在的字段
            "SELECT xueyuanname FROM table",
            False  # 不应该匹配
        ),
    ]

    all_passed = True
    for i, (generated, expected, should_match) in enumerate(test_cases, 1):
        result, match_type = SQLEvaluator.evaluate_sql(generated, expected)

        if should_match:
            if result == TestResult.PASS and match_type == "field_normalized":
                print(f"测试 {i}: 通过 (匹配类型: {match_type})")
            else:
                print(f"测试 {i}: 失败 (预期通过field_normalized，但得到: {result}, {match_type})")
                all_passed = False
        else:
            if result == TestResult.FAIL:
                print(f"测试 {i}: 通过 (正确拒绝)")
            else:
                print(f"测试 {i}: 失败 (预期失败，但得到: {result}, {match_type})")
                all_passed = False

    print(f"\n字段名标准化测试: {'全部通过' if all_passed else '有失败'}")

def test_normalization_functions():
    """测试标准化函数"""
    print("\n测试标准化函数...")

    # 测试normalize_field_names
    test_cases = [
        ("SELECT xueyuanName FROM table", "select xueyuanname from table"),
        ("SELECT XUEYUANNAME FROM table", "select xueyuanname from table"),
        ("SELECT XueyuanName FROM table", "select xueyuanname from table"),
        ("SELECT money1 FROM table", "select money_1 from table"),
        ("SELECT MONEY1 FROM table", "select money_1 from table"),
        ("SELECT chuguotime FROM table", "select chuguo_time from table"),
        ("SELECT CHUGUOTIME FROM table", "select chuguo_time from table"),
    ]

    for i, (input_sql, expected_lower) in enumerate(test_cases, 1):
        result = SQLEvaluator.normalize_field_names(input_sql)
        if result == expected_lower:
            print(f"测试 {i}: 通过 [OK]")
        else:
            print(f"测试 {i}: 失败 [FAIL] (输入: {input_sql})")
            print(f"     得到: {result}")
            print(f"     预期: {expected_lower}")

if __name__ == '__main__':
    test_field_normalization()
    test_normalization_functions()