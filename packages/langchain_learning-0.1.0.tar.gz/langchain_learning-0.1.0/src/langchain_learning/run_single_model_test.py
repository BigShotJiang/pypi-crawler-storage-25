#!/usr/bin/env python3
"""测试单个模型（使用修复编码后的提示词）"""

import os
import sys
import subprocess
import time
from datetime import datetime

# 服务器配置
SERVER_URL = "http://10.254.2.127:8001"
SCHEMA_FILE = "data/json/compressed_schema.json"
TEST_CASES_FILE = "test_cases_complex.json"
MODEL = "gemma3:27b"
TIMEOUT = 300  # 5分钟

def main():
    print("=" * 60)
    print(f"测试单个模型: {MODEL}")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # 检查文件
    if not os.path.exists(SCHEMA_FILE):
        print(f"错误: schema文件不存在: {SCHEMA_FILE}")
        sys.exit(1)

    if not os.path.exists(TEST_CASES_FILE):
        print(f"错误: 测试用例文件不存在: {TEST_CASES_FILE}")
        sys.exit(1)

    # 创建输出目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = f"test_fixed_prompt_{timestamp}"
    os.makedirs(output_dir, exist_ok=True)

    print(f"输出目录: {output_dir}")

    # 构建命令
    cmd = [
        "python", "examples/model_sql_comprehensive_test_full_db_optimized.py",
        "--ollama-url", SERVER_URL,
        "--schema-file", SCHEMA_FILE,
        "--test-cases", TEST_CASES_FILE,
        "--timeout", str(TIMEOUT),
        "--output-dir", output_dir,
        "--skip-model-fetch",
        "--default-models", MODEL
    ]

    cmd_str = " ".join(cmd)
    print(f"执行命令: {cmd_str}")

    # 运行命令
    start_time = time.time()
    result = subprocess.run(cmd_str, shell=True, capture_output=True, text=True)
    end_time = time.time()
    elapsed = end_time - start_time

    # 输出结果
    print(f"\n测试完成，耗时: {elapsed:.1f}秒")
    print(f"退出码: {result.returncode}")

    if result.returncode == 0:
        print("测试成功!")
        # 查找结果文件
        result_files = [f for f in os.listdir(output_dir) if f.startswith("sql_test_results_")]
        if result_files:
            latest_result = max(result_files, key=lambda f: os.path.getmtime(os.path.join(output_dir, f)))
            print(f"结果文件: {os.path.join(output_dir, latest_result)}")
    else:
        print(f"测试失败!")
        print(f"标准输出:\n{result.stdout[-1000:]}")
        print(f"标准错误:\n{result.stderr[-1000:]}")

    return result.returncode

if __name__ == "__main__":
    sys.exit(main())