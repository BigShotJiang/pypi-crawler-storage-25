# qwen3模型SQL生成能力优化建议

## 问题诊断

基于2026-03-26的测试结果，识别出以下关键问题：

### 1. 指令遵循问题
- **小模型（8b、30b）**：无法严格遵守"仅SQL语句"指令，输出推理过程
- **中模型（30b）**：表名识别错误，使用通用表名"table_name"
- **大模型（32b）**：在复杂查询中SQL不完整

### 2. SQL完整性问题
- 缺少FROM子句（qwen3:32b在条件查询中）
- 缺少WHERE条件（qwen3:30b在条件查询中）
- 聚合查询全面失败

### 3. 响应模式问题
- 所有模型在复杂查询中倾向于输出推理而非纯SQL
- 模型规模越大，指令遵循越好但速度越慢

## 优化方案

### 方案一：提示词强化优化

#### 1.1 多级强制指令
```python
prompt_template = """
# SQL生成专家 - 严格模式

## 核心指令（必须遵守）
1. 输出格式：仅SQL语句
2. 禁止内容：推理过程、解释、分析、代码块标记、XML标签
3. 语法要求：完整SQL语句，包含SELECT、FROM、WHERE等必要子句

## 违规示例（禁止输出）
错误1: "首先，我需要分析查询..." [包含推理]
错误2: "SELECT *" [缺少FROM子句]
错误3: "```sql\nSELECT...\n```" [包含代码块]

## 正确示例
查询: "查询创新团队表中年度为2023的记录"
输出: SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'

## 当前查询
{query}
"""
```

#### 1.2 分步骤指令
```python
# 步骤1：表名识别
table_prompt = "根据查询'{query}'，确定涉及的数据库表名："

# 步骤2：字段映射
field_prompt = "将中文字段描述映射到英文字段名："

# 步骤3：SQL生成
sql_prompt = "基于表{tablename}和字段映射，生成完整SQL："
```

### 方案二：Few-shot示例优化

#### 2.1 针对qwen3:8b的简化示例
```python
few_shot_examples = [
    {
        "query": "查询大学设置表",
        "output": "SELECT * FROM auto_base_daxueshezhi",
        "note": "直接输出SQL，无额外内容"
    },
    {
        "query": "查询2023年数据",
        "output": "SELECT * FROM table_name WHERE year = '2023'",
        "note": "包含WHERE条件，使用实际表名"
    }
]
```

#### 2.2 针对复杂查询的分解示例
```python
complex_examples = [
    {
        "query": "统计每个部门的经费总和",
        "analysis": "1. 识别表：科研项目到账经费表\n2. 识别分组字段：xueyuanName\n3. 识别聚合字段：money_1",
        "output": "SELECT xueyuanName, SUM(money_1) FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName"
    }
]
```

### 方案三：后处理增强

#### 3.1 智能SQL提取
```python
def extract_sql_from_response(response):
    """从可能包含推理的响应中提取SQL"""

    # 模式1：纯SQL（理想情况）
    if response.strip().upper().startswith("SELECT"):
        return response.strip()

    # 模式2：包含推理的响应
    patterns = [
        r"SELECT\s+.+?\s+FROM\s+\S+",  # 标准SELECT语句
        r"输出[:：]\s*(SELECT.+)",      # 中文提示后跟SQL
        r"SQL语句[:：]\s*(SELECT.+)"    # 明确标记的SQL
    ]

    for pattern in patterns:
        match = re.search(pattern, response, re.IGNORECASE | re.DOTALL)
        if match:
            return match.group(1).strip()

    return None
```

#### 3.2 SQL完整性验证
```python
def validate_sql_completeness(sql):
    """验证SQL语句完整性"""

    required_clauses = {
        "SELECT": r"SELECT\s+.+",
        "FROM": r"FROM\s+\S+"
    }

    for clause, pattern in required_clauses.items():
        if not re.search(pattern, sql, re.IGNORECASE):
            return False, f"缺少{clause}子句"

    # 检查WHERE条件完整性
    if "WHERE" in sql.upper() and not re.search(r"WHERE\s+.+?\s*=", sql, re.IGNORECASE):
        return False, "WHERE条件不完整"

    return True, "SQL完整"
```

### 方案四：模型特定优化

#### 4.1 qwen3:32b优化
```python
# 利用其较强的理解能力，提供详细schema
optimized_prompt_32b = """
你是一个专业的SQL生成专家。以下是完整的数据库结构：

{full_schema}

要求：
1. 直接输出SQL语句，不要任何解释
2. 确保SQL语法完整（SELECT、FROM、WHERE等）
3. 使用准确的表名和字段名

查询：{query}
"""
```

#### 4.2 qwen3:8b优化
```python
# 简化指令，强调格式
optimized_prompt_8b = """
SQL语句：{query}

格式要求：
- 只输出SQL
- 不要解释
- 使用正确表名

示例：
输入：查询大学设置表
输出：SELECT * FROM auto_base_daxueshezhi
"""
```

#### 4.3 qwen3:30b优化
```python
# 强化表名识别
optimized_prompt_30b = """
查询：{query}

可用表：
- auto_base_daxueshezhi（大学设置表）
- auto_caiji_chuangxin_team（创新团队表）
- auto_caiji_fuwu_summarykyxmdzjf（科研项目经费表）

要求：输出完整SQL语句，不要其他内容。
"""
```

## 实施计划

### 阶段一：立即实施（1-2天）
1. 更新提示词模板，添加强制指令
2. 实现智能SQL提取后处理
3. 为每个模型创建优化后的提示词

### 阶段二：中期优化（3-7天）
1. 实现分步骤提示策略
2. 添加更多few-shot示例
3. 开发SQL完整性验证工具

### 阶段三：长期改进（1-2周）
1. 测试其他提示工程策略（思维链、自洽性等）
2. 评估不同模型参数（temperature、max_tokens）
3. 建立持续测试和优化流程

## 预期效果

### qwen3:32b
- 目标通过率：从33%提升至66%+
- 改进重点：复杂查询完整性
- 预期响应时间：保持30-40秒

### qwen3:8b
- 目标通过率：从0%提升至33%+
- 改进重点：指令遵循和SQL提取
- 预期响应时间：保持8-12秒

### qwen3:30b
- 目标通过率：从0%提升至16%+
- 改进重点：表名识别和基本SQL生成
- 预期响应时间：保持6-10秒

## 测试验证方案

### 1. A/B测试设计
- 对照组：当前提示词
- 实验组：优化后提示词
- 测试用例：相同的3个测试用例

### 2. 评估指标
- 通过率（PASS）
- 有效得分（PASS + 0.5×PARTIAL）
- 响应时间
- SQL完整性评分

### 3. 迭代流程
```python
def optimization_iteration():
    # 1. 分析当前问题
    analyze_test_results()

    # 2. 设计优化方案
    design_optimization()

    # 3. 实施测试
    run_optimized_test()

    # 4. 评估效果
    evaluate_improvement()

    # 5. 决定是否继续迭代
    if improvement_significant():
        return "继续优化"
    else:
        return "优化完成"
```

## 风险与缓解

### 风险1：过度优化导致泛化能力下降
- **缓解**：使用多样化的测试用例
- **监控**：定期测试未知查询类型

### 风险2：后处理过于复杂
- **缓解**：保持后处理逻辑简单透明
- **备选**：如效果不佳，回归基础方法

### 风险3：模型更新导致性能变化
- **缓解**：建立基准测试集
- **策略**：每次模型更新后重新测试

## 结论

qwen3系列模型在SQL生成任务上展现出潜力，但需要针对性的优化：
1. **qwen3:32b**：适合深入优化，追求高准确率
2. **qwen3:8b**：适合轻量级优化，平衡速度与准确率
3. **qwen3:30b**：需要基础优化，改善指令遵循

通过系统化的提示词优化、后处理增强和模型特定调优，预期可将总体通过率提升50%以上。