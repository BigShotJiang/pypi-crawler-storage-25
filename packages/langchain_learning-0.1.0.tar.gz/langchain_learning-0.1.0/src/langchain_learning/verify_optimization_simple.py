#!/usr/bin/env python3
"""
简化验证优化效果（只检查3个关键测试用例）
"""
import os
import json
import sys
import time
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import (
    SQLGenerationTesterFullDBOptimized
)

def load_schema():
    """加载数据库schema"""
    schema_file = "data/json/compressed_schema.json"
    with open(schema_file, 'r', encoding='utf-8') as f:
        schema_data = json.load(f)
    return json.dumps(schema_data, ensure_ascii=False)

def manual_evaluate(generated, expected):
    """手动评估SQL（简化版）"""
    if not generated.strip():
        return "FAIL", "empty"

    # 简单检查：是否包含SELECT
    if not generated.strip().upper().startswith('SELECT'):
        return "FAIL", "not_select"

    # 精确匹配
    if generated.strip() == expected.strip():
        return "PASS", "exact"

    # 检查表名是否正确
    # 从预期的8个测试用例中提取表名
    expected_tables = {
        "auto_base_daxueshezhi": ["大学设置", "基本条件"],
        "auto_caiji_chuangxin_team": ["创新团队"],
        "auto_caiji_fuwu_summarykyxmdzjf": ["科研项目", "到账经费"],
        "auto_caiji_guoji_summarylxhb": ["留学湖北", "外国留学生"],
        "auto_caiji_keyanxiangmu": ["科研项目"],
        "auto_caiji_innovationteam": ["创新团队"],
        "auto_caiji_projectgjkypt": ["项目", "经费"]
    }

    # 检查生成的SQL是否包含预期表名
    for table_name, keywords in expected_tables.items():
        if table_name.lower() in generated.lower():
            # 检查是否是正确表名
            for keyword in keywords:
                if keyword in expected:
                    return "PARTIAL", f"contains_table_{table_name}"

    return "FAIL", "wrong_table"

def test_key_queries():
    """测试3个关键查询"""
    print("=" * 80)
    print("简化优化效果验证 (gemma3:27b)")
    print("=" * 80)

    # 加载schema
    print("加载数据库schema...")
    schema_text = load_schema()
    print(f"Schema大小: {len(schema_text)} 字符")

    # 初始化测试器
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url="http://10.254.2.127:8001",
        timeout=120,
        full_schema_text=schema_text
    )

    # 3个关键测试用例
    test_cases = [
        {
            "id": 1,
            "query": "查询大学设置基本条件表的所有记录",
            "expected": "SELECT * FROM auto_base_daxueshezhi",
            "name": "简单SELECT查询"
        },
        {
            "id": 2,
            "query": "查询创新团队表中所属院系为计算机学院的记录",
            "expected": "SELECT * FROM auto_caiji_chuangxin_team WHERE xueyuanname = '计算机学院'",
            "name": "WHERE条件查询"
        },
        {
            "id": 3,
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和，并按照经费总额降序排列",
            "expected": "SELECT xueyuanname, SUM(money_1) as total_money FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanname ORDER BY total_money DESC",
            "name": "GROUP BY聚合查询"
        }
    ]

    test_model = "gemma3:27b"
    print(f"\n测试模型: {test_model}")
    print("-" * 80)

    results = []
    for test_case in test_cases:
        query = test_case["query"]
        expected = test_case["expected"]
        name = test_case["name"]

        print(f"\n测试: {name}")
        print(f"查询: {query}")
        print(f"预期SQL: {expected}")

        try:
            # 生成SQL（单阶段，使用优化后的提示词）
            start_time = time.time()
            raw_response, cleaned_sql, response_time = tester.generate_sql(
                model_name=test_model,
                query=query,
                two_stage=False
            )
            end_time = time.time()
            actual_response_time = end_time - start_time

            print(f"生成的SQL: {cleaned_sql}")
            print(f"响应时间: {response_time:.2f}秒 (实际: {actual_response_time:.2f}秒)")

            # 手动评估
            result, match_type = manual_evaluate(cleaned_sql, expected)
            print(f"评估结果: {result} ({match_type})")

            results.append({
                "id": test_case["id"],
                "name": name,
                "query": query,
                "expected": expected,
                "generated": cleaned_sql,
                "result": result,
                "match_type": match_type,
                "response_time": response_time,
                "actual_response_time": actual_response_time
            })

        except Exception as e:
            print(f"生成SQL时出错: {e}")
            import traceback
            traceback.print_exc()
            results.append({
                "id": test_case["id"],
                "name": name,
                "query": query,
                "expected": expected,
                "generated": "",
                "result": "ERROR",
                "match_type": "error",
                "response_time": 0,
                "actual_response_time": 0
            })

    # 分析结果
    print("\n" + "=" * 80)
    print("验证结果总结")
    print("=" * 80)

    total = len(results)
    passed = sum(1 for r in results if r["result"] == "PASS")
    partial = sum(1 for r in results if r["result"] == "PARTIAL")
    failed = sum(1 for r in results if r["result"] == "FAIL")
    error = sum(1 for r in results if r["result"] == "ERROR")

    passed_rate = passed / total if total > 0 else 0
    partial_rate = partial / total if total > 0 else 0
    avg_time = sum(r["response_time"] for r in results) / total if total > 0 else 0

    print(f"测试总数: {total}")
    print(f"通过: {passed} ({passed_rate*100:.1f}%)")
    print(f"部分通过: {partial} ({partial_rate*100:.1f}%)")
    print(f"失败: {failed} ({failed/total*100 if total>0 else 0:.1f}%)")
    print(f"错误: {error} ({error/total*100 if total>0 else 0:.1f}%)")
    print(f"平均响应时间: {avg_time:.2f}秒")

    # 基准对比
    print("\n" + "=" * 80)
    print("与基准对比")
    print("=" * 80)

    print("基准测试 (gemma3:27b, 优化前):")
    print("  - 响应时间: 69.39秒 (测试用例1-3平均)")
    print("  - 通过率: 12.5% (1/8)")
    print("  - 部分通过率: 12.5%")

    print(f"\n优化后测试:")
    print(f"  - 响应时间: {avg_time:.2f}秒")
    print(f"  - 通过率: {passed_rate:.3f}")
    print(f"  - 部分通过率: {partial_rate:.3f}")

    time_reduction = ((69.39 - avg_time) / 69.39 * 100) if avg_time > 0 else 0
    print(f"\n响应时间减少: {time_reduction:+.1f}%")

    # 表名映射分析
    print("\n" + "=" * 80)
    print("表名映射分析")
    print("=" * 80)

    for result in results:
        if result["generated"]:
            generated = result["generated"].lower()
            expected_table = None

            # 提取预期表名
            if "auto_base_daxueshezhi" in result["expected"].lower():
                expected_table = "auto_base_daxueshezhi"
            elif "auto_caiji_chuangxin_team" in result["expected"].lower():
                expected_table = "auto_caiji_chuangxin_team"
            elif "auto_caiji_fuwu_summarykyxmdzjf" in result["expected"].lower():
                expected_table = "auto_caiji_fuwu_summarykyxmdzjf"

            if expected_table:
                if expected_table in generated:
                    print(f"测试{result['id']}: ✓ 正确表名 {expected_table}")
                else:
                    # 检查使用了什么表名
                    import re
                    table_match = re.search(r'from\s+(\w+)', generated, re.IGNORECASE)
                    if table_match:
                        actual_table = table_match.group(1)
                        print(f"测试{result['id']}: ✗ 错误表名 {actual_table} (应为 {expected_table})")
                    else:
                        print(f"测试{result['id']}: ? 未识别表名")

    return results

if __name__ == "__main__":
    test_key_queries()