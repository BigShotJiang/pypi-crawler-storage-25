#!/usr/bin/env python3
"""重新评估测试结果（使用修复后的比较逻辑）"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

# 导入比较函数（与test_alias_fix.py相同的方式）
import importlib.util
import importlib.machinery

def import_from_file(file_path, function_names):
    """从文件导入指定函数"""
    module_name = os.path.basename(file_path).replace('.py', '').replace('-', '_')
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    functions = {}
    for name in function_names:
        if hasattr(module, name):
            functions[name] = getattr(module, name)
        else:
            raise ImportError(f"函数 {name} 在 {file_path} 中未找到")

    return functions

# 导入所需函数
file_path = os.path.join(os.path.dirname(__file__), "examples", "model-test-lenient.py")
functions = import_from_file(file_path, [
    "clean_sql",
    "compare_sql_semantic",
    "TestResult"
])

clean_sql = functions["clean_sql"]
compare_sql_semantic = functions["compare_sql_semantic"]
TestResult = functions["TestResult"]

def reevaluate_result(generated_sql, expected_sql):
    """重新评估单个测试结果"""
    try:
        if compare_sql_semantic(generated_sql, expected_sql):
            return TestResult.PASS.value
        else:
            return TestResult.FAIL.value
    except Exception as e:
        print(f"比较错误: {e}")
        return TestResult.ERROR.value

def load_results(results_file):
    """加载结果文件"""
    with open(results_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_results(results, output_file):
    """保存结果到文件"""
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

def calculate_model_stats(results):
    """计算模型统计信息"""
    stats = {}

    for result in results:
        model_name = result["model_name"]
        if model_name not in stats:
            stats[model_name] = {
                "total": 0,
                "passed": 0,
                "failed": 0,
                "errors": 0,
                "total_time": 0.0
            }

        stats[model_name]["total"] += 1
        stats[model_name]["total_time"] += result.get("response_time", 0.0)

        if result["result"] == TestResult.PASS.value:
            stats[model_name]["passed"] += 1
        elif result["result"] == TestResult.FAIL.value:
            stats[model_name]["failed"] += 1
        elif result["result"] == TestResult.ERROR.value:
            stats[model_name]["errors"] += 1

    # 计算通过率和平均响应时间
    for model_name, data in stats.items():
        data["passed_rate"] = data["passed"] / data["total"] if data["total"] > 0 else 0
        data["avg_time"] = data["total_time"] / data["total"] if data["total"] > 0 else 0

    return stats

def generate_leaderboard(stats, output_file):
    """生成排行榜"""
    # 按通过率降序排序，如果通过率相同则按平均响应时间升序排序
    sorted_models = sorted(stats.items(), key=lambda x: (-x[1]["passed_rate"], x[1]["avg_time"]))

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("=" * 60 + "\n")
        f.write("本地大模型SQL生成能力排行榜（宽松匹配）- 重新评估\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"匹配规则: 忽略大小写、空格、代码块标记，仅评估SQL语义正确性\n")
        f.write(f"重新评估时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("\n" + "=" * 60 + "\n\n")

        for i, (model_name, data) in enumerate(sorted_models, 1):
            f.write(f"第{i}名: {model_name}\n")
            f.write(f"   通过率: {data['passed_rate']:.2%} ({data['passed']}/{data['total']})\n")
            f.write(f"   平均响应时间: {data['avg_time']:.2f}秒\n")
            f.write("\n")

def generate_summary_report(results, stats, test_cases_file, output_file):
    """生成汇总报告"""
    # 加载测试用例信息（如果有）
    test_cases = []
    if test_cases_file and os.path.exists(test_cases_file):
        with open(test_cases_file, 'r', encoding='utf-8') as f:
            test_cases = json.load(f)

    # 按测试用例ID组织结果
    results_by_test_case = {}
    for result in results:
        test_case_id = result["test_case_id"]
        if test_case_id not in results_by_test_case:
            results_by_test_case[test_case_id] = []
        results_by_test_case[test_case_id].append(result)

    # 按模型组织结果
    results_by_model = {}
    for result in results:
        model_name = result["model_name"]
        if model_name not in results_by_model:
            results_by_model[model_name] = []
        results_by_model[model_name].append(result)

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# SQL生成能力对比汇总报告（重新评估）\n\n")
        f.write(f"原始测试时间: 2026-03-20 08:59:07\n")
        f.write(f"重新评估时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"测试模型数量: {len(stats)}\n")
        f.write(f"测试用例数量: {len(results_by_test_case)}\n")
        f.write(f"评估标准: 宽松语义匹配（忽略大小写、空格、代码块标记）\n")
        f.write(f"修复内容: 表别名标准化（alias.* 与 * 等价）\n\n")

        # 总体表现
        f.write("## 📊 总体表现\n\n")
        f.write("| 模型 | 通过率 | 通过数/总数 | 错误数 | 平均响应时间 |\n")
        f.write("|------|--------|-------------|--------|--------------|\n")

        # 按通过率排序
        sorted_models = sorted(stats.items(), key=lambda x: -x[1]["passed_rate"])
        for model_name, data in sorted_models:
            f.write(f"| {model_name} | {data['passed_rate']:.1%} | {data['passed']}/{data['total']} | "
                    f"{data['errors']} | {data['avg_time']:.2f}秒 |\n")

        f.write("\n---\n\n")

        # 按测试用例对比
        f.write("## 🔍 按测试用例对比\n\n")

        for test_case_id in sorted(results_by_test_case.keys()):
            case_results = results_by_test_case[test_case_id]

            # 查找测试用例信息
            test_case_info = None
            for tc in test_cases:
                if tc.get("id") == test_case_id:
                    test_case_info = tc
                    break

            if test_case_info:
                f.write(f"### 测试用例 {test_case_id}: {test_case_info.get('name', '未知')}\n\n")
                f.write(f"**难度**: {test_case_info.get('difficulty', 'basic')}\n\n")
                f.write(f"**自然语言查询**: {test_case_info.get('natural_language_query', '')}\n\n")
                f.write(f"**预期SQL**: `{test_case_info.get('expected_sql', '')}`\n\n")
            else:
                f.write(f"### 测试用例 {test_case_id}\n\n")

            f.write("| 模型 | 结果 | 生成的SQL | 响应时间 |\n")
            f.write("|------|------|-----------|----------|\n")

            # 按模型名排序
            case_results.sort(key=lambda r: r["model_name"])

            for result in case_results:
                # 清理SQL用于显示
                cleaned_sql = clean_sql(result["generated_sql"])
                if len(cleaned_sql) > 100:
                    display_sql = cleaned_sql[:97] + "..."
                else:
                    display_sql = cleaned_sql

                result_symbol = "✅" if result["result"] == TestResult.PASS.value else "❌"
                if result["result"] == TestResult.ERROR.value:
                    result_symbol = "⚠️"
                    error_msg = result.get("error_message", "")
                    if error_msg:
                        display_sql = f"错误: {error_msg[:50]}..."

                f.write(f"| {result['model_name']} | {result_symbol} | `{display_sql}` | {result.get('response_time', 0):.2f}秒 |\n")

            f.write("\n")

        f.write("---\n\n")

        # 按模型分析
        f.write("## 🏆 按模型分析\n\n")

        for model_name, data in sorted(stats.items(), key=lambda x: -x[1]["passed_rate"]):
            f.write(f"### 模型: {model_name}\n\n")
            f.write(f"**总体表现**: {data['passed']}/{data['total']} 通过 ({data['passed_rate']:.1%})\n\n")
            f.write(f"**平均响应时间**: {data['avg_time']:.2f}秒\n\n")

            # 具体测试结果
            model_results = results_by_model.get(model_name, [])
            if model_results:
                f.write("**具体测试结果**:\n\n")
                f.write("| 测试用例 | 结果 | 生成的SQL |\n")
                f.write("|----------|------|-----------|\n")

                # 按测试用例ID排序
                model_results.sort(key=lambda r: r["test_case_id"])

                for result in model_results:
                    test_case_id = result["test_case_id"]

                    # 查找测试用例名称
                    tc_name = f"测试用例 {test_case_id}"
                    for tc in test_cases:
                        if tc.get("id") == test_case_id:
                            tc_name = tc.get("name", tc_name)
                            break

                    # 清理SQL
                    cleaned_sql = clean_sql(result["generated_sql"])
                    if len(cleaned_sql) > 80:
                        display_sql = cleaned_sql[:77] + "..."
                    else:
                        display_sql = cleaned_sql

                    result_symbol = "✅" if result["result"] == TestResult.PASS.value else "❌"
                    if result["result"] == TestResult.ERROR.value:
                        result_symbol = "⚠️"
                        error_msg = result.get("error_message", "")
                        if error_msg:
                            display_sql = f"错误: {error_msg[:30]}..."

                    f.write(f"| {tc_name} | {result_symbol} | `{display_sql}` |\n")

            f.write("\n")

        f.write("---\n\n")

        # 分析总结
        f.write("## 📈 分析总结\n\n")

        if stats:
            best_model = max(stats.items(), key=lambda x: x[1]["passed_rate"])
            worst_model = min(stats.items(), key=lambda x: x[1]["passed_rate"])

            f.write(f"**最佳模型**: {best_model[0]} ({best_model[1]['passed_rate']:.1%} 通过率)\n\n")
            f.write(f"**最差模型**: {worst_model[0]} ({worst_model[1]['passed_rate']:.1%} 通过率)\n\n")

        f.write("**修复说明**:\n")
        f.write("1. 修复了表别名标准化问题：`alias.*` 现在与 `*` 视为语义等价\n")
        f.write("2. 此修复主要影响测试用例7（子查询），其中 `SELECT s.* FROM students s` 与 `SELECT * FROM students` 现在视为等价\n")
        f.write("3. 其他测试用例不受影响或影响较小\n\n")

        f.write("*报告生成时间: " + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "*\n")

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法: python reevaluate_results.py <结果文件> [测试用例文件]")
        print("示例: python reevaluate_results.py results/latest_test_20260320_085133/sql_test_lenient_results_20260320_085907.json")
        sys.exit(1)

    results_file = sys.argv[1]
    test_cases_file = sys.argv[2] if len(sys.argv) > 2 else None

    if not os.path.exists(results_file):
        print(f"错误: 结果文件不存在: {results_file}")
        sys.exit(1)

    print(f"加载结果文件: {results_file}")
    results = load_results(results_file)
    print(f"加载了 {len(results)} 条结果记录")

    # 重新评估每条结果
    print("重新评估结果中...")
    changed_count = 0
    for i, result in enumerate(results):
        original_result = result["result"]
        new_result = reevaluate_result(result["generated_sql"], result["expected_sql"])

        if new_result != original_result:
            result["result"] = new_result
            changed_count += 1
            print(f"  结果 {i+1} 改变: {original_result} -> {new_result}")
            print(f"    模型: {result['model_name']}, 测试用例: {result['test_case_id']}")
            print(f"    生成SQL: {result['generated_sql'][:100]}...")

    print(f"重新评估完成: {changed_count}/{len(results)} 条结果发生改变")

    # 创建输出目录
    output_dir = "results/reevaluated_" + datetime.now().strftime("%Y%m%d_%H%M%S")
    os.makedirs(output_dir, exist_ok=True)

    # 保存重新评估后的结果
    output_results_file = os.path.join(output_dir, "sql_test_lenient_results_reevaluated.json")
    save_results(results, output_results_file)
    print(f"保存重新评估结果到: {output_results_file}")

    # 计算统计信息
    stats = calculate_model_stats(results)

    # 生成排行榜
    leaderboard_file = os.path.join(output_dir, "sql_test_lenient_leaderboard_reevaluated.txt")
    generate_leaderboard(stats, leaderboard_file)
    print(f"生成排行榜到: {leaderboard_file}")

    # 生成汇总报告
    summary_file = os.path.join(output_dir, "sql_test_lenient_summary_reevaluated.md")
    generate_summary_report(results, stats, test_cases_file, summary_file)
    print(f"生成汇总报告到: {summary_file}")

    # 显示排行榜
    print("\n" + "=" * 60)
    print("重新评估后的排行榜")
    print("=" * 60)
    sorted_models = sorted(stats.items(), key=lambda x: (-x[1]["passed_rate"], x[1]["avg_time"]))
    for i, (model_name, data) in enumerate(sorted_models, 1):
        print(f"{i}. {model_name}: {data['passed_rate']:.2%} ({data['passed']}/{data['total']}), "
              f"平均响应时间: {data['avg_time']:.2f}秒")

    print(f"\n所有输出已保存到目录: {output_dir}")

if __name__ == "__main__":
    main()