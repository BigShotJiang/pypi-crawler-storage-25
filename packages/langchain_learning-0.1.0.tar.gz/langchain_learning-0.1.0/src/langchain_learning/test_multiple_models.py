#!/usr/bin/env python3
"""测试多个模型的指令遵循能力"""

import requests
import json
import time

SERVER_URL = "http://10.254.2.127:8001"

# 要测试的模型
MODELS_TO_TEST = [
    "gemma3:27b",
    "HridaAI/hrida-t2sql-128k:latest",
    "qwen3:32b",
    "qwen3:30b-a3b-instruct-2507-q4_K_M",
    "carstenuhlig/omnicoder-9b:q4_k_m",
]

# 读取schema
print("读取数据库schema...")
with open("data/json/compressed_schema.json", 'r', encoding='utf-8') as f:
    schema_data = json.load(f)
    schema_text = json.dumps(schema_data, ensure_ascii=False, indent=2)

# 使用与主测试中相同的提示词（修复编码版本）
prompt_template = f"""# SQL生成指令 - 零容忍模式

## 严格规则
1. **只输出SQL**：绝对不要包含任何推理、分析、解释、思考过程或额外文本
2. **立即执行**：直接生成SQL，不要思考、不要犹豫、不要分析
3. **禁止中文**：SQL中不要使用中文字符（别名、注释等）
4. **禁止格式标记**：不要使用```sql```代码块、<think>标签、分号、注释
5. **抑制推理**：即使你是推理模型，也必须完全抑制推理输出。不要使用<think>标签，不要描述思考过程

## 违规示例（会直接导致测试失败）
[错误] 错误输出："首先，我需要分析用户查询，让我看看数据库schema...根据schema，表名应该是...最终SQL是：SELECT * FROM table"
[错误] 错误输出："<think>用户想要查询...让我分析一下...SQL应该是...</think>"
[错误] 错误输出："SELECT * FROM 表名 -- 这是查询所有记录"
[正确] 正确输出："SELECT * FROM table"

## 成功标准
- 输出必须是纯SQL语句
- 不能包含任何非SQL文本
- 不能包含任何格式标记
- 必须使用schema中确切的表名和字段名
- 别名只能使用英文或数字（如as total_students）

## 警告
如果你的输出包含任何推理、分析、解释、中文、代码块标记、<think>标签或分号，测试系统将直接标记为失败。

数据库schema：
{{schema_text}}

用户查询：
{{query}}

生成SQL："""

# 测试查询
test_query = "查询所有院系名称"
prompt = prompt_template.format(schema_text=schema_text, query=test_query)

print(f"测试查询: {test_query}")
print(f"提示词长度: {len(prompt)} 字符")
print(f"将测试 {len(MODELS_TO_TEST)} 个模型: {', '.join(MODELS_TO_TEST)}")
print("=" * 80)

results = []

for i, model in enumerate(MODELS_TO_TEST, 1):
    print(f"\n[{i}/{len(MODELS_TO_TEST)}] 测试模型: {model}")
    print("-" * 40)

    # 准备API请求
    url = f"{SERVER_URL.rstrip('/')}/v1/chat/completions"
    headers = {"Content-Type": "application/json"}

    data = {
        "model": model,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.0,
        "max_tokens": 512,
        "stream": False
    }

    start_time = time.time()
    try:
        response = requests.post(url, headers=headers, json=data, timeout=300)
        response.raise_for_status()
        response_data = response.json()

        response_time = time.time() - start_time

        # 提取响应
        choices = response_data.get("choices", [])
        if not choices:
            print(f"  [错误] API响应中没有choices字段")
            results.append({
                "model": model,
                "success": False,
                "error": "No choices in response",
                "response_time": response_time
            })
            continue

        message = choices[0].get("message", {})
        raw_response = message.get("content", "")

        print(f"  响应时间: {response_time:.2f}秒")
        print(f"  响应长度: {len(raw_response)} 字符")
        print(f"  响应内容: {repr(raw_response[:200])}")

        # 分析响应
        contains_chinese = any('\u4e00' <= c <= '\u9fff' for c in raw_response)
        contains_think = '<think>' in raw_response.lower()
        contains_explanation = any(word in raw_response.lower() for word in ['首先', '然后', '需要', '应该', '让我', '分析', '思考', '推理'])
        contains_code_block = '```' in raw_response
        starts_with_select = raw_response.strip().upper().startswith('SELECT')

        print(f"  分析结果:")
        print(f"    - 包含中文: {contains_chinese}")
        print(f"    - 包含<think>: {contains_think}")
        print(f"    - 包含解释文本: {contains_explanation}")
        print(f"    - 包含代码块标记: {contains_code_block}")
        print(f"    - 以SELECT开头: {starts_with_select}")

        # 判断是否遵循指令
        follows_instructions = (starts_with_select and
                               not contains_chinese and
                               not contains_think and
                               not contains_explanation and
                               not contains_code_block)

        if follows_instructions:
            print(f"  [成功] 模型成功遵循指令: 输出纯SQL")
        else:
            print(f"  [失败] 模型未遵循指令")

        results.append({
            "model": model,
            "success": True,
            "follows_instructions": follows_instructions,
            "response_time": response_time,
            "response_length": len(raw_response),
            "contains_chinese": contains_chinese,
            "contains_think": contains_think,
            "contains_explanation": contains_explanation,
            "contains_code_block": contains_code_block,
            "starts_with_select": starts_with_select,
            "raw_response_preview": raw_response[:200]
        })

    except Exception as e:
        response_time = time.time() - start_time
        print(f"  [错误] 请求失败: {e}")
        results.append({
            "model": model,
            "success": False,
            "error": str(e),
            "response_time": response_time
        })

    # 在模型之间添加延迟
    if i < len(MODELS_TO_TEST):
        delay = 10
        print(f"\n  等待 {delay} 秒后测试下一个模型...")
        time.sleep(delay)

# 打印汇总结果
print(f"\n{'='*80}")
print("测试完成汇总")
print("=" * 80)

successful_tests = [r for r in results if r.get("success", False)]
failed_tests = [r for r in results if not r.get("success", False)]

print(f"总测试模型: {len(results)}")
print(f"成功测试: {len(successful_tests)}")
print(f"失败测试: {len(failed_tests)}")

print(f"\n指令遵循情况:")
for result in successful_tests:
    status = "[遵循]" if result.get("follows_instructions", False) else "[未遵循]"
    issues = []
    if result.get("contains_chinese", False):
        issues.append("中文")
    if result.get("contains_think", False):
        issues.append("<think>标签")
    if result.get("contains_explanation", False):
        issues.append("解释文本")
    if result.get("contains_code_block", False):
        issues.append("代码块标记")

    issue_text = f" ({', '.join(issues)})" if issues else ""
    print(f"  {status} {result['model']}: {result['response_time']:.1f}秒{issue_text}")

if failed_tests:
    print(f"\n失败的测试:")
    for result in failed_tests:
        print(f"  - {result['model']}: {result.get('error', '未知错误')}")

# 保存结果
timestamp = time.strftime("%Y%m%d_%H%M%S")
output_file = f"model_instruction_test_results_{timestamp}.json"
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump({
        "timestamp": timestamp,
        "server_url": SERVER_URL,
        "test_query": test_query,
        "results": results
    }, f, ensure_ascii=False, indent=2)

print(f"\n结果已保存到: {output_file}")