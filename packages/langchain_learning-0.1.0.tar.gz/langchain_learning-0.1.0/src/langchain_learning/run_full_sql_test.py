#!/usr/bin/env python3
"""运行完整SQL生成能力测试（所有模型）"""

import os
import sys
import json
import time
import subprocess
from datetime import datetime

def run_command(cmd):
    """运行命令并返回输出"""
    print(f"执行命令: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"命令失败 (退出码: {result.returncode})")
        print(f"标准错误: {result.stderr}")
    return result

def main():
    print("=" * 80)
    print("本地大模型SQL生成能力完整测试")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    # 检查文件存在
    schema_file = "data/json/compressed_schema.json"
    test_cases_file = "test_cases_complex.json"

    if not os.path.exists(schema_file):
        print(f"错误: schema文件不存在: {schema_file}")
        sys.exit(1)

    if not os.path.exists(test_cases_file):
        print(f"错误: 测试用例文件不存在: {test_cases_file}")
        sys.exit(1)

    # 检查文件大小
    schema_size = os.path.getsize(schema_file)
    print(f"Schema文件大小: {schema_size:,} 字节 ({schema_size/1024:.1f} KB)")

    with open(test_cases_file, 'r', encoding='utf-8') as f:
        test_cases = json.load(f)
    print(f"测试用例数量: {len(test_cases)}")

    # 创建输出目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = f"full_db_all_models_complex_test_{timestamp}"
    os.makedirs(output_dir, exist_ok=True)
    print(f"输出目录: {output_dir}")

    # 保存配置信息
    config = {
        "timestamp": timestamp,
        "schema_file": schema_file,
        "test_cases_file": test_cases_file,
        "output_dir": output_dir,
        "server_url": "http://10.254.2.99:8001",
        "timeout": 1200,  # 20分钟超时
        "gpu": "Tesla V100-SXM2-32GB"
    }

    config_file = os.path.join(output_dir, "test_config.json")
    with open(config_file, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)

    print(f"配置已保存: {config_file}")

    # 构建命令
    cmd = [
        "python", "examples/model_sql_comprehensive_test_full_db_optimized.py",
        "--ollama-url", "http://10.254.2.99:8001",
        "--schema-file", schema_file,
        "--test-cases", test_cases_file,
        "--timeout", "1200",
        "--output-dir", output_dir
    ]

    cmd_str = " ".join(cmd)

    print(f"\n将要执行的命令:")
    print(f"{cmd_str}")

    # 确认
    print(f"\n警告: 这将测试服务器上所有可用模型")
    print(f"预计测试时间: 8个模型 × 8个测试用例 = 64次测试")
    print(f"假设每次测试平均2-3分钟，总时间约2-4小时")
    print(f"V100显卡显存: 32GB，将逐个测试并卸载模型")
    print(f"超时设置: 1200秒 (20分钟) 每次请求")

    # 询问是否继续
    response = input("\n是否开始测试？(y/N): ")
    if response.lower() != 'y':
        print("取消测试")
        sys.exit(0)

    print(f"\n开始测试...")

    # 运行测试
    start_time = time.time()
    result = run_command(cmd_str)
    end_time = time.time()
    total_time = end_time - start_time

    print(f"\n测试完成!")
    print(f"总运行时间: {total_time:.2f}秒 ({total_time/3600:.2f}小时)")

    # 保存结果摘要
    summary = {
        "start_time": start_time,
        "end_time": end_time,
        "total_time": total_time,
        "command": cmd_str,
        "returncode": result.returncode,
        "output_dir": output_dir
    }

    summary_file = os.path.join(output_dir, "test_summary.json")
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(f"\n结果目录: {output_dir}")
    print(f"测试摘要: {summary_file}")

    if result.returncode == 0:
        print("测试成功完成!")
    else:
        print(f"测试失败 (退出码: {result.returncode})")
        print(f"请检查日志文件")

if __name__ == "__main__":
    main()