#!/usr/bin/env python3
"""检查compressed_schema.json文件结构"""

import json
import os

def main():
    file_path = "data/json/compressed_schema.json"

    if not os.path.exists(file_path):
        print(f"文件不存在: {file_path}")
        return

    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    print(f"压缩schema文件结构检查")
    print(f"文件大小: {os.path.getsize(file_path):,} 字节")

    if "themes" in data:
        themes = data.get("themes", [])
        print(f"\n主题数量: {len(themes)}")

        total_tables = 0
        for i, theme in enumerate(themes, 1):
            theme_name = theme.get("name", "未知")
            theme_desc = theme.get("description", "")
            tables = theme.get("tables", [])
            table_count = len(tables)
            total_tables += table_count

            print(f"\n主题 {i}: {theme_name}")
            print(f"  描述: {theme_desc}")
            print(f"  表数量: {table_count}")

            # 显示前3个表
            if tables:
                print(f"  前3个表:")
                for j, table in enumerate(tables[:3], 1):
                    table_label = table.get("label", "")
                    original_name = table.get("original_name", "")
                    key_fields = table.get("key_fields", [])
                    print(f"    {j}. {table_label} ({original_name}) - {len(key_fields)}个关键字段")

        print(f"\n总计: {total_tables} 个表")

        # 计算字符数
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            char_count = len(content)
            print(f"\n文件字符数: {char_count:,} (约{char_count/1024:.1f} KB)")

        # 显示所有主题名称
        print(f"\n所有主题:")
        for i, theme in enumerate(themes, 1):
            theme_name = theme.get("name", "")
            tables = theme.get("tables", [])
            print(f"  {i}. {theme_name} ({len(tables)}表)")

    else:
        print("不是压缩schema格式（缺少'themes'字段）")
        print(f"JSON键: {list(data.keys())}")

    # 检查测试用例文件
    test_cases_file = "test_cases_complex.json"
    if os.path.exists(test_cases_file):
        with open(test_cases_file, 'r', encoding='utf-8') as f:
            test_cases = json.load(f)
        print(f"\n测试用例文件: {test_cases_file}")
        print(f"测试用例数量: {len(test_cases)}")
        print(f"难度分布:")
        difficulties = {}
        for tc in test_cases:
            diff = tc.get("difficulty", "basic")
            difficulties[diff] = difficulties.get(diff, 0) + 1
        for diff, count in difficulties.items():
            print(f"  {diff}: {count}个")
    else:
        print(f"\n警告: 测试用例文件 {test_cases_file} 不存在")

if __name__ == "__main__":
    main()