#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
汇总所有模型测试结果并生成最终报告
"""

import os
import re
import json
from datetime import datetime
from typing import List, Dict, Tuple

def parse_leaderboard_file(file_path: str) -> Dict:
    """解析排行榜文件，提取模型信息"""
    if not os.path.exists(file_path):
        return None

    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    result = {
        'model_name': '',
        'pass_rate': 0.0,
        'partial_rate': 0.0,
        'total_score': 0.0,
        'avg_response_time': 0.0,
        'total_response_time': 0.0,
        'test_cases': 0,
        'total_tests': 0,
        'test_time': ''
    }

    # 提取模型名称
    model_match = re.search(r'第1名:\s*([^\n]+)', content)
    if model_match:
        result['model_name'] = model_match.group(1).strip()

    # 提取通过率
    pass_match = re.search(r'通过率:\s*([\d.]+)%\s*\((\d+)/(\d+)\)', content)
    if pass_match:
        result['pass_rate'] = float(pass_match.group(1))
        result['total_tests'] = int(pass_match.group(3))

    # 提取部分通过率
    partial_match = re.search(r'部分通过率:\s*([\d.]+)%\s*\((\d+)/(\d+)\)', content)
    if partial_match:
        result['partial_rate'] = float(partial_match.group(1))

    # 提取综合得分
    score_match = re.search(r'综合得分:\s*([\d.]+)%', content)
    if score_match:
        result['total_score'] = float(score_match.group(1))

    # 提取平均响应时间
    time_match = re.search(r'平均响应时间:\s*([\d.]+)秒', content)
    if time_match:
        result['avg_response_time'] = float(time_match.group(1))

    # 提取总响应时间
    total_time_match = re.search(r'总响应时间:\s*([\d.]+)秒', content)
    if total_time_match:
        result['total_response_time'] = float(total_time_match.group(1))

    # 提取测试用例总数
    case_match = re.search(r'测试用例总数:\s*(\d+)', content)
    if case_match:
        result['test_cases'] = int(case_match.group(1))

    # 提取测试时间
    time_match = re.search(r'测试时间:\s*([^\n]+)', content)
    if time_match:
        result['test_time'] = time_match.group(1).strip()

    return result

def collect_all_results() -> List[Dict]:
    """收集所有模型的结果"""
    result_dirs = [
        'phase1_results_qwen8b',
        'phase1_results_qwen14b',
        'phase1_results_deepseek14b',
        'phase2_results_gemma27b',
        'phase2_results_glm_flash',
        'phase3_results_qwen30b',
        'phase3_results_qwen32b'
    ]

    all_results = []

    for dir_name in result_dirs:
        leaderboard_pattern = os.path.join(dir_name, 'sql_test_leaderboard_*.txt')
        import glob
        files = glob.glob(leaderboard_pattern)

        if not files:
            print(f"警告: 在目录 {dir_name} 中未找到排行榜文件")
            continue

        # 使用最新的文件
        latest_file = max(files, key=os.path.getctime)
        result = parse_leaderboard_file(latest_file)

        if result:
            # 从目录名提取模型类型信息
            if 'qwen8b' in dir_name:
                result['model_type'] = 'qwen3:8b'
            elif 'qwen14b' in dir_name:
                result['model_type'] = 'qwen3:14b'
            elif 'deepseek' in dir_name:
                result['model_type'] = 'deepseek-r1:14b'
            elif 'gemma' in dir_name:
                result['model_type'] = 'gemma3:27b'
            elif 'glm' in dir_name:
                result['model_type'] = 'glm-4.7-flash:q4_K_M'
            elif 'qwen30b' in dir_name:
                result['model_type'] = 'qwen3:30b'
            elif 'qwen32b' in dir_name:
                result['model_type'] = 'qwen3:32b'
            else:
                result['model_type'] = result['model_name']

            all_results.append(result)

    return all_results

def generate_report(results: List[Dict]) -> str:
    """生成最终报告"""
    report = []

    # 标题
    report.append("# 本地大模型SQL生成能力测试最终报告")
    report.append("")
    report.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("测试服务器: http://10.254.2.99:8001")
    report.append("数据库schema: mini_schema.json (1个主题，包含测试用例相关表)")
    report.append("测试用例: 2个简单查询 (test_cases_simple.json)")
    report.append("")

    # 按综合得分排序
    sorted_results = sorted(results, key=lambda x: (-x['total_score'], x['avg_response_time']))

    # 汇总表格
    report.append("## 模型性能排行榜")
    report.append("")
    report.append("| 排名 | 模型名称 | 综合得分 | 通过率 | 部分通过率 | 平均响应时间(秒) | 总响应时间(秒) | 测试用例数 |")
    report.append("|------|----------|----------|--------|------------|------------------|----------------|------------|")

    for i, result in enumerate(sorted_results, 1):
        report.append(f"| {i} | {result['model_name']} | {result['total_score']:.2f}% | {result['pass_rate']:.2f}% | {result['partial_rate']:.2f}% | {result['avg_response_time']:.2f} | {result['total_response_time']:.2f} | {result['test_cases']} |")

    report.append("")

    # 详细分析
    report.append("## 详细分析")
    report.append("")

    # 按模型大小分组
    report.append("### 1. 按模型大小分组")
    report.append("")
    report.append("| 模型大小 | 模型 | 综合得分 | 平均响应时间 |")
    report.append("|----------|------|----------|--------------|")

    # 小模型 (<10B)
    small_models = [r for r in results if '8b' in r['model_type'].lower()]
    for model in small_models:
        report.append(f"| 小模型 (8B) | {model['model_name']} | {model['total_score']:.2f}% | {model['avg_response_time']:.2f}秒 |")

    # 中模型 (14B-27B)
    medium_models = [r for r in results if any(x in r['model_type'].lower() for x in ['14b', '27b'])]
    for model in medium_models:
        size = '14B' if '14b' in model['model_type'].lower() else '27B'
        report.append(f"| 中模型 ({size}) | {model['model_name']} | {model['total_score']:.2f}% | {model['avg_response_time']:.2f}秒 |")

    # 大模型 (30B+)
    large_models = [r for r in results if any(x in r['model_type'].lower() for x in ['30b', '32b'])]
    for model in large_models:
        size = '30B' if '30b' in model['model_type'].lower() else '32B'
        report.append(f"| 大模型 ({size}) | {model['model_name']} | {model['total_score']:.2f}% | {model['avg_response_time']:.2f}秒 |")

    report.append("")

    # 性能分析
    report.append("### 2. 关键发现")
    report.append("")

    # 找出最佳模型
    best_model = sorted_results[0]
    report.append(f"1. **最佳表现模型**: {best_model['model_name']} (综合得分: {best_model['total_score']:.2f}%)")

    # 找出最快模型
    fastest_model = min(results, key=lambda x: x['avg_response_time'])
    report.append(f"2. **最快模型**: {fastest_model['model_name']} (平均响应时间: {fastest_model['avg_response_time']:.2f}秒)")

    # 统计完美模型
    perfect_models = [r for r in results if r['total_score'] >= 99.99]
    report.append(f"3. **完美表现模型**: {len(perfect_models)}个 ({', '.join([m['model_name'] for m in perfect_models])})")

    # 推理模型问题
    reasoning_models = [r for r in results if r['pass_rate'] < 100 and 'not_sql' in str(r)]
    report.append(f"4. **推理模型问题**: {len(reasoning_models)}个模型因返回推理内容而非纯SQL导致测试失败")

    report.append("")
    report.append("### 3. 测试配置")
    report.append("")
    report.append("- **测试框架**: model_sql_comprehensive_test_full_db_optimized.py")
    report.append("- **评估方法**: 精确匹配 + 清洗后匹配 + 标准化匹配 + 语义相似度")
    report.append("- **部分匹配阈值**: 70%关键元素匹配")
    report.append("- **超时设置**: 120-300秒（根据模型大小调整）")
    report.append("- **提示词策略**: 强制只输出SQL，禁止推理过程")
    report.append("")

    # 结论
    report.append("## 结论与建议")
    report.append("")
    report.append("1. **qwen3:8b和qwen3:32b表现最佳**，在两个测试用例上都获得100%通过率")
    report.append("2. **模型大小不一定决定SQL生成能力**，8B模型表现优于部分14B/30B模型")
    report.append("3. **推理模型（qwen3:14b/30b, glm-4.7-flash）存在格式遵循问题**，倾向于输出推理过程而非纯SQL")
    report.append("4. **gemma3:27b表现优异**，在27B规模模型中表现最佳")
    report.append("5. **响应时间与模型大小正相关**，但qwen3:30b意外地比qwen3:14b更快")
    report.append("")
    report.append("**推荐模型**: 对于生产环境SQL生成任务，推荐使用 **qwen3:8b**（平衡性能与速度）或 **gemma3:27b**（更高准确率需求）。")

    return "\n".join(report)

def main():
    """主函数"""
    print("正在收集所有模型测试结果...")
    results = collect_all_results()

    if not results:
        print("错误: 未找到任何测试结果")
        return

    print(f"成功收集 {len(results)} 个模型的结果")

    # 生成报告
    report = generate_report(results)

    # 保存报告
    output_file = "final_sql_test_report.md"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(report)

    print(f"报告已保存到: {output_file}")

    # 同时在控制台显示摘要
    print("\n" + "="*80)
    print("SQL生成能力测试摘要")
    print("="*80)

    sorted_results = sorted(results, key=lambda x: (-x['total_score'], x['avg_response_time']))
    for i, result in enumerate(sorted_results, 1):
        print(f"{i}. {result['model_name']:30} 得分: {result['total_score']:6.2f}%  通过: {result['pass_rate']:5.2f}%  时间: {result['avg_response_time']:6.2f}秒")

if __name__ == "__main__":
    main()