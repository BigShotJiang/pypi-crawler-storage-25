#!/usr/bin/env python3
"""简化版SQL生成测试"""

import time
import json
import requests
from typing import List, Tuple

def get_ollama_models(base_url: str = "http://10.254.2.99:8001") -> List[str]:
    """获取Ollama服务器上的所有模型"""
    try:
        response = requests.get(f"{base_url}/v1/models", timeout=10)
        if response.status_code == 200:
            models = response.json().get("data", [])
            return [model.get("id") for model in models if model.get("id")]
        return []
    except Exception as e:
        print(f"获取模型列表失败: {e}")
        return []

def generate_sql_simple(model_name: str, query: str, schema_text: str = None) -> Tuple[str, float]:
    """生成SQL语句（简化版）"""

    # 简化的schema，只包含几个关键表
    if not schema_text:
        schema_text = """数据库表结构：
1. auto_base_daxueshezhi (大学设置基本条件表)
   - zongguimo: INT (总规模)
   - yanjiusheng: INT (研究生)
   - zhishaoyou5jieshuoshiyanjiusheng: NVARCHAR(n) (至少拥有5届硕士研究生)

2. auto_caiji_chuangxin_team (创新团队表)
   - year: NVARCHAR(n) (年度)
   - name: NVARCHAR(n) (团队名称)
   - level: NVARCHAR(n) (级别)

3. auto_caiji_fuwu_summarykyxmdzjf (科研项目到账经费表)
   - xueyuanName: NVARCHAR(n) (所属院系)
   - money_1: DECIMAL (纵向项目到账经费)
   - year: NVARCHAR(n) (年度)
"""

    prompt = f"""根据以下数据库表结构和自然语言查询，生成正确的SQL语句。

只生成纯SQL语句，不要有任何额外的解释、注释或文本。

数据库表结构：
{schema_text}

自然语言查询：
{query}

SQL语句："""

    # 使用OpenAI兼容API
    url = "http://10.254.2.99:8001/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "model": model_name,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.0,
        "max_tokens": 512,
        "stream": False
    }

    start_time = time.time()
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        response_time = time.time() - start_time

        if response.status_code == 200:
            result = response.json()
            content = result.get("choices", [{}])[0].get("message", {}).get("content", "").strip()

            # 清理响应
            if content.startswith("```sql"):
                content = content[6:]
            if content.startswith("```"):
                content = content[3:]
            if content.endswith("```"):
                content = content[:-3]

            return content, response_time
        else:
            error_msg = f"HTTP {response.status_code}: {response.text}"
            return f"ERROR: {error_msg}", response_time

    except Exception as e:
        response_time = time.time() - start_time
        return f"ERROR: {str(e)}", response_time

def run_test_suite():
    """运行测试套件"""

    print("=" * 80)
    print("简化版SQL生成能力测试")
    print("=" * 80)

    # 获取模型列表
    models = get_ollama_models()
    if not models:
        print("没有找到可用模型")
        return

    print(f"找到 {len(models)} 个模型:")
    for i, model in enumerate(models, 1):
        print(f"  {i}. {model}")

    # 测试用例
    test_cases = [
        {
            "id": 1,
            "name": "简单SELECT查询",
            "query": "查询大学设置基本条件表的所有记录",
            "expected": "SELECT * FROM auto_base_daxueshezhi"
        },
        {
            "id": 2,
            "name": "带WHERE条件的查询",
            "query": "查询创新团队表中年度为2023的记录",
            "expected": "SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'"
        },
        {
            "id": 3,
            "name": "聚合查询",
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
            "expected": "SELECT xueyuanName, SUM(money_1) as total_money_1 FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName"
        }
    ]

    print(f"\n测试用例 ({len(test_cases)} 个):")
    for case in test_cases:
        print(f"  {case['id']}. {case['name']}: {case['query']}")

    # 运行测试
    results = []

    for model_idx, model_name in enumerate(models, 1):
        print(f"\n[{model_idx}/{len(models)}] 测试模型: {model_name}")

        for case in test_cases:
            print(f"  测试用例 {case['id']}: {case['name']}...", end="", flush=True)

            sql, resp_time = generate_sql_simple(model_name, case["query"])

            # 评估结果（简单匹配）
            if sql.startswith("ERROR:"):
                result = "ERROR"
            elif sql.strip() == case["expected"].strip():
                result = "PASS"
            else:
                result = "FAIL"

            results.append({
                "model": model_name,
                "test_case_id": case["id"],
                "test_case_name": case["name"],
                "query": case["query"],
                "expected_sql": case["expected"],
                "generated_sql": sql,
                "result": result,
                "response_time": resp_time
            })

            print(f" {result} ({resp_time:.2f}s)")

    # 保存结果
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    output_file = f"sql_test_simple_results_{timestamp}.json"

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # 计算统计
    model_stats = {}
    for result in results:
        model = result["model"]
        if model not in model_stats:
            model_stats[model] = {"total": 0, "passed": 0, "total_time": 0.0}

        model_stats[model]["total"] += 1
        model_stats[model]["total_time"] += result["response_time"]

        if result["result"] == "PASS":
            model_stats[model]["passed"] += 1

    # 显示排行榜
    print("\n" + "=" * 80)
    print("排行榜")
    print("=" * 80)

    sorted_models = sorted(
        model_stats.items(),
        key=lambda x: (x[1]["passed"] / x[1]["total"], -x[1]["total_time"] / x[1]["total"]),
        reverse=True
    )

    for i, (model_name, stats) in enumerate(sorted_models, 1):
        passed_rate = stats["passed"] / stats["total"] if stats["total"] > 0 else 0
        avg_time = stats["total_time"] / stats["total"] if stats["total"] > 0 else 0

        print(f"{i}. {model_name}")
        print(f"   通过率: {passed_rate:.2%} ({stats['passed']}/{stats['total']})")
        print(f"   平均响应时间: {avg_time:.2f}秒")

    # 生成详细报告
    report_file = f"sql_test_simple_report_{timestamp}.txt"
    with open(report_file, "w", encoding="utf-8") as f:
        f.write("简化版SQL生成能力测试报告\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"测试时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"服务器地址: http://10.254.2.99:8001\n")
        f.write(f"测试模型数: {len(models)}\n")
        f.write(f"测试用例数: {len(test_cases)}\n\n")

        f.write("模型排名:\n")
        f.write("-" * 80 + "\n")
        for i, (model_name, stats) in enumerate(sorted_models, 1):
            passed_rate = stats["passed"] / stats["total"] if stats["total"] > 0 else 0
            avg_time = stats["total_time"] / stats["total"] if stats["total"] > 0 else 0

            f.write(f"第{i}名: {model_name}\n")
            f.write(f"  通过率: {passed_rate:.2%} ({stats['passed']}/{stats['total']})\n")
            f.write(f"  平均响应时间: {avg_time:.2f}秒\n\n")

        f.write("\n详细结果:\n")
        f.write("=" * 80 + "\n")
        for model_name in models:
            f.write(f"\n{model_name}:\n")
            f.write("-" * 40 + "\n")

            model_results = [r for r in results if r["model"] == model_name]
            for result in sorted(model_results, key=lambda x: x["test_case_id"]):
                f.write(f"测试用例 {result['test_case_id']}: {result['test_case_name']}\n")
                f.write(f"  查询: {result['query']}\n")
                f.write(f"  预期SQL: {result['expected_sql']}\n")
                f.write(f"  生成SQL: {result['generated_sql']}\n")
                f.write(f"  结果: {result['result']} (响应时间: {result['response_time']:.2f}秒)\n\n")

    print(f"\n结果已保存到: {output_file}")
    print(f"报告已保存到: {report_file}")
    print(f"\n测试完成!")

if __name__ == "__main__":
    run_test_suite()