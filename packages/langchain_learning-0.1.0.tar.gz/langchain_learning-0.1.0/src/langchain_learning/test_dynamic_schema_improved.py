#!/usr/bin/env python3
"""
测试改进后的动态schema选择
"""
import os
import json
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import (
    SQLGenerationTesterFullDBOptimized
)

def load_schema():
    """加载数据库schema"""
    schema_file = "data/json/compressed_schema.json"
    with open(schema_file, 'r', encoding='utf-8') as f:
        schema_data = json.load(f)
    return json.dumps(schema_data, ensure_ascii=False)

def test_improved_schema_extraction():
    """测试改进后的schema提取"""
    print("=" * 80)
    print("测试改进后的动态schema选择")
    print("=" * 80)

    # 加载schema
    print("加载数据库schema...")
    schema_text = load_schema()

    # 初始化测试器
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url="http://10.254.2.127:8001",
        timeout=60,
        full_schema_text=schema_text
    )

    # 测试查询
    test_queries = [
        "查询大学设置基本条件表的所有记录",
        "查询创新团队表中所属院系为计算机学院的记录",
        "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
        "统计留学湖北表中2023年度每个省份的在籍外国留学生总人数",
        "查询创新团队信息及其对应的科研项目到账经费信息",
        "查询科研项目到账经费表中纵向项目到账经费高于平均值的项目信息"
    ]

    for query in test_queries:
        print(f"\n查询: {query}")
        print("-" * 40)

        # 提取相关schema
        relevant_schema = tester.extract_relevant_schema(query, top_k=3)

        # 检查是否成功筛选
        if "相关表schema（根据查询自动筛选" in relevant_schema:
            print("状态: 动态筛选生效")
            # 计算相关表数量
            lines = relevant_schema.split('\n')
            table_count = sum(1 for line in lines if line.startswith('## 表:'))
            print(f"相关表数量: {table_count}")
            print(f"schema长度: {len(relevant_schema)} 字符")
            print(f"完整schema长度: {len(schema_text)} 字符")
            reduction = (1 - len(relevant_schema) / len(schema_text)) * 100
            print(f"长度减少: {reduction:.1f}%")

            # 显示前几行
            print("\n相关schema预览:")
            preview_lines = relevant_schema.split('\n')[:15]
            for line in preview_lines:
                print(f"  {line}")
            if len(relevant_schema.split('\n')) > 15:
                print("  ...")
        else:
            print("状态: 使用了完整schema")
            print(f"schema长度: {len(relevant_schema)} 字符")

    print("\n" + "=" * 80)
    print("测试完成")
    print("=" * 80)

if __name__ == "__main__":
    test_improved_schema_extraction()