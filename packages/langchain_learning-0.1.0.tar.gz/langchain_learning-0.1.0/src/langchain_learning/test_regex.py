import re

# 模拟 qwen3:8b 的响应
response = '''<think>
好的，用户让我生成一个纯SQL语句，查询大学设置基本条件表的所有记录。首先，我需要确认这个表的名称。根据用户提供的信息，主题8下的表1是"大学设置基本条件表"，原表名是auto_base_daxueshezhi。所以正确的表名应该是auto_base_daxueshezhi。

接下来，用户要查询的是所有记录，所以使用SELECT *语句。然后需要确认是否有特定的字段需要排除或者是否需要考虑性能问题，但用户没有提到这些，所以直接选所有字段。

然后，检查是否有拼写错误或者表名是否正确。用户提供的表名中有"auto_base_daxueshezhi"，所以直接使用这个名称。最后，确保SQL语句的语法正确，没有多余的符号。因此，最终的SQL应该是SELECT * FROM auto_base_daxueshezhi;。不需要任何其他文本，符合用户的要求。
</think>

SELECT * FROM auto_base_daxueshezhi;'''

print('原始响应:')
print(repr(response))
print()

# 步骤1：去除首尾空白
cleaned = response.strip()

# 步骤2：移除代码块标记
cleaned = re.sub(r'^```sql\s*', '', cleaned, flags=re.IGNORECASE)
cleaned = re.sub(r'^```\s*', '', cleaned, flags=re.IGNORECASE)
cleaned = re.sub(r'\s*```\s*$', '', cleaned, flags=re.IGNORECASE)

# 步骤3：移除成对XML/HTML标签及其内容
print('步骤3前:', repr(cleaned[:200]))
cleaned = re.sub(r'<[^>]+>.*?</[^>]+>', '', cleaned, flags=re.DOTALL | re.IGNORECASE)
print('步骤3后:', repr(cleaned[:200]))

# 步骤4：移除XML/HTML标签
cleaned = re.sub(r'<[^>]+>', '', cleaned)
print('步骤4后:', repr(cleaned[:200]))

# 步骤5：移除分号
cleaned = cleaned.rstrip(';')
print('步骤5后:', repr(cleaned[:200]))

# 现在尝试不同的正则表达式
print('\n--- 测试不同的正则表达式 ---')
cleaned2 = response.strip()
print('原始:', repr(cleaned2[:200]))

# 尝试匹配 <think>...</think>
pattern1 = r'<think>.*?</think>'
cleaned2 = re.sub(pattern1, '', cleaned2, flags=re.DOTALL | re.IGNORECASE)
print('使用 <think>.*?</think>:', repr(cleaned2[:200]))

# 如果还有标签
cleaned2 = re.sub(r'<[^>]+>', '', cleaned2)
print('移除剩余标签:', repr(cleaned2[:200]))