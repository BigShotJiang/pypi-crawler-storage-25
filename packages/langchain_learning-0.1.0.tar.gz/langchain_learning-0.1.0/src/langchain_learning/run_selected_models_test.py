#!/usr/bin/env python3
"""测试选定模型（快速版本）"""

import os
import sys
import subprocess
import time
from datetime import datetime

# 服务器配置
SERVER_URL = "http://10.254.2.127:8001"
SCHEMA_FILE = "data/json/compressed_schema.json"
TEST_CASES_FILE = "test_cases_complex.json"

# 选择关键模型测试
SELECTED_MODELS = [
    "gemma3:27b",                     # 非推理模型，可能表现更好
    "HridaAI/hrida-t2sql-128k:latest", # 专门SQL模型
    "qwen3:32b",                      # 大模型，测试推理能力
]

# 超时配置
MODEL_TIMEOUTS = {
    "gemma3:27b": 900,
    "HridaAI/hrida-t2sql-128k:latest": 600,
    "qwen3:32b": 900,
}

def main():
    print("=" * 80)
    print("本地大模型SQL生成能力测试（选定模型快速测试）")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"测试模型: {', '.join(SELECTED_MODELS)}")
    print("=" * 80)

    # 检查文件
    if not os.path.exists(SCHEMA_FILE):
        print(f"错误: schema文件不存在: {SCHEMA_FILE}")
        sys.exit(1)

    if not os.path.exists(TEST_CASES_FILE):
        print(f"错误: 测试用例文件不存在: {TEST_CASES_FILE}")
        sys.exit(1)

    # 创建主输出目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    main_output_dir = f"selected_models_test_{timestamp}"
    os.makedirs(main_output_dir, exist_ok=True)

    print(f"主输出目录: {main_output_dir}")

    # 保存测试计划
    test_plan = {
        "timestamp": timestamp,
        "server_url": SERVER_URL,
        "schema_file": SCHEMA_FILE,
        "test_cases_file": TEST_CASES_FILE,
        "models_to_test": SELECTED_MODELS,
        "timeout_config": MODEL_TIMEOUTS
    }

    plan_file = os.path.join(main_output_dir, "test_plan.json")
    with open(plan_file, 'w', encoding='utf-8') as f:
        import json
        json.dump(test_plan, f, ensure_ascii=False, indent=2)

    print(f"测试计划已保存: {plan_file}")

    # 逐个测试模型
    print(f"\n开始测试 {len(SELECTED_MODELS)} 个模型...")
    all_results = []

    for i, model in enumerate(SELECTED_MODELS, 1):
        print(f"\n{'='*60}")
        print(f"[{i}/{len(SELECTED_MODELS)}] 测试模型: {model}")
        print(f"{'='*60}")

        # 为每个模型创建单独的输出目录
        model_safe_name = model.replace(':', '_').replace('.', '_').replace('/', '_')
        model_output_dir = os.path.join(main_output_dir, f"model_{model_safe_name}")

        # 获取超时设置
        timeout = MODEL_TIMEOUTS.get(model, 600)

        # 构建命令
        cmd = [
            "python", "examples/model_sql_comprehensive_test_full_db_optimized.py",
            "--ollama-url", SERVER_URL,
            "--schema-file", SCHEMA_FILE,
            "--test-cases", TEST_CASES_FILE,
            "--timeout", str(timeout),
            "--output-dir", model_output_dir,
            "--skip-model-fetch",
            "--default-models", model
        ]

        cmd_str = " ".join(cmd)
        print(f"执行命令: {cmd_str}")

        # 运行命令
        start_time = time.time()
        result = subprocess.run(cmd_str, shell=True, capture_output=True, text=True)
        end_time = time.time()
        elapsed = end_time - start_time

        # 记录结果
        test_result = {
            "model": model,
            "timeout": timeout,
            "elapsed_time": elapsed,
            "returncode": result.returncode,
            "success": result.returncode == 0,
            "start_time": start_time,
            "end_time": end_time
        }

        if result.returncode == 0:
            print(f"模型 {model} 测试成功，耗时: {elapsed:.1f}秒")
        else:
            print(f"模型 {model} 测试失败，退出码: {result.returncode}")
            print(f"标准错误: {result.stderr[:500]}...")

        all_results.append(test_result)

        # 保存进度
        progress = {
            "completed": i,
            "total": len(SELECTED_MODELS),
            "current_model": model,
            "results_so_far": all_results
        }

        progress_file = os.path.join(main_output_dir, f"progress_{i}.json")
        with open(progress_file, 'w', encoding='utf-8') as f:
            import json
            json.dump(progress, f, ensure_ascii=False, indent=2)

        # 在模型之间添加延迟（让服务器休息）
        if i < len(SELECTED_MODELS):
            delay = 30  # 30秒
            print(f"\n等待 {delay} 秒后测试下一个模型...")
            time.sleep(delay)

    # 汇总结果
    print(f"\n{'='*80}")
    print("测试完成汇总")
    print(f"{'='*80}")

    successful = [r for r in all_results if r["success"]]
    failed = [r for r in all_results if not r["success"]]

    print(f"成功测试: {len(successful)}/{len(all_results)} 个模型")
    print(f"失败测试: {len(failed)}/{len(all_results)} 个模型")

    if failed:
        print(f"\n失败的模型:")
        for result in failed:
            print(f"  - {result['model']} (耗时: {result['elapsed_time']:.1f}秒)")

    print(f"\n测试完成!")
    print(f"结果目录: {main_output_dir}")

    return 0

if __name__ == "__main__":
    sys.exit(main())