#!/usr/bin/env python3
"""测试和改进SQLResponseCleaner"""

import re
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import SQLResponseCleaner

# 实际qwen3:8b输出（从测试结果中复制）
qwen_response_1 = """SELECT *语句。不过有时候可能需要注意是否需要考虑性能或者是否有特定的列需要排除，但用户没有提到这些，所以直接选所有列就可以了。

然后，我需要检查是否有其他可能的表名或者别名，但根据提供的信息，原表名明确是auto_base_daxueshezhi，所以直接使用这个表名。另外，用户可能希望结果中包含所有字段，所以不需要添加WHERE子句或者其他条件。

最后，确保SQL语法正确，没有拼写错误。所以最终的SQL应该是SELECT * FROM auto_base_daxueshezhi;。这样就能获取到该表的所有记录了。"""

qwen_response_2 = """<think>
好的，我现在需要帮用户生成一个SQL查询，用来统计每个年度每个院系的科研项目到账经费，并计算年度内院系经费排名。首先，我得仔细分析用户的需求，确保理解正确。

用户提到的“科研项目到账经费”可能涉及多个表，但根据提供的主题分类，科研项目相关的表可能在主题6“科研项目”下。不过，用户提供的表信息中，主题6的表是“科研项目”，但描述里没有明确提到经费字段。不过，可能需要查看其他表是否有相关字段，比如“大学设置基本条件表”中的“教学科研仪器设备金额”可能和经费有关，但不确定是否是到账经费。或者可能用户指的是科研项目中的经费到账情况，但表中没有明确字段。

这里可能存在信息不全的情况，因为用户提供的表结构中，科研项目相关的表可能没有直接记录到账经费的字段。例如，主题6的“科研项目”表可能包含项目金额或经费信息，但根据用户提供的描述，该表的字段包括项目名称、负责人、项目类型、经费、起止时间等，其中“经费”字段可能就是到账经费。因此，假设存在一个表，比如“科研项目”表，其中包含“经费”字段，用于计算每个院系的年度经费总额。

接下来，我需要确定如何连接表。假设“科研项目”表中有一个字段是“所属院系”（可能对应到“xueyuanname”），而“年度”可能在“起止时间”字段中提取，比如起始年份。或者可能有一个“年度”字段。但根据用户提供的表结构，比如“科研项目”表的字段包括“year”吗？根据用户提供的表结构，主题6的“科研项目”表的字段可能包括“year”吗？需要再检查用户提供的表信息。

在用户提供的主题6的“科研项目”表中，关键字段包括“project_name”、“responsible_person”、“project_type”、“funds”、“start_time”、“end_time”、“year”等。例如，表1的描述是“科研项目表，包含字段：project_name, responsible_person, project_type, funds, start_time, end_time, year”。所以，这里有一个“year”字段，可能表示项目所在的年度。同时，“funds”字段可能代表该项目的经费金额。

因此，用户需要统计每个年度每个院系的"""

# gemma3:27b输出（带代码块）
gemma_response = """```sql
SELECT DISTINCT
  field1name
FROM auto_base_daxueshezhi
UNION
SELECT DISTINCT
  field2name
FROM auto_jiaoshigongcheng
UNION
SELECT DISTINCT
  field1name
FROM auto_jiaoshi
UNION
SELECT DISTINCT
  field2name
FROM auto_jiaoshi
UNION
SELECT DISTINCT
  field11name
FROM auto_jiaoshizhuanlishouquanqingkuang
UNION
SELECT DISTINCT
  field2name
FROM auto_zhuanyezhuanrenjiaoshirongyu
UNION
SELECT DISTINCT
  field1name
FROM auto_base_daxueshezhi
```"""

print("测试当前清洗器...")
print("=" * 80)

cleaner = SQLResponseCleaner()

test_cases = [
    ("qwen_response_1 (包含SQL)", qwen_response_1),
    ("qwen_response_2 (长推理)", qwen_response_2),
    ("gemma_response (带代码块)", gemma_response)
]

for name, response in test_cases:
    print(f"\n测试: {name}")
    print(f"原始响应长度: {len(response)}")
    print(f"原始响应前150字符: {repr(response[:150])}")

    cleaned = cleaner.clean_sql_response(response)
    print(f"清洗后长度: {len(cleaned)}")
    print(f"清洗后内容: {repr(cleaned[:150])}")

    is_likely = cleaner.is_likely_sql(cleaned)
    print(f"看起来像SQL吗? {is_likely}")

    # 提取可能的SQL部分
    print(f"提取SQL尝试...")
    # 手动尝试查找SQL
    sql_keywords = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP']
    for keyword in sql_keywords:
        pos = response.upper().find(keyword)
        if pos != -1:
            print(f"  找到 '{keyword}' 在位置 {pos}")
            # 提取从该位置开始的文本
            snippet = response[pos:pos+200]
            print(f"  片段: {repr(snippet)}")

print(f"\n{'='*80}")
print("改进清洗器建议")
print("=" * 80)
print("""
问题分析:
1. qwen3的输出包含中文推理，但末尾可能有SQL语句
2. 当前清洗器可能因为中文文本而无法识别SQL
3. 需要更好的模式匹配来提取嵌入在中文中的SQL

改进建议:
1. 增强SQL模式匹配，允许SQL被非英文字符包围
2. 添加专门处理<think>标签的逻辑
3. 如果清洗后不是SQL，尝试查找包含SQL关键字的片段
4. 放宽is_likely_sql的中文检查
""")

# 实现改进的清洗器
class ImprovedSQLResponseCleaner(SQLResponseCleaner):
    """改进的SQL响应清洗器，更好地处理推理输出"""

    @staticmethod
    def clean_sql_response(response: str) -> str:
        """
        清洗SQL响应，改进处理推理输出
        """
        if not response:
            return ""

        # 1. 去除首尾空白
        cleaned = response.strip()

        # 2. 移除代码块标记
        cleaned = re.sub(r'^```sql\s*', '', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r'^```\s*', '', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r'\s*```\s*$', '', cleaned, flags=re.IGNORECASE)

        # 3. 移除成对XML/HTML标签及其内容（如<think>...</think>）
        # 匹配 <tag>任意内容</tag>，包括跨行
        cleaned = re.sub(r'<[^>]+>.*?</[^>]+>', '', cleaned, flags=re.DOTALL | re.IGNORECASE)

        # 4. 移除XML/HTML标签（如<think>）
        cleaned = re.sub(r'<[^>]+>', '', cleaned)

        # 5. 移除分号（如果是在末尾）
        cleaned = cleaned.rstrip(';')

        # 6. 移除常见的解释性前缀
        prefixes_to_remove = [
            r'^sql\s*',
            r'^query:\s*',
            r'^sql query:\s*',
            r'^生成的sql:\s*',
            r'^sql语句:\s*',
            r'^answer:\s*',
            r'^response:\s*',
        ]

        for prefix in prefixes_to_remove:
            cleaned = re.sub(prefix, '', cleaned, flags=re.IGNORECASE)

        # 7. 尝试查找SQL语句（改进版）
        # 首先尝试匹配完整的SQL语句，即使被中文包围
        sql_patterns = [
            r'(SELECT\s+.+?\s+FROM\s+\S+)',  # SELECT ... FROM ...
            r'(INSERT\s+INTO\s+\S+)',        # INSERT INTO ...
            r'(UPDATE\s+\S+\s+SET\s+)',      # UPDATE ... SET ...
            r'(DELETE\s+FROM\s+\S+)',        # DELETE FROM ...
            r'(CREATE\s+TABLE\s+\S+)',       # CREATE TABLE ...
            r'(ALTER\s+TABLE\s+\S+)',        # ALTER TABLE ...
            r'(DROP\s+TABLE\s+\S+)'          # DROP TABLE ...
        ]

        found_sql = None
        for pattern in sql_patterns:
            # 使用re.DOTALL匹配跨行，re.IGNORECASE忽略大小写
            matches = re.finditer(pattern, cleaned, re.IGNORECASE | re.DOTALL)
            for match in matches:
                # 提取匹配的SQL语句开始位置
                sql_start = match.start()
                sql_text = cleaned[sql_start:]

                # 尝试提取完整的语句
                # 查找语句结束位置：分号、换行后跟中文、或文本结束
                end_pos = len(sql_text)

                # 查找分号
                semicolon_pos = sql_text.find(';')
                if semicolon_pos != -1 and semicolon_pos < end_pos:
                    end_pos = semicolon_pos + 1  # 包含分号

                # 查找可能的中文结束标记
                chinese_end_pattern = r'[。；\n\n]'
                chinese_match = re.search(chinese_end_pattern, sql_text)
                if chinese_match and chinese_match.start() < end_pos:
                    end_pos = chinese_match.start()

                # 提取SQL语句
                sql_statement = sql_text[:end_pos].strip()

                # 如果看起来像SQL，使用它
                if ImprovedSQLResponseCleaner.is_likely_sql(sql_statement):
                    found_sql = sql_statement
                    break
            if found_sql:
                break

        # 如果通过模式匹配找到了SQL，使用它
        if found_sql:
            cleaned = found_sql
        else:
            # 回退：查找第一个SQL关键字并提取后续文本
            sql_keywords = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP']
            first_sql_pos = -1
            first_keyword = None

            for keyword in sql_keywords:
                pos = cleaned.upper().find(keyword)
                if pos != -1 and (first_sql_pos == -1 or pos < first_sql_pos):
                    first_sql_pos = pos
                    first_keyword = keyword

            if first_sql_pos != -1:
                # 从第一个SQL关键字开始提取
                remaining = cleaned[first_sql_pos:]

                # 查找结束位置
                end_pos = len(remaining)

                # 查找分号
                semicolon_pos = remaining.find(';')
                if semicolon_pos != -1:
                    end_pos = semicolon_pos + 1

                # 查找可能的中文结束标记
                chinese_end_pattern = r'[。；\n\n]'
                chinese_match = re.search(chinese_end_pattern, remaining)
                if chinese_match and chinese_match.start() < end_pos:
                    end_pos = chinese_match.start()

                # 提取SQL语句
                sql_statement = remaining[:end_pos].strip()
                cleaned = sql_statement

        # 最后清理：去除可能的分号
        cleaned = cleaned.rstrip(';')

        return cleaned

    @staticmethod
    def is_likely_sql(text: str) -> bool:
        """判断文本是否可能是SQL语句（放宽中文检查）"""
        if not text:
            return False

        text_upper = text.upper()
        text_lower = text.lower()

        # 1. 检查是否包含SQL关键字
        sql_keywords = ['SELECT', 'FROM', 'WHERE', 'JOIN', 'GROUP BY', 'ORDER BY',
                       'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP']
        has_sql_keyword = any(keyword in text_upper for keyword in sql_keywords)
        if not has_sql_keyword:
            return False

        # 2. 检查是否以解释性短语开头（放宽检查）
        explanation_indicators = [
            'this query', 'the sql', 'generated sql', 'explanation', '分析',
            '首先', '然后', '因此', '所以', '查询语句', '```sql',
            '用户', '需要', '应该', '可以', '可能', '如果', '那么'
        ]

        # 只检查文本是否以解释性短语开头（前50字符）
        text_lower_start = text_lower[:50]
        has_explanation_start = any(text_lower_start.startswith(indicator) for indicator in explanation_indicators)

        # 如果文本以解释性短语开头，可能不是纯SQL
        if has_explanation_start:
            return False

        # 3. 放宽中文检查：允许SQL中包含少量中文
        # 中文字符范围：\u4e00-\u9fff
        chinese_chars = re.findall(r'[\u4e00-\u9fff]', text)
        if chinese_chars:
            chinese_ratio = len(chinese_chars) / len(text)
            # 如果中文字符比例超过40%，可能不是纯SQL
            if chinese_ratio > 0.4:
                return False

        # 4. 检查SQL结构完整性（放宽）
        # 至少包含SELECT ... FROM 或类似结构
        sql_patterns = [
            r'SELECT\s+.+?\s+FROM\s+',
            r'INSERT\s+INTO\s+\S+\s+',
            r'UPDATE\s+\S+\s+SET\s+',
            r'DELETE\s+FROM\s+\S+\s+',
        ]

        has_sql_structure = any(re.search(pattern, text_upper) for pattern in sql_patterns)

        return has_sql_structure

print(f"\n{'='*80}")
print("测试改进的清洗器")
print("=" * 80)

improved_cleaner = ImprovedSQLResponseCleaner()

for name, response in test_cases:
    print(f"\n测试: {name}")
    cleaned = improved_cleaner.clean_sql_response(response)
    print(f"改进清洗后长度: {len(cleaned)}")
    print(f"改进清洗后内容: {repr(cleaned[:150])}")
    is_likely = improved_cleaner.is_likely_sql(cleaned)
    print(f"看起来像SQL吗? {is_likely}")