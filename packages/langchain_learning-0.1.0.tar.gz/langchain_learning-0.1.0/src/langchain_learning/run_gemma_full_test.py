#!/usr/bin/env python3
"""运行gemma3:27b的完整测试"""

import os
import sys
import subprocess
import time
from datetime import datetime

# 服务器配置
SERVER_URL = "http://10.254.2.127:8001"
SCHEMA_FILE = "data/json/compressed_schema.json"
TEST_CASES_FILE = "test_cases_complex.json"
MODEL = "gemma3:27b"
TIMEOUT = 900  # 15分钟（大模型可能需要更长时间）

def main():
    print("=" * 80)
    print(f"运行完整测试 - 模型: {MODEL}")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"测试用例文件: {TEST_CASES_FILE}")
    print(f"Schema文件: {SCHEMA_FILE}")
    print("=" * 80)

    # 检查文件
    if not os.path.exists(SCHEMA_FILE):
        print(f"错误: schema文件不存在: {SCHEMA_FILE}")
        sys.exit(1)

    if not os.path.exists(TEST_CASES_FILE):
        print(f"错误: 测试用例文件不存在: {TEST_CASES_FILE}")
        sys.exit(1)

    # 创建输出目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = f"gemma3_full_test_{timestamp}"
    os.makedirs(output_dir, exist_ok=True)

    print(f"输出目录: {output_dir}")

    # 构建命令
    cmd = [
        "python", "examples/model_sql_comprehensive_test_full_db_optimized.py",
        "--ollama-url", SERVER_URL,
        "--schema-file", SCHEMA_FILE,
        "--test-cases", TEST_CASES_FILE,
        "--timeout", str(TIMEOUT),
        "--output-dir", output_dir,
        "--skip-model-fetch",
        "--default-models", MODEL
    ]

    cmd_str = " ".join(cmd)
    print(f"执行命令: {cmd_str}")

    # 运行命令
    start_time = time.time()
    result = subprocess.run(cmd_str, shell=True, capture_output=True, text=True)
    end_time = time.time()
    elapsed = end_time - start_time

    # 输出结果
    print(f"\n测试完成，耗时: {elapsed:.1f}秒")
    print(f"退出码: {result.returncode}")

    if result.returncode == 0:
        print("测试成功完成!")
        # 查找结果文件
        result_files = [f for f in os.listdir(output_dir) if f.startswith("sql_test_results_")]
        if result_files:
            latest_result = max(result_files, key=lambda f: os.path.getmtime(os.path.join(output_dir, f)))
            result_file = os.path.join(output_dir, latest_result)
            print(f"结果文件: {result_file}")

            # 读取并显示摘要
            try:
                import json
                with open(result_file, 'r', encoding='utf-8') as f:
                    results = json.load(f)

                print(f"\n测试结果摘要:")
                print(f"总测试用例数: {len(results)}")

                pass_count = sum(1 for r in results if r.get("result") == "PASS")
                partial_count = sum(1 for r in results if r.get("result") == "PARTIAL")
                fail_count = sum(1 for r in results if r.get("result") == "FAIL")
                error_count = sum(1 for r in results if r.get("result") == "ERROR")

                print(f"通过: {pass_count}")
                print(f"部分通过: {partial_count}")
                print(f"失败: {fail_count}")
                print(f"错误: {error_count}")

                if fail_count > 0:
                    print(f"\n失败用例:")
                    for r in results:
                        if r.get("result") == "FAIL":
                            print(f"  用例 {r['test_case_id']}: {r.get('match_type', '未知')}")

            except Exception as e:
                print(f"读取结果文件时出错: {e}")
    else:
        print(f"测试失败!")
        print(f"标准输出:\n{result.stdout[-1000:]}")
        print(f"标准错误:\n{result.stderr[-1000:]}")

    return result.returncode

if __name__ == "__main__":
    sys.exit(main())