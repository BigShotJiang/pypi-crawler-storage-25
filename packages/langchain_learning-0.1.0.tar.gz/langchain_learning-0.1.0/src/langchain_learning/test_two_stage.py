#!/usr/bin/env python3
"""
测试两阶段SQL生成
"""

import os
import json
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import (
    SQLGenerationTesterFullDBOptimized
)

def load_schema():
    """加载数据库schema"""
    schema_file = "data/json/compressed_schema.json"
    with open(schema_file, 'r', encoding='utf-8') as f:
        schema_data = json.load(f)

    # 转换为文本格式
    lines = []
    lines.append("# 数据库schema（共118个表）")

    for theme in schema_data.get('themes', []):
        theme_name = theme.get('name', '未知主题')
        theme_desc = theme.get('description', '')
        lines.append(f"\n## 主题: {theme_name}")
        if theme_desc:
            lines.append(f"描述: {theme_desc}")

        for table in theme.get('tables', []):
            table_name = table.get('original_name', '')
            table_label = table.get('label', '')
            table_desc = table.get('description', '')

            lines.append(f"\n### 表: {table_name}")
            lines.append(f"标签: {table_label}")
            if table_desc:
                lines.append(f"描述: {table_desc}")

            key_fields = table.get('key_fields', [])
            if key_fields:
                lines.append("关键字段:")
                for field in key_fields:
                    field_name = field.get('name', '')
                    field_type = field.get('type', '')
                    field_remark = field.get('remark', '')
                    lines.append(f"  - {field_name} ({field_type}): {field_remark}")

    return '\n'.join(lines)

def test_two_stage_vs_single():
    """对比两阶段和单阶段生成"""
    print("=" * 80)
    print("测试两阶段SQL生成 vs 单阶段生成")
    print("=" * 80)

    # 加载schema
    print("加载数据库schema...")
    schema_text = load_schema()
    print(f"Schema大小: {len(schema_text)} 字符")

    # 初始化测试器
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url="http://10.254.2.127:8001",
        timeout=180,
        full_schema_text=schema_text
    )

    # 测试查询
    test_queries = [
        {
            "query": "查询大学设置基本条件表的所有记录",
            "expected": "SELECT * FROM auto_base_daxueshezhi",
            "name": "简单SELECT查询"
        },
        {
            "query": "查询创新团队表中所属院系为计算机学院的记录",
            "expected": "SELECT * FROM auto_caiji_chuangxin_team WHERE xueyuanname = '计算机学院'",
            "name": "WHERE条件查询"
        },
        {
            "query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和，并按照经费总额降序排列",
            "expected": "SELECT xueyuanname, SUM(money_1) as total_money FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanname ORDER BY total_money DESC",
            "name": "GROUP BY聚合查询"
        }
    ]

    # 测试模型
    test_model = "gemma3:27b"  # 选择一个表现较好的模型

    print(f"\n测试模型: {test_model}")
    print("-" * 80)

    for test in test_queries:
        print(f"\n测试用例: {test['name']}")
        print(f"查询: {test['query']}")
        print(f"预期SQL: {test['expected']}")

        # 测试两阶段生成
        print("\n1. 两阶段生成:")
        try:
            raw_two_stage, sql_two_stage, time_two_stage = tester.generate_sql(
                model_name=test_model,
                query=test['query'],
                two_stage=True
            )
            print(f"   生成时间: {time_two_stage:.2f}秒")
            print(f"   生成的SQL: {sql_two_stage[:100]}{'...' if len(sql_two_stage) > 100 else ''}")
            print(f"   匹配结果: {'[PASS]' if sql_two_stage.strip() == test['expected'].strip() else '[FAIL]'}")
        except Exception as e:
            print(f"   两阶段生成失败: {e}")
            sql_two_stage = ""
            time_two_stage = 0

        # 测试单阶段生成
        print("\n2. 单阶段生成:")
        try:
            raw_single, sql_single, time_single = tester.generate_sql(
                model_name=test_model,
                query=test['query'],
                two_stage=False
            )
            print(f"   生成时间: {time_single:.2f}秒")
            print(f"   生成的SQL: {sql_single[:100]}{'...' if len(sql_single) > 100 else ''}")
            print(f"   匹配结果: {'[PASS]' if sql_single.strip() == test['expected'].strip() else '[FAIL]'}")
        except Exception as e:
            print(f"   单阶段生成失败: {e}")
            sql_single = ""
            time_single = 0

        # 比较结果
        print("\n3. 结果比较:")
        if sql_two_stage and sql_single:
            if sql_two_stage.strip() == sql_single.strip():
                print("   两阶段和单阶段生成相同SQL")
            else:
                print("   两阶段和单阶段生成不同SQL")
                if sql_two_stage.strip() == test['expected'].strip():
                    print("   -> 两阶段生成正确")
                elif sql_single.strip() == test['expected'].strip():
                    print("   -> 单阶段生成正确")
                else:
                    print("   -> 两者都不正确")

            # 时间比较
            if time_two_stage > 0 and time_single > 0:
                time_diff = time_two_stage - time_single
                if time_diff > 0:
                    print(f"   两阶段比单阶段慢 {time_diff:.2f}秒")
                else:
                    print(f"   两阶段比单阶段快 {-time_diff:.2f}秒")

        print("-" * 80)

def test_stage1_analysis():
    """测试第一阶段分析功能"""
    print("\n" + "=" * 80)
    print("测试第一阶段查询分析")
    print("=" * 80)

    # 加载schema
    schema_text = load_schema()

    # 初始化测试器
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url="http://10.254.2.127:8001",
        timeout=120,
        full_schema_text=schema_text
    )

    # 测试查询
    test_queries = [
        "查询大学设置基本条件表的所有记录",
        "查询创新团队表中所属院系为计算机学院的记录",
        "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和"
    ]

    test_model = "gemma3:27b"

    for query in test_queries:
        print(f"\n查询: {query}")
        try:
            analysis = tester.stage1_analyze_query(test_model, query)
            print(f"分析结果:")
            print(f"  相关表: {analysis.get('tables', [])}")
            print(f"  相关字段: {analysis.get('fields', [])}")
            print(f"  操作: {analysis.get('operations', [])}")
            print(f"  条件: {analysis.get('conditions', '')}")
            print(f"  聚合: {analysis.get('aggregations', '')}")
            print(f"  连接: {analysis.get('joins', '')}")
        except Exception as e:
            print(f"分析失败: {e}")

def main():
    """主函数"""
    try:
        # 测试第一阶段分析
        test_stage1_analysis()

        # 对比两阶段和单阶段生成
        test_two_stage_vs_single()

        print("\n" + "=" * 80)
        print("测试完成")
        print("=" * 80)

    except Exception as e:
        print(f"测试过程中出错: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()