#!/usr/bin/env python3
"""Debug SQLResponseCleaner"""

import re
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from examples.model_sql_comprehensive_test_full_db_optimized import SQLResponseCleaner

# Test case from test_and_improve_cleaner.py
qwen_response_1 = """SELECT *语句。不过有时候可能需要注意是否需要考虑性能或者是否有特定的列需要排除，但用户没有提到这些，所以直接选所有列就可以了。

然后，我需要检查是否有其他可能的表名或者别名，但根据提供的信息，原表名明确是auto_base_daxueshezhi，所以直接使用这个表名。另外，用户可能希望结果中包含所有字段，所以不需要添加WHERE子句或者其他条件。

最后，确保SQL语法正确，没有拼写错误。所以最终的SQL应该是SELECT * FROM auto_base_daxueshezhi;。这样就能获取到该表的所有记录了。"""

cleaner = SQLResponseCleaner()

print("Testing qwen_response_1")
print("Original text (first 200 chars):")
print(repr(qwen_response_1[:200]))
print()

# Test clean_sql_response
cleaned = cleaner.clean_sql_response(qwen_response_1)
print("Cleaned text:")
print(repr(cleaned))
print(f"Length: {len(cleaned)}")
print()

# Test is_likely_sql
is_likely = cleaner.is_likely_sql(cleaned)
print(f"Is likely SQL? {is_likely}")
print()

# Manual pattern matching
print("Manual pattern matching:")
pattern = r'SELECT\s+.+?\s+FROM\s+\S+'
matches = list(re.finditer(pattern, qwen_response_1, re.IGNORECASE | re.DOTALL))
print(f"Found {len(matches)} matches with pattern: {pattern}")
for i, match in enumerate(matches):
    print(f"  Match {i}:")
    print(f"    Position: {match.start()}-{match.end()}")
    print(f"    Text: {repr(match.group())}")
    print(f"    Context: {repr(qwen_response_1[max(0, match.start()-20):match.end()+20])}")
    print()

# Check if the SQL at the end is found
print("Searching for 'SELECT * FROM auto_base_daxueshezhi;':")
pos = qwen_response_1.find('SELECT * FROM auto_base_daxueshezhi;')
if pos != -1:
    print(f"  Found at position {pos}")
    print(f"  Text: {repr(qwen_response_1[pos:pos+50])}")
else:
    print("  Not found")
    # Try case insensitive
    import re
    match = re.search(r'SELECT \* FROM auto_base_daxueshezhi;', qwen_response_1, re.IGNORECASE)
    if match:
        print(f"  Found (case-insensitive) at {match.start()}")
        print(f"  Text: {repr(match.group())}")