#!/usr/bin/env python3
"""
测试提示词更新效果
"""

import sys
import os

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 模拟必要的组件
class MockSchemaLoader:
    def load_full_schema(self):
        return "模拟数据库schema"

# 导入测试器类
from examples.model_sql_comprehensive_test_full_db_optimized import SQLGenerationTesterFullDBOptimized

def main():
    print("测试提示词更新")
    print("=" * 60)

    # 初始化测试器（使用模拟schema）
    schema_text = "压缩版数据库结构（8个主题）\n主题1: 基础信息\n主题2: 数据采集..."

    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url="http://10.254.2.99:8001/v1",
        timeout=120,
        full_schema_text=schema_text
    )

    # 获取提示词模板
    print("提示词模板类型:", type(tester.prompt_template))

    # 生成一个示例提示词
    example_query = "查询大学设置基本条件表的所有记录"
    prompt = tester.prompt_template.invoke({"query": example_query})

    print(f"\n生成的提示词大小: {len(str(prompt))} 字符")
    print(f"\n提示词开头500字符:")
    print("-" * 60)
    prompt_str = str(prompt)
    print(prompt_str[:500])
    print("-" * 60)

    print(f"\n提示词结尾500字符:")
    print("-" * 60)
    print(prompt_str[-500:])
    print("-" * 60)

    # 检查关键内容
    print("\n检查关键内容:")
    print("1. 强制指令:", "输出格式：仅SQL语句，不要推理过程" in prompt_str)
    print("2. 推理过程禁止:", "不要推理过程" in prompt_str)
    print("3. 示例13:", "示例13：禁止推理过程" in prompt_str)
    print("4. 简洁性原则:", "不要解释、注释、推理过程或额外文本" in prompt_str)
    print("5. 格式要求:", "推理过程、分号、中文别名" in prompt_str)

    # 查找示例13内容
    if "示例13：禁止推理过程" in prompt_str:
        start = prompt_str.find("示例13：禁止推理过程")
        end = prompt_str.find("## 当前数据库schema", start)
        if end != -1:
            print(f"\n示例13内容:")
            print("-" * 60)
            print(prompt_str[start:end][:300])
            print("-" * 60)

if __name__ == "__main__":
    main()