#!/usr/bin/env python3
"""
完整的SQL生成能力测试（简化版）
测试服务器上所有模型的SQL生成能力并生成准确排名
使用优化后的提示词和强制指令
"""

import os
import sys
import json
import time
import requests
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple, Optional
import re

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 从优化脚本导入必要的组件
from examples.model_sql_comprehensive_test_full_db_optimized import (
    FullDatabaseSchemaLoader, SQLGenerationTesterFullDBOptimized,
    TestCase, TestResult, TestResultRecord, ModelScore, ModelInfo,
    SQLEvaluator, SQLResponseCleaner
)

@dataclass
class SimplifiedTestResult:
    """简化的测试结果"""
    model_name: str
    test_case_id: int
    test_case_name: str
    generated_sql: str
    expected_sql: str
    result: str  # PASS, FAIL, ERROR
    response_time: float
    match_type: str = ""
    error_message: str = ""

def load_compressed_schema():
    """加载压缩schema"""
    schema_file = "data/json/compressed_schema.json"
    print(f"加载schema文件: {schema_file}")

    loader = FullDatabaseSchemaLoader(schema_file)
    schema_text = loader.load_full_schema()

    if "压缩版数据库结构" in schema_text:
        print("✓ 使用压缩版schema")
    print(f"Schema大小: {len(schema_text)} 字符")

    return schema_text

def create_full_test_cases() -> List[TestCase]:
    """创建完整的测试用例（与主脚本一致）"""
    test_cases = []

    # 基础测试用例 - 简单查询
    test_cases.append(TestCase(
        id=1,
        name="简单查询 - 大学设置表",
        natural_language_query="查询大学设置基本条件表的所有记录",
        expected_sql="SELECT * FROM auto_base_daxueshezhi",
        difficulty="basic",
        description="简单SELECT查询"
    ))

    test_cases.append(TestCase(
        id=2,
        name="条件查询 - 创新团队",
        natural_language_query="查询创新团队表中年度为2023的记录",
        expected_sql="SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'",
        difficulty="basic",
        description="带WHERE条件查询"
    ))

    test_cases.append(TestCase(
        id=3,
        name="聚合查询 - 科研经费",
        natural_language_query="统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
        expected_sql="SELECT xueyuanName, SUM(money_1) as total_money_1 FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName",
        difficulty="intermediate",
        description="GROUP BY和SUM聚合查询"
    ))

    test_cases.append(TestCase(
        id=4,
        name="连接查询测试",
        natural_language_query="查询创新团队和科研项目到账经费表中相同年度的数据",
        expected_sql="SELECT t1.*, t2.* FROM auto_caiji_chuangxin_team t1 JOIN auto_caiji_fuwu_summarykyxmdzjf t2 ON t1.year = t2.year",
        difficulty="intermediate",
        description="表连接查询"
    ))

    test_cases.append(TestCase(
        id=5,
        name="复杂条件查询 - 教师出国",
        natural_language_query="查询教师出国研修表中项目级别为国家级且出国时间大于某个值的记录",
        expected_sql="SELECT * FROM auto_caiji_guoji_projectjscgyx WHERE projectlevelName = '国家级' AND chuguo_time > 1000000000",
        difficulty="advanced",
        description="复杂条件组合查询"
    ))

    test_cases.append(TestCase(
        id=6,
        name="多表查询 - 学生出国",
        natural_language_query="查询学生出国学习表中学生人数大于10且年度为2023的记录",
        expected_sql="SELECT * FROM auto_caiji_guoji_projectxscgxx WHERE number_person > 10 AND year = '2023'",
        difficulty="basic",
        description="多条件查询"
    ))

    test_cases.append(TestCase(
        id=7,
        name="聚合统计 - 留学湖北",
        natural_language_query="统计留学湖北表中每个年度的在籍外国留学生总人数",
        expected_sql="SELECT year, SUM(number_1) as total_students FROM auto_caiji_guoji_summarylxhb GROUP BY year",
        difficulty="intermediate",
        description="按年度分组统计"
    ))

    return test_cases

def get_available_models() -> List[str]:
    """获取服务器上所有可用模型"""
    OLLAMA_URL = "http://10.254.2.99:8001"

    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10)
        if response.status_code == 200:
            data = response.json()
            models = [model.get("name") for model in data.get("models", [])]
            print(f"获取到 {len(models)} 个模型: {', '.join(models)}")
            return models
        else:
            print(f"获取模型列表失败，状态码: {response.status_code}")
            return ["qwen3:8b", "qwen3:30b", "qwen3:32b"]  # 默认列表
    except Exception as e:
        print(f"获取模型列表异常: {e}")
        return ["qwen3:8b", "qwen3:30b", "qwen3:32b"]  # 默认列表

def run_single_test(tester: SQLGenerationTesterFullDBOptimized,
                   model_name: str,
                   test_case: TestCase) -> SimplifiedTestResult:
    """运行单个测试"""
    print(f"  测试用例 {test_case.id}: {test_case.name}...", end="", flush=True)

    start_time = time.time()

    try:
        # 使用测试器的generate_sql方法
        raw_sql, cleaned_sql, response_time = tester.generate_sql(
            model_name, test_case.natural_language_query
        )

        # 评估SQL
        result, match_type = SQLEvaluator.evaluate_sql(raw_sql, test_case.expected_sql)

        print(f" [{result.value}] ({response_time:.1f}s)")

        return SimplifiedTestResult(
            model_name=model_name,
            test_case_id=test_case.id,
            test_case_name=test_case.name,
            generated_sql=cleaned_sql,
            expected_sql=test_case.expected_sql,
            result=result.value,
            response_time=response_time,
            match_type=match_type
        )

    except Exception as e:
        error_time = time.time() - start_time
        error_msg = str(e)
        print(f" [ERROR] ({error_time:.1f}s)")

        return SimplifiedTestResult(
            model_name=model_name,
            test_case_id=test_case.id,
            test_case_name=test_case.name,
            generated_sql="",
            expected_sql=test_case.expected_sql,
            result="ERROR",
            response_time=error_time,
            error_message=error_msg[:200]  # 限制错误信息长度
        )

def calculate_scores(results: List[SimplifiedTestResult]) -> Dict[str, Dict]:
    """计算模型得分"""
    scores = {}

    for result in results:
        if result.model_name not in scores:
            scores[result.model_name] = {
                "total": 0,
                "passed": 0,
                "failed": 0,
                "error": 0,
                "total_time": 0.0,
                "response_times": []
            }

        scores[result.model_name]["total"] += 1
        scores[result.model_name]["total_time"] += result.response_time
        scores[result.model_name]["response_times"].append(result.response_time)

        if result.result == "PASS":
            scores[result.model_name]["passed"] += 1
        elif result.result == "FAIL":
            scores[result.model_name]["failed"] += 1
        elif result.result == "ERROR":
            scores[result.model_name]["error"] += 1

    # 计算统计信息
    for model_name, data in scores.items():
        total = data["total"]
        if total > 0:
            data["pass_rate"] = data["passed"] / total
            data["avg_response_time"] = data["total_time"] / total
            if data["response_times"]:
                data["min_response_time"] = min(data["response_times"])
                data["max_response_time"] = max(data["response_times"])
            else:
                data["min_response_time"] = 0
                data["max_response_time"] = 0

    return scores

def save_results(results: List[SimplifiedTestResult], scores: Dict[str, Dict],
                 test_cases: List[TestCase], output_dir: str = "complete_sql_results"):
    """保存测试结果"""
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # 保存详细结果
    results_file = os.path.join(output_dir, f"sql_test_results_{timestamp}.json")
    with open(results_file, 'w', encoding='utf-8') as f:
        results_data = []
        for result in results:
            results_data.append(asdict(result))
        json.dump(results_data, f, ensure_ascii=False, indent=2)

    # 保存得分
    scores_file = os.path.join(output_dir, f"sql_test_scores_{timestamp}.json")
    with open(scores_file, 'w', encoding='utf-8') as f:
        json.dump(scores, f, ensure_ascii=False, indent=2)

    # 生成排行榜文本
    leaderboard_file = os.path.join(output_dir, f"sql_test_leaderboard_{timestamp}.txt")
    with open(leaderboard_file, 'w', encoding='utf-8') as f:
        f.write("=" * 80 + "\n")
        f.write("本地大模型SQL生成能力排行榜（完整测试优化版）\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"测试模型数: {len(scores)}\n")
        f.write(f"测试用例数: {len(test_cases)}\n")
        f.write(f"总测试次数: {len(results)}\n")
        f.write(f"服务器地址: http://10.254.2.99:8001\n")
        f.write(f"数据库schema: 压缩版（8个主题）\n")
        f.write(f"评估方法: 精确匹配 + 清洗后匹配 + 标准化匹配 + 语义相似度\n")
        f.write(f"优化特性: 字段名大小写容错、禁止中文别名、强制指令避免推理\n")
        f.write("\n" + "=" * 80 + "\n\n")

        # 按通过率排序
        sorted_scores = sorted(scores.items(), key=lambda x: x[1].get("pass_rate", 0), reverse=True)

        f.write("模型排名（按通过率排序）:\n")
        f.write("-" * 80 + "\n")
        for i, (model_name, data) in enumerate(sorted_scores, 1):
            pass_rate = data.get("pass_rate", 0)
            passed = data.get("passed", 0)
            total = data.get("total", 0)
            avg_time = data.get("avg_response_time", 0)
            min_time = data.get("min_response_time", 0)
            max_time = data.get("max_response_time", 0)

            f.write(f"第{i}名: {model_name}\n")
            f.write(f"   通过率: {pass_rate:.2%} ({passed}/{total})\n")
            f.write(f"   失败: {data.get('failed', 0)}，错误: {data.get('error', 0)}\n")
            f.write(f"   平均响应时间: {avg_time:.2f}秒\n")
            f.write(f"   响应时间范围: {min_time:.2f}-{max_time:.2f}秒\n")
            f.write("\n")

        # 测试用例统计
        f.write("\n" + "=" * 80 + "\n")
        f.write("测试用例统计:\n")
        f.write("-" * 80 + "\n")

        for test_case in test_cases:
            case_results = [r for r in results if r.test_case_id == test_case.id]
            total = len(case_results)
            passed = len([r for r in case_results if r.result == "PASS"])

            if total > 0:
                pass_rate = passed / total
                f.write(f"测试用例 {test_case.id}: {test_case.name}\n")
                f.write(f"   通过率: {pass_rate:.2%} ({passed}/{total})\n")
                f.write(f"   难度: {test_case.difficulty}\n")
                f.write(f"   描述: {test_case.description}\n")
                f.write("\n")

    print(f"\n结果已保存到目录: {output_dir}")
    print(f"详细结果: {results_file}")
    print(f"得分文件: {scores_file}")
    print(f"排行榜: {leaderboard_file}")

    return leaderboard_file

def display_leaderboard(scores: Dict[str, Dict]):
    """在控制台显示排行榜"""
    print("\n" + "=" * 80)
    print("SQL生成能力排行榜")
    print("=" * 80)

    # 按通过率排序
    sorted_scores = sorted(scores.items(), key=lambda x: x[1].get("pass_rate", 0), reverse=True)

    for i, (model_name, data) in enumerate(sorted_scores, 1):
        pass_rate = data.get("pass_rate", 0)
        passed = data.get("passed", 0)
        total = data.get("total", 0)
        avg_time = data.get("avg_response_time", 0)

        print(f"{i}. {model_name}")
        print(f"   通过率: {pass_rate:.2%} ({passed}/{total})")
        print(f"   平均响应时间: {avg_time:.2f}秒")
        print()

def main():
    print("=" * 80)
    print("完整的SQL生成能力测试（优化版）")
    print("=" * 80)
    print("优化特性:")
    print("1. 强制指令：'输出格式：仅SQL语句，不要推理过程'")
    print("2. 字段名大小写容错机制")
    print("3. 禁止中文别名规则")
    print("4. 13个Few-shot示例（包括禁止推理示例）")
    print("5. 使用压缩版schema（8个主题）")
    print("=" * 80)

    # 1. 加载schema
    print("\n1. 加载数据库schema...")
    schema_text = load_compressed_schema()

    # 2. 获取可用模型
    print("\n2. 获取服务器上的模型...")
    model_names = get_available_models()
    print(f"  将要测试的模型: {', '.join(model_names)}")

    # 3. 创建测试用例
    print("\n3. 创建测试用例...")
    test_cases = create_full_test_cases()
    print(f"  创建了 {len(test_cases)} 个测试用例")
    print(f"  难度分布: basic={sum(1 for tc in test_cases if tc.difficulty == 'basic')}, "
          f"intermediate={sum(1 for tc in test_cases if tc.difficulty == 'intermediate')}, "
          f"advanced={sum(1 for tc in test_cases if tc.difficulty == 'advanced')}")

    # 4. 初始化测试器
    print("\n4. 初始化测试器...")
    OLLAMA_URL = "http://10.254.2.99:8001"
    tester = SQLGenerationTesterFullDBOptimized(
        ollama_base_url=f"{OLLAMA_URL}/v1",
        timeout=300,  # 300秒超时
        full_schema_text=schema_text
    )

    # 5. 运行测试
    print("\n5. 开始测试...")
    print("=" * 80)

    all_results = []
    total_tests = len(model_names) * len(test_cases)
    completed_tests = 0

    start_time = time.time()

    for model_idx, model_name in enumerate(model_names, 1):
        print(f"\n[{model_idx}/{len(model_names)}] 测试模型: {model_name}")

        for case_idx, test_case in enumerate(test_cases, 1):
            result = run_single_test(tester, model_name, test_case)
            all_results.append(result)
            completed_tests += 1

    total_test_time = time.time() - start_time

    # 6. 计算得分
    print("\n6. 计算测试结果...")
    scores = calculate_scores(all_results)

    # 7. 显示排行榜
    display_leaderboard(scores)

    print(f"总测试时间: {total_test_time:.2f}秒")
    print(f"总测试次数: {len(all_results)}")
    print(f"平均每个测试: {total_test_time/len(all_results) if all_results else 0:.2f}秒")

    # 8. 保存结果
    print("\n7. 保存测试结果...")
    leaderboard_file = save_results(all_results, scores, test_cases)

    # 9. 读取并显示排行榜文件内容
    try:
        with open(leaderboard_file, 'r', encoding='utf-8') as f:
            print("\n" + "=" * 80)
            print("最终排行榜（从文件读取）:")
            print("=" * 80)
            print(f.read())
    except Exception as e:
        print(f"读取排行榜文件失败: {e}")

    print("\n" + "=" * 80)
    print("测试完成！")
    print("=" * 80)

if __name__ == "__main__":
    main()