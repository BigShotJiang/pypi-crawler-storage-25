#!/usr/bin/env python3
"""测试字段名标准化功能"""

import re

def normalize_field_names(sql: str) -> str:
    """标准化字段名大小写格式"""
    if not sql:
        return sql

    # 常见的字段名大小写问题映射（基于测试结果）
    field_name_mappings = {
        # 驼峰命名转小写（主要问题）
        'XUEYUANNAME': 'xueyuanname',
        'PROJECTLEVELNAME': 'projectlevelname',
        'XUEYUAN_NAME': 'xueyuanname',  # 可能的变体
        'PROJECTLEVEL_NAME': 'projectlevelname',  # 可能的变体

        # 其他常见字段名（确保一致性）
        'MONEY_1': 'money_1',
        'MONEY1': 'money_1',
        'CHUGUO_TIME': 'chuguo_time',
        'CHUGUOTIME': 'chuguo_time',
        'HUIGUO_TIME': 'huiguo_time',
        'HUIGUOTIME': 'huiguo_time',
        'YEAR': 'year',
        'NUMBER_PERSON': 'number_person',
        'NUMBERPERSON': 'number_person',
        'NUMBER_1': 'number_1',
        'NUMBER1': 'number_1',
        'STATUS': 'status',
        'FIELD1': 'field1',
        'FIELD2NAME': 'field2name',
        'FIELD2_NAME': 'field2name',
        'FIELD5': 'field5',
        'FIELD6': 'field6',
    }

    # 将SQL转换为小写进行字段名替换
    sql_lower = sql.lower()

    # 对每个字段名进行标准化
    for upper_name, normalized_name in field_name_mappings.items():
        # 替换各种大小写变体
        sql_lower = re.sub(r'\b' + re.escape(upper_name.lower()) + r'\b', normalized_name, sql_lower)
        sql_lower = re.sub(r'\b' + re.escape(upper_name.title()) + r'\b', normalized_name, sql_lower)
        sql_lower = re.sub(r'\b' + re.escape(upper_name) + r'\b', normalized_name, sql_lower)

    return sql_lower

def normalize_sql(sql: str) -> str:
    """标准化SQL语句以便比较"""
    if not sql:
        return ""

    # 1. 转换为大写
    normalized = sql.upper()

    # 2. 移除多余空白
    normalized = re.sub(r'\s+', ' ', normalized)

    # 3. 移除AS关键字（可选）
    normalized = re.sub(r'\s+AS\s+', ' ', normalized)

    # 4. 标准化别名
    normalized = re.sub(r'(\w+)\s+(\w+)(?=\s|$)', r'\1 \2', normalized)

    # 5. 移除尾部分号（如果存在）
    normalized = normalized.rstrip(';')

    return normalized.strip()

# 测试用例
test_cases = [
    # 原始SQL, 预期标准化后SQL
    ("SELECT xueyuanName, SUM(money_1) as total_money_1 FROM table GROUP BY xueyuanName",
     "SELECT xueyuanname, SUM(money_1) as total_money_1 FROM table GROUP BY xueyuanname"),

    ("SELECT xueyuanname, SUM(money_1) AS zongxiang_zhonghe FROM table GROUP BY xueyuanname",
     "SELECT xueyuanname, SUM(money_1) AS zongxiang_zhonghe FROM table GROUP BY xueyuanname"),

    ("SELECT projectlevelName, chuguo_time FROM table WHERE projectlevelName = '国家级'",
     "SELECT projectlevelname, chuguo_time FROM table WHERE projectlevelname = '国家级'"),

    ("SELECT XueyuanName, ProjectLevelName FROM table",
     "SELECT xueyuanname, projectlevelname FROM table"),

    ("SELECT XUEYUANNAME, PROJECTLEVELNAME FROM table",
     "SELECT xueyuanname, projectlevelname FROM table"),
]

print("测试字段名标准化功能：")
for i, (input_sql, expected) in enumerate(test_cases, 1):
    result = normalize_field_names(input_sql)
    normalized_input = normalize_sql(result)
    normalized_expected = normalize_sql(expected)

    match = normalized_input == normalized_expected
    print(f"测试 {i}: {'通过' if match else '失败'}")
    print(f"  输入: {input_sql}")
    print(f"  字段名标准化后: {result}")
    print(f"  完全标准化后: {normalized_input}")
    print(f"  预期标准化: {normalized_expected}")
    if not match:
        print(f"  差异: 输入标准化='{normalized_input}', 预期='{normalized_expected}'")
    print()