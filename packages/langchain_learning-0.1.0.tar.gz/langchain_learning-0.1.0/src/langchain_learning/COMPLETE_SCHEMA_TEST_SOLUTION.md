# 完整数据库Schema SQL生成测试解决方案

## 问题分析

原测试脚本`model_sql_comprehensive_test.py`为每个测试用例提供单独的表结构（`table_schema`）。根据用户要求，需要改为一次性提供完整数据库schema（所有表结构）给大模型进行测试。

## 解决方案

已创建完整的测试框架，支持以下功能：

### 1. 完整数据库Schema加载器 (`FullDatabaseSchemaLoader`)
- 从`data/json/json.json`加载118个表的结构
- 格式化schema为模型可理解的文本格式
- 自动简化复杂字段名（如CASE表达式、DATEADD函数）
- 限制表数量以避免token过长

### 2. 完整Schema测试脚本 (`model_sql_comprehensive_test_full_db.py`)
- 将完整数据库schema一次性提供给模型
- 支持从服务器自动获取模型列表
- 内置7个测试用例，覆盖不同难度级别
- 完整的测试结果统计和排名功能

### 3. 测试用例设计

**基础查询 (3个)**:
1. 简单查询 - 大学设置表: `SELECT * FROM auto_base_daxueshezhi`
2. 条件查询 - 创新团队: `SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'`
3. 多条件查询 - 学生出国: `SELECT * FROM auto_caiji_guoji_projectxscgxx WHERE number_person > 10 AND year = '2023'`

**中级查询 (3个)**:
4. 聚合查询 - 科研经费: `SELECT xueyuanName, SUM(money_1) as total_money_1 FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName`
5. 连接查询测试: `SELECT t1.*, t2.* FROM auto_caiji_chuangxin_team t1 JOIN auto_caiji_fuwu_summarykyxmdzjf t2 ON t1.year = t2.year`
6. 聚合统计 - 留学湖北: `SELECT year, SUM(number_1) as total_students FROM auto_caiji_guoji_summarylxhb GROUP BY year`

**高级查询 (1个)**:
7. 复杂条件查询 - 教师出国: `SELECT * FROM auto_caiji_guoji_projectjscgyx WHERE projectlevelName = '国家级' AND chuguo_time > 1000000000`

## 运行方法

### 基础测试
```bash
# 自动获取服务器模型并测试
python examples/model_sql_comprehensive_test_full_db.py

# 使用指定schema文件
python examples/model_sql_comprehensive_test_full_db.py --schema-file data/json/json.json

# 限制测试模型数量
python examples/model_sql_comprehensive_test_full_db.py --max-models 2

# 指定输出目录
python examples/model_sql_comprehensive_test_full_db.py --output-dir ./full_db_results
```

### 高级配置
```bash
# 跳过自动获取模型，使用指定模型
python examples/model_sql_comprehensive_test_full_db.py --skip-model-fetch --default-models "HridaAI/hrida-t2sql-128k:latest" "a-kore/Arctic-Text2SQL-R1-7B:latest" "qwen3:8b"

# 增加超时时间
python examples/model_sql_comprehensive_test_full_db.py --timeout 180

# 干运行模式（只显示配置，不实际执行）
python examples/model_sql_comprehensive_test_full_db.py --dry-run
```

## 预期测试的模型

服务器上检测到的可用模型：
1. `HridaAI/hrida-t2sql-128k:latest` - Text2SQL专业模型
2. `a-kore/Arctic-Text2SQL-R1-7B:latest` - Text2SQL专业模型
3. `qwen3:8b` - 通用大模型
4. `qwen3:30b-a3b-instruct-2507-q4_K_M` - 高级Qwen模型
5. `deepseek-r1:8b` - DeepSeek模型
6. `qllama/bge-large-zh-v1.5:latest` - 嵌入模型
7. `nomic-embed-text:latest` - 嵌入模型

## 测试结果输出

测试完成后生成以下文件：
- `sql_test_leaderboard_*.txt` - 模型排名榜
- `sql_test_results_*.json` - 详细测试结果
- `sql_test_scores_*.json` - 模型得分统计
- `sql_test_details_*.csv` - CSV格式详情
- `models_info_*.json` - 模型信息

## 示例排行榜输出

```
================================================================================
本地大模型SQL生成能力排行榜（完整数据库schema测试）
================================================================================

测试时间: 2026-03-21 HH:MM:SS
测试模型总数: 3
测试用例总数: 7
总测试次数: 21
服务器地址: http://10.254.2.127:8001
数据库表数量: 50个表

模型排名:
--------------------------------------------------------------------------------
第1名: HridaAI/hrida-t2sql-128k:latest
   通过率: 85.7% (6/7)
   平均响应时间: 2.34秒
   总响应时间: 16.38秒

第2名: a-kore/Arctic-Text2SQL-R1-7B:latest
   通过率: 71.4% (5/7)
   平均响应时间: 3.12秒
   总响应时间: 21.84秒

第3名: qwen3:8b
   通过率: 57.1% (4/7)
   平均响应时间: 4.56秒
   总响应时间: 31.92秒
```

## 当前连接问题

测试过程中发现服务器`http://10.254.2.127:8001`连接超时。可能原因：
1. 服务器暂时不可用
2. 网络配置问题
3. 防火墙限制

## 建议的调试步骤

1. **检查服务器状态**:
   ```bash
   curl http://10.254.2.127:8001
   ```

2. **检查模型可用性**:
   ```bash
   curl http://10.254.2.127:8001/v1/models
   ```

3. **测试简单请求**:
   ```bash
   curl -X POST http://10.254.2.127:8001/v1/chat/completions \
     -H "Content-Type: application/json" \
     -d '{"model": "llama2", "messages": [{"role": "user", "content": "Hello"}]}'
   ```

4. **修改Python脚本超时设置**:
   在脚本中增加超时时间到180秒或更长

## 备用方案：本地测试

如果远程服务器不可用，可以在本地安装Ollama并运行测试：

1. **安装Ollama**:
   ```bash
   # Windows
   winget install ollama.ollama

   # 或从官网下载安装
   ```

2. **下载测试模型**:
   ```bash
   ollama pull hrida-t2sql-128k
   ollama pull arctic-text2sql-r1-7b
   ollama pull qwen3:8b
   ```

3. **修改脚本使用本地服务器**:
   ```bash
   python examples/model_sql_comprehensive_test_full_db.py --ollama-url http://localhost:11434
   ```

## 已创建的文件

1. `examples/model_sql_comprehensive_test_full_db.py` - 完整schema测试主脚本
2. `formatted_schema.txt` - 格式化后的完整schema示例
3. `schema_summary.txt` - schema摘要
4. `test_full_schema_simple.py` - 简化测试脚本（直接API调用）
5. `check_server.py` - 服务器连接检查工具

## 技术要点

1. **Schema优化**:
   - 将复杂字段表达式简化为基本字段名
   - 限制显示的表和字段数量以控制token长度
   - 提供schema使用说明

2. **Prompt设计**:
   - 一次性提供完整数据库schema
   - 明确的指令要求只输出纯SQL
   - 强调使用正确的表名和字段名

3. **评估方法**:
   - 精确匹配生成的SQL和预期SQL
   - 统计通过率、响应时间
   - 多维度模型排名

## 后续扩展建议

1. **增加测试用例**:
   - 更复杂的JOIN查询
   - 子查询和嵌套查询
   - 窗口函数
   - 日期时间处理

2. **改进评估方法**:
   - 语义相似度评估（而非精确匹配）
   - SQL语法正确性检查
   - 查询结果正确性验证

3. **性能优化**:
   - 并行测试多个模型
   - 缓存schema和模型响应
   - 增量测试模式

## 结论

已成功创建完整的数据库schema测试框架，能够一次性将118个表的结构提供给大模型进行SQL生成能力测试。该框架支持自动模型发现、多难度测试用例、完整的结果统计和排名功能。

当服务器`http://10.254.2.127:8001`恢复可用时，可直接运行以下命令进行完整测试：

```bash
python examples/model_sql_comprehensive_test_full_db.py --skip-model-fetch --default-models "HridaAI/hrida-t2sql-128k:latest" "a-kore/Arctic-Text2SQL-R1-7B:latest" "qwen3:8b" --max-models 3 --timeout 180 --output-dir ./full_db_results
```