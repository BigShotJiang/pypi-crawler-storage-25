#!/usr/bin/env python3
"""测试Ollama连接和SQL生成"""

import time
import requests
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

def test_ollama_models():
    """测试获取模型列表"""
    print("测试Ollama服务器连接...")
    try:
        response = requests.get("http://10.254.2.99:8001/v1/models", timeout=10)
        if response.status_code == 200:
            models = response.json().get("data", [])
            print(f"找到 {len(models)} 个模型:")
            for model in models:
                print(f"  - {model.get('id', 'N/A')}")
            return [model.get('id') for model in models]
        else:
            print(f"错误: HTTP {response.status_code}")
            return []
    except Exception as e:
        print(f"连接失败: {e}")
        return []

def test_chat_openai(model_name="qwen3:8b"):
    """测试ChatOpenAI与Ollama的集成"""
    print(f"\n测试ChatOpenAI与模型 {model_name}...")

    # 创建ChatOpenAI实例
    llm = ChatOpenAI(
        base_url="http://10.254.2.99:8001/v1",
        model=model_name,
        api_key="ollama",
        temperature=0.0,
        max_tokens=50,
        timeout=30
    )

    # 创建简单提示
    prompt = ChatPromptTemplate.from_messages([
        ("system", "你是一个助手。只回复'Hello, world!'，不要其他内容。"),
        ("human", "请说你好")
    ])

    chain = prompt | llm | StrOutputParser()

    start_time = time.time()
    try:
        response = chain.invoke({})
        elapsed = time.time() - start_time
        print(f"响应成功 ({elapsed:.2f}秒): {response}")
        return True
    except Exception as e:
        elapsed = time.time() - start_time
        print(f"响应失败 ({elapsed:.2f}秒): {e}")
        return False

def test_sql_generation():
    """测试SQL生成"""
    print("\n测试SQL生成...")

    # 使用脚本中的类
    import sys
    sys.path.append('.')
    from examples.model_sql_comprehensive_test_full_db import (
        SQLGenerationTesterFullDB, FullDatabaseSchemaLoader, TestCase
    )

    # 加载schema
    loader = FullDatabaseSchemaLoader("data/json/json.json")
    schema_text = loader.load_full_schema()
    print(f"Schema加载成功，长度: {len(schema_text)} 字符")

    # 创建测试器
    tester = SQLGenerationTesterFullDB(
        ollama_base_url="http://10.254.2.99:8001/v1",
        timeout=30,
        full_schema_text=schema_text[:1000]  # 只使用前1000字符测试
    )

    # 测试一个简单查询
    test_case = TestCase(
        id=1,
        name="测试查询",
        natural_language_query="查询所有记录",
        expected_sql="SELECT * FROM auto_base_daxueshezhi",
        difficulty="basic"
    )

    print(f"测试查询: {test_case.natural_language_query}")

    try:
        # 测试第一个模型
        models = test_ollama_models()
        if models:
            model_name = models[0]
            print(f"使用模型: {model_name}")

            # 直接测试generate_sql方法
            sql, resp_time = tester.generate_sql(model_name, test_case.natural_language_query)
            print(f"生成的SQL ({resp_time:.2f}秒): {sql}")
            return True
    except Exception as e:
        print(f"SQL生成失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("开始Ollama连接测试")
    print("=" * 60)

    # 测试1: 获取模型列表
    models = test_ollama_models()

    # 测试2: ChatOpenAI集成
    if models:
        success = test_chat_openai(models[0])
        if success:
            print("\nChatOpenAI测试成功!")
        else:
            print("\nChatOpenAI测试失败!")

    # 测试3: SQL生成（可选）
    # test_sql_generation()

    print("\n测试完成")