#!/usr/bin/env python3
import json

# 创建测试用例（排除测试用例5）
test_cases = [
    {
        "id": 1,
        "name": "简单查询 - 大学设置表",
        "natural_language_query": "查询大学设置基本条件表的所有记录",
        "expected_sql": "SELECT * FROM auto_base_daxueshezhi",
        "difficulty": "basic",
        "description": "简单SELECT查询"
    },
    {
        "id": 2,
        "name": "条件查询 - 创新团队",
        "natural_language_query": "查询创新团队表中年度为2023的记录",
        "expected_sql": "SELECT * FROM auto_caiji_chuangxin_team WHERE year = '2023'",
        "difficulty": "basic",
        "description": "带WHERE条件查询"
    },
    {
        "id": 3,
        "name": "聚合查询 - 科研经费",
        "natural_language_query": "统计科研项目到账经费表中每个所属院系的纵向项目到账经费总和",
        "expected_sql": "SELECT xueyuanName, SUM(money_1) as total_money_1 FROM auto_caiji_fuwu_summarykyxmdzjf GROUP BY xueyuanName",
        "difficulty": "intermediate",
        "description": "GROUP BY和SUM聚合查询"
    },
    {
        "id": 4,
        "name": "连接查询测试",
        "natural_language_query": "查询创新团队和科研项目到账经费表中相同年度的数据",
        "expected_sql": "SELECT t1.*, t2.* FROM auto_caiji_chuangxin_team t1 JOIN auto_caiji_fuwu_summarykyxmdzjf t2 ON t1.year = t2.year",
        "difficulty": "intermediate",
        "description": "表连接查询"
    },
    {
        "id": 6,
        "name": "多表查询 - 学生出国",
        "natural_language_query": "查询学生出国学习表中学生人数大于10且年度为2023的记录",
        "expected_sql": "SELECT * FROM auto_caiji_guoji_projectxscgxx WHERE number_person > 10 AND year = '2023'",
        "difficulty": "basic",
        "description": "多条件查询"
    },
    {
        "id": 7,
        "name": "聚合统计 - 留学湖北",
        "natural_language_query": "统计留学湖北表中每个年度的在籍外国留学生总人数",
        "expected_sql": "SELECT year, SUM(number_1) as total_students FROM auto_caiji_guoji_summarylxhb GROUP BY year",
        "difficulty": "intermediate",
        "description": "按年度分组统计"
    }
]

with open('test_cases_no5.json', 'w', encoding='utf-8') as f:
    json.dump(test_cases, f, ensure_ascii=False, indent=2)

print(f"创建了包含 {len(test_cases)} 个测试用例的文件: test_cases_no5.json")