# LangChain Learning Project

A structured learning project for mastering LangChain and vector databases (Milvus).

## Project Structure

```
langchain-learning/
├── src/                    # Source code
│   ├── core/              # Core functionality modules
│   ├── chains/            # LangChain chains
│   ├── agents/            # LangChain agents
│   └── utils/             # Utility functions
├── examples/              # Example scripts (migrated from LangChain-*.py)
├── tests/                 # Test code
├── docs/                  # Documentation
├── data/                  # Data files
└── config/                # Configuration files
```

## Getting Started

### Prerequisites
- Python 3.8+
- Milvus server (for vector database examples)
- API keys for AI services (DeepSeek, OpenAI, etc.)

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd langchain-learning
```

2. Create and activate virtual environment:
```bash
python -m venv .venv
# On Windows
.venv\Scripts\activate
# On Linux/Mac
source .venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your API keys
```

## Examples

The `examples/` directory contains learning scripts:
- `LangChain-1.py` to `LangChain-22.py`: Step-by-step tutorials
- Each script demonstrates a specific LangChain/Milvus concept

## Development

### Code Quality Tools
- **Black**: Code formatting
- **isort**: Import sorting
- **mypy**: Static type checking
- **pytest**: Testing framework
- **flake8**: Linting

### Running Tests
```bash
pytest
```

### Code Formatting
```bash
black src tests
isort src tests
```

## Learning Path

1. **Basics**: Embeddings, vector stores, document loaders
2. **Chains**: Sequential chains, transformation chains
3. **Agents**: Tool-using agents, reasoning agents
4. **Memory**: Conversation memory, entity memory
5. **Advanced**: Retrieval-augmented generation (RAG), multi-modal chains

## Resources

- [LangChain Documentation](https://python.langchain.com/)
- [Milvus Documentation](https://milvus.io/docs)
- [Pydantic Documentation](https://docs.pydantic.dev/)

## License

This project is for educational purposes.

#cd examples
#python demo_embeddings.py
