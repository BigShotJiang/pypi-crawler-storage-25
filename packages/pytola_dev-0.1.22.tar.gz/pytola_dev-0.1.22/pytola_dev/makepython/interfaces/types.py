"""Type definitions for MakePython."""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Protocol, TypeVar


class BuildTool(Enum):
    """Supported build tools."""

    UV = "uv"
    POETRY = "poetry"
    HATCH = "hatch"


T = TypeVar("T")


class CacheProtocol(Protocol[T]):
    """Protocol for cache implementations."""

    def get(self, key: Path) -> T | None:
        """Get value from cache."""
        ...

    def put(self, key: Path, value: T) -> None:
        """Put value in cache."""
        ...

    def invalidate(self, key: Path) -> None:
        """Invalidate cache entry."""
        ...

    def clear(self) -> None:
        """Clear all cache entries."""
        ...
