"""Command factory for MakePython."""

from __future__ import annotations

from ..commands.impl.activate import ActivateCommand
from ..commands.impl.build import BuildCommand
from ..commands.impl.clean import CleanCommand
from ..commands.impl.dist import DistCommand
from ..commands.impl.doc import DocCommand
from ..commands.impl.init import InitCommand
from ..commands.impl.lint import LintCommand
from ..commands.impl.publish import BumpPublishCommand, PublishCommand
from ..commands.impl.test import (
    TestBenchmarkCommand,
    TestCommand,
    TestCoverageCommand,
    TestCoverageSlowCommand,
    TestDefaultCommand,
)
from ..commands.impl.token import TokenCommand
from ..commands.impl.update import UpdateCommand
from ..commands.impl.version import BumpVersionCommand
from .registry import get_registry


def register_new_commands() -> None:
    """Register only new implementation commands that are not already registered."""
    registry = get_registry()

    # Core commands
    for cmd_class in [BuildCommand, CleanCommand, ActivateCommand, DistCommand]:
        try:
            registry.register(cmd_class)
        except ValueError:
            pass  # Command already registered

    # Test commands
    for cmd_class in [
        TestCommand,
        TestDefaultCommand,
        TestBenchmarkCommand,
        TestCoverageCommand,
        TestCoverageSlowCommand,
    ]:
        try:
            registry.register(cmd_class)
        except ValueError:
            pass  # Command already registered

    # Publish and version commands
    for cmd_class in [PublishCommand, BumpPublishCommand, BumpVersionCommand, TokenCommand]:
        try:
            registry.register(cmd_class)
        except ValueError:
            pass  # Command already registered

    # Utility commands
    for cmd_class in [LintCommand, DocCommand, UpdateCommand, InitCommand]:
        try:
            registry.register(cmd_class)
        except ValueError:
            pass  # Command already registered


def initialize_command_system() -> None:
    """Initialize the command system by registering new commands."""
    register_new_commands()


# Initialize the command system when this module is imported
initialize_command_system()
