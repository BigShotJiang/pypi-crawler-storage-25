"""Core module for MakePython."""
