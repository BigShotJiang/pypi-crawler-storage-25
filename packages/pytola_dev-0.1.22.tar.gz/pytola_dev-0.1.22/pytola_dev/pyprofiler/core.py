"""cProfile 执行引擎与数据加载器."""

from __future__ import annotations

import ast
import cProfile
import io
import logging
import pstats
import runpy
import sys
from pathlib import Path

logger = logging.getLogger(__name__)


class ProfileRunner:
    """非侵入式 cProfile 执行引擎.

    通过 cProfile.Profile 包裹 runpy 来运行目标脚本/模块, 无需修改目标代码即可收集性能数据.
    """

    @staticmethod
    def _validate_script(script: Path) -> None:
        """验证脚本文件是否可执行.

        Parameters
        ----------
        script : Path
            要验证的脚本路径

        Raises
        ------
        FileNotFoundError
            文件不存在
        ValueError
            文件格式不正确、无法执行或 Python 语法错误
        PermissionError
            文件无读取权限
        """
        # 检查文件是否存在
        if not script.exists():
            msg = f"脚本文件不存在: {script}"
            raise FileNotFoundError(msg)

        if not script.is_file():
            msg = f"不是文件: {script}"
            raise ValueError(msg)

        # 检查文件扩展名
        if script.suffix.lower() != ".py":
            msg = f"文件扩展名不是 .py: {script} (扩展名: {script.suffix})"
            raise ValueError(msg)

        # 检查文件是否可读
        try:
            with script.open("r", encoding="utf-8") as f:
                source_code = f.read()
        except PermissionError as exc:
            msg = f"文件无读取权限: {script}"
            raise PermissionError(msg) from exc
        except UnicodeDecodeError as exc:
            msg = f"文件编码错误, 无法使用 UTF-8 读取: {script}"
            raise ValueError(msg) from exc

        # 检查 Python 语法
        try:
            ast.parse(source_code, filename=str(script))
        except SyntaxError as exc:
            msg = f"Python 语法错误: {exc.msg} (文件: {script}, 行 {exc.lineno})"
            raise ValueError(msg) from exc

    @staticmethod
    def run_script(script: Path, args: list[str] | None = None) -> pstats.Stats:
        """运行并分析 Python 脚本.

        Parameters
        ----------
        script : Path
            要分析的 Python 脚本路径
        args : list[str] | None
            传递给目标脚本的命令行参数

        Returns
        -------
        pstats.Stats
            cProfile 统计数据
        """
        script = script.resolve()

        # 验证脚本是否可执行
        ProfileRunner._validate_script(script)

        args = args or []
        orig_argv = sys.argv[:]
        orig_path = sys.path[:]

        profile = cProfile.Profile()
        try:
            sys.argv = [str(script), *args]
            # 将脚本所在目录加入 sys.path, 模拟 python script.py 行为
            script_dir = str(script.parent)
            if script_dir not in sys.path:
                sys.path.insert(0, script_dir)

            profile.enable()
            try:
                runpy.run_path(str(script), run_name="__main__")
            except SystemExit:
                pass  # 目标脚本调用 sys.exit() 是正常行为
            except Exception:
                logger.exception("目标脚本执行出错, 将基于已收集的数据生成报告")
            finally:
                profile.disable()
        finally:
            sys.argv = orig_argv
            sys.path = orig_path

        stream = io.StringIO()
        return pstats.Stats(profile, stream=stream)

    @staticmethod
    def run_module(module: str, args: list[str] | None = None) -> pstats.Stats:
        """运行并分析 Python 模块.

        Parameters
        ----------
        module : str
            要分析的模块名, 如 "json.tool"
        args : list[str] | None
            传递给目标模块的命令行参数

        Returns
        -------
        pstats.Stats
            cProfile 统计数据
        """
        args = args or []
        orig_argv = sys.argv[:]

        profile = cProfile.Profile()
        try:
            sys.argv = [module, *args]
            profile.enable()
            try:
                runpy.run_module(module, run_name="__main__", alter_sys=True)
            except SystemExit:
                pass
            except Exception:
                logger.exception("目标模块执行出错, 将基于已收集的数据生成报告")
            finally:
                profile.disable()
        finally:
            sys.argv = orig_argv

        stream = io.StringIO()
        return pstats.Stats(profile, stream=stream)


class ProfileLoader:
    """加载已有的 cProfile 数据文件."""

    @staticmethod
    def load(file_path: Path) -> pstats.Stats:
        """加载 .prof 或 .pstats 文件.

        Parameters
        ----------
        file_path : Path
            cProfile 数据文件路径

        Returns
        -------
        pstats.Stats
            加载的统计数据

        Raises
        ------
        FileNotFoundError
            文件不存在
        ValueError
            文件格式无法识别
        """
        file_path = file_path.resolve()
        if not file_path.is_file():
            msg = f"文件不存在: {file_path}"
            raise FileNotFoundError(msg)

        # pstats.Stats 可以直接加载 cProfile.run(filename=...) 生成的 marshal 格式文件
        stream = io.StringIO()
        try:
            stats = pstats.Stats(str(file_path), stream=stream)
        except Exception as exc:
            msg = f"无法加载性能数据文件: {file_path}"
            raise ValueError(msg) from exc
        else:
            return stats
