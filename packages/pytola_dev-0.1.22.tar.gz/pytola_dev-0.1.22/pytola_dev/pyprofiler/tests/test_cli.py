"""Tests for the CLI module."""

import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from pytola_dev.pyprofiler.cli import _build_parser, _parse_args, main


class TestBuildParser:
    """Test cases for _build_parser function."""

    def test_parser_creation(self) -> None:
        """Test that parser is created correctly."""
        parser = _build_parser()
        assert parser is not None
        # Verify parser has the expected subcommands by parsing help
        import io
        from contextlib import redirect_stdout

        f = io.StringIO()
        with pytest.raises(SystemExit), redirect_stdout(f):
            parser.parse_args(["-h"])
        output = f.getvalue()
        assert "run" in output
        assert "load" in output

    def test_run_subcommand(self) -> None:
        """Test run subcommand parsing."""
        parser = _build_parser()
        args = parser.parse_args(["run", "script.py"])
        assert args.command == "run"
        assert args.script == Path("script.py")

    def test_load_subcommand(self) -> None:
        """Test load subcommand parsing."""
        parser = _build_parser()
        args = parser.parse_args(["load", "profile.prof"])
        assert args.command == "load"
        assert args.profile_file == Path("profile.prof")

    def test_common_options(self) -> None:
        """Test common optional arguments."""
        parser = _build_parser()
        args = parser.parse_args(
            [
                "run",
                "script.py",
                "-o",
                "output.html",
                "--no-open",
                "--top",
                "100",
                "--sort-by",
                "cumtime",
            ],
        )
        assert args.output == Path("output.html")
        assert args.no_open is True
        assert args.top_n == 100
        assert args.sort_by == "cumtime"

    def test_fuzzy_option(self) -> None:
        """Test fuzzy matching option (not applicable to profiler)."""
        parser = _build_parser()
        # Fuzzy is not a valid option for pyprofiler
        with pytest.raises(SystemExit):
            parser.parse_args(["run", "script.py", "--fuzzy"])


class TestParseArgs:
    """Test cases for _parse_args function."""

    @patch("sys.argv", ["pyprofiler", "run", "script.py"])
    def test_parse_run_command(self) -> None:
        """Test parsing run command from sys.argv."""
        config = _parse_args()
        assert config.mode == "run"
        assert config.script == Path("script.py")

    @patch("sys.argv", ["pyprofiler", "load", "profile.prof"])
    def test_parse_load_command(self) -> None:
        """Test parsing load command from sys.argv."""
        config = _parse_args()
        assert config.mode == "load"
        assert config.profile_file == Path("profile.prof")

    @patch("sys.argv", ["pyprofiler", "run", "script.py", "--debug"])
    def test_parse_debug_flag(self) -> None:
        """Test parsing debug flag."""
        config = _parse_args()
        # Debug flag sets logging level, not stored in config
        assert config.mode == "run"

    @patch("sys.argv", ["pyprofiler", "run", "-m", "json.tool"])
    def test_parse_module_mode(self) -> None:
        """Test parsing module execution mode."""
        config = _parse_args()
        assert config.mode == "run"
        assert config.module == "json.tool"

    def test_parse_with_custom_options(self) -> None:
        """Test parsing with custom options."""
        args = ["run", "script.py", "-o", "report.html", "--top", "20", "--sort-by", "cumtime"]
        config = _parse_args(args)
        assert config.output == Path("report.html")
        assert config.top_n == 20
        assert config.sort_by == "cumtime"

    def test_no_command_shows_help(self) -> None:
        """Test that running without command shows help."""
        with pytest.raises(SystemExit):
            _parse_args([])


class TestMain:
    """Test cases for main function."""

    @patch("pytola_dev.pyprofiler.cli.ProfileRunner.run_script")
    @patch("pytola_dev.pyprofiler.cli.ProfileAnalyzer.analyze")
    @patch("pytola_dev.pyprofiler.cli.ReportGenerator.generate")
    @patch("pytola_dev.pyprofiler.cli.webbrowser.open")
    def test_main_run_script(
        self,
        mock_open: MagicMock,
        mock_generate: MagicMock,
        mock_analyze: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        """Test main function with run command."""
        # Setup mocks
        mock_run.return_value = MagicMock()
        mock_analyze.return_value = MagicMock()
        mock_generate.return_value = Path(tempfile.gettempdir()) / "report.html"

        # Run main
        main(["run", "script.py", "--no-open"])

        # Verify calls
        mock_run.assert_called_once()
        mock_analyze.assert_called_once()
        mock_generate.assert_called_once()
        # Browser should not be opened with --no-open
        mock_open.assert_not_called()

    @patch("pytola_dev.pyprofiler.cli.ProfileLoader.load")
    @patch("pytola_dev.pyprofiler.cli.ProfileAnalyzer.analyze")
    @patch("pytola_dev.pyprofiler.cli.ReportGenerator.generate")
    @patch("pytola_dev.pyprofiler.cli.webbrowser.open")
    def test_main_load_profile(
        self,
        mock_open: MagicMock,
        mock_generate: MagicMock,
        mock_analyze: MagicMock,
        mock_load: MagicMock,
    ) -> None:
        """Test main function with load command."""
        # Setup mocks
        mock_load.return_value = MagicMock()
        mock_analyze.return_value = MagicMock()
        mock_generate.return_value = Path(tempfile.gettempdir()) / "report.html"

        # Run main
        main(["load", "profile.prof", "--no-open"])

        # Verify calls
        mock_load.assert_called_once()
        mock_analyze.assert_called_once()
        mock_generate.assert_called_once()

    @patch("pytola_dev.pyprofiler.cli.ProfileRunner.run_script")
    @patch("pytola_dev.pyprofiler.cli.ProfileAnalyzer.analyze")
    @patch("pytola_dev.pyprofiler.cli.ReportGenerator.generate")
    @patch("pytola_dev.pyprofiler.cli.webbrowser.open")
    def test_main_opens_browser_by_default(
        self,
        mock_open: MagicMock,
        mock_generate: MagicMock,
        mock_analyze: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        """Test that browser is opened by default."""
        mock_run.return_value = MagicMock()
        mock_analyze.return_value = MagicMock()
        mock_generate.return_value = Path(tempfile.gettempdir()) / "report.html"

        # Run without --no-open
        main(["run", "script.py"])

        # Browser should be opened
        mock_open.assert_called_once()

    @patch("pytola_dev.pyprofiler.cli.ProfileRunner.run_module")
    @patch("pytola_dev.pyprofiler.cli.ProfileAnalyzer.analyze")
    @patch("pytola_dev.pyprofiler.cli.ReportGenerator.generate")
    def test_main_run_module(
        self,
        mock_generate: MagicMock,
        mock_analyze: MagicMock,
        mock_run_module: MagicMock,
    ) -> None:
        """Test main function with module execution."""
        mock_run_module.return_value = MagicMock()
        mock_analyze.return_value = MagicMock()
        mock_generate.return_value = Path(tempfile.gettempdir()) / "report.html"

        main(["run", "-m", "json.tool", "--no-open"])

        mock_run_module.assert_called_once()

    def test_main_script_not_provided(self) -> None:
        """Test error when no script is provided."""
        with pytest.raises(SystemExit):
            main(["run"])

    def test_main_invalid_profile_file(self) -> None:
        """Test error when profile file doesn't exist."""
        with pytest.raises(FileNotFoundError):
            main(["load", "/nonexistent/profile.prof", "--no-open"])


class TestIntegration:
    """Integration tests for CLI."""

    def test_end_to_end_script_analysis(self) -> None:
        """Test complete workflow with actual script."""
        # Create a temporary script
        with tempfile.NamedTemporaryFile(encoding="utf-8", mode="w", suffix=".py", delete=False) as f:
            f.write("def compute():\n")
            f.write("    return sum(range(1000))\n")
            f.write("if __name__ == '__main__':\n")
            f.write("    compute()\n")
            temp_script = Path(f.name)

        with tempfile.NamedTemporaryFile(encoding="utf-8", mode="w", suffix=".html", delete=False) as f:
            output_path = Path(f.name)

        try:
            # Run analysis
            main(
                [
                    "run",
                    str(temp_script),
                    "-o",
                    str(output_path),
                    "--no-open",
                    "--top",
                    "10",
                ],
            )

            # Verify report was generated
            assert output_path.exists()
            assert output_path.stat().st_size > 0

            # Verify HTML content
            content = Path(output_path).read_text(encoding="utf-8")
            assert "<!DOCTYPE html>" in content
            assert "性能分析报告" in content
        finally:
            temp_script.unlink()
            output_path.unlink()

    def test_end_to_end_module_analysis(self) -> None:
        """Test complete workflow with module."""
        with tempfile.NamedTemporaryFile(encoding="utf-8", mode="w", suffix=".html", delete=False) as f:
            output_path = Path(f.name)

        try:
            # Run analysis on timeit module (simpler than json.tool)
            # Note: -o and --no-open must come before -m to avoid being parsed as script
            main(
                [
                    "run",
                    "-o",
                    str(output_path),
                    "--no-open",
                    "-m",
                    "timeit",
                    "--",
                    "-n",
                    "1",
                    "pass",
                ],
            )

            # Verify report was generated
            assert output_path.exists()
        finally:
            output_path.unlink()
