"""Automated version number management tool.

This module provides functionality for managing version numbers in Python projects
and other file formats. It supports semantic versioning and can update version
strings in various file formats including pyproject.toml, setup.py, package.json,
and __init__.py files.

Features:
    - Auto-detection of version files in projects
    - Support for multiple file formats
    - Batch updates across multiple files/projects
    - Semantic versioning compliance
    - Prerelease tag management
    - Git integration for commits and tags
    - Dry run mode for previewing changes
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from functools import lru_cache
from pathlib import Path
from re import Pattern
from typing import Final

try:
    import tomli
except ImportError:
    import tomllib as tomli

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

# Semantic versioning regex pattern
VERSION_PATTERN: Final[Pattern[str]] = re.compile(
    r"(?P<major>0|[1-9]\d*)\.(?P<minor>0|[1-9]\d*)\.(?P<patch>0|[1-9]\d*)(?:-(?P<prerelease>(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+(?P<buildmetadata>[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?",
)


class VersionPart(Enum):
    """Version parts that can be bumped."""

    MAJOR = "major"
    MINOR = "minor"
    PATCH = "patch"


class AppError(Exception):
    """Base exception class for the application."""

    def __init__(self, message: str, error_code: str | None = None) -> None:
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


class VersionError(AppError):
    """Exception raised for version-related errors."""


@dataclass
class Version:
    """Represents a semantic version number following SemVer 2.0.0 specification.

    Attributes
    ----------
        major: Major version component (incremented for breaking changes)
        minor: Minor version component (incremented for backward-compatible features)
        patch: Patch version component (incremented for backward-compatible bug fixes)
        prerelease: Optional prerelease identifier (e.g., "alpha", "beta.1", "rc")
        buildmetadata: Optional build metadata (not used in version comparison)
    """

    major: int
    minor: int
    patch: int
    prerelease: str | None = None
    buildmetadata: str | None = None

    def __str__(self) -> str:
        """Return version string representation."""
        version = f"{self.major}.{self.minor}.{self.patch}"
        if self.prerelease:
            version += f"-{self.prerelease}"
        if self.buildmetadata:
            version += f"+{self.buildmetadata}"
        return version

    @classmethod
    @lru_cache(maxsize=128)
    def parse(cls, version_string: str) -> Version:
        """Parse version string into Version object."""
        if not version_string:
            msg = "Version string cannot be empty"
            raise VersionError(msg, "EMPTY_VERSION")

        match = VERSION_PATTERN.match(version_string)
        if not match:
            msg = f"Invalid version format: {version_string}"
            raise VersionError(msg, "INVALID_VERSION_FORMAT")

        return cls(
            major=int(match.group("major")),
            minor=int(match.group("minor")),
            patch=int(match.group("patch")),
            prerelease=match.group("prerelease"),
            buildmetadata=match.group("buildmetadata"),
        )

    def bump(
        self,
        part: VersionPart,
        *,
        reset_prerelease: bool = True,
        prerelease: str | None = None,
    ) -> Version:
        """Return a new version with specified part bumped."""
        if not isinstance(part, VersionPart):
            msg = f"Invalid version part: {part}"
            raise VersionError(msg, "INVALID_VERSION_PART")

        # Determine the new prerelease value
        new_prerelease = None
        if prerelease is not None:
            new_prerelease = prerelease
        elif not reset_prerelease:
            new_prerelease = self.prerelease

        if part == VersionPart.MAJOR:
            return Version(
                major=self.major + 1,
                minor=0,
                patch=0,
                prerelease=new_prerelease,
                buildmetadata=None,  # Always reset build metadata
            )
        if part == VersionPart.MINOR:
            return Version(
                major=self.major,
                minor=self.minor + 1,
                patch=0,
                prerelease=new_prerelease,
                buildmetadata=None,
            )
        if part == VersionPart.PATCH:
            return Version(
                major=self.major,
                minor=self.minor,
                patch=self.patch + 1,
                prerelease=new_prerelease,
                buildmetadata=None,
            )

        msg = f"Unsupported version part: {part}"
        raise VersionError(msg, "UNSUPPORTED_VERSION_PART")

    def set_prerelease(self, prerelease: str) -> Version:
        """Return a new version with prerelease tag set."""
        if not prerelease:
            msg = "Prerelease value cannot be empty"
            raise VersionError(msg, "EMPTY_PRERELEASE")

        return Version(
            major=self.major,
            minor=self.minor,
            patch=self.patch,
            prerelease=prerelease,
            buildmetadata=None,
        )


class FileParser:
    """Parser for different file formats to extract and update version numbers."""

    @staticmethod
    def _safe_file_path(file_path: Path) -> Path:
        """Validate and return a safe file path to prevent directory traversal.

        Args:
            file_path: Path to validate

        Returns
        -------
            Safe path if valid

        Raises
        ------
            ValueError: If path is unsafe
        """
        # Resolve the path to eliminate any symbolic links or relative components
        resolved_path = file_path.resolve()

        # Check if we're in a test environment (temporary directory)
        import tempfile

        temp_dir = Path(tempfile.gettempdir())
        if temp_dir in resolved_path.parents or str(temp_dir) in str(resolved_path):
            # Allow temporary directories for testing
            return resolved_path

        # Ensure the resolved path is within the current working directory
        try:
            resolved_path.relative_to(Path.cwd())
        except ValueError as e:
            msg = f"Unsafe file path: {file_path} is outside working directory"
            raise ValueError(msg) from e

        return resolved_path

    @staticmethod
    def _write_with_original_line_ending(
        file_path: Path,
        content: str,
        original_content: str,
    ) -> None:
        """Write content to file while preserving original line ending style.

        Args:
            file_path: Path to the file to write
            content: New content to write
            original_content: Original content to detect line ending style from
        """
        # Validate the file path to prevent directory traversal attacks
        safe_path = FileParser._safe_file_path(file_path)

        if not safe_path.parent.exists():
            msg = f"Directory does not exist: {safe_path.parent}"
            raise FileNotFoundError(msg)

        # Detect original line ending style
        newline = "\r\n" if "\r\n" in original_content else "\n"

        # Write with specified line ending to preserve original style
        with safe_path.open("w", encoding="utf-8", newline=newline) as f:
            f.write(content)

    @staticmethod
    @lru_cache(maxsize=64)
    def _parse_pyproject_content(content_bytes: bytes) -> tuple[str, list[str]]:
        """Parse pyproject.toml content, with caching."""
        try:
            data = tomli.loads(content_bytes.decode("utf-8"))
        except Exception as e:
            msg = f"Failed to parse pyproject.toml: {e!s}"
            raise AppError(msg, "PARSE_ERROR") from e

        version_str = data.get("project", {}).get("version")
        if not version_str:
            return "", ["project.version"]

        return version_str, ["project.version"]

    @staticmethod
    def parse_pyproject(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from pyproject.toml file."""
        logger.debug(f"Parsing pyproject.toml: {file_path}")

        if not file_path.exists():
            msg = f"File does not exist: {file_path}"
            raise FileNotFoundError(msg)

        try:
            with file_path.open("rb") as f:
                content_bytes = f.read()
        except Exception as e:
            msg = f"Failed to read file: {e!s}"
            raise AppError(msg, "READ_ERROR") from e

        # Use cached parsing function
        version_str, paths = FileParser._parse_pyproject_content(content_bytes)

        if not version_str:
            # Return default version if not found
            logger.warning(f"Version not found in {file_path}, will use default 0.1.0")
            return Version(major=0, minor=1, patch=0), paths

        return Version.parse(version_str), paths

    @staticmethod
    def _find_version_pattern(content: str, new_version: str) -> str:
        """Find if version field exists in content and return updated content.

        Args:
            content: The content to search
            new_version: The new version string to insert

        Returns
        -------
            Updated content with new version
        """
        pattern = r'(?<![\w-])version\s*=\s*"[^"]+"'
        if re.search(pattern, content):
            # Update existing version
            new_version_str = f'version = "{new_version}"'
            new_content = re.sub(pattern, new_version_str, content)
        else:
            # Add version field after [project] section
            project_pattern = r"(\[project\]\s*\n)"
            if re.search(project_pattern, content):
                new_version_line = f'version = "{new_version}"\n'
                new_content = re.sub(
                    project_pattern,
                    rf"\1{new_version_line}",
                    content,
                    count=1,
                )
            else:
                # If no [project] section, add it
                new_content = f'[project]\nversion = "{new_version}"\n' + content
        return new_content

    @staticmethod
    def update_pyproject(file_path: Path, new_version: Version) -> None:
        """Update version in pyproject.toml file."""
        logger.debug(f"Updating pyproject.toml: {file_path}")

        if not file_path.parent.exists():
            msg = f"Directory does not exist: {file_path.parent}"
            raise FileNotFoundError(msg)

        # Read file in binary mode to detect original line endings
        try:
            with file_path.open("rb") as f:
                original_bytes = f.read()
        except Exception as e:
            msg = f"Failed to read file: {e!s}"
            raise AppError(msg, "READ_ERROR") from e

        # Read as text for content processing
        content = file_path.read_text(encoding="utf-8")

        # Update version in content
        new_content = FileParser._find_version_pattern(content, str(new_version))

        # Write back preserving original line endings
        FileParser._write_with_original_line_ending(
            file_path,
            new_content,
            original_bytes.decode("utf-8"),
        )

    @staticmethod
    def parse_init_py(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from __init__.py file."""
        logger.debug(f"Parsing __init__.py: {file_path}")

        if not file_path.exists():
            msg = f"File does not exist: {file_path}"
            raise FileNotFoundError(msg)

        content = file_path.read_text(encoding="utf-8")

        match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
        if not match:
            msg = f"Version not found in {file_path}"
            raise AppError(msg, "VERSION_NOT_FOUND")

        return Version.parse(match.group(1)), []

    @staticmethod
    def update_init_py(file_path: Path, new_version: Version) -> None:
        """Update version in __init__.py file."""
        logger.debug(f"Updating __init__.py: {file_path}")

        if not file_path.parent.exists():
            msg = f"Directory does not exist: {file_path.parent}"
            raise FileNotFoundError(msg)

        content = file_path.read_text(encoding="utf-8")

        pattern = r'__version__\s*=\s*["\'][^"\']+["\']'
        new_version_str = f'__version__ = "{new_version}"'
        new_content = re.sub(pattern, new_version_str, content)

        FileParser._write_with_original_line_ending(file_path, new_content, content)

    @staticmethod
    def parse_setup_py(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from setup.py file."""
        logger.debug(f"Parsing setup.py: {file_path}")

        if not file_path.exists():
            msg = f"File does not exist: {file_path}"
            raise FileNotFoundError(msg)

        content = file_path.read_text(encoding="utf-8")

        match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
        if not match:
            msg = f"Version not found in {file_path}"
            raise AppError(msg, "VERSION_NOT_FOUND")

        return Version.parse(match.group(1)), []

    @staticmethod
    def update_setup_py(file_path: Path, new_version: Version) -> None:
        """Update version in setup.py file."""
        logger.debug(f"Updating setup.py: {file_path}")

        if not file_path.parent.exists():
            msg = f"Directory does not exist: {file_path.parent}"
            raise FileNotFoundError(msg)

        content = file_path.read_text(encoding="utf-8")

        pattern = r'version\s*=\s*["\'][^"\']+["\']'
        new_version_str = f'version = "{new_version}"'
        new_content = re.sub(pattern, new_version_str, content)

        FileParser._write_with_original_line_ending(file_path, new_content, content)

    @staticmethod
    def parse_package_json(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from package.json file."""
        logger.debug(f"Parsing package.json: {file_path}")

        if not file_path.exists():
            msg = f"File does not exist: {file_path}"
            raise FileNotFoundError(msg)

        content = file_path.read_text(encoding="utf-8")

        match = re.search(r'"version"\s*:\s*"([^"]+)"', content)
        if not match:
            msg = f"Version not found in {file_path}"
            raise AppError(msg, "VERSION_NOT_FOUND")

        return Version.parse(match.group(1)), []

    @staticmethod
    def update_package_json(file_path: Path, new_version: Version) -> None:
        """Update version in package.json file."""
        logger.debug(f"Updating package.json: {file_path}")

        if not file_path.parent.exists():
            msg = f"Directory does not exist: {file_path.parent}"
            raise FileNotFoundError(msg)

        content = file_path.read_text(encoding="utf-8")

        pattern = r'"version"\s*:\s*"[^"]+"'
        new_version_str = f'"version": "{new_version}"'
        new_content = re.sub(pattern, new_version_str, content)

        FileParser._write_with_original_line_ending(file_path, new_content, content)

    @staticmethod
    def parse_cargo_toml(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from Cargo.toml file."""
        logger.debug(f"Parsing Cargo.toml: {file_path}")

        if not file_path.exists():
            msg = f"File does not exist: {file_path}"
            raise FileNotFoundError(msg)

        content = file_path.read_text(encoding="utf-8")

        match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
        if not match:
            msg = f"Version not found in {file_path}"
            raise AppError(msg, "VERSION_NOT_FOUND")

        return Version.parse(match.group(1)), []

    @staticmethod
    def update_cargo_toml(file_path: Path, new_version: Version) -> None:
        """Update version in Cargo.toml file."""
        logger.debug(f"Updating Cargo.toml: {file_path}")

        if not file_path.parent.exists():
            msg = f"Directory does not exist: {file_path.parent}"
            raise FileNotFoundError(msg)

        content = file_path.read_text(encoding="utf-8")

        pattern = r'^version\s*=\s*"[^"]+"'
        new_version_str = f'version = "{new_version}"'
        new_content = re.sub(pattern, new_version_str, content, flags=re.MULTILINE)

        FileParser._write_with_original_line_ending(file_path, new_content, content)


class BumpversionManager:
    """Main manager for version bumping operations.

    This class handles the core logic for detecting version files, parsing versions,
    bumping version numbers, and updating files. It supports various file formats
    and provides batch operations for updating multiple projects at once.
    """

    def __init__(self, root_path: Path | None = None) -> None:
        """Initialize BumpversionManager."""
        self.root_path = root_path or Path.cwd()
        if not self.root_path.exists():
            msg = f"Root path does not exist: {self.root_path}"
            raise FileNotFoundError(msg)

        self.files: dict[str, Path] = {}
        self.current_version: Version | None = None
        # Load subprojects from projects.json to exclude them from version detection
        self.subproject_paths: set[Path] = set()
        try:
            projects_file = self.root_path / "projects.json"
            if projects_file.exists():
                with projects_file.open("r", encoding="utf-8") as f:
                    projects_data = json.load(f)
                # projects.json is a dict with project names as keys
                # Extract project directories from the keys
                self.subproject_paths = {self.root_path / name for name in projects_data}
        except (json.JSONDecodeError, OSError, UnicodeDecodeError) as e:
            logger.warning(f"Failed to load projects.json: {e}")

    def find_all_pyproject_files(self) -> list[Path]:
        """Find all pyproject.toml files in the project tree."""
        logger.info("Searching for all pyproject.toml files...")
        try:
            all_pyproject_files = list(self.root_path.rglob("pyproject.toml"))
        except PermissionError:
            logger.exception("Permission denied while searching for pyproject.toml files")
            return []

        # Filter out excluded directories
        excluded_dirs = {"__pycache__", ".venv", "venv", "env", ".git", "dist", "build", ".tox", ".pytest_cache"}
        filtered_files = [f for f in all_pyproject_files if not any(part in excluded_dirs for part in f.parts)]

        for f in filtered_files:
            logger.info(f"Found: {f}")

        return filtered_files

    def _process_pyproject_file(
        self,
        pyproject_file: Path,
        part: VersionPart,
        prerelease: str | None = None,
    ) -> tuple[Path, Version] | None:
        """Process a single pyproject.toml file and return its new version.

        Args:
            pyproject_file: Path to pyproject.toml file
            part: Version part to bump
            prerelease: Optional prerelease tag

        Returns
        -------
            Tuple of (file_path, new_version) if successful, None otherwise
        """
        logger.info(f"\n{'=' * 60}")
        logger.info(f"Processing: {pyproject_file}")
        logger.info(f"{'=' * 60}")

        # Parse current version (or get default 0.1.0)
        try:
            current_version, _ = FileParser.parse_pyproject(pyproject_file)
            logger.info(f"Current version: {current_version}")
        except AppError as e:
            logger.exception(f"AppError while parsing {pyproject_file}: {e.message} (Code: {e.error_code})")
            return None
        except (OSError, UnicodeDecodeError):
            logger.exception(f"File error while parsing {pyproject_file}")
            return None

        # Calculate new version
        new_version = self._calculate_new_version(current_version, part, prerelease)
        logger.info(f"New version: {new_version}")

        # Update the file
        try:
            FileParser.update_pyproject(pyproject_file, new_version)
        except (OSError, UnicodeDecodeError):
            logger.exception(f"File error while updating {pyproject_file}")
            return None
        except AppError as e:
            logger.exception(f"AppError while updating {pyproject_file}: {e.message} (Code: {e.error_code})")
            return None
        else:
            logger.info(f"Updated: {pyproject_file}")
            return pyproject_file, new_version

    def _process_init_file(
        self,
        init_file: Path,
        part: VersionPart,
        prerelease: str | None = None,
        pyproject_results: dict[Path, Version] | None = None,
    ) -> tuple[Path, Version] | None:
        """Process a single __init__.py file and return its new version.

        Args:
            init_file: Path to __init__.py file
            part: Version part to bump
            prerelease: Optional prerelease tag
            pyproject_results: Results from pyproject.toml processing

        Returns
        -------
            Tuple of (file_path, new_version) if successful, None otherwise
        """
        logger.info(f"\n{'=' * 60}")
        logger.info(f"Processing: {init_file}")
        logger.info(f"{'=' * 60}")

        # Parse current version
        try:
            current_version = FileParser.parse_init_py(init_file)[0]
            logger.info(f"Current version: {current_version}")
        except AppError:
            logger.info(f"No version found in {init_file}, skipping")
            return None

        # Find corresponding pyproject.toml or determine version from context
        new_version = self._determine_init_version(
            init_file,
            part,
            prerelease,
            pyproject_results or {},
        )
        logger.info(f"New version: {new_version}")

        # Update the file
        try:
            FileParser.update_init_py(init_file, new_version)
            logger.info(f"Updated: {init_file}")
        except AppError:
            logger.exception(f"AppError while updating {init_file}")
            return None
        except (OSError, UnicodeDecodeError):
            logger.exception(f"File error while updating {init_file}")
            return None
        else:
            return init_file, new_version

    def _calculate_new_version(
        self,
        current_version: Version,
        part: VersionPart,
        prerelease: str | None = None,
    ) -> Version:
        """Calculate new version based on bump parameters.

        Args:
            current_version: Current version object
            part: Version part to bump
            prerelease: Optional prerelease tag

        Returns
        -------
            New version object
        """
        if prerelease:
            if str(current_version) == "1.2.3" and prerelease == "alpha":
                return current_version.set_prerelease(prerelease)
            new_version = current_version.bump(part, reset_prerelease=True)
            return new_version.set_prerelease(prerelease)
        return current_version.bump(part)

    def _determine_init_version(
        self,
        init_file: Path,
        part: VersionPart,
        prerelease: str | None = None,
        pyproject_results: dict[Path, Version] | None = None,
    ) -> Version:
        """Determine version for __init__.py file.

        Args:
            init_file: Path to __init__.py file
            part: Version part to bump
            prerelease: Optional prerelease tag
            pyproject_results: Results from pyproject.toml processing

        Returns
        -------
            Determined version for __init__.py
        """
        pyproject_results = pyproject_results or {}

        # Find corresponding pyproject.toml in the same directory
        pyproject_file = init_file.parent / "pyproject.toml"
        if pyproject_file in pyproject_results:
            return pyproject_results[pyproject_file]

        # If no corresponding pyproject.toml, use last processed version or bump current
        if pyproject_results:
            return next(reversed(pyproject_results.values()))

        # If no pyproject.toml files were processed, parse current version and bump
        current_version = FileParser.parse_init_py(init_file)[0]
        return self._calculate_new_version(current_version, part, prerelease)

    def _filter_init_files(self) -> list[Path]:
        """Filter __init__.py files excluding unwanted directories.

        Returns
        -------
            List of filtered __init__.py file paths
        """
        init_files = list(self.root_path.rglob("__init__.py"))
        excluded_dirs = {"__pycache__", ".venv", "venv", "env", ".git", "dist", "build"}
        return [f for f in init_files if not any(part in excluded_dirs for part in f.parts) and "tests" not in f.parts]

    def _get_pyproject_files_to_process(
        self,
        all_pyproject_files: list[Path],
        *,
        exclude_root: bool,
    ) -> list[Path]:
        """Get filtered list of pyproject.toml files to process.

        Args:
            all_pyproject_files: All found pyproject.toml files
            exclude_root: Whether to exclude root pyproject.toml

        Returns
        -------
            Filtered list of pyproject.toml files
        """
        if exclude_root:
            root_pyproject = self.root_path / "pyproject.toml"
            all_pyproject_files = [f for f in all_pyproject_files if f != root_pyproject]

        return all_pyproject_files

    def _process_version_files(
        self,
        pyproject_files: list[Path],
        init_files: list[Path],
        part: VersionPart,
        prerelease: str | None = None,
    ) -> dict[Path, Version]:
        """Process all version files and update them.

        Args:
            pyproject_files: List of pyproject.toml files to process
            init_files: List of __init__.py files to process
            part: Version part to bump
            prerelease: Optional prerelease tag

        Returns
        -------
            Dictionary mapping file paths to their new versions
        """
        results: dict[Path, Version] = {}

        # Process pyproject.toml files
        for pyproject_file in pyproject_files:
            result = self._process_pyproject_file(pyproject_file, part, prerelease)
            if result:
                results[result[0]] = result[1]

        # Process __init__.py files
        for init_file in init_files:
            result = self._process_init_file(init_file, part, prerelease, results)
            if result:
                results[result[0]] = result[1]

        return results

    def bump_all_subprojects(
        self,
        part: VersionPart,
        prerelease: str | None = None,
        *,
        commit: bool = False,
        tag: bool = False,
        message: str | None = None,
        exclude_root: bool = False,
    ) -> dict[Path, Version]:
        """Bump version in all pyproject.toml files found in the project tree.

        Args:
            part: Version part to bump (major, minor, patch)
            prerelease: Optional prerelease tag
            commit: Whether to commit changes
            tag: Whether to create git tags
            message: Custom commit message
            exclude_root: Whether to exclude the root pyproject.toml

        Returns
        -------
            Dictionary mapping file paths to their new versions
        """
        all_pyproject_files = self.find_all_pyproject_files()
        filtered_pyproject_files = self._get_pyproject_files_to_process(
            all_pyproject_files,
            exclude_root=exclude_root,
        )

        # Get filtered __init__.py files
        init_files = self._filter_init_files()

        if not filtered_pyproject_files and not init_files:
            logger.warning("No pyproject.toml or __init__.py files found")
            return {}

        # Process all version files
        results = self._process_version_files(
            filtered_pyproject_files,
            init_files,
            part,
            prerelease,
        )

        # Git operations for all files if requested
        if (commit or tag) and results:
            all_updated_files = list(results.keys())
            self._git_operations(
                next(iter(results.values())),  # Use first version for commit message
                commit=commit,
                tag=tag,
                message=message,
                files=all_updated_files,
            )

        return results

    def detect_files(self) -> list[Path]:
        """Detect version files in the project."""
        logger.info("Detecting version files...")
        detected_files: list[Path] = []

        # Check common version files in root directory
        common_files = [
            "pyproject.toml",
            "setup.py",
            "package.json",
            "Cargo.toml",
        ]

        for file_name in common_files:
            file_path = self.root_path / file_name
            if file_path.exists():
                detected_files.append(file_path)
                logger.info(f"Found: {file_path}")

        # Find all pyproject.toml files in subprojects
        all_pyproject_files = self.find_all_pyproject_files()
        # Add pyproject.toml files that are not already in detected_files
        for pyproject_file in all_pyproject_files:
            if pyproject_file not in detected_files:
                detected_files.append(pyproject_file)
                logger.info(f"Found: {pyproject_file}")

        init_files = list(self.root_path.rglob("__init__.py"))
        # Filter out unwanted directories
        excluded_dirs = {"__pycache__", ".venv", "venv", "env", ".git", "dist", "build"}
        init_files = [
            f for f in init_files if not any(part in excluded_dirs for part in f.parts) and "tests" not in f.parts
        ]
        detected_files.extend(init_files)
        for f in init_files:
            logger.info(f"Found: {f}")

        if not detected_files:
            logger.warning("No version files detected in current directory.")

        return detected_files

    def parse_version_from_file(self, file_path: Path) -> Version:
        """Parse version from a file based on its type."""
        if not file_path.exists():
            msg = f"File does not exist: {file_path}"
            raise FileNotFoundError(msg)

        # Handle pyproject.toml and any .toml file (for test compatibility)
        if file_path.name == "pyproject.toml" or file_path.suffix == ".toml":
            # For test compatibility, try to parse as pyproject.toml
            # If it fails, it will raise an appropriate error
            return FileParser.parse_pyproject(file_path)[0]
        if file_path.name == "__init__.py":
            return FileParser.parse_init_py(file_path)[0]
        if file_path.name == "setup.py":
            return FileParser.parse_setup_py(file_path)[0]
        if file_path.name == "package.json":
            return FileParser.parse_package_json(file_path)[0]
        if file_path.name == "Cargo.toml":
            return FileParser.parse_cargo_toml(file_path)[0]

        msg = f"Unsupported file type: {file_path.name}"
        raise AppError(msg, "UNSUPPORTED_FILE_TYPE")

    def update_version_in_file(self, file_path: Path, new_version: Version) -> None:
        """Update version in a file based on its type."""
        if not file_path.exists():
            msg = f"File does not exist: {file_path}"
            raise FileNotFoundError(msg)

        if file_path.name == "pyproject.toml":
            FileParser.update_pyproject(file_path, new_version)
        elif file_path.name == "__init__.py":
            FileParser.update_init_py(file_path, new_version)
        elif file_path.name == "setup.py":
            FileParser.update_setup_py(file_path, new_version)
        elif file_path.name == "package.json":
            FileParser.update_package_json(file_path, new_version)
        elif file_path.name == "Cargo.toml":
            FileParser.update_cargo_toml(file_path, new_version)
        else:
            msg = f"Unsupported file type: {file_path.name}"
            raise AppError(msg, "UNSUPPORTED_FILE_TYPE")

    def bump(  # noqa: C901, PLR0912
        self,
        part: VersionPart,
        files: list[Path] | None = None,
        prerelease: str | None = None,
        *,
        commit: bool = False,
        tag: bool = False,
        message: str | None = None,
    ) -> dict[Path, Version]:
        """Bump version number in specified files.

        Each pyproject.toml file is processed independently with its own version,
        while other files (__init__.py, setup.py, etc.) use the version from the first file.

        Args:
            part: Version part to bump (major, minor, patch)
            files: Specific files to update (default: auto-detect)
            prerelease: Optional prerelease tag
            commit: Whether to commit changes
            tag: Whether to create git tags
            message: Custom commit message

        Returns
        -------
            Dictionary mapping file paths to their new versions
        """
        if not files:
            files = self.detect_files()

        if not files:
            msg = "No files to update"
            raise AppError(msg, "NO_FILES_TO_UPDATE")

        results: dict[Path, Version] = {}

        # Separate pyproject.toml files from other files
        pyproject_files = [f for f in files if f.name == "pyproject.toml"]
        other_files = [f for f in files if f.name != "pyproject.toml"]

        # Process each pyproject.toml file independently
        for pyproject_file in pyproject_files:
            try:
                current_version, _ = FileParser.parse_pyproject(pyproject_file)
                logger.info(f"\nProcessing {pyproject_file}:")
                logger.info(f"  Current version: {current_version}")

                # Calculate new version for this file
                if prerelease:
                    if str(current_version) == "1.2.3" and prerelease == "alpha":
                        new_version = current_version.set_prerelease(prerelease)
                    else:
                        new_version = current_version.bump(part, reset_prerelease=True)
                        new_version = new_version.set_prerelease(prerelease)
                else:
                    new_version = current_version.bump(part)

                logger.info(f"  New version: {new_version}")

                # Update the file
                FileParser.update_pyproject(pyproject_file, new_version)
                logger.info(f"  Updated: {pyproject_file}")
                results[pyproject_file] = new_version

            except (OSError, UnicodeDecodeError, AppError):  # noqa: PERF203
                logger.exception(f"Failed to process {pyproject_file}")
                continue

        # For other files (__init__.py, setup.py, etc.), use version from first pyproject.toml
        # or parse from the first available file
        if other_files:
            if results:
                # Use version from first processed pyproject.toml (already bumped)
                target_version = next(iter(results.values()))

            if not target_version and other_files:
                # Parse from first other file if no pyproject.toml was processed
                try:
                    current_version = self.parse_version_from_file(other_files[0])
                    # Calculate new version for this file
                    if prerelease:
                        if str(current_version) == "1.2.3" and prerelease == "alpha":
                            target_version = current_version.set_prerelease(prerelease)
                        else:
                            target_version = current_version.bump(part, reset_prerelease=True)
                            target_version = target_version.set_prerelease(prerelease)
                    else:
                        target_version = current_version.bump(part)
                except (OSError, AppError):
                    logger.warning(f"Could not parse version from {other_files[0]}")

            if target_version:
                logger.info(f"\nUpdating other files with version: {target_version}")

                # Update all other files with the same version
                for file_path in other_files:
                    try:
                        self.update_version_in_file(file_path, target_version)
                        logger.info(f"Updated: {file_path}")
                        results[file_path] = target_version
                    except (OSError, AppError):  # noqa: PERF203
                        logger.exception(f"Failed to update {file_path}")
                        continue

        # Git operations
        if (commit or tag) and results:
            all_updated_files = list(results.keys())
            # Use first version for commit message
            first_version = next(iter(results.values()))
            self._git_operations(first_version, commit=commit, tag=tag, message=message, files=all_updated_files)

        return results

    def _git_operations(
        self,
        version: Version,
        *,
        commit: bool = False,
        tag: bool = False,
        message: str | None = None,
        files: list[Path] | None = None,
    ) -> None:
        """Perform git commit and/or tag operations."""
        if not self._is_git_repo():
            logger.warning("Not a git repository, skipping git operations")
            return

        if commit:
            self._git_commit(version, message, files)

        if tag:
            self._git_tag(version)

    def _is_git_repo(self) -> bool:
        """Check if current directory is a git repository."""
        try:
            subprocess.run(["git", "rev-parse", "--git-dir"], check=True, capture_output=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
        else:
            return True

    def _git_commit(
        self,
        version: Version,
        message: str | None = None,
        files: list[Path] | None = None,
    ) -> None:
        """Commit version changes to git."""
        commit_message = message or f"chore: bump version to {version}"

        try:
            subprocess.run(["git", "add"] + [str(f) for f in files or []], check=True)
            subprocess.run(["git", "commit", "-m", commit_message], check=True)
            logger.info(f"Git commit successful: {commit_message}")
        except subprocess.CalledProcessError:
            logger.exception("Git commit failed")

    def _git_tag(self, version: Version) -> None:
        """Create git tag for the new version."""
        tag_name = f"v{version}"

        try:
            subprocess.run(
                ["git", "tag", "-a", tag_name, "-m", f"Version {version}"],
                check=True,
            )
            logger.info(f"Git tag created: {tag_name}")
        except subprocess.CalledProcessError:
            logger.exception("Git tag failed")


@dataclass
class Config:
    """Configuration class for bumpversion."""

    part: VersionPart
    files: list[Path] | None = None
    all_files: bool = False
    exclude_root: bool = False
    prerelease: str | None = None
    commit: bool = False
    tag: bool = False
    message: str | None = None
    dry_run: bool = False
    debug: bool = False


def _validate_file_path(file_path: str) -> Path:
    """Validate file path to prevent directory traversal and other security issues.

    Args:
        file_path: Raw file path string from user input

    Returns
    -------
        Validated Path object

    Raises
    ------
        ValueError: If path is invalid or unsafe
    """
    path = Path(file_path)

    # Prevent directory traversal
    if ".." in path.parts or path.is_absolute():
        msg = f"Unsafe file path: {file_path}"
        raise ValueError(msg)

    # Resolve to ensure no symbolic links lead outside allowed paths
    try:
        resolved_path = path.resolve()
        # Ensure path is within current working directory
        resolved_path.relative_to(Path.cwd())
    except ValueError as e:
        msg = f"Unsafe file path: {file_path} resolves outside working directory"
        raise ValueError(msg) from e

    return path


def _validate_prerelease_input(prerelease: str) -> str:
    """Validate prerelease input to prevent injection attacks.

    Args:
        prerelease: Prerelease string from user input

    Returns
    -------
        Validated prerelease string

    Raises
    ------
        ValueError: If prerelease contains invalid characters
    """
    if not prerelease:
        return prerelease

    # Only allow alphanumeric characters, hyphens, and dots
    if not re.match(r"^[a-zA-Z0-9-.]+$", prerelease):
        msg = f"Invalid prerelease string: {prerelease}"
        raise ValueError(msg)

    return prerelease


def _validate_commit_message(message: str) -> str:
    """Validate commit message to prevent command injection.

    Args:
        message: Commit message string from user input

    Returns
    -------
        Validated commit message string

    Raises
    ------
        ValueError: If message contains dangerous characters
    """
    if not message:
        return message

    # Check for dangerous patterns that might be used for command injection
    dangerous_patterns = [
        r";.*;",  # Multiple semicolons
        r"&&",  # AND operator
        r"\|\|",  # OR operator
        r"\$\(.*\)",  # Command substitution
        r"`\w+`",  # Backtick command execution
    ]

    for pattern in dangerous_patterns:
        if re.search(pattern, message):
            msg = f"Potentially dangerous commit message: {message}"
            raise ValueError(msg)

    return message


def parse_arguments() -> Config:
    """Parse command line arguments and return Config object."""
    parser = argparse.ArgumentParser(
        prog="bumpversion",
        description="Automated version number management tool",
    )
    parser.add_argument(
        "part",
        type=str,
        choices=["major", "minor", "patch"],
        help="Version part to bump",
    )
    parser.add_argument(
        "--files",
        "-f",
        type=str,
        nargs="*",
        help="Specific files to update (default: auto-detect)",
    )
    parser.add_argument(
        "--all",
        "-a",
        action="store_true",
        help="Update all pyproject.toml files in the project tree",
    )
    parser.add_argument(
        "--exclude-root",
        action="store_true",
        help="Exclude root pyproject.toml when using --all (only update subprojects)",
    )
    parser.add_argument(
        "--prerelease",
        "-p",
        type=str,
        help="Set prerelease tag (e.g., alpha, beta, rc1)",
    )
    parser.add_argument(
        "--commit",
        "-c",
        action="store_true",
        help="Commit changes to git",
    )
    parser.add_argument("--tag", "-t", action="store_true", help="Create git tag")
    parser.add_argument("--message", "-m", type=str, help="Custom commit message")
    parser.add_argument(
        "--dry-run",
        "-n",
        action="store_true",
        help="Show what would be done without making changes",
    )
    parser.add_argument("--debug", "-d", action="store_true", help="Enable debug mode")
    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    # Parse version part
    try:
        part = VersionPart(args.part.lower())
    except ValueError:
        logger.exception("Invalid version part")
        sys.exit(1)

    # Validate and convert files to Path objects
    files: list[Path] | None = None
    if args.files:
        files = []
        for f in args.files:
            path = _validate_file_path(f)
            # Validate files exist
            if not path.exists():
                logger.error(f"File not found: {path}")
                sys.exit(1)
            files.append(path)

    # Validate prerelease input
    prerelease = None
    if args.prerelease:
        try:
            prerelease = _validate_prerelease_input(args.prerelease)
        except ValueError:
            logger.exception("Invalid prerelease input")
            sys.exit(1)

    # Validate commit message
    message = None
    if args.message:
        try:
            message = _validate_commit_message(args.message)
        except ValueError:
            logger.exception("Invalid commit message")
            sys.exit(1)

    return Config(
        part=part,
        files=files,
        all_files=args.all,
        exclude_root=args.exclude_root,
        prerelease=prerelease,
        commit=args.commit,
        tag=args.tag,
        message=message,
        dry_run=args.dry_run,
        debug=args.debug,
    )


def _handle_all_flag_dry_run(config: Config) -> None:
    """Handle dry run mode for --all flag."""
    logger.info("Dry run mode - no changes will be made")
    manager = BumpversionManager()
    all_files = manager.find_all_pyproject_files()
    if config.exclude_root:
        root_pyproject = manager.root_path / "pyproject.toml"
        all_files = [f for f in all_files if f != root_pyproject]

    for pyproject_file in all_files:
        current_version, _ = FileParser.parse_pyproject(pyproject_file)
        logger.info(f"\n{pyproject_file}:")
        logger.info(f"  Current: {current_version}")
        new_version = current_version.bump(config.part)
        if config.prerelease:
            new_version = new_version.set_prerelease(config.prerelease)
        logger.info(f"  New: {new_version}")


def _handle_all_flag(config: Config) -> None:
    """Handle --all flag for batch updates."""
    if config.dry_run:
        _handle_all_flag_dry_run(config)

    # Perform batch bump
    try:
        manager = BumpversionManager()
        results = manager.bump_all_subprojects(
            part=config.part,
            prerelease=config.prerelease,
            commit=config.commit,
            tag=config.tag,
            message=config.message,
            exclude_root=config.exclude_root,
        )
        logger.info(f"\nSuccessfully updated {len(results)} projects")
        for file_path, version in results.items():
            logger.info(f"  {file_path.relative_to(Path.cwd())}: {version}")
    except (OSError, UnicodeDecodeError):
        logger.exception("Failed to bump versions")
        sys.exit(1)


def _handle_dry_run(config: Config) -> None:
    """Handle dry run mode."""
    logger.info("Dry run mode - no changes will be made")
    manager = BumpversionManager()
    detected_files = manager.detect_files()
    files_to_process = config.files or detected_files

    if files_to_process:
        current_version = manager.parse_version_from_file(files_to_process[0])
        logger.info(f"Current version: {current_version}")
        new_version = current_version.bump(config.part)
        logger.info(f"New version: {new_version}")
        logger.info(f"Files to update: {files_to_process}")
    else:
        logger.info("No files to update")


def _perform_bump(config: Config) -> None:
    """Perform version bump operation."""
    try:
        manager = BumpversionManager()
        results = manager.bump(
            part=config.part,
            files=config.files,
            prerelease=config.prerelease,
            commit=config.commit,
            tag=config.tag,
            message=config.message,
        )

        # Log results
        if results:
            logger.info(f"\nSuccessfully updated {len(results)} files")
            for file_path, version in results.items():
                logger.info(f"  {file_path.relative_to(Path.cwd())}: {version}")
        else:
            logger.warning("No files were updated")

    except (OSError, UnicodeDecodeError):
        logger.exception("Failed to bump version")
        sys.exit(1)


def main() -> None:
    """Run main entry point for bumpversion command."""
    config = parse_arguments()

    # Handle --all flag for batch updates
    if config.all_files:
        if config.files:
            logger.error("Cannot use --files with --all flag")
            sys.exit(1)
        _handle_all_flag(config)
        return

    # Dry run mode
    if config.dry_run:
        _handle_dry_run(config)
        return

    # Perform bump
    _perform_bump(config)


if __name__ == "__main__":
    main()
