"""Checksum module."""
