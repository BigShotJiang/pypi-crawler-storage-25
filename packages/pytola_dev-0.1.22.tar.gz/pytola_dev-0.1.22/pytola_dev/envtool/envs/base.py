"""envtool 基础模块."""

from __future__ import annotations

from typing import ClassVar

from pytola_core.config import ConfigMixin
from pytola_core.logger import get_logger

__all__ = ["BaseEnvTool", "EnvtoolConfig", "conf"]

logger = get_logger(__name__)


class EnvtoolConfig(ConfigMixin):
    """环境工具配置类."""

    OVERRIDE = False

    # python 配置项
    _PYPI_TOKEN: str | None = None
    PIP_INDEX_URL = "https://mirrors.aliyun.com/pypi/simple/"
    PIP_CONFIG_CONTENT = """[global]
index-url = https://mirrors.aliyun.com/pypi/simple/
[install]
trusted-host = mirrors.aliyun.com
"""
    UV_INDEX_URL = "https://mirrors.aliyun.com/pypi/simple/"
    UV_DEFAULT_INDEX = "https://mirrors.aliyun.com/pypi/simple/"
    UV_HTTP_TIMEOUT = 600
    UV_LINK_MODE = "copy"

    # rust 配置项
    RUST_CONFIG_CONTENT = """[source.crates-io]
replace-with = 'ustc'

[source.ustc]
registry = "https://mirrors.ustc.edu.cn/crates.io-index"
"""

    RUSTUP_UPDATE_ROOT: ClassVar[str] = "https://mirrors.ustc.edu.cn/rust-static/rustup"
    RUSTUP_DIST_SERVER: ClassVar[str] = "https://mirrors.ustc.edu.cn/rust-static"

    _RUST_INSTALL_VERSION: str = "stable"
    _RUST_DOWNLOAD_CMD_WINDOWS: ClassVar[list[str]] = ["wget", "https://win.rustup.rs", "-O", "rustup-init.exe"]
    _RUST_DOWNLOAD_CMD_LINUX: ClassVar[list[str]] = [
        "curl",
        "--proto",
        "=https",
        "--tlsv1.2",
        "-sSf",
        "https://sh.rustup.rs",
    ]

    # node 配置项
    NODE_VERSIONS: ClassVar[dict[str, str]] = {
        "V20": "curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -",
        "V18": "curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -",
    }

    @property
    def _RUST_HOST(self) -> str:
        """获取 rustup 默认主机地址.

        Returns
        -------
            str: 默认主机地址
        """
        return "x86_64-pc-windows-msvc" if self._IS_WINDOWS else "x86_64-unknown-linux-gnu"


conf = EnvtoolConfig()


class BaseEnvTool:
    """环境工具基类."""

    desc = ""
    conf: ConfigMixin | None = None

    def run(self) -> None:
        """运行工具."""
        if self.desc:
            logger.info(f"{self.desc}")
