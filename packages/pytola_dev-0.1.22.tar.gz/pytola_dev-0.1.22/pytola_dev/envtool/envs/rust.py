"""功能：初始化 Rust 环境变量."""

from __future__ import annotations

import subprocess
from pathlib import Path

from pytola_core.network.url import urlopen_safe

from pytola_dev.envtool.envs.base import BaseEnvTool, conf, logger
from pytola_dev.envtool.envs.python import add_env_to_bashrc


class RustEnvTool(BaseEnvTool):
    """Rust 环境配置工具."""

    def run(self) -> None:
        """安装 Rust."""
        self.setup_env(override=conf.OVERRIDE)
        self.setup_cargo_config()

        if self._check_rustup_callable():
            logger.info("rustup 已安装，跳过安装步骤")
            logger.info("设置 rustup 默认 host")
            subprocess.run(["rustup", "set", "default-host", conf._RUST_HOST], check=True)
            subprocess.run(["rustup", "default", conf._RUST_INSTALL_VERSION], check=True)
        else:
            self._download_rustup()
            self._run_rustup(conf._RUST_INSTALL_VERSION)

        logger.info("查看 rustup 安装信息")
        subprocess.run(["rustup", "show"], check=True)

    def setup_env(self, *, override: bool = True) -> None:
        """设置 Rust 环境变量."""
        logger.info("配置 Rust 环境变量")

        rustup_envs: dict[str, object] = {k: v for k, v in conf.attrs.items() if k.startswith("RUSTUP_")}

        if conf._IS_WINDOWS:
            for k, v in rustup_envs.items():
                logger.info(f"设置环境变量：{k}={v}")
                subprocess.run(["setx", str(k), str(v)], check=True)
        else:
            for k, v in rustup_envs.items():
                add_env_to_bashrc(str(k), str(v), override=override)

    def setup_cargo_config(self) -> None:
        """配置 Cargo 配置文件."""
        cargo_dir = conf._HOME_DIR / ".cargo"
        cargo_conf = cargo_dir / "config.toml"

        if not cargo_dir.exists():
            logger.info(f"创建 Cargo 文件夹：[green bold]{cargo_dir}")
            cargo_dir.mkdir(parents=True)
        else:
            logger.info(f"已存在 Cargo 文件夹：[green bold]{cargo_dir}")

        logger.info(f"写入文件：[green bold]{cargo_conf}")
        cargo_conf.write_text(conf.RUST_CONFIG_CONTENT)

    def _check_rustup_callable(self) -> bool:
        """检查 rustup 是否可执行.

        Returns
        -------
            bool: 是否可执行
        """
        try:
            result = subprocess.run(["rustup", "--version"], capture_output=True, text=True, timeout=5, check=False)
        except (subprocess.TimeoutExpired, FileNotFoundError):
            logger.exception("rustup 未安装")
            return False
        else:
            return result.returncode == 0

    def _run_rustup(self, install_version: str = "nightly") -> None:
        try:
            logger.info("运行 rustup-init.exe")
            subprocess.run(
                [
                    "rustup-init.exe",
                    f"--default-toolchain={install_version}",
                    "--no-modify-path",
                    "--default-host",
                    conf._RUST_HOST,
                ],
                check=True,
            )
        except OSError:
            logger.exception("运行 rustup-init.exe 失败")
            logger.info("请手动运行 rustup-init.exe 进行安装，或者删除该文件后重新下载")

    def _download_rustup(self) -> None:
        """下载 rustup."""
        rustup_init_name = f"rustup-init{conf._EXTENSION}"
        rustup_init_file = Path.cwd() / rustup_init_name

        if rustup_init_file.exists():
            logger.info(f"已存在 rustup 安装文件: [green bold]{rustup_init_file}")
            return

        if conf._IS_WINDOWS:
            logger.info("下载 rustup-init.exe")
            subprocess.run(conf._RUST_DOWNLOAD_CMD_WINDOWS, check=True)
        else:
            logger.info("下载 rustup-init.sh")
            # 对于 Linux 系统，需要单独处理管道
            import tempfile

            # 安全性：验证 URL 方案以防止 SSRF 和本地文件访问 (CWE-22)
            # 仅允许 http/https 方案用于下载 rustup 脚本
            script_content = urlopen_safe("https://sh.rustup.rs", timeout=10)

            # 保存到临时文件并执行
            with tempfile.NamedTemporaryFile(mode="wb", delete=False, suffix=".sh") as f:
                f.write(script_content)
                temp_script_path = f.name

            try:
                subprocess.run(["sh", temp_script_path], check=True)
            finally:
                Path(temp_script_path).unlink()

        rustup_path = Path.cwd() / "rustup-init.exe"
        if rustup_path.exists():
            logger.info(f"下载完成, 保存到: [green bold]{rustup_path}")
        else:
            logger.error(f"下载失败, 请手动下载到当前目录: [red bold]{rustup_path}")
