"""环境配置工具."""

from __future__ import annotations

import argparse

from .envs.base import conf, logger

# 支持的环境配置工具
_SUPP_TOOLS: set[str] = {"python", "rust"}


def parse_args() -> argparse.Namespace:
    """解析命令行参数."""
    parser = argparse.ArgumentParser(description="环境配置工具")
    subparser = parser.add_subparsers(dest="tool")

    py_parser = subparser.add_parser("python", help="Python 环境配置工具")
    py_parser.add_argument("pypi_token", type=str, default="", nargs="?", help="PyPI token值")
    py_parser.add_argument("--override", help="是否覆盖已存在选项", action="store_true")

    rust_parser = subparser.add_parser("rust", help="Rust 环境配置工具")
    rust_parser.add_argument("install_version", type=str, default="nightly", nargs="?", help="Rust安装版本")
    rust_parser.add_argument("--override", help="是否覆盖已存在选项", action="store_true")

    return parser.parse_args()


def main() -> None:
    """运行环境工具的命令行入口.

    环境配置工具的命令行接口

    Examples
    --------
      cli [选项] <参数>
    """
    args = parse_args()

    if not args.tool or args.tool not in _SUPP_TOOLS:
        logger.error("无效的工具指定")
        return

    if args.tool == "python":
        from pytola_dev.envtool.envs.python import PythonEnvtool

        conf.OVERRIDE = args.override
        conf._PYPI_TOKEN = args.pypi_token

        tool = PythonEnvtool()
        tool.run()
    elif args.tool == "rust":
        from pytola_dev.envtool.envs.rust import RustEnvTool

        conf.OVERRIDE = args.override
        conf._RUST_INSTALL_VERSION = args.install_version

        tool = RustEnvTool()
        tool.run()
