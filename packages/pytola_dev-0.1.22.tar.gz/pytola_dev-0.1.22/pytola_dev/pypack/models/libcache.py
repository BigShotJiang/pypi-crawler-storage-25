"""Libcache module for models."""

from __future__ import annotations

import json
import re
import shutil
import tarfile
import time
import zipfile
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from typing import Any, Final

from packaging.specifiers import SpecifierSet
from packaging.version import InvalidVersion, Version
from pytola_core.logger import get_logger

logger = get_logger(__name__)

DEFAULT_CACHE_DIR = Path.home() / ".pytola" / ".cache" / "python-libs"
MAX_DEPTH: Final[int] = 50  # Maximum recursion depth to prevent infinite loops


@dataclass
class CacheMetadata:
    """Metadata for cached package."""

    name: str
    version: str | None
    path: str
    timestamp: float


DEV_TOOLS = frozenset({
    "sphinx",
    "sphinx_rtd_theme",
    "watchdog",
    "pytest",
    "coverage",
    "black",
    "mypy",
    "flake8",
    "pylint",
    "isort",
    "pre-commit",
    "tox",
    "nose",
    "unittest",
    "mock",
})
DEV_PATTERNS = frozenset({"dev", "test", "docs", "lint", "example"})
TYPING_PATTERNS = frozenset({"stubs", "typing", "types"})


def normalize_package_name(name: str) -> str:
    """Normalize package name to lowercase with underscores.

    Args:
        name: Package name to normalize

    Returns
    -------
        Normalized package name
    """
    return name.lower().replace("-", "_")


def should_skip_dependency(req_name: str, has_extras: bool = False) -> bool:
    """Check if a dependency should be skipped based on common patterns.

    Args:
        req_name: Package name
        has_extras: Whether the requirement has extras

    Returns
    -------
        True if should skip, False otherwise
    """
    # Skip extras
    if has_extras:
        return True

    req_lower = req_name.lower()
    normalized_req = req_lower.replace("-", "_")

    # Skip dev/test/docs/lint/example patterns
    if any(keyword in req_lower for keyword in DEV_PATTERNS):
        return True

    # Skip typing/stubs dependencies
    if any(keyword in req_lower for keyword in TYPING_PATTERNS):
        return True

    # Skip common dev tools
    return normalized_req in DEV_TOOLS


@dataclass(frozen=False)
class LibraryCache:
    """Manage local cache for Python packages."""

    cache_dir: Path = field(default_factory=lambda: DEFAULT_CACHE_DIR)
    _dependencies_cache: dict[Path, set[str]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Initialize the cache directory if it doesn't exist."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    @cached_property
    def metadata_file(self) -> Path:
        """Path to the metadata file for the cache directory.

        Returns
        -------
            Path to the metadata file
        """
        return self.cache_dir / "metadata.json"

    @cached_property
    def wheel_files(self) -> list[Path]:
        """List of wheel files in the cache directory.

        Returns
        -------
            List of wheel files
        """
        return list(self.cache_dir.glob("*.whl"))

    @cached_property
    def sdist_files(self) -> list[Path]:
        """List of source distribution files in the cache directory.

        Returns
        -------
            List of source distribution files
        """
        return list(self.cache_dir.glob("*.tar.gz")) + list(self.cache_dir.glob("*.zip"))

    def collect_dependencies_from_list(
        self, dependency_list: list[str], version_requirements: dict[str, str | None] | None = None
    ) -> set[str]:
        """Recursively collect all dependencies from package files (wheel or sdist).

        Args:
            dependency_list: List of root package names to start from
            version_requirements: Optional mapping of package names to version specifiers
                (e.g., {"requests": ">=2.0.0,<3.0.0", "numpy": None}).
                When provided, uses get_package_path with version matching.

        Returns
        -------
            Set of all required package names (normalized)
        """
        all_packages: set[str] = set()
        visited: set[str] = set()
        visit_stack: dict[str, int] = {}  # Track visit depth for cycle detection

        def visit(pkg_name: str, level: int = 0) -> None:
            """Visit a package and collect its dependencies."""
            # Normalize package name for consistency
            normalized_pkg_name = pkg_name.lower().replace("-", "_")

            # Check for cycles
            if normalized_pkg_name in visit_stack:
                logger.warning(
                    f"Potential circular dependency detected: {normalized_pkg_name} (current depth: {level}, "
                    f"previous depth: {visit_stack[normalized_pkg_name]})"
                )
                return

            # Check depth limit
            if level > MAX_DEPTH:
                logger.warning(
                    f"Maximum dependency depth ({MAX_DEPTH}) reached for {normalized_pkg_name}, stopping recursion"
                )
                return

            # Skip if already visited
            if normalized_pkg_name in visited:
                return

            # Mark as visited and track depth
            visited.add(normalized_pkg_name)
            visit_stack[normalized_pkg_name] = level
            all_packages.add(normalized_pkg_name)

            # Process dependencies if package exists in map
            # Use version-aware lookup when version_requirements is provided
            if version_requirements is not None:
                version_spec = version_requirements.get(normalized_pkg_name)
                package_path = self.get_package_path(normalized_pkg_name, version_spec)
            else:
                package_path = self.package_map.get(normalized_pkg_name)

            if package_path:
                deps = self._extract_dependencies_from_wheel(package_path)
                logger.debug(f"{'  ' * level}{normalized_pkg_name} -> {deps}")
                for dep in deps:
                    visit(dep, level + 1)

            # Remove from stack when done
            visit_stack.pop(normalized_pkg_name, None)

        for pkg_name in dependency_list:
            visit(pkg_name)

        logger.info(f"Collected {len(all_packages)} packages: {all_packages}")
        return all_packages

    @cached_property
    def versioned_package_map(self) -> dict[str, dict[str, Path]]:
        """Create a mapping of package names to all their versions.

        Returns
        -------
            Dictionary mapping package names to {version: path} dictionaries
        """
        packages: dict[str, dict[str, Path]] = {}

        # Process wheel files first
        for wheel_file in self.wheel_files:
            pkg_name = self._extract_package_name_from_wheel(wheel_file)
            if pkg_name:
                normalized_pkg_name = normalize_package_name(pkg_name)
                version = self._extract_version_from_wheel(wheel_file) or "unknown"
                if normalized_pkg_name not in packages:
                    packages[normalized_pkg_name] = {}
                packages[normalized_pkg_name][version] = wheel_file

        # Add sdist files
        for sdist_file in self.sdist_files:
            pkg_name = self._extract_package_name_from_sdist(sdist_file)
            if pkg_name:
                normalized_pkg_name = normalize_package_name(pkg_name)
                version = self._extract_version_from_sdist(sdist_file) or "unknown"
                if normalized_pkg_name not in packages:
                    packages[normalized_pkg_name] = {}
                # Only add if this version doesn't already have a wheel
                if version not in packages[normalized_pkg_name]:
                    packages[normalized_pkg_name][version] = sdist_file

        return packages

    @cached_property
    def package_map(self) -> dict[str, Path]:
        """Create a mapping of package names to their highest version file paths.

        When multiple versions of the same package exist in cache, selects
        the highest version using packaging.version.Version comparison.

        Returns
        -------
            Dictionary mapping package names to their highest version file paths
        """
        return {
            pkg_name: self._select_highest_version(versions)
            for pkg_name, versions in self.versioned_package_map.items()
            if versions
        }

    def _select_highest_version(self, versions: dict[str, Path]) -> Path:
        """Select the highest version from a version-to-path mapping.

        Args:
            versions: Dictionary mapping version strings to file paths

        Returns
        -------
            Path to the file with the highest version
        """
        if len(versions) == 1:
            return next(iter(versions.values()))

        best_version = None
        best_path = None
        for ver, path in versions.items():
            if best_version is None:
                best_version = ver
                best_path = path
            else:
                try:
                    if Version(ver) > Version(best_version):
                        best_version = ver
                        best_path = path
                except InvalidVersion:
                    pass

        return best_path or next(iter(versions.values()))

    @cached_property
    def cache_size(self) -> int:
        """Calculate total size of cache in bytes."""
        if not self.cache_dir.exists():
            return 0

        # Use generator expression for memory efficiency
        return sum(file_path.stat().st_size for file_path in self.cache_dir.rglob("*") if file_path.is_file())

    @cached_property
    def package_count(self) -> int:
        """Get the count of packages in cache."""
        return len(self.package_map)

    @cached_property
    def cache_stats(self) -> dict[str, int]:
        """Get detailed cache statistics."""
        return {
            "total_packages": self.package_count,
            "wheel_count": len(self.wheel_files),
            "sdist_count": len(self.sdist_files),
            "cache_size_bytes": self.cache_size,
        }

    def get_package_path(self, package_name: str, version: str | None = None) -> Path | None:
        """Get cached package path if available, optionally matching a specific version.

        Args:
            package_name: Name of the package
            version: Version specifier (optional, e.g., ">=1.0.0,<2.0.0")

        Returns
        -------
            Path to cached package or None
        """
        normalized_name = normalize_package_name(package_name)

        # First try filesystem lookup for wheel files with version matching
        matching_wheel_files: list[tuple[Path, str]] = []  # List of (file_path, version)
        for whl_file in self.cache_dir.glob("*.whl"):
            parsed_name = self._extract_package_name_from_wheel(whl_file)
            if parsed_name == normalized_name:
                parsed_version = self._extract_version_from_wheel(whl_file)
                if version is None or self._version_matches(parsed_version, version):
                    matching_wheel_files.append((whl_file, parsed_version or "unknown"))
                    if version is None:
                        logger.debug(f"Cache hit (filesystem wheel): {package_name}")
                        return whl_file

        # If version was specified, select the best match from wheels
        if version and matching_wheel_files:
            # Sort by version descending and return the highest matching version
            from packaging.version import parse as parse_version

            matching_wheel_files.sort(
                key=lambda x: parse_version(x[1]) if x[1] != "unknown" else parse_version("0"), reverse=True
            )
            logger.debug(f"Cache hit (filesystem wheel with version): {package_name} - {matching_wheel_files[0][1]}")
            return matching_wheel_files[0][0]

        # Try filesystem lookup for sdist files (.tar.gz, .zip) with version matching
        matching_sdist_files: list[tuple[Path, str]] = []
        for sdist_file in self.cache_dir.glob("*.tar.gz"):
            parsed_name = self._extract_package_name_from_sdist(sdist_file)
            if parsed_name == normalized_name:
                parsed_version = self._extract_version_from_sdist(sdist_file)
                if version is None or self._version_matches(parsed_version, version):
                    matching_sdist_files.append((sdist_file, parsed_version or "unknown"))
                    if version is None:
                        logger.debug(f"Cache hit (filesystem sdist): {package_name}")
                        return sdist_file

        for sdist_file in self.cache_dir.glob("*.zip"):
            parsed_name = self._extract_package_name_from_sdist(sdist_file)
            if parsed_name == normalized_name:
                parsed_version = self._extract_version_from_sdist(sdist_file)
                if version is None or self._version_matches(parsed_version, version):
                    matching_sdist_files.append((sdist_file, parsed_version or "unknown"))
                    if version is None:
                        logger.debug(f"Cache hit (filesystem sdist): {package_name}")
                        return sdist_file

        # If version was specified, select the best match from sdists
        if version and matching_sdist_files:
            from packaging.version import parse as parse_version

            matching_sdist_files.sort(
                key=lambda x: parse_version(x[1]) if x[1] != "unknown" else parse_version("0"), reverse=True
            )
            logger.debug(f"Cache hit (filesystem sdist with version): {package_name} - {matching_sdist_files[0][1]}")
            return matching_sdist_files[0][0]

        # Fallback to metadata lookup
        metadata = self._load_metadata()
        for info in metadata.values():
            if info["name"] == normalized_name:
                cached_version = info.get("version")
                if version is None or self._version_matches(cached_version, version):
                    path = self.cache_dir / info["path"]
                    if path.exists():
                        logger.debug(f"Cache hit (metadata): {package_name}")
                        return path

        logger.debug(f"Cache miss: {package_name}")
        return None

    @staticmethod
    def _extract_package_name_from_wheel(wheel_file: Path) -> str | None:
        """Extract package name from wheel file.

        Wheel filename format: {distribution}-{version}(-{build tag})?-{python}-{abi}-{platform}.whl
        Uses regex to handle package names with hyphens (e.g., scikit-learn).

        Args:
            wheel_file: Path to wheel file

        Returns
        -------
            Package name or None
        """
        try:
            filename = wheel_file.stem  # Remove .whl extension
            # Use regex to extract package name and version
            # Pattern: package name (non-greedy) followed by version (starts with digit)
            match = re.match(r"^(.+?)-(\d+[^-]*)-", filename)
            if match:
                return normalize_package_name(match.group(1))
        except Exception:
            pass
        return None

    @staticmethod
    def _extract_package_name_from_sdist(sdist_file: Path) -> str | None:
        """Extract package name from source distribution file (.tar.gz or .zip).

        Args:
            sdist_file: Path to sdist file

        Returns
        -------
            Package name or None
        """
        try:
            # Handle .tar.gz files (e.g., package_name-1.0.0.tar.gz)
            if sdist_file.suffixes and ".tar" in sdist_file.suffixes and ".gz" in sdist_file.suffixes:
                # Remove both .tar.gz extensions by removing the last 7 characters (.tar.gz)
                stem_without_ext = sdist_file.stem  # This removes .gz, leaving package-1.0.0.tar
                # Now remove the remaining .tar
                if stem_without_ext.endswith(".tar"):
                    stem_without_ext = stem_without_ext[:-4]  # Remove .tar
                parts = stem_without_ext.rsplit("-", 1)  # Split from right: ["package_name", "1.0.0"]
                if len(parts) >= 1 and parts[0]:
                    return normalize_package_name(parts[0])
            # Handle .zip files
            elif sdist_file.suffix == ".zip":
                filename = sdist_file.stem  # Remove .zip extension
                parts = filename.rsplit("-", 1)
                if len(parts) >= 1 and parts[0]:
                    return normalize_package_name(parts[0])
        except Exception as e:
            logger.debug(f"Failed to extract package name from {sdist_file}: {e}")
        return None

    def _extract_dependencies_from_wheel(self, wheel_file: Path) -> set[str]:
        """Extract dependencies from wheel METADATA file with caching.

        Args:
            wheel_file: Path to wheel or sdist file

        Returns
        -------
            Set of package names (normalized)
        """
        # Check cache first
        if wheel_file in self._dependencies_cache:
            return self._dependencies_cache[wheel_file]

        # Check if it's an sdist file (.tar.gz or .zip)
        if wheel_file.suffix in {".gz", ".zip"}:
            dependencies = self._extract_dependencies_from_sdist(wheel_file)
            self._dependencies_cache[wheel_file] = dependencies
            return dependencies

        # Early return if wheel file doesn't exist
        if not wheel_file.exists():
            logger.warning(f"Wheel file does not exist: {wheel_file}")
            self._dependencies_cache[wheel_file] = set()
            return set()

        try:
            with zipfile.ZipFile(wheel_file, "r") as zf:
                # Find metadata file
                metadata_files = [name for name in zf.namelist() if name.endswith("METADATA")]

                if not metadata_files:
                    dependencies = set()
                else:
                    metadata_content = zf.read(metadata_files[0]).decode("utf-8", errors="ignore")
                    dependencies = self._parse_metadata_content(metadata_content)

            # Cache the result
            self._dependencies_cache[wheel_file] = dependencies
            return dependencies
        except Exception as e:
            logger.warning(f"Failed to extract dependencies from {wheel_file.name}: {e}")
            return set()

    def _extract_dependencies_from_sdist(self, sdist_file: Path) -> set[str]:
        """Extract dependencies from source distribution file with caching.

        Args:
            sdist_file: Path to sdist file (.tar.gz or .zip)

        Returns
        -------
            Set of package names (normalized)
        """
        dependencies: set[str] = set()

        try:
            # Handle .tar.gz files
            if sdist_file.suffix == ".gz":
                with tarfile.open(sdist_file, "r:gz") as tf:
                    for member in tf.getmembers():
                        # Look for PKG-INFO or METADATA file in the root of the package
                        if member.name.endswith(("PKG-INFO", "METADATA")):
                            # Only use PKG-INFO/METADATA files in the root directory
                            # Count the number of slashes in the path
                            path_parts = member.name.split("/")
                            if len(path_parts) == 2 or (
                                len(path_parts) == 3 and path_parts[2] in {"PKG-INFO", "METADATA"}
                            ):
                                content = tf.extractfile(member)
                                if content:
                                    metadata_content = content.read().decode("utf-8", errors="ignore")
                                    dependencies = self._parse_metadata_content(metadata_content)
                                    logger.debug(f"Extracted dependencies from {member.name} in {sdist_file.name}")
                                    break
            # Handle .zip files
            elif sdist_file.suffix == ".zip":
                with zipfile.ZipFile(sdist_file, "r") as zf:
                    for name in zf.namelist():
                        # Look for PKG-INFO or METADATA file in the root of the package
                        if name.endswith(("PKG-INFO", "METADATA")):
                            path_parts = name.split("/")
                            if len(path_parts) == 2 or (
                                len(path_parts) == 3 and path_parts[2] in {"PKG-INFO", "METADATA"}
                            ):
                                metadata_content = zf.read(name).decode("utf-8", errors="ignore")
                                dependencies = self._parse_metadata_content(metadata_content)
                                logger.debug(f"Extracted dependencies from {name} in {sdist_file.name}")
                                break
        except Exception as e:
            logger.warning(f"Failed to extract dependencies from sdist {sdist_file.name}: {e}")

        return dependencies

    @staticmethod
    def _parse_metadata_content(metadata_content: str) -> set[str]:
        """Parse metadata content (PKG-INFO or METADATA) to extract dependencies.

        Args:
            metadata_content: Content of PKG-INFO or METADATA file

        Returns
        -------
            Set of package names (normalized)
        """
        dependencies: set[str] = set()
        try:
            for line in metadata_content.splitlines():
                # Look for Requires-Dist or Requires field
                if line.startswith(("Requires-Dist:", "Requires:")):
                    if line.startswith("Requires:"):
                        # Requires field contains comma-separated list
                        dep_str = line.split(":", 1)[1].strip()
                        for req_str in re.split(r",\s*", dep_str):
                            req_str = req_str.strip()
                            if req_str:
                                dependencies.update(LibraryCache._parse_single_requirement(req_str))
                    else:
                        # Requires-Dist field
                        dep_str = line.split(":", 1)[1].strip()
                        dependencies.update(LibraryCache._parse_single_requirement(dep_str))
        except Exception as e:
            logger.debug(f"Failed to parse metadata content: {e}")

        return dependencies

    @staticmethod
    def _parse_single_requirement(req_str: str) -> set[str]:
        """Parse a single requirement string and extract package name.

        Args:
            req_str: Requirement string (e.g., "numpy>=1.20.0", "package[extra]>=1.0")

        Returns
        -------
            Set containing the normalized package name, or empty set if should skip
        """
        try:
            # Skip extras dependencies
            if re.search(r'extra\s*==\s*["\']?([^"\';\s]+)["\']?', req_str, re.IGNORECASE):
                logger.debug(f"Skipping extra dependency: {req_str}")
                return set()

            from packaging.requirements import Requirement

            req = Requirement(req_str)
            if not should_skip_dependency(req.name, bool(req.extras)):
                dep_name = normalize_package_name(req.name)
                logger.debug(f"Found core dependency: {dep_name}")
                return {dep_name}
        except Exception:
            pass

        return set()

    def add_package(self, package_name: str, package_path: Path, version: str | None = None) -> None:
        """Add package to cache.

        Args:
            package_name: Name of the package
            package_path: Path to package files
            version: Package version
        """
        # Normalize package name to ensure consistency
        normalized_name = normalize_package_name(package_name)

        # Copy package files to cache (flat structure for wheels, nested for dirs)
        if package_path.is_dir():
            dest_dir = self.cache_dir / normalized_name
            if dest_dir.exists():
                shutil.rmtree(dest_dir)
            shutil.copytree(package_path, dest_dir)
            relative_path = normalized_name
        else:
            dest_file = self.cache_dir / package_path.name
            shutil.copy2(package_path, dest_file)
            relative_path = package_path.name

        # Update metadata using CacheMetadata dataclass
        metadata = self._load_metadata()
        metadata[str(package_path)] = CacheMetadata(
            name=normalized_name, version=version, path=relative_path, timestamp=time.time()
        ).__dict__
        self._save_metadata(metadata)

        # Clear cached_property caches to force recomputation on next access
        self._clear_cached_properties()

        logger.info(f"Cached package: {normalized_name}")

    def _clear_cached_properties(self) -> None:
        """Clear all cached_property caches to force recomputation."""
        cached_props = [
            "wheel_files",
            "sdist_files",
            "versioned_package_map",
            "package_map",
            "cache_size",
            "package_count",
            "cache_stats",
        ]
        for prop_name in cached_props:
            if prop_name in self.__dict__:
                del self.__dict__[prop_name]

    def _load_metadata(self) -> dict[str, Any]:
        """Load cache metadata.

        Returns
        -------
            Metadata dictionary
        """
        if self.metadata_file.exists():
            try:
                with Path(self.metadata_file).open(encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load cache metadata: {e}")

        return {}

    def _save_metadata(self, metadata: dict[str, Any]) -> None:
        """Save cache metadata.

        Args:
            metadata: Metadata dictionary
        """
        with Path(self.metadata_file).open("w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=2)

    @staticmethod
    def _extract_version_from_wheel(wheel_file: Path) -> str | None:
        """Extract version from wheel file.

        Wheel filename format: {distribution}-{version}(-{build tag})?-{python}-{abi}-{platform}.whl
        Uses regex to handle package names with hyphens (e.g., scikit-learn).

        Args:
            wheel_file: Path to wheel file

        Returns
        -------
            Version string or None
        """
        try:
            filename = wheel_file.stem  # Remove .whl extension
            # Use regex to extract package name and version
            # Pattern: package name (non-greedy) followed by version (starts with digit)
            match = re.match(r"^(.+?)-(\d+[^-]*)-", filename)
            if match:
                return match.group(2)
        except Exception:
            pass
        return None

    @staticmethod
    def _extract_version_from_sdist(sdist_file: Path) -> str | None:
        """Extract version from source distribution file (.tar.gz or .zip).

        Sdist filename format: {distribution}-{version}.tar.gz or {distribution}-{version}.zip

        Args:
            sdist_file: Path to sdist file

        Returns
        -------
            Version string or None
        """
        try:
            # Handle .tar.gz files
            if sdist_file.suffixes and ".tar" in sdist_file.suffixes and ".gz" in sdist_file.suffixes:
                stem_without_ext = sdist_file.stem  # This removes .gz, leaving package-1.0.0.tar
                if stem_without_ext.endswith(".tar"):
                    stem_without_ext = stem_without_ext[:-4]  # Remove .tar
                parts = stem_without_ext.rsplit("-", 1)
                if len(parts) >= 2:
                    return parts[1]
            # Handle .zip files
            elif sdist_file.suffix == ".zip":
                filename = sdist_file.stem  # Remove .zip extension
                parts = filename.rsplit("-", 1)
                if len(parts) >= 2:
                    return parts[1]
        except Exception as e:
            logger.debug(f"Failed to extract version from {sdist_file}: {e}")
        return None

    @staticmethod
    def _version_matches(version_str: str | None, version_spec: str | None) -> bool:
        """Check if a version matches a version specifier.

        Args:
            version_str: Version string to check (e.g., "1.2.3")
            version_spec: Version specifier (e.g., ">=1.0.0,<2.0.0")

        Returns
        -------
            True if version matches the specifier, False otherwise
        """
        if version_str is None or version_spec is None:
            return True  # No version constraint, accept any

        try:
            version = Version(version_str)
            spec = SpecifierSet(version_spec)
            return version in spec
        except InvalidVersion:
            logger.warning(f"Invalid version: {version_str}")
            return False
        except Exception as e:
            logger.warning(f"Error checking version match: {e}")
            return False

    @staticmethod
    def _should_skip_dist_info(file_path: Path) -> bool:
        """Check if the file path should be skipped because it's a dist-info directory."""
        if file_path.name.endswith(".dist-info"):
            return True
        # Check if any parent directory ends with .dist-info
        return any(part.endswith(".dist-info") for part in file_path.parts)

    def clear_cache(self) -> None:
        """Clear all cached packages."""
        if self.cache_dir.exists():
            shutil.rmtree(self.cache_dir)
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._dependencies_cache.clear()  # Clear in-memory dependencies cache
        logger.info("Cache cleared")
