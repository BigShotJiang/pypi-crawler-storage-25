"""Test version-aware cache matching in LibraryCache.

This module tests the version cache matching functionality that was fixed:
- package_map selects highest version when multiple versions exist
- versioned_package_map stores all versions
- get_package_path supports version specifier matching
- collect_dependencies_from_list supports version_requirements parameter
- Wheel filename parsing supports complex package names with hyphens
- cached_property caches are properly cleared on add_package
"""

from __future__ import annotations

import zipfile
from pathlib import Path
from typing import Optional

import pytest

from pytola_dev.pypack.models.libcache import LibraryCache, normalize_package_name


def create_mock_wheel(cache_dir: Path, name: str, version: str, dependencies: Optional[list[str]] = None) -> Path:
    """Create a minimal valid wheel file for testing.

    Args:
        cache_dir: Directory to create the wheel in
        name: Package name
        version: Package version
        dependencies: List of dependency strings (e.g., ["requests>=2.0.0"])

    Returns
    -------
        Path to the created wheel file
    """
    # Normalize name for filename (hyphens are common in wheel filenames)
    filename_name = name.replace("_", "-")
    wheel_filename = f"{filename_name}-{version}-py3-none-any.whl"
    wheel_path = cache_dir / wheel_filename

    # Build METADATA content
    metadata_lines = ["Metadata-Version: 2.1", f"Name: {name}", f"Version: {version}"]

    if dependencies:
        metadata_lines.extend(f"Requires-Dist: {dep}" for dep in dependencies)

    metadata_content = "\n".join(metadata_lines) + "\n"

    # Create the wheel as a zip file with METADATA
    with zipfile.ZipFile(wheel_path, "w") as zf:
        # Wheel files must have {name}-{version}.dist-info/METADATA
        dist_info_path = f"{filename_name}-{version}.dist-info/METADATA"
        zf.writestr(dist_info_path, metadata_content)

    return wheel_path


class TestPackageMapHighestVersion:
    """Test that package_map selects the highest version."""

    def test_package_map_selects_highest_version(self, tmp_path: Path):
        """Verify package_map returns the highest version when multiple exist."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create multiple versions of the same package
        create_mock_wheel(cache_dir, "requests", "2.20.0")
        wheel_v228 = create_mock_wheel(cache_dir, "requests", "2.28.0")
        create_mock_wheel(cache_dir, "requests", "2.25.0")

        # package_map should select the highest version (2.28.0)
        pkg_map = cache.package_map
        assert "requests" in pkg_map
        assert pkg_map["requests"] == wheel_v228

    def test_package_map_single_version(self, tmp_path: Path):
        """Verify package_map works correctly with a single version."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        wheel = create_mock_wheel(cache_dir, "requests", "2.20.0")

        pkg_map = cache.package_map
        assert "requests" in pkg_map
        assert pkg_map["requests"] == wheel


class TestVersionedPackageMap:
    """Test versioned_package_map stores all versions."""

    def test_versioned_package_map_contains_all_versions(self, tmp_path: Path):
        """Verify versioned_package_map contains all versions of a package."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create multiple versions
        wheel_v220 = create_mock_wheel(cache_dir, "requests", "2.20.0")
        wheel_v228 = create_mock_wheel(cache_dir, "requests", "2.28.0")

        versioned_map = cache.versioned_package_map
        assert "requests" in versioned_map
        assert "2.20.0" in versioned_map["requests"]
        assert "2.28.0" in versioned_map["requests"]
        assert versioned_map["requests"]["2.20.0"] == wheel_v220
        assert versioned_map["requests"]["2.28.0"] == wheel_v228

    def test_versioned_package_map_multiple_packages(self, tmp_path: Path):
        """Verify versioned_package_map handles multiple packages."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        create_mock_wheel(cache_dir, "requests", "2.28.0")
        create_mock_wheel(cache_dir, "requests", "2.20.0")
        create_mock_wheel(cache_dir, "flask", "2.0.0")
        create_mock_wheel(cache_dir, "flask", "2.1.0")

        versioned_map = cache.versioned_package_map
        assert "requests" in versioned_map
        assert "flask" in versioned_map
        assert len(versioned_map["requests"]) == 2
        assert len(versioned_map["flask"]) == 2


class TestGetPackagePathVersionMatching:
    """Test get_package_path with version specifiers."""

    def test_get_package_path_gte_version(self, tmp_path: Path):
        """Test >= version specifier returns correct version."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        create_mock_wheel(cache_dir, "test_pkg", "1.0.0")
        wheel_v2 = create_mock_wheel(cache_dir, "test_pkg", "2.0.0")

        # >=2.0 should return 2.0.0
        result = cache.get_package_path("test_pkg", ">=2.0.0")
        assert result == wheel_v2

    def test_get_package_path_range_version(self, tmp_path: Path):
        """Test version range specifier returns correct version."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        wheel_v1 = create_mock_wheel(cache_dir, "test_pkg", "1.0.0")
        create_mock_wheel(cache_dir, "test_pkg", "2.0.0")

        # >=1.0,<2.0 should return 1.0.0
        result = cache.get_package_path("test_pkg", ">=1.0.0,<2.0.0")
        assert result == wheel_v1

    def test_get_package_path_no_match_returns_none(self, tmp_path: Path):
        """Test that non-matching version returns None."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        create_mock_wheel(cache_dir, "test_pkg", "1.0.0")

        # >=2.0 should return None (only 1.0.0 exists)
        result = cache.get_package_path("test_pkg", ">=2.0.0")
        assert result is None

    def test_get_package_path_no_version_returns_match(self, tmp_path: Path):
        """Test that no version specifier returns a matching package.

        Note: When no version is specified, get_package_path returns the first
        matching wheel file found. The package_map property should be used to
        get the highest version.
        """
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        wheel_v1 = create_mock_wheel(cache_dir, "test_pkg", "1.0.0")
        wheel_v2 = create_mock_wheel(cache_dir, "test_pkg", "2.0.0")

        # No version should return a valid wheel (filesystem glob order)
        result = cache.get_package_path("test_pkg")
        # Result should be one of the wheels
        assert result in {wheel_v1, wheel_v2}
        assert result is not None

    def test_package_map_returns_highest_version(self, tmp_path: Path):
        """Test that package_map returns the highest version."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        create_mock_wheel(cache_dir, "test_pkg", "1.0.0")
        wheel_v2 = create_mock_wheel(cache_dir, "test_pkg", "2.0.0")

        # package_map should return highest version
        result = cache.package_map.get("test_pkg")
        assert result == wheel_v2

    def test_get_package_path_exact_version(self, tmp_path: Path):
        """Test exact version matching."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        wheel_v1 = create_mock_wheel(cache_dir, "test_pkg", "1.0.0")
        wheel_v2 = create_mock_wheel(cache_dir, "test_pkg", "2.0.0")

        result = cache.get_package_path("test_pkg", "==1.0.0")
        assert result == wheel_v1

        result = cache.get_package_path("test_pkg", "==2.0.0")
        assert result == wheel_v2


class TestCollectDependenciesVersionAware:
    """Test collect_dependencies_from_list with version_requirements."""

    def test_collect_dependencies_with_version_requirements(self, tmp_path: Path):
        """Test version_requirements parameter uses correct version."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create main package with dependencies
        create_mock_wheel(cache_dir, "main_pkg", "1.0.0", ["dep_pkg>=1.0.0"])

        # Create two versions of dependency with different sub-dependencies
        create_mock_wheel(cache_dir, "dep_pkg", "1.0.0", ["sub_dep_v1"])
        create_mock_wheel(cache_dir, "dep_pkg", "2.0.0", ["sub_dep_v2"])

        # Without version requirements, should use highest version (2.0.0)
        all_packages = cache.collect_dependencies_from_list(["main_pkg"])
        assert "sub_dep_v2" in all_packages
        assert "sub_dep_v1" not in all_packages

        # With version requirement for 1.0.0, should use that version
        version_reqs = {"dep_pkg": ">=1.0.0,<2.0.0"}
        all_packages_v1 = cache.collect_dependencies_from_list(["main_pkg"], version_requirements=version_reqs)
        assert "sub_dep_v1" in all_packages_v1

    def test_collect_dependencies_backward_compatible(self, tmp_path: Path):
        """Test that omitting version_requirements maintains backward compatibility."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create package chain
        create_mock_wheel(cache_dir, "pkg_a", "1.0.0", ["pkg_b"])
        create_mock_wheel(cache_dir, "pkg_b", "1.0.0", ["pkg_c"])
        create_mock_wheel(cache_dir, "pkg_c", "1.0.0", [])

        # Without version_requirements parameter (backward compatible)
        all_packages = cache.collect_dependencies_from_list(["pkg_a"])
        assert "pkg_a" in all_packages
        assert "pkg_b" in all_packages
        assert "pkg_c" in all_packages

    def test_collect_dependencies_partial_version_requirements(self, tmp_path: Path):
        """Test version_requirements with only some packages specified."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create packages
        create_mock_wheel(cache_dir, "main_pkg", "1.0.0", ["dep_a", "dep_b"])
        create_mock_wheel(cache_dir, "dep_a", "1.0.0", [])
        create_mock_wheel(cache_dir, "dep_a", "2.0.0", [])
        create_mock_wheel(cache_dir, "dep_b", "1.0.0", [])

        # Only specify version for dep_a, dep_b should use default (highest)
        version_reqs = {"dep_a": "==1.0.0"}
        all_packages = cache.collect_dependencies_from_list(["main_pkg"], version_requirements=version_reqs)
        assert "dep_a" in all_packages
        assert "dep_b" in all_packages


class TestComplexPackageNameParsing:
    """Test wheel filename parsing for complex package names."""

    def test_scikit_learn_parsing(self, tmp_path: Path):
        """Test parsing scikit-learn style package names."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create wheel with scikit_learn name (underscores)
        wheel = cache_dir / "scikit_learn-1.2.3-cp310-cp310-win_amd64.whl"
        with zipfile.ZipFile(wheel, "w") as zf:
            zf.writestr(
                "scikit_learn-1.2.3.dist-info/METADATA", "Metadata-Version: 2.1\nName: scikit-learn\nVersion: 1.2.3\n"
            )

        pkg_name = cache._extract_package_name_from_wheel(wheel)
        version = cache._extract_version_from_wheel(wheel)

        assert pkg_name == "scikit_learn"  # Normalized to underscores
        assert version == "1.2.3"

    def test_pillow_parsing(self, tmp_path: Path):
        """Test parsing Pillow (capitalized) package names."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        wheel = cache_dir / "Pillow-10.0.0-cp310-cp310-win_amd64.whl"
        with zipfile.ZipFile(wheel, "w") as zf:
            zf.writestr("Pillow-10.0.0.dist-info/METADATA", "Metadata-Version: 2.1\nName: Pillow\nVersion: 10.0.0\n")

        pkg_name = cache._extract_package_name_from_wheel(wheel)
        version = cache._extract_version_from_wheel(wheel)

        assert pkg_name == "pillow"  # Normalized to lowercase
        assert version == "10.0.0"

    def test_azure_storage_blob_parsing(self, tmp_path: Path):
        """Test parsing azure-storage-blob style package names."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        wheel = cache_dir / "azure_storage_blob-12.19.0-py3-none-any.whl"
        with zipfile.ZipFile(wheel, "w") as zf:
            zf.writestr(
                "azure_storage_blob-12.19.0.dist-info/METADATA",
                "Metadata-Version: 2.1\nName: azure-storage-blob\nVersion: 12.19.0\n",
            )

        pkg_name = cache._extract_package_name_from_wheel(wheel)
        version = cache._extract_version_from_wheel(wheel)

        assert pkg_name == "azure_storage_blob"  # Normalized
        assert version == "12.19.0"

    def test_package_map_with_complex_names(self, tmp_path: Path):
        """Test package_map handles complex package names correctly."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create wheels with complex names
        wheel_scikit = cache_dir / "scikit_learn-1.2.3-cp310-cp310-win_amd64.whl"
        with zipfile.ZipFile(wheel_scikit, "w") as zf:
            zf.writestr(
                "scikit_learn-1.2.3.dist-info/METADATA", "Metadata-Version: 2.1\nName: scikit-learn\nVersion: 1.2.3\n"
            )

        wheel_azure = cache_dir / "azure_storage_blob-12.19.0-py3-none-any.whl"
        with zipfile.ZipFile(wheel_azure, "w") as zf:
            zf.writestr(
                "azure_storage_blob-12.19.0.dist-info/METADATA",
                "Metadata-Version: 2.1\nName: azure-storage-blob\nVersion: 12.19.0\n",
            )

        pkg_map = cache.package_map
        assert "scikit_learn" in pkg_map
        assert "azure_storage_blob" in pkg_map


class TestCachedPropertyClearing:
    """Test that cached_property caches are cleared on add_package."""

    def test_add_package_clears_package_map_cache(self, tmp_path: Path):
        """Verify add_package clears package_map cache."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        other_dir = tmp_path / "other"
        other_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create initial wheel and access package_map to cache it
        create_mock_wheel(cache_dir, "pkg_a", "1.0.0")
        pkg_map_1 = cache.package_map
        assert "pkg_a" in pkg_map_1

        # Add another package from a different directory
        wheel_b = create_mock_wheel(other_dir, "pkg_b", "1.0.0")
        cache.add_package("pkg_b", wheel_b, "1.0.0")

        # package_map should be recomputed and include pkg_b
        pkg_map_2 = cache.package_map
        assert "pkg_b" in pkg_map_2

    def test_add_package_clears_versioned_package_map_cache(self, tmp_path: Path):
        """Verify add_package clears versioned_package_map cache."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        other_dir = tmp_path / "other"
        other_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create initial wheel and access versioned_package_map to cache it
        create_mock_wheel(cache_dir, "pkg_a", "1.0.0")
        versioned_map_1 = cache.versioned_package_map
        assert "pkg_a" in versioned_map_1

        # Add another package from a different directory
        wheel_b = create_mock_wheel(other_dir, "pkg_b", "1.0.0")
        cache.add_package("pkg_b", wheel_b, "1.0.0")

        # versioned_package_map should be recomputed and include pkg_b
        versioned_map_2 = cache.versioned_package_map
        assert "pkg_b" in versioned_map_2

    def test_add_package_clears_wheel_files_cache(self, tmp_path: Path):
        """Verify add_package clears wheel_files cache."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        other_dir = tmp_path / "other"
        other_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create initial wheel and access wheel_files to cache it
        create_mock_wheel(cache_dir, "pkg_a", "1.0.0")
        wheel_files_1 = cache.wheel_files
        assert len(wheel_files_1) == 1

        # Add another package from a different directory
        wheel_b = create_mock_wheel(other_dir, "pkg_b", "1.0.0")
        cache.add_package("pkg_b", wheel_b, "1.0.0")

        # wheel_files should be recomputed
        wheel_files_2 = cache.wheel_files
        assert len(wheel_files_2) == 2

    def test_add_package_clears_cache_stats(self, tmp_path: Path):
        """Verify add_package clears cache_stats cache."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        other_dir = tmp_path / "other"
        other_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create initial wheel and access cache_stats to cache it
        create_mock_wheel(cache_dir, "pkg_a", "1.0.0")
        stats_1 = cache.cache_stats
        initial_count = stats_1["total_packages"]

        # Add another package from a different directory
        wheel_b = create_mock_wheel(other_dir, "pkg_b", "1.0.0")
        cache.add_package("pkg_b", wheel_b, "1.0.0")

        # cache_stats should be recomputed
        stats_2 = cache.cache_stats
        assert stats_2["total_packages"] == initial_count + 1


class TestNormalizePackageName:
    """Test package name normalization."""

    @pytest.mark.parametrize(
        ("input_name", "expected"),
        [
            ("requests", "requests"),
            ("Requests", "requests"),
            ("scikit-learn", "scikit_learn"),
            ("azure-storage-blob", "azure_storage_blob"),
            ("Pillow", "pillow"),
        ],
    )
    def test_normalize_package_name(self, input_name: str, expected: str):
        """Test package name normalization."""
        assert normalize_package_name(input_name) == expected


class TestVersionRequirementsMerging:
    """Test version requirements merging in _build_version_requirements."""

    def test_merge_transitive_version_specs(self, tmp_path: Path):
        """Test that transitive dependencies with different version specs are merged."""
        from unittest.mock import MagicMock

        from pytola_dev.pypack.components.libpacker import PyLibPacker, PyLibPackerConfig
        from pytola_dev.pypack.models.libdownloader import DownloadResult
        from pytola_dev.pypack.models.project import Project

        # Create a packer with mocked cache
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        config = PyLibPackerConfig(cache_dir=cache_dir)
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        # Create mock wheels for testing
        # lib_a depends on common_dep>=2.20
        create_mock_wheel(cache_dir, "lib_a", "1.0.0", ["common_dep>=2.20"])
        # lib_b depends on common_dep>=2.25
        create_mock_wheel(cache_dir, "lib_b", "1.0.0", ["common_dep>=2.25"])
        # common_dep wheels
        create_mock_wheel(cache_dir, "common_dep", "2.20.0", [])
        create_mock_wheel(cache_dir, "common_dep", "2.25.0", [])

        # Create mock project with no direct dependencies
        mock_project = MagicMock(spec=Project)
        mock_project.converted_dependencies = set()

        # Create mock download result with lib_a and lib_b
        download_result = DownloadResult(
            results={"lib_a": True, "lib_b": True}, total=2, successful=2, cached=2, downloaded=0
        )

        # Build version requirements
        version_reqs = packer._build_version_requirements(mock_project, download_result)

        # Verify common_dep has merged version specs
        assert "common_dep" in version_reqs
        # Should be merged: >=2.20,>=2.25
        assert ">=2.20" in version_reqs["common_dep"]
        assert ">=2.25" in version_reqs["common_dep"]

    def test_direct_dependency_priority(self, tmp_path: Path):
        """Test that direct dependencies take priority over transitive ones."""
        from unittest.mock import MagicMock

        from pytola_dev.pypack.components.libpacker import PyLibPacker, PyLibPackerConfig
        from pytola_dev.pypack.models.dependency import Dependency
        from pytola_dev.pypack.models.libdownloader import DownloadResult
        from pytola_dev.pypack.models.project import Project

        # Create a packer with mocked cache
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        config = PyLibPackerConfig(cache_dir=cache_dir)
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        # Create mock wheels
        # lib_a depends on common_dep>=2.20
        create_mock_wheel(cache_dir, "lib_a", "1.0.0", ["common_dep>=2.20"])
        create_mock_wheel(cache_dir, "common_dep", "2.30.0", [])

        # Create mock project with direct dependency on common_dep>=3.0
        mock_project = MagicMock(spec=Project)
        direct_dep = Dependency(name="common_dep", version=">=3.0")
        mock_project.converted_dependencies = {direct_dep}

        # Create mock download result
        download_result = DownloadResult(results={"lib_a": True}, total=1, successful=1, cached=1, downloaded=0)

        # Build version requirements
        version_reqs = packer._build_version_requirements(mock_project, download_result)

        # Direct dependency should take priority and not be overwritten
        assert version_reqs["common_dep"] == ">=3.0"

    def test_merge_with_none_version(self, tmp_path: Path):
        """Test merging when one dependency has no version constraint."""
        from unittest.mock import MagicMock

        from pytola_dev.pypack.components.libpacker import PyLibPacker, PyLibPackerConfig
        from pytola_dev.pypack.models.libdownloader import DownloadResult
        from pytola_dev.pypack.models.project import Project

        # Create a packer with mocked cache
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        config = PyLibPackerConfig(cache_dir=cache_dir)
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        # Create mock wheels
        # lib_a depends on common_dep (no version)
        create_mock_wheel(cache_dir, "lib_a", "1.0.0", ["common_dep"])
        # lib_b depends on common_dep>=2.25
        create_mock_wheel(cache_dir, "lib_b", "1.0.0", ["common_dep>=2.25"])
        create_mock_wheel(cache_dir, "common_dep", "2.25.0", [])

        # Create mock project with no direct dependencies
        mock_project = MagicMock(spec=Project)
        mock_project.converted_dependencies = set()

        # Create mock download result
        download_result = DownloadResult(
            results={"lib_a": True, "lib_b": True}, total=2, successful=2, cached=2, downloaded=0
        )

        # Build version requirements
        version_reqs = packer._build_version_requirements(mock_project, download_result)

        # common_dep should have the version constraint from lib_b
        assert version_reqs["common_dep"] == ">=2.25"
