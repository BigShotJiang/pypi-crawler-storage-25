"""Test version validation in libpacker."""

import tempfile
from pathlib import Path

from pytola_dev.pypack.models.libcache import LibraryCache


def test_version_extraction_from_wheel():
    """Test extracting version from wheel filename."""
    # Test standard wheel format: package_name-1.2.3-py3-none-any.whl
    wheel_file = Path("test_package-1.2.3-py3-none-any.whl")
    version = LibraryCache._extract_version_from_wheel(wheel_file)
    assert version == "1.2.3", f"Expected '1.2.3', got '{version}'"

    # Test with build tag: package_name-1.0.0-1-py3-none-any.whl
    wheel_file_with_build = Path("test_package-1.0.0-1-py3-none-any.whl")
    version_with_build = LibraryCache._extract_version_from_wheel(wheel_file_with_build)
    assert version_with_build == "1.0.0", f"Expected '1.0.0', got '{version_with_build}'"


def test_version_extraction_from_sdist():
    """Test extracting version from sdist filename."""
    # Test .tar.gz format
    sdist_tar_gz = Path("test_package-1.2.3.tar.gz")
    version_tar_gz = LibraryCache._extract_version_from_sdist(sdist_tar_gz)
    assert version_tar_gz == "1.2.3", f"Expected '1.2.3', got '{version_tar_gz}'"

    # Test .zip format
    sdist_zip = Path("test_package-1.0.0.zip")
    version_zip = LibraryCache._extract_version_from_sdist(sdist_zip)
    assert version_zip == "1.0.0", f"Expected '1.0.0', got '{version_zip}'"


def test_version_matching():
    """Test version matching logic."""
    # Test exact match
    assert LibraryCache._version_matches("1.2.3", "==1.2.3") is True
    assert LibraryCache._version_matches("1.2.3", "==1.2.4") is False

    # Test greater than or equal
    assert LibraryCache._version_matches("1.2.3", ">=1.0.0") is True
    assert LibraryCache._version_matches("1.2.3", ">=1.5.0") is False

    # Test less than
    assert LibraryCache._version_matches("1.2.3", "<2.0.0") is True
    assert LibraryCache._version_matches("1.2.3", "<1.0.0") is False

    # Test compound specifiers
    assert LibraryCache._version_matches("1.2.3", ">=1.0.0,<2.0.0") is True
    assert LibraryCache._version_matches("2.5.0", ">=1.0.0,<2.0.0") is False

    # Test no version constraint
    assert LibraryCache._version_matches("1.2.3", None) is True
    assert LibraryCache._version_matches(None, ">=1.0.0") is True


def test_get_package_path_with_version():
    """Test getting package path with version matching."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        cache_dir = Path(tmp_dir) / "cache"
        cache_dir.mkdir()
        cache = LibraryCache(cache_dir=cache_dir)

        # Create mock wheel files with different versions
        wheel_v1 = cache_dir / "test_pkg-1.0.0-py3-none-any.whl"
        wheel_v2 = cache_dir / "test_pkg-2.0.0-py3-none-any.whl"
        wheel_v3 = cache_dir / "test_pkg-3.0.0-py3-none-any.whl"

        # Create empty files
        wheel_v1.touch()
        wheel_v2.touch()
        wheel_v3.touch()

        # Test without version (should return first match)
        result_any = cache.get_package_path("test_pkg")
        assert result_any is not None, "Should find a package without version constraint"

        # Test with exact version
        result_v1 = cache.get_package_path("test_pkg", "==1.0.0")
        assert result_v1 == wheel_v1, f"Should find v1.0.0, got {result_v1}"

        result_v2 = cache.get_package_path("test_pkg", "==2.0.0")
        assert result_v2 == wheel_v2, f"Should find v2.0.0, got {result_v2}"

        # Test with version range
        result_range = cache.get_package_path("test_pkg", ">=1.5.0,<3.0.0")
        assert result_range == wheel_v2, f"Should find v2.0.0 for range >=1.5.0,<3.0.0, got {result_range}"

        # Test with non-matching version
        result_no_match = cache.get_package_path("test_pkg", "==5.0.0")
        assert result_no_match is None, "Should return None for non-matching version"


if __name__ == "__main__":
    test_version_extraction_from_wheel()
    test_version_extraction_from_sdist()
    test_version_matching()
    test_get_package_path_with_version()
