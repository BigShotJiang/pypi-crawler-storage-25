"""GUI widgets for pypack."""
