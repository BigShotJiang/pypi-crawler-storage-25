"""Type definitions for pymake."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class BuildTool(Enum):
    """Enumeration of supported build tools."""

    UV = "uv"
    POETRY = "poetry"
    HATCH = "hatch"


class ProjectType(Enum):
    """Enumeration of project types."""

    CLI = "cli"
    GUI = "gui"
    LIBRARY = "library"
    UNKNOWN = "unknown"


@dataclass
class TokenInfo:
    """PyPI token information."""

    username: str
    token: str
    repository: str = "pypi"
