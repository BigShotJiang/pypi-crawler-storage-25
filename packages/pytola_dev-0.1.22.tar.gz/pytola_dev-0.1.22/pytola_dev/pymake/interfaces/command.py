"""Command interface definition for pymake."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from ..core.context import ExecutionContext

from ..logger import logger


class CommandType(Enum):
    """Enumeration of command types."""

    BUILD = "build"
    CLEAN = "clean"
    TEST = "test"
    PUBLISH = "publish"
    BUMP_VERSION = "bump_version"
    TOKEN = "token"
    DOC = "doc"
    INIT = "init"
    UTIL = "util"


@dataclass
class CommandResult:
    """Result of command execution.

    Attributes
    ----------
        success: Whether the command executed successfully
        message: Human-readable result message
        data: Optional structured data payload
        exit_code: System exit code (0 for success)
    """

    success: bool
    message: str = ""
    data: dict[str, Any] | None = None
    exit_code: int = 0


class Command(Protocol):
    """Interface for all pymake commands.

    All commands must implement this protocol with required attributes
    and an execute method that returns a CommandResult.
    """

    name: str
    alias: str
    description: str
    command_type: CommandType

    def execute(self, context: ExecutionContext) -> CommandResult:
        """Execute the command with given context.

        Args:
            context: Execution context containing config, logger, etc.

        Returns
        -------
            CommandResult with execution status and details
        """
        ...


class ValidatableCommand(ABC):
    """Abstract base class for commands that need validation.

    Subclasses must implement validate() and execute() methods.
    The execute method should call validate() before proceeding.
    """

    name: str = ""
    alias: str = ""
    description: str = ""
    command_type: CommandType = CommandType.UTIL

    def __init__(self) -> None:
        self.logger = logger

    @abstractmethod
    def validate(self, context: ExecutionContext) -> bool:
        """Validate command inputs and prerequisites.

        Args:
            context: Execution context

        Returns
        -------
            True if validation passes, False otherwise
        """
        ...

    @abstractmethod
    def execute(self, context: ExecutionContext) -> CommandResult:
        """Execute the command with validation.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        ...
