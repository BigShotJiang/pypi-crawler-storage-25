"""Pymake CLI module.

This module provides the command-line interface for pymake,
a comprehensive build and management tool for Pytola projects.

Features:
    - Modern command architecture with clear separation of concerns
    - Centralized command registration and management
    - Standardized execution context and validation
    - Support for multiple build tools (uv, poetry, hatch)
    - Comprehensive error handling and logging
    - Structured command results with detailed feedback

Example:
    >>> # 构建项目
    >>> pymake build
    >>>
    >>> # 运行测试
    >>> pymake test
    >>>
    >>> # 生成文档
    >>> pymake doc
"""

from __future__ import annotations

import argparse
import logging
import sys

from pytola_core.config import ConfigMixin
from pytola_core.logger import get_logger

from . import __version__
from .conf import conf
from .core.context import create_default_context
from .core.registry import CommandRegistry, get_registry
from .interfaces.command import Command

logger = get_logger(__name__)


def main() -> None:
    """运行 Pymake 工具的主入口点.

    Loads all commands, parses arguments, and executes the requested command.

    Raises
    ------
        SystemExit: If command execution fails or unknown command is provided
    """
    try:
        # Import all commands to register them
        _load_all_commands()

        # Get registry
        registry = get_registry()

        # Get all available command names (including aliases)
        all_names = registry.list_commands() + list(registry.list_aliases().keys())

        if not all_names:
            logger.error("未加载任何命令")
            sys.exit(1)

        # Parse arguments
        parser = _create_parser(all_names)
        args = parser.parse_args()

        # Handle information options
        if args.list_commands:
            _list_commands()
            return

        if args.help_commands:
            _show_detailed_help()
            return

        # Set logging level
        if args.debug:
            logger.setLevel(logging.DEBUG)
            conf.verbose = True

        # Validate that a command was provided
        if not args.command:
            parser.print_help()
            logger.error("未指定命令，使用 --help 查看用法信息")
            sys.exit(1)

        # Execute command
        logger.info(f"正在执行命令：{args.command}")
        _execute_command(args.command, args.args, conf)

    except KeyboardInterrupt:
        logger.info("用户取消操作")
        sys.exit(130)  # Standard exit code for Ctrl+C
    except Exception:
        logger.exception("发生意外错误")
        sys.exit(1)


def _load_all_commands() -> None:
    """加载所有命令模块以注册它们."""
    # Import commands module to trigger auto-registration
    # The commands/__init__.py imports all command modules which triggers @register decorators
    from . import commands  # noqa: F401


def _create_parser(all_names: list[str]) -> argparse.ArgumentParser:
    """创建包含所有命令的参数解析器.

    Args:
        all_names: List of all command names and aliases

    Returns
    -------
        Configured argument parser
    """
    parser = argparse.ArgumentParser(
        prog="pymake",
        description="Pytola 项目构建和管理工具",
        epilog="""示例:
  pymake build           构建项目
  pymake test            运行测试
  pymake doc             生成文档
  pymake bumpversion     增加版本号
  pymake init            初始化新项目

使用 'pymake --list-commands' 查看所有可用命令""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Add argument groups for better organization
    info_group = parser.add_argument_group("Information Options")
    info_group.add_argument(
        "--version", action="version", version=f"Pymake v{__version__}", help="Show version information and exit"
    )
    info_group.add_argument(
        "--list-commands", "-lc", action="store_true", help="List all available commands with descriptions"
    )
    info_group.add_argument("--help-commands", "-hc", action="store_true", help="Show detailed help for all commands")

    logging_group = parser.add_argument_group("Logging Options")
    logging_group.add_argument("--debug", "-d", action="store_true", help="Enable debug mode with verbose output")

    parser.add_argument(
        "command",
        nargs="?",
        type=str,
        choices=all_names,
        help=f"Command to run. Available: {', '.join(sorted(all_names))}",
    )

    parser.add_argument("args", nargs=argparse.REMAINDER, help="Additional arguments for the command")

    return parser


def _execute_command(command_name: str, command_args: list[str], conf: ConfigMixin) -> None:
    """Execute a registered command.

    Args:
        command_name: Name or alias of the command to execute
        command_args: Additional arguments for the command
        config: Pymake configuration
    """
    registry = get_registry()

    # Create execution context
    context = create_default_context()
    context.config = conf

    # Check if command exists before executing
    command_cls = registry.get_command_class(command_name)

    if not command_cls:
        logger.error(f"Unknown command: {command_name}")
        available_commands = registry.list_commands() + list(registry.list_aliases().keys())
        logger.info(f"Available commands: {', '.join(sorted(available_commands))}")
        sys.exit(1)

    # Parse command-specific arguments
    command_instance = command_cls()
    _parse_command_arguments(command_name, command_args, command_instance)

    # Execute command instance directly instead of creating a new one in registry
    result = command_instance.execute(context)

    if not result.success:
        logger.error(f"Command execution failed: {result.message}")
        sys.exit(1)

    # Command succeeded
    logger.info("Command completed successfully!")


def _parse_command_arguments(
    command_name: str, command_args: list[str], command_instance: Command
) -> argparse.Namespace:
    """Parse command-specific arguments.

    Args:
        command_name: Name of the command
        command_args: Raw command line arguments
        command_instance: Command instance to configure

    Returns
    -------
        Parsed arguments namespace
    """
    # Create parser for command-specific arguments
    parser = argparse.ArgumentParser(add_help=False)

    # Add known arguments based on command type
    if command_name in {"build", "b"}:
        parser.add_argument(
            "--match-name", "-m", type=str, default=None, help="Pattern to match subdirectory names (e.g., 'pytola-*')"
        )

    # Parse known args (ignore unknown ones for now)
    args, _ = parser.parse_known_args(command_args)

    # Apply parsed arguments to command instance if it supports them
    if hasattr(args, "match_name") and hasattr(command_instance, "set_match_name"):
        command_instance.set_match_name(args.match_name)

    return args


def _list_commands() -> None:
    """List all available commands with their descriptions."""
    registry = get_registry()

    # Get all command types
    all_types = registry.get_all_types()

    # Define type order for consistent output
    from .interfaces.command import CommandType

    type_order = [
        CommandType.BUILD,
        CommandType.TEST,
        CommandType.PUBLISH,
        CommandType.BUMP_VERSION,
        CommandType.DOC,
        CommandType.INIT,
        CommandType.TOKEN,
        CommandType.CLEAN,
        CommandType.UTIL,
    ]

    # Show commands in ordered types
    for cmd_type in type_order:
        if cmd_type not in all_types:
            continue

        commands = registry.get_commands_by_type(cmd_type)
        if not commands:
            continue

        _display_command_list(registry, sorted(commands))

    # Show any remaining types not in the predefined order
    for cmd_type in sorted(all_types, key=lambda x: x.name):
        if cmd_type in type_order:
            continue

        commands = registry.get_commands_by_type(cmd_type)
        if not commands:
            continue

        _display_command_list(registry, sorted(commands))


def _display_command_list(registry: CommandRegistry, cmd_names: list[str]) -> None:
    """Display a list of commands with their descriptions.

    Args:
        registry: Command registry instance
        cmd_names: Sorted list of command names to display
    """
    for cmd_name in cmd_names:
        cmd_cls = registry.get_command_class(cmd_name)
        if not cmd_cls:
            continue

        getattr(cmd_cls, "description", "No description")
        getattr(cmd_cls, "alias", "No alias")


def _show_detailed_help() -> None:
    """Show detailed help for all commands."""
    registry = get_registry()

    # Get all command types
    all_types = registry.get_all_types()

    # Define type order for consistent output
    from .interfaces.command import CommandType

    type_order = [
        CommandType.BUILD,
        CommandType.TEST,
        CommandType.PUBLISH,
        CommandType.BUMP_VERSION,
        CommandType.DOC,
        CommandType.INIT,
        CommandType.TOKEN,
        CommandType.CLEAN,
        CommandType.UTIL,
    ]

    # Show commands in ordered types
    for cmd_type in type_order:
        if cmd_type not in all_types:
            continue

        commands = registry.get_commands_by_type(cmd_type)
        if not commands:
            continue

        _display_command_help(registry, sorted(commands))

    # Show any remaining types not in the predefined order
    for cmd_type in sorted(all_types, key=lambda x: x.name):
        if cmd_type in type_order:
            continue

        commands = registry.get_commands_by_type(cmd_type)
        if not commands:
            continue

        _display_command_help(registry, sorted(commands))


def _display_command_help(registry: CommandRegistry, cmd_names: list[str]) -> None:
    """Display help information for a list of commands.

    Args:
        registry: Command registry instance
        cmd_names: Sorted list of command names to display
    """
    for cmd_name in cmd_names:
        cmd_cls = registry.get_command_class(cmd_name)
        if not cmd_cls:
            continue

        getattr(cmd_cls, "description", "No description")
        getattr(cmd_cls, "alias", "No alias")

        # Try to get help_text from metadata
        metadata = registry.get_metadata(cmd_name)
        if metadata and metadata.get("help_text"):
            pass


if __name__ == "__main__":
    main()
