"""Logger module for pymake."""

from pytola_core.logger import get_logger

logger = get_logger(__name__)
