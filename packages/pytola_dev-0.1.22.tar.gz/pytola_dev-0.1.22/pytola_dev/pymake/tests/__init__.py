"""Tests for pymake."""
