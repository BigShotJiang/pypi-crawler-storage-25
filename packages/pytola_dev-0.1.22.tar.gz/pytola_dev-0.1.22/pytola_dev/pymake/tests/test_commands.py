"""Basic tests for pymake commands."""

from pathlib import Path

import pytest

from pytola_dev.pymake.core.context import create_default_context
from pytola_dev.pymake.core.registry import get_registry
from pytola_dev.pymake.interfaces.command import CommandResult


class TestRegistry:
    """Test command registry functionality."""

    def test_registry_singleton(self):
        """Test that registry is a singleton."""
        registry1 = get_registry()
        registry2 = get_registry()
        assert registry1 is registry2

    def test_list_commands(self):
        """Test listing registered commands."""
        registry = get_registry()
        commands = registry.list_commands()
        # Should have at least the basic commands
        assert len(commands) > 0
        assert "build" in commands
        assert "test" in commands
        assert "clean" in commands


class TestExecutionContext:
    """Test execution context functionality."""

    def test_create_default_context(self):
        """Test creating default execution context."""
        context = create_default_context()
        assert context.cwd == Path.cwd()

    def test_context_project_detection(self):
        """Test that context can detect project root."""
        create_default_context()
        # Should find project root somewhere
        # (may be None if not in a project)
        assert True  # Allow None


class TestCommands:
    """Test individual commands."""

    @pytest.mark.parametrize("command_name", ["build", "clean", "lint", "test", "list", "version"])
    def test_command_exists(self, command_name):
        """Test that basic commands are registered."""
        registry = get_registry()
        cmd_class = registry.get_command_class(command_name)
        assert cmd_class is not None

    def test_list_command_execution(self):
        """Test list command execution."""
        from pytola_dev.pymake.commands.list import ListCommand

        context = create_default_context()
        cmd = ListCommand()
        result = cmd.run(context)

        assert isinstance(result, CommandResult)
        # Should succeed even if no projects found
        assert result.success is True


class TestValidators:
    """Test validation utilities."""

    def test_validate_version_valid(self):
        """Test version validation with valid input."""
        from pytola_dev.pymake.utils.validators import validate_version

        is_valid, error_msg = validate_version("1.2.3")
        assert is_valid is True
        assert not error_msg

    def test_validate_version_invalid(self):
        """Test version validation with invalid input."""
        from pytola_dev.pymake.utils.validators import validate_version

        is_valid, error_msg = validate_version("invalid")
        assert is_valid is False
        assert "Invalid version format" in error_msg

    def test_validate_bump_type_valid(self):
        """Test bump type validation with valid input."""
        from pytola_dev.pymake.utils.validators import validate_bump_type

        for bump_type in ["patch", "minor", "major"]:
            is_valid, error_msg = validate_bump_type(bump_type)
            assert is_valid is True
            assert not error_msg

    def test_validate_bump_type_invalid(self):
        """Test bump type validation with invalid input."""
        from pytola_dev.pymake.utils.validators import validate_bump_type

        is_valid, error_msg = validate_bump_type("invalid")
        assert is_valid is False
        assert "Invalid bump type" in error_msg
