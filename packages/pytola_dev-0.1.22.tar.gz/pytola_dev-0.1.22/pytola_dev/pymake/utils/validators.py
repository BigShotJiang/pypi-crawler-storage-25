"""Validation utilities for pymake."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Tuple

# Maximum length for Python project names (PEP 508 compliant)
MAX_PROJECT_NAME_LENGTH = 214

# Maximum value for each semantic version part (X.Y.Z where each part is 0-999)
MAX_VERSION_PART = 999


def validate_path(path: str | Path, *, must_exist: bool = False) -> Tuple[bool, str]:
    """Validate a file or directory path.

    Args:
        path: Path to validate
        must_exist: Whether the path must exist

    Returns
    -------
        Tuple of (is_valid, error_message)
        error_message is empty if path is valid
    """
    path_obj = Path(path)

    # Check for invalid characters
    invalid_chars = '<>"|?*'
    if any(char in str(path_obj) for char in invalid_chars):
        return False, f"Path contains invalid characters: {invalid_chars}"

    # Check existence if required
    if must_exist and not path_obj.exists():
        return False, f"Path does not exist: {path}"

    return True, ""


def validate_version(version: str) -> Tuple[bool, str]:
    """Validate a semantic version string.

    Args:
        version: Version string to validate (e.g., "1.2.3")

    Returns
    -------
        Tuple of (is_valid, error_message)
        error_message is empty if version is valid
    """
    # Simple semver pattern
    pattern = r"^\d+\.\d+\.\d+$"

    if not re.match(pattern, version):
        return False, f"Invalid version format: {version} (expected X.Y.Z)"

    # Check each part is reasonable
    parts = version.split(".")
    for i, part in enumerate(parts):
        # Use LBYL pattern to avoid try-except in loop (PERF203)
        if not part.isdigit():
            return False, f"Version part {i + 1} is not a number: {part}"

        num = int(part)
        if num < 0 or num > MAX_VERSION_PART:
            return False, f"Version part {i + 1} out of range (0-{MAX_VERSION_PART}): {part}"

    return True, ""


def validate_bump_type(bump_type: str) -> Tuple[bool, str]:
    """Validate a version bump type.

    Args:
        bump_type: Type of version bump (patch/minor/major)

    Returns
    -------
        Tuple of (is_valid, error_message)
        error_message is empty if bump_type is valid
    """
    valid_types = {"patch", "minor", "major"}

    if bump_type.lower() not in valid_types:
        return False, f"Invalid bump type: {bump_type} (must be one of: {', '.join(valid_types)})"

    return True, ""


def validate_project_name(name: str) -> Tuple[bool, str]:
    """Validate a Python project name.

    Args:
        name: Project name to validate

    Returns
    -------
        Tuple of (is_valid, error_message)
        error_message is empty if name is valid
    """
    # PEP 508 compliant package name pattern
    pattern = r"^([A-Z0-9]|[A-Z0-9][A-Z0-9._-]*[A-Z0-9])$"

    if not re.match(pattern, name, re.IGNORECASE):
        return False, f"Invalid project name: {name}"

    if len(name) > MAX_PROJECT_NAME_LENGTH:
        return False, f"Project name too long (>{MAX_PROJECT_NAME_LENGTH} chars): {name}"

    return True, ""


def is_valid_python_identifier(name: str) -> bool:
    """Check if a string is a valid Python identifier.

    Args:
        name: String to check

    Returns
    -------
        True if valid Python identifier, False otherwise
    """
    return name.isidentifier() and not iskeyword(name)


def iskeyword(name: str) -> bool:
    """Check if a string is a Python keyword.

    Args:
        name: String to check

    Returns
    -------
        True if string is a Python keyword, False otherwise
    """
    import keyword

    return keyword.iskeyword(name)
