"""Command registry for pymake."""

from __future__ import annotations

from typing import TYPE_CHECKING, Dict, List, Optional, Type

from pytola_dev.pymake.interfaces.command import Command, CommandType

if TYPE_CHECKING:
    from pytola_dev.pymake.interfaces.command import CommandResult

    from .context import ExecutionContext


class CommandRegistry:
    """所有 pymake 命令的中央注册表."""

    def __init__(self) -> None:
        """初始化命令注册表."""
        self._commands: Dict[str, Type[Command]] = {}
        self._aliases: Dict[str, str] = {}  # alias -> command_name mapping
        self._command_types: Dict[CommandType, List[str]] = {}
        self._metadata: Dict[str, dict] = {}  # Store additional metadata

    def register(self, command_class: Type[Command], metadata: Optional[dict] = None) -> None:
        """注册一个命令类.

        Args:
            command_class: The command class to register
            metadata: Optional additional metadata for the command
        """
        # Validate command class
        if not hasattr(command_class, "name") or not hasattr(command_class, "alias"):
            msg = f"命令类 {command_class.__name__} 必须有 'name' 和 'alias' 属性"
            raise ValueError(msg)

        name = command_class.name
        alias = command_class.alias

        # Check for name conflicts
        if name in self._commands:
            msg = f"命令名 '{name}' 已被注册"
            raise ValueError(msg)

        # Check for alias conflicts
        if alias in self._aliases:
            msg = f"命令别名 '{alias}' 已被注册"
            raise ValueError(msg)

        # Register the command
        self._commands[name] = command_class
        self._aliases[alias] = name

        # Register by type
        cmd_type = getattr(command_class, "command_type", CommandType.UTIL)
        if cmd_type not in self._command_types:
            self._command_types[cmd_type] = []
        self._command_types[cmd_type].append(name)

        # Store metadata if provided
        if metadata:
            self._metadata[name] = metadata

    def get_command_class(self, name_or_alias: str) -> Optional[Type[Command]]:
        """通过名称或别名获取命令类.

        Args:
            name_or_alias: Command name or alias

        Returns
        -------
            Command class or None if not found
        """
        # First check if it's a direct name
        if name_or_alias in self._commands:
            return self._commands[name_or_alias]

        # Then check if it's an alias
        if name_or_alias in self._aliases:
            actual_name = self._aliases[name_or_alias]
            return self._commands.get(actual_name)

        return None

    def get_command_instance(self, name_or_alias: str) -> Optional[Command]:
        """通过名称或别名获取命令实例.

        Args:
            name_or_alias: Command name or alias

        Returns
        -------
            Command instance or None if not found
        """
        command_class = self.get_command_class(name_or_alias)
        if command_class:
            return command_class()
        return None

    def execute_command(self, name_or_alias: str, context: ExecutionContext) -> CommandResult:
        """通过名称或别名执行命令.

        Args:
            name_or_alias: Command name or alias
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        command = self.get_command_instance(name_or_alias)
        if not command:
            from pytola_dev.pymake.interfaces.command import CommandResult

            return CommandResult(success=False, message=f"Command '{name_or_alias}' not found")

        return command.execute(context)

    def list_commands(self) -> List[str]:
        """获取所有已注册命令的名称列表.

        Returns
        -------
            List of command names
        """
        return list(self._commands.keys())

    def list_aliases(self) -> Dict[str, str]:
        """获取别名到命令名称的映射.

        Returns
        -------
            Dictionary mapping aliases to command names
        """
        return self._aliases.copy()

    def get_commands_by_type(self, cmd_type: CommandType) -> List[str]:
        """按类型获取命令.

        Args:
            cmd_type: Command type

        Returns
        -------
            List of command names for the given type
        """
        return self._command_types.get(cmd_type, [])

    def get_all_types(self) -> List[CommandType]:
        """获取所有已注册的命令类型.

        Returns
        -------
            List of command types
        """
        return list(self._command_types.keys())

    def get_metadata(self, command_name: str) -> Optional[dict]:
        """获取命令的元数据.

        Args:
            command_name: Command name

        Returns
        -------
            Metadata dictionary or None if not found
        """
        return self._metadata.get(command_name)


# Global registry instance
_registry: Optional[CommandRegistry] = None


def get_registry() -> CommandRegistry:
    """获取全局命令注册表.

    Returns
    -------
        Global command registry instance
    """
    global _registry  # noqa: PLW0603
    if _registry is None:
        _registry = CommandRegistry()
    return _registry


def register_command(command_class: Type[Command], metadata: Optional[dict] = None) -> Type[Command]:
    """注册一个命令类.

    Args:
        command_class: The command class to register
        metadata: Optional additional metadata

    Returns
    -------
        The same command class (for decorator chaining)
    """
    registry = get_registry()
    registry.register(command_class, metadata)
    return command_class
