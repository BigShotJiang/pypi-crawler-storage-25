"""Project cache for pymake."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Optional

from pytola_core.logger import get_logger

if TYPE_CHECKING:
    from pytola_dev.pypack.models.project import Project
    from pytola_dev.pypack.models.solution import Solution

logger = get_logger(__name__)


class ProjectCache:
    """Cache for project and solution objects.

    This cache helps avoid repeated parsing of pyproject.toml files
    by caching Project and Solution instances.
    """

    def __init__(self, max_size: int = 100) -> None:
        """Initialize the project cache.

        Args:
            max_size: Maximum number of items to cache
        """
        self._cache: Dict[str, Project | Solution] = {}
        self._access_order: list[str] = []
        self._max_size = max_size

    def _generate_key(self, path: Path) -> str:
        """Generate a cache key from a path.

        Args:
            path: File or directory path

        Returns
        -------
            Hash string representing the path
        """
        return hashlib.sha256(str(path.resolve()).encode()).hexdigest()

    def get(self, path: Path) -> Optional[Project | Solution]:
        """Get a cached project or solution.

        Args:
            path: Path to the project or solution

        Returns
        -------
            Cached Project/Solution or None if not found
        """
        key = self._generate_key(path)
        if key in self._cache:
            # Move to end (most recently used)
            self._access_order.remove(key)
            self._access_order.append(key)
            logger.debug(f"Cache hit for {path}")
            return self._cache[key]
        logger.debug(f"Cache miss for {path}")
        return None

    def put(self, path: Path, obj: Project | Solution) -> None:
        """Cache a project or solution.

        Args:
            path: Path to the project or solution
            obj: Project or Solution instance to cache
        """
        key = self._generate_key(path)

        # Evict oldest if at capacity
        if len(self._cache) >= self._max_size and key not in self._cache:
            oldest_key = self._access_order.pop(0)
            del self._cache[oldest_key]
            logger.debug(f"Evicted oldest cache entry: {oldest_key[:16]}")

        # Add/update cache
        if key not in self._cache:
            self._access_order.append(key)
        self._cache[key] = obj
        logger.debug(f"Cached object for {path}")

    def clear(self) -> None:
        """Clear all cached items."""
        self._cache.clear()
        self._access_order.clear()
        logger.info("Cache cleared")

    def size(self) -> int:
        """Get the current number of cached items.

        Returns
        -------
            Number of items in cache
        """
        return len(self._cache)
