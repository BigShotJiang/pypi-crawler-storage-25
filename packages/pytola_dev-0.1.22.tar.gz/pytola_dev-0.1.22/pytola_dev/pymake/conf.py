"""Configuration management for pymake."""

from __future__ import annotations

from typing import Optional

from pytola_core.config import ConfigMixin

__all__ = ["conf"]


class PymakeConfig(ConfigMixin):
    """Pymake 配置管理."""

    verbose: bool = False
    max_workers: int = 8
    build_tool: str = "hatch"
    pypi_token: Optional[str] = None
    auto_detect_tool: bool = True
    timeout_seconds: int = 300


conf = PymakeConfig()
