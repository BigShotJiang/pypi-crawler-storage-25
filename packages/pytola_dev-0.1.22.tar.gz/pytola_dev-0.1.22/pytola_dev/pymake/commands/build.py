"""Build command for pymake."""

from __future__ import annotations

import os
from pathlib import Path

from ..core.context import ExecutionContext
from ..core.executor import CommandExecutor
from ..interfaces.command import CommandResult, CommandType
from ..logger import logger
from .base import BaseCommand, PymakeValidatableCommand, register


@register(
    name="build",
    aliases=["b"],
    description="构建所有项目",
    help_text="使用检测到的构建系统编译和打包所有项目, 如果提供了 --match-name 参数，则构建所有匹配模式的子目录",
    command_type=CommandType.BUILD,
)
class BuildCommand(BaseCommand, PymakeValidatableCommand):
    """项目的构建操作."""

    name = "build"
    alias = "b"
    description = "Build all projects"
    command_type = CommandType.BUILD

    def __init__(self) -> None:
        """Initialize the build command with a logger."""
        super().__init__()

    def execute(self, context: ExecutionContext) -> CommandResult:
        """执行构建命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        pytola_projects = self.pytola_projects or []
        for project in pytola_projects:
            original_dir = Path.cwd()
            os.chdir(project.root_dir)

            # 创建新的执行上下文，确保使用正确的项目信息
            project_context = ExecutionContext(cwd=project.root_dir, cache=context.cache)

            logger.info(f"构建项目：{project.name}")
            self._execute_single_build(project_context)
            os.chdir(original_dir)

        # Otherwise, build in current directory
        return self._execute_single_build(context)

    def _execute_single_build(self, context: ExecutionContext) -> CommandResult:
        """在单个目录中执行构建.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        # Validate prerequisites
        if not self.validate(context):
            return CommandResult(success=False, message="验证失败")

        # Get build tool
        build_tool = context.get_build_tool()
        if not build_tool:
            return CommandResult(success=False, message="无法确定构建工具")

        logger.info(f"使用 {build_tool.value} 进行构建")

        cmd = [build_tool.value, "build", context.project_info.name]
        executor = CommandExecutor(context)
        result = executor.execute_shell_command(cmd)

        if result.success:
            logger.info("构建完成")
        else:
            logger.error(f"构建失败，退出码 {result.exit_code}")

        return result

    def validate(self, context: ExecutionContext) -> bool:
        """验证构建命令的先决条件.

        Args:
            context: Execution context

        Returns
        -------
            True if validation passes, False otherwise
        """
        # Check if pyproject.toml exists
        if not self.validate_pyproject_exists(context):
            return False

        # Check if build tool is available
        return self.validate_build_tool(context)
