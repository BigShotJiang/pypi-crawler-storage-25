"""Base command classes for pymake."""

from __future__ import annotations

import fnmatch
import logging
import shutil
import subprocess
from functools import cached_property
from pathlib import Path
from typing import Any, Callable, ClassVar, List, Union

from pytola_dev.pypack.models.solution import Solution

from ..core.context import ExecutionContext
from ..interfaces.command import CommandResult, CommandType, ValidatableCommand

Action = Union[List[str], Callable[[], bool]]


def register(
    name: str,
    aliases: list[str] | None = None,
    description: str = "",
    help_text: str = "",
    command_type: CommandType | None = None,
) -> Callable[[type], type]:
    """Register a command with enhanced metadata.

    This is a wrapper around the base register decorator that adds
    pymake-specific metadata fields.

    Args:
        name: Command name
        aliases: List of command aliases
        description: Short description of the command
        help_text: Detailed help text
        command_type: CommandType enum value

    Returns
    -------
        Decorated command class
    """
    from ..core.registry import get_registry
    from ..interfaces.command import CommandType

    # Prepare metadata
    metadata = {
        "name": name,
        "aliases": aliases or [],
        "description": description,
        "help_text": help_text or description,
    }

    if command_type:
        metadata["command_type"] = command_type.name

    # Create decorator with metadata
    def decorator(cls: type[Any]) -> type[Any]:
        # Set class attributes from decorator parameters using setattr to avoid type checking issues
        cls.name = name
        cls.alias = aliases[0] if aliases else name
        cls.description = description
        cls.command_type = command_type or CommandType.UTIL

        # Get our custom registry and register the command
        registry = get_registry()
        registry.register(cls, metadata)

        return cls

    return decorator


class BaseCommand:
    """Abstract base class for all pymake commands.

    Subclasses must implement the run() method to execute the command.
    Commands can define COMMANDS class variable for automatic execution,
    or override run() for custom logic.

    Attributes
    ----------
        COMMANDS: List of actions to execute. Can be shell command lists
            or callable functions returning bool.
    """

    COMMANDS: ClassVar[list[Action]] = []
    logger: logging.Logger

    def __init__(self) -> None:
        """Initialize the base command with a logger."""
        self.logger = logging.getLogger(self.__class__.__name__)

    def run(self, context: ExecutionContext) -> CommandResult:  # noqa: ARG002
        """Execute the command.

        Iterates through COMMANDS and executes each one.
        For custom behavior, override this method.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult indicating success or failure

        Raises
        ------
            TypeError: If a command is not a list or callable
        """
        self.logger.info(f"Running command: `{self.__class__.__name__}`")

        for command in self.COMMANDS:
            if callable(command):
                # Cast to callable to avoid type checking issues
                cmd_func: Callable[[], bool] = command  # type: ignore[assignment]
                if not cmd_func():
                    self.logger.error(f"Callable command failed: `{command}`")
                    return CommandResult(success=False, message=f"Callable command failed: {command}")
            elif isinstance(command, list):
                if not self._run_command(command):
                    self.logger.error(f"Shell command failed: `{command}`")
                    return CommandResult(success=False, message=f"Shell command failed: {command}")
            else:
                msg = f"Invalid command type: {type(command)}"
                raise TypeError(msg)

        return CommandResult(success=True, message=f"{self.__class__.__name__} completed successfully")

    def execute(self, context: ExecutionContext) -> CommandResult:
        """Execute the command (alias for run to match Command Protocol).

        This method calls run() to maintain compatibility with the
        Command Protocol interface expected by the registry.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult indicating success or failure
        """
        return self.run(context)

    def __hash__(self) -> int:
        """Return a hash based on the class name and commands.

        Returns
        -------
            int: Hash value based on class name and commands.
        """
        return hash((self.__class__.__name__, tuple(self.COMMANDS)))

    @cached_property
    def solution(self) -> Solution:
        """Get the solution instance."""
        return Solution.from_directory(Path.cwd())

    @cached_property
    def projects(self) -> list:
        """Get a list of all Pytola projects in the solution."""
        return [p for p in self.solution.projects.values() if p.name.startswith("pytola")]

    @cached_property
    def pytola_projects(self) -> list:
        """获取所有 Pytola 项目."""
        return [project for project in self.projects if fnmatch.fnmatch(project.name, "pytola*")]

    def _run_command(self, command: list[str], cwd: Path | None = None) -> bool:
        """Run a single shell command with real-time console output.

        Args:
            command: Command to run as a list of strings.
            cwd: Working directory for the command. Defaults to current directory.

        Returns
        -------
            True if command succeeded (exit code 0), False otherwise.
        """
        cmd_str = " ".join(command)
        self.logger.info(f"Running: {cmd_str}")
        try:
            # Run command with real-time output to console
            result = subprocess.run(command, cwd=cwd, check=True)
        except FileNotFoundError:
            self.logger.exception(f"Command not found: `{command[0]}`")
            return False
        except Exception:
            self.logger.exception("Command failed unexpectedly")
            return False
        else:
            if result.returncode != 0:
                self.logger.error(f"Command failed (exit {result.returncode}): {cmd_str}")
                return False
            return True


class PymakeValidatableCommand(ValidatableCommand):
    """Enhanced ValidatableCommand with common utilities.

    Provides common validation methods and standardized execute flow.
    """

    def __init__(self) -> None:
        """Initialize the command with a logger."""
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)

    def validate_pyproject_exists(self, context: ExecutionContext) -> bool:
        """Validate that pyproject.toml exists in the project root.

        Args:
            context: Execution context

        Returns
        -------
            True if pyproject.toml exists, False otherwise
        """
        if context.project_root is None:
            self.logger.error("Could not determine project root")
            return False

        pyproject_path = context.project_root / "pyproject.toml"
        if not pyproject_path.exists():
            self.logger.error(f"pyproject.toml not found at {pyproject_path}")
            return False

        self.logger.debug(f"Found pyproject.toml at {pyproject_path}")
        return True

    def validate_build_tool(self, context: ExecutionContext) -> bool:
        """Validate that a build tool is available.

        Args:
            context: Execution context

        Returns
        -------
            True if build tool is available, False otherwise
        """
        build_tool = context.get_build_tool()
        if not build_tool:
            self.logger.error("Could not determine build tool from pyproject.toml")
            return False

        # Check if the build tool executable is available
        tool_name = build_tool.value
        if not shutil.which(tool_name):
            self.logger.error(f"Build tool '{tool_name}' not found in PATH")
            return False

        self.logger.debug(f"Build tool '{tool_name}' is available")
        return True
