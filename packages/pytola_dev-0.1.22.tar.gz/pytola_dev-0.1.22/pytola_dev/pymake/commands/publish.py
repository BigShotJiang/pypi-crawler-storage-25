"""Publish command for pymake."""

from __future__ import annotations

import os
from pathlib import Path

from ..core.context import ExecutionContext
from ..core.executor import CommandExecutor
from ..interfaces.command import CommandResult, CommandType
from .base import BaseCommand, PymakeValidatableCommand, register


@register(
    name="publish",
    aliases=["p"],
    description="发布所有项目",
    help_text="使用检测到的构建系统上传包到 PyPI",
    command_type=CommandType.PUBLISH,
)
class PublishCommand(BaseCommand, PymakeValidatableCommand):
    """发布命令，用于上传包到 PyPI."""

    name = "publish"
    alias = "p"
    description = "Publish all projects"
    command_type = CommandType.PUBLISH

    def validate(self, context: ExecutionContext) -> bool:
        """验证发布命令的先决条件.

        Args:
            context: Execution context

        Returns
        -------
            True if validation passes, False otherwise
        """
        # Check if pyproject.toml exists
        if not self.validate_pyproject_exists(context):
            return False

        # Check if build tool is available
        return self.validate_build_tool(context)

    def execute(self, context: ExecutionContext) -> CommandResult:
        """执行发布命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        # Validate prerequisites
        if not self.validate(context):
            return CommandResult(success=False, message="验证失败")

        # Get build tool
        build_tool = context.get_build_tool()
        if not build_tool:
            return CommandResult(success=False, message="无法确定构建工具")

        for project in self.pytola_projects:
            original_dir = Path.cwd()
            os.chdir(project.root_dir)

            # Create execution context for this project
            project_context = ExecutionContext(project.root_dir)

            # Step 1: Build the project first
            self.logger.info(f"正在构建项目：{project.name}")
            build_cmd = [build_tool.value, "build"]
            executor = CommandExecutor(project_context)
            build_result = executor.execute_shell_command(build_cmd)

            if not build_result.success:
                self.logger.error(f"构建失败，退出码 {build_result.exit_code}")
                os.chdir(original_dir)
                continue

            # Step 2: Publish the project
            self.logger.info(f"正在发布项目：{project.name}")
            publish_cmd = [build_tool.value, "publish"]
            result = executor.execute_shell_command(publish_cmd)

            if result.success:
                self.logger.info(f"{project.name} 发布成功完成")
            else:
                self.logger.error(f"{project.name} 发布失败，退出码 {result.exit_code}")

            os.chdir(original_dir)

        return CommandResult(success=True, message="发布完成")
