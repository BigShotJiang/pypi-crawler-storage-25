"""Test commands for pymake."""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from ..interfaces.command import CommandResult, CommandType
from .base import BaseCommand, register

if TYPE_CHECKING:
    from ..core.context import ExecutionContext


@register(
    name="test",
    aliases=["t"],
    description="测试所有项目",
    help_text="使用 pytest 运行测试 (8 个并行 worker)",
    command_type=CommandType.TEST,
)
class TestCommand(BaseCommand):
    """使用 pytest 运行并行执行的测试命令."""

    name = "test"
    alias = "t"
    description = "Test all projects"
    command_type = CommandType.TEST

    COMMANDS: ClassVar[list[list[str]]] = [["pytest", "-n", "8"]]

    def run(self, context: ExecutionContext) -> CommandResult:
        """运行测试命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        result = super().run(context)
        if result.success:
            self.logger.info("测试成功完成")
        else:
            self.logger.error("测试失败")
        return result


@register(
    name="test-benchmark",
    aliases=["tb"],
    description="使用基准测试测试所有项目",
    help_text="使用 pytest 运行基准测试",
    command_type=CommandType.TEST,
)
class TestBenchmarkCommand(BaseCommand):
    """使用 pytest 运行基准测试的测试命令."""

    name = "test-benchmark"
    alias = "tb"
    description = "Test all projects with benchmarking"
    command_type = CommandType.TEST

    COMMANDS: ClassVar[list[list[str]]] = [["pytest", "-m", "benchmark"]]

    def run(self, context: ExecutionContext) -> CommandResult:
        """运行基准测试命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        result = super().run(context)
        if result.success:
            self.logger.info("基准测试成功完成")
        else:
            self.logger.error("基准测试失败")
        return result


@register(
    name="test-coverage",
    aliases=["tc"],
    description="使用覆盖率测试所有项目",
    help_text="使用 pytest 和覆盖率报告运行测试",
    command_type=CommandType.TEST,
)
class TestCoverageCommand(BaseCommand):
    """使用 pytest 运行覆盖率报告的测试命令."""

    name = "test-coverage"
    alias = "tc"
    description = "Test all projects with coverage"
    command_type = CommandType.TEST

    COMMANDS: ClassVar[list[list[str]]] = [["pytest", "--cov=pytola", "--cov-report=term-missing", "-n", "auto"]]

    def run(self, context: ExecutionContext) -> CommandResult:
        """运行带覆盖率的测试命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        result = super().run(context)
        if result.success:
            self.logger.info("覆盖率测试成功完成")
        else:
            self.logger.error("覆盖率测试失败")
        return result


@register(
    name="test-single-worker",
    aliases=["td"],
    description="使用单 worker 测试所有项目",
    help_text="使用单个 worker 运行 pytest 测试",
    command_type=CommandType.TEST,
)
class TestSingleWorkerCommand(TestCommand):
    """使用单个 worker 运行 pytest 的测试命令."""

    name = "test-single-worker"
    alias = "td"
    description = "Test all projects with single worker"
    command_type = CommandType.TEST

    COMMANDS: ClassVar[list[list[str]]] = [["pytest"]]

    def run(self, context: ExecutionContext) -> CommandResult:
        """运行单 worker 测试命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        result = super().run(context)
        if result.success:
            self.logger.info("单 worker 测试成功完成")
        else:
            self.logger.error("单 worker 测试失败")
        return result
