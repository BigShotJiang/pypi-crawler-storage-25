"""PyPI token management command for pymake."""

from __future__ import annotations

import getpass
from typing import TYPE_CHECKING

from ..interfaces.command import CommandResult, CommandType
from .base import BaseCommand, register

if TYPE_CHECKING:
    from ..core.context import ExecutionContext


@register(
    name="token",
    aliases=["tk", "pypi-token"],
    description="设置 PyPI 认证令牌",
    help_text="安全存储 PyPI 认证令牌用于发布",
    command_type=CommandType.TOKEN,
)
class TokenCommand(BaseCommand):
    """设置 PyPI 认证令牌."""

    name = "token"
    alias = "tk"
    description = "Set PyPI authentication token"
    command_type = CommandType.TOKEN

    def run(self, context: ExecutionContext) -> CommandResult:
        """运行 token 命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        self.logger.info("设置 PyPI 认证令牌")

        # Prompt for token securely
        try:
            token = getpass.getpass("请输入 PyPI 令牌：")

            if not token.strip():
                self.logger.error("令牌不能为空")
                return CommandResult(success=False, message="令牌不能为空")

            # Store token in config
            context.config.set_pypi_token(token.strip(), save=True)

            self.logger.info("PyPI 令牌已保存")
            self.logger.info(f"令牌存储位置：{context.config._user_config_path}")

            return CommandResult(success=True, message="PyPI 令牌已保存", data={"token_set": True})

        except KeyboardInterrupt:
            self.logger.info("用户取消设置令牌")
            return CommandResult(success=False, message="用户取消")
        except Exception as e:
            self.logger.exception("保存令牌失败")
            return CommandResult(success=False, message=f"保存令牌失败：{e}")


@register(
    name="clear-token",
    aliases=["ct", "clear-tokens"],
    description="清除 PyPI 令牌",
    help_text="移除存储的 PyPI 认证令牌",
    command_type=CommandType.TOKEN,
)
class ClearTokenCommand(BaseCommand):
    """清除存储的 PyPI 令牌."""

    name = "clear-token"
    alias = "ct"
    description = "Clear stored PyPI token"
    command_type = CommandType.TOKEN

    def run(self, context: ExecutionContext) -> CommandResult:
        """运行清除令牌命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        self.logger.info("清除 PyPI 认证令牌")

        # Clear token
        context.config.pypi_token = None
        context.config.save(scope="user")

        self.logger.info("PyPI 令牌已清除")

        return CommandResult(success=True, message="PyPI 令牌已清除", data={"token_cleared": True})
