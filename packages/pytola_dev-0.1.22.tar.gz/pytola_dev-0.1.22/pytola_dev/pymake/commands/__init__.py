"""Commands for pymake."""

# Import all commands to register them
from .base import BaseCommand, PymakeValidatableCommand
from .build import BuildCommand
from .clean import CleanCommand
from .doc import DocCommand
from .init import InitCommand
from .lint import LintCommand
from .list import ListCommand
from .publish import PublishCommand
from .test import TestBenchmarkCommand, TestCommand, TestCoverageCommand, TestSingleWorkerCommand
from .token import ClearTokenCommand, TokenCommand
from .version import BumpVersionCommand, VersionCommand

__all__ = [
    # Base classes
    "BaseCommand",
    # Build commands
    "BuildCommand",
    "BumpVersionCommand",
    "CleanCommand",
    "ClearTokenCommand",
    "DocCommand",
    "InitCommand",
    # Code quality
    "LintCommand",
    # Project commands
    "ListCommand",
    # Publish commands
    "PublishCommand",
    "PymakeValidatableCommand",
    "TestBenchmarkCommand",
    # Test commands
    "TestCommand",
    "TestCoverageCommand",
    "TestSingleWorkerCommand",
    "TokenCommand",
    # Version commands
    "VersionCommand",
]
