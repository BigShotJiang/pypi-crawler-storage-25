"""Project initialization command for pymake."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..core.executor import CommandExecutor
from ..interfaces.command import CommandResult, CommandType
from .base import PymakeValidatableCommand, register

if TYPE_CHECKING:
    from ..core.context import ExecutionContext


@register(
    name="init",
    aliases=["i", "initialize"],
    description="初始化新项目",
    help_text="初始化 git 仓库、pre-commit 钩子和基础结构",
    command_type=CommandType.INIT,
)
class InitCommand(PymakeValidatableCommand):
    """初始化新项目."""

    name = "init"
    alias = "i"
    description = "Initialize new project"
    command_type = CommandType.INIT

    def validate(self, context: ExecutionContext) -> bool:
        """验证 init 命令的先决条件.

        Args:
            context: Execution context

        Returns
        -------
            True if validation passes, False otherwise
        """
        # Just need a valid directory
        if not context.cwd.exists():
            self.logger.error(f"目录不存在：{context.cwd}")
            return False

        return True

    def execute(self, context: ExecutionContext) -> CommandResult:
        """执行 init 命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        if not self.validate(context):
            return CommandResult(success=False, message="验证失败")

        self.logger.info("正在初始化项目...")

        # Step 1: Initialize git repository
        if not self._init_git(context):
            return CommandResult(success=False, message="初始化 git 仓库失败")

        # Step 2: Create .gitignore
        if not self._create_gitignore(context):
            self.logger.warning("创建 .gitignore 失败")

        # Step 3: Create README.md
        if not self._create_readme(context):
            self.logger.warning("创建 README.md 失败")

        # Step 4: Create LICENSE
        if not self._create_license(context):
            self.logger.warning("创建 LICENSE 失败")

        # Step 5: Install pre-commit hooks (if .pre-commit-config.yaml exists)
        self._install_precommit_hooks(context)

        self.logger.info("项目初始化成功完成")

        return CommandResult(success=True, message="项目初始化成功完成")

    def _init_git(self, context: ExecutionContext) -> bool:
        """初始化 git 仓库.

        Args:
            context: Execution context

        Returns
        -------
            True if initialization succeeded, False otherwise
        """
        executor = CommandExecutor(context)

        # Check if already a git repo
        if (context.cwd / ".git").exists():
            self.logger.info("git 仓库已初始化")
            return True

        self.logger.info("正在初始化 git 仓库...")
        cmd = ["git", "init"]
        result = executor.execute_shell_command(cmd, cwd=context.cwd)

        return result.success

    def _create_gitignore(self, context: ExecutionContext) -> bool:
        """创建 .gitignore 文件.

        Args:
            context: Execution context

        Returns
        -------
            True if creation succeeded, False otherwise
        """
        gitignore_path = context.cwd / ".gitignore"

        if gitignore_path.exists():
            self.logger.info(".gitignore 已存在")
            return True

        self.logger.info("正在创建 .gitignore...")

        gitignore_content = """# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# C extensions
*.so

# Distribution / packaging
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# PyInstaller
*.manifest
*.spec

# Installer logs
pip-log.txt
pip-delete-this-directory.txt

# Unit test / coverage reports
htmlcov/
.tox/
.nox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.py,cover
.hypothesis/
.pytest_cache/

# Translations
*.mo
*.pot

# Django stuff:
*.log
local_settings.py
db.sqlite3
db.sqlite3-journal

# Flask stuff:
instance/
.webassets-cache

# Scrapy stuff:
.scrapy

# Sphinx documentation
docs/_build/

# PyBuilder
target/

# Jupyter Notebook
.ipynb_checkpoints

# IPython
profile_default/
ipython_config.py

# pyenv
.python-version

# pipenv
Pipfile.lock

# PEP 582
__pypackages__/

# Celery stuff
celerybeat-schedule
celerybeat.pid

# SageMath parsed files
*.sage.py

# Environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# Spyder project settings
.spyderproject
.spyproject

# Rope project settings
.ropeproject

# mkdocs documentation
/site

# mypy
.mypy_cache/
.dmypy.json
dmypy.json

# Pyre type checker static analysis cache
.pyre/

# IDE
.idea/
.vscode/
*.swp
*.swo
*~

# OS
.DS_Store
Thumbs.db

# Project specific
.ruff_cache/
"""

        try:
            gitignore_path.write_text(gitignore_content, encoding="utf-8")
        except Exception:
            self.logger.exception("创建 .gitignore 失败")
            return False
        else:
            return True

    def _create_readme(self, context: ExecutionContext) -> bool:
        """创建 README.md 文件.

        Args:
            context: Execution context

        Returns
        -------
            True if creation succeeded, False otherwise
        """
        readme_path = context.cwd / "README.md"

        if readme_path.exists():
            self.logger.info("README.md 已存在")
            return True

        self.logger.info("正在创建 README.md...")

        # Try to get project name from pyproject.toml
        project_name = "My Project"
        if context.project_info:
            project_name = context.project_info.name

        readme_content = f"""# {project_name}

## 描述

TODO: 在此添加项目描述

## 安装

```bash
pip install -e .
```

## 用法

```python
# TODO: 添加使用示例
```

## 开发

### 设置

```bash
# 安装依赖
pip install -e ".[dev]"

# 运行测试
pymake test

# 运行 lint 检查
pymake lint
```

## 许可证

MIT License - 详见 LICENSE 文件
"""

        try:
            readme_path.write_text(readme_content, encoding="utf-8")
        except Exception:
            self.logger.exception("创建 README.md 失败")
            return False
        else:
            return True

    def _create_license(self, context: ExecutionContext) -> bool:
        """创建 LICENSE 文件 (MIT).

        Args:
            context: Execution context

        Returns
        -------
            True if creation succeeded, False otherwise
        """
        license_path = context.cwd / "LICENSE"

        if license_path.exists():
            self.logger.info("LICENSE 已存在")
            return True

        self.logger.info("正在创建 LICENSE (MIT)...")

        license_content = """MIT License

Copyright (c) 2024 TODO: 添加您的姓名

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

        try:
            license_path.write_text(license_content, encoding="utf-8")
        except Exception:
            self.logger.exception("创建 LICENSE 失败")
            return False
        else:
            return True

    def _install_precommit_hooks(self, context: ExecutionContext) -> None:
        """如果配置文件存在则安装 pre-commit 钩子.

        Args:
            context: Execution context
        """
        precommit_config = context.cwd / ".pre-commit-config.yaml"

        if not precommit_config.exists():
            self.logger.debug("未找到 .pre-commit-config.yaml，跳过钩子安装")
            return

        self.logger.info("正在安装 pre-commit 钩子...")

        executor = CommandExecutor(context)
        cmd = ["pre-commit", "install"]
        result = executor.execute_shell_command(cmd, cwd=context.cwd)

        if result.success:
            self.logger.info("pre-commit 钩子安装成功")
        else:
            self.logger.warning("安装 pre-commit 钩子失败")
