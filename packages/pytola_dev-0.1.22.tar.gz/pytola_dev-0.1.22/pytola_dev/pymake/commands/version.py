"""Version management commands for pymake."""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

from ..interfaces.command import CommandResult, CommandType
from ..utils.validators import validate_bump_type, validate_version
from .base import PymakeValidatableCommand, register

if TYPE_CHECKING:
    from ..core.context import ExecutionContext

VERSION_PARTS_COUNT = 3


@register(
    name="version",
    aliases=["v", "ver"],
    description="显示当前版本",
    help_text="显示当前项目版本",
    command_type=CommandType.UTIL,
)
class VersionCommand(PymakeValidatableCommand):
    """显示当前项目版本."""

    name = "version"
    alias = "v"
    description = "Show current version"
    command_type = CommandType.UTIL

    def validate(self, context: ExecutionContext) -> bool:
        """验证版本命令的先决条件.

        Args:
            context: Execution context

        Returns
        -------
            True if validation passes, False otherwise
        """
        return self.validate_pyproject_exists(context)

    def execute(self, context: ExecutionContext) -> CommandResult:
        """执行版本命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status and version info
        """
        if not self.validate(context):
            return CommandResult(success=False, message="验证失败")

        if not context.project_info:
            self.logger.error("无法读取项目信息")
            return CommandResult(success=False, message="读取项目信息失败")

        version = context.project_info.version
        self.logger.info(f"当前版本：{version}")

        return CommandResult(success=True, message=f"版本：{version}", data={"version": version})


@register(
    name="bumpversion",
    aliases=["bump", "bv"],
    description="增加项目版本",
    help_text="增加项目版本 (patch/minor/major)",
    command_type=CommandType.BUMP_VERSION,
)
class BumpVersionCommand(PymakeValidatableCommand):
    """增加项目版本."""

    name = "bumpversion"
    alias = "bump"
    description = "Bump project version"
    command_type = CommandType.BUMP_VERSION

    def __init__(self, bump_type: str = "patch") -> None:
        """初始化 bump version 命令.

        Args:
            bump_type: Type of version bump (patch/minor/major)
        """
        super().__init__()
        self.bump_type = bump_type.lower()

    def validate(self, context: ExecutionContext) -> bool:
        """验证 bump version 命令的先决条件.

        Args:
            context: Execution context

        Returns
        -------
            True if validation passes, False otherwise
        """
        # Check pyproject.toml exists
        if not self.validate_pyproject_exists(context):
            return False

        # Validate bump type
        is_valid, error_msg = validate_bump_type(self.bump_type)
        if not is_valid:
            self.logger.error(error_msg)
            return False

        # Validate current version format
        if context.project_info:
            is_valid, error_msg = validate_version(context.project_info.version)
            if not is_valid:
                self.logger.warning(f"当前版本格式可能无效：{error_msg}")

        return True

    def execute(self, context: ExecutionContext) -> CommandResult:
        """执行 bump version 命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        if not self.validate(context):
            return CommandResult(success=False, message="验证失败")

        if not context.project_root or not context.project_info:
            return CommandResult(success=False, message="无法确定项目根目录")

        # Get current version
        old_version = context.project_info.version
        new_version = self._calculate_new_version(old_version)

        self.logger.info(f"更新版本：{old_version} -> {new_version} ({self.bump_type})")

        # Update pyproject.toml
        pyproject_path = context.project_root / "pyproject.toml"
        if not self._update_pyproject_version(pyproject_path, new_version):
            return CommandResult(success=False, message="更新 pyproject.toml 失败")

        # Update __init__.py if it exists
        self._update_init_version(context.project_root, new_version)

        self.logger.info(f"版本更新成功：{new_version}")

        return CommandResult(
            success=True,
            message=f"版本已更新：{old_version} -> {new_version}",
            data={"old_version": old_version, "new_version": new_version},
        )

    def _calculate_new_version(self, current_version: str) -> str:
        """根据 bump 类型计算新版本.

        Args:
            current_version: Current version string (X.Y.Z)

        Returns
        -------
            New version string
        """
        parts = current_version.split(".")
        if len(parts) != VERSION_PARTS_COUNT:
            # Fallback to patch if format is unexpected
            self.bump_type = "patch"
            return "0.0.1"

        major, minor, patch = map(int, parts)

        if self.bump_type == "major":
            major += 1
            minor = 0
            patch = 0
        elif self.bump_type == "minor":
            minor += 1
            patch = 0
        else:  # patch
            patch += 1

        return f"{major}.{minor}.{patch}"

    def _update_pyproject_version(self, pyproject_path: Path, new_version: str) -> bool:
        """更新 pyproject.toml 文件中的版本.

        Args:
            pyproject_path: Path to pyproject.toml
            new_version: New version string

        Returns
        -------
            True if update succeeded, False otherwise
        """
        try:
            content = pyproject_path.read_text(encoding="utf-8")

            # Update version line
            version_pattern = r'^version\s*=\s*["\'].*?["\']'
            replacement = f'version = "{new_version}"'
            new_content = re.sub(version_pattern, replacement, content, flags=re.MULTILINE)

            if new_content == content:
                # Try alternative format
                alt_pattern = r'^version:\s*["\']?.*?["\']?\s*$'
                alt_replacement = f'version: "{new_version}"'
                new_content = re.sub(alt_pattern, alt_replacement, content, flags=re.MULTILINE)

            pyproject_path.write_text(new_content, encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            self.logger.exception("更新 pyproject.toml 失败")
            return False
        else:
            self.logger.debug(f"已更新版本：{pyproject_path}")
            return True

    def _update_init_version(self, project_root: Path, new_version: str) -> bool:
        """如果存在则更新 __init__.py 文件中的版本.

        Args:
            project_root: Project root directory
            new_version: New version string

        Returns
        -------
            True if update succeeded, False otherwise
        """
        init_path = project_root / "__init__.py"
        if not init_path.exists():
            self.logger.debug(f"未找到 __init__.py，跳过版本更新：{init_path}")
            return True

        try:
            content = init_path.read_text(encoding="utf-8")

            # Look for __version__ pattern
            version_pattern = r'^__version__\s*=\s*["\'].*?["\']'
            replacement = f'__version__ = "{new_version}"'
            new_content = re.sub(version_pattern, replacement, content, flags=re.MULTILINE)

            if new_content != content:
                init_path.write_text(new_content, encoding="utf-8")
                self.logger.debug(f"已更新版本：{init_path}")
        except (OSError, UnicodeDecodeError) as e:
            self.logger.warning(f"更新 __init__.py 失败：{e}")
            return True  # Don't fail the command if this fails
        else:
            return True
