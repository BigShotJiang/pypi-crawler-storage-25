"""Lint command for pymake."""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from ..interfaces.command import CommandResult, CommandType
from .base import BaseCommand, register

if TYPE_CHECKING:
    from ..core.context import ExecutionContext


@register(
    name="lint",
    aliases=["l"],
    description="检查所有项目",
    help_text="使用 ruff 检查代码质量并自动修复问题",
    command_type=CommandType.UTIL,
)
class LintCommand(BaseCommand):
    """检查代码质量的 lint 命令."""

    name = "lint"
    alias = "l"
    description = "Lint all projects"
    command_type = CommandType.UTIL

    COMMANDS: ClassVar[list[list[str]]] = [["ruff", "check", ".", "--fix", "--unsafe-fixes"]]

    def run(self, context: ExecutionContext) -> CommandResult:
        """运行 lint 命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        result = super().run(context)
        if result.success:
            self.logger.info("lint 检查成功完成")
        else:
            self.logger.error("lint 检查失败")
        return result
