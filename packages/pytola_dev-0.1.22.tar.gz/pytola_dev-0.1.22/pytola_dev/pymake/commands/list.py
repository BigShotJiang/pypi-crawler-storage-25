"""List command for pymake."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..interfaces.command import CommandResult, CommandType
from .base import BaseCommand, register

if TYPE_CHECKING:
    from ..core.context import ExecutionContext


@register(
    name="list",
    aliases=["ls", "list"],
    description="列出所有项目",
    help_text="显示解决方案中的所有 Pytola 项目",
    command_type=CommandType.UTIL,
)
class ListCommand(BaseCommand):
    """列出所有项目的命令."""

    name = "list"
    alias = "ls"
    description = "List all projects"
    command_type = CommandType.UTIL

    def run(self, context: ExecutionContext) -> CommandResult:  # noqa: ARG002
        """列出解决方案中的所有项目.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        if not self.projects:
            self.logger.info("解决方案中没有找到 Pytola 项目")
            return CommandResult(success=True, message="未找到项目")

        self.logger.info(f"找到 {len(self.projects)} 个项目:")
        for project in self.projects:
            self.logger.info(f"  - {project.name} (v{project.version})")

        return CommandResult(
            success=True,
            message=f"已列出 {len(self.projects)} 个项目",
            data={"count": len(self.projects), "projects": [p.name for p in self.projects]},
        )
