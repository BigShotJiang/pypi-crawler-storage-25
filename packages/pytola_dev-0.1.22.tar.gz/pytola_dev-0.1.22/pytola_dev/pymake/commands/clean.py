"""Clean command for pymake."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import ClassVar

from ..core.context import ExecutionContext
from ..interfaces.command import CommandResult, CommandType
from .base import BaseCommand, register


@register(
    name="clean",
    aliases=["c"],
    description="清理构建产物",
    help_text="移除构建目录和生成的文件",
    command_type=CommandType.CLEAN,
)
class CleanCommand(BaseCommand):
    """清理命令，用于移除构建产物."""

    name = "clean"
    alias = "c"
    description = "Clean build artifacts"
    command_type = CommandType.CLEAN

    # Patterns to clean in each project
    CLEAN_PATTERNS: ClassVar[list[str]] = ["build", "dist", "*.egg-info", "__pycache__", ".pytest_cache", ".ruff_cache"]

    def run(self, context: ExecutionContext) -> CommandResult:  # noqa: ARG002
        """清理所有项目.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult indicating success or failure
        """
        self.logger.info("Starting clean action")

        for project in self.projects:
            self.logger.info(f"Cleaning project: {project.name}")
            self._clean_project(project.root_dir)

        self.logger.info("Clean action completed")
        return CommandResult(success=True, message="清理成功完成")

    def _clean_project(self, package_path: Path) -> None:
        """清理项目的构建产物.

        Args:
            package_path: Path to the project directory
        """
        for pattern in self.CLEAN_PATTERNS:
            for item in package_path.glob(pattern):
                try:
                    if item.is_dir():
                        shutil.rmtree(item)
                        self.logger.info(f"Removed directory: {item.relative_to(package_path)}")
                    else:
                        item.unlink()
                        self.logger.info(f"Removed file: {item.relative_to(package_path)}")
                except Exception as e:  # noqa: BLE001, PERF203
                    self.logger.warning(f"Failed to remove {item}: {e}")
