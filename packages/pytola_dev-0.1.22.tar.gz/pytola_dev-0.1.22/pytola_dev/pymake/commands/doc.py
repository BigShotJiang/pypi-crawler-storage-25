"""Documentation generation command for pymake."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import TYPE_CHECKING

from ..core.executor import CommandExecutor
from ..interfaces.command import CommandResult, CommandType
from .base import PymakeValidatableCommand, register

if TYPE_CHECKING:
    from ..core.context import ExecutionContext


@register(
    name="doc",
    aliases=["d", "docs", "documentation"],
    description="生成 Sphinx 文档",
    help_text="生成 Sphinx HTML 文档，包括 API 文档",
    command_type=CommandType.DOC,
)
class DocCommand(PymakeValidatableCommand):
    """生成 Sphinx 文档."""

    name = "doc"
    alias = "d"
    description = "Generate Sphinx documentation"
    command_type = CommandType.DOC

    def validate(self, context: ExecutionContext) -> bool:
        """验证 doc 命令的先决条件.

        Args:
            context: Execution context

        Returns
        -------
            True if validation passes, False otherwise
        """
        # Check if project root exists
        if not self.validate_pyproject_exists(context):
            return False

        # Check if sphinx is available
        if not shutil.which("sphinx-quickstart"):
            self.logger.error("未找到 Sphinx，请安装：pip install sphinx")
            return False

        return True

    def execute(self, context: ExecutionContext) -> CommandResult:
        """执行 doc 命令.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        if not self.validate(context):
            return CommandResult(success=False, message="验证失败")

        if not context.project_root:
            return CommandResult(success=False, message="无法确定项目根目录")

        docs_dir = context.project_root / "docs"

        # Step 1: Initialize Sphinx if docs directory doesn't exist or is empty
        if not docs_dir.exists() or not any(docs_dir.iterdir()):
            self.logger.info("正在初始化 Sphinx 文档...")
            if not self._init_sphinx(docs_dir, context):
                return CommandResult(success=False, message="初始化 Sphinx 失败")

        # Step 2: Generate API documentation with sphinx-apidoc
        self.logger.info("正在生成 API 文档...")
        if not self._generate_api_docs(context):
            self.logger.warning("API 文档生成失败，继续执行...")

        # Step 3: Build HTML documentation
        self.logger.info("正在构建 HTML 文档...")
        if not self._build_html(docs_dir, context):
            return CommandResult(success=False, message="构建 HTML 文档失败")

        self.logger.info(f"文档已生成：{docs_dir / '_build' / 'html'}")

        return CommandResult(
            success=True,
            message=f"文档已生成：{docs_dir / '_build' / 'html'}",
            data={"output_dir": str(docs_dir / "_build" / "html")},
        )

    def _init_sphinx(self, docs_dir: Path, context: ExecutionContext) -> bool:
        """初始化 Sphinx 文档.

        Args:
            docs_dir: Directory for documentation
            context: Execution context

        Returns
        -------
            True if initialization succeeded, False otherwise
        """
        executor = CommandExecutor(context)

        # Run sphinx-quickstart with minimal prompts
        cmd = [
            "sphinx-quickstart",
            "--sep",  # Separate source and build directories
            "-p",
            context.project_info.name if context.project_info else "Project",
            "-a",
            "Pytola Team",
            "-v",
            "0.1",
            "-r",
            "0.1",
            "-l",
            "en",
            "--ext-autodoc",
            "--ext-viewcode",
            "--ext-doctree",
            "--ext-todo",
            "--no-batchfile",
            str(docs_dir),
        ]

        result = executor.execute_shell_command(cmd)
        return result.success

    def _generate_api_docs(self, context: ExecutionContext) -> bool:
        """使用 sphinx-apidoc 生成 API 文档.

        Args:
            context: Execution context

        Returns
        -------
            True if generation succeeded, False otherwise
        """
        if not context.project_root:
            return False

        executor = CommandExecutor(context)

        # Find the main package directory
        package_name = self._find_package_name(context.project_root)
        if not package_name:
            self.logger.warning("无法确定包名，跳过 API 文档生成")
            return False

        package_dir = context.project_root / package_name
        if not package_dir.exists():
            self.logger.warning(f"未找到包目录：{package_dir}")
            return False

        docs_source = context.project_root / "docs" / "source"
        if not docs_source.exists():
            docs_source = context.project_root / "docs"

        # Run sphinx-apidoc
        cmd = [
            "sphinx-apidoc",
            "-o",
            str(docs_source),
            "-f",  # Overwrite existing files
            "-e",  # Put each module in separate page
            "-M",  # Put module templates before submodule templates
            str(package_dir),
        ]

        result = executor.execute_shell_command(cmd)
        return result.success

    def _build_html(self, docs_dir: Path, context: ExecutionContext) -> bool:
        """构建 HTML 文档.

        Args:
            docs_dir: Documentation directory
            context: Execution context

        Returns
        -------
            True if build succeeded, False otherwise
        """
        executor = CommandExecutor(context)

        # Determine source and build directories
        source_dir = docs_dir / "source" if (docs_dir / "source").exists() else docs_dir
        build_dir = docs_dir / "_build"

        # Run sphinx-build
        cmd = [
            "sphinx-build",
            "-b",
            "html",
            "-E",  # Don't use saved environment
            str(source_dir),
            str(build_dir / "html"),
        ]

        result = executor.execute_shell_command(cmd)
        return result.success

    def _find_package_name(self, project_root: Path) -> str | None:
        """查找项目中的主包名.

        Args:
            project_root: Project root directory

        Returns
        -------
            Package name or None if not found
        """
        # Look for directories with __init__.py
        for item in project_root.iterdir():
            if item.is_dir() and not item.name.startswith((".", "_")) and (item / "__init__.py").exists():
                return item.name

        # Fallback: use project name
        return None
