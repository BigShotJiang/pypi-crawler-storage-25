"""Base module for formatters."""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from functools import cached_property
from pathlib import Path
from typing import ClassVar


class BaseFormatter(ABC):
    """Base class for auto-formatting tools."""

    IGNORE_PATTERNS: ClassVar[set[str]] = {
        "__pycache__",
        "dist",
        "build",
        ".venv",
        "venv",
        "env",
        ".env",
        "tests",
        ".tox",
    }

    def __init__(self, root_dir: Path | None = None, *, check_only: bool = False, dry_run: bool = True) -> None:
        self.root_dir = root_dir or Path.cwd()
        self.check_only = check_only
        self.dry_run = dry_run

    @abstractmethod
    def run(self, *, dry_run: bool = True, check_only: bool = False) -> bool:
        """Run the formatter on all Python files.

        Args:
            dry_run: If True, only report changes without writing
            check_only: If True, only check if conversion is needed

        Returns
        -------
            True if successful, False otherwise
        """

    @cached_property
    def python_files(self) -> set[Path]:
        """Get a set of Python files in the root directory, excluding certain folders."""
        py_files = set()
        for root, _, files in os.walk(self.root_dir):
            if any(part in self.IGNORE_PATTERNS for part in Path(root).parts):
                continue

            for file in files:
                if file.endswith(".py"):
                    py_files.add(Path(root) / file)
        return py_files

    @cached_property
    def init_files(self) -> set[Path]:
        """Get a set of __init__.py files in the root directory, excluding certain folders."""
        return {f for f in self.python_files if f.name == "__init__.py"}
