# eeglab

This package reserves the `eeglab` Python package namespace for the official EEGLAB project by the SCCN / EEGLAB development team.

This initial release is intentionally minimal. Functional Python interfaces for EEGLAB may be added in later releases.

EEGLAB: https://sccn.ucsd.edu/eeglab/
