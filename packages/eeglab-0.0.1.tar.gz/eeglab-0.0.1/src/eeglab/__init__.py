"""Python package namespace for the official EEGLAB project."""

__version__ = "0.0.1"
