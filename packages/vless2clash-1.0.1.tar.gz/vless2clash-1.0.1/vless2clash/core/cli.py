import os
import sys
import base64
import argparse

from vless2clash import __version__
from .generator import show_config


def _parser():
    parser = argparse.ArgumentParser(
        formatter_class=lambda prog: argparse.HelpFormatter(prog, max_help_position=40)
    )
    main_args = parser.add_argument_group("main")
    optional_args = parser.add_argument_group("optional")

    parser.add_argument("-v", "--version", action="version", version=__version__)

    group = main_args.add_mutually_exclusive_group()
    group.add_argument("-d",  "--decode",     action="store_true", help="base64 decode to proxies for Mihomo config")
    group.add_argument("-dr", "--decode-raw", action="store_true", help="base64 decode to VLESS links")

    optional_args.add_argument("-c", "--counter", type=int, default=None, metavar="NUMB", help="starting index for server names")
    optional_args.add_argument("-g", "--group",             default=None, metavar="NAME", help="proxy-group name for Mihomo config")

    main_args.add_argument("string", help="VLESS links (text or base64) or a file path containing them")

    return parser


def _validate_args(args: argparse.Namespace, parser: argparse.ArgumentParser):
    if args.decode_raw:
        optional = next(group for group in parser._action_groups if group.title == "optional")

        error = False
        optional_list = []

        for action in optional._group_actions:
            optional_list.append(f"  {', '.join(action.option_strings)}")

            if getattr(args, action.dest) != action.default:
                error = True

        if optional_list and error:
            parser.error(f"these options cannot be used with --decode-raw:\n{chr(10).join(optional_list)}")
    
    return args


def _read_file(path: str):
    if (os.path.isfile(path)):
        with open(path, "r", encoding="utf-8") as file:
            content = file.read().strip()
            return content if content else None
    return None


def _decode_base64(string: str):
    return base64.b64decode(string).decode("utf-8").strip()


def execute():
    try:
        sys.stdout.reconfigure(encoding='utf-8')

        parser = _parser()
        args = _validate_args(parser.parse_args(), parser)
        links = _read_file(args.string) or args.string

        if args.decode or args.decode_raw:
            links = _decode_base64(links)

        show_config(links.split("\n"), args.counter, args.group, args.decode_raw, sys.stdout.isatty())
    except Exception as e:
        parser.error(str(e))