import shutil
import urllib.parse


def _parse_vless(url: str, counter: int, names: bool):
    parsed = urllib.parse.urlparse(url)    
    query_params = urllib.parse.parse_qs(parsed.query)

    return {
        "name": urllib.parse.unquote(parsed.fragment or "").strip() or f"SERVER-{counter:02d}" if names else f"SERVER-{counter:02d}",
        "type": "vless",
        "server": parsed.hostname,
        "port": parsed.port,
        "uuid": parsed.username,
        "network": query_params.get("type", ["tcp"])[0],
        "tls": "true",
        "udp": "true",
        "flow": query_params.get("flow", [""])[0],
        "servername": query_params.get("sni", [""])[0],
        "reality-opts": {
            "public-key": query_params.get("pbk", [""])[0],
            "short-id": query_params.get("sid", [""])[0],
            "support-x25519mlkem768": "false"
        },
        "client-fingerprint": query_params.get("fp", ["chrome"])[0]
    }


def _generate_config(servers: list, counter: int):
    original_names = counter is None
    if original_names:
        counter = 1

    config = {
        "proxies": [],
        "proxy-groups": []
    }
    
    for vless_url in servers:
        proxy = _parse_vless(vless_url, counter, original_names)
        config["proxies"].append(proxy)
        config["proxy-groups"].append(proxy["name"])
        
        counter += 1

    return config


def show_config(servers: list, counter: int, group: str, raw: bool, istty: bool):
    width = shutil.get_terminal_size(fallback=(80, 24)).columns

    separation_start = f"\n{'#' * width}\n\n" if istty else ""
    separation_end = f"\n\n{'#' * width}\n" if istty else ""

    if not raw:
        config = _generate_config(servers, counter)

        print(
            f"{separation_start}"
            f"proxies:"
        )

        for proxy in config["proxies"]:
            for key, value in proxy.items():
                
                if key == "name":
                    print(f"  - {key}: {value}")

                elif isinstance(value, str):
                    print(f"    {key}: {value}")

                elif isinstance(value, dict):
                    print(f"    {key}:")
                    for sub_key, sub_value in value.items():
                        print(f"      {sub_key}: {sub_value}")

            print()

        print(
            f"\n\n\n"
            f"proxy-groups:\n"
            f"  - name: \"{group}\"\n"
            f"    type: select\n"
            f"    proxies:\n"
            f"{chr(10).join(f'      - {name}' for name in config['proxy-groups'])}"
            f"{separation_end}"
        )
    
    else:
        print(
            f"{separation_start}"
            f"{chr(10).join(servers)}"
            f"{separation_end}"
        )