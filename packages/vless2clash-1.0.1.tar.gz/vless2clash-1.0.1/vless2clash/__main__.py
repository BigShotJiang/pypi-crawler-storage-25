from .core.cli import execute


if __name__ == "__main__":
    execute()