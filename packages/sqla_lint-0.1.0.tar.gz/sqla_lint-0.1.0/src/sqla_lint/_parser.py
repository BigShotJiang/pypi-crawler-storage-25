"""AST-based parser for detecting SQLAlchemy query patterns in Python source files.

This module provides static analysis of ``.py`` files: it parses the Python
AST and checks for the same violations that :class:`~sqla_lint.Linter` checks
at runtime — without importing or executing any user code.

Limitations compared to the runtime linter
-------------------------------------------
* Only single-expression chains are analysed.  If a query is built up across
  multiple statements (``q = select(...); q = q.where(...)``) only the
  individual fragments are seen.
* SQLA007 (implicit cross-join) requires knowing the *types* of expressions
  and is not checked here.
* False positives are possible for functions whose names collide with
  SQLAlchemy constructors (``select``, ``delete``, ``update``) that are *not*
  imported from SQLAlchemy.  Import tracking reduces this in most cases.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from ._models import Severity

# ---------------------------------------------------------------------------
# Public result type
# ---------------------------------------------------------------------------

_SQLA_CONSTRUCTORS: frozenset[str] = frozenset({"select", "delete", "update", "insert"})


@dataclass
class FileViolation:
    """A lint violation found at a specific location in a source file."""

    rule_id: str
    message: str
    severity: Severity
    filename: str
    line: int
    col: int

    def __str__(self) -> str:
        return (
            f"{self.filename}:{self.line}:{self.col}: "
            f"[{self.severity.value.upper()}] {self.rule_id}: {self.message}"
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_file(path: str | Path) -> list[FileViolation]:
    """Parse *path* and return all SQLAlchemy lint violations found in the source.

    Returns an empty list if the file has a syntax error.

    Example::

        from sqla_lint import parse_file

        for violation in parse_file("myapp/queries.py"):
            print(violation)
    """
    path = Path(path)
    try:
        source = path.read_text(encoding="utf-8")
    except OSError:
        return []
    return _lint_source(source, str(path))


def parse_source(source: str, filename: str = "<string>") -> list[FileViolation]:
    """Lint *source* (a Python source string) and return violations.

    *filename* is used only for reporting.
    """
    return _lint_source(source, filename)


# ---------------------------------------------------------------------------
# Internal: import tracking
# ---------------------------------------------------------------------------


class _ImportTracker(ast.NodeVisitor):
    """Collect which local names refer to SQLAlchemy constructors or modules."""

    def __init__(self) -> None:
        # local_name → canonical sqlalchemy name  e.g. 'sel' → 'select'
        self.sqla_names: dict[str, str] = {}
        # local names that *are* the sqlalchemy module  e.g. 'sa', 'sqlalchemy'
        self.sqla_modules: set[str] = set()

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            if alias.name == "sqlalchemy" or alias.name.startswith("sqlalchemy."):
                local = alias.asname if alias.asname else alias.name
                self.sqla_modules.add(local)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        mod = node.module or ""
        if mod == "sqlalchemy" or mod.startswith("sqlalchemy."):
            for alias in node.names:
                local = alias.asname if alias.asname else alias.name
                self.sqla_names[local] = alias.name
        self.generic_visit(node)

    def is_sqla_call(self, call: ast.Call) -> bool:
        """Return True if *call* is (likely) a SQLAlchemy constructor call."""
        func = call.func
        if isinstance(func, ast.Name):
            # Direct name: select(...), delete(...), etc.
            name = func.id
            # Known import from sqlalchemy
            if name in self.sqla_names:
                return True
            # Heuristic: name matches a constructor and no explicit import
            # contradicts it (i.e. it was never imported from *another* module).
            if name in _SQLA_CONSTRUCTORS and name not in self.sqla_names:
                # Only flag if there are *no* import-from statements that
                # imported this name from a non-sqla source.
                return True
        if isinstance(func, ast.Attribute):
            # Module-qualified: sa.select(...), sqlalchemy.delete(...)
            if isinstance(func.value, ast.Name):
                return func.value.id in self.sqla_modules
        return False

    def canonical_name(self, call: ast.Call) -> str | None:
        """Return the canonical SQLAlchemy function name for *call*, or None."""
        func = call.func
        if isinstance(func, ast.Name):
            return self.sqla_names.get(func.id, func.id)
        if isinstance(func, ast.Attribute):
            return func.attr
        return None


# ---------------------------------------------------------------------------
# Internal: chain unwrapping
# ---------------------------------------------------------------------------


def _unwrap_chain(node: ast.Call) -> tuple[str | None, set[str], ast.Call | None]:
    """Walk from the outermost call inward to find the root constructor.

    Given ``select(t).where(c).limit(10)`` (as the outermost ``Call`` node)
    this returns ``('select', {'where', 'limit'}, <inner select Call>)``.
    """
    methods: set[str] = set()
    current: ast.expr = node

    # Walk inward through method-call chains: value.method(args)
    # Only continue when the attribute's value is itself a Call — this
    # distinguishes a real chain (select(...).where(...)) from a module-
    # qualified call (sa.select(...)) where value is a bare Name.
    while (
        isinstance(current, ast.Call)
        and isinstance(current.func, ast.Attribute)
        and isinstance(current.func.value, ast.Call)
    ):
        methods.add(current.func.attr)
        current = current.func.value

    if not isinstance(current, ast.Call):
        return None, methods, None

    # current is now the innermost call — extract the function name
    func = current.func
    if isinstance(func, ast.Name):
        root_name: str | None = func.id
    elif isinstance(func, ast.Attribute):
        root_name = func.attr
    else:
        root_name = None

    return root_name, methods, current


# ---------------------------------------------------------------------------
# Internal: AST visitor
# ---------------------------------------------------------------------------


class _QueryVisitor(ast.NodeVisitor):
    def __init__(
        self,
        filename: str,
        tracker: _ImportTracker,
        parent_map: dict[int, ast.AST],
    ) -> None:
        self.filename = filename
        self.tracker = tracker
        self.parent_map = parent_map
        self.violations: list[FileViolation] = []
        # Tracks how many loop "bodies" we are currently nested inside.
        # Incremented when entering the repeated part of a for/while/comprehension;
        # the one-time parts (the iterable expression, orelse) stay at the
        # outer depth so they are not mistakenly flagged.
        self._loop_depth: int = 0

    # ------------------------------------------------------------------
    # Loop-aware traversal
    # ------------------------------------------------------------------

    def visit_For(self, node: ast.For) -> None:
        # iter is evaluated once — visit at current depth
        self.visit(node.iter)
        # body is evaluated N times — visit at incremented depth
        self._loop_depth += 1
        for stmt in node.body:
            self.visit(stmt)
        self._loop_depth -= 1
        # orelse runs at most once after the loop
        for stmt in node.orelse:
            self.visit(stmt)

    def visit_While(self, node: ast.While) -> None:
        # test and body are both re-evaluated every iteration
        self._loop_depth += 1
        self.visit(node.test)
        for stmt in node.body:
            self.visit(stmt)
        self._loop_depth -= 1
        for stmt in node.orelse:
            self.visit(stmt)

    def visit_ListComp(self, node: ast.ListComp) -> None:
        self._visit_comp(node.elt, node.generators)

    def visit_SetComp(self, node: ast.SetComp) -> None:
        self._visit_comp(node.elt, node.generators)

    def visit_GeneratorExp(self, node: ast.GeneratorExp) -> None:
        self._visit_comp(node.elt, node.generators)

    def visit_DictComp(self, node: ast.DictComp) -> None:
        # DictComp has key+value instead of a single elt
        if node.generators:
            self.visit(node.generators[0].iter)
        self._loop_depth += 1
        self.visit(node.key)
        self.visit(node.value)
        for i, gen in enumerate(node.generators):
            for cond in gen.ifs:
                self.visit(cond)
            if i > 0:
                self.visit(gen.iter)
        self._loop_depth -= 1

    def _visit_comp(self, elt: ast.expr, generators: list[ast.comprehension]) -> None:
        """Shared traversal for list/set/generator comprehensions.

        The first generator's ``iter`` is evaluated once in the enclosing
        scope; everything else (the element expression, if-clauses, and
        subsequent generators' iters) runs once per element.
        """
        if generators:
            # Outermost iterable — evaluated once, keep current depth
            self.visit(generators[0].iter)
        self._loop_depth += 1
        self.visit(elt)
        for i, gen in enumerate(generators):
            for cond in gen.ifs:
                self.visit(cond)
            if i > 0:
                # Subsequent generator iters are in the inner scope
                self.visit(gen.iter)
        self._loop_depth -= 1

    # ------------------------------------------------------------------
    # Query call visitor
    # ------------------------------------------------------------------

    def visit_Call(self, node: ast.Call) -> None:
        # Only process the outermost call in each method-chain so we don't
        # emit duplicate violations for intermediate nodes.
        if not self._is_chain_receiver(node):
            root_name, methods, root_call = _unwrap_chain(node)
            if (
                root_call is not None
                and root_name in _SQLA_CONSTRUCTORS
                and self.tracker.is_sqla_call(root_call)
            ):
                for v in self._check_query(node, root_name, methods, root_call):
                    self.violations.append(v)
                # SQLA008 — query inside a loop
                if self._loop_depth > 0:
                    self.violations.append(
                        self._v(
                            "SQLA008",
                            f"{root_name}() called inside a loop — this is a potential "
                            "N+1 query; consider eager loading or a single bulk query",
                            Severity.WARNING,
                            root_call.lineno,
                            root_call.col_offset,
                        )
                    )
        self.generic_visit(node)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _is_chain_receiver(self, node: ast.Call) -> bool:
        """Return True if *node* is the receiver (value) of a method-call chain.

        When ``select(t).limit(10)`` is parsed the inner ``select(t)`` Call
        appears as the ``value`` of the ``Attribute`` node for ``.limit``.
        Its parent in the AST is therefore that ``Attribute`` node, not the
        outer ``Call`` — which is how we detect it is not the outermost call.
        """
        parent = self.parent_map.get(id(node))
        return isinstance(parent, ast.Attribute)

    def _v(
        self,
        rule_id: str,
        message: str,
        severity: Severity,
        line: int,
        col: int,
    ) -> FileViolation:
        return FileViolation(
            rule_id=rule_id,
            message=message,
            severity=severity,
            filename=self.filename,
            line=line,
            col=col,
        )

    # ------------------------------------------------------------------
    # Rule checks
    # ------------------------------------------------------------------

    def _check_query(
        self,
        outer: ast.Call,
        constructor: str,
        methods: set[str],
        root: ast.Call,
    ) -> Iterator[FileViolation]:
        line, col = root.lineno, root.col_offset

        if constructor == "select":
            yield from self._check_select(outer, methods, line, col)
        elif constructor == "delete":
            yield from self._check_delete(methods, line, col)
        elif constructor == "update":
            yield from self._check_update(methods, line, col)

    def _check_select(
        self,
        outer: ast.Call,
        methods: set[str],
        line: int,
        col: int,
    ) -> Iterator[FileViolation]:
        # SQLA001 — SELECT *
        if self._root_call_has_star(outer):
            yield self._v(
                "SQLA001",
                "Query uses SELECT * — explicitly list the columns you need",
                Severity.WARNING,
                line,
                col,
            )

        # SQLA004 — no LIMIT
        if "limit" not in methods:
            yield self._v(
                "SQLA004",
                "SELECT has no LIMIT — consider adding one to avoid fetching unbounded rows",
                Severity.WARNING,
                line,
                col,
            )

        # SQLA005 — LIMIT without ORDER BY
        if "limit" in methods and "order_by" not in methods:
            yield self._v(
                "SQLA005",
                "SELECT uses LIMIT without ORDER BY — row order is non-deterministic",
                Severity.WARNING,
                line,
                col,
            )

        # SQLA006 — count(*)
        if self._expr_has_count_star(outer):
            yield self._v(
                "SQLA006",
                "Query uses count(*) — prefer count(1) or count(primary_key) for clarity",
                Severity.INFO,
                line,
                col,
            )

    def _check_delete(
        self, methods: set[str], line: int, col: int
    ) -> Iterator[FileViolation]:
        # SQLA002 — DELETE without WHERE
        if "where" not in methods and "filter" not in methods:
            yield self._v(
                "SQLA002",
                "DELETE statement has no WHERE clause — this will delete all rows in the table",
                Severity.ERROR,
                line,
                col,
            )

    def _check_update(
        self, methods: set[str], line: int, col: int
    ) -> Iterator[FileViolation]:
        # SQLA003 — UPDATE without WHERE
        if "where" not in methods and "filter" not in methods:
            yield self._v(
                "SQLA003",
                "UPDATE statement has no WHERE clause — this will update all rows in the table",
                Severity.ERROR,
                line,
                col,
            )

    # ------------------------------------------------------------------
    # AST pattern helpers
    # ------------------------------------------------------------------

    def _root_call_has_star(self, outer: ast.Call) -> bool:
        """Return True if the innermost select() call receives ``text('*')``.

        We walk *inward* along the chain to find the root call's args — the
        same logic as ``_unwrap_chain`` but we only need the innermost args.
        """
        current: ast.expr = outer
        while (
            isinstance(current, ast.Call)
            and isinstance(current.func, ast.Attribute)
            and isinstance(current.func.value, ast.Call)
        ):
            current = current.func.value
        if not isinstance(current, ast.Call):
            return False
        return self._args_contain_star(current.args)

    def _args_contain_star(self, args: list[ast.expr]) -> bool:
        for arg in args:
            # text("*")  or  column("*")
            if isinstance(arg, ast.Call) and isinstance(
                arg.func, (ast.Name, ast.Attribute)
            ):
                func_name = (
                    arg.func.id if isinstance(arg.func, ast.Name) else arg.func.attr
                )
                if func_name in ("text", "column"):
                    for inner in arg.args:
                        if isinstance(inner, ast.Constant) and inner.value == "*":
                            return True
            # Bare string literal "*" (non-standard but detectable)
            if isinstance(arg, ast.Constant) and arg.value == "*":
                return True
        return False

    def _expr_has_count_star(self, node: ast.expr) -> bool:
        """Return True if *node* contains a ``count()`` / ``count(text('*'))`` call."""
        for child in ast.walk(node):
            if not isinstance(child, ast.Call):
                continue
            func = child.func
            if not (isinstance(func, ast.Attribute) and func.attr == "count"):
                continue
            # func.count() with no arguments → COUNT(*)
            if not child.args and not child.keywords:
                return True
            # func.count(text("*")) or func.count(column("*"))
            for arg in child.args:
                if isinstance(arg, ast.Call) and isinstance(
                    arg.func, (ast.Name, ast.Attribute)
                ):
                    inner_name = (
                        arg.func.id if isinstance(arg.func, ast.Name) else arg.func.attr
                    )
                    if inner_name in ("text", "column"):
                        for inner in arg.args:
                            if isinstance(inner, ast.Constant) and inner.value == "*":
                                return True
        return False


# ---------------------------------------------------------------------------
# Internal: orchestration
# ---------------------------------------------------------------------------


def _lint_source(source: str, filename: str) -> list[FileViolation]:
    try:
        tree = ast.parse(source, filename=filename)
    except SyntaxError:
        return []

    # Build parent map: id(child) → parent node
    parent_map: dict[int, ast.AST] = {}
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            parent_map[id(child)] = node

    tracker = _ImportTracker()
    tracker.visit(tree)

    visitor = _QueryVisitor(filename, tracker, parent_map)
    visitor.visit(tree)
    return visitor.violations
