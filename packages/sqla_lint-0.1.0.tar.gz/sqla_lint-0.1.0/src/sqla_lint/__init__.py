"""sqla-lint — SQLAlchemy query linter.

Quick start::

    from sqlalchemy import select, delete
    import sqla_lint

    # Lint a single query with all default rules
    result = sqla_lint.lint(select(...))

    # Skip specific rules
    config = sqla_lint.LintConfig(skip_rules={"SQLA004", "SQLA006"})
    result = sqla_lint.lint(stmt, config=config)

    # Override severity for a rule
    from sqla_lint import LintConfig, RuleConfig, Severity
    config = LintConfig(
        rule_configs={"SQLA004": RuleConfig(severity_override=Severity.ERROR)}
    )
"""

from ._linter import Linter, lint
from ._models import LintConfig, LintResult, LintViolation, RuleConfig, Severity
from ._parser import FileViolation, parse_file, parse_source
from ._rules import ALL_RULES, Rule

__all__ = [
    # Core API
    "lint",
    "Linter",
    # Static file analysis
    "parse_file",
    "parse_source",
    "FileViolation",
    # Configuration
    "LintConfig",
    "RuleConfig",
    # Result types
    "LintResult",
    "LintViolation",
    "Severity",
    # Rule primitives
    "Rule",
    "ALL_RULES",
]
