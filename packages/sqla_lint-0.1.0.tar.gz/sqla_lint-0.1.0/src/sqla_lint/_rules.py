"""Built-in lint rules for SQLAlchemy queries.

Each rule is a class with a stable ``rule_id`` (e.g. ``"SQLA001"``) so users
can skip individual rules via :class:`~sqla_lint.LintConfig`.

Adding a custom rule
--------------------
Subclass :class:`Rule`, set ``rule_id``, ``description``, and
``default_severity``, implement :meth:`Rule.check`, then pass an instance
to :class:`~sqla_lint.Linter` via the ``rules`` parameter.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ._models import LintViolation, Severity


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------


class Rule(ABC):
    """Abstract base for all lint rules."""

    rule_id: str
    description: str
    default_severity: Severity

    @abstractmethod
    def check(self, query: Any) -> list[LintViolation]:
        """Inspect *query* and return any violations found."""
        ...

    def _violation(
        self, message: str, severity: Severity | None = None
    ) -> LintViolation:
        return LintViolation(
            rule_id=self.rule_id,
            message=message,
            severity=severity if severity is not None else self.default_severity,
        )


# ---------------------------------------------------------------------------
# Duck-typing helpers (no SQLAlchemy import required)
# ---------------------------------------------------------------------------


def _sqla_mro_names(obj: Any) -> set[str]:
    """Return the set of class names in *obj*'s MRO that belong to sqlalchemy."""
    return {
        cls.__name__
        for cls in type(obj).__mro__
        if cls.__module__.startswith("sqlalchemy")
    }


def _is_select(obj: Any) -> bool:
    return "Select" in _sqla_mro_names(obj)


def _is_delete(obj: Any) -> bool:
    return "Delete" in _sqla_mro_names(obj)


def _is_update(obj: Any) -> bool:
    return "Update" in _sqla_mro_names(obj)


def _is_join(obj: Any) -> bool:
    return "Join" in _sqla_mro_names(obj)


def _is_text_clause(obj: Any) -> bool:
    return "TextClause" in _sqla_mro_names(obj)


def _is_column_clause(obj: Any) -> bool:
    return "ColumnClause" in _sqla_mro_names(obj)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_select(query: Any) -> Any | None:
    """Return the underlying Select for *query*, or ``None``."""
    # ORM legacy Query exposes .statement
    if hasattr(query, "statement"):
        stmt = query.statement
        if _is_select(stmt):
            return stmt
    if _is_select(query):
        return query
    return None


def _iter_elements(query: Any):
    """Iterate over all SQLAlchemy clause elements inside *query*."""
    try:
        from sqlalchemy.sql import visitors  # lazy import

        yield from visitors.iterate(query)
        return
    except ImportError:
        pass
    # Fallback: walk via get_children() which is part of SQLAlchemy's public API
    try:
        yield query
        for child in query.get_children():
            yield from _iter_elements(child)
    except Exception:
        return


def _has_literal_star(stmt: Any) -> bool:
    """Return ``True`` if the SELECT clause contains a literal ``*`` at the top level.

    We intentionally avoid deep recursion so that ``count(*)`` (which internally
    holds a ``ColumnClause('*')``) does not trigger this check.
    """
    try:
        columns = stmt.inner_columns
    except Exception:
        return False
    for col in columns:
        if _is_text_clause(col) and col.text.strip() == "*":
            return True
        if _is_column_clause(col) and col.key == "*":
            return True
        # label('*') or similar wrappers
        inner = getattr(col, "element", None)
        if inner is not None and (_is_text_clause(inner) or _is_column_clause(inner)):
            key = getattr(inner, "key", None) or getattr(inner, "text", "")
            if key.strip() == "*":
                return True
    return False


def _has_count_star(stmt: Any) -> bool:
    """Return ``True`` if the query calls ``count(*)`` (explicit or implicit).

    ``func.count()`` with no user-supplied argument compiles to ``COUNT(*)``
    by injecting a ``ColumnClause('*')`` internally — we detect that here.
    """
    for elem in _iter_elements(stmt):
        name = getattr(elem, "name", None)
        if not (isinstance(name, str) and name.lower() == "count"):
            continue
        clauses = list(getattr(getattr(elem, "clauses", None), "clauses", ()))
        if not clauses:
            return True
        for clause in clauses:
            if _is_column_clause(clause) and clause.key == "*":
                return True
            if _is_text_clause(clause) and clause.text.strip() == "*":
                return True
    return False


def _has_limit(stmt: Any) -> bool:
    return getattr(stmt, "_limit_clause", None) is not None


def _has_order_by(stmt: Any) -> bool:
    return bool(getattr(stmt, "_order_by_clauses", ()))


# ---------------------------------------------------------------------------
# Rules
# ---------------------------------------------------------------------------


class SelectStarRule(Rule):
    """SQLA001 — Detects queries that select a literal ``*`` column."""

    rule_id = "SQLA001"
    description = "Avoid SELECT * — use explicit column names"
    default_severity = Severity.WARNING

    def check(self, query: Any) -> list[LintViolation]:
        stmt = _to_select(query)
        if stmt is None:
            return []
        if _has_literal_star(stmt):
            return [
                self._violation(
                    "Query uses SELECT * — explicitly list the columns you need"
                )
            ]
        return []


class MissingWhereOnDeleteRule(Rule):
    """SQLA002 — Detects DELETE statements with no WHERE clause."""

    rule_id = "SQLA002"
    description = "DELETE without WHERE clause affects every row in the table"
    default_severity = Severity.ERROR

    def check(self, query: Any) -> list[LintViolation]:
        if not _is_delete(query):
            return []
        if query.whereclause is None:
            return [
                self._violation(
                    "DELETE statement has no WHERE clause — this will delete all rows in the table"
                )
            ]
        return []


class MissingWhereOnUpdateRule(Rule):
    """SQLA003 — Detects UPDATE statements with no WHERE clause."""

    rule_id = "SQLA003"
    description = "UPDATE without WHERE clause affects every row in the table"
    default_severity = Severity.ERROR

    def check(self, query: Any) -> list[LintViolation]:
        if not _is_update(query):
            return []
        if query.whereclause is None:
            return [
                self._violation(
                    "UPDATE statement has no WHERE clause — this will update all rows in the table"
                )
            ]
        return []


class MissingLimitRule(Rule):
    """SQLA004 — Detects SELECT statements that fetch an unbounded result set."""

    rule_id = "SQLA004"
    description = "SELECT without LIMIT may return an unbounded result set"
    default_severity = Severity.WARNING

    def check(self, query: Any) -> list[LintViolation]:
        stmt = _to_select(query)
        if stmt is None:
            return []
        if not _has_limit(stmt):
            return [
                self._violation(
                    "SELECT has no LIMIT — consider adding one to avoid fetching unbounded rows"
                )
            ]
        return []


class LimitWithoutOrderByRule(Rule):
    """SQLA005 — Detects LIMIT without ORDER BY, which yields non-deterministic pages."""

    rule_id = "SQLA005"
    description = "LIMIT without ORDER BY produces non-deterministic results"
    default_severity = Severity.WARNING

    def check(self, query: Any) -> list[LintViolation]:
        stmt = _to_select(query)
        if stmt is None:
            return []
        if _has_limit(stmt) and not _has_order_by(stmt):
            return [
                self._violation(
                    "SELECT uses LIMIT without ORDER BY — row order is non-deterministic"
                )
            ]
        return []


class CountStarRule(Rule):
    """SQLA006 — Detects ``count()`` with no arguments, which compiles to ``COUNT(*)``."""

    rule_id = "SQLA006"
    description = "Prefer count(1) or count(primary_key) over count(*)"
    default_severity = Severity.INFO

    def check(self, query: Any) -> list[LintViolation]:
        stmt = _to_select(query)
        if stmt is None:
            return []
        if _has_count_star(stmt):
            return [
                self._violation(
                    "Query uses count(*) — prefer count(1) or count(primary_key) for clarity"
                )
            ]
        return []


class ImplicitCrossJoinRule(Rule):
    """SQLA007 — Detects multiple FROM tables without an explicit JOIN condition.

    A query like ``select(A, B)`` without ``.join()`` or a WHERE linking the
    two tables produces a Cartesian product.
    """

    rule_id = "SQLA007"
    description = "Multiple FROM tables without JOIN produces a Cartesian product"
    default_severity = Severity.ERROR

    def check(self, query: Any) -> list[LintViolation]:
        stmt = _to_select(query)
        if stmt is None:
            return []

        try:
            froms = stmt.froms
        except Exception:
            return []

        # If there are 2+ raw table references and no explicit JOIN, flag it.
        plain_froms = [f for f in froms if not _is_join(f)]
        if len(plain_froms) >= 2:
            names = ", ".join(getattr(f, "name", repr(f)) for f in plain_froms)
            return [
                self._violation(
                    f"Query references {len(plain_froms)} tables ({names}) without an explicit "
                    "JOIN — this creates a Cartesian product"
                )
            ]
        return []


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

ALL_RULES: list[Rule] = [
    SelectStarRule(),
    MissingWhereOnDeleteRule(),
    MissingWhereOnUpdateRule(),
    MissingLimitRule(),
    LimitWithoutOrderByRule(),
    CountStarRule(),
    ImplicitCrossJoinRule(),
]
