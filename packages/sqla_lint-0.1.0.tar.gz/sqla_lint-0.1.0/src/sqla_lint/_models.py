from dataclasses import dataclass, field
from enum import Enum


class Severity(Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class LintViolation:
    rule_id: str
    message: str
    severity: Severity


@dataclass
class LintResult:
    violations: list[LintViolation] = field(default_factory=list)

    @property
    def has_violations(self) -> bool:
        return bool(self.violations)

    @property
    def errors(self) -> list[LintViolation]:
        return [v for v in self.violations if v.severity == Severity.ERROR]

    @property
    def warnings(self) -> list[LintViolation]:
        return [v for v in self.violations if v.severity == Severity.WARNING]

    @property
    def infos(self) -> list[LintViolation]:
        return [v for v in self.violations if v.severity == Severity.INFO]


@dataclass
class RuleConfig:
    enabled: bool = True
    severity_override: Severity | None = None


@dataclass
class LintConfig:
    """Configuration for the linter.

    Use ``skip_rules`` to disable rules by ID (e.g. ``{"SQLA004"}``).
    Use ``rule_configs`` for per-rule options such as toggling or overriding severity.
    """

    skip_rules: set[str] = field(default_factory=set)
    rule_configs: dict[str, RuleConfig] = field(default_factory=dict)

    def is_rule_enabled(self, rule_id: str) -> bool:
        if rule_id in self.skip_rules:
            return False
        config = self.rule_configs.get(rule_id)
        if config is not None:
            return config.enabled
        return True

    def effective_severity(self, rule_id: str, default: Severity) -> Severity:
        config = self.rule_configs.get(rule_id)
        if config is not None and config.severity_override is not None:
            return config.severity_override
        return default
