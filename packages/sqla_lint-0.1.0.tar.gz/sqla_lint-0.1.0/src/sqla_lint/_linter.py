from __future__ import annotations

from typing import Any

from ._models import LintConfig, LintResult, LintViolation
from ._rules import ALL_RULES, Rule


class Linter:
    """Runs a set of :class:`~sqla_lint.Rule` objects against SQLAlchemy queries.

    Parameters
    ----------
    config:
        Controls which rules are active and lets you override per-rule severity.
        Defaults to :class:`~sqla_lint.LintConfig` with all rules enabled.
    rules:
        The rule instances to run.  Defaults to :data:`~sqla_lint._rules.ALL_RULES`.
        Pass a custom list to use only specific rules or to add your own.
    """

    def __init__(
        self,
        config: LintConfig | None = None,
        rules: list[Rule] | None = None,
    ) -> None:
        self.config = config or LintConfig()
        self.rules = rules if rules is not None else list(ALL_RULES)

    def lint(self, query: Any) -> LintResult:
        """Lint *query* and return a :class:`~sqla_lint.LintResult`."""
        result = LintResult()
        for rule in self.rules:
            if not self.config.is_rule_enabled(rule.rule_id):
                continue
            for violation in rule.check(query):
                result.violations.append(
                    LintViolation(
                        rule_id=violation.rule_id,
                        message=violation.message,
                        severity=self.config.effective_severity(
                            violation.rule_id, violation.severity
                        ),
                    )
                )
        return result


def lint(query: Any, config: LintConfig | None = None) -> LintResult:
    """Convenience wrapper — lint *query* with an optional :class:`~sqla_lint.LintConfig`.

    Example::

        from sqlalchemy import select, text
        import sqla_lint

        stmt = select(text("*")).select_from(users)
        result = sqla_lint.lint(stmt)
        for v in result.violations:
            print(f"[{v.severity.value.upper()}] {v.rule_id}: {v.message}")
    """
    return Linter(config=config).lint(query)
