"""Command-line interface for sqla-lint.

Entry point: ``sqla-lint`` (configured in pyproject.toml).

Usage
-----
    sqla-lint path/to/file.py
    sqla-lint src/                        # recurse into a directory
    sqla-lint "src/**/*.py"               # shell glob
    sqla-lint src/ --skip SQLA004,SQLA006
    sqla-lint src/ --select SQLA002,SQLA003
    sqla-lint src/ --min-severity error
    sqla-lint src/ --format json

Exit codes
----------
    0   No violations found (at or above --min-severity).
    1   One or more violations found.
    2   Usage / I/O error (no files found, unreadable path, …).
"""

from __future__ import annotations

import argparse
import glob
import json
import sys
from pathlib import Path

from ._models import Severity
from ._parser import FileViolation, parse_file

# Ordered from least to most severe — used for --min-severity filtering.
_SEVERITY_ORDER = [Severity.INFO, Severity.WARNING, Severity.ERROR]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> None:
    args = _build_parser().parse_args(argv)

    skip_rules = _split_ids(args.skip)
    select_rules = _split_ids(args.select)
    min_severity = Severity(args.min_severity)

    files = _collect_files(args.paths)
    if not files:
        _err("no Python files found for the given path(s)")
        sys.exit(2)

    all_violations: list[FileViolation] = []
    for path in files:
        for v in parse_file(path):
            if skip_rules and v.rule_id in skip_rules:
                continue
            if select_rules and v.rule_id not in select_rules:
                continue
            if _SEVERITY_ORDER.index(v.severity) < _SEVERITY_ORDER.index(min_severity):
                continue
            all_violations.append(v)

    if not args.quiet:
        if args.format == "json":
            _print_json(all_violations)
        else:
            _print_text(all_violations)

    sys.exit(1 if all_violations else 0)


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="sqla-lint",
        description="Lint Python source files for SQLAlchemy query anti-patterns.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=_EPILOG,
    )

    p.add_argument(
        "paths",
        nargs="+",
        metavar="PATH",
        help=(
            "Files or directories to lint.  Directories are searched recursively "
            "for '*.py' files.  Shell glob patterns (e.g. 'src/**/*.py') are "
            "accepted when quoted."
        ),
    )
    p.add_argument(
        "--skip",
        metavar="RULE[,RULE…]",
        action="append",
        default=[],
        help=(
            "Rule ID(s) to skip.  Accepts a comma-separated list or may be "
            "repeated.  Example: --skip SQLA004 --skip SQLA006"
        ),
    )
    p.add_argument(
        "--select",
        metavar="RULE[,RULE…]",
        action="append",
        default=[],
        help=(
            "Only report these rule ID(s).  Accepts a comma-separated list or "
            "may be repeated.  Takes precedence over --skip when both are given."
        ),
    )
    p.add_argument(
        "--min-severity",
        choices=["error", "warning", "info"],
        default="info",
        metavar="LEVEL",
        help="Minimum severity to report: error | warning | info  (default: info).",
    )
    p.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format: text (default) or json.",
    )
    p.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Suppress all output; rely on exit code only.",
    )

    return p


_EPILOG = """\
Rules
-----
  SQLA001  SELECT * — use explicit column names             [warning]
  SQLA002  DELETE without WHERE clause                      [error]
  SQLA003  UPDATE without WHERE clause                      [error]
  SQLA004  SELECT without LIMIT                             [warning]
  SQLA005  LIMIT without ORDER BY                           [warning]
  SQLA006  count(*) — prefer count(1) or count(pk)         [info]
  SQLA007  Implicit cross-join (runtime linter only)        [error]
  SQLA008  Query inside a loop — potential N+1              [warning]
"""


# ---------------------------------------------------------------------------
# File collection
# ---------------------------------------------------------------------------


def _collect_files(paths: list[str]) -> list[Path]:
    """Expand paths / directories / glob patterns into a sorted list of .py files."""
    seen: set[Path] = set()
    result: list[Path] = []

    def _add(p: Path) -> None:
        resolved = p.resolve()
        if resolved not in seen:
            seen.add(resolved)
            result.append(p)

    for raw in paths:
        p = Path(raw)
        if p.is_file():
            if p.suffix == ".py":
                _add(p)
        elif p.is_dir():
            for f in sorted(p.rglob("*.py")):
                _add(f)
        else:
            # Treat as a shell glob pattern (useful on Windows or when quoted)
            matched = sorted(glob.glob(raw, recursive=True))
            for m in matched:
                mp = Path(m)
                if mp.is_file() and mp.suffix == ".py":
                    _add(mp)

    return result


# ---------------------------------------------------------------------------
# Output formatters
# ---------------------------------------------------------------------------


def _print_text(violations: list[FileViolation]) -> None:
    for v in violations:
        print(v)

    if violations:
        errors = sum(1 for v in violations if v.severity == Severity.ERROR)
        warnings = sum(1 for v in violations if v.severity == Severity.WARNING)
        infos = sum(1 for v in violations if v.severity == Severity.INFO)

        parts: list[str] = []
        if errors:
            parts.append(f"{errors} error{'s' if errors != 1 else ''}")
        if warnings:
            parts.append(f"{warnings} warning{'s' if warnings != 1 else ''}")
        if infos:
            parts.append(f"{infos} info")

        total = len(violations)
        _err(f"{total} violation{'s' if total != 1 else ''}: {', '.join(parts)}")


def _print_json(violations: list[FileViolation]) -> None:
    print(
        json.dumps(
            [
                {
                    "rule_id": v.rule_id,
                    "message": v.message,
                    "severity": v.severity.value,
                    "filename": v.filename,
                    "line": v.line,
                    "col": v.col,
                }
                for v in violations
            ],
            indent=2,
        )
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _split_ids(items: list[str]) -> set[str]:
    """Flatten ``["SQLA001,SQLA002", "SQLA003"]`` → ``{"SQLA001", "SQLA002", "SQLA003"}``."""
    result: set[str] = set()
    for item in items:
        for part in item.split(","):
            stripped = part.strip()
            if stripped:
                result.add(stripped)
    return result


def _err(message: str) -> None:
    print(f"sqla-lint: {message}", file=sys.stderr)
