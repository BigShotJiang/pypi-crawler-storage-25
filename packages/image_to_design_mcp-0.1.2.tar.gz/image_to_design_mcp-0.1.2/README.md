# gauss-mcp

基于 `uv` 管理的 Python MCP server，用于把本地图片导入为方案，并通过 job 协议提供可轮询的进度与结果。

## 当前 MVP 范围

- 输入本地图片路径
- 上传图片
- 判断普通图/全景图
- 普通图转全景图
- 可选清家具
- 全景图转点云
- 空间调整
- 导入方案
- 返回 design link

## 核心设计

- 单次 tool 调用只做有限工作，不阻塞等待整条链路结束
- 对外主流程只暴露 5 个 job tools：
  - `gauss_start_image_job`
  - `gauss_poll_job`
  - `gauss_get_job`
  - `gauss_resume_job`
  - `gauss_list_jobs`
- 通过阶段事件而不是 fake percent 给 skill 提供进度展示依据
- 长耗时阶段按低频轮询推进，默认 15-30 秒一轮，避免大量碎片化等待输出
- `gauss_import` 完成后会立即产出 `design_url`，用户可以先打开方案预览；`gauss_show_info` 继续补齐 `splat_url` / `drc_url`
- job 状态落盘到 `IMAGE_TO_DESIGN_JOB_STATE_DIR`，支持中断后继续查询或恢复

## 阶段顺序

1. `upload`
2. `image_type`
3. `img2pano`
4. `pano_clear`
5. `pano2pointcloud`
6. `spatial_tune`
7. `gauss_import`
8. `gauss_show_info`

## 开发

```bash
uv sync --dev
uv run pytest
uv run ruff check src tests
```

## 运行 MCP Server

```bash
uv run gauss-mcp
```

## 本地 smoke test

```bash
uv run python scripts/e2e_image_to_plan.py /absolute/path/to/image.png
```

可选参数：

```bash
uv run python scripts/e2e_image_to_plan.py /absolute/path/to/image.png \
  --floor-plan-name demo-plan \
  --level-height-mm 2800 \
  --no-clear-furniture
```

## Claude Code Skill

Skill 位于：

```text
.claude/skills/gauss-image-to-plan/SKILL.md
```

它基于 `gauss_*` job tools 做阶段式编排：

- 长耗时阶段默认按约 30 秒节奏低频心跳
- `gauss_import` 完成后先返回可预览的 `design_url`
- `gauss_show_info` 继续补齐 `splat_url` / `drc_url`
