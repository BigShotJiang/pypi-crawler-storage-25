from __future__ import annotations

from typing import Any

from image_to_design_mcp.client import GAUSS_SHOW_STATUS_LABELS, IMPORT_STATUS_LABELS, ApiClient, status_label
from image_to_design_mcp.config import Settings, get_settings
from image_to_design_mcp.errors import ImageToDesignError
from image_to_design_mcp.models import ImageToDesignJob


class GaussImportApi:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()

    async def start(self, job: ImageToDesignJob) -> str:
        payload = _build_import_payload(job)
        async with ApiClient(settings=self.settings) as client:
            task_id = await client.post("/kam/api/gauss/import", json=payload)
        if not isinstance(task_id, str) or not task_id.strip():
            raise ImageToDesignError(
                "gauss_import_submit_error",
                "提交导入方案任务失败，未返回 task_id",
                details={"response": task_id, "payload": payload},
            )
        return task_id.strip()

    async def get_status(self, task_id: str) -> dict[str, Any]:
        data = await self._get_status(task_id)
        status = _coerce_int(data.get("status"))
        if status == 0:
            return {"done": False, "message": data.get("message") or status_label(IMPORT_STATUS_LABELS, status)}
        if status != 1:
            raise self._status_error(stage="gauss_import", task_id=task_id, status=status, data=data)

        level_status = _coerce_int(data.get("levelStatus"))
        if level_status == 0:
            return {"done": False, "message": data.get("message") or "楼层导入处理中"}
        if level_status not in (None, 1):
            raise self._status_error(stage="gauss_import_level", task_id=task_id, status=level_status, data=data)

        obs_design_id = _require_string(data, "obsDesignId", task_id=task_id)
        obs_plan_id = _require_string(data, "obsPlanId", task_id=task_id)
        level_id = _require_string(data, "levelId", task_id=task_id)

        return {
            "done": True,
            "message": data.get("message") or "导入方案完成",
            "obs_design_id": obs_design_id,
            "obs_plan_id": obs_plan_id,
            "level_id": level_id,
            "design_url": _build_design_url(self.settings.base_url, obs_design_id),
        }

    async def get_show_info(self, job: ImageToDesignJob) -> dict[str, Any]:
        obs_design_id = job.result.obsDesignId
        level_id = job.result.levelId
        if not obs_design_id or not level_id:
            raise ImageToDesignError(
                "missing_show_info_params",
                "缺少 obsDesignId 或 levelId，无法查询方案信息",
                details={"obs_design_id": obs_design_id, "level_id": level_id},
            )

        async with ApiClient(settings=self.settings) as client:
            data = await client.get(f"/kam/api/gauss/info/{obs_design_id}", params={"levelid": level_id})
        if not isinstance(data, dict):
            raise ImageToDesignError(
                "gauss_show_info_error",
                "查询方案信息失败，返回结构异常",
                details={"obs_design_id": obs_design_id, "level_id": level_id, "response": data},
            )

        status = _coerce_int(data.get("status"))
        if status in (0, 1):
            return {"done": False, "message": data.get("message") or status_label(GAUSS_SHOW_STATUS_LABELS, status)}
        if status != 2:
            raise ImageToDesignError(
                "gauss_show_info_failed",
                f"查询方案信息失败，状态: {status_label(GAUSS_SHOW_STATUS_LABELS, status)}",
                details={"obs_design_id": obs_design_id, "level_id": level_id, "status": status, "response": data},
            )

        result: dict[str, Any] = {
            "done": True,
            "message": data.get("message") or "方案信息查询完成",
            "design_url": _build_design_url(self.settings.base_url, obs_design_id),
        }
        splat_url = _optional_string(data.get("splatUrl"))
        drc_url = _optional_string(data.get("drcUrl"))
        if splat_url:
            result["splat_url"] = splat_url
        if drc_url:
            result["drc_url"] = drc_url
        return result

    async def _get_status(self, task_id: str) -> dict[str, Any]:
        async with ApiClient(settings=self.settings) as client:
            data = await client.get("/kam/api/gauss/status", params={"taskId": task_id})
        if not isinstance(data, dict):
            raise ImageToDesignError(
                "gauss_import_status_error",
                "查询导入方案状态失败，返回结构异常",
                details={"task_id": task_id, "response": data},
            )
        return data

    def _status_error(self, *, stage: str, task_id: str, status: int | None, data: dict[str, Any]) -> ImageToDesignError:
        return ImageToDesignError(
            "gauss_import_failed",
            f"{stage} 任务失败，状态: {status_label(IMPORT_STATUS_LABELS, status)}",
            details={"stage": stage, "task_id": task_id, "status": status, "response": data},
        )


def _build_import_payload(job: ImageToDesignJob) -> dict[str, Any]:
    point_cloud_ply_url = _require_job_string(job.artifacts.pointCloudPlyUrl, "pointCloudPlyUrl")
    point_cloud_drc_url = _require_job_string(job.artifacts.pointCloudDrcUrl, "pointCloudDrcUrl")
    pano_depth_url = _require_job_string(job.artifacts.panoDepthUrl, "panoDepthUrl")
    pano_mask_url = _require_job_string(job.artifacts.panoMaskUrl, "panoMaskUrl")
    pano_image_url = _require_job_string(_effective_pano_url(job), "effectivePanoUrl")
    gs_scale = _require_job_float(job.artifacts.gsScale, "gsScale")
    bottom_position = _require_job_point(job.artifacts.floorplanBottomPosition, "floorplanBottomPosition")
    top_position = _require_job_point(job.artifacts.floorplanTopPosition, "floorplanTopPosition")
    rotate = _require_job_float(job.artifacts.floorplanTuneRotate, "floorplanTuneRotate")

    scene_height = top_position["z"] - bottom_position["z"]
    if scene_height <= 0:
        raise ImageToDesignError(
            "invalid_spatial_tune_result",
            "空间调整结果异常，topPosition.z 必须大于 bottomPosition.z",
            details={"bottom_position": bottom_position, "top_position": top_position},
        )

    payload: dict[str, Any] = {
        "fileName": point_cloud_ply_url,
        "spatialGen": True,
        "floorPlanName": _optional_string(job.floor_plan_name),
        "originPosition": bottom_position,
        "position": bottom_position,
        "rotation": {"x": 0.0, "y": 0.0, "z": rotate},
        "scale": job.level_height_mm / scene_height,
        "importParams": _default_import_params(job.level_height_mm),
        "spatialPanoParam": {
            "result_drc": point_cloud_drc_url,
            "result_ply": point_cloud_ply_url,
            "result_gs_scale": str(gs_scale),
            "result_depth": pano_depth_url,
            "result_mask": pano_mask_url,
            "uploadPanoImagePath": pano_image_url,
        },
        "gaussFileInfo": job.artifacts.model_dump(mode="json", exclude_none=True),
    }
    if payload["floorPlanName"] is None:
        payload.pop("floorPlanName")
    return payload


def _default_import_params(level_height_mm: float) -> dict[str, Any]:
    return {
        "paramMode": "Custom",
        "showModel": True,
        "mergeCollinearConnectedWalls": True,
        "params": [
            _height_param("doorOpening", 2200, 10000, 1, offground=0, offground_max=5000, offground_min=0),
            _height_param("slidingDoor", 2200, 10000, 1, offground=0, offground_max=5000, offground_min=0),
            _height_param("singleDoor", 2200, 10000, 1, offground=0, offground_max=5000, offground_min=0),
            _height_param("doubleDoor", 2200, 10000, 1, offground=0, offground_max=5000, offground_min=0),
            _height_param("window", 1300, 10000, 1, offground=900, offground_max=5000, offground_min=0),
            _height_param("floor", 120, 1000, 1),
            _height_param("levelHeight", level_height_mm, 20000, 1),
        ],
        "mergeWallTol": 20,
        "freeWallEndExtension": True,
        "maxDistanceBetweenFreeEndpoints": 100,
        "maxAttemptedExtensionLength": 100,
    }


def _height_param(
    param_type: str,
    height: float,
    max_value: float,
    min_value: float,
    *,
    offground: float | None = None,
    offground_max: float | None = None,
    offground_min: float | None = None,
) -> dict[str, Any]:
    data: dict[str, Any] = {
        "type": param_type,
        "height": {"value": height, "maxValue": max_value, "minValue": min_value},
    }
    if offground is not None and offground_max is not None and offground_min is not None:
        data["offground"] = {"value": offground, "maxValue": offground_max, "minValue": offground_min}
    return data


def _build_design_url(base_url: str, obs_design_id: str) -> str:
    return f"{base_url.rstrip('/')}/cloud/tool/h5/bim?designid={obs_design_id}&__appfv=kam_gs&__rd=y&_gr_ds=true"


def _effective_pano_url(job: ImageToDesignJob) -> str | None:
    return job.artifacts.panoClearImgUrl or job.artifacts.panoImgUrl or job.artifacts.originImgUrl


def _coerce_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _optional_string(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _require_string(payload: dict[str, Any], key: str, *, task_id: str) -> str:
    value = _optional_string(payload.get(key))
    if value is not None:
        return value
    raise ImageToDesignError(
        "missing_result_field",
        f"gauss_import 返回字段 {key} 为空",
        details={"task_id": task_id, "key": key, "response": payload},
    )


def _require_job_string(value: Any, field: str) -> str:
    normalized = _optional_string(value)
    if normalized is not None:
        return normalized
    raise ImageToDesignError("missing_job_artifact", f"缺少 {field}，无法执行导入方案")


def _require_job_float(value: Any, field: str) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ImageToDesignError("invalid_job_artifact", f"{field} 不是数字，无法执行导入方案", details={"field": field, "value": value}) from exc


def _require_job_point(value: Any, field: str) -> dict[str, float]:
    if not isinstance(value, dict):
        raise ImageToDesignError("missing_job_artifact", f"缺少 {field}，无法执行导入方案")
    return {
        "x": _require_job_float(value.get("x"), f"{field}.x"),
        "y": _require_job_float(value.get("y"), f"{field}.y"),
        "z": _require_job_float(value.get("z"), f"{field}.z"),
    }
