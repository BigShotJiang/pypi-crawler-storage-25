from __future__ import annotations

from datetime import datetime, timezone
from functools import lru_cache
from typing import Any, Awaitable, Callable

from mcp.server.fastmcp import FastMCP

from image_to_design_mcp.config import Settings, get_settings
from image_to_design_mcp.engine import JobEngine, PollResult
from image_to_design_mcp.errors import ImageToDesignError
from image_to_design_mcp.gauss_import import GaussImportApi
from image_to_design_mcp.maas import MaasApi
from image_to_design_mcp.models import ImageToDesignJob, JobEvent, StageStatus, STAGE_SEQUENCE
from image_to_design_mcp.spatial_tune import SpatialTuneApi
from image_to_design_mcp.store import JobStore
from image_to_design_mcp.upload import upload_local_image


def build_job_engine(
    settings: Settings | None = None,
    *,
    uploader: Callable[[str], Awaitable[dict[str, Any]]] | None = None,
    maas: MaasApi | None = None,
    spatial_tune: SpatialTuneApi | None = None,
    gauss_import: GaussImportApi | None = None,
) -> JobEngine:
    resolved_settings = settings or get_settings()
    return JobEngine(
        store=JobStore(resolved_settings),
        uploader=uploader or (lambda local_path: upload_local_image(local_path, settings=resolved_settings)),
        maas=maas or MaasApi(resolved_settings),
        spatial_tune=spatial_tune or SpatialTuneApi(resolved_settings),
        gauss_import=gauss_import or GaussImportApi(resolved_settings),
    )


@lru_cache(maxsize=1)
def get_job_engine() -> JobEngine:
    return build_job_engine()


async def run_start_image_job(
    engine: JobEngine,
    *,
    local_path: str,
    clear_furniture: bool = True,
    floor_plan_name: str | None = None,
    level_height_mm: float = 2800.0,
) -> dict[str, Any]:
    async def action() -> dict[str, Any]:
        job = engine.create_job(
            local_path=local_path,
            clear_furniture=clear_furniture,
            floor_plan_name=floor_plan_name,
            level_height_mm=level_height_mm,
        )
        return {
            "job": serialize_job(job),
            "events": [serialize_event(job.history[-1])] if job.history else [],
            "next_poll_after_sec": 0,
        }

    return await _run_tool(action)


async def run_poll_job(engine: JobEngine, *, job_id: str) -> dict[str, Any]:
    async def action() -> dict[str, Any]:
        result = await engine.poll_job(job_id)
        return serialize_poll_result(result)

    return await _run_tool(action)


async def run_get_job(engine: JobEngine, *, job_id: str) -> dict[str, Any]:
    async def action() -> dict[str, Any]:
        return {"job": serialize_job(engine.get_job(job_id))}

    return await _run_tool(action)


async def run_resume_job(engine: JobEngine, *, job_id: str) -> dict[str, Any]:
    async def action() -> dict[str, Any]:
        result = await engine.resume_job(job_id)
        return serialize_poll_result(result)

    return await _run_tool(action)


async def run_list_jobs(engine: JobEngine, *, limit: int = 20) -> dict[str, Any]:
    async def action() -> dict[str, Any]:
        jobs = engine.list_jobs(limit=limit)
        return {"jobs": [serialize_job_summary(job) for job in jobs]}

    return await _run_tool(action)


def register_tools(mcp: FastMCP) -> None:
    @mcp.tool(name="gauss_start_image_job")
    async def gauss_start_image_job(
        local_path: str,
        clear_furniture: bool = True,
        floor_plan_name: str | None = None,
        level_height_mm: float = 2800.0,
    ) -> dict[str, Any]:
        """创建图片导入 job，快速返回 job_id 和初始状态。"""

        return await run_start_image_job(
            get_job_engine(),
            local_path=local_path,
            clear_furniture=clear_furniture,
            floor_plan_name=floor_plan_name,
            level_height_mm=level_height_mm,
        )

    @mcp.tool(name="gauss_poll_job")
    async def gauss_poll_job(job_id: str) -> dict[str, Any]:
        """推进 job 一次，返回当前阶段、事件和建议轮询间隔。"""

        return await run_poll_job(get_job_engine(), job_id=job_id)

    @mcp.tool(name="gauss_get_job")
    async def gauss_get_job(job_id: str) -> dict[str, Any]:
        """读取 job 当前状态，不推进执行。"""

        return await run_get_job(get_job_engine(), job_id=job_id)

    @mcp.tool(name="gauss_resume_job")
    async def gauss_resume_job(job_id: str) -> dict[str, Any]:
        """恢复失败 job，并继续推进当前阶段。"""

        return await run_resume_job(get_job_engine(), job_id=job_id)

    @mcp.tool(name="gauss_list_jobs")
    async def gauss_list_jobs(limit: int = 20) -> dict[str, Any]:
        """列出最近的图片导入 jobs。"""

        return await run_list_jobs(get_job_engine(), limit=limit)


def serialize_poll_result(result: PollResult) -> dict[str, Any]:
    return {
        "job": serialize_job(result.job),
        "events": [serialize_event(event) for event in result.events],
        "next_poll_after_sec": result.next_poll_after_sec,
    }


def serialize_job(job: ImageToDesignJob) -> dict[str, Any]:
    stage = job.stage(job.current_stage)
    payload = job.model_dump(mode="json")
    return {
        "job_id": job.id,
        "job_status": job.status,
        "current_stage": job.current_stage,
        "current_stage_status": stage.status,
        "current_stage_task_id": stage.backend_task_id,
        "current_stage_elapsed_sec": _stage_elapsed_sec(stage),
        "progress": _progress(job),
        "task_ids": {name: state.backend_task_id for name, state in job.stages.items() if state.backend_task_id},
        "local_path": payload["local_path"],
        "clear_furniture": payload["clear_furniture"],
        "floor_plan_name": payload["floor_plan_name"],
        "level_height_mm": payload["level_height_mm"],
        "stages": payload["stages"],
        "artifacts": payload["artifacts"],
        "result": payload["result"],
        "error": payload["error"],
        "history": payload["history"],
        "created_at": payload["created_at"],
        "updated_at": payload["updated_at"],
    }


def serialize_job_summary(job: ImageToDesignJob) -> dict[str, Any]:
    serialized = serialize_job(job)
    return {
        "job_id": serialized["job_id"],
        "job_status": serialized["job_status"],
        "current_stage": serialized["current_stage"],
        "current_stage_status": serialized["current_stage_status"],
        "progress": serialized["progress"],
        "updated_at": serialized["updated_at"],
        "result": serialized["result"],
        "error": serialized["error"],
    }


def serialize_event(event: JobEvent) -> dict[str, Any]:
    return event.model_dump(mode="json")


async def _run_tool(action: Callable[[], Awaitable[dict[str, Any]]]) -> dict[str, Any]:
    try:
        payload = await action()
        return {"success": True, **payload}
    except ImageToDesignError as exc:
        return exc.to_dict()
    except Exception as exc:  # pragma: no cover - defensive fallback
        return ImageToDesignError(
            "internal_error",
            "工具执行失败",
            details={"reason": str(exc)},
            recoverable=False,
        ).to_dict()


def _progress(job: ImageToDesignJob) -> dict[str, int]:
    completed = 0
    for stage in job.stages.values():
        if stage.status in (StageStatus.succeeded, StageStatus.skipped):
            completed += 1
    return {"completed": completed, "total": len(STAGE_SEQUENCE)}


def _stage_elapsed_sec(stage) -> int | None:
    if stage.started_at is None:
        return None
    return max(0, int((datetime.now(timezone.utc) - stage.started_at).total_seconds()))
