"""Data classes for Aletheia API responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from uuid import UUID


@dataclass(frozen=True)
class Question:
    """A question from the evaluation catalog."""

    id: str
    title: str
    difficulty: str
    family: str


@dataclass(frozen=True)
class QuestionDetail(Question):
    """Full question including prompt and skill weights."""

    prompt: str = ""
    skills: dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class Check:
    """A single evaluation check within a result."""

    id: str
    label: str
    passed: bool
    points_awarded: float
    points_possible: float
    score: float | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        icon = "PASS" if self.passed else "FAIL"
        return f"[{icon}] {self.label} ({self.points_awarded}/{self.points_possible})"


@dataclass(frozen=True)
class ResultQuestion:
    """Question identity attached to a result (subset of QuestionDetail)."""

    id: str
    title: str


@dataclass(frozen=True)
class Result:
    """Evaluation result for a completed submission."""

    checks: list[Check]
    points_awarded: float
    points_possible: float
    question: ResultQuestion
    build_log: str | None = None
    measurements: dict[str, Any] = field(default_factory=dict)

    @property
    def score(self) -> float:
        """Score as a fraction 0.0-1.0."""
        if self.points_possible == 0:
            return 0.0
        return self.points_awarded / self.points_possible

    @property
    def passed(self) -> bool:
        """True if all checks passed."""
        return all(c.passed for c in self.checks)

    @property
    def points(self) -> str:
        """Human-readable points string."""
        return f"{self.points_awarded} / {self.points_possible}"

    def __str__(self) -> str:
        lines = [f"Score: {self.score:.1%} ({self.points})"]
        for check in self.checks:
            lines.append(f"  {check}")
        return "\n".join(lines)

    @classmethod
    def _from_dict(cls, data: dict[str, Any]) -> Result:
        checks = [
            Check(
                id=c.get("id", ""),
                label=c.get("label", ""),
                passed=c.get("passed", False),
                points_awarded=c.get("points_awarded", 0),
                points_possible=c.get("points_possible", 0),
                score=c.get("score"),
                details=c.get("details", {}),
            )
            for c in data.get("checks", [])
        ]
        q_data = data.get("question") or {}
        question = ResultQuestion(
            id=str(q_data.get("id", "")),
            title=str(q_data.get("title", "")),
        )
        return cls(
            checks=checks,
            points_awarded=data.get("points_awarded", 0),
            points_possible=data.get("points_possible", 0),
            question=question,
            build_log=data.get("build_log"),
            measurements=data.get("measurements", {}),
        )


@dataclass
class Submission:
    """A submission, possibly still in progress.

    Use .wait() to block until completion, or check .status and .refresh().
    """

    id: UUID
    question_id: str
    status: str
    created_at: str
    started_at: str | None = None
    completed_at: str | None = None
    result: Result | None = None
    error: str | None = None

    # Set internally by the client so .wait() and .refresh() work
    _client: Any = field(default=None, repr=False)

    @property
    def is_terminal(self) -> bool:
        return self.status in ("completed", "failed")

    def refresh(self) -> Submission:
        """Re-fetch this submission. Updates in place and returns self."""
        updated = self._client.submissions.get(self.id)
        self.status = updated.status
        self.started_at = updated.started_at
        self.completed_at = updated.completed_at
        self.result = updated.result
        self.error = updated.error
        return self

    def wait(self, timeout: float = 300, poll_interval: float = 2.0) -> Submission:
        """Block until this submission reaches a terminal state."""
        return self._client._wait_for_submission(
            self, timeout=timeout, poll_interval=poll_interval
        )

    @classmethod
    def _from_dict(cls, data: dict[str, Any], client: Any = None) -> Submission:
        result_data = data.get("result")
        result = Result._from_dict(result_data) if result_data else None
        return cls(
            id=UUID(str(data["id"])),
            question_id=data["question_id"],
            status=data["status"],
            created_at=data["created_at"],
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
            result=result,
            error=data.get("error"),
            _client=client,
        )
