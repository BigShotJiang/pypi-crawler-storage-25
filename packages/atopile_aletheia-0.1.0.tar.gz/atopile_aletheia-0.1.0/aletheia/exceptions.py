"""Exceptions raised by the Aletheia SDK."""

from __future__ import annotations


class AletheiaError(Exception):
    """Base exception for all SDK errors."""

    def __init__(self, message: str, status_code: int | None = None):
        self.status_code = status_code
        super().__init__(message)


class AuthenticationError(AletheiaError):
    """Raised when the API key is missing or invalid."""


class NotFoundError(AletheiaError):
    """Raised when a resource is not found (404)."""


class ValidationError(AletheiaError):
    """Raised when the server rejects input (422)."""


class SubmissionTimeoutError(AletheiaError):
    """Raised when waiting for a submission exceeds the timeout."""


class SubmissionFailedError(AletheiaError):
    """Raised when a submission completes with status 'failed'."""

    def __init__(self, message: str, error_detail: str | None = None):
        self.error_detail = error_detail
        super().__init__(message)
