"""Thin HTTP layer wrapping httpx."""

from __future__ import annotations

from typing import Any

import httpx

from aletheia.exceptions import (
    AletheiaError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
)

DEFAULT_BASE_URL = "https://aletheia.atopile.io"
DEFAULT_TIMEOUT = 30.0


class HttpClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        resp = self._client.get(path, params=_clean_params(params))
        return _handle_response(resp)

    def post(self, path: str, json: dict[str, Any] | None = None) -> Any:
        resp = self._client.post(path, json=json)
        return _handle_response(resp)

    def close(self) -> None:
        self._client.close()


def _clean_params(params: dict[str, Any] | None) -> dict[str, Any] | None:
    if params is None:
        return None
    return {k: v for k, v in params.items() if v is not None}


def _handle_response(resp: httpx.Response) -> Any:
    if resp.status_code in (200, 201, 202):
        return resp.json()

    detail = ""
    try:
        body = resp.json()
        detail = body.get("detail", str(body))
    except Exception:
        detail = resp.text

    if resp.status_code == 401:
        raise AuthenticationError(f"Authentication failed: {detail}", 401)
    if resp.status_code == 404:
        raise NotFoundError(detail, 404)
    if resp.status_code == 422:
        raise ValidationError(f"Validation error: {detail}", 422)
    raise AletheiaError(f"API error {resp.status_code}: {detail}", resp.status_code)
