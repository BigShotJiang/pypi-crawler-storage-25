"""Main Aletheia client."""

from __future__ import annotations

import os
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any
from uuid import UUID

from aletheia._http import DEFAULT_BASE_URL, HttpClient
from aletheia.exceptions import (
    AuthenticationError,
    SubmissionFailedError,
    SubmissionTimeoutError,
)
from aletheia.models import Question, QuestionDetail, Submission


class _Questions:
    """Namespace for question operations."""

    def __init__(self, http: HttpClient):
        self._http = http

    def list(
        self,
        *,
        family: str | None = None,
        difficulty: int | str | None = None,
        offset: int = 0,
        limit: int = 50,
    ) -> list[Question]:
        """List available questions."""
        data = self._http.get(
            "/v1/questions",
            params={
                "family": family,
                "difficulty": str(difficulty) if difficulty is not None else None,
                "offset": offset,
                "limit": limit,
            },
        )
        return [
            Question(
                id=q["id"],
                title=q["title"],
                difficulty=q["difficulty"],
                family=q["family"],
            )
            for q in data
        ]

    def get(self, question_id: str) -> QuestionDetail:
        """Get full details for a question including the prompt."""
        data = self._http.get(f"/v1/questions/{question_id}")
        return QuestionDetail(
            id=data["id"],
            title=data["title"],
            difficulty=data["difficulty"],
            family=data["family"],
            prompt=data["prompt"],
            skills=data.get("skills", {}),
        )


class _Submissions:
    """Namespace for submission operations."""

    def __init__(self, http: HttpClient, client: Aletheia):
        self._http = http
        self._client = client

    def list(
        self,
        *,
        question_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[Submission]:
        """List submissions."""
        data = self._http.get(
            "/v1/submissions",
            params={"question_id": question_id, "status": status, "limit": limit},
        )
        return [
            Submission._from_dict(s, client=self._client) for s in data["submissions"]
        ]

    def get(self, submission_id: str | UUID) -> Submission:
        """Get a submission by ID."""
        data = self._http.get(f"/v1/submissions/{submission_id}")
        return Submission._from_dict(data, client=self._client)


class BatchResult:
    """Results from a batch submission."""

    def __init__(self, submissions: list[Submission]):
        self.submissions = submissions

    @property
    def completed(self) -> list[Submission]:
        return [s for s in self.submissions if s.status == "completed"]

    @property
    def failed(self) -> list[Submission]:
        return [s for s in self.submissions if s.status == "failed"]

    def summary(self) -> str:
        """Print a human-readable summary of the batch results."""
        total = len(self.submissions)
        passed = sum(1 for s in self.submissions if s.result and s.result.passed)
        total_awarded = sum(
            s.result.points_awarded for s in self.submissions if s.result
        )
        total_possible = sum(
            s.result.points_possible for s in self.submissions if s.result
        )
        score_pct = (total_awarded / total_possible * 100) if total_possible else 0

        lines = [
            "Aletheia Benchmark Results",
            "-" * 40,
            f"Total: {passed}/{total} passed | Score: {score_pct:.1f}%",
            f"Completed: {len(self.completed)} | Failed: {len(self.failed)}",
        ]
        if total_awarded > 0:
            lines.append("")
            lines.append(f"Points: {total_awarded} / {total_possible}")

        return "\n".join(lines)

    def to_dataframe(self):
        """Convert results to a pandas DataFrame. Requires pandas to be installed."""
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for to_dataframe(). "
                "Install it with: pip install atopile-aletheia[pandas]"
            )

        rows = []
        for s in self.submissions:
            row = {
                "submission_id": str(s.id),
                "question_id": s.question_id,
                "status": s.status,
                "passed": s.result.passed if s.result else None,
                "score": s.result.score if s.result else None,
                "points_awarded": s.result.points_awarded if s.result else None,
                "points_possible": s.result.points_possible if s.result else None,
                "error": s.error,
                "created_at": s.created_at,
                "completed_at": s.completed_at,
            }
            rows.append(row)

        return pd.DataFrame(rows)


class Aletheia:
    """Client for the Aletheia evaluation platform.

    Usage:
        client = Aletheia(api_key="ak_...")
        # or set ALETHEIA_API_KEY env var:
        client = Aletheia()

        # Browse questions
        questions = client.questions.list()
        q = client.questions.get("q1_555_astable")

        # Submit and wait for result
        result = client.submit(question_id="q1_555_astable", code="...")
        print(result.score)
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        resolved_key = api_key or os.environ.get("ALETHEIA_API_KEY")
        if not resolved_key:
            raise AuthenticationError(
                "No API key provided. Pass api_key= or set ALETHEIA_API_KEY env var."
            )

        self._http = HttpClient(
            api_key=resolved_key,
            base_url=base_url,
            timeout=timeout,
        )
        self.questions = _Questions(self._http)
        self.submissions = _Submissions(self._http, client=self)

    def submit(
        self,
        *,
        question_id: str,
        code: str,
        metadata: dict[str, Any] | None = None,
        wait: bool = True,
        timeout: float = 300,
        poll_interval: float = 2.0,
    ) -> Submission:
        """Submit code for evaluation.

        By default blocks until the submission completes. Set wait=False
        to return immediately with a pending Submission you can .wait() later.
        """
        data = self._http.post(
            "/v1/submissions",
            json={
                "question_id": question_id,
                "code": code,
                "metadata": metadata or {},
            },
        )
        sub = Submission._from_dict(data, client=self)

        if wait:
            return self._wait_for_submission(
                sub, timeout=timeout, poll_interval=poll_interval
            )
        return sub

    def submit_batch(
        self,
        submissions: list[dict[str, Any]],
        *,
        metadata: dict[str, Any] | None = None,
        max_concurrent: int = 10,
    ) -> BatchHandle:
        """Submit multiple evaluations at once.

        Each entry should have 'question_id' and 'code' keys, with optional
        per-entry 'metadata' merged with the top-level metadata.

        Returns a BatchHandle you can .wait() on. The returned submissions
        preserve the order of the input list.
        """

        def _submit_one(entry: dict[str, Any]) -> Submission:
            merged_meta = {**(metadata or {}), **(entry.get("metadata", {}))}
            return self.submit(
                question_id=entry["question_id"],
                code=entry["code"],
                metadata=merged_meta,
                wait=False,
            )

        with ThreadPoolExecutor(max_workers=max_concurrent) as pool:
            pending = list(pool.map(_submit_one, submissions))

        return BatchHandle(pending, client=self)

    def _wait_for_submission(
        self,
        sub: Submission,
        *,
        timeout: float = 300,
        poll_interval: float = 2.0,
    ) -> Submission:
        """Poll until a submission reaches a terminal state."""
        deadline = time.monotonic() + timeout
        while not sub.is_terminal:
            if time.monotonic() > deadline:
                raise SubmissionTimeoutError(
                    f"Submission {sub.id} did not complete within {timeout}s "
                    f"(status: {sub.status})"
                )
            time.sleep(poll_interval)
            sub.refresh()

        if sub.status == "failed":
            raise SubmissionFailedError(
                f"Submission {sub.id} failed: {sub.error}",
                error_detail=sub.error,
            )
        return sub

    def close(self) -> None:
        """Close the underlying HTTP connection."""
        self._http.close()

    def __enter__(self) -> Aletheia:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class BatchHandle:
    """Handle for a batch of in-flight submissions."""

    def __init__(self, submissions: list[Submission], client: Aletheia):
        self.submissions = submissions
        self._client = client

    def wait(
        self,
        *,
        timeout: float = 600,
        poll_interval: float = 3.0,
        raise_on_failure: bool = False,
        max_concurrent: int = 10,
    ) -> BatchResult:
        """Block until all submissions complete.

        Pending submissions are refreshed concurrently each cycle to keep
        polling cost ~O(1 wall-clock latency) rather than O(N).

        If raise_on_failure is False (default), failed submissions are
        included in the result rather than raising.
        """
        deadline = time.monotonic() + timeout

        while True:
            pending = [s for s in self.submissions if not s.is_terminal]
            if not pending:
                break

            if time.monotonic() > deadline:
                statuses = {s.status for s in self.submissions if not s.is_terminal}
                raise SubmissionTimeoutError(
                    f"Batch timed out after {timeout}s. "
                    f"{len(pending)} submissions still in: {statuses}"
                )

            time.sleep(poll_interval)
            workers = min(len(pending), max_concurrent)
            with ThreadPoolExecutor(max_workers=workers) as pool:
                list(pool.map(lambda s: s.refresh(), pending))

        if raise_on_failure:
            failed = [s for s in self.submissions if s.status == "failed"]
            if failed:
                raise SubmissionFailedError(
                    f"{len(failed)} submission(s) failed in batch"
                )

        return BatchResult(self.submissions)
