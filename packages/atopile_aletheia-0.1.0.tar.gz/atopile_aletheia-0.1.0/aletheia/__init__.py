"""Aletheia SDK — evaluate EE agent designs against the Aletheia benchmark."""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

from aletheia.client import Aletheia, BatchHandle, BatchResult
from aletheia.exceptions import (
    AletheiaError,
    AuthenticationError,
    NotFoundError,
    SubmissionFailedError,
    SubmissionTimeoutError,
    ValidationError,
)
from aletheia.models import (
    Check,
    Question,
    QuestionDetail,
    Result,
    ResultQuestion,
    Submission,
)

try:
    __version__ = _pkg_version("atopile-aletheia")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"


__all__ = [
    "Aletheia",
    "AletheiaError",
    "AuthenticationError",
    "BatchHandle",
    "BatchResult",
    "Check",
    "NotFoundError",
    "Question",
    "QuestionDetail",
    "Result",
    "ResultQuestion",
    "Submission",
    "SubmissionFailedError",
    "SubmissionTimeoutError",
    "ValidationError",
]
