# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 13:37:34 2025

@author: xinli
"""

from futu import *
import numpy as np
import json
import os
import pandas as pd
from datetime import datetime, time, timedelta
import logging
from functools import wraps
import traceback


# 添加日志配置（保持原配置，确保格式统一）
def setup_logging():
    """配置日志系统"""
    # 创建logs目录如果不存在
    if not os.path.exists('../logs'):
        os.makedirs('../logs')

    # 生成日志文件名（带日期）
    log_filename = f"logs/trading_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

    # 配置日志：格式为「时间 - 日志名 - 级别 - 信息」
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename, encoding='utf-8'),  # 写入文件
            logging.StreamHandler()  # 控制台输出
        ]
    )

    # 创建特定的logger（避免与其他模块日志冲突）
    logger = logging.getLogger('TradingStrategy')
    logger.setLevel(logging.INFO)

    return logger


# 创建日志记录器（全局使用）
logger = setup_logging()


def log_function_call(func):
    """装饰器：记录函数调用和异常（保持原逻辑）"""

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            logger.info(f"开始执行函数: {func.__name__}")
            if args:
                logger.debug(f"函数参数: {args}")
            if kwargs:
                logger.debug(f"关键字参数: {kwargs}")

            result = func(*args, **kwargs)

            logger.info(f"函数执行完成: {func.__name__}")
            return result

        except Exception as e:
            logger.error(f"函数 {func.__name__} 执行出错: {str(e)}")
            logger.error(f"异常堆栈: {traceback.format_exc()}")
            raise

    return wrapper


def log_important_event(event_type, message, level='info'):
    """记录重要事件（保持原逻辑）"""
    if level == 'info':
        logger.info(f"[{event_type}] {message}")
    elif level == 'warning':
        logger.warning(f"[{event_type}] {message}")
    elif level == 'error':
        logger.error(f"[{event_type}] {message}")
    elif level == 'critical':
        logger.critical(f"[{event_type}] {message}")


# Pandas 显示配置（保持原逻辑）
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)

############################ 全局变量设置 ############################
FUTUOPEND_ADDRESS = '127.0.0.1'  # OpenD 监听地址
FUTUOPEND_PORT = 11111  # OpenD 监听端口
TRADING_ENVIRONMENT = TrdEnv.SIMULATE  # 交易环境：真实TrdEnv.REAL / 模拟TrdEnv.SIMULATE
TRADING_MARKET = TrdMarket.HK  # 交易市场权限
TRADING_PWD = 'Kalaiqi0'  # 交易密码（模拟环境可忽略，真实环境需谨慎）
TRADING_PERIOD_1 = KLType.K_1M  # 1分钟K线周期
TRADING_PERIOD_3 = KLType.K_3M  # 3分钟K线周期
TRADING_PERIOD_5 = KLType.K_5M  # 5分钟K线周期
TRADING_SECURITY = 'HK.HSI2601'  # 交易标的
TRADING_STOP_LOSS = 0.2  # 1%止损 10

############################ 参数设置 ##################################
settings = {
    'N秒后撤单': 45,
    '平仓规则4的止盈': 50,  # 代表利润回撤50%
    '均线1': 5,
    '均线2': 15,
    '均线3': 30,
    'K线周期1': 1,  # 1分钟K线
    'K线周期2': 3,  # 3分钟K线
    'K线周期3': 5,  # 5分钟K线
    '下单手数': 5
}

# 初始化行情/交易对象（保持原逻辑）
quote_context = OpenQuoteContext(host=FUTUOPEND_ADDRESS, port=FUTUOPEND_PORT)
trade_context = OpenFutureTradeContext(
    host='127.0.0.1',
    port=11111,
    is_encrypt=None,
    security_firm=SecurityFirm.FUTUSECURITIES
)
order_id = ''  # 全局订单ID
positions = dict()  # 全局持仓（后续从JSON加载）


def save_positions_to_json(positions, filename=TRADING_SECURITY.split('.')[1] + "_pos_only_close.json"):
    """将策略持仓保存到JSON文件（修复print为logger）"""
    try:
        if not isinstance(positions, dict):
            raise TypeError("持仓数据必须是字典类型，格式为{symbol: 持仓数量}")

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(positions, f, ensure_ascii=False, indent=4)

        logger.info(f"持仓数据已成功保存到：{os.path.abspath(filename)}")
        return True

    except Exception as e:
        # 替换print为logger.error，保留错误信息
        logger.error(f"保存持仓数据失败：{str(e)}")
        return False


def load_positions_from_json(filename=TRADING_SECURITY.split('.')[1] + "_pos_only_close.json"):
    """从JSON文件读取策略持仓（修复print为logger）"""
    try:
        if not os.path.exists(filename):
            logger.info(f"持仓文件 {filename} 不存在，返回初始空持仓")
            return None

        with open(filename, 'r', encoding='utf-8') as f:
            positions = json.load(f)

        if not isinstance(positions, dict):
            raise TypeError("持仓数据应为字典类型")

        logger.info(f"成功从 {os.path.abspath(filename)} 读取持仓数据：{positions}")
        return positions

    except Exception as e:
        logger.error(f"读取持仓数据失败：{str(e)}")
        return None


def unlock_trade():
    """解锁交易（修复日志参数格式）"""
    if TRADING_ENVIRONMENT == TrdEnv.REAL:
        ret, data = trade_context.unlock_trade(TRADING_PWD)
        if ret != RET_OK:
            # 原代码用逗号分隔，改为f-string格式化
            logger.error(f"解锁交易失败：{data}")
            return False
        logger.info("解锁交易成功！")
    return True


def is_normal_trading_time(code):
    """获取市场状态（修复日志参数格式）"""
    ret, data = quote_context.get_market_state([code])
    if ret != RET_OK:
        logger.error(f"获取市场状态失败：{data}")
        return False

    market_state = data['market_state'][0]
    valid_states = [
        MarketState.MORNING, MarketState.AFTERNOON,
        MarketState.FUTURE_DAY_OPEN, MarketState.FUTURE_OPEN,
        MarketState.FUTURE_BREAK_OVER, MarketState.NIGHT_OPEN
    ]

    if market_state in valid_states:
        return True
    logger.info(f"当前非持续交易时段，市场状态：{market_state}")
    return False


################################# 计算高低点 #################################
def cal_high_point(opens, highs, lows, closes, ma_period=5):
    """计算高点（修改版：处理K1和K2最高价相等的情况）
    高点定义：
    条件1：K线在上涨过程中出现左（K0）右（K2）两根K线最高价均低于中间K线（K1）最高价
    条件2：当K1的最高价等于K2，则将K1和K2视为一个整体（视为K1），后续K线向后移一位
    条件3：在后续K线（K3到K7）出现最低价低于K1和K2的最低价
    条件4：在后续K线（K3到K7）出现收盘价低于K2收盘价
    条件5：K0、K1或K2有一根K线满足收盘价大于MA5（多单条件）
    条件3和条件4可以分别由不同K线满足
    """
    k_high_point = np.zeros(len(closes))
    length = len(closes)

    # 计算MA5
    ma5_values = []
    for i in range(len(closes)):
        if i >= ma_period - 1:
            ma5_values.append(np.mean(closes[i - ma_period + 1:i + 1]))
        else:
            ma5_values.append(np.mean(closes[:i + 1]))

    i = 1
    while i < length - 1:  # 使用while循环以便在需要时跳过K线
        # 条件1：K1是局部高点（K0和K2的最高价都低于K1）
        if not (highs[i] > highs[i - 1] and highs[i] > highs[i + 1]):
            i += 1
            continue

        # 条件2：检查K1和K2最高价是否相等
        k1_index = i
        k2_index = i + 1

        # 如果K1和K2最高价相等，将它们视为一个整体
        if highs[k1_index] == highs[k2_index]:
            # 将K1和K2视为一个整体，K1的最高价取两者中的最大值（实际上相等）
            k1_high = max(highs[k1_index], highs[k2_index])
            k1_low = min(lows[k1_index], lows[k2_index])
            k1_close = closes[k2_index]  # 使用K2的收盘价作为整体的收盘价

            # 调整后续K线索引：K3变成K2，K4变成K3，以此类推
            adjusted_k2_index = k2_index + 1  # 原来的K3现在作为K2
            adjusted_k3_start = k2_index + 2  # 原来的K4现在作为K3的起始

            logger.debug(
                f"高点合并 | 位置K1:{k1_index}, K2:{k2_index} | 最高价相等: {highs[k1_index]:.2f} = {highs[k2_index]:.2f}")
        else:
            # 正常情况：K1和K2最高价不相等
            k1_high = highs[k1_index]
            k1_low = lows[k1_index]
            k1_close = closes[k1_index]

            adjusted_k2_index = k2_index  # K2索引不变
            adjusted_k3_start = k2_index + 1  # K3从K2的下一个开始

        # 条件5：K0、K1或K2有一根K线满足收盘价大于MA5（多单条件）
        condition5_met = False

        # 检查K0的收盘价是否大于MA5
        if k1_index - 1 >= 0:  # 确保K0存在
            k0_close = closes[k1_index - 1]
            k0_ma5 = ma5_values[k1_index - 1]
            if k0_close > k0_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K0收盘价{k0_close:.2f} > MA5{k0_ma5:.2f}")

        # 检查K1的收盘价是否大于MA5
        if not condition5_met and k1_index < len(closes):
            k1_ma5 = ma5_values[k1_index]
            if k1_close > k1_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K1收盘价{k1_close:.2f} > MA5{k1_ma5:.2f}")

        # 检查K2的收盘价是否大于MA5
        if not condition5_met and adjusted_k2_index < len(closes):
            k2_close = closes[adjusted_k2_index] if adjusted_k2_index < len(closes) else closes[k2_index]
            k2_ma5 = ma5_values[adjusted_k2_index] if adjusted_k2_index < len(ma5_values) else ma5_values[k2_index]
            if k2_close > k2_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K2收盘价{k2_close:.2f} > MA5{k2_ma5:.2f}")

        # 如果条件5不满足，跳过当前高点判断
        if not condition5_met:
            logger.debug(f"条件5未满足：K0、K1、K2收盘价均不大于MA5")
            if highs[k1_index] == highs[k2_index]:
                i += 2  # 跳过K1和K2，直接处理下一个K线
            else:
                i += 1  # 正常移动到下一个K线
            continue

        # 获取K2的关键价格（调整后的K2）
        if adjusted_k2_index < length:
            k2_high = highs[adjusted_k2_index] if adjusted_k2_index < length else highs[k2_index]
            k2_low = lows[adjusted_k2_index] if adjusted_k2_index < length else lows[k2_index]
            k2_close = closes[adjusted_k2_index] if adjusted_k2_index < length else closes[k2_index]
        else:
            k2_high = highs[k2_index]
            k2_low = lows[k2_index]
            k2_close = closes[k2_index]

        # 计算合并后的最低价（K1和K2中的最小值）
        combined_low = min(k1_low, k2_low)

        # 初始化条件标志
        condition3_met = False  # 条件3：最低价低于K1和K2的最低价
        condition4_met = False  # 条件4：收盘价低于K2收盘价

        # 检查K3到K7区间（使用调整后的索引）
        for j in range(adjusted_k3_start, min(adjusted_k3_start + 5, length)):
            # 检查条件3：最低价低于K1和K2的最低价
            if not condition3_met and lows[j] < combined_low:
                condition3_met = True

            # 检查条件4：收盘价低于K2收盘价
            if not condition4_met and closes[j] < k2_close:
                condition4_met = True

            # 如果两个条件都满足，则标记为高点
            if condition3_met and condition4_met:
                k_high_point[k1_index] = 1
                logger.info(f"高点确认 | 位置：{k1_index} | 价格：{k1_high:.2f} | "
                            f"收盘价：{k1_close:.2f} | MA5：{ma5_values[k1_index]:.2f} | "
                            f"K2调整：{'是' if highs[k1_index] == highs[k2_index] else '否'} | "
                            f"条件3：{condition3_met} | 条件4：{condition4_met}")
                break  # 找到确认信号即可

        # 如果K1和K2被合并，跳过K2的处理
        if highs[k1_index] == highs[k2_index]:
            i += 2  # 跳过K1和K2，直接处理下一个K线
        else:
            i += 1  # 正常移动到下一个K线

    return k_high_point


def cal_low_point(opens, highs, lows, closes, ma_period=5):
    """计算低点（修改版：处理K1和K2最低价相等的情况）
    低点定义：
    条件1：K线在下跌过程中出现左（K0）右（K2）两根K线最低价均高于中间K线（K1）最低价
    条件2：当K1的最低价等于K2，则将K1和K2视为一个整体（视为K1），后续K线向后移一位
    条件3：在后续K线（K3到K7）出现最高价高于K1和K2的最高价
    条件4：在后续K线（K3到K7）出现收盘价高于K2收盘价
    条件5：K0、K1或K2有一根K线满足收盘价小于MA5（空单条件）
    条件3和条件4可以分别由不同K线满足
    """
    k_low_point = np.zeros(len(closes))
    length = len(closes)

    # 计算MA5
    ma5_values = []
    for i in range(len(closes)):
        if i >= ma_period - 1:
            ma5_values.append(np.mean(closes[i - ma_period + 1:i + 1]))
        else:
            ma5_values.append(np.mean(closes[:i + 1]))

    i = 1
    while i < length - 1:  # 使用while循环以便在需要时跳过K线
        # 条件1：K1是局部低点（K0和K2的最低价都高于K1）
        if not (lows[i] < lows[i - 1] and lows[i] < lows[i + 1]):
            i += 1
            continue

        # 条件2：检查K1和K2最低价是否相等
        k1_index = i
        k2_index = i + 1

        # 如果K1和K2最低价相等，将它们视为一个整体
        if lows[k1_index] == lows[k2_index]:
            # 将K1和K2视为一个整体，K1的最低价取两者中的最小值（实际上相等）
            k1_low = min(lows[k1_index], lows[k2_index])
            k1_high = max(highs[k1_index], highs[k2_index])
            k1_close = closes[k2_index]  # 使用K2的收盘价作为整体的收盘价

            # 调整后续K线索引：K3变成K2，K4变成K3，以此类推
            adjusted_k2_index = k2_index + 1  # 原来的K3现在作为K2
            adjusted_k3_start = k2_index + 2  # 原来的K4现在作为K3的起始

            logger.debug(
                f"低点合并 | 位置K1:{k1_index}, K2:{k2_index} | 最低价相等: {lows[k1_index]:.2f} = {lows[k2_index]:.2f}")
        else:
            # 正常情况：K1和K2最低价不相等
            k1_low = lows[k1_index]
            k1_high = highs[k1_index]
            k1_close = closes[k1_index]

            adjusted_k2_index = k2_index  # K2索引不变
            adjusted_k3_start = k2_index + 1  # K3从K2的下一个开始

        # 条件5：K0、K1或K2有一根K线满足收盘价小于MA5（空单条件）
        condition5_met = False

        # 检查K0的收盘价是否小于MA5
        if k1_index - 1 >= 0:  # 确保K0存在
            k0_close = closes[k1_index - 1]
            k0_ma5 = ma5_values[k1_index - 1]
            if k0_close < k0_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K0收盘价{k0_close:.2f} < MA5{k0_ma5:.2f}")

        # 检查K1的收盘价是否小于MA5
        if not condition5_met and k1_index < len(closes):
            k1_ma5 = ma5_values[k1_index]
            if k1_close < k1_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K1收盘价{k1_close:.2f} < MA5{k1_ma5:.2f}")

        # 检查K2的收盘价是否小于MA5
        if not condition5_met and adjusted_k2_index < len(closes):
            k2_close = closes[adjusted_k2_index] if adjusted_k2_index < len(closes) else closes[k2_index]
            k2_ma5 = ma5_values[adjusted_k2_index] if adjusted_k2_index < len(ma5_values) else ma5_values[k2_index]
            if k2_close < k2_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K2收盘价{k2_close:.2f} < MA5{k2_ma5:.2f}")

        # 如果条件5不满足，跳过当前低点判断
        if not condition5_met:
            logger.debug(f"条件5未满足：K0、K1、K2收盘价均不小于MA5")
            if lows[k1_index] == lows[k2_index]:
                i += 2  # 跳过K1和K2，直接处理下一个K线
            else:
                i += 1  # 正常移动到下一个K线
            continue

        # 获取K2的关键价格（调整后的K2）
        if adjusted_k2_index < length:
            k2_low = lows[adjusted_k2_index] if adjusted_k2_index < length else lows[k2_index]
            k2_high = highs[adjusted_k2_index] if adjusted_k2_index < length else highs[k2_index]
            k2_close = closes[adjusted_k2_index] if adjusted_k2_index < length else closes[k2_index]
        else:
            k2_low = lows[k2_index]
            k2_high = highs[k2_index]
            k2_close = closes[k2_index]

        # 计算合并后的最高价（K1和K2中的最大值）
        combined_high = max(k1_high, k2_high)

        # 初始化条件标志
        condition3_met = False  # 条件3：最高价高于K1和K2的最高价
        condition4_met = False  # 条件4：收盘价高于K2收盘价

        # 检查K3到K7区间（使用调整后的索引）
        for j in range(adjusted_k3_start, min(adjusted_k3_start + 5, length)):
            # 检查条件3：最高价高于K1和K2的最高价
            if not condition3_met and highs[j] > combined_high:
                condition3_met = True

            # 检查条件4：收盘价高于K2收盘价
            if not condition4_met and closes[j] > k2_close:
                condition4_met = True

            # 如果两个条件都满足，则标记为低点
            if condition3_met and condition4_met:
                k_low_point[k1_index] = 1
                logger.info(f"低点确认 | 位置：{k1_index} | 价格：{k1_low:.2f} | "
                            f"收盘价：{k1_close:.2f} | MA5：{ma5_values[k1_index]:.2f} | "
                            f"K2调整：{'是' if lows[k1_index] == lows[k2_index] else '否'} | "
                            f"条件3：{condition3_met} | 条件4：{condition4_met}")
                break  # 找到确认信号即可

        # 如果K1和K2被合并，跳过K2的处理
        if lows[k1_index] == lows[k2_index]:
            i += 2  # 跳过K1和K2，直接处理下一个K线
        else:
            i += 1  # 正常移动到下一个K线

    return k_low_point


def cal_high_low_point(opens, highs, lows, closes, ma_period=5):
    """同时计算高点和低点（兼容旧版本，添加MA参数）"""
    k_high_point = cal_high_point(opens, highs, lows, closes, ma_period)
    k_low_point = cal_low_point(opens, highs, lows, closes, ma_period)
    return k_high_point, k_low_point


################################# 获取持仓数量 #################################
def get_holding_position(code):
    holding_position = {'pos': 0, 'cost_price': 0}
    ret, data = trade_context.position_list_query(code=code, trd_env=TRADING_ENVIRONMENT)

    if ret != RET_OK:
        logger.error(f"获取持仓数据失败：{data}")
        return holding_position
    else:
        if len(data) > 0:
            holding_position['pos'] = data['qty'].sum()  # 简化求和逻辑
            holding_position['cost_price'] = data['cost_price'][0]
            # logger.info(f"【持仓状态】{TRADING_SECURITY} 的持仓数量为：{holding_position}")
    return holding_position


################################# 计算下单数量 #################################
def calculate_quantity():
    """计算下单数量（修复print为logger）"""
    ret, data = quote_context.get_market_snapshot([TRADING_SECURITY])
    if ret != RET_OK:
        logger.error(f"获取市场快照失败：{data}")
        return 0
    price_quantity = data['lot_size'][0]  # 最小交易量
    logger.debug(f"计算下单数量：最小交易量为 {price_quantity}")
    return price_quantity


def is_valid_quantity(code, quantity, price):
    """判断购买力是否足够（修复print为logger）"""
    ret, data = trade_context.acctradinginfo_query(
        order_type=OrderType.NORMAL,
        code=code,
        price=price,
        trd_env=TRADING_ENVIRONMENT
    )

    if ret != RET_OK:
        logger.error(f"获取最大可买可卖数量失败：{data}")
        return False

    max_can_buy = data['max_cash_buy'][0]
    max_can_sell = data['max_sell_short'][0]

    if quantity > 0:
        is_valid = quantity < max_can_buy
        logger.debug(f"判断购买力：需买入 {quantity}，最大可买 {max_can_buy}，是否有效：{is_valid}")
        return is_valid
    elif quantity < 0:
        is_valid = abs(quantity) < max_can_sell
        logger.debug(f"判断购买力：需卖出 {abs(quantity)}，最大可卖 {max_can_sell}，是否有效：{is_valid}")
        return is_valid
    else:
        logger.warning("下单数量为0，无效")
        return False


def show_order_status(data):
    """展示订单回调（修复print为logger）"""
    order_status = data['order_status'][0]
    order_info = {
        '代码': data['code'][0],
        '价格': data['price'][0],
        '方向': data['trd_side'][0],
        '数量': data['qty'][0],
        '成交数量': data['dealt_qty'][0]
    }
    logger.info(f"【订单状态】{order_status} | {order_info}")


############################ 操作信号更新函数（显示订单状态） ############################
def on_init():
    if not unlock_trade():
        return False
    logger.info("【初始化】大恒指HSI2601平仓策略开始执行")
    return True


def on_tick():
    """每个tick运行（预留，无逻辑）"""
    pass


def on_bar_open():
    """新K线生成时运行（原逻辑，补充日志）"""
    logger.info("*************************************")
    if not is_normal_trading_time(TRADING_SECURITY):
        return

    # 原代码中 calculate_bull_bear 未定义，此处补充日志提醒
    logger.warning("calculate_bull_bear 函数未定义，暂不执行多空判断")
    holding_position = get_holding_position(TRADING_SECURITY)

    if holding_position == 0:
        logger.info("【操作信号】当前无持仓，暂不操作（多空判断函数未定义）")
    elif holding_position > 0:
        logger.info("【操作信号】当前有多头持仓，暂不平仓（多空判断函数未定义）")


def on_fill(data):
    """委托成交回调（预留，无逻辑）"""
    pass


def on_order_status(data):
    """订单状态变化回调（修复print为logger）"""
    if data['code'][0] == TRADING_SECURITY:
        show_order_status(data)


################################# 平仓规则1（3分钟和5分钟无条件止损止盈） #################################
def close_3m_5m_2K_ma5_pos(cur_time):
    """平仓规则1（优化版）：多单和空单分别判断的双周期条件"""
    global order_id
    global positions
    ma1_length = settings['均线1']  # MA5

    # 检查是否有持仓
    if abs(positions['pos']) == 0:
        logger.info("【平仓规则1】当前无持仓，跳过检查")
        return

    try:
        # 获取1分钟K线数据（用于重采样）
        k_ret, k_data = quote_context.get_cur_kline(
            TRADING_SECURITY,
            45,  # 获取足够的数据
            KLType.K_1M,
            AuType.NONE
        )

        if k_ret != RET_OK:
            logger.error(f"【平仓规则1】获取K线失败 | {TRADING_SECURITY} | 时间：{cur_time} | 原因：{k_data}")
            return

        # 数据预处理
        k_data = k_data.iloc[:-1]  # 去掉最后一根未完成的K线
        k_data['time_key'] = pd.to_datetime(k_data['time_key'])
        k_data = k_data.set_index('time_key')

        # 重采样为3分钟和5分钟K线
        resample_3m = k_data.resample('3min').agg({
            'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum'
        })
        resample_5m = k_data.resample('5min').agg({
            'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum'
        })

        # 检查数据是否足够
        if len(resample_3m) < 3 or len(resample_5m) < 3:
            logger.warning(f"【平仓规则1】重采样数据不足 | 3分钟K线:{len(resample_3m)}根, 5分钟K线:{len(resample_5m)}根")
            return

        # 提取收盘价数据
        closes_3m = resample_3m['close'].values
        closes_5m = resample_5m['close'].values

        # 计算3分钟K线的MA5
        ma5_3m = []
        for i in range(len(closes_3m)):
            if i >= ma1_length - 1:
                ma5_3m.append(np.mean(closes_3m[i - ma1_length + 1:i + 1]))
            else:
                ma5_3m.append(np.mean(closes_3m[:i + 1]))

        # 计算5分钟K线的MA5
        ma5_5m = []
        for i in range(len(closes_5m)):
            if i >= ma1_length - 1:
                ma5_5m.append(np.mean(closes_5m[i - ma1_length + 1:i + 1]))
            else:
                ma5_5m.append(np.mean(closes_5m[:i + 1]))

        # 获取最新价格用于平仓
        ret, snapshot = quote_context.get_market_snapshot([TRADING_SECURITY])
        if ret != RET_OK:
            logger.error(f"【平仓规则1】获取快照失败: {snapshot}")
            return

        last_price = snapshot['last_price'][0]

        # 多头平仓判断：连续两根K线收盘价小于MA5
        if positions['pos'] > 0:
            # 检查3分钟K线条件：连续两根K线收盘价小于MA5
            condition_3m = False
            if len(closes_3m) >= 2:
                # 检查最新两根K线
                last_close_3m = closes_3m[-1]
                prev_close_3m = closes_3m[-2]
                last_ma5_3m = ma5_3m[-1] if ma5_3m else last_close_3m
                prev_ma5_3m = ma5_3m[-2] if len(ma5_3m) >= 2 else prev_close_3m

                condition_3m = (last_close_3m < last_ma5_3m) and (prev_close_3m < prev_ma5_3m)

                logger.info(f"【平仓规则1】3分钟K线检查: "
                            f"最新收盘价={last_close_3m:.2f} < MA5={last_ma5_3m:.2f} -> {last_close_3m < last_ma5_3m}, "
                            f"前一根收盘价={prev_close_3m:.2f} < MA5={prev_ma5_3m:.2f} -> {prev_close_3m < prev_ma5_3m}")

            # 检查5分钟K线条件：连续两根K线收盘价小于MA5
            condition_5m = False
            if len(closes_5m) >= 2:
                # 检查最新两根K线
                last_close_5m = closes_5m[-1]
                prev_close_5m = closes_5m[-2]
                last_ma5_5m = ma5_5m[-1] if ma5_5m else last_close_5m
                prev_ma5_5m = ma5_5m[-2] if len(ma5_5m) >= 2 else prev_close_5m

                condition_5m = (last_close_5m < last_ma5_5m) and (prev_close_5m < prev_ma5_5m)

                logger.info(f"【平仓规则1】5分钟K线检查: "
                            f"最新收盘价={last_close_5m:.2f} < MA5={last_ma5_5m:.2f} -> {last_close_5m < last_ma5_5m}, "
                            f"前一根收盘价={prev_close_5m:.2f} < MA5={prev_ma5_5m:.2f} -> {prev_close_5m < prev_ma5_5m}")

            # 判断平仓条件
            if condition_3m and condition_5m:
                logger.info(f"【平仓规则1】触发平仓条件: 3分钟和5分钟K线同时满足连续两根K线收盘价小于MA5")

                # 执行平仓
                order_ret, order_data = trade_context.place_order(
                    price=last_price,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.SELL,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )

                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'SELL_CLOSE'
                    positions['open_time'] = cur_time
                    logger.info(f"【平仓规则1】平仓成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                f"操作：卖出平仓 | 订单ID：{order_id} | "
                                f"价格：{last_price:.2f} | 数量：{abs(positions['pos'])}")
                else:
                    logger.error(f"【平仓规则1】平仓失败 | 原因：{order_data}")
            else:
                logger.info(f"【平仓规则1】条件未满足: 3分钟条件={condition_3m}, 5分钟条件={condition_5m}")

        # 空头平仓判断：连续两根K线收盘价大于MA5
        elif positions['pos'] < 0:
            # 检查3分钟K线条件：连续两根K线收盘价大于MA5
            condition_3m = False
            if len(closes_3m) >= 2:
                # 检查最新两根K线
                last_close_3m = closes_3m[-1]
                prev_close_3m = closes_3m[-2]
                last_ma5_3m = ma5_3m[-1] if ma5_3m else last_close_3m
                prev_ma5_3m = ma5_3m[-2] if len(ma5_3m) >= 2 else prev_close_3m

                condition_3m = (last_close_3m > last_ma5_3m) and (prev_close_3m > prev_ma5_3m)

                logger.info(f"【平仓规则1】3分钟K线检查: "
                            f"最新收盘价={last_close_3m:.2f} > MA5={last_ma5_3m:.2f} -> {last_close_3m > last_ma5_3m}, "
                            f"前一根收盘价={prev_close_3m:.2f} > MA5={prev_ma5_3m:.2f} -> {prev_close_3m > prev_ma5_3m}")

            # 检查5分钟K线条件：连续两根K线收盘价大于MA5
            condition_5m = False
            if len(closes_5m) >= 2:
                # 检查最新两根K线
                last_close_5m = closes_5m[-1]
                prev_close_5m = closes_5m[-2]
                last_ma5_5m = ma5_5m[-1] if ma5_5m else last_close_5m
                prev_ma5_5m = ma5_5m[-2] if len(ma5_5m) >= 2 else prev_close_5m

                condition_5m = (last_close_5m > last_ma5_5m) and (prev_close_5m > prev_ma5_5m)

                logger.info(f"【平仓规则1】5分钟K线检查: "
                            f"最新收盘价={last_close_5m:.2f} > MA5={last_ma5_5m:.2f} -> {last_close_5m > last_ma5_5m}, "
                            f"前一根收盘价={prev_close_5m:.2f} > MA5={prev_ma5_5m:.2f} -> {prev_close_5m > prev_ma5_5m}")

            # 判断平仓条件
            if condition_3m and condition_5m:
                logger.info(f"【平仓规则1】触发平仓条件: 3分钟和5分钟K线同时满足连续两根K线收盘价大于MA5")

                # 执行平仓
                order_ret, order_data = trade_context.place_order(
                    price=last_price,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.BUY,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )

                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'BUY_CLOSE'
                    positions['open_time'] = cur_time
                    logger.info(f"【平仓规则1】平仓成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                f"操作：买入平仓 | 订单ID：{order_id} | "
                                f"价格：{last_price:.2f} | 数量：{abs(positions['pos'])}")
                else:
                    logger.error(f"【平仓规则1】平仓失败 | 原因：{order_data}")
            else:
                logger.info(f"【平仓规则1】条件未满足: 3分钟条件={condition_3m}, 5分钟条件={condition_5m}")

    except Exception as e:
        logger.error(f"【平仓规则1】执行错误 | {TRADING_SECURITY} | 时间：{cur_time} | 错误：{str(e)}")
        logger.error(traceback.format_exc())


################################# 平仓规则2（3分钟高点+双阴线+MA5之下平仓） #################################
def close_3m_high_low_point(cur_time, period, n):
    """平仓规则2（优化版）：3分钟高点+连续双阴线+MA5之下平仓"""
    global order_id
    global positions
    ma1_length = settings['均线1']  # MA5

    # 获取K线数据
    k_ret, k_data = quote_context.get_cur_kline(
        TRADING_SECURITY,
        45,  # 确保足够的数据量
        TRADING_PERIOD_1,
        AuType.NONE
    )

    if k_ret != RET_OK:
        logger.error(f"【平仓规则2】获取K线失败 | {TRADING_SECURITY} | 时间：{cur_time} | 原因：{k_data}")
        return

    try:
        # 数据预处理
        k_data = k_data.iloc[:-1]  # 去掉最后一行（未完成的K线）
        k_data['time_key'] = pd.to_datetime(k_data['time_key'])
        k_data = k_data.set_index('time_key')

        # 重采样为3分钟K线
        resampled_df = k_data.resample(f"{period}min").agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        })

        # 确保有足够的数据
        if len(resampled_df) < max(ma1_length, n) + 3:
            logger.warning(f"【平仓规则2】3分钟K线数据不足，需要{max(ma1_length, n) + 3}根，当前只有{len(resampled_df)}根")
            return

        # 提取价格数据
        opens = resampled_df['open'].values
        highs = resampled_df['high'].values
        lows = resampled_df['low'].values
        closes = resampled_df['close'].values

        # 计算MA5
        ma5_values = []
        for i in range(len(closes)):
            if i >= ma1_length - 1:
                ma5_values.append(np.mean(closes[i - ma1_length + 1:i + 1]))
            else:
                ma5_values.append(np.mean(closes[:i + 1]))  # 数据不足时使用所有可用数据

        last_close = closes[-1]
        last_ma5 = ma5_values[-1] if ma5_values else closes[-1]

        logger.info(f"【平仓规则2】3分钟K线数据：最新收盘价={last_close:.2f}, MA5={last_ma5:.2f}")

        # 多头平仓判断
        if positions['pos'] > 0:
            # 计算3分钟高点
            high_points = cal_high_point(opens, highs, lows, closes)

            # 检查是否有3分钟高点
            has_high_point = False
            high_point_index = -1

            # 在最近n个周期内查找高点
            for i in range(max(0, len(high_points) - n), len(high_points)):
                if high_points[i] == 1:
                    has_high_point = True
                    high_point_index = i
                    break

            if has_high_point:
                logger.info(f"【平仓规则2】发现3分钟高点，位置：{high_point_index}，价格：{highs[high_point_index]:.2f}")

                # 检查高点后是否有连续两根阴线
                if len(closes) >= high_point_index + 3:  # 确保有足够的数据
                    # 检查高点后的两根K线
                    k1_index = high_point_index + 1
                    k2_index = high_point_index + 2

                    # 判断是否为阴线（收盘价低于开盘价）
                    is_k1_negative = closes[k1_index] < opens[k1_index]
                    is_k2_negative = closes[k2_index] < opens[k2_index]

                    # 判断收盘价是否都在MA5之下
                    k1_below_ma5 = closes[k1_index] < ma5_values[k1_index]
                    k2_below_ma5 = closes[k2_index] < ma5_values[k2_index]

                    logger.info(
                        f"【平仓规则2】高点后K线1: 阴线={is_k1_negative}, 收盘价={closes[k1_index]:.2f}, MA5={ma5_values[k1_index]:.2f}, 低于MA5={k1_below_ma5}")
                    logger.info(
                        f"【平仓规则2】高点后K线2: 阴线={is_k2_negative}, 收盘价={closes[k2_index]:.2f}, MA5={ma5_values[k2_index]:.2f}, 低于MA5={k2_below_ma5}")

                    # 平仓条件：连续两根阴线且收盘价都在MA5之下
                    if is_k1_negative and is_k2_negative and k1_below_ma5 and k2_below_ma5:
                        logger.info(f"【平仓规则2】触发平仓条件：3分钟高点+双阴线+MA5之下")

                        # 执行平仓
                        order_ret, order_data = trade_context.place_order(
                            price=last_close,
                            order_type=OrderType.MARKET,
                            qty=abs(positions['pos']),
                            code=TRADING_SECURITY,
                            trd_side=TrdSide.SELL,
                            trd_env=TRADING_ENVIRONMENT,
                            session=Session.NONE
                        )

                        if order_ret == RET_OK:
                            order_id = order_data['order_id'][0]
                            positions['action'] = 'SELL_CLOSE'
                            positions['open_time'] = cur_time
                            logger.info(f"【平仓规则2】平仓成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                        f"操作：卖出平仓 | 订单ID：{order_id} | "
                                        f"价格：{last_close:.2f} | 数量：{abs(positions['pos'])}")
                        else:
                            logger.error(f"【平仓规则2】平仓失败 | 原因：{order_data}")
                else:
                    logger.warning(f"【平仓规则2】高点后数据不足，无法判断双阴线条件")
            else:
                logger.info(f"【平仓规则2】最近{n}个周期内未发现3分钟高点")

        # 空头平仓判断（对称逻辑）
        elif positions['pos'] < 0:
            # 计算3分钟低点
            low_points = cal_low_point(opens, highs, lows, closes)

            # 检查是否有3分钟低点
            has_low_point = False
            low_point_index = -1

            # 在最近n个周期内查找低点
            for i in range(max(0, len(low_points) - n), len(low_points)):
                if low_points[i] == 1:
                    has_low_point = True
                    low_point_index = i
                    break

            if has_low_point:
                logger.info(f"【平仓规则2】发现3分钟低点，位置：{low_point_index}，价格：{lows[low_point_index]:.2f}")

                # 检查低点后是否有连续两根阳线
                if len(closes) >= low_point_index + 3:  # 确保有足够的数据
                    # 检查低点后的两根K线
                    k1_index = low_point_index + 1
                    k2_index = low_point_index + 2

                    # 判断是否为阳线（收盘价高于开盘价）
                    is_k1_positive = closes[k1_index] > opens[k1_index]
                    is_k2_positive = closes[k2_index] > opens[k2_index]

                    # 判断收盘价是否都在MA5之上
                    k1_above_ma5 = closes[k1_index] > ma5_values[k1_index]
                    k2_above_ma5 = closes[k2_index] > ma5_values[k2_index]

                    logger.info(
                        f"【平仓规则2】低点后K线1: 阳线={is_k1_positive}, 收盘价={closes[k1_index]:.2f}, MA5={ma5_values[k1_index]:.2f}, 高于MA5={k1_above_ma5}")
                    logger.info(
                        f"【平仓规则2】低点后K线2: 阳线={is_k2_positive}, 收盘价={closes[k2_index]:.2f}, MA5={ma5_values[k2_index]:.2f}, 高于MA5={k2_above_ma5}")

                    # 平仓条件：连续两根阳线且收盘价都在MA5之上
                    if is_k1_positive and is_k2_positive and k1_above_ma5 and k2_above_ma5:
                        logger.info(f"【平仓规则2】触发平仓条件：3分钟低点+双阳线+MA5之上")

                        # 执行平仓
                        order_ret, order_data = trade_context.place_order(
                            price=last_close,
                            order_type=OrderType.MARKET,
                            qty=abs(positions['pos']),
                            code=TRADING_SECURITY,
                            trd_side=TrdSide.BUY,
                            trd_env=TRADING_ENVIRONMENT,
                            session=Session.NONE
                        )

                        if order_ret == RET_OK:
                            order_id = order_data['order_id'][0]
                            positions['action'] = 'BUY_CLOSE'
                            positions['open_time'] = cur_time
                            logger.info(f"【平仓规则2】平仓成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                        f"操作：买入平仓 | 订单ID：{order_id} | "
                                        f"价格：{last_close:.2f} | 数量：{abs(positions['pos'])}")
                        else:
                            logger.error(f"【平仓规则2】平仓失败 | 原因：{order_data}")
                else:
                    logger.warning(f"【平仓规则2】低点后数据不足，无法判断双阳线条件")
            else:
                logger.info(f"【平仓规则2】最近{n}个周期内未发现3分钟低点")

    except Exception as e:
        logger.error(f"【平仓规则2】执行错误 | {TRADING_SECURITY} | 时间：{cur_time} | 错误：{str(e)}")
        logger.error(traceback.format_exc())


################################# 平仓规则3（次高点平仓） #################################
def close_3m_high_low_point_compare(cur_time, period, n):
    """平仓规则3（优化版）：次高点平仓策略，检查形成次高点时的K线组合条件"""
    global order_id
    global positions
    ma1_length = settings['均线1']  # MA5

    # 检查是否有持仓
    if abs(positions['pos']) == 0:
        logger.info("【平仓规则3】当前无持仓，跳过检查")
        return

    # 获取K线数据
    k_ret, k_data = quote_context.get_cur_kline(
        TRADING_SECURITY,
        45,  # 获取足够的历史数据
        KLType.K_1M,  # 使用1分钟K线
        AuType.NONE
    )

    if k_ret != RET_OK:
        logger.error(f"【平仓规则3】获取K线失败 | {TRADING_SECURITY} | 时间：{cur_time} | 原因：{k_data}")
        return

    try:
        # 数据预处理
        k_data = k_data.iloc[:-1]  # 去掉最后一根未完成的K线
        k_data['time_key'] = pd.to_datetime(k_data['time_key'])
        k_data = k_data.sort_values('time_key')  # 确保按时间排序

        # 确保数据足够
        if len(k_data) < 10:  # 至少需要10根K线
            logger.warning(f"【平仓规则3】数据不足，当前只有{len(k_data)}根K线")
            return

        # 提取价格数据
        opens = k_data['open'].values
        highs = k_data['high'].values
        lows = k_data['low'].values
        closes = k_data['close'].values

        # 计算MA5
        if len(closes) >= ma1_length:
            # 计算每根K线的MA5
            ma5_values = []
            for i in range(len(closes)):
                if i >= ma1_length - 1:
                    ma5_values.append(np.mean(closes[i - ma1_length + 1:i + 1]))
                else:
                    ma5_values.append(np.mean(closes[:i + 1]))  # 数据不足时使用所有可用数据
        else:
            ma5_values = [np.mean(closes)] * len(closes)  # 如果数据不足，使用平均值

        last_close = closes[-1]  # 最新收盘价

        logger.info(f"【平仓规则3】最新收盘价：{last_close:.2f}，MA5：{ma5_values[-1]:.2f}")

        # 初始化变量，避免UnboundLocalError
        recent_high_idx = -1
        prev_high_idx = -1

        # 多头平仓判断
        if positions['pos'] > 0:
            # 计算高点序列
            high_points = cal_high_point(opens, highs, lows, closes)

            # 查找最近的两个高点
            high_indices = []
            for i in range(len(high_points) - 1, -1, -1):  # 从最新数据向前查找
                if high_points[i] == 1:
                    high_indices.append(i)
                if len(high_indices) >= 2:  # 找到最近两个高点就停止
                    break

            if len(high_indices) >= 2:
                recent_high_idx, prev_high_idx = high_indices[0], high_indices[1]
                recent_high = highs[recent_high_idx]
                prev_high = highs[prev_high_idx]

                logger.info(f"【平仓规则3】最近高点：{recent_high:.2f}（位置{recent_high_idx}），"
                            f"前高点：{prev_high:.2f}（位置{prev_high_idx}）")

                # 平仓条件1：最近高点低于前高点（形成次高点）
                if recent_high < prev_high:
                    logger.info(f"【平仓规则3】次高点形成：{recent_high:.2f} < {prev_high:.2f}")

                    # 检查索引是否有效且在最后5个位置内
                    if 0 <= recent_high_idx < len(closes) and recent_high_idx >= max(0, len(closes) - 5):
                        # 平仓条件2：检查形成次高点时的K线组合条件
                        # 情况1：形成次高点时的K线（K1）和其前一条K线（K0）的收盘价同时小于MA5
                        # 情况2：形成次高点时的K线（K1）和其后一条K线（K2）的收盘价同时小于MA5
                        # 满足情况1或情况2之一即可
                        condition_met = False

                        # 确保有足够的数据
                        if recent_high_idx >= 0 and recent_high_idx < len(closes):
                            # 情况1：检查K0和K1的收盘价是否都在MA5之下
                            if recent_high_idx >= 1:  # 确保有前一根K线
                                k0_idx = recent_high_idx - 1  # 前一根K线
                                k1_idx = recent_high_idx  # 次高点K线

                                k0_below_ma5 = closes[k0_idx] < ma5_values[k0_idx]
                                k1_below_ma5 = closes[k1_idx] < ma5_values[k1_idx]

                                if k0_below_ma5 and k1_below_ma5:
                                    condition_met = True
                                    logger.info(f"【平仓规则3】情况1满足：K0和K1都在MA5之下 | "
                                                f"K0收盘价={closes[k0_idx]:.2f} < MA5={ma5_values[k0_idx]:.2f}, "
                                                f"K1收盘价={closes[k1_idx]:.2f} < MA5={ma5_values[k1_idx]:.2f}")

                            # 情况2：检查K1和K2的收盘价是否都在MA5之下（如果情况1不满足）
                            if not condition_met and recent_high_idx < len(closes) - 1:  # 确保有后一根K线
                                k1_idx = recent_high_idx  # 次高点K线
                                k2_idx = recent_high_idx + 1  # 后一根K线

                                k1_below_ma5 = closes[k1_idx] < ma5_values[k1_idx]
                                k2_below_ma5 = closes[k2_idx] < ma5_values[k2_idx]

                                if k1_below_ma5 and k2_below_ma5:
                                    condition_met = True
                                    logger.info(f"【平仓规则3】情况2满足：K1和K2都在MA5之下 | "
                                                f"K1收盘价={closes[k1_idx]:.2f} < MA5={ma5_values[k1_idx]:.2f}, "
                                                f"K2收盘价={closes[k2_idx]:.2f} < MA5={ma5_values[k2_idx]:.2f}")

                            # 如果条件满足，执行平仓
                            if condition_met:
                                logger.info(f"【平仓规则3】触发平仓条件：次高点形成且K线组合满足MA5之下条件")

                                # 执行平仓
                                order_ret, order_data = trade_context.place_order(
                                    price=last_close,
                                    order_type=OrderType.MARKET,
                                    qty=abs(positions['pos']),
                                    code=TRADING_SECURITY,
                                    trd_side=TrdSide.SELL,
                                    trd_env=TRADING_ENVIRONMENT,
                                    session=Session.NONE
                                )

                                if order_ret == RET_OK:
                                    order_id = order_data['order_id'][0]
                                    positions['action'] = 'SELL_CLOSE'
                                    positions['open_time'] = cur_time
                                    logger.info(f"【平仓规则3】平仓成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                                f"操作：卖出平仓 | 订单ID：{order_id} | "
                                                f"价格：{last_close:.2f} | 数量：{abs(positions['pos'])}")
                                else:
                                    logger.error(f"【平仓规则3】平仓失败 | 原因：{order_data}")
                            else:
                                logger.info(f"【平仓规则3】K线组合条件未满足（情况1和情况2均不满足）")
                        else:
                            logger.warning(f"【平仓规则3】数据索引超出范围，无法检查K线组合条件")
                    else:
                        logger.info(f"【平仓规则3】次高点不在最近5根K线内，不进行平仓判断")
                else:
                    logger.info(f"【平仓规则3】未形成次高点：{recent_high:.2f} >= {prev_high:.2f}")
            else:
                logger.info(f"【平仓规则3】未找到足够的高点（需要2个，当前找到{len(high_indices)}个）")

        # 空头平仓判断（对称逻辑：次低点平仓）
        elif positions['pos'] < 0:
            # 计算低点序列
            low_points = cal_low_point(opens, highs, lows, closes)

            # 查找最近的两个低点
            low_indices = []
            for i in range(len(low_points) - 1, -1, -1):
                if low_points[i] == 1:
                    low_indices.append(i)
                    if len(low_indices) >= 2:
                        break

            if len(low_indices) >= 2:
                recent_low_idx, prev_low_idx = low_indices[0], low_indices[1]
                recent_low = lows[recent_low_idx]
                prev_low = lows[prev_low_idx]

                logger.info(f"【平仓规则3】最近低点：{recent_low:.2f}（位置{recent_low_idx}），"
                            f"前低点：{prev_low:.2f}（位置{prev_low_idx}）")

                # 平仓条件1：最近低点高于前低点（形成次低点）
                if recent_low > prev_low:
                    logger.info(f"【平仓规则3】次低点形成：{recent_low:.2f} > {prev_low:.2f}")

                    # 检查索引是否有效且在最后5个位置内
                    if 0 <= recent_low_idx < len(closes) and recent_low_idx >= max(0, len(closes) - 5):
                        # 平仓条件2：检查形成次低点时的K线组合条件（对称逻辑）
                        # 情况1：形成次低点时的K线（K1）和其前一条K线（K0）的收盘价同时大于MA5
                        # 情况2：形成次低点时的K线（K1）和其后一条K线（K2）的收盘价同时大于MA5
                        # 满足情况1或情况2之一即可
                        condition_met = False

                        # 确保有足够的数据
                        if recent_low_idx >= 0 and recent_low_idx < len(closes):
                            # 情况1：检查K0和K1的收盘价是否都在MA5之上
                            if recent_low_idx >= 1:  # 确保有前一根K线
                                k0_idx = recent_low_idx - 1  # 前一根K线
                                k1_idx = recent_low_idx  # 次低点K线

                                k0_above_ma5 = closes[k0_idx] > ma5_values[k0_idx]
                                k1_above_ma5 = closes[k1_idx] > ma5_values[k1_idx]

                                if k0_above_ma5 and k1_above_ma5:
                                    condition_met = True
                                    logger.info(f"【平仓规则3】情况1满足：K0和K1都在MA5之上 | "
                                                f"K0收盘价={closes[k0_idx]:.2f} > MA5={ma5_values[k0_idx]:.2f}, "
                                                f"K1收盘价={closes[k1_idx]:.2f} > MA5={ma5_values[k1_idx]:.2f}")

                            # 情况2：检查K1和K2的收盘价是否都在MA5之上（如果情况1不满足）
                            if not condition_met and recent_low_idx < len(closes) - 1:  # 确保有后一根K线
                                k1_idx = recent_low_idx  # 次低点K线
                                k2_idx = recent_low_idx + 1  # 后一根K线

                                k1_above_ma5 = closes[k1_idx] > ma5_values[k1_idx]
                                k2_above_ma5 = closes[k2_idx] > ma5_values[k2_idx]

                                if k1_above_ma5 and k2_above_ma5:
                                    condition_met = True
                                    logger.info(f"【平仓规则3】情况2满足：K1和K2都在MA5之上 | "
                                                f"K1收盘价={closes[k1_idx]:.2f} > MA5={ma5_values[k1_idx]:.2f}, "
                                                f"K2收盘价={closes[k2_idx]:.2f} > MA5={ma5_values[k2_idx]:.2f}")

                            # 如果条件满足，执行平仓
                            if condition_met:
                                logger.info(f"【平仓规则3】触发平仓条件：次低点形成且K线组合满足MA5之上条件")

                                # 执行平仓
                                order_ret, order_data = trade_context.place_order(
                                    price=last_close,
                                    order_type=OrderType.MARKET,
                                    qty=abs(positions['pos']),
                                    code=TRADING_SECURITY,
                                    trd_side=TrdSide.BUY,
                                    trd_env=TRADING_ENVIRONMENT,
                                    session=Session.NONE
                                )

                                if order_ret == RET_OK:
                                    order_id = order_data['order_id'][0]
                                    positions['action'] = 'BUY_CLOSE'
                                    positions['open_time'] = cur_time
                                    logger.info(f"【平仓规则3】平仓成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                                f"操作：买入平仓 | 订单ID：{order_id} | "
                                                f"价格：{last_close:.2f} | 数量：{abs(positions['pos'])}")
                                else:
                                    logger.error(f"【平仓规则3】平仓失败 | 原因：{order_data}")
                            else:
                                logger.info(f"【平仓规则3】K线组合条件未满足（情况1和情况2均不满足）")
                        else:
                            logger.warning(f"【平仓规则3】数据索引超出范围，无法检查K线组合条件")
                    else:
                        logger.info(f"【平仓规则3】次低点不在最近5根K线内，不进行平仓判断")
                else:
                    logger.info(f"【平仓规则3】未形成次低点：{recent_low:.2f} <= {prev_low:.2f}")
            else:
                logger.info(f"【平仓规则3】未找到足够的低点（需要2个，当前找到{len(low_indices)}个）")

    except Exception as e:
        logger.error(f"【平仓规则3】执行错误 | {TRADING_SECURITY} | 时间：{cur_time} | 错误：{str(e)}")
        logger.error(traceback.format_exc())


################################# 平仓规则4（止盈止损平仓） #################################
def close_1m_stop_profit(cur_time, price, period, n):
    """平仓规则4（优化版）：止盈平仓
    止盈条件：统计从开仓到至今为止的高点数量 + 利润回撤达到比例
    每分钟统计一次高点数量
    """
    global order_id
    global positions
    stop_profit_ratio = settings['平仓规则4的止盈'] / 100  # 止盈比例（50% → 0.5）

    current_minute = datetime.now().minute
    # 检查是否有持仓
    if abs(positions['pos']) == 0:
        # 每分钟检查一次无持仓日志
        current_minute = datetime.now().minute
        if not hasattr(close_1m_stop_profit, 'last_no_position_log_minute'):
            close_1m_stop_profit.last_no_position_log_minute = -1

        if current_minute != close_1m_stop_profit.last_no_position_log_minute:
            logger.info("【平仓规则4】当前无持仓，跳过止盈检查")
            close_1m_stop_profit.last_no_position_log_minute = current_minute
        return

    # 获取从开仓时间到现在的K线数据
    try:
        # 计算需要获取的K线数量（从开仓到现在）
        open_time = datetime.strptime(positions['open_time'], "%Y-%m-%d %H:%M:%S")
        current_time = datetime.strptime(cur_time, "%Y-%m-%d %H:%M:%S")
        minutes_since_open = int((current_time - open_time).total_seconds() / 60)

        # 确保有足够的数据（至少10根K线，最多200根）
        kline_count = min(max(minutes_since_open + 10, 20), 200)

        k_ret, k_data = quote_context.get_cur_kline(
            TRADING_SECURITY,
            kline_count,  # 动态获取从开仓到现在的K线数量
            TRADING_PERIOD_1,
            AuType.NONE
        )

        if k_ret != RET_OK:
            logger.error(f"【平仓规则4】获取K线失败 | {TRADING_SECURITY} | 时间：{cur_time} | 原因：{k_data}")
            return

        # 数据预处理
        k_data = k_data.iloc[:-1]  # 去掉最后一根未完成的K线
        k_data = k_data.sort_values('time_key')  # 确保按时间排序

        # 找到开仓时间对应的K线位置
        open_k_index = -1
        for i, row in k_data.iterrows():
            k_time = datetime.strptime(str(row['time_key']), "%Y-%m-%d %H:%M:%S")
            if k_time >= open_time:
                open_k_index = i
                break

        if open_k_index == -1:
            logger.warning(f"【平仓规则4】未找到开仓时间对应的K线 | 开仓时间：{positions['open_time']}")
            return

        # 提取从开仓到现在的价格数据
        relevant_data = k_data.iloc[open_k_index:]
        if len(relevant_data) == 0:
            logger.warning("【平仓规则4】开仓后无K线数据")
            return

        opens = relevant_data['open'].values
        highs = relevant_data['high'].values
        lows = relevant_data['low'].values
        closes = relevant_data['close'].values
        last_close = closes[-1] if len(closes) > 0 else price

        ############################ 止盈条件判断 ############################
        # 多头止盈平仓
        if positions['pos'] > 0:
            # 计算从开仓到现在的总高点数量
            high_points = cal_high_point(opens, highs, lows, closes)
            total_high_point_count = np.sum(high_points)

            # 计算最高价和利润回撤
            max_high = max(highs) if len(highs) > 0 else price
            max_profit = max_high - price  # 最大利润
            current_profit = last_close - price  # 当前利润
            profit_retracement = max_high - last_close  # 利润回撤点数

            # 每分钟记录一次分析信息
            if current_minute != getattr(close_1m_stop_profit, 'last_analysis_log_minute', -1):
                logger.info(f"【平仓规则4】多头持仓分析 | "
                            f"总高点数量：{total_high_point_count} | 最高价：{max_high:.2f} | "
                            f"最大利润：{max_profit:.2f} | 当前利润：{current_profit:.2f} | "
                            f"利润回撤：{profit_retracement:.2f} | "
                            f"回撤比例：{profit_retracement / max_profit * 100 if max_profit > 0 else 0:.1f}%")
                close_1m_stop_profit.last_analysis_log_minute = current_minute

            # 止盈条件：总高点数量 ≥ 2 + 利润回撤达到比例
            if total_high_point_count >= 2 and profit_retracement >= max_profit * stop_profit_ratio:
                # 触发止盈条件立即记录，不受频率限制
                logger.info(f"【平仓规则4】触发止盈条件 | "
                            f"高点数量：{total_high_point_count} ≥ 2 | "
                            f"利润回撤达到止盈比例：{stop_profit_ratio * 100}%")

                # 执行止盈平仓
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.SELL,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )

                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'SELL_CLOSE_STOP_PROFIT'
                    positions['open_time'] = cur_time
                    logger.info(f"【平仓规则4】止盈成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                f"操作：卖出止盈 | 订单ID：{order_id} | "
                                f"开仓价：{price:.2f} | 平仓价：{last_close:.2f} | "
                                f"利润：{current_profit:.2f} | 止盈比例：{stop_profit_ratio * 100}% | "
                                f"总高点数量：{total_high_point_count}")
                else:
                    logger.error(f"【平仓规则4】止盈失败 | 原因：{order_data}")
            else:
                # 未触发条件，每分钟记录一次
                if current_minute != getattr(close_1m_stop_profit, 'last_condition_log_minute', -1):
                    if total_high_point_count < 2:
                        logger.info(f"【平仓规则4】止盈条件未满足：高点数量不足（{total_high_point_count} < 2）")
                    else:
                        current_ratio = profit_retracement / max_profit * 100 if max_profit > 0 else 0
                        logger.info(
                            f"【平仓规则4】止盈条件未满足：利润回撤比例不足（{current_ratio:.1f}% < {stop_profit_ratio * 100}%）")
                    close_1m_stop_profit.last_condition_log_minute = current_minute

        # 空头止盈平仓
        elif positions['pos'] < 0:
            # 计算从开仓到现在的总低点数量
            low_points = cal_low_point(opens, highs, lows, closes)
            total_low_point_count = np.sum(low_points)

            # 计算最低价和利润回撤
            min_low = min(lows) if len(lows) > 0 else price
            max_profit = price - min_low  # 最大利润
            current_profit = price - last_close  # 当前利润
            profit_retracement = last_close - min_low  # 利润回撤点数

            # 每分钟记录一次分析信息
            if current_minute != getattr(close_1m_stop_profit, 'last_analysis_log_minute', -1):
                logger.info(f"【平仓规则4】空头持仓分析 | "
                            f"总低点数量：{total_low_point_count} | 最低价：{min_low:.2f} | "
                            f"最大利润：{max_profit:.2f} | 当前利润：{current_profit:.2f} | "
                            f"利润回撤：{profit_retracement:.2f} | "
                            f"回撤比例：{profit_retracement / max_profit * 100 if max_profit > 0 else 0:.1f}%")
                close_1m_stop_profit.last_analysis_log_minute = current_minute

            # 止盈条件：总低点数量 ≥ 2 + 利润回撤达到比例
            if total_low_point_count >= 2 and profit_retracement >= max_profit * stop_profit_ratio:
                # 触发止盈条件立即记录，不受频率限制
                logger.info(f"【平仓规则4】触发止盈条件 | "
                            f"低点数量：{total_low_point_count} ≥ 2 | "
                            f"利润回撤达到止盈比例：{stop_profit_ratio * 100}%")

                # 执行止盈平仓
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.BUY,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )

                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'BUY_CLOSE_STOP_PROFIT'
                    positions['open_time'] = cur_time
                    logger.info(f"【平仓规则4】止盈成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                f"操作：买入止盈 | 订单ID：{order_id} | "
                                f"开仓价：{price:.2f} | 平仓价：{last_close:.2f} | "
                                f"利润：{current_profit:.2f} | 止盈比例：{stop_profit_ratio * 100}% | "
                                f"总低点数量：{total_low_point_count}")
                else:
                    logger.error(f"【平仓规则4】止盈失败 | 原因：{order_data}")
            else:
                # 未触发条件，每分钟记录一次
                if current_minute != getattr(close_1m_stop_profit, 'last_condition_log_minute', -1):
                    if total_low_point_count < 2:
                        logger.info(f"【平仓规则4】止盈条件未满足：低点数量不足（{total_low_point_count} < 2）")
                    else:
                        current_ratio = profit_retracement / max_profit * 100 if max_profit > 0 else 0
                        logger.info(
                            f"【平仓规则4】止盈条件未满足：利润回撤比例不足（{current_ratio:.1f}% < {stop_profit_ratio * 100}%）")
                    close_1m_stop_profit.last_condition_log_minute = current_minute

    except Exception as e:
        # 错误日志立即记录，不受频率限制
        logger.error(f"【平仓规则4】执行错误 | {TRADING_SECURITY} | 时间：{cur_time} | 错误：{str(e)}")
        logger.error(traceback.format_exc())


################################# 实时止损函数 #################################
def close_stop_loss(last_close, cur_time):
    """实时止损函数（优化版）
    止损条件：达到止损价位
    日志频率：每分钟打印一次
    """
    global order_id
    global positions
    stop_loss_ratio = TRADING_STOP_LOSS / 100  # 止损比例（0.5% → 0.005）

    # 检查是否有持仓
    if abs(positions['pos']) == 0:
        # 每分钟检查一次无持仓日志
        current_minute = datetime.now().minute
        if not hasattr(close_stop_loss, 'last_no_position_log_minute'):
            close_stop_loss.last_no_position_log_minute = -1

        if current_minute != close_stop_loss.last_no_position_log_minute:
            logger.debug("【实时止损】当前无持仓，跳过止损检查")
            close_stop_loss.last_no_position_log_minute = current_minute
        return

    try:
        # 计算止损价位
        if positions['pos'] > 0:  # 多头持仓
            stop_loss_price = positions['price'] * (1 - stop_loss_ratio)
            current_pl = last_close - positions['price']  # 当前盈亏
            stop_loss_pl = stop_loss_price - positions['price']  # 止损盈亏

            # 每分钟记录一次检查信息
            current_minute = datetime.now().minute
            if not hasattr(close_stop_loss, 'last_check_log_minute'):
                close_stop_loss.last_check_log_minute = -1

            if current_minute != close_stop_loss.last_check_log_minute:
                logger.info(f"【实时止损】多头持仓检查 | "
                            f"当前价：{last_close:.2f} | 开仓价：{positions['price']:.2f} | "
                            f"止损价：{stop_loss_price:.2f} | 当前盈亏：{current_pl:.2f} | "
                            f"止损盈亏：{stop_loss_pl:.2f}")
                close_stop_loss.last_check_log_minute = current_minute

            # 多头止损条件：当前价 ≤ 止损价
            if last_close <= stop_loss_price:
                # 触发止损立即记录，不受频率限制
                logger.info(f"【实时止损】触发多头止损 | 当前价：{last_close:.2f} ≤ 止损价：{stop_loss_price:.2f}")

                # 执行止损平仓
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.SELL,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )

                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'SELL_CLOSE_STOP_LOSS'
                    positions['open_time'] = cur_time
                    logger.info(f"【实时止损】止损成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                f"操作：卖出止损 | 订单ID：{order_id} | "
                                f"开仓价：{positions['price']:.2f} | 平仓价：{last_close:.2f} | "
                                f"亏损：{current_pl:.2f} | 止损比例：{TRADING_STOP_LOSS}%")
                else:
                    logger.error(f"【实时止损】止损失败 | 原因：{order_data}")

        elif positions['pos'] < 0:  # 空头持仓
            stop_loss_price = positions['price'] * (1 + stop_loss_ratio)
            current_pl = positions['price'] - last_close  # 当前盈亏
            stop_loss_pl = positions['price'] - stop_loss_price  # 止损盈亏

            # 每分钟记录一次检查信息
            current_minute = datetime.now().minute
            if not hasattr(close_stop_loss, 'last_check_log_minute'):
                close_stop_loss.last_check_log_minute = -1

            if current_minute != close_stop_loss.last_check_log_minute:
                logger.info(f"【实时止损】空头持仓检查 | "
                            f"当前价：{last_close:.2f} | 开仓价：{positions['price']:.2f} | "
                            f"止损价：{stop_loss_price:.2f} | 当前盈亏：{current_pl:.2f} | "
                            f"止损盈亏：{stop_loss_pl:.2f}")
                close_stop_loss.last_check_log_minute = current_minute

            # 空头止损条件：当前价 ≥ 止损价
            if last_close >= stop_loss_price:
                # 触发止损立即记录，不受频率限制
                logger.info(f"【实时止损】触发空头止损 | 当前价：{last_close:.2f} ≥ 止损价：{stop_loss_price:.2f}")

                # 执行止损平仓
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.BUY,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )

                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'BUY_CLOSE_STOP_LOSS'
                    positions['open_time'] = cur_time
                    logger.info(f"【实时止损】止损成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                f"操作：买入止损 | 订单ID：{order_id} | "
                                f"开仓价：{positions['price']:.2f} | 平仓价：{last_close:.2f} | "
                                f"亏损：{current_pl:.2f} | 止损比例：{TRADING_STOP_LOSS}%")
                else:
                    logger.error(f"【实时止损】止损失败 | 原因：{order_data}")

    except Exception as e:
        # 错误日志立即记录，不受频率限制
        logger.error(f"【实时止损】执行错误 | {TRADING_SECURITY} | 时间：{cur_time} | 错误：{str(e)}")
        logger.error(traceback.format_exc())


################################# 平仓规则5（MACD背离 + 价格跌破MA5或连续阴线）#################################
def close_5_1min_macd_divergence(cur_time):
    """平仓规则5（1分钟周期）：基于高低点+MACD背离的平仓策略
    优化：仅计算高低点的MACD值，不计算所有K线的MACD。
    """
    global order_id
    global positions

    # 检查是否有持仓
    if abs(positions['pos']) == 0:
        logger.info("【平仓规则5】当前无持仓，跳过检查")
        return

    try:
        # 获取1分钟K线数据
        k_ret, k_data = quote_context.get_cur_kline(
            TRADING_SECURITY,
            45,  # 获取足够的数据用于高低点检测，可根据需要调整
            KLType.K_1M,
            AuType.NONE
        )
        if k_ret != RET_OK:
            logger.error(f"【平仓规则5】获取1分钟K线失败: {k_data}")
            return

        # 数据预处理：去掉最后一根未完成的K线
        if len(k_data) > 1:
            k_data = k_data.iloc[:-1]

        k_data = k_data.sort_values('time_key')  # 确保按时间排序

        # 确保数据足够
        if len(k_data) < 5:  # 至少需要5根K线来检测高低点
            logger.warning(f"【平仓规则5】1分钟K线数据不足，当前只有{len(k_data)}根")
            return

        # 提取价格数据
        opens = k_data['open'].values
        highs = k_data['high'].values
        lows = k_data['low'].values
        closes = k_data['close'].values

        # 计算高点和低点
        high_points = cal_high_point(opens, highs, lows, closes, ma_period=5)
        low_points = cal_low_point(opens, highs, lows, closes, ma_period=5)

        # 获取高点和低点的索引及对应的价格
        high_indices = [i for i, val in enumerate(high_points) if val == 1]
        low_indices = [i for i, val in enumerate(low_points) if val == 1]

        high_points_data = [
            {'index': i, 'price': highs[i], 'time': k_data.iloc[i]['time_key'] if i < len(k_data) else '未知'} for i in
            high_indices]
        low_points_data = [
            {'index': i, 'price': lows[i], 'time': k_data.iloc[i]['time_key'] if i < len(k_data) else '未知'} for i in
            low_indices]

        # 仅对高点和低点计算MACD值
        def calculate_macd_for_prices(prices):
            """为给定的价格序列计算MACD值（DIF, DEA, MACD柱）"""
            if len(prices) < 26:  # 通常MACD的slow_period为26，这里可以根据需求调整
                return None, None, None

            try:
                # 计算EMA12和EMA26
                def calculate_ema(prices, period):
                    if len(prices) < period:
                        return None
                    ema = [0] * len(prices)
                    ema[period - 1] = sum(prices[:period]) / period
                    alpha = 2.0 / (period + 1.0)
                    for i in range(period, len(prices)):
                        ema[i] = prices[i] * alpha + ema[i - 1] * (1 - alpha)
                    return ema

                ema12 = calculate_ema(prices, 12)
                ema26 = calculate_ema(prices, 26)

                if ema12 is None or ema26 is None:
                    return None, None, None

                # 计算DIF = EMA12 - EMA26
                dif = [ema12[i] - ema26[i] for i in range(len(prices))]

                # 计算DEA = DIF的9日EMA
                def calculate_ema_dif(dif_values, period=9):
                    if len(dif_values) < period:
                        return None
                    ema_dif = [0] * len(dif_values)
                    ema_dif[period - 1] = sum(dif_values[:period]) / period
                    alpha = 2.0 / (period + 1.0)
                    for i in range(period, len(dif_values)):
                        ema_dif[i] = dif_values[i] * alpha + ema_dif[i - 1] * (1 - alpha)
                    return ema_dif

                dea = calculate_ema_dif(dif, 9)
                if dea is None:
                    return None, None, None

                # 计算MACD柱 = (DIF - DEA) * 2
                macd_hist = [(dif[i] - dea[i]) * 2 for i in range(len(prices))]

                return dif, dea, macd_hist

            except Exception as e:
                logger.error(f"MACD计算错误: {str(e)}")
                return None, None, None

        # 为每个高点和低点计算MACD值
        high_points_with_macd = []
        for hp in high_points_data:
            idx = hp['index']
            price = hp['price']
            time_key = hp['time']
            # 提取该索引对应的价格序列（这里假设使用收盘价，可以根据需求调整）
            # 为了计算MACD，我们需要一个价格序列，这里我们使用该高点的价格作为单一价格是不合理的，
            # 因此，我们需要一个窗口或者多个价格点来计算EMA。
            # 为了简化，我们可以考虑使用该高点所在的局部价格序列（例如前后几根K线）
            # 这里我们采用一个简化的方法：使用该高点所在位置前N根K线的收盘价来计算MACD
            N = 26 + 9 + 1  # 保证至少有足够的K线来计算EMA12, EMA26, 和 DEA
            start_idx = max(0, idx - N + 1)
            end_idx = idx + 1
            local_closes = closes[start_idx:end_idx]
            if len(local_closes) < 26:
                logger.warning(f"【平仓规则5】高点索引 {idx} 的局部K线数量不足，无法计算MACD")
                continue
            dif, dea, macd_hist = calculate_macd_for_prices(local_closes)
            if dif is None or dea is None or macd_hist is None:
                logger.warning(f"【平仓规则5】高点索引 {idx} 的MACD计算失败")
                continue
            # 获取当前高点对应的DIF, DEA, MACD柱
            current_dif = dif[-1]  # 最新的DIF值
            current_dea = dea[-1]  # 最新的DEA值
            current_macd = macd_hist[-1]  # 最新的MACD柱
            high_points_with_macd.append({
                'index': idx,
                'price': price,
                'dif': current_dif,
                'dea': current_dea,
                'macd': current_macd,
                'time': time_key
            })

        low_points_with_macd = []
        for lp in low_points_data:
            idx = lp['index']
            price = lp['price']
            time_key = lp['time']
            # 同样地，提取局部价格序列
            N = 26 + 9 + 1  # 保证至少有足够的K线来计算EMA12, EMA26, 和 DEA
            start_idx = max(0, idx - N + 1)
            end_idx = idx + 1
            local_closes = closes[start_idx:end_idx]
            if len(local_closes) < 26:
                logger.warning(f"【平仓规则5】低点索引 {idx} 的局部K线数量不足，无法计算MACD")
                continue
            dif, dea, macd_hist = calculate_macd_for_prices(local_closes)
            if dif is None or dea is None or macd_hist is None:
                logger.warning(f"【平仓规则5】低点索引 {idx} 的MACD计算失败")
                continue
            # 获取当前低点对应的DIF, DEA, MACD柱
            current_dif = dif[-1]  # 最新的DIF值
            current_dea = dea[-1]  # 最新的DEA值
            current_macd = macd_hist[-1]  # 最新的MACD柱
            low_points_with_macd.append({
                'index': idx,
                'price': price,
                'dif': current_dif,
                'dea': current_dea,
                'macd': current_macd,
                'time': time_key
            })

        # 按时间倒序排列，获取最近的高点和低点
        high_points_with_macd.sort(key=lambda x: x['index'], reverse=True)
        low_points_with_macd.sort(key=lambda x: x['index'], reverse=True)

        # 每分钟记录一次分析信息
        current_minute = datetime.now().minute
        if not hasattr(close_5_1min_macd_divergence, 'last_log_minute'):
            close_5_1min_macd_divergence.last_log_minute = -1

        if current_minute != close_5_1min_macd_divergence.last_log_minute:
            logger.info(f"【平仓规则5】1分钟分析 | 最新价格: {closes[-1] if len(closes) > 0 else 0:.2f}")
            if len(high_points_with_macd) > 0:
                latest_high = high_points_with_macd[0]
                logger.info(f"【平仓规则5】最近高点: 价格{latest_high['price']:.2f}, MACD: {latest_high['macd']:.6f}")
            if len(low_points_with_macd) > 0:
                latest_low = low_points_with_macd[0]
                logger.info(f"【平仓规则5】最近低点: 价格{latest_low['price']:.2f}, MACD: {latest_low['macd']:.6f}")
            close_5_1min_macd_divergence.last_log_minute = current_minute

        # 多头平仓判断：顶背离 + 价格跌破MA5
        ma5_values = []
        if positions['pos'] > 0:
            # 检查顶背离条件：价格创新高但MACD未创新高
            top_divergence_detected = False
            divergence_details = ""

            if len(high_points_with_macd) >= 2:
                recent_high = high_points_with_macd[0]  # 最近的高点
                prev_high = high_points_with_macd[1]  # 前一个高点

                # 顶背离条件：价格创新高但DIF未创新高
                price_higher = recent_high['price'] > prev_high['price']
                dif_higher = recent_high['dif'] > prev_high['dif']

                if price_higher and not dif_higher:
                    top_divergence_detected = True
                    divergence_details = (f"价格新高({recent_high['price']:.2f} > {prev_high['price']:.2f}) "
                                          f"但DIF走低({recent_high['dif']:.6f} <= {prev_high['dif']:.6f})")

            # 检查价格跌破MA5条件
            # 计算MA5

            for i in range(len(closes)):
                if i >= 4:  # MA5需要至少5个数据点
                    ma5_values.append(np.mean(closes[i - 4:i + 1]))
                else:
                    ma5_values.append(np.mean(closes[:i + 1]))
            last_close = closes[-1] if len(closes) > 0 else 0
            price_below_ma5 = last_close < ma5_values[-1] if len(ma5_values) > 0 else False

            # 平仓条件：顶背离 + 价格跌破MA5
            if top_divergence_detected and price_below_ma5:
                logger.info(
                    f"【平仓规则5】触发多头平仓条件: 顶背离({divergence_details}) + 价格跌破MA5({last_close:.2f} < {ma5_values[-1]:.2f})")

                # 执行平仓
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.SELL,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )

                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'SELL_CLOSE_MACD_DIVERGENCE'
                    positions['open_time'] = cur_time
                    logger.info(f"【平仓规则5】平仓成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                f"操作：卖出平仓 | 价格：{last_close:.2f} | "
                                f"顶背离确认 | DIF: {recent_high['dif']:.6f}, 前DIF: {prev_high['dif']:.6f}")
                else:
                    logger.error(f"【平仓规则5】平仓失败 | 原因：{order_data}")
            else:
                # 记录未触发条件的原因
                if current_minute != getattr(close_5_1min_macd_divergence, 'last_condition_log_minute', -1):
                    if not top_divergence_detected:
                        logger.info(f"【平仓规则5】顶背离条件未满足")
                    elif not price_below_ma5:
                        logger.info(
                            f"【平仓规则5】价格未跌破MA5: {last_close:.2f} >= {ma5_values[-1]:.2f if len(ma5_values) > 0 else 'N/A'}")
                    close_5_1min_macd_divergence.last_condition_log_minute = current_minute

        # 空头平仓判断：底背离 + 价格突破MA5
        elif positions['pos'] < 0:
            # 检查底背离条件：价格创新低但MACD未创新低
            bottom_divergence_detected = False
            divergence_details = ""

            if len(low_points_with_macd) >= 2:
                recent_low = low_points_with_macd[0]  # 最近的低点
                prev_low = low_points_with_macd[1]  # 前一个低点

                # 底背离条件：价格创新低但DIF未创新低
                price_lower = recent_low['price'] < prev_low['price']
                dif_lower = recent_low['dif'] < prev_low['dif']

                if price_lower and not dif_lower:
                    bottom_divergence_detected = True
                    divergence_details = (f"价格新低({recent_low['price']:.2f} < {prev_low['price']:.2f}) "
                                          f"但DIF走高({recent_low['dif']:.6f} >= {prev_low['dif']:.6f})")

            # 检查价格突破MA5条件
            last_close = closes[-1] if len(closes) > 0 else 0
            price_above_ma5 = last_close > ma5_values[-1] if len(ma5_values) > 0 else False

            # 平仓条件：底背离 + 价格突破MA5
            if bottom_divergence_detected and price_above_ma5:
                logger.info(
                    f"【平仓规则5】触发空头平仓条件: 底背离({divergence_details}) + 价格突破MA5({last_close:.2f} > {ma5_values[-1]:.2f})")

                # 执行平仓
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.BUY,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )

                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'BUY_CLOSE_MACD_DIVERGENCE'
                    positions['open_time'] = cur_time
                    logger.info(f"【平仓规则5】平仓成功 | {TRADING_SECURITY} | 时间：{cur_time} | "
                                f"操作：买入平仓 | 价格：{last_close:.2f} | "
                                f"底背离确认 | DIF: {recent_low['dif']:.6f}, 前DIF: {prev_low['dif']:.6f}")
                else:
                    logger.error(f"【平仓规则5】平仓失败 | 原因：{order_data}")
            else:
                # 记录未触发条件的原因
                if current_minute != getattr(close_5_1min_macd_divergence, 'last_condition_log_minute', -1):
                    if not bottom_divergence_detected:
                        logger.info(f"【平仓规则5】底背离条件未满足")
                    elif not price_above_ma5:
                        logger.info(
                            f"【平仓规则5】价格未突破MA5: {last_close:.2f} <= {ma5_values[-1]:.2f if len(ma5_values) > 0 else 'N/A'}")
                    close_5_1min_macd_divergence.last_condition_log_minute = current_minute

    except Exception as e:
        logger.error(f"【平仓规则5】执行错误 | {TRADING_SECURITY} | 时间：{cur_time} | 错误：{str(e)}")
        logger.error(traceback.format_exc())


################################ 回调类 ##################################
# 仅平仓策略
class OnQuoteClass(StockQuoteHandlerBase):
    # 记录上一次时间（用于分钟级判断）
    last_time = None  # 记录上一次时间（用于分钟级判断）

    def on_recv_rsp(self, rsp_pb):
        global order_id
        global positions
        ma1_length = settings['均线1']
        ma2_length = settings['均线2']
        ma3_length = settings['均线3']

        # 调用父类方法获取行情数据
        Quote_ret_code, Quote_data = super(OnQuoteClass, self).on_recv_rsp(rsp_pb)
        if Quote_ret_code != RET_OK:
            logger.error(f"获取行情数据失败：{Quote_data}")
            return

        # 提取行情关键信息
        data_time = Quote_data['data_time'][0]
        data_date = Quote_data['data_date'][0]
        cur_datetime_str = f"{data_date} {data_time[:8]}"  # 格式：YYYY-MM-DD HH:MM:SS
        last_price = Quote_data['last_price'][0]

        # 初始化last_time（首次运行）
        if self.last_time is None:
            self.last_time = data_time[3:5]  # 取分钟数（如「13:37:34」→「37」）
            return

        ############################ 实时止损 ############################
        cur_quote_time = datetime.strptime(cur_datetime_str, "%Y-%m-%d %H:%M:%S")

        # 平仓规则4（1分钟周期，开仓后至少5分钟）
        if order_id == '' and abs(positions['pos']) > 0 and positions['open_time'] != '':
            open_time = datetime.strptime(positions['open_time'], "%Y-%m-%d %H:%M:%S")

            time_since_open = (cur_quote_time - open_time).total_seconds() / 60  # 开仓后分钟数

            if int(data_time[6:8]) % 8 == 0:
                close_stop_loss(last_price, cur_datetime_str)
                if time_since_open >= 4:
                    n = int(time_since_open)  # 开仓后分钟数（作为K线数量）
                    close_1m_stop_profit(cur_datetime_str, positions['price'], KLType.K_1M, n)

        ############################ 分钟级时序分配 ############################
        current_minute = data_time[3:5]
        if self.last_time != current_minute and abs(positions['pos']) > 0 and positions['open_time'] != '':
            try:
                open_time = datetime.strptime(positions['open_time'], "%Y-%m-%d %H:%M:%S")  # 开仓时间
                time_since_open = (cur_quote_time - open_time).total_seconds() / 60  # 开仓后分钟数

                logger.info(f"新的一分钟K线产生 | 开仓时间：{positions['open_time']} | 当前价格: {last_price}")

            except ValueError as e:
                logger.error(f"时间格式转换失败：{e} | 开仓时间：{positions['open_time']}")
                return

            # 平仓规则1（3\5分钟周期，开仓后至少1个周期）
            if (order_id == '' and time_since_open >= 1 * settings['K线周期3'] and
                    int(current_minute) % settings['K线周期3'] == 0):
                close_3m_5m_2K_ma5_pos(cur_datetime_str)  # 正确：只传入1个参数

            # 平仓规则2（3分钟周期，开仓后至少2个周期）
            if (order_id == '' and time_since_open >= 1 * settings['K线周期2'] and
                    int(current_minute) % settings['K线周期2'] == 0):
                n = int(time_since_open / settings['K线周期2'])
                close_3m_high_low_point(cur_datetime_str, settings['K线周期2'], n)

            # 平仓规则3（1分钟周期，开仓后至少2个周期）
            if (order_id == '' and time_since_open >= 1 * settings['K线周期1'] and
                    int(current_minute) % settings['K线周期1'] == 0):
                n = int(time_since_open / settings['K线周期1'])
                close_3m_high_low_point_compare(cur_datetime_str, settings['K线周期1'], n)

            # 平仓规则5（1分钟周期，开仓后至少9个周期）
            # if (order_id == '' and time_since_open >= 3 * settings['K线周期1'] and
            #    int(current_minute) % settings['K线周期1'] == 0):
            #    close_5_1min_macd_divergence(cur_datetime_str)

        ############################ 开仓逻辑 ############################
        '''
        logger.info(
            f"【秒级监控】{TRADING_SECURITY} | 时间：{data_time} | "
            f"订单ID：{order_id} | 持仓数量：{abs(positions['pos'])} | 最新价：{last_price}"
        )
        '''

        # 分钟级日志（避免重复输出）
        if self.last_time != current_minute:
            # trd_ctx = OpenSecTradeContext(filter_trdmarket=TrdMarket.HK, host='127.0.0.1', port=11111, security_firm=SecurityFirm.FUTUSECURITIES)
            holding_position = get_holding_position(TRADING_SECURITY)

            if holding_position['pos'] == 0:

                positions['open_time'] = ''
                logger.info(f"【操作信号】当前无持仓，暂不操作{positions}")
                # save_positions_to_json(positions)
            elif holding_position['pos'] > 0:

                if positions['pos'] <= 0:
                    positions['open_time'] = cur_datetime_str
                    positions['pos'] = float(holding_position['pos'])
                    logger.info(f"【操作信号】当前有多头持仓{positions}")
                    # save_positions_to_json(positions)
            else:

                if positions['pos'] >= 0:
                    positions['open_time'] = cur_datetime_str
                    positions['pos'] = float(holding_position['pos'])
                    logger.info(f"【操作信号】当前有空头持仓{positions}")
                    # save_positions_to_json(positions)

                # 更新last_time（避免重复触发分钟级逻辑）
        self.last_time = current_minute


############################ 订单状态更新 ###############################
class OnOrderClass(TradeOrderHandlerBase):
    """订单状态回调（修复日志格式）"""

    def on_recv_rsp(self, rsp_pb):
        global order_id
        global positions

        ret, data = super(OnOrderClass, self).on_recv_rsp(rsp_pb)
        if ret == RET_OK:
            if data['code'][0] == TRADING_SECURITY:
                order_status = data['order_status'][0]
                logger.info(
                    f"【订单回调】{data['code'][0]} | 订单ID：{data['order_id'][0]} | "
                    f"状态：{order_status} | 方向：{data['trd_side'][0]} | "
                    f"数量：{data['qty'][0]} | 成交：{data['dealt_qty'][0]}"
                )

                # 订单完全成交
                if order_status == OrderStatus.FILLED_ALL:
                    if data['order_id'][0] == order_id:
                        order_id = ''  # 重置订单ID
                        dealt_qty = data['dealt_qty'][0]
                        dealt_avg_price = data['dealt_avg_price'][0]

                        # 平仓成交
                        if positions['action'] in ['BUY_CLOSE', 'SELL_CLOSE']:
                            positions = {'pos': 0, 'open_time': '', 'action': '', 'price': 0}
                            logger.info(
                                f"【成交确认】{TRADING_SECURITY} | 操作：{positions['action']} | "
                                f"成交数量：{dealt_qty} | 成交均价：{dealt_avg_price}"
                            )

                        # 保存持仓到JSON
                        # save_positions_to_json(positions)
                    else:
                        dealt_qty = data['dealt_qty'][0]
                        dealt_avg_price = data['dealt_avg_price'][0]
                        if data['trd_side'][0] == TrdSide.BUY:
                            if positions['pos'] > 0:

                                positions['price'] = (positions['pos'] * positions[
                                    'price'] + dealt_avg_price * dealt_qty) / (positions['pos'] + dealt_qty)
                                positions['pos'] = positions['pos'] + dealt_qty

                            else:
                                positions['pos'] = positions['pos'] + dealt_qty

                                if positions['pos'] > 0:
                                    positions['open_time'] = data['create_time'][0].split('.')[0]
                                    positions['price'] = dealt_avg_price
                            logger.info(
                                f"【成交确认】{TRADING_SECURITY} | 人工买入 | "
                                f"成交数量：{dealt_qty} | 成交均价：{dealt_avg_price} | positions_pos:{positions['pos']} | positions_price:{positions['price']}"
                            )
                            # 保存持仓到JSON
                            # save_positions_to_json(positions)
                        if data['trd_side'][0] == TrdSide.SELL:
                            if positions['pos'] < 0:

                                positions['price'] = (abs(positions['pos']) * positions[
                                    'price'] + dealt_avg_price * dealt_qty) / (abs(positions['pos']) + dealt_qty)
                                positions['pos'] = positions['pos'] - dealt_qty

                            else:
                                positions['pos'] = positions['pos'] - dealt_qty

                                if positions['pos'] < 0:
                                    positions['open_time'] = data['create_time'][0].split('.')[0]
                                    positions['price'] = dealt_avg_price
                            logger.info(
                                f"【成交确认】{TRADING_SECURITY} | 人工卖出 | "
                                f"成交数量：{dealt_qty} | 成交均价：{dealt_avg_price} | positions_pos:{positions['pos']} | positions_price:{positions['price']}"
                            )
                            # 保存持仓到JSON
                            # save_positions_to_json(positions)



        else:
            logger.error(f"【订单回调】获取订单数据失败：{data}")


class OnFillClass(TradeDealHandlerBase):
    """成交回调"""

    def on_recv_rsp(self, rsp_pb):
        ret, data = super(OnFillClass, self).on_recv_rsp(rsp_pb)
        if ret == RET_OK:
            logger.info(
                f"【成交明细】{data['code'][0]} | 订单ID：{data['order_id'][0]} | "
                f"成交ID：{data['deal_id'][0]} | 方向：{data['trd_side'][0]} | "
                f"价格：{data['deal_price'][0]} | 数量：{data['deal_qty'][0]} | "
                f"时间：{data['deal_time'][0]}"
            )
            on_fill(data)
        else:
            logger.error(f"【成交回调】获取成交数据失败：{data}")


############################ 主函数 ###############################
if __name__ == '__main__':
    # 加载持仓数据
    positions = {'pos': 0, 'open_time': '', 'action': '', 'price': 0}
    pos = get_holding_position(TRADING_SECURITY)
    if pos is not None:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        positions['pos'] = pos['pos']
        positions['price'] = pos['cost_price']
        positions['open_time'] = formatted_time

    # 初始化策略
    if not on_init():
        logger.error("初始化失败，脚本退出！")
        quote_context.close()
        trade_context.close()
    else:
        logger.info(f"【初始化成功】{TRADING_SECURITY} | 当前持仓：{positions} | 环境：{TRADING_ENVIRONMENT}")

        # 设置回调
        quote_context.set_handler(OnQuoteClass())
        trade_context.set_handler(OnOrderClass())
        trade_context.set_handler(OnFillClass())

        # 定义K线类型常量
        TRADING_PERIOD_1 = KLType.K_1M  # 1分钟K线
        TRADING_PERIOD_3 = KLType.K_3M  # 3分钟K线

        # 订阅行情（1分钟K线、3分钟K线、摆盘、逐笔）
        subscribe_ret, subscribe_data = quote_context.subscribe(
            code_list=[TRADING_SECURITY],
            subtype_list=[SubType.QUOTE, SubType.ORDER_BOOK, TRADING_PERIOD_1, TRADING_PERIOD_3]  # 添加TRADING_PERIOD_3
        )

        if subscribe_ret == RET_OK:
            logger.info(
                f"【订阅成功】{TRADING_SECURITY} | 订阅类型：{[SubType.QUOTE, SubType.ORDER_BOOK, TRADING_PERIOD_1, TRADING_PERIOD_3]}")
        else:
            logger.error(f"【订阅失败】 | 原因：{subscribe_data}")
            quote_context.close()
            trade_context.close()