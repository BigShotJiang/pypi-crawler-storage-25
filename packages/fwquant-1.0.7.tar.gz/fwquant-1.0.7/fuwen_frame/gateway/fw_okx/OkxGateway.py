import os
import traceback
from typing import Optional, Dict, List

from dotenv import load_dotenv

from fuwen_frame.gateway.fw_okx.OKX基类.okx_gateway import PrivateApi, OkxGateway
from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_adaptor.trader.object import OrderRequest, ContractData, OrderData
from fuwen_adaptor.trader.constant import Direction, Offset, Product
from fuwen_adaptor.trader.gateway import BaseGateway

# 加载环境变量
load_dotenv()

# 导入自定义日志模块（保持你的原有引用）


# OKX常量映射（适配fuwen标准）
DIRECTION_VT2OKX: Dict[Direction, str] = {
    Direction.LONG: "buy",
    Direction.SHORT: "sell"
}

ORDERTYPE_VT2OKX: Dict[str, str] = {
    "LIMIT": "limit",
    "MARKET": "market",
    "限价": "limit",
    "市价": "market"
}


class fw_OkxGateway(OkxGateway):
    """
    fuwen_adaptor OKX网关增强版（终极兼容版）
    - 整合posSide参数修复逻辑
    - 修复现货ccy参数不能为空问题
    - 替换原生PrivateApi为自定义版本
    - 异常隔离，不影响核心流程
    """
    DEFAULT_NAME: str = "福纹OKX网关"

    def __init__(self, event_engine, gateway_name: str = DEFAULT_NAME):
        super().__init__(event_engine, gateway_name)
        # 替换原生PrivateApi为自定义版本
        self.private_api = 福纹_PrivateApi(self)
        logger.info("【福纹OKX网关】初始化完成，已替换自定义PrivateApi", gateway_name=self.gateway_name)

    def send_order(self, req: OrderRequest) -> str:
        """
        扩展下单逻辑：先修复posSide，再调用父类方法
        """
        try:
            # 前置修复posSide参数（双重保障）
            self._fix_pos_side(req)
            logger.debug(f"福纹扩展后的订单请求：{req}")

            # 调用父类原生下单逻辑（已自动使用替换后的PrivateApi）
            return super().send_order(req)
        except Exception as e:
            logger.error(f"下单扩展处理失败：{str(e)}\n{traceback.format_exc()}")
            return ""

    def _fix_pos_side(self, req: OrderRequest):
        """
        前置修复posSide参数（双重保障）
        """
        try:
            # 1. 获取合约信息
            contract = self.symbol_contract_map.get(req.symbol)
            if not contract:
                logger.info(f"合约不存在，跳过posSide修复：{req.symbol}")
                return

            # 2. 判断产品类型
            product_type = str(contract.product).upper() if contract.product else ""

            # 3. 现货：移除posSide
            if "SPOT" in product_type:
                if hasattr(req, "posSide"):
                    delattr(req, "posSide")
                logger.debug(f"现货合约移除posSide：{req.symbol}")
                return

            # 4. 合约：设置posSide
            contract_keywords = ["FUTURES", "SWAP", "OPTIONS", "PERPETUAL", "FUTURE"]
            if any(keyword in product_type for keyword in contract_keywords):
                pos_side_mapping = {
                    (Direction.LONG, Offset.OPEN): "long",
                    (Direction.SHORT, Offset.OPEN): "short",
                    (Direction.LONG, Offset.CLOSE): "long",
                    (Direction.SHORT, Offset.CLOSE): "short",
                    (Direction.LONG, Offset.CLOSETODAY): "long",
                    (Direction.SHORT, Offset.CLOSETODAY): "short",
                    (Direction.LONG, Offset.CLOSEYESTERDAY): "long",
                    (Direction.SHORT, Offset.CLOSEYESTERDAY): "short",
                }

                key = (req.direction, req.offset)
                target_pos_side = pos_side_mapping.get(key)

                if target_pos_side:
                    setattr(req, "posSide", target_pos_side)
                    logger.debug(f"修复posSide参数：{req.symbol} -> {key} -> {target_pos_side}")
                else:
                    if hasattr(req, "posSide"):
                        delattr(req, "posSide")
                    logger.warning(f"未知订单组合，清空posSide：{req.direction}/{req.offset}")

        except Exception as e:
            logger.error(f"修复posSide参数出错：{str(e)}\n{traceback.format_exc()}")


class 福纹_PrivateApi(PrivateApi):
    """
    重写后的OKX私有API类
    - 核心修复posSide参数传递问题
    - 新增现货ccy参数必传处理（解决50014错误）
    - 完全兼容原有逻辑
    """

    def __init__(self, gateway: BaseGateway):
        super().__init__(gateway)
        # 复用父类的属性，避免重复定义导致的初始化问题
        self.gateway = gateway

    def send_order(self, req: OrderRequest) -> str:
        """
        重写下单逻辑
        - 核心新增posSide参数处理
        - 修复现货ccy参数不能为空问题
        """
        try:
            # 1. 原有校验：订单类型
            if req.type.value not in ORDERTYPE_VT2OKX:
                self.gateway.write_log(f"下单失败：不支持的订单类型 {req.type.value}")
                return ""

            # 2. 原有校验：合约信息
            contract: Optional[ContractData] = self.gateway.get_contract_by_symbol(req.symbol)
            if not contract:
                self.gateway.write_log(f"下单失败：合约不存在 {req.symbol}")
                return ""

            # 3. 原有逻辑：生成订单ID
            self.order_count += 1
            count_str = str(self.order_count).rjust(6, "0")
            orderid = f"{self.connect_time}{count_str}"

            # 4. 原有逻辑：构建基础参数
            arg: dict = {
                "instIdCode": contract.extra["instIdCode"],
                "clOrdId": orderid,
                "side": DIRECTION_VT2OKX[req.direction],
                "ordType": ORDERTYPE_VT2OKX[req.type.value],
                "px": str(req.price),
                "sz": str(req.volume),
                "tdMode": "cross"
            }

            # 5. 修复核心：ccy参数处理（优先现货计价币种，再用保证金币种）
            if "SPOT" in req.symbol:
                # 现货场景：从合约信息中获取计价币种作为ccy
                quote_ccy_list: List[str] = contract.extra.get("tradeQuoteCcyList", [])
                if quote_ccy_list:
                    arg["ccy"] = quote_ccy_list[0]
                    logger.debug(f"现货下单设置ccy参数：{req.symbol} -> {quote_ccy_list[0]}")
                else:
                    self.gateway.write_log(f"下单失败：现货{req.symbol}无计价币种信息")
                    return ""
            elif self.margin_currency:
                # 合约场景：复用原有保证金币种逻辑
                arg["ccy"] = self.margin_currency

            # 6. 原有逻辑：现货参数（保留，确保兼容性）
            if "SPOT" in req.symbol:
                quote_ccy_list: List[str] = contract.extra["tradeQuoteCcyList"]
                arg["tradeQuoteCcy"] = quote_ccy_list[0]

            # 7. 核心新增：合约posSide参数
            if "SPOT" not in req.symbol:
                pos_side = self._get_okx_pos_side(req.direction, req.offset)
                if pos_side:
                    arg["posSide"] = pos_side
                    logger.debug(f"设置posSide参数：{req.symbol} -> {pos_side}")

            # 8. 原有逻辑：构建并发送WebSocket包
            self.reqid += 1
            packet: dict = {
                "id": str(self.reqid),
                "op": "order",
                "args": [arg]
            }
            self.send_packet(packet)

            # 9. 原有逻辑：创建订单对象
            order: OrderData = req.create_order_data(orderid, self.gateway_name)
            self.gateway.on_order(order)

            return str(order.vt_orderid)

        except Exception as e:
            logger.error(f"PrivateApi下单异常：{str(e)}\n{traceback.format_exc()}")
            return ""

    def _get_okx_pos_side(self, direction: Direction, offset: Offset) -> Optional[str]:
        """
        映射fuwen方向/开平到OKX的posSide参数
        """
        pos_side_mapping = {
            (Direction.LONG, Offset.OPEN): "long",
            (Direction.SHORT, Offset.OPEN): "short",
            (Direction.LONG, Offset.CLOSE): "long",
            (Direction.SHORT, Offset.CLOSE): "short",
            (Direction.LONG, Offset.CLOSETODAY): "long",
            (Direction.SHORT, Offset.CLOSETODAY): "short",
            (Direction.LONG, Offset.CLOSEYESTERDAY): "long",
            (Direction.SHORT, Offset.CLOSEYESTERDAY): "short",
        }
        return pos_side_mapping.get((direction, offset))


# 测试用例（可选）
if __name__ == "__main__":
    from fuwen_adaptor.trader.event import EventEngine

    # 初始化网关
    event_engine = EventEngine()
    gateway = fw_OkxGateway(event_engine)
    logger.info("福纹OKX网关测试初始化完成")
