from PySide6 import QtCore, QtWidgets

from fuwen_frame.gateway import fuwen
from fuwen_adaptor.event import EventEngine
from fuwen_adaptor.trader.engine import MainEngine
from fuwen_adaptor.trader.ui import MainWindow
from fuwen_adaptor.trader.ui.widget import TradingWidget, BaseMonitor
from fuwen_frame.gateway.fuwen.trader.ui.widget import fw_TradingWidget
from fuwen_adaptor.trader.utility import TRADER_DIR


class fw_MainWindow(MainWindow):
    """主窗口"""

    def __init__(self, main_engine: MainEngine, event_engine: EventEngine) -> None:
        # 调用父类构造方法，保留原有所有初始化逻辑
        super().__init__(main_engine, event_engine)

        # 仅修改这一句窗口标题，其余保持与父类一致
        self.window_title: str = f"福纹量化系统 - [{fuwen.__version__}]"
        self.setWindowTitle(self.window_title)

    def create_dock(self, widget_class, name, area):
        """
        重写创建dock的方法：自动把 TradingWidget 替换成 fw_TradingWidget
        """
        # 核心：只要父类要创建原版 TradingWidget，就替换成你的自定义组件
        if widget_class == TradingWidget:
            widget_class = fw_TradingWidget

        # 其他所有组件，保持父类原来逻辑不变
        return super().create_dock(widget_class, name, area)

    def init_dock(self) -> None:
        # 直接执行父类方法，自动用你的组件替换原版，无需任何修改
        super().init_dock()
