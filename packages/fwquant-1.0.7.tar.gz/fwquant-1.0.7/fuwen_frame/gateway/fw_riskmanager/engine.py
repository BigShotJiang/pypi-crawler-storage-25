from logging import ERROR



from fuwen_adaptor.event import Event
from fuwen_adaptor.trader.event import EVENT_LOG
from fuwen_adaptor.trader.object import LogData
from fuwen_riskmanager import RiskEngine, APP_NAME
from fuwen_riskmanager.base import EVENT_RISK_NOTIFY

try:
    import winsound
except ImportError:
    winsound = None  # type: ignore


class fw_RiskEngine(RiskEngine):
    """风控引擎"""

    def write_log(self, msg: str) -> None:
        """输出风控日志"""
        log: LogData = LogData(
            msg="【风控引擎】警示：委托被拦截，" + msg,
            level=ERROR,
            gateway_name=APP_NAME,
        )
        self.event_engine.put(Event(EVENT_LOG, log))

        # 推送风险通知事件
        self.event_engine.put(Event(EVENT_RISK_NOTIFY, msg))

        # 输出拦截日志后播放声音
        if winsound:
            winsound.PlaySound("SystemExclamation", winsound.SND_ALIAS | winsound.SND_ASYNC)
