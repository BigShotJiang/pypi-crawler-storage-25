from fuwen_ctp.fw_ctp import CtpGateway
from fuwen_ctp.fw_ctp.gateway.ctp_gateway import CtpTdApi
from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_adaptor.event import EventEngine


# fw_ctp.gateway.ctp_gateway.CtpTdApi.onRspUserLogin

class fw_CtpGateway(CtpGateway):
    def __init__(self, event_engine: EventEngine, gateway_name: str) -> None:
        """构造函数"""
        super().__init__(event_engine, gateway_name)

        self.td_api: "fw_CtpTdApi" = fw_CtpTdApi(self)


class fw_CtpTdApi(CtpTdApi):
    """
    期货CTP柜台交易接口。
    """

    def onRspUserLogin(self, data: dict, error: dict, reqid: int, last: bool) -> None:
        """用户登录请求回报"""
        if not error["ErrorID"]:
            self.frontid = data["FrontID"]
            self.sessionid = data["SessionID"]
            self.login_status = True
            logger.info("【登录】交易服务器登录成功.")

            # 自动确认结算单
            ctp_req: dict = {
                "BrokerID": self.brokerid,
                "InvestorID": self.userid
            }
            self.reqid += 1
            self.reqSettlementInfoConfirm(ctp_req, self.reqid)
        else:
            self.login_failed = True

            logger.error("交易服务器登录失败", error)
