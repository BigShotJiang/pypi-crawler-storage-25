from .启动程序.启动_福纹系统 import main

if __name__ == '__main__':
    main()
