import pandas as pd
from futu import OpenQuoteContext, KLType, AuType

quote_context = OpenQuoteContext(host='127.0.0.1', port=11111)


# 拿k线数据
def 获得k线(股票代码, 数量, 类型=KLType.K_DAY, 复权类型=AuType.QFQ):
    # 获取1分钟K线数据（用于重采样）
    subscribe_ret, subscribe_data = quote_context.subscribe(code_list=股票代码, subtype_list=类型)
    _k_ret, _k_data = quote_context.get_cur_kline(code=股票代码, num=数量, ktype=类型, autype=复权类型)
    return _k_ret, _k_data


if __name__ == '__main__':
    股票代码 = 'HK.HSImain'
    k_ret, k_data_df = 获得k线(股票代码=股票代码, 数量=14400, 类型=KLType.K_1M)

    k_data_df['datetime'] = pd.to_datetime(k_data_df['time_key'], format='%Y-%m-%d %H:%M:%S')
    k_data_df = pd.DataFrame(k_data_df, columns=['datetime', 'open', 'high', 'low', 'close', 'volume', 'turnover',
                                                 'open_interest'])
    k_data_df['open_interest'] = 0

    k_data_df.to_csv(f'/Users/yanhuang/github/fwquant/fuwen_fuwen/缓存目录/HK.{股票代码}_1m.csv', index=False)
    print(f"k_data_df: {k_data_df}")
