import os
import traceback

import akshare as ak
import numpy as np
import pandas as pd

from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# -------------------------- 配置参数 --------------------------
STOCK_CODE = "HK.HSI2602"  # 恒指期货
START_TIME = "2026-01-30 09:30:00"  # 开始时间
END_TIME = "2026-02-01 16:00:00"  # 结束时间
SAVE_PATH = f"/Users/yanhuang/github/fwquant/fuwen_frame/缓存目录/{STOCK_CODE}_1m.csv"


# --------------------------------------------------------------

def get_hk_futures_data_akshare():
    """
    使用akshare获取港股/期货数据
    注意：akshare对港股期货支持有限，可能需要调整
    """
    print("🔍 尝试使用akshare获取数据...")

    # 方法1：尝试获取恒生指数数据（股票指数）
    try:
        print("1. 尝试获取恒生指数数据...")
        # 获取恒生指数成分股（作为备用方案）
        df = ak.stock_hk_spot()
        if not df.empty:
            print(f"   ✅ 获取到{len(df)}只港股实时数据")
            # 这里只是示例，实际需要调整获取期货数据
    except Exception as e:
        print(f"   ❌ 获取港股数据失败: {str(e)[:50]}")

    # 方法2：尝试获取国际期货数据
    try:
        print("\n2. 尝试获取国际期货数据...")
        # akshare的国际期货接口
        df = ak.futures_hq_subscribe_exchange_symbol()
        if not df.empty:
            print(f"   ✅ 获取到{len(df)}个期货品种")
            print(f"   交易所列表: {df['exchange'].unique()}")
    except Exception as e:
        print(f"   ❌ 获取国际期货失败: {str(e)[:50]}")

    # 方法3：尝试获取国内期货数据（测试用）
    try:
        print("\n3. 获取国内期货数据示例...")
        # 获取国内期货主力合约列表
        df = ak.futures_main_sina()
        if not df.empty:
            print(f"   ✅ 获取到{len(df)}个国内期货主力合约")
            print(f"   示例: {df['symbol'].head(3).tolist()}")

            # 获取某个期货的分钟数据（例如：甲醇MA）
            symbol = "MA0"  # 甲醇主力
            period = "1"  # 1分钟
            try:
                futures_df = ak.futures_zh_minute_sina(symbol=symbol, period=period)
                if not futures_df.empty:
                    print(f"   ✅ 成功获取{symbol}的{len(futures_df)}条分钟数据")
                    return futures_df, "国内期货示例"
            except Exception as e:
                print(f"   ❌ 获取{symbol}分钟数据失败: {str(e)[:50]}")
    except Exception as e:
        print(f"   ❌ 获取国内期货列表失败: {str(e)[:50]}")

    return pd.DataFrame(), None


def get_simulated_hk_futures_data(start_time, end_time, symbol):
    """
    生成模拟的恒指期货数据（更真实）
    """
    print(f"\n📊 生成模拟的{symbol}数据...")

    # 创建完整的交易时间序列
    start_dt = pd.to_datetime(start_time)
    end_dt = pd.to_datetime(end_time)

    # 生成每个交易日的分钟数据
    all_data = []

    # 遍历每个交易日
    current_date = start_dt.date()
    end_date = end_dt.date()

    while current_date <= end_date:
        # 生成该交易日的分钟数据（09:30-16:00）
        date_str = current_date.strftime("%Y-%m-%d")

        # 创建该交易日的分钟时间序列
        day_start = pd.Timestamp(f"{date_str} 09:30:00")
        day_end = pd.Timestamp(f"{date_str} 16:00:00")

        if day_start >= start_dt and day_end <= end_dt:
            minutes = pd.date_range(start=day_start, end=day_end, freq='1min')
            n = len(minutes)

            if n > 0:
                # 更真实的模拟：开盘价、日内趋势、波动率
                base_price = 17000
                daily_trend = np.random.randn() * 100  # 日内趋势
                volatility = 50 + np.random.rand() * 50  # 波动率

                # 生成价格序列（带趋势的随机游走）
                returns = np.random.randn(n) * 0.0005  # 0.05%的分钟波动
                trend_component = np.linspace(0, daily_trend / 10000, n)  # 日内趋势
                prices = base_price * np.exp(np.cumsum(returns) + trend_component)

                # 生成K线
                opens = prices * (1 - np.random.rand(n) * 0.0005)
                highs = np.maximum(
                    opens * (1 + np.abs(np.random.randn(n)) * 0.001),
                    prices * (1 + np.abs(np.random.randn(n)) * 0.001)
                )
                lows = np.minimum(
                    opens * (1 - np.abs(np.random.randn(n)) * 0.001),
                    prices * (1 - np.abs(np.random.randn(n)) * 0.001)
                )
                closes = prices

                # 成交量模式：开盘和收盘较高，中午较低
                time_factors = np.sin(np.pi * np.arange(n) / n) * 0.5 + 0.8  # U型曲线
                volumes = (np.random.randint(500, 5000, n) * time_factors).astype(int)
                turnovers = volumes * prices * 50  # 假设每手50港币合约乘数

                day_df = pd.DataFrame({
                    'datetime': minutes,
                    'open': opens,
                    'high': highs,
                    'low': lows,
                    'close': closes,
                    'volume': volumes,
                    'turnover': turnovers.astype(int)
                })

                all_data.append(day_df)
                print(f"   📅 {date_str}: {n}条数据")

        current_date += pd.Timedelta(days=1)

    if all_data:
        df = pd.concat(all_data, ignore_index=True)
        return df
    else:
        # 如果没生成数据，返回简单模拟
        return generate_simple_mock_data(start_time, end_time)


def generate_simple_mock_data(start_time, end_time):
    """生成简单的模拟数据"""
    dates = pd.date_range(start=start_time, end=end_time, freq='1min')
    n = len(dates)

    df = pd.DataFrame({
        'datetime': dates,
        'open': 17000 + np.random.randn(n) * 100,
        'high': 17000 + np.random.randn(n) * 100 + 50,
        'low': 17000 + np.random.randn(n) * 100 - 50,
        'close': 17000 + np.random.randn(n) * 100,
        'volume': np.random.randint(100, 10000, n),
        'turnover': np.random.randint(100000, 10000000, n)
    })

    return df


def standardize_for_fuwen(df, symbol):
    """标准化为fuwen格式"""
    print("🔄 标准化数据格式...")

    # 添加必要列
    df['open_interest'] = 0
    df['symbol'] = symbol

    # 确保列顺序正确
    required_cols = ['datetime', 'open', 'high', 'low', 'close', 'volume', 'turnover', 'open_interest']

    # 只保留需要的列
    available_cols = [col for col in required_cols if col in df.columns]
    result_df = df[available_cols].copy()

    # 排序
    result_df = result_df.sort_values('datetime').reset_index(drop=True)

    return result_df


def check_data_quality(df):
    """检查数据质量"""
    print("\n🔍 数据质量检查：")
    print(f"   总数据量: {len(df)} 条")
    print(f"   时间范围: {df['datetime'].min()} 至 {df['datetime'].max()}")
    print(f"   缺失值数量: {df.isnull().sum().sum()}")

    # 基本统计
    print(f"\n📈 价格统计：")
    print(f"   开盘价: {df['open'].mean():.2f} ± {df['open'].std():.2f}")
    print(f"   最高价: {df['high'].mean():.2f} ± {df['high'].std():.2f}")
    print(f"   最低价: {df['low'].mean():.2f} ± {df['low'].std():.2f}")
    print(f"   收盘价: {df['close'].mean():.2f} ± {df['close'].std():.2f}")
    print(f"   价格范围: {df['low'].min():.2f} - {df['high'].max():.2f}")

    print(f"\n📊 成交量统计：")
    print(f"   平均成交量: {df['volume'].mean():.0f}")
    print(f"   最大成交量: {df['volume'].max():.0f}")
    print(f"   总成交量: {df['volume'].sum():,.0f}")


def save_data_with_backup(df, save_path):
    """保存数据并创建备份"""
    # 确保目录存在
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    # 如果文件已存在，创建备份
    if os.path.exists(save_path):
        import shutil
        backup_path = save_path.replace('.csv', f'_backup_{pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")}.csv')
        shutil.copy2(save_path, backup_path)
        print(f"📂 已创建备份: {backup_path}")

    # 保存新数据
    df.to_csv(save_path, index=False, encoding='utf-8')
    file_size = os.path.getsize(save_path) / 1024
    print(f"💾 数据已保存: {save_path} ({file_size:.1f} KB)")


def main():
    """主函数"""
    print("=" * 60)
    print("📊 恒指期货(HK.HSI2602)数据获取工具")
    print("=" * 60)
    print(f"目标标的: {STOCK_CODE}")
    print(f"时间范围: {START_TIME} 至 {END_TIME}")
    print(f"保存路径: {SAVE_PATH}")
    print("-" * 60)

    try:
        # 1. 尝试使用akshare获取真实数据
        real_data, source = get_hk_futures_data_akshare()

        if not real_data.empty:
            print(f"\n✅ 从{source}获取到真实数据")
            df = real_data
        else:
            # 2. 生成模拟数据
            print(f"\n⚠️  使用模拟数据（用于测试）")
            df = get_simulated_hk_futures_data(START_TIME, END_TIME, STOCK_CODE)

        # 3. 标准化数据格式
        standardized_df = standardize_for_fuwen(df, STOCK_CODE)

        # 4. 检查数据质量
        check_data_quality(standardized_df)

        # 5. 保存数据
        save_data_with_backup(standardized_df, SAVE_PATH)

        # 6. 显示数据预览
        print(f"\n📋 数据预览（前5行）：")
        print(standardized_df.head())

        print(f"\n📋 数据预览（后5行）：")
        print(standardized_df.tail())

        print(f"\n🎉 数据处理完成！")
        print(f"   共处理 {len(standardized_df)} 条1分钟K线数据")
        print(f"   可用于fuwen回测或实盘交易")

        # 7. 使用建议
        print(f"\n💡 使用建议：")
        print("   1. 在fuwen中使用时，确保数据文件路径正确")
        print("   2. 可以使用fuwen的CsvLoader模块导入数据")
        print("   3. 对于实盘交易，建议连接真实行情源")

    except Exception as e:
        print(f"\n❌ 程序执行失败：{str(e)}")
        traceback.print_exc()


if __name__ == '__main__':
    main()
