import sys
from datetime import datetime, date, time

from PySide6 import QtCore
from qtpy import QtWidgets

from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_adaptor.trader.engine import MainEngine
from fuwen_adaptor.trader.ui.widget import ConnectDialog


# ------------------------------
# 核心：动态交易日判断函数
# ------------------------------

def 是否交易日_2026(check_date: date = None) -> bool:
    """
    动态判断指定日期是否为A股/中金所交易日
    :param check_date: 要检查的日期（默认当前日期）
    :return: True=交易日，False=非交易日
    """
    # 1. 默认使用当前日期
    if check_date is None:
        check_date = date.today()

    # 2. 先判断是否为周末（周六/周日）
    weekday = check_date.weekday()  # 0=周一, 5=周六, 6=周日
    if weekday >= 5:
        return False

    # 3. 按年份整理节假日和调休日（字典格式，便于编辑/扩展）
    # 2026年节假日（根据国务院节假日安排提前整理，实际以交易所公告为准）
    holiday_config = {
        2026: {
            "holidays": [
                date(2026, 1, 1),  # 元旦
                date(2026, 2, 17),  # 春节
                date(2026, 2, 18),  # 春节
                date(2026, 2, 19),  # 春节
                date(2026, 2, 20),  # 春节
                date(2026, 2, 21),  # 春节
                date(2026, 4, 5),  # 清明节
                date(2026, 5, 1),  # 劳动节
                date(2026, 5, 2),  # 劳动节
                date(2026, 5, 3),  # 劳动节
                date(2026, 5, 4),  # 劳动节
                date(2026, 6, 17),  # 端午节
                date(2026, 9, 22),  # 中秋节
                date(2026, 10, 1),  # 国庆节
                date(2026, 10, 2),  # 国庆节
                date(2026, 10, 3),  # 国庆节
                date(2026, 10, 4),  # 国庆节
                date(2026, 10, 5),  # 国庆节
            ],
            "work_weekends": [
                date(2026, 2, 15),  # 周日（春节调班）
                date(2026, 2, 22),  # 周六（春节调班）
                date(2026, 4, 6),  # 周日（清明节调班）
                date(2026, 4, 27),  # 周六（劳动节调班）
                date(2026, 5, 7),  # 周日（劳动节调班）
                date(2026, 9, 20),  # 周六（中秋节调班）
                date(2026, 10, 10),  # 周六（国庆节调班）
            ]
        },
        # 可快速扩展其他年份，比如2025年
        2025: {
            "holidays": [date(2025, 1, 1), ...],
            "work_weekends": [date(2025, 1, 25), ...]
        }
    }

    # 4. 获取当前检查日期的年份对应的节假日配置
    target_year = check_date.year
    # 如果年份不在配置中，默认用空列表（避免KeyError）
    year_holidays = holiday_config.get(target_year, {}).get("holidays", [])
    year_work_weekends = holiday_config.get(target_year, {}).get("work_weekends", [])

    # 5. 最终判断
    if check_date in year_holidays:
        return False  # 法定节假日，不交易
    if check_date in year_work_weekends:
        return True  # 调休日，需要交易

    # 6. 非周末、非节假日、非调休日 = 交易日
    return True


# ------------------------------
# 网关连接函数（示例）
# ------------------------------
# ===== 自动连接OKX的函数 =====
def 登录自动连接网关(主引擎, 网关名称: str = "OKX"):
    """
    自动连接OKX网关
    """
    try:
        # 1. 创建OKX连接对话框
        dialog = ConnectDialog(main_engine=主引擎, gateway_name=网关名称)
        # 4. 自动点击连接按钮
        for button in dialog.findChildren(QtWidgets.QPushButton):
            if "连接" in button.text() or "connect" in button.text().lower():
                button.click()
                break

        logger.info(f"[{网关名称}]自动连接请求已发送")
    except Exception as e:
        logger.error(f"[{网关名称}]自动连接请求失败: {str(e)}")


# ------------------------------
# 核心：根据时间自动连接网关
# ------------------------------
def 登录自动连接SIMNOW网关(主引擎: MainEngine, 环境1: str = "SIMNOW-247672", 环境2_7X24: str = "环境1"):
    """内部函数：时间判断+连接执行"""
    now = datetime.now()
    当前时间 = now.time()
    当前日期 = now.date()

    # 动态判断是否为交易日
    是否为交易日 = 是否交易日_2026(当前日期)
    连接服务器 = ""
    # 1. 白天交易时段（09:25-15:00）
    if 是否为交易日:
        if (当前时间 >= time(9, 25) and 当前时间 <= time(11, 30)) \
                or (当前时间 >= time(13, 00) and 当前时间 <= time(15, 00)):
            连接服务器 = "环境1"
        if (当前时间 >= time(16, 00) and 当前时间 <= time(23, 59)) \
                or (当前时间 >= time(00, 00) and 当前时间 <= time(9, 00)):
            连接服务器 = "环境2"
    else:
        if (当前时间 >= time(16, 00) and 当前时间 <= time(23, 59)) \
                or (当前时间 >= time(00, 00) and 当前时间 <= time(12, 00)):
            连接服务器 = "环境2"

    if 连接服务器 == "环境1":
        登录自动连接网关(主引擎=主引擎, 网关名称=环境1)
    elif 连接服务器 == "环境2":
        登录自动连接网关(主引擎=主引擎, 网关名称=环境2_7X24)
    else:
        logger.info(
            f"当前时间无可用simnow服务器: {连接服务器},说明：交易日：环境一（09：25-11：30，13：00-15：00），环境二（16：00-次日09:00） 非交易日：环境一（无），环境二（16：00-次日12:00）")


if __name__ == '__main__':
    result = 是否交易日_2026(date(2026, 3, 23))
    print(f"是否为交易日: {result}")
