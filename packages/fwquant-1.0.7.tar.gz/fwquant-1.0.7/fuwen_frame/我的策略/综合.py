from fuwen_frame.我的策略.示例_七福 import 示例_七福类
from fuwen_frame.我的策略.示例_七福_20260407 import 示例_七福类20260407
from fuwen_frame.我的策略.示例_七福_继承.main import 示例_七福_继承
from fuwen_frame.我的策略.示例_七福_继承.示例_七福_批量保存 import 示例_七福_批量保存
from fuwen_frame.我的策略.示例_双均线 import 示例_双均线类
from fuwen_frame.我的策略.示例_双均线_新 import 示例_双均线_新类
from fuwen_frame.我的策略.示例_双均线_继承.main import 示例_双均线_继承
from fuwen_frame.我的策略.示例_常用 import 示例_常用类
from fuwen_frame.我的策略.示例_指定时间交易 import 示例_指定时间交易类
from fuwen_frame.我的策略.示例_最简 import 示例_最简类
from fuwen_frame.我的策略.示例_随机 import 示例_随机类
from fuwen_frame.我的策略.示例_随机_继承.main import 示例_随机_继承

if __name__ == '__main__':
    _unused_classes = [
        # 七福
        示例_七福类,
        示例_七福_继承,
        示例_七福_批量保存,
        示例_七福类20260407,

        # 双均线
        示例_双均线类,
        示例_双均线_继承,
        示例_双均线_新类,

        # 其它
        示例_常用类,
        示例_最简类,
        示例_指定时间交易类,

        示例_随机类,
        示例_随机_继承,

    ]
