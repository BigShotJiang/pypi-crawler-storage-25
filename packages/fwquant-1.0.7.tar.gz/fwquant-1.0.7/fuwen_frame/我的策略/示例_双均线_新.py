from dataclasses import dataclass

import numpy as np
from fuwen_ctastrategy import CtaTemplate

from fuwen_signal.fw_signal.信号工厂.双均线.双均线_新 import 双均线信号_新
from fuwen_frame.我的策略.示例_双均线 import 交易指令
from fuwen_adaptor.trader.object import BarData



# ====================== fuwen策略类（框架接口英文，自定义部分中文） ======================
class 示例_双均线_新类(CtaTemplate):
    """双均线策略（框架接口英文，自定义标识中文）"""
    # 策略参数（自定义中文）
    快线周期 = 10
    慢线周期 = 30
    下单数量 = 1

    # 框架原生属性（必须英文）
    author = "双均线策略"
    parameters = ["快线周期", "慢线周期", "下单数量"]  # fuwen支持中文参数名
    variables = ["pos", "快线值", "慢线值"]

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # 自定义数据缓存：改为动态列表，只存储有效收盘价
        self.bar = None
        self.快线值 = None
        self.慢线值 = None
        self.价格列表 = []  # 替换原固定长度数组，动态存储收盘价
        # 新增：标记是否是第一根K线（避免索引越界）
        self.is_first_bar = True
        self.最大缓存K线数量 = 10000  # 新增：缓存最近200根K线

    def on_init(self):
        """框架原生初始化接口（英文）"""
        self.write_log(f"双均线策略初始化 - 快线:{self.快线周期} 慢线:{self.慢线周期}")

    def on_start(self):
        """框架原生启动接口（英文）"""
        self.write_log("双均线策略启动")

    def on_stop(self):
        """框架原生停止接口（英文）"""
        self.write_log("双均线策略停止")

    def on_bar(self, bar: BarData):
        print(f"时间:{bar.datetime} 价格:{bar.close_price}")
        """框架原生K线回调接口（英文）"""
        # 核心修复：避免未来数据的关键逻辑
        # 1. 首次收到K线：只缓存，不计算信号（因为需要至少1根已收盘K线）
        if self.is_first_bar:
            self.价格列表.append(bar.close_price)
            self.is_first_bar = False
            return

        # 2. 非首次收到K线：
        #    - 先将上一根K线的收盘价加入列表（已收盘，无未来数据）
        #    - 计算信号后，再缓存当前K线（供下一根K线使用）
        # 注意：这里先计算信号，再更新价格列表，确保计算用的都是已收盘数据
        指令 = 双均线信号_新(
            价格列表=self.价格列表,  # 此时列表中只有上一根及之前的已收盘K线价格
            快线周期=self.快线周期,
            慢线周期=self.慢线周期,
            当前持仓=self.pos,
            最新价格=bar.close_price,  # 下单价格用当前最新价，无问题
            下单数量=self.下单数量
        )

        # 3. 执行交易指令
        self.执行交易指令(指令)

        # 4. 更新价格列表：将当前K线收盘价加入（供下一根K线计算使用）
        self.价格列表.append(bar.close_price)

        # 5. 限制列表长度：避免内存溢出（）
        if len(self.价格列表) > self.最大缓存K线数量:
            self.价格列表 = self.价格列表[-self.最大缓存K线数量:]

        # 6. 更新UI
        self.put_event()

    def 执行交易指令(self, 指令: 交易指令):
        """自定义执行指令方法（全中文）"""
        if 指令.操作类型 == "开多":
            self.buy(price=指令.价格, volume=指令.数量)  # 框架原生下单方法（英文）
            self.write_log(f"开多单 - 价格:{指令.价格}, 数量:{指令.数量}")
        elif 指令.操作类型 == "开空":
            self.short(price=指令.价格, volume=指令.数量)
            self.write_log(f"开空单 - 价格:{指令.价格}, 数量:{指令.数量}")
        elif 指令.操作类型 == "平空反手多":
            self.cover(price=指令.价格, volume=abs(self.pos))
            self.buy(price=指令.价格, volume=指令.数量)
            self.write_log(f"平空反手开多 - 价格:{指令.价格}, 数量:{指令.数量}")
        elif 指令.操作类型 == "平多反手空":
            self.sell(price=指令.价格, volume=self.pos)
            self.short(price=指令.价格, volume=指令.数量)
            self.write_log(f"平多反手开空 - 价格:{指令.价格}, 数量:{指令.数量}")
        elif 指令.操作类型 == "无操作":
            pass  # 无操作
