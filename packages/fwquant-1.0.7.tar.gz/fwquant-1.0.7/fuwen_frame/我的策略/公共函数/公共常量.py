import os

from fuwen_adaptor.trader.setting import SETTING_FILENAME

SETTING_PATH = os.path.expanduser(f"~/.fw_quant/{SETTING_FILENAME}")