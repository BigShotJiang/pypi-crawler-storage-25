import random

from fuwen_ctastrategy import CtaTemplate
from fuwen_adaptor.trader.object import BarData, TradeData, TickData, OrderData


class 示例_常用类(CtaTemplate):
    """fuwen_adaptor CTA通用参考模板-中文标识｜含全核心API+模块化结构｜原随机策略逻辑"""
    # 策略可配置参数（回测/实盘UI直接修改，无需改代码）
    触发交易概率 = 0.2
    单次交易手数 = 1
    单方向最大持仓 = 5
    开多概率权重 = 0.7
    开空概率权重 = 0.3
    author = "fuwen通用模板"  # 保留原生字段名

    # fuwen标准配置：UI可配置参数列表/UI显示参数列表
    显示参数列表 = ["触发交易概率", "单次交易手数", "单方向最大持仓", "开多概率权重", "开空概率权重", "author"]
    parameters = 显示参数列表  # 保留原生字段名

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        # 保留原生初始化参数名，保证与fuwen框架兼容
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # 策略运行统计（通用统计项，按需拓展）
        self.pnl = 0
        self.统计_总触发 = 0
        self.统计_开多 = 0
        self.统计_平多 = 0
        self.统计_开空 = 0
        self.统计_平空 = 0
        self.统计_无操作 = 0

    # -------------------------------------------------------------------------
    # 模块1：策略生命周期（fuwen必实现-初始化/启动/停止）
    # -------------------------------------------------------------------------
    def on_init(self) -> None:
        """策略初始化（fuwen原生接口）"""
        self.write_log("策略初始化｜回测加载10天1分钟K线")  # 保留原生API

    def on_start(self) -> None:
        """策略启动（fuwen原生接口）"""
        启动信息 = f"【策略启动】{self.strategy_name}｜合约：{self.vt_symbol}｜最大持仓：{self.单方向最大持仓}手"
        self.write_log(启动信息)
        print(启动信息)
        self.put_event()  # 保留原生API：更新客户端UI持仓/参数

    def on_stop(self) -> None:
        """策略停止（fuwen原生接口）"""
        停止统计 = (
            f"【策略停止】{self.strategy_name}｜合约：{self.vt_symbol}\n"
            f"  总触发：{self.统计_总触发}｜无操作：{self.统计_无操作}\n"
            f"  开多：{self.统计_开多}｜平多：{self.统计_平多}\n"
            f"  开空：{self.统计_开空}｜平空：{self.统计_平空}\n"
            f"  当前持仓：{self.pos}手｜累计盈亏：{self.pnl:.2f}"
        )
        self.write_log(停止统计)
        print(停止统计)
        self.put_event()  # 保留原生API

    # -------------------------------------------------------------------------
    # 模块2：行情数据回调（fuwen核心-Tick/K线，回测/实盘行情入口）
    # -------------------------------------------------------------------------
    def on_tick(self, tick: TickData) -> None:
        """Tick行情回调（fuwen原生接口）：仅实盘/模拟触发，回测不触发｜最小粒度行情"""
        tick行情 = f"【TICK行情】{self.vt_symbol}｜最新价：{tick.last_price}｜买一：{tick.bid_price_1}｜卖一：{tick.ask_price_1}"
        # 实盘如需打印行情，取消下方注释
        # print(tick行情)

    def on_bar(self, bar: BarData) -> None:
        """K线行情回调（fuwen原生接口）：回测/实盘/模拟通用｜策略核心逻辑入口"""
        self.cancel_all()  # 保留原生API：防止未成交委托重复挂单
        self.sync_data()  # 保留原生API：fuwen实盘专用，同步最新持仓/账户数据

        if random.random() < self.触发交易概率:
            交易信号 = self.生成交易信号()
            self.统计_总触发 += 1
            self.执行交易(交易信号, bar)
        else:
            self.统计_无操作 += 1

        self.put_event()  # 保留原生API：K线结束后更新UI，保证数据实时

    # -------------------------------------------------------------------------
    # 模块3：交易信号生成（通用模板-可直接替换为自定义策略逻辑）
    # -------------------------------------------------------------------------
    def 生成交易信号(self) -> str:
        """生成交易信号｜返回：开多/开空/平多/平空｜可替换为MA/BOLL/RSI等自定义逻辑"""
        可选信号 = []
        # 基于当前持仓添加平仓信号
        if self.pos > 0:  # 保留原生字段：持仓
            可选信号.append("平多")
        if self.pos < 0:
            可选信号.append("平空")

        # 开仓概率归一化（避免权重和大于1）
        总权重 = self.开多概率权重 + self.开空概率权重
        开多权重 = self.开多概率权重 / 总权重 if 总权重 > 0 else 0.7
        开空权重 = self.开空概率权重 / 总权重 if 总权重 > 0 else 0.3

        # 按权重生成开仓信号
        随机值 = random.random()
        开仓信号 = "开多" if 随机值 < 开多权重 else "开空"
        可选信号.append(开仓信号)

        # 随机选择最终交易信号
        return random.choice(可选信号)

    # -------------------------------------------------------------------------
    # 模块4：交易核心（校验+执行）｜fuwen核心API封装，通用可复用
    # -------------------------------------------------------------------------
    def 交易规则校验(self, 交易类型: str, 原始手数: int) -> dict:
        """交易规则统一校验｜防超仓/超平/无持仓操作｜返回标准化校验结果"""
        校验结果 = {
            "校验通过": False,
            "交易API": None,
            "统计字段": None,
            "交易描述": None,
            "实际委托手数": 0,
            "失败原因": ""
        }
        # 开多校验：不超过单方向最大持仓
        if 交易类型 == "开多":
            校验结果.update(
                {"交易API": self.buy, "统计字段": "统计_开多", "交易描述": "开多", "实际委托手数": 原始手数})
            if self.pos < self.单方向最大持仓:
                校验结果["校验通过"] = True
            else:
                校验结果["失败原因"] = f"多仓{self.pos}手，已达最大持仓{self.单方向最大持仓}手"
        # 开空校验：不超过单方向最大持仓
        elif 交易类型 == "开空":
            校验结果.update(
                {"交易API": self.short, "统计字段": "统计_开空", "交易描述": "开空", "实际委托手数": 原始手数})
            if self.pos > -self.单方向最大持仓:
                校验结果["校验通过"] = True
            else:
                校验结果["失败原因"] = f"空仓{abs(self.pos)}手，已达最大持仓{self.单方向最大持仓}手"
        # 平多校验：有持仓+防超平
        elif 交易类型 == "平多":
            实际手数 = min(原始手数, self.pos)
            校验结果.update(
                {"交易API": self.sell, "统计字段": "统计_平多", "交易描述": "平多", "实际委托手数": 实际手数})
            if self.pos > 0:
                校验结果["校验通过"] = True
            else:
                校验结果["失败原因"] = f"当前无多头持仓，持仓为{self.pos}手"
        # 平空校验：有持仓+防超平
        elif 交易类型 == "平空":
            实际手数 = min(原始手数, abs(self.pos))
            校验结果.update(
                {"交易API": self.cover, "统计字段": "统计_平空", "交易描述": "平空", "实际委托手数": 实际手数})
            if self.pos < 0:
                校验结果["校验通过"] = True
            else:
                校验结果["失败原因"] = f"当前无空头持仓，持仓为{self.pos}手"
        # 未知交易类型
        else:
            校验结果["失败原因"] = f"不支持的交易类型：{交易类型}，仅支持[开多/开空/平多/平空]"
        return 校验结果

    def 执行交易(self, 交易类型: str, bar: BarData) -> None:
        """通用交易执行函数｜仅执行委托，所有规则在交易规则校验中实现"""
        委托价格 = bar.close_price
        原始手数 = self.单次交易手数
        # K线基础信息
        K线信息 = (
            f"合约：{self.vt_symbol} | 时间：{bar.datetime.strftime('%Y-%m-%d %H:%M:%S')} | "
            f"收盘价：{bar.close_price} | 当前持仓：{self.pos}手 | 最大持仓：{self.单方向最大持仓}手"
        )
        # 执行交易校验
        校验结果 = self.交易规则校验(交易类型, 原始手数)
        if not 校验结果["校验通过"]:
            失败日志 = f"{K线信息} | 【{校验结果['交易描述']}失败】：{校验结果['失败原因']}"
            self.write_log(f"【交易失败】{失败日志}")
            print(f"【交易失败】{失败日志}")
            self.统计_无操作 += 1
            return
        # 提取校验后参数
        交易API = 校验结果["交易API"]
        统计字段 = 校验结果["统计字段"]
        交易描述 = 校验结果["交易描述"]
        实际手数 = 校验结果["实际委托手数"]
        # 更新统计
        setattr(self, 统计字段, getattr(self, 统计字段) + 1)
        当前次数 = getattr(self, 统计字段)
        # 发送委托（fuwen核心交易API）
        委托编号 = 交易API(price=委托价格, volume=实际手数)
        # 写入成功日志
        成功日志 = (
            f"{K线信息} | 【{交易描述}成功】第{当前次数}次 | "
            f"委托价格：{委托价格} | 委托手数：{实际手数} | 委托编号：{委托编号[:8]}..."
        )
        self.write_log(f"【委托发送】{成功日志}")
        print(f"【委托发送】{成功日志}")

    # -------------------------------------------------------------------------
    # 模块5：委托/成交回调（fuwen核心-实时反馈委托/成交状态）
    # -------------------------------------------------------------------------
    def on_trade(self, trade: TradeData) -> None:
        """成交回调（fuwen原生接口）｜回测/实盘/模拟通用｜成交后唯一触发入口"""
        成交日志 = (
            f"【成交确认】{self.vt_symbol} | 成交号：{trade.tradeid[:8]}... | "
            f"方向：{trade.direction.name} | 开平：{trade.offset.name} | "
            f"价格：{trade.price} | 手数：{trade.volume} "
        )
        self.write_log(成交日志)
        print(成交日志)
        self.put_event()  # 成交后立即更新UI持仓

    def on_order(self, order: OrderData) -> None:
        """委托回调（fuwen原生接口）｜委托状态变化时触发｜仅处理异常状态"""
        if order.status.name in ["CANCELLED", "REJECTED"]:
            委托日志 = f"【委托异常】{order.orderid[:8]}... | 合约：{self.vt_symbol} | 状态：{order.status.name}"
            self.write_log(委托日志)
            print(委托日志)

    # -------------------------------------------------------------------------
