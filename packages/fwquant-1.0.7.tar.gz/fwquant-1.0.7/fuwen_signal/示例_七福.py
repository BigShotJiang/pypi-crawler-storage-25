import pandas as pd

from fuwen_signal.fw_signal.信号工厂 import 七福

def main():
    # 信号工厂
    result_七福 = 七福.演示_样例()
    print(f"result_福纹信号_响应:{result_七福}")
    pass


if __name__ == '__main__':
    main()
