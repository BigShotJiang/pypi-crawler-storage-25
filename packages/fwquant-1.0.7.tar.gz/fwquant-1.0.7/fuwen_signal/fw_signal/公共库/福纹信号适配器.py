from enum import unique, Enum
from typing import Optional, Dict, Any

import pandas as pd


class 信号结果_枚举(Enum):
    看多 = "看多"
    看空 = "看空"
    无信号 = "无信号"


福纹信号_请求_模板 = FUWEN_SIGNAL_REQUEST_TEMPLATE = {
    "标的代码": "HSIMain.GLOBAL",
    "当前价": 100.0,
    "看多价": 150.0,
    "看空价": 50.0,
    "行情数据": {
        "k线数据": pd.DataFrame(columns=["时间", "开盘价", "收盘价", "最高价", "最低价", "成交量"]),  # 指定列名
        "实时行情": pd.DataFrame(columns=["时间", "最新价", "买一价", "卖一价", "成交量"]),
    },

    "请求时间": "2023-08-01 12:00:00",
    "有效时间": "9999m",
    "用户自定义": "内容原样返回，方便异步处理",
}
print(f"result_config:{福纹信号_请求_模板}")

# 返回信号结构
福纹信号_响应_模板 = FUWEN_SIGNAL_RESPONSE_TEMPLATE = {
    "success": True,
    "msg": "",

    "标的代码": "123",
    "信号结果": "看多",
    "信号概率":
        {"先到达看多价概率": 40.0,
         "先到达看空价概率": 34.0,
         "未达价概率": 26.0,
         "置信度": 0.8,
         },

    "响应时间": "2023-08-01 12:00:00",

    "用户自定义": "内容原样返回，方便异步处理",
}


class 福纹信号_请求类:
    def __init__(self, 标的代码: str = "HSIMain.GLOBAL",
                 当前价: float = 100.0,
                 看多价: float = 150.0,
                 看空价: float = 50.0,
                 请求时间: Optional[str] = None,
                 有效时间: str = "9999m",
                 用户自定义: str = "内容原样返回，方便异步处理",
                 行情数据: Optional[pd.DataFrame] = None,
                 ):
        self.标的代码 = 标的代码
        self.当前价 = 当前价
        self.看多价 = 看多价
        self.看空价 = 看空价
        self.请求时间 = 请求时间
        self.有效时间 = 有效时间
        self.用户自定义 = 用户自定义
        self.行情数据 = 行情数据

    def 转为字典(self) -> Dict[str, Any]:
        """转换为字典格式（兼容原有使用方式）"""
        return {
            "标的代码": self.标的代码,
            "当前价": self.当前价,
            "看多价": self.看多价,
            "看空价": self.看空价,
            "请求时间": self.请求时间,
            "有效时间": self.有效时间,
            "行情数据": self.行情数据,
            "用户自定义": self.用户自定义,
        }


class 福纹信号_响应类:
    def __init__(self, 标的代码: str = "HSIMain.GLOBAL",
                 信号结果: 信号结果_枚举 = 信号结果_枚举.看多,
                 信号概率=None,
                 响应时间: Optional[str] = None,
                 用户自定义: str = "内容原样返回，方便异步处理",
                 data: Optional[Dict[str, Any]] = None,
                 success: bool = True,
                 msg: str = ""
                 ):
        if 信号概率 is None:
            信号概率 = {"先到达看多价概率": 40.0,
                        "先到达看空价概率": 34.0,
                        "未达价概率": 26.0,
                        "置信度": 0.8,
                        }
        self.标的代码 = 标的代码
        self.信号结果 = 信号结果
        self.信号概率 = 信号概率
        self.响应时间 = 响应时间
        self.用户自定义 = 用户自定义
        self.data = data
        self.success = success
        self.msg = msg

    def 转为字典(self) -> Dict[str, Any]:
        """转换为字典格式（兼容原有使用方式）"""
        return {
            "标的代码": self.标的代码,
            "信号结果": self.信号结果,
            "信号概率": self.信号概率,
            "响应时间": self.响应时间,
            "用户自定义": self.用户自定义,
            "data": self.data,
            "success": self.success,
            "msg": self.msg,
        }


if __name__ == '__main__':
    print(f"查看类 实例：")
    res_福纹信号_请求 = 福纹信号_请求类(**FUWEN_SIGNAL_REQUEST_TEMPLATE)
    print(f"福纹信号_请求 实例：{res_福纹信号_请求.转为字典()}")
    res_福纹信号_响应 = 福纹信号_响应类(**福纹信号_响应_模板)
    print(f"福纹信号_响应 实例：{res_福纹信号_响应.转为字典()}")
    pass
