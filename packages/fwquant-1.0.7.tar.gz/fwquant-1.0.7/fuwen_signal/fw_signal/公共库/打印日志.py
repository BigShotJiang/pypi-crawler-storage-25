class 自定义控制台日志记录器:
    """自定义控制台日志对象：支持分级打印+级别过滤，完全兼容fuwen接口"""
    # 定义日志级别及优先级（数字越小，级别越低）
    LOG_LEVELS = {
        "DEBUG": 10,
        "INFO": 20,
        "WARNING": 30,
        "ERROR": 40
    }

    def __init__(self, name: str = "fuwen_adaptor", level: str = "INFO"):
        self.current_level = None
        self.current_level_name = None
        self.name = name
        # 初始化打印级别（默认INFO，可通过set_level动态修改）
        self.set_level(level)

    def set_level(self, level: str):
        """设置日志过滤级别：仅打印≥该级别的日志"""
        # 校验级别合法性，非法级别默认设为INFO
        if level.upper() not in self.LOG_LEVELS:
            print(f"日志级别 {level} 不合法，默认使用 INFO 级别")
            self.current_level = self.LOG_LEVELS["INFO"]
            self.current_level_name = "INFO"
        else:
            self.current_level = self.LOG_LEVELS[level.upper()]
            self.current_level_name = level.upper()
        # 控制台提示（可选）
        print(f"日志级别已设置为：{self.current_level_name}（仅打印≥该级别的日志）")

    def _should_print(self, level: str) -> bool:
        """内部判断：该级别日志是否需要打印"""
        return self.LOG_LEVELS[level] >= self.current_level

    def _print_log(self, msg: str, level: str):
        """内部核心方法：级别过滤 + 控制台打印"""
        if not self._should_print(level):
            return  # 级别不够，跳过打印

        import datetime
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # 颜色配置（可选，去掉则注释/删除颜色相关代码）
        level_color = {
            "DEBUG": "\033[37m",  # 灰色
            "INFO": "\033[32m",  # 绿色
            "WARNING": "\033[33m",  # 黄色
            "ERROR": "\033[31m"  # 红色
        }.get(level, "\033[0m")
        reset_color = "\033[0m"

        # 仅输出到控制台
        print(f"{level_color}[{timestamp}] [{self.name}] [{level}] {msg}{reset_color}")

    # 兼容fuwen原有分级方法
    def debug(self, msg: str):
        self._print_log(msg, "DEBUG")

    def info(self, msg: str):
        self._print_log(msg, "INFO")

    def warning(self, msg: str):
        self._print_log(msg, "WARNING")

    def error(self, msg: str):
        self._print_log(msg, "ERROR")

    # 保留原write_log方法（默认INFO级别）
    def write_log(self, msg: str):
        self._print_log(msg, "INFO")


# 创建全局logger对象，直接替换原fuwen的logger
logger = 自定义控制台日志记录器(level="INFO")  # DEBUG       INFO   WARNING   ERROR
