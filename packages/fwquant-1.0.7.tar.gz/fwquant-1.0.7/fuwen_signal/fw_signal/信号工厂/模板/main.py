import random

from fuwen_signal.fw_signal.公共库.福纹信号适配器 import 信号结果_枚举


def 模板信号(信号列表: list = []) -> 信号结果_枚举:
    if len(信号列表) < 2:
        信号列表 = list(信号结果_枚举)
    _result = random.choice(信号列表)
    return _result


if __name__ == '__main__':
    result = 模板信号(["看多", "看空", "看空", "看空", "看空"])
    print(f"模板信号: {result}")
