import numpy as np

from fuwen_signal.fw_signal.公共库.福纹信号适配器 import 信号结果_枚举

import numpy as np
from fuwen_signal.fw_signal.公共库.福纹信号适配器 import 信号结果_枚举


def 双均线信号(价格列表: list | np.ndarray, 快线周期: int = 10, 慢线周期: int = 30):
    # 优化点1：统一数据类型（支持list/np.ndarray，避免重复转换）
    if isinstance(价格列表, list):
        价格数组 = np.array(价格列表)
    else:
        价格数组 = 价格列表  # 复用已有数组，减少内存拷贝

    # 优化点2：强化边界校验（空数组/非数值型直接返回无信号）
    if len(价格数组) == 0 or not np.issubdtype(价格数组.dtype, np.number):
        return 信号结果_枚举.无信号

    # 优化点3：精简最小数据量计算（移除冗余变量）
    最小数据量 = max(快线周期, 慢线周期) + 1
    if len(价格数组) < 最小数据量:
        return 信号结果_枚举.无信号

    # 优化点4：复用数组切片，减少重复计算（用[-n:]代替多次切片）
    当前快线值 = np.mean(价格数组[-快线周期:])
    当前慢线值 = np.mean(价格数组[-慢线周期:])
    上一快线值 = np.mean(价格数组[-快线周期 - 1:-1])
    上一慢线值 = np.mean(价格数组[-慢线周期 - 1:-1])

    # 优化点5：精简条件判断（合并逻辑，减少分支）
    金叉 = (上一快线值 <= 上一慢线值) and (当前快线值 > 当前慢线值)
    死叉 = (上一快线值 >= 上一慢线值) and (当前快线值 < 当前慢线值)

    if 金叉:
        return 信号结果_枚举.看多
    elif 死叉:
        return 信号结果_枚举.看空
    else:
        return 信号结果_枚举.无信号  # 显式返回，避免隐式None


if __name__ == '__main__':
    价格列表 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110]
    # 快线周期=10, 慢线周期=30 用函数生成若干 N个 价格列表
    result = 双均线信号(价格列表=价格列表, 快线周期=10, 慢线周期=30)
    print(f"双均线信号: {result}")
