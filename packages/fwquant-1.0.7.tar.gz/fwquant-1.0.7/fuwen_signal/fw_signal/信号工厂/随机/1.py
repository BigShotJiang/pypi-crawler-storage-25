import sys
import os
import random

# ========== 强制修复路径（核心代码） ==========
# 1. 硬编码项目根目录（根据你的实际路径确认）
PROJECT_ROOT = "/Users/yanhuang/github/fwquant/fuwen_signal"
# 2. 确保路径是绝对路径
PROJECT_ROOT = os.path.abspath(PROJECT_ROOT)
# 3. 强制添加到sys.path首位（优先级最高）
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# ========== 调试信息（帮助确认路径） ==========
print("=== 路径调试信息 ===")
print(f"Python版本: {sys.version}")
print(f"运行平台: {sys.platform}")
print(f"项目根目录: {PROJECT_ROOT}")
print(f"根目录是否存在: {os.path.exists(PROJECT_ROOT)}")
print(f"main目录是否存在: {os.path.exists(os.path.join(PROJECT_ROOT, 'fw_signal'))}")
print(f"公共库目录是否存在: {os.path.exists(os.path.join(PROJECT_ROOT, 'fw_signal', '公共库'))}")
print(f"福纹信号适配器是否存在: {os.path.exists(os.path.join(PROJECT_ROOT, 'fw_signal', '公共库', '福纹信号适配器.py'))}")

# ========== 安全导入（带异常处理） ==========
try:
    # 先尝试导入main包
    import fw_frame
    print(f"\n✅ main包导入成功: {fw_frame.__file__}")

    # 再导入具体模块
    from fuwen_signal.fw_signal.公共库.福纹信号适配器 import 信号结果_枚举
    print(f"✅ 信号结果_枚举导入成功: {信号结果_枚举}")

except Exception as e:
    print(f"\n❌ 导入失败: {type(e).__name__}: {e}")
    # 打印详细的sys.path，帮助排查
    print(f"\nsys.path 完整列表:")
    for i, path in enumerate(sys.path):
        print(f"  {i}: {path}")
    raise  # 抛出异常，终止程序

# ========== 业务逻辑 ==========
def 随机信号(信号列表: list = []) -> 信号结果_枚举:
    if len(信号列表) < 2:
        信号列表 = list(信号结果_枚举)
    result = random.choice(信号列表)
    return result

# ========== 主程序 ==========
if __name__ == '__main__':
    print("\n=== 随机信号生成 ===")
    # 注意：传入的参数要和信号结果_枚举的取值匹配
    # 如果信号结果_枚举是枚举类，应该用枚举成员，而不是字符串
    # 示例：result = 随机信号([信号结果_枚举.看多, 信号结果_枚举.看空])
    result = 随机信号(["看多", "看空", "看空", "看空", "看空"])
    print(f"随机信号结果: {result}")