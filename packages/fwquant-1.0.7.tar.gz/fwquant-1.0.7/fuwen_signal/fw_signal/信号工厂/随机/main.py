import random

from fuwen_signal.fw_signal.公共库.福纹信号适配器 import 信号结果_枚举


def 随机信号(信号列表: list = [], 随机种子: int = None) -> 信号结果_枚举:
    # 仅当明确提供了随机种子时才设置,random模块默认就是真随机
    if 随机种子 is not None:
        random.seed(随机种子)
        print(f"使用固定随机种子: {随机种子} (可复现)")

    if len(信号列表) < 2:
        信号列表 = list(信号结果_枚举)
    print(f"随机种子: {随机种子}")
    result = random.choice(信号列表)
    return result


if __name__ == '__main__':
    result = 随机信号(["看多", "看空", "看空", "看空", "看空"])
    print(f"随机信号: {result}")
