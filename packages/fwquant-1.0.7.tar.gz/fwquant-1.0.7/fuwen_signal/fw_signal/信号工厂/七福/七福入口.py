from datetime import datetime

import pandas as pd

from fuwen_signal.fw_signal.信号工厂.七福.平仓规则.平仓信号检测 import 平仓检测
from fuwen_signal.fw_signal.信号工厂.七福.开仓规则.开仓信号判断 import 开仓信号
from fuwen_signal.fw_signal.信号工厂.七福.配置.默认 import 七福默认参数配置
from fuwen_signal.fw_signal.公共库.福纹信号适配器 import 福纹信号_响应类, 信号结果_枚举


class 七福信号引擎:
    # ===================== 核心配置字典 =====================
    _七福默认参数配置 = 七福默认参数配置

    def __init__(self, 参数: dict):
        # 原始参数字典（保留，兼容老代码）
        self._参数 = {}
        # 【方案2优化】核心字段全部绑定为实例变量，不再反复读字典
        self._标的代码: str = ""
        self._历史k线: pd.DataFrame = pd.DataFrame()
        self._当前k线: pd.DataFrame | pd.Series = None
        self._当前k线时间: str = ""
        self._历史k线_全量_回测: pd.DataFrame = pd.DataFrame()
        self._缓存k线_最大保存数量: int = 0
        self._n个周期内查找低点 = None

        # 统一初始化参数（自动绑定到变量）
        self.设置参数(参数)

    ############################ 主开仓函数 ###############################
    def 开仓检测(self, 参数=None):
        if 参数 is None:
            参数 = self._参数

        res = 开仓信号(参数=参数)
        return res

    def 平仓判断(self, 参数=None):
        if 参数 is None:
            参数 = self._参数
        res = 平仓检测(参数=参数)
        return res

    @property
    def 七福信号(self) -> 福纹信号_响应类:
        # 初始化
        信号概率 = {"先到达看多价概率": 0.0, "先到达看空价概率": 0.0, "未达价概率": 0.0, "置信度": 50.0, }
        原因msg = ""
        用户自定义 = ""
        data = {}
        响应时间 = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        信号结果 = 信号结果_枚举.无信号
        msg = ""

        # 请求信号配置
        res_开仓检测 = self.开仓检测()
        res_平仓检测 = self.平仓判断()

        id_开仓 = float(res_开仓检测.get('id', 0))
        if id_开仓 > 0:
            if id_开仓 in [1001, 1003]:
                信号结果 = 信号结果_枚举.看多
            if id_开仓 in [1002, 1004]:
                信号结果 = 信号结果_枚举.看空
            原因msg = res_开仓检测.get('判断详情', {}).get('最终说明', '')

        id_平仓 = float(res_平仓检测.get('id', 0))
        if id_平仓 > 0:
            if id_平仓 in [2001, 2003, 2005, 2007, 2009, 2011]:
                信号结果 = 信号结果_枚举.看多
            if id_平仓 in [2002, 2004, 2006, 2008, 2010, 2012]:
                信号结果 = 信号结果_枚举.看空
            原因msg = res_平仓检测.get('判断详情', {}).get('最终说明', '')

        if 信号结果 == 信号结果_枚举.看多:
            信号概率 = {"先到达看多价概率": 100.0, "先到达看空价概率": 0.0, "未达价概率": 0.0, "置信度": 50.0, }
        if 信号结果 == 信号结果_枚举.看空:
            信号概率 = {"先到达看多价概率": 0.0, "先到达看空价概率": 100.0, "未达价概率": 0.0, "置信度": 50.0, }

        msg = 原因msg
        data['平仓检测'] = res_平仓检测
        data['开仓检测'] = res_开仓检测

        result_福纹信号_响应 = 福纹信号_响应类(
            标的代码=self._标的代码,
            信号结果=信号结果,
            信号概率=信号概率,
            响应时间=响应时间,
            用户自定义=用户自定义,
            data=data,
            success=True,
            msg=msg
        )
        return result_福纹信号_响应

    def 七福参数配置样例(self):
        result = self._七福默认参数配置.copy()
        return result

    def 设置参数(self, 参数: dict):
        """
        【优化核心】设置参数时，自动同步到实例变量
        兼容老代码，同时使用方案2更安全
        """
        if 参数 is None:
            参数 = {}

        # 1. 保留原始字典（兼容老代码）
        self._参数 = 参数

        # 2. 【关键优化】自动绑定到实例变量，后续直接用 self.变量
        self._标的代码 = self._参数.get('标的代码', '')
        self._历史k线 = self._参数.get('历史k线', pd.DataFrame())
        self._当前k线 = self._参数.get('当前k线', None)
        self._当前k线时间 = self._参数.get('当前k线时间', '')
        self._历史k线_全量_回测 = self._参数.get('历史k线_全量_回测', pd.DataFrame())
        self._缓存k线_最大保存数量 = self._参数.get('缓存k线_最大保存数量', 120)

        # 返回值保持不变
        return self._参数.copy() if isinstance(self._参数, dict) else self._参数

    def 获取参数(self):
        return self._参数.copy()

    def 设置历史k线(self, 历史k线: pd.DataFrame):
        self._历史k线 = 历史k线
        self._参数['历史k线'] = self._历史k线

    def 追加历史k线(self, 新k线: pd.DataFrame):
        """【优化】使用实例变量，不再直接读写字典"""
        self._历史k线 = pd.concat([self._历史k线, 新k线], axis=0)
        self._历史k线 = self._历史k线.iloc[-self._缓存k线_最大保存数量:]

        # 同步回参数字典（兼容老代码）
        self._参数['历史k线'] = self._历史k线

    def 更新当前k线(self, 当前k线: pd.Series):
        """【优化】使用实例变量，更安全"""
        self._当前k线 = 当前k线
        if 当前k线.__len__() > 0:
            if 'time_key' in self._当前k线.columns:
                self._当前k线时间 = self._当前k线['time_key'].iloc[0]
            elif 'datetime' in self._当前k线.columns:
                self._当前k线时间 = self._当前k线['datetime'].iloc[0]
            else:
                # 没有时间字段时的安全处理
                self._当前k线时间 = None
        # 同步字典
        self._参数['当前k线'] = self._当前k线
        self._参数['当前k线时间'] = self._当前k线时间

    def 更新历史k线_全量_回测(self, 全量历史k线: pd.DataFrame):
        """【优化】实例变量读写"""
        self._历史k线_全量_回测 = 全量历史k线
        self._参数['历史k线_全量_回测'] = self._历史k线_全量_回测

    def 设置当前k线_回测(self, 当前k线: pd.DataFrame):
        """【优化】实例变量读写，逻辑完全不变"""
        self._当前k线 = 当前k线

        # 提取时间逻辑完全保留
        try:
            self._当前k线时间 = 当前k线.index[0]
        except (IndexError, AttributeError):
            try:
                self._当前k线时间 = 当前k线.name
            except AttributeError:
                if 'time_key' in 当前k线.columns:
                    self._当前k线时间 = 当前k线['time_key'].iloc[0]
                elif 当前k线.index.name == 'time_key':
                    self._当前k线时间 = 当前k线.index[0]
                else:
                    raise ValueError("无法从当前k线中提取有效的time_key时间")

        # 获取历史K线
        self._历史k线 = self._获取历史k线_回测(
            全量历史k线=self._历史k线_全量_回测,
            当前k线时间=self._当前k线时间,
            周期数=120
        )

        # 同步回字典（兼容老代码）
        self._参数['当前k线'] = self._当前k线
        self._参数['当前k线时间'] = self._当前k线时间
        self._参数['历史k线'] = self._历史k线

    def _获取历史k线_回测(self, 全量历史k线: pd.DataFrame, 当前k线时间: str, 周期数: int = 120):
        """
        逻辑完全不变，保持兼容
        """
        if 全量历史k线.empty:
            return pd.DataFrame()

        if 全量历史k线.index.name == 'time_key':
            时间列 = 全量历史k线.index.astype(str)
        elif 'time_key' in 全量历史k线.columns:
            时间列 = 全量历史k线['time_key'].astype(str)
        else:
            raise KeyError("全量历史k线必须包含time_key（索引名或列名）")

        当前k线时间_str = str(当前k线时间)
        筛选掩码 = 时间列 < 当前k线时间_str
        历史k线 = 全量历史k线[筛选掩码].copy()

        if len(历史k线) <= 周期数:
            返回k线 = 历史k线
        else:
            返回k线 = 历史k线.iloc[-周期数:]

        返回k线 = 返回k线.reset_index(drop=True)
        return 返回k线


def 七福信号(参数=None):
    if 参数 is None:
        参数 = 七福默认参数配置.copy()
    七福信号实例 = 七福信号引擎(参数=参数)
    返回信号 = 七福信号实例.七福信号
    return 返回信号


def main():
    # 准备
    七福 = 七福信号引擎(参数={})
    result_七福参数配置样例 = 七福.七福参数配置样例()
    k线数据路径 = f"temp/k线.csv"
    k线数据_原文 = pd.read_csv(k线数据路径, index_col=0)
    result_七福参数配置样例['历史k线'] = pd.DataFrame(k线数据_原文)
    七福.设置参数(result_七福参数配置样例)
    print(f"result_七福参数配置样例:{result_七福参数配置样例}")

    # 信号工厂
    result_福纹信号_响应 = 七福信号(参数=result_七福参数配置样例)
    print(f"result_福纹信号_响应:{result_福纹信号_响应.转为字典()}")


if __name__ == '__main__':
    main()
