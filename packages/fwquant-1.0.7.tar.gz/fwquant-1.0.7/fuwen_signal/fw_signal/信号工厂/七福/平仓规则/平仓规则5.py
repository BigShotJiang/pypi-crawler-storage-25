################################# 平仓规则5（MACD背离 + 价格跌破MA5或连续阴线）#################################
import traceback

from fuwen_signal.fw_signal.信号工厂.七福.公共.公用函数 import RET_OK, 平仓方向, logger, 获取回测K线, 计算局部MACD, \
    计算MA, 计算MACD
from fuwen_signal.fw_signal.信号工厂.七福.公共.计算高低点 import 计算高点, 计算低点
from fuwen_signal.fw_signal.信号工厂.七福.公共.公共常量 import 信号返回_空


def 平仓规则5_MACD背离MA5平仓(参数=None):
    信号返回 = 信号返回_空.copy()
    res = 信号返回

    res = 平仓规则5_MACD背离MA5平仓_old(参数=参数)
    # res = 平仓规则5_MACD背离MA5平仓_doubao(参数=参数)
    # res = 平仓规则5_MACD背离MA5平仓_deepseek(参数=参数)
    # res = 平仓规则5_MACD背离MA5平仓_chuan(参数=参数)

    return res


################################# 平仓规则5（MACD背离 + 价格跌破MA5或连续阴线）#################################
def 平仓规则5_MACD背离MA5平仓_old(参数=None):
    """
    平仓规则5（精简版）：
    - 平多：顶背离（价格新高+DIF未新高） + 价格跌破MA5
    - 平空：底背离（价格新低+DIF未新低） + 价格突破MA5
    优化点：
    1. 统一参数/返回格式，与规则1-4对齐
    2. 精简MACD计算逻辑，移除冗余日志频率控制
    3. 增强边界校验，解耦平仓执行逻辑
    4. 保留核心背离判断和MA5突破逻辑
    """
    # 初始化标准返回信号
    信号返回 = 信号返回_空.copy()

    # 提取核心参数
    当前仓位 = 参数.get('仓位', None)
    当前K线时间 = 参数.get('当前k线时间', None)
    均线快周期 = 参数.get('均线快周期', 5)  # 默认MA5
    推荐平仓数量 = abs(当前仓位['持仓数量'])

    try:
        # ===================== 数据获取与预处理 =====================
        # 获取1分钟K线数据（60根）
        k_ret, k_data = 获取回测K线(参数=参数, 数量=60, 周期="K_1M")
        if k_ret != RET_OK:
            信号返回['原因'] = f"【平仓规则5】获取1分钟K线失败: {k_data}"
            return 信号返回

        # 数据清洗（移除未完成K线+时间排序）
        k_data = k_data.copy()
        if len(k_data) > 1:
            k_data = k_data.iloc[:-1]  # 去掉最后一根未完成K线
        k_data = k_data.sort_values('time_key')

        # 基础数据量校验
        if len(k_data) < 5:
            信号返回['原因'] = f"【平仓规则5】K线数据不足 | 当前{len(k_data)}根（需至少5根）"
            return 信号返回

        # 提取价格序列
        开盘价序列 = k_data['open'].values
        最高价序列 = k_data['high'].values
        最低价序列 = k_data['low'].values
        收盘价序列 = k_data['close'].values
        最新收盘价 = 收盘价序列[-1] if len(收盘价序列) > 0 else 0
        推荐平仓价格 = 最新收盘价

        # ===================== 高低点与MACD匹配 =====================
        # 计算高低点序列
        高点序列 = 计算高点(最高价序列, 最低价序列, 收盘价序列, ma_period=5)
        低点序列 = 计算低点(最高价序列, 最低价序列, 收盘价序列, ma_period=5)

        # 提取高低点索引并计算对应MACD
        高点索引列表 = [i for i, val in enumerate(高点序列) if val == 1]
        低点索引列表 = [i for i, val in enumerate(低点序列) if val == 1]

        # 为高低点匹配MACD值
        带MACD的高点列表 = []
        for idx in 高点索引列表:
            dif, dea, macd = 计算局部MACD(收盘价序列, idx)
            if dif is not None:
                带MACD的高点列表.append({
                    'index': idx,
                    'price': 最高价序列[idx],
                    'dif': dif,
                    'dea': dea,
                    'macd': macd
                })

        带MACD的低点列表 = []
        for idx in 低点索引列表:
            dif, dea, macd = 计算局部MACD(收盘价序列, idx)
            if dif is not None:
                带MACD的低点列表.append({
                    'index': idx,
                    'price': 最低价序列[idx],
                    'dif': dif,
                    'dea': dea,
                    'macd': macd
                })

        # 按索引倒序排列（最新的在前）
        带MACD的高点列表.sort(key=lambda x: x['index'], reverse=True)
        带MACD的低点列表.sort(key=lambda x: x['index'], reverse=True)

        # ===================== MA5计算 =====================
        ma5序列 = 计算MA(收盘价序列=收盘价序列, 周期=均线快周期)
        if len(ma5序列) == 0:
            信号返回['原因'] = f"【平仓规则5】MA5计算失败，收盘价序列长度不足"
            return 信号返回

        ma5最新值 = ma5序列.iloc[-1] if hasattr(ma5序列, 'iloc') else ma5序列[-1]
        价格跌破MA5 = 最新收盘价 < ma5最新值
        价格突破MA5 = 最新收盘价 > ma5最新值

        # ===================== 多头平仓（顶背离+跌破MA5） =====================
        if 当前仓位['持仓数量'] > 0:
            顶背离触发 = False
            背离详情 = ""

            # 检查顶背离（至少2个带MACD的高点）
            if len(带MACD的高点列表) >= 2:
                最近高点 = 带MACD的高点列表[0]
                前高点 = 带MACD的高点列表[1]

                价格新高 = 最近高点['price'] > 前高点['price']
                DIF新高 = 最近高点['dif'] > 前高点['dif']

                if 价格新高 and not DIF新高:
                    顶背离触发 = True
                    背离详情 = (f"价格新高({最近高点['price']:.2f} > {前高点['price']:.2f}) "
                                f"但DIF走低({最近高点['dif']:.6f} ≤ {前高点['dif']:.6f})")

            # 平仓条件判断
            if 顶背离触发 and 价格跌破MA5:
                信号返回 = {
                    'id': 2012,
                    '信号工厂': 平仓方向.平多,
                    '推荐平仓方向': 平仓方向.平多,
                    '推荐平仓数量': 推荐平仓数量,
                    '推荐平仓价格': 推荐平仓价格,
                    '原因': (
                        f"【平仓规则5】触发平多条件：顶背离({背离详情}) + 价格跌破MA5 "
                        f"({最新收盘价:.2f} < {ma5最新值:.2f})"
                    )
                }
            else:
                未满足原因 = []
                if not 顶背离触发:
                    未满足原因.append("顶背离条件未触发")
                if not 价格跌破MA5:
                    未满足原因.append(f"价格未跌破MA5({最新收盘价:.2f} ≥ {ma5最新值:.2f})")
                信号返回['原因'] = f"【平仓规则5】平多条件未满足：{' | '.join(未满足原因)}"

        # ===================== 空头平仓（底背离+突破MA5） =====================
        elif 当前仓位['持仓数量'] < 0:
            底背离触发 = False
            背离详情 = ""

            # 检查底背离（至少2个带MACD的低点）
            if len(带MACD的低点列表) >= 2:
                最近低点 = 带MACD的低点列表[0]
                前低点 = 带MACD的低点列表[1]

                价格新低 = 最近低点['price'] < 前低点['price']
                DIF新低 = 最近低点['dif'] < 前低点['dif']

                if 价格新低 and not DIF新低:
                    底背离触发 = True
                    背离详情 = (f"价格新低({最近低点['price']:.2f} < {前低点['price']:.2f}) "
                                f"但DIF走高({最近低点['dif']:.6f} ≥ {前低点['dif']:.6f})")

            # 平仓条件判断    ----20260305 modiing
            if 底背离触发 and 价格突破MA5:
                信号返回 = {
                    'id': 2011,
                    '信号工厂': 平仓方向.平空,
                    '推荐平仓方向': 平仓方向.平空,
                    '推荐平仓数量': 推荐平仓数量,
                    '推荐平仓价格': 推荐平仓价格,
                    '原因': (
                        f"【平仓规则5】触发平空条件：底背离({背离详情}) + 价格突破MA5 "
                        f"({最新收盘价:.2f} > {ma5最新值:.2f})"
                    )
                }
            else:
                未满足原因 = []
                if not 底背离触发:
                    未满足原因.append("底背离条件未触发")
                if not 价格突破MA5:
                    未满足原因.append(f"价格未突破MA5({最新收盘价:.2f} ≤ {ma5最新值:.2f})")
                信号返回['原因'] = f"【平仓规则5】平空条件未满足：{' | '.join(未满足原因)}"

        # 无持仓情况
        else:
            信号返回['原因'] = f"【平仓规则5】条件未满足：持仓数量为0，不能平仓"

        return 信号返回

    # 标准化异常处理
    except Exception as e:
        错误信息 = f"【平仓规则5】执行错误 |  时间：{当前K线时间} | 错误：{str(e)},traceback:{traceback.format_exc()}"
        logger.error(错误信息)
        print("错误信息:", 错误信息)
        信号返回['id'] = -1
        信号返回['原因'] = 错误信息
        return 信号返回


################################# 平仓规则5（MACD背离 + 价格跌破MA5或连续阴线）#################################
def 平仓规则5_MACD背离MA5平仓_doubao(参数=None):
    """
    平仓规则5（优化版）：
    - 平多：顶背离（严格价格新高+DIF明显未新高） + 价格跌破MA5 或 连续3根阴线
    - 平空：底背离（严格价格新低+DIF明显未新低） + 价格突破MA5 或 连续3根阳线
    核心优化：
    1. 背离判断增加阈值过滤，避免微小波动误判
    2. 补充连续阴阳线验证，提升平仓信号可靠性
    3. 优化高低点匹配逻辑，只取有效周期内的高低点
    4. 增强数据校验和异常值处理，避免极端值影响
    5. 优化MA5计算和突破/跌破判断的时效性
    """
    # 初始化标准返回信号
    信号返回 = 信号返回_空.copy()

    # 提取核心参数
    当前仓位 = 参数.get('仓位', None)
    当前K线时间 = 参数.get('当前k线时间', None)
    均线快周期 = 参数.get('均线快周期', 5)  # 默认MA5
    背离阈值 = 参数.get('背离阈值', 0.001)  # DIF背离最小差值阈值
    连续K线数 = 参数.get('连续K线数', 3)  # 连续阴阳线判断数量
    推荐平仓数量 = abs(当前仓位['持仓数量']) if 当前仓位 else 0

    try:
        # ===================== 数据获取与预处理 =====================
        # 获取1分钟K线数据（60根），确保有足够的背离判断周期
        k_ret, k_data = 获取回测K线(参数=参数, 数量=60, 周期="K_1M")
        if k_ret != RET_OK or k_data.empty:
            信号返回['原因'] = f"【平仓规则5】获取1分钟K线失败: {k_data}"
            return 信号返回

        # 数据清洗（移除未完成K线+时间排序+去重）
        k_data = k_data.copy().drop_duplicates(subset=['time_key'])
        if len(k_data) > 1:
            k_data = k_data.iloc[:-1]  # 去掉最后一根未完成K线
        k_data = k_data.sort_values('time_key').reset_index(drop=True)

        # 基础数据量校验（至少需要20根K线保证背离判断有效性）
        if len(k_data) < 20:
            信号返回['原因'] = f"【平仓规则5】K线数据不足 | 当前{len(k_data)}根（需至少20根）"
            return 信号返回

        # 提取价格序列（转为numpy数组提升计算效率）
        开盘价序列 = k_data['open'].values
        最高价序列 = k_data['high'].values
        最低价序列 = k_data['low'].values
        收盘价序列 = k_data['close'].values
        最新收盘价 = 收盘价序列[-1] if len(收盘价序列) > 0 else 0
        次新收盘价 = 收盘价序列[-2] if len(收盘价序列) > 1 else 0
        推荐平仓价格 = 最新收盘价

        # ===================== 连续阴阳线判断 =====================
        # 连续阴线（收盘价<开盘价）：平多补充条件
        阴线标记 = (收盘价序列 < 开盘价序列).astype(int)
        连续阴线数 = 0
        for i in range(-1, -min(连续K线数 + 1, len(阴线标记) + 1), -1):
            if 阴线标记[i] == 1:
                连续阴线数 += 1
            else:
                break
        连续3根阴线 = 连续阴线数 >= 连续K线数

        # 连续阳线（收盘价>开盘价）：平空补充条件
        阳线标记 = (收盘价序列 > 开盘价序列).astype(int)
        连续阳线数 = 0
        for i in range(-1, -min(连续K线数 + 1, len(阳线标记) + 1), -1):
            if 阳线标记[i] == 1:
                连续阳线数 += 1
            else:
                break
        连续3根阳线 = 连续阳线数 >= 连续K线数

        # ===================== MA5计算与突破判断 =====================
        # 计算MA5序列（使用最新的收盘价）
        ma5序列 = 计算MA(收盘价序列=收盘价序列, 周期=均线快周期)
        if len(ma5序列) < 2:
            信号返回['原因'] = f"【平仓规则5】MA5计算失败，收盘价序列长度不足"
            return 信号返回

        # 最新MA5值和前值（避免单根K线假突破）
        ma5最新值 = ma5序列.iloc[-1] if hasattr(ma5序列, 'iloc') else ma5序列[-1]
        ma5前值 = ma5序列.iloc[-2] if hasattr(ma5序列, 'iloc') else ma5序列[-2]

        # 更严格的突破/跌破判断（收盘价穿越+确认）
        价格跌破MA5 = (最新收盘价 < ma5最新值) and (次新收盘价 >= ma5前值)
        价格突破MA5 = (最新收盘价 > ma5最新值) and (次新收盘价 <= ma5前值)

        # ===================== 高低点与MACD匹配（优化版） =====================
        # 计算高低点序列（缩小计算范围到最近30根K线，提升准确性）
        计算范围 = min(30, len(最高价序列))
        近期最高价 = 最高价序列[-计算范围:]
        近期最低价 = 最低价序列[-计算范围:]
        近期收盘价 = 收盘价序列[-计算范围:]

        高点序列 = 计算高点(近期最高价, 近期最低价, 近期收盘价, ma_period=5)
        低点序列 = 计算低点(近期最高价, 近期最低价, 近期收盘价, ma_period=5)

        # 提取高低点索引（映射回原序列）
        高点索引列表 = [len(收盘价序列) - 计算范围 + i for i, val in enumerate(高点序列) if val == 1]
        低点索引列表 = [len(收盘价序列) - 计算范围 + i for i, val in enumerate(低点序列) if val == 1]

        # 过滤无效高低点（至少间隔5根K线，避免密集信号）
        有效高点索引 = []
        上一个高点位置 = -10
        for idx in sorted(高点索引列表):
            if idx - 上一个高点位置 >= 5:
                有效高点索引.append(idx)
                上一个高点位置 = idx

        有效低点索引 = []
        上一个低点位置 = -10
        for idx in sorted(低点索引列表):
            if idx - 上一个低点位置 >= 5:
                有效低点索引.append(idx)
                上一个低点位置 = idx

        # 为有效高低点匹配MACD值
        带MACD的高点列表 = []
        for idx in 有效高点索引:
            dif, dea, macd = 计算局部MACD(收盘价序列, idx)
            if dif is not None and not (dif == 0 and dea == 0):  # 过滤无效MACD值
                带MACD的高点列表.append({
                    'index': idx,
                    'price': 最高价序列[idx],
                    'dif': dif,
                    'dea': dea,
                    'macd': macd
                })

        带MACD的低点列表 = []
        for idx in 有效低点索引:
            dif, dea, macd = 计算局部MACD(收盘价序列, idx)
            if dif is not None and not (dif == 0 and dea == 0):  # 过滤无效MACD值
                带MACD的低点列表.append({
                    'index': idx,
                    'price': 最低价序列[idx],
                    'dif': dif,
                    'dea': dea,
                    'macd': macd
                })

        # 按索引倒序排列（最新的在前）
        带MACD的高点列表.sort(key=lambda x: x['index'], reverse=True)
        带MACD的低点列表.sort(key=lambda x: x['index'], reverse=True)

        # ===================== 多头平仓（顶背离+跌破MA5/连续阴线） =====================
        if 当前仓位 and 当前仓位['持仓数量'] > 0:
            顶背离触发 = False
            背离详情 = ""

            # 检查顶背离（至少2个带MACD的高点，且满足阈值）
            if len(带MACD的高点列表) >= 2:
                最近高点 = 带MACD的高点列表[0]
                前高点 = 带MACD的高点列表[1]

                # 严格顶背离判断：价格新高 + DIF明显未新高（超过阈值）
                价格新高 = 最近高点['price'] > 前高点['price'] * (1 + 1e-6)  # 微小阈值避免精度问题
                DIF未新高 = 最近高点['dif'] < 前高点['dif'] - 背离阈值

                if 价格新高 and DIF未新高:
                    顶背离触发 = True
                    背离详情 = (f"价格新高({最近高点['price']:.2f} > {前高点['price']:.2f}) "
                                f"但DIF明显走低({最近高点['dif']:.6f} < {前高点['dif']:.6f} - {背离阈值})")

            # 平仓条件判断（顶背离 + (跌破MA5 或 连续3根阴线)）
            触发条件1 = 顶背离触发 and 价格跌破MA5
            触发条件2 = 顶背离触发 and 连续3根阴线
            if 触发条件1 or 触发条件2:
                触发原因 = "顶背离+价格跌破MA5" if 触发条件1 else "顶背离+连续3根阴线"
                信号返回 = {
                    'id': 2012,
                    '信号工厂': 平仓方向.平多,
                    '推荐平仓方向': 平仓方向.平多,
                    '推荐平仓数量': 推荐平仓数量,
                    '推荐平仓价格': 推荐平仓价格,
                    '原因': (
                        f"【平仓规则5】触发平多条件：{触发原因} | {背离详情} "
                        f"| MA5({ma5最新值:.2f}) | 收盘价({最新收盘价:.2f}) | 连续阴线数({连续阴线数})"
                    )
                }
            else:
                未满足原因 = []
                if not 顶背离触发:
                    未满足原因.append("顶背离条件未触发")
                else:
                    if not 价格跌破MA5 and not 连续3根阴线:
                        未满足原因.append(
                            f"价格未跌破MA5({最新收盘价:.2f} ≥ {ma5最新值:.2f})且未出现连续3根阴线(当前{连续阴线数}根)")
                    elif not 价格跌破MA5:
                        未满足原因.append(f"价格未跌破MA5({最新收盘价:.2f} ≥ {ma5最新值:.2f})")
                    else:
                        未满足原因.append(f"未出现连续3根阴线(当前{连续阴线数}根)")
                信号返回['原因'] = f"【平仓规则5】平多条件未满足：{' | '.join(未满足原因)}"

        # ===================== 空头平仓（底背离+突破MA5/连续阳线） =====================
        elif 当前仓位 and 当前仓位['持仓数量'] < 0:
            底背离触发 = False
            背离详情 = ""

            # 检查底背离（至少2个带MACD的低点，且满足阈值）
            if len(带MACD的低点列表) >= 2:
                最近低点 = 带MACD的低点列表[0]
                前低点 = 带MACD的低点列表[1]

                # 严格底背离判断：价格新低 + DIF明显未新低（超过阈值）
                价格新低 = 最近低点['price'] < 前低点['price'] * (1 - 1e-6)  # 微小阈值避免精度问题
                DIF未新低 = 最近低点['dif'] > 前低点['dif'] + 背离阈值

                if 价格新低 and DIF未新低:
                    底背离触发 = True
                    背离详情 = (f"价格新低({最近低点['price']:.2f} < {前低点['price']:.2f}) "
                                f"但DIF明显走高({最近低点['dif']:.6f} > {前低点['dif']:.6f} + {背离阈值})")

            # 平仓条件判断（底背离 + (突破MA5 或 连续3根阳线)）
            触发条件1 = 底背离触发 and 价格突破MA5
            触发条件2 = 底背离触发 and 连续3根阳线
            if 触发条件1 or 触发条件2:
                触发原因 = "底背离+价格突破MA5" if 触发条件1 else "底背离+连续3根阳线"
                信号返回 = {
                    'id': 2011,
                    '信号工厂': 平仓方向.平空,
                    '推荐平仓方向': 平仓方向.平空,
                    '推荐平仓数量': 推荐平仓数量,
                    '推荐平仓价格': 推荐平仓价格,
                    '原因': (
                        f"【平仓规则5】触发平空条件：{触发原因} | {背离详情} "
                        f"| MA5({ma5最新值:.2f}) | 收盘价({最新收盘价:.2f}) | 连续阳线数({连续阳线数})"
                    )
                }
            else:
                未满足原因 = []
                if not 底背离触发:
                    未满足原因.append("底背离条件未触发")
                else:
                    if not 价格突破MA5 and not 连续3根阳线:
                        未满足原因.append(
                            f"价格未突破MA5({最新收盘价:.2f} ≤ {ma5最新值:.2f})且未出现连续3根阳线(当前{连续阳线数}根)")
                    elif not 价格突破MA5:
                        未满足原因.append(f"价格未突破MA5({最新收盘价:.2f} ≤ {ma5最新值:.2f})")
                    else:
                        未满足原因.append(f"未出现连续3根阳线(当前{连续阳线数}根)")
                信号返回['原因'] = f"【平仓规则5】平空条件未满足：{' | '.join(未满足原因)}"

        # 无持仓情况
        else:
            信号返回['原因'] = f"【平仓规则5】条件未满足：持仓数量为0，不能平仓"

        return 信号返回

    # 标准化异常处理（更详细的错误信息）
    except Exception as e:
        仓位信息 = f"持仓数量：{当前仓位['持仓数量'] if (当前仓位 and '持仓数量' in 当前仓位) else '未知'}" if 当前仓位 else "无仓位信息"
        错误信息 = (
            f"【平仓规则5】执行错误 | 时间：{当前K线时间} | {仓位信息} "
            f"| 错误类型：{type(e).__name__} | 错误内容：{str(e)} "
            f"| 堆栈信息：{traceback.format_exc()}"
        )
        logger.error(错误信息)
        print("错误信息:", 错误信息)
        信号返回['id'] = -1
        信号返回['原因'] = 错误信息
        return 信号返回


def 平仓规则5_MACD背离MA5平仓_deepseek(参数=None):
    """
    平仓规则5（优化增强版）- MACD顶底背离 + MA5过滤
    平多：出现顶背离（价格创近期新高但DIF未创新高）且收盘价跌破MA5
    平空：出现底背离（价格创近期新低但DIF未创新低）且收盘价站上MA5
    优化点：
    1. 高低点识别增加过滤条件：使用N日高低点结合MACD金叉死叉位置增强有效性
    2. 增加背离有效性确认：要求背离形成后DIF与DEA处于特定状态
    3. 引入连续确认机制：价格突破MA5后等待1-2根K线确认
    4. 优化参数适配不同周期
    """
    # 初始化标准返回信号
    信号返回 = 信号返回_空.copy()

    # 提取核心参数
    当前仓位 = 参数.get('仓位', None)
    当前K线时间 = 参数.get('当前k线时间', None)
    均线快周期 = 参数.get('均线快周期', 5)
    推荐平仓数量 = abs(当前仓位['持仓数量'])

    # 可调参数
    高低点回溯窗口 = 参数.get('高低点回溯窗口', 20)  # 用于确认近期高低点
    连续阴线根数 = 参数.get('连续阴线根数', 2)  # 连续阴线确认参数
    macd_lookback = 参数.get('macd_lookback', 3)  # MACD对比回溯周期

    try:
        # ===================== 数据获取与预处理 =====================
        # 获取1分钟K线数据（60根）
        k_ret, k_data = 获取回测K线(参数=参数, 数量=80, 周期="K_1M")  # 增加数据量确保稳定
        if k_ret != RET_OK:
            信号返回['原因'] = f"【平仓规则5NEW】获取1分钟K线失败: {k_data}"
            return 信号返回

        # 数据清洗（移除未完成K线+时间排序）
        k_data = k_data.copy()
        if len(k_data) > 1:
            k_data = k_data.iloc[:-1]
        k_data = k_data.sort_values('time_key')

        if len(k_data) < 20:  # 提高数据量要求
            信号返回['原因'] = f"【平仓规则5NEW】K线数据不足 | 当前{len(k_data)}根（需至少20根）"
            return 信号返回

        # 提取价格序列
        开盘价序列 = k_data['open'].values
        最高价序列 = k_data['high'].values
        最低价序列 = k_data['low'].values
        收盘价序列 = k_data['close'].values
        最新收盘价 = 收盘价序列[-1]
        推荐平仓价格 = 最新收盘价

        # ===================== 增强型高低点识别 =====================
        # 计算标准高低点
        高点序列 = 计算高点(最高价序列, 最低价序列, 收盘价序列, ma_period=5)
        低点序列 = 计算低点(最高价序列, 最低价序列, 收盘价序列, ma_period=5)

        # 计算MACD值序列用于辅助判断
        dif_list, dea_list, macd_list = 计算MACD(收盘价序列)

        # 增强高点识别：要求高点同时是近期N周期高点
        有效高点列表 = []
        for i in range(len(高点序列)):
            if 高点序列[i] == 1 and i >= 5:  # 确保有足够的数据
                # 检查是否为近期高点
                if i >= 5:
                    left = max(0, i - 高低点回溯窗口)
                    right = min(len(最高价序列), i + 5)  # 向后看几根
                    recent_highs = 最高价序列[left:i + 1]
                    if 最高价序列[i] >= max(recent_highs) * 0.995:  # 接近近期高点
                        # 获取该位置的MACD值
                        if i < len(dif_list):
                            有效高点列表.append({
                                'index': i,
                                'price': 最高价序列[i],
                                'dif': dif_list[i],
                                'dea': dea_list[i],
                                'macd': macd_list[i]
                            })

        # 增强低点识别：要求低点同时是近期N周期低点
        有效低点列表 = []
        for i in range(len(低点序列)):
            if 低点序列[i] == 1 and i >= 5:
                if i >= 5:
                    left = max(0, i - 高低点回溯窗口)
                    right = min(len(最低价序列), i + 5)
                    recent_lows = 最低价序列[left:i + 1]
                    if 最低价序列[i] <= min(recent_lows) * 1.005:  # 接近近期低点
                        if i < len(dif_list):
                            有效低点列表.append({
                                'index': i,
                                'price': 最低价序列[i],
                                'dif': dif_list[i],
                                'dea': dea_list[i],
                                'macd': macd_list[i]
                            })

        # 按索引排序（最新的在前）
        有效高点列表.sort(key=lambda x: x['index'], reverse=True)
        有效低点列表.sort(key=lambda x: x['index'], reverse=True)

        # 如果没有识别到有效高低点，使用原始高低点作为备选
        if len(有效高点列表) < 2:
            有效高点列表 = []
            for idx in [i for i, val in enumerate(高点序列) if val == 1]:
                if idx < len(dif_list) and dif_list[idx] is not None:
                    有效高点列表.append({
                        'index': idx,
                        'price': 最高价序列[idx],
                        'dif': dif_list[idx],
                        'dea': dea_list[idx],
                        'macd': macd_list[idx]
                    })
            有效高点列表.sort(key=lambda x: x['index'], reverse=True)

        if len(有效低点列表) < 2:
            有效低点列表 = []
            for idx in [i for i, val in enumerate(低点序列) if val == 1]:
                if idx < len(dif_list) and dif_list[idx] is not None:
                    有效低点列表.append({
                        'index': idx,
                        'price': 最低价序列[idx],
                        'dif': dif_list[idx],
                        'dea': dea_list[idx],
                        'macd': macd_list[idx]
                    })
            有效低点列表.sort(key=lambda x: x['index'], reverse=True)

        # ===================== MA5计算与趋势判断 =====================
        ma5序列 = 计算MA(收盘价序列=收盘价序列, 周期=均线快周期)
        if len(ma5序列) == 0:
            信号返回['原因'] = f"【平仓规则5NEW】MA5计算失败"
            return 信号返回

        ma5最新值 = ma5序列.iloc[-1] if hasattr(ma5序列, 'iloc') else ma5序列[-1]
        ma5前值 = ma5序列.iloc[-2] if hasattr(ma5序列, 'iloc') and len(ma5序列) > 1 else ma5序列[-2]

        # 增强MA5判断：考虑趋势方向和连续性
        ma5_trend_up = ma5最新值 > ma5前值  # MA5向上
        ma5_trend_down = ma5最新值 < ma5前值  # MA5向下

        # 连续阴线/阳线判断
        连续阴线计数 = 0
        连续阳线计数 = 0
        for i in range(min(连续阴线根数 + 2, len(收盘价序列))):
            idx = -1 - i
            if idx < -len(收盘价序列):
                break
            if 收盘价序列[idx] < 开盘价序列[idx]:  # 阴线
                连续阴线计数 += 1
            else:
                break

        for i in range(min(连续阴线根数 + 2, len(收盘价序列))):
            idx = -1 - i
            if idx < -len(收盘价序列):
                break
            if 收盘价序列[idx] > 开盘价序列[idx]:  # 阳线
                连续阳线计数 += 1
            else:
                break

        连续阴线触发 = 连续阴线计数 >= 连续阴线根数
        连续阳线触发 = 连续阳线计数 >= 连续阴线根数

        # ===================== 多头平仓（顶背离+跌破MA5/连续阴线） =====================
        if 当前仓位['持仓数量'] > 0:
            顶背离触发 = False
            背离强度 = 0
            背离详情 = ""

            # 检查顶背离（至少2个有效高点）
            if len(有效高点列表) >= 2:
                # 取最近的两个高点进行比较
                最近高点 = 有效高点列表[0]
                前高点 = None

                # 寻找一个合理的前高点（时间间隔足够）
                for h in 有效高点列表[1:]:
                    if 最近高点['index'] - h['index'] >= 3:  # 至少间隔3根K线
                        前高点 = h
                        break

                if 前高点:
                    价格新高 = 最近高点['price'] > 前高点['price'] * 1.001  # 价格新高（容忍微小误差）
                    DIF新高 = 最近高点['dif'] > 前高点['dif']

                    if 价格新高 and not DIF新高:
                        顶背离触发 = True
                        背离强度 = (最近高点['price'] - 前高点['price']) / 前高点['price'] * 100  # 背离幅度
                        背离详情 = (f"价格新高({最近高点['price']:.2f} > {前高点['price']:.2f}) "
                                    f"但DIF走低({最近高点['dif']:.6f} ≤ {前高点['dif']:.6f})")

                        # 额外有效性检查：当前DIF是否已掉头向下
                        current_idx = -1
                        if abs(current_idx) <= len(dif_list):
                            current_dif = dif_list[current_idx]
                            prev_dif = dif_list[current_idx - 1] if current_idx - 1 >= -len(dif_list) else current_dif
                            if current_dif < prev_dif:  # DIF正在向下
                                背离强度 += 1  # 增强背离有效性

            # 平仓条件判断：顶背离 + (跌破MA5 或 连续阴线)
            if 顶背离触发 and (最新收盘价 < ma5最新值 or 连续阴线触发):
                信号返回 = {
                    'id': 2012,
                    '信号工厂': 平仓方向.平多,
                    '推荐平仓方向': 平仓方向.平多,
                    '推荐平仓数量': 推荐平仓数量,
                    '推荐平仓价格': 推荐平仓价格,
                    '原因': (
                        f"【平仓规则5NEW】平多条件触发：顶背离({背离详情}) + "
                        f"{'跌破MA5' if 最新收盘价 < ma5最新值 else '连续阴线'}"
                        f"({最新收盘价:.2f} {'<' if 最新收盘价 < ma5最新值 else '>'}{ma5最新值:.2f})"
                    )
                }
            else:
                未满足原因 = []
                if not 顶背离触发:
                    未满足原因.append("顶背离未触发")
                if not (最新收盘价 < ma5最新值 or 连续阴线触发):
                    未满足原因.append("价格未跌破MA5且无连续阴线")
                信号返回['原因'] = f"【平仓规则5NEW】平多条件未满足：{' | '.join(未满足原因)}"

        # ===================== 空头平仓（底背离+突破MA5/连续阳线） =====================
        elif 当前仓位['持仓数量'] < 0:
            底背离触发 = False
            背离强度 = 0
            背离详情 = ""

            # 检查底背离（至少2个有效低点）
            if len(有效低点列表) >= 2:
                # 取最近的两个低点进行比较
                最近低点 = 有效低点列表[0]
                前低点 = None

                for l in 有效低点列表[1:]:
                    if 最近低点['index'] - l['index'] >= 3:  # 至少间隔3根K线
                        前低点 = l
                        break

                if 前低点:
                    价格新低 = 最近低点['price'] < 前低点['price'] * 0.999  # 价格新低
                    DIF新低 = 最近低点['dif'] < 前低点['dif']

                    if 价格新低 and not DIF新低:
                        底背离触发 = True
                        背离强度 = (前低点['price'] - 最近低点['price']) / 前低点['price'] * 100
                        背离详情 = (f"价格新低({最近低点['price']:.2f} < {前低点['price']:.2f}) "
                                    f"但DIF走高({最近低点['dif']:.6f} ≥ {前低点['dif']:.6f})")

                        # 额外有效性检查：当前DIF是否已掉头向上
                        current_idx = -1
                        if abs(current_idx) <= len(dif_list):
                            current_dif = dif_list[current_idx]
                            prev_dif = dif_list[current_idx - 1] if current_idx - 1 >= -len(dif_list) else current_dif
                            if current_dif > prev_dif:  # DIF正在向上
                                背离强度 += 1

            # 平仓条件判断：底背离 + (突破MA5 或 连续阳线)
            if 底背离触发 and (最新收盘价 > ma5最新值 or 连续阳线触发):
                信号返回 = {
                    'id': 2011,
                    '信号工厂': 平仓方向.平空,
                    '推荐平仓方向': 平仓方向.平空,
                    '推荐平仓数量': 推荐平仓数量,
                    '推荐平仓价格': 推荐平仓价格,
                    '原因': (
                        f"【平仓规则5NEW】平空条件触发：底背离({背离详情}) + "
                        f"{'突破MA5' if 最新收盘价 > ma5最新值 else '连续阳线'}"
                        f"({最新收盘价:.2f} {'>' if 最新收盘价 > ma5最新值 else '<'}{ma5最新值:.2f})"
                    )
                }
            else:
                未满足原因 = []
                if not 底背离触发:
                    未满足原因.append("底背离未触发")
                if not (最新收盘价 > ma5最新值 or 连续阳线触发):
                    未满足原因.append("价格未突破MA5且无连续阳线")
                信号返回['原因'] = f"【平仓规则5NEW】平空条件未满足：{' | '.join(未满足原因)}"

        else:
            信号返回['原因'] = f"【平仓规则5NEW】无持仓，无需平仓"

        return 信号返回

    except Exception as e:
        错误信息 = f"【平仓规则5NEW】执行错误 | 时间：{当前K线时间} | 错误：{str(e)},traceback:{traceback.format_exc()}"
        logger.error(错误信息)
        信号返回['id'] = -1
        信号返回['原因'] = 错误信息
        return 信号返回


################################# 改写后的 平仓规则5（MACD背离平仓）#################################
def 平仓规则5_MACD背离MA5平仓_chuan(参数=None):
    """
    改写版 平仓规则5：基于MACD背离信号的平仓规则
    - 核心逻辑：价格与MACD（柱状图）发生背离时，结合价格与均线关系判断平仓时机
    - 平多条件：顶背离（价格创新高但MACD未创新高） + 价格跌破MA5
    - 平空条件：底背离（价格创新低但MACD未创新低） + 价格突破MA5

    改写说明：
    1. 严格遵循文档代码结构和编程规范
    2. 背离判断基于MACD柱状图（而非DIF线），符合用户最新指令
    3. 保持统一的参数格式和返回信号格式
    """

    # 初始化标准返回信号
    信号返回 = {
        'id': 0,
        '信号': '',
        '推荐平仓方向': '',
        '推荐平仓数量': 0,
        '推荐平仓价格': 0,
        '原因': ''
    }

    # 提取核心参数
    当前仓位 = 参数.get('仓位', None)
    当前K线时间 = 参数.get('当前k线时间', None)
    均线快周期 = 参数.get('均线快周期', 5)  # 默认MA5
    推荐平仓数量 = abs(当前仓位['持仓数量']) if 当前仓位 and 当前仓位['持仓数量'] != 0 else 0

    try:
        # ===================== 1. 数据获取与预处理 =====================
        # 获取1分钟K线数据（60根，确保有足够数据计算MACD）
        k_ret, k_data = 获取回测K线(参数=参数, 数量=60, 周期="K_1M")
        if k_ret != RET_OK or k_data is None or k_data.empty:
            信号返回['原因'] = f"【改写平仓规则5】获取1分钟K线失败: {k_data}"
            return 信号返回

        # 数据清洗：移除未完成K线并按时间排序
        k_data = k_data.copy()
        if len(k_data) > 1:
            k_data = k_data.iloc[:-1]  # 去掉最后一根未完成K线
        k_data = k_data.sort_values('time_key')

        # 基础数据量校验（至少需要26+9=35根K线计算可靠MACD）
        if len(k_data) < 35:
            信号返回['原因'] = f"【改写平仓规则5】K线数据不足 | 当前{len(k_data)}根（需至少35根）"
            return 信号返回

        # 提取价格序列
        开盘价序列 = k_data['open'].values
        最高价序列 = k_data['high'].values
        最低价序列 = k_data['low'].values
        收盘价序列 = k_data['close'].values
        最新收盘价 = 收盘价序列[-1] if len(收盘价序列) > 0 else 0
        推荐平仓价格 = 最新收盘价

        # ===================== 2. 计算技术指标 =====================
        # 2.1 计算高低点序列
        高点序列 = 计算高点(最高价序列, 最低价序列, 收盘价序列, ma_period=5)
        低点序列 = 计算低点(最高价序列, 最低价序列, 收盘价序列, ma_period=5)

        # 提取高低点索引
        高点索引列表 = [i for i, val in enumerate(高点序列) if val == 1]
        低点索引列表 = [i for i, val in enumerate(低点序列) if val == 1]

        # 2.2 为每个高低点计算对应的MACD值（包含DIF, DEA, MACD柱）
        带MACD的高点列表 = []
        for idx in 高点索引列表:
            dif, dea, macd = 计算局部MACD(收盘价序列, idx)
            if dif is not None and macd is not None:  # 确保MACD值有效
                带MACD的高点列表.append({
                    'index': idx,
                    'price': 最高价序列[idx],
                    'dif': dif,
                    'dea': dea,
                    'macd': macd  # 这是MACD柱状图的值
                })

        带MACD的低点列表 = []
        for idx in 低点索引列表:
            dif, dea, macd = 计算局部MACD(收盘价序列, idx)
            if dif is not None and macd is not None:  # 确保MACD值有效
                带MACD的低点列表.append({
                    'index': idx,
                    'price': 最低价序列[idx],
                    'dif': dif,
                    'dea': dea,
                    'macd': macd  # 这是MACD柱状图的值
                })

        # 按时间倒序排列（最近的在前）
        带MACD的高点列表.sort(key=lambda x: x['index'], reverse=True)
        带MACD的低点列表.sort(key=lambda x: x['index'], reverse=True)

        # 2.3 计算MA5
        ma5序列 = 计算MA(收盘价序列=收盘价序列, 周期=均线快周期)
        if len(ma5序列) == 0:
            信号返回['原因'] = f"【改写平仓规则5】MA5计算失败，收盘价序列长度不足"
            return 信号返回

        ma5最新值 = ma5序列.iloc[-1] if hasattr(ma5序列, 'iloc') else ma5序列[-1]

        # 判断价格与MA5关系
        价格跌破MA5 = 最新收盘价 < ma5最新值
        价格突破MA5 = 最新收盘价 > ma5最新值

        # ===================== 3. 多头平仓判断（顶背离+跌破MA5） =====================
        if 当前仓位 and 当前仓位['持仓数量'] > 0:
            顶背离触发 = False
            背离详情 = ""

            # 检查顶背离：需要至少2个有效高点
            if len(带MACD的高点列表) >= 2:
                最近高点 = 带MACD的高点列表[0]
                前高点 = 带MACD的高点列表[1]

                # 顶背离条件：价格创新高，但MACD柱未创新高
                价格新高 = 最近高点['price'] > 前高点['price']
                MACD新高 = 最近高点['macd'] > 前高点['macd']

                if 价格新高 and not MACD新高:
                    顶背离触发 = True
                    背离详情 = (f"价格新高({最近高点['price']:.2f} > {前高点['price']:.2f}) "
                                f"但MACD走低({最近高点['macd']:.6f} ≤ {前高点['macd']:.6f})")

            # 平仓条件判断：顶背离 + 价格跌破MA5
            if 顶背离触发 and 价格跌破MA5:
                信号返回 = {
                    'id': 811,  # 保持与文档一致的信号ID
                    '信号': 平仓方向.平多,
                    '推荐平仓方向': 平仓方向.平多,
                    '推荐平仓数量': 推荐平仓数量,
                    '推荐平仓价格': 推荐平仓价格,
                    '原因': (
                        f"【改写平仓规则5】触发平多条件：MACD顶背离({背离详情}) + 价格跌破MA5 "
                        f"({最新收盘价:.2f} < {ma5最新值:.2f})"
                    )
                }
            else:
                未满足原因 = []
                if not 顶背离触发:
                    if len(带MACD的高点列表) < 2:
                        未满足原因.append(f"有效高点不足{len(带MACD的高点列表)}个")
                    else:
                        未满足原因.append("未检测到MACD顶背离信号")
                if not 价格跌破MA5:
                    未满足原因.append(f"价格未跌破MA5({最新收盘价:.2f} ≥ {ma5最新值:.2f})")
                信号返回['原因'] = f"【改写平仓规则5】平多条件未满足：{' | '.join(未满足原因)}"

        # ===================== 4. 空头平仓判断（底背离+突破MA5） =====================
        elif 当前仓位 and 当前仓位['持仓数量'] < 0:
            底背离触发 = False
            背离详情 = ""

            # 检查底背离：需要至少2个有效低点
            if len(带MACD的低点列表) >= 2:
                最近低点 = 带MACD的低点列表[0]
                前低点 = 带MACD的低点列表[1]

                # 底背离条件：价格创新低，但MACD柱未创新低
                价格新低 = 最近低点['price'] < 前低点['price']
                MACD新低 = 最近低点['macd'] < 前低点['macd']

                if 价格新低 and not MACD新低:
                    底背离触发 = True
                    背离详情 = (f"价格新低({最近低点['price']:.2f} < {前低点['price']:.2f}) "
                                f"但MACD走高({最近低点['macd']:.6f} ≥ {前低点['macd']:.6f})")

            # 平仓条件判断：底背离 + 价格突破MA5
            if 底背离触发 and 价格突破MA5:
                信号返回 = {
                    'id': 812,  # 保持与文档一致的信号ID
                    '信号': 平仓方向.平空,
                    '推荐平仓方向': 平仓方向.平空,
                    '推荐平仓数量': 推荐平仓数量,
                    '推荐平仓价格': 推荐平仓价格,
                    '原因': (
                        f"【改写平仓规则5】触发平空条件：MACD底背离({背离详情}) + 价格突破MA5 "
                        f"({最新收盘价:.2f} > {ma5最新值:.2f})"
                    )
                }
            else:
                未满足原因 = []
                if not 底背离触发:
                    if len(带MACD的低点列表) < 2:
                        未满足原因.append(f"有效低点不足{len(带MACD的低点列表)}个")
                    else:
                        未满足原因.append("未检测到MACD底背离信号")
                if not 价格突破MA5:
                    未满足原因.append(f"价格未突破MA5({最新收盘价:.2f} ≤ {ma5最新值:.2f})")
                信号返回['原因'] = f"【改写平仓规则5】平空条件未满足：{' | '.join(未满足原因)}"

        # ===================== 5. 无持仓情况 =====================
        else:
            信号返回['原因'] = f"【改写平仓规则5】条件未满足：持仓数量为0，无需平仓"

        return 信号返回

    except Exception as e:
        # 标准化异常处理
        错误信息 = (f"【改写平仓规则5】执行错误 | 时间：{当前K线时间} | "
                    f"错误类型：{type(e).__name__} | 错误内容：{str(e)} | "
                    f"堆栈信息：{traceback.format_exc()}")
        logger.error(错误信息)
        信号返回['id'] = -1
        信号返回['原因'] = 错误信息
        return 信号返回
