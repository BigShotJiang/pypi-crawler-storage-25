from fuwen_signal.fw_signal.信号工厂.七福.公共.公用函数 import logger, 判断是否满足开仓N分钟后平仓
from fuwen_signal.fw_signal.信号工厂.七福.公共.公共常量 import 信号返回_空
from fuwen_signal.fw_signal.信号工厂.七福.平仓规则.平仓规则1 import 平仓规则1_3分钟和5分钟K线连续两根收盘价突破快均线触发平仓
from fuwen_signal.fw_signal.信号工厂.七福.平仓规则.平仓规则2 import 平仓规则2_3分钟高低点双阴阳线快均线触发平仓
from fuwen_signal.fw_signal.信号工厂.七福.平仓规则.平仓规则3 import 平仓规则3_次高低点K线组合MA5平仓
from fuwen_signal.fw_signal.信号工厂.七福.平仓规则.平仓规则4 import 平仓规则4_止盈_高低点数量利润回撤平仓, 平仓规则4_止损_价格触发止损价平仓
from fuwen_signal.fw_signal.信号工厂.七福.平仓规则.平仓规则5 import 平仓规则5_MACD背离MA5平仓


def 平仓前有效性检查(参数=None):
    if 参数 is None:
        return {"id": -1, "原因": "【平仓前有效性检查】参数为空"}
    信号返回 = 信号返回_空.copy()
    if 参数.get('当前k线时间') in ['2026-02-02 18:57']:
        logger.debug(f"【平仓规则1】当前k线时间={参数.get('当前k线时间')}")

    当前仓位 = 参数.get('仓位', {})
    if abs(当前仓位.get('持仓数量', 0)) == 0:
        信号返回['id'], 信号返回['原因'] = -1, f"【平仓检查】当前无持仓，跳过检查"
        return 信号返回

    # 开仓成功N分钟后才允许平仓
    if not 判断是否满足开仓N分钟后平仓(参数=参数):
        信号返回['id'], 信号返回['原因'] = -2, f"【平仓检查】不满足条件：开仓N分钟后才允许平仓"
        return 信号返回

    return 信号返回


def 平仓检测(参数=None):
    if 参数 is None:
        参数 = {}
    res = {}
    res_平仓检查 = 平仓前有效性检查(参数=参数)
    if res_平仓检查.get('id', 0) != 0:
        return res_平仓检查

    # 定义规则配置列表：(规则名, 检测方法, 触发ID列表)
    平仓规则列表 = [
        ('平仓规则1', 平仓规则1_3分钟和5分钟K线连续两根收盘价突破快均线触发平仓, [2002, 2001]),
        ('平仓规则2', 平仓规则2_3分钟高低点双阴阳线快均线触发平仓, [2004, 2003]),
        ('平仓规则3', 平仓规则3_次高低点K线组合MA5平仓, [2006, 2005]),
        ('平仓规则4_止盈', 平仓规则4_止盈_高低点数量利润回撤平仓, [2008, 2007]),
        ('平仓规则4_止损', 平仓规则4_止损_价格触发止损价平仓, [2010, 2009]),
        ('平仓规则5_MACD', 平仓规则5_MACD背离MA5平仓, [2012, 2011]),
    ]

    # 遍历规则列表，按顺序检测
    for 规则名, 检测方法, 触发ID in 平仓规则列表:
        检测结果 = 检测方法(参数=参数)
        res[规则名] = 检测结果
        # 判断是否触发平仓
        if type(检测结果) == str:
            continue
        检测结果id = int(检测结果.get('id', 0))
        if 检测结果id in 触发ID:
            res['平仓规则'] = 检测结果
            res['id'] = 检测结果id
            break  # 找到触发规则后终止遍历


    return res  # 仅保留一个return


if __name__ == '__main__':
    result = 平仓检测()
    print("result:", result)
