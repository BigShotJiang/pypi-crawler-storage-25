############################ 高低点计算 ############################
import numpy as np

from fuwen_signal.fw_signal.信号工厂.七福.公共.公用函数 import 计算MA, logger


def 计算高点(highs, lows, closes, ma_period=5) -> np.ndarray:
    """self.计算高点（修改版：处理K1和K2最高价相等的情况）
    高点定义：
    条件1：K线在上涨过程中出现左（K0）右（K2）两根K线最高价均低于中间K线（K1）最高价
    条件2：当K1的最高价等于K2，则将K1和K2视为一个整体（视为K1），后续K线向后移一位
    条件3：在后续K线（K3到K7）出现最低价低于K1和K2的最低价
    条件4：在后续K线（K3到K7）出现收盘价低于K2收盘价
    条件5：K0、K1或K2有一根K线满足收盘价大于MA5（多单条件）
    条件3和条件4可以分别由不同K线满足
    """
    k线高点序列 = np.zeros(len(closes))
    length = len(closes)

    # self.计算MA5
    ma5_values = 计算MA(收盘价序列=closes, 周期=ma_period)

    i = 1
    while i < length - 1:  # 使用while循环以便在需要时跳过K线
        # 条件1：K1是局部高点（K0和K2的最高价都低于K1）
        if not (highs[i] > highs[i - 1] and highs[i] > highs[i + 1]):
            i += 1
            continue

        # 条件2：检查K1和K2最高价是否相等
        k1_index = i
        k2_index = i + 1

        # 如果K1和K2最高价相等，将它们视为一个整体
        if highs[k1_index] == highs[k2_index]:
            # 将K1和K2视为一个整体，K1的最高价取两者中的最大值（实际上相等）
            k1_high = max(highs[k1_index], highs[k2_index])
            k1_low = min(lows[k1_index], lows[k2_index])
            k1_close = closes[k2_index]  # 使用K2的收盘价作为整体的收盘价

            # 调整后续K线索引：K3变成K2，K4变成K3，以此类推
            adjusted_k2_index = k2_index + 1  # 原来的K3现在作为K2

            adjusted_k3_start = k2_index + 2  # 原来的K4现在作为K3的起始

            logger.debug(
                f"高点合并 | 位置K1:{k1_index}, K2:{k2_index} | 最高价相等: {highs[k1_index]:.2f} = {highs[k2_index]:.2f}")
        else:
            # 正常情况：K1和K2最高价不相等
            k1_high = highs[k1_index]
            k1_low = lows[k1_index]
            k1_close = closes[k1_index]

            adjusted_k2_index = k2_index  # K2索引不变
            adjusted_k3_start = k2_index + 1  # K3从K2的下一个开始

        # 条件5：K0、K1或K2有一根K线满足收盘价大于MA5（多单条件）
        condition5_met = False

        # 检查K0的收盘价是否大于MA5
        if k1_index - 1 >= 0:  # 确保K0存在
            k0_close = closes[k1_index - 1]
            k0_ma5 = ma5_values[k1_index - 1]
            if k0_close > k0_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K0收盘价{k0_close:.2f} > MA5{k0_ma5:.2f}")

        # 检查K1的收盘价是否大于MA5
        if not condition5_met and k1_index < len(closes):
            k1_ma5 = ma5_values[k1_index]
            if k1_close > k1_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K1收盘价{k1_close:.2f} > MA5{k1_ma5:.2f}")

        # 检查K2的收盘价是否大于MA5
        if not condition5_met and adjusted_k2_index < len(closes):
            k2_close = closes[adjusted_k2_index] if adjusted_k2_index < len(closes) else closes[k2_index]
            k2_ma5 = ma5_values[adjusted_k2_index] if adjusted_k2_index < len(ma5_values) else ma5_values[k2_index]
            if k2_close > k2_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K2收盘价{k2_close:.2f} > MA5{k2_ma5:.2f}")

        # 如果条件5不满足，跳过当前高点判断
        if not condition5_met:
            logger.debug(f"条件5未满足：K0、K1、K2收盘价均不大于MA5")
            if highs[k1_index] == highs[k2_index]:
                i += 2  # 跳过K1和K2，直接处理下一个K线
            else:
                i += 1  # 正常移动到下一个K线
            continue

        # 获取K2的关键价格（调整后的K2）
        if adjusted_k2_index < length:
            k2_high = highs[adjusted_k2_index] if adjusted_k2_index < length else highs[k2_index]
            k2_low = lows[adjusted_k2_index] if adjusted_k2_index < length else lows[k2_index]
            k2_close = closes[adjusted_k2_index] if adjusted_k2_index < length else closes[k2_index]
        else:
            k2_high = highs[k2_index]
            k2_low = lows[k2_index]
            k2_close = closes[k2_index]

        # 计算合并后的最低价（K1和K2中的最小值）
        combined_low = min(k1_low, k2_low)

        # 初始化条件标志
        condition3_met = False  # 条件3：最低价低于K1和K2的最低价
        condition4_met = False  # 条件4：收盘价低于K2收盘价

        # 检查K3到K7区间（使用调整后的索引）
        for j in range(adjusted_k3_start, min(adjusted_k3_start + 5, length)):

            # 检查条件3：最低价低于K1和K2的最低价
            if not condition3_met and lows[j] < combined_low:
                condition3_met = True

            # 检查条件4：收盘价低于K2收盘价
            if not condition4_met and closes[j] < k2_close:
                condition4_met = True

            # 如果两个条件都满足，则标记为高点
            if condition3_met and condition4_met:
                k线高点序列[k1_index] = 1
                logger.debug(f"高点确认 | 位置：{k1_index} | 价格：{k1_high:.2f} |  "
                             f"收盘价：{k1_close:.2f} | MA5：{ma5_values[k1_index]:.2f} | "
                             f"K2调整：{'是' if highs[k1_index] == highs[k2_index] else '否'} | "
                             f"条件3：{condition3_met} | 条件4：{condition4_met}")
                break  # 找到确认信号即可

        maxhighs = highs[k1_index + 1]
        for j in range(k1_index + 1, min(k1_index + 5, length)):
            if highs[j] > maxhighs:
                maxhighs = highs[j]

        if maxhighs >= highs[k1_index]:
            k线高点序列[k1_index] = 0  # 修复（假高点）

        # 如果K1和K2被合并，跳过K2的处理
        if highs[k1_index] == highs[k2_index]:
            i += 2  # 跳过K1和K2，直接处理下一个K线
        else:
            i += 1  # 正常移动到下一个K线

    return k线高点序列


def 计算低点(highs, lows, closes, ma_period=5) -> np.ndarray:
    """self.计算低点（修改版：处理K1和K2最低价相等的情况）
    低点定义：
    条件1：K线在下跌过程中出现左（K0）右（K2）两根K线最低价均高于中间K线（K1）最低价
    条件2：当K1的最低价等于K2，则将K1和K2视为一个整体（视为K1），后续K线向后移一位
    条件3：在后续K线（K3到K7）出现最高价高于K1和K2的最高价
    条件4：在后续K线（K3到K7）出现收盘价高于K2收盘价
    条件5：K0、K1或K2有一根K线满足收盘价小于MA5（空单条件）
    条件3和条件4可以分别由不同K线满足
    """
    k线低点序列 = np.zeros(len(closes))
    length = len(closes)

    # self.计算MA5
    ma5_values = 计算MA(收盘价序列=closes, 周期=ma_period)
    i = 1
    while i < length - 1:  # 使用while循环以便在需要时跳过K线
        # 条件1：K1是局部低点（K0和K2的最低价都高于K1）
        # rem  del 20260126 tjw
        if not (lows[i] <= lows[i - 1] and lows[i] <= lows[i + 1]):
            i += 1
            continue

        # 条件2：检查K1和K2最低价是否相等
        k1_index = i
        k2_index = i + 1

        for j in range(i + 1, length - i):
            if lows[j] != lows[k1_index]:
                k2_index = j
                break

        # 如果K1和K2最低价相等，将它们视为一个整体
        if lows[k1_index] == lows[k2_index]:
            # 将K1和K2视为一个整体，K1的最低价取两者中的最小值（实际上相等）
            k1_low = min(lows[k1_index], lows[k2_index])
            k1_high = max(highs[k1_index], highs[k2_index])
            k1_close = closes[k2_index]  # 使用K2的收盘价作为整体的收盘价

            # 调整后续K线索引：K3变成K2，K4变成K3，以此类推
            adjusted_k2_index = k2_index + 1  # 原来的K3现在作为K2
            adjusted_k3_start = k2_index + 2  # 原来的K4现在作为K3的起始

            logger.debug(
                f"低点合并 | 位置K1:{k1_index}, K2:{k2_index} | 最低价相等: {lows[k1_index]:.2f} = {lows[k2_index]:.2f}")
        else:
            # 正常情况：K1和K2最低价不相等
            k1_low = lows[k1_index]
            k1_high = highs[k1_index]
            k1_close = closes[k1_index]

            adjusted_k2_index = k2_index  # K2索引不变
            adjusted_k3_start = k2_index + 1  # K3从K2的下一个开始

        # 条件5：K0、K1或K2有一根K线满足收盘价小于MA5（空单条件）
        condition5_met = False

        # 检查K0的收盘价是否小于MA5
        if k1_index - 1 >= 0:  # 确保K0存在
            k0_close = closes[k1_index - 1]
            k0_ma5 = ma5_values[k1_index - 1]
            if k0_close < k0_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K0收盘价{k0_close:.2f} < MA5{k0_ma5:.2f}")

        # 检查K1的收盘价是否小于MA5
        if not condition5_met and k1_index < len(closes):
            k1_ma5 = ma5_values[k1_index]
            if k1_close < k1_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K1收盘价{k1_close:.2f} < MA5{k1_ma5:.2f}")

        # 检查K2的收盘价是否小于MA5
        if not condition5_met and adjusted_k2_index < len(closes):
            k2_close = closes[adjusted_k2_index] if adjusted_k2_index < len(closes) else closes[k2_index]
            k2_ma5 = ma5_values[adjusted_k2_index] if adjusted_k2_index < len(ma5_values) else ma5_values[k2_index]
            if k2_close < k2_ma5:
                condition5_met = True
                logger.debug(f"条件5满足：K2收盘价{k2_close:.2f} < MA5{k2_ma5:.2f}")

        # 如果条件5不满足，跳过当前低点判断
        if not condition5_met:
            logger.debug(f"条件5未满足：K0、K1、K2收盘价均不小于MA5")
            if lows[k1_index] == lows[k2_index]:
                i += 2  # 跳过K1和K2，直接处理下一个K线
            else:
                i += 1  # 正常移动到下一个K线
            continue

        # 获取K2的关键价格（调整后的K2）
        if adjusted_k2_index < length:
            k2_low = lows[adjusted_k2_index] if adjusted_k2_index < length else lows[k2_index]
            k2_high = highs[adjusted_k2_index] if adjusted_k2_index < length else highs[k2_index]
            k2_close = closes[adjusted_k2_index] if adjusted_k2_index < length else closes[k2_index]
        else:
            k2_low = lows[k2_index]
            k2_high = highs[k2_index]
            k2_close = closes[k2_index]

        # 计算合并后的最高价（K1和K2中的最大值）
        combined_high = max(k1_high, k2_high)

        # 初始化条件标志
        condition3_met = False  # 条件3：最高价高于K1和K2的最高价
        condition4_met = False  # 条件4：收盘价高于K2收盘价

        # 检查K3到K7区间（使用调整后的索引）
        adjusted_k3_start = i + 1
        for j in range(adjusted_k3_start, min(adjusted_k3_start + 5, length)):
            # 检查条件3：最高价高于K1和K2的最高价
            if not condition3_met and highs[j] > combined_high:
                condition3_met = True

            # 检查条件4：收盘价高于K2收盘价
            if not condition4_met and closes[j] > k2_close:
                condition4_met = True

            # 如果两个条件都满足，则标记为低点
            if condition3_met and condition4_met:
                k线低点序列[k1_index] = 1
                # logger.info(f"低点确认 | 位置：{k1_index} | 价格：{k1_low:.2f} | "
                #             f"收盘价：{k1_close:.2f} | MA5：{ma5_values[k1_index]:.2f} | "
                #             f"K2调整：{'是' if lows[k1_index] == lows[k2_index] else '否'} | "
                #             f"条件3：{condition3_met} | 条件4：{condition4_met}")
                break  # 找到确认信号即可

        if k线低点序列[k1_index] == 1:
            imin = lows[k1_index + 1]
            for j in range(k2_index, min(k2_index + 2, length)):
                if lows[j] <= imin:
                    imin = lows[j]

            if imin <= lows[k1_index]:
                logger.debug(f"{i},低点确认 | k1_index：{k1_index}，k2_index：{k2_index} "
                             f"| imin：{imin:.2f}，lows[k1_index]：{lows[k1_index]:.2f}"
                             f"，lows[k2_index]：{lows[k2_index]:.2f}"
                             f"\n")
            if lows[k1_index] == lows[k1_index - 1]:
                if lows[k1_index] > lows[k1_index - 2]:
                    k线低点序列[k1_index] = 0

        # 如果K1和K2被合并，跳过K2的处理
        if k线低点序列[k1_index] == 1:
            i = k2_index + 2
        else:
            i = i + 1

    return k线低点序列
