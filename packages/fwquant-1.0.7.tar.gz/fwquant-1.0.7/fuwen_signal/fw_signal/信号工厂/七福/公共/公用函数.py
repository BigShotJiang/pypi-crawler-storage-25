# 自定义打印对象
import traceback

import pandas as pd

from fuwen_signal.fw_signal.公共库.打印日志 import logger


class 平仓方向:
    平多 = "long"
    平空 = "short"


RET_OK = 0
IS_DEBUG = True


def 计算MA(收盘价序列, 周期=5):
    """计算简单移动平均线（SMA）"""
    # 保留原逻辑，min_periods=周期确保不足周期时返回NaN
    try:
        ma_values = pd.Series(收盘价序列).rolling(window=周期, min_periods=周期).mean()
        return ma_values
    except ValueError as e:
        logger.error(f"计算MA时出错：{e}，traceback={traceback.format_exc()}")
        return None


def 计算EMA(收盘价序列, 周期=5, adjust=True):
    """
    计算指数移动平均线（EMA）
    :param 收盘价序列: 收盘价列表/数组/pd.Series
    :param 周期: EMA计算周期
    :param adjust: 是否调整初始值（默认True，符合金融领域常用逻辑）
    :return: pd.Series 类型的EMA值
    """
    # 转换为Series确保计算一致性
    close_series = pd.Series(收盘价序列)

    # 核心：用ewm计算指数加权平均（真正的EMA）
    # span=周期：等价于EMA的周期参数
    # min_periods=周期：不足周期时返回NaN（和SMA逻辑对齐）
    # adjust=True：初始阶段用简单平均调整，False则用递归计算
    ema_values = close_series.ewm(
        span=周期,
        min_periods=周期,
        adjust=adjust,
        ignore_na=False  # 忽略NaN值，不影响计算
    ).mean()

    return ema_values


def 获取两个时间分钟差(开始时间, 结束时间):
    """
    计算两个时间之间的分钟差，统一使用东八区（北京时间）
    """
    # 转换为pandas Timestamp
    结束时间_single = 结束时间.iloc[0] if isinstance(结束时间, pd.Series) else 结束时间
    开始时间_single = 开始时间.iloc[0] if isinstance(开始时间, pd.Series) else 开始时间

    结束时间_ts = pd.Timestamp(结束时间_single)
    开始时间_ts = pd.Timestamp(开始时间_single)

    # 统一时区为东八区（北京时间） UTC
    if 开始时间_ts.tz is None:
        开始时间_ts = 开始时间_ts.tz_localize('Asia/Shanghai')
    else:
        开始时间_ts = 开始时间_ts.tz_convert('Asia/Shanghai')

    if 结束时间_ts.tz is None:
        结束时间_ts = 结束时间_ts.tz_localize('Asia/Shanghai')
    else:
        结束时间_ts = 结束时间_ts.tz_convert('Asia/Shanghai')

    result = (结束时间_ts - 开始时间_ts).total_seconds() / 60
    return result


def 判断是否满足开仓N分钟后平仓(参数=None):
    result = False
    开仓成功N分钟后才允许平仓 = 参数.get('开仓成功N分钟后才允许平仓', None)
    if 开仓成功N分钟后才允许平仓 <= 0:
        return True

    # 开仓时间
    当前仓位 = 参数.get('仓位', None)
    当前开仓时间 = 当前仓位.get('开仓时间', None)
    委托开仓时间 = 当前仓位.get('委托开仓时间', None)

    # 当前k线时间
    当前k线 = 参数.get('当前k线', None)
    # 当前k线时间 = 当前k线.datetime
    当前k线时间 = 当前k线.time_key

    # 3. 计算已开仓时长（转换为分钟）
    已委托开仓多少分钟 = 获取两个时间分钟差(开始时间=委托开仓时间, 结束时间=当前k线时间)
    已开仓多少分钟 = 获取两个时间分钟差(开始时间=当前开仓时间, 结束时间=当前k线时间)

    if 已开仓多少分钟 >= 开仓成功N分钟后才允许平仓 \
            and 已委托开仓多少分钟 >= 开仓成功N分钟后才允许平仓:
        result = True
    return result


def 获取无时区时间(时间):
    if hasattr(时间, 'tzinfo') and 时间.tzinfo is not None:
        时间_无时区 = 时间.astimezone(pd.Timestamp.utcnow().tzinfo).replace(tzinfo=None)
    else:
        时间_无时区 = 时间
    return 时间_无时区


def 获取分钟值(k_df, sKey="time_key"):
    result = k_df[sKey].iloc[-1].to_pydatetime().minute
    return result


def 获取回测K线(参数, 数量, 周期="1m"):
    """
    获取指定周期的回测K线数据（兼容大小写、关键字参数调用）
    :param 参数: 包含历史k线的参数字典
    :param 数量: 需要获取的K线数量
    :param 周期: K线周期（支持1m/3m/5m，大小写不敏感，如K_1M/k_3M/5M等）
    :return: (状态码, 结果) - 成功返回(RET_OK, K线数据)，失败返回(-1, 错误信息)
    """
    # 校验历史k线是否存在
    f历史k线 = 参数.get('历史k线', None)
    if f历史k线 is None or f历史k线.empty:
        msg = f"【获取回测K线】历史k线数据为空 | 周期：{周期}"
        logger.error(msg)
        return -1, msg

    # 安全复制（避免原数据被修改）
    f历史k线 = f历史k线.copy()

    # 2. 周期大小写统一（核心兼容逻辑）
    周期_小写 = 周期.lower()  # 将K_1M转为k_1m，1M转为1m，实现大小写不敏感

    # 3. 按周期处理K线
    try:
        if 周期_小写 in ["1m", "k_1m"]:  # 兼容K_1M/K_1m/k_1M/1M等所有大小写组合
            k线 = f历史k线
        elif 周期_小写 in ["3m", "k_3m"]:  # 兼容3M/K_3M/k_3m等
            # 转换3分钟周期（确保time_key是datetime类型）
            k线 = f历史k线.set_index('time_key').resample('3min').agg({
                'open': 'first', 'high': 'max', 'low': 'min',
                'close': 'last', 'volume': 'sum'
            }).reset_index()
        elif 周期_小写 in ["5m", "k_5m"]:  # 兼容5M/K_5M/k_5m等
            # 转换5分钟周期
            k线 = f历史k线.set_index('time_key').resample('5min').agg({
                'open': 'first', 'high': 'max', 'low': 'min',
                'close': 'last', 'volume': 'sum'
            }).reset_index()
        else:
            msg = f"【获取回测K线】不支持的周期: {周期}（已转换为小写：{周期_小写}）"
            logger.error(msg)
            return -1, msg

        # 4. 截取最后N条数据（处理数量为0/负数的情况）
        数量 = max(int(数量), 1)  # 确保数量至少为1
        result = k线.tail(数量) if len(k线) >= 数量 else k线  # 替代k线[-数量:]，更安全

        return RET_OK, result

    except Exception as e:
        # 新增：捕获所有异常，避免函数崩溃
        msg = f"【获取回测K线】处理失败 | 周期：{周期} | 数量：{数量} | 错误：{str(e)}"
        logger.error(msg)
        logger.error(traceback.format_exc())
        return -1, msg


# ===================== MACD计算工具函数 =====================
def 计算局部MACD(收盘价序列, 目录索引, short_period=12, long_period=26, signal_period=9):
    """修复后的计算局部MACD函数（增加边界检查）"""
    try:
        # 确保有足够的数据计算MACD
        start_idx = max(0, 目录索引 - long_period - signal_period)
        end_idx = 目录索引 + 1
        if end_idx - start_idx < long_period + signal_period:
            return None, None, None

        # 截取局部数据计算MACD
        local_data = 收盘价序列[start_idx:end_idx]
        if len(local_data) < long_period:
            return None, None, None

        # 计算EMA
        ema_short = pd.Series(local_data).ewm(span=short_period, adjust=False).mean()
        ema_long = pd.Series(local_data).ewm(span=long_period, adjust=False).mean()

        dif = ema_short - ema_long
        dea = dif.ewm(span=signal_period, adjust=False).mean()
        macd柱 = 2 * (dif - dea)

        # 确保有有效数据返回
        if len(dif) == 0 or len(dea) == 0 or len(macd柱) == 0:
            return None, None, None

        return dif.iloc[-1], dea.iloc[-1], macd柱.iloc[-1]
    except Exception:
        logger.error(f"【计算局部MACD】处理失败 | 目录索引：{目录索引} | 错误：{traceback.format_exc()}")
        return None, None, None


def 计算MACD(close_prices, fastperiod=12, slowperiod=26, signalperiod=9):
    """
    计算MACD指标（指数平滑移动平均线）

    参数:
        close_prices: list or array, 收盘价序列
        fastperiod: int, 快线周期，默认12
        slowperiod: int, 慢线周期，默认26
        signalperiod: int, 信号线周期，默认9

    返回:
        dif: list, 差离值（快线-慢线）
        dea: list, 信号线（DIF的EMA）
        macd: list, MACD柱（2*(DIF-DEA)）
    """
    import numpy as np

    # 转换为numpy数组便于计算
    if not isinstance(close_prices, np.ndarray):
        close_prices = np.array(close_prices, dtype=float)

    length = len(close_prices)

    # 初始化返回值
    dif = [None] * length
    dea = [None] * length
    macd = [None] * length

    # 数据量不足时返回空值
    if length < slowperiod + signalperiod:
        return dif, dea, macd

    # 计算EMA
    def EMA(data, period):
        """
        计算指数移动平均
        """
        result = np.zeros_like(data)
        alpha = 2 / (period + 1)

        # 第一个值用SMA
        result[0] = data[0]

        # 递归计算EMA
        for j in range(1, len(data)):
            result[j] = alpha * data[j] + (1 - alpha) * result[j - 1]

        return result

    # 计算快线EMA12和慢线EMA26
    ema12 = EMA(close_prices, fastperiod)
    ema26 = EMA(close_prices, slowperiod)

    # 计算DIF = EMA12 - EMA26
    for i in range(length):
        dif[i] = ema12[i] - ema26[i]

    # 计算DEA（DIF的EMA9）
    # 将DIF转为numpy数组
    dif_array = np.array([x if x is not None else 0 for x in dif])
    dea_values = EMA(dif_array, signalperiod)

    # 计算MACD柱
    for i in range(length):
        dea[i] = dea_values[i]
        if dif[i] is not None and dea[i] is not None:
            macd[i] = 2 * (dif[i] - dea[i])

    return dif, dea, macd
