import zoneinfo
from datetime import datetime

七福默认参数配置 = {
    # 七福参数
    '缓存k线_最大保存数量': 150,

    'n个周期内查找低点': 30,
    '开仓成功N分钟后才允许平仓': 5,
    '止损比例': 0.3,
    '止盈回撤比例': 0.5,

    # 三均线参数
    '均线中周期': 20,
    '均线快周期': 5,
    '均线慢周期': 60,

    # k线数据
    '当前k线时间': '2026-02-26 00:09',
    '历史k线': [
        {
            'open': 26743.0,
            'high': 26750.0,
            'low': 26743.0,
            'close': 26746.0,
            'volume': 22.0,
            'time_key': datetime(2026, 2, 26, 0, 0, tzinfo=zoneinfo.ZoneInfo(key='Asia/Shanghai')),
            'last_price': 26746.0
        },
        {
            'open': 26746.0,
            'high': 26756.0,
            'low': 26745.0,
            'close': 26756.0,
            'volume': 25.0,
            'time_key': datetime(2026, 2, 26, 0, 1, tzinfo=zoneinfo.ZoneInfo(key='Asia/Shanghai')),
            'last_price': 26756.0
        },
        {
            'open': 26757.0,
            'high': 26757.0,
            'low': 26743.0,
            'close': 26749.0,
            'volume': 49.0,
            'time_key': datetime(2026, 2, 26, 0, 2, tzinfo=zoneinfo.ZoneInfo(key='Asia/Shanghai')),
            'last_price': 26749.0
        }
    ],

    # 其它参数
    '最大持仓量': 2,
    '订单_id': '',
    '当前k线': None,
    '当前k线索引': 10,
    '总K线数量_回测': 1233,
    '仓位': {
        '委托开仓时间': None,
        '委托时间': None,
        '平仓下单时间': None,
        '平仓价格': None,
        '平仓数量': None,
        '平仓方向': 'long',
        '平仓订单id': None,
        '开仓价格': 0,
        '开仓数量': 0,
        '开仓方向': '',
        '开仓时间': None,
        '开仓订单id': None,
        '持仓数量': 0,
        '方向': ''
    },

}
