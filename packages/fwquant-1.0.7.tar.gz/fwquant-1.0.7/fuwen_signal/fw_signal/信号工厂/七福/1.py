from fuwen_signal.fw_signal.公共库.打印日志 import logger

if __name__ == '__main__':
    logger.info("123123")