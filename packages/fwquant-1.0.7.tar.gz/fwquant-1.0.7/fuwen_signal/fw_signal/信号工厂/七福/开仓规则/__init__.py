from fuwen_signal.fw_signal.信号工厂.七福.开仓规则.开仓信号判断 import 开仓信号

if __name__ == '__main__':
    result = 开仓信号()
    print(f"开仓信号判断结果：{result}")
    pass
