from fuwen_frame.我的策略.综合 import *

from fuwen_frame.我的策略.示例_双均线 import 示例_双均线类
from fuwen_frame.我的策略.示例_常用 import 示例_常用类

if __name__ == '__main__':
    x = 示例_七福类()
    x = 示例_常用类()
    x = 示例_双均线类()
    pass
