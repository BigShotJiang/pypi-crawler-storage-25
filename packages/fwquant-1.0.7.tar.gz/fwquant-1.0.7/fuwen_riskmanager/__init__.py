# The MIT License (MIT)
#
# Copyright (c) 2015-present, Xiaoyou Chen
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from pathlib import Path

from fuwen_adaptor.trader.app import BaseApp

from .engine import RiskEngine, APP_NAME
from fuwen_frame.公共库.语言 import _

__all__ = [
    "RiskEngine",
    "APP_NAME",
    "RiskManagerApp",
]

__version__ = "2.0.0"

__module__ = "fuwen_riskmanager"
class RiskManagerApp(BaseApp):
    """"""
    app_name: str = APP_NAME
    app_module: str = __name__
    app_path: Path = Path(__file__).parent
    display_name: str = _("交易风控")
    engine_class: type[RiskEngine] = RiskEngine
    widget_name: str = "RiskManager"
    icon_name: str = str(app_path.joinpath("ui", "rm.ico"))
