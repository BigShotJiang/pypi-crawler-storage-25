# 项目根目录（跨平台兼容）
import os

项目根目录 = os.path.abspath(os.path.join(os.path.dirname(__file__), '../'))

# 缓存目录路径
缓存目录 = os.path.join(项目根目录, "缓存目录")
os.makedirs(缓存目录, exist_ok=True)

# 日志目录路径
日志目录 = os.path.join(项目根目录, "日志目录")
os.makedirs(日志目录, exist_ok=True)
