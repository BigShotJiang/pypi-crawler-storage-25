import random

from fuwen_ctastrategy import CtaTemplate

from fuwen_adaptor.trader.object import BarData


class random_strategy(CtaTemplate):
    """示例_随机策略"""

    def on_init(self) -> None:
        pass

    author = "示例_随机"
    parameters = ["author"]  # 显示 参数

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

    def on_bar(self, bar: BarData):
        """每根K线随机交易"""
        if random.random() < 0.2:        # 20%概率触发交易
            if random.choice([True, False]):            # 50%概率做多，50%概率做空
                result=self.buy(bar.close_price, 1)  # 做多1手
                print(f"{bar.datetime} 做多，价格: {bar.close_price},result: {result}")
            else:
                result=self.short(bar.close_price, 1)  # 做空1手
                print(f"{bar.datetime} 做空，价格: {bar.close_price},result: {result}")
