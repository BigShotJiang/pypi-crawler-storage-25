"""
PolarGrid SDK Tests

Comprehensive test suite for the PolarGrid Python SDK.
"""

import time

import pytest

from polargrid import PolarGrid, PolarGridSync, ValidationError, is_polargrid_error
from polargrid.types import VerboseTranscriptionResponse

# ============================================================================
# FIXTURES
# ============================================================================


@pytest.fixture
def mock_client():
    """Create a mock client for testing."""
    return PolarGrid(
        api_key="test-api-key-123",
        use_mock_data=True,
        debug=False,
    )


@pytest.fixture
def mock_sync_client():
    """Create a synchronous mock client for testing."""
    return PolarGridSync(
        api_key="test-api-key-123",
        use_mock_data=True,
        debug=False,
    )


# ============================================================================
# CONSTRUCTOR TESTS
# ============================================================================


class TestConstructor:
    def test_create_client_with_api_key(self):
        client = PolarGrid(api_key="test-key")
        assert client is not None

    def test_allow_client_without_api_key_in_production(self):
        # Should not raise - allowed for edge server access
        client = PolarGrid(use_mock_data=False)
        assert client is not None

    def test_allow_mock_mode_without_api_key(self):
        client = PolarGrid(use_mock_data=True)
        assert client is not None

    def test_use_custom_base_url(self):
        client = PolarGrid(
            api_key="test-key",
            base_url="https://custom.api.com/v2",
        )
        assert client is not None


# ============================================================================
# CHAT COMPLETION TESTS
# ============================================================================


class TestChatCompletion:
    @pytest.mark.asyncio
    async def test_generate_chat_completion(self, mock_client):
        response = await mock_client.chat_completion({
            "model": "llama-3.1-8b",
            "messages": [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": "What is the capital of France?"},
            ],
            "max_tokens": 150,
            "temperature": 0.7,
        })

        assert response.id.startswith("chatcmpl-")
        assert response.object == "chat.completion"
        assert response.model == "llama-3.1-8b"
        assert len(response.choices) > 0
        assert response.choices[0].message.role == "assistant"
        assert len(response.choices[0].message.content) > 0
        assert "Paris" in response.choices[0].message.content
        assert response.usage.prompt_tokens > 0
        assert response.usage.completion_tokens > 0

    @pytest.mark.asyncio
    async def test_validation_error_for_missing_model(self, mock_client):
        with pytest.raises(ValidationError):
            await mock_client.chat_completion({
                "model": "",
                "messages": [{"role": "user", "content": "Test"}],
            })

    @pytest.mark.asyncio
    async def test_validation_error_for_empty_messages(self, mock_client):
        # Pydantic validates min_length before our custom validation
        from pydantic import ValidationError as PydanticValidationError
        with pytest.raises((ValidationError, PydanticValidationError)):
            await mock_client.chat_completion({
                "model": "llama-3.1-8b",
                "messages": [],
            })

    @pytest.mark.asyncio
    async def test_streaming_chat_completion(self, mock_client):
        chunks = []

        async for chunk in mock_client.chat_completion_stream({
            "model": "llama-3.1-8b",
            "messages": [{"role": "user", "content": "Tell me a short story"}],
            "max_tokens": 50,
        }):
            assert chunk.id.startswith("chatcmpl-stream-")
            assert chunk.object == "chat.completion.chunk"
            chunks.append(chunk)

        assert len(chunks) > 0
        # First chunk should have role
        assert chunks[0].choices[0].delta.role == "assistant"


# ============================================================================
# TEXT COMPLETION TESTS
# ============================================================================


class TestChatCompletionBodyForwarding:
    """Regression tests: the SDK must forward the full extended OpenAI
    surface (tools, response_format, seed, repetition controls,
    multi-turn tool_calls) to the gateway body, not silently drop fields
    the typed request advertises.
    """

    def _build_body(self, **fields):
        from polargrid.types import ChatCompletionRequest, Message
        client = PolarGrid(api_key="pg_test", use_mock_data=False)
        msgs = fields.pop("messages", [Message(role="user", content="hi")])
        req = ChatCompletionRequest(model="qwen-3.5-27b", messages=msgs, **fields)
        return client._build_chat_completion_body(req, stream_override=False)

    def test_tools_and_tool_choice_round_trip(self):
        from polargrid.types import ChatTool, FunctionDefinition
        body = self._build_body(
            tools=[ChatTool(function=FunctionDefinition(name="get_weather"))],
            tool_choice="auto",
        )
        assert body["tools"] == [{"type": "function", "function": {"name": "get_weather"}}]
        assert body["tool_choice"] == "auto"

    def test_response_format_round_trip(self):
        from polargrid.types import ResponseFormat
        body = self._build_body(
            response_format=ResponseFormat(type="json_schema", json_schema={"schema": {"type": "object"}}),
        )
        assert body["response_format"]["type"] == "json_schema"
        assert body["response_format"]["json_schema"] == {"schema": {"type": "object"}}

    def test_seed_and_sampling_extras_round_trip(self):
        body = self._build_body(seed=42, repetition_penalty=1.1, min_p=0.05)
        assert body["seed"] == 42
        from math import isclose
        assert isclose(body["repetition_penalty"], 1.1, rel_tol=1e-9)
        assert isclose(body["min_p"], 0.05, rel_tol=1e-9)

    def test_assistant_tool_calls_and_tool_role_survive_serialization(self):
        from polargrid.types import Message, ToolCall, ToolCallFunction
        msgs = [
            Message(role="user", content="weather?"),
            Message(role="assistant", tool_calls=[ToolCall(
                id="call_1",
                function=ToolCallFunction(name="get_weather", arguments='{"city":"Tokyo"}'),
            )]),
            Message(role="tool", content="sunny", tool_call_id="call_1"),
        ]
        body = self._build_body(messages=msgs)
        assert body["messages"][1]["tool_calls"][0]["function"]["name"] == "get_weather"
        assert body["messages"][2]["tool_call_id"] == "call_1"
        assert body["messages"][2]["role"] == "tool"

    def test_none_fields_dropped(self):
        body = self._build_body()
        for k in ("tools", "tool_choice", "response_format", "seed", "repetition_penalty", "min_p"):
            assert k not in body, f"{k} should be stripped when unset"


class TestCompletion:
    @pytest.mark.asyncio
    async def test_generate_text_completion(self, mock_client):
        response = await mock_client.completion({
            "prompt": "Once upon a time",
            "model": "llama-3.1-8b",
            "max_tokens": 100,
            "temperature": 0.8,
        })

        assert response.id.startswith("cmpl-")
        assert response.object == "text_completion"
        assert response.model == "llama-3.1-8b"
        assert len(response.choices) > 0
        assert len(response.choices[0].text) > 0
        assert response.choices[0].finish_reason == "stop"

    @pytest.mark.asyncio
    async def test_validation_error_for_empty_prompt(self, mock_client):
        with pytest.raises(ValidationError, match="Prompt is required"):
            await mock_client.completion({
                "prompt": "",
                "model": "llama-3.1-8b",
            })

    @pytest.mark.asyncio
    async def test_streaming_completion(self, mock_client):
        chunks = []

        async for chunk in mock_client.completion_stream({
            "prompt": "The future of AI is",
            "model": "llama-3.1-8b",
            "max_tokens": 50,
        }):
            assert chunk.id.startswith("cmpl-stream-")
            assert chunk.object == "text_completion.chunk"
            chunks.append(chunk)

        assert len(chunks) > 0


# ============================================================================
# LEGACY GENERATE METHOD TESTS
# ============================================================================


class TestGenerate:
    @pytest.mark.asyncio
    async def test_legacy_generate_method(self, mock_client):
        response = await mock_client.generate({
            "model": "llama-3.1-8b",
            "prompt": "Explain quantum computing",
            "max_tokens": 150,
            "temperature": 0.7,
        })

        assert response.id is not None
        assert response.model == "llama-3.1-8b"
        assert len(response.content) > 0
        assert response.usage.prompt_tokens > 0
        assert response.usage.completion_tokens > 0
        assert response.created_at is not None
        assert response.processing_time_ms >= 0


# ============================================================================
# TEXT-TO-SPEECH TESTS
# ============================================================================


class TestTextToSpeech:
    @pytest.mark.asyncio
    async def test_generate_audio_from_text(self, mock_client):
        audio_buffer = await mock_client.text_to_speech({
            "model": "tts-1",
            "input": "Hello from PolarGrid!",
            "voice": "alloy",
            "response_format": "mp3",
            "speed": 1.0,
        })

        assert isinstance(audio_buffer, bytes)
        assert len(audio_buffer) > 0

    @pytest.mark.asyncio
    async def test_validation_error_for_empty_input(self, mock_client):
        with pytest.raises(ValidationError, match="Input text is required"):
            await mock_client.text_to_speech({
                "model": "tts-1",
                "input": "",
                "voice": "alloy",
            })

    @pytest.mark.asyncio
    async def test_validation_error_for_long_input(self, mock_client):
        from pydantic import ValidationError as PydanticValidationError
        long_text = "a" * 5000  # Over 4096 character limit

        with pytest.raises((ValidationError, PydanticValidationError)):
            await mock_client.text_to_speech({
                "model": "tts-1",
                "input": long_text,
                "voice": "alloy",
            })

    @pytest.mark.asyncio
    async def test_streaming_tts(self, mock_client):
        chunks = []

        async for chunk in mock_client.text_to_speech_stream({
            "model": "tts-1",
            "input": "This is a longer text that will be streamed.",
            "voice": "nova",
        }):
            assert isinstance(chunk, bytes)
            chunks.append(chunk)

        assert len(chunks) > 0


# ============================================================================
# SPEECH-TO-TEXT TESTS
# ============================================================================


class TestTranscription:
    @pytest.mark.asyncio
    async def test_transcribe_audio(self, mock_client):
        mock_audio_data = bytes([0xFF, 0xFB, 0x90, 0x00])

        transcription = await mock_client.transcribe(
            file=mock_audio_data,
            request={
                "model": "whisper-1",
                "language": "en",
                "response_format": "json",
            },
        )

        assert hasattr(transcription, "text")
        assert len(transcription.text) > 0

    @pytest.mark.asyncio
    async def test_verbose_transcription_with_timestamps(self, mock_client):
        mock_audio_data = bytes([0xFF, 0xFB, 0x90, 0x00])

        transcription = await mock_client.transcribe(
            file=mock_audio_data,
            request={
                "model": "whisper-1",
                "response_format": "verbose_json",
            },
        )

        assert isinstance(transcription, VerboseTranscriptionResponse)
        assert transcription.task == "transcribe"
        assert transcription.language is not None
        assert transcription.duration > 0
        assert len(transcription.segments) > 0

        segment = transcription.segments[0]
        assert segment.start >= 0
        assert segment.end > segment.start
        assert len(segment.text) > 0


class TestTranslation:
    @pytest.mark.asyncio
    async def test_translate_audio(self, mock_client):
        mock_audio_data = bytes([0xFF, 0xFB, 0x90, 0x00])

        translation = await mock_client.translate(
            file=mock_audio_data,
            request={
                "model": "whisper-1",
                "response_format": "json",
            },
        )

        assert hasattr(translation, "text")
        assert len(translation.text) > 0


# ============================================================================
# MODEL MANAGEMENT TESTS
# ============================================================================


class TestModelManagement:
    @pytest.mark.asyncio
    async def test_list_models(self, mock_client):
        response = await mock_client.list_models()

        assert response.object == "list"
        assert len(response.data) > 0

        model = response.data[0]
        assert model.id is not None
        assert model.object == "model"
        assert model.owned_by is not None

        model_ids = [m.id for m in response.data]
        assert "llama-3.1-8b" in model_ids
        assert "whisper-1" in model_ids
        assert "tts-1" in model_ids

    @pytest.mark.asyncio
    async def test_load_model(self, mock_client):
        result = await mock_client.load_model({
            "model_name": "llama-3.1-70b",
            "force_reload": False,
        })

        assert result.status in ("success", "loading", "failed")
        assert result.model == "llama-3.1-70b"
        assert result.force_reload is False
        assert len(result.message) > 0

    @pytest.mark.asyncio
    async def test_validation_error_for_missing_model_name(self, mock_client):
        with pytest.raises(ValidationError, match="Model name is required"):
            await mock_client.load_model({"model_name": ""})

    @pytest.mark.asyncio
    async def test_unload_model(self, mock_client):
        result = await mock_client.unload_model({"model_name": "gpt2"})

        assert result.status in ("success", "failed")
        assert result.model == "gpt2"
        assert len(result.message) > 0

    @pytest.mark.asyncio
    async def test_unload_all_models(self, mock_client):
        result = await mock_client.unload_all_models()

        assert result.status in ("success", "partial", "failed")
        assert len(result.unloaded_models) > 0
        assert result.total_unloaded > 0

    @pytest.mark.asyncio
    async def test_get_model_status(self, mock_client):
        status = await mock_client.get_model_status()

        assert len(status.loaded) > 0
        assert len(status.loading_status) > 0
        assert status.repository is not None


# ============================================================================
# GPU MANAGEMENT TESTS
# ============================================================================


class TestGPUManagement:
    @pytest.mark.asyncio
    async def test_get_gpu_status(self, mock_client):
        status = await mock_client.get_gpu_status()

        assert status.status == "success"
        assert status.timestamp is not None
        assert len(status.gpus) > 0
        assert status.total_gpus > 0

        gpu = status.gpus[0]
        assert gpu.index >= 0
        assert gpu.name is not None
        assert gpu.memory.total_gb > 0
        assert gpu.memory.used_gb >= 0
        assert gpu.utilization.gpu_percent >= 0
        assert gpu.temperature_c > 0

    @pytest.mark.asyncio
    async def test_get_gpu_memory(self, mock_client):
        memory = await mock_client.get_gpu_memory()

        assert memory.status == "success"
        assert memory.timestamp is not None
        assert len(memory.memory) > 0

        mem_info = memory.memory[0]
        assert mem_info.total_gb > 0
        assert mem_info.used_gb >= 0
        assert mem_info.free_gb >= 0
        assert 0 <= mem_info.percent_used <= 100
        assert 0 <= mem_info.percent_free <= 100

    @pytest.mark.asyncio
    async def test_purge_gpu(self, mock_client):
        result = await mock_client.purge_gpu({"force": False})

        assert result.status in ("success", "partial", "failed")
        assert result.timestamp is not None
        assert len(result.actions) > 0
        assert result.memory_freed_gb > 0
        assert len(result.models_unloaded) > 0
        assert result.recommendation is not None


# ============================================================================
# HEALTH CHECK TESTS
# ============================================================================


class TestHealthCheck:
    @pytest.mark.asyncio
    async def test_health_check(self, mock_client):
        health = await mock_client.health()

        assert health.status in ("healthy", "degraded", "unhealthy")
        assert health.service is not None
        assert health.runtime is not None
        assert health.timestamp is not None

        assert health.features.text_inference is True
        assert health.features.voice is True
        assert health.features.dynamic_loading is True
        assert health.features.streaming is True

        assert health.backend.url is not None
        assert health.backend.healthy is True
        assert health.backend.info.models_loaded > 0
        assert health.backend.info.gpu_available is True


# ============================================================================
# ERROR HANDLING TESTS
# ============================================================================


class TestErrorHandling:
    def test_allow_empty_api_key(self):
        # Should not raise - allowed for edge server access
        PolarGrid(api_key="", use_mock_data=False)
        PolarGrid(api_key="   ", use_mock_data=False)
        PolarGrid(api_key=None, use_mock_data=False)

    @pytest.mark.asyncio
    async def test_is_polargrid_error_identifies_sdk_errors(self, mock_client):
        # Test with our ValidationError (not Pydantic's)
        try:
            await mock_client.completion({
                "model": "test-model",
                "prompt": "",  # Empty prompt triggers our ValidationError
            })
        except Exception as error:
            assert is_polargrid_error(error) is True
            assert isinstance(error, ValidationError)


# ============================================================================
# MOCK MODE TESTS
# ============================================================================


class TestMockMode:
    def test_work_without_api_key_in_mock_mode(self):
        client = PolarGrid(use_mock_data=True)
        assert client is not None

    @pytest.mark.asyncio
    async def test_simulate_realistic_latency(self, mock_client):
        import time

        start = time.time()
        await mock_client.chat_completion({
            "model": "llama-3.1-8b",
            "messages": [{"role": "user", "content": "Test"}],
        })
        duration = time.time() - start

        # Should take at least 0.4 seconds (simulated delay)
        assert duration > 0.4


# ============================================================================
# SYNC CLIENT TESTS
# ============================================================================


class TestSyncClient:
    def test_sync_chat_completion(self, mock_sync_client):
        response = mock_sync_client.chat_completion({
            "model": "llama-3.1-8b",
            "messages": [{"role": "user", "content": "Hello!"}],
        })

        assert response.id.startswith("chatcmpl-")
        assert len(response.choices) > 0
        assert len(response.choices[0].message.content) > 0

    def test_sync_list_models(self, mock_sync_client):
        response = mock_sync_client.list_models()

        assert response.object == "list"
        assert len(response.data) > 0

    def test_sync_health(self, mock_sync_client):
        health = mock_sync_client.health()

        assert health.status == "healthy"
        assert health.backend.healthy is True


# ============================================================================
# AUTOROUTER (_discover_best_region) — locks down the new server contract
# {region, name, endpoint, ttl}. Mocks httpx.AsyncClient.get to avoid network.
# ============================================================================


class _FakeAsyncClient:
    """Minimal httpx.AsyncClient stand-in for autorouter tests."""

    def __init__(self, response=None, raise_exc=None, capture=None):
        self._response = response
        self._raise = raise_exc
        self._capture = capture

    def __call__(self, *_, **__):
        return self

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False

    async def get(self, url, **_):
        if self._capture is not None:
            self._capture["url"] = url
        if self._raise is not None:
            raise self._raise
        return self._response


class _FakeResponse:
    def __init__(self, status_code=200, body=None, raise_on_json=None):
        self.status_code = status_code
        self._body = body
        self._raise = raise_on_json

    def json(self):
        if self._raise is not None:
            raise self._raise
        return self._body


class TestAutorouter:
    """Cover happy + every fallback path in _discover_best_region."""

    @pytest.fixture(autouse=True)
    def _clear_region_cache(self):
        """Each test starts with a clean autorouter cache so cached picks
        from earlier tests don't leak."""
        from polargrid import client as client_module
        client_module._REGION_CACHE.clear()
        yield
        client_module._REGION_CACHE.clear()

    @pytest.mark.asyncio
    async def test_happy_path_returns_picked_region(self, monkeypatch):
        from polargrid import client as client_module

        captured = {}
        fake = _FakeAsyncClient(
            response=_FakeResponse(200, {
                "region": "yvr-02",
                "name": "Vancouver",
                "endpoint": "https://api.yvr-02.edge.polargrid.ai",
                "ttl": 3600,
            }),
            capture=captured,
        )
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)
        result = await client_module._discover_best_region(debug=False)

        assert result == {
            "endpoint": "https://api.yvr-02.edge.polargrid.ai",
            "region_id": "yvr-02",
            "region_name": "Vancouver",
        }
        assert "/v1/route" in captured["url"]
        assert "all=true" not in captured["url"]

    @pytest.mark.asyncio
    async def test_missing_region_field_falls_back(self, monkeypatch):
        from polargrid import client as client_module

        fake = _FakeAsyncClient(
            response=_FakeResponse(200, {"regions": [], "ttl": 3600})  # old shape
        )
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)
        result = await client_module._discover_best_region(debug=False)
        assert result["region_id"] == client_module.DEFAULT_REGION

    @pytest.mark.asyncio
    async def test_missing_endpoint_field_falls_back(self, monkeypatch):
        from polargrid import client as client_module

        fake = _FakeAsyncClient(
            response=_FakeResponse(200, {"region": "yvr-02", "name": "Vancouver", "ttl": 3600})
        )
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)
        result = await client_module._discover_best_region(debug=False)
        assert result["region_id"] == client_module.DEFAULT_REGION

    @pytest.mark.asyncio
    async def test_http_500_falls_back(self, monkeypatch):
        from polargrid import client as client_module

        fake = _FakeAsyncClient(response=_FakeResponse(500, {"error": "oops"}))
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)
        result = await client_module._discover_best_region(debug=False)
        assert result["region_id"] == client_module.DEFAULT_REGION

    @pytest.mark.asyncio
    async def test_network_error_falls_back(self, monkeypatch):
        from polargrid import client as client_module

        fake = _FakeAsyncClient(raise_exc=client_module.httpx.ConnectError("boom"))
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)
        result = await client_module._discover_best_region(debug=False)
        assert result["region_id"] == client_module.DEFAULT_REGION

    @pytest.mark.asyncio
    async def test_non_json_body_falls_back(self, monkeypatch):
        """200 with HTML/text body → JSONDecodeError, distinguished from network error."""
        import json as _json
        from polargrid import client as client_module

        fake = _FakeAsyncClient(
            response=_FakeResponse(
                200, body=None, raise_on_json=_json.JSONDecodeError("boom", "doc", 0),
            ),
        )
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)
        result = await client_module._discover_best_region(debug=False)
        assert result["region_id"] == client_module.DEFAULT_REGION

    @pytest.mark.asyncio
    async def test_name_defaults_to_region_when_absent(self, monkeypatch):
        from polargrid import client as client_module

        fake = _FakeAsyncClient(
            response=_FakeResponse(200, {
                "region": "yul-01",
                "endpoint": "https://api.yul-01.edge.polargrid.ai",
                "ttl": 3600,
            }),
        )
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)
        result = await client_module._discover_best_region(debug=False)
        assert result["region_name"] == "yul-01"  # falls back to region id

    @pytest.mark.asyncio
    async def test_cache_hit_skips_network(self, monkeypatch):
        """Second call within TTL must not re-invoke httpx.AsyncClient."""
        from polargrid import client as client_module

        captured = {"calls": 0}

        class _CountingResponse:
            status_code = 200
            def json(self_):
                captured["calls"] += 1
                return {
                    "region": "yto-01",
                    "name": "Toronto",
                    "endpoint": "https://api.yto-01.edge.polargrid.ai",
                    "ttl": 3600,
                }

        fake = _FakeAsyncClient(response=_CountingResponse())
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)

        first = await client_module._discover_best_region(debug=False)
        second = await client_module._discover_best_region(debug=False)

        assert first == second
        assert captured["calls"] == 1, "second discover should hit cache, not network"

    @pytest.mark.asyncio
    async def test_expired_cache_re_fetches(self, monkeypatch):
        """A cached entry with a past expiry triggers a fresh fetch."""
        from polargrid import client as client_module

        # Pre-seed an expired entry.
        client_module._REGION_CACHE[client_module.AUTOROUTER_URL] = (
            {"endpoint": "https://stale", "region_id": "stale", "region_name": "Stale"},
            time.time() - 1,
        )

        fake = _FakeAsyncClient(response=_FakeResponse(200, {
            "region": "yvr-02",
            "name": "Vancouver",
            "endpoint": "https://api.yvr-02.edge.polargrid.ai",
            "ttl": 3600,
        }))
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)

        result = await client_module._discover_best_region(debug=False)
        assert result["region_id"] == "yvr-02"

    @pytest.mark.asyncio
    async def test_fallback_path_does_not_pollute_cache(self, monkeypatch):
        """Fallback (autorouter unreachable) must NOT cache the default region —
        otherwise we'd be stuck on yto-01 for an hour even after the autorouter
        comes back."""
        from polargrid import client as client_module

        fake = _FakeAsyncClient(raise_exc=client_module.httpx.ConnectError("boom"))
        monkeypatch.setattr(client_module.httpx, "AsyncClient", fake)

        await client_module._discover_best_region(debug=False)
        assert client_module.AUTOROUTER_URL not in client_module._REGION_CACHE