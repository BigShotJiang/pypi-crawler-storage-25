"""
PolarGrid SDK Type Definitions

This module contains all the Pydantic models for request/response types.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field

# ============================================================================
# POLARGRID METADATA
# ============================================================================


class PGMetadata(BaseModel):
    """PolarGrid-specific metadata returned with inference responses."""

    region: str = Field(..., description="Edge region that processed the request")
    latency_ms: int = Field(..., description="Total processing latency in milliseconds")
    model_load_time_ms: int | None = Field(default=None, description="Time to load the model in milliseconds")
    queue_time_ms: int | None = Field(default=None, description="Time spent in the request queue in milliseconds")
    inference_time_ms: int | None = Field(default=None, description="Time spent on inference in milliseconds")


# ============================================================================
# CONFIGURATION
# ============================================================================


class PolarGridConfig(BaseModel):
    """Configuration options for the PolarGrid client."""

    api_key: str | None = Field(
        default=None,
        description="API key for authentication. If not provided, will look for POLARGRID_API_KEY environment variable",
    )
    base_url: str = Field(
        default="https://api.polargrid.ai",
        description="Base URL for the PolarGrid API",
    )
    auth_url: str = Field(
        default="https://auth.polargrid.ai/v1/auth/session",
        description="URL for JWT token exchange",
    )
    timeout: float = Field(
        default=30.0,
        description="Request timeout in seconds",
    )
    max_retries: int = Field(
        default=3,
        description="Maximum number of retry attempts for failed requests",
    )
    debug: bool = Field(
        default=False,
        description="Enable debug logging",
    )
    use_mock_data: bool = Field(
        default=False,
        description="Use mock data instead of making real API calls",
    )


# ============================================================================
# TEXT INFERENCE TYPES
# ============================================================================


class FunctionDefinition(BaseModel):
    """OpenAI function definition used inside a `ChatTool`."""

    name: str
    description: str | None = None
    parameters: dict[str, Any] | None = None


class ChatTool(BaseModel):
    """OpenAI-compatible tool definition (function-only for now)."""

    type: Literal["function"] = "function"
    function: FunctionDefinition


class ToolCallFunction(BaseModel):
    """Function payload inside a tool call (arguments is a JSON string)."""

    name: str
    arguments: str


class ToolCall(BaseModel):
    """A function/tool invocation emitted by the assistant."""

    id: str
    type: Literal["function"] = "function"
    function: ToolCallFunction


class ResponseFormat(BaseModel):
    """Output shape constraint. Maps to vLLM `guided_json` server-side."""

    type: Literal["text", "json_object", "json_schema"]
    json_schema: dict[str, Any] | None = Field(
        default=None,
        description="Required when type=json_schema. Shape: {name?, schema, strict?}",
    )


class Message(BaseModel):
    """A message in a chat conversation."""

    role: Literal["system", "user", "assistant", "tool"]
    content: str | None = None
    name: str | None = Field(default=None, description="Optional name of the message author")
    tool_calls: list[ToolCall] | None = None
    tool_call_id: str | None = Field(
        default=None,
        description="Pairs a tool-result message with the assistant's tool_calls[].id",
    )


class CompletionRequest(BaseModel):
    """Parameters for text completion requests."""

    prompt: str | list[str] = Field(..., description="The input prompt for text generation")
    model: str = Field(..., description="The model to use for generation")
    max_tokens: int | None = Field(default=100, ge=1, le=4096, description="Maximum tokens to generate")
    temperature: float | None = Field(default=0.7, ge=0.0, le=2.0, description="Temperature for randomness")
    top_p: float | None = Field(default=0.9, ge=0.0, le=1.0, description="Top-p sampling parameter")
    top_k: int | None = Field(default=50, description="Top-k sampling parameter")
    frequency_penalty: float | None = Field(default=0.0, ge=-2.0, le=2.0)
    presence_penalty: float | None = Field(default=0.0, ge=-2.0, le=2.0)
    stop: list[str] | None = Field(default=None, max_length=4, description="Stop sequences")
    user: str | None = Field(default=None, description="End-user identifier")


class CompletionChoice(BaseModel):
    """A single completion choice."""

    text: str
    index: int
    logprobs: Any | None = None
    finish_reason: Literal["stop", "length", "content_filter"]


class TokenUsage(BaseModel):
    """Token usage information."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class CompletionResponse(BaseModel):
    """Response from text completion requests."""

    id: str
    object: Literal["text_completion"] = "text_completion"
    created: int
    model: str
    choices: list[CompletionChoice]
    usage: TokenUsage
    pg_metadata: PGMetadata | None = Field(default=None, description="PolarGrid-specific metadata (region, latency breakdown)")


class CompletionChunkChoice(BaseModel):
    """A choice in a streaming completion chunk."""

    text: str
    index: int
    finish_reason: Literal["stop", "length", "content_filter"] | None = None


class CompletionChunk(BaseModel):
    """Streaming completion chunk.

    The gateway emits ``"text_completion"`` for SSE chunks (matching OpenAI's
    legacy completion-streaming spec); newer ``"text_completion.chunk"`` is
    accepted for forward compatibility.
    """

    id: str
    object: Literal["text_completion", "text_completion.chunk"] = "text_completion"
    created: int
    model: str
    choices: list[CompletionChunkChoice]


ToolChoice = Literal["none", "auto", "required"] | dict[str, Any]


class ChatCompletionRequest(BaseModel):
    """Parameters for chat completion requests."""

    model: str = Field(..., description="The model to use for generation")
    messages: list[Message] = Field(..., min_length=1, description="Array of messages")
    max_tokens: int | None = Field(default=150, ge=1, le=4096)
    temperature: float | None = Field(default=0.7, ge=0.0, le=2.0)
    top_p: float | None = Field(default=0.9, ge=0.0, le=1.0)
    top_k: int | None = Field(default=None)
    frequency_penalty: float | None = Field(default=None, ge=-2.0, le=2.0)
    presence_penalty: float | None = Field(default=None, ge=-2.0, le=2.0)
    stop: list[str] | None = Field(default=None)
    stream: bool | None = Field(default=False)
    user: str | None = Field(default=None)
    tools: list[ChatTool] | None = Field(
        default=None,
        description="Function definitions the model may call",
    )
    tool_choice: ToolChoice | None = Field(
        default=None,
        description="`none` / `auto` / `required` / `{type:'function',function:{name:...}}`. Defaults to `auto` when tools is set.",
    )
    response_format: ResponseFormat | None = Field(
        default=None,
        description="Output shape constraint. `json_object` for free JSON, `json_schema` for schema-locked.",
    )
    seed: int | None = Field(default=None)
    repetition_penalty: float | None = Field(default=None)
    min_p: float | None = Field(default=None, ge=0.0, le=1.0)


class ChatMessage(BaseModel):
    """A chat message in a response."""

    role: Literal["assistant"]
    content: str | None = None
    tool_calls: list[ToolCall] | None = None


class ChatCompletionChoice(BaseModel):
    """A single chat completion choice."""

    index: int
    message: ChatMessage
    finish_reason: Literal["stop", "length", "content_filter", "tool_calls"]


class ChatCompletionResponse(BaseModel):
    """Response from chat completion requests."""

    id: str
    object: Literal["chat.completion"] = "chat.completion"
    created: int
    model: str
    choices: list[ChatCompletionChoice]
    usage: TokenUsage
    pg_metadata: PGMetadata | None = Field(default=None, description="PolarGrid-specific metadata (region, latency breakdown)")


class ToolCallDelta(BaseModel):
    """Per-chunk delta for an emerging tool call (matched across chunks by index)."""

    index: int
    id: str | None = None
    type: Literal["function"] | None = None
    function: dict[str, Any] | None = None


class ChatDelta(BaseModel):
    """Delta content in a streaming chat chunk."""

    role: Literal["assistant"] | None = None
    content: str | None = None
    tool_calls: list[ToolCallDelta] | None = None


class ChatCompletionChunkChoice(BaseModel):
    """A choice in a streaming chat chunk."""

    index: int
    delta: ChatDelta
    finish_reason: Literal["stop", "length", "content_filter", "tool_calls"] | None = None


class ChatCompletionChunk(BaseModel):
    """Streaming chat completion chunk."""

    id: str
    object: Literal["chat.completion.chunk"] = "chat.completion.chunk"
    created: int
    model: str
    choices: list[ChatCompletionChunkChoice]


class GenerateRequest(BaseModel):
    """Legacy GenerateRequest for backward compatibility."""

    model: str
    prompt: str
    max_tokens: int | None = Field(default=150)
    temperature: float | None = Field(default=0.7)
    top_p: float | None = Field(default=0.9)
    stop: list[str] | None = None
    request_id: str | None = None


class GenerateResponse(BaseModel):
    """Legacy GenerateResponse for backward compatibility."""

    id: str
    model: str
    content: str
    usage: TokenUsage
    created_at: str
    processing_time_ms: int


# ============================================================================
# VOICE / AUDIO TYPES
# ============================================================================


class TTSVoice(str, Enum):
    """Available TTS voices."""

    ALLOY = "alloy"
    ECHO = "echo"
    FABLE = "fable"
    ONYX = "onyx"
    NOVA = "nova"
    SHIMMER = "shimmer"
    AF_BELLA = "af_bella"
    AF_SARAH = "af_sarah"
    AM_ADAM = "am_adam"
    AM_MICHAEL = "am_michael"
    BF_EMMA = "bf_emma"
    BF_ISABELLA = "bf_isabella"
    BM_GEORGE = "bm_george"
    BM_LEWIS = "bm_lewis"


class STTModel(str, Enum):
    """Available STT models."""

    WHISPER_LARGE_V3_TURBO = "whisper-large-v3-turbo"
    OPENAI_WHISPER_LARGE_V3_TURBO = "openai/whisper-large-v3-turbo"
    STT_1B_EN_FR = "stt-1b-en_fr"
    KYUTAI_STT_1B_EN_FR = "kyutai/stt-1b-en_fr"
    WHISPER_1 = "whisper-1"


class AudioFormat(str, Enum):
    """Available audio formats."""

    MP3 = "mp3"
    OPUS = "opus"
    AAC = "aac"
    FLAC = "flac"
    WAV = "wav"
    PCM = "pcm"


class TranscriptionFormat(str, Enum):
    """Response format for transcription/translation."""

    JSON = "json"
    TEXT = "text"
    SRT = "srt"
    VTT = "vtt"
    VERBOSE_JSON = "verbose_json"


class TextToSpeechRequest(BaseModel):
    """Parameters for text-to-speech requests."""

    model: Literal[
        "tts-1",
        "tts-1-hd",
        "kokoro-82m",
        "hexgrad/Kokoro-82M",
        "tada-3b-ml",
        "HumeAI/tada-3b-ml",
    ]
    input: str = Field(..., max_length=4096, description="Text to convert to speech")
    voice: TTSVoice | str
    response_format: AudioFormat | str = Field(default=AudioFormat.MP3)
    speed: float = Field(default=1.0, ge=0.25, le=4.0)


class TranscriptionRequest(BaseModel):
    """Parameters for speech-to-text transcription."""

    model: STTModel | str
    language: str | None = Field(default=None, description="ISO-639-1 language code")
    prompt: str | None = Field(default=None, description="Context hint to guide model")
    response_format: TranscriptionFormat | str = Field(default=TranscriptionFormat.JSON)
    temperature: float | None = Field(default=None, ge=0.0, le=1.0)


class TranscriptionResponse(BaseModel):
    """Simple transcription response (json format)."""

    text: str


class TranscriptionSegment(BaseModel):
    """A segment in a verbose transcription."""

    id: int
    seek: int
    start: float
    end: float
    text: str
    tokens: list[int]
    temperature: float
    avg_logprob: float
    compression_ratio: float
    no_speech_prob: float


class VerboseTranscriptionResponse(BaseModel):
    """Detailed transcription response (verbose_json format)."""

    task: Literal["transcribe"]
    language: str
    duration: float
    text: str
    segments: list[TranscriptionSegment]


class TranslationRequest(BaseModel):
    """Parameters for speech-to-text translation (to English)."""

    model: STTModel | str
    prompt: str | None = Field(default=None)
    response_format: TranscriptionFormat | str = Field(default=TranscriptionFormat.JSON)
    temperature: float | None = Field(default=None, ge=0.0, le=1.0)


class TranslationResponse(BaseModel):
    """Translation response."""

    text: str


# ============================================================================
# MODEL MANAGEMENT TYPES
# ============================================================================


class ModelPricing(BaseModel):
    """Pricing information for a model."""

    input_tokens: float = Field(..., description="Cost per 1k input tokens")
    output_tokens: float = Field(..., description="Cost per 1k output tokens")
    unit: str = Field(default="per_1k_tokens")


class ModelInfo(BaseModel):
    """Information about available models."""

    id: str
    object: Literal["model"] = "model"
    created: int
    owned_by: str
    permission: list[Any] = Field(default_factory=list)
    root: str
    parent: str | None = None
    pg_model_type: Literal["text-generation", "chat", "embedding", "image-generation"] | None = None
    pg_parameters: int | None = None
    pg_regions: list[str] | None = None
    pg_avg_latency_ms: int | None = None
    pg_max_tokens: int | None = None
    pg_pricing: ModelPricing | None = None


class ListModelsResponse(BaseModel):
    """List of available models response."""

    object: Literal["list"] = "list"
    data: list[ModelInfo]


class LoadModelRequest(BaseModel):
    """Parameters for loading a model."""

    model_name: str
    force_reload: bool = False


class LoadModelResponse(BaseModel):
    """Response from model load request."""

    status: Literal["success", "loading", "failed"]
    model: str
    force_reload: bool
    message: str


class UnloadModelRequest(BaseModel):
    """Parameters for unloading a model."""

    model_name: str


class UnloadModelResponse(BaseModel):
    """Response from model unload request."""

    status: Literal["success", "failed"]
    model: str
    message: str


class UnloadAllModelsResponse(BaseModel):
    """Response from unload all models request."""

    status: Literal["success", "partial", "failed"]
    unloaded_models: list[str]
    errors: list[str]
    total_unloaded: int


class ModelStatusResponse(BaseModel):
    """Model loading status."""

    loaded: list[str]
    loading_status: dict[str, Literal["loaded", "loading", "unloaded", "failed"]]
    repository: str


# ============================================================================
# GPU MANAGEMENT TYPES
# ============================================================================


class GPUMemoryInfo(BaseModel):
    """GPU memory information."""

    total_mb: int
    used_mb: int
    free_mb: int
    total_gb: float
    used_gb: float
    free_gb: float
    percent_used: float


class GPUUtilization(BaseModel):
    """GPU utilization information."""

    gpu_percent: int
    memory_percent: int


class GPUProcess(BaseModel):
    """GPU process information."""

    pid: int
    name: str
    memory_mb: int


class GPUInfo(BaseModel):
    """Single GPU status."""

    index: int
    name: str
    memory: GPUMemoryInfo
    utilization: GPUUtilization
    temperature_c: int


class GPUStatusResponse(BaseModel):
    """Full GPU status response."""

    status: Literal["success"]
    timestamp: str
    gpus: list[GPUInfo]
    processes: list[GPUProcess]
    total_gpus: int


class GPUMemorySimple(BaseModel):
    """Simplified GPU memory info."""

    total_gb: float
    used_gb: float
    free_gb: float
    percent_used: float
    percent_free: float


class GPUMemoryResponse(BaseModel):
    """Simplified GPU memory response."""

    status: Literal["success"]
    timestamp: str
    memory: list[GPUMemorySimple]


class GPUPurgeRequest(BaseModel):
    """Parameters for GPU purge request."""

    force: bool = False


class GPUMemoryState(BaseModel):
    """Memory state before/after purge."""

    used_gb: float
    total_gb: float
    percent_used: float


class GPUPurgeResponse(BaseModel):
    """Response from GPU purge request."""

    status: Literal["success", "partial", "failed"]
    timestamp: str
    actions: list[str]
    memory_before: GPUMemoryState
    memory_after: GPUMemoryState
    memory_freed_gb: float
    models_unloaded: list[str]
    errors: list[str]
    recommendation: str


# ============================================================================
# HEALTH CHECK TYPES
# ============================================================================


class HealthFeatures(BaseModel):
    """Enabled features in health check."""

    text_inference: bool
    voice: bool
    dynamic_loading: bool
    streaming: bool


class BackendInfo(BaseModel):
    """Backend information in health check."""

    models_loaded: int
    gpu_available: bool


class BackendStatus(BaseModel):
    """Backend status in health check."""

    url: str
    healthy: bool
    info: BackendInfo


class HealthResponse(BaseModel):
    """Health check response."""

    status: Literal["healthy", "degraded", "unhealthy"]
    service: str
    runtime: str
    timestamp: str
    features: HealthFeatures
    backend: BackendStatus


# ============================================================================
# EMBEDDING TYPES
# ============================================================================


class EmbeddingRequest(BaseModel):
    """Parameters for embedding requests."""

    model: str = Field(..., description="Model to use for embedding generation")
    input: str | list[str] = Field(..., description="Text input(s) to embed")
    user: str | None = Field(default=None, description="End-user identifier")


class EmbeddingData(BaseModel):
    """A single embedding result."""

    object: Literal["embedding"] = "embedding"
    index: int
    embedding: list[float]


class EmbeddingResponse(BaseModel):
    """Response from embedding requests."""

    object: Literal["list"] = "list"
    data: list[EmbeddingData]
    model: str
    usage: TokenUsage


# ============================================================================
# SYSTEM STATUS TYPES
# ============================================================================


class RegionModelStatus(BaseModel):
    """Model status within a region."""

    model_id: str
    status: Literal["available", "loading", "unavailable"]
    instances: int
    avg_latency_ms: int
    queue_depth: int


class RegionStatus(BaseModel):
    """Status of a single region."""

    region: str
    status: Literal["healthy", "degraded", "unavailable"]
    models: list[RegionModelStatus] = Field(default_factory=list)


class SystemStatus(BaseModel):
    """Full system status response."""

    status: Literal["healthy", "degraded", "unavailable"]
    regions: list[RegionStatus] = Field(default_factory=list)


# ============================================================================
# USAGE TYPES
# ============================================================================


class ModelUsage(BaseModel):
    """Usage breakdown by model."""

    model_id: str
    requests: int
    tokens: int
    cost: float


class RegionUsage(BaseModel):
    """Usage breakdown by region."""

    region: str
    requests: int
    avg_latency_ms: int


class UsagePeriod(BaseModel):
    """Usage query period."""

    start_date: str
    end_date: str


class UsageStats(BaseModel):
    """Usage statistics."""

    total_requests: int
    total_tokens: int
    total_cost: float
    by_model: list[ModelUsage] = Field(default_factory=list)
    by_region: list[RegionUsage] = Field(default_factory=list)


class UsageResponse(BaseModel):
    """Response from usage queries."""

    period: UsagePeriod
    usage: UsageStats


# ============================================================================
# ERROR TYPES
# ============================================================================


class ApiError(BaseModel):
    """Error response from the API."""

    code: str
    message: str
    details: dict[str, Any] | None = None
    request_id: str | None = None


# ============================================================================
# ASYNC TRANSCRIPTION TYPES
# ============================================================================


class TranscriptionJobStatus(str, Enum):
    """Job lifecycle states for async transcription."""

    ACCEPTED = "accepted"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AsyncTranscriptionMetadata(BaseModel):
    """Metadata returned when an async transcription job is created."""

    filename: str
    file_size_mb: float
    audio_format: str
    estimated_duration_seconds: float
    model: str


class AsyncTranscriptionJobAccepted(BaseModel):
    """Response from submitting an async transcription job."""

    job_id: str
    status: Literal["accepted"]
    message: str
    metadata: AsyncTranscriptionMetadata
    poll_url: str
    result_url: str


class TranscriptionJobInfo(BaseModel):
    """Status of an async transcription job."""

    job_id: str
    type: str = "transcription"
    status: TranscriptionJobStatus
    created_at: str
    updated_at: str
    started_at: str | None = None
    completed_at: str | None = None
    progress: float | None = None
    metadata: dict[str, Any] | None = None
    has_result: bool | None = None
    error: str | None = None
    error_code: str | None = None
    poll_interval_ms: int | None = None
    result_url: str | None = None


class TranscriptionJobResult(BaseModel):
    """Result of a completed transcription job."""

    job_id: str | None = None
    status: Literal["completed"] | None = None
    text: str
    language: str | None = None
    duration: float | None = None


class TranscriptionJobListResponse(BaseModel):
    """List of transcription jobs."""

    jobs: list[TranscriptionJobInfo]
    count: int