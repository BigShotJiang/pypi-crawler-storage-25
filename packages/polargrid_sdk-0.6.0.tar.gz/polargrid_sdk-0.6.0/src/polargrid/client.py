"""
PolarGrid SDK Client

The main client class for interacting with PolarGrid Edge AI Infrastructure.
"""

from __future__ import annotations

import asyncio
import json
import os
import random
import time
import urllib.parse
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any, AsyncIterator, BinaryIO, Iterator

import httpx
from pydantic import BaseModel, ValidationError as PydanticValidationError

from .errors import (
    AuthenticationError,
    NetworkError,
    PolarGridError,
    TimeoutError,
    ValidationError,
    create_error_from_response,
)

from .mock_data import (
    format_transcription,
    generate_mock_chat_completion,
    generate_mock_chat_completion_stream,
    generate_mock_completion,
    generate_mock_completion_stream,
    generate_mock_tts_stream,
    get_mock_gpu_memory,
    get_mock_gpu_purge,
    get_mock_gpu_status,
    get_mock_health,
    get_mock_load_model,
    get_mock_model_status,
    get_mock_models,
    get_mock_transcription,
    get_mock_translation,
    get_mock_tts_audio,
    get_mock_unload_all_models,
    get_mock_unload_model,
    get_mock_verbose_transcription,
)
from .types import (
    AsyncTranscriptionJobAccepted,
    ChatCompletionChunk,
    ChatCompletionRequest,
    ChatCompletionResponse,
    CompletionChunk,
    CompletionRequest,
    CompletionResponse,
    EmbeddingRequest,
    EmbeddingResponse,
    GenerateRequest,
    GenerateResponse,
    GPUMemoryResponse,
    GPUPurgeRequest,
    GPUPurgeResponse,
    GPUStatusResponse,
    HealthResponse,
    ListModelsResponse,
    LoadModelRequest,
    LoadModelResponse,
    Message,
    ModelInfo,
    ModelStatusResponse,
    SystemStatus,
    TextToSpeechRequest,
    TokenUsage,
    TranscriptionJobInfo,
    TranscriptionJobListResponse,
    TranscriptionJobResult,
    TranscriptionJobStatus,
    TranscriptionRequest,
    TranscriptionResponse,
    TranslationRequest,
    TranslationResponse,
    UnloadAllModelsResponse,
    UnloadModelRequest,
    UnloadModelResponse,
    UsageResponse,
    VerboseTranscriptionResponse,
)

if TYPE_CHECKING:
    pass

def _coerce_request(cls: type[BaseModel], request: Any) -> Any:
    """Coerce a dict into a pydantic request model, wrapping errors.

    Without this wrapper, callers who pass a dict with missing/invalid fields
    see raw pydantic `ValidationError`s, which don't pass `is_polargrid_error`.
    Surfacing everything through the SDK's own `ValidationError` keeps the
    public error contract stable.
    """
    if not isinstance(request, dict):
        return request
    try:
        return cls(**request)
    except PydanticValidationError as err:
        raise ValidationError(str(err)) from err


# SDK version — keep in sync with pyproject.toml
SDK_VERSION = "0.5.1"

# Available PolarGrid edge regions
POLARGRID_REGIONS = {
    'yto-01': {
        'id': 'yto-01',
        'name': 'Toronto',
        'url': 'https://api.yto-01.edge.polargrid.ai',
    },
    'yvr-02': {
        'id': 'yvr-02',
        'name': 'Vancouver',
        'url': 'https://api.yvr-02.edge.polargrid.ai',
    },
    'yul-01': {
        'id': 'yul-01',
        'name': 'Montreal',
        'url': 'https://api.yul-01.edge.polargrid.ai',
    },
}

# Region aliases for convenience (e.g., 'toronto' -> 'yto-01')
REGION_ALIASES = {
    'toronto': 'yto-01',
    'yto': 'yto-01',
    'vancouver': 'yvr-02',
    'yvr': 'yvr-02',
    'montreal': 'yul-01',
    'yul': 'yul-01',
}

AUTOROUTER_URL = 'https://autorouter.polargrid.ai'
DEFAULT_REGION = 'yto-01'

# In-process cache honoring the server's `max-age=3600` / `ttl`. Keyed by
# AUTOROUTER_URL so a hostname migration doesn't serve stale picks.
_REGION_CACHE: dict[str, tuple[dict[str, str], float]] = {}


def _read_cached_region(key: str) -> dict[str, str] | None:
    entry = _REGION_CACHE.get(key)
    if entry is None:
        return None
    pick, expires_at = entry
    if expires_at > time.time():
        return pick
    _REGION_CACHE.pop(key, None)
    return None


def _write_cached_region(key: str, pick: dict[str, str], ttl_seconds: float) -> None:
    if ttl_seconds <= 0:
        return
    _REGION_CACHE[key] = (pick, time.time() + ttl_seconds)


async def _discover_best_region(debug: bool = False) -> dict[str, str]:
    """Ask the autorouter which edge to use. Server is authoritative — no client probing.

    Wire shape owned by backend/route-service/internal/handler/route.go.
    """
    cache_key = AUTOROUTER_URL
    cached = _read_cached_region(cache_key)
    if cached is not None:
        if debug:
            print(f"[PolarGrid] Auto-routing: cache hit {cached['region_name']} ({cached['region_id']})")
        return cached

    try:
        if debug:
            print("[PolarGrid] Auto-routing: asking autorouter...")

        async with httpx.AsyncClient(timeout=2.0) as client:
            response = await client.get(
                f"{AUTOROUTER_URL}/v1/route",
                headers={'Accept': 'application/json'},
            )

            if response.status_code != 200:
                if debug:
                    print(f"[PolarGrid] Auto-routing: HTTP {response.status_code}, falling back")
            else:
                # 200 with HTML/text body would raise here — distinguish from network error.
                try:
                    pick = response.json()
                except json.JSONDecodeError as je:
                    if debug:
                        print(f"[PolarGrid] Auto-routing: 200 but non-JSON body, falling back: {je}")
                    pick = None

                if pick is not None:
                    region = pick.get('region')
                    endpoint = pick.get('endpoint')
                    name = pick.get('name', region)
                    if region and endpoint:
                        if debug:
                            print(f"[PolarGrid] Auto-routing: server picked {name} ({region})")
                        result = {
                            'endpoint': endpoint,
                            'region_id': region,
                            'region_name': name,
                        }
                        ttl = pick.get('ttl')
                        ttl_seconds = float(ttl) if isinstance(ttl, (int, float)) and ttl > 0 else 3600.0
                        _write_cached_region(cache_key, result, ttl_seconds)
                        return result
                    if debug:
                        print(f"[PolarGrid] Auto-routing: response missing region/endpoint, falling back: {pick}")

    except Exception as e:
        if debug:
            print(f"[PolarGrid] Auto-routing: discovery failed, using fallback: {e}")

    # Last-resort fallback when the autorouter is unreachable.
    fallback = POLARGRID_REGIONS[DEFAULT_REGION]
    if debug:
        print(f"[PolarGrid] Auto-routing: using fallback region {fallback['name']} ({DEFAULT_REGION})")
    return {
        'endpoint': fallback['url'],
        'region_id': DEFAULT_REGION,
        'region_name': fallback['name'],
    }


class PolarGrid:
    """
    PolarGrid async client for interacting with the Edge AI Infrastructure API.

    Example:
        >>> from polargrid import PolarGrid
        >>> # Auto-select best region by latency
        >>> client = await PolarGrid.create(api_key="your-api-key")
        >>> # Or specify a region directly
        >>> client = PolarGrid(api_key="your-api-key", region="vancouver")
        >>> response = await client.chat_completion({
        ...     "model": "Meta-Llama-3.1-8B-Instruct",
        ...     "messages": [{"role": "user", "content": "Hello!"}],
        ... })
    """

    @classmethod
    async def create(
        cls,
        api_key: str | None = None,
        base_url: str | None = None,
        auth_url: str | None = None,
        region: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        debug: bool = False,
        use_mock_data: bool = False,
    ) -> "PolarGrid":
        """
        Create a PolarGrid client with automatic region selection.
        This is the recommended way to create a client when you want auto-routing.
        """
        if region or base_url:
            return cls(
                api_key=api_key,
                base_url=base_url,
                auth_url=auth_url,
                region=region,
                timeout=timeout,
                max_retries=max_retries,
                debug=debug,
                use_mock_data=use_mock_data,
            )

        result = await _discover_best_region(debug)

        client = cls(
            api_key=api_key,
            base_url=result['endpoint'],
            auth_url=auth_url,
            timeout=timeout,
            max_retries=max_retries,
            debug=debug,
            use_mock_data=use_mock_data,
        )

        client._resolved_region_id = result['region_id']
        client._resolved_region_name = result['region_name']

        return client

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        auth_url: str | None = None,
        region: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        debug: bool = False,
        use_mock_data: bool = False,
    ) -> None:
        """
        Initialize the PolarGrid client.

        For automatic region selection based on latency, use `await PolarGrid.create()` instead.
        """
        self._api_key = api_key or os.environ.get("POLARGRID_API_KEY", "")
        self._resolved_region_id: str | None = None
        self._resolved_region_name: str | None = None

        if base_url:
            self._base_url = base_url
        elif region:
            resolved_region = REGION_ALIASES.get(region.lower(), region)
            region_config = POLARGRID_REGIONS.get(resolved_region)
            if region_config:
                self._base_url = region_config['url']
                self._resolved_region_id = resolved_region
                self._resolved_region_name = region_config['name']
            else:
                self._base_url = f"https://api.{resolved_region}.edge.polargrid.ai"
                self._resolved_region_id = resolved_region
        else:
            env_url = os.environ.get("POLARGRID_BASE_URL") or os.environ.get("NEXT_PUBLIC_INFERENCE_URL")
            if env_url:
                self._base_url = env_url
            else:
                default_region = POLARGRID_REGIONS[DEFAULT_REGION]
                self._base_url = default_region['url']
                self._resolved_region_id = DEFAULT_REGION
                self._resolved_region_name = default_region['name']

        # Auth flows go directly to auth-service. Legacy
        # app.polargrid.ai/api/auth/inference-token proxy was removed.
        self._auth_url = auth_url or os.environ.get(
            "POLARGRID_AUTH_URL", "https://auth.polargrid.ai/v1/auth/session"
        )
        self._refresh_url = os.environ.get(
            "POLARGRID_REFRESH_URL",
            self._auth_url.replace("/session", "/refresh"),
        )
        self._timeout = timeout
        self._max_retries = max_retries
        self._debug = debug
        self._use_mock_data = use_mock_data

        self._jwt_token: str | None = None
        self._refresh_token: str | None = None
        self._session_id: str | None = None
        self._jwt_expiry: float | None = None

        if not self._use_mock_data and not self._api_key:
            if self._debug:
                print("[PolarGrid] No API key provided. Some endpoints may require authentication.")

        if self._debug:
            print(
                f"[PolarGrid] Client initialized: base_url={self._base_url}, "
                f"auth_url={self._auth_url}, region={self._resolved_region_id}, "
                f"timeout={self._timeout}, max_retries={self._max_retries}, "
                f"use_mock_data={self._use_mock_data}"
            )

    def get_region_id(self) -> str | None:
        """Get the currently connected region ID."""
        return self._resolved_region_id

    def get_region_name(self) -> str | None:
        """Get the currently connected region name."""
        return self._resolved_region_name

    # ============================================================================
    # TEXT INFERENCE METHODS
    # ============================================================================

    async def completion(self, request: CompletionRequest | dict[str, Any]) -> CompletionResponse:
        """
        Generate text completion.

        POST /v1/completions
        """
        request = _coerce_request(CompletionRequest, request)

        self._validate_completion_request(request)

        if self._use_mock_data:
            await self._simulate_delay(0.5, 1.5)
            return generate_mock_completion(request)

        body = {
            "prompt": request.prompt,
            "model": request.model or "gpt2",
            "max_tokens": request.max_tokens or 100,
            "temperature": request.temperature or 0.7,
            "top_p": request.top_p or 0.9,
            "top_k": request.top_k or 50,
            "frequency_penalty": request.frequency_penalty or 0.0,
            "presence_penalty": request.presence_penalty or 0.0,
            "stop": request.stop,
            "user": request.user,
        }

        response = await self._make_request("/v1/completions", method="POST", body=body)
        return self._convert_completion_response(response)

    async def completion_stream(
        self, request: CompletionRequest | dict[str, Any]
    ) -> AsyncIterator[CompletionChunk]:
        """Generate streaming text completion."""
        request = _coerce_request(CompletionRequest, request)

        self._validate_completion_request(request)

        if self._use_mock_data:
            for chunk in generate_mock_completion_stream(request):
                await self._simulate_delay(0.05, 0.15)
                yield chunk
            return

        body = {
            "prompt": request.prompt,
            "model": request.model or "gpt2",
            "max_tokens": request.max_tokens or 100,
            "temperature": request.temperature or 0.7,
            "top_p": request.top_p or 0.9,
            "top_k": request.top_k or 50,
            "frequency_penalty": request.frequency_penalty or 0.0,
            "presence_penalty": request.presence_penalty or 0.0,
            "stop": request.stop,
            "user": request.user,
        }
        body = {k: v for k, v in body.items() if v is not None}

        async for raw in self._stream_post("/v1/completions/stream", body):
            if "error" in raw:
                raise NetworkError(
                    raw["error"].get("message", "stream error"), None, None
                )
            try:
                yield CompletionChunk(**raw)
            except PydanticValidationError:
                if self._debug:
                    print(f"[PolarGrid] Skipping unparseable chunk: {raw}")
                continue

    async def chat_completion(
        self, request: ChatCompletionRequest | dict[str, Any]
    ) -> ChatCompletionResponse:
        """Generate chat completion."""
        if isinstance(request, dict):
            try:
                if "messages" in request:
                    request["messages"] = [
                        Message(**m) if isinstance(m, dict) else m for m in request["messages"]
                    ]
                request = ChatCompletionRequest(**request)
            except PydanticValidationError as err:
                raise ValidationError(str(err)) from err

        self._validate_chat_completion_request(request)

        if self._use_mock_data:
            await self._simulate_delay(0.5, 1.5)
            return generate_mock_chat_completion(request)

        body = self._build_chat_completion_body(request, stream_override=False)
        response = await self._make_request("/v1/chat/completions", method="POST", body=body)
        return self._convert_chat_completion_response(response)

    def _build_chat_completion_body(
        self, request: "ChatCompletionRequest", *, stream_override: bool
    ) -> dict[str, Any]:
        """Serialize the chat-completion request for the gateway.

        Forwards the full extended OpenAI surface (tools, response_format,
        seed, repetition controls). Uses ``model_dump(exclude_none=True)``
        on each Message so prior-turn ``tool_calls`` / ``tool_call_id``
        survive the round trip — a plain ``{role, content}`` projection
        breaks multi-turn tool conversations.
        """
        body = {
            "model": request.model,
            "messages": [m.model_dump(exclude_none=True) for m in request.messages],
            "max_tokens": request.max_tokens or 150,
            "temperature": request.temperature or 0.7,
            "top_p": request.top_p or 0.9,
            "top_k": request.top_k,
            "frequency_penalty": request.frequency_penalty,
            "presence_penalty": request.presence_penalty,
            "stop": request.stop,
            "stream": stream_override or (request.stream or False),
            "user": request.user,
            "tools": [t.model_dump(exclude_none=True) for t in request.tools] if request.tools else None,
            "tool_choice": request.tool_choice,
            "response_format": request.response_format.model_dump(exclude_none=True) if request.response_format else None,
            "seed": request.seed,
            "repetition_penalty": request.repetition_penalty,
            "min_p": request.min_p,
        }
        # Drop None values so we don't override gateway defaults with nulls.
        return {k: v for k, v in body.items() if v is not None}

    async def chat_completion_stream(
        self, request: ChatCompletionRequest | dict[str, Any]
    ) -> AsyncIterator[ChatCompletionChunk]:
        """Generate streaming chat completion."""
        if isinstance(request, dict):
            try:
                if "messages" in request:
                    request["messages"] = [
                        Message(**m) if isinstance(m, dict) else m for m in request["messages"]
                    ]
                request = ChatCompletionRequest(**request)
            except PydanticValidationError as err:
                raise ValidationError(str(err)) from err

        self._validate_chat_completion_request(request)

        if self._use_mock_data:
            for chunk in generate_mock_chat_completion_stream(request):
                await self._simulate_delay(0.05, 0.15)
                yield chunk
            return

        body = self._build_chat_completion_body(request, stream_override=True)

        async for raw in self._stream_post("/v1/chat/completions", body):
            if "error" in raw:
                raise NetworkError(
                    raw["error"].get("message", "stream error"), None, None
                )
            try:
                yield ChatCompletionChunk(**raw)
            except PydanticValidationError:
                if self._debug:
                    print(f"[PolarGrid] Skipping unparseable chunk: {raw}")
                continue

    async def generate(self, request: GenerateRequest | dict[str, Any]) -> GenerateResponse:
        """Legacy generate method (maps to chat_completion)."""
        request = _coerce_request(GenerateRequest, request)

        chat_request = ChatCompletionRequest(
            model=request.model,
            messages=[Message(role="user", content=request.prompt)],
            max_tokens=request.max_tokens or 150,
            temperature=request.temperature or 0.7,
            top_p=request.top_p or 0.9,
            stop=request.stop,
        )

        start_time = time.time()
        response = await self.chat_completion(chat_request)
        processing_time = int((time.time() - start_time) * 1000)

        from datetime import datetime

        return GenerateResponse(
            id=response.id,
            model=response.model,
            content=response.choices[0].message.content if response.choices else "",
            usage=response.usage,
            created_at=datetime.fromtimestamp(response.created).isoformat(),
            processing_time_ms=processing_time,
        )

    # ============================================================================
    # VOICE / AUDIO METHODS
    # ============================================================================

    async def text_to_speech(self, request: TextToSpeechRequest | dict[str, Any]) -> bytes:
        """Convert text to speech."""
        request = _coerce_request(TextToSpeechRequest, request)

        self._validate_tts_request(request)

        if self._use_mock_data:
            await self._simulate_delay(1.0, 2.0)
            voice = request.voice.value if hasattr(request.voice, "value") else str(request.voice)
            fmt = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else str(request.response_format)
            )
            return get_mock_tts_audio(request.input, voice, fmt)

        body = {
            "model": request.model,
            "input": request.input,
            "voice": request.voice.value if hasattr(request.voice, "value") else request.voice,
            "response_format": (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else request.response_format
            ),
            "speed": request.speed or 1.0,
        }

        return await self._make_raw_request("/v1/audio/speech", method="POST", body=body)

    async def text_to_speech_stream(
        self, request: TextToSpeechRequest | dict[str, Any]
    ) -> AsyncIterator[bytes]:
        """Convert text to speech with streaming."""
        request = _coerce_request(TextToSpeechRequest, request)

        self._validate_tts_request(request)

        if self._use_mock_data:
            voice = request.voice.value if hasattr(request.voice, "value") else str(request.voice)
            fmt = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else str(request.response_format)
            )
            for chunk in generate_mock_tts_stream(request.input, voice, fmt):
                await self._simulate_delay(0.1, 0.3)
                yield chunk
            return

        raise NotImplementedError("Streaming TTS not yet implemented for production API")

    async def transcribe(
        self,
        file: BinaryIO | bytes | Path,
        request: TranscriptionRequest | dict[str, Any],
    ) -> TranscriptionResponse | VerboseTranscriptionResponse | str:
        """Transcribe audio to text."""
        request = _coerce_request(TranscriptionRequest, request)

        self._validate_transcription_request(request)

        if self._use_mock_data:
            await self._simulate_delay(1.0, 3.0)

            filename = None
            if isinstance(file, Path):
                filename = file.name

            fmt = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else str(request.response_format)
            )

            if fmt == "verbose_json":
                return get_mock_verbose_transcription(filename)
            elif fmt == "json":
                return get_mock_transcription(filename)
            else:
                verbose = get_mock_verbose_transcription(filename)
                return format_transcription(verbose, fmt)

        files = self._prepare_file(file, "file")
        data = {
            "model": request.model.value if hasattr(request.model, "value") else request.model,
        }
        if request.language:
            data["language"] = request.language
        if request.prompt:
            data["prompt"] = request.prompt
        if request.response_format:
            data["response_format"] = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else request.response_format
            )
        if request.temperature is not None:
            data["temperature"] = str(request.temperature)

        response = await self._make_multipart_request(
            "/v1/audio/transcriptions", files=files, data=data
        )

        fmt = (
            request.response_format.value
            if hasattr(request.response_format, "value")
            else str(request.response_format or "json")
        )

        if fmt in ("text", "srt", "vtt"):
            return response
        elif fmt == "verbose_json":
            return VerboseTranscriptionResponse(**response)
        else:
            return TranscriptionResponse(**response)

    async def translate(
        self,
        file: BinaryIO | bytes | Path,
        request: TranslationRequest | dict[str, Any],
    ) -> TranslationResponse | str:
        """Translate audio to English text."""
        request = _coerce_request(TranslationRequest, request)

        self._validate_translation_request(request)

        if self._use_mock_data:
            await self._simulate_delay(1.0, 3.0)

            filename = None
            if isinstance(file, Path):
                filename = file.name

            fmt = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else str(request.response_format)
            )

            if fmt == "json":
                return get_mock_translation(filename)
            else:
                translation = get_mock_translation(filename)
                return translation.text

        files = self._prepare_file(file, "file")
        data = {
            "model": request.model.value if hasattr(request.model, "value") else request.model,
        }
        if request.prompt:
            data["prompt"] = request.prompt
        if request.response_format:
            data["response_format"] = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else request.response_format
            )
        if request.temperature is not None:
            data["temperature"] = str(request.temperature)

        response = await self._make_multipart_request(
            "/v1/audio/translations", files=files, data=data
        )

        fmt = (
            request.response_format.value
            if hasattr(request.response_format, "value")
            else str(request.response_format or "json")
        )

        if fmt == "text":
            return response
        return TranslationResponse(**response)

    # ============================================================================
    # ASYNC TRANSCRIPTION METHODS
    # ============================================================================

    async def transcribe_async(
        self,
        file: BinaryIO | bytes | Path,
        model: str = "stt-1b-en_fr",
        language: str | None = None,
        prompt: str | None = None,
        response_format: str = "json",
        temperature: float | None = None,
    ) -> AsyncTranscriptionJobAccepted:
        """
        Submit audio for async transcription. Returns job_id immediately.

        POST /v1/audio/transcriptions/async

        Args:
            file: Audio file (bytes, file-like object, or Path).
            model: STT model to use.
            language: ISO-639-1 language code.
            prompt: Context hint for the model.
            response_format: Output format (json, text, verbose_json).
            temperature: Sampling temperature.

        Returns:
            AsyncTranscriptionJobAccepted with job_id and polling URLs.

        Example::

            job = await client.transcribe_async(
                file=Path("recording.mp3"),
                language="en",
            )
            print(job.job_id)
        """
        files = self._prepare_file(file, "file")
        data: dict[str, str] = {"model": model, "response_format": response_format}
        if language:
            data["language"] = language
        if prompt:
            data["prompt"] = prompt
        if temperature is not None:
            data["temperature"] = str(temperature)

        response = await self._make_multipart_request(
            "/v1/audio/transcriptions/async", files=files, data=data
        )

        return AsyncTranscriptionJobAccepted(**response)

    async def get_transcription_job(self, job_id: str) -> TranscriptionJobInfo:
        """
        Get status of an async transcription job.

        GET /v1/audio/transcriptions/jobs/{job_id}
        """
        response = await self._make_request(f"/v1/audio/transcriptions/jobs/{job_id}")
        return TranscriptionJobInfo(**response)

    async def get_transcription_result(self, job_id: str) -> TranscriptionJobResult:
        """
        Get result of a completed transcription job.

        GET /v1/audio/transcriptions/jobs/{job_id}/result
        """
        response = await self._make_request(f"/v1/audio/transcriptions/jobs/{job_id}/result")
        return TranscriptionJobResult(**response)

    async def list_transcription_jobs(
        self,
        status: str | None = None,
        limit: int = 50,
    ) -> TranscriptionJobListResponse:
        """
        List transcription jobs.

        GET /v1/audio/transcriptions/jobs
        """
        params = []
        if status:
            params.append(f"status={status}")
        if limit != 50:
            params.append(f"limit={limit}")
        qs = f"?{'&'.join(params)}" if params else ""

        response = await self._make_request(f"/v1/audio/transcriptions/jobs{qs}")
        return TranscriptionJobListResponse(**response)

    async def transcribe_and_wait(
        self,
        file: BinaryIO | bytes | Path,
        model: str = "stt-1b-en_fr",
        language: str | None = None,
        prompt: str | None = None,
        response_format: str = "json",
        temperature: float | None = None,
        poll_interval: float = 1.0,
        timeout: float = 600.0,
        on_progress: Any = None,
    ) -> TranscriptionJobResult:
        """
        Submit async transcription and wait for result.

        Args:
            file: Audio file.
            model: STT model.
            language: Language code.
            prompt: Context hint.
            response_format: Output format.
            temperature: Sampling temperature.
            poll_interval: Seconds between polls (default 1.0).
            timeout: Max seconds to wait (default 600).
            on_progress: Optional callback(TranscriptionJobInfo) on each poll.

        Returns:
            TranscriptionJobResult with transcribed text.

        Raises:
            TimeoutError: If job doesn't complete within timeout.
            RuntimeError: If job fails or is cancelled.

        Example::

            result = await client.transcribe_and_wait(
                file=Path("long_recording.mp3"),
                on_progress=lambda j: print(f"{j.status}: {(j.progress or 0)*100:.0f}%"),
            )
            print(result.text)
        """
        job = await self.transcribe_async(
            file=file,
            model=model,
            language=language,
            prompt=prompt,
            response_format=response_format,
            temperature=temperature,
        )
        job_id = job.job_id

        import time as _time
        start = _time.time()

        while True:
            elapsed = _time.time() - start
            if elapsed > timeout:
                raise TimeoutError(f"Transcription job {job_id} timed out after {timeout:.0f}s")

            await asyncio.sleep(poll_interval)

            info = await self.get_transcription_job(job_id)
            if on_progress:
                on_progress(info)

            if info.status == TranscriptionJobStatus.COMPLETED:
                return await self.get_transcription_result(job_id)
            elif info.status == TranscriptionJobStatus.FAILED:
                raise RuntimeError(
                    f"Transcription failed: {info.error or 'Unknown error'} ({info.error_code or 'unknown'})"
                )
            elif info.status == TranscriptionJobStatus.CANCELLED:
                raise RuntimeError(f"Transcription job {job_id} was cancelled")

            if info.poll_interval_ms and info.poll_interval_ms / 1000 > poll_interval:
                await asyncio.sleep((info.poll_interval_ms / 1000) - poll_interval)

    # ============================================================================
    # MODEL MANAGEMENT METHODS
    # ============================================================================

    async def list_models(self) -> ListModelsResponse:
        """List available models."""
        if self._use_mock_data:
            await self._simulate_delay(0.2, 0.5)
            return get_mock_models()

        response = await self._make_request("/v1/models")
        return ListModelsResponse(**response)

    async def load_model(self, request: LoadModelRequest | dict[str, Any]) -> LoadModelResponse:
        """Load a model."""
        request = _coerce_request(LoadModelRequest, request)

        if not request.model_name:
            raise ValidationError("Model name is required")

        if self._use_mock_data:
            await self._simulate_delay(0.5, 2.0)
            return get_mock_load_model(request.model_name, request.force_reload)

        body = {
            "model_name": request.model_name,
            "force_reload": request.force_reload,
        }

        response = await self._make_request("/v1/models/load", method="POST", body=body)
        return LoadModelResponse(
            status=response["status"],
            model=response["model"],
            force_reload=response.get("force_reload", False),
            message=response["message"],
        )

    async def unload_model(
        self, request: UnloadModelRequest | dict[str, Any]
    ) -> UnloadModelResponse:
        """Unload a model."""
        request = _coerce_request(UnloadModelRequest, request)

        if not request.model_name:
            raise ValidationError("Model name is required")

        if self._use_mock_data:
            await self._simulate_delay(0.3, 0.8)
            return get_mock_unload_model(request.model_name)

        body = {"model_name": request.model_name}

        response = await self._make_request("/v1/models/unload", method="POST", body=body)
        return UnloadModelResponse(
            status=response["status"],
            model=response["model"],
            message=response["message"],
        )

    async def unload_all_models(self) -> UnloadAllModelsResponse:
        """Unload all models."""
        if self._use_mock_data:
            await self._simulate_delay(0.5, 1.5)
            return get_mock_unload_all_models()

        response = await self._make_request("/v1/models/unload-all", method="POST")
        return UnloadAllModelsResponse(
            status=response["status"],
            unloaded_models=response.get("unloaded_models", []),
            errors=response.get("errors", []),
            total_unloaded=response.get("total_unloaded", 0),
        )

    async def get_model_status(self) -> ModelStatusResponse:
        """Get model loading status."""
        if self._use_mock_data:
            await self._simulate_delay(0.2, 0.5)
            return get_mock_model_status()

        response = await self._make_request("/v1/models/status")
        return ModelStatusResponse(
            loaded=response.get("loaded", []),
            loading_status=response.get("loading_status", {}),
            repository=response.get("repository", "/models"),
        )

    # ============================================================================
    # GPU MANAGEMENT METHODS
    # ============================================================================

    async def get_gpu_status(self) -> GPUStatusResponse:
        """Get detailed GPU status."""
        if self._use_mock_data:
            await self._simulate_delay(0.2, 0.5)
            return get_mock_gpu_status()

        response = await self._make_request("/v1/gpu/status")
        return self._convert_gpu_status_response(response)

    async def get_gpu_memory(self) -> GPUMemoryResponse:
        """Get simplified GPU memory info."""
        if self._use_mock_data:
            await self._simulate_delay(0.2, 0.5)
            return get_mock_gpu_memory()

        response = await self._make_request("/v1/gpu/memory")
        return self._convert_gpu_memory_response(response)

    async def purge_gpu(
        self, request: GPUPurgeRequest | dict[str, Any] | None = None
    ) -> GPUPurgeResponse:
        """Purge GPU memory."""
        if request is None:
            request = GPUPurgeRequest()
        else:
            request = _coerce_request(GPUPurgeRequest, request)

        if self._use_mock_data:
            await self._simulate_delay(1.0, 3.0)
            return get_mock_gpu_purge(request.force)

        body = {"force": request.force}

        response = await self._make_request("/v1/gpu/purge", method="POST", body=body)
        return self._convert_gpu_purge_response(response)

    # ============================================================================
    # HEALTH CHECK METHODS
    # ============================================================================

    async def health(self) -> HealthResponse:
        """Check API health."""
        if self._use_mock_data:
            await self._simulate_delay(0.1, 0.3)
            return get_mock_health(True)

        response = await self._make_request("/health")
        return self._convert_health_response(response)

    # ============================================================================
    # MODEL DETAILS
    # ============================================================================

    async def get_model(self, model_id: str) -> ModelInfo:
        """Get details for a specific model."""
        if not model_id:
            raise ValidationError("Model ID is required")

        response = await self._make_request(f"/v1/models/{urllib.parse.quote(model_id, safe='')}")
        return ModelInfo(**response)

    # ============================================================================
    # EMBEDDINGS
    # ============================================================================

    async def embeddings(self, request: EmbeddingRequest) -> EmbeddingResponse:
        """Create embeddings for text inputs."""
        if not request.model:
            raise ValidationError("Model is required")
        if not request.input:
            raise ValidationError("Input is required")

        body = {
            "model": request.model,
            "input": request.input,
        }
        if request.user:
            body["user"] = request.user

        response = await self._make_request("/v1/embeddings", method="POST", body=body)
        return self._convert_embedding_response(response)

    # ============================================================================
    # SYSTEM STATUS
    # ============================================================================

    async def get_status(self) -> SystemStatus:
        """Get detailed system status across all edge locations."""
        response = await self._make_request("/v1/status")
        return self._convert_system_status(response)

    # ============================================================================
    # USAGE
    # ============================================================================

    async def get_usage(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> UsageResponse:
        """Get usage statistics for your API key."""
        params: list[str] = []
        if start_date:
            params.append(f"start_date={start_date}")
        if end_date:
            params.append(f"end_date={end_date}")
        qs = "&".join(params)

        response = await self._make_request(f"/v1/usage{'?' + qs if qs else ''}")
        return UsageResponse(**response)

    # ============================================================================
    # SESSION TOKEN PERSISTENCE
    # ============================================================================

    def get_refresh_token(self) -> str | None:
        """Return the current refresh token, or None if no session minted yet.

        Refresh tokens are NOT persisted across client instances by default —
        the caller is responsible for storing them (disk, keystore, cookie)
        and seeding a fresh client via :meth:`set_refresh_token`.
        """
        return self._refresh_token

    def set_refresh_token(self, refresh_token: str | None) -> None:
        """Seed the client with a previously-saved refresh token.

        The next request that needs a session JWT will attempt to refresh
        first (cheap, no API key required upstream), falling back to a full
        mint only if the refresh fails.

        Call this after construction when restoring a previously-saved
        session across processes / warm Lambda invocations.
        """
        self._refresh_token = refresh_token
        # Force a fresh exchange — don't keep a stale JWT.
        self._jwt_token = None
        self._jwt_expiry = None

    def get_session_id(self) -> str | None:
        """Return the current session ID, if a session has been minted.
        Useful for logging/debugging — not for authentication.
        """
        return self._session_id

    # ============================================================================
    # PRIVATE HELPER METHODS
    # ============================================================================

    async def _get_jwt_token(self) -> str:
        """Get a valid session JWT, using refresh path when possible."""
        if self._jwt_token and self._jwt_expiry and time.time() < self._jwt_expiry:
            return self._jwt_token

        if self._refresh_token:
            refreshed = await self._try_refresh()
            if refreshed:
                return refreshed

        if self._debug:
            print("[PolarGrid] Exchanging API key for session token")

        if not self._api_key:
            if self._debug:
                print("[PolarGrid] No API key, skipping session exchange")
            return ""

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(
                    self._auth_url,
                    headers={
                        "Authorization": f"Bearer {self._api_key}",
                        "Content-Type": "application/json",
                    },
                    json={"user_agent": "polargrid-python-sdk"},
                )

                if response.status_code != 200:
                    raise AuthenticationError(f"Failed to get session token: {response.text}")

                data = response.json()
                # Accept new + legacy response shapes.
                self._jwt_token = data.get("session_token") or data.get("token") or ""
                self._refresh_token = data.get("refresh_token")
                self._session_id = data.get("session_id")
                expires_in = data.get("expires_in", 86400)
                self._jwt_expiry = time.time() + max(expires_in - 60, 30)

                if self._debug:
                    print("[PolarGrid] Session token obtained")

                return self._jwt_token
        except httpx.HTTPError as e:
            raise NetworkError("Failed to exchange API key for session token", e)

    async def _try_refresh(self) -> str | None:
        """Refresh the session JWT using the cached refresh token. None on failure."""
        if not self._refresh_token:
            return None
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(
                    self._refresh_url,
                    headers={"Content-Type": "application/json"},
                    json={"refresh_token": self._refresh_token},
                )
                if response.status_code != 200:
                    self._refresh_token = None
                    return None
                data = response.json()
                self._jwt_token = data.get("session_token") or data.get("token") or ""
                self._session_id = data.get("session_id")
                expires_in = data.get("expires_in", 86400)
                self._jwt_expiry = time.time() + max(expires_in - 60, 30)
                if self._debug:
                    print("[PolarGrid] Session refreshed")
                return self._jwt_token
        except httpx.HTTPError:
            self._refresh_token = None
            return None

    def invalidate_session(self) -> None:
        """Clear the cached session. Next call will re-auth."""
        self._jwt_token = None
        self._jwt_expiry = None
        self._refresh_token = None
        self._session_id = None

    async def _make_request(
        self,
        endpoint: str,
        method: str = "GET",
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request with retry logic."""
        request_id = f"req_{int(time.time())}_{uuid.uuid4().hex[:9]}"
        last_error: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                jwt = await self._get_jwt_token()

                url = f"{self._base_url}{endpoint}"
                request_headers = {
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {jwt}",
                    "User-Agent": f"polargrid-python-sdk/{SDK_VERSION}",
                    "X-Request-ID": request_id,
                    **(headers or {}),
                }

                if self._debug:
                    print(
                        f"[PolarGrid] Making request (attempt {attempt + 1}): "
                        f"url={url}, method={method}, request_id={request_id}"
                    )

                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    response = await client.request(
                        method=method,
                        url=url,
                        headers=request_headers,
                        json=body if body else None,
                    )

                if response.status_code >= 400:
                    error_text = response.text
                    try:
                        raw_error = response.json()
                        message = raw_error.get("message") or raw_error.get("detail") or error_text
                        code = raw_error.get("code", "error")
                        details = raw_error.get("details")
                    except json.JSONDecodeError:
                        message = error_text or f"HTTP {response.status_code}"
                        code = "unknown_error"
                        details = None

                    if response.status_code == 401:
                        self._jwt_token = None
                        self._jwt_expiry = None

                    raise create_error_from_response(
                        response.status_code, code, message, details, request_id
                    )

                if self._debug:
                    print(
                        f"[PolarGrid] Request successful: "
                        f"request_id={request_id}, status={response.status_code}"
                    )

                return response.json()

            except PolarGridError as e:
                last_error = e

                if self._debug:
                    print(
                        f"[PolarGrid] Request failed (attempt {attempt + 1}): "
                        f"request_id={request_id}, error={e.message}"
                    )

                if isinstance(e, AuthenticationError) and attempt > 0:
                    raise

                if not isinstance(e, NetworkError):
                    raise

                if attempt == self._max_retries:
                    break

                base_delay = (2**attempt) * 1.0
                jitter = random.random() * 0.1 * base_delay
                await asyncio.sleep(base_delay + jitter)

            except httpx.TimeoutException:
                last_error = TimeoutError("Request timed out", request_id)
                if attempt == self._max_retries:
                    raise last_error
                await asyncio.sleep((2**attempt) * 1.0)

            except httpx.HTTPError as e:
                last_error = NetworkError(str(e), e, request_id)
                if attempt == self._max_retries:
                    raise last_error
                await asyncio.sleep((2**attempt) * 1.0)

        if last_error:
            raise last_error
        raise NetworkError("Unknown error occurred", None, request_id)

    async def _stream_post(
        self,
        endpoint: str,
        body: dict[str, Any],
    ) -> AsyncIterator[dict[str, Any]]:
        """POST to a streaming SSE endpoint and yield parsed JSON dicts.

        Stops when the server sends ``data: [DONE]`` (OpenAI convention) or the
        stream closes. Raises on HTTP errors *before* the stream begins; mid-stream
        errors are surfaced as dicts with an ``error`` key for the caller to handle.
        """
        request_id = f"req_{int(time.time())}_{uuid.uuid4().hex[:9]}"
        jwt = await self._get_jwt_token()
        url = f"{self._base_url}{endpoint}"
        request_headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {jwt}",
            "User-Agent": f"polargrid-python-sdk/{SDK_VERSION}",
            "X-Request-ID": request_id,
            "Accept": "text/event-stream",
        }

        if self._debug:
            print(f"[PolarGrid] Streaming POST: url={url}, request_id={request_id}")

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            async with client.stream(
                method="POST",
                url=url,
                headers=request_headers,
                json=body,
            ) as response:
                if response.status_code >= 400:
                    error_text = await response.aread()
                    try:
                        raw_error = json.loads(error_text)
                        message = raw_error.get("message") or raw_error.get("detail") or error_text.decode()
                        code = raw_error.get("code", "error")
                        details = raw_error.get("details")
                    except (json.JSONDecodeError, UnicodeDecodeError):
                        message = error_text.decode(errors="replace") or f"HTTP {response.status_code}"
                        code = "unknown_error"
                        details = None
                    if response.status_code == 401:
                        self._jwt_token = None
                        self._jwt_expiry = None
                    raise create_error_from_response(
                        response.status_code, code, message, details, request_id
                    )

                async for raw_line in response.aiter_lines():
                    if not raw_line:
                        continue
                    if not raw_line.startswith("data:"):
                        continue
                    payload = raw_line[5:].strip()
                    if payload == "[DONE]":
                        return
                    if not payload:
                        continue
                    try:
                        yield json.loads(payload)
                    except json.JSONDecodeError:
                        if self._debug:
                            print(f"[PolarGrid] Skipping non-JSON SSE line: {payload[:80]}")
                        continue

    async def _make_raw_request(
        self,
        endpoint: str,
        method: str = "POST",
        body: dict[str, Any] | None = None,
    ) -> bytes:
        """Make raw HTTP request (for binary responses)."""
        jwt = await self._get_jwt_token()
        url = f"{self._base_url}{endpoint}"

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.request(
                method=method,
                url=url,
                headers={
                    "Authorization": f"Bearer {jwt}",
                    "User-Agent": f"polargrid-python-sdk/{SDK_VERSION}",
                    "Content-Type": "application/json",
                },
                json=body,
            )

            if response.status_code >= 400:
                raise NetworkError(f"Request failed: {response.text}")

            return response.content

    async def _make_multipart_request(
        self,
        endpoint: str,
        files: dict[str, tuple[str, bytes, str]],
        data: dict[str, str],
    ) -> dict[str, Any] | str:
        """Make multipart request (for file uploads)."""
        jwt = await self._get_jwt_token()
        url = f"{self._base_url}{endpoint}"

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(
                url,
                headers={
                    "Authorization": f"Bearer {jwt}",
                    "User-Agent": f"polargrid-python-sdk/{SDK_VERSION}",
                },
                files=files,
                data=data,
            )

            if response.status_code >= 400:
                raise NetworkError(f"Request failed: {response.text}")

            content_type = response.headers.get("content-type", "")
            if "application/json" in content_type:
                return response.json()
            return response.text

    def _prepare_file(
        self, file: BinaryIO | bytes | Path, field_name: str
    ) -> dict[str, tuple[str, bytes, str]]:
        """Prepare file for multipart upload."""
        if isinstance(file, Path):
            content = file.read_bytes()
            filename = file.name
            content_type = self._guess_content_type(filename)
        elif isinstance(file, bytes):
            content = file
            filename = "audio.wav"
            content_type = "audio/wav"
        else:
            content = file.read()
            filename = getattr(file, "name", "audio.wav")
            content_type = self._guess_content_type(filename)

        return {field_name: (filename, content, content_type)}

    def _guess_content_type(self, filename: str) -> str:
        """Guess content type from filename."""
        ext = Path(filename).suffix.lower()
        return {
            ".mp3": "audio/mpeg",
            ".wav": "audio/wav",
            ".m4a": "audio/mp4",
            ".ogg": "audio/ogg",
            ".flac": "audio/flac",
            ".webm": "audio/webm",
        }.get(ext, "application/octet-stream")

    async def _simulate_delay(self, min_ms: float, max_ms: float) -> None:
        """Simulate network delay for mock data."""
        delay = min_ms + random.random() * (max_ms - min_ms)
        await asyncio.sleep(delay)

    # ============================================================================
    # VALIDATION METHODS
    # ============================================================================

    def _validate_completion_request(self, request: CompletionRequest) -> None:
        if not request.prompt:
            raise ValidationError("Prompt is required")
        if request.max_tokens is not None and (request.max_tokens < 1 or request.max_tokens > 4096):
            raise ValidationError("max_tokens must be between 1 and 4096")
        if request.temperature is not None and (request.temperature < 0 or request.temperature > 2):
            raise ValidationError("temperature must be between 0.0 and 2.0")
        if request.top_p is not None and (request.top_p < 0 or request.top_p > 1):
            raise ValidationError("top_p must be between 0.0 and 1.0")

    def _validate_chat_completion_request(self, request: ChatCompletionRequest) -> None:
        if not request.model:
            raise ValidationError("Model is required")
        if not request.messages or len(request.messages) == 0:
            raise ValidationError("Messages array is required and cannot be empty")
        if request.max_tokens is not None and (request.max_tokens < 1 or request.max_tokens > 4096):
            raise ValidationError("max_tokens must be between 1 and 4096")
        if request.temperature is not None and (request.temperature < 0 or request.temperature > 2):
            raise ValidationError("temperature must be between 0.0 and 2.0")
        if request.top_p is not None and (request.top_p < 0 or request.top_p > 1):
            raise ValidationError("top_p must be between 0.0 and 1.0")

    def _validate_tts_request(self, request: TextToSpeechRequest) -> None:
        if not request.input:
            raise ValidationError("Input text is required")
        if len(request.input) > 4096:
            raise ValidationError("Input text must be 4096 characters or less")
        if not request.voice:
            raise ValidationError("Voice is required")
        if request.speed is not None and (request.speed < 0.25 or request.speed > 4.0):
            raise ValidationError("Speed must be between 0.25 and 4.0")

    def _validate_transcription_request(self, request: TranscriptionRequest) -> None:
        if not request.model:
            raise ValidationError("Model is required")

    def _validate_translation_request(self, request: TranslationRequest) -> None:
        if not request.model:
            raise ValidationError("Model is required")

    # ============================================================================
    # RESPONSE CONVERSION METHODS
    # ============================================================================

    @staticmethod
    def _convert_pg_metadata(raw: dict[str, Any] | None) -> "PGMetadata | None":
        if not raw:
            return None
        from .types import PGMetadata

        return PGMetadata(
            region=raw["region"],
            latency_ms=raw["latency_ms"],
            model_load_time_ms=raw.get("model_load_time_ms"),
            queue_time_ms=raw.get("queue_time_ms"),
            inference_time_ms=raw.get("inference_time_ms"),
        )

    def _convert_completion_response(self, response: dict[str, Any]) -> CompletionResponse:
        from .types import CompletionChoice, TokenUsage

        return CompletionResponse(
            id=response["id"],
            object="text_completion",
            created=response["created"],
            model=response["model"],
            choices=[
                CompletionChoice(
                    text=c["text"],
                    index=c["index"],
                    logprobs=c.get("logprobs"),
                    finish_reason=c["finish_reason"],
                )
                for c in response["choices"]
            ],
            usage=TokenUsage(
                prompt_tokens=response["usage"]["prompt_tokens"],
                completion_tokens=response["usage"]["completion_tokens"],
                total_tokens=response["usage"]["total_tokens"],
            ),
            pg_metadata=self._convert_pg_metadata(response.get("pg_metadata")),
        )

    def _convert_chat_completion_response(
        self, response: dict[str, Any]
    ) -> ChatCompletionResponse:
        from .types import ChatCompletionChoice, ChatMessage, TokenUsage

        return ChatCompletionResponse(
            id=response["id"],
            object="chat.completion",
            created=response["created"],
            model=response["model"],
            choices=[
                ChatCompletionChoice(
                    index=c["index"],
                    message=ChatMessage(
                        role="assistant",
                        content=c["message"]["content"],
                    ),
                    finish_reason=c["finish_reason"],
                )
                for c in response["choices"]
            ],
            usage=TokenUsage(
                prompt_tokens=response["usage"]["prompt_tokens"],
                completion_tokens=response["usage"]["completion_tokens"],
                total_tokens=response["usage"]["total_tokens"],
            ),
            pg_metadata=self._convert_pg_metadata(response.get("pg_metadata")),
        )

    def _convert_embedding_response(self, response: dict[str, Any]) -> EmbeddingResponse:
        from .types import EmbeddingData, TokenUsage

        return EmbeddingResponse(
            data=[
                EmbeddingData(index=d["index"], embedding=d["embedding"])
                for d in response["data"]
            ],
            model=response["model"],
            usage=TokenUsage(
                prompt_tokens=response["usage"]["prompt_tokens"],
                completion_tokens=0,
                total_tokens=response["usage"]["total_tokens"],
            ),
        )

    def _convert_system_status(self, response: dict[str, Any]) -> SystemStatus:
        from .types import RegionModelStatus, RegionStatus

        return SystemStatus(
            status=response["status"],
            regions=[
                RegionStatus(
                    region=r["region"],
                    status=r["status"],
                    models=[
                        RegionModelStatus(
                            model_id=m["model_id"],
                            status=m["status"],
                            instances=m["instances"],
                            avg_latency_ms=m["avg_latency_ms"],
                            queue_depth=m["queue_depth"],
                        )
                        for m in r.get("models", [])
                    ],
                )
                for r in response.get("regions", [])
            ],
        )

    def _convert_gpu_status_response(self, response: dict[str, Any]) -> GPUStatusResponse:
        from .types import GPUInfo, GPUMemoryInfo, GPUProcess, GPUUtilization

        return GPUStatusResponse(
            status="success",
            timestamp=response["timestamp"],
            gpus=[
                GPUInfo(
                    index=gpu["index"],
                    name=gpu["name"],
                    memory=GPUMemoryInfo(
                        total_mb=gpu["memory"]["total_mb"],
                        used_mb=gpu["memory"]["used_mb"],
                        free_mb=gpu["memory"]["free_mb"],
                        total_gb=gpu["memory"]["total_gb"],
                        used_gb=gpu["memory"]["used_gb"],
                        free_gb=gpu["memory"]["free_gb"],
                        percent_used=gpu["memory"]["percent_used"],
                    ),
                    utilization=GPUUtilization(
                        gpu_percent=gpu["utilization"]["gpu_percent"],
                        memory_percent=gpu["utilization"]["memory_percent"],
                    ),
                    temperature_c=gpu["temperature_c"],
                )
                for gpu in response["gpus"]
            ],
            processes=[
                GPUProcess(
                    pid=proc["pid"],
                    name=proc["name"],
                    memory_mb=proc["memory_mb"],
                )
                for proc in response["processes"]
            ],
            total_gpus=response["total_gpus"],
        )

    def _convert_gpu_memory_response(self, response: dict[str, Any]) -> GPUMemoryResponse:
        from .types import GPUMemorySimple

        return GPUMemoryResponse(
            status="success",
            timestamp=response["timestamp"],
            memory=[
                GPUMemorySimple(
                    total_gb=mem["total_gb"],
                    used_gb=mem["used_gb"],
                    free_gb=mem["free_gb"],
                    percent_used=mem["percent_used"],
                    percent_free=mem["percent_free"],
                )
                for mem in response["memory"]
            ],
        )

    def _convert_gpu_purge_response(self, response: dict[str, Any]) -> GPUPurgeResponse:
        from .types import GPUMemoryState

        return GPUPurgeResponse(
            status=response["status"],
            timestamp=response["timestamp"],
            actions=response["actions"],
            memory_before=GPUMemoryState(
                used_gb=response["memory_before"]["used_gb"],
                total_gb=response["memory_before"]["total_gb"],
                percent_used=response["memory_before"]["percent_used"],
            ),
            memory_after=GPUMemoryState(
                used_gb=response["memory_after"]["used_gb"],
                total_gb=response["memory_after"]["total_gb"],
                percent_used=response["memory_after"]["percent_used"],
            ),
            memory_freed_gb=response["memory_freed_gb"],
            models_unloaded=response["models_unloaded"],
            errors=response["errors"],
            recommendation=response["recommendation"],
        )

    def _convert_health_response(self, response: dict[str, Any]) -> HealthResponse:
        from .types import BackendInfo, BackendStatus, HealthFeatures

        features = response.get("features", {})
        backend = response.get("backend", {})
        backend_info = backend.get("info", {})

        return HealthResponse(
            status=response.get("status", "unknown"),
            service=response.get("service", "unknown"),
            runtime=response.get("runtime", "unknown"),
            timestamp=response.get("timestamp", ""),
            features=HealthFeatures(
                text_inference=features.get("text_inference", False),
                voice=features.get("voice", False),
                dynamic_loading=features.get("dynamic_loading", False),
                streaming=features.get("streaming", False),
            ),
            backend=BackendStatus(
                url=backend.get("url", ""),
                healthy=backend.get("healthy", False),
                info=BackendInfo(
                    models_loaded=backend_info.get("models_loaded", 0),
                    gpu_available=backend_info.get("gpu_available", False),
                ),
            ),
        )


# ============================================================================
# SYNCHRONOUS CLIENT WRAPPER
# ============================================================================


class PolarGridSync:
    """
    Synchronous wrapper for the PolarGrid client.

    Example:
        >>> from polargrid import PolarGridSync
        >>> client = PolarGridSync(api_key="your-api-key")
        >>> response = client.chat_completion({
        ...     "model": "Meta-Llama-3.1-8B-Instruct",
        ...     "messages": [{"role": "user", "content": "Hello!"}],
        ... })
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._async_client = PolarGrid(*args, **kwargs)

    def _run(self, coro: Any) -> Any:
        """Run an async coroutine synchronously."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result()
        else:
            return asyncio.run(coro)

    def completion(self, request: CompletionRequest | dict[str, Any]) -> CompletionResponse:
        """Generate text completion (sync version)."""
        return self._run(self._async_client.completion(request))

    def completion_stream(
        self, request: CompletionRequest | dict[str, Any]
    ) -> Iterator[CompletionChunk]:
        """Generate streaming text completion (sync version)."""
        async def collect() -> list[CompletionChunk]:
            return [chunk async for chunk in self._async_client.completion_stream(request)]
        return iter(self._run(collect()))

    def chat_completion(
        self, request: ChatCompletionRequest | dict[str, Any]
    ) -> ChatCompletionResponse:
        """Generate chat completion (sync version)."""
        return self._run(self._async_client.chat_completion(request))

    def chat_completion_stream(
        self, request: ChatCompletionRequest | dict[str, Any]
    ) -> Iterator[ChatCompletionChunk]:
        """Generate streaming chat completion (sync version)."""
        async def collect() -> list[ChatCompletionChunk]:
            return [chunk async for chunk in self._async_client.chat_completion_stream(request)]
        return iter(self._run(collect()))

    def generate(self, request: GenerateRequest | dict[str, Any]) -> GenerateResponse:
        """Legacy generate method (sync version)."""
        return self._run(self._async_client.generate(request))

    def text_to_speech(self, request: TextToSpeechRequest | dict[str, Any]) -> bytes:
        """Convert text to speech (sync version)."""
        return self._run(self._async_client.text_to_speech(request))

    def text_to_speech_stream(
        self, request: TextToSpeechRequest | dict[str, Any]
    ) -> Iterator[bytes]:
        """Convert text to speech with streaming (sync version)."""
        async def collect() -> list[bytes]:
            return [chunk async for chunk in self._async_client.text_to_speech_stream(request)]
        return iter(self._run(collect()))

    def transcribe(
        self,
        file: BinaryIO | bytes | Path,
        request: TranscriptionRequest | dict[str, Any],
    ) -> TranscriptionResponse | VerboseTranscriptionResponse | str:
        """Transcribe audio to text (sync version)."""
        return self._run(self._async_client.transcribe(file, request))

    def translate(
        self,
        file: BinaryIO | bytes | Path,
        request: TranslationRequest | dict[str, Any],
    ) -> TranslationResponse | str:
        """Translate audio to English text (sync version)."""
        return self._run(self._async_client.translate(file, request))

    def transcribe_async(self, *args: Any, **kwargs: Any) -> AsyncTranscriptionJobAccepted:
        """Submit async transcription (sync version)."""
        return self._run(self._async_client.transcribe_async(*args, **kwargs))

    def get_transcription_job(self, job_id: str) -> TranscriptionJobInfo:
        """Get transcription job status (sync version)."""
        return self._run(self._async_client.get_transcription_job(job_id))

    def get_transcription_result(self, job_id: str) -> TranscriptionJobResult:
        """Get transcription job result (sync version)."""
        return self._run(self._async_client.get_transcription_result(job_id))

    def list_transcription_jobs(
        self, status: str | None = None, limit: int = 50
    ) -> TranscriptionJobListResponse:
        """List transcription jobs (sync version)."""
        return self._run(self._async_client.list_transcription_jobs(status, limit))

    def transcribe_and_wait(self, *args: Any, **kwargs: Any) -> TranscriptionJobResult:
        """Submit async transcription and wait (sync version)."""
        return self._run(self._async_client.transcribe_and_wait(*args, **kwargs))

    def list_models(self) -> ListModelsResponse:
        """List available models (sync version)."""
        return self._run(self._async_client.list_models())

    def load_model(self, request: LoadModelRequest | dict[str, Any]) -> LoadModelResponse:
        """Load a model (sync version)."""
        return self._run(self._async_client.load_model(request))

    def unload_model(self, request: UnloadModelRequest | dict[str, Any]) -> UnloadModelResponse:
        """Unload a model (sync version)."""
        return self._run(self._async_client.unload_model(request))

    def unload_all_models(self) -> UnloadAllModelsResponse:
        """Unload all models (sync version)."""
        return self._run(self._async_client.unload_all_models())

    def get_model_status(self) -> ModelStatusResponse:
        """Get model loading status (sync version)."""
        return self._run(self._async_client.get_model_status())

    def get_gpu_status(self) -> GPUStatusResponse:
        """Get detailed GPU status (sync version)."""
        return self._run(self._async_client.get_gpu_status())

    def get_gpu_memory(self) -> GPUMemoryResponse:
        """Get simplified GPU memory info (sync version)."""
        return self._run(self._async_client.get_gpu_memory())

    def purge_gpu(
        self, request: GPUPurgeRequest | dict[str, Any] | None = None
    ) -> GPUPurgeResponse:
        """Purge GPU memory (sync version)."""
        return self._run(self._async_client.purge_gpu(request))

    def health(self) -> HealthResponse:
        """Check API health (sync version)."""
        return self._run(self._async_client.health())

    def get_model(self, model_id: str) -> ModelInfo:
        """Get details for a specific model (sync version)."""
        return self._run(self._async_client.get_model(model_id))

    def embeddings(self, request: EmbeddingRequest) -> EmbeddingResponse:
        """Create embeddings for text inputs (sync version)."""
        return self._run(self._async_client.embeddings(request))

    def get_status(self) -> SystemStatus:
        """Get detailed system status (sync version)."""
        return self._run(self._async_client.get_status())

    def get_usage(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> UsageResponse:
        """Get usage statistics (sync version)."""
        return self._run(self._async_client.get_usage(start_date, end_date))
