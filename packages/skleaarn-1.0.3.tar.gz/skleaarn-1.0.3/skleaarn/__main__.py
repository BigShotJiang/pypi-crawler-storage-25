import sys
from skleaarn._installer import run_install

def main():
    dest = sys.argv[1] if len(sys.argv) > 1 else None
    run_install(dest)

if __name__ == "__main__":
    main()
