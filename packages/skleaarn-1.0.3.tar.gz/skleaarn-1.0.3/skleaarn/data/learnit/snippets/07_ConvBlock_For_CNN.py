# Title: ConvBlock For CNN
# Description: Reusable Conv2d + BatchNorm + ReLU + MaxPool block for CNN architectures
# Category: cnn

class CONVBlock(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_c),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2)
        )

    def forward(self, x):
        return self.block(x)
