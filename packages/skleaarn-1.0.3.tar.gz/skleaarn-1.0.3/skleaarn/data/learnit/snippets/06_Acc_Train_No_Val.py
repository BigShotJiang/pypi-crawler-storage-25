# Title: Acc train(NO VAL)
# Description: Training loop with accuracy tracking, no validation split
# Category: general

for epoch in range(40):
    model.train()
    total_loss = 0
    correct = 0
    total = 0

    for x, y in loader:
        x, y = x.to(device), y.to(device)

        out = model(x)
        loss = criterion(out, y)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        correct += (out.argmax(1) == y).sum().item()
        total += y.size(0)

    scheduler.step()
    acc = correct / total * 100
    print(f"Epoch {epoch:2d} | Loss: {total_loss/len(loader):.4f} | Acc: {acc:.1f}%")
