# Title: F1 Train/Val loop
# Description: Full training loop with validation and F1 score + scheduler step
# Category: general

for epoch in range(10):
    model.train()
    total_loss = 0
    for x,y in train_loader:
        x = x.to(device)
        y = y.to(device)
        optimizer.zero_grad()
        output = model(x)
        loss = criterion(output, y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    model.eval()
    val_loss = 0
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for x,y in val_loader:
            x = x.to(device)
            y = y.to(device)
            output = model(x)
            loss = criterion(output, y)
            preds = output.argmax(dim=1)

            all_preds.append(preds.cpu())
            all_labels.append(y.cpu())
    all_labels = torch.cat(all_labels)
    all_preds = torch.cat(all_preds)
    f1 = f1_score(all_labels.numpy(), all_preds.numpy(), average = "macro")
    scheduler.step(f1)
