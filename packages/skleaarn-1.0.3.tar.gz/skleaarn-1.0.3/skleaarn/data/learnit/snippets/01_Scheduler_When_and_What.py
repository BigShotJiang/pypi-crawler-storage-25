# Title: Scheduler When and What
# Description: When to use StepLR vs ReduceLROnPlateau and how to call .step()
# Category: general

schedulerLR = optim.lr_scheduler.StepLR(optimizer, step_size = 15, gamma=0.5)
schedLRP=optim.lr_scheduler.ReduceLROnPlateau(optimizer, "max")
for epoch in range(...):
    # TRAIN...
    # EVAL...
    scheduler.step()
    schedLRP.step(metric)
