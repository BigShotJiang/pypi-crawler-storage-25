# Title: CustomCNN
# Description: Full custom CNN model using CONVBlock with AdaptiveAvgPool and classifier head
# Category: cnn

class CustomModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            CONVBlock(1, 32),   # 48 -> 24
            CONVBlock(32, 64),  # 24 -> 12
            CONVBlock(64, 128), # 12 -> 6
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1))
        )
        self.cls = nn.Sequential(
            nn.Flatten(),
            nn.Dropout(0.2),
            nn.Linear(128, 8)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.cls(x)
        return x
