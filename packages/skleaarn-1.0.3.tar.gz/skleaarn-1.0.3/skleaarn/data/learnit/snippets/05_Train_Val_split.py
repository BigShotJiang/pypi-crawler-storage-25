# Title: Train/Val split
# Description: Split a Dataset into train and validation subsets using random_split
# Category: general

from torch.utils.data import random_split
train_ds = TrainDataset()
train_size = int(0.8*len(train_ds))
val_size = len(train_ds) - train_size
train_subset, val_subset = random_split(train_ds, [train_size, val_size])
