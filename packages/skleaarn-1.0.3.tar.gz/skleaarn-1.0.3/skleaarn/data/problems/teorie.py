

import numpy as np
mask_labeled = ~np.isna(y_train)
mask_unlabeled = np.isna(y_train)
X_labeled = X_train[mask_labeled]
y_labeled = y_train[mask_labeled]
X_unlabeled = X_train[mask_unlabeled]
y_unlabeled = y_train[mask_unlabeled]
rf = RandomForestClassifier(class_weights='balanced')
rf.fit(X_labeled,y_labeled)
probs = rf.predict_proba(X_unlabeled)[:,1]
mask = (probs >0.95) | (probs <0.1)
X_pseduo = X_unlabeled[mask]
y_presudo = (probs[mask]>0.5).astype(int)
X_aug = np.vstack([X_labeled,X_pseduo])
y_aug = np.concatenate([y_labeled,y_presudo])


for tr_idx, val_idx in kf.split(train):
    tr_col = train.iloc[tr_idx]
    val_col = train.iloc[val_idx]
    means = tr_col.groupby(cat_col)[taget].mean()
    train.loc[val_idx,'te'] = val_col[cat_col].map(means)
means = train.groupby(cat_col)[target].mean()
test['te'] = test['te'].map(means)
