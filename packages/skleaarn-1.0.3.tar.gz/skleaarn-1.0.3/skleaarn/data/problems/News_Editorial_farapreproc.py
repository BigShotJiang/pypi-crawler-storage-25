

import pandas as pd
train = pd.read_csv('train.csv')
test  = pd.read_csv('test.csv')
train['text'] = train['text'].str.lower()
test['text'] = test['text'].str.lower()
from sklearn.model_selection import train_test_split
X=train.drop(columns=['label']).copy()
y= train['label'].copy()
X_train, X_test, y_train ,y_test =train_test_split(X,y,test_size=0.2,random_state=42)
from sklearn.feature_extraction.text import TfidfVectorizer
import scipy.sparse as sp
vec = TfidfVectorizer(max_features=20000, ngram_range=(1,2), sublinear_tf=True)
char_vec  = TfidfVectorizer(analyzer='char_wb', ngram_range=(2,4), max_features=20000)
X_train_c = char_vec.fit_transform(X_train['text'])
X_train_tfidf = vec.fit_transform(X_train['text'])
X_test_tfidf  = vec.transform(X_test['text'])
X_test_c = char_vec.transform(X_test['text'])
X_test_final = sp.hstack([X_test_tfidf, X_test_c])
X_train_final = sp.hstack([X_train_tfidf, X_train_c])
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
model = LinearSVC(random_state=42)
model.fit(X_train_final, y_train)
proba = model.predict(X_test_final)
from sklearn.metrics import accuracy_score
acc = accuracy_score(y_test, proba)
acc
from sklearn.metrics import confusion_matrix
print(confusion_matrix(y_test, proba))
print(train[train['label']==2]['text'].iloc[0])
print(train[train['label']==3]['text'].iloc[0])
X_test_raw = test  # textul original din X_test
wrong_idx = y_test.values != proba
wrong_texts = X_test[wrong_idx]['text']
wrong_true = y_test[wrong_idx]
wrong_pred = proba[wrong_idx]

for text, true, pred in zip(wrong_texts[:5], wrong_true, wrong_pred):
    print(f"TRUE: {true} | PRED: {pred}")
    print(text[:200])
    print("---")
for label in [0,1,2,3]:
    print(f"\n=== LABEL {label} ===")
    print(train[train['label']==label]['text'].iloc[0][:300])
