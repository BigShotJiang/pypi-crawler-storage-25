

import pandas as pd
import numpy as np
train = pd.read_csv('dataset_train.csv')
test = pd.read_csv('dataset_eval.csv')
dt = pd.to_datetime(train["Activity Date"], format="%b %d, %Y, %I:%M:%S %p", utc=True)
train["month"] = dt.dt.strftime("%b")
test["month"] = dt.dt.strftime("%b")
train['Speed'] = train['Distance']/(train['Moving Time']/60/60)
test['Speed'] = test['Distance']/(test['Moving Time']/60/60)
train['month'].value_counts()
month_order = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
avg_by_month = train.groupby("month")["Speed"].mean().reindex(month_order)
avg_by_month
avg_floor_5 = np.floor(avg_by_month.values * 1e5) / 1e5
train['Label'].value_counts()
train["hour"] = pd.to_datetime(
    train["Activity Date"],
    format="%b %d, %Y, %I:%M:%S %p"
).dt.hour
test["hour"] = pd.to_datetime(
    test["Activity Date"],
    format="%b %d, %Y, %I:%M:%S %p"
).dt.hour
test_ids = test['Activity ID']
train = train.drop(columns = ['Activity ID', 'Activity Date','month'])
test = test.drop(columns = ['Activity ID', 'Activity Date','month'])
train.info()

map_target = {'COMMUTE':0, 'LEISURELY_COMMUTE':1,'PURE_LEISURE':2}
train['Label'] = train['Label'].astype(str).map(map_target)
train['Label'].value_counts()
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from catboost import CatBoostClassifier
X = train.drop(columns = ['Label'])
y= train['Label']
X_train, X_test, y_train, y_test=train_test_split(X,y, test_size=0.2, random_state=42)
model = CatBoostClassifier(random_state=42)
scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc = scaler.transform(X_test)
model.fit(X_train_sc,y_train)
y_pred = model.predict(X_test_sc)
acc = accuracy_score(y_test,y_pred)
acc
test.head()
X_scaled = scaler.fit_transform(X)        
test_scaled = scaler.transform(test)      

model.fit(X_scaled, y)
y_pred_final = model.predict(test_scaled)
inv_map_target = {0:'COMMUTE', 1:'LEISURELY_COMMUTE',2:'PURE_LEISURE'}
labels_final = pd.Series(np.ravel(y_pred_final)).map(inv_map_target)
task1 = pd.DataFrame({
    "subtaskID": 1,
    "Answer1": month_order,
    "Answer2": [f"{v:.5f}" for v in avg_floor_5]
})
task2 = pd.DataFrame({
    "subtaskID": 2,
    "Answer1": test_ids,
    "Answer2": labels_final
})

ssubmission = pd.concat([task1, task2], ignore_index=True)
ssubmission.to_csv("submission.csv", index=False)
