

import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
train.head()
train.head()
train['Autor'].value_counts()
map_autori = {'Grigore Vieru':0,'Mihai Eminescu':1,'Vasile Alecsandri':2, 'Ana Blandiana':3, 'George Toparceanu':4, "Lucian Blaga":5, 'George Bacovia':6}
train['Autor'] = train['Autor'].map(map_autori)
train['Versuri'] = train['Versuri'].str.lower()
test['Versuri'] = test['Versuri'].str.lower()
# train['Versuri'] = train['Versuri'].str.replace(r'[^a-zA-Z\s]', '', regex=True)
# test['Versuri'] = test['Versuri'].str.replace(r'[^a-zA-Z\s]', '', regex=True)
train.head()
train['Versuri'] = train['Versuri'].str.replace("\n", ' NEWLINE ', regex=False)
test['Versuri'] = test['Versuri'].str.replace("\n", '', regex=True)
train['tokens'] = train['Versuri'].str.split()
test['tokens'] = test['Versuri'].str.split()
# from nltk.stem import WordNetLemmatizer
# lem = WordNetLemmatizer()
# train['tokens'] = train['tokens'].apply(lambda tokens: [lem.lemmatize(w) for w in tokens])
# test['tokens'] = test['tokens'].apply(lambda tokens: [lem.lemmatize(w) for w in tokens])
train['text_clean'] = train['tokens'].apply(lambda tokens: ' '.join(tokens))
test['text_clean'] = test['tokens'].apply(lambda tokens: ' '.join(tokens))
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer
X = train.drop(columns='Autor')
y = train['Autor']
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=42, stratify=y)
import scipy.sparse as sp

word_vec = TfidfVectorizer(ngram_range=(1,2), max_features=20000,sublinear_tf=True)
char_vec  = TfidfVectorizer(analyzer='char_wb', ngram_range=(2,6), max_features=50000,sublinear_tf=True)

X_train_w = word_vec.fit_transform(X_train['text_clean'])
X_train_c = char_vec.fit_transform(X_train['text_clean'])
X_train_final = sp.hstack([X_train_w, X_train_c])

X_test_w = word_vec.transform(X_test['text_clean'])
X_test_c = char_vec.transform(X_test['text_clean'])
X_test_final = sp.hstack([X_test_w, X_test_c])

from sklearn.svm import LinearSVC
model = LinearSVC(C=1, class_weight='balanced')
model.fit(X_train_final,y_train)
pred = model.predict(X_test_final)
from sklearn.metrics import accuracy_score
acc = accuracy_score(y_test,pred)
acc
from sklearn.metrics import confusion_matrix
print(confusion_matrix(y_test, pred))
