

import pandas as pd
import numpy as np
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
train.head()
train=train.drop(columns=['track_id']).copy()
train['popularity']
from sklearn.model_selection import KFold
cat_col = "album_name"   
target   = "popularity"       

train["TargetEncodingalbum_name"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingalbum_name"] = val_fold[cat_col].map(means)

train["TargetEncodingalbum_name"] = train["TargetEncodingalbum_name"].fillna(global_mean)

test_te = test.copy()

means_full = train.groupby(cat_col)[target].mean()

test_te["TargetEncodingalbum_name"] = test_te[cat_col].map(means_full).fillna(global_mean)
cat_col = "track_genre"   
target   = "popularity"       

train["TargetEncodingtrack_genre"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingtrack_genre"] = val_fold[cat_col].map(means)

train["TargetEncodingtrack_genre"] = train["TargetEncodingtrack_genre"].fillna(global_mean)


means_full = train.groupby(cat_col)[target].mean()

test_te["TargetEncodingtrack_genre"] = test_te[cat_col].map(means_full).fillna(global_mean)
cat_col = "track_name"   
target   = "popularity"       

train["TargetEncodingtrack_name"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingtrack_name"] = val_fold[cat_col].map(means)

train["TargetEncodingtrack_name"] = train["TargetEncodingtrack_name"].fillna(global_mean)

means_full = train.groupby(cat_col)[target].mean()

test_te["TargetEncodingtrack_name"] = test_te[cat_col].map(means_full).fillna(global_mean)
cat_col = "artists"   
target   = "popularity"       

train["TargetEncodingArtist"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingArtist"] = val_fold[cat_col].map(means)

train["TargetEncodingArtist"] = train["TargetEncodingArtist"].fillna(global_mean)

means_full = train.groupby(cat_col)[target].mean()

test_te["TargetEncodingArtist"] = test_te[cat_col].map(means_full).fillna(global_mean)
train['explicit'] = train['explicit'].astype(int)
train.head()
train=train.drop(columns = ['artists','album_name','track_name','track_genre']).copy()
train.head()
!pip install catboost
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from catboost import CatBoostRegressor
from sklearn.pipeline import Pipeline, make_pipeline
from sklearn.ensemble import RandomForestRegressor

X = train.drop(columns = ['popularity']).copy()
y= train['popularity'].copy()
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=42)
pipeline=Pipeline(steps=[('pre',StandardScaler()),('model',RandomForestRegressor())])
pipeline.fit(X_train,y_train)
y_pred = pipeline.predict(X_test)
acc = mean_absolute_error(y_pred,y_test)
acc
test_te.head()
test_ids=test['track_id']
test_ids

test_te=test_te.drop(columns='track_id').copy()
test_te=test_te.drop(columns=['artists','album_name','track_name','track_genre']).copy()
pred_final = pipeline.predict(test_te)
submission = pd.DataFrame({
    'track_id': test_ids,
    'popularity': pred_final.astype(float)
})

submission.to_csv('submission.csv', index=False)
