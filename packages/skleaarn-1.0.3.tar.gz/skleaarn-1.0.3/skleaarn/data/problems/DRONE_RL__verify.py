import csv
import sys

gt = {}
with open('ground_truth.csv') as f:
    for row in csv.DictReader(f):
        gt[int(row['state_id'])] = float(row['v_star'])

preds = {}
with open('subs.csv') as f:
    for row in csv.DictReader(f):
        preds[int(row['state'])] = float(row['answer'])

print(f"{'State':>6} {'Pred':>10} {'Truth':>10} {'Error':>10}")
print("-" * 42)
total = 0
n = 0
for sid in sorted(gt.keys()):
    t = gt[sid]
    p = preds.get(sid, 0)
    e = abs(p - t)
    total += e
    n += 1
    flag = " !!!" if e > 5 else ""
    print(f"{sid:>6} {p:>10.2f} {t:>10.2f} {e:>10.2f}{flag}")

mae = total / n
print(f"\nMAE: {mae:.4f}")
print(f"Target: < 5.0")
print(f"Result: {'PASS' if mae < 5 else 'FAIL'}")
