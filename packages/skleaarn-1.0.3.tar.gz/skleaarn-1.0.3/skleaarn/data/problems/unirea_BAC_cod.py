

import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
train.head()
task1_df = test[
    (test["liceu"] == 'COLEGIUL NATIONAL "UNIREA" FOCSANI') & 
    (test["an"] == 2023) &
    (~test["materie"].isin(["LIMBA ROMANA", "GENERAL"]))
]
task1_answer = task1_df.loc[task1_df["preferinta_materie"].idxmax(), "materie"]
task1_answer
train['an'].value_counts()
df = train.loc[
    (train["liceu"].astype(str).str.strip() == 'COLEGIUL NATIONAL "UNIREA" FOCSANI') &
    (train["materie"].astype(str).str.strip() == "INFORMATICA MI C-C++") &
    (train["an"].between(2014, 2022)),
    ["an", "preferinta_materie"]
]

year_most_popular = df.loc[df["preferinta_materie"].idxmax(), "an"]
year_most_popular
train.head()
len(train['materie'].value_counts())
from sklearn.model_selection import KFold
import numpy as np
cat_col = "liceu"   
target   = "medie"       

train["TargetEncodingliceu"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingliceu"] = val_fold[cat_col].map(means)

train["TargetEncodingliceu"] = train["TargetEncodingliceu"].fillna(global_mean)

test_te = test.copy()

means_full = train.groupby(cat_col)[target].mean()

test_te["TargetEncodingliceu"] = test_te[cat_col].map(means_full).fillna(global_mean)
train.head()
from sklearn.model_selection import KFold
import numpy as np
cat_col = "materie"   
target   = "medie"       

train["TargetEncodingmaterie"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingmaterie"] = val_fold[cat_col].map(means)

train["TargetEncodingmaterie"] = train["TargetEncodingmaterie"].fillna(global_mean)

means_full = train.groupby(cat_col)[target].mean()

test_te["TargetEncodingmaterie"] = test_te[cat_col].map(means_full).fillna(global_mean)
train = train.drop(columns=['materie','liceu'])
from sklearn.model_selection import KFold
import numpy as np
cat_col = "judet"   
target   = "medie"       

train["TargetEncodingjudet"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingjudet"] = val_fold[cat_col].map(means)

train["TargetEncodingjudet"] = train["TargetEncodingjudet"].fillna(global_mean)

means_full = train.groupby(cat_col)[target].mean()

test_te["TargetEncodingjudet"] = test_te[cat_col].map(means_full).fillna(global_mean)
from sklearn.model_selection import KFold
import numpy as np
cat_col = "an"   
target   = "medie"       

train["TargetEncodingan"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingan"] = val_fold[cat_col].map(means)

train["TargetEncodingan"] = train["TargetEncodingan"].fillna(global_mean)

means_full = train.groupby(cat_col)[target].mean()

test_te["TargetEncodingan"] = test_te[cat_col].map(means_full).fillna(global_mean)
#train = train.drop(columns=['judet','an'])
train = train.drop(columns=['judet'])
train.info()
train.head()
corr_target = train.corr()["medie"].sort_values(ascending=False)
corr_target
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from xgboost import XGBRegressor
from catboost import CatBoostRegressor
from lightgbm import LGBMRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingClassifier, GradientBoostingRegressor
X = train.drop(columns=['medie','anomalie','preferinta_materie'])
y = train['medie']
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=42)
model = RandomForestRegressor()
scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc= scaler.transform(X_test)
model.fit(X_train_sc,y_train)
y_pred = model.predict(X_test_sc)
mea = mean_absolute_error(y_test, y_pred)
mea
test_te = test_te.drop(columns= ['judet','liceu','materie','an','preferinta_materie'])
X_scaled = scaler.fit_transform(X)        
test_scaled = scaler.transform(test_te)      

model.fit(X_scaled, y)
y_pred_final = model.predict(test_scaled)
corr_target = train.corr()["anomalie"].sort_values(ascending=False)
corr_target
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from catboost import CatBoostClassifier
X2 = train.drop(columns=["medie", "anomalie","preferinta_materie"])
y2 = train["anomalie"]  
X_train2, X_test2, y_train2, y_test2 = train_test_split(
    X2, y2, test_size=0.2, random_state=42, stratify=y2
)
scaler2 = StandardScaler()
X_train2_sc = scaler2.fit_transform(X_train2)
X_test2_sc  = scaler2.transform(X_test2)
model2 = CatBoostClassifier(random_state=42)
model2.fit(X_train2_sc, y_train2)
y_proba2 = model2.predict_proba(X_test2_sc)[:, 1]
auc2 = roc_auc_score(y_test2, y_proba2)
auc2
X_scaled2 = scaler2.fit_transform(X2)        
test_scaled2 = scaler2.transform(test_te)      

model2.fit(X_scaled2, y2)
y_pred_final2 = model2.predict(test_scaled2)
mask1 = (
    (test["liceu"].astype(str).str.strip() == 'COLEGIUL NATIONAL "UNIREA" FOCSANI') &
    (test["an"] == 2023) &
    (test["materie"].astype(str).str.strip() != "LIMBA ROMANA")
)

df1 = test.loc[mask1, ["materie", "preferinta_materie"]].copy()

df1["preferinta_materie"] = pd.to_numeric(df1["preferinta_materie"], errors="coerce")

most_frequent = df1.loc[df1["preferinta_materie"].idxmax(), "materie"]
test_ids = test["id"].values

y_pred_final = np.array(y_pred_final).reshape(-1)
y_pred_final2 = np.array(y_pred_final2).reshape(-1)

y_pred_final2 = y_pred_final2.astype(int)



sub_task12 = pd.DataFrame({
    "id": [1, 2],
    "subtaskID": [1, 2],
    "answer": [task1_answer, int(year_most_popular)]
})


sub_task3 = pd.DataFrame({
    "id": test_ids,
    "subtaskID": 3,
    "answer": y_pred_final
})

sub_task4 = pd.DataFrame({
    "id": test_ids,
    "subtaskID": 4,
    "answer": y_pred_final2
})

submission = pd.concat([sub_task12, sub_task3, sub_task4], ignore_index=True)


submission["id"] = submission["id"].astype(int)
submission["subtaskID"] = submission["subtaskID"].astype(int)

submission.to_csv("submission.csv", index=False)


