# %%
import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')

# %%
train.head()

# %%
from sentence_transformers import SentenceTransformer
embeddings = []
model = SentenceTransformer('all-mpnet-base-v2')
for i in range(len(train)):
    embedding = model.encode(train['text'][i])
    embeddings.append(embedding)

# %%
len(embeddings)

# %%
from sklearn.metrics import f1_score
from sklearn.linear_model import LogisticRegression
from catboost import CatBoostClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

X = embeddings
y = train['label']
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=42)
model_ml = CatBoostClassifier()
model_ml.fit(X_train, y_train)
pred = model_ml.predict(X_test)
acc = f1_score(y_test,pred)
acc

# %%
test.head()

# %%
embeddings_test = []
for i in range(len(test[test['subtaskID'] == 1])):
    embedding = model.encode(test[test['subtaskID'] == 1]['text'][i])
    embeddings_test.append(embedding)

# %%
model_ml.fit(X,y)
pred_final = model_ml.predict(embeddings_test)

# %%
label_texts = {
    "SCIENCE": "Scientific research and discovery in physics, biology, chemistry, medicine, and technology",
    "BUSINESS": "Business news about companies, markets, finance, economics, stocks, and corporate strategy",
    "CRIME": "Criminal activity including murder, theft, robbery, arrest, police investigation, and court trials",
    "RELIGION": "Religious beliefs, faith, worship, God, church, prayer, and spiritual practices"
}

label_names = list(label_texts.keys())
label_emb = model.encode(list(label_texts.values()))

test2 = test[test['subtaskID'] == 2]
test2_emb = model.encode(test2['text'].tolist())

from sentence_transformers import util
scores = util.cos_sim(test2_emb, label_emb) 
preds = [label_names[i] for i in scores.argmax(dim=1)]

# %%
rows = []
for idx, row in test[test['subtaskID'] == 1].iterrows():
    rows.append({"subtaskID": 1, "datapointID": row['ID'], "answer": pred_final[idx]})

for idx, row in test[test['subtaskID'] == 2].iterrows():
    rows.append({"subtaskID": 2, "datapointID": row['ID'], "answer": preds[idx]})

pd.DataFrame(rows).to_csv('output.csv', index=False)

# %%


# %%


# %%


# %% [markdown]
# # GLOVE

# %%
import pandas as pd

# %%
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
train.head()

# %%
text_test = test[test['subtaskID']==2]['text']

# %%
text_test = text_test.reset_index(drop=True)

# %%
text_test

# %%
from nltk.tokenize import word_tokenize
test_tokenized = []
for i in range(len(text_test)):
    test_tokenized.append(word_tokenize(text_test[i].lower()))

# %%
import numpy as np
embeddings_index = {}

with open('glove.6B.200d.txt', encoding='utf-8') as f:
    for line in f:
        values = line.split()
        word = values[0]
        vector = np.asarray(values[1:], dtype='float32')
        embeddings_index[word] = vector

# %%
def sentence_embedding(tokens, embeddings_index, emedding_dim=200):
    vectors = [embeddings_index[word] for word in tokens if word in embeddings_index]
    if len(vectors) == 0:
        return np.zeros(emedding_dim)
    return np.mean(vectors, axis=0)

# %%
vectors_test = np.array([sentence_embedding(tokens, embeddings_index) for tokens in test_tokenized])

# %%
vectors_test

# %%
texts = {
    "SCIENCE":["lab", 'bacteria', 'virus', 't-virus', 'doctor', 'discovery', 'science', 'chemist', 'organism','nasa','science',"research"],
    "BUSINESS":["money",'stock','company','profit','loss','owner','CEO','shares','manage','employees'],
    "CRIME":["gang","guns","kill", "thief","prison","police", "dead","shot","escape","wanted"],
    "RELIGION":["god","priest","jesus","pray", "church","holiday","confess","donation","faith","religious"]
}

# %%
labels = list(texts.keys())

category_vectors = np.array([sentence_embedding(texts[label], embeddings_index)for label in labels])
category_vectors = category_vectors / np.linalg.norm(category_vectors, axis=1, keepdims=True)

vectors_test_norm = vectors_test / np.linalg.norm(vectors_test, axis=1, keepdims=True)
similarity = vectors_test_norm @ category_vectors.T

pred_indices = np.argmax(similarity, axis=1)
pred_labels = [labels[i] for i in pred_indices]

# %%
pred_labels

# %%
from sklearn.feature_extraction.text import TfidfVectorizer
from catboost import CatBoostClassifier
text = train['text']
tfidf = TfidfVectorizer(analyzer='char_wb',ngram_range=(1,2),max_features=50000)
text = tfidf.fit_transform(text)
labels = train['label']
model = CatBoostClassifier(random_state=42)
model.fit(text,labels)
test_text= test[test['subtaskID']== 1]['text']
test_text = tfidf.transform(test_text)
preds = model.predict(test_text)

# %%
len(test[test['subtaskID']== 2])

# %%
subs1 = pd.DataFrame({
    'subtaskID':1,
    'datapointID':test[test['subtaskID']== 1]['ID'],
    'answer':preds
})
subs2 = pd.DataFrame({
    'subtaskID':2,
    'datapointID':test[test['subtaskID']== 2]['ID'],
    'answer':pred_labels
})
sub_final = pd.concat([subs1,subs2]).to_csv('subs.csv',index=False)

# %%
test.head()

# %%
len(test['s'])

# %%



