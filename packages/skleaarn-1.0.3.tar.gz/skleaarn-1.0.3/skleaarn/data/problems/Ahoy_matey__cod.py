# %%
import pandas as pd
train = pd.read_csv('train.csv')
test= pd.read_csv('test.csv')

# %%
train.info()

# %%
pirate_crew=test['PIRATE_CREW']

# %%
train["hour"] = (train["SCHEDULED_DEPARTURE"] // 100).astype(int)
test["hour"]  = (test["SCHEDULED_DEPARTURE"]  // 100).astype(int)
crew_mode = train.groupby("PIRATE_CREW")["hour"].agg(lambda x: x.mode().iloc[0])
global_mode = train["hour"].mode().iloc[0]


# %%
train.head()

# %%
train['DESTINATION_PORT'].value_counts().nunique()

# %%
import numpy as np

# %%
# from sklearn.model_selection import KFold
# cat_col = "PIRATE_CREW"   
# target   = "ARRIVAL_DELAY"       

# train["TargetEncodingPIRATE_CREW"] = np.nan

# kf = KFold(n_splits=5, shuffle=True, random_state=42)
# global_mean = train[target].mean()

# for tr_idx, val_idx in kf.split(train):
#     tr_fold = train.iloc[tr_idx]
#     val_fold = train.iloc[val_idx]

#     means = tr_fold.groupby(cat_col)[target].mean()

#     train.loc[val_idx, "TargetEncodingPIRATE_CREW"] = val_fold[cat_col].map(means)

# train["TargetEncodingaPIRATE_CREW"] = train["TargetEncodingPIRATE_CREW"].fillna(global_mean)

# test_te = test.copy()

# means_full = train.groupby(cat_col)[target].mean()

# test_te["TargetEncodingPIRATE_CREW"] = test_te[cat_col].map(means_full).fillna(global_mean)

# %%
from sklearn.model_selection import KFold
cat_col = "SHIP_NAME"   
target   = "ARRIVAL_DELAY"       

train["TargetEncodingPSHIP_NAME"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingPSHIP_NAME"] = val_fold[cat_col].map(means)

train["TargetEncodingPSHIP_NAME"] = train["TargetEncodingPSHIP_NAME"].fillna(global_mean)

means_full = train.groupby(cat_col)[target].mean()

test["TargetEncodingPSHIP_NAME"] = test[cat_col].map(means_full).fillna(global_mean)

# %%
# from sklearn.model_selection import KFold
# cat_col = "ORIGIN_PORT"   
# target   = "ARRIVAL_DELAY"       

# train["TargetEncodingORIGIN_PORT"] = np.nan

# kf = KFold(n_splits=5, shuffle=True, random_state=42)
# global_mean = train[target].mean()

# for tr_idx, val_idx in kf.split(train):
#     tr_fold = train.iloc[tr_idx]
#     val_fold = train.iloc[val_idx]

#     means = tr_fold.groupby(cat_col)[target].mean()

#     train.loc[val_idx, "TargetEncodingORIGIN_PORT"] = val_fold[cat_col].map(means)

# train["TargetEncodingORIGIN_PORT"] = train["TargetEncodingORIGIN_PORT"].fillna(global_mean)

# means_full = train.groupby(cat_col)[target].mean()

# test_te["TargetEncodingORIGIN_PORT"] = test_te[cat_col].map(means_full).fillna(global_mean)

# %%
# from sklearn.model_selection import KFold
# cat_col = "DESTINATION_PORT"   
# target   = "ARRIVAL_DELAY"       

# train["TargetEncodingDESTINATION_PORT"] = np.nan

# kf = KFold(n_splits=5, shuffle=True, random_state=42)
# global_mean = train[target].mean()

# for tr_idx, val_idx in kf.split(train):
#     tr_fold = train.iloc[tr_idx]
#     val_fold = train.iloc[val_idx]

#     means = tr_fold.groupby(cat_col)[target].mean()

#     train.loc[val_idx, "TargetEncodingDESTINATION_PORT"] = val_fold[cat_col].map(means)

# train["TargetEncodingDESTINATION_PORT"] = train["TargetEncodingDESTINATION_PORT"].fillna(global_mean)

# means_full = train.groupby(cat_col)[target].mean()

# test_te["TargetEncodingDESTINATION_PORT"] = test_te[cat_col].map(means_full).fillna(global_mean)

# %%
test.info()

# %%
sunt_null = 57140-34676

# %%
null_procent = sunt_null/57140 *100

# %%
train['SCHEDULED_DEPARTURE']

# %%
from sklearn.impute import SimpleImputer

imp = SimpleImputer(strategy='mean')

train['DAY_OF_WEEK'] = imp.fit_transform(train[['DAY_OF_WEEK']]).ravel()
test['DAY_OF_WEEK'] = imp.transform(test[['DAY_OF_WEEK']]).ravel()

# %%
from sklearn.preprocessing import OneHotEncoder

niga = ['PIRATE_CREW','ORIGIN_PORT','DESTINATION_PORT']

ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)

encoded = ohe.fit_transform(train[niga])
enpula_test = ohe.transform(test[niga])
encoded_df = pd.DataFrame(encoded, columns=ohe.get_feature_names_out(niga), index=train.index)
encoded_df_test = pd.DataFrame(enpula_test, columns=ohe.get_feature_names_out(niga), index=test.index)
train = train.drop(columns=niga).join(encoded_df)
test = test.drop(columns=niga).join(encoded_df_test)


# %%
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
# X= train.drop(columns=['ARRIVAL_DELAY','DESTINATION_PORT','ORIGIN_PORT','SHIP_NAME','PIRATE_CREW'])
X= train.drop(columns=['ARRIVAL_DELAY','SHIP_NAME'])
y=train['ARRIVAL_DELAY']
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)
sc = StandardScaler()
X_train_sc = sc.fit_transform(X_train)
X_test_sc = sc.transform(X_test)
model=LinearRegression()
model.fit(X_train_sc,y_train)
pred=model.predict(X_test_sc)
acc = mean_absolute_error(y_test,pred)
acc

# %%
test.head()

# %%
train.head()

# %%
test_sc=test.drop(columns='SHIP_NAME')
test_sc = sc.transform(test_sc)
X_sc = sc.transform(X)
model.fit(X_sc,y)
pred_final = model.predict(test_sc)

# %%
# def time(t):
#     hour = 0
#     t=str(t)
#     t = t.split('.')[0]
#     if len(t) == 4:
#         hour = int(t[0] + t[1])
#     elif len(t) == 3:
#         hour = int(t[0])
#     elif len(t) == 2:
#         hour=0
#     return hour
# test['hour'] = test['SCHEDULED_DEPARTURE'].apply(time)
# def time(t):
#     return int(float(t) // 100)

# test['hour'] = test['SCHEDULED_DEPARTURE'].apply(time)

# %%

test["crew_mode_hour"] = pirate_crew.map(crew_mode).fillna(global_mode).astype(int)

# %%
rows = []

rows.append({'subtaskID': 1, 'datapointID': 1, 'answer': null_procent})

for idx, row in test.iterrows():
    rows.append({'subtaskID': 2, 'datapointID': pirate_crew.iloc[idx], 'answer': test.loc[idx, 'crew_mode_hour']})
    rows.append({'subtaskID': 3, 'datapointID': row['SampleID'], 'answer': pred_final[idx]})

pd.DataFrame(rows).to_csv('submission.csv', index=False)


