# %%
import pandas as pd
df = pd.read_csv("muzee.csv")

# %%
df.head()

# %%
#TASK 1
marime = len(df)
marime

# %%
#TASK 2
nr_muzee = (df['județul'] == 'București').sum()
nr_muzee

# %%
#TASK 3
nr_lipsa = df.isna().any().sum()
nr_lipsa

# %%
#TASK 4
df['anul înființării'].value_counts()
anul_celmult = 2006

# %%
#TASK 5
muzee_pe_judet = df['județul'].value_counts()
muzee_pe_judet

# %%
#TASK 6
procent = df.notna().mean(axis=1)*100
procent = procent.round(2)

# %%
#TASK 7
total = 0
for i, val in enumerate(procent):
    total += val
media = total/marime
media

# %%
#TASK 8
procent_maxim = (procent == procent.max()).mean() *100
procent_maxim = procent_maxim.round(2)

# %%
df['_id']

# %%
rows = []
rows.append([1,1,marime])
rows.append([2,2,nr_muzee])
rows.append([3,3,nr_lipsa])
rows.append([4,4,anul_celmult])
for judet,val in muzee_pe_judet.items():
    rows.append([judet,5,val])
for idx, val in zip(df['_id'],procent):
    rows.append([idx,6,val])
rows.append([7,7,media])
rows.append([8,8,procent_maxim])
submission = pd.DataFrame(rows, columns=['id','subtaskID','answer'])
submission.to_csv('submission.csv',index=False)
    

# %%



