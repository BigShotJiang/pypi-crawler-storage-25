

import pandas as pd
train = pd.read_csv('obsidian_train.csv')
train.head()
import matplotlib.pyplot as plt
plt.scatter(train["sensor_x"]*train["sensor_x"], train["sensor_y"]*train["sensor_y"])
plt.xlabel("X")
plt.ylabel("Y")
plt.show()
r2 = train["sensor_x"]**2 + train["sensor_y"]**2
print(r2.describe())
plt.hist(r2, bins=50)
plt.show()
plt.scatter(train["sensor_x"], train["sensor_y"], s=5)
plt.axis("equal")
plt.show()
r2 = train["sensor_x"]**2 + train["sensor_y"]**2
plt.scatter(r2, train["flux_energy"], s=5)
plt.show()
import numpy as np

r2 = train["sensor_x"]**2 + train["sensor_y"]**2
y = train["flux_energy"]

coef = np.polyfit(r2, y, 1)  # linie: a*r2 + b
a, b = coef
pred = a * r2 + b
error = abs(y - pred)
threshold = error.quantile(0.1)  # sau ajustezi

train["label"] = (error < threshold).astype(int)
train['label'].value_counts()
