# %%
!pip install ImageIO

# %%
from sklearn.feature_extraction import image
import imageio.v3 as iio
import os
from PIL import Image, ImageStat

# %%
import os
import pandas as pd
train = pd.read_csv('train_data.csv')
test = pd.read_csv('test_data.csv')

# %%
img_xrays = iio.imread("xrays.png")
img_xrays.shape

# %%
for i in range(0,3):
    print(i)

# %%
img_xray = Image.open("xrays.png")
count=0
for i in range(50):
    for y in range(22):
        pixel = img_xray.getpixel(xy=(i,y))
        print(pixel)
        for r in range(0,3):
           if pixel[r] != 0:
            count+=1
            # print(pixel[r])
            continue

count

# %%
count=0
for i in img_xrays:
     for y in i:
        for z in y:
            if z!=0:
                count+=1
count

# %%
img = os.path.join("train",train['file_name'][0])
im = iio.imread(img)
im

# %%
import matplotlib.pyplot as plt
plt.imshow(im)
plt.show()

# %%
len(train)

# %%
import numpy as np

# %%
def extract(id):
    img = os.path.join("train",train['file_name'][id])
    im = iio.imread(img)
    imagine = Image.open(img)
    stats = ImageStat.Stat(imagine)
    return [np.mean(im),np.std(im),np.histogram(im,bins=10),np.var(im),np.float64(stats.median),np.float64(stats.extrema)[0][1],np.float64(stats.rms)[0]]

# %%
extract(213)[6]

# %%
train['val1'] = np.nan
train['val2'] = np.nan
train['val4'] = np.nan
train['median'] = np.nan
train['extrema']=np.nan
train['rms'] = np.nan
for i in range(len(train)):
    train.loc[i,'val1']=extract(i)[0]
    train.loc[i,'val2']=extract(i)[1]
    train.loc[i,'val4']=extract(i)[3]
    train.loc[i,'extrema'] = extract(i)[5]
    train.loc[i,'rms'] = extract(i)[6]

# %%
train.head()

# %%
train_to_use = train.drop(columns=['datapointID','file_name','median'])

# %%
train_to_use

# %%
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import f1_score
from sklearn.ensemble import RandomForestClassifier

X = train_to_use.drop(columns='label')
y = train_to_use['label']
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=42)
scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc = scaler.transform(X_test)
model = LogisticRegression(max_iter=10000)
model.fit(X_train,y_train)
pred = model.predict(X_test)
acc = f1_score(y_test,pred,average='macro')
acc

# %%
def extract_test(id):
    img = os.path.join("test",test['file_name'][id])
    im = iio.imread(img)
    imagine = Image.open(img)
    stats = ImageStat.Stat(imagine)
    return [np.mean(im),np.std(im),np.histogram(im,bins=10),np.var(im),np.float64(stats.median),np.float64(stats.extrema)[0][1],np.float64(stats.rms)[0]]

# %%
test['val1'] = np.nan
test['val2'] = np.nan
test['val4'] = np.nan
for i in range(len(test)):
    test.loc[i,'val1']=extract_test(i)[0]
    test.loc[i,'val2']=extract_test(i)[1]
    test.loc[i,'val4']=extract_test(i)[3]
    test.loc[i,'extrema'] = extract_test(i)[5]
    test.loc[i,'rms'] = extract_test(i)[6]

# %%
test.head()

# %%
ids = test['datapointID']
test_to_use = test.drop(columns = ['label','file_name','datapointID'])

# %%
test_to_use

# %%
model.fit(X,y)
preds = model.predict(test_to_use)

# %%
ids

# %%
rows = []
rows.append({"subtaskID":1,'datapointID':1,'answer':2393})
for idx,row in test.iterrows():
    rows.append({"subtaskID":2,'datapointID':idx+1,'answer':preds[idx]})
pd.DataFrame(rows).to_csv('subs.csv',index=False)


