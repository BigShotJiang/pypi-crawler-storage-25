# %%
import pandas as pd
train = pd.read_csv("train.csv")
test = pd.read_csv('test.csv')

# %%
train.info()

# %%
train['Internet Type']

# %%
len(train['Contract'].unique())

# %%
type(train[['Internet Type']])

# %%
from sklearn.impute import SimpleImputer
imputer = SimpleImputer(strategy='most_frequent')
train['Internet Type']= imputer.fit_transform(train[['Internet Type']]).ravel()

# %%
train.info()

# %%
cat_cols = train.select_dtypes(include=['object']).columns
train_enc = pd.get_dummies(train,columns=cat_cols,dtype=int)

# %%
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

X = train_enc.drop(columns = ['SampleID','Churn']).copy()
y= train_enc['Churn'].copy()
X_trian, X_test, y_train, y_test = train_test_split(X,y,random_state=42)
model = CatBoostClassifier(random_state=42)
model.fit(X_trian,y_train)
y_pred = model.predict(X_test)
auc = roc_auc_score(y_test,y_pred)


# %%
auc

# %%
train.head()

# %%
cat_cols_test = test.select_dtypes(include=['object']).columns
test_enc = pd.get_dummies(test,columns=cat_cols_test,dtype=int)
test_ids = test['SampleID']
test_enc =test_enc.drop(columns = 'SampleID')
test_enc = test_enc.reindex(columns = X.columns, fill_value=0)

# %%
model.fit(X,y)
y_pred_final = model.predict_proba(test_enc)[:,1]

# %%
#TASK 1
test['FinancialRiskScore'] = ((test['Monthly Charge']>70).astype(int) + (test['Total Extra Data Charges']>10).astype(int))

# %%
#TASK 2
test['ServiceQualityScore'] = ((test['Avg Speed']<50).astype(int) + (test['Ping Score']>80).astype(int) + (test['Link Quality Index']<30).astype(int))

# %%
sub1 = pd.DataFrame({"id":test['SampleID'],'subtaskID':1,'answer':test['FinancialRiskScore']})
sub2 = pd.DataFrame({"id":test['SampleID'],'subtaskID':2,'answer':test['ServiceQualityScore']})
sub3 = pd.DataFrame({"id":test['SampleID'],'subtaskID':3,'answer':y_pred_final})

submission = pd.concat([sub1,sub2,sub3],ignore_index=True)
submission.to_csv('submission.csv',index=False)

# %%



