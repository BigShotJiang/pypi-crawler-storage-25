import pandas as pd
import numpy as np


# Read data
train_df = pd.read_csv("train_data.csv")
test_df = pd.read_csv("test_datacsv")

# Create dataset
X_train = train_df["comment_text"]
y_train = train_df[["toxic", "severe_toxic", "obscene",  "insult"]]
X_test = test_df["comment_text"]

# Predict
y_pred = model.predict(X_test)

# Create submission
submission = pd.DataFrame()
submission["datapointID"] = test_df["id"]
submission["answer"] = [list(map(int, row)) for row in y_pred]
submission["answer"] = submission["answer"].apply(str)
submission["subtaskID"] = 1

# Save submission
submission.to_csv("submission.csv", index=False)
