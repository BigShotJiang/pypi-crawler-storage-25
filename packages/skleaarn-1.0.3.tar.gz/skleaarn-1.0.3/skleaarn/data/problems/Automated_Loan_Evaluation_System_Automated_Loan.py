

import pandas as pd
import numpy as np

train = pd.read_csv("train.csv")
test  = pd.read_csv("test.csv")
def classify(age):
  if age < 30:
    return "Young"
  if 30<=age < 60:
    return "Adult"
  if age >= 60:
    return "Senior"
train["class_by_age"] = train["age"].apply(classify)

def determin_risk(DTI):
  if DTI < 20:
    return "LowRisk"
  if 20<=DTI< 40:
    return "MediumRisk"
  if DTI >= 40:
    return "HighRisk"
train["risk"] = train["debt_to_income_ratio"].apply(determin_risk)
test["risk"] = test["debt_to_income_ratio"].apply(determin_risk)
train['total_obligations'] = train['current_debt'] + train['derogatory_marks'] + train['delinquencies_last_2yrs']
test['total_obligations'] = test['current_debt'] + test['derogatory_marks'] + test['delinquencies_last_2yrs']
TARGET = 'loan_status'
X = train.drop(columns=['customer_id',TARGET])
y=train[TARGET]
print(y.value_counts(normalize=True))
from sklearn.model_selection import train_test_split
X_train, X_val, y_train, y_val = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)
X_test_final = test.drop(columns=["customer_id"])
!pip install catboost
TARGET = "loan_status"
ID_COL = "customer_id"

# -------------------------------
# 1. Split features / target
# -------------------------------
X = train.drop(columns=[ID_COL, TARGET])
y = train[TARGET]

# -------------------------------
# 2. Train / validation split
# -------------------------------
from sklearn.model_selection import train_test_split

X_train, X_val, y_train, y_val = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# -------------------------------
# 3. CatBoost Pools
# -------------------------------
# -------------------------------
# Detect categorical features
# -------------------------------
cat_cols = X_train.select_dtypes(include=["object", "category"]).columns.tolist()
cat_features = [X_train.columns.get_loc(c) for c in cat_cols]
X_test_final = test[X_train.columns]
print("Categorical columns:", cat_cols)

# -------------------------------
# Create CatBoost pools
# -------------------------------
from catboost import Pool
test_pool = Pool(
    X_test_final,
    cat_features=cat_features
)
train_pool = Pool(
    X_train,
    y_train,
    cat_features=cat_features
)

val_pool = Pool(
    X_val,
    y_val,
    cat_features=cat_features
)


# -------------------------------
# 4. Model
# -------------------------------
model = CatBoostClassifier(
    loss_function="Logloss",
    eval_metric="AUC",
    iterations=5000,
    learning_rate=0.03,
    depth=6,
    l2_leaf_reg=3,
    random_seed=42,
    od_type="Iter",
    od_wait=200,
    auto_class_weights="Balanced",
    verbose=200
)

# -------------------------------
# 5. Train
# -------------------------------
model.fit(train_pool, eval_set=val_pool, use_best_model=True)

# -------------------------------
# 6. Predict on test
# -------------------------------
X_test_final = test.drop(columns=[ID_COL])
probs_ml = model.predict_proba(test_pool)[:, 1]

set(X_train.columns) - set(test.columns)
submission_rows = []

for i, row in test.iterrows():
    pid = row["customer_id"]

    # Subtask 1
    submission_rows.append([1, pid, row["class_by_age"]])

    # Subtask 2
    submission_rows.append([2, pid, row["risk"]])

    # Subtask 3
    submission_rows.append([3, pid, row["total_obligations"]])


    submission_rows.append([4, pid, float(probs_ml[i])])

submission = pd.DataFrame(submission_rows, columns=["subtaskID", "datapointID", "answer"])
submission.to_csv("submission.csv", index=False)
