import os
import zipfile
import shutil
import pandas as pd

train_df = pd.read_csv('train_data.csv')
test_df = pd.read_csv('test_data.csv')

unique_ids = test_df['IDSample'].unique()
submission = pd.DataFrame({
    'IDSample': unique_ids,
    'Subtask1': 0,
    'Subtask2': 0,
    'Subtask3': 0
})

# Inițializăm o listă goală pentru a stoca rezultatele
result = []

# Iterăm prin fiecare rând al setului de date de test
for _, row in submission.iterrows():
    # Iterăm prin subtasks (Subtask1 până la Subtask5)
    for subtask_id in range(1, 4):
        # Adăugăm un dicționar cu valorile corespunzătoare fiecărui subtask
        result.append({
            'subtaskID': subtask_id,  # ID-ul subtask-ului
            'datapointID': row['IDSample'],  # ID-ul datapoint-ului din rândul curent
            'answer': row[f'Subtask{subtask_id}']  # Răspunsul pentru subtask-ul curent
        })

# Creăm un DataFrame cu rezultatele obținute
df_output = pd.DataFrame(result)

# Afișăm primele 5 rânduri din DataFrame-ul rezultat
df_output.head()

# Salvăm rezultatele într-un fișier CSV pe care să-l putem apoi submite pe platformă
df_output.to_csv('submission.csv', index=False)