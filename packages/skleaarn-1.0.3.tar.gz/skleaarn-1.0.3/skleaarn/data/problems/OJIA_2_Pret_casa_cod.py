

import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
train.head(
)
import seaborn as sb
sb.heatmap(train.corr(method='pearson'),annot=True, annot_kws={"size": 6})

#PRICE CORELATIONS
#PRICE: NUM_BEDROMS = 0.75
#PRICE: FOOTAGE_to_Lot_Ratio = 0.92
import matplotlib as plt
sb.histplot(train['Footage_to_Lot_Ratio'],bins=50)
import numpy as np
train['Footage_to_Lot_Rati_log'] = np.log(train['Footage_to_Lot_Ratio'])
test['Footage_to_Lot_Rati_log'] = np.log(test['Footage_to_Lot_Ratio'])
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error
from catboost import CatBoostRegressor
scaler = StandardScaler()
model = CatBoostRegressor()
X = train.drop(columns=['Price'])
y = train['Price']
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2, random_state=42)
X_train_sc = scaler.fit_transform(X_train)
X_test_sc = scaler.transform(X_test)
model.fit(X_train_sc, y_train)
y_pred = model.predict(X_test_sc)
mae = mean_absolute_error(y_test,y_pred)
mae
X_pred = test
X_sc = scaler.transform(X)
model.fit(X,y)
y_pred_final = model.predict(X_pred)
sub_task3 = pd.DataFrame({
    "id": test_ids,
    "subtaskID": 3,
    "answer": y_pred_final
})
