

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import re
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
import pandas as pd
df = pd.read_csv('train.csv', encoding='latin-1')
df = df.drop(columns = 'SampleID')
import nltk
nltk.download('stopwords')
nltk.download('punkt_tab')
nltk.download('wordnet')
df.columns = ['label', 'text']
stop_words = set(stopwords.words('english'))
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'\d+', '', text)  # Remove digits
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    lemmatizer = WordNetLemmatizer()
    tokens = nltk.word_tokenize(text)
    tokens = [lemmatizer.lemmatize(w) for w in tokens if w not in stop_words]
    return ' '.join(tokens)

df['cleaned'] = df['text'].apply(preprocess_text)
df = df.drop(columns=['text'])
X_train, X_test, y_train, y_test = train_test_split(df['cleaned'], df['label'], test_size=0.3, random_state=42)
tfidf = TfidfVectorizer()
X_train_tfidf = tfidf.fit_transform(X_train)
X_test_tfidf = tfidf.transform(X_test)
tfidf = TfidfVectorizer(
    max_features=50000,   # sau 50000 dacă tot crapă
    min_df=2,
    max_df=0.95,
    ngram_range=(1,1)
)
X_train_tfidf = tfidf.fit_transform(X_train)
X_test_tfidf = tfidf.transform(X_test)
model = make_pipeline(TfidfVectorizer(), MultinomialNB())

# Naive Bayes Classifier
nb = MultinomialNB()
nb.fit(X_train_tfidf, y_train)
y_pred_nb = nb.predict(X_test_tfidf)
print("=== Naive Bayes ===\n")
print(classification_report(y_test, y_pred_nb))
