# %%
import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')

# %%
testfe = test.copy()

# %%
test['Nutrient_Index'] = 0.4*test['Nitrogen']+0.3*test['Phosphorus']+0.3*test['Potassium']
testfe['Nutrient_Index'] = 0.4*testfe['Nitrogen']+0.3*testfe['Phosphorus']+0.3*testfe['Potassium']
train['Nutrient_Index'] = 0.4*train['Nitrogen']+0.3*train['Phosphorus']+0.3*train['Potassium']

# %%
test.head()

# %%
def acid(df):
    if df['pH']<6.0:
        return "Acid"
    if df['pH']>=6.0 and df['pH']<=7.5:
        return "Neutral"
    if df['pH']>7.5:
        return "Alkaline"
test['pH_classification'] = test.apply(acid,axis=1)
testfe['pH_classification'] = testfe.apply(acid,axis=1)
train['pH_classification'] = train.apply(acid,axis=1)

# %%
test.head()

# %%
moisture = train['Moisture'].median(skipna=True)
def media(df):
    if df['Moisture']>moisture:
        return 1
    else:
        return 0
test['MedianClassification'] = test.apply(media,axis=1)
train['MedianClassification'] = train.apply(media,axis=1)
testfe['MedianClassification'] = testfe.apply(media,axis=1)

# %%
test['Soil_Type'].value_counts()

# %%
train['Soil_Type'].value_counts()

# %%
test['Soil_type_train'] = test['Soil_Type'].copy()
testfe['Soil_type_train'] = testfe['Soil_Type'].copy()
train['Soil_type_train'] = train['Soil_Type'].copy()

# %%
map_soil={
"Loam":  len(train[train['Soil_Type'] == 'Loam']),
"Sandy": len(train[train['Soil_Type'] == 'Sandy']),
"Clay" : len(train[train['Soil_Type'] == 'Clay']),
"Silt": len(train[train['Soil_Type'] == 'Silt']),
}
test['Soil_type_train'] = test['Soil_type_train'].map(map_soil)
testfe['Soil_type_train'] = testfe['Soil_type_train'].map(map_soil)
train['Soil_type_train'] = train['Soil_type_train'].map(map_soil)

# %%
test['Soil_type_train'].value_counts()

# %%
#map 0->Favorable, 1->Unfavorable

# %%
train.info()

# %%
from sklearn.impute import SimpleImputer
cat = ['Irrigation']
num = ['Organic_Matter', 'Moisture']

cat_imputer = SimpleImputer(strategy="most_frequent")
num_imputer = SimpleImputer(strategy="mean")

train[cat] = cat_imputer.fit_transform(train[cat])
train[num] = num_imputer.fit_transform(train[num])

# %%
train.head()

# %%
train['Region'].value_counts()

# %%
cat_cols = train.select_dtypes(include='object').columns.drop('Suitability')

train = pd.get_dummies(train, columns=cat_cols, dtype=int)

# %%
train.head()

# %%
train['Suitability']

# %%
map_target = {'Unfavorable':0,"Favorable":1}
train['Suitability'] = train['Suitability'].astype(str).map(map_target)

# %%
from sklearn.linear_model import LogisticRegression
from catboost import CatBoostClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score

X=train.drop(columns=['Suitability','ID'])
y=train['Suitability']
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2,random_state=42,stratify=y)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
model = CatBoostClassifier(random_state=42)
# model = LogisticRegression(max_iter=5000, random_state=42)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
f1 = f1_score(y_test,y_pred)
f1

# %%


# %%


# %%
test.info()

# %%
cat_cols = test.select_dtypes(include='object').columns

test = pd.get_dummies(test, columns=cat_cols, dtype=int)

# %%
test.head()

# %%
cat = ['Irrigation']
num = ['Organic_Matter', 'Moisture']

test[cat] = cat_imputer.transform(test[cat])
test[num] = num_imputer.transform(test[num])

# %%
test = test.drop(columns='ID')
test_scaled = scaler.transform(test)
test = pd.DataFrame(test_scaled, columns=test.columns, index=test.index)

# %%
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
model = LogisticRegression(max_iter=5000, solver="liblinear", random_state=42)
model.fit(X_scaled, y)

y_pred_final = model.predict(test_scaled)

# %%
ids = testfe["ID"]

# %%

inv_map_target = {0:'Unfavorable',1:'Favorable'}
sub5_ans = pd.Series(y_pred_final, index=test.index).map(inv_map_target)
submission = pd.concat([
    pd.DataFrame({"subtaskID": 1, "datapointID": ids, "answer": testfe["Nutrient_Index"]}),
    pd.DataFrame({"subtaskID": 2, "datapointID": ids, "answer": testfe["pH_classification"]}),
    pd.DataFrame({"subtaskID": 3, "datapointID": ids, "answer": testfe["MedianClassification"]}),
    pd.DataFrame({"subtaskID": 4, "datapointID": ids, "answer": testfe["Soil_type_train"]}),
    pd.DataFrame({"subtaskID": 5, "datapointID": ids, "answer": sub5_ans}),
], ignore_index=True)
submission.to_csv("submission.csv", index=False)


