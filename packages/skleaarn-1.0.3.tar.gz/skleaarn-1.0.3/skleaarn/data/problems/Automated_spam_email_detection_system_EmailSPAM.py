

# #TASK #1
import numpy as np
import pandas as pd
import os

train = pd.read_csv("train.csv")
test = pd.read_csv("test.csv")
train['length'] = train['text'].str.len()
train['length']
# #TASK #2
train['count_free'] = train['text'].str.count('free')
train['count_free']
# #TASK #3
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

X = train["text"].fillna("")
y = train["label"].astype(int)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = Pipeline([
    ("tfidf", TfidfVectorizer(max_features=200_000, ngram_range=(1,2), min_df=2, sublinear_tf=True)),
    ("clf", LogisticRegression(max_iter=2000, solver="liblinear"))
])

model.fit(X_train, y_train)
proba = model.predict_proba(X_test)[:, 1]
print("ROC AUC:", roc_auc_score(y_test, proba))
import pandas as pd
import re

df = test.copy()
df["text"] = df["text"].fillna("")

# ensure sample_id stays zero-padded
df["sample_id"] = df["sample_id"].astype(str)

# Task1
sub1 = pd.DataFrame({
    "subtaskID": 1,
    "datapointID": df["sample_id"],
    "answer": df["text"].str.len().astype(int)
})

# Task2
sub2 = pd.DataFrame({
    "subtaskID": 2,
    "datapointID": df["sample_id"],
    "answer": df["text"].str.count(r"\bfree\b", flags=re.IGNORECASE)
})

# Task3
spam_proba = model.predict_proba(df["text"])[:, 1]

sub3 = pd.DataFrame({
    "subtaskID": 3,
    "datapointID": df["sample_id"],
    "answer": spam_proba
})

# Combine and save
final_csv = pd.concat([sub1, sub2, sub3], ignore_index=True)
final_csv.to_csv("submission.csv", index=False)
