# %%
import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')

# %%
test['custom'] = (test['HoneyBeeDensity'] == 0.25) & (test['BumbleDensity']==0.25) &  (test['AndrenaDensity']==0.25) & (test['OsmiaDensity']==0.25)& (test['FruitMass']>=0.45) & (test['SeedCount']>=36)

# %%
test['custom'].value_counts()

# %%
numar = 31

# %%
test['custom2'] = (test['RainingDays']<20) & (test['FruitMass']>0.45) & (test['CloneSize'] == 25.0)

# %%
mediu = test['SeedCount'][(test['custom2']==True)==True].mean()

# %%
mediu

# %%
mediu = 38

# %%


# %%


# %%
train.head()

# %%
train.info()

# %%
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
model = GradientBoostingRegressor(learning_rate=0.2,n_estimators=200,loss='absolute_error',random_state=42)
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
scaler = StandardScaler()
X=train.drop(columns=['RaspberryYield'])
y = train['RaspberryYield']
model_lr = LinearRegression()
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2,random_state=42)
X_train_sc = scaler.fit_transform(X_train)
X_test_sc = scaler.transform(X_test)
model_lr.fit(X_train_sc,y_train)
pred_lr = model_lr.predict(X_test_sc)
acc_lr = mean_absolute_error(y_test,pred_lr)
model.fit(X_train,y_train)
pred = model.predict(X_test)
acc = mean_absolute_error(y_test,pred)
print(acc_lr)
print(model._get_params_html())
acc

# %%
import seaborn as sns
import matplotlib.pyplot as plt

corr = train.corr()['RaspberryYield'].sort_values(ascending=False)

sns.heatmap(corr.to_frame(), annot=True, cmap='coolwarm')
plt.show()

# %%
test.head()

# %%
test = test.drop(columns=['custom','custom2'])

# %%
model.fit(X,y)
pred_final = model.predict(test)

# %%
test['pred']=pred_final

# %%
def convert(t):
    for i,val in enumerate(test[t]):
        test[t][i] = int(val)

# %%
convert('pred')

# %%
len(pred)

# %%
test['pred']

# %%
for i in range(3000):
    test.loc[i,'pred'] = int(pred_final[i])

# %%
test['custom'] = ((test['SeedCount']>42) | (test['SeedCount']<28)) & (test['AverageRainingDays']>0.3)

# %%
media2 = test['pred'][(test['custom']==True)==True].mean()

# %%
media2 = 5493

# %%
#BRUTE FORCE MAE 5352

# %%
rows = []
rows.append({'subtaskID':1, 'datapointID':int(0), 'answer':numar})
rows.append({'subtaskID':2, 'datapointID':int(1), 'answer':mediu})
for idx,row in test.iterrows():
    
    
    rows.append({'subtaskID':3, 'datapointID':row['id'], 'answer':int(pred_final[idx])})
rows.append({'subtaskID':4, 'datapointID':int(3002), 'answer':5352})
pd.DataFrame(rows).to_csv('Submission.csv',index=False)

# %%



