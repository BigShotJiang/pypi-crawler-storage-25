

import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
train.head()
train.groupby(['job'])['deposit'].mean().sort_values(ascending=False)
answer1 = 'student'
train['month'].value_counts()
answer2 = 'may'
train.info()
cat_col = train.select_dtypes(include='object').columns.to_list()
cat_col
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from catboost import CatBoostClassifier

X=train.drop(columns=['deposit'])
y = train['deposit']
X_train,X_test, y_train, y_test =train_test_split(X,y,test_size=0.2,random_state=42)
model = CatBoostClassifier(random_state=42,cat_features=cat_col)
model.fit(X_train,y_train)
pred = model.predict(X_test)
acc = f1_score(y_test,pred, average='macro')
acc
model.fit(X,y)
pred_final = model.predict(test)
num_cols = [c for c in train.columns if c not in cat_col]
num_cols_upd = [c for c in num_cols if c != 'deposit']
num_cols_upd = [c for c in num_cols_upd if c != 'id']
num_cols_upd
y_train
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
X_scaled = StandardScaler().fit_transform(test[num_cols_upd])

tsne = TSNE(n_components=2, perplexity=30, random_state=42)
X_2d = tsne.fit_transform(X_scaled)
plt.scatter(X_2d[:, 0], X_2d[:, 1])
plt.show()
from sklearn.cluster import KMeans
scaler = StandardScaler()
X_scaled = scaler.fit_transform(test[num_cols_upd])
km = KMeans(n_clusters=2, random_state=42, n_init=10)
labels_final = km.fit_predict(X_scaled)
count = 0
for i in labels_final:
    if i != 0:
        count+=1
        print('t')
count
rows = []
rows.append({'subtaskID':1,'datapointID':1,"answer":answer1})
rows.append({'subtaskID':2,'datapointID':1,"answer":answer2})
for idx,row in test.iterrows():
    rows.append({'subtaskID':3,'datapointID':row['id'],"answer":pred_final[idx]})
for idx,row in test.iterrows():    
    rows.append({'subtaskID':4,'datapointID':row['id'],"answer":labels_final[idx]})
pd.DataFrame(rows).to_csv('subs.csv',index=False)
    
