

import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
train.info()
train['date'] = train['date'].str.split('-',expand = True)[0].astype(int)
test['date'] = test['date'].str.split('-',expand = True)[0].astype(int)
from xgboost import XGBRegressor as XGB
from sklearn.model_selection import train_test_split
from sklearn.metrics import root_mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import RandomizedSearchCV
X = train.drop(columns = ['gold close','ID']).copy()
y = train['gold close'].copy()
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2,random_state=42)
model = XGB(eval_metric='rmse',random_state= 42,tree_method="hist",device="cuda")
# model.fit(X_train, y_train)
# y_pred = model.predict(X_test)
# acc = root_mean_squared_error(y_test,y_pred)
# acc
scaler = StandardScaler()
scaler.fit(X_train)
X_train_transfromed = scaler.transform(X_train)
X_test_transformed = scaler.transform(X_test)
model.fit(X_train_transfromed,y_train)
y_pred = model.predict(X_test_transformed)
acc = root_mean_squared_error(y_test,y_pred)
acc
param_grid = {
    "n_estimators": [500, 1000, 2000],
    "learning_rate": [0.01, 0.05, 0.1],
    "max_depth": [3, 5, 7],
    "min_child_weight": [1, 5, 10],
    "subsample": [0.7, 0.9, 1.0],
    "colsample_bytree": [0.7, 0.9, 1.0],
    "gamma": [0, 1, 5],
    "reg_lambda": [1, 5, 10]
}
random = RandomizedSearchCV(model, param_grid,refit=True,random_state=42)
random.fit(X_train_transfromed,y_train)
random.best_params_
model_best = random.best_estimator_
y_new_pred = model_best.predict(X_test_transformed)
acc2= root_mean_squared_error(y_test,y_new_pred)
acc2
model_best_new = random.best_estimator_
X_pred = test.drop(columns=['ID']).copy()
X_pred_t = scaler.transform(X_pred)
y_final = model_best_new.predict(X_pred_t)
df = pd.DataFrame({
    "ID": test["ID"].values,
    "gold close": y_final
})
df.to_csv(("submission.csv"),index = False)
