

import pandas as pd
df = pd.read_csv('dataset.csv')
df.head()
#TASK 1
answer1 = df['vehicle_type'].value_counts().nunique()
answer1
#TASK 2
from sklearn.cluster import DBSCAN
import numpy as np

df_grouped = df.groupby("id", as_index=False)[["latitude", "longitude"]].mean()
coords = df_grouped[["latitude", "longitude"]]
cluster = DBSCAN(n_jobs=-1)

labels = cluster.fit_predict(coords)
labels
