

from sklearn.model_selection import KFold
cat_col = "album_name"   
target   = "popularity"       

train["TargetEncodingalbum_name"] = np.nan

kf = KFold(n_splits=5, shuffle=True, random_state=42)
global_mean = train[target].mean()

for tr_idx, val_idx in kf.split(train):
    tr_fold = train.iloc[tr_idx]
    val_fold = train.iloc[val_idx]

    means = tr_fold.groupby(cat_col)[target].mean()

    train.loc[val_idx, "TargetEncodingalbum_name"] = val_fold[cat_col].map(means)

train["TargetEncodingalbum_name"] = train["TargetEncodingalbum_name"].fillna(global_mean)

test_te = test.copy()

means_full = train.groupby(cat_col)[target].mean()

test_te["TargetEncodingalbum_name"] = test_te[cat_col].map(means_full).fillna(global_mean)
