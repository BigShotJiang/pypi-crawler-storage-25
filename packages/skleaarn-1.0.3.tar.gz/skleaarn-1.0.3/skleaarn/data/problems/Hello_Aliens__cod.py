# %%
import pandas as pd
train = pd.read_csv("train.csv")
test = pd.read_csv("test.csv")

# %%
train.head()

# %%
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
train_sc = scaler.fit_transform(train.drop(columns='Target'))
test_sc = scaler.transform(test)
kmeans= DBSCAN(eps=9)
kmeans.fit(train_sc)
train['SpaceNoise'] = kmeans.labels_
kmeans.fit(test_sc)
test['SpaceNoise'] = kmeans.labels_

# %%
train['SpaceNoise'].value_counts()

# %%
train['SpaceNoise'] = (train['SpaceNoise']==-1)-1 #asta e space noise = 2155
test['SpaceNoise'] = (test['SpaceNoise']==-1)-1 #asta e space noise = 2155

# %%
train['SpaceNoise'].value_counts()

# %%
train['SpaceNoise'] = (train['SpaceNoise']==-1).astype(int)#asta e candidate signals = 3845
test['SpaceNoise'] = (test['SpaceNoise']==-1).astype(int)#asta e candidate signals = 3845

# %%
train['SpaceNoise'].value_counts()

# %%
train.head()

# %%
from sklearn.model_selection import train_test_split
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
X=train.drop(columns='Target')
y= train['Target']
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2, random_state=42)
# scaler = StandardScaler()
# model = LinearRegression()
# X_train_sc = scaler.fit_transform(X_train)
# X_test_sc = scaler.transform(X_test)
# model.fit(X_train_sc,y_train)
# pred = model.predict(X_test_sc)
model = CatBoostRegressor(random_state=42)
model.fit(X_train, y_train)
pred = model.predict(X_test)
acc= mean_squared_error(y_test,pred)
acc

# %%
model.fit(X,y)
pred_final = model.predict(test)

# %%

dbscan2 = DBSCAN(eps=5, min_samples=10)
labels_origin = dbscan2.fit_predict(train_sc)

train['dbscan_labels'] = labels_origin
train['SourceOrigin'] = 0
counts = pd.Series(labels_origin).value_counts()
active_cluster_ids = counts[(counts > 100) & (counts.index != -1)].index

train.loc[train['dbscan_labels'].isin(active_cluster_ids), 'SourceOrigin'] = 1

# %%
dbscan2 = DBSCAN(eps=5, min_samples=10)
labels_origin = dbscan2.fit_predict(test_sc)

test['dbscan_labels'] = labels_origin
test['SourceOrigin'] = 0
counts = pd.Series(labels_origin).value_counts()
active_cluster_ids = counts[(counts > 100) & (counts.index != -1)].index

test.loc[test['dbscan_labels'].isin(active_cluster_ids), 'SourceOrigin'] = 1

# %%
train['dbscan_labels'].value_counts()

# %%
test['SourceOrigin'].value_counts()

# %%
test['ID']

# %%
sub1 = pd.DataFrame({
    'subtaskID': 1,
    'datapointID': test['ID'],
    'answer': test['SpaceNoise']
})

sub2 = pd.DataFrame({
    'subtaskID': 2,
    'datapointID': test['ID'],
    'answer': pred_final
})

sub3 = pd.DataFrame({
    'subtaskID': 3,
    'datapointID': test['ID'],
    'answer': test['SourceOrigin']
})

submission = pd.concat([sub1, sub2, sub3])
submission.to_csv('submission.csv', index=False)


