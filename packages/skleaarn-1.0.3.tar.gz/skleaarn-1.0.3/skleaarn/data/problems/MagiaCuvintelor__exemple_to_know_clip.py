#INCARCARE CLIP
from transformers import CLIPProcessor, CLIPModel

model = CLIPModel.from_pretrained("openai/clip-vit-large-patch14")
processor = CLIPProcessor.from_pretrained("openai/clip-vit-large-patch14")

#Preprocesare
inputs = processor(
        text=text,
        #Sau image = .....
        return_tensors="pt",
        padding=True,
        truncation=True
    )

#calculare embeddings
import torch.nn.functional as F
with torch.no_grad():
    text_features = model.get_text_features(**inputs)
    #sau pt imagini
    img_features = model.get_image_features(**inputs)
    #DONT FORGET NORMALIZARE OR THE DIMENSION GODS WILL HATE YOU 
    #bla bla =  F.normalize(bla bla, dim = -1).squeeze(0)

#Calculare top K
topk = similarity.topk(k=5, dim=1)
