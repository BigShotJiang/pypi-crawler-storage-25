import pandas as pd
from sklearn.metrics import f1_score
gt = pd.read_csv("p1_ground_truth.csv")
pred = pd.read_csv("submission_p1.csv")
merged = gt.merge(pred, on="state", suffixes=("_true","_pred"))
print(f"F1: {f1_score(merged['action_true'], merged['action_pred'], average='weighted'):.4f}")
