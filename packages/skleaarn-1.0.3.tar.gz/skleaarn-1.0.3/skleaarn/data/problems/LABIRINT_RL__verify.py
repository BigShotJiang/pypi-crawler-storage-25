import csv

gt = {}
with open('ground_truth.csv') as f:
    for row in csv.DictReader(f):
        gt[int(row['id'])] = (int(row['state_id']), float(row['v_star']))

preds = {}
with open('predictions.csv') as f:
    for row in csv.DictReader(f):
        preds[int(row['id'])] = float(row['v_star'])

print(f"{'ID':>4} {'State':>6} {'Pred':>10} {'Truth':>10} {'Error':>10}")
print("-" * 46)
total = 0
n = 0
for qid in sorted(gt.keys()):
    sid, t = gt[qid]
    p = preds.get(qid, 0)
    e = abs(p - t)
    total += e
    n += 1
    flag = " !!!" if e > 50 else ""
    print(f"{qid:>4} {sid:>6} {p:>10.2f} {t:>10.2f} {e:>10.2f}{flag}")

mae = total / n
print(f"\nMAE: {mae:.4f}")
print(f"< 50 = rezonabil | < 10 = bun | < 2 = excelent")
print(f"Result: {'EXCELENT' if mae < 2 else 'BUN' if mae < 10 else 'REZONABIL' if mae < 50 else 'FAIL'}")
