

import pandas as pd
import numpy as np
df_train = pd.read_csv('./obsidian_train.csv').drop(["id_hex"], axis = 1)
df_test = pd.read_csv ("./obsidian_test.csv")
id_test = df_test["id_hex"]
df_test = df_test.drop(["id_hex"], axis = 1)
df_train.head(5)
x_tr = df_train[["flux_energy", "sensor_x", "sensor_y"]]
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
pc = TSNE()
x_tr = pc.fit_transform(x_tr)
import matplotlib.pyplot as plt
plt.scatter(x_tr[:, 0], x_tr[:, 1])
from sklearn.feature_extraction.text import TfidfVectorizer
tfidf = TfidfVectorizer(analyzer="char", ngram_range=(1, 3))
x_text_train = tfidf.fit_transform(df_train["resonance_str"])
x_text_test = tfidf.transform(df_test["resonance_str"])
ts = TSNE(init="random")
x_ = ts.fit_transform(x_text_train)
plt.scatter(x_[:, 0], x_[:, 1])
from sklearn.cluster import KMeans
kmn = KMeans(n_clusters= 2)
df_train["label"] = kmn.fit_predict(x_text_train)
df_test["label"] = kmn.fit_predict(x_text_test)
df_train = df_train.drop(["resonance_str"], axis = 1)
df_test = df_test.drop(["resonance_str"], axis = 1)
X = df_train.drop(["sensor_x", "sensor_y"], axis= 1)
y = df_train[["sensor_x"]]
from sklearn.model_selection import train_test_split
X_tr, X_vl, y_tr, y_vl = train_test_split(X, y, test_size= 0.2)
from catboost import CatBoostRegressor
from sklearn.metrics import mean_absolute_error
lr = CatBoostRegressor()
lr.fit(X_tr, y_tr)
print(f"TR MAE: {mean_absolute_error(y_tr, lr.predict(X_tr))}")
print(f"Vl MAE: {mean_absolute_error(y_vl, lr.predict(X_vl))}")
pd.DataFrame({
    "subtaskID" : 1,
    "datapointID" : id_test,
    "answer" : df_test["label"].map({
        0 : 1,
        1 : 0
    })
}).to_csv("subi.csv", index= False)
