

import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
import cv2
import os
import matplotlib.pyplot as plt
train['id'][111]
y=3
x=0
for i in range(0,4): print(i)
img = cv2.imread("./train_images/903ce922.png", cv2.IMREAD_COLOR_RGB)
roi = img[x*64:(x+1)*64,y*64:(y+1)*64]
plt.imshow(roi)
plt.axis("off")  
plt.show()
print(img.shape)
# img = cv2.imread("./train_images/903ce922.png", cv2.IMREAD_COLOR_RGB)
# for x in range(0,5):
#         for y in range(0,5):
#             roi = img[x*64:(x+1)*64,y*64:(y+1)*64]
#             plt.imshow(roi)

# plt.axis("off")  
# plt.show()
# print(img.shape)
import numpy as np
def extract_features_blobs(img_id):
    path = test['id'][img_id]
    img = cv2.imread(path,cv2.IMREAD_GRAYSCALE)
    img = img[0:64,0:64]
    #blurred = cv2.GaussianBlur(img, (5, 5), 0)
    circles = cv2.HoughCircles(
        img,
        cv2.HOUGH_GRADIENT,
        1,
        18,
        param1=50,
        param2=22,
        minRadius=6,
        maxRadius=22,
    )
    m3 = len(circles[0]) if circles is not None else 0
    # plt.imshow(img)
    # plt.axis("off")  
    # plt.show()
    return m3
x = extract_features_blobs(99)
type(x)
len(test)
answer = []
def assaign(idx):
    if extract_features_blobs(idx) == 0:
        return 1
    else:
        return 0
for i in range(0,100): answer.append(assaign(i))
answer
def assaing2(val):
    if val == 0:
        return 1
    else:
        return 0
def convert(bit_string):
    n = len(bit_string)
    value = int(bit_string, 2)
    
    if bit_string[0] == '1':
        value -= 2**n
    
    return value
answer3 = []
def extract_features_blobs(img_id):
    answer2 =[]
    text = ""
    path = test['id'][img_id]
    img = cv2.imread(path,cv2.IMREAD_GRAYSCALE)
    for x in range(0,4):
        for y in range(0,4):
            roi = img[x*64:(x+1)*64,y*64:(y+1)*64]
            circles = cv2.HoughCircles(
                roi,
                cv2.HOUGH_GRADIENT,
                1,
                18,
                param1=50,
                param2=22,
                minRadius=6,
                maxRadius=22,
            )
            m3 = len(circles[0]) if circles is not None else 0
            answer2.append(assaing2(m3))
    for i in range(0,16):
        text += str(answer2[i])
    return convert(text)
a = extract_features_blobs(2)
a
for i in range(0,100): answer3.append(extract_features_blobs(i))
answer3
rows = []
for idx, row in test.iterrows():
    rows.append({"subtaskID":1, 'ID':row['id'],'answer':answer[idx]})
    rows.append({"subtaskID":2, 'ID':row['id'],'answer':answer3[idx]})
pd.DataFrame(rows).to_csv('subs.csv',index=False)
