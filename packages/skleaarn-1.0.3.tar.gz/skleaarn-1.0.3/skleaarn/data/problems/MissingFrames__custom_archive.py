# Install the required packages
%pip install transformers
%pip install git+https://github.com/huggingface/diffusers

# Import the needed packages
from diffusers import DiffusionPipeline, AutoencoderKL
from transformers import pipeline
import torch
import random
import ast

######################################

# Read and process the training data
train_data = pd.read_csv('train_data.csv')
train_data['answer'] = train_data['answer'].apply(lambda x: np.array(ast.literal_eval(x)).astype(np.float32))

# Before sumbitting apply the follosing processing on the column of arrays
submission_csv['answer'] = submission_csv['answer'].apply(lambda x: x.tolist())

######################################

# Run to ensure consistency
seed = 42
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

# Autoencoder model
vae = AutoencoderKL.from_pretrained("stabilityai/sdxl-vae")
vae.to(device, dtype=torch.float32)
vae.eval()
vae.enable_tiling()
vae.enable_slicing()


######################################


# Decode a latent
with torch.no_grad():# crucial for keeping memory stable
  img = vae.decode(latents).sample[0] # make sure latents has shape of type (batch_size,4,90,160)

# Encode an image
with torch.no_grad():
  latent = vae.encode(timg)['latent_dist'].sample()# timg is the image in torch.tensor format of shape (batch_size,3, 720, 1280)


######################################

# Depth model
pipe = pipeline(task="depth-estimation", model="depth-anything/Depth-Anything-V2-Base-hf", device=device)
# Get the depth of an image
depth = pipe(image)['depth'].convert('RGB') # image - PIL.Image object


######################################
