

import pandas as pd
import numpy as np
df = pd.read_csv("dataset.csv")
n_veh = df["id"].nunique()
n_types = df["vehicle_type"].nunique()
from sklearn.cluster import DBSCAN
Poz = df.groupby("id")[["latitude", "longitude"]].mean()

labels = DBSCAN(eps=5/6371, min_samples=2, metric="haversine").fit_predict(np.radians(Poz.to_numpy()))
unic = [x for x in np.unique(labels) if x != -1]
centers = np.array([Poz.to_numpy()[labels == k].mean(axis=0) for k in unic])
for i in np.where(labels == -1)[0]:
    labels[i] = unic[np.argmin(np.sum((centers - Poz.to_numpy()[i])**2, axis=1))]
from sklearn.cluster import KMeans
type10 = df[df["vehicle_type"] == 10].copy()
type10["hour"] = pd.to_datetime(type10["timestamp"]).dt.hour
type10 = type10[(type10["hour"] == 23) | (type10["hour"] < 3)]

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
type10_coords = type10[["latitude", "longitude"]].copy()
type10_coords["depot"] = kmeans.fit_predict(type10_coords)

depots = (type10_coords.groupby("depot")[["latitude", "longitude"]].mean().reset_index(drop=True))
subtask3 = depots.sort_values("latitude").reset_index(drop=True)
rows = []
rows.append(["1", n_veh, n_types])

for i in range(len(Poz)):
    rows.append(["2", Poz.index[i], int(labels[i])])

for _, r in depots.iterrows():
    rows.append(["3", round(r["latitude"], 6), round(r["longitude"], 6)])

pd.DataFrame(rows, columns=["subtaskID", "Value1", "Value2"]).to_csv(
    "submission.csv", index=False
)
