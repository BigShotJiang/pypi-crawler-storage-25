# %%
import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')

# %%
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
cat = train.select_dtypes(include="object").columns
num = [c for c in train.columns if c not in cat]
num_imputer = SimpleImputer(strategy="mean")
train[num]=num_imputer.fit_transform(train[num])
cat_imputer = SimpleImputer(strategy="most_frequent")
train[cat] = cat_imputer.fit_transform(train[cat])

# %%
train.info()

# %%
train.isna().sum().sum()

# %%
train['HadHeartAttack'].value_counts()

# %%
train['HadHeartAttack'].value_counts().iloc[train['HadHeartAttack'].value_counts().argmax()]

# %%
train['HadHeartAttack'].value_counts().argmin()

# %%
train['HadHeartAttack'].value_counts().argmax()

# %%
ratio = train['HadHeartAttack'].value_counts().iloc[train['HadHeartAttack'].value_counts().argmin()] / train['HadHeartAttack'].value_counts().iloc[train['HadHeartAttack'].value_counts().argmax()]
ratio

# %%
train.info()

# %%
train = train.dropna()

# %%
pd.set_option("display.max_columns", None)

# %%
train.head()

# %%
train['Ra']

# %%
train['CovidPos'].value_counts()

# %%
map_ch = {"Within past year (anytime less than 12 months ago)":1, "Within past 2 years (1 year but less than 2 years ago)":2, "Within past 5 years (2 years but less than 5 years ago)":5,"5 or more years ago":10}
map_health = {'Poor':0,'Fair':1, 'Excellent':2, 'Good':3, 'Very good':4}
map_sex = {'Female':0 , 'Male':1}
map_diab = {'Yes':10, 'No':0,'No, pre-diabetes or borderline diabetes':5,'Yes, but only during pregnancy (female)':2}
map_YES_NO = {'Yes':1, 'No':0}
map_covid ={'Yes':2, 'No':0, 'Tested positive using home test without a health professional':1}
map_theeth = {'None of them':0, '1 to 5': 2,"6 or more, but not all":3,"All": 10}
map_TETANUS = {'No, did not receive any tetanus shot in the past 10 years':0, 'Yes, received tetanus shot but not sure what type':1,'Yes, received Tdap':2,'Yes, received tetanus shot, but not Tdap':3}
map_SMOKER = {'Never smoked':10, 'Former smoker':6, 'Current smoker - now smokes every day':2,'Current smoker - now smokes some days':1 }
map_VAPE = {'Never used e-cigarettes in my entire life':10, 'Not at all (right now)':6, 'Use them some days':3,'Use them every day':1}
map_age= {
    "Age 18 to 24": 0,
    "Age 25 to 29": 1,
    "Age 30 to 34": 2,
    "Age 35 to 39": 3,
    "Age 40 to 44": 4,
    "Age 45 to 49": 5,
    "Age 50 to 54": 6,
    "Age 55 to 59": 7,
    "Age 60 to 64": 8,
    "Age 65 to 69": 9,
    "Age 70 to 74": 10,
    "Age 75 to 79": 11,
    "Age 80 or older": 12
}
train = pd.get_dummies(train, columns=["RaceEthnicityCategory"], drop_first=True)
train['LastCheckupTime'] = train['LastCheckupTime'].astype(str).map(map_ch)
train['Sex'] = train['Sex'].astype(str).map(map_sex)
train['GeneralHealth'] = train['GeneralHealth'].astype(str).map(map_health)
train['RemovedTeeth'] = train['RemovedTeeth'].astype(str).map(map_theeth)
yes_no_cols = [
    "HadHeartAttack", "HadAngina", "HadStroke", "HadAsthma",
    "HadSkinCancer", "HadCOPD", "HadDepressiveDisorder",
    "HadKidneyDisease", "HadArthritis",
    "DeafOrHardOfHearing", "BlindOrVisionDifficulty",
    "DifficultyConcentrating", "DifficultyWalking",'PhysicalActivities',
    "DifficultyDressingBathing", "DifficultyErrands","ChestScan","AlcoholDrinkers","HIVTesting","FluVaxLast12","PneumoVaxEver","HighRiskLastYear"
]

for col in yes_no_cols:
    train[col] = train[col].astype(str).map(map_YES_NO)
train['SmokerStatus'] = train['SmokerStatus'].astype(str).map(map_SMOKER)
train['ECigaretteUsage'] = train['ECigaretteUsage'].astype(str).map(map_VAPE)
train['AgeCategory'] = train['AgeCategory'].astype(str).map(map_age)
train['TetanusLast10Tdap'] = train['TetanusLast10Tdap'].astype(str).map(map_TETANUS)
train['HadDiabetes'] = train['HadDiabetes'].astype(str).map(map_diab)
train['CovidPos'] = train['CovidPos'].astype(str).map(map_covid)


# %%
train = train.drop(columns = ['ID','State'])

# %%
train = train.dropna()

# %%
train = train.astype(int)

# %%
len(train)

# %%
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from catboost import CatBoostClassifier
from sklearn.metrics import f1_score
from sklearn.ensemble import RandomForestClassifier,VotingClassifier
from sklearn.svm import SVC
import numpy as np
from sklearn.metrics import confusion_matrix, classification_report

X = train.drop(columns='HadHeartAttack').copy()
y = train['HadHeartAttack'].copy()
scaler = StandardScaler()
X= scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=42)
# pipeline = Pipeline([('pre',StandardScaler()),('model',CatBoostClassifier(random_state=42))])
# pipeline.fit(X_train, y_train)
# y_pred = pipeline.predict(X_test)


lr = LogisticRegression(solver="saga", class_weight="balanced", max_iter=2000, random_state=42)
rf = RandomForestClassifier(n_estimators=300, max_depth=12, class_weight="balanced", random_state=42, n_jobs=-1)
cb = CatBoostClassifier(random_state=42, verbose=0)
# voting = VotingClassifier(
#     estimators=[("lr", lr), ("rf", rf), ("cb", cb)],
#     voting="soft"
# )
lr.fit(X_train, y_train)
rf.fit(X_train, y_train)
cb.fit(X_train, y_train)
p_lr = lr.predict_proba(X_test)[:, 1]
p_rf = rf.predict_proba(X_test)[:, 1]
p_cb = cb.predict_proba(X_test)[:, 1]
p = 0.2*p_lr + 0.2*p_rf + 0.6*p_cb


ths = np.linspace(0.05, 0.9, 86)
f1s = [f1_score(y_test, (p >= t).astype(int)) for t in ths]
best_i = int(np.argmax(f1s))
best_t = float(ths[best_i])
best_f1 = float(f1s[best_i])

print("thresh:", best_t)
print("F1:", best_f1)

y_pred = (p >= best_t).astype(int)

# %%


# %%
test.head()

# %%
test_ids = test['ID'].copy()

# %%
test['RaceEthnicityCategory'].value_counts()

# %%
test[num] = num_imputer.transform(test[num])
cat_test = [c for c in cat if c != "HadHeartAttack"]
cat_imputer2 = SimpleImputer(strategy="most_frequent")
test[cat_test] = cat_imputer2.fit_transform(test[cat_test])

test = pd.get_dummies(test, columns=["RaceEthnicityCategory"], drop_first=True)

test["LastCheckupTime"] = test["LastCheckupTime"].astype(str).map(map_ch)
test["Sex"] = test["Sex"].astype(str).map(map_sex)
test["GeneralHealth"] = test["GeneralHealth"].astype(str).map(map_health)
test["RemovedTeeth"] = test["RemovedTeeth"].astype(str).map(map_theeth)

yes_no_cols_test = [c for c in yes_no_cols if c in test.columns]
for col in yes_no_cols_test:
    test[col] = test[col].astype(str).map(map_YES_NO)
test["SmokerStatus"] = test["SmokerStatus"].astype(str).map(map_SMOKER)
test["ECigaretteUsage"] = test["ECigaretteUsage"].astype(str).map(map_VAPE)
test["AgeCategory"] = test["AgeCategory"].astype(str).map(map_age)
test["TetanusLast10Tdap"] = test["TetanusLast10Tdap"].astype(str).map(map_TETANUS)
test["HadDiabetes"] = test["HadDiabetes"].astype(str).map(map_diab)
test["CovidPos"] = test["CovidPos"].astype(str).map(map_covid)

test = test.drop(columns=["ID", "State"], errors="ignore")
test = test.dropna()

X_test_final = scaler.transform(test)
p_lr = lr.predict_proba(X_test_final)[:, 1]
p_rf = rf.predict_proba(X_test_final)[:, 1]
p_cb = cb.predict_proba(X_test_final)[:, 1]

p = 0.2*p_lr + 0.2*p_rf + 0.6*p_cb
y_pred_final = (p >= best_t).astype(int)


# %%
sub1 = pd.DataFrame({
    "subtaskID": [1],
    "datapointID": [0],
    "answer": [f"{ratio:.6f}"]
})

pred_yesno = pd.Series(y_pred_final).map({1: "Yes", 0: "No"})

sub2 = pd.DataFrame({
    "subtaskID": 2,
    "datapointID": test_ids.values,
    "answer": pred_yesno.values
})

output = pd.concat([sub1, sub2], ignore_index=True)
output.to_csv("output.csv", index=False)


