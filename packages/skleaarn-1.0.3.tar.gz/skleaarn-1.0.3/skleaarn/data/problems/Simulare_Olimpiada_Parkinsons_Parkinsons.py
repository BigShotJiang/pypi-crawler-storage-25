

import pandas as pd
train = pd.read_csv('train.csv')
test= pd.read_csv('test.csv')
test['Task1'] = (test['Hypertension'] == 1).astype(int) + (test['Diabetes'] == 1).astype(int) + (test['BMI'] > 30).astype(int)
test['Task1'].head()
test['Task2'] = (test['Smoking'] == 1).astype(int) + (test['AlcoholConsumption'] > 2).astype(int) + (test['PhysicalActivity'] < 1).astype(int)
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from catboost import CatBoostClassifier
from metrics import roc_auc_score
X = train.drop(columns=['Diagnosis','PatientID'])
y = train['Diagnosis']

num_cols = X.select_dtypes(exclude="object").columns
cat_cols = X.select_dtypes(include="object").columns

preprocess = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), num_cols),
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
    ],
    remainder="drop"
)

model = Pipeline(steps=[
    ("preprocess", preprocess),
    ("regressor", CatBoostClassifier(loss_function='Logloss',eval_metric='AUC',verbose=0))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model.fit(X_train, y_train)
y_pred = model.predict(X_test).reshape(-1)
auc = roc_auc_score(y_test, y_pred)
print(auc)
model.fit(X,y)
test['Task3'] = model.predict(test)
sub_task1 = pd.DataFrame({
    'PatientID': test['PatientID'],
    'subtaskID': 'Task1',
    'Answer': test['Task1']
})

sub_task2 = pd.DataFrame({
    'PatientID': test['PatientID'],
    'subtaskID': 'Task2',
    'Answer': test['Task2']
})

sub_task3 = pd.DataFrame({
    'PatientID': test['PatientID'],
    'subtaskID': 'Task3',
    'Answer': test['Task3'].round().astype(int)
})

submission = pd.concat([sub_task1, sub_task2, sub_task3], ignore_index=True)
submission.to_csv("submission.csv", index=False)
