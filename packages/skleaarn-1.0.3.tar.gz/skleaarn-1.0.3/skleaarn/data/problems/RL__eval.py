import pandas as pd
import numpy as np
from sklearn.metrics import f1_score

df_test = pd.read_csv("ground_truth.csv")
df_pred = pd.read_csv("submission.csv")
df_merged = df_test.merge(df_pred, on="state", suffixes=("_true", "_pred"))
y_pred = df_merged["action_pred"]
y_true = df_merged["action_true"]
print(f1_score(y_pred, y_true, average="weighted"))