

import pandas as pd
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
a = 3
print( a)
import cv2
import matplotlib.pyplot as plt
import os
path = os.path.join(".\dataset\images", f"sample_{train['SampleID'][20]:04d}.png")
img = cv2.imread(path,cv2.IMREAD_COLOR)
plt.imshow(img)
plt.axis("off")  
plt.show()
img.shape
#fiecare imagine e 32x32
train.head()
import numpy as np
def euclidean_distance(f1, f2):
    return np.linalg.norm(f1 - f2)
def features(image):
    hist_r = cv2.calcHist([image], [0], None, [256], [0, 256]).flatten()
    hist_g = cv2.calcHist([image], [1], None, [256], [0, 256]).flatten()
    hist_b = cv2.calcHist([image], [2], None, [256], [0, 256]).flatten()

    hist_r = hist_r / (hist_r.sum() + 1e-12)
    hist_g = hist_g / (hist_g.sum() + 1e-12)
    hist_b = hist_b / (hist_b.sum() + 1e-12)

    color_features = np.concatenate([hist_r, hist_g, hist_b]).astype(np.float32)

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    edge_density = float((edges > 0).mean())   

    mean_color = np.mean(image, axis=(0, 1)).astype(np.float32)  
    std_color  = np.std(image, axis=(0, 1)).astype(np.float32)   


    feature_vector = np.concatenate([
        color_features,
        np.array([edge_density], dtype=np.float32),
        mean_color,
        std_color
    ])

    return feature_vector
def separate_image(idx):
    sid = int(train['SampleID'].iloc[idx])
    path = os.path.join(r".\dataset\images", f"sample_{sid:04d}.png")
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    _, w, _ = img.shape
    tile = 32
    n_tiles = w // tile

    splits = []
    for i in range(n_tiles):
        roi = img[0:tile, i*tile:(i+1)*tile]
        splits.append(roi)

    return splits

T = 30
answer = []

# for idx in range(len(train)):
for idx in range(len(train)):
    count = 0
    splits = separate_image(idx)              
    feats = [features(im) for im in splits]   
    n = len(splits)
    # for i in range(len(splits)):
    #     plt.imshow(splits[i])
    #     plt.show()
    pairs = []
    for a in range(n):
        for b in range(a + 1, n):
            dist = euclidean_distance(feats[a], feats[b])
            if dist <= T:
                # pairs.append((a, b, dist))
                count+=1

    answer.append(len(splits)-count)
answer
rows = []
for idx, row in test.iterrows():
    rows.append({'SampleID':idx, 'PredictedLabel':answer[idx]})
pd.DataFrame(rows).to_csv('subs.csv',index=False)
