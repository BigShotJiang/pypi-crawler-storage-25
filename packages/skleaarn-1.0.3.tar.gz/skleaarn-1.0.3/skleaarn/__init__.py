"""
skleaarn - ML Problems Collection & Learning Notes
A collection of machine learning problem solutions and study notes.
"""

import os
import sys

__version__ = "1.0.3"

def _get_data_dir():
    return os.path.join(os.path.dirname(__file__), "data")

def install(dest=None):
    """
    Install the Sklearn folder with all ML problems and notes.
    Creates a 'Sklearn' folder on the Desktop (or dest if provided).
    Also creates a Windows Start Menu shortcut.
    """
    from skleaarn._installer import run_install
    run_install(dest)

# Auto-install on first import if SKLEARN folder doesn't exist
def _auto_install():
    marker = os.path.join(os.path.expanduser("~"), ".skleaarn_installed")
    if not os.path.exists(marker):
        try:
            from skleaarn._installer import run_install
            run_install()
            open(marker, 'w').close()
        except Exception as e:
            print(f"[skleaarn] Auto-install failed: {e}")
            print("[skleaarn] Run skleaarn.install() manually.")

_auto_install()
