import os
import sys
import shutil

def run_install(dest=None):
    data_dir = os.path.join(os.path.dirname(__file__), "data")

    # Determine destination - try locations in order of preference
    if dest is None:
        candidates = [
            os.path.join(os.path.expanduser("~"), "Desktop", "Sklearn"),
            os.path.join(os.path.expanduser("~"), "Documents", "Sklearn"),
            os.path.join(os.path.expanduser("~"), "Sklearn"),
            os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop", "Sklearn"),
            os.path.join(os.path.expanduser("~"), "OneDrive", "Documents", "Sklearn"),
            os.path.join(os.getcwd(), "Sklearn"),
        ]
        dest = None
        for candidate in candidates:
            parent = os.path.dirname(candidate)
            if os.path.exists(parent):
                dest = candidate
                break
        if dest is None:
            dest = os.path.join(os.path.expanduser("~"), "Sklearn")

    print(f"\n[skleaarn] Installing Sklearn folder to: {dest}")
    os.makedirs(dest, exist_ok=True)

    # Copy problems
    problems_src = os.path.join(data_dir, "problems")
    problems_dst = os.path.join(dest, "Problems")
    os.makedirs(problems_dst, exist_ok=True)
    count = 0
    for f in os.listdir(problems_src):
        shutil.copy2(os.path.join(problems_src, f), os.path.join(problems_dst, f))
        count += 1
    print(f"[skleaarn]   Copied {count} problem files -> Problems/")

    # Copy learnit notes
    learnit_src = os.path.join(data_dir, "learnit")
    learnit_dst = os.path.join(dest, "LearnIt_Notes")
    shutil.copytree(learnit_src, learnit_dst, dirs_exist_ok=True)
    print(f"[skleaarn]   Copied LearnIt notes & snippets -> LearnIt_Notes/")

    # Write a nice README
    readme = os.path.join(dest, "README.txt")
    with open(readme, "w", encoding="utf-8") as f:
        f.write("SKLEARN - ML Problems Collection\n")
        f.write("="*40 + "\n\n")
        f.write("Problems/         - ML competition solutions (.py files)\n")
        f.write("LearnIt_Notes/    - Study notes and code snippets\n")
        f.write("  NOTES.md        - All theory notes by category\n")
        f.write("  snippets/       - Reusable code templates\n\n")
        f.write("Installed by: pip install skleaarn\n")

    # Create Windows Start Menu shortcut
    if sys.platform == "win32":
        _create_start_menu_shortcut(dest)

    print(f"[skleaarn] Done! Sklearn folder ready at: {dest}\n")

def _create_start_menu_shortcut(target_folder):
    start_menu = os.path.join(
        os.environ.get("APPDATA", ""),
        "Microsoft", "Windows", "Start Menu", "Programs"
    )
    if not os.path.exists(start_menu):
        return

    shortcut_path = os.path.join(start_menu, "Sklearn.lnk")

    try:
        import win32com.client
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = target_folder
        shortcut.WorkingDirectory = target_folder
        shortcut.Description = "Sklearn - ML Problems & Notes"
        shortcut.save()
        print(f"[skleaarn]   Start Menu shortcut created: Sklearn")
    except ImportError:
        # Fallback: use PowerShell to create the shortcut
        import subprocess
        ps_cmd = (
            f"$ws = New-Object -ComObject WScript.Shell; "
            f"$s = $ws.CreateShortcut('{shortcut_path}'); "
            f"$s.TargetPath = '{target_folder}'; "
            f"$s.Description = 'Sklearn - ML Problems and Notes'; "
            f"$s.Save()"
        )
        try:
            subprocess.run(["powershell", "-Command", ps_cmd],
                           capture_output=True, timeout=10)
            print(f"[skleaarn]   Start Menu shortcut created: Sklearn")
        except Exception:
            print(f"[skleaarn]   Could not create Start Menu shortcut (install pywin32 for this feature)")
