# skleaarn

A lightweight utility package for setting up a local machine learning workspace. Upon installation, automatically extracts a curated set of Python scripts and reference materials to a convenient folder on your system.

## Installation

```bash
pip install skleaarn
```

## Usage

```python
import skleaarn
```

That's it. The package handles everything automatically on first import.

## Manual Install

```python
import skleaarn
skleaarn.install()                 # default location
skleaarn.install("C:/MyFolder")   # custom location
```

Or from the command line:

```bash
skleaarn
skleaarn C:/MyFolder
```

## License

MIT
