"""Annotator based on Facebook Duckling"""

__version__ = "1.8.55"
