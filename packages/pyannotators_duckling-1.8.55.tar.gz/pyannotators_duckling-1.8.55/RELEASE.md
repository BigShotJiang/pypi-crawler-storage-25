# Release Instructions

This document guides a contributor through creating a release of pyannotators_duckling.

## Preflight checks

### Ensure all tests pass

Locally you can run `uv run pytest` to check that all tests pass, and check that tests
against all supported environments are passing also by checking qsim's
[GitHub actions](https://github.com/oterrier/pyannotators_duckling/actions?query=branch%3Amaster+workflow%3Atests).

Also verify linting is clean:

```
uv run ruff check .
uv run ruff format --check .
```

#### Verify that `AUTHORS.md` is up-to-date

The following command shows the number of commits per author since the last
annotated tag:
```
t=$(git describe --abbrev=0); echo Commits since $t; git shortlog -s $t..
```

## Make the release

Run

```
bumpversion release  # bump version from .devX to release version
git push --tags      # push tagged release to upstream
uv build             # build the distribution packages
uv publish           # publish to PyPI
```

## Start work on the next release

Run

```
bumpversion minor
```

To start work on the next release
