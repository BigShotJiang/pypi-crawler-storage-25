# neo4j-cli — generated shim package
__version__ = "0.0.1"
