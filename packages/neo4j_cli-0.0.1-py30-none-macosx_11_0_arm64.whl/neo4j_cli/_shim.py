import os, sys

def main():
    here = os.path.dirname(os.path.abspath(__file__))
    binary = os.path.join(here, "neo4j-cli")
    os.execv(binary, [binary] + sys.argv[1:])
