# SPDX-License-Identifier: Apache-2.0
# Copyright 2024-2026 Dragonscale Team

"""Async E2E tests for CRUD operations."""

import pytest


@pytest.mark.asyncio
async def test_create_single_vertex_and_read(async_social_db):
    """Test creating a single vertex and reading it back with MATCH."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Alice', age: 30})")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (p:Person {name: 'Alice'}) RETURN p.name, p.age"
    )

    assert len(result) == 1
    assert result[0]["p.name"] == "Alice"
    assert result[0]["p.age"] == 30


@pytest.mark.asyncio
async def test_create_vertex_with_all_properties(async_social_db):
    """Test creating a vertex with all properties including optional ones."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute(
        "CREATE (p:Person {name: 'Bob', age: 25, email: 'bob@example.com'})"
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (p:Person {name: 'Bob'}) RETURN p.name, p.age, p.email"
    )

    assert len(result) == 1
    assert result[0]["p.name"] == "Bob"
    assert result[0]["p.age"] == 25
    assert result[0]["p.email"] == "bob@example.com"


@pytest.mark.asyncio
async def test_create_vertex_with_nullable_property_omitted(async_social_db):
    """Test creating a vertex with optional property omitted."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Charlie', age: 35})")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (p:Person {name: 'Charlie'}) RETURN p.name, p.age, p.email"
    )

    assert len(result) == 1
    assert result[0]["p.name"] == "Charlie"
    assert result[0]["p.age"] == 35
    assert result[0].get("p.email") is None


@pytest.mark.asyncio
async def test_create_multiple_vertices(async_social_db):
    """Test creating multiple vertices in one operation."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p1:Person {name: 'Diana', age: 28})")
    await tx.execute("CREATE (p2:Person {name: 'Eve', age: 32})")
    await tx.execute("CREATE (p3:Person {name: 'Frank', age: 40})")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (p:Person) WHERE p.name IN ['Diana', 'Eve', 'Frank'] RETURN p.name ORDER BY p.name"
    )

    assert len(result) == 3
    assert result[0]["p.name"] == "Diana"
    assert result[1]["p.name"] == "Eve"
    assert result[2]["p.name"] == "Frank"


@pytest.mark.asyncio
async def test_create_edge_between_vertices(async_social_db):
    """Test creating an edge between two vertices."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Grace', age: 29})")
    await tx.execute("CREATE (p:Person {name: 'Henry', age: 31})")
    await tx.commit()
    await async_social_db.flush()

    tx = await session.tx()
    await tx.execute(
        "MATCH (a:Person {name: 'Grace'}), (b:Person {name: 'Henry'}) CREATE (a)-[:KNOWS]->(b)"
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (a:Person {name: 'Grace'})-[:KNOWS]->(b:Person {name: 'Henry'}) RETURN a.name, b.name"
    )

    assert len(result) == 1
    assert result[0]["a.name"] == "Grace"
    assert result[0]["b.name"] == "Henry"


@pytest.mark.asyncio
async def test_create_edge_with_properties(async_social_db):
    """Test creating an edge with properties."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Ivy', age: 27})")
    await tx.execute("CREATE (p:Person {name: 'Jack', age: 33})")
    await tx.commit()
    await async_social_db.flush()

    tx = await session.tx()
    await tx.execute(
        "MATCH (a:Person {name: 'Ivy'}), (b:Person {name: 'Jack'}) "
        "CREATE (a)-[:KNOWS {since: 2020}]->(b)"
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (a:Person {name: 'Ivy'})-[k:KNOWS]->(b:Person {name: 'Jack'}) "
        "RETURN a.name, b.name, k.since"
    )

    assert len(result) == 1
    assert result[0]["a.name"] == "Ivy"
    assert result[0]["b.name"] == "Jack"
    assert result[0]["k.since"] == 2020


@pytest.mark.asyncio
async def test_match_vertex_by_property(async_social_db):
    """Test matching a vertex by a specific property."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Kelly', age: 26})")
    await tx.execute("CREATE (p:Person {name: 'Leo', age: 26})")
    await tx.execute("CREATE (p:Person {name: 'Mia', age: 30})")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (p:Person {age: 26}) RETURN p.name ORDER BY p.name"
    )

    assert len(result) == 2
    assert result[0]["p.name"] == "Kelly"
    assert result[1]["p.name"] == "Leo"


@pytest.mark.asyncio
async def test_match_with_where_clause(async_social_db):
    """Test matching vertices with WHERE clause."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Nina', age: 24})")
    await tx.execute("CREATE (p:Person {name: 'Oscar', age: 35})")
    await tx.execute("CREATE (p:Person {name: 'Paul', age: 42})")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (p:Person) WHERE p.age >= 30 AND p.age < 40 RETURN p.name, p.age ORDER BY p.name"
    )

    assert len(result) == 1
    assert result[0]["p.name"] == "Oscar"
    assert result[0]["p.age"] == 35


@pytest.mark.asyncio
async def test_set_property_on_vertex(async_social_db):
    """Test updating a property on a vertex using SET."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Quinn', age: 28})")
    await tx.commit()
    await async_social_db.flush()

    tx = await session.tx()
    await tx.execute("MATCH (p:Person {name: 'Quinn'}) SET p.age = 29")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query("MATCH (p:Person {name: 'Quinn'}) RETURN p.age")

    assert len(result) == 1
    assert result[0]["p.age"] == 29


@pytest.mark.asyncio
async def test_set_property_on_edge(async_social_db):
    """Test updating a property on an edge using SET."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Rachel', age: 30})")
    await tx.execute("CREATE (p:Person {name: 'Sam', age: 32})")
    await tx.execute(
        "MATCH (a:Person {name: 'Rachel'}), (b:Person {name: 'Sam'}) "
        "CREATE (a)-[:KNOWS {since: 2015}]->(b)"
    )
    await tx.commit()
    await async_social_db.flush()

    tx = await session.tx()
    await tx.execute(
        "MATCH (a:Person {name: 'Rachel'})-[k:KNOWS]->(b:Person {name: 'Sam'}) "
        "SET k.since = 2018"
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (a:Person {name: 'Rachel'})-[k:KNOWS]->(b:Person {name: 'Sam'}) "
        "RETURN k.since"
    )

    assert len(result) == 1
    assert result[0]["k.since"] == 2018


@pytest.mark.asyncio
async def test_delete_vertex(async_social_db):
    """Test deleting a vertex."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Tina', age: 27})")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query("MATCH (p:Person {name: 'Tina'}) RETURN p.name")
    assert len(result) == 1

    tx = await session.tx()
    await tx.execute("MATCH (p:Person {name: 'Tina'}) DELETE p")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query("MATCH (p:Person {name: 'Tina'}) RETURN p.name")
    assert len(result) == 0


@pytest.mark.asyncio
async def test_delete_edge(async_social_db):
    """Test deleting an edge."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Uma', age: 29})")
    await tx.execute("CREATE (p:Person {name: 'Victor', age: 31})")
    await tx.execute(
        "MATCH (a:Person {name: 'Uma'}), (b:Person {name: 'Victor'}) "
        "CREATE (a)-[:KNOWS]->(b)"
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (a:Person {name: 'Uma'})-[:KNOWS]->(b:Person {name: 'Victor'}) "
        "RETURN a.name, b.name"
    )
    assert len(result) == 1

    tx = await session.tx()
    await tx.execute(
        "MATCH (a:Person {name: 'Uma'})-[k:KNOWS]->(b:Person {name: 'Victor'}) DELETE k"
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (a:Person {name: 'Uma'})-[:KNOWS]->(b:Person {name: 'Victor'}) "
        "RETURN a.name"
    )
    assert len(result) == 0

    result = await session.query(
        "MATCH (p:Person) WHERE p.name IN ['Uma', 'Victor'] RETURN p.name"
    )
    assert len(result) == 2


@pytest.mark.asyncio
async def test_delete_vertex_with_cascading_edge_removal(async_social_db):
    """Test deleting a vertex with its connected edges."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Wendy', age: 28})")
    await tx.execute("CREATE (p:Person {name: 'Xavier', age: 30})")
    await tx.execute("CREATE (p:Person {name: 'Yara', age: 26})")
    await tx.execute(
        "MATCH (a:Person {name: 'Wendy'}), (b:Person {name: 'Xavier'}) "
        "CREATE (a)-[:KNOWS]->(b)"
    )
    await tx.execute(
        "MATCH (a:Person {name: 'Wendy'}), (b:Person {name: 'Yara'}) "
        "CREATE (a)-[:KNOWS]->(b)"
    )
    await tx.commit()
    await async_social_db.flush()

    tx = await session.tx()
    await tx.execute("MATCH (p:Person {name: 'Wendy'}) DETACH DELETE p")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query("MATCH (p:Person {name: 'Wendy'}) RETURN p.name")
    assert len(result) == 0

    result = await session.query(
        "MATCH (p:Person) WHERE p.name IN ['Xavier', 'Yara'] RETURN p.name"
    )
    assert len(result) == 2


@pytest.mark.asyncio
async def test_merge_vertex_upsert(async_social_db):
    """Test MERGE for upserting a vertex."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("MERGE (p:Person {name: 'Zara', age: 25})")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query("MATCH (p:Person {name: 'Zara'}) RETURN p.age")
    assert len(result) == 1
    assert result[0]["p.age"] == 25

    tx = await session.tx()
    await tx.execute("MERGE (p:Person {name: 'Zara', age: 25})")
    await tx.commit()
    await async_social_db.flush()

    result = await session.query("MATCH (p:Person {name: 'Zara'}) RETURN p.age")
    assert len(result) == 1
    assert result[0]["p.age"] == 25  # Should still be original value


@pytest.mark.asyncio
async def test_merge_edge(async_social_db):
    """Test MERGE for upserting an edge."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute("CREATE (p:Person {name: 'Adam', age: 33})")
    await tx.execute("CREATE (p:Person {name: 'Beth', age: 29})")
    await tx.commit()
    await async_social_db.flush()

    tx = await session.tx()
    await tx.execute(
        "MATCH (a:Person {name: 'Adam'}), (b:Person {name: 'Beth'}) "
        "MERGE (a)-[k:KNOWS]->(b) ON CREATE SET k.since = 2021"
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (a:Person {name: 'Adam'})-[k:KNOWS]->(b:Person {name: 'Beth'}) "
        "RETURN k.since"
    )
    assert len(result) == 1
    assert result[0]["k.since"] == 2021

    tx = await session.tx()
    await tx.execute(
        "MATCH (a:Person {name: 'Adam'}), (b:Person {name: 'Beth'}) "
        "MERGE (a)-[k:KNOWS]->(b) ON CREATE SET k.since = 2023"
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (a:Person {name: 'Adam'})-[k:KNOWS]->(b:Person {name: 'Beth'}) "
        "RETURN k.since"
    )
    assert len(result) == 1
    assert result[0]["k.since"] == 2021  # Should still be original value


@pytest.mark.asyncio
async def test_match_and_return_multiple_properties(async_social_db):
    """Test matching and returning multiple properties."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute(
        "CREATE (p:Person {name: 'Carol', age: 34, email: 'carol@example.com'})"
    )
    await tx.execute("CREATE (c:Company {name: 'TechCorp', founded: 2010})")
    await tx.execute(
        "MATCH (p:Person {name: 'Carol'}), (c:Company {name: 'TechCorp'}) "
        "CREATE (p)-[:WORKS_AT {role: 'Engineer'}]->(c)"
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (p:Person {name: 'Carol'})-[w:WORKS_AT]->(c:Company) "
        "RETURN p.name, p.age, p.email, c.name, c.founded, w.role"
    )

    assert len(result) == 1
    assert result[0]["p.name"] == "Carol"
    assert result[0]["p.age"] == 34
    assert result[0]["p.email"] == "carol@example.com"
    assert result[0]["c.name"] == "TechCorp"
    assert result[0]["c.founded"] == 2010
    assert result[0]["w.role"] == "Engineer"


@pytest.mark.asyncio
async def test_create_with_parameterized_queries(async_social_db):
    """Test CREATE with parameterized queries using $param syntax."""

    session = async_social_db.session()

    tx = await session.tx()
    await tx.execute(
        "CREATE (p:Person {name: $name, age: $age})",
        params={"name": "David", "age": 36},
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (p:Person {name: $name}) RETURN p.name, p.age", params={"name": "David"}
    )

    assert len(result) == 1
    assert result[0]["p.name"] == "David"
    assert result[0]["p.age"] == 36

    tx = await session.tx()
    await tx.execute(
        "CREATE (p:Person {name: $name, age: $age})", params={"name": "Emma", "age": 28}
    )
    await tx.execute(
        "MATCH (a:Person {name: $name1}), (b:Person {name: $name2}) "
        "CREATE (a)-[:KNOWS {since: $since}]->(b)",
        params={"name1": "David", "name2": "Emma", "since": 2019},
    )
    await tx.commit()
    await async_social_db.flush()

    result = await session.query(
        "MATCH (a:Person {name: $name1})-[k:KNOWS]->(b:Person {name: $name2}) "
        "RETURN a.name, b.name, k.since",
        params={"name1": "David", "name2": "Emma"},
    )

    assert len(result) == 1
    assert result[0]["a.name"] == "David"
    assert result[0]["b.name"] == "Emma"
    assert result[0]["k.since"] == 2019
