"""
Content Hub CLI — format ideas into platform-specific posts.

Usage:
    viral hub format 42 --platforms twitter,linkedin
    viral hub show 42
    viral hub export --ideas 42,43 --format json
    viral hub usage
    viral hub webhooks list
"""
import json
import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from viral_cli.client import ViralClient
from viral_cli.output import OutputFormat, render, print_json, print_single

app = typer.Typer(no_args_is_help=True)
console = Console()

PLATFORMS_ALL = "twitter,linkedin,instagram,facebook,tiktok,threads,youtube,reddit,substack"

POST_COLUMNS = [
    ("platform", "Platform"),
    ("char_count", "Chars"),
    ("estimated_score", "Score"),
    ("text_preview", "Text Preview"),
]

WEBHOOK_COLUMNS = [
    ("id", "ID"),
    ("webhook_url", "URL"),
    ("events", "Events"),
    ("is_active", "Active"),
    ("failure_count", "Failures"),
]


def _truncate(text: str, max_len: int = 80) -> str:
    return text[:max_len] + "..." if len(text) > max_len else text


@app.command("format")
def format_idea(
    idea_id: int = typer.Argument(..., help="ID of the idea to format"),
    platforms: str = typer.Option("twitter,linkedin,instagram", "--platforms", "-p", help="Comma-separated platforms"),
    all_platforms: bool = typer.Option(False, "--all-platforms", "-a", help="Format for all 9 platforms"),
    with_image: bool = typer.Option(False, "--with-image", help="Generate Pillow branded image"),
    fmt: OutputFormat = typer.Option("table", "--format", "-f"),
) -> None:
    """Format an idea into platform-specific posts via AI."""
    try:
        client = ViralClient()
        target = PLATFORMS_ALL if all_platforms else platforms
        platform_list = [p.strip() for p in target.split(",") if p.strip()]

        console.print(f"[bold]Formatting idea #{idea_id}[/bold] for {', '.join(platform_list)}...")

        resp = client.post("/api/v1/content-hub/format", json_body={
            "idea_id": idea_id,
            "platforms": platform_list,
            "generate_image": with_image,
        })

        if fmt == OutputFormat.json:
            print_json(resp)
            return

        # Show each platform post
        platforms_data = resp.get("platforms", {})
        console.print(f"\n[bold green]Generated {len(platforms_data)} posts[/bold green] "
                       f"(model: {resp.get('ai_model_used', '?')}, "
                       f"tokens: {resp.get('ai_tokens_used', 0)})\n")

        for platform, post in platforms_data.items():
            text = post.get("text", "")
            hashtags = post.get("hashtags", [])
            char_count = post.get("char_count", len(text))
            score = post.get("estimated_score", "?")

            panel_content = Text()
            panel_content.append(text + "\n\n")
            if hashtags:
                panel_content.append(" ".join(hashtags), style="bold cyan")
                panel_content.append("\n")
            if post.get("image_prompt"):
                panel_content.append(f"\nImage Prompt: ", style="bold yellow")
                panel_content.append(post["image_prompt"])
            if post.get("video_prompt"):
                panel_content.append(f"\nVideo Prompt: ", style="bold magenta")
                panel_content.append(post["video_prompt"])

            # Reddit metadata
            if platform == "reddit" and post.get("metadata", {}).get("suggested_subreddits"):
                subs = post["metadata"]["suggested_subreddits"]
                panel_content.append(f"\nSubreddits: ", style="bold red")
                panel_content.append(", ".join(f"r/{s}" for s in subs))

            console.print(Panel(
                panel_content,
                title=f"[bold]{platform.upper()}[/bold] ({char_count} chars, score: {score}/10)",
                border_style="cyan",
                padding=(1, 2),
            ))

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@app.command("show")
def show_posts(
    idea_id: int = typer.Argument(..., help="ID of the idea"),
    platform: str = typer.Option(None, "--platform", "-p", help="Specific platform"),
    fmt: OutputFormat = typer.Option("table", "--format", "-f"),
) -> None:
    """Show cached formatted posts for an idea."""
    try:
        client = ViralClient()

        if platform:
            resp = client.get(f"/api/v1/content-hub/posts/{idea_id}/{platform}")
            if fmt == OutputFormat.json:
                print_json(resp)
            else:
                print_single(resp, [
                    ("platform", "Platform"),
                    ("text", "Text"),
                    ("hashtags", "Hashtags"),
                    ("char_count", "Characters"),
                    ("estimated_score", "Score"),
                    ("image_prompt", "Image Prompt"),
                    ("video_prompt", "Video Prompt"),
                ])
        else:
            resp = client.get(f"/api/v1/content-hub/posts/{idea_id}")
            if fmt == OutputFormat.json:
                print_json(resp)
            else:
                platforms_data = resp.get("platforms", {})
                items = []
                for p, post in platforms_data.items():
                    items.append({
                        "platform": p,
                        "char_count": post.get("char_count", 0),
                        "estimated_score": post.get("estimated_score", "?"),
                        "text_preview": _truncate(post.get("text", ""), 60),
                    })
                render(items, fmt, columns=POST_COLUMNS, title=f"Formatted Posts (Idea #{idea_id})")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@app.command("export")
def export_posts(
    ideas: str = typer.Option(..., "--ideas", "-i", help="Comma-separated idea IDs"),
    fmt: str = typer.Option("json", "--format", "-f", help="json or csv"),
) -> None:
    """Export formatted posts as JSON or CSV."""
    try:
        client = ViralClient()
        resp = client.get(f"/api/v1/content-hub/export", params={
            "idea_ids": ideas,
            "format": fmt,
        })
        if fmt == "json":
            print_json(resp)
        else:
            # CSV is returned as raw text from the API
            import sys
            sys.stdout.write(json.dumps(resp, ensure_ascii=False, indent=2) if isinstance(resp, dict) else str(resp))

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@app.command("usage")
def hub_usage(
    fmt: OutputFormat = typer.Option("table", "--format", "-f"),
) -> None:
    """Show Content Hub usage for current month."""
    try:
        client = ViralClient()
        resp = client.get("/api/v1/content-hub/usage")

        if fmt == OutputFormat.json:
            print_json(resp)
        else:
            print_single(resp, [
                ("plan", "Plan"),
                ("formats_used", "Formats Used"),
                ("formats_limit", "Formats Limit"),
                ("platforms_per_format", "Platforms/Format"),
                ("available_platforms", "Available Platforms"),
            ])

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


# ── Webhook subcommands ───────────────────────────────

webhooks_app = typer.Typer(no_args_is_help=True)
app.add_typer(webhooks_app, name="webhooks", help="Manage outgoing webhooks")


@webhooks_app.command("list")
def list_webhooks(
    fmt: OutputFormat = typer.Option("table", "--format", "-f"),
) -> None:
    """List configured webhooks."""
    try:
        client = ViralClient()
        resp = client.get("/api/v1/content-hub/webhooks")

        if fmt == OutputFormat.json:
            print_json(resp)
        else:
            items = []
            for w in resp:
                items.append({
                    "id": w.get("id"),
                    "webhook_url": _truncate(w.get("webhook_url", ""), 50),
                    "events": ", ".join(w.get("events", [])),
                    "is_active": w.get("is_active"),
                    "failure_count": w.get("failure_count", 0),
                })
            render(items, fmt, columns=WEBHOOK_COLUMNS, title="Webhooks")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@webhooks_app.command("add")
def add_webhook(
    url: str = typer.Argument(..., help="Webhook URL (https://)"),
    events: str = typer.Option("post.formatted", "--events", "-e", help="Comma-separated events"),
) -> None:
    """Add a webhook URL."""
    try:
        client = ViralClient()
        event_list = [e.strip() for e in events.split(",")]
        resp = client.post("/api/v1/content-hub/webhooks", json_body={
            "webhook_url": url,
            "events": event_list,
        })
        console.print(f"[green]Webhook created: ID {resp.get('id')}[/green]")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@webhooks_app.command("test")
def test_webhook(
    webhook_id: int = typer.Argument(..., help="Webhook ID to test"),
) -> None:
    """Send a test payload to a webhook."""
    try:
        client = ViralClient()
        resp = client.post(f"/api/v1/content-hub/webhooks/{webhook_id}/test")
        if resp.get("success"):
            console.print(f"[green]Webhook test succeeded (status: {resp.get('status_code')})[/green]")
        else:
            console.print(f"[red]Webhook test failed: {resp.get('error')}[/red]")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@webhooks_app.command("remove")
def remove_webhook(
    webhook_id: int = typer.Argument(..., help="Webhook ID to remove"),
) -> None:
    """Remove a webhook."""
    try:
        client = ViralClient()
        client.delete(f"/api/v1/content-hub/webhooks/{webhook_id}")
        console.print(f"[green]Webhook {webhook_id} removed[/green]")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
