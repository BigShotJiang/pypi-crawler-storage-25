"""Media generation commands: subtitle, music, background, voice, erase."""
import typer

from viral_cli.client import ViralClient
from viral_cli.constants import API
from viral_cli.errors import handle_error
from viral_cli.output import OutputFormat, render

app = typer.Typer(no_args_is_help=True, help="AI media generation tools (subtitles, music, voice, etc.)")

JOB_COLUMNS = [
    ("id", "ID"),
    ("actor_type", "Type"),
    ("status", "Status"),
    ("cost_usd", "Cost $"),
    ("duration_secs", "Duration"),
    ("created_at", "Created"),
]


@app.command("subtitle")
def generate_subtitle(
    file_url: str = typer.Argument(..., help="URL to video or audio file"),
    language: str = typer.Option("auto", "--lang", "-l", help="Source language (auto, en, pt, es, etc.)"),
    style: str = typer.Option("tiktok", "--style", "-s", help="Burn-in style: none, tiktok, youtube, netflix, karaoke, minimal, bold, neon, news, cinematic"),
    translate: bool = typer.Option(False, "--translate", "-t", help="Translate to English"),
    fmt: OutputFormat = typer.Option(OutputFormat.json, "--format", "-f"),
):
    """Generate AI subtitles for video/audio using Whisper V3 Turbo (99 languages)."""
    with handle_error():
        client = ViralClient()
        result = client.post(API.MEDIA_SUBTITLE_GEN, params={
            "file_url": file_url,
            "language": language,
            "style": style,
            "translate_to_english": translate,
        })
        render(result, fmt=fmt)


@app.command("music")
def generate_music(
    prompt: str = typer.Argument(..., help="Music description (genre, instruments, mood)"),
    style: str = typer.Option("cinematic", "--style", "-s", help="Style preset: cinematic, lofi, corporate, epic, edm, jazz, ambient, rock, pop, etc."),
    duration: int = typer.Option(30, "--duration", "-d", help="Duration in seconds (5-60)"),
    fmt: OutputFormat = typer.Option(OutputFormat.json, "--format", "-f"),
):
    """Generate AI music track using MusicGen Large 3.3B (up to 60s)."""
    with handle_error():
        client = ViralClient()
        result = client.post(API.MEDIA_MUSIC_GEN, params={
            "prompt": prompt,
            "style": style,
            "duration": duration,
        })
        render(result, fmt=fmt)


@app.command("remove-bg")
def remove_background(
    image_url: str = typer.Argument(..., help="URL to image"),
    mode: str = typer.Option("transparent", "--mode", "-m", help="Background mode: transparent, white, black, blur, custom_color"),
    color: str = typer.Option("#ffffff", "--color", "-c", help="Hex color for custom_color mode"),
    fmt: OutputFormat = typer.Option(OutputFormat.json, "--format", "-f"),
):
    """Remove background from image using BiRefNet AI segmentation."""
    with handle_error():
        client = ViralClient()
        result = client.post(API.MEDIA_BG_REMOVE, params={
            "image_url": image_url,
            "background_mode": mode,
            "color_hex": color,
        })
        render(result, fmt=fmt)


@app.command("voice")
def generate_voice(
    text: str = typer.Argument(..., help="Text to speak (max 5000 chars)"),
    voice: str = typer.Option("narrator", "--voice", "-v", help="Voice style: narrator, podcast, commercial, news, dramatic, calm, energetic, whisper"),
    language: str = typer.Option("en", "--lang", "-l", help="Language: en, pt, es, fr, de, ja, ko, zh"),
    speed: float = typer.Option(1.0, "--speed", "-s", help="Speed multiplier (0.5-2.0)"),
    fmt: OutputFormat = typer.Option(OutputFormat.json, "--format", "-f"),
):
    """Generate speech audio using Edge TTS neural voices (8 styles, 8 languages)."""
    with handle_error():
        client = ViralClient()
        result = client.post(API.MEDIA_VOICE_GEN, params={
            "text": text,
            "voice_style": voice,
            "language": language,
            "speed": speed,
        })
        render(result, fmt=fmt)


@app.command("erase-subtitle")
def erase_subtitles(
    file_url: str = typer.Argument(..., help="URL to video or image with hardcoded subtitles"),
    region: str = typer.Option("auto", "--region", "-r", help="Detection: auto (OCR) or bottom_third"),
    fmt: OutputFormat = typer.Option(OutputFormat.json, "--format", "-f"),
):
    """Remove hardcoded subtitles/watermarks using LAMA AI inpainting."""
    with handle_error():
        client = ViralClient()
        result = client.post(API.MEDIA_SUBTITLE_ERASE, params={
            "file_url": file_url,
            "region": region,
        })
        render(result, fmt=fmt)


@app.command("jobs")
def list_jobs(
    actor_type: str = typer.Option(None, "--type", "-t", help="Filter: subtitle_generator, music_generator, background_remover, voice_generator, subtitle_eraser"),
    limit: int = typer.Option(20, "--limit", "-n"),
    fmt: OutputFormat = typer.Option(OutputFormat.table, "--format", "-f"),
):
    """List media generation jobs."""
    with handle_error():
        client = ViralClient()
        params = {"limit": limit}
        if actor_type:
            params["actor_type"] = actor_type
        result = client.get(API.MEDIA_JOBS, params=params)
        render(result, columns=JOB_COLUMNS, fmt=fmt)


@app.command("usage")
def media_usage(
    fmt: OutputFormat = typer.Option(OutputFormat.table, "--format", "-f"),
):
    """Show monthly media generation usage and costs."""
    with handle_error():
        client = ViralClient()
        result = client.get(API.MEDIA_USAGE)
        render(result, columns=[
            ("actor_type", "Actor"),
            ("job_count", "Jobs"),
            ("total_cost_usd", "Cost $"),
            ("total_duration_mins", "Minutes"),
            ("month_year", "Month"),
        ], fmt=fmt)


@app.command("dashboard")
def media_dashboard(
    days: int = typer.Option(30, "--days", "-d"),
    fmt: OutputFormat = typer.Option(OutputFormat.json, "--format", "-f"),
):
    """Show media generation dashboard KPIs."""
    with handle_error():
        client = ViralClient()
        result = client.get(API.MEDIA_DASHBOARD, params={"days": days})
        render(result, fmt=fmt)
