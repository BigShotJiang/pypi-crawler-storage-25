"""Central registry of API paths and app constants."""

APP_NAME = "viral-analyzer-cli"
APP_VERSION = "0.2.0"
DEFAULT_API_URL = "https://api.viralanalyzer.com.br"
CONFIG_DIR_NAME = ".viralanalyzer"
CONFIG_FILE_NAME = "config.json"


class API:
    """All API v1 paths used by the CLI."""

    AUTH_REGISTER = "/api/v1/billing/register"
    AUTH_LOGIN = "/api/v1/auth/login"
    AUTH_ME = "/api/v1/auth/me"
    AUTH_REFRESH = "/api/v1/auth/refresh"

    CONTENT = "/api/v1/content"
    IDEAS = "/api/v1/ideas"
    IDEAS_GENERATE = "/api/v1/ideas/generate"
    IDEAS_LIFECYCLE = "/api/v1/ideas/lifecycle/summary"

    TRENDS = "/api/v1/trends"
    PROFILES = "/api/v1/profiles"

    DASHBOARD_STATS = "/api/v1/dashboard/stats"
    DASHBOARD_HISTORY = "/api/v1/dashboard/history"

    BILLING_USAGE = "/api/v1/billing/usage"

    AI_SETTINGS = "/api/v1/ai-settings"
    AI_SETTINGS_USAGE = "/api/v1/ai-settings/usage"
    AI_SETTINGS_MODELS = "/api/v1/ai-settings/models"

    PIPELINE_TRIGGER = "/api/v1/pipelines/trigger"
    PIPELINE_RUNS = "/api/v1/pipelines/runs"
    PIPELINE_CONFIGS = "/api/v1/pipeline-configs"

    # Content Hub
    CONTENT_HUB_FORMAT = "/api/v1/content-hub/format"
    CONTENT_HUB_BATCH = "/api/v1/content-hub/batch-format"
    CONTENT_HUB_POSTS = "/api/v1/content-hub/posts"
    CONTENT_HUB_EXPORT = "/api/v1/content-hub/export"
    CONTENT_HUB_USAGE = "/api/v1/content-hub/usage"
    CONTENT_HUB_WEBHOOKS = "/api/v1/content-hub/webhooks"

    # Media Generation
    MEDIA_SUBTITLE_GEN = "/api/v1/media/subtitle/generate"
    MEDIA_MUSIC_GEN = "/api/v1/media/music/generate"
    MEDIA_BG_REMOVE = "/api/v1/media/background/remove"
    MEDIA_VOICE_GEN = "/api/v1/media/voice/generate"
    MEDIA_SUBTITLE_ERASE = "/api/v1/media/subtitle/erase"
    MEDIA_JOBS = "/api/v1/media/jobs"
    MEDIA_USAGE = "/api/v1/media/usage"
    MEDIA_DASHBOARD = "/api/v1/media/dashboard/stats"
