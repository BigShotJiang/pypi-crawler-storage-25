"""ViralAnalyzer CLI — competitive intelligence from your terminal."""

__version__ = "0.1.0"
