from pydefend.types import Action, DefendResult, Severity, Violation


def test_defend_result_bool() -> None:
    r = DefendResult(
        flagged=False,
        action=Action.PASSED,
        text="ok",
        original_text="ok",
    )
    assert bool(r) is True
    r2 = DefendResult(
        flagged=True,
        action=Action.FLAGGED,
        text="ok",
        original_text="ok",
        violations=[
            Violation(
                module="m",
                category=None,
                severity=Severity.LOW,
                confidence=0.5,
                action_taken=Action.FLAGGED,
            )
        ],
    )
    assert bool(r2) is False


def test_to_dict_roundtrip_keys() -> None:
    r = DefendResult(
        flagged=True,
        action=Action.BLOCKED,
        text=None,
        original_text="x",
        latency_ms=1.5,
        module_latencies={"a": 1.0},
        provider="p",
    )
    d = r.to_dict()
    assert d["action"] == "blocked"
    assert d["text"] is None
