import pytest

from pydefend.core import Defend
from pydefend.modules import Injection
from pydefend.orchestrator import apply_redactions
from pydefend.policy import OnFail
from pydefend.providers.base import BaseProvider, ClassifierBatchResult, ClassifierModuleOutcome
from pydefend.types import Action


class MockProvider(BaseProvider):
    name = "mock"

    def __init__(self, outcomes: list[ClassifierModuleOutcome]) -> None:
        self._out = outcomes

    async def classify_modules(self, text, modules, allowed_module_names, **kwargs):
        return ClassifierBatchResult(outcomes=list(self._out), latency_ms=5.0, provider=self.name)


@pytest.mark.asyncio
async def test_scan_blocks_when_injection_triggers() -> None:
    prov = MockProvider(
        [ClassifierModuleOutcome(module="injection", triggered=True, confidence=0.95, explanation="inj")],
    )
    d = Defend(provider=prov, modules=[Injection(on_fail=OnFail.BLOCK)])
    r = await d.scan("hello")
    assert not r
    assert r.action == Action.BLOCKED
    assert r.text is None


@pytest.mark.asyncio
async def test_redact_with_spans() -> None:
    prov = MockProvider(
        [
            ClassifierModuleOutcome(module="injection", triggered=False, confidence=0.0),
            ClassifierModuleOutcome(
                module="pii",
                triggered=True,
                confidence=0.9,
                spans=[(3, 6)],
            ),
        ],
    )
    from pydefend.modules import Pii

    d = Defend(provider=prov, modules=[Injection(), Pii(on_fail=OnFail.REDACT)])
    r = await d.scan("hi SSn")
    assert r.text is not None
    assert "[REDACTED]" in (r.text or "")


def test_apply_redactions() -> None:
    assert apply_redactions("abcdef", [(1, 3)]) == "a[REDACTED]def"
