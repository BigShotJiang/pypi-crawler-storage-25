from pathlib import Path

import pytest

from pydefend.config import load_defend_config
from pydefend.exceptions import ConfigError


def test_load_minimal_yaml(tmp_path: Path) -> None:
    p = tmp_path / "defend.yaml"
    p.write_text(
        """
provider: auto
timeout: 5.0
modules:
  input:
    - injection: {strict: true}
  output:
    - prompt_leak: {}
""",
        encoding="utf-8",
    )
    d = load_defend_config(p)
    names = {m.name for m in d._rt.all_modules}
    assert "injection" in names
    assert "prompt_leak" in names


def test_invalid_module_raises(tmp_path: Path) -> None:
    p = tmp_path / "bad.yaml"
    p.write_text("modules:\n  input:\n    - not_a_real_module: {}\n", encoding="utf-8")
    with pytest.raises(ConfigError):
        load_defend_config(p)
