<p align="center">
  <img src="assets/header.jpg" alt="Defend - AI security guardrails for LLM applications" width="100%" />
</p>

<p align="center"><strong>AI security guardrails for LLM applications</strong></p>

<p align="center">
  <img src="https://img.shields.io/badge/license-Apache--2.0-blue" alt="License: Apache-2.0" />
  <img src="https://img.shields.io/badge/python-3.10%2B-blue" alt="Python: 3.10+" />
</p>

**Defend** sits around your LLM calls: **scan** user text on the way in, run your model as usual, **check** the reply on the way out.

Pick the modules you need (injection, PII, prompt leaks, URLs, and more). Every scan answers the same way: pass, flag, block, or redact.

Wire it up in Python or drop a `defend.yaml` in the repo. No extra service to deploy.

## Install

```bash
pip install pydefend
```

Set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` (or configure another [provider](https://www.pydefend.com/docs) via env).

## Quick start

```python
import asyncio
from pydefend import Defend

defend = Defend.default()

async def main():
    result = await defend.scan("User message here")
    if not result:
        return "Can't help with that."
    # ... call your LLM with result.text ...
    out = await defend.check("Model reply here")
    return out.text if out else None

asyncio.run(main())
```

`Defend.default()` is a sensible starting preset; customize with `Defend.from_yaml("defend.yaml")`, the fluent builder (`Defend().input(...).output(...).build()`), or by passing your own modules.

## How it works

Defend doesn’t replace your LLM—it wraps the text going **in** and **out**. You keep your provider SDK and prompts; pydefend adds `scan` before the model and `check` after, with modules you enable.

<p align="center">
  <img src="assets/pipeline.jpg" alt="Flow: user input through input guard, then your LLM, then output guard, then safe response to user" width="100%" />
</p>

That flow is the baseline: one message in, one reply out. The same `Defend` instance also supports:

- **`scan_batch`** — many texts in one go (e.g. RAG chunks before they hit the prompt)
- **`scan_conversation`** — full thread history, not just the latest user line
- **`check_structured`** — guard JSON-shaped (or similar) model output
- **`scan_tool_call`** — validate a tool invocation before your agent runs it

Same modules and **`DefendResult`** everywhere; only the call site changes.

Read **[pydefend.com/docs](https://www.pydefend.com/docs)** for APIs, examples, and configuration.

## License

Apache-2.0 — see [LICENSE](LICENSE).
