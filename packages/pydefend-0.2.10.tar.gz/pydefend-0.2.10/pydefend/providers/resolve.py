from __future__ import annotations

import os

from .azure import AzureOpenAIProvider
from .base import BaseProvider
from .claude import ClaudeProvider
from .ollama import OllamaProvider
from .openai import OpenAIProvider


def resolve_provider(
    *,
    provider: str | None = None,
    model: str | None = None,
) -> BaseProvider:
    """
    Resolve provider from explicit name or DEFEND_PROVIDER / env keys (auto).
    """
    d = (provider or os.environ.get("DEFEND_PROVIDER") or "auto").strip().lower()
    if d == "anthropic":
        return ClaudeProvider(model=model or "claude-haiku-4-5")
    if d == "openai":
        return OpenAIProvider(model=model or "gpt-4o-mini")
    if d == "azure":
        return AzureOpenAIProvider(model=model)
    if d == "ollama":
        return OllamaProvider(model=model)
    if d == "auto":
        if os.environ.get("ANTHROPIC_API_KEY"):
            return ClaudeProvider(model=model or "claude-haiku-4-5")
        if os.environ.get("OPENAI_API_KEY"):
            return OpenAIProvider(model=model or "gpt-4o-mini")
        if os.environ.get("AZURE_OPENAI_ENDPOINT") and os.environ.get("AZURE_OPENAI_API_KEY"):
            return AzureOpenAIProvider(model=model)
        return OllamaProvider(model=model)
    valid = '"auto" | "anthropic" | "openai" | "azure" | "ollama"'
    raise ValueError(
        
            f"Unknown DEFEND_PROVIDER / provider: {d!r} "
            f"(valid: {valid}; docs: docs/getting-started/installation#provider-credentials-and-env-vars)"
        
    )
