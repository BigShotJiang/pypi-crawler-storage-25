from __future__ import annotations

from typing import Any

from .base import BaseModule, pop_module_runtime_kwargs
from .fragments import build_system_prompt


class CodeExecutionOutput(BaseModule):
    name = "code_execution_output"
    description = "Detect dangerous code in LLM responses before execution."
    direction = "output"

    def __init__(self, **kwargs: Any) -> None:
        on_fail, timeout, cfg = pop_module_runtime_kwargs(kwargs)
        super().__init__(on_fail=on_fail, timeout=timeout)
        self._cfg = cfg

    def system_prompt(self) -> str:
        return build_system_prompt(self.name, self._cfg)
