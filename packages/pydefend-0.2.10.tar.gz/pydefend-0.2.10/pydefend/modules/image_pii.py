from __future__ import annotations

from typing import Any

from .base import BaseModule, pop_module_runtime_kwargs
from .fragments import build_system_prompt


class ImagePii(BaseModule):
    name = "image_pii"
    description = "Detect PII in images (faces, documents, ID cards) when multimodal context is available."
    direction = "input"

    def __init__(self, **kwargs: Any) -> None:
        on_fail, timeout, cfg = pop_module_runtime_kwargs(kwargs)
        super().__init__(on_fail=on_fail, timeout=timeout)
        self._cfg = cfg

    def system_prompt(self) -> str:
        body = build_system_prompt(self.name, self._cfg)
        if not body:
            cats = self._cfg.get("categories") or ["face", "document", "id_card"]
            return (
                "When images are provided, detect sensitive visual PII such as: "
                f"{', '.join(str(c) for c in cats)}. Set triggered=true when present.\n"
            )
        return body
