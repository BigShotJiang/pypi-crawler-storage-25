from __future__ import annotations

from typing import Any

from .base import BaseModule, pop_module_runtime_kwargs
from .fragments import build_system_prompt


class ToolMisuse(BaseModule):
    name = "tool_misuse"
    description = "Detect tool misuse or policy violations in LLM responses."
    direction = "output"

    def __init__(self, **kwargs: Any) -> None:
        on_fail, timeout, cfg = pop_module_runtime_kwargs(kwargs)
        super().__init__(on_fail=on_fail, timeout=timeout)
        self._cfg = cfg

    def system_prompt(self) -> str:
        return build_system_prompt(self.name, self._cfg)
