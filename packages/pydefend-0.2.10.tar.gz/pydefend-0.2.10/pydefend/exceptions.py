from __future__ import annotations

from typing import Any

from .types import Violation


class DefendError(Exception):
    """Base exception for defend."""


class ConfigError(DefendError):
    """Malformed defend.yaml or invalid programmatic config."""


class ProviderError(DefendError):
    def __init__(self, provider: str, underlying: Exception | None = None, message: str | None = None) -> None:
        self.provider = provider
        self.underlying_exception = underlying
        msg = message or (str(underlying) if underlying else "provider error")
        super().__init__(f"{provider}: {msg}")


class InputBlockedError(DefendError):
    def __init__(self, violations: list[Violation], original_text: str) -> None:
        self.violations = violations
        self.original_text = original_text
        super().__init__("input blocked")

    def to_dict(self) -> dict[str, Any]:
        return {
            "violations": [v.to_dict() for v in self.violations],
            "original_text": self.original_text,
        }


class OutputBlockedError(DefendError):
    def __init__(self, violations: list[Violation], original_text: str) -> None:
        self.violations = violations
        self.original_text = original_text
        super().__init__("output blocked")

    def to_dict(self) -> dict[str, Any]:
        return {
            "violations": [v.to_dict() for v in self.violations],
            "original_text": self.original_text,
        }


class ModuleTimeoutError(DefendError):
    def __init__(self, module_name: str, timeout_ms: float) -> None:
        self.module_name = module_name
        self.timeout_ms = timeout_ms
        super().__init__(f"module {module_name} timed out after {timeout_ms}ms")


class ExcessiveAgencyError(DefendError):
    def __init__(self, attempted_tool: str, scope: str, reason: str) -> None:
        self.attempted_tool = attempted_tool
        self.scope = scope
        self.reason = reason
        super().__init__(reason)
