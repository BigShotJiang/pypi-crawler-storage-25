from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from ..core import Defend


class DefendMiddleware(BaseHTTPMiddleware):
    """Scan a JSON body field on incoming requests (input guard)."""

    def __init__(
        self,
        app: Any,
        defend: Defend,
        *,
        input_field: str = "message",
        output_field: str = "response",
        block_status_code: int = 400,
    ) -> None:
        super().__init__(app)
        self._defend = defend
        self._input_field = input_field
        self._output_field = output_field
        self._code = block_status_code

    async def dispatch(self, request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
        if request.method not in ("POST", "PUT", "PATCH"):
            return await call_next(request)
        ct = request.headers.get("content-type", "")
        if "application/json" not in ct:
            return await call_next(request)
        body = await request.body()
        if not body:
            return await call_next(request)
        try:
            data = json.loads(body.decode("utf-8"))
        except json.JSONDecodeError:
            return await call_next(request)
        if not isinstance(data, dict) or self._input_field not in data:
            return await call_next(request)
        raw = data[self._input_field]
        if not isinstance(raw, str):
            return await call_next(request)
        result = await self._defend.scan(raw)
        if not result:
            return JSONResponse(
                {"error": "blocked", "action": result.action.value, "explain": result.explain()},
                status_code=self._code,
            )
        if result.text is not None and result.text != raw:
            data[self._input_field] = result.text
        new_body = json.dumps(data).encode("utf-8")

        async def receive() -> dict[str, Any]:
            return {"type": "http.request", "body": new_body, "more_body": False}

        new_request = Request(request.scope, receive)
        return await call_next(new_request)
