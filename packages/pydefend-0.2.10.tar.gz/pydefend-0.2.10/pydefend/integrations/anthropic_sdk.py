from __future__ import annotations

from typing import Any

from ..core import Defend


class GuardedAnthropic:
    """Scan user messages before ``messages.create``, check assistant text after (async client)."""

    def __init__(self, defend: Defend, client: Any | None = None) -> None:
        try:
            from anthropic import AsyncAnthropic
        except Exception as exc:  # pragma: no cover
            raise RuntimeError('anthropic is not installed; install "pydefend[anthropic]"') from exc

        self._defend = defend
        self._client = client or AsyncAnthropic()
        self.messages = _MessagesNamespace(self)

    @property
    def inner(self) -> Any:
        return self._client


class _MessagesNamespace:
    def __init__(self, g: GuardedAnthropic) -> None:
        self._g = g

    async def create(self, *args: Any, **kwargs: Any) -> Any:
        messages = kwargs.get("messages")
        if isinstance(messages, list):
            for m in reversed(messages):
                if isinstance(m, dict) and m.get("role") == "user":
                    blocks = m.get("content")
                    if isinstance(blocks, str):
                        res = await self._g._defend.scan(blocks)
                        if not res:
                            raise RuntimeError(f"defend blocked input: {res.action.value}")
                        if res.text is not None:
                            m["content"] = res.text
                    break
        resp = await self._g._client.messages.create(*args, **kwargs)
        try:
            parts: list[str] = []
            for b in getattr(resp, "content", []) or []:
                if getattr(b, "type", None) == "text":
                    parts.append(getattr(b, "text", "") or "")
            joined = "".join(parts)
            if joined:
                await self._g._defend.check(joined)
        except Exception:
            pass
        return resp
