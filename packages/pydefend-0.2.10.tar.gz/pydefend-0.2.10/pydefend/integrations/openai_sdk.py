from __future__ import annotations

from typing import Any

from ..core import Defend


class GuardedOpenAI:
    """
    Thin wrapper: scans the last user message before ``chat.completions.create``,
    and checks assistant text after (AsyncOpenAI only).
    """

    def __init__(self, defend: Defend, client: Any | None = None) -> None:
        try:
            from openai import AsyncOpenAI
        except Exception as exc:  # pragma: no cover
            raise RuntimeError('openai is not installed; install "pydefend[openai]"') from exc

        self._defend = defend
        self._client = client or AsyncOpenAI()
        self.chat = _ChatNamespace(self)

    @property
    def inner(self) -> Any:
        return self._client


class _ChatNamespace:
    def __init__(self, g: GuardedOpenAI) -> None:
        self._g = g
        self.completions = _CompletionsNamespace(g)


class _CompletionsNamespace:
    def __init__(self, g: GuardedOpenAI) -> None:
        self._g = g

    async def create(self, *args: Any, **kwargs: Any) -> Any:
        messages = kwargs.get("messages")
        if isinstance(messages, list):
            for m in reversed(messages):
                if isinstance(m, dict) and m.get("role") == "user":
                    c = m.get("content")
                    if isinstance(c, str):
                        res = await self._g._defend.scan(c)
                        if not res:
                            raise RuntimeError(f"defend blocked input: {res.action.value}")
                        if res.text is not None:
                            m["content"] = res.text
                    break
        resp = await self._g._client.chat.completions.create(*args, **kwargs)
        try:
            msg = resp.choices[0].message
            content = getattr(msg, "content", None)
            if isinstance(content, str) and content:
                out = await self._g._defend.check(content)
                if out.text is not None:
                    msg.content = out.text
        except Exception:
            pass
        return resp
