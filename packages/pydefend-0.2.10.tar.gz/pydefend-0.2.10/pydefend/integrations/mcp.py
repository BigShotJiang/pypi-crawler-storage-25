from __future__ import annotations

from typing import Any

from ..core import Defend


class DefendedMCPClient:
    """Stub MCP client wrapper; implement transport-specific tool calls in your stack."""

    def __init__(
        self,
        mcp_url: str,
        defend: Defend,
        *,
        allowed_tools: list[str] | None = None,
    ) -> None:
        self._url = mcp_url
        self._defend = defend
        self._allowed = set(allowed_tools or [])

    async def call_tool(self, name: str, args: dict[str, Any]) -> Any:
        if self._allowed and name not in self._allowed:
            raise PermissionError(name)
        r = await self._defend.scan_tool_call(tool_name=name, tool_args=args)
        if not r:
            raise RuntimeError(f"tool call blocked: {r.action.value}")
        return {"ok": True, "defend": r.to_dict()}
