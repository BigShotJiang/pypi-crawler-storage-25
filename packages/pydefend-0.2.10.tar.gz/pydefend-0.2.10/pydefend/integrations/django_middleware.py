from __future__ import annotations

# Django middleware requires WSGI/ASGI wiring in the host project.
# See docs for copying a small adapter that calls Defend.scan on request.POST fields.
