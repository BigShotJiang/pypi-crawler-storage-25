from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from ..core import Defend


def _text_from_content(content: Any) -> str | None:
    if content is None:
        return None
    if isinstance(content, str):
        return content or None
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(str(block.get("text", "") or ""))
                continue
            txt = getattr(block, "text", None)
            if isinstance(txt, str):
                parts.append(txt)
        joined = "".join(parts)
        return joined or None
    return None


def _last_user_index_and_text(messages: list[Any], HumanMessage: type[Any]) -> tuple[int, str] | None:
    for i in range(len(messages) - 1, -1, -1):
        m = messages[i]
        if isinstance(m, HumanMessage):
            t = _text_from_content(getattr(m, "content", None))
            if t is not None:
                return i, t
    return None


def _last_ai_text_index(messages: list[Any], AIMessage: type[Any]) -> tuple[int, str] | None:
    for i in range(len(messages) - 1, -1, -1):
        m = messages[i]
        if isinstance(m, AIMessage):
            if getattr(m, "tool_calls", None):
                return None
            t = _text_from_content(getattr(m, "content", None))
            if t is None:
                return None
            return i, t
    return None


try:
    from langchain.agents.middleware import AgentMiddleware, ModelRequest, ModelResponse
    from langchain_core.messages import AIMessage, HumanMessage
except ImportError:
    AgentMiddleware = None  # type: ignore[misc, assignment]


if AgentMiddleware is not None:

    class DefendAgentMiddleware(AgentMiddleware):  # type: ignore[misc, valid-type]
        """
        LangChain 1.x agent middleware: scans the latest user turn before each model call
        and checks the latest assistant text after each call. Install ``pydefend[langchain]``.
        """

        def __init__(
            self,
            defend: Defend,
            *,
            block_message: str = "This request could not be processed due to policy.",
        ) -> None:
            super().__init__()
            self._defend = defend
            self._block_message = block_message

        def _guard_request_sync(self, request: ModelRequest[Any]) -> ModelRequest[Any] | ModelResponse[Any]:
            msgs = list(request.messages)
            hit = _last_user_index_and_text(msgs, HumanMessage)
            if hit is None:
                return request
            idx, text = hit
            res = self._defend.scan_sync(text)
            if not res:
                return ModelResponse(result=[AIMessage(content=self._block_message)])
            new_text = res.text if res.text is not None else text
            if new_text != text:
                msgs[idx] = HumanMessage(content=new_text)
                return request.override(messages=msgs)
            return request

        async def _guard_request_async(self, request: ModelRequest[Any]) -> ModelRequest[Any] | ModelResponse[Any]:
            msgs = list(request.messages)
            hit = _last_user_index_and_text(msgs, HumanMessage)
            if hit is None:
                return request
            idx, text = hit
            res = await self._defend.scan(text)
            if not res:
                return ModelResponse(result=[AIMessage(content=self._block_message)])
            new_text = res.text if res.text is not None else text
            if new_text != text:
                msgs[idx] = HumanMessage(content=new_text)
                return request.override(messages=msgs)
            return request

        def _guard_response_sync(self, response: ModelResponse[Any]) -> ModelResponse[Any]:
            results = list(response.result)
            hit = _last_ai_text_index(results, AIMessage)
            if hit is None:
                return response
            idx, text = hit
            out = self._defend.check_sync(text)
            if not out:
                results[idx] = AIMessage(content=self._block_message)
                return ModelResponse(
                    result=results, structured_response=getattr(response, "structured_response", None)
                )
            new_text = out.text if out.text is not None else text
            if new_text != text:
                results[idx] = AIMessage(content=new_text)
                return ModelResponse(
                    result=results, structured_response=getattr(response, "structured_response", None)
                )
            return response

        async def _guard_response_async(self, response: ModelResponse[Any]) -> ModelResponse[Any]:
            results = list(response.result)
            hit = _last_ai_text_index(results, AIMessage)
            if hit is None:
                return response
            idx, text = hit
            out = await self._defend.check(text)
            if not out:
                results[idx] = AIMessage(content=self._block_message)
                return ModelResponse(
                    result=results, structured_response=getattr(response, "structured_response", None)
                )
            new_text = out.text if out.text is not None else text
            if new_text != text:
                results[idx] = AIMessage(content=new_text)
                return ModelResponse(
                    result=results, structured_response=getattr(response, "structured_response", None)
                )
            return response

        def wrap_model_call(
            self,
            request: ModelRequest[Any],
            handler: Callable[[ModelRequest[Any]], ModelResponse[Any]],
        ) -> ModelResponse[Any]:
            guarded = self._guard_request_sync(request)
            if isinstance(guarded, ModelResponse):
                return guarded
            return self._guard_response_sync(handler(guarded))

        async def awrap_model_call(
            self,
            request: ModelRequest[Any],
            handler: Callable[[ModelRequest[Any]], Awaitable[ModelResponse[Any]]],
        ) -> ModelResponse[Any]:
            guarded = await self._guard_request_async(request)
            if isinstance(guarded, ModelResponse):
                return guarded
            response = await handler(guarded)
            return await self._guard_response_async(response)

else:

    class DefendAgentMiddleware:  # type: ignore[no-redef]
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            raise RuntimeError(
                'LangChain is not installed; install with pip install "pydefend[langchain]"'
            )


__all__ = ["DefendAgentMiddleware"]
