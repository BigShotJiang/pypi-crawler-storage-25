from __future__ import annotations

from collections.abc import Callable
from enum import Enum

from .context import GuardContext
from .types import Action, Violation


class OnFail(str, Enum):
    BLOCK = "block"
    REDACT = "redact"
    WARN = "warn"
    FLAG = "flag"
    PASSTHROUGH = "passthrough"


OnFailCallable = Callable[[Violation, GuardContext], OnFail]


def on_fail_to_action(on_fail: OnFail) -> Action:
    return {
        OnFail.BLOCK: Action.BLOCKED,
        OnFail.REDACT: Action.REDACTED,
        OnFail.WARN: Action.WARNED,
        OnFail.FLAG: Action.FLAGGED,
        OnFail.PASSTHROUGH: Action.PASSED,
    }[on_fail]


def resolve_on_fail(
    module_on_fail: OnFail | OnFailCallable | None,
    global_on_fail: OnFail | None,
) -> OnFail:
    if module_on_fail is not None and not callable(module_on_fail):
        return module_on_fail
    if global_on_fail is not None:
        return global_on_fail
    return OnFail.BLOCK


def resolve_on_fail_dynamic(
    module_on_fail: OnFail | OnFailCallable | None,
    global_on_fail: OnFail | None,
    violation: Violation,
    ctx: GuardContext,
) -> OnFail:
    if callable(module_on_fail):
        return module_on_fail(violation, ctx)
    if module_on_fail is not None:
        return module_on_fail
    if global_on_fail is not None:
        return global_on_fail
    return OnFail.BLOCK
