from __future__ import annotations

import json
import logging
from typing import Any

from .base import BaseObserver


class StructuredLogger(BaseObserver):
    def __init__(self, level: str = "INFO") -> None:
        self._log = logging.getLogger("pydefend.audit")
        self._log.setLevel(getattr(logging, level.upper(), logging.INFO))

    async def on_event(self, name: str, payload: dict[str, Any]) -> None:
        safe = {k: v for k, v in payload.items() if k != "text"}
        self._log.info("%s %s", name, json.dumps(safe, default=str)[:8000])
