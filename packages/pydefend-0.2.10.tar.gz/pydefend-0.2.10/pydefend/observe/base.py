from __future__ import annotations

from typing import Any


class BaseObserver:
    async def on_event(self, name: str, payload: dict[str, Any]) -> None:
        raise NotImplementedError
