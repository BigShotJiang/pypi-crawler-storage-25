from __future__ import annotations

import json
from typing import Any

import httpx

from .base import BaseObserver


class WebhookObserver(BaseObserver):
    def __init__(self, url: str) -> None:
        self._url = url

    async def on_event(self, name: str, payload: dict[str, Any]) -> None:
        body = json.dumps({"event": name, "payload": payload}, default=str).encode("utf-8")
        async with httpx.AsyncClient(timeout=10.0) as client:
            await client.post(self._url, content=body, headers={"Content-Type": "application/json"})


class PrometheusExporter:
    """Placeholder for a metrics server; wire in your stack if needed."""

    def __init__(self, port: int = 9090) -> None:
        self.port = port


class DatadogTracer:
    """Placeholder for Datadog integration."""

    def __init__(self) -> None:
        pass
