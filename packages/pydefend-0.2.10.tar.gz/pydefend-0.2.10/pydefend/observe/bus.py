from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import Any

_LOG = logging.getLogger("pydefend.events")

Handler = Callable[[dict[str, Any]], Awaitable[None] | None]


class EventBus:
    def __init__(self) -> None:
        self._subs: dict[str, list[Handler]] = {}
        self._observers: list[Any] = []

    def subscribe(self, name: str, fn: Handler) -> None:
        self._subs.setdefault(name, []).append(fn)

    def add_observer(self, observer: Any) -> None:
        self._observers.append(observer)

    async def emit(self, name: str, payload: dict[str, Any]) -> None:
        for fn in self._subs.get(name, []):
            try:
                r = fn(payload)
                if hasattr(r, "__await__"):
                    await r
            except Exception as exc:  # pragma: no cover - observer isolation
                _LOG.warning("handler %s failed: %s", name, exc)
        for obs in self._observers:
            if hasattr(obs, "on_event"):
                try:
                    r = obs.on_event(name, payload)
                    if hasattr(r, "__await__"):
                        await r
                except Exception as exc:  # pragma: no cover
                    _LOG.warning("observer failed: %s", exc)
