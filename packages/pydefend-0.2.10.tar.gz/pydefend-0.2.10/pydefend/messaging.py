from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProviderFailureMessage:
    message: str


def format_provider_failure_one_line(provider_name: str, exc: Exception) -> ProviderFailureMessage:
    """
    One-line, CLI-friendly provider/setup failure message.

    Keep this intentionally terse; it may be emitted even in passthrough mode.
    """
    p = (provider_name or "provider").strip().lower()
    raw = str(exc).strip() or exc.__class__.__name__
    low = raw.lower()

    fix = None

    # Missing optional extras
    if 'install "pydefend[openai]"' in raw or "pydefend[openai]" in low:
        # Underlying already contains install hint; keep fix to the next step.
        fix = "install the OpenAI extra, then set OPENAI_API_KEY (or set DEFEND_PROVIDER=ollama)"
    elif 'install "pydefend[anthropic]"' in raw or "pydefend[anthropic]" in low:
        # Underlying already contains install hint; keep fix to the next step.
        fix = "install the Anthropic extra, then set ANTHROPIC_API_KEY (or set DEFEND_PROVIDER=ollama)"
    elif "openai_api_key is not set" in low:
        fix = "set OPENAI_API_KEY (or set DEFEND_PROVIDER=ollama)"
    elif "anthropic_api_key is not set" in low:
        fix = "set ANTHROPIC_API_KEY (or set DEFEND_PROVIDER=ollama)"

    # Azure common env-var misconfig
    elif "azure openai requires" in low:
        fix = "set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY (or change DEFEND_PROVIDER)"

    # Ollama connectivity
    elif p == "ollama" or "ollama error" in low:
        fix = (
            "start Ollama (default http://127.0.0.1:11434), "
            "or set ANTHROPIC_API_KEY / OPENAI_API_KEY, "
            "or DEFEND_PROVIDER"
        )

    # Generic hosted provider failures
    elif p in ("openai", "claude", "anthropic", "azure"):
        if ("not_found_error" in low and "model" in low) or "model:" in low:
            fix = "model not found; set a valid model for your account or set DEFEND_PROVIDER=ollama"
        else:
            fix = "check provider credentials/env vars, network access, and model; or set DEFEND_PROVIDER=ollama"

    # Fallback
    if not fix:
        fix = "check provider configuration; see docs"

    # Keep it short: error + fix only.
    msg = "\n".join([f"pydefend provider error: {provider_name}: {raw}", f"fix: {fix}"])
    return ProviderFailureMessage(message=msg)

