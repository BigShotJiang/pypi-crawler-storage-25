from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class GuardContext:
    """Passed to every module run and dynamic on_fail callables."""

    metadata: dict[str, Any] = field(default_factory=dict)
    session_id: str | None = None
    messages: list[dict[str, Any]] | None = None
    latest_message: str | None = None
