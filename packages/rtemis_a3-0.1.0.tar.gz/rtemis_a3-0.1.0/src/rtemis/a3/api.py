"""Functional API for A3 construction, parsing, and querying.

Users interact with A3 objects exclusively through these functions.
Pydantic models are never constructed directly.
"""

from __future__ import annotations

import json
from typing import Any, cast

from pydantic import ValidationError

from ._models import A3, VariantRecord, _BoundsErrors
from .errors import A3ParseError, A3ValidationError

_A3_SCHEMA_URI = "https://schema.rtemis.org/a3/v1/schema.json"
_A3_VERSION = "1.0.0"
_ENVELOPE_KEYS = frozenset({"$schema", "a3_version"})


def create_a3(
    sequence: str,
    *,
    site: dict[str, dict[str, Any]] | None = None,
    region: dict[str, dict[str, Any]] | None = None,
    ptm: dict[str, dict[str, Any]] | None = None,
    processing: dict[str, dict[str, Any]] | None = None,
    variant: list[dict[str, Any]] | None = None,
    metadata: dict[str, str] | None = None,
) -> A3:
    """Create an A3 object from raw components.

    Parameters
    ----------
    sequence : str
        Amino acid sequence (minimum 2 characters, ``[A-Za-z*]``).
    site : dict, optional
        Named site annotations. Each value: ``{"index": [...], "type": "..."}``.
    region : dict, optional
        Named region annotations. Each value:
        ``{"index": [[s, e], ...], "type": "..."}``.
    ptm : dict, optional
        Named PTM annotations. Index may be positions or ranges.
    processing : dict, optional
        Named processing annotations. Index may be positions or ranges.
    variant : list of dict, optional
        Variant records. Each must have ``"position"``; other fields are open.
    metadata : dict, optional
        Metadata fields: ``uniprot_id``, ``description``, ``reference``,
        ``organism``.

    Returns
    -------
    A3
        Validated, immutable A3 object.

    Raises
    ------
    A3ValidationError
        If input fails structural or contextual validation.
    """
    data: dict[str, Any] = {"sequence": sequence}
    annotations: dict[str, Any] = {}
    if site is not None:
        annotations["site"] = site
    if region is not None:
        annotations["region"] = region
    if ptm is not None:
        annotations["ptm"] = ptm
    if processing is not None:
        annotations["processing"] = processing
    if variant is not None:
        annotations["variant"] = variant
    if annotations:
        data["annotations"] = annotations
    if metadata is not None:
        data["metadata"] = metadata

    try:
        return A3.model_validate(data)
    except _BoundsErrors as exc:
        errors = [{"loc": (), "msg": msg, "type": "value_error"} for msg in exc.messages]
        raise A3ValidationError("\n".join(exc.messages), errors) from exc
    except ValidationError as exc:
        raise A3ValidationError(str(exc), cast(list[dict[str, Any]], exc.errors())) from exc


def a3_from_json(text: str) -> A3:
    """Parse a JSON string into an A3 object.

    Parameters
    ----------
    text : str
        JSON string conforming to the A3 wire format.

    Returns
    -------
    A3
        Validated, immutable A3 object.

    Raises
    ------
    A3ParseError
        If JSON parsing fails.
    A3ValidationError
        If parsed data fails validation.
    """
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError) as exc:
        raise A3ParseError(f"invalid JSON: {exc}") from exc

    if not isinstance(data, dict):
        raise A3ValidationError(
            "JSON root must be an object",
            [{"loc": (), "msg": "JSON root must be an object", "type": "value_error", "input": data}],
        )
    envelope_errors: list[dict[str, Any]] = []
    schema_val = data.get("$schema")
    if schema_val is None:
        envelope_errors.append({"loc": ("$schema",), "msg": "missing required field '$schema'", "type": "missing", "input": data})
    elif schema_val != _A3_SCHEMA_URI:
        envelope_errors.append({"loc": ("$schema",), "msg": f"'$schema' must be '{_A3_SCHEMA_URI}', got '{schema_val}'", "type": "value_error", "input": schema_val})
    version_val = data.get("a3_version")
    if version_val is None:
        envelope_errors.append({"loc": ("a3_version",), "msg": "missing required field 'a3_version'", "type": "missing", "input": data})
    elif version_val != _A3_VERSION:
        envelope_errors.append({"loc": ("a3_version",), "msg": f"'a3_version' must be '{_A3_VERSION}', got '{version_val}'", "type": "value_error", "input": version_val})
    if envelope_errors:
        raise A3ValidationError(
            "; ".join(e["msg"] for e in envelope_errors),
            envelope_errors,
        )
    # Strip envelope keys before passing to the data model
    for key in _ENVELOPE_KEYS:
        data.pop(key, None)

    try:
        return A3.model_validate(data)
    except _BoundsErrors as exc:
        errors = [{"loc": (), "msg": msg, "type": "value_error"} for msg in exc.messages]
        raise A3ValidationError("\n".join(exc.messages), errors) from exc
    except ValidationError as exc:
        raise A3ValidationError(str(exc), cast(list[dict[str, Any]], exc.errors())) from exc


def a3_to_json(a3: A3, *, indent: int | None = None) -> str:
    """Serialize an A3 object to a canonical JSON string.

    Parameters
    ----------
    a3 : A3
        A3 object to serialize.
    indent : int, optional
        JSON indentation level. ``None`` for compact output.

    Returns
    -------
    str
        JSON string.
    """
    data: dict[str, Any] = {
        "$schema": _A3_SCHEMA_URI,
        "a3_version": _A3_VERSION,
        **a3.model_dump(mode="json"),
    }
    return json.dumps(data, indent=indent, ensure_ascii=False)


def residue_at(a3: A3, position: int) -> str:
    """Return the residue at a 1-based position.

    Parameters
    ----------
    a3 : A3
        A3 object.
    position : int
        1-based position in the sequence.

    Returns
    -------
    str
        Single character at the given position.

    Raises
    ------
    ValueError
        If position is out of bounds.
    """
    if position < 1 or position > len(a3.sequence):
        raise ValueError(
            f"position {position} is out of bounds for sequence of length "
            f"{len(a3.sequence)} (must be 1-{len(a3.sequence)})"
        )
    return a3.sequence[position - 1]


def variants_at(a3: A3, position: int) -> list[VariantRecord]:
    """Return all variant records at the given 1-based position.

    Parameters
    ----------
    a3 : A3
        A3 object.
    position : int
        1-based position in the sequence.

    Returns
    -------
    list[VariantRecord]
        Variant records matching the position. May be empty.
    """
    return [v for v in a3.annotations.variant if v.position == position]
