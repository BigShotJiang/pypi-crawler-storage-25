import pytest

from dominus.namespaces.coder import CoderNamespace
from dominus.namespaces.platform import PlatformNamespace


class MockGatewayClient:
    def __init__(self):
        self.calls = []

    async def gateway_fetch(self, path, **kwargs):
        self.calls.append((path, kwargs))
        return {"ok": True}


@pytest.mark.asyncio
async def test_platform_namespace_normalizes_helpers_onto_service_routes():
    client = MockGatewayClient()
    platform = PlatformNamespace(client)

    await platform.health()
    await platform.list_groups()
    await platform.upsert_group({"slug": "dominus", "name": "Dominus"})
    await platform.add_group_member("dominus", "user-1")
    await platform.link_group_repository(
        "dominus",
        "carebridgesystems/dominus-platform-worker",
    )
    await platform.ensure_policy_decision(
        {
            "group": "dominus",
            "repository": "carebridgesystems/dominus-platform-worker",
            "metadata": {"safe": "ok"},
        },
        actor_context={"type": "user", "id": "user-1"},
    )
    await platform.rehydrate_policy_decision("pd_123", {"run_id": "run_123"})

    assert [(path, kwargs["method"]) for path, kwargs in client.calls] == [
        ("/svc/platform/health", "GET"),
        ("/svc/platform/groups", "GET"),
        ("/svc/platform/groups", "POST"),
        ("/svc/platform/groups/dominus/members", "POST"),
        ("/svc/platform/groups/dominus/repositories", "POST"),
        ("/svc/platform/policy/decisions/ensure", "POST"),
        ("/svc/platform/policy/decisions/pd_123/rehydrate", "POST"),
    ]
    assert client.calls[2][1]["body"] == {"slug": "dominus", "name": "Dominus"}
    assert client.calls[3][1]["body"] == {"subject_id": "user-1"}
    assert client.calls[5][1]["body"] == {
        "group": "dominus",
        "repository": "carebridgesystems/dominus-platform-worker",
        "metadata": {"safe": "ok"},
    }
    assert client.calls[5][1]["headers"] == {"X-Actor-Type": "user", "X-Actor-Id": "user-1"}


@pytest.mark.asyncio
async def test_platform_request_preserves_explicit_platform_paths():
    client = MockGatewayClient()
    platform = PlatformNamespace(client)

    await platform.request("/api/platform/groups", method="GET")
    await platform.request("/svc/platform/policy/decisions/pd_123", method="GET")

    assert [path for path, _ in client.calls] == [
        "/svc/platform/groups",
        "/svc/platform/policy/decisions/pd_123",
    ]


@pytest.mark.asyncio
async def test_coder_namespace_exposes_lifecycle_helpers_but_no_raw_shell():
    client = MockGatewayClient()
    coder = CoderNamespace(client)

    await coder.ensure_run(
        policy_decision_id="pd_123",
        mode="async",
        task_recipe_ref="recipe://coder-task-recipe-v1/fix-tests@head",
        workflow_recipe_ref="recipe://workflow-recipe-v1/coder-feature@head",
        repository="carebridgesystems/dominus-platform-worker",
        instructions="Fix failing tests",
        actor_context={"type": "user", "id": "user-1"},
    )
    await coder.list_runs(status="running", limit=10)
    await coder.cancel_run("run_123", reason="operator requested")
    await coder.retry_run("run_123", idempotency_key="retry-1")
    await coder.nudge_run("run_123", metadata={"hint": "continue"})
    await coder.get_run_summary("run_123")
    await coder.get_run_artifacts("run_123")

    assert [(path, kwargs["method"]) for path, kwargs in client.calls] == [
        ("/svc/coder/runs/ensure", "POST"),
        ("/svc/coder/runs?status=running&limit=10", "GET"),
        ("/svc/coder/runs/run_123/cancel", "POST"),
        ("/svc/coder/runs/run_123/retry", "POST"),
        ("/svc/coder/runs/run_123/nudge", "POST"),
        ("/svc/coder/runs/run_123/summary", "GET"),
        ("/svc/coder/runs/run_123/artifacts", "GET"),
    ]
    assert client.calls[0][1]["body"] == {
        "policy_decision_id": "pd_123",
        "mode": "async",
        "task_recipe_ref": "recipe://coder-task-recipe-v1/fix-tests@head",
        "workflow_recipe_ref": "recipe://workflow-recipe-v1/coder-feature@head",
        "repository": "carebridgesystems/dominus-platform-worker",
        "instructions": "Fix failing tests",
    }
    assert client.calls[0][1]["headers"] == {"X-Actor-Type": "user", "X-Actor-Id": "user-1"}
    assert not hasattr(coder, "shell")
    assert not hasattr(coder, "exec")
    assert not hasattr(coder, "command")


@pytest.mark.asyncio
async def test_coder_ensure_run_requires_policy_decision_id():
    client = MockGatewayClient()
    coder = CoderNamespace(client)

    with pytest.raises(ValueError, match="policy_decision_id"):
        await coder.ensure_run(policy_decision_id="")

    assert client.calls == []


@pytest.mark.asyncio
async def test_coder_ensure_run_requires_exactly_one_authority_launch_source():
    client = MockGatewayClient()
    coder = CoderNamespace(client)

    with pytest.raises(ValueError, match="exactly one"):
        await coder.ensure_run(policy_decision_id="pd_123")

    with pytest.raises(ValueError, match="exactly one"):
        await coder.ensure_run(
            policy_decision_id="pd_123",
            workflow_recipe_ref="recipe://workflow-recipe-v1/coder@head",
            pipeline_recipe_ref="recipe://pipeline-recipe-v1/coder@head",
        )

    assert client.calls == []
