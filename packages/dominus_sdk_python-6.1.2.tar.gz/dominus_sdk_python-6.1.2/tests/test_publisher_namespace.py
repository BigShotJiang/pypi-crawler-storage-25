import pytest

from dominus.namespaces.publisher import PublisherNamespace


class MockGatewayClient:
    def __init__(self):
        self.calls = []

    async def gateway_fetch(self, path, **kwargs):
        self.calls.append((path, kwargs))
        return {"ok": True}


@pytest.mark.asyncio
async def test_publisher_namespace_normalizes_lifecycle_and_resolver_helpers():
    client = MockGatewayClient()
    publisher = PublisherNamespace(client)

    await publisher.health()
    await publisher.ready()
    await publisher.list_builds()
    await publisher.ensure_build(
        {"artifact_key": "envoy_binary"},
        actor_context={"type": "service", "id": "dominus-deployer"},
    )
    await publisher.get_build("pub_123")
    await publisher.retry_build("pub_123", reason="rerun", idempotency_key="retry-1")
    await publisher.cancel_build("pub_123", metadata={"requested_by": "operator"})
    await publisher.evaluate_signing({"environment": "production"})
    await publisher.record_signing_evidence({"artifact_key": "envoy_binary"})
    await publisher.list_artifacts()
    await publisher.record_release({"artifact_key": "envoy_binary"})
    await publisher.resolve_artifact(
        "envoy_binary",
        selector="stable",
        environment="production",
        target_app="powerscribe",
        architecture="x64",
        runtime_family="rust-tauri",
    )
    await publisher.list_channels()
    await publisher.get_channel("envoy_binary", "stable", environment="production")
    await publisher.pin_channel("envoy_binary", "stable", {"release_ref": "ar://..."})
    await publisher.list_prestage()

    assert [(path, kwargs["method"]) for path, kwargs in client.calls] == [
        ("/svc/publisher/health", "GET"),
        ("/svc/publisher/ready", "GET"),
        ("/svc/publisher/builds", "GET"),
        ("/svc/publisher/builds/ensure", "POST"),
        ("/svc/publisher/builds/pub_123", "GET"),
        ("/svc/publisher/builds/pub_123/retry", "POST"),
        ("/svc/publisher/builds/pub_123/cancel", "POST"),
        ("/svc/publisher/builds/signing/evaluate", "POST"),
        ("/svc/publisher/builds/signing/evidence", "POST"),
        ("/svc/publisher/artifacts", "GET"),
        ("/svc/publisher/artifacts/releases/record", "POST"),
        ("/svc/publisher/artifacts/envoy_binary?selector=stable&environment=production&target_app=powerscribe&architecture=x64&runtime_family=rust-tauri", "GET"),
        ("/svc/publisher/channels", "GET"),
        ("/svc/publisher/channels/envoy_binary/stable?environment=production", "GET"),
        ("/svc/publisher/channels/envoy_binary/stable/pin", "POST"),
        ("/svc/publisher/prestage", "GET"),
    ]
    assert client.calls[3][1]["headers"] == {"X-Actor-Type": "service", "X-Actor-Id": "dominus-deployer"}
    assert client.calls[5][1]["body"] == {"reason": "rerun", "idempotency_key": "retry-1"}
    assert not hasattr(publisher, "shell")
    assert not hasattr(publisher, "command")


@pytest.mark.asyncio
async def test_publisher_request_rewrites_api_paths_to_svc_paths():
    client = MockGatewayClient()
    publisher = PublisherNamespace(client)

    await publisher.request("/api/publisher/builds", method="GET")
    await publisher.request("/svc/publisher/channels", method="GET")

    assert [path for path, _ in client.calls] == [
        "/svc/publisher/builds",
        "/svc/publisher/channels",
    ]
