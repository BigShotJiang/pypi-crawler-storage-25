import pytest

import dominus.start as start_module


@pytest.fixture()
def sdk(monkeypatch):
    monkeypatch.setattr(start_module, "_VALIDATION_ERROR", None)
    monkeypatch.setattr(start_module, "_TOKEN", "a" * 64)
    monkeypatch.setattr(start_module, "_VALIDATED", False)
    monkeypatch.setattr(start_module, "_BASE_URL", "https://gateway.example")
    monkeypatch.setattr(start_module, "_GATEWAY_URL", "https://gateway.example")
    return start_module.Dominus()


@pytest.mark.asyncio
async def test_browser_namespace_uses_gateway_routed_api_browser_paths(monkeypatch, sdk):
    calls = []

    async def fake_request(**kwargs):
        calls.append(kwargs)
        return {
            "ok": True,
            "run_id": "br_123",
            "status": "queued",
            "provider": "cloudflare_browser_run",
            "mode": "playwright",
        }

    monkeypatch.setattr(sdk, "_request", fake_request)

    await sdk.browser.get_health()
    await sdk.browser.ensure_run(
        idempotency_key="idem-1",
        run_kind="browser.route_check",
        route_label="summit-dashboard",
        route_policy_ref="rrc.v1:project",
        target={"url": "https://summit.example/dashboard?token=redacted"},
        provider="auto",
        mode="playwright",
        auth_ref={
            "kind": "dominus_secret",
            "secret_ref": "warden://browser/summit/session",
            "expected_project_id": "project-123",
            "expected_scopes": ["browser.run"],
            "expected_view": "dashboard",
            "session_probe": "#app",
        },
        capture_policy={
            "screenshots": "on_failure",
            "dom_snapshot": "always",
            "raw_response_bodies": "always",
            "phi_risk": "likely",
            "retention_seconds": 900,
        },
        assertions=[
            {"kind": "status_code", "expected": 200},
            {"kind": "selector_visible", "selector": "#app", "timeout_ms": 5000},
        ],
        authority={"run_id": "auth-run-1", "artifact_observations": True},
        metadata={"route": "dashboard"},
        recipe={"version": "browser-recipe-v1", "steps": [{"kind": "goto", "url": "https://summit.example/dashboard"}]},
        recipe_inputs={"tenant": "summit"},
    )
    await sdk.browser.start_run("br_123")
    await sdk.browser.get_run_status("br_123")
    await sdk.browser.get_run_result("br_123")
    await sdk.browser.retry_run("br_123")
    await sdk.browser.nudge_run("br_123")
    await sdk.browser.cancel_run("br_123")
    await sdk.browser.get_run_timeline("br_123")
    await sdk.browser.get_run_dossier("br_123")

    assert [(call["method"], call["endpoint"], call["use_gateway"]) for call in calls] == [
        ("GET", "/api/browser/health", True),
        ("POST", "/api/browser/runs/ensure", True),
        ("POST", "/api/browser/runs/br_123/start", True),
        ("GET", "/api/browser/runs/br_123/status", True),
        ("GET", "/api/browser/runs/br_123/result", True),
        ("POST", "/api/browser/runs/br_123/retry", True),
        ("POST", "/api/browser/runs/br_123/nudge", True),
        ("POST", "/api/browser/runs/br_123/cancel", True),
        ("GET", "/api/browser/runs/br_123/timeline", True),
        ("GET", "/api/browser/runs/br_123/dossier", True),
    ]

    ensure_body = calls[1]["body"]
    assert ensure_body["idempotency_key"] == "idem-1"
    assert ensure_body["run_kind"] == "browser.route_check"
    assert ensure_body["route_label"] == "summit-dashboard"
    assert ensure_body["route_policy_ref"] == "rrc.v1:project"
    assert ensure_body["auth_ref"]["secret_ref"] == "warden://browser/summit/session"
    assert ensure_body["capture_policy"]["dom_snapshot"] == "always"
    assert ensure_body["capture_policy"]["raw_response_bodies"] == "always"
    assert ensure_body["assertions"][1] == {
        "kind": "selector_visible",
        "selector": "#app",
        "timeout_ms": 5000,
    }
    assert ensure_body["authority"] == {
        "run_id": "auth-run-1",
        "artifact_observations": True,
    }
    assert ensure_body["recipe"]["version"] == "browser-recipe-v1"
    assert ensure_body["recipe_inputs"] == {"tenant": "summit"}


@pytest.mark.asyncio
async def test_browser_ensure_run_requires_target_or_recipe(sdk):
    with pytest.raises(ValueError, match="target, recipe_ref, or recipe is required"):
        await sdk.browser.ensure_run(target={})
