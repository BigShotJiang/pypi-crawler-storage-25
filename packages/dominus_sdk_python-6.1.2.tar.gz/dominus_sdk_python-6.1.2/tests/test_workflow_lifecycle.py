import pytest
import base64
import json

from dominus.namespaces.ai import WorkflowSubNamespace
from dominus.namespaces.workflow import WorkflowNamespace


class FakeClient:
    def __init__(self, stream_chunks=None):
        self.calls = []
        self.stream_calls = []
        self.stream_chunks = list(stream_chunks or [{"_event": "workflow_start"}])

    async def _request(
        self,
        endpoint,
        method="POST",
        body=None,
        user_token=None,
        use_gateway=False,
        timeout=30.0,
    ):
        self.calls.append(
            {
                "endpoint": endpoint,
                "method": method,
                "body": body,
                "user_token": user_token,
                "use_gateway": use_gateway,
                "timeout": timeout,
            }
        )
        return {"ok": True}

    async def _stream_request(
        self,
        endpoint,
        body=None,
        on_chunk=None,
        timeout=300.0,
        use_gateway=False,
    ):
        self.stream_calls.append(
            {
                "endpoint": endpoint,
                "body": body,
                "timeout": timeout,
                "use_gateway": use_gateway,
            }
        )
        for chunk in self.stream_chunks:
            if on_chunk:
                on_chunk(chunk)
            yield chunk


def authority_run_id(**overrides):
    payload = {
        "project_id": "proj-1",
        "environment": "production",
        "workflow_id": "wf-instance",
        "instance_id": "inst-1",
    }
    payload.update(overrides)
    encoded = base64.urlsafe_b64encode(json.dumps(payload).encode("utf-8")).decode("utf-8")
    return encoded.rstrip("=")


@pytest.mark.asyncio
async def test_ai_workflow_create_run_requires_inline_definition():
    namespace = WorkflowSubNamespace(FakeClient())

    with pytest.raises(ValueError, match="does not support saved workflow IDs"):
        await namespace.create_run(workflow_id="wf_saved_only")


@pytest.mark.asyncio
async def test_ai_workflow_execute_uses_truthful_raw_contract():
    client = FakeClient()
    namespace = WorkflowSubNamespace(client)

    await namespace.execute(
        workflow_definition={"workflow": {"name": "raw"}},
        initial_artifacts={"report_snapshot_current": "artifact-1"},
        conversation_id="conv-123",
        mode="async",
        timeout_seconds=45,
        save_events=True,
        environment="production",
        webhook_url="https://example.com/hook",
    )

    assert len(client.calls) == 1
    call = client.calls[0]
    assert call["endpoint"] == "/api/orchestration/execute"
    assert call["method"] == "POST"
    assert call["use_gateway"] is True
    assert call["body"] == {
        "workflow_definition": {"workflow": {"name": "raw"}},
        "initial_artifacts": {"report_snapshot_current": "artifact-1"},
        "conversation_id": "conv-123",
        "webhook_url": "https://example.com/hook",
        "config": {
            "mode": "async",
            "timeout_seconds": 45,
            "save_events": True,
            "environment": "production",
        },
    }


@pytest.mark.asyncio
async def test_ai_workflow_two_phase_lifecycle_routes_match_node_surface():
    client = FakeClient(stream_chunks=[{"_event": "node_start"}, {"_event": "workflow_complete"}])
    namespace = WorkflowSubNamespace(client)

    await namespace.create_run(
        workflow_definition={"workflow": {"name": "raw"}},
        run_id="run-123",
        metadata={"purpose": "processor-smoke"},
        environment="production",
    )
    await namespace.register_artifact(
        "run-123",
        "report_snapshot_current",
        "artifact-123",
        source_conversation_id="run-123",
        metadata={"report_ref": {"report_id": "r-1"}},
        metadata_trusted=True,
    )
    await namespace.validate_run("run-123")
    await namespace.start_run("run-123", mode="blocking", timeout_seconds=30, save_events=False)
    streamed = [chunk async for chunk in namespace.stream_start_run("run-123", timeout_seconds=60)]
    await namespace.messages("exec-123", count=25)
    await namespace.events("exec-123", from_id="evt-1", count=10)
    await namespace.status("exec-123")
    await namespace.output("exec-123")
    await namespace.cancel("exec-123")

    endpoints = [call["endpoint"] for call in client.calls]
    assert endpoints == [
        "/api/orchestration/runs",
        "/api/orchestration/runs/run-123/artifacts",
        "/api/orchestration/runs/run-123/validate",
        "/api/orchestration/runs/run-123/start",
        "/api/orchestration/messages/exec-123?count=25",
        "/api/orchestration/events/exec-123?from_id=evt-1&count=10",
        "/api/orchestration/status/exec-123",
        "/api/orchestration/output/exec-123",
        "/api/orchestration/cancel/exec-123",
    ]
    assert client.stream_calls == [
        {
            "endpoint": "/api/orchestration/runs/run-123/start",
            "body": {
                "config": {
                    "mode": "streaming",
                    "timeout_seconds": 60,
                }
            },
            "timeout": 60.0,
            "use_gateway": True,
        }
    ]
    assert streamed == [{"_event": "node_start"}, {"_event": "workflow_complete"}]


@pytest.mark.asyncio
async def test_saved_workflow_facade_legacy_chain_raises():
    client = FakeClient(stream_chunks=[{"_event": "workflow_start"}])
    namespace = WorkflowNamespace(client)

    with pytest.raises(RuntimeError, match="removed"):
        await namespace.create_run(
            "wf-123",
            run_id="report-run-1",
            context={"report_ref": {"report_id": "report-1"}},
        )
    with pytest.raises(RuntimeError, match="removed"):
        await namespace.register_artifact("report-run-1", "k", artifact_id="x")
    with pytest.raises(RuntimeError, match="removed"):
        await namespace.validate_run("report-run-1")
    with pytest.raises(RuntimeError, match="removed"):
        await namespace.start_run("report-run-1", timeout_seconds=120)
    with pytest.raises(RuntimeError, match="removed"):
        _ = [c async for c in namespace.stream_start_run("report-run-1", timeout_seconds=90)]

    assert client.calls == []


@pytest.mark.asyncio
async def test_saved_workflow_execution_poll_endpoints_unchanged():
    client = FakeClient(stream_chunks=[])
    namespace = WorkflowNamespace(client)

    await namespace.messages("exec-456", count=15)
    await namespace.events("exec-456", from_id="evt-2", count=20)
    await namespace.status("exec-456")
    await namespace.output("exec-456")
    await namespace.cancel("exec-456")

    assert client.calls[0]["endpoint"] == "/api/workflow/executions/exec-456/messages?count=15"
    assert client.calls[1]["endpoint"] == "/api/workflow/executions/exec-456/events?from_id=evt-2&count=20"
    assert client.calls[2]["endpoint"] == "/api/workflow/executions/exec-456/status"
    assert client.calls[3]["endpoint"] == "/api/workflow/executions/exec-456/output"
    assert client.calls[4]["endpoint"] == "/api/workflow/executions/exec-456/cancel"


@pytest.mark.asyncio
async def test_workflow_tool_registry_endpoints():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.list_tools(is_enabled=True, is_builtin=False, limit=10, offset=2)
    await namespace.get_tool("tool-uuid")
    await namespace.register_tool({"slug": "x", "name": "X", "tool_type": "http"})
    await namespace.update_tool("tool-uuid", {"name": "Y"})
    await namespace.delete_tool("tool-uuid")
    await namespace.enable_tool("tool-uuid")
    await namespace.disable_tool("tool-uuid")

    assert client.calls[0]["endpoint"] == "/api/workflow/tools?limit=10&offset=2&is_enabled=true&is_builtin=false"
    assert client.calls[0]["method"] == "GET"
    assert client.calls[1]["endpoint"] == "/api/workflow/tools/tool-uuid"
    assert client.calls[1]["method"] == "GET"
    assert client.calls[2]["endpoint"] == "/api/workflow/tools"
    assert client.calls[2]["body"] == {"slug": "x", "name": "X", "tool_type": "http"}
    assert client.calls[3]["endpoint"] == "/api/workflow/tools/tool-uuid"
    assert client.calls[3]["method"] == "PUT"
    assert client.calls[3]["body"] == {"name": "Y"}
    assert client.calls[4]["endpoint"] == "/api/workflow/tools/tool-uuid"
    assert client.calls[4]["method"] == "DELETE"
    assert client.calls[5]["endpoint"] == "/api/workflow/tools/tool-uuid/enable"
    assert client.calls[5]["body"] == {}
    assert client.calls[6]["endpoint"] == "/api/workflow/tools/tool-uuid/disable"
    assert client.calls[6]["body"] == {}
    assert all(c["use_gateway"] is True for c in client.calls)


@pytest.mark.asyncio
async def test_workflow_update_tool_rejects_empty_patch():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    with pytest.raises(ValueError, match="patch must not be empty"):
        await namespace.update_tool("tool-uuid", {})

    assert client.calls == []


@pytest.mark.asyncio
async def test_workflow_ensure_supports_authority_one_call_lifecycle():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.ensure(
        workflow_recipe_ref="recipe://workflow-recipe-v1/report-cycle@head",
        subject="PCM47474562",
        company="summit-radiology",
        inputs={"report_snapshot": "ar://artifact"},
        target_project_id="proj-1",
        target_environment="production",
    )

    assert client.calls[0]["endpoint"] == "/api/authority/runs/ensure"
    body = client.calls[0]["body"]
    assert body["workflow_recipe_ref"] == "recipe://workflow-recipe-v1/report-cycle@head"
    assert body["subject"] == "PCM47474562"
    assert body["company"] == "summit-radiology"
    assert body["inputs"] == {"report_snapshot": "ar://artifact"}
    assert body["target_org_id"] == "proj-1"
    assert body["target_env"] == "production"
    assert isinstance(body["idempotency_key"], str) and body["idempotency_key"]


@pytest.mark.asyncio
async def test_workflow_ensure_can_infer_recipe_ref_from_first_argument():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.ensure(
        "recipe://workflow-recipe-v1/report-cycle@v3",
        company="summit-radiology",
        mode="async",
    )

    body = client.calls[0]["body"]
    assert body["workflow_recipe_ref"] == "recipe://workflow-recipe-v1/report-cycle@v3"
    assert body["company"] == "summit-radiology"
    assert "workflow_id" not in body


@pytest.mark.asyncio
async def test_workflow_get_detects_authority_run_ids():
    client = FakeClient()
    namespace = WorkflowNamespace(client)
    run_id = authority_run_id()

    await namespace.get(run_id)

    assert client.calls[0]["endpoint"] == f"/api/authority/runs/{run_id}"
    assert client.calls[0]["method"] == "GET"


@pytest.mark.asyncio
async def test_workflow_retry_nudge_and_cancel_support_authority_run_ids():
    client = FakeClient()
    namespace = WorkflowNamespace(client)
    run_id = authority_run_id()

    await namespace.retry(run_id, reason="manual-retry")
    await namespace.nudge(run_id, reason="new-input", trigger_artifact="artifact-1")
    await namespace.cancel(run_id)

    assert [call["endpoint"] for call in client.calls] == [
        f"/api/authority/runs/{run_id}/retry",
        f"/api/authority/runs/{run_id}/nudge",
        f"/api/authority/runs/{run_id}/cancel",
    ]
    assert client.calls[0]["body"]["reason"] == "manual-retry"
    assert client.calls[1]["body"]["reason"] == "new-input"
    assert client.calls[1]["body"]["trigger_artifact"] == "artifact-1"
    assert isinstance(client.calls[0]["body"]["idempotency_key"], str)
    assert isinstance(client.calls[1]["body"]["idempotency_key"], str)
    assert isinstance(client.calls[2]["body"]["idempotency_key"], str)


@pytest.mark.asyncio
async def test_execute_pipeline_routes_to_native_pipeline_runner():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.execute_pipeline(
        "pipe-123",
        mode="async",
        context={"accession": "A-1"},
        workflow_overrides={
            "wf-123": {
                "artifacts": [{"artifact_key": "input", "artifact_id": "art-1"}],
            }
        },
        poll_interval_ms=500,
    )

    call = client.calls[0]
    assert call["endpoint"] == "/api/workflow/pipelines/pipe-123/execute"
    assert call["body"]["config"]["mode"] == "async"
    assert call["body"]["config"]["poll_interval_ms"] == 500
    assert call["body"]["context"] == {"accession": "A-1"}
    assert call["body"]["workflow_overrides"]["wf-123"]["artifacts"] == [
        {"artifact_key": "input", "artifact_id": "art-1"}
    ]


@pytest.mark.asyncio
async def test_update_pipeline_routes_to_put_surface():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.update_pipeline(
        "pipe-123",
        name="Claims Pipeline",
        definition={
            "version": 2,
            "nodes": [{"id": "seed", "type": "deterministic", "operation": "set_value", "value": "ok"}],
        },
    )

    call = client.calls[0]
    assert call["endpoint"] == "/api/workflow/pipelines/pipe-123"
    assert call["method"] == "PUT"
    assert call["body"]["name"] == "Claims Pipeline"
    assert call["body"]["definition"]["version"] == 2


@pytest.mark.asyncio
async def test_execute_pipeline_forwards_resume_execution_id():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.execute_pipeline(
        "pipe-123",
        mode="blocking",
        resume_execution_id="resume-1",
    )

    call = client.calls[0]
    assert call["body"]["config"]["resume_execution_id"] == "resume-1"


@pytest.mark.asyncio
async def test_saved_workflow_instance_ensure_contract_matches_workflow_manager():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.ensure_instance(
        "wf-instance",
        instance_id="inst-1",
        group="reports",
        owner="company:acme",
        environment="production",
        nudge_policy={
            "mode": "coalesce",
            "maxRerunCount": 3,
            "rerunWindowSeconds": 120,
            "cooldown_seconds": 15,
        },
        bindings={"subject": "PCM47474562"},
        mode="async",
        context={"company": "acme"},
    )

    call = client.calls[0]
    assert call["endpoint"] == "/api/workflow/workflows/wf-instance/instances/ensure"
    assert call["body"] == {
        "instance_id": "inst-1",
        "params": {
            "group": "reports",
            "owner": "company:acme",
            "env": "production",
            "nudge_policy": {
                "mode": "coalesce",
                "max_rerun_count": 3,
                "rerun_window_seconds": 120,
                "cooldown_seconds": 15,
            },
        },
        "bindings": {"subject": "PCM47474562"},
        "mode": "async",
        "context": {"company": "acme"},
    }


@pytest.mark.asyncio
async def test_recipe_workflow_ensure_is_authority_only_and_stream_guard():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.ensure(
        workflow_recipe_ref="recipe://workflow-recipe-v1/report-cycle@head",
        mode="ensure_only",
    )

    call = client.calls[0]
    assert call["endpoint"] == "/api/authority/runs/ensure"
    assert call["body"]["workflow_recipe_ref"] == "recipe://workflow-recipe-v1/report-cycle@head"
    assert call["body"]["mode"] == "ensure_only"
    assert isinstance(call["body"]["idempotency_key"], str)

    with pytest.raises(ValueError, match="Authority-only and supports blocking, async, or ensure_only"):
        await namespace.ensure(
            workflow_recipe_ref="recipe://workflow-recipe-v1/report-cycle@head",
            mode="streaming",
        )

    with pytest.raises(ValueError, match="Use stream_ensure_instance\\(\\) for streaming instance execution"):
        await namespace.ensure_instance(
            "wf-instance",
            group="reports",
            owner="company:acme",
            mode="streaming",
        )


@pytest.mark.asyncio
async def test_stream_ensure_instance_uses_streaming_mode():
    client = FakeClient(stream_chunks=[{"_event": "instance_ensured"}, {"_event": "workflow_complete"}])
    namespace = WorkflowNamespace(client)

    streamed = [
        chunk
        async for chunk in namespace.stream_ensure_instance(
            "wf-instance",
            group="reports",
            owner="company:acme",
            bindings={"subject": "PCM47474562"},
        )
    ]

    assert client.stream_calls == [
        {
            "endpoint": "/api/workflow/workflows/wf-instance/instances/ensure",
            "body": {
                "params": {
                    "group": "reports",
                    "owner": "company:acme",
                },
                "bindings": {"subject": "PCM47474562"},
                "mode": "streaming",
            },
            "timeout": 300.0,
            "use_gateway": True,
        }
    ]
    assert streamed == [{"_event": "instance_ensured"}, {"_event": "workflow_complete"}]


@pytest.mark.asyncio
async def test_workflow_instance_read_routes_match_contract():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.get_instance_status("wf-instance", "inst/1")
    await namespace.list_instances(
        workflow_id="wf-instance",
        group="reports",
        owner="company:acme",
        environment="production",
        status="idle",
        limit=25,
        offset=5,
    )
    await namespace.get_instance_artifacts("wf-instance", "inst-1")
    await namespace.get_instance_outputs("wf-instance", "inst-1")
    await namespace.get_instance_history("wf-instance", "inst-1", limit=10, offset=2)

    assert client.calls[0]["endpoint"] == "/api/workflow/workflows/wf-instance/instances/inst%2F1/status"
    assert client.calls[0]["method"] == "GET"
    assert client.calls[1]["endpoint"] == (
        "/api/workflow/instances"
        "?limit=25&offset=5&workflow_id=wf-instance&group=reports&owner=company:acme"
        "&environment=production&status=idle"
    )
    assert client.calls[1]["method"] == "GET"
    assert client.calls[2]["endpoint"] == "/api/workflow/workflows/wf-instance/instances/inst-1/artifacts"
    assert client.calls[2]["method"] == "GET"
    assert client.calls[3]["endpoint"] == "/api/workflow/workflows/wf-instance/instances/inst-1/outputs"
    assert client.calls[3]["method"] == "GET"
    assert client.calls[4]["endpoint"] == (
        "/api/workflow/workflows/wf-instance/instances/inst-1/history?limit=10&offset=2"
    )
    assert client.calls[4]["method"] == "GET"


@pytest.mark.asyncio
async def test_workflow_instance_nudge_retry_and_cancel_contract():
    client = FakeClient(stream_chunks=[{"_event": "instance_nudged"}])
    namespace = WorkflowNamespace(client)

    await namespace.nudge_instance(
        "wf-instance",
        "inst-1",
        reason="artifact-updated",
        trigger_artifact="report_snapshot",
        mode="blocking",
    )
    await namespace.nudge(
        "wf-instance",
        "inst-2",
        reason="manual-retry",
    )
    await namespace.retry_instance(
        "wf-instance",
        "inst-3",
        trigger_artifact="report_snapshot",
        mode="async",
    )
    await namespace.cancel_instance("wf-instance", "inst-4")

    streamed = [
        chunk
        async for chunk in namespace.stream_nudge_instance(
            "wf-instance",
            "inst-5",
            reason="artifact-updated",
            trigger_artifact="report_snapshot",
        )
    ]

    assert client.calls[0]["endpoint"] == "/api/workflow/workflows/wf-instance/instances/inst-1/nudge"
    assert client.calls[0]["body"] == {
        "reason": "artifact-updated",
        "trigger_artifact": "report_snapshot",
        "mode": "blocking",
    }

    assert client.calls[1]["endpoint"] == "/api/workflow/workflows/wf-instance/instances/inst-2/nudge"
    assert client.calls[1]["body"] == {
        "reason": "manual-retry",
        "mode": "async",
    }

    assert client.calls[2]["endpoint"] == "/api/workflow/workflows/wf-instance/instances/inst-3/nudge"
    assert client.calls[2]["body"] == {
        "reason": "retry",
        "trigger_artifact": "report_snapshot",
        "mode": "async",
    }

    assert client.calls[3]["endpoint"] == "/api/workflow/workflows/wf-instance/instances/inst-4/cancel"
    assert client.calls[3]["body"] == {}

    assert client.stream_calls == [
        {
            "endpoint": "/api/workflow/workflows/wf-instance/instances/inst-5/nudge",
            "body": {
                "reason": "artifact-updated",
                "trigger_artifact": "report_snapshot",
                "mode": "streaming",
            },
            "timeout": 300.0,
            "use_gateway": True,
        }
    ]
    assert streamed == [{"_event": "instance_nudged"}]

    with pytest.raises(ValueError, match="Use stream_nudge_instance\\(\\) for streaming instance execution"):
        await namespace.nudge_instance(
            "wf-instance",
            "inst-1",
            reason="artifact-updated",
            mode="streaming",
        )
