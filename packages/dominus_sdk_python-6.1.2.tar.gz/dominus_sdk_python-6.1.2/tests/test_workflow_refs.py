import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dominus.namespaces.artifacts import ArtifactsNamespace, build_artifact_ref, parse_artifact_ref  # noqa: E402
from dominus.namespaces.workflow import WorkflowNamespace  # noqa: E402


class FakeClient:
    def __init__(self):
        self.calls = []

    async def _request(
        self,
        endpoint,
        method="POST",
        body=None,
        user_token=None,
        use_gateway=False,
        timeout=30.0,
        actor=None,
        **kwargs,
    ):
        self.calls.append(
            {
                "endpoint": endpoint,
                "method": method,
                "body": body,
                "user_token": user_token,
                "use_gateway": use_gateway,
                "timeout": timeout,
                "actor": actor,
            }
        )
        return {"ok": True}


@pytest.mark.asyncio
async def test_workflow_get_accepts_workflow_ref():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.get("wf://carebridge-platform/production/shared/patient-intake", include_content=True)

    assert client.calls[0]["endpoint"] == (
        "/api/workflow/workflows/by-ref?"
        "workflow_ref=wf%3A%2F%2Fcarebridge-platform%2Fproduction%2Fshared%2Fpatient-intake"
        "&include_content=true"
    )


@pytest.mark.asyncio
async def test_workflow_ensure_rejects_legacy_workflow_ref():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    with pytest.raises(ValueError, match="recipe_ref"):
        await namespace.ensure(
            "wf://carebridge-platform/production/shared/patient-intake",
            subject="sub-1",
            company="co-1",
            instance_id="run-123",
            context={"report_ref": {"report_id": "r-1"}},
            mode="async",
        )

    assert client.calls == []


@pytest.mark.asyncio
async def test_workflow_ensure_accepts_recipe_refs():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.ensure(
        workflow_recipe_ref="recipe://workflow-recipe-v1/patient-intake@v4",
        subject="sub-1",
        company="co-1",
        mode="async",
    )
    await namespace.ensure(
        pipeline_recipe_ref="recipe://pipeline-recipe-v1/intake-pipeline@v2",
        context={"report_ref": {"report_id": "r-1"}},
        mode="async",
    )

    first = client.calls[0]["body"]
    assert first["workflow_recipe_ref"] == "recipe://workflow-recipe-v1/patient-intake@v4"
    assert first["subject"] == "sub-1"
    assert "workflow_id" not in first
    second = client.calls[1]["body"]
    assert second["pipeline_recipe_ref"] == "recipe://pipeline-recipe-v1/intake-pipeline@v2"
    assert second["context"] == {"report_ref": {"report_id": "r-1"}}
    assert "workflow_ref" not in second


@pytest.mark.asyncio
async def test_workflow_ensure_rejects_mixed_recipe_refs():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    with pytest.raises(ValueError, match="exactly one"):
        await namespace.ensure(
            "recipe://pipeline-recipe-v1/intake-pipeline@v2",
            workflow_recipe_ref="recipe://workflow-recipe-v1/patient-intake@v4",
        )

    assert client.calls == []


@pytest.mark.asyncio
async def test_workflow_save_forwards_builder_metadata():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.save(
        name="Report Organizer",
        yaml_content="name: report-organizer",
        workflow_id="wf-123",
        metadata={
            "customRunId": "report-session-1",
            "preloadedArtifacts": [{"name": "raw_report"}],
        },
    )

    assert client.calls[0]["endpoint"] == "/api/workflow/workflows"
    assert client.calls[0]["body"] == {
        "name": "Report Organizer",
        "yaml_content": "name: report-organizer",
        "workflow_id": "wf-123",
        "metadata": {
            "customRunId": "report-session-1",
            "preloadedArtifacts": [{"name": "raw_report"}],
        },
    }


def test_artifact_ref_helpers_round_trip():
    artifact_ref = build_artifact_ref(
        project_slug="carebridge-summit",
        environment="production",
        namespace="company",
        artifact_key="carebridge/carebridge-summit/production/report-workflow/report/report-1/report_snapshot_current.json",
    )

    assert artifact_ref == (
        "ar://carebridge-summit/production/company/"
        "carebridge%2Fcarebridge-summit%2Fproduction%2Freport-workflow%2Freport%2Freport-1%2Freport_snapshot_current.json"
    )
    assert parse_artifact_ref(artifact_ref) == {
        "format": "v1",
        "raw": artifact_ref,
        "project_slug": "carebridge-summit",
        "environment": "production",
        "namespace": "company",
        "artifact_key": "carebridge/carebridge-summit/production/report-workflow/report/report-1/report_snapshot_current.json",
    }


def test_artifact_ref_helpers_support_v2_refs():
    v2_ref = build_artifact_ref(
        group="carebridge",
        owner="carebridge-summit",
        environment="production",
        kind="company",
        artifact_key="report_snapshot_current",
    )

    assert v2_ref == "ar://carebridge/carebridge-summit/production/company/report_snapshot_current"
    assert parse_artifact_ref(v2_ref) == {
        "format": "v2",
        "raw": v2_ref,
        "group": "carebridge",
        "owner": "carebridge-summit",
        "environment": "production",
        "kind": "company",
        "artifact_key": "report_snapshot_current",
    }

    pinned_ref = f"{v2_ref}@v3"
    assert parse_artifact_ref(pinned_ref) == {
        "format": "v2",
        "raw": pinned_ref,
        "group": "carebridge",
        "owner": "carebridge-summit",
        "environment": "production",
        "kind": "company",
        "artifact_key": "report_snapshot_current",
        "version": 3,
    }


@pytest.mark.asyncio
async def test_artifacts_namespace_v2_routes_use_addressed_endpoints():
    client = FakeClient()
    namespace = ArtifactsNamespace(client)

    await namespace.store_v2(
        group="carebridge",
        owner="carebridge-summit",
        environment="production",
        kind="company",
        artifact_key="report_snapshot_current",
        data="ZGF0YQ==",
    )
    await namespace.head_v2(
        group="carebridge",
        owner="carebridge-summit",
        environment="production",
        kind="company",
        artifact_key="report_snapshot_current",
    )
    await namespace.compare_v2(
        left={
            "group": "carebridge",
            "owner": "carebridge-summit",
            "environment": "production",
            "kind": "company",
            "artifact_key": "report_snapshot_current",
        },
        right={
            "group": "carebridge",
            "owner": "carebridge-summit",
            "environment": "production",
            "kind": "company",
            "artifact_key": "report_snapshot_next",
        },
        mode="hash",
    )
    await namespace.bookmark_set_v2(
        bookmark_name="latest",
        group="carebridge",
        owner="carebridge-summit",
        environment="production",
        kind="company",
        artifact_key="report_snapshot_current",
    )
    await namespace.watch_v2(
        watcher_name="report-hook",
        trigger_rule="any_new_version",
        target="https://example.com/hooks/report",
        group="carebridge",
        owner="carebridge-summit",
        environment="production",
        kind="company",
        artifact_key="report_snapshot_current",
    )

    assert [call["endpoint"] for call in client.calls] == [
        "/api/artifact/v2/store",
        "/api/artifact/v2/head",
        "/api/artifact/v2/compare",
        "/api/artifact/v2/bookmark/set",
        "/api/artifact/v2/watch",
    ]
