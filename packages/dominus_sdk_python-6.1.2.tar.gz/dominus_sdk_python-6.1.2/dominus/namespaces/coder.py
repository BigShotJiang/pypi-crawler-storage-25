"""Coder namespace.

Lifecycle helpers for dominus-coder-runtime. This surface intentionally avoids
raw shell, filesystem browsing, and credential ingress helpers; Platform
decisions and Coder Runtime own executor policy and workspace operations.
"""
from __future__ import annotations

from typing import Any, Dict, Optional, TYPE_CHECKING
from urllib.parse import quote, urlencode

if TYPE_CHECKING:
    from ..start import Dominus


def _compact(payload: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for key, value in payload.items():
        if value is None:
            continue
        if isinstance(value, str) and value.strip() == "":
            continue
        out[key] = value
    return out


def _query_string(params: Dict[str, Any]) -> str:
    cleaned = _compact(params)
    return f"?{urlencode(cleaned)}" if cleaned else ""


def _normalize_coder_path(path: str) -> str:
    trimmed = path.strip()
    normalized = trimmed if trimmed.startswith("/") else f"/{trimmed}"
    if normalized == "/svc/coder" or normalized.startswith("/svc/coder/"):
        return normalized
    if normalized == "/api/coder" or normalized.startswith("/api/coder/"):
        return normalized.replace("/api/", "/svc/", 1)
    return f"/svc/coder{normalized}"


def _mutation_body(
    *,
    reason: Optional[str] = None,
    idempotency_key: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return _compact(
        {
            "reason": reason,
            "idempotency_key": idempotency_key,
            "metadata": metadata,
        }
    )


def _actor_headers(actor_context: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
    if not actor_context:
        return None
    actor_type = str(actor_context.get("type") or actor_context.get("actor_type") or "").strip()
    actor_id = str(actor_context.get("id") or actor_context.get("actor_id") or "").strip()
    if not actor_type or not actor_id:
        return None
    return {"X-Actor-Type": actor_type, "X-Actor-Id": actor_id}


def _assert_one_launch_source(workflow_recipe_ref: Optional[str], pipeline_recipe_ref: Optional[str]) -> None:
    present = [
        ref
        for ref in (workflow_recipe_ref, pipeline_recipe_ref)
        if isinstance(ref, str) and ref.strip()
    ]
    if len(present) != 1:
        raise ValueError("ensure_run requires exactly one of workflow_recipe_ref or pipeline_recipe_ref")


class CoderNamespace:
    """Coder run lifecycle helpers."""

    def __init__(self, client: "Dominus"):
        self._client = client

    async def request(
        self,
        path: str,
        *,
        method: str = "GET",
        body: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
    ) -> Any:
        return await self._client.gateway_fetch(
            _normalize_coder_path(path),
            method=method,
            body=body,
            headers=headers,
            timeout=timeout,
        )

    async def health(self) -> Dict[str, Any]:
        return await self.request("/health", method="GET")

    async def ready(self) -> Dict[str, Any]:
        return await self.request("/ready", method="GET")

    async def ensure_run(
        self,
        *,
        policy_decision_id: str,
        idempotency_key: Optional[str] = None,
        mode: Optional[str] = None,
        task_recipe_ref: Optional[str] = None,
        workflow_recipe_ref: Optional[str] = None,
        pipeline_recipe_ref: Optional[str] = None,
        group: Optional[str] = None,
        repository: Optional[str] = None,
        branch: Optional[str] = None,
        base_branch: Optional[str] = None,
        working_branch: Optional[str] = None,
        title: Optional[str] = None,
        instructions: Optional[str] = None,
        inputs: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        if not policy_decision_id or policy_decision_id.strip() == "":
            raise ValueError("ensure_run requires policy_decision_id")
        _assert_one_launch_source(workflow_recipe_ref, pipeline_recipe_ref)

        body = _compact(
            {
                "policy_decision_id": policy_decision_id,
                "idempotency_key": idempotency_key,
                "mode": mode,
                "task_recipe_ref": task_recipe_ref,
                "workflow_recipe_ref": workflow_recipe_ref,
                "pipeline_recipe_ref": pipeline_recipe_ref,
                "group": group,
                "repository": repository,
                "branch": branch,
                "base_branch": base_branch,
                "working_branch": working_branch,
                "title": title,
                "instructions": instructions,
                "inputs": inputs,
                "metadata": metadata,
            }
        )
        return await self.request(
            "/runs/ensure",
            method="POST",
            body=body,
            headers=_actor_headers(actor_context),
            timeout=600.0,
        )

    async def list_runs(
        self,
        *,
        status: Optional[str] = None,
        group: Optional[str] = None,
        repository: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        qs = _query_string(
            {
                "status": status,
                "group": group,
                "repository": repository,
                "limit": limit,
                "offset": offset,
            }
        )
        return await self.request(f"/runs{qs}", method="GET", headers=_actor_headers(actor_context))

    async def get_run(
        self,
        run_id: str,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/runs/{quote(run_id, safe='')}",
            method="GET",
            headers=_actor_headers(actor_context),
        )

    async def cancel_run(
        self,
        run_id: str,
        *,
        reason: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/runs/{quote(run_id, safe='')}/cancel",
            method="POST",
            body=_mutation_body(
                reason=reason,
                idempotency_key=idempotency_key,
                metadata=metadata,
            ),
            headers=_actor_headers(actor_context),
        )

    async def retry_run(
        self,
        run_id: str,
        *,
        reason: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/runs/{quote(run_id, safe='')}/retry",
            method="POST",
            body=_mutation_body(
                reason=reason,
                idempotency_key=idempotency_key,
                metadata=metadata,
            ),
            headers=_actor_headers(actor_context),
        )

    async def nudge_run(
        self,
        run_id: str,
        *,
        reason: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/runs/{quote(run_id, safe='')}/nudge",
            method="POST",
            body=_mutation_body(
                reason=reason,
                idempotency_key=idempotency_key,
                metadata=metadata,
            ),
            headers=_actor_headers(actor_context),
        )

    async def get_run_summary(
        self,
        run_id: str,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/runs/{quote(run_id, safe='')}/summary",
            method="GET",
            headers=_actor_headers(actor_context),
        )

    async def get_run_artifacts(
        self,
        run_id: str,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/runs/{quote(run_id, safe='')}/artifacts",
            method="GET",
            headers=_actor_headers(actor_context),
        )
