"""
Redis Namespace - Redis Worker caching operations.

Provides Redis caching operations via Upstash REST API.
"""
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


class RedisNamespace:
    """
    Redis caching namespace.

    All caching operations go through /api/redis/* endpoints.
    TTL enforced: min 60 seconds, max 86400 seconds (24 hours).

    Usage:
        # Set/get values
        await dominus.redis.set("user:123", {"name": "John"}, ttl=3600)
        value = await dominus.redis.get("user:123")

        # Get with TTL refresh
        value = await dominus.redis.get("user:123", nudge=True, ttl=3600)

        # Distributed locks
        acquired = await dominus.redis.setnx("lock:resource", "owner_id", ttl=30)

        # Counters
        count = await dominus.redis.incr("page:views", delta=1)

        # Hash operations
        await dominus.redis.hset("user:123", "email", "john@example.com")
        email = await dominus.redis.hget("user:123", "email")
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def set(
        self,
        key: str,
        value: Any,
        ttl: int = 3600,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Set a value with TTL.

        Args:
            key: Key name (logical_path)
            value: Any JSON-serializable value
            ttl: Time-to-live in seconds (60-86400, default: 3600)
            category: Optional namespace category

        Returns:
            Dict with "key", "stored", "ttl_seconds"
        """
        body = {
            "logical_path": key,
            "value": value,
            "ttl_seconds": ttl
        }
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/set",
            body=body,
            use_gateway=True,
        )

    async def get(
        self,
        key: str,
        category: Optional[str] = None,
        nudge: bool = False,
        ttl: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Get a value, optionally refreshing TTL.

        Args:
            key: Key name (logical_path)
            category: Optional namespace category
            nudge: If True, refresh TTL on read
            ttl: New TTL if nudge=True (uses default if not provided)

        Returns:
            Dict with "found" (bool) and "value" (if found)
        """
        body = {
            "logical_path": key,
            "nudge": nudge
        }
        if category:
            body["category"] = category
        if ttl and nudge:
            body["ttl_seconds"] = ttl

        return await self._client._request(
            endpoint="/api/redis/get",
            body=body,
            use_gateway=True,
        )

    async def delete(
        self,
        key: str,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Delete a key.

        Args:
            key: Key name (logical_path)
            category: Optional namespace category

        Returns:
            Dict with "deleted" (bool)
        """
        body = {"logical_path": key}
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/delete",
            body=body,
            use_gateway=True,
        )

    async def ttl(
        self,
        key: str,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get remaining TTL for a key.

        Args:
            key: Key name (logical_path)
            category: Optional namespace category

        Returns:
            Dict with "found" (bool), "ttl_seconds" (int, -1 if no expiry)
        """
        body: Dict[str, Any] = {"logical_path": key}
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/ttl",
            body=body,
            use_gateway=True,
        )

    async def list(
        self,
        prefix: Optional[str] = None,
        category: Optional[str] = None,
        limit: int = 100,
        cursor: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List keys by prefix with pagination.

        Args:
            prefix: Key prefix filter
            category: Optional namespace category
            limit: Maximum keys to return (max 500, default: 100)
            cursor: Pagination cursor from previous response

        Returns:
            Dict with "keys" list, "cursor" (for next page), "count"
        """
        body = {"limit": min(limit, 500)}
        if prefix:
            body["logical_prefix"] = prefix
        if category:
            body["category"] = category
        if cursor:
            body["cursor"] = cursor

        return await self._client._request(
            endpoint="/api/redis/list",
            body=body,
            use_gateway=True,
        )

    async def mget(self, keys: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        Get multiple keys at once.

        Args:
            keys: List of key specs [{"logical_path": "...", "category": "..."}]
                  Maximum 100 keys per request.

        Returns:
            Dict with "results" list of {"found": bool, "value": ...}
        """
        return await self._client._request(
            endpoint="/api/redis/mget",
            body={"keys": keys[:100]},
            use_gateway=True,
        )

    async def setnx(
        self,
        key: str,
        value: Any,
        ttl: int = 60,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Set if not exists (for distributed locks/idempotency).

        Args:
            key: Key name (logical_path)
            value: Any JSON-serializable value
            ttl: Time-to-live in seconds (60-86400, default: 60)
            category: Optional namespace category

        Returns:
            Dict with "acquired" (bool), and "existing" value if not acquired
        """
        body = {
            "logical_path": key,
            "value": value,
            "ttl_seconds": ttl
        }
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/setnx",
            body=body,
            use_gateway=True,
        )

    async def incr(
        self,
        key: str,
        delta: int = 1,
        ttl: int = 3600,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Increment counter (creates if not exists).

        Args:
            key: Key name (logical_path)
            delta: Increment amount (can be negative, default: 1)
            ttl: Time-to-live in seconds (60-86400, default: 3600)
            category: Optional namespace category

        Returns:
            Dict with "value" (new counter value)
        """
        body = {
            "logical_path": key,
            "delta": delta,
            "ttl_seconds": ttl
        }
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/incr",
            body=body,
            use_gateway=True,
        )

    async def hset(
        self,
        key: str,
        field: str,
        value: Any,
        ttl: int = 3600,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Set a hash field.

        Args:
            key: Hash key name (logical_path)
            field: Field name within the hash
            value: Any JSON-serializable value
            ttl: Time-to-live in seconds (60-86400, default: 3600)
            category: Optional namespace category

        Returns:
            Dict with "set" (bool - True if new field, False if updated)
        """
        body = {
            "logical_path": key,
            "field": field,
            "value": value,
            "ttl_seconds": ttl
        }
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/hset",
            body=body,
            use_gateway=True,
        )

    async def hget(
        self,
        key: str,
        field: str,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get a hash field.

        Args:
            key: Hash key name (logical_path)
            field: Field name within the hash
            category: Optional namespace category

        Returns:
            Dict with "found" (bool) and "value" (if found)
        """
        body = {
            "logical_path": key,
            "field": field
        }
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/hget",
            body=body,
            use_gateway=True,
        )

    async def hgetall(
        self,
        key: str,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get all fields from a hash.

        Args:
            key: Hash key name (logical_path)
            category: Optional namespace category

        Returns:
            Dict with "found" (bool) and "fields" dict (if found)
        """
        body = {"logical_path": key}
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/hgetall",
            body=body,
            use_gateway=True,
        )

    async def hdel(
        self,
        key: str,
        field: str,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Delete a hash field.

        Args:
            key: Hash key name (logical_path)
            field: Field name to delete
            category: Optional namespace category

        Returns:
            Dict with "deleted" (bool)
        """
        body = {
            "logical_path": key,
            "field": field
        }
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/hdel",
            body=body,
            use_gateway=True,
        )

    async def type(
        self,
        key: str,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get the type of a key.

        Args:
            key: Key name (logical_path)
            category: Optional namespace category

        Returns:
            Dict with "type" (string: none, string, list, set, zset, hash)
        """
        body = {"logical_path": key}
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/type",
            body=body,
            use_gateway=True,
        )

    async def smembers(
        self,
        key: str,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get all members of a set.

        Args:
            key: Key name (logical_path)
            category: Optional namespace category

        Returns:
            Dict with "members" list
        """
        body = {"logical_path": key}
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/smembers",
            body=body,
            use_gateway=True,
        )

    async def sadd(
        self,
        key: str,
        members: List[Any],
        ttl: int = 3600,
        category: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Add one or more members to a Redis set, with TTL refresh.

        Backed by the native dominus-redis-worker /sadd route added 2026-05-09.
        Each member is independently size-guarded (1 MiB cap per encoded value).

        Args:
            key: Key name (logical_path)
            members: List of values to add
            ttl: Time-to-live in seconds for the set (default 3600)
            category: Optional namespace category

        Returns:
            Dict with {"key", "added", "ttl_seconds"}
        """
        body: Dict[str, Any] = {
            "logical_path": key,
            "members": members,
            "ttl_seconds": ttl,
        }
        if category:
            body["category"] = category
        return await self._client._request(
            endpoint="/api/redis/sadd",
            body=body,
            use_gateway=True,
        )

    async def srem(
        self,
        key: str,
        members: List[Any],
        category: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Remove one or more members from a Redis set.

        Backed by the native dominus-redis-worker /srem route added 2026-05-09.

        Args:
            key: Key name (logical_path)
            members: List of values to remove
            category: Optional namespace category

        Returns:
            Dict with {"key", "removed"}
        """
        body: Dict[str, Any] = {
            "logical_path": key,
            "members": members,
        }
        if category:
            body["category"] = category
        return await self._client._request(
            endpoint="/api/redis/srem",
            body=body,
            use_gateway=True,
        )

    async def mset(
        self,
        entries: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Multi-set: write 1..50 keys (potentially different categories and TTLs)
        in one redis-worker invocation. Backed by /mset added 2026-05-08.

        Use for fixed-batch fan-out (e.g. heartbeat-style multi-write paths)
        to reduce Cloudflare worker invocation counts and gateway hops.

        Args:
            entries: List of dicts each with {"key": str, "value": Any,
                     "ttl"?: int, "category"?: str}

        Returns:
            Dict with {"stored": [{"key", "stored", "ttl_seconds"}, ...]}
        """
        wire_entries: List[Dict[str, Any]] = []
        for entry in entries:
            wire: Dict[str, Any] = {
                "logical_path": entry["key"],
                "value": entry["value"],
            }
            if "ttl" in entry and entry["ttl"] is not None:
                wire["ttl_seconds"] = entry["ttl"]
            if entry.get("category"):
                wire["category"] = entry["category"]
            wire_entries.append(wire)
        return await self._client._request(
            endpoint="/api/redis/mset",
            body={"entries": wire_entries},
            use_gateway=True,
        )

    async def lrange(
        self,
        key: str,
        start: int = 0,
        stop: int = -1,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get a range of items from a list.

        Args:
            key: Key name (logical_path)
            start: Start index (default: 0)
            stop: Stop index (default: -1 for all)
            category: Optional namespace category

        Returns:
            Dict with "items" list
        """
        body = {
            "logical_path": key,
            "start": start,
            "stop": stop
        }
        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/redis/lrange",
            body=body,
            use_gateway=True,
        )

    async def xadd(
        self,
        key: str,
        fields: Dict[str, Any],
        id: Optional[str] = None,
        maxlen: Optional[int] = None,
        ttl: Optional[int] = None,
        category: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Append an entry to a Redis stream.

        Backed by the native dominus-redis-worker /xadd route added 2026-05-09.
        Each field value is independently size-guarded (1 MiB cap per encoded
        value). Use streams for log-style state that scales with iteration
        count (agent step events, audit trails). Replaces RedisWorkerProjectCompat
        shim emulation that did SET/GET whole-collection rewrites.

        Args:
            key: Stream key (logical_path)
            fields: Field/value dict for the new entry
            id: Optional explicit ID. Defaults to ``*`` (server-generated
                ``<ms>-<seq>``). Returned in the response so callers can use
                it for downstream xrange resume-after pagination.
            maxlen: Optional MAXLEN cap. When set, redis-worker calls XADD
                with MAXLEN ~ N (approximate trim).
            ttl: Optional TTL in seconds (default uses worker default 3600).
            category: Optional namespace category (default ``streams``).

        Returns:
            Dict with {"key", "id", "ttl_seconds"}
        """
        body: Dict[str, Any] = {
            "logical_path": key,
            "fields": fields,
        }
        if id:
            body["id"] = id
        if maxlen is not None:
            body["maxlen"] = maxlen
        if ttl is not None:
            body["ttl_seconds"] = ttl
        if category:
            body["category"] = category
        return await self._client._request(
            endpoint="/api/redis/xadd",
            body=body,
            use_gateway=True,
        )

    async def xrange(
        self,
        key: str,
        min: str = "-",
        max: str = "+",
        count: Optional[int] = None,
        category: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Read entries from a Redis stream in id order.

        Backed by /xrange added 2026-05-09. Pass ``-``/``+`` (default) for
        the full range or explicit ``<ms>-<seq>`` ids for resume-after
        pagination.

        Args:
            key: Stream key (logical_path)
            min: Inclusive lower bound id, ``-`` for oldest.
            max: Inclusive upper bound id, ``+`` for newest.
            count: Optional COUNT cap.
            category: Optional namespace category (default ``streams``).

        Returns:
            Dict with {"found", "entries": [{"id", "fields"}, ...], "count"}
        """
        body: Dict[str, Any] = {
            "logical_path": key,
            "min": min,
            "max": max,
        }
        if count is not None:
            body["count"] = count
        if category:
            body["category"] = category
        return await self._client._request(
            endpoint="/api/redis/xrange",
            body=body,
            use_gateway=True,
        )

    async def xlen(
        self,
        key: str,
        category: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Stream entry count.

        Backed by /xlen added 2026-05-09. Approximate on streams with
        deletions; exact otherwise.

        Args:
            key: Stream key (logical_path)
            category: Optional namespace category (default ``streams``).

        Returns:
            Dict with {"length"}
        """
        body: Dict[str, Any] = {"logical_path": key}
        if category:
            body["category"] = category
        return await self._client._request(
            endpoint="/api/redis/xlen",
            body=body,
            use_gateway=True,
        )
