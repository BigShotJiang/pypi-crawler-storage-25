"""
Stash Namespace - per-scope durable items (credentials + configs).

Routes through ``/svc/stash/*`` on the Dominus gateway. The stash worker
stores items in each project's ``stash.*`` schema and transparently falls
back to a designated shared project on read.
"""
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


class StashNamespace:
    """
    Stash worker namespace.

    Usage:
        item = await dominus.stash.resolve(
            kind="credential.vendor.fuji_synapse",
            scope={"user_id": user_id, "organization_code": "piedmont"},
            purpose="extraction",
        )
        await dominus.stash.mark_verified(id=item["id"], purpose="extraction")
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def upsert(
        self,
        *,
        kind: str,
        scope: Dict[str, Any],
        value: Dict[str, Any],
        id: Optional[str] = None,
        target: Optional[str] = None,
        item_key: Optional[str] = None,
        role: Optional[str] = None,
        priority: Optional[int] = None,
        is_sensitive: Optional[bool] = None,
        rotation_interval_days: Optional[int] = None,
        expires_at: Optional[str] = None,
        purpose: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Insert or update a stash item."""
        body: Dict[str, Any] = {"kind": kind, "scope": scope, "value": value}
        if id is not None:
            body["id"] = id
        if target is not None:
            body["target"] = target
        if item_key is not None:
            body["item_key"] = item_key
        if role is not None:
            body["role"] = role
        if priority is not None:
            body["priority"] = priority
        if is_sensitive is not None:
            body["is_sensitive"] = is_sensitive
        if rotation_interval_days is not None:
            body["rotation_interval_days"] = rotation_interval_days
        if expires_at is not None:
            body["expires_at"] = expires_at
        if purpose is not None:
            body["purpose"] = purpose
        return await self._client._request(
            endpoint="/svc/stash/items/upsert",
            body=body,
            use_gateway=True,
        )

    async def get(
        self,
        id: str,
        *,
        purpose: Optional[str] = None,
        include_shared: Optional[bool] = None,
    ) -> Optional[Dict[str, Any]]:
        """Fetch a single item by id; decrypts sensitive values."""
        body: Dict[str, Any] = {"id": id}
        if purpose is not None:
            body["purpose"] = purpose
        if include_shared is not None:
            body["include_shared"] = include_shared
        result = await self._client._request(
            endpoint="/svc/stash/items/get",
            body=body,
            use_gateway=True,
        )
        return result.get("item") if isinstance(result, dict) else None

    async def resolve(
        self,
        *,
        kind: str,
        scope: Dict[str, Any],
        purpose: str,
        fallback_roles: Optional[List[str]] = None,
        health_status_in: Optional[List[str]] = None,
        machine_id: Optional[str] = None,
        include_shared: Optional[bool] = None,
    ) -> Optional[Dict[str, Any]]:
        """Resolve the best-priority match by (kind, scope) with fallback walk."""
        body: Dict[str, Any] = {"kind": kind, "scope": scope, "purpose": purpose}
        if fallback_roles is not None:
            body["fallback_roles"] = fallback_roles
        if health_status_in is not None:
            body["health_status_in"] = health_status_in
        if machine_id is not None:
            body["machine_id"] = machine_id
        if include_shared is not None:
            body["include_shared"] = include_shared
        result = await self._client._request(
            endpoint="/svc/stash/items/resolve",
            body=body,
            use_gateway=True,
        )
        return result.get("item") if isinstance(result, dict) else None

    async def list(
        self,
        *,
        kind: Optional[str] = None,
        scope: Optional[Dict[str, Any]] = None,
        role: Optional[str] = None,
        health_status: Optional[Any] = None,
        scope_origin: Optional[str] = None,
        include_deleted: Optional[bool] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        """List items by (kind, partial scope, role, health). Metadata only."""
        body: Dict[str, Any] = {}
        if kind is not None:
            body["kind"] = kind
        if scope is not None:
            body["scope"] = scope
        if role is not None:
            body["role"] = role
        if health_status is not None:
            body["health_status"] = health_status
        if scope_origin is not None:
            body["scope_origin"] = scope_origin
        if include_deleted is not None:
            body["include_deleted"] = include_deleted
        if limit is not None:
            body["limit"] = limit
        if offset is not None:
            body["offset"] = offset
        return await self._client._request(
            endpoint="/svc/stash/items/list",
            body=body,
            use_gateway=True,
        )

    async def mark_verified(
        self, *, id: str, purpose: str, detail: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Mark an item as verified after a successful use; resets failure_count."""
        body: Dict[str, Any] = {"id": id, "purpose": purpose}
        if detail is not None:
            body["detail"] = detail
        result = await self._client._request(
            endpoint="/svc/stash/items/mark-verified",
            body=body,
            use_gateway=True,
        )
        return result.get("item") if isinstance(result, dict) else None

    async def mark_failed(
        self,
        *,
        id: str,
        purpose: str,
        failure_reason: Optional[str] = None,
        detail: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Mark an item as failed; increments failure_count, sets last_failed_at."""
        body: Dict[str, Any] = {"id": id, "purpose": purpose}
        if failure_reason is not None:
            body["failure_reason"] = failure_reason
        if detail is not None:
            body["detail"] = detail
        result = await self._client._request(
            endpoint="/svc/stash/items/mark-failed",
            body=body,
            use_gateway=True,
        )
        return result.get("item") if isinstance(result, dict) else None

    async def delete(self, id: str, *, purpose: Optional[str] = None) -> bool:
        """Soft-delete an item (sets deleted_at)."""
        body: Dict[str, Any] = {"id": id}
        if purpose is not None:
            body["purpose"] = purpose
        result = await self._client._request(
            endpoint="/svc/stash/items/delete",
            body=body,
            use_gateway=True,
        )
        return bool(result.get("deleted")) if isinstance(result, dict) else False

    async def register_kind(
        self,
        *,
        kind: str,
        is_sensitive: Optional[bool] = None,
        value_schema: Optional[Dict[str, Any]] = None,
        default_rotation_days: Optional[int] = None,
        verification_probe_ref: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Register or update a kind in stash.kind_registry. Admin-scoped."""
        body: Dict[str, Any] = {"kind": kind}
        if is_sensitive is not None:
            body["is_sensitive"] = is_sensitive
        if value_schema is not None:
            body["value_schema"] = value_schema
        if default_rotation_days is not None:
            body["default_rotation_days"] = default_rotation_days
        if verification_probe_ref is not None:
            body["verification_probe_ref"] = verification_probe_ref
        if description is not None:
            body["description"] = description
        result = await self._client._request(
            endpoint="/svc/stash/kinds/register",
            body=body,
            use_gateway=True,
        )
        return result.get("kind", {}) if isinstance(result, dict) else {}

    async def list_kinds(self) -> List[Dict[str, Any]]:
        """List registered kinds (own + shared merged)."""
        result = await self._client._request(
            endpoint="/svc/stash/kinds/list",
            body={},
            use_gateway=True,
        )
        return result.get("kinds", []) if isinstance(result, dict) else []

    async def query_audit(
        self,
        *,
        item_id: Optional[str] = None,
        kind: Optional[str] = None,
        caller_id: Optional[str] = None,
        action: Optional[str] = None,
        occurred_after: Optional[str] = None,
        occurred_before: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Query the append-only audit log. Hashes only — never plaintext."""
        body: Dict[str, Any] = {}
        if item_id is not None:
            body["item_id"] = item_id
        if kind is not None:
            body["kind"] = kind
        if caller_id is not None:
            body["caller_id"] = caller_id
        if action is not None:
            body["action"] = action
        if occurred_after is not None:
            body["occurred_after"] = occurred_after
        if occurred_before is not None:
            body["occurred_before"] = occurred_before
        if limit is not None:
            body["limit"] = limit
        if offset is not None:
            body["offset"] = offset
        return await self._client._request(
            endpoint="/svc/stash/audit/query",
            body=body,
            use_gateway=True,
        )
