"""Platform namespace.

Thin JSON-first helpers for the dominus-platform-worker Gateway surface.
Platform owns group/repository policy decisions; it does not execute coder work
or expose credentials.
"""
from __future__ import annotations

from typing import Any, Dict, Optional, TYPE_CHECKING
from urllib.parse import quote

if TYPE_CHECKING:
    from ..start import Dominus


def _normalize_platform_path(path: str) -> str:
    trimmed = path.strip()
    normalized = trimmed if trimmed.startswith("/") else f"/{trimmed}"
    if normalized == "/svc/platform" or normalized.startswith("/svc/platform/"):
        return normalized
    if normalized == "/api/platform" or normalized.startswith("/api/platform/"):
        return normalized.replace("/api/", "/svc/", 1)
    return f"/svc/platform{normalized}"


def _actor_headers(actor_context: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
    if not actor_context:
        return None
    actor_type = str(actor_context.get("type") or actor_context.get("actor_type") or "").strip()
    actor_id = str(actor_context.get("id") or actor_context.get("actor_id") or "").strip()
    if not actor_type or not actor_id:
        return None
    return {"X-Actor-Type": actor_type, "X-Actor-Id": actor_id}


class PlatformNamespace:
    """Platform group/repository policy helpers."""

    def __init__(self, client: "Dominus"):
        self._client = client

    async def request(
        self,
        path: str,
        *,
        method: str = "GET",
        body: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
    ) -> Any:
        return await self._client.gateway_fetch(
            _normalize_platform_path(path),
            method=method,
            body=body,
            headers=headers,
            timeout=timeout,
        )

    async def health(self) -> Dict[str, Any]:
        return await self.request("/health", method="GET")

    async def ready(self) -> Dict[str, Any]:
        return await self.request("/ready", method="GET")

    async def list_groups(self) -> Dict[str, Any]:
        return await self.request("/groups", method="GET")

    async def get_group(self, group_slug: str) -> Dict[str, Any]:
        return await self.request(f"/groups/{quote(group_slug, safe='')}", method="GET")

    async def upsert_group(self, group: Dict[str, Any]) -> Dict[str, Any]:
        return await self.request("/groups", method="POST", body=group)

    async def update_group(self, group_slug: str, group: Dict[str, Any]) -> Dict[str, Any]:
        return await self.request(
            f"/groups/{quote(group_slug, safe='')}",
            method="PATCH",
            body=group,
        )

    async def add_group_member(self, group_slug: str, subject_id: str) -> Dict[str, Any]:
        return await self.request(
            f"/groups/{quote(group_slug, safe='')}/members",
            method="POST",
            body={"subject_id": subject_id},
        )

    async def link_group_repository(self, group_slug: str, repository: str) -> Dict[str, Any]:
        return await self.request(
            f"/groups/{quote(group_slug, safe='')}/repositories",
            method="POST",
            body={"repository": repository},
        )

    async def list_repositories(self) -> Dict[str, Any]:
        return await self.request("/repositories", method="GET")

    async def get_repository(self, repository_id: str) -> Dict[str, Any]:
        return await self.request(
            f"/repositories/{quote(repository_id, safe='')}",
            method="GET",
        )

    async def upsert_repository(self, repository: Dict[str, Any]) -> Dict[str, Any]:
        return await self.request("/repositories", method="POST", body=repository)

    async def update_repository(
        self,
        repository_id: str,
        repository: Dict[str, Any],
    ) -> Dict[str, Any]:
        return await self.request(
            f"/repositories/{quote(repository_id, safe='')}",
            method="PATCH",
            body=repository,
        )

    async def ensure_policy_decision(
        self,
        options: Dict[str, Any],
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            "/policy/decisions/ensure",
            method="POST",
            body=options,
            headers=_actor_headers(actor_context),
        )

    async def get_policy_decision(
        self,
        decision_id: str,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/policy/decisions/{quote(decision_id, safe='')}",
            method="GET",
            headers=_actor_headers(actor_context),
        )

    async def rehydrate_policy_decision(
        self,
        decision_id: str,
        options: Optional[Dict[str, Any]] = None,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/policy/decisions/{quote(decision_id, safe='')}/rehydrate",
            method="POST",
            body=options or {},
            headers=_actor_headers(actor_context),
        )
