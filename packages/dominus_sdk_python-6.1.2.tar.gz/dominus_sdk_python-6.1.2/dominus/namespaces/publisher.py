"""Publisher namespace.

Build-artifact lifecycle, signing, release records, channel pins, and resolver
reads for dominus-publisher. This surface intentionally does not expose raw
runner credentials or direct byte upload shortcuts.
"""
from __future__ import annotations

from typing import Any, Dict, Optional, TYPE_CHECKING
from urllib.parse import quote, urlencode

if TYPE_CHECKING:
    from ..start import Dominus


def _compact(payload: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for key, value in payload.items():
        if value is None:
            continue
        if isinstance(value, str) and value.strip() == "":
            continue
        out[key] = value
    return out


def _query_string(params: Dict[str, Any]) -> str:
    cleaned = _compact(params)
    return f"?{urlencode(cleaned)}" if cleaned else ""


def _normalize_publisher_path(path: str) -> str:
    trimmed = path.strip()
    normalized = trimmed if trimmed.startswith("/") else f"/{trimmed}"
    if normalized == "/svc/publisher" or normalized.startswith("/svc/publisher/"):
        return normalized
    if normalized == "/api/publisher" or normalized.startswith("/api/publisher/"):
        return normalized.replace("/api/", "/svc/", 1)
    return f"/svc/publisher{normalized}"


def _actor_headers(actor_context: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
    if not actor_context:
        return None
    actor_type = str(actor_context.get("type") or actor_context.get("actor_type") or "").strip()
    actor_id = str(actor_context.get("id") or actor_context.get("actor_id") or "").strip()
    if not actor_type or not actor_id:
        return None
    return {"X-Actor-Type": actor_type, "X-Actor-Id": actor_id}


def _mutation_body(
    *,
    reason: Optional[str] = None,
    idempotency_key: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return _compact(
        {
            "reason": reason,
            "idempotency_key": idempotency_key,
            "metadata": metadata,
        }
    )


class PublisherNamespace:
    """Publisher build-artifact lifecycle helpers."""

    def __init__(self, client: "Dominus"):
        self._client = client

    async def request(
        self,
        path: str,
        *,
        method: str = "GET",
        body: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
    ) -> Any:
        return await self._client.gateway_fetch(
            _normalize_publisher_path(path),
            method=method,
            body=body,
            headers=headers,
            timeout=timeout,
        )

    async def health(self) -> Dict[str, Any]:
        return await self.request("/health", method="GET")

    async def ready(self) -> Dict[str, Any]:
        return await self.request("/ready", method="GET")

    async def list_builds(
        self,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request("/builds", method="GET", headers=_actor_headers(actor_context))

    async def ensure_build(
        self,
        payload: Dict[str, Any],
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            "/builds/ensure",
            method="POST",
            body=payload,
            headers=_actor_headers(actor_context),
            timeout=600.0,
        )

    async def get_build(
        self,
        build_id: str,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/builds/{quote(build_id, safe='')}",
            method="GET",
            headers=_actor_headers(actor_context),
        )

    async def retry_build(
        self,
        build_id: str,
        *,
        reason: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/builds/{quote(build_id, safe='')}/retry",
            method="POST",
            body=_mutation_body(reason=reason, idempotency_key=idempotency_key, metadata=metadata),
            headers=_actor_headers(actor_context),
        )

    async def cancel_build(
        self,
        build_id: str,
        *,
        reason: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/builds/{quote(build_id, safe='')}/cancel",
            method="POST",
            body=_mutation_body(reason=reason, idempotency_key=idempotency_key, metadata=metadata),
            headers=_actor_headers(actor_context),
        )

    async def evaluate_signing(
        self,
        payload: Dict[str, Any],
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            "/builds/signing/evaluate",
            method="POST",
            body=payload,
            headers=_actor_headers(actor_context),
        )

    async def record_signing_evidence(
        self,
        payload: Dict[str, Any],
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            "/builds/signing/evidence",
            method="POST",
            body=payload,
            headers=_actor_headers(actor_context),
        )

    async def list_artifacts(
        self,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request("/artifacts", method="GET", headers=_actor_headers(actor_context))

    async def record_release(
        self,
        payload: Dict[str, Any],
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            "/artifacts/releases/record",
            method="POST",
            body=payload,
            headers=_actor_headers(actor_context),
            timeout=600.0,
        )

    async def resolve_artifact(
        self,
        artifact_key: str,
        *,
        selector: Optional[str] = None,
        environment: Optional[str] = None,
        target_app: Optional[str] = None,
        architecture: Optional[str] = None,
        runtime_family: Optional[str] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        qs = _query_string(
            {
                "selector": selector,
                "environment": environment,
                "target_app": target_app,
                "architecture": architecture,
                "runtime_family": runtime_family,
            }
        )
        return await self.request(
            f"/artifacts/{quote(artifact_key, safe='')}{qs}",
            method="GET",
            headers=_actor_headers(actor_context),
        )

    async def list_channels(
        self,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request("/channels", method="GET", headers=_actor_headers(actor_context))

    async def get_channel(
        self,
        artifact_key: str,
        selector: str,
        *,
        environment: Optional[str] = None,
        target_app: Optional[str] = None,
        architecture: Optional[str] = None,
        runtime_family: Optional[str] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        qs = _query_string(
            {
                "environment": environment,
                "target_app": target_app,
                "architecture": architecture,
                "runtime_family": runtime_family,
            }
        )
        return await self.request(
            f"/channels/{quote(artifact_key, safe='')}/{quote(selector, safe='')}{qs}",
            method="GET",
            headers=_actor_headers(actor_context),
        )

    async def pin_channel(
        self,
        artifact_key: str,
        selector: str,
        payload: Dict[str, Any],
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            f"/channels/{quote(artifact_key, safe='')}/{quote(selector, safe='')}/pin",
            method="POST",
            body=payload,
            headers=_actor_headers(actor_context),
        )

    async def list_prestage(
        self,
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request("/prestage", method="GET", headers=_actor_headers(actor_context))

    async def ensure_prestage(
        self,
        payload: Dict[str, Any],
        *,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        return await self.request(
            "/prestage/ensure",
            method="POST",
            body=payload,
            headers=_actor_headers(actor_context),
            timeout=600.0,
        )
