"""
Browser Namespace - first-class Dominus browser automation primitive.

All methods route through gateway (``/api/browser/*`` -> ``/svc/browser/*``).
Worker-local routes remain ``/health`` and ``/runs/*``; application code should
use this namespace instead of constructing worker-local paths directly.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping, Optional, TYPE_CHECKING
from urllib.parse import quote

if TYPE_CHECKING:
    from ..start import Dominus


def _compact(payload: Mapping[str, Any]) -> Dict[str, Any]:
    """Drop None and empty-string values."""
    out: Dict[str, Any] = {}
    for key, value in payload.items():
        if value is None:
            continue
        if isinstance(value, str) and value == "":
            continue
        out[key] = value
    return out


class BrowserNamespace:
    """
    Browser automation namespace.

    Usage::

        health = await dominus.browser.get_health()
        run = await dominus.browser.ensure_run(
            target={"url": "https://example.com/dashboard"},
            assertions=[{"kind": "status_code", "expected": 200}],
        )
        await dominus.browser.start_run(run["run_id"])
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def _post(
        self,
        endpoint: str,
        body: Optional[Dict[str, Any]] = None,
        *,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=endpoint,
            method="POST",
            body=body or {},
            use_gateway=True,
            timeout=timeout,
        )

    async def _get(self, endpoint: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=endpoint,
            method="GET",
            use_gateway=True,
            timeout=timeout,
        )

    async def get_health(self, *, timeout: float = 15.0) -> Dict[str, Any]:
        """Authenticated browser worker health. ``GET /api/browser/health``."""
        return await self._get("/api/browser/health", timeout=timeout)

    async def health(self, *, timeout: float = 15.0) -> Dict[str, Any]:
        """Alias for :meth:`get_health`."""
        return await self.get_health(timeout=timeout)

    async def ensure_run(
        self,
        *,
        target: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        run_kind: Optional[str] = None,
        route_label: Optional[str] = None,
        route_policy_ref: Optional[str] = None,
        provider: Optional[str] = None,
        mode: Optional[str] = None,
        auth_ref: Optional[Dict[str, Any]] = None,
        capture_policy: Optional[Dict[str, Any]] = None,
        assertions: Optional[list[Dict[str, Any]]] = None,
        authority: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        org_id: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        recipe_ref: Optional[str] = None,
        recipe: Optional[Any] = None,
        recipe_inputs: Optional[Dict[str, Any]] = None,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """
        Ensure a browser run. ``POST /api/browser/runs/ensure``.

        ``target`` shorthand, ``recipe_ref``, or inline ``recipe`` must be
        present. When ``recipe_ref`` is set, the worker resolves the
        recipe through the recipe-worker, parses it, resolves variables, and
        runs it through the recipe executor — supporting multi-step flows
        including clicks, fills, assertions, extracts, and stash-backed
        credential fills.

        ``recipe`` may be an inline YAML string or JSON object for one-off
        runs. Stable/shared recipes should be published and referenced via
        ``recipe_ref``. Target/assertion shorthand runs are synthesized into a
        ``browser-recipe-v1`` recipe internally; there is no separate runner path.

        ``recipe_inputs`` supplies scalar values consumed by ``recipe-input://``
        variable refs declared in the recipe's vars map.

        Browser run metadata remains browser-worker runtime state. Artifact V2
        is used for sanitized `browser-run` result payloads and, when opted-in
        via ``capture_policy["storage_state"] = "always"`` plus
        ``auth_ref["session_slot_id"]``, for captured Playwright storage_state
        in the separate ``browser-session`` category. Captured values are
        never returned inline; only the artifact ref appears on the result
        envelope as ``result_summary.captured_session_artifact_ref``.

        Reuse a captured session by passing the same ``session_slot_id`` (slot
        lookup, returns no storage_state on first call) or an explicit
        ``session_artifact_ref`` (hard-error if the ref does not exist).
        """
        if not target and not recipe_ref and recipe is None:
            raise ValueError("target, recipe_ref, or recipe is required")
        body = _compact({
            "idempotency_key": idempotency_key,
            "run_kind": run_kind,
            "route_label": route_label,
            "route_policy_ref": route_policy_ref,
            "target": target,
            "provider": provider,
            "mode": mode,
            "auth_ref": auth_ref,
            "capture_policy": capture_policy,
            "assertions": assertions,
            "authority": authority,
            "metadata": metadata,
            "org_id": org_id,
            "app_slug": app_slug,
            "env": env,
            "recipe_ref": recipe_ref,
            "recipe": recipe,
            "recipe_inputs": recipe_inputs,
        })
        return await self._post("/api/browser/runs/ensure", body, timeout=timeout)

    async def start_run(self, run_id: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        """Start a queued browser run. ``POST /api/browser/runs/{run_id}/start``."""
        if not run_id:
            raise ValueError("run_id is required")
        return await self._post(
            f"/api/browser/runs/{quote(run_id, safe='')}/start",
            {},
            timeout=timeout,
        )

    async def get_run_status(self, run_id: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        """Read browser run runtime state. ``GET /api/browser/runs/{run_id}/status``."""
        if not run_id:
            raise ValueError("run_id is required")
        return await self._get(
            f"/api/browser/runs/{quote(run_id, safe='')}/status",
            timeout=timeout,
        )

    async def get_run_result(self, run_id: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        """Read browser run result availability. ``GET /api/browser/runs/{run_id}/result``."""
        if not run_id:
            raise ValueError("run_id is required")
        return await self._get(
            f"/api/browser/runs/{quote(run_id, safe='')}/result",
            timeout=timeout,
        )

    async def retry_run(self, run_id: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        """Retry a failed or expired browser run. ``POST /api/browser/runs/{run_id}/retry``."""
        if not run_id:
            raise ValueError("run_id is required")
        return await self._post(
            f"/api/browser/runs/{quote(run_id, safe='')}/retry",
            {},
            timeout=timeout,
        )

    async def nudge_run(self, run_id: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        """Nudge a paused or waiting browser run. ``POST /api/browser/runs/{run_id}/nudge``."""
        if not run_id:
            raise ValueError("run_id is required")
        return await self._post(
            f"/api/browser/runs/{quote(run_id, safe='')}/nudge",
            {},
            timeout=timeout,
        )

    async def cancel_run(self, run_id: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        """Cancel a non-terminal browser run. ``POST /api/browser/runs/{run_id}/cancel``."""
        if not run_id:
            raise ValueError("run_id is required")
        return await self._post(
            f"/api/browser/runs/{quote(run_id, safe='')}/cancel",
            {},
            timeout=timeout,
        )

    async def get_run_timeline(self, run_id: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        """Read browser run timeline. ``GET /api/browser/runs/{run_id}/timeline``."""
        if not run_id:
            raise ValueError("run_id is required")
        return await self._get(
            f"/api/browser/runs/{quote(run_id, safe='')}/timeline",
            timeout=timeout,
        )

    async def get_run_dossier(self, run_id: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        """Read browser run dossier. ``GET /api/browser/runs/{run_id}/dossier``."""
        if not run_id:
            raise ValueError("run_id is required")
        return await self._get(
            f"/api/browser/runs/{quote(run_id, safe='')}/dossier",
            timeout=timeout,
        )
