"""LEGEND Data Objects (LGDO) types."""

from __future__ import annotations

from .array import Array
from .arrayofdetectorids import ArrayOfDetectorIDs
from .arrayofequalsizedarrays import ArrayOfEqualSizedArrays
from .encoded import ArrayOfEncodedEqualSizedArrays, VectorOfEncodedVectors
from .fixedsizearray import FixedSizeArray
from .histogram import Histogram
from .lgdo import LGDO, LGDOCollection
from .scalar import Scalar
from .struct import Struct
from .table import Table
from .vectorofvectors import VectorOfVectors
from .waveformtable import WaveformTable

__all__ = [
    "LGDO",
    "Array",
    "ArrayOfDetectorIDs",
    "ArrayOfEncodedEqualSizedArrays",
    "ArrayOfEqualSizedArrays",
    "FixedSizeArray",
    "Histogram",
    "LGDOCollection",
    "Scalar",
    "Struct",
    "Table",
    "VectorOfEncodedVectors",
    "VectorOfVectors",
    "WaveformTable",
]

import numpy as np

np.set_printoptions(threshold=10)
