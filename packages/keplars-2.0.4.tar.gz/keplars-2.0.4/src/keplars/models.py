from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator

EmailPriority = Literal["instant", "high", "async", "bulk"]
ErrorCode = Literal[
    "VALIDATION_ERROR",
    "AUTHENTICATION_ERROR",
    "AUTHORIZATION_ERROR",
    "DOMAIN_NOT_VERIFIED",
    "RATE_LIMIT_EXCEEDED",
    "NOT_FOUND",
    "PLAN_LIMIT_EXCEEDED",
    "QUOTA_EXCEEDED",
    "CONFLICT",
    "INTERNAL_ERROR",
]


class KeplarsConfig(BaseModel):
    api_key: str
    base_url: str = "https://api.keplars.com"
    timeout: float = 30.0
    max_retries: int = 3
    retry_delay: float = 1.0

    @field_validator("api_key")
    @classmethod
    def validate_api_key(cls, v: str) -> str:
        import re

        if not re.match(r"^kms_[a-f0-9]+\.(live|adm)_[a-f0-9]+$", v):
            raise ValueError(
                "Invalid API key format. Expected: kms_<id>.live_<secret> or kms_<id>.adm_<secret>"
            )
        return v


class EmailRecipient(BaseModel):
    email: EmailStr
    name: Optional[str] = None


class SendEmailRequest(BaseModel):
    to: Union[EmailStr, List[str]]
    from_email: EmailStr = Field(..., alias="from")
    from_name: Optional[str] = None
    subject: str = Field(..., min_length=1, max_length=998)
    body: Optional[str] = Field(None, max_length=524288)
    is_html: Optional[bool] = None
    cc: Optional[List[str]] = None
    bcc: Optional[List[str]] = None
    template_id: Optional[str] = None
    params: Optional[Dict[str, Any]] = None

    @model_validator(mode="after")
    def validate_content(self) -> "SendEmailRequest":
        has_content = self.body
        has_template = self.template_id

        if not has_content and not has_template:
            raise ValueError("Either body or template_id is required")

        if has_content and has_template:
            raise ValueError("Cannot use both body and template_id")

        return self

    model_config = {"populate_by_name": True}


class EmailMetadata(BaseModel):
    priority: Optional[str] = None
    estimated_delivery: Optional[str] = None
    recipients_count: Optional[int] = None

    model_config = {"extra": "allow"}


class SendEmailResponse(BaseModel):
    id: str
    object: Optional[str] = None
    status: Optional[str] = None
    from_email: Optional[EmailStr] = Field(None, alias="from")
    to: Optional[List[str]] = None
    subject: Optional[str] = None
    created_at: Optional[str] = None
    metadata: Optional[EmailMetadata] = None

    model_config = {"populate_by_name": True, "extra": "allow"}


class ScheduleEmailRequest(SendEmailRequest):
    scheduled_for: str
    timezone: Optional[str] = None
    priority: Optional[EmailPriority] = "async"


ScheduledEmailResponse = SendEmailResponse


class Contact(BaseModel):
    id: Optional[str] = None
    email: str
    name: Optional[str] = None
    audience_id: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    model_config = {"extra": "allow"}


class Audience(BaseModel):
    id: Optional[str] = None
    name: str
    description: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class Automation(BaseModel):
    id: Optional[str] = None
    name: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[str] = None

    model_config = {"extra": "allow"}


class DomainListItem(BaseModel):
    id: Optional[str] = None
    domain: str
    verified: Optional[bool] = None
    created_at: Optional[str] = None


class PaginatedMeta(BaseModel):
    page: Optional[int] = None
    limit: Optional[int] = None
    total: Optional[int] = None

    model_config = {"extra": "allow"}


class ErrorDetail(BaseModel):
    field: Optional[str] = None
    message: str
    value: Optional[Any] = None


class KeplarsErrorResponse(BaseModel):
    success: Optional[bool] = None
    error: Optional[str] = None
    message: Optional[str] = None

    model_config = {"extra": "allow"}


class RateLimitInfo(BaseModel):
    limit: int
    remaining: int
    reset: int
