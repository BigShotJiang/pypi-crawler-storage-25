import cpm.brainexplorer as be
import pandas as pd

data = pd.read_csv("tmp/SpaceObserver-raw-hash.csv")

x = be.perceptual_decision_making.SpaceObserver("tmp/SpaceObserver-raw-hash.csv")
x.metrics()

x.data_processed[x.data_processed["run"] > 1].head()
