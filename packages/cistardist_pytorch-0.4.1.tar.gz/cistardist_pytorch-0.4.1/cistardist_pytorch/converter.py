from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import h5py
import numpy as np
import torch

from .config import StarDist2DConfig, load_thresholds
from .net import StarDist2DNet


def _decode_h5_attr(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return str(value)


def list_h5_layers(h5_path: str | Path) -> list[str]:
    with h5py.File(h5_path, "r") as h5:
        names = h5.attrs.get("layer_names")
        if names is not None:
            return [_decode_h5_attr(name) for name in names]
        return list(h5.keys())


def _find_dataset(group: h5py.Group, suffix: str) -> np.ndarray:
    matches: list[h5py.Dataset] = []

    def visitor(_name: str, obj: h5py.Dataset) -> None:
        if isinstance(obj, h5py.Dataset) and _name.endswith(suffix):
            matches.append(obj)

    group.visititems(visitor)
    if len(matches) != 1:
        raise KeyError(f"Expected one dataset ending with {suffix!r}, found {len(matches)}.")
    return np.asarray(matches[0])


def _load_keras_conv(h5: h5py.File, layer_name: str) -> tuple[np.ndarray, np.ndarray]:
    if layer_name not in h5:
        raise KeyError(f"Layer {layer_name!r} is missing from the H5 file.")
    group = h5[layer_name]
    return _find_dataset(group, "kernel:0"), _find_dataset(group, "bias:0")


def _remap_conv2d_name(name: str, offset: int) -> str:
    """Apply an index offset to a conv2d_N layer name.

    Keras names the first global conv2d as 'conv2d' (no suffix), then 'conv2d_1', etc.
    When the model was saved in a fresh Keras session offset is 0 and names start at
    'conv2d_1'.  Older/different models start at 'conv2d' (offset -1 relative to the
    net names which always begin at index 1).
    """
    m = re.match(r"^conv2d_(\d+)$", name)
    if not m:
        return name
    n = int(m.group(1)) + offset
    return "conv2d" if n == 0 else f"conv2d_{n}"


def _detect_conv2d_offset(available: set[str], net_layer_names: list[str]) -> int:
    """Return the index offset to apply to conv2d_N net names to match H5 names.

    Returns 0 (no change) or -1 (H5 uses 0-based Keras numbering).
    """
    stem = [n for n in net_layer_names if re.match(r"^conv2d_\d+$", n)]
    if not stem:
        return 0
    if all(n in available for n in stem):
        return 0
    if all(_remap_conv2d_name(n, -1) in available for n in stem):
        return -1
    return 0


def convert_h5_to_state_dict(h5_path: str | Path, config: StarDist2DConfig) -> tuple[dict[str, torch.Tensor], dict[str, Any]]:
    net = StarDist2DNet(config)
    state = net.state_dict()
    consumed: list[str] = []

    with h5py.File(h5_path, "r") as h5:
        available = set(list_h5_layers(h5_path))
        offset = _detect_conv2d_offset(available, net.keras_layer_names)
        missing = [
            _remap_conv2d_name(name, offset)
            for name in net.keras_layer_names
            if _remap_conv2d_name(name, offset) not in available
        ]
        if missing:
            raise KeyError(f"The H5 file is missing expected StarDist layers: {missing}")

        for layer_name in net.keras_layer_names:
            h5_layer_name = _remap_conv2d_name(layer_name, offset)
            kernel, bias = _load_keras_conv(h5, h5_layer_name)
            weight_key = f"layers.{layer_name}.weight"
            bias_key = f"layers.{layer_name}.bias"

            if kernel.ndim != 4:
                raise ValueError(f"{layer_name}: expected Conv2D kernel with 4 dims, got {kernel.shape}.")
            torch_kernel = np.transpose(kernel, (3, 2, 0, 1))
            if tuple(torch_kernel.shape) != tuple(state[weight_key].shape):
                raise ValueError(
                    f"{layer_name}: converted kernel shape {torch_kernel.shape} "
                    f"does not match PyTorch shape {tuple(state[weight_key].shape)}."
                )
            if tuple(bias.shape) != tuple(state[bias_key].shape):
                raise ValueError(
                    f"{layer_name}: bias shape {bias.shape} does not match "
                    f"PyTorch shape {tuple(state[bias_key].shape)}."
                )

            state[weight_key] = torch.from_numpy(np.ascontiguousarray(torch_kernel)).to(dtype=state[weight_key].dtype)
            state[bias_key] = torch.from_numpy(np.ascontiguousarray(bias)).to(dtype=state[bias_key].dtype)
            consumed.append(layer_name)

    report = {
        "source": str(h5_path),
        "converted_layers": consumed,
        "n_layers": len(consumed),
    }
    return state, report


def convert_model_folder(
    model_dir: str | Path,
    weights_name: str | None = None,
    output_name: str | None = None,
) -> tuple[Path, dict[str, Any]]:
    model_dir = Path(model_dir)
    config_path = model_dir / "config.json"
    if not config_path.exists():
        raise FileNotFoundError(f"Missing config.json in {model_dir}. V1 cannot convert model folders without config.json.")

    config = StarDist2DConfig.from_json(config_path)
    weights_name = weights_name or config.train_checkpoint
    h5_path = model_dir / weights_name
    if not h5_path.exists():
        raise FileNotFoundError(f"Missing Keras weights file: {h5_path}")

    output_name = output_name or f"{model_dir.name}.pt"
    output_path = model_dir / output_name
    thresholds = load_thresholds(model_dir / "thresholds.json")
    state_dict, report = convert_h5_to_state_dict(h5_path, config)
    checkpoint = {
        "state_dict": state_dict,
        "conversion": report,
    }
    torch.save(checkpoint, output_path)

    # Also write config.json and thresholds.json next to the .pt so the whole
    # output folder can be uploaded to Zenodo as a complete, self-describing record.
    out_config = output_path.parent / "config.json"
    if not out_config.exists():
        with out_config.open("w", encoding="utf-8") as fh:
            import json as _json
            _json.dump(config.as_dict(), fh, indent=2)

    out_thresh = output_path.parent / "thresholds.json"
    if not out_thresh.exists():
        with out_thresh.open("w", encoding="utf-8") as fh:
            import json as _json
            _json.dump(thresholds, fh, indent=2)

    return output_path, report
