"""Prompt contract assembly for Aegis canonical identity and user state."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .governance import (
    aegis_text,
    build_companion_identity_state,
    clone_text,
    parse_user_profile_content,
    render_user_profile_text,
    user_profile_text,
)
from .loader import LoadedProfile

PromptMode = Literal["full", "minimal"]

_USER_FIELD_LABELS = (
    "Preferred name",
    "Current work",
    "School",
    "Current city",
    "MBTI",
    "Dream",
    "Creative hobby",
    "Media hobby",
    "Movement hobby",
    "Boundaries",
)


@dataclass(frozen=True, slots=True)
class PromptContract:
    prompt_mode: PromptMode
    section_names: tuple[str, ...]
    instruction_refs: tuple[str, ...]
    stable_prefix_refs: tuple[str, ...] = ()
    profile_snapshot_refs: tuple[str, ...] = ()


def build_identity_capsule_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    capsule = (
        f"You are {identity.display_name}, a named Aegis clone on one long-lived continuity line. "
        f"Carry this clone as {identity.personality_summary} "
        f"Use a {identity.initiative} initiative style and keep the relational stance as {identity.relational_stance}. "
        "Stay warm where appropriate, direct when useful, and bounded: never fake memory, certainty, capability, intimacy, or identity."
    )
    lines = [
        "section:identity-capsule",
        f"identity-display-name={identity.display_name}",
        f"aegis-charter={_single_line(aegis_text(profile))}",
        f"identity-capsule={capsule}",
    ]
    if prompt_mode == "full":
        lines.append(f"identity-charter-extension={_single_line(clone_text(profile))}")
    return tuple(lines)


def build_continuity_contract_section(profile: LoadedProfile) -> tuple[str, ...]:
    del profile
    return (
        "section:continuity-contract",
        "continuity-1=Preserve the thread instead of acting like a disposable chat.",
        "continuity-2=Recover relevant context from the provided state before asking the user to repeat themselves.",
        "continuity-3=Never fake memory, certainty, capability, intimacy, or identity.",
        "continuity-4=Use canonical identity, user, relationship, work, and evidence state as durable truth; treat prompt text as a projection.",
        "continuity-5=Ask minimally and only for the next detail that materially helps the current task or durable continuity.",
    )


def build_state_write_policy_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    lines = [
        "section:state-write-policy",
        "state-write-policy=When state, memory, profile, relationship, or work-write tools are available, use them to preserve concrete durable changes; otherwise state the durable update clearly without pretending it was stored.",
        "state-scope=Keep shared user state limited to stable facts, preferences, boundaries, and recurring work context; do not store transient tasks, one-off asks, generic chatter, or completed-work logs as user facts.",
        "state-update-trigger=When the user shares or corrects durable identity, preferences, boundaries, recurring work, voice, stance, initiative, or collaboration rhythm, preserve that delta through the governed state path.",
        "state-read-before-ask=If the user asks what you already know, answer from current identity, user, relationship, and work state first; only write when the turn adds or corrects durable facts.",
        "state-onboarding=Do not run a formal onboarding ritual; if no durable goal exists yet, naturally help the user name one foundational ongoing thread once it is relevant.",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"governance={identity.governance_summary}",
                "grounding-policy=durable user and relationship context should deepen through normal conversation, not a file-first onboarding gate.",
            )
        )
    return tuple(lines)


def build_identity_kernel(profile: LoadedProfile) -> tuple[str, ...]:
    return build_identity_capsule_section(profile)


def build_aegis_section(profile: LoadedProfile) -> tuple[str, ...]:
    return build_continuity_contract_section(profile)


def build_identity_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    return build_identity_capsule_section(profile, prompt_mode=prompt_mode)


def build_user_snapshot_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    parsed_profile = parse_user_profile_content(user_profile_text(profile))
    known_fields = dict(parsed_profile.field_values)
    durable_notes = parsed_profile.durable_notes
    structured_summary = render_user_profile_text(**known_fields)
    note_summary = _durable_note_summary(durable_notes)
    summary_parts = [structured_summary] if structured_summary else []
    if note_summary:
        summary_parts.append(f"Durable notes: {note_summary}")
    lines = [
        "section:user-snapshot",
        f"user-known-fields={', '.join(known_fields.keys()) or 'none'}",
        f"user-summary={' | '.join(summary_parts) or 'No durable user profile facts are set yet.'}",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"active-display-name={identity.display_name}",
                f"mode={identity.mode}",
                f"continuity-notes={', '.join(identity.continuity_notes) or 'none'}",
                f"user-canonical-fields={', '.join(_USER_FIELD_LABELS)}",
                f"user-open-facts={note_summary or 'none'}",
                f"user-open-facts-count={len(durable_notes)}",
            )
        )
    return tuple(lines)


def build_personality_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    return build_identity_section(profile, prompt_mode=prompt_mode)


def build_runtime_contract_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    return build_state_write_policy_section(profile, prompt_mode=prompt_mode)


def build_prompt_contract(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> PromptContract:
    stable_sections: list[tuple[str, tuple[str, ...]]] = [
        ("identity-capsule", build_identity_capsule_section(profile, prompt_mode=prompt_mode)),
        ("continuity-contract", build_continuity_contract_section(profile)),
        ("state-write-policy", build_state_write_policy_section(profile, prompt_mode=prompt_mode)),
    ]
    profile_snapshot_sections: list[tuple[str, tuple[str, ...]]] = [
        ("user-snapshot", build_user_snapshot_section(profile, prompt_mode=prompt_mode)),
    ]
    sections = [*stable_sections, *profile_snapshot_sections]
    stable_prefix_refs = tuple(line for _, lines in stable_sections for line in lines)
    profile_snapshot_refs = tuple(line for _, lines in profile_snapshot_sections for line in lines)
    instruction_refs = tuple((*stable_prefix_refs, *profile_snapshot_refs))
    return PromptContract(
        prompt_mode=prompt_mode,
        section_names=tuple(name for name, _ in sections),
        instruction_refs=instruction_refs,
        stable_prefix_refs=stable_prefix_refs,
        profile_snapshot_refs=profile_snapshot_refs,
    )


def _durable_note_summary(notes: tuple[str, ...], *, limit: int = 3) -> str:
    if not notes:
        return ""
    shown = notes[:limit]
    remainder = len(notes) - len(shown)
    summary = " | ".join(shown)
    if remainder > 0:
        summary += f" | +{remainder} more"
    return summary


def _single_line(value: str) -> str:
    return " ".join(str(value).split())
