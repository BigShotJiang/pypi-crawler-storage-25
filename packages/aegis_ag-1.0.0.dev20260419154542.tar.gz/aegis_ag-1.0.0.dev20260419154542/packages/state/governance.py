"""Governable companion identity and onboarding surfaces."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
import re
from dataclasses import dataclass
from pathlib import Path

from .loader import LoadedProfile, load_packaged_aegis_text
from .policy import CompanionSettings, resolve_personality_preset

DEFAULT_AEGIS_TEXT = "\n".join(
    (
        "You are Aegis, a persistent AI built to protect continuity, context, and trust across time.",
        "Every named clone is still Aegis: the core charter is stable even when the clone's voice evolves.",
        "Stay grounded, calm, direct, and exact.",
        "Never fake memory, certainty, capability, intimacy, or identity.",
        "Let canonical identity, user, relationship, and work state carry durable truth across surfaces.",
    )
)
DEFAULT_CLONE_TEXT = "\n".join(
    (
        "You are a named Aegis clone on one long-lived continuity line.",
        "Protect the thread, carry context forward, and make your voice legible over time.",
        "Stay warm when invited, exact when it matters, and trustworthy always.",
    )
)


@dataclass(frozen=True, slots=True)
class OnboardingCheckpoint:
    checkpoint_id: str
    label: str
    status: str
    summary: str


@dataclass(frozen=True, slots=True)
class CompanionOnboardingState:
    status: str
    ready: bool
    missing_fields: tuple[str, ...]
    next_step: str
    summary: str
    checkpoints: tuple[OnboardingCheckpoint, ...]


@dataclass(frozen=True, slots=True)
class CompanionIdentityState:
    display_name: str
    mode: str
    aegis_text: str
    clone_text: str
    user_profile_text: str
    personality_preset: str
    personality_label: str
    personality_traits: tuple[str, ...]
    personality_summary: str
    relational_stance: str
    initiative: str
    continuity_notes: tuple[str, ...]
    governance_summary: str
    proactive_summary: str
    voice_identity_summary: str


@dataclass(frozen=True, slots=True)
class CompanionGovernanceState:
    identity: CompanionIdentityState
    onboarding: CompanionOnboardingState


@dataclass(frozen=True, slots=True)
class UserProfileField:
    field_id: str
    canonical_label: str
    bucket: str
    aliases: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ParsedUserProfileText:
    field_values: Mapping[str, str]
    durable_notes: tuple[str, ...] = ()


USER_PROFILE_FIELDS = (
    UserProfileField(
        field_id="preferred_name",
        canonical_label="Preferred name",
        bucket="required",
        aliases=("name", "nickname", "call me"),
    ),
    UserProfileField(
        field_id="current_work",
        canonical_label="Current work",
        bucket="required",
        aliases=("work", "current role", "work focus"),
    ),
    UserProfileField(
        field_id="school",
        canonical_label="School",
        bucket="good-to-have",
    ),
    UserProfileField(
        field_id="current_city",
        canonical_label="Current city",
        bucket="good-to-have",
        aliases=("city", "home city"),
    ),
    UserProfileField(
        field_id="mbti",
        canonical_label="MBTI",
        bucket="good-to-have",
    ),
    UserProfileField(
        field_id="dream",
        canonical_label="Dream",
        bucket="good-to-have",
    ),
    UserProfileField(
        field_id="creative_hobby",
        canonical_label="Creative hobby",
        bucket="good-to-have",
        aliases=("hobby creative",),
    ),
    UserProfileField(
        field_id="media_hobby",
        canonical_label="Media hobby",
        bucket="good-to-have",
        aliases=("hobby media",),
    ),
    UserProfileField(
        field_id="movement_hobby",
        canonical_label="Movement hobby",
        bucket="good-to-have",
        aliases=("hobby movement",),
    ),
    UserProfileField(
        field_id="boundaries",
        canonical_label="Boundaries",
        bucket="good-to-have",
        aliases=("sensitivities", "boundaries and sensitivities"),
    ),
)


def _normalize_user_field_label(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.strip().lower()).strip()


_USER_PROFILE_FIELD_LOOKUP = {
    _normalize_user_field_label(label): question.field_id
    for question in USER_PROFILE_FIELDS
    for label in (question.field_id, question.canonical_label, *question.aliases)
}
_USER_PROFILE_NOTE_LABELS = frozenset(
    {
        "remember",
        "remember this",
        "note",
        "notes",
        "durable note",
        "durable notes",
        "open fact",
        "open facts",
        "preference note",
        "preference notes",
    }
)
_UNKNOWN_VALUES = {"unknown", "n/a", "none", "<unknown>", "<unset>"}


def _clean_user_field_value(value: str) -> str:
    cleaned = value.strip().strip("*").strip()
    cleaned = cleaned.strip("\"' ")
    return cleaned


def parse_user_profile_content(text: str) -> ParsedUserProfileText:
    values: dict[str, str] = {}
    durable_notes: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("#"):
            continue
        line = re.sub(r"^[-*]\s+", "", line)
        if not line or _is_profile_heading(line):
            continue
        if ":" in line:
            label, raw_value = line.split(":", 1)
            normalized_label = _normalize_user_field_label(label)
            value = _clean_user_field_value(raw_value)
            if value and value.lower() not in _UNKNOWN_VALUES:
                field_id = _USER_PROFILE_FIELD_LOOKUP.get(normalized_label)
                if field_id is not None:
                    values[field_id] = value
                    continue
                if normalized_label in _USER_PROFILE_NOTE_LABELS:
                    durable_notes.append(value)
                    continue
            if value:
                durable_notes.append(line)
            continue
        if _line_is_inference_only(line):
            continue
        durable_notes.append(line)
    if "preferred_name" not in values:
        name_match = re.search(
            r"(?i)\b(?:call me|i go by|my name is|i'm called|i am called)\s+([^\n,.;:]+)",
            text,
        )
        if name_match is not None:
            inferred = _clean_user_field_value(name_match.group(1))
            if inferred:
                values["preferred_name"] = inferred
    if "current_work" not in values:
        work_match = re.search(
            (
                r"(?i)\b(?:i work on|i'm working on|i am working on|user works on|i build|i'm building|"
                r"i am building|user builds|i research|i'm researching|i am researching|user researches|"
                r"i study|i'm studying|i am studying|user studies|current work is|my work is)\s+([^\n.!?]+)"
            ),
            text,
        )
        if work_match is not None:
            inferred = _clean_user_field_value(work_match.group(1))
            if inferred:
                values["current_work"] = inferred
    return ParsedUserProfileText(
        field_values=values,
        durable_notes=_normalize_durable_notes(durable_notes),
    )


def parse_user_profile_text(text: str) -> dict[str, str]:
    return dict(parse_user_profile_content(text).field_values)


def user_profile_updates(
    payload: Mapping[str, object],
    *,
    ignored_keys: Sequence[str] = ("action", "target", "text", "fields", "profile_id"),
) -> dict[str, str]:
    ignored = {_normalize_user_field_label(key) for key in ignored_keys}
    values: dict[str, str] = {}
    for raw_key, raw_value in payload.items():
        normalized_key = _normalize_user_field_label(str(raw_key))
        if not normalized_key or normalized_key in ignored:
            continue
        field_id = _USER_PROFILE_FIELD_LOOKUP.get(normalized_key)
        if field_id is None:
            continue
        value = _clean_user_field_value(str(raw_value or ""))
        if not value or value.lower() in {"unknown", "n/a", "none", "<unknown>", "<unset>"}:
            continue
        values[field_id] = value
    return values


def merge_user_profile_text(
    existing_text: str | None,
    *,
    field_values: Mapping[str, str],
) -> str | None:
    parsed = parse_user_profile_content(existing_text or "")
    merged = dict(parsed.field_values)
    merged.update(field_values)
    if not merged and not parsed.durable_notes:
        return None
    return render_user_profile_text(durable_notes=parsed.durable_notes, **merged)


def user_profile_fields(profile: LoadedProfile) -> dict[str, str]:
    return dict(parse_user_profile_content(user_profile_text(profile)).field_values)


def user_profile_durable_notes(profile: LoadedProfile) -> tuple[str, ...]:
    return parse_user_profile_content(user_profile_text(profile)).durable_notes


def render_user_profile_text(
    *,
    durable_notes: Sequence[str] = (),
    **field_values: str | None,
) -> str:
    lines: list[str] = []
    for question in USER_PROFILE_FIELDS:
        value = _clean_user_field_value(str(field_values.get(question.field_id) or ""))
        if value:
            lines.append(f"{question.canonical_label}: {value}")
    lines.extend(f"Remember: {note}" for note in _normalize_durable_notes(durable_notes))
    return "\n".join(lines)


def missing_required_user_fields(profile: LoadedProfile) -> tuple[UserProfileField, ...]:
    values = user_profile_fields(profile)
    return tuple(
        question
        for question in USER_PROFILE_FIELDS
        if question.bucket == "required" and not values.get(question.field_id)
    )


def missing_optional_user_fields(profile: LoadedProfile) -> tuple[UserProfileField, ...]:
    values = user_profile_fields(profile)
    return tuple(
        question
        for question in USER_PROFILE_FIELDS
        if question.bucket == "good-to-have" and not values.get(question.field_id)
    )


def resolved_companion_settings(profile: LoadedProfile) -> CompanionSettings:
    if profile.companion is not None:
        return profile.companion
    preset = resolve_personality_preset(None, mode=profile.state.mode)
    return CompanionSettings(
        personality_preset=preset.preset_id,
        personality=preset.traits,
    )


def aegis_text(profile: LoadedProfile) -> str:
    if profile.aegis_path:
        try:
            text = Path(profile.aegis_path).expanduser().read_text(encoding="utf-8").strip()
            if text:
                return text
        except OSError:
            pass
    try:
        return load_packaged_aegis_text().strip()
    except OSError:
        return DEFAULT_AEGIS_TEXT


def render_clone_charter(
    *,
    display_name: str,
    personality_preset: str | None,
    initiative: str,
    mode: str = "default",
) -> str:
    preset = resolve_personality_preset(personality_preset, mode=mode)
    traits = ", ".join(preset.traits) or "grounded, direct, trustworthy"
    return "\n".join(
        (
            f"You are {display_name}, a named Aegis clone on one long-lived continuity line.",
            f"Default posture: {preset.summary}",
            f"Traits to preserve: {traits}.",
            f"Initiative style: {initiative}.",
            "Carry continuity carefully, protect trust, and let the user refine this clone over time.",
        )
    )


def clone_text(profile: LoadedProfile) -> str:
    companion = resolved_companion_settings(profile)
    return (
        profile.clone_text
        or render_clone_charter(
            display_name=profile.state.display_name,
            personality_preset=companion.personality_preset,
            initiative=companion.initiative,
            mode=profile.state.mode,
        )
        or DEFAULT_CLONE_TEXT
    ).strip()


def user_profile_text(profile: LoadedProfile) -> str:
    return (profile.user_profile_text or "").strip()


def _normalize_durable_notes(values: Sequence[str]) -> tuple[str, ...]:
    normalized: list[str] = []
    for value in values:
        cleaned = _clean_user_profile_note(value)
        if cleaned and cleaned not in normalized:
            normalized.append(cleaned)
    return tuple(normalized)


def _clean_user_profile_note(value: str) -> str | None:
    cleaned = _clean_user_field_value(str(value))
    if not cleaned or cleaned.lower() in _UNKNOWN_VALUES:
        return None
    return cleaned


def _is_profile_heading(value: str) -> bool:
    normalized = _normalize_user_field_label(value)
    return normalized in {
        "user",
        "user profile",
        "profile",
        "durable user profile",
        "stable user profile",
    }


def _line_is_inference_only(line: str) -> bool:
    return _matches_line(
        line,
        (
            r"(?i)^(?:call me|i go by|my name is|i'm called|i am called)\s+([^\n,.;:]+)$",
            (
                r"(?i)^(?:i work on|i'm working on|i am working on|user works on|i build|i'm building|"
                r"i am building|user builds|i research|i'm researching|i am researching|user researches|"
                r"i study|i'm studying|i am studying|user studies|current work is|my work is)\s+([^\n.!?]+)$"
            ),
        ),
    )


def _matches_line(line: str, patterns: Sequence[str]) -> bool:
    return any(re.match(pattern, line) is not None for pattern in patterns)


def build_companion_identity_state(profile: LoadedProfile) -> CompanionIdentityState:
    companion = resolved_companion_settings(profile)
    preset = resolve_personality_preset(companion.personality_preset, mode=profile.state.mode)
    traits = companion.personality or preset.traits
    clone_charter = clone_text(profile)
    user_summary = user_profile_text(profile)
    return CompanionIdentityState(
        display_name=profile.state.display_name,
        mode=profile.state.mode,
        aegis_text=aegis_text(profile),
        clone_text=clone_charter,
        user_profile_text=user_summary,
        personality_preset=preset.preset_id,
        personality_label=preset.label,
        personality_traits=traits,
        personality_summary=preset.summary,
        relational_stance=preset.relational_stance,
        initiative=companion.initiative,
        continuity_notes=companion.notes,
        governance_summary=companion.governance_summary(),
        proactive_summary=companion.proactive_summary(),
        voice_identity_summary=companion.voice_identity_summary(),
    )


def build_companion_onboarding_state(profile: LoadedProfile) -> CompanionOnboardingState:
    identity = build_companion_identity_state(profile)
    checkpoints = (
        OnboardingCheckpoint(
            checkpoint_id="identity-owner",
            label="Canonical identity owner",
            status="ready",
            summary=f"canonical identity is live as {identity.display_name}",
        ),
        OnboardingCheckpoint(
            checkpoint_id="user-state",
            label="Durable user state",
            status="ready",
            summary=(
                "durable user grounding should deepen through normal conversation "
                "instead of a file-first onboarding checklist"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="relationship-state",
            label="Relationship continuity",
            status="ready",
            summary="relationship posture stays governable through canonical continuity records",
        ),
    )
    return CompanionOnboardingState(
        status="ready",
        ready=True,
        missing_fields=(),
        next_step="continue-normal-conversation",
        summary=(
            "Canonical identity, user, and relationship state are live; deepen them "
            "through normal turns rather than a file-driven onboarding gate."
        ),
        checkpoints=checkpoints,
    )


def build_companion_governance_state(profile: LoadedProfile) -> CompanionGovernanceState:
    return CompanionGovernanceState(
        identity=build_companion_identity_state(profile),
        onboarding=build_companion_onboarding_state(profile),
    )
