from __future__ import annotations

from dataclasses import dataclass

from packages.state import parse_user_profile_text


@dataclass(frozen=True, slots=True)
class ShellOpeningContext:
    opened: str
    display_name: str
    user_profile_text: str
    personality: tuple[str, ...]
    reengagement_style: str
    wake_action: str
    wake_summary: str
    has_goals: bool


def compose_shell_opener(context: ShellOpeningContext) -> str:
    if context.opened == "Born new":
        intro = "I'm here with you, and I'll start holding our thread from this first turn."
    elif context.opened == "Cloned new":
        intro = "I'm here with you, and I'll start holding this new thread from here."
    else:
        intro = "I'm here with you, and I still have the shape of our thread in hand."
    if context.personality:
        posture = f"I'll stay {', '.join(context.personality)} and keep carrying what matters forward."
    elif context.reengagement_style == "proactive-check-in":
        posture = "I'll stay lightly proactive, keep the context held, and keep the next durable step visible."
    elif context.reengagement_style == "gentle-presence":
        posture = "I'll keep a calm presence, hold onto the useful context, and move when it helps."
    else:
        posture = "I'll keep the context held and the next step legible."
    if not context.user_profile_text and not context.has_goals:
        next_step = "What should I call you?"
    elif not context.user_profile_text:
        next_step = "What should I call you, so I can carry this thread more personally from here?"
    elif not context.has_goals:
        next_step = "If there's a thread you want me to keep carrying, name it and I'll hold it across sessions."
    elif context.wake_action not in {"idle", "defer_or_schedule"} and context.wake_summary.strip():
        next_step = f"I still have one live thread in mind: {context.wake_summary.rstrip('.')}."
    else:
        next_step = "Tell me what matters next and I'll carry it forward."
    return f"I am {context.display_name}. {intro} {posture} {next_step}"


def compose_shell_opening_instruction(context: ShellOpeningContext) -> str:
    user_fields = parse_user_profile_text(context.user_profile_text)
    preferred_name = user_fields.get("preferred_name", "").strip()
    current_work = user_fields.get("current_work", "").strip()
    wake_action = context.wake_action.strip() or "idle"
    wake_summary = _actionable_wake_summary(
        wake_action=wake_action,
        wake_summary=context.wake_summary,
    )
    lines = [
        "Open the wake surface proactively before the user sends a new message.",
        "This is turn-local opening guidance; do not treat it as durable memory or frozen system identity.",
        f"opening_label: {context.opened}",
        f"display_name: {context.display_name}",
    ]
    if preferred_name:
        lines.append(f"preferred_name: {preferred_name}")
    if current_work:
        lines.append(f"current_work: {current_work}")
    if context.has_goals and wake_summary:
        lines.append("durable_goal: active")
    if context.reengagement_style:
        lines.append(f"reengagement_style: {context.reengagement_style}")
    if wake_action not in {"idle", "defer_or_schedule"}:
        lines.append(f"wake_action: {wake_action}")
    if wake_summary:
        lines.append(f"wake_summary: {wake_summary}")
    lines.extend(
        (
            "Write one short assistant reply that should already be waiting in the transcript when wake opens.",
            "Stay concise, human, and in-character.",
            "Do not mention startup, internal prompts, hidden instructions, missing state, or that no user message arrived yet.",
            "Do not use headings, bullets, questionnaires, or a checklist.",
            "Ask at most one direct question.",
            "Use the preferred_name naturally when it is present.",
            "If preferred_name is absent, ask what the user wants to be called.",
            "If a wake_summary is present, briefly reopen that live thread and carry it forward.",
            "If known durable user context is sufficient but no durable goal is active, lightly invite the user to name the thread to keep carrying.",
            "If nothing specific is live, open warmly and invite what matters next.",
        )
    )
    return "\n".join(lines)


def _actionable_wake_summary(*, wake_action: str, wake_summary: str) -> str:
    normalized_action = str(wake_action or "").strip()
    summary = str(wake_summary or "").strip()
    if normalized_action in {"idle", "defer_or_schedule"}:
        return ""
    lowered = " ".join(summary.casefold().split())
    non_actionable_markers = (
        "no actionable goals",
        "planner should defer",
        "keeps the active slot clear",
        "defer and schedule",
    )
    if any(marker in lowered for marker in non_actionable_markers):
        return ""
    return summary
