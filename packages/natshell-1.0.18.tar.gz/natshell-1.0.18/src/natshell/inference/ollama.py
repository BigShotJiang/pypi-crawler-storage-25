"""Remote API client for Ollama and OpenAI-compatible servers."""

from __future__ import annotations

import logging
from dataclasses import dataclass

import httpx

logger = logging.getLogger(__name__)


@dataclass
class OllamaModel:
    """A model available on a remote server."""

    name: str
    size_gb: float = 0.0
    parameter_size: str = ""
    family: str = ""


def normalize_base_url(url: str) -> str:
    """Strip /v1 suffix and trailing slash to get the server root URL.

    Adds ``http://`` if no scheme is present.

    >>> normalize_base_url("http://localhost:11434/v1")
    'http://localhost:11434'
    >>> normalize_base_url("http://localhost:11434/v1/")
    'http://localhost:11434'
    >>> normalize_base_url("http://localhost:11434")
    'http://localhost:11434'
    >>> normalize_base_url("myhost:11434/v1")
    'http://myhost:11434'
    """
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = f"http://{url}"
    url = url.rstrip("/")
    if url.endswith("/v1"):
        url = url[:-3]
    return url


async def ping_server(base_url: str, api_key: str = "") -> bool:
    """Check if a server is reachable. Returns True if we get any 200 response.

    Tries the root URL first (Ollama), then /v1/models (OpenAI-compatible APIs).
    An optional *api_key* is sent as a Bearer token for authenticated APIs.
    """
    base_url = normalize_base_url(base_url)
    headers: dict[str, str] = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        async with httpx.AsyncClient(timeout=5.0, headers=headers) as client:
            resp = await client.get(f"{base_url}/")
            if resp.status_code == 200:
                return True
            # Root may not respond 200 on non-Ollama APIs — try /v1/models
            resp = await client.get(f"{base_url}/v1/models")
            return resp.status_code == 200
    except (
        httpx.ConnectError,
        httpx.ConnectTimeout,
        httpx.ReadTimeout,
        httpx.UnsupportedProtocol,
        OSError,
    ):
        return False


async def list_models(base_url: str) -> list[OllamaModel]:
    """List available models from a remote server.

    Tries Ollama native /api/tags first, then falls back to OpenAI /v1/models.
    Returns [] on failure.
    """
    base_url = normalize_base_url(base_url)
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            # Try Ollama native endpoint first
            try:
                resp = await client.get(f"{base_url}/api/tags")
                if resp.status_code == 200:
                    data = resp.json()
                    return _parse_ollama_models(data)
            except (httpx.HTTPError, ValueError, KeyError):
                pass

            # Fall back to OpenAI-compatible endpoint
            try:
                resp = await client.get(f"{base_url}/v1/models")
                if resp.status_code == 200:
                    data = resp.json()
                    return _parse_openai_models(data)
            except (httpx.HTTPError, ValueError, KeyError):
                pass

    except (httpx.ConnectError, httpx.ConnectTimeout, OSError):
        pass

    return []


def _parse_ollama_models(data: dict) -> list[OllamaModel]:
    """Parse Ollama /api/tags response."""
    models = []
    for m in data.get("models", []):
        details = m.get("details", {})
        size_bytes = m.get("size", 0)
        models.append(
            OllamaModel(
                name=m.get("name", ""),
                size_gb=round(size_bytes / (1024**3), 1) if size_bytes else 0.0,
                parameter_size=details.get("parameter_size", ""),
                family=details.get("family", ""),
            )
        )
    return models


def _parse_openai_models(data: dict) -> list[OllamaModel]:
    """Parse OpenAI /v1/models response."""
    models = []
    for m in data.get("data", []):
        models.append(
            OllamaModel(
                name=m.get("id", ""),
            )
        )
    return models


def _model_matches(query: str, name: str, model: str) -> bool:
    """Check if a model query matches an /api/ps entry.

    Handles Ollama's implicit :latest tag — e.g. query "qwen3" matches
    name "qwen3:latest".
    """
    if query in (name, model):
        return True
    # "qwen3" should match "qwen3:latest"
    if ":" not in query:
        return f"{query}:latest" in (name, model)
    return False


async def _get_running_context(base_url: str, model: str) -> int | None:
    """Query Ollama /api/ps for the actual runtime context of a loaded model.

    Returns the context length if the model is currently loaded, or None if
    unavailable (model not loaded, non-Ollama server, connection failure).
    """
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(f"{base_url}/api/ps")
            if resp.status_code != 200:
                return None
            data = resp.json()
            for entry in data.get("models", []):
                entry_name = entry.get("name", "")
                entry_model = entry.get("model", "")
                if _model_matches(model, entry_name, entry_model):
                    # Ollama returns context_length as a top-level field
                    ctx = entry.get("context_length")
                    if isinstance(ctx, int) and ctx > 0:
                        return ctx
    except (
        httpx.HTTPError,
        httpx.ConnectError,
        httpx.ConnectTimeout,
        OSError,
        ValueError,
        KeyError,
    ):
        pass
    return None


async def get_model_context_length(base_url: str, model: str) -> int:
    """Query the server for the model's context window size.

    Precedence:
    1. /api/ps runtime context (actual loaded context)
    2. /api/show metadata (architecture maximum)
    3. 0 (unavailable)
    """
    base_url = normalize_base_url(base_url)

    # Prefer runtime context from /api/ps (reflects actual loaded n_ctx)
    runtime_ctx = await _get_running_context(base_url, model)
    if runtime_ctx is not None:
        logger.debug("Got runtime context from /api/ps: %d", runtime_ctx)
        return runtime_ctx

    # Fall back to metadata from /api/show (architecture maximum)
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                f"{base_url}/api/show",
                json={"model": model},
            )
            if resp.status_code == 200:
                data = resp.json()
                model_info = data.get("model_info", {})
                # Context length key varies by architecture: llama.context_length,
                # qwen2.context_length, etc. Search for any key ending in .context_length
                for key, value in model_info.items():
                    if key.endswith(".context_length") and isinstance(value, int):
                        return value
    except (
        httpx.HTTPError,
        httpx.ConnectError,
        httpx.ConnectTimeout,
        OSError,
        ValueError,
        KeyError,
    ):
        pass
    return 0
