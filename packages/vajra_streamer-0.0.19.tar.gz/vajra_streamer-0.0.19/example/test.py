import os
import sys

# Ensure the parent directory (python) is in path to import vajra
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from vajra import VajraStreamer, StreamConfig

def main():
    # URL to a small model for testing
    url = "https://huggingface.co/meta-llama/Meta-Llama-3-8B/resolve/main/model-00001-of-00004.safetensors"

    config = StreamConfig(
        auth_token="", # Using public model
        chunk_size_mb=16, # Small chunk size for the small model
        chunk_workers=4,
        gpu_workers=2,
        disable_cache=True,
        log_level=4 # 4 = info, 3 = diagnostic, 2 = debug, 1 = debugV, 0 = trace
    )

    print(f"Streaming {url} into GPU memory (zero-copy)...")

    print("[Python] Entering VajraStreamer context")
    with VajraStreamer(config) as streamer:
        # Load the model directly to VRAM
        print("[Python] Calling streamer.load(url)")
        tensors = streamer.load(url)
        print("[Python] streamer.load(url) completed")

        print("\nSuccessfully loaded model!")
        print(f"Total tensors loaded: {len(tensors)}")

        if len(tensors) > 0:
            print("\nSample Tensors:")
            # Print the first few tensors to verify
            count = 0
            for name, tensor in tensors.items():
                if hasattr(tensor, 'dtype'):
                    print(f" - {name}: shape={tensor.shape}, dtype={tensor.dtype}, device={tensor.device}")
                else:
                    print(f" - {name}: shape={tensor.shape}, dtype={tensor.typestr}, device=cuda (raw VajraGPUTensor)")
                count += 1
                if count >= 5:
                    print(" - ...")
                    break

    print("\nExiting with block. All VRAM will be freed automatically.")
    print("[Python] Context manager exited successfully")

if __name__ == "__main__":
    main()
