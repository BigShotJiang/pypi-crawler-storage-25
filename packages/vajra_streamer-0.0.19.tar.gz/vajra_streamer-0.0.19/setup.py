import platform
import sys

from setuptools import Distribution, setup

# Guard must run before setuptools does any work. This sdist intentionally
# bundles a prebuilt Linux x86_64 binary (libvajra.so). It cannot be built
# on any other platform. Fail loudly here rather than with a confusing
# linker or import error later.
if not (sys.platform == "linux" and platform.machine() == "x86_64"):
    raise RuntimeError(
        "vajra ships a prebuilt Linux x86_64 shared library (libvajra.so). "
        "This sdist cannot be built on your platform. "
        "Install the pre-built wheel instead:\n\n"
        "    pip install vajra-streamer\n\n"
        "If no wheel is available for your platform, "
        "please open an issue at https://github.com/your-org/vibe-streamer"
    )


try:
    from wheel.bdist_wheel import bdist_wheel as _bdist_wheel
    class bdist_wheel(_bdist_wheel):
        def finalize_options(self):
            _bdist_wheel.finalize_options(self)
            self.root_is_pure = False

        def get_tag(self):
            python, abi, plat = _bdist_wheel.get_tag(self)
            # We don't contain any Python C-API extensions, just a generic shared library.
            # So we can use 'py3' for python and 'none' for ABI.
            return 'py3', 'none', plat
    cmdclass = {'bdist_wheel': bdist_wheel}
except ImportError:
    cmdclass = {}

class BinaryDistribution(Distribution):
    """Force setuptools to treat this as a platform-specific wheel.

    setuptools has no declarative flag in pyproject.toml for this case —
    where a pre-compiled .so is injected from outside the Python build
    system. Overriding has_ext_modules() is the standard escape hatch.
    Without this, `python -m build` produces a `*-any.whl` (pure-Python
    tag), which PyPI would serve to Windows/macOS users who can't run .so
    files.
    """

    def has_ext_modules(self):
        return True


setup(distclass=BinaryDistribution, cmdclass=cmdclass)
