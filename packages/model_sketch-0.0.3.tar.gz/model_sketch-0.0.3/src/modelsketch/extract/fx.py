"""torch.fx-backed extraction entry point for the MVP."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import torch
from torch.fx.passes.shape_prop import ShapeProp

from modelsketch.extract.models import GraphEdge, GraphNode, GraphSpec

if TYPE_CHECKING:
    from collections.abc import Mapping

    from torch.fx import GraphModule, Node


def extract_graph(
    model: Any,
    *,
    args: tuple[Any, ...],
    kwargs: Mapping[str, Any],
) -> GraphSpec:
    """Extract a graph from a model and example inputs.

    Args:
        model: Model object that will be traced in future iterations.
        args: Example positional arguments used for tracing.
        kwargs: Example keyword arguments used for tracing.

    Returns:
        Graph representation extracted from torch.fx tracing.
    """

    if not isinstance(model, torch.nn.Module):
        msg = "model must be an instance of torch.nn.Module"
        raise TypeError(msg)

    traced = torch.fx.symbolic_trace(model)
    _run_shape_propagation(traced, args=args, kwargs=kwargs)

    nodes: list[GraphNode] = []
    edges: list[GraphEdge] = []

    for node in traced.graph.nodes:
        if node.op == "output":
            continue
        nodes.append(
            GraphNode(
                id=node.name,
                op_type=node.op,
                label=_node_label(node=node, graph_module=traced),
                module_path=(str(node.target) if node.op == "call_module" else None),
            ),
        )
        for input_node in node.all_input_nodes:
            edges.append(GraphEdge(source=input_node.name, target=node.name))

    return GraphSpec(nodes=nodes, edges=edges)


def _run_shape_propagation(
    traced: GraphModule,
    *,
    args: tuple[Any, ...],
    kwargs: Mapping[str, Any],
) -> None:
    """Best-effort shape propagation for labels.

    Shape propagation is optional because some models require runtime data or
    control flow that cannot be inferred statically.
    """

    if not args and not kwargs:
        return
    try:
        ShapeProp(traced).propagate(*args, **dict(kwargs))
    except (AssertionError, RuntimeError, TypeError, ValueError):
        return


def _node_label(*, node: Node, graph_module: GraphModule) -> str:
    """Build a concise label for a traced node."""

    if node.op == "call_module":
        submodule = graph_module.get_submodule(str(node.target))
        base = type(submodule).__name__
    elif node.op == "call_function":
        base = getattr(node.target, "__name__", str(node.target))
    elif node.op in {"call_method", "placeholder"}:
        base = str(node.target)
    else:
        base = str(node.op)

    shape_suffix = _shape_suffix(node)
    return f"{base}{shape_suffix}"


def _shape_suffix(node: Node) -> str:
    """Create a compact shape suffix from fx tensor metadata when present."""

    tensor_meta = node.meta.get("tensor_meta")
    if tensor_meta is None:
        return ""
    shape = getattr(tensor_meta, "shape", None)
    if shape is None:
        return ""
    return f" {tuple(shape)}"
