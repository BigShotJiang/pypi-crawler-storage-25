"""Simple layout planner for MVP model diagrams."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import TYPE_CHECKING

from modelsketch.layout.types import LayoutPlan, NodeBox

if TYPE_CHECKING:
    from modelsketch.extract.models import GraphSpec
    from modelsketch.semantic.models import SemanticModel


@dataclass(frozen=True)
class _LayoutConfig:
    """Internal configuration for layout planning helpers."""

    start_x: float
    start_y: float
    box_width: float
    box_height: float
    gap: float
    inter_block_gap: float
    lane_gap: float = 36.0


def plan_layout(
    graph: GraphSpec,
    *,
    semantic_model: SemanticModel | None = None,
    inter_block_gap: float = 96.0,
) -> LayoutPlan:
    """Plan a deterministic left-to-right layout for graph nodes.

    Args:
        graph: Extracted model graph.
        semantic_model: Optional semantic grouping used for visual spacing.
        inter_block_gap: Horizontal gap inserted between semantic blocks.

    Returns:
        Layout plan with node boxes and viewport dimensions.
    """

    start_x = 24.0
    start_y = 24.0
    box_width = 180.0
    box_height = 72.0
    gap = 48.0

    if inter_block_gap < 0.0:
        msg = "inter_block_gap must be non-negative"
        raise ValueError(msg)

    node_to_block = _node_to_block_mapping(semantic_model)

    config = _LayoutConfig(
        start_x=start_x,
        start_y=start_y,
        box_width=box_width,
        box_height=box_height,
        gap=gap,
        inter_block_gap=inter_block_gap,
    )

    if not graph.edges or not _has_branching(graph):
        return _plan_sequential_layout(
            graph=graph,
            node_to_block=node_to_block,
            config=config,
        )

    return _plan_depth_layout(
        graph=graph,
        node_to_block=node_to_block,
        config=config,
    )


def _plan_sequential_layout(
    *,
    graph: GraphSpec,
    node_to_block: dict[str, str],
    config: _LayoutConfig,
) -> LayoutPlan:
    """Plan a one-row left-to-right layout."""

    boxes: dict[str, NodeBox] = {}
    cursor_x = config.start_x
    previous_block: str | None = None

    for node in graph.nodes:
        current_block = node_to_block.get(node.id)
        if boxes:
            step_gap = (
                config.inter_block_gap
                if current_block != previous_block
                else config.gap
            )
            cursor_x += config.box_width + step_gap
        x = cursor_x
        boxes[node.id] = NodeBox(
            x=x,
            y=config.start_y,
            width=config.box_width,
            height=config.box_height,
        )
        previous_block = current_block

    width = (
        cursor_x + config.box_width + config.start_x if boxes else config.start_x * 2
    )
    height = config.start_y * 2 + config.box_height

    return LayoutPlan(boxes=boxes, width=width, height=height)


def _plan_depth_layout(
    *,
    graph: GraphSpec,
    node_to_block: dict[str, str],
    config: _LayoutConfig,
) -> LayoutPlan:
    """Plan a deterministic depth-based layout for branching graphs."""

    incoming: dict[str, list[str]] = defaultdict(list)
    for edge in graph.edges:
        incoming[edge.target].append(edge.source)

    depth_by_node: dict[str, int] = {}
    nodes_by_depth: dict[int, list[str]] = defaultdict(list)

    for node in graph.nodes:
        parent_depth = max(
            (depth_by_node.get(src, 0) for src in incoming[node.id]),
            default=-1,
        )
        depth = parent_depth + 1
        depth_by_node[node.id] = depth
        nodes_by_depth[depth].append(node.id)

    sorted_depths = sorted(nodes_by_depth)
    x_by_depth: dict[int, float] = {}
    cursor_x = config.start_x
    previous_depth_block: str | None = None

    for depth in sorted_depths:
        x_by_depth[depth] = cursor_x
        representative = nodes_by_depth[depth][0]
        current_block = node_to_block.get(representative)
        step_gap = (
            config.inter_block_gap
            if previous_depth_block is not None
            and current_block != previous_depth_block
            else config.gap
        )
        cursor_x += config.box_width + step_gap
        previous_depth_block = current_block

    boxes: dict[str, NodeBox] = {}
    max_lanes = 1
    for depth in sorted_depths:
        lanes = nodes_by_depth[depth]
        max_lanes = max(max_lanes, len(lanes))
        for lane_index, node_id in enumerate(lanes):
            boxes[node_id] = NodeBox(
                x=x_by_depth[depth],
                y=config.start_y + lane_index * (config.box_height + config.lane_gap),
                width=config.box_width,
                height=config.box_height,
            )

    if sorted_depths:
        last_depth = sorted_depths[-1]
        width = x_by_depth[last_depth] + config.box_width + config.start_x
    else:
        width = config.start_x * 2

    height = (
        config.start_y * 2
        + max_lanes * config.box_height
        + (max_lanes - 1) * config.lane_gap
    )
    return LayoutPlan(boxes=boxes, width=width, height=height)


def _node_to_block_mapping(semantic_model: SemanticModel | None) -> dict[str, str]:
    """Create a lookup from node id to semantic block name."""

    if semantic_model is None:
        return {}

    mapping: dict[str, str] = {}
    for stage in semantic_model.stages:
        for block in stage.blocks:
            for layer in block.layers:
                mapping[layer.id] = block.name
    return mapping


def _has_branching(graph: GraphSpec) -> bool:
    """Return True when the graph includes split or merge connectivity."""

    outgoing_count: dict[str, int] = defaultdict(int)
    incoming_count: dict[str, int] = defaultdict(int)

    for edge in graph.edges:
        outgoing_count[edge.source] += 1
        incoming_count[edge.target] += 1

    return any(count > 1 for count in outgoing_count.values()) or any(
        count > 1 for count in incoming_count.values()
    )
