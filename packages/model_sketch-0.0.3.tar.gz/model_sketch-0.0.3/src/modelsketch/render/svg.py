"""SVG rendering backend for architecture sketches."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal
from xml.sax.saxutils import escape

if TYPE_CHECKING:
    from modelsketch.extract.models import GraphSpec
    from modelsketch.layout.types import LayoutPlan

EdgeStyle = Literal["straight", "orthogonal"]


def render_svg(
    *,
    graph: GraphSpec,
    layout: LayoutPlan,
    edge_style: EdgeStyle = "straight",
    arrowheads: bool = False,
) -> str:
    """Render a graph and layout plan to SVG.

    Args:
        graph: Graph to render.
        layout: Precomputed layout plan.
        edge_style: Edge rendering style.
        arrowheads: Whether to render arrowheads on edges.

    Returns:
        SVG document as a UTF-8 compatible string.
    """

    parts: list[str] = [
        (
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'width="{layout.width:.0f}" height="{layout.height:.0f}" '
            f'viewBox="0 0 {layout.width:.0f} {layout.height:.0f}">'
        ),
        '<rect width="100%" height="100%" fill="white" />',
    ]

    if arrowheads:
        parts.extend(
            [
                "<defs>",
                (
                    '<marker id="edge-arrow" markerWidth="10" markerHeight="7" '
                    'refX="9" refY="3.5" orient="auto" markerUnits="strokeWidth">'
                ),
                '<path d="M0,0 L10,3.5 L0,7 z" fill="#333" />',
                "</marker>",
                "</defs>",
            ],
        )

    for edge in graph.edges:
        source_box = layout.boxes.get(edge.source)
        target_box = layout.boxes.get(edge.target)
        if source_box is None or target_box is None:
            continue
        x1 = source_box.x + source_box.width
        y1 = source_box.y + source_box.height / 2
        x2 = target_box.x
        y2 = target_box.y + target_box.height / 2
        marker_attr = ' marker-end="url(#edge-arrow)"' if arrowheads else ""
        if edge_style == "orthogonal":
            bend_x = x1 + (x2 - x1) / 2
            parts.append(
                (
                    f'<path d="M{x1:.1f},{y1:.1f} L{bend_x:.1f},{y1:.1f} '
                    f'L{bend_x:.1f},{y2:.1f} L{x2:.1f},{y2:.1f}" '
                    f'stroke="#333" stroke-width="2" fill="none"{marker_attr} />'
                ),
            )
        else:
            parts.append(
                (
                    f'<line x1="{x1:.1f}" y1="{y1:.1f}" '
                    f'x2="{x2:.1f}" y2="{y2:.1f}" '
                    f'stroke="#333" stroke-width="2"{marker_attr} />'
                ),
            )

    for node in graph.nodes:
        box = layout.boxes.get(node.id)
        if box is None:
            continue
        label = escape(node.label)
        parts.append("<g>")
        parts.extend(
            [
                (
                    f'<rect x="{box.x:.1f}" y="{box.y:.1f}" '
                    f'width="{box.width:.1f}" height="{box.height:.1f}" '
                    'rx="10" fill="#f2f6fb" stroke="#1f2937" stroke-width="1.5" />'
                ),
                (
                    f'<text x="{box.x + 12:.1f}" y="{box.y + box.height / 2 + 5:.1f}" '
                    'font-family="Helvetica, Arial, sans-serif" '
                    'font-size="14" fill="#111827">'
                    f"{label}</text>"
                ),
            ],
        )
        parts.append("</g>")

    parts.append("</svg>")
    return "".join(parts)
