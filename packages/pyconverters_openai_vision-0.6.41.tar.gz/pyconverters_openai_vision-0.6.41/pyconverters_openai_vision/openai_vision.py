import base64
import collections.abc
import inspect
import os
import re
from enum import StrEnum
from functools import cache
from logging import Logger
from re import Pattern
from string import Template
from typing import Any, cast

import filetype as filetype
import jinja2
from log_with_context import add_logging_context
from pydantic import BaseModel, Field
from pymultirole_plugins.v1.converter import ConverterBase, ConverterParameters
from pymultirole_plugins.v1.processor import ProcessorBase, ProcessorParameters
from pymultirole_plugins.v1.schema import AltText, Document, Sentence
from starlette.datastructures import UploadFile

from .openai_utils import (
    NO_DEPLOYED_MODELS,
    OAuthToken,
    all_filter,
    check_litellm_defined,
    create_openai_model_enum,
    gpt_filter,
    openai_chat_completion,
)

logger = Logger("pymultirole")
SHOW_INTERNAL = bool(os.getenv("SHOW_INTERNAL", "false"))

# Pattern to match fenced code blocks with optional language marker
_FENCED_PATTERN: Pattern = re.compile(r"```(\w+)?\s*\n?(.*?)```", re.DOTALL)

# Mapping from fenced code block language markers to MIME types
_LANG_TO_MIME: dict[str, str] = {
    "json": "application/json",
    "markdown": "text/markdown",
    "md": "text/markdown",
    "html": "text/html",
    "xml": "application/xml",
    "yaml": "application/yaml",
    "yml": "application/yaml",
    "csv": "text/csv",
    "python": "text/x-python",
    "py": "text/x-python",
    "javascript": "text/javascript",
    "js": "text/javascript",
    "typescript": "text/typescript",
    "ts": "text/typescript",
    "css": "text/css",
    "sql": "application/sql",
    "text": "text/plain",
    "txt": "text/plain",
    "latex": "application/x-latex",
    "tex": "application/x-latex",
}


def _lang_to_mime(lang: str) -> str:
    """Convert a fenced code block language marker to a MIME type."""
    return _LANG_TO_MIME.get(lang.lower(), f"text/x-{lang.lower()}")


def _extract_fenced_block(text: str) -> tuple[str | None, str]:
    """Extract content from a fenced code block, returning (mime_type, cleaned_text).

    If the text contains a fenced block like ```json ... ```, returns ("application/json", "<content>").
    If the fence has no language marker, returns (None, "<content>").
    If no fenced block is found, returns (None, original_text).
    """
    match = _FENCED_PATTERN.search(text)
    if match is not None:
        lang = match.group(1)  # e.g. "json", "markdown", "python", or None
        content = match.group(2).strip()
        mime = _lang_to_mime(lang) if lang else None
        return mime, content
    return None, text


class TemplateLanguage(StrEnum):
    none = "none"
    string = "string"
    jinja2 = "jinja2"


def get_template(prompt: str, _default: str = None):
    if prompt:
        if "$" in prompt:
            prompt_templ = Template(prompt)
            return TemplateLanguage.string, prompt_templ
        elif "{{" in prompt:
            environment = get_jinja2_env()
            prompt_dedented = inspect.cleandoc(prompt)
            prompt_templ = environment.from_string(prompt_dedented)
            return TemplateLanguage.jinja2, prompt_templ
    return TemplateLanguage.none, prompt


def render_template(templ, prompt_templ, document, params):
    if templ == TemplateLanguage.string:
        flat = {k: v for k, v in document.__dict__.items() if not k.startswith("_")}
        prompt = prompt_templ.safe_substitute(flat)
    elif templ == TemplateLanguage.jinja2:
        prompt = prompt_templ.render(doc=document, parameters=params)
    else:
        prompt = prompt_templ
    return prompt


@cache
def get_jinja2_env():
    return jinja2.Environment(extensions=["jinja2.ext.do"])


class OpenAIVisionBaseParameters(ConverterParameters):
    base_url: str = Field(None, description="""OpenAI endpoint base url""", json_schema_extra={"extra": "advanced"})
    model_str: str = Field(None, json_schema_extra={"extra": "advanced"})
    model: str = Field(None, json_schema_extra={"extra": "internal"})
    prompt: str = Field(
        """If the attached file is an image: describe the image.""",
        description="""Contains the prompt as a string""",
        json_schema_extra={"extra": "multiline"},
    )
    max_tokens: int = Field(
        16384,
        description="""The maximum number of tokens to generate in the completion.
    The token count of your prompt plus max_tokens cannot exceed the model's context length.
    Most models have a context length of 2048 tokens (except for the newest models, which support 4096).""",
    )
    system_prompt: str = Field(
        None,
        description="""Contains the system prompt""",
        json_schema_extra={"extra": "multiline,advanced"},
    )
    temperature: float = Field(
        0.1,
        description="""What sampling temperature to use, between 0 and 2.
    Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic.
    We generally recommend altering this or `top_p` but not both.""",
        json_schema_extra={"extra": "advanced"},
    )
    top_p: int = Field(
        1,
        description="""An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass.
    So 0.1 means only the tokens comprising the top 10% probability mass are considered.
    We generally recommend altering this or `temperature` but not both.""",
        json_schema_extra={"extra": "advanced"},
    )
    n: int = Field(
        1,
        description="""How many completions to generate for each prompt.
    Note: Because this parameter generates many completions, it can quickly consume your token quota.
    Use carefully and ensure that you have reasonable settings for `max_tokens`.""",
        json_schema_extra={"extra": "advanced"},
    )
    best_of: int = Field(
        1,
        description="""Generates best_of completions server-side and returns the "best" (the one with the highest log probability per token).
    Results cannot be streamed.
    When used with `n`, `best_of` controls the number of candidate completions and `n` specifies how many to return – `best_of` must be greater than `n`.
    Use carefully and ensure that you have reasonable settings for `max_tokens`.""",
        json_schema_extra={"extra": "advanced"},
    )
    presence_penalty: float = Field(
        0.0,
        description="""Number between -2.0 and 2.0.
    Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.""",
        json_schema_extra={"extra": "advanced"},
    )
    frequency_penalty: float = Field(
        0.0,
        description="""Number between -2.0 and 2.0.
    Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.""",
        json_schema_extra={"extra": "advanced"},
    )


class OpenAIVisionModel(StrEnum):
    gpt_4o_mini = "gpt-4o-mini"
    gpt_4o = "gpt-4o"
    gpt_4_1 = "gpt-4.1"
    gpt_4_1_mini = "gpt-4.1-mini"
    gpt_4_1_nano = "gpt-4.1-nano"
    gpt_5 = "gpt-5"
    gpt_5_mini = "gpt-5-mini"
    gpt_5_nano = "gpt-5-nano"


check_litellm_defined()
OPENAI_PREFIX = ""
OPENAI_API_BASE = os.getenv(OPENAI_PREFIX + "OPENAI_API_BASE", None)
CHAT_GPT_MODEL_ENUM, DEFAULT_CHAT_GPT_MODEL = create_openai_model_enum(
    "OpenAIModel2",
    prefix=OPENAI_PREFIX,
    base_url=OPENAI_API_BASE,
    key=gpt_filter if OPENAI_API_BASE is None else all_filter,
)


class OpenAIVisionParameters(OpenAIVisionBaseParameters):
    base_url: str | None = Field(
        os.getenv(OPENAI_PREFIX + "OPENAI_API_BASE", None),
        description="""OpenAI endpoint base url""",
        json_schema_extra={"extra": "advanced"},
    )
    model: CHAT_GPT_MODEL_ENUM = Field(
        DEFAULT_CHAT_GPT_MODEL,
        description="""The [OpenAI model](https://platform.openai.com/docs/models) used for completion.""",
        json_schema_extra={"extra": "pipeline-naming-hint"},
    )


DEEPINFRA_PREFIX = "DEEPINFRA_"
DEEPINFRA_OPENAI_API_BASE = os.getenv(DEEPINFRA_PREFIX + "OPENAI_API_BASE", None)
DEEPINFRA_CHAT_GPT_MODEL_ENUM, DEEPINFRA_DEFAULT_CHAT_GPT_MODEL = create_openai_model_enum(
    "DeepInfraOpenAIModel", prefix=DEEPINFRA_PREFIX, base_url=DEEPINFRA_OPENAI_API_BASE
)


class DeepInfraOpenAIVisionParameters(OpenAIVisionBaseParameters):
    base_url: str = Field(
        os.getenv(DEEPINFRA_PREFIX + "OPENAI_API_BASE", None),
        description="""OpenAI endpoint base url""",
        json_schema_extra={"extra": "advanced"},
    )
    model: DEEPINFRA_CHAT_GPT_MODEL_ENUM = Field(
        None,
        description="""The [DeepInfra 'OpenAI compatible' model](https://deepinfra.com/models?type=text-generation) used for completion. It must be deployed on your [DeepInfra dashboard](https://deepinfra.com/dash).""",
        json_schema_extra={"extra": "pipeline-naming-hint"},
    )


class OpenAIVisionConverterBase(ConverterBase):
    __doc__ = """Generate text using [OpenAI Text Completion](https://platform.openai.com/docs/guides/completion) API
    You input some text as a prompt, and the model will generate a text completion that attempts to match whatever context or pattern you gave it."""
    PREFIX: str = ""
    oauth_token: OAuthToken = OAuthToken()

    def compute_args(self, params: OpenAIVisionBaseParameters, source: UploadFile, kind) -> dict[str, Any]:
        data = source.file.read()
        rv = base64.b64encode(data)
        if kind.mime.startswith("image"):
            binary_block = {"type": "image_url", "image_url": {"url": f"data:{kind.mime};base64,{rv.decode('utf-8')}"}}
        messages = [{"role": "system", "content": params.system_prompt}] if params.system_prompt is not None else []
        messages.append({"role": "user", "content": [{"type": "text", "text": params.prompt}, binary_block]})
        kwargs = {
            "model": params.model_str,
            "messages": messages,
            "max_tokens": params.max_tokens,
            "temperature": params.temperature,
            "top_p": params.top_p,
            "n": params.n,
            "frequency_penalty": params.frequency_penalty,
            "presence_penalty": params.presence_penalty,
        }
        return kwargs

    def compute_result(self, base_url, **kwargs) -> tuple[str | None, str] | None:
        """Compute the result from OpenAI chat completion.

        Returns a tuple (mime_type, text) where mime_type is derived from the
        fenced code block language marker (e.g. "application/json") or None.
        """
        response = openai_chat_completion(self.PREFIX, self.oauth_token, base_url, **kwargs)
        contents = []
        content_type = None
        for choice in response.choices:
            if choice.message.content:
                if "```" in choice.message.content:
                    lang, extracted = _extract_fenced_block(choice.message.content)
                    contents.append(extracted)
                    if lang is not None:
                        content_type = lang
                else:
                    contents.append(choice.message.content)
        if contents:
            return content_type, "\n".join(contents)
        return None

    def convert(self, source: UploadFile, parameters: ConverterParameters) -> list[Document]:
        params: OpenAIVisionBaseParameters = cast(OpenAIVisionBaseParameters, parameters)
        OPENAI_MODEL = os.getenv(self.PREFIX + "OPENAI_MODEL", None)
        if OPENAI_MODEL:
            params.model_str = OPENAI_MODEL
        doc = None
        try:
            kind = filetype.guess(source.file)
            source.file.seek(0)
            if kind.mime.startswith("image"):
                result = None
                kwargs = self.compute_args(params, source, kind)
                if kwargs["model"] != NO_DEPLOYED_MODELS:
                    result = self.compute_result(params.base_url, **kwargs)
                if result:
                    content_type, text = result
                    doc = Document(identifier=source.filename, text=text)
                    doc.properties = {"fileName": source.filename}
                    if content_type:
                        doc.properties["mime-type"] = content_type
        except BaseException as err:
            raise err
        if doc is None:
            raise TypeError(f"Conversion of file {source.filename} failed")
        return [doc]

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return OpenAIVisionBaseParameters


class OpenAIVisionConverter(OpenAIVisionConverterBase):
    __doc__ = """Convert audio using [OpenAI Audio](https://platform.openai.com/docs/guides/speech-to-text) API"""

    def convert(self, source: UploadFile, parameters: ConverterParameters) -> list[Document]:
        params: OpenAIVisionParameters = cast(OpenAIVisionParameters, parameters)
        model_str = params.model_str if bool(params.model_str and params.model_str.strip()) else None
        model = params.model.value if params.model is not None else None
        params.model_str = model_str or model
        return super().convert(source, params)

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return OpenAIVisionParameters


class DeepInfraOpenAIVisionConverter(OpenAIVisionConverterBase):
    __doc__ = """Convert images using [DeepInfra Vision](https://deepinfra.com/docs/tutorials/whisper) API"""
    PREFIX = DEEPINFRA_PREFIX

    def convert(self, source: UploadFile, parameters: ConverterParameters) -> list[Document]:
        params: DeepInfraOpenAIVisionParameters = cast(DeepInfraOpenAIVisionParameters, parameters)
        model_str = params.model_str if bool(params.model_str and params.model_str.strip()) else None
        model = params.model.value if params.model is not None else None
        params.model_str = model_str or model
        return super().convert(source, params)

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return DeepInfraOpenAIVisionParameters


def guess_kind(base64_src):
    kind = None
    img_regex = r"data:(image/[^;]+);base64"
    matches = re.search(img_regex, base64_src)
    if matches:
        mime = matches.group(1)
        kind = filetype.get_type(mime)
    return kind


class OpenAIVisionProcessorBaseParameters(ProcessorParameters):
    base_url: str = Field(None, description="""OpenAI endpoint base url""", json_schema_extra={"extra": "advanced"})
    model_str: str = Field(None, json_schema_extra={"extra": "advanced"})
    model: str = Field(None, json_schema_extra={"extra": "internal"})
    max_tokens: int = Field(
        16384,
        description="""The maximum number of tokens to generate in the completion.
        The token count of your prompt plus max_tokens cannot exceed the model's context length.
        Most models have a context length of 2048 tokens (except for the newest models, which support 4096).""",
    )
    replace_refs_altTexts_by_descriptions: bool = Field(
        True,
        description="""Replace references to images in text by their textual description.""",
        json_schema_extra={"extra": "advanced"},
    )
    system_prompt: str = Field(
        None,
        description="""Contains the system prompt""",
        json_schema_extra={"extra": "multiline,advanced"},
    )
    prompt: str = Field(
        "Generate a textual description of the image",
        description="""Contains the prompt as a template string, templates can be:
         <li>a simple (python template string)[https://docs.python.org/3/library/string.html#template-strings]<br/>
         where the document elements can be substituted using `$based`-syntax<br/>
         `$text` to be substituted by the document text<br/>
         `$title` to be substituted by the document title
         <li>a more complex (jinja2 template)[https://jinja.palletsprojects.com/en/3.1.x/]
         where the document is injected as `doc` and can be used in jinja2 variables like<br/>
         `{{ doc.text }}` to be substituted by the document text etc...""",
        json_schema_extra={"extra": "multiline"},
    )
    temperature: float = Field(
        0.1,
        description="""What sampling temperature to use, between 0 and 2.
        Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic.
        We generally recommend altering this or `top_p` but not both.""",
        json_schema_extra={"extra": "advanced"},
    )
    top_p: int = Field(
        1,
        description="""An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass.
        So 0.1 means only the tokens comprising the top 10% probability mass are considered.
        We generally recommend altering this or `temperature` but not both.""",
        json_schema_extra={"extra": "advanced"},
    )
    n: int = Field(
        1,
        description="""How many completions to generate for each prompt.
        Note: Because this parameter generates many completions, it can quickly consume your token quota.
        Use carefully and ensure that you have reasonable settings for `max_tokens`.""",
        json_schema_extra={"extra": "advanced"},
    )
    best_of: int = Field(
        1,
        description="""Generates best_of completions server-side and returns the "best" (the one with the highest log probability per token).
        Results cannot be streamed.
        When used with `n`, `best_of` controls the number of candidate completions and `n` specifies how many to return – `best_of` must be greater than `n`.
        Use carefully and ensure that you have reasonable settings for `max_tokens`.""",
        json_schema_extra={"extra": "advanced"},
    )
    presence_penalty: float = Field(
        0.0,
        description="""Number between -2.0 and 2.0.
        Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.""",
        json_schema_extra={"extra": "advanced"},
    )
    frequency_penalty: float = Field(
        0.0,
        description="""Number between -2.0 and 2.0.
        Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.""",
        json_schema_extra={"extra": "advanced"},
    )


def regex_sub_preserve_spans(
    text: str,
    regex: str,
    repl: collections.abc.Callable[[re.Match], str],
    spans: list[Sentence],
    flags=0,
):
    new_text_parts = []
    char_map = {}  # old_char_offset -> new_char_offset

    last_pos = 0
    new_pos = 0

    for match in re.finditer(regex, text, flags):
        start, end = match.start(), match.end()
        replacement = repl(match)

        # Copier le texte inchangé
        unchanged = text[last_pos:start]
        new_text_parts.append(unchanged)

        for i in range(last_pos, start):
            char_map[i] = new_pos
            new_pos += 1

        # Insérer le remplacement
        new_text_parts.append(replacement)

        for i in range(start, end):
            char_map[i] = new_pos

        new_pos += len(replacement)
        last_pos = end

    # Reste du texte
    tail = text[last_pos:]
    new_text_parts.append(tail)

    for i in range(last_pos, len(text)):
        char_map[i] = new_pos
        new_pos += 1

    new_text = "".join(new_text_parts)

    # Créer le nouveau Doc
    # Recréer les spans
    new_spans = None
    if spans is not None:
        new_spans = []
        for span in spans:
            if span.start not in char_map or span.end not in char_map:
                continue

            new_start = char_map[span.start]
            new_end = min(char_map[span.end], len(new_text))

            new_span = Sentence(start=new_start, end=new_end, metadata=span.metadata)

            if new_span is not None:
                new_spans.append(new_span)

    return new_text, new_spans


class OpenAIVisionProcessorBase(ProcessorBase):
    __doc__ = """Generate text using [OpenAI Text Completion](https://platform.openai.com/docs/guides/completion) API
    You input some text as a prompt, and the model will generate a text completion that attempts to match whatever context or pattern you gave it."""
    PREFIX: str = ""
    oauth_token: OAuthToken = OAuthToken()

    def compute_args(
        self,
        params: OpenAIVisionProcessorBaseParameters,
        source: str,
        kind,
        prompt: str = None,
        system_prompt: str = None,
    ) -> dict[str, Any]:
        if prompt is None:
            prompt = params.prompt
        if system_prompt is None:
            system_prompt = params.system_prompt
        if kind.mime.startswith("image"):
            binary_block = {"type": "image_url", "image_url": {"url": source}}
        messages = [{"role": "system", "content": system_prompt}] if system_prompt is not None else []
        messages.append({"role": "user", "content": [{"type": "text", "text": prompt}, binary_block]})
        kwargs = {
            "model": params.model_str,
            "messages": messages,
            "max_tokens": params.max_tokens,
            "temperature": params.temperature,
            "top_p": params.top_p,
            "n": params.n,
            "frequency_penalty": params.frequency_penalty,
            "presence_penalty": params.presence_penalty,
        }
        return kwargs

    def compute_result(self, base_url, **kwargs) -> tuple[str | None, str] | None:
        """Compute the result from OpenAI chat completion.

        Returns a tuple (mime_type, text) where mime_type is derived from the
        fenced code block language marker (e.g. "application/json") or None.
        """
        try:
            response = openai_chat_completion(self.PREFIX, self.oauth_token, base_url, **kwargs)
            contents = []
            content_type = None
            for choice in response.choices:
                if choice.message.content:
                    if "```" in choice.message.content:
                        lang, extracted = _extract_fenced_block(choice.message.content)
                        contents.append(extracted)
                        if lang is not None:
                            content_type = lang
                    else:
                        contents.append(choice.message.content)
            if contents:
                return content_type, "\n".join(contents)
        except Exception:
            logger.warning("Conversion of image failed", exc_info=True)
        return None

    def process(self, documents: list[Document], parameters: ProcessorParameters) -> list[Document]:
        # supported_languages = comma_separated_to_list(SUPPORTED_LANGUAGES)

        params: OpenAIVisionProcessorBaseParameters = cast(OpenAIVisionProcessorBaseParameters, parameters)
        OPENAI_MODEL = os.getenv(self.PREFIX + "OPENAI_MODEL", None)
        if OPENAI_MODEL:
            params.model_str = OPENAI_MODEL
        try:
            templ, prompt_templ = get_template(params.prompt)
            system_templ, system_prompt_templ = get_template(params.system_prompt)

            for document in documents:
                with add_logging_context(docid=document.identifier):
                    prompt = render_template(templ, prompt_templ, document, params)
                    system_prompt = render_template(system_templ, system_prompt_templ, document, params)
                    if document.altTexts:
                        altTexts = document.altTexts
                        alts = {altText.name: altText.text for altText in altTexts}
                        alt_mimes: dict[str, str] = {}
                        anames = list(alts.keys())
                        for aname in anames:
                            atext = alts[aname]
                            result = None
                            kind = guess_kind(atext)
                            if kind is not None and kind.mime.startswith("image"):
                                kwargs = self.compute_args(params, atext, kind, prompt, system_prompt)
                                if kwargs["model"] != NO_DEPLOYED_MODELS:
                                    result = self.compute_result(params.base_url, **kwargs)
                            if result is not None:
                                mime_type, text = result
                                alts[aname] = text
                                if mime_type:
                                    alt_mimes[aname] = mime_type
                            else:
                                del alts[aname]
                        if alts:
                            document.altTexts = []
                            if params.replace_refs_altTexts_by_descriptions:
                                text = document.text
                                link_regex = r"!\[([^]]+)\]\(([^)]+)\)"

                                def convert_links(matchobj, alts=alts):
                                    m = matchobj.group(0)
                                    m_id = matchobj.group(1)
                                    if m_id in alts:
                                        # markdown blockquote
                                        # m_desc = "\n".join(["> " + li for li in alts[m_id].splitlines()])
                                        m_desc = alts[m_id]
                                        return f"{m}\n{m_desc}\n"
                                    return m

                                new_text, new_sentences = regex_sub_preserve_spans(
                                    text, link_regex, convert_links, document.sentences, flags=re.MULTILINE
                                )
                                document.text = new_text
                                document.sentences = new_sentences
                                for altText in altTexts:
                                    if altText.name not in alts:
                                        document.altTexts.append(altText)
                            else:
                                for altText in altTexts:
                                    if altText.name in alts:
                                        props = (
                                            {"mime-type": alt_mimes[altText.name]}
                                            if altText.name in alt_mimes
                                            else None
                                        )
                                        document.altTexts.append(
                                            AltText(name=altText.name, text=alts[altText.name], properties=props)
                                        )
                                    else:
                                        document.altTexts.append(altText)

        except BaseException as err:
            raise err
        return documents

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return OpenAIVisionProcessorBaseParameters


class OpenAIVisionProcessorParameters(OpenAIVisionProcessorBaseParameters):
    base_url: str | None = Field(
        os.getenv(OPENAI_PREFIX + "OPENAI_API_BASE", None),
        description="""OpenAI endpoint base url""",
        json_schema_extra={"extra": "advanced"},
    )
    model: CHAT_GPT_MODEL_ENUM = Field(
        DEFAULT_CHAT_GPT_MODEL,
        description="""The [OpenAI model](https://platform.openai.com/docs/models) used for completion.""",
        json_schema_extra={"extra": "pipeline-naming-hint"},
    )


class OpenAIVisionProcessor(OpenAIVisionProcessorBase):
    __doc__ = """Replace image by description using [OpenAI](https://developers.openai.com/api/docs/models) API"""

    def process(self, documents: list[Document], parameters: ProcessorParameters) -> list[Document]:
        params: OpenAIVisionProcessorParameters = cast(OpenAIVisionProcessorParameters, parameters)
        model_str = params.model_str if bool(params.model_str and params.model_str.strip()) else None
        model = params.model.value if params.model is not None else None
        params.model_str = model_str or model
        return super().process(documents, params)

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return OpenAIVisionProcessorParameters


class DeepInfraOpenAIVisionProcessorParameters(OpenAIVisionProcessorBaseParameters):
    base_url: str = Field(
        os.getenv(DEEPINFRA_PREFIX + "OPENAI_API_BASE", None),
        description="""OpenAI endpoint base url""",
        json_schema_extra={"extra": "advanced"},
    )
    model: DEEPINFRA_CHAT_GPT_MODEL_ENUM = Field(
        None,
        description="""The [DeepInfra 'OpenAI compatible' model](https://deepinfra.com/models?type=text-generation) used for completion. It must be deployed on your [DeepInfra dashboard](https://deepinfra.com/dash).""",
        json_schema_extra={"extra": "pipeline-naming-hint"},
    )


class DeepInfraOpenAIVisionProcessor(OpenAIVisionProcessorBase):
    __doc__ = (
        """Replace image by description using [DeepInfra Vision](https://deepinfra.com/docs/tutorials/whisper) API"""
    )
    PREFIX = DEEPINFRA_PREFIX

    def process(self, documents: list[Document], parameters: ProcessorParameters) -> list[Document]:
        params: DeepInfraOpenAIVisionProcessorParameters = cast(DeepInfraOpenAIVisionProcessorParameters, parameters)
        model_str = params.model_str if bool(params.model_str and params.model_str.strip()) else None
        model = params.model.value if params.model is not None else None
        params.model_str = model_str or model
        return super().process(documents, params)

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return DeepInfraOpenAIVisionProcessorParameters
