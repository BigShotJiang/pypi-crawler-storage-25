"""Tests for AsyncVectorStore — uses in-memory async Qdrant."""
import pytest
import pytest_asyncio
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import DatetimeRange, Distance, Range

from mnemostack.vector import AsyncVectorStore, Hit


@pytest_asyncio.fixture
async def store():
    s = AsyncVectorStore.__new__(AsyncVectorStore)
    s.collection = "test_async"
    s.dimension = 4
    s.distance = Distance.COSINE
    s.client = AsyncQdrantClient(":memory:")
    await s.ensure_collection()
    yield s
    await s.close()


@pytest.mark.asyncio
async def test_async_ensure_collection_idempotent(store):
    created = await store.ensure_collection()
    assert not created  # already created in fixture


@pytest.mark.asyncio
async def test_async_collection_exists_reraises_non_not_found_errors():
    store = AsyncVectorStore.__new__(AsyncVectorStore)
    store.collection = "test_async"

    class FailingClient:
        async def get_collection(self, _collection):
            raise RuntimeError("qdrant auth failed")

    store.client = FailingClient()

    with pytest.raises(RuntimeError, match="qdrant auth failed"):
        await store.collection_exists()


@pytest.mark.asyncio
async def test_async_upsert_and_search(store):
    await store.upsert(1, [1.0, 0.0, 0.0, 0.0], {"text": "dog"})
    await store.upsert(2, [0.0, 1.0, 0.0, 0.0], {"text": "car"})
    hits = await store.search([1.0, 0.0, 0.0, 0.0], limit=1)
    assert len(hits) == 1
    assert isinstance(hits[0], Hit)
    assert hits[0].id == 1
    assert hits[0].payload["text"] == "dog"


@pytest.mark.asyncio
async def test_async_upsert_batch(store):
    points = [(i, [float(i) / 10, 0.0, 0.0, 0.0], {"idx": i}) for i in range(1, 6)]
    n = await store.upsert_batch(points)
    assert n == 5
    count = await store.count()
    assert count == 5


@pytest.mark.asyncio
async def test_async_search_with_filter(store):
    await store.upsert(1, [1.0, 0.0, 0.0, 0.0], {"class": "A"})
    await store.upsert(2, [1.0, 0.0, 0.0, 0.0], {"class": "B"})
    hits = await store.search([1.0, 0.0, 0.0, 0.0], limit=10, filters={"class": "B"})
    assert len(hits) == 1
    assert hits[0].id == 2


def test_async_build_filter_uses_datetime_range_for_iso_strings():
    filters = {
        "timestamp": {
            "gte": "2026-04-01T00:00:00+00:00",
            "lte": "2026-05-01T00:00:00+00:00",
        }
    }

    qfilter = AsyncVectorStore._build_filter(filters)

    cond = qfilter.must[0]
    assert cond.key == "timestamp"
    assert isinstance(cond.range, DatetimeRange)


def test_async_build_filter_keeps_numeric_range():
    qfilter = AsyncVectorStore._build_filter({"score": {"gte": 0.5, "lte": 1.0}})

    cond = qfilter.must[0]
    assert cond.key == "score"
    assert isinstance(cond.range, Range)


@pytest.mark.asyncio
async def test_async_context_manager():
    async with AsyncVectorStore(collection="test_ctx", dimension=4):
        # Just ensure we can call async methods
        # Skip actual Qdrant call if no real server — in-memory works
        pass
