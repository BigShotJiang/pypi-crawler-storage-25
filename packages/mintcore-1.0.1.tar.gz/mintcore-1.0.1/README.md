# MintCore

[![PyPI](https://img.shields.io/pypi/v/mintcore)](https://pypi.org/project/mintcore/)
[![Python](https://img.shields.io/pypi/pyversions/mintcore)](https://pypi.org/project/mintcore/)
[![License: SOCL-1.0](https://img.shields.io/badge/License-SOCL--1.0-blue.svg)](LICENSE)

Centralized virtual currency engine for game economies.

## Install

```bash
pip install mintcore           # core engine + CLI
pip install mintcore[bot]      # + Discord bot
pip install mintcore[dev]      # + dev/test tools
```

## Quickstart

```bash
# 1. Install
pip install mintcore[bot]

# 2. Write .env
mintcore init

# 3. Fill in DISCORD_TOKEN in .env

# 4. Start API (terminal 1)
mintcore start

# 5. Start bot (terminal 2)
python -m mintcore.bot.main
```

## Embed in your own app

```python
from mintcore import MintCore

engine = MintCore(database_url="sqlite:///./mygame.db", admin_key="s3cr3t")
engine.run(host="0.0.0.0", port=8000)
```

## CLI

```bash
mintcore start
mintcore admin currency GLD Gold G --supply-cap 1000000
mintcore admin mint player1 500 GLD
mintcore admin tax 5 GLD
mintcore admin richlist GLD
mintcore status
```

## Discord slash commands

| Command | Who | Description |
|---|---|---|
| `/balance` | Everyone | Your wallet balances |
| `/transfer @user amount currency` | Everyone | Send currency |
| `/loan amount currency` | Everyone | Borrow from treasury |
| `/repay amount currency` | Everyone | Pay back debt |
| `/ledger` | Everyone | Last 10 transactions |
| `/rate USD EUR` | Everyone | Exchange rate lookup |
| `/admin-mint @user amount currency` | MintAdmin | Mint currency |
| `/admin-burn @user amount currency` | MintAdmin | Burn currency |
| `/admin-tax percentage currency` | MintAdmin | Tax sweep |
| `/admin-interest` | MintAdmin | Apply interest |
| `/admin-currency id name symbol` | MintAdmin | Create currency |
| `/stats` | Everyone | Economy snapshot |
| `/richlist currency` | Everyone | Top holders |

## Publishing to PyPI

```bash
pip install hatch twine
hatch build
twine upload dist/*
```

GitHub: https://github.com/TheServer-lab/mintcore