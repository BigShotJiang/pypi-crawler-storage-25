# FIX 3: Removed manual tx_id generation — Transaction.tx_id already has
# default=_uuid() in models.py, so setting it here was redundant.
# Also removed unused `import uuid`.
from mintcore.models import Wallet, Transaction

def get_or_create_wallet(db, user_id: str, currency_id: str) -> Wallet:
    wallet = db.query(Wallet).filter_by(user_id=user_id, currency_id=currency_id).first()
    if not wallet:
        wallet = Wallet(user_id=user_id, currency_id=currency_id, balance=0)
        db.add(wallet)
        db.flush()
    return wallet

def log_tx(db, type: str, currency_id, from_user: str, to_user: str, amount: int):
    db.add(Transaction(
        type        = type,
        currency_id = currency_id,
        from_user   = from_user,
        to_user     = to_user,
        amount      = amount,
    ))