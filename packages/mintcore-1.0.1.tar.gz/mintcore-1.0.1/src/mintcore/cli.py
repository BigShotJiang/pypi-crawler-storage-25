import os
import typer
import httpx
from rich.console import Console
from rich.table   import Table
from rich.panel   import Panel

app   = typer.Typer(help="MintCore — virtual currency engine CLI")
adm   = typer.Typer(help="Admin commands")
app.add_typer(adm, name="admin")

console = Console()

def _url():    return os.getenv("MINTCORE_URL", "http://127.0.0.1:8000")
def _headers(): return {"X-Admin-Key": os.getenv("MINTCORE_ADMIN_KEY", "admin-secret")}

@app.command()
def start(
    host:   str  = typer.Option("127.0.0.1"),
    port:   int  = typer.Option(8000),
    reload: bool = typer.Option(False),
):
    """Start the MintCore API server."""
    import uvicorn
    console.print(Panel(
        f"[bold green]MintCore[/] starting on [cyan]http://{host}:{port}[/]\n"
        f"Docs → [cyan]http://{host}:{port}/docs[/]",
        title="MintCore", border_style="green",
    ))
    uvicorn.run("mintcore.app:create_app", host=host, port=port,
                reload=reload, factory=True)

@app.command()
def init():
    """Write a .env template to the current directory."""
    if os.path.exists(".env"):
        console.print("[yellow].env already exists — skipping.[/]")
        return
    with open(".env", "w") as f:
        f.write(
            "DISCORD_TOKEN=your-bot-token-here\n"
            "MINTCORE_ADMIN_KEY=admin-secret\n"
            "MINTCORE_DB_URL=sqlite:///./mintcore.db\n"
            "MINTCORE_TREASURY=treasury\n"
            "MINTCORE_INTEREST_RATE=5\n"
            "MINTCORE_DEBT_CAP=-1000\n"
            "MINTCORE_CACHE_TTL=300\n"
        )
    console.print("[green]✓ .env written.[/] Fill in DISCORD_TOKEN before starting the bot.")

@app.command()
def status():
    """Check whether the MintCore server is reachable."""
    try:
        r = httpx.get(f"{_url()}/analytics/stats", timeout=3.0)
        data = r.json()
        console.print(Panel(
            f"[green]● Online[/]  {_url()}\n\n"
            f"Users: [bold]{data['user_count']}[/]   "
            f"Transactions: [bold]{data['total_tx']}[/]",
            title="MintCore Status", border_style="green",
        ))
    except Exception:
        console.print(Panel(
            f"[red]● Offline[/]  {_url()}\nTry: mintcore start",
            title="MintCore Status", border_style="red",
        ))

@adm.command("mint")
def admin_mint(to: str, amount: int, currency: str):
    """Mint currency to a user."""
    r = httpx.post(f"{_url()}/admin/mint",
                   json={"to": to, "amount": amount, "currency_id": currency},
                   headers=_headers())
    console.print(r.json())

@adm.command("burn")
def admin_burn(from_user: str, amount: int, currency: str):
    """Burn currency from a user."""
    r = httpx.post(f"{_url()}/admin/burn",
                   json={"from_user": from_user, "amount": amount, "currency_id": currency},
                   headers=_headers())
    console.print(r.json())

@adm.command("tax")
def admin_tax(percentage: int, currency: str):
    """Apply a tax sweep."""
    r = httpx.post(f"{_url()}/admin/tax",
                   json={"percentage": percentage, "currency_id": currency},
                   headers=_headers())
    console.print(r.json())

@adm.command("interest")
def admin_interest():
    """Apply interest to all debts."""
    r = httpx.post(f"{_url()}/admin/apply-interest", headers=_headers())
    console.print(r.json())

@adm.command("currency")
def admin_currency(
    currency_id: str,
    name:        str,
    symbol:      str,
    supply_cap:  int = typer.Option(0),
):
    """Create a new virtual currency."""
    payload = {"currency_id": currency_id, "name": name, "symbol": symbol}
    if supply_cap > 0:
        payload["supply_cap"] = supply_cap
    r = httpx.post(f"{_url()}/admin/currency", json=payload, headers=_headers())
    console.print(r.json())

@adm.command("stats")
def admin_stats():
    """Economy snapshot."""
    r    = httpx.get(f"{_url()}/analytics/stats")
    data = r.json()
    t    = Table("Metric", "Value")
    t.add_row("Users",        str(data["user_count"]))
    t.add_row("Transactions", str(data["total_tx"]))
    t.add_row("Total debt",   str(data["total_debt"]))
    for cid, supply in data.get("supply_by_currency", {}).items():
        t.add_row(f"Supply ({cid})", str(supply))
    console.print(t)

@adm.command("richlist")
def admin_richlist(currency: str, limit: int = typer.Option(10)):
    """Top holders for a currency."""
    r    = httpx.get(f"{_url()}/analytics/richlist/{currency}?limit={limit}")
    data = r.json()
    t    = Table("Rank", "User", "Balance")
    for i, row in enumerate(data["richlist"], 1):
        t.add_row(str(i), row["user_id"], f"{row['balance']:,}")
    console.print(t)

if __name__ == "__main__":
    app()