import os
from dotenv import load_dotenv

load_dotenv()

ADMIN_KEY     = os.getenv("MINTCORE_ADMIN_KEY",      "admin-secret")
TREASURY_ID   = os.getenv("MINTCORE_TREASURY",       "treasury")
DATABASE_URL  = os.getenv("MINTCORE_DB_URL",         "sqlite:///./mintcore.db")
INTEREST_RATE = int(os.getenv("MINTCORE_INTEREST_RATE", "5"))
DEBT_CAP      = int(os.getenv("MINTCORE_DEBT_CAP",      "-1000"))
CACHE_TTL     = int(os.getenv("MINTCORE_CACHE_TTL",     "300"))
LIVE_RATE_URL = "https://open.er-api.com/v6/latest/{base}"