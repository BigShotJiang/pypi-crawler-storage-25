from fastapi import APIRouter, HTTPException, Header
from sqlalchemy import func
from mintcore.database import get_db
from mintcore.models import User, Currency, Wallet, ExchangeRate
from mintcore.schemas import CreateCurrency, Mint, Burn, Tax, Loan, SetRate
from mintcore import config
from mintcore.helpers import get_or_create_wallet, log_tx

router = APIRouter(prefix="/admin", tags=["admin"])

def _auth(key: str):
    if key != config.ADMIN_KEY:
        raise HTTPException(403, "Unauthorized")

@router.post("/currency")
def create_currency(data: CreateCurrency, x_admin_key: str = Header(None)):
    _auth(x_admin_key)
    with get_db() as db:
        if db.query(Currency).filter_by(currency_id=data.currency_id).first():
            raise HTTPException(400, "Currency already exists")
        db.add(Currency(**data.model_dump()))
        db.commit()
    return {"status": "currency_created", "currency_id": data.currency_id}

@router.get("/currency")
def list_currencies(x_admin_key: str = Header(None)):
    _auth(x_admin_key)
    with get_db() as db:
        return [{"currency_id": c.currency_id, "name": c.name,
                 "symbol": c.symbol, "supply_cap": c.supply_cap}
                for c in db.query(Currency).all()]

@router.post("/rates")
def set_rate(data: SetRate, x_admin_key: str = Header(None)):
    _auth(x_admin_key)
    with get_db() as db:
        existing = db.query(ExchangeRate).filter_by(
            base_currency=data.base, target_currency=data.target).first()
        if existing:
            existing.rate = data.rate
        else:
            db.add(ExchangeRate(base_currency=data.base,
                                target_currency=data.target, rate=data.rate))
        db.commit()
    return {"status": "rate_set", "pair": f"{data.base}/{data.target}", "rate": data.rate}

@router.post("/mint")
def mint(data: Mint, x_admin_key: str = Header(None)):
    _auth(x_admin_key)
    with get_db() as db:
        cur = db.query(Currency).filter_by(currency_id=data.currency_id).first()
        if not cur:
            raise HTTPException(404, "Currency not found")
        if cur.supply_cap is not None:
            total = db.query(func.sum(Wallet.balance)).filter_by(
                currency_id=data.currency_id).scalar() or 0
            if total + data.amount > cur.supply_cap:
                raise HTTPException(400, "SUPPLY_CAP_EXCEEDED")
        if not db.query(User).filter_by(user_id=data.to).first():
            db.add(User(user_id=data.to))
        wallet = get_or_create_wallet(db, data.to, data.currency_id)
        wallet.balance += data.amount
        log_tx(db, "mint", data.currency_id, "system", data.to, data.amount)
        db.commit()
    return {"status": "minted", "to": data.to,
            "amount": data.amount, "currency": data.currency_id}

@router.post("/burn")
def burn(data: Burn, x_admin_key: str = Header(None)):
    _auth(x_admin_key)
    with get_db() as db:
        wallet = get_or_create_wallet(db, data.from_user, data.currency_id)
        if wallet.balance < data.amount:
            raise HTTPException(400, "INSUFFICIENT_BALANCE_TO_BURN")
        wallet.balance -= data.amount
        log_tx(db, "burn", data.currency_id, data.from_user, "system", data.amount)
        db.commit()
    return {"status": "burned", "amount": data.amount}

@router.post("/tax")
def apply_tax(data: Tax, x_admin_key: str = Header(None)):
    _auth(x_admin_key)
    collected = 0
    with get_db() as db:
        treasury = get_or_create_wallet(db, config.TREASURY_ID, data.currency_id)
        wallets  = db.query(Wallet).filter(
            Wallet.currency_id == data.currency_id,
            Wallet.user_id    != config.TREASURY_ID,
            Wallet.balance     > 0,
        ).all()
        for w in wallets:
            tax = int(w.balance * (data.percentage / 100))
            if tax == 0:
                continue
            w.balance        -= tax
            treasury.balance += tax
            collected        += tax
            log_tx(db, "tax", data.currency_id, w.user_id, config.TREASURY_ID, tax)
        db.commit()
    return {"status": "tax_applied", "rate": data.percentage,
            "currency": data.currency_id, "total_collected": collected}

@router.post("/loan")
def give_loan(data: Loan, x_admin_key: str = Header(None)):
    _auth(x_admin_key)
    with get_db() as db:
        user = db.query(User).filter_by(user_id=data.user_id).first()
        if not user:
            raise HTTPException(404, "User not found")
        treasury = get_or_create_wallet(db, config.TREASURY_ID, data.currency_id)
        # FIX 2: Treasury cannot issue loans it can't cover — prevents treasury
        # balance from silently going negative and corrupting economy stats.
        if treasury.balance < data.amount:
            raise HTTPException(400, "TREASURY_INSUFFICIENT_FUNDS")
        wallet              = get_or_create_wallet(db, data.user_id, data.currency_id)
        user.debt              += data.amount
        wallet.balance         += data.amount
        treasury.balance       -= data.amount
        log_tx(db, "loan", data.currency_id, config.TREASURY_ID, data.user_id, data.amount)
        db.commit()
    return {"status": "loan_given", "debt": user.debt}

@router.post("/apply-interest")
def apply_interest(x_admin_key: str = Header(None)):
    _auth(x_admin_key)
    total_interest = 0
    with get_db() as db:
        for user in db.query(User).filter(User.debt > 0).all():
            interest = int(user.debt * (config.INTEREST_RATE / 100))
            if interest == 0:
                continue
            user.debt      += interest
            total_interest += interest
            log_tx(db, "interest", None, user.user_id, config.TREASURY_ID, interest)
        db.commit()
    return {"status": "interest_applied",
            "rate": config.INTEREST_RATE, "total_charged": total_interest}