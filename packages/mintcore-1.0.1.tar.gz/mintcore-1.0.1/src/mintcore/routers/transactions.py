from fastapi import APIRouter, HTTPException
from mintcore.database import get_db
from mintcore.models import User, Transaction
from mintcore.schemas import Transfer, Repay
from mintcore import config
from mintcore.helpers import get_or_create_wallet, log_tx

router = APIRouter(tags=["transactions"])

@router.post("/transactions/transfer")
def transfer(data: Transfer):
    with get_db() as db:
        sender   = db.query(User).filter_by(user_id=data.from_user).first()
        receiver = db.query(User).filter_by(user_id=data.to_user).first()
        if not sender or not receiver:
            raise HTTPException(404, "User not found")
        sw = get_or_create_wallet(db, data.from_user, data.currency_id)
        rw = get_or_create_wallet(db, data.to_user,   data.currency_id)
        if sw.balance - data.amount < config.DEBT_CAP:
            raise HTTPException(400, "DEBT_LIMIT_EXCEEDED")
        sw.balance -= data.amount
        rw.balance += data.amount
        # FIX 1: Removed `sender.debt = abs(sw.balance)` — the debt field
        # is exclusively for loan obligations (tracked in /admin/loan and
        # /repay). Wallet balance going negative is a transfer overdraft and
        # is already enforced by DEBT_CAP above. Mixing the two caused debt
        # to be set by transfers but never cleared when balance recovered.
        log_tx(db, "transfer", data.currency_id, data.from_user, data.to_user, data.amount)
        db.commit()
    return {"status": "success", "from_balance": sw.balance, "to_balance": rw.balance}

@router.post("/repay")
def repay_loan(data: Repay):
    with get_db() as db:
        user = db.query(User).filter_by(user_id=data.user_id).first()
        if not user:
            raise HTTPException(404, "User not found")
        wallet = get_or_create_wallet(db, data.user_id, data.currency_id)
        if wallet.balance < data.amount:
            raise HTTPException(400, "INSUFFICIENT_FUNDS")
        repay_amount = min(data.amount, user.debt)
        if repay_amount == 0:
            raise HTTPException(400, "NO_DEBT_TO_REPAY")
        treasury_w          = get_or_create_wallet(db, config.TREASURY_ID, data.currency_id)
        wallet.balance     -= repay_amount
        user.debt          -= repay_amount
        treasury_w.balance += repay_amount
        log_tx(db, "repay", data.currency_id, data.user_id, config.TREASURY_ID, repay_amount)
        db.commit()
    return {
        "status":         "repaid",
        "repaid_amount":  repay_amount,
        "remaining_debt": user.debt,
        "excess_ignored": data.amount - repay_amount,
    }

@router.get("/ledger")
def get_ledger():
    with get_db() as db:
        txs = db.query(Transaction).order_by(Transaction.timestamp.desc()).all()
        return [_fmt(t) for t in txs]

@router.get("/ledger/{user_id}")
def get_user_ledger(user_id: str):
    with get_db() as db:
        txs = db.query(Transaction).filter(
            (Transaction.from_user == user_id) | (Transaction.to_user == user_id)
        ).order_by(Transaction.timestamp.desc()).all()
        return [_fmt(t) for t in txs]

def _fmt(t):
    return {
        "tx_id": t.tx_id, "type": t.type, "currency_id": t.currency_id,
        "from_user": t.from_user, "to_user": t.to_user,
        "amount": t.amount, "timestamp": str(t.timestamp),
    }