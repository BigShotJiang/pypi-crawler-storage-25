from __future__ import annotations
import uvicorn
from mintcore.app import create_app

class MintCore:
    def __init__(
        self,
        database_url: str  = "sqlite:///./mintcore.db",
        admin_key: str     = "admin-secret",
        treasury_id: str   = "treasury",
        interest_rate: int = 5,
        debt_cap: int      = -1000,
        cache_ttl: int     = 300,
    ):
        from mintcore import config as _cfg
        _cfg.DATABASE_URL  = database_url
        _cfg.ADMIN_KEY     = admin_key
        _cfg.TREASURY_ID   = treasury_id
        _cfg.INTEREST_RATE = interest_rate
        _cfg.DEBT_CAP      = debt_cap
        _cfg.CACHE_TTL     = cache_ttl
        self._app = create_app()

    @property
    def app(self):
        return self._app

    def run(self, host: str = "127.0.0.1", port: int = 8000, **kwargs):
        uvicorn.run(self._app, host=host, port=port, **kwargs)