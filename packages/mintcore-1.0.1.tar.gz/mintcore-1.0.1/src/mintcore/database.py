from contextlib import contextmanager
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import StaticPool
from mintcore import config

def _make_engine():
    url = config.DATABASE_URL
    if ":memory:" in url:
        # StaticPool: all sessions share one physical connection.
        # Required for SQLite in-memory so that tables created by
        # create_all() are visible to subsequent ORM queries.
        return create_engine(
            url,
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
        )
    return create_engine(url, connect_args={"check_same_thread": False})

engine       = _make_engine()
# expire_on_commit=False: attributes are NOT cleared after commit, so they
# can be read outside the `with get_db()` block without triggering a lazy
# reload on a closed session (which raises DetachedInstanceError).
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
Base         = declarative_base()

@contextmanager
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()