import os
import asyncio
import discord
from discord.ext import commands
from dotenv import load_dotenv
from mintcore.bot.client import close_client

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN or TOKEN == "your-bot-token-here":
    raise RuntimeError(
        "DISCORD_TOKEN not set.\n"
        "1. Open .env in this folder\n"
        "2. Replace 'your-bot-token-here' with your token from\n"
        "   https://discord.com/developers/applications"
    )

intents         = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

COGS = [
    "mintcore.bot.cogs.player",
    "mintcore.bot.cogs.admin",
]

@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"[MintCore Bot] Logged in as {bot.user}")
    print(f"[MintCore Bot] Slash commands synced.")
    print(f"[MintCore Bot] Serving {len(bot.guilds)} server(s).")

@bot.event
async def on_disconnect():
    await close_client()

async def main():
    async with bot:
        for cog in COGS:
            await bot.load_extension(cog)
            print(f"[MintCore Bot] Loaded cog: {cog}")
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())