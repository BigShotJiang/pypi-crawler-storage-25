import discord
from discord import app_commands
from discord.ext import commands
import httpx

from mintcore.bot import client as mc
from mintcore.bot.embeds import (
    balance_embed, transfer_embed, loan_embed,
    repay_embed, ledger_embed, rate_embed, error_embed,
)

class PlayerCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="balance", description="Check your wallet balances")
    async def balance(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)
        await mc.ensure_user(uid)
        try:
            data = await mc.get_balance(uid)
            await interaction.followup.send(
                embed=balance_embed(interaction.user.display_name, data), ephemeral=True)
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Unknown error")),
                ephemeral=True)

    @app_commands.command(name="transfer", description="Send currency to another player")
    @app_commands.describe(recipient="Player to send to", amount="Amount", currency="Currency ID e.g. GLD")
    async def transfer(self, interaction: discord.Interaction,
                       recipient: discord.Member, amount: int, currency: str):
        await interaction.response.defer(ephemeral=True)
        if amount <= 0:
            return await interaction.followup.send(
                embed=error_embed("Amount must be greater than 0"), ephemeral=True)
        if recipient.id == interaction.user.id:
            return await interaction.followup.send(
                embed=error_embed("You can't transfer to yourself"), ephemeral=True)
        from_uid = str(interaction.user.id)
        to_uid   = str(recipient.id)
        await mc.ensure_user(from_uid)
        await mc.ensure_user(to_uid)
        try:
            data = await mc.transfer(from_uid, to_uid, amount, currency.upper())
            await interaction.followup.send(
                embed=transfer_embed(interaction.user.display_name,
                                     recipient.display_name, amount,
                                     currency.upper(), data["from_balance"]),
                ephemeral=True)
        except httpx.HTTPStatusError as e:
            detail = e.response.json().get("detail", "Transfer failed")
            msgs   = {"DEBT_LIMIT_EXCEEDED": "You've hit your debt limit."}
            await interaction.followup.send(
                embed=error_embed(msgs.get(detail, detail)), ephemeral=True)

    @app_commands.command(name="loan", description="Take a loan from the treasury")
    @app_commands.describe(amount="Amount to borrow", currency="Currency ID e.g. GLD")
    async def loan(self, interaction: discord.Interaction, amount: int, currency: str):
        await interaction.response.defer(ephemeral=True)
        if amount <= 0:
            return await interaction.followup.send(
                embed=error_embed("Amount must be greater than 0"), ephemeral=True)
        uid = str(interaction.user.id)
        await mc.ensure_user(uid)
        try:
            data = await mc.take_loan(uid, amount, currency.upper())
            await interaction.followup.send(
                embed=loan_embed(interaction.user.display_name, amount,
                                 currency.upper(), data["debt"]),
                ephemeral=True)
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Loan failed")),
                ephemeral=True)

    @app_commands.command(name="repay", description="Repay your outstanding loan")
    @app_commands.describe(amount="Amount to repay", currency="Currency ID e.g. GLD")
    async def repay(self, interaction: discord.Interaction, amount: int, currency: str):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)
        await mc.ensure_user(uid)
        try:
            data = await mc.repay_loan(uid, amount, currency.upper())
            await interaction.followup.send(
                embed=repay_embed(interaction.user.display_name,
                                  data["repaid_amount"], currency.upper(),
                                  data["remaining_debt"], data["excess_ignored"]),
                ephemeral=True)
        except httpx.HTTPStatusError as e:
            detail = e.response.json().get("detail", "Repay failed")
            msgs   = {
                "INSUFFICIENT_FUNDS": "You don't have enough funds.",
                "NO_DEBT_TO_REPAY":   "You have no outstanding debt.",
            }
            await interaction.followup.send(
                embed=error_embed(msgs.get(detail, detail)), ephemeral=True)

    @app_commands.command(name="ledger", description="View your last 10 transactions")
    async def ledger(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)
        await mc.ensure_user(uid)
        try:
            txs = await mc.get_ledger(uid)
            await interaction.followup.send(
                embed=ledger_embed(interaction.user.display_name, txs), ephemeral=True)
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Error")), ephemeral=True)

    @app_commands.command(name="rate", description="Check an exchange rate")
    @app_commands.describe(base="Base currency e.g. USD", target="Target currency e.g. EUR")
    async def rate(self, interaction: discord.Interaction, base: str, target: str):
        await interaction.response.defer(ephemeral=True)
        try:
            data = await mc.get_rate(base.upper(), target.upper())
            await interaction.followup.send(
                embed=rate_embed(base.upper(), target.upper(),
                                 data["rate"], data["source"]),
                ephemeral=True)
        except httpx.HTTPStatusError:
            await interaction.followup.send(
                embed=error_embed(f"No rate found for {base.upper()}/{target.upper()}"),
                ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(PlayerCog(bot))