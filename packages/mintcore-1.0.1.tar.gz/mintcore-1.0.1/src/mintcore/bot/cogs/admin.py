import os
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
import httpx

from mintcore.bot import client as mc
from mintcore.bot.embeds import (
    mint_embed, burn_embed, tax_embed, stats_embed,
    richlist_embed, interest_embed, error_embed,
)

load_dotenv()
ADMIN_ROLE = os.getenv("ADMIN_ROLE_NAME", "MintAdmin")

def is_admin(interaction: discord.Interaction) -> bool:
    return ADMIN_ROLE in [r.name for r in interaction.user.roles]

async def _deny(interaction: discord.Interaction):
    await interaction.response.send_message(
        embed=error_embed(f"You need the **{ADMIN_ROLE}** role to use this command."),
        ephemeral=True)

class AdminCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="admin-mint", description="[Admin] Mint currency to a user")
    @app_commands.describe(recipient="Target member", amount="Amount", currency="Currency ID")
    async def admin_mint(self, interaction: discord.Interaction,
                         recipient: discord.Member, amount: int, currency: str):
        if not is_admin(interaction):
            return await _deny(interaction)
        await interaction.response.defer(ephemeral=True)
        try:
            await mc.ensure_user(str(recipient.id))
            await mc.admin_mint(str(recipient.id), amount, currency.upper())
            await interaction.followup.send(
                embed=mint_embed(recipient.display_name, amount, currency.upper()),
                ephemeral=True)
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Mint failed")),
                ephemeral=True)

    @app_commands.command(name="admin-burn", description="[Admin] Burn currency from a user")
    @app_commands.describe(target="Target member", amount="Amount", currency="Currency ID")
    async def admin_burn(self, interaction: discord.Interaction,
                         target: discord.Member, amount: int, currency: str):
        if not is_admin(interaction):
            return await _deny(interaction)
        await interaction.response.defer(ephemeral=True)
        try:
            await mc.admin_burn(str(target.id), amount, currency.upper())
            await interaction.followup.send(
                embed=burn_embed(target.display_name, amount, currency.upper()),
                ephemeral=True)
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Burn failed")),
                ephemeral=True)

    @app_commands.command(name="admin-tax", description="[Admin] Apply a tax sweep")
    @app_commands.describe(percentage="Tax percentage 1-100", currency="Currency ID")
    async def admin_tax(self, interaction: discord.Interaction,
                        percentage: int, currency: str):
        if not is_admin(interaction):
            return await _deny(interaction)
        await interaction.response.defer(ephemeral=True)
        try:
            data = await mc.admin_tax(percentage, currency.upper())
            await interaction.followup.send(
                embed=tax_embed(percentage, currency.upper(), data["total_collected"]),
                ephemeral=True)
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Tax failed")),
                ephemeral=True)

    @app_commands.command(name="admin-interest", description="[Admin] Apply interest to all debts")
    async def admin_interest(self, interaction: discord.Interaction):
        if not is_admin(interaction):
            return await _deny(interaction)
        await interaction.response.defer(ephemeral=True)
        try:
            data = await mc.admin_apply_interest()
            await interaction.followup.send(
                embed=interest_embed(data["rate"], data["total_charged"]), ephemeral=True)
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Failed")),
                ephemeral=True)

    @app_commands.command(name="admin-currency", description="[Admin] Create a new currency")
    @app_commands.describe(currency_id="Short ID e.g. GLD", name="Full name e.g. Gold",
                           symbol="Symbol e.g. G", supply_cap="Max supply (0 = unlimited)")
    async def admin_currency(self, interaction: discord.Interaction,
                             currency_id: str, name: str, symbol: str, supply_cap: int = 0):
        if not is_admin(interaction):
            return await _deny(interaction)
        await interaction.response.defer(ephemeral=True)
        cap = supply_cap if supply_cap > 0 else None
        try:
            await mc.admin_create_currency(currency_id.upper(), name, symbol, cap)
            e = discord.Embed(title="Currency Created", color=0x2ECC71)
            e.add_field(name="ID",         value=f"`{currency_id.upper()}`", inline=True)
            e.add_field(name="Name",       value=f"`{name}`",                inline=True)
            e.add_field(name="Symbol",     value=f"`{symbol}`",              inline=True)
            e.add_field(name="Supply cap", value=f"`{supply_cap:,}`" if cap else "`Unlimited`", inline=True)
            await interaction.followup.send(embed=e, ephemeral=True)
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Failed")),
                ephemeral=True)

    @app_commands.command(name="stats", description="Economy-wide stats")
    async def stats(self, interaction: discord.Interaction):
        await interaction.response.defer()
        try:
            data = await mc.get_stats()
            await interaction.followup.send(embed=stats_embed(data))
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Error")), ephemeral=True)

    @app_commands.command(name="richlist", description="Top holders for a currency")
    @app_commands.describe(currency="Currency ID", limit="How many to show (max 10)")
    async def richlist(self, interaction: discord.Interaction,
                       currency: str, limit: int = 10):
        await interaction.response.defer()
        try:
            data = await mc.get_richlist(currency.upper(), min(limit, 10))
            await interaction.followup.send(
                embed=richlist_embed(currency.upper(), data["richlist"]))
        except httpx.HTTPStatusError as e:
            await interaction.followup.send(
                embed=error_embed(e.response.json().get("detail", "Error")), ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(AdminCog(bot))