import discord
from datetime import datetime

GOLD   = 0xF4C430
GREEN  = 0x2ECC71
RED    = 0xE74C3C
BLUE   = 0x3498DB
PURPLE = 0x9B59B6

def _base(title: str, color: int) -> discord.Embed:
    e = discord.Embed(title=title, color=color, timestamp=datetime.utcnow())
    e.set_footer(text="MintCore Economy Engine")
    return e

def balance_embed(username: str, data: dict) -> discord.Embed:
    e = _base(f"Wallet — {username}", GOLD)
    wallets = data.get("wallets", {})
    wallet_lines = "\n".join(
        f"**{cid}** — `{bal:,}`" for cid, bal in wallets.items()
    ) if wallets else "*No currency yet*"
    e.add_field(name="Balances", value=wallet_lines, inline=False)
    if data.get("debt", 0) > 0:
        e.add_field(name="Outstanding Debt", value=f"`{data['debt']:,}`", inline=False)
        e.color = 0xE67E22
    return e

def transfer_embed(from_user, to_user, amount, currency_id, new_balance) -> discord.Embed:
    e = _base("Transfer Complete", GREEN)
    e.add_field(name="From",             value=f"`{from_user}`",             inline=True)
    e.add_field(name="To",               value=f"`{to_user}`",               inline=True)
    e.add_field(name="Amount",           value=f"`{amount:,} {currency_id}`", inline=True)
    e.add_field(name="Your new balance", value=f"`{new_balance:,}`",          inline=False)
    return e

def loan_embed(user, amount, currency_id, total_debt) -> discord.Embed:
    e = _base("Loan Issued", BLUE)
    e.add_field(name="Recipient",  value=f"`{user}`",                inline=True)
    e.add_field(name="Amount",     value=f"`{amount:,} {currency_id}`", inline=True)
    e.add_field(name="Total debt", value=f"`{total_debt:,}`",         inline=False)
    return e

def repay_embed(user, repaid, currency_id, remaining, excess) -> discord.Embed:
    e = _base("Loan Repaid", GREEN)
    e.add_field(name="Repaid",         value=f"`{repaid:,} {currency_id}`", inline=True)
    e.add_field(name="Remaining debt", value=f"`{remaining:,}`",            inline=True)
    if excess > 0:
        e.add_field(name="Note",
                    value=f"`{excess:,}` was not applied (no remaining debt)",
                    inline=False)
    return e

def ledger_embed(username: str, txs: list) -> discord.Embed:
    e = _base(f"Ledger — {username}", PURPLE)
    if not txs:
        e.description = "*No transactions yet.*"
        return e
    lines = []
    for tx in txs[:10]:
        ts   = str(tx.get("timestamp", ""))[:10]
        kind = tx["type"].upper()
        cid  = tx.get("currency_id") or ""
        amt  = f"{tx['amount']:,}"
        lines.append(f"`{ts}` **{kind}** {amt} {cid}  {tx['from_user']} → {tx['to_user']}")
    e.description = "\n".join(lines)
    return e

def rate_embed(base, target, rate, source) -> discord.Embed:
    e = _base("Exchange Rate", GOLD)
    e.add_field(name="Pair",   value=f"`{base} / {target}`", inline=True)
    e.add_field(name="Rate",   value=f"`{rate}`",            inline=True)
    e.add_field(name="Source", value=f"`{source}`",          inline=True)
    return e

def error_embed(msg: str) -> discord.Embed:
    return _base(f"Error: {msg}", RED)

def mint_embed(to, amount, currency_id) -> discord.Embed:
    e = _base("Minted", GREEN)
    e.add_field(name="To",     value=f"`{to}`",                    inline=True)
    e.add_field(name="Amount", value=f"`{amount:,} {currency_id}`", inline=True)
    return e

def burn_embed(from_user, amount, currency_id) -> discord.Embed:
    e = _base("Burned", RED)
    e.add_field(name="From",   value=f"`{from_user}`",             inline=True)
    e.add_field(name="Amount", value=f"`{amount:,} {currency_id}`", inline=True)
    return e

def tax_embed(rate, currency_id, collected) -> discord.Embed:
    e = _base("Tax Applied", GOLD)
    e.add_field(name="Rate",      value=f"`{rate}%`",     inline=True)
    e.add_field(name="Currency",  value=f"`{currency_id}`", inline=True)
    e.add_field(name="Collected", value=f"`{collected:,}`", inline=True)
    return e

def stats_embed(data: dict) -> discord.Embed:
    e = _base("Economy Stats", BLUE)
    e.add_field(name="Users",        value=f"`{data['user_count']:,}`", inline=True)
    e.add_field(name="Transactions", value=f"`{data['total_tx']:,}`",   inline=True)
    e.add_field(name="Total debt",   value=f"`{data['total_debt']:,}`", inline=True)
    supply = data.get("supply_by_currency", {})
    if supply:
        e.add_field(name="Supply",
                    value="\n".join(f"**{cid}** — `{amt:,}`" for cid, amt in supply.items()),
                    inline=False)
    return e

def richlist_embed(currency_id: str, entries: list) -> discord.Embed:
    e = _base(f"Richlist — {currency_id}", GOLD)
    medals = ["🥇", "🥈", "🥉"]
    lines  = [
        f"{medals[i] if i < 3 else f'`#{i+1}`'} `{row['user_id']}` — **{row['balance']:,}**"
        for i, row in enumerate(entries)
    ]
    e.description = "\n".join(lines) if lines else "*No holders yet.*"
    return e

def interest_embed(rate, total_charged) -> discord.Embed:
    e = _base("Interest Applied", GOLD)
    e.add_field(name="Rate",          value=f"`{rate}%`",           inline=True)
    e.add_field(name="Total charged", value=f"`{total_charged:,}`", inline=True)
    return e