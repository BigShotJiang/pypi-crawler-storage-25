# setup_module removed — seed data is now in conftest.py::seed_data (autouse)

def test_mint_and_balance(client, admin_headers):
    client.post("/admin/mint",
                json={"to": "alice", "amount": 500, "currency_id": "GLD"},
                headers=admin_headers)
    r = client.get("/users/alice/balance")
    assert r.status_code == 200
    assert r.json()["wallets"]["GLD"] == 500

def test_transfer(client):
    r = client.post("/transactions/transfer", json={
        "from_user": "alice", "to_user": "bob",
        "amount": 100, "currency_id": "GLD",
    })
    assert r.status_code == 200
    assert r.json()["from_balance"] == 400

def test_debt_cap(client):
    r = client.post("/transactions/transfer", json={
        "from_user": "bob", "to_user": "alice",
        "amount": 9999, "currency_id": "GLD",
    })
    assert r.status_code == 400

def test_analytics(client):
    r = client.get("/analytics/stats")
    assert "user_count" in r.json()

def test_transfer_does_not_corrupt_loan_debt(client, admin_headers):
    """Fix 1 regression: a transfer that causes overdraft must NOT touch
    user.debt (which is reserved for loan obligations only)."""
    # seed a fresh user so debt starts at 0
    client.post("/users", json={"user_id": "carol"})
    # give carol some balance
    client.post("/admin/mint",
                json={"to": "carol", "amount": 50, "currency_id": "GLD"},
                headers=admin_headers)
    # transfer more than carol has — goes into overdraft
    client.post("/transactions/transfer", json={
        "from_user": "carol", "to_user": "alice",
        "amount": 50, "currency_id": "GLD",
    })
    # carol has 0 balance, but debt field must still be 0 (no loan taken)
    r = client.get("/users/carol/balance")
    assert r.json()["debt"] == 0

def test_treasury_floor_on_loan(client, admin_headers):
    """Fix 2 regression: loan must fail if treasury can't cover it."""
    client.post("/users", json={"user_id": "dave"})
    r = client.post("/admin/loan",
                    json={"user_id": "dave", "amount": 99_999_999, "currency_id": "GLD"},
                    headers=admin_headers)
    assert r.status_code == 400
    assert r.json()["detail"] == "TREASURY_INSUFFICIENT_FUNDS"