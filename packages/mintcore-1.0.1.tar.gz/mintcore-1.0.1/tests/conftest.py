# FIX 4: Set DATABASE_URL to in-memory SQLite BEFORE importing any mintcore
# modules. config.py reads env vars at import time, so the assignment must
# happen first. Using a file-based DB caused test runs to bleed state into
# each other and into development databases.
import os
os.environ["MINTCORE_DB_URL"] = "sqlite:///:memory:"

import pytest
from fastapi.testclient import TestClient
from mintcore.app import create_app

@pytest.fixture(scope="session")
def client():
    with TestClient(create_app()) as c:
        yield c

@pytest.fixture(scope="session")
def admin_headers():
    return {"X-Admin-Key": "admin-secret"}

# FIX 5: Moved seed data out of test_core.setup_module (which created its
# own separate DB instance, making seed data invisible to the shared `client`
# fixture) into a session-scoped autouse fixture here. All tests in the
# session now share one in-memory DB and one seeded state.
@pytest.fixture(scope="session", autouse=True)
def seed_data(client, admin_headers):
    client.post("/admin/currency",
                json={"currency_id": "GLD", "name": "Gold", "symbol": "G"},
                headers=admin_headers)
    client.post("/users", json={"user_id": "alice"})
    client.post("/users", json={"user_id": "bob"})