Main `galactic` **C**ommand **L**ine **I**nterface.
This is the main entry point for users to interact with the **GALACTIC** ecosystem.
It has been designed to be modular and extensible, allowing developers
to easily add new features and functionality as needed.
