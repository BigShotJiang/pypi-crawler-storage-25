"""
Defines the public API for the CLI application module.
"""

__all__ = (
    "application",
    "error",
    "info",
    "warning",
    "comment",
    "prompt",
    "confirm",
    "prompt_password_with_confirmation",
    "AppStyles",
    "Group",
    "get_global_extra_index_lines",
    "set_global_extra_index_lines",
    "config_save",
)

from ._app import (
    AppStyles,
    Group,
    application,
    comment,
    config_save,
    confirm,
    error,
    get_global_extra_index_lines,
    info,
    prompt,
    prompt_password_with_confirmation,
    set_global_extra_index_lines,
    warning,
)
