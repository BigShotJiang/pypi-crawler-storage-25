"""
Main app module.
"""

from __future__ import annotations

import os
import sys
import urllib.parse
from configparser import ConfigParser
from typing import TYPE_CHECKING, Any, ClassVar

import rich.console
import rich_click as click

from galactic.helpers.core import detect_plugins, resolve_pip_config_path

if TYPE_CHECKING:
    from collections.abc import Iterable
    from pathlib import Path


# pylint: disable=too-few-public-methods
class AppStyles:
    """
    Styles used in application.

    Attributes
    ----------
    ERROR
        Style for errors (``red bold`` by default).
    WARNING
        Style for warnings (``yellow bold`` by default).
    INFO
        Style for informations (``bright_magenta`` by default).
    COMMENT
        Style for comments (``green`` by default).
    QUESTION
        Style for questions (``cyan`` by default).
    """

    ERROR: ClassVar[str] = "red bold"
    WARNING: ClassVar[str] = "yellow bold"
    INFO: ClassVar[str] = "bright_magenta"
    COMMENT: ClassVar[str] = "green"
    QUESTION: ClassVar[str] = "cyan"


# pylint: disable=too-few-public-methods
class AppEnvVars:
    """
    Environment variables.

    Attributes
    ----------
    NO_COLOR
        Name of environment variable for no-color.
    FORCE_COLOR
        Name of environment variable for force color.
    """

    # https://no-color.org
    NO_COLOR = "NO_COLOR"
    FORCE_COLOR = "FORCE_COLOR"


GALACTIC_INDEX_URL = "https://www.thegalactic.org/pypi/simple/"
GALACTIC_EPILOG_PLAIN = (
    "GAlois LAttices, Concept Theory, Implicational systems and Closures."
)
GALACTIC_EPILOG_RICH = (
    f"[{AppStyles.WARNING}]GA[/]lois "
    f"[{AppStyles.WARNING}]LA[/]ttices, "
    f"[{AppStyles.WARNING}]C[/]oncept "
    f"[{AppStyles.WARNING}]T[/]heory, "
    f"[{AppStyles.WARNING}]I[/]mplicational systems and "
    f"[{AppStyles.WARNING}]C[/]losures."
)
GALACTIC_HELP_PLAIN = "GALACTIC main application."
GALACTIC_HELP_RICH = f"[{AppStyles.WARNING}]GALACTIC[/] main application."

if "sphinx" in sys.modules:
    GALACTIC_EPILOG = GALACTIC_EPILOG_PLAIN
    GALACTIC_HELP = GALACTIC_HELP_PLAIN
else:
    click.rich_click.TEXT_MARKUP = "rich"
    GALACTIC_EPILOG = GALACTIC_EPILOG_RICH
    GALACTIC_HELP = GALACTIC_HELP_RICH


def error(text: str) -> None:
    """
    Display an error message.

    Parameters
    ----------
    text
        Text to display

    """
    rich.console.Console().print(text, style=AppStyles.ERROR)


def info(text: str) -> None:
    """
    Display an info message.

    Parameters
    ----------
    text
        Text to display

    """
    rich.console.Console().print(text, style=AppStyles.INFO)


def warning(text: str) -> None:
    """
    Display a warning.

    Parameters
    ----------
    text
        Text to display

    """
    rich.console.Console().print(text, style=AppStyles.WARNING)


def comment(text: str) -> None:
    """
    Display a comment.

    Parameters
    ----------
    text
        Text to display

    """
    rich.console.Console().print(text, style=AppStyles.COMMENT)


def prompt(text: str, **kwargs: Any) -> Any:
    """
    Prompt the user.

    Parameters
    ----------
    text
        Text to display
    **kwargs
        Additional parameters passed to click.prompt

    """
    rich.console.Console().print(text, style=AppStyles.QUESTION, end="")
    return click.prompt("", **kwargs)


def confirm(text: str, **kwargs: Any) -> bool:
    """
    Prompt the user for a confirmation.

    Parameters
    ----------
    text
        Text to display
    **kwargs
        Additional parameters passed to click.confirm

    """
    rich.console.Console().print(text, style=AppStyles.QUESTION, end="")
    return click.confirm("", **kwargs)


def prompt_password_with_confirmation(
    message: str = "Password",
    confirmation: str = "Confirm password",
) -> str:
    """
    Prompt a hidden password twice and allow empty values.

    Parameters
    ----------
    message
        Text to display for the password prompt.
    confirmation
        Text to display for the confirmation prompt.

    Returns
    -------
    str
        Confirmed password.

    """
    while True:
        password = prompt(
            message,
            default="",
            hide_input=True,
            show_default=False,
            type=str,
        )
        confirmation = prompt(
            confirmation,
            default="",
            hide_input=True,
            show_default=False,
            type=str,
        )
        if password == confirmation:
            return password
        error("Passwords do not match. Please retry.")


class Group(click.RichGroup):  # type: ignore[misc]
    """
    Group class for the GALACTIC app.

    It does two things:

    * it detects plugins from the galactic.apps.cli.main group.
    * it adds an epilog to all added commands.
    """

    _plugins_detected = False

    @classmethod
    def detect_plugins(cls) -> None:
        """
        Detect plugins from the galactic.apps.cli.main group.
        """
        if not cls._plugins_detected:
            detect_plugins(group="galactic.apps.cli.main")
            cls._plugins_detected = True

    def list_commands(self, ctx: click.Context) -> list[str]:
        """
        List commands in the group.

        Parameters
        ----------
        ctx
            The click context

        Returns
        -------
        list[str]
            List of command names in the group

        """
        self.detect_plugins()
        return super().list_commands(ctx)

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        """
        Get a command by name.

        Parameters
        ----------
        ctx
            The click context
        cmd_name
            The name of the command to get

        Returns
        -------
        click.Command | None
            The command if found, otherwise None

        """
        self.detect_plugins()
        return super().get_command(ctx, cmd_name)

    def add_command(
        self,
        cmd: click.Command,
        name: str | None = None,
        aliases: Iterable[str] | None = None,
        panel: str | None = None,
    ) -> None:
        """
        Add a command to the group.

        This method also sets the epilog of the command to the application's epilog.
        It is useful for commands that are part of the application and should
        inherit the application's epilog.

        Parameters
        ----------
        cmd
            The command to add
        name
            The name of the command (if None, the name of the command is used)
        aliases
            Aliases for the command
        panel
            Panel name for the command in the help message

        """
        cmd.epilog = cmd.epilog or application.epilog
        super().add_command(cmd, name, aliases, panel)


@click.version_option(package_name="galactic")  # type: ignore[untyped-decorator]
@click.group(  # type: ignore[untyped-decorator]
    name="galactic",
    cls=Group,
    epilog=GALACTIC_EPILOG,
    help=GALACTIC_HELP,
)
@click.pass_context  # type: ignore[untyped-decorator]
def application(ctx: click.Context) -> int:
    """
    GALACTIC main application.
    """
    if os.environ.get(AppEnvVars.NO_COLOR) == "1":
        ctx.color = False
    elif os.environ.get(AppEnvVars.FORCE_COLOR) == "1":
        ctx.color = True
    return 0


@application.group()  # type: ignore[untyped-decorator]
def config() -> None:
    """
    Configure access to the package indexes.
    """


@config.command("init")  # type: ignore[untyped-decorator]
def config_init() -> None:
    """
    Add the GALACTIC public extra-index-url.
    """
    config_parser = ConfigParser(interpolation=None)
    config_path = resolve_pip_config_path()
    if config_path.exists():
        backup_path = config_path.with_name(f"{config_path.name}.old")
        config_parser.read(config_path, encoding="utf-8")
        if not config_parser.has_section("global"):
            config_parser.add_section("global")
        index = config_parser.get("global", "index-url", fallback="")
        url = urllib.parse.urlparse(index)
        hostname = url.hostname
        port = url.port
        netloc = f"{hostname}{':' + str(port) if port else ''}"
        index = urllib.parse.urlunparse(
            (url.scheme, netloc, url.path, url.params, url.query, url.fragment),
        )
        if index == GALACTIC_INDEX_URL:
            warning(
                f"GALACTIC public index is already configured in {config_path}.",
            )
            return
        warn_backup(config_parser, backup_path)
    if not config_parser.has_section("global"):
        config_parser.add_section("global")
    config_parser.set("global", "index-url", GALACTIC_INDEX_URL)
    info_save(config_parser, config_path)


@config.command("credential")  # type: ignore[untyped-decorator]
def config_credential() -> None:
    """
    Update credentials for an index-url entry.
    """
    config_parser = ConfigParser(interpolation=None)
    config_path = resolve_pip_config_path()
    if config_path.exists():
        backup_path = config_path.with_name(f"{config_path.name}.old")
        config_parser.read(config_path, encoding="utf-8")
        if not config_parser.has_section("global"):
            config_parser.add_section("global")
        index_url = config_parser.get("global", "index-url", fallback="")
        url = urllib.parse.urlparse(index_url)
        hostname = url.hostname
        port = url.port
        netloc = f"{hostname}{':' + str(port) if port else ''}"
        index_url = urllib.parse.urlunparse(
            (url.scheme, netloc, url.path, url.params, url.query, url.fragment),
        )
        if index_url != GALACTIC_INDEX_URL:
            warn_run_init()
            return
        lines = get_global_extra_index_lines(config_parser)
        lines.insert(0, index_url)
        info("Found index entries:")
        parsed_urls = [urllib.parse.urlparse(line) for line in lines]
        for index, url in enumerate(parsed_urls, start=1):
            hostname = url.hostname
            port = url.port
            netloc = f"{hostname}{':' + str(port) if port else ''}"
            line = urllib.parse.urlunparse(
                (url.scheme, netloc, url.path, url.params, url.query, url.fragment),
            )
            comment(f"{index}. {line}")
        selected_index = prompt(
            "Which index URL do you want to configure?",
            type=click.IntRange(min=1, max=len(lines)),
        )
        url = parsed_urls[selected_index - 1]
        hostname = url.hostname
        port = url.port
        username = url.username or "__token__"
        username = prompt("Username", default=username, show_default=True, type=str)
        password = prompt_password_with_confirmation()
        netloc = (
            f"{urllib.parse.quote(username)}"
            f":{urllib.parse.quote(password)}"
            f"@{hostname}"
            f"{':' + str(port) if port else ''}"
        )
        warn_backup(config_parser, backup_path)
        lines[selected_index - 1] = urllib.parse.urlunparse(
            (url.scheme, netloc, url.path, url.params, url.query, url.fragment),
        )
        if selected_index == 1:
            config_parser.set("global", "index-url", lines[0])
        else:
            set_global_extra_index_lines(config_parser, lines[1:])
        info_save(config_parser, config_path)
    else:
        warn_run_init()


def config_save(config_parser: ConfigParser, config_path: Path) -> None:
    """
    Save the configuration file.

    Parameters
    ----------
    config_parser
        The pip configuration parser.
    config_path
        The path to the configuration file.

    """
    with config_path.open("w", encoding="utf-8") as stream:
        config_parser.write(stream)


def info_save(config_parser: ConfigParser, config_path: Path) -> None:
    """
    Save the configuration file and inform the user.

    Parameters
    ----------
    config_parser
        The pip configuration parser.
    config_path
        The path to the configuration file.

    """
    config_save(config_parser, config_path)
    info(f"New configuration stored in {config_path}.")


def warn_backup(config_parser: ConfigParser, backup_path: Path) -> None:
    """
    Warn the user to overwrite existing backups.

    Parameters
    ----------
    config_parser
        The pip configuration parser.
    backup_path
        The path to the backup file.

    """
    config_save(config_parser, backup_path)
    warning(f"Previous configuration stored in {backup_path}.")


def warn_run_init() -> None:
    """
    Warn the user if a configuration file is missing or invalid.
    """
    warning(
        "Run `galactic config init` first, then add another URL in your pip config.",
    )


def get_global_extra_index_lines(config_parser: ConfigParser) -> list[str]:
    """
    Get the extra-index-url entries in the global section of the pip configuration.

    Parameters
    ----------
    config_parser
            The pip configuration parser.

    Returns
    -------
    list[str]
        The extra-index-url entries in the global section of the pip configuration.

    """
    if config_parser.has_section("global"):
        # Get existing URLs
        existing_raw = config_parser.get("global", "extra-index-url", fallback="")
        return [line for line in existing_raw.splitlines() if line]
    return []


def set_global_extra_index_lines(config_parser: ConfigParser, lines: list[str]) -> None:
    """
    Set the extra-index-url entries in the global section of the pip configuration.

    Parameters
    ----------
    config_parser
        The pip configuration parser.
    lines
        The extra-index-url entries in the global section of the pip configuration.

    """
    updated_raw = os.linesep.join(lines)
    if not config_parser.has_section("global"):
        config_parser.add_section("global")
    if len(lines) > 1:
        config_parser.set("global", "extra-index-url", os.linesep + updated_raw)
    else:
        config_parser.set("global", "extra-index-url", updated_raw)
