=============================
**GALACTIC** main application
=============================

*galactic* [#logo]_ [#logomain]_ is the
main application for **GALACTIC**.

**GALACTIC** stands for
**GA**\ lois
**LA**\ ttices,
**C**\ oncept
**T**\ heory,
**I**\ mplicational systems and
**C**\ losures.

..  toctree::
    :hidden:
    :maxdepth: 1
    :caption: 🚀 Getting started

    install/index.rst
    release-notes

..  toctree::
    :hidden:
    :maxdepth: 1
    :caption: 🎓 Usage

    usage

..  toctree::
    :hidden:
    :maxdepth: 1
    :caption: 🔌 Reference

    CLI API <api/apps/cli/main/index>

..  toctree::
    :hidden:
    :maxdepth: 1
    :caption: GALACTIC

    Main <https://galactic.univ-lr.fr/>
    Projects <https://galactic.univ-lr.fr/docs/>
    Guides <https://galactic.univ-lr.fr/guides/>
    Slides <https://galactic.univ-lr.fr/slides/>
    Posters <https://galactic.univ-lr.fr/posters/>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`

.. [#logo]
        The **GALACTIC** icon has been constructed using icons present in the
        `free star wars icons set <http://sensibleworld.com/news/free-star-wars-icons>`_
        designed by `Sensible World <http://www.iconarchive.com/artist/sensibleworld.html>`_.
        The product or characters depicted in these icons
        are © by Disney / Lucasfilm.

        It's a tribute to the French mathematician
        `Évariste Galois <https://en.wikipedia.org/wiki/Évariste_Galois>`_ who
        died at age 20 in a duel.
        In France, Concept Lattices are also called *Galois Lattices*.

.. [#logomain]
        The *galactic* icon has been constructed using the main
        **GALACTIC** icon, the
        `Terminal icon <https://www.iconfinder.com/icons/8665801/terminal_icon>`_
        designed by
        `Font Awesome <https://www.iconfinder.com/font-awesome>`_ and the
        `Hat And Magic Wand <https://www.svgrepo.com/svg/29580/hat-and-magic-wand>`_
        designed by
        `SVGrepo <https://www.svgrepo.com/>`_.
