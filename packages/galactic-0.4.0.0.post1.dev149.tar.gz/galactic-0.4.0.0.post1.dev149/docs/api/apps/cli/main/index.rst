🔌 CLI API
==========

.. autosummary::
   :recursive:
   :toctree: modules

   galactic.apps.cli.main
