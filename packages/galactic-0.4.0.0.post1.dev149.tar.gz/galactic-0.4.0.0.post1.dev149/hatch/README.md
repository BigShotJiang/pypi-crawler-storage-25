**GALACTIC** `hatch` submodule
==============================

This submodule should be added to projects that need to build **GALACTIC** packages.

Icon constructed using:

* the main **GALACTIC** icon
* the [Git, branch icon](https://www.iconfinder.com/icons/9025799/git_branch_icon)
  designed by [Phosphor Icons](https://www.iconfinder.com/phosphor-icons)
* the [Ic, build icon](https://www.iconfinder.com/icons/3669398/ic_build_icon)
  icon designed by [https://www.iconfinder.com/iconsets/google-material-design-3-0](https://www.iconfinder.com/iconsets/google-material-design-3-0)
