from __future__ import annotations

import json
import mimetypes
import tempfile
import uuid
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx

from lfx.custom.custom_component.component import Component
from lfx.io import MessageTextInput, Output, StrInput, TableInput
from lfx.schema.data import Data
from lfx.schema.message import Message
from lfx.utils.constants import MESSAGE_SENDER_NAME_USER, MESSAGE_SENDER_USER
from lfx.utils.image import create_image_content_dict


class EahImgURLConvertComponent(Component):
    display_name = "Image URL Convert"
    description = "Download an image URL and convert it to Agent-ready multimodal inputs."
    documentation = "https://docs.langflow.org/agents"
    icon = "😃"
    name = "EahImgURLConvertComponent"
    _DOWNLOAD_TIMEOUT_SECONDS = 30
    _MAX_IMAGE_SIZE_MB = 20
    _CACHE_REGISTRY_FILE = "cache_dirs.json"
    _DEFAULT_USER_AGENT = "langflow-img-url-convert/1.0"

    inputs = [
        MessageTextInput(
            name="image_url",
            display_name="Image URL",
            info="Image URL (http/https).",
            required=False,
            tool_mode=True,
        ),
        MessageTextInput(
            name="prompt_text",
            display_name="Prompt Text",
            info="Optional text prompt sent together with the image.",
            value="Please analyze this image.",
            required=False,
            tool_mode=True,
        ),
        StrInput(
            name="save_dir",
            display_name="Save Directory",
            info="Optional local directory for downloaded images. Uses temp directory if empty.",
            value="",
            required=False,
            advanced=True,
        ),
        TableInput(
            name="headers",
            display_name="Request Headers",
            info=(
                "Optional HTTP headers for image download auth (open table format). "
                "Example: Authorization=Bearer xxx, Cookie=sid=yyy."
            ),
            table_schema=[
                {
                    "name": "key",
                    "display_name": "Header",
                    "type": "str",
                    "description": "Header name",
                },
                {
                    "name": "value",
                    "display_name": "Value",
                    "type": "str",
                    "description": "Header value",
                },
            ],
            value=[],
            required=False,
            advanced=True,
        ),
    ]

    outputs = [
        Output(display_name="Message", name="message", method="to_message"),
        Output(display_name="Multimodal Data", name="multimodal_data", method="to_multimodal_data"),
        Output(display_name="Clear Cache", name="clear_cache", method="clear_cache"),
    ]

    _ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tiff", ".svg"}
    _FORMAT_TO_MIME = {
        "jpeg": "image/jpeg",
        "png": "image/png",
        "gif": "image/gif",
        "webp": "image/webp",
        "bmp": "image/bmp",
        "tiff": "image/tiff",
    }
    _FORMAT_TO_EXTENSION = {
        "jpeg": ".jpg",
        "png": ".png",
        "gif": ".gif",
        "webp": ".webp",
        "bmp": ".bmp",
        "tiff": ".tiff",
    }

    @staticmethod
    def _headers_dict_to_rows(headers: dict[str, str]) -> list[dict[str, str]]:
        return [{"key": key, "value": value} for key, value in headers.items()]

    @classmethod
    def _coerce_headers_value_to_rows(cls, raw_value: Any) -> list[dict[str, str]]:
        if raw_value in (None, "", []):
            return []

        if hasattr(raw_value, "to_dict"):
            try:
                rows = raw_value.to_dict(orient="records")
            except Exception:  # noqa: BLE001
                rows = None
            if isinstance(rows, list):
                normalized = cls._headers_from_rows(rows)
                return cls._headers_dict_to_rows(normalized)

        if isinstance(raw_value, list):
            normalized = cls._headers_from_rows(raw_value)
            return cls._headers_dict_to_rows(normalized)

        if isinstance(raw_value, dict):
            normalized = cls._normalize_header_pairs(raw_value)
            return cls._headers_dict_to_rows(normalized)

        if isinstance(raw_value, str):
            raw_text = raw_value.strip()
            if not raw_text:
                return []
            try:
                parsed = json.loads(raw_text)
            except json.JSONDecodeError:
                return []
            return cls._coerce_headers_value_to_rows(parsed)

        return []

    def update_build_config(self, build_config: dict, field_value: Any, field_name: str | None = None):
        headers_config = build_config.get("headers")
        if not isinstance(headers_config, dict):
            return build_config

        current_value = headers_config.get("value")
        rows = self._coerce_headers_value_to_rows(current_value)
        headers_config["value"] = rows
        return build_config

    @classmethod
    def _global_cache_root(cls) -> Path:
        return Path(tempfile.gettempdir()) / "langflow_img_url_convert"

    @classmethod
    def _cache_registry_path(cls) -> Path:
        return cls._global_cache_root() / cls._CACHE_REGISTRY_FILE

    @classmethod
    def _load_registered_cache_dirs(cls) -> set[Path]:
        registry_path = cls._cache_registry_path()
        if not registry_path.exists():
            return set()
        try:
            raw = json.loads(registry_path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return set()
        if not isinstance(raw, list):
            return set()
        dirs = set()
        for item in raw:
            if not isinstance(item, str):
                continue
            p = Path(item).expanduser()
            dirs.add(p)
        return dirs

    @classmethod
    def _persist_registered_cache_dirs(cls, cache_dirs: set[Path]) -> None:
        root = cls._global_cache_root()
        root.mkdir(parents=True, exist_ok=True)
        registry_path = cls._cache_registry_path()
        payload = sorted(str(p) for p in cache_dirs)
        registry_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def _register_cache_dir(cls, cache_dir: Path) -> None:
        dirs = cls._load_registered_cache_dirs()
        dirs.add(cache_dir)
        dirs.add(cls._global_cache_root())
        cls._persist_registered_cache_dirs(dirs)

    def _all_cache_dirs(self) -> set[Path]:
        dirs = self._load_registered_cache_dirs()
        dirs.add(self._global_cache_root())
        raw = str(getattr(self, "save_dir", "") or "").strip()
        if raw:
            dirs.add(Path(raw).expanduser())
        return dirs

    def _validate_url(self, url: str) -> str:
        normalized = str(url or "").strip()
        if not normalized:
            msg = "image_url is required."
            raise ValueError(msg)
        parsed = urlparse(normalized)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            msg = f"Invalid image URL: {normalized!r}. Only http/https URLs are supported."
            raise ValueError(msg)
        return normalized

    def _get_image_url(self) -> str:
        return str(getattr(self, "image_url", "") or "").strip()

    @staticmethod
    def _normalize_header_pairs(pairs: dict) -> dict[str, str]:
        normalized: dict[str, str] = {}
        for key, value in pairs.items():
            key_text = str(key).strip()
            if not key_text:
                continue
            normalized[key_text] = "" if value is None else str(value)
        return normalized

    @staticmethod
    def _headers_from_rows(rows: list) -> dict[str, str]:
        parsed: dict[str, str] = {}
        for row in rows:
            if row is None:
                continue

            if isinstance(row, dict):
                key = row.get("key")
                value = row.get("value")
                if key is None and value is None and len(row) >= 2:
                    items = list(row.items())
                    key = items[0][1]
                    value = items[1][1]
            elif isinstance(row, (list, tuple)) and len(row) >= 2:
                key, value = row[0], row[1]
            else:
                continue

            key_text = str(key or "").strip()
            if not key_text:
                continue
            parsed[key_text] = "" if value is None else str(value)

        return parsed

    def _parse_custom_headers(self) -> dict[str, str]:
        raw_headers = getattr(self, "headers", "")

        if raw_headers in (None, "", []):
            return {}

        if hasattr(raw_headers, "to_dict"):
            try:
                rows = raw_headers.to_dict(orient="records")
            except Exception:  # noqa: BLE001
                rows = None
            if isinstance(rows, list):
                return self._headers_from_rows(rows)

        if isinstance(raw_headers, list):
            return self._headers_from_rows(raw_headers)

        if isinstance(raw_headers, dict):
            return self._normalize_header_pairs(raw_headers)

        if isinstance(raw_headers, str):
            raw_text = str(raw_headers).strip()
            if not raw_text:
                return {}
            try:
                parsed = json.loads(raw_text)
            except json.JSONDecodeError as exc:
                msg = "headers must be a valid table value, dict, or JSON string."
                raise ValueError(msg) from exc
            if isinstance(parsed, dict):
                return self._normalize_header_pairs(parsed)
            if isinstance(parsed, list):
                return self._headers_from_rows(parsed)
            msg = "headers JSON must be an object or key/value list."
            raise ValueError(msg)

        msg = "Unsupported headers type. Use TableInput rows, dict, or JSON string."
        raise ValueError(msg)

    def _build_request_headers(self) -> dict[str, str]:
        default_headers = {
            "User-Agent": self._DEFAULT_USER_AGENT,
            "Accept": "image/*,*/*;q=0.8",
        }
        custom_headers = self._parse_custom_headers()
        merged_headers = default_headers.copy()
        merged_headers.update(custom_headers)
        return merged_headers

    def _headers_cache_key(self) -> str:
        headers = self._build_request_headers()
        return json.dumps(headers, ensure_ascii=False, sort_keys=True)

    def _get_effective_save_dir(self) -> Path:
        raw = str(getattr(self, "save_dir", "") or "").strip()
        if raw:
            save_dir = Path(raw).expanduser()
        else:
            save_dir = self._global_cache_root()
        save_dir.mkdir(parents=True, exist_ok=True)
        self._register_cache_dir(save_dir)
        return save_dir

    def _normalize_extension(self, extension: str | None, fallback: str = ".png") -> str:
        if not extension:
            return fallback
        normalized = extension.lower()
        if not normalized.startswith("."):
            normalized = f".{normalized}"
        if normalized == ".jpe":
            normalized = ".jpg"
        return normalized if normalized in self._ALLOWED_EXTENSIONS else fallback

    def _detect_image_mime_and_extension(self, body: bytes) -> tuple[str, str]:
        # NOTE: Import inside method because Langflow custom component loader
        # may not preserve `from x import y as z` aliases in execution globals.
        from PIL import Image as PILImage
        from PIL import UnidentifiedImageError

        try:
            with PILImage.open(BytesIO(body)) as image:
                image_format = str(image.format or "").lower()
                image.verify()
        except UnidentifiedImageError as exc:
            msg = "URL content is not a valid image."
            raise ValueError(msg) from exc
        except Exception as exc:
            msg = f"Failed to validate image bytes: {exc!s}"
            raise ValueError(msg) from exc

        if image_format == "jpg":
            image_format = "jpeg"
        mime_type = self._FORMAT_TO_MIME.get(image_format, "image/png")
        extension = self._FORMAT_TO_EXTENSION.get(image_format, ".png")
        return mime_type, extension

    def _resolve_extension(self, image_url: str, mime_type: str, detected_ext: str) -> str:
        url_ext = self._normalize_extension(Path(urlparse(image_url).path).suffix, fallback="")
        if url_ext:
            return url_ext

        mime_ext = self._normalize_extension(mimetypes.guess_extension(mime_type), fallback="")
        if mime_ext:
            return mime_ext

        return self._normalize_extension(detected_ext, fallback=".png")

    def _download_image(self, image_url: str) -> dict:
        timeout = max(int(self._DOWNLOAD_TIMEOUT_SECONDS), 1)
        max_size_mb = max(int(self._MAX_IMAGE_SIZE_MB), 1)
        max_bytes = max_size_mb * 1024 * 1024
        request_headers = self._build_request_headers()

        try:
            with httpx.Client(timeout=timeout, follow_redirects=True) as client:
                response = client.get(image_url, headers=request_headers)
                response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code if exc.response is not None else "unknown"
            msg = f"Image download failed, HTTP status: {status}."
            raise ValueError(msg) from exc
        except httpx.RequestError as exc:
            msg = f"Image download request failed: {exc!s}"
            raise ValueError(msg) from exc

        body = response.content
        if not body:
            msg = "Downloaded image is empty."
            raise ValueError(msg)
        if len(body) > max_bytes:
            msg = f"Image too large ({len(body)} bytes). Limit is {max_bytes} bytes."
            raise ValueError(msg)

        header_mime = (response.headers.get("content-type") or "").split(";")[0].strip().lower()
        if header_mime == "image/svg+xml":
            mime_type = header_mime
            extension = ".svg"
        else:
            detected_mime, detected_ext = self._detect_image_mime_and_extension(body)
            mime_type = header_mime if header_mime.startswith("image/") else detected_mime
            extension = self._resolve_extension(image_url, mime_type, detected_ext)

        save_dir = self._get_effective_save_dir()
        file_path = save_dir / f"img_{uuid.uuid4().hex}{extension}"
        file_path.write_bytes(body)

        return {
            "source_url": image_url,
            "request_headers_key": self._headers_cache_key(),
            "path": str(file_path),
            "mime_type": mime_type,
            "size_bytes": len(body),
        }

    def _ensure_downloaded(self) -> dict:
        image_url = self._validate_url(self._get_image_url())
        headers_key = self._headers_cache_key()
        cached = getattr(self, "_download_result", None)
        if (
            isinstance(cached, dict)
            and cached.get("source_url") == image_url
            and cached.get("request_headers_key") == headers_key
        ):
            return cached

        result = self._download_image(image_url)
        self._download_result = result
        return result

    def to_message(self) -> Message:
        prompt_text = str(getattr(self, "prompt_text", "") or "").strip()
        image_url = self._get_image_url()
        if not image_url:
            message = Message(
                text=prompt_text,
                sender=MESSAGE_SENDER_USER,
                sender_name=MESSAGE_SENDER_NAME_USER,
                files=[],
            )
            self.status = {"skipped": True, "reason": "image_url is empty"}
            return message

        downloaded = self._ensure_downloaded()

        message = Message(
            text=prompt_text,
            sender=MESSAGE_SENDER_USER,
            sender_name=MESSAGE_SENDER_NAME_USER,
            files=[downloaded["path"]],
        )
        self.status = {
            "image_path": downloaded["path"],
            "mime_type": downloaded["mime_type"],
            "size_bytes": downloaded["size_bytes"],
        }
        return message

    def to_multimodal_data(self) -> Data:
        prompt_text = str(getattr(self, "prompt_text", "") or "").strip()
        image_url = self._get_image_url()
        if not image_url:
            content: list[dict] = []
            if prompt_text:
                content.append({"type": "text", "text": prompt_text})
            data = Data(
                data={
                    "content": content,
                    "image_url": "",
                    "image_path": "",
                    "mime_type": "",
                    "size_bytes": 0,
                    "skipped": True,
                    "reason": "image_url is empty",
                }
            )
            self.status = data
            return data

        downloaded = self._ensure_downloaded()
        content: list[dict] = []
        if prompt_text:
            content.append({"type": "text", "text": prompt_text})
        content.append(create_image_content_dict(downloaded["path"], downloaded["mime_type"]))

        data = Data(
            data={
                "content": content,
                "image_url": downloaded["source_url"],
                "image_path": downloaded["path"],
                "mime_type": downloaded["mime_type"],
                "size_bytes": downloaded["size_bytes"],
            }
        )
        self.status = data
        return data

    def clear_cache(self) -> Data:
        deleted_files: list[str] = []
        failed_files: list[dict[str, str]] = []
        scanned_dirs: list[str] = []

        for cache_dir in sorted(self._all_cache_dirs(), key=lambda p: str(p)):
            scanned_dirs.append(str(cache_dir))
            if not cache_dir.exists() or not cache_dir.is_dir():
                continue
            for file_path in cache_dir.glob("img_*"):
                if not file_path.is_file():
                    continue
                if file_path.suffix.lower() not in self._ALLOWED_EXTENSIONS:
                    continue
                try:
                    file_path.unlink()
                    deleted_files.append(str(file_path))
                except Exception as exc:  # noqa: BLE001
                    failed_files.append({"path": str(file_path), "error": str(exc)})

        self._download_result = None
        result = Data(
            data={
                "scanned_dirs": scanned_dirs,
                "deleted_count": len(deleted_files),
                "failed_count": len(failed_files),
                "deleted_files": deleted_files,
                "failed_files": failed_files,
            }
        )
        self.status = result
        return result
