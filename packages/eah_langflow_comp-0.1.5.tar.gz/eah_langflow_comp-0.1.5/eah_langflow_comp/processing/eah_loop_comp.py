import ast
import json

from lfx.base.flow_controls.loop_utils import (
    execute_loop_body,
    extract_loop_output,
    get_loop_body_start_edge,
    get_loop_body_start_vertex,
    get_loop_body_vertices,
    validate_data_input,
)
from lfx.components.flow_controls.loop import LoopComponent
from lfx.components.processing.converter import convert_to_data
from lfx.inputs.inputs import HandleInput
from lfx.schema.data import Data
from lfx.schema.dataframe import DataFrame
from lfx.schema.message import Message
from lfx.template.field.base import Output


class EahLoopComponent(LoopComponent):
    display_name = "Eah Loop"
    description = (
        "Iterates through Data or Message objects, processing items individually "
        "and aggregating results from loop inputs."
    )
    documentation: str = "https://docs.langflow.org/loop"
    icon = "😃"
    name = "EahLoopComponent"
    inputs = [
        HandleInput(
            name="data",
            display_name="Inputs",
            info="Supports DataFrame, list input, or stringified list (for example: [\"a\", \"b\"]).",
            input_types=["DataFrame", "Data", "Message"],
        ),
    ]

    outputs = [
        Output(
            display_name="Item",
            name="item",
            method="item_output",
            types=["Message", "Text", "Data"],
            selected="Message",
            allows_loop=True,
            loop_types=["Message", "Text", "Data"],
            group_outputs=True,
        ),
        Output(display_name="Done", name="done", method="done_output", group_outputs=True),
    ]

    def _current_run_id(self) -> str | None:
        """Get current graph run id without raising when graph is not initialized."""
        if not hasattr(self, "graph") or self.graph is None:
            return None
        return getattr(self.graph, "_run_id", None)

    def initialize_data(self) -> None:
        """Initialize the data list, context index, and aggregated list."""
        run_id = self._current_run_id()
        initialized_key = f"{self._id}_initialized"
        run_id_key = f"{self._id}_run_id"
        if self.ctx.get(initialized_key, False) and self.ctx.get(run_id_key) == run_id:
            return

        # Ensure data is a list of Data objects
        data_list = self._validate_data(self.data)

        # Store the initial data and context variables
        self.update_ctx(
            {
                f"{self._id}_data": data_list,
                f"{self._id}_index": 0,
                f"{self._id}_aggregated": [],
                f"{self._id}_iterated": False,
                f"{self._id}_iteration_error": None,
                initialized_key: True,
                run_id_key: run_id,
            }
        )

    def _convert_message_to_data(self, message: Message) -> Data:
        """Convert a Message object to a Data object using Type Convert logic."""
        return convert_to_data(message, auto_parse=False)

    def _stringify_item(self, item) -> str:
        """Convert any item to a stable string representation."""
        if isinstance(item, str):
            return item
        if isinstance(item, (dict, list, tuple)):
            try:
                return json.dumps(item, ensure_ascii=False)
            except TypeError:
                return str(item)
        return str(item)

    def _parse_array_string(self, value: str) -> list:
        """Parse string input that may represent a list/tuple."""
        stripped = value.strip()
        if not stripped:
            return []

        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            try:
                parsed = ast.literal_eval(stripped)
            except (ValueError, SyntaxError):
                # Fallback: treat a plain string as a single item.
                return [stripped]

        if isinstance(parsed, tuple):
            return list(parsed)
        if isinstance(parsed, list):
            return parsed
        return [parsed]

    def _is_array_like_string(self, value: str) -> bool:
        stripped = value.strip()
        return (stripped.startswith("[") and stripped.endswith("]")) or (
            stripped.startswith("(") and stripped.endswith(")")
        )

    def _expand_item_if_array_like(self, item) -> list:
        """Expand array-like payloads into individual items, otherwise keep as single item."""
        if isinstance(item, (list, tuple)):
            return list(item)

        if isinstance(item, str):
            if self._is_array_like_string(item):
                return self._parse_array_string(item)
            return [item]

        if isinstance(item, Message):
            text_value = getattr(item, "text", "")
            if isinstance(text_value, (list, tuple)):
                return list(text_value)
            if isinstance(text_value, str) and self._is_array_like_string(text_value):
                return self._parse_array_string(text_value)
            return [item]

        if isinstance(item, Data):
            text_value = item.get_text()
            if isinstance(text_value, (list, tuple)):
                return list(text_value)
            if isinstance(text_value, str) and self._is_array_like_string(text_value):
                return self._parse_array_string(text_value)
            return [item]

        return [item]

    def _to_string_data(self, item) -> Data:
        """Normalize any supported item into Data(text=<string>)."""
        if isinstance(item, Data):
            text_value = item.get_text()
            if text_value not in (None, ""):
                return Data(text=self._stringify_item(text_value))

            data_value = getattr(item, "data", None)
            if isinstance(data_value, dict):
                text_key = getattr(item, "text_key", "text")
                payload = data_value
                if text_key in payload:
                    payload_without_text = {k: v for k, v in payload.items() if k != text_key}
                    payload = payload_without_text if payload_without_text else payload[text_key]
                if payload not in (None, "", {}, []):
                    return Data(text=self._stringify_item(payload))
                return Data(text="")
            if data_value not in (None, "", {}, []):
                return Data(text=self._stringify_item(data_value))
            return Data(text="")

        if isinstance(item, Message):
            text_value = getattr(item, "text", None)
            if text_value in (None, ""):
                return Data(text=self._stringify_item(item))
            return Data(text=self._stringify_item(text_value))

        return Data(text=self._stringify_item(item))

    def _validate_data(self, data):
        """Validate input and return a list of Data(text=<string>) objects."""
        if isinstance(data, str):
            return [self._to_string_data(item) for item in self._parse_array_string(data)]

        if isinstance(data, (list, tuple, Message, Data)):
            expanded_items = []
            for item in self._expand_item_if_array_like(data):
                expanded_items.extend(self._expand_item_if_array_like(item))
            return [self._to_string_data(item) for item in expanded_items]

        validated_data = validate_data_input(data)
        if not isinstance(validated_data, (list, tuple)):
            validated_data = [validated_data]
        expanded_items = []
        for item in validated_data:
            expanded_items.extend(self._expand_item_if_array_like(item))
        return [self._to_string_data(item) for item in expanded_items]

    def get_loop_body_vertices(self) -> set[str]:
        """Identify vertices in this loop's body via graph traversal.

        Traverses from the loop's "item" output to the vertex that feeds back
        to the loop's "item" input, collecting all vertices in between.
        This naturally handles nested loops by stopping at this loop's feedback edge.

        Returns:
            Set of vertex IDs that form this loop's body
        """
        # Check if we have a proper graph context
        if not hasattr(self, "_vertex") or self._vertex is None:
            return set()

        return get_loop_body_vertices(
            vertex=self._vertex,
            graph=self.graph,
            get_incoming_edge_by_target_param_fn=self.get_incoming_edge_by_target_param,
        )

    def _get_loop_body_start_vertex(self) -> str | None:
        """Get the first vertex in the loop body (connected to loop's item output).

        Returns:
            The vertex ID of the first vertex in the loop body, or None if not found
        """
        # Check if we have a proper graph context
        if not hasattr(self, "_vertex") or self._vertex is None:
            return None

        return get_loop_body_start_vertex(vertex=self._vertex)

    def _extract_loop_output(self, results: list) -> Data:
        """Extract the output from subgraph execution results.

        Args:
            results: List of VertexBuildResult objects from subgraph execution

        Returns:
            Data object containing the loop iteration output
        """
        # Get the vertex ID that feeds back to the item input (end of loop body)
        end_vertex_id = self.get_incoming_edge_by_target_param("item")
        return extract_loop_output(results=results, end_vertex_id=end_vertex_id)

    async def execute_loop_body(self, data_list: list[Data], event_manager=None) -> list[Data]:
        """Execute loop body for each data item.

        Creates an isolated subgraph for the loop body and executes it
        for each item in the data list, collecting results.

        Args:
            data_list: List of Data objects to iterate over
            event_manager: Optional event manager to pass to subgraph execution for UI events

        Returns:
            List of Data objects containing results from each iteration
        """
        # Get the loop body configuration once
        loop_body_vertex_ids = self.get_loop_body_vertices()
        start_vertex_id = self._get_loop_body_start_vertex()
        start_edge = get_loop_body_start_edge(self._vertex)
        end_vertex_id = self.get_incoming_edge_by_target_param("item")
        # Fallback for simplified wiring: if no explicit feedback edge exists,
        # extract each iteration result from the loop start vertex output.
        if not end_vertex_id:
            end_vertex_id = start_vertex_id

        return await execute_loop_body(
            graph=self.graph,
            data_list=data_list,
            loop_body_vertex_ids=loop_body_vertex_ids,
            start_vertex_id=start_vertex_id,
            start_edge=start_edge,
            end_vertex_id=end_vertex_id,
            event_manager=event_manager,
        )

    async def _iterate(self) -> list[Data]:
        """Execute loop body once and cache iteration result for this run."""
        iterated_key = f"{self._id}_iterated"
        aggregated_key = f"{self._id}_aggregated"
        error_key = f"{self._id}_iteration_error"

        if self.ctx.get(iterated_key, False):
            cached_error = self.ctx.get(error_key)
            if cached_error is not None:
                raise cached_error
            return self.ctx.get(aggregated_key, [])

        self.initialize_data()
        data_list = self.ctx.get(f"{self._id}_data", [])

        if not data_list:
            self.update_ctx({aggregated_key: [], iterated_key: True, error_key: None})
            return []

        try:
            aggregated_results = await self.execute_loop_body(data_list, event_manager=self._event_manager)
        except Exception as exc:
            self.update_ctx({error_key: exc, iterated_key: True})
            raise

        self.update_ctx({aggregated_key: aggregated_results, iterated_key: True, error_key: None})
        return aggregated_results

    async def item_output(self) -> Data:
        """Loop body execution placeholder output.

        Loop execution can happen in either output, and is cached by _iterate().
        We still expose a stable preview item instead of an empty payload so
        UI/edge artifacts do not degrade to {"text": ""}.
        """
        self.initialize_data()
        self.stop("item")
        # If done output is not connected, item output should still trigger iteration.
        if self._vertex is not None and "done" not in self._vertex.edges_source_names:
            await self._iterate()
        data_list = self.ctx.get(f"{self._id}_data", [])
        if data_list:
            first_item = data_list[0]
            if isinstance(first_item, Data):
                return first_item
            return self._to_string_data(first_item)
        return Data(text="")

    async def done_output(self) -> DataFrame:
        """Execute the loop body for all items and return aggregated results.

        This is now the main execution point for the loop. It:
        1. Gets the data list to iterate over
        2. Executes the loop body as an isolated subgraph for each item
        3. Returns the aggregated results

        Args:
            event_manager: Optional event manager for UI event emission
        """
        aggregated_results = await self._iterate()
        return DataFrame(aggregated_results)
