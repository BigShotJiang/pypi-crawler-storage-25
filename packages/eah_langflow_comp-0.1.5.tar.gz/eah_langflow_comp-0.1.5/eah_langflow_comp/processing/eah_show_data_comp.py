from __future__ import annotations

import json
from typing import Any

from lfx.custom.custom_component.component import Component
from lfx.io import DataInput, Output
from lfx.schema.data import Data
from lfx.schema.message import Message


class EahShowDataComponent(Component):
    display_name = "Eah Show Data"
    description = "Display the full incoming data payload for debugging."
    documentation = "https://docs.langflow.org/components-processing"
    icon = "😃"
    name = "EahShowDataComponent"

    inputs = [
        DataInput(
            name="data",
            display_name="Data",
            info="Any Data/Message/DataFrame payload to inspect. Lists are also supported.",
            input_types=["Data", "Message", "DataFrame"],
            is_list=True,
            required=True,
        ),
    ]

    outputs = [
        Output(display_name="Message", name="message", method="to_message"),
        Output(display_name="Data", name="full_data", method="to_data"),
    ]

    def _to_serializable(self, value: Any) -> Any:
        if value is None or isinstance(value, (str, int, float, bool)):
            return value

        if isinstance(value, dict):
            return {str(key): self._to_serializable(item) for key, item in value.items()}

        if isinstance(value, (list, tuple, set)):
            return [self._to_serializable(item) for item in value]

        if hasattr(value, "model_dump"):
            try:
                return self._to_serializable(value.model_dump())
            except Exception:
                pass

        if hasattr(value, "to_dict"):
            try:
                return self._to_serializable(value.to_dict())
            except Exception:
                pass

        if hasattr(value, "dict"):
            try:
                return self._to_serializable(value.dict())
            except Exception:
                pass

        return str(value)

    def _build_serialized(self) -> Any:
        return self._to_serializable(getattr(self, "data", None))

    def _build_message_text(self, payload: Any) -> str:
        try:
            return json.dumps(payload, ensure_ascii=False, indent=2)
        except Exception:
            return str(payload)

    async def to_message(self) -> Message:
        payload = self._build_serialized()
        return Message(
            text=self._build_message_text(payload),
            data={"full_data": payload},
        )

    async def to_data(self) -> Data:
        payload = self._build_serialized()
        return Data(data={"full_data": payload})
