from typing import Any
from urllib.parse import urlparse

from lfx.base.vectorstores.model import check_cached_vector_store
from lfx.components.milvus.milvus import MilvusVectorStoreComponent
from lfx.schema.data import Data


def _ensure_milvus_orm_connection_compatibility(connection_args: dict[str, Any], timeout: float | None) -> None:
    """Register the shared MilvusClient handler in pymilvus ORM aliases when needed."""
    try:
        from pymilvus import MilvusClient
        from pymilvus.orm.connections import connections
    except ImportError:
        return

    probe_client = MilvusClient(timeout=timeout, **connection_args)
    alias = getattr(probe_client, "_using", "")
    handler = getattr(probe_client, "_handler", None)
    config = getattr(probe_client, "_config", None)

    if not alias or handler is None or config is None:
        return

    if alias not in connections._alias_config:
        alias_config = {"address": getattr(config, "address", ""), "user": ""}
        db_name = getattr(config, "db_name", "")
        if db_name:
            alias_config["db_name"] = db_name

        get_handler_kwargs = getattr(config, "get_handler_kwargs", None)
        if callable(get_handler_kwargs):
            alias_config.update(get_handler_kwargs())

        connections._alias_config[alias] = alias_config

    if not connections.has_connection(alias):
        connections._alias_handlers[alias] = handler


def _normalize_milvus_connection_args(
    uri: str,
    password: str,
    connection_args: dict[str, Any] | None,
) -> dict[str, Any]:
    normalized_args = dict(connection_args or {})
    normalized_args["uri"] = uri.strip()

    if password:
        normalized_args["token"] = password
    else:
        normalized_args.setdefault("token", "")

    scheme = urlparse(normalized_args["uri"]).scheme.lower()
    if scheme == "http":
        normalized_args.pop("secure", None)
    elif scheme == "https":
        normalized_args["secure"] = True

    return normalized_args


def _normalize_milvus_timeout(timeout: float | None) -> float | None:
    if timeout is None or timeout <= 0:
        return None
    return timeout


class EahMilvusVectorStoreComponent(MilvusVectorStoreComponent):
    display_name = "Eah Milvus"
    name = "EahMilvus"
    icon = "😃"

    @check_cached_vector_store
    def build_vector_store(self):
        try:
            from langchain_milvus.vectorstores import Milvus as LangchainMilvus
        except ImportError as e:
            msg = "Could not import Milvus integration package. Please install it with `pip install langchain-milvus`."
            raise ImportError(msg) from e

        timeout = _normalize_milvus_timeout(self.timeout)
        connection_args = _normalize_milvus_connection_args(
            uri=self.uri,
            password=self.password,
            connection_args=self.connection_args,
        )
        _ensure_milvus_orm_connection_compatibility(connection_args, timeout)

        milvus_store = LangchainMilvus(
            embedding_function=self.embedding,
            collection_name=self.collection_name,
            collection_description=self.collection_description,
            connection_args=connection_args,
            consistency_level=self.consistency_level,
            index_params=self.index_params,
            search_params=self.search_params,
            drop_old=self.drop_old,
            auto_id=True,
            primary_field=self.primary_field,
            text_field=self.text_field,
            vector_field=self.vector_field,
            timeout=timeout,
        )

        self.ingest_data = self._prepare_ingest_data()
        documents = []
        for _input in self.ingest_data or []:
            if isinstance(_input, Data):
                documents.append(_input.to_lc_document())
            else:
                documents.append(_input)

        if documents:
            milvus_store.add_documents(documents)

        return milvus_store
