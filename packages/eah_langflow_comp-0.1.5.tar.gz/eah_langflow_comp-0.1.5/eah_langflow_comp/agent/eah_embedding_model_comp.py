from typing import Any

from langchain_openai import OpenAIEmbeddings

from lfx.base.embeddings.embeddings_class import EmbeddingsWithModels
from lfx.base.models.unified_models import get_api_key_for_provider
from lfx.components.models_and_agents.embedding_model import EmbeddingModelComponent
from lfx.field_typing import Embeddings
from lfx.io import BoolInput, DictInput, FloatInput, IntInput, MessageTextInput, StrInput


class EahEmbeddingModelComponent(EmbeddingModelComponent):
    display_name = "Eah Embedding Model"
    description = "Generate embeddings using an OpenAI-compatible endpoint."
    documentation: str = "https://docs.langflow.org/components-embedding-models"
    icon = "🤔"
    name = "EahEmbeddingModel"
    category = "models"

    inputs = [
        StrInput(
            name="model",
            display_name="Embedding Model",
            info=(
                "Enter the embedding model name exposed by your company gateway, for example "
                "text-embedding-3-small or corp-embed-v1."
            ),
            real_time_refresh=False,
            required=True,
            input_types=["Embeddings"],
            load_from_db=False,
        ),
        StrInput(
            name="api_key",
            display_name="API Key",
            info=(
                "Gateway API key. Leave empty to fall back to the global OpenAI key. "
                "If your gateway does not require auth, a placeholder key will be used."
            ),
            real_time_refresh=False,
            advanced=True,
            required=False,
            load_from_db=False,
        ),
        MessageTextInput(
            name="api_base",
            display_name="API Base URL",
            info="OpenAI-compatible API base URL provided by your company gateway.",
            required=False,
        ),
        IntInput(
            name="dimensions",
            display_name="Dimensions",
            info="The number of dimensions for output embeddings. Supported by selected models only.",
            advanced=True,
        ),
        IntInput(
            name="chunk_size",
            display_name="Chunk Size",
            advanced=True,
            value=1000,
        ),
        FloatInput(
            name="request_timeout",
            display_name="Request Timeout",
            advanced=True,
        ),
        IntInput(
            name="max_retries",
            display_name="Max Retries",
            advanced=True,
            value=3,
        ),
        BoolInput(
            name="show_progress_bar",
            display_name="Show Progress Bar",
            advanced=True,
        ),
        DictInput(
            name="model_kwargs",
            display_name="Model Kwargs",
            advanced=True,
            info="Additional keyword arguments to pass to the embedding client.",
        ),
    ]

    def update_build_config(self, build_config: dict, field_value: Any, field_name: str | None = None):
        if "provider" in build_config:
            build_config["provider"]["show"] = False
            build_config["provider"]["required"] = False

        for deprecated_field in [
            "base_url_ibm_watsonx",
            "project_id",
            "truncate_input_tokens",
            "input_text",
        ]:
            if deprecated_field in build_config:
                build_config[deprecated_field]["show"] = False
                build_config[deprecated_field]["required"] = False

        if "model" in build_config:
            build_config["model"]["input_types"] = ["Embeddings"]
            build_config["model"]["required"] = True
            build_config["model"]["type"] = "str"
            build_config["model"]["_input_type"] = "StrInput"
            build_config["model"]["info"] = (
                "Enter the embedding model name exposed by your company gateway, for example "
                "text-embedding-3-small or corp-embed-v1."
            )

        if "api_key" in build_config:
            api_key_config = build_config["api_key"]
            api_key_config["load_from_db"] = False
            api_key_config["required"] = False
            api_key_config["show"] = True
            api_key_config["real_time_refresh"] = False
            api_key_config["type"] = "str"
            api_key_config["_input_type"] = "StrInput"
            api_key_config["info"] = (
                "Directly enter the gateway API key. Leave empty to fall back to the global OpenAI key. "
                "If your gateway does not require auth, the component will use a placeholder key."
            )

        if "api_base" in build_config:
            build_config["api_base"]["info"] = "OpenAI-compatible API base URL provided by your company gateway."

        return build_config

    @staticmethod
    def _normalize_text_input(value: Any) -> str:
        if value is None:
            return ""
        if hasattr(value, "get_secret_value"):
            try:
                value = value.get_secret_value()
            except Exception:  # noqa: BLE001 - secret wrappers vary by runtime
                pass
        return str(value or "").strip()

    def _resolve_model_name(self) -> str:
        model_value = self.model

        if isinstance(model_value, list) and model_value:
            model_value = model_value[0]

        if isinstance(model_value, dict):
            model_name = str(model_value.get("name") or "").strip()
        else:
            model_name = str(model_value or "").strip()

        if model_name.lower().startswith("openai:"):
            model_name = model_name.split(":", 1)[1].strip()

        if not model_name:
            msg = "Embedding model is required."
            raise ValueError(msg)

        return model_name

    def build_embeddings(self) -> Embeddings:
        try:
            from langchain_core.embeddings import Embeddings as BaseEmbeddings

            if isinstance(self.model, BaseEmbeddings):
                return self.model
        except ImportError:
            pass

        model_name = self._resolve_model_name()
        manual_api_key = self._normalize_text_input(getattr(self, "api_key", ""))
        api_key = get_api_key_for_provider(self.user_id, "OpenAI", manual_api_key or None) or "EMPTY"
        kwargs = self._build_kwargs(model_name=model_name, api_key=api_key)
        embedding = OpenAIEmbeddings(**kwargs)

        return EmbeddingsWithModels(
            embeddings=embedding,
            available_models={model_name: embedding},
        )

    def _build_kwargs(self, model_name: str, api_key: str) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": model_name,
            "api_key": api_key,
            "chunk_size": int(self.chunk_size) if self.chunk_size else 1000,
            "max_retries": int(self.max_retries) if self.max_retries else 3,
        }

        if self.api_base:
            kwargs["base_url"] = self.api_base
        if self.dimensions:
            kwargs["dimensions"] = int(self.dimensions)
        if self.request_timeout:
            kwargs["timeout"] = float(self.request_timeout)
        if hasattr(self, "show_progress_bar"):
            kwargs["show_progress_bar"] = self.show_progress_bar
        if self.model_kwargs:
            kwargs["model_kwargs"] = self.model_kwargs

        return kwargs
