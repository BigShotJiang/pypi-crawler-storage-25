from __future__ import annotations

import json
import re
from collections.abc import Callable  # noqa: TC003 - required at runtime for dynamic exec()
from typing import Any

from lfx.base.models.unified_models import (
    apply_provider_variable_config_to_build_config,
    get_api_key_for_provider,
    get_language_model_options,
    get_llm,
    update_model_options_in_build_config,
)
from lfx.custom.custom_component.component import Component
from lfx.io import DataInput, IntInput, ModelInput, MultilineInput, Output, StrInput
from lfx.schema.data import Data
from lfx.schema.dataframe import DataFrame
from lfx.schema.message import Message
from lfx.utils.constants import MESSAGE_SENDER_AI
from langchain_openai import ChatOpenAI

TEXT_TRANSFORM_PROMPT = (
    "Given this text, create a Python lambda function that transforms it "
    "according to the instruction.\n"
    "The lambda should take a string parameter and return the transformed string.\n\n"
    "Text Preview:\n{text_preview}\n\n"
    "Instruction: {instruction}\n\n"
    "Return ONLY the lambda function and nothing else. No need for ```python or whatever.\n"
    "Just a string starting with lambda.\n"
    "Example: lambda text: text.upper()"
)

DATA_TRANSFORM_PROMPT = (
    "Given this data structure and examples, create a Python lambda function "
    "that implements the following instruction:\n\n"
    "Data Structure:\n{dump_structure}\n\n"
    "Example Items:\n{data_sample}\n\n"
    "Instruction: {instruction}\n\n"
    "Return ONLY the lambda function and nothing else. No need for ```python or whatever.\n"
    "Just a string starting with lambda.\n"
    "The lambda must be syntactically valid Python and preferably concise."
)

LAMBDA_REPAIR_PROMPT = (
    "The following lambda is syntactically invalid.\n"
    "Fix ONLY the syntax while keeping the same behavior.\n\n"
    "Return ONLY one valid Python lambda expression. Do not include explanations.\n\n"
    "Invalid lambda:\n{invalid_lambda}\n\n"
    "Syntax error:\n{syntax_error}"
)

LAMBDA_RUNTIME_REPAIR_PROMPT = (
    "The following lambda raised a runtime error.\n"
    "Rewrite it to satisfy the same instruction and work for the given input type.\n\n"
    "Return ONLY one valid Python lambda expression. Do not include explanations.\n\n"
    "Instruction:\n{instruction}\n\n"
    "Input Type:\n{input_type}\n\n"
    "Input Structure:\n{data_structure}\n\n"
    "Input Preview:\n{data_preview}\n\n"
    "Failing lambda:\n{invalid_lambda}\n\n"
    "Runtime error:\n{runtime_error}"
)


class EahSmartTransformComponent(Component):
    display_name = "Eah Smart Transform"
    description = "Uses an LLM to generate a function for filtering or transforming structured data and messages."
    documentation: str = "https://docs.langflow.org/smart-transform"
    name = "EahSmartTransformComponent"
    icon = "🤔"


    inputs = [
        DataInput(
            name="data",
            display_name="Data",
            info="The structured data or text messages to filter or transform using a lambda function.",
            input_types=["Data", "DataFrame", "Message"],
            is_list=True,
            required=True,
        ),
        ModelInput(
            name="model",
            display_name="Language Model",
            info="Select your model provider",
            real_time_refresh=True,
            required=True,
        ),
        StrInput(
            name="api_key",
            display_name="API Key",
            info="Model Provider API key",
            real_time_refresh=False,
            advanced=True,
            required=False,
            load_from_db=False,
        ),
        StrInput(
            name="base_url",
            display_name="Base URL",
            info="Custom base URL for OpenAI-compatible APIs (optional).",
            real_time_refresh=False,
            advanced=True,
            required=False,
            load_from_db=False,
        ),
        MultilineInput(
            name="filter_instruction",
            display_name="Instructions",
            info=(
                "Natural language instructions for how to filter or transform the data using a lambda function. "
                "Examples: 'Filter the data to only include items where status is active', "
                "'Convert the text to uppercase', 'Keep only first 100 characters'"
            ),
            value="Transform the data to...",
            required=True,
        ),
        IntInput(
            name="sample_size",
            display_name="Sample Size",
            info="For large datasets, number of items to sample from head/tail.",
            value=1000,
            advanced=True,
        ),
        IntInput(
            name="max_size",
            display_name="Max Size",
            info="Number of characters for the data to be considered large.",
            value=30000,
            advanced=True,
        ),
    ]

    outputs = [
        Output(
            display_name="Output",
            name="data_output",
            method="process_as_data",
        ),
        Output(
            display_name="Output",
            name="dataframe_output",
            method="process_as_dataframe",
        ),
        Output(
            display_name="Output",
            name="message_output",
            method="process_as_message",
        ),
    ]

    def _normalize_text_input(self, value: Any) -> str:
        """Normalize text-like values from config/runtime into a plain string."""
        if value is None:
            return ""
        if hasattr(value, "get_secret_value"):
            try:
                value = value.get_secret_value()
            except Exception:  # noqa: BLE001 - secret wrappers vary by runtime
                pass
        return str(value or "").strip()

    def _get_config_text_value(self, build_config: dict, key: str) -> str:
        """Safely read and normalize a field value from build config."""
        config = build_config.get(key)
        if not isinstance(config, dict):
            return ""
        return self._normalize_text_input(config.get("value"))

    def _get_provider_for_model_name(self, model_name: str) -> str:
        """Best-effort provider lookup by model name using unified model options."""
        normalized_name = str(model_name or "").strip()
        if not normalized_name:
            return ""

        try:
            options = get_language_model_options(user_id=self.user_id)
        except Exception:  # noqa: BLE001 - option fetch may fail depending on runtime services
            return ""

        for provider_group in options:
            provider = str(provider_group.get("provider") or "").strip()
            for model in provider_group.get("models", []):
                candidate_name = str(model.get("name") or model.get("model_name") or "").strip()
                if candidate_name == normalized_name:
                    return provider
        return ""

    def update_build_config(self, build_config: dict, field_value: str, field_name: str | None = None):
        """Dynamically update build config with user-filtered model options."""
        build_config = update_model_options_in_build_config(
            component=self,
            build_config=build_config,
            cache_key_prefix="language_model_options",
            get_options_func=get_language_model_options,
            field_name=field_name,
            field_value=field_value,
        )

        current_model_value = field_value if field_name == "model" else build_config.get("model", {}).get("value")
        provider = ""
        if isinstance(current_model_value, list) and current_model_value:
            selected_model = current_model_value[0]
            provider = (selected_model.get("provider") or "").strip()
            if not provider and selected_model.get("name"):
                provider = self._get_provider_for_model_name(str(selected_model["name"]))

        api_key_value_before = self._get_config_text_value(build_config, "api_key")
        base_url_value_before = self._get_config_text_value(build_config, "base_url")

        if field_name == "api_key":
            api_key_value_before = self._normalize_text_input(field_value)
        elif field_name == "base_url":
            base_url_value_before = self._normalize_text_input(field_value)

        if not api_key_value_before:
            api_key_value_before = self._normalize_text_input(getattr(self, "api_key", ""))
        if not base_url_value_before:
            base_url_value_before = self._normalize_text_input(getattr(self, "base_url", ""))

        if provider:
            build_config = apply_provider_variable_config_to_build_config(build_config, provider)

        if "api_key" in build_config:
            api_key_config = build_config["api_key"]
            api_key_config["required"] = False
            api_key_config["show"] = True
            api_key_config["advanced"] = True
            api_key_config["real_time_refresh"] = False
            api_key_config["load_from_db"] = False
            api_key_config["type"] = "str"
            api_key_config["_input_type"] = "StrInput"
            api_key_config["info"] = (
                "Custom API key for the selected provider. "
                "Leave empty to fall back to globally configured credentials."
            )
            api_key_config["value"] = api_key_value_before

        if "base_url" in build_config:
            base_url_config = build_config["base_url"]
            base_url_config["required"] = False
            base_url_config["show"] = True
            base_url_config["advanced"] = True
            base_url_config["real_time_refresh"] = False
            base_url_config["load_from_db"] = False
            base_url_config["info"] = "Optional custom base URL for OpenAI-compatible APIs."
            base_url_config["value"] = base_url_value_before

        return build_config

    def get_data_structure(self, data):
        """Extract the structure of data, replacing values with their types."""
        if isinstance(data, list):
            # For lists, get structure of first item if available
            if data:
                return [self.get_data_structure(data[0])]
            return []
        if isinstance(data, dict):
            return {k: self.get_data_structure(v) for k, v in data.items()}
        # For primitive types, return the type name
        return type(data).__name__

    def _validate_lambda(self, lambda_text: str) -> bool:
        """Validate the provided lambda function text."""
        normalized = lambda_text.strip()
        if not normalized.startswith("lambda") or ":" not in normalized:
            return False
        try:
            compile(normalized, "<generated_lambda>", "eval")
        except SyntaxError:
            return False
        return True

    def _extract_lambda_text(self, response_text: str) -> str:
        """Extract the first syntactically-valid lambda from an LLM response."""
        normalized_response = str(response_text or "").strip()
        if not normalized_response:
            msg = "Received empty response from model."
            raise ValueError(msg)

        fenced_blocks = re.findall(
            r"```(?:python)?\s*([\s\S]*?)```",
            normalized_response,
            flags=re.IGNORECASE,
        )
        candidate_sources = [*fenced_blocks, normalized_response]
        syntax_errors: list[str] = []

        for source in candidate_sources:
            for match in re.finditer(r"\blambda\b", source):
                tail = source[match.start() :].strip()
                lines = [
                    line.rstrip()
                    for line in tail.splitlines()
                    if line.strip() and not line.strip().startswith("```")
                ]
                if not lines:
                    continue

                for prefix_len in range(1, len(lines) + 1):
                    candidate = "\n".join(lines[:prefix_len]).strip()
                    if ":" not in candidate:
                        continue
                    try:
                        compile(candidate, "<generated_lambda>", "eval")
                    except SyntaxError as err:
                        syntax_errors.append(f"line {err.lineno}: {err.msg}")
                        continue
                    return candidate

        suffix = f" Last syntax error: {syntax_errors[-1]}." if syntax_errors else ""
        msg = f"Could not parse a valid lambda from model response.{suffix}"
        raise ValueError(msg)

    def _build_lambda_repair_prompt(self, invalid_lambda: str, syntax_error: str) -> str:
        """Build retry prompt for fixing invalid lambda syntax."""
        return LAMBDA_REPAIR_PROMPT.format(
            invalid_lambda=(invalid_lambda or "").strip(),
            syntax_error=(syntax_error or "").strip(),
        )

    def _build_runtime_data_preview(self, data: Any) -> str:
        """Build a bounded preview of runtime input data for repair prompts."""
        try:
            preview = json.dumps(data, ensure_ascii=False, default=str)
        except TypeError:
            preview = str(data)
        limit = max(int(getattr(self, "sample_size", 1000) or 1000), 200)
        if len(preview) > limit:
            return f"{preview[:limit]}\n... (truncated, total {len(preview)} chars)"
        return preview

    def _build_lambda_runtime_repair_prompt(self, invalid_lambda: str, runtime_error: str, data: Any) -> str:
        """Build retry prompt for fixing lambda runtime errors."""
        data_structure = json.dumps(self.get_data_structure(data), ensure_ascii=False)
        data_preview = self._build_runtime_data_preview(data)
        return LAMBDA_RUNTIME_REPAIR_PROMPT.format(
            instruction=str(getattr(self, "filter_instruction", "") or "").strip(),
            input_type=self._get_input_type_name(),
            data_structure=data_structure,
            data_preview=data_preview,
            invalid_lambda=(invalid_lambda or "").strip(),
            runtime_error=(runtime_error or "").strip(),
        )

    def _get_input_type_name(self) -> str:
        """Detect and return the input type name for error messages."""
        if isinstance(self.data, Message):
            return "Message"
        if isinstance(self.data, DataFrame):
            return "DataFrame"
        if isinstance(self.data, Data):
            return "Data"
        if isinstance(self.data, list) and len(self.data) > 0:
            first = self.data[0]
            if isinstance(first, Message):
                return "Message"
            if isinstance(first, DataFrame):
                return "DataFrame"
            if isinstance(first, Data):
                return "Data"
        return "unknown"

    def _extract_message_text(self) -> str:
        """Extract text content from Message input(s)."""
        if isinstance(self.data, Message):
            return self.data.text or ""

        texts = [msg.text or "" for msg in self.data if isinstance(msg, Message)]
        return "\n\n".join(texts) if len(texts) > 1 else (texts[0] if texts else "")

    def _extract_structured_data(self) -> dict | list:
        """Extract structured data from Data or DataFrame input(s)."""
        if isinstance(self.data, DataFrame):
            rows = self.data.to_dict(orient="records")
            if len(rows) == 1 and isinstance(rows[0], dict):
                return rows[0]
            return rows

        if hasattr(self.data, "data"):
            return self.data.data

        if not isinstance(self.data, list):
            return self.data

        combined_data: list[dict] = []
        for item in self.data:
            if isinstance(item, DataFrame):
                combined_data.extend(item.to_dict(orient="records"))
            elif hasattr(item, "data"):
                if isinstance(item.data, dict):
                    combined_data.append(item.data)
                elif isinstance(item.data, list):
                    combined_data.extend(item.data)

        if len(combined_data) == 1 and isinstance(combined_data[0], dict):
            return combined_data[0]
        if len(combined_data) == 0:
            return {}
        return combined_data

    def _is_message_input(self) -> bool:
        """Check if input is Message type."""
        if isinstance(self.data, Message):
            return True
        return isinstance(self.data, list) and len(self.data) > 0 and isinstance(self.data[0], Message)

    def _build_text_prompt(self, text: str) -> str:
        """Build prompt for text/Message transformation."""
        text_length = len(text)
        if text_length > self.max_size:
            text_preview = (
                f"Text length: {text_length} characters\n\n"
                f"First {self.sample_size} characters:\n{text[: self.sample_size]}\n\n"
                f"Last {self.sample_size} characters:\n{text[-self.sample_size :]}"
            )
        else:
            text_preview = text

        return TEXT_TRANSFORM_PROMPT.format(text_preview=text_preview, instruction=self.filter_instruction)

    def _build_data_prompt(self, data: dict | list) -> str:
        """Build prompt for structured data transformation."""
        dump = json.dumps(data)
        dump_structure = json.dumps(self.get_data_structure(data))

        if len(dump) > self.max_size:
            data_sample = (
                f"Data is too long to display...\n\nFirst lines (head): {dump[: self.sample_size]}\n\n"
                f"Last lines (tail): {dump[-self.sample_size :]}"
            )
        else:
            data_sample = dump

        return DATA_TRANSFORM_PROMPT.format(
            dump_structure=dump_structure, data_sample=data_sample, instruction=self.filter_instruction
        )

    def _parse_lambda_from_response(self, response_text: str) -> Callable[[Any], Any]:
        """Extract and validate lambda function from LLM response."""
        lambda_text = self._extract_lambda_text(response_text)
        self._last_generated_lambda = lambda_text
        self.log(f"Generated lambda: {lambda_text}")

        if not self._validate_lambda(lambda_text):
            msg = f"Invalid lambda format: {lambda_text}"
            raise ValueError(msg)
        try:
            return eval(lambda_text)  # noqa: S307
        except SyntaxError as err:
            msg = f"Invalid lambda syntax on line {err.lineno}: {err.msg}. Lambda: {lambda_text}"
            raise ValueError(msg) from err

    def _get_selected_provider(self) -> str:
        """Resolve selected provider name from the current model value."""
        model_value: Any = self.model
        if isinstance(model_value, list) and model_value:
            model_value = model_value[0]

        if isinstance(model_value, dict):
            provider = str(model_value.get("provider") or "").strip()
            if provider:
                return provider
            model_name = str(model_value.get("name") or "").strip()
            if model_name:
                return self._get_provider_for_model_name(model_name)
        elif isinstance(model_value, str):
            return self._get_provider_for_model_name(model_value)
        return ""

    def _resolve_model_name(self) -> str:
        """Resolve model name from ModelInput value."""
        model_value: Any = self.model
        if isinstance(model_value, list) and model_value:
            model_value = model_value[0]

        if isinstance(model_value, dict):
            model_name = str(model_value.get("name") or "").strip()
        else:
            model_name = str(model_value or "").strip()

        if model_name.lower().startswith("openai:"):
            model_name = model_name.split(":", 1)[1].strip()

        if not model_name:
            msg = "A model selection is required."
            raise ValueError(msg)

        return model_name

    def _resolve_manual_api_key(self) -> str:
        """Resolve API key from component input, preferring explicit user input."""
        return self._normalize_text_input(getattr(self, "api_key", ""))

    def _build_llm(self):
        """Build LLM client with optional custom base URL support."""
        base_url = str(getattr(self, "base_url", "") or "").strip()
        provider = self._get_selected_provider()
        manual_api_key = self._resolve_manual_api_key()

        # When base_url is provided, follow smart-router style for OpenAI-compatible endpoints.
        if base_url and provider != "Ollama":
            model_name = self._resolve_model_name()
            api_key = manual_api_key or get_api_key_for_provider(self.user_id, "OpenAI", None) or "EMPTY"
            return ChatOpenAI(
                temperature=0.0,
                model=model_name,
                api_key=api_key,
                base_url=base_url,
            )

        return get_llm(
            model=self.model,
            user_id=self.user_id,
            api_key=manual_api_key or None,
            ollama_base_url=base_url or None,
        )

    async def _execute_lambda(self) -> Any:
        """Generate and execute a lambda function based on input type."""
        if self._is_message_input():
            data: Any = self._extract_message_text()
            prompt = self._build_text_prompt(data)
        else:
            data = self._extract_structured_data()
            prompt = self._build_data_prompt(data)

        llm = self._build_llm()
        response = await llm.ainvoke(prompt)
        response_text = response.content if hasattr(response, "content") else str(response)
        last_error: Exception | None = None

        for attempt in range(3):
            try:
                parsed_fn = self._parse_lambda_from_response(response_text)
            except ValueError as err:
                last_error = err
                if attempt >= 2:
                    break
                self.log(f"Lambda parse failed on attempt {attempt + 1}: {err}")
                repair_prompt = self._build_lambda_repair_prompt(
                    invalid_lambda=response_text,
                    syntax_error=str(err),
                )
                response = await llm.ainvoke(repair_prompt)
                response_text = response.content if hasattr(response, "content") else str(response)
                continue

            try:
                return parsed_fn(data)
            except Exception as err:  # noqa: BLE001 - generated lambda can raise any runtime error
                last_error = err
                if attempt >= 2:
                    break
                self.log(f"Lambda execution failed on attempt {attempt + 1}: {type(err).__name__}: {err}")
                runtime_prompt = self._build_lambda_runtime_repair_prompt(
                    invalid_lambda=getattr(self, "_last_generated_lambda", response_text),
                    runtime_error=f"{type(err).__name__}: {err}",
                    data=data,
                )
                response = await llm.ainvoke(runtime_prompt)
                response_text = response.content if hasattr(response, "content") else str(response)

        if last_error is not None:
            raise last_error
        msg = "Failed to generate lambda from model response."
        raise ValueError(msg)

    def _handle_process_error(self, error: Exception, output_type: str) -> None:
        """Handle errors from process methods with context-aware messages."""
        input_type = self._get_input_type_name()
        lambda_preview = str(getattr(self, "_last_generated_lambda", "") or "").replace("\n", " ").strip()
        if len(lambda_preview) > 240:
            lambda_preview = f"{lambda_preview[:240]}..."
        lambda_hint = f" Generated lambda: {lambda_preview}." if lambda_preview else ""
        error_msg = (
            f"Failed to process {output_type} output. "
            f"Error: {error}. "
            f"Input type was {input_type}. "
            f"Try using the same output type as the input."
            f"{lambda_hint}"
        )
        raise ValueError(error_msg) from error

    def _convert_result_to_data(self, result: Any) -> Data:
        """Convert lambda result to Data object."""
        if isinstance(result, dict):
            return Data(data=result)
        if isinstance(result, list):
            return Data(data={"_results": result})
        return Data(data={"text": str(result)})

    def _convert_result_to_dataframe(self, result: Any) -> DataFrame:
        """Convert lambda result to DataFrame object."""
        if isinstance(result, list):
            if all(isinstance(item, dict) for item in result):
                return DataFrame(result)
            return DataFrame([{"value": item} for item in result])
        if isinstance(result, dict):
            return DataFrame([result])
        return DataFrame([{"value": str(result)}])

    def _convert_result_to_message(self, result: Any) -> Message:
        """Convert lambda result to Message object."""
        if isinstance(result, str):
            return Message(text=result, sender=MESSAGE_SENDER_AI)
        if isinstance(result, list):
            text = "\n".join(str(item) for item in result)
            return Message(text=text, sender=MESSAGE_SENDER_AI)
        if isinstance(result, dict):
            text = json.dumps(result, indent=2)
            return Message(text=text, sender=MESSAGE_SENDER_AI)
        return Message(text=str(result), sender=MESSAGE_SENDER_AI)

    async def process_as_data(self) -> Data:
        """Process the data and return as a Data object."""
        try:
            result = await self._execute_lambda()
            return self._convert_result_to_data(result)
        except Exception as e:  # noqa: BLE001 - dynamic lambda can raise any exception
            self._handle_process_error(e, "Data")

    async def process_as_dataframe(self) -> DataFrame:
        """Process the data and return as a DataFrame."""
        try:
            result = await self._execute_lambda()
            return self._convert_result_to_dataframe(result)
        except Exception as e:  # noqa: BLE001 - dynamic lambda can raise any exception
            self._handle_process_error(e, "DataFrame")

    async def process_as_message(self) -> Message:
        """Process the data and return as a Message."""
        try:
            result = await self._execute_lambda()
            return self._convert_result_to_message(result)
        except Exception as e:  # noqa: BLE001 - dynamic lambda can raise any exception
            self._handle_process_error(e, "Message")
