from .eah_agent_comp import EahAgentComponent
from lfx.schema.message import Message
from lfx.schema.data import Data
from lfx.io import Output
from lfx.custom.custom_component.component import get_component_toolkit
import tiktoken


class EahAgentStatComponent(EahAgentComponent):
    display_name: str = "Eah Agent (Token Stats)"
    name: str = "EahAgentStat"
    outputs = [
        Output(name="response", display_name="Response", method="message_response"),
        Output(name="token_stats", display_name="Token Stats", method="token_stats_output"),
    ]

    def _get_text(self, obj) -> str:
        if obj is None:
            return ""
        if hasattr(obj, "content"):
            return str(getattr(obj, "content"))
        if hasattr(obj, "text"):
            return str(getattr(obj, "text"))
        return str(obj)

    def _get_encoding(self):
        model = getattr(self, "model_name", "") or ""
        try:
            return tiktoken.encoding_for_model(model)
        except Exception:
            return tiktoken.get_encoding("cl100k_base")

    def _count_tokens(self, text: str) -> int:
        if not text:
            return 0
        enc = self._get_encoding()
        try:
            return len(enc.encode(text))
        except Exception:
            return len(text.split())

    def _compute_prompt_tokens(self) -> int:
        total = 0
        total += self._count_tokens(getattr(self, "system_prompt", "") or "")
        for m in getattr(self, "chat_history", []) or []:
            total += self._count_tokens(self._get_text(m))
        total += self._count_tokens(self._get_text(getattr(self, "input_value", None)))
        return total

    def _push_usage(self, prompt_tokens: int, completion_tokens: int) -> None:
        usage = {
            "prompt_tokens": int(prompt_tokens),
            "completion_tokens": int(completion_tokens),
            "total_tokens": int(prompt_tokens + completion_tokens),
        }
        token_stats = self._get_token_stats_store()
        token_stats["runs"].append(usage)
        token_stats["total_prompt_tokens"] += usage["prompt_tokens"]
        token_stats["total_completion_tokens"] += usage["completion_tokens"]
        token_stats["total_tokens"] += usage["total_tokens"]

    def _get_token_stats_store(self) -> dict:
        token_stats = getattr(self, "token_stats", None)
        if not isinstance(token_stats, dict):
            token_stats = getattr(self, "_token_stats_store", None)

        if not isinstance(token_stats, dict):
            token_stats = {
                "runs": [],
                "total_prompt_tokens": 0,
                "total_completion_tokens": 0,
                "total_tokens": 0,
            }

        if not isinstance(token_stats.get("runs"), list):
            token_stats["runs"] = []
        token_stats["total_prompt_tokens"] = int(token_stats.get("total_prompt_tokens", 0))
        token_stats["total_completion_tokens"] = int(token_stats.get("total_completion_tokens", 0))
        token_stats["total_tokens"] = int(token_stats.get("total_tokens", 0))

        setattr(self, "_token_stats_store", token_stats)
        try:
            setattr(self, "token_stats", token_stats)
        except Exception:
            pass
        return token_stats

    def _set_last_response(self, msg: Message | None = None, text: str = "") -> None:
        if msg is not None:
            self._last_response_message = msg
        normalized_text = str(text or "").strip()
        if normalized_text:
            self._last_response_text = normalized_text
            return
        if msg is not None:
            fallback_text = self._get_text(msg)
            if fallback_text:
                self._last_response_text = str(fallback_text)

    def _get_last_response_text(self) -> str:
        cached_text = getattr(self, "_last_response_text", "")
        if isinstance(cached_text, str) and cached_text:
            return cached_text
        cached_msg = getattr(self, "_last_response_message", None)
        if cached_msg is not None:
            return self._get_text(cached_msg)
        return ""

    async def message_response(self) -> Message:
        msg = await super().message_response()
        try:
            prompt_tokens = self._compute_prompt_tokens()
            text = self._get_text(msg)
            self._set_last_response(msg=msg, text=text)
            completion_tokens = self._count_tokens(text)
            self._push_usage(prompt_tokens, completion_tokens)
            usage = {
                "prompt_tokens": int(prompt_tokens),
                "completion_tokens": int(completion_tokens),
                "total_tokens": int(prompt_tokens + completion_tokens),
            }
            try:
                if hasattr(msg, "data") and isinstance(getattr(msg, "data"), dict):
                    msg.data["token_stats"] = usage
                    if "text" not in msg.data and text:
                        msg.data["text"] = text
                else:
                    setattr(msg, "data", {"text": text, "token_stats": usage})
            except Exception:
                pass
        except Exception:
            pass
        return msg

    async def json_response(self) -> Data:
        data = await super().json_response()
        try:
            prompt_tokens = self._compute_prompt_tokens()
            content = ""
            if isinstance(data, Data):
                payload = getattr(data, "data", None)
                if isinstance(payload, dict):
                    if "content" in payload and isinstance(payload["content"], str):
                        content = payload["content"]
                    elif "results" in payload and isinstance(payload["results"], list):
                        content = str(payload["results"])
                    usage = {
                        "prompt_tokens": int(prompt_tokens),
                        "completion_tokens": int(self._count_tokens(content)),
                        "total_tokens": int(prompt_tokens + self._count_tokens(content)),
                    }
                    try:
                        payload["token_stats"] = usage
                    except Exception:
                        pass
                else:
                    content = str(payload)
            else:
                content = self._get_text(data)
            completion_tokens = self._count_tokens(content)
            self._push_usage(prompt_tokens, completion_tokens)
            if content:
                self._set_last_response(text=content)
        except Exception:
            pass
        return data

    async def token_stats_output(self) -> Message:
        result_msg = None
        token_stats = self._get_token_stats_store()
        if not token_stats.get("runs"):
            result_msg = await self.message_response()
            token_stats = self._get_token_stats_store()

            # If usage tracking failed silently in message_response, backfill from the current run.
            if not token_stats.get("runs"):
                response_text = self._get_text(result_msg)
                prompt_tokens = self._compute_prompt_tokens()
                completion_tokens = self._count_tokens(response_text)
                self._push_usage(prompt_tokens, completion_tokens)
                token_stats = self._get_token_stats_store()
                self._set_last_response(msg=result_msg, text=response_text)

        totals = {
            "prompt_tokens": int(token_stats.get("total_prompt_tokens", 0)),
            "completion_tokens": int(token_stats.get("total_completion_tokens", 0)),
            "total_tokens": int(token_stats.get("total_tokens", 0)),
        }

        response_text = self._get_last_response_text()
        if not response_text and result_msg is not None:
            response_text = self._get_text(result_msg)

        cached_msg = result_msg or getattr(self, "_last_response_message", None)
        if isinstance(cached_msg, Message):
            msg = cached_msg
        else:
            msg = Message(text=response_text)
        setattr(msg, "text", response_text)

        msg_data = getattr(msg, "data", None)
        if not isinstance(msg_data, dict):
            msg_data = {}
        msg_data["text"] = response_text
        msg_data["token_stats"] = {**totals, "response": response_text}
        setattr(msg, "data", msg_data)

        self._set_last_response(msg=msg, text=response_text)
        return msg

    async def _get_tools(self):
        toolkit = get_component_toolkit()
        tools = toolkit(component=self).get_tools(
            callbacks=self.get_langchain_callbacks(),
        )
        if hasattr(self, "tools_metadata"):
            tools = toolkit(component=self, metadata=self.tools_metadata).update_tools_metadata(tools=tools)
        return tools
