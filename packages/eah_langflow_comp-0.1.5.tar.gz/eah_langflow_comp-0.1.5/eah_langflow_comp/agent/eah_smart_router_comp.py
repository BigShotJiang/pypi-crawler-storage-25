from __future__ import annotations

import logging
from copy import deepcopy
from typing import Any
from urllib.parse import urlparse

from langchain_openai import ChatOpenAI

from lfx.components.llm_operations.llm_conditional_router import SmartRouterComponent
from lfx.io import BoolInput, SecretStrInput, StrInput

logger = logging.getLogger("EahSmartRouter")


def _clone_parent_input(input_name: str):
    for component_input in SmartRouterComponent.inputs:
        if getattr(component_input, "name", None) == input_name:
            return deepcopy(component_input)
    msg = f"SmartRouter parent input '{input_name}' not found."
    raise ValueError(msg)


class EahSmartRouterComponent(SmartRouterComponent):
    display_name = "Eah Smart Router"
    icon = "🤔"
    name = "SmartRouter"

    inputs = [
        StrInput(
            name="model",
            display_name="Language Model",
            info="Enter your model name (for example: gpt-4o-mini).",
            required=True,
        ),
        SecretStrInput(
            name="api_key",
            display_name="API Key",
            info="Model provider API key.",
            real_time_refresh=False,
            advanced=True,
            required=False,
        ),
        StrInput(
            name="base_url",
            display_name="Base URL",
            info="Custom base URL for OpenAI-compatible API providers.",
            real_time_refresh=False,
            advanced=True,
            required=False,
        ),
        _clone_parent_input("input_text"),
        _clone_parent_input("routes"),
        _clone_parent_input("message"),
        _clone_parent_input("enable_else_output"),
        BoolInput(
            name="prefer_rule_routing",
            display_name="Prefer Rule Routing",
            info="Try keyword/regex rules before invoking the model.",
            value=True,
            advanced=True,
            real_time_refresh=True,
        ),
        _clone_parent_input("custom_prompt"),
    ]

    def update_build_config(self, build_config: dict, field_value: str, field_name: str | None = None):
        """Keep static build config to avoid provider option remapping."""
        return build_config

    @staticmethod
    def _normalize_secret(value: Any) -> str:
        if value is None:
            return ""
        if hasattr(value, "get_secret_value"):
            try:
                value = value.get_secret_value()
            except Exception:  # noqa: BLE001
                pass
        return str(value or "").strip()

    @staticmethod
    def _preprocess_text(text: str) -> str:
        value = str(text or "").strip()
        if value.startswith("```") and value.endswith("```"):
            value = value[3:-3].strip()

        pairs = {("`", "`"), ('"', '"'), ("'", "'"), ("“", "”"), ("‘", "’")}
        changed = True
        while changed and len(value) >= 2:
            changed = False
            for left, right in pairs:
                if value.startswith(left) and value.endswith(right):
                    value = value[len(left) : -len(right)].strip()
                    changed = True
        return value

    @staticmethod
    def _map_result_to_category(result: str, categories: list[dict]) -> str | None:
        normalized = str(result or "").strip().lower()
        if not normalized:
            return None

        if normalized.isdigit():
            idx = int(normalized) - 1
            if 0 <= idx < len(categories):
                category_name = categories[idx].get("route_category", "")
                return category_name if category_name else None

        for category in categories:
            category_name = str(category.get("route_category", "")).strip()
            if category_name and category_name.lower() == normalized:
                return category_name

        for category in categories:
            category_name = str(category.get("route_category", "")).strip()
            if category_name and (category_name.lower() in normalized or normalized in category_name.lower()):
                return category_name

        return None

    def _rule_based_categorization(self, input_text: str, categories: list[dict]) -> str | None:
        text = input_text.lower()
        try:
            parsed = urlparse(input_text)
            host = parsed.netloc.lower()
            path = parsed.path.lower()
        except Exception:  # noqa: BLE001
            host = ""
            path = ""

        for category in categories:
            name = str(category.get("route_category", "")).strip()
            description = str(category.get("route_description", "") or "").strip()
            if not name:
                continue

            if description:
                if description.startswith("re:"):
                    import re

                    pattern = description[3:].strip()
                    try:
                        if re.search(pattern, text, flags=re.IGNORECASE) or (
                            host and re.search(pattern, host, flags=re.IGNORECASE)
                        ):
                            return name
                    except Exception:  # noqa: BLE001
                        pass
                else:
                    tokens = [token.strip().lower() for token in description.split(",") if token.strip()]
                    for token in tokens:
                        if token and (token in text or (host and token in host) or (path and token in path)):
                            return name

            lowered_name = name.lower()
            if lowered_name in text or (host and lowered_name in host) or (path and lowered_name in path):
                return name
        return None

    def _get_categorization(self) -> str:
        if self._categorization_result is not None:
            return self._categorization_result

        categories = getattr(self, "routes", []) or []
        input_text = self._preprocess_text(getattr(self, "input_text", ""))

        if not input_text:
            self.status = "Input text is empty."
            self._categorization_result = "NONE"
            return self._categorization_result

        if getattr(self, "prefer_rule_routing", True):
            rule_result = self._rule_based_categorization(input_text, categories)
            if rule_result:
                self.status = f"Rule matched category: {rule_result}"
                self._categorization_result = rule_result
                return self._categorization_result

        api_key = self._normalize_secret(getattr(self, "api_key", ""))
        base_url = self._preprocess_text(getattr(self, "base_url", ""))
        model_name = self._preprocess_text(getattr(self, "model", ""))

        llm = None
        if model_name:
            try:
                llm = ChatOpenAI(
                    temperature=0.0,
                    model=model_name,
                    api_key=api_key or None,
                    base_url=base_url or None,
                )
            except Exception as e:  # noqa: BLE001
                logger.warning("LLM initialization failed: %s", e)

        if llm is None or not categories:
            fallback = self._rule_based_categorization(input_text, categories)
            self._categorization_result = fallback or "NONE"
            self.status = "Model unavailable or routes empty; using rule fallback."
            return self._categorization_result

        try:
            category_pairs = []
            for idx, category in enumerate(categories):
                category_name = str(category.get("route_category", "")).strip()
                category_description = str(category.get("route_description", "") or "").strip()
                number = idx + 1
                if category_description:
                    category_pairs.append(f"{number}. {category_name} - {category_description}")
                else:
                    category_pairs.append(f"{number}. {category_name}")

            indexes = "\n".join(category_pairs)
            custom_prompt = str(getattr(self, "custom_prompt", "") or "").strip()
            if custom_prompt:
                prompt = (
                    "Choose exactly one best-matching category from the list and return only the number or name.\n"
                    f"{indexes}\n\n"
                    f"Additional instructions:\n{custom_prompt}\n\n"
                    f"Text:\n{input_text}\n\n"
                    "Output one number or category name:"
                )
            else:
                prompt = (
                    "Choose exactly one best-matching category from the list and return only the number or name. "
                    "If none match, return NONE.\n"
                    f"{indexes}\n\n"
                    f"Text:\n{input_text}\n\n"
                    "Output one number or category name:"
                )

            response = llm.invoke(prompt)
            raw_result = self._preprocess_text(getattr(response, "content", str(response)))

            mapped = self._map_result_to_category(raw_result, categories)
            if mapped:
                self._categorization_result = mapped
            else:
                fallback = self._rule_based_categorization(input_text, categories)
                self._categorization_result = fallback or ("NONE" if not raw_result else raw_result)

            if str(self._categorization_result).lower() == "none":
                self._categorization_result = "NONE"
            self.status = f"Categorization result: {self._categorization_result}"
        except Exception as e:  # noqa: BLE001
            logger.error("Categorization failed: %s", e, exc_info=True)
            self.status = f"Categorization error: {e!s}"
            self._categorization_result = "NONE"

        return self._categorization_result


__all__ = ["EahSmartRouterComponent"]
