import shutil
import tempfile
from contextlib import asynccontextmanager
from pathlib import Path

import anyio
from langchain_community.document_loaders.git import GitLoader

from lfx.components.git.git import GitLoaderComponent
from lfx.io import MessageTextInput


class EahGitLoaderComponent(GitLoaderComponent):
    display_name = "Eah Git Loader"
    icon = "😃"

    inputs = [
        *GitLoaderComponent.inputs,
        MessageTextInput(
            name="dir_filter",
            display_name="Directory Filter",
            required=False,
            advanced=True,
            info=(
                "Specify directories to include (relative to repo root).\n"
                "Multiple directories can be separated by commas.\n"
                "Example: 'src/, tests/utils/, docs/'\n"
                "Use '!' to exclude directories: '!venv/, !node_modules/'"
            ),
        ),
    ]

    @staticmethod
    def check_directory_patterns(file_path: str | Path, repo_root: str, patterns: str) -> bool:
        """Check if a file is in the specified directories (relative to repo root)."""
        if not patterns or patterns.isspace():
            return True

        file_path_obj = Path(file_path).resolve()
        repo_root_obj = Path(repo_root).resolve()

        try:
            rel_path = file_path_obj.relative_to(repo_root_obj)
        except ValueError:
            return False

        rel_path_str = str(rel_path)
        pattern_list: list[str] = [pattern.strip() for pattern in patterns.split(",") if pattern.strip()]
        if not pattern_list:
            return True

        for pattern in pattern_list:
            if pattern.startswith("!"):
                exclude_pattern = pattern[1:].rstrip("/")
                if rel_path_str.startswith(exclude_pattern):
                    return False

        include_patterns = [p.rstrip("/") for p in pattern_list if not p.startswith("!")]
        if not include_patterns:
            return True

        return any(rel_path_str.startswith(pattern) for pattern in include_patterns)

    def build_combined_filter(
        self,
        repo_root: str,
        dir_filter_patterns: str | None = None,
        file_filter_patterns: str | None = None,
        content_filter_pattern: str | None = None,
    ):
        """Build a combined filter function from directory, file and content patterns."""

        def combined_filter(file_path: str) -> bool:
            try:
                path = Path(file_path)
                if not path.exists():
                    return False
                if self.is_binary(path):
                    return False
                if dir_filter_patterns and not self.check_directory_patterns(path, repo_root, dir_filter_patterns):
                    return False
                if file_filter_patterns and not self.check_file_patterns(path, file_filter_patterns):
                    return False
                return not (content_filter_pattern and not self.check_content_pattern(path, content_filter_pattern))
            except Exception:  # noqa: BLE001
                return False

        return combined_filter

    @asynccontextmanager
    async def temp_clone_dir(self):
        """Context manager for handling temporary clone directory."""
        temp_dir = None
        try:
            temp_dir = tempfile.mkdtemp(prefix="langflow_clone_")
            yield temp_dir
        finally:
            if temp_dir and Path(temp_dir).exists():
                await anyio.to_thread.run_sync(lambda: shutil.rmtree(temp_dir, ignore_errors=True))

    async def build_gitloader(self) -> GitLoader:
        dir_filter_patterns = getattr(self, "dir_filter", None)
        file_filter_patterns = getattr(self, "file_filter", None)
        content_filter_pattern = getattr(self, "content_filter", None)

        repo_source = getattr(self, "repo_source", None)
        if repo_source == "Local":
            repo_path = self.repo_path
            clone_url = None
        else:
            clone_url = self.clone_url
            async with self.temp_clone_dir() as temp_dir:
                repo_path = temp_dir

        combined_filter = self.build_combined_filter(
            repo_root=repo_path,
            dir_filter_patterns=dir_filter_patterns,
            file_filter_patterns=file_filter_patterns,
            content_filter_pattern=content_filter_pattern,
        )

        branch = getattr(self, "branch", None)
        if not branch:
            branch = None

        return GitLoader(
            repo_path=repo_path,
            clone_url=clone_url if repo_source == "Remote" else None,
            branch=branch,
            file_filter=combined_filter,
        )
