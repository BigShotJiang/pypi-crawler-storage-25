import io

from bs4 import BeautifulSoup
from markitdown import MarkItDown

from lfx.components.data_source.url import URLComponent
from lfx.log.logger import logger


class EahURLComponent(URLComponent):
    display_name = "Eah URL"
    icon = "😃"
    name = "EahURLComponent"

    @staticmethod
    def _text_extractor(x: str) -> str:
        """Extract clean text from HTML with fallback parser and graceful failure."""
        try:
            return BeautifulSoup(x, "html.parser").get_text()
        except Exception as e:  # noqa: BLE001 - extractor must be resilient to malformed HTML
            logger.warning(f"HTML text extraction failed, skipping page: {str(e)[:100]}")
            return ""

    @staticmethod
    def _markdown_extractor(x: str) -> str:
        """Convert HTML to Markdown with graceful failure."""
        try:
            stream = io.BytesIO(x.encode("utf-8", errors="ignore"))
            result = MarkItDown(enable_plugins=False).convert_stream(stream)
            return result.markdown
        except Exception as e:  # noqa: BLE001 - conversion can fail on malformed HTML
            logger.warning(f"Markdown conversion failed, skipping page: {str(e)[:100]}")
            return ""
