from __future__ import annotations

import copy
import functools
import json

from lfx.base.mcp.util import create_input_schema_from_json_schema, update_tools
from lfx.components.models_and_agents.mcp_component import MCPToolsComponent
from lfx.io.schema import flatten_schema, schema_to_langflow_inputs
from lfx.log.logger import logger
from lfx.schema.dataframe import DataFrame
from lfx.schema.message import Message
from lfx.base.agents.utils import maybe_unflatten_dict


class EahMCPToolsComponent(MCPToolsComponent):
    """MCP Tools 组件的扩展版本。

    在 MCPToolsComponent 基础上，额外处理 MCP server 返回的 tool 参数名中
    含有前置下划线（如 ``_param``）的场景。

    Pydantic v2 禁止以 ``_`` 开头的字段名，因此在构建 args_schema 时会报错。
    本组件通过在 ``lfx.schema.json_schema`` 模块的 ``create_model`` 上安装
    一次性字段名净化 patch 来绕过该限制，并在调用 MCP server 时还原原始名。

    重写的方法
    ----------
    _validate_schema_inputs   -- 净化 schema 后再生成 LangFlow 输入
    get_inputs_for_all_tools  -- 净化 schema 后再生成 LangFlow 输入
    update_tool_list          -- 通过 _safe_update_tools 加载 tools
    build_output              -- 执行时还原字段名映射
    """

    display_name = "Eah MCP Tools"
    name = "EahMCPTools"
    icon = "😃"

    # ------------------------------------------------------------------
    # 字段名净化工具方法
    # ------------------------------------------------------------------

    @staticmethod
    def _sanitize_field_name(name: str) -> str:
        """将前置下划线字段名改为 ``field_xxx`` 形式。"""
        if name.startswith("_"):
            return "field" + name
        return name

    @staticmethod
    def _build_field_name_mapping(schema_dict: dict) -> dict[str, str]:
        """构建 净化名 -> 原始名 的映射表。"""
        mapping = {}
        for field_name in schema_dict.get("properties", {}):
            sanitized = EahMCPToolsComponent._sanitize_field_name(field_name)
            if sanitized != field_name:
                mapping[sanitized] = field_name
        return mapping

    @staticmethod
    def _sanitize_schema_dict(schema_dict: dict) -> dict:
        """返回将 properties 中前置下划线字段名替换后的 schema 副本。"""
        schema_copy = copy.deepcopy(schema_dict)
        new_props = {}
        for k, v in schema_copy.get("properties", {}).items():
            new_props[EahMCPToolsComponent._sanitize_field_name(k)] = v
        schema_copy["properties"] = new_props
        if "required" in schema_copy:
            schema_copy["required"] = [
                EahMCPToolsComponent._sanitize_field_name(f)
                for f in schema_copy["required"]
            ]
        return schema_copy

    # ------------------------------------------------------------------
    # json_schema.create_model 一次性 patch
    # ------------------------------------------------------------------

    @staticmethod
    def _install_json_schema_create_model_patch() -> None:
        """在 lfx.schema.json_schema 模块的 create_model 上安装净化 patch（幂等）。

        该 patch 将字段名 ``_xxx`` 改为 ``field_xxx`` 再传给 Pydantic，
        并在生成的 model class 上附加 ``__mcp_field_name_map__``（净化名->原始名），
        供 coroutine 包装器还原参数名时使用。
        """
        try:
            import lfx.schema.json_schema as _js  # noqa: PLC2701

            if getattr(_js, "_mcp_create_model_patched", False):
                return

            _orig = _js.create_model

            def _sanitized_create_model(__model_name: str, **field_definitions):
                renamed: dict = {}
                key_map: dict = {}
                for k, v in field_definitions.items():
                    if k.startswith("_") and not k.startswith("__"):
                        new_k = "field" + k
                        renamed[new_k] = v
                        key_map[new_k] = k
                    else:
                        renamed[k] = v
                model_cls = _orig(__model_name, **renamed)
                if key_map:
                    model_cls.__mcp_field_name_map__ = key_map
                return model_cls

            _js.create_model = _sanitized_create_model
            _js._mcp_create_model_patched = True  # type: ignore[attr-defined]
        except Exception:
            pass

    # ------------------------------------------------------------------
    # 安全加载 tools
    # ------------------------------------------------------------------

    async def _safe_update_tools(self, server_name: str, server_config: dict):
        """安装 patch 后调用 update_tools，并为 coroutine 添加参数名还原包装。"""
        self._install_json_schema_create_model_patch()
        try:
            result = await update_tools(
                server_name=server_name,
                server_config=server_config,
                mcp_stdio_client=self.stdio_client,
                mcp_streamable_http_client=self.streamable_http_client,
            )
            if result is not None and len(result) == 3:
                _, tool_list, tool_cache = result
                self._wrap_tool_cache_coroutines(tool_cache)
            return result
        except Exception as e:
            err_msg = str(e)
            if "leading underscores" not in err_msg:
                raise
            await logger.awarning(
                f"MCP tool schema still has leading-underscore field names "
                f"for server '{server_name}': {err_msg}"
            )
            return None, [], {}

    def _wrap_tool_cache_coroutines(self, tool_cache: dict) -> None:
        """给 tool_cache 中每个 tool 的 coroutine 包装参数名还原逻辑。

        ``create_model`` patch 把 ``_foo`` 改为 ``field_foo``，LLM 按净化后
        的字段名传参；此包装器在调用真实 coroutine 前把参数名还原为原始名，
        确保 MCP server 收到正确的参数。
        """
        for _tool_name, exec_tool in list(tool_cache.items()):
            original_coroutine = getattr(exec_tool, "coroutine", None)
            if original_coroutine is None:
                continue
            if getattr(original_coroutine, "_mcp_field_remapped", False):
                continue

            args_schema = getattr(exec_tool, "args_schema", None)
            field_name_map: dict = getattr(args_schema, "__mcp_field_name_map__", {})
            if not field_name_map:
                continue

            @functools.wraps(original_coroutine)
            async def _remapped_coroutine(
                *args,
                _orig=original_coroutine,
                _fmap=field_name_map,
                **kwargs,
            ):
                restored = {_fmap.get(k, k): v for k, v in kwargs.items()}
                return await _orig(*args, **restored)

            _remapped_coroutine._mcp_field_remapped = True
            exec_tool.coroutine = _remapped_coroutine

    # ------------------------------------------------------------------
    # 重写父类方法
    # ------------------------------------------------------------------

    async def _validate_schema_inputs(self, tool_obj):
        """重写：净化 schema 字段名后再生成 LangFlow 输入，并记录字段名映射。"""
        try:
            if not tool_obj or not hasattr(tool_obj, "args_schema"):
                raise ValueError("Invalid tool object or missing input schema")

            raw_schema = tool_obj.args_schema.schema()
            sanitized_schema = self._sanitize_schema_dict(raw_schema)

            # 记录净化名->原始名映射，供 build_output 还原
            mapping = self._build_field_name_mapping(raw_schema)
            if mapping:
                if not hasattr(self, "_tool_field_name_mapping"):
                    self._tool_field_name_mapping = {}
                self._tool_field_name_mapping[tool_obj.name] = mapping

            flat_schema = flatten_schema(sanitized_schema)
            input_schema = create_input_schema_from_json_schema(flat_schema)
            if not input_schema:
                raise ValueError(f"Empty input schema for tool '{tool_obj.name}'")

            schema_inputs = schema_to_langflow_inputs(input_schema)
            if not schema_inputs:
                await logger.awarning(f"No input parameters defined for tool '{tool_obj.name}'")
                return []

        except Exception as e:
            msg = f"Error validating schema inputs: {e!s}"
            await logger.aexception(msg)
            raise ValueError(msg) from e
        else:
            return schema_inputs

    def get_inputs_for_all_tools(self, tools: list) -> dict:
        """重写：净化 schema 字段名后再生成 LangFlow 输入。"""
        inputs = {}
        for tool in tools:
            if not tool or not hasattr(tool, "name"):
                continue
            try:
                raw_schema = tool.args_schema.schema()
                sanitized_schema = self._sanitize_schema_dict(raw_schema)
                flat_schema = flatten_schema(sanitized_schema)
                input_schema = create_input_schema_from_json_schema(flat_schema)
                inputs[tool.name] = schema_to_langflow_inputs(input_schema)
            except (AttributeError, ValueError, TypeError, KeyError) as e:
                logger.exception(f"Error getting inputs for tool {getattr(tool, 'name', 'unknown')}: {e!s}")
                continue
        return inputs

    async def update_tool_list(self, mcp_server_value=None):
        """重写：将内部的 ``update_tools`` 调用替换为 ``_safe_update_tools``。"""
        from lfx.base.agents.utils import safe_cache_get, safe_cache_set
        import asyncio

        mcp_server = mcp_server_value if mcp_server_value is not None else getattr(self, "mcp_server", None)
        server_name = None
        server_config_from_value = None
        if isinstance(mcp_server, dict):
            server_name = mcp_server.get("name")
            server_config_from_value = mcp_server.get("config")
        else:
            server_name = mcp_server
        if not server_name:
            self.tools = []
            return [], {"name": server_name, "config": server_config_from_value}

        use_cache = getattr(self, "use_cache", False)

        cached = None
        if use_cache:
            servers_cache = safe_cache_get(self._shared_component_cache, "servers", {})
            cached = servers_cache.get(server_name) if isinstance(servers_cache, dict) else None

        if cached is not None:
            try:
                self.tools = cached["tools"]
                self.tool_names = cached["tool_names"]
                self._tool_cache = cached["tool_cache"]
                server_config_from_value = cached["config"]
            except (TypeError, KeyError, AttributeError) as e:
                await logger.awarning(f"Unable to use cached data for MCP Server {server_name}: {e}")
                current_servers_cache = safe_cache_get(self._shared_component_cache, "servers", {})
                if isinstance(current_servers_cache, dict) and server_name in current_servers_cache:
                    current_servers_cache.pop(server_name)
                    safe_cache_set(self._shared_component_cache, "servers", current_servers_cache)
            else:
                return self.tools, {"name": server_name, "config": server_config_from_value}

        try:
            try:
                from langflow.api.v2.mcp import get_server
                from langflow.services.database.models.user.crud import get_user_by_id
            except ImportError as e:
                raise ImportError(
                    "Langflow MCP server functionality is not available. "
                    "This feature requires the full Langflow installation."
                ) from e

            from lfx.services.deps import get_settings_service, get_storage_service, session_scope

            async with session_scope() as db:
                if not self.user_id:
                    raise ValueError("User ID is required for fetching MCP tools.")
                current_user = await get_user_by_id(db, self.user_id)
                server_config = await get_server(
                    server_name,
                    current_user,
                    db,
                    storage_service=get_storage_service(),
                    settings_service=get_settings_service(),
                )

            if not server_config and server_config_from_value:
                server_config = server_config_from_value
            if not server_config:
                self.tools = []
                return [], {"name": server_name, "config": server_config}

            if "verify_ssl" not in server_config:
                server_config["verify_ssl"] = getattr(self, "verify_ssl", True)

            # ↓ 关键：使用 _safe_update_tools 替代直接调用 update_tools
            _, tool_list, tool_cache = await self._safe_update_tools(
                server_name=server_name,
                server_config=server_config,
            )

            self.tool_names = [tool.name for tool in tool_list if hasattr(tool, "name")]
            self._tool_cache = tool_cache
            self.tools = tool_list

            if use_cache:
                current_servers_cache = safe_cache_get(self._shared_component_cache, "servers", {})
                if isinstance(current_servers_cache, dict):
                    current_servers_cache[server_name] = {
                        "tools": tool_list,
                        "tool_names": self.tool_names,
                        "tool_cache": tool_cache,
                        "config": server_config,
                    }
                    safe_cache_set(self._shared_component_cache, "servers", current_servers_cache)

        except (TimeoutError, asyncio.TimeoutError) as e:
            msg = f"Timeout updating tool list: {e!s}"
            await logger.aexception(msg)
            raise TimeoutError(msg) from e
        except Exception as e:
            msg = f"Error updating tool list: {e!s}"
            await logger.aexception(msg)
            raise ValueError(msg) from e
        else:
            return tool_list, {"name": server_name, "config": server_config}

    async def build_output(self) -> DataFrame:
        """重写：执行 tool 时将净化字段名还原为原始名再传给 MCP server。"""
        try:
            self.tools, _ = await self.update_tool_list()
            if self.tool != "":
                session_context = self._get_session_context()
                if session_context:
                    self.stdio_client.set_session_context(session_context)
                    self.streamable_http_client.set_session_context(session_context)

                exec_tool = self._tool_cache[self.tool]
                tool_args = self.get_inputs_for_all_tools(self.tools)[self.tool]

                # 收集用户填写的参数（字段名为净化后的名，如 field_param）
                kwargs = {}
                for arg in tool_args:
                    value = getattr(self, arg.name, None)
                    if value is not None:
                        kwargs[arg.name] = value.text if isinstance(value, Message) else value

                # 若 args_schema 携带映射表（由 create_model patch 写入），优先使用；
                # 否则退回到 _tool_field_name_mapping（由 _validate_schema_inputs 写入）
                args_schema = getattr(exec_tool, "args_schema", None)
                field_name_map: dict = getattr(args_schema, "__mcp_field_name_map__", {})
                if not field_name_map and hasattr(self, "_tool_field_name_mapping"):
                    field_name_map = self._tool_field_name_mapping.get(self.tool, {})

                if field_name_map:
                    kwargs = {field_name_map.get(k, k): v for k, v in kwargs.items()}

                unflattened_kwargs = maybe_unflatten_dict(kwargs)
                output = await exec_tool.coroutine(**unflattened_kwargs)

                tool_content = []
                for item in output.content:
                    item_dict = item.model_dump()
                    item_dict = self.process_output_item(item_dict)
                    tool_content.append(item_dict)

                if isinstance(tool_content, list) and all(isinstance(x, dict) for x in tool_content):
                    return DataFrame(tool_content)
                return DataFrame(data=tool_content)
            return DataFrame(data=[{"error": "You must select a tool"}])
        except Exception as e:
            msg = f"Error in build_output: {e!s}"
            await logger.aexception(msg)
            raise ValueError(msg) from e
