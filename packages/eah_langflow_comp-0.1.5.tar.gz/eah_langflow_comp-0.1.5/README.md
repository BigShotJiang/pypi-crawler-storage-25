# EAH AI Flow

A Python package for AI-powered workflows.

## Installation

```bash
pip install eah_langflow_comp
```

## Usage

```python
from eah_langflow_comp import CustomMCPToolsComponent, AgentComponent, BaseAgentComponent, Message2TextComponent
```

## License

MIT