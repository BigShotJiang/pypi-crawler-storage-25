from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import re
import socket
import sys
import uuid
from pathlib import Path

from bridgeflow.binding import approve_bind, clear_binding, issue_bind_code, private_bind_state, public_bind_state
from bridgeflow.config import DEFAULT_CONFIG_NAME, DEFAULT_FIXED_ROLES, load_config
from bridgeflow.desktop.executor import execute_desktop_action
from bridgeflow.desktop.patrol import patrol_once, print_doctor_result, run_doctor
from bridgeflow.desktop.runner import start_desktop_bridge
from bridgeflow.task_writer import write_admin_task, write_role_reply


def _default_project_root() -> Path:
    return Path.cwd()


def _patch_config_if_needed(config_path: Path) -> None:
    """Auto-fill fields that older configs may lack (e.g. machine_code)."""
    raw = json.loads(config_path.read_text(encoding="utf-8-sig"))
    changed = False
    device = raw.setdefault("device", {})
    if not device.get("machine_code"):
        hostname = socket.gethostname() or "BridgeFlow-PC"
        device["machine_code"] = _build_machine_code(hostname)
        changed = True
    bind = raw.setdefault("bind", {})
    for key in ("status", "bound_mobile_device_id", "bound_mobile_device_name",
                "bound_at", "pending_bind_code", "pending_bind_expires_at",
                "pending_mobile_device_id", "pending_mobile_device_name"):
        if key not in bind:
            bind[key] = "" if key != "bind_code_ttl_seconds" else 600
            changed = True
    bind.setdefault("bind_code_ttl_seconds", 600)
    if "bind_code_ttl_seconds" not in bind:
        changed = True
    runtime = raw.setdefault("runtime", {})
    for key, default in (("runtime_dir", ".bridgeflow/runtime"),
                         ("status_dir", ".bridgeflow/runtime/status"),
                         ("task_details_dir", ".bridgeflow/runtime/task_details"),
                         ("idle_seconds", 180),
                         ("stale_task_seconds", 900)):
        if key not in runtime:
            runtime[key] = default
            changed = True
    if changed:
        config_path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"  已自动补全配置字段: {config_path}")


def _create_initial_docs(config) -> None:
    """Create initial markdown docs so Cursor agents have something to read."""
    from datetime import datetime
    today = datetime.now().strftime("%Y%m%d")
    project_root = config.project_root

    docs_dir = project_root / "docs" / "agents"
    tasks_dir = docs_dir / "tasks"
    reports_dir = docs_dir / "reports"
    issues_dir = docs_dir / "issues"
    log_dir = docs_dir / "log"
    for d in (tasks_dir, reports_dir, issues_dir, log_dir):
        d.mkdir(parents=True, exist_ok=True)

    readme = docs_dir / "README.md"
    if not readme.exists():
        readme.write_text(
            f"# BridgeFlow AI 团队协作目录\n\n"
            f"创建时间：{today}\n\n"
            f"## 目录说明\n\n"
            f"| 目录 | 用途 |\n"
            f"|---|---|\n"
            f"| `tasks/` | 任务单（PM→各角色，或 ADMIN→PM） |\n"
            f"| `reports/` | 完成报告（各角色→PM，或 PM→ADMIN） |\n"
            f"| `issues/` | Bug / 问题记录 |\n"
            f"| `log/` | 已归档的历史任务和报告 |\n\n"
            f"## 文件命名规范\n\n"
            f"- 任务单：`TASK-{{日期}}-{{序号}}-{{发件人}}-to-{{收件人}}.md`\n"
            f"- 示例：`TASK-{today}-001-ADMIN01-to-PM01.md`\n",
            encoding="utf-8",
        )

    roles = {"PM01": "项目经理", "DEV01": "全栈开发", "QA01": "质量测试", "OPS01": "运维部署"}
    for role_id, role_name in roles.items():
        role_file = docs_dir / f"{role_id}.md"
        if not role_file.exists():
            role_file.write_text(
                f"# {role_id} — {role_name}\n\n"
                f"## 职责\n\n"
                f"- 按 BridgeFlow 协作规范执行任务\n"
                f"- 监听 `tasks/` 目录中发给自己的任务单\n"
                f"- 完成后在 `reports/` 写回复报告\n\n"
                f"## 巡检触发\n\n"
                f"收到巡检消息时，检查 `tasks/` 是否有新的 `to-{role_id}` 任务单。\n",
                encoding="utf-8",
            )

    welcome_task = tasks_dir / f"TASK-{today}-001-ADMIN01-to-PM01.md"
    if not welcome_task.exists():
        welcome_task.write_text(
            f"---\n"
            f"task_id: TASK-{today}-001\n"
            f"sender: ADMIN01\n"
            f"recipient: PM01\n"
            f"priority: P2\n"
            f"created_at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"status: published\n"
            f"---\n\n"
            f"# 欢迎使用 BridgeFlow\n\n"
            f"BridgeFlow 已初始化完成。\n\n"
            f"## 下一步\n\n"
            f"1. 在 Cursor 中打开本项目，确认 4 个 Agent（1-PM、2-DEV、3-QA、4-OPS）已创建\n"
            f"2. 手机 PWA 扫码绑定 PC 仪表盘\n"
            f"3. 点击「开始巡检」，巡检器会自动通知各 Agent 查看任务\n",
            encoding="utf-8",
        )

    created = sum(1 for d in (tasks_dir, reports_dir, issues_dir, log_dir) for _ in d.iterdir())
    print(f"  Docs initialized: {docs_dir} ({created} files)")


def _sync_rules(project_dir: Path) -> None:
    """Copy latest .mdc rules from package data to project .cursor/rules/."""
    import shutil
    rules_src = Path(__file__).resolve().parent / "data" / "rules"
    rules_dst = project_dir / ".cursor" / "rules"
    if not rules_src.exists():
        return
    rules_dst.mkdir(parents=True, exist_ok=True)
    updated = 0
    for mdc in rules_src.glob("*.mdc"):
        dst_file = rules_dst / mdc.name
        if not dst_file.exists() or mdc.stat().st_mtime > dst_file.stat().st_mtime:
            shutil.copy2(mdc, dst_file)
            updated += 1
    if updated:
        print(f"  已同步 {updated} 个 Cursor 规则文件到 {rules_dst}")


def _slug(value: str) -> str:
    clean = re.sub(r"[^A-Za-z0-9_-]+", "-", value.strip())
    clean = clean.strip("-").lower()
    return clean or "bridgeflow-pc"


def _build_machine_code(hostname: str) -> str:
    seed = f"{hostname}-{uuid.getnode()}".encode("utf-8", errors="ignore")
    digest = hashlib.sha1(seed).hexdigest()[:12].upper()
    return f"BF-{digest}"


def _print_bind_state(state: dict) -> None:
    print(f"  Bind status  : {state.get('status', '')}")
    print(f"  Machine code : {state.get('machine_code', '')}")
    if state.get("pending_bind_code"):
        print(f"  Bind code    : {state['pending_bind_code']}")
    if state.get("pending_bind_expires_at"):
        print(f"  Code expires : {state['pending_bind_expires_at']}")
    if state.get("pending_mobile_device_id") or state.get("pending_mobile_device_name"):
        print(f"  Pending phone: {state.get('pending_mobile_device_name', '')} {state.get('pending_mobile_device_id', '')}".strip())
    if state.get("bound_mobile_device_id") or state.get("bound_mobile_device_name"):
        print(f"  Bound phone  : {state.get('bound_mobile_device_name', '')} {state.get('bound_mobile_device_id', '')}".strip())
    if state.get("bound_at"):
        print(f"  Bound at     : {state['bound_at']}")


def _print_action_result(result: dict) -> None:
    print(f"  Action : {result.get('action', '')}")
    print(f"  Result : {'OK' if result.get('ok') else 'FAILED'}")
    print(f"  Message: {result.get('message', '')}")
    print(f"  Windows: {result.get('window_count', 0)}")
    print(f"  Target : {result.get('target_title', '')}")
    if result.get("typed_text"):
        print(f"  Typed  : {result['typed_text']}")
    print(f"  Dry-run: {result.get('dry_run', False)}")


def cmd_init(args: argparse.Namespace) -> int:
    project_root = Path(args.project_root or _default_project_root()).resolve()
    project_root.mkdir(parents=True, exist_ok=True)
    target = project_root / DEFAULT_CONFIG_NAME
    example = Path(__file__).resolve().parent / "data" / DEFAULT_CONFIG_NAME
    if target.exists() and not args.force:
        raw = json.loads(target.read_text(encoding="utf-8-sig"))
        changed = False
        if getattr(args, "relay_url", None):
            raw.setdefault("relay", {})["url"] = args.relay_url
            changed = True
        if getattr(args, "room_key", None):
            raw.setdefault("relay", {})["room_key"] = args.room_key
            changed = True
        if changed:
            target.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"  Config updated: {target}")
        else:
            print(f"  Config exists : {target}")
        return 0

    import secrets
    hostname = socket.gethostname() or "BridgeFlow-PC"
    raw = json.loads(example.read_text(encoding="utf-8-sig"))
    raw["project"]["root_dir"] = str(project_root)
    raw.setdefault("device", {})
    raw["device"]["device_id"] = f"{_slug(hostname)}-pc"
    raw["device"]["device_name"] = f"{hostname} AI-Agent"
    raw["device"].setdefault("owner_role", "PM01")
    raw["device"]["machine_code"] = _build_machine_code(hostname)

    if getattr(args, "room_key", None):
        raw.setdefault("relay", {})["room_key"] = args.room_key
    else:
        auto_room = f"bf-{_slug(hostname)}-{secrets.token_hex(4)}"
        raw.setdefault("relay", {})["room_key"] = auto_room

    if getattr(args, "relay_url", None):
        raw.setdefault("relay", {})["url"] = args.relay_url

    raw.setdefault("ai_team", {})
    raw["ai_team"]["fixed_roles"] = DEFAULT_FIXED_ROLES[:]
    raw["ai_team"]["cursor_only"] = True

    raw.setdefault("bind", {})
    raw["bind"].setdefault("status", "unbound")
    raw["bind"].setdefault("bound_mobile_device_id", "")
    raw["bind"].setdefault("bound_mobile_device_name", "")
    raw["bind"].setdefault("bound_at", "")
    raw["bind"].setdefault("bind_code_ttl_seconds", 600)
    raw["bind"].setdefault("pending_bind_code", "")
    raw["bind"].setdefault("pending_bind_expires_at", "")
    raw["bind"].setdefault("pending_mobile_device_id", "")
    raw["bind"].setdefault("pending_mobile_device_name", "")
    raw["bind"].setdefault("last_bind_code_issued_at", "")

    raw.setdefault("runtime", {})
    raw["runtime"].setdefault("runtime_dir", ".bridgeflow/runtime")
    raw["runtime"].setdefault("status_dir", ".bridgeflow/runtime/status")
    raw["runtime"].setdefault("task_details_dir", ".bridgeflow/runtime/task_details")
    raw["runtime"].setdefault("idle_seconds", 180)
    raw["runtime"].setdefault("stale_task_seconds", 900)

    target.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    config = load_config(target)
    config.ensure_runtime_dirs()

    rules_src = Path(__file__).resolve().parent / "data" / "rules"
    rules_dst = project_root / ".cursor" / "rules"
    if rules_src.exists():
        rules_dst.mkdir(parents=True, exist_ok=True)
        import shutil
        for mdc in rules_src.glob("*.mdc"):
            shutil.copy2(mdc, rules_dst / mdc.name)
        print(f"  Cursor rules installed: {rules_dst}")

    _create_initial_docs(config)

    from bridgeflow import __version__
    print(f"  Config created : {target}")
    print(f"  Device ID      : {config.device_id}")
    print(f"  Machine code   : {config.machine_code}")
    print(f"  Relay URL      : {config.relay_url}")
    print(f"  Room key       : {config.room_key}")
    print(f"  Runtime dir    : {config.runtime_dir}")
    print(f"  Version        : v{__version__}  (upgrade: pip install --upgrade bridgeflow)")
    print()
    print("  NOTE: The mobile PWA must use the same room key to communicate with this PC.")
    print("        Easiest way: scan the QR code on the dashboard after startup.")
    return 0


def cmd_write_admin_task(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    written = write_admin_task(
        config,
        args.text,
        recipient=args.recipient,
        priority=args.priority,
        attachments=args.attachments or [],
        thread_key=args.thread_key,
    )
    print(f"  Written: {written.path}")
    print(f"  Thread : {written.thread_key}")
    return 0


def cmd_write_reply(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    written = write_role_reply(
        config,
        args.text,
        sender=args.sender,
        recipient=args.recipient,
        priority=args.priority,
        attachments=args.attachments or [],
        thread_key=args.thread_key,
    )
    print(f"  Written: {written.path}")
    print(f"  Thread : {written.thread_key}")
    return 0


def cmd_bind_status(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    _print_bind_state(private_bind_state(config))
    return 0


def cmd_bind_code(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    state = issue_bind_code(
        config,
        mobile_device_id=args.mobile_device_id,
        mobile_device_name=args.mobile_device_name,
    )
    _print_bind_state(state)
    return 0


def cmd_approve_bind(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    state = approve_bind(
        config,
        bind_code=args.code,
        mobile_device_id=args.mobile_device_id,
        mobile_device_name=args.mobile_device_name,
    )
    _print_bind_state(state)
    return 0


def cmd_unbind(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    state = clear_binding(config)
    _print_bind_state(state)
    return 0


def cmd_desktop_action(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    result = execute_desktop_action(config, args.action, dry_run=args.dry_run).to_dict()
    _print_action_result(result)
    return 0 if result.get("ok") else 1


def cmd_relay_connect(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    asyncio.run(start_desktop_bridge(config))
    return 0



def cmd_run(args: argparse.Namespace) -> int:
    import webbrowser
    from bridgeflow import __version__
    from bridgeflow.dashboard.server import DASHBOARD_PORT, start_dashboard, update_status

    # ── Auto-init: current directory = project directory ─────────────────────
    config_path = Path(args.config).resolve()
    project_dir = Path.cwd().resolve()
    if not config_path.exists():
        print(f"  项目目录: {project_dir}")
        print(f"  首次运行，正在初始化...")
        init_args = argparse.Namespace(
            project_root=str(project_dir),
            relay_url="",
            room_key="",
            force=False,
        )
        ret = cmd_init(init_args)
        if ret != 0:
            return ret
        config_path = project_dir / DEFAULT_CONFIG_NAME
        print()
    else:
        _sync_rules(project_dir)

    _patch_config_if_needed(config_path)

    config = load_config(str(config_path))
    config.ensure_runtime_dirs()

    # Ensure docs exist (for upgrades or if deleted)
    docs_readme = project_dir / "docs" / "agents" / "README.md"
    if not docs_readme.exists():
        _create_initial_docs(config)

    # ── Banner ────────────────────────────────────────────────────────────────
    print("=" * 52)
    print(f"  BridgeFlow Desktop Agent  v{__version__}")
    print(f"  Dashboard: http://localhost:{DASHBOARD_PORT}")
    print("=" * 52)

    # ── Dashboard (always start — all checks are done via web UI) ─────────
    start_dashboard(config)
    url = f"http://localhost:{DASHBOARD_PORT}"
    print(f"\n  Dashboard started: {url}")
    print("  Opening browser...\n")
    webbrowser.open(url)

    # ── Main bridge loop ──────────────────────────────────────────────────────
    from bridgeflow.desktop.runner import start_desktop_bridge

    def on_connected():
        update_status(relay_connected=True)
        print(f"  [BridgeFlow] Connected to relay {config.relay_url}")

    def on_disconnected(exc):
        update_status(relay_connected=False)
        print(f"  [BridgeFlow] Disconnected, reconnecting... ({exc})")

    asyncio.run(start_desktop_bridge(config,
                                     on_connected=on_connected,
                                     on_disconnected=on_disconnected))
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    config.ensure_runtime_dirs()
    result = run_doctor(config)
    print_doctor_result(result)
    return 0 if result.tasks_dir_exists and result.reports_dir_exists else 1


def cmd_patrol_once(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    targets = sorted(patrol_once(config))
    if not targets:
        print("  No patrol targets found this round.")
        return 0
    print("  Patrol targets:")
    for item in targets:
        print(f"  - {item}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="bridgeflow", description="BridgeFlow human-AI collaboration bridge tool")
    sub = parser.add_subparsers(dest="command", required=True)

    init_p = sub.add_parser("init", help="Generate default bridgeflow_config.json")
    init_p.add_argument("--project-root", default="")
    init_p.add_argument("--force", action="store_true")
    init_p.add_argument("--relay-url", default="", help="Relay server URL")
    init_p.add_argument("--room-key", default="", help="Room key")
    init_p.set_defaults(func=cmd_init)

    bind_status_p = sub.add_parser("bind-status", help="Show current bind status")
    bind_status_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    bind_status_p.set_defaults(func=cmd_bind_status)

    bind_code_p = sub.add_parser("bind-code", help="Generate one-time bind code")
    bind_code_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    bind_code_p.add_argument("--mobile-device-id", default="")
    bind_code_p.add_argument("--mobile-device-name", default="")
    bind_code_p.set_defaults(func=cmd_bind_code)

    approve_bind_p = sub.add_parser("approve-bind", help="Approve mobile binding")
    approve_bind_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    approve_bind_p.add_argument("--code", required=True)
    approve_bind_p.add_argument("--mobile-device-id", required=True)
    approve_bind_p.add_argument("--mobile-device-name", default="")
    approve_bind_p.set_defaults(func=cmd_approve_bind)

    unbind_p = sub.add_parser("unbind", help="Clear current binding")
    unbind_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    unbind_p.set_defaults(func=cmd_unbind)

    action_p = sub.add_parser("desktop-action", help="Execute a desktop action")
    action_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    action_p.add_argument("--action", choices=["focus_cursor", "inspect", "start_work"], required=True)
    action_p.add_argument("--dry-run", action="store_true")
    action_p.set_defaults(func=cmd_desktop_action)

    write_p = sub.add_parser("write-admin-task", help="Write an ADMIN01 -> PM01 task file")
    write_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    write_p.add_argument("--text", required=True)
    write_p.add_argument("--recipient", default="")
    write_p.add_argument("--priority", default="")
    write_p.add_argument("--thread-key", default="")
    write_p.add_argument("--attachments", nargs="*")
    write_p.set_defaults(func=cmd_write_admin_task)

    reply_p = sub.add_parser("write-reply", help="Write a role reply file")
    reply_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    reply_p.add_argument("--sender", required=True, help="Sender role, e.g. PM01/DEV01/QA01")
    reply_p.add_argument("--recipient", default="ADMIN01")
    reply_p.add_argument("--text", required=True)
    reply_p.add_argument("--priority", default="")
    reply_p.add_argument("--thread-key", default="")
    reply_p.add_argument("--attachments", nargs="*")
    reply_p.set_defaults(func=cmd_write_reply)

    relay_p = sub.add_parser("relay-connect", help="Connect to relay and start bridge")
    relay_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    relay_p.set_defaults(func=cmd_relay_connect)

    doctor_p = sub.add_parser("doctor", help="Check project directories")
    doctor_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    doctor_p.set_defaults(func=cmd_doctor)

    patrol_p = sub.add_parser("patrol-once", help="Scan tasks/reports and output patrol targets")
    patrol_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    patrol_p.set_defaults(func=cmd_patrol_once)

    run_p = sub.add_parser("run", help="Start the desktop bridge main loop")
    run_p.add_argument("--config", default=DEFAULT_CONFIG_NAME)
    run_p.set_defaults(func=cmd_run)

    return parser


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    parser = build_parser()
    args = parser.parse_args()
    raise SystemExit(args.func(args))


if __name__ == "__main__":
    main()
