"""
BridgeFlow local dashboard — ops panel.
URL: http://localhost:18765

Endpoints:
  GET  /                  — Dashboard HTML
  GET  /api/status        — Live connection & device state
  GET  /api/preflight     — Full pre-check (env, network, Cursor, agents, version)
  GET  /api/upgrade-status — Poll pip upgrade progress
  GET  /api/qr            — QR code PNG for mobile binding
  POST /api/upgrade       — Trigger pip install --upgrade bridgeflow
  POST /api/restart       — Restart the bridgeflow process
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bridgeflow.config import PatrolConfig

DASHBOARD_PORT = int(os.environ.get("BRIDGEFLOW_DASHBOARD_PORT", "18765"))

_config: "PatrolConfig | None" = None

_status: dict = {
    "relay_connected": False,
    "relay_url": "",
    "room_key": "",
    "device_id": "",
    "device_name": "",
    "machine_code": "",
    "bind_status": "unbound",
    "env": {},
    "task_count": 0,
    "reply_count": 0,
}
_lock = threading.Lock()
_upgrade_log: list[str] = []
_upgrade_running = False

# ── Patrol state ──────────────────────────────────────────────────────────────
_patrol_running = False
_patrol_thread: threading.Thread | None = None
_patrol_log: list[str] = []
_patrol_round = 0


def update_status(**kwargs) -> None:
    with _lock:
        _status.update(kwargs)


def get_status() -> dict:
    with _lock:
        data = dict(_status)
    if _config is not None:
        data["bind_status"] = _config.bind_status
    return data


# ── Preflight helpers ─────────────────────────────────────────────────────────

def _tcp_ping(host: str, port: int = 443, timeout: float = 3.0) -> bool:
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        sock.close()
        return True
    except Exception:
        return False


def _check_network() -> dict:
    pypi_ok = _tcp_ping("pypi.org", 443)
    relay_url = get_status().get("relay_url", "")
    relay_host = ""
    relay_ok = False
    if relay_url:
        try:
            from urllib.parse import urlparse
            parsed = urlparse(relay_url)
            relay_host = parsed.hostname or ""
            relay_port = parsed.port or (443 if parsed.scheme == "wss" else 80)
            if relay_host:
                relay_ok = _tcp_ping(relay_host, relay_port)
        except Exception:
            pass
    return {"pypi_reachable": pypi_ok, "relay_reachable": relay_ok, "relay_host": relay_host}


def _check_version() -> dict:
    from bridgeflow import __version__
    latest = None
    try:
        from bridgeflow.version_check import _fetch_latest_version, _parse_version
        latest = _fetch_latest_version()
    except Exception:
        pass
    update_available = False
    if latest:
        try:
            from bridgeflow.version_check import _parse_version
            update_available = _parse_version(latest) > _parse_version(__version__)
        except Exception:
            pass
    return {"current": __version__, "latest": latest, "update_available": update_available}


def _check_agents() -> dict:
    """Check file-driven agent readiness: tasks/reports dirs exist."""
    config = _config
    issues = []
    if config is None:
        return {"mode": "file", "ready": False, "issues": ["config not loaded"]}
    tasks_ok = config.tasks_dir.exists()
    reports_ok = config.reports_dir.exists()
    if not tasks_ok:
        issues.append(f"tasks dir missing: {config.tasks_dir}")
    if not reports_ok:
        issues.append(f"reports dir missing: {config.reports_dir}")
    return {
        "mode": "file",
        "ready": len(issues) == 0,
        "tasks_dir": str(config.tasks_dir),
        "reports_dir": str(config.reports_dir),
        "issues": issues,
    }


def _run_preflight() -> dict:
    from bridgeflow.env_check import check_env
    env = check_env()
    with _lock:
        _status["env"] = env.to_dict()
    return {
        "env": env.to_dict(),
        "network": _check_network(),
        "agents": _check_agents(),
        "version": _check_version(),
    }


# ── Upgrade worker ────────────────────────────────────────────────────────────

def _do_upgrade() -> None:
    global _upgrade_running
    _upgrade_running = True
    _upgrade_log.clear()
    _upgrade_log.append("Starting upgrade...\n")
    try:
        proc = subprocess.Popen(
            [sys.executable, "-m", "pip", "install", "--upgrade",
             "--no-cache-dir", "--index-url", "https://pypi.org/simple/", "bridgeflow"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace",
        )
        for line in proc.stdout:
            _upgrade_log.append(line)
        proc.wait()
        if proc.returncode == 0:
            _upgrade_log.append("\nUpgrade complete. Click [Restart] to apply.\n")
        else:
            _upgrade_log.append(f"\nUpgrade failed (exit code {proc.returncode}).\n")
    except Exception as exc:
        _upgrade_log.append(f"\nError: {exc}\n")
    finally:
        _upgrade_running = False


# ── Patrol worker ─────────────────────────────────────────────────────────────

def _do_patrol() -> None:
    """Patrol worker -- file-driven. Write task files, monitor for new reports."""
    global _patrol_running, _patrol_round
    import datetime
    _patrol_log.clear()
    _patrol_round = 0

    config = _config
    if config is None:
        _patrol_running = False
        return

    ts = lambda: f"[{datetime.datetime.now():%H:%M:%S}]"
    _patrol_log.append(f"{ts()} patrol started (file-driven)\n")

    from bridgeflow.file_watcher import scan_markdown_files
    from bridgeflow.desktop.executor import notify_agent

    _patrol_log.append(f"{ts()} [init] writing patrol tasks for all agents...\n")
    all_chats = config.all_worker_chats or ["1-PM", "2-DEV", "3-QA", "4-OPS"]
    for name in all_chats:
        _patrol_round += 1
        r = notify_agent(config, name)
        _patrol_log.append(f"{ts()}   {name}: {r.message[:80]}\n")
    _patrol_log.append(f"{ts()} [init] done\n")

    _patrol_log.append(f"{ts()} monitoring file changes...\n")
    known_tasks = scan_markdown_files(config.tasks_dir)
    known_reports = scan_markdown_files(config.reports_dir)
    last_hb = 0

    while _patrol_running:
        interval = config.patrol_poll_interval if config else 10
        for _ in range(interval):
            if not _patrol_running:
                break
            time.sleep(1)
        if not _patrol_running:
            break

        _patrol_round += 1
        try:
            cur_tasks = scan_markdown_files(config.tasks_dir)
            cur_reports = scan_markdown_files(config.reports_dir)
            new_t = cur_tasks - known_tasks
            new_r = cur_reports - known_reports

            if new_t or new_r:
                for f in sorted(new_t):
                    _patrol_log.append(f"{ts()} new task: {f}\n")
                for f in sorted(new_r):
                    _patrol_log.append(f"{ts()} new report: {f}\n")
                known_tasks = cur_tasks
                known_reports = cur_reports
            else:
                now = int(time.time())
                if now - last_hb >= 60:
                    _patrol_log.append(f"{ts()} round {_patrol_round}: watching...\n")
                    last_hb = now
        except Exception as exc:
            _patrol_log.append(f"{ts()} round {_patrol_round}: error {exc}\n")

        if len(_patrol_log) > 200:
            _patrol_log[:] = _patrol_log[-100:]

    _patrol_log.append(f"{ts()} patrol stopped\n")
    _patrol_running = False


def start_patrol() -> dict:
    global _patrol_running, _patrol_thread
    if _patrol_running:
        return {"ok": True, "message": "巡检已在运行中", "running": True}
    if _config is None:
        return {"ok": False, "message": "配置未加载", "running": False}
    _patrol_running = True
    _patrol_thread = threading.Thread(target=_do_patrol, daemon=True)
    _patrol_thread.start()
    return {"ok": True, "message": "巡检已启动", "running": True}


def stop_patrol() -> dict:
    global _patrol_running
    if not _patrol_running:
        return {"ok": True, "message": "巡检未运行", "running": False}
    _patrol_running = False
    return {"ok": True, "message": "正在停止巡检...", "running": False}


def patrol_status() -> dict:
    return {
        "running": _patrol_running,
        "round": _patrol_round,
        "log": "".join(_patrol_log[-50:]),
    }


# ── HTTP Handler ──────────────────────────────────────────────────────────────

class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send_json(self, data: dict, code: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html: str) -> None:
        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_png(self, data: bytes) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "image/png")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def _read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(length) if length else b""

    # ── GET ────────────────────────────────────────────────────────────────
    def do_GET(self):
        if self.path == "/api/status":
            self._send_json(get_status())

        elif self.path.startswith("/api/preflight"):
            self._send_json(_run_preflight())

        elif self.path.startswith("/api/upgrade-status"):
            self._send_json({"running": _upgrade_running, "log": "".join(_upgrade_log)})

        elif self.path.startswith("/api/qr"):
            try:
                import io
                import segno
                status = get_status()
                mc = status.get("machine_code") or "BF-UNKNOWN"
                device_id = status.get("device_id", "")
                room_key = status.get("room_key", "")
                qr_content = f"bf:{mc}|{device_id}|{room_key}"
                qr = segno.make_qr(qr_content, error="M")
                buf = io.BytesIO()
                qr.save(buf, kind="png", scale=8, border=2)
                self._send_png(buf.getvalue())
            except Exception:
                self.send_response(500)
                self.end_headers()

        elif self.path.startswith("/api/patrol/status"):
            self._send_json(patrol_status())

        elif self.path in ("/", "/index.html"):
            html_path = Path(__file__).parent / "index.html"
            self._send_html(html_path.read_text(encoding="utf-8"))

        else:
            self.send_response(404)
            self.end_headers()

    # ── POST ───────────────────────────────────────────────────────────────
    def do_POST(self):
        self._read_body()

        if self.path == "/api/patrol/start":
            self._send_json(start_patrol())

        elif self.path == "/api/patrol/stop":
            self._send_json(stop_patrol())

        elif self.path == "/api/upgrade":
            if _upgrade_running:
                self._send_json({"ok": False, "message": "Upgrade already running"})
                return
            threading.Thread(target=_do_upgrade, daemon=True).start()
            self._send_json({"ok": True, "message": "Upgrade started"})

        elif self.path == "/api/unbind":
            if _config is not None:
                from bridgeflow.binding import clear_binding
                clear_binding(_config)
                self._send_json({"ok": True, "message": "已解绑"})
            else:
                self._send_json({"ok": False, "message": "配置未加载"})

        elif self.path == "/api/restart":
            self._send_json({"ok": True, "message": "Restarting..."})
            def _restart():
                time.sleep(1)
                try:
                    os.execv(sys.argv[0], sys.argv)
                except Exception:
                    subprocess.Popen([sys.argv[0]] + sys.argv[1:])
                    sys.exit(0)
            threading.Thread(target=_restart, daemon=True).start()

        else:
            self.send_response(404)
            self.end_headers()


# ── Startup ───────────────────────────────────────────────────────────────────

def start_dashboard(config: "PatrolConfig") -> None:
    """Start the dashboard HTTP server on a background thread."""
    global _config
    _config = config
    from bridgeflow.env_check import check_env

    env = check_env()
    update_status(
        relay_url=config.relay_url,
        room_key=config.room_key,
        device_id=config.device_id,
        device_name=config.device_name,
        machine_code=config.machine_code,
        bind_status=config.bind_status,
        env=env.to_dict(),
    )

    server = HTTPServer(("127.0.0.1", DASHBOARD_PORT), _Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
