"""
Patrol logic -- file scanning and doctor checks.
File-driven mode: no ACP, no CLI.
"""
from __future__ import annotations

from dataclasses import dataclass

from bridgeflow.config import PatrolConfig
from bridgeflow.file_watcher import decide_notify_targets, scan_markdown_files


@dataclass
class PatrolDoctorResult:
    tasks_dir_exists: bool
    reports_dir_exists: bool


def run_doctor(config: PatrolConfig) -> PatrolDoctorResult:
    return PatrolDoctorResult(
        tasks_dir_exists=config.tasks_dir.exists(),
        reports_dir_exists=config.reports_dir.exists(),
    )


def print_doctor_result(result: PatrolDoctorResult) -> None:
    print("=== BridgeFlow doctor (file-driven) ===")
    print(f"  tasks dir    : {'OK' if result.tasks_dir_exists else 'MISSING'}")
    print(f"  reports dir  : {'OK' if result.reports_dir_exists else 'MISSING'}")
    if not result.tasks_dir_exists or not result.reports_dir_exists:
        print("  Run 'bridgeflow run' in your project directory to create them.")


def patrol_once(config: PatrolConfig) -> set[str]:
    current_tasks = scan_markdown_files(config.tasks_dir)
    current_reports = scan_markdown_files(config.reports_dir)
    return decide_notify_targets(current_tasks, current_reports, config.role_to_chat)


def monitor_targets(config: PatrolConfig, callback) -> None:
    import time
    known_tasks = scan_markdown_files(config.tasks_dir)
    known_reports = scan_markdown_files(config.reports_dir)

    while True:
        time.sleep(config.patrol_poll_interval)
        current_tasks = scan_markdown_files(config.tasks_dir)
        current_reports = scan_markdown_files(config.reports_dir)
        new_tasks = current_tasks - known_tasks
        new_reports = current_reports - known_reports
        if new_tasks or new_reports:
            callback(new_tasks, new_reports, decide_notify_targets(new_tasks, new_reports, config.role_to_chat))
            known_tasks = current_tasks
            known_reports = current_reports
