"""Pydantic models for the AMFS Pro multi-tenant IAM layer.

Hierarchy: Account -> Users (with roles) + API Keys (with scopes).
Every memory operation is scoped to an account via Postgres RLS.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class Role(str, Enum):
    """User roles within an account."""

    ADMIN = "admin"
    DEVELOPER = "developer"
    USER = "user"


class KeyType(str, Enum):
    """API key types with different default capabilities."""

    AGENT = "agent"
    INGESTION = "ingestion"
    READONLY = "readonly"
    ADMIN = "admin"


class Permission(str, Enum):
    """Entity-path permission levels attached to API key scopes."""

    READ = "read"
    WRITE = "write"
    READ_WRITE = "read_write"


class ActorType(str, Enum):
    """Type of actor that performed an auditable action."""

    USER = "user"
    API_KEY = "api_key"
    SYSTEM = "system"


class VisibilityLevel(str, Enum):
    """Cross-boundary visibility within an account.

    - none: agents only see their own team/namespace
    - read_only: agents can read across boundaries but only write to their own
    - full: unrestricted access within the account (OSS-like behavior)
    """

    NONE = "none"
    READ_ONLY = "read_only"
    FULL = "full"


class PlanTier(str, Enum):
    """Account plan tiers with different quota limits.

    Must match the CHECK constraint on accounts.plan_tier (migration 023):
    free, starter, pro, team, teams, enterprise.
    """

    FREE = "free"
    STARTER = "starter"
    PRO = "pro"
    TEAM = "team"
    TEAMS = "teams"
    ENTERPRISE = "enterprise"


# ---------------------------------------------------------------------------
# Quota defaults per tier
# ---------------------------------------------------------------------------

TIER_QUOTAS: dict[PlanTier, dict[str, int]] = {
    PlanTier.FREE: {
        "max_entries": 1_000,
        "max_decision_traces": 100,
        "max_api_keys": 1,
        "max_users": 1,
        "max_ingestion_webhooks": 0,
        "default_rate_limit_rpm": 30,
        "audit_retention_days": 7,
    },
    PlanTier.STARTER: {
        "max_entries": 10_000,
        "max_decision_traces": 1_000,
        "max_api_keys": 5,
        "max_users": 3,
        "max_ingestion_webhooks": 2,
        "default_rate_limit_rpm": 60,
        "audit_retention_days": 30,
    },
    PlanTier.PRO: {
        "max_entries": 50_000,
        "max_decision_traces": 10_000,
        "max_api_keys": 50,
        "max_users": 5,
        "max_ingestion_webhooks": 5,
        "default_rate_limit_rpm": 300,
        "audit_retention_days": 90,
    },
    PlanTier.TEAM: {
        "max_entries": 100_000,
        "max_decision_traces": 50_000,
        "max_api_keys": 25,
        "max_users": 20,
        "max_ingestion_webhooks": 10,
        "default_rate_limit_rpm": 600,
        "audit_retention_days": 365,
    },
    PlanTier.TEAMS: {
        "max_entries": 100_000,
        "max_decision_traces": 50_000,
        "max_api_keys": 25,
        "max_users": 20,
        "max_ingestion_webhooks": 10,
        "default_rate_limit_rpm": 600,
        "audit_retention_days": 365,
    },
    PlanTier.ENTERPRISE: {
        "max_entries": 0,  # 0 = unlimited
        "max_decision_traces": 0,
        "max_api_keys": 0,
        "max_users": 0,
        "max_ingestion_webhooks": 0,
        "default_rate_limit_rpm": 6_000,
        "audit_retention_days": 0,  # unlimited
    },
}


# ---------------------------------------------------------------------------
# Visibility policy (stored in accounts.settings JSONB)
# ---------------------------------------------------------------------------

class VisibilityPolicy(BaseModel):
    """Configurable visibility policy for an account.

    Stored as ``accounts.settings["visibility"]`` in the database.
    """

    cross_team: VisibilityLevel = VisibilityLevel.READ_ONLY
    cross_namespace: VisibilityLevel = VisibilityLevel.NONE


class AgentDefaults(BaseModel):
    """Default settings for agents created in an account.

    Stored as ``accounts.settings["agent_defaults"]`` in the database.
    """

    auto_register: bool = True
    default_team_id: UUID | None = None


# ---------------------------------------------------------------------------
# Core models
# ---------------------------------------------------------------------------

class Account(BaseModel):
    """A tenant account — the hard isolation boundary."""

    id: UUID = Field(default_factory=uuid4)
    name: str
    slug: str
    plan_tier: PlanTier | None = None
    max_entries: int = 10_000
    max_api_keys: int = 5
    max_users: int = 3
    settings: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime | None = None

    @property
    def visibility_policy(self) -> VisibilityPolicy:
        raw = self.settings.get("visibility", {})
        return VisibilityPolicy(**raw) if raw else VisibilityPolicy()

    @property
    def agent_defaults(self) -> AgentDefaults:
        raw = self.settings.get("agent_defaults", {})
        return AgentDefaults(**raw) if raw else AgentDefaults()


class User(BaseModel):
    """A human user within an account, authenticated via OAuth/OIDC."""

    id: UUID = Field(default_factory=uuid4)
    account_id: UUID
    email: str
    name: str | None = None
    role: Role = Role.USER
    idp_subject: str | None = None
    idp_provider: str | None = None
    mfa_enabled: bool = False
    last_login: datetime | None = None
    created_at: datetime | None = None


class APIKey(BaseModel):
    """An API key used by agents, ingestion tools, or admin scripts.

    The raw key is only available at creation time. We store the argon2 hash
    and a prefix (first 8 chars) for identification in logs and dashboards.
    """

    id: UUID = Field(default_factory=uuid4)
    account_id: UUID
    created_by: UUID
    name: str
    key_hash: str
    key_prefix: str
    key_type: KeyType = KeyType.AGENT
    active: bool = True
    expires_at: datetime | None = None
    rate_limit_rpm: int = 60
    last_used_at: datetime | None = None
    created_at: datetime | None = None
    scopes: list[APIKeyScope] = Field(default_factory=list)


class APIKeyScope(BaseModel):
    """A permission scope binding an API key to entity path patterns.

    Path patterns use glob-style matching:
      - ``checkout-service/*``  — direct children
      - ``client-a/**``         — recursive match
      - ``*/incidents``         — incidents under any entity
      - ``*``                   — full access
    """

    id: UUID = Field(default_factory=uuid4)
    api_key_id: UUID
    entity_path_pattern: str
    permission: Permission = Permission.READ_WRITE


class Agent(BaseModel):
    """A registered agent within an account, optionally assigned to a team."""

    id: UUID = Field(default_factory=uuid4)
    account_id: UUID
    team_id: UUID | None = None
    agent_id: str
    namespace: str = "default"
    display_name: str | None = None
    description: str | None = None
    config: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime | None = None
    last_seen_at: datetime | None = None


class AuditEntry(BaseModel):
    """An immutable audit log record for compliance and traceability."""

    id: UUID = Field(default_factory=uuid4)
    account_id: UUID
    actor_id: UUID
    actor_type: ActorType
    action: str
    resource: str | None = None
    details: dict[str, Any] | None = None
    ip_address: str | None = None
    created_at: datetime | None = None


# ---------------------------------------------------------------------------
# Auth context — threaded through every request
# ---------------------------------------------------------------------------

class TenantContext(BaseModel):
    """Resolved authentication and authorization context for a request.

    Set once at the middleware layer and propagated through the call chain.
    The Postgres connection uses ``account_id`` to set the RLS variable.
    """

    account_id: UUID
    actor_id: UUID
    actor_type: ActorType
    role: Role | None = None
    key_type: KeyType | None = None
    scopes: list[APIKeyScope] = Field(default_factory=list)
    agent_id: str | None = None
    team_id: UUID | None = None
    namespace: str = "default"
    visibility: VisibilityPolicy = Field(default_factory=VisibilityPolicy)
    rate_limit_rpm: int = 60

    @property
    def is_admin(self) -> bool:
        return self.role == Role.ADMIN or self.key_type == KeyType.ADMIN

    @property
    def is_developer(self) -> bool:
        return self.role in (Role.ADMIN, Role.DEVELOPER) or self.key_type in (
            KeyType.ADMIN,
            KeyType.AGENT,
            KeyType.INGESTION,
        )
