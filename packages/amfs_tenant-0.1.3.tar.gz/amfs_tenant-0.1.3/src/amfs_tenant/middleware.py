"""FastAPI middleware and dependencies for multi-tenant authentication.

Resolves incoming requests to a ``TenantContext`` via either:
  - Bearer token (API key) → agent / ingestion / admin access
  - Session cookie         → human dashboard access (OAuth/OIDC)

Sets the Postgres RLS session variable so all downstream queries
are automatically scoped to the tenant. Populates visibility policy
and agent context when available.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated, Any
from uuid import UUID

import psycopg
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from psycopg.rows import dict_row

from amfs_tenant.models import ActorType, Role, TenantContext, VisibilityPolicy
from amfs_tenant.repository import (
    authenticate_api_key,
    get_user,
    get_visibility_policy,
    resolve_agent_context,
    set_tenant_context,
    write_audit,
)


def _q(conn: psycopg.Connection) -> psycopg.Cursor:
    return conn.cursor(row_factory=dict_row)

_bearer_scheme = HTTPBearer(auto_error=False)


def _get_db(request: Request) -> psycopg.Connection:
    """Retrieve the database connection from app state.

    The Pro HTTP server must attach a connection (or pool) to
    ``request.app.state.db``. This is a thin integration point.
    """
    db = getattr(request.app.state, "db", None)
    if db is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database not available",
        )
    return db


async def resolve_tenant(
    request: Request,
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer_scheme)] = None,
) -> TenantContext:
    """FastAPI dependency that resolves the request to a TenantContext.

    Priority:
      1. Authorization: Bearer <api_key>
      2. Session cookie (for dashboard users)

    Also resolves the account's visibility policy and agent context
    (team_id, namespace) when an agent_id is provided via header or
    query parameter.
    """
    db = _get_db(request)

    # --- API Key auth ---
    if credentials and credentials.credentials:
        ctx = authenticate_api_key(db, credentials.credentials)
        if ctx is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired API key",
            )
        key_team = _q(db).execute(
            "SELECT team_id FROM api_keys WHERE id = %s", [str(ctx.actor_id)]
        ).fetchone()
        key_team_id = key_team["team_id"] if key_team else None
        set_tenant_context(db, ctx.account_id, team_id=key_team_id, is_admin=False)

        ctx = _enrich_context(db, ctx, request)
        return ctx

    # --- Session/cookie auth ---
    session_data = getattr(request.state, "session", None)
    if session_data and "user_id" in session_data:
        user = get_user(db, UUID(session_data["user_id"]))
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Session user not found",
            )
        user_team = _q(db).execute(
            """SELECT tm.team_id FROM amfs_team_members tm
               JOIN amfs_teams t ON t.id = tm.team_id
               WHERE lower(tm.email) = lower(%s) AND t.account_id = %s
                 AND tm.removed_at IS NULL
               LIMIT 1""",
            [user.email, str(user.account_id)]
        ).fetchone()
        user_team_id = user_team["team_id"] if user_team else None
        is_admin = user.role == Role.ADMIN
        ctx = TenantContext(
            account_id=user.account_id,
            actor_id=user.id,
            actor_type=ActorType.USER,
            role=user.role,
            team_id=user_team_id,
            scopes=[],
        )
        set_tenant_context(db, ctx.account_id, team_id=user_team_id, is_admin=is_admin)

        ctx = _enrich_context(db, ctx, request)
        return ctx

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required",
        headers={"WWW-Authenticate": "Bearer"},
    )


def _enrich_context(
    db: psycopg.Connection,
    ctx: TenantContext,
    request: Request,
) -> TenantContext:
    """Add visibility policy and agent context to the tenant context.

    Reads X-AMFS-Agent-Id and X-AMFS-Namespace headers (or query params)
    to resolve the requesting agent's team and the account's visibility policy.
    """
    agent_id = (
        request.headers.get("x-amfs-agent-id")
        or request.query_params.get("agent_id")
    )
    namespace = (
        request.headers.get("x-amfs-namespace")
        or request.query_params.get("namespace")
        or "default"
    )

    try:
        visibility = get_visibility_policy(db, ctx.account_id)
    except Exception:
        visibility = VisibilityPolicy()

    team_id = None
    if agent_id:
        try:
            team_id, visibility = resolve_agent_context(
                db, ctx.account_id, agent_id, namespace,
            )
        except Exception:
            pass

    return ctx.model_copy(update={
        "agent_id": agent_id,
        "team_id": team_id,
        "namespace": namespace,
        "visibility": visibility,
    })


def require_role(*roles: Role):
    """FastAPI dependency factory that enforces user role requirements."""

    async def _check(ctx: Annotated[TenantContext, Depends(resolve_tenant)]) -> TenantContext:
        if ctx.actor_type == ActorType.API_KEY:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="This endpoint requires a user session, not an API key",
            )
        if ctx.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires one of: {[r.value for r in roles]}",
            )
        return ctx

    return _check


def require_admin():
    """Shorthand: require admin role."""
    return require_role(Role.ADMIN)


def require_developer():
    """Shorthand: require admin or developer role."""
    return require_role(Role.ADMIN, Role.DEVELOPER)


# ---------------------------------------------------------------------------
# Audit helper
# ---------------------------------------------------------------------------

def audit(
    db: psycopg.Connection,
    ctx: TenantContext,
    action: str,
    *,
    resource: str | None = None,
    details: dict[str, Any] | None = None,
    ip_address: str | None = None,
) -> None:
    """Write an audit log entry for the current request."""
    write_audit(
        db,
        account_id=ctx.account_id,
        actor_id=ctx.actor_id,
        actor_type=ctx.actor_type,
        action=action,
        resource=resource,
        details=details,
        ip_address=ip_address,
    )
