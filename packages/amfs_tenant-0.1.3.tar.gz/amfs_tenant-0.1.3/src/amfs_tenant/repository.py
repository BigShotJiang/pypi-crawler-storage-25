"""Database repository for multi-tenant IAM operations.

All public methods accept a ``psycopg.Connection`` (or async variant) that
must already have ``amfs.current_account_id`` set for RLS enforcement —
except ``create_account`` and ``authenticate_api_key`` which operate across
tenants by design.
"""

from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

import psycopg
from argon2 import PasswordHasher
from psycopg.rows import dict_row

from amfs_tenant.models import (
    Account,
    Agent,
    AgentDefaults,
    ActorType,
    APIKey,
    APIKeyScope,
    AuditEntry,
    KeyType,
    Permission,
    PlanTier,
    Role,
    TenantContext,
    TIER_QUOTAS,
    User,
    VisibilityLevel,
    VisibilityPolicy,
)

_ph = PasswordHasher()


def _q(conn: psycopg.Connection) -> psycopg.Cursor:
    """Return a cursor with dict_row regardless of connection-level setting."""
    return conn.cursor(row_factory=dict_row)


KEY_PREFIX_LEN = 8
KEY_RANDOM_BYTES = 32


def _generate_api_key(env: str = "live") -> tuple[str, str, str]:
    """Generate a raw API key, its hash, and its display prefix.

    Returns (raw_key, key_hash, key_prefix).
    """
    random_part = secrets.token_urlsafe(KEY_RANDOM_BYTES)
    raw_key = f"amfs_sk_{env}_{random_part}"
    key_hash = _ph.hash(raw_key)
    key_prefix = raw_key[:KEY_PREFIX_LEN]
    return raw_key, key_hash, key_prefix


def _verify_key(raw_key: str, key_hash: str) -> bool:
    try:
        return _ph.verify(key_hash, raw_key)
    except Exception:
        return False


# =========================================================================
# Tenant context helpers
# =========================================================================

def set_tenant_context(
    conn: psycopg.Connection,
    account_id: UUID,
    team_id: UUID | None = None,
    is_admin: bool = False,
) -> None:
    """Set RLS session variables for the current connection."""
    _q(conn).execute(
        "SELECT set_config('amfs.current_account_id', %s, true)",
        [str(account_id)],
    )
    _q(conn).execute(
        "SELECT set_config('amfs.current_team_id', %s, true)",
        [str(team_id) if team_id else ""],
    )
    _q(conn).execute(
        "SELECT set_config('amfs.is_account_admin', %s, true)",
        ["true" if is_admin else "false"],
    )


def clear_tenant_context(conn: psycopg.Connection) -> None:
    _q(conn).execute("RESET amfs.current_account_id")


# =========================================================================
# Account operations
# =========================================================================

_PENDING_PLAN_QUOTAS = {"max_entries": 1000, "max_api_keys": 1, "max_users": 1}

def create_account(
    conn: psycopg.Connection,
    *,
    name: str,
    slug: str,
    plan_tier: PlanTier | None = None,
    settings: dict[str, Any] | None = None,
) -> Account:
    """Create a new tenant account. Does NOT require RLS context."""
    quotas = TIER_QUOTAS[plan_tier] if plan_tier is not None else _PENDING_PLAN_QUOTAS
    row = _q(conn).execute(
        """
        INSERT INTO accounts (name, slug, plan_tier, max_entries, max_api_keys, max_users, settings)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        RETURNING *
        """,
        [
            name,
            slug,
            plan_tier.value if plan_tier is not None else None,
            quotas["max_entries"],
            quotas["max_api_keys"],
            quotas["max_users"],
            psycopg.types.json.Json(settings or {}),
        ],
    ).fetchone()
    return _row_to_account(row)


def get_account(conn: psycopg.Connection, account_id: UUID) -> Account | None:
    row = _q(conn).execute(
        "SELECT * FROM accounts WHERE id = %s",
        [str(account_id)],
    ).fetchone()
    return _row_to_account(row) if row else None


def get_account_by_slug(conn: psycopg.Connection, slug: str) -> Account | None:
    row = _q(conn).execute(
        "SELECT * FROM accounts WHERE slug = %s",
        [slug],
    ).fetchone()
    return _row_to_account(row) if row else None


def update_account(
    conn: psycopg.Connection,
    account_id: UUID,
    *,
    name: str | None = None,
    plan_tier: PlanTier | None = None,
    settings: dict[str, Any] | None = None,
) -> Account | None:
    updates: list[str] = []
    params: list[Any] = []
    if name is not None:
        updates.append("name = %s")
        params.append(name)
    if plan_tier is not None:
        quotas = TIER_QUOTAS[plan_tier]
        updates.extend([
            "plan_tier = %s",
            "max_entries = %s",
            "max_api_keys = %s",
            "max_users = %s",
        ])
        params.extend([plan_tier.value, quotas["max_entries"], quotas["max_api_keys"], quotas["max_users"]])
    if settings is not None:
        updates.append("settings = %s")
        params.append(psycopg.types.json.Json(settings))
    if not updates:
        return get_account(conn, account_id)
    params.append(str(account_id))
    row = _q(conn).execute(
        f"UPDATE accounts SET {', '.join(updates)} WHERE id = %s RETURNING *",
        params,
    ).fetchone()
    return _row_to_account(row) if row else None


# =========================================================================
# User operations
# =========================================================================

def create_user(
    conn: psycopg.Connection,
    *,
    account_id: UUID,
    email: str,
    name: str | None = None,
    role: Role = Role.USER,
    idp_subject: str | None = None,
    idp_provider: str | None = None,
) -> User:
    row = _q(conn).execute(
        """
        INSERT INTO users (account_id, email, name, role, idp_subject, idp_provider)
        VALUES (%s, %s, %s, %s, %s, %s)
        RETURNING *
        """,
        [str(account_id), email, name, role.value, idp_subject, idp_provider],
    ).fetchone()
    return _row_to_user(row)


def get_user(conn: psycopg.Connection, user_id: UUID) -> User | None:
    row = _q(conn).execute(
        "SELECT * FROM users WHERE id = %s", [str(user_id)]
    ).fetchone()
    return _row_to_user(row) if row else None


def get_user_by_email(conn: psycopg.Connection, email: str) -> User | None:
    row = _q(conn).execute(
        "SELECT * FROM users WHERE email = %s", [email]
    ).fetchone()
    return _row_to_user(row) if row else None


def get_user_by_idp(
    conn: psycopg.Connection, idp_provider: str, idp_subject: str
) -> User | None:
    row = _q(conn).execute(
        "SELECT * FROM users WHERE idp_provider = %s AND idp_subject = %s",
        [idp_provider, idp_subject],
    ).fetchone()
    return _row_to_user(row) if row else None


def list_users(conn: psycopg.Connection, account_id: UUID) -> list[User]:
    """List all users in an account (requires RLS context set)."""
    rows = _q(conn).execute(
        "SELECT * FROM users WHERE account_id = %s ORDER BY created_at",
        [str(account_id)],
    ).fetchall()
    return [_row_to_user(r) for r in rows]


def update_user_role(conn: psycopg.Connection, user_id: UUID, role: Role) -> User | None:
    row = _q(conn).execute(
        "UPDATE users SET role = %s WHERE id = %s RETURNING *",
        [role.value, str(user_id)],
    ).fetchone()
    return _row_to_user(row) if row else None


def delete_user(conn: psycopg.Connection, user_id: UUID) -> bool:
    result = _q(conn).execute("DELETE FROM users WHERE id = %s", [str(user_id)])
    return result.rowcount > 0


def touch_user_login(conn: psycopg.Connection, user_id: UUID) -> None:
    _q(conn).execute(
        "UPDATE users SET last_login = %s WHERE id = %s",
        [datetime.now(timezone.utc), str(user_id)],
    )


# =========================================================================
# API Key operations
# =========================================================================

def create_api_key(
    conn: psycopg.Connection,
    *,
    account_id: UUID,
    created_by: UUID,
    name: str,
    key_type: KeyType = KeyType.AGENT,
    scopes: list[tuple[str, Permission]] | None = None,
    expires_at: datetime | None = None,
    rate_limit_rpm: int = 60,
    env: str = "live",
    team_id: UUID | None = None,
) -> tuple[APIKey, str]:
    """Create an API key with scopes. Returns (key_model, raw_key).

    The raw key is only available here — store/display it once.
    """
    raw_key, key_hash, key_prefix = _generate_api_key(env)

    row = _q(conn).execute(
        """
        INSERT INTO api_keys (account_id, created_by, name, key_hash, key_prefix,
                              key_type, expires_at, rate_limit_rpm, team_id)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING *
        """,
        [
            str(account_id), str(created_by), name, key_hash, key_prefix,
            key_type.value, expires_at, rate_limit_rpm,
            str(team_id) if team_id else None,
        ],
    ).fetchone()
    key = _row_to_api_key(row)

    if scopes:
        for pattern, perm in scopes:
            _create_scope(conn, key.id, pattern, perm)
    key.scopes = list_api_key_scopes(conn, key.id)

    return key, raw_key


def authenticate_api_key(
    conn: psycopg.Connection, raw_key: str
) -> TenantContext | None:
    """Look up an API key by prefix, verify the hash, return a TenantContext.

    This operates OUTSIDE RLS (uses prefix index across all accounts).
    Returns None if the key is invalid, inactive, or expired.
    """
    prefix = raw_key[:KEY_PREFIX_LEN]
    rows = _q(conn).execute(
        """
        SELECT ak.*, array_agg(
            json_build_object(
                'id', s.id, 'api_key_id', s.api_key_id,
                'entity_path_pattern', s.entity_path_pattern,
                'permission', s.permission
            )
        ) FILTER (WHERE s.id IS NOT NULL) AS scope_rows
        FROM api_keys ak
        LEFT JOIN api_key_scopes s ON s.api_key_id = ak.id
        WHERE ak.key_prefix = %s AND ak.active = true
        GROUP BY ak.id
        """,
        [prefix],
    ).fetchall()

    now = datetime.now(timezone.utc)
    for row in rows:
        if not _verify_key(raw_key, row["key_hash"]):
            continue
        if row.get("expires_at") and row["expires_at"] < now:
            continue

        _q(conn).execute(
            "UPDATE api_keys SET last_used_at = %s WHERE id = %s",
            [now, str(row["id"])],
        )

        scopes = _parse_scope_rows(row.get("scope_rows") or [])
        return TenantContext(
            account_id=row["account_id"],
            actor_id=row["id"],
            actor_type=ActorType.API_KEY,
            key_type=KeyType(row["key_type"]),
            scopes=scopes,
            rate_limit_rpm=row.get("rate_limit_rpm") or 60,
        )

    return None


def list_api_keys(conn: psycopg.Connection, account_id: UUID) -> list[APIKey]:
    rows = _q(conn).execute(
        "SELECT * FROM api_keys WHERE account_id = %s ORDER BY created_at",
        [str(account_id)],
    ).fetchall()
    keys = [_row_to_api_key(r) for r in rows]
    for key in keys:
        key.scopes = list_api_key_scopes(conn, key.id)
    return keys


def revoke_api_key(conn: psycopg.Connection, key_id: UUID) -> bool:
    result = _q(conn).execute(
        "UPDATE api_keys SET active = false WHERE id = %s", [str(key_id)]
    )
    return result.rowcount > 0


def list_api_key_scopes(conn: psycopg.Connection, key_id: UUID) -> list[APIKeyScope]:
    rows = _q(conn).execute(
        "SELECT * FROM api_key_scopes WHERE api_key_id = %s",
        [str(key_id)],
    ).fetchall()
    return [_row_to_scope(r) for r in rows]


def _create_scope(
    conn: psycopg.Connection,
    key_id: UUID,
    pattern: str,
    permission: Permission,
) -> APIKeyScope:
    row = _q(conn).execute(
        """
        INSERT INTO api_key_scopes (api_key_id, entity_path_pattern, permission)
        VALUES (%s, %s, %s) RETURNING *
        """,
        [str(key_id), pattern, permission.value],
    ).fetchone()
    return _row_to_scope(row)


# =========================================================================
# Audit log
# =========================================================================

def write_audit(
    conn: psycopg.Connection,
    *,
    account_id: UUID,
    actor_id: UUID,
    actor_type: ActorType,
    action: str,
    resource: str | None = None,
    details: dict[str, Any] | None = None,
    ip_address: str | None = None,
) -> AuditEntry:
    row = _q(conn).execute(
        """
        INSERT INTO audit_log (account_id, actor_id, actor_type, action, resource, details, ip_address)
        VALUES (%s, %s, %s, %s, %s, %s, %s::inet)
        RETURNING *
        """,
        [
            str(account_id), str(actor_id), actor_type.value, action,
            resource, psycopg.types.json.Json(details) if details else None,
            ip_address,
        ],
    ).fetchone()
    return _row_to_audit(row)


def list_audit(
    conn: psycopg.Connection,
    account_id: UUID,
    *,
    action: str | None = None,
    since: datetime | None = None,
    limit: int = 100,
) -> list[AuditEntry]:
    clauses = ["account_id = %s"]
    params: list[Any] = [str(account_id)]
    if action:
        clauses.append("action = %s")
        params.append(action)
    if since:
        clauses.append("created_at >= %s")
        params.append(since)
    params.append(limit)
    rows = _q(conn).execute(
        f"SELECT * FROM audit_log WHERE {' AND '.join(clauses)} "
        f"ORDER BY created_at DESC LIMIT %s",
        params,
    ).fetchall()
    return [_row_to_audit(r) for r in rows]


# =========================================================================
# Quota checks
# =========================================================================

def check_entry_quota(conn: psycopg.Connection, account: Account) -> bool:
    """Return True if the account is within its entry quota (0 = unlimited)."""
    if account.max_entries == 0:
        return True
    row = _q(conn).execute(
        "SELECT COUNT(*) AS cnt FROM amfs_memory_entries WHERE account_id = %s AND superseded_at IS NULL",
        [str(account.id)],
    ).fetchone()
    return row["cnt"] < account.max_entries


def check_api_key_quota(conn: psycopg.Connection, account: Account) -> bool:
    if account.max_api_keys == 0:
        return True
    row = _q(conn).execute(
        "SELECT COUNT(*) AS cnt FROM api_keys WHERE account_id = %s AND active = true",
        [str(account.id)],
    ).fetchone()
    return row["cnt"] < account.max_api_keys


def check_user_quota(conn: psycopg.Connection, account: Account) -> bool:
    if account.max_users == 0:
        return True
    row = _q(conn).execute(
        "SELECT COUNT(*) AS cnt FROM users WHERE account_id = %s",
        [str(account.id)],
    ).fetchone()
    return row["cnt"] < account.max_users


# =========================================================================
# Row -> Model helpers
# =========================================================================

def _row_to_account(row: dict[str, Any]) -> Account:
    return Account(
        id=row["id"],
        name=row["name"],
        slug=row["slug"],
        plan_tier=PlanTier(row["plan_tier"]),
        max_entries=row["max_entries"],
        max_api_keys=row["max_api_keys"],
        max_users=row["max_users"],
        settings=row.get("settings") or {},
        created_at=row["created_at"],
    )


def _row_to_user(row: dict[str, Any]) -> User:
    return User(
        id=row["id"],
        account_id=row["account_id"],
        email=row["email"],
        name=row.get("name"),
        role=Role(row["role"]),
        idp_subject=row.get("idp_subject"),
        idp_provider=row.get("idp_provider"),
        mfa_enabled=row.get("mfa_enabled", False),
        last_login=row.get("last_login"),
        created_at=row["created_at"],
    )


def _row_to_api_key(row: dict[str, Any]) -> APIKey:
    return APIKey(
        id=row["id"],
        account_id=row["account_id"],
        created_by=row["created_by"],
        name=row["name"],
        key_hash=row["key_hash"],
        key_prefix=row["key_prefix"],
        key_type=KeyType(row["key_type"]),
        active=row["active"],
        expires_at=row.get("expires_at"),
        rate_limit_rpm=row.get("rate_limit_rpm", 60),
        last_used_at=row.get("last_used_at"),
        created_at=row["created_at"],
    )


def _row_to_scope(row: dict[str, Any]) -> APIKeyScope:
    return APIKeyScope(
        id=row["id"],
        api_key_id=row["api_key_id"],
        entity_path_pattern=row["entity_path_pattern"],
        permission=Permission(row["permission"]),
    )


def _row_to_audit(row: dict[str, Any]) -> AuditEntry:
    return AuditEntry(
        id=row["id"],
        account_id=row["account_id"],
        actor_id=row["actor_id"],
        actor_type=ActorType(row["actor_type"]),
        action=row["action"],
        resource=row.get("resource"),
        details=row.get("details"),
        ip_address=str(row["ip_address"]) if row.get("ip_address") else None,
        created_at=row["created_at"],
    )


def _parse_scope_rows(scope_rows: list[Any]) -> list[APIKeyScope]:
    scopes: list[APIKeyScope] = []
    for s in scope_rows:
        if isinstance(s, dict):
            scopes.append(APIKeyScope(
                id=s["id"],
                api_key_id=s["api_key_id"],
                entity_path_pattern=s["entity_path_pattern"],
                permission=Permission(s["permission"]),
            ))
    return scopes


# =========================================================================
# Agent registration
# =========================================================================

def register_agent(
    conn: psycopg.Connection,
    *,
    account_id: UUID,
    agent_id: str,
    namespace: str = "default",
    team_id: UUID | None = None,
    owner_user_id: UUID | None = None,
    display_name: str | None = None,
    description: str | None = None,
    config: dict[str, Any] | None = None,
) -> Agent:
    """Register an agent within an account, creating or updating the record."""
    row = _q(conn).execute(
        """
        INSERT INTO agents (account_id, team_id, agent_id, namespace, owner_user_id, display_name, description, config)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (account_id, namespace, agent_id) DO UPDATE SET
            team_id = EXCLUDED.team_id,
            owner_user_id = COALESCE(agents.owner_user_id, EXCLUDED.owner_user_id),
            display_name = COALESCE(EXCLUDED.display_name, agents.display_name),
            description = COALESCE(EXCLUDED.description, agents.description),
            config = CASE WHEN EXCLUDED.config != '{}'::jsonb THEN EXCLUDED.config ELSE agents.config END,
            last_seen_at = now()
        RETURNING *
        """,
        [
            str(account_id), str(team_id) if team_id else None, agent_id,
            namespace, str(owner_user_id) if owner_user_id else None,
            display_name, description,
            psycopg.types.json.Json(config or {}),
        ],
    ).fetchone()
    return _row_to_agent(row)


def get_agent(conn: psycopg.Connection, agent_id: str, namespace: str = "default") -> Agent | None:
    row = _q(conn).execute(
        "SELECT * FROM agents WHERE agent_id = %s AND namespace = %s",
        [agent_id, namespace],
    ).fetchone()
    return _row_to_agent(row) if row else None


def list_agents(conn: psycopg.Connection, account_id: UUID) -> list[Agent]:
    rows = _q(conn).execute(
        "SELECT * FROM agents WHERE account_id = %s ORDER BY created_at",
        [str(account_id)],
    ).fetchall()
    return [_row_to_agent(r) for r in rows]


def touch_agent(conn: psycopg.Connection, agent_id: str, namespace: str = "default") -> None:
    """Update last_seen_at for an agent."""
    _q(conn).execute(
        "UPDATE agents SET last_seen_at = %s WHERE agent_id = %s AND namespace = %s",
        [datetime.now(timezone.utc), agent_id, namespace],
    )


def delete_agent(conn: psycopg.Connection, agent_uuid: UUID) -> bool:
    result = _q(conn).execute("DELETE FROM agents WHERE id = %s", [str(agent_uuid)])
    return result.rowcount > 0


def _row_to_agent(row: dict[str, Any]) -> Agent:
    return Agent(
        id=row["id"],
        account_id=row["account_id"],
        team_id=row.get("team_id"),
        agent_id=row["agent_id"],
        namespace=row.get("namespace", "default"),
        display_name=row.get("display_name"),
        description=row.get("description"),
        config=row.get("config") or {},
        created_at=row["created_at"],
        last_seen_at=row.get("last_seen_at"),
    )


# =========================================================================
# Visibility policy operations
# =========================================================================

def get_visibility_policy(conn: psycopg.Connection, account_id: UUID) -> VisibilityPolicy:
    """Read the visibility policy from account settings."""
    row = _q(conn).execute(
        "SELECT settings FROM accounts WHERE id = %s",
        [str(account_id)],
    ).fetchone()
    if not row:
        return VisibilityPolicy()
    settings = row.get("settings") or {}
    raw = settings.get("visibility", {})
    return VisibilityPolicy(**raw) if raw else VisibilityPolicy()


def update_visibility_policy(
    conn: psycopg.Connection,
    account_id: UUID,
    policy: VisibilityPolicy,
) -> VisibilityPolicy:
    """Update the visibility policy in account settings JSONB."""
    _q(conn).execute(
        """
        UPDATE accounts
        SET settings = jsonb_set(
            COALESCE(settings, '{}'::jsonb),
            '{visibility}',
            %s::jsonb
        )
        WHERE id = %s
        """,
        [policy.model_dump_json(), str(account_id)],
    )
    return policy


def get_agent_defaults(conn: psycopg.Connection, account_id: UUID) -> AgentDefaults:
    """Read agent defaults from account settings."""
    row = _q(conn).execute(
        "SELECT settings FROM accounts WHERE id = %s",
        [str(account_id)],
    ).fetchone()
    if not row:
        return AgentDefaults()
    settings = row.get("settings") or {}
    raw = settings.get("agent_defaults", {})
    return AgentDefaults(**raw) if raw else AgentDefaults()


def update_agent_defaults(
    conn: psycopg.Connection,
    account_id: UUID,
    defaults: AgentDefaults,
) -> AgentDefaults:
    """Update agent defaults in account settings JSONB."""
    _q(conn).execute(
        """
        UPDATE accounts
        SET settings = jsonb_set(
            COALESCE(settings, '{}'::jsonb),
            '{agent_defaults}',
            %s::jsonb
        )
        WHERE id = %s
        """,
        [defaults.model_dump_json(), str(account_id)],
    )
    return defaults


def resolve_agent_context(
    conn: psycopg.Connection,
    account_id: UUID,
    agent_id: str,
    namespace: str = "default",
) -> tuple[UUID | None, VisibilityPolicy]:
    """Look up an agent's team_id and the account's visibility policy.

    Returns (team_id, visibility_policy). If the agent is not registered,
    team_id is None. Used by middleware to populate TenantContext.
    """
    policy = get_visibility_policy(conn, account_id)

    agent = get_agent(conn, agent_id, namespace)
    team_id = agent.team_id if agent else None

    return team_id, policy
