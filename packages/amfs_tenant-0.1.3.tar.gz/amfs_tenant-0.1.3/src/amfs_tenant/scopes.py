"""Scope enforcement for entity-path-level permissions.

Matches API key scopes (glob patterns) against requested entity paths
and checks whether the requested permission (READ / WRITE) is allowed.

Also enforces cross-team and cross-namespace visibility policies when
the requesting agent's team/namespace context is available.
"""

from __future__ import annotations

import re
from typing import Sequence
from uuid import UUID

from amfs_tenant.models import (
    APIKeyScope,
    KeyType,
    Permission,
    TenantContext,
    VisibilityLevel,
)


def _pattern_matches(pattern: str, entity_path: str) -> bool:
    """Check whether a glob-style scope pattern matches an entity path.

    Supports:
      ``checkout-service/*``  — direct children under checkout-service
      ``client-a/**``         — recursive match under client-a
      ``*/incidents``         — 'incidents' under any single-level entity
      ``*``                   — everything
    """
    if pattern == "*":
        return True

    regex = _glob_to_regex(pattern)
    return bool(re.match(regex, entity_path))


def _glob_to_regex(pattern: str) -> str:
    """Convert a path glob pattern to a regex string.

    ``**`` matches any number of path segments (including zero).
    ``*``  matches a single path segment (no slashes).
    """
    parts: list[str] = []
    i = 0
    while i < len(pattern):
        if pattern[i:i + 2] == "**":
            parts.append(".*")
            i += 2
            if i < len(pattern) and pattern[i] == "/":
                i += 1  # consume trailing slash after **
        elif pattern[i] == "*":
            parts.append("[^/]*")
            i += 1
        elif pattern[i] == "?":
            parts.append("[^/]")
            i += 1
        else:
            parts.append(re.escape(pattern[i]))
            i += 1
    return "^" + "".join(parts) + "$"


def _scope_allows(scope: APIKeyScope, entity_path: str, need: Permission) -> bool:
    if not _pattern_matches(scope.entity_path_pattern, entity_path):
        return False

    if scope.permission == Permission.READ_WRITE:
        return True
    if need == Permission.READ and scope.permission == Permission.READ:
        return True
    if need == Permission.WRITE and scope.permission == Permission.WRITE:
        return True
    return False


# ---------------------------------------------------------------------------
# Visibility policy enforcement
# ---------------------------------------------------------------------------

def check_cross_boundary(
    ctx: TenantContext,
    *,
    target_team_id: UUID | None = None,
    target_namespace: str | None = None,
    need: Permission,
) -> bool:
    """Check whether the visibility policy allows cross-boundary access.

    Returns True if the access is within the same boundary or the
    policy allows the requested access level across boundaries.
    Admins bypass all visibility checks.
    """
    if ctx.is_admin:
        return True

    policy = ctx.visibility

    if target_team_id is not None and ctx.team_id is not None:
        if target_team_id != ctx.team_id:
            if policy.cross_team == VisibilityLevel.NONE:
                return False
            if policy.cross_team == VisibilityLevel.READ_ONLY and need != Permission.READ:
                return False

    if target_namespace is not None:
        if target_namespace != ctx.namespace:
            if policy.cross_namespace == VisibilityLevel.NONE:
                return False
            if policy.cross_namespace == VisibilityLevel.READ_ONLY and need != Permission.READ:
                return False

    return True


def check_agent_visibility(
    ctx: TenantContext,
    entry_agent_id: str | None,
    entry_team_id: UUID | None,
    entry_namespace: str | None,
    need: Permission,
) -> bool:
    """Full visibility check for a specific memory entry.

    Combines scope-based and policy-based checks. Returns True if the
    requesting context is allowed to perform ``need`` on the entry.
    Same-agent access is always allowed.
    """
    if ctx.is_admin:
        return True

    if ctx.agent_id and entry_agent_id == ctx.agent_id:
        return True

    return check_cross_boundary(
        ctx,
        target_team_id=entry_team_id,
        target_namespace=entry_namespace,
        need=need,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def check_permission(
    ctx: TenantContext,
    entity_path: str,
    need: Permission,
) -> bool:
    """Return True if the tenant context allows ``need`` on ``entity_path``.

    Admin keys and admin users bypass scope checks entirely.
    """
    if ctx.is_admin:
        return True

    return any(
        _scope_allows(scope, entity_path, need) for scope in ctx.scopes
    )


def check_permission_with_visibility(
    ctx: TenantContext,
    entity_path: str,
    need: Permission,
    *,
    entry_agent_id: str | None = None,
    entry_team_id: UUID | None = None,
    entry_namespace: str | None = None,
) -> bool:
    """Combined scope + visibility check.

    First checks API key scopes, then applies the account's visibility
    policy for cross-team/cross-namespace access.
    """
    if not check_permission(ctx, entity_path, need):
        return False

    return check_agent_visibility(
        ctx, entry_agent_id, entry_team_id, entry_namespace, need,
    )


def filter_readable_paths(
    ctx: TenantContext,
    entity_paths: Sequence[str],
) -> list[str]:
    """Filter a list of entity paths to those the context can READ."""
    if ctx.is_admin:
        return list(entity_paths)
    return [p for p in entity_paths if check_permission(ctx, p, Permission.READ)]


def readable_patterns(ctx: TenantContext) -> list[str]:
    """Return the list of entity-path glob patterns the context can read.

    Useful for constructing SQL WHERE clauses with LIKE/pattern matching.
    """
    if ctx.is_admin:
        return ["*"]
    patterns: list[str] = []
    for scope in ctx.scopes:
        if scope.permission in (Permission.READ, Permission.READ_WRITE):
            patterns.append(scope.entity_path_pattern)
    return patterns


def writable_patterns(ctx: TenantContext) -> list[str]:
    """Return the list of entity-path glob patterns the context can write."""
    if ctx.is_admin:
        return ["*"]
    patterns: list[str] = []
    for scope in ctx.scopes:
        if scope.permission in (Permission.WRITE, Permission.READ_WRITE):
            patterns.append(scope.entity_path_pattern)
    return patterns
