"""In-memory sliding-window rate limiter and quota enforcer.

Uses a simple token-bucket approach per API key with minute-level granularity.
For distributed deployments, replace with Redis-backed implementation.
"""

from __future__ import annotations

import time
from collections import defaultdict
from typing import Any
from uuid import UUID

from amfs_tenant.models import Account, TenantContext


class RateLimitExceeded(Exception):
    """Raised when an API key exceeds its requests-per-minute limit."""

    def __init__(self, key_id: UUID, rpm_limit: int, retry_after: float) -> None:
        self.key_id = key_id
        self.rpm_limit = rpm_limit
        self.retry_after = retry_after
        super().__init__(
            f"Rate limit exceeded for key {str(key_id)[:8]}...: "
            f"{rpm_limit} RPM. Retry after {retry_after:.1f}s"
        )


class QuotaExceeded(Exception):
    """Raised when an account exceeds a hard quota limit."""

    def __init__(self, account_id: UUID, resource: str, limit: int) -> None:
        self.account_id = account_id
        self.resource = resource
        self.limit = limit
        super().__init__(
            f"Quota exceeded for account {str(account_id)[:8]}...: "
            f"max {resource} = {limit}"
        )


class SlidingWindowCounter:
    """Per-key sliding window counter for rate limiting.

    Each key gets a list of timestamps. On each check, we prune entries
    older than the window and count remaining.
    """

    def __init__(self, window_seconds: float = 60.0) -> None:
        self._window = window_seconds
        self._timestamps: dict[UUID, list[float]] = defaultdict(list)

    def check_and_record(self, key_id: UUID, limit: int) -> float | None:
        """Check if the key is within rate limit and record the request.

        Returns None if allowed, or the retry-after seconds if denied.
        """
        now = time.monotonic()
        cutoff = now - self._window
        timestamps = self._timestamps[key_id]

        # Prune old entries
        self._timestamps[key_id] = [t for t in timestamps if t > cutoff]
        timestamps = self._timestamps[key_id]

        if len(timestamps) >= limit:
            oldest = timestamps[0]
            retry_after = oldest + self._window - now
            return max(retry_after, 0.1)

        timestamps.append(now)
        return None

    def get_remaining(self, key_id: UUID, limit: int) -> int:
        """Return how many requests remain in the current window."""
        now = time.monotonic()
        cutoff = now - self._window
        timestamps = [t for t in self._timestamps.get(key_id, []) if t > cutoff]
        return max(0, limit - len(timestamps))

    def reset(self, key_id: UUID) -> None:
        """Clear rate limit state for a key (e.g. after key rotation)."""
        self._timestamps.pop(key_id, None)

    def clear(self) -> None:
        """Clear all rate limit state."""
        self._timestamps.clear()


class RateLimiter:
    """Rate limiter that enforces per-key RPM limits.

    Usage::

        limiter = RateLimiter()

        # In middleware, before processing the request:
        limiter.check(ctx)  # raises RateLimitExceeded if over limit

        # Get headers for the response:
        headers = limiter.response_headers(ctx)
    """

    def __init__(self) -> None:
        self._counter = SlidingWindowCounter(window_seconds=60.0)

    def check(self, ctx: TenantContext) -> None:
        """Check rate limit for the current request.

        Admin users are not rate-limited.
        Raises RateLimitExceeded if over limit.
        """
        if ctx.is_admin:
            return

        key_id = ctx.actor_id
        rpm_limit = self._get_rpm_limit(ctx)

        retry_after = self._counter.check_and_record(key_id, rpm_limit)
        if retry_after is not None:
            raise RateLimitExceeded(key_id, rpm_limit, retry_after)

    def response_headers(self, ctx: TenantContext) -> dict[str, str]:
        """Return rate limit headers for HTTP responses."""
        rpm_limit = self._get_rpm_limit(ctx)
        remaining = self._counter.get_remaining(ctx.actor_id, rpm_limit)
        return {
            "X-RateLimit-Limit": str(rpm_limit),
            "X-RateLimit-Remaining": str(remaining),
            "X-RateLimit-Window": "60",
        }

    def reset(self, key_id: UUID) -> None:
        self._counter.reset(key_id)

    def _get_rpm_limit(self, ctx: TenantContext) -> int:
        """Determine the RPM limit from the tenant context."""
        return ctx.rate_limit_rpm or 60


class QuotaEnforcer:
    """Enforces hard account-level quotas before write operations.

    Usage::

        enforcer = QuotaEnforcer()

        # Before writing a memory entry:
        enforcer.check_entry_write(account, current_entry_count)

        # Before creating an API key:
        enforcer.check_api_key_creation(account, current_key_count)
    """

    def check_entry_write(self, account: Account, current_count: int) -> None:
        """Check if the account can write another memory entry."""
        if account.max_entries == 0:  # unlimited
            return
        if current_count >= account.max_entries:
            raise QuotaExceeded(account.id, "entries", account.max_entries)

    def check_api_key_creation(self, account: Account, current_count: int) -> None:
        """Check if the account can create another API key."""
        if account.max_api_keys == 0:
            return
        if current_count >= account.max_api_keys:
            raise QuotaExceeded(account.id, "api_keys", account.max_api_keys)

    def check_user_creation(self, account: Account, current_count: int) -> None:
        """Check if the account can add another user."""
        if account.max_users == 0:
            return
        if current_count >= account.max_users:
            raise QuotaExceeded(account.id, "users", account.max_users)
