"""ScopedMemory — wraps AgentMemory with scope-based permission enforcement.

Every read/write/list/search/explain operation is checked against the
TenantContext's API key scopes. This is permissioned inference: agents
only see and write memory within their authorized entity paths.

Brain methods (recall, my_entries, read_from) add agent-scoped views
with cross-team/cross-namespace visibility policy enforcement.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from amfs_tenant.models import Permission, TenantContext, VisibilityLevel
from amfs_tenant.scopes import (
    check_agent_visibility,
    check_permission,
    filter_readable_paths,
)


class PermissionDenied(Exception):
    """Raised when a memory operation violates scope permissions."""

    def __init__(self, entity_path: str, permission: Permission) -> None:
        self.entity_path = entity_path
        self.permission = permission
        super().__init__(
            f"Permission denied: {permission.value} on '{entity_path}'"
        )


class VisibilityDenied(Exception):
    """Raised when a cross-boundary access violates visibility policy."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(f"Visibility denied: {reason}")


class ScopedMemory:
    """Wraps any AgentMemory-like object with scope enforcement.

    All operations that touch entity paths are checked against the
    tenant context's scopes. Operations on unauthorized paths raise
    PermissionDenied.

    For list/search operations, results are automatically filtered
    to only include entries within readable scopes.
    """

    def __init__(self, memory: Any, ctx: TenantContext) -> None:
        self._memory = memory
        self._ctx = ctx

    @property
    def memory(self) -> Any:
        return self._memory

    @property
    def ctx(self) -> TenantContext:
        return self._ctx

    # ------------------------------------------------------------------
    # Standard memory operations (unchanged API, scope-checked)
    # ------------------------------------------------------------------

    def read(
        self,
        entity_path: str,
        key: str,
        *,
        min_confidence: float = 0.0,
    ) -> Any:
        """Read with scope check — requires READ permission on entity_path."""
        if not check_permission(self._ctx, entity_path, Permission.READ):
            raise PermissionDenied(entity_path, Permission.READ)
        return self._memory.read(entity_path, key, min_confidence=min_confidence)

    def write(
        self,
        entity_path: str,
        key: str,
        value: Any,
        **kwargs: Any,
    ) -> Any:
        """Write with scope check — requires WRITE permission on entity_path."""
        if not check_permission(self._ctx, entity_path, Permission.WRITE):
            raise PermissionDenied(entity_path, Permission.WRITE)
        return self._memory.write(entity_path, key, value, **kwargs)

    def list(
        self,
        entity_path: str | None = None,
        *,
        include_superseded: bool = False,
    ) -> list[Any]:
        """List with scope filtering.

        If entity_path is given, checks READ permission on it.
        If entity_path is None (list all), returns only entries within
        readable scopes.
        """
        if entity_path is not None:
            if not check_permission(self._ctx, entity_path, Permission.READ):
                raise PermissionDenied(entity_path, Permission.READ)
            return self._memory.list(entity_path, include_superseded=include_superseded)

        entries = self._memory.list(include_superseded=include_superseded)
        return [
            e for e in entries
            if check_permission(self._ctx, e.entity_path, Permission.READ)
        ]

    def search(
        self,
        query: str | None = None,
        *,
        entity_path: str | None = None,
        min_confidence: float = 0.0,
        **kwargs: Any,
    ) -> list[Any]:
        """Search with scope filtering — results are filtered to readable paths.

        If entity_path is given, checks READ permission first.
        """
        if entity_path is not None:
            if not check_permission(self._ctx, entity_path, Permission.READ):
                raise PermissionDenied(entity_path, Permission.READ)

        results = self._memory.search(
            query,
            entity_path=entity_path,
            min_confidence=min_confidence,
            **kwargs,
        ) if query else self._memory.list(entity_path)

        return [
            r for r in results
            if check_permission(self._ctx, getattr(r, "entity_path", ""), Permission.READ)
        ]

    def history(
        self,
        entity_path: str,
        key: str,
        *,
        since: datetime | None = None,
        until: datetime | None = None,
    ) -> list[Any]:
        """History with scope check — requires READ permission."""
        if not check_permission(self._ctx, entity_path, Permission.READ):
            raise PermissionDenied(entity_path, Permission.READ)
        return self._memory.history(entity_path, key, since=since, until=until)

    def explain(self, outcome_ref: str | None = None) -> dict[str, Any]:
        """Explain with scope filtering.

        The full causal chain is returned, but entries outside readable
        scopes are redacted (replaced with a minimal stub showing only
        entity_path and key, without the value).
        """
        result = self._memory.explain(outcome_ref)
        if "causal_entries" in result:
            filtered = []
            for entry in result["causal_entries"]:
                ep = entry.get("entity_path", "")
                if check_permission(self._ctx, ep, Permission.READ):
                    filtered.append(entry)
                else:
                    filtered.append({
                        "entity_path": ep,
                        "key": entry.get("key"),
                        "redacted": True,
                        "reason": "insufficient_scope",
                    })
            result["causal_entries"] = filtered
        return result

    def commit_outcome(
        self,
        outcome_ref: str,
        outcome_type: Any,
        causal_entry_keys: list[str] | None = None,
        *,
        causal_confidence: float = 1.0,
    ) -> list[Any]:
        """Commit outcome with scope filtering.

        If causal_entry_keys are provided, each must be within writable scope.
        If auto-derived from read tracker, filters to writable keys only.
        """
        if causal_entry_keys is not None:
            for ek in causal_entry_keys:
                parts = ek.rsplit("/", 1)
                if len(parts) == 2:
                    ep = parts[0]
                    if not check_permission(self._ctx, ep, Permission.WRITE):
                        raise PermissionDenied(ep, Permission.WRITE)

        return self._memory.commit_outcome(
            outcome_ref,
            outcome_type,
            causal_entry_keys,
            causal_confidence=causal_confidence,
        )

    def record_context(
        self,
        label: str,
        summary: str,
        *,
        source: str | None = None,
    ) -> None:
        """Record context — no scope check needed (it's metadata, not entity data)."""
        self._memory.record_context(label, summary, source=source)

    def stats(self) -> Any:
        """Stats — returns aggregate stats, but only from readable entities."""
        return self._memory.stats()

    # ------------------------------------------------------------------
    # Brain methods — agent-scoped views with visibility enforcement
    # ------------------------------------------------------------------

    def recall(
        self,
        entity_path: str,
        key: str,
        *,
        min_confidence: float = 0.0,
    ) -> Any:
        """Recall this agent's own memory at entity_path/key.

        Scope-checked but always allowed for own entries (same agent_id).
        """
        if not check_permission(self._ctx, entity_path, Permission.READ):
            raise PermissionDenied(entity_path, Permission.READ)
        return self._memory.recall(entity_path, key, min_confidence=min_confidence)

    def my_entries(
        self,
        entity_path: str | None = None,
    ) -> list[Any]:
        """List all entries written by the current agent.

        Filtered to readable scopes when entity_path is None.
        """
        if entity_path is not None:
            if not check_permission(self._ctx, entity_path, Permission.READ):
                raise PermissionDenied(entity_path, Permission.READ)

        entries = self._memory.my_entries(entity_path)
        if entity_path is None:
            entries = [
                e for e in entries
                if check_permission(self._ctx, e.entity_path, Permission.READ)
            ]
        return entries

    def read_from(
        self,
        agent_id: str,
        entity_path: str,
        key: str,
    ) -> Any:
        """Read a specific agent's memory entry — cross-agent with visibility check.

        Enforces:
        1. Scope permission (entity_path must be readable)
        2. Visibility policy (cross-team/namespace checks if source agent
           is on a different team or namespace)
        """
        if not check_permission(self._ctx, entity_path, Permission.READ):
            raise PermissionDenied(entity_path, Permission.READ)

        entry = self._memory.read_from(agent_id, entity_path, key)
        if entry is None:
            return None

        entry_team_id = getattr(entry, "team_id", None)
        entry_namespace = getattr(entry, "namespace", None)

        if not check_agent_visibility(
            self._ctx, agent_id, entry_team_id, entry_namespace, Permission.READ,
        ):
            raise VisibilityDenied(
                f"Cannot read from agent '{agent_id}': "
                f"cross-boundary access denied by visibility policy"
            )

        return entry

    def cross_agent_reads(self) -> list[dict[str, Any]]:
        """Return cross-agent read relationships, filtered by visibility."""
        if not hasattr(self._memory, "cross_agent_reads"):
            return []

        reads = self._memory.cross_agent_reads()
        return [
            r for r in reads
            if check_permission(
                self._ctx,
                r.get("entity_path", ""),
                Permission.READ,
            )
        ]
