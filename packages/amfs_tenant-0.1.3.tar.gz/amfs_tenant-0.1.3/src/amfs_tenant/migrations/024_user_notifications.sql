-- User notifications for negotiation events, agent engagement, etc.

CREATE TABLE IF NOT EXISTS user_notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL,
    user_id UUID NOT NULL,
    notification_type TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT,
    metadata JSONB NOT NULL DEFAULT '{}',
    room_id UUID,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_notifications_user_unread
    ON user_notifications(account_id, user_id, created_at DESC)
    WHERE read_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_user_notifications_user_all
    ON user_notifications(account_id, user_id, created_at DESC);

-- Prevent duplicate notifications per user per event
CREATE UNIQUE INDEX IF NOT EXISTS idx_user_notifications_dedup
    ON user_notifications(account_id, user_id, notification_type, (metadata->>'session_id'))
    WHERE metadata->>'session_id' IS NOT NULL;

ALTER TABLE user_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_notifications FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS user_notifications_tenant ON user_notifications;
CREATE POLICY user_notifications_tenant ON user_notifications
    USING (account_id::text = current_setting('amfs.current_account_id', true));
