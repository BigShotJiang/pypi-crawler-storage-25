-- AMFS Pro: RLS for decision traces, detected patterns, and immutable traces
-- These tables had account_id columns (from migration 002) but no RLS policies,
-- allowing potential cross-tenant reads.

-- ---------------------------------------------------------------------------
-- 1. Enable RLS on all three tables
-- ---------------------------------------------------------------------------

ALTER TABLE amfs_decision_traces ENABLE ROW LEVEL SECURITY;
ALTER TABLE amfs_detected_patterns ENABLE ROW LEVEL SECURITY;
ALTER TABLE amfs_decision_traces FORCE ROW LEVEL SECURITY;
ALTER TABLE amfs_detected_patterns FORCE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.tables
        WHERE table_name = 'amfs_immutable_traces'
    ) THEN
        EXECUTE 'ALTER TABLE amfs_immutable_traces ENABLE ROW LEVEL SECURITY';
        EXECUTE 'ALTER TABLE amfs_immutable_traces FORCE ROW LEVEL SECURITY';
    END IF;
END $$;

-- ---------------------------------------------------------------------------
-- 2. Create tenant isolation policies
-- ---------------------------------------------------------------------------

DROP POLICY IF EXISTS tenant_isolation_traces ON amfs_decision_traces;
CREATE POLICY tenant_isolation_traces ON amfs_decision_traces
    USING (account_id = current_setting('amfs.current_account_id', true)::uuid);

DROP POLICY IF EXISTS tenant_isolation_patterns ON amfs_detected_patterns;
CREATE POLICY tenant_isolation_patterns ON amfs_detected_patterns
    USING (account_id = current_setting('amfs.current_account_id', true)::uuid);

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.tables
        WHERE table_name = 'amfs_immutable_traces'
    ) THEN
        EXECUTE 'DROP POLICY IF EXISTS tenant_isolation_immutable_traces ON amfs_immutable_traces';
        EXECUTE $p$CREATE POLICY tenant_isolation_immutable_traces ON amfs_immutable_traces
            USING (account_id = current_setting('amfs.current_account_id', true)::uuid)$p$;
    END IF;
END $$;

-- ---------------------------------------------------------------------------
-- 3. Add account_id defaults (auto-inherit from session variable on INSERT)
-- ---------------------------------------------------------------------------

ALTER TABLE amfs_decision_traces
    ALTER COLUMN account_id SET DEFAULT current_setting('amfs.current_account_id', true)::uuid;

ALTER TABLE amfs_detected_patterns
    ALTER COLUMN account_id SET DEFAULT current_setting('amfs.current_account_id', true)::uuid;

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.tables
        WHERE table_name = 'amfs_immutable_traces'
    ) THEN
        EXECUTE $a$ALTER TABLE amfs_immutable_traces
            ALTER COLUMN account_id SET DEFAULT current_setting('amfs.current_account_id', true)::uuid$a$;
    END IF;
END $$;
