-- =========================================================================
-- Migration 021: Fix room_snapshots FK to cascade on room deletion
-- =========================================================================
-- room_snapshots.room_id was missing ON DELETE CASCADE, which would block
-- room deletion.  The actual snapshot data lives in amfs_memory_entries
-- (at {agent_id}/rooms/{entity_path}), so the metadata row can safely
-- cascade-delete with the room.
-- =========================================================================

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_name = 'room_snapshots_room_id_fkey'
          AND table_name = 'room_snapshots'
    ) THEN
        ALTER TABLE room_snapshots DROP CONSTRAINT room_snapshots_room_id_fkey;
    END IF;
END $$;

ALTER TABLE room_snapshots
    ADD CONSTRAINT room_snapshots_room_id_fkey
    FOREIGN KEY (room_id) REFERENCES entity_rooms(id) ON DELETE CASCADE;
