-- Fix: team slug uniqueness must be scoped per account (multi-tenant).
-- The OSS schema defines UNIQUE(namespace, slug) which is global.
-- Replace with UNIQUE(account_id, namespace, slug) so different tenants
-- can have teams with the same slug.

ALTER TABLE amfs_teams DROP CONSTRAINT IF EXISTS uq_team_slug;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'uq_team_slug_account'
    ) THEN
        ALTER TABLE amfs_teams
            ADD CONSTRAINT uq_team_slug_account UNIQUE (account_id, namespace, slug);
    END IF;
END
$$;
