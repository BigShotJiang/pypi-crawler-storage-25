-- AMFS Pro: Multi-Tenant Schema
-- Adds account isolation (RLS), users, API keys with scoped permissions,
-- and an append-only audit log.
--
-- Prerequisites: the OSS amfs_memory_entries and amfs_outcomes tables must
-- already exist (from amfs-adapter-postgres schema.sql).

-- =========================================================================
-- 1. Accounts (tenants)
-- =========================================================================

CREATE TABLE IF NOT EXISTS accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    plan_tier TEXT NOT NULL DEFAULT 'starter'
        CHECK (plan_tier IN ('starter', 'team', 'enterprise')),
    max_entries INT NOT NULL DEFAULT 10000,
    max_api_keys INT NOT NULL DEFAULT 5,
    max_users INT NOT NULL DEFAULT 3,
    settings JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =========================================================================
-- 2. Users (human, dashboard access)
-- =========================================================================

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    name TEXT,
    role TEXT NOT NULL DEFAULT 'user'
        CHECK (role IN ('admin', 'developer', 'user')),
    idp_subject TEXT,
    idp_provider TEXT,
    mfa_enabled BOOLEAN NOT NULL DEFAULT false,
    last_login TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (account_id, email)
);

CREATE INDEX IF NOT EXISTS idx_users_account ON users (account_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);

-- =========================================================================
-- 3. API Keys (agents, ingestion tools, admin scripts)
-- =========================================================================

CREATE TABLE IF NOT EXISTS api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    created_by UUID NOT NULL REFERENCES users(id),
    name TEXT NOT NULL,
    key_hash TEXT NOT NULL UNIQUE,
    key_prefix TEXT NOT NULL,
    key_type TEXT NOT NULL DEFAULT 'agent'
        CHECK (key_type IN ('agent', 'ingestion', 'readonly', 'admin')),
    active BOOLEAN NOT NULL DEFAULT true,
    expires_at TIMESTAMPTZ,
    rate_limit_rpm INT NOT NULL DEFAULT 60,
    last_used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_apikeys_account ON api_keys (account_id);
CREATE INDEX IF NOT EXISTS idx_apikeys_hash ON api_keys (key_hash);
CREATE INDEX IF NOT EXISTS idx_apikeys_prefix ON api_keys (key_prefix);

-- =========================================================================
-- 4. API Key Scopes (entity-path-level permissions)
-- =========================================================================

CREATE TABLE IF NOT EXISTS api_key_scopes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    api_key_id UUID NOT NULL REFERENCES api_keys(id) ON DELETE CASCADE,
    entity_path_pattern TEXT NOT NULL,
    permission TEXT NOT NULL DEFAULT 'read_write'
        CHECK (permission IN ('read', 'write', 'read_write'))
);

CREATE INDEX IF NOT EXISTS idx_scopes_key ON api_key_scopes (api_key_id);

-- =========================================================================
-- 5. Audit Log (append-only)
-- =========================================================================

CREATE TABLE IF NOT EXISTS audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL,
    actor_id UUID NOT NULL,
    actor_type TEXT NOT NULL CHECK (actor_type IN ('user', 'api_key', 'system')),
    action TEXT NOT NULL,
    resource TEXT,
    details JSONB,
    ip_address INET,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_account_time
    ON audit_log (account_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action
    ON audit_log (account_id, action);

-- =========================================================================
-- 6. Add account_id to existing AMFS tables
-- =========================================================================

-- Memory entries: add account_id column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_memory_entries' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_memory_entries
            ADD COLUMN account_id UUID REFERENCES accounts(id);

        CREATE INDEX idx_entries_account
            ON amfs_memory_entries (account_id);
    END IF;
END $$;

-- Outcomes: add account_id column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_outcomes' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_outcomes
            ADD COLUMN account_id UUID REFERENCES accounts(id);

        CREATE INDEX idx_outcomes_account
            ON amfs_outcomes (account_id);
    END IF;
END $$;

-- =========================================================================
-- 7. Row-Level Security (RLS) — hard tenant isolation
-- =========================================================================
-- The application sets `amfs.current_account_id` on every connection.
-- Even if application code has a bug, the database itself prevents
-- cross-tenant data access.

ALTER TABLE amfs_memory_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE amfs_outcomes ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_key_scopes ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

-- FORCE RLS even for the table owner (the app connects as the owner).
-- Without this, the amfs user bypasses all policies.
-- NOTE: users table is NOT forced — auth queries (login, session check)
-- must search by email across all accounts before account_id is known.
ALTER TABLE amfs_memory_entries FORCE ROW LEVEL SECURITY;
ALTER TABLE amfs_outcomes FORCE ROW LEVEL SECURITY;
ALTER TABLE api_keys FORCE ROW LEVEL SECURITY;
ALTER TABLE api_key_scopes FORCE ROW LEVEL SECURITY;
ALTER TABLE audit_log FORCE ROW LEVEL SECURITY;

-- Policies: rows are only visible when account_id matches the session var.
-- Only true superusers (not the app role) bypass RLS.
-- DROP IF EXISTS keeps CI / re-runs idempotent (CREATE POLICY is not IF NOT EXISTS on all versions).

DROP POLICY IF EXISTS tenant_isolation_entries ON amfs_memory_entries;
CREATE POLICY tenant_isolation_entries ON amfs_memory_entries
    USING (account_id = current_setting('amfs.current_account_id', true)::uuid);

DROP POLICY IF EXISTS tenant_isolation_outcomes ON amfs_outcomes;
CREATE POLICY tenant_isolation_outcomes ON amfs_outcomes
    USING (account_id = current_setting('amfs.current_account_id', true)::uuid);

DROP POLICY IF EXISTS tenant_isolation_users ON users;
CREATE POLICY tenant_isolation_users ON users
    USING (account_id = current_setting('amfs.current_account_id', true)::uuid);

DROP POLICY IF EXISTS tenant_isolation_apikeys ON api_keys;
CREATE POLICY tenant_isolation_apikeys ON api_keys
    USING (account_id = current_setting('amfs.current_account_id', true)::uuid);

DROP POLICY IF EXISTS tenant_isolation_scopes ON api_key_scopes;
CREATE POLICY tenant_isolation_scopes ON api_key_scopes
    USING (api_key_id IN (
        SELECT id FROM api_keys
        WHERE account_id = current_setting('amfs.current_account_id', true)::uuid
    ));

DROP POLICY IF EXISTS tenant_isolation_audit ON audit_log;
CREATE POLICY tenant_isolation_audit ON audit_log
    USING (account_id = current_setting('amfs.current_account_id', true)::uuid);

-- =========================================================================
-- 8. Update the outcome propagation trigger for multi-tenant
-- =========================================================================
-- The original trigger references namespace; we also propagate account_id
-- so new versions inherit tenant context.

CREATE OR REPLACE FUNCTION amfs_propagate_outcome() RETURNS TRIGGER AS $$
DECLARE
    multiplier NUMERIC;
    entry_key TEXT;
    parts TEXT[];
    ep TEXT;
    k TEXT;
    cur RECORD;
BEGIN
    CASE NEW.outcome_type
        WHEN 'critical_failure' THEN multiplier := 1.15;
        WHEN 'failure' THEN multiplier := 1.10;
        WHEN 'minor_failure' THEN multiplier := 1.08;
        WHEN 'success' THEN multiplier := 0.97;
        WHEN 'p1_incident' THEN multiplier := 1.15;
        WHEN 'p2_incident' THEN multiplier := 1.10;
        WHEN 'regression' THEN multiplier := 1.08;
        WHEN 'clean_deploy' THEN multiplier := 0.97;
        ELSE multiplier := 1.0;
    END CASE;

    FOREACH entry_key IN ARRAY NEW.causal_entry_keys
    LOOP
        IF position('/' in entry_key) = 0 THEN
            CONTINUE;
        END IF;
        k := substring(entry_key from '([^/]+)$');
        ep := left(entry_key, length(entry_key) - length(k) - 1);

        SELECT * INTO cur FROM amfs_memory_entries
        WHERE namespace = NEW.namespace
          AND entity_path = ep
          AND key = k
          AND superseded_at IS NULL
          AND (account_id = NEW.account_id OR NEW.account_id IS NULL)
        ORDER BY version DESC LIMIT 1;

        IF FOUND THEN
            UPDATE amfs_memory_entries
            SET superseded_at = NOW()
            WHERE id = cur.id;

            INSERT INTO amfs_memory_entries (
                namespace, entity_path, key, version, value,
                agent_id, session_id, written_at, pattern_refs,
                confidence, outcome_count, ttl_at, memory_type,
                artifact_refs, account_id
            ) VALUES (
                cur.namespace, cur.entity_path, cur.key, cur.version + 1, cur.value,
                cur.agent_id, cur.session_id, cur.written_at, cur.pattern_refs,
                cur.confidence * multiplier * NEW.causal_confidence,
                cur.outcome_count + 1, cur.ttl_at, cur.memory_type,
                cur.artifact_refs, cur.account_id
            );
        END IF;
    END LOOP;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
