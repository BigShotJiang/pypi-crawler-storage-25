-- 011: Add plan lifecycle + profile columns for onboarding flow.
--
-- Enables the onboarding gate: new accounts start with plan_status='pending_plan'
-- and must complete a two-step onboarding (profile → plan selection) before
-- accessing the dashboard. Existing accounts are backfilled to 'active'.

-- Plan lifecycle on accounts.
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS plan_status TEXT
    NOT NULL DEFAULT 'pending_plan'
    CHECK (plan_status IN ('pending_plan', 'active', 'suspended'));

ALTER TABLE accounts ADD COLUMN IF NOT EXISTS plan_resolved_at TIMESTAMPTZ;

ALTER TABLE accounts ADD COLUMN IF NOT EXISTS stripe_customer_id TEXT;

-- Company name collected during onboarding step 1.
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS company_name TEXT;

-- Profile fields collected during onboarding step 1.
ALTER TABLE users ADD COLUMN IF NOT EXISTS first_name TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_name TEXT;

-- Backfill existing accounts to 'active' so current users are not affected.
UPDATE accounts
SET plan_status = 'active', plan_resolved_at = now()
WHERE plan_resolved_at IS NULL;
