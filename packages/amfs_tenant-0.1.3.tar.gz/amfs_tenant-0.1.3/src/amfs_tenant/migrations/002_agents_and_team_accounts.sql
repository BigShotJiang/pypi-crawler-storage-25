-- AMFS Pro: Agent Registration & Team-Account Linking
-- Adds registered agents within accounts/teams, and links the
-- OSS amfs_teams table to the Pro accounts table.

-- =========================================================================
-- 1. Link teams to accounts
-- =========================================================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_teams' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_teams
            ADD COLUMN account_id UUID REFERENCES accounts(id);

        CREATE INDEX idx_amfs_teams_account
            ON amfs_teams (account_id);
    END IF;
END $$;

-- =========================================================================
-- 2. Registered agents
-- =========================================================================

CREATE TABLE IF NOT EXISTS agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    team_id UUID REFERENCES amfs_teams(id) ON DELETE SET NULL,
    agent_id TEXT NOT NULL,
    namespace TEXT NOT NULL DEFAULT 'default',
    display_name TEXT,
    description TEXT,
    config JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at TIMESTAMPTZ,
    UNIQUE (account_id, namespace, agent_id)
);

CREATE INDEX IF NOT EXISTS idx_agents_account ON agents (account_id);
CREATE INDEX IF NOT EXISTS idx_agents_team ON agents (team_id);
CREATE INDEX IF NOT EXISTS idx_agents_agent_id ON agents (agent_id);

-- =========================================================================
-- 3. RLS on agents
-- =========================================================================

ALTER TABLE agents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS tenant_isolation_agents ON agents;
CREATE POLICY tenant_isolation_agents ON agents
    USING (account_id = current_setting('amfs.current_account_id', true)::uuid);

-- =========================================================================
-- 4. Add account_id to remaining AMFS tables if missing
-- =========================================================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_decision_traces' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_decision_traces
            ADD COLUMN account_id UUID REFERENCES accounts(id);
        CREATE INDEX idx_traces_account ON amfs_decision_traces (account_id);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_detected_patterns' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_detected_patterns
            ADD COLUMN account_id UUID REFERENCES accounts(id);
        CREATE INDEX idx_patterns_account ON amfs_detected_patterns (account_id);
    END IF;
END $$;
