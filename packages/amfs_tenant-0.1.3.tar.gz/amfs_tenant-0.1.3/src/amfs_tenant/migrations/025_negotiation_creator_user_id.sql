-- Track which user_id created each negotiation session.
-- This allows the dashboard to restrict actions (e.g. cancel) to the creator.

ALTER TABLE negotiation_sessions
    ADD COLUMN IF NOT EXISTS created_by_user_id UUID REFERENCES users(id);

CREATE INDEX IF NOT EXISTS idx_neg_sessions_creator_user
    ON negotiation_sessions(created_by_user_id);
