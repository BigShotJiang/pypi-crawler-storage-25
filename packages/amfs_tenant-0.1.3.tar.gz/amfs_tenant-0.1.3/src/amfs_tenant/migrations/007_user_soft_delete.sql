-- AMFS Pro: Soft-delete for users
-- When a user is deleted from the platform, we keep the row with deleted_at set.
-- This prevents re-authentication and blocks new signups with the same email.

ALTER TABLE users ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Update the staff list function to exclude soft-deleted users
CREATE OR REPLACE FUNCTION amfs_staff_list_users()
RETURNS TABLE (
    user_id UUID,
    account_id UUID,
    email TEXT,
    name TEXT,
    role TEXT,
    created_at TIMESTAMPTZ,
    last_login TIMESTAMPTZ,
    account_name TEXT,
    account_slug TEXT
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT
        u.id,
        u.account_id,
        u.email,
        u.name,
        u.role::text,
        u.created_at,
        u.last_login,
        a.name,
        a.slug
    FROM users u
    JOIN accounts a ON a.id = u.account_id
    WHERE u.deleted_at IS NULL
    ORDER BY u.created_at DESC;
$$;
