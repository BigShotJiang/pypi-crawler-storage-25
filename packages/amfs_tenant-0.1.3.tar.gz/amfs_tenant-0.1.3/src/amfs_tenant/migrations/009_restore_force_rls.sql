-- 009: Restore FORCE ROW LEVEL SECURITY on core data tables.
--
-- Migration 006 reverted FORCE RLS under the assumption that standard
-- RLS is enough.  That assumption was wrong: the application connects
-- as the table owner (`amfs`), and Postgres skips RLS entirely for
-- table owners unless FORCE is set.  This means any authenticated
-- request returns ALL rows across ALL tenants.
--
-- The concern in 006 (OSS handler using a separate pool that doesn't
-- set amfs.current_account_id) is addressed by the _TenantRLSPoolWrapper
-- in amfs_postgres and the _dashboard_tenant_middleware / _pro_scope_middleware
-- which both set the thread-local before the handler runs.
--
-- Tables already forced by 008 (amfs_decision_traces, amfs_detected_patterns)
-- are re-stated here for completeness / idempotency.

ALTER TABLE amfs_memory_entries FORCE ROW LEVEL SECURITY;
ALTER TABLE amfs_outcomes FORCE ROW LEVEL SECURITY;
ALTER TABLE audit_log FORCE ROW LEVEL SECURITY;
ALTER TABLE amfs_decision_traces FORCE ROW LEVEL SECURITY;
ALTER TABLE amfs_detected_patterns FORCE ROW LEVEL SECURITY;

-- Also force on teams/members — these hold namespace-scoped data
-- that should respect tenant boundaries.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_teams' AND column_name = 'account_id'
    ) THEN
        EXECUTE 'ALTER TABLE amfs_teams FORCE ROW LEVEL SECURITY';
    END IF;

    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_team_members' AND column_name = 'account_id'
    ) THEN
        EXECUTE 'ALTER TABLE amfs_team_members FORCE ROW LEVEL SECURITY';
    END IF;
END $$;

-- Immutable traces (if the table exists from Pro traces package)
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.tables
        WHERE table_name = 'amfs_immutable_traces'
    ) THEN
        EXECUTE 'ALTER TABLE amfs_immutable_traces FORCE ROW LEVEL SECURITY';
    END IF;
END $$;
