-- 012: Ensure NOTIFY triggers exist for CortexWorker.
--
-- These triggers fire pg_notify() on writes, outcomes, and digest changes.
-- The CortexWorker listens on these channels to recompile digests.
-- They may have been dropped during schema reapplication or migrations.

-- 1. NOTIFY on new memory writes
CREATE OR REPLACE FUNCTION amfs_notify_write() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.superseded_at IS NULL THEN
        PERFORM pg_notify('amfs_write', json_build_object(
            'namespace', NEW.namespace,
            'entity_path', NEW.entity_path,
            'key', NEW.key,
            'version', NEW.version,
            'agent_id', NEW.agent_id,
            'branch', NEW.branch
        )::TEXT);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_notify_write ON amfs_memory_entries;
CREATE TRIGGER trg_notify_write
    AFTER INSERT ON amfs_memory_entries
    FOR EACH ROW EXECUTE FUNCTION amfs_notify_write();

-- 2. NOTIFY on digest compilation
CREATE OR REPLACE FUNCTION amfs_notify_digest() RETURNS TRIGGER AS $$
BEGIN
    PERFORM pg_notify('amfs_digest', json_build_object(
        'namespace', NEW.namespace,
        'digest_type', NEW.digest_type,
        'scope', NEW.scope
    )::TEXT);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_notify_digest ON amfs_digests;
CREATE TRIGGER trg_notify_digest
    AFTER INSERT OR UPDATE ON amfs_digests
    FOR EACH ROW EXECUTE FUNCTION amfs_notify_digest();
