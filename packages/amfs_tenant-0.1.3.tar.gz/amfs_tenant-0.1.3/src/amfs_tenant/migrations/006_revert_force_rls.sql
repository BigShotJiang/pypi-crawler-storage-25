-- 006: Revert FORCE ROW LEVEL SECURITY from data tables.
--
-- FORCE RLS causes every query to go through RLS even as table owner.
-- The Pro middleware sets amfs.current_account_id on its OWN connection,
-- but the OSS request handler uses a separate connection pool that
-- never sets this variable.  With FORCE RLS, those handler queries
-- evaluate the policy with NULL, causing requests to hang or return
-- empty results.
--
-- Standard RLS (without FORCE) still applies to non-owner roles, which
-- is sufficient for tenant isolation.  The middleware + DEFAULT on
-- account_id already ensure correct tenant tagging on writes.

ALTER TABLE amfs_memory_entries NO FORCE ROW LEVEL SECURITY;
ALTER TABLE amfs_outcomes NO FORCE ROW LEVEL SECURITY;
ALTER TABLE audit_log NO FORCE ROW LEVEL SECURITY;
