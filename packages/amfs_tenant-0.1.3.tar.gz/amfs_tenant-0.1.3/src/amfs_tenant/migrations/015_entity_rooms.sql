-- =========================================================================
-- Migration 015: Entity Rooms + Agent User Ownership
-- =========================================================================
-- Adds collaborative "rooms" on top of AMFS entities, plus user-level
-- agent ownership for cross-user isolation (agents from different users
-- can only interact through rooms).
--
-- Tables created:
--   entity_rooms          -- Room metadata per entity
--   room_user_invites     -- User-level invitations (users invite users)
--   room_memberships      -- Agent-level membership (agents join rooms)
--   room_activity         -- Append-only room activity log
--   room_snapshots        -- Snapshots taken when a room is closed
--
-- Also adds:
--   agents.owner_user_id  -- Links each agent to the user who created the
--                            API key it authenticated with
-- =========================================================================


-- =========================================================================
-- 1. Agent user ownership
-- =========================================================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'agents' AND column_name = 'owner_user_id'
    ) THEN
        ALTER TABLE agents
            ADD COLUMN owner_user_id UUID REFERENCES users(id);

        -- Backfill from the API key creator. For agents that predate this
        -- migration we pick the key creator in the same account, falling
        -- back to the account admin.
        UPDATE agents a
        SET owner_user_id = COALESCE(
            (SELECT ak.created_by FROM api_keys ak
             WHERE ak.account_id = a.account_id
             ORDER BY ak.created_at ASC LIMIT 1),
            (SELECT u.id FROM users u
             WHERE u.account_id = a.account_id AND u.role = 'admin'
             ORDER BY u.created_at ASC LIMIT 1)
        )
        WHERE a.owner_user_id IS NULL;

        ALTER TABLE agents
            ALTER COLUMN owner_user_id SET NOT NULL;

        CREATE INDEX idx_agents_owner_user ON agents(owner_user_id);
    END IF;
END $$;


-- =========================================================================
-- 2. Entity rooms
-- =========================================================================

CREATE TABLE IF NOT EXISTS entity_rooms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    entity_path TEXT NOT NULL,
    namespace TEXT NOT NULL DEFAULT 'default',
    display_name TEXT,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'open'
        CHECK (status IN ('open', 'closed')),
    discussions_enabled BOOLEAN NOT NULL DEFAULT false,
    settings JSONB NOT NULL DEFAULT '{}',
    created_by UUID NOT NULL REFERENCES users(id),
    closed_at TIMESTAMPTZ,
    closed_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (account_id, namespace, entity_path)
);

CREATE INDEX IF NOT EXISTS idx_entity_rooms_account ON entity_rooms(account_id);
CREATE INDEX IF NOT EXISTS idx_entity_rooms_entity ON entity_rooms(account_id, entity_path);
CREATE INDEX IF NOT EXISTS idx_entity_rooms_created_by ON entity_rooms(created_by);


-- =========================================================================
-- 3. User-level invitations (users invite users, not agents)
-- =========================================================================

CREATE TABLE IF NOT EXISTS room_user_invites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES entity_rooms(id) ON DELETE CASCADE,
    account_id UUID NOT NULL REFERENCES accounts(id),
    invited_user_id UUID NOT NULL REFERENCES users(id),
    invited_by UUID NOT NULL REFERENCES users(id),
    role TEXT NOT NULL DEFAULT 'collaborator'
        CHECK (role IN ('collaborator', 'viewer')),
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'accepted', 'declined', 'revoked')),
    accepted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (room_id, invited_user_id)
);

CREATE INDEX IF NOT EXISTS idx_room_invites_room ON room_user_invites(room_id);
CREATE INDEX IF NOT EXISTS idx_room_invites_user ON room_user_invites(invited_user_id);
CREATE INDEX IF NOT EXISTS idx_room_invites_account ON room_user_invites(account_id);


-- =========================================================================
-- 4. Agent-level membership (agents join after their user is invited)
-- =========================================================================

CREATE TABLE IF NOT EXISTS room_memberships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES entity_rooms(id) ON DELETE CASCADE,
    invite_id UUID NOT NULL REFERENCES room_user_invites(id),
    agent_id TEXT NOT NULL,
    owner_user_id UUID NOT NULL REFERENCES users(id),
    role TEXT NOT NULL DEFAULT 'member'
        CHECK (role IN ('member', 'viewer')),
    briefing_delivered BOOLEAN NOT NULL DEFAULT false,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    left_at TIMESTAMPTZ,
    UNIQUE (room_id, agent_id)
);

CREATE INDEX IF NOT EXISTS idx_room_memberships_room ON room_memberships(room_id);
CREATE INDEX IF NOT EXISTS idx_room_memberships_agent ON room_memberships(agent_id);
CREATE INDEX IF NOT EXISTS idx_room_memberships_user ON room_memberships(owner_user_id);


-- =========================================================================
-- 5. Room activity log (append-only)
-- =========================================================================

CREATE TABLE IF NOT EXISTS room_activity (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES entity_rooms(id) ON DELETE CASCADE,
    account_id UUID NOT NULL,
    agent_id TEXT,
    user_id UUID REFERENCES users(id),
    activity_type TEXT NOT NULL
        CHECK (activity_type IN (
            'room_created', 'room_closed',
            'user_invited', 'user_accepted', 'user_removed',
            'agent_joined', 'agent_left',
            'write', 'read',
            'discussion_message',
            'negotiation_started', 'negotiation_round',
            'negotiation_consensus', 'negotiation_failed',
            'briefing_delivered', 'synthesis_completed',
            'extraction_completed'
        )),
    details JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_room_activity_room ON room_activity(room_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_room_activity_agent ON room_activity(agent_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_room_activity_account ON room_activity(account_id);
CREATE INDEX IF NOT EXISTS idx_room_activity_type ON room_activity(room_id, activity_type);


-- =========================================================================
-- 6. Room snapshots (created when a room is closed)
-- =========================================================================

CREATE TABLE IF NOT EXISTS room_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES entity_rooms(id),
    agent_id TEXT NOT NULL,
    snapshot_entity_path TEXT NOT NULL,
    entry_count INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_room_snapshots_room ON room_snapshots(room_id);
CREATE INDEX IF NOT EXISTS idx_room_snapshots_agent ON room_snapshots(agent_id);


-- =========================================================================
-- 7. Row-Level Security
-- =========================================================================
-- All room tables use account_id isolation matching the existing pattern.
-- The NULLIF wrapper handles empty-string edge cases (see migration 014).

ALTER TABLE entity_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE entity_rooms FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS tenant_isolation_entity_rooms ON entity_rooms;
CREATE POLICY tenant_isolation_entity_rooms ON entity_rooms
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);

ALTER TABLE room_user_invites ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_user_invites FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS tenant_isolation_room_invites ON room_user_invites;
CREATE POLICY tenant_isolation_room_invites ON room_user_invites
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);

-- room_memberships doesn't have account_id directly; join through entity_rooms
ALTER TABLE room_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_memberships FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS tenant_isolation_room_memberships ON room_memberships;
CREATE POLICY tenant_isolation_room_memberships ON room_memberships
    USING (room_id IN (
        SELECT id FROM entity_rooms
        WHERE account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    ));

ALTER TABLE room_activity ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_activity FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS tenant_isolation_room_activity ON room_activity;
CREATE POLICY tenant_isolation_room_activity ON room_activity
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);

ALTER TABLE room_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_snapshots FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS tenant_isolation_room_snapshots ON room_snapshots;
CREATE POLICY tenant_isolation_room_snapshots ON room_snapshots
    USING (room_id IN (
        SELECT id FROM entity_rooms
        WHERE account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    ));


-- =========================================================================
-- 8. Helper function: check if an agent is an active member of a room
-- =========================================================================

CREATE OR REPLACE FUNCTION is_room_member(
    p_room_id UUID,
    p_agent_id TEXT
) RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM room_memberships
        WHERE room_id = p_room_id
          AND agent_id = p_agent_id
          AND left_at IS NULL
    );
END;
$$ LANGUAGE plpgsql STABLE;


-- =========================================================================
-- 9. Helper function: get rooms an agent is a member of with entity paths
-- =========================================================================

CREATE OR REPLACE FUNCTION get_agent_room_entity_paths(
    p_agent_id TEXT
) RETURNS TABLE (
    room_id UUID,
    entity_path TEXT,
    member_agent_ids TEXT[]
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        er.id AS room_id,
        er.entity_path,
        array_agg(DISTINCT rm2.agent_id) AS member_agent_ids
    FROM room_memberships rm
    JOIN entity_rooms er ON er.id = rm.room_id
    JOIN room_memberships rm2 ON rm2.room_id = er.id AND rm2.left_at IS NULL
    WHERE rm.agent_id = p_agent_id
      AND rm.left_at IS NULL
      AND er.status = 'open'
    GROUP BY er.id, er.entity_path;
END;
$$ LANGUAGE plpgsql STABLE;


-- =========================================================================
-- 10. updated_at trigger for entity_rooms
-- =========================================================================

CREATE OR REPLACE FUNCTION update_entity_rooms_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_entity_rooms_updated_at ON entity_rooms;
CREATE TRIGGER trg_entity_rooms_updated_at
    BEFORE UPDATE ON entity_rooms
    FOR EACH ROW
    EXECUTE FUNCTION update_entity_rooms_updated_at();
