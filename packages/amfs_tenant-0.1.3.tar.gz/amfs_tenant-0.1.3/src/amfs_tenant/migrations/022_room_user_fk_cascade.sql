-- =========================================================================
-- Migration 022: Add ON DELETE CASCADE/SET NULL to room FK refs to users
-- =========================================================================
-- The room tables (015_entity_rooms) reference users(id) without CASCADE.
-- When a user is deleted (staff panel, account purge, re-registration),
-- these FKs block the DELETE. PostgreSQL CASCADE operations are internal
-- and bypass RLS, which is critical since cross-account room invites are
-- invisible to the deleting account's RLS context.
-- =========================================================================

-- 1. room_memberships.invite_id → room_user_invites(id)
--    Must be CASCADE so deleting an invite cascades to its memberships.
ALTER TABLE room_memberships DROP CONSTRAINT IF EXISTS room_memberships_invite_id_fkey;
ALTER TABLE room_memberships
    ADD CONSTRAINT room_memberships_invite_id_fkey
    FOREIGN KEY (invite_id) REFERENCES room_user_invites(id) ON DELETE CASCADE;

-- 2. room_user_invites.invited_user_id → users(id)
--    Deleting a user removes all invites TO that user.
ALTER TABLE room_user_invites DROP CONSTRAINT IF EXISTS room_user_invites_invited_user_id_fkey;
ALTER TABLE room_user_invites
    ADD CONSTRAINT room_user_invites_invited_user_id_fkey
    FOREIGN KEY (invited_user_id) REFERENCES users(id) ON DELETE CASCADE;

-- 3. room_user_invites.invited_by → users(id)
--    Invites sent by a deleted user should survive (the invite is still
--    valid for the recipient). Make nullable and SET NULL on delete.
ALTER TABLE room_user_invites ALTER COLUMN invited_by DROP NOT NULL;
ALTER TABLE room_user_invites DROP CONSTRAINT IF EXISTS room_user_invites_invited_by_fkey;
ALTER TABLE room_user_invites
    ADD CONSTRAINT room_user_invites_invited_by_fkey
    FOREIGN KEY (invited_by) REFERENCES users(id) ON DELETE SET NULL;

-- 4. room_memberships.owner_user_id → users(id)
--    Deleting a user removes their agent memberships.
ALTER TABLE room_memberships DROP CONSTRAINT IF EXISTS room_memberships_owner_user_id_fkey;
ALTER TABLE room_memberships
    ADD CONSTRAINT room_memberships_owner_user_id_fkey
    FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE;

-- 5. entity_rooms.created_by → users(id)
--    Rooms should survive when their creator is deleted (other users may
--    still use them). Make nullable and SET NULL.
ALTER TABLE entity_rooms ALTER COLUMN created_by DROP NOT NULL;
ALTER TABLE entity_rooms DROP CONSTRAINT IF EXISTS entity_rooms_created_by_fkey;
ALTER TABLE entity_rooms
    ADD CONSTRAINT entity_rooms_created_by_fkey
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;

-- 6. entity_rooms.closed_by → users(id)
--    Already nullable. Just fix the cascade behavior.
ALTER TABLE entity_rooms DROP CONSTRAINT IF EXISTS entity_rooms_closed_by_fkey;
ALTER TABLE entity_rooms
    ADD CONSTRAINT entity_rooms_closed_by_fkey
    FOREIGN KEY (closed_by) REFERENCES users(id) ON DELETE SET NULL;

-- 7. room_activity.user_id → users(id)
--    Already nullable. Activity log entries survive user deletion.
ALTER TABLE room_activity DROP CONSTRAINT IF EXISTS room_activity_user_id_fkey;
ALTER TABLE room_activity
    ADD CONSTRAINT room_activity_user_id_fkey
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;

-- 8. agents.owner_user_id → users(id)
--    Agents can't function without a user — cascade delete.
ALTER TABLE agents DROP CONSTRAINT IF EXISTS agents_owner_user_id_fkey;
ALTER TABLE agents
    ADD CONSTRAINT agents_owner_user_id_fkey
    FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE;
