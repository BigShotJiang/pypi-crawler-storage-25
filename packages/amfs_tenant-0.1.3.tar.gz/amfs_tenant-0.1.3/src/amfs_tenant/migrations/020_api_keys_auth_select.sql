-- Migration 020: Add permissive auth-select policy on api_keys
--
-- The api_keys table has FORCE ROW LEVEL SECURITY (migration 001) but only
-- has a tenant_isolation_apikeys policy requiring amfs.current_account_id.
-- authenticate_api_key() needs to look up keys by prefix BEFORE the tenant
-- is known. Without a permissive SELECT policy, all key lookups fail when
-- the GUC is empty (e.g. in pro-api trace handlers).
--
-- This mirrors migration 010 which added the same pattern for amfs_api_keys.

DROP POLICY IF EXISTS api_keys_auth_select ON api_keys;
DROP POLICY IF EXISTS api_keys_tenant_modify ON api_keys;
DROP POLICY IF EXISTS tenant_isolation_apikeys ON api_keys;

-- Auth select: allows unauthenticated reads for key lookup (account_id may be NULL/empty)
-- plus tenant-scoped reads when a GUC is set.
CREATE POLICY api_keys_auth_select ON api_keys
    FOR SELECT
    USING (
        current_setting('amfs.current_account_id', true) IS NULL
        OR current_setting('amfs.current_account_id', true) = ''
        OR account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    );

-- Writes still require tenant context.
CREATE POLICY api_keys_tenant_modify ON api_keys
    FOR ALL
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid)
    WITH CHECK (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);
