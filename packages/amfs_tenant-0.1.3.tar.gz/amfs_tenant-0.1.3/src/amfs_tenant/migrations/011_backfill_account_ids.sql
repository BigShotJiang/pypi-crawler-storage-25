-- =========================================================================
-- Migration 011: Backfill account_id on tables that were missing it
-- =========================================================================
-- MUST BE RUN AS A SUPERUSER (e.g. `postgres` role on Cloud SQL)
-- because amfs_memory_entries has FORCE ROW LEVEL SECURITY enabled
-- and we need to read entries across all tenants to derive account_id.
--
-- Tables backfilled:
--   1. amfs_knowledge_graph  (account_id added in OSS PR #173)
--   2. amfs_digests           (account_id added in OSS PR #172)
--   3. amfs_events            (account_id column added below)
--   4. amfs_agents            (account_id column added below)
--   5. amfs_branches          (account_id added in OSS PR #173)
--   6. amfs_tags              (account_id added in OSS PR #173)
--   7. amfs_pull_requests     (account_id added in OSS PR #173)
--   8. amfs_branch_access     (account_id added in OSS PR #173)
--   9. amfs_pr_reviews        (account_id added in OSS PR #173)
-- =========================================================================

BEGIN;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 0: Add account_id columns to tables that don't have them yet
-- ─────────────────────────────────────────────────────────────────────────

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_events' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_events ADD COLUMN account_id UUID;
        CREATE INDEX idx_events_account ON amfs_events (account_id) WHERE account_id IS NOT NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_agents' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_agents ADD COLUMN account_id UUID;
        CREATE INDEX idx_agents_account ON amfs_agents (account_id) WHERE account_id IS NOT NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_knowledge_graph' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_knowledge_graph ADD COLUMN account_id UUID;
        CREATE INDEX idx_kg_account ON amfs_knowledge_graph (account_id) WHERE account_id IS NOT NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_branches' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_branches ADD COLUMN account_id UUID;
        CREATE INDEX idx_branches_account ON amfs_branches (account_id) WHERE account_id IS NOT NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_tags' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_tags ADD COLUMN account_id UUID;
        CREATE INDEX idx_tags_account ON amfs_tags (account_id) WHERE account_id IS NOT NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_pull_requests' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_pull_requests ADD COLUMN account_id UUID;
        CREATE INDEX idx_prs_account ON amfs_pull_requests (account_id) WHERE account_id IS NOT NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_branch_access' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_branch_access ADD COLUMN account_id UUID;
        CREATE INDEX idx_branch_access_account ON amfs_branch_access (account_id) WHERE account_id IS NOT NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_pr_reviews' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_pr_reviews ADD COLUMN account_id UUID;
        CREATE INDEX idx_pr_reviews_account ON amfs_pr_reviews (account_id) WHERE account_id IS NOT NULL;
    END IF;
END $$;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 1: Backfill amfs_knowledge_graph.account_id
-- Strategy: join on source_entity = entity_path in amfs_memory_entries
-- ─────────────────────────────────────────────────────────────────────────

UPDATE amfs_knowledge_graph kg
SET account_id = sub.account_id
FROM (
    SELECT DISTINCT ON (kg2.id)
        kg2.id AS kg_id,
        me.account_id
    FROM amfs_knowledge_graph kg2
    JOIN amfs_memory_entries me
        ON me.namespace = kg2.namespace
        AND me.entity_path = kg2.source_entity
        AND me.account_id IS NOT NULL
    WHERE kg2.account_id IS NULL
    ORDER BY kg2.id, me.written_at DESC
) sub
WHERE kg.id = sub.kg_id;

-- Catch remaining edges by matching target_entity
UPDATE amfs_knowledge_graph kg
SET account_id = sub.account_id
FROM (
    SELECT DISTINCT ON (kg2.id)
        kg2.id AS kg_id,
        me.account_id
    FROM amfs_knowledge_graph kg2
    JOIN amfs_memory_entries me
        ON me.namespace = kg2.namespace
        AND me.entity_path = kg2.target_entity
        AND me.account_id IS NOT NULL
    WHERE kg2.account_id IS NULL
    ORDER BY kg2.id, me.written_at DESC
) sub
WHERE kg.id = sub.kg_id;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 2: Backfill amfs_digests.account_id
-- Strategy: digests have a `scope` field which is the entity_path
-- ─────────────────────────────────────────────────────────────────────────

UPDATE amfs_digests d
SET account_id = sub.account_id
FROM (
    SELECT DISTINCT ON (d2.id)
        d2.id AS digest_id,
        me.account_id
    FROM amfs_digests d2
    JOIN amfs_memory_entries me
        ON me.namespace = d2.namespace
        AND me.entity_path = d2.scope
        AND me.account_id IS NOT NULL
    WHERE d2.account_id IS NULL
    ORDER BY d2.id, me.written_at DESC
) sub
WHERE d.id = sub.digest_id;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 3: Backfill amfs_events.account_id
-- Strategy: events have agent_id; match to entries by (namespace, agent_id)
-- ─────────────────────────────────────────────────────────────────────────

UPDATE amfs_events ev
SET account_id = sub.account_id
FROM (
    SELECT DISTINCT ON (ev2.id)
        ev2.id AS event_id,
        me.account_id
    FROM amfs_events ev2
    JOIN amfs_memory_entries me
        ON me.namespace = ev2.namespace
        AND me.agent_id = ev2.agent_id
        AND me.account_id IS NOT NULL
    WHERE ev2.account_id IS NULL
    ORDER BY ev2.id, me.written_at DESC
) sub
WHERE ev.id = sub.event_id;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 4: Backfill amfs_agents.account_id
-- Strategy: agents have agent_id; match to entries by (namespace, agent_id)
-- ─────────────────────────────────────────────────────────────────────────

UPDATE amfs_agents ag
SET account_id = sub.account_id
FROM (
    SELECT DISTINCT ON (ag2.id)
        ag2.id AS agent_id,
        me.account_id
    FROM amfs_agents ag2
    JOIN amfs_memory_entries me
        ON me.namespace = ag2.namespace
        AND me.agent_id = ag2.agent_id
        AND me.account_id IS NOT NULL
    WHERE ag2.account_id IS NULL
    ORDER BY ag2.id, me.written_at DESC
) sub
WHERE ag.id = sub.agent_id;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 5: Backfill amfs_branches.account_id
-- Strategy: branches have created_by (agent_id); match to entries
-- ─────────────────────────────────────────────────────────────────────────

UPDATE amfs_branches br
SET account_id = sub.account_id
FROM (
    SELECT DISTINCT ON (br2.id)
        br2.id AS branch_id,
        me.account_id
    FROM amfs_branches br2
    JOIN amfs_memory_entries me
        ON me.namespace = br2.namespace
        AND me.agent_id = br2.created_by
        AND me.account_id IS NOT NULL
    WHERE br2.account_id IS NULL
    ORDER BY br2.id, me.written_at DESC
) sub
WHERE br.id = sub.branch_id;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 6: Backfill amfs_tags.account_id
-- Strategy: tags have created_by (agent_id); match to entries
-- ─────────────────────────────────────────────────────────────────────────

UPDATE amfs_tags t
SET account_id = sub.account_id
FROM (
    SELECT DISTINCT ON (t2.id)
        t2.id AS tag_id,
        me.account_id
    FROM amfs_tags t2
    JOIN amfs_memory_entries me
        ON me.namespace = t2.namespace
        AND me.agent_id = t2.created_by
        AND me.account_id IS NOT NULL
    WHERE t2.account_id IS NULL
    ORDER BY t2.id, me.written_at DESC
) sub
WHERE t.id = sub.tag_id;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 7: Backfill amfs_pull_requests.account_id
-- Strategy: PRs have created_by (agent_id); match to entries
-- ─────────────────────────────────────────────────────────────────────────

UPDATE amfs_pull_requests pr
SET account_id = sub.account_id
FROM (
    SELECT DISTINCT ON (pr2.id)
        pr2.id AS pr_id,
        me.account_id
    FROM amfs_pull_requests pr2
    JOIN amfs_memory_entries me
        ON me.namespace = pr2.namespace
        AND me.agent_id = pr2.created_by
        AND me.account_id IS NOT NULL
    WHERE pr2.account_id IS NULL
    ORDER BY pr2.id, me.written_at DESC
) sub
WHERE pr.id = sub.pr_id;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 8: Backfill amfs_branch_access.account_id
-- Strategy: branch_access inherits account from the branch it refers to
-- ─────────────────────────────────────────────────────────────────────────

UPDATE amfs_branch_access ba
SET account_id = br.account_id
FROM amfs_branches br
WHERE ba.namespace = br.namespace
  AND ba.branch_name = br.name
  AND br.account_id IS NOT NULL
  AND ba.account_id IS NULL;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 9: Backfill amfs_pr_reviews.account_id
-- Strategy: PR reviews inherit account from the PR they refer to
-- ─────────────────────────────────────────────────────────────────────────

UPDATE amfs_pr_reviews rv
SET account_id = pr.account_id
FROM amfs_pull_requests pr
WHERE rv.pr_id = pr.id
  AND pr.account_id IS NOT NULL
  AND rv.account_id IS NULL;

-- ─────────────────────────────────────────────────────────────────────────
-- Step 10: Report results
-- ─────────────────────────────────────────────────────────────────────────

DO $$
DECLARE
    kg_total    BIGINT;
    kg_filled   BIGINT;
    kg_null     BIGINT;
    dig_total   BIGINT;
    dig_filled  BIGINT;
    dig_null    BIGINT;
    ev_total    BIGINT;
    ev_filled   BIGINT;
    ev_null     BIGINT;
    ag_total    BIGINT;
    ag_filled   BIGINT;
    ag_null     BIGINT;
    br_total    BIGINT;
    br_filled   BIGINT;
    br_null     BIGINT;
    tag_total   BIGINT;
    tag_filled  BIGINT;
    tag_null    BIGINT;
    pr_total    BIGINT;
    pr_filled   BIGINT;
    pr_null     BIGINT;
    ba_total    BIGINT;
    ba_filled   BIGINT;
    ba_null     BIGINT;
    rv_total    BIGINT;
    rv_filled   BIGINT;
    rv_null     BIGINT;
BEGIN
    SELECT count(*), count(account_id), count(*) - count(account_id)
        INTO kg_total, kg_filled, kg_null FROM amfs_knowledge_graph;
    SELECT count(*), count(account_id), count(*) - count(account_id)
        INTO dig_total, dig_filled, dig_null FROM amfs_digests;
    SELECT count(*), count(account_id), count(*) - count(account_id)
        INTO ev_total, ev_filled, ev_null FROM amfs_events;
    SELECT count(*), count(account_id), count(*) - count(account_id)
        INTO ag_total, ag_filled, ag_null FROM amfs_agents;
    SELECT count(*), count(account_id), count(*) - count(account_id)
        INTO br_total, br_filled, br_null FROM amfs_branches;
    SELECT count(*), count(account_id), count(*) - count(account_id)
        INTO tag_total, tag_filled, tag_null FROM amfs_tags;
    SELECT count(*), count(account_id), count(*) - count(account_id)
        INTO pr_total, pr_filled, pr_null FROM amfs_pull_requests;
    SELECT count(*), count(account_id), count(*) - count(account_id)
        INTO ba_total, ba_filled, ba_null FROM amfs_branch_access;
    SELECT count(*), count(account_id), count(*) - count(account_id)
        INTO rv_total, rv_filled, rv_null FROM amfs_pr_reviews;

    RAISE NOTICE '──────────────── Backfill Results ────────────────';
    RAISE NOTICE 'amfs_knowledge_graph : % total, % filled, % still NULL', kg_total, kg_filled, kg_null;
    RAISE NOTICE 'amfs_digests         : % total, % filled, % still NULL', dig_total, dig_filled, dig_null;
    RAISE NOTICE 'amfs_events          : % total, % filled, % still NULL', ev_total, ev_filled, ev_null;
    RAISE NOTICE 'amfs_agents          : % total, % filled, % still NULL', ag_total, ag_filled, ag_null;
    RAISE NOTICE 'amfs_branches        : % total, % filled, % still NULL', br_total, br_filled, br_null;
    RAISE NOTICE 'amfs_tags            : % total, % filled, % still NULL', tag_total, tag_filled, tag_null;
    RAISE NOTICE 'amfs_pull_requests   : % total, % filled, % still NULL', pr_total, pr_filled, pr_null;
    RAISE NOTICE 'amfs_branch_access   : % total, % filled, % still NULL', ba_total, ba_filled, ba_null;
    RAISE NOTICE 'amfs_pr_reviews      : % total, % filled, % still NULL', rv_total, rv_filled, rv_null;
    RAISE NOTICE '──────────────────────────────────────────────────';

    IF kg_null > 0 OR dig_null > 0 OR ev_null > 0 OR ag_null > 0
       OR br_null > 0 OR tag_null > 0 OR pr_null > 0 OR ba_null > 0 OR rv_null > 0 THEN
        RAISE NOTICE 'Some rows still have NULL account_id — likely orphans with no matching entries.';
        RAISE NOTICE 'Review them: SELECT * FROM <table> WHERE account_id IS NULL;';
    ELSE
        RAISE NOTICE 'All rows backfilled successfully.';
    END IF;
END $$;

COMMIT;
