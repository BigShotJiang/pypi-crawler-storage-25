-- 005: Auto-populate account_id from session variable + enforce RLS
--
-- The OSS PostgresAdapter INSERT statements don't include account_id.
-- By setting a DEFAULT that reads from the session variable, all writes
-- automatically get the correct tenant without changing OSS code.
--
-- FORCE ROW LEVEL SECURITY ensures RLS applies even when connected as
-- the table owner (typical with Cloud SQL managed databases).

ALTER TABLE amfs_memory_entries
    ALTER COLUMN account_id
    SET DEFAULT current_setting('amfs.current_account_id', true)::uuid;

ALTER TABLE amfs_outcomes
    ALTER COLUMN account_id
    SET DEFAULT current_setting('amfs.current_account_id', true)::uuid;

-- Force RLS on data tables so isolation applies even as table owner.
-- Do NOT force on api_keys/api_key_scopes — authenticate_api_key()
-- queries those BEFORE the tenant context is set.
ALTER TABLE amfs_memory_entries FORCE ROW LEVEL SECURITY;
ALTER TABLE amfs_outcomes FORCE ROW LEVEL SECURITY;
ALTER TABLE audit_log FORCE ROW LEVEL SECURITY;
