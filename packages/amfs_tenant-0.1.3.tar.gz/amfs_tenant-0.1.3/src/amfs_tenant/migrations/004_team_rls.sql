-- AMFS Pro: Row-level security for amfs_teams and amfs_team_members
-- Requires amfs.current_account_id set on the session (same as other tenant tables).

-- Backfill account_id on teams that are still NULL (single-tenant / legacy)
UPDATE amfs_teams t
SET account_id = a.id
FROM (SELECT id FROM accounts ORDER BY created_at ASC LIMIT 1) a
WHERE t.account_id IS NULL
  AND EXISTS (SELECT 1 FROM accounts);

ALTER TABLE amfs_teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE amfs_team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE amfs_teams FORCE ROW LEVEL SECURITY;
ALTER TABLE amfs_team_members FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS tenant_isolation_teams ON amfs_teams;
CREATE POLICY tenant_isolation_teams ON amfs_teams
    FOR ALL
    USING (
        account_id IS NOT NULL
        AND account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    )
    WITH CHECK (
        account_id IS NOT NULL
        AND account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    );

DROP POLICY IF EXISTS tenant_isolation_team_members ON amfs_team_members;
CREATE POLICY tenant_isolation_team_members ON amfs_team_members
    FOR ALL
    USING (
        team_id IN (
            SELECT id FROM amfs_teams
            WHERE account_id IS NOT NULL
              AND account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
        )
    )
    WITH CHECK (
        team_id IN (
            SELECT id FROM amfs_teams
            WHERE account_id IS NOT NULL
              AND account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
        )
    );
