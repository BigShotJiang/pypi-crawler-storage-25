-- =========================================================================
-- Migration 016: Negotiation, Discussions, and Knowledge Graph
-- =========================================================================
-- Phase 2 of Entity Rooms: structured negotiation between agents,
-- mediated discussions, and LLM-powered knowledge graph extraction.
--
-- Tables created:
--   negotiation_sessions   -- A negotiation topic with outcome
--   negotiation_issues     -- Issues/dimensions under negotiation
--   negotiation_rounds     -- Individual proposal/response rounds
--   negotiation_outcomes   -- Final consensus or failure records
--   discussion_messages    -- Agent-to-agent discussion messages
--   room_concepts          -- LLM-extracted concepts from room activity
--   room_concept_relations -- Relationships between extracted concepts
-- =========================================================================


-- =========================================================================
-- 1. Negotiation sessions
-- =========================================================================

CREATE TABLE IF NOT EXISTS negotiation_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES entity_rooms(id) ON DELETE CASCADE,
    account_id UUID NOT NULL REFERENCES accounts(id),
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'open'
        CHECK (status IN ('open', 'in_progress', 'consensus', 'failed', 'cancelled')),
    strategy TEXT NOT NULL DEFAULT 'mediated'
        CHECK (strategy IN ('mediated', 'round_robin', 'free_form')),
    max_rounds INT NOT NULL DEFAULT 10,
    deadline_at TIMESTAMPTZ,
    created_by TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_neg_sessions_room ON negotiation_sessions(room_id);
CREATE INDEX IF NOT EXISTS idx_neg_sessions_account ON negotiation_sessions(account_id);
CREATE INDEX IF NOT EXISTS idx_neg_sessions_status ON negotiation_sessions(room_id, status);


-- =========================================================================
-- 2. Negotiation issues (dimensions under negotiation)
-- =========================================================================

CREATE TABLE IF NOT EXISTS negotiation_issues (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES negotiation_sessions(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    value_type TEXT NOT NULL DEFAULT 'text'
        CHECK (value_type IN ('text', 'numeric', 'boolean', 'enum')),
    constraints JSONB NOT NULL DEFAULT '{}',
    weight FLOAT NOT NULL DEFAULT 1.0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_neg_issues_session ON negotiation_issues(session_id);


-- =========================================================================
-- 3. Negotiation rounds (proposals and responses)
-- =========================================================================

CREATE TABLE IF NOT EXISTS negotiation_rounds (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES negotiation_sessions(id) ON DELETE CASCADE,
    round_number INT NOT NULL,
    agent_id TEXT NOT NULL,
    action TEXT NOT NULL
        CHECK (action IN ('propose', 'counter', 'accept', 'reject', 'abstain')),
    proposal JSONB NOT NULL DEFAULT '{}',
    rationale TEXT,
    mediator_analysis TEXT,
    confidence FLOAT NOT NULL DEFAULT 0.5,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (session_id, round_number, agent_id)
);

CREATE INDEX IF NOT EXISTS idx_neg_rounds_session ON negotiation_rounds(session_id, round_number);
CREATE INDEX IF NOT EXISTS idx_neg_rounds_agent ON negotiation_rounds(agent_id);


-- =========================================================================
-- 4. Negotiation outcomes
-- =========================================================================

CREATE TABLE IF NOT EXISTS negotiation_outcomes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES negotiation_sessions(id) ON DELETE CASCADE,
    outcome_type TEXT NOT NULL
        CHECK (outcome_type IN ('consensus', 'majority', 'mediator_decision', 'timeout', 'failed')),
    final_proposal JSONB NOT NULL DEFAULT '{}',
    participating_agents TEXT[] NOT NULL DEFAULT '{}',
    dissenting_agents TEXT[] NOT NULL DEFAULT '{}',
    summary TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_neg_outcomes_session ON negotiation_outcomes(session_id);


-- =========================================================================
-- 5. Discussion messages (agent-to-agent, when enabled)
-- =========================================================================

CREATE TABLE IF NOT EXISTS discussion_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES entity_rooms(id) ON DELETE CASCADE,
    account_id UUID NOT NULL REFERENCES accounts(id),
    agent_id TEXT NOT NULL,
    message_type TEXT NOT NULL DEFAULT 'message'
        CHECK (message_type IN ('message', 'question', 'answer', 'proposal', 'summary', 'system')),
    content TEXT NOT NULL,
    reply_to UUID REFERENCES discussion_messages(id),
    addressed_to TEXT,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_disc_messages_room ON discussion_messages(room_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_disc_messages_agent ON discussion_messages(agent_id);
CREATE INDEX IF NOT EXISTS idx_disc_messages_account ON discussion_messages(account_id);


-- =========================================================================
-- 6. Room concepts (LLM-extracted knowledge graph nodes)
-- =========================================================================

CREATE TABLE IF NOT EXISTS room_concepts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES entity_rooms(id) ON DELETE CASCADE,
    account_id UUID NOT NULL REFERENCES accounts(id),
    name TEXT NOT NULL,
    concept_type TEXT NOT NULL DEFAULT 'concept',
    description TEXT,
    confidence FLOAT NOT NULL DEFAULT 0.5,
    source_entry_key TEXT,
    source_agent_id TEXT,
    extracted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (room_id, name, concept_type)
);

CREATE INDEX IF NOT EXISTS idx_room_concepts_room ON room_concepts(room_id);
CREATE INDEX IF NOT EXISTS idx_room_concepts_account ON room_concepts(account_id);


-- =========================================================================
-- 7. Room concept relations (edges in the knowledge graph)
-- =========================================================================

CREATE TABLE IF NOT EXISTS room_concept_relations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES entity_rooms(id) ON DELETE CASCADE,
    source_id UUID NOT NULL REFERENCES room_concepts(id) ON DELETE CASCADE,
    target_id UUID NOT NULL REFERENCES room_concepts(id) ON DELETE CASCADE,
    relation_type TEXT NOT NULL,
    confidence FLOAT NOT NULL DEFAULT 0.5,
    metadata JSONB NOT NULL DEFAULT '{}',
    extracted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (room_id, source_id, target_id, relation_type)
);

CREATE INDEX IF NOT EXISTS idx_concept_rels_room ON room_concept_relations(room_id);
CREATE INDEX IF NOT EXISTS idx_concept_rels_source ON room_concept_relations(source_id);
CREATE INDEX IF NOT EXISTS idx_concept_rels_target ON room_concept_relations(target_id);


-- =========================================================================
-- 8. Row-Level Security
-- =========================================================================

ALTER TABLE negotiation_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE negotiation_sessions FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_neg_sessions ON negotiation_sessions;
CREATE POLICY tenant_isolation_neg_sessions ON negotiation_sessions
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);

ALTER TABLE negotiation_issues ENABLE ROW LEVEL SECURITY;
ALTER TABLE negotiation_issues FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_neg_issues ON negotiation_issues;
CREATE POLICY tenant_isolation_neg_issues ON negotiation_issues
    USING (session_id IN (
        SELECT id FROM negotiation_sessions
        WHERE account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    ));

ALTER TABLE negotiation_rounds ENABLE ROW LEVEL SECURITY;
ALTER TABLE negotiation_rounds FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_neg_rounds ON negotiation_rounds;
CREATE POLICY tenant_isolation_neg_rounds ON negotiation_rounds
    USING (session_id IN (
        SELECT id FROM negotiation_sessions
        WHERE account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    ));

ALTER TABLE negotiation_outcomes ENABLE ROW LEVEL SECURITY;
ALTER TABLE negotiation_outcomes FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_neg_outcomes ON negotiation_outcomes;
CREATE POLICY tenant_isolation_neg_outcomes ON negotiation_outcomes
    USING (session_id IN (
        SELECT id FROM negotiation_sessions
        WHERE account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    ));

ALTER TABLE discussion_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE discussion_messages FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_disc_messages ON discussion_messages;
CREATE POLICY tenant_isolation_disc_messages ON discussion_messages
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);

ALTER TABLE room_concepts ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_concepts FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_room_concepts ON room_concepts;
CREATE POLICY tenant_isolation_room_concepts ON room_concepts
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);

ALTER TABLE room_concept_relations ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_concept_relations FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_concept_rels ON room_concept_relations;
CREATE POLICY tenant_isolation_concept_rels ON room_concept_relations
    USING (room_id IN (
        SELECT id FROM entity_rooms
        WHERE account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    ));
