-- AMFS Pro: Dashboard auth, invitations, password reset, platform staff
-- Run after 001_multi_tenant.sql and OSS amfs_teams / amfs_team_members exist.

-- ---------------------------------------------------------------------------
-- users: password (credentials) + optional email verification
-- ---------------------------------------------------------------------------

ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified_at TIMESTAMPTZ;

-- ---------------------------------------------------------------------------
-- Platform staff (SenseLab operators; not tenant-scoped)
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS platform_staff (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by_email TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_platform_staff_email_lower
    ON platform_staff ((lower(email)));

INSERT INTO platform_staff (email)
VALUES (lower('bruno@sense-lab.ai'))
ON CONFLICT ((lower(email))) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Team / org invitations (magic link; token stored hashed)
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS user_invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    team_id UUID NOT NULL REFERENCES amfs_teams(id) ON DELETE CASCADE,
    team_role TEXT NOT NULL CHECK (team_role IN ('admin', 'developer', 'viewer')),
    token_hash TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    accepted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_invitations_token ON user_invitations (token_hash);
CREATE INDEX IF NOT EXISTS idx_user_invitations_lookup ON user_invitations (account_id, lower(email));

-- ---------------------------------------------------------------------------
-- Password reset tokens (hashed, single-use)
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_password_reset_token_hash
    ON password_reset_tokens (token_hash)
    WHERE used_at IS NULL;

-- ---------------------------------------------------------------------------
-- Staff-only read: all dashboard users (bypasses RLS on users)
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION amfs_staff_list_users()
RETURNS TABLE (
    user_id UUID,
    account_id UUID,
    email TEXT,
    name TEXT,
    role TEXT,
    created_at TIMESTAMPTZ,
    last_login TIMESTAMPTZ,
    account_name TEXT,
    account_slug TEXT
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT
        u.id,
        u.account_id,
        u.email,
        u.name,
        u.role::text,
        u.created_at,
        u.last_login,
        a.name,
        a.slug
    FROM users u
    JOIN accounts a ON a.id = u.account_id
    ORDER BY u.created_at DESC;
$$;
