-- 019: Per-team tenancy — add team_id to data tables and enforce via RLS
--
-- Adds a second isolation layer: within each account, data is scoped to
-- the team that created it.  Admin users bypass team filtering.
--
-- GUCs used:
--   amfs.current_team_id       — the requesting user/key's team UUID
--   amfs.is_account_admin      — 'true' for admin users (bypass team filter)
--
-- Safety:
--   - team_id columns are nullable; existing data stays visible via
--     the "team_id IS NULL" clause in RLS policies.
--   - DEFAULT reads from the GUC so new writes auto-populate without
--     any changes to the OSS adapter's INSERT statements.
--   - Backfill at the end assigns all NULL rows to a per-account
--     default team.

-- =========================================================================
-- 1a. Add team_id columns with DEFAULT from GUC
-- =========================================================================

-- amfs_memory_entries
ALTER TABLE amfs_memory_entries
    ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
ALTER TABLE amfs_memory_entries
    ALTER COLUMN team_id SET DEFAULT
        NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
CREATE INDEX IF NOT EXISTS idx_entries_team
    ON amfs_memory_entries (team_id) WHERE team_id IS NOT NULL;

-- amfs_decision_traces
ALTER TABLE amfs_decision_traces
    ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
ALTER TABLE amfs_decision_traces
    ALTER COLUMN team_id SET DEFAULT
        NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
CREATE INDEX IF NOT EXISTS idx_traces_team
    ON amfs_decision_traces (team_id) WHERE team_id IS NOT NULL;

-- amfs_detected_patterns
ALTER TABLE amfs_detected_patterns
    ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
ALTER TABLE amfs_detected_patterns
    ALTER COLUMN team_id SET DEFAULT
        NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
CREATE INDEX IF NOT EXISTS idx_patterns_team
    ON amfs_detected_patterns (team_id) WHERE team_id IS NOT NULL;

-- amfs_outcomes
ALTER TABLE amfs_outcomes
    ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
ALTER TABLE amfs_outcomes
    ALTER COLUMN team_id SET DEFAULT
        NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
CREATE INDEX IF NOT EXISTS idx_outcomes_team
    ON amfs_outcomes (team_id) WHERE team_id IS NOT NULL;

-- amfs_agents
ALTER TABLE amfs_agents
    ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
ALTER TABLE amfs_agents
    ALTER COLUMN team_id SET DEFAULT
        NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
CREATE INDEX IF NOT EXISTS idx_amfs_agents_team
    ON amfs_agents (team_id) WHERE team_id IS NOT NULL;

-- amfs_audit_log
ALTER TABLE amfs_audit_log
    ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
ALTER TABLE amfs_audit_log
    ALTER COLUMN team_id SET DEFAULT
        NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
CREATE INDEX IF NOT EXISTS idx_amfs_audit_team
    ON amfs_audit_log (team_id) WHERE team_id IS NOT NULL;

-- amfs_events (guard: table may not exist in minimal environments)
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables
               WHERE table_name = 'amfs_events') THEN
        EXECUTE $a$
            ALTER TABLE amfs_events
                ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
            ALTER TABLE amfs_events
                ALTER COLUMN team_id SET DEFAULT
                    NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
            CREATE INDEX IF NOT EXISTS idx_events_team
                ON amfs_events (team_id) WHERE team_id IS NOT NULL;
        $a$;
    END IF;
END $$;

-- amfs_knowledge_graph (guard: table may not exist)
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables
               WHERE table_name = 'amfs_knowledge_graph') THEN
        EXECUTE $a$
            ALTER TABLE amfs_knowledge_graph
                ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
            ALTER TABLE amfs_knowledge_graph
                ALTER COLUMN team_id SET DEFAULT
                    NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
            CREATE INDEX IF NOT EXISTS idx_kg_team
                ON amfs_knowledge_graph (team_id) WHERE team_id IS NOT NULL;
        $a$;
    END IF;
END $$;

-- amfs_immutable_traces (guard: table may not exist)
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables
               WHERE table_name = 'amfs_immutable_traces') THEN
        EXECUTE $a$
            ALTER TABLE amfs_immutable_traces
                ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
            ALTER TABLE amfs_immutable_traces
                ALTER COLUMN team_id SET DEFAULT
                    NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
            CREATE INDEX IF NOT EXISTS idx_immutable_traces_team
                ON amfs_immutable_traces (team_id) WHERE team_id IS NOT NULL;
        $a$;
    END IF;
END $$;

-- amfs_digests
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables
               WHERE table_name = 'amfs_digests') THEN
        EXECUTE $a$
            ALTER TABLE amfs_digests
                ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
            ALTER TABLE amfs_digests
                ALTER COLUMN team_id SET DEFAULT
                    NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
            CREATE INDEX IF NOT EXISTS idx_digests_team
                ON amfs_digests (team_id) WHERE team_id IS NOT NULL;
        $a$;
    END IF;
END $$;

-- api_keys (Pro IAM keys)
ALTER TABLE api_keys
    ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
ALTER TABLE api_keys
    ALTER COLUMN team_id SET DEFAULT
        NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
CREATE INDEX IF NOT EXISTS idx_api_keys_team
    ON api_keys (team_id) WHERE team_id IS NOT NULL;

-- amfs_api_keys (OSS keys)
ALTER TABLE amfs_api_keys
    ADD COLUMN IF NOT EXISTS team_id UUID REFERENCES amfs_teams(id);
ALTER TABLE amfs_api_keys
    ALTER COLUMN team_id SET DEFAULT
        NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
CREATE INDEX IF NOT EXISTS idx_amfs_api_keys_team
    ON amfs_api_keys (team_id) WHERE team_id IS NOT NULL;

-- agents (Pro registered agents — already has team_id from migration 002,
-- just add the DEFAULT and index if missing)
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns
               WHERE table_name = 'agents' AND column_name = 'team_id') THEN
        EXECUTE $a$
            ALTER TABLE agents
                ALTER COLUMN team_id SET DEFAULT
                    NULLIF(current_setting('amfs.current_team_id', true), '')::uuid;
            CREATE INDEX IF NOT EXISTS idx_agents_team
                ON agents (team_id) WHERE team_id IS NOT NULL;
        $a$;
    END IF;
END $$;


-- =========================================================================
-- 1c. Rewrite RLS policies to include team_id with admin bypass
-- =========================================================================

-- amfs_memory_entries
DROP POLICY IF EXISTS tenant_isolation_entries ON amfs_memory_entries;
CREATE POLICY tenant_isolation_entries ON amfs_memory_entries
    FOR ALL
    USING (
        account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
        AND (
            current_setting('amfs.is_account_admin', true) = 'true'
            OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
            OR team_id IS NULL
            OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
        )
    )
    WITH CHECK (
        account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
        AND (
            current_setting('amfs.is_account_admin', true) = 'true'
            OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
            OR team_id IS NULL
            OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
        )
    );

-- amfs_outcomes
DROP POLICY IF EXISTS tenant_isolation_outcomes ON amfs_outcomes;
CREATE POLICY tenant_isolation_outcomes ON amfs_outcomes
    FOR ALL
    USING (
        account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
        AND (
            current_setting('amfs.is_account_admin', true) = 'true'
            OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
            OR team_id IS NULL
            OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
        )
    )
    WITH CHECK (
        account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
        AND (
            current_setting('amfs.is_account_admin', true) = 'true'
            OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
            OR team_id IS NULL
            OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
        )
    );

-- amfs_decision_traces
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM pg_policies
               WHERE tablename = 'amfs_decision_traces'
                 AND policyname = 'tenant_isolation_traces') THEN
        DROP POLICY tenant_isolation_traces ON amfs_decision_traces;
    END IF;
    EXECUTE $p$CREATE POLICY tenant_isolation_traces ON amfs_decision_traces
        FOR ALL
        USING (
            account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
            AND (
                current_setting('amfs.is_account_admin', true) = 'true'
                OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                OR team_id IS NULL
                OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
            )
        )
        WITH CHECK (
            account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
            AND (
                current_setting('amfs.is_account_admin', true) = 'true'
                OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                OR team_id IS NULL
                OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
            )
        )$p$;
END $$;

-- amfs_detected_patterns
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM pg_policies
               WHERE tablename = 'amfs_detected_patterns'
                 AND policyname = 'tenant_isolation_patterns') THEN
        DROP POLICY tenant_isolation_patterns ON amfs_detected_patterns;
    END IF;
    EXECUTE $p$CREATE POLICY tenant_isolation_patterns ON amfs_detected_patterns
        FOR ALL
        USING (
            account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
            AND (
                current_setting('amfs.is_account_admin', true) = 'true'
                OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                OR team_id IS NULL
                OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
            )
        )
        WITH CHECK (
            account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
            AND (
                current_setting('amfs.is_account_admin', true) = 'true'
                OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                OR team_id IS NULL
                OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
            )
        )$p$;
END $$;

-- amfs_immutable_traces (guard)
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM pg_policies
               WHERE tablename = 'amfs_immutable_traces'
                 AND policyname = 'tenant_isolation_immutable_traces') THEN
        DROP POLICY tenant_isolation_immutable_traces ON amfs_immutable_traces;
        EXECUTE $p$CREATE POLICY tenant_isolation_immutable_traces ON amfs_immutable_traces
            FOR ALL
            USING (
                account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
                AND (
                    current_setting('amfs.is_account_admin', true) = 'true'
                    OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                    OR team_id IS NULL
                    OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
                )
            )
            WITH CHECK (
                account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
                AND (
                    current_setting('amfs.is_account_admin', true) = 'true'
                    OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                    OR team_id IS NULL
                    OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
                )
            )$p$;
    END IF;
END $$;

-- agents (Pro registered agents)
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM pg_policies
               WHERE tablename = 'agents'
                 AND policyname = 'tenant_isolation_agents') THEN
        DROP POLICY tenant_isolation_agents ON agents;
        EXECUTE $p$CREATE POLICY tenant_isolation_agents ON agents
            FOR ALL
            USING (
                account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
                AND (
                    current_setting('amfs.is_account_admin', true) = 'true'
                    OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                    OR team_id IS NULL
                    OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
                )
            )
            WITH CHECK (
                account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
                AND (
                    current_setting('amfs.is_account_admin', true) = 'true'
                    OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                    OR team_id IS NULL
                    OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
                )
            )$p$;
    END IF;
END $$;

-- amfs_audit_log
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM pg_policies
               WHERE tablename = 'amfs_audit_log'
                 AND policyname = 'tenant_isolation_oss_audit_log') THEN
        DROP POLICY tenant_isolation_oss_audit_log ON amfs_audit_log;
    END IF;
    EXECUTE $p$CREATE POLICY tenant_isolation_oss_audit_log ON amfs_audit_log
        FOR ALL
        USING (
            account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
            AND (
                current_setting('amfs.is_account_admin', true) = 'true'
                OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                OR team_id IS NULL
                OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
            )
        )
        WITH CHECK (
            account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
            AND (
                current_setting('amfs.is_account_admin', true) = 'true'
                OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                OR team_id IS NULL
                OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
            )
        )$p$;
END $$;

-- api_keys (Pro IAM keys)
DROP POLICY IF EXISTS tenant_isolation_apikeys ON api_keys;
CREATE POLICY tenant_isolation_apikeys ON api_keys
    FOR ALL
    USING (
        account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
        AND (
            current_setting('amfs.is_account_admin', true) = 'true'
            OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
            OR team_id IS NULL
            OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
        )
    )
    WITH CHECK (
        account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
        AND (
            current_setting('amfs.is_account_admin', true) = 'true'
            OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
            OR team_id IS NULL
            OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
        )
    );

-- api_key_scopes (inherits via subquery on api_keys which now has team filter)
DROP POLICY IF EXISTS tenant_isolation_scopes ON api_key_scopes;
CREATE POLICY tenant_isolation_scopes ON api_key_scopes
    FOR ALL
    USING (
        api_key_id IN (
            SELECT id FROM api_keys
            WHERE account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
              AND (
                  current_setting('amfs.is_account_admin', true) = 'true'
                  OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                  OR team_id IS NULL
                  OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
              )
        )
    )
    WITH CHECK (
        api_key_id IN (
            SELECT id FROM api_keys
            WHERE account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
              AND (
                  current_setting('amfs.is_account_admin', true) = 'true'
                  OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                  OR team_id IS NULL
                  OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
              )
        )
    );

-- audit_log (Pro audit — account_id only, no team_id column on this table)
-- Leave untouched: admins need full audit visibility.

-- amfs_api_keys (OSS keys) — update policies to include team filter
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM pg_policies
               WHERE tablename = 'amfs_api_keys'
                 AND policyname = 'api_keys_tenant_modify') THEN
        DROP POLICY api_keys_tenant_modify ON amfs_api_keys;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_policies
               WHERE tablename = 'amfs_api_keys'
                 AND policyname = 'api_keys_auth_select') THEN
        DROP POLICY api_keys_auth_select ON amfs_api_keys;
    END IF;

    -- Auth select: allows unauthenticated reads for key lookup (account_id may be NULL/empty)
    -- plus tenant-scoped reads with team filter
    EXECUTE $p$CREATE POLICY api_keys_auth_select ON amfs_api_keys
        FOR SELECT
        USING (
            current_setting('amfs.current_account_id', true) IS NULL
            OR current_setting('amfs.current_account_id', true) = ''
            OR (
                account_id = current_setting('amfs.current_account_id', true)::uuid
                AND (
                    current_setting('amfs.is_account_admin', true) = 'true'
                    OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                    OR team_id IS NULL
                    OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
                )
            )
        )$p$;

    -- Modify: requires tenant context + team match
    EXECUTE $p$CREATE POLICY api_keys_tenant_modify ON amfs_api_keys
        FOR ALL
        USING (
            current_setting('amfs.current_account_id', true) IS NULL
            OR current_setting('amfs.current_account_id', true) = ''
            OR (
                account_id = current_setting('amfs.current_account_id', true)::uuid
                AND (
                    current_setting('amfs.is_account_admin', true) = 'true'
                    OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                    OR team_id IS NULL
                    OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
                )
            )
        )
        WITH CHECK (
            current_setting('amfs.current_account_id', true) IS NULL
            OR current_setting('amfs.current_account_id', true) = ''
            OR (
                account_id = current_setting('amfs.current_account_id', true)::uuid
                AND (
                    current_setting('amfs.is_account_admin', true) = 'true'
                    OR NULLIF(current_setting('amfs.current_team_id', true), '') IS NULL
                    OR team_id IS NULL
                    OR team_id = NULLIF(current_setting('amfs.current_team_id', true), '')::uuid
                )
            )
        )$p$;
END $$;


-- =========================================================================
-- 1e. Backfill: create default teams and assign all NULL team_id rows
-- =========================================================================

DO $$
DECLARE
    acc RECORD;
    default_team_id UUID;
BEGIN
    FOR acc IN SELECT id, slug FROM accounts LOOP
        -- Set GUCs so RLS policies (including FORCE RLS on amfs_teams) pass
        PERFORM set_config('amfs.current_account_id', acc.id::text, true);
        PERFORM set_config('amfs.is_account_admin', 'true', true);
        PERFORM set_config('amfs.current_team_id', '', true);

        SELECT id INTO default_team_id
        FROM amfs_teams
        WHERE account_id = acc.id AND slug LIKE '%-default'
        LIMIT 1;

        IF default_team_id IS NULL THEN
            INSERT INTO amfs_teams (namespace, name, slug, description, account_id)
            VALUES ('default', 'Default', acc.slug || '-default', 'Default team', acc.id)
            RETURNING id INTO default_team_id;
        END IF;

        UPDATE amfs_memory_entries SET team_id = default_team_id
            WHERE account_id = acc.id AND team_id IS NULL;
        UPDATE amfs_decision_traces SET team_id = default_team_id
            WHERE account_id = acc.id AND team_id IS NULL;
        UPDATE amfs_detected_patterns SET team_id = default_team_id
            WHERE account_id = acc.id AND team_id IS NULL;
        UPDATE amfs_outcomes SET team_id = default_team_id
            WHERE account_id = acc.id AND team_id IS NULL;
        UPDATE amfs_agents SET team_id = default_team_id
            WHERE account_id = acc.id AND team_id IS NULL;
        UPDATE amfs_audit_log SET team_id = default_team_id
            WHERE account_id = acc.id AND team_id IS NULL;
        UPDATE api_keys SET team_id = default_team_id
            WHERE account_id = acc.id AND team_id IS NULL;
        UPDATE amfs_api_keys SET team_id = default_team_id
            WHERE account_id = acc.id AND team_id IS NULL;
        UPDATE agents SET team_id = default_team_id
            WHERE account_id = acc.id AND team_id IS NULL;

        INSERT INTO amfs_team_members (namespace, team_id, email, display_name, role, accepted_at)
        SELECT 'default', default_team_id, u.email, COALESCE(u.name, u.email),
               CASE WHEN u.role = 'admin' THEN 'admin' ELSE 'developer' END,
               now()
        FROM users u
        WHERE u.account_id = acc.id
          AND u.deleted_at IS NULL
          AND NOT EXISTS (
              SELECT 1 FROM amfs_team_members tm
              WHERE tm.email = u.email
                AND tm.removed_at IS NULL
          );
    END LOOP;

    -- Clear GUCs after backfill
    PERFORM set_config('amfs.current_account_id', '', true);
    PERFORM set_config('amfs.is_account_admin', 'false', true);
    PERFORM set_config('amfs.current_team_id', '', true);
END $$;
