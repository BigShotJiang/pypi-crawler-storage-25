-- 013: Expand plan_tier CHECK constraint to include free, pro, and teams.
--
-- The original constraint only allowed starter/team/enterprise. The onboarding
-- flow needs 'free', and Stripe plans use 'pro' and 'teams' (plural).

ALTER TABLE accounts DROP CONSTRAINT IF EXISTS accounts_plan_tier_check;

ALTER TABLE accounts ADD CONSTRAINT accounts_plan_tier_check
    CHECK (plan_tier IN ('free', 'starter', 'pro', 'team', 'teams', 'enterprise'));
