-- 023: Make plan_tier nullable with no default.
--
-- The original schema (001) set plan_tier NOT NULL DEFAULT 'starter'. This
-- meant every INSERT that omitted plan_tier silently got 'starter' — even
-- after the dashboard fix (PR #210) that removed the hardcoded value.
-- New accounts should start with plan_tier = NULL (no tier assigned) until
-- the user explicitly selects and pays for a plan.

-- 1. Drop the NOT NULL and DEFAULT so new rows get NULL by default.
ALTER TABLE accounts ALTER COLUMN plan_tier DROP NOT NULL;
ALTER TABLE accounts ALTER COLUMN plan_tier DROP DEFAULT;

-- 2. Update the CHECK constraint to explicitly allow NULL (it already does
--    in Postgres when the column is nullable, but be explicit for clarity).
ALTER TABLE accounts DROP CONSTRAINT IF EXISTS accounts_plan_tier_check;
ALTER TABLE accounts ADD CONSTRAINT accounts_plan_tier_check
    CHECK (plan_tier IS NULL
        OR plan_tier IN ('free', 'starter', 'pro', 'team', 'teams', 'enterprise'));

-- 3. Fix any accounts that were wrongly assigned 'starter' without payment:
--    if plan_status is still 'pending_plan', the user never completed checkout.
UPDATE accounts
SET plan_tier = NULL
WHERE plan_tier = 'starter'
  AND plan_status = 'pending_plan';
