-- 010: Add account_id + RLS to OSS amfs_api_keys and amfs_audit_log tables.
--
-- These tables used namespace-based scoping which does not enforce tenant
-- isolation when all tenants share namespace='default'.  Adding account_id
-- with RLS policies + FORCE fixes the cross-tenant data leak.
--
-- SECURITY DEFINER functions are required because _check_db_key() in auth.py
-- opens a raw connection without setting amfs.current_account_id.  Without
-- these functions, FORCE RLS would block all API key authentication.

-- =========================================================================
-- 1. Add account_id columns (idempotent)
-- =========================================================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_api_keys' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_api_keys ADD COLUMN account_id UUID;
        CREATE INDEX idx_amfs_api_keys_account ON amfs_api_keys (account_id);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'amfs_audit_log' AND column_name = 'account_id'
    ) THEN
        ALTER TABLE amfs_audit_log ADD COLUMN account_id UUID;
        CREATE INDEX idx_amfs_audit_log_account ON amfs_audit_log (account_id);
    END IF;
END $$;

-- =========================================================================
-- 2. Set DEFAULT to auto-inherit from session variable on INSERT
-- =========================================================================

ALTER TABLE amfs_api_keys
    ALTER COLUMN account_id
    SET DEFAULT current_setting('amfs.current_account_id', true)::uuid;

ALTER TABLE amfs_audit_log
    ALTER COLUMN account_id
    SET DEFAULT current_setting('amfs.current_account_id', true)::uuid;

-- =========================================================================
-- 3. Backfill existing rows to the first account (single-tenant assumption)
-- =========================================================================

UPDATE amfs_api_keys k
SET account_id = a.id
FROM (SELECT id FROM accounts ORDER BY created_at ASC LIMIT 1) a
WHERE k.account_id IS NULL
  AND EXISTS (SELECT 1 FROM accounts);

UPDATE amfs_audit_log l
SET account_id = a.id
FROM (SELECT id FROM accounts ORDER BY created_at ASC LIMIT 1) a
WHERE l.account_id IS NULL
  AND EXISTS (SELECT 1 FROM accounts);

-- =========================================================================
-- 4. Enable + Force RLS
-- =========================================================================

ALTER TABLE amfs_api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE amfs_api_keys FORCE ROW LEVEL SECURITY;

ALTER TABLE amfs_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE amfs_audit_log FORCE ROW LEVEL SECURITY;

-- =========================================================================
-- 5. RLS policies
--
-- amfs_api_keys needs a SELECT policy that allows reads without tenant
-- context so the SECURITY DEFINER auth functions can look up keys before
-- the tenant is known.  Writes still require tenant context.
-- =========================================================================

DROP POLICY IF EXISTS tenant_isolation_oss_api_keys ON amfs_api_keys;
DROP POLICY IF EXISTS api_keys_auth_select ON amfs_api_keys;
CREATE POLICY api_keys_auth_select ON amfs_api_keys
    FOR SELECT
    USING (
        current_setting('amfs.current_account_id', true) IS NULL
        OR current_setting('amfs.current_account_id', true) = ''
        OR account_id = current_setting('amfs.current_account_id', true)::uuid
    );

DROP POLICY IF EXISTS api_keys_tenant_modify ON amfs_api_keys;
CREATE POLICY api_keys_tenant_modify ON amfs_api_keys
    FOR ALL
    USING (
        current_setting('amfs.current_account_id', true) IS NULL
        OR current_setting('amfs.current_account_id', true) = ''
        OR account_id = current_setting('amfs.current_account_id', true)::uuid
    )
    WITH CHECK (
        current_setting('amfs.current_account_id', true) IS NULL
        OR current_setting('amfs.current_account_id', true) = ''
        OR account_id = current_setting('amfs.current_account_id', true)::uuid
    );

DROP POLICY IF EXISTS tenant_isolation_oss_audit_log ON amfs_audit_log;
CREATE POLICY tenant_isolation_oss_audit_log ON amfs_audit_log
    USING (account_id = current_setting('amfs.current_account_id', true)::uuid);

-- =========================================================================
-- 6. SECURITY DEFINER functions for API key auth
--
-- These functions run as the table owner but rely on the permissive SELECT
-- policy above to read keys without tenant context.  This is safe because
-- the functions only return (id, account_id) — no sensitive data.
-- =========================================================================

CREATE OR REPLACE FUNCTION amfs_authenticate_api_key(p_key_hash TEXT)
RETURNS TABLE (key_id UUID, key_account_id UUID)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT id, account_id
    FROM amfs_api_keys
    WHERE key_hash = p_key_hash
      AND active = TRUE
      AND (expires_at IS NULL OR expires_at > NOW())
    LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION amfs_touch_api_key_usage(p_key_id UUID)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
    UPDATE amfs_api_keys SET last_used = NOW() WHERE id = p_key_id;
$$;
