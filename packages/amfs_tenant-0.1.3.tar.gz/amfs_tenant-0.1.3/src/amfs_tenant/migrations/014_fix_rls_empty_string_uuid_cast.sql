-- =========================================================================
-- Migration 014: Fix RLS policies that crash on empty-string UUID cast
-- =========================================================================
-- When amfs.current_account_id is '' (empty string) — e.g. background
-- workers with no HTTP request context — the RLS policies from
-- migration 001 crash with:
--   invalid input syntax for type uuid: ""
--
-- Fix: wrap current_setting with NULLIF(..., '') so empty strings
-- become NULL, and the comparison safely returns FALSE (no rows).
--
-- Migration 004 already did this for teams; this brings all other
-- policies into alignment.
-- =========================================================================

-- amfs_memory_entries (from 001)
DROP POLICY IF EXISTS tenant_isolation_entries ON amfs_memory_entries;
CREATE POLICY tenant_isolation_entries ON amfs_memory_entries
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);

-- amfs_outcomes (from 001)
DROP POLICY IF EXISTS tenant_isolation_outcomes ON amfs_outcomes;
CREATE POLICY tenant_isolation_outcomes ON amfs_outcomes
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);

-- users (from 001)
DROP POLICY IF EXISTS tenant_isolation_users ON users;
CREATE POLICY tenant_isolation_users ON users
    USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid);

-- api_keys (from 001 — note: 010 added a separate SELECT policy with NULLIF,
-- but the original FOR ALL policy may still be active)
DO $$ BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_policies
        WHERE tablename = 'api_keys' AND policyname = 'tenant_isolation_apikeys'
    ) THEN
        DROP POLICY tenant_isolation_apikeys ON api_keys;
        EXECUTE $p$CREATE POLICY tenant_isolation_apikeys ON api_keys
            USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid)$p$;
    END IF;
END $$;

-- api_key_scopes (from 001)
DROP POLICY IF EXISTS tenant_isolation_scopes ON api_key_scopes;
CREATE POLICY tenant_isolation_scopes ON api_key_scopes
    USING (api_key_id IN (
        SELECT id FROM api_keys
        WHERE account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid
    ));

-- audit_log (from 001)
DO $$ BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_policies
        WHERE tablename = 'audit_log' AND policyname = 'tenant_isolation_audit'
    ) THEN
        DROP POLICY tenant_isolation_audit ON audit_log;
        EXECUTE $p$CREATE POLICY tenant_isolation_audit ON audit_log
            USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid)$p$;
    END IF;
END $$;

-- amfs_audit_log (from 010 — if it exists as a separate table)
DO $$ BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_policies
        WHERE tablename = 'amfs_audit_log' AND policyname = 'tenant_isolation_oss_audit_log'
    ) THEN
        DROP POLICY tenant_isolation_oss_audit_log ON amfs_audit_log;
        EXECUTE $p$CREATE POLICY tenant_isolation_oss_audit_log ON amfs_audit_log
            USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid)$p$;
    END IF;
END $$;

-- amfs_decision_traces (from 008)
DO $$ BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_policies
        WHERE tablename = 'amfs_decision_traces' AND policyname = 'tenant_isolation_traces'
    ) THEN
        DROP POLICY tenant_isolation_traces ON amfs_decision_traces;
        EXECUTE $p$CREATE POLICY tenant_isolation_traces ON amfs_decision_traces
            USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid)$p$;
    END IF;
END $$;

-- amfs_detected_patterns (from 008)
DO $$ BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_policies
        WHERE tablename = 'amfs_detected_patterns' AND policyname = 'tenant_isolation_patterns'
    ) THEN
        DROP POLICY tenant_isolation_patterns ON amfs_detected_patterns;
        EXECUTE $p$CREATE POLICY tenant_isolation_patterns ON amfs_detected_patterns
            USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid)$p$;
    END IF;
END $$;

-- amfs_immutable_traces (from 008 — conditional)
DO $$ BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_policies
        WHERE tablename = 'amfs_immutable_traces' AND policyname = 'tenant_isolation_immutable_traces'
    ) THEN
        DROP POLICY tenant_isolation_immutable_traces ON amfs_immutable_traces;
        EXECUTE $p$CREATE POLICY tenant_isolation_immutable_traces ON amfs_immutable_traces
            USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid)$p$;
    END IF;
END $$;

-- agents (from 002)
DO $$ BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_policies
        WHERE tablename = 'agents' AND policyname = 'tenant_isolation_agents'
    ) THEN
        DROP POLICY tenant_isolation_agents ON agents;
        EXECUTE $p$CREATE POLICY tenant_isolation_agents ON agents
            USING (account_id = NULLIF(current_setting('amfs.current_account_id', true), '')::uuid)$p$;
    END IF;
END $$;

-- Also fix the DEFAULT columns that use ::uuid cast on empty string
-- (these fire on INSERT when no explicit account_id is provided)
ALTER TABLE amfs_memory_entries
    ALTER COLUMN account_id
    SET DEFAULT NULLIF(current_setting('amfs.current_account_id', true), '')::uuid;

ALTER TABLE amfs_outcomes
    ALTER COLUMN account_id
    SET DEFAULT NULLIF(current_setting('amfs.current_account_id', true), '')::uuid;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'amfs_decision_traces') THEN
        EXECUTE $a$ALTER TABLE amfs_decision_traces
            ALTER COLUMN account_id
            SET DEFAULT NULLIF(current_setting('amfs.current_account_id', true), '')::uuid$a$;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'amfs_detected_patterns') THEN
        EXECUTE $a$ALTER TABLE amfs_detected_patterns
            ALTER COLUMN account_id
            SET DEFAULT NULLIF(current_setting('amfs.current_account_id', true), '')::uuid$a$;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'amfs_immutable_traces') THEN
        EXECUTE $a$ALTER TABLE amfs_immutable_traces
            ALTER COLUMN account_id
            SET DEFAULT NULLIF(current_setting('amfs.current_account_id', true), '')::uuid$a$;
    END IF;
END $$;
