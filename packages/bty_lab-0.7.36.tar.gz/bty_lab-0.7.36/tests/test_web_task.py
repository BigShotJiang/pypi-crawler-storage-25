"""Tests for ``bty.web._task.TaskRunner``.

Subprocess invocations of cijoe are mocked - a real cijoe binary
isn't installed in the dev env's ``[web]`` extras, and we don't
want the test suite to depend on the network either way. Each test
seeds an in-memory machine record, kicks off a runner with a
synchronous fake (no thread spawn) for the actual ``_run`` body,
and asserts the resulting DB state.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from bty.web import _db
from bty.web._task import TaskRunner


def _seed_machine(state_path: Path, mac: str = "aa:bb:cc:dd:ee:ff") -> None:
    """Insert a machine row so the runner's UPDATEs have a target."""
    with _db.open_db(state_path) as conn:
        conn.execute(
            """
            INSERT INTO machines
                (mac, provisioning_mode, boot_policy, created_at, updated_at)
            VALUES (?, 'cijoe-online', 'flash', ?, ?)
            """,
            (mac, "2026-01-01T00:00:00+00:00", "2026-01-01T00:00:00+00:00"),
        )
        conn.commit()


@pytest.fixture
def runner(tmp_path: Path):
    state = tmp_path / "state.db"
    _db.init_db(state)
    publishes: list[None] = []
    runner = TaskRunner(
        state_path=state,
        publish_machines_changed=lambda: publishes.append(None),
        tasks_dir=tmp_path / "tasks",
        ssh_key_path=tmp_path / "key",
        cijoe_bin="cijoe-fake",
    )
    return runner, state, publishes


# ---------- _run synchronous path ------------------------------------------


def test_task_runner_records_success(runner) -> None:
    runner_obj, state, publishes = runner
    _seed_machine(state)

    completed = subprocess.CompletedProcess(args=[], returncode=0, stdout="ok\n", stderr="")
    with patch("bty.web._task.subprocess.run", return_value=completed):
        runner_obj._run("aa:bb:cc:dd:ee:ff", "/path/to/wf.yaml", "10.0.0.5")

    with _db.open_db(state) as conn:
        row = conn.execute(
            "SELECT last_task_status, last_task_run_at, last_task_output_path "
            "FROM machines WHERE mac = ?",
            ("aa:bb:cc:dd:ee:ff",),
        ).fetchone()
    assert row["last_task_status"] == "success"
    assert row["last_task_run_at"] is not None
    assert row["last_task_output_path"]
    out_dir = Path(row["last_task_output_path"])
    # cijoe stdout/stderr captured as sidecars next to the run dir.
    assert (out_dir / "cijoe.stdout").read_text() == "ok\n"
    # Two SSE publishes: running, then success.
    assert len(publishes) == 2


def test_task_runner_records_failed_on_nonzero_exit(runner) -> None:
    runner_obj, state, _ = runner
    _seed_machine(state)

    completed = subprocess.CompletedProcess(args=[], returncode=2, stdout="", stderr="boom\n")
    with patch("bty.web._task.subprocess.run", return_value=completed):
        runner_obj._run("aa:bb:cc:dd:ee:ff", "/path/to/wf.yaml", "10.0.0.5")

    with _db.open_db(state) as conn:
        row = conn.execute(
            "SELECT last_task_status FROM machines WHERE mac = ?",
            ("aa:bb:cc:dd:ee:ff",),
        ).fetchone()
    assert row["last_task_status"] == "failed"


def test_task_runner_records_failed_on_timeout(runner) -> None:
    runner_obj, state, _ = runner
    _seed_machine(state)

    err = subprocess.TimeoutExpired(cmd=["cijoe"], timeout=10)
    with patch("bty.web._task.subprocess.run", side_effect=err):
        runner_obj._run("aa:bb:cc:dd:ee:ff", "/path/to/wf.yaml", "10.0.0.5")

    with _db.open_db(state) as conn:
        row = conn.execute(
            "SELECT last_task_status, last_task_output_path FROM machines WHERE mac = ?",
            ("aa:bb:cc:dd:ee:ff",),
        ).fetchone()
    assert row["last_task_status"] == "failed"
    assert (
        (Path(row["last_task_output_path"]) / "error.txt").read_text().startswith("cijoe timed out")
    )


def test_task_runner_records_failed_on_missing_binary(runner) -> None:
    runner_obj, state, _ = runner
    _seed_machine(state)

    err = FileNotFoundError("[Errno 2] No such file: 'cijoe-fake'")
    with patch("bty.web._task.subprocess.run", side_effect=err):
        runner_obj._run("aa:bb:cc:dd:ee:ff", "/path/to/wf.yaml", "10.0.0.5")

    with _db.open_db(state) as conn:
        row = conn.execute(
            "SELECT last_task_status, last_task_output_path FROM machines WHERE mac = ?",
            ("aa:bb:cc:dd:ee:ff",),
        ).fetchone()
    assert row["last_task_status"] == "failed"
    assert (
        "cijoe binary not found" in (Path(row["last_task_output_path"]) / "error.txt").read_text()
    )


# ---------- transport config ------------------------------------------------


def test_task_runner_renders_transport_config(runner) -> None:
    runner_obj, state, _ = runner
    _seed_machine(state)

    completed = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
    with patch("bty.web._task.subprocess.run", return_value=completed):
        runner_obj._run("aa:bb:cc:dd:ee:ff", "/path/to/wf.yaml", "10.0.0.5")

    with _db.open_db(state) as conn:
        row = conn.execute(
            "SELECT last_task_output_path FROM machines WHERE mac = ?",
            ("aa:bb:cc:dd:ee:ff",),
        ).fetchone()
    config = (Path(row["last_task_output_path"]) / "transport.toml").read_text()
    assert 'hostname = "10.0.0.5"' in config
    assert "cijoe.transport.ssh" in config
    assert 'username = "root"' in config


# ---------- subprocess invocation -------------------------------------------


def test_task_runner_invokes_cijoe_with_task_and_config(runner) -> None:
    runner_obj, state, _ = runner
    _seed_machine(state)

    completed = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
    with patch("bty.web._task.subprocess.run", return_value=completed) as mock_run:
        runner_obj._run("aa:bb:cc:dd:ee:ff", "/path/to/wf.yaml", "10.0.0.5")

    args, kwargs = mock_run.call_args
    cmd = args[0]
    assert cmd[0] == "cijoe-fake"
    assert cmd[1] == "/path/to/wf.yaml"
    assert "--config" in cmd
    assert "--monitor" in cmd
    # Subprocess runs with cwd set to the run dir so cijoe's
    # cijoe-output/ lands there.
    assert kwargs["cwd"]


def test_kick_off_refuses_non_ip_target(runner) -> None:
    """``kick_off`` validates ``target_ip`` is a real IPv4/v6
    address before spawning the worker thread. Currently
    ``last_seen_ip`` is set from ``request.client.host`` (TCP
    source IP, network-layer guaranteed) so a non-IP value
    cannot reach this code path -- but :func:`_render_config`
    interpolates ``target_ip`` into a TOML string with f-strings,
    and a future code path that lets a header populate the field
    without validation would otherwise enable TOML injection.
    The boundary check protects regardless."""
    runner_obj, state, _ = runner
    _seed_machine(state)

    # No real subprocess; if kick_off doesn't short-circuit, the
    # spawned thread would try to invoke cijoe.
    with patch("bty.web._task.subprocess.run") as mock_run:
        for bad in (
            'host"; injected="x',  # break out of TOML string
            "10.0.0.1\n[evil]\nx = 1",  # newline-injected TOML key
            "not-an-ip",
            "",
        ):
            runner_obj.kick_off(
                mac="aa:bb:cc:dd:ee:ff",
                task_ref="/path/to/wf.yaml",
                target_ip=bad,
            )
    assert not mock_run.called
