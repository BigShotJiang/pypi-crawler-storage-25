"""Per-dialect translation from a FilterIntent into a backend-native
filter expression.

Each backend's `build_filter_expr` calls into one of these. Kept as
module-level fns rather than methods because they're pure — no
backend state needed — and grouping them here makes adding a new
dialect (e.g. Cypher, Mongo) a single-file change.
"""

from __future__ import annotations

from ..models import FilterIntent


def _escape_meili_value(v: str) -> str:
    return v.replace("\\", "\\\\").replace('"', '\\"')


def _escape_sql_value(v: str) -> str:
    return v.replace("'", "''")


def _meili_filter_expr(intent: FilterIntent) -> str:
    op = intent.operator
    field_name = intent.field
    value = _escape_meili_value(intent.value)
    if op == "NOT_CONTAINS":
        parts = [f'NOT {field_name} CONTAINS "{value}"']
        for extra in intent.extra_excludes:
            parts.append(f'NOT {field_name} CONTAINS "{_escape_meili_value(extra)}"')
    else:
        parts = [f'{field_name} {op} "{value}"']
    for af in intent.and_filters:
        if af.field:
            parts.append(_meili_filter_expr(af))
    return " AND ".join(parts)


def _sql_jsonb_clause(parent: str, child: str, op: str, value: str) -> str:
    """JSONB array-aware clause: matches if any element of `parent`'s array
    has `child` matching `value` under `op`. Works on Postgres + DuckDB
    when the column is JSONB / JSON."""
    if op == "CONTAINS":
        return (
            f"EXISTS (SELECT 1 FROM jsonb_array_elements({parent}) jae "
            f"WHERE jae->>'{child}' ILIKE '%{value}%')"
        )
    if op == "NOT_CONTAINS":
        return (
            f"NOT EXISTS (SELECT 1 FROM jsonb_array_elements({parent}) jae "
            f"WHERE jae->>'{child}' ILIKE '%{value}%')"
        )
    if op in ("=", "!="):
        return (
            f"EXISTS (SELECT 1 FROM jsonb_array_elements({parent}) jae "
            f"WHERE jae->>'{child}' {op} '{value}')"
        )
    return ""


def _sql_filter_expr(intent: FilterIntent) -> str:
    op = intent.operator
    field_name = intent.field
    value = _escape_sql_value(intent.value)

    # Dotted path → JSONB array-element form. One level deep is enough
    # for the common case (list[dict] of structured records).
    if field_name and "." in field_name:
        parent, _, child = field_name.partition(".")
        if "." in child:
            # Deeper paths fall back to in-memory match in the caller.
            return ""
        parts = [_sql_jsonb_clause(parent, child, op, value)]
        if op == "NOT_CONTAINS":
            for extra in intent.extra_excludes:
                parts.append(
                    _sql_jsonb_clause(
                        parent, child, "NOT_CONTAINS", _escape_sql_value(extra)
                    )
                )
        for af in intent.and_filters:
            if af.field:
                sub = _sql_filter_expr(af)
                if sub:
                    parts.append(sub)
        return " AND ".join(p for p in parts if p)

    if op == "NOT_CONTAINS":
        parts = [f"{field_name} NOT ILIKE '%{value}%'"]
        for extra in intent.extra_excludes:
            parts.append(f"{field_name} NOT ILIKE '%{_escape_sql_value(extra)}%'")
    else:
        parts = [f"{field_name} {op} '{value}'"]
    for af in intent.and_filters:
        if af.field:
            sub = _sql_filter_expr(af)
            if sub:
                parts.append(sub)
    return " AND ".join(parts)


def _qdrant_filter_dict(intent: FilterIntent) -> dict:
    """Compile a FilterIntent into a Qdrant Filter dict.

    Qdrant supports nested array fields via the `[]` suffix notation:
    `stock_data[].location_name`. Dotted paths are auto-converted —
    we assume list[dict], which is the common case.

    Operators map to:
      CONTAINS / =        → must:[{key,match:{text|value}}]
      NOT_CONTAINS / !=   → must_not:[{key,match:{text|value}}]
    """

    def _key(field: str) -> str:
        if "." in field:
            head, _, tail = field.partition(".")
            return f"{head}[].{tail}"
        return field

    def _condition(field: str, op: str, value: str) -> dict:
        if op in ("CONTAINS", "NOT_CONTAINS"):
            match = {"text": value}
        else:
            match = {"value": value}
        return {"key": _key(field), "match": match}

    must: list[dict] = []
    must_not: list[dict] = []

    if intent.field and intent.value:
        cond = _condition(intent.field, intent.operator, intent.value)
        if intent.operator in ("NOT_CONTAINS", "!="):
            must_not.append(cond)
            for extra in intent.extra_excludes:
                must_not.append(_condition(intent.field, intent.operator, extra))
        else:
            must.append(cond)

    for af in intent.and_filters:
        if not af.field or not af.value:
            continue
        cond = _condition(af.field, af.operator, af.value)
        if af.operator in ("NOT_CONTAINS", "!="):
            must_not.append(cond)
            for extra in af.extra_excludes:
                must_not.append(_condition(af.field, af.operator, extra))
        else:
            must.append(cond)

    out: dict = {}
    if must:
        out["must"] = must
    if must_not:
        out["must_not"] = must_not
    return out


def _sqlite_json1_clause(parent: str, child: str, op: str, value: str) -> str:
    """SQLite json1 array-aware clause. Uses LIKE + COLLATE NOCASE
    since SQLite has no ILIKE. Compatible with json1 (built into all
    modern SQLite builds).
    """
    if op == "CONTAINS":
        return (
            f"EXISTS (SELECT 1 FROM json_each({parent}) WHERE "
            f"json_extract(value, '$.{child}') LIKE '%{value}%' COLLATE NOCASE)"
        )
    if op == "NOT_CONTAINS":
        return (
            f"NOT EXISTS (SELECT 1 FROM json_each({parent}) WHERE "
            f"json_extract(value, '$.{child}') LIKE '%{value}%' COLLATE NOCASE)"
        )
    if op in ("=", "!="):
        cmp = "=" if op == "=" else "!="
        return (
            f"EXISTS (SELECT 1 FROM json_each({parent}) WHERE "
            f"json_extract(value, '$.{child}') {cmp} '{value}' COLLATE NOCASE)"
        )
    return ""


def _sqlite_filter_expr(intent: FilterIntent) -> str:
    """SQLite-flavoured SQL: LIKE + COLLATE NOCASE for case-insensitive
    matching (no ILIKE), json1 EXISTS for nested arrays."""
    op = intent.operator
    field_name = intent.field
    value = _escape_sql_value(intent.value)

    if field_name and "." in field_name:
        parent, _, child = field_name.partition(".")
        if "." in child:
            return ""
        parts = [_sqlite_json1_clause(parent, child, op, value)]
        if op == "NOT_CONTAINS":
            for extra in intent.extra_excludes:
                parts.append(
                    _sqlite_json1_clause(
                        parent, child, "NOT_CONTAINS", _escape_sql_value(extra)
                    )
                )
        for af in intent.and_filters:
            if af.field:
                sub = _sqlite_filter_expr(af)
                if sub:
                    parts.append(sub)
        return " AND ".join(p for p in parts if p)

    if op == "NOT_CONTAINS":
        parts = [f"{field_name} NOT LIKE '%{value}%' COLLATE NOCASE"]
        for extra in intent.extra_excludes:
            parts.append(
                f"{field_name} NOT LIKE '%{_escape_sql_value(extra)}%' COLLATE NOCASE"
            )
    elif op == "CONTAINS":
        parts = [f"{field_name} LIKE '%{value}%' COLLATE NOCASE"]
    else:
        parts = [f"{field_name} {op} '{value}' COLLATE NOCASE"]
    for af in intent.and_filters:
        if af.field:
            sub = _sqlite_filter_expr(af)
            if sub:
                parts.append(sub)
    return " AND ".join(parts)


def _lancedb_filter_expr(intent: FilterIntent) -> str:
    """LanceDB SQL (DataFusion-flavoured). Flat fields use the same
    syntax as the base SQL dialect; dotted paths return empty so the
    caller falls back to in-memory match — list[struct] doesn't have
    a clean predicate-substring form on LanceDB.
    """
    field_name = intent.field
    if field_name and "." in field_name:
        return ""
    return _sql_filter_expr(intent)


def _odata_filter_expr(intent: FilterIntent) -> str:
    op = intent.operator
    op_map = {"=": "eq", "!=": "ne", "<": "lt", "<=": "le", ">": "gt", ">=": "ge"}
    field_name = intent.field
    # Azure complex types use slash-separated paths
    # (e.g. stock_data/location_name). Convert dotted paths automatically.
    if field_name and "." in field_name:
        field_name = field_name.replace(".", "/")
    value = intent.value.replace("'", "''")
    if op == "NOT_CONTAINS":
        parts = [f"not search.ismatch('{value}', '{field_name}')"]
        for extra in intent.extra_excludes:
            esc = extra.replace("'", "''")
            parts.append(f"not search.ismatch('{esc}', '{field_name}')")
    elif op == "CONTAINS":
        parts = [f"search.ismatch('{value}', '{field_name}')"]
    else:
        parts = [f"{field_name} {op_map.get(op, op)} '{value}'"]
    for af in intent.and_filters:
        if af.field:
            parts.append(_odata_filter_expr(af))
    return " and ".join(parts)
