# tcknvkn (Python)

`tcknvkn`, Türkiye kimlik/vergi numarası doğrulama ihtiyacı olan projeler için hafif ve hızlı bir Python paketidir.  
Paket yalnızca doğrulama yapar; üretim işlemleri için uygulama tarafındaki iş akışınızı bozmadan entegre olur.

## Kurulum

```bash
pip install tcknvkn
```

## Hızlı Başlangıç

```python
from tcknvkn import (
    validate_tckn,
    validate_multiple_tckn,
    validate_vkn,
    validate_multiple_vkn,
)

tekil_tckn = validate_tckn("10000000146")
print(tekil_tckn.valid)   # True
print(tekil_tckn.errors)  # []

tekil_vkn = validate_vkn("1000036109")
print(tekil_vkn.valid)    # True

toplu = validate_multiple_tckn(["10000000146", "99999999999"])
for sonuc in toplu:
    print(sonuc.value, sonuc.valid)
```

## API Özeti

- `validate_tckn(value: str) -> ValidationResult`
- `validate_multiple_tckn(values: list[str]) -> list[ValidationResult]`
- `validate_vkn(value: str) -> ValidationResult`
- `validate_multiple_vkn(values: list[str]) -> list[ValidationResult]`

## ValidationResult Modeli

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    value: str
    errors: list[str]
```

## Ayrıntılı Dokümantasyon

Detaylı kullanım ve tüm doğrulama kuralları için: `docs/API_TR.md`

## Faydalı Bağlantı

- TC numarası test akışı: https://www.tcknvkn.com/tc-uret
- Kütüphaneler merkezi: https://www.tcknvkn.com/kutuphaneler
- Python kütüphane sayfası: https://www.tcknvkn.com/kutuphaneler/python

## Test Çalıştırma

```bash
python -m unittest discover -s tests
```

## Lisans

MIT
