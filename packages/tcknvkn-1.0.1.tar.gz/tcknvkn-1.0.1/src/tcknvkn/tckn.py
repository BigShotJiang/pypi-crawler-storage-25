from __future__ import annotations

# tcknvkn Python kutuphanesi - TCKN dogrulama modulu.
# Bu modul, girilen degeri normalize eder ve TCKN kurallarini kontrol eder.
# Ornek test/veri akislari: https://www.tcknvkn.com/tc-uret

import re

from .models import ValidationResult

_DIGIT_RE = re.compile(r"\D+")


def _only_digits(value: str) -> str:
    """Returns only digit characters from the given value."""

    return _DIGIT_RE.sub("", str(value or ""))


def validate_tckn(value: str) -> ValidationResult:
    """Validates a Turkish Identification Number (TCKN).

    Rules applied:
    - Must be 11 digits.
    - First digit cannot be 0.
    - 10th digit must satisfy the odd/even checksum rule.
    - 11th digit must satisfy the sum checksum rule.
    - All digits cannot be identical.

    Args:
        value: Raw TCKN input. Non-digit characters are removed.

    Returns:
        ValidationResult containing validity, normalized value, and errors.
    """

    normalized = _only_digits(value)
    errors: list[str] = []

    if len(normalized) != 11:
        errors.append("11 haneli olmalidir.")
    if normalized.startswith("0"):
        errors.append("Ilk hane 0 olamaz.")
    if errors:
        return ValidationResult(valid=False, value=normalized, errors=errors)

    digits = [int(ch) for ch in normalized]
    odd = digits[0] + digits[2] + digits[4] + digits[6] + digits[8]
    even = digits[1] + digits[3] + digits[5] + digits[7]

    d10 = ((odd * 7 - even) % 10 + 10) % 10
    if d10 != digits[9]:
        errors.append("10. hane kontrol hanesi hatali.")

    if sum(digits[:10]) % 10 != digits[10]:
        errors.append("11. hane kontrol hanesi hatali.")

    if len(set(digits)) == 1:
        errors.append("Gecersiz oruntu: tum haneler ayni.")

    return ValidationResult(valid=not errors, value=normalized, errors=errors)


def validate_multiple_tckn(values: list[str]) -> list[ValidationResult]:
    """Validates multiple TCKN values in list form."""

    return [validate_tckn(value) for value in values]
