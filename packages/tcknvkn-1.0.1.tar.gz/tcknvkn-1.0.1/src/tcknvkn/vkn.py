from __future__ import annotations

import re

from .models import ValidationResult

_DIGIT_RE = re.compile(r"\D+")


def _only_digits(value: str) -> str:
    """Returns only digit characters from the given value."""

    return _DIGIT_RE.sub("", str(value or ""))


def _vkn_checksum(digits: list[int]) -> int:
    """Computes the expected VKN checksum digit from the first 9 digits."""

    total = 0
    for i in range(9):
        tmp = (digits[i] + (9 - i)) % 10
        res = (tmp * (2 ** (9 - i))) % 9
        if tmp != 0 and res == 0:
            res = 9
        total += res
    return (10 - (total % 10)) % 10


def validate_vkn(value: str) -> ValidationResult:
    """Validates a Turkish Tax Number (VKN).

    Rules applied:
    - Must be 10 digits.
    - Last digit must match checksum.
    - All digits cannot be identical.

    Args:
        value: Raw VKN input. Non-digit characters are removed.

    Returns:
        ValidationResult containing validity, normalized value, and errors.
    """

    normalized = _only_digits(value)
    errors: list[str] = []

    if len(normalized) != 10:
        errors.append("10 haneli olmalidir.")
        return ValidationResult(valid=False, value=normalized, errors=errors)

    digits = [int(ch) for ch in normalized]
    if _vkn_checksum(digits) != digits[9]:
        errors.append("Son hane kontrol hanesi hatali.")
    if len(set(digits)) == 1:
        errors.append("Gecersiz oruntu: tum haneler ayni.")

    return ValidationResult(valid=not errors, value=normalized, errors=errors)


def validate_multiple_vkn(values: list[str]) -> list[ValidationResult]:
    """Validates multiple VKN values in list form."""

    return [validate_vkn(value) for value in values]
