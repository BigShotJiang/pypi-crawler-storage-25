"""Public exports for the tcknvkn Python package.

The package provides validation helpers for:
- Turkish Identification Number (TCKN)
- Turkish Tax Number (VKN)
"""

from .models import ValidationResult
from .tckn import validate_multiple_tckn, validate_tckn
from .vkn import validate_multiple_vkn, validate_vkn

__all__ = [
    "ValidationResult",
    "validate_tckn",
    "validate_multiple_tckn",
    "validate_vkn",
    "validate_multiple_vkn",
]
