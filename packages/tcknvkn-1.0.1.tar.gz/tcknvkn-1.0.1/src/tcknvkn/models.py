from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ValidationResult:
    """Represents the output of a validation operation.

    Attributes:
        valid: True when the value passes all validation rules.
        value: Normalized value used during validation.
        errors: Validation rule failures in readable text form.
    """

    valid: bool
    value: str
    errors: list[str] = field(default_factory=list)
