"""numbering 모듈 단위 테스트."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from hwp_thesis_mcp.numbering import (  # noqa: E402
    CiteRegistry, chapter_heading, section_heading, subsection_heading,
    table_label, figure_label, render_paragraph_text,
)
from hwp_thesis_mcp.parser import Reference, Paragraph, TextRun  # noqa: E402


def test_headings() -> None:
    assert chapter_heading(1, "서론") == "제 1 장  서론"
    assert section_heading(1, 2, "연구 목적") == "1.2 연구 목적"
    assert subsection_heading(1, 2, 3, "세부") == "1.2.3 세부"


def test_table_figure_labels() -> None:
    assert table_label("2-1", 2, 1, "모델 비교") == "[표 2-1] 모델 비교"
    assert figure_label("", 3, 2, "구조도") == "[그림 3-2] 구조도"


def test_cite_registry_order() -> None:
    refs = [Reference(id=f"r{i}", text=f"text{i}") for i in range(3)]
    reg = CiteRegistry(refs)
    # 등장 순서대로 번호 부여
    assert reg.number_for("r2") == 1
    assert reg.number_for("r0") == 2
    assert reg.number_for("r2") == 1   # 재호출은 기존 번호
    assert reg.number_for("r1") == 3


def test_cite_registry_sorted_references() -> None:
    refs = [Reference(id=f"r{i}", text=f"text{i}") for i in range(3)]
    reg = CiteRegistry(refs)
    reg.number_for("r2"); reg.number_for("r0")
    # sorted: 등장 순서 (r2, r0), 등장 안한 r1은 뒤
    ordered = reg.sorted_references(refs)
    assert [r.id for r in ordered] == ["r2", "r0", "r1"]


def test_render_paragraph_text_plain() -> None:
    p = Paragraph(runs=[TextRun("text", "안녕")])
    refs = [Reference(id="x", text="ref")]
    parts = render_paragraph_text(p, CiteRegistry(refs))
    assert parts == [{"text": "안녕", "style": "normal"}]


def test_render_paragraph_text_cite() -> None:
    p = Paragraph(runs=[
        TextRun("text", "본문 "),
        TextRun("cite", ref="x"),
        TextRun("text", " 끝"),
    ])
    refs = [Reference(id="x", text="ref")]
    parts = render_paragraph_text(p, CiteRegistry(refs))
    texts = [p["text"] for p in parts]
    assert texts == ["본문 ", "[1]", " 끝"]


def test_render_paragraph_text_em_term() -> None:
    p = Paragraph(runs=[
        TextRun("em", "강조"),
        TextRun("term", "용어"),
    ])
    parts = render_paragraph_text(p, CiteRegistry([]))
    assert parts == [
        {"text": "강조", "style": "em"},
        {"text": "용어", "style": "term"},
    ]
