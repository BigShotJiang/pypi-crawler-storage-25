"""모든 프리셋 JSON이 _schema.json에 부합하는지 검증."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

_ROOT = Path(__file__).resolve().parent.parent
_PRESETS = _ROOT / "hwp_thesis_mcp" / "presets"


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _iter_presets():
    for p in _PRESETS.glob("*.json"):
        if p.name.startswith("_"):
            continue
        yield p


@pytest.fixture(scope="module")
def schema() -> dict:
    return _load_json(_PRESETS / "_schema.json")


@pytest.mark.parametrize("preset_path", list(_iter_presets()), ids=lambda p: p.name)
def test_preset_conforms_to_schema(preset_path: Path, schema: dict) -> None:
    jsonschema = pytest.importorskip("jsonschema")
    data = _load_json(preset_path)
    jsonschema.validate(data, schema)


def test_styles_loader(tmp_path: Path) -> None:
    """styles.load_stylesheet이 각 프리셋을 실제로 읽는지."""
    sys.path.insert(0, str(_ROOT))
    from hwp_thesis_mcp.styles import load_stylesheet
    for p in _iter_presets():
        ss = load_stylesheet(preset=p.stem)
        assert ss.page.width_cm > 0
        assert ss.page.height_cm > 0
        assert len(ss.styles) > 0, f"{p.name} has no styles"
