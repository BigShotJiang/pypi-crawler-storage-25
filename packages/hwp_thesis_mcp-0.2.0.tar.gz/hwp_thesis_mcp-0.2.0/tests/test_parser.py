"""parser 모듈 단위 테스트. HWP 불필요 — 순수 XML 파싱."""
from __future__ import annotations

import sys
from pathlib import Path
from textwrap import dedent

import pytest

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from hwp_thesis_mcp.parser import parse_thesis, Meta, Paragraph, Table, Figure, TextRun  # noqa: E402


def _tmp_xml(tmp_path: Path, content: str) -> Path:
    p = tmp_path / "t.xml"
    p.write_text(dedent(content).strip(), encoding="utf-8")
    return p


def test_meta_basic(tmp_path: Path) -> None:
    xml = _tmp_xml(tmp_path, """
        <?xml version="1.0" encoding="UTF-8"?>
        <thesis version="1.0">
          <meta>
            <university>숭실대학교</university>
            <graduate-school>일반대학원</graduate-school>
            <department lang="ko">인공지능학과</department>
            <department lang="en">Department of AI</department>
            <degree>석사</degree>
            <title lang="ko">한글 제목</title>
            <title lang="en">English Title</title>
            <author lang="ko">이윤복</author>
            <author lang="en">Lee Yunbok</author>
            <advisor role="주">노동건</advisor>
            <date year="2026" month="6"/>
            <committee>
              <examiner role="위원장">박심사</examiner>
              <examiner>최위원</examiner>
              <examiner>정위원</examiner>
            </committee>
          </meta>
        </thesis>
    """)
    doc = parse_thesis(xml)
    assert doc.meta.university == "숭실대학교"
    assert doc.meta.graduate_school == "일반대학원"
    assert doc.meta.department_ko == "인공지능학과"
    assert doc.meta.department_en == "Department of AI"
    assert doc.meta.degree == "석사"
    assert doc.meta.title_ko == "한글 제목"
    assert doc.meta.title_en == "English Title"
    assert doc.meta.author_ko == "이윤복"
    assert doc.meta.author_en == "Lee Yunbok"
    assert doc.meta.advisor_main == "노동건"
    assert doc.meta.year == "2026"
    assert doc.meta.month == "6"
    assert doc.meta.chair == "박심사"
    assert doc.meta.examiners == ["최위원", "정위원"]


def test_empty_meta(tmp_path: Path) -> None:
    xml = _tmp_xml(tmp_path, """
        <?xml version="1.0" encoding="UTF-8"?>
        <thesis version="1.0">
          <meta>
            <title lang="ko"></title>
            <author lang="ko"></author>
          </meta>
        </thesis>
    """)
    doc = parse_thesis(xml)
    assert doc.meta.title_ko == ""
    assert doc.meta.author_ko == ""


def test_body_chapters_sections(tmp_path: Path) -> None:
    xml = _tmp_xml(tmp_path, """
        <?xml version="1.0" encoding="UTF-8"?>
        <thesis version="1.0">
          <body>
            <chapter title="서론">
              <section title="연구 배경">
                <p>첫 문단</p>
                <p>둘째 문단</p>
              </section>
              <section title="연구 목적">
                <subsection title="세부 목표">
                  <p>항 내용</p>
                </subsection>
              </section>
            </chapter>
            <chapter title="관련 연구"/>
          </body>
        </thesis>
    """)
    doc = parse_thesis(xml)
    assert len(doc.chapters) == 2
    ch1 = doc.chapters[0]
    assert ch1.title == "서론"
    assert len(ch1.sections) == 2
    assert ch1.sections[0].title == "연구 배경"
    assert len(ch1.sections[0].blocks) == 2
    assert isinstance(ch1.sections[0].blocks[0], Paragraph)
    assert ch1.sections[1].subsections[0].title == "세부 목표"


def test_cite_in_paragraph(tmp_path: Path) -> None:
    xml = _tmp_xml(tmp_path, """
        <?xml version="1.0" encoding="UTF-8"?>
        <thesis version="1.0">
          <body>
            <chapter title="본문">
              <section title="">
                <p>이전 연구<cite ref="smith2020"/>에서는<cite ref="jones2021"/>...</p>
              </section>
            </chapter>
          </body>
          <references>
            <ref id="smith2020">Smith, A., 2020.</ref>
            <ref id="jones2021">Jones, B., 2021.</ref>
          </references>
        </thesis>
    """)
    doc = parse_thesis(xml)
    assert len(doc.references) == 2
    para = doc.chapters[0].sections[0].blocks[0]
    assert isinstance(para, Paragraph)
    cite_refs = [r.ref for r in para.runs if r.kind == "cite"]
    assert cite_refs == ["smith2020", "jones2021"]


def test_table_and_figure(tmp_path: Path) -> None:
    xml = _tmp_xml(tmp_path, """
        <?xml version="1.0" encoding="UTF-8"?>
        <thesis version="1.0">
          <body>
            <chapter title="ch">
              <section title="sec">
                <table id="2-1" caption="모델 비교">
                  <thead><tr><th>이름</th><th>크기</th></tr></thead>
                  <tbody>
                    <tr><td>GPT</td><td>175B</td></tr>
                    <tr><td>BERT</td><td>340M</td></tr>
                  </tbody>
                </table>
                <figure id="2-1" src="img/a.png" caption="구조도"/>
              </section>
            </chapter>
          </body>
        </thesis>
    """)
    doc = parse_thesis(xml)
    blocks = doc.chapters[0].sections[0].blocks
    tables = [b for b in blocks if isinstance(b, Table)]
    figures = [b for b in blocks if isinstance(b, Figure)]
    assert len(tables) == 1 and tables[0].caption == "모델 비교"
    assert tables[0].header == [["이름", "크기"]]
    assert tables[0].rows == [["GPT", "175B"], ["BERT", "340M"]]
    assert figures[0].src == "img/a.png" and figures[0].caption == "구조도"


def test_abstract_ko_en(tmp_path: Path) -> None:
    xml = _tmp_xml(tmp_path, """
        <?xml version="1.0" encoding="UTF-8"?>
        <thesis version="1.0">
          <abstract lang="ko">
            <p>국문 초록 내용.</p>
            <keywords>키워드1, 키워드2</keywords>
          </abstract>
          <abstract lang="en">
            <p>English abstract.</p>
            <keywords>k1, k2</keywords>
          </abstract>
        </thesis>
    """)
    doc = parse_thesis(xml)
    assert doc.abstract_ko is not None
    assert doc.abstract_ko.keywords == "키워드1, 키워드2"
    assert doc.abstract_en.keywords == "k1, k2"


def test_references_and_style(tmp_path: Path) -> None:
    xml = _tmp_xml(tmp_path, """
        <?xml version="1.0" encoding="UTF-8"?>
        <thesis version="1.0">
          <references style="IEEE">
            <ref id="a">Author A, Title, 2020.</ref>
            <ref id="b">Author B, Title, 2021.</ref>
          </references>
        </thesis>
    """)
    doc = parse_thesis(xml)
    assert doc.reference_style == "IEEE"
    assert len(doc.references) == 2
    assert doc.references[0].id == "a"


def test_xml_with_comments(tmp_path: Path) -> None:
    """XML 주석이 파서를 깨뜨리지 않아야 함 (regression test)."""
    xml = _tmp_xml(tmp_path, """
        <?xml version="1.0" encoding="UTF-8"?>
        <thesis version="1.0">
          <!-- 메타 -->
          <meta>
            <title lang="ko">test</title>
          </meta>
          <body>
            <!-- 여기는 주석 -->
            <chapter title="ch">
              <section title="sec">
                <!-- 섹션 주석 -->
                <p>내용</p>
              </section>
            </chapter>
          </body>
        </thesis>
    """)
    doc = parse_thesis(xml)
    assert doc.meta.title_ko == "test"
    assert len(doc.chapters) == 1
