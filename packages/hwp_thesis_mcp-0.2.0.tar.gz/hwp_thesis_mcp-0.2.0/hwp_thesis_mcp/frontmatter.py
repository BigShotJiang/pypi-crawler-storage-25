"""겉표지 / 백지간지 / 표제지 / 속표지 / 인준서 렌더.

필수안내서 1~5번 항목. 빈 meta 값은 placeholder로 대체한다.
"""
from __future__ import annotations

from .hwp_controller import HwpController
from .parser import Meta
from .styles import StyleSheet


_PH = {
    "title_ko":   "[국문 제목]",
    "title_en":   "[English Title]",
    "author_ko":  "[성 명]",
    "author_en":  "[Author Name]",
    "advisor":    "[지도교수]",
    "department_ko": "[학과]",
    "department_en": "[Department]",
    "chair":      "[심사위원장]",
    "examiner":   "[심사위원]",
    "year":       "____",
    "month":      "__",
}


def _or(v: str, ph: str) -> str:
    return v if v else ph


def _degree_label(degree: str) -> str:
    # "석사" 또는 "박사"
    d = degree or "석사"
    return f"{d} 학위 논문"


def _submission_label(degree: str) -> str:
    d = degree or "석사"
    return f"이 논문은 {d}학위 논문으로 제출함"


def _approval_title(author: str, degree: str) -> str:
    a = _or(author, _PH["author_ko"])
    d = degree or "석사"
    return f"{a}의 {d}학위 논문을 인준함"


def _date_label(year: str, month: str) -> str:
    y = _or(year, _PH["year"])
    m = _or(month, _PH["month"])
    return f"{y}년 {m}월"


def _write_cover_like(hwp: HwpController, ss: StyleSheet, meta: Meta,
                      show_submission: bool, show_advisor: bool) -> None:
    """겉표지/표제지/속표지 공통 레이아웃."""
    # 1. 학위 논문 (상단)
    hwp.write_paragraph(_degree_label(meta.degree), ss.get("cover_degree"))
    hwp.empty_paragraph(2)

    # 2. 국문 제목/부제목
    hwp.write_paragraph(_or(meta.title_ko, _PH["title_ko"]), ss.get("cover_title_kr"))
    if meta.subtitle_ko:
        hwp.write_paragraph(meta.subtitle_ko, ss.get("cover_subtitle_kr"))
    hwp.empty_paragraph(1)

    # 3. 영문 제목/부제목
    hwp.write_paragraph(_or(meta.title_en, _PH["title_en"]), ss.get("cover_title_en"))
    if meta.subtitle_en:
        hwp.write_paragraph(meta.subtitle_en, ss.get("cover_subtitle_en"))
    hwp.empty_paragraph(1)

    # 4. 지도교수 (속표지만)
    if show_advisor:
        advisor = _or(meta.advisor_main, _PH["advisor"])
        hwp.write_paragraph(f"지도교수  {advisor}", ss.get("cover_subtitle_kr"))
        hwp.empty_paragraph(1)

    # 5. "이 논문은 ~ 제출함" (속표지만)
    if show_submission:
        hwp.write_paragraph(_submission_label(meta.degree), ss.get("cover_degree"))
        hwp.empty_paragraph(2)
    else:
        hwp.empty_paragraph(3)

    # 6. 날짜
    hwp.write_paragraph(_date_label(meta.year, meta.month), ss.get("cover_date"))
    hwp.empty_paragraph(1)

    # 7. 대학교 / 대학원
    uni = meta.university or "숭실대학교"
    gs = meta.graduate_school or "대학원"
    hwp.write_paragraph(f"{uni}  {gs}", ss.get("cover_university"))

    # 8. 학과
    hwp.write_paragraph(_or(meta.department_ko, _PH["department_ko"]),
                        ss.get("cover_department"))

    # 9. 성명
    hwp.write_paragraph(_or(meta.author_ko, _PH["author_ko"]),
                        ss.get("cover_author"))


def render_cover(hwp: HwpController, ss: StyleSheet, meta: Meta) -> None:
    """1. 겉표지"""
    _write_cover_like(hwp, ss, meta, show_submission=False, show_advisor=False)
    hwp.break_page()


def render_blank_page(hwp: HwpController) -> None:
    """2. 백지간지"""
    hwp.break_page()


def render_title_page(hwp: HwpController, ss: StyleSheet, meta: Meta) -> None:
    """3. 표제지 (겉표지와 동일)"""
    _write_cover_like(hwp, ss, meta, show_submission=False, show_advisor=False)
    hwp.break_page()


def render_inner_title_page(hwp: HwpController, ss: StyleSheet, meta: Meta) -> None:
    """4. 속표지 (지도교수 + 제출문구 포함)"""
    _write_cover_like(hwp, ss, meta, show_submission=True, show_advisor=True)
    hwp.break_page()


def render_approval_page(hwp: HwpController, ss: StyleSheet, meta: Meta) -> None:
    """5. 인준서. 심사위원 수는 프리셋의 committee_size 기준 (석사 3, 박사 5)."""
    hwp.empty_paragraph(3)
    hwp.write_paragraph(_approval_title(meta.author_ko, meta.degree),
                        ss.get("approval_title"))
    hwp.empty_paragraph(4)

    chair = _or(meta.chair, _PH["chair"])
    examiners = list(meta.examiners) if meta.examiners else []
    # 전체 심사위원 수 = committee_size (위원장 포함)
    # 위원장 1 + 일반위원 (committee_size - 1)
    non_chair_count = max(0, ss.committee_size - 1)
    while len(examiners) < non_chair_count:
        examiners.append(_PH["examiner"])

    hwp.write_paragraph(f"심 사 위 원 장    {chair}  (인)", ss.get("approval_examiner"))
    hwp.empty_paragraph(1)
    for ex in examiners[:non_chair_count]:
        hwp.write_paragraph(f"심 사 위 원      {ex}  (인)", ss.get("approval_examiner"))
        hwp.empty_paragraph(1)

    hwp.empty_paragraph(3)
    hwp.write_paragraph(_date_label(meta.year, meta.month), ss.get("approval_examiner"))
    hwp.empty_paragraph(1)
    uni = meta.university or "숭실대학교"
    gs = meta.graduate_school or "대학원"
    hwp.write_paragraph(f"{uni}  {gs}", ss.get("approval_title"))

    hwp.break_page()
