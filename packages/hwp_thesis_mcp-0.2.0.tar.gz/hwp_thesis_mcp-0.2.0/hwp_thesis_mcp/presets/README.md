# Presets (학교/학위별 양식)

각 JSON 파일이 한 학교·학위의 논문 서식을 정의합니다. 변환 시 `--preset <이름>` 플래그로 선택.

## 네이밍 규칙

```
<학교약칭>_<학위>[.json]
```

- `ssu_masters.json` — 숭실대학교 일반대학원 석사
- `ssu_phd.json` — 숭실대학교 일반대학원 박사 (예정)
- `snu_masters.json` — 서울대학교 석사 (예정)
- ...

## 새 프리셋 추가하기

1. 기준 대학의 논문 작성 필수안내서(PDF)를 구해서 서식 조항 확인
2. 기존 `ssu_masters.json` 복사해 `<school>_<degree>.json`으로 저장
3. 다음 항목 수정:
   - `university` / `graduate-school` / `degree` 기본값
   - `paper_size` (판종)
   - `margins` (여백)
   - `styles` 각 항목의 `font` / `size_pt` / `bold` / `align` / `line_spacing_pct` / `indent_cm`
   - `document_order` (페이지 순서)
4. 테스트: `hwp-thesis-convert hwp_thesis_mcp/template.xml -o test.hwp --preset <학교>_<학위>`

## 주요 스타일 키

| 키 | 용도 |
|---|---|
| `cover_degree` | 표지 "석/박사 학위 논문" |
| `cover_title_kr` / `cover_title_en` | 국/영문 제목 |
| `cover_subtitle_kr` / `cover_subtitle_en` | 부제목 |
| `cover_university` / `cover_department` / `cover_author` | 대학/학과/성명 |
| `approval_title` / `approval_examiner` | 인준서 |
| `toc_heading` / `toc_chapter` / `toc_section` / `toc_subsection` | 목차 |
| `abstract_kr_title` / `abstract_kr_body` | 국문초록 |
| `abstract_en_title` / `abstract_en_body` | 영문초록 |
| `chapter_title` / `section_title` / `subsection_title` / `body_text` | 본문 |
| `reference_heading` / `reference_item` | 참고문헌 |
| `appendix_heading` | 부록 |
| `table_caption` / `figure_caption` | 캡션 |

## 학위별 차이 처리

`committee_size` 필드로 필수 심사위원 수 지정 (석사 3, 박사 5 등).

```json
{
  "degree": "석사",
  "committee_size": 3,
  ...
}
```
