"""hwp-thesis-mcp — 한국 대학원 학위논문 HWP 자동 변환 MCP 서버."""
__version__ = "0.2.0"
