"""논문목차 / 표목차 / 그림목차 자동 생성.

쪽번호는 HWP 빌드 시점에 확정되지 않으므로 v1은 쪽번호를 비워둔다.
(HWP의 '목차 만들기' 기능으로 후처리하거나, 추후 2-pass로 채울 수 있음)
"""
from __future__ import annotations

from .hwp_controller import HwpController
from .parser import ThesisDoc, Paragraph, Table, Figure
from .styles import StyleSheet


_TOC_WIDTH_CHAPTER = 36  # toc_chapter (13pt)는 글자가 커서 짧게
_TOC_WIDTH_SECTION = 42  # toc_section/subsection (11pt)


def toc_marker(key: str) -> str:
    """본문 렌더 후 실제 페이지 번호로 치환할 유니크 마커."""
    return f"@@PG:{key}@@"


def _toc_line(title: str, marker_key: str, indent: int = 0,
              width: int | None = None) -> str:
    """제목 + 점선 + 페이지 마커. level에 따라 width 자동 선택.
    주의: `·`(U+00B7) 문자는 한글 폰트에서 full-width(2 units)로 렌더됨.
    indent는 텍스트 앞 전각공백으로 직접 처리 — HWP가 숫자 prefix("1.1")를
    auto-list로 인식해 paragraph indent를 무시하는 경우를 회피하기 위함."""
    if width is None:
        width = _TOC_WIDTH_CHAPTER if indent == 0 else _TOC_WIDTH_SECTION
    w = max(width - indent * 3, 10)
    visual = sum(2 if ord(c) > 127 else 1 for c in title)
    filler = max((w - visual - 2) // 2, 3)
    # 전각공백(U+3000) 2개당 한 레벨 — 한글 폰트에서 full-width라 일관성 있음
    prefix = "\u3000" * (indent * 2)
    return f"{prefix}{title} {'·' * filler} {toc_marker(marker_key)}"


def render_toc(hwp: HwpController, ss: StyleSheet, doc: ThesisDoc) -> None:
    """7. 논문목차"""
    hwp.write_paragraph("목  차", ss.get("toc_heading"))
    hwp.empty_paragraph(1)

    # 초록도 목차에 포함
    if doc.abstract_ko is not None:
        hwp.write_paragraph(
            _toc_line("국문초록", "abstract_ko", 0), ss.get("toc_section"))
    if doc.abstract_en is not None:
        hwp.write_paragraph(
            _toc_line("ABSTRACT", "abstract_en", 0), ss.get("toc_section"))
    if doc.abstract_ko or doc.abstract_en:
        hwp.empty_paragraph(1)

    for ci, ch in enumerate(doc.chapters, start=1):
        hwp.write_paragraph(
            _toc_line(f"제 {ci} 장  {ch.title}", f"ch{ci}", 0),
            ss.get("toc_chapter"),
        )
        for si, sec in enumerate(ch.sections, start=1):
            hwp.write_paragraph(
                _toc_line(f"{ci}.{si}  {sec.title}", f"ch{ci}s{si}", 1),
                ss.get("toc_section"),
            )
            for sub_i, sub in enumerate(sec.subsections, start=1):
                hwp.write_paragraph(
                    _toc_line(
                        f"{ci}.{si}.{sub_i}  {sub.title}",
                        f"ch{ci}s{si}sub{sub_i}",
                        2,
                    ),
                    ss.get("toc_subsection"),
                )

    hwp.empty_paragraph(1)
    if doc.references:
        hwp.write_paragraph(
            _toc_line("참고문헌", "references", 0), ss.get("toc_chapter"))
    for ai, ap in enumerate(doc.appendices, start=1):
        hwp.write_paragraph(
            _toc_line(f"부 록  {ap.title}", f"appendix{ai}", 0),
            ss.get("toc_chapter"),
        )

    hwp.break_page()


def _iter_tables(doc: ThesisDoc):
    for ci, ch in enumerate(doc.chapters, start=1):
        seq = 0
        for b in ch.blocks:
            if isinstance(b, Table):
                seq += 1
                yield ci, seq, b
        for sec in ch.sections:
            for b in sec.blocks:
                if isinstance(b, Table):
                    seq += 1
                    yield ci, seq, b
            for ss in sec.subsections:
                for b in ss.blocks:
                    if isinstance(b, Table):
                        seq += 1
                        yield ci, seq, b


def _iter_figures(doc: ThesisDoc):
    for ci, ch in enumerate(doc.chapters, start=1):
        seq = 0
        for b in ch.blocks:
            if isinstance(b, Figure):
                seq += 1
                yield ci, seq, b
        for sec in ch.sections:
            for b in sec.blocks:
                if isinstance(b, Figure):
                    seq += 1
                    yield ci, seq, b
            for ss in sec.subsections:
                for b in ss.blocks:
                    if isinstance(b, Figure):
                        seq += 1
                        yield ci, seq, b


def render_table_list(hwp: HwpController, ss: StyleSheet, doc: ThesisDoc) -> None:
    """8-1. 표 목차 (내용이 없어도 페이지 생성)"""
    hwp.write_paragraph("표 목 차", ss.get("toc_heading"))
    hwp.empty_paragraph(1)

    items = list(_iter_tables(doc))
    if not items:
        hwp.write_paragraph("", ss.get("toc_section"))
    else:
        for ci, seq, t in items:
            tid = t.id or f"{ci}-{seq}"
            hwp.write_paragraph(
                _toc_line(f"[표 {tid}]  {t.caption}", f"table_{tid}", 0),
                ss.get("toc_section"),
            )

    hwp.break_page()


def render_figure_list(hwp: HwpController, ss: StyleSheet, doc: ThesisDoc) -> None:
    """8-2. 그림 목차 (내용이 없어도 페이지 생성)"""
    hwp.write_paragraph("그 림 목 차", ss.get("toc_heading"))
    hwp.empty_paragraph(1)

    items = list(_iter_figures(doc))
    if not items:
        hwp.write_paragraph("", ss.get("toc_section"))
    else:
        for ci, seq, f in items:
            fid = f.id or f"{ci}-{seq}"
            hwp.write_paragraph(
                _toc_line(f"[그림 {fid}]  {f.caption}", f"figure_{fid}", 0),
                ss.get("toc_section"),
            )

    hwp.break_page()
