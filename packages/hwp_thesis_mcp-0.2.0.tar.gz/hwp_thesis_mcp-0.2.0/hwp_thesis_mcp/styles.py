"""스타일 로더.

src/ssu_thesis_styles.json을 읽어 Style 객체로 변환.
각 Style은 renderer_hwp.py에서 HwpController.apply_style()에 전달된다.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class Style:
    name: str = ""
    font: str = "신명조"
    size_pt: int = 11
    bold: bool = False
    italic: bool = False
    align: str = "justify"           # left, right, center, justify
    line_spacing_pct: int = 200
    first_indent_pt: int = 0
    left_indent_cm: float = 0.0
    hanging_indent_cm: float = 0.0
    space_before_cm: float = 0.0
    space_after_cm: float = 0.0


@dataclass
class PageConfig:
    width_cm: float = 18.2
    height_cm: float = 25.7
    left_cm: float = 2.0
    right_cm: float = 2.0
    top_cm: float = 2.5
    bottom_cm: float = 2.5


@dataclass
class StyleSheet:
    page: PageConfig = field(default_factory=PageConfig)
    styles: dict[str, Style] = field(default_factory=dict)
    # 프리셋 메타 (학교/학위별 구조)
    degree: str = ""
    committee_size: int = 3
    university: str = ""
    graduate_school: str = ""

    def get(self, key: str) -> Style:
        if key in self.styles:
            return self.styles[key]
        return Style(name=key)


def _style_from_dict(key: str, d: dict) -> Style:
    return Style(
        name=d.get("name", key),
        font=d.get("font", "신명조"),
        size_pt=int(d.get("size_pt", 11)),
        bold=bool(d.get("bold", False)),
        italic=bool(d.get("italic", False)),
        align=d.get("align", "justify"),
        line_spacing_pct=int(d.get("line_spacing_pct", 200)),
        first_indent_pt=int(d.get("first_line_indent_pt", 0)),
        left_indent_cm=float(d.get("indent_cm", 0.0)),
        hanging_indent_cm=float(d.get("hanging_indent_cm", 0.0)),
        # top_margin_cm은 "페이지 상단 여백" 의미이며 문단 PrevSpacing과 다르다.
        # 페이지 상단 여백은 page config로 처리하고 여기선 무시.
        space_before_cm=float(d.get("space_before_cm", 0.0)),
        space_after_cm=float(d.get("space_after_cm", 0.0)),
    )


def load_stylesheet(
    json_path: Optional[Path] = None,
    preset: Optional[str] = None,
) -> StyleSheet:
    """스타일시트 로드.

    우선순위:
      1. json_path가 지정되면 그 파일을 직접 로드
      2. preset이 지정되면 presets/<preset>.json 로드
      3. 둘 다 없으면 기본 presets/ssu_masters.json
    """
    here = Path(__file__).parent
    if json_path is not None:
        path = Path(json_path)
    elif preset is not None:
        path = here / "presets" / f"{preset}.json"
        if not path.exists():
            raise FileNotFoundError(f"preset not found: {path}")
    else:
        path = here / "presets" / "ssu_masters.json"

    data = json.loads(path.read_text(encoding="utf-8"))

    paper = data.get("paper_size", {})
    margins = data.get("margins", {})
    page = PageConfig(
        width_cm=float(paper.get("width_cm", 18.2)),
        height_cm=float(paper.get("height_cm", 25.7)),
        left_cm=float(margins.get("left_cm", 2.0)),
        right_cm=float(margins.get("right_cm", 2.0)),
        top_cm=float(margins.get("top_cm", 2.5)),
        bottom_cm=float(margins.get("bottom_cm", 2.5)),
    )

    styles: dict[str, Style] = {}
    for key, entry in data.get("styles", {}).items():
        if not isinstance(entry, dict):
            continue
        if "font" not in entry:
            continue
        styles[key] = _style_from_dict(key, entry)

    return StyleSheet(
        page=page,
        styles=styles,
        degree=str(data.get("degree", "")),
        committee_size=int(data.get("committee_size", 3)),
        university=str(data.get("university", "")),
        graduate_school=str(data.get("graduate_school", "")),
    )
