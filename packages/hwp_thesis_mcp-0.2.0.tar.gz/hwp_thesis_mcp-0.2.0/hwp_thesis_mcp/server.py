"""hwp-thesis-mcp — 한국 대학원 석사학위논문 HWP 자동 변환 MCP 서버.

Copyright (c) 2026 Minisoft, Inc.
Licensed under MIT (see LICENSE).

References:
  - pyhwpx (MIT) by martiniifun — https://github.com/martiniifun/pyhwpx
  - HwpCtrl COM by Hancom Inc. — https://developer.hancom.com/
  - Soongsil University Graduate School 필수안내서 — 서식 규격 출처

Author: mobisk (Minisoft CEO)
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

# MCP는 stdout으로 JSON-RPC를 주고받음. print() 같은 디버그 출력이 섞이면
# 클라이언트 파서가 깨지므로 stdout을 stderr로 강제 우회.
# sys.stdout에 직접 쓰는 경로(렌더러 로그 등)도 안전해진다.
if os.environ.get("HWP_THESIS_MCP_PROTECT_STDOUT", "1") != "0":
    sys.stdout = sys.stderr

try:
    from mcp.server.fastmcp import FastMCP
except ImportError as e:
    raise SystemExit(
        "mcp SDK가 설치되어 있지 않습니다. `pip install mcp` 또는 "
        "`pip install \"mcp[cli]\"`로 설치하세요."
    ) from e

_HERE = Path(__file__).parent


mcp = FastMCP(
    name="hwp-thesis-mcp",
    instructions=(
        "한국 대학원 석사학위논문 HWP 자동 변환기. "
        "SCHEMA.md 규격의 XML을 받아 숭실대학교 석사논문 양식의 HWP 파일을 생성합니다. "
        "XML을 작성할 땐 get_schema() 도구로 규격을 먼저 확인하세요."
    ),
)


@mcp.tool()
def list_presets() -> list[str]:
    """사용 가능한 프리셋(학교·학위) 이름 목록."""
    p = _HERE / "presets"
    if not p.exists():
        return []
    return sorted([f.stem for f in p.glob("*.json")])


@mcp.tool()
def get_schema() -> str:
    """XML 작성 규격(SCHEMA.md) 전체 반환. LLM이 논문 XML 작성 시 참조."""
    schema = _HERE / "SCHEMA.md"
    if schema.exists():
        return schema.read_text(encoding="utf-8")
    return "SCHEMA.md not found"


@mcp.tool()
def validate_thesis(xml_content: str) -> dict:
    """XML 구조 검증. 파싱 성공/실패와 기본 구조 정보 반환."""
    from .parser import parse_thesis
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".xml", delete=False, encoding="utf-8",
    )
    try:
        tmp.write(xml_content)
        tmp.close()
        doc = parse_thesis(Path(tmp.name))
        return {
            "valid": True,
            "title_ko": doc.meta.title_ko,
            "title_en": doc.meta.title_en,
            "author": doc.meta.author_ko,
            "chapters": len(doc.chapters),
            "references": len(doc.references),
            "appendices": len(doc.appendices),
            "has_acknowledgement": bool(doc.acknowledgement),
            "has_abstract_ko": doc.abstract_ko is not None,
            "has_abstract_en": doc.abstract_en is not None,
        }
    except Exception as e:
        return {"valid": False, "error": str(e)}
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


@mcp.tool()
def convert_thesis(
    xml_content: str,
    output_path: str,
    preset: str = "ssu_masters",
    export_pdf: bool = False,
) -> dict:
    """XML을 HWP로 변환.

    Args:
        xml_content: SCHEMA.md 규격의 XML 문자열
        output_path: 출력 HWP 파일 절대경로 (예: C:/temp/thesis.hwp)
        preset: 학교/학위 프리셋 이름. 기본 ssu_masters
        export_pdf: True면 같은 경로에 .pdf도 생성 (진단용)

    Returns:
        {"success": bool, "output": "...", "pdf": "..." (optional), "error": "..."}

    Windows + 한/글 설치 + 보안모듈 등록 필수.
    """
    from .parser import parse_thesis
    from .styles import load_stylesheet
    from .renderer_hwp import render

    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".xml", delete=False, encoding="utf-8",
    )
    try:
        tmp.write(xml_content)
        tmp.close()
        doc = parse_thesis(Path(tmp.name))
        ss = load_stylesheet(preset=preset)
        abs_out = os.path.abspath(output_path)
        render(doc, ss, abs_out, export_pdf=export_pdf)
        result = {"success": True, "output": abs_out}
        if export_pdf:
            result["pdf"] = os.path.splitext(abs_out)[0] + ".pdf"
        return result
    except Exception as e:
        return {"success": False, "error": f"{type(e).__name__}: {e}"}
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


@mcp.tool()
def preview_thesis_pages(
    xml_content: str,
    preset: str = "ssu_masters",
    pages: str = "1-5",
) -> list[dict]:
    """변환된 HWP의 특정 페이지를 PDF 렌더해 이미지 경로 리스트로 반환.
    LLM이 결과를 시각적으로 검증할 때 사용.

    Args:
        xml_content: XML 내용
        preset: 프리셋 이름
        pages: 페이지 범위 (예: "1-5", "1,3,5", "1")

    Returns:
        [{"page": n, "path": "/tmp/..._pN.png"}, ...]
    """
    try:
        import fitz  # PyMuPDF
    except ImportError:
        return [{"error": "PyMuPDF 필요: pip install pymupdf"}]

    workdir = Path(tempfile.mkdtemp(prefix="hwp_preview_"))
    hwp_path = workdir / "preview.hwp"
    pdf_path = workdir / "preview.pdf"

    r = convert_thesis(xml_content, str(hwp_path), preset=preset, export_pdf=True)
    if not r.get("success"):
        return [{"error": r.get("error", "convert failed")}]

    # 페이지 범위 파싱
    want: list[int] = []
    for part in pages.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            want.extend(range(int(a), int(b) + 1))
        else:
            want.append(int(part))

    try:
        doc = fitz.open(str(pdf_path))
        out = []
        for n in want:
            if 1 <= n <= doc.page_count:
                pix = doc[n - 1].get_pixmap(dpi=110)
                p = workdir / f"page_{n}.png"
                pix.save(str(p))
                out.append({"page": n, "path": str(p)})
        return out
    except Exception as e:
        return [{"error": str(e)}]


def main() -> None:
    # stdio transport — Claude Desktop/Claude Code 호환
    mcp.run()


if __name__ == "__main__":
    main()
