"""XML 파서.

thesis XML → 내부 데이터 구조 (ThesisDoc).
빈 값은 placeholder 문자열로 치환해서 빈 template.xml도 변환 가능하게 한다.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Union

from lxml import etree


# ---- 데이터 모델 -----------------------------------------------------------

@dataclass
class Meta:
    university: str = "숭실대학교"
    graduate_school: str = "일반대학원"
    department_ko: str = ""
    department_en: str = ""
    degree: str = "석사"
    title_ko: str = ""
    title_en: str = ""
    subtitle_ko: str = ""
    subtitle_en: str = ""
    author_ko: str = ""
    author_en: str = ""
    advisor_main: str = ""
    advisor_co: str = ""
    year: str = ""
    month: str = ""
    chair: str = ""           # 심사위원장
    examiners: list[str] = field(default_factory=list)  # 나머지 심사위원


@dataclass
class TextRun:
    """인라인 텍스트 조각. kind: 'text' | 'cite' | 'em' | 'term'"""
    kind: str
    text: str = ""
    ref: str = ""


@dataclass
class Paragraph:
    runs: list[TextRun] = field(default_factory=list)


@dataclass
class Table:
    id: str = ""
    caption: str = ""
    header: list[list[str]] = field(default_factory=list)
    rows: list[list[str]] = field(default_factory=list)


@dataclass
class Figure:
    id: str = ""
    caption: str = ""
    src: str = ""


@dataclass
class Equation:
    id: str = ""
    text: str = ""


# 본문 블록: 문단/표/그림/수식
Block = Union[Paragraph, Table, Figure, Equation]


@dataclass
class Subsection:
    title: str = ""
    blocks: list[Block] = field(default_factory=list)


@dataclass
class Section:
    title: str = ""
    blocks: list[Block] = field(default_factory=list)
    subsections: list[Subsection] = field(default_factory=list)


@dataclass
class Chapter:
    title: str = ""
    sections: list[Section] = field(default_factory=list)
    # 장 바로 아래(절 이전)에 올 수 있는 블록
    blocks: list[Block] = field(default_factory=list)


@dataclass
class Abstract:
    lang: str = "ko"
    paragraphs: list[Paragraph] = field(default_factory=list)
    keywords: str = ""


@dataclass
class Reference:
    id: str = ""
    text: str = ""


@dataclass
class Appendix:
    title: str = ""
    blocks: list[Block] = field(default_factory=list)


@dataclass
class ThesisDoc:
    meta: Meta = field(default_factory=Meta)
    acknowledgement: list[Paragraph] = field(default_factory=list)
    abstract_ko: Optional[Abstract] = None
    abstract_en: Optional[Abstract] = None
    chapters: list[Chapter] = field(default_factory=list)
    references: list[Reference] = field(default_factory=list)
    reference_style: str = "IEEE"
    appendices: list[Appendix] = field(default_factory=list)


# ---- 파싱 헬퍼 -------------------------------------------------------------

def _text(el) -> str:
    if el is None:
        return ""
    return (el.text or "").strip()


def _local_tag(child) -> str:
    """주석/PI 등 비-엘리먼트는 빈 문자열 반환."""
    if not isinstance(child.tag, str):
        return ""
    return etree.QName(child).localname


def _find_by_lang(parent, tag: str, lang: str) -> str:
    for el in parent.findall(tag):
        if el.get("lang") == lang:
            return _text(el)
    # lang 없으면 첫번째
    first = parent.find(tag)
    return _text(first)


def _parse_meta(root) -> Meta:
    m = root.find("meta")
    if m is None:
        return Meta()

    date = m.find("date")
    year = date.get("year", "") if date is not None else ""
    month = date.get("month", "") if date is not None else ""

    chair = ""
    examiners: list[str] = []
    committee = m.find("committee")
    if committee is not None:
        for ex in committee.findall("examiner"):
            name = _text(ex)
            if ex.get("role") == "위원장":
                chair = name
            else:
                examiners.append(name)

    advisor_main = ""
    advisor_co = ""
    for a in m.findall("advisor"):
        role = a.get("role", "주")
        if role == "주":
            advisor_main = _text(a)
        else:
            advisor_co = _text(a)

    return Meta(
        university=_text(m.find("university")) or "숭실대학교",
        graduate_school=_text(m.find("graduate-school")) or "일반대학원",
        department_ko=_find_by_lang(m, "department", "ko"),
        department_en=_find_by_lang(m, "department", "en"),
        degree=_text(m.find("degree")) or "석사",
        title_ko=_find_by_lang(m, "title", "ko"),
        title_en=_find_by_lang(m, "title", "en"),
        subtitle_ko=_find_by_lang(m, "subtitle", "ko"),
        subtitle_en=_find_by_lang(m, "subtitle", "en"),
        author_ko=_find_by_lang(m, "author", "ko"),
        author_en=_find_by_lang(m, "author", "en"),
        advisor_main=advisor_main,
        advisor_co=advisor_co,
        year=year,
        month=month,
        chair=chair,
        examiners=examiners,
    )


def _parse_paragraph(p_el) -> Paragraph:
    """p 엘리먼트의 인라인 구조를 TextRun 리스트로 변환."""
    runs: list[TextRun] = []

    # 선행 텍스트
    if p_el.text:
        runs.append(TextRun("text", p_el.text))

    for child in p_el:
        tag = _local_tag(child)
        if tag == "cite":
            runs.append(TextRun("cite", ref=child.get("ref", "")))
        elif tag == "em":
            runs.append(TextRun("em", child.text or ""))
        elif tag == "term":
            runs.append(TextRun("term", child.text or ""))
        else:
            # 알 수 없는 태그는 텍스트로 펼침
            runs.append(TextRun("text", child.text or ""))

        if child.tail:
            runs.append(TextRun("text", child.tail))

    # 빈 문단 방지: 공백 최소화
    cleaned = []
    for r in runs:
        if r.kind == "text":
            if r.text:
                cleaned.append(r)
        else:
            cleaned.append(r)
    return Paragraph(runs=cleaned)


def _parse_table(t_el) -> Table:
    t = Table(id=t_el.get("id", ""), caption=t_el.get("caption", ""))
    thead = t_el.find("thead")
    if thead is not None:
        for tr in thead.findall("tr"):
            t.header.append([_text(th) for th in tr.findall("th")])
    tbody = t_el.find("tbody")
    if tbody is not None:
        for tr in tbody.findall("tr"):
            t.rows.append([_text(td) for td in tr.findall("td")])
    return t


def _parse_figure(f_el) -> Figure:
    return Figure(
        id=f_el.get("id", ""),
        caption=f_el.get("caption", ""),
        src=f_el.get("src", ""),
    )


def _parse_equation(e_el) -> Equation:
    return Equation(id=e_el.get("id", ""), text=(e_el.text or "").strip())


def _parse_blocks(parent) -> list[Block]:
    blocks: list[Block] = []
    for child in parent:
        tag = _local_tag(child)
        if tag == "p":
            blocks.append(_parse_paragraph(child))
        elif tag == "table":
            blocks.append(_parse_table(child))
        elif tag == "figure":
            blocks.append(_parse_figure(child))
        elif tag == "equation":
            blocks.append(_parse_equation(child))
    return blocks


def _parse_chapter(c_el) -> Chapter:
    chapter = Chapter(title=c_el.get("title", ""))

    # 섹션 이전의 블록 (있을 수 있음)
    for child in c_el:
        tag = _local_tag(child)
        if tag == "section":
            sec = Section(title=child.get("title", ""))
            for ss in child:
                stag = _local_tag(ss)
                if stag == "subsection":
                    subs = Subsection(title=ss.get("title", ""))
                    subs.blocks = _parse_blocks(ss)
                    sec.subsections.append(subs)
                elif stag == "p":
                    sec.blocks.append(_parse_paragraph(ss))
                elif stag == "table":
                    sec.blocks.append(_parse_table(ss))
                elif stag == "figure":
                    sec.blocks.append(_parse_figure(ss))
                elif stag == "equation":
                    sec.blocks.append(_parse_equation(ss))
            chapter.sections.append(sec)
        elif tag == "p":
            chapter.blocks.append(_parse_paragraph(child))
        elif tag == "table":
            chapter.blocks.append(_parse_table(child))
        elif tag == "figure":
            chapter.blocks.append(_parse_figure(child))
        elif tag == "equation":
            chapter.blocks.append(_parse_equation(child))

    return chapter


def _parse_abstract(a_el) -> Abstract:
    lang = a_el.get("lang", "ko")
    paragraphs: list[Paragraph] = []
    keywords = ""
    for child in a_el:
        tag = _local_tag(child)
        if tag == "p":
            paragraphs.append(_parse_paragraph(child))
        elif tag == "keywords":
            keywords = (child.text or "").strip()
    return Abstract(lang=lang, paragraphs=paragraphs, keywords=keywords)


def parse_thesis(xml_path: Path) -> ThesisDoc:
    tree = etree.parse(str(xml_path))
    root = tree.getroot()

    doc = ThesisDoc()
    doc.meta = _parse_meta(root)

    ack = root.find("acknowledgement")
    if ack is not None:
        for p in ack.findall("p"):
            doc.acknowledgement.append(_parse_paragraph(p))

    for a in root.findall("abstract"):
        lang = a.get("lang", "ko")
        abs_obj = _parse_abstract(a)
        if lang == "en":
            doc.abstract_en = abs_obj
        else:
            doc.abstract_ko = abs_obj

    body = root.find("body")
    if body is not None:
        for c in body.findall("chapter"):
            doc.chapters.append(_parse_chapter(c))

    refs = root.find("references")
    if refs is not None:
        doc.reference_style = refs.get("style", "IEEE")
        for r in refs.findall("ref"):
            doc.references.append(Reference(id=r.get("id", ""), text=_text(r)))

    for ap in root.findall("appendix"):
        appendix = Appendix(title=ap.get("title", ""))
        appendix.blocks = _parse_blocks(ap)
        doc.appendices.append(appendix)

    return doc
