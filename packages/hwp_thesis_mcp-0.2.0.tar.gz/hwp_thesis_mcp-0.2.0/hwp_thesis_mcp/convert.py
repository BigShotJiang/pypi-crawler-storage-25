"""hwp-thesis-mcp — 한국 대학원 학위논문 HWP 자동 변환기 CLI.

사용법 (pip install 후):
    hwp-thesis-convert init                         # 새 템플릿 XML 생성
    hwp-thesis-convert template.xml --validate      # 구조 검증
    hwp-thesis-convert template.xml -o out.hwp      # HWP 생성
    hwp-thesis-convert template.xml -o out.hwp --pdf --preset ssu_phd

개발 환경 (소스 트리):
    python -m hwp_thesis_mcp.convert ...

Copyright (c) 2026 Minisoft, Inc. — Licensed under MIT (see LICENSE).
References: pyhwpx (MIT), Hancom HwpCtrl, 숭실대 필수안내서 — ATTRIBUTION.md
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Windows 콘솔 CP949에서 유니코드 문자 출력 시 에러 방지
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


_HERE = Path(__file__).parent


def _friendly_error(e: Exception) -> str:
    """에러 메시지를 사용자 친화적으로 변환."""
    msg = str(e)
    # 자주 겪는 케이스 안내
    if "HWPFrame.HwpObject" in msg or "CoCreateInstance" in msg:
        return (
            "한/글 프로그램을 찾을 수 없습니다.\n"
            "  → 한컴오피스 한/글 2018 이상이 설치되어 있는지 확인하세요."
        )
    if "FilePathChecker" in msg or "보안" in msg:
        return (
            "HwpCtrl 보안 모듈 등록이 필요합니다.\n"
            "  → scripts/setup_hwp.ps1 을 실행하세요."
        )
    if "MiliToHwpUnit" in msg:
        return (
            "COM 인터페이스 초기화 오류.\n"
            "  → 기존 한/글 프로세스를 모두 종료한 뒤 재시도하세요."
        )
    if "AttributeError" in msg and "win32com" in msg:
        return (
            "win32com 타입 라이브러리 캐시 문제.\n"
            "  → C:\\Users\\<사용자>\\AppData\\Local\\Temp\\gen_py 폴더 삭제 후 재시도."
        )
    return msg


def _cmd_init(args: argparse.Namespace) -> int:
    """기본 template.xml을 현재 디렉토리에 생성."""
    src = _HERE / "template.xml"
    if not src.exists():
        print(f"[error] 기본 template.xml을 찾을 수 없습니다: {src}", file=sys.stderr)
        return 2
    out = Path(args.out)
    if out.exists() and not args.force:
        print(f"[error] 이미 존재합니다: {out} (덮어쓰려면 --force)", file=sys.stderr)
        return 2
    out.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    print(f"[ok] 템플릿 생성: {out}")
    print("다음 단계:")
    print(f"  1. {out} 편집 (meta 정보 + body 본문 작성)")
    print(f"  2. hwp-thesis-convert {out} --validate   # 구조 검증")
    print(f"  3. hwp-thesis-convert {out} -o thesis.hwp")
    return 0


def _cmd_convert(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"[error] 입력 파일 없음: {input_path}", file=sys.stderr)
        print("  → hwp-thesis-convert init 으로 기본 템플릿을 먼저 생성할 수 있습니다.",
              file=sys.stderr)
        return 2

    from .parser import parse_thesis
    try:
        doc = parse_thesis(input_path)
    except Exception as e:
        print(f"[error] XML 파싱 실패: {_friendly_error(e)}", file=sys.stderr)
        return 2

    if args.validate:
        print("[ok] XML 파싱 성공")
        print(f"  프리셋:   {args.preset}")
        print(f"  제목(ko): {doc.meta.title_ko or '(비어있음)'}")
        print(f"  제목(en): {doc.meta.title_en or '(비어있음)'}")
        print(f"  저자:     {doc.meta.author_ko or '(비어있음)'}")
        print(f"  지도교수: {doc.meta.advisor_main or '(비어있음)'}")
        print(f"  장 수:    {len(doc.chapters)}")
        print(f"  참고문헌: {len(doc.references)}건")
        print(f"  초록:     국문={'O' if doc.abstract_ko else 'X'} "
              f"영문={'O' if doc.abstract_en else 'X'}")
        return 0

    if not args.output:
        print("[error] -o/--output 을 지정해 주세요", file=sys.stderr)
        return 2

    from .styles import load_stylesheet
    try:
        ss = load_stylesheet(preset=args.preset)
    except FileNotFoundError as e:
        print(f"[error] 프리셋 없음: {e}", file=sys.stderr)
        print(f"  → 사용 가능한 프리셋은 presets/ 폴더를 확인하세요.", file=sys.stderr)
        return 2

    from .renderer_hwp import render
    try:
        render(doc, ss, args.output, visible=args.visible, export_pdf=args.pdf)
    except Exception as e:
        print(f"[error] 변환 실패: {_friendly_error(e)}", file=sys.stderr)
        return 1

    print(f"[ok] 변환 완료: {args.output}")
    if args.pdf:
        pdf_path = Path(args.output).with_suffix(".pdf")
        print(f"[ok] PDF 내보내기: {pdf_path}")
    return 0


def _build_convert_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="hwp-thesis-convert",
        description="한국 대학원 석사학위논문 XML → HWP 변환기",
    )
    ap.add_argument("input", help="입력 XML 파일 경로")
    ap.add_argument("-o", "--output", help="출력 HWP 파일 경로")
    ap.add_argument("--validate", action="store_true",
                    help="XML 구조 검증만 수행 (변환하지 않음)")
    ap.add_argument("--visible", action="store_true",
                    help="변환 과정을 한/글 창으로 표시")
    ap.add_argument("--pdf", action="store_true",
                    help="HWP와 함께 PDF도 내보내기 (진단용)")
    ap.add_argument("--preset", default="ssu_masters",
                    help="학교/학위 프리셋 (기본: ssu_masters)")
    return ap


def _build_init_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="hwp-thesis-convert init",
        description="기본 template.xml 생성",
    )
    ap.add_argument("--out", default="template.xml",
                    help="생성할 파일 경로 (기본: template.xml)")
    ap.add_argument("--force", action="store_true",
                    help="기존 파일 덮어쓰기")
    return ap


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv

    # 전역 도움말
    if not argv or argv[0] in ("-h", "--help"):
        print("사용법:")
        print("  hwp-thesis-convert init [--out <path>] [--force]")
        print("  hwp-thesis-convert <input.xml> --validate")
        print("  hwp-thesis-convert <input.xml> -o <output.hwp> [--pdf] [--preset <name>]")
        print("")
        print("예시:")
        print("  hwp-thesis-convert init                   # template.xml 생성")
        print("  hwp-thesis-convert template.xml --validate")
        print("  hwp-thesis-convert template.xml -o thesis.hwp --pdf")
        print("  hwp-thesis-convert template.xml -o thesis.hwp --preset ssu_phd")
        return 0

    if argv[0] == "init":
        args = _build_init_parser().parse_args(argv[1:])
        return _cmd_init(args)

    args = _build_convert_parser().parse_args(argv)
    return _cmd_convert(args)


if __name__ == "__main__":
    sys.exit(main())
