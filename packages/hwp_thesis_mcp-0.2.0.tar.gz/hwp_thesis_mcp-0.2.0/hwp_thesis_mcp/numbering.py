"""번호 자동 생성.

- chapter:    "제 {n} 장"
- section:    "{chapter}.{section}"
- subsection: "{chapter}.{section}.{subsection}"
- table:      [표 {chapter}-{seq}]  (id에 있으면 파싱, 없으면 자동)
- figure:     [그림 {chapter}-{seq}]
- cite:       본문 등장 순서대로 [1], [2]...
"""
from __future__ import annotations

from .parser import ThesisDoc, Paragraph, Table, Figure, TextRun


class CiteRegistry:
    """cite ref → 번호 매핑. 본문 순회 중 등장한 순서대로 번호 부여."""

    def __init__(self, refs: list) -> None:
        # refs: list[Reference]
        self._ref_ids = {r.id for r in refs}
        self._order: dict[str, int] = {}

    def number_for(self, ref_id: str) -> int:
        if ref_id not in self._order:
            self._order[ref_id] = len(self._order) + 1
        return self._order[ref_id]

    def sorted_references(self, all_refs: list):
        """등장 순서에 맞춰 Reference 객체 리스트 반환. 등장하지 않은 것은 뒤에 붙임."""
        idx = {rid: i for i, rid in enumerate(self._order.keys())}
        def key(r):
            return idx.get(r.id, len(idx) + 1)
        ordered = sorted(all_refs, key=key)
        return ordered


def _collect_cites_in_paragraph(p: Paragraph, reg: CiteRegistry) -> None:
    for run in p.runs:
        if run.kind == "cite" and run.ref:
            reg.number_for(run.ref)


def preregister_cites(doc: ThesisDoc) -> CiteRegistry:
    """본문을 순회하며 cite 등장 순서로 번호를 미리 매김."""
    reg = CiteRegistry(doc.references)
    for ch in doc.chapters:
        for b in ch.blocks:
            if isinstance(b, Paragraph):
                _collect_cites_in_paragraph(b, reg)
        for sec in ch.sections:
            for b in sec.blocks:
                if isinstance(b, Paragraph):
                    _collect_cites_in_paragraph(b, reg)
            for ss in sec.subsections:
                for b in ss.blocks:
                    if isinstance(b, Paragraph):
                        _collect_cites_in_paragraph(b, reg)
    return reg


def chapter_heading(n: int, title: str) -> str:
    return f"제 {n} 장  {title}".rstrip()


def section_heading(ch: int, sec: int, title: str) -> str:
    return f"{ch}.{sec} {title}".rstrip()


def subsection_heading(ch: int, sec: int, sub: int, title: str) -> str:
    return f"{ch}.{sec}.{sub} {title}".rstrip()


def table_label(table_id: str, chapter_no: int, seq: int, caption: str) -> str:
    # id가 "{chapter}-{seq}" 형식이면 그대로, 아니면 auto
    label_id = table_id or f"{chapter_no}-{seq}"
    return f"[표 {label_id}] {caption}".rstrip()


def figure_label(figure_id: str, chapter_no: int, seq: int, caption: str) -> str:
    label_id = figure_id or f"{chapter_no}-{seq}"
    return f"[그림 {label_id}] {caption}".rstrip()


def render_paragraph_text(p: Paragraph, cites: CiteRegistry) -> list[dict]:
    """문단을 렌더링 가능한 조각으로 변환.

    반환: [{"text": str, "style": "normal"|"em"|"term"}, ...]
    cite는 [번호]로 전개된 일반 텍스트로 합쳐진다.
    """
    out: list[dict] = []
    for run in p.runs:
        if run.kind == "text":
            if run.text:
                out.append({"text": run.text, "style": "normal"})
        elif run.kind == "cite":
            num = cites.number_for(run.ref) if run.ref else 0
            out.append({"text": f"[{num}]", "style": "normal"})
        elif run.kind == "em":
            if run.text:
                out.append({"text": run.text, "style": "em"})
        elif run.kind == "term":
            if run.text:
                out.append({"text": run.text, "style": "term"})
    return out
