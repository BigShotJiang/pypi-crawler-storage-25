"""HwpCtrl COM 래퍼.

핵심 패턴은 pyhwpx (MIT) <https://github.com/martiniifun/pyhwpx> 소스를 참조해
검증했음: ApplyTo 아이템, AutoNumType/HAlign/PageNumPosition/NumberFormat
enum 변환, Action 이름 "ParagraphShape" 등.

Copyright (c) 2026 Minisoft, Inc. — Licensed under MIT.
Portions derived from pyhwpx (MIT) by martiniifun.
"""
from __future__ import annotations

import sys
from typing import Optional

try:
    import pythoncom  # type: ignore
    import win32com.client  # type: ignore
except ImportError as exc:  # pragma: no cover
    raise RuntimeError(
        "이 모듈은 Windows + pywin32 + 한/글이 설치된 환경에서만 동작합니다."
    ) from exc


def _warn(msg: str) -> None:
    """stderr로 경고 출력 — MCP stdio 프로토콜을 오염시키지 않기 위함."""
    print(msg, file=sys.stderr, flush=True)

from .styles import Style, PageConfig


NUM_ARABIC = 0
NUM_ROMAN_LOWER = 3

_ALIGN_MAP = {
    "justify": 0,
    "left": 1,
    "right": 2,
    "center": 3,
    "distribute": 4,
}


class HwpController:
    def __init__(self) -> None:
        self.hwp = None

    # ---- 연결/종료 ----------------------------------------------------------

    def connect(self, visible: bool = False) -> None:
        pythoncom.CoInitialize()
        # Dispatch: gen_py 캐시가 있으면 typed wrapper, 없으면 late-binding.
        # typed wrapper 쪽이 nested 속성(PageDef.*) 세팅을 제대로 전파한다.
        # gen_py typed wrapper 강제 생성. nested property(PageDef.*) 세팅을
        # 올바르게 COM으로 전파하려면 typed 바인딩이 필요.
        self.hwp = win32com.client.gencache.EnsureDispatch("HWPFrame.HwpObject")
        try:
            self.hwp.SetMessageBoxMode(0xFFFFFF)
        except Exception:
            pass
        try:
            self.hwp.RegisterModule("FilePathCheckDLL", "FilePathCheckerModuleExample")
        except Exception:
            pass
        # 활성 문서 확보
        try:
            self.hwp.XHwpDocuments.Add(0)
        except Exception:
            try:
                self.hwp.HAction.Run("FileNew")
            except Exception:
                pass

    def open_as_base(self, hwp_path: str) -> bool:
        """기존 HWP 파일을 열고 내용만 비운 뒤 작업 시작 문서로 사용."""
        import os
        import threading
        abs_path = os.path.abspath(hwp_path)
        if not os.path.exists(abs_path):
            return False
        stop = threading.Event()
        t = threading.Thread(target=self._dismiss_loop, args=(stop,), daemon=True)
        t.start()
        try:
            self.hwp.Open(abs_path, "HWP", "")
            self.hwp.HAction.Run("SelectAll")
            self.hwp.HAction.Run("Delete")
            return True
        except Exception as e:
            _warn(f"[warn] open_as_base 실패: {e}")
            return False
        finally:
            stop.set()
        try:
            self.hwp.XHwpWindows.Item(0).Visible = bool(visible)
        except Exception:
            pass

    def quit(self) -> None:
        if self.hwp is not None:
            try:
                self.hwp.Quit()
            except Exception:
                pass
            self.hwp = None

    # ---- 저장 ---------------------------------------------------------------

    def save_as_pdf(self, path: str) -> bool:
        """PDF로 내보내기. FilePathChecker 팝업은 save_as와 동일하게 자동 처리."""
        import threading
        stop = threading.Event()
        t = threading.Thread(target=self._dismiss_loop, args=(stop,), daemon=True)
        t.start()
        try:
            ok = bool(self.hwp.SaveAs(path, "PDF", ""))
        finally:
            stop.set()
        return ok

    def _dismiss_loop(self, stop) -> None:
        import ctypes
        import ctypes.wintypes
        import time
        user32 = ctypes.windll.user32
        EnumProc = ctypes.WINFUNCTYPE(
            ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
        while not stop.is_set():
            targets: list[int] = []

            def cb(hwnd, lparam):
                if not user32.IsWindowVisible(hwnd):
                    return True
                cls = ctypes.create_unicode_buffer(64)
                user32.GetClassNameW(hwnd, cls, 64)
                if cls.value in ("HNC_DIALOG", "#32770"):
                    targets.append(hwnd)
                return True

            user32.EnumWindows(EnumProc(cb), 0)
            for hwnd in targets:
                user32.PostMessageW(hwnd, 0x0100, 0x0D, 0)
                user32.PostMessageW(hwnd, 0x0101, 0x0D, 0)
            time.sleep(0.3)

    def save_as(self, path: str) -> bool:
        """SaveAs 호출 시 FilePathChecker 보안 팝업이 뜨면 자동으로 '확인' 클릭."""
        import threading
        stop = threading.Event()

        def dismiss_loop():
            import ctypes
            import ctypes.wintypes
            import time
            user32 = ctypes.windll.user32
            WM_KEYDOWN = 0x0100
            WM_KEYUP = 0x0101
            VK_RETURN = 0x0D
            VK_Y = 0x59

            EnumProc = ctypes.WINFUNCTYPE(
                ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)

            def want(hwnd):
                if not user32.IsWindowVisible(hwnd):
                    return False
                cls = ctypes.create_unicode_buffer(64)
                user32.GetClassNameW(hwnd, cls, 64)
                # HWP 보안 팝업은 HNC_DIALOG 클래스, 일반은 #32770
                return cls.value in ("HNC_DIALOG", "#32770")

            while not stop.is_set():
                targets: list[int] = []

                def cb(hwnd, lparam):
                    if want(hwnd):
                        targets.append(hwnd)
                    return True

                user32.EnumWindows(EnumProc(cb), 0)
                for hwnd in targets:
                    # Enter 키 전송 (기본 버튼 활성화)
                    user32.PostMessageW(hwnd, WM_KEYDOWN, VK_RETURN, 0)
                    user32.PostMessageW(hwnd, WM_KEYUP, VK_RETURN, 0)
                    # Y (예) 키도 함께
                    user32.PostMessageW(hwnd, WM_KEYDOWN, VK_Y, 0)
                    user32.PostMessageW(hwnd, WM_KEYUP, VK_Y, 0)
                time.sleep(0.3)

        t = threading.Thread(target=dismiss_loop, daemon=True)
        t.start()
        try:
            ok = bool(self.hwp.SaveAs(path, "HWP", ""))
        finally:
            stop.set()
        return ok

    # ---- 단위 변환 ----------------------------------------------------------

    def mm(self, v_mm: float) -> int:
        return int(self.hwp.MiliToHwpUnit(float(v_mm)))

    def cm(self, v_cm: float) -> int:
        return self.mm(v_cm * 10.0)

    # ---- Action 헬퍼 (C# CreateAction/CreateSet 패턴) -----------------------

    def _new_action(self, name: str):
        """CreateAction + CreateSet + GetDefault — 실패 시 (None, None)."""
        try:
            act = self.hwp.CreateAction(name)
            pset = act.CreateSet()
            act.GetDefault(pset)
            return act, pset
        except Exception:
            return None, None

    def _set(self, pset, key: str, value) -> None:
        try:
            pset.SetItem(key, value)
        except Exception:
            # 일부 속성은 구조체 경유 — 최상위 SetItem으로 접근 안될 수 있음
            pass

    # ---- 페이지 설정 --------------------------------------------------------

    def set_page(self, page: PageConfig) -> None:
        """PageSetup — ApplyTo=3(모든 구역) 설정이 핵심.
        이걸 빼먹으면 Execute가 False를 반환한다 (pyhwpx 소스 참조)."""
        try:
            sd = self.hwp.HParameterSet.HSecDef
            self.hwp.HAction.GetDefault("PageSetup", sd.HSet)
            sd.PageDef.PaperWidth = self.cm(page.width_cm)
            sd.PageDef.PaperHeight = self.cm(page.height_cm)
            sd.PageDef.LeftMargin = self.cm(page.left_cm)
            sd.PageDef.RightMargin = self.cm(page.right_cm)
            sd.PageDef.TopMargin = self.cm(page.top_cm)
            sd.PageDef.BottomMargin = self.cm(page.bottom_cm)
            sd.PageDef.HeaderLen = self.cm(1.5)
            sd.PageDef.FooterLen = self.cm(1.5)
            sd.PageDef.GutterLen = 0
            sd.PageDef.Landscape = 0
            # 결정적 누락 항목: ApplyTo (2=현재구역, 3=모든구역, 4=새구역)
            sd.HSet.SetItem("ApplyTo", 3)
            ok = self.hwp.HAction.Execute("PageSetup", sd.HSet)
            if not ok:
                _warn("[warn] PageSetup Execute=False")
        except Exception as e:
            _warn(f"[warn] PageSetup 실패: {e}")

    def set_page_number(self, num_shape: int = NUM_ARABIC, begin: int = 1) -> None:
        """쪽번호 표시 설정 (PageNumPos) + 시작번호 리셋 (NewNumber).
        gen_py HPageNumPos에 NewNumber 속성이 없어 HAutoNum 경로로 분리."""
        try:
            pn = self.hwp.HParameterSet.HPageNumPos
            self.hwp.HAction.GetDefault("PageNumPos", pn.HSet)
            pn.DrawPos = self.hwp.PageNumPosition("BottomCenter")
            fmt_name = {NUM_ARABIC: "Digit", NUM_ROMAN_LOWER: "RomanSmall"}.get(
                num_shape, "Digit")
            pn.NumberFormat = self.hwp.NumberFormat(fmt_name)
            pn.SideChar = 45
            # NewNumber는 attr로 없을 수 있어 SetItem으로 병행 시도
            try:
                pn.HSet.SetItem("NewNumber", begin)
            except Exception:
                pass
            ok = self.hwp.HAction.Execute("PageNumPos", pn.HSet)
            if not ok:
                _warn("[warn] PageNumPos Execute=False")
        except Exception as e:
            _warn(f"[warn] PageNumPos 실패: {e}")

        # PageNumPos가 NewNumber를 수용하지 않는 환경을 위해 NewNumber Action 병행
        try:
            an = self.hwp.HParameterSet.HAutoNum
            self.hwp.HAction.GetDefault("NewNumber", an.HSet)
            an.NumType = self.hwp.AutoNumType("Page")
            an.NewNumber = begin
            self.hwp.HAction.Execute("NewNumber", an.HSet)
        except Exception as e:
            _warn(f"[warn] NewNumber 실패: {e}")

    def hide_page_number(self) -> None:
        return

    # ---- 문자/문단 속성 -----------------------------------------------------

    def apply_char_shape(self, style: Style) -> None:
        try:
            cs = self.hwp.HParameterSet.HCharShape
            self.hwp.HAction.GetDefault("CharShape", cs.HSet)
            cs.FaceNameHangul = style.font
            cs.FaceNameLatin = style.font
            cs.FaceNameHanja = style.font
            cs.FaceNameJapanese = style.font
            cs.FaceNameOther = style.font
            cs.FaceNameSymbol = style.font
            cs.FaceNameUser = style.font
            cs.Height = style.size_pt * 100
            cs.Bold = 1 if style.bold else 0
            cs.Italic = 1 if style.italic else 0
            self.hwp.HAction.Execute("CharShape", cs.HSet)
        except Exception as e:
            _warn(f"[warn] CharShape 실패: {e}")

    _ALIGN_ENUM = {
        "left": "Left", "center": "Center", "right": "Right",
        "justify": "Justify", "distribute": "Distribute",
    }

    def apply_para_shape(self, style: Style) -> None:
        """pyhwpx set_para 패턴:
        - Action 이름은 "ParagraphShape" (주의: "ParaShape" 아님!)
        - AlignType은 hwp.HAlign("Center")로 enum 변환
        - Indentation/Margin 단위는 hwp.PointToHwpUnit(pt*2)"""
        try:
            ps = self.hwp.HParameterSet.HParaShape
            self.hwp.HAction.GetDefault("ParagraphShape", ps.HSet)

            # 정렬 (enum 변환)
            align_name = self._ALIGN_ENUM.get(style.align, "Justify")
            try:
                ps.AlignType = self.hwp.HAlign(align_name)
            except Exception:
                pass

            # 줄간격 %
            ps.LineSpacing = style.line_spacing_pct
            ps.LineSpacingType = 0

            # 여백/들여쓰기 단위: cm 값은 MiliToHwpUnit, pt 값은 PointToHwpUnit
            def pt_to_hu(pt: float) -> int:
                try:
                    return int(self.hwp.PointToHwpUnit(float(pt)))
                except Exception:
                    return int(pt * 100)

            left_cm = style.left_indent_cm
            first_pt = style.first_indent_pt
            hang_cm = style.hanging_indent_cm

            # HWP 모델: LeftMargin = 줄바꿈된 줄의 왼쪽 여백 위치
            #           Indentation = 첫 줄이 LeftMargin으로부터 떨어진 거리
            #                       (-값이면 첫 줄이 더 왼쪽, = hanging indent)
            if hang_cm > 0 and left_cm > 0:
                left_margin = self.cm(left_cm + hang_cm)
                indent = -self.cm(hang_cm)
            elif hang_cm > 0:
                left_margin = self.cm(hang_cm)
                indent = -self.cm(hang_cm)
            else:
                left_margin = self.cm(left_cm) if left_cm else 0
                indent = pt_to_hu(first_pt) if first_pt else 0

            prev_sp = self.cm(style.space_before_cm) if style.space_before_cm else 0
            next_sp = self.cm(style.space_after_cm) if style.space_after_cm else 0

            # typed wrapper setter와 HSet.SetItem 이중 설정 — gen_py 환경에서
            # setter가 무시되는 경우를 위한 fallback.
            ps.LeftMargin = left_margin
            ps.Indentation = indent
            ps.RightMargin = 0
            ps.PrevSpacing = prev_sp
            ps.NextSpacing = next_sp
            try:
                ps.HSet.SetItem("LeftMargin", left_margin)
                ps.HSet.SetItem("Indentation", indent)
                ps.HSet.SetItem("RightMargin", 0)
                ps.HSet.SetItem("PrevSpacing", prev_sp)
                ps.HSet.SetItem("NextSpacing", next_sp)
            except Exception:
                pass

            ok = self.hwp.HAction.Execute("ParagraphShape", ps.HSet)
            if not ok:
                _warn("[warn] ParagraphShape Execute=False")
        except Exception as e:
            _warn(f"[warn] ParagraphShape 실패: {e}")

    def apply_style(self, style: Style) -> None:
        self.apply_para_shape(style)
        self.apply_char_shape(style)

    # ---- 텍스트/구조 삽입 ---------------------------------------------------

    def insert_text(self, text: str) -> None:
        if not text:
            return
        parts = text.split("\n")
        for i, chunk in enumerate(parts):
            if chunk:
                act, pset = self._new_action("InsertText")
                if act is not None:
                    self._set(pset, "Text", chunk)
                    try:
                        act.Execute(pset)
                    except Exception as e:
                        _warn(f"[warn] InsertText 실패: {e}")
            if i != len(parts) - 1:
                self.break_para()

    def _run(self, cmd: str) -> None:
        try:
            self.hwp.HAction.Run(cmd)
        except Exception as e:
            _warn(f"[warn] Run({cmd}) 실패: {e}")

    def break_para(self) -> None:
        self._run("BreakPara")

    def break_page(self) -> None:
        self._run("BreakPage")

    def break_section(self) -> None:
        self._run("BreakSection")

    def move_doc_end(self) -> None:
        self._run("MoveDocEnd")

    # ---- 고수준 유틸 --------------------------------------------------------

    def write_paragraph(self, text: str, style: Optional[Style] = None) -> None:
        if style is not None:
            self.apply_style(style)
        self.insert_text(text)
        self.break_para()

    def empty_paragraph(self, count: int = 1) -> None:
        for _ in range(count):
            self.break_para()

    # ---- 페이지 조회 / 치환 ------------------------------------------------

    def current_page(self) -> int:
        """현재 커서 위치의 페이지 번호. KeyIndicator 튜플의 4번째 요소([3]).
        (튜플 예: (valid, 3, section, page, col, ..., ctrl_name))"""
        try:
            ki = self.hwp.KeyIndicator()
            if isinstance(ki, (tuple, list)) and len(ki) >= 4:
                return int(ki[3])
        except Exception:
            pass
        return 0

    def find_and_get_page(self, text: str) -> int:
        """문서 끝에서 역방향으로 text를 찾아 페이지 번호 반환.
        역방향이므로 목차의 자기 참조가 아니라 본문의 실제 제목이 먼저 걸린다."""
        try:
            self.hwp.HAction.Run("MoveDocEnd")
            act = self.hwp.CreateAction("RepeatFind")
            pset = act.CreateSet()
            act.GetDefault(pset)
            pset.SetItem("FindString", text)
            pset.SetItem("IgnoreCase", 1)
            pset.SetItem("Direction", 1)  # 1 = 역방향
            pset.SetItem("WholeWordOnly", 0)
            pset.SetItem("UseWildCards", 0)
            pset.SetItem("AutoSpell", 1)
            pset.SetItem("FindType", 1)
            pset.SetItem("FindStyle", "")
            pset.SetItem("ReplaceStyle", "")
            pset.SetItem("FindRegExp", 0)
            if act.Execute(pset):
                return self.current_page()
        except Exception as e:
            _warn(f"[warn] find_and_get_page 실패: {e}")
        return 0

    def replace_all(self, find: str, repl: str) -> int:
        """문서 전체에서 find → repl. 완료 대화상자도 자동 dismiss."""
        import threading
        stop = threading.Event()
        t = threading.Thread(target=self._dismiss_loop, args=(stop,), daemon=True)
        t.start()
        try:
            self.hwp.HAction.Run("MoveDocBegin")
            act = self.hwp.CreateAction("AllReplace")
            pset = act.CreateSet()
            act.GetDefault(pset)
            pset.SetItem("FindString", find)
            pset.SetItem("ReplaceString", repl)
            pset.SetItem("IgnoreCase", 1)
            pset.SetItem("Direction", 0)
            pset.SetItem("WholeWordOnly", 0)
            pset.SetItem("UseWildCards", 0)
            pset.SetItem("FindType", 1)
            pset.SetItem("MessageBox", 0)
            act.Execute(pset)
            return 1
        except Exception as e:
            _warn(f"[warn] replace_all 실패: {e}")
            return 0
        finally:
            stop.set()
