"""본문 / 초록 / 감사의글 / 참고문헌 / 부록 렌더링.
Copyright (c) 2026 Minisoft, Inc. — MIT. See ATTRIBUTION.md for references.

흐름:
  1) 페이지 설정
  2) 1~5 겉표지~인준서 (frontmatter.py)
  3) 6 감사의 글
  4) 7,8 목차/표목차/그림목차 (toc_generator.py)  — 로마자 쪽번호 시작
  5) 9,10 국문/영문 초록
  6) 11 본문  — 구역 나눔 후 아라비아 쪽번호 시작
  7) 12 참고문헌
  8) 13 부록
"""
from __future__ import annotations

from .hwp_controller import (
    HwpController,
    NUM_ARABIC,
    NUM_ROMAN_LOWER,
)
from .parser import ThesisDoc, Paragraph, Table, Figure, Equation, Subsection
from .styles import Style, StyleSheet
from .numbering import (
    CiteRegistry,
    preregister_cites,
    render_paragraph_text,
)
from .frontmatter import (
    render_cover,
    render_blank_page,
    render_title_page,
    render_inner_title_page,
    render_approval_page,
)
from .toc_generator import (
    render_toc,
    render_table_list,
    render_figure_list,
)


# ---- 인라인 렌더 -----------------------------------------------------------

def _write_paragraph_runs(hwp: HwpController, p: Paragraph,
                          base_style: Style, cites: CiteRegistry) -> None:
    """문단 1개를 base_style로 렌더. em/term은 임시로 속성 바꿨다가 복귀."""
    hwp.apply_style(base_style)
    parts = render_paragraph_text(p, cites)
    if not parts:
        # 빈 문단도 한 줄은 남김
        hwp.break_para()
        return

    # 첫줄 들여쓰기는 ParagraphShape.Indentation에서 처리됨 (pyhwpx 패턴)
    for part in parts:
        if part["style"] == "em":
            em = Style(**{**base_style.__dict__, "italic": True})
            hwp.apply_char_shape(em)
            hwp.insert_text(part["text"])
            hwp.apply_char_shape(base_style)
        elif part["style"] == "term":
            term = Style(**{**base_style.__dict__, "bold": True})
            hwp.apply_char_shape(term)
            hwp.insert_text(part["text"])
            hwp.apply_char_shape(base_style)
        else:
            hwp.insert_text(part["text"])
    hwp.break_para()


# ---- 블록 렌더 -------------------------------------------------------------

def _render_table_block(hwp: HwpController, ss: StyleSheet, t: Table,
                         chapter_no: int, seq: int) -> None:
    tid = t.id or f"{chapter_no}-{seq}"
    hwp.write_paragraph(f"[표 {tid}]  {t.caption}", ss.get("table_caption"))

    rows = len(t.header) + len(t.rows)
    cols = max(
        (len(r) for r in (t.header + t.rows)),
        default=1,
    )
    if rows == 0:
        rows = 1
    if cols == 0:
        cols = 1

    # 사용 가능한 본문 폭 (종이폭 - 좌/우 여백) 을 열 수로 균등 분할
    usable_cm = max(
        ss.page.width_cm - ss.page.left_cm - ss.page.right_cm - 0.2,
        5.0,
    )
    col_width_mm = (usable_cm * 10.0) / cols

    try:
        pset = hwp.hwp.HParameterSet.HTableCreation
        hwp.hwp.HAction.GetDefault("TableCreate", pset.HSet)
        pset.Rows = rows
        pset.Cols = cols
        pset.WidthType = 0
        pset.HeightType = 1
        pset.WidthValue = 0
        pset.HeightValue = hwp.mm(7.0)
        try:
            pset.CreateItemArray("RowHeight", rows)
            pset.CreateItemArray("ColWidth", cols)
            for i in range(rows):
                pset.RowHeight.SetItem(i, hwp.mm(8.0))
            for j in range(cols):
                pset.ColWidth.SetItem(j, hwp.mm(col_width_mm))
        except Exception:
            pass
        hwp.hwp.HAction.Execute("TableCreate", pset.HSet)

        # 셀 채우기
        all_rows = list(t.header) + list(t.rows)
        for r_idx, row in enumerate(all_rows):
            for c_idx in range(cols):
                if c_idx < len(row):
                    hwp.insert_text(row[c_idx])
                # 다음 셀로 이동
                if not (r_idx == len(all_rows) - 1 and c_idx == cols - 1):
                    hwp.hwp.HAction.Run("TableRightCell")
        # 표 바깥으로 이동
        hwp.hwp.HAction.Run("Close")
    except Exception:
        # 표 생성 실패 시 텍스트 폴백
        hwp.write_paragraph("[표 삽입 실패 - 수동 보완 필요]", ss.get("body_text"))

    hwp.break_para()


def _render_figure_block(hwp: HwpController, ss: StyleSheet, f: Figure,
                          chapter_no: int, seq: int) -> None:
    fid = f.id or f"{chapter_no}-{seq}"
    # 이미지 삽입 (src 존재 시)
    import os
    if f.src and os.path.exists(f.src):
        try:
            hwp.hwp.InsertPicture(
                os.path.abspath(f.src),
                True, 0, True, False,
            )
        except Exception:
            hwp.write_paragraph("[이미지 삽입 실패]", ss.get("figure_caption"))
    else:
        hwp.write_paragraph(f"[그림 파일 없음: {f.src}]", ss.get("figure_caption"))

    hwp.break_para()
    hwp.write_paragraph(f"[그림 {fid}]  {f.caption}", ss.get("figure_caption"))


def _render_equation_block(hwp: HwpController, ss: StyleSheet, e: Equation) -> None:
    # 간단히 텍스트로 삽입 (수식편집기 자동화는 향후 확장)
    hwp.write_paragraph(e.text, ss.get("body_text"))


def _render_blocks(hwp: HwpController, ss: StyleSheet, blocks: list,
                   chapter_no: int, cites: CiteRegistry,
                   counters: dict, page_map: dict | None = None) -> None:
    for b in blocks:
        if isinstance(b, Paragraph):
            _write_paragraph_runs(hwp, b, ss.get("body_text"), cites)
        elif isinstance(b, Table):
            counters["table"] = counters.get("table", 0) + 1
            tid = b.id or f"{chapter_no}-{counters['table']}"
            if page_map is not None:
                page_map[f"table_{tid}"] = hwp.current_page()
            _render_table_block(hwp, ss, b, chapter_no, counters["table"])
        elif isinstance(b, Figure):
            counters["figure"] = counters.get("figure", 0) + 1
            fid = b.id or f"{chapter_no}-{counters['figure']}"
            if page_map is not None:
                page_map[f"figure_{fid}"] = hwp.current_page()
            _render_figure_block(hwp, ss, b, chapter_no, counters["figure"])
        elif isinstance(b, Equation):
            _render_equation_block(hwp, ss, b)


# ---- 섹션별 렌더 ----------------------------------------------------------

def render_acknowledgement(hwp: HwpController, ss: StyleSheet,
                            doc: ThesisDoc, cites: CiteRegistry) -> None:
    if not doc.acknowledgement:
        return
    hwp.write_paragraph("감사의 글", ss.get("abstract_kr_title"))
    hwp.empty_paragraph(1)
    for p in doc.acknowledgement:
        _write_paragraph_runs(hwp, p, ss.get("acknowledgement"), cites)
    hwp.break_page()


def render_abstract(hwp: HwpController, ss: StyleSheet, abstract,
                    title_style_key: str, body_style_key: str,
                    title_text: str, meta, cites: CiteRegistry) -> None:
    if abstract is None:
        return
    hwp.write_paragraph(title_text, ss.get(title_style_key))
    hwp.empty_paragraph(1)

    # 소속 블록 (우측정렬) — 필수안내서 9/10번
    affil_style_dict = {**ss.get(body_style_key).__dict__, "align": "right"}
    affil_style = type(ss.get(body_style_key))(**affil_style_dict)
    if abstract.lang == "ko":
        dep = meta.department_ko or "[학과]"
        uni = meta.university or "숭실대학교"
        gs = meta.graduate_school or "대학원"
        hwp.write_paragraph(dep, affil_style)
        hwp.write_paragraph(f"{uni}  {gs}", affil_style)
    else:
        dep_en = meta.department_en or "[Department]"
        hwp.write_paragraph(dep_en, affil_style)
        hwp.write_paragraph("Graduate School of Soongsil University", affil_style)
    hwp.empty_paragraph(1)

    for p in abstract.paragraphs:
        _write_paragraph_runs(hwp, p, ss.get(body_style_key), cites)
    if abstract.keywords:
        hwp.empty_paragraph(1)
        label = "주제어" if abstract.lang == "ko" else "Keywords"
        hwp.write_paragraph(f"{label}: {abstract.keywords}", ss.get(body_style_key))
    hwp.break_page()


def render_body(hwp: HwpController, ss: StyleSheet, doc: ThesisDoc,
                cites: CiteRegistry) -> None:
    for ci, ch in enumerate(doc.chapters, start=1):
        hwp.write_paragraph(f"제 {ci} 장  {ch.title}", ss.get("chapter_title"))
        hwp.empty_paragraph(1)

        counters = {"table": 0, "figure": 0}
        _render_blocks(hwp, ss, ch.blocks, ci, cites, counters)

        for si, sec in enumerate(ch.sections, start=1):
            hwp.write_paragraph(f"{ci}.{si} {sec.title}", ss.get("section_title"))
            _render_blocks(hwp, ss, sec.blocks, ci, cites, counters)
            for sub_i, sub in enumerate(sec.subsections, start=1):
                hwp.write_paragraph(
                    f"{ci}.{si}.{sub_i} {sub.title}",
                    ss.get("subsection_title"),
                )
                _render_blocks(hwp, ss, sub.blocks, ci, cites, counters)

        if ci < len(doc.chapters):
            hwp.break_page()


def _collect_page_map(hwp: HwpController, doc: ThesisDoc) -> dict:
    """렌더 완료 후 각 제목 텍스트를 찾아 페이지 번호를 수집."""
    page_map: dict = {}

    if doc.abstract_ko is not None:
        page_map["abstract_ko"] = hwp.find_and_get_page("국문초록")
    if doc.abstract_en is not None:
        page_map["abstract_en"] = hwp.find_and_get_page("ABSTRACT")

    for ci, ch in enumerate(doc.chapters, start=1):
        page_map[f"ch{ci}"] = hwp.find_and_get_page(f"제 {ci} 장  {ch.title}")
        for si, sec in enumerate(ch.sections, start=1):
            page_map[f"ch{ci}s{si}"] = hwp.find_and_get_page(f"{ci}.{si} {sec.title}")
            for sub_i, sub in enumerate(sec.subsections, start=1):
                page_map[f"ch{ci}s{si}sub{sub_i}"] = hwp.find_and_get_page(
                    f"{ci}.{si}.{sub_i} {sub.title}"
                )

    if doc.references:
        page_map["references"] = hwp.find_and_get_page("참고문헌")

    # 표/그림은 캡션 문자열로 찾기
    for ci, ch in enumerate(doc.chapters, start=1):
        seq_t = seq_f = 0
        def scan(blocks, parent=None):
            nonlocal seq_t, seq_f
            for b in blocks:
                if isinstance(b, Table):
                    seq_t += 1
                    tid = b.id or f"{ci}-{seq_t}"
                    page_map[f"table_{tid}"] = hwp.find_and_get_page(
                        f"[표 {tid}]")
                elif isinstance(b, Figure):
                    seq_f += 1
                    fid = b.id or f"{ci}-{seq_f}"
                    page_map[f"figure_{fid}"] = hwp.find_and_get_page(
                        f"[그림 {fid}]")
        scan(ch.blocks)
        for sec in ch.sections:
            scan(sec.blocks)
            for sub in sec.subsections:
                scan(sub.blocks)

    for ai, ap in enumerate(doc.appendices, start=1):
        page_map[f"appendix{ai}"] = hwp.find_and_get_page(f"부 록  {ap.title}")

    return page_map


def render_references(hwp: HwpController, ss: StyleSheet,
                      doc: ThesisDoc, cites: CiteRegistry) -> None:
    hwp.break_page()
    hwp.write_paragraph("참고문헌", ss.get("reference_heading"))
    hwp.empty_paragraph(1)

    ordered = cites.sorted_references(doc.references)
    for i, ref in enumerate(ordered, start=1):
        hwp.write_paragraph(f"[{i}]  {ref.text}", ss.get("reference_item"))


def render_appendices(hwp: HwpController, ss: StyleSheet, doc: ThesisDoc,
                      cites: CiteRegistry) -> None:
    if not doc.appendices:
        return
    for ap in doc.appendices:
        hwp.break_page()
        hwp.write_paragraph(f"부 록  {ap.title}", ss.get("appendix_heading"))
        hwp.empty_paragraph(1)
        counters = {"table": 0, "figure": 0}
        _render_blocks(hwp, ss, ap.blocks, 0, cites, counters)


# ---- 엔트리 ---------------------------------------------------------------

def render(doc: ThesisDoc, ss: StyleSheet, output_path: str,
           visible: bool = False, export_pdf: bool = False) -> None:
    import sys
    def log(msg: str) -> None:
        print(f"[render] {msg}", flush=True, file=sys.stderr)

    # 프리셋이 학위를 명시하면 meta를 덮어씀 (--preset ssu_phd 시 자동 박사 처리)
    if ss.degree and ss.degree != doc.meta.degree:
        log(f"프리셋 degree={ss.degree} → meta 덮어씀 (원래: {doc.meta.degree})")
        doc.meta.degree = ss.degree

    log("HwpCtrl 연결 중...")
    hwp = HwpController()
    hwp.connect(visible=visible)
    log("연결 OK")
    try:
        # 빈 문서에서 시작 — thesis_template.hwp를 base로 쓰면 그 문서의
        # paragraph style("바탕글" 등)이 CharShape Height/Font를 override해서
        # 폰트 크기 지정이 전부 무시됨. 빈 문서는 CharShape가 정상 반영.
        # (판종 18.2×25.7은 이 환경에선 API 반영 안 되므로 README의 수동 설정 안내 참조)
        log("페이지 설정 중...")
        hwp.set_page(ss.page)

        cites = preregister_cites(doc)
        log(f"cite {len(cites._order)}건 미리 등록")

        log("표지류 렌더 시작")
        hwp.hide_page_number()
        render_cover(hwp, ss, doc.meta);          log(" - 겉표지")
        render_blank_page(hwp);                   log(" - 백지간지")
        render_title_page(hwp, ss, doc.meta);     log(" - 표제지")
        render_inner_title_page(hwp, ss, doc.meta); log(" - 속표지")
        render_approval_page(hwp, ss, doc.meta);  log(" - 인준서")

        render_acknowledgement(hwp, ss, doc, cites); log("감사의 글 OK")

        hwp.break_section()
        hwp.set_page_number(num_shape=NUM_ROMAN_LOWER, begin=1)
        render_toc(hwp, ss, doc);           log("논문목차 OK")
        render_table_list(hwp, ss, doc);    log("표 목차 OK")
        render_figure_list(hwp, ss, doc);   log("그림 목차 OK")

        render_abstract(hwp, ss, doc.abstract_ko,
                        "abstract_kr_title", "abstract_kr_body",
                        "국문초록", doc.meta, cites); log("국문초록 OK")
        render_abstract(hwp, ss, doc.abstract_en,
                        "abstract_en_title", "abstract_en_body",
                        "ABSTRACT", doc.meta, cites); log("영문초록 OK")

        hwp.break_section()
        hwp.set_page_number(num_shape=NUM_ARABIC, begin=1)
        render_body(hwp, ss, doc, cites);    log("본문 OK")

        render_references(hwp, ss, doc, cites); log("참고문헌 OK")
        render_appendices(hwp, ss, doc, cites); log("부록 OK")

        def to_roman(n: int) -> str:
            vals = [(1000,'m'),(900,'cm'),(500,'d'),(400,'cd'),(100,'c'),(90,'xc'),
                    (50,'l'),(40,'xl'),(10,'x'),(9,'ix'),(5,'v'),(4,'iv'),(1,'i')]
            s = ''
            for v, c in vals:
                while n >= v:
                    s += c; n -= v
            return s

        # NewNumber로 각 섹션 쪽번호가 1부터 리셋되므로, KeyIndicator가
        # 반환하는 페이지는 이미 "섹션 상대" 번호. offset 계산 불필요.
        # key 이름으로 어느 섹션인지 구분해서 로마/아라비아 표기.
        log("페이지 맵 수집 중...")
        page_map_raw = _collect_page_map(hwp, doc)
        page_map: dict = {}
        for key, page in page_map_raw.items():
            if page <= 0:
                page_map[key] = "?"
                continue
            # abstract_*, 목차/표/그림 목차 섹션 → 로마 소문자
            if key.startswith("abstract"):
                page_map[key] = to_roman(page)
            else:
                page_map[key] = str(page)
        log(f"페이지 맵 {len(page_map)}건 - 목차 치환 시작")
        from .toc_generator import toc_marker
        for key, page_str in page_map.items():
            if page_str and page_str != "0":
                hwp.replace_all(toc_marker(key), page_str)
        # 찾지 못한 마커는 '?'로 남김 → 마지막에 모두 ?로 교체
        hwp.replace_all("@@PG:", "")  # 접두사 흔적 제거 (안전장치)
        log("목차 치환 완료")

        import os
        abs_out = os.path.abspath(output_path)
        log(f"저장 중: {abs_out}")
        hwp.save_as(abs_out)
        log("저장 OK")
        if export_pdf:
            pdf_out = os.path.splitext(abs_out)[0] + ".pdf"
            log(f"PDF 내보내기: {pdf_out}")
            try:
                hwp.save_as_pdf(pdf_out)
                log("PDF OK")
            except Exception as e:
                log(f"PDF 실패: {e}")
    finally:
        hwp.quit()
