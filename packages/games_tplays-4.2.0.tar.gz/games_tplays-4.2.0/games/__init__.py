import os
import warnings

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
warnings.filterwarnings("ignore", category=UserWarning)

import pygame
from OpenGL.GL import *
from OpenGL.GLU import gluOrtho2D
import math
import re
import sys
import shutil
import subprocess
import time

__author__ = 'TiagoPlays'
__version__ = '4.2.0'

def RGBA(red: int | float = 10, green: int | float = 10, blue: int | float = 10, alpha: int | float = 1) -> tuple:
    r, g, b, a = max(0, min(255, red)), max(0, min(255, green)), max(0, min(255, blue)), max(0, min(1, alpha))
    return (r, g, b, a)

class __GroupList2DGame(list):
    def __init__(self, data: list, game_ref):
        super().__init__(data)
        self.game = game_ref

    def __setitem__(self, index: int, value: list):
        if index == 0 or index == 1:
            diff = value - self[index]
            for obj in self[2]:
                size = len(obj)

                # Rectangles / Circles
                if size in [6, 4]:
                    obj[0] += diff if index == 0 else 0
                    obj[1] += diff if index == 1 else 0

                # Triangles
                elif size == 8:
                    for i in range(index, 6, 2): obj[i] += diff
                
                # LINES
                elif size == 7:
                    for i in range(index, 4, 2): obj[i] += diff

                # TEXTS
                elif size == 9:
                    obj[index + 3] += diff

        super().__setitem__(index, value)

class _2DGame:
    def __init__(self, width: int | float, height: int | float, title: str = 'games._2DGame'):
        pygame.init()
        pygame.font.init()

        self.windowSize: tuple = (width, height)
        self.title = title
        self.bgColor: tuple = RGBA()
        self.fps = 60

        self.FPS_COUNTER = 0
        self.__last_keys = pygame.key.get_pressed()
        self.__current_keys_state = []

        self.RECTANGLES = 0
        self.CIRCLES = 1
        self.LINES = 2
        self.TRIANGLES = 3
        self.TEXTS = 4
        self.GROUPS = 5
        self.CONTENT = {'TEXTS': 0, 'GROUPS': 2}
        self.FONT_NAME = {'TEXTS': 1}
        self.FONT_SIZE = {'TEXTS': 2}
        self.X = {'RECTANGLES': 0, 'CIRCLES': 0, 'LINES': {'start': 0, 'end': 2}, 'TRIANGLES': {'vertex1': 0, 'vertex2': 2, 'vertex3': 4}, 'TEXTS': 3, 'GROUPS': 0}
        self.Y = {'RECTANGLES': 1, 'CIRCLES': 1, 'LINES': {'start': 1, 'end': 3}, 'TRIANGLES': {'vertex1': 1, 'vertex2': 3, 'vertex3': 5}, 'TEXTS': 4, 'GROUPS': 1}
        self.WIDTH = {'RECTANGLES': 2, 'TEXTS': 5}
        self.HEIGHT = {'RECTANGLES': 3, 'TEXTS': 6}
        self.RADIUS = {'CIRCLES': 2}
        self.COLOR = {'RECTANGLES': 4, 'CIRCLES': 3, 'LINES': 5, 'TRIANGLES': 6, 'TEXTS': 5}
        self.THICKNESS = {'LINES': 4}
        self.ROTATION = {'RECTANGLES': 5, 'TRIANGLES': 7, 'LINES': 6, 'TEXTS': 6}
        self.BOLD = {'TEXTS': 7}
        self.ITALIC = {'TEXTS': 8}

        self.draws = ([], [], [], [], [], [])
        
    def after(self, milliseconds: int, fps_counter: int | None = None) -> bool:
        if fps_counter is None:
            fps_counter = self.FPS_COUNTER

        if self.fps <= 0:
            self.fps = 1

        frames = (milliseconds * self.fps) / 1000
        return fps_counter % int(frames) == 0

    def draw_rectangle(self, x: int | float, y: int | float, width: int | float, height: int | float, rgba: tuple, rotation: int | float = 0.0) -> list:
        config = [x, y, width, height, rgba, rotation]
        self.draws[self.RECTANGLES].append(config)
        return self.draws[self.RECTANGLES][-1]

    def draw_circle(self, centerX: int | float, centerY: int | float, radius: int | float, rgba: tuple) -> list:
        config = [centerX, centerY, radius, rgba]
        self.draws[self.CIRCLES].append(config)
        return self.draws[self.CIRCLES][-1]

    def draw_line(self, startX: int | float, startY: int | float, endX:int | float, endY: int | float, rgba: tuple, thickness: int | float = 3, rotation: int | float = 0.0) -> list:
        config = [startX, startY, endX, endY, thickness, rgba, rotation]
        self.draws[self.LINES].append(config)
        return self.draws[self.LINES][-1]

    def draw_triangle(self, vertex1X: int | float, vertex1Y: int | float, vertex2X: int | float, vertex2Y: int | float, vertex3X: int | float, vertex3Y: int | float, rgba: tuple, rotation: int | float = 0.0) -> list:
        config = [vertex1X, vertex1Y, vertex2X, vertex2Y, vertex3X, vertex3Y, rgba, rotation]
        self.draws[self.TRIANGLES].append(config)
        return self.draws[self.TRIANGLES][-1]

    def draw_text(self, text: str, font_name: str, size: int | float, x: int | float, y: int | float, rgba: tuple, bold: bool = False, italic: bool = False, rotation: int | float = 0.0) -> list:
        config = [text, font_name, size, x, y, rgba, rotation, bold, italic]
        self.draws[self.TEXTS].append(config)
        return self.draws[self.TEXTS][-1]
    
    def draw_group(self, x: int | float, y: int | float, *drawings) -> list:
        config = __GroupList2DGame([x, y, list(drawings)], self)
        self.draws[self.GROUPS].append(config)
        return self.draws[self.GROUPS][-1]

    def __get_aabb(self, draw: list) -> list:
        CALCS = {
            6: lambda o: [o[0], o[1], o[0]+o[2], o[1]+o[3]],                                   # Rectangles
            4: lambda o: [o[0]-o[2], o[1]-o[2], o[0]+o[2], o[1]+o[2]],                         # Circle
            8: lambda o: [min(o[0:5:2]), min(o[1:6:2]), max(o[0:5:2]), max(o[1:6:2])],         # Triangle
            7: lambda o: [min(o[0], o[2]), min(o[1], o[3]), max(o[0], o[2]), max(o[1], o[3])], # Line
            9: lambda o: [o[3], o[4], o[3]+o[7], o[4]+o[8]]                                    # Text
        }
        DEFAULT_AABB = lambda o: [0, 0, 0, 0]

        return CALCS.get(len(draw), DEFAULT_AABB)(draw)

    def collided(self, draw1: list, draw2: list) -> bool:
        if len(draw1) == 4 and len(draw2) == 4:
            return ((draw1[0]-draw2[0])**2 + (draw1[1]-draw2[1])**2) <= (draw1[2]+draw2[2])**2
            
        b1, b2 = self.__get_aabb(draw1), self.__get_aabb(draw2)
        return b1[0] < b2[2] and b1[2] > b2[0] and b1[1] < b2[3] and b1[3] > b2[1]

    def __check_key_state(self, key: str | int, keys_buffer: list) -> bool:
        k_val = str(key).strip()
        if k_val.isdigit():
            try:
                if keys_buffer[getattr(pygame, f"K_{k_val}")]:
                    return True
            except AttributeError: pass
            
            try:
                if keys_buffer[getattr(pygame, f"K_KP{k_val}")]:
                    return True
            except AttributeError: pass
            
            return False

        if isinstance(key, int):
            return bool(keys_buffer[key])

        if isinstance(key, str) and "+" in key:
            parts = key.split("+")
            return all(self.__check_key_state(p.strip(), keys_buffer) for p in parts)

        k_str = k_val.lower()
        mapping = {
            "ctrl": [pygame.K_LCTRL, pygame.K_RCTRL],
            "shift": [pygame.K_LSHIFT, pygame.K_RSHIFT],
            "alt": [pygame.K_LALT, pygame.K_RALT],
            "win": [pygame.K_LSUPER, pygame.K_RSUPER],
            "cmd": [pygame.K_LMETA, pygame.K_RMETA],
            "enter": [pygame.K_RETURN, pygame.K_KP_ENTER],
            "esc": [pygame.K_ESCAPE]
        }

        if k_str in mapping:
            return any(keys_buffer[k_code] for k_code in mapping[k_str])

        try:
            suffix = k_str if len(k_str) == 1 else k_str.upper()
            key_code = getattr(pygame, f"K_{suffix}")
            return bool(keys_buffer[key_code])
        except AttributeError:
            return False

    def pressed(self, key: str | int) -> bool:
        return self.__check_key_state(key, self.__current_keys_state)

    def __was_pressed(self, key: str | int) -> bool:
        if not hasattr(self, "_2DGame__last_keys") or self.__last_keys is None:
            return False
        return self.__check_key_state(key, self.__last_keys)

    def clicked(self, key: str | int) -> bool:
        return self.pressed(key) and not self.__was_pressed(key)

    def animation(self):
        pass

    def clear_objects(self, *categories):
        targets = categories if categories else [
            self.RECTANGLES, self.CIRCLES, self.LINES, 
            self.TRIANGLES, self.TEXTS, self.GROUPS
        ]
        
        for obj_idx in targets:
            if 0 <= obj_idx < len(self.draws):
                self.draws[obj_idx].clear()

    def clear_drawings(self, *drawings):
        for drawing in drawings:
            for category in self.draws:
                if drawing in category:
                    category.remove(drawing)
                    break

    def close(self):
        self.running = False

    def run(self):
        pygame.display.set_mode(self.windowSize, pygame.DOUBLEBUF | pygame.OPENGL)
        pygame.display.set_caption(self.title)
        
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        def setup_2d():
            glMatrixMode(GL_PROJECTION)
            glLoadIdentity()
            gluOrtho2D(0, self.windowSize[0], 0, self.windowSize[1])
            glMatrixMode(GL_MODELVIEW)
            glLoadIdentity()

        def draw():
            # Rectangles
            for rectangle in self.draws[self.RECTANGLES]:
                x, y, w, h, c, angle = rectangle
                r, g, b, a = c
                glPushMatrix()
                glTranslatef(x + w/2, y + h/2, 0)
                glRotatef(-angle, 0, 0, 1)
                glTranslatef(-w/2, -h/2, 0)
                glColor4f(r/255, g/255, b/255, a)
                glBegin(GL_QUADS)
                glVertex2f(0, 0); glVertex2f(w, 0); glVertex2f(w, h); glVertex2f(0, h)
                glEnd()
                glPopMatrix()

            # Circles
            for circle in self.draws[self.CIRCLES]:
                cx, cy, radius, c = circle
                r, g, b, a = c
                glColor4f(r/255, g/255, b/255, a)
                glBegin(GL_POLYGON)
                for i in range(360):
                    theta = i * math.pi / 180
                    glVertex2f(cx + math.cos(theta) * radius, cy + math.sin(theta) * radius)
                glEnd()

            # Lines
            for line in self.draws[self.LINES]:
                x1, y1, x2, y2, t, c, angle = line
                r, g, b, a = c
                
                mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                
                glPushMatrix()
                glTranslatef(mid_x, mid_y, 0)
                glRotatef(-angle, 0, 0, 1)
                glTranslatef(-mid_x, -mid_y, 0)
                
                glLineWidth(0.1 if t <= 0 else t)
                glColor4f(r/255, g/255, b/255, a)
                glBegin(GL_LINES)
                glVertex2f(x1, y1)
                glVertex2f(x2, y2)
                glEnd()
                glPopMatrix()

            # Triangles
            for triangle in self.draws[self.TRIANGLES]:
                v1x, v1y, v2x, v2y, v3x, v3y, c, angle = triangle
                r, g, b, a = c
                cx, cy = (v1x + v2x + v3x)/3, (v1y + v2y + v3y)/3
                glPushMatrix()
                glTranslatef(cx, cy, 0)
                glRotatef(-angle, 0, 0, 1)
                glTranslatef(-cx, -cy, 0)
                glColor4f(r/255, g/255, b/255, a)
                glBegin(GL_TRIANGLES)
                glVertex2f(v1x, v1y); glVertex2f(v2x, v2y); glVertex2f(v3x, v3y)
                glEnd()
                glPopMatrix()

            # Texts
            for text in self.draws[self.TEXTS]:
                txt_string = text[self.CONTENT['TEXTS']]
                f_name = text[self.FONT_NAME['TEXTS']]
                f_size = text[self.FONT_SIZE['TEXTS']]
                x = text[self.X['TEXTS']]
                y = text[self.Y['TEXTS']]
                c = text[self.COLOR['TEXTS']]
                angle = text[self.ROTATION['TEXTS']]
                is_bold = text[self.BOLD['TEXTS']]
                is_italic = text[self.ITALIC['TEXTS']]
                
                r, g, b, a = c

                font = pygame.font.SysFont(f_name, f_size, is_bold, is_italic)
                surf = font.render(txt_string, True, (255, 255, 255))
                w, h = surf.get_size()
                text_data = pygame.image.tostring(surf, "RGBA", True)

                glPushMatrix()
                glTranslatef(x + w/2, y + h/2, 0)
                glRotatef(-angle, 0, 0, 1)
                glTranslatef(-w/2, -h/2, 0)
                
                glEnable(GL_TEXTURE_2D)
                tex_id = glGenTextures(1)
                glBindTexture(GL_TEXTURE_2D, tex_id)
                glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
                
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, text_data)
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
                
                glColor4f(r/255, g/255, b/255, a)
                
                glBegin(GL_QUADS)
                glTexCoord2f(0, 0); glVertex2f(0, 0)
                glTexCoord2f(1, 0); glVertex2f(w, 0)
                glTexCoord2f(1, 1); glVertex2f(w, h)
                glTexCoord2f(0, 1); glVertex2f(0, h)
                glEnd()
                
                glDeleteTextures([tex_id])
                glDisable(GL_TEXTURE_2D)
                glPopMatrix()

        self.running = True
        clock = pygame.time.Clock()

        while self.running:
            self.__current_keys_state = pygame.key.get_pressed()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.close()

            self.FPS_COUNTER += 1
            self.animation()

            self.__last_keys = self.__current_keys_state

            if not self.running:
                break

            r, g, b, a = self.bgColor

            r *= a
            g *= a
            b *= a

            glClearColor(r / 255, g / 255, b / 255, 1.0)

            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

            setup_2d()
            draw()

            pygame.display.flip()
            clock.tick(self.fps if self.fps > 0 else 60)

        pygame.quit()

    def create_exe(self, show_mensages: bool = True, show_errors: bool = True, show_building_outputs: bool = False):
        safe_title = re.sub(r'[\\/*?:"<>|]', "", self.title).strip().replace(" ", "_")
        original_script = os.path.abspath(sys.argv[0])
        root_dir = os.path.dirname(original_script)
        
        temp_build_folder = os.path.join(root_dir, f"_temp_build_{safe_title}")
        temp_script = os.path.join(root_dir, f"{safe_title}_temp.py")
        
        try:
            if not os.path.exists(temp_build_folder):
                os.makedirs(temp_build_folder)

            with open(original_script, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            with open(temp_script, 'w', encoding='utf-8') as f:
                for line in lines:
                    if '.create_exe(' in line:
                        continue
                    f.write(line)

            stdout_setting = None if show_building_outputs else subprocess.DEVNULL
            stderr_setting = None if show_building_outputs else subprocess.DEVNULL

            if show_mensages: print(f"Generating executable: {safe_title}...")

            subprocess.run([
                sys.executable,
                '-m', 'PyInstaller',
                '--onefile',
                '--noconsole',
                '--name', safe_title,
                '--specpath', temp_build_folder,
                '--workpath', os.path.join(temp_build_folder, "build"),
                '--distpath', os.path.join(temp_build_folder, "dist"),
                temp_script
            ], stdout=stdout_setting, stderr=stderr_setting, check=True)

            exe_ext = ".exe" if os.name == 'nt' else ""
            exe_name = f"{safe_title}{exe_ext}"
            source_exe = os.path.join(temp_build_folder, "dist", exe_name)
            final_exe_path = os.path.join(root_dir, exe_name)

            time.sleep(3) 

            if os.path.exists(source_exe):
                if os.path.exists(final_exe_path):
                    os.remove(final_exe_path)
                shutil.move(source_exe, final_exe_path)

            if os.path.exists(temp_script):
                os.remove(temp_script)

            def force_remove(action, name, exc):
                try:
                    os.chmod(name, 0o777)
                    if os.path.isdir(name):
                        shutil.rmtree(name)
                    else:
                        os.remove(name)
                except Exception:
                    pass

            if os.path.exists(temp_build_folder):
                for _ in range(5):
                    try:
                        shutil.rmtree(temp_build_folder, onerror=force_remove)
                        break
                    except:
                        time.sleep(1)

            if show_mensages:
                print(f"Success! Executable created at: {final_exe_path}.")

        except subprocess.CalledProcessError:
            if show_errors: print("Error: PyInstaller failed.")
        except Exception as e:
            if show_errors: print(f"Unexpected error: {e}")