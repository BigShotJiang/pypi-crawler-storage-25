import random
from games import _2DGame, RGBA

class baseVídeo(_2DGame):
    def __init__(self):
        super().__init__(1000, 800, "Vídeo - GLITCH")
        self.bgColor = RGBA(5, 5, 10)
        self.frame_count = 0
        
        self.glitch_rects = []
        for _ in range(150):
            self.glitch_rects.append({
                'x': random.randint(0, 1000),
                'y': random.randint(0, 800),
                'w': random.randint(10, 250),
                'h': random.randint(2, 10),
                'color': RGBA(random.randint(100, 255), 0, 255, random.randint(80, 200))
            })
        
    def animation(self):
        self.clear_objects()
        self.frame_count += 1

        if self.frame_count % 2 == 0:
            for _ in range(30):
                idx = random.randint(0, len(self.glitch_rects) - 1)
                self.glitch_rects[idx]['x'] = random.randint(0, 1000)
                self.glitch_rects[idx]['y'] = random.randint(0, 800)
                self.glitch_rects[idx]['w'] = random.randint(20, 400)
                
                nova_r = random.randint(100, 255)
                self.glitch_rects[idx]['color'] = RGBA(nova_r, 0, 255, random.randint(80, 200))

        for r in self.glitch_rects:
            self.draw_rectangle(r['x'], r['y'], r['w'], r['h'], r['color'])

        if self.frame_count % 60 < 55:
            tx, ty = 250 + random.randint(-1, 1), 380 + random.randint(-1, 1)
            self.draw_text("SISTEMA CORROMPIDO", "Courier", 60, tx, ty, RGBA(0, 255, 150))
        else:
            self.draw_text("SISTEMA CORROMPIDO", "Courier", 60, 258, 384, RGBA(255, 0, 0, 180))
            self.draw_text("SISTEMA CORROMPIDO", "Courier", 60, 242, 376, RGBA(0, 0, 255, 180))

vídeo = baseVídeo()

vídeo.run()
vídeo.create_exe()