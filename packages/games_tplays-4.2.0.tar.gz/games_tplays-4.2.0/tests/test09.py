from games import _2DGame, RGBA

class Game(_2DGame):
    def __init__(self, r, g, b, a):
        super().__init__(800, 600, 'O meu Jogo')

        self.bgColor = RGBA(r, g, b, a)

Game(255, 255, 255, 0.5).run()