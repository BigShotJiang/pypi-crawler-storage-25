from dataclasses import dataclass
from xml.etree.ElementTree import Element, SubElement

from papyru import XMLHelper


@dataclass(frozen=True)
class PlaceholderInfo:
    wrapper: Element
    placeholder: Element


@dataclass(frozen=True)
class ImageInfo:
    location: str
    width: int
    height: int


def find_placeholder(doc: XMLHelper,
                     placeholder_tag: str,
                     placeholder_id: str) -> PlaceholderInfo:

    wrapper = doc.root.find('.//{%s}svg/{%s}%s[@id="%s"]/..'
                            % (doc.default_namespace,
                               doc.default_namespace,
                               placeholder_tag,
                               placeholder_id))

    if wrapper is None:
        return None

    placeholder = wrapper.find('./{%s}%s[@id="%s"]'
                               % (doc.default_namespace,
                                  placeholder_tag,
                                  placeholder_id))

    if placeholder is None:
        return None

    return PlaceholderInfo(wrapper=wrapper,
                           placeholder=placeholder)


def replace_text_with_image(doc: XMLHelper,
                            placeholder_id: str) -> XMLHelper:
    ph = find_placeholder(doc, 'text', placeholder_id)

    if ph is None:
        return doc

    ph.wrapper.remove(ph.placeholder)

    replacement = SubElement(ph.wrapper,
                             '{%s}image' % doc.default_namespace)

    doc.set_attribute(
        replacement, 'id', doc.get_attribute(ph.placeholder, 'id'))

    doc.set_attribute(replacement, 'x', '0')
    doc.set_attribute(replacement, 'y', '0')

    doc.set_attribute(
        replacement, 'width', doc.get_attribute(ph.wrapper, 'width'))

    doc.set_attribute(
        replacement, 'height', doc.get_attribute(ph.wrapper, 'height'))

    return doc


def fit_image(doc: XMLHelper,
              placeholder_id: str,
              image_info: ImageInfo) -> XMLHelper:
    ph = find_placeholder(doc, 'image', placeholder_id)

    if ph is None:
        return doc

    wrapper_dims = (float(doc.get_attribute(ph.wrapper, 'width')),
                    float(doc.get_attribute(ph.wrapper, 'height')))

    image_dims = (float(image_info.width),
                  float(image_info.height))

    viewbox = _fit_dimensions(wrapper_dims, image_dims)

    doc.set_attribute(ph.wrapper,
                      'viewBox',
                      '%s %s %s %s' % viewbox)

    has_xlink = doc.namespace('xlink') is not None
    doc.set_attribute(ph.placeholder,
                      'href', image_info.location,
                      'xlink' if has_xlink else None)

    doc.set_attribute(ph.placeholder, 'x', '0.0')
    doc.set_attribute(ph.placeholder, 'y', '0.0')
    doc.set_attribute(ph.placeholder, 'width', '%s' % image_dims[0])
    doc.set_attribute(ph.placeholder, 'height', '%s' % image_dims[1])

    _set_changed(doc, ph.placeholder)

    return doc


def _set_changed(document: XMLHelper, element: Element):
    if document.has_attribute(element, 'is-unchanged', 'pap'):
        document.set_attribute(element, 'is-unchanged', 'false', 'pap')


def _fit_dimensions(container_dims: (float, float),
                    element_dims: (float, float)
                    ) -> (float, float, float, float):
    aspect_container = container_dims[0] / container_dims[1]
    aspect_element = element_dims[0] / element_dims[1]

    e_w = element_dims[0]
    e_h = element_dims[1]

    if aspect_container > aspect_element:
        h = element_dims[0] / aspect_container
        return (0.0, (e_h - h) / 2, e_w, h)
    else:
        w = element_dims[1] * aspect_container
        return ((e_w - w) / 2, 0.0, w, e_h)
