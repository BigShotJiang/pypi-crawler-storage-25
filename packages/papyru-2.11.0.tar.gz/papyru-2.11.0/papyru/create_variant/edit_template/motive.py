from functools import reduce

from papyru import XMLHelper
from papyru.create_variant.constants import (MOTIVE_PLACEHOLDER_ID,
                                             MOTIVE_USE_ID)

from .xml import ImageInfo, fit_image


def insert_motive(doc: XMLHelper, motive_info: ImageInfo) -> XMLHelper:
    return reduce(lambda acc, el: fit_image(acc, el, motive_info),
                  [MOTIVE_PLACEHOLDER_ID,
                   MOTIVE_USE_ID],
                  doc)
