from os import getpid
from subprocess import PIPE, Popen

from papyru import XMLHelper
from papyru.create_variant.constants import EAN_PLACEHOLDER_ID
from papyru.create_variant.resi import import_into_resi

from .xml import ImageInfo, find_placeholder, fit_image


def insert_ean(doc: XMLHelper,
               ean: str,
               disposition: str,
               resi_instance: object,
               resi_url: str,
               ) -> XMLHelper:
    ph = find_placeholder(doc, 'image', EAN_PLACEHOLDER_ID)

    if ph is None:
        return doc

    width = float(doc.get_attribute(ph.wrapper, 'width'))
    height = float(doc.get_attribute(ph.wrapper, 'height'))

    ean_location = _create_ean(ean, width, height, disposition,
                               resi_instance, resi_url)

    return fit_image(doc,
                     EAN_PLACEHOLDER_ID,
                     ImageInfo(location=ean_location,
                               width=width,
                               height=height))


def _create_ean(ean: str,
                width: int,
                height: int,
                disposition: str,
                resi_instance: any,
                resi_url: str) -> str:
    _, ean_bytes = resi_instance.provide_version_bytes(
        generate_barcode_svg(ean).encode(),
        {
            "convert": "image/png",
            "stretch": {
                "width": int(width),
                "height": int(height),
            }
        },
        track=str(getpid()))

    return import_into_resi(
        ean_bytes, resi_instance, resi_url, None, disposition)


def generate_barcode_svg(text: str) -> str:
    call = ['barcode', '-e', 'EAN', '-S']

    with Popen(call, stdin=PIPE, stdout=PIPE, stderr=PIPE, text=True) as proc:
        out, err = proc.communicate(input=text)
        if err != '':
            raise Exception("call barcode failed: %s" % err)

        return out.replace('Helvetica', 'Open Sans')
