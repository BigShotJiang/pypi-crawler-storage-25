"""
Constants for specific templates

These constants are used in specific templates to ensure that SVG
components are generated correctly, e.g.:

- https://masa.productdesignerd.puzzleandplay.de/
  templates/single-image-4-3-landscape/structure/original
- https://masa.productdesignerd.puzzleandplay.de/
  templates/box_small_500_landscape_grey/structure/original
"""

from .edit_template.render_text import (Alignment, HorizontalAlignment,
                                        RGBAColor, VerticalAlignment)

# Preview types can be overwritten by ShopAttributes in Masa.
PREVIEW_TYPE_BOX = 'box'
PREVIEW_TYPE_PARTS = 'pieces'

PREVIEW_IMAGE_FORMAT = 'jpeg'
PREVIEW_MIME_TYPE = 'image/%s' % PREVIEW_IMAGE_FORMAT
PREVIEW_QUALITY_LEVEL = 90
DEFAULT_PREVIEW_SIZE = 1500

MOTIVE_PLACEHOLDER_ID = 'img-main'
MOTIVE_USE_ID = 'img-main-use'

TITLE_PLACEHOLDER_ID = 'txt-main'
TITLE_ALIGNMENT = Alignment(
    vertical=VerticalAlignment.Top, horizontal=HorizontalAlignment.Center)
TITLE_FONT = 'FreeSerif'
TITLE_COLOR_FOREGROUND = RGBAColor(255, 255, 255, 1.0)
TITLE_COLOR_BACKGROUND = RGBAColor(0, 0, 0, 0.0)

EAN_PLACEHOLDER_ID = 'img-ean'

MANUFACTURER_ADDRESS_PLACEHOLDER_ID = 'manufacturer-address'
MANUFACTURER_ADDRESS_ALIGNMENT = Alignment(
    vertical=VerticalAlignment.Center, horizontal=HorizontalAlignment.Center)
MANUFACTURER_ADDRESS_FONT = 'Open Sans'
MANUFACTURER_ADDRESS_COLOR_FOREGROUND = RGBAColor(0, 0, 0, 1.0)
MANUFACTURER_ADDRESS_COLOR_BACKGROUND = RGBAColor(0, 0, 0, 0.0)
