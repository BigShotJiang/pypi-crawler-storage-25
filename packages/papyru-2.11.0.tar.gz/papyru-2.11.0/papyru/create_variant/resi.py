from os import getpid
from typing import Optional

import resi


def import_into_resi(data: bytes,
                     resi_instance: resi.Instance,
                     resi_url: str,
                     properties: Optional[resi.VersionProperties] = None,
                     disposition: Optional[str] = None
                     ) -> str:

    if properties is not None:
        properties.is_derived = False

    with resi_instance.import_image_binary(data,
                                           properties=properties,
                                           track=str(getpid())) as img:
        if disposition is not None:
            img.set_properties(disposition=disposition)

        location = '%s/images/%s' % (resi_url, img.ref_number)

    return location
