from papyru import XMLHelper

from .edit_template.ean import insert_ean
from .edit_template.manufacturer_address import insert_manufacturer_address
from .edit_template.motive import insert_motive
from .edit_template.title import insert_title
from .edit_template.xml import ImageInfo
from .resi import import_into_resi


def create_component(template: str,
                     motive_image_info: ImageInfo,
                     resi_instance: object,
                     resi_url: str,
                     disposition_component: str,
                     disposition_manufacturer_address: str,
                     disposition_title=None,
                     motive_title=None,
                     disposition_ean=None,
                     ean=None,
                     properties=None,
                     ) -> str:

    doc = XMLHelper(template)
    insert_motive(doc, motive_image_info)
    insert_title(doc, motive_title, disposition_title, resi_instance, resi_url)
    insert_ean(doc, ean, disposition_ean, resi_instance, resi_url)
    insert_manufacturer_address(doc, disposition_manufacturer_address,
                                resi_instance, resi_url)

    return import_into_resi(doc.serialize(doc.root),
                            resi_instance,
                            resi_url,
                            properties,
                            disposition_component)
