# sentrytriage Release Runbook

How to cut and publish a new `sentrytriage` release to PyPI.

## Prerequisites

1. **`tesla-clip-tools` must already be published to PyPI** (sentrytriage depends on it).
   Verify with:
   ```bash
   pip index versions tesla-clip-tools
   ```
   The version available on PyPI must satisfy the `tesla-clip-tools>=0.3` pin in
   `pyproject.toml`. If it doesn't, publish `tesla-clip-tools` first (see its own
   `RELEASE.md`) and bump the pin here if needed.
2. You have a PyPI account with maintainer rights on the `sentrytriage` project,
   and an API token configured in `~/.pypirc` (or set via `UV_PUBLISH_TOKEN`).
3. `uv` is on PATH (`/c/Users/rpr29/AppData/Roaming/Python/Python314/Scripts`).
4. Working tree is clean (`git status` shows no uncommitted changes).
5. You're on `main` and pulled latest.

## Steps

### 1. Bump the version

Edit `pyproject.toml` and bump `version = "0.12.0"` to the new release version.
Follow semver: bug fix -> patch, new feature -> minor, breaking change -> major.

### 2. Update CHANGELOG.md

Move items from `Unreleased` into a new dated section for the new version.
Keep the `Unreleased` heading at the top with empty subsections.

### 3. Run the full test suite

```bash
uv run pytest -q
```

All 98 tests must pass. If any fail, stop and fix before continuing.

Also run the linter:
```bash
uv run ruff check src tests
```

### 4. Build artifacts

From the repo root:

```bash
rm -rf dist/
uv build
```

This should produce:
- `dist/sentrytriage-X.Y.Z.tar.gz`
- `dist/sentrytriage-X.Y.Z-py3-none-any.whl`

### 5. Verify the wheel installs and imports cleanly

```bash
uv venv /tmp/release-test
/tmp/release-test/Scripts/pip install dist/sentrytriage-X.Y.Z-py3-none-any.whl
/tmp/release-test/Scripts/python -c "from sentrytriage.cli import app; print('ok')"
```

Also confirm the FastAPI templates are bundled (they're loaded by `web.py` at runtime):
```bash
python -m zipfile -l dist/sentrytriage-X.Y.Z-py3-none-any.whl | grep templates
```
You should see all five HTML templates: `base.html`, `events.html`, `event_detail.html`,
`index.html`, `overrides.html`. If any are missing, the dashboard will 500 in production.
Fix by adding `[tool.hatch.build.targets.wheel.force-include]` for the templates dir.

### 6. Smoke-test the CLI entry point

```bash
/tmp/release-test/Scripts/triage --help
```

Should print the Typer help banner. If the entry point is broken, the wheel is bad.

### 7. Tag the release

```bash
git add pyproject.toml CHANGELOG.md
git commit -m "Release vX.Y.Z"
git tag vX.Y.Z
```

### 8. Publish to TestPyPI first (optional but recommended for major versions)

```bash
uv publish --publish-url https://test.pypi.org/legacy/ dist/*
```

Then verify by installing from TestPyPI in a fresh venv:
```bash
pip install --index-url https://test.pypi.org/simple/ \
    --extra-index-url https://pypi.org/simple/ sentrytriage
```

### 9. Publish to PyPI

```bash
uv publish dist/*
```

### 10. Push to GitHub

```bash
git push origin main
git push origin vX.Y.Z
```

Then create a GitHub Release from the tag, pasting the CHANGELOG section as the body.

### 11. Post-publish smoke test

In a fresh venv on a different machine if possible (catches stale local-state assumptions):
```bash
pip install sentrytriage
triage demo
```

Confirm the demo command runs end-to-end and the dashboard at `http://localhost:8000`
serves all five template pages without 500s.

There are no downstream consumers of `sentrytriage` in this workspace, so no further
dependency bumps are required.
