# Contributing to sentrytriage

Local AI triage for Tesla Sentry events — watches your `SentryClips` folder, sends each event's keyframes to a vision-language model, and classifies the event so you only get notified about the ones that actually matter.

## Quickstart for contributors

```bash
# Clone
git clone https://github.com/Raymondriter/sentrytriage.git
cd sentrytriage

# Install with dev extras
uv sync --all-extras

# Run tests
uv run pytest -q

# Lint
uv run ruff check .
```

## What kind of contributions are welcome

- **Prompt-tuning improvements** — the classification prompt at `prompts/classify.md` is the heart of the project. False-positive and false-negative reports (with example clips or descriptions) are valuable on their own; PRs that tighten the prompt while keeping the overall regression suite green are very welcome.
- **New dashboard views** — the FastAPI + Jinja dashboard in `src/sentrytriage/web/` is intentionally small. Charts (events-per-day exists; per-category trend lines, per-cam heatmaps, hour-of-day histograms are open), filter controls, and per-event drilldowns are all good areas.
- **More source plugin coverage** — new IP-camera vendors get added upstream in [`tesla-clip-tools`](https://github.com/Raymondriter/tesla-clip-tools) under the `Source` protocol; once they're there, the wiring on this side is just one line in the `--source-type` dispatch in `cli.py`.
- **New VLM backends** — same story. Add the backend in `tesla-clip-tools/src/tesla_clip_tools/vlm/`, then expose it via `--backend` in this repo's CLI.
- **New notifiers** — Discord and email are the most-requested. Implement under `tesla-clip-tools` and wire here.

Bug reports for the dashboard, SQLite schema, and the suppression / reel commands are equally welcome.

## What to read first

The pipeline composes cleanly: source → sampler → VLM → store → (notifier | dashboard | reel). Start in `cli.py` to see how the commands wire those layers together, then read `web/__init__.py` for the dashboard surface. The `Source`, `VLMBackend`, and `Notifier` protocols all live in [`tesla-clip-tools`](https://github.com/Raymondriter/tesla-clip-tools) — this repo is mostly the application logic that uses them.

## Commit conventions

`type: short imperative description` — types are `feat`, `fix`, `refactor`, `test`, `chore`, `docs`. Lowercase. No period. One logical change per commit.

## Pull request flow

1. Fork the repo.
2. Branch off `main` (e.g. `feat/per-cam-heatmap`).
3. Write tests for your change. The dashboard uses FastAPI's `TestClient` — see existing tests under `tests/test_web*.py`.
4. Push and open a PR against `main`.
5. CI must be green (ruff + pytest on Python 3.12 and 3.13).
6. One review approval before merge. Right now the only reviewer is [@Raymondriter](https://github.com/Raymondriter); expect a turnaround within a few days.

## Where to ask questions

Use [GitHub Discussions](https://github.com/Raymondriter/sentrytriage/discussions) for design questions, prompt-tuning collaboration, and anything that isn't a confirmed bug. Open issues only for confirmed bugs and concrete feature requests.

## What NOT to PR

- PRs that bundle unrelated changes (split them up — one logical change per PR).
- New features without tests. The pipeline is small enough that a missing test will rot the next refactor.
- License changes. The project is MIT and will stay that way.
- New runtime dependencies without a clear justification. Most additions belong upstream in `tesla-clip-tools`, not here.
- Auto-deletion of clips, ever. Suppression only moves files between folders; this is a load-bearing design choice.

## Code of Conduct

Participation in this project is governed by the [Code of Conduct](CODE_OF_CONDUCT.md).
