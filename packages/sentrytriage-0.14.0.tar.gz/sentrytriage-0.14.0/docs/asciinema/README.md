# asciinema demo

`asciinema` was not on `PATH` when this directory was prepared, so no
`demo.cast` recording is checked in yet. The intended capture is a single
60-90 second session that walks through the full feedback loop on the
synthetic demo data.

## Recording the cast

Once `asciinema` is installed (`brew install asciinema`, `pipx install
asciinema`, or `apt install asciinema`):

```bash
cd /path/to/sentrytriage
asciinema rec docs/asciinema/demo.cast \
  --title "sentrytriage: classify -> thumb -> tune -> evaluate"
```

In the recorded shell, run roughly this script. Pause for a beat between
commands so the cast is readable on playback:

```bash
# 1. Seed ~60 deterministic synthetic Sentry events.
uv run triage demo-seed --events 60

# 2. Open the dashboard (boots uvicorn + opens your browser).
#    Click around: dashboard -> events?interesting=true -> a detail page,
#    tap the thumbs-down to register a disagreement, then back out.
uv run triage demo &
DEMO_PID=$!
sleep 8
kill $DEMO_PID

# 3. Append the new disagreements to the prompt as few-shot examples.
uv run triage tune-prompt --in prompts/classify.md \
  --out prompts/classify.tuned.md

# 4. Score baseline-vs-tuned on a held-out test split using the mock
#    backend — no API key, fully deterministic.
uv run triage evaluate --backend mock --random-seed 42
```

Stop the recording with `Ctrl-D` (or `exit`). Optionally trim with
`asciinema cut` and bump the playback speed by editing the cast file's
header (`"idle_time_limit": 1.5`).

## Hosting / embedding

The README links to `docs/asciinema/demo.cast` directly so anyone with the
[asciinema player](https://github.com/asciinema/asciinema-player) (or
GitHub's preview if/when it ships native support) can play it inline.
You can also `asciinema upload demo.cast` to get a shareable URL and add
it as a badge in the README.
