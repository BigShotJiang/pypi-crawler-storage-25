## Summary
<!-- 1-2 sentences. What changed and why. -->

## Test plan
<!-- How a reviewer can verify this works. -->
- [ ] `uv run pytest -q`
- [ ] `uv run ruff check .` is clean
- [ ] If touching the dashboard: tested against `triage demo` at http://127.0.0.1:8001/

## Linked issues
<!-- Use "Fixes #N" or "Closes #N" to auto-close on merge. -->

## Checklist
- [ ] Tests added or updated
- [ ] CHANGELOG.md `[Unreleased]` updated if user-visible
- [ ] Templates updated if the dashboard changed
- [ ] No new dependencies (or justified)
