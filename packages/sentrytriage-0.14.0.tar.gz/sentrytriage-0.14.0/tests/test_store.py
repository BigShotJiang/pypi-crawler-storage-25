"""Direct tests for Store methods that aren't already covered through the web layer."""

from __future__ import annotations

from datetime import UTC, date, datetime, timedelta
from pathlib import Path

from sentrytriage.store import EventRecord, Store


def _make_event(
    suffix: str,
    *,
    interesting: bool | None,
    when: datetime,
    category: str = "person_pass",
) -> EventRecord:
    return EventRecord(
        id=f"tesla:{suffix}",
        timestamp=when,
        folder=f"~/Tesla/SentryClips/{suffix}",
        interesting=interesting,
        category=category,
        one_line_caption=f"event {suffix}",
        confidence=0.8,
        classified_at=when + timedelta(minutes=3),
    )


# ---------------------------------------------------------------------------
# set_feedback / get_feedback
# ---------------------------------------------------------------------------


def test_set_feedback_inserts(tmp_path: Path) -> None:
    store = Store(tmp_path / "fb.db")
    store.upsert(_make_event("a", interesting=False, when=datetime(2026, 5, 9, tzinfo=UTC)))
    row = store.set_feedback("tesla:a", True)
    assert row.event_id == "tesla:a"
    assert row.value is True
    assert store.get_feedback("tesla:a") is True


def test_set_feedback_updates_existing(tmp_path: Path) -> None:
    store = Store(tmp_path / "fb.db")
    store.upsert(_make_event("a", interesting=True, when=datetime(2026, 5, 9, tzinfo=UTC)))
    store.set_feedback("tesla:a", False)
    store.set_feedback("tesla:a", True)
    assert store.get_feedback("tesla:a") is True


def test_get_feedback_missing_returns_none(tmp_path: Path) -> None:
    store = Store(tmp_path / "fb.db")
    assert store.get_feedback("nope") is None


# ---------------------------------------------------------------------------
# feedback_stats
# ---------------------------------------------------------------------------


def test_feedback_stats_classifies_agree_and_overrides(tmp_path: Path) -> None:
    store = Store(tmp_path / "fb.db")
    base = datetime(2026, 5, 9, 10, tzinfo=UTC)

    # VLM says interesting, user agrees                  → agree
    # VLM says boring, user says interesting             → override_to_interesting
    # VLM says interesting, user says boring             → override_to_boring
    # VLM says unclassified, user says interesting       → override_to_interesting
    rows = [
        ("a", True),
        ("b", False),
        ("c", True),
        ("d", None),
    ]
    for i, (sfx, vlm) in enumerate(rows):
        store.upsert(_make_event(sfx, interesting=vlm, when=base + timedelta(minutes=i)))

    store.set_feedback("tesla:a", True)
    store.set_feedback("tesla:b", True)
    store.set_feedback("tesla:c", False)
    store.set_feedback("tesla:d", True)

    stats = store.feedback_stats()
    assert stats == {
        "agree_count": 1,
        "override_to_interesting": 2,
        "override_to_boring": 1,
        "total": 4,
    }


def test_feedback_stats_empty(tmp_path: Path) -> None:
    store = Store(tmp_path / "fb.db")
    assert store.feedback_stats() == {
        "agree_count": 0,
        "override_to_interesting": 0,
        "override_to_boring": 0,
        "total": 0,
    }


# ---------------------------------------------------------------------------
# events_per_day
# ---------------------------------------------------------------------------


def test_events_per_day_returns_window_with_zero_fill(tmp_path: Path) -> None:
    store = Store(tmp_path / "epd.db")
    today = date(2026, 5, 9)
    # Two events today, one event 2 days ago, none on the other 11 days
    store.upsert(_make_event("today-1", interesting=True,
                             when=datetime.combine(today, datetime.min.time())))
    store.upsert(_make_event("today-2", interesting=False,
                             when=datetime.combine(today, datetime.min.time()) + timedelta(hours=3)))
    two_days = datetime.combine(today - timedelta(days=2), datetime.min.time()) + timedelta(hours=8)
    store.upsert(_make_event("two-days-ago", interesting=False, when=two_days))

    rows = store.events_per_day(days=14, today=today)
    assert len(rows) == 14
    # Newest day at the end, oldest at index 0
    assert rows[-1] == (today, 2)
    assert rows[-3] == (today - timedelta(days=2), 1)
    # Every other day in window is zero
    nonzero_days = [d for d, n in rows if n > 0]
    assert nonzero_days == [today - timedelta(days=2), today]


def test_events_per_day_default_window_size(tmp_path: Path) -> None:
    store = Store(tmp_path / "epd.db")
    rows = store.events_per_day()  # default 14 days
    assert len(rows) == 14
    assert all(n == 0 for _, n in rows)


def test_events_per_day_excludes_older_than_window(tmp_path: Path) -> None:
    store = Store(tmp_path / "epd.db")
    today = date(2026, 5, 9)
    too_old = datetime.combine(today - timedelta(days=30), datetime.min.time())
    store.upsert(_make_event("ancient", interesting=False, when=too_old))
    rows = store.events_per_day(days=14, today=today)
    assert sum(n for _, n in rows) == 0


# ---------------------------------------------------------------------------
# v0.8 — list_overrides
# ---------------------------------------------------------------------------


def test_list_overrides_excludes_agreements(tmp_path: Path) -> None:
    store = Store(tmp_path / "ov.db")
    base = datetime(2026, 5, 9, 10, tzinfo=UTC)
    store.upsert(_make_event("a", interesting=True, when=base))
    store.upsert(_make_event("b", interesting=False, when=base + timedelta(minutes=1)))
    store.set_feedback("tesla:a", True)   # agree
    store.set_feedback("tesla:b", True)   # override -> interesting
    rows = store.list_overrides()
    assert len(rows) == 1
    ev, fb = rows[0]
    assert ev.id == "tesla:b"
    assert fb.value is True


def test_list_overrides_includes_unclassified_with_feedback(tmp_path: Path) -> None:
    """VLM unclassified + user verdict counts as an override."""
    store = Store(tmp_path / "ov.db")
    when = datetime(2026, 5, 9, 10, tzinfo=UTC)
    store.upsert(_make_event("u", interesting=None, when=when))
    store.set_feedback("tesla:u", True)
    rows = store.list_overrides()
    assert len(rows) == 1
    assert rows[0][0].id == "tesla:u"


def test_list_overrides_newest_first(tmp_path: Path) -> None:
    store = Store(tmp_path / "ov.db")
    base = datetime(2026, 5, 9, 10, tzinfo=UTC)
    store.upsert(_make_event("a", interesting=True, when=base))
    store.upsert(_make_event("b", interesting=True, when=base + timedelta(minutes=1)))
    # Both VLM said interesting, user marks both boring (overrides).
    # Set feedback in chronological order so created_at ordering is deterministic.
    store.set_feedback("tesla:a", False)
    import time
    time.sleep(0.01)  # ensure created_at differs at second resolution? It's UTC datetime, microsecond precision.
    store.set_feedback("tesla:b", False)
    rows = store.list_overrides()
    assert [ev.id for ev, _ in rows] == ["tesla:b", "tesla:a"]


def test_list_overrides_respects_limit(tmp_path: Path) -> None:
    store = Store(tmp_path / "ov.db")
    base = datetime(2026, 5, 9, 10, tzinfo=UTC)
    for i in range(5):
        store.upsert(_make_event(f"e{i}", interesting=True, when=base + timedelta(minutes=i)))
        store.set_feedback(f"tesla:e{i}", False)  # all overrides
    assert len(store.list_overrides(limit=3)) == 3
    assert len(store.list_overrides(limit=10)) == 5


def test_list_overrides_empty(tmp_path: Path) -> None:
    store = Store(tmp_path / "ov.db")
    assert store.list_overrides() == []
