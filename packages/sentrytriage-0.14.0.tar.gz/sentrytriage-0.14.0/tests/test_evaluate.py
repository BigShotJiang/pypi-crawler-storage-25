"""Tests for the A/B evaluation module."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

from sentrytriage.classifier import EventCategory, EventClassification
from sentrytriage.evaluate import (
    _build_text_only_payload,
    _make_vlm_backed_classifier,
    build_eval_items,
    compare_prompts,
    evaluate_prompt,
    make_anthropic_classifier,
    make_gemini_classifier,
    make_ollama_classifier,
    make_openai_classifier,
    mock_classifier,
    train_test_split,
)
from sentrytriage.store import EventRecord, Feedback
from sentrytriage.tune import build_tuned_prompt

BASE_PROMPT = "# baseline\n\n## Worked examples\n\n(none)\n"


def _ev(suffix: str, *, interesting: bool | None, caption: str,
        category: str = "person_pass", subjects=None,
        folder: str | None = None) -> EventRecord:
    return EventRecord(
        id=f"tesla:{suffix}",
        timestamp=datetime(2026, 5, 12, 10, tzinfo=UTC),
        folder=folder if folder is not None else f"~/SentryClips/{suffix}",
        interesting=interesting,
        category=category,
        one_line_caption=caption,
        confidence=0.8,
        subjects_json=json.dumps(subjects or []),
    )


def _fb(suffix: str, *, value: bool) -> Feedback:
    return Feedback(
        event_id=f"tesla:{suffix}",
        value=value,
        created_at=datetime(2026, 5, 12, 11, tzinfo=UTC),
    )


# ---------------------------------------------------------------------------
# evaluate_prompt — pure scoring
# ---------------------------------------------------------------------------


def test_evaluate_prompt_counts_matches() -> None:
    items = [
        (_ev("a", interesting=False, caption="c1"), True),
        (_ev("b", interesting=True, caption="c2"), True),
        (_ev("c", interesting=False, caption="c3"), False),
    ]
    # Stub classifier always says True
    result = evaluate_prompt("ignored", items, lambda _p, _e: True)
    assert result.total == 3
    assert result.correct == 2  # rows where ground-truth was True
    assert abs(result.accuracy - 2 / 3) < 1e-9


def test_evaluate_empty_returns_zero_accuracy() -> None:
    result = evaluate_prompt("p", [], lambda _p, _e: True)
    assert result.total == 0
    assert result.accuracy == 0.0


def test_evaluate_per_category_breakdown() -> None:
    items = [
        (_ev("a", interesting=False, caption="x", category="animal"), True),
        (_ev("b", interesting=False, caption="y", category="animal"), False),
        (_ev("c", interesting=True, caption="z", category="person_approach"), True),
    ]
    result = evaluate_prompt("p", items, lambda _p, e: e.interesting)
    # Predictions follow VLM verdicts: a=False (wrong), b=False (right), c=True (right)
    assert result.per_category["animal"] == (1, 2)
    assert result.per_category["person_approach"] == (1, 1)


# ---------------------------------------------------------------------------
# compare_prompts
# ---------------------------------------------------------------------------


def test_compare_prompts_reports_deltas() -> None:
    items = [(_ev("a", interesting=False, caption="x"), True)]
    # Baseline classifier always wrong, tuned classifier always right
    cmp = compare_prompts(
        "base", "tuned", items,
        lambda p, _e: p == "tuned",
    )
    assert cmp.baseline.correct == 0
    assert cmp.tuned.correct == 1
    assert cmp.correct_delta == 1
    assert cmp.accuracy_delta == 1.0


# ---------------------------------------------------------------------------
# mock_classifier
# ---------------------------------------------------------------------------


def test_mock_classifier_keyword_rules() -> None:
    # Caption containing "approaches" -> True via keyword rule
    ev_yes = _ev("a", interesting=False, caption="Stranger approaches the door.")
    ev_no = _ev("b", interesting=False, caption="A leaf moves in the wind.")
    assert mock_classifier(BASE_PROMPT, ev_yes) is True
    assert mock_classifier(BASE_PROMPT, ev_no) is False


def test_mock_classifier_learns_from_few_shot_examples() -> None:
    """When the prompt contains a few-shot block for a given caption, the
    mock returns the corrected label — this simulates prompt tuning."""
    ev = _ev("a", interesting=False, caption="A leaf moves in the wind.")
    # Without tuning -> keyword rules say False
    assert mock_classifier(BASE_PROMPT, ev) is False

    # Tune the prompt with an override saying this event IS interesting
    overrides = [(ev, _fb("a", value=True))]
    tuned = build_tuned_prompt(BASE_PROMPT, overrides).prompt
    # Now the mock should pick up the corrected label from the prompt
    assert mock_classifier(tuned, ev) is True


def test_compare_with_mock_classifier_shows_tune_benefit() -> None:
    """End-to-end: tune-prompt + mock evaluator should show baseline < tuned."""
    overrides = [
        (_ev("a", interesting=False,
             caption="A leaf moves in the wind."), _fb("a", value=True)),
        (_ev("b", interesting=True,
             caption="Pedestrian walks past on the sidewalk without stopping.",
             category="person_pass"), _fb("b", value=False)),
    ]
    items = build_eval_items(overrides)
    tuned = build_tuned_prompt(BASE_PROMPT, overrides).prompt
    cmp = compare_prompts(BASE_PROMPT, tuned, items, mock_classifier)
    # By construction, baseline disagrees on every override (those ARE the disagreements);
    # the tuned prompt now reflects each correction so accuracy should jump to 100%.
    assert cmp.tuned.accuracy == 1.0
    assert cmp.tuned.correct > cmp.baseline.correct


# ---------------------------------------------------------------------------
# build_eval_items
# ---------------------------------------------------------------------------


def test_train_test_split_is_deterministic_for_same_seed() -> None:
    pairs = [(_ev(f"e{i}", interesting=False, caption=f"c{i}"),
              _fb(f"e{i}", value=True)) for i in range(10)]
    a_train, a_test = train_test_split(pairs, random_seed=7)
    b_train, b_test = train_test_split(pairs, random_seed=7)
    assert [ev.id for ev, _ in a_train] == [ev.id for ev, _ in b_train]
    assert [ev.id for ev, _ in a_test] == [ev.id for ev, _ in b_test]


def test_train_test_split_respects_fraction() -> None:
    pairs = [(_ev(f"e{i}", interesting=False, caption=f"c{i}"),
              _fb(f"e{i}", value=True)) for i in range(10)]
    train, test = train_test_split(pairs, train_fraction=0.7)
    assert len(train) == 7
    assert len(test) == 3
    # No overlap between train and test
    train_ids = {ev.id for ev, _ in train}
    test_ids = {ev.id for ev, _ in test}
    assert not (train_ids & test_ids)
    assert train_ids | test_ids == {f"tesla:e{i}" for i in range(10)}


def test_train_test_split_keeps_at_least_one_in_train() -> None:
    """Even a tiny override set returns at least one training example."""
    pairs = [(_ev("a", interesting=False, caption="x"), _fb("a", value=True))]
    train, test = train_test_split(pairs, train_fraction=0.7)
    assert len(train) == 1
    assert test == []


def test_train_test_split_rejects_invalid_fraction() -> None:
    import pytest
    with pytest.raises(ValueError):
        train_test_split([], train_fraction=0.0)
    with pytest.raises(ValueError):
        train_test_split([], train_fraction=1.0)


def test_build_eval_items_uses_user_value_as_label() -> None:
    pairs = [
        (_ev("a", interesting=False, caption="x"), _fb("a", value=True)),
        (_ev("b", interesting=True, caption="y"), _fb("b", value=False)),
    ]
    items = build_eval_items(pairs)
    assert [(ev.id, label) for ev, label in items] == [
        ("tesla:a", True),
        ("tesla:b", False),
    ]


# ---------------------------------------------------------------------------
# Real VLM-backed classifiers — exercise via _make_vlm_backed_classifier so
# we don't need real API keys or a running Ollama. Each test injects a
# MagicMock VLMBackend so the test asserts the *wrapper* logic
# (keyframes-first vs. text-only fallback vs. None on failure), not the
# underlying VLM.
# ---------------------------------------------------------------------------


def _verdict(*, interesting: bool, caption: str = "auto verdict") -> EventClassification:
    return EventClassification(
        interesting=interesting,
        category=EventCategory.PERSON_PASS,
        subjects=["test subject"],
        one_line_caption=caption,
        confidence=0.9,
    )


def test_real_classifier_uses_keyframes_when_folder_exists(tmp_path: Path) -> None:
    """Folder + video on disk -> keyframe path runs, VLM verdict is returned."""
    folder = tmp_path / "2026-05-12_10-00-00"
    folder.mkdir()
    (folder / "front.mp4").write_bytes(b"fake-mp4")  # presence is enough
    event = _ev("k1", interesting=False, caption="caption", folder=str(folder))

    fake_vlm = MagicMock()
    fake_vlm.classify.return_value = _verdict(interesting=True)

    # Patch sample_keyframes inside the evaluate module so the call returns
    # one usable Sample without touching ffmpeg.
    fake_sample = MagicMock()
    fake_sample.image = MagicMock()
    fake_sample.cam = "front"
    fake_sample.timestamp_seconds = 1.0
    with patch("tesla_clip_tools.sampler.sample_keyframes", return_value=[fake_sample]):
        classify = _make_vlm_backed_classifier(fake_vlm, backend_label="test")
        result = classify("prompt-text", event)

    assert result is True
    assert fake_vlm.classify.call_count == 1
    # The first positional arg should be the list of one image (keyframe path).
    images_arg = fake_vlm.classify.call_args.args[0]
    assert len(images_arg) == 1


def test_real_classifier_falls_back_to_text_when_folder_missing() -> None:
    """No folder on disk -> classifier skips keyframes and uses text-only."""
    event = _ev(
        "missing", interesting=False, caption="A leaf moves in the wind.",
        subjects=["leaf"],
        folder="/this/path/does/not/exist/anywhere",
    )

    fake_vlm = MagicMock()
    fake_vlm.classify.return_value = _verdict(interesting=False)

    classify = _make_vlm_backed_classifier(fake_vlm, backend_label="test")
    result = classify("system-prompt", event)

    assert result is False
    # Exactly one call (text-only path), and it was given a single placeholder image.
    assert fake_vlm.classify.call_count == 1
    images_arg = fake_vlm.classify.call_args.args[0]
    assert len(images_arg) == 1


def test_real_classifier_returns_none_when_both_paths_fail() -> None:
    """Folder missing AND text-only call raises -> classifier returns None and warns."""
    event = _ev("doomed", interesting=False, caption="caption",
                folder="/no/such/folder")

    fake_vlm = MagicMock()
    fake_vlm.classify.side_effect = RuntimeError("API down")

    classify = _make_vlm_backed_classifier(fake_vlm, backend_label="test")
    result = classify("prompt", event)

    assert result is None
    assert fake_vlm.classify.call_count == 1  # one text-only attempt, no folder so no keyframes try


def test_real_classifier_falls_back_when_keyframe_call_raises(tmp_path: Path) -> None:
    """Keyframe path blows up -> classifier still returns the text-only verdict."""
    folder = tmp_path / "2026-05-12_11-00-00"
    folder.mkdir()
    (folder / "front.mp4").write_bytes(b"x")
    event = _ev("flaky", interesting=False, caption="caption", folder=str(folder))

    # First call (keyframe path) raises; second call (text-only) succeeds.
    fake_vlm = MagicMock()
    fake_vlm.classify.side_effect = [
        RuntimeError("timeout"),
        _verdict(interesting=True),
    ]

    fake_sample = MagicMock()
    fake_sample.image = MagicMock()
    fake_sample.cam = "front"
    fake_sample.timestamp_seconds = 0.5
    with patch("tesla_clip_tools.sampler.sample_keyframes", return_value=[fake_sample]):
        classify = _make_vlm_backed_classifier(fake_vlm, backend_label="test")
        result = classify("prompt", event)

    assert result is True
    assert fake_vlm.classify.call_count == 2  # tried keyframes, then text


def test_text_only_payload_includes_caption_and_subjects() -> None:
    """The text-only fallback prompt must surface both the caption and subjects."""
    event = _ev(
        "with-subjects", interesting=False,
        caption="Delivery driver in red hat walks past.",
        subjects=["delivery driver", "red hat"],
    )
    _, user_text = _build_text_only_payload("system-prompt", event)
    assert "Delivery driver in red hat walks past." in user_text
    assert "delivery driver" in user_text
    assert "red hat" in user_text
    # Schema expectation must be made explicit so the VLM returns structured output.
    assert "interesting" in user_text


def test_make_openai_classifier_uses_openai_backend() -> None:
    """make_openai_classifier wires the OpenAIBackend constructor with the model."""
    with patch("tesla_clip_tools.vlm.openai.OpenAIBackend") as fake_ctor:
        fake_ctor.return_value = MagicMock()
        classifier = make_openai_classifier(model="gpt-4o")
    fake_ctor.assert_called_once_with(model="gpt-4o")
    assert callable(classifier)


def test_make_ollama_classifier_uses_ollama_backend() -> None:
    """make_ollama_classifier wires the OllamaBackend constructor with the model."""
    with patch("tesla_clip_tools.vlm.ollama.OllamaBackend") as fake_ctor:
        fake_ctor.return_value = MagicMock()
        classifier = make_ollama_classifier(model="qwen2.5vl:3b")
    fake_ctor.assert_called_once_with(model="qwen2.5vl:3b")
    assert callable(classifier)


def test_make_anthropic_classifier_uses_anthropic_backend() -> None:
    """make_anthropic_classifier wires the AnthropicBackend constructor with the model."""
    with patch("tesla_clip_tools.vlm.anthropic.AnthropicBackend") as fake_ctor:
        fake_ctor.return_value = MagicMock()
        classifier = make_anthropic_classifier(model="claude-haiku-4-6")
    fake_ctor.assert_called_once_with(model="claude-haiku-4-6")
    assert callable(classifier)


def test_make_anthropic_classifier_default_model_is_sonnet_4_6() -> None:
    """The default Anthropic model must be claude-sonnet-4-6 (the v0.5 baseline)."""
    with patch("tesla_clip_tools.vlm.anthropic.AnthropicBackend") as fake_ctor:
        fake_ctor.return_value = MagicMock()
        make_anthropic_classifier()
    fake_ctor.assert_called_once_with(model="claude-sonnet-4-6")


def test_make_gemini_classifier_uses_gemini_backend() -> None:
    """make_gemini_classifier wires the GeminiBackend constructor with the model."""
    with patch("tesla_clip_tools.vlm.gemini.GeminiBackend") as fake_ctor:
        fake_ctor.return_value = MagicMock()
        classifier = make_gemini_classifier(model="gemini-2.0-flash")
    fake_ctor.assert_called_once_with(model="gemini-2.0-flash")
    assert callable(classifier)


def test_make_gemini_classifier_default_model_is_flash_2_5() -> None:
    """The default Gemini model must be gemini-2.5-flash (the v0.5 baseline)."""
    with patch("tesla_clip_tools.vlm.gemini.GeminiBackend") as fake_ctor:
        fake_ctor.return_value = MagicMock()
        make_gemini_classifier()
    fake_ctor.assert_called_once_with(model="gemini-2.5-flash")
