"""Tests for the demo-seed function."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta, timezone  # noqa: F401
from pathlib import Path

from sentrytriage.classifier import EventCategory
from sentrytriage.seed import (
    CATEGORY_WEIGHTS,
    DEFAULT_EVENT_COUNT,
    seed_demo_events,
)
from sentrytriage.store import Store


def test_seed_writes_default_event_count(tmp_path: Path) -> None:
    db = tmp_path / "demo.db"
    counts = seed_demo_events(db_path=db)
    assert counts["events"] == DEFAULT_EVENT_COUNT
    store = Store(db)
    events = store.list_events(limit=200)
    assert len(events) == DEFAULT_EVENT_COUNT


def test_seed_is_deterministic(tmp_path: Path) -> None:
    """Same seed + same `now` anchor must produce byte-identical event streams."""
    fixed_now = datetime(2026, 5, 12, 12, 0, tzinfo=UTC)
    db1 = tmp_path / "a.db"
    db2 = tmp_path / "b.db"
    seed_demo_events(db_path=db1, random_seed=42, now=fixed_now)
    seed_demo_events(db_path=db2, random_seed=42, now=fixed_now)
    s1 = Store(db1).list_events(limit=200)
    s2 = Store(db2).list_events(limit=200)
    assert len(s1) == len(s2)
    assert s1[0].id == s2[0].id
    assert s1[0].category == s2[0].category


def test_seed_produces_mix_of_interesting_and_boring(tmp_path: Path) -> None:
    db = tmp_path / "demo.db"
    counts = seed_demo_events(db_path=db, event_count=200, random_seed=7)
    assert counts["interesting"] >= 5
    assert counts["boring"] >= 100
    assert counts["interesting"] + counts["boring"] == 200


def test_seed_uses_known_category_values(tmp_path: Path) -> None:
    db = tmp_path / "demo.db"
    seed_demo_events(db_path=db, event_count=50, random_seed=3)
    valid = {c.value for c in EventCategory}
    for ev in Store(db).list_events(limit=100):
        assert ev.category in valid


def test_seed_spreads_across_categories(tmp_path: Path) -> None:
    """At 200 events with non-trivial weights, every category should appear at least once."""
    db = tmp_path / "demo.db"
    seed_demo_events(db_path=db, event_count=200, random_seed=11)
    cats = {e.category for e in Store(db).list_events(limit=300)}
    expected = {c.value for c in CATEGORY_WEIGHTS}
    assert cats == expected


def test_seed_event_id_uses_tesla_prefix(tmp_path: Path) -> None:
    db = tmp_path / "demo.db"
    seed_demo_events(db_path=db, event_count=5)
    for ev in Store(db).list_events(limit=10):
        assert ev.id.startswith("tesla:")


def test_seed_writes_subjects_as_json(tmp_path: Path) -> None:
    db = tmp_path / "demo.db"
    seed_demo_events(db_path=db, event_count=20, random_seed=5)
    import json as _json

    for ev in Store(db).list_events(limit=30):
        if ev.subjects_json:
            parsed = _json.loads(ev.subjects_json)
            assert isinstance(parsed, list)
            assert all(isinstance(s, str) for s in parsed)


def test_seed_events_sorted_newest_first(tmp_path: Path) -> None:
    db = tmp_path / "demo.db"
    seed_demo_events(db_path=db)
    events = Store(db).list_events(limit=200)
    timestamps = [e.timestamp for e in events]
    assert timestamps == sorted(timestamps, reverse=True)


def test_seed_event_count_overrides_default(tmp_path: Path) -> None:
    db = tmp_path / "demo.db"
    seed_demo_events(db_path=db, event_count=12)
    assert len(Store(db).list_events(limit=50)) == 12


def test_seed_classified_at_after_timestamp(tmp_path: Path) -> None:
    """Classified_at should be a few minutes after the event timestamp."""
    db = tmp_path / "demo.db"
    seed_demo_events(db_path=db, event_count=20)
    for ev in Store(db).list_events(limit=30):
        assert ev.classified_at is not None
        assert ev.classified_at > ev.timestamp
        # Within 30 minutes
        assert (ev.classified_at - ev.timestamp) < timedelta(minutes=30)
