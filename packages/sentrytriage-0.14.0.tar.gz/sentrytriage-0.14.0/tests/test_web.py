"""FastAPI route tests via TestClient — no real uvicorn needed."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from sentrytriage.store import EventRecord, Store
from sentrytriage.web import create_app, get_store

# Marker bytes the streaming test uses; not a real .mp4 — just enough to assert
# the bytes flow through FileResponse end-to-end.
_FAKE_MP4_BYTES = b"\x00\x00\x00\x20ftypisom" + b"sentrytriage-test-payload\x00" * 8


@pytest.fixture()
def seeded_store(tmp_path: Path) -> Store:
    store = Store(tmp_path / "events.db")
    base = datetime(2026, 5, 9, 10, tzinfo=UTC)
    rows = [
        ("a", "person_approach", True, 0.9, "Stranger walks up to driver door."),
        ("b", "vehicle_collision", True, 0.95, "White SUV reverses into front bumper."),
        ("c", "person_pass", False, 0.85, "Pedestrian walks past on the sidewalk."),
        ("d", "vehicle_close", False, 0.78, "Car drives past on the street, no approach."),
        ("e", "glitch", False, 0.7, "No apparent cause; possible sensor false trigger."),
        ("f", "animal", True, 0.82, "Raccoon walks across the front bumper."),
    ]
    for i, (suffix, cat, interesting, conf, caption) in enumerate(rows):
        store.upsert(
            EventRecord(
                id=f"tesla:demo-{suffix}",
                timestamp=base + timedelta(hours=i),
                folder=f"~/Tesla/SentryClips/demo-{suffix}",
                interesting=interesting,
                category=cat,
                one_line_caption=caption,
                confidence=conf,
                subjects_json=json.dumps([f"subject-{i}"]),
                classified_at=base + timedelta(hours=i, minutes=5),
            )
        )
    return store


@pytest.fixture()
def client(seeded_store: Store) -> TestClient:
    app = create_app()
    app.dependency_overrides[get_store] = lambda: seeded_store
    return TestClient(app)


def test_healthz(client: TestClient) -> None:
    r = client.get("/healthz")
    assert r.status_code == 200
    assert r.text == "ok"


def test_index_renders_with_stats(client: TestClient) -> None:
    r = client.get("/")
    assert r.status_code == 200
    assert "sentrytriage" in r.text
    assert "Total events" in r.text
    assert "person_approach" in r.text or "vehicle_collision" in r.text


def test_index_shows_category_histogram(client: TestClient) -> None:
    r = client.get("/")
    assert r.status_code == 200
    assert "Categories" in r.text
    assert "person_approach" in r.text
    assert "glitch" in r.text


def test_index_shows_interesting_section(client: TestClient) -> None:
    r = client.get("/")
    assert "Recent interesting events" in r.text
    assert "Stranger walks up to driver door" in r.text


def test_events_page_renders(client: TestClient) -> None:
    r = client.get("/events")
    assert r.status_code == 200
    assert "Pedestrian walks past" in r.text


def test_events_filter_interesting_true(client: TestClient) -> None:
    r = client.get("/events?interesting=true")
    assert r.status_code == 200
    assert "Stranger walks up" in r.text
    assert "Pedestrian walks past" not in r.text


def test_events_filter_interesting_false(client: TestClient) -> None:
    r = client.get("/events?interesting=false")
    assert r.status_code == 200
    assert "Pedestrian walks past" in r.text
    assert "Stranger walks up" not in r.text


def test_events_filter_by_category(client: TestClient) -> None:
    r = client.get("/events?category=animal")
    assert r.status_code == 200
    assert "Raccoon" in r.text
    assert "Pedestrian" not in r.text


def test_event_detail(client: TestClient) -> None:
    r = client.get("/events/tesla:demo-a")
    assert r.status_code == 200
    assert "Stranger walks up to driver door" in r.text
    assert "subject-0" in r.text  # subject rendered


def test_event_detail_404(client: TestClient) -> None:
    r = client.get("/events/does:not:exist")
    assert r.status_code == 404


def test_api_categories_returns_dict(client: TestClient) -> None:
    r = client.get("/api/categories")
    assert r.status_code == 200
    data = r.json()
    assert data["person_approach"] == 1
    assert data["vehicle_collision"] == 1


def test_api_events_returns_list(client: TestClient) -> None:
    r = client.get("/api/events")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == 6
    # Newest first
    assert rows[0]["id"] == "tesla:demo-f"


def test_api_events_filter(client: TestClient) -> None:
    r = client.get("/api/events?interesting=true")
    rows = r.json()
    assert len(rows) == 3
    assert all(row["interesting"] for row in rows)


def test_navbar_links_present(client: TestClient) -> None:
    r = client.get("/")
    assert 'href="/"' in r.text
    assert 'href="/events"' in r.text
    assert 'href="/events?interesting=true"' in r.text


def test_index_empty_state(tmp_path: Path) -> None:
    """Empty store should render an empty-state message instead of crashing."""
    empty_store = Store(tmp_path / "empty.db")
    app = create_app()
    app.dependency_overrides[get_store] = lambda: empty_store
    c = TestClient(app)
    r = c.get("/")
    assert r.status_code == 200
    assert "No events yet" in r.text


# ---------------------------------------------------------------------------
# v0.7 — feedback round-trip
# ---------------------------------------------------------------------------


def test_post_feedback_sets_value_and_returns_agreement(client: TestClient,
                                                        seeded_store) -> None:
    # tesla:demo-c is interesting=False ("Pedestrian walks past")
    r = client.post("/events/tesla:demo-c/feedback?value=true")
    assert r.status_code == 200
    body = r.json()
    assert body["event_id"] == "tesla:demo-c"
    assert body["vlm_interesting"] is False
    assert body["user_value"] is True
    assert body["agreement"] == "override"
    assert seeded_store.get_feedback("tesla:demo-c") is True


def test_post_feedback_agree_path(client: TestClient) -> None:
    # tesla:demo-a is interesting=True
    r = client.post("/events/tesla:demo-a/feedback?value=true")
    assert r.status_code == 200
    assert r.json()["agreement"] == "agree"


def test_post_feedback_rejects_garbage_value(client: TestClient) -> None:
    r = client.post("/events/tesla:demo-a/feedback?value=maybe")
    assert r.status_code == 400


def test_post_feedback_404_for_missing_event(client: TestClient) -> None:
    r = client.post("/events/does:not:exist/feedback?value=true")
    assert r.status_code == 404


def test_event_detail_renders_thumbs_buttons(client: TestClient) -> None:
    r = client.get("/events/tesla:demo-a")
    assert r.status_code == 200
    assert "thumb-up" in r.text
    assert "thumb-down" in r.text
    assert "Your verdict" in r.text


def test_event_detail_shows_existing_feedback(client: TestClient,
                                               seeded_store) -> None:
    seeded_store.set_feedback("tesla:demo-a", False)
    r = client.get("/events/tesla:demo-a")
    assert r.status_code == 200
    # interesting VLM verdict + user said boring -> override badge
    assert "override" in r.text
    assert "You marked this" in r.text


def test_index_shows_feedback_panel_after_rating(client: TestClient,
                                                  seeded_store) -> None:
    seeded_store.set_feedback("tesla:demo-a", True)
    r = client.get("/")
    assert r.status_code == 200
    assert "Your feedback vs. the VLM" in r.text
    assert "Agreement" in r.text


def test_index_chart_renders_svg(client: TestClient) -> None:
    r = client.get("/")
    assert r.status_code == 200
    assert "Events per day" in r.text
    assert "<svg" in r.text


def test_api_feedback_stats(client: TestClient, seeded_store) -> None:
    seeded_store.set_feedback("tesla:demo-a", True)   # agree
    seeded_store.set_feedback("tesla:demo-c", True)   # override -> interesting
    r = client.get("/api/feedback/stats")
    assert r.status_code == 200
    body = r.json()
    assert body["total"] == 2
    assert body["agree_count"] == 1
    assert body["override_to_interesting"] == 1
    assert body["agreement_pct"] == 50


# ---------------------------------------------------------------------------
# v0.8 — overrides routes + dashboard panel
# ---------------------------------------------------------------------------


def test_api_overrides_returns_only_disagreements(client: TestClient, seeded_store) -> None:
    seeded_store.set_feedback("tesla:demo-a", True)   # agree (VLM said interesting)
    seeded_store.set_feedback("tesla:demo-c", True)   # override (VLM said boring)
    seeded_store.set_feedback("tesla:demo-d", True)   # override (VLM said boring)
    r = client.get("/api/overrides")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == 2
    ids = {row["event_id"] for row in rows}
    assert ids == {"tesla:demo-c", "tesla:demo-d"}
    # Schema check on one row
    row = rows[0]
    for key in ("event_id", "timestamp", "folder", "vlm_interesting", "user_interesting",
                "category", "caption", "confidence", "subjects", "feedback_at"):
        assert key in row


def test_api_overrides_empty_when_no_disagreements(client: TestClient, seeded_store) -> None:
    seeded_store.set_feedback("tesla:demo-a", True)   # agree
    r = client.get("/api/overrides")
    assert r.status_code == 200
    assert r.json() == []


def test_overrides_page_renders(client: TestClient, seeded_store) -> None:
    seeded_store.set_feedback("tesla:demo-c", True)
    r = client.get("/overrides")
    assert r.status_code == 200
    assert "VLM overrides" in r.text
    assert "Pedestrian walks past" in r.text  # demo-c's caption
    assert "export-overrides" in r.text  # CTA hint


def test_overrides_page_empty_state(client: TestClient) -> None:
    r = client.get("/overrides")
    assert r.status_code == 200
    assert "No overrides yet" in r.text


def test_index_shows_recent_overrides_section(client: TestClient, seeded_store) -> None:
    seeded_store.set_feedback("tesla:demo-c", True)   # override
    r = client.get("/")
    assert r.status_code == 200
    assert "Recent overrides" in r.text


def test_index_no_overrides_panel_when_only_agreements(client: TestClient, seeded_store) -> None:
    """If feedback exists but every rating agreed, the recent-overrides panel is hidden."""
    seeded_store.set_feedback("tesla:demo-a", True)   # agree
    r = client.get("/")
    assert r.status_code == 200
    assert "Recent overrides" not in r.text
    # feedback panel should still appear since there is feedback
    assert "Your feedback vs. the VLM" in r.text


def test_navbar_includes_overrides_link(client: TestClient) -> None:
    r = client.get("/")
    assert 'href="/overrides"' in r.text


# ---------------------------------------------------------------------------
# v0.12 — embedded video playback in /events/{id}
# ---------------------------------------------------------------------------


@pytest.fixture()
def clips_root(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Isolated SentryClips root so the security check passes for tmp data."""
    root = tmp_path / "SentryClips"
    root.mkdir()
    monkeypatch.setenv("SENTRYTRIAGE_CLIPS_ROOT", str(root))
    return root


@pytest.fixture()
def clips_store(tmp_path: Path, clips_root: Path) -> Store:
    """Store seeded with two events: 'has-clips' (with .mp4 files on disk) and
    'no-clips' (folder-on-disk doesn't exist — exercises demo-mode placeholder)."""
    store = Store(tmp_path / "clips.db")
    has_folder = clips_root / "2026-05-08_14-22-31"
    has_folder.mkdir()
    (has_folder / "front.mp4").write_bytes(_FAKE_MP4_BYTES)
    (has_folder / "back.mp4").write_bytes(_FAKE_MP4_BYTES)
    base = datetime(2026, 5, 8, 14, 22, 31, tzinfo=UTC)
    store.upsert(
        EventRecord(
            id="tesla:has-clips",
            timestamp=base,
            folder=str(has_folder),
            interesting=True,
            category="person_approach",
            one_line_caption="Person walks toward driver door.",
            confidence=0.9,
            subjects_json=json.dumps(["person"]),
            classified_at=base,
        )
    )
    store.upsert(
        EventRecord(
            id="tesla:no-clips",
            timestamp=base,
            folder=str(clips_root / "2026-05-09_09-00-00"),  # not on disk
            interesting=False,
            category="glitch",
            one_line_caption="Sensor false trigger.",
            confidence=0.7,
            subjects_json="[]",
            classified_at=base,
        )
    )
    return store


@pytest.fixture()
def clips_client(clips_store: Store) -> TestClient:
    app = create_app()
    app.dependency_overrides[get_store] = lambda: clips_store
    return TestClient(app)


def test_clip_route_404_when_event_missing(clips_client: TestClient) -> None:
    r = clips_client.get("/clips/does:not:exist/front.mp4")
    assert r.status_code == 404


def test_clip_route_404_when_file_missing(clips_client: TestClient) -> None:
    # Event exists but the requested cam isn't there
    r = clips_client.get("/clips/tesla:has-clips/missing.mp4")
    assert r.status_code == 404


def test_clip_route_404_when_folder_missing_on_disk(clips_client: TestClient) -> None:
    r = clips_client.get("/clips/tesla:no-clips/front.mp4")
    assert r.status_code == 404


def test_clip_route_403_on_path_traversal(clips_client: TestClient) -> None:
    # URL-encoded `../../etc/passwd` should be rejected before we open anything
    r = clips_client.get("/clips/tesla:has-clips/..%2F..%2Fetc%2Fpasswd")
    assert r.status_code == 403


def test_clip_route_403_on_non_video_suffix(
    clips_client: TestClient, clips_root: Path
) -> None:
    # A txt file in the same folder must be rejected even though it's in-root
    folder = clips_root / "2026-05-08_14-22-31"
    (folder / "secret.txt").write_text("nope")
    r = clips_client.get("/clips/tesla:has-clips/secret.txt")
    assert r.status_code == 403


def test_clip_route_serves_real_video_bytes(clips_client: TestClient) -> None:
    r = clips_client.get("/clips/tesla:has-clips/front.mp4")
    assert r.status_code == 200
    assert r.headers["content-type"] == "video/mp4"
    assert r.content == _FAKE_MP4_BYTES


def test_thumbnail_route_generates_then_caches(
    clips_client: TestClient, clips_root: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # We ship a real, decodable mini-mp4 for this one test — written with imageio
    # the same way the prod thumbnail extractor reads it.
    import imageio.v3 as iio
    import numpy as np

    folder = clips_root / "thumb-event"
    folder.mkdir()
    video = folder / "left.mp4"
    frames = np.zeros((8, 64, 64, 3), dtype=np.uint8)
    for i in range(8):
        frames[i, :, :, 1] = i * 30  # green ramp so frames differ
    iio.imwrite(str(video), frames, plugin="FFMPEG", codec="libx264")

    base = datetime(2026, 5, 9, 12, tzinfo=UTC)
    # Reuse the existing store dependency by upserting through it
    store = clips_client.app.dependency_overrides[get_store]()
    store.upsert(
        EventRecord(
            id="tesla:thumb-event",
            timestamp=base,
            folder=str(folder),
            interesting=True,
            category="person_approach",
            one_line_caption="Person.",
            confidence=0.8,
            subjects_json="[]",
            classified_at=base,
        )
    )

    thumb_cache = folder / ".thumbs" / "left.mp4.jpg"
    assert not thumb_cache.exists()

    r1 = clips_client.get("/clips/tesla:thumb-event/left.mp4/thumb.jpg")
    assert r1.status_code == 200
    assert r1.headers["content-type"] == "image/jpeg"
    assert thumb_cache.exists()
    first_mtime = thumb_cache.stat().st_mtime_ns

    # Second call must serve from cache (no re-extraction).
    # Patch _ensure_thumbnail's lazy imageio import surface: assert via mtime
    # that the file wasn't rewritten.
    r2 = clips_client.get("/clips/tesla:thumb-event/left.mp4/thumb.jpg")
    assert r2.status_code == 200
    assert thumb_cache.stat().st_mtime_ns == first_mtime, (
        "thumbnail should be served from cache, not re-extracted"
    )


def test_event_detail_renders_video_tags_when_folder_has_videos(
    clips_client: TestClient,
) -> None:
    r = clips_client.get("/events/tesla:has-clips")
    assert r.status_code == 200
    assert "<video" in r.text
    assert "/clips/tesla:has-clips/front.mp4" in r.text
    assert "/clips/tesla:has-clips/back.mp4" in r.text
    # Lazy thumbnail strip is also rendered
    assert "thumb.jpg" in r.text


def test_event_detail_graceful_placeholder_when_no_videos(
    clips_client: TestClient,
) -> None:
    r = clips_client.get("/events/tesla:no-clips")
    assert r.status_code == 200
    assert "No playable videos found" in r.text
    assert "<video" not in r.text


def test_clip_route_403_when_event_folder_outside_root(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """An event whose folder lives outside SENTRYTRIAGE_CLIPS_ROOT must NOT
    leak files even if the event record points there. Defense in depth."""
    safe_root = tmp_path / "safe-root"
    safe_root.mkdir()
    rogue_folder = tmp_path / "rogue"
    rogue_folder.mkdir()
    (rogue_folder / "front.mp4").write_bytes(_FAKE_MP4_BYTES)

    monkeypatch.setenv("SENTRYTRIAGE_CLIPS_ROOT", str(safe_root))
    store = Store(tmp_path / "rogue.db")
    base = datetime(2026, 5, 8, tzinfo=UTC)
    store.upsert(
        EventRecord(
            id="rogue:event",
            timestamp=base,
            folder=str(rogue_folder),
            interesting=True,
            category="x",
            one_line_caption="x",
            confidence=0.5,
            subjects_json="[]",
            classified_at=base,
        )
    )
    app = create_app()
    app.dependency_overrides[get_store] = lambda: store
    c = TestClient(app)
    r = c.get("/clips/rogue:event/front.mp4")
    assert r.status_code == 403


# ---------------------------------------------------------------------------
# v0.12.1 — video playback hardening (regression + edge cases)
# ---------------------------------------------------------------------------


def test_clip_route_supports_range_requests(clips_client: TestClient) -> None:
    """Browsers send `Range: bytes=N-M` when seeking inside a `<video>`. The
    route must return 206 Partial Content with the requested byte slice,
    otherwise seeking past a few seconds buffers forever in Safari/iOS."""
    r = clips_client.get(
        "/clips/tesla:has-clips/front.mp4",
        headers={"Range": "bytes=0-9"},
    )
    assert r.status_code == 206, "expected 206 Partial Content from Range request"
    assert r.content == _FAKE_MP4_BYTES[:10]
    cr = r.headers.get("content-range", "")
    assert cr.startswith("bytes 0-9/"), f"unexpected Content-Range: {cr!r}"
    assert r.headers.get("accept-ranges") == "bytes"


def test_event_detail_orders_cams_front_back_repeaters_pillars(
    clips_client: TestClient, clips_root: Path,
) -> None:
    """HW4 6-cam folder should render in (front, back, left_repeater,
    right_repeater, left_pillar, right_pillar) order — NOT alphabetical
    (which would put back before front and pillars before repeaters)."""
    folder = clips_root / "hw4-event"
    folder.mkdir()
    for name in (
        "back.mp4", "front.mp4", "right_repeater.mp4",
        "left_pillar.mp4", "left_repeater.mp4", "right_pillar.mp4",
    ):
        (folder / name).write_bytes(_FAKE_MP4_BYTES)
    base = datetime(2026, 5, 9, 12, tzinfo=UTC)
    store = clips_client.app.dependency_overrides[get_store]()
    store.upsert(
        EventRecord(
            id="tesla:hw4",
            timestamp=base,
            folder=str(folder),
            interesting=True,
            category="x",
            one_line_caption="x",
            confidence=0.5,
            subjects_json="[]",
            classified_at=base,
        )
    )
    r = clips_client.get("/events/tesla:hw4")
    assert r.status_code == 200
    body = r.text
    # Each cam URL appears exactly once; check positional ordering.
    expected_order = [
        "front.mp4", "back.mp4",
        "left_repeater.mp4", "right_repeater.mp4",
        "left_pillar.mp4", "right_pillar.mp4",
    ]
    positions = [body.index(f"/clips/tesla:hw4/{name}") for name in expected_order]
    assert positions == sorted(positions), (
        f"cam order mismatch: positions={positions} for {expected_order}"
    )


def test_filename_with_space_round_trips_through_url(
    clips_client: TestClient, clips_root: Path,
) -> None:
    """Wyze / Reolink cams sometimes include spaces (`front cam.mp4`). The
    template must percent-encode in the link, the route must accept the
    decoded name back."""
    folder = clips_root / "spaced-event"
    folder.mkdir()
    (folder / "front cam.mp4").write_bytes(_FAKE_MP4_BYTES)
    base = datetime(2026, 5, 9, 13, tzinfo=UTC)
    store = clips_client.app.dependency_overrides[get_store]()
    store.upsert(
        EventRecord(
            id="wyze:spaced",
            timestamp=base,
            folder=str(folder),
            interesting=True,
            category="x",
            one_line_caption="x",
            confidence=0.5,
            subjects_json="[]",
            classified_at=base,
        )
    )
    detail = clips_client.get("/events/wyze:spaced")
    assert detail.status_code == 200
    # Template must contain the percent-encoded form, not the raw space.
    assert "/clips/wyze:spaced/front%20cam.mp4" in detail.text
    assert "/clips/wyze:spaced/front cam.mp4" not in detail.text
    # The route must decode back to the original filename and serve.
    r = clips_client.get("/clips/wyze:spaced/front%20cam.mp4")
    assert r.status_code == 200
    assert r.content == _FAKE_MP4_BYTES


def test_symlink_pointing_outside_root_is_rejected(
    clips_client: TestClient, clips_root: Path, tmp_path: Path,
) -> None:
    """A symlink inside an event folder pointing to a file outside the clips
    root must be rejected. `_safe_path.resolve()` follows symlinks, so the
    final resolved path lands outside `_clips_root()` and is denied."""
    secret = tmp_path / "outside_secret.mp4"
    secret.write_bytes(b"top secret")
    folder = clips_root / "symlink-event"
    folder.mkdir()
    link = folder / "leak.mp4"
    try:
        link.symlink_to(secret)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks not supported on this platform / privilege level")
    base = datetime(2026, 5, 9, 14, tzinfo=UTC)
    store = clips_client.app.dependency_overrides[get_store]()
    store.upsert(
        EventRecord(
            id="rogue:symlink",
            timestamp=base,
            folder=str(folder),
            interesting=True,
            category="x",
            one_line_caption="x",
            confidence=0.5,
            subjects_json="[]",
            classified_at=base,
        )
    )
    r = clips_client.get("/clips/rogue:symlink/leak.mp4")
    assert r.status_code == 403, "symlink escape must be rejected"


def test_thumbnail_404_on_zero_byte_video(
    clips_client: TestClient, clips_root: Path,
) -> None:
    """A 0-byte / corrupt source must NOT crash the thumbnail extractor;
    the route should respond 404 with a sensible message."""
    folder = clips_root / "corrupt-event"
    folder.mkdir()
    (folder / "front.mp4").write_bytes(b"")  # zero bytes
    base = datetime(2026, 5, 9, 15, tzinfo=UTC)
    store = clips_client.app.dependency_overrides[get_store]()
    store.upsert(
        EventRecord(
            id="tesla:corrupt",
            timestamp=base,
            folder=str(folder),
            interesting=True,
            category="x",
            one_line_caption="x",
            confidence=0.5,
            subjects_json="[]",
            classified_at=base,
        )
    )
    r = clips_client.get("/clips/tesla:corrupt/front.mp4/thumb.jpg")
    assert r.status_code == 404
    # The video itself is still served (it's a valid file, just empty); the
    # browser handles the 0-byte payload itself.
    rv = clips_client.get("/clips/tesla:corrupt/front.mp4")
    assert rv.status_code == 200


def test_thumbnail_atomic_write_no_partial_files(
    clips_client: TestClient, clips_root: Path,
) -> None:
    """Concurrent thumbnail requests must not leave a half-written .jpg in
    the cache. We can't easily race in-process, but we can assert the writer
    uses a tempfile + rename path by inspecting the cache directory after
    extraction — no leftover `.tmp` files."""
    import imageio.v3 as iio
    import numpy as np

    folder = clips_root / "atomic-event"
    folder.mkdir()
    video = folder / "front.mp4"
    frames = np.zeros((8, 32, 32, 3), dtype=np.uint8)
    for i in range(8):
        frames[i, :, :, 2] = i * 30
    iio.imwrite(str(video), frames, plugin="FFMPEG", codec="libx264")

    base = datetime(2026, 5, 9, 16, tzinfo=UTC)
    store = clips_client.app.dependency_overrides[get_store]()
    store.upsert(
        EventRecord(
            id="tesla:atomic",
            timestamp=base,
            folder=str(folder),
            interesting=True,
            category="x",
            one_line_caption="x",
            confidence=0.5,
            subjects_json="[]",
            classified_at=base,
        )
    )
    r = clips_client.get("/clips/tesla:atomic/front.mp4/thumb.jpg")
    assert r.status_code == 200
    cache_dir = folder / ".thumbs"
    assert cache_dir.exists()
    # Only the final .jpg should remain — no `.tmp` debris from the atomic write.
    leftover_tmps = list(cache_dir.glob("*.tmp"))
    assert leftover_tmps == [], f"leftover tempfiles in cache: {leftover_tmps}"
    # And the cached file is non-empty (atomic rename only happened after
    # imageio finished writing the bytes).
    assert (cache_dir / "front.mp4.jpg").stat().st_size > 0


@pytest.mark.parametrize(
    "suffix,expected",
    [
        (".mp4", "video/mp4"),
        (".m4v", "video/mp4"),
        (".mov", "video/quicktime"),
        (".mkv", "video/x-matroska"),
        (".avi", "video/x-msvideo"),
    ],
)
def test_clip_route_mime_type_per_suffix(
    clips_client: TestClient, clips_root: Path,
    suffix: str, expected: str,
) -> None:
    """Each video suffix returns the correct browser-playable MIME type.
    A generic application/octet-stream would make most browsers refuse to
    play the file in a `<video>` tag (and would also reject Range requests
    in some configurations)."""
    folder = clips_root / f"mime-{suffix.strip('.')}"
    folder.mkdir()
    name = f"front{suffix}"
    (folder / name).write_bytes(_FAKE_MP4_BYTES)
    base = datetime(2026, 5, 9, 17, tzinfo=UTC)
    store = clips_client.app.dependency_overrides[get_store]()
    event_id = f"tesla:mime-{suffix.strip('.')}"
    store.upsert(
        EventRecord(
            id=event_id,
            timestamp=base,
            folder=str(folder),
            interesting=True,
            category="x",
            one_line_caption="x",
            confidence=0.5,
            subjects_json="[]",
            classified_at=base,
        )
    )
    r = clips_client.get(f"/clips/{event_id}/{name}")
    assert r.status_code == 200
    assert r.headers["content-type"] == expected


def test_event_detail_empty_folder_renders_placeholder(
    clips_client: TestClient, clips_root: Path,
) -> None:
    """An event folder that exists on disk but contains no playable videos
    must render the same `<no playable videos>` placeholder as a missing
    folder — and the clip routes still 404 for any filename."""
    folder = clips_root / "empty-folder-event"
    folder.mkdir()  # exists, but empty
    base = datetime(2026, 5, 9, 18, tzinfo=UTC)
    store = clips_client.app.dependency_overrides[get_store]()
    store.upsert(
        EventRecord(
            id="tesla:empty-folder",
            timestamp=base,
            folder=str(folder),
            interesting=False,
            category="glitch",
            one_line_caption="x",
            confidence=0.5,
            subjects_json="[]",
            classified_at=base,
        )
    )
    detail = clips_client.get("/events/tesla:empty-folder")
    assert detail.status_code == 200
    assert "No playable videos found" in detail.text
    assert "<video" not in detail.text
    # Direct clip access for any filename must still 404.
    r = clips_client.get("/clips/tesla:empty-folder/front.mp4")
    assert r.status_code == 404


def test_default_clips_root_used_when_env_unset(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Removing SENTRYTRIAGE_CLIPS_ROOT falls back to ~/Tesla/SentryClips per
    the documented default."""
    from sentrytriage.web import _clips_root

    monkeypatch.delenv("SENTRYTRIAGE_CLIPS_ROOT", raising=False)
    expected = Path("~/Tesla/SentryClips").expanduser().resolve()
    assert _clips_root() == expected
