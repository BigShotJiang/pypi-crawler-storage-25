# Test fixtures

This directory holds synthetic TeslaCam `SentryClips` folders used for end-to-end smoke tests.

## Two test surfaces

**Unit tests** (under `../../tests/test_*.py`) use **purely fake byte-payloads** for `.mp4` files (literally `b"fake-mp4"`) — they exercise the parser, the SQLModel schema, and the Pydantic validators without needing a video decoder. Those tests run with no extra setup:

```bash
uv sync --extra dev
uv run pytest
```

**End-to-end smoke tests** of the actual classifier pipeline (sampler → VLM → store → reel) need real video frames. Generate synthetic clips locally:

```bash
uv sync --extra fixture
uv run python ../../tools/generate_fixture.py --root ./SentryClips
```

This produces 4 events:

| Folder | HW | Cams | Label |
|---|---|---|---|
| `SentryClips/2026-05-08_14-22-31` | HW3 | 4 | boring |
| `SentryClips/2026-05-08_15-00-00` | HW4 | 6 | interesting |
| `SentryClips/2026-05-08_16-30-00` | HW3 | 4 | boring |
| `SentryClips/2026-05-08_17-45-00` | HW4 | 6 | interesting |

Each clip is ~4 s of color-coded video with a moving white rectangle. **The synthetic content is for pipeline-only tests** — the VLM will return nonsense classifications because the frames don't depict a real Sentry scene. To test classification quality, you need real saved Sentry clips from a Tesla.

## Using real Tesla footage

If you own a Tesla, drop a few of your own `SavedClips/` event folders here and rename them under the `YYYY-MM-DD_HH-MM-SS/` convention. Highly recommended: redact plates and faces first with [tfaehse/DashcamCleaner](https://github.com/tfaehse/DashcamCleaner) before committing or sharing.

The `.gitignore` excludes `SentryClips/` so your fixture data won't accidentally commit.
