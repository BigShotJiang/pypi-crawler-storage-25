"""Tests for the tune-prompt builder."""

from __future__ import annotations

import json
from datetime import UTC, datetime

from sentrytriage.store import EventRecord, Feedback
from sentrytriage.tune import (
    OVERRIDE_SECTION_HEADER,
    build_tuned_prompt,
)

BASE_PROMPT = "# original prompt\n\nrules go here.\n\n## Worked examples\n\n(existing examples)\n"


def _ev(suffix: str, *, interesting: bool | None, caption: str = "x",
        category: str = "person_pass", subjects: list[str] | None = None) -> EventRecord:
    return EventRecord(
        id=f"tesla:{suffix}",
        timestamp=datetime(2026, 5, 12, 10, tzinfo=UTC),
        folder=f"~/SentryClips/{suffix}",
        interesting=interesting,
        category=category,
        one_line_caption=caption,
        confidence=0.8,
        subjects_json=json.dumps(subjects or []),
    )


def _fb(suffix: str, *, value: bool) -> Feedback:
    return Feedback(
        event_id=f"tesla:{suffix}",
        value=value,
        created_at=datetime(2026, 5, 12, 11, tzinfo=UTC),
    )


def test_no_overrides_returns_prompt_unchanged() -> None:
    result = build_tuned_prompt(BASE_PROMPT, [])
    assert result.prompt == BASE_PROMPT
    assert result.examples_added == 0


def test_single_override_appends_section() -> None:
    pairs = [(
        _ev("a", interesting=False, caption="Pedestrian walks past.", category="person_pass"),
        _fb("a", value=True),
    )]
    result = build_tuned_prompt(BASE_PROMPT, pairs)
    assert result.examples_added == 1
    assert result.bumped_to_interesting == 1
    assert result.bumped_to_boring == 0
    assert OVERRIDE_SECTION_HEADER in result.prompt
    assert "Bumped to interesting" in result.prompt
    assert "Pedestrian walks past." in result.prompt
    # Original prompt content preserved
    assert "## Worked examples" in result.prompt


def test_mixed_overrides_count_correctly() -> None:
    pairs = [
        (_ev("a", interesting=False), _fb("a", value=True)),   # bumped up
        (_ev("b", interesting=True), _fb("b", value=False)),   # bumped down
        (_ev("c", interesting=False), _fb("c", value=True)),   # bumped up
    ]
    result = build_tuned_prompt(BASE_PROMPT, pairs)
    assert result.bumped_to_interesting == 2
    assert result.bumped_to_boring == 1
    assert result.examples_added == 3


def test_idempotent_when_run_twice() -> None:
    """Re-running tune should replace the previous overrides section, not duplicate it."""
    pairs = [(_ev("a", interesting=False, caption="first"), _fb("a", value=True))]
    once = build_tuned_prompt(BASE_PROMPT, pairs).prompt
    twice = build_tuned_prompt(once, pairs).prompt
    assert twice.count(OVERRIDE_SECTION_HEADER) == 1


def test_idempotent_with_different_overrides() -> None:
    """Subsequent runs replace stale overrides, even if the override list changed."""
    initial = [(_ev("a", interesting=False, caption="caption A"), _fb("a", value=True))]
    later = [(_ev("b", interesting=True, caption="caption B"), _fb("b", value=False))]
    once = build_tuned_prompt(BASE_PROMPT, initial).prompt
    twice = build_tuned_prompt(once, later).prompt
    assert twice.count(OVERRIDE_SECTION_HEADER) == 1
    assert "caption A" not in twice  # stale example evicted
    assert "caption B" in twice


def test_includes_original_classification_in_example() -> None:
    pairs = [(_ev("a", interesting=False, category="glitch"), _fb("a", value=True))]
    result = build_tuned_prompt(BASE_PROMPT, pairs)
    assert "Originally classified as `interesting=False`" in result.prompt
    assert "category `glitch`" in result.prompt


def test_subjects_carry_through_to_json_block() -> None:
    pairs = [(_ev("a", interesting=False, subjects=["raccoon", "small dog"]),
              _fb("a", value=True))]
    result = build_tuned_prompt(BASE_PROMPT, pairs)
    assert '"raccoon"' in result.prompt
    assert '"small dog"' in result.prompt


def test_handles_unclassified_event() -> None:
    """VLM unclassified + user verdict should still produce a clean example."""
    pairs = [(_ev("a", interesting=None, caption="ambiguous"), _fb("a", value=True))]
    result = build_tuned_prompt(BASE_PROMPT, pairs)
    assert "Bumped to interesting" in result.prompt
    # `None` becomes `interesting=None` in the human-readable header
    assert "interesting=None" in result.prompt
