"""Tests for the EventClassification Pydantic schema."""

from __future__ import annotations

import json

import pytest
from pydantic import ValidationError

from sentrytriage.classifier import EventCategory, EventClassification


def test_valid_classification_round_trips() -> None:
    c = EventClassification(
        interesting=True,
        category=EventCategory.PERSON_APPROACH,
        subjects=["man in red hat"],
        one_line_caption="Man approaches the driver door.",
        confidence=0.85,
    )
    assert c.interesting is True
    assert c.category is EventCategory.PERSON_APPROACH
    assert c.subjects == ["man in red hat"]


@pytest.mark.parametrize("bad_confidence", [-0.1, 1.5, 2.0])
def test_confidence_out_of_range_rejected(bad_confidence: float) -> None:
    with pytest.raises(ValidationError):
        EventClassification(
            interesting=True,
            category=EventCategory.UNKNOWN,
            one_line_caption="x",
            confidence=bad_confidence,
        )


def test_category_must_be_known_enum_value() -> None:
    with pytest.raises(ValidationError):
        EventClassification(
            interesting=False,
            category="surprise",  # type: ignore[arg-type]
            one_line_caption="x",
            confidence=0.5,
        )


def test_serialises_category_as_string() -> None:
    c = EventClassification(
        interesting=False,
        category=EventCategory.GLITCH,
        one_line_caption="Sensor false trigger.",
        confidence=0.7,
    )
    payload = json.loads(c.model_dump_json())
    assert payload["category"] == "glitch"
    assert payload["interesting"] is False
    assert payload["subjects"] == []


def test_subjects_default_empty_list() -> None:
    c = EventClassification(
        interesting=False,
        category=EventCategory.UNKNOWN,
        one_line_caption="x",
        confidence=0.5,
    )
    assert c.subjects == []
