# Security policy

This is alpha software (Development Status :: 3 - Alpha). Do not ship to production without your own threat model.

## Reporting vulnerabilities

Email **tenzinshare@gmail.com** rather than filing a public issue. Include:
- The package version (e.g. `sentrytriage 0.12.0`)
- Reproduction steps or proof-of-concept
- Your assessment of impact

## Disclosure timeline

- Response within 7 days
- Fix released within 30 days if reproducible and severe (critical or high)
- Lower-severity issues land in the next scheduled release

## Surfaces worth your scrutiny

### Dashboard authentication

**The FastAPI dashboard has no authentication.** It is intended to run on `127.0.0.1` (localhost). Bind to localhost only, OR front it with a reverse proxy that adds auth (caddy + basic auth, nginx + OIDC, Tailscale Funnel, etc.) before exposing on a network reachable by anyone but you.

### Video playback path-traversal jail

The `GET /clips/<event_id>/<filename:path>` route serves video files from `$SENTRYTRIAGE_CLIPS_ROOT` (default `~/Tesla/SentryClips`). The `_safe_path` helper joins the path, calls `Path.resolve()`, then verifies the result is `is_relative_to(_clips_root())` — escapes return 403. Symlinks are followed at resolve time; we explicitly test that a symlink pointing outside the root is rejected.

If you find a path-traversal that bypasses `_safe_path`, please disclose privately (this would be a high-severity finding).

### Stored credentials

- `OPENAI_API_KEY` / Ollama base URL come from env vars, never persisted or logged.
- `PUSHOVER_TOKEN` / `TELEGRAM_BOT_TOKEN` (transitive from `tesla-clip-tools`) — same treatment.
- The local SQLite at `~/.sentrytriage/triage.db` stores event metadata + your feedback. It does **not** store API keys.

### Untrusted .mp4 input

Real Sentry clips are produced by your own car. If you point sentrytriage at clips from an untrusted source, treat them the same as any untrusted binary parser input — the keyframe sampler runs ffmpeg under the hood (bundled via imageio-ffmpeg).
