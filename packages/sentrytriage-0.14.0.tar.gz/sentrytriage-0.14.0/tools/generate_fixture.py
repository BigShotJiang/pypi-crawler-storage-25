"""Generate a synthetic TeslaCam SentryClips folder for end-to-end smoke testing.

Requires the `fixture` extra:

    uv sync --extra fixture
    uv run python tools/generate_fixture.py --root ./tests/fixtures/SentryClips

Produces 4 events (2 HW3 4-cam, 2 HW4 6-cam) plus an `event.json` per event.
The synthetic content is colored frames with a moving rectangle — enough to
exercise the sampler/extractor/store pipeline. **It does not depict a real
Sentry scene**, so VLM verdicts will be nonsense; classification *quality*
needs real saved Sentry clips from a Tesla.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import imageio.v3 as iio
import numpy as np

CAMS_HW3 = ("front", "back", "left_repeater", "right_repeater")
CAMS_HW4 = CAMS_HW3 + ("left_pillar", "right_pillar")

EVENTS = [
    # (folder_name, cams, label, base_color)
    ("2026-05-08_14-22-31", CAMS_HW3, "boring",      (40, 80, 200)),
    ("2026-05-08_15-00-00", CAMS_HW4, "interesting", (200, 80, 40)),
    ("2026-05-08_16-30-00", CAMS_HW3, "boring",      (60, 140, 60)),
    ("2026-05-08_17-45-00", CAMS_HW4, "interesting", (180, 40, 80)),
]


def render_clip(
    path: Path,
    cam: str,
    base_color: tuple[int, int, int],
    fps: int = 24,
    seconds: int = 4,
    size: tuple[int, int] = (640, 360),
) -> None:
    width, height = size
    frames = np.empty((fps * seconds, height, width, 3), dtype=np.uint8)
    rect_size = 60
    for i in range(fps * seconds):
        # Slight color drift per frame so the VLM sees motion.
        r = (base_color[0] + i * 2) % 256
        g = (base_color[1] + i * 3) % 256
        b = (base_color[2] + i * 5) % 256
        frame = np.full((height, width, 3), (r, g, b), dtype=np.uint8)
        # Black title bar so the cam name region is identifiable.
        frame[0:40, :, :] = 0
        # Animated white rectangle moving left to right.
        x0 = int((i / (fps * seconds)) * (width - rect_size))
        y0 = (height - rect_size) // 2
        frame[y0 : y0 + rect_size, x0 : x0 + rect_size, :] = 255
        frames[i] = frame
    iio.imwrite(
        path,
        frames,
        fps=fps,
        codec="libx264",
        pixelformat="yuv420p",
        macro_block_size=8,
        quality=6,
    )


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--root",
        type=Path,
        default=Path("tests/fixtures/SentryClips"),
        help="Output directory (default: tests/fixtures/SentryClips).",
    )
    ap.add_argument("--seconds", type=int, default=4, help="Clip duration per cam.")
    ap.add_argument("--fps", type=int, default=24)
    args = ap.parse_args()

    args.root.mkdir(parents=True, exist_ok=True)
    for stamp, cams, label, color in EVENTS:
        event_dir = args.root / stamp
        event_dir.mkdir(parents=True, exist_ok=True)
        for cam in cams:
            mp4 = event_dir / f"{cam}.mp4"
            print(f"  rendering {mp4} ({label})")
            render_clip(mp4, cam, color, fps=args.fps, seconds=args.seconds)
        meta = {
            "label": label,
            "synthetic": True,
            "cams": list(cams),
            "note": "VLM verdicts on this fixture are not meaningful — pipeline test only.",
        }
        (event_dir / "event.json").write_text(json.dumps(meta, indent=2))
    print(f"done — {len(EVENTS)} events under {args.root}")


if __name__ == "__main__":
    main()
