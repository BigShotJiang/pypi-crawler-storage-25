# Changelog

All notable changes to **sentrytriage** are documented here. The format is based on
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Dates are in `YYYY-MM-DD` (UTC). The "v0.x" series is alpha — breaking changes are called
out explicitly under **Changed** / **Removed**, but minor-version bumps may still rearrange
internals until v1.0.

## [Unreleased]

### Added
- SEI metadata-aware triage: suppress events recorded while the car was moving, surface
  HW4-only camera angles when present.
- Multi-source dispatch: `triage watch --sources tesla,wyze --roots /Tesla/SentryClips,/wyze/SD`
  so a single daemon can triage every camera you own.

## [0.14.0] - 2026-05-14

Two new notifier backends — **Discord** (incoming webhooks) and **Email**
(SMTP) — wired through the existing `--notify` flag on `triage watch` and
`triage notify-test`. Brings the supported set to four
(`pushover | telegram | discord | email`).

### Added
- `triage watch --notify discord` — pushes interesting events to a Discord
  channel via an incoming webhook. Set `DISCORD_WEBHOOK_URL` to the URL
  from the channel's *Integrations -> Webhooks* page; no bot token, no
  OAuth.
- `triage watch --notify email` — sends interesting events over plain
  SMTP. Uses stdlib `smtplib` (no new deps). Reads `SMTP_HOST`,
  `SMTP_PORT` (default 587), `SMTP_USER`, `SMTP_PASSWORD`, `EMAIL_FROM`,
  `EMAIL_TO` (comma-separated recipients). Port 465 -> implicit
  `SMTP_SSL`; everything else -> `SMTP` + `STARTTLS`.
- `triage notify-test --backend discord|email` — same end-to-end credential
  smoke test we already had for Pushover and Telegram.

### Changed
- `_build_notifier` in `cli.py` dispatches the two new backends through
  the existing typer `BadParameter` path, with help text and error
  messages updated to list all four supported notifiers.
- `tesla-clip-tools` dependency pin bumped from `>=0.5` to `>=0.6` so the
  new `DiscordNotifier` and `EmailNotifier` classes are guaranteed
  available.
- FastAPI app `version` bumped to `0.14.0` for `/openapi.json` consumers.

## [0.13.0] - 2026-05-13

Multi-vendor VLM support — `triage classify`, `triage watch`, and `triage evaluate`
now accept **anthropic** (Claude) and **gemini** (Google Gemini) alongside the
existing **openai**, **ollama**, and **mock** backends. Removes single-vendor
lock-in.

### Added
- `triage evaluate --backend anthropic` — Claude vision via the new
  `tesla-clip-tools` v0.5 `AnthropicBackend`. Default model
  `claude-sonnet-4-6`. Needs `ANTHROPIC_API_KEY` and the optional
  `tesla-clip-tools[anthropic]` extra.
- `triage evaluate --backend gemini` — Gemini vision via the new
  `tesla-clip-tools` v0.5 `GeminiBackend`. Default model `gemini-2.5-flash`
  (auto-fallback to `gemini-2.0-flash` if the SDK rejects the newer name).
  Needs `GOOGLE_API_KEY` and the optional `tesla-clip-tools[gemini]` extra.
- `make_anthropic_classifier` and `make_gemini_classifier` factory functions
  in `sentrytriage.evaluate`, mirroring the existing `make_openai_classifier`
  / `make_ollama_classifier` pattern (same keyframes-first / text-only-fallback
  semantics, same `EventClassification` schema).
- `triage classify --backend anthropic|gemini` and `triage watch --backend anthropic|gemini`
  pick up the new backends through the same `_build_vlm` dispatch.
- 4 new tests in `tests/test_evaluate.py` covering both factory functions
  (constructor wiring + default-model regression).

### Changed
- `triage evaluate --backend` help text now lists all five backends
  (`mock | openai | ollama | anthropic | gemini`) and what each one needs to run.
- `tesla-clip-tools` dependency pin bumped from `>=0.3` to `>=0.5` so the new
  backends are guaranteed available.
- FastAPI app `version` bumped to `0.13.0` for `/openapi.json` consumers.

## [0.12.1] - 2026-05-13

Patch release that hardens the v0.12 video-playback feature against edge cases real
deployments hit (multi-cam Tesla folders, Wyze/Reolink filenames with spaces, corrupt
clips, concurrent thumbnail extraction).

### Fixed
- **Multi-cam ordering** — HW4 6-camera folders now render in
  `(front, back, left_repeater, right_repeater, left_pillar, right_pillar)` order
  instead of alphabetical (which put `back.mp4` before `front.mp4` and pillars before
  repeaters). Unknown cam names (Wyze, Reolink, UniFi) still sort alphabetically after
  the named Tesla cams, so non-Tesla deployments are unaffected.
- **Filenames with spaces / special characters** — the per-event detail page now
  percent-encodes the filename when building `<video src>` and thumbnail-strip URLs.
  Previously a Wyze/Reolink clip named `front cam.mp4` produced an unquoted URL
  (`/clips/.../front cam.mp4`) that browsers either truncated or sent as a malformed
  request, leading to a silent 404 in the player.
- **Thumbnail extraction crash on 0-byte / corrupt clips** — the extractor now
  short-circuits before invoking imageio when the source file is empty or unreadable,
  returning a clean 404 from `/clips/.../thumb.jpg` instead of letting an imageio
  exception bubble up as a generic 500.
- **Concurrent thumbnail-cache race** — thumbnail JPEGs are now written to a
  same-directory tempfile and `os.replace`d into place, so two simultaneous requests
  for the same cold thumbnail can never observe a half-written file. Previously the
  cache was written in-place, which could leave a partial JPEG visible to a concurrent
  reader.

### Added
- Regression + edge-case tests for the v0.12 video routes:
  - HTTP `Range: bytes=N-M` requests return `206 Partial Content` (covers `<video>`
    seeks, especially Safari/iOS which buffers forever otherwise).
  - HW4 6-cam folder renders in cam-priority order, not alphabetical.
  - Filename with a space round-trips correctly through URL encode → route decode.
  - Symlink in an event folder pointing outside `SENTRYTRIAGE_CLIPS_ROOT` is rejected
    with `403` (the existing `Path.resolve()` already followed symlinks; test locks in
    the behavior). Skipped on platforms where symlink creation requires elevated
    privileges (Windows non-dev-mode).
  - Thumbnail route returns `404` (not a 500 crash) when the source `.mp4` is 0 bytes.
  - Atomic-write check: no leftover `.tmp` files in the thumbnail cache directory after
    extraction.
  - Per-suffix MIME-type matrix (`.mp4`, `.m4v`, `.mov`, `.mkv`, `.avi`) returns the
    correct `Content-Type` header so browsers will accept the response in `<video>`.
  - Empty event folder (exists on disk but no playable videos) renders the same
    placeholder as a missing folder; clip routes still `404` for any filename.
  - `_clips_root()` falls back to `~/Tesla/SentryClips` when `SENTRYTRIAGE_CLIPS_ROOT`
    is unset.

### Notes
- `FileResponse` (Starlette) handles `Range` requests natively; the new test simply
  locks in the behavior so a future swap to a custom streaming response can't silently
  regress it. We do **not** test 1 GB streaming directly — Starlette's chunked
  iterator is well-trodden territory and a multi-GB sparse fixture would balloon CI
  runtime — but the `Range` test exercises the same code path.

## [0.12.0] - 2026-05-13

### Added
- Embedded HTML5 `<video>` playback in the per-event detail page; the page now loads the
  full clip for each cam instead of just printing the source-folder path.
- Per-camera thumbnail strip under the player so you can scrub without playing.

### Notes
- The detail page falls back to the old folder-path text when the source `.mp4` files are
  missing (e.g. after `triage suppress` moved them, or after running against synthetic
  demo data).

## [0.11.0] - 2026-05-13

### Added
- **Real `--backend openai|ollama` on `triage evaluate`** — until v0.10 the evaluate
  command only ran against the deterministic mock classifier. It now scores the
  baseline-vs-tuned prompt against the actual VLM you'll deploy.
- **Hybrid keyframes-first / text-only fallback** classifier path used by `triage
  evaluate`:
  - When the event's source folder still exists on disk, the classifier samples
    keyframes (same code path as `triage classify`) and calls the VLM with images +
    per-image captions. This is the apples-to-apples comparison.
  - When the folder is missing (synthetic demo events, or a wiped `SentryClips/`), the
    classifier falls back to a **text-only** call: it hands the VLM the stored caption +
    subjects + category and asks it to re-derive the verdict against the same
    `EventClassification` schema. Useful for prompt-tuning iteration without paying to
    re-encode every video.
  - When both paths fail (no folder, no caption, or a transient API error) the classifier
    returns `None` with a `warn[openai]: ...` line on stdout; `compare_prompts` counts
    that event as a miss for **both** prompts so the delta isn't poisoned.

### Changed
- `triage evaluate --backend` help text now lists all three backends (`mock`, `openai`,
  `ollama`) and what each one needs to run.

## [0.10.0] - 2026-05-13

### Added
- `triage evaluate --backend mock` — A/B-evaluate two prompts against your override
  history.
- Train/test split: overrides are deterministically partitioned (`--random-seed 42`) into
  a TRAIN set used to tune the prompt and a held-out TEST set used only for scoring, so
  the headline accuracy isn't overfit.
- Bundled **mock classifier** that simulates a VLM that learns from few-shot examples in
  the prompt — lets you demo the entire feedback loop with no API key.
- Per-category breakdown alongside the overall baseline-vs-tuned accuracy.
- CLI warning when the held-out test set is too small to be meaningful (kills the
  misleading "100% accuracy" headline).

## [0.9.0] - 2026-05-13

### Added
- `triage tune-prompt` command — reads your overrides and appends them as few-shot "you
  got this wrong" examples under a fresh `## Examples from your overrides` section in the
  prompt.
- Default writes to `prompts/classify.tuned.md` so you can diff before adopting; pass
  `--apply` to overwrite `prompts/classify.md` directly.

### Changed
- Tuning is **idempotent** — re-running after collecting more overrides replaces the
  previous `## Examples from your overrides` section instead of stacking duplicates.

## [0.8.0] - 2026-05-13

### Added
- `/overrides` HTML page — lists every event where you disagreed with the VLM's verdict.
- `/api/overrides` JSON endpoint returning the same data for scripts.
- `triage export-overrides --out training-data.jsonl` — dumps a clean training-data file
  (one JSON object per override with caption, subjects, source folder, both verdicts)
  ready for the v0.9 prompt-tuning workflow.
- "Recent overrides" panel on the dashboard with the 5 most-recent disagreements.

## [0.7.0] - 2026-05-13

### Added
- Thumbs feedback on every event detail page — &#128077; / &#128078; buttons POST to
  `/events/{id}/feedback`.
- New sibling `Feedback` table in SQLite so the VLM's verdict is **never** overwritten;
  absence of a row means "no opinion yet".
- Dashboard now shows your agreement rate (`Agreement: 86%`) and per-class override
  counts.
- `/api/feedback/stats` endpoint exposes the same stats for scripts.
- Inline SVG events-per-day bar chart on the dashboard for the last 14 days. No JS chart
  dependency, prints fine, hover for exact counts.

### Changed
- The `Feedback` table is created automatically on existing DBs because `create_all` is
  idempotent — no migration needed when upgrading from v0.6.

## [0.6.0] - 2026-05-13

### Added
- **Demo mode** — `triage demo-seed` populates the local SQLite with ~60 deterministic
  synthetic events; `triage demo` seeds-and-serves the FastAPI dashboard at
  `http://127.0.0.1:8001/`, opens your browser, and lets anyone (no Tesla, no API keys,
  no real cameras) see what triage looks like in 30 seconds.
- **Web dashboard** — `sentrytriage.web:app` (FastAPI + Jinja) renders a dark dashboard
  with header stats, category histograms, recent-events tables, and per-event detail
  pages.
- JSON API at `/api/categories` and `/api/events`; reads from the same SQLite the daemon
  writes, so it's live during `triage watch`.
- One-double-click launcher scripts at the workspace root: `start-triage-demo.ps1`,
  `start-triage-demo.sh`.

## [0.5.0] - 2026-05-12

### Added
- `triage notify-test --backend pushover|telegram` — verifies notifier credentials before
  you deploy a `triage watch` daemon to a server.
- `triage suppress --threshold 0.7` — moves boring events (high-confidence false) into a
  sibling `BoringClips/` folder. **Never** deletes anything.
- `triage reel --since-hours 24 --duration-seconds 60` — concats every interesting event
  from the last 24 h into a single highlight reel mp4 with caption overlays.

[Unreleased]: https://github.com/Raymondriter/sentrytriage/compare/v0.14.0...HEAD
[0.14.0]: https://github.com/Raymondriter/sentrytriage/compare/v0.13.0...v0.14.0
[0.13.0]: https://github.com/Raymondriter/sentrytriage/compare/v0.12.1...v0.13.0
[0.12.1]: https://github.com/Raymondriter/sentrytriage/compare/v0.12.0...v0.12.1
[0.12.0]: https://github.com/Raymondriter/sentrytriage/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/Raymondriter/sentrytriage/compare/v0.10.0...v0.11.0
[0.10.0]: https://github.com/Raymondriter/sentrytriage/compare/v0.9.0...v0.10.0
[0.9.0]: https://github.com/Raymondriter/sentrytriage/compare/v0.8.0...v0.9.0
[0.8.0]: https://github.com/Raymondriter/sentrytriage/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/Raymondriter/sentrytriage/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/Raymondriter/sentrytriage/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/Raymondriter/sentrytriage/releases/tag/v0.5.0
