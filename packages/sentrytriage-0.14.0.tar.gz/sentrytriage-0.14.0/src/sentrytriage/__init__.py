"""sentrytriage — local AI triage for IP-camera events (Tesla, Wyze, Reolink, UniFi Protect, Ring, Nest)."""

__version__ = "0.5.0"
