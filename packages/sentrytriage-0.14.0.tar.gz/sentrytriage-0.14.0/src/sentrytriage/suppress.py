"""Move boring events to BoringClips/. Off by default. Never deletes."""

from __future__ import annotations

import shutil
from datetime import UTC, datetime, timedelta
from pathlib import Path

from sqlmodel import Session, select

from .store import EventRecord, Store


def suppress_boring(
    store: Store,
    boring_root: Path,
    threshold: float = 0.7,
    since_hours: int = 168,
) -> list[Path]:
    """Move event folders flagged interesting=False with confidence>=threshold.

    Updates each record's `folder` field to the new location so reels and
    dashboards point at the correct path. Returns the list of moved folders.
    """
    boring_root = Path(boring_root).expanduser()
    boring_root.mkdir(parents=True, exist_ok=True)
    cutoff = datetime.now(UTC) - timedelta(hours=since_hours)
    moved: list[Path] = []

    with Session(store.engine) as session:
        stmt = (
            select(EventRecord)
            .where(EventRecord.interesting.is_(False))  # type: ignore[union-attr]
            .where(EventRecord.confidence >= threshold)  # type: ignore[operator]
            .where(EventRecord.timestamp >= cutoff)
        )
        records = list(session.exec(stmt).all())
        for rec in records:
            src = Path(rec.folder)
            if not src.is_dir():
                continue
            dst = boring_root / src.name
            if dst.exists():
                continue  # already moved or name collision — skip rather than overwrite
            try:
                shutil.move(str(src), str(dst))
            except OSError:
                continue
            rec.folder = str(dst)
            session.add(rec)
            moved.append(dst)
        session.commit()

    return moved
