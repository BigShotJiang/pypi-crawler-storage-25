"""Append the user's overrides to the classification prompt as few-shot examples.

The flow is:
  1. Read the current `prompts/classify.md`.
  2. For each (event, feedback) override, build a markdown example block that
     shows the corrected verdict alongside the caption + subjects the VLM saw.
  3. Append everything under a fresh ``## Examples from your overrides``
     section so the original ``## Worked examples`` block stays untouched.

The output is a *new* string; whether to write it to a sibling file
(``classify.tuned.md``) or overwrite the original is the caller's choice.
This makes the function trivially testable and keeps the destructive step
(``--apply``) on the CLI surface.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from .store import EventRecord, Feedback

OVERRIDE_SECTION_HEADER = "## Examples from your overrides"
OVERRIDE_SECTION_INTRO = (
    "These are events where the user disagreed with an earlier verdict. "
    "Treat them as corrections — when you see a similar event, follow the "
    "user's labelling, not the original."
)


@dataclass(frozen=True)
class TunedPromptResult:
    """What `build_tuned_prompt` returns. Bundles the new prompt text with
    counts so the CLI can print a useful summary without re-parsing."""

    prompt: str
    examples_added: int
    bumped_to_interesting: int
    bumped_to_boring: int


def _decode_subjects(payload: str | None) -> list[str]:
    if not payload:
        return []
    try:
        out = json.loads(payload)
        return [str(s) for s in out] if isinstance(out, list) else []
    except json.JSONDecodeError:
        return []


def _format_example(event: EventRecord, feedback: Feedback) -> str:
    user_value = feedback.value
    arrow = "Bumped to interesting" if user_value else "Bumped to boring"
    caption = event.one_line_caption or "(no caption recorded)"
    subjects = _decode_subjects(event.subjects_json)
    verdict = {
        "interesting": user_value,
        "category": event.category or "unknown",
        "subjects": subjects,
        "one_line_caption": caption,
        "confidence": 0.85,
    }
    return (
        f"### {arrow} - {caption}\n"
        f"Originally classified as `interesting={event.interesting!r}` "
        f"(category `{event.category or 'unknown'}`). User corrected this verdict.\n"
        "```json\n"
        f"{json.dumps(verdict, indent=2)}\n"
        "```\n"
    )


def build_tuned_prompt(
    prompt_text: str,
    overrides: list[tuple[EventRecord, Feedback]],
) -> TunedPromptResult:
    """Append override examples to `prompt_text`. Returns the new prompt + counts.

    Idempotent: if the prompt already contains an ``OVERRIDE_SECTION_HEADER``,
    it is replaced wholesale rather than duplicated. This means re-running
    `tune-prompt` after a few more overrides leaves a single up-to-date section.
    """
    bumped_up = sum(1 for _, fb in overrides if fb.value)
    bumped_down = len(overrides) - bumped_up

    if not overrides:
        return TunedPromptResult(prompt=prompt_text, examples_added=0,
                                  bumped_to_interesting=0, bumped_to_boring=0)

    examples = "\n".join(_format_example(ev, fb) for ev, fb in overrides)
    new_section = (
        f"\n{OVERRIDE_SECTION_HEADER}\n\n{OVERRIDE_SECTION_INTRO}\n\n{examples}"
    )

    base = _strip_existing_section(prompt_text).rstrip() + "\n"
    return TunedPromptResult(
        prompt=base + new_section,
        examples_added=len(overrides),
        bumped_to_interesting=bumped_up,
        bumped_to_boring=bumped_down,
    )


def _strip_existing_section(prompt_text: str) -> str:
    """Remove a previously-appended overrides section so re-runs stay idempotent."""
    marker_idx = prompt_text.find(OVERRIDE_SECTION_HEADER)
    if marker_idx == -1:
        return prompt_text
    return prompt_text[:marker_idx]
