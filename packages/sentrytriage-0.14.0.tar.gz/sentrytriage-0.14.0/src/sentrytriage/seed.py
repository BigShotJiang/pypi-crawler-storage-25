"""Demo-mode seed data — realistic synthetic Sentry events.

Use via `triage demo-seed` or `triage demo` (which seeds + serves).
Generated data is deterministic when `random_seed` is fixed so repeated runs
of the demo show the same dashboard state.
"""

from __future__ import annotations

import json
import random
from datetime import UTC, datetime, timedelta
from pathlib import Path

from .classifier import EventCategory
from .store import EventRecord, Store

DEFAULT_EVENT_COUNT = 60

# Category distribution heavy on the noise end (passing cars/pedestrians,
# environmental, glitches) and light on the actually-interesting end —
# realistic for a busy parking-lot Sentry stream.
CATEGORY_WEIGHTS: dict[EventCategory, float] = {
    EventCategory.PERSON_PASS: 0.30,
    EventCategory.VEHICLE_CLOSE: 0.25,
    EventCategory.ENVIRONMENTAL: 0.15,
    EventCategory.GLITCH: 0.10,
    EventCategory.PERSON_APPROACH: 0.08,
    EventCategory.ANIMAL: 0.05,
    EventCategory.VEHICLE_COLLISION: 0.04,
    EventCategory.UNKNOWN: 0.03,
}

# Whether each category typically gets `interesting=True`. Probabilistic — we
# want a healthy mix so the dashboard isn't all-noise or all-signal.
INTERESTING_PROB: dict[EventCategory, float] = {
    EventCategory.PERSON_PASS: 0.05,
    EventCategory.VEHICLE_CLOSE: 0.10,
    EventCategory.ENVIRONMENTAL: 0.02,
    EventCategory.GLITCH: 0.0,
    EventCategory.PERSON_APPROACH: 0.85,
    EventCategory.ANIMAL: 0.55,
    EventCategory.VEHICLE_COLLISION: 1.0,
    EventCategory.UNKNOWN: 0.30,
}

CAPTIONS: dict[EventCategory, tuple[str, ...]] = {
    EventCategory.PERSON_PASS: (
        "Pedestrian walks past on the sidewalk without stopping.",
        "Jogger runs past at the curb line.",
        "Two people walking dogs pass on the opposite sidewalk.",
        "Person crosses the street behind the car.",
    ),
    EventCategory.VEHICLE_CLOSE: (
        "Car drives past on the street, no approach.",
        "Cyclist rides by within five feet of the door.",
        "Sedan reverses out of adjacent spot.",
        "Pickup truck parks two spaces over.",
    ),
    EventCategory.ENVIRONMENTAL: (
        "Branches swaying in wind triggered the camera.",
        "Leaves blown across the lot kicked off motion.",
        "Sprinklers cycled and triggered the rear-view trigger.",
    ),
    EventCategory.GLITCH: (
        "No apparent cause; possible sensor false trigger.",
        "Brief sun flare across left repeater; no real subject.",
        "Camera artifact; no motion correlate visible.",
    ),
    EventCategory.PERSON_APPROACH: (
        "Man approaches driver door, looks in window, then leaves.",
        "Delivery driver in red hat walks up to the front bumper with package.",
        "Stranger circles the car twice before walking away.",
        "Child climbs briefly on the rear bumper while parent watches.",
    ),
    EventCategory.ANIMAL: (
        "Raccoon walks across the front bumper sniffing wheels.",
        "Stray cat sits on the hood for ~30 seconds before leaving.",
        "Dog off-leash trots past the rear and marks the tire.",
    ),
    EventCategory.VEHICLE_COLLISION: (
        "White SUV reverses into the front bumper.",
        "Shopping cart rolls into the driver door.",
        "Cyclist clips the side mirror while passing.",
    ),
    EventCategory.UNKNOWN: (
        "Frames don't capture enough context to attribute a cause.",
    ),
}

SUBJECTS: dict[EventCategory, tuple[str, ...]] = {
    EventCategory.PERSON_PASS: ("pedestrian", "jogger", "dog walker", "child"),
    EventCategory.VEHICLE_CLOSE: ("passing sedan", "delivery van", "cyclist", "pickup truck"),
    EventCategory.ENVIRONMENTAL: ("swaying branches", "blowing leaves", "sprinklers"),
    EventCategory.GLITCH: (),
    EventCategory.PERSON_APPROACH: ("man in dark jacket", "delivery driver in red hat",
                                     "stranger with backpack"),
    EventCategory.ANIMAL: ("raccoon", "stray cat", "off-leash dog"),
    EventCategory.VEHICLE_COLLISION: ("white SUV", "shopping cart", "cyclist"),
    EventCategory.UNKNOWN: (),
}


def _weighted(rng: random.Random, weights: dict):
    items = list(weights.items())
    return rng.choices([k for k, _ in items], weights=[w for _, w in items], k=1)[0]


def seed_demo_events(
    *,
    db_path: Path | str,
    event_count: int = DEFAULT_EVENT_COUNT,
    random_seed: int = 42,
    now: datetime | None = None,
) -> dict:
    """Populate `db_path` with synthetic Sentry events.

    Returns a counts dict for the caller to display.
    """
    rng = random.Random(random_seed)
    now = now or datetime.now(UTC)
    store = Store(db_path)

    interesting_count = 0
    boring_count = 0
    for _ in range(event_count):
        # Spread across last 14 days, weighted toward more recent.
        days_back = rng.triangular(0, 14, 2.5)  # mode at ~2.5d ago
        ts = now - timedelta(
            days=days_back,
            hours=rng.uniform(0, 24),
            minutes=rng.uniform(0, 60),
        )
        category = _weighted(rng, CATEGORY_WEIGHTS)
        is_interesting = rng.random() < INTERESTING_PROB[category]
        caption = rng.choice(CAPTIONS[category])
        confidence = (
            rng.uniform(0.75, 0.95)
            if is_interesting
            else rng.uniform(0.55, 0.92)
        )
        subjects_pool = SUBJECTS.get(category, ())
        if subjects_pool:
            n = rng.randint(1, min(2, len(subjects_pool)))
            subjects = list(rng.sample(subjects_pool, n))
        else:
            subjects = []
        folder_name = ts.strftime("%Y-%m-%d_%H-%M-%S")
        record = EventRecord(
            id=f"tesla:{folder_name}",
            timestamp=ts,
            folder=f"~/Tesla/SentryClips/{folder_name}",
            interesting=is_interesting,
            category=category.value,
            one_line_caption=caption,
            confidence=confidence,
            subjects_json=json.dumps(subjects),
            classified_at=ts + timedelta(minutes=rng.uniform(2, 25)),
        )
        store.upsert(record)
        if is_interesting:
            interesting_count += 1
        else:
            boring_count += 1

    return {
        "events": event_count,
        "interesting": interesting_count,
        "boring": boring_count,
    }
