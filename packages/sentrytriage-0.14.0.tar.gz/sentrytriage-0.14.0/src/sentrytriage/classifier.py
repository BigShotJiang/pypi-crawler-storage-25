"""Pydantic schema for VLM event verdicts.

This is the contract every backend must produce. Keep field names stable —
they're persisted to SQLite and surfaced in notifications.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class EventCategory(str, Enum):
    PERSON_APPROACH = "person_approach"
    PERSON_PASS = "person_pass"
    VEHICLE_COLLISION = "vehicle_collision"
    VEHICLE_CLOSE = "vehicle_close"
    ANIMAL = "animal"
    ENVIRONMENTAL = "environmental"
    GLITCH = "glitch"
    UNKNOWN = "unknown"


class EventClassification(BaseModel):
    """Structured verdict from the VLM for a single Sentry event."""

    interesting: bool = Field(description="Does this event deserve human attention?")
    category: EventCategory = Field(description="Coarse classification.")
    subjects: list[str] = Field(
        default_factory=list,
        description='Concrete nouns observed, e.g. ["delivery driver in red hat", "raccoon"].',
    )
    one_line_caption: str = Field(description="One sentence describing what happens.")
    confidence: float = Field(ge=0.0, le=1.0, description="Self-reported confidence 0-1.")
