"""A/B evaluation for prompt-tuning.

Given a set of events that have user feedback (so we know ground truth) and a
classify function, score how often each prompt's verdict matches the user.

The classify function is injected so the same logic powers:
  * tests (deterministic stub)
  * `triage evaluate --backend mock` (demo mode, no API key required)
  * real backends (OpenAI / Ollama wrappers, called from the CLI)

The pure-Python core (build_eval_items, evaluate_prompt, compare_prompts,
mock_classifier) has no I/O. The real-backend factory functions
(make_openai_classifier, make_ollama_classifier) are added at the bottom of
this module — they wrap the heavy VLM clients but stay narrow: each is a
thin closure over (prompt, event) -> bool | None and degrades gracefully
when keyframes are unreachable.
"""

from __future__ import annotations

import json
import random
import re
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from .store import EventRecord, Feedback

if TYPE_CHECKING:
    from tesla_clip_tools.vlm.base import VLMBackend

# A prompt-classifier callable: given the prompt text and an event record,
# return True / False / None (unclassified).
ClassifyFn = Callable[[str, EventRecord], bool | None]

# What we evaluate against: the event itself + the user's "ground truth" label.
EvalItem = tuple[EventRecord, bool]


@dataclass(frozen=True)
class EvaluationResult:
    total: int
    correct: int
    per_category: dict[str, tuple[int, int]] = field(default_factory=dict)
    """Per-category (correct, total)."""

    @property
    def accuracy(self) -> float:
        return (self.correct / self.total) if self.total else 0.0


@dataclass(frozen=True)
class ComparisonResult:
    baseline: EvaluationResult
    tuned: EvaluationResult

    @property
    def accuracy_delta(self) -> float:
        return self.tuned.accuracy - self.baseline.accuracy

    @property
    def correct_delta(self) -> int:
        return self.tuned.correct - self.baseline.correct


def build_eval_items(overrides: Iterable[tuple[EventRecord, Feedback]]) -> list[EvalItem]:
    """Treat each user-overridden feedback as a ground-truth label."""
    return [(ev, fb.value) for ev, fb in overrides]


def train_test_split(
    overrides: list[tuple[EventRecord, Feedback]],
    *,
    train_fraction: float = 0.7,
    random_seed: int = 42,
) -> tuple[list[tuple[EventRecord, Feedback]], list[tuple[EventRecord, Feedback]]]:
    """Deterministic shuffle + split. Returns (train, test).

    With <4 overrides the test split would be size 0 or 1 — we still return
    them so the caller can decide whether the holdout is meaningful (the CLI
    reports both train-set and test-set accuracy explicitly so the user sees
    when the test set is too small to trust).
    """
    if not 0 < train_fraction < 1:
        raise ValueError("train_fraction must be between 0 and 1 exclusive")
    rng = random.Random(random_seed)
    shuffled = list(overrides)
    rng.shuffle(shuffled)
    split = max(1, int(round(len(shuffled) * train_fraction)))
    return shuffled[:split], shuffled[split:]


def evaluate_prompt(
    prompt: str,
    items: list[EvalItem],
    classify_fn: ClassifyFn,
) -> EvaluationResult:
    """Score `prompt` against ground-truth labels by calling `classify_fn` per item."""
    correct = 0
    per_cat: dict[str, list[int]] = {}
    for event, ground_truth in items:
        prediction = classify_fn(prompt, event)
        cat = event.category or "unclassified"
        bucket = per_cat.setdefault(cat, [0, 0])  # [correct, total]
        bucket[1] += 1
        if prediction is ground_truth:
            correct += 1
            bucket[0] += 1
    return EvaluationResult(
        total=len(items),
        correct=correct,
        per_category={k: (v[0], v[1]) for k, v in per_cat.items()},
    )


def compare_prompts(
    baseline_prompt: str,
    tuned_prompt: str,
    items: list[EvalItem],
    classify_fn: ClassifyFn,
) -> ComparisonResult:
    return ComparisonResult(
        baseline=evaluate_prompt(baseline_prompt, items, classify_fn),
        tuned=evaluate_prompt(tuned_prompt, items, classify_fn),
    )


# ---------------------------------------------------------------------------
# Mock classifier — used by `triage evaluate --backend mock` and tests.
# ---------------------------------------------------------------------------

# Static rules — a coarse approximation of what the real VLM tends to flag.
# These match the demo seed's "interesting" examples so a baseline run on
# demo data has a non-zero accuracy.
_INTERESTING_KEYWORDS = (
    "approach", "approaches",
    "collision", "reverses into", "clips",
    "circles",
    "raccoon", "stray cat",
    "delivery driver",
)

# Caption-fragment marker for prompt examples appended by `tune-prompt`.
# We use the JSON `"interesting": true,` line surrounding a known caption
# to detect when the tuned prompt has "taught" the model a correction.
_CAPTION_PATTERN = re.compile(
    r'"interesting":\s*(true|false),[^}]*?"one_line_caption":\s*"([^"]+)"',
    flags=re.DOTALL,
)


def _extract_prompt_corrections(prompt: str) -> dict[str, bool]:
    """Pull (caption -> corrected_label) pairs out of an appended overrides section.

    The mock classifier uses these to simulate the tuned prompt actually
    learning from few-shot examples.
    """
    corrections: dict[str, bool] = {}
    for match in _CAPTION_PATTERN.finditer(prompt):
        label, caption = match.group(1), match.group(2)
        corrections[caption.strip()] = (label == "true")
    return corrections


def mock_classifier(prompt: str, event: EventRecord) -> bool:
    """Deterministic stand-in for a real VLM call.

    Reads the prompt for previously-corrected captions and returns the user's
    label when it sees the same caption again — that's the simulated effect
    of few-shot prompt tuning. Otherwise falls back to keyword rules.
    """
    caption = (event.one_line_caption or "").strip()
    corrections = _extract_prompt_corrections(prompt)
    if caption in corrections:
        return corrections[caption]
    lowered = caption.lower()
    return any(kw in lowered for kw in _INTERESTING_KEYWORDS)


# ---------------------------------------------------------------------------
# Real VLM-backed classifiers — used by `triage evaluate --backend openai|ollama`.
# ---------------------------------------------------------------------------
#
# Design: hybrid keyframes-first, text-only fallback.
#
#   1. Re-derive the event's source folder from `EventRecord.folder`. If the
#      folder exists on disk and contains video files, sample keyframes the
#      same way the live `triage classify` flow does and ask the VLM to
#      classify the images.
#   2. If the folder is missing (e.g. demo seed data, or the user moved/wiped
#      the SentryClips directory) — fall back to a TEXT-ONLY classification:
#      hand the VLM the stored caption + subjects + category as text and ask
#      it for the same `EventClassification` verdict. This keeps `triage
#      evaluate` useful even without the original video on disk, at the cost
#      of evaluating the prompt against a degraded input.
#   3. If both paths fail (no folder AND no caption to fall back on, OR a
#      transient API error) — return None and print a warning. The
#      ClassifyFn protocol allows None for "I don't know"; evaluate_prompt
#      counts those as misses.

_VIDEO_SUFFIXES = {".mp4", ".mov", ".m4v", ".mkv", ".avi"}
_DEFAULT_KEYFRAMES_PER_CAM = 4


def _event_folder(event: EventRecord) -> Path | None:
    """Resolve the event's stored folder string to a real, existing Path or None."""
    if not event.folder:
        return None
    p = Path(event.folder).expanduser()
    return p if p.exists() and p.is_dir() else None


def _collect_cam_videos(folder: Path) -> dict[str, Path]:
    """Return {cam_name: video_path} for every video file directly in `folder`.

    Cam name is the file stem (e.g. "front.mp4" -> "front"). This matches the
    Tesla layout the live classifier uses; for non-Tesla sources it still
    produces a usable dict because the keys only need to be unique.
    """
    return {
        p.stem: p
        for p in sorted(folder.iterdir())
        if p.is_file() and p.suffix.lower() in _VIDEO_SUFFIXES
    }


def _decode_subjects(payload: str | None) -> list[str]:
    if not payload:
        return []
    try:
        out = json.loads(payload)
        return [str(s) for s in out] if isinstance(out, list) else []
    except json.JSONDecodeError:
        return []


def _build_text_only_payload(prompt: str, event: EventRecord) -> tuple[str, str]:
    """Return (system_prompt, user_text) for the text-only fallback path.

    The user text packs everything we know about the event (caption, subjects,
    category) and explicitly asks for the same Pydantic schema we use in the
    image path so structured-output parsing still works.
    """
    caption = (event.one_line_caption or "").strip() or "(no caption available)"
    subjects = _decode_subjects(event.subjects_json)
    subjects_str = ", ".join(subjects) if subjects else "(none recorded)"
    category = event.category or "unknown"
    user_text = (
        "No video keyframes are available for this event. "
        "Classify it from the stored metadata alone:\n\n"
        f"caption: {caption}\n"
        f"subjects: {subjects_str}\n"
        f"category: {category}\n\n"
        "Reply with the structured EventClassification verdict — "
        "set `interesting` to true if a person would want to be alerted, "
        "false if it's noise (leaves, parked cars, glitches)."
    )
    return prompt, user_text


def _classify_via_keyframes(
    vlm: VLMBackend,
    prompt: str,
    folder: Path,
    n_per_cam: int,
) -> bool | None:
    """Sample keyframes from `folder` and ask the VLM. Returns interesting bool or None."""
    from tesla_clip_tools.sampler import sample_keyframes

    from .classifier import EventClassification

    cam_paths = _collect_cam_videos(folder)
    if not cam_paths:
        return None
    samples = sample_keyframes(cam_paths, n_per_cam=n_per_cam)
    if not samples:
        return None
    images = [s.image for s in samples]
    captions = [f"[{s.cam} t={s.timestamp_seconds:.1f}s]" for s in samples]
    verdict = vlm.classify(images, captions, prompt, response_format=EventClassification)
    return bool(verdict.interesting)


def _classify_via_text(
    vlm: VLMBackend,
    prompt: str,
    event: EventRecord,
) -> bool | None:
    """Hand the VLM the caption + subjects as text-only and parse the verdict.

    Reuses the structured-output `EventClassification` schema so the same
    backend client works in both paths. No images are sent — we pass an
    empty image list and a single text caption with the metadata.
    """
    from PIL import Image

    from .classifier import EventClassification

    _, user_text = _build_text_only_payload(prompt, event)
    # Smallest valid image — some backends reject zero-image messages but tolerate a 1x1.
    placeholder = Image.new("RGB", (1, 1), color=(0, 0, 0))
    verdict = vlm.classify(
        [placeholder],
        [user_text],
        prompt,
        response_format=EventClassification,
    )
    return bool(verdict.interesting)


def _make_vlm_backed_classifier(
    vlm: VLMBackend,
    *,
    backend_label: str,
    n_per_cam: int = _DEFAULT_KEYFRAMES_PER_CAM,
) -> ClassifyFn:
    """Shared builder: wrap a `VLMBackend` instance into a (prompt, event) callable.

    Used by `make_openai_classifier` and `make_ollama_classifier`. Keeping the
    keyframes-first / text-only-fallback / warn-and-skip-on-failure logic in
    one place means the two factory functions are 3-line wrappers — and the
    behaviour stays consistent if we add Anthropic/Gemini backends in v0.12.
    """

    def classify(prompt: str, event: EventRecord) -> bool | None:
        folder = _event_folder(event)
        if folder is not None:
            try:
                result = _classify_via_keyframes(vlm, prompt, folder, n_per_cam)
                if result is not None:
                    return result
            except Exception as exc:  # noqa: BLE001 — degrade to text-only on any failure
                print(
                    f"warn[{backend_label}]: keyframe classification failed for "
                    f"{event.id}: {exc}; falling back to text-only."
                )
        # Text-only fallback (folder missing OR keyframes unusable).
        try:
            return _classify_via_text(vlm, prompt, event)
        except Exception as exc:  # noqa: BLE001 — give up, return None so caller can score it.
            print(
                f"warn[{backend_label}]: text-only fallback failed for "
                f"{event.id}: {exc}; skipping."
            )
            return None

    return classify


def make_openai_classifier(
    model: str = "gpt-4o-mini",
    *,
    n_per_cam: int = _DEFAULT_KEYFRAMES_PER_CAM,
) -> ClassifyFn:
    """Build a `ClassifyFn` backed by OpenAI's chat-completions vision API.

    Requires `OPENAI_API_KEY`. The returned callable is safe to pass straight
    to `compare_prompts` — it tries keyframe extraction first and falls back
    to a text-only classification if the source folder is missing.
    """
    from tesla_clip_tools.vlm.openai import OpenAIBackend

    return _make_vlm_backed_classifier(
        OpenAIBackend(model=model),
        backend_label="openai",
        n_per_cam=n_per_cam,
    )


def make_ollama_classifier(
    model: str = "qwen2.5vl:7b",
    *,
    n_per_cam: int = _DEFAULT_KEYFRAMES_PER_CAM,
) -> ClassifyFn:
    """Build a `ClassifyFn` backed by a local Ollama server.

    Requires Ollama running locally with the chosen vision model pulled. Same
    keyframes-first / text-only-fallback semantics as the OpenAI variant.
    """
    from tesla_clip_tools.vlm.ollama import OllamaBackend

    return _make_vlm_backed_classifier(
        OllamaBackend(model=model),
        backend_label="ollama",
        n_per_cam=n_per_cam,
    )


def make_anthropic_classifier(
    model: str = "claude-sonnet-4-6",
    *,
    n_per_cam: int = _DEFAULT_KEYFRAMES_PER_CAM,
) -> ClassifyFn:
    """Build a `ClassifyFn` backed by Anthropic's Messages API (Claude vision).

    Requires `ANTHROPIC_API_KEY` and the optional `[anthropic]` extra of
    `tesla-clip-tools`. Same keyframes-first / text-only-fallback semantics as
    the OpenAI variant — Anthropic's tools API produces structured output
    matching the same `EventClassification` schema.
    """
    from tesla_clip_tools.vlm.anthropic import AnthropicBackend

    return _make_vlm_backed_classifier(
        AnthropicBackend(model=model),
        backend_label="anthropic",
        n_per_cam=n_per_cam,
    )


def make_gemini_classifier(
    model: str = "gemini-2.5-flash",
    *,
    n_per_cam: int = _DEFAULT_KEYFRAMES_PER_CAM,
) -> ClassifyFn:
    """Build a `ClassifyFn` backed by Google's Gemini vision API.

    Requires `GOOGLE_API_KEY` and the optional `[gemini]` extra of
    `tesla-clip-tools`. Gemini's `response_schema` accepts the
    `EventClassification` Pydantic class directly, so no tools-call workaround
    is needed.
    """
    from tesla_clip_tools.vlm.gemini import GeminiBackend

    return _make_vlm_backed_classifier(
        GeminiBackend(model=model),
        backend_label="gemini",
        n_per_cam=n_per_cam,
    )
