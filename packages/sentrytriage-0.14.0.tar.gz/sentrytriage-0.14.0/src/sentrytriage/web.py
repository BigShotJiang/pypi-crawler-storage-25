"""FastAPI + Jinja dashboard for sentrytriage.

HTML routes:
  GET /                  → header stats + recent events list
  GET /events            → filterable events table (interesting / category)
  GET /events/{id}       → single-event drilldown (caption + subjects + folder)

JSON routes (machine consumers):
  GET /api/categories    → category histogram
  GET /api/events        → paginated event list with filters
  GET /healthz           → "ok"

DB path comes from SENTRYTRIAGE_DB_PATH env var (default: ~/.sentrytriage/triage.db).
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Annotated
from urllib.parse import quote

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.templating import Jinja2Templates

from .store import EventRecord, Store

DEFAULT_DB_PATH = Path("~/.sentrytriage/triage.db")
DEFAULT_CLIPS_ROOT = Path("~/Tesla/SentryClips")
TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"

# Mirror evaluate.py:_VIDEO_SUFFIXES so cam discovery stays consistent.
VIDEO_SUFFIXES = {".mp4", ".mov", ".m4v", ".mkv", ".avi"}


def _build_store() -> Store:
    db_path = Path(os.environ.get("SENTRYTRIAGE_DB_PATH") or str(DEFAULT_DB_PATH))
    return Store(db_path)


def get_store() -> Store:
    """FastAPI dependency hook — overridable in tests."""
    return _build_store()


def _clips_root() -> Path:
    """Root directory below which `/clips/...` may serve files. Read fresh each
    request so tests can monkey-patch SENTRYTRIAGE_CLIPS_ROOT per case."""
    raw = os.environ.get("SENTRYTRIAGE_CLIPS_ROOT") or str(DEFAULT_CLIPS_ROOT)
    return Path(raw).expanduser().resolve()


def _safe_path(folder: str | None, filename: str) -> Path | None:
    """Resolve `folder/filename` and return it iff inside `_clips_root()`.

    Returns None on any traversal attempt (`..`, absolute filenames, symlinks
    pointing outside the root). The folder string comes from a stored event
    record (already trusted), but `filename` is from the URL and untrusted.
    The root check is the canonical defense — even if `folder` were tampered
    with, escapes still get rejected here.
    """
    if not folder:
        return None
    root = _clips_root()
    base = Path(folder).expanduser()
    candidate = (base / filename).resolve()
    try:
        if not candidate.is_relative_to(root):
            return None
    except ValueError:  # different drives on Windows
        return None
    return candidate


# HW4 6-cam layout (front, back, repeaters, pillars). Lower number = earlier in
# the strip / grid. Anything not in this map sorts after the named cams,
# alphabetically — keeps Wyze/Reolink/UniFi names stable even though they don't
# match the Tesla naming convention.
_CAM_PRIORITY = {
    "front": 0,
    "back": 1,
    "rear": 1,                 # some sources name the back cam "rear"
    "left_repeater": 2,
    "right_repeater": 3,
    "left_pillar": 4,
    "front_pillar_left": 4,    # HW4 alt naming
    "right_pillar": 5,
    "front_pillar_right": 5,
    "back_pillar": 6,          # HW3 alt
}


def _cam_sort_key(path: Path) -> tuple[int, str]:
    """Sort key that puts Tesla cams in (front, back, repeaters, pillars) order
    and pushes unknown names to the end alphabetically."""
    stem = path.stem.lower()
    return (_CAM_PRIORITY.get(stem, 100), stem)


def _list_videos(folder: str | None) -> list[Path]:
    """List of video files in `folder` ordered by Tesla cam priority (front,
    back, repeaters, pillars), then alphabetically for any unknown names."""
    if not folder:
        return []
    base = Path(folder).expanduser()
    if not base.exists() or not base.is_dir():
        return []
    root = _clips_root()
    try:
        if not base.resolve().is_relative_to(root):
            return []
    except ValueError:
        return []
    return sorted(
        (p for p in base.iterdir()
         if p.is_file() and p.suffix.lower() in VIDEO_SUFFIXES),
        key=_cam_sort_key,
    )


def _thumb_path(video: Path) -> Path:
    """Cache location for the thumbnail of a given video file."""
    return video.parent / ".thumbs" / f"{video.name}.jpg"


def _ensure_thumbnail(video: Path) -> Path | None:
    """Generate (and cache) a JPEG thumbnail at ~1s. Returns the path, or None
    if extraction fails (corrupt clip, missing codec, etc.).

    The cache write goes through a same-directory tempfile + atomic rename, so
    two concurrent requests for the same cold thumbnail can't race on a
    half-written file — at worst they both extract and the second rename wins
    cleanly. The reader only ever sees a fully-formed JPEG."""
    thumb = _thumb_path(video)
    if thumb.exists() and thumb.stat().st_size > 0:
        return thumb
    # Bail early on obviously-broken inputs so we don't spin up imageio.
    try:
        if not video.exists() or video.stat().st_size == 0:
            return None
    except OSError:
        return None
    try:
        import imageio.v3 as iio  # imported lazily; ffmpeg via tesla-clip-tools

        # Walk a few frames in and grab the last one we see (or the 30th, ~1s
        # at 30fps). Avoids picking the all-black opening frame some Sentry
        # clips have.
        frame = None
        for idx, f in enumerate(iio.imiter(str(video), plugin="FFMPEG")):
            frame = f
            if idx >= 30:
                break
        if frame is None:
            return None
        thumb.parent.mkdir(parents=True, exist_ok=True)
        # Write to a temp file in the same directory, then atomically replace.
        # Same-dir tempfile guarantees rename() is atomic on the same volume.
        fd, tmp_name = tempfile.mkstemp(
            prefix=f".{thumb.name}.", suffix=".tmp", dir=str(thumb.parent)
        )
        os.close(fd)
        tmp_path = Path(tmp_name)
        try:
            iio.imwrite(str(tmp_path), frame, extension=".jpg")
            os.replace(tmp_path, thumb)
        except Exception:
            tmp_path.unlink(missing_ok=True)
            raise
    except Exception:
        # Any decode failure → fall back to "no thumbnail". The route will 404.
        return None
    return thumb


def _serve_video(store: Store, event_id: str, filename: str):
    event = store.get_event(event_id)
    if event is None:
        raise HTTPException(404, f"event {event_id!r} not found")
    path = _safe_path(event.folder, filename)
    if path is None:
        raise HTTPException(403, "path traversal rejected")
    if path.suffix.lower() not in VIDEO_SUFFIXES:
        raise HTTPException(403, "non-video file")
    if not path.exists() or not path.is_file():
        raise HTTPException(404, f"clip {filename!r} not found")
    return FileResponse(path, media_type=_video_media_type(path))


def _serve_thumb(store: Store, event_id: str, filename: str):
    event = store.get_event(event_id)
    if event is None:
        raise HTTPException(404, f"event {event_id!r} not found")
    video = _safe_path(event.folder, filename)
    if video is None:
        raise HTTPException(403, "path traversal rejected")
    if video.suffix.lower() not in VIDEO_SUFFIXES:
        raise HTTPException(403, "non-video file")
    if not video.exists() or not video.is_file():
        raise HTTPException(404, f"clip {filename!r} not found")
    thumb = _ensure_thumbnail(video)
    if thumb is None or not thumb.exists():
        raise HTTPException(404, "thumbnail unavailable")
    return FileResponse(thumb, media_type="image/jpeg")


def _decode_subjects(payload: str | None) -> list[str]:
    if not payload:
        return []
    try:
        out = json.loads(payload)
        return list(out) if isinstance(out, list) else []
    except json.JSONDecodeError:
        return []


def create_app(templates_dir: Path | None = None) -> FastAPI:
    """Create the FastAPI application. Templates dir is overridable for tests."""
    templates = Jinja2Templates(directory=str(templates_dir or TEMPLATES_DIR))
    app = FastAPI(
        title="sentrytriage",
        description="Local AI Sentry triage dashboard.",
        version="0.14.0",
    )

    @app.get("/healthz", response_class=PlainTextResponse)
    def healthz() -> str:
        return "ok"

    @app.get("/", response_class=HTMLResponse)
    def index(
        request: Request,
        store: Annotated[Store, Depends(get_store)],
    ):
        recent = store.list_events(limit=20)
        interesting_recent = store.list_events(limit=10, interesting=True)
        counts = store.interesting_counts()
        cat_counts = sorted(
            store.category_counts().items(),
            key=lambda kv: kv[1],
            reverse=True,
        )
        per_day = store.events_per_day(days=14)
        max_per_day = max((n for _, n in per_day), default=0) or 1
        feedback_stats = store.feedback_stats()
        agreement_pct = _agreement_pct(feedback_stats)
        recent_overrides = store.list_overrides(limit=5)
        return templates.TemplateResponse(
            request,
            "index.html",
            {
                "recent_events": recent,
                "interesting_recent": interesting_recent,
                "counts": counts,
                "category_counts": cat_counts,
                "total_events": sum(counts.values()),
                "feedback_stats": feedback_stats,
                "agreement_pct": agreement_pct,
                "events_per_day": per_day,
                "max_per_day": max_per_day,
                "recent_overrides": recent_overrides,
            },
        )

    @app.get("/events", response_class=HTMLResponse)
    def list_events(
        request: Request,
        store: Annotated[Store, Depends(get_store)],
        interesting: str | None = None,
        category: str | None = None,
        limit: int = 100,
    ):
        # `interesting` query param: "true"/"false"/None
        interesting_bool: bool | None
        if interesting == "true":
            interesting_bool = True
        elif interesting == "false":
            interesting_bool = False
        else:
            interesting_bool = None
        events = store.list_events(
            limit=limit, interesting=interesting_bool, category=category
        )
        all_categories = sorted(store.category_counts().keys())
        return templates.TemplateResponse(
            request,
            "events.html",
            {
                "events": events,
                "categories": all_categories,
                "active_interesting": interesting,
                "active_category": category,
                "total_in_view": len(events),
            },
        )

    @app.get("/events/{event_id}", response_class=HTMLResponse)
    def event_detail(
        event_id: str,
        request: Request,
        store: Annotated[Store, Depends(get_store)],
    ):
        event = store.get_event(event_id)
        if event is None:
            raise HTTPException(404, f"event {event_id!r} not found")
        feedback = store.get_feedback(event_id)
        # Percent-encode the filename so spaces, parentheses, etc. (Wyze /
        # Reolink can produce these) survive the round-trip through the URL.
        # `safe=""` ensures even `/` is escaped so a filename with a slash
        # can't accidentally introduce a path segment. `event_id` already
        # comes from the trusted store (e.g. `tesla:demo-a`) — its `:` is a
        # legal URL char in this position, but we still encode the filename.
        videos = [
            {
                "name": v.name,
                "stem": v.stem,
                "video_url": f"/clips/{event_id}/{quote(v.name, safe='')}",
                "thumb_url": f"/clips/{event_id}/{quote(v.name, safe='')}/thumb.jpg",
            }
            for v in _list_videos(event.folder)
        ]
        return templates.TemplateResponse(
            request,
            "event_detail.html",
            {
                "event": event,
                "subjects": _decode_subjects(event.subjects_json),
                "feedback": feedback,
                "agreement": _agreement_label(event.interesting, feedback),
                "videos": videos,
            },
        )

    @app.get("/clips/{event_id}/{filename:path}")
    def serve_clip(
        event_id: str,
        filename: str,
        store: Annotated[Store, Depends(get_store)],
    ):
        # Strip the trailing /thumb.jpg sentinel so we can dispatch to the
        # thumbnail extractor under the same path prefix. Anything else after
        # the cam filename is rejected as a traversal attempt.
        if filename.endswith("/thumb.jpg"):
            return _serve_thumb(store, event_id, filename[: -len("/thumb.jpg")])
        return _serve_video(store, event_id, filename)

    @app.post("/events/{event_id}/feedback", response_class=JSONResponse)
    def post_feedback(
        event_id: str,
        store: Annotated[Store, Depends(get_store)],
        value: str,
    ):
        if value not in ("true", "false"):
            raise HTTPException(400, "value must be 'true' or 'false'")
        event = store.get_event(event_id)
        if event is None:
            raise HTTPException(404, f"event {event_id!r} not found")
        bool_value = value == "true"
        row = store.set_feedback(event_id, bool_value)
        return {
            "event_id": event_id,
            "vlm_interesting": event.interesting,
            "user_value": row.value,
            "agreement": _agreement_label(event.interesting, row.value),
        }

    @app.get("/api/feedback/stats", response_class=JSONResponse)
    def api_feedback_stats(store: Annotated[Store, Depends(get_store)]):
        stats = store.feedback_stats()
        return {**stats, "agreement_pct": _agreement_pct(stats)}

    @app.get("/api/overrides", response_class=JSONResponse)
    def api_overrides(
        store: Annotated[Store, Depends(get_store)],
        limit: int = 100,
    ):
        return [_override_dict(ev, fb) for ev, fb in store.list_overrides(limit=limit)]

    @app.get("/overrides", response_class=HTMLResponse)
    def overrides_page(
        request: Request,
        store: Annotated[Store, Depends(get_store)],
        limit: int = 100,
    ):
        rows = store.list_overrides(limit=limit)
        return templates.TemplateResponse(
            request,
            "overrides.html",
            {"overrides": rows, "total_in_view": len(rows)},
        )

    @app.get("/api/categories", response_class=JSONResponse)
    def api_categories(store: Annotated[Store, Depends(get_store)]):
        return store.category_counts()

    @app.get("/api/events", response_class=JSONResponse)
    def api_events(
        store: Annotated[Store, Depends(get_store)],
        interesting: str | None = None,
        category: str | None = None,
        limit: int = 100,
    ):
        interesting_bool: bool | None
        if interesting == "true":
            interesting_bool = True
        elif interesting == "false":
            interesting_bool = False
        else:
            interesting_bool = None
        events = store.list_events(
            limit=limit, interesting=interesting_bool, category=category
        )
        return [_event_dict(e) for e in events]

    return app


def _override_dict(event: EventRecord, feedback) -> dict:
    return {
        "event_id": event.id,
        "timestamp": event.timestamp.isoformat(),
        "folder": event.folder,
        "vlm_interesting": event.interesting,
        "user_interesting": feedback.value,
        "category": event.category,
        "caption": event.one_line_caption,
        "confidence": event.confidence,
        "subjects": _decode_subjects(event.subjects_json),
        "feedback_at": feedback.created_at.isoformat(),
    }


def _agreement_label(vlm_interesting: bool | None, user_value: bool | None) -> str:
    """Compact label for templates and API consumers."""
    if user_value is None:
        return "no-feedback"
    if vlm_interesting is None:
        return "user-classified-only"
    return "agree" if vlm_interesting is user_value else "override"


def _agreement_pct(stats: dict[str, int]) -> int | None:
    total = stats.get("total", 0)
    if total == 0:
        return None
    return round(100 * stats.get("agree_count", 0) / total)


def _event_dict(e: EventRecord) -> dict:
    return {
        "id": e.id,
        "timestamp": e.timestamp.isoformat(),
        "folder": e.folder,
        "interesting": e.interesting,
        "category": e.category,
        "one_line_caption": e.one_line_caption,
        "confidence": e.confidence,
        "subjects": _decode_subjects(e.subjects_json),
        "classified_at": e.classified_at.isoformat() if e.classified_at else None,
    }


_MEDIA_TYPES = {
    ".mp4": "video/mp4",
    ".m4v": "video/mp4",
    ".mov": "video/quicktime",
    ".mkv": "video/x-matroska",
    ".avi": "video/x-msvideo",
}


def _video_media_type(path: Path) -> str:
    return _MEDIA_TYPES.get(path.suffix.lower(), "application/octet-stream")


# Module-level instance for `uvicorn sentrytriage.web:app`.
app = create_app()
