"""Typer CLI: `triage classify <event>` and `triage watch <root>`."""

from __future__ import annotations

import json
import time
from datetime import UTC, datetime
from pathlib import Path

import typer
from rich import print as rprint
from tesla_clip_tools.notify.base import Notifier, NotifyError
from tesla_clip_tools.sampler import sample_keyframes
from tesla_clip_tools.sources.base import Event, Source
from tesla_clip_tools.sources.nest import NestSource
from tesla_clip_tools.sources.reolink import ReolinkSource
from tesla_clip_tools.sources.ring import RingSource
from tesla_clip_tools.sources.tesla import TeslaSource
from tesla_clip_tools.sources.unifi_protect import UniFiProtectSource
from tesla_clip_tools.sources.wyze import WyzeSource
from tesla_clip_tools.vlm.base import VLMBackend
from tesla_clip_tools.vlm.openai import OpenAIBackend

from .classifier import EventClassification
from .store import EventRecord, Store

app = typer.Typer(
    no_args_is_help=True,
    add_completion=False,
    help="Local AI triage for Sentry / IP-camera events (Tesla, Wyze, Reolink, UniFi Protect, Ring, Nest).",
)

# Default prompt lives at <repo>/prompts/classify.md.
DEFAULT_PROMPT_PATH = (
    Path(__file__).resolve().parent.parent.parent / "prompts" / "classify.md"
)

# Source dispatch — keep this map in sync with the --source-type help text.
_SOURCE_TYPES: dict[str, type[Source]] = {
    "tesla": TeslaSource,
    "wyze": WyzeSource,
    "reolink": ReolinkSource,
    "unifi": UniFiProtectSource,
    "ring": RingSource,
    "nest": NestSource,
}


def _load_prompt(prompt_path: Path | None) -> str:
    return (prompt_path or DEFAULT_PROMPT_PATH).read_text(encoding="utf-8")


def _build_source(path: Path, source_type: str = "tesla") -> Source:
    cls = _SOURCE_TYPES.get(source_type)
    if cls is None:
        raise typer.BadParameter(
            f"Unknown source type: {source_type!r}. "
            f"Supported: {', '.join(_SOURCE_TYPES)}."
        )
    return cls(path)


def _build_vlm(backend: str, model: str) -> VLMBackend:
    if backend == "openai":
        return OpenAIBackend(model=model)
    if backend == "ollama":
        from tesla_clip_tools.vlm.ollama import OllamaBackend
        return OllamaBackend(model=model)
    if backend == "anthropic":
        from tesla_clip_tools.vlm.anthropic import AnthropicBackend
        return AnthropicBackend(model=model)
    if backend == "gemini":
        from tesla_clip_tools.vlm.gemini import GeminiBackend
        return GeminiBackend(model=model)
    raise typer.BadParameter(
        f"Unknown VLM backend: {backend!r}. "
        f"Supported: openai, ollama, anthropic, gemini."
    )


def _build_notifier(backend: str | None) -> Notifier | None:
    if not backend or backend == "none":
        return None
    if backend == "pushover":
        from tesla_clip_tools.notify.pushover import PushoverNotifier
        return PushoverNotifier()
    if backend == "telegram":
        from tesla_clip_tools.notify.telegram import TelegramNotifier
        return TelegramNotifier()
    if backend == "discord":
        from tesla_clip_tools.notify.discord import DiscordNotifier
        return DiscordNotifier()
    if backend == "email":
        from tesla_clip_tools.notify.email_smtp import EmailNotifier
        return EmailNotifier()
    raise typer.BadParameter(
        f"Unknown notify backend: {backend!r}. "
        f"Supported: none, pushover, telegram, discord, email."
    )


def _parse_cams(cams: str) -> list[str]:
    return [c.strip() for c in cams.split(",") if c.strip()]


def _classify_event(
    event: Event,
    vlm: VLMBackend,
    system_prompt: str,
    n_per_cam: int,
    cams_to_use: list[str],
) -> EventClassification:
    cams_subset = {k: v for k, v in event.cams.items() if k in cams_to_use}
    if not cams_subset:
        cams_subset = event.cams  # fall back to all cams if filter killed everything
    samples = sample_keyframes(cams_subset, n_per_cam=n_per_cam)
    if not samples:
        raise RuntimeError(f"No keyframes extractable for event {event.id}")
    images = [s.image for s in samples]
    captions = [f"[{s.cam} t={s.timestamp_seconds:.1f}s]" for s in samples]
    return vlm.classify(images, captions, system_prompt, response_format=EventClassification)


@app.command()
def classify(
    path: Path = typer.Argument(
        ...,
        exists=True,
        file_okay=False,
        dir_okay=True,
        help="Path to a single Sentry event folder.",
    ),
    backend: str = typer.Option(
        "openai",
        help="VLM backend: openai | ollama | anthropic | gemini.",
    ),
    model: str = typer.Option("gpt-4o-mini", help="Model name on the chosen backend."),
    cams: str = typer.Option("front,back", help="Comma-separated cam names to sample."),
    keyframes_per_cam: int = typer.Option(4),
    prompt: Path | None = typer.Option(None, help="Override prompt path."),
) -> None:
    """Classify a single event folder and print the JSON verdict to stdout."""
    source = _build_source(path.parent)
    matches = [e for e in source.discover() if e.folder.name == path.name]
    if not matches:
        raise typer.BadParameter(f"No Tesla event folder found at {path}")
    event = matches[0]
    vlm = _build_vlm(backend, model)
    verdict = _classify_event(
        event, vlm, _load_prompt(prompt), keyframes_per_cam, _parse_cams(cams)
    )
    print(json.dumps(verdict.model_dump(mode="json"), indent=2))


@app.command()
def watch(
    path: Path = typer.Argument(
        ...,
        exists=True,
        file_okay=False,
        dir_okay=True,
        help="Root directory: SentryClips/ (tesla), Wyze SD root, Reolink-export dir, UniFi-export dir.",
    ),
    source_type: str = typer.Option(
        "tesla",
        "--source-type",
        help="Source layout: tesla | wyze | reolink | unifi | ring | nest. Default: tesla.",
    ),
    db: Path = typer.Option(
        Path("~/.sentrytriage/triage.db"), help="SQLite DB path."
    ),
    backend: str = typer.Option(
        "openai",
        help="VLM backend: openai | ollama | anthropic | gemini.",
    ),
    model: str = typer.Option("gpt-4o-mini"),
    cams: str = typer.Option(
        "front,back",
        help=(
            "Comma-separated cam names to sample. For tesla use front,back. "
            "For wyze/reolink/unifi use the cam name(s) emitted by the source -- or "
            'leave it loose: a stray cam name like "front" simply means "all cams" '
            "for sources where the cam set doesn't match."
        ),
    ),
    keyframes_per_cam: int = typer.Option(4),
    poll_seconds: float = typer.Option(15.0, help="Seconds between scans."),
    notify: str = typer.Option(
        "none",
        help=(
            "Push interesting events through this notifier "
            "(none|pushover|telegram|discord|email)."
        ),
    ),
    prompt: Path | None = typer.Option(None),
) -> None:
    """Poll a directory and classify new events as they appear.

    Source-layout dispatch via --source-type:
      tesla  --> SentryClips/<YYYY-MM-DD_HH-MM-SS>/{front,back,...}.mp4
      wyze   --> SD card layout: <YYYYMMDD>/<HH>/<MM>.mp4
      reolink --> flat dir: <CamName>_<YYYYMMDDHHMMSS>.mp4 (and 2 other patterns)
      unifi  --> flat or date-partitioned: <CamName>_<YYYY-MM-DD>_<HH-MM-SS>[_<event>].mp4
    """
    source = _build_source(path, source_type)
    store = Store(db)
    vlm = _build_vlm(backend, model)
    notifier = _build_notifier(notify)
    system_prompt = _load_prompt(prompt)
    cams_list = _parse_cams(cams)

    last_seen = store.latest_classified_at()
    notify_msg = f" notify=[bold]{notify}[/bold]" if notifier else ""
    rprint(
        f"[bold]watching[/bold] {path} (last classified: {last_seen}){notify_msg}"
    )

    try:
        while True:
            for event in source.scan_for_new(after=last_seen):
                rprint(f"  classifying {event.id} ({len(event.cams)} cams)…")
                try:
                    verdict = _classify_event(
                        event, vlm, system_prompt, keyframes_per_cam, cams_list
                    )
                except Exception as exc:  # noqa: BLE001 — surface and continue
                    rprint(f"  [red]error[/red] {event.id}: {exc}")
                    continue

                store.upsert(
                    EventRecord(
                        id=event.id,
                        timestamp=event.timestamp,
                        folder=str(event.folder),
                        interesting=verdict.interesting,
                        category=verdict.category.value,
                        one_line_caption=verdict.one_line_caption,
                        confidence=verdict.confidence,
                        subjects_json=json.dumps(verdict.subjects),
                        classified_at=datetime.now(UTC),
                    )
                )
                tag = "[green]★[/green]" if verdict.interesting else "·"
                rprint(
                    f"  {tag} {event.id}: "
                    f"[{verdict.category.value}] {verdict.one_line_caption}"
                )
                if notifier and verdict.interesting:
                    _push_notify(notifier, event, verdict)
                last_seen = (
                    max(last_seen, event.timestamp) if last_seen else event.timestamp
                )
            time.sleep(poll_seconds)
    except KeyboardInterrupt:
        rprint("\nstopped.")


def _push_notify(
    notifier: Notifier,
    event: Event,
    verdict: EventClassification,
) -> None:
    """Best-effort notification — log + continue on failure rather than crash the daemon."""
    title = f"Sentry: {verdict.category.value}"
    body = (
        f"{verdict.one_line_caption}\n"
        f"confidence: {verdict.confidence:.2f}\n"
        f"subjects: {', '.join(verdict.subjects) if verdict.subjects else '—'}\n"
        f"folder: {event.folder}"
    )
    try:
        notifier.send(title, body)
    except NotifyError as exc:
        rprint(f"  [yellow]notify failed[/yellow]: {exc}")


@app.command()
def reel(
    output_dir: Path = typer.Option(
        Path("~/Tesla/Highlights"), help="Where to write the daily reel mp4."
    ),
    db: Path = typer.Option(Path("~/.sentrytriage/triage.db")),
    since_hours: int = typer.Option(24, help="Look back N hours."),
    duration_seconds: int = typer.Option(60, help="Total reel length."),
    cam: str = typer.Option("front", help="Camera to draw from."),
) -> None:
    """Stitch all interesting events from the last N hours into one reel mp4."""
    from .reel import cut_daily_reel

    store = Store(db)
    out = cut_daily_reel(store, output_dir, duration_seconds, since_hours, cam)
    if out is None:
        rprint("[yellow]No interesting events in the window — no reel produced.[/yellow]")
    else:
        rprint(f"[green]reel written:[/green] {out}")


@app.command()
def suppress(
    boring_root: Path = typer.Option(
        Path("~/Tesla/BoringClips"), help="Where to move suppressed events."
    ),
    db: Path = typer.Option(Path("~/.sentrytriage/triage.db")),
    threshold: float = typer.Option(0.7, help="Min confidence to suppress."),
    since_hours: int = typer.Option(168, help="Look back N hours (default: 1 week)."),
) -> None:
    """Move boring events (interesting=False, confidence>=threshold) to BoringClips/."""
    from .suppress import suppress_boring

    store = Store(db)
    moved = suppress_boring(store, boring_root, threshold, since_hours)
    rprint(f"moved [bold]{len(moved)}[/bold] folder(s) to {boring_root}")


@app.command("notify-test")
def notify_test(
    backend: str = typer.Option(
        "pushover", help="pushover|telegram|discord|email"
    ),
) -> None:
    """Send a test notification through the given backend."""
    notifier = _build_notifier(backend)
    if notifier is None:
        raise typer.BadParameter(
            "Pick a real backend (pushover|telegram|discord|email)."
        )
    notifier.send(
        "sentrytriage test",
        "If you see this, your notifier credentials are working. Go build something.",
    )
    rprint(f"[green]ok[/green] sent test notification via {backend}.")


@app.command("evaluate")
def evaluate_cmd(
    prompt_in: Path = typer.Option(
        DEFAULT_PROMPT_PATH,
        "--in",
        help="Baseline prompt to compare against. Defaults to prompts/classify.md.",
    ),
    db: Path = typer.Option(
        Path("~/.sentrytriage/triage.db"),
        help="SQLite DB path; user feedback in here is the ground truth.",
    ),
    backend: str = typer.Option(
        "mock",
        help=(
            "Classifier backend: mock | openai | ollama | anthropic | gemini. "
            "'mock' runs end-to-end with no API key; 'openai' needs OPENAI_API_KEY; "
            "'ollama' needs a local Ollama server with the model pulled; "
            "'anthropic' needs ANTHROPIC_API_KEY (and the [anthropic] extra of tesla-clip-tools); "
            "'gemini' needs GOOGLE_API_KEY (and the [gemini] extra of tesla-clip-tools)."
        ),
    ),
    model: str = typer.Option("gpt-4o-mini", help="Model name on the chosen backend."),
    limit: int = typer.Option(50, help="Max overrides to pull from the DB."),
    train_fraction: float = typer.Option(
        0.7,
        help="Fraction of overrides used for tuning the prompt. Remainder is held out for eval.",
    ),
    random_seed: int = typer.Option(
        42, help="Deterministic seed for the train/test split.",
    ),
) -> None:
    """A/B compare the baseline prompt vs the tune-prompt output.

    Splits the overrides into a TRAIN set (used to tune the prompt) and a
    TEST set (used only for evaluation). Reports accuracy on both:
      - TRAIN: how well the tuned prompt fits its own examples (overfit-OK)
      - TEST:  how well the tuning generalises to held-out overrides

    `--backend mock` runs end-to-end without API keys.
    """
    from .evaluate import (
        build_eval_items,
        compare_prompts,
        train_test_split,
    )
    from .store import Store
    from .tune import build_tuned_prompt

    prompt_in = prompt_in.expanduser()
    if not prompt_in.exists():
        rprint(f"[red]baseline prompt not found:[/red] {prompt_in}")
        raise typer.Exit(code=1)

    store = Store(db)
    overrides = store.list_overrides(limit=limit)
    if not overrides:
        rprint("[yellow]no overrides yet[/yellow] - rate some events first via the dashboard.")
        raise typer.Exit(code=0)

    train, test = train_test_split(
        overrides, train_fraction=train_fraction, random_seed=random_seed,
    )

    baseline_prompt = prompt_in.read_text(encoding="utf-8")
    tuned_prompt = build_tuned_prompt(baseline_prompt, train).prompt
    classify_fn = _resolve_classifier(backend, model)

    rprint(
        f"\n[bold]overrides[/bold]: {len(overrides)} total "
        f"-> train={len(train)} / test={len(test)} "
        f"(seed={random_seed}, train_fraction={train_fraction})"
    )

    train_cmp = compare_prompts(baseline_prompt, tuned_prompt,
                                 build_eval_items(train), classify_fn)
    _print_split("TRAIN  (in-sample, overfit-OK)", train_cmp)

    if test:
        test_cmp = compare_prompts(baseline_prompt, tuned_prompt,
                                    build_eval_items(test), classify_fn)
        _print_split("TEST   (held-out, real generalisation)", test_cmp)
        if len(test) < 5:
            rprint(
                "[yellow]warn[/yellow]: test set is small "
                f"({len(test)} item{'s' if len(test) != 1 else ''}) - "
                "rate more events for a meaningful generalisation number."
            )
    else:
        rprint(
            "[yellow]warn[/yellow]: train_fraction left no items in the test set; "
            "skipping held-out evaluation. Lower --train-fraction or rate more events."
        )


def _print_split(label: str, cmp) -> None:
    delta_color = "green" if cmp.correct_delta > 0 else "red" if cmp.correct_delta < 0 else "yellow"
    rprint(f"\n[bold]{label}[/bold]")
    rprint(
        f"  baseline  {cmp.baseline.correct}/{cmp.baseline.total} "
        f"([cyan]{100 * cmp.baseline.accuracy:.1f}%[/cyan])"
    )
    rprint(
        f"  tuned     {cmp.tuned.correct}/{cmp.tuned.total} "
        f"([cyan]{100 * cmp.tuned.accuracy:.1f}%[/cyan])"
    )
    delta_pp = 100 * cmp.accuracy_delta
    rprint(
        f"  [{delta_color}]delta     "
        f"{'+' if cmp.correct_delta >= 0 else ''}{cmp.correct_delta} correct, "
        f"{'+' if delta_pp >= 0 else ''}{delta_pp:.1f} pp[/{delta_color}]"
    )


def _resolve_classifier(backend: str, model: str):
    """Wrap a backend selection into a (prompt, event) -> bool|None callable.

    Dispatch:
      mock      -> deterministic stub (no API key, no network)
      openai    -> hits the OpenAI vision API (needs OPENAI_API_KEY)
      ollama    -> hits a local Ollama server (needs the model pulled)
      anthropic -> hits Anthropic's Messages API (needs ANTHROPIC_API_KEY)
      gemini    -> hits Google's Gemini vision API (needs GOOGLE_API_KEY)

    All real backends do keyframes-first, then fall back to a text-only prompt
    when the source folder is missing — see `evaluate._make_vlm_backed_classifier`.
    """
    from .evaluate import (
        make_anthropic_classifier,
        make_gemini_classifier,
        make_ollama_classifier,
        make_openai_classifier,
        mock_classifier,
    )

    if backend == "mock":
        return mock_classifier
    if backend == "openai":
        return make_openai_classifier(model=model)
    if backend == "ollama":
        return make_ollama_classifier(model=model)
    if backend == "anthropic":
        return make_anthropic_classifier(model=model)
    if backend == "gemini":
        return make_gemini_classifier(model=model)
    raise typer.BadParameter(
        f"Unknown evaluate backend: {backend!r}. "
        f"Supported: mock, openai, ollama, anthropic, gemini."
    )


@app.command("tune-prompt")
def tune_prompt(
    prompt_in: Path = typer.Option(
        DEFAULT_PROMPT_PATH,
        "--in",
        help="Source prompt file. Defaults to prompts/classify.md.",
    ),
    output: Path = typer.Option(
        Path("prompts/classify.tuned.md"),
        "--out",
        "-o",
        help="Where to write the tuned prompt. Ignored if --apply is set.",
    ),
    db: Path = typer.Option(
        Path("~/.sentrytriage/triage.db"),
        help="SQLite DB path.",
    ),
    limit: int = typer.Option(
        50,
        help="Max overrides to append as few-shot examples (newest-first).",
    ),
    apply_in_place: bool = typer.Option(
        False,
        "--apply",
        help="Overwrite the source prompt instead of writing a sibling file.",
    ),
) -> None:
    """Append your VLM overrides to the classification prompt as few-shot examples.

    The default behaviour writes to a sibling `prompts/classify.tuned.md` so the
    original is untouched — review the diff, then re-run with `--apply` to overwrite.
    Re-running is idempotent: a previously-appended section is replaced, not duplicated.
    """
    from .store import Store
    from .tune import build_tuned_prompt

    prompt_in = prompt_in.expanduser()
    if not prompt_in.exists():
        rprint(f"[red]source prompt not found:[/red] {prompt_in}")
        raise typer.Exit(code=1)

    store = Store(db)
    overrides = store.list_overrides(limit=limit)
    if not overrides:
        rprint(
            "[yellow]no overrides yet[/yellow] - rate some events first via the dashboard, "
            "then re-run."
        )
        raise typer.Exit(code=0)

    result = build_tuned_prompt(prompt_in.read_text(encoding="utf-8"), overrides)

    target = prompt_in if apply_in_place else output.expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(result.prompt, encoding="utf-8")

    rprint(
        f"[green]appended {result.examples_added} few-shot example(s)[/green] "
        f"({result.bumped_to_interesting} bumped to interesting, "
        f"{result.bumped_to_boring} bumped to boring) -> {target}"
    )
    if not apply_in_place:
        rprint(
            "  diff against the original, then re-run with [cyan]--apply[/cyan] "
            "to overwrite [cyan]prompts/classify.md[/cyan]."
        )


@app.command("export-overrides")
def export_overrides(
    output: Path = typer.Option(
        Path("training-data.jsonl"),
        "--out",
        "-o",
        help="Where to write the JSONL training data.",
    ),
    db: Path = typer.Option(
        Path("~/.sentrytriage/triage.db"),
        help="SQLite DB path.",
    ),
    limit: int = typer.Option(1000, help="Max overrides to export."),
) -> None:
    """Export the user's VLM overrides as JSONL training data.

    Each line is one event the user disagreed with: the VLM verdict, the
    user verdict, and enough context (caption, subjects, source folder)
    to feed a few-shot prompt-tuning workflow.
    """
    from .store import Store

    store = Store(db)
    overrides = store.list_overrides(limit=limit)
    if not overrides:
        rprint("[yellow]no overrides yet[/yellow] - rate some events first via the dashboard.")
        raise typer.Exit(code=0)

    output = output.expanduser()
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as f:
        for ev, fb in overrides:
            row = {
                "event_id": ev.id,
                "timestamp": ev.timestamp.isoformat(),
                "folder": ev.folder,
                "vlm_interesting": ev.interesting,
                "user_interesting": fb.value,
                "category": ev.category,
                "caption": ev.one_line_caption,
                "confidence": ev.confidence,
                "subjects_json": ev.subjects_json,
                "feedback_at": fb.created_at.isoformat(),
            }
            f.write(json.dumps(row) + "\n")
    rprint(
        f"[green]wrote {len(overrides)} override(s)[/green] -> {output}\n"
        f"  next: feed this file to a prompt-tuning workflow "
        f"(e.g. append as few-shot examples in [cyan]prompts/classify.md[/cyan])"
    )


@app.command("demo-seed")
def demo_seed(
    db: Path = typer.Option(
        Path("~/.sentrytriage/triage.db"),
        help="SQLite DB path (the dashboard reads from here).",
    ),
    events: int = typer.Option(60, help="How many synthetic events to seed."),
    seed: int = typer.Option(42, help="Random seed (deterministic for fixed value)."),
) -> None:
    """Seed the local DB with synthetic Sentry events for demo mode."""
    from .seed import seed_demo_events

    counts = seed_demo_events(db_path=db, event_count=events, random_seed=seed)
    rprint(
        f"[green]seeded[/green] {counts['events']} events "
        f"([bold]{counts['interesting']}[/bold] interesting, "
        f"{counts['boring']} boring) -> {db}"
    )


@app.command()
def demo(
    host: str = typer.Option("127.0.0.1", help="Bind host."),
    port: int = typer.Option(8001, help="Bind port."),
    db: Path = typer.Option(
        Path("~/.sentrytriage/triage.db"),
        help="SQLite DB path; auto-seeded if --seed-first.",
    ),
    seed_first: bool = typer.Option(
        True,
        "--seed-first/--no-seed-first",
        help="Seed synthetic data before serving (idempotent for the same seed).",
    ),
    open_browser: bool = typer.Option(
        True,
        "--open/--no-open",
        help="Open the dashboard in your default browser on launch.",
    ),
) -> None:
    """Seed synthetic data and serve the dashboard at http://host:port/.

    Run this with no args to see what sentrytriage looks like before pointing
    it at a real SentryClips/ folder.
    """
    import threading
    import time as _time
    import webbrowser

    import uvicorn

    if seed_first:
        from .seed import seed_demo_events

        counts = seed_demo_events(db_path=db)
        rprint(
            f"[green]seeded[/green] {counts['events']} events "
            f"({counts['interesting']} interesting, {counts['boring']} boring)"
        )

    import os as _os
    _os.environ["SENTRYTRIAGE_DB_PATH"] = str(db)

    url = f"http://{host}:{port}/"
    rprint(f"[bold]dashboard:[/bold] {url}")

    if open_browser:
        def _open() -> None:
            _time.sleep(1.5)
            webbrowser.open(url)

        threading.Thread(target=_open, daemon=True).start()

    # Re-import so SENTRYTRIAGE_DB_PATH is honored when the app builds its store.
    uvicorn.run("sentrytriage.web:app", host=host, port=port, log_level="info")


if __name__ == "__main__":
    app()
