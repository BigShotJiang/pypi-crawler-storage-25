"""Daily highlight reel — concat interesting events with caption overlay."""

from __future__ import annotations

from datetime import UTC, date, datetime, timedelta
from pathlib import Path

import ffmpeg
from sqlmodel import Session, select

from .store import EventRecord, Store


def cut_daily_reel(
    store: Store,
    output_dir: Path,
    duration_seconds: int = 60,
    since_hours: int = 24,
    cam: str = "front",
) -> Path | None:
    """Stitch all `interesting=True` events from the last N hours into one reel.

    Returns the path of the produced reel, or None if there were no interesting
    events to stitch.
    """
    output_dir = Path(output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)

    cutoff = datetime.now(UTC) - timedelta(hours=since_hours)
    interesting = _select_interesting(store, cutoff)
    if not interesting:
        return None

    per_event_seconds = max(2, duration_seconds // len(interesting))
    out_path = output_dir / f"{date.today().isoformat()}.mp4"
    _stitch(interesting, cam, per_event_seconds, out_path)
    return out_path


def _select_interesting(store: Store, since: datetime) -> list[EventRecord]:
    with Session(store.engine) as session:
        stmt = (
            select(EventRecord)
            .where(EventRecord.interesting.is_(True))  # type: ignore[union-attr]
            .where(EventRecord.timestamp >= since)
            .order_by(EventRecord.timestamp.asc())
        )
        return list(session.exec(stmt).all())


def _stitch(
    events: list[EventRecord],
    cam: str,
    per_event_seconds: int,
    out_path: Path,
) -> None:
    """Concatenate one cam from each event with a caption overlay, drop audio."""
    streams = []
    for ev in events:
        clip = Path(ev.folder) / f"{cam}.mp4"
        if not clip.is_file():
            continue
        caption = _escape_drawtext(ev.one_line_caption or "")
        stream = ffmpeg.input(str(clip), t=per_event_seconds).filter(
            "drawtext",
            text=caption,
            fontcolor="white",
            fontsize=22,
            box=1,
            boxcolor="black@0.55",
            boxborderw=8,
            x=20,
            y="h-th-20",
        )
        streams.append(stream)
    if not streams:
        return

    (
        ffmpeg.concat(*streams, v=1, a=0)
        .output(
            str(out_path),
            vcodec="libx264",
            pix_fmt="yuv420p",
            preset="ultrafast",
            crf=23,
            loglevel="quiet",
        )
        .overwrite_output()
        .run()
    )


def _escape_drawtext(text: str) -> str:
    """ffmpeg's drawtext filter has its own escaping rules; cover the common ones."""
    return text.replace("\\", "\\\\").replace("'", "\\'").replace(":", "\\:")
