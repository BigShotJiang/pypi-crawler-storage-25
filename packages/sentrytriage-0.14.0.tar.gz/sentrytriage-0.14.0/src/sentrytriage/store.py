"""SQLite persistence for classified events.

Single table: every event is one row. Verdicts are stored flat so dashboards
and notifiers can SELECT without parsing JSON. Subjects are JSON-encoded
because SQLite has no native list type.

v0.7 adds a sibling `Feedback` table that captures user thumbs-up/down
overrides without mutating the VLM's verdict. New `Feedback` rows show up on
existing DBs automatically because `create_all` is idempotent.
"""

from __future__ import annotations

from datetime import UTC, date, datetime, timedelta
from pathlib import Path

from sqlalchemy import func
from sqlmodel import Field, Session, SQLModel, create_engine, select


class EventRecord(SQLModel, table=True):
    id: str = Field(primary_key=True)
    timestamp: datetime = Field(index=True)
    folder: str
    interesting: bool | None = None
    category: str | None = None
    one_line_caption: str | None = None
    confidence: float | None = None
    subjects_json: str | None = None  # JSON-serialised list[str]
    classified_at: datetime | None = Field(default=None, index=True)


class Feedback(SQLModel, table=True):
    """User thumbs-up/down on the VLM's verdict for one event.

    A row exists only after the user has acted; absence means "no opinion yet".
    Stored separately from `EventRecord.interesting` so the VLM verdict is never
    overwritten — useful both for prompt-tuning analysis and for showing the
    user where they disagreed with the model.
    """

    event_id: str = Field(primary_key=True)
    value: bool
    created_at: datetime = Field(index=True)


class Store:
    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_engine(f"sqlite:///{self.db_path}")
        SQLModel.metadata.create_all(self.engine)

    def latest_classified_at(self) -> datetime | None:
        """Return the timestamp of the most recently classified event, or None."""
        with Session(self.engine) as session:
            stmt = (
                select(EventRecord.timestamp)
                .where(EventRecord.classified_at.is_not(None))  # type: ignore[union-attr]
                .order_by(EventRecord.timestamp.desc())
                .limit(1)
            )
            return session.exec(stmt).first()

    def upsert(self, record: EventRecord) -> None:
        with Session(self.engine, expire_on_commit=False) as session:
            existing = session.get(EventRecord, record.id)
            if existing is None:
                session.add(record)
            else:
                for key, value in record.model_dump(exclude={"id"}).items():
                    setattr(existing, key, value)
                session.add(existing)
            session.commit()

    def list_events(
        self,
        limit: int = 100,
        *,
        interesting: bool | None = None,
        category: str | None = None,
    ) -> list[EventRecord]:
        """Return events newest-first, optionally filtered by interesting/category."""
        with Session(self.engine, expire_on_commit=False) as session:
            stmt = select(EventRecord).order_by(EventRecord.timestamp.desc())
            if interesting is not None:
                stmt = stmt.where(EventRecord.interesting.is_(interesting))  # type: ignore[union-attr]
            if category is not None:
                stmt = stmt.where(EventRecord.category == category)
            stmt = stmt.limit(limit)
            return list(session.exec(stmt).all())

    def get_event(self, event_id: str) -> EventRecord | None:
        with Session(self.engine, expire_on_commit=False) as session:
            return session.get(EventRecord, event_id)

    def category_counts(self) -> dict[str, int]:
        """Histogram of category strings across all events."""
        with Session(self.engine, expire_on_commit=False) as session:
            rows = session.exec(select(EventRecord)).all()
        out: dict[str, int] = {}
        for r in rows:
            key = r.category or "unclassified"
            out[key] = out.get(key, 0) + 1
        return out

    def interesting_counts(self) -> dict[str, int]:
        """{'interesting': N, 'boring': M, 'unclassified': K}"""
        with Session(self.engine, expire_on_commit=False) as session:
            rows = session.exec(select(EventRecord)).all()
        out = {"interesting": 0, "boring": 0, "unclassified": 0}
        for r in rows:
            if r.interesting is True:
                out["interesting"] += 1
            elif r.interesting is False:
                out["boring"] += 1
            else:
                out["unclassified"] += 1
        return out

    # ------------------------------------------------------------------
    # v0.7 — feedback + per-day rollup
    # ------------------------------------------------------------------

    def set_feedback(self, event_id: str, value: bool) -> Feedback:
        """Upsert the user's thumb on `event_id`. Returns the saved row."""
        now = datetime.now(UTC)
        with Session(self.engine, expire_on_commit=False) as session:
            existing = session.get(Feedback, event_id)
            if existing is None:
                row = Feedback(event_id=event_id, value=value, created_at=now)
                session.add(row)
            else:
                existing.value = value
                existing.created_at = now
                session.add(existing)
                row = existing
            session.commit()
            return row

    def get_feedback(self, event_id: str) -> bool | None:
        with Session(self.engine, expire_on_commit=False) as session:
            row = session.get(Feedback, event_id)
            return None if row is None else row.value

    def feedback_stats(self) -> dict[str, int]:
        """Compare each Feedback row against the matching EventRecord.interesting.

        Returns a dict with:
            agree_count                  — feedback matches the VLM verdict
            override_to_interesting      — VLM said boring/unclassified, user said interesting
            override_to_boring           — VLM said interesting/unclassified, user said boring
            total                        — total feedback rows
        """
        out = {
            "agree_count": 0,
            "override_to_interesting": 0,
            "override_to_boring": 0,
            "total": 0,
        }
        with Session(self.engine, expire_on_commit=False) as session:
            stmt = select(Feedback, EventRecord).join(
                EventRecord, EventRecord.id == Feedback.event_id  # type: ignore[arg-type]
            )
            for fb, ev in session.exec(stmt).all():
                out["total"] += 1
                if ev.interesting is fb.value:
                    out["agree_count"] += 1
                elif fb.value is True:
                    out["override_to_interesting"] += 1
                else:
                    out["override_to_boring"] += 1
        return out

    def list_overrides(self, limit: int = 100) -> list[tuple[EventRecord, Feedback]]:
        """Return (event, feedback) pairs where the user disagreed with the VLM.

        Newest feedback first. Useful both for the dashboard's review panel and
        for `triage export-overrides` to dump training data.
        """
        with Session(self.engine, expire_on_commit=False) as session:
            stmt = (
                select(EventRecord, Feedback)
                .join(Feedback, Feedback.event_id == EventRecord.id)  # type: ignore[arg-type]
                .order_by(Feedback.created_at.desc())  # type: ignore[union-attr]
            )
            rows = session.exec(stmt).all()
        # Filter in Python — `is` semantics for None vs True/False don't translate
        # cleanly to SQL, and overrides are a small subset so we don't need an index.
        out: list[tuple[EventRecord, Feedback]] = []
        for ev, fb in rows:
            if ev.interesting is None or ev.interesting is not fb.value:
                out.append((ev, fb))
                if len(out) >= limit:
                    break
        return out

    def events_per_day(self, days: int = 14, *, today: date | None = None) -> list[tuple[date, int]]:
        """Bucket events into UTC days, newest day last. Missing days fill with zero.

        Returns exactly `days` rows so the dashboard's bar chart has a stable width.
        """
        anchor = today or datetime.now(UTC).date()
        start = anchor - timedelta(days=days - 1)
        with Session(self.engine, expire_on_commit=False) as session:
            stmt = (
                select(
                    func.date(EventRecord.timestamp).label("day"),
                    func.count().label("n"),
                )
                .where(EventRecord.timestamp >= datetime.combine(start, datetime.min.time()))
                .group_by("day")
            )
            raw = {
                _coerce_date(row[0]): int(row[1])
                for row in session.exec(stmt).all()
            }
        return [
            (start + timedelta(days=i), raw.get(start + timedelta(days=i), 0))
            for i in range(days)
        ]


def _coerce_date(value: date | str) -> date:
    """SQLite returns dates as ISO strings; SQLModel-mapped backends may return date."""
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))
