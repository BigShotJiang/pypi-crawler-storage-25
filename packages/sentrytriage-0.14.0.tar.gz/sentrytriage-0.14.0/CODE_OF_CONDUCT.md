## Code of conduct

This project follows a simple principle: **be kind to each other**.

In practice:
- Assume good faith. Most disagreements are about understanding, not malice.
- Critique code, not people. "This function has a race condition" is feedback. "You wrote terrible code" is not.
- Welcome newcomers. Everyone wrote their first PR once.
- Stay on-topic in issues and discussions.

### Reporting concerns

If you see something or are on the receiving end of something, email **tenzinshare@gmail.com**. Reports are read by the maintainer and replied to within 7 days. Maintainer decisions on enforcement (warnings, temporary bans, permanent bans) are final for this repo.

The maintainer holds themselves to the same standard.

### Scope

This applies to all project spaces: issues, pull requests, discussions, commit messages. The full Contributor Covenant v2.1 is a useful longer reference: https://www.contributor-covenant.org/version/2/1/code_of_conduct/
