"""Markdown splitter"""

__version__ = "1.6.29"
