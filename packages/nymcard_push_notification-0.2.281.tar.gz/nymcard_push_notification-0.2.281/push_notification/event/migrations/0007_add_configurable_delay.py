# Generated migration for configurable delay per listener

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('event', '0006_add_payload_pattern'),
    ]

    operations = [
        # Add retry_delay_seconds to PushNotification (listener-level delay)
        migrations.AddField(
            model_name='pushnotification',
            name='retry_delay_seconds',
            field=models.IntegerField(null=True, blank=True),
        ),
        # Add next_retry_at to PushNotificationEvent (per-event retry scheduling)
        migrations.AddField(
            model_name='pushnotificationevent',
            name='next_retry_at',
            field=models.DateTimeField(null=True, blank=True),
        ),
        # Remove old index (processed_at, retry, last_retried_at) and add new one with next_retry_at
        migrations.RemoveIndex(
            model_name='pushnotificationevent',
            name='event_pushn_process_4728e8_idx',
        ),
        migrations.AddIndex(
            model_name='pushnotificationevent',
            index=models.Index(
                fields=['processed_at', 'next_retry_at', 'retry'],
                name='event_pushn_nextretry_idx',
            ),
        ),
    ]
