from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("event", "0007_add_configurable_delay"),
    ]

    operations = [
        migrations.AddField(
            model_name="pushnotificationevent",
            name="terminal_status",
            field=models.CharField(
                blank=True,
                choices=[
                    ("delivered", "Delivered"),
                    ("failed", "Permanently Failed"),
                    ("expired", "TTL Expired"),
                ],
                max_length=20,
                null=True,
            ),
        ),
        migrations.AddField(
            model_name="pushnotificationevent",
            name="failed_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.CreateModel(
            name="DeliveryAttempt",
            fields=[
                ("id", models.BigAutoField(primary_key=True, serialize=False)),
                ("attempt_number", models.PositiveSmallIntegerField()),
                ("is_retry", models.BooleanField(default=False)),
                (
                    "status",
                    models.CharField(
                        choices=[
                            ("success", "Success"),
                            ("http_error", "HTTP Error"),
                            ("timeout", "Timeout"),
                            ("connection_error", "Connection Error"),
                            ("ssl_error", "SSL Error"),
                            ("invalid_response", "Invalid Response"),
                        ],
                        max_length=20,
                    ),
                ),
                ("request_url", models.URLField(max_length=2000)),
                ("request_headers", models.JSONField(default=dict)),
                ("request_body", models.JSONField(blank=True, null=True)),
                ("http_status_code", models.PositiveSmallIntegerField(blank=True, null=True)),
                ("response_headers", models.JSONField(blank=True, null=True)),
                ("response_body", models.TextField(blank=True, default="", max_length=4096)),
                ("error_message", models.TextField(blank=True, default="")),
                (
                    "duration_ms",
                    models.PositiveIntegerField(
                        help_text="Round-trip time of the HTTP request in milliseconds"
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "push_notification_event",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="delivery_attempts",
                        to="event.pushnotificationevent",
                    ),
                ),
            ],
            options={
                "db_table": "push_notification_delivery_attempt",
                "ordering": ["attempt_number"],
            },
        ),
        migrations.AddIndex(
            model_name="deliveryattempt",
            index=models.Index(
                fields=["push_notification_event", "attempt_number"],
                name="pn_delivery_event_attempt_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="deliveryattempt",
            index=models.Index(
                fields=["status", "created_at"],
                name="pn_delivery_status_created_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="deliveryattempt",
            index=models.Index(
                fields=["created_at"],
                name="pn_delivery_created_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="pushnotificationevent",
            index=models.Index(
                fields=["terminal_status", "failed_at"],
                name="pn_event_terminal_failed_idx",
            ),
        ),
    ]
