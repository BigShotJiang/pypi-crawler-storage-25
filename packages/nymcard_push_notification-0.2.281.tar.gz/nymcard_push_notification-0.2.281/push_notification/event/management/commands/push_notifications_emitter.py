import asyncio
import json
import time
import traceback
from datetime import datetime, timedelta, timezone
from time import monotonic
from typing import List

import aiohttp
from asgiref.sync import sync_to_async
from django.conf import settings
from django.core.management.base import BaseCommand
from django.db import transaction
from django.db.models import Q
from django.utils.module_loading import import_string

from push_notification.event.models import DeliveryAttempt, PushNotification, PushNotificationEvent


class Command(BaseCommand):
    help = "Send events to registered push notification url"

    retry = settings.PUSH_NOTIFICATIONS.get('RETRY', 10)
    retry_interval = settings.PUSH_NOTIFICATIONS.get('RETRY_INTERVAL', 60)
    connection_timeout = settings.PUSH_NOTIFICATIONS.get('CONNECTION_TIMEOUT', 30)
    read_timeout = settings.PUSH_NOTIFICATIONS.get('READ_TIMEOUT', 30)
    connection_per_host = settings.PUSH_NOTIFICATIONS.get('CONNECTIONS_PER_HOST', 10)
    process_butch = settings.PUSH_NOTIFICATIONS.get('PROCESS_BUTCH', 100)
    permanent_error_codes = settings.PUSH_NOTIFICATIONS.get(
        'PERMANENT_ERROR_CODES',
        [400, 401, 403, 404, 410],
    )
    invalid_response_validator = settings.PUSH_NOTIFICATIONS.get('INVALID_RESPONSE_VALIDATOR')

    def handle(self, *args, **kwargs):
        self.stdout.write("push notifications emitter started")
        self.stdout.flush()

        while True:
            now = datetime.now(timezone.utc)
            try:
                with transaction.atomic():
                    events = PushNotificationEvent.actual_objects.select_for_update(nowait=True).filter(
                        Q(retry__isnull=True) | Q(retry__lt=self.retry),
                        Q(next_retry_at__isnull=True) | Q(next_retry_at__lte=now),
                    ).all()[:self.process_butch]

                    events_len = events.count()
                    if events_len < 1:
                        time.sleep(1)
                        continue

                    self.stdout.write(
                        "proccessing {} events".format(events_len)
                    )
                    self.stdout.flush()

                    asyncio.run(self.emits(events))
            except Exception:
                traceback.print_exc()
            time.sleep(1)

    # this needs to be separated like so because transactions do not support async mode in django 4.1
    # https://docs.djangoproject.com/en/4.1/topics/async/#queries-the-orm
    def create_event_tasks(self, session, events):
        tasks = []
        with transaction.atomic():
            for event in events:
                tasks.append(
                    self.emit(session, event)
                )
        return tasks

    async def emits(self, events: List[PushNotificationEvent]):
        timeout = aiohttp.ClientTimeout(
            sock_connect=self.connection_timeout,
            sock_read=self.read_timeout,
        )
        conn = aiohttp.TCPConnector(limit_per_host=self.connection_per_host)
        async with aiohttp.ClientSession(timeout=timeout, connector=conn, trust_env=True) as session:
            tasks = await sync_to_async(self.create_event_tasks)(session, events)
            await asyncio.gather(*tasks)

    def get_invalid_response_message(self, json_res):
        if self.invalid_response_validator:
            validator = self.invalid_response_validator
            if isinstance(validator, str):
                validator = import_string(validator)
            return validator(json_res)

        # Default: check SMS / LS / Hub application-level response patterns
        if not isinstance(json_res, dict):
            return None
        sms_res_base = (
            json_res.get("NotificationSendRs", {})
            .get("Header", {})
            .get("ISMHdr", {})
            .get("RespeCde", {})
        )
        rtrn_code = sms_res_base.get("RtrnCde") if isinstance(sms_res_base, dict) else None

        is_sms_failed = rtrn_code != "00"
        is_ls_failed = json_res.get("code", None) != 0
        is_hub_failed = json_res.get("statusCode", None) != 200

        if is_sms_failed and is_ls_failed and is_hub_failed:
            return f"Failed to deliver event, json_response: {json_res}"
        return None

    def get_response_body(self, raw_text, json_body):
        if raw_text is not None:
            return raw_text[:4096]
        return json.dumps(json_body)[:4096]

    async def emit(self, session: aiohttp.ClientSession, event: PushNotificationEvent):
        self.stdout.write("emit event {}".format(event.event_id))
        self.stdout.flush()

        utcnow = datetime.now(timezone.utc)
        event.retry = 1 if not event.retry else event.retry + 1
        event.last_retried_at = utcnow

        # fetch listener config for retry delay
        push_notification = await PushNotification.actual_objects.aget(pk=event.push_notification_id)
        retry_delay = push_notification.retry_delay_seconds
        if not retry_delay or retry_delay <= 0:
            retry_delay = self.retry_interval
        event.next_retry_at = utcnow + timedelta(seconds=retry_delay)

        attempt_status = DeliveryAttempt.Status.CONNECTION_ERROR
        http_status_code = None
        response_headers = None
        response_body = ""
        error_message = ""
        duration_ms = 0
        request_details = await event.build_request_details()
        is_retry_attempt = bool(event.retry and event.retry > 1)
        start = monotonic()

        try:
            async with session.post(
                request_details["request_url"],
                data=event.serialize_request_body(request_details["request_body"]),
                headers=request_details["request_headers"],
                ssl=request_details["ssl"],
            ) as res:
                duration_ms = int((monotonic() - start) * 1000)
                http_status_code = res.status
                response_headers = dict(res.headers)

                json_body = None
                raw_text = None
                try:
                    json_body = await res.json()
                except (aiohttp.ContentTypeError, json.JSONDecodeError):
                    raw_text = await res.text()
                    try:
                        json_body = json.loads(raw_text)
                    except json.JSONDecodeError:
                        json_body = {"raw_text": raw_text}

                response_body = self.get_response_body(raw_text, json_body)

                if res.status >= 400:
                    attempt_status = DeliveryAttempt.Status.HTTP_ERROR
                    error_message = f"Subscriber returned HTTP {res.status}"
                else:
                    invalid_response_message = self.get_invalid_response_message(json_body)
                    if invalid_response_message:
                        attempt_status = DeliveryAttempt.Status.INVALID_RESPONSE
                        error_message = invalid_response_message
                    else:
                        attempt_status = DeliveryAttempt.Status.SUCCESS
                        event.processed_at = utcnow
                        event.terminal_status = PushNotificationEvent.TerminalStatus.DELIVERED
                        event.failed_at = None
                        self.stdout.write(
                            f"event {event.event_id} has been delivered to {res.url}\njson_response: {str(json_body)}\n"
                        )
                        self.stdout.flush()
        except asyncio.TimeoutError:
            duration_ms = int((monotonic() - start) * 1000)
            attempt_status = DeliveryAttempt.Status.TIMEOUT
            error_message = (
                f"Timeout after {self.connection_timeout}s connect / {self.read_timeout}s read"
            )
        except aiohttp.ClientSSLError as exc:
            duration_ms = int((monotonic() - start) * 1000)
            attempt_status = DeliveryAttempt.Status.SSL_ERROR
            error_message = str(exc)
        except aiohttp.ClientConnectionError as exc:
            duration_ms = int((monotonic() - start) * 1000)
            attempt_status = DeliveryAttempt.Status.CONNECTION_ERROR
            error_message = str(exc)
        except Exception as exc:
            duration_ms = int((monotonic() - start) * 1000)
            attempt_status = DeliveryAttempt.Status.CONNECTION_ERROR
            error_message = str(exc)

        if http_status_code in self.permanent_error_codes:
            event.terminal_status = PushNotificationEvent.TerminalStatus.FAILED
            event.failed_at = utcnow

        if event.retry >= self.retry and event.terminal_status != PushNotificationEvent.TerminalStatus.DELIVERED:
            event.terminal_status = PushNotificationEvent.TerminalStatus.FAILED
            event.failed_at = utcnow

        if attempt_status != DeliveryAttempt.Status.SUCCESS:
            self.stderr.write(
                "error while delivering the event {}, retry {}: {}".format(
                    event.event_id, event.retry, error_message or attempt_status,
                )
            )
            self.stdout.flush()

        await sync_to_async(event.save)()

        try:
            await sync_to_async(DeliveryAttempt.objects.create)(
                push_notification_event=event,
                attempt_number=event.retry,
                is_retry=is_retry_attempt,
                status=attempt_status,
                request_url=request_details["request_url"],
                request_headers=request_details["request_headers"],
                request_body=request_details["request_body"],
                http_status_code=http_status_code,
                response_headers=response_headers,
                response_body=response_body,
                error_message=error_message,
                duration_ms=duration_ms,
            )
        except Exception as exc:
            self.stderr.write(f"Failed to log DeliveryAttempt for event {event.pk}: {exc}")
