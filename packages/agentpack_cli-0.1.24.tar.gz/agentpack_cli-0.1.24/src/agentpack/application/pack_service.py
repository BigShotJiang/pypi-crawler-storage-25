from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from agentpack.core.config import load_config
from agentpack.core.ignore import load_spec
from agentpack.core.scanner import scan
from agentpack.core.snapshot import build_snapshot, save_snapshot, load_snapshot
from agentpack.core.diff import diff_snapshots
from agentpack.core import git
from agentpack.core.context_pack import select_files, save_pack_metadata
from agentpack.core.models import ContextPack, DependencyGraph, FileInfo, ScanResult, SelectedFile, Receipt
from agentpack.core.token_estimator import estimate_tokens
from agentpack.analysis.ranking import (
    score_files,
    extract_keyword_weights,
    enrich_keyword_weights_from_files,
    boost_paired_tests,
    boost_cross_layer_related,
    generic_task_term_ratio,
)
from agentpack.analysis.tests import find_related_tests
from agentpack.analysis import dependency_graph as dep_graph_mod
from agentpack.summaries.base import build_all_summaries


@dataclass
class PackRequest:
    root: Path
    agent: str
    task: str
    mode: str
    budget: int
    since: str | None
    refresh: bool
    task_source: str = "explicit"


@dataclass
class PackResult:
    pack: ContextPack
    out_path: Path
    phase_times: dict[str, float]
    packed_tokens: int
    raw_tokens: int
    saving_pct: float
    changed_files: list[str]
    scan_result: ScanResult


@dataclass
class ChangeSet:
    """Result of change detection: snapshot diff combined with git diff."""
    all_changed: set[str]
    git_staged: set[str]
    recently_modified: list[str]
    source: str
    current_snap: dict[str, Any] = field(default_factory=dict)


@dataclass
class RankResult:
    """Result of keyword extraction and file scoring."""
    keywords: set[str]
    generic_ratio: float
    scored: list[tuple[Any, float, list[str]]]


@dataclass
class PackPlan:
    """Shared planning output used by both pack and explain."""
    task: str
    mode: str
    budget: int
    scan_result: ScanResult
    summaries: dict[str, Any]
    dep_graph: DependencyGraph
    all_changed: set[str]
    git_staged: set[str]
    recently_modified: list[str]
    keywords: set[str]
    generic_task_ratio: float
    changed_files_source: str
    scored: list[tuple[Any, float, list[str]]]
    selected: list[SelectedFile]
    receipts: list[Receipt]
    phase_times: dict[str, float]
    current_snap: dict[str, Any] = field(default_factory=dict)


class ChangeDetector:
    """Combines snapshot diff + git diff → ChangeSet of changed paths."""

    def detect(
        self,
        packable: list[FileInfo],
        root: Path,
        since: str | None,
        previous_snap: dict | None = None,
    ) -> ChangeSet:
        current_snap = build_snapshot(packable)
        if previous_snap is None:
            previous_snap = load_snapshot(root)
        snap_diff = diff_snapshots(previous_snap, current_snap)
        changed_from_snap: set[str] = set(snap_diff.added + snap_diff.modified)

        git_changed: set[str] = set()
        git_staged: set[str] = set()
        recently_modified: list[str] = []

        if git.is_git_repo(root):
            if since:
                git_changed = git.changed_files_since(root, since)
            else:
                git_changed = git.changed_files(root)
            git_staged = git_changed
            recently_modified = git.recently_modified_files(root)

        return ChangeSet(
            all_changed=changed_from_snap | git_changed,
            git_staged=git_staged,
            recently_modified=recently_modified,
            source=_change_source(root, since, changed_from_snap, git_changed),
            current_snap=current_snap,
        )


class FileRanker:
    """Extracts keywords from the task and scores files against them."""

    def rank(
        self,
        packable: list[FileInfo],
        changes: ChangeSet,
        dep_graph: DependencyGraph,
        task: str,
        cfg: Any,
        summaries: dict | None = None,
        root: Path | None = None,
    ) -> RankResult:
        from agentpack.core import git as _git
        keyword_weights = extract_keyword_weights(task)
        keyword_weights = enrich_keyword_weights_from_files(keyword_weights, changes.all_changed, packable)
        keywords = set(keyword_weights)
        generic_ratio = generic_task_term_ratio(task)
        all_paths = {f.path for f in packable}

        for fi in packable:
            tests = find_related_tests(fi.path, all_paths)
            dep_graph.nodes[fi.path].tests = tests

        churn_counts: dict[str, int] = {}
        if root is not None and _git.is_git_repo(root):
            churn_counts = _git.file_churn_counts(root)

        scored = score_files(
            packable,
            changed_paths=changes.all_changed,
            staged_paths=changes.git_staged,
            recently_modified=changes.recently_modified,
            dep_graph=dep_graph,
            keywords=keyword_weights,
            include_tests=cfg.context.include_tests,
            include_configs=cfg.context.include_configs,
            weights=cfg.scoring,
            summaries=summaries,
            churn_counts=churn_counts,
        )
        scored = boost_cross_layer_related(scored, keyword_weights, weights=cfg.scoring)
        scored = boost_paired_tests(scored, weights=cfg.scoring)
        return RankResult(keywords=keywords, generic_ratio=generic_ratio, scored=scored)


class PackPlanner:
    """Runs scan → summarize → graph → rank → select; shared by pack and explain."""

    def plan(self, request: PackRequest) -> PackPlan:
        root = request.root
        cfg = load_config(root)
        effective_budget = request.budget if request.budget > 0 else cfg.context.default_budget
        ignore_spec = load_spec(root / cfg.project.ignore_file)
        phase_times: dict[str, float] = {}

        t0 = time.perf_counter()
        previous_snap = load_snapshot(root)
        scan_result = scan(
            root, ignore_spec, cfg.context.max_file_tokens,
            previous_snapshot=previous_snap,
            include_globs=cfg.project.include_globs or None,
            exclude_globs=cfg.project.exclude_globs or None,
        )
        phase_times["scan"] = time.perf_counter() - t0

        packable = scan_result.packable

        t0 = time.perf_counter()
        summaries_objs = build_all_summaries(packable, root)
        summaries = {p: s.model_dump() for p, s in summaries_objs.items()}
        phase_times["summarize"] = time.perf_counter() - t0

        t0 = time.perf_counter()
        dep_graph = dep_graph_mod.build(packable, root, summaries=summaries)
        phase_times["deps"] = time.perf_counter() - t0

        t0 = time.perf_counter()
        changes = ChangeDetector().detect(packable, root, request.since, previous_snap=previous_snap)
        phase_times["changes"] = time.perf_counter() - t0

        t0 = time.perf_counter()
        rank_result = FileRanker().rank(packable, changes, dep_graph, request.task, cfg, summaries=summaries, root=root)
        phase_times["rank"] = time.perf_counter() - t0

        t0 = time.perf_counter()
        selected, receipts = select_files(
            files=packable,
            scored=rank_result.scored,
            changed_paths=changes.all_changed,
            summaries=summaries,
            mode=request.mode,  # type: ignore[arg-type]
            budget=effective_budget,
            max_file_tokens=cfg.context.max_file_tokens,
            keywords=rank_result.keywords,
            min_summary_score=_summary_score_floor(cfg, rank_result.generic_ratio),
            max_summary_files=_summary_cap_for_mode(cfg, request.mode, rank_result.generic_ratio),
        )
        phase_times["select"] = time.perf_counter() - t0

        return PackPlan(
            task=request.task,
            mode=request.mode,
            budget=effective_budget,
            scan_result=scan_result,
            summaries=summaries,
            dep_graph=dep_graph,
            all_changed=changes.all_changed,
            git_staged=changes.git_staged,
            recently_modified=changes.recently_modified,
            keywords=rank_result.keywords,
            generic_task_ratio=rank_result.generic_ratio,
            changed_files_source=changes.source,
            scored=rank_result.scored,
            selected=selected,
            receipts=receipts,
            phase_times=phase_times,
            current_snap=changes.current_snap,
        )


class AdapterRegistry:
    """Maps agent names to adapter instances; extensible without touching PackService."""

    @staticmethod
    def get(agent: str, cfg: Any) -> Any:
        from agentpack.adapters.antigravity import AntigravityAdapter
        from agentpack.adapters.claude import ClaudeAdapter
        from agentpack.adapters.codex import CodexAdapter
        from agentpack.adapters.cursor import CursorAdapter
        from agentpack.adapters.windsurf import WindsurfAdapter
        from agentpack.adapters.generic import GenericAdapter

        adapters = {
            "antigravity": lambda: AntigravityAdapter(),
            "claude": lambda: ClaudeAdapter(cfg.agents.claude.output),
            "cursor": lambda: CursorAdapter(cfg.agents.generic.output),
            "windsurf": lambda: WindsurfAdapter(cfg.agents.generic.output),
            "codex": lambda: CodexAdapter(cfg.agents.generic.output),
        }
        return adapters.get(agent, lambda: GenericAdapter(cfg.agents.generic.output))()


class PackService:
    """Materializes a plan from PackPlanner into a written context file."""

    def run(self, request: PackRequest) -> PackResult:
        root = request.root
        cfg = load_config(root)

        plan = PackPlanner().plan(request)

        packable = plan.scan_result.packable
        all_tokens = sum(f.estimated_tokens for f in plan.scan_result.all_files)
        raw_tokens = sum(f.estimated_tokens for f in packable)
        packed_tokens = sum(_sf_tokens(sf) for sf in plan.selected)
        saving_pct = (1 - packed_tokens / all_tokens) * 100 if all_tokens > 0 else 0.0

        all_redaction_warnings = [w for sf in plan.selected for w in sf.redaction_warnings]
        freshness = _build_freshness_metadata(
            root,
            request=request,
            plan=plan,
            snapshot_root_hash=plan.current_snap["root_hash"],
        )
        freshness_warnings = _freshness_warnings(root, request, freshness)

        pack_obj = ContextPack(
            task=request.task,
            agent=request.agent,
            mode=request.mode,  # type: ignore[arg-type]
            budget=plan.budget,
            token_estimate=packed_tokens,
            raw_repo_tokens=all_tokens,
            after_ignore_tokens=raw_tokens,
            estimated_savings_percent=saving_pct,
            changed_files=sorted(plan.all_changed),
            selected_files=plan.selected,
            receipts=plan.receipts if cfg.context.include_receipts else [],
            redaction_warnings=all_redaction_warnings,
            stale=False,
            freshness=freshness,
            freshness_warnings=freshness_warnings,
        )

        adapter = AdapterRegistry.get(request.agent, cfg)

        t0 = time.perf_counter()
        out_path = adapter.write(pack_obj, root)
        plan.phase_times["render"] = time.perf_counter() - t0

        save_snapshot(plan.current_snap, root)
        save_pack_metadata(
            root,
            context_path=str(out_path.relative_to(root)),
            snapshot_root_hash=plan.current_snap["root_hash"],
            task=request.task,
            agent=request.agent,
            mode=request.mode,
            budget=plan.budget,
            token_estimate=packed_tokens,
            freshness=freshness,
            freshness_warnings=freshness_warnings,
        )
        excluded_receipts = [r for r in plan.receipts if r.action == "excluded"]
        # Budget-cut: files that scored OK but didn't fit — more useful signal than "score too low"
        budget_cut = [r.path for r in plan.receipts if r.reason == "budget exhausted"][:10]
        _record_metrics(
            root,
            task=request.task,
            mode=request.mode,
            phase_times=plan.phase_times,
            packed_tokens=packed_tokens,
            raw_tokens=all_tokens,
            saving_pct=saving_pct,
            selected_count=len(plan.selected),
            changed_count=len(plan.all_changed),
            selected_paths=[sf.path for sf in plan.selected],
            selected_tokens={sf.path: _sf_tokens(sf) for sf in plan.selected},
            selected_modes={sf.path: sf.include_mode for sf in plan.selected},
            selected_hints=[{"path": sf.path, "why": sf.reasons[0] if sf.reasons else ""} for sf in plan.selected[:8]],
            current_changed=plan.all_changed,
            excluded_count=len(excluded_receipts),
            excluded_paths=budget_cut,
        )

        return PackResult(
            pack=pack_obj,
            out_path=out_path,
            phase_times=plan.phase_times,
            packed_tokens=packed_tokens,
            raw_tokens=all_tokens,
            saving_pct=saving_pct,
            changed_files=sorted(plan.all_changed),
            scan_result=plan.scan_result,
        )


def _sf_tokens(sf: SelectedFile) -> int:
    if sf.content:
        return estimate_tokens(sf.content)
    parts: list[str] = []
    if sf.summary:
        parts.append(sf.summary)
    for sym in sf.symbols:
        if sym.signature:
            parts.append(sym.signature)
    return estimate_tokens("\n".join(parts)) if parts else 50


def _summary_score_floor(cfg: Any, generic_ratio: float) -> float:
    floor = cfg.context.min_summary_score
    if generic_ratio >= 0.5:
        return floor + 15
    if generic_ratio >= 0.35:
        return floor + 8
    return floor


def _summary_cap_for_mode(cfg: Any, mode: str, generic_ratio: float = 0.0) -> int:
    if mode == "minimal":
        cap = cfg.context.max_summary_files_minimal
    elif mode == "balanced":
        cap = cfg.context.max_summary_files_balanced
    elif mode == "deep":
        cap = cfg.context.max_summary_files_deep
    else:
        cap = 0
    if cap > 0 and generic_ratio >= 0.5:
        return max(8, cap // 2)
    if cap > 0 and generic_ratio >= 0.35:
        return max(12, int(cap * 0.75))
    return cap


def _change_source(root: Path, since: str | None, snapshot_changed: set[str], git_changed: set[str]) -> str:
    if not git.is_git_repo(root):
        return "snapshot diff"
    if since:
        return f"git diff since {since} + snapshot diff"
    if git_changed and snapshot_changed:
        return "git working tree + snapshot diff"
    if git_changed:
        return "git working tree"
    if snapshot_changed:
        return "snapshot diff"
    return "no live changes; ranking used task keywords and history"


def _task_md_body(root: Path) -> str | None:
    task_md_path = root / ".agentpack" / "task.md"
    if not task_md_path.exists():
        return None
    try:
        content = task_md_path.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    lines = [ln for ln in content.splitlines() if ln.strip() and not ln.startswith("#")]
    body = lines[0].strip() if lines else ""
    placeholder = "Write or update the current coding task here."
    if body and placeholder not in body:
        return body
    return None


def _build_freshness_metadata(
    root: Path,
    *,
    request: PackRequest,
    plan: PackPlan,
    snapshot_root_hash: str,
) -> dict[str, Any]:
    dirty = git.dirty_files(root) if git.is_git_repo(root) else set()
    metadata: dict[str, Any] = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "task_source": request.task_source,
        "changed_files_source": plan.changed_files_source,
        "snapshot_root_hash": snapshot_root_hash,
        "generic_task_ratio": round(plan.generic_task_ratio, 3),
        "dirty_files_count": len(dirty),
    }
    if git.is_git_repo(root):
        metadata["git_sha"] = git.current_sha(root)
        metadata["git_branch"] = git.current_branch(root)
    if dirty:
        metadata["dirty_files_sample"] = sorted(dirty)[:8]
    task_md = _task_md_body(root)
    if task_md:
        metadata["task_md"] = task_md
    return metadata


def _freshness_warnings(root: Path, request: PackRequest, freshness: dict[str, Any]) -> list[str]:
    warnings: list[str] = []
    task_md = freshness.get("task_md")
    if task_md and task_md != request.task:
        warnings.append(
            ".agentpack/task.md differs from the packed task; rerun with --task auto if task.md should win."
        )
    if freshness.get("changed_files_source") == "no live changes; ranking used task keywords and history":
        warnings.append("No live changed files were detected; treat selected files as keyword-based hints.")
    if freshness.get("generic_task_ratio", 0) >= 0.5:
        warnings.append("Task terms are broad/generic; pack tightened weak-summary selection.")
    saved_sha = freshness.get("git_sha")
    current_sha = git.current_sha(root) if git.is_git_repo(root) else None
    if saved_sha and current_sha and saved_sha != current_sha:
        warnings.append("Git HEAD changed since this pack was generated.")
    return warnings


def _load_last_record(metrics_path: Path) -> dict[str, Any] | None:
    """Return the most recent metrics record that has selected_paths."""
    if not metrics_path.exists():
        return None
    try:
        lines = metrics_path.read_text(encoding="utf-8").splitlines()
        for line in reversed(lines):
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            if rec.get("selected_paths"):
                return rec
    except Exception:
        pass
    return None


def _compute_selection_accuracy(
    root: Path,
    metrics_path: Path,
    current_selected: list[str],
    current_changed: set[str],
) -> dict[str, float]:
    """Compare previous pack's selected_paths vs files actually changed since then.

    recall    = |predicted ∩ actual_changed| / |actual_changed|
    precision = |predicted ∩ actual_changed| / |predicted|
    """
    prev = _load_last_record(metrics_path)
    if prev is None:
        return {}

    prev_selected: set[str] = set(prev["selected_paths"])
    # actual_changed = files changed since the previous pack (current git diff)
    actual_changed: set[str] = current_changed
    if not actual_changed or not prev_selected:
        return {}

    hits = prev_selected & actual_changed
    recall = len(hits) / len(actual_changed)
    precision = len(hits) / len(prev_selected)
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
    result = {
        "selection_recall": round(recall, 3),
        "selection_precision": round(precision, 3),
        "selection_f1": round(f1, 3),
    }
    token_map = prev.get("selected_tokens") or {}
    if isinstance(token_map, dict):
        total_tokens = sum(v for v in token_map.values() if isinstance(v, int | float))
        hit_tokens = sum(
            token_map.get(path, 0)
            for path in hits
            if isinstance(token_map.get(path, 0), int | float)
        )
        if total_tokens > 0:
            token_precision = hit_tokens / total_tokens
            result["selection_token_precision"] = round(token_precision, 3)
            result["selection_noise_pct"] = round((1 - token_precision) * 100, 1)
        mode_map = prev.get("selected_modes") or {}
        if isinstance(mode_map, dict):
            for mode in ("full", "symbols", "summary"):
                mode_paths = {path for path, value in mode_map.items() if value == mode}
                mode_total = sum(
                    token_map.get(path, 0)
                    for path in mode_paths
                    if isinstance(token_map.get(path, 0), int | float)
                )
                if mode_total <= 0:
                    continue
                mode_hit_tokens = sum(
                    token_map.get(path, 0)
                    for path in mode_paths & hits
                    if isinstance(token_map.get(path, 0), int | float)
                )
                result[f"selection_token_precision_{mode}"] = round(mode_hit_tokens / mode_total, 3)
    return result


def _record_metrics(
    root: Path,
    *,
    task: str,
    mode: str,
    phase_times: dict[str, float],
    packed_tokens: int,
    raw_tokens: int,
    saving_pct: float,
    selected_count: int,
    changed_count: int,
    selected_paths: list[str],
    selected_tokens: dict[str, int],
    selected_modes: dict[str, str],
    current_changed: set[str],
    selected_hints: list[dict] | None = None,
    excluded_count: int = 0,
    excluded_paths: list[str] | None = None,
) -> None:
    metrics_path = root / ".agentpack" / "metrics.jsonl"
    accuracy = _compute_selection_accuracy(root, metrics_path, selected_paths, current_changed)
    record: dict[str, Any] = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "task": task,
        "mode": mode,
        "packed_tokens": packed_tokens,
        "raw_tokens": raw_tokens,
        "saving_pct": round(saving_pct, 1),
        "selected_files": selected_count,
        "changed_files": changed_count,
        "excluded_files": excluded_count,
        "excluded_paths": excluded_paths or [],
        "selected_paths": selected_paths,
        "selected_tokens": selected_tokens,
        "selected_modes": selected_modes,
        "selected_hints": selected_hints or [],
        "phases": {k: round(v, 3) for k, v in phase_times.items()},
        "total_s": round(sum(phase_times.values()), 3),
    }
    record.update(accuracy)
    try:
        with metrics_path.open("a") as fh:
            fh.write(json.dumps(record) + "\n")
    except Exception:
        pass
