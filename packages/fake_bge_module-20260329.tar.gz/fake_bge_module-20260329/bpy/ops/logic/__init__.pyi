import typing
import collections.abc
import typing_extensions
import numpy.typing as npt
import bpy.stub_internal.rna_enums

def actuator_add(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    type: str | None = "",
    name: str | None = "",
    object: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Add an actuator to the active object

    :param type: Type, Type of actuator to add (optional)
    :param name: Name, Name of the Actuator to add (optional, never None)
    :param object: Object, Name of the Object to add the Actuator to (optional, never None)
    :return: Result of the operator call.
    """

def actuator_move(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    actuator: str | None = "",
    object: str | None = "",
    direction: typing.Literal["UP", "DOWN"] | None = "UP",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Move Actuator

    :param actuator: Actuator, Name of the actuator to edit (optional, never None)
    :param object: Object, Name of the object the actuator belongs to (optional, never None)
    :param direction: Direction, Move Up or Down (optional)
    :return: Result of the operator call.
    """

def actuator_remove(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    actuator: str | None = "",
    object: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove an actuator from the active object

    :param actuator: Actuator, Name of the actuator to edit (optional, never None)
    :param object: Object, Name of the object the actuator belongs to (optional, never None)
    :return: Result of the operator call.
    """

def controller_add(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    type: Literal[bpy.stub_internal.rna_enums.ControllerTypeItems] | None = "LOGIC_AND",
    name: str | None = "",
    object: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Add a controller to the active object

    :param type: Type, Type of controller to add (optional)
    :param name: Name, Name of the Controller to add (optional, never None)
    :param object: Object, Name of the Object to add the Controller to (optional, never None)
    :return: Result of the operator call.
    """

def controller_move(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    controller: str | None = "",
    object: str | None = "",
    direction: typing.Literal["UP", "DOWN"] | None = "UP",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Move Controller

    :param controller: Controller, Name of the controller to edit (optional, never None)
    :param object: Object, Name of the object the controller belongs to (optional, never None)
    :param direction: Direction, Move Up or Down (optional)
    :return: Result of the operator call.
    """

def controller_remove(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    controller: str | None = "",
    object: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove a controller from the active object

    :param controller: Controller, Name of the controller to edit (optional, never None)
    :param object: Object, Name of the object the controller belongs to (optional, never None)
    :return: Result of the operator call.
    """

def custom_object_create(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    class_name: str | None = "module.MyObject",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Create a KX_GameObject subclass and attach it to the selected object

    :param class_name: MyObject, The class name with module (module.ClassName) (never None)
    :return: Result of the operator call.
    """

def custom_object_register(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    class_name: str | None = "module.MyObject",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Use a custom KX_GameObject subclass for the selected object

    :param class_name: MyObject, The class name with module (module.ClassName) (never None)
    :return: Result of the operator call.
    """

def custom_object_reload(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Reload custom object from the source script

    :return: Result of the operator call.
    """

def custom_object_remove(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove this custom class from the object

    :return: Result of the operator call.
    """

def links_cut(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    path=None,
    cursor: int | None = 15,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove logic brick connections

    :param path: Path, (optional)
    :param cursor: Cursor, (in [0, inf], optional)
    :return: Result of the operator call.
    """

def properties(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Toggle the properties region visibility

    :return: Result of the operator call.
    """

def python_component_create(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    component_name: str | None = "module.Component",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Create a Python component to the selected object

    :param component_name: Component, The component class name with module (module.ComponentName) (never None)
    :return: Result of the operator call.
    """

def python_component_move_down(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Move this component down in the list

    :param index: Index, Component index to move (in [0, inf], optional)
    :return: Result of the operator call.
    """

def python_component_move_up(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Move this component up in the list

    :param index: Index, Component index to move (in [0, inf], optional)
    :return: Result of the operator call.
    """

def python_component_register(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    component_name: str | None = "module.Component",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Add a Python component to the selected object

    :param component_name: Component, The component class name with module (module.ComponentName) (never None)
    :return: Result of the operator call.
    """

def python_component_reload(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Reload component from the source script

    :param index: Index, Component index to reload (in [0, inf], optional)
    :return: Result of the operator call.
    """

def python_component_remove(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove this component from the object

    :param index: Index, Component index to remove (in [0, inf], optional)
    :return: Result of the operator call.
    """

def region_flip(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Toggle the properties regions alignment (left/right)

    :return: Result of the operator call.
    """

def sensor_add(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    type: str | None = "",
    name: str | None = "",
    object: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Add a sensor to the active object

    :param type: Type, Type of sensor to add (optional)
    :param name: Name, Name of the Sensor to add (optional, never None)
    :param object: Object, Name of the Object to add the Sensor to (optional, never None)
    :return: Result of the operator call.
    """

def sensor_move(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    sensor: str | None = "",
    object: str | None = "",
    direction: typing.Literal["UP", "DOWN"] | None = "UP",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Move Sensor

    :param sensor: Sensor, Name of the sensor to edit (optional, never None)
    :param object: Object, Name of the object the sensor belongs to (optional, never None)
    :param direction: Direction, Move Up or Down (optional)
    :return: Result of the operator call.
    """

def sensor_remove(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    sensor: str | None = "",
    object: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove a sensor from the active object

    :param sensor: Sensor, Name of the sensor to edit (optional, never None)
    :param object: Object, Name of the object the sensor belongs to (optional, never None)
    :return: Result of the operator call.
    """

def view_all(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Resize view so you can see all logic bricks

    :return: Result of the operator call.
    """
