import typing
import collections.abc
import typing_extensions
import numpy.typing as npt
import bpy.stub_internal.rna_enums

def convert_bricks(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Convert Bricks to Nodes

    :return: Result of the operator call.
    """

def duplicate_brick(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Duplicate this brick

    :return: Result of the operator call.
    """

def remove_actuator(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    target_brick: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove the selected actuator from the selected object

    :param target_brick: target_brick, (optional, never None)
    :return: Result of the operator call.
    """

def remove_controller(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    target_brick: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove the selected controller from the selected object

    :param target_brick: target_brick, (optional, never None)
    :return: Result of the operator call.
    """

def remove_sensor(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    target_brick: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove the selected sensor from the selected object

    :param target_brick: target_brick, (optional, never None)
    :return: Result of the operator call.
    """

def update_all(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Synchronize logic bricks with the node setup. This should normally happen automatically

    :return: Result of the operator call.
    """
