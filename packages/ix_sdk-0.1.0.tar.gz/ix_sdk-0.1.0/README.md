# ix-sdk

Python bindings for the canonical Rust `ix-sdk`.

The package now mirrors the high-level client/branch/fs/secrets surface from
`crates/ix/sdk-napi`, using PyO3-backed handles plus typed Python dataclasses in
`ix_sdk`.

Build artifacts with `nix run .#python-sdk-build`.

Build and upload the Linux x86_64 wheel, the macOS arm64 wheel, and one source
distribution with `nix run --override-input appleSdk path:/nix/store/...-MacOSX.sdk .#py-upload`.
Set `TWINE_USERNAME` and `TWINE_PASSWORD` first. Add `-- --check` to validate
the artifacts without uploading them.

`just py-upload` defaults to the current local `MacOSX.sdk` store path. You can
also pass a raw `/path/to/MacOSX.sdk`.

Pure wheel builds are also exposed as flake packages, so `nix build` can
produce the wheel directly inside the sandbox.

Supported wheel targets are `x86_64-unknown-linux-gnu`,
`aarch64-unknown-linux-gnu`, `x86_64-apple-darwin`, and
`aarch64-apple-darwin`.

For Apple wheels from Linux, override the non-redistributable `appleSdk` flake
input to a real store path for `MacOSX.sdk`:

```bash
nix build --override-input appleSdk path:/nix/store/ik7p8ii801w0bsxwbd2b280nvgj11l3f-MacOSX26.4.sdk \
  .#python-sdk-wheel-aarch64-apple-darwin
```

The build output directory contains the wheel plus the source distribution.

Run live Python end-to-end tests with `nix run .#python-sdk-e2e`.
