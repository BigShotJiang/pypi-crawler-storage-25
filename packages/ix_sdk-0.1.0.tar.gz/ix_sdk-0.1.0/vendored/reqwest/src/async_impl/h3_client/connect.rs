use crate::async_impl::h3_client::dns::resolve;
use crate::dns::DynResolver;
use crate::error::BoxError;
use bytes::Bytes;
use h3::client::SendRequest;
use h3_quinn::{Connection, OpenStreams};
use http::Uri;
use hyper_util::client::legacy::connect::dns::Name;
use log::trace;
use quinn::crypto::rustls::QuicClientConfig;
use quinn::{ClientConfig, Endpoint, TransportConfig};
use std::net::{IpAddr, SocketAddr};
use std::str::FromStr;
use std::sync::Arc;

type H3Connection = (
    h3::client::Connection<Connection, Bytes>,
    SendRequest<OpenStreams, Bytes>,
);

/// H3 Client Config
#[derive(Clone)]
pub(crate) struct H3ClientConfig {
    pub(crate) max_field_section_size: Option<u64>,
    pub(crate) send_grease: Option<bool>,
    pub(crate) enable_0rtt: bool,
}

impl Default for H3ClientConfig {
    fn default() -> Self {
        Self {
            max_field_section_size: None,
            send_grease: None,
            enable_0rtt: false,
        }
    }
}

#[derive(Clone)]
pub(crate) struct H3Connector {
    resolver: DynResolver,
    /// Deferred: the quinn endpoint is created on first connect() so the
    /// tokio reactor is guaranteed to be the one driving the async context.
    endpoint: Option<Endpoint>,
    quinn_client_config: ClientConfig,
    local_addr: SocketAddr,
    client_config: H3ClientConfig,
}

impl H3Connector {
    pub fn new(
        resolver: DynResolver,
        tls: rustls::ClientConfig,
        local_addr: Option<IpAddr>,
        transport_config: TransportConfig,
        client_config: H3ClientConfig,
    ) -> Result<H3Connector, BoxError> {
        let quic_client_config = Arc::new(QuicClientConfig::try_from(tls)?);
        let mut config = ClientConfig::new(quic_client_config);
        config.transport_config(Arc::new(transport_config));

        let socket_addr = match local_addr {
            Some(ip) => SocketAddr::new(ip, 0),
            None => "[::]:0".parse::<SocketAddr>().unwrap(),
        };

        Ok(Self {
            resolver,
            endpoint: None,
            quinn_client_config: config,
            local_addr: socket_addr,
            client_config,
        })
    }

    /// Get or create the quinn endpoint. Deferred to first use so the
    /// endpoint's IO driver is spawned on the active tokio runtime rather
    /// than whatever runtime context existed during Client::build().
    fn endpoint(&mut self) -> Result<&Endpoint, BoxError> {
        if self.endpoint.is_none() {
            let mut endpoint = Endpoint::client(self.local_addr)?;
            endpoint.set_default_client_config(self.quinn_client_config.clone());
            self.endpoint = Some(endpoint);
        }
        Ok(self.endpoint.as_ref().unwrap())
    }

    pub async fn connect(&mut self, dest: Uri) -> Result<H3Connection, BoxError> {
        let host = dest
            .host()
            .ok_or("destination must have a host")?
            .trim_start_matches('[')
            .trim_end_matches(']');
        let port = dest.port_u16().unwrap_or(443);

        trace!("H3 connect: resolving {host}:{port}");

        let addrs = if let Ok(addr) = IpAddr::from_str(host) {
            vec![SocketAddr::new(addr, port)]
        } else {
            let addrs = resolve(&mut self.resolver, Name::from_str(host)?).await?;
            let addrs = addrs.map(|mut addr| {
                addr.set_port(port);
                addr
            });
            addrs.collect()
        };

        trace!("H3 connect: resolved {} addresses for {host}", addrs.len());
        self.remote_connect(addrs, host).await
    }

    /// Connect to one of the resolved addresses using RFC 8305 Happy Eyeballs:
    /// interleave IPv6/IPv4, race first two with a 250ms head start for IPv6,
    /// then try remaining addresses sequentially on failure.
    async fn remote_connect(
        &mut self,
        addrs: Vec<SocketAddr>,
        server_name: &str,
    ) -> Result<H3Connection, BoxError> {
        if addrs.is_empty() {
            return Err("no addresses resolved for HTTP/3 request".into());
        }

        let endpoint = self.endpoint()?.clone();
        let enable_0rtt = self.client_config.enable_0rtt;

        // Single address: direct connect, no racing.
        if addrs.len() == 1 {
            let conn = connect_one(&endpoint, addrs[0], server_name, enable_0rtt).await?;
            return self.build_h3_connection(conn).await;
        }

        let interleaved = interleave_addresses(addrs);
        let mut iter = interleaved.into_iter();
        let first = iter.next().unwrap();
        let second = iter.next().unwrap();
        let remaining: Vec<_> = iter.collect();

        // Race: start first (typically IPv6) immediately, give it 250ms head
        // start, then race against second (typically IPv4).
        let conn = race_first_two(
            &endpoint,
            first,
            second,
            server_name,
            enable_0rtt,
        )
        .await;

        match conn {
            Ok(conn) => return self.build_h3_connection(conn).await,
            Err(e) => {
                trace!("first two addresses failed: {e}");
                // Fall through to try remaining addresses sequentially.
            }
        }

        let mut last_err: BoxError =
            "first two addresses failed".into();

        for addr in remaining {
            match connect_one(&endpoint, addr, server_name, enable_0rtt).await {
                Ok(conn) => return self.build_h3_connection(conn).await,
                Err(e) => {
                    trace!("QUIC connect to {addr} failed: {e}");
                    last_err = e;
                }
            }
        }

        Err(last_err)
    }

    async fn build_h3_connection(
        &self,
        conn: quinn::Connection,
    ) -> Result<H3Connection, BoxError> {
        let quinn_conn = Connection::new(conn);
        let mut h3_client_builder = h3::client::builder();
        if let Some(max_field_section_size) = self.client_config.max_field_section_size {
            h3_client_builder.max_field_section_size(max_field_section_size);
        }
        if let Some(send_grease) = self.client_config.send_grease {
            h3_client_builder.send_grease(send_grease);
        }
        Ok(h3_client_builder.build(quinn_conn).await?)
    }
}

/// Establish a QUIC connection to a single address, with optional 0-RTT.
async fn connect_one(
    endpoint: &Endpoint,
    addr: SocketAddr,
    server_name: &str,
    enable_0rtt: bool,
) -> Result<quinn::Connection, BoxError> {
    let connecting = endpoint.connect(addr, server_name)?;

    if enable_0rtt {
        match connecting.into_0rtt() {
            Ok((conn, _zero_rtt_accepted)) => {
                trace!("QUIC 0-RTT succeeded for {addr}");
                Ok(conn)
            }
            Err(connecting) => {
                trace!("no session ticket for 0-RTT, falling back to full handshake");
                Ok(connecting.await?)
            }
        }
    } else {
        Ok(connecting.await?)
    }
}

/// RFC 8305 Happy Eyeballs: race two addresses with a 250ms delay between
/// them. Start `first` immediately; if it hasn't connected after 250ms,
/// start `second` concurrently. First success wins.
async fn race_first_two(
    endpoint: &Endpoint,
    first: SocketAddr,
    second: SocketAddr,
    server_name: &str,
    enable_0rtt: bool,
) -> Result<quinn::Connection, BoxError> {
    const HAPPY_EYEBALLS_DELAY: std::time::Duration = std::time::Duration::from_millis(250);

    let first_fut = connect_one(endpoint, first, server_name, enable_0rtt);
    tokio::pin!(first_fut);

    // Phase 1: wait up to 250ms for first to succeed.
    let delay = tokio::time::sleep(HAPPY_EYEBALLS_DELAY);
    tokio::pin!(delay);

    tokio::select! {
        result = &mut first_fut => {
            match result {
                Ok(conn) => return Ok(conn),
                Err(first_err) => {
                    trace!("first address {first} failed: {first_err}, trying {second}");
                    // First failed fast — try second directly.
                    return connect_one(endpoint, second, server_name, enable_0rtt).await;
                }
            }
        }
        () = &mut delay => {
            trace!("250ms elapsed for {first}, racing with {second}");
        }
    }

    // Phase 2: race first (still in progress) against second.
    let second_fut = connect_one(endpoint, second, server_name, enable_0rtt);
    tokio::pin!(second_fut);

    tokio::select! {
        result = &mut first_fut => {
            match result {
                Ok(conn) => Ok(conn),
                Err(first_err) => {
                    trace!("first address {first} failed: {first_err}, waiting for {second}");
                    second_fut.await
                }
            }
        }
        result = &mut second_fut => {
            match result {
                Ok(conn) => Ok(conn),
                Err(second_err) => {
                    trace!("second address {second} failed: {second_err}, waiting for {first}");
                    first_fut.await
                }
            }
        }
    }
}

/// Interleave resolved addresses: IPv6 first, alternating with IPv4 (RFC 8305).
fn interleave_addresses(addrs: Vec<SocketAddr>) -> Vec<SocketAddr> {
    let mut v6: Vec<SocketAddr> = addrs.iter().filter(|a| a.is_ipv6()).copied().collect();
    let mut v4: Vec<SocketAddr> = addrs.iter().filter(|a| a.is_ipv4()).copied().collect();

    let mut result = Vec::with_capacity(addrs.len());
    let mut v6_iter = v6.drain(..);
    let mut v4_iter = v4.drain(..);

    loop {
        match (v6_iter.next(), v4_iter.next()) {
            (Some(a6), Some(a4)) => {
                result.push(a6);
                result.push(a4);
            }
            (Some(a6), None) => {
                result.push(a6);
                result.extend(v6_iter);
                break;
            }
            (None, Some(a4)) => {
                result.push(a4);
                result.extend(v4_iter);
                break;
            }
            (None, None) => break,
        }
    }

    result
}
