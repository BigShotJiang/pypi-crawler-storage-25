use serde::{Deserialize, Serialize};

pub const DEFAULT_COLS: u16 = 80;
pub const DEFAULT_ROWS: u16 = 24;

/// TCP port the console agent listens on inside each VM.
pub const DEFAULT_PORT: u16 = 5001;

/// Well-known path for the per-instance attach token file.
///
/// Written by vm-init (initial boot) and ix-vm-guest Configure handler
/// (golden/fork restore). Read by ix-console on each incoming connection.
/// Lives on tmpfs, ephemeral per VM boot, survives golden restore.
pub const TOKEN_FILE_PATH: &str = "/run/ix/console-token";

/// Console connection mode sent in the handshake.
#[derive(Debug, Default, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase", deny_unknown_fields)]
pub enum Mode {
    #[default]
    Attach,
    Create,
    List,
    Peek,
}

/// Handshake message between client and console agent.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Handshake {
    pub token: String,
    pub cols: u16,
    pub rows: u16,
    pub mode: Mode,
    pub session: Option<u32>,
    pub command: Option<Vec<String>>,
    pub term: Option<String>,
}

/// Response sent after a successful attach or create.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AttachResponse {
    pub session: u32,
}

/// Session metadata returned by list mode.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SessionInfo {
    pub id: u32,
    pub command: Vec<String>,
    pub attached: bool,
    pub exited: bool,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn handshake_roundtrip() {
        let handshake = Handshake {
            token: "test-token".to_owned(),
            cols: 120,
            rows: 40,
            mode: Mode::Create,
            session: None,
            command: Some(vec!["bash".to_owned(), "-l".to_owned()]),
            term: Some("xterm-256color".to_owned()),
        };
        let json = serde_json::to_string(&handshake).unwrap();
        let parsed: Handshake = serde_json::from_str(&json).unwrap();
        assert_eq!(parsed.token, "test-token");
        assert_eq!(parsed.cols, 120);
        assert_eq!(parsed.rows, 40);
        assert_eq!(parsed.mode, Mode::Create);
        assert_eq!(
            parsed.command.as_deref(),
            Some(["bash".to_owned(), "-l".to_owned()].as_slice())
        );
        assert_eq!(parsed.term.as_deref(), Some("xterm-256color"));
    }

    #[test]
    fn session_info_roundtrip() {
        let info = SessionInfo {
            id: 3,
            command: vec!["htop".to_owned()],
            attached: true,
            exited: false,
        };
        let json = serde_json::to_string(&info).unwrap();
        let parsed: SessionInfo = serde_json::from_str(&json).unwrap();
        assert_eq!(parsed.id, 3);
        assert!(parsed.attached);
        assert!(!parsed.exited);
    }
}
