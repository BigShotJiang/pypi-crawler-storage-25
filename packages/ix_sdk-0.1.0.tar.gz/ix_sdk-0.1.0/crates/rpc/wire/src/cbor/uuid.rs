//! minicbor `with` module for encoding `uuid::Uuid` as a 16-byte CBOR byte string.
//!
//! Usage on fields:
//! ```ignore
//! #[n(0)] #[cbor(with = "rpc_wire::cbor::uuid")]
//! pub id: uuid::Uuid,
//! ```

/// Number of bytes in a UUID (128-bit identifier).
const BYTE_LEN: usize = 16;

pub fn encode<Ctx, W: minicbor::encode::Write>(
    uuid: &uuid::Uuid,
    e: &mut minicbor::encode::Encoder<W>,
    _ctx: &mut Ctx,
) -> Result<(), minicbor::encode::Error<W::Error>> {
    e.bytes(uuid.as_bytes())?;
    Ok(())
}

pub fn decode<Ctx>(
    d: &mut minicbor::decode::Decoder<'_>,
    _ctx: &mut Ctx,
) -> Result<uuid::Uuid, minicbor::decode::Error> {
    let bytes = d.bytes()?;
    let arr: [u8; BYTE_LEN] = bytes
        .try_into()
        .map_err(|_error| minicbor::decode::Error::message("UUID must be 16 bytes"))?;
    Ok(uuid::Uuid::from_bytes(arr))
}

/// Encode/decode for `Vec<uuid::Uuid>`.
pub mod vec {
    pub fn encode<Ctx, W: minicbor::encode::Write>(
        uuids: &Vec<uuid::Uuid>,
        e: &mut minicbor::encode::Encoder<W>,
        _ctx: &mut Ctx,
    ) -> Result<(), minicbor::encode::Error<W::Error>> {
        e.array(
            u64::try_from(uuids.len())
                .map_err(|_error| minicbor::encode::Error::message("Vec<Uuid> len overflow"))?,
        )?;
        for uuid in uuids {
            e.bytes(uuid.as_bytes())?;
        }
        Ok(())
    }

    pub fn decode<Ctx>(
        d: &mut minicbor::decode::Decoder<'_>,
        _ctx: &mut Ctx,
    ) -> Result<Vec<uuid::Uuid>, minicbor::decode::Error> {
        let len = d.array()?.ok_or_else(|| {
            minicbor::decode::Error::message("indefinite-length arrays not supported for Vec<Uuid>")
        })?;
        let capacity = usize::try_from(len)
            .map_err(|_error| minicbor::decode::Error::message("Vec<Uuid> len overflow"))?;
        let mut out = Vec::with_capacity(capacity);
        for _ in 0..len {
            let bytes = d.bytes()?;
            let arr: [u8; super::BYTE_LEN] = bytes
                .try_into()
                .map_err(|_error| minicbor::decode::Error::message("UUID must be 16 bytes"))?;
            out.push(uuid::Uuid::from_bytes(arr));
        }
        Ok(out)
    }
}

/// Encode/decode for `Option<Vec<uuid::Uuid>>`.
pub mod option_vec {
    pub fn encode<Ctx, W: minicbor::encode::Write>(
        uuids: &Option<Vec<uuid::Uuid>>,
        e: &mut minicbor::encode::Encoder<W>,
        ctx: &mut Ctx,
    ) -> Result<(), minicbor::encode::Error<W::Error>> {
        match uuids {
            Some(v) => crate::cbor::uuid::vec::encode(v, e, ctx)?,
            None => {
                e.null()?;
            }
        }
        Ok(())
    }

    pub fn decode<Ctx>(
        d: &mut minicbor::decode::Decoder<'_>,
        ctx: &mut Ctx,
    ) -> Result<Option<Vec<uuid::Uuid>>, minicbor::decode::Error> {
        if d.datatype()? == minicbor::data::Type::Null {
            d.null()?;
            return Ok(None);
        }
        crate::cbor::uuid::vec::decode(d, ctx).map(Some)
    }
}

/// Encode/decode for `Option<uuid::Uuid>`.
pub mod option {
    pub fn encode<Ctx, W: minicbor::encode::Write>(
        uuid: &Option<uuid::Uuid>,
        e: &mut minicbor::encode::Encoder<W>,
        _ctx: &mut Ctx,
    ) -> Result<(), minicbor::encode::Error<W::Error>> {
        match uuid {
            Some(u) => e.bytes(u.as_bytes())?,
            None => e.null()?,
        };
        Ok(())
    }

    pub fn decode<Ctx>(
        d: &mut minicbor::decode::Decoder<'_>,
        _ctx: &mut Ctx,
    ) -> Result<Option<uuid::Uuid>, minicbor::decode::Error> {
        if d.datatype()? == minicbor::data::Type::Null {
            d.null()?;
            return Ok(None);
        }
        let bytes = d.bytes()?;
        let arr: [u8; super::BYTE_LEN] = bytes
            .try_into()
            .map_err(|_error| minicbor::decode::Error::message("UUID must be 16 bytes"))?;
        Ok(Some(uuid::Uuid::from_bytes(arr)))
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn roundtrip() {
        #[derive(Debug, PartialEq, minicbor::Encode, minicbor::Decode)]
        struct Test {
            #[n(0)]
            #[cbor(with = "crate::cbor::uuid")]
            id: uuid::Uuid,
        }

        let original = Test {
            id: uuid::Uuid::from_bytes([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]),
        };
        let bytes = crate::encode(&original).expect("encode");
        let decoded: Test = crate::decode(&bytes).expect("decode");
        assert_eq!(original.id, decoded.id);
    }

    #[test]
    fn optional_roundtrip() {
        #[derive(Debug, PartialEq, minicbor::Encode, minicbor::Decode)]
        struct Test {
            #[n(0)]
            #[cbor(with = "crate::cbor::uuid::option")]
            id: Option<uuid::Uuid>,
        }

        let with_value = Test {
            id: Some(uuid::Uuid::from_bytes([
                1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
            ])),
        };
        let bytes = crate::encode(&with_value).expect("encode");
        let decoded: Test = crate::decode(&bytes).expect("decode");
        assert_eq!(with_value.id, decoded.id);

        let without_value = Test { id: None };
        let bytes = crate::encode(&without_value).expect("encode");
        let decoded: Test = crate::decode(&bytes).expect("decode");
        assert_eq!(without_value.id, decoded.id);
    }

    #[test]
    fn schema_evolution_skips_unknown_fields() {
        #[derive(Debug, PartialEq, minicbor::Encode, minicbor::Decode)]
        struct V1 {
            #[n(0)]
            name: String,
        }

        #[derive(Debug, PartialEq, minicbor::Encode, minicbor::Decode)]
        struct V2 {
            #[n(0)]
            name: String,
            #[n(1)]
            new_field: Option<String>,
        }

        let v2 = V2 {
            name: "test".to_owned(),
            new_field: Some("new".to_owned()),
        };
        let bytes = crate::encode(&v2).expect("encode v2");
        let v1: V1 = crate::decode(&bytes).expect("v1 should decode v2 bytes");
        assert_eq!(v1.name, "test");

        let v1 = V1 {
            name: "test".to_owned(),
        };
        let bytes = crate::encode(&v1).expect("encode v1");
        let v2: V2 = crate::decode(&bytes).expect("v2 should decode v1 bytes");
        assert_eq!(v2.name, "test");
        assert_eq!(v2.new_field, None);
    }
}
