//! minicbor `with` module for encoding `std::path::PathBuf` as a UTF-8 CBOR string.
//!
//! Usage on fields:
//! ```ignore
//! #[n(0)] #[cbor(with = "rpc_wire::cbor::path")]
//! pub path: std::path::PathBuf,
//! ```
//!
//! All paths are store paths (pure ASCII), so UTF-8 is lossless.

pub fn encode<Ctx, W: minicbor::encode::Write>(
    path: &std::path::Path,
    e: &mut minicbor::encode::Encoder<W>,
    _ctx: &mut Ctx,
) -> Result<(), minicbor::encode::Error<W::Error>> {
    e.str(&path.to_string_lossy())?;
    Ok(())
}

pub fn decode<Ctx>(
    d: &mut minicbor::decode::Decoder<'_>,
    _ctx: &mut Ctx,
) -> Result<std::path::PathBuf, minicbor::decode::Error> {
    let s = d.str()?;
    Ok(std::path::PathBuf::from(s))
}

/// Encode/decode for `Vec<PathBuf>`.
pub mod vec {
    pub fn encode<Ctx, W: minicbor::encode::Write>(
        paths: &Vec<std::path::PathBuf>,
        e: &mut minicbor::encode::Encoder<W>,
        _ctx: &mut Ctx,
    ) -> Result<(), minicbor::encode::Error<W::Error>> {
        e.array(
            u64::try_from(paths.len())
                .map_err(|_foo| minicbor::encode::Error::message("Vec<PathBuf> len overflow"))?,
        )?;
        for p in paths {
            e.str(&p.to_string_lossy())?;
        }
        Ok(())
    }

    pub fn decode<Ctx>(
        d: &mut minicbor::decode::Decoder<'_>,
        _ctx: &mut Ctx,
    ) -> Result<Vec<std::path::PathBuf>, minicbor::decode::Error> {
        let len = d
            .array()?
            .ok_or_else(|| minicbor::decode::Error::message("indefinite arrays not supported"))?;
        let cap = usize::try_from(len)
            .map_err(|_foo| minicbor::decode::Error::message("Vec<PathBuf> len overflow"))?;
        let mut out = Vec::with_capacity(cap);
        for _ in 0..len {
            out.push(std::path::PathBuf::from(d.str()?));
        }
        Ok(out)
    }
}
