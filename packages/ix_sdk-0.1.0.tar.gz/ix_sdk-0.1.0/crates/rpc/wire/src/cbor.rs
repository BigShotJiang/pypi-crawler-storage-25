//! minicbor `with` helpers for CBOR encoding of common types.

/// minicbor `with` helpers for encoding `std::path::PathBuf` as a UTF-8 CBOR string.
pub mod path;
/// minicbor `with` helpers for encoding `uuid::Uuid` as a 16-byte CBOR byte string.
pub mod uuid;
