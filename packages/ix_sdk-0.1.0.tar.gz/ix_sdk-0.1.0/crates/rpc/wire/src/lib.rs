//! Generic RPC wire encoding: CBOR codec, framing, and core traits.
//!
//! Wraps [`minicbor`] to provide:
//! - Integer-keyed CBOR map encoding (rename-safe, schema-evolution-safe)
//! - UUID encoding bridge (`cbor::uuid` module)
//! - Wire frame format (6-byte header + method + CBOR body)
//! - Core RPC traits (`Op`, `RpcRequest`, `RpcTransport`)
//!
//! This crate is transport-agnostic and contains no application-specific types.

pub mod cbor;
pub mod frame;

pub use minicbor::{Decode, Encode};

/// Per-request context. A type-erased map for arbitrary per-request data.
///
/// Servers insert whatever context they need before dispatch (auth, user ID,
/// headers, trace span), and service methods extract it via
/// [`get`](Ctx::get).
pub struct Ctx(http::Extensions);

impl Ctx {
    /// Create an empty context.
    #[must_use]
    pub fn new() -> Self {
        Self(http::Extensions::new())
    }

    /// Insert a value. Replaces any previous value of the same type.
    pub fn insert<T: Clone + Send + Sync + 'static>(&mut self, val: T) {
        self.0.insert(val);
    }

    /// Get a reference to a previously inserted value.
    #[must_use]
    pub fn get<T: Send + Sync + 'static>(&self) -> Option<&T> {
        self.0.get()
    }
}

impl Default for Ctx {
    fn default() -> Self {
        Self::new()
    }
}

/// An RPC operation with a string method name and typed request/response.
pub trait Op: Send + Sync + 'static {
    const METHOD: &'static str;
    type Req: minicbor::Encode<()> + for<'a> minicbor::Decode<'a, ()> + Send;
    type Resp: minicbor::Encode<()> + for<'a> minicbor::Decode<'a, ()> + Send;
}

/// Streaming transport shape inferred from an op's declared return type.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StreamKind {
    Event,
    Duplex,
}

/// A non-`/rpc` streaming operation.
pub trait StreamOp: Send + Sync + 'static {
    const METHOD: &'static str;
    const KIND: StreamKind;
    type Req: minicbor::Encode<()> + for<'a> minicbor::Decode<'a, ()> + Send;
}

/// Links a request type to its unique [`Op`].
///
/// Every request/response op has a unique request type. The compiler uses this
/// to infer the operation (and thus the response type) from the request alone.
pub trait RpcRequest:
    minicbor::Encode<()> + for<'a> minicbor::Decode<'a, ()> + Send + Sync
{
    type Op: Op<Req = Self>;
}

/// Links a streaming request type to its unique [`StreamOp`].
pub trait StreamRequest:
    minicbor::Encode<()> + for<'a> minicbor::Decode<'a, ()> + Send + Sync
{
    type Op: StreamOp<Req = Self>;
}

/// Typed RPC transport. Implement this to get compile-time checked RPC
/// calls where the operation and response type are inferred from the
/// request type.
pub trait RpcTransport {
    type Error;

    fn call<R: RpcRequest>(
        &self,
        req: &R,
    ) -> impl std::future::Future<Output = Result<<<R as RpcRequest>::Op as Op>::Resp, Self::Error>> + Send;
}

/// Encode a value to CBOR bytes.
pub fn encode<T: minicbor::Encode<()>>(value: &T) -> Result<Vec<u8>, EncodeError> {
    minicbor::to_vec(value).map_err(|source| EncodeError::Encode {
        detail: source.to_string(),
    })
}

/// Decode a value from CBOR bytes.
pub fn decode<'a, T: minicbor::Decode<'a, ()>>(bytes: &'a [u8]) -> Result<T, DecodeError> {
    minicbor::decode(bytes).map_err(|source| DecodeError::Decode {
        detail: source.to_string(),
    })
}

#[derive(Debug, snafu::Snafu)]
#[snafu(visibility(pub))]
pub enum EncodeError {
    #[snafu(display("CBOR encode failed: {detail}"))]
    Encode { detail: String },
}

#[derive(Debug, snafu::Snafu)]
#[snafu(visibility(pub))]
pub enum DecodeError {
    #[snafu(display("CBOR decode failed: {detail}"))]
    Decode { detail: String },
}
