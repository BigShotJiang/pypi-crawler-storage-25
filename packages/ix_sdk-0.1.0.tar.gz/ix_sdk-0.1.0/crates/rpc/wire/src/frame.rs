/// Field sizes in bytes.
const METHOD_LEN_SIZE: usize = 1;
const FLAGS_SIZE: usize = 1;
const BODY_LEN_SIZE: usize = 4;

/// Wire frame header size in bytes.
pub const HEADER_SIZE: usize = METHOD_LEN_SIZE + FLAGS_SIZE + BODY_LEN_SIZE;

/// Byte offsets within the frame header.
const METHOD_LEN_OFFSET: usize = 0;
const FLAGS_OFFSET: usize = METHOD_LEN_OFFSET + METHOD_LEN_SIZE;
const BODY_LEN_OFFSET: usize = FLAGS_OFFSET + FLAGS_SIZE;
const BODY_LEN_END: usize = BODY_LEN_OFFSET + BODY_LEN_SIZE;

/// Frame flags.
pub mod flags {
    /// Client -> server request.
    pub const REQUEST: u8 = 0x01;
    /// Server -> client response (success).
    pub const RESPONSE: u8 = 0x02;
    /// Server -> client error response.
    pub const ERROR: u8 = 0x04;
    /// Ongoing stream data (not the final frame).
    pub const STREAM: u8 = 0x08;
    /// Final frame on a stream direction.
    pub const STREAM_END: u8 = 0x10;
}

/// Wire frame header.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Header {
    pub method_len: u8,
    pub flags: u8,
    pub body_len: u32,
}

impl Header {
    #[must_use]
    pub fn encode(&self) -> [u8; HEADER_SIZE] {
        let mut buf = [0u8; HEADER_SIZE];
        buf[METHOD_LEN_OFFSET] = self.method_len;
        buf[FLAGS_OFFSET] = self.flags;
        buf[BODY_LEN_OFFSET..BODY_LEN_END].copy_from_slice(&self.body_len.to_le_bytes());
        buf
    }

    #[must_use]
    pub fn decode(buf: &[u8; HEADER_SIZE]) -> Self {
        let mut body_len_bytes = [0u8; BODY_LEN_SIZE];
        body_len_bytes.copy_from_slice(&buf[BODY_LEN_OFFSET..BODY_LEN_END]);
        Self {
            method_len: buf[METHOD_LEN_OFFSET],
            flags: buf[FLAGS_OFFSET],
            body_len: u32::from_le_bytes(body_len_bytes),
        }
    }
}

/// Maximum body size: 64 MiB. Rejects malformed frames early.
pub const MAX_BODY_SIZE: u32 = 64 * 1024 * 1024;

#[derive(Debug, snafu::Snafu)]
#[snafu(visibility(pub))]
pub enum Error {
    #[snafu(display("failed to encode frame payload: {source}"))]
    Encode { source: crate::EncodeError },

    #[snafu(display("body too large: {len} bytes"))]
    BodyTooLarge { len: usize },

    #[snafu(display("method name too long: {len} bytes (max 255)"))]
    MethodTooLong { len: usize },

    #[snafu(display("truncated frame header at offset {offset}"))]
    TruncatedHeader { offset: usize },

    #[snafu(display("truncated method name at offset {offset}"))]
    TruncatedMethod { offset: usize },

    #[snafu(display("invalid UTF-8 in method name at offset {offset}"))]
    InvalidMethodUtf8 { offset: usize },

    #[snafu(display("truncated frame body at offset {offset}"))]
    TruncatedBody { offset: usize },

    #[snafu(display("frame body length overflows usize at offset {offset}"))]
    BodyLenOverflow { offset: usize },
}

fn body_len_u32(body: &[u8]) -> Result<u32, Error> {
    u32::try_from(body.len())
        .ok()
        .filter(|&n| n <= MAX_BODY_SIZE)
        .ok_or(Error::BodyTooLarge { len: body.len() })
}

/// Parsed frame borrowed from a byte buffer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ParsedFrame<'a> {
    pub header: Header,
    pub method: &'a str,
    pub body: &'a [u8],
}

/// Parse one or more concatenated frames from a byte slice.
pub fn parse_frames(bytes: &[u8]) -> Result<Vec<ParsedFrame<'_>>, Error> {
    let mut frames = Vec::new();
    let mut offset = 0usize;

    while offset < bytes.len() {
        let remaining = bytes.len() - offset;
        if remaining < HEADER_SIZE {
            return Err(Error::TruncatedHeader { offset });
        }

        let header_slice = &bytes[offset..offset + HEADER_SIZE];
        let header_bytes: &[u8; HEADER_SIZE] = header_slice
            .try_into()
            .map_err(|_| Error::TruncatedHeader { offset })?;
        let header = Header::decode(header_bytes);
        offset += HEADER_SIZE;

        let method_len = usize::from(header.method_len);
        if bytes.len().saturating_sub(offset) < method_len {
            return Err(Error::TruncatedMethod { offset });
        }
        let method_bytes = &bytes[offset..offset + method_len];
        let method =
            core::str::from_utf8(method_bytes).map_err(|_| Error::InvalidMethodUtf8 { offset })?;
        offset += method_len;

        let body_len =
            usize::try_from(header.body_len).map_err(|_| Error::BodyLenOverflow { offset })?;
        if bytes.len().saturating_sub(offset) < body_len {
            return Err(Error::TruncatedBody { offset });
        }

        let body = &bytes[offset..offset + body_len];
        frames.push(ParsedFrame {
            header,
            method,
            body,
        });
        offset += body_len;
    }

    Ok(frames)
}

/// Extract the method name from raw frame bytes.
#[must_use]
pub fn parse_method(frame: &[u8]) -> Option<&str> {
    if frame.len() < HEADER_SIZE {
        return None;
    }
    let header_bytes: &[u8; HEADER_SIZE] = frame[..HEADER_SIZE].try_into().ok()?;
    let header = Header::decode(header_bytes);
    let method_len = usize::from(header.method_len);
    let method_end = HEADER_SIZE.checked_add(method_len)?;
    if frame.len() < method_end {
        return None;
    }
    core::str::from_utf8(&frame[HEADER_SIZE..method_end]).ok()
}

fn method_len_u8(method: &str) -> Result<u8, Error> {
    u8::try_from(method.len()).map_err(|_| Error::MethodTooLong { len: method.len() })
}

/// Build a complete frame with explicit flags.
pub fn frame_with_flags<T: minicbor::Encode<()>>(
    method: &str,
    flags: u8,
    value: &T,
) -> Result<Vec<u8>, Error> {
    use snafu::ResultExt as _;

    let method_len = method_len_u8(method)?;
    let body = crate::encode(value).context(EncodeSnafu)?;
    let header = Header {
        method_len,
        flags,
        body_len: body_len_u32(&body)?,
    };
    let mut frame = Vec::with_capacity(HEADER_SIZE + method.len() + body.len());
    frame.extend_from_slice(&header.encode());
    frame.extend_from_slice(method.as_bytes());
    frame.extend_from_slice(&body);
    Ok(frame)
}

pub fn request<T: minicbor::Encode<()>>(method: &str, value: &T) -> Result<Vec<u8>, Error> {
    frame_with_flags(method, flags::REQUEST, value)
}

pub fn response<T: minicbor::Encode<()>>(method: &str, value: &T) -> Result<Vec<u8>, Error> {
    frame_with_flags(method, flags::RESPONSE, value)
}

pub fn error<T: minicbor::Encode<()>>(method: &str, error: &T) -> Result<Vec<u8>, Error> {
    frame_with_flags(method, flags::ERROR, error)
}

#[cfg(test)]
mod tests {
    use super::{HEADER_SIZE, Header, flags, parse_frames, parse_method};

    #[test]
    fn roundtrip_header() {
        let header = Header {
            method_len: 11,
            flags: 0x03,
            body_len: 1024,
        };
        let encoded = header.encode();
        assert_eq!(encoded.len(), HEADER_SIZE);
        let decoded = Header::decode(&encoded);
        assert_eq!(header, decoded);
    }

    #[test]
    fn zero_body() {
        let header = Header {
            method_len: 0,
            flags: 0,
            body_len: 0,
        };
        let decoded = Header::decode(&header.encode());
        assert_eq!(decoded.body_len, 0);
        assert_eq!(decoded.method_len, 0);
    }

    #[test]
    fn roundtrip_request_frame() {
        let frame = super::request("getVm", &42u32).unwrap();
        let parsed = parse_frames(&frame).unwrap();
        assert_eq!(parsed.len(), 1);
        assert_eq!(parsed[0].method, "getVm");
        assert_eq!(parsed[0].header.flags, flags::REQUEST);
        assert_eq!(parsed[0].header.method_len, 5);
    }

    #[test]
    fn parse_method_extracts_name() {
        let frame = super::response("listVms", &true).unwrap();
        assert_eq!(parse_method(&frame), Some("listVms"));
    }

    #[test]
    fn parse_method_truncated() {
        assert_eq!(parse_method(&[0u8; 2]), None);
    }
}
