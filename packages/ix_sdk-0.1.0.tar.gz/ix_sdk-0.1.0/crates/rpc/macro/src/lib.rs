use proc_macro::TokenStream;
use proc_macro2::TokenStream as TokenStream2;
use quote::{format_ident, quote};
use syn::{
    GenericArgument, Ident, Result, Token, Type, TypeParamBound,
    parse::{Parse, ParseStream},
    punctuated::Punctuated,
};

#[derive(Clone, Copy, PartialEq, Eq)]
enum OpKind {
    Rpc,
    EventStream,
    Duplex,
}

/// A single parsed operation entry.
struct OpDef {
    name: Ident,
    req: Type,
    resp: Option<Type>,
}

/// The full input to `define_ops! { ... }`.
struct DefineOpsInput {
    ops: Vec<OpDef>,
}

impl Parse for OpDef {
    fn parse(input: ParseStream<'_>) -> Result<Self> {
        let name: Ident = input.parse()?;

        // Request type: `(Type)` — required.
        let content;
        syn::parenthesized!(content in input);
        let req: Type = content.parse()?;

        // Response type: `-> Type`, `-> ()`, or omitted.
        let resp = if input.peek(Token![->]) {
            input.parse::<Token![->]>()?;
            let ty: Type = input.parse()?;
            if matches!(&ty, Type::Tuple(t) if t.elems.is_empty()) {
                None
            } else {
                Some(ty)
            }
        } else {
            None
        };

        Ok(Self { name, req, resp })
    }
}

impl Parse for DefineOpsInput {
    fn parse(input: ParseStream<'_>) -> Result<Self> {
        let ops = Punctuated::<OpDef, Token![;]>::parse_terminated(input)?;
        Ok(Self {
            ops: ops.into_iter().collect(),
        })
    }
}

/// Generate all RPC artifacts from a definition block.
///
/// # Syntax
///
/// ```ignore
/// define_ops! {
///     create_vm(vm::CreateRequest) -> vm::CreateResponse;
///     delete_vm(DeleteVmRequest);  // no response = BoolResponse
///     console(subscribe::ConsoleRequest) -> impl subscribe::Duplex;
/// }
/// ```
///
/// All request and response types must be pre-defined structs.
#[proc_macro]
pub fn define_ops(input: TokenStream) -> TokenStream {
    let input = syn::parse_macro_input!(input as DefineOpsInput);
    generate(input)
        .unwrap_or_else(|err| err.to_compile_error())
        .into()
}

fn generate(input: DefineOpsInput) -> Result<TokenStream2> {
    let rpc_ops: Vec<&OpDef> = input
        .ops
        .iter()
        .filter(|op| inferred_kind(op) == OpKind::Rpc)
        .collect();
    let stream_ops: Vec<&OpDef> = input
        .ops
        .iter()
        .filter(|op| inferred_kind(op) != OpKind::Rpc)
        .collect();

    let rpc_op_structs = gen_rpc_op_structs(&rpc_ops);
    let stream_op_structs = gen_stream_op_structs(&stream_ops);
    let rpc_request_impls = gen_rpc_request_impls(&rpc_ops);
    let stream_request_impls = gen_stream_request_impls(&stream_ops);
    let service_trait = gen_service_trait(&rpc_ops);
    let dispatch_fn = gen_dispatch(&rpc_ops);
    let op_table_macro = gen_op_table(&rpc_ops);
    let activity_name_fn = gen_activity_name(&input.ops);

    Ok(quote! {
        #rpc_op_structs
        #stream_op_structs
        #rpc_request_impls
        #stream_request_impls
        #service_trait
        #dispatch_fn
        #op_table_macro
        #activity_name_fn
    })
}

// ── Naming helpers ──────────────────────────────────────────────────

/// Convert snake_case op name to a human-readable activity label.
fn to_activity_label(name: &str) -> String {
    const ABBREVIATIONS: &[&str] = &[
        "vm", "api", "ssh", "ip", "vcs", "fs", "env", "dns", "rpc", "uri", "url",
    ];
    name.split('_')
        .map(|word| {
            if ABBREVIATIONS.contains(&word) {
                word.to_uppercase()
            } else {
                word.to_owned()
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

fn req_type(op: &OpDef) -> &Type {
    &op.req
}

fn resp_type(op: &OpDef) -> TokenStream2 {
    match &op.resp {
        Some(ty) => quote! { #ty },
        None => quote! { crate::types::BoolResponse },
    }
}

// ── Stream/duplex detection ─────────────────────────────────────────

fn inferred_kind(op: &OpDef) -> OpKind {
    match op.resp.as_ref() {
        Some(ty) => infer_type_kind(ty).unwrap_or(OpKind::Rpc),
        None => OpKind::Rpc,
    }
}

fn infer_type_kind(ty: &Type) -> Option<OpKind> {
    match ty {
        Type::ImplTrait(ty) => infer_bounds_kind(&ty.bounds),
        Type::TraitObject(ty) => infer_bounds_kind(&ty.bounds),
        Type::Path(ty) => {
            let seg = ty.path.segments.last()?;
            match seg.ident.to_string().as_str() {
                "EventStream" => Some(OpKind::EventStream),
                "DuplexStream" => Some(OpKind::Duplex),
                _ => match &seg.arguments {
                    syn::PathArguments::AngleBracketed(args) => {
                        args.args.iter().find_map(|arg| match arg {
                            GenericArgument::Type(inner) => infer_type_kind(inner),
                            GenericArgument::AssocType(assoc) => infer_type_kind(&assoc.ty),
                            _ => None,
                        })
                    }
                    _ => None,
                },
            }
        }
        Type::Group(ty) => infer_type_kind(&ty.elem),
        Type::Paren(ty) => infer_type_kind(&ty.elem),
        _ => None,
    }
}

fn infer_bounds_kind(bounds: &Punctuated<TypeParamBound, Token![+]>) -> Option<OpKind> {
    if bounds.iter().any(|b| matches!(b, TypeParamBound::Trait(t) if t.path.segments.last().is_some_and(|s| s.ident == "Duplex"))) {
        return Some(OpKind::Duplex);
    }
    bounds.iter().find_map(|b| {
        matches!(b, TypeParamBound::Trait(t) if t.path.segments.last().is_some_and(|s| s.ident == "Stream"))
            .then_some(OpKind::EventStream)
    })
}

// ── Code generation ─────────────────────────────────────────────────

fn gen_rpc_op_structs(ops: &[&OpDef]) -> TokenStream2 {
    let items: Vec<TokenStream2> = ops
        .iter()
        .map(|op| {
            let name = &op.name;
            let method_str = name.to_string();
            let req_ty = req_type(op);
            let resp_ty = resp_type(op);
            quote! {
                #[allow(non_camel_case_types)]
                pub struct #name;
                impl ::rpc_wire::Op for #name {
                    const METHOD: &'static str = #method_str;
                    type Req = #req_ty;
                    type Resp = #resp_ty;
                }
            }
        })
        .collect();
    quote! { #(#items)* }
}

fn gen_stream_op_structs(ops: &[&OpDef]) -> TokenStream2 {
    let items: Vec<TokenStream2> = ops
        .iter()
        .map(|op| {
            let name = &op.name;
            let method_str = name.to_string();
            let req_ty = req_type(op);
            let kind = match inferred_kind(op) {
                OpKind::EventStream => quote! { ::rpc_wire::StreamKind::Event },
                OpKind::Duplex => quote! { ::rpc_wire::StreamKind::Duplex },
                OpKind::Rpc => unreachable!("stream op expected"),
            };
            quote! {
                #[allow(non_camel_case_types)]
                pub struct #name;
                impl ::rpc_wire::StreamOp for #name {
                    const METHOD: &'static str = #method_str;
                    const KIND: ::rpc_wire::StreamKind = #kind;
                    type Req = #req_ty;
                }
            }
        })
        .collect();
    quote! { #(#items)* }
}

fn gen_rpc_request_impls(ops: &[&OpDef]) -> TokenStream2 {
    let impls: Vec<TokenStream2> = ops
        .iter()
        .map(|op| {
            let req_ty = req_type(op);
            let op_name = &op.name;
            quote! {
                impl ::rpc_wire::RpcRequest for #req_ty {
                    type Op = #op_name;
                }
            }
        })
        .collect();
    quote! { #(#impls)* }
}

fn gen_stream_request_impls(ops: &[&OpDef]) -> TokenStream2 {
    let impls: Vec<TokenStream2> = ops
        .iter()
        .map(|op| {
            let req_ty = req_type(op);
            let op_name = &op.name;
            quote! {
                impl ::rpc_wire::StreamRequest for #req_ty {
                    type Op = #op_name;
                }
            }
        })
        .collect();
    quote! { #(#impls)* }
}

fn gen_service_trait(ops: &[&OpDef]) -> TokenStream2 {
    let methods: Vec<TokenStream2> = ops
        .iter()
        .map(|op| {
            let name = &op.name;
            let req_ty = req_type(op);
            let resp_ty = resp_type(op);
            quote! {
                async fn #name(
                    &self,
                    ctx: &::rpc_wire::Ctx,
                    req: #req_ty,
                ) -> ::core::result::Result<#resp_ty, crate::error::Error>;
            }
        })
        .collect();

    quote! {
        /// Generated RPC service trait.
        #[allow(async_fn_in_trait)]
        pub trait Service {
            #(#methods)*
        }
    }
}

fn gen_dispatch(ops: &[&OpDef]) -> TokenStream2 {
    let arms: Vec<TokenStream2> = ops
        .iter()
        .map(|op| {
            let name = &op.name;
            let method_str = name.to_string();
            let req_ty = req_type(op);
            quote! {
                #method_str => {
                    let req: #req_ty = ::rpc_wire::decode(payload).map_err(|_| {
                        crate::error::Error::InvalidRequest {
                            message: "failed to decode request".to_owned(),
                        }
                    })?;
                    let resp = service.#name(ctx, req).await?;
                    ::rpc_wire::encode(&resp).map_err(|_| crate::error::Error::Internal {
                        message: "failed to encode response".to_owned(),
                    })
                }
            }
        })
        .collect();

    quote! {
        /// Decode a CBOR request, route to the matching [`Service`] method,
        /// and encode the response as CBOR bytes.
        ///
        /// Returns `Err` for decode failures, unknown methods, or handler errors.
        pub async fn dispatch(
            service: &(impl Service + Sync),
            ctx: &::rpc_wire::Ctx,
            method: &str,
            payload: &[u8],
        ) -> ::core::result::Result<Vec<u8>, crate::error::Error> {
            match method {
                #(#arms)*
                _ => Err(crate::error::Error::UnsupportedOp {
                    method: method.to_owned(),
                }),
            }
        }
    }
}

fn gen_op_table(ops: &[&OpDef]) -> TokenStream2 {
    let dollar = proc_macro2::Punct::new('$', proc_macro2::Spacing::Alone);
    let entries: Vec<TokenStream2> = ops
        .iter()
        .map(|op| {
            let name = &op.name;
            quote! {
                (#name,
                 <crate::ops::#name as ::rpc_wire::Op>::Req,
                 <crate::ops::#name as ::rpc_wire::Op>::Resp),
            }
        })
        .collect();
    let cb = format_ident!("callback");
    quote! {
        #[macro_export]
        macro_rules! op_table {
            (#dollar #cb:ident) => {
                #dollar #cb ! {
                    #(#entries)*
                }
            };
        }
    }
}

fn gen_activity_name(ops: &[OpDef]) -> TokenStream2 {
    let arms: Vec<TokenStream2> = ops
        .iter()
        .map(|op| {
            let method_str = op.name.to_string();
            let label = to_activity_label(&method_str);
            quote! { #method_str => #label, }
        })
        .collect();

    quote! {
        #[must_use]
        pub fn activity_name(method: &str) -> &'static str {
            match method {
                #(#arms)*
                _ => "RPC request",
            }
        }
    }
}
