//! Generic idempotency middleware for 0-RTT replay protection.
//!
//! Provides at-most-once execution for RPC handlers when TLS 1.3 early data
//! (0-RTT) is enabled. The client sends an `idempotency-key` header with each
//! request; the server deduplicates by key.
//!
//! Implement [`Store`] for your backend (e.g. PostgreSQL) and call
//! [`execute`] to wrap any handler with idempotency.

const HEADER: &str = "idempotency-key";
const POLL_INTERVAL: std::time::Duration = std::time::Duration::from_millis(10);
const POLL_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(30);

/// Backend for idempotency key storage.
///
/// Must support atomic claim (insert-if-absent), response caching, and
/// response retrieval. Implementations should use a durable store (e.g.
/// PostgreSQL) so that replayed requests are caught across server restarts.
pub trait Store: Send + Sync {
    type Error: std::error::Error + Send;

    /// Try to claim a key. Returns `true` if this caller now owns it,
    /// `false` if it was already claimed (duplicate/replay).
    fn try_claim(
        &self,
        key: uuid::Uuid,
    ) -> impl std::future::Future<Output = Result<bool, Self::Error>> + Send;

    /// Fetch the cached response for a previously claimed key.
    /// Returns `None` if the key has no response yet (still in-flight).
    fn get_response(
        &self,
        key: uuid::Uuid,
    ) -> impl std::future::Future<Output = Result<Option<Vec<u8>>, Self::Error>> + Send;

    /// Store the response for a claimed key.
    fn set_response(
        &self,
        key: uuid::Uuid,
        response: &[u8],
    ) -> impl std::future::Future<Output = Result<(), Self::Error>> + Send;
}

/// Idempotency execution failure.
#[derive(Debug)]
pub enum Error {
    /// Duplicate request still in-flight; timed out waiting for the
    /// original to complete.
    InFlight,
    /// Store backend error — fail closed.
    Store,
}

impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InFlight => write!(f, "duplicate request in flight"),
            Self::Store => {
                write!(f, "idempotency store unavailable; retry with the same key")
            }
        }
    }
}

/// Execute a handler with idempotency protection.
///
/// If the request has an `idempotency-key` header:
/// - First request: claims the key, executes the handler, caches the response.
/// - Duplicate while in-flight: polls until the first completes, returns cached.
/// - Duplicate after completion: returns cached response immediately.
///
/// If no header is present, executes the handler directly.
pub async fn execute<S, F, Fut>(
    store: &S,
    headers: &http::HeaderMap,
    handler: F,
) -> Result<Vec<u8>, Error>
where
    S: Store,
    F: FnOnce() -> Fut,
    Fut: std::future::Future<Output = Vec<u8>>,
{
    let Some(key) = extract_key(headers) else {
        return Ok(handler().await);
    };

    match store.try_claim(key).await {
        Ok(true) => {
            let response = handler().await;
            if let Err(e) = store.set_response(key, &response).await {
                tracing::warn!(?e, %key, "failed to cache idempotency response");
            }
            Ok(response)
        }
        Ok(false) => poll_for_cached(store, key).await,
        Err(e) => {
            tracing::warn!(?e, %key, "idempotency claim failed");
            Err(Error::Store)
        }
    }
}

async fn poll_for_cached<S: Store>(store: &S, key: uuid::Uuid) -> Result<Vec<u8>, Error> {
    let deadline = tokio::time::Instant::now() + POLL_TIMEOUT;

    loop {
        match store.get_response(key).await {
            Ok(Some(response)) => return Ok(response),
            Ok(None) if tokio::time::Instant::now() >= deadline => return Err(Error::InFlight),
            Ok(None) => tokio::time::sleep(POLL_INTERVAL).await,
            Err(e) => {
                tracing::warn!(?e, %key, "failed to fetch cached response");
                return Err(Error::Store);
            }
        }
    }
}

fn extract_key(headers: &http::HeaderMap) -> Option<uuid::Uuid> {
    headers
        .get(HEADER)
        .and_then(|v| v.to_str().ok())
        .and_then(|s| uuid::Uuid::parse_str(s).ok())
}
