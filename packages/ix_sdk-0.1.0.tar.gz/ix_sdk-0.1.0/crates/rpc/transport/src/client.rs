//! Generic HTTP client for method-framed CBOR RPC.

use snafu::ResultExt as _;

#[derive(Debug, snafu::Snafu)]
#[snafu(visibility(pub))]
pub enum Error {
    #[snafu(display("failed to encode request: {source}"))]
    Encode { source: rpc_wire::frame::Error },

    #[snafu(display("failed to decode response: {source}"))]
    Decode { source: rpc_wire::DecodeError },

    #[snafu(display("stream ended without a terminal frame"))]
    MissingStreamEnd,

    #[snafu(display("failed to parse response frame stream: {detail}"))]
    FrameStream { detail: String },

    #[snafu(display("HTTP request failed: {source}"))]
    Http { source: reqwest::Error },

    #[snafu(display("invalid endpoint URL: {source}"))]
    InvalidUrl { source: url::ParseError },

    #[snafu(display("response frame too short ({len} bytes)"))]
    FrameTooShort { len: usize },

    #[snafu(display("RPC error frame received (error flag set)"))]
    RpcErrorFrame,
}

/// Generic CBOR-framed RPC client.
///
/// Sends `POST` with `application/x-ix-rpc` body, dispatched by method name.
/// Auth headers are injected via a caller-provided closure.
#[derive(Clone)]
pub struct Client {
    http: reqwest::Client,
    endpoint: url::Url,
}

impl std::fmt::Debug for Client {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Client")
            .field("endpoint", &self.endpoint)
            .finish_non_exhaustive()
    }
}

impl Client {
    /// Create a client for `{base_url}/{rpc_path}` with default HTTP settings.
    pub fn new(base_url: &str, rpc_path: &str) -> Result<Self, Error> {
        Self::with_http_client(
            reqwest::Client::builder()
                .http2_prior_knowledge()
                .timeout(std::time::Duration::from_secs(30))
                .connect_timeout(std::time::Duration::from_secs(5))
                .build()
                .unwrap_or_default(),
            base_url,
            rpc_path,
        )
    }

    /// Create a client with a caller-provided [`reqwest::Client`].
    ///
    /// Use this when the transport needs custom TLS (e.g. mTLS via SPIFFE).
    pub fn with_http_client(
        http: reqwest::Client,
        base_url: &str,
        rpc_path: &str,
    ) -> Result<Self, Error> {
        let base = base_url.trim_end_matches('/');
        let endpoint = url::Url::parse(&format!("{base}/{rpc_path}")).context(InvalidUrlSnafu)?;
        Ok(Self { http, endpoint })
    }

    /// Send a typed RPC request and decode the response.
    pub async fn call<O: rpc_wire::Op>(&self, req: &O::Req) -> Result<O::Resp, Error> {
        self.call_op::<O>(req).await
    }

    /// Send an inferred typed RPC request and decode the response.
    pub async fn call_req<R: rpc_wire::RpcRequest>(
        &self,
        req: &R,
    ) -> Result<<<R as rpc_wire::RpcRequest>::Op as rpc_wire::Op>::Resp, Error> {
        self.call_op::<<R as rpc_wire::RpcRequest>::Op>(req).await
    }

    /// Like [`call`](Self::call) but injects a user-id header.
    pub async fn call_as<O: rpc_wire::Op>(
        &self,
        user_id: uuid::Uuid,
        req: &O::Req,
    ) -> Result<O::Resp, Error> {
        self.call_op_as::<O>(user_id, req).await
    }

    /// Like [`call_as`](Self::call_as) but decodes typed RPC error frames.
    pub async fn call_as_with_rpc_error<O: rpc_wire::Op, E>(
        &self,
        user_id: uuid::Uuid,
        req: &O::Req,
    ) -> Result<O::Resp, ErrorWithRpc<E>>
    where
        E: for<'a> minicbor::Decode<'a, ()>,
    {
        self.call_op_as_with_rpc_error::<O, E>(user_id, req).await
    }

    /// Like [`call_req`](Self::call_req) but injects a user-id header.
    pub async fn call_req_as<R: rpc_wire::RpcRequest>(
        &self,
        user_id: uuid::Uuid,
        req: &R,
    ) -> Result<<<R as rpc_wire::RpcRequest>::Op as rpc_wire::Op>::Resp, Error> {
        self.call_op_as::<<R as rpc_wire::RpcRequest>::Op>(user_id, req)
            .await
    }

    /// Like [`call`](Self::call) but with caller-provided headers.
    pub async fn call_with_headers<O: rpc_wire::Op>(
        &self,
        req: &O::Req,
        headers: &http::HeaderMap,
    ) -> Result<O::Resp, Error> {
        self.call_op_with_headers::<O>(req, headers).await
    }

    /// Like [`call_with_headers`](Self::call_with_headers) but decodes typed
    /// RPC error frames.
    pub async fn call_with_headers_with_rpc_error<O: rpc_wire::Op, E>(
        &self,
        req: &O::Req,
        headers: &http::HeaderMap,
    ) -> Result<O::Resp, ErrorWithRpc<E>>
    where
        E: for<'a> minicbor::Decode<'a, ()>,
    {
        self.call_op_with_headers_with_rpc_error::<O, E>(req, headers)
            .await
    }

    /// Raw POST returning the response body bytes.
    pub async fn post_raw(&self, body: Vec<u8>) -> Result<Vec<u8>, Error> {
        self.post(body, &http::HeaderMap::new()).await
    }

    async fn call_op<O: rpc_wire::Op>(&self, req: &O::Req) -> Result<O::Resp, Error> {
        self.call_op_with_headers::<O>(req, &http::HeaderMap::new())
            .await
    }

    async fn call_op_as<O: rpc_wire::Op>(
        &self,
        user_id: uuid::Uuid,
        req: &O::Req,
    ) -> Result<O::Resp, Error> {
        let mut headers = http::HeaderMap::new();
        headers.insert("x-ix-user-id", user_id.to_string().parse().unwrap());
        self.call_op_with_headers::<O>(req, &headers).await
    }

    async fn call_op_as_with_rpc_error<O: rpc_wire::Op, E>(
        &self,
        user_id: uuid::Uuid,
        req: &O::Req,
    ) -> Result<O::Resp, ErrorWithRpc<E>>
    where
        E: for<'a> minicbor::Decode<'a, ()>,
    {
        let mut headers = http::HeaderMap::new();
        headers.insert("x-ix-user-id", user_id.to_string().parse().unwrap());
        self.call_op_with_headers_with_rpc_error::<O, E>(req, &headers)
            .await
    }

    async fn call_op_with_headers<O: rpc_wire::Op>(
        &self,
        req: &O::Req,
        headers: &http::HeaderMap,
    ) -> Result<O::Resp, Error> {
        let frame = rpc_wire::frame::request(O::METHOD, req).context(EncodeSnafu)?;
        let body = self.post(frame, headers).await?;
        decode_response(&body)
    }

    async fn call_op_with_headers_with_rpc_error<O: rpc_wire::Op, E>(
        &self,
        req: &O::Req,
        headers: &http::HeaderMap,
    ) -> Result<O::Resp, ErrorWithRpc<E>>
    where
        E: for<'a> minicbor::Decode<'a, ()>,
    {
        let frame = rpc_wire::frame::request(O::METHOD, req)
            .map_err(|source| ErrorWithRpc::Transport(Error::Encode { source }))?;
        let body = self
            .post(frame, headers)
            .await
            .map_err(ErrorWithRpc::Transport)?;
        decode_response_with_error(&body)
    }

    async fn post(&self, body: Vec<u8>, extra_headers: &http::HeaderMap) -> Result<Vec<u8>, Error> {
        let mut request = self
            .http
            .post(self.endpoint.clone())
            .header("content-type", "application/x-ix-rpc");

        let mut trace_headers = http::HeaderMap::new();
        ix_tracing::inject_current_context_into_http_headers(&mut trace_headers);
        for (name, value) in &trace_headers {
            request = request.header(name, value);
        }

        for (name, value) in extra_headers {
            request = request.header(name, value);
        }

        let response = request.body(body).send().await.context(HttpSnafu)?;
        Ok(response.bytes().await.context(HttpSnafu)?.to_vec())
    }
}

/// Decode a single-frame response, checking for error flag.
///
/// If the response frame has the error flag set, returns `RpcErrorFrame`.
/// For application-level error decoding (e.g. typed RPC errors), use
/// [`decode_response_with_error`].
pub fn decode_response<Resp>(body: &[u8]) -> Result<Resp, Error>
where
    Resp: for<'a> minicbor::Decode<'a, ()>,
{
    if body.len() < rpc_wire::frame::HEADER_SIZE {
        return Err(Error::FrameTooShort { len: body.len() });
    }

    let header_bytes: &[u8; rpc_wire::frame::HEADER_SIZE] = body[..rpc_wire::frame::HEADER_SIZE]
        .try_into()
        .expect("length checked above");
    let header = rpc_wire::frame::Header::decode(header_bytes);

    let method_len = usize::from(header.method_len);
    let payload_start = rpc_wire::frame::HEADER_SIZE + method_len;
    if body.len() < payload_start {
        return Err(Error::FrameTooShort { len: body.len() });
    }
    let payload = &body[payload_start..];

    if header.flags & rpc_wire::frame::flags::ERROR != 0 {
        return Err(Error::RpcErrorFrame);
    }

    rpc_wire::decode(payload).context(DecodeSnafu)
}

/// Decode a response frame, decoding typed errors from error frames.
///
/// Returns `Ok(resp)` on success frames, `Err(RpcError { error })` on error
/// frames where the error body decodes as `E`.
pub fn decode_response_with_error<Resp, E>(body: &[u8]) -> Result<Resp, ErrorWithRpc<E>>
where
    Resp: for<'a> minicbor::Decode<'a, ()>,
    E: for<'a> minicbor::Decode<'a, ()>,
{
    if body.len() < rpc_wire::frame::HEADER_SIZE {
        return Err(ErrorWithRpc::Transport(Error::FrameTooShort {
            len: body.len(),
        }));
    }

    let header_bytes: &[u8; rpc_wire::frame::HEADER_SIZE] = body[..rpc_wire::frame::HEADER_SIZE]
        .try_into()
        .expect("length checked above");
    let header = rpc_wire::frame::Header::decode(header_bytes);

    let method_len = usize::from(header.method_len);
    let payload_start = rpc_wire::frame::HEADER_SIZE + method_len;
    if body.len() < payload_start {
        return Err(ErrorWithRpc::Transport(Error::FrameTooShort {
            len: body.len(),
        }));
    }
    let payload = &body[payload_start..];

    if header.flags & rpc_wire::frame::flags::ERROR != 0 {
        let rpc_err: E = rpc_wire::decode(payload)
            .map_err(|source| ErrorWithRpc::Transport(Error::Decode { source }))?;
        return Err(ErrorWithRpc::Rpc(rpc_err));
    }

    rpc_wire::decode(payload).map_err(|source| ErrorWithRpc::Transport(Error::Decode { source }))
}

/// Error type that distinguishes transport failures from typed RPC errors.
#[derive(Debug)]
pub enum ErrorWithRpc<E> {
    Transport(Error),
    Rpc(E),
}

impl<E: std::fmt::Display> std::fmt::Display for ErrorWithRpc<E> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Transport(e) => write!(f, "transport error: {e}"),
            Self::Rpc(e) => write!(f, "RPC error: {e}"),
        }
    }
}
