//! Server-side frame helpers for method-framed CBOR RPC.
//!
//! These helpers are generic — they work with any CBOR-encodable types.
//! Application-specific error mapping (e.g. RPC error → HTTP status)
//! belongs in the application's RPC crate.

/// Parsed RPC frame: method name + payload bytes.
#[derive(Debug)]
pub struct RequestFrame<'a> {
    pub method: &'a str,
    pub payload: &'a [u8],
}

/// Parse an RPC request frame from raw bytes.
///
/// Validates the 6-byte header, extracts the method name, and returns
/// a borrowed view of the payload. No allocation.
pub fn parse_request(body: &[u8]) -> Result<RequestFrame<'_>, FrameError> {
    if body.len() < rpc_wire::frame::HEADER_SIZE {
        return Err(FrameError::TooShort { len: body.len() });
    }

    let header_bytes: &[u8; rpc_wire::frame::HEADER_SIZE] = body[..rpc_wire::frame::HEADER_SIZE]
        .try_into()
        .expect("length checked above");
    let header = rpc_wire::frame::Header::decode(header_bytes);

    if header.body_len > rpc_wire::frame::MAX_BODY_SIZE {
        return Err(FrameError::BodyTooLarge {
            len: header.body_len,
        });
    }

    let method_len = usize::from(header.method_len);
    let method_end = rpc_wire::frame::HEADER_SIZE + method_len;
    if body.len() < method_end {
        return Err(FrameError::TruncatedMethod);
    }

    let method = core::str::from_utf8(&body[rpc_wire::frame::HEADER_SIZE..method_end])
        .map_err(|_| FrameError::InvalidMethodUtf8)?;

    let payload = &body[method_end..];
    let payload_len = u32::try_from(payload.len()).map_err(|_| FrameError::BodyLenMismatch)?;
    if payload_len != header.body_len {
        return Err(FrameError::BodyLenMismatch);
    }

    Ok(RequestFrame { method, payload })
}

#[derive(Debug, snafu::Snafu)]
#[snafu(visibility(pub))]
pub enum FrameError {
    #[snafu(display("frame too short ({len} bytes)"))]
    TooShort { len: usize },

    #[snafu(display("body too large ({len} bytes)"))]
    BodyTooLarge { len: u32 },

    #[snafu(display("truncated method name"))]
    TruncatedMethod,

    #[snafu(display("invalid UTF-8 in method name"))]
    InvalidMethodUtf8,

    #[snafu(display("body_len does not match actual payload length"))]
    BodyLenMismatch,
}

#[cfg(feature = "axum")]
impl axum::response::IntoResponse for FrameError {
    fn into_response(self) -> axum::response::Response {
        (http::StatusCode::BAD_REQUEST, self.to_string()).into_response()
    }
}

/// Decode a CBOR-encoded request from a raw payload.
pub fn decode_req<'a, T: rpc_wire::Decode<'a, ()>>(
    payload: &'a [u8],
) -> Result<T, rpc_wire::DecodeError> {
    rpc_wire::decode(payload)
}

/// Encode a response value to CBOR bytes.
pub fn encode_resp<T: rpc_wire::Encode<()>>(value: &T) -> Result<Vec<u8>, rpc_wire::EncodeError> {
    rpc_wire::encode(value)
}

/// Decode a single-frame request (exactly one frame expected).
pub fn decode_single_req<T>(frames: &[rpc_wire::frame::ParsedFrame<'_>]) -> Result<T, DecodeError>
where
    T: for<'a> minicbor::Decode<'a, ()>,
{
    if frames.len() != 1 {
        return Err(DecodeError::ExpectedOneFrame {
            actual: frames.len(),
        });
    }
    rpc_wire::decode(frames[0].body).map_err(|source| DecodeError::Cbor { source })
}

/// Build a success response frame (header + method + CBOR body).
pub fn success_response(method: &str, response_body: &[u8]) -> Vec<u8> {
    let method_len = match u8::try_from(method.len()) {
        Ok(len) => len,
        Err(_) => return empty_error_frame(method),
    };
    let body_len = match u32::try_from(response_body.len()) {
        Ok(len) => len,
        Err(_) => return empty_error_frame(method),
    };
    let header = rpc_wire::frame::Header {
        method_len,
        flags: rpc_wire::frame::flags::RESPONSE,
        body_len,
    };
    let mut frame =
        Vec::with_capacity(rpc_wire::frame::HEADER_SIZE + method.len() + response_body.len());
    frame.extend_from_slice(&header.encode());
    frame.extend_from_slice(method.as_bytes());
    frame.extend_from_slice(response_body);
    frame
}

/// Build an error response frame with a CBOR-encodable error body.
pub fn error_frame<E: rpc_wire::Encode<()>>(method: &str, err: &E) -> Vec<u8> {
    match rpc_wire::frame::error(method, err) {
        Ok(frame) => frame,
        Err(encode_err) => {
            tracing::error!(
                method,
                encode_error = ?encode_err,
                "failed to serialize RPC error frame"
            );
            empty_error_frame(method)
        }
    }
}

/// Encode a response frame (header + method + CBOR body).
pub fn encode_response_frame<T: rpc_wire::Encode<()>>(
    method: &str,
    value: &T,
) -> Result<Vec<u8>, rpc_wire::frame::Error> {
    rpc_wire::frame::response(method, value)
}

/// Minimal error frame with no body (last-resort fallback).
fn empty_error_frame(method: &str) -> Vec<u8> {
    let method_len = u8::try_from(method.len()).unwrap_or(0);
    let header = rpc_wire::frame::Header {
        method_len,
        flags: rpc_wire::frame::flags::ERROR,
        body_len: 0,
    };
    let mut buf = Vec::with_capacity(rpc_wire::frame::HEADER_SIZE + usize::from(method_len));
    buf.extend_from_slice(&header.encode());
    buf.extend_from_slice(&method.as_bytes()[..usize::from(method_len)]);
    buf
}

#[derive(Debug, snafu::Snafu)]
#[snafu(visibility(pub))]
pub enum DecodeError {
    #[snafu(display("expected exactly one frame, got {actual}"))]
    ExpectedOneFrame { actual: usize },

    #[snafu(display("failed to decode request: {source}"))]
    Cbor { source: rpc_wire::DecodeError },
}
