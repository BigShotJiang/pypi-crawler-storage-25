//! Generic RPC transport for CBOR-framed services.
//!
//! Provides:
//! - [`Op`] trait (re-exported from `rpc-wire`): ties a method name to its request/response types
//! - [`op!`] macro: one-liner op definitions
//! - [`Client`]: generic HTTP client for method-framed RPC
//! - [`server`]: shared frame encode/response helpers

#[cfg(feature = "client")]
pub mod client;
pub mod idempotency;
pub mod server;

pub use rpc_wire::Op;

/// Define an [`Op`] implementation as a unit struct.
///
/// ```ignore
/// // Explicit method name:
/// rpc_transport::op!(pub boot_vm = "boot_vm", BootVmRequest, BootVmResponse);
/// // Method name derived from struct name:
/// rpc_transport::op!(pub boot_vm, BootVmRequest, BootVmResponse);
/// ```
#[macro_export]
macro_rules! op {
    ($vis:vis $name:ident = $method:expr, $req:ty, $resp:ty) => {
        #[allow(non_camel_case_types)]
        $vis struct $name;
        impl $crate::Op for $name {
            const METHOD: &'static str = $method;
            type Req = $req;
            type Resp = $resp;
        }
    };
    ($vis:vis $name:ident, $req:ty, $resp:ty) => {
        #[allow(non_camel_case_types)]
        $vis struct $name;
        impl $crate::Op for $name {
            const METHOD: &'static str = stringify!($name);
            type Req = $req;
            type Resp = $resp;
        }
    };
}
