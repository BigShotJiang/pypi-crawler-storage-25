use crate::{
    Backend,
    backend::Error,
    config::Ssh,
    ssh::{self, KeySource, expand_tilde},
    types::SigStatus,
};

const TEST_PRIVATE_KEY: &str = r#"-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACDx71sNV//ZjA00Sz+kXGVZDmXrOU6yyjZdaIlap8cvhQAAAJgQMeH8EDHh
/AAAAAtzc2gtZWQyNTUxOQAAACDx71sNV//ZjA00Sz+kXGVZDmXrOU6yyjZdaIlap8cvhQ
AAAEAueTcWll7PKYgVYX6FiT0wnioj3BISN9FJrR1dqC6fRvHvWw1X/9mMDTRLP6RcZVkO
Zes5TrLKNl1oiVqnxy+FAAAAEHRlc3RAZXhhbXBsZS5jb20BAgMEBQ==
-----END OPENSSH PRIVATE KEY-----"#;

#[test]
fn test_can_read_signature() {
    let backend = ssh::Backend::from_config(None, Ssh::default());

    assert!(backend.can_read(b"-----BEGIN SSH SIGNATURE-----\nfoo"));
    assert!(!backend.can_read(b"-----BEGIN PGP SIGNATURE-----\nfoo"));
    assert!(!backend.can_read(b"random data"));
}

#[test]
fn test_expand_tilde() {
    let path = expand_tilde("~/.ssh/id_ed25519");
    assert!(!path.to_string_lossy().starts_with('~'));
}

#[test]
fn test_key_parsing() {
    let private_key = ssh_key::PrivateKey::from_openssh(TEST_PRIVATE_KEY)
        .expect("test key should parse correctly");

    assert_eq!(
        private_key.algorithm(),
        ssh_key::Algorithm::Ed25519,
        "test key should be Ed25519"
    );
}

#[test]
fn test_sign_with_inline_key() {
    let backend = ssh::Backend::with_key_data(TEST_PRIVATE_KEY, Ssh::default());
    let data = b"test data to sign";

    let signature = backend.sign(data, None).expect("signing should succeed");

    assert!(signature.starts_with(b"-----BEGIN SSH SIGNATURE-----"));
    assert!(signature.ends_with(b"-----END SSH SIGNATURE-----\n"));
}

#[test]
fn test_sign_verify_roundtrip() {
    let backend = ssh::Backend::with_key_data(TEST_PRIVATE_KEY, Ssh::default());
    let data = b"test commit data";

    let signature = backend.sign(data, None).expect("signing should succeed");

    let verification = backend
        .verify(data, &signature)
        .expect("verification should succeed");

    assert!(
        verification.status == SigStatus::Unknown,
        "expected Unknown status (no allowed-signers), got {:?}",
        verification.status
    );
    assert!(verification.key_fingerprint.is_some());
}

#[test]
fn test_sign_different_data_different_signature() {
    let backend = ssh::Backend::with_key_data(TEST_PRIVATE_KEY, Ssh::default());

    let sig1 = backend.sign(b"data1", None).expect("sign 1");
    let sig2 = backend.sign(b"data2", None).expect("sign 2");

    assert_ne!(sig1, sig2);
}

#[test]
fn test_verify_wrong_data_fails() {
    let backend = ssh::Backend::with_key_data(TEST_PRIVATE_KEY, Ssh::default());

    let signature = backend.sign(b"original data", None).expect("sign");

    let result = backend.verify(b"tampered data", &signature);

    let verification = result.expect("verification should succeed");
    assert_eq!(verification.status, SigStatus::Bad);
}

#[test]
fn test_sign_without_key_fails() {
    let backend = ssh::Backend::from_config(None, Ssh::default());

    let err = backend
        .sign(b"data", None)
        .expect_err("signing should fail without a configured key");
    assert!(
        matches!(err, Error::KeyNotFound { .. }),
        "expected KeyNotFound, got {err:?}"
    );
}

#[test]
fn test_verify_invalid_signature_format() {
    let backend = ssh::Backend::from_config(None, Ssh::default());

    let err = backend
        .verify(b"data", b"not a valid signature")
        .expect_err("verification should fail for invalid signature format");
    assert!(
        matches!(err, Error::VerificationFailed { .. }),
        "expected VerificationFailed, got {err:?}"
    );
}

#[test]
fn test_from_config_detects_inline_key() {
    let backend1 = ssh::Backend::from_config(Some(TEST_PRIVATE_KEY), Ssh::default());
    assert!(matches!(backend1.key_source, Some(KeySource::Data(_))));

    let backend2 = ssh::Backend::from_config(Some("~/.ssh/id_ed25519"), Ssh::default());
    assert!(matches!(backend2.key_source, Some(KeySource::Path(_))));
}
