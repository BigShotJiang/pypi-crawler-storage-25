#[derive(
    Debug,
    Clone,
    PartialEq,
    Eq,
    serde::Serialize,
    serde::Deserialize,
    rkyv::Archive,
    rkyv::Serialize,
    rkyv::Deserialize
)]
#[serde(deny_unknown_fields)]
pub struct SecureSig {
    pub data: Vec<u8>,

    pub sig: Vec<u8>,

    pub format: String,
}

impl SecureSig {
    #[must_use]
    pub fn new(data: Vec<u8>, sig: Vec<u8>, format: impl Into<String>) -> Self {
        Self {
            data,
            sig,
            format: format.into(),
        }
    }

    #[must_use]
    pub fn ssh(data: Vec<u8>, sig: Vec<u8>) -> Self {
        Self::new(data, sig, "ssh")
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SigStatus {
    Good,

    Unknown,

    Bad,

    Missing,
}

impl SigStatus {
    #[must_use]
    pub fn is_valid(&self) -> bool {
        matches!(self, Self::Good | Self::Unknown)
    }

    #[must_use]
    pub fn is_trusted(&self) -> bool {
        matches!(self, Self::Good)
    }
}

#[derive(Debug, Clone)]
pub struct Verification {
    pub status: SigStatus,

    pub key_fingerprint: Option<String>,

    pub signer_identity: Option<String>,

    pub message: Option<String>,
}

impl Verification {
    #[must_use]
    pub fn good(fingerprint: String, identity: String) -> Self {
        let message = format!("Signed by {identity}");
        Self {
            status: SigStatus::Good,
            key_fingerprint: Some(fingerprint),
            signer_identity: Some(identity),
            message: Some(message),
        }
    }

    #[must_use]
    pub fn unknown(fingerprint: String) -> Self {
        Self {
            status: SigStatus::Unknown,
            key_fingerprint: Some(fingerprint),
            signer_identity: None,
            message: Some("Valid signature from unknown key".to_owned()),
        }
    }

    #[must_use]
    pub fn bad(reason: impl Into<String>) -> Self {
        Self {
            status: SigStatus::Bad,
            key_fingerprint: None,
            signer_identity: None,
            message: Some(reason.into()),
        }
    }

    #[must_use]
    pub fn missing() -> Self {
        Self {
            status: SigStatus::Missing,
            key_fingerprint: None,
            signer_identity: None,
            message: Some("No signature present".to_owned()),
        }
    }
}
