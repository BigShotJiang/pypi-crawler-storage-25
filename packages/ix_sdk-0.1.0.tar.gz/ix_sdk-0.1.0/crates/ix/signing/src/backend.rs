use crate::types::Verification;

#[derive(Debug, snafu::Snafu)]
#[snafu(visibility(pub))]
pub enum Error {
    #[snafu(display("signing key not found: {details}"))]
    KeyNotFound { details: String },

    #[snafu(display("failed to parse signing key"))]
    InvalidKey { source: ssh_key::Error },

    #[snafu(display("failed to read key file"))]
    ReadKeyFile {
        source: std::io::Error,
        path: String,
    },

    #[snafu(display("failed to sign data"))]
    Key { source: ssh_key::Error },

    #[snafu(display("failed to encode signature as PEM"))]
    EncodePem { source: ssh_key::Error },

    #[snafu(display("verification failed: {details}"))]
    VerificationFailed { details: String },

    #[snafu(display("signing backend not configured"))]
    NotConfigured,

    #[snafu(display("I/O error"))]
    Io { source: std::io::Error },
}

pub type Result<T> = std::result::Result<T, Error>;

pub trait Backend: std::fmt::Debug + Send + Sync {
    fn name(&self) -> &'static str;

    fn can_read(&self, signature: &[u8]) -> bool;

    fn sign(&self, data: &[u8], key: Option<&str>) -> Result<Vec<u8>>;

    fn verify(&self, data: &[u8], signature: &[u8]) -> Result<Verification>;
}

#[derive(Debug, Default)]
pub struct Noop;

impl Backend for Noop {
    fn name(&self) -> &'static str {
        "none"
    }

    fn can_read(&self, _signature: &[u8]) -> bool {
        false
    }

    fn sign(&self, _data: &[u8], _key: Option<&str>) -> Result<Vec<u8>> {
        Err(Error::NotConfigured)
    }

    fn verify(&self, _data: &[u8], _signature: &[u8]) -> Result<Verification> {
        Ok(Verification::missing())
    }
}
