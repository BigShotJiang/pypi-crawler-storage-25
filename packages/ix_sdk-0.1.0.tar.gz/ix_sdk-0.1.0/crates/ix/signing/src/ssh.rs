use snafu::ResultExt as _;

use crate::{
    backend::{self, Error},
    config::Ssh,
    types::Verification,
};

const SIG_MAGIC: &[u8] = b"-----BEGIN SSH SIGNATURE-----";

const NAMESPACE: &str = "ix";

/// Source of the signing key — either a file path or inline PEM data.
/// Encodes the mutual exclusion at the type level: exactly one source or none.
#[derive(Debug)]
pub(crate) enum KeySource {
    Path(std::path::PathBuf),
    Data(String),
}

#[derive(Debug)]
pub struct Backend {
    key_source: Option<KeySource>,
    config: Ssh,
}

impl Backend {
    #[must_use]
    pub fn with_key_path(path: impl Into<std::path::PathBuf>, config: Ssh) -> Self {
        Self {
            key_source: Some(KeySource::Path(path.into())),
            config,
        }
    }

    #[must_use]
    pub fn with_key_data(data: impl Into<String>, config: Ssh) -> Self {
        Self {
            key_source: Some(KeySource::Data(data.into())),
            config,
        }
    }

    #[must_use]
    pub fn from_config(key: Option<&str>, config: Ssh) -> Self {
        match key {
            Some(k) if k.contains("-----BEGIN") => Self::with_key_data(k, config),
            Some(k) => Self::with_key_path(expand_tilde(k), config),
            None => Self {
                key_source: None,
                config,
            },
        }
    }

    fn sign_with_key(&self, data: &[u8]) -> backend::Result<Vec<u8>> {
        let private_key = self.load_private_key()?;

        let signature = private_key
            .sign(NAMESPACE, ssh_key::HashAlg::Sha512, data)
            .context(crate::backend::KeySnafu)?;

        let sig_bytes = signature
            .to_pem(ssh_key::LineEnding::LF)
            .context(crate::backend::EncodePemSnafu)?;

        Ok(sig_bytes.into_bytes())
    }

    fn load_private_key(&self) -> backend::Result<ssh_key::PrivateKey> {
        match &self.key_source {
            Some(KeySource::Data(data)) => {
                ssh_key::PrivateKey::from_openssh(data).context(crate::backend::InvalidKeySnafu)
            }
            Some(KeySource::Path(path)) => {
                let data =
                    std::fs::read_to_string(path).context(crate::backend::ReadKeyFileSnafu {
                        path: path.display().to_string(),
                    })?;
                ssh_key::PrivateKey::from_openssh(&data).context(crate::backend::InvalidKeySnafu)
            }
            None => Err(Error::KeyNotFound {
                details: "no signing key configured".to_owned(),
            }),
        }
    }

    fn lookup_identity(&self, public_key: &ssh_key::PublicKey) -> Option<String> {
        let allowed_signers_path = self.config.allowed_signers.as_ref()?;
        let path = expand_tilde(allowed_signers_path);

        let content = std::fs::read_to_string(&path).ok()?;
        let key_data = public_key.to_openssh().ok()?;

        for line in content.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            const ALLOWED_SIGNERS_FIELDS: usize = 3;
            let parts: Vec<&str> = line.splitn(ALLOWED_SIGNERS_FIELDS, ' ').collect();
            let (Some(identity), Some(rest)) = (parts.first(), parts.get(2)) else {
                continue;
            };
            let matches = rest.contains(&*key_data);
            if matches {
                return Some((*identity).to_owned());
            }
        }

        None
    }
}

struct VerifyResult {
    is_valid: Option<bool>,
    fingerprint: String,
    public_key: ssh_key::PublicKey,
}

impl crate::backend::Backend for Backend {
    fn name(&self) -> &'static str {
        "ssh"
    }

    fn can_read(&self, signature: &[u8]) -> bool {
        signature.starts_with(SIG_MAGIC)
    }

    fn sign(&self, data: &[u8], key: Option<&str>) -> backend::Result<Vec<u8>> {
        if let Some(k) = key {
            let temp_backend = Self::from_config(Some(k), self.config.clone());
            return temp_backend.sign_with_key(data);
        }

        self.sign_with_key(data)
    }

    fn verify(&self, data: &[u8], signature: &[u8]) -> backend::Result<Verification> {
        let result = verify_signature(data, signature)?;

        match result.is_valid {
            Some(false) => Ok(Verification::bad("cryptographic verification failed")),
            Some(true) => match self.lookup_identity(&result.public_key) {
                Some(identity) => Ok(Verification::good(result.fingerprint, identity)),
                None => Ok(Verification::unknown(result.fingerprint)),
            },
            None => Ok(Verification::unknown(result.fingerprint)),
        }
    }
}

fn verify_signature(data: &[u8], signature: &[u8]) -> backend::Result<VerifyResult> {
    let sig_str = std::str::from_utf8(signature).map_err(|e| Error::VerificationFailed {
        details: format!("invalid UTF-8 in signature: {e}"),
    })?;

    let ssh_sig = ssh_key::SshSig::from_pem(sig_str).map_err(|e| Error::VerificationFailed {
        details: format!("invalid SSH signature: {e}"),
    })?;

    if ssh_sig.namespace() != NAMESPACE {
        return Err(Error::VerificationFailed {
            details: format!(
                "wrong namespace: expected '{}', got '{}'",
                NAMESPACE,
                ssh_sig.namespace()
            ),
        });
    }

    let key_data = ssh_sig.public_key();

    let public_key: ssh_key::PublicKey = key_data.clone().into();

    let fingerprint = public_key.fingerprint(ssh_key::HashAlg::Sha256).to_string();

    let is_valid = public_key.verify(NAMESPACE, data, &ssh_sig).is_ok();

    Ok(VerifyResult {
        is_valid: Some(is_valid),
        fingerprint,
        public_key,
    })
}

pub(crate) fn expand_tilde(path: &str) -> std::path::PathBuf {
    if let Some(rest) = path.strip_prefix("~/") {
        if let Some(home) = dirs::home_dir() {
            return home.join(rest);
        }
    }
    std::path::PathBuf::from(path)
}

#[cfg(test)]
mod tests;
