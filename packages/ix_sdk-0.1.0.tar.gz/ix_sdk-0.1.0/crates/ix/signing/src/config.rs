#[derive(
    Debug,
    Clone,
    Copy,
    Default,
    PartialEq,
    Eq,
    serde::Serialize,
    serde::Deserialize
)]
#[serde(deny_unknown_fields, rename_all = "lowercase")]
pub enum Behavior {
    Drop,

    #[default]
    Keep,

    Own,

    Force,
}

impl Behavior {
    #[must_use]
    pub fn should_sign(&self, author_entity: &str, current_entity: &str) -> bool {
        match self {
            Self::Drop => false,
            Self::Keep => false,
            Self::Own => author_entity == current_entity,
            Self::Force => true,
        }
    }

    #[must_use]
    pub fn should_preserve(&self) -> bool {
        matches!(self, Self::Keep)
    }
}

#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    pub backend: String,

    pub key: Option<String>,

    pub sign: Behavior,

    pub ssh: Ssh,
}

impl Config {
    #[must_use]
    pub fn is_enabled(&self) -> bool {
        !self.backend.is_empty() && self.backend != "none"
    }

    #[must_use]
    pub fn backend_name(&self) -> &str {
        if self.backend.is_empty() {
            "none"
        } else {
            &self.backend
        }
    }
}

#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Ssh {
    pub allowed_signers: Option<String>,

    pub revocation_list: Option<String>,

    pub program: String,
}
