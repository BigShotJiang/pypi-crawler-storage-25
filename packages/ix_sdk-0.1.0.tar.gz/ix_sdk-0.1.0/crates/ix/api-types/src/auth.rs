// SSH authentication types

#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SshChallengeRequest {
    pub fingerprint: String,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SshChallengeResponse {
    pub challenge: String,
    pub expires_at: String,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SshVerifyRequest {
    pub fingerprint: String,
    pub challenge: String,
    pub signature: String,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SshVerifyResponse {
    pub token: String,
    pub user: UserInfo,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct UserInfo {
    pub id: i64,
    pub username: String,
}

// CLI login types

#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct StartCliLoginResponse {
    pub token: String,
    pub url: String,
}

#[derive(
    Debug,
    Clone,
    Copy,
    PartialEq,
    Eq,
    serde::Serialize,
    serde::Deserialize
)]
#[serde(deny_unknown_fields, rename_all = "snake_case")]
pub enum CliLoginStatus {
    Pending,
    Authenticated,
    Expired,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CliLoginPollResponse {
    pub status: CliLoginStatus,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub token: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub username: Option<String>,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CompleteCliLoginRequest {
    pub cli_token: String,
}

// Common types

#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ErrorResponse {
    pub error: String,
}
