/// Memory size in mebibytes (MiB, 2^20 bytes).
#[derive(
    Debug,
    Clone,
    Copy,
    PartialEq,
    Eq,
    PartialOrd,
    Ord,
    Hash,
    serde::Serialize,
    serde::Deserialize
)]
#[serde(transparent)]
pub struct Mebibytes(pub i32);

impl std::fmt::Display for Mebibytes {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{} MiB", self.0)
    }
}

impl From<i32> for Mebibytes {
    fn from(value: i32) -> Self {
        Self(value)
    }
}

impl TryFrom<i64> for Mebibytes {
    type Error = std::num::TryFromIntError;

    fn try_from(value: i64) -> Result<Self, Self::Error> {
        Ok(Self(i32::try_from(value)?))
    }
}

impl From<Mebibytes> for i32 {
    fn from(value: Mebibytes) -> Self {
        value.0
    }
}
