/// Strip CIDR prefix length (e.g. `/128`) from an address string.
///
/// Postgres `inet` columns and orchestrator responses serialize addresses as
/// `addr/prefix` (e.g. `fd00::1/128`, `10.0.0.1/24`). Consumers typically
/// expect the bare address without the prefix length.
#[must_use]
pub fn strip_cidr_suffix(addr: &str) -> &str {
    match addr.split('/').next() {
        Some(host) => host,
        None => addr,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strips_ipv6_128() {
        assert_eq!(strip_cidr_suffix("fd00::1/128"), "fd00::1");
    }

    #[test]
    fn strips_ipv6_64() {
        assert_eq!(strip_cidr_suffix("fd00::1/64"), "fd00::1");
    }

    #[test]
    fn strips_ipv4() {
        assert_eq!(strip_cidr_suffix("10.0.0.1/24"), "10.0.0.1");
    }

    #[test]
    fn no_prefix_unchanged() {
        assert_eq!(strip_cidr_suffix("fd00::1"), "fd00::1");
    }

    #[test]
    fn empty_string() {
        assert_eq!(strip_cidr_suffix(""), "");
    }
}
