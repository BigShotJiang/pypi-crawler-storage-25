pub mod auth;
pub mod net;
pub mod units;

/// Synthetic user for system-owned resources (external image cache, system compute VMs).
/// Must exist in the `users` table for FK constraints.
pub const SYSTEM_USER_ID: uuid::Uuid = uuid::Uuid::from_bytes([
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x70, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01,
]);
