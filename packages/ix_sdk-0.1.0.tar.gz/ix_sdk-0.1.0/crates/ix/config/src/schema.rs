use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Profile {
    pub token: Option<String>,

    #[serde(default = "crate::server::default_url")]
    pub server: String,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Settings {
    pub token: Option<String>,

    #[serde(default = "crate::server::default_url")]
    pub server: String,

    pub default_profile: Option<String>,

    #[serde(default)]
    pub profiles: std::collections::BTreeMap<String, Profile>,

    pub branch_prefix: Option<String>,

    #[serde(default)]
    pub worktree: Worktree,

    #[serde(default)]
    pub signing: ix_signing::Config,

    #[serde(skip)]
    pub repo: Option<Repo>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Worktree {
    pub enabled: bool,

    pub location: WorktreeLocation,

    pub auto_cleanup: bool,

    pub cache_count: u32,

    pub cow_cache: CowCache,
}

/// Default number of cached base worktrees for fast CoW cloning.
const DEFAULT_CACHE_COUNT: u32 = 5;

impl Default for Worktree {
    fn default() -> Self {
        Self {
            enabled: false,
            location: WorktreeLocation::default(),
            auto_cleanup: true,
            cache_count: DEFAULT_CACHE_COUNT,
            cow_cache: CowCache::default(),
        }
    }
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, rename_all = "lowercase")]
pub enum WorktreeLocation {
    #[default]
    Git,

    Xdg,
}

const DEFAULT_COW_CACHE_ENABLED: bool = false;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CowCache {
    pub enabled: bool,

    pub directories: Vec<String>,

    pub skip_patterns: Vec<String>,
}

impl Default for CowCache {
    fn default() -> Self {
        Self {
            enabled: DEFAULT_COW_CACHE_ENABLED,
            directories: vec![
                "target".to_owned(),
                "node_modules".to_owned(),
                ".build".to_owned(),
                "dist".to_owned(),
                "vendor".to_owned(),
                "__pycache__".to_owned(),
                ".venv".to_owned(),
            ],
            skip_patterns: vec![
                "target/*/incremental".to_owned(),
                "target/*/incremental/**".to_owned(),
                "target/*/deps/*.exe".to_owned(),
                "target/*/examples".to_owned(),
                "target/*/examples/**".to_owned(),
                "target/doc".to_owned(),
                "target/doc/**".to_owned(),
                "node_modules/.cache".to_owned(),
                "node_modules/.cache/**".to_owned(),
                "node_modules/.vite".to_owned(),
                "node_modules/.vite/**".to_owned(),
                "**/__pycache__".to_owned(),
                "**/*.pyc".to_owned(),
                "**/.DS_Store".to_owned(),
                "**/Thumbs.db".to_owned(),
            ],
        }
    }
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Repo {
    pub trunk: Option<String>,

    pub remote: String,

    pub repo: Option<String>,

    pub worktree: Option<Worktree>,
}

/// Resolved profile credentials after applying profile + legacy fallback.
pub struct ResolvedProfile {
    pub name: String,
    pub token: Option<String>,
    pub server: String,
}

impl Settings {
    /// Resolve credentials from the named profile, falling back to top-level
    /// `token`/`server` when `profiles` is empty (legacy config).
    #[must_use]
    pub fn resolve_profile(&self, name: Option<&str>) -> ResolvedProfile {
        let profile_name = name
            .map(str::to_owned)
            .or_else(|| self.default_profile.clone())
            .unwrap_or_else(|| "default".to_owned());

        if let Some(profile) = self.profiles.get(&profile_name) {
            return ResolvedProfile {
                name: profile_name,
                token: profile.token.clone(),
                server: profile.server.clone(),
            };
        }

        // Legacy fallback: no profiles map, use top-level fields.
        ResolvedProfile {
            name: profile_name,
            token: self.token.clone(),
            server: self.server.clone(),
        }
    }

    #[must_use]
    pub fn effective_worktree(&self) -> &Worktree {
        match self.repo.as_ref().and_then(|repo| repo.worktree.as_ref()) {
            Some(worktree) => worktree,
            None => &self.worktree,
        }
    }

    #[must_use]
    pub fn worktree_enabled(&self) -> bool {
        self.effective_worktree().enabled
    }
}
