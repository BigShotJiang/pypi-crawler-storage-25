/// Tiered config resolution for SDK clients.
///
/// Resolution order per field (highest wins):
/// 1. Explicit caller-provided value
/// 2. Env var (`IX_TOKEN`, `IX_SERVER`)
/// 3. `/etc/ix/config.toml` (machine-level)
/// 4. `~/.config/ix/config.toml` (user-level, default profile)
/// 5. Built-in default (server only: `https://api.ix.dev`)

const MACHINE_CONFIG_PATH: &str = "/etc/ix/config.toml";

/// Machine-level config — intentionally minimal, no `deny_unknown_fields`
/// so it can coexist with other fields in `/etc/ix/config.toml`.
#[derive(Default, serde::Deserialize)]
struct MachineConfig {
    #[serde(default)]
    token: Option<String>,
    #[serde(default)]
    server: Option<String>,
}

pub struct Resolved {
    pub token: Option<String>,
    pub server: String,
}

/// Resolve token + server from the tiered config chain.
///
/// Each field is resolved independently: machine config wins over user config,
/// env vars win over both, and explicit overrides win over everything.
pub fn resolve(token_override: Option<&str>, server_override: Option<&str>) -> Resolved {
    // Layer 5: built-in default
    let mut token: Option<String> = None;
    let mut server = crate::DEFAULT_URL.to_owned();

    // Layer 4: user config (~/.config/ix/config.toml)
    if let Ok(user_settings) = crate::load_global() {
        let profile = user_settings.resolve_profile(None);
        if let Some(t) = profile.token {
            token = Some(t);
        }
        if !profile.server.is_empty() {
            server = profile.server;
        }
    }

    // Layer 3: machine config (/etc/ix/config.toml)
    if let Some(machine) = load_machine_config() {
        if let Some(t) = machine.token {
            token = Some(t);
        }
        if let Some(s) = machine.server {
            if !s.is_empty() {
                server = s;
            }
        }
    }

    // Layer 2: env vars
    if let Ok(val) = std::env::var("IX_TOKEN") {
        if !val.is_empty() {
            token = Some(val);
        }
    }
    if let Ok(val) = std::env::var("IX_SERVER") {
        if !val.is_empty() {
            server = val;
        }
    }

    // Layer 1: explicit overrides
    if let Some(t) = token_override {
        if !t.is_empty() {
            token = Some(t.to_owned());
        }
    }
    if let Some(s) = server_override {
        if !s.is_empty() {
            server = s.to_owned();
        }
    }

    Resolved { token, server }
}

fn load_machine_config() -> Option<MachineConfig> {
    let content = std::fs::read_to_string(MACHINE_CONFIG_PATH).ok()?;
    toml::from_str(&content).ok()
}
