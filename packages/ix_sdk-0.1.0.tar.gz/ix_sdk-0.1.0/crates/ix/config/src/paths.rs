use snafu::OptionExt as _;

#[derive(Debug, snafu::Snafu)]
#[snafu(visibility(pub))]
pub enum Error {
    #[snafu(display("could not determine config directory"))]
    Dir,

    #[snafu(display("could not determine data directory"))]
    DataDir,

    #[snafu(display("could not determine home directory"))]
    HomeDir,
}

/// # Errors
///
/// Returns an error if the config directory cannot be determined.
pub fn global() -> Result<std::path::PathBuf, Error> {
    if let Ok(config_home) = std::env::var("XDG_CONFIG_HOME") {
        return Ok(std::path::PathBuf::from(config_home)
            .join("ix")
            .join("config.toml"));
    }

    if let Some(home_dir) = dirs::home_dir() {
        return Ok(home_dir.join(".config").join("ix").join("config.toml"));
    }

    let config_dir = dirs::config_dir().context(DirSnafu)?;
    Ok(config_dir.join("ix").join("config.toml"))
}

#[must_use]
pub fn repo(repo_root: &std::path::Path) -> std::path::PathBuf {
    repo_root.join(".ix").join("config.toml")
}

/// # Errors
///
/// Returns an error if the data directory cannot be determined.
pub fn data_dir() -> Result<std::path::PathBuf, Error> {
    let data_dir = dirs::data_dir().context(DataDirSnafu)?;
    Ok(data_dir.join("ix"))
}

/// # Errors
///
/// Returns an error if the data directory cannot be determined.
pub fn xdg_worktrees_dir(repo_name: &str) -> Result<std::path::PathBuf, Error> {
    Ok(data_dir()?.join("worktrees").join(repo_name))
}

/// # Errors
///
/// Returns an error if the home directory cannot be determined.
pub fn trace_dir() -> Result<std::path::PathBuf, Error> {
    let home = dirs::home_dir().context(HomeDirSnafu)?;
    Ok(home.join(".ix").join("trace"))
}

#[cfg(test)]
mod tests {
    #[test]
    fn test_global() {
        let path = super::global().unwrap();
        assert!(path.ends_with("ix/config.toml"));
    }

    #[test]
    fn test_repo() {
        let path = super::repo(std::path::Path::new("/tmp/myrepo"));
        assert_eq!(
            path,
            std::path::PathBuf::from("/tmp/myrepo/.ix/config.toml")
        );
    }
}
