mod defaults;
mod env;
pub mod paths;
pub mod resolve;
mod schema;
mod server;

use std::path::Path;

pub use defaults::generate;
pub use resolve::resolve;
pub use schema::{CowCache, Profile, Repo, ResolvedProfile, Settings, Worktree, WorktreeLocation};
pub use server::{
    DEFAULT_API_HOST, DEFAULT_FRONTEND_URL, DEFAULT_GIT_HOST, DEFAULT_HOST, DEFAULT_URL,
    default_docs_url, default_url, is_default_git_ssh_url, is_default_http_url,
    strip_default_git_ssh_prefix, strip_default_http_prefix,
};
use snafu::ResultExt as _;

#[derive(Debug, snafu::Snafu)]
#[snafu(module, visibility(pub))]
pub enum LoadError {
    #[snafu(display("failed to resolve config path"))]
    ResolvePath { source: paths::Error },
    #[snafu(display("failed to read config file: {}", path.display()))]
    ReadFile {
        path: std::path::PathBuf,
        source: std::io::Error,
    },
    #[snafu(display("failed to parse config file: {}", path.display()))]
    ParseToml {
        path: std::path::PathBuf,
        source: toml::de::Error,
    },
}

#[derive(Debug, snafu::Snafu)]
#[snafu(module, visibility(pub))]
pub enum SaveError {
    #[snafu(display("failed to resolve config path"))]
    ResolvePath { source: paths::Error },
    #[snafu(display("failed to create config directory: {}", path.display()))]
    CreateDir {
        path: std::path::PathBuf,
        source: std::io::Error,
    },
    #[snafu(display("failed to serialize config"))]
    Serialize { source: toml::ser::Error },
    #[snafu(display("failed to write config file: {}", path.display()))]
    WriteFile {
        path: std::path::PathBuf,
        source: std::io::Error,
    },
}

pub fn load(repo_root: &Path) -> Result<Settings, LoadError> {
    let global_path = paths::global().context(load_error::ResolvePathSnafu)?;
    let mut config = if global_path.exists() {
        load_strict_toml(&global_path)?
    } else {
        Settings::default()
    };

    let repo_path = paths::repo(repo_root);
    if repo_path.exists() {
        let repo_config: Repo = load_strict_toml(&repo_path)?;
        config.repo = Some(repo_config);
    }

    env::apply_overrides(&mut config);

    Ok(config)
}

pub fn load_global() -> Result<Settings, LoadError> {
    let global_path = paths::global().context(load_error::ResolvePathSnafu)?;
    let mut config = if global_path.exists() {
        load_strict_toml(&global_path)?
    } else {
        Settings::default()
    };

    env::apply_overrides(&mut config);
    Ok(config)
}

pub fn save_global(config: &Settings) -> Result<(), SaveError> {
    let path = paths::global().context(save_error::ResolvePathSnafu)?;
    save_toml(&path, config)
}

pub fn save_repo(repo_root: &Path, config: &Repo) -> Result<(), SaveError> {
    let path = paths::repo(repo_root);
    save_toml(&path, config)
}

fn load_strict_toml<T: serde::de::DeserializeOwned>(path: &Path) -> Result<T, LoadError> {
    let content = std::fs::read_to_string(path).context(load_error::ReadFileSnafu {
        path: path.to_owned(),
    })?;

    toml::from_str(&content).context(load_error::ParseTomlSnafu {
        path: path.to_owned(),
    })
}

fn save_toml<T: serde::Serialize>(path: &Path, value: &T) -> Result<(), SaveError> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).context(save_error::CreateDirSnafu {
            path: parent.to_owned(),
        })?;
    }

    let content = toml::to_string_pretty(value).context(save_error::SerializeSnafu)?;
    std::fs::write(path, content).context(save_error::WriteFileSnafu {
        path: path.to_owned(),
    })
}
