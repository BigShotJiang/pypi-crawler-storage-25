use crate::schema::{Settings, WorktreeLocation};

pub fn apply_overrides(config: &mut Settings) {
    if let Some(val) = parse_bool("IX_WORKTREE") {
        config.worktree.enabled = val;
    }

    if let Ok(val) = std::env::var("IX_WORKTREE_LOCATION") {
        match val.to_lowercase().as_str() {
            "git" => config.worktree.location = WorktreeLocation::Git,
            "xdg" => config.worktree.location = WorktreeLocation::Xdg,
            other => {
                tracing::warn!(
                    value = other,
                    "invalid IX_WORKTREE_LOCATION (expected 'git' or 'xdg'), ignoring"
                );
            }
        }
    }

    if let Some(val) = parse_bool("IX_WORKTREE_AUTO_CLEANUP") {
        config.worktree.auto_cleanup = val;
    }

    if let Ok(val) = std::env::var("IX_WORKTREE_CACHE_COUNT") {
        match val.parse::<u32>() {
            Ok(count) => config.worktree.cache_count = count,
            Err(_) => {
                tracing::warn!(
                    value = val,
                    "invalid IX_WORKTREE_CACHE_COUNT (expected integer), ignoring"
                );
            }
        }
    }

    if let Some(val) = parse_bool("IX_WORKTREE_COW") {
        config.worktree.cow_cache.enabled = val;
    }

    if let Ok(val) = std::env::var("IX_SERVER") {
        if !val.is_empty() {
            config.server = val;
        }
    }

    if let Ok(val) = std::env::var("IX_TOKEN") {
        if !val.is_empty() {
            config.token = Some(val);
        }
    }
}

fn parse_bool(name: &str) -> Option<bool> {
    let val = std::env::var(name).ok()?;
    match val.to_lowercase().as_str() {
        "1" | "true" | "yes" | "on" => Some(true),
        "0" | "false" | "no" | "off" => Some(false),
        other => {
            tracing::warn!(
                var = name,
                value = other,
                "invalid boolean value (expected 1/0, true/false, yes/no), ignoring"
            );
            None
        }
    }
}

#[cfg(test)]
#[expect(
    unsafe_code,
    clippy::undocumented_unsafe_blocks,
    clippy::multiple_unsafe_ops_per_block,
    reason = "Test code - single-threaded env var manipulation"
)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_bool() {
        unsafe {
            std::env::set_var("TEST_BOOL_TRUE", "true");
            std::env::set_var("TEST_BOOL_FALSE", "0");
            std::env::set_var("TEST_BOOL_INVALID", "maybe");
        }

        assert_eq!(parse_bool("TEST_BOOL_TRUE"), Some(true));
        assert_eq!(parse_bool("TEST_BOOL_FALSE"), Some(false));
        assert_eq!(parse_bool("TEST_BOOL_INVALID"), None);
        assert_eq!(parse_bool("TEST_BOOL_UNSET"), None);
    }

    #[test]
    fn test_overrides() {
        unsafe {
            std::env::set_var("IX_WORKTREE", "1");
            std::env::set_var("IX_WORKTREE_LOCATION", "xdg");
            std::env::set_var("IX_WORKTREE_CACHE_COUNT", "10");
        }

        let mut config = Settings::default();
        apply_overrides(&mut config);

        assert!(config.worktree.enabled);
        assert_eq!(config.worktree.location, WorktreeLocation::Xdg);
        assert_eq!(config.worktree.cache_count, 10);
    }
}
