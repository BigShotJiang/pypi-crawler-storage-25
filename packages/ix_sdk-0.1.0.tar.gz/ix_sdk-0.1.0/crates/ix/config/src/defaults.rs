#[must_use]
pub fn generate() -> String {
    let docs_url = crate::server::default_docs_url();

    format!(
        r#"# ix configuration
# See: {docs_url}

# Authentication token for ix platform (or use IX_TOKEN env var)
# token = "ix_..."

# Default ix server URL
# server = "{server_url}"

# Default branch prefix (e.g., "feature/", "andrewgazelka/")
# branch_prefix = ""

[worktree]
# Create worktrees by default when creating branches
# Set IX_WORKTREE=1 to enable via environment
enabled = false

# Where to store worktrees:
# - "git": .git/worktrees/ (best for AI agents bound to repo directory)
# - "xdg": ~/.local/share/ix/worktrees/<repo>/ (better for manual workflows)
location = "git"

# Automatically cleanup worktrees after branch is merged
auto_cleanup = true

# Number of cached base worktrees to maintain (for fast CoW cloning)
cache_count = 5

[worktree.cow_cache]
# Use copy-on-write cloning for cached directories (APFS/btrfs/XFS)
enabled = true

# Directories to cache (build artifacts, dependencies)
directories = [
    "target",
    "node_modules",
    ".build",
    "dist",
    "vendor",
    "__pycache__",
    ".venv",
]
"#,
        docs_url = docs_url,
        server_url = crate::server::DEFAULT_URL
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_is_valid_toml() {
        let content = generate();
        let parsed: Result<crate::schema::Settings, _> = toml::from_str(&content);
        assert!(parsed.is_ok(), "default config should be valid TOML");
    }
}
