pub const DEFAULT_GIT_HOST: &str = "ix.dev";

pub const DEFAULT_API_HOST: &str = "api.ix.dev";

pub const DEFAULT_URL: &str = "https://api.ix.dev";

pub const DEFAULT_FRONTEND_URL: &str = "https://ix.dev";

pub const DEFAULT_HOST: &str = DEFAULT_GIT_HOST;

#[must_use]
pub fn default_url() -> String {
    DEFAULT_URL.to_owned()
}

#[must_use]
pub fn default_docs_url() -> String {
    format!("{}/docs/config", DEFAULT_FRONTEND_URL)
}

#[must_use]
pub fn is_default_http_url(url: &str) -> bool {
    url == DEFAULT_URL || url == DEFAULT_FRONTEND_URL || strip_default_http_prefix(url).is_some()
}

#[must_use]
pub fn is_default_git_ssh_url(url: &str) -> bool {
    strip_default_git_ssh_prefix(url).is_some()
}

#[must_use]
pub fn strip_default_http_prefix(url: &str) -> Option<&str> {
    for host in [DEFAULT_API_HOST, DEFAULT_GIT_HOST] {
        let https_prefix = format!("https://{host}/");
        let http_prefix = format!("http://{host}/");
        if let Some(rest) = url.strip_prefix(&https_prefix) {
            return Some(rest);
        }
        if let Some(rest) = url.strip_prefix(&http_prefix) {
            return Some(rest);
        }
    }
    None
}

#[must_use]
pub fn strip_default_git_ssh_prefix(url: &str) -> Option<&str> {
    let git_prefix = format!("git@{DEFAULT_GIT_HOST}:");
    url.strip_prefix(&git_prefix)
}
