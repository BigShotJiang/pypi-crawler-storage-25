#![feature(const_trait_impl, const_convert)]

mod codec;
mod prefixes;

#[cfg(test)]
mod tests;

use std::{fmt, hash::Hash, marker::PhantomData, str::FromStr};

pub use crate::prefixes::*;

const ALPHABET: &[u8; 32] = b"0123456789abcdefghjkmnpqrstvwxyz";

/// Maximum allowed prefix length (TypeId spec).
const MAX_PREFIX_LEN: usize = 63;

/// Encoded suffix length in base32 characters (128-bit UUID / 5 bits per char, rounded up + 2 padding bits).
const SUFFIX_LEN: usize = 26;

/// Bits per base32-encoded character.
const BITS_PER_CHAR: u32 = 5;

/// Mask for a single base32 character value (5 bits).
const BASE32_CHAR_MASK: u128 = 0x1F;

/// Padding bits added before encoding / removed after decoding (130 - 128 = 2).
const PADDING_BITS: u32 = 2;

/// Number of bytes in a UUID.
const UUID_BYTE_LEN: usize = 16;

/// Total bits in a UUID (128).
const UUID_TOTAL_BITS: u32 = 128;

/// Bits per byte.
const BITS_PER_BYTE: u32 = 8;

/// Byte mask for extracting a single byte from a u128.
const BYTE_MASK: u128 = 0xFF;

/// ASCII range upper bound for decode table lookup.
const ASCII_RANGE: usize = 128;

/// Sentinel value for unmapped characters in the decode table.
const DECODE_INVALID: i8 = -1;

#[expect(
    clippy::indexing_slicing,
    reason = "const context requires direct indexing; all indices are ASCII literals < 128"
)]
const DECODE_TABLE: [i8; ASCII_RANGE] = {
    let mut table = [-1i8; ASCII_RANGE];
    let mut i: usize = 0;
    while i < 32 {
        let Ok(idx) = i8::try_from(i) else {
            panic!("index exceeds i8::MAX");
        };
        table[ALPHABET[i] as usize] = idx;
        i += 1;
    }
    table[b'A' as usize] = 10;
    table[b'B' as usize] = 11;
    table[b'C' as usize] = 12;
    table[b'D' as usize] = 13;
    table[b'E' as usize] = 14;
    table[b'F' as usize] = 15;
    table[b'G' as usize] = 16;
    table[b'H' as usize] = 17;
    table[b'J' as usize] = 18;
    table[b'K' as usize] = 19;
    table[b'M' as usize] = 20;
    table[b'N' as usize] = 21;
    table[b'P' as usize] = 22;
    table[b'Q' as usize] = 23;
    table[b'R' as usize] = 24;
    table[b'S' as usize] = 25;
    table[b'T' as usize] = 26;
    table[b'V' as usize] = 27;
    table[b'W' as usize] = 28;
    table[b'X' as usize] = 29;
    table[b'Y' as usize] = 30;
    table[b'Z' as usize] = 31;
    table[b'i' as usize] = 1;
    table[b'I' as usize] = 1;
    table[b'l' as usize] = 1;
    table[b'L' as usize] = 1;
    table[b'o' as usize] = 0;
    table[b'O' as usize] = 0;
    table
};

#[derive(Debug, Clone, snafu::Snafu)]
#[snafu(visibility(pub))]
pub enum TypeIdError {
    #[snafu(display("invalid format: expected 'prefix_suffix'"))]
    InvalidFormat,

    #[snafu(display("prefix mismatch: expected '{expected}', got '{actual}'"))]
    PrefixMismatch { expected: String, actual: String },

    #[snafu(display("invalid suffix length: expected 26 characters, got {length}"))]
    InvalidSuffixLength { length: usize },

    #[snafu(display("invalid character in suffix: '{character}'"))]
    InvalidCharacter { character: char },

    #[snafu(display("invalid UUID version: expected v7"))]
    InvalidUuidVersion,

    #[snafu(display("invalid UUID variant: expected RFC4122"))]
    InvalidUuidVariant,
}

pub trait TypeIdPrefix: Clone + Copy + fmt::Debug + Send + Sync + 'static {
    const PREFIX: &'static str;
}

#[must_use]
#[expect(
    clippy::indexing_slicing,
    reason = "const validation loops over byte indices; bounds are guarded by the loop condition"
)]
pub const fn is_valid_prefix(s: &str) -> bool {
    let bytes = s.as_bytes();
    if bytes.is_empty() || bytes.len() > MAX_PREFIX_LEN {
        return false;
    }
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if b != b'_' && (b < b'a' || b > b'z') {
            return false;
        }
        i += 1;
    }
    true
}

#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub struct TypeId<P: TypeIdPrefix> {
    uuid: uuid::Uuid,
    _prefix: PhantomData<P>,
}

impl<P: TypeIdPrefix> TypeId<P> {
    #[must_use]
    pub fn new() -> Self {
        Self {
            uuid: uuid::Uuid::now_v7(),
            _prefix: PhantomData,
        }
    }

    #[must_use]
    pub const fn from_uuid(uuid: uuid::Uuid) -> Self {
        Self {
            uuid,
            _prefix: PhantomData,
        }
    }

    #[must_use]
    pub const fn uuid(&self) -> uuid::Uuid {
        self.uuid
    }

    #[must_use]
    pub const fn prefix(&self) -> &'static str {
        P::PREFIX
    }

    fn encode_suffix(&self) -> String {
        let bytes = self.uuid.as_bytes();
        let mut output = String::with_capacity(SUFFIX_LEN);

        let mut bits: u128 = 0;
        for &b in bytes {
            bits = (bits << BITS_PER_BYTE) | u128::from(b);
        }

        bits <<= PADDING_BITS;

        for i in (0..SUFFIX_LEN).rev() {
            #[expect(
                clippy::cast_possible_truncation,
                reason = "i <= SUFFIX_LEN (26), fits u32"
            )]
            let idx = ((bits >> (i as u32 * BITS_PER_CHAR)) & BASE32_CHAR_MASK) as usize;
            // idx is masked to 0..31, ALPHABET has 32 entries — always in bounds
            let ch = ALPHABET.get(idx).copied().unwrap_or_default();
            output.push(char::from(ch));
        }

        output
    }
}

impl<P: TypeIdPrefix> Default for TypeId<P> {
    fn default() -> Self {
        Self::new()
    }
}

impl<P: TypeIdPrefix> fmt::Debug for TypeId<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "TypeId({})", self)
    }
}

impl<P: TypeIdPrefix> fmt::Display for TypeId<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}_{}", P::PREFIX, self.encode_suffix())
    }
}

impl<P: TypeIdPrefix> FromStr for TypeId<P> {
    type Err = TypeIdError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let (prefix, suffix) = s.split_once('_').ok_or(TypeIdError::InvalidFormat)?;

        if prefix != P::PREFIX {
            return Err(TypeIdError::PrefixMismatch {
                expected: P::PREFIX.to_owned(),
                actual: prefix.to_owned(),
            });
        }

        let uuid = codec::decode_suffix(suffix)?;
        Ok(Self::from_uuid(uuid))
    }
}

impl<P: TypeIdPrefix> serde::Serialize for TypeId<P> {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        serializer.serialize_str(&self.to_string())
    }
}

impl<'de, P: TypeIdPrefix> serde::Deserialize<'de> for TypeId<P> {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;
        s.parse().map_err(serde::de::Error::custom)
    }
}

#[cfg(feature = "graphql")]
mod graphql;

#[expect(
    clippy::path_segment_repetition,
    reason = "TypeId is the canonical name for this newtype"
)]
#[macro_export]
macro_rules! define_typeid {
    ($name:ident, $prefix:literal) => {
        #[derive(Debug, Clone, Copy)]
        pub struct $name;

        impl $crate::TypeIdPrefix for $name {
            const PREFIX: &'static str = $prefix;
        }

        const _: () = {
            if !$crate::is_valid_prefix($prefix) {
                panic!("invalid typeid prefix");
            }
        };
    };
}
