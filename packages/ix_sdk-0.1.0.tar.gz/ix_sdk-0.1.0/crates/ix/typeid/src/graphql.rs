use crate::{TypeId, TypeIdPrefix};

impl<P: TypeIdPrefix> async_graphql::InputType for TypeId<P> {
    type RawValueType = Self;

    fn type_name() -> std::borrow::Cow<'static, str> {
        std::borrow::Cow::Borrowed("ID")
    }

    fn create_type_info(registry: &mut async_graphql::registry::Registry) -> String {
        <String as async_graphql::InputType>::create_type_info(registry)
    }

    fn parse(value: Option<async_graphql::Value>) -> async_graphql::InputValueResult<Self> {
        match value {
            Some(async_graphql::Value::String(s)) => {
                s.parse().map_err(async_graphql::InputValueError::custom)
            }
            _ => {
                // Value::default() is Value::Null — the correct sentinel for
                // "no value provided" in async_graphql error reporting.
                let v = match value {
                    Some(v) => v,
                    None => async_graphql::Value::Null,
                };
                Err(async_graphql::InputValueError::expected_type(v))
            }
        }
    }

    fn to_value(&self) -> async_graphql::Value {
        async_graphql::Value::String(self.to_string())
    }

    fn as_raw_value(&self) -> Option<&Self::RawValueType> {
        Some(self)
    }
}

impl<P: TypeIdPrefix> async_graphql::OutputType for TypeId<P> {
    fn type_name() -> std::borrow::Cow<'static, str> {
        std::borrow::Cow::Borrowed("ID")
    }

    fn create_type_info(registry: &mut async_graphql::registry::Registry) -> String {
        <String as async_graphql::OutputType>::create_type_info(registry)
    }

    #[expect(
        refining_impl_trait_reachable,
        reason = "use a concrete ready future to avoid the nightly RPITIT compiler ICE on nix \
                  musl release builds"
    )]
    fn resolve(
        &self,
        _ctx: &async_graphql::ContextSelectionSet<'_>,
        _field: &async_graphql::Positioned<async_graphql::parser::types::Field>,
    ) -> std::future::Ready<async_graphql::ServerResult<async_graphql::Value>> {
        std::future::ready(Ok(async_graphql::Value::String(self.to_string())))
    }
}
