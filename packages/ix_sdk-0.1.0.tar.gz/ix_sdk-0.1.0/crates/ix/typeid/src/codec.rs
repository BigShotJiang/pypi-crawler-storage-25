use crate::{
    ASCII_RANGE, BITS_PER_BYTE, BITS_PER_CHAR, BYTE_MASK, DECODE_INVALID, DECODE_TABLE,
    PADDING_BITS, SUFFIX_LEN, TypeIdError, UUID_BYTE_LEN, UUID_TOTAL_BITS,
};

pub(crate) fn decode_suffix(suffix: &str) -> Result<uuid::Uuid, TypeIdError> {
    if suffix.len() != SUFFIX_LEN {
        return Err(TypeIdError::InvalidSuffixLength {
            length: suffix.len(),
        });
    }

    let mut bits: u128 = 0;
    for c in suffix.chars() {
        let code = c as usize;
        // DECODE_TABLE has ASCII_RANGE entries; out-of-range or unmapped chars -> InvalidCharacter
        let val = if code < ASCII_RANGE {
            DECODE_TABLE.get(code).copied().unwrap_or(DECODE_INVALID)
        } else {
            DECODE_INVALID
        };
        if val < 0 {
            return Err(TypeIdError::InvalidCharacter { character: c });
        }
        // val is non-negative (0..31) after the check above
        #[expect(
            clippy::cast_sign_loss,
            reason = "val proven non-negative by guard above"
        )]
        let unsigned_val = val as u128;
        bits = (bits << BITS_PER_CHAR) | unsigned_val;
    }

    bits >>= PADDING_BITS;

    let mut bytes = [0u8; UUID_BYTE_LEN];
    for (i, byte) in bytes.iter_mut().enumerate() {
        #[expect(
            clippy::cast_possible_truncation,
            reason = "i <= UUID_BYTE_LEN (16), fits u32"
        )]
        let shift = UUID_TOTAL_BITS - BITS_PER_BYTE - i as u32 * BITS_PER_BYTE;
        *byte = ((bits >> shift) & BYTE_MASK) as u8;
    }

    let uuid = uuid::Uuid::from_bytes(bytes);
    if uuid.get_version() != Some(uuid::Version::SortRand) {
        return Err(TypeIdError::InvalidUuidVersion);
    }
    if uuid.get_variant() != uuid::Variant::RFC4122 {
        return Err(TypeIdError::InvalidUuidVariant);
    }
    Ok(uuid)
}
