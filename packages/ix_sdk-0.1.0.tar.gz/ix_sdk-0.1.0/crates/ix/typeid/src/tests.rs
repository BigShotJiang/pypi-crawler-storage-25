use crate::{Id, TypeIdError, UserId};

#[test]
fn test_roundtrip() {
    let id = Id::new();
    let s = id.to_string();
    assert!(s.starts_with("vm_"));
    assert_eq!(s.len(), 3 + 26);

    let parsed: Id = s.parse().unwrap();
    assert_eq!(id.uuid(), parsed.uuid());
}

#[test]
fn test_prefix_mismatch() {
    let id = Id::new();
    let s = id.to_string();

    let result: Result<UserId, _> = s.parse();
    assert!(matches!(result, Err(TypeIdError::PrefixMismatch { .. })));
}

#[test]
fn test_invalid_format() {
    let result: Result<Id, _> = "nounderscore".parse();
    assert!(matches!(result, Err(TypeIdError::InvalidFormat)));
}

#[test]
fn test_invalid_suffix_length() {
    let result: Result<Id, _> = "vm_tooshort".parse();
    assert!(matches!(
        result,
        Err(TypeIdError::InvalidSuffixLength { .. })
    ));
}

#[test]
fn test_invalid_uuid_version() {
    let uuid = uuid::Uuid::new_v4();
    let id = Id::from_uuid(uuid);
    let s = id.to_string();
    let result: Result<Id, _> = s.parse();
    assert!(matches!(result, Err(TypeIdError::InvalidUuidVersion)));
}

#[test]
fn test_serde_roundtrip() {
    let id = Id::new();
    let json = serde_json::to_string(&id).unwrap();
    let parsed: Id = serde_json::from_str(&json).unwrap();
    assert_eq!(id.uuid(), parsed.uuid());
}

#[test]
fn test_display_format() {
    let uuid = uuid::Uuid::parse_str("01932c57-f03c-7f15-8312-f0c4c1e5a0b7").unwrap();
    let id = Id::from_uuid(uuid);
    let s = id.to_string();
    assert!(s.starts_with("vm_"));
    let parsed: Id = s.parse().unwrap();
    assert_eq!(uuid, parsed.uuid());
}
