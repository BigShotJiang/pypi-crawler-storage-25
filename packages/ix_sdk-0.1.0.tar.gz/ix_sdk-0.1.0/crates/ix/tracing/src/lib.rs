use http::{HeaderMap, HeaderName, HeaderValue};
use opentelemetry::{
    propagation::{Extractor, Injector},
    trace::TraceContextExt as _,
};

pub const REQUEST_ID_HEADER_NAME: &str = "x-request-id";
pub const ID_HEADER_NAME: &str = "x-trace-id";
pub const OPERATION_ID_HEADER_NAME: &str = "x-ix-operation-id";

#[must_use]
pub fn request_id_from_http_headers(headers: &HeaderMap) -> Option<&str> {
    non_empty_http_header(headers, REQUEST_ID_HEADER_NAME)
}

pub fn ensure_http_request_id(headers: &mut HeaderMap) -> String {
    let request_id =
        request_id_from_http_headers(headers).map_or_else(new_request_id, str::to_owned);
    set_http_header_if_missing(headers, REQUEST_ID_HEADER_NAME, &request_id);
    request_id
}

pub fn set_http_correlation_response_headers(headers: &mut HeaderMap, request_id: &str) {
    set_http_header(headers, REQUEST_ID_HEADER_NAME, request_id);
    if let Some(trace_id) = current_id() {
        set_http_header(headers, ID_HEADER_NAME, &trace_id);
    }
}

pub fn inject_current_context_into_http_headers(headers: &mut HeaderMap) {
    use tracing_opentelemetry::OpenTelemetrySpanExt as _;

    let cx = tracing::Span::current().context();
    opentelemetry::global::get_text_map_propagator(|propagator| {
        propagator.inject_context(&cx, &mut HttpHeaderInjector(headers));
    });
}

pub fn set_span_parent_from_http_headers(span: &tracing::Span, headers: &HeaderMap) {
    use tracing_opentelemetry::OpenTelemetrySpanExt as _;

    let parent_cx = opentelemetry::global::get_text_map_propagator(|propagator| {
        propagator.extract(&HttpHeaderExtractor(headers))
    });
    if let Err(error) = span.set_parent(parent_cx) {
        tracing::debug!(?error, "failed to set span parent from HTTP headers");
    }
}

pub fn inject_current_context_into_tonic_metadata(metadata: &mut tonic::metadata::MetadataMap) {
    use tracing_opentelemetry::OpenTelemetrySpanExt as _;

    let cx = tracing::Span::current().context();
    opentelemetry::global::get_text_map_propagator(|propagator| {
        propagator.inject_context(&cx, &mut TonicMetadataInjector(metadata));
    });
}

pub fn set_span_parent_from_tonic_metadata(
    span: &tracing::Span,
    metadata: &tonic::metadata::MetadataMap,
) {
    use tracing_opentelemetry::OpenTelemetrySpanExt as _;

    let parent_cx = opentelemetry::global::get_text_map_propagator(|propagator| {
        propagator.extract(&TonicMetadataExtractor(metadata))
    });
    if let Err(error) = span.set_parent(parent_cx) {
        tracing::debug!(?error, "failed to set span parent from tonic metadata");
    }
}

#[must_use]
pub fn operation_id_from_tonic_metadata(metadata: &tonic::metadata::MetadataMap) -> Option<&str> {
    metadata
        .get(OPERATION_ID_HEADER_NAME)
        .and_then(|value| value.to_str().ok())
        .filter(|value| !value.is_empty())
}

pub fn ensure_tonic_operation_id(
    metadata: &mut tonic::metadata::MetadataMap,
    fallback_prefix: &str,
) -> String {
    let operation_id = operation_id_from_tonic_metadata(metadata).map_or_else(
        || current_id().unwrap_or_else(|| fallback_id(fallback_prefix)),
        str::to_owned,
    );
    set_tonic_metadata_if_missing(metadata, OPERATION_ID_HEADER_NAME, &operation_id);
    operation_id
}

pub fn record_span_field(span: &tracing::Span, field_name: &str, value: &str) {
    span.record(field_name, tracing::field::display(value));
}

#[must_use]
pub fn record_span_id(span: &tracing::Span) -> Option<String> {
    let trace_id = span_id(span)?;
    record_span_field(span, "trace_id", &trace_id);
    Some(trace_id)
}

#[must_use]
pub fn span_id(span: &tracing::Span) -> Option<String> {
    use tracing_opentelemetry::OpenTelemetrySpanExt as _;

    let cx = span.context();
    let span_context = cx.span().span_context().clone();
    if span_context.is_valid() {
        Some(span_context.trace_id().to_string())
    } else {
        None
    }
}

#[must_use]
pub fn current_id() -> Option<String> {
    span_id(&tracing::Span::current())
}

fn new_request_id() -> String {
    uuid::Uuid::new_v4().to_string()
}

fn fallback_id(prefix: &str) -> String {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos());
    format!("{prefix}-{nanos:x}")
}

fn non_empty_http_header<'a>(headers: &'a HeaderMap, name: &str) -> Option<&'a str> {
    headers
        .get(name)
        .and_then(|value| value.to_str().ok())
        .filter(|value| !value.is_empty())
}

fn set_http_header_if_missing(headers: &mut HeaderMap, name: &str, value: &str) {
    if headers.get(name).is_none() {
        set_http_header(headers, name, value);
    }
}

fn set_http_header(headers: &mut HeaderMap, name: &str, value: &str) {
    let Ok(header_name) = HeaderName::from_bytes(name.as_bytes()) else {
        return;
    };
    let Ok(header_value) = HeaderValue::from_str(value) else {
        return;
    };
    headers.insert(header_name, header_value);
}

fn set_tonic_metadata_if_missing(
    metadata: &mut tonic::metadata::MetadataMap,
    name: &str,
    value: &str,
) {
    let Ok(metadata_key) = tonic::metadata::MetadataKey::from_bytes(name.as_bytes()) else {
        return;
    };
    if metadata.get(&metadata_key).is_none()
        && let Ok(metadata_value) = tonic::metadata::MetadataValue::try_from(value)
    {
        metadata.insert(metadata_key, metadata_value);
    }
}

struct HttpHeaderInjector<'a>(&'a mut HeaderMap);

impl Injector for HttpHeaderInjector<'_> {
    fn set(&mut self, key: &str, value: String) {
        set_http_header(self.0, key, &value);
    }
}

struct HttpHeaderExtractor<'a>(&'a HeaderMap);

impl Extractor for HttpHeaderExtractor<'_> {
    fn get(&self, key: &str) -> Option<&str> {
        non_empty_http_header(self.0, key)
    }

    fn keys(&self) -> Vec<&str> {
        self.0.keys().map(HeaderName::as_str).collect()
    }
}

struct TonicMetadataInjector<'a>(&'a mut tonic::metadata::MetadataMap);

impl Injector for TonicMetadataInjector<'_> {
    fn set(&mut self, key: &str, value: String) {
        let Ok(metadata_key) = tonic::metadata::MetadataKey::from_bytes(key.as_bytes()) else {
            return;
        };
        let Ok(metadata_value) = value.parse() else {
            return;
        };
        self.0.insert(metadata_key, metadata_value);
    }
}

struct TonicMetadataExtractor<'a>(&'a tonic::metadata::MetadataMap);

impl Extractor for TonicMetadataExtractor<'_> {
    fn get(&self, key: &str) -> Option<&str> {
        self.0.get(key).and_then(|value| value.to_str().ok())
    }

    fn keys(&self) -> Vec<&str> {
        self.0
            .keys()
            .filter_map(|key| match key {
                tonic::metadata::KeyRef::Ascii(value) => Some(value.as_str()),
                tonic::metadata::KeyRef::Binary(_) => None,
            })
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ensure_http_request_id_preserves_existing_value() {
        let mut headers = HeaderMap::new();
        headers.insert(
            REQUEST_ID_HEADER_NAME,
            HeaderValue::from_static("existing-request-id"),
        );

        let request_id = ensure_http_request_id(&mut headers);

        assert_eq!(request_id, "existing-request-id");
        assert_eq!(
            request_id_from_http_headers(&headers),
            Some("existing-request-id")
        );
    }

    #[test]
    fn ensure_tonic_operation_id_preserves_existing_value() {
        let mut metadata = tonic::metadata::MetadataMap::new();
        metadata.insert(
            OPERATION_ID_HEADER_NAME,
            tonic::metadata::MetadataValue::from_static("existing-operation-id"),
        );

        let operation_id = ensure_tonic_operation_id(&mut metadata, "rpc");

        assert_eq!(operation_id, "existing-operation-id");
        assert_eq!(
            operation_id_from_tonic_metadata(&metadata),
            Some("existing-operation-id")
        );
    }
}
